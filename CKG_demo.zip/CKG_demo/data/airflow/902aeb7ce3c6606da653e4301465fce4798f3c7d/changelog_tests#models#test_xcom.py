===
match
---
operator: { [7094,7095]
operator: { [3996,3997]
===
match
---
operator: = [2503,2504]
operator: = [2480,2481]
===
match
---
name: execution_date [3405,3419]
name: execution_date [3851,3865]
===
match
---
string: "key" [3381,3386]
string: "key" [3827,3832]
===
match
---
operator: == [2852,2854]
operator: == [3721,3723]
===
match
---
name: self [2088,2092]
name: self [1875,1879]
===
match
---
name: XCom [2950,2954]
name: XCom [3396,3400]
===
match
---
expr_stmt [7966,7984]
expr_stmt [6081,6099]
===
match
---
simple_stmt [5382,5405]
simple_stmt [4758,4781]
===
match
---
atom_expr [3065,3077]
atom_expr [3527,3539]
===
match
---
name: key [5327,5330]
name: key [4703,4706]
===
match
---
atom_expr [7752,7769]
atom_expr [5825,5842]
===
match
---
dictorsetmaker [3381,3395]
dictorsetmaker [3827,3841]
===
match
---
atom [1980,2023]
atom [1767,1810]
===
match
---
operator: = [7970,7971]
operator: = [6085,6086]
===
match
---
import_as_names [953,989]
import_as_names [908,944]
===
match
---
atom_expr [2239,2265]
atom_expr [2026,2052]
===
match
---
atom [2293,2325]
atom [2550,2582]
===
match
---
name: dag_id1 [7993,8000]
name: dag_id1 [6108,6115]
===
match
---
atom [7802,7834]
atom [5908,5940]
===
match
---
arglist [1545,1560]
arglist [1332,1347]
===
match
---
simple_stmt [7887,7915]
simple_stmt [6002,6030]
===
match
---
atom_expr [8648,8864]
atom_expr [6980,7196]
===
match
---
funcdef [1155,1209]
funcdef [1078,1132]
===
match
---
string: "False" [1955,1962]
string: "False" [1742,1749]
===
match
---
simple_stmt [7568,7785]
simple_stmt [5641,5891]
===
match
---
name: conf_vars [1910,1919]
name: conf_vars [1697,1706]
===
match
---
suite [8627,8953]
suite [6959,7285]
===
match
---
name: resolve_xcom_backend [2160,2180]
name: resolve_xcom_backend [1947,1967]
===
match
---
simple_stmt [1187,1209]
simple_stmt [1110,1132]
===
match
---
string: "test_dag1" [2505,2516]
string: "test_dag1" [2482,2493]
===
match
---
simple_stmt [7923,7958]
simple_stmt [6038,6073]
===
match
---
name: dag_id [3041,3047]
name: dag_id [3499,3505]
===
match
---
import_from [882,920]
import_from [837,875]
===
match
---
name: conf_vars [6906,6915]
name: conf_vars [4293,4302]
===
match
---
assert_stmt [6633,6661]
assert_stmt [3111,3139]
===
match
---
operator: { [1920,1921]
operator: { [1707,1708]
===
match
---
comparison [1577,1622]
comparison [1364,1409]
===
match
---
operator: @ [7790,7791]
operator: @ [5896,5897]
===
match
---
name: self [1475,1479]
name: self [1262,1266]
===
match
---
string: "test_task3" [6254,6266]
string: "test_task3" [3959,3971]
===
match
---
string: "core" [1641,1647]
string: "core" [1428,1434]
===
match
---
simple_stmt [2191,2224]
simple_stmt [1978,2011]
===
match
---
operator: , [6924,6925]
operator: , [4311,4312]
===
match
---
name: json_obj [2855,2863]
name: json_obj [3724,3732]
===
match
---
operator: { [6916,6917]
operator: { [4303,4304]
===
match
---
name: mock [8480,8484]
name: mock [6812,6816]
===
match
---
name: PickleRce [7634,7643]
name: PickleRce [5707,5716]
===
match
---
argument [7737,7769]
argument [5810,5842]
===
match
---
atom_expr [6281,6335]
atom_expr [5101,5155]
===
match
---
name: cls [1545,1548]
name: cls [1332,1335]
===
match
---
argument [8838,8853]
argument [7170,7185]
===
match
---
expr_stmt [3369,3396]
expr_stmt [3815,3842]
===
match
---
simple_stmt [5327,5346]
simple_stmt [4703,4722]
===
match
---
operator: , [1386,1387]
operator: , [1173,1174]
===
match
---
name: system [7495,7501]
name: system [5568,5574]
===
match
---
simple_stmt [4271,4299]
simple_stmt [4624,4652]
===
match
---
operator: == [5642,5644]
operator: == [3327,3329]
===
match
---
name: task_id [7699,7706]
name: task_id [5772,5779]
===
match
---
string: "xcom_enable_pickling" [7811,7833]
string: "xcom_enable_pickling" [5917,5939]
===
match
---
atom_expr [7568,7784]
atom_expr [5641,5890]
===
match
---
name: dag_id [8838,8844]
name: dag_id [7170,7176]
===
match
---
trailer [1582,1598]
trailer [1369,1385]
===
match
---
name: dag_id [3031,3037]
name: dag_id [3489,3495]
===
match
---
simple_stmt [2103,2146]
simple_stmt [1890,1933]
===
match
---
simple_stmt [3369,3397]
simple_stmt [3815,3843]
===
match
---
name: utcnow [3431,3437]
name: utcnow [3877,3883]
===
match
---
trailer [1544,1561]
trailer [1331,1348]
===
match
---
name: raises [7537,7543]
name: raises [5610,5616]
===
match
---
expr_stmt [2390,2417]
expr_stmt [2367,2394]
===
match
---
operator: == [4733,4735]
operator: == [5339,5341]
===
match
---
operator: @ [8479,8480]
operator: @ [6811,6812]
===
match
---
operator: = [5390,5391]
operator: = [4766,4767]
===
match
---
atom_expr [3106,3125]
atom_expr [3572,3591]
===
match
---
name: test_resolve_xcom_class_fallback_to_basexcom_no_config [2033,2087]
name: test_resolve_xcom_class_fallback_to_basexcom_no_config [1820,1874]
===
match
---
arglist [2993,3144]
arglist [3447,3610]
===
match
---
name: airflow [995,1002]
name: airflow [950,957]
===
match
---
suite [1481,1623]
suite [1268,1410]
===
match
---
string: "enable_xcom_pickling" [7104,7126]
string: "enable_xcom_pickling" [4006,4028]
===
match
---
operator: , [7513,7514]
operator: , [5586,5587]
===
match
---
simple_stmt [3747,3776]
simple_stmt [4513,4542]
===
match
---
operator: = [5361,5362]
operator: = [4737,4738]
===
match
---
string: "test_dag5" [8065,8076]
string: "test_dag5" [6180,6191]
===
match
---
string: "xcom_test4" [7972,7984]
string: "xcom_test4" [6087,6099]
===
match
---
simple_stmt [3405,3440]
simple_stmt [3851,3886]
===
match
---
name: XCom [3106,3110]
name: XCom [3572,3576]
===
match
---
simple_stmt [8637,8865]
simple_stmt [6969,7197]
===
match
---
name: issubclass [1534,1544]
name: issubclass [1321,1331]
===
match
---
name: utcnow [7949,7955]
name: utcnow [6064,6070]
===
match
---
name: conf_vars [6281,6290]
name: conf_vars [5101,5110]
===
match
---
comparison [3065,3088]
comparison [3527,3550]
===
match
---
operator: == [3126,3128]
operator: == [3592,3594]
===
match
---
name: timezone [8776,8784]
name: timezone [7108,7116]
===
match
---
dictorsetmaker [1921,1962]
dictorsetmaker [1708,1749]
===
match
---
simple_stmt [6189,6208]
simple_stmt [3894,3913]
===
match
---
operator: = [6252,6253]
operator: = [3957,3958]
===
match
---
string: "True" [6505,6511]
string: "True" [4840,4846]
===
match
---
name: assert_called_once_with [8927,8950]
name: assert_called_once_with [7259,7282]
===
match
---
name: ret_value [6640,6649]
name: ret_value [3118,3127]
===
match
---
trailer [2244,2260]
trailer [2031,2047]
===
match
---
atom [1639,1712]
atom [1426,1499]
===
match
---
atom_expr [2993,3001]
atom_expr [3447,3455]
===
match
---
atom [7094,7137]
atom [3996,4039]
===
match
---
operator: } [2022,2023]
operator: } [1809,1810]
===
match
---
name: set [7573,7576]
name: set [5646,5649]
===
match
---
name: airflow [887,894]
name: airflow [842,849]
===
match
---
expr_stmt [2154,2182]
expr_stmt [1941,1969]
===
match
---
name: key [6189,6192]
name: key [3894,3897]
===
match
---
simple_stmt [6244,6267]
simple_stmt [3949,3972]
===
match
---
classdef [7418,7516]
classdef [5491,5589]
===
match
---
name: instance [8637,8645]
name: instance [6969,6977]
===
match
---
suite [7555,7785]
suite [5628,5891]
===
match
---
atom [2261,2264]
atom [2048,2051]
===
match
---
suite [7434,7516]
suite [5507,5589]
===
match
---
suite [7409,7785]
suite [5482,5891]
===
match
---
trailer [8455,8461]
trailer [6787,6793]
===
match
---
name: cls [2239,2242]
name: cls [2026,2029]
===
match
---
testlist_comp [7504,7514]
testlist_comp [5577,5587]
===
match
---
name: conf_vars [7791,7800]
name: conf_vars [5897,5906]
===
match
---
operator: == [3764,3766]
operator: == [4530,4532]
===
match
---
decorator [7292,7348]
decorator [5356,5412]
===
match
---
simple_stmt [882,921]
simple_stmt [837,876]
===
match
---
name: results [8421,8428]
name: results [6753,6760]
===
match
---
comparison [8449,8473]
comparison [6781,6805]
===
match
---
dotted_name [1062,1085]
dotted_name [985,1008]
===
match
---
name: pytest [845,851]
name: pytest [829,835]
===
match
---
expr_stmt [3405,3439]
expr_stmt [3851,3885]
===
match
---
operator: , [8706,8707]
operator: , [7038,7039]
===
match
---
simple_stmt [1057,1103]
simple_stmt [980,1026]
===
match
---
string: "tests.models.test_xcom.CustomXCom" [1405,1440]
string: "tests.models.test_xcom.CustomXCom" [1192,1227]
===
match
---
name: ret_value [2910,2919]
name: ret_value [3352,3361]
===
match
---
name: execution_date [2426,2440]
name: execution_date [2403,2417]
===
match
---
string: "dag_id" [8845,8853]
string: "dag_id" [7177,7185]
===
match
---
name: pytest [7530,7536]
name: pytest [5603,5609]
===
match
---
name: utcnow [7761,7767]
name: utcnow [5834,5840]
===
match
---
atom_expr [8874,8897]
atom_expr [7206,7229]
===
match
---
string: "core" [6293,6299]
string: "core" [5113,5119]
===
match
---
operator: == [6650,6652]
operator: == [3128,3130]
===
match
---
name: BaseXCom [1842,1850]
name: BaseXCom [1629,1637]
===
match
---
simple_stmt [2426,2461]
simple_stmt [2403,2438]
===
match
---
parameters [7402,7408]
parameters [5466,5481]
===
match
---
simple_stmt [8085,8109]
simple_stmt [6200,6224]
===
match
---
string: "True" [7836,7842]
string: "True" [5942,5948]
===
match
---
operator: = [2533,2534]
operator: = [2510,2511]
===
match
---
testlist_comp [6293,6323]
testlist_comp [5113,5143]
===
match
---
atom_expr [2103,2145]
atom_expr [1890,1932]
===
match
---
simple_stmt [990,1025]
simple_stmt [945,980]
===
match
---
param [1475,1479]
param [1262,1266]
===
match
---
operator: } [6511,6512]
operator: } [4846,4847]
===
match
---
atom [1981,2005]
atom [1768,1792]
===
match
---
name: CustomXCom [1111,1121]
name: CustomXCom [1034,1044]
===
match
---
operator: = [3378,3379]
operator: = [3824,3825]
===
match
---
trailer [6469,6513]
trailer [4804,4848]
===
match
---
comparison [3026,3047]
comparison [3484,3505]
===
match
---
name: staticmethod [1138,1150]
name: staticmethod [1061,1073]
===
match
---
atom_expr [1788,1810]
atom_expr [1575,1597]
===
match
---
name: conf [916,920]
name: conf [871,875]
===
match
---
trailer [2949,2955]
trailer [3395,3401]
===
match
---
atom [2292,2335]
atom [2549,2610]
===
match
---
atom [1640,1664]
atom [1427,1451]
===
match
---
name: value [7628,7633]
name: value [5701,5706]
===
match
---
operator: } [3395,3396]
operator: } [3841,3842]
===
match
---
expr_stmt [7993,8014]
expr_stmt [6108,6129]
===
match
---
name: XCom [7568,7572]
name: XCom [5641,5645]
===
match
---
name: json_obj [4271,4279]
name: json_obj [4624,4632]
===
match
---
operator: , [7610,7611]
operator: , [5683,5684]
===
match
---
name: cls [2209,2212]
name: cls [1996,1999]
===
match
---
testlist_comp [2294,2324]
testlist_comp [2551,2581]
===
match
---
testlist_comp [7305,7335]
testlist_comp [5369,5399]
===
match
---
import_from [921,989]
import_from [876,944]
===
match
---
name: dag_id [7663,7669]
name: dag_id [5736,5742]
===
match
---
operator: = [8032,8033]
operator: = [6147,6148]
===
match
---
operator: = [7706,7707]
operator: = [5779,5780]
===
match
---
string: "enable_xcom_pickling" [2302,2324]
string: "enable_xcom_pickling" [2559,2581]
===
match
---
simple_stmt [5625,5654]
simple_stmt [3310,3339]
===
match
---
trailer [8895,8897]
trailer [7227,7229]
===
match
---
dotted_name [926,945]
dotted_name [881,900]
===
match
---
operator: { [4282,4283]
operator: { [4635,4636]
===
match
---
atom [1889,1892]
atom [1676,1679]
===
match
---
operator: = [7896,7897]
operator: = [6011,6012]
===
match
---
return_stmt [1187,1208]
return_stmt [1110,1131]
===
match
---
name: task_id [3081,3088]
name: task_id [3543,3550]
===
match
---
expr_stmt [2469,2487]
expr_stmt [2446,2464]
===
match
---
expr_stmt [5327,5345]
expr_stmt [4703,4721]
===
match
---
simple_stmt [2232,2276]
simple_stmt [2019,2063]
===
match
---
atom_expr [8730,8747]
atom_expr [7062,7079]
===
match
---
operator: , [7719,7720]
operator: , [5792,5793]
===
match
---
expr_stmt [2426,2460]
expr_stmt [2403,2437]
===
match
---
name: XCom [3026,3030]
name: XCom [3484,3488]
===
match
---
simple_stmt [2390,2418]
simple_stmt [2367,2395]
===
match
---
number: 1 [1890,1891]
number: 1 [1677,1678]
===
match
---
dotted_name [8480,8490]
dotted_name [6812,6822]
===
match
---
arglist [1837,1850]
arglist [1624,1637]
===
match
---
name: json_obj [2390,2398]
name: json_obj [2367,2375]
===
match
---
string: "False" [1704,1711]
string: "False" [1491,1498]
===
match
---
simple_stmt [8055,8077]
simple_stmt [6170,6192]
===
match
---
operator: = [7669,7670]
operator: = [5742,5743]
===
match
---
expr_stmt [8085,8108]
expr_stmt [6200,6223]
===
match
---
string: "key" [8674,8679]
string: "key" [7006,7011]
===
match
---
operator: = [7597,7598]
operator: = [5670,5671]
===
match
---
atom_expr [7492,7501]
atom_expr [5565,5574]
===
match
---
string: b"[1]" [2269,2275]
string: b"[1]" [2056,2062]
===
match
---
assert_stmt [1527,1561]
assert_stmt [1314,1348]
===
match
---
import_from [811,836]
import_from [795,820]
===
match
---
operator: , [1668,1669]
operator: , [1455,1456]
===
match
---
param [1175,1176]
param [1098,1099]
===
match
---
operator: , [7102,7103]
operator: , [4004,4005]
===
match
---
atom [3380,3396]
atom [3826,3842]
===
match
---
operator: , [8603,8604]
operator: , [6935,6936]
===
match
---
string: "enable_xcom_pickling" [6926,6948]
string: "enable_xcom_pickling" [4313,4335]
===
match
---
simple_stmt [8874,8898]
simple_stmt [7206,7230]
===
match
---
operator: = [7633,7634]
operator: = [5706,5707]
===
match
---
atom [4282,4298]
atom [4635,4651]
===
match
---
argument [7663,7681]
argument [5736,5754]
===
match
---
comparison [2239,2275]
comparison [2026,2062]
===
match
---
decorator [1909,1965]
decorator [1696,1752]
===
match
---
string: "value" [2409,2416]
string: "value" [2386,2393]
===
match
---
comparison [1867,1903]
comparison [1654,1690]
===
match
---
operator: == [1605,1607]
operator: == [1392,1394]
===
match
---
atom [7303,7346]
atom [5367,5410]
===
match
---
operator: = [7751,7752]
operator: = [5824,5825]
===
match
---
simple_stmt [7993,8015]
simple_stmt [6108,6130]
===
match
---
testlist_comp [1671,1701]
testlist_comp [1458,1488]
===
match
---
trailer [6915,6959]
trailer [4302,4346]
===
match
---
name: dag_id2 [8055,8062]
name: dag_id2 [6170,6177]
===
match
---
trailer [3177,3179]
trailer [3651,3653]
===
match
---
comparison [3754,3775]
comparison [4520,4541]
===
match
---
atom [2922,3208]
atom [3364,3690]
===
match
---
simple_stmt [6216,6236]
simple_stmt [3921,3941]
===
match
---
string: "key" [2402,2407]
string: "key" [2379,2384]
===
match
---
name: conf_vars [6460,6469]
name: conf_vars [4795,4804]
===
match
---
name: self [7462,7466]
name: self [5535,5539]
===
match
---
string: b"[1]" [1897,1903]
string: b"[1]" [1684,1690]
===
match
---
operator: } [7842,7843]
operator: } [5948,5949]
===
match
---
atom [7095,7127]
atom [3997,4029]
===
match
---
string: "xcom_test3" [7598,7610]
string: "xcom_test3" [5671,5683]
===
match
---
string: "xcom_backend" [2130,2144]
string: "xcom_backend" [1917,1931]
===
match
---
simple_stmt [785,795]
simple_stmt [785,795]
===
match
---
simple_stmt [2525,2548]
simple_stmt [2502,2525]
===
match
---
expr_stmt [1782,1810]
expr_stmt [1569,1597]
===
match
---
trailer [3437,3439]
trailer [3883,3885]
===
match
---
trailer [3110,3125]
trailer [3576,3591]
===
match
---
decorators [1909,2025]
decorators [1696,1812]
===
match
---
name: value [8693,8698]
name: value [7025,7030]
===
match
---
name: timezone [7752,7760]
name: timezone [5825,5833]
===
match
---
trailer [8791,8793]
trailer [7123,7125]
===
match
---
param [7403,7407]
param [5467,5472]
===
match
---
atom_expr [7634,7645]
atom_expr [5707,5718]
===
match
---
operator: = [2441,2442]
operator: = [2418,2419]
===
match
---
name: mock_orm_deserialize [8906,8926]
name: mock_orm_deserialize [7238,7258]
===
match
---
funcdef [7352,7785]
funcdef [5416,5891]
===
match
---
suite [8429,8474]
suite [6761,6806]
===
match
---
dictorsetmaker [2402,2416]
dictorsetmaker [2379,2393]
===
match
---
simple_stmt [2910,3209]
simple_stmt [3352,3691]
===
match
---
atom [1378,1441]
atom [1165,1228]
===
match
---
name: task_id [2525,2532]
name: task_id [2502,2509]
===
match
---
operator: , [8793,8794]
operator: , [7125,7126]
===
match
---
string: "core" [7096,7102]
string: "core" [3998,4004]
===
match
---
simple_stmt [2835,2864]
simple_stmt [3704,3733]
===
match
---
trailer [3030,3037]
trailer [3488,3495]
===
match
---
operator: } [1711,1712]
operator: } [1498,1499]
===
match
---
operator: , [961,962]
operator: , [916,917]
===
match
---
simple_stmt [2469,2488]
simple_stmt [2446,2465]
===
match
---
trailer [1580,1582]
trailer [1367,1369]
===
match
---
string: "test_dag4" [8003,8014]
string: "test_dag4" [6118,6129]
===
match
---
comparison [3106,3143]
comparison [3572,3609]
===
match
---
operator: = [8646,8647]
operator: = [6978,6979]
===
match
---
suite [1178,1209]
suite [1101,1132]
===
match
---
operator: , [8679,8680]
operator: , [7011,7012]
===
match
---
simple_stmt [8442,8474]
simple_stmt [6774,6806]
===
match
---
simple_stmt [1819,1852]
simple_stmt [1606,1639]
===
match
---
expr_stmt [1490,1518]
expr_stmt [1277,1305]
===
match
---
name: ret_value [2842,2851]
name: ret_value [3711,3720]
===
match
---
name: mock [832,836]
name: mock [816,820]
===
match
---
string: "value" [4290,4297]
string: "value" [4643,4650]
===
match
---
operator: @ [1909,1910]
operator: @ [1696,1697]
===
match
---
name: os [7492,7494]
name: os [5565,5567]
===
match
---
import_name [838,851]
import_name [822,835]
===
match
---
expr_stmt [6244,6266]
expr_stmt [3949,3971]
===
match
---
dictorsetmaker [7802,7842]
dictorsetmaker [5908,5948]
===
match
---
name: dag_id [5354,5360]
name: dag_id [4730,4736]
===
match
---
name: cls [1782,1785]
name: cls [1569,1572]
===
match
---
name: query [2944,2949]
name: query [3390,3395]
===
match
---
operator: = [8698,8699]
operator: = [7030,7031]
===
match
---
operator: , [7501,7502]
operator: , [5574,5575]
===
match
---
dictorsetmaker [2293,2334]
dictorsetmaker [2550,2609]
===
match
---
funcdef [2029,2276]
funcdef [1816,2063]
===
match
---
name: timestamp [8720,8729]
name: timestamp [7052,7061]
===
match
---
atom_expr [2936,3198]
atom_expr [3382,3676]
===
match
---
trailer [7767,7769]
trailer [5840,5842]
===
match
---
operator: , [2128,2129]
operator: , [1915,1916]
===
match
---
name: XCom [963,967]
name: XCom [918,922]
===
match
---
string: "core" [1922,1928]
string: "core" [1709,1715]
===
match
---
operator: } [6957,6958]
operator: } [4344,4345]
===
match
---
comparison [4723,4744]
comparison [5329,5350]
===
match
---
trailer [3430,3437]
trailer [3876,3883]
===
match
---
operator: } [1440,1441]
operator: } [1227,1228]
===
match
---
name: dag_id [2496,2502]
name: dag_id [2473,2479]
===
match
---
dictorsetmaker [7899,7913]
dictorsetmaker [6014,6028]
===
match
---
string: "core" [7305,7311]
string: "core" [5369,5375]
===
match
---
name: XCom [3065,3069]
name: XCom [3527,3531]
===
match
---
name: resolve_xcom_backend [1788,1808]
name: resolve_xcom_backend [1575,1595]
===
match
---
operator: == [1894,1896]
operator: == [1681,1683]
===
match
---
argument [7699,7719]
argument [5772,5792]
===
match
---
operator: , [1928,1929]
operator: , [1715,1716]
===
match
---
name: conf_vars [1970,1979]
name: conf_vars [1757,1766]
===
match
---
string: "core" [2122,2128]
string: "core" [1909,1915]
===
match
---
operator: @ [1367,1368]
operator: @ [1154,1155]
===
match
---
name: execution_date [7923,7937]
name: execution_date [6038,6052]
===
match
---
name: ret_value [3754,3763]
name: ret_value [4520,4529]
===
match
---
trailer [1598,1604]
trailer [1385,1391]
===
match
---
decorated [1628,1904]
decorated [1415,1691]
===
match
---
name: test_xcom_disable_pickle_type_fail_on_non_json [7356,7402]
name: test_xcom_disable_pickle_type_fail_on_non_json [5420,5466]
===
match
---
atom_expr [8449,8461]
atom_expr [6781,6793]
===
match
---
simple_stmt [1860,1904]
simple_stmt [1647,1691]
===
match
---
string: "xcom_backend" [1649,1663]
string: "xcom_backend" [1436,1450]
===
match
---
assert_stmt [3747,3775]
assert_stmt [4513,4541]
===
match
---
trailer [1516,1518]
trailer [1303,1305]
===
match
---
argument [8761,8793]
argument [7093,7125]
===
match
---
argument [8807,8824]
argument [7139,7156]
===
match
---
operator: } [4297,4298]
operator: } [4650,4651]
===
match
---
string: "xcom_test3" [5333,5345]
string: "xcom_test3" [4709,4721]
===
match
---
trailer [8926,8950]
trailer [7258,7282]
===
match
---
operator: , [1988,1989]
operator: , [1775,1776]
===
match
---
operator: , [7681,7682]
operator: , [5754,5755]
===
match
---
name: issubclass [1826,1836]
name: issubclass [1613,1623]
===
match
---
name: XCom [2993,2997]
name: XCom [3447,3451]
===
match
---
simple_stmt [1527,1562]
simple_stmt [1314,1349]
===
match
---
trailer [7948,7955]
trailer [6063,6070]
===
match
---
trailer [2458,2460]
trailer [2435,2437]
===
match
---
name: conf_vars [1093,1102]
name: conf_vars [1016,1025]
===
match
---
param [2088,2092]
param [1875,1879]
===
match
---
funcdef [8545,8953]
funcdef [6877,7285]
===
match
---
dotted_name [995,1008]
dotted_name [950,963]
===
match
---
decorator [8479,8541]
decorator [6811,6873]
===
match
---
atom_expr [4324,4341]
atom_expr [4677,4694]
===
match
---
parameters [7461,7467]
parameters [5534,5540]
===
match
---
operator: = [3420,3421]
operator: = [3866,3867]
===
match
---
name: test_xcom_init_on_load_uses_orm_deserialize_value [8549,8598]
name: test_xcom_init_on_load_uses_orm_deserialize_value [6881,6930]
===
match
---
name: self [7403,7407]
name: self [5467,5471]
===
match
---
trailer [7093,7138]
trailer [3995,4040]
===
match
---
string: "value" [7906,7913]
string: "value" [6021,6028]
===
match
---
name: value [8456,8461]
name: value [6788,6793]
===
match
---
operator: = [8673,8674]
operator: = [7005,7006]
===
match
---
atom [7801,7843]
atom [5907,5949]
===
match
---
trailer [4339,4341]
trailer [4692,4694]
===
match
---
assert_stmt [4716,4744]
assert_stmt [5322,5350]
===
match
---
operator: { [6291,6292]
operator: { [5111,5112]
===
match
---
string: "key" [4283,4288]
string: "key" [4636,4641]
===
match
---
atom [6292,6324]
atom [5112,5144]
===
match
---
expr_stmt [5354,5373]
expr_stmt [4730,4749]
===
match
---
operator: , [7809,7810]
operator: , [5915,5916]
===
match
---
operator: , [6478,6479]
operator: , [4813,4814]
===
match
---
name: conf_vars [1629,1638]
name: conf_vars [1416,1425]
===
match
---
operator: == [8462,8464]
operator: == [6794,6796]
===
match
---
simple_stmt [921,990]
simple_stmt [876,945]
===
match
---
string: "test_task3" [7707,7719]
string: "test_task3" [5780,5792]
===
match
---
string: "test_task4" [8034,8046]
string: "test_task4" [6149,6161]
===
match
---
trailer [2121,2145]
trailer [1908,1932]
===
match
---
name: tests [1062,1067]
name: tests [985,990]
===
match
---
string: "core" [7803,7809]
string: "core" [5909,5915]
===
match
---
name: serialize_value [1873,1888]
name: serialize_value [1660,1675]
===
match
---
operator: = [2473,2474]
operator: = [2450,2451]
===
match
---
operator: = [6193,6194]
operator: = [3898,3899]
===
match
---
operator: == [3078,3080]
operator: == [3540,3542]
===
match
---
operator: { [3380,3381]
operator: { [3826,3827]
===
match
---
atom [1921,1953]
atom [1708,1740]
===
match
---
name: key [3005,3008]
name: key [3459,3462]
===
match
---
operator: , [2300,2301]
operator: , [2557,2558]
===
match
---
operator: @ [7292,7293]
operator: @ [5356,5357]
===
match
---
name: resolve_xcom_backend [1496,1516]
name: resolve_xcom_backend [1283,1303]
===
match
---
dictorsetmaker [7304,7345]
dictorsetmaker [5368,5409]
===
match
---
name: execution_date [3111,3125]
name: execution_date [3577,3591]
===
match
---
operator: { [1639,1640]
operator: { [1426,1427]
===
match
---
testlist [7492,7515]
testlist [5565,5588]
===
match
---
trailer [8656,8864]
trailer [6988,7196]
===
match
---
import_name [785,794]
import_name [785,794]
===
match
---
string: "core" [1380,1386]
string: "core" [1167,1173]
===
match
---
atom_expr [3026,3037]
atom_expr [3484,3495]
===
match
---
string: "custom_value" [1194,1208]
string: "custom_value" [1117,1131]
===
match
---
assert_stmt [2835,2863]
assert_stmt [3704,3732]
===
match
---
operator: = [8063,8064]
operator: = [6178,6179]
===
match
---
name: timezone [8730,8738]
name: timezone [7062,7070]
===
match
---
assert_stmt [2232,2275]
assert_stmt [2019,2062]
===
match
---
name: key [8670,8673]
name: key [7002,7005]
===
match
---
expr_stmt [4271,4298]
expr_stmt [4624,4651]
===
match
---
trailer [2975,3158]
trailer [3425,3628]
===
match
---
name: os [792,794]
name: os [792,794]
===
match
---
funcdef [1718,1904]
funcdef [1505,1691]
===
match
---
dictorsetmaker [6292,6333]
dictorsetmaker [5112,5153]
===
match
---
name: timezone [2443,2451]
name: timezone [2420,2428]
===
match
---
decorated [1909,2276]
decorated [1696,2063]
===
match
---
operator: @ [1969,1970]
operator: @ [1756,1757]
===
match
---
expr_stmt [2525,2547]
expr_stmt [2502,2524]
===
match
---
trailer [1872,1888]
trailer [1659,1675]
===
match
---
atom [6916,6958]
atom [4303,4345]
===
match
---
string: "core" [2294,2300]
string: "core" [2551,2557]
===
match
---
trailer [1888,1893]
trailer [1675,1680]
===
match
---
dictorsetmaker [4283,4297]
dictorsetmaker [4636,4650]
===
match
---
atom_expr [3422,3439]
atom_expr [3868,3885]
===
match
---
name: conf_vars [1368,1377]
name: conf_vars [1155,1164]
===
match
---
parameters [1474,1480]
parameters [1261,1267]
===
match
---
trailer [2451,2458]
trailer [2428,2435]
===
match
---
testlist_comp [1922,1952]
testlist_comp [1709,1739]
===
match
---
name: conf [2103,2107]
name: conf [1890,1894]
===
match
---
trailer [8950,8952]
trailer [7282,7284]
===
match
---
simple_stmt [7485,7516]
simple_stmt [5558,5589]
===
match
---
operator: = [2399,2400]
operator: = [2376,2377]
===
match
---
name: configuration [895,908]
name: configuration [850,863]
===
match
---
atom_expr [8906,8952]
atom_expr [7238,7284]
===
match
---
operator: = [4322,4323]
operator: = [4675,4676]
===
match
---
atom_expr [6460,6513]
atom_expr [4795,4848]
===
match
---
name: PickleRce [7424,7433]
name: PickleRce [5497,5506]
===
match
---
operator: } [7345,7346]
operator: } [5409,5410]
===
match
---
name: unittest [816,824]
name: unittest [800,808]
===
match
---
atom [6471,6503]
atom [4806,4838]
===
match
---
operator: , [6299,6300]
operator: , [5119,5120]
===
match
---
name: first [3172,3177]
name: first [3646,3651]
===
match
---
arglist [7594,7770]
arglist [5667,5876]
===
match
---
name: patch [8485,8490]
name: patch [6817,6822]
===
match
---
atom [6470,6512]
atom [4805,4847]
===
match
---
name: utcnow [2452,2458]
name: utcnow [2429,2435]
===
match
---
name: json_obj [8465,8473]
name: json_obj [6797,6805]
===
match
---
name: key [7594,7597]
name: key [5667,5670]
===
match
---
assert_stmt [1570,1622]
assert_stmt [1357,1409]
===
match
---
simple_stmt [2496,2517]
simple_stmt [2473,2494]
===
match
---
atom_expr [7084,7138]
atom_expr [3986,4040]
===
match
---
name: timezone [1016,1024]
name: timezone [971,979]
===
match
---
name: xcom [941,945]
name: xcom [896,900]
===
match
---
name: conf_vars [7293,7302]
name: conf_vars [5357,5366]
===
match
---
operator: , [1840,1841]
operator: , [1627,1628]
===
match
---
testlist_comp [1380,1402]
testlist_comp [1167,1189]
===
match
---
trailer [2180,2182]
trailer [1967,1969]
===
match
---
testlist_comp [7803,7833]
testlist_comp [5909,5939]
===
match
---
name: TypeError [7544,7553]
name: TypeError [5617,5626]
===
match
---
atom_expr [1534,1561]
atom_expr [1321,1348]
===
match
---
operator: { [1980,1981]
operator: { [1767,1768]
===
match
---
operator: { [7303,7304]
operator: { [5367,5368]
===
match
---
comparison [2993,3008]
comparison [3447,3462]
===
match
---
simple_stmt [1570,1623]
simple_stmt [1357,1410]
===
match
---
name: cls [1837,1840]
name: cls [1624,1627]
===
match
---
param [8599,8604]
param [6931,6936]
===
match
---
name: task_id2 [8085,8093]
name: task_id2 [6200,6208]
===
match
---
atom [1379,1403]
atom [1166,1190]
===
match
---
assert_stmt [1860,1903]
assert_stmt [1647,1690]
===
match
---
trailer [7955,7957]
trailer [6070,6072]
===
match
---
dictorsetmaker [1640,1711]
dictorsetmaker [1427,1498]
===
match
---
name: timezone [7940,7948]
name: timezone [6055,6063]
===
match
---
operator: , [2212,2213]
operator: , [1999,2000]
===
match
---
parameters [2087,2093]
parameters [1874,1880]
===
match
---
name: __reduce__ [7451,7461]
name: __reduce__ [5524,5534]
===
match
---
name: ret_value [4723,4732]
name: ret_value [5329,5338]
===
match
---
name: mock_orm_deserialize [8605,8625]
name: mock_orm_deserialize [6937,6957]
===
match
---
atom_expr [6906,6959]
atom_expr [4293,4346]
===
match
---
name: conf_vars [7084,7093]
name: conf_vars [3986,3995]
===
match
---
string: "xcom_enable_pickling" [7313,7335]
string: "xcom_enable_pickling" [5377,5399]
===
match
---
string: "test_task1" [2535,2547]
string: "test_task1" [2512,2524]
===
match
---
string: "custom_value" [1608,1622]
string: "custom_value" [1395,1409]
===
match
---
funcdef [7447,7516]
funcdef [5520,5589]
===
match
---
name: json_obj [7887,7895]
name: json_obj [6002,6010]
===
match
---
operator: , [8853,8854]
operator: , [7185,7186]
===
match
---
simple_stmt [1782,1811]
simple_stmt [1569,1598]
===
match
---
name: cls [2154,2157]
name: cls [1941,1944]
===
match
---
expr_stmt [6189,6207]
expr_stmt [3894,3912]
===
match
---
name: value [3193,3198]
name: value [3671,3676]
===
match
---
parameters [1174,1177]
parameters [1097,1100]
===
match
---
string: "xcom_test1" [2475,2487]
string: "xcom_test1" [2452,2464]
===
match
---
atom_expr [2160,2182]
atom_expr [1947,1969]
===
match
---
operator: = [7938,7939]
operator: = [6053,6054]
===
match
---
name: dag_id [6216,6222]
name: dag_id [3921,3927]
===
match
---
trailer [1836,1851]
trailer [1623,1638]
===
match
---
operator: } [2416,2417]
operator: } [2393,2394]
===
match
---
operator: { [2401,2402]
operator: { [2378,2379]
===
match
---
testlist_comp [1982,2004]
testlist_comp [1769,1791]
===
match
---
simple_stmt [2154,2183]
simple_stmt [1941,1970]
===
match
---
trailer [7543,7554]
trailer [5616,5627]
===
match
---
testlist_comp [1641,1663]
testlist_comp [1428,1450]
===
match
---
operator: , [7311,7312]
operator: , [5375,5376]
===
match
---
operator: , [3008,3009]
operator: , [3462,3463]
===
match
---
trailer [7576,7784]
trailer [5649,5890]
===
match
---
name: cls [1577,1580]
name: cls [1364,1367]
===
match
---
name: serialize_value [1583,1598]
name: serialize_value [1370,1385]
===
match
---
trailer [2943,2949]
trailer [3389,3395]
===
match
---
operator: == [3002,3004]
operator: == [3456,3458]
===
match
---
number: 1 [2262,2263]
number: 1 [2049,2050]
===
match
---
simple_stmt [4716,4745]
simple_stmt [5322,5351]
===
match
---
testlist_comp [7096,7126]
testlist_comp [3998,4028]
===
match
---
name: timezone [4324,4332]
name: timezone [4677,4685]
===
match
---
expr_stmt [7923,7957]
expr_stmt [6038,6072]
===
match
---
trailer [7494,7501]
trailer [5567,5574]
===
match
---
simple_stmt [8906,8953]
simple_stmt [7238,7285]
===
match
---
decorated [1137,1209]
decorated [1060,1132]
===
match
---
name: result [8449,8455]
name: result [6781,6787]
===
match
---
operator: , [3143,3144]
operator: , [3609,3610]
===
match
---
operator: } [7913,7914]
operator: } [6028,6029]
===
match
---
atom_expr [7530,7554]
atom_expr [5603,5627]
===
match
---
trailer [1870,1872]
trailer [1657,1659]
===
match
---
expr_stmt [5382,5404]
expr_stmt [4758,4780]
===
match
---
name: task_id [8807,8814]
name: task_id [7139,7146]
===
match
---
atom [7304,7336]
atom [5368,5400]
===
match
---
suite [1773,1904]
suite [1560,1691]
===
match
---
operator: } [2334,2335]
operator: } [2609,2610]
===
match
---
operator: , [7645,7646]
operator: , [5718,5719]
===
match
---
string: "ls -alt" [7504,7513]
string: "ls -alt" [5577,5586]
===
match
---
string: "enable_xcom_pickling" [6480,6502]
string: "enable_xcom_pickling" [4815,4837]
===
match
---
decorator [7790,7845]
decorator [5896,5951]
===
match
---
operator: , [967,968]
operator: , [922,923]
===
match
---
comparison [6640,6661]
comparison [3118,3139]
===
match
---
name: execution_date [3129,3143]
name: execution_date [3595,3609]
===
match
---
name: json_obj [5645,5653]
name: json_obj [3330,3338]
===
match
---
arglist [8670,8854]
arglist [7002,7186]
===
match
---
string: "core" [1671,1677]
string: "core" [1458,1464]
===
match
---
string: "xcom_backend" [1990,2004]
string: "xcom_backend" [1777,1791]
===
match
---
trailer [1808,1810]
trailer [1595,1597]
===
match
---
atom [1920,1963]
atom [1707,1750]
===
match
---
import_from [1057,1102]
import_from [980,1025]
===
match
---
argument [7594,7610]
argument [5667,5683]
===
match
---
atom [7898,7914]
atom [6013,6029]
===
match
---
operator: = [1494,1495]
operator: = [1281,1282]
===
match
---
name: utcnow [8739,8745]
name: utcnow [7071,7077]
===
match
---
operator: , [7769,7770]
operator: , [5842,5843]
===
match
---
trailer [8738,8745]
trailer [7070,7077]
===
match
---
trailer [2997,3001]
trailer [3451,3455]
===
match
---
dictorsetmaker [6917,6957]
dictorsetmaker [4304,4344]
===
match
---
dictorsetmaker [1379,1440]
dictorsetmaker [1166,1227]
===
match
---
string: "False" [7129,7136]
string: "False" [4031,4038]
===
match
---
name: test_utils [1068,1078]
name: test_utils [991,1001]
===
match
---
name: remove_option [2108,2121]
name: remove_option [1895,1908]
===
match
---
operator: { [7801,7802]
operator: { [5907,5908]
===
match
---
string: "value" [3388,3395]
string: "value" [3834,3841]
===
match
---
atom_expr [1826,1851]
atom_expr [1613,1638]
===
match
---
atom [2401,2417]
atom [2378,2394]
===
match
---
expr_stmt [7887,7914]
expr_stmt [6002,6029]
===
match
---
string: "test_task5" [8096,8108]
string: "test_task5" [6211,6223]
===
match
---
import_from [990,1024]
import_from [945,979]
===
match
---
name: resolve_xcom_backend [969,989]
name: resolve_xcom_backend [924,944]
===
match
---
trailer [3069,3077]
trailer [3531,3539]
===
match
---
name: utcnow [8785,8791]
name: utcnow [7117,7123]
===
match
---
operator: = [8094,8095]
operator: = [6209,6210]
===
match
---
atom_expr [2443,2460]
atom_expr [2420,2437]
===
match
---
trailer [6290,6335]
trailer [5110,5155]
===
match
---
name: ret_value [5632,5641]
name: ret_value [3317,3326]
===
match
---
argument [7628,7645]
argument [5701,5718]
===
match
---
assert_stmt [8442,8473]
assert_stmt [6774,6805]
===
match
---
with_stmt [7525,7785]
with_stmt [5598,5891]
===
match
---
name: BaseXCom [1122,1130]
name: BaseXCom [1045,1053]
===
match
---
name: _ [1175,1176]
name: _ [1098,1099]
===
match
---
string: "test_task3" [5392,5404]
string: "test_task3" [4768,4780]
===
match
---
string: "test_dag3" [7670,7681]
string: "test_dag3" [5743,5754]
===
match
---
operator: { [7898,7899]
operator: { [6013,6014]
===
match
---
atom_expr [1867,1893]
atom_expr [1654,1680]
===
match
---
dictorsetmaker [7095,7136]
dictorsetmaker [3997,4038]
===
match
---
operator: , [1647,1648]
operator: , [1434,1435]
===
match
---
atom [7503,7515]
atom [5576,5588]
===
match
---
dictorsetmaker [1981,2022]
dictorsetmaker [1768,1809]
===
match
---
argument [8670,8679]
argument [7002,7011]
===
match
---
atom [6917,6949]
atom [4304,4336]
===
match
---
name: config [1079,1085]
name: config [1002,1008]
===
match
---
parameters [8598,8626]
parameters [6930,6958]
===
match
---
operator: @ [1628,1629]
operator: @ [1415,1416]
===
match
---
name: task_id1 [8023,8031]
name: task_id1 [6138,6146]
===
match
---
string: "enable_xcom_pickling" [1930,1952]
string: "enable_xcom_pickling" [1717,1739]
===
match
---
trailer [2260,2265]
trailer [2047,2052]
===
match
---
operator: } [1962,1963]
operator: } [1749,1750]
===
match
---
name: CustomXCom [1550,1560]
name: CustomXCom [1337,1347]
===
match
---
trailer [7536,7543]
trailer [5609,5616]
===
match
---
expr_stmt [6216,6235]
expr_stmt [3921,3940]
===
match
---
operator: , [3047,3048]
operator: , [3505,3506]
===
match
---
name: utcnow [4333,4339]
name: utcnow [4686,4692]
===
match
---
operator: = [5331,5332]
operator: = [4707,4708]
===
match
---
expr_stmt [8637,8864]
expr_stmt [6969,7196]
===
match
---
operator: @ [1137,1138]
operator: @ [1060,1061]
===
match
---
operator: , [8824,8825]
operator: , [7156,7157]
===
match
---
name: test_resolve_xcom_class_fallback_to_basexcom [1722,1766]
name: test_resolve_xcom_class_fallback_to_basexcom [1509,1553]
===
match
---
arglist [2209,2222]
arglist [1996,2009]
===
match
---
name: json_obj [6653,6661]
name: json_obj [3131,3139]
===
match
---
funcdef [1447,1623]
funcdef [1234,1410]
===
match
---
string: "airflow.models.xcom.XCom.orm_deserialize_value" [8491,8539]
string: "airflow.models.xcom.XCom.orm_deserialize_value" [6823,6871]
===
match
---
string: "xcom_backend" [1388,1402]
string: "xcom_backend" [1175,1189]
===
match
---
assert_stmt [2191,2223]
assert_stmt [1978,2010]
===
match
---
name: key [2998,3001]
name: key [3452,3455]
===
match
---
decorator [1969,2025]
decorator [1756,1812]
===
match
---
name: task_id [5382,5389]
name: task_id [4758,4765]
===
match
---
trailer [2208,2223]
trailer [1995,2010]
===
match
---
operator: = [8729,8730]
operator: = [7061,7062]
===
match
---
decorator [1367,1443]
decorator [1154,1230]
===
match
---
name: BaseXCom [8648,8656]
name: BaseXCom [6980,6988]
===
match
---
name: timezone [3422,3430]
name: timezone [3868,3876]
===
match
---
operator: == [3038,3040]
operator: == [3496,3498]
===
match
---
operator: { [6470,6471]
operator: { [4805,4806]
===
match
---
arglist [2122,2144]
arglist [1909,1931]
===
match
---
operator: { [1378,1379]
operator: { [1165,1166]
===
match
---
decorator [1628,1714]
decorator [1415,1501]
===
match
---
name: BaseXCom [953,961]
name: BaseXCom [908,916]
===
match
---
trailer [2242,2244]
trailer [2029,2031]
===
match
---
string: "key" [7899,7904]
string: "key" [6014,6019]
===
match
---
atom_expr [7940,7957]
atom_expr [6055,6072]
===
match
---
argument [8720,8747]
argument [7052,7079]
===
match
---
dotted_name [887,908]
dotted_name [842,863]
===
match
---
trailer [7760,7767]
trailer [5833,5840]
===
match
---
name: key [7966,7969]
name: key [6081,6084]
===
match
---
name: session [2936,2943]
name: session [3382,3389]
===
match
---
name: issubclass [2198,2208]
name: issubclass [1985,1995]
===
match
---
classdef [1105,1209]
classdef [1028,1132]
===
match
---
operator: , [3088,3089]
operator: , [3550,3551]
===
match
---
expr_stmt [2496,2516]
expr_stmt [2473,2493]
===
match
---
assert_stmt [1819,1851]
assert_stmt [1606,1638]
===
match
---
name: key [2469,2472]
name: key [2446,2449]
===
match
---
operator: , [1677,1678]
operator: , [1464,1465]
===
match
---
name: BaseXCom [2214,2222]
name: BaseXCom [2001,2009]
===
match
---
name: self [8599,8603]
name: self [6931,6935]
===
match
---
operator: = [8001,8002]
operator: = [6116,6117]
===
match
---
string: "xcom_test3" [6195,6207]
string: "xcom_test3" [3900,3912]
===
match
---
name: init_on_load [8883,8895]
name: init_on_load [7215,7227]
===
match
---
name: task_id [6244,6251]
name: task_id [3949,3956]
===
match
---
trailer [4332,4339]
trailer [4685,4692]
===
match
---
operator: } [7136,7137]
operator: } [4038,4039]
===
match
---
trailer [3171,3177]
trailer [3645,3651]
===
match
---
string: "core" [6472,6478]
string: "core" [4807,4813]
===
match
---
name: utils [1003,1008]
name: utils [958,963]
===
match
---
expr_stmt [8023,8046]
expr_stmt [6138,6161]
===
match
---
string: "enable_xcom_pickling" [1679,1701]
string: "enable_xcom_pickling" [1466,1488]
===
match
---
operator: = [4280,4281]
operator: = [4633,4634]
===
match
---
name: task_id [3070,3077]
name: task_id [3532,3539]
===
match
---
trailer [7572,7576]
trailer [5645,5649]
===
match
---
name: execution_date [8761,8775]
name: execution_date [7093,7107]
===
match
---
suite [2094,2276]
suite [1881,2063]
===
match
---
param [7462,7466]
param [5535,5539]
===
match
---
operator: , [8747,8748]
operator: , [7079,7080]
===
match
---
decorator [1137,1151]
decorator [1060,1074]
===
match
---
decorated [1367,1623]
decorated [1154,1410]
===
match
---
operator: { [2292,2293]
operator: { [2549,2550]
===
match
---
param [1767,1771]
param [1554,1558]
===
match
---
testlist_comp [6918,6948]
testlist_comp [4305,4335]
===
match
---
name: execution_date [7737,7751]
name: execution_date [5810,5824]
===
match
---
name: test_resolve_xcom_class [1451,1474]
name: test_resolve_xcom_class [1238,1261]
===
match
---
string: "core" [1982,1988]
string: "core" [1769,1775]
===
match
---
operator: = [2920,2921]
operator: = [3362,3363]
===
match
---
decorated [7292,7785]
decorated [5356,5891]
===
match
---
string: "test_dag" [6225,6235]
string: "test_dag" [3930,3940]
===
match
---
operator: = [1786,1787]
operator: = [1573,1574]
===
match
---
simple_stmt [5354,5374]
simple_stmt [4730,4750]
===
match
---
operator: == [2266,2268]
operator: == [2053,2055]
===
match
---
trailer [2968,2975]
trailer [3418,3425]
===
match
---
dictorsetmaker [6471,6511]
dictorsetmaker [4806,4846]
===
match
---
for_stmt [8407,8474]
for_stmt [6739,6806]
===
match
---
operator: = [6223,6224]
operator: = [3928,3929]
===
match
---
atom [1670,1702]
atom [1457,1489]
===
match
---
string: "to be removed" [2007,2022]
string: "to be removed" [1794,1809]
===
match
---
string: "task_id" [8815,8824]
string: "task_id" [7147,7156]
===
match
---
operator: , [1548,1549]
operator: , [1335,1336]
===
match
---
name: execution_date [4307,4321]
name: execution_date [4660,4674]
===
match
---
atom_expr [2198,2223]
atom_expr [1985,2010]
===
match
---
name: airflow [926,933]
name: airflow [881,888]
===
match
---
name: filter [2969,2975]
name: filter [3419,3425]
===
match
---
name: cls [1867,1870]
name: cls [1654,1657]
===
match
---
operator: = [8775,8776]
operator: = [7107,7108]
===
match
---
simple_stmt [7966,7985]
simple_stmt [6081,6100]
===
match
---
expr_stmt [4307,4341]
expr_stmt [4660,4694]
===
match
---
suite [7468,7516]
suite [5541,5589]
===
match
---
name: self [1767,1771]
name: self [1554,1558]
===
match
---
expr_stmt [2910,3208]
expr_stmt [3352,3690]
===
match
---
param [8605,8625]
param [6937,6957]
===
match
---
comparison [5632,5653]
comparison [3317,3338]
===
match
---
string: "test_dag" [5363,5373]
string: "test_dag" [4739,4749]
===
match
---
name: json_obj [4736,4744]
name: json_obj [5342,5350]
===
match
---
operator: } [6333,6334]
operator: } [5153,5154]
===
match
---
name: cls [1490,1493]
name: cls [1277,1280]
===
match
---
suite [1132,1209]
suite [1055,1132]
===
match
---
atom_expr [1496,1518]
atom_expr [1283,1305]
===
match
---
name: json_obj [3369,3377]
name: json_obj [3815,3823]
===
match
---
comparison [2842,2863]
comparison [3711,3732]
===
match
---
operator: = [8814,8815]
operator: = [7146,7147]
===
match
---
decorated [8479,8953]
decorated [6811,7285]
===
match
---
trailer [2107,2121]
trailer [1894,1908]
===
match
---
name: serialize_value [1159,1174]
name: serialize_value [1082,1097]
===
match
---
simple_stmt [811,837]
simple_stmt [795,821]
===
match
---
string: "False" [6326,6333]
string: "False" [5146,5153]
===
match
---
trailer [8784,8791]
trailer [7116,7123]
===
match
---
simple_stmt [838,852]
simple_stmt [822,836]
===
match
---
simple_stmt [8023,8047]
simple_stmt [6138,6162]
===
match
---
assert_stmt [5625,5653]
assert_stmt [3310,3338]
===
match
---
string: "" [1666,1668]
string: "" [1453,1455]
===
match
---
parameters [1766,1772]
parameters [1553,1559]
===
match
---
atom [6291,6334]
atom [5111,5154]
===
match
---
expr_stmt [8055,8076]
expr_stmt [6170,6191]
===
match
---
name: serialize_value [2245,2260]
name: serialize_value [2032,2047]
===
match
---
string: "core" [6918,6924]
string: "core" [4305,4311]
===
match
---
atom_expr [1577,1604]
atom_expr [1364,1391]
===
match
---
name: result [8411,8417]
name: result [6743,6749]
===
match
---
simple_stmt [1490,1519]
simple_stmt [1277,1306]
===
match
---
return_stmt [7485,7515]
return_stmt [5558,5588]
===
match
---
name: models [934,940]
name: models [889,895]
===
match
---
trailer [8882,8895]
trailer [7214,7227]
===
match
---
simple_stmt [6633,6662]
simple_stmt [3111,3140]
===
match
---
operator: = [8844,8845]
operator: = [7176,7177]
===
match
---
simple_stmt [4307,4342]
simple_stmt [4660,4695]
===
match
---
trailer [3192,3198]
trailer [3670,3676]
===
match
---
trailer [7643,7645]
trailer [5716,5718]
===
match
---
string: "True" [6951,6957]
string: "True" [4338,4344]
===
match
---
testlist_comp [6472,6502]
testlist_comp [4807,4837]
===
match
---
string: "value" [8699,8706]
string: "value" [7031,7038]
===
match
---
name: instance [8874,8882]
name: instance [7206,7214]
===
match
---
file_input [785,8953]
file_input [785,7285]
===
match
---
trailer [8745,8747]
trailer [7077,7079]
===
match
---
string: "False" [7338,7345]
string: "False" [5402,5409]
===
match
---
atom_expr [8776,8793]
atom_expr [7108,7125]
===
match
---
name: json_obj [3767,3775]
name: json_obj [4533,4541]
===
match
---
string: "enable_xcom_pickling" [6301,6323]
string: "enable_xcom_pickling" [5121,5143]
===
match
---
argument [8693,8706]
argument [7025,7038]
===
match
---
operator: = [2158,2159]
operator: = [1945,1946]
===
insert-node
---
classdef [1134,7285]
to
file_input [785,8953]
at 11
===
insert-node
---
suite [1149,7285]
to
classdef [1134,7285]
at 1
===
move-tree
---
decorated [1367,1623]
    decorator [1367,1443]
        operator: @ [1367,1368]
        name: conf_vars [1368,1377]
        atom [1378,1441]
            operator: { [1378,1379]
            dictorsetmaker [1379,1440]
                atom [1379,1403]
                    testlist_comp [1380,1402]
                        string: "core" [1380,1386]
                        operator: , [1386,1387]
                        string: "xcom_backend" [1388,1402]
                string: "tests.models.test_xcom.CustomXCom" [1405,1440]
            operator: } [1440,1441]
    funcdef [1447,1623]
        name: test_resolve_xcom_class [1451,1474]
        parameters [1474,1480]
            param [1475,1479]
                name: self [1475,1479]
        suite [1481,1623]
            simple_stmt [1490,1519]
                expr_stmt [1490,1518]
                    name: cls [1490,1493]
                    operator: = [1494,1495]
                    atom_expr [1496,1518]
                        name: resolve_xcom_backend [1496,1516]
                        trailer [1516,1518]
            simple_stmt [1527,1562]
                assert_stmt [1527,1561]
                    atom_expr [1534,1561]
                        name: issubclass [1534,1544]
                        trailer [1544,1561]
                            arglist [1545,1560]
                                name: cls [1545,1548]
                                operator: , [1548,1549]
                                name: CustomXCom [1550,1560]
            simple_stmt [1570,1623]
                assert_stmt [1570,1622]
                    comparison [1577,1622]
                        atom_expr [1577,1604]
                            name: cls [1577,1580]
                            trailer [1580,1582]
                            trailer [1582,1598]
                                name: serialize_value [1583,1598]
                            trailer [1598,1604]
                        operator: == [1605,1607]
                        string: "custom_value" [1608,1622]
to
suite [1149,7285]
at 0
===
move-tree
---
decorated [1628,1904]
    decorator [1628,1714]
        operator: @ [1628,1629]
        name: conf_vars [1629,1638]
        atom [1639,1712]
            operator: { [1639,1640]
            dictorsetmaker [1640,1711]
                atom [1640,1664]
                    testlist_comp [1641,1663]
                        string: "core" [1641,1647]
                        operator: , [1647,1648]
                        string: "xcom_backend" [1649,1663]
                string: "" [1666,1668]
                operator: , [1668,1669]
                atom [1670,1702]
                    testlist_comp [1671,1701]
                        string: "core" [1671,1677]
                        operator: , [1677,1678]
                        string: "enable_xcom_pickling" [1679,1701]
                string: "False" [1704,1711]
            operator: } [1711,1712]
    funcdef [1718,1904]
        name: test_resolve_xcom_class_fallback_to_basexcom [1722,1766]
        parameters [1766,1772]
            param [1767,1771]
                name: self [1767,1771]
        suite [1773,1904]
            simple_stmt [1782,1811]
                expr_stmt [1782,1810]
                    name: cls [1782,1785]
                    operator: = [1786,1787]
                    atom_expr [1788,1810]
                        name: resolve_xcom_backend [1788,1808]
                        trailer [1808,1810]
            simple_stmt [1819,1852]
                assert_stmt [1819,1851]
                    atom_expr [1826,1851]
                        name: issubclass [1826,1836]
                        trailer [1836,1851]
                            arglist [1837,1850]
                                name: cls [1837,1840]
                                operator: , [1840,1841]
                                name: BaseXCom [1842,1850]
            simple_stmt [1860,1904]
                assert_stmt [1860,1903]
                    comparison [1867,1903]
                        atom_expr [1867,1893]
                            name: cls [1867,1870]
                            trailer [1870,1872]
                            trailer [1872,1888]
                                name: serialize_value [1873,1888]
                            trailer [1888,1893]
                                atom [1889,1892]
                                    number: 1 [1890,1891]
                        operator: == [1894,1896]
                        string: b"[1]" [1897,1903]
to
suite [1149,7285]
at 1
===
move-tree
---
decorated [1909,2276]
    decorators [1909,2025]
        decorator [1909,1965]
            operator: @ [1909,1910]
            name: conf_vars [1910,1919]
            atom [1920,1963]
                operator: { [1920,1921]
                dictorsetmaker [1921,1962]
                    atom [1921,1953]
                        testlist_comp [1922,1952]
                            string: "core" [1922,1928]
                            operator: , [1928,1929]
                            string: "enable_xcom_pickling" [1930,1952]
                    string: "False" [1955,1962]
                operator: } [1962,1963]
        decorator [1969,2025]
            operator: @ [1969,1970]
            name: conf_vars [1970,1979]
            atom [1980,2023]
                operator: { [1980,1981]
                dictorsetmaker [1981,2022]
                    atom [1981,2005]
                        testlist_comp [1982,2004]
                            string: "core" [1982,1988]
                            operator: , [1988,1989]
                            string: "xcom_backend" [1990,2004]
                    string: "to be removed" [2007,2022]
                operator: } [2022,2023]
    funcdef [2029,2276]
        name: test_resolve_xcom_class_fallback_to_basexcom_no_config [2033,2087]
        parameters [2087,2093]
            param [2088,2092]
                name: self [2088,2092]
        suite [2094,2276]
            simple_stmt [2103,2146]
                atom_expr [2103,2145]
                    name: conf [2103,2107]
                    trailer [2107,2121]
                        name: remove_option [2108,2121]
                    trailer [2121,2145]
                        arglist [2122,2144]
                            string: "core" [2122,2128]
                            operator: , [2128,2129]
                            string: "xcom_backend" [2130,2144]
            simple_stmt [2154,2183]
                expr_stmt [2154,2182]
                    name: cls [2154,2157]
                    operator: = [2158,2159]
                    atom_expr [2160,2182]
                        name: resolve_xcom_backend [2160,2180]
                        trailer [2180,2182]
            simple_stmt [2191,2224]
                assert_stmt [2191,2223]
                    atom_expr [2198,2223]
                        name: issubclass [2198,2208]
                        trailer [2208,2223]
                            arglist [2209,2222]
                                name: cls [2209,2212]
                                operator: , [2212,2213]
                                name: BaseXCom [2214,2222]
            simple_stmt [2232,2276]
                assert_stmt [2232,2275]
                    comparison [2239,2275]
                        atom_expr [2239,2265]
                            name: cls [2239,2242]
                            trailer [2242,2244]
                            trailer [2244,2260]
                                name: serialize_value [2245,2260]
                            trailer [2260,2265]
                                atom [2261,2264]
                                    number: 1 [2262,2263]
                        operator: == [2266,2268]
                        string: b"[1]" [2269,2275]
to
suite [1149,7285]
at 2
===
insert-node
---
decorated [2068,3733]
to
suite [1149,7285]
at 3
===
insert-node
---
funcdef [3738,4542]
to
suite [1149,7285]
at 4
===
insert-node
---
funcdef [4547,5351]
to
suite [1149,7285]
at 5
===
move-tree
---
decorated [7292,7785]
    decorator [7292,7348]
        operator: @ [7292,7293]
        name: conf_vars [7293,7302]
        atom [7303,7346]
            operator: { [7303,7304]
            dictorsetmaker [7304,7345]
                atom [7304,7336]
                    testlist_comp [7305,7335]
                        string: "core" [7305,7311]
                        operator: , [7311,7312]
                        string: "xcom_enable_pickling" [7313,7335]
                string: "False" [7338,7345]
            operator: } [7345,7346]
    funcdef [7352,7785]
        name: test_xcom_disable_pickle_type_fail_on_non_json [7356,7402]
        parameters [7402,7408]
            param [7403,7407]
                name: self [7403,7407]
        suite [7409,7785]
            classdef [7418,7516]
                name: PickleRce [7424,7433]
                suite [7434,7516]
                    funcdef [7447,7516]
                        name: __reduce__ [7451,7461]
                        parameters [7461,7467]
                            param [7462,7466]
                                name: self [7462,7466]
                        suite [7468,7516]
                            simple_stmt [7485,7516]
                                return_stmt [7485,7515]
                                    testlist [7492,7515]
                                        atom_expr [7492,7501]
                                            name: os [7492,7494]
                                            trailer [7494,7501]
                                                name: system [7495,7501]
                                        operator: , [7501,7502]
                                        atom [7503,7515]
                                            testlist_comp [7504,7514]
                                                string: "ls -alt" [7504,7513]
                                                operator: , [7513,7514]
            with_stmt [7525,7785]
                atom_expr [7530,7554]
                    name: pytest [7530,7536]
                    trailer [7536,7543]
                        name: raises [7537,7543]
                    trailer [7543,7554]
                        name: TypeError [7544,7553]
                suite [7555,7785]
                    simple_stmt [7568,7785]
                        atom_expr [7568,7784]
                            name: XCom [7568,7572]
                            trailer [7572,7576]
                                name: set [7573,7576]
                            trailer [7576,7784]
                                arglist [7594,7770]
                                    argument [7594,7610]
                                        name: key [7594,7597]
                                        operator: = [7597,7598]
                                        string: "xcom_test3" [7598,7610]
                                    operator: , [7610,7611]
                                    argument [7628,7645]
                                        name: value [7628,7633]
                                        operator: = [7633,7634]
                                        atom_expr [7634,7645]
                                            name: PickleRce [7634,7643]
                                            trailer [7643,7645]
                                    operator: , [7645,7646]
                                    argument [7663,7681]
                                        name: dag_id [7663,7669]
                                        operator: = [7669,7670]
                                        string: "test_dag3" [7670,7681]
                                    operator: , [7681,7682]
                                    argument [7699,7719]
                                        name: task_id [7699,7706]
                                        operator: = [7706,7707]
                                        string: "test_task3" [7707,7719]
                                    operator: , [7719,7720]
                                    argument [7737,7769]
                                        name: execution_date [7737,7751]
                                        operator: = [7751,7752]
                                        atom_expr [7752,7769]
                                            name: timezone [7752,7760]
                                            trailer [7760,7767]
                                                name: utcnow [7761,7767]
                                            trailer [7767,7769]
                                    operator: , [7769,7770]
to
suite [1149,7285]
at 6
===
insert-node
---
decorated [5896,6806]
to
suite [1149,7285]
at 7
===
move-tree
---
decorated [8479,8953]
    decorator [8479,8541]
        operator: @ [8479,8480]
        dotted_name [8480,8490]
            name: mock [8480,8484]
            name: patch [8485,8490]
        string: "airflow.models.xcom.XCom.orm_deserialize_value" [8491,8539]
    funcdef [8545,8953]
        name: test_xcom_init_on_load_uses_orm_deserialize_value [8549,8598]
        parameters [8598,8626]
            param [8599,8604]
                name: self [8599,8603]
                operator: , [8603,8604]
            param [8605,8625]
                name: mock_orm_deserialize [8605,8625]
        suite [8627,8953]
            simple_stmt [8637,8865]
                expr_stmt [8637,8864]
                    name: instance [8637,8645]
                    operator: = [8646,8647]
                    atom_expr [8648,8864]
                        name: BaseXCom [8648,8656]
                        trailer [8656,8864]
                            arglist [8670,8854]
                                argument [8670,8679]
                                    name: key [8670,8673]
                                    operator: = [8673,8674]
                                    string: "key" [8674,8679]
                                operator: , [8679,8680]
                                argument [8693,8706]
                                    name: value [8693,8698]
                                    operator: = [8698,8699]
                                    string: "value" [8699,8706]
                                operator: , [8706,8707]
                                argument [8720,8747]
                                    name: timestamp [8720,8729]
                                    operator: = [8729,8730]
                                    atom_expr [8730,8747]
                                        name: timezone [8730,8738]
                                        trailer [8738,8745]
                                            name: utcnow [8739,8745]
                                        trailer [8745,8747]
                                operator: , [8747,8748]
                                argument [8761,8793]
                                    name: execution_date [8761,8775]
                                    operator: = [8775,8776]
                                    atom_expr [8776,8793]
                                        name: timezone [8776,8784]
                                        trailer [8784,8791]
                                            name: utcnow [8785,8791]
                                        trailer [8791,8793]
                                operator: , [8793,8794]
                                argument [8807,8824]
                                    name: task_id [8807,8814]
                                    operator: = [8814,8815]
                                    string: "task_id" [8815,8824]
                                operator: , [8824,8825]
                                argument [8838,8853]
                                    name: dag_id [8838,8844]
                                    operator: = [8844,8845]
                                    string: "dag_id" [8845,8853]
                                operator: , [8853,8854]
            simple_stmt [8874,8898]
                atom_expr [8874,8897]
                    name: instance [8874,8882]
                    trailer [8882,8895]
                        name: init_on_load [8883,8895]
                    trailer [8895,8897]
            simple_stmt [8906,8953]
                atom_expr [8906,8952]
                    name: mock_orm_deserialize [8906,8926]
                    trailer [8926,8950]
                        name: assert_called_once_with [8927,8950]
                    trailer [8950,8952]
to
suite [1149,7285]
at 8
===
insert-node
---
funcdef [2290,3733]
to
decorated [2068,3733]
at 1
===
insert-node
---
suite [3806,4542]
to
funcdef [3738,4542]
at 2
===
insert-node
---
suite [4615,5351]
to
funcdef [4547,5351]
at 2
===
move-tree
---
decorator [7790,7845]
    operator: @ [7790,7791]
    name: conf_vars [7791,7800]
    atom [7801,7843]
        operator: { [7801,7802]
        dictorsetmaker [7802,7842]
            atom [7802,7834]
                testlist_comp [7803,7833]
                    string: "core" [7803,7809]
                    operator: , [7809,7810]
                    string: "xcom_enable_pickling" [7811,7833]
            string: "True" [7836,7842]
        operator: } [7842,7843]
to
decorated [5896,6806]
at 0
===
insert-node
---
funcdef [5955,6806]
to
decorated [5896,6806]
at 1
===
insert-node
---
suite [2358,3733]
to
funcdef [2290,3733]
at 2
===
move-tree
---
simple_stmt [3369,3397]
    expr_stmt [3369,3396]
        name: json_obj [3369,3377]
        operator: = [3378,3379]
        atom [3380,3396]
            operator: { [3380,3381]
            dictorsetmaker [3381,3395]
                string: "key" [3381,3386]
                string: "value" [3388,3395]
            operator: } [3395,3396]
to
suite [3806,4542]
at 0
===
move-tree
---
simple_stmt [3405,3440]
    expr_stmt [3405,3439]
        name: execution_date [3405,3419]
        operator: = [3420,3421]
        atom_expr [3422,3439]
            name: timezone [3422,3430]
            trailer [3430,3437]
                name: utcnow [3431,3437]
            trailer [3437,3439]
to
suite [3806,4542]
at 1
===
move-tree
---
simple_stmt [6189,6208]
    expr_stmt [6189,6207]
        name: key [6189,6192]
        operator: = [6193,6194]
        string: "xcom_test3" [6195,6207]
to
suite [3806,4542]
at 2
===
move-tree
---
simple_stmt [6216,6236]
    expr_stmt [6216,6235]
        name: dag_id [6216,6222]
        operator: = [6223,6224]
        string: "test_dag" [6225,6235]
to
suite [3806,4542]
at 3
===
move-tree
---
simple_stmt [6244,6267]
    expr_stmt [6244,6266]
        name: task_id [6244,6251]
        operator: = [6252,6253]
        string: "test_task3" [6254,6266]
to
suite [3806,4542]
at 4
===
insert-node
---
with_stmt [3981,4279]
to
suite [3806,4542]
at 5
===
insert-node
---
with_stmt [4288,4504]
to
suite [3806,4542]
at 6
===
move-tree
---
simple_stmt [3747,3776]
    assert_stmt [3747,3775]
        comparison [3754,3775]
            name: ret_value [3754,3763]
            operator: == [3764,3766]
            name: json_obj [3767,3775]
to
suite [3806,4542]
at 7
===
move-tree
---
simple_stmt [4271,4299]
    expr_stmt [4271,4298]
        name: json_obj [4271,4279]
        operator: = [4280,4281]
        atom [4282,4298]
            operator: { [4282,4283]
            dictorsetmaker [4283,4297]
                string: "key" [4283,4288]
                string: "value" [4290,4297]
            operator: } [4297,4298]
to
suite [4615,5351]
at 0
===
move-tree
---
simple_stmt [4307,4342]
    expr_stmt [4307,4341]
        name: execution_date [4307,4321]
        operator: = [4322,4323]
        atom_expr [4324,4341]
            name: timezone [4324,4332]
            trailer [4332,4339]
                name: utcnow [4333,4339]
            trailer [4339,4341]
to
suite [4615,5351]
at 1
===
move-tree
---
simple_stmt [5327,5346]
    expr_stmt [5327,5345]
        name: key [5327,5330]
        operator: = [5331,5332]
        string: "xcom_test3" [5333,5345]
to
suite [4615,5351]
at 2
===
move-tree
---
simple_stmt [5354,5374]
    expr_stmt [5354,5373]
        name: dag_id [5354,5360]
        operator: = [5361,5362]
        string: "test_dag" [5363,5373]
to
suite [4615,5351]
at 3
===
move-tree
---
simple_stmt [5382,5405]
    expr_stmt [5382,5404]
        name: task_id [5382,5389]
        operator: = [5390,5391]
        string: "test_task3" [5392,5404]
to
suite [4615,5351]
at 4
===
insert-node
---
with_stmt [4790,5087]
to
suite [4615,5351]
at 5
===
insert-node
---
with_stmt [5096,5313]
to
suite [4615,5351]
at 6
===
move-tree
---
simple_stmt [4716,4745]
    assert_stmt [4716,4744]
        comparison [4723,4744]
            name: ret_value [4723,4732]
            operator: == [4733,4735]
            name: json_obj [4736,4744]
to
suite [4615,5351]
at 7
===
insert-node
---
suite [5993,6806]
to
funcdef [5955,6806]
at 2
===
move-tree
---
simple_stmt [2390,2418]
    expr_stmt [2390,2417]
        name: json_obj [2390,2398]
        operator: = [2399,2400]
        atom [2401,2417]
            operator: { [2401,2402]
            dictorsetmaker [2402,2416]
                string: "key" [2402,2407]
                string: "value" [2409,2416]
            operator: } [2416,2417]
to
suite [2358,3733]
at 0
===
move-tree
---
simple_stmt [2426,2461]
    expr_stmt [2426,2460]
        name: execution_date [2426,2440]
        operator: = [2441,2442]
        atom_expr [2443,2460]
            name: timezone [2443,2451]
            trailer [2451,2458]
                name: utcnow [2452,2458]
            trailer [2458,2460]
to
suite [2358,3733]
at 1
===
move-tree
---
simple_stmt [2469,2488]
    expr_stmt [2469,2487]
        name: key [2469,2472]
        operator: = [2473,2474]
        string: "xcom_test1" [2475,2487]
to
suite [2358,3733]
at 2
===
move-tree
---
simple_stmt [2496,2517]
    expr_stmt [2496,2516]
        name: dag_id [2496,2502]
        operator: = [2503,2504]
        string: "test_dag1" [2505,2516]
to
suite [2358,3733]
at 3
===
move-tree
---
simple_stmt [2525,2548]
    expr_stmt [2525,2547]
        name: task_id [2525,2532]
        operator: = [2533,2534]
        string: "test_task1" [2535,2547]
to
suite [2358,3733]
at 4
===
insert-node
---
with_stmt [2534,3733]
to
suite [2358,3733]
at 5
===
move-tree
---
atom_expr [7084,7138]
    name: conf_vars [7084,7093]
    trailer [7093,7138]
        atom [7094,7137]
            operator: { [7094,7095]
            dictorsetmaker [7095,7136]
                atom [7095,7127]
                    testlist_comp [7096,7126]
                        string: "core" [7096,7102]
                        operator: , [7102,7103]
                        string: "enable_xcom_pickling" [7104,7126]
                string: "False" [7129,7136]
            operator: } [7136,7137]
to
with_stmt [3981,4279]
at 0
===
move-tree
---
atom_expr [6906,6959]
    name: conf_vars [6906,6915]
    trailer [6915,6959]
        atom [6916,6958]
            operator: { [6916,6917]
            dictorsetmaker [6917,6957]
                atom [6917,6949]
                    testlist_comp [6918,6948]
                        string: "core" [6918,6924]
                        operator: , [6924,6925]
                        string: "enable_xcom_pickling" [6926,6948]
                string: "True" [6951,6957]
            operator: } [6957,6958]
to
with_stmt [4288,4504]
at 0
===
move-tree
---
atom_expr [6460,6513]
    name: conf_vars [6460,6469]
    trailer [6469,6513]
        atom [6470,6512]
            operator: { [6470,6471]
            dictorsetmaker [6471,6511]
                atom [6471,6503]
                    testlist_comp [6472,6502]
                        string: "core" [6472,6478]
                        operator: , [6478,6479]
                        string: "enable_xcom_pickling" [6480,6502]
                string: "True" [6505,6511]
            operator: } [6511,6512]
to
with_stmt [4790,5087]
at 0
===
move-tree
---
atom_expr [6281,6335]
    name: conf_vars [6281,6290]
    trailer [6290,6335]
        atom [6291,6334]
            operator: { [6291,6292]
            dictorsetmaker [6292,6333]
                atom [6292,6324]
                    testlist_comp [6293,6323]
                        string: "core" [6293,6299]
                        operator: , [6299,6300]
                        string: "enable_xcom_pickling" [6301,6323]
                string: "False" [6326,6333]
            operator: } [6333,6334]
to
with_stmt [5096,5313]
at 0
===
insert-tree
---
param [5473,5480]
    name: session [5473,5480]
to
parameters [7402,7408]
at 1
===
move-tree
---
simple_stmt [7887,7915]
    expr_stmt [7887,7914]
        name: json_obj [7887,7895]
        operator: = [7896,7897]
        atom [7898,7914]
            operator: { [7898,7899]
            dictorsetmaker [7899,7913]
                string: "key" [7899,7904]
                string: "value" [7906,7913]
            operator: } [7913,7914]
to
suite [5993,6806]
at 0
===
move-tree
---
simple_stmt [7923,7958]
    expr_stmt [7923,7957]
        name: execution_date [7923,7937]
        operator: = [7938,7939]
        atom_expr [7940,7957]
            name: timezone [7940,7948]
            trailer [7948,7955]
                name: utcnow [7949,7955]
            trailer [7955,7957]
to
suite [5993,6806]
at 1
===
move-tree
---
simple_stmt [7966,7985]
    expr_stmt [7966,7984]
        name: key [7966,7969]
        operator: = [7970,7971]
        string: "xcom_test4" [7972,7984]
to
suite [5993,6806]
at 2
===
move-tree
---
simple_stmt [7993,8015]
    expr_stmt [7993,8014]
        name: dag_id1 [7993,8000]
        operator: = [8001,8002]
        string: "test_dag4" [8003,8014]
to
suite [5993,6806]
at 3
===
move-tree
---
simple_stmt [8023,8047]
    expr_stmt [8023,8046]
        name: task_id1 [8023,8031]
        operator: = [8032,8033]
        string: "test_task4" [8034,8046]
to
suite [5993,6806]
at 4
===
move-tree
---
simple_stmt [8055,8077]
    expr_stmt [8055,8076]
        name: dag_id2 [8055,8062]
        operator: = [8063,8064]
        string: "test_dag5" [8065,8076]
to
suite [5993,6806]
at 5
===
move-tree
---
simple_stmt [8085,8109]
    expr_stmt [8085,8108]
        name: task_id2 [8085,8093]
        operator: = [8094,8095]
        string: "test_task5" [8096,8108]
to
suite [5993,6806]
at 6
===
move-tree
---
for_stmt [8407,8474]
    name: result [8411,8417]
    name: results [8421,8428]
    suite [8429,8474]
        simple_stmt [8442,8474]
            assert_stmt [8442,8473]
                comparison [8449,8473]
                    atom_expr [8449,8461]
                        name: result [8449,8455]
                        trailer [8455,8461]
                            name: value [8456,8461]
                    operator: == [8462,8464]
                    name: json_obj [8465,8473]
to
suite [5993,6806]
at 10
===
insert-node
---
atom_expr [2539,2611]
to
with_stmt [2534,3733]
at 0
===
insert-node
---
suite [2612,3733]
to
with_stmt [2534,3733]
at 1
===
insert-node
---
operator: , [5471,5472]
to
param [7403,7407]
at 1
===
insert-node
---
trailer [2548,2611]
to
atom_expr [2539,2611]
at 1
===
move-tree
---
simple_stmt [6633,6662]
    assert_stmt [6633,6661]
        comparison [6640,6661]
            name: ret_value [6640,6649]
            operator: == [6650,6652]
            name: json_obj [6653,6661]
to
suite [2612,3733]
at 2
===
move-tree
---
simple_stmt [5625,5654]
    assert_stmt [5625,5653]
        comparison [5632,5653]
            name: ret_value [5632,5641]
            operator: == [5642,5644]
            name: json_obj [5645,5653]
to
suite [2612,3733]
at 4
===
move-tree
---
simple_stmt [2910,3209]
    expr_stmt [2910,3208]
        name: ret_value [2910,2919]
        operator: = [2920,2921]
        atom [2922,3208]
            atom_expr [2936,3198]
                name: session [2936,2943]
                trailer [2943,2949]
                    name: query [2944,2949]
                trailer [2949,2955]
                    name: XCom [2950,2954]
                trailer [2968,2975]
                    name: filter [2969,2975]
                trailer [2975,3158]
                    arglist [2993,3144]
                        comparison [2993,3008]
                            atom_expr [2993,3001]
                                name: XCom [2993,2997]
                                trailer [2997,3001]
                                    name: key [2998,3001]
                            operator: == [3002,3004]
                            name: key [3005,3008]
                        operator: , [3008,3009]
                        comparison [3026,3047]
                            atom_expr [3026,3037]
                                name: XCom [3026,3030]
                                trailer [3030,3037]
                                    name: dag_id [3031,3037]
                            operator: == [3038,3040]
                            name: dag_id [3041,3047]
                        operator: , [3047,3048]
                        comparison [3065,3088]
                            atom_expr [3065,3077]
                                name: XCom [3065,3069]
                                trailer [3069,3077]
                                    name: task_id [3070,3077]
                            operator: == [3078,3080]
                            name: task_id [3081,3088]
                        operator: , [3088,3089]
                        comparison [3106,3143]
                            atom_expr [3106,3125]
                                name: XCom [3106,3110]
                                trailer [3110,3125]
                                    name: execution_date [3111,3125]
                            operator: == [3126,3128]
                            name: execution_date [3129,3143]
                        operator: , [3143,3144]
                trailer [3171,3177]
                    name: first [3172,3177]
                trailer [3177,3179]
                trailer [3192,3198]
                    name: value [3193,3198]
to
suite [2612,3733]
at 5
===
move-tree
---
simple_stmt [2835,2864]
    assert_stmt [2835,2863]
        comparison [2842,2863]
            name: ret_value [2842,2851]
            operator: == [2852,2854]
            name: json_obj [2855,2863]
to
suite [2612,3733]
at 6
===
move-tree
---
atom [2292,2335]
    operator: { [2292,2293]
    dictorsetmaker [2293,2334]
        atom [2293,2325]
            testlist_comp [2294,2324]
                string: "core" [2294,2300]
                operator: , [2300,2301]
                string: "enable_xcom_pickling" [2302,2324]
        string: "False" [2327,2334]
    operator: } [2334,2335]
to
trailer [2548,2611]
at 0
===
insert-tree
---
atom_expr [2584,2609]
    name: str [2584,2587]
    trailer [2587,2609]
        name: enable_xcom_pickling [2588,2608]
to
dictorsetmaker [2293,2334]
at 1
===
insert-tree
---
argument [5860,5875]
    name: session [5860,5867]
    operator: = [5867,5868]
    name: session [5868,5875]
to
arglist [7594,7770]
at 10
===
insert-node
---
operator: , [5875,5876]
to
arglist [7594,7770]
at 11
===
delete-tree
---
simple_stmt [795,811]
    import_name [795,810]
        name: unittest [802,810]
===
delete-tree
---
simple_stmt [853,882]
    import_from [853,881]
        name: airflow [858,865]
        name: settings [873,881]
===
delete-tree
---
simple_stmt [1025,1057]
    import_from [1025,1056]
        dotted_name [1030,1046]
            name: tests [1030,1035]
            name: test_utils [1036,1046]
        name: db [1054,1056]
===
delete-node
---
string: "False" [2327,2334]
===
===
delete-node
---
decorator [2281,2337]
===
===
delete-node
---
suite [2381,3247]
===
===
delete-node
---
funcdef [2341,3247]
===
===
delete-node
---
decorated [2281,3247]
===
===
delete-node
---
suite [3360,4159]
===
===
delete-node
---
funcdef [3312,4159]
===
===
delete-node
---
decorated [3252,4159]
===
===
delete-node
---
suite [4262,5128]
===
===
delete-node
---
funcdef [4223,5128]
===
===
delete-node
---
decorated [4164,5128]
===
===
delete-node
---
suite [5239,6037]
===
===
delete-node
---
funcdef [5192,6037]
===
===
delete-node
---
decorated [5133,6037]
===
===
delete-node
---
with_stmt [6276,6446]
===
===
delete-node
---
with_stmt [6455,6624]
===
===
delete-node
---
suite [6101,6662]
===
===
delete-node
---
funcdef [6042,6662]
===
===
delete-node
---
with_stmt [6901,7070]
===
===
delete-node
---
with_stmt [7079,7249]
===
===
delete-node
---
suite [6726,7287]
===
===
delete-node
---
funcdef [6667,7287]
===
===
delete-node
---
suite [7878,8474]
===
===
delete-node
---
funcdef [7849,8474]
===
===
delete-node
---
decorated [7790,8474]
===
===
delete-node
---
suite [1245,8953]
===
===
delete-node
---
classdef [1211,8953]
===
