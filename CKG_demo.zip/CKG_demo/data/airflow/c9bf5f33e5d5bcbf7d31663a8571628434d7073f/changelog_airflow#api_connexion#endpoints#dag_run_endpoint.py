===
match
---
trailer [7284,7289]
trailer [7300,7305]
===
match
---
atom_expr [9634,9647]
atom_expr [9741,9754]
===
match
---
dotted_name [1705,1724]
dotted_name [1721,1740]
===
match
---
name: requires_access [2263,2278]
name: requires_access [2279,2294]
===
match
---
name: session [9580,9587]
name: session [9687,9694]
===
match
---
name: query [6756,6761]
name: query [6772,6777]
===
match
---
operator: } [9098,9099]
operator: } [9190,9191]
===
match
---
fstring_expr [9049,9057]
fstring_expr [9102,9110]
===
match
---
simple_stmt [10256,10304]
simple_stmt [10363,10411]
===
match
---
arglist [8396,8782]
arglist [8431,8817]
===
match
---
trailer [8152,8159]
trailer [8187,8194]
===
match
---
name: execution_date_lte [4467,4485]
name: execution_date_lte [4483,4501]
===
match
---
name: order_by [4554,4562]
name: order_by [4570,4578]
===
match
---
operator: , [5077,5078]
operator: , [5093,5094]
===
match
---
name: err [9970,9973]
name: err [10077,10080]
===
match
---
operator: , [4694,4695]
operator: , [4710,4711]
===
match
---
comparison [9609,9632]
comparison [9716,9739]
===
match
---
simple_stmt [7946,7989]
simple_stmt [7962,8024]
===
match
---
simple_stmt [8986,9127]
simple_stmt [9021,9234]
===
match
---
operator: , [7324,7325]
operator: , [7340,7341]
===
match
---
trailer [9892,9897]
trailer [9999,10004]
===
match
---
dotted_name [7359,7383]
dotted_name [7375,7399]
===
match
---
operator: @ [9237,9238]
operator: @ [9344,9345]
===
match
---
suite [6814,6881]
suite [6830,6897]
===
match
---
atom_expr [7623,7688]
atom_expr [7639,7704]
===
match
---
simple_stmt [10012,10054]
simple_stmt [10119,10161]
===
match
---
atom_expr [10018,10053]
atom_expr [10125,10160]
===
match
---
trailer [2104,2111]
trailer [2120,2127]
===
match
---
operator: , [6248,6249]
operator: , [6264,6265]
===
match
---
name: start_date_lte [3442,3456]
name: start_date_lte [3458,3472]
===
match
---
operator: , [4236,4237]
operator: , [4252,4253]
===
match
---
name: session [9484,9491]
name: session [9591,9598]
===
match
---
name: messages [6505,6513]
name: messages [6521,6529]
===
match
---
name: dag_id [8774,8780]
name: dag_id [8809,8815]
===
match
---
operator: } [9781,9782]
operator: } [9888,9889]
===
match
---
simple_stmt [9839,9899]
simple_stmt [9946,10006]
===
match
---
param [3417,3437]
param [3433,3453]
===
match
---
trailer [7088,7106]
trailer [7104,7122]
===
match
---
name: requires_access [6093,6108]
name: requires_access [6109,6124]
===
match
---
string: "conf" [8667,8673]
string: "conf" [8702,8708]
===
match
---
fstring_expr [9774,9782]
fstring_expr [9881,9889]
===
match
---
arglist [5127,5176]
arglist [5143,5192]
===
match
---
operator: = [7718,7719]
operator: = [7734,7735]
===
match
---
name: query [6831,6836]
name: query [6847,6852]
===
match
---
name: run_id [9641,9647]
name: run_id [9748,9754]
===
match
---
name: RESOURCE_DAG [1828,1840]
name: RESOURCE_DAG [1844,1856]
===
match
---
param [1966,1977]
param [1982,1993]
===
match
---
param [3571,3583]
param [3587,3599]
===
match
---
operator: <= [5853,5855]
operator: <= [5869,5871]
===
match
---
operator: { [9085,9086]
operator: { [9158,9159]
===
match
---
atom_expr [9885,9897]
atom_expr [9992,10004]
===
match
---
name: Optional [804,812]
name: Optional [804,812]
===
match
---
suite [2119,2225]
suite [2135,2241]
===
match
---
dictorsetmaker [3061,3344]
dictorsetmaker [3077,3360]
===
match
---
name: run_id [8163,8169]
name: run_id [8198,8204]
===
match
---
name: dag_run [8351,8358]
name: dag_run [8386,8393]
===
match
---
name: dag_run [10292,10299]
name: dag_run [10399,10406]
===
match
---
operator: , [2986,2987]
operator: , [3002,3003]
===
match
---
import_as_names [1033,1095]
import_as_names [1049,1111]
===
match
---
atom [6189,6248]
atom [6205,6264]
===
match
---
name: start_date [5616,5626]
name: start_date [5632,5642]
===
match
---
trailer [9290,9306]
trailer [9397,9413]
===
match
---
name: query [3959,3964]
name: query [3975,3980]
===
match
---
operator: } [7770,7771]
operator: } [7786,7787]
===
match
---
trailer [7827,7832]
trailer [7843,7848]
===
match
---
name: dag_id [9183,9189]
name: dag_id [9290,9296]
===
match
---
operator: , [5424,5425]
operator: , [5440,5441]
===
match
---
fstring_expr [2173,2181]
fstring_expr [2189,2197]
===
match
---
name: execution_date_gte [5755,5773]
name: execution_date_gte [5771,5789]
===
match
---
operator: , [7454,7455]
operator: , [7470,7471]
===
match
---
argument [8731,8781]
argument [8766,8816]
===
match
---
name: utils [1625,1630]
name: utils [1641,1646]
===
match
---
trailer [3901,3922]
trailer [3917,3938]
===
match
---
name: run_id [7993,7999]
name: run_id [8028,8034]
===
match
---
operator: = [8617,8618]
operator: = [8652,8653]
===
match
---
operator: = [2149,2150]
operator: = [2165,2166]
===
match
---
trailer [7476,7494]
trailer [7492,7510]
===
match
---
operator: == [8193,8195]
operator: == [8228,8230]
===
match
---
operator: == [2114,2116]
operator: == [2130,2132]
===
match
---
operator: , [4401,4402]
operator: , [4417,4418]
===
match
---
trailer [5954,5963]
trailer [5970,5979]
===
match
---
argument [8648,8674]
argument [8683,8709]
===
match
---
name: run_id [8440,8446]
name: run_id [8475,8481]
===
match
---
fstring [9731,9783]
fstring [9838,9890]
===
match
---
decorator [2253,2428]
decorator [2269,2444]
===
match
---
name: dump [7285,7289]
name: dump [7301,7305]
===
match
---
simple_stmt [5265,5295]
simple_stmt [5281,5311]
===
match
---
name: state [1681,1686]
name: state [1697,1702]
===
match
---
name: session [2481,2488]
name: session [2497,2504]
===
match
---
simple_stmt [10093,10164]
simple_stmt [10200,10271]
===
match
---
atom_expr [8146,8159]
atom_expr [8181,8194]
===
match
---
name: security [1746,1754]
name: security [1762,1770]
===
match
---
operator: = [6633,6634]
operator: = [6649,6650]
===
match
---
name: appbuilder [3805,3815]
name: appbuilder [3821,3831]
===
match
---
simple_stmt [6886,7248]
simple_stmt [6902,7264]
===
match
---
trailer [5233,5241]
trailer [5249,5257]
===
match
---
name: query [4617,4622]
name: query [4633,4638]
===
match
---
trailer [6776,6804]
trailer [6792,6820]
===
match
---
raise_stmt [8986,9126]
raise_stmt [9021,9233]
===
match
---
name: execution_date_gte [4676,4694]
name: execution_date_gte [4692,4710]
===
match
---
name: execution_date_lte [5782,5800]
name: execution_date_lte [5798,5816]
===
match
---
name: set [6726,6729]
name: set [6742,6745]
===
match
---
simple_stmt [9132,9235]
simple_stmt [9239,9342]
===
match
---
fstring_start: f" [2150,2152]
fstring_start: f" [2166,2168]
===
match
---
operator: , [5279,5280]
operator: , [5295,5296]
===
match
---
arglist [7307,7353]
arglist [7323,7369]
===
match
---
atom_expr [6154,6178]
atom_expr [6170,6194]
===
match
---
simple_stmt [4800,4830]
simple_stmt [4816,4846]
===
match
---
suite [2490,2850]
suite [2506,2866]
===
match
---
string: 'start_date_gte' [3061,3077]
string: 'start_date_gte' [3077,3093]
===
match
---
name: filter [5602,5608]
name: filter [5618,5624]
===
match
---
operator: , [7038,7039]
operator: , [7054,7055]
===
match
---
trailer [2558,2612]
trailer [2574,2628]
===
match
---
atom_expr [8303,8338]
atom_expr [8338,8373]
===
match
---
string: """Trigger a DAG.""" [7591,7611]
string: """Trigger a DAG.""" [7607,7627]
===
match
---
operator: , [9402,9403]
operator: , [9509,9510]
===
match
---
operator: , [8594,8595]
operator: , [8629,8630]
===
match
---
atom_expr [8105,8118]
atom_expr [8140,8153]
===
match
---
name: apply_sorting [1267,1280]
name: apply_sorting [1283,1296]
===
match
---
simple_stmt [2229,2251]
simple_stmt [2245,2267]
===
match
---
dotted_name [1532,1546]
dotted_name [1548,1562]
===
match
---
trailer [7680,7686]
trailer [7696,7702]
===
match
---
atom_expr [4579,4777]
atom_expr [4595,4793]
===
match
---
simple_stmt [5709,5775]
simple_stmt [5725,5791]
===
match
---
name: start_date_gte [4732,4746]
name: start_date_gte [4748,4762]
===
match
---
name: run_id [9209,9215]
name: run_id [9316,9322]
===
match
---
atom [1786,1841]
atom [1802,1857]
===
match
---
name: format_datetime [1295,1310]
name: format_datetime [1311,1326]
===
match
---
name: detail [6490,6496]
name: detail [6506,6512]
===
match
---
if_stmt [8248,8922]
if_stmt [8283,8957]
===
match
---
name: order_by [5134,5142]
name: order_by [5150,5158]
===
match
---
operator: == [8961,8963]
operator: == [8996,8998]
===
match
---
operator: = [6701,6702]
operator: = [6717,6718]
===
match
---
name: run_type [8396,8404]
name: run_type [8431,8439]
===
match
---
not_test [8251,8270]
not_test [8286,8305]
===
match
---
operator: , [3017,3018]
operator: , [3033,3034]
===
match
---
name: set [6703,6706]
name: set [6719,6722]
===
match
---
string: "run_id" [8012,8020]
string: "run_id" [8047,8055]
===
match
---
trailer [6593,6614]
trailer [6609,6630]
===
match
---
name: session [3662,3669]
name: session [3678,3685]
===
match
---
simple_stmt [4002,4262]
simple_stmt [4018,4278]
===
match
---
name: DagRun [6777,6783]
name: DagRun [6793,6799]
===
match
---
atom_expr [3923,3929]
atom_expr [3939,3945]
===
match
---
arglist [10122,10162]
arglist [10229,10269]
===
match
---
expr_stmt [6756,6804]
expr_stmt [6772,6820]
===
match
---
operator: , [1293,1294]
operator: , [1309,1310]
===
match
---
comparison [5948,5979]
comparison [5964,5995]
===
match
---
atom_expr [8171,8192]
atom_expr [8206,8227]
===
match
---
atom_expr [8361,8796]
atom_expr [8396,8831]
===
match
---
name: current_app [8303,8314]
name: current_app [8338,8349]
===
match
---
not_test [7619,7688]
not_test [7635,7704]
===
match
---
expr_stmt [10012,10053]
expr_stmt [10119,10160]
===
match
---
name: dagrun_schema [10315,10328]
name: dagrun_schema [10422,10435]
===
match
---
name: dagrun_instance [8930,8945]
name: dagrun_instance [8965,8980]
===
match
---
name: ACTION_CAN_READ [2307,2322]
name: ACTION_CAN_READ [2323,2338]
===
match
---
trailer [8084,8091]
trailer [8119,8126]
===
match
---
name: filter [6770,6776]
name: filter [6786,6792]
===
match
---
atom_expr [2959,2986]
atom_expr [2975,3002]
===
match
---
atom_expr [7704,7784]
atom_expr [7720,7800]
===
match
---
name: filter [5941,5947]
name: filter [5957,5963]
===
match
---
param [4396,4402]
param [4412,4418]
===
match
---
simple_stmt [1330,1527]
simple_stmt [1346,1543]
===
match
---
operator: , [1310,1311]
operator: , [1326,1327]
===
match
---
name: dag_id [9454,9460]
name: dag_id [9561,9567]
===
match
---
dotted_name [9238,9262]
dotted_name [9345,9369]
===
match
---
atom_expr [7654,7669]
atom_expr [7670,7685]
===
match
---
operator: , [3343,3344]
operator: , [3359,3360]
===
match
---
simple_stmt [2659,2811]
simple_stmt [2675,2827]
===
match
---
string: 'order_by' [7223,7233]
string: 'order_by' [7239,7249]
===
match
---
testlist_star_expr [4002,4024]
testlist_star_expr [4018,4040]
===
match
---
suite [3942,3997]
suite [3958,4013]
===
match
---
param [5335,5341]
param [5351,5357]
===
match
---
simple_stmt [6756,6805]
simple_stmt [6772,6821]
===
match
---
try_stmt [8280,8922]
try_stmt [8315,8957]
===
match
---
name: get_dag [8323,8330]
name: get_dag [8358,8365]
===
match
---
name: dag [10122,10125]
name: dag [10229,10232]
===
match
---
trailer [5729,5774]
trailer [5745,5790]
===
match
---
operator: , [1280,1281]
operator: , [1296,1297]
===
match
---
name: end_date_lte [5356,5368]
name: end_date_lte [5372,5384]
===
match
---
decorated [6083,7356]
decorated [6099,7372]
===
match
---
trailer [8235,8237]
trailer [8270,8272]
===
match
---
argument [8692,8713]
argument [8727,8748]
===
match
---
name: json [7841,7845]
name: json [7857,7861]
===
match
---
name: run_id [8447,8453]
name: run_id [8482,8488]
===
match
---
name: mark_tasks [1009,1019]
name: mark_tasks [1025,1035]
===
match
---
operator: , [5408,5409]
operator: , [5424,5425]
===
match
---
name: readable_dag_ids [6862,6878]
name: readable_dag_ids [6878,6894]
===
match
---
trailer [3922,3930]
trailer [3938,3946]
===
match
---
name: data [6952,6956]
name: data [6968,6972]
===
match
---
atom_expr [4274,4368]
atom_expr [4290,4384]
===
match
---
name: set_dagrun_state_form_schema [1495,1523]
name: set_dagrun_state_form_schema [1511,1539]
===
match
---
name: security [1584,1592]
name: security [1600,1608]
===
match
---
operator: , [8781,8782]
operator: , [8816,8817]
===
match
---
name: NotFound [7704,7712]
name: NotFound [7720,7728]
===
match
---
name: dagrun_schema [1445,1458]
name: dagrun_schema [1461,1474]
===
match
---
name: dag_run_id [2469,2479]
name: dag_run_id [2485,2495]
===
match
---
string: 'end_date_lte' [3282,3296]
string: 'end_date_lte' [3298,3312]
===
match
---
simple_stmt [4571,4778]
simple_stmt [4587,4794]
===
match
---
name: dagrun_schema [7814,7827]
name: dagrun_schema [7830,7843]
===
match
---
trailer [2029,2035]
trailer [2045,2051]
===
match
---
name: state [9981,9986]
name: state [10088,10093]
===
match
---
name: order_by [7205,7213]
name: order_by [7221,7229]
===
match
---
atom_expr [8618,8630]
atom_expr [8653,8665]
===
match
---
name: _apply_date_filters_to_query [5301,5329]
name: _apply_date_filters_to_query [5317,5345]
===
match
---
name: dag_run [8835,8842]
name: dag_run [8870,8877]
===
match
---
funcdef [1939,2251]
funcdef [1955,2267]
===
match
---
fstring_string: DAGRun with DAG ID: ' [2152,2173]
fstring_string: DAGRun with DAG ID: ' [2168,2189]
===
match
---
name: DagRun [9609,9615]
name: DagRun [9716,9722]
===
match
---
string: "dag_run_id" [4995,5007]
string: "dag_run_id" [5011,5023]
===
match
---
trailer [5247,5254]
trailer [5263,5270]
===
match
---
name: _fetch_dag_runs [6912,6927]
name: _fetch_dag_runs [6928,6943]
===
match
---
name: offset [3571,3577]
name: offset [3587,3593]
===
match
---
string: "run_id" [4873,4881]
string: "run_id" [4889,4897]
===
match
---
operator: { [7763,7764]
operator: { [7779,7780]
===
match
---
trailer [2306,2322]
trailer [2322,2338]
===
match
---
name: request [9885,9892]
name: request [9992,9999]
===
match
---
atom_expr [6707,6722]
atom_expr [6723,6738]
===
match
---
import_from [1612,1661]
import_from [1628,1677]
===
match
---
name: RESOURCE_DAG [2935,2947]
name: RESOURCE_DAG [2951,2963]
===
match
---
name: detail [2143,2149]
name: detail [2159,2165]
===
match
---
simple_stmt [8889,8922]
simple_stmt [8924,8957]
===
match
---
atom_expr [5935,5980]
atom_expr [5951,5996]
===
match
---
name: ValueError [8859,8869]
name: ValueError [8894,8904]
===
match
---
name: dag_id [9626,9632]
name: dag_id [9733,9739]
===
match
---
annassign [9549,9682]
annassign [9656,9789]
===
match
---
operator: = [3537,3538]
operator: = [3553,3554]
===
match
---
atom_expr [6501,6513]
atom_expr [6517,6529]
===
match
---
operator: = [8580,8581]
operator: = [8615,8616]
===
match
---
trailer [7152,7166]
trailer [7168,7182]
===
match
---
operator: { [9208,9209]
operator: { [9315,9316]
===
match
---
operator: = [9987,9988]
operator: = [10094,10095]
===
match
---
if_stmt [5779,5876]
if_stmt [5795,5892]
===
match
---
name: common [989,995]
name: common [1005,1011]
===
match
---
trailer [10222,10237]
trailer [10329,10344]
===
match
---
string: "execution_date_gte" [7017,7037]
string: "execution_date_gte" [7033,7053]
===
match
---
name: airflow [1617,1624]
name: airflow [1633,1640]
===
match
---
name: dagruns_batch_form_schema [6393,6418]
name: dagruns_batch_form_schema [6409,6434]
===
match
---
except_clause [6434,6463]
except_clause [6450,6479]
===
match
---
fstring_expr [9744,9756]
fstring_expr [9851,9863]
===
match
---
name: appbuilder [3888,3898]
name: appbuilder [3904,3914]
===
match
---
name: dag_bag [8752,8759]
name: dag_bag [8787,8794]
===
match
---
atom_expr [9989,10007]
atom_expr [10096,10114]
===
match
---
expr_stmt [5211,5260]
expr_stmt [5227,5276]
===
match
---
trailer [7306,7354]
trailer [7322,7370]
===
match
---
import_from [924,971]
import_from [940,987]
===
match
---
raise_stmt [8889,8921]
raise_stmt [8924,8956]
===
match
---
string: "dag_run_id" [4859,4871]
string: "dag_run_id" [4875,4887]
===
match
---
trailer [2590,2597]
trailer [2606,2613]
===
match
---
name: _fetch_dag_runs [4027,4042]
name: _fetch_dag_runs [4043,4058]
===
match
---
operator: -> [9493,9495]
operator: -> [9600,9602]
===
match
---
argument [8471,8498]
argument [8506,8533]
===
match
---
param [5370,5389]
param [5386,5405]
===
match
---
simple_stmt [7591,7612]
simple_stmt [7607,7628]
===
match
---
name: query [3849,3854]
name: query [3865,3870]
===
match
---
operator: = [8446,8447]
operator: = [8481,8482]
===
match
---
atom_expr [5717,5774]
atom_expr [5733,5790]
===
match
---
trailer [9806,9821]
trailer [9913,9928]
===
match
---
name: request [848,855]
name: request [864,871]
===
match
---
dictorsetmaker [4859,4881]
dictorsetmaker [4875,4897]
===
match
---
name: _vendor [937,944]
name: _vendor [953,960]
===
match
---
operator: = [6762,6763]
operator: = [6778,6779]
===
match
---
atom_expr [9279,9306]
atom_expr [9386,9413]
===
match
---
name: DagRun [9560,9566]
name: DagRun [9667,9673]
===
match
---
raise_stmt [9942,9975]
raise_stmt [10049,10082]
===
match
---
operator: = [3855,3856]
operator: = [3871,3872]
===
match
---
fstring_expr [7763,7771]
fstring_expr [7779,7787]
===
match
---
trailer [5526,5537]
trailer [5542,5553]
===
match
---
name: DagModel [7654,7662]
name: DagModel [7670,7678]
===
match
---
atom_expr [6703,6723]
atom_expr [6719,6739]
===
match
---
trailer [7712,7784]
trailer [7728,7800]
===
match
---
name: data [6707,6711]
name: data [6723,6727]
===
match
---
trailer [8666,8674]
trailer [8701,8709]
===
match
---
trailer [6489,6515]
trailer [6505,6531]
===
match
---
name: err [6501,6504]
name: err [6517,6520]
===
match
---
param [5390,5409]
param [5406,5425]
===
match
---
simple_stmt [6312,6339]
simple_stmt [6328,6355]
===
match
---
expr_stmt [7946,7988]
expr_stmt [7962,8023]
===
match
---
atom_expr [8740,8781]
atom_expr [8775,8816]
===
match
---
operator: , [2467,2468]
operator: , [2483,2484]
===
match
---
atom_expr [6479,6515]
atom_expr [6495,6531]
===
match
---
import_from [1527,1570]
import_from [1543,1586]
===
match
---
expr_stmt [7993,8021]
expr_stmt [8028,8056]
===
match
---
atom_expr [8142,8209]
atom_expr [8177,8244]
===
match
---
name: end_date [6038,6046]
name: end_date [6054,6062]
===
match
---
name: dag_id [7673,7679]
name: dag_id [7689,7695]
===
match
---
return_stmt [2815,2849]
return_stmt [2831,2865]
===
match
---
comparison [2076,2103]
comparison [2092,2119]
===
match
---
operator: , [1211,1212]
operator: , [1227,1228]
===
match
---
decorated [7358,9235]
decorated [7374,9342]
===
match
---
atom_expr [6190,6217]
atom_expr [6206,6233]
===
match
---
name: update_dag_run_state [9433,9453]
name: update_dag_run_state [9540,9560]
===
match
---
argument [7326,7353]
argument [7342,7369]
===
match
---
name: start_date_gte [3417,3431]
name: start_date_gte [3433,3447]
===
match
---
atom_expr [9551,9567]
atom_expr [9658,9674]
===
match
---
trailer [9615,9622]
trailer [9722,9729]
===
match
---
trailer [5254,5258]
trailer [5270,5274]
===
match
---
name: dag_run_id [1966,1976]
name: dag_run_id [1982,1992]
===
match
---
name: dagrun_collection_schema [7260,7284]
name: dagrun_collection_schema [7276,7300]
===
match
---
decorators [9237,9429]
decorators [9344,9536]
===
match
---
suite [6001,6064]
suite [6017,6080]
===
match
---
operator: , [3542,3543]
operator: , [3558,3559]
===
match
---
try_stmt [9826,9976]
try_stmt [9933,10083]
===
match
---
string: "end_date_gte" [6957,6971]
string: "end_date_gte" [6973,6987]
===
match
---
operator: { [4858,4859]
operator: { [4874,4875]
===
match
---
fstring_expr [2199,2211]
fstring_expr [2215,2227]
===
match
---
name: run_id [2591,2597]
name: run_id [2607,2613]
===
match
---
atom_expr [6393,6429]
atom_expr [6409,6445]
===
match
---
name: filter [6837,6843]
name: filter [6853,6859]
===
match
---
atom_expr [2665,2810]
atom_expr [2681,2826]
===
match
---
arglist [4617,4771]
arglist [4633,4787]
===
match
---
atom_expr [4816,4829]
atom_expr [4832,4845]
===
match
---
operator: = [8359,8360]
operator: = [8394,8395]
===
match
---
trailer [9601,9608]
trailer [9708,9715]
===
match
---
operator: == [3986,3988]
operator: == [4002,4004]
===
match
---
name: dagrun_instance [8255,8270]
name: dagrun_instance [8290,8305]
===
match
---
trailer [2673,2810]
trailer [2689,2826]
===
match
---
trailer [7840,7845]
trailer [7856,7861]
===
match
---
trailer [2537,2543]
trailer [2553,2559]
===
match
---
name: end_date_gte [5342,5354]
name: end_date_gte [5358,5370]
===
match
---
simple_stmt [5105,5178]
simple_stmt [5121,5194]
===
match
---
if_stmt [2019,2225]
if_stmt [2035,2241]
===
match
---
operator: , [1409,1410]
operator: , [1425,1426]
===
match
---
atom_expr [9373,9401]
atom_expr [9480,9508]
===
match
---
name: BadRequest [8895,8905]
name: BadRequest [8930,8940]
===
match
---
name: Optional [9551,9559]
name: Optional [9658,9666]
===
match
---
trailer [6614,6622]
trailer [6630,6638]
===
match
---
operator: = [6829,6830]
operator: = [6845,6846]
===
match
---
operator: = [5594,5595]
operator: = [5610,5611]
===
match
---
name: data [7048,7052]
name: data [7064,7068]
===
match
---
trailer [3675,3683]
trailer [3691,3699]
===
match
---
name: provide_session [9413,9428]
name: provide_session [9520,9535]
===
match
---
name: query [5588,5593]
name: query [5604,5609]
===
match
---
simple_stmt [4845,4883]
simple_stmt [4861,4899]
===
match
---
trailer [2400,2417]
trailer [2416,2433]
===
match
---
trailer [6850,6857]
trailer [6866,6873]
===
match
---
simple_stmt [8297,8339]
simple_stmt [8332,8374]
===
match
---
arglist [2687,2800]
arglist [2703,2816]
===
match
---
name: start_date_gte [4167,4181]
name: start_date_gte [4183,4197]
===
match
---
dotted_name [2254,2278]
dotted_name [2270,2294]
===
match
---
operator: , [9333,9334]
operator: , [9440,9441]
===
match
---
operator: = [3560,3561]
operator: = [3576,3577]
===
match
---
name: state [10061,10066]
name: state [10168,10173]
===
match
---
comparison [5831,5874]
comparison [5847,5890]
===
match
---
name: dag_id [3979,3985]
name: dag_id [3995,4001]
===
match
---
name: total_entries [7326,7339]
name: total_entries [7342,7355]
===
match
---
name: dag_run_id [9651,9661]
name: dag_run_id [9758,9768]
===
match
---
trailer [8623,8630]
trailer [8658,8665]
===
match
---
name: count [4822,4827]
name: count [4838,4843]
===
match
---
name: current_app [8740,8751]
name: current_app [8775,8786]
===
match
---
param [4407,4420]
param [4423,4436]
===
match
---
trailer [3869,3932]
trailer [3885,3948]
===
match
---
atom_expr [6018,6063]
atom_expr [6034,6079]
===
match
---
suite [5490,5557]
suite [5506,5573]
===
match
---
name: end_date_lte [4654,4666]
name: end_date_lte [4670,4682]
===
match
---
atom_expr [10215,10237]
atom_expr [10322,10344]
===
match
---
param [9467,9483]
param [9574,9590]
===
match
---
name: start_date_gte [4491,4505]
name: start_date_gte [4507,4521]
===
match
---
fstring_string: ' not found [2787,2798]
fstring_string: ' not found [2803,2814]
===
match
---
atom [4910,5100]
atom [4926,5116]
===
match
---
argument [8516,8594]
argument [8551,8629]
===
match
---
name: execution_date_lte [5390,5408]
name: execution_date_lte [5406,5424]
===
match
---
name: get_readable_dag_ids [3902,3922]
name: get_readable_dag_ids [3918,3938]
===
match
---
param [3548,3566]
param [3564,3582]
===
match
---
name: str [7931,7934]
name: str [7947,7950]
===
match
---
operator: , [1458,1459]
operator: , [1474,1475]
===
match
---
name: ve [8873,8875]
name: ve [8908,8910]
===
match
---
suite [5700,5775]
suite [5716,5791]
===
match
---
trailer [6783,6790]
trailer [6799,6806]
===
match
---
operator: = [2528,2529]
operator: = [2544,2545]
===
match
---
argument [6490,6514]
argument [6506,6530]
===
match
---
atom_expr [7400,7427]
atom_expr [7416,7443]
===
match
---
name: session [7847,7854]
name: session [7863,7870]
===
match
---
name: start_date_gte [5410,5424]
name: start_date_gte [5426,5440]
===
match
---
name: permissions [2894,2905]
name: permissions [2910,2921]
===
match
---
testlist_comp [2893,3018]
testlist_comp [2909,3034]
===
match
---
comparison [9634,9661]
comparison [9741,9768]
===
match
---
trailer [6616,6621]
trailer [6632,6637]
===
match
---
atom_expr [6125,6152]
atom_expr [6141,6168]
===
match
---
funcdef [9429,10343]
funcdef [9536,10450]
===
match
---
atom_expr [1816,1840]
atom_expr [1832,1856]
===
match
---
name: DagRun [5831,5837]
name: DagRun [5847,5853]
===
match
---
name: RESOURCE_DAG [9320,9332]
name: RESOURCE_DAG [9427,9439]
===
match
---
atom_expr [8816,8843]
atom_expr [8851,8878]
===
match
---
atom_expr [6497,6514]
atom_expr [6513,6530]
===
match
---
operator: , [4985,4986]
operator: , [5001,5002]
===
match
---
name: BadRequest [9948,9958]
name: BadRequest [10055,10065]
===
match
---
name: query [2538,2543]
name: query [2554,2559]
===
match
---
expr_stmt [4002,4261]
expr_stmt [4018,4277]
===
match
---
name: offset [4230,4236]
name: offset [4246,4252]
===
match
---
operator: , [7233,7234]
operator: , [7249,7250]
===
match
---
trailer [8067,8075]
trailer [8102,8110]
===
match
---
name: DagRun [8068,8074]
name: DagRun [8103,8109]
===
match
---
param [3525,3543]
param [3541,3559]
===
match
---
return_stmt [5265,5294]
return_stmt [5281,5310]
===
match
---
operator: @ [1922,1923]
operator: @ [1938,1939]
===
match
---
trailer [4320,4367]
trailer [4336,4383]
===
match
---
operator: = [9025,9026]
operator: = [9060,9061]
===
match
---
param [9454,9466]
param [9561,9573]
===
match
---
testlist_comp [6124,6249]
testlist_comp [6140,6265]
===
match
---
operator: = [6391,6392]
operator: = [6407,6408]
===
match
---
expr_stmt [3951,3996]
expr_stmt [3967,4012]
===
match
---
trailer [8011,8021]
trailer [8046,8056]
===
match
---
name: logical_date [7946,7958]
name: logical_date [7962,7974]
===
match
---
name: execution_date [8178,8192]
name: execution_date [8213,8227]
===
match
---
name: NoContent [2236,2245]
name: NoContent [2252,2261]
===
match
---
operator: , [2921,2922]
operator: , [2937,2938]
===
match
---
atom_expr [3972,3985]
atom_expr [3988,4001]
===
match
---
expr_stmt [9715,9783]
expr_stmt [9822,9890]
===
match
---
trailer [6861,6879]
trailer [6877,6895]
===
match
---
name: session [8054,8061]
name: session [8089,8096]
===
match
---
trailer [8829,8834]
trailer [8864,8869]
===
match
---
simple_stmt [1571,1612]
simple_stmt [1587,1628]
===
match
---
name: ACTION_CAN_READ [2372,2387]
name: ACTION_CAN_READ [2388,2403]
===
match
---
fstring_string: ' and DAGRun logical date: ' [9057,9085]
fstring_string: DAGRun logical date: ' [9136,9158]
===
match
---
name: filter [2552,2558]
name: filter [2568,2574]
===
match
---
operator: = [3593,3594]
operator: = [3609,3610]
===
match
---
trailer [4042,4261]
trailer [4058,4277]
===
match
---
trailer [7411,7427]
trailer [7427,7443]
===
match
---
operator: , [3094,3095]
operator: , [3110,3111]
===
match
---
expr_stmt [6010,6063]
expr_stmt [6026,6079]
===
match
---
name: DAGRunCollection [1393,1409]
name: DAGRunCollection [1409,1425]
===
match
---
name: DagRun [5730,5736]
name: DagRun [5746,5752]
===
match
---
trailer [5947,5980]
trailer [5963,5996]
===
match
---
atom_expr [9308,9332]
atom_expr [9415,9439]
===
match
---
name: dag_ids [6693,6700]
name: dag_ids [6709,6716]
===
match
---
operator: , [8128,8129]
operator: , [8163,8164]
===
match
---
simple_stmt [8809,8844]
simple_stmt [8844,8879]
===
match
---
atom_expr [7260,7355]
atom_expr [7276,7371]
===
match
---
operator: , [3490,3491]
operator: , [3506,3507]
===
match
---
param [4511,4526]
param [4527,4542]
===
match
---
operator: , [5368,5369]
operator: , [5384,5385]
===
match
---
expr_stmt [7802,7863]
expr_stmt [7818,7879]
===
match
---
name: dag_run [5211,5218]
name: dag_run [5227,5234]
===
match
---
trailer [6504,6513]
trailer [6520,6529]
===
match
---
name: dag [10210,10213]
name: dag [10317,10320]
===
match
---
name: execution_date [5838,5852]
name: execution_date [5854,5868]
===
match
---
name: permissions [1816,1827]
name: permissions [1832,1843]
===
match
---
name: dag_run [5272,5279]
name: dag_run [5288,5295]
===
match
---
name: execution_date [5737,5751]
name: execution_date [5753,5767]
===
match
---
suite [7689,7785]
suite [7705,7801]
===
match
---
name: dag_run [10334,10341]
name: dag_run [10441,10448]
===
match
---
operator: = [3456,3457]
operator: = [3472,3473]
===
match
---
operator: , [6179,6180]
operator: , [6195,6196]
===
match
---
trailer [7970,7988]
trailer [8004,8022]
===
match
---
simple_stmt [4267,4369]
simple_stmt [4283,4385]
===
match
---
operator: , [4536,4537]
operator: , [4552,4553]
===
match
---
operator: @ [2428,2429]
operator: @ [2444,2445]
===
match
---
name: api_connexion [1111,1124]
name: api_connexion [1127,1140]
===
match
---
name: ACTION_CAN_READ [6202,6217]
name: ACTION_CAN_READ [6218,6233]
===
match
---
string: "conf" [5087,5093]
string: "conf" [5103,5109]
===
match
---
operator: = [3431,3432]
operator: = [3447,3448]
===
match
---
return_stmt [6068,6080]
return_stmt [6084,6096]
===
match
---
operator: } [4881,4882]
operator: } [4897,4898]
===
match
---
name: dag [8530,8533]
name: dag [8565,8568]
===
match
---
expr_stmt [8297,8338]
expr_stmt [8332,8373]
===
match
---
name: session [1978,1985]
name: session [1994,2001]
===
match
---
name: query [6075,6080]
name: query [6091,6096]
===
match
---
dotted_name [1746,1770]
dotted_name [1762,1786]
===
match
---
simple_stmt [5499,5557]
simple_stmt [5515,5573]
===
match
---
trailer [2612,2624]
trailer [2628,2640]
===
match
---
param [4443,4462]
param [4459,4478]
===
match
---
operator: , [2074,2075]
operator: , [2090,2091]
===
match
---
atom_expr [2584,2597]
atom_expr [2600,2613]
===
match
---
name: dag_id [8112,8118]
name: dag_id [8147,8153]
===
match
---
dotted_name [2853,2877]
dotted_name [2869,2893]
===
match
---
trailer [7052,7074]
trailer [7068,7090]
===
match
---
name: NotFound [1213,1221]
name: NotFound [1229,1237]
===
match
---
dotted_name [1617,1638]
dotted_name [1633,1654]
===
match
---
name: dag_id [1958,1964]
name: dag_id [1974,1980]
===
match
---
operator: , [5049,5050]
operator: , [5065,5066]
===
match
---
except_clause [9903,9932]
except_clause [10010,10039]
===
match
---
if_stmt [7616,7785]
if_stmt [7632,7801]
===
match
---
trailer [9674,9676]
trailer [9781,9783]
===
match
---
operator: , [2418,2419]
operator: , [2434,2435]
===
match
---
name: filter [6024,6030]
name: filter [6040,6046]
===
match
---
name: dag_run_id [9467,9477]
name: dag_run_id [9574,9584]
===
match
---
operator: == [8119,8121]
operator: == [8154,8156]
===
match
---
simple_stmt [814,856]
simple_stmt [830,872]
===
match
---
operator: = [7742,7743]
operator: = [7758,7759]
===
match
---
operator: , [8713,8714]
operator: , [8748,8749]
===
match
---
comparison [2022,2118]
comparison [2038,2134]
===
match
---
atom_expr [9966,9974]
atom_expr [10073,10081]
===
match
---
name: dag_id [8331,8337]
name: dag_id [8366,8372]
===
match
---
trailer [9559,9567]
trailer [9666,9674]
===
match
---
name: sm [3899,3901]
name: sm [3915,3917]
===
match
---
if_stmt [5678,5775]
if_stmt [5694,5791]
===
match
---
trailer [2565,2572]
trailer [2581,2588]
===
match
---
operator: == [2598,2600]
operator: == [2614,2616]
===
match
---
name: DagRun [2584,2590]
name: DagRun [2600,2606]
===
match
---
expr_stmt [4887,5100]
expr_stmt [4903,5116]
===
match
---
atom_expr [7214,7240]
atom_expr [7230,7256]
===
match
---
dotted_name [1667,1686]
dotted_name [1683,1702]
===
match
---
name: end_date_lte [4425,4437]
name: end_date_lte [4441,4453]
===
match
---
param [4531,4537]
param [4547,4553]
===
match
---
raise_stmt [9132,9234]
raise_stmt [9239,9341]
===
match
---
simple_stmt [1141,1222]
simple_stmt [1157,1238]
===
match
---
dotted_name [929,954]
dotted_name [945,970]
===
match
---
simple_stmt [9542,9683]
simple_stmt [9649,9790]
===
match
---
operator: , [3411,3412]
operator: , [3427,3428]
===
match
---
parameters [3386,3620]
parameters [3402,3636]
===
match
---
operator: = [8301,8302]
operator: = [8336,8337]
===
match
---
operator: , [9371,9372]
operator: , [9478,9479]
===
match
---
simple_stmt [3951,3997]
simple_stmt [3967,4013]
===
match
---
atom_expr [5596,5645]
atom_expr [5612,5661]
===
match
---
suite [9933,9976]
suite [10040,10083]
===
match
---
trailer [3964,3971]
trailer [3980,3987]
===
match
---
name: get [7219,7222]
name: get [7235,7238]
===
match
---
name: airflow [977,984]
name: airflow [993,1000]
===
match
---
name: typing [790,796]
name: typing [790,796]
===
match
---
name: NotFound [2665,2673]
name: NotFound [2681,2689]
===
match
---
name: session [2022,2029]
name: session [2038,2045]
===
match
---
testlist_comp [1852,1911]
testlist_comp [1868,1927]
===
match
---
if_stmt [5985,6064]
if_stmt [6001,6080]
===
match
---
name: security [2853,2861]
name: security [2869,2877]
===
match
---
name: provide_session [2429,2444]
name: provide_session [2445,2460]
===
match
---
operator: = [9729,9730]
operator: = [9836,9837]
===
match
---
expr_stmt [3654,3683]
expr_stmt [3670,3699]
===
match
---
name: execution_date [10223,10237]
name: execution_date [10330,10344]
===
match
---
comparison [8146,8169]
comparison [8181,8204]
===
match
---
name: dag_id [3877,3883]
name: dag_id [3893,3899]
===
match
---
param [2461,2468]
param [2477,2484]
===
match
---
trailer [5940,5947]
trailer [5956,5963]
===
match
---
name: title [7713,7718]
name: title [7729,7734]
===
match
---
arglist [6937,7241]
arglist [6953,7257]
===
match
---
operator: } [3349,3350]
operator: } [3365,3366]
===
match
---
atom_expr [5831,5852]
atom_expr [5847,5868]
===
match
---
operator: , [2479,2480]
operator: , [2495,2496]
===
match
---
comparison [8171,8208]
comparison [8206,8243]
===
match
---
name: ACTION_CAN_EDIT [7412,7427]
name: ACTION_CAN_EDIT [7428,7443]
===
match
---
simple_stmt [1700,1743]
simple_stmt [1716,1759]
===
match
---
param [3588,3599]
param [3604,3615]
===
match
---
name: error_message [9715,9728]
name: error_message [9822,9835]
===
match
---
operator: , [4505,4506]
operator: , [4521,4522]
===
match
---
trailer [8145,8209]
trailer [8180,8244]
===
match
---
trailer [9640,9647]
trailer [9747,9754]
===
match
---
trailer [7222,7240]
trailer [7238,7256]
===
match
---
fstring [2726,2799]
fstring [2742,2815]
===
match
---
name: dag_runs [6886,6894]
name: dag_runs [6902,6910]
===
match
---
string: """Get a DAG Run.""" [2495,2515]
string: """Get a DAG Run.""" [2511,2531]
===
match
---
string: 'id' [3613,3617]
string: 'id' [3629,3633]
===
match
---
fstring_string: ' already exists [9216,9232]
fstring_string: ' already exists [9323,9339]
===
match
---
name: check_limit [1282,1293]
name: check_limit [1298,1309]
===
match
---
name: get_readable_dag_ids [6594,6614]
name: get_readable_dag_ids [6610,6630]
===
match
---
simple_stmt [7253,7356]
simple_stmt [7269,7372]
===
match
---
name: query [8062,8067]
name: query [8097,8102]
===
match
---
name: current_app [3818,3829]
name: current_app [3834,3845]
===
match
---
trailer [8091,8220]
trailer [8126,8255]
===
match
---
operator: = [7930,7931]
operator: = [7946,7947]
===
match
---
testlist_comp [2360,2417]
testlist_comp [2376,2433]
===
match
---
name: start_date_lte [4511,4525]
name: start_date_lte [4527,4541]
===
match
---
trailer [2835,2840]
trailer [2851,2856]
===
match
---
atom_expr [6350,6368]
atom_expr [6366,6384]
===
match
---
operator: = [4856,4857]
operator: = [4872,4873]
===
match
---
name: dict [9496,9500]
name: dict [9603,9607]
===
match
---
suite [7898,7941]
suite [7914,7957]
===
match
---
atom_expr [5221,5260]
atom_expr [5237,5276]
===
match
---
name: requires_access [1755,1770]
name: requires_access [1771,1786]
===
match
---
trailer [2111,2113]
trailer [2127,2129]
===
match
---
trailer [5126,5177]
trailer [5142,5193]
===
match
---
trailer [8905,8921]
trailer [8940,8956]
===
match
---
fstring_string: ' and DAGRun ID: ' [9190,9208]
fstring_string: ' and DAGRun ID: ' [9297,9315]
===
match
---
trailer [7686,7688]
trailer [7702,7704]
===
match
---
trailer [9884,9898]
trailer [9991,10005]
===
match
---
expr_stmt [9839,9898]
expr_stmt [9946,10005]
===
match
---
trailer [7507,7524]
trailer [7523,7540]
===
match
---
operator: , [10213,10214]
operator: , [10320,10321]
===
match
---
trailer [6230,6247]
trailer [6246,6263]
===
match
---
param [4554,4563]
param [4570,4579]
===
match
---
name: query [9588,9593]
name: query [9695,9700]
===
match
---
dotted_name [1576,1592]
dotted_name [1592,1608]
===
match
---
expr_stmt [6386,6429]
expr_stmt [6402,6445]
===
match
---
expr_stmt [6521,6556]
expr_stmt [6537,6572]
===
match
---
fstring_end: " [2222,2223]
fstring_end: " [2238,2239]
===
match
---
trailer [5258,5260]
trailer [5274,5276]
===
match
---
operator: >= [5964,5966]
operator: >= [5980,5982]
===
match
---
simple_stmt [1222,1330]
simple_stmt [1238,1346]
===
match
---
name: limit [4531,4536]
name: limit [4547,4552]
===
match
---
name: permissions [2923,2934]
name: permissions [2939,2950]
===
match
---
name: query [5221,5226]
name: query [5237,5242]
===
match
---
name: airflow [1705,1712]
name: airflow [1721,1728]
===
match
---
suite [3796,3933]
suite [3812,3949]
===
match
---
name: end_date_gte [3525,3537]
name: end_date_gte [3541,3553]
===
match
---
trailer [7636,7646]
trailer [7652,7662]
===
match
---
name: dag_id [2174,2180]
name: dag_id [2190,2196]
===
match
---
name: query [3951,3956]
name: query [3967,3972]
===
match
---
atom [9268,9409]
atom [9375,9516]
===
match
---
fstring_string: ' and DagRun ID: ' [2181,2199]
fstring_string: ' and DagRun ID: ' [2197,2215]
===
match
---
name: filter [5513,5519]
name: filter [5529,5535]
===
match
---
expr_stmt [4845,4882]
expr_stmt [4861,4898]
===
match
---
name: get_json [6358,6366]
name: get_json [6374,6382]
===
match
---
name: query [3857,3862]
name: query [3873,3878]
===
match
---
name: airflow [929,936]
name: airflow [945,952]
===
match
---
name: order_by [3604,3612]
name: order_by [3620,3628]
===
match
---
operator: = [6016,6017]
operator: = [6032,6033]
===
match
---
name: airflow [1576,1583]
name: airflow [1592,1599]
===
match
---
atom_expr [3959,3996]
atom_expr [3975,4012]
===
match
---
name: or_ [919,922]
name: or_ [935,938]
===
match
---
operator: == [2573,2575]
operator: == [2589,2591]
===
match
---
if_stmt [5472,5557]
if_stmt [5488,5573]
===
match
---
param [7569,7576]
param [7585,7592]
===
match
---
trailer [5823,5830]
trailer [5839,5846]
===
match
---
name: one_or_none [2613,2624]
name: one_or_none [2629,2640]
===
match
---
trailer [6843,6880]
trailer [6859,6896]
===
match
---
operator: = [3577,3578]
operator: = [3593,3594]
===
match
---
operator: = [8000,8001]
operator: = [8035,8036]
===
match
---
atom_expr [6777,6803]
atom_expr [6793,6819]
===
match
---
operator: @ [7535,7536]
operator: @ [7551,7552]
===
match
---
decorator [6258,6275]
decorator [6274,6291]
===
match
---
name: DagRun [1564,1570]
name: DagRun [1580,1586]
===
match
---
atom_expr [6580,6622]
atom_expr [6596,6638]
===
match
---
decorators [2253,2445]
decorators [2269,2461]
===
match
---
operator: , [3137,3138]
operator: , [3153,3154]
===
match
---
name: dag_run [4330,4337]
name: dag_run [4346,4353]
===
match
---
operator: , [1094,1095]
operator: , [1110,1111]
===
match
---
name: filter [2044,2050]
name: filter [2060,2066]
===
match
---
operator: @ [3027,3028]
operator: @ [3043,3044]
===
match
---
comparison [2634,2649]
comparison [2650,2665]
===
match
---
simple_stmt [3805,3841]
simple_stmt [3821,3857]
===
match
---
parameters [7568,7585]
parameters [7584,7601]
===
match
---
expr_stmt [5709,5774]
expr_stmt [5725,5790]
===
match
---
atom_expr [10182,10251]
atom_expr [10289,10358]
===
match
---
name: execution_date_lte [4139,4157]
name: execution_date_lte [4155,4173]
===
match
---
name: query [5717,5722]
name: query [5733,5738]
===
match
---
trailer [10029,10037]
trailer [10136,10144]
===
match
---
trailer [8364,8378]
trailer [8399,8413]
===
match
---
testlist_comp [2894,2947]
testlist_comp [2910,2963]
===
match
---
name: end_date_lte [5988,6000]
name: end_date_lte [6004,6016]
===
match
---
operator: = [3612,3613]
operator: = [3628,3629]
===
match
---
name: ACTION_CAN_READ [6137,6152]
name: ACTION_CAN_READ [6153,6168]
===
match
---
trailer [6357,6366]
trailer [6373,6382]
===
match
---
decorator [1745,1922]
decorator [1761,1938]
===
match
---
name: end_date_lte [3548,3560]
name: end_date_lte [3564,3576]
===
match
---
name: airflow [1227,1234]
name: airflow [1243,1250]
===
match
---
name: DagRunType [8405,8415]
name: DagRunType [8440,8450]
===
match
---
simple_stmt [10308,10343]
simple_stmt [10415,10450]
===
match
---
name: permissions [7465,7476]
name: permissions [7481,7492]
===
match
---
argument [9152,9233]
argument [9259,9340]
===
match
---
testlist_comp [1787,1840]
testlist_comp [1803,1856]
===
match
---
name: dag [8361,8364]
name: dag [8396,8399]
===
match
---
name: to_replace [4845,4855]
name: to_replace [4861,4871]
===
match
---
testlist [5272,5294]
testlist [5288,5310]
===
match
---
parameters [5329,5442]
parameters [5345,5458]
===
match
---
name: query [5499,5504]
name: query [5515,5520]
===
match
---
operator: = [4025,4026]
operator: = [4041,4042]
===
match
---
param [3496,3520]
param [3512,3536]
===
match
---
name: dag_id [3405,3411]
name: dag_id [3421,3427]
===
match
---
operator: , [4254,4255]
operator: , [4270,4271]
===
match
---
trailer [8543,8570]
trailer [8578,8605]
===
match
---
trailer [5736,5751]
trailer [5752,5767]
===
match
---
parameters [4390,4565]
parameters [4406,4581]
===
match
---
trailer [9662,9674]
trailer [9769,9781]
===
match
---
trailer [7646,7653]
trailer [7662,7669]
===
match
---
name: filter [8085,8091]
name: filter [8120,8126]
===
match
---
trailer [10328,10333]
trailer [10435,10440]
===
match
---
name: appbuilder [6580,6590]
name: appbuilder [6596,6606]
===
match
---
name: dag_run_id [2200,2210]
name: dag_run_id [2216,2226]
===
match
---
comparison [3782,3795]
comparison [3798,3811]
===
match
---
operator: , [4562,4563]
operator: , [4578,4579]
===
match
---
name: State [10070,10075]
name: State [10177,10182]
===
match
---
operator: , [4461,4462]
operator: , [4477,4478]
===
match
---
string: "end_date" [5039,5049]
string: "end_date" [5055,5065]
===
match
---
name: ACTION_CAN_READ [9291,9306]
name: ACTION_CAN_READ [9398,9413]
===
match
---
name: permissions [7429,7440]
name: permissions [7445,7456]
===
match
---
string: "execution_date_lte" [7053,7073]
string: "execution_date_lte" [7069,7089]
===
match
---
operator: @ [2852,2853]
operator: @ [2868,2869]
===
match
---
atom [2893,2948]
atom [2909,2964]
===
match
---
atom [9278,9333]
atom [9385,9440]
===
match
---
operator: , [8453,8454]
operator: , [8488,8489]
===
match
---
name: _apply_date_filters_to_query [4579,4607]
name: _apply_date_filters_to_query [4595,4623]
===
match
---
simple_stmt [3654,3684]
simple_stmt [3670,3700]
===
match
---
trailer [6794,6803]
trailer [6810,6819]
===
match
---
operator: = [2725,2726]
operator: = [2741,2742]
===
match
---
trailer [7832,7863]
trailer [7848,7879]
===
match
---
name: query [5596,5601]
name: query [5612,5617]
===
match
---
suite [5443,6081]
suite [5459,6097]
===
match
---
argument [10239,10250]
argument [10346,10357]
===
match
---
name: provide_session [1646,1661]
name: provide_session [1662,1677]
===
match
---
name: total_entries [4339,4352]
name: total_entries [4355,4368]
===
match
---
name: delete [2105,2111]
name: delete [2121,2127]
===
match
---
simple_stmt [6627,6657]
simple_stmt [6643,6673]
===
match
---
atom_expr [5730,5751]
atom_expr [5746,5767]
===
match
---
operator: , [7195,7196]
operator: , [7211,7212]
===
match
---
operator: , [5142,5143]
operator: , [5158,5159]
===
match
---
name: dag_ids [6795,6802]
name: dag_ids [6811,6818]
===
match
---
comparison [2584,2611]
comparison [2600,2627]
===
match
---
trailer [9879,9884]
trailer [9986,9991]
===
match
---
name: post_body [8653,8662]
name: post_body [8688,8697]
===
match
---
atom_expr [7465,7494]
atom_expr [7481,7510]
===
match
---
name: detail [7924,7930]
name: detail [7940,7946]
===
match
---
expr_stmt [8026,8243]
expr_stmt [8061,8278]
===
match
---
operator: , [4722,4723]
operator: , [4738,4739]
===
match
---
atom_expr [7176,7195]
atom_expr [7192,7211]
===
match
---
name: data [6664,6668]
name: data [6680,6684]
===
match
---
operator: >= [5538,5540]
operator: >= [5554,5556]
===
match
---
name: ACTION_CAN_EDIT [9356,9371]
name: ACTION_CAN_EDIT [9463,9478]
===
match
---
name: ValidationError [6441,6456]
name: ValidationError [6457,6472]
===
match
---
trailer [7440,7453]
trailer [7456,7469]
===
match
---
comparison [5730,5773]
comparison [5746,5789]
===
match
---
name: apply_sorting [5113,5126]
name: apply_sorting [5129,5142]
===
match
---
testlist_comp [7465,7524]
testlist_comp [7481,7540]
===
match
---
atom [2883,3024]
atom [2899,3040]
===
match
---
name: post_body [9989,9998]
name: post_body [10096,10105]
===
match
---
operator: , [3272,3273]
operator: , [3288,3289]
===
match
---
atom_expr [2295,2322]
atom_expr [2311,2338]
===
match
---
decorator [7358,7535]
decorator [7374,7551]
===
match
---
name: run_after [8571,8580]
name: run_after [8606,8615]
===
match
---
operator: , [7106,7107]
operator: , [7122,7123]
===
match
---
simple_stmt [1098,1141]
simple_stmt [1114,1157]
===
match
---
string: "DAGRun not found" [2687,2705]
string: "DAGRun not found" [2703,2721]
===
match
---
operator: = [9568,9569]
operator: = [9675,9676]
===
match
---
trailer [9005,9126]
trailer [9040,9233]
===
match
---
suite [7586,9235]
suite [7602,9342]
===
match
---
trailer [5722,5729]
trailer [5738,5745]
===
match
---
name: dag_run [9690,9697]
name: dag_run [9797,9804]
===
match
---
expr_stmt [2520,2626]
expr_stmt [2536,2642]
===
match
---
name: session [7623,7630]
name: session [7639,7646]
===
match
---
operator: = [10245,10246]
operator: = [10352,10353]
===
match
---
fstring_start: f" [9026,9028]
fstring_start: f" [9079,9081]
===
match
---
param [5410,5425]
param [5426,5441]
===
match
---
name: post_body [7961,7970]
name: post_body [7995,8004]
===
match
---
operator: = [3485,3486]
operator: = [3501,3502]
===
match
---
name: dag_runs [7316,7324]
name: dag_runs [7332,7340]
===
match
---
string: "execution_date" [4969,4985]
string: "execution_date" [4985,5001]
===
match
---
operator: = [8404,8405]
operator: = [8439,8440]
===
match
---
operator: , [4337,4338]
operator: , [4353,4354]
===
match
---
operator: == [2090,2092]
operator: == [2106,2108]
===
match
---
operator: , [6942,6943]
operator: , [6958,6959]
===
match
---
operator: @ [3353,3354]
operator: @ [3369,3370]
===
match
---
trailer [4303,4368]
trailer [4319,4384]
===
match
---
trailer [10287,10291]
trailer [10394,10398]
===
match
---
trailer [6790,6794]
trailer [6806,6810]
===
match
---
import_from [896,922]
import_from [912,938]
===
match
---
operator: , [4548,4549]
operator: , [4564,4565]
===
match
---
name: query [7631,7636]
name: query [7647,7652]
===
match
---
comparison [6031,6062]
comparison [6047,6078]
===
match
---
name: DagRun [8146,8152]
name: DagRun [8181,8187]
===
match
---
fstring_start: f" [7743,7745]
fstring_start: f" [7759,7761]
===
match
---
operator: , [1199,1200]
operator: , [1215,1216]
===
match
---
operator: , [1881,1882]
operator: , [1897,1898]
===
match
---
atom_expr [7814,7863]
atom_expr [7830,7879]
===
match
---
atom [7399,7454]
atom [7415,7470]
===
match
---
trailer [7662,7669]
trailer [7678,7685]
===
match
---
operator: , [4437,4438]
operator: , [4453,4454]
===
match
---
name: dag_runs [7307,7315]
name: dag_runs [7323,7331]
===
match
---
name: query [6764,6769]
name: query [6780,6785]
===
match
---
operator: , [1814,1815]
operator: , [1830,1831]
===
match
---
name: execution_date_lte [5856,5874]
name: execution_date_lte [5872,5890]
===
match
---
fstring_end: " [2798,2799]
fstring_end: " [2814,2815]
===
match
---
operator: , [7240,7241]
operator: , [7256,7257]
===
match
---
trailer [6642,6648]
trailer [6658,6664]
===
match
---
atom_expr [6764,6804]
atom_expr [6780,6820]
===
match
---
operator: = [4908,4909]
operator: = [4924,4925]
===
match
---
trailer [6956,6972]
trailer [6972,6988]
===
match
---
name: data [7084,7088]
name: data [7100,7104]
===
match
---
name: DagRun [9594,9600]
name: DagRun [9701,9707]
===
match
---
atom_expr [8653,8674]
atom_expr [8688,8709]
===
match
---
trailer [2543,2551]
trailer [2559,2567]
===
match
---
simple_stmt [5927,5981]
simple_stmt [5943,5997]
===
match
---
operator: , [2322,2323]
operator: , [2338,2339]
===
match
---
param [3467,3491]
param [3483,3507]
===
match
---
trailer [5512,5519]
trailer [5528,5535]
===
match
---
name: dagrun_schema [8816,8829]
name: dagrun_schema [8851,8864]
===
match
---
name: request [6350,6357]
name: request [6366,6373]
===
match
---
decorator [9412,9429]
decorator [9519,9536]
===
match
---
operator: , [3519,3520]
operator: , [3535,3536]
===
match
---
operator: = [7812,7813]
operator: = [7828,7829]
===
match
---
operator: = [5219,5220]
operator: = [5235,5236]
===
match
---
suite [10173,10252]
suite [10280,10359]
===
match
---
operator: >= [5752,5754]
operator: >= [5768,5770]
===
match
---
import_as_names [1393,1524]
import_as_names [1409,1540]
===
match
---
try_stmt [7789,7941]
try_stmt [7805,7957]
===
match
---
param [2469,2480]
param [2485,2496]
===
match
---
if_stmt [6661,6881]
if_stmt [6677,6897]
===
match
---
expr_stmt [5588,5645]
expr_stmt [5604,5661]
===
match
---
operator: } [9215,9216]
operator: } [9322,9323]
===
match
---
import_as_names [832,855]
import_as_names [848,871]
===
match
---
operator: = [10264,10265]
operator: = [10371,10372]
===
match
---
operator: , [6217,6218]
operator: , [6233,6234]
===
match
---
return_stmt [2229,2250]
return_stmt [2245,2266]
===
match
---
dotted_name [1335,1379]
dotted_name [1351,1395]
===
match
---
operator: , [4485,4486]
operator: , [4501,4502]
===
match
---
dotted_name [977,1019]
dotted_name [993,1035]
===
match
---
name: permissions [9373,9384]
name: permissions [9480,9491]
===
match
---
atom_expr [8530,8594]
atom_expr [8565,8629]
===
match
---
string: """Delete a DAG Run""" [1992,2014]
string: """Delete a DAG Run""" [2008,2030]
===
match
---
name: dag_id [7569,7575]
name: dag_id [7585,7591]
===
match
---
name: dag_run_id [2776,2786]
name: dag_run_id [2792,2802]
===
match
---
operator: , [2948,2949]
operator: , [2964,2965]
===
match
---
name: BadRequest [7913,7923]
name: BadRequest [7929,7939]
===
match
---
parameters [6297,6306]
parameters [6313,6322]
===
match
---
name: DagRun [2051,2057]
name: DagRun [2067,2073]
===
match
---
trailer [2905,2921]
trailer [2921,2937]
===
match
---
raise_stmt [9792,9821]
raise_stmt [9899,9928]
===
match
---
operator: , [4129,4130]
operator: , [4145,4146]
===
match
---
name: timetable [8534,8543]
name: timetable [8569,8578]
===
match
---
name: str [9462,9465]
name: str [9569,9572]
===
match
---
name: permissions [1852,1863]
name: permissions [1868,1879]
===
match
---
operator: , [4079,4080]
operator: , [4095,4096]
===
match
---
trailer [8570,8594]
trailer [8605,8629]
===
match
---
operator: = [3514,3515]
operator: = [3530,3531]
===
match
---
trailer [6423,6429]
trailer [6439,6445]
===
match
---
name: get_dag_run [2449,2460]
name: get_dag_run [2465,2476]
===
match
---
name: end_date_lte [6050,6062]
name: end_date_lte [6066,6078]
===
match
---
operator: , [5093,5094]
operator: , [5109,5110]
===
match
---
trailer [8662,8666]
trailer [8697,8701]
===
match
---
name: run_id [8153,8159]
name: run_id [8188,8194]
===
match
---
arglist [4052,4255]
arglist [4068,4271]
===
match
---
name: airflow [1103,1110]
name: airflow [1119,1126]
===
match
---
atom [2284,2425]
atom [2300,2441]
===
match
---
import_from [1222,1329]
import_from [1238,1345]
===
match
---
name: query [6018,6023]
name: query [6034,6039]
===
match
---
trailer [8415,8422]
trailer [8450,8457]
===
match
---
fstring_string: DAGRun with DAG ID: ' [9028,9049]
fstring_string: DAGRun with DAG ID: ' [9081,9102]
===
match
---
param [3405,3412]
param [3421,3428]
===
match
---
name: detail [8906,8912]
name: detail [8941,8947]
===
match
---
name: security [1132,1140]
name: security [1148,1156]
===
match
---
trailer [9593,9601]
trailer [9700,9708]
===
match
---
name: AlreadyExists [9138,9151]
name: AlreadyExists [9245,9258]
===
match
---
atom_expr [2923,2947]
atom_expr [2939,2963]
===
match
---
argument [4321,4337]
argument [4337,4353]
===
match
---
operator: = [6348,6349]
operator: = [6364,6365]
===
match
---
comparison [9690,9705]
comparison [9797,9812]
===
match
---
operator: , [3399,3400]
operator: , [3415,3416]
===
match
---
atom_expr [4027,4261]
atom_expr [4043,4277]
===
match
---
operator: = [5505,5506]
operator: = [5521,5522]
===
match
---
arglist [8146,8208]
arglist [8181,8243]
===
match
---
trailer [6030,6063]
trailer [6046,6079]
===
match
---
operator: , [7845,7846]
operator: , [7861,7862]
===
match
---
name: State [8618,8623]
name: State [8653,8658]
===
match
---
operator: = [8739,8740]
operator: = [8774,8775]
===
match
---
atom_expr [6219,6247]
atom_expr [6235,6263]
===
match
---
name: ACTION_CAN_READ [2971,2986]
name: ACTION_CAN_READ [2987,3002]
===
match
---
param [1958,1965]
param [1974,1981]
===
match
---
name: logical_date [8486,8498]
name: logical_date [8521,8533]
===
match
---
import_from [1662,1699]
import_from [1678,1715]
===
match
---
name: body [6424,6428]
name: body [6440,6444]
===
match
---
name: ValidationError [9910,9925]
name: ValidationError [10017,10032]
===
match
---
trailer [8177,8192]
trailer [8212,8227]
===
match
---
atom_expr [10266,10303]
atom_expr [10373,10410]
===
match
---
fstring_string:  not found in dag  [9756,9774]
fstring_string:  not found in dag  [9863,9881]
===
match
---
name: NotFound [9798,9806]
name: NotFound [9905,9913]
===
match
---
name: filter [3965,3971]
name: filter [3981,3987]
===
match
---
name: post_dag_run [7556,7568]
name: post_dag_run [7572,7584]
===
match
---
raise_stmt [6473,6515]
raise_stmt [6489,6531]
===
match
---
name: execution_date_gte [4111,4129]
name: execution_date_gte [4127,4145]
===
match
---
name: State [1694,1699]
name: State [1710,1715]
===
match
---
name: data [7214,7218]
name: data [7230,7234]
===
match
---
name: user [3925,3929]
name: user [3941,3945]
===
match
---
trailer [7630,7636]
trailer [7646,7652]
===
match
---
simple_stmt [2520,2627]
simple_stmt [2536,2643]
===
match
---
operator: , [3184,3185]
operator: , [3200,3201]
===
match
---
raise_stmt [2128,2224]
raise_stmt [2144,2240]
===
match
---
atom_expr [6726,6747]
atom_expr [6742,6763]
===
match
---
name: start_date_gte [5475,5489]
name: start_date_gte [5491,5505]
===
match
---
name: dag_hash [8731,8739]
name: dag_hash [8766,8774]
===
match
---
trailer [5241,5247]
trailer [5257,5263]
===
match
---
file_input [785,10343]
file_input [785,10450]
===
match
---
operator: = [8912,8913]
operator: = [8947,8948]
===
match
---
operator: == [10067,10069]
operator: == [10174,10176]
===
match
---
trailer [8322,8330]
trailer [8357,8365]
===
match
---
dotted_name [1103,1124]
dotted_name [1119,1140]
===
match
---
atom_expr [5609,5626]
atom_expr [5625,5642]
===
match
---
argument [8440,8453]
argument [8475,8488]
===
match
---
fstring_start: f" [9159,9161]
fstring_start: f" [9266,9268]
===
match
---
simple_stmt [2815,2850]
simple_stmt [2831,2866]
===
match
---
import_from [1330,1526]
import_from [1346,1542]
===
match
---
name: detail [7736,7742]
name: detail [7752,7758]
===
match
---
name: models [1540,1546]
name: models [1556,1562]
===
match
---
param [5342,5355]
param [5358,5371]
===
match
---
operator: , [4220,4221]
operator: , [4236,4237]
===
match
---
operator: , [4770,4771]
operator: , [4786,4787]
===
match
---
trailer [7180,7195]
trailer [7196,7211]
===
match
---
comparison [8930,8976]
comparison [8965,9011]
===
match
---
name: types [1719,1724]
name: types [1735,1740]
===
match
---
name: g [6615,6616]
name: g [6631,6632]
===
match
---
name: logical_date [8964,8976]
name: logical_date [8999,9011]
===
match
---
name: DagModel [1554,1562]
name: DagModel [1570,1578]
===
match
---
operator: = [10157,10158]
operator: = [10264,10265]
===
match
---
atom [1776,1919]
atom [1792,1935]
===
match
---
name: data [7012,7016]
name: data [7028,7032]
===
match
---
operator: , [10149,10150]
operator: , [10256,10257]
===
match
---
simple_stmt [9506,9538]
simple_stmt [9613,9645]
===
match
---
trailer [10291,10303]
trailer [10398,10410]
===
match
---
param [9484,9491]
param [9591,9598]
===
match
---
name: query [5810,5815]
name: query [5826,5831]
===
match
---
trailer [8061,8067]
trailer [8096,8102]
===
match
---
name: permissions [9279,9290]
name: permissions [9386,9397]
===
match
---
name: dag_run [10256,10263]
name: dag_run [10363,10370]
===
match
---
trailer [6711,6722]
trailer [6727,6738]
===
match
---
operator: } [2180,2181]
operator: } [2196,2197]
===
match
---
import_as_names [1186,1221]
import_as_names [1202,1237]
===
match
---
fstring_string: Dag Run id  [9733,9744]
fstring_string: Dag Run id  [9840,9851]
===
match
---
name: DagRunType [1732,1742]
name: DagRunType [1748,1758]
===
match
---
operator: , [8630,8631]
operator: , [8665,8666]
===
match
---
string: "external_trigger" [5059,5077]
string: "external_trigger" [5075,5093]
===
match
---
atom_expr [7116,7138]
atom_expr [7132,7154]
===
match
---
trailer [2043,2050]
trailer [2059,2066]
===
match
---
simple_stmt [5810,5876]
simple_stmt [5826,5892]
===
match
---
suite [8284,8844]
suite [8319,8879]
===
match
---
name: conf [8648,8652]
name: conf [8683,8687]
===
match
---
operator: , [3565,3566]
operator: , [3581,3582]
===
match
---
testlist_comp [2294,2419]
testlist_comp [2310,2435]
===
match
---
name: data [6982,6986]
name: data [6998,7002]
===
match
---
operator: == [3789,3791]
operator: == [3805,3807]
===
match
---
string: "state" [4934,4941]
string: "state" [4950,4957]
===
match
---
trailer [6366,6368]
trailer [6382,6384]
===
match
---
name: format_datetime [3257,3272]
name: format_datetime [3273,3288]
===
match
---
operator: , [7525,7526]
operator: , [7541,7542]
===
match
---
name: session [2530,2537]
name: session [2546,2553]
===
match
---
trailer [3978,3985]
trailer [3994,4001]
===
match
---
trailer [10075,10083]
trailer [10182,10190]
===
match
---
name: sm [6591,6593]
name: sm [6607,6609]
===
match
---
operator: , [1562,1563]
operator: , [1578,1579]
===
match
---
string: "execution_date" [7971,7987]
string: "execution_date" [8005,8021]
===
match
---
name: RESOURCE_DAG_RUN [7508,7524]
name: RESOURCE_DAG_RUN [7524,7540]
===
match
---
operator: = [6578,6579]
operator: = [6594,6595]
===
match
---
dotted_name [6084,6108]
dotted_name [6100,6124]
===
match
---
name: external_trigger [8692,8708]
name: external_trigger [8727,8743]
===
match
---
operator: = [10016,10017]
operator: = [10123,10124]
===
match
---
name: create_dagrun [8365,8378]
name: create_dagrun [8400,8413]
===
match
---
trailer [3924,3929]
trailer [3940,3945]
===
match
---
name: DagRun [5520,5526]
name: DagRun [5536,5542]
===
match
---
name: appbuilder [3830,3840]
name: appbuilder [3846,3856]
===
match
---
fstring_string: DAGRun with DAG ID: ' [9161,9182]
fstring_string: DAGRun with DAG ID: ' [9268,9289]
===
match
---
param [3604,3618]
param [3620,3634]
===
match
---
atom_expr [9580,9676]
atom_expr [9687,9783]
===
match
---
operator: , [2387,2388]
operator: , [2403,2404]
===
match
---
name: NotFound [2134,2142]
name: NotFound [2150,2158]
===
match
---
name: DagRun [5609,5615]
name: DagRun [5625,5631]
===
match
---
operator: , [8674,8675]
operator: , [8709,8710]
===
match
---
name: BadRequest [1201,1211]
name: BadRequest [1217,1227]
===
match
---
param [4542,4549]
param [4558,4565]
===
match
---
trailer [6857,6861]
trailer [6873,6877]
===
match
---
name: dagrun_schema [2822,2835]
name: dagrun_schema [2838,2851]
===
match
---
name: security [9238,9246]
name: security [9345,9353]
===
match
---
operator: , [6894,6895]
operator: , [6910,6911]
===
match
---
operator: = [3660,3661]
operator: = [3676,3677]
===
match
---
operator: , [9306,9307]
operator: , [9413,9414]
===
match
---
comparison [7654,7679]
comparison [7670,7695]
===
match
---
trailer [2624,2626]
trailer [2640,2642]
===
match
---
atom_expr [7084,7106]
atom_expr [7100,7122]
===
match
---
name: set_dag_run_state_to_success [1066,1094]
name: set_dag_run_state_to_success [1082,1110]
===
match
---
testlist_comp [9278,9403]
testlist_comp [9385,9510]
===
match
---
decorator [2428,2445]
decorator [2444,2461]
===
match
---
funcdef [6275,7356]
funcdef [6291,7372]
===
match
---
name: provide_session [1923,1938]
name: provide_session [1939,1954]
===
match
---
name: load [9880,9884]
name: load [9987,9991]
===
match
---
name: total_entries [6896,6909]
name: total_entries [6912,6925]
===
match
---
operator: , [3313,3314]
operator: , [3329,3330]
===
match
---
parameters [2460,2489]
parameters [2476,2505]
===
match
---
name: set_dag_run_state_to_failed [10182,10209]
name: set_dag_run_state_to_failed [10289,10316]
===
match
---
string: "dag_ids" [6712,6721]
string: "dag_ids" [6728,6737]
===
match
---
simple_stmt [6823,6881]
simple_stmt [6839,6897]
===
match
---
name: limit [3588,3593]
name: limit [3604,3609]
===
match
---
testlist_comp [9279,9332]
testlist_comp [9386,9439]
===
match
---
trailer [7934,7939]
trailer [7950,7955]
===
match
---
param [4467,4486]
param [4483,4502]
===
match
---
name: filter [5723,5729]
name: filter [5739,5745]
===
match
---
operator: , [7002,7003]
operator: , [7018,7019]
===
match
---
atom_expr [6635,6656]
atom_expr [6651,6672]
===
match
---
name: dag_run_id [2601,2611]
name: dag_run_id [2617,2627]
===
match
---
suite [3621,4369]
suite [3637,4385]
===
match
---
operator: , [4419,4420]
operator: , [4435,4436]
===
match
---
atom_expr [8054,8237]
atom_expr [8089,8272]
===
match
---
argument [7736,7783]
argument [7752,7799]
===
match
---
operator: , [5154,5155]
operator: , [5170,5171]
===
match
---
param [6298,6305]
param [6314,6321]
===
match
---
trailer [1827,1840]
trailer [1843,1856]
===
match
---
name: total_entries [4353,4366]
name: total_entries [4369,4382]
===
match
---
name: dagrun_instance [8026,8041]
name: dagrun_instance [8061,8076]
===
match
---
operator: , [9632,9633]
operator: , [9739,9740]
===
match
---
atom_expr [10315,10342]
atom_expr [10422,10449]
===
match
---
operator: , [846,847]
operator: , [862,863]
===
match
---
name: logical_date [8581,8593]
name: logical_date [8616,8628]
===
match
---
name: err [7894,7897]
name: err [7910,7913]
===
match
---
name: err [9929,9932]
name: err [10036,10039]
===
match
---
operator: = [6532,6533]
operator: = [6548,6549]
===
match
---
name: airflow [1146,1153]
name: airflow [1162,1169]
===
match
---
operator: = [7959,7960]
operator: = [7975,7976]
===
match
---
operator: , [5029,5030]
operator: , [5045,5046]
===
match
---
name: _fetch_dag_runs [4375,4390]
name: _fetch_dag_runs [4391,4406]
===
match
---
operator: = [8485,8486]
operator: = [8520,8521]
===
match
---
trailer [3883,3887]
trailer [3899,3903]
===
match
---
operator: = [3816,3817]
operator: = [3832,3833]
===
match
---
name: in_ [6858,6861]
name: in_ [6874,6877]
===
match
---
operator: , [10237,10238]
operator: , [10344,10345]
===
match
---
trailer [3971,3996]
trailer [3987,4012]
===
match
---
operator: } [9056,9057]
operator: } [9109,9110]
===
match
---
operator: = [7854,7855]
operator: = [7870,7871]
===
match
---
suite [6684,6805]
suite [6700,6821]
===
match
---
name: total_entries [4011,4024]
name: total_entries [4027,4040]
===
match
---
name: DagModel [7637,7645]
name: DagModel [7653,7661]
===
match
---
comparison [3972,3995]
comparison [3988,4011]
===
match
---
simple_stmt [8351,8797]
simple_stmt [8386,8832]
===
match
---
operator: , [7575,7576]
operator: , [7591,7592]
===
match
---
operator: { [9774,9775]
operator: { [9881,9882]
===
match
---
atom_expr [8930,8960]
atom_expr [8965,8995]
===
match
---
atom_expr [7961,7988]
atom_expr [7995,8022]
===
match
---
atom_expr [6031,6046]
atom_expr [6047,6062]
===
match
---
trailer [3862,3869]
trailer [3878,3885]
===
match
---
atom_expr [2389,2417]
atom_expr [2405,2433]
===
match
---
trailer [6668,6672]
trailer [6684,6688]
===
match
---
name: execution_date_lte [3496,3514]
name: execution_date_lte [3512,3530]
===
match
---
if_stmt [3779,3997]
if_stmt [3795,4013]
===
match
---
string: "page_offset" [7181,7194]
string: "page_offset" [7197,7210]
===
match
---
name: QUEUED [8624,8630]
name: QUEUED [8659,8665]
===
match
---
param [4491,4506]
param [4507,4522]
===
match
---
name: start_date_lte [4756,4770]
name: start_date_lte [4772,4786]
===
match
---
string: "dag_id" [4951,4959]
string: "dag_id" [4967,4975]
===
match
---
atom_expr [1787,1814]
atom_expr [1803,1830]
===
match
---
name: query [4396,4401]
name: query [4412,4417]
===
match
---
atom_expr [9798,9821]
atom_expr [9905,9928]
===
match
---
trailer [6500,6514]
trailer [6516,6530]
===
match
---
name: dags_hash [8760,8769]
name: dags_hash [8795,8804]
===
match
---
trailer [10299,10302]
trailer [10406,10409]
===
match
---
name: limit [4215,4220]
name: limit [4231,4236]
===
match
---
name: err [6460,6463]
name: err [6476,6479]
===
match
---
atom_expr [7931,7939]
atom_expr [7947,7955]
===
match
---
argument [7205,7240]
argument [7221,7256]
===
match
---
name: security [2254,2262]
name: security [2270,2278]
===
match
---
name: permissions [2959,2970]
name: permissions [2975,2986]
===
match
---
fstring_end: " [7782,7783]
fstring_end: " [7798,7799]
===
match
---
trailer [6418,6423]
trailer [6434,6439]
===
match
---
name: AlreadyExists [1186,1199]
name: AlreadyExists [1202,1215]
===
match
---
atom_expr [7012,7038]
atom_expr [7028,7054]
===
match
---
return_stmt [7253,7355]
return_stmt [7269,7371]
===
match
---
name: DagRun [2036,2042]
name: DagRun [2052,2058]
===
match
---
if_stmt [8927,9127]
if_stmt [8962,9234]
===
match
---
trailer [10134,10149]
trailer [10241,10256]
===
match
---
operator: , [7074,7075]
operator: , [7090,7091]
===
match
---
name: data [7176,7180]
name: data [7192,7196]
===
match
---
name: dag [10012,10015]
name: dag [10119,10122]
===
match
---
name: err [7935,7938]
name: err [7951,7954]
===
match
---
simple_stmt [2495,2516]
simple_stmt [2511,2532]
===
match
---
if_stmt [2631,2811]
if_stmt [2647,2827]
===
match
---
name: query [5335,5340]
name: query [5351,5356]
===
match
---
atom_expr [9609,9622]
atom_expr [9716,9729]
===
match
---
name: requires_access [9247,9262]
name: requires_access [9354,9369]
===
match
---
operator: , [3617,3618]
operator: , [3633,3634]
===
match
---
simple_stmt [9792,9822]
simple_stmt [9899,9929]
===
match
---
name: error_message [9807,9820]
name: error_message [9914,9927]
===
match
---
try_stmt [6373,6516]
try_stmt [6389,6532]
===
match
---
operator: , [5007,5008]
operator: , [5023,5024]
===
match
---
trailer [6037,6046]
trailer [6053,6062]
===
match
---
name: format_datetime [3079,3094]
name: format_datetime [3095,3110]
===
match
---
name: start_date_lte [4191,4205]
name: start_date_lte [4207,4221]
===
match
---
operator: , [843,844]
operator: , [859,860]
===
match
---
argument [2143,2223]
argument [2159,2239]
===
match
---
name: body [6343,6347]
name: body [6359,6363]
===
match
---
name: DAGRunCollection [7290,7306]
name: DAGRunCollection [7306,7322]
===
match
---
funcdef [2445,2850]
funcdef [2461,2866]
===
match
---
string: "page_limit" [7153,7165]
string: "page_limit" [7169,7181]
===
match
---
atom [3051,3350]
atom [3067,3366]
===
match
---
raise_stmt [7698,7784]
raise_stmt [7714,7800]
===
match
---
trailer [6590,6593]
trailer [6606,6609]
===
match
---
comparison [8105,8128]
comparison [8140,8163]
===
match
---
trailer [2082,2089]
trailer [2098,2105]
===
match
---
operator: , [4157,4158]
operator: , [4173,4174]
===
match
---
name: AlreadyExists [8992,9005]
name: AlreadyExists [9027,9040]
===
match
---
name: marshmallow [861,872]
name: marshmallow [877,888]
===
match
---
arglist [4321,4366]
arglist [4337,4382]
===
match
---
suite [5801,5876]
suite [5817,5892]
===
match
---
name: query [5935,5940]
name: query [5951,5956]
===
match
---
name: offset [4542,4548]
name: offset [4558,4564]
===
match
---
operator: @ [6258,6259]
operator: @ [6274,6275]
===
match
---
operator: , [1523,1524]
operator: , [1539,1540]
===
match
---
trailer [3669,3675]
trailer [3685,3691]
===
match
---
argument [7307,7324]
argument [7323,7340]
===
match
---
parameters [1957,1986]
parameters [1973,2002]
===
match
---
operator: , [10125,10126]
operator: , [10232,10233]
===
match
---
name: provide_session [7536,7551]
name: provide_session [7552,7567]
===
match
---
import_from [1571,1611]
import_from [1587,1627]
===
match
---
name: dag_run [9542,9549]
name: dag_run [9649,9656]
===
match
---
operator: @ [6083,6084]
operator: @ [6099,6100]
===
match
---
atom_expr [8002,8021]
atom_expr [8037,8056]
===
match
---
trailer [3887,3931]
trailer [3903,3947]
===
match
---
operator: = [7315,7316]
operator: = [7331,7332]
===
match
---
operator: = [7339,7340]
operator: = [7355,7356]
===
match
---
suite [4566,5295]
suite [4582,5311]
===
match
---
operator: , [7494,7495]
operator: , [7510,7511]
===
match
---
atom_expr [3857,3932]
atom_expr [3873,3948]
===
match
---
name: RESOURCE_DAG [2336,2348]
name: RESOURCE_DAG [2352,2364]
===
match
---
simple_stmt [8026,8244]
simple_stmt [8061,8279]
===
match
---
name: security [7359,7367]
name: security [7375,7383]
===
match
---
name: appbuilder [6521,6531]
name: appbuilder [6537,6547]
===
match
---
simple_stmt [6521,6557]
simple_stmt [6537,6573]
===
match
---
name: RESOURCE_DAG_RUN [9385,9401]
name: RESOURCE_DAG_RUN [9492,9508]
===
match
---
trailer [10121,10163]
trailer [10228,10270]
===
match
---
name: data [6386,6390]
name: data [6402,6406]
===
match
---
dotted_name [1146,1178]
dotted_name [1162,1194]
===
match
---
name: total_entries [4800,4813]
name: total_entries [4816,4829]
===
match
---
operator: , [3598,3599]
operator: , [3614,3615]
===
match
---
expr_stmt [4800,4829]
expr_stmt [4816,4845]
===
match
---
operator: } [2786,2787]
operator: } [2802,2803]
===
match
---
name: api_connexion [1343,1356]
name: api_connexion [1359,1372]
===
match
---
funcdef [7552,9235]
funcdef [7568,9342]
===
match
---
decorator [2852,3027]
decorator [2868,3043]
===
match
---
decorated [2253,2850]
decorated [2269,2866]
===
match
---
param [5356,5369]
param [5372,5385]
===
match
---
return_stmt [10308,10342]
return_stmt [10415,10449]
===
match
---
name: parameters [1249,1259]
name: parameters [1265,1275]
===
match
---
string: "id" [7235,7239]
string: "id" [7251,7255]
===
match
---
operator: == [8160,8162]
operator: == [8195,8197]
===
match
---
name: readable_dag_ids [6730,6746]
name: readable_dag_ids [6746,6762]
===
match
---
name: set_dag_run_state_to_failed [1033,1060]
name: set_dag_run_state_to_failed [1049,1076]
===
match
---
import_from [1098,1140]
import_from [1114,1156]
===
match
---
name: data [7116,7120]
name: data [7132,7136]
===
match
---
operator: = [6910,6911]
operator: = [6926,6927]
===
match
---
suite [6377,6430]
suite [6393,6446]
===
match
---
name: dag_id [2750,2756]
name: dag_id [2766,2772]
===
match
---
trailer [1798,1814]
trailer [1814,1830]
===
match
---
trailer [2999,3016]
trailer [3015,3032]
===
match
---
suite [9706,9822]
suite [9813,9929]
===
match
---
testlist_comp [6125,6178]
testlist_comp [6141,6194]
===
match
---
string: 'execution_date_gte' [3147,3167]
string: 'execution_date_gte' [3163,3183]
===
match
---
trailer [2371,2387]
trailer [2387,2403]
===
match
---
name: post_body [8002,8011]
name: post_body [8037,8046]
===
match
---
name: query [5105,5110]
name: query [5121,5126]
===
match
---
tfpdef [9467,9482]
tfpdef [9574,9589]
===
match
---
operator: } [9755,9756]
operator: } [9862,9863]
===
match
---
fstring [7743,7783]
fstring [7759,7799]
===
match
---
trailer [4827,4829]
trailer [4843,4845]
===
match
---
atom_expr [9948,9975]
atom_expr [10055,10082]
===
match
---
if_stmt [5561,5646]
if_stmt [5577,5662]
===
match
---
fstring_expr [2749,2757]
fstring_expr [2765,2773]
===
match
---
atom_expr [7290,7354]
atom_expr [7306,7370]
===
match
---
operator: { [2199,2200]
operator: { [2215,2216]
===
match
---
atom_expr [3662,3683]
atom_expr [3678,3699]
===
match
---
name: dag_bag [8315,8322]
name: dag_bag [8350,8357]
===
match
---
trailer [9151,9234]
trailer [9258,9341]
===
match
---
operator: , [3231,3232]
operator: , [3247,3248]
===
match
---
fstring_string: DAG with dag_id: ' [7745,7763]
fstring_string: DAG with dag_id: ' [7761,7779]
===
match
---
trailer [6201,6217]
trailer [6217,6233]
===
match
---
string: "start_date_gte" [7089,7105]
string: "start_date_gte" [7105,7121]
===
match
---
atom_expr [9344,9371]
atom_expr [9451,9478]
===
match
---
expr_stmt [10256,10303]
expr_stmt [10363,10410]
===
match
---
name: RESOURCE_DAG_RUN [1895,1911]
name: RESOURCE_DAG_RUN [1911,1927]
===
match
---
parameters [9453,9492]
parameters [9560,9599]
===
match
---
name: airflow [1667,1674]
name: airflow [1683,1690]
===
match
---
name: ACTION_CAN_CREATE [7477,7494]
name: ACTION_CAN_CREATE [7493,7510]
===
match
---
name: DagRun [9634,9640]
name: DagRun [9741,9747]
===
match
---
name: dag_id [10046,10052]
name: dag_id [10153,10159]
===
match
---
atom_expr [1883,1911]
atom_expr [1899,1927]
===
match
---
name: RESOURCE_DAG_RUN [6231,6247]
name: RESOURCE_DAG_RUN [6247,6263]
===
match
---
name: airflow [1532,1539]
name: airflow [1548,1555]
===
match
---
suite [1987,2251]
suite [2003,2267]
===
match
---
atom_expr [9851,9898]
atom_expr [9958,10005]
===
match
---
name: query [3654,3659]
name: query [3670,3675]
===
match
---
name: permissions [7400,7411]
name: permissions [7416,7427]
===
match
---
operator: , [3582,3583]
operator: , [3598,3599]
===
match
---
atom_expr [6844,6879]
atom_expr [6860,6895]
===
match
---
operator: , [7138,7139]
operator: , [7154,7155]
===
match
---
name: delete_dag_run [1943,1957]
name: delete_dag_run [1959,1973]
===
match
---
name: execution_date_gte [4443,4461]
name: execution_date_gte [4459,4477]
===
match
---
name: query [5127,5132]
name: query [5143,5148]
===
match
---
name: session [6298,6305]
name: session [6314,6321]
===
match
---
atom_expr [2051,2064]
atom_expr [2067,2080]
===
match
---
except_clause [8852,8875]
except_clause [8887,8910]
===
match
---
suite [2650,2811]
suite [2666,2827]
===
match
---
name: user [6617,6621]
name: user [6633,6637]
===
match
---
trailer [6165,6178]
trailer [6181,6194]
===
match
---
name: api [985,988]
name: api [1001,1004]
===
match
---
operator: , [4644,4645]
operator: , [4660,4661]
===
match
---
name: permissions [2360,2371]
name: permissions [2376,2387]
===
match
---
string: 'state' [9999,10006]
string: 'state' [10106,10113]
===
match
---
dotted_name [1227,1259]
dotted_name [1243,1275]
===
match
---
name: query [6627,6632]
name: query [6643,6648]
===
match
---
atom_expr [6831,6880]
atom_expr [6847,6896]
===
match
---
operator: , [2245,2246]
operator: , [2261,2262]
===
match
---
operator: , [4101,4102]
operator: , [4117,4118]
===
match
---
argument [7924,7939]
argument [7940,7955]
===
match
---
operator: } [9189,9190]
operator: } [9296,9297]
===
match
---
string: 'end_date_gte' [3241,3255]
string: 'end_date_gte' [3257,3271]
===
match
---
string: 'limit' [3323,3330]
string: 'limit' [3339,3346]
===
match
---
name: permissions [1883,1894]
name: permissions [1899,1910]
===
match
---
operator: = [4352,4353]
operator: = [4368,4369]
===
match
---
atom_expr [6982,7002]
atom_expr [6998,7018]
===
match
---
name: query [5927,5932]
name: query [5943,5948]
===
match
---
fstring_string: DAGRun with DAG ID: ' [2728,2749]
fstring_string: DAGRun with DAG ID: ' [2744,2765]
===
match
---
name: session [7855,7862]
name: session [7871,7878]
===
match
---
import_from [814,855]
import_from [830,871]
===
match
---
trailer [8769,8773]
trailer [8804,8808]
===
match
---
raise_stmt [2659,2810]
raise_stmt [2675,2826]
===
match
---
operator: @ [7358,7359]
operator: @ [7374,7375]
===
match
---
suite [6307,7356]
suite [6323,7372]
===
match
---
simple_stmt [6010,6064]
simple_stmt [6026,6080]
===
match
---
simple_stmt [9942,9976]
simple_stmt [10049,10083]
===
match
---
simple_stmt [6386,6430]
simple_stmt [6402,6446]
===
match
---
atom_expr [8405,8422]
atom_expr [8440,8457]
===
match
---
trailer [10333,10342]
trailer [10440,10449]
===
match
---
trailer [9355,9371]
trailer [9462,9478]
===
match
---
name: query [3670,3675]
name: query [3686,3691]
===
match
---
param [3392,3400]
param [3408,3416]
===
match
---
name: DagRun [2559,2565]
name: DagRun [2575,2581]
===
match
---
name: offset [5227,5233]
name: offset [5243,5249]
===
match
---
trailer [2335,2348]
trailer [2351,2364]
===
match
---
name: data [7148,7152]
name: data [7164,7168]
===
match
---
import_from [785,812]
import_from [785,812]
===
match
---
arglist [8105,8210]
arglist [8140,8245]
===
match
---
name: data_interval [8516,8529]
name: data_interval [8551,8564]
===
match
---
atom_expr [6664,6683]
atom_expr [6680,6699]
===
match
---
name: NoContent [962,971]
name: NoContent [978,987]
===
match
---
name: permissions [6154,6165]
name: permissions [6170,6181]
===
match
---
fstring [2150,2223]
fstring [2166,2239]
===
match
---
name: filter [5824,5830]
name: filter [5840,5846]
===
match
---
name: DagRun [3972,3978]
name: DagRun [3988,3994]
===
match
---
name: readable_dag_ids [6561,6577]
name: readable_dag_ids [6577,6593]
===
match
---
name: dag_id [2068,2074]
name: dag_id [2084,2090]
===
match
---
name: start_date_lte [5630,5644]
name: start_date_lte [5646,5660]
===
match
---
trailer [2840,2849]
trailer [2856,2865]
===
match
---
import_as_names [1554,1570]
import_as_names [1570,1586]
===
match
---
atom_expr [8913,8920]
atom_expr [8948,8955]
===
match
---
name: dag_runs [4321,4329]
name: dag_runs [4337,4345]
===
match
---
simple_stmt [6068,6081]
simple_stmt [6084,6097]
===
match
---
testlist_comp [6190,6247]
testlist_comp [6206,6263]
===
match
---
atom_expr [5818,5875]
atom_expr [5834,5891]
===
match
---
name: json [9893,9897]
name: json [10000,10004]
===
match
---
suite [5579,5646]
suite [5595,5662]
===
match
---
atom_expr [3818,3840]
atom_expr [3834,3856]
===
match
---
name: order_by [4246,4254]
name: order_by [4262,4270]
===
match
---
simple_stmt [856,896]
simple_stmt [872,912]
===
match
---
expr_stmt [6627,6656]
expr_stmt [6643,6672]
===
match
---
fstring_string: ' not found [7771,7782]
fstring_string: ' not found [7787,7798]
===
match
---
name: end_date_gte [5967,5979]
name: end_date_gte [5983,5995]
===
match
---
decorated [1745,2251]
decorated [1761,2267]
===
match
---
name: get_dag [10038,10045]
name: get_dag [10145,10152]
===
match
---
comparison [2051,2074]
comparison [2067,2090]
===
match
---
argument [2719,2799]
argument [2735,2815]
===
match
---
name: end_date [5955,5963]
name: end_date [5971,5979]
===
match
---
name: all [5255,5258]
name: all [5271,5274]
===
match
---
operator: = [6496,6497]
operator: = [6512,6513]
===
match
---
operator: , [2349,2350]
operator: , [2365,2366]
===
match
---
argument [9959,9974]
argument [10066,10081]
===
match
---
trailer [10037,10045]
trailer [10144,10152]
===
match
---
suite [8271,8922]
suite [8306,8957]
===
match
---
trailer [2057,2064]
trailer [2073,2080]
===
match
---
trailer [2934,2947]
trailer [2950,2963]
===
match
---
simple_stmt [7698,7785]
simple_stmt [7714,7801]
===
match
---
name: commit [10151,10157]
name: commit [10258,10264]
===
match
---
name: execution_date [8946,8960]
name: execution_date [8981,8995]
===
match
---
name: utils [1713,1718]
name: utils [1729,1734]
===
match
---
name: query [6010,6015]
name: query [6026,6031]
===
match
---
atom [6114,6255]
atom [6130,6271]
===
match
---
name: ValidationError [880,895]
name: ValidationError [896,911]
===
match
---
name: get [10288,10291]
name: get [10395,10398]
===
match
---
argument [8612,8630]
argument [8647,8665]
===
match
---
testlist_star_expr [6886,6909]
testlist_star_expr [6902,6925]
===
match
---
operator: , [7427,7428]
operator: , [7443,7444]
===
match
---
name: dag_id [2058,2064]
name: dag_id [2074,2080]
===
match
---
name: provide_session [3354,3369]
name: provide_session [3370,3385]
===
match
---
trailer [8533,8543]
trailer [8568,8578]
===
match
---
fstring_start: f" [2726,2728]
fstring_start: f" [2742,2744]
===
match
---
name: permissions [7496,7507]
name: permissions [7512,7523]
===
match
---
operator: , [9482,9483]
operator: , [9589,9590]
===
match
---
name: run_id [2083,2089]
name: run_id [2099,2105]
===
match
---
string: 'start_date_lte' [3104,3120]
string: 'start_date_lte' [3120,3136]
===
match
---
operator: { [3051,3052]
operator: { [3067,3068]
===
match
---
name: allowed_filter_attrs [5156,5176]
name: allowed_filter_attrs [5172,5192]
===
match
---
name: current_app [10018,10029]
name: current_app [10125,10136]
===
match
---
simple_stmt [2128,2225]
simple_stmt [2144,2241]
===
match
---
name: offset [5234,5240]
name: offset [5250,5256]
===
match
---
name: permissions [1787,1798]
name: permissions [1803,1814]
===
match
---
param [7577,7584]
param [7593,7600]
===
match
---
name: execution_date_gte [3467,3485]
name: execution_date_gte [3483,3501]
===
match
---
trailer [2050,2104]
trailer [2066,2120]
===
match
---
fstring_start: f' [9731,9733]
fstring_start: f' [9838,9840]
===
match
---
name: dag_run [2841,2848]
name: dag_run [2857,2864]
===
match
---
operator: , [4959,4960]
operator: , [4975,4976]
===
match
---
name: end_date_gte [4632,4644]
name: end_date_gte [4648,4660]
===
match
---
name: total_entries [7340,7353]
name: total_entries [7356,7369]
===
match
---
operator: , [3436,3437]
operator: , [3452,3453]
===
match
---
name: permissions [6125,6136]
name: permissions [6141,6152]
===
match
---
name: limit [5248,5253]
name: limit [5264,5269]
===
match
---
operator: , [4009,4010]
operator: , [4025,4026]
===
match
---
decorated [2852,4369]
decorated [2868,4385]
===
match
---
operator: , [2582,2583]
operator: , [2598,2599]
===
match
---
fstring_end: ' [9782,9783]
fstring_end: ' [9889,9890]
===
match
---
atom_expr [7913,7940]
atom_expr [7929,7956]
===
match
---
name: provide_session [6259,6274]
name: provide_session [6275,6290]
===
match
---
name: query [10274,10279]
name: query [10381,10386]
===
match
---
param [2481,2488]
param [2497,2504]
===
match
---
simple_stmt [896,923]
simple_stmt [912,939]
===
match
---
string: "~" [3792,3795]
string: "~" [3808,3811]
===
match
---
atom_expr [5113,5177]
atom_expr [5129,5193]
===
match
---
operator: , [4941,4942]
operator: , [4957,4958]
===
match
---
name: get_dag_runs [3374,3386]
name: get_dag_runs [3390,3402]
===
match
---
import_from [1141,1221]
import_from [1157,1237]
===
match
---
trailer [6648,6656]
trailer [6664,6672]
===
match
---
decorators [7358,7552]
decorators [7374,7568]
===
match
---
name: session [10266,10273]
name: session [10373,10380]
===
match
---
operator: , [8498,8499]
operator: , [8533,8534]
===
match
---
name: DagRun [3676,3682]
name: DagRun [3692,3698]
===
match
---
atom_expr [10292,10302]
atom_expr [10399,10409]
===
match
---
suite [9501,10343]
suite [9608,10450]
===
match
---
name: post_body [9839,9848]
name: post_body [9946,9955]
===
match
---
name: dag_run_id [9745,9755]
name: dag_run_id [9852,9862]
===
match
---
suite [6464,6516]
suite [6480,6532]
===
match
---
decorator [6083,6258]
decorator [6099,6274]
===
match
---
operator: @ [9412,9413]
operator: @ [9519,9520]
===
match
---
name: start_date [5527,5537]
name: start_date [5543,5553]
===
match
---
name: permissions [1600,1611]
name: permissions [1616,1627]
===
match
---
trailer [6729,6747]
trailer [6745,6763]
===
match
---
trailer [7218,7222]
trailer [7234,7238]
===
match
---
decorator [3353,3370]
decorator [3369,3386]
===
match
---
operator: == [7670,7672]
operator: == [7686,7688]
===
match
---
suite [7793,7864]
suite [7809,7880]
===
match
---
name: permissions [2324,2335]
name: permissions [2340,2351]
===
match
---
fstring_expr [9085,9099]
fstring_expr [9158,9191]
===
match
---
name: permissions [6190,6201]
name: permissions [6206,6217]
===
match
---
suite [8876,8922]
suite [8911,8957]
===
match
---
atom_expr [6912,7247]
atom_expr [6928,7263]
===
match
---
suite [5918,5981]
suite [5934,5997]
===
match
---
operator: , [1841,1842]
operator: , [1857,1858]
===
match
---
name: format_parameters [1312,1329]
name: format_parameters [1328,1345]
===
match
---
name: start_date_gte [5541,5555]
name: start_date_gte [5557,5571]
===
match
---
trailer [10045,10053]
trailer [10152,10160]
===
match
---
trailer [10279,10287]
trailer [10386,10394]
===
match
---
trailer [10273,10279]
trailer [10380,10386]
===
match
---
name: format_datetime [3169,3184]
name: format_datetime [3185,3200]
===
match
---
operator: = [5111,5112]
operator: = [5127,5128]
===
match
---
operator: , [4924,4925]
operator: , [4940,4941]
===
match
---
name: query [6937,6942]
name: query [6953,6958]
===
match
---
name: request [7833,7840]
name: request [7849,7856]
===
match
---
name: start_date_lte [5564,5578]
name: start_date_lte [5580,5594]
===
match
---
argument [8571,8593]
argument [8606,8628]
===
match
---
name: DagRun [8171,8177]
name: DagRun [8206,8212]
===
match
---
name: logical_date [9086,9098]
name: logical_date [9159,9171]
===
match
---
name: RESOURCE_DAG [6166,6178]
name: RESOURCE_DAG [6182,6194]
===
match
---
name: RESOURCE_DAG [7441,7453]
name: RESOURCE_DAG [7457,7469]
===
match
---
name: in_ [3884,3887]
name: in_ [3900,3903]
===
match
---
expr_stmt [4571,4777]
expr_stmt [4587,4793]
===
match
---
name: requires_access [7368,7383]
name: requires_access [7384,7399]
===
match
---
trailer [3898,3901]
trailer [3914,3917]
===
match
---
atom [2359,2418]
atom [2375,2434]
===
match
---
name: start_date_lte [5426,5440]
name: start_date_lte [5442,5456]
===
match
---
name: dag_run [10215,10222]
name: dag_run [10322,10329]
===
match
---
trailer [4821,4827]
trailer [4837,4843]
===
match
---
atom_expr [2022,2113]
atom_expr [2038,2129]
===
match
---
trailer [2142,2224]
trailer [2158,2240]
===
match
---
name: detail [9019,9025]
name: detail [9054,9060]
===
match
---
trailer [8945,8960]
trailer [8980,8995]
===
match
---
expr_stmt [6561,6622]
expr_stmt [6577,6638]
===
match
---
operator: = [8042,8043]
operator: = [8077,8078]
===
match
---
name: post_body [7802,7811]
name: post_body [7818,7827]
===
match
---
simple_stmt [1527,1571]
simple_stmt [1543,1587]
===
match
---
name: schemas [1357,1364]
name: schemas [1373,1380]
===
match
---
string: """Get all DAG Runs.""" [3626,3649]
string: """Get all DAG Runs.""" [3642,3665]
===
match
---
argument [9019,9116]
argument [9054,9222]
===
match
---
atom_expr [8895,8921]
atom_expr [8930,8956]
===
match
---
trailer [8111,8118]
trailer [8146,8153]
===
match
---
atom_expr [2360,2387]
atom_expr [2376,2403]
===
match
---
atom [9343,9402]
atom [9450,9509]
===
match
---
name: query [6643,6648]
name: query [6659,6664]
===
match
---
atom [7389,7532]
atom [7405,7548]
===
match
---
name: dag_id [2576,2582]
name: dag_id [2592,2598]
===
match
---
atom [2294,2349]
atom [2310,2365]
===
match
---
operator: = [9965,9966]
operator: = [10072,10073]
===
match
---
arglist [2559,2611]
arglist [2575,2627]
===
match
---
name: dag_id [8122,8128]
name: dag_id [8157,8163]
===
match
---
if_stmt [5902,5981]
if_stmt [5918,5997]
===
match
---
trailer [9384,9401]
trailer [9491,9508]
===
match
---
name: check_limit [3332,3343]
name: check_limit [3348,3359]
===
match
---
name: dag_bag [10030,10037]
name: dag_bag [10137,10144]
===
match
---
name: dag_id [7663,7669]
name: dag_id [7679,7685]
===
match
---
name: RESOURCE_DAG_RUN [3000,3016]
name: RESOURCE_DAG_RUN [3016,3032]
===
match
---
trailer [6986,7002]
trailer [7002,7018]
===
match
---
name: first [8230,8235]
name: first [8265,8270]
===
match
---
operator: , [2799,2800]
operator: , [2815,2816]
===
match
---
string: 'execution_date_lte' [3194,3214]
string: 'execution_date_lte' [3210,3230]
===
match
---
atom_expr [7148,7166]
atom_expr [7164,7182]
===
match
---
atom_expr [7048,7074]
atom_expr [7064,7090]
===
match
---
arglist [7713,7783]
arglist [7729,7799]
===
match
---
name: detail [9959,9965]
name: detail [10066,10072]
===
match
---
simple_stmt [6561,6623]
simple_stmt [6577,6639]
===
match
---
arglist [9609,9661]
arglist [9716,9768]
===
match
---
string: "end_date_lte" [6987,7001]
string: "end_date_lte" [7003,7017]
===
match
---
name: end_date_gte [4067,4079]
name: end_date_gte [4083,4095]
===
match
---
trailer [6672,6683]
trailer [6688,6699]
===
match
---
name: query [4571,4576]
name: query [4587,4592]
===
match
---
expr_stmt [5499,5556]
expr_stmt [5515,5572]
===
match
---
string: "id" [4920,4924]
string: "id" [4936,4940]
===
match
---
fstring_expr [2775,2787]
fstring_expr [2791,2803]
===
match
---
operator: , [5388,5389]
operator: , [5404,5405]
===
match
---
name: commit [10239,10245]
name: commit [10346,10352]
===
match
---
name: DagRun [6844,6850]
name: DagRun [6860,6866]
===
match
---
testlist_comp [7399,7526]
testlist_comp [7415,7542]
===
match
---
name: dag_run_schema [1365,1379]
name: dag_run_schema [1381,1395]
===
match
---
arglist [7833,7862]
arglist [7849,7878]
===
match
---
operator: , [8169,8170]
operator: , [8204,8205]
===
match
---
operator: } [2210,2211]
operator: } [2226,2227]
===
match
---
name: filter [3863,3869]
name: filter [3879,3885]
===
match
---
operator: , [8422,8423]
operator: , [8457,8458]
===
match
---
name: dagruns_batch_form_schema [1464,1489]
name: dagruns_batch_form_schema [1480,1505]
===
match
---
testlist_comp [1786,1913]
testlist_comp [1802,1929]
===
match
---
fstring [9159,9233]
fstring [9266,9340]
===
match
---
name: one_or_none [9663,9674]
name: one_or_none [9770,9781]
===
match
---
name: str [8913,8916]
name: str [8948,8951]
===
match
---
name: to_replace [5144,5154]
name: to_replace [5160,5170]
===
match
---
atom_expr [6534,6556]
atom_expr [6550,6572]
===
match
---
simple_stmt [6343,6369]
simple_stmt [6359,6385]
===
match
---
suite [10084,10164]
suite [10191,10271]
===
match
---
import_as_names [1267,1329]
import_as_names [1283,1345]
===
match
---
simple_stmt [9715,9784]
simple_stmt [9822,9891]
===
match
---
name: format_datetime [3298,3313]
name: format_datetime [3314,3329]
===
match
---
atom_expr [3888,3930]
atom_expr [3904,3946]
===
match
---
simple_stmt [10182,10252]
simple_stmt [10289,10359]
===
match
---
name: load [6419,6423]
name: load [6435,6439]
===
match
---
name: execution_date [10135,10149]
name: execution_date [10242,10256]
===
match
---
trailer [7653,7680]
trailer [7669,7696]
===
match
---
operator: , [4205,4206]
operator: , [4221,4222]
===
match
---
name: permissions [2389,2400]
name: permissions [2405,2416]
===
match
---
return_stmt [8809,8843]
return_stmt [8844,8878]
===
match
---
expr_stmt [5810,5875]
expr_stmt [5826,5891]
===
match
---
trailer [9969,9974]
trailer [10076,10081]
===
match
---
tfpdef [9454,9465]
tfpdef [9561,9572]
===
match
---
atom [6124,6179]
atom [6140,6195]
===
match
---
atom_expr [3870,3931]
atom_expr [3886,3947]
===
match
---
argument [7847,7862]
argument [7863,7878]
===
match
---
name: utils [1675,1680]
name: utils [1691,1696]
===
match
---
expr_stmt [6886,7247]
expr_stmt [6902,7263]
===
match
---
param [1978,1985]
param [1994,2001]
===
match
---
name: first [7681,7686]
name: first [7697,7702]
===
match
---
comparison [5609,5644]
comparison [5625,5660]
===
match
---
if_stmt [9687,9822]
if_stmt [9794,9929]
===
match
---
name: get [8770,8773]
name: get [8805,8808]
===
match
---
name: connexion [945,954]
name: connexion [961,970]
===
match
---
operator: = [5715,5716]
operator: = [5731,5732]
===
match
---
atom_expr [7429,7453]
atom_expr [7445,7469]
===
match
---
name: filter [7647,7653]
name: filter [7663,7669]
===
match
---
name: RESOURCE_DAG_RUN [2401,2417]
name: RESOURCE_DAG_RUN [2417,2433]
===
match
---
expr_stmt [9542,9682]
expr_stmt [9649,9789]
===
match
---
name: get_dag_runs_batch [6279,6297]
name: get_dag_runs_batch [6295,6313]
===
match
---
name: dag_id [2566,2572]
name: dag_id [2582,2588]
===
match
---
operator: @ [2253,2254]
operator: @ [2269,2270]
===
match
---
testlist_comp [2959,3016]
testlist_comp [2975,3032]
===
match
---
string: "start_date_lte" [7121,7137]
string: "start_date_lte" [7137,7153]
===
match
---
name: dag_id [9616,9622]
name: dag_id [9723,9729]
===
match
---
name: ve [8917,8919]
name: ve [8952,8954]
===
match
---
operator: = [4577,4578]
operator: = [4593,4594]
===
match
---
number: 0 [2117,2118]
number: 0 [2133,2134]
===
match
---
comparison [5520,5555]
comparison [5536,5571]
===
match
---
name: experimental [996,1008]
name: experimental [1012,1024]
===
match
---
name: logical_date [8196,8208]
name: logical_date [8231,8243]
===
match
---
decorated [9237,10343]
decorated [9344,10450]
===
match
---
name: security [6084,6092]
name: security [6100,6108]
===
match
---
trailer [6836,6843]
trailer [6852,6859]
===
match
---
name: DagRun [6031,6037]
name: DagRun [6047,6053]
===
match
---
trailer [6769,6776]
trailer [6785,6792]
===
match
---
name: dag_id [6851,6857]
name: dag_id [6867,6873]
===
match
---
operator: == [2065,2067]
operator: == [2081,2083]
===
match
---
name: dag_run [4002,4009]
name: dag_run [4018,4025]
===
match
---
name: end_date_gte [5905,5917]
name: end_date_gte [5921,5933]
===
match
---
atom_expr [2894,2921]
atom_expr [2910,2937]
===
match
---
operator: , [8209,8210]
operator: , [8244,8245]
===
match
---
name: flask [819,824]
name: flask [835,840]
===
match
---
name: dag_id [9775,9781]
name: dag_id [9882,9888]
===
match
---
comparison [2559,2582]
comparison [2575,2598]
===
match
---
operator: = [8529,8530]
operator: = [8564,8565]
===
match
---
operator: , [4057,4058]
operator: , [4073,4074]
===
match
---
name: api_connexion [1154,1167]
name: api_connexion [1170,1183]
===
match
---
operator: == [9648,9650]
operator: == [9755,9757]
===
match
---
name: ACTION_CAN_DELETE [1864,1881]
name: ACTION_CAN_DELETE [1880,1897]
===
match
---
atom_expr [10093,10163]
atom_expr [10200,10270]
===
match
---
name: end_date_lte [4089,4101]
name: end_date_lte [4105,4117]
===
match
---
name: current_app [6534,6545]
name: current_app [6550,6561]
===
match
---
name: format_datetime [3216,3231]
name: format_datetime [3232,3247]
===
match
---
atom_expr [5948,5963]
atom_expr [5964,5979]
===
match
---
return_stmt [4267,4368]
return_stmt [4283,4384]
===
match
---
decorator [9237,9412]
decorator [9344,9519]
===
match
---
param [5426,5440]
param [5442,5456]
===
match
---
trailer [5519,5556]
trailer [5535,5572]
===
match
---
atom_expr [4304,4367]
atom_expr [4320,4383]
===
match
---
operator: , [9465,9466]
operator: , [9572,9573]
===
match
---
name: set_dagrun_state_form_schema [9851,9879]
name: set_dagrun_state_form_schema [9958,9986]
===
match
---
name: allowed_filter_attrs [4887,4907]
name: allowed_filter_attrs [4903,4923]
===
match
---
name: str [9966,9969]
name: str [10073,10076]
===
match
---
atom_expr [2134,2224]
atom_expr [2150,2240]
===
match
---
operator: = [9849,9850]
operator: = [9956,9957]
===
match
---
simple_stmt [9981,10008]
simple_stmt [10088,10115]
===
match
---
operator: , [2705,2706]
operator: , [2721,2722]
===
match
---
expr_stmt [6823,6880]
expr_stmt [6839,6896]
===
match
---
operator: , [5132,5133]
operator: , [5148,5149]
===
match
---
fstring_expr [9208,9216]
fstring_expr [9315,9323]
===
match
---
name: format_parameters [3028,3045]
name: format_parameters [3044,3061]
===
match
---
trailer [9587,9593]
trailer [9694,9700]
===
match
---
name: session [6635,6642]
name: session [6651,6658]
===
match
---
name: dag_id [2461,2467]
name: dag_id [2477,2483]
===
match
---
string: """Set a state of a dag run.""" [9506,9537]
string: """Set a state of a dag run.""" [9613,9644]
===
match
---
operator: = [8708,8709]
operator: = [8743,8744]
===
match
---
atom_expr [6952,6972]
atom_expr [6968,6988]
===
match
---
string: "start_date" [5017,5029]
string: "start_date" [5033,5045]
===
match
---
atom_expr [10070,10083]
atom_expr [10177,10190]
===
match
---
name: detail [2719,2725]
name: detail [2735,2741]
===
match
---
name: query [5818,5823]
name: query [5834,5839]
===
match
---
name: permissions [9344,9355]
name: permissions [9451,9462]
===
match
---
simple_stmt [3849,3933]
simple_stmt [3865,3949]
===
match
---
fstring_string: ' and DagRun ID: ' [2757,2775]
fstring_string: ' and DagRun ID: ' [2773,2791]
===
match
---
argument [8906,8920]
argument [8941,8955]
===
match
---
name: dump [10329,10333]
name: dump [10436,10440]
===
match
---
name: query [4816,4821]
name: query [4832,4837]
===
match
---
name: set_dag_run_state_to_success [10093,10121]
name: set_dag_run_state_to_success [10200,10228]
===
match
---
trailer [6927,7247]
trailer [6943,7263]
===
match
---
operator: , [1976,1977]
operator: , [1992,1993]
===
match
---
name: DagRun [2544,2550]
name: DagRun [2560,2566]
===
match
---
atom_expr [2076,2089]
atom_expr [2092,2105]
===
match
---
name: session [3392,3399]
name: session [3408,3415]
===
match
---
expr_stmt [6693,6747]
expr_stmt [6709,6763]
===
match
---
name: limit [5242,5247]
name: limit [5258,5263]
===
match
---
operator: { [2749,2750]
operator: { [2765,2766]
===
match
---
param [4425,4438]
param [4441,4454]
===
match
---
and_expr [6703,6747]
and_expr [6719,6763]
===
match
---
operator: , [1439,1440]
operator: , [1455,1456]
===
match
---
name: query [5507,5512]
name: query [5523,5528]
===
match
---
name: dag_run [2520,2527]
name: dag_run [2536,2543]
===
match
---
name: api_connexion [1235,1248]
name: api_connexion [1251,1264]
===
match
---
trailer [6706,6723]
trailer [6722,6739]
===
match
---
operator: & [6724,6725]
operator: & [6740,6741]
===
match
---
if_stmt [10058,10252]
if_stmt [10165,10359]
===
match
---
trailer [8751,8759]
trailer [8786,8794]
===
match
---
name: DagRun [6649,6655]
name: DagRun [6665,6671]
===
match
---
name: in_ [6791,6794]
name: in_ [6807,6810]
===
match
---
trailer [1863,1881]
trailer [1879,1897]
===
match
---
name: load [7828,7832]
name: load [7844,7848]
===
match
---
expr_stmt [5927,5980]
expr_stmt [5943,5996]
===
match
---
atom [1851,1912]
atom [1867,1928]
===
match
---
name: query [4052,4057]
name: query [4068,4073]
===
match
---
decorators [1745,1939]
decorators [1761,1955]
===
match
---
testlist [2236,2250]
testlist [2252,2266]
===
match
---
name: dag_id [6784,6790]
name: dag_id [6800,6806]
===
match
---
trailer [5608,5645]
trailer [5624,5661]
===
match
---
simple_stmt [785,813]
simple_stmt [785,813]
===
match
---
operator: = [4814,4815]
operator: = [4830,4831]
===
match
---
operator: = [3957,3958]
operator: = [3973,3974]
===
match
---
simple_stmt [7907,7941]
simple_stmt [7923,7957]
===
match
---
operator: { [9744,9745]
operator: { [9851,9852]
===
match
---
operator: = [7213,7214]
operator: = [7229,7230]
===
match
---
trailer [9608,9662]
trailer [9715,9769]
===
match
---
name: DagRun [10280,10286]
name: DagRun [10387,10393]
===
match
---
name: dag_id [9050,9056]
name: dag_id [9103,9109]
===
match
---
testlist_comp [4920,5094]
testlist_comp [4936,5110]
===
match
---
trailer [2551,2558]
trailer [2567,2574]
===
match
---
atom [2958,3017]
atom [2974,3033]
===
match
---
name: session [7577,7584]
name: session [7593,7600]
===
match
---
atom_expr [1852,1881]
atom_expr [1868,1897]
===
match
---
name: id [10300,10302]
name: id [10407,10409]
===
match
---
name: permissions [9308,9319]
name: permissions [9415,9426]
===
match
---
operator: = [5816,5817]
operator: = [5832,5833]
===
match
---
fstring_end: " [9232,9233]
fstring_end: " [9339,9340]
===
match
---
argument [7713,7734]
argument [7729,7750]
===
match
---
argument [8396,8422]
argument [8431,8457]
===
match
---
funcdef [4371,5295]
funcdef [4387,5311]
===
match
---
trailer [9319,9332]
trailer [9426,9439]
===
match
---
trailer [2035,2043]
trailer [2051,2059]
===
match
---
name: format_datetime [3122,3137]
name: format_datetime [3138,3153]
===
match
---
name: query [5709,5714]
name: query [5725,5730]
===
match
---
name: DagRun [2076,2082]
name: DagRun [2092,2098]
===
match
---
funcdef [3370,4369]
funcdef [3386,4385]
===
match
---
param [3442,3462]
param [3458,3478]
===
match
---
testlist_comp [9344,9401]
testlist_comp [9451,9508]
===
match
---
trailer [8330,8338]
trailer [8365,8373]
===
match
---
expr_stmt [5105,5177]
expr_stmt [5121,5193]
===
match
---
arglist [2051,2103]
arglist [2067,2119]
===
match
---
trailer [5830,5875]
trailer [5846,5891]
===
match
---
operator: } [2756,2757]
operator: } [2772,2773]
===
match
---
simple_stmt [7993,8022]
simple_stmt [8028,8057]
===
match
---
trailer [5837,5852]
trailer [5853,5868]
===
match
---
name: requires_access [2862,2877]
name: requires_access [2878,2893]
===
match
---
trailer [2970,2986]
trailer [2986,3002]
===
match
---
operator: , [1964,1965]
operator: , [1980,1981]
===
match
---
operator: = [4329,4330]
operator: = [4345,4346]
===
match
---
name: session [1631,1638]
name: session [1647,1654]
===
match
---
expr_stmt [6343,6368]
expr_stmt [6359,6384]
===
match
---
name: query [2030,2035]
name: query [2046,2051]
===
match
---
atom_expr [10127,10149]
atom_expr [10234,10256]
===
match
---
name: DAGRunCollection [4304,4320]
name: DAGRunCollection [4320,4336]
===
match
---
arglist [7223,7239]
arglist [7239,7255]
===
match
---
name: query [6823,6828]
name: query [6839,6844]
===
match
---
name: MANUAL [8416,8422]
name: MANUAL [8451,8457]
===
match
---
name: g [845,846]
name: g [861,862]
===
match
---
fstring_string: ' not found [2211,2222]
fstring_string: ' not found [2227,2238]
===
match
---
trailer [7120,7138]
trailer [7136,7154]
===
match
---
atom_expr [5520,5537]
atom_expr [5536,5553]
===
match
---
expr_stmt [8351,8796]
expr_stmt [8386,8831]
===
match
---
atom_expr [7833,7845]
atom_expr [7849,7861]
===
match
---
name: permissions [2295,2306]
name: permissions [2311,2322]
===
match
---
simple_stmt [6693,6748]
simple_stmt [6709,6764]
===
match
---
atom [8044,8243]
atom [8079,8278]
===
match
---
name: execution_date_gte [5681,5699]
name: execution_date_gte [5697,5715]
===
match
---
name: ACTION_CAN_EDIT [1799,1814]
name: ACTION_CAN_EDIT [1815,1830]
===
match
---
operator: = [8652,8653]
operator: = [8687,8688]
===
match
---
name: dump [2836,2840]
name: dump [2852,2856]
===
match
---
simple_stmt [3626,3650]
simple_stmt [3642,3666]
===
match
---
name: exceptions [1168,1178]
name: exceptions [1184,1194]
===
match
---
suite [9830,9899]
suite [9937,10006]
===
match
---
operator: { [9049,9050]
operator: { [9102,9103]
===
match
---
name: SUCCESS [10076,10083]
name: SUCCESS [10183,10190]
===
match
---
name: permissions [6219,6230]
name: permissions [6235,6246]
===
match
---
name: BadRequest [6479,6489]
name: BadRequest [6495,6505]
===
match
---
trailer [3876,3883]
trailer [3892,3899]
===
match
---
name: dagrun_collection_schema [4274,4298]
name: dagrun_collection_schema [4290,4314]
===
match
---
name: dump [4299,4303]
name: dump [4315,4319]
===
match
---
trailer [5226,5233]
trailer [5242,5249]
===
match
---
funcdef [5297,6081]
funcdef [5313,6097]
===
match
---
simple_stmt [972,1098]
simple_stmt [988,1114]
===
match
---
trailer [7289,7355]
trailer [7305,7371]
===
match
---
operator: { [2775,2776]
operator: { [2791,2792]
===
match
---
name: ACTION_CAN_READ [2906,2921]
name: ACTION_CAN_READ [2922,2937]
===
match
---
operator: , [1060,1061]
operator: , [1076,1077]
===
match
---
name: DagRun [3870,3876]
name: DagRun [3886,3892]
===
match
---
name: dag_id [3782,3788]
name: dag_id [3798,3804]
===
match
---
operator: = [9158,9159]
operator: = [9265,9266]
===
match
---
atom [9570,9682]
atom [9677,9789]
===
match
---
name: state [8612,8617]
name: state [8647,8652]
===
match
---
name: dag_id [7764,7770]
name: dag_id [7780,7786]
===
match
---
trailer [9958,9975]
trailer [10065,10082]
===
match
---
atom_expr [6615,6621]
atom_expr [6631,6637]
===
match
---
trailer [8759,8769]
trailer [8794,8804]
===
match
---
string: "dag_ids" [6673,6682]
string: "dag_ids" [6689,6698]
===
match
---
testlist_comp [2295,2348]
testlist_comp [2311,2364]
===
match
---
name: str [9479,9482]
name: str [9586,9589]
===
match
---
atom_expr [8992,9126]
atom_expr [9027,9233]
===
match
---
atom_expr [2988,3016]
atom_expr [3004,3032]
===
match
---
atom_expr [5507,5556]
atom_expr [5523,5572]
===
match
---
name: current_app [832,843]
name: current_app [848,859]
===
match
---
atom_expr [2822,2849]
atom_expr [2838,2865]
===
match
---
trailer [4607,4777]
trailer [4623,4793]
===
match
---
decorator [7535,7552]
decorator [7551,7568]
===
match
---
name: execution_date [8471,8485]
name: execution_date [8506,8520]
===
match
---
trailer [8229,8235]
trailer [8264,8270]
===
match
---
name: total_entries [5281,5294]
name: total_entries [5297,5310]
===
match
---
operator: , [4622,4623]
operator: , [4638,4639]
===
match
---
operator: , [4746,4747]
operator: , [4762,4763]
===
match
---
simple_stmt [924,972]
simple_stmt [940,988]
===
match
---
testlist_comp [7400,7453]
testlist_comp [7416,7469]
===
match
---
name: execution_date_gte [5370,5388]
name: execution_date_gte [5386,5404]
===
match
---
operator: = [5933,5934]
operator: = [5949,5950]
===
match
---
suite [8977,9127]
suite [9012,9234]
===
match
---
name: sqlalchemy [901,911]
name: sqlalchemy [917,927]
===
match
---
name: end_date_gte [4407,4419]
name: end_date_gte [4423,4435]
===
match
---
simple_stmt [6473,6516]
simple_stmt [6489,6532]
===
match
---
operator: , [5340,5341]
operator: , [5356,5357]
===
match
---
trailer [8834,8843]
trailer [8869,8878]
===
match
---
atom_expr [7496,7524]
atom_expr [7512,7540]
===
match
---
atom_expr [2324,2348]
atom_expr [2340,2364]
===
match
---
argument [10151,10162]
argument [10258,10269]
===
match
---
import_from [856,895]
import_from [872,911]
===
match
---
trailer [6136,6152]
trailer [6152,6168]
===
match
---
name: filter [9602,9608]
name: filter [9709,9715]
===
match
---
operator: , [4666,4667]
operator: , [4682,4683]
===
match
---
simple_stmt [1992,2015]
simple_stmt [2008,2031]
===
match
---
fstring_string: ' already exists [9099,9115]
fstring_string: ' already exists [9191,9207]
===
match
---
raise_stmt [7907,7940]
raise_stmt [7923,7956]
===
match
---
name: detail [9152,9158]
name: detail [9259,9265]
===
match
---
operator: , [6972,6973]
operator: , [6988,6989]
===
match
---
simple_stmt [4887,5101]
simple_stmt [4903,5117]
===
match
---
operator: , [5354,5355]
operator: , [5370,5371]
===
match
---
name: appbuilder [6546,6556]
name: appbuilder [6562,6572]
===
match
---
name: g [3923,3924]
name: g [3939,3940]
===
match
---
atom [4858,4882]
atom [4874,4898]
===
match
---
trailer [5615,5626]
trailer [5631,5642]
===
match
---
simple_stmt [1612,1662]
simple_stmt [1628,1678]
===
match
---
fstring_end: " [9115,9116]
fstring_end: " [9207,9208]
===
match
---
operator: , [4525,4526]
operator: , [4541,4542]
===
match
---
trailer [3829,3840]
trailer [3845,3856]
===
match
---
simple_stmt [7802,7864]
simple_stmt [7818,7880]
===
match
---
operator: , [1489,1490]
operator: , [1505,1506]
===
match
---
fstring_expr [9182,9190]
fstring_expr [9289,9297]
===
match
---
trailer [8773,8781]
trailer [8808,8816]
===
match
---
operator: , [6152,6153]
operator: , [6168,6169]
===
match
---
simple_stmt [1662,1700]
simple_stmt [1678,1716]
===
match
---
name: dag [8297,8300]
name: dag [8332,8335]
===
match
---
operator: , [7166,7167]
operator: , [7182,7183]
===
match
---
except_clause [7868,7897]
except_clause [7884,7913]
===
match
---
trailer [5601,5608]
trailer [5617,5624]
===
match
---
atom_expr [2559,2572]
atom_expr [2575,2588]
===
match
---
trailer [8314,8322]
trailer [8349,8357]
===
match
---
operator: == [9623,9625]
operator: == [9730,9732]
===
match
---
string: "DAG not found" [7719,7734]
string: "DAG not found" [7735,7750]
===
match
---
name: get [8663,8666]
name: get [8698,8701]
===
match
---
trailer [4298,4303]
trailer [4314,4319]
===
match
---
name: ValidationError [7875,7890]
name: ValidationError [7891,7906]
===
match
---
atom [7464,7525]
atom [7480,7541]
===
match
---
decorators [2852,3370]
decorators [2868,3386]
===
match
---
trailer [10209,10251]
trailer [10316,10358]
===
match
---
name: dag_id [3989,3995]
name: dag_id [4005,4011]
===
match
---
argument [4339,4366]
argument [4355,4382]
===
match
---
trailer [7016,7038]
trailer [7032,7054]
===
match
---
trailer [8916,8920]
trailer [8951,8955]
===
match
---
name: DagRun [8105,8111]
name: DagRun [8140,8146]
===
match
---
atom_expr [2530,2626]
atom_expr [2546,2642]
===
match
---
arglist [10210,10250]
arglist [10317,10357]
===
match
---
decorators [6083,6275]
decorators [6099,6291]
===
match
---
comparison [10061,10083]
comparison [10168,10190]
===
match
---
name: dump [8830,8834]
name: dump [8865,8869]
===
match
---
name: dagrun_collection_schema [1415,1439]
name: dagrun_collection_schema [1431,1455]
===
match
---
operator: , [1912,1913]
operator: , [1928,1929]
===
match
---
operator: @ [1745,1746]
operator: @ [1761,1762]
===
match
---
trailer [1894,1911]
trailer [1910,1927]
===
match
---
number: 204 [2247,2250]
number: 204 [2263,2266]
===
match
---
simple_stmt [5588,5646]
simple_stmt [5604,5662]
===
match
---
name: infer_manual_data_interval [8544,8570]
name: infer_manual_data_interval [8579,8605]
===
match
---
name: or_ [8142,8145]
name: or_ [8177,8180]
===
match
---
trailer [7923,7940]
trailer [7939,7956]
===
match
---
name: dag_run [10127,10134]
name: dag_run [10234,10241]
===
match
---
decorator [3027,3353]
decorator [3043,3369]
===
match
---
decorator [1922,1939]
decorator [1938,1955]
===
match
---
trailer [8378,8796]
trailer [8413,8831]
===
match
---
name: airflow [1335,1342]
name: airflow [1351,1358]
===
match
---
operator: { [9182,9183]
operator: { [9289,9290]
===
match
---
import_from [1700,1742]
import_from [1716,1758]
===
match
---
operator: <= [6047,6049]
operator: <= [6063,6065]
===
match
---
name: execution_date_lte [4704,4722]
name: execution_date_lte [4720,4738]
===
match
---
string: """Get list of DAG Runs""" [6312,6338]
string: """Get list of DAG Runs""" [6328,6354]
===
match
---
expr_stmt [3805,3840]
expr_stmt [3821,3856]
===
match
---
operator: , [7734,7735]
operator: , [7750,7751]
===
match
---
operator: , [3461,3462]
operator: , [3477,3478]
===
match
---
operator: <= [5627,5629]
operator: <= [5643,5645]
===
match
---
name: permissions [2988,2999]
name: permissions [3004,3015]
===
match
---
operator: { [2173,2174]
operator: { [2189,2190]
===
match
---
name: dag_run [2634,2641]
name: dag_run [2650,2657]
===
match
---
expr_stmt [3849,3932]
expr_stmt [3865,3948]
===
match
---
simple_stmt [5211,5261]
simple_stmt [5227,5277]
===
match
---
import_from [972,1097]
import_from [988,1113]
===
match
---
trailer [9998,10007]
trailer [10105,10114]
===
match
---
operator: , [4181,4182]
operator: , [4197,4198]
===
match
---
expr_stmt [9981,10007]
expr_stmt [10088,10114]
===
match
---
name: DagRun [5948,5954]
name: DagRun [5964,5970]
===
match
---
trailer [6023,6030]
trailer [6039,6046]
===
match
---
atom_expr [9138,9234]
atom_expr [9245,9341]
===
match
---
trailer [6545,6556]
trailer [6561,6572]
===
match
---
name: str [6497,6500]
name: str [6513,6516]
===
match
---
name: get [6669,6672]
name: get [6685,6688]
===
match
---
name: dag_run_id [2093,2103]
name: dag_run_id [2109,2119]
===
insert-tree
---
simple_stmt [814,830]
    import_name [814,829]
        name: pendulum [821,829]
to
file_input [785,10343]
at 1
===
insert-node
---
atom_expr [7977,8023]
to
expr_stmt [7946,7988]
at 2
===
insert-node
---
trailer [7994,8023]
to
atom_expr [7977,8023]
at 2
===
move-tree
---
atom_expr [7961,7988]
    name: post_body [7961,7970]
    trailer [7970,7988]
        string: "execution_date" [7971,7987]
to
trailer [7994,8023]
at 0
===
insert-node
---
arglist [9054,9223]
to
trailer [9005,9126]
at 0
===
move-tree
---
argument [9019,9116]
    name: detail [9019,9025]
    operator: = [9025,9026]
    fstring [9026,9116]
        fstring_start: f" [9026,9028]
        fstring_string: DAGRun with DAG ID: ' [9028,9049]
        fstring_expr [9049,9057]
            operator: { [9049,9050]
            name: dag_id [9050,9056]
            operator: } [9056,9057]
        fstring_string: ' and DAGRun logical date: ' [9057,9085]
        fstring_expr [9085,9099]
            operator: { [9085,9086]
            name: logical_date [9086,9098]
            operator: } [9098,9099]
        fstring_string: ' already exists [9099,9115]
        fstring_end: " [9115,9116]
to
arglist [9054,9223]
at 0
===
insert-node
---
atom [9061,9222]
to
argument [9019,9116]
at 2
===
insert-node
---
strings [9079,9208]
to
atom [9061,9222]
at 0
===
insert-node
---
fstring [9079,9117]
to
strings [9079,9208]
at 0
===
insert-node
---
fstring [9134,9208]
to
strings [9079,9208]
at 1
===
move-tree
---
fstring_start: f" [9026,9028]
to
fstring [9079,9117]
at 0
===
move-tree
---
fstring_string: DAGRun with DAG ID: ' [9028,9049]
to
fstring [9079,9117]
at 1
===
move-tree
---
fstring_expr [9049,9057]
    operator: { [9049,9050]
    name: dag_id [9050,9056]
    operator: } [9056,9057]
to
fstring [9079,9117]
at 2
===
update-node
---
fstring_string: ' and DAGRun logical date: ' [9057,9085]
replace ' and DAGRun logical date: ' by DAGRun logical date: '
===
move-tree
---
fstring_string: ' and DAGRun logical date: ' [9057,9085]
to
fstring [9134,9208]
at 1
===
move-tree
---
fstring_expr [9085,9099]
    operator: { [9085,9086]
    name: logical_date [9086,9098]
    operator: } [9098,9099]
to
fstring [9134,9208]
at 2
===
move-tree
---
fstring_string: ' already exists [9099,9115]
to
fstring [9134,9208]
at 3
===
move-tree
---
fstring_end: " [9115,9116]
to
fstring [9134,9208]
at 4
===
insert-node
---
atom_expr [9159,9190]
to
fstring_expr [9085,9099]
at 1
===
move-tree
---
name: logical_date [9086,9098]
to
atom_expr [9159,9190]
at 0
===
delete-node
---
fstring [9026,9116]
===
