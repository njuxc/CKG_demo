===
match
---
funcdef [18193,18465]
funcdef [18249,18521]
===
match
---
simple_stmt [7001,7034]
simple_stmt [7057,7090]
===
match
---
testlist_comp [17231,17241]
testlist_comp [17287,17297]
===
match
---
argument [7080,7087]
argument [7136,7143]
===
match
---
name: self [15011,15015]
name: self [15067,15071]
===
match
---
trailer [7129,7139]
trailer [7185,7195]
===
match
---
expr_stmt [12521,12624]
expr_stmt [12577,12680]
===
match
---
atom_expr [13671,13715]
atom_expr [13727,13771]
===
match
---
return_stmt [15483,15536]
return_stmt [15539,15592]
===
match
---
expr_stmt [4375,4447]
expr_stmt [4431,4503]
===
match
---
name: dagbag [6401,6407]
name: dagbag [6457,6463]
===
match
---
atom_expr [11820,11878]
atom_expr [11876,11934]
===
match
---
name: self [16545,16549]
name: self [16601,16605]
===
match
---
operator: = [10995,10996]
operator: = [11051,11052]
===
match
---
atom_expr [11103,11134]
atom_expr [11159,11190]
===
match
---
trailer [17987,17997]
trailer [18043,18053]
===
match
---
trailer [4053,4062]
trailer [4109,4118]
===
match
---
operator: , [11259,11260]
operator: , [11315,11316]
===
match
---
name: response [12441,12449]
name: response [12497,12505]
===
match
---
name: i [16380,16381]
name: i [16436,16437]
===
match
---
expr_stmt [4949,5035]
expr_stmt [5005,5091]
===
match
---
string: 'true' [2434,2440]
string: 'true' [2434,2440]
===
match
---
name: loads [16006,16011]
name: loads [16062,16067]
===
match
---
trailer [14938,14940]
trailer [14994,14996]
===
match
---
trailer [11542,11560]
trailer [11598,11616]
===
match
---
operator: , [9696,9697]
operator: , [9752,9753]
===
match
---
trailer [14510,14514]
trailer [14566,14570]
===
match
---
trailer [6068,6078]
trailer [6124,6134]
===
match
---
atom_expr [10362,10382]
atom_expr [10418,10438]
===
match
---
name: execution_date [13279,13293]
name: execution_date [13335,13349]
===
match
---
assert_stmt [18049,18120]
assert_stmt [18105,18176]
===
match
---
atom_expr [11484,11528]
atom_expr [11540,11584]
===
match
---
name: self [15896,15900]
name: self [15952,15956]
===
match
---
operator: = [8928,8929]
operator: = [8984,8985]
===
match
---
parameters [1912,1918]
parameters [1912,1918]
===
match
---
name: response [3897,3905]
name: response [3953,3961]
===
match
---
trailer [15266,15272]
trailer [15322,15328]
===
match
---
trailer [17694,17701]
trailer [17750,17757]
===
match
---
operator: , [18314,18315]
operator: , [18370,18371]
===
match
---
trailer [6494,6505]
trailer [6550,6561]
===
match
---
assert_stmt [13868,13919]
assert_stmt [13924,13975]
===
match
---
assert_stmt [16454,16492]
assert_stmt [16510,16548]
===
match
---
trailer [1988,1999]
trailer [1988,1999]
===
match
---
name: session [3104,3111]
name: session [3160,3167]
===
match
---
operator: == [14354,14356]
operator: == [14410,14412]
===
match
---
operator: == [4679,4681]
operator: == [4735,4737]
===
match
---
name: pool [16461,16465]
name: pool [16517,16521]
===
match
---
number: 200 [5244,5247]
number: 200 [5300,5303]
===
match
---
name: json [8641,8645]
name: json [8697,8701]
===
match
---
atom [16647,16772]
atom [16703,16828]
===
match
---
trailer [15601,15669]
trailer [15657,15725]
===
match
---
name: dagbag [2916,2922]
name: dagbag [2972,2978]
===
match
---
name: session [2754,2761]
name: session [2810,2817]
===
match
---
atom_expr [2059,2101]
atom_expr [2059,2101]
===
match
---
import_name [787,798]
import_name [787,798]
===
match
---
atom_expr [11912,11932]
atom_expr [11968,11988]
===
match
---
atom_expr [11161,11199]
atom_expr [11217,11255]
===
match
---
name: decode [11654,11660]
name: decode [11710,11716]
===
match
---
trailer [10290,10338]
trailer [10346,10394]
===
match
---
dotted_name [1440,1467]
dotted_name [1440,1467]
===
match
---
simple_stmt [17965,17998]
simple_stmt [18021,18054]
===
match
---
name: data [10172,10176]
name: data [10228,10232]
===
match
---
trailer [8342,8350]
trailer [8398,8406]
===
match
---
operator: == [17644,17646]
operator: == [17700,17702]
===
match
---
name: decode [5472,5478]
name: decode [5528,5534]
===
match
---
comparison [14393,14433]
comparison [14449,14489]
===
match
---
trailer [17774,17790]
trailer [17830,17846]
===
match
---
dotted_name [1393,1412]
dotted_name [1393,1412]
===
match
---
name: DagBag [8305,8311]
name: DagBag [8361,8367]
===
match
---
expr_stmt [10244,10339]
expr_stmt [10300,10395]
===
match
---
simple_stmt [4561,4596]
simple_stmt [4617,4652]
===
match
---
expr_stmt [7001,7033]
expr_stmt [7057,7089]
===
match
---
comparison [4022,4062]
comparison [4078,4118]
===
match
---
operator: = [13294,13295]
operator: = [13350,13351]
===
match
---
name: url_template [11484,11496]
name: url_template [11540,11552]
===
match
---
atom_expr [17070,17089]
atom_expr [17126,17145]
===
match
---
decorator [1755,1899]
decorator [1755,1899]
===
match
---
atom [1818,1892]
atom [1818,1892]
===
match
---
string: "application/json" [7365,7383]
string: "application/json" [7421,7439]
===
match
---
name: appbuilder [2011,2021]
name: appbuilder [2011,2021]
===
match
---
number: 1 [11261,11262]
number: 1 [11317,11318]
===
match
---
operator: == [16343,16345]
operator: == [16399,16401]
===
match
---
trailer [17888,17956]
trailer [17944,18012]
===
match
---
operator: = [2262,2263]
operator: = [2262,2263]
===
match
---
name: DagRun [1061,1067]
name: DagRun [1061,1067]
===
match
---
exprlist [16380,16387]
exprlist [16436,16443]
===
match
---
trailer [17689,17694]
trailer [17745,17750]
===
match
---
trailer [14157,14162]
trailer [14213,14218]
===
match
---
simple_stmt [6575,6603]
simple_stmt [6631,6659]
===
match
---
name: response [17623,17631]
name: response [17679,17687]
===
match
---
operator: , [13569,13570]
operator: , [13625,13626]
===
match
---
name: app [2231,2234]
name: app [2231,2234]
===
match
---
suite [3561,4276]
suite [3617,4332]
===
match
---
simple_stmt [3631,3715]
simple_stmt [3687,3771]
===
match
---
operator: == [11909,11911]
operator: == [11965,11967]
===
match
---
name: client [18555,18561]
name: client [18611,18617]
===
match
---
trailer [3022,3024]
trailer [3078,3080]
===
match
---
name: pool [15231,15235]
name: pool [15287,15291]
===
match
---
name: response [15505,15513]
name: response [15561,15569]
===
match
---
operator: = [11789,11790]
operator: = [11845,11846]
===
match
---
trailer [16430,16438]
trailer [16486,16494]
===
match
---
name: key [16415,16418]
name: key [16471,16474]
===
match
---
name: get [13993,13996]
name: get [14049,14052]
===
match
---
name: pool [15118,15122]
name: pool [15174,15178]
===
match
---
name: test_trigger_dag [5706,5722]
name: test_trigger_dag [5762,5778]
===
match
---
simple_stmt [14613,14661]
simple_stmt [14669,14717]
===
match
---
trailer [3653,3657]
trailer [3709,3713]
===
match
---
operator: , [7383,7384]
operator: , [7439,7440]
===
match
---
name: wrong_datetime_string [12121,12142]
name: wrong_datetime_string [12177,12198]
===
match
---
name: session [2891,2898]
name: session [2947,2954]
===
match
---
atom_expr [6742,6783]
atom_expr [6798,6839]
===
match
---
arglist [17902,17946]
arglist [17958,18002]
===
match
---
simple_stmt [9873,9925]
simple_stmt [9929,9981]
===
match
---
name: name [15182,15186]
name: name [15238,15242]
===
match
---
trailer [18721,18730]
trailer [18777,18786]
===
match
---
operator: = [15894,15895]
operator: = [15950,15951]
===
match
---
operator: , [4167,4168]
operator: , [4223,4224]
===
match
---
comparison [18384,18464]
comparison [18440,18520]
===
match
---
import_from [929,957]
import_from [929,957]
===
match
---
name: serialized_dag [1108,1122]
name: serialized_dag [1108,1122]
===
match
---
operator: } [7764,7765]
operator: } [7820,7821]
===
match
---
trailer [10772,10779]
trailer [10828,10835]
===
match
---
string: 'true' [1742,1748]
string: 'true' [1742,1748]
===
match
---
operator: == [17012,17014]
operator: == [17068,17070]
===
match
---
name: include_examples [2932,2948]
name: include_examples [2988,3004]
===
match
---
operator: , [15658,15659]
operator: , [15714,15715]
===
match
---
operator: == [5606,5608]
operator: == [5662,5664]
===
match
---
name: airflow [1268,1275]
name: airflow [1268,1275]
===
match
---
name: delete [18265,18271]
name: delete [18321,18327]
===
match
---
operator: = [6007,6008]
operator: = [6063,6064]
===
match
---
simple_stmt [13279,13328]
simple_stmt [13335,13384]
===
match
---
atom_expr [5358,5434]
atom_expr [5414,5490]
===
match
---
string: 'state' [9824,9831]
string: 'state' [9880,9887]
===
match
---
string: "airflow.settings.DAGS_FOLDER" [13079,13109]
string: "airflow.settings.DAGS_FOLDER" [13135,13165]
===
match
---
simple_stmt [13176,13225]
simple_stmt [13232,13281]
===
match
---
operator: { [8652,8653]
operator: { [8708,8709]
===
match
---
trailer [6355,6361]
trailer [6411,6417]
===
match
---
trailer [6171,6232]
trailer [6227,6288]
===
match
---
name: task_id [9238,9245]
name: task_id [9294,9301]
===
match
---
operator: , [9530,9531]
operator: , [9586,9587]
===
match
---
name: response [18013,18021]
name: response [18069,18077]
===
match
---
name: pool [15316,15320]
name: pool [15372,15376]
===
match
---
trailer [15651,15656]
trailer [15707,15712]
===
match
---
name: self [5044,5048]
name: self [5100,5104]
===
match
---
name: timedelta [856,865]
name: timedelta [856,865]
===
match
---
expr_stmt [6401,6418]
expr_stmt [6457,6474]
===
match
---
assert_stmt [11579,11613]
assert_stmt [11635,11669]
===
match
---
string: "Pool name shouldn't be empty" [17724,17754]
string: "Pool name shouldn't be empty" [17780,17810]
===
match
---
operator: == [16052,16054]
operator: == [16108,16110]
===
match
---
comparison [17036,17054]
comparison [17092,17110]
===
match
---
assert_stmt [10655,10702]
assert_stmt [10711,10758]
===
match
---
operator: == [18098,18100]
operator: == [18154,18156]
===
match
---
simple_stmt [5287,5338]
simple_stmt [5343,5394]
===
match
---
expr_stmt [5347,5434]
expr_stmt [5403,5490]
===
match
---
name: self [7215,7219]
name: self [7271,7275]
===
match
---
name: url_template [14283,14295]
name: url_template [14339,14351]
===
match
---
name: dag_id [12113,12119]
name: dag_id [12169,12175]
===
match
---
name: url_template [10784,10796]
name: url_template [10840,10852]
===
match
---
trailer [14029,14068]
trailer [14085,14124]
===
match
---
name: self [18101,18105]
name: self [18157,18161]
===
match
---
name: data [4212,4216]
name: data [4268,4272]
===
match
---
name: datetime_string [13336,13351]
name: datetime_string [13392,13407]
===
match
---
string: 'utf-8' [4054,4061]
string: 'utf-8' [4110,4117]
===
match
---
trailer [12694,12696]
trailer [12750,12752]
===
match
---
simple_stmt [10757,10840]
simple_stmt [10813,10896]
===
match
---
atom_expr [14849,14869]
atom_expr [14905,14925]
===
match
---
name: run_id [9532,9538]
name: run_id [9588,9594]
===
match
---
atom_expr [18136,18158]
atom_expr [18192,18214]
===
match
---
arith_expr [15069,15074]
arith_expr [15125,15130]
===
match
---
number: 1 [9450,9451]
number: 1 [9506,9507]
===
match
---
name: client [17272,17278]
name: client [17328,17334]
===
match
---
string: 'error' [12430,12437]
string: 'error' [12486,12493]
===
match
---
atom_expr [11593,11613]
atom_expr [11649,11669]
===
match
---
trailer [14527,14534]
trailer [14583,14590]
===
match
---
simple_stmt [6401,6419]
simple_stmt [6457,6475]
===
match
---
trailer [9843,9848]
trailer [9899,9904]
===
match
---
atom_expr [9895,9924]
atom_expr [9951,9980]
===
match
---
name: pools [16474,16479]
name: pools [16530,16535]
===
match
---
atom_expr [11319,11414]
atom_expr [11375,11470]
===
match
---
classdef [2638,12471]
classdef [2694,12527]
===
match
---
atom_expr [10271,10338]
atom_expr [10327,10394]
===
match
---
trailer [10034,10082]
trailer [10090,10138]
===
match
---
name: dag_id [11331,11337]
name: dag_id [11387,11393]
===
match
---
simple_stmt [13233,13271]
simple_stmt [13289,13327]
===
match
---
arglist [12345,12369]
arglist [12401,12425]
===
match
---
simple_stmt [12705,12725]
simple_stmt [12761,12781]
===
match
---
trailer [16205,16215]
trailer [16261,16271]
===
match
---
name: client [12082,12088]
name: client [12138,12144]
===
match
---
name: self [16469,16473]
name: self [16525,16529]
===
match
---
operator: == [17134,17136]
operator: == [17190,17192]
===
match
---
operator: } [1748,1749]
operator: } [1748,1749]
===
match
---
name: assert_deprecated [13730,13747]
name: assert_deprecated [13786,13803]
===
match
---
trailer [5332,5337]
trailer [5388,5393]
===
match
---
trailer [15404,15431]
trailer [15460,15487]
===
match
---
atom_expr [15249,15272]
atom_expr [15305,15328]
===
match
---
trailer [10796,10803]
trailer [10852,10859]
===
match
---
atom_expr [15586,15669]
atom_expr [15642,15725]
===
match
---
trailer [11920,11932]
trailer [11976,11988]
===
match
---
operator: + [14768,14769]
operator: + [14824,14825]
===
match
---
comparison [18690,18776]
comparison [18746,18832]
===
match
---
trailer [12855,12857]
trailer [12911,12913]
===
match
---
operator: == [10623,10625]
operator: == [10679,10681]
===
match
---
expr_stmt [2059,2116]
expr_stmt [2059,2116]
===
match
---
argument [7352,7383]
argument [7408,7439]
===
match
---
name: assert_deprecated [3503,3520]
name: assert_deprecated [3559,3576]
===
match
---
trailer [12324,12371]
trailer [12380,12427]
===
match
---
name: cls [14835,14838]
name: cls [14891,14894]
===
match
---
name: join [1557,1561]
name: join [1557,1561]
===
match
---
fstring_string: /api/experimental/pools/ [17904,17928]
fstring_string: /api/experimental/pools/ [17960,17984]
===
match
---
operator: = [15584,15585]
operator: = [15640,15641]
===
match
---
decorator [14803,14816]
decorator [14859,14872]
===
match
---
trailer [10176,10183]
trailer [10232,10239]
===
match
---
atom_expr [13981,14079]
atom_expr [14037,14135]
===
match
---
assert_stmt [15719,15753]
assert_stmt [15775,15809]
===
match
---
decorated [2679,3071]
decorated [2735,3127]
===
match
---
assert_stmt [8086,8120]
assert_stmt [8142,8176]
===
match
---
string: 'foo' [17015,17020]
string: 'foo' [17071,17076]
===
match
---
simple_stmt [11579,11614]
simple_stmt [11635,11670]
===
match
---
operator: , [16682,16683]
operator: , [16738,16739]
===
match
---
name: pool [17939,17943]
name: pool [17995,17999]
===
match
---
name: response [16231,16239]
name: response [16287,16295]
===
match
---
trailer [3745,3755]
trailer [3801,3811]
===
match
---
name: data [16021,16025]
name: data [16077,16081]
===
match
---
atom_expr [4682,4702]
atom_expr [4738,4758]
===
match
---
trailer [6361,6392]
trailer [6417,6448]
===
match
---
name: pools [16408,16413]
name: pools [16464,16469]
===
match
---
name: self [2125,2129]
name: self [2125,2129]
===
match
---
name: format [8594,8600]
name: format [8650,8656]
===
match
---
name: query [3140,3145]
name: query [3196,3201]
===
match
---
simple_stmt [2226,2270]
simple_stmt [2226,2270]
===
match
---
string: 'example_bash_operator' [4422,4445]
string: 'example_bash_operator' [4478,4501]
===
match
---
name: self [4303,4307]
name: self [4359,4363]
===
match
---
simple_stmt [9042,9077]
simple_stmt [9098,9133]
===
match
---
suite [15566,15834]
suite [15622,15890]
===
match
---
name: self [6046,6050]
name: self [6102,6106]
===
match
---
name: isoformat [13380,13389]
name: isoformat [13436,13445]
===
match
---
name: paused_url [4875,4885]
name: paused_url [4931,4941]
===
match
---
name: sync_to_db [3012,3022]
name: sync_to_db [3068,3078]
===
match
---
operator: == [5149,5151]
operator: == [5205,5207]
===
match
---
expr_stmt [13970,14079]
expr_stmt [14026,14135]
===
match
---
name: self [15642,15646]
name: self [15698,15702]
===
match
---
simple_stmt [18539,18632]
simple_stmt [18595,18688]
===
match
---
import_from [1435,1511]
import_from [1435,1511]
===
match
---
name: name [17415,17419]
name: name [17471,17475]
===
match
---
string: 'application/json' [17570,17588]
string: 'application/json' [17626,17644]
===
match
---
name: loads [15774,15779]
name: loads [15830,15835]
===
match
---
simple_stmt [14733,14798]
simple_stmt [14789,14854]
===
match
---
string: 'error' [16043,16050]
string: 'error' [16099,16106]
===
match
---
operator: == [18435,18437]
operator: == [18491,18493]
===
match
---
string: 'does_not_exist_task' [10316,10337]
string: 'does_not_exist_task' [10372,10393]
===
match
---
operator: = [4886,4887]
operator: = [4942,4943]
===
match
---
expr_stmt [14256,14334]
expr_stmt [14312,14390]
===
match
---
trailer [15900,15907]
trailer [15956,15963]
===
match
---
parameters [18498,18504]
parameters [18554,18560]
===
match
---
simple_stmt [7042,7089]
simple_stmt [7098,7145]
===
match
---
string: '/api/experimental/pools' [16148,16173]
string: '/api/experimental/pools' [16204,16229]
===
match
---
import_from [866,891]
import_from [866,891]
===
match
---
name: assert_deprecated [3728,3745]
name: assert_deprecated [3784,3801]
===
match
---
operator: = [9584,9585]
operator: = [9640,9641]
===
match
---
atom_expr [4255,4275]
atom_expr [4311,4331]
===
match
---
string: 'does_not_exist_dag' [10035,10055]
string: 'does_not_exist_dag' [10091,10111]
===
match
---
atom_expr [16231,16251]
atom_expr [16287,16307]
===
match
---
operator: = [11352,11353]
operator: = [11408,11409]
===
match
---
atom_expr [2725,2745]
atom_expr [2781,2801]
===
match
---
atom_expr [9347,9385]
atom_expr [9403,9441]
===
match
---
trailer [3727,3745]
trailer [3783,3801]
===
match
---
operator: = [11230,11231]
operator: = [11286,11287]
===
match
---
operator: = [6408,6409]
operator: = [6464,6465]
===
match
---
string: 'error' [12203,12210]
string: 'error' [12259,12266]
===
match
---
atom_expr [13830,13859]
atom_expr [13886,13915]
===
match
---
name: url_template [4318,4330]
name: url_template [4374,4386]
===
match
---
name: i [16480,16481]
name: i [16536,16537]
===
match
---
atom_expr [10862,10882]
atom_expr [10918,10938]
===
match
---
name: query [2829,2834]
name: query [2885,2890]
===
match
---
expr_stmt [10757,10839]
expr_stmt [10813,10895]
===
match
---
assert_stmt [12380,12414]
assert_stmt [12436,12470]
===
match
---
name: json [6351,6355]
name: json [6407,6411]
===
match
---
name: format [10797,10803]
name: format [10853,10859]
===
match
---
trailer [2732,2743]
trailer [2788,2799]
===
match
---
operator: = [5856,5857]
operator: = [5912,5913]
===
match
---
comparison [13816,13859]
comparison [13872,13915]
===
match
---
operator: , [10297,10298]
operator: , [10353,10354]
===
match
---
operator: } [5979,5980]
operator: } [6035,6036]
===
match
---
trailer [14651,14660]
trailer [14707,14716]
===
match
---
atom_expr [15005,15032]
atom_expr [15061,15088]
===
match
---
simple_stmt [12867,12946]
simple_stmt [12923,13002]
===
match
---
name: re [816,818]
name: re [816,818]
===
match
---
simple_stmt [3265,3284]
simple_stmt [3321,3340]
===
match
---
name: self [10768,10772]
name: self [10824,10828]
===
match
---
name: dag_run [7701,7708]
name: dag_run [7757,7764]
===
match
---
operator: = [15094,15095]
operator: = [15150,15151]
===
match
---
trailer [18425,18434]
trailer [18481,18490]
===
match
---
expr_stmt [2226,2269]
expr_stmt [2226,2269]
===
match
---
trailer [1534,1543]
trailer [1534,1543]
===
match
---
name: url_template [5738,5750]
name: url_template [5794,5806]
===
match
---
string: 'error' [4192,4199]
string: 'error' [4248,4255]
===
match
---
atom_expr [8929,8977]
atom_expr [8985,9033]
===
match
---
trailer [4414,4421]
trailer [4470,4477]
===
match
---
string: 'slots' [16704,16711]
string: 'slots' [16760,16767]
===
match
---
operator: { [17381,17382]
operator: { [17437,17438]
===
match
---
trailer [16952,16983]
trailer [17008,17039]
===
match
---
trailer [4046,4053]
trailer [4102,4109]
===
match
---
trailer [16623,16629]
trailer [16679,16685]
===
match
---
atom_expr [18647,18667]
atom_expr [18703,18723]
===
match
---
name: SerializedDagModel [13028,13046]
name: SerializedDagModel [13084,13102]
===
match
---
name: TOTAL_POOL_COUNT [18167,18183]
name: TOTAL_POOL_COUNT [18223,18239]
===
match
---
name: data [5946,5950]
name: data [6002,6006]
===
match
---
atom_expr [7591,7599]
atom_expr [7647,7655]
===
match
---
name: self [3555,3559]
name: self [3611,3615]
===
match
---
trailer [16020,16025]
trailer [16076,16081]
===
match
---
string: 'utf-8' [13911,13918]
string: 'utf-8' [13967,13974]
===
match
---
name: decode [12455,12461]
name: decode [12511,12517]
===
match
---
atom_expr [9835,9864]
atom_expr [9891,9920]
===
match
---
trailer [2133,2140]
trailer [2133,2140]
===
match
---
trailer [12681,12683]
trailer [12737,12739]
===
match
---
assert_stmt [7444,7478]
assert_stmt [7500,7534]
===
match
---
name: self [17965,17969]
name: self [18021,18025]
===
match
---
suite [1689,2636]
suite [1689,2692]
===
match
---
operator: = [17265,17266]
operator: = [17321,17322]
===
match
---
string: 'utf-8' [3866,3873]
string: 'utf-8' [3922,3929]
===
match
---
operator: - [18184,18185]
operator: - [18240,18241]
===
match
---
expr_stmt [10516,10603]
expr_stmt [10572,10659]
===
match
---
name: decode [11973,11979]
name: decode [12029,12035]
===
match
---
atom_expr [14963,14986]
atom_expr [15019,15042]
===
match
---
trailer [13013,13015]
trailer [13069,13071]
===
match
---
assert_stmt [16224,16258]
assert_stmt [16280,16314]
===
match
---
simple_stmt [4318,4366]
simple_stmt [4374,4422]
===
match
---
atom_expr [12441,12470]
atom_expr [12497,12526]
===
match
---
name: commit [2874,2880]
name: commit [2930,2936]
===
match
---
name: USER_POOL_COUNT [14752,14767]
name: USER_POOL_COUNT [14808,14823]
===
match
---
trailer [6754,6761]
trailer [6810,6817]
===
match
---
atom_expr [12715,12724]
atom_expr [12771,12780]
===
match
---
simple_stmt [9272,9321]
simple_stmt [9328,9377]
===
match
---
assert_stmt [4185,4232]
assert_stmt [4241,4288]
===
match
---
expr_stmt [13644,13716]
expr_stmt [13700,13772]
===
match
---
trailer [2873,2880]
trailer [2929,2936]
===
match
---
name: self [18162,18166]
name: self [18218,18222]
===
match
---
trailer [9848,9855]
trailer [9904,9911]
===
match
---
name: TestBase [12506,12514]
name: TestBase [12562,12570]
===
match
---
name: wrong_datetime_string [14311,14332]
name: wrong_datetime_string [14367,14388]
===
match
---
atom_expr [7115,7141]
atom_expr [7171,7197]
===
match
---
trailer [4130,4137]
trailer [4186,4193]
===
match
---
operator: == [9053,9055]
operator: == [9109,9111]
===
match
---
atom_expr [4976,5034]
atom_expr [5032,5090]
===
match
---
name: dag_id [9517,9523]
name: dag_id [9573,9579]
===
match
---
atom_expr [15490,15536]
atom_expr [15546,15592]
===
match
---
operator: = [1937,1938]
operator: = [1937,1938]
===
match
---
trailer [10183,10192]
trailer [10239,10248]
===
match
---
atom_expr [17137,17158]
atom_expr [17193,17214]
===
match
---
simple_stmt [18683,18777]
simple_stmt [18739,18833]
===
match
---
trailer [3677,3713]
trailer [3733,3769]
===
match
---
name: datetime_string [10299,10314]
name: datetime_string [10355,10370]
===
match
---
name: resp [3398,3402]
name: resp [3454,3458]
===
match
---
name: isoformat [9373,9382]
name: isoformat [9429,9438]
===
match
---
trailer [3223,3230]
trailer [3279,3286]
===
match
---
operator: = [3583,3584]
operator: = [3639,3640]
===
match
---
trailer [11720,11729]
trailer [11776,11785]
===
match
---
comparison [5145,5172]
comparison [5201,5228]
===
match
---
trailer [3436,3445]
trailer [3492,3501]
===
match
---
assert_stmt [16992,17020]
assert_stmt [17048,17076]
===
match
---
trailer [7669,7685]
trailer [7725,7741]
===
match
---
operator: , [10082,10083]
operator: , [10138,10139]
===
match
---
name: setUpClass [2733,2743]
name: setUpClass [2789,2799]
===
match
---
number: 1990 [9438,9442]
number: 1990 [9494,9498]
===
match
---
name: session [15219,15226]
name: session [15275,15282]
===
match
---
comparison [9049,9076]
comparison [9105,9132]
===
match
---
name: pardir [1621,1627]
name: pardir [1621,1627]
===
match
---
number: 404 [11905,11908]
number: 404 [11961,11964]
===
match
---
simple_stmt [12733,12764]
simple_stmt [12789,12820]
===
match
---
trailer [10422,10429]
trailer [10478,10485]
===
match
---
argument [2932,2953]
argument [2988,3009]
===
match
---
name: content_type [5995,6007]
name: content_type [6051,6063]
===
match
---
operator: == [11590,11592]
operator: == [11646,11648]
===
match
---
trailer [5399,5433]
trailer [5455,5489]
===
match
---
expr_stmt [2754,2773]
expr_stmt [2810,2829]
===
match
---
expr_stmt [12705,12724]
expr_stmt [12761,12780]
===
match
---
arglist [16408,16438]
arglist [16464,16494]
===
match
---
name: format [12338,12344]
name: format [12394,12400]
===
match
---
atom_expr [4456,4488]
atom_expr [4512,4544]
===
match
---
name: json [7942,7946]
name: json [7998,8002]
===
match
---
assert_stmt [14613,14660]
assert_stmt [14669,14716]
===
match
---
name: self [4126,4130]
name: self [4182,4186]
===
match
---
operator: , [15152,15153]
operator: , [15208,15209]
===
match
---
atom_expr [18056,18097]
atom_expr [18112,18153]
===
match
---
expr_stmt [14488,14561]
expr_stmt [14544,14617]
===
match
---
operator: , [14068,14069]
operator: , [14124,14125]
===
match
---
operator: = [12075,12076]
operator: = [12131,12132]
===
match
---
trailer [13523,13601]
trailer [13579,13657]
===
match
---
simple_stmt [4743,4802]
simple_stmt [4799,4858]
===
match
---
comparison [7451,7478]
comparison [7507,7534]
===
match
---
argument [9532,9568]
argument [9588,9624]
===
match
---
name: self [6926,6930]
name: self [6982,6986]
===
match
---
trailer [12779,12785]
trailer [12835,12841]
===
match
---
dotted_name [1304,1315]
dotted_name [1304,1315]
===
match
---
number: 1 [15335,15336]
number: 1 [15391,15392]
===
match
---
string: "application/json" [9004,9022]
string: "application/json" [9060,9078]
===
match
---
trailer [18408,18415]
trailer [18464,18471]
===
match
---
operator: = [13530,13531]
operator: = [13586,13587]
===
match
---
operator: = [13324,13325]
operator: = [13380,13381]
===
match
---
trailer [16350,16367]
trailer [16406,16423]
===
match
---
name: response [4203,4211]
name: response [4259,4267]
===
match
---
argument [5946,5981]
argument [6002,6037]
===
match
---
trailer [11795,11802]
trailer [11851,11858]
===
match
---
comparison [16461,16492]
comparison [16517,16548]
===
match
---
trailer [14278,14282]
trailer [14334,14338]
===
match
---
name: parse_datetime [1240,1254]
name: parse_datetime [1240,1254]
===
match
---
trailer [2456,2471]
trailer [2456,2471]
===
match
---
name: client [15394,15400]
name: client [15450,15456]
===
match
---
simple_stmt [13028,13062]
simple_stmt [13084,13118]
===
match
---
operator: = [11052,11053]
operator: = [11108,11109]
===
match
---
name: get_default_pool [14968,14984]
name: get_default_pool [15024,15040]
===
match
---
string: "application/json" [8715,8733]
string: "application/json" [8771,8789]
===
match
---
name: data [11968,11972]
name: data [12024,12028]
===
match
---
file_input [787,18777]
file_input [787,18833]
===
match
---
simple_stmt [3216,3233]
simple_stmt [3272,3289]
===
match
---
simple_stmt [12817,12834]
simple_stmt [12873,12890]
===
match
---
funcdef [15542,15834]
funcdef [15598,15890]
===
match
---
operator: , [12570,12571]
operator: , [12626,12627]
===
match
---
simple_stmt [13970,14080]
simple_stmt [14026,14136]
===
match
---
operator: } [15074,15075]
operator: } [15130,15131]
===
match
---
name: response [4115,4123]
name: response [4171,4179]
===
match
---
simple_stmt [14949,14988]
simple_stmt [15005,15044]
===
match
---
dotted_name [1031,1045]
dotted_name [1031,1045]
===
match
---
comparison [16332,16367]
comparison [16388,16423]
===
match
---
argument [16614,16786]
argument [16670,16842]
===
match
---
trailer [10370,10382]
trailer [10426,10438]
===
match
---
operator: = [6954,6955]
operator: = [7010,7011]
===
match
---
operator: } [8975,8976]
operator: } [9031,9032]
===
match
---
simple_stmt [3456,3490]
simple_stmt [3512,3546]
===
match
---
trailer [18080,18087]
trailer [18136,18143]
===
match
---
name: app [2130,2133]
name: app [2130,2133]
===
match
---
string: 'error' [14138,14145]
string: 'error' [14194,14201]
===
match
---
name: assert_deprecated [6051,6068]
name: assert_deprecated [6107,6124]
===
match
---
simple_stmt [5138,5173]
simple_stmt [5194,5229]
===
match
---
funcdef [2384,2636]
funcdef [2384,2692]
===
match
---
name: response [4033,4041]
name: response [4089,4097]
===
match
---
atom_expr [3008,3024]
atom_expr [3064,3080]
===
match
---
atom_expr [13436,13477]
atom_expr [13492,13533]
===
match
---
name: get [10780,10783]
name: get [10836,10839]
===
match
---
name: Session [2371,2378]
name: Session [2371,2378]
===
match
---
name: TestBase [2664,2672]
name: TestBase [2720,2728]
===
match
---
operator: = [16812,16813]
operator: = [16868,16869]
===
match
---
atom_expr [3474,3489]
atom_expr [3530,3545]
===
match
---
trailer [10555,10562]
trailer [10611,10618]
===
match
---
name: self [15281,15285]
name: self [15337,15341]
===
match
---
name: len [16332,16335]
name: len [16388,16391]
===
match
---
simple_stmt [14849,14870]
simple_stmt [14905,14926]
===
match
---
simple_stmt [5798,5839]
simple_stmt [5854,5895]
===
match
---
name: decode [3859,3865]
name: decode [3915,3921]
===
match
---
suite [15369,15537]
suite [15425,15593]
===
match
---
number: 404 [10109,10112]
number: 404 [10165,10168]
===
match
---
name: decode [9849,9855]
name: decode [9905,9911]
===
match
---
suite [18505,18777]
suite [18561,18833]
===
match
---
name: response_execution_date [8129,8152]
name: response_execution_date [8185,8208]
===
match
---
name: tearDown [3273,3281]
name: tearDown [3329,3337]
===
match
---
arglist [7896,8067]
arglist [7952,8123]
===
match
---
trailer [2230,2234]
trailer [2230,2234]
===
match
---
name: session [2782,2789]
name: session [2838,2845]
===
match
---
name: decode [7538,7544]
name: decode [7594,7600]
===
match
---
operator: { [1705,1706]
operator: { [1705,1706]
===
match
---
trailer [3415,3446]
trailer [3471,3502]
===
match
---
number: 0 [8246,8247]
number: 0 [8302,8303]
===
match
---
import_name [799,808]
import_name [799,808]
===
match
---
simple_stmt [8540,8745]
simple_stmt [8596,8801]
===
match
---
simple_stmt [11208,11286]
simple_stmt [11264,11342]
===
match
---
name: format [6755,6761]
name: format [6811,6817]
===
match
---
name: TestCase [1679,1687]
name: TestCase [1679,1687]
===
match
---
atom_expr [8100,8120]
atom_expr [8156,8176]
===
match
---
name: status_code [4691,4702]
name: status_code [4747,4758]
===
match
---
name: pool [18106,18110]
name: pool [18162,18166]
===
match
---
name: json [7291,7295]
name: json [7347,7351]
===
match
---
trailer [13364,13392]
trailer [13420,13448]
===
match
---
atom_expr [16012,16041]
atom_expr [16068,16097]
===
match
---
funcdef [17823,18188]
funcdef [17879,18244]
===
match
---
name: dag_id [13691,13697]
name: dag_id [13747,13753]
===
match
---
simple_stmt [1342,1388]
simple_stmt [1342,1388]
===
match
---
simple_stmt [11538,11571]
simple_stmt [11594,11627]
===
match
---
assert_stmt [10848,10882]
assert_stmt [10904,10938]
===
match
---
name: format [10284,10290]
name: format [10340,10346]
===
match
---
atom_expr [8170,8229]
atom_expr [8226,8285]
===
match
---
trailer [13304,13312]
trailer [13360,13368]
===
match
---
simple_stmt [4810,4867]
simple_stmt [4866,4923]
===
match
---
trailer [9903,9908]
trailer [9959,9964]
===
match
---
atom_expr [16001,16051]
atom_expr [16057,16107]
===
match
---
simple_stmt [14709,14729]
simple_stmt [14765,14785]
===
match
---
simple_stmt [11678,11730]
simple_stmt [11734,11786]
===
match
---
name: data [7533,7537]
name: data [7589,7593]
===
match
---
operator: == [18159,18161]
operator: == [18215,18217]
===
match
---
trailer [12746,12754]
trailer [12802,12810]
===
match
---
name: version [3463,3470]
name: version [3519,3526]
===
match
---
name: status_code [5519,5530]
name: status_code [5575,5586]
===
match
---
name: unittest [871,879]
name: unittest [871,879]
===
match
---
trailer [18655,18667]
trailer [18711,18723]
===
match
---
name: decode [15794,15800]
name: decode [15850,15856]
===
match
---
name: datetime [11243,11251]
name: datetime [11299,11307]
===
match
---
name: data [8924,8928]
name: data [8980,8984]
===
match
---
trailer [8895,8902]
trailer [8951,8958]
===
match
---
name: response [17681,17689]
name: response [17737,17745]
===
match
---
name: clear_db_pools [14924,14938]
name: clear_db_pools [14980,14994]
===
match
---
name: conf_vars [1695,1704]
name: conf_vars [1695,1704]
===
match
---
trailer [12081,12088]
trailer [12137,12144]
===
match
---
operator: , [12351,12352]
operator: , [12407,12408]
===
match
---
parameters [4727,4733]
parameters [4783,4789]
===
match
---
trailer [9468,9470]
trailer [9524,9526]
===
match
---
expr_stmt [3318,3348]
expr_stmt [3374,3404]
===
match
---
string: "is_paused" [5295,5306]
string: "is_paused" [5351,5362]
===
match
---
trailer [8174,8180]
trailer [8230,8236]
===
match
---
argument [17344,17539]
argument [17400,17595]
===
match
---
dictorsetmaker [7954,8019]
dictorsetmaker [8010,8075]
===
match
---
name: TaskInstance [3185,3197]
name: TaskInstance [3241,3253]
===
match
---
assert_stmt [11941,11988]
assert_stmt [11997,12044]
===
match
---
trailer [7301,7338]
trailer [7357,7394]
===
match
---
operator: , [13458,13459]
operator: , [13514,13515]
===
match
---
name: data [18710,18714]
name: data [18766,18770]
===
match
---
arglist [14010,14069]
arglist [14066,14125]
===
match
---
name: wrong_datetime_string [9394,9415]
name: wrong_datetime_string [9450,9471]
===
match
---
operator: == [18741,18743]
operator: == [18797,18799]
===
match
---
name: DagRun [3146,3152]
name: DagRun [3202,3208]
===
match
---
name: dag_id [10804,10810]
name: dag_id [10860,10866]
===
match
---
operator: == [6629,6631]
operator: == [6685,6687]
===
match
---
trailer [12976,12983]
trailer [13032,13039]
===
match
---
simple_stmt [2356,2379]
simple_stmt [2356,2379]
===
match
---
atom_expr [2487,2635]
atom_expr [2487,2691]
===
match
---
name: response [13780,13788]
name: response [13836,13844]
===
match
---
name: tests [1347,1352]
name: tests [1347,1352]
===
match
---
parameters [2405,2417]
parameters [2405,2417]
===
match
---
name: data [15514,15518]
name: data [15570,15574]
===
match
---
name: data [12223,12227]
name: data [12279,12283]
===
match
---
atom_expr [14010,14068]
atom_expr [14066,14124]
===
match
---
simple_stmt [18514,18531]
simple_stmt [18570,18587]
===
match
---
trailer [4543,4552]
trailer [4599,4608]
===
match
---
string: 'utf-8' [3437,3444]
string: 'utf-8' [3493,3500]
===
match
---
import_as_names [1053,1087]
import_as_names [1053,1087]
===
match
---
name: assert_deprecated [4461,4478]
name: assert_deprecated [4517,4534]
===
match
---
simple_stmt [18242,18326]
simple_stmt [18298,18382]
===
match
---
simple_stmt [17029,17055]
simple_stmt [17085,17111]
===
match
---
name: test_trigger_dag_for_date [6900,6925]
name: test_trigger_dag_for_date [6956,6981]
===
match
---
trailer [7620,7628]
trailer [7676,7684]
===
match
---
atom_expr [7403,7435]
atom_expr [7459,7491]
===
match
---
operator: , [15127,15128]
operator: , [15183,15184]
===
match
---
import_from [1263,1298]
import_from [1263,1298]
===
match
---
expr_stmt [6941,6992]
expr_stmt [6997,7048]
===
match
---
assert_stmt [12153,12187]
assert_stmt [12209,12243]
===
match
---
trailer [13843,13850]
trailer [13899,13906]
===
match
---
name: utcnow [1256,1262]
name: utcnow [1256,1262]
===
match
---
number: 0 [9318,9319]
number: 0 [9374,9375]
===
match
---
expr_stmt [14709,14728]
expr_stmt [14765,14784]
===
match
---
name: url_template [7245,7257]
name: url_template [7301,7313]
===
match
---
assert_stmt [3456,3489]
assert_stmt [3512,3545]
===
match
---
fstring_start: f' [7710,7712]
fstring_start: f' [7766,7768]
===
match
---
name: response [14357,14365]
name: response [14413,14421]
===
match
---
suite [1919,2379]
suite [1919,2379]
===
match
---
trailer [1961,1975]
trailer [1961,1975]
===
match
---
trailer [16294,16299]
trailer [16350,16355]
===
match
---
name: post [5870,5874]
name: post [5926,5930]
===
match
---
number: 1 [17454,17455]
number: 1 [17510,17511]
===
match
---
comparison [13875,13919]
comparison [13931,13975]
===
match
---
atom_expr [2125,2154]
atom_expr [2125,2154]
===
match
---
atom_expr [8305,8313]
atom_expr [8361,8369]
===
match
---
trailer [2063,2067]
trailer [2063,2067]
===
match
---
string: 'name' [17407,17413]
string: 'name' [17463,17469]
===
match
---
assert_stmt [5595,5636]
assert_stmt [5651,5692]
===
match
---
trailer [10779,10783]
trailer [10835,10839]
===
match
---
trailer [4644,4651]
trailer [4700,4707]
===
match
---
name: self [15814,15818]
name: self [15870,15874]
===
match
---
atom_expr [12676,12696]
atom_expr [12732,12752]
===
match
---
comparison [11685,11729]
comparison [11741,11785]
===
match
---
name: status_code [18350,18361]
name: status_code [18406,18417]
===
match
---
simple_stmt [3498,3531]
simple_stmt [3554,3587]
===
match
---
name: loads [15499,15504]
name: loads [15555,15560]
===
match
---
string: 'utf-8' [12462,12469]
string: 'utf-8' [12518,12525]
===
match
---
trailer [2234,2241]
trailer [2234,2241]
===
match
---
string: "default_pool cannot be deleted" [18744,18776]
string: "default_pool cannot be deleted" [18800,18832]
===
match
---
simple_stmt [6088,6123]
simple_stmt [6144,6179]
===
match
---
lambdef [16419,16438]
lambdef [16475,16494]
===
match
---
assert_stmt [4015,4062]
assert_stmt [4071,4118]
===
match
---
name: query [3179,3184]
name: query [3235,3240]
===
match
---
arglist [14535,14559]
arglist [14591,14615]
===
match
---
name: add [15227,15230]
name: add [15283,15286]
===
match
---
trailer [3953,4006]
trailer [4009,4062]
===
match
---
atom_expr [15505,15534]
atom_expr [15561,15590]
===
match
---
name: session [12705,12712]
name: session [12761,12768]
===
match
---
trailer [16873,16883]
trailer [16929,16939]
===
match
---
atom_expr [18013,18033]
atom_expr [18069,18089]
===
match
---
name: os [12546,12548]
name: os [12602,12604]
===
match
---
operator: , [9454,9455]
operator: , [9510,9511]
===
match
---
comparison [4078,4105]
comparison [4134,4161]
===
match
---
trailer [8372,8383]
trailer [8428,8439]
===
match
---
operator: , [3701,3702]
operator: , [3757,3758]
===
match
---
atom_expr [5888,5932]
atom_expr [5944,5988]
===
match
---
arglist [11840,11877]
arglist [11896,11933]
===
match
---
trailer [16907,16919]
trailer [16963,16975]
===
match
---
name: mock [887,891]
name: mock [887,891]
===
match
---
expr_stmt [15089,15201]
expr_stmt [15145,15257]
===
match
---
name: assert_deprecated [11543,11560]
name: assert_deprecated [11599,11616]
===
match
---
assert_stmt [18683,18776]
assert_stmt [18739,18832]
===
match
---
name: test_get_pool_non_existing [15843,15869]
name: test_get_pool_non_existing [15899,15925]
===
match
---
operator: == [2441,2443]
operator: == [2441,2443]
===
match
---
funcdef [15839,16082]
funcdef [15895,16138]
===
match
---
name: setUp [14879,14884]
name: setUp [14935,14940]
===
match
---
string: 'utf-8' [18416,18423]
string: 'utf-8' [18472,18479]
===
match
---
trailer [9458,9468]
trailer [9514,9524]
===
match
---
name: len [15490,15493]
name: len [15546,15549]
===
match
---
name: common [975,981]
name: common [975,981]
===
match
---
name: dag [12999,13002]
name: dag [13055,13058]
===
match
---
string: "init_appbuilder" [1874,1891]
string: "init_appbuilder" [1874,1891]
===
match
---
name: datetime_string [11143,11158]
name: datetime_string [11199,11214]
===
match
---
dotted_name [897,909]
dotted_name [897,909]
===
match
---
name: response [5510,5518]
name: response [5566,5574]
===
match
---
atom_expr [5818,5838]
atom_expr [5874,5894]
===
match
---
operator: = [17569,17570]
operator: = [17625,17626]
===
match
---
operator: = [1817,1818]
operator: = [1817,1818]
===
match
---
name: TestPoolApiExperimental [14669,14692]
name: TestPoolApiExperimental [14725,14748]
===
match
---
name: status_code [14111,14122]
name: status_code [14167,14178]
===
match
---
expr_stmt [7097,7141]
expr_stmt [7153,7197]
===
match
---
name: response [9788,9796]
name: response [9844,9852]
===
match
---
string: 'execution_date' [8653,8669]
string: 'execution_date' [8709,8725]
===
match
---
decorators [1694,1899]
decorators [1694,1899]
===
match
---
string: 'execution_date' [7555,7571]
string: 'execution_date' [7611,7627]
===
match
---
name: replace [9298,9305]
name: replace [9354,9361]
===
match
---
number: 0 [13325,13326]
number: 0 [13381,13382]
===
match
---
operator: = [2948,2949]
operator: = [3004,3005]
===
match
---
name: get [9666,9669]
name: get [9722,9725]
===
match
---
name: values [12977,12983]
name: values [13033,13039]
===
match
---
name: self [16183,16187]
name: self [16239,16243]
===
match
---
name: datetime [13436,13444]
name: datetime [13492,13500]
===
match
---
comparison [14095,14122]
comparison [14151,14178]
===
match
---
atom_expr [16942,16983]
atom_expr [16998,17039]
===
match
---
trailer [8555,8562]
trailer [8611,8618]
===
match
---
expr_stmt [9125,9188]
expr_stmt [9181,9244]
===
match
---
name: datetime [840,848]
name: datetime [840,848]
===
match
---
import_from [1088,1148]
import_from [1088,1148]
===
match
---
name: get [9998,10001]
name: get [10054,10057]
===
match
---
string: 'WTF_CSRF_ENABLED' [2242,2260]
string: 'WTF_CSRF_ENABLED' [2242,2260]
===
match
---
trailer [5471,5478]
trailer [5527,5534]
===
match
---
operator: = [5556,5557]
operator: = [5612,5613]
===
match
---
simple_stmt [9975,10094]
simple_stmt [10031,10150]
===
match
---
string: 'runme_0' [3703,3712]
string: 'runme_0' [3759,3768]
===
match
---
name: app [2064,2067]
name: app [2064,2067]
===
match
---
atom_expr [4033,4062]
atom_expr [4089,4118]
===
match
---
decorator [2679,2692]
decorator [2735,2748]
===
match
---
name: config [2134,2140]
name: config [2134,2140]
===
match
---
trailer [15010,15032]
trailer [15066,15088]
===
match
---
argument [9570,9599]
argument [9626,9655]
===
match
---
argument [8924,8977]
argument [8980,9033]
===
match
---
name: content_type [16800,16812]
name: content_type [16856,16868]
===
match
---
trailer [18561,18568]
trailer [18617,18624]
===
match
---
trailer [17003,17011]
trailer [17059,17067]
===
match
---
trailer [10686,10693]
trailer [10742,10749]
===
match
---
operator: = [6155,6156]
operator: = [6211,6212]
===
match
---
name: response_execution_date [8384,8407]
name: response_execution_date [8440,8463]
===
match
---
operator: = [9287,9288]
operator: = [9343,9344]
===
match
---
suite [18233,18465]
suite [18289,18521]
===
match
---
trailer [18709,18714]
trailer [18765,18770]
===
match
---
name: format [4995,5001]
name: format [5051,5057]
===
match
---
name: resp_raw [3416,3424]
name: resp_raw [3472,3480]
===
match
---
name: response [3845,3853]
name: response [3901,3909]
===
match
---
string: '' [17496,17498]
string: '' [17552,17554]
===
match
---
simple_stmt [4115,4177]
simple_stmt [4171,4233]
===
match
---
name: decode [16026,16032]
name: decode [16082,16088]
===
match
---
fstring_end: ' [8488,8489]
fstring_end: ' [8544,8545]
===
match
---
simple_stmt [15951,15986]
simple_stmt [16007,16042]
===
match
---
name: self [8551,8555]
name: self [8607,8611]
===
match
---
trailer [16966,16973]
trailer [17022,17029]
===
match
---
trailer [17353,17359]
trailer [17409,17415]
===
match
---
simple_stmt [2891,2907]
simple_stmt [2947,2963]
===
match
---
expr_stmt [15311,15337]
expr_stmt [15367,15393]
===
match
---
name: format [13684,13690]
name: format [13740,13746]
===
match
---
name: response [6183,6191]
name: response [6239,6247]
===
match
---
trailer [2992,2994]
trailer [3048,3050]
===
match
---
comparison [6863,6890]
comparison [6919,6946]
===
match
---
string: 'example_bash_operator' [6448,6471]
string: 'example_bash_operator' [6504,6527]
===
match
---
name: loads [7518,7523]
name: loads [7574,7579]
===
match
---
assert_stmt [4668,4702]
assert_stmt [4724,4758]
===
match
---
simple_stmt [16992,17021]
simple_stmt [17048,17077]
===
match
---
name: self [10255,10259]
name: self [10311,10315]
===
match
---
trailer [11242,11285]
trailer [11298,11341]
===
match
---
name: data [5467,5471]
name: data [5523,5527]
===
match
---
operator: = [3640,3641]
operator: = [3696,3697]
===
match
---
operator: = [6818,6819]
operator: = [6874,6875]
===
match
---
number: 0 [6248,6249]
number: 0 [6304,6305]
===
match
---
name: TaskInstance [2835,2847]
name: TaskInstance [2891,2903]
===
match
---
name: app [1933,1936]
name: app [1933,1936]
===
match
---
comparison [5450,5487]
comparison [5506,5543]
===
match
---
atom_expr [16183,16215]
atom_expr [16239,16271]
===
match
---
name: values [2986,2992]
name: values [3042,3048]
===
match
---
operator: == [3894,3896]
operator: == [3950,3952]
===
match
---
trailer [5466,5471]
trailer [5522,5527]
===
match
---
name: response [7204,7212]
name: response [7260,7268]
===
match
---
trailer [5362,5369]
trailer [5418,5425]
===
match
---
trailer [14110,14122]
trailer [14166,14178]
===
match
---
funcdef [17168,17818]
funcdef [17224,17874]
===
match
---
trailer [13046,13056]
trailer [13102,13112]
===
match
---
name: self [2278,2282]
name: self [2278,2282]
===
match
---
trailer [16335,16342]
trailer [16391,16398]
===
match
---
name: url_template [13176,13188]
name: url_template [13232,13244]
===
match
---
string: 'utf-8' [14425,14432]
string: 'utf-8' [14481,14488]
===
match
---
simple_stmt [2754,2774]
simple_stmt [2810,2830]
===
match
---
string: 'not_a_datetime' [8959,8975]
string: 'not_a_datetime' [9015,9031]
===
match
---
suite [12986,13062]
suite [13042,13118]
===
match
---
parameters [15559,15565]
parameters [15615,15621]
===
match
---
string: '/api/experimental/pools' [17301,17326]
string: '/api/experimental/pools' [17357,17382]
===
match
---
simple_stmt [3823,3875]
simple_stmt [3879,3931]
===
match
---
name: client [9991,9997]
name: client [10047,10053]
===
match
---
trailer [9796,9808]
trailer [9852,9864]
===
match
---
trailer [8869,9033]
trailer [8925,9089]
===
match
---
trailer [9755,9765]
trailer [9811,9821]
===
match
---
name: paused_url [5216,5226]
name: paused_url [5272,5282]
===
match
---
trailer [6439,6447]
trailer [6495,6503]
===
match
---
trailer [14417,14424]
trailer [14473,14480]
===
match
---
atom_expr [18162,18183]
atom_expr [18218,18239]
===
match
---
trailer [14302,14333]
trailer [14358,14389]
===
match
---
name: sync_to_db [13003,13013]
name: sync_to_db [13059,13069]
===
match
---
string: 'name' [16669,16675]
string: 'name' [16725,16731]
===
match
---
trailer [13475,13477]
trailer [13531,13533]
===
match
---
trailer [2300,2312]
trailer [2300,2312]
===
match
---
name: response [14584,14592]
name: response [14640,14648]
===
match
---
atom_expr [11791,11889]
atom_expr [11847,11945]
===
match
---
string: 'description' [17481,17494]
string: 'description' [17537,17550]
===
match
---
string: 'utf-8' [16033,16040]
string: 'utf-8' [16089,16096]
===
match
---
name: client [16137,16143]
name: client [16193,16199]
===
match
---
name: status_code [16908,16919]
name: status_code [16964,16975]
===
match
---
trailer [15218,15226]
trailer [15274,15282]
===
match
---
trailer [1529,1534]
trailer [1529,1534]
===
match
---
trailer [1556,1561]
trailer [1556,1561]
===
match
---
trailer [5392,5399]
trailer [5448,5455]
===
match
---
fstring [17902,17945]
fstring [17958,18001]
===
match
---
number: 1 [11264,11265]
number: 1 [11320,11321]
===
match
---
name: DagBag [6410,6416]
name: DagBag [6466,6472]
===
match
---
arglist [13691,13714]
arglist [13747,13770]
===
match
---
name: json [15769,15773]
name: json [15825,15829]
===
match
---
operator: = [3112,3113]
operator: = [3168,3169]
===
match
---
number: 1 [17161,17162]
number: 1 [17217,17218]
===
match
---
operator: } [17943,17944]
operator: } [17999,18000]
===
match
---
string: 'utf-8' [6204,6211]
string: 'utf-8' [6260,6267]
===
match
---
atom_expr [6410,6418]
atom_expr [6466,6474]
===
match
---
operator: = [17348,17349]
operator: = [17404,17405]
===
match
---
operator: , [16381,16382]
operator: , [16437,16438]
===
match
---
operator: = [16618,16619]
operator: = [16674,16675]
===
match
---
param [13161,13165]
param [13217,13221]
===
match
---
operator: = [12307,12308]
operator: = [12363,12364]
===
match
---
argument [6785,6804]
argument [6841,6860]
===
match
---
name: self [4386,4390]
name: self [4442,4446]
===
match
---
name: TestBase [14693,14701]
name: TestBase [14749,14757]
===
match
---
atom_expr [10255,10339]
atom_expr [10311,10395]
===
match
---
number: 200 [7451,7454]
number: 200 [7507,7510]
===
match
---
name: classmethod [14804,14815]
name: classmethod [14860,14871]
===
match
---
operator: { [17928,17929]
operator: { [17984,17985]
===
match
---
trailer [5874,6037]
trailer [5930,6093]
===
match
---
string: 'DNE' [4169,4174]
string: 'DNE' [4225,4230]
===
match
---
name: wrong_datetime_string [11208,11229]
name: wrong_datetime_string [11264,11285]
===
match
---
string: 'not_a_datetime' [12353,12369]
string: 'not_a_datetime' [12409,12425]
===
match
---
trailer [5108,5113]
trailer [5164,5169]
===
match
---
trailer [2345,2347]
trailer [2345,2347]
===
match
---
name: dag [3008,3011]
name: dag [3064,3067]
===
match
---
name: task_id [10594,10601]
name: task_id [10650,10657]
===
match
---
trailer [17938,17943]
trailer [17994,17999]
===
match
---
simple_stmt [1026,1088]
simple_stmt [1026,1088]
===
match
---
operator: , [7338,7339]
operator: , [7394,7395]
===
match
---
string: 'Deprecation' [2457,2470]
string: 'Deprecation' [2457,2470]
===
match
---
name: session [2866,2873]
name: session [2922,2929]
===
match
---
name: pardir [1632,1638]
name: pardir [1632,1638]
===
match
---
atom_expr [5200,5227]
atom_expr [5256,5283]
===
match
---
fstring [8433,8489]
fstring [8489,8545]
===
match
---
trailer [3429,3436]
trailer [3485,3492]
===
match
---
simple_stmt [3318,3349]
simple_stmt [3374,3405]
===
match
---
trailer [4161,4175]
trailer [4217,4231]
===
match
---
atom_expr [12918,12944]
atom_expr [12974,13000]
===
match
---
name: decode [14418,14424]
name: decode [14474,14480]
===
match
---
name: parse_datetime [8155,8169]
name: parse_datetime [8211,8225]
===
match
---
operator: == [17090,17092]
operator: == [17146,17148]
===
match
---
atom_expr [14924,14940]
atom_expr [14980,14996]
===
match
---
operator: = [14497,14498]
operator: = [14553,14554]
===
match
---
name: dont_initialize_flask_app_submodules [1475,1511]
name: dont_initialize_flask_app_submodules [1475,1511]
===
match
---
trailer [8600,8622]
trailer [8656,8678]
===
match
---
simple_stmt [2059,2117]
simple_stmt [2059,2117]
===
match
---
trailer [5836,5838]
trailer [5892,5894]
===
match
---
name: post [8563,8567]
name: post [8619,8623]
===
match
---
name: execution_date [13365,13379]
name: execution_date [13421,13435]
===
match
---
name: self [17796,17800]
name: self [17852,17856]
===
match
---
name: self [4616,4620]
name: self [4672,4676]
===
match
---
trailer [9665,9669]
trailer [9721,9725]
===
match
---
atom_expr [10116,10136]
atom_expr [10172,10192]
===
match
---
name: response [15575,15583]
name: response [15631,15639]
===
match
---
trailer [4216,4223]
trailer [4272,4279]
===
match
---
atom_expr [12093,12143]
atom_expr [12149,12199]
===
match
---
atom_expr [9654,9724]
atom_expr [9710,9780]
===
match
---
name: status_code [10125,10136]
name: status_code [10181,10192]
===
match
---
trailer [18415,18424]
trailer [18471,18480]
===
match
---
trailer [15259,15266]
trailer [15315,15322]
===
match
---
trailer [5955,5961]
trailer [6011,6017]
===
match
---
trailer [3865,3874]
trailer [3921,3930]
===
match
---
trailer [10259,10266]
trailer [10315,10322]
===
match
---
expr_stmt [16935,16983]
expr_stmt [16991,17039]
===
match
---
name: url_template [10543,10555]
name: url_template [10599,10611]
===
match
---
trailer [10001,10093]
trailer [10057,10149]
===
match
---
atom_expr [10527,10603]
atom_expr [10583,10659]
===
match
---
name: response [12298,12306]
name: response [12354,12362]
===
match
---
simple_stmt [10982,11037]
simple_stmt [11038,11093]
===
match
---
number: 200 [9781,9784]
number: 200 [9837,9840]
===
match
---
assert_stmt [18006,18040]
assert_stmt [18062,18096]
===
match
---
dotted_name [963,1006]
dotted_name [963,1006]
===
match
---
name: response [4523,4531]
name: response [4579,4587]
===
match
---
name: test_get_pool [15546,15559]
name: test_get_pool [15602,15615]
===
match
---
trailer [2795,2803]
trailer [2851,2859]
===
match
---
trailer [17141,17158]
trailer [17197,17214]
===
match
---
param [18227,18231]
param [18283,18287]
===
match
---
trailer [1577,1605]
trailer [1577,1605]
===
match
---
name: dag_id [10291,10297]
name: dag_id [10347,10353]
===
match
---
trailer [16306,16315]
trailer [16362,16371]
===
match
---
operator: == [14099,14101]
operator: == [14155,14157]
===
match
---
string: 'SECRET_KEY' [2141,2153]
string: 'SECRET_KEY' [2141,2153]
===
match
---
name: response [15378,15386]
name: response [15434,15442]
===
match
---
name: run_id [5798,5804]
name: run_id [5854,5860]
===
match
---
atom_expr [8641,8688]
atom_expr [8697,8744]
===
match
---
name: response [11561,11569]
name: response [11617,11625]
===
match
---
name: response [13830,13838]
name: response [13886,13894]
===
match
---
name: response [16953,16961]
name: response [17009,17017]
===
match
---
expr_stmt [2178,2217]
expr_stmt [2178,2217]
===
match
---
trailer [15226,15230]
trailer [15282,15286]
===
match
---
operator: , [10072,10073]
operator: , [10128,10129]
===
match
---
string: 'utf-8' [12235,12242]
string: 'utf-8' [12291,12298]
===
match
---
arglist [13445,13464]
arglist [13501,13520]
===
match
---
trailer [3281,3283]
trailer [3337,3339]
===
match
---
funcdef [4708,5697]
funcdef [4764,5753]
===
match
---
string: 'utf-8' [16974,16981]
string: 'utf-8' [17030,17037]
===
match
---
expr_stmt [15378,15431]
expr_stmt [15434,15487]
===
match
---
name: conf_vars [1378,1387]
name: conf_vars [1378,1387]
===
match
---
name: self [5200,5204]
name: self [5256,5260]
===
match
---
name: client [4621,4627]
name: client [4677,4683]
===
match
---
trailer [2296,2300]
trailer [2296,2300]
===
match
---
trailer [10929,10938]
trailer [10985,10994]
===
match
---
name: self [3303,3307]
name: self [3359,3363]
===
match
---
trailer [6878,6890]
trailer [6934,6946]
===
match
---
operator: , [9448,9449]
operator: , [9504,9505]
===
match
---
name: self [16519,16523]
name: self [16575,16579]
===
match
---
trailer [11653,11660]
trailer [11709,11716]
===
match
---
atom_expr [10673,10702]
atom_expr [10729,10758]
===
match
---
name: self [7403,7407]
name: self [7459,7463]
===
match
---
trailer [18140,18156]
trailer [18196,18212]
===
match
---
operator: == [12164,12166]
operator: == [12220,12222]
===
match
---
trailer [11479,11483]
trailer [11535,11539]
===
match
---
name: data [15789,15793]
name: data [15845,15849]
===
match
---
arglist [10291,10337]
arglist [10347,10393]
===
match
---
name: pool [16999,17003]
name: pool [17055,17059]
===
match
---
name: self [10527,10531]
name: self [10583,10587]
===
match
---
name: delete [17882,17888]
name: delete [17938,17944]
===
match
---
name: pause_url_template [4976,4994]
name: pause_url_template [5032,5050]
===
match
---
comp_op [9888,9894]
comp_op [9944,9950]
===
match
---
atom_expr [10543,10602]
atom_expr [10599,10658]
===
match
---
name: i [15069,15070]
name: i [15125,15126]
===
match
---
trailer [2904,2906]
trailer [2960,2962]
===
match
---
name: url_template [10015,10027]
name: url_template [10071,10083]
===
match
---
name: client [5563,5569]
name: client [5619,5625]
===
match
---
assert_stmt [7694,7766]
assert_stmt [7750,7822]
===
match
---
trailer [10562,10602]
trailer [10618,10658]
===
match
---
simple_stmt [7855,8078]
simple_stmt [7911,8134]
===
match
---
assert_stmt [11678,11729]
assert_stmt [11734,11785]
===
match
---
name: slots [15145,15150]
name: slots [15201,15206]
===
match
---
arglist [9690,9722]
arglist [9746,9778]
===
match
---
name: response [10909,10917]
name: response [10965,10973]
===
match
---
simple_stmt [2323,2348]
simple_stmt [2323,2348]
===
match
---
operator: , [11382,11383]
operator: , [11438,11439]
===
match
---
operator: = [14750,14751]
operator: = [14806,14807]
===
match
---
simple_stmt [6856,6891]
simple_stmt [6912,6947]
===
match
---
number: 1 [7086,7087]
number: 1 [7142,7143]
===
match
---
assert_stmt [18377,18464]
assert_stmt [18433,18520]
===
match
---
name: create_app [1951,1961]
name: create_app [1951,1961]
===
match
---
trailer [2006,2010]
trailer [2006,2010]
===
match
---
name: response [7855,7863]
name: response [7911,7919]
===
match
---
trailer [7908,7915]
trailer [7964,7971]
===
match
---
operator: = [15387,15388]
operator: = [15443,15444]
===
match
---
for_stmt [16376,16493]
for_stmt [16432,16549]
===
match
---
parameters [17843,17849]
parameters [17899,17905]
===
match
---
comparison [5092,5129]
comparison [5148,5185]
===
match
---
trailer [15773,15779]
trailer [15829,15835]
===
match
---
number: 404 [4248,4251]
number: 404 [4304,4307]
===
match
---
trailer [3055,3065]
trailer [3111,3121]
===
match
---
operator: , [1254,1255]
operator: , [1254,1255]
===
match
---
operator: = [5198,5199]
operator: = [5254,5255]
===
match
---
name: dag [8369,8372]
name: dag [8425,8428]
===
match
---
atom_expr [1527,1652]
atom_expr [1527,1652]
===
match
---
comparison [14138,14178]
comparison [14194,14234]
===
match
---
name: dag_folder [12907,12917]
name: dag_folder [12963,12973]
===
match
---
trailer [13903,13910]
trailer [13959,13966]
===
match
---
operator: , [12581,12582]
operator: , [12637,12638]
===
match
---
simple_stmt [10244,10340]
simple_stmt [10300,10396]
===
match
---
arglist [2510,2625]
arglist [2510,2681]
===
match
---
name: json [6790,6794]
name: json [6846,6850]
===
match
---
name: ROOT_FOLDER [12559,12570]
name: ROOT_FOLDER [12615,12626]
===
match
---
atom_expr [3037,3070]
atom_expr [3093,3126]
===
match
---
name: response [10244,10252]
name: response [10300,10308]
===
match
---
simple_stmt [8842,9034]
simple_stmt [8898,9090]
===
match
---
atom_expr [16132,16174]
atom_expr [16188,16230]
===
match
---
simple_stmt [7444,7479]
simple_stmt [7500,7535]
===
match
---
name: self [11538,11542]
name: self [11594,11598]
===
match
---
trailer [5001,5034]
trailer [5057,5090]
===
match
---
comparison [5652,5696]
comparison [5708,5752]
===
match
---
atom_expr [16391,16440]
atom_expr [16447,16496]
===
match
---
simple_stmt [4949,5036]
simple_stmt [5005,5092]
===
match
---
name: utcnow [13296,13302]
name: utcnow [13352,13358]
===
match
---
number: 1 [9447,9448]
number: 1 [9503,9504]
===
match
---
trailer [18349,18361]
trailer [18405,18417]
===
match
---
name: response [14256,14264]
name: response [14312,14320]
===
match
---
assert_stmt [18129,18187]
assert_stmt [18185,18243]
===
match
---
trailer [2828,2834]
trailer [2884,2890]
===
match
---
trailer [17881,17888]
trailer [17937,17944]
===
match
---
expr_stmt [9329,9385]
expr_stmt [9385,9441]
===
match
---
trailer [5569,5573]
trailer [5625,5629]
===
match
---
simple_stmt [4375,4448]
simple_stmt [4431,4504]
===
match
---
operator: , [7272,7273]
operator: , [7328,7329]
===
match
---
trailer [16032,16041]
trailer [16088,16097]
===
match
---
string: 'test_task_instance_info_run' [11353,11382]
string: 'test_task_instance_info_run' [11409,11438]
===
match
---
operator: == [15747,15749]
operator: == [15803,15805]
===
match
---
trailer [10270,10339]
trailer [10326,10395]
===
match
---
simple_stmt [15311,15338]
simple_stmt [15367,15394]
===
match
---
name: isoformat [11187,11196]
name: isoformat [11243,11252]
===
match
---
name: path [1530,1534]
name: path [1530,1534]
===
match
---
name: resp [3474,3478]
name: resp [3530,3534]
===
match
---
comparison [16999,17020]
comparison [17055,17076]
===
match
---
simple_stmt [4071,4106]
simple_stmt [4127,4162]
===
match
---
operator: == [6589,6591]
operator: == [6645,6647]
===
match
---
string: 'utf-8' [10694,10701]
string: 'utf-8' [10750,10757]
===
match
---
string: 'utf-8' [7545,7552]
string: 'utf-8' [7601,7608]
===
match
---
operator: , [6783,6784]
operator: , [6839,6840]
===
match
---
name: data [11709,11713]
name: data [11765,11769]
===
match
---
number: 404 [4078,4081]
number: 404 [4134,4137]
===
match
---
trailer [16407,16439]
trailer [16463,16495]
===
match
---
trailer [5826,5836]
trailer [5882,5892]
===
match
---
name: enumerate [16391,16400]
name: enumerate [16447,16456]
===
match
---
comparison [4675,4702]
comparison [4731,4758]
===
match
---
operator: = [16543,16544]
operator: = [16599,16600]
===
match
---
name: dag_run_id [6592,6602]
name: dag_run_id [6648,6658]
===
match
---
decorated [12630,13062]
decorated [12686,13118]
===
match
---
number: 400 [12387,12390]
number: 400 [12443,12446]
===
match
---
name: decode [13844,13850]
name: decode [13900,13906]
===
match
---
trailer [2448,2456]
trailer [2448,2456]
===
match
---
atom_expr [8853,9033]
atom_expr [8909,9089]
===
match
---
dictorsetmaker [7303,7336]
dictorsetmaker [7359,7392]
===
match
---
operator: = [13979,13980]
operator: = [14035,14036]
===
match
---
suite [16525,17163]
suite [16581,17219]
===
match
---
name: decode [5114,5120]
name: decode [5170,5176]
===
match
---
param [15870,15874]
param [15926,15930]
===
match
---
parameters [9109,9115]
parameters [9165,9171]
===
match
---
simple_stmt [18334,18369]
simple_stmt [18390,18425]
===
match
---
atom_expr [4085,4105]
atom_expr [4141,4161]
===
match
---
operator: , [1627,1628]
operator: , [1627,1628]
===
match
---
trailer [16400,16440]
trailer [16456,16496]
===
match
---
argument [16800,16831]
argument [16856,16887]
===
match
---
trailer [3424,3429]
trailer [3480,3485]
===
match
---
name: dags [2981,2985]
name: dags [3037,3041]
===
match
---
name: json [16619,16623]
name: json [16675,16679]
===
match
---
name: client [6717,6723]
name: client [6773,6779]
===
match
---
name: decode [6197,6203]
name: decode [6253,6259]
===
match
---
trailer [7537,7544]
trailer [7593,7600]
===
match
---
operator: , [17233,17234]
operator: , [17289,17290]
===
match
---
expr_stmt [1928,1975]
expr_stmt [1928,1975]
===
match
---
name: parse [1231,1236]
name: parse [1231,1236]
===
match
---
atom_expr [14584,14604]
atom_expr [14640,14660]
===
match
---
name: task_id [10830,10837]
name: task_id [10886,10893]
===
match
---
operator: = [3936,3937]
operator: = [3992,3993]
===
match
---
number: 200 [18037,18040]
number: 200 [18093,18096]
===
match
---
trailer [11708,11713]
trailer [11764,11769]
===
match
---
atom_expr [14404,14433]
atom_expr [14460,14489]
===
match
---
trailer [15911,15942]
trailer [15967,15998]
===
match
---
operator: - [15334,15335]
operator: - [15390,15391]
===
match
---
name: datetime [1221,1229]
name: datetime [1221,1229]
===
match
---
name: status_code [5267,5278]
name: status_code [5323,5334]
===
match
---
expr_stmt [17256,17603]
expr_stmt [17312,17659]
===
match
---
trailer [15230,15236]
trailer [15286,15292]
===
match
---
trailer [13670,13716]
trailer [13726,13772]
===
match
---
trailer [1642,1649]
trailer [1642,1649]
===
match
---
trailer [1594,1604]
trailer [1594,1604]
===
match
---
number: 1 [15073,15074]
number: 1 [15129,15130]
===
match
---
argument [13571,13600]
argument [13627,13656]
===
match
---
expr_stmt [1513,1652]
expr_stmt [1513,1652]
===
match
---
name: get [3381,3384]
name: get [3437,3440]
===
match
---
name: response [16874,16882]
name: response [16930,16938]
===
match
---
name: datetime_string [10057,10072]
name: datetime_string [10113,10128]
===
match
---
name: self [16851,16855]
name: self [16907,16911]
===
match
---
name: microsecond [9306,9317]
name: microsecond [9362,9373]
===
match
---
name: dag_run [6552,6559]
name: dag_run [6608,6615]
===
match
---
name: self [12309,12313]
name: self [12365,12369]
===
match
---
name: response [5152,5160]
name: response [5208,5216]
===
match
---
comp_op [11693,11699]
comp_op [11749,11755]
===
match
---
atom_expr [16401,16439]
atom_expr [16457,16495]
===
match
---
name: dag_id [11045,11051]
name: dag_id [11101,11107]
===
match
---
trailer [1580,1585]
trailer [1580,1585]
===
match
---
name: pool [15819,15823]
name: pool [15875,15879]
===
match
---
name: microsecond [6277,6288]
name: microsecond [6333,6344]
===
match
---
operator: , [9568,9569]
operator: , [9624,9625]
===
match
---
name: data [9904,9908]
name: data [9960,9964]
===
match
---
operator: = [12544,12545]
operator: = [12600,12601]
===
match
---
expr_stmt [13336,13392]
expr_stmt [13392,13448]
===
match
---
simple_stmt [4605,4660]
simple_stmt [4661,4716]
===
match
---
atom_expr [12309,12371]
atom_expr [12365,12427]
===
match
---
argument [11331,11344]
argument [11387,11400]
===
match
---
argument [7286,7338]
argument [7342,7394]
===
match
---
name: json [18056,18060]
name: json [18112,18116]
===
match
---
operator: == [6250,6252]
operator: == [6306,6308]
===
match
---
name: client [17875,17881]
name: client [17931,17937]
===
match
---
argument [8991,9022]
argument [9047,9078]
===
match
---
name: execution_date [9272,9286]
name: execution_date [9328,9342]
===
match
---
trailer [14365,14377]
trailer [14421,14433]
===
match
---
name: decode [3430,3436]
name: decode [3486,3492]
===
match
---
trailer [3646,3653]
trailer [3702,3709]
===
match
---
trailer [3805,3814]
trailer [3861,3870]
===
match
---
simple_stmt [15994,16082]
simple_stmt [16050,16138]
===
match
---
trailer [16490,16492]
trailer [16546,16548]
===
match
---
expr_stmt [2356,2378]
expr_stmt [2356,2378]
===
match
---
simple_stmt [3398,3447]
simple_stmt [3454,3503]
===
match
---
trailer [4620,4627]
trailer [4676,4683]
===
match
---
atom_expr [6046,6078]
atom_expr [6102,6134]
===
match
---
operator: == [5248,5250]
operator: == [5304,5306]
===
match
---
operator: { [5962,5963]
operator: { [6018,6019]
===
match
---
trailer [15400,15404]
trailer [15456,15460]
===
match
---
number: 404 [6863,6866]
number: 404 [6919,6922]
===
match
---
assert_stmt [10891,10938]
assert_stmt [10947,10994]
===
match
---
name: os [1527,1529]
name: os [1527,1529]
===
match
---
trailer [12461,12470]
trailer [12517,12526]
===
match
---
atom_expr [2323,2347]
atom_expr [2323,2347]
===
match
---
string: 'utf-8' [14652,14659]
string: 'utf-8' [14708,14715]
===
match
---
name: utcnow [11103,11109]
name: utcnow [11159,11165]
===
match
---
simple_stmt [5085,5130]
simple_stmt [5141,5186]
===
match
---
string: 'does_not_exist_dag' [6762,6782]
string: 'does_not_exist_dag' [6818,6838]
===
match
---
string: 'description' [16736,16749]
string: 'description' [16792,16805]
===
match
---
trailer [18528,18530]
trailer [18584,18586]
===
match
---
string: 'example_bash_operator' [4915,4938]
string: 'example_bash_operator' [4971,4994]
===
match
---
name: response [18647,18655]
name: response [18703,18711]
===
match
---
simple_stmt [7403,7436]
simple_stmt [7459,7492]
===
match
---
name: classmethod [2680,2691]
name: classmethod [2736,2747]
===
match
---
atom_expr [4402,4446]
atom_expr [4458,4502]
===
match
---
expr_stmt [13401,13478]
expr_stmt [13457,13534]
===
match
---
operator: , [2410,2411]
operator: , [2410,2411]
===
match
---
operator: = [9138,9139]
operator: = [9194,9195]
===
match
---
trailer [2129,2133]
trailer [2129,2133]
===
match
---
trailer [9682,9689]
trailer [9738,9745]
===
match
---
name: appbuilder [1989,1999]
name: appbuilder [1989,1999]
===
match
---
simple_stmt [16892,16927]
simple_stmt [16948,16983]
===
match
---
atom_expr [1640,1649]
atom_expr [1640,1649]
===
match
---
trailer [8334,8342]
trailer [8390,8398]
===
match
---
atom_expr [15678,15710]
atom_expr [15734,15766]
===
match
---
operator: == [15468,15470]
operator: == [15524,15526]
===
match
---
atom_expr [6157,6232]
atom_expr [6213,6288]
===
match
---
name: application [1330,1341]
name: application [1330,1341]
===
match
---
trailer [8274,8286]
trailer [8330,8342]
===
match
---
simple_stmt [3037,3071]
simple_stmt [3093,3127]
===
match
---
simple_stmt [17063,17096]
simple_stmt [17119,17152]
===
match
---
trailer [3145,3153]
trailer [3201,3209]
===
match
---
trailer [3478,3489]
trailer [3534,3545]
===
match
---
name: utcnow [5818,5824]
name: utcnow [5874,5880]
===
match
---
simple_stmt [10655,10703]
simple_stmt [10711,10759]
===
match
---
atom_expr [15896,15942]
atom_expr [15952,15998]
===
match
---
trailer [14639,14644]
trailer [14695,14700]
===
match
---
name: execution_date [7042,7056]
name: execution_date [7098,7112]
===
match
---
name: quote_plus [11161,11171]
name: quote_plus [11217,11227]
===
match
---
assert_stmt [5645,5696]
assert_stmt [5701,5752]
===
match
---
name: quote_plus [9418,9428]
name: quote_plus [9474,9484]
===
match
---
string: 'utf-8' [5479,5486]
string: 'utf-8' [5535,5542]
===
match
---
trailer [9357,9385]
trailer [9413,9441]
===
match
---
trailer [7231,7394]
trailer [7287,7450]
===
match
---
name: client [13986,13992]
name: client [14042,14048]
===
match
---
assert_stmt [6088,6122]
assert_stmt [6144,6178]
===
match
---
name: get [14279,14282]
name: get [14335,14338]
===
match
---
name: self [13981,13985]
name: self [14037,14041]
===
match
---
assert_stmt [17029,17054]
assert_stmt [17085,17110]
===
match
---
name: response [6069,6077]
name: response [6125,6133]
===
match
---
string: 'DNE' [4162,4167]
string: 'DNE' [4218,4223]
===
match
---
atom_expr [13028,13061]
atom_expr [13084,13117]
===
match
---
atom_expr [5044,5076]
atom_expr [5100,5132]
===
match
---
operator: , [5932,5933]
operator: , [5988,5989]
===
match
---
name: self [9110,9114]
name: self [9166,9170]
===
match
---
trailer [14592,14604]
trailer [14648,14660]
===
match
---
atom_expr [12394,12414]
atom_expr [12450,12470]
===
match
---
name: response [17256,17264]
name: response [17312,17320]
===
match
---
name: get_dagrun [7659,7669]
name: get_dagrun [7715,7725]
===
match
---
trailer [18700,18731]
trailer [18756,18787]
===
match
---
operator: , [10569,10570]
operator: , [10625,10626]
===
match
---
argument [11346,11382]
argument [11402,11438]
===
match
---
operator: } [8487,8488]
operator: } [8543,8544]
===
match
---
name: include_examples [12883,12899]
name: include_examples [12939,12955]
===
match
---
name: cls [2711,2714]
name: cls [2767,2770]
===
match
---
operator: = [15150,15151]
operator: = [15206,15207]
===
match
---
name: get [14511,14514]
name: get [14567,14570]
===
match
---
string: 'utf-8' [6383,6390]
string: 'utf-8' [6439,6446]
===
match
---
name: resp_raw [3358,3366]
name: resp_raw [3414,3422]
===
match
---
trailer [10542,10603]
trailer [10598,10659]
===
match
---
trailer [6794,6800]
trailer [6850,6856]
===
match
---
name: response [13748,13756]
name: response [13804,13812]
===
match
---
name: pool [15267,15271]
name: pool [15323,15327]
===
match
---
name: format [5901,5907]
name: format [5957,5963]
===
match
---
assert_stmt [11622,11669]
assert_stmt [11678,11725]
===
match
---
expr_stmt [7645,7685]
expr_stmt [7701,7741]
===
match
---
trailer [12882,12945]
trailer [12938,13001]
===
match
---
atom_expr [11959,11988]
atom_expr [12015,12044]
===
match
---
argument [15170,15186]
argument [15226,15242]
===
match
---
trailer [7264,7272]
trailer [7320,7328]
===
match
---
atom_expr [12999,13015]
atom_expr [13055,13071]
===
match
---
name: parse [904,909]
name: parse [904,909]
===
match
---
name: response [4575,4583]
name: response [4631,4639]
===
match
---
comparison [10855,10882]
comparison [10911,10938]
===
match
---
trailer [13747,13757]
trailer [13803,13813]
===
match
---
suite [4734,5697]
suite [4790,5753]
===
match
---
name: settings [2323,2331]
name: settings [2323,2331]
===
match
---
name: delete [2849,2855]
name: delete [2905,2911]
===
match
---
name: dags [12972,12976]
name: dags [13028,13032]
===
match
---
name: self [15323,15327]
name: self [15379,15383]
===
match
---
operator: = [7008,7009]
operator: = [7064,7065]
===
match
---
expr_stmt [9238,9263]
expr_stmt [9294,9319]
===
match
---
string: 'error' [9880,9887]
string: 'error' [9936,9943]
===
match
---
atom_expr [16469,16492]
atom_expr [16525,16548]
===
match
---
name: paused_response [5540,5555]
name: paused_response [5596,5611]
===
match
---
name: decode [18715,18721]
name: decode [18771,18777]
===
match
---
operator: = [6789,6790]
operator: = [6845,6846]
===
match
---
name: TestLineageApiExperimental [12479,12505]
name: TestLineageApiExperimental [12535,12561]
===
match
---
name: paused_response [5182,5197]
name: paused_response [5238,5253]
===
match
---
operator: = [14725,14726]
operator: = [14781,14782]
===
match
---
name: USER_POOL_COUNT [15016,15031]
name: USER_POOL_COUNT [15072,15087]
===
match
---
trailer [5478,5487]
trailer [5534,5543]
===
match
---
trailer [4460,4478]
trailer [4516,4534]
===
match
---
trailer [4971,4975]
trailer [5027,5031]
===
match
---
operator: } [8019,8020]
operator: } [8075,8076]
===
match
---
string: 'my_run' [5807,5815]
string: 'my_run' [5863,5871]
===
match
---
string: 'xyz' [4652,4657]
string: 'xyz' [4708,4713]
===
match
---
string: 'example_bash_operator' [9206,9229]
string: 'example_bash_operator' [9262,9285]
===
match
---
arglist [5400,5432]
arglist [5456,5488]
===
match
---
parameters [12661,12666]
parameters [12717,12722]
===
match
---
comparison [8093,8120]
comparison [8149,8176]
===
match
---
atom_expr [11538,11570]
atom_expr [11594,11626]
===
match
---
simple_stmt [2125,2170]
simple_stmt [2125,2170]
===
match
---
trailer [3905,3917]
trailer [3961,3973]
===
match
---
expr_stmt [5847,6037]
expr_stmt [5903,6093]
===
match
---
string: 'utf-8' [8202,8209]
string: 'utf-8' [8258,8265]
===
match
---
trailer [10417,10422]
trailer [10473,10478]
===
match
---
expr_stmt [7582,7599]
expr_stmt [7638,7655]
===
match
---
atom_expr [6183,6212]
atom_expr [6239,6268]
===
match
---
name: status_code [14593,14604]
name: status_code [14649,14660]
===
match
---
param [5723,5727]
param [5779,5783]
===
match
---
name: format [7258,7264]
name: format [7314,7320]
===
match
---
trailer [4907,4914]
trailer [4963,4970]
===
match
---
expr_stmt [16534,16842]
expr_stmt [16590,16898]
===
match
---
name: data [6192,6196]
name: data [6248,6252]
===
match
---
name: response [11912,11920]
name: response [11968,11976]
===
match
---
name: dag [6491,6494]
name: dag [6547,6550]
===
match
---
trailer [9658,9665]
trailer [9714,9721]
===
match
---
operator: , [1616,1617]
operator: , [1616,1617]
===
match
---
name: self [8853,8857]
name: self [8909,8913]
===
match
---
trailer [17271,17278]
trailer [17327,17334]
===
match
---
number: 1990 [11252,11256]
number: 1990 [11308,11312]
===
match
---
assert_stmt [9817,9864]
assert_stmt [9873,9920]
===
match
---
funcdef [1903,2379]
funcdef [1903,2379]
===
match
---
operator: = [6710,6711]
operator: = [6766,6767]
===
match
---
simple_stmt [11941,11989]
simple_stmt [11997,12045]
===
match
---
name: session [3132,3139]
name: session [3188,3195]
===
match
---
atom_expr [16346,16367]
atom_expr [16402,16423]
===
match
---
name: path [1581,1585]
name: path [1581,1585]
===
match
---
comparison [10355,10382]
comparison [10411,10438]
===
match
---
name: response [5847,5855]
name: response [5903,5911]
===
match
---
string: '/api/experimental/lineage/{}/{}' [13191,13224]
string: '/api/experimental/lineage/{}/{}' [13247,13280]
===
match
---
atom_expr [14499,14561]
atom_expr [14555,14617]
===
match
---
trailer [9997,10001]
trailer [10053,10057]
===
match
---
trailer [12313,12320]
trailer [12369,12376]
===
match
---
name: response [11959,11967]
name: response [12015,12023]
===
match
---
trailer [17115,17131]
trailer [17171,17187]
===
match
---
string: 'also_run_this' [9248,9263]
string: 'also_run_this' [9304,9319]
===
match
---
name: data [16962,16966]
name: data [17018,17022]
===
match
---
name: format [8896,8902]
name: format [8952,8958]
===
match
---
comparison [7494,7572]
comparison [7550,7628]
===
match
---
name: status_code [18022,18033]
name: status_code [18078,18089]
===
match
---
name: url_template [3954,3966]
name: url_template [4010,4022]
===
match
---
operator: } [6802,6803]
operator: } [6858,6859]
===
match
---
trailer [2010,2021]
trailer [2010,2021]
===
match
---
dictorsetmaker [5295,5312]
dictorsetmaker [5351,5368]
===
match
---
name: app [1323,1326]
name: app [1323,1326]
===
match
---
strings [2510,2590]
strings [2510,2646]
===
match
---
simple_stmt [10102,10137]
simple_stmt [10158,10193]
===
match
---
parameters [5722,5728]
parameters [5778,5784]
===
match
---
arith_expr [14752,14771]
arith_expr [14808,14827]
===
match
---
name: dag_id [8343,8349]
name: dag_id [8399,8405]
===
match
---
name: tearDown [3080,3088]
name: tearDown [3136,3144]
===
match
---
arglist [9517,9599]
arglist [9573,9655]
===
match
---
simple_stmt [1984,2051]
simple_stmt [1984,2051]
===
match
---
simple_stmt [17104,17163]
simple_stmt [17160,17219]
===
match
---
number: 200 [16923,16926]
number: 200 [16979,16982]
===
match
---
operator: , [16831,16832]
operator: , [16887,16888]
===
match
---
expr_stmt [7855,8077]
expr_stmt [7911,8133]
===
match
---
name: delete [12800,12806]
name: delete [12856,12862]
===
match
---
operator: == [9785,9787]
operator: == [9841,9843]
===
match
---
trailer [3270,3272]
trailer [3326,3328]
===
match
---
trailer [15525,15534]
trailer [15581,15590]
===
match
---
atom_expr [17036,17049]
atom_expr [17092,17105]
===
match
---
name: datetime_string [9698,9713]
name: datetime_string [9754,9769]
===
match
---
trailer [6191,6196]
trailer [6247,6252]
===
match
---
simple_stmt [10891,10939]
simple_stmt [10947,10995]
===
match
---
operator: , [13537,13538]
operator: , [13593,13594]
===
match
---
name: dagbag [12965,12971]
name: dagbag [13021,13027]
===
match
---
trailer [8201,8210]
trailer [8257,8266]
===
match
---
string: 'slots' [17041,17048]
string: 'slots' [17097,17104]
===
match
---
name: query [12780,12785]
name: query [12836,12841]
===
match
---
name: status_code [11921,11932]
name: status_code [11977,11988]
===
match
---
trailer [17040,17049]
trailer [17096,17105]
===
match
---
arglist [7245,7384]
arglist [7301,7440]
===
match
---
name: data [12450,12454]
name: data [12506,12510]
===
match
---
atom [1705,1749]
atom [1705,1749]
===
match
---
name: pause_url_template [4743,4761]
name: pause_url_template [4799,4817]
===
match
---
name: self [4960,4964]
name: self [5016,5020]
===
match
---
comparison [18056,18120]
comparison [18112,18176]
===
match
---
trailer [8593,8600]
trailer [8649,8656]
===
match
---
trailer [10783,10839]
trailer [10839,10895]
===
match
---
atom_expr [5100,5129]
atom_expr [5156,5185]
===
match
---
name: super [12676,12681]
name: super [12732,12737]
===
match
---
operator: = [5356,5357]
operator: = [5412,5413]
===
match
---
expr_stmt [13176,13224]
expr_stmt [13232,13280]
===
match
---
name: session [12817,12824]
name: session [12873,12880]
===
match
---
trailer [16299,16306]
trailer [16355,16362]
===
match
---
atom_expr [3216,3232]
atom_expr [3272,3288]
===
match
---
trailer [15513,15518]
trailer [15569,15574]
===
match
---
name: _get_pool_count [18141,18156]
name: _get_pool_count [18197,18212]
===
match
---
trailer [15315,15320]
trailer [15371,15376]
===
match
---
operator: = [16418,16419]
operator: = [16474,16475]
===
match
---
simple_stmt [5237,5279]
simple_stmt [5293,5335]
===
match
---
comparison [6582,6602]
comparison [6638,6658]
===
match
---
name: self [2178,2182]
name: self [2178,2182]
===
match
---
operator: { [16647,16648]
operator: { [16703,16704]
===
match
---
name: config [2068,2074]
name: config [2068,2074]
===
match
---
trailer [16143,16147]
trailer [16199,16203]
===
match
---
simple_stmt [12298,12372]
simple_stmt [12354,12428]
===
match
---
operator: == [10113,10115]
operator: == [10169,10171]
===
match
---
name: to_json [15824,15831]
name: to_json [15880,15887]
===
match
---
fstring_expr [15068,15075]
fstring_expr [15124,15131]
===
match
---
name: to_json [18111,18118]
name: to_json [18167,18174]
===
match
---
comparison [4248,4275]
comparison [4304,4331]
===
match
---
name: format [3967,3973]
name: format [4023,4029]
===
match
---
dotted_name [1154,1170]
dotted_name [1154,1170]
===
match
---
operator: = [16130,16131]
operator: = [16186,16187]
===
match
---
atom_expr [18395,18424]
atom_expr [18451,18480]
===
match
---
assert_stmt [4561,4595]
assert_stmt [4617,4651]
===
match
---
operator: { [7749,7750]
operator: { [7805,7806]
===
match
---
name: setUpClass [14824,14834]
name: setUpClass [14880,14890]
===
match
---
name: timedelta [7070,7079]
name: timedelta [7126,7135]
===
match
---
atom_expr [13354,13392]
atom_expr [13410,13448]
===
match
---
name: replace [11112,11119]
name: replace [11168,11175]
===
match
---
trailer [17711,17720]
trailer [17767,17776]
===
match
---
operator: , [3997,3998]
operator: , [4053,4054]
===
match
---
operator: , [11268,11269]
operator: , [11324,11325]
===
match
---
classdef [14663,18777]
classdef [14719,18833]
===
match
---
expr_stmt [15885,15942]
expr_stmt [15941,15998]
===
match
---
string: 'example_papermill_operator' [13242,13270]
string: 'example_papermill_operator' [13298,13326]
===
match
---
name: microsecond [11120,11131]
name: microsecond [11176,11187]
===
match
---
trailer [7517,7523]
trailer [7573,7579]
===
match
---
operator: = [4614,4615]
operator: = [4670,4671]
===
match
---
string: 'error' [17712,17719]
string: 'error' [17768,17775]
===
match
---
trailer [11272,11282]
trailer [11328,11338]
===
match
---
name: pool [15647,15651]
name: pool [15703,15707]
===
match
---
name: airflow [1191,1198]
name: airflow [1191,1198]
===
match
---
operator: , [13697,13698]
operator: , [13753,13754]
===
match
---
number: 200 [3890,3893]
number: 200 [3946,3949]
===
match
---
name: decode [3799,3805]
name: decode [3855,3861]
===
match
---
name: url_template [8883,8895]
name: url_template [8939,8951]
===
match
---
name: settings [1162,1170]
name: settings [1162,1170]
===
match
---
string: 'execution_date' [6214,6230]
string: 'execution_date' [6270,6286]
===
match
---
simple_stmt [2178,2218]
simple_stmt [2178,2218]
===
match
---
simple_stmt [1088,1149]
simple_stmt [1088,1149]
===
match
---
operator: , [13461,13462]
operator: , [13517,13518]
===
match
---
expr_stmt [9272,9320]
expr_stmt [9328,9376]
===
match
---
comparison [5244,5278]
comparison [5300,5334]
===
match
---
name: format [4645,4651]
name: format [4701,4707]
===
match
---
simple_stmt [5645,5697]
simple_stmt [5701,5753]
===
match
---
trailer [15493,15536]
trailer [15549,15592]
===
match
---
operator: = [15051,15052]
operator: = [15107,15108]
===
match
---
name: self [16106,16110]
name: self [16162,16166]
===
match
---
name: loads [17675,17680]
name: loads [17731,17736]
===
match
---
arglist [11331,11413]
arglist [11387,11469]
===
match
---
atom_expr [15814,15833]
atom_expr [15870,15889]
===
match
---
expr_stmt [11780,11889]
expr_stmt [11836,11945]
===
match
---
string: 'test_lineage_info_run' [13546,13569]
string: 'test_lineage_info_run' [13602,13625]
===
match
---
name: post [8865,8869]
name: post [8921,8925]
===
match
---
trailer [1543,1652]
trailer [1543,1652]
===
match
---
trailer [7226,7231]
trailer [7282,7287]
===
match
---
simple_stmt [11086,11135]
simple_stmt [11142,11191]
===
match
---
name: decode [14163,14169]
name: decode [14219,14225]
===
match
---
trailer [12553,12558]
trailer [12609,12614]
===
match
---
name: version [1291,1298]
name: version [1291,1298]
===
match
---
atom_expr [15726,15746]
atom_expr [15782,15802]
===
match
---
param [15363,15367]
param [15419,15423]
===
match
---
name: client [5205,5211]
name: client [5261,5267]
===
match
---
name: data [3794,3798]
name: data [3850,3854]
===
match
---
atom_expr [6632,6650]
atom_expr [6688,6706]
===
match
---
name: path [1565,1569]
name: path [1565,1569]
===
match
---
trailer [2855,2857]
trailer [2911,2913]
===
match
---
trailer [15823,15831]
trailer [15879,15887]
===
match
---
operator: , [11265,11266]
operator: , [11321,11322]
===
match
---
number: 1 [11270,11271]
number: 1 [11326,11327]
===
match
---
name: config [1364,1370]
name: config [1364,1370]
===
match
---
name: self [5723,5727]
name: self [5779,5783]
===
match
---
name: decode [16967,16973]
name: decode [17023,17029]
===
match
---
operator: == [17050,17052]
operator: == [17106,17108]
===
match
---
fstring_start: f' [15615,15617]
fstring_start: f' [15671,15673]
===
match
---
atom_expr [9418,9471]
atom_expr [9474,9527]
===
match
---
name: self [17267,17271]
name: self [17323,17327]
===
match
---
trailer [3520,3530]
trailer [3576,3586]
===
match
---
trailer [5373,5434]
trailer [5429,5490]
===
match
---
name: datetime [9429,9437]
name: datetime [9485,9493]
===
match
---
atom_expr [12325,12370]
atom_expr [12381,12426]
===
match
---
atom_expr [7245,7272]
atom_expr [7301,7328]
===
match
---
trailer [16285,16316]
trailer [16341,16372]
===
match
---
name: self [15249,15253]
name: self [15305,15309]
===
match
---
name: dagbag [8328,8334]
name: dagbag [8384,8390]
===
match
---
testlist_comp [1819,1891]
testlist_comp [1819,1891]
===
match
---
string: '/api/experimental/dags/{}/dag_runs/{}' [10997,11036]
string: '/api/experimental/dags/{}/dag_runs/{}' [11053,11092]
===
match
---
import_from [958,1025]
import_from [958,1025]
===
match
---
expr_stmt [14733,14771]
expr_stmt [14789,14827]
===
match
---
name: status_code [6111,6122]
name: status_code [6167,6178]
===
match
---
simple_stmt [835,866]
simple_stmt [835,866]
===
match
---
expr_stmt [9197,9229]
expr_stmt [9253,9285]
===
match
---
name: execution_date [11086,11100]
name: execution_date [11142,11156]
===
match
---
param [2406,2411]
param [2406,2411]
===
match
---
comparison [15958,15985]
comparison [16014,16041]
===
match
---
string: 'slots' [17445,17452]
string: 'slots' [17501,17508]
===
match
---
name: json [17349,17353]
name: json [17405,17409]
===
match
---
trailer [6213,6231]
trailer [6269,6287]
===
match
---
atom_expr [5374,5433]
atom_expr [5430,5489]
===
match
---
simple_stmt [7204,7395]
simple_stmt [7260,7451]
===
match
---
trailer [13302,13304]
trailer [13358,13360]
===
match
---
string: 'error' [14620,14627]
string: 'error' [14676,14683]
===
match
---
comparison [14350,14377]
comparison [14406,14433]
===
match
---
atom_expr [18341,18361]
atom_expr [18397,18417]
===
match
---
comparison [17111,17162]
comparison [17167,17218]
===
match
---
name: status_code [7467,7478]
name: status_code [7523,7534]
===
match
---
operator: , [17539,17540]
operator: , [17595,17596]
===
match
---
string: '/api/experimental/pools/foo' [18285,18314]
string: '/api/experimental/pools/foo' [18341,18370]
===
match
---
name: airflow [963,970]
name: airflow [963,970]
===
match
---
trailer [12105,12112]
trailer [12161,12168]
===
match
---
arglist [4162,4174]
arglist [4218,4230]
===
match
---
operator: = [10766,10767]
operator: = [10822,10823]
===
match
---
atom [8652,8687]
atom [8708,8743]
===
match
---
name: self [6712,6716]
name: self [6768,6772]
===
match
---
simple_stmt [15762,15834]
simple_stmt [15818,15890]
===
match
---
operator: , [12594,12595]
operator: , [12650,12651]
===
match
---
simple_stmt [7694,7767]
simple_stmt [7750,7823]
===
match
---
number: 400 [18671,18674]
number: 400 [18727,18730]
===
match
---
argument [17557,17588]
argument [17613,17644]
===
match
---
atom_expr [8767,8787]
atom_expr [8823,8843]
===
match
---
import_name [819,834]
import_name [819,834]
===
match
---
trailer [10803,10838]
trailer [10859,10894]
===
match
---
parameters [13160,13166]
parameters [13216,13222]
===
match
---
name: get [4398,4401]
name: get [4454,4457]
===
match
---
operator: = [9652,9653]
operator: = [9708,9709]
===
match
---
name: resp_raw [3521,3529]
name: resp_raw [3577,3585]
===
match
---
trailer [11660,11669]
trailer [11716,11725]
===
match
---
name: super [14849,14854]
name: super [14905,14910]
===
match
---
atom_expr [7655,7685]
atom_expr [7711,7741]
===
match
---
atom_expr [1939,1975]
atom_expr [1939,1975]
===
match
---
name: self [12077,12081]
name: self [12133,12137]
===
match
---
trailer [17359,17539]
trailer [17415,17595]
===
match
---
operator: , [10592,10593]
operator: , [10648,10649]
===
match
---
name: url_template [12325,12337]
name: url_template [12381,12393]
===
match
---
name: os [1562,1564]
name: os [1562,1564]
===
match
---
fstring_expr [17928,17944]
fstring_expr [17984,18000]
===
match
---
trailer [9372,9382]
trailer [9428,9438]
===
match
---
trailer [5562,5569]
trailer [5618,5625]
===
match
---
operator: , [2590,2591]
operator: , [2646,2647]
===
match
---
simple_stmt [18049,18121]
simple_stmt [18105,18177]
===
match
---
name: client [10532,10538]
name: client [10588,10594]
===
match
---
number: 200 [6095,6098]
number: 200 [6151,6154]
===
match
---
string: "example_dags" [12609,12623]
string: "example_dags" [12665,12679]
===
match
---
name: client [12314,12320]
name: client [12370,12376]
===
match
---
name: dont_initialize_flask_app_submodules [1756,1792]
name: dont_initialize_flask_app_submodules [1756,1792]
===
match
---
name: format [14023,14029]
name: format [14079,14085]
===
match
---
string: 'example_bash_operator' [5002,5025]
string: 'example_bash_operator' [5058,5081]
===
match
---
param [16106,16110]
param [16162,16166]
===
match
---
name: models [1101,1107]
name: models [1101,1107]
===
match
---
trailer [11503,11528]
trailer [11559,11584]
===
match
---
trailer [4536,4543]
trailer [4592,4599]
===
match
---
name: pools [15328,15333]
name: pools [15384,15389]
===
match
---
trailer [17933,17938]
trailer [17989,17994]
===
match
---
funcdef [14820,14870]
funcdef [14876,14926]
===
match
---
name: data [5109,5113]
name: data [5165,5169]
===
match
---
name: url_template [10982,10994]
name: url_template [11038,11050]
===
match
---
name: _get_pool_count [17116,17131]
name: _get_pool_count [17172,17187]
===
match
---
name: format [9683,9689]
name: format [9739,9745]
===
match
---
trailer [13666,13670]
trailer [13722,13726]
===
match
---
name: paused_url_template [4810,4829]
name: paused_url_template [4866,4885]
===
match
---
trailer [18110,18118]
trailer [18166,18174]
===
match
---
operator: } [5671,5672]
operator: } [5727,5728]
===
match
---
trailer [9382,9384]
trailer [9438,9440]
===
match
---
argument [16415,16438]
argument [16471,16494]
===
match
---
name: self [15363,15367]
name: self [15419,15423]
===
match
---
atom_expr [17670,17720]
atom_expr [17726,17776]
===
match
---
parameters [3302,3308]
parameters [3358,3364]
===
match
---
expr_stmt [8129,8230]
expr_stmt [8185,8286]
===
match
---
atom_expr [15011,15031]
atom_expr [15067,15087]
===
match
---
name: client [10773,10779]
name: client [10829,10835]
===
match
---
name: close [2899,2904]
name: close [2955,2960]
===
match
---
expr_stmt [15046,15076]
expr_stmt [15102,15132]
===
match
---
name: get [11803,11806]
name: get [11859,11862]
===
match
---
atom_expr [4523,4552]
atom_expr [4579,4608]
===
match
---
number: 404 [10355,10358]
number: 404 [10411,10414]
===
match
---
trailer [18060,18066]
trailer [18116,18122]
===
match
---
trailer [2608,2616]
trailer [2664,2672]
===
match
---
name: dag [2967,2970]
name: dag [3023,3026]
===
match
---
name: decode [10687,10693]
name: decode [10743,10749]
===
match
---
arglist [11504,11527]
arglist [11560,11583]
===
match
---
name: response [17859,17867]
name: response [17915,17923]
===
match
---
atom_expr [7291,7338]
atom_expr [7347,7394]
===
match
---
parameters [4302,4308]
parameters [4358,4364]
===
match
---
string: 'utf-8' [11980,11987]
string: 'utf-8' [12036,12043]
===
match
---
fstring [15053,15076]
fstring [15109,15132]
===
match
---
operator: , [8622,8623]
operator: , [8678,8679]
===
match
---
trailer [15700,15710]
trailer [15756,15766]
===
match
---
trailer [6800,6804]
trailer [6856,6860]
===
match
---
atom_expr [13296,13327]
atom_expr [13352,13383]
===
match
---
param [16426,16427]
param [16482,16483]
===
match
---
name: format [4415,4421]
name: format [4471,4477]
===
match
---
name: get [10539,10542]
name: get [10595,10598]
===
match
---
string: 'state' [11629,11636]
string: 'state' [11685,11692]
===
match
---
funcdef [3536,4276]
funcdef [3592,4332]
===
match
---
operator: == [18034,18036]
operator: == [18090,18092]
===
match
---
name: test_delete_default_pool [18474,18498]
name: test_delete_default_pool [18530,18554]
===
match
---
atom_expr [2821,2857]
atom_expr [2877,2913]
===
match
---
name: tests [1393,1398]
name: tests [1393,1398]
===
match
---
atom [5652,5672]
atom [5708,5728]
===
match
---
name: get_dagrun [6495,6505]
name: get_dagrun [6551,6561]
===
match
---
arglist [15615,15659]
arglist [15671,15715]
===
match
---
name: close [3249,3254]
name: close [3305,3310]
===
match
---
operator: , [16600,16601]
operator: , [16656,16657]
===
match
---
trailer [6416,6418]
trailer [6472,6474]
===
match
---
name: response [16286,16294]
name: response [16342,16350]
===
match
---
param [18499,18503]
param [18555,18559]
===
match
---
assert_stmt [8239,8286]
assert_stmt [8295,8342]
===
match
---
name: Session [3114,3121]
name: Session [3170,3177]
===
match
---
name: client [8556,8562]
name: client [8612,8618]
===
match
---
name: test_utils [1399,1409]
name: test_utils [1399,1409]
===
match
---
name: response [9643,9651]
name: response [9699,9707]
===
match
---
operator: , [17945,17946]
operator: , [18001,18002]
===
match
---
string: 'replace_microseconds' [7989,8011]
string: 'replace_microseconds' [8045,8067]
===
match
---
name: self [9654,9658]
name: self [9710,9714]
===
match
---
dictorsetmaker [17407,17499]
dictorsetmaker [17463,17555]
===
match
---
operator: == [6099,6101]
operator: == [6155,6157]
===
match
---
name: response [8767,8775]
name: response [8823,8831]
===
match
---
simple_stmt [3171,3208]
simple_stmt [3227,3264]
===
match
---
assert_stmt [13766,13800]
assert_stmt [13822,13856]
===
match
---
simple_stmt [9733,9766]
simple_stmt [9789,9822]
===
match
---
name: decode [4047,4053]
name: decode [4103,4109]
===
match
---
operator: = [2762,2763]
operator: = [2818,2819]
===
match
---
name: decode [10923,10929]
name: decode [10979,10985]
===
match
---
name: response [9756,9764]
name: response [9812,9820]
===
match
---
name: assert_deprecated [16856,16873]
name: assert_deprecated [16912,16929]
===
match
---
assert_stmt [18334,18368]
assert_stmt [18390,18424]
===
match
---
name: response [12167,12175]
name: response [12223,12231]
===
match
---
trailer [13312,13327]
trailer [13368,13383]
===
match
---
trailer [16973,16982]
trailer [17029,17038]
===
match
---
expr_stmt [4810,4866]
expr_stmt [4866,4922]
===
match
---
trailer [11648,11653]
trailer [11704,11709]
===
match
---
operator: , [13452,13453]
operator: , [13508,13509]
===
match
---
name: dag [7608,7611]
name: dag [7664,7667]
===
match
---
name: status_code [3906,3917]
name: status_code [3962,3973]
===
match
---
name: response [18701,18709]
name: response [18757,18765]
===
match
---
name: TestBase [1661,1669]
name: TestBase [1661,1669]
===
match
---
comparison [5602,5636]
comparison [5658,5692]
===
match
---
name: response [4375,4383]
name: response [4431,4439]
===
match
---
arglist [11820,11879]
arglist [11876,11935]
===
match
---
name: datetime_string [7321,7336]
name: datetime_string [7377,7392]
===
match
---
simple_stmt [11898,11933]
simple_stmt [11954,11989]
===
match
---
comp_op [3838,3844]
comp_op [3894,3900]
===
match
---
trailer [4994,5001]
trailer [5050,5057]
===
match
---
name: self [15678,15682]
name: self [15734,15738]
===
match
---
trailer [4141,4176]
trailer [4197,4232]
===
match
---
name: datetime_string [9329,9344]
name: datetime_string [9385,9400]
===
match
---
operator: = [7653,7654]
operator: = [7709,7710]
===
match
---
trailer [12222,12227]
trailer [12278,12283]
===
match
---
comparison [5294,5337]
comparison [5350,5393]
===
match
---
trailer [3670,3677]
trailer [3726,3733]
===
match
---
name: pool [15089,15093]
name: pool [15145,15149]
===
match
---
simple_stmt [5044,5077]
simple_stmt [5100,5133]
===
match
---
name: response [14631,14639]
name: response [14687,14695]
===
match
---
assert_stmt [14343,14377]
assert_stmt [14399,14433]
===
match
---
name: assert_deprecated [2388,2405]
name: assert_deprecated [2388,2405]
===
match
---
simple_stmt [8129,8231]
simple_stmt [8185,8287]
===
match
---
atom_expr [8251,8286]
atom_expr [8307,8342]
===
match
---
arglist [3974,4004]
arglist [4030,4060]
===
match
---
atom_expr [14357,14377]
atom_expr [14413,14433]
===
match
---
trailer [15831,15833]
trailer [15887,15889]
===
match
---
simple_stmt [7645,7686]
simple_stmt [7701,7742]
===
match
---
atom_expr [12817,12833]
atom_expr [12873,12889]
===
match
---
name: json [3405,3409]
name: json [3461,3465]
===
match
---
atom_expr [6351,6392]
atom_expr [6407,6448]
===
match
---
number: 404 [10619,10622]
number: 404 [10675,10678]
===
match
---
number: 404 [14350,14353]
number: 404 [14406,14409]
===
match
---
trailer [2803,2810]
trailer [2859,2866]
===
match
---
name: self [13725,13729]
name: self [13781,13785]
===
match
---
name: assert_deprecated [7408,7425]
name: assert_deprecated [7464,7481]
===
match
---
dotted_name [1093,1122]
dotted_name [1093,1122]
===
match
---
name: loads [6356,6361]
name: loads [6412,6417]
===
match
---
parameters [17202,17208]
parameters [17258,17264]
===
match
---
atom_expr [13655,13716]
atom_expr [13711,13772]
===
match
---
name: get_dag [6440,6447]
name: get_dag [6496,6503]
===
match
---
trailer [10922,10929]
trailer [10978,10985]
===
match
---
operator: , [7987,7988]
operator: , [8043,8044]
===
match
---
arglist [1562,1649]
arglist [1562,1649]
===
match
---
suite [17209,17818]
suite [17265,17874]
===
match
---
name: quote_plus [13425,13435]
name: quote_plus [13481,13491]
===
match
---
fstring_start: f' [8433,8435]
fstring_start: f' [8489,8491]
===
match
---
name: dagbag [6433,6439]
name: dagbag [6489,6495]
===
match
---
suite [10973,12471]
suite [11029,12527]
===
match
---
number: 1 [9456,9457]
number: 1 [9512,9513]
===
match
---
operator: , [1605,1606]
operator: , [1605,1606]
===
match
---
atom_expr [6870,6890]
atom_expr [6926,6946]
===
match
---
name: response [11593,11601]
name: response [11649,11657]
===
match
---
trailer [4397,4401]
trailer [4453,4457]
===
match
---
trailer [12548,12553]
trailer [12604,12609]
===
match
---
atom_expr [7458,7478]
atom_expr [7514,7534]
===
match
---
string: 'does_not_exist_dag' [8601,8621]
string: 'does_not_exist_dag' [8657,8677]
===
match
---
operator: = [13423,13424]
operator: = [13479,13480]
===
match
---
atom_expr [5251,5278]
atom_expr [5307,5334]
===
match
---
operator: = [4124,4125]
operator: = [4180,4181]
===
match
---
name: resp [2444,2448]
name: resp [2444,2448]
===
match
---
name: to_json [16483,16490]
name: to_json [16539,16546]
===
match
---
name: loads [16280,16285]
name: loads [16336,16341]
===
match
---
operator: , [16413,16414]
operator: , [16469,16470]
===
match
---
name: write_dag [3056,3065]
name: write_dag [3112,3121]
===
match
---
arglist [10804,10837]
arglist [10860,10893]
===
match
---
atom_expr [2002,2021]
atom_expr [2002,2021]
===
match
---
name: self [9986,9990]
name: self [10042,10046]
===
match
---
simple_stmt [1149,1186]
simple_stmt [1149,1186]
===
match
---
atom_expr [4126,4176]
atom_expr [4182,4232]
===
match
---
fstring_end: ' [15075,15076]
fstring_end: ' [15131,15132]
===
match
---
atom_expr [8181,8210]
atom_expr [8237,8266]
===
match
---
string: '/api/experimental/pools/default_pool' [18582,18620]
string: '/api/experimental/pools/default_pool' [18638,18676]
===
match
---
name: response_execution_date [8251,8274]
name: response_execution_date [8307,8330]
===
match
---
atom_expr [8883,8910]
atom_expr [8939,8966]
===
match
---
trailer [14169,14178]
trailer [14225,14234]
===
match
---
trailer [13435,13478]
trailer [13491,13534]
===
match
---
name: trigger_dag [11319,11330]
name: trigger_dag [11375,11386]
===
match
---
simple_stmt [12380,12415]
simple_stmt [12436,12471]
===
match
---
atom_expr [17770,17792]
atom_expr [17826,17848]
===
match
---
name: decode [8195,8201]
name: decode [8251,8257]
===
match
---
operator: = [15321,15322]
operator: = [15377,15378]
===
match
---
parameters [3088,3094]
parameters [3144,3150]
===
match
---
atom_expr [11243,11284]
atom_expr [11299,11340]
===
match
---
param [10967,10971]
param [11023,11027]
===
match
---
trailer [16239,16251]
trailer [16295,16307]
===
match
---
name: dag_run [7645,7652]
name: dag_run [7701,7708]
===
match
---
param [2412,2416]
param [2412,2416]
===
match
---
operator: = [1969,1970]
operator: = [1969,1970]
===
match
---
operator: = [11398,11399]
operator: = [11454,11455]
===
match
---
name: response [8540,8548]
name: response [8596,8604]
===
match
---
operator: = [8640,8641]
operator: = [8696,8697]
===
match
---
param [14885,14889]
param [14941,14945]
===
match
---
atom_expr [17111,17133]
atom_expr [17167,17189]
===
match
---
atom_expr [9788,9808]
atom_expr [9844,9864]
===
match
---
trailer [14503,14510]
trailer [14559,14566]
===
match
---
import_from [835,865]
import_from [835,865]
===
match
---
atom_expr [15769,15810]
atom_expr [15825,15866]
===
match
---
trailer [5862,5869]
trailer [5918,5925]
===
match
---
trailer [8180,8211]
trailer [8236,8267]
===
match
---
comparison [18647,18674]
comparison [18703,18730]
===
match
---
name: api [971,974]
name: api [971,974]
===
match
---
simple_stmt [9774,9809]
simple_stmt [9830,9865]
===
match
---
operator: = [6489,6490]
operator: = [6545,6546]
===
match
---
arglist [10015,10083]
arglist [10071,10139]
===
match
---
argument [15145,15152]
argument [15201,15208]
===
match
---
name: os [1640,1642]
name: os [1640,1642]
===
match
---
name: dumps [6795,6800]
name: dumps [6851,6856]
===
match
---
string: 'rel="deprecation"; type="text/html"' [2553,2590]
string: 'rel="deprecation"; type="text/html"' [2609,2646]
===
match
---
simple_stmt [13401,13479]
simple_stmt [13457,13535]
===
match
---
trailer [15818,15823]
trailer [15874,15879]
===
match
---
trailer [1564,1569]
trailer [1564,1569]
===
match
---
operator: { [15641,15642]
operator: { [15697,15698]
===
match
---
simple_stmt [6340,6393]
simple_stmt [6396,6449]
===
match
---
name: dag_id [11504,11510]
name: dag_id [11560,11566]
===
match
---
trailer [2931,2954]
trailer [2987,3010]
===
match
---
fstring_string: Dag Run not found for execution date  [7712,7749]
fstring_string: Dag Run not found for execution date  [7768,7805]
===
match
---
simple_stmt [9197,9230]
simple_stmt [9253,9286]
===
match
---
atom_expr [14515,14560]
atom_expr [14571,14616]
===
match
---
trailer [12454,12461]
trailer [12510,12517]
===
match
---
arglist [5002,5033]
arglist [5058,5089]
===
match
---
operator: = [5805,5806]
operator: = [5861,5862]
===
match
---
simple_stmt [15378,15432]
simple_stmt [15434,15488]
===
match
---
fstring_string: /api/experimental/pools/ [15617,15641]
fstring_string: /api/experimental/pools/ [15673,15697]
===
match
---
name: self [9733,9737]
name: self [9789,9793]
===
match
---
trailer [12402,12414]
trailer [12458,12470]
===
match
---
trailer [14412,14417]
trailer [14468,14473]
===
match
---
trailer [17701,17710]
trailer [17757,17766]
===
match
---
name: assert_deprecated [9738,9755]
name: assert_deprecated [9794,9811]
===
match
---
comparison [16899,16926]
comparison [16955,16982]
===
match
---
funcdef [18470,18777]
funcdef [18526,18833]
===
match
---
funcdef [15343,15537]
funcdef [15399,15593]
===
match
---
simple_stmt [892,928]
simple_stmt [892,928]
===
match
---
name: response [18395,18403]
name: response [18451,18459]
===
match
---
atom_expr [9289,9320]
atom_expr [9345,9376]
===
match
---
simple_stmt [16224,16259]
simple_stmt [16280,16315]
===
match
---
string: '/api/experimental/dags/{}/code' [4333,4365]
string: '/api/experimental/dags/{}/code' [4389,4421]
===
match
---
name: pool [17070,17074]
name: pool [17126,17130]
===
match
---
expr_stmt [4743,4801]
expr_stmt [4799,4857]
===
match
---
trailer [6176,6182]
trailer [6232,6238]
===
match
---
trailer [6276,6288]
trailer [6332,6344]
===
match
---
expr_stmt [7204,7394]
expr_stmt [7260,7450]
===
match
---
trailer [8645,8651]
trailer [8701,8707]
===
match
---
trailer [15293,15300]
trailer [15349,15356]
===
match
---
name: self [17203,17207]
name: self [17259,17263]
===
match
---
name: execution_date [11172,11186]
name: execution_date [11228,11242]
===
match
---
name: dag_id [13233,13239]
name: dag_id [13289,13295]
===
match
---
number: 1 [16713,16714]
number: 1 [16769,16770]
===
match
---
operator: , [7708,7709]
operator: , [7764,7765]
===
match
---
param [3555,3559]
param [3611,3615]
===
match
---
atom_expr [5510,5530]
atom_expr [5566,5586]
===
match
---
operator: , [10055,10056]
operator: , [10111,10112]
===
match
---
trailer [11330,11414]
trailer [11386,11470]
===
match
---
trailer [15504,15535]
trailer [15560,15591]
===
match
---
name: self [3642,3646]
name: self [3698,3702]
===
match
---
operator: == [15979,15981]
operator: == [16035,16037]
===
match
---
name: client [3374,3380]
name: client [3430,3436]
===
match
---
operator: = [3403,3404]
operator: = [3459,3460]
===
match
---
string: 'run_id' [5963,5971]
string: 'run_id' [6019,6027]
===
match
---
atom_expr [10409,10438]
atom_expr [10465,10494]
===
match
---
string: 'utf-8' [17702,17709]
string: 'utf-8' [17758,17765]
===
match
---
name: self [7866,7870]
name: self [7922,7926]
===
match
---
trailer [5691,5696]
trailer [5747,5752]
===
match
---
name: client [4391,4397]
name: client [4447,4453]
===
match
---
atom_expr [8155,8230]
atom_expr [8211,8286]
===
match
---
trailer [11839,11878]
trailer [11895,11934]
===
match
---
operator: = [18548,18549]
operator: = [18604,18605]
===
match
---
name: self [13161,13165]
name: self [13217,13221]
===
match
---
atom_expr [5558,5585]
atom_expr [5614,5641]
===
match
---
name: response [6701,6709]
name: response [6757,6765]
===
match
---
name: response [11700,11708]
name: response [11756,11764]
===
match
---
operator: , [9445,9446]
operator: , [9501,9502]
===
match
---
trailer [2186,2193]
trailer [2186,2193]
===
match
---
trailer [13992,13996]
trailer [14048,14052]
===
match
---
expr_stmt [2916,2954]
expr_stmt [2972,3010]
===
match
---
comparison [3463,3489]
comparison [3519,3545]
===
match
---
simple_stmt [9329,9386]
simple_stmt [9385,9442]
===
match
---
suite [13167,14661]
suite [13223,14717]
===
match
---
trailer [11802,11806]
trailer [11858,11862]
===
match
---
operator: = [11466,11467]
operator: = [11522,11523]
===
match
---
operator: == [10359,10361]
operator: == [10415,10417]
===
match
---
atom_expr [15281,15302]
atom_expr [15337,15358]
===
match
---
trailer [15734,15746]
trailer [15790,15802]
===
match
---
operator: = [2290,2291]
operator: = [2290,2291]
===
match
---
atom_expr [15958,15978]
atom_expr [16014,16034]
===
match
---
trailer [16549,16556]
trailer [16605,16612]
===
match
---
atom_expr [1670,1687]
atom_expr [1670,1687]
===
match
---
assert_stmt [7487,7572]
assert_stmt [7543,7628]
===
match
---
comparison [9880,9924]
comparison [9936,9980]
===
match
---
trailer [16187,16205]
trailer [16243,16261]
===
match
---
name: client [18258,18264]
name: client [18314,18320]
===
match
---
name: pools [16336,16341]
name: pools [16392,16397]
===
match
---
string: 'not_a_datetime' [10812,10828]
string: 'not_a_datetime' [10868,10884]
===
match
---
trailer [16042,16051]
trailer [16098,16107]
===
match
---
name: client [10260,10266]
name: client [10316,10322]
===
match
---
trailer [15793,15800]
trailer [15849,15856]
===
match
---
trailer [9737,9755]
trailer [9793,9811]
===
match
---
name: range [15005,15010]
name: range [15061,15066]
===
match
---
name: dag_id [11338,11344]
name: dag_id [11394,11400]
===
match
---
name: search [2490,2496]
name: search [2490,2496]
===
match
---
name: decode [15519,15525]
name: decode [15575,15581]
===
match
---
arglist [14303,14332]
arglist [14359,14388]
===
match
---
simple_stmt [15483,15537]
simple_stmt [15539,15593]
===
match
---
trailer [6728,6847]
trailer [6784,6903]
===
match
---
name: airflow [934,941]
name: airflow [934,941]
===
match
---
name: response [7426,7434]
name: response [7482,7490]
===
match
---
string: 'utf-8' [5121,5128]
string: 'utf-8' [5177,5184]
===
match
---
name: status_code [5625,5636]
name: status_code [5681,5692]
===
match
---
string: 'error' [10398,10405]
string: 'error' [10454,10461]
===
match
---
atom_expr [17349,17539]
atom_expr [17405,17595]
===
match
---
trailer [11601,11613]
trailer [11657,11669]
===
match
---
trailer [7882,8077]
trailer [7938,8133]
===
match
---
argument [8035,8066]
argument [8091,8122]
===
match
---
operator: { [8472,8473]
operator: { [8528,8529]
===
match
---
trailer [12558,12624]
trailer [12614,12680]
===
match
---
operator: == [16252,16254]
operator: == [16308,16310]
===
match
---
trailer [14856,14867]
trailer [14912,14923]
===
match
---
name: _get_pool_count [15347,15362]
name: _get_pool_count [15403,15418]
===
match
---
string: "airflow" [12572,12581]
string: "airflow" [12628,12637]
===
match
---
atom_expr [14283,14333]
atom_expr [14339,14389]
===
match
---
atom_expr [15494,15535]
atom_expr [15550,15591]
===
match
---
parameters [15869,15875]
parameters [15925,15931]
===
match
---
dictorsetmaker [16669,16754]
dictorsetmaker [16725,16810]
===
match
---
trailer [5573,5585]
trailer [5629,5641]
===
match
---
argument [13539,13569]
argument [13595,13625]
===
match
---
trailer [15300,15302]
trailer [15356,15358]
===
match
---
name: response [3631,3639]
name: response [3687,3695]
===
match
---
atom_expr [10909,10938]
atom_expr [10965,10994]
===
match
---
expr_stmt [12298,12371]
expr_stmt [12354,12427]
===
match
---
name: response [14488,14496]
name: response [14544,14552]
===
match
---
trailer [9305,9320]
trailer [9361,9376]
===
match
---
number: 1 [17053,17054]
number: 1 [17109,17110]
===
match
---
trailer [11171,11199]
trailer [11227,11255]
===
match
---
name: dumps [8646,8651]
name: dumps [8702,8707]
===
match
---
operator: = [9345,9346]
operator: = [9401,9402]
===
match
---
name: self [3938,3942]
name: self [3994,3998]
===
match
---
string: 'pool' [16431,16437]
string: 'pool' [16487,16493]
===
match
---
name: self [15214,15218]
name: self [15270,15274]
===
match
---
name: paused_url_template [4888,4907]
name: paused_url_template [4944,4963]
===
match
---
expr_stmt [16121,16174]
expr_stmt [16177,16230]
===
match
---
name: self [17929,17933]
name: self [17985,17989]
===
match
---
name: url_template [9670,9682]
name: url_template [9726,9738]
===
match
---
name: dag_id [12345,12351]
name: dag_id [12401,12407]
===
match
---
atom_expr [3171,3207]
atom_expr [3227,3263]
===
match
---
name: write_dag [13047,13056]
name: write_dag [13103,13112]
===
match
---
string: 'error' [14393,14400]
string: 'error' [14449,14456]
===
match
---
atom_expr [6102,6122]
atom_expr [6158,6178]
===
match
---
atom_expr [6253,6288]
atom_expr [6309,6344]
===
match
---
expr_stmt [8296,8313]
expr_stmt [8352,8369]
===
match
---
name: self [4456,4460]
name: self [4512,4516]
===
match
---
name: data [11649,11653]
name: data [11705,11709]
===
match
---
name: get [15908,15911]
name: get [15964,15967]
===
match
---
expr_stmt [5182,5227]
expr_stmt [5238,5283]
===
match
---
atom_expr [9986,10093]
atom_expr [10042,10149]
===
match
---
name: Pool [1069,1073]
name: Pool [1069,1073]
===
match
---
atom_expr [12965,12985]
atom_expr [13021,13041]
===
match
---
name: data [3425,3429]
name: data [3481,3485]
===
match
---
atom_expr [3498,3530]
atom_expr [3554,3586]
===
match
---
trailer [3858,3865]
trailer [3914,3921]
===
match
---
operator: = [4830,4831]
operator: = [4886,4887]
===
match
---
expr_stmt [3631,3714]
expr_stmt [3687,3770]
===
match
---
trailer [4401,4447]
trailer [4457,4503]
===
match
---
name: utcnow [7059,7065]
name: utcnow [7115,7121]
===
match
---
name: response [4682,4690]
name: response [4738,4746]
===
match
---
trailer [5369,5373]
trailer [5425,5429]
===
match
---
simple_stmt [6481,6531]
simple_stmt [6537,6587]
===
match
---
comparison [10662,10702]
comparison [10718,10758]
===
match
---
atom_expr [2226,2261]
atom_expr [2226,2261]
===
match
---
name: format [4908,4914]
name: format [4964,4970]
===
match
---
name: sorted [16401,16407]
name: sorted [16457,16463]
===
match
---
trailer [13465,13475]
trailer [13521,13531]
===
match
---
name: dagbag [8296,8302]
name: dagbag [8352,8358]
===
match
---
operator: + [5816,5817]
operator: + [5872,5873]
===
match
---
atom_expr [15389,15431]
atom_expr [15445,15487]
===
match
---
operator: , [1712,1713]
operator: , [1712,1713]
===
match
---
trailer [8939,8977]
trailer [8995,9033]
===
match
---
operator: == [4252,4254]
operator: == [4308,4310]
===
match
---
trailer [13690,13715]
trailer [13746,13771]
===
match
---
name: response [4605,4613]
name: response [4661,4669]
===
match
---
name: json [16001,16005]
name: json [16057,16061]
===
match
---
name: url_template [4632,4644]
name: url_template [4688,4700]
===
match
---
arglist [18582,18621]
arglist [18638,18677]
===
match
---
operator: , [12607,12608]
operator: , [12663,12664]
===
match
---
name: data [6785,6789]
name: data [6841,6845]
===
match
---
operator: { [5652,5653]
operator: { [5708,5709]
===
match
---
name: get [10267,10270]
name: get [10323,10326]
===
match
---
name: status_code [4584,4595]
name: status_code [4640,4651]
===
match
---
operator: , [10810,10811]
operator: , [10866,10867]
===
match
---
simple_stmt [12066,12145]
simple_stmt [12122,12201]
===
match
---
trailer [2489,2496]
trailer [2489,2496]
===
match
---
trailer [18075,18080]
trailer [18131,18136]
===
match
---
operator: == [14581,14583]
operator: == [14637,14639]
===
match
---
trailer [18554,18561]
trailer [18610,18617]
===
match
---
trailer [4478,4488]
trailer [4534,4544]
===
match
---
name: i [15000,15001]
name: i [15056,15057]
===
match
---
trailer [7952,8021]
trailer [8008,8077]
===
match
---
trailer [8108,8120]
trailer [8164,8176]
===
match
---
name: response [9056,9064]
name: response [9112,9120]
===
match
---
string: 'utf-8' [11721,11728]
string: 'utf-8' [11777,11784]
===
match
---
name: trigger_dag [13512,13523]
name: trigger_dag [13568,13579]
===
match
---
operator: } [5312,5313]
operator: } [5368,5369]
===
match
---
simple_stmt [8322,8351]
simple_stmt [8378,8407]
===
match
---
argument [8702,8733]
argument [8758,8789]
===
match
---
import_from [1342,1387]
import_from [1342,1387]
===
match
---
atom_expr [12876,12945]
atom_expr [12932,13001]
===
match
---
name: decode [9909,9915]
name: decode [9965,9971]
===
match
---
atom_expr [15780,15809]
atom_expr [15836,15865]
===
match
---
trailer [16025,16032]
trailer [16081,16088]
===
match
---
expr_stmt [3358,3389]
expr_stmt [3414,3445]
===
match
---
simple_stmt [5738,5790]
simple_stmt [5794,5846]
===
match
---
trailer [11967,11972]
trailer [12023,12028]
===
match
---
name: status_code [4094,4105]
name: status_code [4150,4161]
===
match
---
name: isoformat [9459,9468]
name: isoformat [9515,9524]
===
match
---
name: status_code [10871,10882]
name: status_code [10927,10938]
===
match
---
trailer [1561,1650]
trailer [1561,1650]
===
match
---
name: self [2002,2006]
name: self [2002,2006]
===
match
---
name: paused_url [5574,5584]
name: paused_url [5630,5640]
===
match
---
name: dag_run [8359,8366]
name: dag_run [8415,8422]
===
match
---
name: post [17279,17283]
name: post [17335,17339]
===
match
---
simple_stmt [13809,13860]
simple_stmt [13865,13916]
===
match
---
assert_stmt [17763,17817]
assert_stmt [17819,17873]
===
match
---
trailer [3011,3022]
trailer [3067,3078]
===
match
---
atom_expr [5458,5487]
atom_expr [5514,5543]
===
match
---
trailer [15327,15333]
trailer [15383,15389]
===
match
---
atom_expr [18384,18434]
atom_expr [18440,18490]
===
match
---
assert_stmt [16892,16926]
assert_stmt [16948,16982]
===
match
---
atom_expr [2178,2209]
atom_expr [2178,2209]
===
match
---
atom [14962,14987]
atom [15018,15043]
===
match
---
trailer [15333,15337]
trailer [15389,15393]
===
match
---
arglist [9438,9457]
arglist [9494,9513]
===
match
---
atom_expr [12167,12187]
atom_expr [12223,12243]
===
match
---
import_from [892,927]
import_from [892,927]
===
match
---
number: 2 [14727,14728]
number: 2 [14783,14784]
===
match
---
name: data [14413,14417]
name: data [14469,14473]
===
match
---
name: classmethod [12631,12642]
name: classmethod [12687,12698]
===
match
---
funcdef [16087,16493]
funcdef [16143,16549]
===
match
---
expr_stmt [3398,3446]
expr_stmt [3454,3502]
===
match
---
name: json [15494,15498]
name: json [15550,15554]
===
match
---
simple_stmt [13336,13393]
simple_stmt [13392,13449]
===
match
---
name: session [3171,3178]
name: session [3227,3234]
===
match
---
trailer [10027,10034]
trailer [10083,10090]
===
match
---
name: datetime_string [7097,7112]
name: datetime_string [7153,7168]
===
match
---
string: '' [16751,16753]
string: '' [16807,16809]
===
match
---
operator: @ [13067,13068]
operator: @ [13123,13124]
===
match
---
name: response [13644,13652]
name: response [13700,13708]
===
match
---
param [3303,3307]
param [3359,3363]
===
match
---
expr_stmt [11457,11529]
expr_stmt [11513,11585]
===
match
---
testlist_comp [1707,1739]
testlist_comp [1707,1739]
===
match
---
operator: , [5025,5026]
operator: , [5081,5082]
===
match
---
atom_expr [7896,7923]
atom_expr [7952,7979]
===
match
---
operator: , [13109,13110]
operator: , [13165,13166]
===
match
---
trailer [6196,6203]
trailer [6252,6259]
===
match
---
argument [9306,9319]
argument [9362,9375]
===
match
---
trailer [3966,3973]
trailer [4022,4029]
===
match
---
fstring_expr [15641,15657]
fstring_expr [15697,15713]
===
match
---
expr_stmt [6427,6472]
expr_stmt [6483,6528]
===
match
---
number: 404 [12160,12163]
number: 404 [12216,12219]
===
match
---
trailer [10917,10922]
trailer [10973,10978]
===
match
---
name: format [14296,14302]
name: format [14352,14358]
===
match
---
name: decode [6376,6382]
name: decode [6432,6438]
===
match
---
simple_stmt [1263,1299]
simple_stmt [1263,1299]
===
match
---
simple_stmt [8359,8409]
simple_stmt [8415,8465]
===
match
---
simple_stmt [14570,14605]
simple_stmt [14626,14661]
===
match
---
name: response [15780,15788]
name: response [15836,15844]
===
match
---
trailer [4041,4046]
trailer [4097,4102]
===
match
---
expr_stmt [7042,7088]
expr_stmt [7098,7144]
===
match
---
name: content_type [8702,8714]
name: content_type [8758,8770]
===
match
---
string: '' [17093,17095]
string: '' [17149,17151]
===
match
---
name: datetime_string [14052,14067]
name: datetime_string [14108,14123]
===
match
---
trailer [7466,7478]
trailer [7522,7534]
===
match
---
atom_expr [10163,10192]
atom_expr [10219,10248]
===
match
---
trailer [16629,16786]
trailer [16685,16842]
===
match
---
arith_expr [18162,18187]
arith_expr [18218,18243]
===
match
---
atom_expr [18690,18740]
atom_expr [18746,18796]
===
match
---
operator: , [8431,8432]
operator: , [8487,8488]
===
match
---
name: test_task_info [3540,3554]
name: test_task_info [3596,3610]
===
match
---
suite [14891,15338]
suite [14947,15394]
===
match
---
trailer [2067,2074]
trailer [2067,2074]
===
match
---
atom_expr [3642,3714]
atom_expr [3698,3770]
===
match
---
trailer [12983,12985]
trailer [13039,13041]
===
match
---
simple_stmt [14131,14179]
simple_stmt [14187,14235]
===
match
---
trailer [7915,7923]
trailer [7971,7979]
===
match
---
name: response [11640,11648]
name: response [11696,11704]
===
match
---
name: decode [13904,13910]
name: decode [13960,13966]
===
match
---
decorated [1694,2379]
decorated [1694,2379]
===
match
---
simple_stmt [3927,4007]
simple_stmt [3983,4063]
===
match
---
trailer [14905,14907]
trailer [14961,14963]
===
match
---
operator: = [6349,6350]
operator: = [6405,6406]
===
match
---
trailer [9990,9997]
trailer [10046,10053]
===
match
---
param [17844,17848]
param [17900,17904]
===
match
---
name: unittest [1670,1678]
name: unittest [1670,1678]
===
match
---
operator: = [6431,6432]
operator: = [6487,6488]
===
match
---
number: 1 [9444,9445]
number: 1 [9500,9501]
===
match
---
trailer [16279,16285]
trailer [16335,16341]
===
match
---
comparison [17770,17817]
comparison [17826,17873]
===
match
---
arglist [12559,12623]
arglist [12615,12679]
===
match
---
name: response [16121,16129]
name: response [16177,16185]
===
match
---
dotted_name [1268,1283]
dotted_name [1268,1283]
===
match
---
trailer [3160,3162]
trailer [3216,3218]
===
match
---
name: DagRun [12747,12753]
name: DagRun [12803,12809]
===
match
---
simple_stmt [18640,18675]
simple_stmt [18696,18731]
===
match
---
name: trigger_dag [995,1006]
name: trigger_dag [995,1006]
===
match
---
name: test_utils [1353,1363]
name: test_utils [1353,1363]
===
match
---
string: 'utf-8' [9916,9923]
string: 'utf-8' [9972,9979]
===
match
---
assert_stmt [18640,18674]
assert_stmt [18696,18730]
===
match
---
assert_stmt [9873,9924]
assert_stmt [9929,9980]
===
match
---
trailer [2282,2289]
trailer [2282,2289]
===
match
---
trailer [4914,4939]
trailer [4970,4995]
===
match
---
name: airflow [1304,1311]
name: airflow [1304,1311]
===
match
---
operator: @ [14803,14804]
operator: @ [14859,14860]
===
match
---
simple_stmt [6427,6473]
simple_stmt [6483,6529]
===
match
---
argument [8636,8688]
argument [8692,8744]
===
match
---
name: response [17988,17996]
name: response [18044,18052]
===
match
---
simple_stmt [16121,16175]
simple_stmt [16177,16231]
===
match
---
trailer [3153,3160]
trailer [3209,3216]
===
match
---
name: url [3385,3388]
name: url [3441,3444]
===
match
---
simple_stmt [819,835]
simple_stmt [819,835]
===
match
---
name: version [1276,1283]
name: version [1276,1283]
===
match
---
trailer [16136,16143]
trailer [16192,16199]
===
match
---
name: dag_id [14535,14541]
name: dag_id [14591,14597]
===
match
---
comparison [15447,15474]
comparison [15503,15530]
===
match
---
name: client [8858,8864]
name: client [8914,8920]
===
match
---
name: path [12549,12553]
name: path [12605,12609]
===
match
---
name: dagbag [7582,7588]
name: dagbag [7638,7644]
===
match
---
param [6926,6930]
param [6982,6986]
===
match
---
param [1913,1917]
param [1913,1917]
===
match
---
trailer [13659,13666]
trailer [13715,13722]
===
match
---
operator: @ [2679,2680]
operator: @ [2735,2736]
===
match
---
trailer [12088,12092]
trailer [12144,12148]
===
match
---
trailer [5048,5066]
trailer [5104,5122]
===
match
---
atom [1706,1740]
atom [1706,1740]
===
match
---
trailer [2985,2992]
trailer [3041,3048]
===
match
---
name: SerializedDagModel [1130,1148]
name: SerializedDagModel [1130,1148]
===
match
---
string: 'error' [13875,13882]
string: 'error' [13931,13938]
===
match
---
name: decode [16300,16306]
name: decode [16356,16362]
===
match
---
suite [2716,3071]
suite [2772,3127]
===
match
---
operator: = [12899,12900]
operator: = [12955,12956]
===
match
---
import_name [809,818]
import_name [809,818]
===
match
---
name: dirname [1570,1577]
name: dirname [1570,1577]
===
match
---
simple_stmt [12423,12471]
simple_stmt [12479,12527]
===
match
---
arglist [16575,16832]
arglist [16631,16888]
===
match
---
simple_stmt [3358,3390]
simple_stmt [3414,3446]
===
match
---
trailer [2743,2745]
trailer [2799,2801]
===
match
---
name: run_id [6560,6566]
name: run_id [6616,6622]
===
match
---
operator: , [9442,9443]
operator: , [9498,9499]
===
match
---
string: 'run_id' [6641,6649]
string: 'run_id' [6697,6705]
===
match
---
atom_expr [9733,9765]
atom_expr [9789,9821]
===
match
---
string: 'utf-8' [16307,16314]
string: 'utf-8' [16363,16370]
===
match
---
assert_stmt [14570,14604]
assert_stmt [14626,14660]
===
match
---
trailer [16855,16873]
trailer [16911,16929]
===
match
---
name: TOTAL_POOL_COUNT [17142,17158]
name: TOTAL_POOL_COUNT [17198,17214]
===
match
---
name: status_code [10635,10646]
name: status_code [10691,10702]
===
match
---
operator: = [15181,15182]
operator: = [15237,15238]
===
match
---
operator: = [11337,11338]
operator: = [11393,11394]
===
match
---
decorated [14803,14870]
decorated [14859,14926]
===
match
---
name: response [10362,10370]
name: response [10418,10426]
===
match
---
operator: , [17326,17327]
operator: , [17382,17383]
===
match
---
name: response [8842,8850]
name: response [8898,8906]
===
match
---
name: loads [8175,8180]
name: loads [8231,8236]
===
match
---
assert_stmt [12196,12243]
assert_stmt [12252,12299]
===
match
---
expr_stmt [4875,4939]
expr_stmt [4931,4995]
===
match
---
trailer [12337,12344]
trailer [12393,12400]
===
match
---
expr_stmt [18539,18631]
expr_stmt [18595,18687]
===
match
---
operator: == [6867,6869]
operator: == [6923,6925]
===
match
---
atom_expr [14149,14178]
atom_expr [14205,14234]
===
match
---
atom_expr [14631,14660]
atom_expr [14687,14716]
===
match
---
simple_stmt [15281,15303]
simple_stmt [15337,15359]
===
match
---
number: 404 [15982,15985]
number: 404 [16038,16041]
===
match
---
name: response [10409,10417]
name: response [10465,10473]
===
match
---
dotted_name [13068,13078]
dotted_name [13124,13134]
===
match
---
atom_expr [11700,11729]
atom_expr [11756,11785]
===
match
---
trailer [14913,14915]
trailer [14969,14971]
===
match
---
expr_stmt [8359,8408]
expr_stmt [8415,8464]
===
match
---
name: loads [16947,16952]
name: loads [17003,17008]
===
match
---
name: url_template [4402,4414]
name: url_template [4458,4470]
===
match
---
name: Pool [15096,15100]
name: Pool [15152,15156]
===
match
---
comparison [3830,3874]
comparison [3886,3930]
===
match
---
string: 'example_bash_operator' [3974,3997]
string: 'example_bash_operator' [4030,4053]
===
match
---
comparison [6618,6650]
comparison [6674,6706]
===
match
---
trailer [9064,9076]
trailer [9120,9132]
===
match
---
name: response [10862,10870]
name: response [10918,10926]
===
match
---
atom_expr [7215,7394]
atom_expr [7271,7450]
===
match
---
trailer [1678,1687]
trailer [1678,1687]
===
match
---
name: get_dag [8335,8342]
name: get_dag [8391,8398]
===
match
---
trailer [10429,10438]
trailer [10485,10494]
===
match
---
name: data [10418,10422]
name: data [10474,10478]
===
match
---
arith_expr [17137,17162]
arith_expr [17193,17218]
===
match
---
name: mock [13068,13072]
name: mock [13124,13128]
===
match
---
expr_stmt [2125,2169]
expr_stmt [2125,2169]
===
match
---
trailer [17790,17792]
trailer [17846,17848]
===
match
---
suite [16112,16493]
suite [16168,16549]
===
match
---
name: self [18253,18257]
name: self [18309,18313]
===
match
---
comparison [10152,10192]
comparison [10208,10248]
===
match
---
operator: , [6804,6805]
operator: , [6860,6861]
===
match
---
name: setUpClass [14857,14867]
name: setUpClass [14913,14923]
===
match
---
number: 200 [5602,5605]
number: 200 [5658,5661]
===
match
---
operator: = [3322,3323]
operator: = [3378,3379]
===
match
---
simple_stmt [11143,11200]
simple_stmt [11199,11256]
===
match
---
name: format [14528,14534]
name: format [14584,14590]
===
match
---
comparison [12203,12243]
comparison [12259,12299]
===
match
---
arglist [6742,6837]
arglist [6798,6893]
===
match
---
operator: = [5950,5951]
operator: = [6006,6007]
===
match
---
for_stmt [14996,15273]
for_stmt [15052,15329]
===
match
---
trailer [5961,5981]
trailer [6017,6037]
===
match
---
number: 200 [4568,4571]
number: 200 [4624,4627]
===
match
---
atom_expr [9429,9470]
atom_expr [9485,9526]
===
match
---
trailer [11472,11479]
trailer [11528,11535]
===
match
---
name: json [16942,16946]
name: json [16998,17002]
===
match
---
trailer [3942,3949]
trailer [3998,4005]
===
match
---
string: 'utf-8' [10430,10437]
string: 'utf-8' [10486,10493]
===
match
---
name: response [7524,7532]
name: response [7580,7588]
===
match
---
trailer [12722,12724]
trailer [12778,12780]
===
match
---
operator: = [2000,2001]
operator: = [2000,2001]
===
match
---
string: 'utf-8' [10930,10937]
string: 'utf-8' [10986,10993]
===
match
---
name: format [10028,10034]
name: format [10084,10090]
===
match
---
atom_expr [2974,2994]
atom_expr [3030,3050]
===
match
---
name: get [13667,13670]
name: get [13723,13726]
===
match
---
operator: = [11159,11160]
operator: = [11215,11216]
===
match
---
trailer [4627,4631]
trailer [4683,4687]
===
match
---
name: pardir [1643,1649]
name: pardir [1643,1649]
===
match
---
name: resp [2604,2608]
name: resp [2660,2664]
===
match
---
name: assert_deprecated [17970,17987]
name: assert_deprecated [18026,18043]
===
match
---
name: pool [16935,16939]
name: pool [16991,16995]
===
match
---
name: response [4085,4093]
name: response [4141,4149]
===
match
---
string: 'error' [10898,10905]
string: 'error' [10954,10961]
===
match
---
name: self [4728,4732]
name: self [4784,4788]
===
match
---
name: quote_plus [9347,9357]
name: quote_plus [9403,9413]
===
match
---
trailer [13996,14079]
trailer [14052,14135]
===
match
---
atom_expr [6362,6391]
atom_expr [6418,6447]
===
match
---
simple_stmt [2278,2315]
simple_stmt [2278,2315]
===
match
---
trailer [10266,10270]
trailer [10322,10326]
===
match
---
argument [5995,6026]
argument [6051,6082]
===
match
---
trailer [11483,11529]
trailer [11539,11585]
===
match
---
trailer [6050,6068]
trailer [6106,6124]
===
match
---
name: self [15560,15564]
name: self [15616,15620]
===
match
---
assert_stmt [17663,17754]
assert_stmt [17719,17810]
===
match
---
operator: } [7336,7337]
operator: } [7392,7393]
===
match
---
name: execution_date [7750,7764]
name: execution_date [7806,7820]
===
match
---
name: PAPERMILL_EXAMPLE_DAGS [13111,13133]
name: PAPERMILL_EXAMPLE_DAGS [13167,13189]
===
match
---
name: airflow [1031,1038]
name: airflow [1031,1038]
===
match
---
operator: == [8248,8250]
operator: == [8304,8306]
===
match
---
comparison [12387,12414]
comparison [12443,12470]
===
match
---
name: run_id [11346,11352]
name: run_id [11402,11408]
===
match
---
trailer [7065,7067]
trailer [7121,7123]
===
match
---
suite [4309,4703]
suite [4365,4759]
===
match
---
simple_stmt [15678,15711]
simple_stmt [15734,15767]
===
match
---
operator: , [14309,14310]
operator: , [14365,14366]
===
match
---
string: 'DNE' [3999,4004]
string: 'DNE' [4055,4060]
===
match
---
name: status_code [8109,8120]
name: status_code [8165,8176]
===
match
---
funcdef [12647,13062]
funcdef [12703,13118]
===
match
---
name: url_template [13671,13683]
name: url_template [13727,13739]
===
match
---
string: '/api/experimental/dags/{}/dag_runs' [6956,6992]
string: '/api/experimental/dags/{}/dag_runs' [7012,7048]
===
match
---
trailer [15498,15504]
trailer [15554,15560]
===
match
---
trailer [11111,11119]
trailer [11167,11175]
===
match
---
funcdef [14875,15338]
funcdef [14931,15394]
===
match
---
name: delete [3199,3205]
name: delete [3255,3261]
===
match
---
comparison [18341,18368]
comparison [18397,18424]
===
match
---
assert_stmt [9042,9076]
assert_stmt [9098,9132]
===
match
---
funcdef [13139,14661]
funcdef [13195,14717]
===
match
---
trailer [4631,4659]
trailer [4687,4715]
===
match
---
expr_stmt [6701,6847]
expr_stmt [6757,6903]
===
match
---
name: self [3723,3727]
name: self [3779,3783]
===
match
---
name: get_dagrun [8373,8383]
name: get_dagrun [8429,8439]
===
match
---
trailer [7532,7537]
trailer [7588,7593]
===
match
---
name: client [14272,14278]
name: client [14328,14334]
===
match
---
trailer [6505,6530]
trailer [6561,6586]
===
match
---
string: 'CSRF_ENABLED' [2194,2208]
string: 'CSRF_ENABLED' [2194,2208]
===
match
---
name: url_template [3658,3670]
name: url_template [3714,3726]
===
match
---
operator: = [15122,15123]
operator: = [15178,15179]
===
match
---
operator: == [18668,18670]
operator: == [18724,18726]
===
match
---
trailer [9915,9924]
trailer [9971,9980]
===
match
---
trailer [4390,4397]
trailer [4446,4453]
===
match
---
operator: = [9523,9524]
operator: = [9579,9580]
===
match
---
trailer [7597,7599]
trailer [7653,7655]
===
match
---
trailer [1569,1577]
trailer [1569,1577]
===
match
---
trailer [16482,16490]
trailer [16538,16546]
===
match
---
simple_stmt [14088,14123]
simple_stmt [14144,14179]
===
match
---
atom_expr [12214,12243]
atom_expr [12270,12299]
===
match
---
trailer [12824,12831]
trailer [12880,12887]
===
match
---
parameters [2710,2715]
parameters [2766,2771]
===
match
---
trailer [8169,8230]
trailer [8225,8286]
===
match
---
assert_stmt [10612,10646]
assert_stmt [10668,10702]
===
match
---
atom_expr [12733,12763]
atom_expr [12789,12819]
===
match
---
name: format [4155,4161]
name: format [4211,4217]
===
match
---
name: self [18136,18140]
name: self [18192,18196]
===
match
---
name: json [6172,6176]
name: json [6228,6232]
===
match
---
atom_expr [6491,6530]
atom_expr [6547,6586]
===
match
---
simple_stmt [15249,15273]
simple_stmt [15305,15329]
===
match
---
name: trigger_dag [1014,1025]
name: trigger_dag [1014,1025]
===
match
---
simple_stmt [13644,13717]
simple_stmt [13700,13773]
===
match
---
string: 'example_bash_operator' [3678,3701]
string: 'example_bash_operator' [3734,3757]
===
match
---
operator: = [7290,7291]
operator: = [7346,7347]
===
match
---
parameters [10966,10972]
parameters [11022,11028]
===
match
---
name: dag_run_id [6539,6549]
name: dag_run_id [6595,6605]
===
match
---
trailer [13056,13061]
trailer [13112,13117]
===
match
---
name: self [14499,14503]
name: self [14555,14559]
===
match
---
trailer [18714,18721]
trailer [18770,18777]
===
match
---
decorator [12630,12643]
decorator [12686,12699]
===
match
---
simple_stmt [7608,7637]
simple_stmt [7664,7693]
===
match
---
name: self [18550,18554]
name: self [18606,18610]
===
match
---
trailer [14953,14959]
trailer [15009,15015]
===
match
---
atom_expr [9670,9723]
atom_expr [9726,9779]
===
match
---
string: 'pool' [17004,17010]
string: 'pool' [17060,17066]
===
match
---
number: 200 [13773,13776]
number: 200 [13829,13832]
===
match
---
trailer [13002,13013]
trailer [13058,13069]
===
match
---
param [3089,3093]
param [3145,3149]
===
match
---
operator: + [7068,7069]
operator: + [7124,7125]
===
match
---
simple_stmt [4497,4553]
simple_stmt [4553,4609]
===
match
---
name: name [17222,17226]
name: name [17278,17282]
===
match
---
operator: , [11262,11263]
operator: , [11318,11319]
===
match
---
simple_stmt [15046,15077]
simple_stmt [15102,15133]
===
match
---
name: USER_POOL_COUNT [14709,14724]
name: USER_POOL_COUNT [14765,14780]
===
match
---
atom_expr [18067,18096]
atom_expr [18123,18152]
===
match
---
trailer [2496,2635]
trailer [2496,2691]
===
match
---
atom_expr [2782,2812]
atom_expr [2838,2868]
===
match
---
trailer [4223,4232]
trailer [4279,4288]
===
match
---
name: self [18499,18503]
name: self [18555,18559]
===
match
---
atom_expr [3785,3814]
atom_expr [3841,3870]
===
match
---
atom_expr [18101,18120]
atom_expr [18157,18176]
===
match
---
atom_expr [10626,10646]
atom_expr [10682,10702]
===
match
---
name: super [14900,14905]
name: super [14956,14961]
===
match
---
atom_expr [6433,6472]
atom_expr [6489,6528]
===
match
---
fstring_end: ' [17944,17945]
fstring_end: ' [18000,18001]
===
match
---
trailer [7425,7435]
trailer [7481,7491]
===
match
---
name: format [12106,12112]
name: format [12162,12168]
===
match
---
name: self [2292,2296]
name: self [2292,2296]
===
match
---
name: os [1578,1580]
name: os [1578,1580]
===
match
---
trailer [8562,8567]
trailer [8618,8623]
===
match
---
operator: @ [1694,1695]
operator: @ [1694,1695]
===
match
---
atom_expr [8551,8744]
atom_expr [8607,8800]
===
match
---
trailer [6182,6213]
trailer [6238,6269]
===
match
---
atom_expr [5676,5696]
atom_expr [5732,5752]
===
match
---
trailer [18156,18158]
trailer [18212,18214]
===
match
---
comparison [4192,4232]
comparison [4248,4288]
===
match
---
suite [3095,3284]
suite [3151,3340]
===
match
---
string: 'utf-8' [15801,15808]
string: 'utf-8' [15857,15864]
===
match
---
operator: , [1847,1848]
operator: , [1847,1848]
===
match
---
simple_stmt [10391,10439]
simple_stmt [10447,10495]
===
match
---
trailer [14162,14169]
trailer [14218,14225]
===
match
---
operator: , [6026,6027]
operator: , [6082,6083]
===
match
---
assert_stmt [3823,3874]
assert_stmt [3879,3930]
===
match
---
name: dag_id [9690,9696]
name: dag_id [9746,9752]
===
match
---
import_from [1299,1341]
import_from [1299,1341]
===
match
---
trailer [2193,2209]
trailer [2193,2209]
===
match
---
string: 'error' [4022,4029]
string: 'error' [4078,4085]
===
match
---
operator: , [8066,8067]
operator: , [8122,8123]
===
match
---
assert_stmt [9774,9808]
assert_stmt [9830,9864]
===
match
---
trailer [2074,2101]
trailer [2074,2101]
===
match
---
string: "is_paused" [5653,5664]
string: "is_paused" [5709,5720]
===
match
---
number: 1 [9453,9454]
number: 1 [9509,9510]
===
match
---
name: quote_plus [917,927]
name: quote_plus [917,927]
===
match
---
simple_stmt [17256,17604]
simple_stmt [17312,17660]
===
match
---
operator: , [17588,17589]
operator: , [17644,17645]
===
match
---
name: dagbag [12867,12873]
name: dagbag [12923,12929]
===
match
---
name: response [15958,15966]
name: response [16014,16022]
===
match
---
import_from [1388,1434]
import_from [1388,1434]
===
match
---
fstring_string: Dag Run not found for execution date  [8435,8472]
fstring_string: Dag Run not found for execution date  [8491,8528]
===
match
---
arglist [8581,8734]
arglist [8637,8790]
===
match
---
trailer [9516,9600]
trailer [9572,9656]
===
match
---
name: decode [4537,4543]
name: decode [4593,4599]
===
match
---
trailer [6559,6566]
trailer [6615,6622]
===
match
---
trailer [18166,18183]
trailer [18222,18239]
===
match
---
trailer [14854,14856]
trailer [14910,14912]
===
match
---
operator: == [16466,16468]
operator: == [16522,16524]
===
match
---
comparison [10398,10438]
comparison [10454,10494]
===
match
---
simple_stmt [866,892]
simple_stmt [866,892]
===
match
---
name: dag_id [7265,7271]
name: dag_id [7321,7327]
===
match
---
name: response [7458,7466]
name: response [7514,7522]
===
match
---
param [9110,9114]
param [9166,9170]
===
match
---
arglist [17301,17589]
arglist [17357,17645]
===
match
---
name: execution_date [9585,9599]
name: execution_date [9641,9655]
===
match
---
string: 'example_bash_operator' [5400,5423]
string: 'example_bash_operator' [5456,5479]
===
match
---
expr_stmt [11143,11199]
expr_stmt [11199,11255]
===
match
---
name: response [18539,18547]
name: response [18595,18603]
===
match
---
simple_stmt [10612,10647]
simple_stmt [10668,10703]
===
match
---
suite [2995,3071]
suite [3051,3127]
===
match
---
name: delete [3154,3160]
name: delete [3210,3216]
===
match
---
operator: , [16753,16754]
operator: , [16809,16810]
===
match
---
fstring [15615,15658]
fstring [15671,15714]
===
match
---
operator: = [14960,14961]
operator: = [15016,15017]
===
match
---
name: response [6340,6348]
name: response [6396,6404]
===
match
---
simple_stmt [2725,2746]
simple_stmt [2781,2802]
===
match
---
assert_stmt [15994,16081]
assert_stmt [16050,16137]
===
match
---
name: os [1549,1551]
name: os [1549,1551]
===
match
---
name: client [3943,3949]
name: client [3999,4005]
===
match
---
trailer [12799,12806]
trailer [12855,12862]
===
match
---
trailer [16147,16174]
trailer [16203,16230]
===
match
---
assert_stmt [17063,17095]
assert_stmt [17119,17151]
===
match
---
number: 200 [15471,15474]
number: 200 [15527,15530]
===
match
---
expr_stmt [3104,3123]
expr_stmt [3160,3179]
===
match
---
string: 'secret_key' [2157,2169]
string: 'secret_key' [2157,2169]
===
match
---
atom_expr [13365,13391]
atom_expr [13421,13447]
===
match
---
trailer [7946,7952]
trailer [8002,8008]
===
match
---
name: response [12214,12222]
name: response [12270,12278]
===
match
---
operator: { [5294,5295]
operator: { [5350,5351]
===
match
---
atom [8940,8976]
atom [8996,9032]
===
match
---
name: data [10918,10922]
name: data [10974,10978]
===
match
---
simple_stmt [17763,17818]
simple_stmt [17819,17874]
===
match
---
suite [5729,6891]
suite [5785,6947]
===
match
---
name: task_id [9715,9722]
name: task_id [9771,9778]
===
match
---
name: dumps [7296,7301]
name: dumps [7352,7357]
===
match
---
string: 'application/json' [16813,16831]
string: 'application/json' [16869,16887]
===
match
---
trailer [18568,18631]
trailer [18624,18687]
===
match
---
name: data [16614,16618]
name: data [16670,16674]
===
match
---
atom_expr [17623,17643]
atom_expr [17679,17699]
===
match
---
name: json [8929,8933]
name: json [8985,8989]
===
match
---
trailer [15682,15700]
trailer [15738,15756]
===
match
---
string: 'error' [18732,18739]
string: 'error' [18788,18795]
===
match
---
trailer [3272,3281]
trailer [3328,3337]
===
match
---
name: decode [17695,17701]
name: decode [17751,17757]
===
match
---
name: response [3746,3754]
name: response [3802,3810]
===
match
---
trailer [12740,12746]
trailer [12796,12802]
===
match
---
name: test_client [2301,2312]
name: test_client [2301,2312]
===
match
---
name: pool [15652,15656]
name: pool [15708,15712]
===
match
---
string: "Pool 'foo' doesn't exist" [16055,16081]
string: "Pool 'foo' doesn't exist" [16111,16137]
===
match
---
name: decode [18081,18087]
name: decode [18137,18143]
===
match
---
trailer [7523,7554]
trailer [7579,7610]
===
match
---
suite [12667,13062]
suite [12723,13118]
===
match
---
string: 'foo' [16677,16682]
string: 'foo' [16733,16738]
===
match
---
suite [15876,16082]
suite [15932,16138]
===
match
---
name: realpath [1535,1543]
name: realpath [1535,1543]
===
match
---
name: commit [12825,12831]
name: commit [12881,12887]
===
match
---
number: 400 [17647,17650]
number: 400 [17703,17706]
===
match
---
name: format [11497,11503]
name: format [11553,11559]
===
match
---
trailer [3853,3858]
trailer [3909,3914]
===
match
---
trailer [17800,17817]
trailer [17856,17873]
===
match
---
simple_stmt [958,1026]
simple_stmt [958,1026]
===
match
---
string: 'BashOperator(' [4504,4519]
string: 'BashOperator(' [4560,4575]
===
match
---
simple_stmt [3241,3257]
simple_stmt [3297,3313]
===
match
---
simple_stmt [4241,4276]
simple_stmt [4297,4332]
===
match
---
name: os [806,808]
name: os [806,808]
===
match
---
fstring_start: f' [15053,15055]
fstring_start: f' [15109,15111]
===
match
---
atom_expr [16286,16315]
atom_expr [16342,16371]
===
match
---
name: resp [2412,2416]
name: resp [2412,2416]
===
match
---
string: 'task_ids' [13816,13826]
string: 'task_ids' [13872,13882]
===
match
---
trailer [13788,13800]
trailer [13844,13856]
===
match
---
atom_expr [16899,16919]
atom_expr [16955,16975]
===
match
---
trailer [18105,18110]
trailer [18161,18166]
===
match
---
expr_stmt [4318,4365]
expr_stmt [4374,4421]
===
match
---
trailer [9437,9458]
trailer [9493,9514]
===
match
---
name: DagBag [2925,2931]
name: DagBag [2981,2987]
===
match
---
name: self [10967,10971]
name: self [11023,11027]
===
match
---
name: datetime_string [7494,7509]
name: datetime_string [7550,7565]
===
match
---
name: response [12066,12074]
name: response [12122,12130]
===
match
---
atom_expr [7524,7553]
atom_expr [7580,7609]
===
match
---
trailer [12785,12799]
trailer [12841,12855]
===
match
---
name: quote_plus [13354,13364]
name: quote_plus [13410,13420]
===
match
---
assert_stmt [3765,3814]
assert_stmt [3821,3870]
===
match
---
name: response [6870,6878]
name: response [6926,6934]
===
match
---
funcdef [3289,3531]
funcdef [3345,3587]
===
match
---
trailer [3409,3415]
trailer [3465,3471]
===
match
---
simple_stmt [799,809]
simple_stmt [799,809]
===
match
---
param [16519,16523]
param [16575,16579]
===
match
---
number: 1 [13451,13452]
number: 1 [13507,13508]
===
match
---
simple_stmt [11780,11890]
simple_stmt [11836,11946]
===
match
---
atom_expr [2292,2314]
atom_expr [2292,2314]
===
match
---
name: test_get_dag_code [4285,4302]
name: test_get_dag_code [4341,4358]
===
match
---
name: decode [18409,18415]
name: decode [18465,18471]
===
match
---
string: 'utf-8' [9856,9863]
string: 'utf-8' [9912,9919]
===
match
---
trailer [4154,4161]
trailer [4210,4217]
===
match
---
operator: , [9451,9452]
operator: , [9507,9508]
===
match
---
number: 1 [11267,11268]
number: 1 [11323,11324]
===
match
---
trailer [2880,2882]
trailer [2936,2938]
===
match
---
name: data [18076,18080]
name: data [18132,18136]
===
match
---
name: self [16346,16350]
name: self [16402,16406]
===
match
---
funcdef [6896,9077]
funcdef [6952,9133]
===
match
---
name: self [14949,14953]
name: self [15005,15009]
===
match
---
trailer [11196,11198]
trailer [11252,11254]
===
match
---
name: DagBag [7591,7597]
name: DagBag [7647,7653]
===
match
---
operator: , [17498,17499]
operator: , [17554,17555]
===
match
---
comparison [16231,16258]
comparison [16287,16314]
===
match
---
simple_stmt [1928,1976]
simple_stmt [1928,1976]
===
match
---
expr_stmt [8540,8744]
expr_stmt [8596,8800]
===
match
---
assert_stmt [14088,14122]
assert_stmt [14144,14178]
===
match
---
name: response [14102,14110]
name: response [14158,14166]
===
match
---
string: 'utf-8' [4544,4551]
string: 'utf-8' [4600,4607]
===
match
---
arglist [13079,13133]
arglist [13135,13189]
===
match
---
suite [2418,2636]
suite [2418,2692]
===
match
---
operator: = [9204,9205]
operator: = [9260,9261]
===
match
---
simple_stmt [12676,12697]
simple_stmt [12732,12753]
===
match
---
atom_expr [5152,5172]
atom_expr [5208,5228]
===
match
---
simple_stmt [11457,11530]
simple_stmt [11513,11586]
===
match
---
name: microsecond [13313,13324]
name: microsecond [13369,13380]
===
match
---
operator: , [1059,1060]
operator: , [1059,1060]
===
match
---
string: 'execution_date' [7303,7319]
string: 'execution_date' [7359,7375]
===
match
---
trailer [8864,8869]
trailer [8920,8925]
===
match
---
name: self [3089,3093]
name: self [3145,3149]
===
match
---
name: content_type [7352,7364]
name: content_type [7408,7420]
===
match
---
name: decode [14645,14651]
name: decode [14701,14707]
===
match
---
operator: , [5423,5424]
operator: , [5479,5480]
===
match
---
name: test_task_instance_info [9086,9109]
name: test_task_instance_info [9142,9165]
===
match
---
name: response [15701,15709]
name: response [15757,15765]
===
match
---
trailer [12112,12143]
trailer [12168,12199]
===
match
---
name: run_id [6582,6588]
name: run_id [6638,6644]
===
match
---
name: url_template [9125,9137]
name: url_template [9181,9193]
===
match
---
name: paused_response [5609,5624]
name: paused_response [5665,5680]
===
match
---
operator: , [11510,11511]
operator: , [11566,11567]
===
match
---
atom_expr [6172,6231]
atom_expr [6228,6287]
===
match
---
import_as_name [1323,1341]
import_as_name [1323,1341]
===
match
---
name: client [15901,15907]
name: client [15957,15963]
===
match
---
name: os [1618,1620]
name: os [1618,1620]
===
match
---
simple_stmt [3723,3756]
simple_stmt [3779,3812]
===
match
---
atom_expr [15642,15656]
atom_expr [15698,15712]
===
match
---
name: skip_all_except [1802,1817]
name: skip_all_except [1802,1817]
===
match
---
argument [11384,11413]
argument [11440,11469]
===
match
---
name: response [4255,4263]
name: response [4311,4319]
===
match
---
name: TOTAL_POOL_COUNT [17801,17817]
name: TOTAL_POOL_COUNT [17857,17873]
===
match
---
name: __file__ [1595,1603]
name: __file__ [1595,1603]
===
match
---
name: get [3950,3953]
name: get [4006,4009]
===
match
---
name: url_template [7896,7908]
name: url_template [7952,7964]
===
match
---
atom_expr [3897,3917]
atom_expr [3953,3973]
===
match
---
operator: = [12874,12875]
operator: = [12930,12931]
===
match
---
name: response [10516,10524]
name: response [10572,10580]
===
match
---
atom_expr [2278,2289]
atom_expr [2278,2289]
===
match
---
comparison [11905,11932]
comparison [11961,11988]
===
match
---
number: 404 [4675,4678]
number: 404 [4731,4734]
===
match
---
trailer [18264,18271]
trailer [18320,18327]
===
match
---
name: url_template [11820,11832]
name: url_template [11876,11888]
===
match
---
comparison [5503,5530]
comparison [5559,5586]
===
match
---
assert_stmt [5138,5172]
assert_stmt [5194,5228]
===
match
---
arith_expr [5807,5838]
arith_expr [5863,5894]
===
match
---
operator: = [4384,4385]
operator: = [4440,4441]
===
match
---
comparison [15726,15753]
comparison [15782,15809]
===
match
---
atom_expr [5317,5337]
atom_expr [5373,5393]
===
match
---
string: 'example_bash_operator' [5908,5931]
string: 'example_bash_operator' [5964,5987]
===
match
---
name: dag_run [8424,8431]
name: dag_run [8480,8487]
===
match
---
trailer [13444,13465]
trailer [13500,13521]
===
match
---
name: json [18690,18694]
name: json [18746,18750]
===
match
---
name: self [17770,17774]
name: self [17826,17830]
===
match
---
simple_stmt [809,819]
simple_stmt [809,819]
===
match
---
operator: == [3471,3473]
operator: == [3527,3529]
===
match
---
name: url_template [8581,8593]
name: url_template [8637,8649]
===
match
---
name: hours [7080,7085]
name: hours [7136,7141]
===
match
---
trailer [13729,13747]
trailer [13785,13803]
===
match
---
trailer [9297,9305]
trailer [9353,9361]
===
match
---
trailer [14967,14984]
trailer [15023,15040]
===
match
---
name: re [2487,2489]
name: re [2487,2489]
===
match
---
operator: , [9022,9023]
operator: , [9078,9079]
===
match
---
assert_stmt [15762,15833]
assert_stmt [15818,15889]
===
match
---
trailer [10681,10686]
trailer [10737,10742]
===
match
---
expr_stmt [2278,2314]
expr_stmt [2278,2314]
===
match
---
parameters [16105,16111]
parameters [16161,16167]
===
match
---
trailer [16011,16042]
trailer [16067,16098]
===
match
---
atom_expr [8369,8408]
atom_expr [8425,8464]
===
match
---
arglist [13524,13600]
arglist [13580,13656]
===
match
---
string: 'utf-8' [13851,13858]
string: 'utf-8' [13907,13914]
===
match
---
trailer [2810,2812]
trailer [2866,2868]
===
match
---
atom_expr [9358,9384]
atom_expr [9414,9440]
===
match
---
atom [17381,17521]
atom [17437,17577]
===
match
---
operator: , [11344,11345]
operator: , [11400,11401]
===
match
---
simple_stmt [14256,14335]
simple_stmt [14312,14391]
===
match
---
simple_stmt [9125,9189]
simple_stmt [9181,9245]
===
match
---
name: session [3216,3223]
name: session [3272,3279]
===
match
---
simple_stmt [15214,15237]
simple_stmt [15270,15293]
===
match
---
simple_stmt [17616,17651]
simple_stmt [17672,17707]
===
match
---
name: assert_deprecated [16188,16205]
name: assert_deprecated [16244,16261]
===
match
---
name: self [14267,14271]
name: self [14323,14327]
===
match
---
simple_stmt [12521,12625]
simple_stmt [12577,12681]
===
match
---
name: paused_response [5317,5332]
name: paused_response [5373,5388]
===
match
---
trailer [3380,3384]
trailer [3436,3440]
===
match
---
atom_expr [7513,7572]
atom_expr [7569,7628]
===
match
---
name: commit [15294,15300]
name: commit [15350,15356]
===
match
---
trailer [2771,2773]
trailer [2827,2829]
===
match
---
name: Pool [14963,14967]
name: Pool [15019,15023]
===
match
---
simple_stmt [18377,18465]
simple_stmt [18433,18521]
===
match
---
name: decorators [1457,1467]
name: decorators [1457,1467]
===
match
---
funcdef [3076,3284]
funcdef [3132,3340]
===
match
---
trailer [7544,7553]
trailer [7600,7609]
===
match
---
trailer [12344,12370]
trailer [12400,12426]
===
match
---
name: response_execution_date [6506,6529]
name: response_execution_date [6562,6585]
===
match
---
simple_stmt [12196,12244]
simple_stmt [12252,12300]
===
match
---
assert_stmt [13809,13859]
assert_stmt [13865,13915]
===
match
---
suite [12516,14661]
suite [12572,14717]
===
match
---
name: status_code [9065,9076]
name: status_code [9121,9132]
===
match
---
string: 'sqlite:///' [2104,2116]
string: 'sqlite:///' [2104,2116]
===
match
---
name: dag [6427,6430]
name: dag [6483,6486]
===
match
---
atom_expr [7866,8077]
atom_expr [7922,8133]
===
match
---
name: response [18341,18349]
name: response [18397,18405]
===
match
---
atom_expr [17965,17997]
atom_expr [18021,18053]
===
match
---
name: response_execution_date [6131,6154]
name: response_execution_date [6187,6210]
===
match
---
trailer [15779,15810]
trailer [15835,15866]
===
match
---
suite [17850,18188]
suite [17906,18244]
===
match
---
assert_stmt [8753,8787]
assert_stmt [8809,8843]
===
match
---
assert_stmt [17104,17162]
assert_stmt [17160,17218]
===
match
---
name: self [3369,3373]
name: self [3425,3429]
===
match
---
name: data [8190,8194]
name: data [8246,8250]
===
match
---
name: TOTAL_POOL_COUNT [14733,14749]
name: TOTAL_POOL_COUNT [14789,14805]
===
match
---
name: utils [1199,1204]
name: utils [1199,1204]
===
match
---
trailer [5113,5120]
trailer [5169,5176]
===
match
---
name: self [17844,17848]
name: self [17900,17904]
===
match
---
name: dagbag [2974,2980]
name: dagbag [3030,3036]
===
match
---
operator: = [4958,4959]
operator: = [5014,5015]
===
match
---
expr_stmt [9975,10093]
expr_stmt [10031,10149]
===
match
---
string: 'utf-8' [11661,11668]
string: 'utf-8' [11717,11724]
===
match
---
simple_stmt [15089,15202]
simple_stmt [15145,15258]
===
match
---
trailer [3198,3205]
trailer [3254,3261]
===
match
---
name: p [16426,16427]
name: p [16482,16483]
===
match
---
name: data [13899,13903]
name: data [13955,13959]
===
match
---
trailer [16961,16966]
trailer [17017,17022]
===
match
---
name: json [5692,5696]
name: json [5748,5752]
===
match
---
arglist [5888,6027]
arglist [5944,6083]
===
match
---
name: post [7878,7882]
name: post [7934,7938]
===
match
---
number: 400 [9049,9052]
number: 400 [9105,9108]
===
match
---
name: paused_response [5251,5266]
name: paused_response [5307,5322]
===
match
---
trailer [11832,11839]
trailer [11888,11895]
===
match
---
name: dag_id [7916,7922]
name: dag_id [7972,7978]
===
match
---
name: query [2790,2795]
name: query [2846,2851]
===
match
---
name: data [17344,17348]
name: data [17400,17404]
===
match
---
operator: , [8977,8978]
operator: , [9033,9034]
===
match
---
name: content_type [17557,17569]
name: content_type [17613,17625]
===
match
---
operator: , [9713,9714]
operator: , [9769,9770]
===
match
---
suite [15033,15273]
suite [15089,15329]
===
match
---
name: response [10116,10124]
name: response [10172,10180]
===
match
---
operator: , [1872,1873]
operator: , [1872,1873]
===
match
---
simple_stmt [3008,3025]
simple_stmt [3064,3081]
===
match
---
trailer [3384,3389]
trailer [3440,3445]
===
match
---
atom_expr [16429,16438]
atom_expr [16485,16494]
===
match
---
assert_stmt [4497,4552]
assert_stmt [4553,4608]
===
match
---
name: TaskInstance [12786,12798]
name: TaskInstance [12842,12854]
===
match
---
comparison [17623,17650]
comparison [17679,17706]
===
match
---
name: www [1312,1315]
name: www [1312,1315]
===
match
---
assert_stmt [5287,5337]
assert_stmt [5343,5393]
===
match
---
string: 'error' [18426,18433]
string: 'error' [18482,18489]
===
match
---
number: 404 [14095,14098]
number: 404 [14151,14154]
===
match
---
number: 1 [18186,18187]
number: 1 [18242,18243]
===
match
---
trailer [15518,15525]
trailer [15574,15581]
===
match
---
name: self [1928,1932]
name: self [1928,1932]
===
match
---
name: datetime_string [13699,13714]
name: datetime_string [13755,13770]
===
match
---
name: self [3498,3502]
name: self [3554,3558]
===
match
---
assert_stmt [5443,5487]
assert_stmt [5499,5543]
===
match
---
trailer [6761,6783]
trailer [6817,6839]
===
match
---
operator: == [4082,4084]
operator: == [4138,4140]
===
match
---
arglist [10035,10081]
arglist [10091,10137]
===
match
---
name: delete [18562,18568]
name: delete [18618,18624]
===
match
---
parameters [3554,3560]
parameters [3610,3616]
===
match
---
name: dag_id [9197,9203]
name: dag_id [9253,9259]
===
match
---
trailer [6447,6472]
trailer [6503,6528]
===
match
---
name: dagbag [7614,7620]
name: dagbag [7670,7676]
===
match
---
atom_expr [1562,1605]
atom_expr [1562,1605]
===
match
---
name: Session [2764,2771]
name: Session [2820,2827]
===
match
---
trailer [5160,5172]
trailer [5216,5228]
===
match
---
trailer [18731,18740]
trailer [18787,18796]
===
match
---
name: test_utils [1446,1456]
name: test_utils [1446,1456]
===
match
---
name: decode [12228,12234]
name: decode [12284,12290]
===
match
---
trailer [12806,12808]
trailer [12862,12864]
===
match
---
number: 200 [15750,15753]
number: 200 [15806,15809]
===
match
---
simple_stmt [9817,9865]
simple_stmt [9873,9921]
===
match
---
operator: = [8303,8304]
operator: = [8359,8360]
===
match
---
name: self [15389,15393]
name: self [15445,15449]
===
match
---
trailer [15800,15809]
trailer [15856,15865]
===
match
---
atom_expr [16275,16316]
atom_expr [16331,16372]
===
match
---
name: client [15591,15597]
name: client [15647,15653]
===
match
---
expr_stmt [3927,4006]
expr_stmt [3983,4062]
===
match
---
string: 'SQLALCHEMY_DATABASE_URI' [2075,2100]
string: 'SQLALCHEMY_DATABASE_URI' [2075,2100]
===
match
---
name: status_code [13789,13800]
name: status_code [13845,13856]
===
match
---
atom_expr [1618,1627]
atom_expr [1618,1627]
===
match
---
import_as_names [1221,1262]
import_as_names [1221,1262]
===
match
---
suite [14703,18777]
suite [14759,18833]
===
match
---
name: dag [13057,13060]
name: dag [13113,13116]
===
match
---
operator: , [11256,11257]
operator: , [11312,11313]
===
match
---
argument [1962,1974]
argument [1962,1974]
===
match
---
name: url_template [4142,4154]
name: url_template [4198,4210]
===
match
---
atom [5962,5980]
atom [6018,6036]
===
match
---
name: wrong_datetime_string [13401,13422]
name: wrong_datetime_string [13457,13478]
===
match
---
operator: = [8549,8550]
operator: = [8605,8606]
===
match
---
atom_expr [4888,4939]
atom_expr [4944,4995]
===
match
---
expr_stmt [8842,9033]
expr_stmt [8898,9089]
===
match
---
string: 'does_not_exist_dag' [14030,14050]
string: 'does_not_exist_dag' [14086,14106]
===
match
---
assert_stmt [10145,10192]
assert_stmt [10201,10248]
===
match
---
atom_expr [6790,6804]
atom_expr [6846,6860]
===
match
---
simple_stmt [12842,12858]
simple_stmt [12898,12914]
===
match
---
simple_stmt [787,799]
simple_stmt [787,799]
===
match
---
expr_stmt [7608,7636]
expr_stmt [7664,7692]
===
match
---
operator: = [4331,4332]
operator: = [4387,4388]
===
match
---
atom_expr [16332,16342]
atom_expr [16388,16398]
===
match
---
arglist [15118,15187]
arglist [15174,15243]
===
match
---
atom_expr [16999,17011]
atom_expr [17055,17067]
===
match
---
name: headers [2449,2456]
name: headers [2449,2456]
===
match
---
trailer [2980,2985]
trailer [3036,3041]
===
match
---
trailer [4531,4536]
trailer [4587,4592]
===
match
---
trailer [7407,7425]
trailer [7463,7481]
===
match
---
string: 'error' [10662,10669]
string: 'error' [10718,10725]
===
match
---
atom_expr [15323,15337]
atom_expr [15379,15393]
===
match
---
atom_expr [17681,17710]
atom_expr [17737,17766]
===
match
---
string: 'error' [11685,11692]
string: 'error' [11741,11748]
===
match
---
simple_stmt [5182,5228]
simple_stmt [5238,5284]
===
match
---
simple_stmt [11045,11078]
simple_stmt [11101,11134]
===
match
---
simple_stmt [16267,16317]
simple_stmt [16323,16373]
===
match
---
name: TestApiExperimental [2644,2663]
name: TestApiExperimental [2700,2719]
===
match
---
trailer [14022,14029]
trailer [14078,14085]
===
match
---
atom_expr [7059,7067]
atom_expr [7115,7123]
===
match
---
name: _get_pool_count [17775,17790]
name: _get_pool_count [17831,17846]
===
match
---
simple_stmt [8296,8314]
simple_stmt [8352,8370]
===
match
---
name: response [6632,6640]
name: response [6688,6696]
===
match
---
trailer [12921,12944]
trailer [12977,13000]
===
match
---
trailer [3373,3380]
trailer [3429,3436]
===
match
---
string: 'version' [3479,3488]
string: 'version' [3535,3544]
===
match
---
name: response [10673,10681]
name: response [10729,10737]
===
match
---
atom_expr [13512,13601]
atom_expr [13568,13657]
===
match
---
name: session [3241,3248]
name: session [3297,3304]
===
match
---
operator: , [1067,1068]
operator: , [1067,1068]
===
match
---
trailer [2360,2368]
trailer [2360,2368]
===
match
---
number: 400 [10855,10858]
number: 400 [10911,10914]
===
match
---
trailer [17969,17987]
trailer [18025,18043]
===
match
---
string: 'true' [8013,8019]
string: 'true' [8069,8075]
===
match
---
number: 1 [13457,13458]
number: 1 [13513,13514]
===
match
---
operator: == [15811,15813]
operator: == [15867,15869]
===
match
---
name: data [18404,18408]
name: data [18460,18464]
===
match
---
name: response [10757,10765]
name: response [10813,10821]
===
match
---
name: loads [3410,3415]
name: loads [3466,3471]
===
match
---
operator: = [7057,7058]
operator: = [7113,7114]
===
match
---
atom_expr [7942,8021]
atom_expr [7998,8077]
===
match
---
name: execution_date [7670,7684]
name: execution_date [7726,7740]
===
match
---
simple_stmt [6941,6993]
simple_stmt [6997,7049]
===
match
---
expr_stmt [10982,11036]
expr_stmt [11038,11092]
===
match
---
string: '"email"' [3772,3781]
string: '"email"' [3828,3837]
===
match
---
simple_stmt [6701,6848]
simple_stmt [6757,6904]
===
match
---
name: data [16295,16299]
name: data [16351,16355]
===
match
---
simple_stmt [3132,3163]
simple_stmt [3188,3219]
===
match
---
trailer [7219,7226]
trailer [7275,7282]
===
match
---
factor [15334,15336]
factor [15390,15392]
===
match
---
dictorsetmaker [8941,8975]
dictorsetmaker [8997,9031]
===
match
---
name: delete [2804,2810]
name: delete [2860,2866]
===
match
---
assert_stmt [10391,10438]
assert_stmt [10447,10494]
===
match
---
operator: = [9003,9004]
operator: = [9059,9060]
===
match
---
name: path [1552,1556]
name: path [1552,1556]
===
match
---
trailer [3949,3953]
trailer [4005,4009]
===
match
---
operator: , [16786,16787]
operator: , [16842,16843]
===
match
---
expr_stmt [12066,12144]
expr_stmt [12122,12200]
===
match
---
assert_stmt [6241,6288]
assert_stmt [6297,6344]
===
match
---
trailer [16561,16842]
trailer [16617,16898]
===
match
---
atom_expr [5609,5636]
atom_expr [5665,5692]
===
match
---
atom_expr [12842,12857]
atom_expr [12898,12913]
===
match
---
expr_stmt [5798,5838]
expr_stmt [5854,5894]
===
match
---
arglist [10563,10601]
arglist [10619,10657]
===
match
---
atom_expr [18253,18325]
atom_expr [18309,18381]
===
match
---
name: status_code [14366,14377]
name: status_code [14422,14433]
===
match
---
trailer [18021,18033]
trailer [18077,18089]
===
match
---
comparison [10109,10136]
comparison [10165,10192]
===
match
---
simple_stmt [13512,13602]
simple_stmt [13568,13658]
===
match
---
name: status_code [17632,17643]
name: status_code [17688,17699]
===
match
---
name: name [15046,15050]
name: name [15102,15106]
===
match
---
trailer [7658,7669]
trailer [7714,7725]
===
match
---
trailer [1609,1616]
trailer [1609,1616]
===
match
---
expr_stmt [1984,2021]
expr_stmt [1984,2021]
===
match
---
trailer [8211,8229]
trailer [8267,8285]
===
match
---
name: self [2406,2410]
name: self [2406,2410]
===
match
---
name: datetime_string [7972,7987]
name: datetime_string [8028,8043]
===
match
---
name: dag_id [13531,13537]
name: dag_id [13587,13593]
===
match
---
name: content_type [8991,9003]
name: content_type [9047,9059]
===
match
---
simple_stmt [14924,14941]
simple_stmt [14980,14997]
===
match
---
operator: { [7302,7303]
operator: { [7358,7359]
===
match
---
name: super [3265,3270]
name: super [3321,3326]
===
match
---
operator: , [1073,1074]
operator: , [1073,1074]
===
match
---
simple_stmt [9643,9725]
simple_stmt [9699,9781]
===
match
---
simple_stmt [16325,16368]
simple_stmt [16381,16424]
===
match
---
name: decode [11714,11720]
name: decode [11770,11776]
===
match
---
name: isoformat [7130,7139]
name: isoformat [7186,7195]
===
match
---
name: self [2059,2063]
name: self [2059,2063]
===
match
---
trailer [2616,2624]
trailer [2672,2680]
===
match
---
trailer [11119,11134]
trailer [11175,11190]
===
match
---
name: self [1984,1988]
name: self [1984,1988]
===
match
---
name: commit [3224,3230]
name: commit [3280,3286]
===
match
---
operator: , [8910,8911]
operator: , [8966,8967]
===
match
---
name: format [10556,10562]
name: format [10612,10618]
===
match
---
atom_expr [4386,4447]
atom_expr [4442,4503]
===
match
---
parameters [14834,14839]
parameters [14890,14895]
===
match
---
expr_stmt [5540,5585]
expr_stmt [5596,5641]
===
match
---
atom_expr [8581,8622]
atom_expr [8637,8678]
===
match
---
trailer [5869,5874]
trailer [5925,5930]
===
match
---
comparison [12160,12187]
comparison [12216,12243]
===
match
---
string: 'does_not_exist_dag' [11840,11860]
string: 'does_not_exist_dag' [11896,11916]
===
match
---
name: dag_id [8903,8909]
name: dag_id [8959,8965]
===
match
---
name: execution_date [9570,9584]
name: execution_date [9626,9640]
===
match
---
string: '/api/experimental/pools' [15405,15430]
string: '/api/experimental/pools' [15461,15486]
===
match
---
name: DagBag [1053,1059]
name: DagBag [1053,1059]
===
match
---
atom_expr [3241,3256]
atom_expr [3297,3312]
===
match
---
name: decode [10177,10183]
name: decode [10233,10239]
===
match
---
string: 'utf-8' [14170,14177]
string: 'utf-8' [14226,14233]
===
match
---
name: response [16534,16542]
name: response [16590,16598]
===
match
---
trailer [17131,17133]
trailer [17187,17189]
===
match
---
trailer [14907,14913]
trailer [14963,14969]
===
match
---
assert_stmt [2480,2635]
assert_stmt [2480,2691]
===
match
---
operator: == [8097,8099]
operator: == [8153,8155]
===
match
---
name: status_code [12403,12414]
name: status_code [12459,12470]
===
match
---
simple_stmt [11319,11415]
simple_stmt [11375,11471]
===
match
---
name: pools [16267,16272]
name: pools [16323,16328]
===
match
---
trailer [15455,15467]
trailer [15511,15523]
===
match
---
name: dumps [5956,5961]
name: dumps [6012,6017]
===
match
---
trailer [4583,4595]
trailer [4639,4651]
===
match
---
operator: , [17455,17456]
operator: , [17511,17512]
===
match
---
simple_stmt [9505,9601]
simple_stmt [9561,9657]
===
match
---
name: run_id [5973,5979]
name: run_id [6029,6035]
===
match
---
name: client [9659,9665]
name: client [9715,9721]
===
match
---
name: config [2187,2193]
name: config [2187,2193]
===
match
---
operator: = [16940,16941]
operator: = [16996,16997]
===
match
---
arglist [12883,12944]
arglist [12939,13000]
===
match
---
operator: == [8764,8766]
operator: == [8820,8822]
===
match
---
trailer [11560,11570]
trailer [11616,11626]
===
match
---
comparison [18136,18187]
comparison [18192,18243]
===
match
---
name: dag [8322,8325]
name: dag [8378,8381]
===
match
---
trailer [6375,6382]
trailer [6431,6438]
===
match
---
simple_stmt [2782,2813]
simple_stmt [2838,2869]
===
match
---
name: session [12733,12740]
name: session [12789,12796]
===
match
---
name: query [12741,12746]
name: query [12797,12802]
===
match
---
trailer [3973,4005]
trailer [4029,4061]
===
match
---
operator: = [13352,13353]
operator: = [13408,13409]
===
match
---
string: 'api' [1707,1712]
string: 'api' [1707,1712]
===
match
---
atom_expr [13780,13800]
atom_expr [13836,13856]
===
match
---
simple_stmt [15719,15754]
simple_stmt [15775,15810]
===
match
---
simple_stmt [10848,10883]
simple_stmt [10904,10939]
===
match
---
name: setUpClass [2700,2710]
name: setUpClass [2756,2766]
===
match
---
name: client [3647,3653]
name: client [3703,3709]
===
match
---
atom_expr [2604,2624]
atom_expr [2660,2680]
===
match
---
name: loads [6177,6182]
name: loads [6233,6238]
===
match
---
name: dag [12958,12961]
name: dag [13014,13017]
===
match
---
name: self [5358,5362]
name: self [5414,5418]
===
match
---
name: response [5100,5108]
name: response [5156,5164]
===
match
---
operator: = [12917,12918]
operator: = [12973,12974]
===
match
---
name: response [14149,14157]
name: response [14205,14213]
===
match
---
trailer [15907,15911]
trailer [15963,15967]
===
match
---
name: post [6724,6728]
name: post [6780,6784]
===
match
---
name: test_create_pool [16502,16518]
name: test_create_pool [16558,16574]
===
match
---
name: status_code [4264,4275]
name: status_code [4320,4331]
===
match
---
assert_stmt [5237,5278]
assert_stmt [5293,5334]
===
match
---
atom_expr [16545,16842]
atom_expr [16601,16898]
===
match
---
expr_stmt [13279,13327]
expr_stmt [13335,13383]
===
match
---
number: 1 [13454,13455]
number: 1 [13510,13511]
===
match
---
parameters [15362,15368]
parameters [15418,15424]
===
match
---
operator: } [17520,17521]
operator: } [17576,17577]
===
match
---
trailer [4093,4105]
trailer [4149,4161]
===
match
---
name: response [6362,6370]
name: response [6418,6426]
===
match
---
atom_expr [14900,14915]
atom_expr [14956,14971]
===
match
---
comparison [4568,4595]
comparison [4624,4651]
===
match
---
simple_stmt [7097,7142]
simple_stmt [7153,7198]
===
match
---
operator: == [12391,12393]
operator: == [12447,12449]
===
match
---
comp_op [13883,13889]
comp_op [13939,13945]
===
match
---
name: data [3854,3858]
name: data [3910,3914]
===
match
---
trailer [8189,8194]
trailer [8245,8250]
===
match
---
name: data [9844,9848]
name: data [9900,9904]
===
match
---
atom_expr [9056,9076]
atom_expr [9112,9132]
===
match
---
trailer [7139,7141]
trailer [7195,7197]
===
match
---
trailer [15590,15597]
trailer [15646,15653]
===
match
---
atom_expr [6712,6847]
atom_expr [6768,6903]
===
match
---
name: utcnow [9289,9295]
name: utcnow [9345,9351]
===
match
---
comparison [12430,12470]
comparison [12486,12526]
===
match
---
trailer [3798,3805]
trailer [3854,3861]
===
match
---
name: url_template [5888,5900]
name: url_template [5944,5956]
===
match
---
name: PAPERMILL_EXAMPLE_DAGS [12922,12944]
name: PAPERMILL_EXAMPLE_DAGS [12978,13000]
===
match
---
string: '    ' [17235,17241]
string: '    ' [17291,17297]
===
match
---
expr_stmt [15575,15669]
expr_stmt [15631,15725]
===
match
---
trailer [17674,17680]
trailer [17730,17736]
===
match
---
operator: == [5507,5509]
operator: == [5563,5565]
===
match
---
argument [9517,9530]
argument [9573,9586]
===
match
---
trailer [13910,13919]
trailer [13966,13975]
===
match
---
trailer [13683,13690]
trailer [13739,13746]
===
match
---
name: pool [17934,17938]
name: pool [17990,17994]
===
match
---
trailer [12831,12833]
trailer [12887,12889]
===
match
---
name: parse_datetime [6157,6171]
name: parse_datetime [6213,6227]
===
match
---
operator: = [7864,7865]
operator: = [7920,7921]
===
match
---
trailer [17278,17283]
trailer [17334,17339]
===
match
---
suite [2674,12471]
suite [2730,12527]
===
match
---
number: 200 [5503,5506]
number: 200 [5559,5562]
===
match
---
expr_stmt [6131,6232]
expr_stmt [6187,6288]
===
match
---
name: url_template [10271,10283]
name: url_template [10327,10339]
===
match
---
name: client [11473,11479]
name: client [11529,11535]
===
match
---
operator: , [12905,12906]
operator: , [12961,12962]
===
match
---
name: response [9975,9983]
name: response [10031,10039]
===
match
---
assert_stmt [17616,17650]
assert_stmt [17672,17706]
===
match
---
name: response [15726,15734]
name: response [15782,15790]
===
match
---
suite [16441,16493]
suite [16497,16549]
===
match
---
suite [9116,10939]
suite [9172,10995]
===
match
---
atom_expr [8328,8350]
atom_expr [8384,8406]
===
match
---
fstring_string: experimental_ [15055,15068]
fstring_string: experimental_ [15111,15124]
===
match
---
simple_stmt [2916,2955]
simple_stmt [2972,3011]
===
match
---
trailer [14424,14433]
trailer [14480,14489]
===
match
---
atom_expr [14949,14959]
atom_expr [15005,15015]
===
match
---
atom_expr [6552,6566]
atom_expr [6608,6622]
===
match
---
fstring [7710,7766]
fstring [7766,7822]
===
match
---
simple_stmt [18006,18041]
simple_stmt [18062,18097]
===
match
---
trailer [17680,17711]
trailer [17736,17767]
===
match
---
simple_stmt [9238,9264]
simple_stmt [9294,9320]
===
match
---
atom_expr [14267,14334]
atom_expr [14323,14390]
===
match
---
expr_stmt [4115,4176]
expr_stmt [4171,4232]
===
match
---
atom_expr [3369,3389]
atom_expr [3425,3445]
===
match
---
trailer [17074,17089]
trailer [17130,17145]
===
match
---
name: self [17111,17115]
name: self [17167,17171]
===
match
---
atom_expr [15214,15236]
atom_expr [15270,15292]
===
match
---
number: 404 [18365,18368]
number: 404 [18421,18424]
===
match
---
trailer [7295,7301]
trailer [7351,7357]
===
match
---
simple_stmt [8086,8121]
simple_stmt [8142,8177]
===
match
---
name: DagBag [12876,12882]
name: DagBag [12932,12938]
===
match
---
name: unittest [826,834]
name: unittest [826,834]
===
match
---
operator: , [13455,13456]
operator: , [13511,13512]
===
match
---
dictorsetmaker [1706,1748]
dictorsetmaker [1706,1748]
===
match
---
name: self [1913,1917]
name: self [1913,1917]
===
match
---
trailer [6370,6375]
trailer [6426,6431]
===
match
---
expr_stmt [6481,6530]
expr_stmt [6537,6586]
===
match
---
name: json [17670,17674]
name: json [17726,17730]
===
match
---
name: response [14404,14412]
name: response [14460,14468]
===
match
---
trailer [13898,13903]
trailer [13954,13959]
===
match
---
simple_stmt [16454,16493]
simple_stmt [16510,16549]
===
match
---
trailer [18388,18394]
trailer [18444,18450]
===
match
---
name: url_template [14515,14527]
name: url_template [14571,14583]
===
match
---
name: response [16206,16214]
name: response [16262,16270]
===
match
---
operator: , [14050,14051]
operator: , [14106,14107]
===
match
---
string: '/api/experimental/dags/{}/dag_runs/{}/tasks/{}' [9140,9188]
string: '/api/experimental/dags/{}/dag_runs/{}/tasks/{}' [9196,9244]
===
match
---
atom_expr [3405,3446]
atom_expr [3461,3502]
===
match
---
name: data [13839,13843]
name: data [13895,13899]
===
match
---
trailer [18394,18425]
trailer [18450,18481]
===
match
---
simple_stmt [5847,6038]
simple_stmt [5903,6094]
===
match
---
name: dumps [7947,7952]
name: dumps [8003,8008]
===
match
---
argument [12907,12944]
argument [12963,13000]
===
match
---
comparison [9824,9864]
comparison [9880,9920]
===
match
---
name: description [15170,15181]
name: description [15226,15237]
===
match
---
simple_stmt [4456,4489]
simple_stmt [4512,4545]
===
match
---
simple_stmt [13766,13801]
simple_stmt [13822,13857]
===
match
---
string: 'error' [10152,10159]
string: 'error' [10208,10215]
===
match
---
name: test_dag_paused [4712,4727]
name: test_dag_paused [4768,4783]
===
match
---
comparison [6095,6122]
comparison [6151,6178]
===
match
---
funcdef [10944,12471]
funcdef [11000,12527]
===
match
---
operator: } [16771,16772]
operator: } [16827,16828]
===
match
---
atom_expr [3845,3874]
atom_expr [3901,3930]
===
match
---
atom_expr [11640,11669]
atom_expr [11696,11725]
===
match
---
name: close [12850,12855]
name: close [12906,12911]
===
match
---
operator: = [9416,9417]
operator: = [9472,9473]
===
match
---
trailer [14534,14560]
trailer [14590,14616]
===
match
---
atom_expr [9505,9600]
atom_expr [9561,9656]
===
match
---
name: data [10682,10686]
name: data [10738,10742]
===
match
---
name: trigger_dag [9505,9516]
name: trigger_dag [9561,9572]
===
match
---
atom_expr [18514,18530]
atom_expr [18570,18586]
===
match
---
operator: @ [12630,12631]
operator: @ [12686,12687]
===
match
---
trailer [15788,15793]
trailer [15844,15849]
===
match
---
import_from [1149,1185]
import_from [1149,1185]
===
match
---
simple_stmt [5347,5435]
simple_stmt [5403,5491]
===
match
---
name: timezone [1205,1213]
name: timezone [1205,1213]
===
match
---
trailer [3248,3254]
trailer [3304,3310]
===
match
---
name: execution_date [9358,9372]
name: execution_date [9414,9428]
===
match
---
assert_stmt [6856,6890]
assert_stmt [6912,6946]
===
match
---
name: status_code [16240,16251]
name: status_code [16296,16307]
===
match
---
string: 'utf-8' [10184,10191]
string: 'utf-8' [10240,10247]
===
match
---
operator: , [7923,7924]
operator: , [7979,7980]
===
match
---
assert_stmt [10348,10382]
assert_stmt [10404,10438]
===
match
---
trailer [9689,9723]
trailer [9745,9779]
===
match
---
name: json [794,798]
name: json [794,798]
===
match
---
trailer [1620,1627]
trailer [1620,1627]
===
match
---
name: execution_date [7115,7129]
name: execution_date [7171,7185]
===
match
---
name: data [8636,8640]
name: data [8692,8696]
===
match
---
atom_expr [5951,5981]
atom_expr [6007,6037]
===
match
---
trailer [16473,16479]
trailer [16529,16535]
===
match
---
trailer [6723,6728]
trailer [6779,6784]
===
match
---
name: url_template [6941,6953]
name: url_template [6997,7009]
===
match
---
name: response [8181,8189]
name: response [8237,8245]
===
match
---
name: status_code [12176,12187]
name: status_code [12232,12243]
===
match
---
trailer [15015,15031]
trailer [15071,15087]
===
match
---
string: "application/json" [6819,6837]
string: "application/json" [6875,6893]
===
match
---
number: 1 [13463,13464]
number: 1 [13519,13520]
===
match
---
name: response [16899,16907]
name: response [16955,16963]
===
match
---
atom_expr [1629,1638]
atom_expr [1629,1638]
===
match
---
trailer [7554,7572]
trailer [7610,7628]
===
match
---
name: experimental [982,994]
name: experimental [982,994]
===
match
---
comparison [11629,11669]
comparison [11685,11725]
===
match
---
decorated [13067,14661]
decorated [13123,14717]
===
match
---
assert_stmt [4071,4105]
assert_stmt [4127,4161]
===
match
---
trailer [12449,12454]
trailer [12505,12510]
===
match
---
atom_expr [4616,4659]
atom_expr [4672,4715]
===
match
---
name: get [4628,4631]
name: get [4684,4687]
===
match
---
trailer [5900,5907]
trailer [5956,5963]
===
match
---
string: 'error' [3830,3837]
string: 'error' [3886,3893]
===
match
---
trailer [3254,3256]
trailer [3310,3312]
===
match
---
operator: = [8714,8715]
operator: = [8770,8771]
===
match
---
name: get [15401,15404]
name: get [15457,15460]
===
match
---
simple_stmt [15885,15943]
simple_stmt [15941,15999]
===
match
---
name: client [5863,5869]
name: client [5919,5925]
===
match
---
string: 'example_bash_operator' [7010,7033]
string: 'example_bash_operator' [7066,7089]
===
match
---
atom [7302,7337]
atom [7358,7393]
===
match
---
argument [6806,6837]
argument [6862,6893]
===
match
---
operator: } [8686,8687]
operator: } [8742,8743]
===
match
---
atom_expr [10784,10838]
atom_expr [10840,10894]
===
match
---
trailer [2312,2314]
trailer [2312,2314]
===
match
---
comparison [10898,10938]
comparison [10954,10994]
===
match
---
trailer [14282,14334]
trailer [14338,14390]
===
match
---
trailer [9669,9724]
trailer [9725,9780]
===
match
---
trailer [7870,7877]
trailer [7926,7933]
===
match
---
comparison [9781,9808]
comparison [9837,9864]
===
match
---
comparison [13773,13800]
comparison [13829,13856]
===
match
---
name: response [18067,18075]
name: response [18123,18131]
===
match
---
operator: = [9246,9247]
operator: = [9302,9303]
===
match
---
number: 200 [8093,8096]
number: 200 [8149,8152]
===
match
---
name: assert_deprecated [5049,5066]
name: assert_deprecated [5105,5122]
===
match
---
argument [13313,13326]
argument [13369,13382]
===
match
---
trailer [5518,5530]
trailer [5574,5586]
===
match
---
operator: == [5314,5316]
operator: == [5370,5372]
===
match
---
param [4303,4307]
param [4359,4363]
===
match
---
atom_expr [15311,15320]
atom_expr [15367,15376]
===
match
---
comparison [16001,16081]
comparison [16057,16137]
===
match
---
name: urllib [897,903]
name: urllib [897,903]
===
match
---
operator: == [17793,17795]
operator: == [17849,17851]
===
match
---
arith_expr [7059,7088]
arith_expr [7115,7144]
===
match
---
atom_expr [7070,7088]
atom_expr [7126,7144]
===
match
---
string: "Pool 'foo' doesn't exist" [18438,18464]
string: "Pool 'foo' doesn't exist" [18494,18520]
===
match
---
name: get [12321,12324]
name: get [12377,12380]
===
match
---
trailer [3502,3520]
trailer [3558,3576]
===
match
---
name: get [16144,16147]
name: get [16200,16203]
===
match
---
simple_stmt [1186,1263]
simple_stmt [1186,1263]
===
match
---
name: get [5370,5373]
name: get [5426,5429]
===
match
---
atom_expr [15447,15467]
atom_expr [15503,15523]
===
match
---
fstring_end: ' [15657,15658]
fstring_end: ' [15713,15714]
===
match
---
trailer [15253,15259]
trailer [15309,15315]
===
match
---
name: Session [1178,1185]
name: Session [1178,1185]
===
match
---
name: status_code [15456,15467]
name: status_code [15512,15523]
===
match
---
name: get [15598,15601]
name: get [15654,15657]
===
match
---
trailer [3657,3714]
trailer [3713,3770]
===
match
---
string: "papermill" [12596,12607]
string: "papermill" [12652,12663]
===
match
---
name: get [3654,3657]
name: get [3710,3713]
===
match
---
trailer [11496,11503]
trailer [11552,11559]
===
match
---
trailer [17283,17603]
trailer [17339,17659]
===
match
---
operator: = [13545,13546]
operator: = [13601,13602]
===
match
---
classdef [12473,14661]
classdef [12529,14717]
===
match
---
trailer [5266,5278]
trailer [5322,5334]
===
match
---
name: airflow [1093,1100]
name: airflow [1093,1100]
===
match
---
name: json [18384,18388]
name: json [18440,18444]
===
match
---
suite [6932,9077]
suite [6988,9133]
===
match
---
name: TaskInstance [1075,1087]
name: TaskInstance [1075,1087]
===
match
---
arglist [18285,18315]
arglist [18341,18371]
===
match
---
operator: , [14541,14542]
operator: , [14597,14598]
===
match
---
atom_expr [17870,17956]
atom_expr [17926,18012]
===
match
---
simple_stmt [6611,6651]
simple_stmt [6667,6707]
===
match
---
name: app [2007,2010]
name: app [2007,2010]
===
match
---
simple_stmt [12772,12809]
simple_stmt [12828,12865]
===
match
---
atom_expr [17796,17817]
atom_expr [17852,17873]
===
match
---
name: data [7937,7941]
name: data [7993,7997]
===
match
---
operator: , [12119,12120]
operator: , [12175,12176]
===
match
---
name: patch [13073,13078]
name: patch [13129,13134]
===
match
---
name: setUp [14908,14913]
name: setUp [14964,14969]
===
match
---
trailer [8651,8688]
trailer [8707,8744]
===
match
---
name: data [4532,4536]
name: data [4588,4592]
===
match
---
atom_expr [17267,17603]
atom_expr [17323,17659]
===
match
---
operator: == [5673,5675]
operator: == [5729,5731]
===
match
---
comparison [8760,8787]
comparison [8816,8843]
===
match
---
assert_stmt [3883,3917]
assert_stmt [3939,3973]
===
match
---
string: 'utf-8' [4224,4231]
string: 'utf-8' [4280,4287]
===
match
---
operator: = [17868,17869]
operator: = [17924,17925]
===
match
---
arglist [3678,3712]
arglist [3734,3768]
===
match
---
simple_stmt [15575,15670]
simple_stmt [15631,15726]
===
match
---
for_stmt [12954,13062]
for_stmt [13010,13118]
===
match
---
name: client [13660,13666]
name: client [13716,13722]
===
match
---
name: dag_id [7629,7635]
name: dag_id [7685,7691]
===
match
---
string: 'description' [17075,17088]
string: 'description' [17131,17144]
===
match
---
trailer [8383,8408]
trailer [8439,8464]
===
match
---
trailer [8775,8787]
trailer [8831,8843]
===
match
---
operator: == [10859,10861]
operator: == [10915,10917]
===
match
---
simple_stmt [12999,13016]
simple_stmt [13055,13072]
===
match
---
string: '/api/experimental/dags/{}/dag_runs' [5753,5789]
string: '/api/experimental/dags/{}/dag_runs' [5809,5845]
===
match
---
atom_expr [13425,13478]
atom_expr [13481,13534]
===
match
---
name: session [2361,2368]
name: session [2361,2368]
===
match
---
name: get [4138,4141]
name: get [4194,4197]
===
match
---
name: content_type [8035,8047]
name: content_type [8091,8103]
===
match
---
param [12662,12665]
param [12718,12721]
===
match
---
atom_expr [4203,4232]
atom_expr [4259,4288]
===
match
---
trailer [11251,11272]
trailer [11307,11328]
===
match
---
simple_stmt [13725,13758]
simple_stmt [13781,13814]
===
match
---
name: test_info [3293,3302]
name: test_info [3349,3358]
===
match
---
fstring_end: ' [7765,7766]
fstring_end: ' [7821,7822]
===
match
---
operator: = [8153,8154]
operator: = [8209,8210]
===
match
---
funcdef [9082,10939]
funcdef [9138,10995]
===
match
---
simple_stmt [6539,6567]
simple_stmt [6595,6623]
===
match
---
atom [6801,6803]
atom [6857,6859]
===
match
---
operator: = [13189,13190]
operator: = [13245,13246]
===
match
---
name: execution_date [13571,13585]
name: execution_date [13627,13641]
===
match
---
name: test_get_pools [16091,16105]
name: test_get_pools [16147,16161]
===
match
---
atom_expr [3416,3445]
atom_expr [3472,3501]
===
match
---
name: test_dagrun_status [10948,10966]
name: test_dagrun_status [11004,11022]
===
match
---
atom_expr [1928,1936]
atom_expr [1928,1936]
===
match
---
trailer [2241,2261]
trailer [2241,2261]
===
match
---
simple_stmt [16183,16216]
simple_stmt [16239,16272]
===
match
---
name: url [3318,3321]
name: url [3374,3377]
===
match
---
name: url_template [3570,3582]
name: url_template [3626,3638]
===
match
---
string: 'Link' [2617,2623]
string: 'Link' [2673,2679]
===
match
---
operator: == [16920,16922]
operator: == [16976,16978]
===
match
---
fstring_expr [8472,8488]
fstring_expr [8528,8544]
===
match
---
simple_stmt [5595,5637]
simple_stmt [5651,5693]
===
match
---
name: status_code [8776,8787]
name: status_code [8832,8843]
===
match
---
parameters [16518,16524]
parameters [16574,16580]
===
match
---
name: join [12554,12558]
name: join [12610,12614]
===
match
---
operator: , [8021,8022]
operator: , [8077,8078]
===
match
---
operator: + [17159,17160]
operator: + [17215,17216]
===
match
---
classdef [1655,2636]
classdef [1655,2692]
===
match
---
trailer [7628,7636]
trailer [7684,7692]
===
match
---
name: execution_date [13586,13600]
name: execution_date [13642,13656]
===
match
---
comparison [18013,18040]
comparison [18069,18096]
===
match
---
trailer [2140,2154]
trailer [2140,2154]
===
match
---
name: os [1629,1631]
name: os [1629,1631]
===
match
---
operator: = [7589,7590]
operator: = [7645,7646]
===
match
---
operator: , [13449,13450]
operator: , [13505,13506]
===
match
---
name: client [5363,5369]
name: client [5419,5425]
===
match
---
trailer [12175,12187]
trailer [12231,12243]
===
match
---
trailer [3205,3207]
trailer [3261,3263]
===
match
---
param [4728,4732]
param [4784,4788]
===
match
---
trailer [16946,16952]
trailer [17002,17008]
===
match
---
trailer [5907,5932]
trailer [5963,5988]
===
match
---
trailer [18271,18325]
trailer [18327,18381]
===
match
---
atom [5294,5313]
atom [5350,5369]
===
match
---
name: client [16550,16556]
name: client [16606,16612]
===
match
---
trailer [18118,18120]
trailer [18174,18176]
===
match
---
trailer [14867,14869]
trailer [14923,14925]
===
match
---
atom_expr [4142,4175]
atom_expr [4198,4231]
===
match
---
name: url_template [12093,12105]
name: url_template [12149,12161]
===
match
---
name: post [7227,7231]
name: post [7283,7287]
===
match
---
suite [17243,17755]
suite [17299,17811]
===
match
---
name: self [2356,2360]
name: self [2356,2360]
===
match
---
atom_expr [13890,13919]
atom_expr [13946,13975]
===
match
---
name: get [11480,11483]
name: get [11536,11539]
===
match
---
atom_expr [16851,16883]
atom_expr [16907,16939]
===
match
---
name: self [15586,15590]
name: self [15642,15646]
===
match
---
string: '/api/experimental/pools' [16575,16600]
string: '/api/experimental/pools' [16631,16656]
===
match
---
atom_expr [14102,14122]
atom_expr [14158,14178]
===
match
---
comparison [6248,6288]
comparison [6304,6344]
===
match
---
name: headers [2609,2616]
name: headers [2665,2672]
===
match
---
trailer [14295,14302]
trailer [14351,14358]
===
match
---
simple_stmt [6131,6233]
simple_stmt [6187,6289]
===
match
---
comparison [8246,8286]
comparison [8302,8342]
===
match
---
atom_expr [2925,2954]
atom_expr [2981,3010]
===
match
---
fstring_expr [7749,7765]
fstring_expr [7805,7821]
===
match
---
atom_expr [11468,11529]
atom_expr [11524,11585]
===
match
---
assert_stmt [16325,16367]
assert_stmt [16381,16423]
===
match
---
simple_stmt [14343,14378]
simple_stmt [14399,14434]
===
match
---
trailer [10531,10538]
trailer [10587,10594]
===
match
---
trailer [16005,16011]
trailer [16061,16067]
===
match
---
expr_stmt [5738,5789]
expr_stmt [5794,5845]
===
match
---
string: r'\<.+/stable-rest-api/migration.html\>; ' [2510,2552]
string: r'\<.+/upgrading-to-2.html#migration-guide-from-experimental-api-to-stable-api-v1\>; ' [2510,2596]
===
match
---
trailer [3065,3070]
trailer [3121,3126]
===
match
---
trailer [4690,4702]
trailer [4746,4758]
===
match
---
comparison [2434,2471]
comparison [2434,2471]
===
match
---
operator: { [15068,15069]
operator: { [15124,15125]
===
match
---
simple_stmt [2866,2883]
simple_stmt [2922,2939]
===
match
---
operator: = [9317,9318]
operator: = [9373,9374]
===
match
---
dotted_name [1191,1213]
dotted_name [1191,1213]
===
match
---
assert_stmt [14131,14178]
assert_stmt [14187,14234]
===
match
---
name: test_delete_pool_non_existing [18197,18226]
name: test_delete_pool_non_existing [18253,18282]
===
match
---
trailer [3184,3198]
trailer [3240,3254]
===
match
---
simple_stmt [2427,2472]
simple_stmt [2427,2472]
===
match
---
trailer [4964,4971]
trailer [5020,5027]
===
match
---
operator: = [7612,7613]
operator: = [7668,7669]
===
match
---
atom_expr [12772,12808]
atom_expr [12828,12864]
===
match
---
trailer [3178,3184]
trailer [3234,3240]
===
match
---
simple_stmt [4015,4063]
simple_stmt [4071,4119]
===
match
---
name: p [16429,16430]
name: p [16485,16486]
===
match
---
trailer [18087,18096]
trailer [18143,18152]
===
match
---
string: "application/json" [6008,6026]
string: "application/json" [6064,6082]
===
match
---
trailer [12234,12243]
trailer [12290,12299]
===
match
---
string: 'not_a_datetime' [14543,14559]
string: 'not_a_datetime' [14599,14615]
===
match
---
name: configure_orm [2332,2345]
name: configure_orm [2332,2345]
===
match
---
name: response [9835,9843]
name: response [9891,9899]
===
match
---
string: 'execution_date' [8212,8228]
string: 'execution_date' [8268,8284]
===
match
---
operator: = [13240,13241]
operator: = [13296,13297]
===
match
---
operator: , [16714,16715]
operator: , [16770,16771]
===
match
---
operator: = [7085,7086]
operator: = [7141,7142]
===
match
---
dictorsetmaker [5653,5671]
dictorsetmaker [5709,5727]
===
match
---
expr_stmt [12867,12945]
expr_stmt [12923,13001]
===
match
---
name: client [7871,7877]
name: client [7927,7933]
===
match
---
operator: == [13777,13779]
operator: == [13833,13835]
===
match
---
name: response [10163,10171]
name: response [10219,10227]
===
match
---
name: self [14885,14889]
name: self [14941,14945]
===
match
---
atom_expr [12546,12624]
atom_expr [12602,12680]
===
match
---
name: response [15447,15455]
name: response [15503,15511]
===
match
---
string: 'false' [5425,5432]
string: 'false' [5481,5488]
===
match
---
simple_stmt [8239,8287]
simple_stmt [8295,8343]
===
match
---
number: 0 [11132,11133]
number: 0 [11188,11189]
===
match
---
name: Session [12715,12722]
name: Session [12771,12778]
===
match
---
arglist [8883,9023]
arglist [8939,9079]
===
match
---
name: get_dag [7621,7628]
name: get_dag [7677,7684]
===
match
---
assert_stmt [5496,5530]
assert_stmt [5552,5586]
===
match
---
trailer [16479,16482]
trailer [16535,16538]
===
match
---
name: dag_id [13524,13530]
name: dag_id [13580,13586]
===
match
---
name: microsecond [8275,8286]
name: microsecond [8331,8342]
===
match
---
trailer [18403,18408]
trailer [18459,18464]
===
match
---
operator: , [8733,8734]
operator: , [8789,8790]
===
match
---
operator: , [8688,8689]
operator: , [8744,8745]
===
match
---
atom_expr [3938,4006]
atom_expr [3994,4062]
===
match
---
name: response [4949,4957]
name: response [5005,5013]
===
match
---
expr_stmt [8322,8350]
expr_stmt [8378,8406]
===
match
---
comparison [11948,11988]
comparison [12004,12044]
===
match
---
argument [7937,8021]
argument [7993,8077]
===
match
---
string: 'execution_date' [8941,8957]
string: 'execution_date' [8997,9013]
===
match
---
trailer [8194,8201]
trailer [8250,8257]
===
match
---
string: 'utf-8' [3806,3813]
string: 'utf-8' [3862,3869]
===
match
---
assert_stmt [11898,11932]
assert_stmt [11954,11988]
===
match
---
simple_stmt [16935,16984]
simple_stmt [16991,17040]
===
match
---
expr_stmt [3570,3621]
expr_stmt [3626,3677]
===
match
---
trailer [8933,8939]
trailer [8989,8995]
===
match
---
simple_stmt [16534,16843]
simple_stmt [16590,16899]
===
match
---
name: paused_response [5676,5691]
name: paused_response [5732,5747]
===
match
---
string: 'test_task_instance_info_run' [9539,9568]
string: 'test_task_instance_info_run' [9595,9624]
===
match
---
name: testing [1962,1969]
name: testing [1962,1969]
===
match
---
name: os [1607,1609]
name: os [1607,1609]
===
match
---
trailer [5824,5826]
trailer [5880,5882]
===
match
---
trailer [5211,5215]
trailer [5267,5271]
===
match
---
operator: = [7364,7365]
operator: = [7420,7421]
===
match
---
name: self [16132,16136]
name: self [16188,16192]
===
match
---
trailer [9295,9297]
trailer [9351,9353]
===
match
---
atom_expr [16619,16786]
atom_expr [16675,16842]
===
match
---
simple_stmt [2480,2636]
simple_stmt [2480,2692]
===
match
---
simple_stmt [14488,14562]
simple_stmt [14544,14618]
===
match
---
trailer [5204,5211]
trailer [5260,5267]
===
match
---
name: task_id [10074,10081]
name: task_id [10130,10137]
===
match
---
trailer [4263,4275]
trailer [4319,4331]
===
match
---
number: 1 [11258,11259]
number: 1 [11314,11315]
===
match
---
atom_expr [4575,4595]
atom_expr [4631,4651]
===
match
---
dictorsetmaker [5963,5979]
dictorsetmaker [6019,6035]
===
match
---
name: loads [18695,18700]
name: loads [18751,18756]
===
match
---
simple_stmt [4185,4233]
simple_stmt [4241,4289]
===
match
---
name: response [11457,11465]
name: response [11513,11521]
===
match
---
trailer [2834,2848]
trailer [2890,2904]
===
match
---
operator: = [13653,13654]
operator: = [13709,13710]
===
match
---
trailer [17874,17881]
trailer [17930,17937]
===
match
---
name: json [5333,5337]
name: json [5389,5393]
===
match
---
trailer [6382,6391]
trailer [6438,6447]
===
match
---
name: status_code [6879,6890]
name: status_code [6935,6946]
===
match
---
comparison [17070,17095]
comparison [17126,17151]
===
match
---
atom_expr [10768,10839]
atom_expr [10824,10895]
===
match
---
string: 'utf-8' [18722,18729]
string: 'utf-8' [18778,18785]
===
match
---
trailer [15597,15601]
trailer [15653,15657]
===
match
---
trailer [11713,11720]
trailer [11769,11776]
===
match
---
name: json [16275,16279]
name: json [16331,16335]
===
match
---
trailer [1932,1936]
trailer [1932,1936]
===
match
---
operator: = [5751,5752]
operator: = [5807,5808]
===
match
---
number: 200 [11586,11589]
number: 200 [11642,11645]
===
match
---
name: decode [10423,10429]
name: decode [10479,10485]
===
match
---
assert_stmt [6611,6650]
assert_stmt [6667,6706]
===
match
---
trailer [3121,3123]
trailer [3177,3179]
===
match
---
atom [7953,8020]
atom [8009,8076]
===
match
---
name: data [17690,17694]
name: data [17746,17750]
===
match
---
trailer [2848,2855]
trailer [2904,2911]
===
match
---
name: client [4965,4971]
name: client [5021,5027]
===
match
---
expr_stmt [17859,17956]
expr_stmt [17915,18012]
===
match
---
operator: = [2155,2156]
operator: = [2155,2156]
===
match
---
name: session [12842,12849]
name: session [12898,12905]
===
match
---
for_stmt [17218,17755]
for_stmt [17274,17811]
===
match
---
name: datetime_string [11512,11527]
name: datetime_string [11568,11583]
===
match
---
trailer [13389,13391]
trailer [13445,13447]
===
match
---
name: get [5212,5215]
name: get [5268,5271]
===
match
---
atom_expr [18550,18631]
atom_expr [18606,18687]
===
match
---
name: application [1939,1950]
name: application [1939,1950]
===
match
---
number: 404 [8760,8763]
number: 404 [8816,8819]
===
match
---
operator: @ [1755,1756]
operator: @ [1755,1756]
===
match
---
comparison [3890,3917]
comparison [3946,3973]
===
match
---
name: quote_plus [11232,11242]
name: quote_plus [11288,11298]
===
match
---
operator: = [13585,13586]
operator: = [13641,13642]
===
match
---
simple_stmt [10145,10193]
simple_stmt [10201,10249]
===
match
---
trailer [11109,11111]
trailer [11165,11167]
===
match
---
string: 'example_bash_operator' [11054,11077]
string: 'example_bash_operator' [11110,11133]
===
match
---
name: cls [12918,12921]
name: cls [12974,12977]
===
match
---
string: 'ok' [5450,5454]
string: 'ok' [5506,5510]
===
match
---
trailer [12971,12976]
trailer [13027,13032]
===
match
---
name: session [15286,15293]
name: session [15342,15349]
===
match
---
operator: == [17721,17723]
operator: == [17777,17779]
===
match
---
name: self [17870,17874]
name: self [17926,17930]
===
match
---
name: cls [12662,12665]
name: cls [12718,12721]
===
match
---
name: setUpClass [12684,12694]
name: setUpClass [12740,12750]
===
match
---
atom_expr [2764,2773]
atom_expr [2820,2829]
===
match
---
number: 200 [5145,5148]
number: 200 [5201,5204]
===
match
---
name: format [3671,3677]
name: format [3727,3733]
===
match
---
name: json [8170,8174]
name: json [8226,8230]
===
match
---
trailer [14514,14561]
trailer [14570,14617]
===
match
---
name: clear_db_pools [18514,18528]
name: clear_db_pools [18570,18584]
===
match
---
name: response [5347,5355]
name: response [5403,5411]
===
match
---
operator: , [1229,1230]
operator: , [1229,1230]
===
match
---
trailer [1551,1556]
trailer [1551,1556]
===
match
---
name: wrong_datetime_string [10571,10592]
name: wrong_datetime_string [10627,10648]
===
match
---
simple_stmt [10516,10604]
simple_stmt [10572,10660]
===
match
---
number: 200 [16255,16258]
number: 200 [16311,16314]
===
match
---
name: settings [949,957]
name: settings [949,957]
===
match
---
trailer [7257,7264]
trailer [7313,7320]
===
match
---
string: 'utf-8' [18088,18095]
string: 'utf-8' [18144,18151]
===
match
---
operator: = [18251,18252]
operator: = [18307,18308]
===
match
---
operator: , [11878,11879]
operator: , [11934,11935]
===
match
---
name: client [4131,4137]
name: client [4187,4193]
===
match
---
operator: , [11860,11861]
operator: , [11916,11917]
===
match
---
name: json [7513,7517]
name: json [7569,7573]
===
match
---
string: '/api/experimental/dags/{}/paused/{}' [4764,4801]
string: '/api/experimental/dags/{}/paused/{}' [4820,4857]
===
match
---
suite [14840,14870]
suite [14896,14926]
===
match
---
trailer [18257,18264]
trailer [18313,18320]
===
match
---
name: delete [12755,12761]
name: delete [12811,12817]
===
match
---
import_from [1026,1087]
import_from [1026,1087]
===
match
---
atom_expr [3114,3123]
atom_expr [3170,3179]
===
match
---
trailer [8857,8864]
trailer [8913,8920]
===
match
---
atom_expr [4960,5035]
atom_expr [5016,5091]
===
match
---
name: client [11796,11802]
name: client [11852,11858]
===
match
---
arglist [12113,12142]
arglist [12169,12198]
===
match
---
arglist [11252,11271]
arglist [11308,11327]
===
match
---
trailer [12683,12694]
trailer [12739,12750]
===
match
---
operator: = [16273,16274]
operator: = [16329,16330]
===
match
---
trailer [2182,2186]
trailer [2182,2186]
===
match
---
name: clear_db_pools [1420,1434]
name: clear_db_pools [1420,1434]
===
match
---
operator: { [6801,6802]
operator: { [6857,6858]
===
match
---
name: url_template [6742,6754]
name: url_template [6798,6810]
===
match
---
operator: = [4762,4763]
operator: = [4818,4819]
===
match
---
assert_stmt [15440,15474]
assert_stmt [15496,15530]
===
match
---
name: self [18227,18231]
name: self [18283,18287]
===
match
---
atom_expr [2356,2368]
atom_expr [2356,2368]
===
match
---
assert_stmt [12423,12470]
assert_stmt [12479,12526]
===
match
---
comparison [15769,15833]
comparison [15825,15889]
===
match
---
trailer [6110,6122]
trailer [6166,6178]
===
match
---
argument [13524,13537]
argument [13580,13593]
===
match
---
trailer [6716,6723]
trailer [6772,6779]
===
match
---
expr_stmt [11208,11285]
expr_stmt [11264,11341]
===
match
---
assert_stmt [15951,15985]
assert_stmt [16007,16041]
===
match
---
name: response_execution_date [6253,6276]
name: response_execution_date [6309,6332]
===
match
---
trailer [2789,2795]
trailer [2845,2851]
===
match
---
trailer [3793,3798]
trailer [3849,3854]
===
match
---
trailer [18066,18097]
trailer [18122,18153]
===
match
---
operator: , [18620,18621]
operator: , [18676,18677]
===
match
---
trailer [2730,2732]
trailer [2786,2788]
===
match
---
name: status_code [5161,5172]
name: status_code [5217,5228]
===
match
---
atom_expr [12077,12144]
atom_expr [12133,12200]
===
match
---
expr_stmt [6539,6566]
expr_stmt [6595,6622]
===
match
---
name: pause_url_template [5374,5392]
name: pause_url_template [5430,5448]
===
match
---
trailer [14984,14986]
trailer [15040,15042]
===
match
---
atom [17230,17242]
atom [17286,17298]
===
match
---
dotted_name [1347,1370]
dotted_name [1347,1370]
===
match
---
simple_stmt [8417,8490]
simple_stmt [8473,8546]
===
match
---
atom_expr [10015,10082]
atom_expr [10071,10138]
===
match
---
name: response [10626,10634]
name: response [10682,10690]
===
match
---
name: format [7909,7915]
name: format [7965,7971]
===
match
---
name: status_code [15967,15978]
name: status_code [16023,16034]
===
match
---
comparison [4504,4552]
comparison [4560,4608]
===
match
---
name: response [3927,3935]
name: response [3983,3991]
===
match
---
name: self [5858,5862]
name: self [5914,5918]
===
match
---
assert_stmt [2427,2471]
assert_stmt [2427,2471]
===
match
---
name: post [16557,16561]
name: post [16613,16617]
===
match
---
name: test_delete_pool [17827,17843]
name: test_delete_pool [17883,17899]
===
match
---
name: response [18242,18250]
name: response [18298,18306]
===
match
---
trailer [12754,12761]
trailer [12810,12817]
===
match
---
trailer [16556,16561]
trailer [16612,16617]
===
match
---
argument [1802,1892]
argument [1802,1892]
===
match
---
operator: = [8851,8852]
operator: = [8907,8908]
===
match
---
trailer [9428,9471]
trailer [9484,9527]
===
match
---
argument [15118,15127]
argument [15174,15183]
===
match
---
name: json [5951,5955]
name: json [6007,6011]
===
match
---
assert_stmt [5085,5129]
assert_stmt [5141,5185]
===
match
---
trailer [10693,10702]
trailer [10749,10758]
===
match
---
trailer [15646,15651]
trailer [15702,15707]
===
match
---
name: data [7286,7290]
name: data [7342,7346]
===
match
---
name: execution_date [11384,11398]
name: execution_date [11440,11454]
===
match
---
name: status_code [10371,10382]
name: status_code [10427,10438]
===
match
---
expr_stmt [16267,16316]
expr_stmt [16323,16372]
===
match
---
param [14835,14838]
param [14891,14894]
===
match
---
name: dumps [16624,16629]
name: dumps [16680,16685]
===
match
---
name: SerializedDagModel [3037,3055]
name: SerializedDagModel [3093,3111]
===
match
---
operator: == [18362,18364]
operator: == [18418,18420]
===
match
---
trailer [4211,4216]
trailer [4267,4272]
===
match
---
name: self [17137,17141]
name: self [17193,17197]
===
match
---
atom_expr [1578,1604]
atom_expr [1578,1604]
===
match
---
name: test_create_pool_with_bad_name [17172,17202]
name: test_create_pool_with_bad_name [17228,17258]
===
match
---
assert_stmt [6575,6602]
assert_stmt [6631,6658]
===
match
---
number: 1 [13460,13461]
number: 1 [13516,13517]
===
match
---
operator: , [2624,2625]
operator: , [2680,2681]
===
match
---
name: format [11833,11839]
name: format [11889,11895]
===
match
---
simple_stmt [5443,5488]
simple_stmt [5499,5544]
===
match
---
name: isoformat [5827,5836]
name: isoformat [5883,5892]
===
match
---
operator: == [7510,7512]
operator: == [7566,7568]
===
match
---
simple_stmt [17663,17755]
simple_stmt [17719,17811]
===
match
---
name: name [15123,15127]
name: name [15179,15183]
===
match
---
name: status_code [15735,15746]
name: status_code [15791,15802]
===
match
---
operator: = [7113,7114]
operator: = [7169,7170]
===
match
---
trailer [14271,14278]
trailer [14327,14334]
===
match
---
trailer [8311,8313]
trailer [8367,8369]
===
match
---
funcdef [16498,17163]
funcdef [16554,17219]
===
match
---
trailer [18694,18700]
trailer [18750,18756]
===
match
---
string: '/api/experimental/info' [3324,3348]
string: '/api/experimental/info' [3380,3404]
===
match
---
trailer [11972,11979]
trailer [12028,12035]
===
match
---
simple_stmt [1513,1653]
simple_stmt [1513,1653]
===
match
---
name: self [11468,11472]
name: self [11524,11528]
===
match
---
operator: = [6550,6551]
operator: = [6606,6607]
===
match
---
operator: = [9538,9539]
operator: = [9594,9595]
===
match
---
trailer [15100,15201]
trailer [15156,15257]
===
match
---
operator: , [15186,15187]
operator: , [15242,15243]
===
match
---
trailer [1631,1638]
trailer [1631,1638]
===
match
---
expr_stmt [4605,4659]
expr_stmt [4661,4715]
===
match
---
simple_stmt [7487,7573]
simple_stmt [7543,7629]
===
match
---
trailer [12761,12763]
trailer [12817,12819]
===
match
---
assert_stmt [10102,10136]
assert_stmt [10158,10192]
===
match
---
name: i [15151,15152]
name: i [15207,15208]
===
match
---
trailer [13838,13843]
trailer [13894,13899]
===
match
---
name: ROOT_FOLDER [1513,1524]
name: ROOT_FOLDER [1513,1524]
===
match
---
name: response [4479,4487]
name: response [4535,4543]
===
match
---
string: 'true' [5027,5033]
string: 'true' [5083,5089]
===
match
---
simple_stmt [11622,11670]
simple_stmt [11678,11726]
===
match
---
trailer [14644,14651]
trailer [14700,14707]
===
match
---
name: response [12394,12402]
name: response [12450,12458]
===
match
---
operator: , [17419,17420]
operator: , [17475,17476]
===
match
---
trailer [12092,12144]
trailer [12148,12200]
===
match
---
simple_stmt [2821,2858]
simple_stmt [2877,2914]
===
match
---
name: decode [4217,4223]
name: decode [4273,4279]
===
match
---
simple_stmt [4668,4703]
simple_stmt [4724,4759]
===
match
---
comparison [3772,3814]
comparison [3828,3870]
===
match
---
simple_stmt [12153,12188]
simple_stmt [12209,12244]
===
match
---
operator: = [8326,8327]
operator: = [8382,8383]
===
match
---
trailer [4651,4658]
trailer [4707,4714]
===
match
---
string: '/api/experimental/dags/{}/paused' [4832,4866]
string: '/api/experimental/dags/{}/paused' [4888,4922]
===
match
---
name: dag_run [6481,6488]
name: dag_run [6537,6544]
===
match
---
name: execution_date [11399,11413]
name: execution_date [11455,11469]
===
match
---
parameters [14884,14890]
parameters [14940,14946]
===
match
---
comparison [17670,17754]
comparison [17726,17810]
===
match
---
name: datetime_string [8671,8686]
name: datetime_string [8727,8742]
===
match
---
trailer [6203,6212]
trailer [6259,6268]
===
match
---
funcdef [4281,4703]
funcdef [4337,4759]
===
match
---
trailer [10283,10290]
trailer [10339,10346]
===
match
---
decorator [13067,13135]
decorator [13123,13191]
===
match
---
trailer [6640,6650]
trailer [6696,6706]
===
match
---
atom_expr [7614,7636]
atom_expr [7670,7692]
===
match
---
name: dag [3066,3069]
name: dag [3122,3125]
===
match
---
operator: = [10525,10526]
operator: = [10581,10582]
===
match
---
param [17203,17207]
param [17259,17263]
===
match
---
atom_expr [18701,18730]
atom_expr [18757,18786]
===
match
---
name: self [15311,15315]
name: self [15367,15371]
===
match
---
name: config [2235,2241]
name: config [2235,2241]
===
match
---
name: dag_run_id [6618,6628]
name: dag_run_id [6674,6684]
===
match
---
name: self [13655,13659]
name: self [13711,13715]
===
match
---
atom_expr [13725,13757]
atom_expr [13781,13813]
===
match
---
operator: == [7455,7457]
operator: == [7511,7513]
===
match
---
argument [11120,11133]
argument [11176,11189]
===
match
---
trailer [12227,12234]
trailer [12283,12290]
===
match
---
trailer [8902,8910]
trailer [8958,8966]
===
match
---
expr_stmt [6340,6392]
expr_stmt [6396,6448]
===
match
---
assert_stmt [14386,14433]
assert_stmt [14442,14489]
===
match
---
name: assert_deprecated [15683,15700]
name: assert_deprecated [15739,15756]
===
match
---
fstring_start: f' [17902,17904]
fstring_start: f' [17958,17960]
===
match
---
name: data [6371,6375]
name: data [6427,6431]
===
match
---
simple_stmt [14900,14916]
simple_stmt [14956,14972]
===
match
---
string: '/api/experimental/pools/foo' [15912,15941]
string: '/api/experimental/pools/foo' [15968,15997]
===
match
---
name: get [4972,4975]
name: get [5028,5031]
===
match
---
operator: , [10314,10315]
operator: , [10370,10371]
===
match
---
name: data [14158,14162]
name: data [14214,14218]
===
match
---
simple_stmt [6241,6289]
simple_stmt [6297,6345]
===
match
---
atom_expr [17929,17943]
atom_expr [17985,17999]
===
match
---
atom_expr [3132,3162]
atom_expr [3188,3218]
===
match
---
operator: { [7953,7954]
operator: { [8009,8010]
===
match
---
expr_stmt [9643,9724]
expr_stmt [9699,9780]
===
match
---
trailer [7877,7882]
trailer [7933,7938]
===
match
---
number: 1 [14770,14771]
number: 1 [14826,14827]
===
match
---
name: dumps [17354,17359]
name: dumps [17410,17415]
===
match
---
parameters [18226,18232]
parameters [18282,18288]
===
match
---
name: app [2297,2300]
name: app [2297,2300]
===
match
---
trailer [2898,2904]
trailer [2954,2960]
===
match
---
import_from [1186,1262]
import_from [1186,1262]
===
match
---
atom_expr [3658,3713]
atom_expr [3714,3769]
===
match
---
operator: == [4572,4574]
operator: == [4628,4630]
===
match
---
trailer [13850,13859]
trailer [13906,13915]
===
match
---
string: 'error' [11948,11955]
string: 'error' [12004,12011]
===
match
---
trailer [5215,5227]
trailer [5271,5283]
===
match
---
operator: = [14265,14266]
operator: = [14321,14322]
===
match
---
trailer [11186,11196]
trailer [11242,11252]
===
match
---
name: response [11780,11788]
name: response [11836,11844]
===
match
---
param [15560,15564]
param [15616,15620]
===
match
---
string: "init_api_experimental_auth" [1819,1847]
string: "init_api_experimental_auth" [1819,1847]
===
match
---
name: response [3785,3793]
name: response [3841,3849]
===
match
---
name: response [15885,15893]
name: response [15941,15949]
===
match
---
name: airflow [1154,1161]
name: airflow [1154,1161]
===
match
---
string: 'execution_date' [7954,7970]
string: 'execution_date' [8010,8026]
===
match
---
name: setUpClass [12651,12661]
name: setUpClass [12707,12717]
===
match
---
trailer [13379,13389]
trailer [13435,13445]
===
match
---
comparison [14577,14604]
comparison [14633,14660]
===
match
---
trailer [5624,5636]
trailer [5680,5692]
===
match
---
name: response [13890,13898]
name: response [13946,13954]
===
match
---
arglist [14030,14067]
arglist [14086,14123]
===
match
---
operator: = [11131,11132]
operator: = [11187,11188]
===
match
---
name: response [16012,16020]
name: response [16068,16076]
===
match
---
simple_stmt [8753,8788]
simple_stmt [8809,8844]
===
match
---
for_stmt [2963,3071]
for_stmt [3019,3127]
===
match
---
name: dumps [8934,8939]
name: dumps [8990,8995]
===
match
---
name: response [13970,13978]
name: response [14026,14034]
===
match
---
trailer [4137,4141]
trailer [4193,4197]
===
match
---
name: response [9895,9903]
name: response [9951,9959]
===
match
---
name: pools [15254,15259]
name: pools [15310,15315]
===
match
---
simple_stmt [3883,3918]
simple_stmt [3939,3974]
===
match
---
name: TOTAL_POOL_COUNT [16351,16367]
name: TOTAL_POOL_COUNT [16407,16423]
===
match
---
name: replace [13305,13312]
name: replace [13361,13368]
===
match
---
atom_expr [1984,1999]
atom_expr [1984,1999]
===
match
---
simple_stmt [1299,1342]
simple_stmt [1299,1342]
===
match
---
simple_stmt [3104,3124]
simple_stmt [3160,3180]
===
match
---
name: test_lineage_info [13143,13160]
name: test_lineage_info [13199,13216]
===
match
---
name: response [8100,8108]
name: response [8156,8164]
===
match
---
name: self [11791,11795]
name: self [11847,11851]
===
match
---
name: tests [1440,1445]
name: tests [1440,1445]
===
match
---
name: dag_id [14303,14309]
name: dag_id [14359,14365]
===
match
---
name: pool [17036,17040]
name: pool [17092,17096]
===
match
---
name: self [15870,15874]
name: self [15926,15930]
===
match
---
argument [12883,12905]
argument [12939,12961]
===
match
---
operator: = [2210,2211]
operator: = [2210,2211]
===
match
---
trailer [5066,5076]
trailer [5122,5132]
===
match
---
comparison [11586,11613]
comparison [11642,11669]
===
match
---
expr_stmt [14949,14987]
expr_stmt [15005,15043]
===
match
---
parameters [6925,6931]
parameters [6981,6987]
===
match
---
name: client [14504,14510]
name: client [14560,14566]
===
match
---
assert_stmt [8417,8489]
assert_stmt [8473,8545]
===
match
---
name: app [2183,2186]
name: app [2183,2186]
===
match
---
name: session [2821,2828]
name: session [2877,2884]
===
match
---
trailer [9908,9915]
trailer [9964,9971]
===
match
---
operator: = [2102,2103]
operator: = [2102,2103]
===
match
---
operator: = [7213,7214]
operator: = [7269,7270]
===
match
---
simple_stmt [17859,17957]
simple_stmt [17915,18013]
===
match
---
import_as_name [1231,1254]
import_as_name [1231,1254]
===
match
---
operator: = [7941,7942]
operator: = [7997,7998]
===
match
---
operator: = [10253,10254]
operator: = [10309,10310]
===
match
---
operator: = [1525,1526]
operator: = [1525,1526]
===
match
---
atom_expr [4632,4658]
atom_expr [4688,4714]
===
match
---
atom_expr [2444,2471]
atom_expr [2444,2471]
===
match
---
trailer [15393,15400]
trailer [15449,15456]
===
match
---
expr_stmt [11045,11077]
expr_stmt [11101,11133]
===
match
---
operator: , [5981,5982]
operator: , [6037,6038]
===
match
---
operator: + [15071,15072]
operator: + [15127,15128]
===
match
---
expr_stmt [9394,9471]
expr_stmt [9450,9527]
===
match
---
string: '' [17231,17233]
string: '' [17287,17289]
===
match
---
trailer [12849,12855]
trailer [12905,12911]
===
match
---
atom_expr [3954,4005]
atom_expr [4010,4061]
===
match
---
name: pool [16383,16387]
name: pool [16439,16443]
===
match
---
expr_stmt [18242,18325]
expr_stmt [18298,18381]
===
match
---
simple_stmt [1435,1512]
simple_stmt [1435,1512]
===
match
---
name: dag_id [7001,7007]
name: dag_id [7057,7063]
===
match
---
name: dag [7655,7658]
name: dag [7711,7714]
===
match
---
trailer [8567,8744]
trailer [8623,8800]
===
match
---
operator: = [3367,3368]
operator: = [3423,3424]
===
match
---
simple_stmt [9394,9472]
simple_stmt [9450,9528]
===
match
---
name: self [5558,5562]
name: self [5614,5618]
===
match
---
trailer [10171,10176]
trailer [10227,10232]
===
match
---
trailer [10870,10882]
trailer [10926,10938]
===
match
---
simple_stmt [10348,10383]
simple_stmt [10404,10439]
===
match
---
operator: } [15656,15657]
operator: } [15712,15713]
===
match
---
assert_stmt [4241,4275]
assert_stmt [4297,4331]
===
match
---
operator: = [11101,11102]
operator: = [11157,11158]
===
match
---
string: "init_api_experimental" [1849,1872]
string: "init_api_experimental" [1849,1872]
===
match
---
name: DagRun [2796,2802]
name: DagRun [2852,2858]
===
match
---
operator: , [1638,1639]
operator: , [1638,1639]
===
match
---
trailer [15285,15293]
trailer [15341,15349]
===
match
---
atom_expr [15096,15201]
atom_expr [15152,15257]
===
match
---
name: db [1410,1412]
name: db [1410,1412]
===
match
---
name: data [4042,4046]
name: data [4098,4102]
===
match
---
simple_stmt [3570,3622]
simple_stmt [3626,3678]
===
match
---
simple_stmt [1388,1435]
simple_stmt [1388,1435]
===
match
---
trailer [1950,1961]
trailer [1950,1961]
===
match
---
trailer [2331,2345]
trailer [2331,2345]
===
match
---
name: format [5393,5399]
name: format [5449,5455]
===
match
---
decorator [1694,1751]
decorator [1694,1751]
===
match
---
name: super [2725,2730]
name: super [2781,2786]
===
match
---
trailer [3139,3145]
trailer [3195,3201]
===
match
---
funcdef [2696,3071]
funcdef [2752,3127]
===
match
---
simple_stmt [18129,18188]
simple_stmt [18185,18244]
===
match
---
simple_stmt [5496,5531]
simple_stmt [5552,5587]
===
match
---
name: client [7220,7226]
name: client [7276,7282]
===
match
---
name: get [12089,12092]
name: get [12145,12148]
===
match
---
string: 'ok' [5092,5096]
string: 'ok' [5148,5152]
===
match
---
atom_expr [11172,11198]
atom_expr [11228,11254]
===
match
---
string: '/api/experimental/dags/{}/tasks/{}' [3585,3621]
string: '/api/experimental/dags/{}/tasks/{}' [3641,3677]
===
match
---
name: isoformat [11273,11282]
name: isoformat [11329,11338]
===
match
---
atom_expr [16953,16982]
atom_expr [17009,17038]
===
match
---
trailer [12320,12324]
trailer [12376,12380]
===
match
---
atom_expr [1607,1616]
atom_expr [1607,1616]
===
match
---
name: setUp [1907,1912]
name: setUp [1907,1912]
===
match
---
name: url_template [14010,14022]
name: url_template [14066,14078]
===
match
---
trailer [11806,11889]
trailer [11862,11945]
===
match
---
simple_stmt [3765,3815]
simple_stmt [3821,3871]
===
match
---
param [2711,2714]
param [2767,2770]
===
match
---
name: response [6102,6110]
name: response [6158,6166]
===
match
---
expr_stmt [13233,13270]
expr_stmt [13289,13326]
===
match
---
name: data [14640,14644]
name: data [14696,14700]
===
match
---
name: PAPERMILL_EXAMPLE_DAGS [12521,12543]
name: PAPERMILL_EXAMPLE_DAGS [12577,12599]
===
match
---
simple_stmt [16851,16884]
simple_stmt [16907,16940]
===
match
---
atom_expr [3723,3755]
atom_expr [3779,3811]
===
match
---
simple_stmt [929,958]
simple_stmt [929,958]
===
match
---
expr_stmt [11086,11134]
expr_stmt [11142,11190]
===
match
---
atom_expr [1549,1650]
atom_expr [1549,1650]
===
match
---
operator: = [2369,2370]
operator: = [2369,2370]
===
match
---
trailer [10634,10646]
trailer [10690,10702]
===
match
---
name: get [5570,5573]
name: get [5626,5629]
===
match
---
trailer [11979,11988]
trailer [12035,12044]
===
match
---
string: "providers" [12583,12594]
string: "providers" [12639,12650]
===
match
---
funcdef [5702,6891]
funcdef [5758,6947]
===
match
---
trailer [9855,9864]
trailer [9911,9920]
===
match
---
name: content_type [6806,6818]
name: content_type [6862,6874]
===
match
---
comparison [14620,14660]
comparison [14676,14716]
===
match
---
trailer [1585,1594]
trailer [1585,1594]
===
match
---
atom_expr [2891,2906]
atom_expr [2947,2962]
===
match
---
trailer [4421,4446]
trailer [4477,4502]
===
match
---
name: realpath [1586,1594]
name: realpath [1586,1594]
===
match
---
name: response [5458,5466]
name: response [5514,5522]
===
match
---
name: client [2283,2289]
name: client [2283,2289]
===
match
---
name: isoformat [13466,13475]
name: isoformat [13522,13531]
===
match
---
name: execution_date [8473,8487]
name: execution_date [8529,8543]
===
match
---
trailer [5120,5129]
trailer [5176,5185]
===
match
---
name: datetime_string [11862,11877]
name: datetime_string [11918,11933]
===
match
---
name: dag_id [9524,9530]
name: dag_id [9580,9586]
===
match
---
name: status_code [9797,9808]
name: status_code [9853,9864]
===
match
---
name: run_id [13539,13545]
name: run_id [13595,13601]
===
match
---
trailer [10538,10542]
trailer [10594,10598]
===
match
---
trailer [13985,13992]
trailer [14041,14048]
===
match
---
name: self [2226,2230]
name: self [2226,2230]
===
match
---
name: status_code [18656,18667]
name: status_code [18712,18723]
===
match
---
trailer [4975,5035]
trailer [5031,5091]
===
match
---
simple_stmt [14386,14434]
simple_stmt [14442,14490]
===
match
---
name: loads [18061,18066]
name: loads [18117,18122]
===
match
---
comparison [10619,10646]
comparison [10675,10702]
===
match
---
operator: = [8047,8048]
operator: = [8103,8104]
===
match
---
atom_expr [2866,2882]
atom_expr [2922,2938]
===
match
---
trailer [10124,10136]
trailer [10180,10192]
===
match
---
simple_stmt [15440,15475]
simple_stmt [15496,15531]
===
match
---
name: models [1039,1045]
name: models [1039,1045]
===
match
---
operator: = [12713,12714]
operator: = [12769,12770]
===
match
---
name: pardir [1610,1616]
name: pardir [1610,1616]
===
match
---
name: response [5067,5075]
name: response [5123,5131]
===
match
---
dictorsetmaker [8653,8686]
dictorsetmaker [8709,8742]
===
match
---
trailer [17631,17643]
trailer [17687,17699]
===
match
---
string: "application/json" [8048,8066]
string: "application/json" [8104,8122]
===
match
---
operator: = [9984,9985]
operator: = [10040,10041]
===
match
---
name: dag_id [10563,10569]
name: dag_id [10619,10625]
===
match
---
trailer [7079,7088]
trailer [7135,7144]
===
match
---
atom_expr [3265,3283]
atom_expr [3321,3339]
===
match
---
atom_expr [11232,11285]
atom_expr [11288,11341]
===
match
---
atom_expr [5858,6037]
atom_expr [5914,6093]
===
match
---
name: status_code [11602,11613]
name: status_code [11658,11669]
===
match
---
operator: , [10828,10829]
operator: , [10884,10885]
===
match
---
number: 1990 [13445,13449]
number: 1990 [13501,13505]
===
match
---
operator: { [8940,8941]
operator: { [8996,8997]
===
match
---
name: append [15260,15266]
name: append [15316,15322]
===
match
---
simple_stmt [13868,13920]
simple_stmt [13924,13976]
===
match
---
operator: = [2923,2924]
operator: = [2979,2980]
===
match
---
trailer [15966,15978]
trailer [16022,16034]
===
match
---
operator: = [8367,8368]
operator: = [8423,8424]
===
match
---
simple_stmt [7582,7600]
simple_stmt [7638,7656]
===
match
---
suite [3309,3531]
suite [3365,3587]
===
match
---
name: session [12772,12779]
name: session [12828,12835]
===
match
---
string: 'enable_experimental_api' [1714,1739]
string: 'enable_experimental_api' [1714,1739]
===
match
---
name: loads [18389,18394]
name: loads [18445,18450]
===
match
---
name: pools [14954,14959]
name: pools [15010,15015]
===
match
---
string: 'utf-8' [15526,15533]
string: 'utf-8' [15582,15589]
===
match
---
simple_stmt [4875,4940]
simple_stmt [4931,4996]
===
match
---
trailer [11282,11284]
trailer [11338,11340]
===
match
---
trailer [3230,3232]
trailer [3286,3288]
===
match
---
simple_stmt [5540,5586]
simple_stmt [5596,5642]
===
match
---
simple_stmt [6046,6079]
simple_stmt [6102,6135]
===
match
---
number: 400 [14577,14580]
number: 400 [14633,14636]
===
update-node
---
string: r'\<.+/stable-rest-api/migration.html\>; ' [2510,2552]
replace r'\<.+/stable-rest-api/migration.html\>; ' by r'\<.+/upgrading-to-2.html#migration-guide-from-experimental-api-to-stable-api-v1\>; '
