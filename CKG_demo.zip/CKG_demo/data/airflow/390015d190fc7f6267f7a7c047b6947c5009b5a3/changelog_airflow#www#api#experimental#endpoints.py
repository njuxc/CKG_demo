===
match
---
string: 'POST' [11995,12001]
string: 'POST' [12039,12045]
===
match
---
name: task_id [7902,7909]
name: task_id [7946,7953]
===
match
---
name: get_json [12094,12102]
name: get_json [12138,12146]
===
match
---
trailer [10560,10575]
trailer [10604,10619]
===
match
---
operator: = [12137,12138]
operator: = [12181,12182]
===
match
---
operator: { [5663,5664]
operator: { [5707,5708]
===
match
---
argument [7812,7827]
argument [7856,7871]
===
match
---
name: response [4861,4869]
name: response [4905,4913]
===
match
---
atom [10776,10801]
atom [10820,10845]
===
match
---
name: k [8958,8959]
name: k [9002,9003]
===
match
---
arglist [4447,4534]
arglist [4491,4578]
===
match
---
funcdef [6584,7042]
funcdef [6628,7086]
===
match
---
simple_stmt [9229,9492]
simple_stmt [9273,9536]
===
match
---
name: to_json [11537,11544]
name: to_json [11581,11588]
===
match
---
string: 'GET' [7165,7170]
string: 'GET' [7209,7214]
===
match
---
name: methods [7486,7493]
name: methods [7530,7537]
===
match
---
expr_stmt [8684,8744]
expr_stmt [8728,8788]
===
match
---
operator: = [7271,7272]
operator: = [7315,7316]
===
match
---
name: task_instance_info [7859,7877]
name: task_instance_info [7903,7921]
===
match
---
name: route [6103,6108]
name: route [6147,6152]
===
match
---
name: requires_authentication [6157,6180]
name: requires_authentication [6201,6224]
===
match
---
expr_stmt [12077,12114]
expr_stmt [12121,12158]
===
match
---
string: 'error' [8581,8588]
string: 'error' [8625,8632]
===
match
---
operator: } [2504,2505]
operator: } [2548,2549]
===
match
---
name: exceptions [1544,1554]
name: exceptions [1544,1554]
===
match
---
simple_stmt [4904,4943]
simple_stmt [4948,4987]
===
match
---
name: status_code [11851,11862]
name: status_code [11895,11906]
===
match
---
name: error [6381,6386]
name: error [6425,6430]
===
match
---
name: info [5618,5622]
name: info [5662,5666]
===
match
---
name: task_id [8720,8727]
name: task_id [8764,8771]
===
match
---
name: AirflowException [8756,8772]
name: AirflowException [8800,8816]
===
match
---
fstring [10134,10142]
fstring [10178,10186]
===
match
---
expr_stmt [13702,13740]
expr_stmt [13746,13784]
===
match
---
atom_expr [12557,12588]
atom_expr [12601,12632]
===
match
---
expr_stmt [10464,10498]
expr_stmt [10508,10542]
===
match
---
atom_expr [3338,3360]
atom_expr [3382,3404]
===
match
---
name: err [4251,4254]
name: err [4295,4298]
===
match
---
name: common [1406,1412]
name: common [1406,1412]
===
match
---
suite [12771,12811]
suite [12815,12855]
===
match
---
try_stmt [11672,11950]
try_stmt [11716,11994]
===
match
---
operator: } [9910,9911]
operator: } [9954,9955]
===
match
---
trailer [8486,8493]
trailer [8530,8537]
===
match
---
name: error_message [8538,8551]
name: error_message [8582,8595]
===
match
---
name: latest_dag_runs [10332,10347]
name: latest_dag_runs [10376,10391]
===
match
---
suite [3312,3891]
suite [3356,3935]
===
match
---
name: jsonify [5742,5749]
name: jsonify [5786,5793]
===
match
---
atom_expr [1746,1773]
atom_expr [1746,1773]
===
match
---
name: route [12412,12417]
name: route [12456,12461]
===
match
---
name: route [11568,11573]
name: route [11612,11617]
===
match
---
strings [8362,8486]
strings [8406,8530]
===
match
---
param [7546,7552]
param [7590,7596]
===
match
---
name: api [996,999]
name: api [996,999]
===
match
---
name: execution_date [10945,10959]
name: execution_date [10989,11003]
===
match
---
operator: = [4925,4926]
operator: = [4969,4970]
===
match
---
string: """     Returns a JSON with a task instance's public instance variables.     The format for the exec_date is expected to be     "YYYY-mm-DDTHH:MM:SS", for example: "2016-11-16T11:34:15". This will     of course need to have been encoded for URL in the request.     """ [7916,8184]
string: """     Returns a JSON with a task instance's public instance variables.     The format for the exec_date is expected to be     "YYYY-mm-DDTHH:MM:SS", for example: "2016-11-16T11:34:15". This will     of course need to have been encoded for URL in the request.     """ [7960,8228]
===
match
---
expr_stmt [13452,13478]
expr_stmt [13496,13522]
===
match
---
name: dag_id [13555,13561]
name: dag_id [13599,13605]
===
match
---
simple_stmt [3529,3729]
simple_stmt [3573,3773]
===
match
---
operator: , [10666,10667]
operator: , [10710,10711]
===
match
---
operator: } [10140,10141]
operator: } [10184,10185]
===
match
---
atom [11183,11190]
atom [11227,11234]
===
match
---
operator: { [8580,8581]
operator: { [8624,8625]
===
match
---
return_stmt [9032,9054]
return_stmt [9076,9098]
===
match
---
operator: = [13723,13724]
operator: = [13767,13768]
===
match
---
name: data [3131,3135]
name: data [3175,3179]
===
match
---
param [6598,6605]
param [6642,6649]
===
match
---
argument [9139,9154]
argument [9183,9198]
===
match
---
simple_stmt [4419,4541]
simple_stmt [4463,4585]
===
match
---
trailer [8993,8999]
trailer [9037,9043]
===
match
---
operator: = [3082,3083]
operator: = [3126,3127]
===
match
---
simple_stmt [11436,11475]
simple_stmt [11480,11519]
===
match
---
param [12503,12507]
param [12547,12551]
===
match
---
atom_expr [10930,10943]
atom_expr [10974,10987]
===
match
---
trailer [2384,2399]
trailer [2384,2399]
===
match
---
expr_stmt [2588,2639]
expr_stmt [2632,2683]
===
match
---
name: trigger [4076,4083]
name: trigger [4120,4127]
===
match
---
import_as_name [1067,1089]
import_as_name [1067,1089]
===
match
---
simple_stmt [6842,6881]
simple_stmt [6886,6925]
===
match
---
dotted_name [1237,1281]
dotted_name [1237,1281]
===
match
---
name: args [1987,1991]
name: args [1987,1991]
===
match
---
name: jsonify [13790,13797]
name: jsonify [13834,13841]
===
match
---
string: "T" [1787,1790]
string: "T" [1787,1790]
===
match
---
string: 'GET' [5803,5808]
string: 'GET' [5847,5852]
===
match
---
string: 'dag_run_url' [10858,10871]
string: 'dag_run_url' [10902,10915]
===
match
---
name: get_code [6279,6287]
name: get_code [6323,6331]
===
match
---
suite [10576,11037]
suite [10620,11081]
===
match
---
operator: = [11591,11592]
operator: = [11635,11636]
===
match
---
name: err [6764,6767]
name: err [6808,6811]
===
match
---
name: to_boolean [4012,4022]
name: to_boolean [4056,4066]
===
match
---
operator: , [5095,5096]
operator: , [5139,5140]
===
match
---
atom_expr [6707,6732]
atom_expr [6751,6776]
===
match
---
import_as_names [849,872]
import_as_names [849,872]
===
match
---
suite [13774,13807]
suite [13818,13851]
===
match
---
name: test [5840,5844]
name: test [5884,5888]
===
match
---
string: """Returns a JSON with a task's public instance variables""" [6620,6680]
string: """Returns a JSON with a task's public instance variables""" [6664,6724]
===
match
---
trailer [13710,13722]
trailer [13754,13766]
===
match
---
name: airflow [1663,1670]
name: airflow [1663,1670]
===
match
---
return_stmt [11483,11498]
return_stmt [11527,11542]
===
match
---
try_stmt [9978,10215]
try_stmt [10022,10259]
===
match
---
name: pool [11290,11294]
name: pool [11334,11338]
===
match
---
import_from [956,982]
import_from [956,982]
===
match
---
operator: } [4468,4469]
operator: } [4512,4513]
===
match
---
name: ValueError [8312,8322]
name: ValueError [8356,8366]
===
match
---
suite [12123,12170]
suite [12167,12214]
===
match
---
decorator [12004,12029]
decorator [12048,12073]
===
match
---
operator: { [7674,7675]
operator: { [7718,7719]
===
match
---
simple_stmt [9921,9948]
simple_stmt [9965,9992]
===
match
---
parameters [10347,10349]
parameters [10391,10393]
===
match
---
strings [9669,9793]
strings [9713,9837]
===
match
---
name: jsonify [10227,10234]
name: jsonify [10271,10278]
===
match
---
name: error [11412,11417]
name: error [11456,11461]
===
match
---
operator: , [10284,10285]
operator: , [10328,10329]
===
match
---
name: response [12280,12288]
name: response [12324,12332]
===
match
---
operator: = [6386,6387]
operator: = [6430,6431]
===
match
---
argument [8830,8844]
argument [8874,8888]
===
match
---
operator: @ [6559,6560]
operator: @ [6603,6604]
===
match
---
simple_stmt [13399,13444]
simple_stmt [13443,13488]
===
match
---
name: execution_date [9801,9815]
name: execution_date [9845,9859]
===
match
---
name: requires_authentication [4633,4656]
name: requires_authentication [4677,4700]
===
match
---
expr_stmt [3835,3861]
expr_stmt [3879,3905]
===
match
---
trailer [4985,5036]
trailer [5029,5080]
===
match
---
name: status_code [10179,10190]
name: status_code [10223,10234]
===
match
---
name: dag_id [7636,7642]
name: dag_id [7680,7686]
===
match
---
name: paused [7221,7227]
name: paused [7265,7271]
===
match
---
name: error [4880,4885]
name: error [4924,4929]
===
match
---
arglist [5063,5112]
arglist [5107,5156]
===
match
---
name: common [1169,1175]
name: common [1169,1175]
===
match
---
name: is_paused [7261,7270]
name: is_paused [7305,7314]
===
match
---
operator: , [10836,10837]
operator: , [10880,10881]
===
match
---
argument [1792,1806]
argument [1792,1806]
===
match
---
name: error [4842,4847]
name: error [4886,4891]
===
match
---
decorated [12813,13807]
decorated [12857,13851]
===
match
---
return_stmt [13783,13806]
return_stmt [13827,13850]
===
match
---
trailer [10712,10727]
trailer [10756,10771]
===
match
---
operator: } [7697,7698]
operator: } [7741,7742]
===
match
---
parameters [12044,12046]
parameters [12088,12090]
===
match
---
operator: @ [12462,12463]
operator: @ [12506,12507]
===
match
---
string: 'true' [7288,7294]
string: 'true' [7332,7338]
===
match
---
trailer [12288,12300]
trailer [12332,12344]
===
match
---
trailer [3135,3145]
trailer [3179,3189]
===
match
---
operator: @ [5039,5040]
operator: @ [5083,5084]
===
match
---
name: decorated [2111,2120]
name: decorated [2111,2120]
===
match
---
import_from [1703,1738]
import_from [1703,1738]
===
match
---
trailer [12375,12391]
trailer [12419,12435]
===
match
---
trailer [4379,4413]
trailer [4423,4457]
===
match
---
atom_expr [2658,2682]
atom_expr [2702,2726]
===
match
---
name: response [4552,4560]
name: response [4596,4604]
===
match
---
dotted_name [6471,6493]
dotted_name [6515,6537]
===
match
---
atom_expr [7026,7041]
atom_expr [7070,7085]
===
match
---
operator: , [2844,2845]
operator: , [2888,2889]
===
match
---
strings [13200,13324]
strings [13244,13368]
===
match
---
trailer [11930,11932]
trailer [11974,11976]
===
match
---
param [7213,7220]
param [7257,7264]
===
match
---
name: airflow [1307,1314]
name: airflow [1307,1314]
===
match
---
trailer [7277,7295]
trailer [7321,7339]
===
match
---
name: execution_date [9560,9574]
name: execution_date [9604,9618]
===
match
---
name: get_dag_runs [1269,1281]
name: get_dag_runs [1269,1281]
===
match
---
atom_expr [13410,13443]
atom_expr [13454,13487]
===
match
---
atom_expr [10554,10575]
atom_expr [10598,10619]
===
match
---
atom_expr [2730,2785]
atom_expr [2774,2829]
===
match
---
operator: = [12720,12721]
operator: = [12764,12765]
===
match
---
string: 'error' [9888,9895]
string: 'error' [9932,9939]
===
match
---
decorated [5039,5759]
decorated [5083,5803]
===
match
---
simple_stmt [7559,7591]
simple_stmt [7603,7635]
===
match
---
fstring_string: < [2495,2496]
fstring_string: < [2539,2540]
===
match
---
name: delete_dag [4775,4785]
name: delete_dag [4819,4829]
===
match
---
name: message [4447,4454]
name: message [4491,4498]
===
match
---
operator: , [4346,4347]
operator: , [4390,4391]
===
match
---
trailer [9800,9816]
trailer [9844,9860]
===
match
---
simple_stmt [9868,9913]
simple_stmt [9912,9957]
===
match
---
suite [3113,3146]
suite [3157,3190]
===
match
---
except_clause [4798,4828]
except_clause [4842,4872]
===
match
---
operator: , [6722,6723]
operator: , [6766,6767]
===
match
---
arglist [4587,4630]
arglist [4631,4674]
===
match
---
expr_stmt [3778,3822]
expr_stmt [3822,3866]
===
match
---
name: execution_date [4118,4132]
name: execution_date [4162,4176]
===
match
---
fstring [4886,4894]
fstring [4930,4938]
===
match
---
name: data [4023,4027]
name: data [4067,4071]
===
match
---
fstring_start: f" [8836,8838]
fstring_start: f" [8880,8882]
===
match
---
expr_stmt [4861,4895]
expr_stmt [4905,4939]
===
match
---
trailer [10480,10496]
trailer [10524,10540]
===
match
---
operator: = [5700,5701]
operator: = [5744,5745]
===
match
---
name: fields [7034,7040]
name: fields [7078,7084]
===
match
---
suite [11281,11326]
suite [11325,11370]
===
match
---
simple_stmt [6051,6083]
simple_stmt [6095,6127]
===
match
---
param [6606,6613]
param [6650,6657]
===
match
---
name: response [4419,4427]
name: response [4463,4471]
===
match
---
arglist [4380,4412]
arglist [4424,4456]
===
match
---
trailer [11850,11862]
trailer [11894,11906]
===
match
---
operator: , [8727,8728]
operator: , [8771,8772]
===
match
---
name: k [9009,9010]
name: k [9053,9054]
===
match
---
operator: = [2491,2492]
operator: = [2535,2536]
===
match
---
name: params [12162,12168]
name: params [12206,12212]
===
match
---
simple_stmt [956,983]
simple_stmt [956,983]
===
match
---
argument [4880,4894]
argument [4924,4938]
===
match
---
decorators [5039,5139]
decorators [5083,5183]
===
match
---
operator: = [3063,3064]
operator: = [3107,3108]
===
match
---
name: airflow [1584,1591]
name: airflow [1584,1591]
===
match
---
string: """Get pool by a given name.""" [11241,11272]
string: """Get pool by a given name.""" [11285,11316]
===
match
---
name: status_code [11463,11474]
name: status_code [11507,11518]
===
match
---
simple_stmt [2124,2183]
simple_stmt [2124,2183]
===
match
---
name: api_experimental [2730,2746]
name: api_experimental [2774,2790]
===
match
---
fstring_expr [2687,2705]
fstring_expr [2731,2749]
===
match
---
simple_stmt [9991,10043]
simple_stmt [10035,10087]
===
match
---
name: AirflowException [1562,1578]
name: AirflowException [1562,1578]
===
match
---
argument [5963,5978]
argument [6007,6022]
===
match
---
atom [11920,11948]
atom [11964,11992]
===
match
---
expr_stmt [3219,3240]
expr_stmt [3263,3284]
===
match
---
atom_expr [5679,5699]
atom_expr [5723,5743]
===
match
---
name: get_lineage [12935,12946]
name: get_lineage [12979,12990]
===
match
---
name: route [11970,11975]
name: route [12014,12019]
===
match
---
name: replace_microseconds [4134,4154]
name: replace_microseconds [4178,4198]
===
match
---
suite [4062,4156]
suite [4106,4200]
===
match
---
name: functools [807,816]
name: functools [807,816]
===
match
---
param [1870,1881]
param [1870,1881]
===
match
---
name: log [5614,5617]
name: log [5658,5661]
===
match
---
expr_stmt [10503,10515]
expr_stmt [10547,10559]
===
match
---
simple_stmt [4861,4896]
simple_stmt [4905,4940]
===
match
---
suite [4362,4414]
suite [4406,4458]
===
match
---
name: g [4402,4403]
name: g [4446,4447]
===
match
---
simple_stmt [11041,11125]
simple_stmt [11085,11169]
===
match
---
fstring_expr [8838,8843]
fstring_expr [8882,8887]
===
match
---
expr_stmt [1775,1807]
expr_stmt [1775,1807]
===
match
---
name: jsonify [7026,7033]
name: jsonify [7070,7077]
===
match
---
decorated [1951,2091]
decorated [1951,2091]
===
match
---
name: response [6405,6413]
name: response [6449,6457]
===
match
---
decorated [2788,4561]
decorated [2832,4605]
===
match
---
operator: @ [9156,9157]
operator: @ [9200,9201]
===
match
---
name: t_info [6698,6704]
name: t_info [6742,6748]
===
match
---
string: '/pools' [11574,11582]
string: '/pools' [11618,11626]
===
match
---
atom_expr [6865,6880]
atom_expr [6909,6924]
===
match
---
suite [5605,5730]
suite [5649,5774]
===
match
---
operator: , [4470,4471]
operator: , [4514,4515]
===
match
---
fstring_end: " [11425,11426]
fstring_end: " [11469,11470]
===
match
---
name: err [6428,6431]
name: err [6472,6475]
===
match
---
parameters [1985,2002]
parameters [1985,2002]
===
match
---
name: jsonify [4978,4985]
name: jsonify [5022,5029]
===
match
---
atom_expr [4023,4051]
atom_expr [4067,4095]
===
match
---
operator: , [5022,5023]
operator: , [5066,5067]
===
match
---
name: jsonify [9879,9886]
name: jsonify [9923,9930]
===
match
---
atom_expr [4266,4286]
atom_expr [4310,4330]
===
match
---
expr_stmt [5532,5569]
expr_stmt [5576,5613]
===
match
---
name: methods [5963,5970]
name: methods [6007,6014]
===
match
---
operator: } [11021,11022]
operator: } [11065,11066]
===
match
---
atom_expr [11847,11862]
atom_expr [11891,11906]
===
match
---
trailer [6431,6443]
trailer [6475,6487]
===
match
---
name: fields [9047,9053]
name: fields [9091,9097]
===
match
---
suite [11676,11714]
suite [11720,11758]
===
match
---
name: utils [1592,1597]
name: utils [1592,1597]
===
match
---
name: url_for [10873,10880]
name: url_for [10917,10924]
===
match
---
name: api_experimental [9058,9074]
name: api_experimental [9102,9118]
===
match
---
name: response [11824,11832]
name: response [11868,11876]
===
match
---
simple_stmt [12280,12319]
simple_stmt [12324,12363]
===
match
---
atom_expr [3201,3213]
atom_expr [3245,3257]
===
match
---
name: requires_authentication [7174,7197]
name: requires_authentication [7218,7241]
===
match
---
name: args [5506,5510]
name: args [5550,5554]
===
match
---
fstring_end: " [6831,6832]
fstring_end: " [6875,6876]
===
match
---
name: log [13636,13639]
name: log [13680,13683]
===
match
---
string: 'GET' [5106,5111]
string: 'GET' [5150,5155]
===
match
---
atom_expr [8694,8744]
atom_expr [8738,8788]
===
match
---
trailer [5514,5523]
trailer [5558,5567]
===
match
---
name: request [938,945]
name: request [938,945]
===
match
---
name: Callable [849,857]
name: Callable [849,857]
===
match
---
file_input [787,13807]
file_input [787,13851]
===
match
---
name: requires_authentication [1846,1869]
name: requires_authentication [1846,1869]
===
match
---
name: get_pools [11702,11711]
name: get_pools [11746,11755]
===
match
---
string: 'Given execution date, {}, could not be identified ' [9669,9721]
string: 'Given execution date, {}, could not be identified ' [9713,9765]
===
match
---
operator: { [10621,10622]
operator: { [10665,10666]
===
match
---
name: get_lineage_api [13532,13547]
name: get_lineage_api [13576,13591]
===
match
---
atom_expr [13790,13806]
atom_expr [13834,13850]
===
match
---
param [7878,7885]
param [7922,7929]
===
match
---
name: DagRun [10474,10480]
name: DagRun [10518,10524]
===
match
---
dotted_name [7431,7453]
dotted_name [7475,7497]
===
match
---
return_stmt [7659,7699]
return_stmt [7703,7743]
===
match
---
fstring_expr [5004,5011]
fstring_expr [5048,5055]
===
match
---
expr_stmt [3529,3728]
expr_stmt [3573,3772]
===
match
---
name: is_paused [7371,7380]
name: is_paused [7415,7424]
===
match
---
name: pool_api [1057,1065]
name: pool_api [1057,1065]
===
match
---
operator: ** [12160,12162]
operator: ** [12204,12206]
===
match
---
dictorsetmaker [8581,8603]
dictorsetmaker [8625,8647]
===
match
---
name: err [4825,4828]
name: err [4869,4872]
===
match
---
name: task_id [6724,6731]
name: task_id [6768,6775]
===
match
---
name: get_json [3049,3057]
name: get_json [3093,3101]
===
match
---
name: response [13756,13764]
name: response [13800,13808]
===
match
---
suite [11749,11887]
suite [11793,11931]
===
match
---
name: name [11230,11234]
name: name [11274,11278]
===
match
---
except_clause [11718,11748]
except_clause [11762,11792]
===
match
---
name: execution_date [7886,7900]
name: execution_date [7930,7944]
===
match
---
decorator [7702,7830]
decorator [7746,7874]
===
match
---
name: parse [3468,3473]
name: parse [3512,3517]
===
match
---
string: 'as a date. Example date format: 2015-11-16T14:34:15+00:00' [9734,9793]
string: 'as a date. Example date format: 2015-11-16T14:34:15+00:00' [9778,9837]
===
match
---
simple_stmt [12746,12762]
simple_stmt [12790,12806]
===
match
---
simple_stmt [4545,4561]
simple_stmt [4589,4605]
===
match
---
operator: , [901,902]
operator: , [901,902]
===
match
---
name: dag_id [10019,10025]
name: dag_id [10063,10069]
===
match
---
name: experimental [1256,1268]
name: experimental [1256,1268]
===
match
---
name: get_task_instance [8694,8711]
name: get_task_instance [8738,8755]
===
match
---
operator: , [1790,1791]
operator: , [1790,1791]
===
match
---
name: err [11421,11424]
name: err [11465,11468]
===
match
---
suite [6263,6296]
suite [6307,6340]
===
match
---
expr_stmt [8948,9027]
expr_stmt [8992,9071]
===
match
---
decorator [5114,5139]
decorator [5158,5183]
===
match
---
name: get_code [1143,1151]
name: get_code [1143,1151]
===
match
---
name: AirflowException [6744,6760]
name: AirflowException [6788,6804]
===
match
---
name: error [12675,12680]
name: error [12719,12724]
===
match
---
operator: { [12683,12684]
operator: { [12727,12728]
===
match
---
expr_stmt [8332,8519]
expr_stmt [8376,8563]
===
match
---
name: replace_microseconds [3989,4009]
name: replace_microseconds [4033,4053]
===
match
---
funcdef [11626,11950]
funcdef [11670,11994]
===
match
---
trailer [8711,8744]
trailer [8755,8788]
===
match
---
string: 'GET' [10295,10300]
string: 'GET' [10339,10344]
===
match
---
atom_expr [7607,7653]
atom_expr [7651,7697]
===
match
---
name: create_pool [12033,12044]
name: create_pool [12077,12088]
===
match
---
trailer [6986,6988]
trailer [7030,7032]
===
match
---
simple_stmt [11758,11773]
simple_stmt [11802,11817]
===
match
---
operator: = [7370,7371]
operator: = [7414,7415]
===
match
---
string: '/lineage/<string:dag_id>/<string:execution_date>' [12837,12887]
string: '/lineage/<string:dag_id>/<string:execution_date>' [12881,12931]
===
match
---
atom_expr [4200,4214]
atom_expr [4244,4258]
===
match
---
name: requires_authentication [5981,6004]
name: requires_authentication [6025,6048]
===
match
---
name: experimental [1413,1425]
name: experimental [1413,1425]
===
match
---
name: execution_date [4472,4486]
name: execution_date [4516,4530]
===
match
---
decorators [10246,10328]
decorators [10290,10372]
===
match
---
operator: @ [1951,1952]
operator: @ [1951,1952]
===
match
---
dotted_name [1619,1637]
dotted_name [1619,1637]
===
match
---
return_stmt [3875,3890]
return_stmt [3919,3934]
===
match
---
fstring_end: " [4469,4470]
fstring_end: " [4513,4514]
===
match
---
name: get_lineage [1339,1350]
name: get_lineage [1339,1350]
===
match
---
atom_expr [6279,6295]
atom_expr [6323,6339]
===
match
---
name: log [8528,8531]
name: log [8572,8575]
===
match
---
name: items [6981,6986]
name: items [7025,7030]
===
match
---
name: is_paused [7361,7370]
name: is_paused [7405,7414]
===
match
---
atom_expr [6996,7013]
atom_expr [7040,7057]
===
match
---
name: info [6344,6348]
name: info [6388,6392]
===
match
---
operator: = [4870,4871]
operator: = [4914,4915]
===
match
---
operator: @ [5114,5115]
operator: @ [5158,5159]
===
match
---
suite [2579,2640]
suite [2623,2684]
===
match
---
dotted_name [1157,1206]
dotted_name [1157,1206]
===
match
---
name: route [7720,7725]
name: route [7764,7769]
===
match
---
trailer [8622,8634]
trailer [8666,8678]
===
match
---
name: response [3882,3890]
name: response [3926,3934]
===
match
---
name: pool [1049,1053]
name: pool [1049,1053]
===
match
---
operator: * [2074,2075]
operator: * [2074,2075]
===
match
---
testlist_comp [11921,11947]
testlist_comp [11965,11991]
===
match
---
trailer [5554,5569]
trailer [5598,5613]
===
match
---
name: dag_id [4786,4792]
name: dag_id [4830,4836]
===
match
---
name: timezone [1605,1613]
name: timezone [1605,1613]
===
match
---
suite [4829,4967]
suite [4873,5011]
===
match
---
name: api_experimental [11551,11567]
name: api_experimental [11595,11611]
===
match
---
trailer [12707,12719]
trailer [12751,12763]
===
match
---
funcdef [10328,11125]
funcdef [10372,11169]
===
match
---
return_stmt [12746,12761]
return_stmt [12790,12805]
===
match
---
funcdef [1972,2091]
funcdef [1972,2091]
===
match
---
name: AirflowException [12600,12616]
name: AirflowException [12644,12660]
===
match
---
decorator [11601,11626]
decorator [11645,11670]
===
match
---
operator: } [12268,12269]
operator: } [12312,12313]
===
match
---
atom_expr [12699,12719]
atom_expr [12743,12763]
===
match
---
atom_expr [13200,13347]
atom_expr [13244,13391]
===
match
---
simple_stmt [9835,9860]
simple_stmt [9879,9904]
===
match
---
name: route [9075,9080]
name: route [9119,9124]
===
match
---
operator: = [6705,6706]
operator: = [6749,6750]
===
match
---
name: methods [6542,6549]
name: methods [6586,6593]
===
match
---
trailer [11379,11384]
trailer [11423,11428]
===
match
---
name: to_json [11923,11930]
name: to_json [11967,11974]
===
match
---
name: ValueError [13150,13160]
name: ValueError [13194,13204]
===
match
---
fstring_start: f" [13684,13686]
fstring_start: f" [13728,13730]
===
match
---
name: error [6818,6823]
name: error [6862,6867]
===
match
---
arglist [5555,5568]
arglist [5599,5612]
===
match
---
name: response [6459,6467]
name: response [6503,6511]
===
match
---
suite [12509,12811]
suite [12553,12855]
===
match
---
string: 'Link' [2675,2681]
string: 'Link' [2719,2725]
===
match
---
name: params [12077,12083]
name: params [12121,12127]
===
match
---
simple_stmt [3321,3361]
simple_stmt [3365,3405]
===
match
---
operator: @ [7702,7703]
operator: @ [7746,7747]
===
match
---
name: dag_id [7878,7884]
name: dag_id [7922,7928]
===
match
---
name: jsonify [7666,7673]
name: jsonify [7710,7717]
===
match
---
operator: , [13561,13562]
operator: , [13605,13606]
===
match
---
name: utils [1671,1676]
name: utils [1671,1676]
===
match
---
atom [11994,12002]
atom [12038,12046]
===
match
---
dotted_name [1536,1554]
dotted_name [1536,1554]
===
match
---
parameters [6197,6205]
parameters [6241,6249]
===
match
---
trailer [11314,11325]
trailer [11358,11369]
===
match
---
trailer [3473,3489]
trailer [3517,3533]
===
match
---
atom_expr [9835,9859]
atom_expr [9879,9903]
===
match
---
name: error [8532,8537]
name: error [8576,8581]
===
match
---
name: count [5024,5029]
name: count [5068,5073]
===
match
---
argument [7361,7380]
argument [7405,7424]
===
match
---
operator: @ [2788,2789]
operator: @ [2832,2833]
===
match
---
suite [9630,9973]
suite [9674,10017]
===
match
---
operator: , [12887,12888]
operator: , [12931,12932]
===
match
---
argument [12675,12689]
argument [12719,12733]
===
match
---
name: err [4927,4930]
name: err [4971,4974]
===
match
---
param [12947,12959]
param [12991,13003]
===
match
---
param [7221,7227]
param [7265,7271]
===
match
---
trailer [7307,7316]
trailer [7351,7360]
===
match
---
expr_stmt [4419,4540]
expr_stmt [4463,4584]
===
match
---
expr_stmt [5636,5670]
expr_stmt [5680,5714]
===
match
---
decorator [7830,7855]
decorator [7874,7899]
===
match
---
name: conf [4112,4116]
name: conf [4156,4160]
===
match
---
string: 'user' [4348,4354]
string: 'user' [4392,4398]
===
match
---
name: dag_id [12947,12953]
name: dag_id [12991,12997]
===
match
---
arglist [5954,5978]
arglist [5998,6022]
===
match
---
operator: = [6863,6864]
operator: = [6907,6908]
===
match
---
name: response [12334,12342]
name: response [12378,12386]
===
match
---
name: requires_authentication [5115,5138]
name: requires_authentication [5159,5182]
===
match
---
operator: , [2171,2172]
operator: , [2171,2172]
===
match
---
suite [1883,2122]
suite [1883,2122]
===
match
---
string: 'GET' [7495,7500]
string: 'GET' [7539,7544]
===
match
---
name: err [13623,13626]
name: err [13667,13670]
===
match
---
simple_stmt [11824,11863]
simple_stmt [11868,11907]
===
match
---
name: info [6009,6013]
name: info [6053,6057]
===
match
---
fstring_end: ' [2638,2639]
fstring_end: ' [2682,2683]
===
match
---
name: log [11758,11761]
name: log [11802,11805]
===
match
---
name: dag_id [10937,10943]
name: dag_id [10981,10987]
===
match
---
name: execution_date [9592,9606]
name: execution_date [9636,9650]
===
match
---
dotted_name [7703,7725]
dotted_name [7747,7769]
===
match
---
trailer [5617,5622]
trailer [5661,5666]
===
match
---
operator: , [4610,4611]
operator: , [4654,4655]
===
match
---
trailer [4912,4924]
trailer [4956,4968]
===
match
---
trailer [2107,2121]
trailer [2107,2121]
===
match
---
name: airflow [1708,1715]
name: airflow [1708,1715]
===
match
---
decorator [5980,6005]
decorator [6024,6049]
===
match
---
atom_expr [3789,3822]
atom_expr [3833,3866]
===
match
---
name: headers [2667,2674]
name: headers [2711,2718]
===
match
---
return_stmt [10220,10243]
return_stmt [10264,10287]
===
match
---
atom_expr [10227,10243]
atom_expr [10271,10287]
===
match
---
name: cast [2103,2107]
name: cast [2103,2107]
===
match
---
name: dag_id [7330,7336]
name: dag_id [7374,7380]
===
match
---
atom_expr [12248,12271]
atom_expr [12292,12315]
===
match
---
name: docs [1633,1637]
name: docs [1633,1637]
===
match
---
return_stmt [4951,4966]
return_stmt [4995,5010]
===
match
---
atom_expr [4371,4413]
atom_expr [4415,4457]
===
match
---
fstring [5661,5669]
fstring [5705,5713]
===
match
---
name: error_message [9639,9652]
name: error_message [9683,9696]
===
match
---
import_from [1658,1702]
import_from [1658,1702]
===
match
---
name: str [12955,12958]
name: str [12999,13002]
===
match
---
argument [4242,4256]
argument [4286,4300]
===
match
---
expr_stmt [12132,12169]
expr_stmt [12176,12213]
===
match
---
operator: += [2613,2615]
operator: += [2657,2659]
===
match
---
name: parse [9586,9591]
name: parse [9630,9635]
===
match
---
name: ValueError [3505,3515]
name: ValueError [3549,3559]
===
match
---
simple_stmt [8811,8846]
simple_stmt [8855,8890]
===
match
---
string: '/pools/<string:name>' [11151,11173]
string: '/pools/<string:name>' [11195,11217]
===
match
---
operator: , [4110,4111]
operator: , [4154,4155]
===
match
---
operator: = [12084,12085]
operator: = [12128,12129]
===
match
---
suite [8244,8301]
suite [8288,8345]
===
match
---
name: TypeVar [859,866]
name: TypeVar [859,866]
===
match
---
fstring [6387,6395]
fstring [6431,6439]
===
match
---
name: get_dagmodel [7317,7329]
name: get_dagmodel [7361,7373]
===
match
---
operator: @ [11601,11602]
operator: @ [11645,11646]
===
match
---
name: response [11490,11498]
name: response [11534,11542]
===
match
---
comparison [3919,3941]
comparison [3963,3985]
===
match
---
except_clause [11330,11360]
except_clause [11374,11404]
===
match
---
simple_stmt [2012,2091]
simple_stmt [2012,2091]
===
match
---
simple_stmt [7261,7296]
simple_stmt [7305,7340]
===
match
---
name: dag_id [10660,10666]
name: dag_id [10704,10710]
===
match
---
name: response [8908,8916]
name: response [8952,8960]
===
match
---
operator: } [2704,2705]
operator: } [2748,2749]
===
match
---
decorator [7084,7173]
decorator [7128,7217]
===
match
---
name: parse [13117,13122]
name: parse [13161,13166]
===
match
---
trailer [7407,7427]
trailer [7451,7471]
===
match
---
name: execution_date [4490,4504]
name: execution_date [4534,4548]
===
match
---
name: decorated [1976,1985]
name: decorated [1976,1985]
===
match
---
trailer [4022,4052]
trailer [4066,4096]
===
match
---
name: execution_date [3474,3488]
name: execution_date [3518,3532]
===
match
---
sync_comp_for [6956,7013]
sync_comp_for [7000,7057]
===
match
---
trailer [10833,10835]
trailer [10877,10879]
===
match
---
funcdef [6005,6083]
funcdef [6049,6127]
===
match
---
trailer [11832,11844]
trailer [11876,11888]
===
match
---
name: AirflowException [11725,11741]
name: AirflowException [11769,11785]
===
match
---
dotted_name [1307,1350]
dotted_name [1307,1350]
===
match
---
fstring_start: f" [4886,4888]
fstring_start: f" [4930,4932]
===
match
---
name: status_code [12307,12318]
name: status_code [12351,12362]
===
match
---
name: items [11056,11061]
name: items [11100,11105]
===
match
---
name: status_code [12708,12719]
name: status_code [12752,12763]
===
match
---
simple_stmt [10503,10516]
simple_stmt [10547,10560]
===
match
---
name: api_experimental [5762,5778]
name: api_experimental [5806,5822]
===
match
---
name: status_code [6869,6880]
name: status_code [6913,6924]
===
match
---
operator: * [1986,1987]
operator: * [1986,1987]
===
match
---
simple_stmt [3034,3070]
simple_stmt [3078,3114]
===
match
---
name: dag_id [2905,2911]
name: dag_id [2949,2955]
===
match
---
trailer [2435,2469]
trailer [2435,2513]
===
match
---
operator: = [5970,5971]
operator: = [6014,6015]
===
match
---
string: 'state' [5515,5522]
string: 'state' [5559,5566]
===
match
---
param [7902,7909]
param [7946,7953]
===
match
---
operator: = [4619,4620]
operator: = [4663,4664]
===
match
---
name: methods [12442,12449]
name: methods [12486,12493]
===
match
---
trailer [2674,2682]
trailer [2718,2726]
===
match
---
name: error_message [13428,13441]
name: error_message [13472,13485]
===
match
---
argument [11175,11190]
argument [11219,11234]
===
match
---
string: 'Link' [2605,2611]
string: 'Link' [2649,2655]
===
match
---
name: pools [11685,11690]
name: pools [11729,11734]
===
match
---
name: err [12722,12725]
name: err [12766,12769]
===
match
---
operator: @ [7430,7431]
operator: @ [7474,7475]
===
match
---
name: dagrun [10960,10966]
name: dagrun [11004,11010]
===
match
---
fstring_end: " [10141,10142]
fstring_end: " [10185,10186]
===
match
---
operator: = [8635,8636]
operator: = [8679,8680]
===
match
---
suite [12352,12392]
suite [12396,12436]
===
match
---
operator: , [4132,4133]
operator: , [4176,4177]
===
match
---
operator: { [4250,4251]
operator: { [4294,4295]
===
match
---
arglist [11976,12002]
arglist [12020,12046]
===
match
---
operator: = [6073,6074]
operator: = [6117,6118]
===
match
---
simple_stmt [787,802]
simple_stmt [787,802]
===
match
---
simple_stmt [802,830]
simple_stmt [802,830]
===
match
---
name: timezone [3459,3467]
name: timezone [3503,3511]
===
match
---
dictorsetmaker [7675,7697]
dictorsetmaker [7719,7741]
===
match
---
name: response [10152,10160]
name: response [10196,10204]
===
match
---
operator: = [13530,13531]
operator: = [13574,13575]
===
match
---
trailer [4292,4304]
trailer [4336,4348]
===
match
---
return_stmt [9957,9972]
return_stmt [10001,10016]
===
match
---
fstring [2685,2706]
fstring [2729,2750]
===
match
---
string: '/pools/<string:name>' [12418,12440]
string: '/pools/<string:name>' [12462,12484]
===
match
---
trailer [12674,12690]
trailer [12718,12734]
===
match
---
expr_stmt [4071,4155]
expr_stmt [4115,4199]
===
match
---
name: isoformat [10728,10737]
name: isoformat [10772,10781]
===
match
---
name: dag_id [6716,6722]
name: dag_id [6760,6766]
===
match
---
string: '/dags/<string:dag_id>/dag_runs/<string:execution_date>' [9081,9137]
string: '/dags/<string:dag_id>/dag_runs/<string:execution_date>' [9125,9181]
===
match
---
simple_stmt [6620,6681]
simple_stmt [6664,6725]
===
match
---
operator: = [2853,2854]
operator: = [2897,2898]
===
match
---
operator: = [3039,3040]
operator: = [3083,3084]
===
match
---
name: dag_id [4096,4102]
name: dag_id [4140,4146]
===
match
---
trailer [8284,8300]
trailer [8328,8344]
===
match
---
atom_expr [4978,5036]
atom_expr [5022,5080]
===
match
---
simple_stmt [1703,1739]
simple_stmt [1703,1739]
===
match
---
atom_expr [11693,11713]
atom_expr [11737,11757]
===
match
---
simple_stmt [1740,1774]
simple_stmt [1740,1774]
===
match
---
simple_stmt [12237,12272]
simple_stmt [12281,12316]
===
match
---
except_clause [9612,9629]
except_clause [9656,9673]
===
match
---
name: methods [6139,6146]
name: methods [6183,6190]
===
match
---
name: jsonify [12368,12375]
name: jsonify [12412,12419]
===
match
---
strings [3563,3691]
strings [3607,3735]
===
match
---
name: log [4200,4203]
name: log [4244,4247]
===
match
---
arglist [5785,5809]
arglist [5829,5853]
===
match
---
simple_stmt [3151,3163]
simple_stmt [3195,3207]
===
match
---
name: dagrun [10930,10936]
name: dagrun [10974,10980]
===
match
---
simple_stmt [6272,6296]
simple_stmt [6316,6340]
===
match
---
name: name [11315,11319]
name: name [11359,11363]
===
match
---
fstring_end: " [11813,11814]
fstring_end: " [11857,11858]
===
match
---
atom_expr [1779,1807]
atom_expr [1779,1807]
===
match
---
try_stmt [11277,11548]
try_stmt [11321,11592]
===
match
---
trailer [2152,2182]
trailer [2152,2182]
===
match
---
simple_stmt [5714,5730]
simple_stmt [5758,5774]
===
match
---
trailer [2596,2604]
trailer [2640,2648]
===
match
---
trailer [4774,4785]
trailer [4818,4829]
===
match
---
argument [6542,6557]
argument [6586,6601]
===
match
---
simple_stmt [11685,11714]
simple_stmt [11729,11758]
===
match
---
operator: = [11993,11994]
operator: = [12037,12038]
===
match
---
simple_stmt [3442,3490]
simple_stmt [3486,3534]
===
match
---
dotted_name [7085,7107]
dotted_name [7129,7151]
===
match
---
decorator [1951,1968]
decorator [1951,1968]
===
match
---
fstring_expr [6826,6831]
fstring_expr [6870,6875]
===
match
---
name: models [7607,7613]
name: models [7651,7657]
===
match
---
operator: = [2141,2142]
operator: = [2141,2142]
===
match
---
name: response [12753,12761]
name: response [12797,12805]
===
match
---
simple_stmt [8901,8917]
simple_stmt [8945,8961]
===
match
---
operator: = [11182,11183]
operator: = [11226,11227]
===
match
---
name: get_dag_run_state [10001,10018]
name: get_dag_run_state [10045,10062]
===
match
---
operator: } [13441,13442]
operator: } [13485,13486]
===
match
---
name: is_paused [7688,7697]
name: is_paused [7732,7741]
===
match
---
trailer [1786,1807]
trailer [1786,1807]
===
match
---
funcdef [5139,5759]
funcdef [5183,5803]
===
match
---
name: log [10087,10090]
name: log [10131,10134]
===
match
---
name: pools [11942,11947]
name: pools [11986,11991]
===
match
---
string: '_' [9022,9025]
string: '_' [9066,9069]
===
match
---
name: data [3338,3342]
name: data [3382,3386]
===
match
---
name: experimental [1176,1188]
name: experimental [1176,1188]
===
match
---
parameters [12502,12508]
parameters [12546,12552]
===
match
---
trailer [2760,2785]
trailer [2804,2829]
===
match
---
simple_stmt [4266,4305]
simple_stmt [4310,4349]
===
match
---
operator: , [7154,7155]
operator: , [7198,7199]
===
match
---
name: error [12256,12261]
name: error [12300,12305]
===
match
---
argument [11800,11814]
argument [11844,11858]
===
match
---
try_stmt [12537,12811]
try_stmt [12581,12855]
===
match
---
operator: = [7493,7494]
operator: = [7537,7538]
===
match
---
expr_stmt [3321,3360]
expr_stmt [3365,3404]
===
match
---
name: response [11393,11401]
name: response [11437,11445]
===
match
---
operator: , [7380,7381]
operator: , [7424,7425]
===
match
---
operator: , [4516,4517]
operator: , [4560,4561]
===
match
---
suite [6016,6083]
suite [6060,6127]
===
match
---
name: log [4371,4374]
name: log [4415,4418]
===
match
---
operator: = [13577,13578]
operator: = [13621,13622]
===
match
---
operator: = [11402,11403]
operator: = [11446,11447]
===
match
---
name: error_message [13376,13389]
name: error_message [13420,13433]
===
match
---
return_stmt [2012,2090]
return_stmt [2012,2090]
===
match
---
operator: = [12896,12897]
operator: = [12940,12941]
===
match
---
trailer [11531,11547]
trailer [11575,11591]
===
match
---
fstring [13684,13692]
fstring [13728,13736]
===
match
---
name: route [12831,12836]
name: route [12875,12880]
===
match
---
operator: @ [5930,5931]
operator: @ [5974,5975]
===
match
---
arglist [6494,6557]
arglist [6538,6601]
===
match
---
funcdef [2889,4561]
funcdef [2933,4605]
===
match
---
atom_expr [6340,6353]
atom_expr [6384,6397]
===
match
---
name: version [1716,1723]
name: version [1716,1723]
===
match
---
operator: = [6823,6824]
operator: = [6867,6868]
===
match
---
name: __name__ [2173,2181]
name: __name__ [2173,2181]
===
match
---
except_clause [6737,6767]
except_clause [6781,6811]
===
match
---
name: dag_id [13548,13554]
name: dag_id [13592,13598]
===
match
---
simple_stmt [10355,10421]
simple_stmt [10399,10465]
===
match
---
operator: , [7484,7485]
operator: , [7528,7529]
===
match
---
operator: } [8603,8604]
operator: } [8647,8648]
===
match
---
decorated [9057,10244]
decorated [9101,10288]
===
match
---
name: execution_date [8253,8267]
name: execution_date [8297,8311]
===
match
---
trailer [12255,12271]
trailer [12299,12315]
===
match
---
atom_expr [10001,10042]
atom_expr [10045,10086]
===
match
---
suite [11361,11499]
suite [11405,11543]
===
match
---
import_from [1389,1450]
import_from [1389,1450]
===
match
---
string: '/dags/<string:dag_id>/tasks/<string:task_id>' [6494,6540]
string: '/dags/<string:dag_id>/tasks/<string:task_id>' [6538,6584]
===
match
---
simple_stmt [2238,2364]
simple_stmt [2238,2364]
===
match
---
decorated [7084,7428]
decorated [7128,7472]
===
match
---
name: models [10438,10444]
name: models [10482,10488]
===
match
---
name: delete_dag [1027,1037]
name: delete_dag [1027,1037]
===
match
---
name: methods [11584,11591]
name: methods [11628,11635]
===
match
---
suite [13627,13765]
suite [13671,13809]
===
match
---
trailer [9929,9941]
trailer [9973,9985]
===
match
---
name: error [5655,5660]
name: error [5699,5704]
===
match
---
try_stmt [8671,8917]
try_stmt [8715,8961]
===
match
---
name: user [4404,4408]
name: user [4448,4452]
===
match
---
name: api_experimental [7703,7719]
name: api_experimental [7747,7763]
===
match
---
atom_expr [4012,4052]
atom_expr [4056,4096]
===
match
---
string: 'true' [2402,2408]
string: 'true' [2402,2408]
===
match
---
decorators [6085,6181]
decorators [6129,6225]
===
match
---
name: payload [10589,10596]
name: payload [10633,10640]
===
match
---
trailer [12388,12390]
trailer [12432,12434]
===
match
---
argument [12889,12904]
argument [12933,12948]
===
match
---
atom_expr [10960,10981]
atom_expr [11004,11025]
===
match
---
arglist [12837,12904]
arglist [12881,12948]
===
match
---
expr_stmt [2124,2182]
expr_stmt [2124,2182]
===
match
---
string: """Get Airflow Version""" [6021,6046]
string: """Get Airflow Version""" [6065,6090]
===
match
---
operator: = [9999,10000]
operator: = [10043,10044]
===
match
---
return_stmt [7393,7427]
return_stmt [7437,7471]
===
match
---
name: url_for [947,954]
name: url_for [947,954]
===
match
---
name: jsonify [11404,11411]
name: jsonify [11448,11455]
===
match
---
atom_expr [11524,11547]
atom_expr [11568,11591]
===
match
---
arglist [7108,7171]
arglist [7152,7215]
===
match
---
name: status [5915,5921]
name: status [5959,5965]
===
match
---
comp_if [6989,7013]
comp_if [7033,7057]
===
match
---
simple_stmt [1775,1840]
simple_stmt [1775,1840]
===
match
---
expr_stmt [10109,10143]
expr_stmt [10153,10187]
===
match
---
name: response [6362,6370]
name: response [6406,6414]
===
match
---
string: 'execution_date' [10688,10704]
string: 'execution_date' [10732,10748]
===
match
---
name: response [2213,2221]
name: response [2213,2221]
===
match
---
comp_op [3300,3306]
comp_op [3344,3350]
===
match
---
name: data [3268,3272]
name: data [3312,3316]
===
match
---
name: info [4375,4379]
name: info [4419,4423]
===
match
---
operator: } [2637,2638]
operator: } [2681,2682]
===
match
---
simple_stmt [4071,4156]
simple_stmt [4115,4200]
===
match
---
operator: { [6389,6390]
operator: { [6433,6434]
===
match
---
operator: , [11003,11004]
operator: , [11047,11048]
===
match
---
operator: = [5540,5541]
operator: = [5584,5585]
===
match
---
arglist [2108,2120]
arglist [2108,2120]
===
match
---
atom_expr [8614,8634]
atom_expr [8658,8678]
===
match
---
trailer [4083,4095]
trailer [4127,4139]
===
match
---
operator: @ [11952,11953]
operator: @ [11996,11997]
===
match
---
simple_stmt [6340,6354]
simple_stmt [6384,6398]
===
match
---
fstring_expr [11420,11425]
fstring_expr [11464,11469]
===
match
---
simple_stmt [9032,9055]
simple_stmt [9076,9099]
===
match
---
tfpdef [12947,12958]
tfpdef [12991,13002]
===
match
---
atom_expr [13636,13650]
atom_expr [13680,13694]
===
match
---
trailer [13460,13472]
trailer [13504,13516]
===
match
---
trailer [11305,11314]
trailer [11349,11358]
===
match
---
name: trigger_dag [2893,2904]
name: trigger_dag [2937,2948]
===
match
---
string: 'Airflow.graph' [10906,10921]
string: 'Airflow.graph' [10950,10965]
===
match
---
operator: = [12261,12262]
operator: = [12305,12306]
===
match
---
trailer [10127,10143]
trailer [10171,10187]
===
match
---
except_clause [8305,8322]
except_clause [8349,8366]
===
match
---
name: format [9794,9800]
name: format [9838,9844]
===
match
---
name: error [3745,3750]
name: error [3789,3794]
===
match
---
dotted_name [5931,5953]
dotted_name [5975,5997]
===
match
---
name: fields [8948,8954]
name: fields [8992,8998]
===
match
---
string: '/latest_runs' [10270,10284]
string: '/latest_runs' [10314,10328]
===
match
---
simple_stmt [9957,9973]
simple_stmt [10001,10017]
===
match
---
decorator [6559,6584]
decorator [6603,6628]
===
match
---
string: 'replace_microseconds' [3949,3971]
string: 'replace_microseconds' [3993,4015]
===
match
---
operator: { [12264,12265]
operator: { [12308,12309]
===
match
---
simple_stmt [11241,11273]
simple_stmt [11285,11317]
===
match
---
name: airflow [988,995]
name: airflow [988,995]
===
match
---
name: count [5005,5010]
name: count [5049,5054]
===
match
---
name: execution_date [3219,3233]
name: execution_date [3263,3277]
===
match
---
simple_stmt [9560,9608]
simple_stmt [9604,9652]
===
match
---
operator: , [11173,11174]
operator: , [11217,11218]
===
match
---
expr_stmt [12280,12318]
expr_stmt [12324,12362]
===
match
---
operator: , [6604,6605]
operator: , [6648,6649]
===
match
---
string: '/test' [5785,5792]
string: '/test' [5829,5836]
===
match
---
atom [3545,3728]
atom [3589,3772]
===
match
---
simple_stmt [830,873]
simple_stmt [830,873]
===
match
---
parameters [5151,5159]
parameters [5195,5203]
===
match
---
name: execution_date [8285,8299]
name: execution_date [8329,8343]
===
match
---
operator: @ [7084,7085]
operator: @ [7128,7129]
===
match
---
operator: = [11061,11062]
operator: = [11105,11106]
===
match
---
atom [6550,6557]
atom [6594,6601]
===
match
---
simple_stmt [7916,8185]
simple_stmt [7960,8229]
===
match
---
dotted_name [11953,11975]
dotted_name [11997,12019]
===
match
---
suite [12981,13807]
suite [13025,13851]
===
match
---
name: message [4986,4993]
name: message [5030,5037]
===
match
---
operator: = [12301,12302]
operator: = [12345,12346]
===
match
---
trailer [3698,3714]
trailer [3742,3758]
===
match
---
return_stmt [2712,2727]
return_stmt [2756,2771]
===
match
---
dotted_name [10430,10444]
dotted_name [10474,10488]
===
match
---
trailer [7033,7041]
trailer [7077,7085]
===
match
---
string: '/dags/<string:dag_id>' [4587,4610]
string: '/dags/<string:dag_id>' [4631,4654]
===
match
---
argument [11986,12002]
argument [12030,12046]
===
match
---
name: api_experimental [5040,5056]
name: api_experimental [5084,5100]
===
match
---
parameters [2212,2232]
parameters [2212,2232]
===
match
---
trailer [3843,3855]
trailer [3887,3899]
===
match
---
decorators [6470,6584]
decorators [6514,6628]
===
match
---
trailer [6952,6955]
trailer [6996,6999]
===
match
---
trailer [12217,12223]
trailer [12261,12267]
===
match
---
name: api_experimental [7085,7101]
name: api_experimental [7129,7145]
===
match
---
expr_stmt [13170,13357]
expr_stmt [13214,13401]
===
match
---
trailer [12636,12642]
trailer [12680,12686]
===
match
---
trailer [7351,7387]
trailer [7395,7431]
===
match
---
dotted_name [10247,10269]
dotted_name [10291,10313]
===
match
---
name: get_task [1426,1434]
name: get_task [1426,1434]
===
match
---
name: fields [6936,6942]
name: fields [6980,6986]
===
match
---
name: DagModel [7614,7622]
name: DagModel [7658,7666]
===
match
---
expr_stmt [13399,13443]
expr_stmt [13443,13487]
===
match
---
name: response [13702,13710]
name: response [13746,13754]
===
match
---
parameters [7545,7553]
parameters [7589,7597]
===
match
---
operator: , [9137,9138]
operator: , [9181,9182]
===
match
---
trailer [11761,11767]
trailer [11805,11811]
===
match
---
name: api [1245,1248]
name: api [1245,1248]
===
match
---
name: p [11937,11938]
name: p [11981,11982]
===
match
---
name: isoformat [10824,10833]
name: isoformat [10868,10877]
===
match
---
atom [8580,8604]
atom [8624,8648]
===
match
---
or_test [10777,10800]
or_test [10821,10844]
===
match
---
simple_stmt [8561,8606]
simple_stmt [8605,8650]
===
match
---
simple_stmt [5900,5928]
simple_stmt [5944,5972]
===
match
---
name: api_experimental [5931,5947]
name: api_experimental [5975,5991]
===
match
---
return_stmt [8901,8916]
return_stmt [8945,8960]
===
match
---
name: pool [12550,12554]
name: pool [12594,12598]
===
match
---
name: append [10597,10603]
name: append [10641,10647]
===
match
---
atom [7164,7171]
atom [7208,7215]
===
match
---
operator: = [7819,7820]
operator: = [7863,7864]
===
match
---
operator: = [5645,5646]
operator: = [5689,5690]
===
match
---
name: jsonify [9039,9046]
name: jsonify [9083,9090]
===
match
---
atom_expr [12667,12690]
atom_expr [12711,12734]
===
match
---
return_stmt [12780,12810]
return_stmt [12824,12854]
===
match
---
string: '/dags/<string:dag_id>/dag_runs' [2812,2844]
string: '/dags/<string:dag_id>/dag_runs' [2856,2888]
===
match
---
name: info [10091,10095]
name: info [10135,10139]
===
match
---
atom [7674,7698]
atom [7718,7742]
===
match
---
atom_expr [11297,11325]
atom_expr [11341,11369]
===
match
---
string: '/dags/<string:dag_id>/paused/<string:paused>' [7108,7154]
string: '/dags/<string:dag_id>/paused/<string:paused>' [7152,7198]
===
match
---
if_stmt [2549,2707]
if_stmt [2593,2751]
===
match
---
name: request [3041,3048]
name: request [3085,3092]
===
match
---
trailer [7622,7635]
trailer [7666,7679]
===
match
---
trailer [12102,12114]
trailer [12146,12158]
===
match
---
name: error_message [3807,3820]
name: error_message [3851,3864]
===
match
---
trailer [3467,3473]
trailer [3511,3517]
===
match
---
suite [11896,11950]
suite [11940,11994]
===
match
---
atom [5971,5978]
atom [6015,6022]
===
match
---
name: lineage [13798,13805]
name: lineage [13842,13849]
===
match
---
simple_stmt [5679,5706]
simple_stmt [5723,5750]
===
match
---
simple_stmt [10152,10191]
simple_stmt [10196,10235]
===
match
---
name: dr [4071,4073]
name: dr [4115,4117]
===
match
---
atom_expr [2562,2578]
atom_expr [2606,2622]
===
match
---
decorator [2788,2864]
decorator [2832,2908]
===
match
---
trailer [2063,2073]
trailer [2063,2073]
===
match
---
trailer [7337,7351]
trailer [7381,7395]
===
match
---
name: err [12643,12646]
name: err [12687,12690]
===
match
---
name: start_date [10784,10794]
name: start_date [10828,10838]
===
match
---
expr_stmt [3896,3941]
expr_stmt [3940,3985]
===
match
---
not_test [6992,7013]
not_test [7036,7057]
===
match
---
simple_stmt [6452,6468]
simple_stmt [6496,6512]
===
match
---
trailer [3691,3698]
trailer [3735,3742]
===
match
---
name: name [11320,11324]
name: name [11364,11368]
===
match
---
name: dagruns [10464,10471]
name: dagruns [10508,10515]
===
match
---
fstring_expr [5663,5668]
fstring_expr [5707,5712]
===
match
---
trailer [9046,9054]
trailer [9090,9098]
===
match
---
atom_expr [4076,4155]
atom_expr [4120,4199]
===
match
---
atom_expr [11459,11474]
atom_expr [11503,11518]
===
match
---
decorator [12813,12906]
decorator [12857,12950]
===
match
---
name: kwargs [1995,2001]
name: kwargs [1995,2001]
===
match
---
trailer [9585,9591]
trailer [9629,9635]
===
match
---
return_stmt [6272,6295]
return_stmt [6316,6339]
===
match
---
atom_expr [6777,6790]
atom_expr [6821,6834]
===
match
---
name: api_experimental [11128,11144]
name: api_experimental [11172,11188]
===
match
---
atom [12897,12904]
atom [12941,12948]
===
match
---
simple_stmt [5532,5570]
simple_stmt [5576,5614]
===
match
---
trailer [4930,4942]
trailer [4974,4986]
===
match
---
atom [5105,5112]
atom [5149,5156]
===
match
---
fstring_start: f" [5661,5663]
fstring_start: f" [5705,5707]
===
match
---
name: error_message [3529,3542]
name: error_message [3573,3586]
===
match
---
name: get_task [6707,6715]
name: get_task [6751,6759]
===
match
---
operator: = [4885,4886]
operator: = [4929,4930]
===
match
---
trailer [5914,5927]
trailer [5958,5971]
===
match
---
name: pool_api [12557,12565]
name: pool_api [12601,12609]
===
match
---
name: execution_date [13332,13346]
name: execution_date [13376,13390]
===
match
---
operator: @ [4563,4564]
operator: @ [4607,4608]
===
match
---
try_stmt [12119,12392]
try_stmt [12163,12436]
===
match
---
operator: = [3156,3157]
operator: = [3200,3201]
===
match
---
if_stmt [4334,4414]
if_stmt [4378,4458]
===
match
---
trailer [11444,11456]
trailer [11488,11500]
===
match
---
simple_stmt [13659,13694]
simple_stmt [13703,13738]
===
match
---
expr_stmt [3122,3145]
expr_stmt [3166,3189]
===
match
---
operator: @ [12906,12907]
operator: @ [12950,12951]
===
match
---
operator: } [3820,3821]
operator: } [3864,3865]
===
match
---
name: response [9964,9972]
name: response [10008,10016]
===
match
---
simple_stmt [1302,1389]
simple_stmt [1302,1389]
===
match
---
name: api [1315,1318]
name: api [1315,1318]
===
match
---
atom_expr [8877,8892]
atom_expr [8921,8936]
===
match
---
name: jsonify [4234,4241]
name: jsonify [4278,4285]
===
match
---
import_as_name [1358,1388]
import_as_name [1358,1388]
===
match
---
expr_stmt [9560,9607]
expr_stmt [9604,9651]
===
match
---
suite [8780,8917]
suite [8824,8961]
===
match
---
atom_expr [4430,4540]
atom_expr [4474,4584]
===
match
---
atom_expr [10589,11036]
atom_expr [10633,11080]
===
match
---
trailer [10090,10095]
trailer [10134,10139]
===
match
---
simple_stmt [2918,3030]
simple_stmt [2962,3074]
===
match
---
name: get_pool [11306,11314]
name: get_pool [11350,11358]
===
match
---
name: format [3692,3698]
name: format [3736,3742]
===
match
---
string: 'DELETE' [12451,12459]
string: 'DELETE' [12495,12503]
===
match
---
trailer [12642,12647]
trailer [12686,12691]
===
match
---
name: error [13370,13375]
name: error [13414,13419]
===
match
---
except_clause [3498,3515]
except_clause [3542,3559]
===
match
---
string: '_' [7009,7012]
string: '_' [7053,7056]
===
match
---
fstring_start: f" [4455,4457]
fstring_start: f" [4499,4501]
===
match
---
comp_if [9002,9026]
comp_if [9046,9070]
===
match
---
atom_expr [10777,10794]
atom_expr [10821,10838]
===
match
---
funcdef [5836,5928]
funcdef [5880,5972]
===
match
---
dotted_name [1456,1505]
dotted_name [1456,1505]
===
match
---
name: jsonify [13410,13417]
name: jsonify [13454,13461]
===
match
---
operator: = [4428,4429]
operator: = [4472,4473]
===
match
---
name: set_is_paused [7338,7351]
name: set_is_paused [7382,7395]
===
match
---
string: 'is_paused' [7675,7686]
string: 'is_paused' [7719,7730]
===
match
---
parameters [1869,1882]
parameters [1869,1882]
===
match
---
name: current_app [2019,2030]
name: current_app [2019,2030]
===
match
---
suite [4191,4329]
suite [4235,4373]
===
match
---
expr_stmt [3442,3489]
expr_stmt [3486,3533]
===
match
---
string: 'execution_date' [3282,3298]
string: 'execution_date' [3326,3342]
===
match
---
fstring_end: " [4255,4256]
fstring_end: " [4299,4300]
===
match
---
operator: = [4524,4525]
operator: = [4568,4569]
===
match
---
name: TypeVar [1779,1786]
name: TypeVar [1779,1786]
===
match
---
trailer [11462,11474]
trailer [11506,11518]
===
match
---
simple_stmt [8253,8301]
simple_stmt [8297,8345]
===
match
---
return_stmt [11905,11949]
return_stmt [11949,11993]
===
match
---
name: api_experimental [2124,2140]
name: api_experimental [2124,2140]
===
match
---
trailer [9010,9021]
trailer [9054,9065]
===
match
---
simple_stmt [2712,2728]
simple_stmt [2756,2772]
===
match
---
dotted_name [4564,4586]
dotted_name [4608,4630]
===
match
---
name: api_experimental [2789,2805]
name: api_experimental [2833,2849]
===
match
---
atom [3797,3821]
atom [3841,3865]
===
match
---
string: "stable-rest-api/migration.html" [2436,2468]
string: "upgrading-to-2.html#migration-guide-from-experimental-api-to-stable-api-v1" [2436,2512]
===
match
---
decorator [7173,7198]
decorator [7217,7242]
===
match
---
operator: = [8820,8821]
operator: = [8864,8865]
===
match
---
name: pool [11532,11536]
name: pool [11576,11580]
===
match
---
string: '/dags/<string:dag_id>/paused' [7454,7484]
string: '/dags/<string:dag_id>/paused' [7498,7528]
===
match
---
atom_expr [2588,2612]
atom_expr [2632,2656]
===
match
---
name: methods [5794,5801]
name: methods [5838,5845]
===
match
---
name: version [1731,1738]
name: version [1731,1738]
===
match
---
name: requires_authentication [2865,2888]
name: requires_authentication [2909,2932]
===
match
---
suite [2913,4561]
suite [2957,4605]
===
match
---
trailer [2570,2578]
trailer [2614,2622]
===
match
---
argument [4472,4516]
argument [4516,4560]
===
match
---
name: dag_id [7213,7219]
name: dag_id [7257,7263]
===
match
---
trailer [3744,3750]
trailer [3788,3794]
===
match
---
operator: } [4892,4893]
operator: } [4936,4937]
===
match
---
name: str [12976,12979]
name: str [13020,13023]
===
match
---
atom_expr [6842,6862]
atom_expr [6886,6906]
===
match
---
name: T [2108,2109]
name: T [2108,2109]
===
match
---
operator: ** [1993,1995]
operator: ** [1993,1995]
===
match
---
atom [8957,9027]
atom [9001,9071]
===
match
---
simple_stmt [6777,6791]
simple_stmt [6821,6835]
===
match
---
name: dag_id [5152,5158]
name: dag_id [5196,5202]
===
match
---
name: Blueprint [2143,2152]
name: Blueprint [2143,2152]
===
match
---
trailer [4344,4361]
trailer [4388,4405]
===
match
---
atom_expr [13702,13722]
atom_expr [13746,13766]
===
match
---
string: 'DELETE' [4621,4629]
string: 'DELETE' [4665,4673]
===
match
---
operator: = [1777,1778]
operator: = [1777,1778]
===
match
---
name: jsonify [929,936]
name: jsonify [929,936]
===
match
---
string: """Get paused state of a dag""" [7559,7590]
string: """Get paused state of a dag""" [7603,7634]
===
match
---
fstring_end: " [4893,4894]
fstring_end: " [4937,4938]
===
match
---
name: api_experimental [12814,12830]
name: api_experimental [12858,12874]
===
match
---
name: jsonify [8572,8579]
name: jsonify [8616,8623]
===
match
---
decorator [11550,11601]
decorator [11594,11645]
===
match
---
simple_stmt [6362,6397]
simple_stmt [6406,6441]
===
match
---
name: requires_authentication [5812,5835]
name: requires_authentication [5856,5879]
===
match
---
name: str [6949,6952]
name: str [6993,6996]
===
match
---
simple_stmt [1451,1531]
simple_stmt [1451,1531]
===
match
---
name: bool [7273,7277]
name: bool [7317,7321]
===
match
---
name: current_app [913,924]
name: current_app [913,924]
===
match
---
operator: = [9653,9654]
operator: = [9697,9698]
===
match
---
try_stmt [4747,4967]
try_stmt [4791,5011]
===
match
---
operator: , [2079,2080]
operator: , [2079,2080]
===
match
---
trailer [6380,6396]
trailer [6424,6440]
===
match
---
name: deprecation_link [2621,2637]
name: deprecation_link [2665,2681]
===
match
---
name: err [12684,12687]
name: err [12728,12731]
===
match
---
name: AirflowException [10054,10070]
name: AirflowException [10098,10114]
===
match
---
operator: = [5801,5802]
operator: = [5845,5846]
===
match
---
name: T [1775,1776]
name: T [1775,1776]
===
match
---
name: dag_is_paused [7532,7545]
name: dag_is_paused [7576,7589]
===
match
---
operator: @ [5811,5812]
operator: @ [5855,5856]
===
match
---
param [2905,2911]
param [2949,2955]
===
match
---
arglist [8712,8743]
arglist [8756,8787]
===
match
---
operator: = [3199,3200]
operator: = [3243,3244]
===
match
---
trailer [12159,12169]
trailer [12203,12213]
===
match
---
operator: { [2496,2497]
operator: { [2540,2541]
===
match
---
name: run_id [4528,4534]
name: run_id [4572,4578]
===
match
---
trailer [1753,1763]
trailer [1753,1763]
===
match
---
name: logging [794,801]
name: logging [794,801]
===
match
---
simple_stmt [9639,9827]
simple_stmt [9683,9871]
===
match
---
decorated [5930,6083]
decorated [5974,6127]
===
match
---
operator: , [12958,12959]
operator: , [13002,13003]
===
match
---
arglist [7731,7827]
arglist [7775,7871]
===
match
---
name: get_lineage [1358,1369]
name: get_lineage [1358,1369]
===
match
---
name: timezone [8270,8278]
name: timezone [8314,8322]
===
match
---
name: err [12303,12306]
name: err [12347,12350]
===
match
---
simple_stmt [11871,11887]
simple_stmt [11915,11931]
===
match
---
name: response [9868,9876]
name: response [9912,9920]
===
match
---
trailer [10603,11036]
trailer [10647,11080]
===
match
---
dictorsetmaker [8958,9026]
dictorsetmaker [9002,9070]
===
match
---
string: '/dags/<string:dag_id>/code' [6109,6137]
string: '/dags/<string:dag_id>/code' [6153,6181]
===
match
---
param [1986,1992]
param [1986,1992]
===
match
---
name: after_request [2747,2760]
name: after_request [2791,2804]
===
match
---
suite [3429,3490]
suite [3473,3534]
===
match
---
operator: = [9575,9576]
operator: = [9619,9620]
===
match
---
simple_stmt [12077,12115]
simple_stmt [12121,12159]
===
match
---
decorator [7430,7503]
decorator [7474,7547]
===
match
---
operator: = [4454,4455]
operator: = [4498,4499]
===
match
---
atom_expr [4337,4361]
atom_expr [4381,4405]
===
match
---
fstring_end: " [13691,13692]
fstring_end: " [13735,13736]
===
match
---
fstring_string:  record(s) [5011,5021]
fstring_string:  record(s) [5055,5065]
===
match
---
if_stmt [3245,3891]
if_stmt [3289,3935]
===
match
---
operator: = [4287,4288]
operator: = [4331,4332]
===
match
---
atom_expr [8980,9001]
atom_expr [9024,9045]
===
match
---
operator: , [9206,9207]
operator: , [9250,9251]
===
match
---
operator: { [4888,4889]
operator: { [4932,4933]
===
match
---
name: status_code [11445,11456]
name: status_code [11489,11500]
===
match
---
operator: = [7163,7164]
operator: = [7207,7208]
===
match
---
name: response [11878,11886]
name: response [11922,11930]
===
match
---
trailer [9591,9607]
trailer [9635,9651]
===
match
---
name: err [10137,10140]
name: err [10181,10184]
===
match
---
fstring_expr [10136,10141]
fstring_expr [10180,10185]
===
match
---
atom_expr [11370,11384]
atom_expr [11414,11428]
===
match
---
name: execution_date [10713,10727]
name: execution_date [10757,10771]
===
match
---
name: requires_authentication [6560,6583]
name: requires_authentication [6604,6627]
===
match
---
operator: , [1047,1048]
operator: , [1047,1048]
===
match
---
trailer [6817,6833]
trailer [6861,6877]
===
match
---
return_stmt [13488,13503]
return_stmt [13532,13547]
===
match
---
name: jsonify [10120,10127]
name: jsonify [10164,10171]
===
match
---
operator: } [6830,6831]
operator: } [6874,6875]
===
match
---
operator: @ [5761,5762]
operator: @ [5805,5806]
===
match
---
atom_expr [11921,11932]
atom_expr [11965,11976]
===
match
---
fstring_start: f" [6387,6389]
fstring_start: f" [6431,6433]
===
match
---
name: jsonify [11524,11531]
name: jsonify [11568,11575]
===
match
---
simple_stmt [12052,12073]
simple_stmt [12096,12117]
===
match
---
name: jsonify [4872,4879]
name: jsonify [4916,4923]
===
match
---
string: 'error' [13419,13426]
string: 'error' [13463,13470]
===
match
---
name: add_deprecation_headers [2189,2212]
name: add_deprecation_headers [2189,2212]
===
match
---
string: 'GET' [11184,11189]
string: 'GET' [11228,11233]
===
match
---
trailer [13122,13138]
trailer [13166,13182]
===
match
---
operator: , [11984,11985]
operator: , [12028,12029]
===
match
---
parameters [4671,4679]
parameters [4715,4723]
===
match
---
atom_expr [4872,4895]
atom_expr [4916,4939]
===
match
---
dotted_name [6086,6108]
dotted_name [6130,6152]
===
match
---
name: jsonify [7400,7407]
name: jsonify [7444,7451]
===
match
---
argument [5024,5035]
argument [5068,5079]
===
match
---
name: error [9839,9844]
name: error [9883,9888]
===
match
---
simple_stmt [5490,5524]
simple_stmt [5534,5568]
===
match
---
operator: = [1744,1745]
operator: = [1744,1745]
===
match
---
string: 'GET' [7821,7826]
string: 'GET' [7865,7870]
===
match
---
decorators [11550,11626]
decorators [11594,11670]
===
match
---
simple_stmt [12361,12392]
simple_stmt [12405,12436]
===
match
---
funcdef [11217,11548]
funcdef [11261,11592]
===
match
---
except_clause [12174,12204]
except_clause [12218,12248]
===
match
---
string: 'execution_date' [3343,3359]
string: 'execution_date' [3387,3403]
===
match
---
name: requires_authentication [2040,2063]
name: requires_authentication [2040,2063]
===
match
---
operator: = [11691,11692]
operator: = [11735,11736]
===
match
---
name: error [12637,12642]
name: error [12681,12686]
===
match
---
name: response [2658,2666]
name: response [2702,2710]
===
match
---
atom_expr [3459,3489]
atom_expr [3503,3533]
===
match
---
trailer [6343,6348]
trailer [6387,6392]
===
match
---
atom_expr [5542,5569]
atom_expr [5586,5613]
===
match
---
name: err [6827,6830]
name: err [6871,6874]
===
match
---
trailer [7613,7622]
trailer [7657,7666]
===
match
---
name: status_code [8863,8874]
name: status_code [8907,8918]
===
match
---
arglist [1787,1806]
arglist [1787,1806]
===
match
---
operator: } [11812,11813]
operator: } [11856,11857]
===
match
---
decorated [11127,11548]
decorated [11171,11592]
===
match
---
fstring_end: " [12269,12270]
fstring_end: " [12313,12314]
===
match
---
operator: = [10959,10960]
operator: = [11003,11004]
===
match
---
simple_stmt [4685,4743]
simple_stmt [4729,4787]
===
match
---
atom_expr [2103,2121]
atom_expr [2103,2121]
===
match
---
name: get_dag_runs [1289,1301]
name: get_dag_runs [1289,1301]
===
match
---
decorators [9057,9181]
decorators [9101,9225]
===
match
---
atom_expr [6968,6988]
atom_expr [7012,7032]
===
match
---
trailer [8964,8967]
trailer [9008,9011]
===
match
---
suite [12541,12589]
suite [12585,12633]
===
match
---
argument [2846,2862]
argument [2890,2906]
===
match
---
fstring [11806,11814]
fstring [11850,11858]
===
match
---
trailer [11544,11546]
trailer [11588,11590]
===
match
---
fstring_start: f" [11418,11420]
fstring_start: f" [11462,11464]
===
match
---
suite [2649,2707]
suite [2693,2751]
===
match
---
trailer [4514,4516]
trailer [4558,4560]
===
match
---
param [9200,9207]
param [9244,9251]
===
match
---
operator: { [10136,10137]
operator: { [10180,10181]
===
match
---
name: AirflowException [13603,13619]
name: AirflowException [13647,13663]
===
match
---
name: log [6777,6780]
name: log [6821,6824]
===
match
---
name: timezone [13108,13116]
name: timezone [13152,13160]
===
match
---
trailer [3057,3069]
trailer [3101,3113]
===
match
---
dictorsetmaker [6946,7013]
dictorsetmaker [6990,7057]
===
match
---
name: name [12578,12582]
name: name [12622,12626]
===
match
---
name: jsonify [13670,13677]
name: jsonify [13714,13721]
===
match
---
expr_stmt [3034,3069]
expr_stmt [3078,3113]
===
match
---
name: jsonify [5647,5654]
name: jsonify [5691,5698]
===
match
---
trailer [10018,10042]
trailer [10062,10086]
===
match
---
name: execution_date [8494,8508]
name: execution_date [8538,8552]
===
match
---
atom_expr [4234,4257]
atom_expr [4278,4301]
===
match
---
name: run_id [4518,4524]
name: run_id [4562,4568]
===
match
---
string: """     Add `Deprecation HTTP Header Field     <https://tools.ietf.org/id/draft-dalal-deprecation-header-03.html>`__.     """ [2238,2363]
string: """     Add `Deprecation HTTP Header Field     <https://tools.ietf.org/id/draft-dalal-deprecation-header-03.html>`__.     """ [2238,2363]
===
match
---
operator: { [2687,2688]
operator: { [2731,2732]
===
match
---
operator: = [13473,13474]
operator: = [13517,13518]
===
match
---
name: jsonify [11048,11055]
name: jsonify [11092,11099]
===
match
---
simple_stmt [4223,4258]
simple_stmt [4267,4302]
===
match
---
trailer [10160,10172]
trailer [10204,10216]
===
match
---
name: dr [4525,4527]
name: dr [4569,4571]
===
match
---
operator: = [3457,3458]
operator: = [3501,3502]
===
match
---
fstring_start: f" [12681,12683]
fstring_start: f" [12725,12727]
===
match
---
fstring_start: f" [12262,12264]
fstring_start: f" [12306,12308]
===
match
---
simple_stmt [11393,11428]
simple_stmt [11437,11472]
===
match
---
atom [7494,7501]
atom [7538,7545]
===
match
---
operator: @ [11550,11551]
operator: @ [11594,11595]
===
match
---
name: task_info [6588,6597]
name: task_info [6632,6641]
===
match
---
trailer [4203,4209]
trailer [4247,4253]
===
match
---
trailer [10659,10666]
trailer [10703,10710]
===
match
---
trailer [11799,11815]
trailer [11843,11859]
===
match
---
atom_expr [12139,12169]
atom_expr [12183,12213]
===
match
---
name: startswith [6998,7008]
name: startswith [7042,7052]
===
match
---
name: dag_id [6198,6204]
name: dag_id [6242,6248]
===
match
---
name: AirflowException [11337,11353]
name: AirflowException [11381,11397]
===
match
---
fstring_string: Created  [4457,4465]
fstring_string: Created  [4501,4509]
===
match
---
trailer [3281,3299]
trailer [3325,3343]
===
match
---
trailer [11767,11772]
trailer [11811,11816]
===
match
---
name: error [11800,11805]
name: error [11844,11849]
===
match
---
atom [7820,7827]
atom [7864,7871]
===
match
---
suite [5481,5570]
suite [5525,5614]
===
match
---
operator: @ [6085,6086]
operator: @ [6129,6130]
===
match
---
string: 'OK' [5922,5926]
string: 'OK' [5966,5970]
===
match
---
atom_expr [3041,3069]
atom_expr [3085,3113]
===
match
---
simple_stmt [4313,4329]
simple_stmt [4357,4373]
===
match
---
name: log [12633,12636]
name: log [12677,12680]
===
match
---
name: route [5057,5062]
name: route [5101,5106]
===
match
---
atom_expr [8270,8300]
atom_expr [8314,8344]
===
match
---
string: '' [10798,10800]
string: '' [10842,10844]
===
match
---
name: data [3277,3281]
name: data [3321,3325]
===
match
---
simple_stmt [4200,4215]
simple_stmt [4244,4259]
===
match
---
trailer [2030,2039]
trailer [2030,2039]
===
match
---
string: 'GET' [6551,6556]
string: 'GET' [6595,6600]
===
match
---
simple_stmt [11370,11385]
simple_stmt [11414,11429]
===
match
---
name: err [6865,6868]
name: err [6909,6912]
===
match
---
operator: , [857,858]
operator: , [857,858]
===
match
---
string: 'GET' [11593,11598]
string: 'GET' [11637,11642]
===
match
---
simple_stmt [12550,12589]
simple_stmt [12594,12633]
===
match
---
name: run_id [3075,3081]
name: run_id [3119,3125]
===
match
---
argument [13548,13561]
argument [13592,13605]
===
match
---
name: err [5601,5604]
name: err [5645,5648]
===
match
---
atom_expr [10474,10498]
atom_expr [10518,10542]
===
match
---
atom_expr [6405,6425]
atom_expr [6449,6469]
===
match
---
name: dr [4487,4489]
name: dr [4531,4533]
===
match
---
simple_stmt [5165,5473]
simple_stmt [5209,5517]
===
match
---
trailer [10095,10100]
trailer [10139,10144]
===
match
---
atom_expr [11404,11427]
atom_expr [11448,11471]
===
match
---
fstring_expr [12683,12688]
fstring_expr [12727,12732]
===
match
---
simple_stmt [8614,8641]
simple_stmt [8658,8685]
===
match
---
suite [6615,7042]
suite [6659,7086]
===
match
---
name: v [8965,8966]
name: v [9009,9010]
===
match
---
atom_expr [8362,8509]
atom_expr [8406,8553]
===
match
---
atom_expr [8528,8552]
atom_expr [8572,8596]
===
match
---
name: trigger_dag [4084,4095]
name: trigger_dag [4128,4139]
===
match
---
import_from [1614,1657]
import_from [1614,1657]
===
match
---
expr_stmt [12699,12737]
expr_stmt [12743,12781]
===
match
---
operator: = [4232,4233]
operator: = [4276,4277]
===
match
---
operator: = [11417,11418]
operator: = [11461,11462]
===
match
---
decorators [11952,12029]
decorators [11996,12073]
===
match
---
try_stmt [4058,4329]
try_stmt [4102,4373]
===
match
---
name: execution_date [10561,10575]
name: execution_date [10605,10619]
===
match
---
return_stmt [11871,11886]
return_stmt [11915,11930]
===
match
---
atom [9147,9154]
atom [9191,9198]
===
match
---
atom_expr [12303,12318]
atom_expr [12347,12362]
===
match
---
string: 'conf' [3170,3176]
string: 'conf' [3214,3220]
===
match
---
operator: = [10472,10473]
operator: = [10516,10517]
===
match
---
name: err [13725,13728]
name: err [13769,13772]
===
match
---
string: '/dags/<string:dag_id>/dag_runs' [5063,5095]
string: '/dags/<string:dag_id>/dag_runs' [5107,5139]
===
match
---
operator: @ [10303,10304]
operator: @ [10347,10348]
===
match
---
trailer [4841,4847]
trailer [4885,4891]
===
match
---
suite [2003,2091]
suite [2003,2091]
===
match
---
atom [11592,11599]
atom [11636,11643]
===
match
---
parameters [6013,6015]
parameters [6057,6059]
===
match
---
simple_stmt [6021,6047]
simple_stmt [6065,6091]
===
match
---
name: is_paused [7644,7653]
name: is_paused [7688,7697]
===
match
---
name: err [11768,11771]
name: err [11812,11815]
===
match
---
expr_stmt [9991,10042]
expr_stmt [10035,10086]
===
match
---
expr_stmt [8811,8845]
expr_stmt [8855,8889]
===
match
---
atom_expr [4402,4408]
atom_expr [4446,4452]
===
match
---
name: jsonify [11792,11799]
name: jsonify [11836,11843]
===
match
---
name: response [2368,2376]
name: response [2368,2376]
===
match
---
name: dr [4466,4468]
name: dr [4510,4512]
===
match
---
name: experimental [1475,1487]
name: experimental [1475,1487]
===
match
---
except_clause [13143,13160]
except_clause [13187,13204]
===
match
---
operator: = [11805,11806]
operator: = [11849,11850]
===
match
---
import_as_name [1027,1047]
import_as_name [1027,1047]
===
match
---
string: 'as a date. Example date format: 2015-11-16T14:34:15+00:00' [13265,13324]
string: 'as a date. Example date format: 2015-11-16T14:34:15+00:00' [13309,13368]
===
match
---
trailer [10596,10603]
trailer [10640,10647]
===
match
---
name: T [1880,1881]
name: T [1880,1881]
===
match
---
fstring_expr [4250,4255]
fstring_expr [4294,4299]
===
match
---
name: api [1165,1168]
name: api [1165,1168]
===
match
---
operator: == [7285,7287]
operator: == [7329,7331]
===
match
---
operator: @ [10246,10247]
operator: @ [10290,10291]
===
match
---
name: g [926,927]
name: g [926,927]
===
match
---
simple_stmt [874,955]
simple_stmt [874,955]
===
match
---
name: force [12103,12108]
name: force [12147,12152]
===
match
---
name: methods [4612,4619]
name: methods [4656,4663]
===
match
---
suite [9224,10244]
suite [9268,10288]
===
match
---
fstring_expr [2496,2505]
fstring_expr [2540,2549]
===
match
---
name: format [13325,13331]
name: format [13369,13375]
===
match
---
trailer [8862,8874]
trailer [8906,8918]
===
match
---
name: response [13399,13407]
name: response [13443,13451]
===
match
---
parameters [9199,9223]
parameters [9243,9267]
===
match
---
name: experimental [1114,1126]
name: experimental [1114,1126]
===
match
---
expr_stmt [8854,8892]
expr_stmt [8898,8936]
===
match
---
param [2213,2231]
param [2213,2231]
===
match
---
trailer [8984,8993]
trailer [9028,9037]
===
match
---
name: error_message [9897,9910]
name: error_message [9941,9954]
===
match
---
operator: = [10118,10119]
operator: = [10162,10163]
===
match
---
name: api [1402,1405]
name: api [1402,1405]
===
match
---
decorators [11127,11217]
decorators [11171,11261]
===
match
---
simple_stmt [2730,2786]
simple_stmt [2774,2830]
===
match
---
simple_stmt [2588,2640]
simple_stmt [2632,2684]
===
match
---
name: str [8961,8964]
name: str [9005,9008]
===
match
---
simple_stmt [4838,4853]
simple_stmt [4882,4897]
===
match
---
decorators [2788,2889]
decorators [2832,2933]
===
match
---
atom_expr [6810,6833]
atom_expr [6854,6877]
===
match
---
simple_stmt [8332,8520]
simple_stmt [8376,8564]
===
match
---
name: dag_run_status [9185,9199]
name: dag_run_status [9229,9243]
===
match
---
operator: = [12108,12109]
operator: = [12152,12153]
===
match
---
operator: , [5561,5562]
operator: , [5605,5606]
===
match
---
name: response [5721,5729]
name: response [5765,5773]
===
match
---
name: cast [868,872]
name: cast [868,872]
===
match
---
argument [7486,7501]
argument [7530,7545]
===
match
---
name: getLogger [1754,1763]
name: getLogger [1754,1763]
===
match
---
name: err [13646,13649]
name: err [13690,13693]
===
match
---
number: 400 [5702,5705]
number: 400 [5746,5749]
===
match
---
operator: = [1797,1798]
operator: = [1797,1798]
===
match
---
simple_stmt [4371,4414]
simple_stmt [4415,4458]
===
match
---
name: airflow [961,968]
name: airflow [961,968]
===
match
---
suite [3516,3891]
suite [3560,3935]
===
match
---
name: pool_api [12139,12147]
name: pool_api [12183,12191]
===
match
---
import_from [1090,1151]
import_from [1090,1151]
===
match
---
dictorsetmaker [3798,3820]
dictorsetmaker [3842,3864]
===
match
---
atom_expr [5614,5627]
atom_expr [5658,5671]
===
match
---
string: 'response' [7409,7419]
string: 'response' [7453,7463]
===
match
---
simple_stmt [12656,12691]
simple_stmt [12700,12735]
===
match
---
param [9208,9222]
param [9252,9266]
===
match
---
name: conf [3194,3198]
name: conf [3238,3242]
===
match
---
atom_expr [5907,5927]
atom_expr [5951,5971]
===
match
---
return_stmt [12327,12342]
return_stmt [12371,12386]
===
match
---
simple_stmt [10464,10499]
simple_stmt [10508,10543]
===
match
---
name: run_id [4104,4110]
name: run_id [4148,4154]
===
match
---
import_name [787,801]
import_name [787,801]
===
match
---
atom_expr [8822,8845]
atom_expr [8866,8889]
===
match
---
name: route [4581,4586]
name: route [4625,4630]
===
match
---
trailer [13331,13347]
trailer [13375,13391]
===
match
---
name: add_deprecation_headers [2761,2784]
name: add_deprecation_headers [2805,2828]
===
match
---
return_stmt [5900,5927]
return_stmt [5944,5971]
===
match
---
decorator [4563,4632]
decorator [4607,4676]
===
match
---
dotted_name [12395,12417]
dotted_name [12439,12461]
===
match
---
operator: , [11582,11583]
operator: , [11626,11627]
===
match
---
decorator [10303,10328]
decorator [10347,10372]
===
match
---
name: requires_authentication [9157,9180]
name: requires_authentication [9201,9224]
===
match
---
except_clause [8749,8779]
except_clause [8793,8823]
===
match
---
name: jsonify [4430,4437]
name: jsonify [4474,4481]
===
match
---
atom_expr [9921,9941]
atom_expr [9965,9985]
===
match
---
string: 'replace_microseconds' [4028,4050]
string: 'replace_microseconds' [4072,4094]
===
match
---
argument [2074,2079]
argument [2074,2079]
===
match
---
operator: = [3856,3857]
operator: = [3900,3901]
===
match
---
name: get_task_instance [1488,1505]
name: get_task_instance [1488,1505]
===
match
---
string: 'as a date. Example date format: 2015-11-16T14:34:15+00:00' [3632,3691]
string: 'as a date. Example date format: 2015-11-16T14:34:15+00:00' [3676,3735]
===
match
---
operator: , [7810,7811]
operator: , [7854,7855]
===
match
---
expr_stmt [12237,12271]
expr_stmt [12281,12315]
===
match
---
name: status_code [13729,13740]
name: status_code [13773,13784]
===
match
---
decorator [10246,10303]
decorator [10290,10347]
===
match
---
trailer [2376,2384]
trailer [2376,2384]
===
match
---
arglist [11574,11599]
arglist [11618,11643]
===
match
---
suite [6331,6468]
suite [6375,6512]
===
match
---
argument [6818,6832]
argument [6862,6876]
===
match
---
argument [7156,7171]
argument [7200,7215]
===
match
---
simple_stmt [4971,5037]
simple_stmt [5015,5081]
===
match
---
simple_stmt [13170,13358]
simple_stmt [13214,13402]
===
match
---
comparison [2552,2578]
comparison [2596,2622]
===
match
---
operator: = [4993,4994]
operator: = [5037,5038]
===
match
---
name: error_message [3751,3764]
name: error_message [3795,3808]
===
match
---
name: response [2588,2596]
name: response [2632,2640]
===
match
---
trailer [11919,11949]
trailer [11963,11993]
===
match
---
string: 'GET' [12898,12903]
string: 'GET' [12942,12947]
===
match
---
name: log [1740,1743]
name: log [1740,1743]
===
match
---
atom_expr [10653,10666]
atom_expr [10697,10710]
===
match
---
name: response [11436,11444]
name: response [11480,11488]
===
match
---
name: response [2562,2570]
name: response [2606,2614]
===
match
---
argument [12256,12270]
argument [12300,12314]
===
match
---
trailer [12577,12588]
trailer [12621,12632]
===
match
---
atom_expr [13532,13591]
atom_expr [13576,13635]
===
match
---
trailer [8579,8605]
trailer [8623,8649]
===
match
---
name: methods [9139,9146]
name: methods [9183,9190]
===
match
---
fstring [4994,5022]
fstring [5038,5066]
===
match
---
name: dagruns [5750,5757]
name: dagruns [5794,5801]
===
match
---
atom_expr [10120,10143]
atom_expr [10164,10187]
===
match
---
name: dag_id [5555,5561]
name: dag_id [5599,5605]
===
match
---
trailer [3205,3213]
trailer [3249,3257]
===
match
---
fstring_expr [12264,12269]
fstring_expr [12308,12313]
===
match
---
funcdef [2185,2728]
funcdef [2185,2772]
===
match
---
name: err [8877,8880]
name: err [8921,8924]
===
match
---
atom_expr [4838,4852]
atom_expr [4882,4896]
===
match
---
expr_stmt [4904,4942]
expr_stmt [4948,4986]
===
match
---
atom_expr [3563,3714]
atom_expr [3607,3758]
===
match
---
name: headers [2571,2578]
name: headers [2615,2622]
===
match
---
exprlist [6960,6964]
exprlist [7004,7008]
===
match
---
trailer [11536,11544]
trailer [11580,11588]
===
match
---
name: get_lineage_api [1373,1388]
name: get_lineage_api [1373,1388]
===
match
---
name: api [1103,1106]
name: api [1103,1106]
===
match
---
funcdef [4657,5037]
funcdef [4701,5081]
===
match
---
name: methods [12889,12896]
name: methods [12933,12940]
===
match
---
simple_stmt [3741,3766]
simple_stmt [3785,3810]
===
match
---
simple_stmt [11517,11548]
simple_stmt [11561,11592]
===
match
---
simple_stmt [1658,1703]
simple_stmt [1658,1703]
===
match
---
import_as_names [1027,1089]
import_as_names [1027,1089]
===
match
---
expr_stmt [7595,7653]
expr_stmt [7639,7697]
===
match
---
operator: = [12582,12583]
operator: = [12626,12627]
===
match
---
string: 'dag_id' [10643,10651]
string: 'dag_id' [10687,10695]
===
match
---
simple_stmt [13452,13479]
simple_stmt [13496,13523]
===
match
---
funcdef [9181,10244]
funcdef [9225,10288]
===
match
---
name: g [4345,4346]
name: g [4389,4390]
===
match
---
simple_stmt [1531,1579]
simple_stmt [1531,1579]
===
match
---
operator: , [7900,7901]
operator: , [7944,7945]
===
match
---
atom_expr [9009,9026]
atom_expr [9053,9070]
===
match
---
trailer [6980,6986]
trailer [7024,7030]
===
match
---
return_stmt [4545,4560]
return_stmt [4589,4604]
===
match
---
expr_stmt [6936,7014]
expr_stmt [6980,7058]
===
match
---
expr_stmt [8614,8640]
expr_stmt [8658,8684]
===
match
---
name: jsonify [12787,12794]
name: jsonify [12831,12838]
===
match
---
simple_stmt [10199,10215]
simple_stmt [10243,10259]
===
match
---
expr_stmt [6799,6833]
expr_stmt [6843,6877]
===
match
---
name: airflow [1619,1626]
name: airflow [1619,1626]
===
match
---
arglist [7454,7501]
arglist [7498,7545]
===
match
---
if_stmt [10551,11037]
if_stmt [10595,11081]
===
match
---
dotted_name [9058,9080]
dotted_name [9102,9124]
===
match
---
name: err [11459,11462]
name: err [11503,11506]
===
match
---
atom_expr [4487,4516]
atom_expr [4531,4560]
===
match
---
name: data [3975,3979]
name: data [4019,4023]
===
match
---
atom_expr [3835,3855]
atom_expr [3879,3899]
===
match
---
return_stmt [4971,5036]
return_stmt [5015,5080]
===
match
---
name: state [5490,5495]
name: state [5534,5539]
===
match
---
operator: = [8955,8956]
operator: = [8999,9000]
===
match
---
trailer [4095,4155]
trailer [4139,4199]
===
match
---
atom [10621,11022]
atom [10665,11066]
===
match
---
argument [6139,6154]
argument [6183,6198]
===
match
---
simple_stmt [6889,6905]
simple_stmt [6933,6949]
===
match
---
operator: = [4766,4767]
operator: = [4810,4811]
===
match
---
name: err [4187,4190]
name: err [4231,4234]
===
match
---
simple_stmt [11905,11950]
simple_stmt [11949,11994]
===
match
---
arglist [4096,4154]
arglist [4140,4198]
===
match
---
operator: , [4408,4409]
operator: , [4452,4453]
===
match
---
operator: } [5667,5668]
operator: } [5711,5712]
===
match
---
dotted_name [1663,1684]
dotted_name [1663,1684]
===
match
---
suite [9982,10043]
suite [10026,10087]
===
match
---
trailer [6780,6785]
trailer [6824,6829]
===
match
---
string: 'Given execution date, {}, could not be identified ' [8362,8414]
string: 'Given execution date, {}, could not be identified ' [8406,8458]
===
match
---
name: deprecation_link [2474,2490]
name: deprecation_link [2518,2534]
===
match
---
expr_stmt [5490,5523]
expr_stmt [5534,5567]
===
match
---
simple_stmt [1389,1451]
simple_stmt [1389,1451]
===
match
---
atom_expr [6428,6443]
atom_expr [6472,6487]
===
match
---
name: log [11370,11373]
name: log [11414,11417]
===
match
---
name: replace_microseconds [3896,3916]
name: replace_microseconds [3940,3960]
===
match
---
name: response [12237,12245]
name: response [12281,12289]
===
match
---
suite [4751,4794]
suite [4795,4838]
===
match
---
name: execution_date [3442,3456]
name: execution_date [3486,3500]
===
match
---
trailer [3796,3822]
trailer [3840,3866]
===
match
---
operator: , [927,928]
operator: , [927,928]
===
match
---
operator: , [866,867]
operator: , [866,867]
===
match
---
decorators [7084,7198]
decorators [7128,7242]
===
match
---
name: paused [7278,7284]
name: paused [7322,7328]
===
match
---
operator: } [7425,7426]
operator: } [7469,7470]
===
match
---
trailer [13417,13443]
trailer [13461,13487]
===
match
---
simple_stmt [11483,11499]
simple_stmt [11527,11543]
===
match
---
simple_stmt [8528,8553]
simple_stmt [8572,8597]
===
match
---
name: status_code [12726,12737]
name: status_code [12770,12781]
===
match
---
parameters [11639,11641]
parameters [11683,11685]
===
match
---
name: items [8994,8999]
name: items [9038,9043]
===
match
---
fstring_start: f" [4248,4250]
fstring_start: f" [4292,4294]
===
match
---
operator: } [12687,12688]
operator: } [12731,12732]
===
match
---
name: v [6953,6954]
name: v [6997,6998]
===
match
---
operator: , [936,937]
operator: , [936,937]
===
match
---
name: pool [12132,12136]
name: pool [12176,12180]
===
match
---
simple_stmt [3075,3089]
simple_stmt [3119,3133]
===
match
---
name: trigger [1082,1089]
name: trigger [1082,1089]
===
match
---
operator: = [12680,12681]
operator: = [12724,12725]
===
match
---
name: jsonify [6810,6817]
name: jsonify [6854,6861]
===
match
---
name: common [1107,1113]
name: common [1107,1113]
===
match
---
name: response [5636,5644]
name: response [5680,5688]
===
match
---
name: methods [11986,11993]
name: methods [12030,12037]
===
match
---
trailer [13645,13650]
trailer [13689,13694]
===
match
---
operator: = [5104,5105]
operator: = [5148,5149]
===
match
---
funcdef [6181,6468]
funcdef [6225,6512]
===
match
---
fstring_end: " [8843,8844]
fstring_end: " [8887,8888]
===
match
---
expr_stmt [1740,1773]
expr_stmt [1740,1773]
===
match
---
operator: , [924,925]
operator: , [924,925]
===
match
---
operator: = [10133,10134]
operator: = [10177,10178]
===
match
---
name: execution_date [8729,8743]
name: execution_date [8773,8787]
===
match
---
name: k [6960,6961]
name: k [7004,7005]
===
match
---
name: status_code [12289,12300]
name: status_code [12333,12344]
===
match
---
decorator [12906,12931]
decorator [12950,12975]
===
match
---
tfpdef [1870,1881]
tfpdef [1870,1881]
===
match
---
name: dagruns [10534,10541]
name: dagruns [10578,10585]
===
match
---
atom [9655,9826]
atom [9699,9870]
===
match
---
parameters [7877,7910]
parameters [7921,7954]
===
match
---
except_clause [10047,10077]
except_clause [10091,10121]
===
match
---
trailer [5654,5670]
trailer [5698,5714]
===
match
---
string: 'link' [2552,2558]
string: 'link' [2596,2602]
===
match
---
trailer [5622,5627]
trailer [5666,5671]
===
match
---
name: execution_date [3699,3713]
name: execution_date [3743,3757]
===
match
---
trailer [8493,8509]
trailer [8537,8553]
===
match
---
trailer [8531,8537]
trailer [8575,8581]
===
match
---
expr_stmt [12656,12690]
expr_stmt [12700,12734]
===
match
---
name: api_experimental [7431,7447]
name: api_experimental [7475,7491]
===
match
---
name: error [11374,11379]
name: error [11418,11423]
===
match
---
string: 'run_id' [3136,3144]
string: 'run_id' [3180,3188]
===
match
---
operator: = [4247,4248]
operator: = [4291,4292]
===
match
---
trailer [6972,6980]
trailer [7016,7024]
===
match
---
return_stmt [13749,13764]
return_stmt [13793,13808]
===
match
---
atom_expr [12633,12647]
atom_expr [12677,12691]
===
match
---
funcdef [12029,12392]
funcdef [12073,12436]
===
match
---
fstring [12262,12270]
fstring [12306,12314]
===
match
---
name: Response [903,911]
name: Response [903,911]
===
match
---
operator: = [3129,3130]
operator: = [3173,3174]
===
match
---
dotted_name [1584,1597]
dotted_name [1584,1597]
===
match
---
import_from [1152,1231]
import_from [1152,1231]
===
match
---
name: api_experimental [4564,4580]
name: api_experimental [4608,4624]
===
match
---
operator: @ [6470,6471]
operator: @ [6514,6515]
===
match
---
name: err [13687,13690]
name: err [13731,13734]
===
match
---
trailer [4241,4257]
trailer [4285,4301]
===
match
---
atom_expr [13366,13390]
atom_expr [13410,13434]
===
match
---
name: status_code [4293,4304]
name: status_code [4337,4348]
===
match
---
name: bound [1792,1797]
name: bound [1792,1797]
===
match
---
suite [11236,11548]
suite [11280,11592]
===
match
---
name: methods [7156,7163]
name: methods [7200,7207]
===
match
---
trailer [12565,12577]
trailer [12609,12621]
===
match
---
name: err [11847,11850]
name: err [11891,11894]
===
match
---
name: response [3778,3786]
name: response [3822,3830]
===
match
---
suite [12047,12392]
suite [12091,12436]
===
match
---
arglist [13548,13590]
arglist [13592,13634]
===
match
---
operator: { [8838,8839]
operator: { [8882,8883]
===
match
---
number: 400 [9944,9947]
number: 400 [9988,9991]
===
match
---
argument [5915,5926]
argument [5959,5970]
===
match
---
trailer [6287,6295]
trailer [6331,6339]
===
match
---
atom_expr [9039,9054]
atom_expr [9083,9098]
===
match
---
decorators [7702,7855]
decorators [7746,7899]
===
match
---
operator: @ [12394,12395]
operator: @ [12438,12439]
===
match
---
trailer [6715,6732]
trailer [6759,6776]
===
match
---
simple_stmt [3989,4053]
simple_stmt [4033,4097]
===
match
---
string: """Create a pool.""" [12052,12072]
string: """Create a pool.""" [12096,12116]
===
match
---
atom_expr [12086,12114]
atom_expr [12130,12158]
===
match
---
trailer [5505,5510]
trailer [5549,5554]
===
match
---
operator: @ [7173,7174]
operator: @ [7217,7218]
===
match
---
suite [5847,5928]
suite [5891,5972]
===
match
---
simple_stmt [3896,3942]
simple_stmt [3940,3986]
===
match
---
simple_stmt [12214,12229]
simple_stmt [12258,12273]
===
match
---
decorated [6470,7042]
decorated [6514,7086]
===
match
---
fstring_string: >; rel="deprecation"; type="text/html" [2505,2543]
fstring_string: >; rel="deprecation"; type="text/html" [2549,2587]
===
match
---
atom_expr [12787,12810]
atom_expr [12831,12854]
===
match
---
simple_stmt [12780,12811]
simple_stmt [12824,12855]
===
match
---
expr_stmt [2658,2706]
expr_stmt [2702,2750]
===
match
---
name: ValueError [9619,9629]
name: ValueError [9663,9673]
===
match
---
fstring [8836,8844]
fstring [8880,8888]
===
match
---
name: jsonify [12667,12674]
name: jsonify [12711,12718]
===
match
---
simple_stmt [6799,6834]
simple_stmt [6843,6878]
===
match
---
atom_expr [7301,7387]
atom_expr [7345,7431]
===
match
---
string: 'Given execution date, {}, could not be identified ' [3563,3615]
string: 'Given execution date, {}, could not be identified ' [3607,3659]
===
match
---
name: state [5563,5568]
name: state [5607,5612]
===
match
---
atom_expr [5742,5758]
atom_expr [5786,5802]
===
match
---
simple_stmt [7301,7388]
simple_stmt [7345,7432]
===
match
---
trailer [13116,13122]
trailer [13160,13166]
===
match
---
suite [10350,11125]
suite [10394,11169]
===
match
---
name: err [10175,10178]
name: err [10219,10222]
===
match
---
fstring_expr [11808,11813]
fstring_expr [11852,11857]
===
match
---
return_stmt [6452,6467]
return_stmt [6496,6511]
===
match
---
operator: @ [2864,2865]
operator: @ [2908,2909]
===
match
---
decorated [11550,11950]
decorated [11594,11994]
===
match
---
decorator [9156,9181]
decorator [9200,9225]
===
match
---
string: """Decorator for functions that require authentication""" [1888,1945]
string: """Decorator for functions that require authentication""" [1888,1945]
===
match
---
not_test [9005,9026]
not_test [9049,9070]
===
match
---
simple_stmt [7019,7042]
simple_stmt [7063,7086]
===
match
---
string: '/pools' [11976,11984]
string: '/pools' [12020,12028]
===
match
---
parameters [6597,6614]
parameters [6641,6658]
===
match
---
name: err [4848,4851]
name: err [4892,4895]
===
match
---
expr_stmt [11436,11474]
expr_stmt [11480,11518]
===
match
---
atom_expr [11792,11815]
atom_expr [11836,11859]
===
match
---
trailer [1763,1773]
trailer [1763,1773]
===
match
---
fstring_start: f" [4994,4996]
fstring_start: f" [5038,5040]
===
match
---
name: response [12656,12664]
name: response [12700,12708]
===
match
---
trailer [6065,6082]
trailer [6109,6126]
===
match
---
name: dagrun [10524,10530]
name: dagrun [10568,10574]
===
match
---
simple_stmt [13093,13139]
simple_stmt [13137,13183]
===
match
---
operator: { [13418,13419]
operator: { [13462,13463]
===
match
---
decorator [5039,5114]
decorator [5083,5158]
===
match
---
operator: = [9146,9147]
operator: = [9190,9191]
===
match
---
trailer [9793,9800]
trailer [9837,9844]
===
match
---
name: dag_id [10923,10929]
name: dag_id [10967,10973]
===
match
---
string: 'run_id' [3096,3104]
string: 'run_id' [3140,3148]
===
match
---
trailer [8278,8284]
trailer [8322,8328]
===
match
---
argument [12442,12460]
argument [12486,12504]
===
match
---
if_stmt [3167,3214]
if_stmt [3211,3258]
===
match
---
name: err [12224,12227]
name: err [12268,12271]
===
match
---
name: timezone [9577,9585]
name: timezone [9621,9629]
===
match
---
arglist [6716,6731]
arglist [6760,6775]
===
match
---
operator: @ [7503,7504]
operator: @ [7547,7548]
===
match
---
fstring_end: ' [2705,2706]
fstring_end: ' [2749,2750]
===
match
---
atom [8348,8519]
atom [8392,8563]
===
match
---
name: delete [1041,1047]
name: delete [1041,1047]
===
match
---
trailer [7329,7337]
trailer [7373,7381]
===
match
---
name: status_code [8623,8634]
name: status_code [8667,8678]
===
match
---
name: execution_date [9208,9222]
name: execution_date [9252,9266]
===
match
---
name: wraps [824,829]
name: wraps [824,829]
===
match
---
operator: ** [2081,2083]
operator: ** [2081,2083]
===
match
---
try_stmt [13080,13504]
try_stmt [13124,13548]
===
match
---
suite [9551,9608]
suite [9595,9652]
===
match
---
name: requires_authentication [12005,12028]
name: requires_authentication [12049,12072]
===
match
---
dotted_name [2789,2811]
dotted_name [2833,2855]
===
match
---
simple_stmt [3778,3823]
simple_stmt [3822,3867]
===
match
---
operator: , [4400,4401]
operator: , [4444,4445]
===
match
---
import_from [1451,1530]
import_from [1451,1530]
===
match
---
simple_stmt [3194,3214]
simple_stmt [3238,3258]
===
match
---
import_as_name [1049,1065]
import_as_name [1049,1065]
===
match
---
atom_expr [9577,9607]
atom_expr [9621,9651]
===
match
---
string: """Delete pool.""" [12514,12532]
string: """Delete pool.""" [12558,12576]
===
match
---
suite [10078,10215]
suite [10122,10259]
===
match
---
name: logging [1746,1753]
name: logging [1746,1753]
===
match
---
operator: = [5660,5661]
operator: = [5704,5705]
===
match
---
fstring_string: ,  [2618,2620]
fstring_string: ,  [2662,2664]
===
match
---
atom_expr [8961,8967]
atom_expr [9005,9011]
===
match
---
simple_stmt [13522,13592]
simple_stmt [13566,13636]
===
match
---
decorators [5930,6005]
decorators [5974,6049]
===
match
---
operator: = [2683,2684]
operator: = [2727,2728]
===
match
---
operator: = [6371,6372]
operator: = [6415,6416]
===
match
---
atom_expr [2423,2469]
atom_expr [2423,2513]
===
match
---
trailer [11411,11427]
trailer [11455,11471]
===
match
---
parameters [5844,5846]
parameters [5888,5890]
===
match
---
suite [7911,9055]
suite [7955,9099]
===
match
---
name: info [8793,8797]
name: info [8837,8841]
===
match
---
name: response [13495,13503]
name: response [13539,13547]
===
match
---
operator: = [12555,12556]
operator: = [12599,12600]
===
match
---
string: 'Given execution date, {}, could not be identified ' [13200,13252]
string: 'Given execution date, {}, could not be identified ' [13244,13296]
===
match
---
name: execution_dt [13578,13590]
name: execution_dt [13622,13634]
===
match
---
operator: = [8570,8571]
operator: = [8614,8615]
===
match
---
trailer [3750,3765]
trailer [3794,3809]
===
match
---
name: route [5779,5784]
name: route [5823,5828]
===
match
---
operator: = [3543,3544]
operator: = [3587,3588]
===
match
---
name: to_boolean [1692,1702]
name: to_boolean [1692,1702]
===
match
---
name: status_code [4931,4942]
name: status_code [4975,4986]
===
match
---
name: flask [879,884]
name: flask [879,884]
===
match
---
operator: = [9877,9878]
operator: = [9921,9922]
===
match
---
trailer [13547,13591]
trailer [13591,13635]
===
match
---
return_stmt [10199,10214]
return_stmt [10243,10258]
===
match
---
name: DagRun [10452,10458]
name: DagRun [10496,10502]
===
match
---
atom_expr [11532,11546]
atom_expr [11576,11590]
===
match
---
name: utils [1627,1632]
name: utils [1627,1632]
===
match
---
name: dag_id [7546,7552]
name: dag_id [7590,7596]
===
match
---
name: name [12583,12587]
name: name [12627,12631]
===
match
---
atom_expr [13670,13693]
atom_expr [13714,13737]
===
match
---
trailer [11711,11713]
trailer [11755,11757]
===
match
---
funcdef [12931,13807]
funcdef [12975,13851]
===
match
---
atom [4620,4630]
atom [4664,4674]
===
match
---
funcdef [12487,12811]
funcdef [12531,12855]
===
match
---
operator: { [11420,11421]
operator: { [11464,11465]
===
match
---
string: """(Un)pauses a dag""" [7234,7256]
string: """(Un)pauses a dag""" [7278,7300]
===
match
---
trailer [12223,12228]
trailer [12267,12272]
===
match
---
operator: , [8718,8719]
operator: , [8762,8763]
===
match
---
trailer [7008,7013]
trailer [7052,7057]
===
match
---
operator: @ [4632,4633]
operator: @ [4676,4677]
===
match
---
atom_expr [10873,11003]
atom_expr [10917,11047]
===
match
---
name: status_code [4913,4924]
name: status_code [4957,4968]
===
match
---
atom [2854,2862]
atom [2898,2906]
===
match
---
name: response [4223,4231]
name: response [4267,4275]
===
match
---
atom_expr [6949,6955]
atom_expr [6993,6999]
===
match
---
name: airflow [1237,1244]
name: airflow [1237,1244]
===
match
---
expr_stmt [3194,3213]
expr_stmt [3238,3257]
===
match
---
string: 'conf' [3206,3212]
string: 'conf' [3250,3256]
===
match
---
trailer [5687,5699]
trailer [5731,5743]
===
match
---
try_stmt [13509,13807]
try_stmt [13553,13851]
===
match
---
name: jsonify [6373,6380]
name: jsonify [6417,6424]
===
match
---
arglist [4345,4360]
arglist [4389,4404]
===
match
---
name: count [5030,5035]
name: count [5074,5079]
===
match
---
arglist [10906,10981]
arglist [10950,11025]
===
match
---
parameters [11229,11235]
parameters [11273,11279]
===
match
---
string: """Get Lineage details for a DagRun""" [12986,13024]
string: """Get Lineage details for a DagRun""" [13030,13068]
===
match
---
return_stmt [6889,6904]
return_stmt [6933,6948]
===
match
---
simple_stmt [10220,10244]
simple_stmt [10264,10288]
===
match
---
operator: , [6961,6962]
operator: , [7005,7006]
===
match
---
suite [11642,11950]
suite [11686,11994]
===
match
---
parameters [12946,12980]
parameters [12990,13024]
===
match
---
simple_stmt [10109,10144]
simple_stmt [10153,10188]
===
match
---
name: doc_url [2497,2504]
name: doc_url [2541,2548]
===
match
---
except_clause [12593,12623]
except_clause [12637,12667]
===
match
---
name: methods [5097,5104]
name: methods [5141,5148]
===
match
---
argument [11315,11324]
argument [11359,11368]
===
match
---
atom_expr [9879,9912]
atom_expr [9923,9956]
===
match
---
name: response [8614,8622]
name: response [8658,8666]
===
match
---
operator: = [12665,12666]
operator: = [12709,12710]
===
match
---
fstring [4455,4470]
fstring [4499,4514]
===
match
---
trailer [9021,9026]
trailer [9065,9070]
===
match
---
operator: = [5496,5497]
operator: = [5540,5541]
===
match
---
operator: = [10929,10930]
operator: = [10973,10974]
===
match
---
operator: { [2620,2621]
operator: { [2664,2665]
===
match
---
operator: = [3787,3788]
operator: = [3831,3832]
===
match
---
comparison [3277,3311]
comparison [3321,3355]
===
match
---
trailer [11055,11070]
trailer [11099,11114]
===
match
---
name: to_json [12381,12388]
name: to_json [12425,12432]
===
match
---
trailer [7635,7643]
trailer [7679,7687]
===
match
---
suite [12205,12343]
suite [12249,12387]
===
match
---
name: Blueprint [892,901]
name: Blueprint [892,901]
===
match
---
operator: } [9026,9027]
operator: } [9070,9071]
===
match
---
decorator [6470,6559]
decorator [6514,6603]
===
match
---
name: requires_authentication [10304,10327]
name: requires_authentication [10348,10371]
===
match
---
trailer [4504,4514]
trailer [4548,4558]
===
match
---
string: """Delete all DB records related to the specified Dag.""" [4685,4742]
string: """Delete all DB records related to the specified Dag.""" [4729,4786]
===
match
---
trailer [6997,7008]
trailer [7041,7052]
===
match
---
name: requires_authentication [12463,12486]
name: requires_authentication [12507,12530]
===
match
---
simple_stmt [13783,13807]
simple_stmt [13827,13851]
===
match
---
name: route [11145,11150]
name: route [11189,11194]
===
match
---
operator: , [4102,4103]
operator: , [4146,4147]
===
match
---
decorators [4563,4657]
decorators [4607,4701]
===
match
---
operator: = [13683,13684]
operator: = [13727,13728]
===
match
---
operator: = [2400,2401]
operator: = [2400,2401]
===
match
---
operator: = [13184,13185]
operator: = [13228,13229]
===
match
---
operator: = [10293,10294]
operator: = [10337,10338]
===
match
---
trailer [13324,13331]
trailer [13368,13375]
===
match
---
atom_expr [2143,2182]
atom_expr [2143,2182]
===
match
---
simple_stmt [11781,11816]
simple_stmt [11825,11860]
===
match
---
return_stmt [4313,4328]
return_stmt [4357,4372]
===
match
---
expr_stmt [11393,11427]
expr_stmt [11437,11471]
===
match
---
name: name [12503,12507]
name: name [12547,12551]
===
match
---
operator: @ [11127,11128]
operator: @ [11171,11172]
===
match
---
name: error_message [8590,8603]
name: error_message [8634,8647]
===
match
---
simple_stmt [2096,2122]
simple_stmt [2096,2122]
===
match
---
name: response [3835,3843]
name: response [3879,3887]
===
match
---
operator: } [4254,4255]
operator: } [4298,4299]
===
match
---
simple_stmt [1152,1232]
simple_stmt [1152,1232]
===
match
---
decorator [4632,4657]
decorator [4676,4701]
===
match
---
name: trigger_dag [1067,1078]
name: trigger_dag [1067,1078]
===
match
---
name: status_code [10161,10172]
name: status_code [10205,10216]
===
match
---
name: pool_api [11297,11305]
name: pool_api [11341,11349]
===
match
---
decorated [6085,6468]
decorated [6129,6512]
===
match
---
name: log [8789,8792]
name: log [8833,8836]
===
match
---
string: """     Returns a JSON with a dag_run's public instance variables.     The format for the exec_date is expected to be     "YYYY-mm-DDTHH:MM:SS", for example: "2016-11-16T11:34:15". This will     of course need to have been encoded for URL in the request.     """ [9229,9491]
string: """     Returns a JSON with a dag_run's public instance variables.     The format for the exec_date is expected to be     "YYYY-mm-DDTHH:MM:SS", for example: "2016-11-16T11:34:15". This will     of course need to have been encoded for URL in the request.     """ [9273,9535]
===
match
---
operator: = [13668,13669]
operator: = [13712,13713]
===
match
---
name: version [6074,6081]
name: version [6118,6125]
===
match
---
tfpdef [12960,12979]
tfpdef [13004,13023]
===
match
---
argument [6066,6081]
argument [6110,6125]
===
match
---
operator: = [11295,11296]
operator: = [11339,11340]
===
match
---
trailer [7673,7699]
trailer [7717,7743]
===
match
---
atom_expr [12722,12737]
atom_expr [12766,12781]
===
match
---
suite [5160,5759]
suite [5204,5803]
===
match
---
trailer [10880,11003]
trailer [10924,11047]
===
match
---
atom_expr [12214,12228]
atom_expr [12258,12272]
===
match
---
name: err [5623,5626]
name: err [5667,5670]
===
match
---
simple_stmt [8650,8666]
simple_stmt [8694,8710]
===
match
---
atom_expr [8789,8802]
atom_expr [8833,8846]
===
match
---
operator: , [4354,4355]
operator: , [4398,4399]
===
match
---
trailer [13677,13693]
trailer [13721,13737]
===
match
---
trailer [3048,3057]
trailer [3092,3101]
===
match
---
import_from [1579,1613]
import_from [1579,1613]
===
match
---
name: response [8854,8862]
name: response [8898,8906]
===
match
---
name: route [5948,5953]
name: route [5992,5997]
===
match
---
operator: { [9887,9888]
operator: { [9931,9932]
===
match
---
fstring_start: f' [2493,2495]
fstring_start: f' [2537,2539]
===
match
---
expr_stmt [9868,9912]
expr_stmt [9912,9956]
===
match
---
string: 'api_experimental' [2153,2171]
string: 'api_experimental' [2153,2171]
===
match
---
argument [12103,12113]
argument [12147,12157]
===
match
---
operator: = [11319,11320]
operator: = [11363,11364]
===
match
---
arglist [12418,12460]
arglist [12462,12504]
===
match
---
arglist [9081,9154]
arglist [9125,9198]
===
match
---
name: log [13366,13369]
name: log [13410,13413]
===
match
---
name: vars [8980,8984]
name: vars [9024,9028]
===
match
---
import_from [830,872]
import_from [830,872]
===
match
---
argument [4986,5022]
argument [5030,5066]
===
match
---
fstring_end: " [5668,5669]
fstring_end: " [5712,5713]
===
match
---
operator: , [5792,5793]
operator: , [5836,5837]
===
match
---
argument [13678,13692]
argument [13722,13736]
===
match
---
try_stmt [6259,6468]
try_stmt [6303,6512]
===
match
---
operator: @ [5980,5981]
operator: @ [6024,6025]
===
match
---
and_test [3248,3311]
and_test [3292,3355]
===
match
---
string: """     Returns a list of Dag Runs for a specific DAG ID.     :query param state: a query string parameter '?state=queued|running|success...'      :param dag_id: String identifier of a DAG     :return: List of DAG runs of a DAG with requested state,         or all runs if the state is not specified     """ [5165,5472]
string: """     Returns a list of Dag Runs for a specific DAG ID.     :query param state: a query string parameter '?state=queued|running|success...'      :param dag_id: String identifier of a DAG     :return: List of DAG runs of a DAG with requested state,         or all runs if the state is not specified     """ [5209,5516]
===
match
---
argument [4518,4534]
argument [4562,4578]
===
match
---
simple_stmt [12986,13025]
simple_stmt [13030,13069]
===
match
---
string: """Test endpoint to check authentication""" [5852,5895]
string: """Test endpoint to check authentication""" [5896,5939]
===
match
---
atom_expr [10152,10172]
atom_expr [10196,10216]
===
match
---
name: airflow [1394,1401]
name: airflow [1394,1401]
===
match
---
operator: } [13690,13691]
operator: } [13734,13735]
===
match
---
expr_stmt [3151,3162]
expr_stmt [3195,3206]
===
match
---
atom_expr [3131,3145]
atom_expr [3175,3189]
===
match
---
name: is_paused [7595,7604]
name: is_paused [7639,7648]
===
match
---
name: err [8776,8779]
name: err [8820,8823]
===
match
---
atom_expr [13725,13740]
atom_expr [13769,13784]
===
match
---
operator: , [10921,10922]
operator: , [10965,10966]
===
match
---
trailer [7643,7653]
trailer [7687,7697]
===
match
---
atom [13418,13442]
atom [13462,13486]
===
match
---
name: info [6781,6785]
name: info [6825,6829]
===
match
---
try_stmt [3425,3891]
try_stmt [3469,3935]
===
match
---
expr_stmt [13659,13693]
expr_stmt [13703,13737]
===
match
---
suite [8323,8666]
suite [8367,8710]
===
match
---
atom [13186,13357]
atom [13230,13401]
===
match
---
decorators [7430,7528]
decorators [7474,7572]
===
match
---
trailer [10823,10833]
trailer [10867,10877]
===
match
---
simple_stmt [7234,7257]
simple_stmt [7278,7301]
===
match
---
name: request [12086,12093]
name: request [12130,12137]
===
match
---
name: execution_date [3321,3335]
name: execution_date [3365,3379]
===
match
---
name: dr_info [9991,9998]
name: dr_info [10035,10042]
===
match
---
operator: = [12449,12450]
operator: = [12493,12494]
===
match
---
param [6198,6204]
param [6242,6248]
===
match
---
suite [2233,2728]
suite [2233,2772]
===
match
---
atom_expr [7666,7699]
atom_expr [7710,7743]
===
match
---
name: AirflowException [4167,4183]
name: AirflowException [4211,4227]
===
match
---
name: err [6390,6393]
name: err [6434,6437]
===
match
---
decorated [10246,11125]
decorated [10290,11169]
===
match
---
dictorsetmaker [9888,9910]
dictorsetmaker [9932,9954]
===
match
---
simple_stmt [6211,6255]
simple_stmt [6255,6299]
===
match
---
dotted_name [12814,12836]
dotted_name [12858,12880]
===
match
---
name: format [8487,8493]
name: format [8531,8537]
===
match
---
operator: { [6945,6946]
operator: { [6989,6990]
===
match
---
fstring_end: " [6394,6395]
fstring_end: " [6438,6439]
===
match
---
name: delete_pool [12566,12577]
name: delete_pool [12610,12621]
===
match
---
name: k [8972,8973]
name: k [9016,9017]
===
match
---
atom_expr [12280,12300]
atom_expr [12324,12344]
===
match
---
simple_stmt [1232,1302]
simple_stmt [1232,1302]
===
match
---
string: 'error' [3798,3805]
string: 'error' [3842,3849]
===
match
---
operator: = [2421,2422]
operator: = [2421,2422]
===
match
---
funcdef [7528,7700]
funcdef [7572,7744]
===
match
---
string: 'ok' [7421,7425]
string: 'ok' [7465,7469]
===
match
---
string: 'execution_date' [3248,3264]
string: 'execution_date' [3292,3308]
===
match
---
name: err [6786,6789]
name: err [6830,6833]
===
match
---
name: dag_id [4672,4678]
name: dag_id [4716,4722]
===
match
---
decorated [11952,12392]
decorated [11996,12436]
===
match
---
sync_comp_for [8968,9026]
sync_comp_for [9012,9070]
===
match
---
trailer [4489,4504]
trailer [4533,4548]
===
match
---
name: error [10128,10133]
name: error [10172,10177]
===
match
---
name: jsonify [3789,3796]
name: jsonify [3833,3840]
===
match
---
name: ti_info [8985,8992]
name: ti_info [9029,9036]
===
match
---
name: get_task [1442,1450]
name: get_task [1442,1450]
===
match
---
expr_stmt [8561,8605]
expr_stmt [8605,8649]
===
match
---
argument [6381,6395]
argument [6425,6439]
===
match
---
operator: = [8346,8347]
operator: = [8390,8391]
===
match
---
fstring_end: " [12688,12689]
fstring_end: " [12732,12733]
===
match
---
decorator [12394,12462]
decorator [12438,12506]
===
match
---
trailer [2666,2674]
trailer [2710,2718]
===
match
---
argument [10286,10301]
argument [10330,10345]
===
match
---
name: args [2075,2079]
name: args [2075,2079]
===
match
---
trailer [10234,10243]
trailer [10278,10287]
===
match
---
operator: = [6426,6427]
operator: = [6470,6471]
===
match
---
expr_stmt [2474,2544]
expr_stmt [2518,2588]
===
match
---
trailer [4847,4852]
trailer [4891,4896]
===
match
---
decorator [11952,12004]
decorator [11996,12048]
===
match
---
atom_expr [10706,10739]
atom_expr [10750,10783]
===
match
---
trailer [10178,10190]
trailer [10222,10234]
===
match
---
operator: = [3234,3235]
operator: = [3278,3279]
===
match
---
trailer [11922,11930]
trailer [11966,11974]
===
match
---
fstring [6824,6832]
fstring [6868,6876]
===
match
---
name: err [12201,12204]
name: err [12245,12248]
===
match
---
atom [6147,6154]
atom [6191,6198]
===
match
---
name: dagrun [10653,10659]
name: dagrun [10697,10703]
===
match
---
simple_stmt [12514,12533]
simple_stmt [12558,12577]
===
match
---
trailer [10496,10498]
trailer [10540,10542]
===
match
---
name: err [11745,11748]
name: err [11789,11792]
===
match
---
fstring_string: Removed  [4996,5004]
fstring_string: Removed  [5040,5048]
===
match
---
name: requires_authentication [11193,11216]
name: requires_authentication [11237,11260]
===
match
---
atom_expr [13452,13472]
atom_expr [13496,13516]
===
match
---
name: response [5679,5687]
name: response [5723,5731]
===
match
---
trailer [2746,2760]
trailer [2790,2804]
===
match
---
argument [2081,2089]
argument [2081,2089]
===
match
---
trailer [8792,8797]
trailer [8836,8841]
===
match
---
decorator [9057,9156]
decorator [9101,9200]
===
match
---
name: airflow [10430,10437]
name: airflow [10474,10481]
===
match
---
operator: , [10025,10026]
operator: , [10069,10070]
===
match
---
operator: , [8973,8974]
operator: , [9017,9018]
===
match
---
exprlist [8972,8976]
exprlist [9016,9020]
===
match
---
comparison [3170,3184]
comparison [3214,3228]
===
match
---
name: requires_authentication [7504,7527]
name: requires_authentication [7548,7571]
===
match
---
dictorsetmaker [7409,7425]
dictorsetmaker [7453,7469]
===
match
---
operator: } [5010,5011]
operator: } [5054,5055]
===
match
---
name: status_code [6851,6862]
name: status_code [6895,6906]
===
match
---
name: kwargs [2083,2089]
name: kwargs [2083,2089]
===
match
---
name: err [6349,6352]
name: err [6393,6396]
===
match
---
name: response [10206,10214]
name: response [10250,10258]
===
match
---
trailer [4527,4534]
trailer [4571,4578]
===
match
---
name: get_dag_code [6185,6197]
name: get_dag_code [6229,6241]
===
match
---
fstring_expr [6389,6394]
fstring_expr [6433,6438]
===
match
---
operator: } [6393,6394]
operator: } [6437,6438]
===
match
---
name: task_id [6606,6613]
name: task_id [6650,6657]
===
match
---
operator: = [6146,6147]
operator: = [6190,6191]
===
match
---
name: delete_pool [12491,12502]
name: delete_pool [12535,12546]
===
match
---
name: dag_id [9200,9206]
name: dag_id [9244,9250]
===
match
---
atom [5802,5809]
atom [5846,5853]
===
match
---
try_stmt [9547,9973]
try_stmt [9591,10017]
===
match
---
suite [3980,4053]
suite [4024,4097]
===
match
---
funcdef [7198,7428]
funcdef [7242,7472]
===
match
---
fstring_end: ' [2543,2544]
fstring_end: ' [2587,2588]
===
match
---
operator: = [4010,4011]
operator: = [4054,4055]
===
match
---
trailer [5510,5514]
trailer [5554,5558]
===
match
---
decorator [5930,5980]
decorator [5974,6024]
===
match
---
operator: , [5961,5962]
operator: , [6005,6006]
===
match
---
name: log [12214,12217]
name: log [12258,12261]
===
match
---
param [1993,2001]
param [1993,2001]
===
match
---
simple_stmt [8948,9028]
simple_stmt [8992,9072]
===
match
---
trailer [7316,7329]
trailer [7360,7373]
===
match
---
simple_stmt [13636,13651]
simple_stmt [13680,13695]
===
match
---
simple_stmt [13749,13765]
simple_stmt [13793,13809]
===
match
---
arglist [6109,6154]
arglist [6153,6198]
===
match
---
fstring [2493,2544]
fstring [2537,2588]
===
match
---
trailer [12807,12809]
trailer [12851,12853]
===
match
---
simple_stmt [1579,1614]
simple_stmt [1579,1614]
===
match
---
operator: { [6826,6827]
operator: { [6870,6871]
===
match
---
operator: { [11808,11809]
operator: { [11852,11853]
===
match
---
simple_stmt [983,1090]
simple_stmt [983,1090]
===
match
---
name: log [3741,3744]
name: log [3785,3788]
===
match
---
decorator [6156,6181]
decorator [6200,6225]
===
match
---
atom_expr [5647,5670]
atom_expr [5691,5714]
===
match
---
atom_expr [11758,11772]
atom_expr [11802,11816]
===
match
---
name: route [6488,6493]
name: route [6532,6537]
===
match
---
name: error [12218,12223]
name: error [12262,12267]
===
match
---
trailer [10812,10823]
trailer [10856,10867]
===
match
---
fstring [2616,2639]
fstring [2660,2683]
===
match
---
param [4672,4678]
param [4716,4722]
===
match
---
atom_expr [10806,10835]
atom_expr [10850,10879]
===
match
---
decorators [5761,5836]
decorators [5805,5880]
===
match
---
operator: @ [12813,12814]
operator: @ [12857,12858]
===
match
---
trailer [12147,12159]
trailer [12191,12203]
===
match
---
name: response [9921,9929]
name: response [9965,9973]
===
match
---
name: response [8657,8665]
name: response [8701,8709]
===
match
---
atom_expr [6058,6082]
atom_expr [6102,6126]
===
match
---
atom_expr [12376,12390]
atom_expr [12420,12434]
===
match
---
operator: , [6540,6541]
operator: , [6584,6585]
===
match
---
decorator [11192,11217]
decorator [11236,11261]
===
match
---
argument [11056,11069]
argument [11100,11113]
===
match
---
simple_stmt [2658,2707]
simple_stmt [2702,2751]
===
match
---
simple_stmt [3219,3241]
simple_stmt [3263,3285]
===
match
---
simple_stmt [8789,8803]
simple_stmt [8833,8847]
===
match
---
trailer [10737,10739]
trailer [10781,10783]
===
match
---
name: payload [11062,11069]
name: payload [11106,11113]
===
match
---
name: p [11921,11922]
name: p [11965,11966]
===
match
---
atom_expr [6373,6396]
atom_expr [6417,6440]
===
match
---
name: data [3108,3112]
name: data [3152,3156]
===
match
---
string: '/info' [5954,5961]
string: '/info' [5998,6005]
===
match
---
dotted_name [1095,1135]
dotted_name [1095,1135]
===
match
---
return_stmt [5735,5758]
return_stmt [5779,5802]
===
match
---
expr_stmt [6698,6732]
expr_stmt [6742,6776]
===
match
---
name: execution_date [13123,13137]
name: execution_date [13167,13181]
===
match
---
name: data [3180,3184]
name: data [3224,3228]
===
match
---
import_as_names [892,954]
import_as_names [892,954]
===
match
---
dotted_name [1708,1723]
dotted_name [1708,1723]
===
match
---
import_from [983,1089]
import_from [983,1089]
===
match
---
return_stmt [8650,8665]
return_stmt [8694,8709]
===
match
---
trailer [9838,9844]
trailer [9882,9888]
===
match
---
simple_stmt [5614,5628]
simple_stmt [5658,5672]
===
match
---
name: to_json [12800,12807]
name: to_json [12844,12851]
===
match
---
expr_stmt [10152,10190]
expr_stmt [10196,10234]
===
match
---
funcdef [7855,9055]
funcdef [7899,9099]
===
match
---
name: airflow [1095,1102]
name: airflow [1095,1102]
===
match
---
name: err [4210,4213]
name: err [4254,4257]
===
match
---
name: log [6340,6343]
name: log [6384,6387]
===
match
---
expr_stmt [4760,4793]
expr_stmt [4804,4837]
===
match
---
name: dag_paused [7202,7212]
name: dag_paused [7246,7256]
===
match
---
atom_expr [2019,2090]
atom_expr [2019,2090]
===
match
---
simple_stmt [10589,11037]
simple_stmt [10633,11081]
===
match
---
operator: { [7408,7409]
operator: { [7452,7453]
===
match
---
operator: = [13106,13107]
operator: = [13150,13151]
===
match
---
name: function [1958,1966]
name: function [1958,1966]
===
match
---
operator: { [8957,8958]
operator: { [9001,9002]
===
match
---
trailer [10966,10981]
trailer [11010,11025]
===
match
---
simple_stmt [4951,4967]
simple_stmt [4995,5011]
===
match
---
decorator [5761,5811]
decorator [5805,5855]
===
match
---
name: execution_date [10967,10981]
name: execution_date [11011,11025]
===
match
---
name: err [11809,11812]
name: err [11853,11856]
===
match
---
name: get [5511,5514]
name: get [5555,5558]
===
match
---
name: response [6842,6850]
name: response [6886,6894]
===
match
---
name: dag_id [6598,6604]
name: dag_id [6642,6648]
===
match
---
name: route [2806,2811]
name: route [2850,2855]
===
match
---
operator: = [3917,3918]
operator: = [3961,3962]
===
match
---
operator: { [4465,4466]
operator: { [4509,4510]
===
match
---
name: status_code [11833,11844]
name: status_code [11877,11888]
===
match
---
operator: = [13408,13409]
operator: = [13452,13453]
===
match
---
name: common [1468,1474]
name: common [1468,1474]
===
match
---
expr_stmt [8253,8300]
expr_stmt [8297,8344]
===
match
---
expr_stmt [11781,11815]
expr_stmt [11825,11859]
===
match
---
simple_stmt [7595,7654]
simple_stmt [7639,7698]
===
match
---
trailer [12794,12810]
trailer [12838,12854]
===
match
---
trailer [5749,5758]
trailer [5793,5802]
===
match
---
suite [12624,12762]
suite [12668,12806]
===
match
---
atom_expr [5498,5523]
atom_expr [5542,5567]
===
match
---
trailer [8829,8845]
trailer [8873,8889]
===
match
---
return_stmt [7019,7041]
return_stmt [7063,7085]
===
match
---
string: """Returns the latest DagRun for each DAG formatted for the UI""" [10355,10420]
string: """Returns the latest DagRun for each DAG formatted for the UI""" [10399,10464]
===
match
---
name: parse [8279,8284]
name: parse [8323,8328]
===
match
---
return_stmt [6051,6082]
return_stmt [6095,6126]
===
match
---
name: data [3201,3205]
name: data [3245,3249]
===
match
---
expr_stmt [3989,4052]
expr_stmt [4033,4096]
===
match
---
operator: = [8875,8876]
operator: = [8919,8920]
===
match
---
fstring [12681,12689]
fstring [12725,12733]
===
match
---
name: api_experimental [6086,6102]
name: api_experimental [6130,6146]
===
match
---
simple_stmt [8854,8893]
simple_stmt [8898,8937]
===
match
---
name: jsonify [11912,11919]
name: jsonify [11956,11963]
===
match
---
fstring [4248,4256]
fstring [4292,4300]
===
match
---
operator: = [12246,12247]
operator: = [12290,12291]
===
match
---
name: api_experimental [10247,10263]
name: api_experimental [10291,10307]
===
match
---
expr_stmt [11685,11713]
expr_stmt [11729,11757]
===
match
---
name: Callable [1798,1806]
name: Callable [1798,1806]
===
match
---
simple_stmt [8684,8745]
simple_stmt [8728,8789]
===
match
---
fstring_start: f' [2685,2687]
fstring_start: f' [2729,2731]
===
match
---
operator: , [12440,12441]
operator: , [12484,12485]
===
match
---
name: execution_date [3919,3933]
name: execution_date [3963,3977]
===
match
---
trailer [6868,6880]
trailer [6912,6924]
===
match
---
argument [11412,11426]
argument [11456,11470]
===
match
---
arglist [4986,5035]
arglist [5030,5079]
===
match
---
argument [10128,10142]
argument [10172,10186]
===
match
---
name: execution_date [13563,13577]
name: execution_date [13607,13621]
===
match
---
sync_comp_for [11933,11947]
sync_comp_for [11977,11991]
===
match
---
atom_expr [2368,2399]
atom_expr [2368,2399]
===
match
---
name: dagrun [10777,10783]
name: dagrun [10821,10827]
===
match
---
string: 'start_date' [10761,10773]
string: 'start_date' [10805,10817]
===
match
---
operator: = [8268,8269]
operator: = [8312,8313]
===
match
---
simple_stmt [11647,11668]
simple_stmt [11691,11712]
===
match
---
name: k [6996,6997]
name: k [7040,7041]
===
match
---
name: experimental [1326,1338]
name: experimental [1326,1338]
===
match
---
argument [5794,5809]
argument [5838,5853]
===
match
---
atom_expr [11912,11949]
atom_expr [11956,11993]
===
match
---
simple_stmt [10425,10459]
simple_stmt [10469,10503]
===
match
---
name: jsonify [12248,12255]
name: jsonify [12292,12299]
===
match
---
name: Response [2223,2231]
name: Response [2223,2231]
===
match
---
argument [12578,12587]
argument [12622,12631]
===
match
---
decorators [12813,12931]
decorators [12857,12975]
===
match
---
argument [10945,10981]
argument [10989,11025]
===
match
---
simple_stmt [12132,12170]
simple_stmt [12176,12214]
===
match
---
name: force [3058,3063]
name: force [3102,3107]
===
match
---
import_from [874,954]
import_from [874,954]
===
match
---
expr_stmt [9921,9947]
expr_stmt [9965,9991]
===
match
---
operator: , [7884,7885]
operator: , [7928,7929]
===
match
---
operator: = [11790,11791]
operator: = [11834,11835]
===
match
---
suite [10542,11037]
suite [10586,11081]
===
match
---
parameters [7212,7228]
parameters [7256,7272]
===
match
---
name: status_code [13711,13722]
name: status_code [13755,13766]
===
match
---
trailer [2073,2090]
trailer [2073,2090]
===
match
---
operator: } [11424,11425]
operator: } [11468,11469]
===
match
---
try_stmt [6685,6905]
try_stmt [6729,6949]
===
match
---
trailer [10936,10943]
trailer [10980,10987]
===
match
---
decorated [4563,5037]
decorated [4607,5081]
===
match
---
name: api_experimental [12395,12411]
name: api_experimental [12439,12455]
===
match
---
atom_expr [4927,4942]
atom_expr [4971,4986]
===
match
---
atom [10294,10301]
atom [10338,10345]
===
match
---
trailer [11373,11379]
trailer [11417,11423]
===
match
---
trailer [4879,4895]
trailer [4923,4939]
===
match
---
name: response [4958,4966]
name: response [5002,5010]
===
match
---
name: error [13678,13683]
name: error [13722,13727]
===
match
---
except_clause [4160,4190]
except_clause [4204,4234]
===
match
---
operator: @ [11192,11193]
operator: @ [11236,11237]
===
match
---
string: """     Trigger a new dag run for a Dag with an execution date of now unless     specified in the data.     """ [2918,3029]
string: """     Trigger a new dag run for a Dag with an execution date of now unless     specified in the data.     """ [2962,3073]
===
match
---
suite [6689,6733]
suite [6733,6777]
===
match
---
name: v [6963,6964]
name: v [7007,7008]
===
match
---
string: 'as a date. Example date format: 2015-11-16T14:34:15+00:00' [8427,8486]
string: 'as a date. Example date format: 2015-11-16T14:34:15+00:00' [8471,8530]
===
match
---
name: pool [12376,12380]
name: pool [12420,12424]
===
match
---
name: jsonify [6058,6065]
name: jsonify [6102,6109]
===
match
---
name: isoformat [4505,4514]
name: isoformat [4549,4558]
===
match
---
trailer [4209,4214]
trailer [4253,4258]
===
match
---
name: response [6799,6807]
name: response [6843,6851]
===
match
---
try_stmt [8240,8666]
try_stmt [8284,8710]
===
match
---
simple_stmt [13488,13504]
simple_stmt [13532,13548]
===
match
---
name: error [8830,8835]
name: error [8874,8879]
===
match
---
expr_stmt [4223,4257]
expr_stmt [4267,4301]
===
match
---
for_stmt [10520,11037]
for_stmt [10564,11081]
===
match
---
atom_expr [12795,12809]
atom_expr [12839,12853]
===
match
---
suite [3185,3214]
suite [3229,3258]
===
match
---
simple_stmt [11290,11326]
simple_stmt [11334,11370]
===
match
---
expr_stmt [4266,4304]
expr_stmt [4310,4348]
===
match
---
except_clause [5574,5604]
except_clause [5618,5648]
===
match
---
name: airflow [1536,1543]
name: airflow [1536,1543]
===
match
---
operator: , [1991,1992]
operator: , [1991,1992]
===
match
---
name: get_dag_run_state [1214,1231]
name: get_dag_run_state [1214,1231]
===
match
---
atom_expr [11048,11070]
atom_expr [11092,11114]
===
match
---
name: function [2064,2072]
name: function [2064,2072]
===
match
---
atom_expr [4289,4304]
atom_expr [4333,4348]
===
match
---
name: deprecation_link [2688,2704]
name: deprecation_link [2732,2748]
===
match
---
argument [5097,5112]
argument [5141,5156]
===
match
---
operator: = [9942,9943]
operator: = [9986,9987]
===
match
---
atom_expr [8572,8605]
atom_expr [8616,8649]
===
match
---
atom_expr [7400,7427]
atom_expr [7444,7471]
===
match
---
suite [8675,8745]
suite [8719,8789]
===
match
---
name: dagrun [10554,10560]
name: dagrun [10598,10604]
===
match
---
name: response [10109,10117]
name: response [10153,10161]
===
match
---
dotted_name [5040,5062]
dotted_name [5084,5106]
===
match
---
trailer [13728,13740]
trailer [13772,13784]
===
match
---
name: response [8561,8569]
name: response [8605,8613]
===
match
---
name: ti_info [8684,8691]
name: ti_info [8728,8735]
===
match
---
param [12960,12979]
param [13004,13023]
===
match
---
atom_expr [4904,4924]
atom_expr [4948,4968]
===
match
---
suite [7554,7700]
suite [7598,7744]
===
match
---
arglist [10270,10301]
arglist [10314,10345]
===
match
---
name: common [1249,1255]
name: common [1249,1255]
===
match
---
name: run_id [3122,3128]
name: run_id [3166,3172]
===
match
---
name: methods [7812,7819]
name: methods [7856,7863]
===
match
---
and_test [10776,10835]
and_test [10820,10879]
===
match
---
name: delete_dag [4661,4671]
name: delete_dag [4705,4715]
===
match
---
name: err [12265,12268]
name: err [12309,12312]
===
match
---
tfpdef [2213,2231]
tfpdef [2213,2231]
===
match
---
argument [11584,11599]
argument [11628,11643]
===
match
---
atom_expr [9669,9816]
atom_expr [9713,9860]
===
match
---
name: start_date [10813,10823]
name: start_date [10857,10867]
===
match
---
fstring_end: " [5021,5022]
fstring_end: " [5065,5066]
===
match
---
name: route [7448,7453]
name: route [7492,7497]
===
match
---
name: response [8811,8819]
name: response [8855,8863]
===
match
---
name: execution_date [12960,12974]
name: execution_date [13004,13018]
===
match
---
dotted_name [11128,11150]
dotted_name [11172,11194]
===
match
---
fstring_expr [2620,2638]
fstring_expr [2664,2682]
===
match
---
number: 400 [3858,3861]
number: 400 [3902,3905]
===
match
---
name: execution_dt [13093,13105]
name: execution_dt [13137,13149]
===
match
---
name: error [11762,11767]
name: error [11806,11811]
===
match
---
name: dag_runs [5143,5151]
name: dag_runs [5187,5195]
===
match
---
name: startswith [9011,9021]
name: startswith [9055,9065]
===
match
---
name: DagModel [7308,7316]
name: DagModel [7352,7360]
===
match
---
operator: = [8835,8836]
operator: = [8879,8880]
===
match
---
operator: { [5004,5005]
operator: { [5048,5049]
===
match
---
import_from [802,829]
import_from [802,829]
===
match
---
argument [13563,13590]
argument [13607,13634]
===
match
---
simple_stmt [2413,2470]
simple_stmt [2413,2514]
===
match
---
return_stmt [12361,12391]
return_stmt [12405,12435]
===
match
---
suite [6206,6468]
suite [6250,6512]
===
match
---
param [5152,5158]
param [5196,5202]
===
match
---
fstring_expr [13686,13691]
fstring_expr [13730,13735]
===
match
---
atom_expr [3277,3299]
atom_expr [3321,3343]
===
match
---
name: delete [4768,4774]
name: delete [4812,4818]
===
match
---
simple_stmt [7659,7700]
simple_stmt [7703,7744]
===
match
---
suite [13084,13139]
suite [13128,13183]
===
match
---
arglist [2153,2181]
arglist [2153,2181]
===
match
---
return_stmt [11517,11547]
return_stmt [11561,11591]
===
match
---
trailer [4785,4793]
trailer [4829,4837]
===
match
---
atom_expr [11824,11844]
atom_expr [11868,11888]
===
match
---
trailer [2039,2063]
trailer [2039,2063]
===
match
---
trailer [12306,12318]
trailer [12350,12362]
===
match
---
operator: } [7013,7014]
operator: } [7057,7058]
===
match
---
name: AirflowException [4805,4821]
name: AirflowException [4849,4865]
===
match
---
name: log [4838,4841]
name: log [4882,4885]
===
match
---
trailer [8797,8802]
trailer [8841,8846]
===
match
---
name: requires_authentication [11602,11625]
name: requires_authentication [11646,11669]
===
match
---
suite [4680,5037]
suite [4724,5081]
===
match
---
name: dr_info [10235,10242]
name: dr_info [10279,10286]
===
match
---
name: err [4889,4892]
name: err [4933,4936]
===
match
---
name: get_dag_run_state [1189,1206]
name: get_dag_run_state [1189,1206]
===
match
---
number: 400 [13475,13478]
number: 400 [13519,13522]
===
match
---
expr_stmt [6842,6880]
expr_stmt [6886,6924]
===
match
---
name: get_pool [11221,11229]
name: get_pool [11265,11273]
===
match
---
name: response [13452,13460]
name: response [13496,13504]
===
match
---
name: error [4204,4209]
name: error [4248,4253]
===
match
---
trailer [13369,13375]
trailer [13413,13419]
===
match
---
simple_stmt [10087,10101]
simple_stmt [10131,10145]
===
match
---
name: methods [2846,2853]
name: methods [2890,2897]
===
match
---
fstring_expr [4888,4893]
fstring_expr [4932,4937]
===
match
---
decorator [6085,6156]
decorator [6129,6200]
===
match
---
expr_stmt [2368,2408]
expr_stmt [2368,2408]
===
match
---
simple_stmt [1090,1152]
simple_stmt [1090,1152]
===
match
---
name: models [7301,7307]
name: models [7345,7351]
===
match
---
operator: = [4074,4075]
operator: = [4118,4119]
===
match
---
operator: = [6943,6944]
operator: = [6987,6988]
===
match
---
name: error_message [8332,8345]
name: error_message [8376,8389]
===
match
---
expr_stmt [2413,2469]
expr_stmt [2413,2513]
===
match
---
operator: , [945,946]
operator: , [945,946]
===
match
---
name: payload [10503,10510]
name: payload [10547,10554]
===
match
---
argument [10923,10943]
argument [10967,10987]
===
match
---
name: requires_authentication [7831,7854]
name: requires_authentication [7875,7898]
===
match
---
name: v [8975,8976]
name: v [9019,9020]
===
match
---
name: err [6327,6330]
name: err [6371,6374]
===
match
---
name: dagrun [10706,10712]
name: dagrun [10750,10756]
===
match
---
expr_stmt [5679,5705]
expr_stmt [5723,5749]
===
match
---
atom [7408,7426]
atom [7452,7470]
===
match
---
atom_expr [12368,12391]
atom_expr [12412,12435]
===
match
---
argument [3058,3068]
argument [3102,3112]
===
match
---
trailer [6785,6790]
trailer [6829,6834]
===
match
---
name: status_code [13461,13472]
name: status_code [13505,13516]
===
match
---
name: strings [1677,1684]
name: strings [1677,1684]
===
match
---
name: err [10074,10077]
name: err [10118,10121]
===
match
---
trailer [8999,9001]
trailer [9043,9045]
===
match
---
name: headers [2597,2604]
name: headers [2641,2648]
===
match
---
arglist [10019,10041]
arglist [10063,10085]
===
match
---
decorator [11127,11192]
decorator [11171,11236]
===
match
---
name: response [2719,2727]
name: response [2763,2771]
===
match
---
dotted_name [988,1019]
dotted_name [988,1019]
===
match
---
argument [4447,4470]
argument [4491,4514]
===
match
---
decorated [12394,12811]
decorated [12438,12855]
===
match
---
trailer [2604,2612]
trailer [2648,2656]
===
match
---
string: """Return python code of a given dag_id.""" [6211,6254]
string: """Return python code of a given dag_id.""" [6255,6298]
===
match
---
name: error [13640,13645]
name: error [13684,13689]
===
match
---
name: conf [3151,3155]
name: conf [3195,3199]
===
match
---
name: common [1319,1325]
name: common [1319,1325]
===
match
---
operator: { [13686,13687]
operator: { [13730,13731]
===
match
---
comparison [3248,3272]
comparison [3292,3316]
===
match
---
operator: = [3336,3337]
operator: = [3380,3381]
===
match
---
atom_expr [10087,10100]
atom_expr [10131,10144]
===
match
---
trailer [6413,6425]
trailer [6457,6469]
===
match
---
name: get_dag_runs [5542,5554]
name: get_dag_runs [5586,5598]
===
match
---
fstring_start: f' [2616,2618]
fstring_start: f' [2660,2662]
===
match
---
trailer [4403,4408]
trailer [4447,4452]
===
match
---
decorator [7503,7528]
decorator [7547,7572]
===
match
---
name: response [13659,13667]
name: response [13703,13711]
===
match
---
arglist [11151,11190]
arglist [11195,11234]
===
match
---
expr_stmt [6362,6396]
expr_stmt [6406,6440]
===
match
---
name: get_docs_url [1645,1657]
name: get_docs_url [1645,1657]
===
match
---
name: status_code [9930,9941]
name: status_code [9974,9985]
===
match
---
expr_stmt [13093,13138]
expr_stmt [13137,13182]
===
match
---
argument [5655,5669]
argument [5699,5713]
===
match
---
name: route [10264,10269]
name: route [10308,10313]
===
match
---
funcdef [1842,2122]
funcdef [1842,2122]
===
match
---
name: methods [11175,11182]
name: methods [11219,11226]
===
match
---
parameters [2904,2912]
parameters [2948,2956]
===
match
---
expr_stmt [3075,3088]
expr_stmt [3119,3132]
===
match
---
name: log [9835,9838]
name: log [9879,9882]
===
match
---
operator: = [13554,13555]
operator: = [13598,13599]
===
match
---
trailer [10727,10737]
trailer [10771,10781]
===
match
---
name: response [4320,4328]
name: response [4364,4372]
===
match
---
suite [6768,6905]
suite [6812,6949]
===
match
---
simple_stmt [12633,12648]
simple_stmt [12677,12692]
===
match
---
trailer [13639,13645]
trailer [13683,13689]
===
match
---
string: 'GET' [9148,9153]
string: 'GET' [9192,9197]
===
match
---
name: err [8839,8842]
name: err [8883,8886]
===
match
---
name: get_latest_runs [10481,10496]
name: get_latest_runs [10525,10540]
===
match
---
name: err [4289,4292]
name: err [4333,4336]
===
match
---
name: api_experimental [11953,11969]
name: api_experimental [11997,12013]
===
match
---
name: response [4904,4912]
name: response [4948,4956]
===
match
---
fstring_expr [4465,4469]
fstring_expr [4509,4513]
===
match
---
name: t_info [6973,6979]
name: t_info [7017,7023]
===
match
---
arglist [2812,2862]
arglist [2856,2906]
===
match
---
name: doc_url [2413,2420]
name: doc_url [2413,2420]
===
match
---
name: __name__ [1764,1772]
name: __name__ [1764,1772]
===
match
---
arglist [2074,2089]
arglist [2074,2089]
===
match
---
name: dr [4410,4412]
name: dr [4454,4456]
===
match
---
name: execution_date [10027,10041]
name: execution_date [10071,10085]
===
match
---
trailer [6850,6862]
trailer [6894,6906]
===
match
---
argument [12160,12168]
argument [12204,12212]
===
match
---
atom_expr [4768,4793]
atom_expr [4812,4837]
===
match
---
import_from [10425,10458]
import_from [10469,10502]
===
match
---
import_from [1302,1388]
import_from [1302,1388]
===
match
---
simple_stmt [1614,1658]
simple_stmt [1614,1658]
===
match
---
dictorsetmaker [13419,13441]
dictorsetmaker [13463,13485]
===
match
---
name: models [976,982]
name: models [976,982]
===
match
---
name: error_message [13170,13183]
name: error_message [13214,13227]
===
match
---
atom_expr [3741,3765]
atom_expr [3785,3809]
===
match
---
operator: = [6808,6809]
operator: = [6852,6853]
===
match
---
trailer [8537,8552]
trailer [8581,8596]
===
match
---
operator: , [6137,6138]
operator: , [6181,6182]
===
match
---
simple_stmt [5636,5671]
simple_stmt [5680,5715]
===
match
---
name: jsonify [8822,8829]
name: jsonify [8866,8873]
===
match
---
expr_stmt [12550,12588]
expr_stmt [12594,12632]
===
match
---
name: response [12699,12707]
name: response [12743,12751]
===
match
---
comparison [3949,3979]
comparison [3993,4023]
===
match
---
name: response [4266,4274]
name: response [4310,4318]
===
match
---
name: AirflowException [5581,5597]
name: AirflowException [5625,5641]
===
match
---
operator: @ [9057,9058]
operator: @ [9101,9102]
===
match
---
name: status_code [4275,4286]
name: status_code [4319,4330]
===
match
---
name: get_dagmodel [7623,7635]
name: get_dagmodel [7667,7679]
===
match
---
decorated [7702,9055]
decorated [7746,9099]
===
match
---
decorated [5761,5928]
decorated [5805,5972]
===
match
---
operator: @ [12004,12005]
operator: @ [12048,12049]
===
match
---
atom_expr [13108,13138]
atom_expr [13152,13182]
===
match
---
name: data [3034,3038]
name: data [3078,3082]
===
match
---
atom_expr [11436,11456]
atom_expr [11480,11500]
===
match
---
if_stmt [3946,4053]
if_stmt [3990,4097]
===
match
---
operator: { [3797,3798]
operator: { [3841,3842]
===
match
---
name: api [1464,1467]
name: api [1464,1467]
===
match
---
string: '/dags/<string:dag_id>/dag_runs/<string:execution_date>/tasks/<string:task_id>' [7731,7810]
string: '/dags/<string:dag_id>/dag_runs/<string:execution_date>/tasks/<string:task_id>' [7775,7854]
===
match
---
name: typing [835,841]
name: typing [835,841]
===
match
---
operator: , [1065,1066]
operator: , [1065,1066]
===
match
---
number: 400 [8637,8640]
number: 400 [8681,8684]
===
match
---
argument [4612,4630]
argument [4656,4674]
===
match
---
name: get_pools [11630,11639]
name: get_pools [11674,11683]
===
match
---
name: count [4760,4765]
name: count [4804,4809]
===
match
---
name: create_pool [12148,12159]
name: create_pool [12192,12203]
===
match
---
dotted_name [1394,1434]
dotted_name [1394,1434]
===
match
---
operator: @ [6156,6157]
operator: @ [6200,6201]
===
match
---
if_stmt [3093,3146]
if_stmt [3137,3190]
===
match
---
name: api_auth [2031,2039]
name: api_auth [2031,2039]
===
match
---
name: AirflowException [6307,6323]
name: AirflowException [6351,6367]
===
match
---
atom [9887,9911]
atom [9931,9955]
===
match
---
name: vars [6968,6972]
name: vars [7012,7016]
===
match
---
suite [13161,13504]
suite [13205,13548]
===
match
---
operator: , [7219,7220]
operator: , [7263,7264]
===
match
---
name: jsonify [5907,5914]
name: jsonify [5951,5958]
===
match
---
operator: = [4486,4487]
operator: = [4530,4531]
===
match
---
simple_stmt [6698,6733]
simple_stmt [6742,6777]
===
match
---
import_from [1531,1578]
import_from [1531,1578]
===
match
---
name: status_code [6414,6425]
name: status_code [6458,6469]
===
match
---
suite [7229,7428]
suite [7273,7472]
===
match
---
comparison [7278,7294]
comparison [7322,7338]
===
match
---
decorated [7430,7700]
decorated [7474,7744]
===
match
---
dotted_name [5762,5784]
dotted_name [5806,5828]
===
match
---
name: wraps [1952,1957]
name: wraps [1952,1957]
===
match
---
param [11230,11234]
param [11274,11278]
===
match
---
operator: = [11457,11458]
operator: = [11501,11502]
===
match
---
suite [11508,11548]
suite [11552,11592]
===
match
---
simple_stmt [12699,12738]
simple_stmt [12743,12782]
===
match
---
name: function [1870,1878]
name: function [1870,1878]
===
match
---
trailer [11701,11711]
trailer [11745,11755]
===
match
---
simple_stmt [5852,5896]
simple_stmt [5896,5940]
===
match
---
name: AirflowException [12181,12197]
name: AirflowException [12225,12241]
===
match
---
return_stmt [11041,11070]
return_stmt [11085,11114]
===
match
---
atom_expr [8854,8874]
atom_expr [8898,8918]
===
match
---
simple_stmt [13366,13391]
simple_stmt [13410,13435]
===
match
---
atom [12450,12460]
atom [12494,12504]
===
match
---
except_clause [6300,6330]
except_clause [6344,6374]
===
match
---
operator: @ [7830,7831]
operator: @ [7874,7875]
===
match
---
expr_stmt [7261,7295]
expr_stmt [7305,7339]
===
match
---
simple_stmt [6405,6444]
simple_stmt [6449,6488]
===
match
---
except_clause [13596,13626]
except_clause [13640,13670]
===
match
---
name: request [5498,5505]
name: request [5542,5549]
===
match
---
trailer [10783,10794]
trailer [10827,10838]
===
match
---
atom [6945,7014]
atom [6989,7058]
===
match
---
trailer [9844,9859]
trailer [9888,9903]
===
match
---
name: airflow [1456,1463]
name: airflow [1456,1463]
===
match
---
operator: = [5029,5030]
operator: = [5073,5074]
===
match
---
atom [10775,10836]
atom [10819,10880]
===
match
---
simple_stmt [7393,7428]
simple_stmt [7437,7472]
===
match
---
simple_stmt [1888,1946]
simple_stmt [1888,1946]
===
match
---
trailer [12799,12807]
trailer [12843,12851]
===
match
---
trailer [9886,9912]
trailer [9930,9956]
===
match
---
dictorsetmaker [10643,11004]
dictorsetmaker [10687,11048]
===
match
---
trailer [4027,4051]
trailer [4071,4095]
===
match
---
name: err [5664,5667]
name: err [5708,5711]
===
match
---
arglist [7361,7381]
arglist [7405,7425]
===
match
---
name: headers [2377,2384]
name: headers [2377,2384]
===
match
---
simple_stmt [2368,2409]
simple_stmt [2368,2409]
===
match
---
string: 'GET' [6148,6153]
string: 'GET' [6192,6197]
===
match
---
name: route [7102,7107]
name: route [7146,7151]
===
match
---
name: status_code [3844,3855]
name: status_code [3888,3899]
===
match
---
name: error_message [9845,9858]
name: error_message [9889,9902]
===
match
---
fstring_start: f" [6824,6826]
fstring_start: f" [6868,6870]
===
match
---
operator: , [10739,10740]
operator: , [10783,10784]
===
match
---
operator: = [11845,11846]
operator: = [11889,11890]
===
match
---
name: methods [10286,10293]
name: methods [10330,10337]
===
match
---
name: get_task_instance [1513,1530]
name: get_task_instance [1513,1530]
===
match
---
string: """Get all pools.""" [11647,11667]
string: """Get all pools.""" [11691,11711]
===
match
---
operator: , [10943,10944]
operator: , [10987,10988]
===
match
---
simple_stmt [5735,5759]
simple_stmt [5779,5803]
===
match
---
decorator [12462,12487]
decorator [12506,12531]
===
match
---
simple_stmt [2474,2545]
simple_stmt [2518,2589]
===
match
---
trailer [4374,4379]
trailer [4418,4423]
===
match
---
operator: , [911,912]
operator: , [911,912]
===
match
---
name: response [6896,6904]
name: response [6940,6948]
===
match
---
operator: , [2109,2110]
operator: , [2109,2110]
===
match
---
trailer [12380,12388]
trailer [12424,12432]
===
match
---
string: "User %s created %s" [4380,4400]
string: "User %s created %s" [4424,4444]
===
match
---
param [7886,7901]
param [7930,7945]
===
match
---
name: common [1000,1006]
name: common [1000,1006]
===
match
---
dotted_name [11551,11573]
dotted_name [11595,11617]
===
match
---
trailer [4274,4286]
trailer [4318,4330]
===
match
---
simple_stmt [6936,7015]
simple_stmt [6980,7059]
===
match
---
decorator [5811,5836]
decorator [5855,5880]
===
match
---
fstring_start: f" [10134,10136]
fstring_start: f" [10178,10180]
===
match
---
decorator [2864,2889]
decorator [2908,2933]
===
match
---
name: status_code [6432,6443]
name: status_code [6476,6487]
===
match
---
trailer [8880,8892]
trailer [8924,8936]
===
match
---
name: dagrun [10806,10812]
name: dagrun [10850,10856]
===
match
---
operator: , [4116,4117]
operator: , [4160,4161]
===
match
---
name: getattr [4337,4344]
name: getattr [4381,4388]
===
match
---
atom_expr [10175,10190]
atom_expr [10219,10234]
===
match
---
name: get_code [1127,1135]
name: get_code [1127,1135]
===
match
---
name: response [11781,11789]
name: response [11825,11833]
===
match
---
name: api_experimental [6471,6487]
name: api_experimental [6515,6531]
===
match
---
simple_stmt [12327,12343]
simple_stmt [12371,12387]
===
match
---
name: status_code [8881,8892]
name: status_code [8925,8936]
===
match
---
decorators [12394,12487]
decorators [12438,12531]
===
match
---
name: err [8798,8801]
name: err [8842,8845]
===
match
---
name: pool_api [11693,11701]
name: pool_api [11737,11745]
===
match
---
operator: = [10511,10512]
operator: = [10555,10556]
===
match
---
expr_stmt [11824,11862]
expr_stmt [11868,11906]
===
match
---
expr_stmt [13522,13591]
expr_stmt [13566,13635]
===
match
---
trailer [13375,13390]
trailer [13419,13434]
===
match
---
suite [13513,13592]
suite [13557,13636]
===
match
---
string: 'POST' [2855,2861]
string: 'POST' [2899,2905]
===
match
---
return_stmt [2096,2121]
return_stmt [2096,2121]
===
match
---
name: status_code [5688,5699]
name: status_code [5732,5743]
===
match
---
atom_expr [4525,4534]
atom_expr [4569,4578]
===
match
---
operator: = [6549,6550]
operator: = [6593,6594]
===
match
---
string: 'GET' [5972,5977]
string: 'GET' [6016,6021]
===
match
---
name: k [6946,6947]
name: k [6990,6991]
===
match
---
operator: } [8842,8843]
operator: } [8886,8887]
===
match
---
simple_stmt [3122,3146]
simple_stmt [3166,3190]
===
match
---
return_stmt [5714,5729]
return_stmt [5758,5773]
===
match
---
name: lineage [13522,13529]
name: lineage [13566,13573]
===
match
---
trailer [4437,4540]
trailer [4481,4584]
===
match
---
fstring_start: f" [11806,11808]
fstring_start: f" [11850,11852]
===
match
---
import_from [1232,1301]
import_from [1232,1301]
===
match
---
trailer [12093,12102]
trailer [12137,12146]
===
match
---
name: err [11380,11383]
name: err [11424,11427]
===
match
---
operator: = [10173,10174]
operator: = [10217,10218]
===
match
---
trailer [6348,6353]
trailer [6392,6397]
===
match
---
atom_expr [7273,7295]
atom_expr [7317,7339]
===
match
---
name: get_docs_url [2423,2435]
name: get_docs_url [2423,2435]
===
match
---
name: err [12620,12623]
name: err [12664,12667]
===
match
---
name: airflow [1157,1164]
name: airflow [1157,1164]
===
match
---
atom [10513,10515]
atom [10557,10559]
===
match
---
try_stmt [5477,5730]
try_stmt [5521,5774]
===
match
---
simple_stmt [3835,3862]
simple_stmt [3879,3906]
===
match
---
name: experimental [1007,1019]
name: experimental [1007,1019]
===
match
---
name: err [10096,10099]
name: err [10140,10143]
===
match
---
trailer [3342,3360]
trailer [3386,3404]
===
match
---
name: dag_id [6288,6294]
name: dag_id [6332,6338]
===
match
---
string: 'Deprecation' [2385,2398]
string: 'Deprecation' [2385,2398]
===
match
---
comparison [3096,3112]
comparison [3140,3156]
===
match
---
trailer [13797,13806]
trailer [13841,13850]
===
match
---
name: requires_authentication [12907,12930]
name: requires_authentication [12951,12974]
===
match
---
simple_stmt [3875,3891]
simple_stmt [3919,3935]
===
match
---
operator: = [7605,7606]
operator: = [7649,7650]
===
match
---
fstring [11418,11426]
fstring [11462,11470]
===
match
---
name: dag_id [8712,8718]
name: dag_id [8756,8762]
===
match
---
name: version [6066,6073]
name: version [6110,6117]
===
match
---
name: error [4242,4247]
name: error [4286,4291]
===
match
---
name: dagruns [5532,5539]
name: dagruns [5576,5583]
===
match
---
operator: = [8692,8693]
operator: = [8736,8737]
===
match
---
expr_stmt [11290,11325]
expr_stmt [11334,11369]
===
match
---
expr_stmt [9639,9826]
expr_stmt [9683,9870]
===
match
---
expr_stmt [6405,6443]
expr_stmt [6449,6487]
===
match
---
name: err [11357,11360]
name: err [11401,11404]
===
match
---
operator: = [5921,5922]
operator: = [5965,5966]
===
match
---
name: pool [12795,12799]
name: pool [12839,12843]
===
match
---
trailer [12725,12737]
trailer [12769,12781]
===
match
---
simple_stmt [4760,4794]
simple_stmt [4804,4838]
===
match
---
simple_stmt [13702,13741]
simple_stmt [13746,13785]
===
update-node
---
string: "stable-rest-api/migration.html" [2436,2468]
replace "stable-rest-api/migration.html" by "upgrading-to-2.html#migration-guide-from-experimental-api-to-stable-api-v1"
