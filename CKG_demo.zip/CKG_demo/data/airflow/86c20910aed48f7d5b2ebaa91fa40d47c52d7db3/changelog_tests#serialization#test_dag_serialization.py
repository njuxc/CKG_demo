===
match
---
trailer [45234,45239]
trailer [45352,45357]
===
match
---
operator: , [16097,16098]
operator: , [16113,16114]
===
match
---
trailer [15484,15494]
trailer [15500,15510]
===
match
---
assert_stmt [21440,21480]
assert_stmt [21558,21598]
===
match
---
trailer [14217,14258]
trailer [14233,14274]
===
match
---
simple_stmt [21561,21620]
simple_stmt [21679,21738]
===
match
---
string: "depends_on_past" [6158,6175]
string: "depends_on_past" [6174,6191]
===
match
---
operator: , [35792,35793]
operator: , [35910,35911]
===
match
---
operator: , [31526,31527]
operator: , [31644,31645]
===
match
---
simple_stmt [21628,21697]
simple_stmt [21746,21815]
===
match
---
name: test_dag_serialized_fields_with_schema [32403,32441]
name: test_dag_serialized_fields_with_schema [32521,32559]
===
match
---
trailer [16278,16311]
trailer [16294,16327]
===
match
---
name: sorted_serialized_dag [11029,11050]
name: sorted_serialized_dag [11045,11066]
===
match
---
name: getattr [13128,13135]
name: getattr [13144,13151]
===
match
---
parameters [7882,7899]
parameters [7898,7915]
===
match
---
param [39577,39582]
param [39695,39700]
===
match
---
param [20731,20735]
param [20849,20853]
===
match
---
name: google_link_from_plugin [24801,24824]
name: google_link_from_plugin [24919,24942]
===
match
---
suite [41126,41201]
suite [41244,41319]
===
match
---
name: validate_serialized_dag [10084,10107]
name: validate_serialized_dag [10100,10123]
===
match
---
operator: , [18177,18178]
operator: , [18295,18296]
===
match
---
simple_stmt [45904,45953]
simple_stmt [46022,46071]
===
match
---
simple_stmt [22149,22239]
simple_stmt [22267,22357]
===
match
---
name: serialization [1504,1517]
name: serialization [1520,1533]
===
match
---
string: 'doc_json' [34595,34605]
string: 'doc_json' [34713,34723]
===
match
---
name: dag [38880,38883]
name: dag [38998,39001]
===
match
---
operator: , [5526,5527]
operator: , [5542,5543]
===
match
---
name: serialized_obj [44370,44384]
name: serialized_obj [44488,44502]
===
match
---
operator: } [5600,5601]
operator: } [5616,5617]
===
match
---
name: getattr [15277,15284]
name: getattr [15293,15300]
===
match
---
atom [20450,20533]
atom [20568,20651]
===
match
---
atom_expr [40941,40961]
atom_expr [41059,41079]
===
match
---
operator: { [29598,29599]
operator: { [29716,29717]
===
match
---
param [41538,41543]
param [41656,41661]
===
match
---
string: "dag" [10914,10919]
string: "dag" [10930,10935]
===
match
---
name: tzinfo [16498,16504]
name: tzinfo [16514,16520]
===
match
---
number: 8 [16167,16168]
number: 8 [16183,16184]
===
match
---
simple_stmt [37555,37636]
simple_stmt [37673,37754]
===
match
---
trailer [33211,33213]
trailer [33329,33331]
===
match
---
trailer [29252,29267]
trailer [29370,29385]
===
match
---
name: SerializedDAG [44218,44231]
name: SerializedDAG [44336,44349]
===
match
---
name: containers [1847,1857]
name: containers [1863,1873]
===
match
---
name: items [8633,8638]
name: items [8649,8654]
===
match
---
import_from [1083,1126]
import_from [1099,1142]
===
match
---
number: 1 [6040,6041]
number: 1 [6056,6057]
===
match
---
trailer [45256,45262]
trailer [45374,45380]
===
match
---
operator: = [37182,37183]
operator: = [37300,37301]
===
match
---
name: self [36566,36570]
name: self [36684,36688]
===
match
---
number: 1 [42146,42147]
number: 1 [42264,42265]
===
match
---
operator: = [37257,37258]
operator: = [37375,37376]
===
match
---
trailer [30683,31113]
trailer [30801,31231]
===
match
---
name: test_task_group_serialization [36536,36565]
name: test_task_group_serialization [36654,36683]
===
match
---
operator: } [2956,2957]
operator: } [2972,2973]
===
match
---
trailer [13994,14008]
trailer [14010,14024]
===
match
---
name: task [24280,24284]
name: task [24398,24402]
===
match
---
string: "doc_md" [4336,4344]
string: "doc_md" [4352,4360]
===
match
---
atom_expr [17185,17218]
atom_expr [17303,17336]
===
match
---
name: DAG [40797,40800]
name: DAG [40915,40918]
===
match
---
name: dagbag [5811,5817]
name: dagbag [5827,5833]
===
match
---
atom [29922,29961]
atom [30040,30079]
===
match
---
string: 'doc' [34570,34575]
string: 'doc' [34688,34693]
===
match
---
name: task [15332,15336]
name: task [15348,15352]
===
match
---
operator: , [42115,42116]
operator: , [42233,42234]
===
match
---
trailer [8477,8507]
trailer [8493,8523]
===
match
---
annassign [33093,33166]
annassign [33211,33284]
===
match
---
atom_expr [9897,9905]
atom_expr [9913,9921]
===
match
---
expr_stmt [28727,28808]
expr_stmt [28845,28926]
===
match
---
operator: , [7591,7592]
operator: , [7607,7608]
===
match
---
operator: , [42966,42967]
operator: , [43084,43085]
===
match
---
arglist [20327,20343]
arglist [20445,20461]
===
match
---
simple_stmt [27197,27261]
simple_stmt [27315,27379]
===
match
---
suite [6478,6827]
suite [6494,6843]
===
match
---
simple_stmt [14956,15029]
simple_stmt [14972,15045]
===
match
---
atom_expr [15765,15779]
atom_expr [15781,15795]
===
match
---
atom_expr [37129,37159]
atom_expr [37247,37277]
===
match
---
string: "value_1" [21023,21032]
string: "value_1" [21141,21150]
===
match
---
exprlist [13298,13302]
exprlist [13314,13318]
===
match
---
suite [36998,37215]
suite [37116,37333]
===
match
---
trailer [16306,16310]
trailer [16322,16326]
===
match
---
name: task_id [36930,36937]
name: task_id [37048,37055]
===
match
---
name: datetime [25660,25668]
name: datetime [25778,25786]
===
match
---
atom_expr [38061,38087]
atom_expr [38179,38205]
===
match
---
atom_expr [22265,22291]
atom_expr [22383,22409]
===
match
---
name: airflow [38754,38761]
name: airflow [38872,38879]
===
match
---
operator: = [7678,7679]
operator: = [7694,7695]
===
match
---
atom_expr [37381,37420]
atom_expr [37499,37538]
===
match
---
operator: , [18111,18112]
operator: , [18229,18230]
===
match
---
comparison [20107,20171]
comparison [20225,20289]
===
match
---
simple_stmt [13774,13863]
simple_stmt [13790,13879]
===
match
---
name: setattr [29147,29154]
name: setattr [29265,29272]
===
match
---
operator: , [32910,32911]
operator: , [33028,33029]
===
match
---
name: edgemodifier [38768,38780]
name: edgemodifier [38886,38898]
===
match
---
trailer [30738,30864]
trailer [30856,30982]
===
match
---
param [22720,22724]
param [22838,22842]
===
match
---
expr_stmt [9694,9715]
expr_stmt [9710,9731]
===
match
---
trailer [5622,5627]
trailer [5638,5643]
===
match
---
expr_stmt [45216,45262]
expr_stmt [45334,45380]
===
match
---
atom_expr [38956,38986]
atom_expr [39074,39104]
===
match
---
trailer [17928,17932]
trailer [18046,18050]
===
match
---
name: dag_folder [8045,8055]
name: dag_folder [8061,8071]
===
match
---
testlist_comp [21890,21936]
testlist_comp [22008,22054]
===
match
---
atom [19791,19793]
atom [19909,19911]
===
match
---
name: SerializedDAG [37602,37615]
name: SerializedDAG [37720,37733]
===
match
---
name: task_end_date [18350,18363]
name: task_end_date [18468,18481]
===
match
---
name: dag_schema [32640,32650]
name: dag_schema [32758,32768]
===
match
---
atom [21889,21937]
atom [22007,22055]
===
match
---
number: 0 [44668,44669]
number: 0 [44786,44787]
===
match
---
trailer [37677,37686]
trailer [37795,37804]
===
match
---
name: expected_schedule_interval [19487,19513]
name: expected_schedule_interval [19605,19631]
===
match
---
operator: , [7732,7733]
operator: , [7748,7749]
===
match
---
name: log [34412,34415]
name: log [34530,34533]
===
match
---
name: utc [17855,17858]
name: utc [17973,17976]
===
match
---
return_stmt [25342,25373]
return_stmt [25460,25491]
===
match
---
comparison [10219,10291]
comparison [10235,10307]
===
match
---
dictorsetmaker [41396,41440]
dictorsetmaker [41514,41558]
===
match
---
trailer [41252,41268]
trailer [41370,41386]
===
match
---
suite [42313,42388]
suite [42431,42506]
===
match
---
atom_expr [17846,17858]
atom_expr [17964,17976]
===
match
---
string: """Serialisation / deserialisation continues to work without kubernetes installed""" [44481,44565]
string: """Serialisation / deserialisation continues to work without kubernetes installed""" [44599,44683]
===
match
---
funcdef [25561,25610]
funcdef [25679,25728]
===
match
---
atom_expr [4203,4250]
atom_expr [4219,4266]
===
match
---
number: 8 [17509,17510]
number: 8 [17627,17628]
===
match
---
name: serialized_task [15250,15265]
name: serialized_task [15266,15281]
===
match
---
operator: , [3965,3966]
operator: , [3981,3982]
===
match
---
string: "dummy_value_1" [28150,28165]
string: "dummy_value_1" [28268,28283]
===
match
---
assert_stmt [11914,11969]
assert_stmt [11930,11985]
===
match
---
operator: , [14876,14877]
operator: , [14892,14893]
===
match
---
parameters [44589,44646]
parameters [44707,44764]
===
match
---
name: dag [23364,23367]
name: dag [23482,23485]
===
match
---
atom_expr [13806,13838]
atom_expr [13822,13854]
===
match
---
operator: , [32030,32031]
operator: , [32148,32149]
===
match
---
name: self [21990,21994]
name: self [22108,22112]
===
match
---
operator: { [42744,42745]
operator: { [42862,42863]
===
match
---
trailer [15006,15028]
trailer [15022,15044]
===
match
---
trailer [17461,17536]
trailer [17579,17654]
===
match
---
name: dag [11849,11852]
name: dag [11865,11868]
===
match
---
name: DummyOperator [36695,36708]
name: DummyOperator [36813,36826]
===
match
---
trailer [45938,45952]
trailer [46056,46070]
===
match
---
string: 'dict' [4034,4040]
string: 'dict' [4050,4056]
===
match
---
operator: , [16533,16534]
operator: , [16549,16550]
===
match
---
name: val [20915,20918]
name: val [21033,21036]
===
match
---
comparison [21447,21480]
comparison [21565,21598]
===
match
---
operator: , [20394,20395]
operator: , [20512,20513]
===
match
---
name: serialized_dag [17185,17199]
name: serialized_dag [17303,17317]
===
match
---
name: serialized_dag [18998,19012]
name: serialized_dag [19116,19130]
===
match
---
argument [42117,42148]
argument [42235,42266]
===
match
---
name: dag [39366,39369]
name: dag [39484,39487]
===
match
---
argument [7461,7486]
argument [7477,7502]
===
match
---
trailer [27211,27240]
trailer [27329,27358]
===
match
---
string: "value" [43540,43547]
string: "value" [43658,43665]
===
match
---
name: user_defined_macros [7496,7515]
name: user_defined_macros [7512,7531]
===
match
---
param [40239,40240]
param [40357,40358]
===
match
---
comparison [22616,22663]
comparison [22734,22781]
===
match
---
name: serialize_subprocess [8685,8705]
name: serialize_subprocess [8701,8721]
===
match
---
name: task_id [7718,7725]
name: task_id [7734,7741]
===
match
---
name: self [41538,41542]
name: self [41656,41660]
===
match
---
number: 2019 [16486,16490]
number: 2019 [16502,16506]
===
match
---
operator: == [15156,15158]
operator: == [15172,15174]
===
match
---
trailer [18165,18199]
trailer [18283,18317]
===
match
---
expr_stmt [34184,34215]
expr_stmt [34302,34333]
===
match
---
number: 1 [45499,45500]
number: 1 [45617,45618]
===
match
---
argument [16498,16517]
argument [16514,16533]
===
match
---
trailer [14937,14947]
trailer [14953,14963]
===
match
---
simple_stmt [1016,1030]
simple_stmt [1032,1046]
===
match
---
trailer [38267,38290]
trailer [38385,38408]
===
match
---
fstring_string: .default_args[ [13623,13637]
fstring_string: .default_args[ [13639,13653]
===
match
---
parameters [21109,21134]
parameters [21227,21252]
===
match
---
string: 'on_retry_callback' [14799,14818]
string: 'on_retry_callback' [14815,14834]
===
match
---
dictorsetmaker [12931,13060]
dictorsetmaker [12947,13076]
===
match
---
name: serialize_operator [38365,38383]
name: serialize_operator [38483,38501]
===
match
---
atom_expr [16180,16192]
atom_expr [16196,16208]
===
match
---
name: simple_task [28073,28084]
name: simple_task [28191,28202]
===
match
---
trailer [25544,25546]
trailer [25662,25664]
===
match
---
argument [34162,34174]
argument [34280,34292]
===
match
---
name: serialized_op [33791,33804]
name: serialized_op [33909,33922]
===
match
---
dictorsetmaker [29973,30000]
dictorsetmaker [30091,30118]
===
match
---
dictorsetmaker [40209,40253]
dictorsetmaker [40327,40371]
===
match
---
suite [8948,44443]
suite [8964,44561]
===
match
---
trailer [33850,33856]
trailer [33968,33974]
===
match
---
assert_stmt [10212,10291]
assert_stmt [10228,10307]
===
match
---
name: make_user_defined_macro_filter_dag [6833,6867]
name: make_user_defined_macro_filter_dag [6849,6883]
===
match
---
name: SerializedDAG [19988,20001]
name: SerializedDAG [20106,20119]
===
match
---
param [18350,18364]
param [18468,18482]
===
match
---
name: templated_field [32108,32123]
name: templated_field [32226,32241]
===
match
---
string: "simple_dag" [46054,46066]
string: "simple_dag" [46172,46184]
===
match
---
operator: } [6413,6414]
operator: } [6429,6430]
===
match
---
atom [30834,30842]
atom [30952,30960]
===
match
---
operator: = [7943,7944]
operator: = [7959,7960]
===
match
---
suite [36895,37326]
suite [37013,37444]
===
match
---
name: serialized_dag [42440,42454]
name: serialized_dag [42558,42572]
===
match
---
simple_stmt [38482,38506]
simple_stmt [38600,38624]
===
match
---
name: DummyOperator [38727,38740]
name: DummyOperator [38845,38858]
===
match
---
string: """         Tests edge_info serialization/deserialization.         """ [38612,38682]
string: """         Tests edge_info serialization/deserialization.         """ [38730,38800]
===
match
---
name: k [13442,13443]
name: k [13458,13459]
===
match
---
operator: = [6310,6311]
operator: = [6326,6327]
===
match
---
string: "simple_task" [23601,23614]
string: "simple_task" [23719,23732]
===
match
---
trailer [1784,1797]
trailer [1800,1813]
===
match
---
name: do_xcom_push [33887,33899]
name: do_xcom_push [34005,34017]
===
match
---
parameters [8705,8724]
parameters [8721,8740]
===
match
---
string: """             Sorts the "tasks" list and "access_control" permissions in the             serialised dag python dictionary. This is needed as the order of             items should not matter but assertEqual would fail if the order of             items changes in the dag dictionary             """ [10398,10696]
string: """             Sorts the "tasks" list and "access_control" permissions in the             serialised dag python dictionary. This is needed as the order of             items should not matter but assertEqual would fail if the order of             items changes in the dag dictionary             """ [10414,10712]
===
match
---
string: "simple_dag" [19715,19727]
string: "simple_dag" [19833,19845]
===
match
---
operator: = [21267,21268]
operator: = [21385,21386]
===
match
---
trailer [28067,28111]
trailer [28185,28229]
===
match
---
atom_expr [15159,15183]
atom_expr [15175,15199]
===
match
---
operator: , [3328,3329]
operator: , [3344,3345]
===
match
---
atom_expr [6356,6383]
atom_expr [6372,6399]
===
match
---
atom_expr [7374,7395]
atom_expr [7390,7411]
===
match
---
trailer [8470,8477]
trailer [8486,8493]
===
match
---
name: serialize_operator [38042,38060]
name: serialize_operator [38160,38178]
===
match
---
trailer [18858,18865]
trailer [18976,18983]
===
match
---
trailer [22278,22286]
trailer [22396,22404]
===
match
---
name: serialized_dag [27557,27571]
name: serialized_dag [27675,27689]
===
match
---
name: relativedelta [20582,20595]
name: relativedelta [20700,20713]
===
match
---
trailer [15835,15842]
trailer [15851,15858]
===
match
---
simple_stmt [1331,1402]
simple_stmt [1347,1418]
===
match
---
simple_stmt [32457,32632]
simple_stmt [32575,32750]
===
match
---
number: 86400.0 [19330,19337]
number: 86400.0 [19448,19455]
===
match
---
string: "BigQuery Console #2" [28534,28555]
string: "BigQuery Console #2" [28652,28673]
===
match
---
string: "key:" [43158,43164]
string: "key:" [43276,43282]
===
match
---
trailer [11437,11439]
trailer [11453,11455]
===
match
---
with_stmt [25619,25729]
with_stmt [25737,25847]
===
match
---
operator: , [5121,5122]
operator: , [5137,5138]
===
match
---
string: 'user_defined_macro_filter_dag' [7420,7451]
string: 'user_defined_macro_filter_dag' [7436,7467]
===
match
---
simple_stmt [44353,44394]
simple_stmt [44471,44512]
===
match
---
simple_stmt [39291,39372]
simple_stmt [39409,39490]
===
match
---
name: serialized_schedule_interval [19867,19895]
name: serialized_schedule_interval [19985,20013]
===
match
---
simple_stmt [8119,8141]
simple_stmt [8135,8157]
===
match
---
with_item [36824,36894]
with_item [36942,37012]
===
match
---
string: "BigQuery Console #1" [28299,28320]
string: "BigQuery Console #1" [28417,28438]
===
match
---
simple_stmt [23519,23565]
simple_stmt [23637,23683]
===
match
---
operator: , [42842,42843]
operator: , [42960,42961]
===
match
---
dictorsetmaker [27692,27702]
dictorsetmaker [27810,27820]
===
match
---
name: expected_val [22001,22013]
name: expected_val [22119,22131]
===
match
---
string: "task2" [43727,43734]
string: "task2" [43845,43852]
===
match
---
name: timedelta [19340,19349]
name: timedelta [19458,19467]
===
match
---
trailer [15567,15577]
trailer [15583,15593]
===
match
---
expr_stmt [24262,24323]
expr_stmt [24380,24441]
===
match
---
comparison [17169,17218]
comparison [17287,17336]
===
match
---
simple_stmt [33002,33075]
simple_stmt [33120,33193]
===
match
---
name: DAG [23267,23270]
name: DAG [23385,23388]
===
match
---
operator: , [42821,42822]
operator: , [42939,42940]
===
match
---
parameters [37807,37813]
parameters [37925,37931]
===
match
---
assert_stmt [37695,37777]
assert_stmt [37813,37895]
===
match
---
operator: , [3218,3219]
operator: , [3234,3235]
===
match
---
operator: >= [16906,16908]
operator: >= [17024,17026]
===
match
---
name: serialized_dag [17102,17116]
name: serialized_dag [17220,17234]
===
match
---
operator: { [27691,27692]
operator: { [27809,27810]
===
match
---
trailer [9713,9715]
trailer [9729,9731]
===
match
---
trailer [24729,24757]
trailer [24847,24875]
===
match
---
string: "dummy_value_1" [24361,24376]
string: "dummy_value_1" [24479,24494]
===
match
---
string: "retries" [2200,2209]
string: "retries" [2216,2225]
===
match
---
atom [2661,2688]
atom [2677,2704]
===
match
---
operator: , [15327,15328]
operator: , [15343,15344]
===
match
---
name: task_id [6559,6566]
name: task_id [6575,6582]
===
match
---
trailer [37727,37736]
trailer [37845,37854]
===
match
---
atom [45732,45848]
atom [45850,45966]
===
match
---
name: list [8092,8096]
name: list [8108,8112]
===
match
---
funcdef [29343,29419]
funcdef [29461,29537]
===
match
---
name: find_spec [45154,45163]
name: find_spec [45272,45281]
===
match
---
name: V1PodSpec [1828,1837]
name: V1PodSpec [1844,1853]
===
match
---
trailer [25668,25680]
trailer [25786,25798]
===
match
---
operator: == [24798,24800]
operator: == [24916,24918]
===
match
---
atom_expr [42176,42202]
atom_expr [42294,42320]
===
match
---
name: serialized_task [14967,14982]
name: serialized_task [14983,14998]
===
match
---
name: deserialized_dag [32278,32294]
name: deserialized_dag [32396,32412]
===
match
---
import_name [845,866]
import_name [845,866]
===
match
---
simple_stmt [40120,40157]
simple_stmt [40238,40275]
===
match
---
atom_expr [39308,39371]
atom_expr [39426,39489]
===
match
---
string: "No module named 'kubernetes'" [44744,44774]
string: "No module named 'kubernetes'" [44862,44892]
===
match
---
try_stmt [37827,38430]
try_stmt [37945,38548]
===
match
---
string: "ui_fgcolor" [4884,4896]
string: "ui_fgcolor" [4900,4912]
===
match
---
trailer [5826,5839]
trailer [5842,5855]
===
match
---
fstring_expr [15364,15371]
fstring_expr [15380,15387]
===
match
---
expr_stmt [23220,23252]
expr_stmt [23338,23370]
===
match
---
number: 8 [16285,16286]
number: 8 [16301,16302]
===
match
---
name: dag [23261,23264]
name: dag [23379,23382]
===
match
---
trailer [25811,25870]
trailer [25929,25988]
===
match
---
operator: , [43002,43003]
operator: , [43120,43121]
===
match
---
trailer [21681,21696]
trailer [21799,21814]
===
match
---
name: dag [13706,13709]
name: dag [13722,13725]
===
match
---
name: task_dict [32295,32304]
name: task_dict [32413,32422]
===
match
---
suite [10385,11013]
suite [10401,11029]
===
match
---
trailer [40897,40962]
trailer [41015,41080]
===
match
---
operator: , [30412,30413]
operator: , [30530,30531]
===
match
---
string: """         Assert extra field exists & OperatorLinks defined in Plugins and inbuilt Operator Links.          This tests also depends on GoogleLink() registered as a plugin         in tests/plugins/test_plugin.py          The function tests that if extra operator links are registered in plugin         in ``operator_extra_links`` and the same is also defined in         the Operator in ``BaseOperator.operator_extra_links``, it has the correct         extra link.         """ [26298,26774]
string: """         Assert extra field exists & OperatorLinks defined in Plugins and inbuilt Operator Links.          This tests also depends on GoogleLink() registered as a plugin         in tests/plugins/test_plugin.py          The function tests that if extra operator links are registered in plugin         in ``operator_extra_links`` and the same is also defined in         the Operator in ``BaseOperator.operator_extra_links``, it has the correct         extra link.         """ [26416,26892]
===
match
---
trailer [25712,25728]
trailer [25830,25846]
===
match
---
operator: , [5201,5202]
operator: , [5217,5218]
===
match
---
operator: @ [39435,39436]
operator: @ [39553,39554]
===
match
---
simple_stmt [25507,25548]
simple_stmt [25625,25666]
===
match
---
string: 'task_2' [42813,42821]
string: 'task_2' [42931,42939]
===
match
---
assert_stmt [13517,13657]
assert_stmt [13533,13673]
===
match
---
name: field [15365,15370]
name: field [15381,15386]
===
match
---
operator: , [20610,20611]
operator: , [20728,20729]
===
match
---
trailer [17247,17257]
trailer [17365,17375]
===
match
---
testlist_comp [20451,20532]
testlist_comp [20569,20650]
===
match
---
name: serialized_dag [12439,12453]
name: serialized_dag [12455,12469]
===
match
---
operator: , [5006,5007]
operator: , [5022,5023]
===
match
---
name: mock__import__ [44575,44589]
name: mock__import__ [44693,44707]
===
match
---
operator: , [39529,39530]
operator: , [39647,39648]
===
match
---
name: SerializedDAG [25755,25768]
name: SerializedDAG [25873,25886]
===
match
---
name: test_date [28523,28532]
name: test_date [28641,28650]
===
match
---
atom [43881,43926]
atom [43999,44044]
===
match
---
parameters [5884,5886]
parameters [5900,5902]
===
match
---
string: 'weight_rule' [35806,35819]
string: 'weight_rule' [35924,35937]
===
match
---
operator: = [44618,44619]
operator: = [44736,44737]
===
match
---
string: 'operator' [2662,2672]
string: 'operator' [2678,2688]
===
match
---
name: resources [15416,15425]
name: resources [15432,15441]
===
match
---
argument [6246,6277]
argument [6262,6293]
===
match
---
dictorsetmaker [2525,2947]
dictorsetmaker [2541,2963]
===
match
---
name: task [14289,14293]
name: task [14305,14309]
===
match
---
string: "task2" [43799,43806]
string: "task2" [43917,43924]
===
match
---
arglist [30764,30842]
arglist [30882,30960]
===
match
---
name: dag_dict [10905,10913]
name: dag_dict [10921,10929]
===
match
---
string: "end_date" [18911,18921]
string: "end_date" [19029,19039]
===
match
---
trailer [42197,42202]
trailer [42315,42320]
===
match
---
trailer [14015,14023]
trailer [14031,14039]
===
match
---
name: serialize_dag [37616,37629]
name: serialize_dag [37734,37747]
===
match
---
string: "https://www.google.com" [24773,24797]
string: "https://www.google.com" [24891,24915]
===
match
---
operator: , [3248,3249]
operator: , [3264,3265]
===
match
---
atom [3400,3402]
atom [3416,3418]
===
match
---
name: DAG [38808,38811]
name: DAG [38926,38929]
===
match
---
name: ClassWithCustomAttributes [30658,30683]
name: ClassWithCustomAttributes [30776,30801]
===
match
---
atom_expr [26885,26962]
atom_expr [27003,27080]
===
match
---
string: "bar" [30032,30037]
string: "bar" [30150,30155]
===
match
---
name: poke [39734,39738]
name: poke [39852,39856]
===
match
---
operator: } [30264,30265]
operator: } [30382,30383]
===
match
---
operator: = [17919,17920]
operator: = [18037,18038]
===
match
---
trailer [44904,44955]
trailer [45022,45073]
===
match
---
expr_stmt [41978,42063]
expr_stmt [42096,42181]
===
match
---
simple_stmt [1991,5605]
simple_stmt [2007,5621]
===
match
---
string: '__type' [4143,4151]
string: '__type' [4159,4167]
===
match
---
testlist_comp [42744,42843]
testlist_comp [42862,42961]
===
match
---
atom [3685,3724]
atom [3701,3740]
===
match
---
operator: , [42763,42764]
operator: , [42881,42882]
===
match
---
trailer [37775,37777]
trailer [37893,37895]
===
match
---
trailer [41987,42063]
trailer [42105,42181]
===
match
---
trailer [17132,17135]
trailer [17250,17253]
===
match
---
string: "value_1" [21902,21911]
string: "value_1" [22020,22029]
===
match
---
operator: , [30281,30282]
operator: , [30399,30400]
===
match
---
number: 2019 [22226,22230]
number: 2019 [22344,22348]
===
match
---
name: dag_dict [10813,10821]
name: dag_dict [10829,10837]
===
match
---
atom_expr [38074,38086]
atom_expr [38192,38204]
===
match
---
operator: = [12454,12455]
operator: = [12470,12471]
===
match
---
operator: , [16371,16372]
operator: , [16387,16388]
===
match
---
string: "params" [22406,22414]
string: "params" [22524,22532]
===
match
---
operator: , [29579,29580]
operator: , [29697,29698]
===
match
---
trailer [10315,10326]
trailer [10331,10342]
===
match
---
name: BaseOperator [40885,40897]
name: BaseOperator [41003,41015]
===
match
---
trailer [18106,18139]
trailer [18224,18257]
===
match
---
with_item [38808,38883]
with_item [38926,39001]
===
match
---
parameters [14059,14119]
parameters [14075,14135]
===
match
---
operator: , [7451,7452]
operator: , [7467,7468]
===
match
---
name: field [13192,13197]
name: field [13208,13213]
===
match
---
number: 1 [23250,23251]
number: 1 [23368,23369]
===
match
---
operator: = [6746,6747]
operator: = [6762,6763]
===
match
---
argument [6424,6463]
argument [6440,6479]
===
match
---
string: 'retries' [35416,35425]
string: 'retries' [35534,35543]
===
match
---
atom [43978,43988]
atom [44096,44106]
===
match
---
operator: } [5215,5216]
operator: } [5231,5232]
===
match
---
string: "att1" [30431,30437]
string: "att1" [30549,30555]
===
match
---
name: update [7992,7998]
name: update [8008,8014]
===
match
---
suite [25689,25729]
suite [25807,25847]
===
match
---
name: check_task_group [38482,38498]
name: check_task_group [38600,38616]
===
match
---
name: json_dag [10219,10227]
name: json_dag [10235,10243]
===
match
---
trailer [1933,1968]
trailer [1949,1984]
===
match
---
trailer [7303,7322]
trailer [7319,7338]
===
match
---
name: dag [16665,16668]
name: dag [16783,16786]
===
match
---
operator: } [4827,4828]
operator: } [4843,4844]
===
match
---
string: 'echo' [7726,7732]
string: 'echo' [7742,7748]
===
match
---
suite [18389,19127]
suite [18507,19245]
===
match
---
name: datetime [18157,18165]
name: datetime [18275,18283]
===
match
---
name: unittest [8929,8937]
name: unittest [8945,8953]
===
match
---
atom_expr [33737,33782]
atom_expr [33855,33900]
===
match
---
trailer [10791,10796]
trailer [10807,10812]
===
match
---
string: "/vol/" [1960,1967]
string: "/vol/" [1976,1983]
===
match
---
with_item [44894,44970]
with_item [45012,45088]
===
match
---
name: to_dict [17705,17712]
name: to_dict [17823,17830]
===
match
---
name: SerializedBaseOperator [40061,40083]
name: SerializedBaseOperator [40179,40201]
===
match
---
argument [44852,44869]
argument [44970,44987]
===
match
---
name: downstream_task_ids [15164,15183]
name: downstream_task_ids [15180,15199]
===
match
---
trailer [7991,7998]
trailer [8007,8014]
===
match
---
string: 'retry_exponential_backoff' [35488,35515]
string: 'retry_exponential_backoff' [35606,35633]
===
match
---
operator: { [30031,30032]
operator: { [30149,30150]
===
match
---
string: '"instance": "mock", ' [9276,9298]
string: '"instance": "mock", ' [9292,9314]
===
match
---
name: name [1934,1938]
name: name [1950,1954]
===
match
---
string: "executor_config" [3983,4000]
string: "executor_config" [3999,4016]
===
match
---
name: v [13360,13361]
name: v [13376,13377]
===
match
---
operator: = [8176,8177]
operator: = [8192,8193]
===
match
---
operator: , [19357,19358]
operator: , [19475,19476]
===
match
---
name: BaseSerialization [45911,45928]
name: BaseSerialization [46029,46046]
===
match
---
name: json_dag [37531,37539]
name: json_dag [37649,37657]
===
match
---
suite [11644,11853]
suite [11660,11869]
===
match
---
expr_stmt [39291,39371]
expr_stmt [39409,39489]
===
match
---
comparison [44409,44442]
comparison [44527,44560]
===
match
---
operator: { [27776,27777]
operator: { [27894,27895]
===
match
---
operator: = [42174,42175]
operator: = [42292,42293]
===
match
---
operator: = [38977,38978]
operator: = [39095,39096]
===
match
---
atom_expr [15242,15273]
atom_expr [15258,15289]
===
match
---
name: tzinfo [16379,16385]
name: tzinfo [16395,16401]
===
match
---
string: 'on_success_callback' [35128,35149]
string: 'on_success_callback' [35246,35267]
===
match
---
testlist_comp [20223,20297]
testlist_comp [20341,20415]
===
match
---
name: dag [8648,8651]
name: dag [8664,8667]
===
match
---
name: pardir [5714,5720]
name: pardir [5730,5736]
===
match
---
trailer [29154,29172]
trailer [29272,29290]
===
match
---
name: test_date [24730,24739]
name: test_date [24848,24857]
===
match
---
number: 8 [16226,16227]
number: 8 [16242,16243]
===
match
---
name: self [38597,38601]
name: self [38715,38719]
===
match
---
atom [29733,29795]
atom [29851,29913]
===
match
---
atom [7846,7863]
atom [7862,7879]
===
match
---
name: test_serialization [9572,9590]
name: test_serialization [9588,9606]
===
match
---
trailer [16247,16251]
trailer [16263,16267]
===
match
---
name: airflow [1563,1570]
name: airflow [1579,1586]
===
match
---
expr_stmt [37997,38088]
expr_stmt [38115,38206]
===
match
---
name: path [5674,5678]
name: path [5690,5694]
===
match
---
name: base_operator [34133,34146]
name: base_operator [34251,34264]
===
match
---
name: self [9007,9011]
name: self [9023,9027]
===
match
---
name: val [20793,20796]
name: val [20911,20914]
===
match
---
operator: , [35240,35241]
operator: , [35358,35359]
===
match
---
trailer [37741,37743]
trailer [37859,37861]
===
match
---
operator: } [20668,20669]
operator: } [20786,20787]
===
match
---
name: serialized_simple_dag_ground_truth [10039,10073]
name: serialized_simple_dag_ground_truth [10055,10089]
===
match
---
trailer [7979,7981]
trailer [7995,7997]
===
match
---
trailer [24279,24323]
trailer [24397,24441]
===
match
---
trailer [28780,28808]
trailer [28898,28926]
===
match
---
if_stmt [41024,41201]
if_stmt [41142,41319]
===
match
---
name: val [22303,22306]
name: val [22421,22424]
===
match
---
atom_expr [17296,17324]
atom_expr [17414,17442]
===
match
---
name: __class__ [29228,29237]
name: __class__ [29346,29355]
===
match
---
atom_expr [19988,20023]
atom_expr [20106,20141]
===
match
---
atom_expr [44370,44393]
atom_expr [44488,44511]
===
match
---
funcdef [29428,29495]
funcdef [29546,29613]
===
match
---
atom_expr [13351,13362]
atom_expr [13367,13378]
===
match
---
operator: , [8089,8090]
operator: , [8105,8106]
===
match
---
name: name [44674,44678]
name: name [44792,44796]
===
match
---
comparison [40017,40035]
comparison [40135,40153]
===
match
---
name: DAG [1293,1296]
name: DAG [1309,1312]
===
match
---
operator: , [17507,17508]
operator: , [17625,17626]
===
match
---
trailer [14396,14418]
trailer [14412,14434]
===
match
---
string: 'template_fields' [14634,14651]
string: 'template_fields' [14650,14667]
===
match
---
string: "airflow/providers/*/*/example_dags" [8318,8354]
string: "airflow/providers/*/*/example_dags" [8334,8370]
===
match
---
operator: , [31617,31618]
operator: , [31735,31736]
===
match
---
operator: = [1914,1915]
operator: = [1930,1931]
===
match
---
name: dags [8674,8678]
name: dags [8690,8694]
===
match
---
simple_stmt [15940,15978]
simple_stmt [15956,15994]
===
match
---
operator: , [4250,4251]
operator: , [4266,4267]
===
match
---
trailer [29237,29246]
trailer [29355,29364]
===
match
---
argument [30387,30412]
argument [30505,30530]
===
match
---
name: expected_value [40382,40396]
name: expected_value [40500,40514]
===
match
---
simple_stmt [13667,13724]
simple_stmt [13683,13740]
===
match
---
name: import_mock [44959,44970]
name: import_mock [45077,45088]
===
match
---
atom_expr [8478,8506]
atom_expr [8494,8522]
===
match
---
name: serialized_task [15947,15962]
name: serialized_task [15963,15978]
===
match
---
operator: , [29636,29637]
operator: , [29754,29755]
===
match
---
operator: , [43190,43191]
operator: , [43308,43309]
===
match
---
trailer [21473,21480]
trailer [21591,21598]
===
match
---
testlist_comp [16358,16519]
testlist_comp [16374,16535]
===
match
---
string: "@once" [19268,19275]
string: "@once" [19386,19393]
===
match
---
dictorsetmaker [45746,45838]
dictorsetmaker [45864,45956]
===
match
---
name: utc [17988,17991]
name: utc [18106,18109]
===
match
---
atom [20222,20298]
atom [20340,20416]
===
match
---
string: '' [2714,2716]
string: '' [2730,2732]
===
match
---
dictorsetmaker [20650,20667]
dictorsetmaker [20768,20785]
===
match
---
dictorsetmaker [3686,3723]
dictorsetmaker [3702,3739]
===
match
---
argument [16379,16398]
argument [16395,16414]
===
match
---
operator: , [42035,42036]
operator: , [42153,42154]
===
match
---
parameters [19441,19549]
parameters [19559,19667]
===
match
---
operator: = [25634,25635]
operator: = [25752,25753]
===
match
---
string: "__var" [2345,2352]
string: "__var" [2361,2368]
===
match
---
string: "bash_command" [27225,27239]
string: "bash_command" [27343,27357]
===
match
---
simple_stmt [19022,19065]
simple_stmt [19140,19183]
===
match
---
string: "test3" [43718,43725]
string: "test3" [43836,43843]
===
match
---
testlist_comp [20222,20671]
testlist_comp [20340,20789]
===
match
---
operator: , [41448,41449]
operator: , [41566,41567]
===
match
---
operator: == [37744,37746]
operator: == [37862,37864]
===
match
---
decorator [20941,21076]
decorator [21059,21194]
===
match
---
arglist [10743,10799]
arglist [10759,10815]
===
match
---
fstring_string:  does not match [13235,13250]
fstring_string:  does not match [13251,13266]
===
match
---
number: 0 [27588,27589]
number: 0 [27706,27707]
===
match
---
name: tzinfo [18239,18245]
name: tzinfo [18357,18363]
===
match
---
parameters [20724,20745]
parameters [20842,20863]
===
match
---
name: dag [27160,27163]
name: dag [27278,27281]
===
match
---
operator: } [21911,21912]
operator: } [22029,22030]
===
match
---
arglist [38812,38875]
arglist [38930,38993]
===
match
---
import_as_names [1065,1082]
import_as_names [1081,1098]
===
match
---
comparison [41285,41343]
comparison [41403,41461]
===
match
---
argument [39827,39836]
argument [39945,39954]
===
match
---
simple_stmt [40407,40783]
simple_stmt [40525,40901]
===
match
---
atom [5336,5526]
atom [5352,5542]
===
match
---
name: task_group [37717,37727]
name: task_group [37835,37845]
===
match
---
string: "default_args" [19639,19653]
string: "default_args" [19757,19771]
===
match
---
operator: , [40380,40381]
operator: , [40498,40499]
===
match
---
simple_stmt [44201,44265]
simple_stmt [44319,44383]
===
match
---
string: "_task_type" [5024,5036]
string: "_task_type" [5040,5052]
===
match
---
trailer [10847,10856]
trailer [10863,10872]
===
match
---
arglist [28133,28183]
arglist [28251,28301]
===
match
---
name: get_extra_links [24714,24729]
name: get_extra_links [24832,24847]
===
match
---
operator: , [5216,5217]
operator: , [5232,5233]
===
match
---
operator: , [32949,32950]
operator: , [33067,33068]
===
match
---
name: test_date [28101,28110]
name: test_date [28219,28228]
===
match
---
param [24902,24906]
param [25020,25024]
===
match
---
import_from [36717,36763]
import_from [36835,36881]
===
match
---
name: json_schema [1518,1529]
name: json_schema [1534,1545]
===
match
---
operator: = [16297,16298]
operator: = [16313,16314]
===
match
---
operator: , [19455,19456]
operator: , [19573,19574]
===
match
---
operator: == [24033,24035]
operator: == [24151,24153]
===
match
---
string: "{{ task.task_id }}" [30769,30789]
string: "{{ task.task_id }}" [30887,30907]
===
match
---
name: field [13229,13234]
name: field [13245,13250]
===
match
---
string: 'airflow' [35205,35214]
string: 'airflow' [35323,35332]
===
match
---
atom_expr [16152,16193]
atom_expr [16168,16209]
===
match
---
name: serialize_pod [4216,4229]
name: serialize_pod [4232,4245]
===
match
---
operator: , [42929,42930]
operator: , [43047,43048]
===
match
---
atom_expr [16029,16070]
atom_expr [16045,16086]
===
match
---
funcdef [18296,19127]
funcdef [18414,19245]
===
match
---
operator: , [24241,24242]
operator: , [24359,24360]
===
match
---
operator: , [30864,30865]
operator: , [30982,30983]
===
match
---
operator: = [1823,1824]
operator: = [1839,1840]
===
match
---
operator: , [28084,28085]
operator: , [28202,28203]
===
match
---
name: minutes [6133,6140]
name: minutes [6149,6156]
===
match
---
operator: = [16669,16670]
operator: = [16787,16788]
===
match
---
operator: , [17481,17482]
operator: , [17599,17600]
===
match
---
comparison [18647,18676]
comparison [18765,18794]
===
match
---
trailer [45550,45561]
trailer [45668,45679]
===
match
---
operator: { [29963,29964]
operator: { [30081,30082]
===
match
---
parameters [26282,26288]
parameters [26400,26406]
===
match
---
operator: , [33380,33381]
operator: , [33498,33499]
===
match
---
string: "tests.test_utils.mock_operators" [5088,5121]
string: "tests.test_utils.mock_operators" [5104,5137]
===
match
---
operator: } [30001,30002]
operator: } [30119,30120]
===
match
---
simple_stmt [11408,11440]
simple_stmt [11424,11456]
===
match
---
number: 8 [6272,6273]
number: 8 [6288,6289]
===
match
---
name: set [27860,27863]
name: set [27978,27981]
===
match
---
operator: { [43157,43158]
operator: { [43275,43276]
===
match
---
name: DAG [15909,15912]
name: DAG [15925,15928]
===
match
---
operator: = [34147,34148]
operator: = [34265,34266]
===
match
---
argument [17570,17591]
argument [17688,17709]
===
match
---
argument [18408,18427]
argument [18526,18545]
===
match
---
atom [42802,42842]
atom [42920,42960]
===
match
---
arglist [23639,23666]
arglist [23757,23784]
===
match
---
atom_expr [20604,20609]
atom_expr [20722,20727]
===
match
---
name: v [9897,9898]
name: v [9913,9914]
===
match
---
trailer [20781,20792]
trailer [20899,20910]
===
match
---
string: "task2" [38978,38985]
string: "task2" [39096,39103]
===
match
---
arith_expr [14392,14887]
arith_expr [14408,14903]
===
match
---
atom_expr [39200,39226]
atom_expr [39318,39344]
===
match
---
trailer [5702,5709]
trailer [5718,5725]
===
match
---
operator: , [42898,42899]
operator: , [43016,43017]
===
match
---
name: call_args_list [45523,45537]
name: call_args_list [45641,45655]
===
match
---
operator: } [32991,32992]
operator: } [33109,33110]
===
match
---
suite [32053,32125]
suite [32171,32243]
===
match
---
trailer [9076,9081]
trailer [9092,9097]
===
match
---
import_from [1491,1557]
import_from [1507,1573]
===
match
---
name: parameterized [15984,15997]
name: parameterized [16000,16013]
===
match
---
operator: } [20407,20408]
operator: } [20525,20526]
===
match
---
expr_stmt [38948,38986]
expr_stmt [39066,39104]
===
match
---
string: """         Additional Properties are disabled on DAGs. This test verifies that all the         keys in DAG.get_serialized_fields are listed in Schema definition.         """ [32457,32631]
string: """         Additional Properties are disabled on DAGs. This test verifies that all the         keys in DAG.get_serialized_fields are listed in Schema definition.         """ [32575,32749]
===
match
---
name: locals_ [44611,44618]
name: locals_ [44729,44736]
===
match
---
testlist_comp [29572,29578]
testlist_comp [29690,29696]
===
match
---
operator: , [7266,7267]
operator: , [7282,7283]
===
match
---
atom_expr [16830,16856]
atom_expr [16948,16974]
===
match
---
comparison [15480,15500]
comparison [15496,15516]
===
match
---
operator: { [43523,43524]
operator: { [43641,43642]
===
match
---
string: "__var" [44385,44392]
string: "__var" [44503,44510]
===
match
---
name: simple_task [24176,24187]
name: simple_task [24294,24305]
===
match
---
name: put [8891,8894]
name: put [8907,8910]
===
match
---
name: _ [37125,37126]
name: _ [37243,37244]
===
match
---
expr_stmt [33791,33856]
expr_stmt [33909,33974]
===
match
---
atom_expr [8648,8661]
atom_expr [8664,8677]
===
match
---
name: expected_deserialized [38105,38126]
name: expected_deserialized [38223,38244]
===
match
---
operator: , [43538,43539]
operator: , [43656,43657]
===
match
---
string: "tasks" [27071,27078]
string: "tasks" [27189,27196]
===
match
---
operator: } [42783,42784]
operator: } [42901,42902]
===
match
---
suite [13331,13658]
suite [13347,13674]
===
match
---
string: "__var" [10940,10947]
string: "__var" [10956,10963]
===
match
---
string: "retries" [3236,3245]
string: "retries" [3252,3261]
===
match
---
atom_expr [7847,7857]
atom_expr [7863,7873]
===
match
---
name: TaskGroup [37072,37081]
name: TaskGroup [37190,37199]
===
match
---
suite [12426,12572]
suite [12442,12588]
===
match
---
simple_stmt [8773,8805]
simple_stmt [8789,8821]
===
match
---
operator: == [35845,35847]
operator: == [35963,35965]
===
match
---
name: field [15267,15272]
name: field [15283,15288]
===
match
---
comp_op [40024,40030]
comp_op [40142,40148]
===
match
---
operator: = [40940,40941]
operator: = [41058,41059]
===
match
---
atom_expr [14278,14318]
atom_expr [14294,14334]
===
match
---
number: 1 [32032,32033]
number: 1 [32150,32151]
===
match
---
operator: } [20296,20297]
operator: } [20414,20415]
===
match
---
string: "deps" [39969,39975]
string: "deps" [40087,40093]
===
match
---
atom_expr [15480,15494]
atom_expr [15496,15510]
===
match
---
name: task5 [37228,37233]
name: task5 [37346,37351]
===
match
---
string: "max_retry_delay" [4536,4553]
string: "max_retry_delay" [4552,4569]
===
match
---
operator: - [10257,10258]
operator: - [10273,10274]
===
match
---
number: 5 [6088,6089]
number: 5 [6104,6105]
===
match
---
expr_stmt [16813,16856]
expr_stmt [16931,16974]
===
match
---
number: 1 [16376,16377]
number: 1 [16392,16393]
===
match
---
name: custom_inbuilt_link [28400,28419]
name: custom_inbuilt_link [28518,28537]
===
match
---
atom_expr [16106,16118]
atom_expr [16122,16134]
===
match
---
funcdef [20692,20936]
funcdef [20810,21054]
===
match
---
trailer [10913,10920]
trailer [10929,10936]
===
match
---
trailer [37477,37485]
trailer [37595,37603]
===
match
---
operator: } [19684,19685]
operator: } [19802,19803]
===
match
---
name: V1VolumeMount [1920,1933]
name: V1VolumeMount [1936,1949]
===
match
---
simple_stmt [21281,21359]
simple_stmt [21399,21477]
===
match
---
name: from_json [12470,12479]
name: from_json [12486,12495]
===
match
---
string: "retry_delay" [2230,2243]
string: "retry_delay" [2246,2259]
===
match
---
operator: } [27788,27789]
operator: } [27906,27907]
===
match
---
name: weekday [20596,20603]
name: weekday [20714,20721]
===
match
---
atom [30158,30198]
atom [30276,30316]
===
match
---
operator: , [13059,13060]
operator: , [13075,13076]
===
match
---
operator: { [19683,19684]
operator: { [19801,19802]
===
match
---
operator: { [29972,29973]
operator: { [30090,30091]
===
match
---
trailer [15458,15468]
trailer [15474,15484]
===
match
---
name: parameterized [40163,40176]
name: parameterized [40281,40294]
===
match
---
operator: @ [15983,15984]
operator: @ [15999,16000]
===
match
---
number: 300.0 [3281,3286]
number: 300.0 [3297,3302]
===
match
---
assert_stmt [11022,11103]
assert_stmt [11038,11119]
===
match
---
atom_expr [13748,13760]
atom_expr [13764,13776]
===
match
---
string: 'google' [28021,28029]
string: 'google' [28139,28147]
===
match
---
param [18330,18335]
param [18448,18453]
===
match
---
argument [25628,25647]
argument [25746,25765]
===
match
---
name: expected_serialized [37997,38016]
name: expected_serialized [38115,38134]
===
match
---
string: "bash_command" [32378,32392]
string: "bash_command" [32496,32510]
===
match
---
trailer [21603,21619]
trailer [21721,21737]
===
match
---
atom [20515,20531]
atom [20633,20649]
===
match
---
atom [2028,5604]
atom [2044,5620]
===
match
---
parameters [29292,29298]
parameters [29410,29416]
===
match
---
string: 'bash_task' [2632,2643]
string: 'bash_task' [2648,2659]
===
match
---
operator: = [39870,39871]
operator: = [39988,39989]
===
match
---
param [7883,7898]
param [7899,7914]
===
match
---
name: name [7639,7643]
name: name [7655,7659]
===
match
---
operator: { [4002,4003]
operator: { [4018,4019]
===
match
---
operator: = [26828,26829]
operator: = [26946,26947]
===
match
---
name: self [14069,14073]
name: self [14085,14089]
===
match
---
comp_op [41172,41178]
comp_op [41290,41296]
===
match
---
atom_expr [7300,7338]
atom_expr [7316,7354]
===
match
---
simple_stmt [25342,25374]
simple_stmt [25460,25492]
===
match
---
name: pod_generator [1232,1245]
name: pod_generator [1248,1261]
===
match
---
trailer [4229,4250]
trailer [4245,4266]
===
match
---
atom_expr [33606,33623]
atom_expr [33724,33741]
===
match
---
operator: { [2385,2386]
operator: { [2401,2402]
===
match
---
name: self [18330,18334]
name: self [18448,18452]
===
match
---
operator: } [43411,43412]
operator: } [43529,43530]
===
match
---
atom_expr [33320,33362]
atom_expr [33438,33480]
===
match
---
trailer [33829,33850]
trailer [33947,33968]
===
match
---
atom_expr [42416,42455]
atom_expr [42534,42573]
===
match
---
name: dag_id [22120,22126]
name: dag_id [22238,22244]
===
match
---
operator: , [18363,18364]
operator: , [18481,18482]
===
match
---
trailer [29409,29418]
trailer [29527,29536]
===
match
---
string: 'on_failure_callback' [35048,35069]
string: 'on_failure_callback' [35166,35187]
===
match
---
operator: = [31082,31083]
operator: = [31200,31201]
===
match
---
argument [33664,33679]
argument [33782,33797]
===
match
---
name: validate_deserialized_dag [39241,39266]
name: validate_deserialized_dag [39359,39384]
===
match
---
name: self [11149,11153]
name: self [11165,11169]
===
match
---
number: 0 [45548,45549]
number: 0 [45666,45667]
===
match
---
string: 'json' [3717,3723]
string: 'json' [3733,3739]
===
match
---
param [19457,19486]
param [19575,19604]
===
match
---
string: "start_date" [2460,2472]
string: "start_date" [2476,2488]
===
match
---
name: permissions [6385,6396]
name: permissions [6401,6412]
===
match
---
name: serialized_simple_dag_ground_truth [1991,2025]
name: serialized_simple_dag_ground_truth [2007,2041]
===
match
---
testlist_comp [19210,19243]
testlist_comp [19328,19361]
===
match
---
simple_stmt [10212,10292]
simple_stmt [10228,10308]
===
match
---
name: SerializedDAG [12480,12493]
name: SerializedDAG [12496,12509]
===
match
---
arglist [32354,32392]
arglist [32472,32510]
===
match
---
name: expected_val [22616,22628]
name: expected_val [22734,22746]
===
match
---
number: 1 [4479,4480]
number: 1 [4495,4496]
===
match
---
string: "schedule_interval" [19846,19865]
string: "schedule_interval" [19964,19983]
===
match
---
expr_stmt [40045,40110]
expr_stmt [40163,40228]
===
match
---
trailer [38498,38505]
trailer [38616,38623]
===
match
---
atom_expr [44791,44883]
atom_expr [44909,45001]
===
match
---
operator: , [31094,31095]
operator: , [31212,31213]
===
match
---
argument [26900,26921]
argument [27018,27039]
===
match
---
operator: , [34993,34994]
operator: , [35111,35112]
===
match
---
simple_stmt [18904,18959]
simple_stmt [19022,19077]
===
match
---
simple_stmt [24262,24324]
simple_stmt [24380,24442]
===
match
---
param [26283,26287]
param [26401,26405]
===
match
---
name: to_dict [42190,42197]
name: to_dict [42308,42315]
===
match
---
trailer [41193,41200]
trailer [41311,41318]
===
match
---
name: test_date [23303,23312]
name: test_date [23421,23430]
===
match
---
atom [40193,40297]
atom [40311,40415]
===
match
---
operator: , [45837,45838]
operator: , [45955,45956]
===
match
---
arglist [25812,25869]
arglist [25930,25987]
===
match
---
param [19487,19514]
param [19605,19632]
===
match
---
string: "{{ task.task_id }}" [30950,30970]
string: "{{ task.task_id }}" [31068,31088]
===
match
---
atom_expr [12456,12507]
atom_expr [12472,12523]
===
match
---
param [38597,38601]
param [38715,38719]
===
match
---
expr_stmt [10813,10984]
expr_stmt [10829,11000]
===
match
---
assert_stmt [20806,20835]
assert_stmt [20924,20953]
===
match
---
trailer [22507,22523]
trailer [22625,22641]
===
match
---
argument [40801,40848]
argument [40919,40966]
===
match
---
expr_stmt [11554,11572]
expr_stmt [11570,11588]
===
match
---
name: V1ObjectMeta [1785,1797]
name: V1ObjectMeta [1801,1813]
===
match
---
string: "__var" [20506,20513]
string: "__var" [20624,20631]
===
match
---
string: "test_role" [6342,6353]
string: "test_role" [6358,6369]
===
match
---
name: dag [15337,15340]
name: dag [15353,15356]
===
match
---
trailer [13852,13861]
trailer [13868,13877]
===
match
---
argument [22194,22204]
argument [22312,22322]
===
match
---
atom_expr [13555,13585]
atom_expr [13571,13601]
===
match
---
testlist_comp [29545,31542]
testlist_comp [29663,31660]
===
match
---
trailer [18134,18138]
trailer [18252,18256]
===
match
---
operator: , [43725,43726]
operator: , [43843,43844]
===
match
---
atom_expr [10300,10326]
atom_expr [10316,10342]
===
match
---
name: client [1099,1105]
name: client [1115,1121]
===
match
---
operator: = [18125,18126]
operator: = [18243,18244]
===
match
---
expr_stmt [31958,32035]
expr_stmt [32076,32153]
===
match
---
atom [42744,42784]
atom [42862,42902]
===
match
---
name: fields_to_check [12805,12820]
name: fields_to_check [12821,12836]
===
match
---
operator: { [30063,30064]
operator: { [30181,30182]
===
match
---
param [29194,29198]
param [29312,29316]
===
match
---
expr_stmt [8773,8804]
expr_stmt [8789,8820]
===
match
---
testlist_comp [2662,2687]
testlist_comp [2678,2703]
===
match
---
name: to_dict [21399,21406]
name: to_dict [21517,21524]
===
match
---
operator: , [12565,12566]
operator: , [12581,12582]
===
match
---
atom_expr [18844,18877]
atom_expr [18962,18995]
===
match
---
simple_stmt [916,967]
simple_stmt [916,967]
===
match
---
operator: == [28632,28634]
operator: == [28750,28752]
===
match
---
argument [6644,6659]
argument [6660,6675]
===
match
---
string: 'simple_dag' [10024,10036]
string: 'simple_dag' [10040,10052]
===
match
---
name: serialized_task [15885,15900]
name: serialized_task [15901,15916]
===
match
---
name: dag [12823,12826]
name: dag [12839,12842]
===
match
---
name: dag [17228,17231]
name: dag [17346,17349]
===
match
---
operator: , [16493,16494]
operator: , [16509,16510]
===
match
---
atom_expr [5655,5698]
atom_expr [5671,5714]
===
match
---
trailer [20606,20609]
trailer [20724,20727]
===
match
---
name: maxDiff [9516,9523]
name: maxDiff [9532,9539]
===
match
---
trailer [22225,22237]
trailer [22343,22355]
===
match
---
name: util [45235,45239]
name: util [45353,45357]
===
match
---
trailer [25921,25937]
trailer [26039,26055]
===
match
---
atom_expr [24176,24199]
atom_expr [24294,24317]
===
match
---
comparison [42472,42530]
comparison [42590,42648]
===
match
---
name: utils [38762,38767]
name: utils [38880,38885]
===
match
---
trailer [13697,13702]
trailer [13713,13718]
===
match
---
name: expected_field [32328,32342]
name: expected_field [32446,32460]
===
match
---
trailer [18194,18198]
trailer [18312,18316]
===
match
---
string: "key:" [43524,43530]
string: "key:" [43642,43648]
===
match
---
string: 'task_5' [42610,42618]
string: 'task_5' [42728,42736]
===
match
---
atom [16134,16326]
atom [16150,16342]
===
match
---
name: V1Container [1876,1887]
name: V1Container [1892,1903]
===
match
---
operator: , [6726,6727]
operator: , [6742,6743]
===
match
---
name: serialized_dag [16813,16827]
name: serialized_dag [16931,16945]
===
match
---
operator: , [43910,43911]
operator: , [44028,44029]
===
match
---
operator: { [5560,5561]
operator: { [5576,5577]
===
match
---
atom_expr [6123,6144]
atom_expr [6139,6160]
===
match
---
exprlist [9757,9761]
exprlist [9773,9777]
===
match
---
trailer [10256,10260]
trailer [10272,10276]
===
match
---
string: "dag" [27064,27069]
string: "dag" [27182,27187]
===
match
---
string: 'queue' [35353,35360]
string: 'queue' [35471,35478]
===
match
---
assert_stmt [33299,33443]
assert_stmt [33417,33561]
===
match
---
dictorsetmaker [33049,33064]
dictorsetmaker [33167,33182]
===
match
---
param [16597,16612]
param [16715,16730]
===
match
---
trailer [16219,16252]
trailer [16235,16268]
===
match
---
trailer [7956,7963]
trailer [7972,7979]
===
match
---
suite [12182,12572]
suite [12198,12588]
===
match
---
operator: = [36788,36789]
operator: = [36906,36907]
===
match
---
number: 23 [39852,39854]
number: 23 [39970,39972]
===
match
---
if_stmt [13348,13658]
if_stmt [13364,13674]
===
match
---
name: tzinfo [18031,18037]
name: tzinfo [18149,18155]
===
match
---
name: datetime [6257,6265]
name: datetime [6273,6281]
===
match
---
string: "__type" [20479,20487]
string: "__type" [20597,20605]
===
match
---
operator: = [44633,44634]
operator: = [44751,44752]
===
match
---
operator: , [6041,6042]
operator: , [6057,6058]
===
match
---
simple_stmt [26177,26218]
simple_stmt [26295,26336]
===
match
---
simple_stmt [828,845]
simple_stmt [828,845]
===
match
---
trailer [46053,46067]
trailer [46171,46185]
===
match
---
operator: , [16459,16460]
operator: , [16475,16476]
===
match
---
argument [38919,38934]
argument [39037,39052]
===
match
---
operator: , [4379,4380]
operator: , [4395,4396]
===
match
---
simple_stmt [37279,37297]
simple_stmt [37397,37415]
===
match
---
suite [21427,21481]
suite [21545,21599]
===
match
---
trailer [10007,10074]
trailer [10023,10090]
===
match
---
operator: = [33671,33672]
operator: = [33789,33790]
===
match
---
trailer [15354,15362]
trailer [15370,15378]
===
match
---
name: to_dict [46028,46035]
name: to_dict [46146,46153]
===
match
---
dictorsetmaker [7847,7862]
dictorsetmaker [7863,7878]
===
match
---
trailer [13615,13622]
trailer [13631,13638]
===
match
---
argument [24280,24296]
argument [24398,24414]
===
match
---
operator: = [44842,44843]
operator: = [44960,44961]
===
match
---
number: 2 [45496,45497]
number: 2 [45614,45615]
===
match
---
atom_expr [29404,29418]
atom_expr [29522,29536]
===
match
---
trailer [5670,5698]
trailer [5686,5714]
===
match
---
operator: } [43267,43268]
operator: } [43385,43386]
===
match
---
number: 1 [35338,35339]
number: 1 [35456,35457]
===
match
---
trailer [46051,46053]
trailer [46169,46171]
===
match
---
operator: - [20404,20405]
operator: - [20522,20523]
===
match
---
dotted_name [1088,1105]
dotted_name [1104,1121]
===
match
---
param [44611,44624]
param [44729,44742]
===
match
---
expr_stmt [19982,20023]
expr_stmt [20100,20141]
===
match
---
atom_expr [17340,17362]
atom_expr [17458,17480]
===
match
---
name: dict [32652,32656]
name: dict [32770,32774]
===
match
---
operator: , [5161,5162]
operator: , [5177,5178]
===
match
---
trailer [34411,34415]
trailer [34529,34533]
===
match
---
operator: = [19354,19355]
operator: = [19472,19473]
===
match
---
name: task2 [39031,39036]
name: task2 [39149,39154]
===
match
---
assert_stmt [32321,32393]
assert_stmt [32439,32511]
===
match
---
atom_expr [33696,33711]
atom_expr [33814,33829]
===
match
---
name: self [31613,31617]
name: self [31731,31735]
===
match
---
trailer [25800,25811]
trailer [25918,25929]
===
match
---
string: "_is_dummy" [4683,4694]
string: "_is_dummy" [4699,4710]
===
match
---
string: "dag" [41194,41199]
string: "dag" [41312,41317]
===
match
---
trailer [6501,6524]
trailer [6517,6540]
===
match
---
name: datetime [16477,16485]
name: datetime [16493,16501]
===
match
---
name: make_simple_dag [5869,5884]
name: make_simple_dag [5885,5900]
===
match
---
operator: == [27241,27243]
operator: == [27359,27361]
===
match
---
atom [21872,21874]
atom [21990,21992]
===
match
---
string: "bash_command" [23652,23666]
string: "bash_command" [23770,23784]
===
match
---
name: custom_inbuilt_link [28635,28654]
name: custom_inbuilt_link [28753,28772]
===
match
---
number: 1 [20294,20295]
number: 1 [20412,20413]
===
match
---
name: executor_config [6673,6688]
name: executor_config [6689,6704]
===
match
---
string: "foo" [30151,30156]
string: "foo" [30269,30274]
===
match
---
arglist [28068,28110]
arglist [28186,28228]
===
match
---
string: "echo {{ task.task_id }}" [3758,3783]
string: "echo {{ task.task_id }}" [3774,3799]
===
match
---
operator: , [3286,3287]
operator: , [3302,3303]
===
match
---
import_from [1266,1330]
import_from [1282,1346]
===
match
---
if_stmt [11685,11721]
if_stmt [11701,11737]
===
match
---
testlist_comp [42658,42696]
testlist_comp [42776,42814]
===
match
---
name: expand [29515,29521]
name: expand [29633,29639]
===
match
---
string: "true" [26954,26960]
string: "true" [27072,27078]
===
match
---
suite [33484,33639]
suite [33602,33757]
===
match
---
testlist_comp [17892,18052]
testlist_comp [18010,18170]
===
match
---
string: "dag" [18859,18864]
string: "dag" [18977,18982]
===
match
---
operator: = [11485,11486]
operator: = [11501,11502]
===
match
---
trailer [34161,34175]
trailer [34279,34293]
===
match
---
operator: , [16045,16046]
operator: , [16061,16062]
===
match
---
argument [9136,9478]
argument [9152,9494]
===
match
---
name: serialized [19559,19569]
name: serialized [19677,19687]
===
match
---
name: SerializedDAG [8853,8866]
name: SerializedDAG [8869,8882]
===
match
---
expr_stmt [7401,7691]
expr_stmt [7417,7707]
===
match
---
name: task_group [37751,37761]
name: task_group [37869,37879]
===
match
---
simple_stmt [33648,33681]
simple_stmt [33766,33799]
===
match
---
name: DAG [11801,11804]
name: DAG [11817,11820]
===
match
---
simple_stmt [26783,26816]
simple_stmt [26901,26934]
===
match
---
simple_stmt [1491,1558]
simple_stmt [1507,1574]
===
match
---
atom_expr [12059,12129]
atom_expr [12075,12145]
===
match
---
name: simple_task [27146,27157]
name: simple_task [27264,27275]
===
match
---
string: 'My Link' [25267,25276]
string: 'My Link' [25385,25394]
===
match
---
string: "hi" [41435,41439]
string: "hi" [41553,41557]
===
match
---
atom_expr [21281,21358]
atom_expr [21399,21476]
===
match
---
string: "dag" [32697,32702]
string: "dag" [32815,32820]
===
match
---
string: 'task_4' [42630,42638]
string: 'task_4' [42748,42756]
===
match
---
number: 2019 [17503,17507]
number: 2019 [17621,17625]
===
match
---
simple_stmt [18819,18878]
simple_stmt [18937,18996]
===
match
---
operator: = [11659,11660]
operator: = [11675,11676]
===
match
---
operator: , [29159,29160]
operator: , [29277,29278]
===
match
---
atom_expr [45790,45837]
atom_expr [45908,45955]
===
match
---
operator: = [17978,17979]
operator: = [18096,18097]
===
match
---
fstring_string:  does not match [15371,15386]
fstring_string:  does not match [15387,15402]
===
match
---
trailer [21807,21814]
trailer [21925,21932]
===
match
---
operator: } [29886,29887]
operator: } [30004,30005]
===
match
---
simple_stmt [17282,17325]
simple_stmt [17400,17443]
===
match
---
arglist [27212,27239]
arglist [27330,27357]
===
match
---
argument [17972,17991]
argument [18090,18109]
===
match
---
name: xcom_push [28123,28132]
name: xcom_push [28241,28250]
===
match
---
operator: , [44609,44610]
operator: , [44727,44728]
===
match
---
comp_if [8641,8661]
comp_if [8657,8677]
===
match
---
atom_expr [15045,15078]
atom_expr [15061,15094]
===
match
---
operator: == [13159,13161]
operator: == [13175,13177]
===
match
---
number: 2019 [18019,18023]
number: 2019 [18137,18141]
===
match
---
decorated [20177,20936]
decorated [20295,21054]
===
match
---
operator: , [42141,42142]
operator: , [42259,42260]
===
match
---
operator: , [44301,44302]
operator: , [44419,44420]
===
match
---
string: "__type" [5297,5305]
string: "__type" [5313,5321]
===
match
---
operator: , [32027,32028]
operator: , [32145,32146]
===
match
---
string: '__var' [4194,4201]
string: '__var' [4210,4217]
===
match
---
arglist [31968,32034]
arglist [32086,32152]
===
match
---
assert_stmt [28565,28654]
assert_stmt [28683,28772]
===
match
---
simple_stmt [11733,11766]
simple_stmt [11749,11782]
===
match
---
string: "tasks" [17207,17214]
string: "tasks" [17325,17332]
===
match
---
fstring [29220,29270]
fstring [29338,29388]
===
match
---
atom [44634,44636]
atom [44752,44754]
===
match
---
string: "_inlets" [3420,3429]
string: "_inlets" [3436,3445]
===
match
---
name: relativedelta [1069,1082]
name: relativedelta [1085,1098]
===
match
---
operator: , [39581,39582]
operator: , [39699,39700]
===
match
---
atom_expr [8628,8640]
atom_expr [8644,8656]
===
match
---
decorator [29500,31559]
decorator [29618,31677]
===
match
---
name: CustomOperator [26885,26899]
name: CustomOperator [27003,27017]
===
match
---
operator: = [1892,1893]
operator: = [1908,1909]
===
match
---
argument [9095,9492]
argument [9111,9508]
===
match
---
comparison [42333,42387]
comparison [42451,42505]
===
match
---
trailer [5644,5649]
trailer [5660,5665]
===
match
---
trailer [8852,8880]
trailer [8868,8896]
===
match
---
assert_stmt [27024,27082]
assert_stmt [27142,27200]
===
match
---
comparison [15454,15476]
comparison [15470,15492]
===
match
---
simple_stmt [12520,12572]
simple_stmt [12536,12588]
===
match
---
atom_expr [36824,36887]
atom_expr [36942,37005]
===
match
---
operator: = [33099,33100]
operator: = [33217,33218]
===
match
---
assert_stmt [33689,33720]
assert_stmt [33807,33838]
===
match
---
number: 8 [17966,17967]
number: 8 [18084,18085]
===
match
---
name: SerializedDAG [23416,23429]
name: SerializedDAG [23534,23547]
===
match
---
trailer [22353,22360]
trailer [22471,22478]
===
match
---
operator: , [19275,19276]
operator: , [19393,19394]
===
match
---
argument [30999,31023]
argument [31117,31141]
===
match
---
operator: , [16252,16253]
operator: , [16268,16269]
===
match
---
name: execution_date [7268,7282]
name: execution_date [7284,7298]
===
match
---
arglist [26834,26875]
arglist [26952,26993]
===
match
---
name: task_dict [19040,19049]
name: task_dict [19158,19167]
===
match
---
name: directory [8407,8416]
name: directory [8423,8432]
===
match
---
trailer [32304,32312]
trailer [32422,32430]
===
match
---
dictorsetmaker [30167,30196]
dictorsetmaker [30285,30314]
===
match
---
arglist [18506,18560]
arglist [18624,18678]
===
match
---
operator: } [41464,41465]
operator: } [41582,41583]
===
match
---
trailer [9896,9906]
trailer [9912,9922]
===
match
---
trailer [9863,9868]
trailer [9879,9884]
===
match
---
name: task [28068,28072]
name: task [28186,28190]
===
match
---
name: task [14933,14937]
name: task [14949,14953]
===
match
---
string: "retries" [6029,6038]
string: "retries" [6045,6054]
===
match
---
operator: } [7395,7396]
operator: } [7411,7412]
===
match
---
string: 'dag' [10309,10314]
string: 'dag' [10325,10330]
===
match
---
string: "dag" [10822,10827]
string: "dag" [10838,10843]
===
match
---
dotted_name [21821,21841]
dotted_name [21939,21959]
===
match
---
operator: , [17908,17909]
operator: , [18026,18027]
===
match
---
name: BaseOperator [25400,25412]
name: BaseOperator [25518,25530]
===
match
---
name: value [29166,29171]
name: value [29284,29289]
===
match
---
assert_stmt [45592,45635]
assert_stmt [45710,45753]
===
match
---
operator: { [2605,2606]
operator: { [2621,2622]
===
match
---
arglist [40801,40875]
arglist [40919,40993]
===
match
---
name: log_output [25874,25884]
name: log_output [25992,26002]
===
match
---
operator: = [33528,33529]
operator: = [33646,33647]
===
match
---
arglist [28781,28807]
arglist [28899,28925]
===
match
---
simple_stmt [44119,44193]
simple_stmt [44237,44311]
===
match
---
arglist [23241,23251]
arglist [23359,23369]
===
match
---
name: dag [11733,11736]
name: dag [11749,11752]
===
match
---
atom [32825,32992]
atom [32943,33110]
===
match
---
string: 'blah' [25721,25727]
string: 'blah' [25839,25845]
===
match
---
trailer [14344,14364]
trailer [14360,14380]
===
match
---
simple_stmt [11581,11594]
simple_stmt [11597,11610]
===
match
---
param [33284,33288]
param [33402,33406]
===
match
---
atom [30021,30103]
atom [30139,30221]
===
match
---
trailer [10234,10245]
trailer [10250,10261]
===
match
---
simple_stmt [25173,25247]
simple_stmt [25291,25365]
===
match
---
dotted_name [1336,1363]
dotted_name [1352,1379]
===
match
---
param [12613,12628]
param [12629,12644]
===
match
---
with_stmt [37067,37215]
with_stmt [37185,37333]
===
match
---
number: 1 [40959,40960]
number: 1 [41077,41078]
===
match
---
operator: { [7359,7360]
operator: { [7375,7376]
===
match
---
name: serialized_dag [13447,13461]
name: serialized_dag [13463,13477]
===
match
---
operator: , [2407,2408]
operator: , [2423,2424]
===
match
---
number: 2019 [7383,7387]
number: 2019 [7399,7403]
===
match
---
name: _serialize [44232,44242]
name: _serialize [44350,44360]
===
match
---
operator: , [17860,17861]
operator: , [17978,17979]
===
match
---
name: serialized_objects [1585,1603]
name: serialized_objects [1601,1619]
===
match
---
string: "UTC" [5249,5254]
string: "UTC" [5265,5270]
===
match
---
simple_stmt [21144,21222]
simple_stmt [21262,21340]
===
match
---
name: dag [16767,16770]
name: dag [16885,16888]
===
match
---
operator: , [34349,34350]
operator: , [34467,34468]
===
match
---
string: 'pool_slots' [35290,35302]
string: 'pool_slots' [35408,35420]
===
match
---
trailer [37249,37266]
trailer [37367,37384]
===
match
---
name: dag_id [13220,13226]
name: dag_id [13236,13242]
===
match
---
suite [17444,17718]
suite [17562,17836]
===
match
---
string: "dict" [43478,43484]
string: "dict" [43596,43602]
===
match
---
decorated [41349,42531]
decorated [41467,42649]
===
match
---
operator: { [7945,7946]
operator: { [7961,7962]
===
match
---
operator: , [30061,30062]
operator: , [30179,30180]
===
match
---
suite [40398,41344]
suite [40516,41462]
===
match
---
string: "dag" [10752,10757]
string: "dag" [10768,10773]
===
match
---
trailer [13461,13474]
trailer [13477,13490]
===
match
---
dotted_name [1271,1285]
dotted_name [1287,1301]
===
match
---
assert_stmt [20908,20935]
assert_stmt [21026,21053]
===
match
---
atom [17874,18066]
atom [17992,18184]
===
match
---
suite [39717,39784]
suite [39835,39902]
===
match
---
name: task_id [33664,33671]
name: task_id [33782,33789]
===
match
---
simple_stmt [900,916]
simple_stmt [900,916]
===
match
---
name: SerializedBaseOperator [38342,38364]
name: SerializedBaseOperator [38460,38482]
===
match
---
operator: == [20824,20826]
operator: == [20942,20944]
===
match
---
assert_stmt [15527,15577]
assert_stmt [15543,15593]
===
match
---
name: serialized_dag [39291,39305]
name: serialized_dag [39409,39423]
===
match
---
atom_expr [21385,21411]
atom_expr [21503,21529]
===
match
---
name: mock_operators [1671,1685]
name: mock_operators [1687,1701]
===
match
---
name: start_date [32003,32013]
name: start_date [32121,32131]
===
match
---
name: self [26283,26287]
name: self [26401,26405]
===
match
---
name: queue [8706,8711]
name: queue [8722,8727]
===
match
---
arglist [36799,36809]
arglist [36917,36927]
===
match
---
string: '"use_proxy": "False", ' [9371,9395]
string: '"use_proxy": "False", ' [9387,9411]
===
match
---
operator: , [27962,27963]
operator: , [28080,28081]
===
match
---
operator: = [26944,26945]
operator: = [27062,27063]
===
match
---
string: 'simple_dag' [25635,25647]
string: 'simple_dag' [25753,25765]
===
match
---
name: access_control [6326,6340]
name: access_control [6342,6356]
===
match
---
operator: } [33073,33074]
operator: } [33191,33192]
===
match
---
string: "task2" [37041,37048]
string: "task2" [37159,37166]
===
match
---
param [44596,44610]
param [44714,44728]
===
match
---
trailer [9081,9502]
trailer [9097,9518]
===
match
---
operator: = [45730,45731]
operator: = [45848,45849]
===
match
---
operator: = [18586,18587]
operator: = [18704,18705]
===
match
---
operator: , [19338,19339]
operator: , [19456,19457]
===
match
---
if_stmt [21420,21552]
if_stmt [21538,21670]
===
match
---
string: "{{ task.task_id }}" [29939,29959]
string: "{{ task.task_id }}" [30057,30077]
===
match
---
operator: = [25659,25660]
operator: = [25777,25778]
===
match
---
arglist [18408,18483]
arglist [18526,18601]
===
match
---
expr_stmt [10709,10800]
expr_stmt [10725,10816]
===
match
---
name: dag [13264,13267]
name: dag [13280,13283]
===
match
---
operator: { [2321,2322]
operator: { [2337,2338]
===
match
---
funcdef [5726,5863]
funcdef [5742,5879]
===
match
---
string: "base" [1893,1899]
string: "base" [1909,1915]
===
match
---
name: deserialized_dag [21728,21744]
name: deserialized_dag [21846,21862]
===
match
---
string: 'dummy' [33672,33679]
string: 'dummy' [33790,33797]
===
match
---
operator: = [11414,11415]
operator: = [11430,11431]
===
match
---
name: self [13774,13778]
name: self [13790,13794]
===
match
---
operator: = [7621,7622]
operator: = [7637,7638]
===
match
---
operator: { [7653,7654]
operator: { [7669,7670]
===
match
---
operator: , [16437,16438]
operator: , [16453,16454]
===
match
---
atom [24099,24101]
atom [24217,24219]
===
match
---
atom_expr [41285,41325]
atom_expr [41403,41443]
===
match
---
number: 30 [18175,18177]
number: 30 [18293,18295]
===
match
---
return_stmt [39771,39783]
return_stmt [39889,39901]
===
match
---
operator: - [14421,14422]
operator: - [14437,14438]
===
match
---
name: k [13298,13299]
name: k [13314,13315]
===
match
---
return_stmt [7839,7863]
return_stmt [7855,7879]
===
match
---
operator: = [11847,11848]
operator: = [11863,11864]
===
match
---
name: bash_command [7742,7754]
name: bash_command [7758,7770]
===
match
---
trailer [38041,38060]
trailer [38159,38178]
===
match
---
simple_stmt [45132,45208]
simple_stmt [45250,45326]
===
match
---
string: "ClassWithCustomAttributes(" [30474,30502]
string: "ClassWithCustomAttributes(" [30592,30620]
===
match
---
name: task [14392,14396]
name: task [14408,14412]
===
match
---
trailer [41301,41325]
trailer [41419,41443]
===
match
---
string: "tasks" [23498,23505]
string: "tasks" [23616,23623]
===
match
---
string: "default_pool" [5147,5161]
string: "default_pool" [5163,5177]
===
match
---
name: utc [18255,18258]
name: utc [18373,18376]
===
match
---
atom_expr [30713,30864]
atom_expr [30831,30982]
===
match
---
simple_stmt [25738,25782]
simple_stmt [25856,25900]
===
match
---
atom_expr [29115,29129]
atom_expr [29233,29247]
===
match
---
fstring_start: f" [8425,8427]
fstring_start: f" [8441,8443]
===
match
---
name: values [12417,12423]
name: values [12433,12439]
===
match
---
comp_op [42359,42365]
comp_op [42477,42483]
===
match
---
simple_stmt [15813,15855]
simple_stmt [15829,15871]
===
match
---
atom_expr [25898,25937]
atom_expr [26016,26055]
===
match
---
simple_stmt [33730,33783]
simple_stmt [33848,33901]
===
match
---
simple_stmt [7938,7948]
simple_stmt [7954,7964]
===
match
---
name: datetime [17892,17900]
name: datetime [18010,18018]
===
match
---
string: "this" [43166,43172]
string: "this" [43284,43290]
===
match
---
string: "test_role" [10949,10960]
string: "test_role" [10965,10976]
===
match
---
name: task_id [34162,34169]
name: task_id [34280,34287]
===
match
---
operator: , [7387,7388]
operator: , [7403,7404]
===
match
---
name: dag [38061,38064]
name: dag [38179,38182]
===
match
---
name: simple_task [24285,24296]
name: simple_task [24403,24414]
===
match
---
import_from [38691,38740]
import_from [38809,38858]
===
match
---
number: 1 [20393,20394]
number: 1 [20511,20512]
===
match
---
name: test_operator_subclass_changing_base_defaults [33238,33283]
name: test_operator_subclass_changing_base_defaults [33356,33401]
===
match
---
name: executor_config_pod [1735,1754]
name: executor_config_pod [1751,1770]
===
match
---
name: ACTION_CAN_EDIT [6397,6412]
name: ACTION_CAN_EDIT [6413,6428]
===
match
---
atom [20346,20408]
atom [20464,20526]
===
match
---
name: dags [7938,7942]
name: dags [7954,7958]
===
match
---
trailer [18946,18955]
trailer [19064,19073]
===
match
---
string: "foo" [29851,29856]
string: "foo" [29969,29974]
===
match
---
name: SerializedDAG [12456,12469]
name: SerializedDAG [12472,12485]
===
match
---
simple_stmt [22320,22373]
simple_stmt [22438,22491]
===
match
---
name: to_dict [39096,39103]
name: to_dict [39214,39221]
===
match
---
trailer [27002,27010]
trailer [27120,27128]
===
match
---
name: field [15308,15313]
name: field [15324,15329]
===
match
---
atom_expr [11072,11103]
atom_expr [11088,11119]
===
match
---
name: patch [44899,44904]
name: patch [45017,45022]
===
match
---
string: 'prefix_group_id' [2556,2573]
string: 'prefix_group_id' [2572,2589]
===
match
---
trailer [20464,20476]
trailer [20582,20594]
===
match
---
name: keys [11942,11946]
name: keys [11958,11962]
===
match
---
operator: @ [20177,20178]
operator: @ [20295,20296]
===
match
---
atom_expr [22339,22372]
atom_expr [22457,22490]
===
match
---
operator: } [24101,24102]
operator: } [24219,24220]
===
match
---
param [10114,10123]
param [10130,10139]
===
match
---
name: validate_schema [39131,39146]
name: validate_schema [39249,39264]
===
match
---
trailer [27578,27587]
trailer [27696,27705]
===
match
---
operator: , [19282,19283]
operator: , [19400,19401]
===
match
---
number: 2019 [6266,6270]
number: 2019 [6282,6286]
===
match
---
operator: , [18427,18428]
operator: , [18545,18546]
===
match
---
argument [32095,32123]
argument [32213,32241]
===
match
---
string: '"use_ssl": "False"' [9416,9436]
string: '"use_ssl": "False"' [9432,9452]
===
match
---
simple_stmt [42159,42203]
simple_stmt [42277,42321]
===
match
---
name: dag [7300,7303]
name: dag [7316,7319]
===
match
---
trailer [38546,38557]
trailer [38664,38675]
===
match
---
atom_expr [45139,45207]
atom_expr [45257,45325]
===
match
---
operator: { [8441,8442]
operator: { [8457,8458]
===
match
---
trailer [32703,32717]
trailer [32821,32835]
===
match
---
operator: = [1857,1858]
operator: = [1873,1874]
===
match
---
fstring_expr [8441,8450]
fstring_expr [8457,8466]
===
match
---
name: DAG [5960,5963]
name: DAG [5976,5979]
===
match
---
operator: , [15907,15908]
operator: , [15923,15924]
===
match
---
operator: , [39587,39588]
operator: , [39705,39706]
===
match
---
arglist [40950,40960]
arglist [41068,41078]
===
match
---
string: 'children' [2593,2603]
string: 'children' [2609,2619]
===
match
---
name: dag_folder [7883,7893]
name: dag_folder [7899,7909]
===
match
---
operator: } [29595,29596]
operator: } [29713,29714]
===
match
---
trailer [34482,34484]
trailer [34600,34602]
===
match
---
operator: = [28072,28073]
operator: = [28190,28191]
===
match
---
operator: = [16786,16787]
operator: = [16904,16905]
===
match
---
string: "bar" [29973,29978]
string: "bar" [30091,30096]
===
match
---
name: compute_next_execution_date [7553,7580]
name: compute_next_execution_date [7569,7596]
===
match
---
atom [41395,41441]
atom [41513,41559]
===
match
---
operator: } [29847,29848]
operator: } [29965,29966]
===
match
---
trailer [5687,5697]
trailer [5703,5713]
===
match
---
atom_expr [37602,37634]
atom_expr [37720,37752]
===
match
---
with_stmt [36819,37326]
with_stmt [36937,37444]
===
match
---
name: start_date [17483,17493]
name: start_date [17601,17611]
===
match
---
trailer [38172,38193]
trailer [38290,38311]
===
match
---
name: expected_output [44427,44442]
name: expected_output [44545,44560]
===
match
---
operator: , [35640,35641]
operator: , [35758,35759]
===
match
---
name: BaseHook [1199,1207]
name: BaseHook [1215,1223]
===
match
---
operator: = [23414,23415]
operator: = [23532,23533]
===
match
---
name: serialized_dag [23974,23988]
name: serialized_dag [24092,24106]
===
match
---
operator: , [14574,14575]
operator: , [14590,14591]
===
match
---
name: ti [28050,28052]
name: ti [28168,28170]
===
match
---
argument [7496,7591]
argument [7512,7607]
===
match
---
simple_stmt [40885,40963]
simple_stmt [41003,41081]
===
match
---
with_item [25624,25688]
with_item [25742,25806]
===
match
---
name: dag [40921,40924]
name: dag [41039,41042]
===
match
---
arglist [1888,1969]
arglist [1904,1985]
===
match
---
name: Connection [9108,9118]
name: Connection [9124,9134]
===
match
---
fstring_expr [13611,13623]
fstring_expr [13627,13639]
===
match
---
assert_stmt [19073,19126]
assert_stmt [19191,19244]
===
match
---
name: google_link_from_plugin [28852,28875]
name: google_link_from_plugin [28970,28993]
===
match
---
string: 'task_4' [42775,42783]
string: 'task_4' [42893,42901]
===
match
---
trailer [40104,40110]
trailer [40222,40228]
===
match
---
name: SerializedDAG [21580,21593]
name: SerializedDAG [21698,21711]
===
match
---
simple_stmt [44481,44566]
simple_stmt [44599,44684]
===
match
---
name: execution_date [36773,36787]
name: execution_date [36891,36905]
===
match
---
name: deserialize_operator [38152,38172]
name: deserialize_operator [38270,38290]
===
match
---
operator: { [29818,29819]
operator: { [29936,29937]
===
match
---
dictorsetmaker [3160,4380]
dictorsetmaker [3176,4396]
===
match
---
trailer [45547,45550]
trailer [45665,45668]
===
match
---
atom_expr [17769,17810]
atom_expr [17887,17928]
===
match
---
expr_stmt [9724,9744]
expr_stmt [9740,9760]
===
match
---
trailer [44242,44264]
trailer [44360,44382]
===
match
---
number: 7 [7389,7390]
number: 7 [7405,7406]
===
match
---
atom [30640,31541]
atom [30758,31659]
===
match
---
atom_expr [27049,27082]
atom_expr [27167,27200]
===
match
---
name: dag [8875,8878]
name: dag [8891,8894]
===
match
---
number: 300.0 [2278,2283]
number: 300.0 [2294,2299]
===
match
---
operator: = [17232,17233]
operator: = [17350,17351]
===
match
---
expr_stmt [22465,22523]
expr_stmt [22583,22641]
===
match
---
operator: , [25317,25318]
operator: , [25435,25436]
===
match
---
operator: , [19895,19896]
operator: , [20013,20014]
===
match
---
trailer [37530,37545]
trailer [37648,37663]
===
match
---
operator: , [43797,43798]
operator: , [43915,43916]
===
match
---
string: 'downstream_group_ids' [2844,2866]
string: 'downstream_group_ids' [2860,2882]
===
match
---
operator: = [16770,16771]
operator: = [16888,16889]
===
match
---
name: SerializedDAG [27098,27111]
name: SerializedDAG [27216,27229]
===
match
---
simple_stmt [28050,28112]
simple_stmt [28168,28230]
===
match
---
name: name [44590,44594]
name: name [44708,44712]
===
match
---
trailer [16366,16399]
trailer [16382,16415]
===
match
---
name: group234 [36989,36997]
name: group234 [37107,37115]
===
match
---
name: simple_task [17340,17351]
name: simple_task [17458,17469]
===
match
---
name: get_connection [9055,9069]
name: get_connection [9071,9085]
===
match
---
simple_stmt [28238,28322]
simple_stmt [28356,28440]
===
match
---
name: default_args [13570,13582]
name: default_args [13586,13598]
===
match
---
string: '.' [44689,44692]
string: '.' [44807,44810]
===
match
---
name: from_dict [45929,45938]
name: from_dict [46047,46056]
===
match
---
name: SerializedDAG [39176,39189]
name: SerializedDAG [39294,39307]
===
match
---
atom [26945,26961]
atom [27063,27079]
===
match
---
atom_expr [12090,12114]
atom_expr [12106,12130]
===
match
---
atom [21890,21912]
atom [22008,22030]
===
match
---
operator: { [2087,2088]
operator: { [2103,2104]
===
match
---
name: SerializedDAG [41229,41242]
name: SerializedDAG [41347,41360]
===
match
---
argument [39810,39825]
argument [39928,39943]
===
match
---
name: utc [18135,18138]
name: utc [18253,18256]
===
match
---
name: datetime [18217,18225]
name: datetime [18335,18343]
===
match
---
trailer [1827,1837]
trailer [1843,1853]
===
match
---
dotted_name [15984,16004]
dotted_name [16000,16020]
===
match
---
name: set [32819,32822]
name: set [32937,32940]
===
match
---
trailer [37463,37491]
trailer [37581,37609]
===
match
---
name: test_deserialization_end_date [18300,18329]
name: test_deserialization_end_date [18418,18447]
===
match
---
number: 2019 [18449,18453]
number: 2019 [18567,18571]
===
match
---
name: print [40242,40247]
name: print [40360,40365]
===
match
---
name: get_extra_links [28272,28287]
name: get_extra_links [28390,28405]
===
match
---
name: blob [40031,40035]
name: blob [40149,40153]
===
match
---
operator: , [16120,16121]
operator: , [16136,16137]
===
match
---
string: "__type" [19298,19306]
string: "__type" [19416,19424]
===
match
---
atom [3615,3638]
atom [3631,3654]
===
match
---
simple_stmt [34184,34216]
simple_stmt [34302,34334]
===
match
---
operator: = [23363,23364]
operator: = [23481,23482]
===
match
---
name: dag [23438,23441]
name: dag [23556,23559]
===
match
---
name: dag_id [25628,25634]
name: dag_id [25746,25752]
===
match
---
atom [3499,3501]
atom [3515,3517]
===
match
---
dotted_name [20178,20198]
dotted_name [20296,20316]
===
match
---
operator: = [7754,7755]
operator: = [7770,7771]
===
match
---
arglist [30360,30438]
arglist [30478,30556]
===
match
---
factor [20404,20406]
factor [20522,20524]
===
match
---
atom_expr [19359,19376]
atom_expr [19477,19494]
===
match
---
expr_stmt [37015,37049]
expr_stmt [37133,37167]
===
match
---
operator: = [5618,5619]
operator: = [5634,5635]
===
match
---
name: dag [7847,7850]
name: dag [7863,7866]
===
match
---
name: op [40127,40129]
name: op [40245,40247]
===
match
---
number: 10 [6141,6143]
number: 10 [6157,6159]
===
match
---
number: 2019 [17960,17964]
number: 2019 [18078,18082]
===
match
---
operator: , [2689,2690]
operator: , [2705,2706]
===
match
---
name: serialized_dags [9881,9896]
name: serialized_dags [9897,9912]
===
match
---
operator: >> [39028,39030]
operator: >> [39146,39148]
===
match
---
parameters [6867,6869]
parameters [6883,6885]
===
match
---
string: "task1" [36938,36945]
string: "task1" [37056,37063]
===
match
---
atom_expr [9108,9492]
atom_expr [9124,9508]
===
match
---
name: partition [44679,44688]
name: partition [44797,44806]
===
match
---
operator: , [39275,39276]
operator: , [39393,39394]
===
match
---
string: "template_fields_renderers" [4975,5002]
string: "template_fields_renderers" [4991,5018]
===
match
---
trailer [22585,22600]
trailer [22703,22718]
===
match
---
dotted_name [1173,1191]
dotted_name [1189,1207]
===
match
---
arglist [24345,24376]
arglist [24463,24494]
===
match
---
atom_expr [11953,11969]
atom_expr [11969,11985]
===
match
---
operator: , [42697,42698]
operator: , [42815,42816]
===
match
---
string: 'task_2' [43965,43973]
string: 'task_2' [44083,44091]
===
match
---
dictorsetmaker [2246,2283]
dictorsetmaker [2262,2299]
===
match
---
simple_stmt [15527,15578]
simple_stmt [15543,15594]
===
match
---
expr_stmt [36908,36946]
expr_stmt [37026,37064]
===
match
---
atom [7359,7396]
atom [7375,7412]
===
match
---
suite [29299,29334]
suite [29417,29452]
===
match
---
argument [39838,39854]
argument [39956,39972]
===
match
---
name: op [33648,33650]
name: op [33766,33768]
===
match
---
dictorsetmaker [20285,20295]
dictorsetmaker [20403,20413]
===
match
---
dictorsetmaker [14470,14877]
dictorsetmaker [14486,14893]
===
match
---
operator: { [20478,20479]
operator: { [20596,20597]
===
match
---
name: TaskGroup [36754,36763]
name: TaskGroup [36872,36881]
===
match
---
name: is_subdag [8652,8661]
name: is_subdag [8668,8677]
===
match
---
simple_stmt [12059,12130]
simple_stmt [12075,12146]
===
match
---
name: dags [8589,8593]
name: dags [8605,8609]
===
match
---
except_clause [37894,37915]
except_clause [38012,38033]
===
match
---
arglist [12090,12128]
arglist [12106,12144]
===
match
---
testlist_comp [29922,30002]
testlist_comp [30040,30120]
===
match
---
name: dag [39222,39225]
name: dag [39340,39343]
===
match
---
simple_stmt [14374,14888]
simple_stmt [14390,14904]
===
match
---
name: os [5711,5713]
name: os [5727,5729]
===
match
---
operator: , [19686,19687]
operator: , [19804,19805]
===
match
---
arglist [37531,37544]
arglist [37649,37662]
===
match
---
annassign [32650,32717]
annassign [32768,32835]
===
match
---
name: BashOperator [6533,6545]
name: BashOperator [6549,6561]
===
match
---
name: serialized_dag [13136,13150]
name: serialized_dag [13152,13166]
===
match
---
trailer [24461,24477]
trailer [24579,24595]
===
match
---
trailer [9118,9492]
trailer [9134,9508]
===
match
---
trailer [19960,19972]
trailer [20078,20090]
===
match
---
operator: , [21350,21351]
operator: , [21468,21469]
===
match
---
param [5748,5759]
param [5764,5775]
===
match
---
atom_expr [18974,19013]
atom_expr [19092,19131]
===
match
---
funcdef [31563,32394]
funcdef [31681,32512]
===
match
---
operator: , [20996,20997]
operator: , [21114,21115]
===
match
---
simple_stmt [8843,8881]
simple_stmt [8859,8897]
===
match
---
suite [29130,29173]
suite [29248,29291]
===
match
---
trailer [39240,39266]
trailer [39358,39384]
===
match
---
string: "simple_task" [27174,27187]
string: "simple_task" [27292,27305]
===
match
---
operator: { [4071,4072]
operator: { [4087,4088]
===
match
---
trailer [18601,18609]
trailer [18719,18727]
===
match
---
atom [41463,41465]
atom [41581,41583]
===
match
---
name: dag [23360,23363]
name: dag [23478,23481]
===
match
---
simple_stmt [27146,27189]
simple_stmt [27264,27307]
===
match
---
trailer [38151,38172]
trailer [38269,38290]
===
match
---
assert_stmt [33866,33908]
assert_stmt [33984,34026]
===
match
---
name: datetime [21337,21345]
name: datetime [21455,21463]
===
match
---
comparison [24523,24603]
comparison [24641,24721]
===
match
---
operator: { [19655,19656]
operator: { [19773,19774]
===
match
---
param [7639,7643]
param [7655,7659]
===
match
---
param [40382,40396]
param [40500,40514]
===
match
---
string: "'nested2': ClassWithCustomAttributes({'att3': '{{ task.task_id }}', 'att4': " [31344,31422]
string: "'nested2': ClassWithCustomAttributes({'att3': '{{ task.task_id }}', 'att4': " [31462,31540]
===
match
---
atom_expr [38342,38389]
atom_expr [38460,38507]
===
match
---
name: task_id [23337,23344]
name: task_id [23455,23462]
===
match
---
name: datetime [16358,16366]
name: datetime [16374,16382]
===
match
---
suite [37104,37215]
suite [37222,37333]
===
match
---
operator: , [18233,18234]
operator: , [18351,18352]
===
match
---
comparison [19080,19126]
comparison [19198,19244]
===
match
---
name: validate_schema [19945,19960]
name: validate_schema [20063,20078]
===
match
---
name: relativedelta [20313,20326]
name: relativedelta [20431,20444]
===
match
---
argument [23360,23367]
argument [23478,23485]
===
match
---
name: to_dict [22279,22286]
name: to_dict [22397,22404]
===
match
---
name: deserialized_dag [21655,21671]
name: deserialized_dag [21773,21789]
===
match
---
arglist [23271,23312]
arglist [23389,23430]
===
match
---
fstring_start: f' [13609,13611]
fstring_start: f' [13625,13627]
===
match
---
trailer [32353,32393]
trailer [32471,32511]
===
match
---
operator: , [35034,35035]
operator: , [35152,35153]
===
match
---
name: task [14108,14112]
name: task [14124,14128]
===
match
---
name: SerializedDAG [16830,16843]
name: SerializedDAG [16948,16961]
===
match
---
atom [30225,30265]
atom [30343,30383]
===
match
---
operator: , [43227,43228]
operator: , [43345,43346]
===
match
---
name: base_operator [34193,34206]
name: base_operator [34311,34324]
===
match
---
string: "{{ task.task_id }}" [29866,29886]
string: "{{ task.task_id }}" [29984,30004]
===
match
---
simple_stmt [27092,27138]
simple_stmt [27210,27256]
===
match
---
trailer [16485,16518]
trailer [16501,16534]
===
match
---
operator: = [32657,32658]
operator: = [32775,32776]
===
match
---
string: "dag" [17117,17122]
string: "dag" [17235,17240]
===
match
---
operator: , [16289,16290]
operator: , [16305,16306]
===
match
---
dictorsetmaker [27906,28030]
dictorsetmaker [28024,28148]
===
match
---
trailer [13843,13852]
trailer [13859,13868]
===
match
---
param [18365,18387]
param [18483,18505]
===
match
---
atom [43352,43412]
atom [43470,43530]
===
match
---
operator: , [19485,19486]
operator: , [19603,19604]
===
match
---
name: validate_serialized_dag [9984,10007]
name: validate_serialized_dag [10000,10023]
===
match
---
trailer [38060,38088]
trailer [38178,38206]
===
match
---
operator: , [16774,16775]
operator: , [16892,16893]
===
match
---
trailer [7963,7982]
trailer [7979,7998]
===
match
---
simple_stmt [25898,25938]
simple_stmt [26016,26056]
===
match
---
atom_expr [14334,14364]
atom_expr [14350,14380]
===
match
---
number: 2 [17969,17970]
number: 2 [18087,18088]
===
match
---
string: "__type" [20248,20256]
string: "__type" [20366,20374]
===
match
---
operator: , [3578,3579]
operator: , [3594,3595]
===
match
---
string: "task_id" [3160,3169]
string: "task_id" [3176,3185]
===
match
---
atom_expr [9834,9868]
atom_expr [9850,9884]
===
match
---
operator: , [3084,3085]
operator: , [3100,3101]
===
match
---
name: deserialized_dag [41210,41226]
name: deserialized_dag [41328,41344]
===
match
---
trailer [29487,29494]
trailer [29605,29612]
===
match
---
atom [20993,20995]
atom [21111,21113]
===
match
---
assert_stmt [38335,38406]
assert_stmt [38453,38524]
===
match
---
operator: , [13838,13839]
operator: , [13854,13855]
===
match
---
string: "hi" [40248,40252]
string: "hi" [40366,40370]
===
match
---
name: task [15454,15458]
name: task [15470,15474]
===
match
---
trailer [13718,13723]
trailer [13734,13739]
===
match
---
operator: = [44368,44369]
operator: = [44486,44487]
===
match
---
param [44071,44092]
param [44189,44210]
===
match
---
simple_stmt [16813,16857]
simple_stmt [16931,16975]
===
match
---
argument [38970,38985]
argument [39088,39103]
===
match
---
trailer [27010,27015]
trailer [27128,27133]
===
match
---
name: dag [22287,22290]
name: dag [22405,22408]
===
match
---
simple_stmt [12643,12797]
simple_stmt [12659,12813]
===
match
---
arglist [18107,18138]
arglist [18225,18256]
===
match
---
name: from_dict [22498,22507]
name: from_dict [22616,22625]
===
match
---
string: "foo" [29766,29771]
string: "foo" [29884,29889]
===
match
---
dictorsetmaker [34245,35834]
dictorsetmaker [34363,35952]
===
match
---
trailer [45275,45282]
trailer [45393,45400]
===
match
---
simple_stmt [22024,22102]
simple_stmt [22142,22220]
===
match
---
operator: , [32001,32002]
operator: , [32119,32120]
===
match
---
operator: = [1780,1781]
operator: = [1796,1797]
===
match
---
simple_stmt [42465,42531]
simple_stmt [42583,42649]
===
match
---
operator: { [14423,14424]
operator: { [14439,14440]
===
match
---
atom_expr [17818,17859]
atom_expr [17936,17977]
===
match
---
number: 2019 [16038,16042]
number: 2019 [16054,16058]
===
match
---
simple_stmt [8667,8679]
simple_stmt [8683,8695]
===
match
---
import_name [867,889]
import_name [867,889]
===
match
---
trailer [39146,39156]
trailer [39264,39274]
===
match
---
atom_expr [6385,6412]
atom_expr [6401,6428]
===
match
---
atom_expr [22632,22663]
atom_expr [22750,22781]
===
match
---
name: BaseOperator [17557,17569]
name: BaseOperator [17675,17687]
===
match
---
name: set [33182,33185]
name: set [33300,33303]
===
match
---
operator: = [30795,30796]
operator: = [30913,30914]
===
match
---
name: dag_end_date [18471,18483]
name: dag_end_date [18589,18601]
===
match
---
trailer [17704,17712]
trailer [17822,17830]
===
match
---
name: start_date [23292,23302]
name: start_date [23410,23420]
===
match
---
name: task [15159,15163]
name: task [15175,15179]
===
match
---
name: serialized_dag [41253,41267]
name: serialized_dag [41371,41385]
===
match
---
param [41544,41568]
param [41662,41686]
===
match
---
dotted_name [20942,20962]
dotted_name [21060,21080]
===
match
---
name: field [13152,13157]
name: field [13168,13173]
===
match
---
string: "airflow/providers/*/example_dags" [8270,8304]
string: "airflow/providers/*/example_dags" [8286,8320]
===
match
---
atom_expr [20107,20139]
atom_expr [20225,20257]
===
match
---
trailer [16188,16192]
trailer [16204,16208]
===
match
---
simple_stmt [39962,39984]
simple_stmt [40080,40102]
===
match
---
name: datetime [16078,16086]
name: datetime [16094,16102]
===
match
---
operator: , [34929,34930]
operator: , [35047,35048]
===
match
---
param [14108,14113]
param [14124,14129]
===
match
---
name: getattr [15242,15249]
name: getattr [15258,15265]
===
match
---
atom_expr [24489,24506]
atom_expr [24607,24624]
===
match
---
operator: @ [20941,20942]
operator: @ [21059,21060]
===
match
---
name: dag_end_date [18647,18659]
name: dag_end_date [18765,18777]
===
match
---
name: SerializedDAG [22265,22278]
name: SerializedDAG [22383,22396]
===
match
---
name: task [14345,14349]
name: task [14361,14365]
===
match
---
argument [30791,30816]
argument [30909,30934]
===
match
---
name: expected_deserialized [38268,38289]
name: expected_deserialized [38386,38407]
===
match
---
operator: = [16504,16505]
operator: = [16520,16521]
===
match
---
operator: = [38926,38927]
operator: = [39044,39045]
===
match
---
string: "start_date" [17082,17094]
string: "start_date" [17200,17212]
===
match
---
name: serialized_dag [37652,37666]
name: serialized_dag [37770,37784]
===
match
---
arglist [16220,16251]
arglist [16236,16267]
===
match
---
param [10780,10781]
param [10796,10797]
===
match
---
operator: - [33124,33125]
operator: - [33242,33243]
===
match
---
argument [21294,21315]
argument [21412,21433]
===
match
---
name: expected [20736,20744]
name: expected [20854,20862]
===
match
---
argument [1888,1899]
argument [1904,1915]
===
match
---
name: utc [17806,17809]
name: utc [17924,17927]
===
match
---
atom [4071,4299]
atom [4087,4315]
===
match
---
atom [33035,33074]
atom [33153,33192]
===
match
---
operator: , [43131,43132]
operator: , [43249,43250]
===
match
---
simple_stmt [40791,40877]
simple_stmt [40909,40995]
===
match
---
operator: , [16070,16071]
operator: , [16086,16087]
===
match
---
name: dags [8773,8777]
name: dags [8789,8793]
===
match
---
string: "my-vol" [1939,1947]
string: "my-vol" [1955,1963]
===
match
---
operator: >> [37285,37287]
operator: >> [37403,37405]
===
match
---
name: field [15197,15202]
name: field [15213,15218]
===
match
---
operator: { [24099,24100]
operator: { [24217,24218]
===
match
---
atom_expr [44894,44955]
atom_expr [45012,45073]
===
match
---
trailer [20595,20610]
trailer [20713,20728]
===
match
---
operator: , [41441,41442]
operator: , [41559,41560]
===
match
---
atom [28149,28183]
atom [28267,28301]
===
match
---
trailer [10828,10847]
trailer [10844,10863]
===
match
---
comparison [29387,29418]
comparison [29505,29536]
===
match
---
trailer [34347,34349]
trailer [34465,34467]
===
match
---
atom_expr [5820,5839]
atom_expr [5836,5855]
===
match
---
atom [27718,27789]
atom [27836,27907]
===
match
---
name: dag [19982,19985]
name: dag [20100,20103]
===
match
---
string: "dict" [43363,43369]
string: "dict" [43481,43487]
===
match
---
operator: { [4777,4778]
operator: { [4793,4794]
===
match
---
comparison [15242,15327]
comparison [15258,15343]
===
match
---
name: BaseOperatorLink [1385,1401]
name: BaseOperatorLink [1401,1417]
===
match
---
funcdef [6829,7864]
funcdef [6845,7880]
===
match
---
assert_stmt [22609,22663]
assert_stmt [22727,22781]
===
match
---
trailer [1887,1970]
trailer [1903,1986]
===
match
---
atom_expr [22217,22237]
atom_expr [22335,22355]
===
match
---
atom [19683,19685]
atom [19801,19803]
===
match
---
simple_stmt [39618,39670]
simple_stmt [39736,39788]
===
match
---
string: "0 0 * * 0" [19232,19243]
string: "0 0 * * 0" [19350,19361]
===
match
---
simple_stmt [29465,29495]
simple_stmt [29583,29613]
===
match
---
name: sensors [39631,39638]
name: sensors [39749,39756]
===
match
---
trailer [11961,11966]
trailer [11977,11982]
===
match
---
name: MyOperator [33653,33663]
name: MyOperator [33771,33781]
===
match
---
name: do_xcom_push [33516,33528]
name: do_xcom_push [33634,33646]
===
match
---
atom [20581,20670]
atom [20699,20788]
===
match
---
arglist [22226,22236]
arglist [22344,22354]
===
match
---
string: 'search_query' [28133,28147]
string: 'search_query' [28251,28265]
===
match
---
atom_expr [16731,16803]
atom_expr [16849,16921]
===
match
---
operator: = [22216,22217]
operator: = [22334,22335]
===
match
---
atom_expr [13840,13861]
atom_expr [13856,13877]
===
match
---
operator: = [26865,26866]
operator: = [26983,26984]
===
match
---
suite [11698,11721]
suite [11714,11737]
===
match
---
atom_expr [39388,39412]
atom_expr [39506,39530]
===
match
---
atom_expr [40797,40876]
atom_expr [40915,40994]
===
match
---
dictorsetmaker [6029,6226]
dictorsetmaker [6045,6242]
===
match
---
simple_stmt [13973,14024]
simple_stmt [13989,14040]
===
match
---
operator: , [34611,34612]
operator: , [34729,34730]
===
match
---
operator: , [44636,44637]
operator: , [44754,44755]
===
match
---
argument [17515,17534]
argument [17633,17652]
===
match
---
parameters [9590,9596]
parameters [9606,9612]
===
match
---
operator: = [7725,7726]
operator: = [7741,7742]
===
match
---
operator: = [26926,26927]
operator: = [27044,27045]
===
match
---
name: parameterized [39436,39449]
name: parameterized [39554,39567]
===
match
---
trailer [24004,24007]
trailer [24122,24125]
===
match
---
name: dag_id [12107,12113]
name: dag_id [12123,12129]
===
match
---
name: simple_task [17282,17293]
name: simple_task [17400,17411]
===
match
---
simple_stmt [15038,15105]
simple_stmt [15054,15121]
===
match
---
param [25319,25323]
param [25437,25441]
===
match
---
operator: ** [29074,29076]
operator: ** [29192,29194]
===
match
---
operator: @ [29500,29501]
operator: @ [29618,29619]
===
match
---
operator: , [2830,2831]
operator: , [2846,2847]
===
match
---
string: 'label' [3801,3808]
string: 'label' [3817,3824]
===
match
---
operator: = [30364,30365]
operator: = [30482,30483]
===
match
---
name: dags [7987,7991]
name: dags [8003,8007]
===
match
---
name: task_id [32079,32086]
name: task_id [32197,32204]
===
match
---
atom [39509,39529]
atom [39627,39647]
===
match
---
string: "test1" [43790,43797]
string: "test1" [43908,43915]
===
match
---
atom [20612,20669]
atom [20730,20787]
===
match
---
atom [29818,29847]
atom [29936,29965]
===
match
---
string: "params" [22327,22335]
string: "params" [22445,22453]
===
match
---
name: sorted_serialized_dag [10347,10368]
name: sorted_serialized_dag [10363,10384]
===
match
---
param [44065,44070]
param [44183,44188]
===
match
---
string: '#000' [2786,2792]
string: '#000' [2802,2808]
===
match
---
string: "_task_type" [3839,3851]
string: "_task_type" [3855,3867]
===
match
---
name: subdag [15901,15907]
name: subdag [15917,15923]
===
match
---
operator: , [6463,6464]
operator: , [6479,6480]
===
match
---
atom [24204,24252]
atom [24322,24370]
===
match
---
trailer [40800,40876]
trailer [40918,40994]
===
match
---
name: keys [37771,37775]
name: keys [37889,37893]
===
match
---
operator: , [40954,40955]
operator: , [41072,41073]
===
match
---
operator: } [20295,20296]
operator: } [20413,20414]
===
match
---
dictorsetmaker [4097,4277]
dictorsetmaker [4113,4293]
===
match
---
name: json_dag [39165,39173]
name: json_dag [39283,39291]
===
match
---
atom_expr [27557,27615]
atom_expr [27675,27733]
===
match
---
operator: , [4665,4666]
operator: , [4681,4682]
===
match
---
operator: = [44876,44877]
operator: = [44994,44995]
===
match
---
testlist_comp [3616,3637]
testlist_comp [3632,3653]
===
match
---
atom_expr [28792,28807]
atom_expr [28910,28925]
===
match
---
string: "task1" [43781,43788]
string: "task1" [43899,43906]
===
match
---
string: "x" [43979,43982]
string: "x" [44097,44100]
===
match
---
string: "sla" [4578,4583]
string: "sla" [4594,4599]
===
match
---
lambdef [10773,10799]
lambdef [10789,10815]
===
match
---
trailer [37410,37420]
trailer [37528,37538]
===
match
---
operator: = [25528,25529]
operator: = [25646,25647]
===
match
---
operator: , [5493,5494]
operator: , [5509,5510]
===
match
---
dictorsetmaker [21915,21935]
dictorsetmaker [22033,22053]
===
match
---
testlist_comp [3142,5217]
testlist_comp [3158,5233]
===
match
---
trailer [39809,39855]
trailer [39927,39973]
===
match
---
name: task [15302,15306]
name: task [15318,15322]
===
match
---
string: '_upstream_task_ids' [34457,34477]
string: '_upstream_task_ids' [34575,34595]
===
match
---
trailer [45476,45481]
trailer [45594,45599]
===
match
---
trailer [20874,20887]
trailer [20992,21005]
===
match
---
name: update [7957,7963]
name: update [7973,7979]
===
match
---
operator: { [27892,27893]
operator: { [28010,28011]
===
match
---
name: get_extra_links [28765,28780]
name: get_extra_links [28883,28898]
===
match
---
if_stmt [39927,40036]
if_stmt [40045,40154]
===
match
---
operator: { [19572,19573]
operator: { [19690,19691]
===
match
---
param [14083,14099]
param [14099,14115]
===
match
---
atom [15498,15500]
atom [15514,15516]
===
match
---
simple_stmt [27853,28041]
simple_stmt [27971,28159]
===
match
---
simple_stmt [46007,46069]
simple_stmt [46125,46187]
===
match
---
import_from [1450,1490]
import_from [1466,1506]
===
match
---
name: simple_task [19022,19033]
name: simple_task [19140,19151]
===
match
---
trailer [4215,4229]
trailer [4231,4245]
===
match
---
atom_expr [16446,16458]
atom_expr [16462,16474]
===
match
---
atom_expr [38226,38290]
atom_expr [38344,38408]
===
match
---
atom_expr [37184,37214]
atom_expr [37302,37332]
===
match
---
name: k [13583,13584]
name: k [13599,13600]
===
match
---
name: dag_id [7851,7857]
name: dag_id [7867,7873]
===
match
---
operator: { [6689,6690]
operator: { [6705,6706]
===
match
---
name: to_dict [25769,25776]
name: to_dict [25887,25894]
===
match
---
number: 1 [35304,35305]
number: 1 [35422,35423]
===
match
---
string: "true" [23671,23677]
string: "true" [23789,23795]
===
match
---
name: simple_task [27864,27875]
name: simple_task [27982,27993]
===
match
---
simple_stmt [9694,9716]
simple_stmt [9710,9732]
===
match
---
trailer [19039,19049]
trailer [19157,19167]
===
match
---
string: "group234" [36974,36984]
string: "group234" [37092,37102]
===
match
---
name: serialized_dag [42159,42173]
name: serialized_dag [42277,42291]
===
match
---
suite [22386,22456]
suite [22504,22574]
===
match
---
fstring_end: ' [13250,13251]
fstring_end: ' [13266,13267]
===
match
---
argument [16232,16251]
argument [16248,16267]
===
match
---
arglist [30945,31023]
arglist [31063,31141]
===
match
---
trailer [39213,39221]
trailer [39331,39339]
===
match
---
name: pytest [1023,1029]
name: pytest [1039,1045]
===
match
---
trailer [6396,6412]
trailer [6412,6428]
===
match
---
operator: , [3708,3709]
operator: , [3724,3725]
===
match
---
number: 1 [26813,26814]
number: 1 [26931,26932]
===
match
---
suite [18677,18878]
suite [18795,18996]
===
match
---
argument [10769,10799]
argument [10785,10815]
===
match
---
name: start_date [17352,17362]
name: start_date [17470,17480]
===
match
---
funcdef [33497,33639]
funcdef [33615,33757]
===
match
---
name: key [29161,29164]
name: key [29279,29282]
===
match
---
name: self [39236,39240]
name: self [39354,39358]
===
match
---
atom [6689,6726]
atom [6705,6742]
===
match
---
expr_stmt [28238,28321]
expr_stmt [28356,28439]
===
match
---
atom_expr [17458,17536]
atom_expr [17576,17654]
===
match
---
return_stmt [29465,29494]
return_stmt [29583,29612]
===
match
---
string: 'task_5' [43955,43963]
string: 'task_5' [44073,44081]
===
match
---
suite [29084,29173]
suite [29202,29291]
===
match
---
atom [34231,35844]
atom [34349,35962]
===
match
---
atom [34901,34903]
atom [35019,35021]
===
match
---
operator: @ [17723,17724]
operator: @ [17841,17842]
===
match
---
name: permissions [5436,5447]
name: permissions [5452,5463]
===
match
---
trailer [41105,41112]
trailer [41223,41230]
===
match
---
argument [32079,32093]
argument [32197,32211]
===
match
---
name: context [39745,39752]
name: context [39863,39870]
===
match
---
suite [25325,25374]
suite [25443,25492]
===
match
---
operator: , [33514,33515]
operator: , [33632,33633]
===
match
---
expr_stmt [21368,21411]
expr_stmt [21486,21529]
===
match
---
operator: { [2511,2512]
operator: { [2527,2528]
===
match
---
trailer [38863,38875]
trailer [38981,38993]
===
match
---
string: "{'nested1': ClassWithCustomAttributes({'att1': '{{ task.task_id }}', " [31176,31247]
string: "{'nested1': ClassWithCustomAttributes({'att1': '{{ task.task_id }}', " [31294,31365]
===
match
---
string: "dag" [42293,42298]
string: "dag" [42411,42416]
===
match
---
string: "template_fields" [4922,4939]
string: "template_fields" [4938,4955]
===
match
---
operator: , [8711,8712]
operator: , [8727,8728]
===
match
---
simple_stmt [15447,15501]
simple_stmt [15463,15517]
===
match
---
string: 'start_date' [35594,35606]
string: 'start_date' [35712,35724]
===
match
---
trailer [10717,10724]
trailer [10733,10740]
===
match
---
simple_stmt [26824,26877]
simple_stmt [26942,26995]
===
match
---
operator: = [26907,26908]
operator: = [27025,27026]
===
match
---
simple_stmt [28727,28809]
simple_stmt [28845,28927]
===
match
---
name: dag [42108,42111]
name: dag [42226,42229]
===
match
---
name: execution_date [36872,36886]
name: execution_date [36990,37004]
===
match
---
suite [8394,8508]
suite [8410,8524]
===
match
---
name: PodGenerator [4203,4215]
name: PodGenerator [4219,4231]
===
match
---
trailer [37485,37490]
trailer [37603,37608]
===
match
---
operator: , [25676,25677]
operator: , [25794,25795]
===
match
---
name: json_dag [39267,39275]
name: json_dag [39385,39393]
===
match
---
number: 100.0 [4585,4590]
number: 100.0 [4601,4606]
===
match
---
trailer [18046,18050]
trailer [18164,18168]
===
match
---
name: BaseOperator [22149,22161]
name: BaseOperator [22267,22279]
===
match
---
name: downstream_task_ids [15136,15155]
name: downstream_task_ids [15152,15171]
===
match
---
param [29293,29297]
param [29411,29415]
===
match
---
string: "_downstream_task_ids" [3376,3398]
string: "_downstream_task_ids" [3392,3414]
===
match
---
atom [4663,4665]
atom [4679,4681]
===
match
---
name: start_date [6246,6256]
name: start_date [6262,6272]
===
match
---
name: __file__ [19756,19764]
name: __file__ [19874,19882]
===
match
---
string: 'env' [3632,3637]
string: 'env' [3648,3653]
===
match
---
string: "bash_command" [23458,23472]
string: "bash_command" [23576,23590]
===
match
---
string: """A serialized DAG can be deserialized in another process.""" [11164,11226]
string: """A serialized DAG can be deserialized in another process.""" [11180,11242]
===
match
---
string: "_outlets" [4719,4729]
string: "_outlets" [4735,4745]
===
match
---
operator: = [44860,44861]
operator: = [44978,44979]
===
match
---
name: task_id [38079,38086]
name: task_id [38197,38204]
===
match
---
expr_stmt [11448,11545]
expr_stmt [11464,11561]
===
match
---
string: "has_on_failure_callback" [42333,42358]
string: "has_on_failure_callback" [42451,42476]
===
match
---
atom [6341,6414]
atom [6357,6430]
===
match
---
name: fromlist [44861,44869]
name: fromlist [44979,44987]
===
match
---
atom [2944,2946]
atom [2960,2962]
===
match
---
operator: , [5404,5405]
operator: , [5420,5421]
===
match
---
atom_expr [27864,27887]
atom_expr [27982,28005]
===
match
---
string: '_dag' [34294,34300]
string: '_dag' [34412,34418]
===
match
---
operator: ** [42037,42039]
operator: ** [42155,42157]
===
match
---
operator: == [32343,32345]
operator: == [32461,32463]
===
match
---
name: self [40351,40355]
name: self [40469,40473]
===
match
---
operator: , [16193,16194]
operator: , [16209,16210]
===
match
---
operator: , [43556,43557]
operator: , [43674,43675]
===
match
---
name: k8s [1916,1919]
name: k8s [1932,1935]
===
match
---
arglist [21346,21356]
arglist [21464,21474]
===
match
---
string: "test_conf" [43216,43227]
string: "test_conf" [43334,43345]
===
match
---
operator: = [21578,21579]
operator: = [21696,21697]
===
match
---
string: "key:" [43101,43107]
string: "key:" [43219,43225]
===
match
---
name: datetime [16029,16037]
name: datetime [16045,16053]
===
match
---
name: serialized_task [15820,15835]
name: serialized_task [15836,15851]
===
match
---
number: 1 [18028,18029]
number: 1 [18146,18147]
===
match
---
fstring_expr [7653,7659]
fstring_expr [7669,7675]
===
match
---
trailer [7708,7834]
trailer [7724,7850]
===
match
---
name: serialized_dag [22422,22436]
name: serialized_dag [22540,22554]
===
match
---
string: "test2" [43808,43815]
string: "test2" [43926,43933]
===
match
---
operator: = [11453,11454]
operator: = [11469,11470]
===
match
---
argument [11508,11544]
argument [11524,11560]
===
match
---
dictorsetmaker [6690,6725]
dictorsetmaker [6706,6741]
===
match
---
operator: , [16496,16497]
operator: , [16512,16513]
===
match
---
trailer [15060,15078]
trailer [15076,15094]
===
match
---
name: other [29360,29365]
name: other [29478,29483]
===
match
---
operator: , [40919,40920]
operator: , [41037,41038]
===
match
---
operator: = [30429,30430]
operator: = [30547,30548]
===
match
---
parameters [25302,25324]
parameters [25420,25442]
===
match
---
operator: , [8304,8305]
operator: , [8320,8321]
===
match
---
atom [20649,20668]
atom [20767,20786]
===
match
---
operator: <= [18660,18662]
operator: <= [18778,18780]
===
match
---
name: serialized [20012,20022]
name: serialized [20130,20140]
===
match
---
atom [16340,16533]
atom [16356,16549]
===
match
---
name: log_output [25966,25976]
name: log_output [26084,26094]
===
match
---
suite [29452,29495]
suite [29570,29613]
===
match
---
trailer [11941,11946]
trailer [11957,11962]
===
match
---
name: tzinfo [16050,16056]
name: tzinfo [16066,16072]
===
match
---
atom_expr [37346,37372]
atom_expr [37464,37490]
===
match
---
simple_stmt [17557,17593]
simple_stmt [17675,17711]
===
match
---
name: dag [13612,13615]
name: dag [13628,13631]
===
match
---
atom_expr [30313,30456]
atom_expr [30431,30574]
===
match
---
atom_expr [45541,45573]
atom_expr [45659,45691]
===
match
---
operator: , [16042,16043]
operator: , [16058,16059]
===
match
---
name: dag_start_date [16707,16721]
name: dag_start_date [16825,16839]
===
match
---
trailer [13322,13328]
trailer [13338,13344]
===
match
---
expr_stmt [12191,12355]
expr_stmt [12207,12371]
===
match
---
operator: , [43973,43974]
operator: , [44091,44092]
===
match
---
string: '__type' [4024,4032]
string: '__type' [4040,4048]
===
match
---
operator: , [34725,34726]
operator: , [34843,34844]
===
match
---
arglist [16087,16118]
arglist [16103,16134]
===
match
---
trailer [27063,27070]
trailer [27181,27188]
===
match
---
suite [25588,25610]
suite [25706,25728]
===
match
---
operator: , [21315,21316]
operator: , [21433,21434]
===
match
---
name: self [12176,12180]
name: self [12192,12196]
===
match
---
name: from_dict [20002,20011]
name: from_dict [20120,20129]
===
match
---
operator: , [4040,4041]
operator: , [4056,4057]
===
match
---
operator: , [35555,35556]
operator: , [35673,35674]
===
match
---
name: airflow [1496,1503]
name: airflow [1512,1519]
===
match
---
name: executor_config_pod [45817,45836]
name: executor_config_pod [45935,45954]
===
match
---
string: """         Assert OperatorLinks not registered via Plugins and if it is not an inbuilt Operator Link,         it can still deserialize the DAG (does not error) but just logs an error         """ [24917,25112]
string: """         Assert OperatorLinks not registered via Plugins and if it is not an inbuilt Operator Link,         it can still deserialize the DAG (does not error) but just logs an error         """ [25035,25230]
===
match
---
atom [30150,30199]
atom [30268,30317]
===
match
---
name: dag [25685,25688]
name: dag [25803,25806]
===
match
---
operator: , [29961,29962]
operator: , [30079,30080]
===
match
---
string: "foo" [30218,30223]
string: "foo" [30336,30341]
===
match
---
expr_stmt [9791,9821]
expr_stmt [9807,9837]
===
match
---
parameters [31612,31651]
parameters [31730,31769]
===
match
---
import_from [967,988]
import_from [967,988]
===
match
---
trailer [5673,5678]
trailer [5689,5694]
===
match
---
string: """Validate pickle in a subprocess.""" [8730,8768]
string: """Validate pickle in a subprocess.""" [8746,8784]
===
match
---
operator: , [42144,42145]
operator: , [42262,42263]
===
match
---
operator: , [17967,17968]
operator: , [18085,18086]
===
match
---
comp_op [45612,45618]
comp_op [45730,45736]
===
match
---
operator: = [18185,18186]
operator: = [18303,18304]
===
match
---
simple_stmt [29312,29334]
simple_stmt [29430,29452]
===
match
---
name: tzinfo [17790,17796]
name: tzinfo [17908,17914]
===
match
---
name: c [45506,45507]
name: c [45624,45625]
===
match
---
trailer [17805,17809]
trailer [17923,17927]
===
match
---
name: from_dict [23539,23548]
name: from_dict [23657,23666]
===
match
---
name: timezone [16505,16513]
name: timezone [16521,16529]
===
match
---
argument [36861,36886]
argument [36979,37004]
===
match
---
argument [30818,30842]
argument [30936,30960]
===
match
---
name: str [29249,29252]
name: str [29367,29370]
===
match
---
string: "dag" [17200,17205]
string: "dag" [17318,17323]
===
match
---
name: name [44812,44816]
name: name [44930,44934]
===
match
---
atom [2511,2957]
atom [2527,2973]
===
match
---
suite [15800,15914]
suite [15816,15930]
===
match
---
name: dag [32173,32176]
name: dag [32291,32294]
===
match
---
assert_stmt [13667,13723]
assert_stmt [13683,13739]
===
match
---
name: serialized_task [15400,15415]
name: serialized_task [15416,15431]
===
match
---
string: "value_1" [21926,21935]
string: "value_1" [22044,22053]
===
match
---
dictorsetmaker [19639,19896]
dictorsetmaker [19757,20014]
===
match
---
trailer [15135,15155]
trailer [15151,15171]
===
match
---
string: "__type" [2322,2330]
string: "__type" [2338,2346]
===
match
---
number: 1 [17787,17788]
number: 1 [17905,17906]
===
match
---
atom_expr [23476,23509]
atom_expr [23594,23627]
===
match
---
operator: , [20729,20730]
operator: , [20847,20848]
===
match
---
comparison [21767,21814]
comparison [21885,21932]
===
match
---
string: 'params' [35228,35236]
string: 'params' [35346,35354]
===
match
---
operator: } [8661,8662]
operator: } [8677,8678]
===
match
---
argument [42037,42062]
argument [42155,42180]
===
match
---
expr_stmt [33083,33166]
expr_stmt [33201,33284]
===
match
---
name: patterns [8209,8217]
name: patterns [8225,8233]
===
match
---
dictorsetmaker [4143,4251]
dictorsetmaker [4159,4267]
===
match
---
atom_expr [6533,6791]
atom_expr [6549,6807]
===
match
---
name: print [41429,41434]
name: print [41547,41552]
===
match
---
trailer [17569,17592]
trailer [17687,17710]
===
match
---
name: op [33696,33698]
name: op [33814,33816]
===
match
---
trailer [39266,39281]
trailer [39384,39399]
===
match
---
atom_expr [20451,20476]
atom_expr [20569,20594]
===
match
---
param [21116,21120]
param [21234,21238]
===
match
---
operator: } [5005,5006]
operator: } [5021,5022]
===
match
---
name: to_json [8867,8874]
name: to_json [8883,8890]
===
match
---
arglist [21294,21357]
arglist [21412,21475]
===
match
---
expr_stmt [42397,42455]
expr_stmt [42515,42573]
===
match
---
expr_stmt [37180,37214]
expr_stmt [37298,37332]
===
match
---
name: keys_for_backwards_compat [33002,33027]
name: keys_for_backwards_compat [33120,33145]
===
match
---
operator: = [16056,16057]
operator: = [16072,16073]
===
match
---
argument [20465,20475]
argument [20583,20593]
===
match
---
parameters [38596,38602]
parameters [38714,38720]
===
match
---
name: dag [37747,37750]
name: dag [37865,37868]
===
match
---
trailer [23995,24004]
trailer [24113,24122]
===
match
---
name: DummySensor [39685,39696]
name: DummySensor [39803,39814]
===
match
---
name: tzinfo [16099,16105]
name: tzinfo [16115,16121]
===
match
---
atom_expr [17951,17992]
atom_expr [18069,18110]
===
match
---
trailer [16513,16517]
trailer [16529,16533]
===
match
---
simple_stmt [29147,29173]
simple_stmt [29265,29291]
===
match
---
operator: , [38871,38872]
operator: , [38989,38990]
===
match
---
simple_stmt [37695,37778]
simple_stmt [37813,37896]
===
match
---
name: val [21116,21119]
name: val [21234,21237]
===
match
---
atom [12224,12345]
atom [12240,12361]
===
match
---
testlist_comp [42948,42986]
testlist_comp [43066,43104]
===
match
---
atom_expr [5620,5723]
atom_expr [5636,5739]
===
match
---
atom_expr [18038,18050]
atom_expr [18156,18168]
===
match
---
assert_stmt [39962,39983]
assert_stmt [40080,40101]
===
match
---
trailer [10856,10869]
trailer [10872,10885]
===
match
---
trailer [13267,13280]
trailer [13283,13296]
===
match
---
name: k8s [1872,1875]
name: k8s [1888,1891]
===
match
---
name: SerializedDAG [9797,9810]
name: SerializedDAG [9813,9826]
===
match
---
operator: } [30196,30197]
operator: } [30314,30315]
===
match
---
testlist_comp [43916,43924]
testlist_comp [44034,44042]
===
match
---
name: baseoperator [1351,1363]
name: baseoperator [1367,1379]
===
match
---
trailer [13359,13362]
trailer [13375,13378]
===
match
---
arglist [38864,38874]
arglist [38982,38992]
===
match
---
trailer [29391,29400]
trailer [29509,29518]
===
match
---
operator: } [8449,8450]
operator: } [8465,8466]
===
match
---
dictorsetmaker [30151,30198]
dictorsetmaker [30269,30316]
===
match
---
operator: , [42976,42977]
operator: , [43094,43095]
===
match
---
atom [2061,5601]
atom [2077,5617]
===
match
---
name: task [15765,15769]
name: task [15781,15785]
===
match
---
arglist [5655,5720]
arglist [5671,5736]
===
match
---
atom [27892,28040]
atom [28010,28158]
===
match
---
operator: = [20472,20473]
operator: = [20590,20591]
===
match
---
string: "@weekly" [19210,19219]
string: "@weekly" [19328,19337]
===
match
---
name: utc [16514,16517]
name: utc [16530,16533]
===
match
---
string: "test label" [39014,39026]
string: "test label" [39132,39144]
===
match
---
number: 2019 [25669,25673]
number: 2019 [25787,25791]
===
match
---
trailer [25768,25776]
trailer [25886,25894]
===
match
---
operator: , [42918,42919]
operator: , [43036,43037]
===
match
---
operator: = [33651,33652]
operator: = [33769,33770]
===
match
---
string: """         Test that templated_fields exists for all Operators in Serialized DAG          Since we don't want to inflate arbitrary python objects (it poses a RCE/security risk etc.)         we want check that non-"basic" objects are turned in to strings after deserializing.         """ [31661,31948]
string: """         Test that templated_fields exists for all Operators in Serialized DAG          Since we don't want to inflate arbitrary python objects (it poses a RCE/security risk etc.)         we want check that non-"basic" objects are turned in to strings after deserializing.         """ [31779,32066]
===
match
---
operator: , [43849,43850]
operator: , [43967,43968]
===
match
---
name: SerializedDAG [19931,19944]
name: SerializedDAG [20049,20062]
===
match
---
simple_stmt [38948,38987]
simple_stmt [39066,39105]
===
match
---
with_stmt [36959,37215]
with_stmt [37077,37333]
===
match
---
operator: , [42811,42812]
operator: , [42929,42930]
===
match
---
operator: = [21246,21247]
operator: = [21364,21365]
===
match
---
testlist_comp [16028,16534]
testlist_comp [16044,16652]
===
match
---
operator: , [18170,18171]
operator: , [18288,18289]
===
match
---
name: op [39914,39916]
name: op [40032,40034]
===
match
---
name: test_date [24478,24487]
name: test_date [24596,24605]
===
match
---
operator: , [29596,29597]
operator: , [29714,29715]
===
match
---
atom_expr [8853,8879]
atom_expr [8869,8895]
===
match
---
name: serialized_task [14218,14233]
name: serialized_task [14234,14249]
===
match
---
operator: { [7622,7623]
operator: { [7638,7639]
===
match
---
atom [16028,16120]
atom [16044,16136]
===
match
---
operator: = [18402,18403]
operator: = [18520,18521]
===
match
---
name: metadata [1772,1780]
name: metadata [1788,1796]
===
match
---
operator: { [5283,5284]
operator: { [5299,5300]
===
match
---
argument [20336,20343]
argument [20454,20461]
===
match
---
operator: { [15331,15332]
operator: { [15347,15348]
===
match
---
operator: , [18334,18335]
operator: , [18452,18453]
===
match
---
string: 'builtins.__import__' [44905,44926]
string: 'builtins.__import__' [45023,45044]
===
match
---
simple_stmt [42397,42456]
simple_stmt [42515,42574]
===
match
---
trailer [13820,13829]
trailer [13836,13845]
===
match
---
simple_stmt [8589,8663]
simple_stmt [8605,8679]
===
match
---
name: task1 [37279,37284]
name: task1 [37397,37402]
===
match
---
dictorsetmaker [30064,30101]
dictorsetmaker [30182,30219]
===
match
---
operator: , [6630,6631]
operator: , [6646,6647]
===
match
---
funcdef [22669,24825]
funcdef [22787,24943]
===
match
---
simple_stmt [23220,23253]
simple_stmt [23338,23371]
===
match
---
assert_stmt [14267,14318]
assert_stmt [14283,14334]
===
match
---
trailer [32228,32244]
trailer [32346,32362]
===
match
---
operator: } [6412,6413]
operator: } [6428,6429]
===
match
---
operator: } [35843,35844]
operator: } [35961,35962]
===
match
---
atom [21851,21948]
atom [21969,22066]
===
match
---
comparison [27031,27082]
comparison [27149,27200]
===
match
---
atom_expr [13128,13158]
atom_expr [13144,13174]
===
match
---
string: "@once" [19259,19266]
string: "@once" [19377,19384]
===
match
---
dotted_name [19133,19153]
dotted_name [19251,19271]
===
match
---
atom_expr [6257,6277]
atom_expr [6273,6293]
===
match
---
string: 'timezone' [12931,12941]
string: 'timezone' [12947,12957]
===
match
---
name: utc [17531,17534]
name: utc [17649,17652]
===
match
---
argument [33580,33588]
argument [33698,33706]
===
match
---
string: "airflow.serialization.serialized_objects" [45164,45206]
string: "airflow.serialization.serialized_objects" [45282,45324]
===
match
---
trailer [39103,39108]
trailer [39221,39226]
===
match
---
string: 'bash' [3702,3708]
string: 'bash' [3718,3724]
===
match
---
atom_expr [39082,39108]
atom_expr [39200,39226]
===
match
---
trailer [45153,45163]
trailer [45271,45281]
===
match
---
string: "max_retry_delay" [2302,2319]
string: "max_retry_delay" [2318,2335]
===
match
---
trailer [22443,22452]
trailer [22561,22570]
===
match
---
trailer [44898,44904]
trailer [45016,45022]
===
match
---
operator: { [43708,43709]
operator: { [43826,43827]
===
match
---
argument [40898,40919]
argument [41016,41037]
===
match
---
atom_expr [33105,33122]
atom_expr [33223,33240]
===
match
---
operator: , [21058,21059]
operator: , [21176,21177]
===
match
---
atom_expr [10783,10799]
atom_expr [10799,10815]
===
match
---
parameters [29438,29451]
parameters [29556,29569]
===
match
---
name: serialized_dag [42366,42380]
name: serialized_dag [42484,42498]
===
match
---
operator: , [16518,16519]
operator: , [16534,16535]
===
match
---
name: dummy [36682,36687]
name: dummy [36800,36805]
===
match
---
atom [5560,5562]
atom [5576,5578]
===
match
---
name: SerializedDAG [18588,18601]
name: SerializedDAG [18706,18719]
===
match
---
simple_stmt [37125,37160]
simple_stmt [37243,37278]
===
match
---
operator: , [31113,31114]
operator: , [31231,31232]
===
match
---
name: security [1463,1471]
name: security [1479,1487]
===
match
---
operator: { [8427,8428]
operator: { [8443,8444]
===
match
---
expr_stmt [24676,24757]
expr_stmt [24794,24875]
===
match
---
operator: } [2688,2689]
operator: } [2704,2705]
===
match
---
atom [3431,3433]
atom [3447,3449]
===
match
---
string: 'wait_for_downstream' [35764,35785]
string: 'wait_for_downstream' [35882,35903]
===
match
---
name: dirname [5663,5670]
name: dirname [5679,5686]
===
match
---
string: "__var" [43371,43378]
string: "__var" [43489,43496]
===
match
---
name: ground_truth_dag [11051,11067]
name: ground_truth_dag [11067,11083]
===
match
---
operator: == [27889,27891]
operator: == [28007,28009]
===
match
---
operator: , [29695,29696]
operator: , [29813,29814]
===
match
---
trailer [45484,45490]
trailer [45602,45608]
===
match
---
arglist [17901,17932]
arglist [18019,18050]
===
match
---
operator: , [43620,43621]
operator: , [43738,43739]
===
match
---
name: SerializedDAG [17234,17247]
name: SerializedDAG [17352,17365]
===
match
---
parameters [29067,29083]
parameters [29185,29201]
===
match
---
atom_expr [31964,32035]
atom_expr [32082,32153]
===
match
---
name: x [10780,10781]
name: x [10796,10797]
===
match
---
name: child [38499,38504]
name: child [38617,38622]
===
match
---
name: DAG [41984,41987]
name: DAG [42102,42105]
===
match
---
operator: , [31541,31542]
operator: , [31659,31660]
===
match
---
name: expected_val [21767,21779]
name: expected_val [21885,21897]
===
match
---
trailer [15340,15347]
trailer [15356,15363]
===
match
---
string: 'http://google.com/custom_base_link?search=dummy_value_1' [24523,24580]
string: 'http://google.com/custom_base_link?search=dummy_value_1' [24641,24698]
===
match
---
name: serialized_task [15120,15135]
name: serialized_task [15136,15151]
===
match
---
comparison [44659,44669]
comparison [44777,44787]
===
match
---
arglist [18019,18050]
arglist [18137,18168]
===
match
---
param [25573,25578]
param [25691,25696]
===
match
---
atom_expr [10008,10037]
atom_expr [10024,10053]
===
match
---
operator: { [2245,2246]
operator: { [2261,2262]
===
match
---
with_stmt [25791,26218]
with_stmt [25909,26336]
===
match
---
name: make_simple_dag [46036,46051]
name: make_simple_dag [46154,46169]
===
match
---
trailer [13778,13805]
trailer [13794,13821]
===
match
---
name: validate_deserialized_dag [37505,37530]
name: validate_deserialized_dag [37623,37648]
===
match
---
operator: , [30385,30386]
operator: , [30503,30504]
===
match
---
operator: { [27633,27634]
operator: { [27751,27752]
===
match
---
trailer [33663,33680]
trailer [33781,33798]
===
match
---
simple_stmt [5811,5840]
simple_stmt [5827,5856]
===
match
---
name: serialized_op [33873,33886]
name: serialized_op [33991,34004]
===
match
---
name: tzinfo [17839,17845]
name: tzinfo [17957,17963]
===
match
---
operator: { [20247,20248]
operator: { [20365,20366]
===
match
---
name: dag_id [8613,8619]
name: dag_id [8629,8635]
===
match
---
argument [38844,38875]
argument [38962,38993]
===
match
---
string: '_inlets' [34363,34372]
string: '_inlets' [34481,34490]
===
match
---
simple_stmt [33606,33639]
simple_stmt [33724,33757]
===
match
---
name: kwargs [29076,29082]
name: kwargs [29194,29200]
===
match
---
name: TaskInstance [24267,24279]
name: TaskInstance [24385,24397]
===
match
---
name: self [22720,22724]
name: self [22838,22842]
===
match
---
trailer [26803,26815]
trailer [26921,26933]
===
match
---
argument [28086,28110]
argument [28204,28228]
===
match
---
operator: , [24220,24221]
operator: , [24338,24339]
===
match
---
argument [6740,6780]
argument [6756,6796]
===
match
---
arglist [35467,35473]
arglist [35585,35591]
===
match
---
trailer [32172,32177]
trailer [32290,32295]
===
match
---
number: 8 [21352,21353]
number: 8 [21470,21471]
===
match
---
operator: { [5367,5368]
operator: { [5383,5384]
===
match
---
name: airflow [36664,36671]
name: airflow [36782,36789]
===
match
---
name: airflow [1173,1180]
name: airflow [1189,1196]
===
match
---
atom_expr [17557,17592]
atom_expr [17675,17710]
===
match
---
trailer [10948,10961]
trailer [10964,10977]
===
match
---
operator: , [34306,34307]
operator: , [34424,34425]
===
match
---
trailer [5713,5720]
trailer [5729,5736]
===
match
---
atom [21914,21936]
atom [22032,22054]
===
match
---
operator: , [29719,29720]
operator: , [29837,29838]
===
match
---
atom_expr [1824,1986]
atom_expr [1840,2002]
===
match
---
operator: , [5601,5602]
operator: , [5617,5618]
===
match
---
number: 2019 [16087,16091]
number: 2019 [16103,16107]
===
match
---
operator: , [29358,29359]
operator: , [29476,29477]
===
match
---
trailer [21293,21358]
trailer [21411,21476]
===
match
---
name: task1 [38999,39004]
name: task1 [39117,39122]
===
match
---
simple_stmt [22465,22524]
simple_stmt [22583,22642]
===
match
---
import_as_names [1293,1330]
import_as_names [1309,1346]
===
match
---
number: 30 [18235,18237]
number: 30 [18353,18355]
===
match
---
atom_expr [29249,29267]
atom_expr [29367,29385]
===
match
---
param [7268,7282]
param [7284,7298]
===
match
---
string: 'simple_dag' [18415,18427]
string: 'simple_dag' [18533,18545]
===
match
---
param [8706,8712]
param [8722,8728]
===
match
---
simple_stmt [45216,45263]
simple_stmt [45334,45381]
===
match
---
trailer [19368,19376]
trailer [19486,19494]
===
match
---
atom_expr [20768,20797]
atom_expr [20886,20915]
===
match
---
name: task_dict [17300,17309]
name: task_dict [17418,17427]
===
match
---
simple_stmt [10997,11013]
simple_stmt [11013,11029]
===
match
---
string: "airflow." [45562,45572]
string: "airflow." [45680,45690]
===
match
---
string: "__type" [2101,2109]
string: "__type" [2117,2125]
===
match
---
operator: { [7846,7847]
operator: { [7862,7863]
===
match
---
comparison [22327,22372]
comparison [22445,22490]
===
match
---
operator: , [43815,43816]
operator: , [43933,43934]
===
match
---
name: blob [39979,39983]
name: blob [40097,40101]
===
match
---
atom [2905,2907]
atom [2921,2923]
===
match
---
operator: , [7684,7685]
operator: , [7700,7701]
===
match
---
expr_stmt [22532,22600]
expr_stmt [22650,22718]
===
match
---
name: dag [39104,39107]
name: dag [39222,39225]
===
match
---
name: expected_value [41027,41041]
name: expected_value [41145,41159]
===
match
---
atom [19258,19282]
atom [19376,19400]
===
match
---
string: "airflow/example_dags" [11882,11904]
string: "airflow/example_dags" [11898,11920]
===
match
---
name: patterns [8119,8127]
name: patterns [8135,8143]
===
match
---
name: att4 [30972,30976]
name: att4 [31090,31094]
===
match
---
string: 'simple_dag' [22127,22139]
string: 'simple_dag' [22245,22257]
===
match
---
trailer [27173,27188]
trailer [27291,27306]
===
match
---
simple_stmt [32640,32718]
simple_stmt [32758,32836]
===
match
---
testlist_comp [18098,18260]
testlist_comp [18216,18378]
===
match
---
name: dag [6822,6825]
name: dag [6838,6841]
===
match
---
string: 'search_query' [24345,24359]
string: 'search_query' [24463,24477]
===
match
---
name: dag_params [33083,33093]
name: dag_params [33201,33211]
===
match
---
simple_stmt [1266,1331]
simple_stmt [1282,1347]
===
match
---
argument [30886,31045]
argument [31004,31163]
===
match
---
name: stringified_dags [11818,11834]
name: stringified_dags [11834,11850]
===
match
---
trailer [20001,20011]
trailer [20119,20129]
===
match
---
trailer [39351,39365]
trailer [39469,39483]
===
match
---
assert_stmt [27853,28040]
assert_stmt [27971,28158]
===
match
---
operator: { [29931,29932]
operator: { [30049,30050]
===
match
---
name: serialization [1571,1584]
name: serialization [1587,1600]
===
match
---
trailer [33698,33711]
trailer [33816,33829]
===
match
---
trailer [23988,23995]
trailer [24106,24113]
===
match
---
operator: , [4866,4867]
operator: , [4882,4883]
===
match
---
name: update [8471,8477]
name: update [8487,8493]
===
match
---
operator: = [17796,17797]
operator: = [17914,17915]
===
match
---
name: base [1187,1191]
name: base [1203,1207]
===
match
---
string: "my-name" [1803,1812]
string: "my-name" [1819,1828]
===
match
---
suite [21494,21552]
suite [21612,21670]
===
match
---
atom_expr [25624,25681]
atom_expr [25742,25799]
===
match
---
atom [27633,27704]
atom [27751,27822]
===
match
---
string: "ERROR" [25862,25869]
string: "ERROR" [25980,25987]
===
match
---
string: "on_failure_callback" [41396,41417]
string: "on_failure_callback" [41514,41535]
===
match
---
operator: , [35428,35429]
operator: , [35546,35547]
===
match
---
trailer [23538,23548]
trailer [23656,23666]
===
match
---
operator: } [2423,2424]
operator: } [2439,2440]
===
match
---
string: 'https://console.cloud.google.com/bigquery?j=dummy_value_2' [28572,28631]
string: 'https://console.cloud.google.com/bigquery?j=dummy_value_2' [28690,28749]
===
match
---
simple_stmt [37180,37215]
simple_stmt [37298,37333]
===
match
---
argument [23369,23388]
argument [23487,23506]
===
match
---
operator: } [2359,2360]
operator: } [2375,2376]
===
match
---
name: expected_val [21712,21724]
name: expected_val [21830,21842]
===
match
---
assert_stmt [13435,13474]
assert_stmt [13451,13490]
===
match
---
name: SerializedBaseOperator [38019,38041]
name: SerializedBaseOperator [38137,38159]
===
match
---
param [39739,39744]
param [39857,39862]
===
match
---
operator: , [24296,24297]
operator: , [24414,24415]
===
match
---
name: name [13698,13702]
name: name [13714,13718]
===
match
---
suite [13363,13475]
suite [13379,13491]
===
match
---
operator: = [39306,39307]
operator: = [39424,39425]
===
match
---
operator: = [24284,24285]
operator: = [24402,24403]
===
match
---
atom_expr [20582,20610]
atom_expr [20700,20728]
===
match
---
operator: = [16828,16829]
operator: = [16946,16947]
===
match
---
parameters [40350,40397]
parameters [40468,40515]
===
match
---
trailer [29331,29333]
trailer [29449,29451]
===
match
---
trailer [24175,24200]
trailer [24293,24318]
===
match
---
number: 0 [35427,35428]
number: 0 [35545,35546]
===
match
---
expr_stmt [45442,45583]
expr_stmt [45560,45701]
===
match
---
dictorsetmaker [2071,5595]
dictorsetmaker [2087,5611]
===
match
---
atom_expr [1781,1813]
atom_expr [1797,1829]
===
match
---
simple_stmt [22110,22141]
simple_stmt [22228,22259]
===
match
---
trailer [10869,10878]
trailer [10885,10894]
===
match
---
operator: , [16165,16166]
operator: , [16181,16182]
===
match
---
operator: , [27704,27705]
operator: , [27822,27823]
===
match
---
not_test [14274,14318]
not_test [14290,14334]
===
match
---
string: """Test Serialized Sets are sorted while list and tuple preserve order""" [44119,44192]
string: """Test Serialized Sets are sorted while list and tuple preserve order""" [44237,44310]
===
match
---
param [11149,11153]
param [11165,11169]
===
match
---
expr_stmt [7344,7396]
expr_stmt [7360,7412]
===
match
---
name: SerializedDAG [18974,18987]
name: SerializedDAG [19092,19105]
===
match
---
operator: , [35276,35277]
operator: , [35394,35395]
===
match
---
operator: , [35750,35751]
operator: , [35868,35869]
===
match
---
string: "_operator_extra_links" [4751,4774]
string: "_operator_extra_links" [4767,4790]
===
match
---
operator: = [41994,41995]
operator: = [42112,42113]
===
match
---
suite [12046,12130]
suite [12062,12146]
===
match
---
decorated [15983,17391]
decorated [15999,17509]
===
match
---
operator: , [16694,16695]
operator: , [16812,16813]
===
match
---
operator: , [19377,19378]
operator: , [19495,19496]
===
match
---
operator: { [6341,6342]
operator: { [6357,6358]
===
match
---
name: raises [45870,45876]
name: raises [45988,45994]
===
match
---
name: full_filepath [13995,14008]
name: full_filepath [14011,14024]
===
match
---
string: "task3" [43817,43824]
string: "task3" [43935,43942]
===
match
---
comparison [24773,24824]
comparison [24891,24942]
===
match
---
string: 'https://console.cloud.google.com/bigquery?j=dummy_value_1' [28337,28396]
string: 'https://console.cloud.google.com/bigquery?j=dummy_value_1' [28455,28514]
===
match
---
operator: , [25577,25578]
operator: , [25695,25696]
===
match
---
string: "test" [32087,32093]
string: "test" [32205,32211]
===
match
---
simple_stmt [33563,33590]
simple_stmt [33681,33708]
===
match
---
string: "_inlets" [4652,4661]
string: "_inlets" [4668,4677]
===
match
---
argument [21317,21324]
argument [21435,21442]
===
match
---
string: 'email_on_retry' [34777,34793]
string: 'email_on_retry' [34895,34911]
===
match
---
operator: = [18037,18038]
operator: = [18155,18156]
===
match
---
fstring [13213,13251]
fstring [13229,13267]
===
match
---
simple_stmt [6487,6525]
simple_stmt [6503,6541]
===
match
---
comparison [24172,24252]
comparison [24290,24370]
===
match
---
operator: , [39487,39488]
operator: , [39605,39606]
===
match
---
atom [43286,43661]
atom [43404,43779]
===
match
---
simple_stmt [42242,42300]
simple_stmt [42360,42418]
===
match
---
operator: @ [40162,40163]
operator: @ [40280,40281]
===
match
---
name: passed_success_callback [40852,40875]
name: passed_success_callback [40970,40993]
===
match
---
operator: , [1721,1722]
operator: , [1737,1738]
===
match
---
name: dag_id [16675,16681]
name: dag_id [16793,16799]
===
match
---
name: task_id [37033,37040]
name: task_id [37151,37158]
===
match
---
name: split [10246,10251]
name: split [10262,10267]
===
match
---
trailer [37601,37635]
trailer [37719,37753]
===
match
---
atom [6355,6413]
atom [6371,6429]
===
match
---
name: get_serialized_fields [33190,33211]
name: get_serialized_fields [33308,33329]
===
match
---
string: "properties" [32704,32716]
string: "properties" [32822,32834]
===
match
---
trailer [28122,28132]
trailer [28240,28250]
===
match
---
number: 2019 [17901,17905]
number: 2019 [18019,18023]
===
match
---
simple_stmt [21760,21815]
simple_stmt [21878,21933]
===
match
---
name: start_date [16776,16786]
name: start_date [16894,16904]
===
match
---
atom_expr [17494,17535]
atom_expr [17612,17653]
===
match
---
string: "test_task_group_serialization" [36828,36859]
string: "test_task_group_serialization" [36946,36977]
===
match
---
simple_stmt [37500,37546]
simple_stmt [37618,37664]
===
match
---
number: 8 [17784,17785]
number: 8 [17902,17903]
===
match
---
operator: , [17970,17971]
operator: , [18088,18089]
===
match
---
string: """         Class for testing purpose: allows to create objects with custom attributes in one single statement.         """ [28922,29045]
string: """         Class for testing purpose: allows to create objects with custom attributes in one single statement.         """ [29040,29163]
===
match
---
string: "dict" [5307,5313]
string: "dict" [5323,5329]
===
match
---
name: module [45295,45301]
name: module [45413,45419]
===
match
---
operator: , [13211,13212]
operator: , [13227,13228]
===
match
---
simple_stmt [25260,25277]
simple_stmt [25378,25395]
===
match
---
parameters [29193,29199]
parameters [29311,29317]
===
match
---
string: '_downstream_task_ids' [34320,34342]
string: '_downstream_task_ids' [34438,34460]
===
match
---
string: "__type" [19656,19664]
string: "__type" [19774,19782]
===
match
---
argument [16767,16774]
argument [16885,16892]
===
match
---
operator: , [6578,6579]
operator: , [6594,6595]
===
match
---
atom_expr [21459,21480]
atom_expr [21577,21598]
===
match
---
operator: , [2182,2183]
operator: , [2198,2199]
===
match
---
atom [29931,29960]
atom [30049,30078]
===
match
---
operator: , [3358,3359]
operator: , [3374,3375]
===
match
---
with_stmt [38803,39062]
with_stmt [38921,39180]
===
match
---
trailer [23437,23442]
trailer [23555,23560]
===
match
---
string: 'start_date' [7360,7372]
string: 'start_date' [7376,7388]
===
match
---
name: setUp [9030,9035]
name: setUp [9046,9051]
===
match
---
name: make_example_dags [5730,5747]
name: make_example_dags [5746,5763]
===
match
---
argument [30972,30997]
argument [31090,31115]
===
match
---
operator: = [21301,21302]
operator: = [21419,21420]
===
match
---
simple_stmt [11022,11104]
simple_stmt [11038,11120]
===
match
---
number: 0 [27080,27081]
number: 0 [27198,27199]
===
match
---
name: other [29445,29450]
name: other [29563,29568]
===
match
---
argument [26923,26930]
argument [27041,27048]
===
match
---
operator: , [42686,42687]
operator: , [42804,42805]
===
match
---
name: att1 [30360,30364]
name: att1 [30478,30482]
===
match
---
argument [1901,1969]
argument [1917,1985]
===
match
---
string: "sla" [6196,6201]
string: "sla" [6212,6217]
===
match
---
operator: , [23367,23368]
operator: , [23485,23486]
===
match
---
name: serialized [20813,20823]
name: serialized [20931,20941]
===
match
---
trailer [33185,33214]
trailer [33303,33332]
===
match
---
fstring_end: " [29269,29270]
fstring_end: " [29387,29388]
===
match
---
simple_stmt [11603,11625]
simple_stmt [11619,11641]
===
match
---
string: "'{{ task.task_id }}', 'template_fields': ['att3']}), 'template_fields': ['nested1']})" [31439,31526]
string: "'{{ task.task_id }}', 'template_fields': ['att3']}), 'template_fields': ['nested1']})" [31557,31644]
===
match
---
name: self [44065,44069]
name: self [44183,44187]
===
match
---
comparison [23974,24112]
comparison [24092,24230]
===
match
---
arglist [26900,26961]
arglist [27018,27079]
===
match
---
atom_expr [40127,40134]
atom_expr [40245,40252]
===
match
---
name: items [29122,29127]
name: items [29240,29245]
===
match
---
dictorsetmaker [2158,2425]
dictorsetmaker [2174,2441]
===
match
---
simple_stmt [23322,23390]
simple_stmt [23440,23508]
===
match
---
for_stmt [12401,12572]
for_stmt [12417,12588]
===
match
---
string: "group34" [37082,37091]
string: "group34" [37200,37209]
===
match
---
simple_stmt [40972,41016]
simple_stmt [41090,41134]
===
match
---
simple_stmt [11657,11673]
simple_stmt [11673,11689]
===
match
---
number: 8 [42143,42144]
number: 8 [42261,42262]
===
match
---
name: utc [16307,16310]
name: utc [16323,16326]
===
match
---
operator: , [7827,7828]
operator: , [7843,7844]
===
match
---
name: dag [37541,37544]
name: dag [37659,37662]
===
match
---
atom_expr [41229,41268]
atom_expr [41347,41386]
===
match
---
number: 2019 [16220,16224]
number: 2019 [16236,16240]
===
match
---
argument [20327,20334]
argument [20445,20452]
===
match
---
trailer [24007,24032]
trailer [24125,24150]
===
match
---
atom_expr [11785,11805]
atom_expr [11801,11821]
===
match
---
operator: , [4450,4451]
operator: , [4466,4467]
===
match
---
atom_expr [8885,8900]
atom_expr [8901,8916]
===
match
---
name: simple_task [24450,24461]
name: simple_task [24568,24579]
===
match
---
name: k8s [1781,1784]
name: k8s [1797,1800]
===
match
---
assert_stmt [23624,23677]
assert_stmt [23742,23795]
===
match
---
trailer [36827,36887]
trailer [36945,37005]
===
match
---
trailer [9029,9035]
trailer [9045,9051]
===
match
---
trailer [17987,17991]
trailer [18105,18109]
===
match
---
simple_stmt [18493,18562]
simple_stmt [18611,18680]
===
match
---
name: params [21745,21751]
name: params [21863,21869]
===
match
---
fstring_string: ( [29247,29248]
fstring_string: ( [29365,29366]
===
match
---
operator: , [38868,38869]
operator: , [38986,38987]
===
match
---
operator: , [18259,18260]
operator: , [18377,18378]
===
match
---
trailer [24477,24507]
trailer [24595,24625]
===
match
---
atom_expr [10219,10260]
atom_expr [10235,10276]
===
match
---
string: "param_1" [21012,21021]
string: "param_1" [21130,21139]
===
match
---
string: 'upstream_group_ids' [2806,2826]
string: 'upstream_group_ids' [2822,2842]
===
match
---
operator: , [19182,19183]
operator: , [19300,19301]
===
match
---
trailer [9810,9818]
trailer [9826,9834]
===
match
---
atom [42657,42697]
atom [42775,42815]
===
match
---
trailer [28132,28184]
trailer [28250,28302]
===
match
---
arglist [14289,14317]
arglist [14305,14333]
===
match
---
funcdef [41495,42531]
funcdef [41613,42649]
===
match
---
annassign [32817,32992]
annassign [32935,33110]
===
match
---
trailer [5654,5721]
trailer [5670,5737]
===
match
---
operator: = [9524,9525]
operator: = [9540,9541]
===
match
---
string: "owner" [3200,3207]
string: "owner" [3216,3223]
===
match
---
operator: , [7580,7581]
operator: , [7596,7597]
===
match
---
trailer [21239,21272]
trailer [21357,21390]
===
match
---
string: 'dag' [10228,10233]
string: 'dag' [10244,10249]
===
match
---
import_from [1558,1648]
import_from [1574,1664]
===
match
---
operator: , [16490,16491]
operator: , [16506,16507]
===
match
---
name: permissions [1479,1490]
name: permissions [1495,1506]
===
match
---
comparison [28337,28419]
comparison [28455,28537]
===
match
---
operator: , [4299,4300]
operator: , [4315,4316]
===
match
---
arglist [25669,25679]
arglist [25787,25797]
===
match
---
string: "_operator_extra_links" [24008,24031]
string: "_operator_extra_links" [24126,24149]
===
match
---
simple_stmt [26972,27016]
simple_stmt [27090,27134]
===
match
---
string: "tasks" [17124,17131]
string: "tasks" [17242,17249]
===
match
---
operator: , [16168,16169]
operator: , [16184,16185]
===
match
---
assert_stmt [13973,14023]
assert_stmt [13989,14039]
===
match
---
testlist_comp [39480,39530]
testlist_comp [39598,39648]
===
match
---
string: "template_fields" [3596,3613]
string: "template_fields" [3612,3629]
===
match
---
operator: = [18513,18514]
operator: = [18631,18632]
===
match
---
name: sorted [10783,10789]
name: sorted [10799,10805]
===
match
---
arglist [45491,45497]
arglist [45609,45615]
===
match
---
name: os [5620,5622]
name: os [5636,5638]
===
match
---
trailer [10251,10256]
trailer [10267,10272]
===
match
---
trailer [39419,39429]
trailer [39537,39547]
===
match
---
atom_expr [18404,18484]
atom_expr [18522,18602]
===
match
---
name: ClassWithCustomAttributes [30313,30338]
name: ClassWithCustomAttributes [30431,30456]
===
match
---
operator: , [2212,2213]
operator: , [2228,2229]
===
match
---
trailer [39221,39226]
trailer [39339,39344]
===
match
---
name: dag [9864,9867]
name: dag [9880,9883]
===
match
---
atom_expr [8820,8833]
atom_expr [8836,8849]
===
match
---
fstring_start: f' [15329,15331]
fstring_start: f' [15345,15347]
===
match
---
operator: = [37040,37041]
operator: = [37158,37159]
===
match
---
dictorsetmaker [20347,20407]
dictorsetmaker [20465,20525]
===
match
---
string: "foo1" [30023,30029]
string: "foo1" [30141,30147]
===
match
---
name: dag [37486,37489]
name: dag [37604,37607]
===
match
---
argument [21326,21357]
argument [21444,21475]
===
match
---
argument [7718,7732]
argument [7734,7748]
===
match
---
trailer [23240,23252]
trailer [23358,23370]
===
match
---
simple_stmt [1208,1266]
simple_stmt [1224,1282]
===
match
---
operator: ** [40850,40852]
operator: ** [40968,40970]
===
match
---
operator: } [3723,3724]
operator: } [3739,3740]
===
match
---
atom [29921,30003]
atom [30039,30121]
===
match
---
trailer [22497,22507]
trailer [22615,22625]
===
match
---
operator: , [34868,34869]
operator: , [34986,34987]
===
match
---
name: test_extra_serialized_field_and_multiple_operator_links [26227,26282]
name: test_extra_serialized_field_and_multiple_operator_links [26345,26400]
===
match
---
simple_stmt [23624,23678]
simple_stmt [23742,23796]
===
match
---
trailer [1919,1933]
trailer [1935,1949]
===
match
---
expr_stmt [25507,25547]
expr_stmt [25625,25665]
===
match
---
comparison [11921,11969]
comparison [11937,11985]
===
match
---
operator: = [36937,36938]
operator: = [37055,37056]
===
match
---
name: dag [20040,20043]
name: dag [20158,20161]
===
match
---
string: 'operator' [2620,2630]
string: 'operator' [2636,2646]
===
match
---
name: level [44877,44882]
name: level [44995,45000]
===
match
---
operator: = [18532,18533]
operator: = [18650,18651]
===
match
---
operator: } [7660,7661]
operator: } [7676,7677]
===
match
---
trailer [45498,45501]
trailer [45616,45619]
===
match
---
decorator [17723,18292]
decorator [17841,18410]
===
match
---
trailer [39402,39412]
trailer [39520,39530]
===
match
---
atom [42889,42929]
atom [43007,43047]
===
match
---
simple_stmt [19073,19127]
simple_stmt [19191,19245]
===
match
---
simple_stmt [39165,39228]
simple_stmt [39283,39346]
===
match
---
expr_stmt [39071,39108]
expr_stmt [39189,39226]
===
match
---
name: proc [11448,11452]
name: proc [11464,11468]
===
match
---
name: self [16591,16595]
name: self [16709,16713]
===
match
---
string: "y" [43921,43924]
string: "y" [44039,44042]
===
match
---
atom [3142,4394]
atom [3158,4410]
===
match
---
name: MyOperator [33459,33469]
name: MyOperator [33577,33587]
===
match
---
string: "x" [43916,43919]
string: "x" [44034,44037]
===
match
---
atom_expr [7952,7982]
atom_expr [7968,7998]
===
match
---
argument [22162,22183]
argument [22280,22301]
===
match
---
operator: , [43926,43927]
operator: , [44044,44045]
===
match
---
name: SerializedDAG [39308,39321]
name: SerializedDAG [39426,39439]
===
match
---
atom_expr [39872,39917]
atom_expr [39990,40035]
===
match
---
trailer [37032,37049]
trailer [37150,37167]
===
match
---
operator: , [30789,30790]
operator: , [30907,30908]
===
match
---
string: "staging_schema" [43056,43072]
string: "staging_schema" [43174,43190]
===
match
---
operator: , [2957,2958]
operator: , [2973,2974]
===
match
---
name: get_extra_links [24462,24477]
name: get_extra_links [24580,24595]
===
match
---
atom [5367,5512]
atom [5383,5528]
===
match
---
name: get_serialized_fields [12827,12848]
name: get_serialized_fields [12843,12864]
===
match
---
string: 'simple_task' [16752,16765]
string: 'simple_task' [16870,16883]
===
match
---
operator: } [30100,30101]
operator: } [30218,30219]
===
match
---
assert_stmt [11778,11805]
assert_stmt [11794,11821]
===
match
---
trailer [39337,39371]
trailer [39455,39489]
===
match
---
number: 0 [22370,22371]
number: 0 [22488,22489]
===
match
---
operator: = [45137,45138]
operator: = [45255,45256]
===
match
---
name: dag [12567,12570]
name: dag [12583,12586]
===
match
---
string: 'task_5' [42668,42676]
string: 'task_5' [42786,42794]
===
match
---
name: expected_value [41329,41343]
name: expected_value [41447,41461]
===
match
---
trailer [10227,10234]
trailer [10243,10250]
===
match
---
name: deserialize_dag [39322,39337]
name: deserialize_dag [39440,39455]
===
match
---
testlist_comp [29594,29600]
testlist_comp [29712,29718]
===
match
---
atom [29674,29718]
atom [29792,29836]
===
match
---
operator: , [18117,18118]
operator: , [18235,18236]
===
match
---
operator: == [21725,21727]
operator: == [21843,21845]
===
match
---
string: "_access_control" [10921,10938]
string: "_access_control" [10937,10954]
===
match
---
simple_stmt [7401,7692]
simple_stmt [7417,7708]
===
match
---
atom_expr [44732,44775]
atom_expr [44850,44893]
===
match
---
suite [29200,29271]
suite [29318,29389]
===
match
---
name: __dict__ [29258,29266]
name: __dict__ [29376,29384]
===
match
---
trailer [15336,15340]
trailer [15352,15356]
===
match
---
string: """Loads DAGs from a module for test.""" [5766,5806]
string: """Loads DAGs from a module for test.""" [5782,5822]
===
match
---
name: BaseHook [9046,9054]
name: BaseHook [9062,9070]
===
match
---
name: dag_id [12121,12127]
name: dag_id [12137,12143]
===
match
---
string: 'label' [5179,5186]
string: 'label' [5195,5202]
===
match
---
parameters [32441,32447]
parameters [32559,32565]
===
match
---
simple_stmt [29380,29419]
simple_stmt [29498,29537]
===
match
---
trailer [12423,12425]
trailer [12439,12441]
===
match
---
atom [29594,29596]
atom [29712,29714]
===
match
---
operator: , [18274,18275]
operator: , [18392,18393]
===
match
---
testlist_comp [43979,43987]
testlist_comp [44097,44105]
===
match
---
name: serialize_operator [38249,38267]
name: serialize_operator [38367,38385]
===
match
---
atom_expr [23267,23313]
atom_expr [23385,23431]
===
match
---
trailer [17116,17123]
trailer [17234,17241]
===
match
---
operator: , [16611,16612]
operator: , [16729,16730]
===
match
---
name: tzinfo [16439,16445]
name: tzinfo [16455,16461]
===
match
---
operator: , [27927,27928]
operator: , [28045,28046]
===
match
---
dictorsetmaker [30226,30264]
dictorsetmaker [30344,30382]
===
match
---
name: datetime [17769,17777]
name: datetime [17887,17895]
===
match
---
atom [33306,33380]
atom [33424,33498]
===
match
---
atom [7945,7947]
atom [7961,7963]
===
match
---
assert_stmt [15447,15500]
assert_stmt [15463,15516]
===
match
---
argument [6559,6578]
argument [6575,6594]
===
match
---
dictorsetmaker [29923,29960]
dictorsetmaker [30041,30078]
===
match
---
simple_stmt [38691,38741]
simple_stmt [38809,38859]
===
match
---
name: other [29488,29493]
name: other [29606,29611]
===
match
---
string: "nested1" [31084,31093]
string: "nested1" [31202,31211]
===
match
---
name: self [21110,21114]
name: self [21228,21232]
===
match
---
operator: { [43438,43439]
operator: { [43556,43557]
===
match
---
parameters [33959,33965]
parameters [34077,34083]
===
match
---
name: DummyOperator [38956,38969]
name: DummyOperator [39074,39087]
===
match
---
string: "definitions" [32682,32695]
string: "definitions" [32800,32813]
===
match
---
operator: , [7810,7811]
operator: , [7826,7827]
===
match
---
operator: } [30101,30102]
operator: } [30219,30220]
===
match
---
string: "simple_task" [22586,22599]
string: "simple_task" [22704,22717]
===
match
---
name: multiprocessing [874,889]
name: multiprocessing [874,889]
===
match
---
name: key [10769,10772]
name: key [10785,10788]
===
match
---
operator: , [3783,3784]
operator: , [3799,3800]
===
match
---
operator: , [40957,40958]
operator: , [41075,41076]
===
match
---
assert_stmt [41139,41200]
assert_stmt [41257,41318]
===
match
---
operator: , [21937,21938]
operator: , [22055,22056]
===
match
---
string: "_operator_extra_links" [27591,27614]
string: "_operator_extra_links" [27709,27732]
===
match
---
operator: } [8439,8440]
operator: } [8455,8456]
===
match
---
number: 1 [17836,17837]
number: 1 [17954,17955]
===
match
---
operator: = [22482,22483]
operator: = [22600,22601]
===
match
---
string: "true" [27253,27259]
string: "true" [27371,27377]
===
match
---
atom_expr [37702,37743]
atom_expr [37820,37861]
===
match
---
operator: , [40848,40849]
operator: , [40966,40967]
===
match
---
operator: } [6235,6236]
operator: } [6251,6252]
===
match
---
if_stmt [15397,15578]
if_stmt [15413,15594]
===
match
---
operator: , [26808,26809]
operator: , [26926,26927]
===
match
---
string: "__var" [20640,20647]
string: "__var" [20758,20765]
===
match
---
arglist [26804,26814]
arglist [26922,26932]
===
match
---
operator: , [29601,29602]
operator: , [29719,29720]
===
match
---
name: dag [27011,27014]
name: dag [27129,27132]
===
match
---
funcdef [44571,44884]
funcdef [44689,45002]
===
match
---
operator: { [27718,27719]
operator: { [27836,27837]
===
match
---
string: "relativedelta" [20357,20372]
string: "relativedelta" [20475,20490]
===
match
---
atom_expr [38129,38193]
atom_expr [38247,38311]
===
match
---
name: join [5650,5654]
name: join [5666,5670]
===
match
---
operator: = [17521,17522]
operator: = [17639,17640]
===
match
---
name: timezone [958,966]
name: timezone [958,966]
===
match
---
param [21996,22000]
param [22114,22118]
===
match
---
name: isinstance [15874,15884]
name: isinstance [15890,15900]
===
match
---
operator: == [20919,20921]
operator: == [21037,21039]
===
match
---
trailer [11431,11437]
trailer [11447,11453]
===
match
---
comparison [41146,41200]
comparison [41264,41318]
===
match
---
argument [1949,1967]
argument [1965,1983]
===
match
---
trailer [21544,21551]
trailer [21662,21669]
===
match
---
suite [45891,45953]
suite [46009,46071]
===
match
---
trailer [17257,17273]
trailer [17375,17391]
===
match
---
atom [42871,43002]
atom [42989,43120]
===
match
---
operator: @ [41349,41350]
operator: @ [41467,41468]
===
match
---
suite [31652,32394]
suite [31770,32512]
===
match
---
name: exec_module [45283,45294]
name: exec_module [45401,45412]
===
match
---
name: set [14963,14966]
name: set [14979,14982]
===
match
---
operator: { [20383,20384]
operator: { [20501,20502]
===
match
---
param [41569,41583]
param [41687,41701]
===
match
---
simple_stmt [1735,1990]
simple_stmt [1751,2006]
===
match
---
atom_expr [8466,8507]
atom_expr [8482,8523]
===
match
---
assert_stmt [17162,17218]
assert_stmt [17280,17336]
===
match
---
number: 2019 [18107,18111]
number: 2019 [18225,18229]
===
match
---
name: expand [41364,41370]
name: expand [41482,41488]
===
match
---
number: 1 [16096,16097]
number: 1 [16112,16113]
===
match
---
name: PodGenerator [45790,45802]
name: PodGenerator [45908,45920]
===
match
---
suite [8834,8881]
suite [8850,8897]
===
match
---
operator: , [29072,29073]
operator: , [29190,29191]
===
match
---
atom_expr [30658,31113]
atom_expr [30776,31231]
===
match
---
trailer [14966,14999]
trailer [14982,15015]
===
match
---
testlist_comp [43881,43990]
testlist_comp [43999,44108]
===
match
---
suite [41585,42531]
suite [41703,42649]
===
match
---
name: module_path [5748,5759]
name: module_path [5764,5775]
===
match
---
operator: , [35182,35183]
operator: , [35300,35301]
===
match
---
testlist_comp [8092,8103]
testlist_comp [8108,8119]
===
match
---
simple_stmt [28473,28557]
simple_stmt [28591,28675]
===
match
---
string: 'task_1' [42803,42811]
string: 'task_1' [42921,42929]
===
match
---
funcdef [32399,33229]
funcdef [32517,33347]
===
match
---
name: expect_custom_deps [39589,39607]
name: expect_custom_deps [39707,39725]
===
match
---
atom_expr [13162,13211]
atom_expr [13178,13227]
===
match
---
atom_expr [20313,20344]
atom_expr [20431,20462]
===
match
---
atom [20247,20297]
atom [20365,20415]
===
match
---
name: validate_schema [9848,9863]
name: validate_schema [9864,9879]
===
match
---
string: 'sla' [35569,35574]
string: 'sla' [35687,35692]
===
match
---
param [39583,39588]
param [39701,39706]
===
match
---
name: timezone [17522,17530]
name: timezone [17640,17648]
===
match
---
operator: = [19034,19035]
operator: = [19152,19153]
===
match
---
trailer [24501,24506]
trailer [24619,24624]
===
match
---
number: 2020 [36799,36803]
number: 2020 [36917,36921]
===
match
---
name: SerializedDAG [32151,32164]
name: SerializedDAG [32269,32282]
===
match
---
import_name [1016,1029]
import_name [1032,1045]
===
match
---
funcdef [44445,46069]
funcdef [44563,46187]
===
match
---
trailer [32164,32172]
trailer [32282,32290]
===
match
---
operator: , [12627,12628]
operator: , [12643,12644]
===
match
---
atom [2245,2284]
atom [2261,2300]
===
match
---
string: 'task_2' [43902,43910]
string: 'task_2' [44020,44028]
===
match
---
parameters [22719,22725]
parameters [22837,22843]
===
match
---
dotted_name [1496,1529]
dotted_name [1512,1545]
===
match
---
name: kwargs [29115,29121]
name: kwargs [29233,29239]
===
match
---
name: task_id [22162,22169]
name: task_id [22280,22287]
===
match
---
name: SerializedDAG [23525,23538]
name: SerializedDAG [23643,23656]
===
match
---
atom_expr [22149,22238]
atom_expr [22267,22356]
===
match
---
name: template_fields [30999,31014]
name: template_fields [31117,31132]
===
match
---
operator: = [7893,7894]
operator: = [7909,7910]
===
match
---
assert_stmt [18904,18958]
assert_stmt [19022,19076]
===
match
---
name: seconds [6213,6220]
name: seconds [6229,6236]
===
match
---
import_as_names [937,966]
import_as_names [937,966]
===
match
---
operator: , [36806,36807]
operator: , [36924,36925]
===
match
---
string: "task5" [37258,37265]
string: "task5" [37376,37383]
===
match
---
trailer [9054,9069]
trailer [9070,9085]
===
match
---
name: task_type [14920,14929]
name: task_type [14936,14945]
===
match
---
atom_expr [27204,27240]
atom_expr [27322,27358]
===
match
---
atom_expr [41984,42063]
atom_expr [42102,42181]
===
match
---
fstring [8425,8451]
fstring [8441,8467]
===
match
---
name: TaskInstance [28055,28067]
name: TaskInstance [28173,28185]
===
match
---
operator: , [21870,21871]
operator: , [21988,21989]
===
match
---
name: custom_inbuilt_link [28473,28492]
name: custom_inbuilt_link [28591,28610]
===
match
---
name: from_dict [42430,42439]
name: from_dict [42548,42557]
===
match
---
operator: { [12853,12854]
operator: { [12869,12870]
===
match
---
simple_stmt [9834,9869]
simple_stmt [9850,9885]
===
match
---
operator: , [42987,42988]
operator: , [43105,43106]
===
match
---
operator: = [17577,17578]
operator: = [17695,17696]
===
match
---
assert_stmt [21705,21751]
assert_stmt [21823,21869]
===
match
---
operator: , [5562,5563]
operator: , [5578,5579]
===
match
---
string: "is_subdag" [32839,32850]
string: "is_subdag" [32957,32968]
===
match
---
string: "tasks" [22444,22451]
string: "tasks" [22562,22569]
===
match
---
name: k [13638,13639]
name: k [13654,13655]
===
match
---
operator: , [35580,35581]
operator: , [35698,35699]
===
match
---
simple_stmt [41278,41344]
simple_stmt [41396,41462]
===
match
---
name: json_dag [11094,11102]
name: json_dag [11110,11118]
===
match
---
operator: , [32871,32872]
operator: , [32989,32990]
===
match
---
argument [19350,19356]
argument [19468,19474]
===
match
---
name: serialized_dag [25738,25752]
name: serialized_dag [25856,25870]
===
match
---
name: dag [22185,22188]
name: dag [22303,22306]
===
match
---
name: dag_folder [8179,8189]
name: dag_folder [8195,8205]
===
match
---
trailer [45239,45256]
trailer [45357,45374]
===
match
---
argument [18462,18483]
argument [18580,18601]
===
match
---
trailer [45490,45498]
trailer [45608,45616]
===
match
---
operator: , [6659,6660]
operator: , [6675,6676]
===
match
---
suite [18891,18959]
suite [19009,19077]
===
match
---
simple_stmt [5766,5807]
simple_stmt [5782,5823]
===
match
---
atom_expr [29476,29494]
atom_expr [29594,29612]
===
match
---
trailer [28522,28556]
trailer [28640,28674]
===
match
---
number: 1 [20243,20244]
number: 1 [20361,20362]
===
match
---
string: """         Test that params work both on Serialized DAGs & Tasks         """ [21144,21221]
string: """         Test that params work both on Serialized DAGs & Tasks         """ [21262,21339]
===
match
---
name: operators [1415,1424]
name: operators [1431,1440]
===
match
---
string: "dict" [19666,19672]
string: "dict" [19784,19790]
===
match
---
trailer [25776,25781]
trailer [25894,25899]
===
match
---
string: "dag" [22437,22442]
string: "dag" [22555,22560]
===
match
---
name: ROOT_FOLDER [8428,8439]
name: ROOT_FOLDER [8444,8455]
===
match
---
name: passed_failure_callback [41544,41567]
name: passed_failure_callback [41662,41685]
===
match
---
name: expected_value [41569,41583]
name: expected_value [41687,41701]
===
match
---
with_item [17458,17543]
with_item [17576,17661]
===
match
---
trailer [45294,45302]
trailer [45412,45420]
===
match
---
comparison [23631,23677]
comparison [23749,23795]
===
match
---
simple_stmt [39236,39282]
simple_stmt [39354,39400]
===
match
---
atom_expr [39338,39370]
atom_expr [39456,39488]
===
match
---
atom_expr [8068,8105]
atom_expr [8084,8121]
===
match
---
string: '"database_type": "postgres", ' [9319,9350]
string: '"database_type": "postgres", ' [9335,9366]
===
match
---
number: 100.0 [2418,2423]
number: 100.0 [2434,2439]
===
match
---
trailer [14288,14318]
trailer [14304,14334]
===
match
---
name: SerializedBaseOperator [33737,33759]
name: SerializedBaseOperator [33855,33877]
===
match
---
string: 'simple_dag' [23278,23290]
string: 'simple_dag' [23396,23408]
===
match
---
operator: , [2439,2440]
operator: , [2455,2456]
===
match
---
operator: , [35854,35855]
operator: , [35972,35973]
===
match
---
name: utc [18195,18198]
name: utc [18313,18316]
===
match
---
name: keys [10792,10796]
name: keys [10808,10812]
===
match
---
atom_expr [30894,31045]
atom_expr [31012,31163]
===
match
---
name: timezone [16239,16247]
name: timezone [16255,16263]
===
match
---
string: "test_conf" [43609,43620]
string: "test_conf" [43727,43738]
===
match
---
name: isinstance [44276,44286]
name: isinstance [44394,44404]
===
match
---
atom_expr [21728,21751]
atom_expr [21846,21869]
===
match
---
string: 'owner' [35196,35203]
string: 'owner' [35314,35321]
===
match
---
operator: = [27158,27159]
operator: = [27276,27277]
===
match
---
number: 7 [16432,16433]
number: 7 [16448,16449]
===
match
---
name: task1 [36908,36913]
name: task1 [37026,37031]
===
match
---
name: group34 [37309,37316]
name: group34 [37427,37434]
===
match
---
argument [40850,40875]
argument [40968,40993]
===
match
---
name: dateutil [1035,1043]
name: dateutil [1051,1059]
===
match
---
name: doc_md [6424,6430]
name: doc_md [6440,6446]
===
match
---
trailer [11881,11905]
trailer [11897,11921]
===
match
---
operator: = [7515,7516]
operator: = [7531,7532]
===
match
---
atom [40276,40278]
atom [40394,40396]
===
match
---
simple_stmt [28817,28876]
simple_stmt [28935,28994]
===
match
---
operator: } [5536,5537]
operator: } [5552,5553]
===
match
---
operator: , [34443,34444]
operator: , [34561,34562]
===
match
---
operator: , [43172,43173]
operator: , [43290,43291]
===
match
---
atom [1915,1969]
atom [1931,1985]
===
match
---
name: ti [24332,24334]
name: ti [24450,24452]
===
match
---
funcdef [24830,26218]
funcdef [24948,26336]
===
match
---
string: "__var" [2131,2138]
string: "__var" [2147,2154]
===
match
---
name: dag_params [33218,33228]
name: dag_params [33336,33346]
===
match
---
atom [5592,5594]
atom [5608,5610]
===
match
---
trailer [10961,10970]
trailer [10977,10986]
===
match
---
atom [8596,8662]
atom [8612,8678]
===
match
---
string: "has_on_success_callback" [41146,41171]
string: "has_on_success_callback" [41264,41289]
===
match
---
string: 'task_1' [42600,42608]
string: 'task_1' [42718,42726]
===
match
---
trailer [14418,14420]
trailer [14434,14436]
===
match
---
operator: , [29795,29796]
operator: , [29913,29914]
===
match
---
name: BaseOperator [14351,14363]
name: BaseOperator [14367,14379]
===
match
---
operator: , [32981,32982]
operator: , [33099,33100]
===
match
---
argument [18506,18527]
argument [18624,18645]
===
match
---
name: CustomOpLink [24489,24501]
name: CustomOpLink [24607,24619]
===
match
---
operator: , [23290,23291]
operator: , [23408,23409]
===
match
---
atom_expr [5711,5720]
atom_expr [5727,5736]
===
match
---
arglist [32079,32123]
arglist [32197,32241]
===
match
---
operator: = [21653,21654]
operator: = [21771,21772]
===
match
---
classdef [39679,39784]
classdef [39797,39902]
===
match
---
trailer [17206,17215]
trailer [17324,17333]
===
match
---
operator: , [40355,40356]
operator: , [40473,40474]
===
match
---
argument [1798,1812]
argument [1814,1828]
===
match
---
name: task_ids [13752,13760]
name: task_ids [13768,13776]
===
match
---
name: tzinfo [17972,17978]
name: tzinfo [18090,18096]
===
match
---
operator: == [15780,15782]
operator: == [15796,15798]
===
match
---
operator: == [39413,39415]
operator: == [39531,39533]
===
match
---
name: children [37728,37736]
name: children [37846,37854]
===
match
---
operator: } [21873,21874]
operator: } [21991,21992]
===
match
---
name: dag_folder [8793,8803]
name: dag_folder [8809,8819]
===
match
---
string: 'subdag' [14496,14504]
string: 'subdag' [14512,14520]
===
match
---
comparison [15765,15799]
comparison [15781,15815]
===
match
---
atom_expr [34479,34484]
atom_expr [34597,34602]
===
match
---
param [10369,10383]
param [10385,10399]
===
match
---
testlist_comp [20582,20669]
testlist_comp [20700,20787]
===
match
---
comparison [28824,28875]
comparison [28942,28993]
===
match
---
operator: , [5054,5055]
operator: , [5070,5071]
===
match
---
name: collect_dags [9701,9713]
name: collect_dags [9717,9729]
===
match
---
name: from_dict [27112,27121]
name: from_dict [27230,27239]
===
match
---
operator: , [35114,35115]
operator: , [35232,35233]
===
match
---
atom [35180,35182]
atom [35298,35300]
===
match
---
argument [21240,21259]
argument [21358,21377]
===
match
---
atom [8220,8365]
atom [8236,8381]
===
match
---
operator: = [12196,12197]
operator: = [12212,12213]
===
match
---
argument [36930,36945]
argument [37048,37063]
===
match
---
simple_stmt [11164,11227]
simple_stmt [11180,11243]
===
match
---
return_stmt [7293,7338]
return_stmt [7309,7354]
===
match
---
operator: , [14504,14505]
operator: , [14520,14521]
===
match
---
comparison [40127,40156]
comparison [40245,40274]
===
match
---
name: items [9770,9775]
name: items [9786,9791]
===
match
---
string: '_outlets' [34429,34439]
string: '_outlets' [34547,34557]
===
match
---
name: AttributeError [37901,37915]
name: AttributeError [38019,38033]
===
match
---
operator: , [5227,5228]
operator: , [5243,5244]
===
match
---
trailer [45148,45153]
trailer [45266,45271]
===
match
---
comparison [17082,17135]
comparison [17200,17253]
===
match
---
expr_stmt [18968,19013]
expr_stmt [19086,19131]
===
match
---
argument [18031,18050]
argument [18149,18168]
===
match
---
name: serialized [20755,20765]
name: serialized [20873,20883]
===
match
---
name: get_extra_links [28507,28522]
name: get_extra_links [28625,28640]
===
match
---
string: 'task_2' [42678,42686]
string: 'task_2' [42796,42804]
===
match
---
string: 'task_4' [42688,42696]
string: 'task_4' [42806,42814]
===
match
---
string: 'ui_fgcolor' [2772,2784]
string: 'ui_fgcolor' [2788,2800]
===
match
---
testlist_comp [43945,43988]
testlist_comp [44063,44106]
===
match
---
trailer [33759,33778]
trailer [33877,33896]
===
match
---
operator: , [28165,28166]
operator: , [28283,28284]
===
match
---
simple_stmt [42326,42388]
simple_stmt [42444,42506]
===
match
---
suite [5887,6827]
suite [5903,6843]
===
match
---
name: os [897,899]
name: os [897,899]
===
match
---
name: name [25260,25264]
name: name [25378,25382]
===
match
---
trailer [32679,32681]
trailer [32797,32799]
===
match
---
dotted_name [40163,40183]
dotted_name [40281,40301]
===
match
---
fstring [7645,7660]
fstring [7661,7676]
===
match
---
trailer [10308,10315]
trailer [10324,10331]
===
match
---
name: fields_to_check [14374,14389]
name: fields_to_check [14390,14405]
===
match
---
name: DummyOperator [36916,36929]
name: DummyOperator [37034,37047]
===
match
---
atom [4777,4829]
atom [4793,4845]
===
match
---
trailer [10796,10798]
trailer [10812,10814]
===
match
---
dotted_name [1407,1429]
dotted_name [1423,1445]
===
match
---
for_stmt [15193,15388]
for_stmt [15209,15404]
===
match
---
atom [2385,2424]
atom [2401,2440]
===
match
---
name: MyOperator [25702,25712]
name: MyOperator [25820,25830]
===
match
---
comparison [23458,23509]
comparison [23576,23627]
===
match
---
string: 'email' [34712,34719]
string: 'email' [34830,34837]
===
match
---
operator: , [26921,26922]
operator: , [27039,27040]
===
match
---
atom_expr [15332,15347]
atom_expr [15348,15363]
===
match
---
string: "_downstream_task_ids" [4608,4630]
string: "_downstream_task_ids" [4624,4646]
===
match
---
testlist_comp [29675,29717]
testlist_comp [29793,29835]
===
match
---
name: execution_date [24298,24312]
name: execution_date [24416,24430]
===
match
---
trailer [12210,12355]
trailer [12226,12371]
===
match
---
number: 1 [16170,16171]
number: 1 [16186,16187]
===
match
---
simple_stmt [36581,36651]
simple_stmt [36699,36769]
===
match
---
name: children [37864,37872]
name: children [37982,37990]
===
match
---
trailer [10789,10799]
trailer [10805,10815]
===
match
---
operator: = [7473,7474]
operator: = [7489,7490]
===
match
---
simple_stmt [13517,13658]
simple_stmt [13533,13674]
===
match
---
atom_expr [29319,29333]
atom_expr [29437,29451]
===
match
---
name: datetime [921,929]
name: datetime [921,929]
===
match
---
atom_expr [45904,45952]
atom_expr [46022,46070]
===
match
---
operator: , [43676,43677]
operator: , [43794,43795]
===
match
---
string: "__var" [19321,19328]
string: "__var" [19439,19446]
===
match
---
atom_expr [42128,42148]
atom_expr [42246,42266]
===
match
---
name: serialized [20888,20898]
name: serialized [21006,21016]
===
match
---
name: bash_command [6592,6604]
name: bash_command [6608,6620]
===
match
---
simple_stmt [15235,15388]
simple_stmt [15251,15404]
===
match
---
string: "bar" [30226,30231]
string: "bar" [30344,30349]
===
match
---
dictorsetmaker [27719,27788]
dictorsetmaker [27837,27906]
===
match
---
operator: , [1947,1948]
operator: , [1963,1964]
===
match
---
classdef [25383,25610]
classdef [25501,25728]
===
match
---
atom_expr [29387,29400]
atom_expr [29505,29518]
===
match
---
atom [43074,43250]
atom [43192,43368]
===
match
---
operator: } [5525,5526]
operator: } [5541,5542]
===
match
---
atom [29576,29578]
atom [29694,29696]
===
match
---
param [31613,31618]
param [31731,31736]
===
match
---
name: edge_info [39420,39429]
name: edge_info [39538,39547]
===
match
---
operator: , [2907,2908]
operator: , [2923,2924]
===
match
---
assert_stmt [33175,33228]
assert_stmt [33293,33346]
===
match
---
comparison [41062,41112]
comparison [41180,41230]
===
match
---
string: "foo2" [30064,30070]
string: "foo2" [30182,30188]
===
match
---
assert_stmt [13121,13251]
assert_stmt [13137,13267]
===
match
---
name: expected_dict [38210,38223]
name: expected_dict [38328,38341]
===
match
---
fstring_expr [29222,29247]
fstring_expr [29340,29365]
===
match
---
fstring_end: ' [15386,15387]
fstring_end: ' [15402,15403]
===
match
---
simple_stmt [41210,41269]
simple_stmt [41328,41387]
===
match
---
operator: == [22629,22631]
operator: == [22747,22749]
===
match
---
assert_stmt [27550,27800]
assert_stmt [27668,27918]
===
match
---
operator: } [34902,34903]
operator: } [35020,35021]
===
match
---
name: simple_task [23573,23584]
name: simple_task [23691,23702]
===
match
---
dictorsetmaker [2386,2423]
dictorsetmaker [2402,2439]
===
match
---
simple_stmt [38612,38683]
simple_stmt [38730,38801]
===
match
---
argument [6673,6726]
argument [6689,6742]
===
match
---
atom_expr [14904,14929]
atom_expr [14920,14945]
===
match
---
name: serialized_dag [26972,26986]
name: serialized_dag [27090,27104]
===
match
---
param [33510,33515]
param [33628,33633]
===
match
---
assert_stmt [41055,41112]
assert_stmt [41173,41230]
===
match
---
trailer [11670,11672]
trailer [11686,11688]
===
match
---
trailer [22452,22455]
trailer [22570,22573]
===
match
---
name: task_end_date [18630,18643]
name: task_end_date [18748,18761]
===
match
---
operator: , [6144,6145]
operator: , [6160,6161]
===
match
---
string: "pool" [5139,5145]
string: "pool" [5155,5161]
===
match
---
string: "fileloc" [19745,19754]
string: "fileloc" [19863,19872]
===
match
---
trailer [6212,6225]
trailer [6228,6241]
===
match
---
trailer [42488,42512]
trailer [42606,42630]
===
match
---
dictorsetmaker [43468,43557]
dictorsetmaker [43586,43675]
===
match
---
name: SerializedDAG [20861,20874]
name: SerializedDAG [20979,20992]
===
match
---
operator: } [4317,4318]
operator: } [4333,4334]
===
match
---
name: dag_id [15341,15347]
name: dag_id [15357,15363]
===
match
---
testlist_comp [19297,19376]
testlist_comp [19415,19494]
===
match
---
testlist_comp [40208,40260]
testlist_comp [40326,40378]
===
match
---
trailer [33189,33211]
trailer [33307,33329]
===
match
---
operator: , [19910,19911]
operator: , [20028,20029]
===
match
---
atom [5004,5006]
atom [5020,5022]
===
match
---
name: datetime [42128,42136]
name: datetime [42246,42254]
===
match
---
suite [44110,44443]
suite [44228,44561]
===
match
---
string: 'on_execute_callback' [35007,35028]
string: 'on_execute_callback' [35125,35146]
===
match
---
name: upstream_task_ids [15087,15104]
name: upstream_task_ids [15103,15120]
===
match
---
name: deserialized_simple_task [21783,21807]
name: deserialized_simple_task [21901,21925]
===
match
---
number: 2 [20665,20666]
number: 2 [20783,20784]
===
match
---
operator: == [10261,10263]
operator: == [10277,10279]
===
match
---
operator: = [6220,6221]
operator: = [6236,6237]
===
match
---
name: self [9591,9595]
name: self [9607,9611]
===
match
---
atom [18080,18274]
atom [18198,18392]
===
match
---
simple_stmt [8167,8191]
simple_stmt [8183,8207]
===
match
---
operator: = [21320,21321]
operator: = [21438,21439]
===
match
---
expr_stmt [37228,37266]
expr_stmt [37346,37384]
===
match
---
trailer [17199,17206]
trailer [17317,17324]
===
match
---
dotted_name [38696,38719]
dotted_name [38814,38837]
===
match
---
name: _serialize [20782,20792]
name: _serialize [20900,20910]
===
match
---
operator: , [4634,4635]
operator: , [4650,4651]
===
match
---
comparison [42249,42299]
comparison [42367,42417]
===
match
---
atom [43157,43190]
atom [43275,43308]
===
match
---
name: serialize_operator [33760,33778]
name: serialize_operator [33878,33896]
===
match
---
fstring_expr [15331,15348]
fstring_expr [15347,15364]
===
match
---
atom_expr [15947,15969]
atom_expr [15963,15985]
===
match
---
testlist_comp [30658,31527]
testlist_comp [30776,31645]
===
match
---
atom [19621,19910]
atom [19739,20028]
===
match
---
string: "bash_command" [27031,27045]
string: "bash_command" [27149,27163]
===
match
---
suite [22307,22373]
suite [22425,22491]
===
match
---
arglist [17462,17535]
arglist [17580,17653]
===
match
---
string: 'label' [34943,34950]
string: 'label' [35061,35068]
===
match
---
name: operator_extra_links [25507,25527]
name: operator_extra_links [25625,25645]
===
match
---
trailer [23548,23564]
trailer [23666,23682]
===
match
---
operator: } [21032,21033]
operator: } [21150,21151]
===
match
---
suite [8056,8191]
suite [8072,8207]
===
match
---
string: "dag" [18940,18945]
string: "dag" [19058,19063]
===
match
---
number: 2 [16229,16230]
number: 2 [16245,16246]
===
match
---
trailer [33349,33362]
trailer [33467,33480]
===
match
---
trailer [38918,38935]
trailer [39036,39053]
===
match
---
name: parameterized [20942,20955]
name: parameterized [21060,21073]
===
match
---
number: 30 [16435,16437]
number: 30 [16451,16453]
===
match
---
trailer [15962,15969]
trailer [15978,15985]
===
match
---
name: dag [11796,11799]
name: dag [11812,11815]
===
match
---
simple_stmt [32805,32993]
simple_stmt [32923,33111]
===
match
---
operator: = [28100,28101]
operator: = [28218,28219]
===
match
---
trailer [20110,20139]
trailer [20228,20257]
===
match
---
name: stringified_dags [12090,12106]
name: stringified_dags [12106,12122]
===
match
---
argument [17462,17481]
argument [17580,17599]
===
match
---
operator: = [9141,9142]
operator: = [9157,9158]
===
match
---
operator: , [2758,2759]
operator: , [2774,2775]
===
match
---
arglist [15250,15272]
arglist [15266,15288]
===
match
---
operator: } [43189,43190]
operator: } [43307,43308]
===
match
---
name: start [11586,11591]
name: start [11602,11607]
===
match
---
operator: , [2792,2793]
operator: , [2808,2809]
===
match
---
atom_expr [14392,14420]
atom_expr [14408,14436]
===
match
---
expr_stmt [37125,37159]
expr_stmt [37243,37277]
===
match
---
operator: = [24312,24313]
operator: = [24430,24431]
===
match
---
trailer [9775,9777]
trailer [9791,9793]
===
match
---
name: output [25977,25983]
name: output [26095,26101]
===
match
---
name: operator [25309,25317]
name: operator [25427,25435]
===
match
---
name: SerializedDAG [1635,1648]
name: SerializedDAG [1651,1664]
===
match
---
fstring_expr [13215,13227]
fstring_expr [13231,13243]
===
match
---
string: "_dag_id" [3009,3018]
string: "_dag_id" [3025,3034]
===
match
---
name: parameterized [17724,17737]
name: parameterized [17842,17855]
===
match
---
operator: , [20409,20410]
operator: , [20527,20528]
===
match
---
operator: , [19513,19514]
operator: , [19631,19632]
===
match
---
atom_expr [5436,5463]
atom_expr [5452,5479]
===
match
---
operator: { [30022,30023]
operator: { [30140,30141]
===
match
---
string: "fileloc" [3094,3103]
string: "fileloc" [3110,3119]
===
match
---
operator: = [30949,30950]
operator: = [31067,31068]
===
match
---
operator: = [37344,37345]
operator: = [37462,37463]
===
match
---
trailer [39095,39103]
trailer [39213,39221]
===
match
---
trailer [15769,15779]
trailer [15785,15795]
===
match
---
operator: { [30233,30234]
operator: { [30351,30352]
===
match
---
string: "value" [43174,43181]
string: "value" [43292,43299]
===
match
---
trailer [10724,10733]
trailer [10740,10749]
===
match
---
number: 0 [17216,17217]
number: 0 [17334,17335]
===
match
---
atom_expr [39236,39281]
atom_expr [39354,39399]
===
match
---
fstring_start: f" [29220,29222]
fstring_start: f" [29338,29340]
===
match
---
name: serialized_dag [42278,42292]
name: serialized_dag [42396,42410]
===
match
---
parameters [12606,12633]
parameters [12622,12649]
===
match
---
operator: , [37539,37540]
operator: , [37657,37658]
===
match
---
import_from [1649,1733]
import_from [1665,1749]
===
match
---
name: month [20327,20332]
name: month [20445,20450]
===
match
---
operator: = [7357,7358]
operator: = [7373,7374]
===
match
---
string: 'doc_rst' [34653,34662]
string: 'doc_rst' [34771,34780]
===
match
---
operator: = [44939,44940]
operator: = [45057,45058]
===
match
---
operator: = [38224,38225]
operator: = [38342,38343]
===
match
---
string: 'simple_task' [26908,26921]
string: 'simple_task' [27026,27039]
===
match
---
trailer [23506,23509]
trailer [23624,23627]
===
match
---
trailer [18865,18874]
trailer [18983,18992]
===
match
---
name: c [45475,45476]
name: c [45593,45594]
===
match
---
argument [37198,37213]
argument [37316,37331]
===
match
---
name: val [20731,20734]
name: val [20849,20852]
===
match
---
name: expected_value [42516,42530]
name: expected_value [42634,42648]
===
match
---
name: BaseOperator [1371,1383]
name: BaseOperator [1387,1399]
===
match
---
simple_stmt [27550,27801]
simple_stmt [27668,27919]
===
match
---
suite [37831,37882]
suite [37949,38000]
===
match
---
name: task_id [18506,18513]
name: task_id [18624,18631]
===
match
---
atom_expr [41091,41112]
atom_expr [41209,41230]
===
match
---
suite [10142,11104]
suite [10158,11120]
===
match
---
name: self [25303,25307]
name: self [25421,25425]
===
match
---
arglist [36828,36886]
arglist [36946,37004]
===
match
---
atom [20284,20296]
atom [20402,20414]
===
match
---
name: self [29293,29297]
name: self [29411,29415]
===
match
---
operator: = [8128,8129]
operator: = [8144,8145]
===
match
---
operator: } [35239,35240]
operator: } [35357,35358]
===
match
---
atom [20527,20530]
atom [20645,20648]
===
match
---
operator: = [39831,39832]
operator: = [39949,39950]
===
match
---
name: val [21996,21999]
name: val [22114,22117]
===
match
---
string: "timedelta" [2332,2343]
string: "timedelta" [2348,2359]
===
match
---
expr_stmt [36773,36810]
expr_stmt [36891,36928]
===
match
---
import_name [890,899]
import_name [890,899]
===
match
---
trailer [10751,10758]
trailer [10767,10774]
===
match
---
trailer [44800,44811]
trailer [44918,44929]
===
match
---
operator: = [23230,23231]
operator: = [23348,23349]
===
match
---
string: "{{ task.task_id }}" [30796,30816]
string: "{{ task.task_id }}" [30914,30934]
===
match
---
comparison [18911,18958]
comparison [19029,19076]
===
match
---
name: airflow [1213,1220]
name: airflow [1229,1236]
===
match
---
operator: , [6270,6271]
operator: , [6286,6287]
===
match
---
name: __str__ [29324,29331]
name: __str__ [29442,29449]
===
match
---
operator: = [1802,1803]
operator: = [1818,1819]
===
match
---
comparison [27204,27260]
comparison [27322,27378]
===
match
---
trailer [13751,13760]
trailer [13767,13776]
===
match
---
name: get [11667,11670]
name: get [11683,11686]
===
match
---
name: has_on_success_callback [41302,41325]
name: has_on_success_callback [41420,41443]
===
match
---
expr_stmt [45717,45848]
expr_stmt [45835,45966]
===
match
---
name: startswith [45551,45561]
name: startswith [45669,45679]
===
match
---
string: 'tests.test_utils.mock_operators.CustomBaseIndexOpLink' [27634,27689]
string: 'tests.test_utils.mock_operators.CustomBaseIndexOpLink' [27752,27807]
===
match
---
atom_expr [37019,37049]
atom_expr [37137,37167]
===
match
---
string: "{{ task.task_id }}" [29980,30000]
string: "{{ task.task_id }}" [30098,30118]
===
match
---
argument [30360,30385]
argument [30478,30503]
===
match
---
arglist [18226,18258]
arglist [18344,18376]
===
match
---
expr_stmt [11818,11852]
expr_stmt [11834,11868]
===
match
---
string: "task4" [37206,37213]
string: "task4" [37324,37331]
===
match
---
string: "__var" [20374,20381]
string: "__var" [20492,20499]
===
match
---
atom_expr [13774,13862]
atom_expr [13790,13878]
===
match
---
fstring_string: / [8440,8441]
fstring_string: / [8456,8457]
===
match
---
string: 'end_date' [34813,34823]
string: 'end_date' [34931,34941]
===
match
---
name: CustomOpLink [1709,1721]
name: CustomOpLink [1725,1737]
===
match
---
name: dag_start_date [16597,16611]
name: dag_start_date [16715,16729]
===
match
---
name: do_xcom_push [33611,33623]
name: do_xcom_push [33729,33741]
===
match
---
trailer [24713,24729]
trailer [24831,24847]
===
match
---
operator: { [4826,4827]
operator: { [4842,4843]
===
match
---
string: 'task_1' [43945,43953]
string: 'task_1' [44063,44071]
===
match
---
suite [13761,13863]
suite [13777,13879]
===
match
---
string: "__version" [19586,19597]
string: "__version" [19704,19715]
===
match
---
name: dag [13187,13190]
name: dag [13203,13206]
===
match
---
name: dag_folder [8713,8723]
name: dag_folder [8729,8739]
===
match
---
name: task_group [36736,36746]
name: task_group [36854,36864]
===
match
---
string: "timedelta" [19308,19319]
string: "timedelta" [19426,19437]
===
match
---
arglist [24730,24756]
arglist [24848,24874]
===
match
---
suite [14120,15978]
suite [14136,15994]
===
match
---
simple_stmt [28120,28185]
simple_stmt [28238,28303]
===
match
---
parameters [25572,25587]
parameters [25690,25705]
===
match
---
name: assertLogs [25801,25811]
name: assertLogs [25919,25929]
===
match
---
name: field [13083,13088]
name: field [13099,13104]
===
match
---
operator: { [20993,20994]
operator: { [21111,21112]
===
match
---
name: load_dag_schema_dict [32659,32679]
name: load_dag_schema_dict [32777,32797]
===
match
---
testlist_comp [5436,5492]
testlist_comp [5452,5508]
===
match
---
operator: { [30072,30073]
operator: { [30190,30191]
===
match
---
trailer [11585,11591]
trailer [11601,11607]
===
match
---
name: dag [17713,17716]
name: dag [17831,17834]
===
match
---
simple_stmt [14200,14259]
simple_stmt [14216,14275]
===
match
---
atom_expr [41179,41200]
atom_expr [41297,41318]
===
match
---
atom [29734,29763]
atom [29852,29881]
===
match
---
assert_stmt [17333,17390]
assert_stmt [17451,17508]
===
match
---
number: 1 [36808,36809]
number: 1 [36926,36927]
===
match
---
name: keys [11962,11966]
name: keys [11978,11982]
===
match
---
string: 'resources' [35385,35396]
string: 'resources' [35503,35514]
===
match
---
operator: { [43100,43101]
operator: { [43218,43219]
===
match
---
operator: , [20991,20992]
operator: , [21109,21110]
===
match
---
string: "deps" [40017,40023]
string: "deps" [40135,40141]
===
match
---
import_from [1168,1207]
import_from [1184,1223]
===
match
---
name: ACTION_CAN_EDIT [5477,5492]
name: ACTION_CAN_EDIT [5493,5508]
===
match
---
classdef [25122,25374]
classdef [25240,25492]
===
match
---
operator: , [2579,2580]
operator: , [2595,2596]
===
match
---
name: expand [19147,19153]
name: expand [19265,19271]
===
match
---
assert_stmt [38307,38318]
assert_stmt [38425,38436]
===
match
---
number: 1 [21355,21356]
number: 1 [21473,21474]
===
match
---
name: start_date [40930,40940]
name: start_date [41048,41058]
===
match
---
name: dag [42198,42201]
name: dag [42316,42319]
===
match
---
operator: , [35155,35156]
operator: , [35273,35274]
===
match
---
expr_stmt [20755,20797]
expr_stmt [20873,20915]
===
match
---
operator: , [40928,40929]
operator: , [41046,41047]
===
match
---
atom [30233,30264]
atom [30351,30382]
===
match
---
name: sorted_serialized_dag [11072,11093]
name: sorted_serialized_dag [11088,11109]
===
match
---
operator: { [21914,21915]
operator: { [22032,22033]
===
match
---
atom_expr [8780,8804]
atom_expr [8796,8820]
===
match
---
param [9591,9595]
param [9607,9611]
===
match
---
string: "simple_task" [17310,17323]
string: "simple_task" [17428,17441]
===
match
---
suite [22726,24825]
suite [22844,24943]
===
match
---
string: "relativedelta" [20489,20504]
string: "relativedelta" [20607,20622]
===
match
---
operator: , [18066,18067]
operator: , [18184,18185]
===
match
---
atom_expr [1872,1970]
atom_expr [1888,1986]
===
match
---
suite [39997,40036]
suite [40115,40154]
===
match
---
operator: , [38842,38843]
operator: , [38960,38961]
===
match
---
operator: , [16430,16431]
operator: , [16446,16447]
===
match
---
operator: = [17845,17846]
operator: = [17963,17964]
===
match
---
suite [38603,39430]
suite [38721,39548]
===
match
---
name: utils [36730,36735]
name: utils [36848,36853]
===
match
---
simple_stmt [20033,20092]
simple_stmt [20151,20210]
===
match
---
string: "timezone" [5237,5247]
string: "timezone" [5253,5263]
===
match
---
atom_expr [7696,7834]
atom_expr [7712,7850]
===
match
---
name: task_group [38547,38557]
name: task_group [38665,38675]
===
match
---
sync_comp_for [45502,45573]
sync_comp_for [45620,45691]
===
match
---
operator: = [39851,39852]
operator: = [39969,39970]
===
match
---
string: "ui_fgcolor" [3558,3570]
string: "ui_fgcolor" [3574,3586]
===
match
---
operator: = [44643,44644]
operator: = [44761,44762]
===
match
---
funcdef [8997,9563]
funcdef [9013,9579]
===
match
---
operator: , [29763,29764]
operator: , [29881,29882]
===
match
---
operator: , [20504,20505]
operator: , [20622,20623]
===
match
---
trailer [6265,6277]
trailer [6281,6293]
===
match
---
name: SerializedDAG [11739,11752]
name: SerializedDAG [11755,11768]
===
match
---
string: 'BigQuery Console #2' [27941,27962]
string: 'BigQuery Console #2' [28059,28080]
===
match
---
trailer [27590,27615]
trailer [27708,27733]
===
match
---
operator: , [18173,18174]
operator: , [18291,18292]
===
match
---
operator: = [18439,18440]
operator: = [18557,18558]
===
match
---
funcdef [7231,7339]
funcdef [7247,7355]
===
match
---
trailer [26833,26876]
trailer [26951,26994]
===
match
---
param [40357,40381]
param [40475,40499]
===
match
---
atom_expr [11818,11846]
atom_expr [11834,11862]
===
match
---
trailer [9847,9863]
trailer [9863,9879]
===
match
---
operator: } [13639,13640]
operator: } [13655,13656]
===
match
---
atom_expr [5851,5862]
atom_expr [5867,5878]
===
match
---
comparison [17340,17390]
comparison [17458,17508]
===
match
---
name: dag [41978,41981]
name: dag [42096,42099]
===
match
---
operator: , [16171,16172]
operator: , [16187,16188]
===
match
---
string: "_access_control" [10829,10846]
string: "_access_control" [10845,10862]
===
match
---
atom [43100,43131]
atom [43218,43249]
===
match
---
operator: } [29762,29763]
operator: } [29880,29881]
===
match
---
name: BashOperator [32066,32078]
name: BashOperator [32184,32196]
===
match
---
operator: , [18029,18030]
operator: , [18147,18148]
===
match
---
suite [25414,25610]
suite [25532,25728]
===
match
---
atom_expr [15003,15028]
atom_expr [15019,15044]
===
match
---
simple_stmt [11778,11806]
simple_stmt [11794,11822]
===
match
---
operator: = [6566,6567]
operator: = [6582,6583]
===
match
---
trailer [20043,20061]
trailer [20161,20179]
===
match
---
operator: { [41463,41464]
operator: { [41581,41582]
===
match
---
suite [39754,39784]
suite [39872,39902]
===
match
---
name: permissions [5465,5476]
name: permissions [5481,5492]
===
match
---
import_from [36659,36708]
import_from [36777,36826]
===
match
---
operator: = [16385,16386]
operator: = [16401,16402]
===
match
---
atom_expr [17920,17932]
atom_expr [18038,18050]
===
match
---
name: GoogleLink [1723,1733]
name: GoogleLink [1739,1749]
===
match
---
string: "dag" [41106,41111]
string: "dag" [41224,41229]
===
match
---
return_stmt [10997,11012]
return_stmt [11013,11028]
===
match
---
fstring_end: ' [7659,7660]
fstring_end: ' [7675,7676]
===
match
---
name: DAG [33186,33189]
name: DAG [33304,33307]
===
match
---
atom_expr [42072,42149]
atom_expr [42190,42267]
===
match
---
atom_expr [37652,37686]
atom_expr [37770,37804]
===
match
---
trailer [12063,12089]
trailer [12079,12105]
===
match
---
string: """Serialization and deserialization should work for every DAG and Operator.""" [9606,9685]
string: """Serialization and deserialization should work for every DAG and Operator.""" [9622,9701]
===
match
---
arglist [5973,6464]
arglist [5989,6480]
===
match
---
atom_expr [39416,39429]
atom_expr [39534,39547]
===
match
---
operator: { [3142,3143]
operator: { [3158,3159]
===
match
---
atom_expr [13980,14008]
atom_expr [13996,14024]
===
match
---
operator: = [9107,9108]
operator: = [9123,9124]
===
match
---
string: 'pool' [35254,35260]
string: 'pool' [35372,35378]
===
match
---
name: k8s [1824,1827]
name: k8s [1840,1843]
===
match
---
operator: , [8256,8257]
operator: , [8272,8273]
===
match
---
atom [29963,30002]
atom [30081,30120]
===
match
---
operator: { [24050,24051]
operator: { [24168,24169]
===
match
---
atom_expr [11739,11765]
atom_expr [11755,11781]
===
match
---
string: "{{ task.task_id }}" [29826,29846]
string: "{{ task.task_id }}" [29944,29964]
===
match
---
name: dag [7263,7266]
name: dag [7279,7282]
===
match
---
name: set [34479,34482]
name: set [34597,34600]
===
match
---
operator: , [17992,17993]
operator: , [18110,18111]
===
match
---
operator: , [3109,3110]
operator: , [3125,3126]
===
match
---
operator: } [28039,28040]
operator: } [28157,28158]
===
match
---
operator: { [21011,21012]
operator: { [21129,21130]
===
match
---
string: 'bash_command' [3616,3630]
string: 'bash_command' [3632,3646]
===
match
---
operator: = [6340,6341]
operator: = [6356,6357]
===
match
---
testlist_comp [19259,19281]
testlist_comp [19377,19399]
===
match
---
name: dag [21317,21320]
name: dag [21435,21438]
===
match
---
string: 'trigger_rule' [35721,35735]
string: 'trigger_rule' [35839,35853]
===
match
---
operator: , [34698,34699]
operator: , [34816,34817]
===
match
---
operator: } [43555,43556]
operator: } [43673,43674]
===
match
---
trailer [17299,17309]
trailer [17417,17427]
===
match
---
fstring_expr [8427,8440]
fstring_expr [8443,8456]
===
match
---
operator: , [34639,34640]
operator: , [34757,34758]
===
match
---
name: airflow [1407,1414]
name: airflow [1423,1430]
===
match
---
testlist_comp [16029,16119]
testlist_comp [16045,16135]
===
match
---
arglist [8079,8104]
arglist [8095,8120]
===
match
---
name: google_link_from_plugin [24676,24699]
name: google_link_from_plugin [24794,24817]
===
match
---
trailer [42136,42148]
trailer [42254,42266]
===
match
---
operator: , [19828,19829]
operator: , [19946,19947]
===
match
---
atom_expr [11416,11439]
atom_expr [11432,11455]
===
match
---
operator: , [2117,2118]
operator: , [2133,2134]
===
match
---
name: realpath [5628,5636]
name: realpath [5644,5652]
===
match
---
number: 1 [25678,25679]
number: 1 [25796,25797]
===
match
---
atom_expr [14012,14023]
atom_expr [14028,14039]
===
match
---
trailer [10939,10948]
trailer [10955,10964]
===
match
---
return_stmt [29312,29333]
return_stmt [29430,29451]
===
match
---
simple_stmt [23967,24113]
simple_stmt [24085,24231]
===
match
---
suite [39949,39984]
suite [40067,40102]
===
match
---
operator: { [29734,29735]
operator: { [29852,29853]
===
match
---
not_test [18626,18643]
not_test [18744,18761]
===
match
---
operator: , [36859,36860]
operator: , [36977,36978]
===
match
---
string: "kubernetes" [45599,45611]
string: "kubernetes" [45717,45729]
===
match
---
operator: = [6688,6689]
operator: = [6704,6705]
===
match
---
name: isinstance [8068,8078]
name: isinstance [8084,8094]
===
match
---
trailer [37872,37879]
trailer [37990,37997]
===
match
---
operator: , [3032,3033]
operator: , [3048,3049]
===
match
---
operator: = [10879,10880]
operator: = [10895,10896]
===
match
---
trailer [13829,13838]
trailer [13845,13854]
===
match
---
string: 'task_1' [42948,42956]
string: 'task_1' [43066,43074]
===
match
---
comparison [14963,15028]
comparison [14979,15044]
===
match
---
string: "### DAG Tutorial Documentation" [3052,3084]
string: "### DAG Tutorial Documentation" [3068,3100]
===
match
---
atom_expr [39117,39156]
atom_expr [39235,39274]
===
match
---
comparison [15947,15977]
comparison [15963,15993]
===
match
---
name: nested2 [30886,30893]
name: nested2 [31004,31011]
===
match
---
name: timezone [17979,17987]
name: timezone [18097,18105]
===
match
---
name: airflow [39623,39630]
name: airflow [39741,39748]
===
match
---
atom [43326,43643]
atom [43444,43761]
===
match
---
name: owner [6644,6649]
name: owner [6660,6665]
===
match
---
funcdef [36532,38559]
funcdef [36650,38677]
===
match
---
trailer [37879,37881]
trailer [37997,37999]
===
match
---
name: task_dict [27164,27173]
name: task_dict [27282,27291]
===
match
---
trailer [15884,15913]
trailer [15900,15929]
===
match
---
atom_expr [32659,32717]
atom_expr [32777,32835]
===
match
---
string: "__type" [2246,2254]
string: "__type" [2262,2270]
===
match
---
operator: , [16374,16375]
operator: , [16390,16391]
===
match
---
name: self [20725,20729]
name: self [20843,20847]
===
match
---
simple_stmt [39381,39430]
simple_stmt [39499,39548]
===
match
---
name: self [29194,29198]
name: self [29312,29316]
===
match
---
name: custom_inbuilt_link [24428,24447]
name: custom_inbuilt_link [24546,24565]
===
match
---
atom_expr [16270,16311]
atom_expr [16286,16327]
===
match
---
simple_stmt [24676,24758]
simple_stmt [24794,24876]
===
match
---
atom_expr [21655,21696]
atom_expr [21773,21814]
===
match
---
operator: , [43583,43584]
operator: , [43701,43702]
===
match
---
name: node [38384,38388]
name: node [38502,38506]
===
match
---
name: dags [9694,9698]
name: dags [9710,9714]
===
match
---
string: 'default' [35362,35371]
string: 'default' [35480,35489]
===
match
---
operator: = [6509,6510]
operator: = [6525,6526]
===
match
---
string: """Verify non-airflow operators are casted to BaseOperator.""" [14129,14191]
string: """Verify non-airflow operators are casted to BaseOperator.""" [14145,14207]
===
match
---
operator: , [21994,21995]
operator: , [22112,22113]
===
match
---
name: x [41426,41427]
name: x [41544,41545]
===
match
---
suite [17149,17219]
suite [17267,17337]
===
match
---
atom [29572,29574]
atom [29690,29692]
===
match
---
simple_stmt [38999,39062]
simple_stmt [39117,39180]
===
match
---
string: 'task_1' [42890,42898]
string: 'task_1' [43008,43016]
===
match
---
name: execution_date [28086,28100]
name: execution_date [28204,28218]
===
match
---
name: DummyOperator [37129,37142]
name: DummyOperator [37247,37260]
===
match
---
string: "dag" [22354,22359]
string: "dag" [22472,22477]
===
match
---
operator: , [44091,44092]
operator: , [44209,44210]
===
match
---
expr_stmt [11408,11439]
expr_stmt [11424,11455]
===
match
---
name: dttm [25319,25323]
name: dttm [25437,25441]
===
match
---
simple_stmt [33791,33857]
simple_stmt [33909,33975]
===
match
---
argument [16291,16310]
argument [16307,16326]
===
match
---
trailer [46013,46027]
trailer [46131,46145]
===
match
---
name: serialized_dag [23399,23413]
name: serialized_dag [23517,23531]
===
match
---
string: 'bash_command' [3686,3700]
string: 'bash_command' [3702,3716]
===
match
---
string: "bar" [30159,30164]
string: "bar" [30277,30282]
===
match
---
operator: = [41982,41983]
operator: = [42100,42101]
===
match
---
expr_stmt [7938,7947]
expr_stmt [7954,7963]
===
match
---
name: expected_field [31636,31650]
name: expected_field [31754,31768]
===
match
---
atom_expr [33873,33899]
atom_expr [33991,34017]
===
match
---
dictorsetmaker [43781,43833]
dictorsetmaker [43899,43951]
===
match
---
sync_comp_for [8609,8661]
sync_comp_for [8625,8677]
===
match
---
string: 'executor_config' [34882,34899]
string: 'executor_config' [35000,35017]
===
match
---
operator: , [42956,42957]
operator: , [43074,43075]
===
match
---
string: 'task_2' [42910,42918]
string: 'task_2' [43028,43036]
===
match
---
name: __init__ [33571,33579]
name: __init__ [33689,33697]
===
match
---
name: self [33606,33610]
name: self [33724,33728]
===
match
---
operator: , [24231,24232]
operator: , [24349,24350]
===
match
---
atom_expr [25796,25870]
atom_expr [25914,25988]
===
match
---
operator: , [17834,17835]
operator: , [17952,17953]
===
match
---
string: "task_id" [4426,4435]
string: "task_id" [4442,4451]
===
match
---
atom_expr [14963,14999]
atom_expr [14979,15015]
===
match
---
operator: , [28029,28030]
operator: , [28147,28148]
===
match
---
trailer [11470,11478]
trailer [11486,11494]
===
match
---
testlist_comp [27245,27259]
testlist_comp [27363,27377]
===
match
---
operator: = [45223,45224]
operator: = [45341,45342]
===
match
---
trailer [23590,23600]
trailer [23708,23718]
===
match
---
string: "foo2" [29964,29970]
string: "foo2" [30082,30088]
===
match
---
simple_stmt [20755,20798]
simple_stmt [20873,20916]
===
match
---
name: v [11688,11689]
name: v [11704,11705]
===
match
---
operator: , [10112,10113]
operator: , [10128,10129]
===
match
---
operator: , [1308,1309]
operator: , [1324,1325]
===
match
---
comp_op [17095,17101]
comp_op [17213,17219]
===
match
---
simple_stmt [23451,23510]
simple_stmt [23569,23628]
===
match
---
name: DAG [21236,21239]
name: DAG [21354,21357]
===
match
---
string: "dag" [42381,42386]
string: "dag" [42499,42504]
===
match
---
string: '_task_group' [2496,2509]
string: '_task_group' [2512,2525]
===
match
---
atom_expr [25755,25781]
atom_expr [25873,25899]
===
match
---
operator: { [43286,43287]
operator: { [43404,43405]
===
match
---
string: 'max_retry_delay' [34970,34987]
string: 'max_retry_delay' [35088,35105]
===
match
---
atom [39480,39495]
atom [39598,39613]
===
match
---
suite [33966,36527]
suite [34084,36645]
===
match
---
comparison [13442,13474]
comparison [13458,13490]
===
match
---
string: "tasks" [19782,19789]
string: "tasks" [19900,19907]
===
match
---
argument [26932,26961]
argument [27050,27079]
===
match
---
funcdef [37787,38506]
funcdef [37905,38624]
===
match
---
simple_stmt [18571,18615]
simple_stmt [18689,18733]
===
match
---
operator: } [45582,45583]
operator: } [45700,45701]
===
match
---
number: 2019 [18166,18170]
number: 2019 [18284,18288]
===
match
---
operator: , [5709,5710]
operator: , [5725,5726]
===
match
---
simple_stmt [33689,33721]
simple_stmt [33807,33839]
===
match
---
dictorsetmaker [2322,2359]
dictorsetmaker [2338,2375]
===
match
---
atom_expr [17102,17135]
atom_expr [17220,17253]
===
match
---
name: deserialized_dag [42472,42488]
name: deserialized_dag [42590,42606]
===
match
---
name: task_id [42085,42092]
name: task_id [42203,42210]
===
match
---
operator: , [4318,4319]
operator: , [4334,4335]
===
match
---
name: CustomOperator [6487,6501]
name: CustomOperator [6503,6517]
===
match
---
simple_stmt [8209,8366]
simple_stmt [8225,8382]
===
match
---
simple_stmt [34224,36527]
simple_stmt [34342,36645]
===
match
---
operator: { [8596,8597]
operator: { [8612,8613]
===
match
---
suite [38884,39062]
suite [39002,39180]
===
match
---
string: "ClassWithCustomAttributes(" [31131,31159]
string: "ClassWithCustomAttributes(" [31249,31277]
===
match
---
decorated [40162,41344]
decorated [40280,41462]
===
match
---
number: 0 [44694,44695]
number: 0 [44812,44813]
===
match
---
operator: , [43762,43763]
operator: , [43880,43881]
===
match
---
name: dag [8813,8816]
name: dag [8829,8832]
===
match
---
number: 100.0 [3353,3358]
number: 100.0 [3369,3374]
===
match
---
name: datetime [18440,18448]
name: datetime [18558,18566]
===
match
---
arglist [16367,16398]
arglist [16383,16414]
===
match
---
atom_expr [15563,15577]
atom_expr [15579,15593]
===
match
---
arglist [16486,16517]
arglist [16502,16533]
===
match
---
string: "_access_control" [5264,5281]
string: "_access_control" [5280,5297]
===
match
---
return_stmt [8667,8678]
return_stmt [8683,8694]
===
match
---
name: k8s [1123,1126]
name: k8s [1139,1142]
===
match
---
string: "pod_override" [4097,4111]
string: "pod_override" [4113,4127]
===
match
---
for_stmt [8403,8508]
for_stmt [8419,8524]
===
match
---
string: "doc_md" [3042,3050]
string: "doc_md" [3058,3066]
===
match
---
operator: = [6140,6141]
operator: = [6156,6157]
===
match
---
testlist_comp [29921,30104]
testlist_comp [30039,30222]
===
match
---
atom_expr [27098,27137]
atom_expr [27216,27255]
===
match
---
argument [41988,42035]
argument [42106,42153]
===
match
---
simple_stmt [7952,7983]
simple_stmt [7968,7999]
===
match
---
name: bash_command [32095,32107]
name: bash_command [32213,32225]
===
match
---
name: name [13719,13723]
name: name [13735,13739]
===
match
---
name: collect_dags [7870,7882]
name: collect_dags [7886,7898]
===
match
---
operator: = [32149,32150]
operator: = [32267,32268]
===
match
---
name: end_date [18462,18470]
name: end_date [18580,18588]
===
match
---
assert_stmt [28330,28419]
assert_stmt [28448,28537]
===
match
---
argument [21261,21271]
argument [21379,21389]
===
match
---
simple_stmt [1402,1450]
simple_stmt [1418,1466]
===
match
---
simple_stmt [8730,8769]
simple_stmt [8746,8785]
===
match
---
name: datetime [16211,16219]
name: datetime [16227,16235]
===
match
---
assert_stmt [28817,28875]
assert_stmt [28935,28993]
===
match
---
operator: = [30768,30769]
operator: = [30886,30887]
===
match
---
operator: { [30158,30159]
operator: { [30276,30277]
===
match
---
operator: , [42608,42609]
operator: , [42726,42727]
===
match
---
operator: == [29401,29403]
operator: == [29519,29521]
===
match
---
atom_expr [23525,23564]
atom_expr [23643,23682]
===
match
---
simple_stmt [22399,22456]
simple_stmt [22517,22574]
===
match
---
dictorsetmaker [4426,5202]
dictorsetmaker [4442,5218]
===
match
---
operator: , [34829,34830]
operator: , [34947,34948]
===
match
---
name: expand [40177,40183]
name: expand [40295,40301]
===
match
---
operator: , [14349,14350]
operator: , [14365,14366]
===
match
---
operator: == [44697,44699]
operator: == [44815,44817]
===
match
---
if_stmt [42211,42388]
if_stmt [42329,42506]
===
match
---
name: to_json [37478,37485]
name: to_json [37596,37603]
===
match
---
name: task5 [37320,37325]
name: task5 [37438,37443]
===
match
---
name: target [11479,11485]
name: target [11495,11501]
===
match
---
name: stringified_dags [11603,11619]
name: stringified_dags [11619,11635]
===
match
---
name: dag_id [12019,12025]
name: dag_id [12035,12041]
===
match
---
parameters [12175,12181]
parameters [12191,12197]
===
match
---
name: timezone [16386,16394]
name: timezone [16402,16410]
===
match
---
atom_expr [28055,28111]
atom_expr [28173,28229]
===
match
---
string: "poke" [39481,39487]
string: "poke" [39599,39605]
===
match
---
atom_expr [37440,37491]
atom_expr [37558,37609]
===
match
---
string: """Make very simple DAG to verify serialization result.""" [5892,5950]
string: """Make very simple DAG to verify serialization result.""" [5908,5966]
===
match
---
operator: = [6649,6650]
operator: = [6665,6666]
===
match
---
trailer [27587,27590]
trailer [27705,27708]
===
match
---
name: keys_for_backwards_compat [33141,33166]
name: keys_for_backwards_compat [33259,33284]
===
match
---
parameters [5747,5760]
parameters [5763,5776]
===
match
---
name: check_task_group [37791,37807]
name: check_task_group [37909,37925]
===
match
---
string: "{{ task.task_id }}" [29742,29762]
string: "{{ task.task_id }}" [29860,29880]
===
match
---
atom_expr [5642,5721]
atom_expr [5658,5737]
===
match
---
name: test_date [26783,26792]
name: test_date [26901,26910]
===
match
---
operator: = [40924,40925]
operator: = [41042,41043]
===
match
---
simple_stmt [12191,12356]
simple_stmt [12207,12372]
===
match
---
simple_stmt [5844,5863]
simple_stmt [5860,5879]
===
match
---
trailer [32218,32228]
trailer [32336,32346]
===
match
---
atom_expr [13706,13723]
atom_expr [13722,13739]
===
match
---
suite [7900,8679]
suite [7916,8695]
===
match
---
suite [39609,40157]
suite [39727,40275]
===
match
---
name: pattern [8442,8449]
name: pattern [8458,8465]
===
match
---
trailer [38969,38986]
trailer [39087,39104]
===
match
---
dotted_name [39436,39456]
dotted_name [39554,39574]
===
match
---
trailer [23490,23497]
trailer [23608,23615]
===
match
---
trailer [12848,12850]
trailer [12864,12866]
===
match
---
simple_stmt [6533,6792]
simple_stmt [6549,6808]
===
match
---
simple_stmt [33866,33909]
simple_stmt [33984,34027]
===
match
---
string: """         Test that params work both on Serialized DAGs & Tasks         """ [22024,22101]
string: """         Test that params work both on Serialized DAGs & Tasks         """ [22142,22219]
===
match
---
string: "set" [5399,5404]
string: "set" [5415,5420]
===
match
---
operator: = [22263,22264]
operator: = [22381,22382]
===
match
---
operator: = [10772,10773]
operator: = [10788,10789]
===
match
---
argument [37143,37158]
argument [37261,37276]
===
match
---
operator: } [27703,27704]
operator: } [27821,27822]
===
match
---
name: task_id [13853,13860]
name: task_id [13869,13876]
===
match
---
operator: } [2283,2284]
operator: } [2299,2300]
===
match
---
name: SerializedDAG [39338,39351]
name: SerializedDAG [39456,39469]
===
match
---
lambdef [41419,41440]
lambdef [41537,41558]
===
match
---
name: importlib [45139,45148]
name: importlib [45257,45266]
===
match
---
expr_stmt [38210,38290]
expr_stmt [38328,38408]
===
match
---
operator: = [9699,9700]
operator: = [9715,9716]
===
match
---
simple_stmt [36717,36764]
simple_stmt [36835,36882]
===
match
---
operator: = [37438,37439]
operator: = [37556,37557]
===
match
---
operator: , [2343,2344]
operator: , [2359,2360]
===
match
---
operator: = [20340,20341]
operator: = [20458,20459]
===
match
---
simple_stmt [38749,38794]
simple_stmt [38867,38912]
===
match
---
trailer [18939,18946]
trailer [19057,19064]
===
match
---
operator: , [6383,6384]
operator: , [6399,6400]
===
match
---
operator: } [29246,29247]
operator: } [29364,29365]
===
match
---
name: timedelta [947,956]
name: timedelta [947,956]
===
match
---
atom [17768,17860]
atom [17886,17978]
===
match
---
operator: , [22230,22231]
operator: , [22348,22349]
===
match
---
name: dict [44303,44307]
name: dict [44421,44425]
===
match
---
suite [15222,15388]
suite [15238,15404]
===
match
---
atom_expr [33186,33213]
atom_expr [33304,33331]
===
match
---
string: 'upstream_task_ids' [2884,2903]
string: 'upstream_task_ids' [2900,2919]
===
match
---
trailer [10821,10828]
trailer [10837,10844]
===
match
---
import_from [1127,1166]
import_from [1143,1182]
===
match
---
trailer [16843,16851]
trailer [16961,16969]
===
match
---
name: serialized_dag [13806,13820]
name: serialized_dag [13822,13836]
===
match
---
name: test_date [24313,24322]
name: test_date [24431,24440]
===
match
---
operator: , [35214,35215]
operator: , [35332,35333]
===
match
---
string: 'simple_task' [40906,40919]
string: 'simple_task' [41024,41037]
===
match
---
trailer [38364,38383]
trailer [38482,38501]
===
match
---
operator: == [24581,24583]
operator: == [24699,24701]
===
match
---
name: dag [11835,11838]
name: dag [11851,11854]
===
match
---
string: "test_serialized_template_fields" [31968,32001]
string: "test_serialized_template_fields" [32086,32119]
===
match
---
string: "att3" [31016,31022]
string: "att3" [31134,31140]
===
match
---
comparison [20813,20835]
comparison [20931,20953]
===
match
---
trailer [42292,42299]
trailer [42410,42417]
===
match
---
name: directory [8496,8505]
name: directory [8512,8521]
===
match
---
name: bash_command [26932,26944]
name: bash_command [27050,27062]
===
match
---
param [29445,29450]
param [29563,29568]
===
match
---
name: SerializedBaseOperator [38129,38151]
name: SerializedBaseOperator [38247,38269]
===
match
---
trailer [32078,32124]
trailer [32196,32242]
===
match
---
operator: , [3540,3541]
operator: , [3556,3557]
===
match
---
number: 8 [22232,22233]
number: 8 [22350,22351]
===
match
---
atom_expr [8929,8946]
atom_expr [8945,8962]
===
match
---
operator: = [16751,16752]
operator: = [16869,16870]
===
match
---
atom_expr [33653,33680]
atom_expr [33771,33798]
===
match
---
expr_stmt [33730,33782]
expr_stmt [33848,33900]
===
match
---
operator: - [20293,20294]
operator: - [20411,20412]
===
match
---
name: test_extra_operator_links_logs_error_for_non_registered_extra_links [24834,24901]
name: test_extra_operator_links_logs_error_for_non_registered_extra_links [24952,25019]
===
match
---
operator: { [29222,29223]
operator: { [29340,29341]
===
match
---
trailer [18997,19013]
trailer [19115,19131]
===
match
---
name: blob [33851,33855]
name: blob [33969,33973]
===
match
---
operator: = [20766,20767]
operator: = [20884,20885]
===
match
---
trailer [22286,22291]
trailer [22404,22409]
===
match
---
string: "params" [21514,21522]
string: "params" [21632,21640]
===
match
---
arglist [29155,29171]
arglist [29273,29289]
===
match
---
name: dag_id [23271,23277]
name: dag_id [23389,23395]
===
match
---
atom [21010,21058]
atom [21128,21176]
===
match
---
string: "#000" [4898,4904]
string: "#000" [4914,4920]
===
match
---
name: tzinfo [16291,16297]
name: tzinfo [16307,16313]
===
match
---
atom_expr [34149,34175]
atom_expr [34267,34293]
===
match
---
operator: { [29922,29923]
operator: { [30040,30041]
===
match
---
trailer [44678,44688]
trailer [44796,44806]
===
match
---
name: task_id [37143,37150]
name: task_id [37261,37268]
===
match
---
fstring_expr [29248,29268]
fstring_expr [29366,29386]
===
match
---
operator: , [43913,43914]
operator: , [44031,44032]
===
match
---
name: test_edge_info_serialization [38568,38596]
name: test_edge_info_serialization [38686,38714]
===
match
---
name: dag [12629,12632]
name: dag [12645,12648]
===
match
---
name: load_dag_schema_dict [1537,1557]
name: load_dag_schema_dict [1553,1573]
===
match
---
trailer [11838,11845]
trailer [11854,11861]
===
match
---
name: context [25579,25586]
name: context [25697,25704]
===
match
---
atom_expr [23974,24032]
atom_expr [24092,24150]
===
match
---
atom_expr [40989,41015]
atom_expr [41107,41133]
===
match
---
string: "pod_override" [6690,6704]
string: "pod_override" [6706,6720]
===
match
---
trailer [7410,7691]
trailer [7426,7707]
===
match
---
name: dag [9909,9912]
name: dag [9925,9928]
===
match
---
operator: { [20649,20650]
operator: { [20767,20768]
===
match
---
param [36566,36570]
param [36684,36688]
===
match
---
operator: , [13150,13151]
operator: , [13166,13167]
===
match
---
atom [29598,29600]
atom [29716,29718]
===
match
---
comparison [45599,45635]
comparison [45717,45753]
===
match
---
suite [44713,44776]
suite [44831,44894]
===
match
---
name: self [29068,29072]
name: self [29186,29190]
===
match
---
atom_expr [18493,18561]
atom_expr [18611,18679]
===
match
---
operator: == [28397,28399]
operator: == [28515,28517]
===
match
---
name: dags [8628,8632]
name: dags [8644,8648]
===
match
---
trailer [28271,28287]
trailer [28389,28405]
===
match
---
name: value [29106,29111]
name: value [29224,29229]
===
match
---
string: """Make DAGs with user defined macros and filters using locally defined methods.      For Webserver, we do not include ``user_defined_macros`` & ``user_defined_filters``.      The examples here test:         (1) functions can be successfully displayed on UI;         (2) templates with function macros have been rendered before serialization.     """ [6875,7225]
string: """Make DAGs with user defined macros and filters using locally defined methods.      For Webserver, we do not include ``user_defined_macros`` & ``user_defined_filters``.      The examples here test:         (1) functions can be successfully displayed on UI;         (2) templates with function macros have been rendered before serialization.     """ [6891,7241]
===
match
---
operator: = [9070,9071]
operator: = [9086,9087]
===
match
---
name: collect_dags [12198,12210]
name: collect_dags [12214,12226]
===
match
---
name: task_id [21294,21301]
name: task_id [21412,21419]
===
match
---
name: serialized_dag [23549,23563]
name: serialized_dag [23667,23681]
===
match
---
operator: { [4113,4114]
operator: { [4129,4130]
===
match
---
name: __init__ [29059,29067]
name: __init__ [29177,29185]
===
match
---
string: 'index' [27777,27784]
string: 'index' [27895,27902]
===
match
---
operator: , [5254,5255]
operator: , [5270,5271]
===
match
---
atom_expr [37747,37777]
atom_expr [37865,37895]
===
match
---
string: 'test_dag_serialization.py' [10264,10291]
string: 'test_dag_serialization.py' [10280,10307]
===
match
---
argument [44818,44834]
argument [44936,44952]
===
match
---
string: 'doc_yaml' [34682,34692]
string: 'doc_yaml' [34800,34810]
===
match
---
parameters [39576,39608]
parameters [39694,39726]
===
match
---
atom [43034,43268]
atom [43152,43386]
===
match
---
atom_expr [15350,15362]
atom_expr [15366,15378]
===
match
---
comparison [28572,28654]
comparison [28690,28772]
===
match
---
expr_stmt [18398,18484]
expr_stmt [18516,18602]
===
match
---
operator: , [29574,29575]
operator: , [29692,29693]
===
match
---
argument [1772,1813]
argument [1788,1829]
===
match
---
name: TaskInstance [1318,1330]
name: TaskInstance [1334,1346]
===
match
---
trailer [37716,37727]
trailer [37834,37845]
===
match
---
trailer [44688,44693]
trailer [44806,44811]
===
match
---
parameters [24901,24907]
parameters [25019,25025]
===
match
---
name: expected [20827,20835]
name: expected [20945,20953]
===
match
---
argument [6133,6143]
argument [6149,6159]
===
match
---
trailer [11558,11565]
trailer [11574,11581]
===
match
---
name: queue [11661,11666]
name: queue [11677,11682]
===
match
---
dictorsetmaker [2034,5602]
dictorsetmaker [2050,5618]
===
match
---
name: SerializedDAG [42416,42429]
name: SerializedDAG [42534,42547]
===
match
---
string: 'tests.test_utils.mock_operators.CustomBaseIndexOpLink' [27719,27774]
string: 'tests.test_utils.mock_operators.CustomBaseIndexOpLink' [27837,27892]
===
match
---
number: 2019 [17827,17831]
number: 2019 [17945,17949]
===
match
---
expr_stmt [12805,13070]
expr_stmt [12821,13086]
===
match
---
number: 2019 [23241,23245]
number: 2019 [23359,23363]
===
match
---
expr_stmt [11862,11905]
expr_stmt [11878,11921]
===
match
---
name: from_json [37454,37463]
name: from_json [37572,37581]
===
match
---
name: serialized_dag [41179,41193]
name: serialized_dag [41297,41311]
===
match
---
dictorsetmaker [29964,30001]
dictorsetmaker [30082,30119]
===
match
---
operator: { [9742,9743]
operator: { [9758,9759]
===
match
---
operator: , [22204,22205]
operator: , [22322,22323]
===
match
---
name: DAG [31964,31967]
name: DAG [32082,32085]
===
match
---
param [17438,17442]
param [17556,17560]
===
match
---
arglist [16675,16721]
arglist [16793,16839]
===
match
---
string: "_is_dummy" [3451,3462]
string: "_is_dummy" [3467,3478]
===
match
---
for_stmt [8370,8508]
for_stmt [8386,8524]
===
match
---
trailer [8651,8661]
trailer [8667,8677]
===
match
---
suite [33546,33639]
suite [33664,33757]
===
match
---
name: getattr [23631,23638]
name: getattr [23749,23756]
===
match
---
trailer [22161,22238]
trailer [22279,22356]
===
match
---
string: '/' [10252,10255]
string: '/' [10268,10271]
===
match
---
atom [20478,20532]
atom [20596,20650]
===
match
---
atom [2605,2689]
atom [2621,2705]
===
match
---
string: "test_role" [5354,5365]
string: "test_role" [5370,5381]
===
match
---
trailer [17712,17717]
trailer [17830,17835]
===
match
---
name: BashOperator [7696,7708]
name: BashOperator [7712,7724]
===
match
---
string: "dag" [23491,23496]
string: "dag" [23609,23614]
===
match
---
operator: , [18460,18461]
operator: , [18578,18579]
===
match
---
name: node [37859,37863]
name: node [37977,37981]
===
match
---
trailer [11924,11949]
trailer [11940,11965]
===
match
---
name: SerializedBaseOperator [14295,14317]
name: SerializedBaseOperator [14311,14333]
===
match
---
fstring_expr [13228,13235]
fstring_expr [13244,13251]
===
match
---
name: template_fields [14983,14998]
name: template_fields [14999,15014]
===
match
---
decorator [39435,39547]
decorator [39553,39665]
===
match
---
name: serialized_obj [44409,44423]
name: serialized_obj [44527,44541]
===
match
---
operator: = [19986,19987]
operator: = [20104,20105]
===
match
---
string: 'simple_task' [23345,23358]
string: 'simple_task' [23463,23476]
===
match
---
argument [6592,6630]
argument [6608,6646]
===
match
---
name: subdag [15836,15842]
name: subdag [15852,15858]
===
match
---
name: hooks [1181,1186]
name: hooks [1197,1202]
===
match
---
simple_stmt [39117,39157]
simple_stmt [39235,39275]
===
match
---
name: test_no_new_fields_added_to_base_operator [33918,33959]
name: test_no_new_fields_added_to_base_operator [34036,34077]
===
match
---
operator: } [29960,29961]
operator: } [30078,30079]
===
match
---
operator: = [6087,6088]
operator: = [6103,6104]
===
match
---
dictorsetmaker [43308,43643]
dictorsetmaker [43426,43761]
===
match
---
operator: = [6604,6605]
operator: = [6620,6621]
===
match
---
operator: , [2450,2451]
operator: , [2466,2467]
===
match
---
string: "dag" [10718,10723]
string: "dag" [10734,10739]
===
match
---
argument [17483,17535]
argument [17601,17653]
===
match
---
name: TaskStateLink [25531,25544]
name: TaskStateLink [25649,25662]
===
match
---
testlist_comp [43882,43925]
testlist_comp [44000,44043]
===
match
---
name: volume_mounts [1901,1914]
name: volume_mounts [1917,1930]
===
match
---
atom_expr [36964,36985]
atom_expr [37082,37103]
===
match
---
name: task_id [13830,13837]
name: task_id [13846,13853]
===
match
---
operator: , [12276,12277]
operator: , [12292,12293]
===
match
---
name: importlib [852,861]
name: importlib [852,861]
===
match
---
operator: , [42753,42754]
operator: , [42871,42872]
===
match
---
expr_stmt [33606,33638]
expr_stmt [33724,33756]
===
match
---
simple_stmt [7905,7934]
simple_stmt [7921,7950]
===
match
---
atom_expr [17234,17273]
atom_expr [17352,17391]
===
match
---
name: parameterized [1132,1145]
name: parameterized [1148,1161]
===
match
---
operator: , [3638,3639]
operator: , [3654,3655]
===
match
---
trailer [21593,21603]
trailer [21711,21721]
===
match
---
name: mode [39827,39831]
name: mode [39945,39949]
===
match
---
operator: >> [39005,39007]
operator: >> [39123,39125]
===
match
---
or_test [16868,16924]
or_test [16986,17042]
===
match
---
operator: } [13069,13070]
operator: } [13085,13086]
===
match
---
name: FR [1065,1067]
name: FR [1081,1083]
===
match
---
name: self [33510,33514]
name: self [33628,33632]
===
match
---
arglist [42085,42148]
arglist [42203,42266]
===
match
---
operator: } [30059,30060]
operator: } [30177,30178]
===
match
---
atom_expr [7407,7691]
atom_expr [7423,7707]
===
match
---
name: self [29319,29323]
name: self [29437,29441]
===
match
---
name: simple_task [28260,28271]
name: simple_task [28378,28389]
===
match
---
name: serialize_subprocess [11486,11506]
name: serialize_subprocess [11502,11522]
===
match
---
name: task_start_date [16909,16924]
name: task_start_date [17027,17042]
===
match
---
assert_stmt [22399,22455]
assert_stmt [22517,22573]
===
match
---
arglist [24478,24506]
arglist [24596,24624]
===
match
---
operator: , [2284,2285]
operator: , [2300,2301]
===
match
---
operator: , [43743,43744]
operator: , [43861,43862]
===
match
---
expr_stmt [5606,5723]
expr_stmt [5622,5739]
===
match
---
string: "__type" [20347,20355]
string: "__type" [20465,20473]
===
match
---
dictorsetmaker [30234,30263]
dictorsetmaker [30352,30381]
===
match
---
trailer [8078,8105]
trailer [8094,8121]
===
match
---
atom [20972,21069]
atom [21090,21187]
===
match
---
simple_stmt [38105,38194]
simple_stmt [38223,38312]
===
match
---
argument [18119,18138]
argument [18237,18256]
===
match
---
name: dag_dict [10709,10717]
name: dag_dict [10725,10733]
===
match
---
string: "__var" [5426,5433]
string: "__var" [5442,5449]
===
match
---
operator: { [29858,29859]
operator: { [29976,29977]
===
match
---
name: timezone [13710,13718]
name: timezone [13726,13734]
===
match
---
atom [40208,40254]
atom [40326,40372]
===
match
---
simple_stmt [24766,24825]
simple_stmt [24884,24943]
===
match
---
decorated [17723,19127]
decorated [17841,19245]
===
match
---
string: "dag" [27572,27577]
string: "dag" [27690,27695]
===
match
---
atom_expr [11921,11949]
atom_expr [11937,11965]
===
match
---
trailer [1760,1766]
trailer [1776,1782]
===
match
---
trailer [37629,37634]
trailer [37747,37752]
===
match
---
name: pattern [8374,8381]
name: pattern [8390,8397]
===
match
---
number: 1 [20405,20406]
number: 1 [20523,20524]
===
match
---
string: "dag" [21474,21479]
string: "dag" [21592,21597]
===
match
---
name: serialized_op [40045,40058]
name: serialized_op [40163,40176]
===
match
---
trailer [17900,17933]
trailer [18018,18051]
===
match
---
arglist [44287,44307]
arglist [44405,44425]
===
match
---
trailer [26899,26962]
trailer [27017,27080]
===
match
---
name: execute [25565,25572]
name: execute [25683,25690]
===
match
---
operator: } [9743,9744]
operator: } [9759,9760]
===
match
---
name: serialized_dag [39388,39402]
name: serialized_dag [39506,39520]
===
match
---
name: dag [26824,26827]
name: dag [26942,26945]
===
match
---
operator: == [13552,13554]
operator: == [13568,13570]
===
match
---
trailer [8792,8804]
trailer [8808,8820]
===
match
---
name: relativedelta [1044,1057]
name: relativedelta [1060,1073]
===
match
---
trailer [40949,40961]
trailer [41067,41079]
===
match
---
parameters [21989,22014]
parameters [22107,22132]
===
match
---
operator: , [3925,3926]
operator: , [3941,3942]
===
match
---
operator: = [38954,38955]
operator: = [39072,39073]
===
match
---
name: op [39793,39795]
name: op [39911,39913]
===
match
---
number: 8 [18113,18114]
number: 8 [18231,18232]
===
match
---
expr_stmt [22110,22140]
expr_stmt [22228,22258]
===
match
---
atom_expr [15454,15468]
atom_expr [15470,15484]
===
match
---
atom_expr [40242,40253]
atom_expr [40360,40371]
===
match
---
name: following_schedule [7304,7322]
name: following_schedule [7320,7338]
===
match
---
trailer [22656,22663]
trailer [22774,22781]
===
match
---
name: dags [11957,11961]
name: dags [11973,11977]
===
match
---
name: os [5700,5702]
name: os [5716,5718]
===
match
---
operator: } [30263,30264]
operator: } [30381,30382]
===
match
---
trailer [38248,38267]
trailer [38366,38385]
===
match
---
trailer [33778,33782]
trailer [33896,33900]
===
match
---
operator: } [30000,30001]
operator: } [30118,30119]
===
match
---
trailer [5857,5862]
trailer [5873,5878]
===
match
---
shift_expr [37279,37296]
shift_expr [37397,37414]
===
match
---
name: val [22201,22204]
name: val [22319,22322]
===
match
---
name: dag_id [5973,5979]
name: dag_id [5989,5995]
===
match
---
trailer [27863,27888]
trailer [27981,28006]
===
match
---
string: 'echo "{{ next_execution_date(dag, execution_date) }}"' [7755,7810]
string: 'echo "{{ next_execution_date(dag, execution_date) }}"' [7771,7826]
===
match
---
operator: >> [37317,37319]
operator: >> [37435,37437]
===
match
---
comparison [33873,33908]
comparison [33991,34026]
===
match
---
trailer [9035,9037]
trailer [9051,9053]
===
match
---
name: dag [16771,16774]
name: dag [16889,16892]
===
match
---
operator: { [13611,13612]
operator: { [13627,13628]
===
match
---
operator: = [11512,11513]
operator: = [11528,11529]
===
match
---
atom_expr [42278,42299]
atom_expr [42396,42417]
===
match
---
arglist [16038,16069]
arglist [16054,16085]
===
match
---
atom_expr [27860,27888]
atom_expr [27978,28006]
===
match
---
atom [34927,34929]
atom [35045,35047]
===
match
---
operator: = [37205,37206]
operator: = [37323,37324]
===
match
---
name: set [33095,33098]
name: set [33213,33216]
===
match
---
name: items [13323,13328]
name: items [13339,13344]
===
match
---
funcdef [5865,6827]
funcdef [5881,6843]
===
match
---
operator: = [20332,20333]
operator: = [20450,20451]
===
match
---
argument [6002,6236]
argument [6018,6252]
===
match
---
operator: = [25964,25965]
operator: = [26082,26083]
===
match
---
param [22001,22013]
param [22119,22131]
===
match
---
name: simple_task [24702,24713]
name: simple_task [24820,24831]
===
match
---
string: "#000" [3572,3578]
string: "#000" [3588,3594]
===
match
---
comparison [26184,26217]
comparison [26302,26335]
===
match
---
name: upstream_task_ids [15061,15078]
name: upstream_task_ids [15077,15094]
===
match
---
string: "bar" [29932,29937]
string: "bar" [30050,30055]
===
match
---
operator: , [43268,43269]
operator: , [43386,43387]
===
match
---
trailer [17502,17535]
trailer [17620,17653]
===
match
---
name: timezone [16180,16188]
name: timezone [16196,16204]
===
match
---
atom [20986,20996]
atom [21104,21114]
===
match
---
atom_expr [40061,40110]
atom_expr [40179,40228]
===
match
---
operator: , [2486,2487]
operator: , [2502,2503]
===
match
---
number: 2019 [16426,16430]
number: 2019 [16442,16446]
===
match
---
operator: == [15000,15002]
operator: == [15016,15018]
===
match
---
param [12176,12180]
param [12192,12196]
===
match
---
operator: , [956,957]
operator: , [956,957]
===
match
---
atom_expr [19340,19357]
atom_expr [19458,19475]
===
match
---
operator: , [1633,1634]
operator: , [1649,1650]
===
match
---
comparison [37702,37777]
comparison [37820,37895]
===
match
---
atom_expr [12520,12571]
atom_expr [12536,12587]
===
match
---
parameters [7262,7283]
parameters [7278,7299]
===
match
---
string: 'depends_on_past' [34498,34515]
string: 'depends_on_past' [34616,34633]
===
match
---
with_stmt [17453,17718]
with_stmt [17571,17836]
===
match
---
string: "_outlets" [3487,3497]
string: "_outlets" [3503,3513]
===
match
---
param [7263,7267]
param [7279,7283]
===
match
---
string: "sla" [3346,3351]
string: "sla" [3362,3367]
===
match
---
trailer [34206,34215]
trailer [34324,34333]
===
match
---
operator: { [29248,29249]
operator: { [29366,29367]
===
match
---
operator: = [1938,1939]
operator: = [1954,1955]
===
match
---
dictorsetmaker [30032,30059]
dictorsetmaker [30150,30177]
===
match
---
simple_stmt [1030,1083]
simple_stmt [1046,1099]
===
match
---
name: expand [20956,20962]
name: expand [21074,21080]
===
match
---
suite [9597,10075]
suite [9613,10091]
===
match
---
trailer [15284,15327]
trailer [15300,15343]
===
match
---
strings [9164,9460]
strings [9180,9476]
===
match
---
dictorsetmaker [43381,43410]
dictorsetmaker [43499,43528]
===
match
---
operator: , [945,946]
operator: , [945,946]
===
match
---
testlist_comp [17768,18275]
testlist_comp [17886,18393]
===
match
---
import_as_names [1611,1648]
import_as_names [1627,1664]
===
match
---
name: kwargs [33582,33588]
name: kwargs [33700,33706]
===
match
---
decorated [21820,22664]
decorated [21938,22782]
===
match
---
trailer [19349,19357]
trailer [19467,19475]
===
match
---
name: glob [984,988]
name: glob [984,988]
===
match
---
atom [29810,29848]
atom [29928,29966]
===
match
---
operator: = [1755,1756]
operator: = [1771,1772]
===
match
---
name: fromlist [44625,44633]
name: fromlist [44743,44751]
===
match
---
atom [30063,30102]
atom [30181,30220]
===
match
---
return_stmt [6800,6826]
return_stmt [6816,6842]
===
match
---
trailer [9818,9821]
trailer [9834,9837]
===
match
---
trailer [11093,11103]
trailer [11109,11119]
===
match
---
operator: , [18456,18457]
operator: , [18574,18575]
===
match
---
name: queue [8885,8890]
name: queue [8901,8906]
===
match
---
trailer [21398,21406]
trailer [21516,21524]
===
match
---
operator: , [22183,22184]
operator: , [22301,22302]
===
match
---
argument [7601,7661]
argument [7617,7677]
===
match
---
suite [5761,5863]
suite [5777,5879]
===
match
---
suite [13108,13252]
suite [13124,13268]
===
match
---
name: timedelta [19359,19368]
name: timedelta [19477,19486]
===
match
---
param [25309,25318]
param [25427,25436]
===
match
---
operator: } [45847,45848]
operator: } [45965,45966]
===
match
---
string: 'fileloc' [10316,10325]
string: 'fileloc' [10332,10341]
===
match
---
name: __eq__ [29347,29353]
name: __eq__ [29465,29471]
===
match
---
operator: = [7405,7406]
operator: = [7421,7422]
===
match
---
atom [43438,43583]
atom [43556,43701]
===
match
---
operator: , [44004,44005]
operator: , [44122,44123]
===
match
---
trailer [19944,19960]
trailer [20062,20078]
===
match
---
operator: } [19337,19338]
operator: } [19455,19456]
===
match
---
operator: , [13299,13300]
operator: , [13315,13316]
===
match
---
trailer [45928,45938]
trailer [46046,46056]
===
match
---
operator: = [16445,16446]
operator: = [16461,16462]
===
match
---
funcdef [19399,20172]
funcdef [19517,20290]
===
match
---
number: 2019 [40950,40954]
number: 2019 [41068,41072]
===
match
---
argument [16696,16721]
argument [16814,16839]
===
match
---
name: task_id [25713,25720]
name: task_id [25831,25838]
===
match
---
string: 'simple_dag' [17469,17481]
string: 'simple_dag' [17587,17599]
===
match
---
name: BashOperator [1437,1449]
name: BashOperator [1453,1465]
===
match
---
expr_stmt [26972,27015]
expr_stmt [27090,27133]
===
match
---
name: sorted [10881,10887]
name: sorted [10897,10903]
===
match
---
shift_expr [37309,37325]
shift_expr [37427,37443]
===
match
---
atom [25530,25547]
atom [25648,25665]
===
match
---
string: "airflow.serialization.serialized_objects" [25812,25854]
string: "airflow.serialization.serialized_objects" [25930,25972]
===
match
---
atom_expr [38905,38935]
atom_expr [39023,39053]
===
match
---
name: kwargs [33538,33544]
name: kwargs [33656,33662]
===
match
---
import_from [1030,1082]
import_from [1046,1098]
===
match
---
name: serialized_schedule_interval [19457,19485]
name: serialized_schedule_interval [19575,19603]
===
match
---
name: test_dag_params_roundtrip [21084,21109]
name: test_dag_params_roundtrip [21202,21227]
===
match
---
number: 1564617600.0 [2474,2486]
number: 1564617600.0 [2490,2502]
===
match
---
name: datetime [17951,17959]
name: datetime [18069,18077]
===
match
---
name: dag [21230,21233]
name: dag [21348,21351]
===
match
---
string: "simple_dag" [3020,3032]
string: "simple_dag" [3036,3048]
===
match
---
expr_stmt [18571,18614]
expr_stmt [18689,18732]
===
match
---
name: timezone [16446,16454]
name: timezone [16462,16470]
===
match
---
operator: , [43834,43835]
operator: , [43952,43953]
===
match
---
string: "test3" [43826,43833]
string: "test3" [43944,43951]
===
match
---
with_stmt [32044,32125]
with_stmt [32162,32243]
===
match
---
name: V1Pod [1761,1766]
name: V1Pod [1777,1782]
===
match
---
name: SerializedDAG [39082,39095]
name: SerializedDAG [39200,39213]
===
match
---
name: serialized_task [14083,14098]
name: serialized_task [14099,14114]
===
match
---
name: return_value [9095,9107]
name: return_value [9111,9123]
===
match
---
string: "#fff" [4860,4866]
string: "#fff" [4876,4882]
===
match
---
dictorsetmaker [6356,6412]
dictorsetmaker [6372,6428]
===
match
---
arglist [41988,42062]
arglist [42106,42180]
===
match
---
with_item [37072,37103]
with_item [37190,37221]
===
match
---
name: SerializedDAG [25898,25911]
name: SerializedDAG [26016,26029]
===
match
---
atom [29765,29794]
atom [29883,29912]
===
match
---
operator: = [32107,32108]
operator: = [32225,32226]
===
match
---
argument [1934,1947]
argument [1950,1963]
===
match
---
string: "### Task Tutorial Documentation" [4346,4379]
string: "### Task Tutorial Documentation" [4362,4395]
===
match
---
name: isinstance [14334,14344]
name: isinstance [14350,14360]
===
match
---
name: params [22194,22200]
name: params [22312,22318]
===
match
---
name: self [32442,32446]
name: self [32560,32564]
===
match
---
number: 1 [16047,16048]
number: 1 [16063,16064]
===
match
---
suite [25885,26218]
suite [26003,26336]
===
match
---
argument [22120,22139]
argument [22238,22257]
===
match
---
operator: = [9795,9796]
operator: = [9811,9812]
===
match
---
operator: , [27789,27790]
operator: , [27907,27908]
===
match
---
operator: , [42831,42832]
operator: , [42949,42950]
===
match
---
with_item [25796,25884]
with_item [25914,26002]
===
match
---
name: BaseSensorOperator [39697,39715]
name: BaseSensorOperator [39815,39833]
===
match
---
operator: = [11737,11738]
operator: = [11753,11754]
===
match
---
name: sorted [10736,10742]
name: sorted [10752,10758]
===
match
---
trailer [44693,44696]
trailer [44811,44814]
===
match
---
atom_expr [44218,44264]
atom_expr [44336,44382]
===
match
---
trailer [29227,29237]
trailer [29345,29355]
===
match
---
simple_stmt [10813,10985]
simple_stmt [10829,11001]
===
match
---
operator: , [1296,1297]
operator: , [1312,1313]
===
match
---
testlist_comp [43100,43228]
testlist_comp [43218,43346]
===
match
---
operator: , [21353,21354]
operator: , [21471,21472]
===
match
---
string: "{{ task.task_id }}" [30167,30187]
string: "{{ task.task_id }}" [30285,30305]
===
match
---
name: dag_id [13616,13622]
name: dag_id [13632,13638]
===
match
---
name: name [1798,1802]
name: name [1814,1818]
===
match
---
atom_expr [6487,6524]
atom_expr [6503,6540]
===
match
---
name: get_link [25294,25302]
name: get_link [25412,25420]
===
match
---
exprlist [8613,8624]
exprlist [8629,8640]
===
match
---
operator: = [22200,22201]
operator: = [22318,22319]
===
match
---
expr_stmt [28050,28111]
expr_stmt [28168,28229]
===
match
---
name: test_task_params_roundtrip [21963,21989]
name: test_task_params_roundtrip [22081,22107]
===
match
---
string: 'task_2' [42620,42628]
string: 'task_2' [42738,42746]
===
match
---
string: "custom_task" [4437,4450]
string: "custom_task" [4453,4466]
===
match
---
not_test [16868,16887]
not_test [16986,17005]
===
match
---
trailer [42380,42387]
trailer [42498,42505]
===
match
---
atom [6015,6236]
atom [6031,6252]
===
match
---
name: set [11921,11924]
name: set [11937,11940]
===
match
---
trailer [39199,39227]
trailer [39317,39345]
===
match
---
name: SerializedDAG [20768,20781]
name: SerializedDAG [20886,20899]
===
match
---
number: 1 [6275,6276]
number: 1 [6291,6292]
===
match
---
name: test_date [28781,28790]
name: test_date [28899,28908]
===
match
---
operator: , [20273,20274]
operator: , [20391,20392]
===
match
---
atom_expr [18010,18051]
atom_expr [18128,18169]
===
match
---
trailer [18254,18258]
trailer [18372,18376]
===
match
---
operator: , [30456,30457]
operator: , [30574,30575]
===
match
---
operator: { [45461,45462]
operator: { [45579,45580]
===
match
---
name: DummySensor [39798,39809]
name: DummySensor [39916,39927]
===
match
---
atom [20383,20407]
atom [20501,20525]
===
match
---
name: expected_val [21121,21133]
name: expected_val [21239,21251]
===
match
---
string: "__version" [2034,2045]
string: "__version" [2050,2061]
===
match
---
operator: { [5336,5337]
operator: { [5352,5353]
===
match
---
string: '"project_id": "mock", ' [9188,9212]
string: '"project_id": "mock", ' [9204,9228]
===
match
---
name: SerializedDAG [46014,46027]
name: SerializedDAG [46132,46145]
===
match
---
name: task_dict [21672,21681]
name: task_dict [21790,21799]
===
match
---
operator: , [40254,40255]
operator: , [40372,40373]
===
match
---
name: object_to_serialized [44071,44091]
name: object_to_serialized [44189,44209]
===
match
---
operator: } [43660,43661]
operator: } [43778,43779]
===
match
---
arglist [17503,17534]
arglist [17621,17652]
===
match
---
string: "foo" [29811,29816]
string: "foo" [29929,29934]
===
match
---
simple_stmt [11914,11970]
simple_stmt [11930,11986]
===
match
---
string: "retry_delay" [4498,4511]
string: "retry_delay" [4514,4527]
===
match
---
string: "retries" [4468,4477]
string: "retries" [4484,4493]
===
match
---
import_from [39618,39669]
import_from [39736,39787]
===
match
---
assert_stmt [40120,40156]
assert_stmt [40238,40274]
===
match
---
string: 'task_2' [42765,42773]
string: 'task_2' [42883,42891]
===
match
---
name: group234 [37288,37296]
name: group234 [37406,37414]
===
match
---
string: "{{ task.task_id }}" [30039,30059]
string: "{{ task.task_id }}" [30157,30177]
===
match
---
atom_expr [32066,32124]
atom_expr [32184,32242]
===
match
---
for_stmt [38443,38506]
for_stmt [38561,38624]
===
match
---
number: 8 [26810,26811]
number: 8 [26928,26929]
===
match
---
operator: == [40135,40137]
operator: == [40253,40255]
===
match
---
param [14069,14074]
param [14085,14090]
===
match
---
operator: , [42676,42677]
operator: , [42794,42795]
===
match
---
name: task_start_date [16872,16887]
name: task_start_date [16990,17005]
===
match
---
arglist [18449,18459]
arglist [18567,18577]
===
match
---
operator: , [39825,39826]
operator: , [39943,39944]
===
match
---
trailer [27070,27079]
trailer [27188,27197]
===
match
---
param [31636,31650]
param [31754,31768]
===
match
---
simple_stmt [7839,7864]
simple_stmt [7855,7880]
===
match
---
name: task [15007,15011]
name: task [15023,15027]
===
match
---
name: datetime [937,945]
name: datetime [937,945]
===
match
---
number: 0 [27701,27702]
number: 0 [27819,27820]
===
match
---
name: resources [15550,15559]
name: resources [15566,15575]
===
match
---
string: "_task_module" [3885,3899]
string: "_task_module" [3901,3915]
===
match
---
name: start_date [21326,21336]
name: start_date [21444,21454]
===
match
---
with_stmt [5955,6827]
with_stmt [5971,6843]
===
match
---
string: 'task_1' [43882,43890]
string: 'task_1' [44000,44008]
===
match
---
number: 0 [23507,23508]
number: 0 [23625,23626]
===
match
---
param [33536,33544]
param [33654,33662]
===
match
---
atom [41394,41448]
atom [41512,41566]
===
match
---
name: fileloc [14016,14023]
name: fileloc [14032,14039]
===
match
---
operator: = [37857,37858]
operator: = [37975,37976]
===
match
---
operator: , [16311,16312]
operator: , [16327,16328]
===
match
---
trailer [10742,10800]
trailer [10758,10816]
===
match
---
name: params [21261,21267]
name: params [21379,21385]
===
match
---
trailer [24187,24199]
trailer [24305,24317]
===
match
---
trailer [6132,6144]
trailer [6148,6160]
===
match
---
operator: } [30265,30266]
operator: } [30383,30384]
===
match
---
dictorsetmaker [24205,24251]
dictorsetmaker [24323,24369]
===
match
---
name: ClassWithCustomAttributes [28887,28912]
name: ClassWithCustomAttributes [29005,29030]
===
match
---
if_stmt [18623,18959]
if_stmt [18741,19077]
===
match
---
operator: } [2438,2439]
operator: } [2454,2455]
===
match
---
operator: , [29550,29551]
operator: , [29668,29669]
===
match
---
operator: , [42106,42107]
operator: , [42224,42225]
===
match
---
trailer [39189,39199]
trailer [39307,39317]
===
match
---
factor [20341,20343]
factor [20459,20461]
===
match
---
name: timezone [17846,17854]
name: timezone [17964,17972]
===
match
---
operator: = [28751,28752]
operator: = [28869,28870]
===
match
---
trailer [38073,38087]
trailer [38191,38205]
===
match
---
number: 300.0 [4513,4518]
number: 300.0 [4529,4534]
===
match
---
trailer [5657,5662]
trailer [5673,5678]
===
match
---
operator: , [21912,21913]
operator: , [22030,22031]
===
match
---
trailer [22119,22140]
trailer [22237,22258]
===
match
---
trailer [8848,8852]
trailer [8864,8868]
===
match
---
atom_expr [12480,12506]
atom_expr [12496,12522]
===
match
---
number: 2019 [18226,18230]
number: 2019 [18344,18348]
===
match
---
testlist_comp [43352,43621]
testlist_comp [43470,43739]
===
match
---
simple_stmt [7696,7835]
simple_stmt [7712,7851]
===
match
---
name: level [44659,44664]
name: level [44777,44782]
===
match
---
trailer [5447,5463]
trailer [5463,5479]
===
match
---
operator: , [39743,39744]
operator: , [39861,39862]
===
match
---
string: "template_fields_renderers" [3656,3683]
string: "template_fields_renderers" [3672,3699]
===
match
---
operator: } [19920,19921]
operator: } [20038,20039]
===
match
---
comparison [13128,13211]
comparison [13144,13227]
===
match
---
name: ti [28120,28122]
name: ti [28238,28240]
===
match
---
operator: { [41395,41396]
operator: { [41513,41514]
===
match
---
for_stmt [29097,29173]
for_stmt [29215,29291]
===
match
---
atom_expr [18588,18614]
atom_expr [18706,18732]
===
match
---
string: "dag_dependencies" [32963,32981]
string: "dag_dependencies" [33081,33099]
===
match
---
operator: , [19266,19267]
operator: , [19384,19385]
===
match
---
atom [19296,19377]
atom [19414,19495]
===
match
---
name: timezone [16057,16065]
name: timezone [16073,16081]
===
match
---
atom_expr [15277,15327]
atom_expr [15293,15343]
===
match
---
name: to_dict [18602,18609]
name: to_dict [18720,18727]
===
match
---
operator: = [39174,39175]
operator: = [39292,39293]
===
match
---
name: spec [45132,45136]
name: spec [45250,45254]
===
match
---
trailer [40083,40104]
trailer [40201,40222]
===
match
---
name: FR [20473,20475]
name: FR [20591,20593]
===
match
---
string: "__type" [5389,5397]
string: "__type" [5405,5413]
===
match
---
operator: = [22126,22127]
operator: = [22244,22245]
===
match
---
atom [43523,43556]
atom [43641,43674]
===
match
---
name: imported_airflow [45442,45458]
name: imported_airflow [45560,45576]
===
match
---
name: __str__ [29186,29193]
name: __str__ [29304,29311]
===
match
---
number: 600.0 [2354,2359]
number: 600.0 [2370,2375]
===
match
---
operator: , [26952,26953]
operator: , [27070,27071]
===
match
---
operator: , [30266,30267]
operator: , [30384,30385]
===
match
---
name: expected_task_end_date [18365,18387]
name: expected_task_end_date [18483,18505]
===
match
---
operator: = [26793,26794]
operator: = [26911,26912]
===
match
---
name: child [38447,38452]
name: child [38565,38570]
===
match
---
atom_expr [13447,13474]
atom_expr [13463,13490]
===
match
---
testlist_comp [40276,40285]
testlist_comp [40394,40403]
===
match
---
atom_expr [18126,18138]
atom_expr [18244,18256]
===
match
---
number: 0 [22453,22454]
number: 0 [22571,22572]
===
match
---
dictorsetmaker [43158,43189]
dictorsetmaker [43276,43307]
===
match
---
operator: , [24739,24740]
operator: , [24857,24858]
===
match
---
name: fields [34184,34190]
name: fields [34302,34308]
===
match
---
atom [4113,4277]
atom [4129,4293]
===
match
---
operator: } [24251,24252]
operator: } [24369,24370]
===
match
---
name: dag [42112,42115]
name: dag [42230,42233]
===
match
---
name: dag [18610,18613]
name: dag [18728,18731]
===
match
---
arglist [24280,24322]
arglist [24398,24440]
===
match
---
name: make_simple_dag [7964,7979]
name: make_simple_dag [7980,7995]
===
match
---
assert_stmt [14897,14947]
assert_stmt [14913,14963]
===
match
---
trailer [45522,45537]
trailer [45640,45655]
===
match
---
name: serialized_dag [37702,37716]
name: serialized_dag [37820,37834]
===
match
---
simple_stmt [44784,44884]
simple_stmt [44902,45002]
===
match
---
operator: , [1383,1384]
operator: , [1399,1400]
===
match
---
name: Queue [11432,11437]
name: Queue [11448,11453]
===
match
---
suite [16925,17136]
suite [17043,17254]
===
match
---
operator: = [22188,22189]
operator: = [22306,22307]
===
match
---
trailer [44811,44883]
trailer [44929,45001]
===
match
---
simple_stmt [867,890]
simple_stmt [867,890]
===
match
---
operator: , [18453,18454]
operator: , [18571,18572]
===
match
---
simple_stmt [11818,11853]
simple_stmt [11834,11869]
===
match
---
string: "__var" [10848,10855]
string: "__var" [10864,10871]
===
match
---
string: '{' [9164,9167]
string: '{' [9180,9183]
===
match
---
name: deserialized_dag [32186,32202]
name: deserialized_dag [32304,32320]
===
match
---
string: 'test_dag_on_failure_callback_roundtrip' [41995,42035]
string: 'test_dag_on_failure_callback_roundtrip' [42113,42153]
===
match
---
parameters [44473,44475]
parameters [44591,44593]
===
match
---
comp_op [21523,21529]
comp_op [21641,21647]
===
match
---
operator: , [20670,20671]
operator: , [20788,20789]
===
match
---
expr_stmt [8119,8140]
expr_stmt [8135,8156]
===
match
---
name: task_id [13737,13744]
name: task_id [13753,13760]
===
match
---
name: tzinfo [17913,17919]
name: tzinfo [18031,18037]
===
match
---
operator: , [17964,17965]
operator: , [18082,18083]
===
match
---
name: os [5642,5644]
name: os [5658,5660]
===
match
---
string: "tasks" [22361,22368]
string: "tasks" [22479,22486]
===
match
---
dictorsetmaker [20384,20406]
dictorsetmaker [20502,20524]
===
match
---
operator: , [35522,35523]
operator: , [35640,35641]
===
match
---
name: SerializedDAG [37346,37359]
name: SerializedDAG [37464,37477]
===
match
---
operator: = [37234,37235]
operator: = [37352,37353]
===
match
---
assert_stmt [27197,27260]
assert_stmt [27315,27378]
===
match
---
parameters [44064,44109]
parameters [44182,44227]
===
match
---
operator: - [33139,33140]
operator: - [33257,33258]
===
match
---
trailer [11666,11670]
trailer [11682,11686]
===
match
---
simple_stmt [28330,28420]
simple_stmt [28448,28538]
===
match
---
string: "airflow/providers/*/*/example_dags" [12294,12330]
string: "airflow/providers/*/*/example_dags" [12310,12346]
===
match
---
trailer [13135,13158]
trailer [13151,13174]
===
match
---
trailer [36929,36946]
trailer [37047,37064]
===
match
---
dictorsetmaker [43524,43555]
dictorsetmaker [43642,43673]
===
match
---
simple_stmt [21440,21481]
simple_stmt [21558,21599]
===
match
---
string: """Collects DAGs to test.""" [7905,7933]
string: """Collects DAGs to test.""" [7921,7949]
===
match
---
decorator [41349,41491]
decorator [41467,41609]
===
match
---
atom_expr [5960,6470]
atom_expr [5976,6486]
===
match
---
operator: = [40807,40808]
operator: = [40925,40926]
===
match
---
suite [33290,33909]
suite [33408,34027]
===
match
---
name: task_type [15770,15779]
name: task_type [15786,15795]
===
match
---
expr_stmt [1991,5604]
expr_stmt [2007,5620]
===
match
---
trailer [33104,33123]
trailer [33222,33241]
===
match
---
simple_stmt [17075,17136]
simple_stmt [17193,17254]
===
match
---
name: validate_schema [37395,37410]
name: validate_schema [37513,37528]
===
match
---
name: key [29101,29104]
name: key [29219,29222]
===
match
---
atom_expr [21236,21272]
atom_expr [21354,21390]
===
match
---
name: dag [37368,37371]
name: dag [37486,37489]
===
match
---
atom [20208,20681]
atom [20326,20799]
===
match
---
trailer [11946,11948]
trailer [11962,11964]
===
match
---
operator: , [16227,16228]
operator: , [16243,16244]
===
match
---
operator: = [38017,38018]
operator: = [38135,38136]
===
match
---
name: put [8849,8852]
name: put [8865,8868]
===
match
---
operator: , [29848,29849]
operator: , [29966,29967]
===
match
---
argument [18529,18536]
argument [18647,18654]
===
match
---
name: timezone [13689,13697]
name: timezone [13705,13713]
===
match
---
operator: , [21033,21034]
operator: , [21151,21152]
===
match
---
name: SerializedBaseOperator [38226,38248]
name: SerializedBaseOperator [38344,38366]
===
match
---
simple_stmt [34133,34176]
simple_stmt [34251,34294]
===
match
---
dotted_name [1213,1245]
dotted_name [1229,1261]
===
match
---
name: ImportError [44732,44743]
name: ImportError [44850,44861]
===
match
---
trailer [44743,44775]
trailer [44861,44893]
===
match
---
name: serialized_dag [32134,32148]
name: serialized_dag [32252,32266]
===
match
---
atom_expr [38482,38505]
atom_expr [38600,38623]
===
match
---
operator: , [6316,6317]
operator: , [6332,6333]
===
match
---
simple_stmt [7293,7339]
simple_stmt [7309,7355]
===
match
---
expr_stmt [19022,19064]
expr_stmt [19140,19182]
===
match
---
name: dag [22189,22192]
name: dag [22307,22310]
===
match
---
operator: , [3469,3470]
operator: , [3485,3486]
===
match
---
atom [35238,35240]
atom [35356,35358]
===
match
---
suite [20746,20936]
suite [20864,21054]
===
match
---
operator: , [2644,2645]
operator: , [2660,2661]
===
match
---
string: "foo1" [29923,29929]
string: "foo1" [30041,30047]
===
match
---
argument [16050,16069]
argument [16066,16085]
===
match
---
testlist_comp [21865,21938]
testlist_comp [21983,22056]
===
match
---
import_from [989,1014]
import_from [989,1014]
===
match
---
trailer [38383,38389]
trailer [38501,38507]
===
match
---
dotted_name [29501,29521]
dotted_name [29619,29639]
===
match
---
dictorsetmaker [30218,30265]
dictorsetmaker [30336,30383]
===
match
---
expr_stmt [45132,45207]
expr_stmt [45250,45325]
===
match
---
name: bash [1425,1429]
name: bash [1441,1445]
===
match
---
string: "test_edge_info_serialization" [38812,38842]
string: "test_edge_info_serialization" [38930,38960]
===
match
---
arglist [32023,32033]
arglist [32141,32151]
===
match
---
string: "bar" [43125,43130]
string: "bar" [43243,43248]
===
match
---
name: serialized_dag [13555,13569]
name: serialized_dag [13571,13585]
===
match
---
trailer [17854,17858]
trailer [17972,17976]
===
match
---
string: "this" [43532,43538]
string: "this" [43650,43656]
===
match
---
atom_expr [10743,10767]
atom_expr [10759,10783]
===
match
---
param [16613,16629]
param [16731,16747]
===
match
---
operator: = [19373,19374]
operator: = [19491,19492]
===
match
---
simple_stmt [11715,11721]
simple_stmt [11731,11737]
===
match
---
string: "tests.test_utils.mock_operators.CustomOpLink" [4778,4824]
string: "tests.test_utils.mock_operators.CustomOpLink" [4794,4840]
===
match
---
operator: = [16238,16239]
operator: = [16254,16255]
===
match
---
trailer [12493,12501]
trailer [12509,12517]
===
match
---
string: '__type' [45746,45754]
string: '__type' [45864,45872]
===
match
---
operator: , [20533,20534]
operator: , [20651,20652]
===
match
---
suite [15434,15501]
suite [15450,15517]
===
match
---
simple_stmt [45717,45849]
simple_stmt [45835,45967]
===
match
---
operator: , [16283,16284]
operator: , [16299,16300]
===
match
---
expr_stmt [24428,24507]
expr_stmt [24546,24625]
===
match
---
dictorsetmaker [21012,21032]
dictorsetmaker [21130,21150]
===
match
---
operator: , [6414,6415]
operator: , [6430,6431]
===
match
---
simple_stmt [32253,32313]
simple_stmt [32371,32431]
===
match
---
name: task_dict [22576,22585]
name: task_dict [22694,22703]
===
match
---
atom_expr [33182,33214]
atom_expr [33300,33332]
===
match
---
testlist_comp [42890,42928]
testlist_comp [43008,43046]
===
match
---
param [37808,37812]
param [37926,37930]
===
match
---
dotted_name [36664,36687]
dotted_name [36782,36805]
===
match
---
operator: , [34522,34523]
operator: , [34640,34641]
===
match
---
string: "_task_group" [13046,13059]
string: "_task_group" [13062,13075]
===
match
---
suite [25160,25374]
suite [25278,25492]
===
match
---
decorator [20177,20688]
decorator [20295,20806]
===
match
---
atom_expr [21783,21814]
atom_expr [21901,21932]
===
match
---
atom_expr [5465,5492]
atom_expr [5481,5508]
===
match
---
string: '__var' [45781,45788]
string: '__var' [45899,45906]
===
match
---
string: "param_1" [21036,21045]
string: "param_1" [21154,21163]
===
match
---
name: to_dict [16844,16851]
name: to_dict [16962,16969]
===
match
---
comparison [13980,14023]
comparison [13996,14039]
===
match
---
trailer [37367,37372]
trailer [37485,37490]
===
match
---
dictorsetmaker [7360,7395]
dictorsetmaker [7376,7411]
===
match
---
testlist_comp [12242,12331]
testlist_comp [12258,12347]
===
match
---
name: unittest [994,1002]
name: unittest [994,1002]
===
match
---
suite [37916,38430]
suite [38034,38548]
===
match
---
operator: , [1316,1317]
operator: , [1332,1333]
===
match
---
trailer [6079,6090]
trailer [6095,6106]
===
match
---
string: "end_date" [18826,18836]
string: "end_date" [18944,18954]
===
match
---
operator: , [2870,2871]
operator: , [2886,2887]
===
match
---
name: dag [39277,39280]
name: dag [39395,39398]
===
match
---
expr_stmt [44201,44264]
expr_stmt [44319,44382]
===
match
---
atom_expr [13216,13226]
atom_expr [13232,13242]
===
match
---
name: task_start_date [16787,16802]
name: task_start_date [16905,16920]
===
match
---
name: schedule_interval [20044,20061]
name: schedule_interval [20162,20179]
===
match
---
string: "tasks" [18866,18873]
string: "tasks" [18984,18991]
===
match
---
string: "foo" [43389,43394]
string: "foo" [43507,43512]
===
match
---
expr_stmt [32134,32177]
expr_stmt [32252,32295]
===
match
---
atom_expr [21530,21551]
atom_expr [21648,21669]
===
match
---
trailer [5636,5723]
trailer [5652,5739]
===
match
---
testlist_comp [30313,30612]
testlist_comp [30431,30730]
===
match
---
expr_stmt [20845,20899]
expr_stmt [20963,21017]
===
match
---
string: "param_1" [21891,21900]
string: "param_1" [22009,22018]
===
match
---
number: 300 [35470,35473]
number: 300 [35588,35591]
===
match
---
atom_expr [14207,14258]
atom_expr [14223,14274]
===
match
---
operator: , [44623,44624]
operator: , [44741,44742]
===
match
---
string: 'kubernetes' [44700,44712]
string: 'kubernetes' [44818,44830]
===
match
---
operator: , [22192,22193]
operator: , [22310,22311]
===
match
---
operator: , [41542,41543]
operator: , [41660,41661]
===
match
---
string: 'downstream' [35821,35833]
string: 'downstream' [35939,35951]
===
match
---
name: timedelta [6203,6212]
name: timedelta [6219,6228]
===
match
---
operator: , [1899,1900]
operator: , [1915,1916]
===
match
---
fstring_expr [15349,15363]
fstring_expr [15365,15379]
===
match
---
suite [26289,28876]
suite [26407,28994]
===
match
---
name: deserialize_operator [40084,40104]
name: deserialize_operator [40202,40222]
===
match
---
expr_stmt [19559,19921]
expr_stmt [19677,20039]
===
match
---
name: serialized_op [40138,40151]
name: serialized_op [40256,40269]
===
match
---
operator: { [30150,30151]
operator: { [30268,30269]
===
match
---
dictorsetmaker [20613,20668]
dictorsetmaker [20731,20786]
===
match
---
name: subdag [15963,15969]
name: subdag [15979,15985]
===
match
---
atom_expr [26989,27015]
atom_expr [27107,27133]
===
match
---
name: custom_inbuilt_link [28238,28257]
name: custom_inbuilt_link [28356,28375]
===
match
---
arglist [44905,44954]
arglist [45023,45072]
===
match
---
operator: = [20241,20242]
operator: = [20359,20360]
===
match
---
name: deps [40152,40156]
name: deps [40270,40274]
===
match
---
operator: { [15364,15365]
operator: { [15380,15381]
===
match
---
operator: } [4828,4829]
operator: } [4844,4845]
===
match
---
operator: , [5992,5993]
operator: , [6008,6009]
===
match
---
number: 0 [25984,25985]
number: 0 [26102,26103]
===
match
---
testlist_comp [20987,20995]
testlist_comp [21105,21113]
===
match
---
trailer [15249,15273]
trailer [15265,15289]
===
match
---
suite [8725,8901]
suite [8741,8917]
===
match
---
tfpdef [10369,10383]
tfpdef [10385,10399]
===
match
---
and_test [44276,44339]
and_test [44394,44457]
===
match
---
name: expected_serialized [38173,38192]
name: expected_serialized [38291,38310]
===
match
---
atom [42726,42857]
atom [42844,42975]
===
match
---
comparison [34231,35854]
comparison [34349,35972]
===
match
---
operator: = [44604,44605]
operator: = [44722,44723]
===
match
---
name: airflow [1455,1462]
name: airflow [1471,1478]
===
match
---
trailer [12106,12114]
trailer [12122,12130]
===
match
---
name: dag [41011,41014]
name: dag [41129,41132]
===
match
---
atom [43016,43676]
atom [43134,43794]
===
match
---
operator: } [43410,43411]
operator: } [43528,43529]
===
match
---
number: 10 [7392,7394]
number: 10 [7408,7410]
===
match
---
trailer [12089,12129]
trailer [12105,12145]
===
match
---
name: getattr [27204,27211]
name: getattr [27322,27329]
===
match
---
simple_stmt [36659,36709]
simple_stmt [36777,36827]
===
match
---
string: "echo" [26946,26952]
string: "echo" [27064,27070]
===
match
---
suite [41042,41113]
suite [41160,41231]
===
match
---
name: deserialized_simple_task [22632,22656]
name: deserialized_simple_task [22750,22774]
===
match
---
atom_expr [24450,24507]
atom_expr [24568,24625]
===
match
---
atom_expr [23587,23615]
atom_expr [23705,23733]
===
match
---
assert_stmt [26177,26217]
assert_stmt [26295,26335]
===
match
---
number: 0 [18956,18957]
number: 0 [19074,19075]
===
match
---
or_test [15454,15500]
or_test [15470,15516]
===
match
---
trailer [39894,39913]
trailer [40012,40031]
===
match
---
operator: = [20603,20604]
operator: = [20721,20722]
===
match
---
name: expected_schedule_interval [20065,20091]
name: expected_schedule_interval [20183,20209]
===
match
---
name: glob [8420,8424]
name: glob [8436,8440]
===
match
---
operator: { [7516,7517]
operator: { [7532,7533]
===
match
---
operator: , [26930,26931]
operator: , [27048,27049]
===
match
---
operator: , [4394,4395]
operator: , [4410,4411]
===
match
---
operator: { [13637,13638]
operator: { [13653,13654]
===
match
---
operator: = [24265,24266]
operator: = [24383,24384]
===
match
---
atom [30430,30438]
atom [30548,30556]
===
match
---
string: "relativedelta" [20258,20273]
string: "relativedelta" [20376,20391]
===
match
---
trailer [17959,17992]
trailer [18077,18110]
===
match
---
operator: , [2946,2947]
operator: , [2962,2963]
===
match
---
name: dag_end_date [18336,18348]
name: dag_end_date [18454,18466]
===
match
---
simple_stmt [845,867]
simple_stmt [845,867]
===
match
---
string: """         This test verifies that there are no new fields added to BaseOperator. And reminds that         tests should be added for it.         """ [33975,34124]
string: """         This test verifies that there are no new fields added to BaseOperator. And reminds that         tests should be added for it.         """ [34093,34242]
===
match
---
name: importlib [44791,44800]
name: importlib [44909,44918]
===
match
---
string: "days" [20396,20402]
string: "days" [20514,20520]
===
match
---
operator: } [11623,11624]
operator: } [11639,11640]
===
match
---
string: "tasks" [3119,3126]
string: "tasks" [3135,3142]
===
match
---
string: "https://www.google.com" [28824,28848]
string: "https://www.google.com" [28942,28966]
===
match
---
atom_expr [22559,22600]
atom_expr [22677,22718]
===
match
---
argument [7820,7827]
argument [7836,7843]
===
match
---
operator: = [26987,26988]
operator: = [27105,27106]
===
match
---
expr_stmt [23573,23615]
expr_stmt [23691,23733]
===
match
---
operator: , [2542,2543]
operator: , [2558,2559]
===
match
---
operator: = [26840,26841]
operator: = [26958,26959]
===
match
---
number: 2019 [16161,16165]
number: 2019 [16177,16181]
===
match
---
name: datetime [17494,17502]
name: datetime [17612,17620]
===
match
---
simple_stmt [14267,14319]
simple_stmt [14283,14335]
===
match
---
operator: , [14651,14652]
operator: , [14667,14668]
===
match
---
name: DAG [16671,16674]
name: DAG [16789,16792]
===
match
---
dictorsetmaker [8597,8661]
dictorsetmaker [8613,8677]
===
match
---
operator: , [18348,18349]
operator: , [18466,18467]
===
match
---
operator: = [40987,40988]
operator: = [41105,41106]
===
match
---
operator: = [22557,22558]
operator: = [22675,22676]
===
match
---
name: DAG [17458,17461]
name: DAG [17576,17579]
===
match
---
trailer [11966,11968]
trailer [11982,11984]
===
match
---
atom_expr [12116,12128]
atom_expr [12132,12144]
===
match
---
testlist_comp [2620,2643]
testlist_comp [2636,2659]
===
match
---
simple_stmt [20908,20936]
simple_stmt [21026,21054]
===
match
---
funcdef [21080,21815]
funcdef [21198,21933]
===
match
---
name: RuntimeError [45877,45889]
name: RuntimeError [45995,46007]
===
match
---
operator: , [34581,34582]
operator: , [34699,34700]
===
match
---
name: resources [15459,15468]
name: resources [15475,15484]
===
match
---
simple_stmt [5892,5951]
simple_stmt [5908,5967]
===
match
---
name: Label [38788,38793]
name: Label [38906,38911]
===
match
---
operator: { [4408,4409]
operator: { [4424,4425]
===
match
---
funcdef [26223,28876]
funcdef [26341,28994]
===
match
---
assert_stmt [21760,21814]
assert_stmt [21878,21932]
===
match
---
name: dag [26927,26930]
name: dag [27045,27048]
===
match
---
name: collect_dags [8780,8792]
name: collect_dags [8796,8808]
===
match
---
operator: { [2061,2062]
operator: { [2077,2078]
===
match
---
assert_stmt [14327,14364]
assert_stmt [14343,14380]
===
match
---
string: "value" [43396,43403]
string: "value" [43514,43521]
===
match
---
operator: , [2716,2717]
operator: , [2732,2733]
===
match
---
argument [30764,30789]
argument [30882,30907]
===
match
---
atom_expr [23322,23389]
atom_expr [23440,23507]
===
match
---
number: 0 [35467,35468]
number: 0 [35585,35586]
===
match
---
string: "echo" [27245,27251]
string: "echo" [27363,27369]
===
match
---
name: __import__ [44801,44811]
name: __import__ [44919,44929]
===
match
---
testlist_comp [41395,41447]
testlist_comp [41513,41565]
===
match
---
name: Connection [1298,1308]
name: Connection [1314,1324]
===
match
---
dictorsetmaker [4778,4828]
dictorsetmaker [4794,4844]
===
match
---
name: serialized [19961,19971]
name: serialized [20079,20089]
===
match
---
name: SerializedBaseOperator [1611,1633]
name: SerializedBaseOperator [1627,1649]
===
match
---
arglist [18166,18198]
arglist [18284,18316]
===
match
---
trailer [32696,32703]
trailer [32814,32821]
===
match
---
atom_expr [39008,39027]
atom_expr [39126,39145]
===
match
---
trailer [37770,37775]
trailer [37888,37893]
===
match
---
if_stmt [8065,8191]
if_stmt [8081,8207]
===
match
---
name: minutes [6080,6087]
name: minutes [6096,6103]
===
match
---
name: serialized_obj [44201,44215]
name: serialized_obj [44319,44333]
===
match
---
file_input [788,46069]
file_input [788,46187]
===
match
---
simple_stmt [32066,32125]
simple_stmt [32184,32243]
===
match
---
atom_expr [24702,24757]
atom_expr [24820,24875]
===
match
---
trailer [5627,5636]
trailer [5643,5652]
===
match
---
expr_stmt [33002,33074]
expr_stmt [33120,33192]
===
match
---
string: "has_on_success_callback" [32885,32910]
string: "has_on_success_callback" [33003,33028]
===
match
---
operator: , [42773,42774]
operator: , [42891,42892]
===
match
---
name: test_deserialization_schedule_interval [19403,19441]
name: test_deserialization_schedule_interval [19521,19559]
===
match
---
operator: , [8619,8620]
operator: , [8635,8636]
===
match
---
simple_stmt [17691,17718]
simple_stmt [17809,17836]
===
match
---
operator: - [20341,20342]
operator: - [20459,20460]
===
match
---
param [16591,16596]
param [16709,16714]
===
match
---
name: test_date [26866,26875]
name: test_date [26984,26993]
===
match
---
name: unittest [907,915]
name: unittest [907,915]
===
match
---
name: serialize_dag [39352,39365]
name: serialize_dag [39470,39483]
===
match
---
argument [18429,18460]
argument [18547,18578]
===
match
---
name: start_date [26855,26865]
name: start_date [26973,26983]
===
match
---
operator: } [6825,6826]
operator: } [6841,6842]
===
match
---
decorator [42536,44022]
decorator [42654,44140]
===
match
---
assert_stmt [20100,20171]
assert_stmt [20218,20289]
===
match
---
operator: } [7862,7863]
operator: } [7878,7879]
===
match
---
name: module [45904,45910]
name: module [46022,46028]
===
match
---
expr_stmt [17282,17324]
expr_stmt [17400,17442]
===
match
---
atom_expr [11554,11565]
atom_expr [11570,11581]
===
match
---
name: dag_dict [10743,10751]
name: dag_dict [10759,10767]
===
match
---
simple_stmt [9046,9503]
simple_stmt [9062,9519]
===
match
---
atom [9142,9478]
atom [9158,9494]
===
match
---
name: datetime [23232,23240]
name: datetime [23350,23358]
===
match
---
string: 'do_xcom_push' [34536,34550]
string: 'do_xcom_push' [34654,34668]
===
match
---
simple_stmt [9979,10075]
simple_stmt [9995,10091]
===
match
---
atom [5435,5493]
atom [5451,5509]
===
match
---
trailer [14982,14998]
trailer [14998,15014]
===
match
---
name: self [39739,39743]
name: self [39857,39861]
===
match
---
atom_expr [23631,23667]
atom_expr [23749,23785]
===
match
---
operator: , [2999,3000]
operator: , [3015,3016]
===
match
---
import_from [1331,1401]
import_from [1347,1417]
===
match
---
name: dag_id [40801,40807]
name: dag_id [40919,40925]
===
match
---
param [44625,44637]
param [44743,44755]
===
match
---
simple_stmt [39071,39109]
simple_stmt [39189,39227]
===
match
---
simple_stmt [6875,7226]
simple_stmt [6891,7242]
===
match
---
name: test_serialized_objects_are_sorted [44030,44064]
name: test_serialized_objects_are_sorted [44148,44182]
===
match
---
string: "foo" [29735,29740]
string: "foo" [29853,29858]
===
match
---
simple_stmt [25702,25729]
simple_stmt [25820,25847]
===
match
---
name: nested1 [30705,30712]
name: nested1 [30823,30830]
===
match
---
name: task_id [38919,38926]
name: task_id [39037,39044]
===
match
---
operator: , [14785,14786]
operator: , [14801,14802]
===
match
---
trailer [9898,9905]
trailer [9914,9921]
===
match
---
name: dag_folder [8130,8140]
name: dag_folder [8146,8156]
===
match
---
arglist [7383,7394]
arglist [7399,7410]
===
match
---
name: BaseOperator [33470,33482]
name: BaseOperator [33588,33600]
===
match
---
assert_stmt [14956,15028]
assert_stmt [14972,15044]
===
match
---
name: template_fields [31067,31082]
name: template_fields [31185,31200]
===
match
---
trailer [45163,45207]
trailer [45281,45325]
===
match
---
trailer [44384,44393]
trailer [44502,44511]
===
match
---
atom_expr [20223,20245]
atom_expr [20341,20363]
===
match
---
trailer [12501,12506]
trailer [12517,12522]
===
match
---
string: '_BaseOperator__instantiated' [34245,34274]
string: '_BaseOperator__instantiated' [34363,34392]
===
match
---
operator: , [8096,8097]
operator: , [8112,8113]
===
match
---
name: dags [5858,5862]
name: dags [5874,5878]
===
match
---
dotted_name [852,866]
dotted_name [852,866]
===
match
---
trailer [27111,27121]
trailer [27229,27239]
===
match
---
decorator [21820,21955]
decorator [21938,22073]
===
match
---
name: task_id [15355,15362]
name: task_id [15371,15378]
===
match
---
atom_expr [8843,8880]
atom_expr [8859,8896]
===
match
---
name: dags [12412,12416]
name: dags [12428,12432]
===
match
---
operator: , [33063,33064]
operator: , [33181,33182]
===
match
---
name: task_id [38970,38977]
name: task_id [39088,39095]
===
match
---
suite [8453,8508]
suite [8469,8524]
===
match
---
name: task_id [17570,17577]
name: task_id [17688,17695]
===
match
---
name: task_start_date [16613,16628]
name: task_start_date [16731,16746]
===
match
---
operator: } [14886,14887]
operator: } [14902,14903]
===
match
---
operator: = [42127,42128]
operator: = [42245,42246]
===
match
---
simple_stmt [26298,26775]
simple_stmt [26416,26893]
===
match
---
string: "days" [20285,20291]
string: "days" [20403,20409]
===
match
---
assert_stmt [15038,15104]
assert_stmt [15054,15120]
===
match
---
decorated [42536,44443]
decorated [42654,44561]
===
match
---
atom_expr [20861,20899]
atom_expr [20979,21017]
===
match
---
string: "bar" [30073,30078]
string: "bar" [30191,30196]
===
match
---
argument [33333,33348]
argument [33451,33466]
===
match
---
string: "relativedelta" [20623,20638]
string: "relativedelta" [20741,20756]
===
match
---
assert_stmt [22320,22372]
assert_stmt [22438,22490]
===
match
---
simple_stmt [1558,1649]
simple_stmt [1574,1665]
===
match
---
simple_stmt [38210,38291]
simple_stmt [38328,38409]
===
match
---
operator: , [31045,31046]
operator: , [31163,31164]
===
match
---
name: dagbag [5851,5857]
name: dagbag [5867,5873]
===
match
---
strings [31131,31526]
strings [31249,31644]
===
match
---
number: 100 [6221,6224]
number: 100 [6237,6240]
===
match
---
dictorsetmaker [30073,30100]
dictorsetmaker [30191,30218]
===
match
---
atom [42581,42712]
atom [42699,42830]
===
match
---
name: base [39639,39643]
name: base [39757,39761]
===
match
---
param [25303,25308]
param [25421,25426]
===
match
---
operator: , [17785,17786]
operator: , [17903,17904]
===
match
---
operator: , [16433,16434]
operator: , [16449,16450]
===
match
---
name: dag_dict [11004,11012]
name: dag_dict [11020,11028]
===
match
---
name: serialized_dag [22339,22353]
name: serialized_dag [22457,22471]
===
match
---
name: serialized_obj [44287,44301]
name: serialized_obj [44405,44419]
===
match
---
arglist [28288,28320]
arglist [28406,28438]
===
match
---
operator: } [13234,13235]
operator: } [13250,13251]
===
match
---
simple_stmt [37228,37267]
simple_stmt [37346,37385]
===
match
---
param [21990,21995]
param [22108,22113]
===
match
---
operator: , [35075,35076]
operator: , [35193,35194]
===
match
---
operator: } [13226,13227]
operator: } [13242,13243]
===
match
---
name: SerializedDAG [39117,39130]
name: SerializedDAG [39235,39248]
===
match
---
operator: } [15370,15371]
operator: } [15386,15387]
===
match
---
name: test_roundtrip_relativedelta [20696,20724]
name: test_roundtrip_relativedelta [20814,20842]
===
match
---
operator: } [2449,2450]
operator: } [2465,2466]
===
match
---
expr_stmt [27146,27188]
expr_stmt [27264,27306]
===
match
---
string: "UTC" [19823,19828]
string: "UTC" [19941,19946]
===
match
---
trailer [5476,5492]
trailer [5492,5508]
===
match
---
name: globals [44818,44825]
name: globals [44936,44943]
===
match
---
name: att2 [30791,30795]
name: att2 [30909,30913]
===
match
---
operator: , [30970,30971]
operator: , [31088,31089]
===
match
---
number: 1 [22235,22236]
number: 1 [22353,22354]
===
match
---
trailer [18987,18997]
trailer [19105,19115]
===
match
---
name: dags [8820,8824]
name: dags [8836,8840]
===
match
---
expr_stmt [10300,10333]
expr_stmt [10316,10349]
===
match
---
name: queue [8843,8848]
name: queue [8859,8864]
===
match
---
name: test_deserialization_start_date [16559,16590]
name: test_deserialization_start_date [16677,16708]
===
match
---
atom_expr [18925,18958]
atom_expr [19043,19076]
===
match
---
name: serialized_dag [17258,17272]
name: serialized_dag [17376,17390]
===
match
---
trailer [20236,20245]
trailer [20354,20363]
===
match
---
simple_stmt [21368,21412]
simple_stmt [21486,21530]
===
match
---
atom_expr [37500,37545]
atom_expr [37618,37663]
===
match
---
suite [44971,46069]
suite [45089,46187]
===
match
---
name: __init__ [33501,33509]
name: __init__ [33619,33627]
===
match
---
operator: = [33624,33625]
operator: = [33742,33743]
===
match
---
funcdef [14029,15978]
funcdef [14045,15994]
===
match
---
testlist_comp [30150,30267]
testlist_comp [30268,30385]
===
match
---
atom_expr [44276,44308]
atom_expr [44394,44426]
===
match
---
name: x [40239,40240]
name: x [40357,40358]
===
match
---
argument [16173,16192]
argument [16189,16208]
===
match
---
name: datetime [38855,38863]
name: datetime [38973,38981]
===
match
---
trailer [38531,38558]
trailer [38649,38676]
===
match
---
name: validate_deserialized_dag [12581,12606]
name: validate_deserialized_dag [12597,12622]
===
match
---
name: datetime [26795,26803]
name: datetime [26913,26921]
===
match
---
name: end_date [18538,18546]
name: end_date [18656,18664]
===
match
---
trailer [42429,42439]
trailer [42547,42557]
===
match
---
assert_stmt [34224,36526]
assert_stmt [34342,36644]
===
match
---
operator: , [20663,20664]
operator: , [20781,20782]
===
match
---
simple_stmt [31661,31949]
simple_stmt [31779,32067]
===
match
---
testlist_comp [26946,26960]
testlist_comp [27064,27078]
===
match
---
trailer [15900,15907]
trailer [15916,15923]
===
match
---
atom [29593,29601]
atom [29711,29719]
===
match
---
number: 600.0 [3323,3328]
number: 600.0 [3339,3344]
===
match
---
argument [26855,26875]
argument [26973,26993]
===
match
---
operator: } [20531,20532]
operator: } [20649,20650]
===
match
---
string: '_group_id' [2525,2536]
string: '_group_id' [2541,2552]
===
match
---
operator: , [41567,41568]
operator: , [41685,41686]
===
match
---
operator: , [17911,17912]
operator: , [18029,18030]
===
match
---
operator: } [19685,19686]
operator: } [19803,19804]
===
match
---
name: task [15350,15354]
name: task [15366,15370]
===
match
---
number: 8 [16492,16493]
number: 8 [16508,16509]
===
match
---
name: ignored_keys [32805,32817]
name: ignored_keys [32923,32935]
===
match
---
operator: = [28053,28054]
operator: = [28171,28172]
===
match
---
name: BaseOperator [18493,18505]
name: BaseOperator [18611,18623]
===
match
---
name: expand [21835,21841]
name: expand [21953,21959]
===
match
---
name: task_id [39810,39817]
name: task_id [39928,39935]
===
match
---
dictorsetmaker [43056,43250]
dictorsetmaker [43174,43368]
===
match
---
operator: = [21383,21384]
operator: = [21501,21502]
===
match
---
name: timedelta [6070,6079]
name: timedelta [6086,6095]
===
match
---
trailer [41434,41440]
trailer [41552,41558]
===
match
---
trailer [8894,8900]
trailer [8910,8916]
===
match
---
operator: , [34799,34800]
operator: , [34917,34918]
===
match
---
atom [30072,30101]
atom [30190,30219]
===
match
---
atom_expr [16057,16069]
atom_expr [16073,16085]
===
match
---
string: '_task_type' [14470,14482]
string: '_task_type' [14486,14498]
===
match
---
comparison [32328,32393]
comparison [32446,32511]
===
match
---
operator: , [16377,16378]
operator: , [16393,16394]
===
match
---
atom [7622,7661]
atom [7638,7677]
===
match
---
annassign [33027,33074]
annassign [33145,33192]
===
match
---
name: self [25573,25577]
name: self [25691,25695]
===
match
---
name: self [12059,12063]
name: self [12075,12079]
===
match
---
trailer [13569,13582]
trailer [13585,13598]
===
match
---
fstring [13609,13657]
fstring [13625,13673]
===
match
---
import_as_name [1113,1126]
import_as_name [1129,1142]
===
match
---
comparison [20915,20935]
comparison [21033,21053]
===
match
---
name: dag_start_date [16891,16905]
name: dag_start_date [17009,17023]
===
match
---
string: 'priority_weight' [35319,35336]
string: 'priority_weight' [35437,35454]
===
match
---
name: tzinfo [16173,16179]
name: tzinfo [16189,16195]
===
match
---
operator: { [2140,2141]
operator: { [2156,2157]
===
match
---
trailer [12416,12423]
trailer [12432,12439]
===
match
---
name: DagBag [5820,5826]
name: DagBag [5836,5842]
===
match
---
if_stmt [44656,44776]
if_stmt [44774,44894]
===
match
---
name: __ne__ [29432,29438]
name: __ne__ [29550,29556]
===
match
---
trailer [42084,42149]
trailer [42202,42267]
===
match
---
name: module [46007,46013]
name: module [46125,46131]
===
match
---
expr_stmt [17228,17273]
expr_stmt [17346,17391]
===
match
---
name: timezone [16106,16114]
name: timezone [16122,16130]
===
match
---
simple_stmt [989,1015]
simple_stmt [989,1015]
===
match
---
name: locals [44836,44842]
name: locals [44954,44960]
===
match
---
simple_stmt [33175,33229]
simple_stmt [33293,33347]
===
match
---
import_as_names [1371,1401]
import_as_names [1387,1417]
===
match
---
number: 8 [32029,32030]
number: 8 [32147,32148]
===
match
---
operator: , [43114,43115]
operator: , [43232,43233]
===
match
---
name: v [9819,9820]
name: v [9835,9836]
===
match
---
operator: == [20062,20064]
operator: == [20180,20182]
===
match
---
trailer [8937,8946]
trailer [8953,8962]
===
match
---
name: spec [1819,1823]
name: spec [1835,1839]
===
match
---
name: CustomOperator [23322,23336]
name: CustomOperator [23440,23454]
===
match
---
argument [22185,22192]
argument [22303,22310]
===
match
---
string: "dag" [2054,2059]
string: "dag" [2070,2075]
===
match
---
operator: , [28790,28791]
operator: , [28908,28909]
===
match
---
expr_stmt [8167,8190]
expr_stmt [8183,8206]
===
match
---
trailer [36798,36810]
trailer [36916,36928]
===
match
---
trailer [18505,18561]
trailer [18623,18679]
===
match
---
name: dag_dict [10369,10377]
name: dag_dict [10385,10393]
===
match
---
name: DAG [36824,36827]
name: DAG [36942,36945]
===
match
---
trailer [16086,16119]
trailer [16102,16135]
===
match
---
trailer [45869,45876]
trailer [45987,45994]
===
match
---
operator: , [21114,21115]
operator: , [21232,21233]
===
match
---
operator: { [43780,43781]
operator: { [43898,43899]
===
match
---
dictorsetmaker [2101,2440]
dictorsetmaker [2117,2456]
===
match
---
name: dag [23519,23522]
name: dag [23637,23640]
===
match
---
arglist [42137,42147]
arglist [42255,42265]
===
match
---
name: task_id [26900,26907]
name: task_id [27018,27025]
===
match
---
simple_stmt [24428,24508]
simple_stmt [24546,24626]
===
match
---
name: SerializedDAG [37440,37453]
name: SerializedDAG [37558,37571]
===
match
---
strings [30474,30611]
strings [30592,30729]
===
match
---
name: make_example_dags [8478,8495]
name: make_example_dags [8494,8511]
===
match
---
simple_stmt [1168,1208]
simple_stmt [1184,1224]
===
match
---
operator: , [19195,19196]
operator: , [19313,19314]
===
match
---
operator: = [30712,30713]
operator: = [30830,30831]
===
match
---
trailer [46027,46035]
trailer [46145,46153]
===
match
---
trailer [37585,37601]
trailer [37703,37719]
===
match
---
name: task_id [37198,37205]
name: task_id [37316,37323]
===
match
---
name: serialized_dag [18844,18858]
name: serialized_dag [18962,18976]
===
match
---
name: parameterized [20178,20191]
name: parameterized [20296,20309]
===
match
---
expr_stmt [26783,26815]
expr_stmt [26901,26933]
===
match
---
atom [40207,40261]
atom [40325,40379]
===
match
---
name: dag_folder [8079,8089]
name: dag_folder [8095,8105]
===
match
---
operator: , [7486,7487]
operator: , [7502,7503]
===
match
---
name: passed_failure_callback [42039,42062]
name: passed_failure_callback [42157,42180]
===
match
---
string: "weekday" [20650,20659]
string: "weekday" [20768,20777]
===
match
---
comparison [15045,15104]
comparison [15061,15120]
===
match
---
dotted_name [39623,39643]
dotted_name [39741,39761]
===
match
---
name: parameterized [19133,19146]
name: parameterized [19251,19264]
===
match
---
operator: , [20344,20345]
operator: , [20462,20463]
===
match
---
operator: , [11506,11507]
operator: , [11522,11523]
===
match
---
trailer [20326,20344]
trailer [20444,20462]
===
match
---
trailer [16674,16722]
trailer [16792,16840]
===
match
---
string: """         Test TaskGroup serialization/deserialization.         """ [36581,36650]
string: """         Test TaskGroup serialization/deserialization.         """ [36699,36768]
===
match
---
number: 600.0 [4555,4560]
number: 600.0 [4571,4576]
===
match
---
trailer [37453,37463]
trailer [37571,37581]
===
match
---
trailer [44286,44308]
trailer [44404,44426]
===
match
---
atom_expr [34193,34215]
atom_expr [34311,34333]
===
match
---
trailer [37666,37677]
trailer [37784,37795]
===
match
---
string: """Verify serialized DAGs match the ground truth.""" [10151,10203]
string: """Verify serialized DAGs match the ground truth.""" [10167,10219]
===
match
---
operator: = [26016,26017]
operator: = [26134,26135]
===
match
---
atom_expr [29147,29172]
atom_expr [29265,29290]
===
match
---
name: task [15563,15567]
name: task [15579,15583]
===
match
---
parameters [10107,10141]
parameters [10123,10157]
===
match
---
operator: , [25673,25674]
operator: , [25791,25792]
===
match
---
string: "true" [23382,23388]
string: "true" [23500,23506]
===
match
---
name: other [29404,29409]
name: other [29522,29527]
===
match
---
assert_stmt [23967,24112]
assert_stmt [24085,24230]
===
match
---
number: 1 [17910,17911]
number: 1 [18028,18029]
===
match
---
name: side_effect [44928,44939]
name: side_effect [45046,45057]
===
match
---
simple_stmt [45592,45636]
simple_stmt [45710,45754]
===
match
---
trailer [19091,19100]
trailer [19209,19218]
===
match
---
string: "value" [43116,43123]
string: "value" [43234,43241]
===
match
---
dictorsetmaker [43709,43761]
dictorsetmaker [43827,43879]
===
match
---
operator: , [20734,20735]
operator: , [20852,20853]
===
match
---
operator: { [29765,29766]
operator: { [29883,29884]
===
match
---
name: serialized_obj [44325,44339]
name: serialized_obj [44443,44457]
===
match
---
atom [30256,30263]
atom [30374,30381]
===
match
---
name: expect_custom_deps [39930,39948]
name: expect_custom_deps [40048,40066]
===
match
---
atom [8178,8190]
atom [8194,8206]
===
match
---
number: 8 [23247,23248]
number: 8 [23365,23366]
===
match
---
argument [44871,44882]
argument [44989,45000]
===
match
---
name: set [24172,24175]
name: set [24290,24293]
===
match
---
classdef [8903,44443]
classdef [8919,44561]
===
match
---
atom_expr [11957,11968]
atom_expr [11973,11984]
===
match
---
trailer [17351,17362]
trailer [17469,17480]
===
match
---
argument [25649,25680]
argument [25767,25798]
===
match
---
trailer [7322,7338]
trailer [7338,7354]
===
match
---
operator: { [29594,29595]
operator: { [29712,29713]
===
match
---
name: set [15003,15006]
name: set [15019,15022]
===
match
---
comparison [33696,33720]
comparison [33814,33838]
===
match
---
decorated [20941,21815]
decorated [21059,21933]
===
match
---
trailer [12120,12128]
trailer [12136,12144]
===
match
---
number: 8 [25675,25676]
number: 8 [25793,25794]
===
match
---
expr_stmt [21561,21619]
expr_stmt [21679,21737]
===
match
---
operator: , [13190,13191]
operator: , [13206,13207]
===
match
---
simple_stmt [39793,39856]
simple_stmt [39911,39974]
===
match
---
string: "__var" [2269,2276]
string: "__var" [2285,2292]
===
match
---
string: "max_retry_delay" [6104,6121]
string: "max_retry_delay" [6120,6137]
===
match
---
operator: , [34668,34669]
operator: , [34786,34787]
===
match
---
name: set [33029,33032]
name: set [33147,33150]
===
match
---
operator: , [10037,10038]
operator: , [10053,10054]
===
match
---
simple_stmt [37429,37492]
simple_stmt [37547,37610]
===
match
---
testlist_comp [8234,8355]
testlist_comp [8250,8371]
===
match
---
string: 'bash_command' [4942,4956]
string: 'bash_command' [4958,4972]
===
match
---
operator: = [34191,34192]
operator: = [34309,34310]
===
match
---
import_from [916,966]
import_from [916,966]
===
match
---
trailer [8638,8640]
trailer [8654,8656]
===
match
---
operator: = [37017,37018]
operator: = [37135,37136]
===
match
---
testlist_comp [16152,16312]
testlist_comp [16168,16328]
===
match
---
name: task_id [37250,37257]
name: task_id [37368,37375]
===
match
---
name: stringified_dags [11925,11941]
name: stringified_dags [11941,11957]
===
match
---
suite [38465,38506]
suite [38583,38624]
===
match
---
operator: = [12821,12822]
operator: = [12837,12838]
===
match
---
string: 'task_4' [42920,42928]
string: 'task_4' [43038,43046]
===
match
---
suite [13281,13658]
suite [13297,13674]
===
match
---
name: path [5623,5627]
name: path [5639,5643]
===
match
---
operator: , [19600,19601]
operator: , [19718,19719]
===
match
---
trailer [40247,40253]
trailer [40365,40371]
===
match
---
operator: , [2360,2361]
operator: , [2376,2377]
===
match
---
operator: = [14390,14391]
operator: = [14406,14407]
===
match
---
name: dag_id [41988,41994]
name: dag_id [42106,42112]
===
match
---
number: 7 [18232,18233]
number: 7 [18350,18351]
===
match
---
fstring_end: ' [13656,13657]
fstring_end: ' [13672,13673]
===
match
---
string: """ !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!       ACTION NEEDED! PLEASE READ THIS CAREFULLY AND CORRECT TESTS CAREFULLY   Some fields were added to the BaseOperator! Please add them to the list above and make sure that  you add support for DAG serialization - you should add the field to  `airflow/serialization/schema.json` - they should have correct type defined there.   Note that we do not support versioning yet so you should only add optional fields to BaseOperator.  !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!                          """ [35856,36526]
string: """ !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!       ACTION NEEDED! PLEASE READ THIS CAREFULLY AND CORRECT TESTS CAREFULLY   Some fields were added to the BaseOperator! Please add them to the list above and make sure that  you add support for DAG serialization - you should add the field to  `airflow/serialization/schema.json` - they should have correct type defined there.   Note that we do not support versioning yet so you should only add optional fields to BaseOperator.  !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!                          """ [35974,36644]
===
match
---
operator: , [16048,16049]
operator: , [16064,16065]
===
match
---
atom [2087,2450]
atom [2103,2466]
===
match
---
comparison [33320,33370]
comparison [33438,33488]
===
match
---
trailer [6367,6383]
trailer [6383,6399]
===
match
---
string: 'on_failure_callback' [14729,14750]
string: 'on_failure_callback' [14745,14766]
===
match
---
param [32442,32446]
param [32560,32564]
===
match
---
name: dag [27092,27095]
name: dag [27210,27213]
===
match
---
operator: , [16091,16092]
operator: , [16107,16108]
===
match
---
number: 2019 [16367,16371]
number: 2019 [16383,16387]
===
match
---
testlist_comp [29810,29888]
testlist_comp [29928,30006]
===
match
---
name: serialized_dag [13674,13688]
name: serialized_dag [13690,13704]
===
match
---
string: "{{ task.task_id }}" [30234,30254]
string: "{{ task.task_id }}" [30352,30372]
===
match
---
operator: { [43352,43353]
operator: { [43470,43471]
===
match
---
string: "__var" [43514,43521]
string: "__var" [43632,43639]
===
match
---
string: 'index' [27692,27699]
string: 'index' [27810,27817]
===
match
---
operator: , [35468,35469]
operator: , [35586,35587]
===
match
---
operator: = [41227,41228]
operator: = [41345,41346]
===
match
---
atom_expr [11029,11068]
atom_expr [11045,11084]
===
match
---
name: get_task [38065,38073]
name: get_task [38183,38191]
===
match
---
operator: , [23248,23249]
operator: , [23366,23367]
===
match
---
string: "{{ task.task_id }}" [29697,29717]
string: "{{ task.task_id }}" [29815,29835]
===
match
---
trailer [33579,33589]
trailer [33697,33707]
===
match
---
name: values [8825,8831]
name: values [8841,8847]
===
match
---
string: 'custom_task' [6510,6523]
string: 'custom_task' [6526,6539]
===
match
---
argument [26834,26853]
argument [26952,26971]
===
match
---
suite [19550,20172]
suite [19668,20290]
===
match
---
operator: , [6090,6091]
operator: , [6106,6107]
===
match
---
atom_expr [15820,15842]
atom_expr [15836,15858]
===
match
---
atom [30295,30626]
atom [30413,30744]
===
match
---
expr_stmt [9511,9530]
expr_stmt [9527,9546]
===
match
---
simple_stmt [25605,25610]
simple_stmt [25723,25728]
===
match
---
operator: , [17513,17514]
operator: , [17631,17632]
===
match
---
trailer [45282,45294]
trailer [45400,45412]
===
match
---
atom_expr [20040,20061]
atom_expr [20158,20179]
===
match
---
trailer [8866,8874]
trailer [8882,8890]
===
match
---
atom_expr [10813,10878]
atom_expr [10829,10894]
===
match
---
simple_stmt [32186,32245]
simple_stmt [32304,32363]
===
match
---
atom [21035,21057]
atom [21153,21175]
===
match
---
atom_expr [10736,10800]
atom_expr [10752,10816]
===
match
---
operator: { [13228,13229]
operator: { [13244,13245]
===
match
---
atom_expr [25531,25546]
atom_expr [25649,25664]
===
match
---
comparison [11029,11103]
comparison [11045,11119]
===
match
---
number: 1 [2047,2048]
number: 1 [2063,2064]
===
match
---
name: dag [7824,7827]
name: dag [7840,7843]
===
match
---
testlist_comp [20986,21059]
testlist_comp [21104,21177]
===
match
---
name: multiprocessing [11455,11470]
name: multiprocessing [11471,11486]
===
match
---
string: "SubDagOperator" [15783,15799]
string: "SubDagOperator" [15799,15815]
===
match
---
operator: , [15265,15266]
operator: , [15281,15282]
===
match
---
trailer [24344,24377]
trailer [24462,24495]
===
match
---
operator: , [8354,8355]
operator: , [8370,8371]
===
match
---
atom_expr [15082,15104]
atom_expr [15098,15120]
===
match
---
string: 'test_dag_on_success_callback_roundtrip' [40808,40848]
string: 'test_dag_on_success_callback_roundtrip' [40926,40966]
===
match
---
name: module [45216,45222]
name: module [45334,45340]
===
match
---
operator: @ [21820,21821]
operator: @ [21938,21939]
===
match
---
name: v [9760,9761]
name: v [9776,9777]
===
match
---
name: edge_info [39403,39412]
name: edge_info [39521,39530]
===
match
---
string: "bar" [29819,29824]
string: "bar" [29937,29942]
===
match
---
atom [31083,31094]
atom [31201,31212]
===
match
---
expr_stmt [22248,22291]
expr_stmt [22366,22409]
===
match
---
trailer [33568,33570]
trailer [33686,33688]
===
match
---
trailer [11762,11765]
trailer [11778,11781]
===
match
---
argument [30945,30970]
argument [31063,31088]
===
match
---
number: 0 [18875,18876]
number: 0 [18993,18994]
===
match
---
atom_expr [1916,1968]
atom_expr [1932,1984]
===
match
---
operator: = [36914,36915]
operator: = [37032,37033]
===
match
---
operator: { [43380,43381]
operator: { [43498,43499]
===
match
---
atom_expr [37236,37266]
atom_expr [37354,37384]
===
match
---
testlist_comp [17769,17859]
testlist_comp [17887,17977]
===
match
---
funcdef [33234,33909]
funcdef [33352,34027]
===
match
---
comparison [38342,38406]
comparison [38460,38524]
===
match
---
trailer [5678,5687]
trailer [5694,5703]
===
match
---
name: self [29387,29391]
name: self [29505,29509]
===
match
---
simple_stmt [39865,39918]
simple_stmt [39983,40036]
===
match
---
operator: == [15079,15081]
operator: == [15095,15097]
===
match
---
operator: , [18237,18238]
operator: , [18355,18356]
===
match
---
simple_stmt [19931,19973]
simple_stmt [20049,20091]
===
match
---
name: dag_dict [37411,37419]
name: dag_dict [37529,37537]
===
match
---
operator: , [42857,42858]
operator: , [42975,42976]
===
match
---
name: self [29253,29257]
name: self [29371,29375]
===
match
---
operator: , [3501,3502]
operator: , [3517,3518]
===
match
---
assert_stmt [42326,42387]
assert_stmt [42444,42505]
===
match
---
arglist [6266,6276]
arglist [6282,6292]
===
match
---
name: tzinfo [16232,16238]
name: tzinfo [16248,16254]
===
match
---
name: self [33284,33288]
name: self [33402,33406]
===
match
---
testlist_comp [42889,42988]
testlist_comp [43007,43106]
===
match
---
name: airflow [38696,38703]
name: airflow [38814,38821]
===
match
---
argument [18179,18198]
argument [18297,18316]
===
match
---
name: default_args [13310,13322]
name: default_args [13326,13338]
===
match
---
operator: , [43919,43920]
operator: , [44037,44038]
===
match
---
name: to_json [39214,39221]
name: to_json [39332,39339]
===
match
---
name: task_dict [23591,23600]
name: task_dict [23709,23718]
===
match
---
operator: } [24100,24101]
operator: } [24218,24219]
===
match
---
argument [11479,11506]
argument [11495,11522]
===
match
---
operator: = [2026,2027]
operator: = [2042,2043]
===
match
---
name: name [28803,28807]
name: name [28921,28925]
===
match
---
simple_stmt [22735,23212]
simple_stmt [22853,23330]
===
match
---
param [10108,10113]
param [10124,10129]
===
match
---
string: "{{ task.task_id }}" [30977,30997]
string: "{{ task.task_id }}" [31095,31115]
===
match
---
testlist_comp [27633,27790]
testlist_comp [27751,27908]
===
match
---
param [39745,39752]
param [39863,39870]
===
match
---
atom [11513,11544]
atom [11529,11560]
===
match
---
atom_expr [40885,40962]
atom_expr [41003,41080]
===
match
---
trailer [25983,25986]
trailer [26101,26104]
===
match
---
atom [19572,19921]
atom [19690,20039]
===
match
---
expr_stmt [39865,39917]
expr_stmt [39983,40035]
===
match
---
arglist [14345,14363]
arglist [14361,14379]
===
match
---
operator: = [31014,31015]
operator: = [31132,31133]
===
match
---
simple_stmt [31958,32036]
simple_stmt [32076,32154]
===
match
---
arglist [10008,10073]
arglist [10024,10089]
===
match
---
trailer [37359,37367]
trailer [37477,37485]
===
match
---
name: GoogleLink [28792,28802]
name: GoogleLink [28910,28920]
===
match
---
string: '_log' [14568,14574]
string: '_log' [14584,14590]
===
match
---
name: fromlist [44852,44860]
name: fromlist [44970,44978]
===
match
---
string: "is_paused_upon_creation" [2967,2992]
string: "is_paused_upon_creation" [2983,3008]
===
match
---
atom_expr [6203,6225]
atom_expr [6219,6241]
===
match
---
string: 'bash_task' [3810,3821]
string: 'bash_task' [3826,3837]
===
match
---
string: 'next_execution_date' [7530,7551]
string: 'next_execution_date' [7546,7567]
===
match
---
simple_stmt [19982,20024]
simple_stmt [20100,20142]
===
match
---
operator: ** [33580,33582]
operator: ** [33698,33700]
===
match
---
argument [40921,40928]
argument [41039,41046]
===
match
---
number: 1 [27786,27787]
number: 1 [27904,27905]
===
match
---
string: 'task_1' [42745,42753]
string: 'task_1' [42863,42871]
===
match
---
name: operators [38704,38713]
name: operators [38822,38831]
===
match
---
name: round_tripped [20845,20858]
name: round_tripped [20963,20976]
===
match
---
parameters [16590,16655]
parameters [16708,16773]
===
match
---
simple_stmt [9022,9038]
simple_stmt [9038,9054]
===
match
---
param [44590,44595]
param [44708,44713]
===
match
---
string: 'on_success_callback' [14764,14785]
string: 'on_success_callback' [14780,14801]
===
match
---
name: test_date [23220,23229]
name: test_date [23338,23347]
===
match
---
simple_stmt [1083,1127]
simple_stmt [1099,1143]
===
match
---
string: "__type" [43353,43361]
string: "__type" [43471,43479]
===
match
---
string: "_concurrency" [33049,33063]
string: "_concurrency" [33167,33181]
===
match
---
suite [15927,15978]
suite [15943,15994]
===
match
---
trailer [13582,13585]
trailer [13598,13601]
===
match
---
name: task [15480,15484]
name: task [15496,15500]
===
match
---
string: "has_on_failure_callback" [32924,32949]
string: "has_on_failure_callback" [33042,33067]
===
match
---
operator: } [7946,7947]
operator: } [7962,7963]
===
match
---
string: 'hello' [7623,7630]
string: 'hello' [7639,7646]
===
match
---
arglist [16279,16310]
arglist [16295,16326]
===
match
---
name: split [45485,45490]
name: split [45603,45608]
===
match
---
atom_expr [9511,9523]
atom_expr [9527,9539]
===
match
---
string: "{{ task.task_id }}" [29638,29658]
string: "{{ task.task_id }}" [29756,29776]
===
match
---
operator: , [26853,26854]
operator: , [26971,26972]
===
match
---
funcdef [39730,39784]
funcdef [39848,39902]
===
match
---
expr_stmt [37848,37881]
expr_stmt [37966,37999]
===
match
---
name: getattr [13162,13169]
name: getattr [13178,13185]
===
match
---
suite [9013,9563]
suite [9029,9579]
===
match
---
name: blob [33730,33734]
name: blob [33848,33852]
===
match
---
argument [23337,23358]
argument [23455,23476]
===
match
---
operator: , [18026,18027]
operator: , [18144,18145]
===
match
---
name: BaseOperator [21281,21293]
name: BaseOperator [21399,21411]
===
match
---
name: weekday [20465,20472]
name: weekday [20583,20590]
===
match
---
operator: { [3685,3686]
operator: { [3701,3702]
===
match
---
suite [6870,7864]
suite [6886,7880]
===
match
---
number: 1 [18116,18117]
number: 1 [18234,18235]
===
match
---
name: from_dict [32219,32228]
name: from_dict [32337,32346]
===
match
---
name: op [33779,33781]
name: op [33897,33899]
===
match
---
atom [2140,2439]
atom [2156,2455]
===
match
---
operator: } [20994,20995]
operator: } [21112,21113]
===
match
---
name: test_utils [1660,1670]
name: test_utils [1676,1686]
===
match
---
name: os [5655,5657]
name: os [5671,5673]
===
match
---
name: serialized_dag [22508,22522]
name: serialized_dag [22626,22640]
===
match
---
import_from [1402,1449]
import_from [1418,1465]
===
match
---
name: expected_n_schedule_interval [19515,19543]
name: expected_n_schedule_interval [19633,19661]
===
match
---
param [29439,29444]
param [29557,29562]
===
match
---
trailer [7382,7395]
trailer [7398,7411]
===
match
---
number: 1 [17512,17513]
number: 1 [17630,17631]
===
match
---
string: "tasks" [10759,10766]
string: "tasks" [10775,10782]
===
match
---
operator: , [16595,16596]
operator: , [16713,16714]
===
match
---
operator: = [8218,8219]
operator: = [8234,8235]
===
match
---
name: dag [40791,40794]
name: dag [40909,40912]
===
match
---
operator: , [3182,3183]
operator: , [3198,3199]
===
match
---
trailer [41242,41252]
trailer [41360,41370]
===
match
---
atom [43690,43849]
atom [43808,43967]
===
match
---
name: dag_id [11839,11845]
name: dag_id [11855,11861]
===
match
---
name: executor_config_pod [6706,6725]
name: executor_config_pod [6722,6741]
===
match
---
atom_expr [8420,8452]
atom_expr [8436,8468]
===
match
---
trailer [16425,16459]
trailer [16441,16475]
===
match
---
name: dag [18398,18401]
name: dag [18516,18519]
===
match
---
suite [32448,33229]
suite [32566,33347]
===
match
---
atom_expr [35457,35474]
atom_expr [35575,35592]
===
match
---
atom_expr [36790,36810]
atom_expr [36908,36928]
===
match
---
name: make_user_defined_macro_filter_dag [7999,8033]
name: make_user_defined_macro_filter_dag [8015,8049]
===
match
---
operator: , [28532,28533]
operator: , [28650,28651]
===
match
---
number: 1 [20333,20334]
number: 1 [20451,20452]
===
match
---
name: dag [7820,7823]
name: dag [7836,7839]
===
match
---
fstring_string: . [13227,13228]
fstring_string: . [13243,13244]
===
match
---
operator: , [19188,19189]
operator: , [19306,19307]
===
match
---
funcdef [8681,8901]
funcdef [8697,8917]
===
match
---
name: group34 [37096,37103]
name: group34 [37214,37221]
===
match
---
arglist [22162,22237]
arglist [22280,22355]
===
match
---
name: name [1888,1892]
name: name [1904,1908]
===
match
---
atom [16014,16544]
atom [16030,16662]
===
match
---
trailer [16851,16856]
trailer [16969,16974]
===
match
---
name: dag [31958,31961]
name: dag [32076,32079]
===
match
---
name: test_dag_on_failure_callback_roundtrip [41499,41537]
name: test_dag_on_failure_callback_roundtrip [41617,41655]
===
match
---
string: 'task_id' [35692,35701]
string: 'task_id' [35810,35819]
===
match
---
name: name [7654,7658]
name: name [7670,7674]
===
match
---
operator: } [20530,20531]
operator: } [20648,20649]
===
match
---
atom_expr [16239,16251]
atom_expr [16255,16267]
===
match
---
name: SerializedDAG [26989,27002]
name: SerializedDAG [27107,27120]
===
match
---
string: 'Google Custom' [24205,24220]
string: 'Google Custom' [24323,24338]
===
match
---
operator: , [16094,16095]
operator: , [16110,16111]
===
match
---
trailer [17309,17324]
trailer [17427,17442]
===
match
---
atom_expr [32014,32034]
atom_expr [32132,32152]
===
match
---
name: globals_ [44826,44834]
name: globals_ [44944,44952]
===
match
---
param [39589,39607]
param [39707,39725]
===
match
---
name: validate_deserialized_dag [12064,12089]
name: validate_deserialized_dag [12080,12105]
===
match
---
name: __name__ [29238,29246]
name: __name__ [29356,29364]
===
match
---
name: dag [9791,9794]
name: dag [9807,9810]
===
match
---
name: ClassWithCustomAttributes [30713,30738]
name: ClassWithCustomAttributes [30831,30856]
===
match
---
comparison [13550,13585]
comparison [13566,13601]
===
match
---
operator: , [3867,3868]
operator: , [3883,3884]
===
match
---
operator: == [28849,28851]
operator: == [28967,28969]
===
match
---
string: 'simple_task' [21302,21315]
string: 'simple_task' [21420,21433]
===
match
---
param [40351,40356]
param [40469,40474]
===
match
---
name: dag [19036,19039]
name: dag [19154,19157]
===
match
---
param [16630,16654]
param [16748,16772]
===
match
---
funcdef [7866,8679]
funcdef [7882,8695]
===
match
---
name: dag [18529,18532]
name: dag [18647,18650]
===
match
---
name: mock [1010,1014]
name: mock [1010,1014]
===
match
---
param [20725,20730]
param [20843,20848]
===
match
---
parameters [18329,18388]
parameters [18447,18506]
===
match
---
atom_expr [16477,16518]
atom_expr [16493,16534]
===
match
---
name: mock [9072,9076]
name: mock [9088,9092]
===
match
---
argument [6287,6316]
argument [6303,6332]
===
match
---
arglist [39267,39280]
arglist [39385,39398]
===
match
---
name: att2 [30387,30391]
name: att2 [30505,30509]
===
match
---
decorator [40162,40304]
decorator [40280,40422]
===
match
---
trailer [1875,1887]
trailer [1891,1903]
===
match
---
atom_expr [19931,19972]
atom_expr [20049,20090]
===
match
---
name: _deserialize [20875,20887]
name: _deserialize [20993,21005]
===
match
---
param [8713,8723]
param [8729,8739]
===
match
---
operator: , [4904,4905]
operator: , [4920,4921]
===
match
---
string: 'bash_task' [6567,6578]
string: 'bash_task' [6583,6594]
===
match
---
name: dag [25777,25780]
name: dag [25895,25898]
===
match
---
atom_expr [14933,14947]
atom_expr [14949,14963]
===
match
---
atom_expr [42366,42387]
atom_expr [42484,42505]
===
match
---
operator: , [29443,29444]
operator: , [29561,29562]
===
match
---
operator: , [5537,5538]
operator: , [5553,5554]
===
match
---
assert_stmt [40010,40035]
assert_stmt [40128,40153]
===
match
---
name: received_logs [25950,25963]
name: received_logs [26068,26081]
===
match
---
trailer [45802,45816]
trailer [45920,45934]
===
match
---
atom_expr [32346,32393]
atom_expr [32464,32511]
===
match
---
atom_expr [22116,22140]
atom_expr [22234,22258]
===
match
---
operator: { [34901,34902]
operator: { [35019,35020]
===
match
---
name: utc [16395,16398]
name: utc [16411,16414]
===
match
---
name: days [19350,19354]
name: days [19468,19472]
===
match
---
suite [13496,13658]
suite [13512,13674]
===
match
---
comparison [21514,21551]
comparison [21632,21669]
===
match
---
atom_expr [15007,15027]
atom_expr [15023,15043]
===
match
---
atom_expr [11835,11845]
atom_expr [11851,11861]
===
match
---
simple_stmt [21230,21273]
simple_stmt [21348,21391]
===
match
---
name: __file__ [5688,5696]
name: __file__ [5704,5712]
===
match
---
atom_expr [16211,16252]
atom_expr [16227,16268]
===
match
---
trailer [16743,16803]
trailer [16861,16921]
===
match
---
trailer [33570,33579]
trailer [33688,33697]
===
match
---
name: do_xcom_push [33699,33711]
name: do_xcom_push [33817,33829]
===
match
---
atom [4941,4957]
atom [4957,4973]
===
match
---
simple_stmt [12805,13071]
simple_stmt [12821,13087]
===
match
---
name: ClassWithCustomAttributes [30894,30919]
name: ClassWithCustomAttributes [31012,31037]
===
match
---
string: 'retry_delay' [35442,35455]
string: 'retry_delay' [35560,35573]
===
match
---
dictorsetmaker [45475,45573]
dictorsetmaker [45593,45691]
===
match
---
expr_stmt [32640,32717]
expr_stmt [32758,32835]
===
match
---
string: "sar" [30257,30262]
string: "sar" [30375,30380]
===
match
---
operator: = [33340,33341]
operator: = [33458,33459]
===
match
---
or_test [18626,18676]
or_test [18744,18794]
===
match
---
simple_stmt [1127,1167]
simple_stmt [1143,1183]
===
match
---
argument [31067,31094]
argument [31185,31212]
===
match
---
string: '_log' [34390,34396]
string: '_log' [34508,34514]
===
match
---
operator: , [30611,30612]
operator: , [30729,30730]
===
match
---
operator: , [5313,5314]
operator: , [5329,5330]
===
match
---
trailer [19049,19064]
trailer [19167,19182]
===
match
---
operator: == [15274,15276]
operator: == [15290,15292]
===
match
---
operator: = [30833,30834]
operator: = [30951,30952]
===
match
---
trailer [11591,11593]
trailer [11607,11609]
===
match
---
operator: , [12611,12612]
operator: , [12627,12628]
===
match
---
trailer [8424,8452]
trailer [8440,8468]
===
match
---
number: 8 [16044,16045]
number: 8 [16060,16061]
===
match
---
atom_expr [15885,15907]
atom_expr [15901,15923]
===
match
---
name: timezone [17920,17928]
name: timezone [18038,18046]
===
match
---
name: serialized_obj [44353,44367]
name: serialized_obj [44471,44485]
===
match
---
string: "CustomOperator" [5038,5054]
string: "CustomOperator" [5054,5070]
===
match
---
name: mode [39832,39836]
name: mode [39950,39954]
===
match
---
name: do_xcom_push [33626,33638]
name: do_xcom_push [33744,33756]
===
match
---
simple_stmt [21507,21552]
simple_stmt [21625,21670]
===
match
---
simple_stmt [11554,11573]
simple_stmt [11570,11589]
===
match
---
return_stmt [5844,5862]
return_stmt [5860,5878]
===
match
---
suite [11155,12130]
suite [11171,12146]
===
match
---
name: BaseSensorOperator [39651,39669]
name: BaseSensorOperator [39769,39787]
===
match
---
return_stmt [44784,44883]
return_stmt [44902,45001]
===
match
---
string: 'simple_task' [22170,22183]
string: 'simple_task' [22288,22301]
===
match
---
name: dag [21407,21410]
name: dag [21525,21528]
===
match
---
operator: } [5511,5512]
operator: } [5527,5528]
===
match
---
name: deserialized_test_task [32354,32376]
name: deserialized_test_task [32472,32494]
===
match
---
atom [30217,30266]
atom [30335,30384]
===
match
---
name: days [20237,20241]
name: days [20355,20359]
===
match
---
operator: = [21234,21235]
operator: = [21352,21353]
===
match
---
name: datetime [16270,16278]
name: datetime [16286,16294]
===
match
---
trailer [28506,28522]
trailer [28624,28640]
===
match
---
operator: { [40208,40209]
operator: { [40326,40327]
===
match
---
trailer [16160,16193]
trailer [16176,16209]
===
match
---
name: serialized_dag [27122,27136]
name: serialized_dag [27240,27254]
===
match
---
operator: , [42784,42785]
operator: , [42902,42903]
===
match
---
operator: , [30003,30004]
operator: , [30121,30122]
===
match
---
operator: = [18546,18547]
operator: = [18664,18665]
===
match
---
argument [16439,16458]
argument [16455,16474]
===
match
---
atom_expr [40138,40156]
atom_expr [40256,40274]
===
match
---
operator: == [20140,20142]
operator: == [20258,20260]
===
match
---
string: "simple_task" [21682,21695]
string: "simple_task" [21800,21813]
===
match
---
string: 'echo {{ task.task_id }}' [6605,6630]
string: 'echo {{ task.task_id }}' [6621,6646]
===
match
---
name: self [9979,9983]
name: self [9995,9999]
===
match
---
number: 1 [19599,19600]
number: 1 [19717,19718]
===
match
---
atom [4408,5216]
atom [4424,5232]
===
match
---
operator: = [28258,28259]
operator: = [28376,28377]
===
match
---
trailer [10023,10037]
trailer [10039,10053]
===
match
---
name: SerializedDAG [17691,17704]
name: SerializedDAG [17809,17822]
===
match
---
number: 1 [20342,20343]
number: 1 [20460,20461]
===
match
---
simple_stmt [40010,40036]
simple_stmt [40128,40154]
===
match
---
name: dag [32049,32052]
name: dag [32167,32170]
===
match
---
atom_expr [45271,45302]
atom_expr [45389,45420]
===
match
---
name: deserialize_dag [37586,37601]
name: deserialize_dag [37704,37719]
===
match
---
name: serialize_operator [39895,39913]
name: serialize_operator [40013,40031]
===
match
---
trailer [39013,39027]
trailer [39131,39145]
===
match
---
simple_stmt [10300,10334]
simple_stmt [10316,10350]
===
match
---
simple_stmt [24516,24604]
simple_stmt [24634,24722]
===
match
---
operator: = [38903,38904]
operator: = [39021,39022]
===
match
---
trailer [9027,9029]
trailer [9043,9045]
===
match
---
operator: , [30103,30104]
operator: , [30221,30222]
===
match
---
with_stmt [44889,46069]
with_stmt [45007,46187]
===
match
---
string: 'inlets' [34917,34925]
string: 'inlets' [35035,35043]
===
match
---
name: start_date [36861,36871]
name: start_date [36979,36989]
===
match
---
expr_stmt [23519,23564]
expr_stmt [23637,23682]
===
match
---
name: expected_task_start_date [16630,16654]
name: expected_task_start_date [16748,16772]
===
match
---
operator: == [23668,23670]
operator: == [23786,23788]
===
match
---
atom [4731,4733]
atom [4747,4749]
===
match
---
trailer [15549,15559]
trailer [15565,15575]
===
match
---
name: task_group [37667,37677]
name: task_group [37785,37795]
===
match
---
name: expected_err_msg [26184,26200]
name: expected_err_msg [26302,26318]
===
match
---
operator: , [42908,42909]
operator: , [43026,43027]
===
match
---
name: validate_deserialized_task [13779,13805]
name: validate_deserialized_task [13795,13821]
===
match
---
comparison [27557,27800]
comparison [27675,27918]
===
match
---
atom [29903,30118]
atom [30021,30236]
===
match
---
operator: , [18536,18537]
operator: , [18654,18655]
===
match
---
fstring [15329,15387]
fstring [15345,15403]
===
match
---
simple_stmt [18968,19014]
simple_stmt [19086,19132]
===
match
---
string: "bash_command" [3742,3756]
string: "bash_command" [3758,3772]
===
match
---
string: """         Verify that all example DAGs work with DAG Serialization by         checking fields between Serialized Dags & non-Serialized Dags         """ [12643,12796]
string: """         Verify that all example DAGs work with DAG Serialization by         checking fields between Serialized Dags & non-Serialized Dags         """ [12659,12812]
===
match
---
string: 'resources' [14865,14876]
string: 'resources' [14881,14892]
===
match
---
funcdef [25290,25374]
funcdef [25408,25492]
===
match
---
string: 'subdag' [35626,35634]
string: 'subdag' [35744,35752]
===
match
---
operator: = [44825,44826]
operator: = [44943,44944]
===
match
---
argument [6213,6224]
argument [6229,6240]
===
match
---
operator: , [27223,27224]
operator: , [27341,27342]
===
match
---
parameters [11148,11154]
parameters [11164,11170]
===
match
---
atom_expr [26795,26815]
atom_expr [26913,26933]
===
match
---
param [31619,31635]
param [31737,31753]
===
match
---
atom [19177,19195]
atom [19295,19313]
===
match
---
operator: , [7661,7662]
operator: , [7677,7678]
===
match
---
operator: = [37127,37128]
operator: = [37245,37246]
===
match
---
name: isinstance [11785,11795]
name: isinstance [11801,11811]
===
match
---
string: "__var" [10962,10969]
string: "__var" [10978,10985]
===
match
---
name: locals_ [44843,44850]
name: locals_ [44961,44968]
===
match
---
string: 'task_concurrency' [35654,35672]
string: 'task_concurrency' [35772,35790]
===
match
---
dictorsetmaker [30159,30197]
dictorsetmaker [30277,30315]
===
match
---
argument [17790,17809]
argument [17908,17927]
===
match
---
name: utc [17929,17932]
name: utc [18047,18050]
===
match
---
arglist [44812,44882]
arglist [44930,45000]
===
match
---
name: proc [11581,11585]
name: proc [11597,11601]
===
match
---
operator: , [43369,43370]
operator: , [43487,43488]
===
match
---
trailer [12826,12848]
trailer [12842,12864]
===
match
---
name: expand [15998,16004]
name: expand [16014,16020]
===
match
---
name: serialized_dags [10008,10023]
name: serialized_dags [10024,10039]
===
match
---
operator: { [6015,6016]
operator: { [6031,6032]
===
match
---
trailer [16037,16070]
trailer [16053,16086]
===
match
---
name: models [1344,1350]
name: models [1360,1366]
===
match
---
classdef [33453,33639]
classdef [33571,33757]
===
match
---
comp_if [45538,45573]
comp_if [45656,45691]
===
match
---
atom [45461,45583]
atom [45579,45701]
===
match
---
name: test_deserialization_with_dag_context [17400,17437]
name: test_deserialization_with_dag_context [17518,17555]
===
match
---
string: 'ui_color' [2730,2740]
string: 'ui_color' [2746,2756]
===
match
---
trailer [16454,16458]
trailer [16470,16474]
===
match
---
operator: = [42414,42415]
operator: = [42532,42533]
===
match
---
expr_stmt [21628,21696]
expr_stmt [21746,21814]
===
match
---
argument [7742,7810]
argument [7758,7826]
===
match
---
atom_expr [37464,37490]
atom_expr [37582,37608]
===
match
---
string: "{'att1': '{{ task.task_id }}', 'att2': '{{ task.task_id }}', 'template_fields': ['att1']})" [30519,30611]
string: "{'att1': '{{ task.task_id }}', 'att2': '{{ task.task_id }}', 'template_fields': ['att1']})" [30637,30729]
===
match
---
operator: { [19297,19298]
operator: { [19415,19416]
===
match
---
dotted_name [41350,41370]
dotted_name [41468,41488]
===
match
---
name: catchup [7671,7678]
name: catchup [7687,7694]
===
match
---
name: dag [40925,40928]
name: dag [41043,41046]
===
match
---
name: self [24902,24906]
name: self [25020,25024]
===
match
---
name: BaseOperator [33320,33332]
name: BaseOperator [33438,33450]
===
match
---
trailer [25627,25681]
trailer [25745,25799]
===
match
---
name: deserialized_test_task [32253,32275]
name: deserialized_test_task [32371,32393]
===
match
---
string: "simple_task" [19050,19063]
string: "simple_task" [19168,19181]
===
match
---
string: 'task_5' [43892,43900]
string: 'task_5' [44010,44018]
===
match
---
atom_expr [9881,9906]
atom_expr [9897,9922]
===
match
---
name: template_fields [30818,30833]
name: template_fields [30936,30951]
===
match
---
operator: , [4701,4702]
operator: , [4717,4718]
===
match
---
param [20736,20744]
param [20854,20862]
===
match
---
name: mount_path [1949,1959]
name: mount_path [1965,1975]
===
match
---
name: to_dict [23430,23437]
name: to_dict [23548,23555]
===
match
---
name: dags [12116,12120]
name: dags [12132,12136]
===
match
---
trailer [37081,37092]
trailer [37199,37210]
===
match
---
string: 'tests.test_utils.mock_operators.CustomOpLink' [24051,24097]
string: 'tests.test_utils.mock_operators.CustomOpLink' [24169,24215]
===
match
---
name: SerializedDAG [37572,37585]
name: SerializedDAG [37690,37703]
===
match
---
atom_expr [10709,10733]
atom_expr [10725,10749]
===
match
---
string: 'task_5' [42900,42908]
string: 'task_5' [43018,43026]
===
match
---
name: utc [16189,16192]
name: utc [16205,16208]
===
match
---
string: 'k8s.V1Pod' [45756,45767]
string: 'k8s.V1Pod' [45874,45885]
===
match
---
name: check_task_group [38515,38531]
name: check_task_group [38633,38649]
===
match
---
name: setUp [9001,9006]
name: setUp [9017,9022]
===
match
---
name: task_end_date [18663,18676]
name: task_end_date [18781,18794]
===
match
---
expr_stmt [39793,39855]
expr_stmt [39911,39973]
===
match
---
name: json_dag [10114,10122]
name: json_dag [10130,10138]
===
match
---
expr_stmt [9881,9912]
expr_stmt [9897,9928]
===
match
---
name: expand [39450,39456]
name: expand [39568,39574]
===
match
---
string: 'tooltip' [2703,2712]
string: 'tooltip' [2719,2728]
===
match
---
string: "### Task Tutorial Documentation" [6747,6780]
string: "### Task Tutorial Documentation" [6763,6796]
===
match
---
name: task_id [33333,33340]
name: task_id [33451,33458]
===
match
---
simple_stmt [967,989]
simple_stmt [967,989]
===
match
---
operator: , [42666,42667]
operator: , [42784,42785]
===
match
---
atom [4002,4318]
atom [4018,4334]
===
match
---
fstring_string: ] does not match [13640,13656]
fstring_string: ] does not match [13656,13672]
===
match
---
number: 1 [38870,38871]
number: 1 [38988,38989]
===
match
---
name: validate_deserialized_task [14033,14059]
name: validate_deserialized_task [14049,14075]
===
match
---
name: default_args [6002,6014]
name: default_args [6018,6030]
===
match
---
operator: , [39495,39496]
operator: , [39613,39614]
===
match
---
trailer [16065,16069]
trailer [16081,16085]
===
match
---
operator: , [35305,35306]
operator: , [35423,35424]
===
match
---
name: v [11657,11658]
name: v [11673,11674]
===
match
---
atom_expr [10881,10984]
atom_expr [10897,11000]
===
match
---
string: 'doc_md' [34625,34633]
string: 'doc_md' [34743,34751]
===
match
---
name: start_date [18429,18439]
name: start_date [18547,18557]
===
match
---
operator: , [17905,17906]
operator: , [18023,18024]
===
match
---
atom_expr [44674,44696]
atom_expr [44792,44814]
===
match
---
simple_stmt [41978,42064]
simple_stmt [42096,42182]
===
match
---
atom_expr [16417,16459]
atom_expr [16433,16475]
===
match
---
name: level [44871,44876]
name: level [44989,44994]
===
match
---
dictorsetmaker [6808,6825]
dictorsetmaker [6824,6841]
===
match
---
operator: { [24204,24205]
operator: { [24322,24323]
===
match
---
name: c [45541,45542]
name: c [45659,45660]
===
match
---
funcdef [29055,29173]
funcdef [29173,29291]
===
match
---
atom [14423,14887]
atom [14439,14903]
===
match
---
string: 'all_success' [35737,35750]
string: 'all_success' [35855,35868]
===
match
---
trailer [27875,27887]
trailer [27993,28005]
===
match
---
dictorsetmaker [2606,2688]
dictorsetmaker [2622,2704]
===
match
---
string: 'github' [24233,24241]
string: 'github' [24351,24359]
===
match
---
atom [2828,2830]
atom [2844,2846]
===
match
---
simple_stmt [33975,34125]
simple_stmt [34093,34243]
===
match
---
atom [30132,30281]
atom [30250,30399]
===
match
---
atom_expr [39176,39227]
atom_expr [39294,39345]
===
match
---
operator: = [16681,16682]
operator: = [16799,16800]
===
match
---
trailer [9769,9775]
trailer [9785,9791]
===
match
---
atom_expr [18246,18258]
atom_expr [18364,18376]
===
match
---
expr_stmt [42159,42202]
expr_stmt [42277,42320]
===
match
---
trailer [15415,15425]
trailer [15431,15441]
===
match
---
name: children [38456,38464]
name: children [38574,38582]
===
match
---
expr_stmt [27092,27137]
expr_stmt [27210,27255]
===
match
---
operator: , [32093,32094]
operator: , [32211,32212]
===
match
---
operator: = [11867,11868]
operator: = [11883,11884]
===
match
---
operator: == [44424,44426]
operator: == [44542,44544]
===
match
---
name: from_dict [41243,41252]
name: from_dict [41361,41370]
===
match
---
name: Mock [9077,9081]
name: Mock [9093,9097]
===
match
---
atom_expr [27160,27188]
atom_expr [27278,27306]
===
match
---
dictorsetmaker [27777,27787]
dictorsetmaker [27895,27905]
===
match
---
name: name [24752,24756]
name: name [24870,24874]
===
match
---
simple_stmt [19559,19922]
simple_stmt [19677,20040]
===
match
---
name: SerializedDAG [40989,41002]
name: SerializedDAG [41107,41120]
===
match
---
number: 2019 [16279,16283]
number: 2019 [16295,16299]
===
match
---
name: to_json [12494,12501]
name: to_json [12510,12517]
===
match
---
operator: , [17831,17832]
operator: , [17949,17950]
===
match
---
name: dag [12502,12505]
name: dag [12518,12521]
===
match
---
operator: , [20372,20373]
operator: , [20490,20491]
===
match
---
name: from_dict [17248,17257]
name: from_dict [17366,17375]
===
match
---
name: DAG [7407,7410]
name: DAG [7423,7426]
===
match
---
trailer [13219,13226]
trailer [13235,13242]
===
match
---
name: patterns [8167,8175]
name: patterns [8183,8191]
===
match
---
atom [27619,27800]
atom [27737,27918]
===
match
---
dictorsetmaker [5297,5527]
dictorsetmaker [5313,5543]
===
match
---
name: days [19369,19373]
name: days [19487,19491]
===
match
---
trailer [33886,33899]
trailer [34004,34017]
===
match
---
expr_stmt [44353,44393]
expr_stmt [44471,44511]
===
match
---
atom_expr [18217,18259]
atom_expr [18335,18377]
===
match
---
funcdef [9568,10075]
funcdef [9584,10091]
===
match
---
atom [21865,21875]
atom [21983,21993]
===
match
---
operator: = [38127,38128]
operator: = [38245,38246]
===
match
---
name: expected_err_msg [25999,26015]
name: expected_err_msg [26117,26133]
===
match
---
operator: , [16326,16327]
operator: , [16342,16343]
===
match
---
operator: = [24448,24449]
operator: = [24566,24567]
===
match
---
name: task_id [16744,16751]
name: task_id [16862,16869]
===
match
---
trailer [23270,23313]
trailer [23388,23431]
===
match
---
arglist [30705,31095]
arglist [30823,31213]
===
match
---
name: self [25796,25800]
name: self [25914,25918]
===
match
---
return_stmt [29380,29418]
return_stmt [29498,29536]
===
match
---
simple_stmt [16731,16804]
simple_stmt [16849,16922]
===
match
---
name: serialized_dag [38532,38546]
name: serialized_dag [38650,38664]
===
match
---
name: passed_success_callback [40357,40380]
name: passed_success_callback [40475,40498]
===
match
---
operator: } [13622,13623]
operator: } [13638,13639]
===
match
---
trailer [8495,8506]
trailer [8511,8522]
===
match
---
comp_op [22415,22421]
comp_op [22533,22539]
===
match
---
operator: = [30976,30977]
operator: = [31094,31095]
===
match
---
operator: , [21259,21260]
operator: , [21377,21378]
===
match
---
operator: = [38854,38855]
operator: = [38972,38973]
===
match
---
testlist_comp [20662,20666]
testlist_comp [20780,20784]
===
match
---
name: test_extra_serialized_field_and_operator_links [22673,22719]
name: test_extra_serialized_field_and_operator_links [22791,22837]
===
match
---
number: 1 [38873,38874]
number: 1 [38991,38992]
===
match
---
string: "start_date" [17169,17181]
string: "start_date" [17287,17299]
===
match
---
param [12607,12612]
param [12623,12628]
===
match
---
string: 'airflow' [6650,6659]
string: 'airflow' [6666,6675]
===
match
---
operator: , [14482,14483]
operator: , [14498,14499]
===
match
---
operator: = [27096,27097]
operator: = [27214,27215]
===
match
---
operator: , [20476,20477]
operator: , [20594,20595]
===
match
---
trailer [45481,45484]
trailer [45599,45602]
===
match
---
number: 2019 [26804,26808]
number: 2019 [26922,26926]
===
match
---
trailer [45910,45928]
trailer [46028,46046]
===
match
---
operator: , [1067,1068]
operator: , [1083,1084]
===
match
---
suite [44476,46069]
suite [44594,46187]
===
match
---
string: 'task_4' [42978,42986]
string: 'task_4' [43096,43104]
===
match
---
atom_expr [24741,24756]
atom_expr [24859,24874]
===
match
---
string: 'simple_dag' [5980,5992]
string: 'simple_dag' [5996,6008]
===
match
---
name: round_tripped [20922,20935]
name: round_tripped [21040,21053]
===
match
---
operator: , [35402,35403]
operator: , [35520,35521]
===
match
---
operator: , [18199,18200]
operator: , [18317,18318]
===
match
---
atom_expr [21580,21619]
atom_expr [21698,21737]
===
match
---
string: "test_role" [10857,10868]
string: "test_role" [10873,10884]
===
match
---
name: end_date [19092,19100]
name: end_date [19210,19218]
===
match
---
operator: , [44069,44070]
operator: , [44187,44188]
===
match
---
name: v [13301,13302]
name: v [13317,13318]
===
match
---
operator: , [18114,18115]
operator: , [18232,18233]
===
match
---
factor [20293,20295]
factor [20411,20413]
===
match
---
atom_expr [33101,33123]
atom_expr [33219,33241]
===
match
---
operator: , [30199,30200]
operator: , [30317,30318]
===
match
---
expr_stmt [32253,32312]
expr_stmt [32371,32430]
===
match
---
simple_stmt [22248,22292]
simple_stmt [22366,22410]
===
match
---
name: from_json [11753,11762]
name: from_json [11769,11778]
===
match
---
string: "retry_delay" [3266,3279]
string: "retry_delay" [3282,3295]
===
match
---
operator: } [27702,27703]
operator: } [27820,27821]
===
match
---
operator: { [2028,2029]
operator: { [2044,2045]
===
match
---
name: DummyOperator [37236,37249]
name: DummyOperator [37354,37367]
===
match
---
name: deserialized_simple_task [21628,21652]
name: deserialized_simple_task [21746,21770]
===
match
---
atom_expr [7999,8035]
atom_expr [8015,8051]
===
match
---
operator: = [5818,5819]
operator: = [5834,5835]
===
match
---
atom_expr [32205,32244]
atom_expr [32323,32362]
===
match
---
arglist [21240,21271]
arglist [21358,21389]
===
match
---
atom_expr [37072,37092]
atom_expr [37190,37210]
===
match
---
operator: , [43484,43485]
operator: , [43602,43603]
===
match
---
string: "timedelta" [2256,2267]
string: "timedelta" [2272,2283]
===
match
---
atom_expr [10905,10970]
atom_expr [10921,10986]
===
match
---
name: pardir [5703,5709]
name: pardir [5719,5725]
===
match
---
operator: , [34903,34904]
operator: , [35021,35022]
===
match
---
operator: , [20245,20246]
operator: , [20363,20364]
===
match
---
simple_stmt [24165,24253]
simple_stmt [24283,24371]
===
match
---
arglist [16744,16802]
arglist [16862,16920]
===
match
---
operator: , [14233,14234]
operator: , [14249,14250]
===
match
---
atom_expr [7987,8036]
atom_expr [8003,8052]
===
match
---
operator: , [44594,44595]
operator: , [44712,44713]
===
match
---
trailer [14919,14929]
trailer [14935,14945]
===
match
---
expr_stmt [23399,23442]
expr_stmt [23517,23560]
===
match
---
comparison [18826,18877]
comparison [18944,18995]
===
match
---
operator: = [32823,32824]
operator: = [32941,32942]
===
match
---
name: expected_task_end_date [19104,19126]
name: expected_task_end_date [19222,19244]
===
match
---
operator: , [2630,2631]
operator: , [2646,2647]
===
match
---
trailer [30338,30456]
trailer [30456,30574]
===
match
---
trailer [13328,13330]
trailer [13344,13346]
===
match
---
trailer [35466,35474]
trailer [35584,35592]
===
match
---
arglist [13136,13157]
arglist [13152,13173]
===
match
---
assert_stmt [15235,15387]
assert_stmt [15251,15403]
===
match
---
operator: , [16628,16629]
operator: , [16746,16747]
===
match
---
string: 'github' [27999,28007]
string: 'github' [28117,28125]
===
match
---
param [25579,25586]
param [25697,25704]
===
match
---
operator: , [24359,24360]
operator: , [24477,24478]
===
match
---
atom_expr [11455,11545]
atom_expr [11471,11561]
===
match
---
operator: , [14293,14294]
operator: , [14309,14310]
===
match
---
atom_expr [46007,46068]
atom_expr [46125,46186]
===
match
---
number: 1 [19355,19356]
number: 1 [19473,19474]
===
match
---
simple_stmt [23399,23443]
simple_stmt [23517,23561]
===
match
---
name: xcom_push [24335,24344]
name: xcom_push [24453,24462]
===
match
---
string: 'k8s.V1Pod' [4153,4164]
string: 'k8s.V1Pod' [4169,4180]
===
match
---
argument [42108,42115]
argument [42226,42233]
===
match
---
string: "bar" [43405,43410]
string: "bar" [43523,43528]
===
match
---
name: start_date [16696,16706]
name: start_date [16814,16824]
===
match
---
string: "ui_color" [3519,3529]
string: "ui_color" [3535,3545]
===
match
---
operator: , [14750,14751]
operator: , [14766,14767]
===
match
---
name: utc [18047,18050]
name: utc [18165,18168]
===
match
---
funcdef [40308,41344]
funcdef [40426,41462]
===
match
---
string: 'BigQuery Console #1' [27906,27927]
string: 'BigQuery Console #1' [28024,28045]
===
match
---
suite [8200,8366]
suite [8216,8382]
===
match
---
operator: , [44869,44870]
operator: , [44987,44988]
===
match
---
import_from [38749,38793]
import_from [38867,38911]
===
match
---
number: 1 [36805,36806]
number: 1 [36923,36924]
===
match
---
atom_expr [25660,25680]
atom_expr [25778,25798]
===
match
---
string: "task3" [37151,37158]
string: "task3" [37269,37276]
===
match
---
string: "on_success_callback" [40209,40230]
string: "on_success_callback" [40327,40348]
===
match
---
string: "default_args" [2071,2085]
string: "default_args" [2087,2101]
===
match
---
name: collect_dags [11869,11881]
name: collect_dags [11885,11897]
===
match
---
operator: = [16179,16180]
operator: = [16195,16196]
===
match
---
name: datetime [17818,17826]
name: datetime [17936,17944]
===
match
---
operator: , [6225,6226]
operator: , [6241,6242]
===
match
---
operator: } [43582,43583]
operator: } [43700,43701]
===
match
---
atom_expr [19080,19100]
atom_expr [19198,19218]
===
match
---
operator: , [19764,19765]
operator: , [19882,19883]
===
match
---
name: dag [13840,13843]
name: dag [13856,13859]
===
match
---
atom_expr [6070,6090]
atom_expr [6086,6106]
===
match
---
operator: } [43833,43834]
operator: } [43951,43952]
===
match
---
operator: } [21056,21057]
operator: } [21174,21175]
===
match
---
name: queue [11408,11413]
name: queue [11424,11429]
===
match
---
arglist [15302,15313]
arglist [15318,15329]
===
match
---
operator: == [14930,14932]
operator: == [14946,14948]
===
match
---
operator: = [25861,25862]
operator: = [25979,25980]
===
match
---
string: "depends_on_past" [2158,2175]
string: "depends_on_past" [2174,2191]
===
match
---
atom_expr [13674,13702]
atom_expr [13690,13718]
===
match
---
dictorsetmaker [20479,20531]
dictorsetmaker [20597,20649]
===
match
---
dictorsetmaker [29819,29846]
dictorsetmaker [29937,29964]
===
match
---
operator: , [35833,35834]
operator: , [35951,35952]
===
match
---
name: super [33563,33568]
name: super [33681,33686]
===
match
---
operator: } [43130,43131]
operator: } [43248,43249]
===
match
---
assert_stmt [39381,39429]
assert_stmt [39499,39547]
===
match
---
name: dag [39416,39419]
name: dag [39534,39537]
===
match
---
name: ACTION_CAN_READ [6368,6383]
name: ACTION_CAN_READ [6384,6399]
===
match
---
name: realpath [5679,5687]
name: realpath [5695,5703]
===
match
---
comparison [15820,15854]
comparison [15836,15870]
===
match
---
assert_stmt [37645,37686]
assert_stmt [37763,37804]
===
match
---
testlist_comp [28150,28182]
testlist_comp [28268,28300]
===
match
---
name: params [21808,21814]
name: params [21926,21932]
===
match
---
while_stmt [11633,11853]
while_stmt [11649,11869]
===
match
---
argument [16675,16694]
argument [16793,16812]
===
match
---
atom [34441,34443]
atom [34559,34561]
===
match
---
operator: , [43953,43954]
operator: , [44071,44072]
===
match
---
name: self [12607,12611]
name: self [12623,12627]
===
match
---
name: dag [7401,7404]
name: dag [7417,7420]
===
match
---
name: user_defined_filters [7601,7621]
name: user_defined_filters [7617,7637]
===
match
---
operator: } [30198,30199]
operator: } [30316,30317]
===
match
---
operator: { [30217,30218]
operator: { [30335,30336]
===
match
---
decorator [15983,16551]
decorator [15999,16669]
===
match
---
operator: = [39817,39818]
operator: = [39935,39936]
===
match
---
trailer [41010,41015]
trailer [41128,41133]
===
match
---
trailer [18225,18259]
trailer [18343,18377]
===
match
---
name: GoogleLink [24741,24751]
name: GoogleLink [24859,24869]
===
match
---
testlist_comp [21011,21057]
testlist_comp [21129,21175]
===
match
---
name: serialized_task [14904,14919]
name: serialized_task [14920,14935]
===
match
---
name: get_task [13821,13829]
name: get_task [13837,13845]
===
match
---
string: 'simple_task' [18514,18527]
string: 'simple_task' [18632,18645]
===
match
---
string: "key:" [43381,43387]
string: "key:" [43499,43505]
===
match
---
trailer [13309,13322]
trailer [13325,13338]
===
match
---
dotted_name [38754,38780]
dotted_name [38872,38898]
===
match
---
name: mock__import__ [44940,44954]
name: mock__import__ [45058,45072]
===
match
---
simple_stmt [15867,15914]
simple_stmt [15883,15930]
===
match
---
atom [31015,31023]
atom [31133,31141]
===
match
---
name: dag [14012,14015]
name: dag [14028,14031]
===
match
---
operator: , [26811,26812]
operator: , [26929,26930]
===
match
---
number: 8 [16373,16374]
number: 8 [16389,16390]
===
match
---
simple_stmt [41055,41113]
simple_stmt [41173,41231]
===
match
---
trailer [39913,39917]
trailer [40031,40035]
===
match
---
operator: , [43963,43964]
operator: , [44081,44082]
===
match
---
atom [43915,43925]
atom [44033,44043]
===
match
---
operator: , [43989,43990]
operator: , [44107,44108]
===
match
---
expr_stmt [25950,25986]
expr_stmt [26068,26104]
===
match
---
name: v [13550,13551]
name: v [13566,13567]
===
match
---
testlist_comp [29546,29556]
testlist_comp [29664,29674]
===
match
---
name: test_kubernetes_optional [44449,44473]
name: test_kubernetes_optional [44567,44591]
===
match
---
trailer [37750,37761]
trailer [37868,37879]
===
match
---
string: "dict" [2111,2117]
string: "dict" [2127,2133]
===
match
---
operator: = [32086,32087]
operator: = [32204,32205]
===
match
---
trailer [33610,33623]
trailer [33728,33741]
===
match
---
operator: { [30225,30226]
operator: { [30343,30344]
===
match
---
atom_expr [17892,17933]
atom_expr [18010,18051]
===
match
---
string: 'email_on_failure' [34739,34757]
string: 'email_on_failure' [34857,34875]
===
match
---
operator: , [43890,43891]
operator: , [44008,44009]
===
match
---
atom_expr [13264,13280]
atom_expr [13280,13296]
===
match
---
atom_expr [15874,15913]
atom_expr [15890,15929]
===
match
---
operator: , [35371,35372]
operator: , [35489,35490]
===
match
---
name: deps [40130,40134]
name: deps [40248,40252]
===
match
---
number: 0 [24005,24006]
number: 0 [24123,24124]
===
match
---
number: 2019 [32023,32027]
number: 2019 [32141,32145]
===
match
---
name: util [45149,45153]
name: util [45267,45271]
===
match
---
name: proc [11554,11558]
name: proc [11570,11574]
===
match
---
operator: = [16706,16707]
operator: = [16824,16825]
===
match
---
trailer [37197,37214]
trailer [37315,37332]
===
match
---
string: "airflow" [3209,3218]
string: "airflow" [3225,3234]
===
match
---
operator: { [6355,6356]
operator: { [6371,6372]
===
match
---
simple_stmt [20806,20836]
simple_stmt [20924,20954]
===
match
---
name: timedelta [35457,35466]
name: timedelta [35575,35584]
===
match
---
fstring_start: f' [13213,13215]
fstring_start: f' [13229,13231]
===
match
---
string: "airflow.operators.bash" [3901,3925]
string: "airflow.operators.bash" [3917,3941]
===
match
---
operator: , [29164,29165]
operator: , [29282,29283]
===
match
---
string: 'run_as_user' [35536,35549]
string: 'run_as_user' [35654,35667]
===
match
---
name: from_dict [25912,25921]
name: from_dict [26030,26039]
===
match
---
argument [24298,24322]
argument [24416,24440]
===
match
---
operator: , [43394,43395]
operator: , [43512,43513]
===
match
---
simple_stmt [32134,32178]
simple_stmt [32252,32296]
===
match
---
string: "tasks" [18947,18954]
string: "tasks" [19065,19072]
===
match
---
name: ACTION_CAN_READ [5448,5463]
name: ACTION_CAN_READ [5464,5479]
===
match
---
name: Label [39008,39013]
name: Label [39126,39131]
===
match
---
operator: , [35707,35708]
operator: , [35825,35826]
===
match
---
operator: { [20284,20285]
operator: { [20402,20403]
===
match
---
string: "has_on_failure_callback" [42249,42274]
string: "has_on_failure_callback" [42367,42392]
===
match
---
expr_stmt [16665,16722]
expr_stmt [16783,16840]
===
match
---
with_item [36964,36997]
with_item [37082,37115]
===
match
---
simple_stmt [26885,26963]
simple_stmt [27003,27081]
===
match
---
trailer [18874,18877]
trailer [18992,18995]
===
match
---
trailer [18018,18051]
trailer [18136,18169]
===
match
---
string: "__var" [2409,2416]
string: "__var" [2425,2432]
===
match
---
expr_stmt [1735,1989]
expr_stmt [1751,2005]
===
match
---
string: "Operator Link class 'tests.serialization.test_dag_serialization.TaskStateLink' " [26036,26117]
string: "Operator Link class 'tests.serialization.test_dag_serialization.TaskStateLink' " [26154,26235]
===
match
---
string: "att1" [30835,30841]
string: "att1" [30953,30959]
===
match
---
string: """Just a DummyOperator using above defined Extra Operator Link""" [25427,25493]
string: """Just a DummyOperator using above defined Extra Operator Link""" [25545,25611]
===
match
---
string: 'bash_task' [2606,2617]
string: 'bash_task' [2622,2633]
===
match
---
name: self [39577,39581]
name: self [39695,39699]
===
match
---
operator: , [4957,4958]
operator: , [4973,4974]
===
match
---
operator: , [18230,18231]
operator: , [18348,18349]
===
match
---
atom [2619,2644]
atom [2635,2660]
===
match
---
name: airflow [1271,1278]
name: airflow [1287,1294]
===
match
---
name: models [1113,1119]
name: models [1129,1135]
===
match
---
string: "airflow/providers/*/example_dags" [12242,12276]
string: "airflow/providers/*/example_dags" [12258,12292]
===
match
---
name: patterns [8385,8393]
name: patterns [8401,8409]
===
match
---
name: tzinfo [17515,17521]
name: tzinfo [17633,17639]
===
match
---
operator: , [21999,22000]
operator: , [22117,22118]
===
match
---
operator: = [25265,25266]
operator: = [25383,25384]
===
match
---
expr_stmt [23261,23313]
expr_stmt [23379,23431]
===
match
---
funcdef [33914,36527]
funcdef [34032,36645]
===
match
---
expr_stmt [37555,37635]
expr_stmt [37673,37753]
===
match
---
operator: , [27251,27252]
operator: , [27369,27370]
===
match
---
string: 'dummy' [33341,33348]
string: 'dummy' [33459,33466]
===
match
---
string: "sla" [2378,2383]
string: "sla" [2394,2399]
===
match
---
operator: { [21872,21873]
operator: { [21990,21991]
===
match
---
trailer [28802,28807]
trailer [28920,28925]
===
match
---
operator: , [18023,18024]
operator: , [18141,18142]
===
match
---
atom [43780,43834]
atom [43898,43952]
===
match
---
number: 8 [16093,16094]
number: 8 [16109,16110]
===
match
---
number: 2019 [21346,21350]
number: 2019 [21464,21468]
===
match
---
expr_stmt [40791,40876]
expr_stmt [40909,40994]
===
match
---
string: 'task_4' [42823,42831]
string: 'task_4' [42941,42949]
===
match
---
operator: , [18527,18528]
operator: , [18645,18646]
===
match
---
name: TaskStateLink [25128,25141]
name: TaskStateLink [25246,25259]
===
match
---
suite [37814,38506]
suite [37932,38624]
===
match
---
operator: , [40278,40279]
operator: , [40396,40397]
===
match
---
atom_expr [16386,16398]
atom_expr [16402,16414]
===
match
---
dictorsetmaker [4024,4300]
dictorsetmaker [4040,4316]
===
match
---
name: import_mock [45511,45522]
name: import_mock [45629,45640]
===
match
---
atom_expr [9072,9502]
atom_expr [9088,9518]
===
match
---
name: att1 [30764,30768]
name: att1 [30882,30886]
===
match
---
testlist_comp [11514,11543]
testlist_comp [11530,11559]
===
match
---
atom_expr [9022,9037]
atom_expr [9038,9053]
===
match
---
name: level [44638,44643]
name: level [44756,44761]
===
match
---
operator: } [4298,4299]
operator: } [4314,4315]
===
match
---
string: 'downstream_task_ids' [2921,2942]
string: 'downstream_task_ids' [2937,2958]
===
match
---
operator: { [29810,29811]
operator: { [29928,29929]
===
match
---
funcdef [21959,22664]
funcdef [22077,22782]
===
match
---
name: SerializedBaseOperator [39872,39894]
name: SerializedBaseOperator [39990,40012]
===
match
---
string: "that" [43549,43555]
string: "that" [43667,43673]
===
match
---
operator: , [34415,34416]
operator: , [34533,34534]
===
match
---
atom [19209,19244]
atom [19327,19362]
===
match
---
expr_stmt [28473,28556]
expr_stmt [28591,28674]
===
match
---
name: serialized_dag [21604,21618]
name: serialized_dag [21722,21736]
===
match
---
simple_stmt [9606,9686]
simple_stmt [9622,9702]
===
match
---
operator: , [40261,40262]
operator: , [40379,40380]
===
match
---
name: extra_links [24188,24199]
name: extra_links [24306,24317]
===
match
---
atom_expr [38808,38876]
atom_expr [38926,38994]
===
match
---
string: 'simple_dag' [21247,21259]
string: 'simple_dag' [21365,21377]
===
match
---
name: val [21423,21426]
name: val [21541,21544]
===
match
---
operator: , [35678,35679]
operator: , [35796,35797]
===
match
---
trailer [11752,11762]
trailer [11768,11778]
===
match
---
operator: = [10734,10735]
operator: = [10750,10751]
===
match
---
simple_stmt [44726,44776]
simple_stmt [44844,44894]
===
match
---
simple_stmt [44402,44443]
simple_stmt [44520,44561]
===
match
---
operator: , [6182,6183]
operator: , [6198,6199]
===
match
---
operator: } [30197,30198]
operator: } [30315,30316]
===
match
---
atom_expr [17979,17991]
atom_expr [18097,18109]
===
match
---
trailer [21345,21357]
trailer [21463,21475]
===
match
---
param [12629,12632]
param [12645,12648]
===
match
---
trailer [39130,39146]
trailer [39248,39264]
===
match
---
name: serialized_dag [37555,37569]
name: serialized_dag [37673,37687]
===
match
---
operator: , [19219,19220]
operator: , [19337,19338]
===
match
---
trailer [8874,8879]
trailer [8890,8895]
===
match
---
operator: , [34484,34485]
operator: , [34602,34603]
===
match
---
dictorsetmaker [29766,29793]
dictorsetmaker [29884,29911]
===
match
---
assert_stmt [42242,42299]
assert_stmt [42360,42417]
===
match
---
name: dag [16852,16855]
name: dag [16970,16973]
===
match
---
string: "y" [43984,43987]
string: "y" [44102,44105]
===
match
---
name: relativedelta [20451,20464]
name: relativedelta [20569,20582]
===
match
---
trailer [10920,10939]
trailer [10936,10955]
===
match
---
param [29074,29082]
param [29192,29200]
===
match
---
exprlist [29101,29111]
exprlist [29219,29229]
===
match
---
name: extra [9136,9141]
name: extra [9152,9157]
===
match
---
assert_stmt [24165,24252]
assert_stmt [24283,24370]
===
match
---
string: "__var" [20275,20282]
string: "__var" [20393,20400]
===
match
---
string: "bar" [29859,29864]
string: "bar" [29977,29982]
===
match
---
name: do_xcom_push [33350,33362]
name: do_xcom_push [33468,33480]
===
match
---
operator: , [17810,17811]
operator: , [17928,17929]
===
match
---
for_stmt [9753,9913]
for_stmt [9769,9929]
===
match
---
name: doc_md [6740,6746]
name: doc_md [6756,6762]
===
match
---
operator: , [16224,16225]
operator: , [16240,16241]
===
match
---
comparison [44313,44339]
comparison [44431,44457]
===
match
---
simple_stmt [8466,8508]
simple_stmt [8482,8524]
===
match
---
dictorsetmaker [24051,24101]
dictorsetmaker [24169,24219]
===
match
---
atom_expr [36916,36946]
atom_expr [37034,37064]
===
match
---
name: serialized_dag [21459,21473]
name: serialized_dag [21577,21591]
===
match
---
name: airflow [1336,1343]
name: airflow [1352,1359]
===
match
---
operator: = [21336,21337]
operator: = [21454,21455]
===
match
---
operator: = [9740,9741]
operator: = [9756,9757]
===
match
---
string: 'custom_task' [5188,5201]
string: 'custom_task' [5204,5217]
===
match
---
operator: , [34280,34281]
operator: , [34398,34399]
===
match
---
operator: } [27787,27788]
operator: } [27905,27906]
===
match
---
dictorsetmaker [5389,5494]
dictorsetmaker [5405,5510]
===
match
---
operator: == [13703,13705]
operator: == [13719,13721]
===
match
---
name: dag [36891,36894]
name: dag [37009,37012]
===
match
---
atom [2868,2870]
atom [2884,2886]
===
match
---
name: Process [11471,11478]
name: Process [11487,11494]
===
match
---
atom [3128,5227]
atom [3144,5243]
===
match
---
name: json_dag [37429,37437]
name: json_dag [37547,37555]
===
match
---
operator: , [34956,34957]
operator: , [35074,35075]
===
match
---
operator: { [13215,13216]
operator: { [13231,13232]
===
match
---
string: "{{ task.task_id }}" [29773,29793]
string: "{{ task.task_id }}" [29891,29911]
===
match
---
atom_expr [28753,28808]
atom_expr [28871,28926]
===
match
---
suite [22015,22664]
suite [22133,22782]
===
match
---
operator: { [15349,15350]
operator: { [15365,15366]
===
match
---
argument [30705,30864]
argument [30823,30982]
===
match
---
number: 1 [2211,2212]
number: 1 [2227,2228]
===
match
---
string: '10' [34952,34956]
string: '10' [35070,35074]
===
match
---
operator: { [45732,45733]
operator: { [45850,45851]
===
match
---
name: args [45477,45481]
name: args [45595,45599]
===
match
---
string: "{{ task.task_id }}" [29675,29695]
string: "{{ task.task_id }}" [29793,29813]
===
match
---
expr_stmt [11657,11672]
expr_stmt [11673,11688]
===
match
---
parameters [29353,29366]
parameters [29471,29484]
===
match
---
simple_stmt [17228,17274]
simple_stmt [17346,17392]
===
match
---
operator: , [40286,40287]
operator: , [40404,40405]
===
match
---
atom_expr [23416,23442]
atom_expr [23534,23560]
===
match
---
operator: , [23245,23246]
operator: , [23363,23364]
===
match
---
operator: } [20667,20668]
operator: } [20785,20786]
===
match
---
trailer [6545,6791]
trailer [6561,6807]
===
match
---
number: 7 [18172,18173]
number: 7 [18290,18291]
===
match
---
string: "tasks" [27579,27586]
string: "tasks" [27697,27704]
===
match
---
name: dag [8621,8624]
name: dag [8637,8640]
===
match
---
name: parameterized [29501,29514]
name: parameterized [29619,29632]
===
match
---
operator: = [17493,17494]
operator: = [17611,17612]
===
match
---
expr_stmt [32805,32992]
expr_stmt [32923,33110]
===
match
---
trailer [15011,15027]
trailer [15027,15043]
===
match
---
name: simple_task [19080,19091]
name: simple_task [19198,19209]
===
match
---
assert_stmt [21507,21551]
assert_stmt [21625,21669]
===
match
---
name: serialized_dag [21530,21544]
name: serialized_dag [21648,21662]
===
match
---
assert_stmt [15940,15977]
assert_stmt [15956,15993]
===
match
---
operator: } [40277,40278]
operator: } [40395,40396]
===
match
---
name: x [10790,10791]
name: x [10806,10807]
===
match
---
operator: = [33735,33736]
operator: = [33853,33854]
===
match
---
expr_stmt [9046,9502]
expr_stmt [9062,9518]
===
match
---
import_name [900,915]
import_name [900,915]
===
match
---
atom_expr [38532,38557]
atom_expr [38650,38675]
===
match
---
funcdef [17396,17718]
funcdef [17514,17836]
===
match
---
name: ROOT_FOLDER [5606,5617]
name: ROOT_FOLDER [5622,5633]
===
match
---
name: MyOperator [25389,25399]
name: MyOperator [25507,25517]
===
match
---
operator: = [23277,23278]
operator: = [23395,23396]
===
match
---
expr_stmt [41210,41268]
expr_stmt [41328,41386]
===
match
---
dotted_name [17724,17744]
dotted_name [17842,17862]
===
match
---
argument [32003,32034]
argument [32121,32152]
===
match
---
atom [6807,6826]
atom [6823,6842]
===
match
---
suite [8106,8141]
suite [8122,8157]
===
match
---
atom [29615,29659]
atom [29733,29777]
===
match
---
operator: = [6430,6431]
operator: = [6446,6447]
===
match
---
operator: = [22114,22115]
operator: = [22232,22233]
===
match
---
trailer [17530,17534]
trailer [17648,17652]
===
match
---
string: 'simple_dag' [6808,6820]
string: 'simple_dag' [6824,6836]
===
match
---
if_stmt [8042,8366]
if_stmt [8058,8382]
===
match
---
name: importlib [835,844]
name: importlib [835,844]
===
match
---
arglist [39810,39854]
arglist [39928,39972]
===
match
---
name: children [37678,37686]
name: children [37796,37804]
===
match
---
operator: { [29850,29851]
operator: { [29968,29969]
===
match
---
name: pod_override [45717,45729]
name: pod_override [45835,45847]
===
match
---
atom_expr [12198,12355]
atom_expr [12214,12371]
===
match
---
atom [29858,29887]
atom [29976,30005]
===
match
---
if_stmt [22300,22456]
if_stmt [22418,22574]
===
match
---
import_name [828,844]
import_name [828,844]
===
match
---
name: start_date [42117,42127]
name: start_date [42235,42245]
===
match
---
atom [27776,27788]
atom [27894,27906]
===
match
---
simple_stmt [14327,14365]
simple_stmt [14343,14381]
===
match
---
atom [43944,43989]
atom [44062,44107]
===
match
---
name: node [38314,38318]
name: node [38432,38436]
===
match
---
operator: = [18414,18415]
operator: = [18532,18533]
===
match
---
simple_stmt [45442,45584]
simple_stmt [45560,45702]
===
match
---
atom [12853,13070]
atom [12869,13086]
===
match
---
trailer [22436,22443]
trailer [22554,22561]
===
match
---
funcdef [10080,11104]
funcdef [10096,11120]
===
match
---
atom [30189,30196]
atom [30307,30314]
===
match
---
dictorsetmaker [27634,27703]
dictorsetmaker [27752,27821]
===
match
---
string: """         Assert extra field exists & OperatorLinks defined in Plugins and inbuilt Operator Links.          This tests also depends on GoogleLink() registered as a plugin         in tests/plugins/test_plugin.py          The function tests that if extra operator links are registered in plugin         in ``operator_extra_links`` and the same is also defined in         the Operator in ``BaseOperator.operator_extra_links``, it has the correct         extra link.         """ [22735,23211]
string: """         Assert extra field exists & OperatorLinks defined in Plugins and inbuilt Operator Links.          This tests also depends on GoogleLink() registered as a plugin         in tests/plugins/test_plugin.py          The function tests that if extra operator links are registered in plugin         in ``operator_extra_links`` and the same is also defined in         the Operator in ``BaseOperator.operator_extra_links``, it has the correct         extra link.         """ [22853,23329]
===
match
---
operator: , [39836,39837]
operator: , [39954,39955]
===
match
---
operator: , [19319,19320]
operator: , [19437,19438]
===
match
---
comp_op [15843,15849]
comp_op [15859,15865]
===
match
---
trailer [21406,21411]
trailer [21524,21529]
===
match
---
name: utc [16115,16118]
name: utc [16131,16134]
===
match
---
parameters [17437,17443]
parameters [17555,17561]
===
match
---
if_stmt [15762,15978]
if_stmt [15778,15994]
===
match
---
atom_expr [1757,1989]
atom_expr [1773,2005]
===
match
---
string: "test1" [43754,43761]
string: "test1" [43872,43879]
===
match
---
assert_stmt [15113,15183]
assert_stmt [15129,15199]
===
match
---
string: "__type" [43468,43476]
string: "__type" [43586,43594]
===
match
---
operator: , [21119,21120]
operator: , [21237,21238]
===
match
---
operator: , [16286,16287]
operator: , [16302,16303]
===
match
---
atom_expr [19036,19064]
atom_expr [19154,19182]
===
match
---
arglist [7718,7828]
arglist [7734,7844]
===
match
---
argument [28068,28084]
argument [28186,28202]
===
match
---
trailer [12550,12571]
trailer [12566,12587]
===
match
---
name: template_fields [15012,15027]
name: template_fields [15028,15043]
===
match
---
dictorsetmaker [29932,29959]
dictorsetmaker [30050,30077]
===
match
---
operator: , [11519,11520]
operator: , [11535,11536]
===
match
---
simple_stmt [10398,10697]
simple_stmt [10414,10713]
===
match
---
comparison [16891,16924]
comparison [17009,17042]
===
match
---
name: tzinfo [18119,18125]
name: tzinfo [18237,18243]
===
match
---
name: task_end_date [18547,18560]
name: task_end_date [18665,18678]
===
match
---
operator: = [6014,6015]
operator: = [6030,6031]
===
match
---
atom_expr [9701,9715]
atom_expr [9717,9731]
===
match
---
trailer [20887,20899]
trailer [21005,21017]
===
match
---
name: isinstance [14278,14288]
name: isinstance [14294,14304]
===
match
---
atom_expr [39798,39855]
atom_expr [39916,39973]
===
match
---
trailer [28764,28780]
trailer [28882,28898]
===
match
---
operator: = [23585,23586]
operator: = [23703,23704]
===
match
---
atom_expr [9765,9777]
atom_expr [9781,9793]
===
match
---
name: datetime [36790,36798]
name: datetime [36908,36916]
===
match
---
string: 'dummy' [39818,39825]
string: 'dummy' [39936,39943]
===
match
---
name: super [9022,9027]
name: super [9038,9043]
===
match
---
name: serialized_dag [18571,18585]
name: serialized_dag [18689,18703]
===
match
---
atom [20312,20409]
atom [20430,20527]
===
match
---
string: "__type" [20613,20621]
string: "__type" [20731,20739]
===
match
---
simple_stmt [15113,15184]
simple_stmt [15129,15200]
===
match
---
simple_stmt [39771,39784]
simple_stmt [39889,39902]
===
match
---
trailer [18448,18460]
trailer [18566,18578]
===
match
---
name: PodGenerator [1253,1265]
name: PodGenerator [1269,1281]
===
match
---
simple_stmt [7987,8037]
simple_stmt [8003,8053]
===
match
---
argument [17839,17858]
argument [17957,17976]
===
match
---
operator: , [43982,43983]
operator: , [44100,44101]
===
match
---
testlist_comp [30022,30102]
testlist_comp [30140,30220]
===
match
---
string: "dummy_value_2" [28167,28182]
string: "dummy_value_2" [28285,28300]
===
match
---
argument [16744,16765]
argument [16862,16883]
===
match
---
simple_stmt [13121,13252]
simple_stmt [13137,13268]
===
match
---
operator: , [35612,35613]
operator: , [35730,35731]
===
match
---
operator: , [1707,1708]
operator: , [1723,1724]
===
match
---
comparison [39388,39429]
comparison [39506,39547]
===
match
---
name: dag [22110,22113]
name: dag [22228,22231]
===
match
---
operator: , [30626,30627]
operator: , [30744,30745]
===
match
---
atom_expr [25702,25728]
atom_expr [25820,25846]
===
match
---
operator: , [16076,16077]
operator: , [16092,16093]
===
match
---
name: pod_override [45939,45951]
name: pod_override [46057,46069]
===
match
---
operator: == [11950,11952]
operator: == [11966,11968]
===
match
---
name: timezone [16298,16306]
name: timezone [16314,16322]
===
match
---
suite [9778,9913]
suite [9794,9929]
===
match
---
string: "__var" [5327,5334]
string: "__var" [5343,5350]
===
match
---
argument [16776,16802]
argument [16894,16920]
===
match
---
operator: , [23650,23651]
operator: , [23768,23769]
===
match
---
simple_stmt [17333,17391]
simple_stmt [17451,17509]
===
match
---
string: 'default_pool' [35262,35276]
string: 'default_pool' [35380,35394]
===
match
---
atom_expr [34398,34415]
atom_expr [34516,34533]
===
match
---
trailer [18407,18484]
trailer [18525,18602]
===
match
---
string: "weekday" [20516,20525]
string: "weekday" [20634,20643]
===
match
---
trailer [37394,37410]
trailer [37512,37528]
===
match
---
operator: = [11620,11621]
operator: = [11636,11637]
===
match
---
name: dag [12405,12408]
name: dag [12421,12424]
===
match
---
name: FR [20604,20606]
name: FR [20722,20724]
===
match
---
operator: , [41465,41466]
operator: , [41583,41584]
===
match
---
trailer [13169,13211]
trailer [13185,13227]
===
match
---
arglist [25628,25680]
arglist [25746,25798]
===
match
---
parameters [33509,33545]
parameters [33627,33663]
===
match
---
simple_stmt [37848,37882]
simple_stmt [37966,38000]
===
match
---
operator: , [30118,30119]
operator: , [30236,30237]
===
match
---
simple_stmt [11448,11546]
simple_stmt [11464,11562]
===
match
---
comparison [11688,11697]
comparison [11704,11713]
===
match
---
name: dag [18533,18536]
name: dag [18651,18654]
===
match
---
operator: , [2048,2049]
operator: , [2064,2065]
===
match
---
operator: { [21035,21036]
operator: { [21153,21154]
===
match
---
name: dag [21321,21324]
name: dag [21439,21442]
===
match
---
trailer [17123,17132]
trailer [17241,17250]
===
match
---
operator: , [12941,12942]
operator: , [12957,12958]
===
match
---
name: imported_airflow [45619,45635]
name: imported_airflow [45737,45753]
===
match
---
name: mock [44894,44898]
name: mock [45012,45016]
===
match
---
name: util [862,866]
name: util [862,866]
===
match
---
expr_stmt [33648,33680]
expr_stmt [33766,33798]
===
match
---
name: mode [39583,39587]
name: mode [39701,39705]
===
match
---
operator: , [5463,5464]
operator: , [5479,5480]
===
match
---
dictorsetmaker [7623,7660]
dictorsetmaker [7639,7676]
===
match
---
string: "10" [34170,34174]
string: "10" [34288,34292]
===
match
---
atom_expr [22484,22523]
atom_expr [22602,22641]
===
match
---
number: 2 [16288,16289]
number: 2 [16304,16305]
===
match
---
atom_expr [28260,28321]
atom_expr [28378,28439]
===
match
---
atom_expr [16358,16399]
atom_expr [16374,16415]
===
match
---
operator: , [33534,33535]
operator: , [33652,33653]
===
match
---
name: SerializedBaseOperator [33807,33829]
name: SerializedBaseOperator [33925,33947]
===
match
---
string: "test" [32305,32311]
string: "test" [32423,32429]
===
match
---
dictorsetmaker [19298,19337]
dictorsetmaker [19416,19455]
===
match
---
name: dag_dict [39147,39155]
name: dag_dict [39265,39273]
===
match
---
for_stmt [12015,12130]
for_stmt [12031,12146]
===
match
---
trailer [23497,23506]
trailer [23615,23624]
===
match
---
simple_stmt [9791,9822]
simple_stmt [9807,9838]
===
match
---
string: "__type" [44313,44321]
string: "__type" [44431,44439]
===
match
---
atom_expr [38855,38875]
atom_expr [38973,38993]
===
match
---
simple_stmt [37645,37687]
simple_stmt [37763,37805]
===
match
---
testlist_comp [40207,40287]
testlist_comp [40325,40405]
===
match
---
trailer [27079,27082]
trailer [27197,27200]
===
match
---
strings [26036,26150]
strings [26154,26268]
===
match
---
name: expected_output [44093,44108]
name: expected_output [44211,44226]
===
match
---
name: test_roundtrip_provider_example_dags [12139,12175]
name: test_roundtrip_provider_example_dags [12155,12191]
===
match
---
expr_stmt [11603,11624]
expr_stmt [11619,11640]
===
match
---
atom [42947,42987]
atom [43065,43105]
===
match
---
atom_expr [18157,18199]
atom_expr [18275,18317]
===
match
---
simple_stmt [37997,38089]
simple_stmt [38115,38207]
===
match
---
operator: , [14098,14099]
operator: , [14114,14115]
===
match
---
operator: , [35339,35340]
operator: , [35457,35458]
===
match
---
trailer [32681,32696]
trailer [32799,32814]
===
match
---
name: CustomOperator [1693,1707]
name: CustomOperator [1709,1723]
===
match
---
operator: , [13032,13033]
operator: , [13048,13049]
===
match
---
operator: , [15306,15307]
operator: , [15322,15323]
===
match
---
trailer [7850,7857]
trailer [7866,7873]
===
match
---
name: keys [33116,33120]
name: keys [33234,33238]
===
match
---
string: "@weekly" [19221,19230]
string: "@weekly" [19339,19348]
===
match
---
name: pytest [45863,45869]
name: pytest [45981,45987]
===
match
---
testlist_comp [42581,44005]
testlist_comp [42699,44123]
===
match
---
trailer [8890,8894]
trailer [8906,8910]
===
match
---
name: expected_task_start_date [17366,17390]
name: expected_task_start_date [17484,17508]
===
match
---
argument [23271,23290]
argument [23389,23408]
===
match
---
string: "tasks" [10725,10732]
string: "tasks" [10741,10748]
===
match
---
string: "{{ task.task_id }}" [30365,30385]
string: "{{ task.task_id }}" [30483,30503]
===
match
---
arglist [17960,17991]
arglist [18078,18109]
===
match
---
operator: = [30391,30392]
operator: = [30509,30510]
===
match
---
simple_stmt [33299,33444]
simple_stmt [33417,33562]
===
match
---
atom_expr [28495,28556]
atom_expr [28613,28674]
===
match
---
name: _ [37180,37181]
name: _ [37298,37299]
===
match
---
funcdef [29182,29271]
funcdef [29300,29389]
===
match
---
name: from_json [39190,39199]
name: from_json [39308,39317]
===
match
---
atom_expr [24172,24200]
atom_expr [24290,24318]
===
match
---
name: resources [15568,15577]
name: resources [15584,15593]
===
match
---
atom_expr [23232,23252]
atom_expr [23350,23370]
===
match
---
simple_stmt [38897,38936]
simple_stmt [39015,39054]
===
match
---
name: serialized_dag [41091,41105]
name: serialized_dag [41209,41223]
===
match
---
number: 8 [17907,17908]
number: 8 [18025,18026]
===
match
---
name: module_path [5827,5838]
name: module_path [5843,5854]
===
match
---
comparison [15400,15433]
comparison [15416,15449]
===
match
---
string: 'task_1' [42658,42666]
string: 'task_1' [42776,42784]
===
match
---
simple_stmt [36773,36811]
simple_stmt [36891,36929]
===
match
---
name: test_dag_on_success_callback_roundtrip [40312,40350]
name: test_dag_on_success_callback_roundtrip [40430,40468]
===
match
---
with_item [5960,6477]
with_item [5976,6493]
===
match
---
number: 4 [20528,20529]
number: 4 [20646,20647]
===
match
---
atom_expr [26830,26876]
atom_expr [26948,26994]
===
match
---
dictorsetmaker [43353,43411]
dictorsetmaker [43471,43529]
===
match
---
parameters [10368,10384]
parameters [10384,10400]
===
match
---
atom [30031,30060]
atom [30149,30178]
===
match
---
comparison [21712,21751]
comparison [21830,21869]
===
match
---
atom [42599,42639]
atom [42717,42757]
===
match
---
simple_stmt [25427,25494]
simple_stmt [25545,25612]
===
match
---
name: SerializedBaseOperator [14235,14257]
name: SerializedBaseOperator [14251,14273]
===
match
---
operator: , [34376,34377]
operator: , [34494,34495]
===
match
---
atom [27691,27703]
atom [27809,27821]
===
match
---
atom_expr [13306,13330]
atom_expr [13322,13346]
===
match
---
operator: , [18139,18140]
operator: , [18257,18258]
===
match
---
operator: = [42111,42112]
operator: = [42229,42230]
===
match
---
operator: = [39080,39081]
operator: = [39198,39199]
===
match
---
trailer [7998,8036]
trailer [8014,8052]
===
match
---
name: DummyOperator [38905,38918]
name: DummyOperator [39023,39036]
===
match
---
operator: , [13607,13608]
operator: , [13623,13624]
===
match
---
assert_stmt [24516,24603]
assert_stmt [24634,24721]
===
match
---
atom [19297,19338]
atom [19415,19456]
===
match
---
operator: } [29599,29600]
operator: } [29717,29718]
===
match
---
trailer [13709,13718]
trailer [13725,13734]
===
match
---
trailer [24334,24344]
trailer [24452,24462]
===
match
---
operator: , [11799,11800]
operator: , [11815,11816]
===
match
---
string: "timezone" [19811,19821]
string: "timezone" [19929,19939]
===
match
---
name: multiprocessing [11416,11431]
name: multiprocessing [11432,11447]
===
match
---
trailer [40129,40134]
trailer [40247,40252]
===
match
---
operator: = [42092,42093]
operator: = [42210,42211]
===
match
---
expr_stmt [37335,37372]
expr_stmt [37453,37490]
===
match
---
name: utc [16455,16458]
name: utc [16471,16474]
===
match
---
name: dag [13748,13751]
name: dag [13764,13767]
===
match
---
trailer [33120,33122]
trailer [33238,33240]
===
match
---
operator: , [4590,4591]
operator: , [4606,4607]
===
match
---
name: expected_dict [38393,38406]
name: expected_dict [38511,38524]
===
match
---
number: 3 [43912,43913]
number: 3 [44030,44031]
===
match
---
trailer [8632,8638]
trailer [8648,8654]
===
match
---
trailer [40151,40156]
trailer [40269,40274]
===
match
---
trailer [23638,23667]
trailer [23756,23785]
===
match
---
assert_stmt [20033,20091]
assert_stmt [20151,20209]
===
match
---
name: self [29155,29159]
name: self [29273,29277]
===
match
---
operator: == [33215,33217]
operator: == [33333,33335]
===
match
---
name: poke_interval [39838,39851]
name: poke_interval [39956,39969]
===
match
---
argument [1847,1980]
argument [1863,1996]
===
match
---
operator: , [6236,6237]
operator: , [6252,6253]
===
match
---
operator: , [19672,19673]
operator: , [19790,19791]
===
match
---
operator: = [22169,22170]
operator: = [22287,22288]
===
match
---
atom [2321,2360]
atom [2337,2376]
===
match
---
simple_stmt [38307,38319]
simple_stmt [38425,38437]
===
match
---
funcdef [12135,12572]
funcdef [12151,12588]
===
match
---
atom_expr [13612,13622]
atom_expr [13628,13638]
===
match
---
name: resources [15485,15494]
name: resources [15501,15510]
===
match
---
trailer [5662,5670]
trailer [5678,5686]
===
match
---
parameters [33283,33289]
parameters [33401,33407]
===
match
---
funcdef [12577,14024]
funcdef [12593,14040]
===
match
---
operator: , [35474,35475]
operator: , [35592,35593]
===
match
---
operator: , [43661,43662]
operator: , [43779,43780]
===
match
---
operator: , [29889,29890]
operator: , [30007,30008]
===
match
---
name: dag_id [18408,18414]
name: dag_id [18526,18532]
===
match
---
operator: } [29267,29268]
operator: } [29385,29386]
===
match
---
atom [43708,43762]
atom [43826,43880]
===
match
---
testlist_comp [21866,21874]
testlist_comp [21984,21992]
===
match
---
atom_expr [28120,28184]
atom_expr [28238,28302]
===
match
---
string: '.' [45491,45494]
string: '.' [45609,45612]
===
match
---
arglist [17827,17858]
arglist [17945,17976]
===
match
---
dotted_name [1654,1685]
dotted_name [1670,1701]
===
match
---
arglist [12551,12570]
arglist [12567,12586]
===
match
---
name: parameterized [1153,1166]
name: parameterized [1169,1182]
===
match
---
operator: , [28147,28148]
operator: , [28265,28266]
===
match
---
string: "month" [20384,20391]
string: "month" [20502,20509]
===
match
---
name: dummy [38714,38719]
name: dummy [38832,38837]
===
match
---
operator: } [15362,15363]
operator: } [15378,15379]
===
match
---
name: ti [24262,24264]
name: ti [24380,24382]
===
match
---
operator: , [10767,10768]
operator: , [10783,10784]
===
match
---
name: k8s [1757,1760]
name: k8s [1773,1776]
===
match
---
name: set [34344,34347]
name: set [34462,34465]
===
match
---
atom [27244,27260]
atom [27362,27378]
===
match
---
number: 0 [44644,44645]
number: 0 [44762,44763]
===
match
---
number: 1 [3247,3248]
number: 1 [3263,3264]
===
match
---
trailer [11795,11805]
trailer [11811,11821]
===
match
---
operator: { [40276,40277]
operator: { [40394,40395]
===
match
---
simple_stmt [17162,17219]
simple_stmt [17280,17337]
===
match
---
shift_expr [38999,39036]
shift_expr [39117,39154]
===
match
---
name: simple_task [27212,27223]
name: simple_task [27330,27341]
===
match
---
name: getattr [32346,32353]
name: getattr [32464,32471]
===
match
---
trailer [32294,32304]
trailer [32412,32422]
===
match
---
name: test_date [28288,28297]
name: test_date [28406,28415]
===
match
---
name: deserialized_dag [21561,21577]
name: deserialized_dag [21679,21695]
===
match
---
trailer [37863,37872]
trailer [37981,37990]
===
match
---
simple_stmt [23573,23616]
simple_stmt [23691,23734]
===
match
---
atom_expr [16671,16722]
atom_expr [16789,16840]
===
match
---
param [44638,44645]
param [44756,44763]
===
match
---
operator: , [21875,21876]
operator: , [21993,21994]
===
match
---
string: 'task_5' [42755,42763]
string: 'task_5' [42873,42881]
===
match
---
trailer [11478,11545]
trailer [11494,11561]
===
match
---
name: dag [13216,13219]
name: dag [13232,13235]
===
match
---
string: "pool" [3943,3949]
string: "pool" [3959,3965]
===
match
---
argument [5973,5992]
argument [5989,6008]
===
match
---
name: children [37762,37770]
name: children [37880,37888]
===
match
---
operator: == [11069,11071]
operator: == [11085,11087]
===
match
---
operator: { [6807,6808]
operator: { [6823,6824]
===
match
---
operator: = [37570,37571]
operator: = [37688,37689]
===
match
---
name: datetime [32014,32022]
name: datetime [32132,32140]
===
match
---
trailer [23336,23389]
trailer [23454,23507]
===
match
---
atom_expr [18186,18198]
atom_expr [18304,18316]
===
match
---
arglist [11796,11804]
arglist [11812,11820]
===
match
---
testlist_comp [41394,41474]
testlist_comp [41512,41592]
===
match
---
trailer [12479,12507]
trailer [12495,12523]
===
match
---
name: SerializedDAG [9834,9847]
name: SerializedDAG [9850,9863]
===
match
---
operator: = [25753,25754]
operator: = [25871,25872]
===
match
---
operator: } [29959,29960]
operator: } [30077,30078]
===
match
---
trailer [41002,41010]
trailer [41120,41128]
===
match
---
expr_stmt [37429,37491]
expr_stmt [37547,37609]
===
match
---
simple_stmt [37015,37050]
simple_stmt [37133,37168]
===
match
---
import_as_names [1693,1733]
import_as_names [1709,1749]
===
match
---
number: 8 [17833,17834]
number: 8 [17951,17952]
===
match
---
operator: = [23381,23382]
operator: = [23499,23500]
===
match
---
trailer [38811,38876]
trailer [38929,38994]
===
match
---
atom_expr [38019,38088]
atom_expr [38137,38206]
===
match
---
comparison [39969,39983]
comparison [40087,40101]
===
match
---
atom_expr [12823,12850]
atom_expr [12839,12866]
===
match
---
operator: = [45459,45460]
operator: = [45577,45578]
===
match
---
trailer [11834,11846]
trailer [11850,11862]
===
match
---
arglist [15885,15912]
arglist [15901,15928]
===
match
---
name: _ [9757,9758]
name: _ [9773,9774]
===
match
---
param [9007,9011]
param [9023,9027]
===
match
---
atom [9742,9744]
atom [9758,9760]
===
match
---
operator: , [43900,43901]
operator: , [44018,44019]
===
match
---
name: days [20336,20340]
name: days [20454,20458]
===
match
---
atom_expr [29253,29266]
atom_expr [29371,29384]
===
match
---
name: dags [11862,11866]
name: dags [11878,11882]
===
match
---
string: 'execution_timeout' [34843,34862]
string: 'execution_timeout' [34961,34980]
===
match
---
string: 'fileloc' [10235,10244]
string: 'fileloc' [10251,10260]
===
match
---
operator: = [37150,37151]
operator: = [37268,37269]
===
match
---
name: datetime [18098,18106]
name: datetime [18216,18224]
===
match
---
name: queue [11514,11519]
name: queue [11530,11535]
===
match
---
name: spec [45257,45261]
name: spec [45375,45379]
===
match
---
name: DAG [25624,25627]
name: DAG [25742,25745]
===
match
---
trailer [9983,10007]
trailer [9999,10023]
===
match
---
name: v [11763,11764]
name: v [11779,11780]
===
match
---
name: tzinfo [18179,18185]
name: tzinfo [18297,18303]
===
match
---
name: parameterized [42537,42550]
name: parameterized [42655,42668]
===
match
---
dictorsetmaker [20248,20296]
dictorsetmaker [20366,20414]
===
match
---
simple_stmt [10151,10204]
simple_stmt [10167,10220]
===
match
---
atom_expr [17797,17809]
atom_expr [17915,17927]
===
match
---
atom_expr [16078,16119]
atom_expr [16094,16135]
===
match
---
expr_stmt [39165,39227]
expr_stmt [39283,39345]
===
match
---
atom [29850,29888]
atom [29968,30006]
===
match
---
atom_expr [33807,33856]
atom_expr [33925,33974]
===
match
---
name: dag_id [9899,9905]
name: dag_id [9915,9921]
===
match
---
number: 2020 [38864,38868]
number: 2020 [38982,38986]
===
match
---
operator: , [34556,34557]
operator: , [34674,34675]
===
match
---
simple_stmt [37309,37326]
simple_stmt [37427,37444]
===
match
---
name: start_date [25649,25659]
name: start_date [25767,25777]
===
match
---
name: dag [23587,23590]
name: dag [23705,23708]
===
match
---
operator: , [42712,42713]
operator: , [42830,42831]
===
match
---
string: 'custom_task' [2674,2687]
string: 'custom_task' [2690,2703]
===
match
---
simple_stmt [38335,38407]
simple_stmt [38453,38525]
===
match
---
suite [24908,26218]
suite [25026,26336]
===
match
---
name: deserialized_simple_task [22532,22556]
name: deserialized_simple_task [22650,22674]
===
match
---
operator: } [7658,7659]
operator: } [7674,7675]
===
match
---
testlist_comp [43708,43835]
testlist_comp [43826,43953]
===
match
---
testlist_comp [19177,19378]
testlist_comp [19295,19496]
===
match
---
expr_stmt [5811,5839]
expr_stmt [5827,5855]
===
match
---
trailer [22360,22369]
trailer [22478,22487]
===
match
---
string: "dag" [23989,23994]
string: "dag" [24107,24112]
===
match
---
param [18336,18349]
param [18454,18467]
===
match
---
operator: , [39522,39523]
operator: , [39640,39641]
===
match
---
name: self [29476,29480]
name: self [29594,29598]
===
match
---
name: TestCase [8938,8946]
name: TestCase [8954,8962]
===
match
---
atom_expr [45225,45262]
atom_expr [45343,45380]
===
match
---
name: glob [972,976]
name: glob [972,976]
===
match
---
operator: , [2267,2268]
operator: , [2283,2284]
===
match
---
operator: = [32203,32204]
operator: = [32321,32322]
===
match
---
string: "task1" [38927,38934]
string: "task1" [39045,39052]
===
match
---
operator: = [36871,36872]
operator: = [36989,36990]
===
match
---
arglist [28523,28555]
arglist [28641,28673]
===
match
---
trailer [18609,18614]
trailer [18727,18732]
===
match
---
name: get_task [13844,13852]
name: get_task [13860,13868]
===
match
---
operator: , [28297,28298]
operator: , [28415,28416]
===
match
---
not_test [29472,29494]
not_test [29590,29612]
===
match
---
string: 'env' [3710,3715]
string: 'env' [3726,3731]
===
match
---
simple_stmt [24917,25113]
simple_stmt [25035,25231]
===
match
---
atom [20661,20667]
atom [20779,20785]
===
match
---
parameters [41537,41584]
parameters [41655,41702]
===
match
---
simple_stmt [28922,29046]
simple_stmt [29040,29164]
===
match
---
string: 'airflow' [24222,24231]
string: 'airflow' [24340,24349]
===
match
---
simple_stmt [40045,40111]
simple_stmt [40163,40229]
===
match
---
simple_stmt [7344,7397]
simple_stmt [7360,7413]
===
match
---
operator: , [44816,44817]
operator: , [44934,44935]
===
match
---
argument [20596,20609]
argument [20714,20727]
===
match
---
argument [42085,42106]
argument [42203,42224]
===
match
---
name: DummyOperator [37019,37032]
name: DummyOperator [37137,37150]
===
match
---
atom [19655,19686]
atom [19773,19804]
===
match
---
for_stmt [13079,13252]
for_stmt [13095,13268]
===
match
---
atom_expr [15120,15155]
atom_expr [15136,15171]
===
match
---
simple_stmt [23261,23314]
simple_stmt [23379,23432]
===
match
---
assert_stmt [24766,24824]
assert_stmt [24884,24942]
===
match
---
name: serialized_dag [21368,21382]
name: serialized_dag [21486,21500]
===
match
---
string: "{{ task.task_id }}" [29616,29636]
string: "{{ task.task_id }}" [29734,29754]
===
match
---
trailer [39365,39370]
trailer [39483,39488]
===
match
---
string: "_task_module" [5072,5086]
string: "_task_module" [5088,5102]
===
match
---
string: "sar" [30190,30195]
string: "sar" [30308,30313]
===
match
---
with_stmt [45858,45953]
with_stmt [45976,46071]
===
match
---
name: datetime [7374,7382]
name: datetime [7390,7398]
===
match
---
trailer [8033,8035]
trailer [8049,8051]
===
match
---
name: deserialized_dag [42397,42413]
name: deserialized_dag [42515,42531]
===
match
---
arglist [16426,16458]
arglist [16442,16474]
===
match
---
number: 8 [40956,40957]
number: 8 [41074,41075]
===
match
---
name: path [5645,5649]
name: path [5661,5665]
===
match
---
parameters [9006,9012]
parameters [9022,9028]
===
match
---
lambdef [7632,7660]
lambdef [7648,7676]
===
match
---
trailer [5649,5654]
trailer [5665,5670]
===
match
---
name: simple_task [23639,23650]
name: simple_task [23757,23768]
===
match
---
argument [18239,18258]
argument [18357,18376]
===
match
---
trailer [42189,42197]
trailer [42307,42315]
===
match
---
argument [25713,25727]
argument [25831,25845]
===
match
---
operator: , [4480,4481]
operator: , [4496,4497]
===
match
---
name: templated_field [31619,31634]
name: templated_field [31737,31752]
===
match
---
param [21121,21133]
param [21239,21251]
===
match
---
name: operators [36672,36681]
name: operators [36790,36799]
===
match
---
name: serialize_pod [45803,45816]
name: serialize_pod [45921,45934]
===
match
---
name: normalized_schedule_interval [20111,20139]
name: normalized_schedule_interval [20229,20257]
===
match
---
operator: , [17782,17783]
operator: , [17900,17901]
===
match
---
name: daemon [11559,11565]
name: daemon [11575,11581]
===
match
---
name: task_type [14938,14947]
name: task_type [14954,14963]
===
match
---
string: "{{ task.task_id }}" [30392,30412]
string: "{{ task.task_id }}" [30510,30530]
===
match
---
operator: = [16105,16106]
operator: = [16121,16122]
===
match
---
dictorsetmaker [19656,19685]
dictorsetmaker [19774,19803]
===
match
---
fstring_string: ) [29268,29269]
fstring_string: ) [29386,29387]
===
match
---
trailer [15086,15104]
trailer [15102,15120]
===
match
---
name: dag [7859,7862]
name: dag [7875,7878]
===
match
---
suite [16656,17391]
suite [16774,17509]
===
match
---
atom [43380,43411]
atom [43498,43529]
===
match
---
assert_stmt [14200,14258]
assert_stmt [14216,14274]
===
match
---
number: 2019 [42137,42141]
number: 2019 [42255,42259]
===
match
---
atom_expr [16298,16310]
atom_expr [16314,16326]
===
match
---
name: dag [17296,17299]
name: dag [17414,17417]
===
match
---
string: "foo" [43109,43114]
string: "foo" [43227,43232]
===
match
---
trailer [29480,29487]
trailer [29598,29605]
===
match
---
name: DagBag [1310,1316]
name: DagBag [1326,1332]
===
match
---
fstring_start: f' [7645,7647]
fstring_start: f' [7661,7663]
===
match
---
operator: } [40253,40254]
operator: } [40371,40372]
===
match
---
name: dags [9765,9769]
name: dags [9781,9785]
===
match
---
name: default_args [7461,7473]
name: default_args [7477,7489]
===
match
---
testlist_comp [20313,20408]
testlist_comp [20431,20526]
===
match
---
name: self [9511,9515]
name: self [9527,9531]
===
match
---
expr_stmt [32186,32244]
expr_stmt [32304,32362]
===
match
---
atom [26018,26164]
atom [26136,26282]
===
match
---
comparison [22406,22455]
comparison [22524,22573]
===
match
---
string: "test2" [43736,43743]
string: "test2" [43854,43861]
===
match
---
operator: , [29557,29558]
operator: , [29675,29676]
===
match
---
raise_stmt [44726,44775]
raise_stmt [44844,44893]
===
match
---
testlist_comp [41463,41472]
testlist_comp [41581,41590]
===
match
---
string: 'default_args' [13018,13032]
string: 'default_args' [13034,13048]
===
match
---
string: "BashOperator" [3853,3867]
string: "BashOperator" [3869,3883]
===
match
---
operator: = [40795,40796]
operator: = [40913,40914]
===
match
---
operator: = [18972,18973]
operator: = [19090,19091]
===
match
---
operator: } [5603,5604]
operator: } [5619,5620]
===
match
---
dotted_name [42537,42557]
dotted_name [42655,42675]
===
match
---
operator: } [5561,5562]
operator: } [5577,5578]
===
match
---
simple_stmt [22532,22601]
simple_stmt [22650,22719]
===
match
---
atom [29809,29889]
atom [29927,30007]
===
match
---
string: """OperatorLink not registered via Plugins nor a built-in OperatorLink""" [25173,25246]
string: """OperatorLink not registered via Plugins nor a built-in OperatorLink""" [25291,25364]
===
match
---
name: dag [18968,18971]
name: dag [19086,19089]
===
match
---
name: BaseOperator [16731,16743]
name: BaseOperator [16849,16861]
===
match
---
operator: = [23344,23345]
operator: = [23462,23463]
===
match
---
operator: , [17933,17934]
operator: , [18051,18052]
===
match
---
operator: , [16765,16766]
operator: , [16883,16884]
===
match
---
atom_expr [32278,32312]
atom_expr [32396,32430]
===
match
---
argument [16099,16118]
argument [16115,16134]
===
match
---
name: task_id [6502,6509]
name: task_id [6518,6525]
===
match
---
atom_expr [14967,14998]
atom_expr [14983,15014]
===
match
---
atom_expr [45863,45890]
atom_expr [45981,46008]
===
match
---
comparison [15120,15183]
comparison [15136,15199]
===
match
---
operator: , [17837,17838]
operator: , [17955,17956]
===
match
---
atom_expr [12412,12425]
atom_expr [12428,12441]
===
match
---
expr_stmt [12439,12507]
expr_stmt [12455,12523]
===
match
---
param [19515,19543]
param [19633,19661]
===
match
---
name: __dict__ [29410,29418]
name: __dict__ [29528,29536]
===
match
---
name: utc [16066,16069]
name: utc [16082,16085]
===
match
---
name: kubernetes [1221,1231]
name: kubernetes [1237,1247]
===
match
---
dictorsetmaker [21891,21911]
dictorsetmaker [22009,22029]
===
match
---
expr_stmt [11733,11765]
expr_stmt [11749,11781]
===
match
---
operator: == [14009,14011]
operator: == [14025,14027]
===
match
---
name: models [1279,1285]
name: models [1295,1301]
===
match
---
operator: = [23265,23266]
operator: = [23383,23384]
===
match
---
if_stmt [44273,44394]
if_stmt [44391,44512]
===
match
---
decorated [39435,40157]
decorated [39553,40275]
===
match
---
suite [36572,38559]
suite [36690,38677]
===
match
---
string: 'task_5' [42833,42841]
string: 'task_5' [42951,42959]
===
match
---
atom_expr [17691,17717]
atom_expr [17809,17835]
===
match
---
atom [4776,4830]
atom [4792,4846]
===
match
---
operator: , [4518,4519]
operator: , [4534,4535]
===
match
---
argument [25856,25869]
argument [25974,25987]
===
match
---
name: node [38074,38078]
name: node [38192,38196]
===
match
---
trailer [38078,38086]
trailer [38196,38204]
===
match
---
trailer [37736,37741]
trailer [37854,37859]
===
match
---
trailer [16394,16398]
trailer [16410,16414]
===
match
---
number: 0 [45482,45483]
number: 0 [45600,45601]
===
match
---
simple_stmt [1450,1491]
simple_stmt [1466,1507]
===
match
---
trailer [21744,21751]
trailer [21862,21869]
===
match
---
fstring_string: . [15363,15364]
fstring_string: . [15379,15380]
===
match
---
name: serialized_task [15534,15549]
name: serialized_task [15550,15565]
===
match
---
name: ground_truth_dag [10124,10140]
name: ground_truth_dag [10140,10156]
===
match
---
name: serialized_dag [27049,27063]
name: serialized_dag [27167,27181]
===
match
---
dictorsetmaker [42745,42783]
dictorsetmaker [42863,42901]
===
match
---
operator: { [20515,20516]
operator: { [20633,20634]
===
match
---
operator: , [10122,10123]
operator: , [10138,10139]
===
match
---
name: airflow [36722,36729]
name: airflow [36840,36847]
===
match
---
string: "reschedule" [39510,39522]
string: "reschedule" [39628,39640]
===
match
---
trailer [8831,8833]
trailer [8847,8849]
===
match
---
expr_stmt [25738,25781]
expr_stmt [25856,25899]
===
match
---
return_stmt [29213,29270]
return_stmt [29331,29388]
===
match
---
operator: , [1986,1987]
operator: , [2002,2003]
===
match
---
operator: , [45494,45495]
operator: , [45612,45613]
===
match
---
operator: == [15560,15562]
operator: == [15576,15578]
===
match
---
name: spec [45271,45275]
name: spec [45389,45393]
===
match
---
trailer [12524,12550]
trailer [12540,12566]
===
match
---
name: datetime [16152,16160]
name: datetime [16168,16176]
===
match
---
simple_stmt [1649,1734]
simple_stmt [1665,1750]
===
match
---
name: dag_dict [37335,37343]
name: dag_dict [37453,37461]
===
match
---
name: timezone [18246,18254]
name: timezone [18364,18372]
===
match
---
name: dag [20107,20110]
name: dag [20225,20228]
===
match
---
atom [40275,40286]
atom [40393,40404]
===
match
---
argument [40930,40961]
argument [41048,41079]
===
match
---
operator: = [39796,39797]
operator: = [39914,39915]
===
match
---
name: to_dict [9811,9818]
name: to_dict [9827,9834]
===
match
---
trailer [29257,29266]
trailer [29375,29384]
===
match
---
atom_expr [42472,42512]
atom_expr [42590,42630]
===
match
---
name: dict [10379,10383]
name: dict [10395,10399]
===
match
---
operator: , [41473,41474]
operator: , [41591,41592]
===
match
---
suite [44647,44884]
suite [44765,45002]
===
match
---
simple_stmt [12439,12508]
simple_stmt [12455,12524]
===
match
---
name: datetime [16417,16425]
name: datetime [16433,16441]
===
match
---
name: SerializedDAG [37464,37477]
name: SerializedDAG [37582,37595]
===
match
---
name: path [5658,5662]
name: path [5674,5678]
===
match
---
trailer [37504,37530]
trailer [37622,37648]
===
match
---
operator: , [44926,44927]
operator: , [45044,45045]
===
match
---
param [33960,33964]
param [34078,34082]
===
match
---
operator: = [32276,32277]
operator: = [32394,32395]
===
match
---
atom_expr [9046,9069]
atom_expr [9062,9085]
===
match
---
name: test_templated_fields_exist_in_serialized_dag [31567,31612]
name: test_templated_fields_exist_in_serialized_dag [31685,31730]
===
match
---
operator: = [17468,17469]
operator: = [17586,17587]
===
match
---
trailer [31967,32035]
trailer [32085,32153]
===
match
---
trailer [25976,25983]
trailer [26094,26101]
===
match
---
parameters [39738,39753]
parameters [39856,39871]
===
match
---
simple_stmt [38423,38430]
simple_stmt [38541,38548]
===
match
---
name: ignored_keys [33126,33138]
name: ignored_keys [33244,33256]
===
match
---
operator: , [21324,21325]
operator: , [21442,21443]
===
match
---
simple_stmt [37381,37421]
simple_stmt [37499,37539]
===
match
---
string: "task3" [43709,43716]
string: "task3" [43827,43834]
===
match
---
trailer [16114,16118]
trailer [16130,16134]
===
match
---
name: val [21268,21271]
name: val [21386,21389]
===
match
---
trailer [27121,27137]
trailer [27239,27255]
===
match
---
simple_stmt [29213,29271]
simple_stmt [29331,29389]
===
match
---
simple_stmt [6800,6827]
simple_stmt [6816,6843]
===
match
---
operator: , [22233,22234]
operator: , [22351,22352]
===
match
---
suite [15514,15578]
suite [15530,15594]
===
match
---
atom [34374,34376]
atom [34492,34494]
===
match
---
operator: } [21935,21936]
operator: } [22053,22054]
===
match
---
operator: @ [42536,42537]
operator: @ [42654,42655]
===
match
---
trailer [10887,10984]
trailer [10903,11000]
===
match
---
string: "airflow/example_dags" [8234,8256]
string: "airflow/example_dags" [8250,8272]
===
match
---
atom_expr [24332,24377]
atom_expr [24450,24495]
===
match
---
arith_expr [12823,13070]
arith_expr [12839,13086]
===
match
---
name: dag_id [21240,21246]
name: dag_id [21358,21364]
===
match
---
operator: } [41440,41441]
operator: } [41558,41559]
===
match
---
operator: = [8594,8595]
operator: = [8610,8611]
===
match
---
trailer [37761,37770]
trailer [37879,37888]
===
match
---
name: custom_inbuilt_link [24584,24603]
name: custom_inbuilt_link [24702,24721]
===
match
---
operator: = [19570,19571]
operator: = [19688,19689]
===
match
---
operator: - [20242,20243]
operator: - [20360,20361]
===
match
---
fstring_string: . [15348,15349]
fstring_string: . [15364,15365]
===
match
---
name: compute_next_execution_date [7235,7262]
name: compute_next_execution_date [7251,7278]
===
match
---
name: self [19451,19455]
name: self [19569,19573]
===
match
---
name: self [29439,29443]
name: self [29557,29561]
===
match
---
trailer [17777,17810]
trailer [17895,17928]
===
match
---
name: json_dag [10300,10308]
name: json_dag [10316,10324]
===
match
---
operator: , [42628,42629]
operator: , [42746,42747]
===
match
---
dictorsetmaker [21036,21056]
dictorsetmaker [21154,21174]
===
match
---
argument [23292,23312]
argument [23410,23430]
===
match
---
name: timedelta [6123,6132]
name: timedelta [6139,6148]
===
match
---
name: isinstance [14207,14217]
name: isinstance [14223,14233]
===
match
---
testlist_comp [42599,42698]
testlist_comp [42717,42816]
===
match
---
name: self [17438,17442]
name: self [17556,17560]
===
match
---
trailer [17826,17859]
trailer [17944,17977]
===
match
---
name: set [11953,11956]
name: set [11969,11972]
===
match
---
operator: , [3630,3631]
operator: , [3646,3647]
===
match
---
operator: , [4830,4831]
operator: , [4846,4847]
===
match
---
name: args [11508,11512]
name: args [11524,11528]
===
match
---
assert_stmt [41278,41343]
assert_stmt [41396,41461]
===
match
---
string: "staging_schema" [43308,43324]
string: "staging_schema" [43426,43442]
===
match
---
name: dag [8605,8608]
name: dag [8621,8624]
===
match
---
operator: = [20859,20860]
operator: = [20977,20978]
===
match
---
parameters [36565,36571]
parameters [36683,36689]
===
match
---
operator: , [20334,20335]
operator: , [20452,20453]
===
match
---
atom [29673,29719]
atom [29791,29837]
===
match
---
assert_stmt [18819,18877]
assert_stmt [18937,18995]
===
match
---
atom [24050,24102]
atom [24168,24220]
===
match
---
trailer [1837,1986]
trailer [1853,2002]
===
match
---
name: children [37848,37856]
name: children [37966,37974]
===
match
---
argument [44836,44850]
argument [44954,44968]
===
match
---
name: task1 [38897,38902]
name: task1 [39015,39020]
===
match
---
name: serialized_task [15045,15060]
name: serialized_task [15061,15076]
===
match
---
simple_stmt [36908,36947]
simple_stmt [37026,37065]
===
match
---
atom_expr [15534,15559]
atom_expr [15550,15575]
===
match
---
string: '}' [9457,9460]
string: '}' [9473,9476]
===
match
---
name: loader [45276,45282]
name: loader [45394,45400]
===
match
---
name: self [12520,12524]
name: self [12536,12540]
===
match
---
expr_stmt [38897,38935]
expr_stmt [39015,39053]
===
match
---
name: default_args [7474,7486]
name: default_args [7490,7502]
===
match
---
atom_expr [9797,9821]
atom_expr [9813,9837]
===
match
---
operator: , [2424,2425]
operator: , [2440,2441]
===
match
---
name: is_paused_upon_creation [6287,6310]
name: is_paused_upon_creation [6303,6326]
===
match
---
operator: == [24201,24203]
operator: == [24319,24321]
===
match
---
string: 'outlets' [35169,35178]
string: 'outlets' [35287,35296]
===
match
---
trailer [32022,32034]
trailer [32140,32152]
===
match
---
param [29360,29365]
param [29478,29483]
===
match
---
operator: { [5004,5005]
operator: { [5020,5021]
===
match
---
atom [8091,8104]
atom [8107,8120]
===
match
---
operator: == [21780,21782]
operator: == [21898,21900]
===
match
---
simple_stmt [42072,42150]
simple_stmt [42190,42268]
===
match
---
atom_expr [38515,38558]
atom_expr [38633,38676]
===
match
---
operator: } [4393,4394]
operator: } [4409,4410]
===
match
---
operator: , [16399,16400]
operator: , [16415,16416]
===
match
---
operator: = [1959,1960]
operator: = [1975,1976]
===
match
---
funcdef [39551,40157]
funcdef [39669,40275]
===
match
---
name: task2 [38948,38953]
name: task2 [39066,39071]
===
match
---
trailer [20011,20023]
trailer [20129,20141]
===
match
---
arglist [40898,40961]
arglist [41016,41079]
===
match
---
assert_stmt [15813,15854]
assert_stmt [15829,15870]
===
match
---
number: 2 [20607,20608]
number: 2 [20725,20726]
===
match
---
operator: , [14073,14074]
operator: , [14089,14090]
===
match
---
number: 8 [18455,18456]
number: 8 [18573,18574]
===
match
---
testlist_comp [43034,43662]
testlist_comp [43152,43780]
===
match
---
simple_stmt [45271,45303]
simple_stmt [45389,45421]
===
match
---
trailer [9515,9523]
trailer [9531,9539]
===
match
---
operator: = [40059,40060]
operator: = [40177,40178]
===
match
---
dotted_name [1455,1471]
dotted_name [1471,1487]
===
match
---
operator: , [14112,14113]
operator: , [14128,14129]
===
match
---
name: SerializedDAG [32205,32218]
name: SerializedDAG [32323,32336]
===
match
---
name: DAG [18404,18407]
name: DAG [18522,18525]
===
match
---
param [21110,21115]
param [21228,21233]
===
match
---
name: serialized_dag [12613,12627]
name: serialized_dag [12629,12643]
===
match
---
string: '10' [35703,35707]
string: '10' [35821,35825]
===
match
---
name: self [10108,10112]
name: self [10124,10128]
===
match
---
name: node [37808,37812]
name: node [37926,37930]
===
match
---
arglist [23337,23388]
arglist [23455,23506]
===
match
---
dictorsetmaker [29851,29887]
dictorsetmaker [29969,30005]
===
match
---
string: "tasks" [23996,24003]
string: "tasks" [24114,24121]
===
match
---
trailer [8824,8831]
trailer [8840,8847]
===
match
---
name: dag_schema [33105,33115]
name: dag_schema [33223,33233]
===
match
---
simple_stmt [14897,14948]
simple_stmt [14913,14964]
===
match
---
argument [17913,17932]
argument [18031,18050]
===
match
---
argument [6326,6414]
argument [6342,6430]
===
match
---
expr_stmt [8209,8365]
expr_stmt [8225,8381]
===
match
---
operator: , [27985,27986]
operator: , [28103,28104]
===
match
---
name: from_dict [21594,21603]
name: from_dict [21712,21721]
===
match
---
operator: , [34763,34764]
operator: , [34881,34882]
===
match
---
trailer [13688,13697]
trailer [13704,13713]
===
match
---
dictorsetmaker [29735,29762]
dictorsetmaker [29853,29880]
===
match
---
atom [29972,30001]
atom [30090,30119]
===
match
---
simple_stmt [11862,11906]
simple_stmt [11878,11922]
===
match
---
simple_stmt [28565,28655]
simple_stmt [28683,28773]
===
match
---
string: "that" [43183,43189]
string: "that" [43301,43307]
===
match
---
dictorsetmaker [29859,29886]
dictorsetmaker [29977,30004]
===
match
---
argument [22206,22237]
argument [22324,22355]
===
match
---
name: start_date [38844,38854]
name: start_date [38962,38972]
===
match
---
name: execution_date [7323,7337]
name: execution_date [7339,7353]
===
match
---
operator: ** [33536,33538]
operator: ** [33654,33656]
===
match
---
string: "param_1" [21915,21924]
string: "param_1" [22033,22042]
===
match
---
factor [10257,10259]
factor [10273,10275]
===
match
---
operator: { [33035,33036]
operator: { [33153,33154]
===
match
---
number: 2019 [17778,17782]
number: 2019 [17896,17900]
===
match
---
operator: = [25720,25721]
operator: = [25838,25839]
===
match
---
decorated [29500,32394]
decorated [29618,32512]
===
match
---
operator: , [31634,31635]
operator: , [31752,31753]
===
match
---
string: 'simple_task' [42093,42106]
string: 'simple_task' [42211,42224]
===
match
---
operator: , [36803,36804]
operator: , [36921,36922]
===
match
---
comp_op [18837,18843]
comp_op [18955,18961]
===
match
---
trailer [44231,44242]
trailer [44349,44360]
===
match
---
string: "value_1" [21047,21056]
string: "value_1" [21165,21174]
===
match
---
operator: { [32825,32826]
operator: { [32943,32944]
===
match
---
comparison [27860,28040]
comparison [27978,28158]
===
match
---
operator: , [2672,2673]
operator: , [2688,2689]
===
match
---
name: timezone [18038,18046]
name: timezone [18156,18164]
===
match
---
operator: , [6277,6278]
operator: , [6293,6294]
===
match
---
name: permissions [6356,6367]
name: permissions [6372,6383]
===
match
---
operator: , [19230,19231]
operator: , [19348,19349]
===
match
---
param [29068,29073]
param [29186,29191]
===
match
---
for_stmt [8809,8881]
for_stmt [8825,8897]
===
match
---
name: validate_deserialized_dag [12525,12550]
name: validate_deserialized_dag [12541,12566]
===
match
---
operator: , [3724,3725]
operator: , [3740,3741]
===
match
---
dictorsetmaker [6342,6413]
dictorsetmaker [6358,6429]
===
match
---
if_stmt [13261,13658]
if_stmt [13277,13674]
===
match
---
param [44093,44108]
param [44211,44226]
===
match
---
name: dag [17540,17543]
name: dag [17658,17661]
===
match
---
simple_stmt [20845,20900]
simple_stmt [20963,21018]
===
match
---
trailer [29323,29331]
trailer [29441,29449]
===
match
---
suite [42229,42300]
suite [42347,42418]
===
match
---
dictorsetmaker [43101,43130]
dictorsetmaker [43219,43248]
===
match
---
argument [1819,1986]
argument [1835,2002]
===
match
---
operator: , [17788,17789]
operator: , [17906,17907]
===
match
---
operator: = [18245,18246]
operator: = [18363,18364]
===
match
---
string: "__var" [10870,10877]
string: "__var" [10886,10893]
===
match
---
trailer [18955,18958]
trailer [19073,19076]
===
match
---
dictorsetmaker [32839,32982]
dictorsetmaker [32957,33100]
===
match
---
name: get_serialized_fields [14397,14418]
name: get_serialized_fields [14413,14434]
===
match
---
operator: , [42618,42619]
operator: , [42736,42737]
===
match
---
funcdef [10343,11013]
funcdef [10359,11029]
===
match
---
string: "dag" [19614,19619]
string: "dag" [19732,19737]
===
match
---
name: datetime [18010,18018]
name: datetime [18128,18136]
===
match
---
operator: { [20612,20613]
operator: { [20730,20731]
===
match
---
number: 3 [43975,43976]
number: 3 [44093,44094]
===
match
---
name: module_from_spec [45240,45256]
name: module_from_spec [45358,45374]
===
match
---
trailer [29127,29129]
trailer [29245,29247]
===
match
---
argument [20237,20244]
argument [20355,20362]
===
match
---
operator: = [30893,30894]
operator: = [31011,31012]
===
match
---
simple_stmt [10709,10801]
simple_stmt [10725,10817]
===
match
---
atom_expr [11869,11905]
atom_expr [11885,11921]
===
match
---
trailer [29121,29127]
trailer [29239,29245]
===
match
---
atom_expr [29223,29246]
atom_expr [29341,29364]
===
match
---
atom [21011,21033]
atom [21129,21151]
===
match
---
name: BaseOperator [42072,42084]
name: BaseOperator [42190,42202]
===
match
---
name: to_dict [32165,32172]
name: to_dict [32283,32290]
===
match
---
funcdef [44026,44443]
funcdef [44144,44561]
===
match
---
name: serialized_dag [40972,40986]
name: serialized_dag [41090,41104]
===
match
---
name: set [33101,33104]
name: set [33219,33222]
===
match
---
trailer [5963,6470]
trailer [5979,6486]
===
match
---
comparison [14904,14947]
comparison [14920,14963]
===
match
---
name: serialized_dags [9724,9739]
name: serialized_dags [9740,9755]
===
match
---
string: "tasks" [32864,32871]
string: "tasks" [32982,32989]
===
match
---
testlist_comp [42600,42638]
testlist_comp [42718,42756]
===
match
---
operator: = [40905,40906]
operator: = [41023,41024]
===
match
---
trailer [22575,22585]
trailer [22693,22703]
===
match
---
operator: , [24487,24488]
operator: , [24605,24606]
===
match
---
name: start_date [22206,22216]
name: start_date [22324,22334]
===
match
---
operator: } [29793,29794]
operator: } [29911,29912]
===
match
---
name: globals_ [44596,44604]
name: globals_ [44714,44722]
===
match
---
number: 4 [20662,20663]
number: 4 [20780,20781]
===
match
---
atom [17754,18285]
atom [17872,18403]
===
match
---
operator: , [4164,4165]
operator: , [4180,4181]
===
match
---
if_stmt [16865,17219]
if_stmt [16983,17337]
===
match
---
operator: , [44850,44851]
operator: , [44968,44969]
===
match
---
expr_stmt [21230,21272]
expr_stmt [21348,21390]
===
match
---
name: tests [1654,1659]
name: tests [1670,1675]
===
match
---
argument [37250,37265]
argument [37368,37383]
===
match
---
arglist [17778,17809]
arglist [17896,17927]
===
match
---
comparison [20040,20091]
comparison [20158,20209]
===
match
---
string: 'task_2' [42968,42976]
string: 'task_2' [43086,43094]
===
match
---
operator: } [29887,29888]
operator: } [30005,30006]
===
match
---
operator: , [4560,4561]
operator: , [4576,4577]
===
match
---
simple_stmt [14129,14192]
simple_stmt [14145,14208]
===
match
---
name: to_dict [27003,27010]
name: to_dict [27121,27128]
===
match
---
name: default_args [7344,7356]
name: default_args [7360,7372]
===
match
---
arglist [6559,6781]
arglist [6575,6797]
===
match
---
trailer [33115,33120]
trailer [33233,33238]
===
match
---
operator: = [34169,34170]
operator: = [34287,34288]
===
match
---
simple_stmt [27024,27083]
simple_stmt [27142,27201]
===
match
---
suite [21135,21815]
suite [21253,21933]
===
match
---
atom [42567,44015]
atom [42685,44133]
===
match
---
name: fields_to_check [13092,13107]
name: fields_to_check [13108,13123]
===
match
---
simple_stmt [33083,33167]
simple_stmt [33201,33285]
===
match
---
arglist [13187,13197]
arglist [13203,13213]
===
match
---
trailer [45876,45890]
trailer [45994,46008]
===
match
---
operator: = [8778,8779]
operator: = [8794,8795]
===
match
---
name: parameterized [41350,41363]
name: parameterized [41468,41481]
===
match
---
trailer [37142,37159]
trailer [37260,37277]
===
match
---
trailer [10758,10767]
trailer [10774,10783]
===
match
---
simple_stmt [9881,9913]
simple_stmt [9897,9929]
===
match
---
operator: = [24700,24701]
operator: = [24818,24819]
===
match
---
operator: , [28007,28008]
operator: , [28125,28126]
===
match
---
simple_stmt [32321,32394]
simple_stmt [32439,32512]
===
match
---
operator: , [45767,45768]
operator: , [45885,45886]
===
match
---
arglist [13806,13861]
arglist [13822,13877]
===
match
---
suite [8154,8191]
suite [8170,8207]
===
match
---
trailer [15163,15183]
trailer [15179,15199]
===
match
---
string: "{{ task.task_id }}" [30080,30100]
string: "{{ task.task_id }}" [30198,30218]
===
match
---
string: "'att2': '{{ task.task_id }}', 'template_fields': ['att1']}), " [31264,31327]
string: "'att2': '{{ task.task_id }}', 'template_fields': ['att1']}), " [31382,31445]
===
match
---
operator: = [44216,44217]
operator: = [44334,44335]
===
match
---
assert_stmt [44402,44442]
assert_stmt [44520,44560]
===
match
---
operator: = [33033,33034]
operator: = [33151,33152]
===
match
---
name: DAG [26830,26833]
name: DAG [26948,26951]
===
match
---
trailer [24751,24756]
trailer [24869,24874]
===
match
---
operator: = [5979,5980]
operator: = [5995,5996]
===
match
---
expr_stmt [8589,8662]
expr_stmt [8605,8678]
===
match
---
funcdef [29280,29334]
funcdef [29398,29452]
===
match
---
atom_expr [5671,5697]
atom_expr [5687,5713]
===
match
---
name: executor_config_pod [4230,4249]
name: executor_config_pod [4246,4265]
===
match
---
fstring_expr [13637,13640]
fstring_expr [13653,13656]
===
match
---
name: name [24502,24506]
name: name [24620,24624]
===
match
---
trailer [30919,31045]
trailer [31037,31163]
===
match
---
name: level [25856,25861]
name: level [25974,25979]
===
match
---
name: os [5671,5673]
name: os [5687,5689]
===
match
---
operator: } [30060,30061]
operator: } [30178,30179]
===
match
---
name: fields_to_check [15206,15221]
name: fields_to_check [15222,15237]
===
match
---
name: expected_n_schedule_interval [20143,20171]
name: expected_n_schedule_interval [20261,20289]
===
match
---
operator: = [11566,11567]
operator: = [11582,11583]
===
match
---
string: 'CornflowerBlue' [2742,2758]
string: 'CornflowerBlue' [2758,2774]
===
match
---
arglist [11479,11544]
arglist [11495,11560]
===
match
---
atom_expr [25966,25986]
atom_expr [26084,26104]
===
match
---
operator: , [29659,29660]
operator: , [29777,29778]
===
match
---
arglist [1934,1967]
arglist [1950,1983]
===
match
---
expr_stmt [14374,14887]
expr_stmt [14390,14903]
===
match
---
string: 'task_5' [42958,42966]
string: 'task_5' [43076,43084]
===
match
---
operator: == [15495,15497]
operator: == [15511,15513]
===
match
---
operator: , [16230,16231]
operator: , [16246,16247]
===
match
---
operator: { [34231,34232]
operator: { [34349,34350]
===
match
---
arglist [16161,16192]
arglist [16177,16208]
===
match
---
operator: , [19727,19728]
operator: , [19845,19846]
===
match
---
funcdef [11109,12130]
funcdef [11125,12146]
===
match
---
import_from [1208,1265]
import_from [1224,1281]
===
match
---
suite [28913,29495]
suite [29031,29613]
===
match
---
atom [39466,39540]
atom [39584,39658]
===
match
---
operator: , [44834,44835]
operator: , [44952,44953]
===
match
---
name: DAG [22116,22119]
name: DAG [22234,22237]
===
match
---
name: default_args [13268,13280]
name: default_args [13284,13296]
===
match
---
atom [29531,31552]
atom [29649,31670]
===
match
---
name: timezone [18126,18134]
name: timezone [18244,18252]
===
match
---
trailer [10245,10251]
trailer [10261,10267]
===
match
---
operator: { [21890,21891]
operator: { [22008,22009]
===
match
---
name: __eq__ [29481,29487]
name: __eq__ [29599,29605]
===
match
---
comparison [13674,13723]
comparison [13690,13739]
===
match
---
atom_expr [41429,41440]
atom_expr [41547,41558]
===
match
---
trailer [42439,42455]
trailer [42557,42573]
===
match
---
atom_expr [7964,7981]
atom_expr [7980,7997]
===
match
---
name: serialized_dag [18925,18939]
name: serialized_dag [19043,19057]
===
match
---
atom [7516,7591]
atom [7532,7607]
===
match
---
atom_expr [37859,37881]
atom_expr [37977,37999]
===
match
---
factor [20242,20244]
factor [20360,20362]
===
match
---
name: dags [8466,8470]
name: dags [8482,8486]
===
match
---
atom_expr [17522,17534]
atom_expr [17640,17652]
===
match
---
atom_expr [11581,11593]
atom_expr [11597,11609]
===
match
---
trailer [45561,45573]
trailer [45679,45691]
===
match
---
operator: , [12330,12331]
operator: , [12346,12347]
===
match
---
atom_expr [37572,37635]
atom_expr [37690,37753]
===
match
---
operator: } [29846,29847]
operator: } [29964,29965]
===
match
---
atom_expr [32151,32177]
atom_expr [32269,32295]
===
match
---
atom_expr [45511,45537]
atom_expr [45629,45655]
===
match
---
atom [29571,29579]
atom [29689,29697]
===
match
---
comparison [44674,44712]
comparison [44792,44830]
===
match
---
operator: = [17294,17295]
operator: = [17412,17413]
===
match
---
trailer [1766,1989]
trailer [1782,2005]
===
match
---
operator: = [23523,23524]
operator: = [23641,23642]
===
match
---
name: dag [13306,13309]
name: dag [13322,13325]
===
match
---
atom [13524,13607]
atom [13540,13623]
===
match
---
number: 8 [18025,18026]
number: 8 [18143,18144]
===
match
---
atom [41380,41484]
atom [41498,41602]
===
match
---
not_test [8644,8661]
not_test [8660,8677]
===
match
---
operator: , [9758,9759]
operator: , [9774,9775]
===
match
---
operator: } [19909,19910]
operator: } [20027,20028]
===
match
---
expr_stmt [38105,38193]
expr_stmt [38223,38311]
===
match
---
argument [30414,30438]
argument [30532,30556]
===
match
---
name: SerializedDAG [37381,37394]
name: SerializedDAG [37499,37512]
===
match
---
name: dag_id [26834,26840]
name: dag_id [26952,26958]
===
match
---
trailer [37615,37629]
trailer [37733,37747]
===
match
---
operator: = [9907,9908]
operator: = [9923,9924]
===
match
---
name: callable [13351,13359]
name: callable [13367,13375]
===
match
---
trailer [45816,45837]
trailer [45934,45955]
===
match
---
dictorsetmaker [20516,20530]
dictorsetmaker [20634,20648]
===
match
---
operator: , [3402,3403]
operator: , [3418,3419]
===
match
---
string: "### DAG Tutorial Documentation" [6431,6463]
string: "### DAG Tutorial Documentation" [6447,6479]
===
match
---
operator: , [20298,20299]
operator: , [20416,20417]
===
match
---
number: 1 [16495,16496]
number: 1 [16511,16512]
===
match
---
trailer [17215,17218]
trailer [17333,17336]
===
match
---
argument [7671,7684]
argument [7687,7700]
===
match
---
decorated [19132,20172]
decorated [19250,20290]
===
match
---
simple_stmt [20100,20172]
simple_stmt [20218,20290]
===
match
---
assert_stmt [17075,17135]
assert_stmt [17193,17253]
===
match
---
atom_expr [11661,11672]
atom_expr [11677,11688]
===
match
---
assert_stmt [42465,42530]
assert_stmt [42583,42648]
===
match
---
name: timezone [18186,18194]
name: timezone [18304,18312]
===
match
---
simple_stmt [9511,9563]
simple_stmt [9527,9579]
===
match
---
operator: , [17510,17511]
operator: , [17628,17629]
===
match
---
for_stmt [13733,13863]
for_stmt [13749,13879]
===
match
---
string: 'simple_dag' [26841,26853]
string: 'simple_dag' [26959,26971]
===
match
---
trailer [39321,39337]
trailer [39439,39455]
===
match
---
atom_expr [46036,46067]
atom_expr [46154,46185]
===
match
---
fstring_end: " [8450,8451]
fstring_end: " [8466,8467]
===
match
---
string: 'simple_dag' [16682,16694]
string: 'simple_dag' [16800,16812]
===
match
---
expr_stmt [34133,34175]
expr_stmt [34251,34293]
===
match
---
param [29354,29359]
param [29472,29477]
===
match
---
name: task_id [40898,40905]
name: task_id [41016,41023]
===
match
---
name: SerializedDAG [42176,42189]
name: SerializedDAG [42294,42307]
===
match
---
string: "retry_delay" [6055,6068]
string: "retry_delay" [6071,6084]
===
match
---
operator: , [30997,30998]
operator: , [31115,31116]
===
match
---
testlist_comp [29734,29794]
testlist_comp [29852,29912]
===
match
---
string: "task1" [43745,43752]
string: "task1" [43863,43870]
===
match
---
name: SerializedDAG [21385,21398]
name: SerializedDAG [21503,21516]
===
match
---
name: args [45543,45547]
name: args [45661,45665]
===
match
---
name: serialized_dag [13980,13994]
name: serialized_dag [13996,14010]
===
match
---
trailer [11956,11969]
trailer [11972,11985]
===
match
---
argument [37033,37048]
argument [37151,37166]
===
match
---
name: to_dict [37360,37367]
name: to_dict [37478,37485]
===
match
---
name: deserialized_dag [22465,22481]
name: deserialized_dag [22583,22599]
===
match
---
name: self [33960,33964]
name: self [34078,34082]
===
match
---
operator: { [19621,19622]
operator: { [19739,19740]
===
match
---
operator: , [3433,3434]
operator: , [3449,3450]
===
match
---
operator: = [7823,7824]
operator: = [7839,7840]
===
match
---
trailer [21671,21681]
trailer [21789,21799]
===
match
---
name: dag [26923,26926]
name: dag [27041,27044]
===
match
---
dictorsetmaker [30023,30060]
dictorsetmaker [30141,30178]
===
match
---
trailer [28287,28321]
trailer [28405,28439]
===
match
---
name: task [15082,15086]
name: task [15098,15102]
===
match
---
funcdef [16555,17391]
funcdef [16673,17509]
===
match
---
name: self [37500,37504]
name: self [37618,37622]
===
match
---
string: "airflow/example_dags" [11521,11543]
string: "airflow/example_dags" [11537,11559]
===
match
---
string: '__var' [4062,4069]
string: '__var' [4078,4085]
===
match
---
suite [17544,17718]
suite [17662,17836]
===
match
---
operator: , [29104,29105]
operator: , [29222,29223]
===
match
---
atom [1858,1980]
atom [1874,1996]
===
match
---
operator: } [6725,6726]
operator: } [6741,6742]
===
match
---
string: "edge_info" [5547,5558]
string: "edge_info" [5563,5574]
===
match
---
string: 'google' [24243,24251]
string: 'google' [24361,24369]
===
match
---
name: simple_task [28495,28506]
name: simple_task [28613,28624]
===
match
---
operator: = [6256,6257]
operator: = [6272,6273]
===
match
---
lambdef [40232,40253]
lambdef [40350,40371]
===
match
---
string: "timedelta" [2396,2407]
string: "timedelta" [2412,2423]
===
match
---
comparison [33182,33228]
comparison [33300,33346]
===
match
---
trailer [22369,22372]
trailer [22487,22490]
===
match
---
atom_expr [18098,18139]
atom_expr [18216,18257]
===
match
---
arglist [14218,14257]
arglist [14234,14273]
===
match
---
atom [29545,29557]
atom [29663,29675]
===
match
---
simple_stmt [16665,16723]
simple_stmt [16783,16841]
===
match
---
operator: , [17816,17817]
operator: , [17934,17935]
===
match
---
name: keys [37737,37741]
name: keys [37855,37859]
===
match
---
name: TaskGroup [36964,36973]
name: TaskGroup [37082,37091]
===
match
---
operator: { [20346,20347]
operator: { [20464,20465]
===
match
---
simple_stmt [41139,41201]
simple_stmt [41257,41319]
===
match
---
string: '"location": "mock", ' [9233,9255]
string: '"location": "mock", ' [9249,9271]
===
match
---
operator: == [19101,19103]
operator: == [19219,19221]
===
match
---
atom_expr [16505,16517]
atom_expr [16521,16533]
===
match
---
comparison [15534,15577]
comparison [15550,15593]
===
match
---
operator: , [32376,32377]
operator: , [32494,32495]
===
match
---
simple_stmt [5606,5724]
simple_stmt [5622,5740]
===
match
---
atom_expr [18440,18460]
atom_expr [18558,18578]
===
match
---
simple_stmt [25950,25987]
simple_stmt [26068,26105]
===
match
---
name: params [22657,22663]
name: params [22775,22781]
===
match
---
string: "params" [21447,21455]
string: "params" [21565,21573]
===
match
---
name: test_deserialization_across_process [11113,11148]
name: test_deserialization_across_process [11129,11164]
===
match
---
operator: , [12114,12115]
operator: , [12130,12131]
===
match
---
atom_expr [33563,33589]
atom_expr [33681,33707]
===
match
---
name: simple_task [28753,28764]
name: simple_task [28871,28882]
===
match
---
string: "__type" [2386,2394]
string: "__type" [2402,2410]
===
match
---
string: """         Test that when on_success_callback is passed to the DAG, has_on_success_callback is stored         in Serialized JSON blob. And when it is de-serialized dag.has_on_success_callback is set to True.          When the callback is not set, has_on_success_callback should not be stored in Serialized blob         and so default to False on de-serialization         """ [40407,40782]
string: """         Test that when on_success_callback is passed to the DAG, has_on_success_callback is stored         in Serialized JSON blob. And when it is de-serialized dag.has_on_success_callback is set to True.          When the callback is not set, has_on_success_callback should not be stored in Serialized blob         and so default to False on de-serialization         """ [40525,40900]
===
match
---
assert_stmt [23451,23509]
assert_stmt [23569,23627]
===
match
---
string: "default_pool" [3951,3965]
string: "default_pool" [3967,3981]
===
match
---
name: datetime [40941,40949]
name: datetime [41059,41067]
===
match
---
expr_stmt [25999,26164]
expr_stmt [26117,26282]
===
match
---
dictorsetmaker [5354,5512]
dictorsetmaker [5370,5528]
===
match
---
operator: } [4276,4277]
operator: } [4292,4293]
===
match
---
name: tuple [8098,8103]
name: tuple [8114,8119]
===
match
---
name: timezone [17797,17805]
name: timezone [17915,17923]
===
match
---
simple_stmt [25999,26165]
simple_stmt [26117,26283]
===
match
---
operator: , [20638,20639]
operator: , [20756,20757]
===
match
---
operator: , [5594,5595]
operator: , [5610,5611]
===
match
---
dictorsetmaker [7530,7581]
dictorsetmaker [7546,7597]
===
match
---
dictorsetmaker [19586,19911]
dictorsetmaker [19704,20029]
===
match
---
operator: { [43034,43035]
operator: { [43152,43153]
===
match
---
simple_stmt [18398,18485]
simple_stmt [18516,18603]
===
match
---
dictorsetmaker [29811,29847]
dictorsetmaker [29929,29965]
===
match
---
operator: , [19244,19245]
operator: , [19362,19363]
===
match
---
simple_stmt [22609,22664]
simple_stmt [22727,22782]
===
match
---
argument [6502,6523]
argument [6518,6539]
===
match
---
name: SerializedDAG [22484,22497]
name: SerializedDAG [22602,22615]
===
match
---
string: 'on_retry_callback' [35089,35108]
string: 'on_retry_callback' [35207,35226]
===
match
---
name: utc [16248,16251]
name: utc [16264,16267]
===
match
---
operator: , [6273,6274]
operator: , [6289,6290]
===
match
---
operator: { [35238,35239]
operator: { [35356,35357]
===
match
---
name: object_to_serialized [44243,44263]
name: object_to_serialized [44361,44381]
===
match
---
string: 'airflow' [27976,27985]
string: 'airflow' [28094,28103]
===
match
---
name: dag_id [17462,17468]
name: dag_id [17580,17586]
===
match
---
operator: } [20406,20407]
operator: } [20524,20525]
===
match
---
operator: , [25307,25308]
operator: , [25425,25426]
===
match
---
atom_expr [5700,5709]
atom_expr [5716,5725]
===
match
---
operator: = [33805,33806]
operator: = [33923,33924]
===
match
---
classdef [28881,29495]
classdef [28999,29613]
===
match
---
fstring_string: Hello  [7647,7653]
fstring_string: Hello  [7663,7669]
===
match
---
atom [30166,30197]
atom [30284,30315]
===
match
---
atom_expr [34344,34349]
atom_expr [34462,34467]
===
match
---
operator: = [23302,23303]
operator: = [23420,23421]
===
match
---
operator: , [7390,7391]
operator: , [7406,7407]
===
match
---
param [19451,19456]
param [19569,19574]
===
match
---
dotted_name [1563,1603]
dotted_name [1579,1619]
===
match
---
string: "not registered" [26134,26150]
string: "not registered" [26252,26268]
===
match
---
argument [19369,19375]
argument [19487,19493]
===
match
---
atom_expr [15400,15425]
atom_expr [15416,15441]
===
match
---
name: bash_command [23369,23381]
name: bash_command [23487,23499]
===
match
---
simple_stmt [21705,21752]
simple_stmt [21823,21870]
===
match
---
operator: = [10327,10328]
operator: = [10343,10344]
===
match
---
suite [29367,29419]
suite [29485,29537]
===
match
---
simple_stmt [37335,37373]
simple_stmt [37453,37491]
===
match
---
name: BaseOperatorLink [25142,25158]
name: BaseOperatorLink [25260,25276]
===
match
---
param [41426,41427]
param [41544,41545]
===
match
---
name: deserialize_operator [33830,33850]
name: deserialize_operator [33948,33968]
===
match
---
simple_stmt [41594,41970]
simple_stmt [41712,42088]
===
match
---
name: SerializedDAG [39200,39213]
name: SerializedDAG [39318,39331]
===
match
---
atom_expr [10790,10798]
atom_expr [10806,10814]
===
match
---
operator: = [28493,28494]
operator: = [28611,28612]
===
match
---
operator: , [43412,43413]
operator: , [43530,43531]
===
match
---
atom [19163,19388]
atom [19281,19506]
===
match
---
operator: } [7590,7591]
operator: } [7606,7607]
===
match
---
name: default_args [13462,13474]
name: default_args [13478,13490]
===
match
---
name: serialized_dag [25922,25936]
name: serialized_dag [26040,26054]
===
match
---
operator: , [43976,43977]
operator: , [44094,44095]
===
match
---
operator: , [25647,25648]
operator: , [25765,25766]
===
match
---
testlist_comp [39481,39494]
testlist_comp [39599,39612]
===
match
---
name: has_on_failure_callback [42489,42512]
name: has_on_failure_callback [42607,42630]
===
match
---
name: test_serialize_sensor [39555,39576]
name: test_serialize_sensor [39673,39694]
===
match
---
name: relativedelta [20223,20236]
name: relativedelta [20341,20354]
===
match
---
name: importlib [45225,45234]
name: importlib [45343,45352]
===
match
---
number: 1 [19374,19375]
number: 1 [19492,19493]
===
match
---
simple_stmt [24332,24378]
simple_stmt [24450,24496]
===
match
---
number: 0 [17133,17134]
number: 0 [17251,17252]
===
match
---
name: att3 [30945,30949]
name: att3 [31063,31067]
===
match
---
operator: == [44665,44667]
operator: == [44783,44785]
===
match
---
operator: = [32013,32014]
operator: = [32131,32132]
===
match
---
operator: , [1813,1814]
operator: , [1829,1830]
===
match
---
trailer [11050,11068]
trailer [11066,11084]
===
match
---
name: dag_dict [39071,39079]
name: dag_dict [39189,39197]
===
match
---
dotted_name [36722,36746]
dotted_name [36840,36864]
===
match
---
name: expand [20192,20198]
name: expand [20310,20316]
===
match
---
name: extra_links [27876,27887]
name: extra_links [27994,28005]
===
match
---
number: 1 [18458,18459]
number: 1 [18576,18577]
===
match
---
name: to_dict [41003,41010]
name: to_dict [41121,41128]
===
match
---
funcdef [38564,39430]
funcdef [38682,39548]
===
match
---
testlist_comp [39510,39528]
testlist_comp [39628,39646]
===
match
---
string: "dag_dependencies" [5572,5590]
string: "dag_dependencies" [5588,5606]
===
match
---
trailer [25911,25921]
trailer [26029,26039]
===
match
---
string: "has_on_success_callback" [41062,41087]
string: "has_on_success_callback" [41180,41205]
===
match
---
name: serialized_dag [32229,32243]
name: serialized_dag [32347,32361]
===
match
---
name: from_dict [18988,18997]
name: from_dict [19106,19115]
===
match
---
string: 'simple_task' [17578,17591]
string: 'simple_task' [17696,17709]
===
match
---
name: base_operator [34398,34411]
name: base_operator [34516,34529]
===
match
---
string: "ui_color" [4848,4858]
string: "ui_color" [4864,4874]
===
match
---
name: deserialized_dag [41285,41301]
name: deserialized_dag [41403,41419]
===
match
---
name: serialized_dag [23476,23490]
name: serialized_dag [23594,23608]
===
match
---
expr_stmt [40972,41015]
expr_stmt [41090,41133]
===
match
---
number: 1 [10258,10259]
number: 1 [10274,10275]
===
match
---
name: dags [12191,12195]
name: dags [12207,12211]
===
match
---
trailer [23600,23615]
trailer [23718,23733]
===
match
---
string: "max_retry_delay" [3304,3321]
string: "max_retry_delay" [3320,3337]
===
match
---
atom_expr [21337,21357]
atom_expr [21455,21475]
===
match
---
trailer [1797,1813]
trailer [1813,1829]
===
match
---
decorator [19132,19395]
decorator [19250,19513]
===
match
---
string: "_dag_id" [19704,19713]
string: "_dag_id" [19822,19831]
===
match
---
trailer [20792,20797]
trailer [20910,20915]
===
match
---
dotted_name [1035,1057]
dotted_name [1051,1073]
===
match
---
name: template_fields [30414,30429]
name: template_fields [30532,30547]
===
match
---
operator: @ [19132,19133]
operator: @ [19250,19251]
===
match
---
operator: , [23358,23359]
operator: , [23476,23477]
===
match
---
name: __dict__ [34207,34215]
name: __dict__ [34325,34333]
===
match
---
suite [12634,14024]
suite [12650,14040]
===
match
---
name: stringified_dags [12029,12045]
name: stringified_dags [12045,12061]
===
match
---
trailer [38064,38073]
trailer [38182,38191]
===
match
---
name: __dict__ [29392,29400]
name: __dict__ [29510,29518]
===
match
---
param [10124,10140]
param [10140,10156]
===
match
---
name: dag [37630,37633]
name: dag [37748,37751]
===
match
---
operator: , [18051,18052]
operator: , [18169,18170]
===
match
---
name: serialized_dag [22248,22262]
name: serialized_dag [22366,22380]
===
match
---
string: 'custom_task' [2646,2659]
string: 'custom_task' [2662,2675]
===
match
---
string: "bash_task" [3171,3182]
string: "bash_task" [3187,3198]
===
match
---
operator: - [12851,12852]
operator: - [12867,12868]
===
match
---
trailer [46035,46068]
trailer [46153,46186]
===
match
---
atom [4632,4634]
atom [4648,4650]
===
match
---
simple_stmt [13435,13475]
simple_stmt [13451,13491]
===
match
---
trailer [36973,36985]
trailer [37091,37103]
===
match
---
name: BaseOperator [34149,34161]
name: BaseOperator [34267,34279]
===
match
---
name: deserialized_dag [22559,22575]
name: deserialized_dag [22677,22693]
===
match
---
trailer [27571,27578]
trailer [27689,27696]
===
match
---
suite [7284,7339]
suite [7300,7355]
===
match
---
name: received_logs [26204,26217]
name: received_logs [26322,26335]
===
match
---
atom [43863,44004]
atom [43981,44122]
===
match
---
name: parameterized [21821,21834]
name: parameterized [21939,21952]
===
match
---
name: __repr__ [29284,29292]
name: __repr__ [29402,29410]
===
match
---
trailer [13805,13862]
trailer [13821,13878]
===
match
---
name: fields [35848,35854]
name: fields [35966,35972]
===
match
---
operator: } [15347,15348]
operator: } [15363,15364]
===
match
---
atom [4826,4828]
atom [4842,4844]
===
match
---
atom [11622,11624]
atom [11638,11640]
===
match
---
name: datetime [22217,22225]
name: datetime [22335,22343]
===
match
---
string: 'https://www.google.com' [25349,25373]
string: 'https://www.google.com' [25467,25491]
===
match
---
string: "__var" [19674,19681]
string: "__var" [19792,19799]
===
match
---
operator: , [3821,3822]
operator: , [3837,3838]
===
match
---
operator: , [6780,6781]
operator: , [6796,6797]
===
match
---
simple_stmt [890,900]
simple_stmt [890,900]
===
match
---
operator: { [30166,30167]
operator: { [30284,30285]
===
match
---
name: expand [42551,42557]
name: expand [42669,42675]
===
match
---
and_test [44659,44712]
and_test [44777,44830]
===
match
---
trailer [12469,12479]
trailer [12485,12495]
===
match
---
atom_expr [22422,22455]
atom_expr [22540,22573]
===
match
---
testlist_comp [19178,19194]
testlist_comp [19296,19312]
===
match
---
name: self [29354,29358]
name: self [29472,29476]
===
match
---
simple_stmt [9724,9745]
simple_stmt [9740,9761]
===
match
---
operator: = [18470,18471]
operator: = [18588,18589]
===
match
---
operator: , [14818,14819]
operator: , [14834,14835]
===
match
---
name: kubernetes [1088,1098]
name: kubernetes [1104,1114]
===
match
---
operator: == [38390,38392]
operator: == [38508,38510]
===
match
---
atom_expr [45475,45501]
atom_expr [45593,45619]
===
match
---
operator: , [32850,32851]
operator: , [32968,32969]
===
match
---
operator: { [11622,11623]
operator: { [11638,11639]
===
match
---
string: "#f0ede4" [3531,3540]
string: "#f0ede4" [3547,3556]
===
match
---
atom [30022,30061]
atom [30140,30179]
===
match
---
operator: , [4733,4734]
operator: , [4749,4750]
===
match
---
operator: , [5698,5699]
operator: , [5714,5715]
===
match
---
string: "dag" [21545,21550]
string: "dag" [21663,21668]
===
match
---
expr_stmt [25260,25276]
expr_stmt [25378,25394]
===
match
---
string: "Precondition check! If this fails the test won't make sense" [33382,33443]
string: "Precondition check! If this fails the test won't make sense" [33500,33561]
===
match
---
atom [41462,41473]
atom [41580,41591]
===
match
---
operator: == [27616,27618]
operator: == [27734,27736]
===
match
---
argument [44928,44954]
argument [45046,45072]
===
match
---
atom [24036,24112]
atom [24154,24230]
===
match
---
name: expected_value [42214,42228]
name: expected_value [42332,42346]
===
match
---
operator: , [25854,25855]
operator: , [25972,25973]
===
match
---
expr_stmt [26824,26876]
expr_stmt [26942,26994]
===
match
---
name: _ [37015,37016]
name: _ [37133,37134]
===
match
---
name: DummyOperator [37184,37197]
name: DummyOperator [37302,37315]
===
match
---
name: expand [17738,17744]
name: expand [17856,17862]
===
match
---
trailer [27163,27173]
trailer [27281,27291]
===
match
---
testlist_comp [42803,42841]
testlist_comp [42921,42959]
===
match
---
arith_expr [33101,33166]
arith_expr [33219,33284]
===
match
---
atom [5283,5537]
atom [5299,5553]
===
match
---
operator: , [30816,30817]
operator: , [30934,30935]
===
match
---
operator: == [17363,17365]
operator: == [17481,17483]
===
match
---
atom_expr [9979,10074]
atom_expr [9995,10090]
===
match
---
name: dag [6474,6477]
name: dag [6490,6493]
===
match
---
for_stmt [13294,13658]
for_stmt [13310,13674]
===
match
---
suite [44340,44394]
suite [44458,44512]
===
match
---
name: values [37873,37879]
name: values [37991,37997]
===
match
---
operator: , [19793,19794]
operator: , [19911,19912]
===
match
---
name: dag_id [8597,8603]
name: dag_id [8613,8619]
===
match
---
atom_expr [11925,11948]
atom_expr [11941,11964]
===
match
---
operator: = [31962,31963]
operator: = [32080,32081]
===
match
---
simple_stmt [8885,8901]
simple_stmt [8901,8917]
===
match
---
name: blob [39865,39869]
name: blob [39983,39987]
===
match
---
simple_stmt [38515,38559]
simple_stmt [38633,38677]
===
match
---
testlist_comp [29616,29658]
testlist_comp [29734,29776]
===
match
---
param [33516,33535]
param [33634,33653]
===
match
---
trailer [45542,45547]
trailer [45660,45665]
===
match
---
name: serialized_dag [12551,12565]
name: serialized_dag [12567,12581]
===
match
---
arglist [7420,7685]
arglist [7436,7701]
===
match
---
assert_stmt [15867,15913]
assert_stmt [15883,15929]
===
match
---
name: google_link_from_plugin [28727,28750]
name: google_link_from_plugin [28845,28868]
===
match
---
argument [6080,6089]
argument [6096,6105]
===
match
---
name: dags [7952,7956]
name: dags [7968,7972]
===
match
---
name: self [29223,29227]
name: self [29341,29345]
===
match
---
name: blob [40105,40109]
name: blob [40223,40227]
===
match
---
operator: , [42639,42640]
operator: , [42757,42758]
===
match
---
string: """         Test that when on_failure_callback is passed to the DAG, has_on_failure_callback is stored         in Serialized JSON blob. And when it is de-serialized dag.has_on_failure_callback is set to True.          When the callback is not set, has_on_failure_callback should not be stored in Serialized blob         and so default to False on de-serialization         """ [41594,41969]
string: """         Test that when on_failure_callback is passed to the DAG, has_on_failure_callback is stored         in Serialized JSON blob. And when it is de-serialized dag.has_on_failure_callback is set to True.          When the callback is not set, has_on_failure_callback should not be stored in Serialized blob         and so default to False on de-serialization         """ [41712,42087]
===
match
---
trailer [33332,33349]
trailer [33450,33467]
===
match
---
trailer [23429,23437]
trailer [23547,23555]
===
match
---
operator: } [43761,43762]
operator: } [43879,43880]
===
match
---
atom_expr [24267,24323]
atom_expr [24385,24441]
===
match
---
arglist [1772,1987]
arglist [1788,2003]
===
match
---
argument [18538,18560]
argument [18656,18678]
===
insert-tree
---
simple_stmt [788,827]
    string: """Unit tests for stringified DAGs.""" [788,826]
to
file_input [788,46069]
at 0
===
insert-tree
---
simple_stmt [1016,1032]
    import_name [1016,1031]
        name: pendulum [1023,1031]
to
file_input [788,46069]
at 10
===
insert-node
---
name: TestStringifiedDAGs [8925,8944]
to
classdef [8903,44443]
at 0
===
insert-tree
---
simple_stmt [8969,9008]
    string: """Unit tests for stringified DAGs.""" [8969,9007]
to
suite [8948,44443]
at 0
===
insert-tree
---
atom [16563,16651]
    testlist_comp [16564,16650]
        atom_expr [16564,16603]
            name: pendulum [16564,16572]
            trailer [16572,16581]
                name: datetime [16573,16581]
            trailer [16581,16603]
                arglist [16582,16602]
                    number: 2019 [16582,16586]
                    operator: , [16586,16587]
                    number: 8 [16588,16589]
                    operator: , [16589,16590]
                    number: 1 [16591,16592]
                    operator: , [16592,16593]
                    argument [16594,16602]
                        name: tz [16594,16596]
                        operator: = [16596,16597]
                        string: 'UTC' [16597,16602]
        operator: , [16603,16604]
        operator: , [16609,16610]
        atom_expr [16611,16650]
            name: pendulum [16611,16619]
            trailer [16619,16628]
                name: datetime [16620,16628]
            trailer [16628,16650]
                arglist [16629,16649]
                    number: 2019 [16629,16633]
                    operator: , [16633,16634]
                    number: 8 [16635,16636]
                    operator: , [16636,16637]
                    number: 1 [16638,16639]
                    operator: , [16639,16640]
                    argument [16641,16649]
                        name: tz [16641,16643]
                        operator: = [16643,16644]
                        string: 'UTC' [16644,16649]
to
testlist_comp [16028,16534]
at 6
===
insert-node
---
operator: , [16651,16652]
to
testlist_comp [16028,16534]
at 7
===
delete-tree
---
simple_stmt [788,827]
    string: """Unit tests for stringified DAGs.""" [788,826]
===
delete-node
---
name: TestStringifiedDAGs [8909,8928]
===
===
delete-tree
---
simple_stmt [8953,8992]
    string: """Unit tests for stringified DAGs.""" [8953,8991]
