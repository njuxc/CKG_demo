===
match
---
atom_expr [19716,19749]
atom_expr [19716,19749]
===
match
---
expr_stmt [63308,63343]
expr_stmt [63260,63295]
===
match
---
arglist [32217,32247]
arglist [32169,32199]
===
match
---
operator: , [80005,80006]
operator: , [79957,79958]
===
match
---
atom_expr [47683,47847]
atom_expr [47635,47799]
===
match
---
argument [93581,93587]
argument [93533,93539]
===
match
---
trailer [68648,68658]
trailer [68600,68610]
===
match
---
name: self [42296,42300]
name: self [42248,42252]
===
match
---
simple_stmt [43947,43994]
simple_stmt [43899,43946]
===
match
---
name: subdags [41088,41095]
name: subdags [41040,41047]
===
match
---
expr_stmt [16804,16850]
expr_stmt [16804,16850]
===
match
---
funcdef [89217,89332]
funcdef [89169,89284]
===
match
---
name: following [28927,28936]
name: following [28879,28888]
===
match
---
trailer [97119,97125]
trailer [97071,97077]
===
match
---
name: task_id [63582,63589]
name: task_id [63534,63541]
===
match
---
name: type [16956,16960]
name: type [16956,16960]
===
match
---
trailer [91891,91897]
trailer [91843,91849]
===
match
---
name: end_date [43468,43476]
name: end_date [43420,43428]
===
match
---
name: first [3661,3666]
name: first [3661,3666]
===
match
---
trailer [11257,11292]
trailer [11257,11292]
===
match
---
trailer [34268,34274]
trailer [34220,34226]
===
match
---
not_test [74162,74172]
not_test [74114,74124]
===
match
---
simple_stmt [79194,79223]
simple_stmt [79146,79175]
===
match
---
arglist [53859,53915]
arglist [53811,53867]
===
match
---
atom_expr [55336,55366]
atom_expr [55288,55318]
===
match
---
name: min [28212,28215]
name: min [28164,28167]
===
match
---
name: self [26707,26711]
name: self [26659,26663]
===
match
---
name: self [24995,24999]
name: self [24947,24951]
===
match
---
parameters [85044,85118]
parameters [84996,85070]
===
match
---
trailer [32288,32298]
trailer [32240,32250]
===
match
---
name: _pickle_id [12789,12799]
name: _pickle_id [12789,12799]
===
match
---
atom_expr [14264,14295]
atom_expr [14264,14295]
===
match
---
name: description [78584,78595]
name: description [78536,78547]
===
match
---
expr_stmt [71951,71998]
expr_stmt [71903,71950]
===
match
---
simple_stmt [87391,87428]
simple_stmt [87343,87380]
===
match
---
trailer [40217,40222]
trailer [40169,40174]
===
match
---
trailer [44384,44399]
trailer [44336,44351]
===
match
---
expr_stmt [86427,86465]
expr_stmt [86379,86417]
===
match
---
name: sys [12928,12931]
name: sys [12928,12931]
===
match
---
name: airflow [1663,1670]
name: airflow [1663,1670]
===
match
---
name: deepcopy [11974,11982]
name: deepcopy [11974,11982]
===
match
---
name: DagRun [47921,47927]
name: DagRun [47873,47879]
===
match
---
funcdef [34314,34659]
funcdef [34266,34611]
===
match
---
simple_stmt [47856,47891]
simple_stmt [47808,47843]
===
match
---
parameters [29900,29906]
parameters [29852,29858]
===
match
---
simple_stmt [83360,83409]
simple_stmt [83312,83361]
===
match
---
trailer [10278,10296]
trailer [10278,10296]
===
match
---
comparison [63504,63534]
comparison [63456,63486]
===
match
---
param [47508,47532]
param [47460,47484]
===
match
---
name: session [74892,74899]
name: session [74844,74851]
===
match
---
expr_stmt [60062,60087]
expr_stmt [60014,60039]
===
match
---
trailer [51790,51797]
trailer [51742,51749]
===
match
---
operator: , [68683,68684]
operator: , [68635,68636]
===
match
---
operator: = [78082,78083]
operator: = [78034,78035]
===
match
---
trailer [64258,64278]
trailer [64210,64230]
===
match
---
trailer [51797,51803]
trailer [51749,51755]
===
match
---
import_from [71907,71941]
import_from [71859,71893]
===
match
---
arglist [96081,96126]
arglist [96033,96078]
===
match
---
trailer [96581,96583]
trailer [96533,96535]
===
match
---
name: List [44464,44468]
name: List [44416,44420]
===
match
---
param [58136,58140]
param [58088,58092]
===
match
---
arglist [94415,94597]
arglist [94367,94549]
===
match
---
atom_expr [64555,64578]
atom_expr [64507,64530]
===
match
---
trailer [3547,3590]
trailer [3547,3590]
===
match
---
name: Column [85544,85550]
name: Column [85496,85502]
===
match
---
name: tis [43947,43950]
name: tis [43899,43902]
===
match
---
operator: , [88020,88021]
operator: , [87972,87973]
===
match
---
atom_expr [16804,16820]
atom_expr [16804,16820]
===
match
---
name: func [37739,37743]
name: func [37691,37695]
===
match
---
name: AirflowException [54441,54457]
name: AirflowException [54393,54409]
===
match
---
fstring_expr [73805,73819]
fstring_expr [73757,73771]
===
match
---
name: utils [2838,2843]
name: utils [2838,2843]
===
match
---
name: task_id [43308,43315]
name: task_id [43260,43267]
===
match
---
atom_expr [27259,27269]
atom_expr [27211,27221]
===
match
---
operator: , [19320,19321]
operator: , [19320,19321]
===
match
---
atom_expr [94670,94744]
atom_expr [94622,94696]
===
match
---
simple_stmt [62021,62083]
simple_stmt [61973,62035]
===
match
---
name: pickle_info [65643,65654]
name: pickle_info [65595,65606]
===
match
---
name: _max_active_tasks [12739,12756]
name: _max_active_tasks [12739,12756]
===
match
---
operator: == [77256,77258]
operator: == [77208,77210]
===
match
---
name: len [65831,65834]
name: len [65783,65786]
===
match
---
operator: , [77907,77908]
operator: , [77859,77860]
===
match
---
operator: = [41589,41590]
operator: = [41541,41542]
===
match
---
name: session [89935,89942]
name: session [89887,89894]
===
match
---
operator: = [55617,55618]
operator: = [55569,55570]
===
match
---
name: warnings [47683,47691]
name: warnings [47635,47643]
===
match
---
simple_stmt [13022,13067]
simple_stmt [13022,13067]
===
match
---
atom_expr [20174,20186]
atom_expr [20174,20186]
===
match
---
operator: = [38763,38764]
operator: = [38715,38716]
===
match
---
simple_stmt [97334,97843]
simple_stmt [97286,97795]
===
match
---
trailer [33215,33222]
trailer [33167,33174]
===
match
---
return_stmt [97038,97052]
return_stmt [96990,97004]
===
match
---
tfpdef [60974,61033]
tfpdef [60926,60985]
===
match
---
operator: , [94126,94127]
operator: , [94078,94079]
===
match
---
trailer [19461,19466]
trailer [19461,19466]
===
match
---
atom_expr [20017,20050]
atom_expr [20017,20050]
===
match
---
name: dag_id [89238,89244]
name: dag_id [89190,89196]
===
match
---
trailer [14010,14021]
trailer [14010,14021]
===
match
---
atom_expr [85544,85610]
atom_expr [85496,85562]
===
match
---
simple_stmt [37163,37181]
simple_stmt [37115,37133]
===
match
---
operator: @ [74951,74952]
operator: @ [74903,74904]
===
match
---
name: orm_dag [76811,76818]
name: orm_dag [76763,76770]
===
match
---
return_stmt [58945,58959]
return_stmt [58897,58911]
===
match
---
dotted_name [29956,29976]
dotted_name [29908,29928]
===
match
---
arglist [29565,29652]
arglist [29517,29604]
===
match
---
atom_expr [67294,67309]
atom_expr [67246,67261]
===
match
---
trailer [21498,21540]
trailer [21474,21516]
===
match
---
operator: , [59768,59769]
operator: , [59720,59721]
===
match
---
trailer [76295,76297]
trailer [76247,76249]
===
match
---
import_name [817,831]
import_name [817,831]
===
match
---
comparison [89139,89164]
comparison [89091,89116]
===
match
---
simple_stmt [28047,28062]
simple_stmt [27999,28014]
===
match
---
name: timezone [43549,43557]
name: timezone [43501,43509]
===
match
---
test [36277,36342]
test [36229,36294]
===
match
---
atom [65219,65250]
atom [65171,65202]
===
match
---
trailer [24695,24713]
trailer [24647,24665]
===
match
---
atom_expr [79342,79356]
atom_expr [79294,79308]
===
match
---
name: include_parentdag [56385,56402]
name: include_parentdag [56337,56354]
===
match
---
name: is_active [34009,34018]
name: is_active [33961,33970]
===
match
---
atom_expr [34237,34248]
atom_expr [34189,34200]
===
match
---
trailer [57196,57198]
trailer [57148,57150]
===
match
---
expr_stmt [3092,3142]
expr_stmt [3092,3142]
===
match
---
string: """File location of where the dag object is instantiated""" [32117,32176]
string: """File location of where the dag object is instantiated""" [32069,32128]
===
match
---
suite [60162,60313]
suite [60114,60265]
===
match
---
simple_stmt [30647,30678]
simple_stmt [30599,30630]
===
match
---
atom_expr [65742,65759]
atom_expr [65694,65711]
===
match
---
trailer [79213,79222]
trailer [79165,79174]
===
match
---
dotted_name [29779,29792]
dotted_name [29731,29744]
===
match
---
operator: , [87920,87921]
operator: , [87872,87873]
===
match
---
operator: = [48623,48624]
operator: = [48575,48576]
===
match
---
name: downstream_task_ids [64686,64705]
name: downstream_task_ids [64638,64657]
===
match
---
name: value [30672,30677]
name: value [30624,30629]
===
match
---
string: 'fetch' [91298,91305]
string: 'fetch' [91250,91257]
===
match
---
operator: -> [34717,34719]
operator: -> [34669,34671]
===
match
---
operator: , [74635,74636]
operator: , [74587,74588]
===
match
---
trailer [74711,74716]
trailer [74663,74668]
===
match
---
operator: = [52039,52040]
operator: = [51991,51992]
===
match
---
name: end_date [67840,67848]
name: end_date [67792,67800]
===
match
---
name: _upgrade_outdated_dag_access_control [18223,18259]
name: _upgrade_outdated_dag_access_control [18223,18259]
===
match
---
trailer [81001,81011]
trailer [80953,80963]
===
match
---
tfpdef [90731,90754]
tfpdef [90683,90706]
===
match
---
string: '_old_context_manager_dags' [83737,83764]
string: '_old_context_manager_dags' [83689,83716]
===
match
---
name: TaskInstance [43143,43155]
name: TaskInstance [43095,43107]
===
match
---
name: conf [69272,69276]
name: conf [69224,69228]
===
match
---
name: template_searchpath [14553,14572]
name: template_searchpath [14553,14572]
===
match
---
trailer [66931,66937]
trailer [66883,66889]
===
match
---
trailer [76085,76095]
trailer [76037,76047]
===
match
---
name: values [31734,31740]
name: values [31686,31692]
===
match
---
trailer [43740,43746]
trailer [43692,43698]
===
match
---
name: template_searchpath [14576,14595]
name: template_searchpath [14576,14595]
===
match
---
name: dag_id [55430,55436]
name: dag_id [55382,55388]
===
match
---
name: self [65090,65094]
name: self [65042,65046]
===
match
---
if_stmt [66384,66595]
if_stmt [66336,66547]
===
match
---
name: roots [44449,44454]
name: roots [44401,44406]
===
match
---
atom_expr [73857,73887]
atom_expr [73809,73839]
===
match
---
name: task_count [68627,68637]
name: task_count [68579,68589]
===
match
---
comparison [13211,13244]
comparison [13211,13244]
===
match
---
atom_expr [94513,94523]
atom_expr [94465,94475]
===
match
---
operator: @ [34664,34665]
operator: @ [34616,34617]
===
match
---
name: end_date [52754,52762]
name: end_date [52706,52714]
===
match
---
name: relativedelta [1299,1312]
name: relativedelta [1299,1312]
===
match
---
return_stmt [89443,89576]
return_stmt [89395,89528]
===
match
---
atom_expr [63308,63328]
atom_expr [63260,63280]
===
match
---
trailer [43079,43112]
trailer [43031,43064]
===
match
---
atom_expr [52710,52727]
atom_expr [52662,52679]
===
match
---
funcdef [16856,16915]
funcdef [16856,16915]
===
match
---
trailer [78398,78405]
trailer [78350,78357]
===
match
---
name: next_dagrun_create_after [94133,94157]
name: next_dagrun_create_after [94085,94109]
===
match
---
argument [88503,88515]
argument [88455,88467]
===
match
---
trailer [54763,54772]
trailer [54715,54724]
===
match
---
atom_expr [26996,27009]
atom_expr [26948,26961]
===
match
---
simple_stmt [95893,95953]
simple_stmt [95845,95905]
===
match
---
suite [38660,38749]
suite [38612,38701]
===
match
---
name: get_last_dagrun [89450,89465]
name: get_last_dagrun [89402,89417]
===
match
---
name: delta [21011,21016]
name: delta [21011,21016]
===
match
---
trailer [85862,85896]
trailer [85814,85848]
===
match
---
operator: @ [31980,31981]
operator: @ [31932,31933]
===
match
---
operator: , [30320,30321]
operator: , [30272,30273]
===
match
---
operator: = [11426,11427]
operator: = [11426,11427]
===
match
---
name: graph_unsorted [46698,46712]
name: graph_unsorted [46650,46664]
===
match
---
name: end_date [68017,68025]
name: end_date [67969,67977]
===
match
---
atom_expr [53879,53915]
atom_expr [53831,53867]
===
match
---
atom [48167,48188]
atom [48119,48140]
===
match
---
suite [80511,80549]
suite [80463,80501]
===
match
---
param [10619,10662]
param [10619,10662]
===
match
---
trailer [65788,65794]
trailer [65740,65746]
===
match
---
operator: , [96640,96641]
operator: , [96592,96593]
===
match
---
name: self [28724,28728]
name: self [28676,28680]
===
match
---
operator: = [82821,82822]
operator: = [82773,82774]
===
match
---
name: execution_date [56008,56022]
name: execution_date [55960,55974]
===
match
---
name: naive [21192,21197]
name: naive [21192,21197]
===
match
---
sync_comp_for [44850,44900]
sync_comp_for [44802,44852]
===
match
---
atom_expr [39577,39590]
atom_expr [39529,39542]
===
match
---
comparison [16956,16981]
comparison [16956,16981]
===
match
---
name: create_dagrun [72094,72107]
name: create_dagrun [72046,72059]
===
match
---
fstring_start: f' [15485,15487]
fstring_start: f' [15485,15487]
===
match
---
name: airflow [2750,2757]
name: airflow [2750,2757]
===
match
---
atom_expr [82675,82783]
atom_expr [82627,82735]
===
match
---
simple_stmt [30535,30565]
simple_stmt [30487,30517]
===
match
---
atom_expr [45712,45727]
atom_expr [45664,45679]
===
match
---
name: dag_args [94756,94764]
name: dag_args [94708,94716]
===
match
---
name: dag_bound_args [96082,96096]
name: dag_bound_args [96034,96048]
===
match
---
operator: , [60863,60864]
operator: , [60815,60816]
===
match
---
name: __serialized_fields [10093,10112]
name: __serialized_fields [10093,10112]
===
match
---
name: provide_session [42815,42830]
name: provide_session [42767,42782]
===
match
---
name: is_paused_at_creation [86059,86080]
name: is_paused_at_creation [86011,86032]
===
match
---
tfpdef [11442,11463]
tfpdef [11442,11463]
===
match
---
trailer [36809,36819]
trailer [36761,36771]
===
match
---
operator: { [18654,18655]
operator: { [18654,18655]
===
match
---
simple_stmt [856,866]
simple_stmt [856,866]
===
match
---
name: self [16090,16094]
name: self [16090,16094]
===
match
---
name: commit [82038,82044]
name: commit [81990,81996]
===
match
---
name: self [14837,14841]
name: self [14837,14841]
===
match
---
trailer [37107,37112]
trailer [37059,37064]
===
match
---
atom_expr [45753,45772]
atom_expr [45705,45724]
===
match
---
simple_stmt [73753,73822]
simple_stmt [73705,73774]
===
match
---
operator: < [17339,17340]
operator: < [17339,17340]
===
match
---
atom_expr [30947,30960]
atom_expr [30899,30912]
===
match
---
suite [41283,42495]
suite [41235,42447]
===
match
---
name: Optional [11393,11401]
name: Optional [11393,11401]
===
match
---
trailer [13253,13266]
trailer [13253,13266]
===
match
---
operator: , [1134,1135]
operator: , [1134,1135]
===
match
---
param [32095,32099]
param [32047,32051]
===
match
---
operator: = [11062,11063]
operator: = [11062,11063]
===
match
---
operator: , [33687,33688]
operator: , [33639,33640]
===
match
---
name: copy [795,799]
name: copy [795,799]
===
match
---
name: filter [43589,43595]
name: filter [43541,43547]
===
match
---
expr_stmt [27328,27367]
expr_stmt [27280,27319]
===
match
---
expr_stmt [44297,44344]
expr_stmt [44249,44296]
===
match
---
trailer [55151,55172]
trailer [55103,55124]
===
match
---
param [68965,68979]
param [68917,68931]
===
match
---
atom_expr [13133,13150]
atom_expr [13133,13150]
===
match
---
param [80637,80649]
param [80589,80601]
===
match
---
name: dag_bound_args [96105,96119]
name: dag_bound_args [96057,96071]
===
match
---
operator: = [78361,78362]
operator: = [78313,78314]
===
match
---
name: TaskInstance [82851,82863]
name: TaskInstance [82803,82815]
===
match
---
operator: , [59458,59459]
operator: , [59410,59411]
===
match
---
simple_stmt [31243,31267]
simple_stmt [31195,31219]
===
match
---
name: datetime [967,975]
name: datetime [967,975]
===
match
---
atom_expr [81653,81678]
atom_expr [81605,81630]
===
match
---
trailer [41037,41044]
trailer [40989,40996]
===
match
---
name: _context_managed_dag [98104,98124]
name: _context_managed_dag [98056,98076]
===
match
---
suite [25613,25711]
suite [25565,25663]
===
match
---
trailer [77898,77932]
trailer [77850,77884]
===
match
---
simple_stmt [36266,36343]
simple_stmt [36218,36295]
===
match
---
name: Collection [75003,75013]
name: Collection [74955,74965]
===
match
---
argument [87935,87947]
argument [87887,87899]
===
match
---
trailer [40448,40450]
trailer [40400,40402]
===
match
---
name: self [16457,16461]
name: self [16457,16461]
===
match
---
operator: * [95712,95713]
operator: * [95664,95665]
===
match
---
operator: = [83669,83670]
operator: = [83621,83622]
===
match
---
name: tis [58907,58910]
name: tis [58859,58862]
===
match
---
name: date_last_automated_dagrun [23418,23444]
name: date_last_automated_dagrun [23370,23396]
===
match
---
name: next_run_date [27383,27396]
name: next_run_date [27335,27348]
===
match
---
atom_expr [63448,63479]
atom_expr [63400,63431]
===
match
---
operator: @ [32499,32500]
operator: @ [32451,32452]
===
match
---
expr_stmt [42962,43017]
expr_stmt [42914,42969]
===
match
---
name: state [43862,43867]
name: state [43814,43819]
===
match
---
trailer [81622,81632]
trailer [81574,81584]
===
match
---
trailer [31155,31166]
trailer [31107,31118]
===
match
---
return_stmt [93552,93637]
return_stmt [93504,93589]
===
match
---
expr_stmt [41571,41785]
expr_stmt [41523,41737]
===
match
---
trailer [97104,97134]
trailer [97056,97086]
===
match
---
name: only_running [52115,52127]
name: only_running [52067,52079]
===
match
---
expr_stmt [87391,87427]
expr_stmt [87343,87379]
===
match
---
return_stmt [98474,98488]
return_stmt [98426,98440]
===
match
---
name: execution_date [74429,74443]
name: execution_date [74381,74395]
===
match
---
name: self [29808,29812]
name: self [29760,29764]
===
match
---
comparison [48111,48144]
comparison [48063,48096]
===
match
---
name: log [91763,91766]
name: log [91715,91718]
===
match
---
name: scalar [83428,83434]
name: scalar [83380,83386]
===
match
---
parameters [31030,31036]
parameters [30982,30988]
===
match
---
trailer [87735,87748]
trailer [87687,87700]
===
match
---
name: external_trigger [37963,37979]
name: external_trigger [37915,37931]
===
match
---
trailer [16783,16788]
trailer [16783,16788]
===
match
---
operator: = [97275,97276]
operator: = [97227,97228]
===
match
---
operator: = [60037,60038]
operator: = [59989,59990]
===
match
---
return_stmt [80441,80497]
return_stmt [80393,80449]
===
match
---
param [94755,94765]
param [94707,94717]
===
match
---
trailer [3666,3668]
trailer [3666,3668]
===
match
---
name: timezone [28293,28301]
name: timezone [28245,28253]
===
match
---
param [59926,59930]
param [59878,59882]
===
match
---
simple_stmt [16457,16478]
simple_stmt [16457,16478]
===
match
---
name: tii [56069,56072]
name: tii [56021,56024]
===
match
---
atom_expr [65000,65056]
atom_expr [64952,65008]
===
match
---
string: 'on_failure_callback' [84211,84232]
string: 'on_failure_callback' [84163,84184]
===
match
---
funcdef [29422,29701]
funcdef [29374,29653]
===
match
---
operator: = [56136,56137]
operator: = [56088,56089]
===
match
---
name: tasks [31771,31776]
name: tasks [31723,31728]
===
match
---
simple_stmt [17320,17354]
simple_stmt [17320,17354]
===
match
---
param [10972,11015]
param [10972,11015]
===
match
---
argument [87582,87596]
argument [87534,87548]
===
match
---
if_stmt [73665,74320]
if_stmt [73617,74272]
===
match
---
name: query [38773,38778]
name: query [38725,38730]
===
match
---
operator: = [65703,65704]
operator: = [65655,65656]
===
match
---
name: timezone [14024,14032]
name: timezone [14024,14032]
===
match
---
name: type [73806,73810]
name: type [73758,73762]
===
match
---
name: pendulum [55137,55145]
name: pendulum [55089,55097]
===
match
---
suite [17447,17825]
suite [17447,17825]
===
match
---
trailer [38257,38266]
trailer [38209,38218]
===
match
---
simple_stmt [62510,62563]
simple_stmt [62462,62515]
===
match
---
trailer [33742,33744]
trailer [33694,33696]
===
match
---
name: str [65881,65884]
name: str [65833,65836]
===
match
---
name: setter [31183,31189]
name: setter [31135,31141]
===
match
---
trailer [12181,12188]
trailer [12181,12188]
===
match
---
operator: , [41745,41746]
operator: , [41697,41698]
===
match
---
param [37366,37378]
param [37318,37330]
===
match
---
simple_stmt [39763,39778]
simple_stmt [39715,39730]
===
match
---
trailer [67345,67389]
trailer [67297,67341]
===
match
---
name: next_run_date [28601,28614]
name: next_run_date [28553,28566]
===
match
---
name: TaskInstance [44199,44211]
name: TaskInstance [44151,44163]
===
match
---
name: ExternalTaskMarker [53183,53201]
name: ExternalTaskMarker [53135,53153]
===
match
---
suite [83605,84514]
suite [83557,84466]
===
match
---
name: task_ids [31903,31911]
name: task_ids [31855,31863]
===
match
---
operator: == [43747,43749]
operator: == [43699,43701]
===
match
---
operator: = [34185,34186]
operator: = [34137,34138]
===
match
---
arglist [13308,13344]
arglist [13308,13344]
===
match
---
name: f [95093,95094]
name: f [95045,95046]
===
match
---
name: include_downstream [55807,55825]
name: include_downstream [55759,55777]
===
match
---
name: self [41907,41911]
name: self [41859,41863]
===
match
---
suite [71108,71244]
suite [71060,71196]
===
match
---
trailer [66276,66286]
trailer [66228,66238]
===
match
---
name: f_back [12944,12950]
name: f_back [12944,12950]
===
match
---
name: dags [75876,75880]
name: dags [75828,75832]
===
match
---
name: dag_args [95302,95310]
name: dag_args [95254,95262]
===
match
---
name: helpers [59314,59321]
name: helpers [59266,59273]
===
match
---
name: run [37193,37196]
name: run [37145,37148]
===
match
---
name: task_id [62370,62377]
name: task_id [62322,62329]
===
match
---
name: DagPickle [66140,66149]
name: DagPickle [66092,66101]
===
match
---
trailer [64394,64407]
trailer [64346,64359]
===
match
---
name: name [85486,85490]
name: name [85438,85442]
===
match
---
operator: = [19715,19716]
operator: = [19715,19716]
===
match
---
name: __serialized_fields [83622,83641]
name: __serialized_fields [83574,83593]
===
match
---
operator: = [35549,35550]
operator: = [35501,35502]
===
match
---
operator: = [15797,15798]
operator: = [15797,15798]
===
match
---
name: _context_managed_dag [98438,98458]
name: _context_managed_dag [98390,98410]
===
match
---
trailer [31966,31971]
trailer [31918,31923]
===
match
---
operator: = [52324,52325]
operator: = [52276,52277]
===
match
---
sync_comp_for [28229,28248]
sync_comp_for [28181,28200]
===
match
---
name: datetime [19547,19555]
name: datetime [19547,19555]
===
match
---
atom_expr [47485,47498]
atom_expr [47437,47450]
===
match
---
name: _log [60541,60545]
name: _log [60493,60497]
===
match
---
operator: , [61137,61138]
operator: , [61089,61090]
===
match
---
operator: @ [90669,90670]
operator: @ [90621,90622]
===
match
---
name: default_view [78532,78544]
name: default_view [78484,78496]
===
match
---
fstring_expr [15267,15289]
fstring_expr [15267,15289]
===
match
---
name: tis [58476,58479]
name: tis [58428,58431]
===
match
---
name: self [91153,91157]
name: self [91105,91109]
===
match
---
name: join [32717,32721]
name: join [32669,32673]
===
match
---
operator: = [76282,76283]
operator: = [76234,76235]
===
match
---
operator: = [89426,89427]
operator: = [89378,89379]
===
match
---
name: func [33169,33173]
name: func [33121,33125]
===
match
---
name: cast [1195,1199]
name: cast [1195,1199]
===
match
---
name: self [84576,84580]
name: self [84528,84532]
===
match
---
name: next_dagrun_after_date [24019,24041]
name: next_dagrun_after_date [23971,23993]
===
match
---
simple_stmt [25782,25803]
simple_stmt [25734,25755]
===
match
---
string: 'start_date' [14224,14236]
string: 'start_date' [14224,14236]
===
match
---
name: group [64370,64375]
name: group [64322,64327]
===
match
---
comparison [91025,91055]
comparison [90977,91007]
===
match
---
operator: = [71064,71065]
operator: = [71016,71017]
===
match
---
name: fileloc [92067,92074]
name: fileloc [92019,92026]
===
match
---
name: provide_session [35488,35503]
name: provide_session [35440,35455]
===
match
---
name: session [54934,54941]
name: session [54886,54893]
===
match
---
operator: , [30419,30420]
operator: , [30371,30372]
===
match
---
operator: , [1168,1169]
operator: , [1168,1169]
===
match
---
expr_stmt [22569,22610]
expr_stmt [22521,22562]
===
match
---
tfpdef [72445,72468]
tfpdef [72397,72420]
===
match
---
simple_stmt [59836,59877]
simple_stmt [59788,59829]
===
match
---
suite [13151,13198]
suite [13151,13198]
===
match
---
name: using_start_date [28071,28087]
name: using_start_date [28023,28039]
===
match
---
name: only_running [48376,48388]
name: only_running [48328,48340]
===
match
---
name: DagRun [3413,3419]
name: DagRun [3413,3419]
===
match
---
simple_stmt [53966,53981]
simple_stmt [53918,53933]
===
match
---
name: run_id [73811,73817]
name: run_id [73763,73769]
===
match
---
string: """     DAG context is used to keep the current DAG when DAG is used as ContextManager.      You can use DAG as context:      .. code-block:: python          with DAG(             dag_id="example_dag",             default_args=default_args,             schedule_interval="0 0 * * *",             dagrun_timeout=timedelta(minutes=60),         ) as dag:             ...      If you do this the context stores the DAG and whenever new task is created, it will use     such stored DAG as the parent DAG.      """ [97334,97842]
string: """     DAG context is used to keep the current DAG when DAG is used as ContextManager.      You can use DAG as context:      .. code-block:: python          with DAG(             dag_id="example_dag",             default_args=default_args,             schedule_interval="0 0 * * *",             dagrun_timeout=timedelta(minutes=60),         ) as dag:             ...      If you do this the context stores the DAG and whenever new task is created, it will use     such stored DAG as the parent DAG.      """ [97286,97794]
===
match
---
trailer [14609,14629]
trailer [14609,14629]
===
match
---
name: conf [10916,10920]
name: conf [10916,10920]
===
match
---
decorator [89032,89049]
decorator [88984,89001]
===
match
---
simple_stmt [42962,43018]
simple_stmt [42914,42970]
===
match
---
operator: = [72012,72013]
operator: = [71964,71965]
===
match
---
return_stmt [74918,74928]
return_stmt [74870,74880]
===
match
---
operator: = [46952,46953]
operator: = [46904,46905]
===
match
---
name: self [89378,89382]
name: self [89330,89334]
===
match
---
name: render_template_as_native_obj [16741,16770]
name: render_template_as_native_obj [16741,16770]
===
match
---
simple_stmt [78215,78269]
simple_stmt [78167,78221]
===
match
---
operator: , [58864,58865]
operator: , [58816,58817]
===
match
---
arglist [80457,80488]
arglist [80409,80440]
===
match
---
number: 1 [66823,66824]
number: 1 [66775,66776]
===
match
---
testlist_comp [79669,79700]
testlist_comp [79621,79652]
===
match
---
arglist [63459,63478]
arglist [63411,63430]
===
match
---
operator: @ [30764,30765]
operator: @ [30716,30717]
===
match
---
simple_stmt [29843,29864]
simple_stmt [29795,29816]
===
match
---
arith_expr [32217,32243]
arith_expr [32169,32195]
===
match
---
atom_expr [42448,42473]
atom_expr [42400,42425]
===
match
---
name: parser [72014,72020]
name: parser [71966,71972]
===
match
---
operator: = [55408,55409]
operator: = [55360,55361]
===
match
---
operator: , [1744,1745]
operator: , [1744,1745]
===
match
---
atom_expr [46698,46721]
atom_expr [46650,46673]
===
match
---
arglist [95301,95324]
arglist [95253,95276]
===
match
---
param [17958,17962]
param [17958,17962]
===
match
---
name: confirm_prompt [57469,57483]
name: confirm_prompt [57421,57435]
===
match
---
trailer [57387,57392]
trailer [57339,57344]
===
match
---
name: datetime [20088,20096]
name: datetime [20088,20096]
===
match
---
name: Boolean [86258,86265]
name: Boolean [86210,86217]
===
match
---
name: bulk_write_to_db [75326,75342]
name: bulk_write_to_db [75278,75294]
===
match
---
name: dag_id [85535,85541]
name: dag_id [85487,85493]
===
match
---
if_stmt [38795,38918]
if_stmt [38747,38870]
===
match
---
simple_stmt [32989,33115]
simple_stmt [32941,33067]
===
match
---
name: ti [53367,53369]
name: ti [53319,53321]
===
match
---
simple_stmt [92127,92155]
simple_stmt [92079,92107]
===
match
---
operator: , [33629,33630]
operator: , [33581,33582]
===
match
---
trailer [63458,63479]
trailer [63410,63431]
===
match
---
expr_stmt [78748,78840]
expr_stmt [78700,78792]
===
match
---
name: classmethod [97948,97959]
name: classmethod [97900,97911]
===
match
---
argument [74492,74525]
argument [74444,74477]
===
match
---
name: memo [59926,59930]
name: memo [59878,59882]
===
match
---
name: qry [82817,82820]
name: qry [82769,82772]
===
match
---
atom_expr [66040,66062]
atom_expr [65992,66014]
===
match
---
simple_stmt [59300,59342]
simple_stmt [59252,59294]
===
match
---
name: task_dict [31724,31733]
name: task_dict [31676,31685]
===
match
---
return_stmt [65548,65577]
return_stmt [65500,65529]
===
match
---
name: _getframe [96735,96744]
name: _getframe [96687,96696]
===
match
---
name: run_id [74091,74097]
name: run_id [74043,74049]
===
match
---
trailer [68567,68579]
trailer [68519,68531]
===
match
---
name: str [73731,73734]
name: str [73683,73686]
===
match
---
except_clause [65919,65940]
except_clause [65871,65892]
===
match
---
param [68679,68684]
param [68631,68636]
===
match
---
name: DagModel [89986,89994]
name: DagModel [89938,89946]
===
match
---
name: _access_control [16492,16507]
name: _access_control [16492,16507]
===
match
---
name: get_downstream [66722,66736]
name: get_downstream [66674,66688]
===
match
---
arglist [87640,87663]
arglist [87592,87615]
===
match
---
name: commit [92492,92498]
name: commit [92444,92450]
===
match
---
name: filter [52703,52709]
name: filter [52655,52661]
===
match
---
simple_stmt [74700,74717]
simple_stmt [74652,74669]
===
match
---
and_test [73901,73928]
and_test [73853,73880]
===
match
---
expr_stmt [16090,16145]
expr_stmt [16090,16145]
===
match
---
name: bool [44956,44960]
name: bool [44908,44912]
===
match
---
comparison [78790,78820]
comparison [78742,78772]
===
match
---
trailer [94114,94126]
trailer [94066,94078]
===
match
---
operator: = [88513,88514]
operator: = [88465,88466]
===
match
---
atom_expr [90521,90570]
atom_expr [90473,90522]
===
match
---
name: DR [3408,3410]
name: DR [3408,3410]
===
match
---
name: BackfillJob [71258,71269]
name: BackfillJob [71210,71221]
===
match
---
operator: ** [96103,96105]
operator: ** [96055,96057]
===
match
---
trailer [95809,95824]
trailer [95761,95776]
===
match
---
name: print [66765,66770]
name: print [66717,66722]
===
match
---
operator: = [55334,55335]
operator: = [55286,55287]
===
match
---
operator: , [89490,89491]
operator: , [89442,89443]
===
match
---
name: task [40788,40792]
name: task [40740,40744]
===
match
---
operator: = [86680,86681]
operator: = [86632,86633]
===
match
---
decorator [35487,35504]
decorator [35439,35456]
===
match
---
trailer [10567,10583]
trailer [10567,10583]
===
match
---
return_stmt [88984,89008]
return_stmt [88936,88960]
===
match
---
import_from [2745,2801]
import_from [2745,2801]
===
match
---
return_stmt [23876,23925]
return_stmt [23828,23877]
===
match
---
trailer [43963,43993]
trailer [43915,43945]
===
match
---
suite [63428,64007]
suite [63380,63959]
===
match
---
trailer [86878,86887]
trailer [86830,86839]
===
match
---
name: task_ids [53089,53097]
name: task_ids [53041,53049]
===
match
---
name: task [45592,45596]
name: task [45544,45548]
===
match
---
expr_stmt [53798,53941]
expr_stmt [53750,53893]
===
match
---
operator: , [90729,90730]
operator: , [90681,90682]
===
match
---
expr_stmt [64975,65056]
expr_stmt [64927,65008]
===
match
---
name: get_template_context [36619,36639]
name: get_template_context [36571,36591]
===
match
---
operator: = [44113,44114]
operator: = [44065,44066]
===
match
---
operator: = [52367,52368]
operator: = [52319,52320]
===
match
---
name: SubDagOperator [40672,40686]
name: SubDagOperator [40624,40638]
===
match
---
operator: = [68456,68457]
operator: = [68408,68409]
===
match
---
suite [41160,41229]
suite [41112,41181]
===
match
---
operator: , [72232,72233]
operator: , [72184,72185]
===
match
---
operator: , [76260,76261]
operator: , [76212,76213]
===
match
---
atom_expr [20706,20746]
atom_expr [20706,20746]
===
match
---
trailer [92136,92146]
trailer [92088,92098]
===
match
---
atom_expr [78025,78042]
atom_expr [77977,77994]
===
match
---
name: dag_model [91938,91947]
name: dag_model [91890,91899]
===
match
---
atom_expr [91982,91999]
atom_expr [91934,91951]
===
match
---
param [29901,29905]
param [29853,29857]
===
match
---
atom_expr [77666,77679]
atom_expr [77618,77631]
===
match
---
param [30626,30636]
param [30578,30588]
===
match
---
name: self [33384,33388]
name: self [33336,33340]
===
match
---
trailer [67866,67875]
trailer [67818,67827]
===
match
---
operator: , [88515,88516]
operator: , [88467,88468]
===
match
---
name: TaskInstance [44314,44326]
name: TaskInstance [44266,44278]
===
match
---
string: '.' [51804,51807]
string: '.' [51756,51759]
===
match
---
operator: , [1442,1443]
operator: , [1442,1443]
===
match
---
name: Optional [72254,72262]
name: Optional [72206,72214]
===
match
---
name: dag_id [95893,95899]
name: dag_id [95845,95851]
===
match
---
name: dag [79477,79480]
name: dag [79429,79432]
===
match
---
name: default_view [78551,78563]
name: default_view [78503,78515]
===
match
---
if_stmt [65426,65578]
if_stmt [65378,65530]
===
match
---
param [88891,88895]
param [88843,88847]
===
match
---
trailer [89323,89329]
trailer [89275,89281]
===
match
---
simple_stmt [52776,52824]
simple_stmt [52728,52776]
===
match
---
atom_expr [17566,17594]
atom_expr [17566,17594]
===
match
---
trailer [11953,11966]
trailer [11953,11966]
===
match
---
atom_expr [82700,82720]
atom_expr [82652,82672]
===
match
---
name: dag_id [34242,34248]
name: dag_id [34194,34200]
===
match
---
name: user_defined_filters [60419,60439]
name: user_defined_filters [60371,60391]
===
match
---
operator: @ [58095,58096]
operator: @ [58047,58048]
===
match
---
simple_stmt [87603,87665]
simple_stmt [87555,87617]
===
match
---
simple_stmt [47164,47241]
simple_stmt [47116,47193]
===
match
---
name: warn [33516,33520]
name: warn [33468,33472]
===
match
---
name: ti [57095,57097]
name: ti [57047,57049]
===
match
---
operator: = [95900,95901]
operator: = [95852,95853]
===
match
---
name: delta [19710,19715]
name: delta [19710,19715]
===
match
---
simple_stmt [78854,79033]
simple_stmt [78806,78985]
===
match
---
name: next_run_date [28748,28761]
name: next_run_date [28700,28713]
===
match
---
atom_expr [10123,10137]
atom_expr [10123,10137]
===
match
---
expr_stmt [52980,53023]
expr_stmt [52932,52975]
===
match
---
param [67116,67121]
param [67068,67073]
===
match
---
name: dttm [29042,29046]
name: dttm [28994,28998]
===
match
---
atom_expr [54934,55199]
atom_expr [54886,55151]
===
match
---
atom [17405,17417]
atom [17405,17417]
===
match
---
name: self [15772,15776]
name: self [15772,15776]
===
match
---
name: upstream_task_ids [64561,64578]
name: upstream_task_ids [64513,64530]
===
match
---
operator: = [15115,15116]
operator: = [15115,15116]
===
match
---
name: conf [11242,11246]
name: conf [11242,11246]
===
match
---
trailer [14248,14263]
trailer [14248,14263]
===
match
---
name: query [38757,38762]
name: query [38709,38714]
===
match
---
operator: , [10241,10242]
operator: , [10241,10242]
===
match
---
name: default_args [14327,14339]
name: default_args [14327,14339]
===
match
---
param [66117,66122]
param [66069,66074]
===
match
---
operator: = [64579,64580]
operator: = [64531,64532]
===
match
---
name: normalize_schedule [26022,26040]
name: normalize_schedule [25974,25992]
===
match
---
name: self [28238,28242]
name: self [28190,28194]
===
match
---
operator: { [73805,73806]
operator: { [73757,73758]
===
match
---
name: query [3655,3660]
name: query [3655,3660]
===
match
---
name: other [17341,17346]
name: other [17341,17346]
===
match
---
name: str [11459,11462]
name: str [11459,11462]
===
match
---
string: """         Ensure the DagModel rows for the given dags are up-to-date in the dag table in the DB, including         calculated fields.          Note that this method can be called for both DAGs and SubDAGs. A SubDag is actually a SubDagOperator.          :param dags: the DAG objects to save to the DB         :type dags: List[airflow.models.dag.DAG]         :return: None         """ [75475,75860]
string: """         Ensure the DagModel rows for the given dags are up-to-date in the dag table in the DB, including         calculated fields.          Note that this method can be called for both DAGs and SubDAGs. A SubDag is actually a SubDagOperator.          :param dags: the DAG objects to save to the DB         :type dags: List[airflow.models.dag.DAG]         :return: None         """ [75427,75812]
===
match
---
trailer [41621,41638]
trailer [41573,41590]
===
match
---
name: dag_bag [55410,55417]
name: dag_bag [55362,55369]
===
match
---
suite [81747,82047]
suite [81699,81999]
===
match
---
name: session [79570,79577]
name: session [79522,79529]
===
match
---
trailer [64636,64638]
trailer [64588,64590]
===
match
---
operator: = [19512,19513]
operator: = [19512,19513]
===
match
---
name: self [26548,26552]
name: self [26500,26504]
===
match
---
trailer [28943,28962]
trailer [28895,28914]
===
match
---
operator: = [71344,71345]
operator: = [71296,71297]
===
match
---
name: types [2764,2769]
name: types [2764,2769]
===
match
---
name: dag_id [94719,94725]
name: dag_id [94671,94677]
===
match
---
trailer [22370,22379]
trailer [22346,22355]
===
match
---
atom_expr [54745,54772]
atom_expr [54697,54724]
===
match
---
operator: = [96620,96621]
operator: = [96572,96573]
===
match
---
name: self [33319,33323]
name: self [33271,33275]
===
match
---
operator: , [47531,47532]
operator: , [47483,47484]
===
match
---
name: dag_id [85847,85853]
name: dag_id [85799,85805]
===
match
---
trailer [29080,29091]
trailer [29032,29043]
===
match
---
name: jinja2 [41264,41270]
name: jinja2 [41216,41222]
===
match
---
if_stmt [19028,19336]
if_stmt [19028,19336]
===
match
---
atom_expr [59046,59072]
atom_expr [58998,59024]
===
match
---
name: t [28233,28234]
name: t [28185,28186]
===
match
---
trailer [63701,63716]
trailer [63653,63668]
===
match
---
operator: , [95310,95311]
operator: , [95262,95263]
===
match
---
name: state [48182,48187]
name: state [48134,48139]
===
match
---
suite [84999,85022]
suite [84951,84974]
===
match
---
atom_expr [55896,56923]
atom_expr [55848,56875]
===
match
---
trailer [55955,56893]
trailer [55907,56845]
===
match
---
name: query [37703,37708]
name: query [37655,37660]
===
match
---
simple_stmt [76957,77380]
simple_stmt [76909,77332]
===
match
---
name: execution_date [73914,73928]
name: execution_date [73866,73880]
===
match
---
name: _dag_id [29765,29772]
name: _dag_id [29717,29724]
===
match
---
tfpdef [11024,11061]
tfpdef [11024,11061]
===
match
---
expr_stmt [3527,3590]
expr_stmt [3527,3590]
===
match
---
trailer [78657,78675]
trailer [78609,78627]
===
match
---
param [80001,80006]
param [79953,79958]
===
match
---
atom_expr [58977,58989]
atom_expr [58929,58941]
===
match
---
name: dag [51398,51401]
name: dag [51350,51353]
===
match
---
operator: , [52093,52094]
operator: , [52045,52046]
===
match
---
simple_stmt [66765,66802]
simple_stmt [66717,66754]
===
match
---
operator: = [45644,45645]
operator: = [45596,45597]
===
match
---
operator: = [33126,33127]
operator: = [33078,33079]
===
match
---
name: signature [95231,95240]
name: signature [95183,95192]
===
match
---
expr_stmt [41469,41507]
expr_stmt [41421,41459]
===
match
---
suite [53347,56981]
suite [53299,56933]
===
match
---
atom_expr [58052,58068]
atom_expr [58004,58020]
===
match
---
string: 'end_date' [14371,14381]
string: 'end_date' [14371,14381]
===
match
---
trailer [24093,24102]
trailer [24045,24054]
===
match
---
parameters [88968,88974]
parameters [88920,88926]
===
match
---
name: RUNNING [77672,77679]
name: RUNNING [77624,77631]
===
match
---
operator: = [39139,39140]
operator: = [39091,39092]
===
match
---
simple_stmt [30731,30759]
simple_stmt [30683,30711]
===
match
---
simple_stmt [64447,64543]
simple_stmt [64399,64495]
===
match
---
name: graph_sorted [45631,45643]
name: graph_sorted [45583,45595]
===
match
---
name: __init__ [95245,95253]
name: __init__ [95197,95205]
===
match
---
operator: = [40389,40390]
operator: = [40341,40342]
===
match
---
argument [55993,56022]
argument [55945,55974]
===
match
---
trailer [33179,33191]
trailer [33131,33143]
===
match
---
trailer [20122,20131]
trailer [20122,20131]
===
match
---
name: dag_id [39584,39590]
name: dag_id [39536,39542]
===
match
---
trailer [11180,11184]
trailer [11180,11184]
===
match
---
operator: = [96274,96275]
operator: = [96226,96227]
===
match
---
name: Column [87344,87350]
name: Column [87296,87302]
===
match
---
return_stmt [41104,41121]
return_stmt [41056,41073]
===
match
---
atom_expr [87351,87361]
atom_expr [87303,87313]
===
match
---
atom_expr [32458,32493]
atom_expr [32410,32445]
===
match
---
name: Column [85856,85862]
name: Column [85808,85814]
===
match
---
simple_stmt [98058,98126]
simple_stmt [98010,98078]
===
match
---
name: _comps [17190,17196]
name: _comps [17190,17196]
===
match
---
name: s [44068,44069]
name: s [44020,44021]
===
match
---
simple_stmt [57497,57538]
simple_stmt [57449,57490]
===
match
---
operator: , [29215,29216]
operator: , [29167,29168]
===
match
---
name: wraps [95346,95351]
name: wraps [95298,95303]
===
match
---
trailer [21752,21792]
trailer [21728,21768]
===
match
---
simple_stmt [15623,15646]
simple_stmt [15623,15646]
===
match
---
operator: = [86352,86353]
operator: = [86304,86305]
===
match
---
name: include_subdag_tasks [47081,47101]
name: include_subdag_tasks [47033,47053]
===
match
---
atom_expr [29269,29395]
atom_expr [29221,29347]
===
match
---
dotted_name [71912,71923]
dotted_name [71864,71875]
===
match
---
argument [51988,52009]
argument [51940,51961]
===
match
---
atom_expr [98223,98236]
atom_expr [98175,98188]
===
match
---
name: intersection [64395,64407]
name: intersection [64347,64359]
===
match
---
name: task_id [82713,82720]
name: task_id [82665,82672]
===
match
---
trailer [82699,82721]
trailer [82651,82673]
===
match
---
atom [79280,79310]
atom [79232,79262]
===
match
---
number: 1.0 [69236,69239]
number: 1.0 [69188,69191]
===
match
---
name: session [66543,66550]
name: session [66495,66502]
===
match
---
fstring_start: f" [55542,55544]
fstring_start: f" [55494,55496]
===
match
---
trailer [77614,77632]
trailer [77566,77584]
===
match
---
name: session [58052,58059]
name: session [58004,58011]
===
match
---
string: """         Sorts tasks in topographical order, such that a task comes after any of its         upstream dependencies.          Heavily inspired by:         http://blog.jupo.org/2012/04/06/topological-sorting-acyclic-directed-graphs/          :param include_subdag_tasks: whether to include tasks in subdags, default to False         :return: list of tasks in topological order         """ [44979,45368]
string: """         Sorts tasks in topographical order, such that a task comes after any of its         upstream dependencies.          Heavily inspired by:         http://blog.jupo.org/2012/04/06/topological-sorting-acyclic-directed-graphs/          :param include_subdag_tasks: whether to include tasks in subdags, default to False         :return: list of tasks in topological order         """ [44931,45320]
===
match
---
parameters [93675,93780]
parameters [93627,93732]
===
match
---
simple_stmt [63122,63195]
simple_stmt [63074,63147]
===
match
---
and_test [12403,12439]
and_test [12403,12439]
===
match
---
comp_op [19573,19579]
comp_op [19573,19579]
===
match
---
operator: @ [44431,44432]
operator: @ [44383,44384]
===
match
---
funcdef [33771,34020]
funcdef [33723,33972]
===
match
---
parameters [65654,65660]
parameters [65606,65612]
===
match
---
return_stmt [45746,45772]
return_stmt [45698,45724]
===
match
---
simple_stmt [88833,88873]
simple_stmt [88785,88825]
===
match
---
atom_expr [83040,83068]
atom_expr [82992,83020]
===
match
---
name: __name__ [95943,95951]
name: __name__ [95895,95903]
===
match
---
name: TaskNotFound [65592,65604]
name: TaskNotFound [65544,65556]
===
match
---
not_test [66387,66393]
not_test [66339,66345]
===
match
---
name: self [35142,35146]
name: self [35094,35098]
===
match
---
atom_expr [10693,10707]
atom_expr [10693,10707]
===
match
---
name: instance [20671,20679]
name: instance [20671,20679]
===
match
---
name: _comps [9881,9887]
name: _comps [9881,9887]
===
match
---
atom_expr [44159,44197]
atom_expr [44111,44149]
===
match
---
trailer [13821,13833]
trailer [13821,13833]
===
match
---
atom_expr [26609,26624]
atom_expr [26561,26576]
===
match
---
param [48669,48682]
param [48621,48634]
===
match
---
dotted_name [45382,45406]
dotted_name [45334,45358]
===
match
---
atom_expr [39676,39697]
atom_expr [39628,39649]
===
match
---
name: orm_dag [78215,78222]
name: orm_dag [78167,78174]
===
match
---
operator: } [10086,10087]
operator: } [10086,10087]
===
match
---
name: isinstance [73949,73959]
name: isinstance [73901,73911]
===
match
---
simple_stmt [65772,65801]
simple_stmt [65724,65753]
===
match
---
name: UtcDateTime [87736,87747]
name: UtcDateTime [87688,87699]
===
match
---
arglist [80267,80282]
arglist [80219,80234]
===
match
---
arglist [78908,79018]
arglist [78860,78970]
===
match
---
simple_stmt [35194,35292]
simple_stmt [35146,35244]
===
match
---
if_stmt [47972,48057]
if_stmt [47924,48009]
===
match
---
name: RUNNING [48523,48530]
name: RUNNING [48475,48482]
===
match
---
operator: = [26185,26186]
operator: = [26137,26138]
===
match
---
name: len [65069,65072]
name: len [65021,65024]
===
match
---
name: t [66841,66842]
name: t [66793,66794]
===
match
---
sync_comp_for [79681,79700]
sync_comp_for [79633,79652]
===
match
---
trailer [51709,51720]
trailer [51661,51672]
===
match
---
parameters [29998,30011]
parameters [29950,29963]
===
match
---
operator: = [68973,68974]
operator: = [68925,68926]
===
match
---
operator: != [66407,66409]
operator: != [66359,66361]
===
match
---
operator: , [69281,69282]
operator: , [69233,69234]
===
match
---
simple_stmt [93552,93638]
simple_stmt [93504,93590]
===
match
---
atom_expr [93502,93531]
atom_expr [93454,93483]
===
match
---
trailer [42039,42049]
trailer [41991,42001]
===
match
---
trailer [77011,77060]
trailer [76963,77012]
===
match
---
name: cls [83618,83621]
name: cls [83570,83573]
===
match
---
name: generate_run_id [74107,74122]
name: generate_run_id [74059,74074]
===
match
---
name: add [79578,79581]
name: add [79530,79533]
===
match
---
trailer [77005,77011]
trailer [76957,76963]
===
match
---
name: dag [93691,93694]
name: dag [93643,93646]
===
match
---
name: confirm_prompt [58667,58681]
name: confirm_prompt [58619,58633]
===
match
---
name: execution_date [38902,38916]
name: execution_date [38854,38868]
===
match
---
name: value [30467,30472]
name: value [30419,30424]
===
match
---
operator: = [36614,36615]
operator: = [36566,36567]
===
match
---
simple_stmt [33836,33898]
simple_stmt [33788,33850]
===
match
---
trailer [39531,39539]
trailer [39483,39491]
===
match
---
operator: = [36275,36276]
operator: = [36227,36228]
===
match
---
not_test [44876,44900]
not_test [44828,44852]
===
match
---
param [90708,90713]
param [90660,90665]
===
match
---
name: dag [63593,63596]
name: dag [63545,63548]
===
match
---
decorated [33750,34020]
decorated [33702,33972]
===
match
---
atom_expr [19085,19335]
atom_expr [19085,19335]
===
match
---
dotted_name [11786,11810]
dotted_name [11786,11810]
===
match
---
name: Optional [10782,10790]
name: Optional [10782,10790]
===
match
---
operator: , [71800,71801]
operator: , [71752,71753]
===
match
---
comp_op [78809,78815]
comp_op [78761,78767]
===
match
---
expr_stmt [28047,28061]
expr_stmt [27999,28013]
===
match
---
name: children [63924,63932]
name: children [63876,63884]
===
match
---
operator: -> [47666,47668]
operator: -> [47618,47620]
===
match
---
name: dag [65462,65465]
name: dag [65414,65417]
===
match
---
atom_expr [77496,77867]
atom_expr [77448,77819]
===
match
---
name: globals [97095,97102]
name: globals [97047,97054]
===
match
---
simple_stmt [16884,16915]
simple_stmt [16884,16915]
===
match
---
string: 'donot_pickle' [69097,69111]
string: 'donot_pickle' [69049,69063]
===
match
---
string: '@once' [35331,35338]
string: '@once' [35283,35290]
===
match
---
trailer [55005,55021]
trailer [54957,54973]
===
match
---
argument [86170,86199]
argument [86122,86151]
===
match
---
name: Optional [34720,34728]
name: Optional [34672,34680]
===
match
---
param [17241,17246]
param [17241,17246]
===
match
---
name: upstream_task_id [85308,85324]
name: upstream_task_id [85260,85276]
===
match
---
operator: = [47617,47618]
operator: = [47569,47570]
===
match
---
suite [36720,36755]
suite [36672,36707]
===
match
---
operator: @ [79965,79966]
operator: @ [79917,79918]
===
match
---
atom_expr [77597,77632]
atom_expr [77549,77584]
===
match
---
trailer [13325,13339]
trailer [13325,13339]
===
match
---
trailer [87271,87277]
trailer [87223,87229]
===
match
---
name: Callable [3117,3125]
name: Callable [3117,3125]
===
match
---
arglist [62111,62121]
arglist [62063,62073]
===
match
---
param [85074,85098]
param [85026,85050]
===
match
---
if_stmt [82910,83409]
if_stmt [82862,83361]
===
match
---
trailer [39968,39991]
trailer [39920,39943]
===
match
---
name: cls [58136,58139]
name: cls [58088,58091]
===
match
---
param [85051,85073]
param [85003,85025]
===
match
---
and_test [24806,24870]
and_test [24758,24822]
===
match
---
name: utils [2582,2587]
name: utils [2582,2587]
===
match
---
trailer [96119,96126]
trailer [96071,96078]
===
match
---
trailer [65408,65417]
trailer [65360,65369]
===
match
---
number: 2 [60862,60863]
number: 2 [60814,60815]
===
match
---
operator: = [48547,48548]
operator: = [48499,48500]
===
match
---
name: Context [3127,3134]
name: Context [3127,3134]
===
match
---
atom_expr [13747,13776]
atom_expr [13747,13776]
===
match
---
parameters [82117,82167]
parameters [82069,82119]
===
match
---
operator: = [63267,63268]
operator: = [63219,63220]
===
match
---
name: node [47052,47056]
name: node [47004,47008]
===
match
---
for_stmt [65458,65578]
for_stmt [65410,65530]
===
match
---
suite [31325,31641]
suite [31277,31593]
===
match
---
parameters [17957,17963]
parameters [17957,17963]
===
match
---
name: get_next [21205,21213]
name: get_next [21205,21213]
===
match
---
name: executor_loader [71144,71159]
name: executor_loader [71096,71111]
===
match
---
trailer [95979,95989]
trailer [95931,95941]
===
match
---
name: dag_model [91982,91991]
name: dag_model [91934,91943]
===
match
---
name: str [59153,59156]
name: str [59105,59108]
===
match
---
suite [59932,60568]
suite [59884,60520]
===
match
---
suite [2820,2872]
suite [2820,2872]
===
match
---
decorated [32333,32494]
decorated [32285,32446]
===
match
---
name: TaskInstance [43225,43237]
name: TaskInstance [43177,43189]
===
match
---
name: dag_by_ids [77952,77962]
name: dag_by_ids [77904,77914]
===
match
---
atom_expr [89108,89173]
atom_expr [89060,89125]
===
match
---
import_from [987,1016]
import_from [987,1016]
===
match
---
name: ti [53331,53333]
name: ti [53283,53285]
===
match
---
trailer [72262,72272]
trailer [72214,72224]
===
match
---
name: List [89653,89657]
name: List [89605,89609]
===
match
---
name: task [68204,68208]
name: task [68156,68160]
===
match
---
trailer [27260,27269]
trailer [27212,27221]
===
match
---
name: add [74708,74711]
name: add [74660,74663]
===
match
---
suite [63738,64007]
suite [63690,63959]
===
match
---
string: 'SubDagOperator' [40913,40929]
string: 'SubDagOperator' [40865,40881]
===
match
---
operator: , [21786,21787]
operator: , [21762,21763]
===
match
---
atom_expr [66572,66586]
atom_expr [66524,66538]
===
match
---
operator: += [62523,62525]
operator: += [62475,62477]
===
match
---
trailer [60454,60461]
trailer [60406,60413]
===
match
---
name: lower [90563,90568]
name: lower [90515,90520]
===
match
---
name: user_defined_filters [42395,42415]
name: user_defined_filters [42347,42367]
===
match
---
name: get_task [53894,53902]
name: get_task [53846,53854]
===
match
---
operator: , [9972,9973]
operator: , [9972,9973]
===
match
---
arglist [43177,43338]
arglist [43129,43290]
===
match
---
testlist_comp [87897,88036]
testlist_comp [87849,87988]
===
match
---
name: conf [88645,88649]
name: conf [88597,88601]
===
match
---
simple_stmt [3648,3669]
simple_stmt [3648,3669]
===
match
---
atom_expr [46693,46722]
atom_expr [46645,46674]
===
match
---
trailer [64737,64739]
trailer [64689,64691]
===
match
---
operator: , [77786,77787]
operator: , [77738,77739]
===
match
---
trailer [78366,78374]
trailer [78318,78326]
===
match
---
simple_stmt [55395,55438]
simple_stmt [55347,55390]
===
match
---
name: also_include [62722,62734]
name: also_include [62674,62686]
===
match
---
operator: { [48167,48168]
operator: { [48119,48120]
===
match
---
simple_stmt [1234,1264]
simple_stmt [1234,1264]
===
match
---
name: concurrency [30080,30091]
name: concurrency [30032,30043]
===
match
---
name: self [60585,60589]
name: self [60537,60541]
===
match
---
name: session [32958,32965]
name: session [32910,32917]
===
match
---
param [29459,29492]
param [29411,29444]
===
match
---
operator: , [72056,72057]
operator: , [72008,72009]
===
match
---
name: utils [2478,2483]
name: utils [2478,2483]
===
match
---
return_stmt [27455,27475]
return_stmt [27407,27427]
===
match
---
name: owners [87188,87194]
name: owners [87140,87146]
===
match
---
name: items [18914,18919]
name: items [18914,18919]
===
match
---
atom_expr [13965,13978]
atom_expr [13965,13978]
===
match
---
string: 'parent_dag' [83707,83719]
string: 'parent_dag' [83659,83671]
===
match
---
name: t [28216,28217]
name: t [28168,28169]
===
match
---
atom_expr [39000,39013]
atom_expr [38952,38965]
===
match
---
expr_stmt [32257,32309]
expr_stmt [32209,32261]
===
match
---
trailer [75971,75978]
trailer [75923,75930]
===
match
---
comparison [92036,92101]
comparison [91988,92053]
===
match
---
arglist [17134,17147]
arglist [17134,17147]
===
match
---
simple_stmt [32545,32697]
simple_stmt [32497,32649]
===
match
---
name: name [79108,79112]
name: name [79060,79064]
===
match
---
fstring_expr [15555,15576]
fstring_expr [15555,15576]
===
match
---
trailer [87139,87145]
trailer [87091,87097]
===
match
---
name: self [66410,66414]
name: self [66362,66366]
===
match
---
string: 'safe_dag_id' [83782,83795]
string: 'safe_dag_id' [83734,83747]
===
match
---
comparison [24806,24839]
comparison [24758,24791]
===
match
---
name: TI [55116,55118]
name: TI [55068,55070]
===
match
---
name: session [33155,33162]
name: session [33107,33114]
===
match
---
string: 'graph' [2997,3004]
string: 'graph' [2997,3004]
===
match
---
operator: = [45563,45564]
operator: = [45515,45516]
===
match
---
operator: == [52890,52892]
operator: == [52842,52844]
===
match
---
name: filter [81012,81018]
name: filter [80964,80970]
===
match
---
name: convert_to_utc [14249,14263]
name: convert_to_utc [14249,14263]
===
match
---
trailer [78957,78964]
trailer [78909,78916]
===
match
---
atom_expr [47380,47399]
atom_expr [47332,47351]
===
match
---
name: task [68447,68451]
name: task [68399,68403]
===
match
---
param [63088,63094]
param [63040,63046]
===
match
---
name: next_run_date [26376,26389]
name: next_run_date [26328,26341]
===
match
---
operator: = [42874,42875]
operator: = [42826,42827]
===
match
---
operator: = [42889,42890]
operator: = [42841,42842]
===
match
---
expr_stmt [76957,77379]
expr_stmt [76909,77331]
===
match
---
trailer [14426,14438]
trailer [14426,14438]
===
match
---
expr_stmt [94624,94660]
expr_stmt [94576,94612]
===
match
---
atom_expr [23458,23480]
atom_expr [23410,23432]
===
match
---
atom_expr [48761,48774]
atom_expr [48713,48726]
===
match
---
decorated [30908,30995]
decorated [30860,30947]
===
match
---
suite [83091,83326]
suite [83043,83278]
===
match
---
trailer [16110,16140]
trailer [16110,16140]
===
match
---
string: "Deactivating DAG ID %s since it was last touched by the scheduler at %s" [81786,81859]
string: "Deactivating DAG ID %s since it was last touched by the scheduler at %s" [81738,81811]
===
match
---
name: self [30542,30546]
name: self [30494,30498]
===
match
---
name: timezone [22743,22751]
name: timezone [22695,22703]
===
match
---
name: self [17411,17415]
name: self [17411,17415]
===
match
---
expr_stmt [92394,92420]
expr_stmt [92346,92372]
===
match
---
name: in_ [77112,77115]
name: in_ [77064,77067]
===
match
---
name: recursion_depth [52431,52446]
name: recursion_depth [52383,52398]
===
match
---
suite [64330,64741]
suite [64282,64693]
===
match
---
trailer [16461,16468]
trailer [16461,16468]
===
match
---
param [65289,65318]
param [65241,65270]
===
match
---
operator: , [91415,91416]
operator: , [91367,91368]
===
match
---
operator: { [62963,62964]
operator: { [62915,62916]
===
match
---
arglist [13925,13978]
arglist [13925,13978]
===
match
---
operator: , [60915,60916]
operator: , [60867,60868]
===
match
---
string: "The 'can_dag_read' and 'can_dag_edit' permissions are deprecated. " [19116,19184]
string: "The 'can_dag_read' and 'can_dag_edit' permissions are deprecated. " [19116,19184]
===
match
---
atom_expr [16411,16435]
atom_expr [16411,16435]
===
match
---
trailer [94217,94233]
trailer [94169,94185]
===
match
---
name: self [71843,71847]
name: self [71795,71799]
===
match
---
trailer [47646,47651]
trailer [47598,47603]
===
match
---
param [30513,30517]
param [30465,30469]
===
match
---
name: DagModel [76086,76094]
name: DagModel [76038,76046]
===
match
---
sync_comp_for [44612,44660]
sync_comp_for [44564,44612]
===
match
---
name: qry [83187,83190]
name: qry [83139,83142]
===
match
---
name: str [10513,10516]
name: str [10513,10516]
===
match
---
name: parent_dag [51710,51720]
name: parent_dag [51662,51672]
===
match
---
funcdef [59903,60568]
funcdef [59855,60520]
===
match
---
operator: , [91841,91842]
operator: , [91793,91794]
===
match
---
name: execution_date [72153,72167]
name: execution_date [72105,72119]
===
match
---
suite [84897,84986]
suite [84849,84938]
===
match
---
expr_stmt [13457,13511]
expr_stmt [13457,13511]
===
match
---
atom_expr [30542,30564]
atom_expr [30494,30516]
===
match
---
name: TaskInstance [43596,43608]
name: TaskInstance [43548,43560]
===
match
---
name: date_range [19384,19394]
name: date_range [19384,19394]
===
match
---
name: List [97927,97931]
name: List [97879,97883]
===
match
---
name: self [64079,64083]
name: self [64031,64035]
===
match
---
name: warn [19094,19098]
name: warn [19094,19098]
===
match
---
param [92628,92644]
param [92580,92596]
===
match
---
atom_expr [38834,38917]
atom_expr [38786,38869]
===
match
---
expr_stmt [9881,10087]
expr_stmt [9881,10087]
===
match
---
param [29197,29202]
param [29149,29154]
===
match
---
trailer [71241,71243]
trailer [71193,71195]
===
match
---
simple_stmt [91109,91166]
simple_stmt [91061,91118]
===
match
---
arglist [91245,91305]
arglist [91197,91257]
===
match
---
name: task_id [68227,68234]
name: task_id [68179,68186]
===
match
---
atom_expr [76023,76040]
atom_expr [75975,75992]
===
match
---
atom_expr [83029,83069]
atom_expr [82981,83021]
===
match
---
name: DateTime [22977,22985]
name: DateTime [22929,22937]
===
match
---
trailer [72220,72225]
trailer [72172,72177]
===
match
---
simple_stmt [57550,57716]
simple_stmt [57502,57668]
===
match
---
for_stmt [41169,41229]
for_stmt [41121,41181]
===
match
---
name: parse [55146,55151]
name: parse [55098,55103]
===
match
---
name: conf [88076,88080]
name: conf [88028,88032]
===
match
---
operator: = [48515,48516]
operator: = [48467,48468]
===
match
---
name: tis [51486,51489]
name: tis [51438,51441]
===
match
---
name: tzinfo [13191,13197]
name: tzinfo [13191,13197]
===
match
---
name: filter [37932,37938]
name: filter [37884,37890]
===
match
---
trailer [77205,77218]
trailer [77157,77170]
===
match
---
name: is_subdag [78033,78042]
name: is_subdag [77985,77994]
===
match
---
import_from [2221,2252]
import_from [2221,2252]
===
match
---
name: val [17819,17822]
name: val [17819,17822]
===
match
---
atom_expr [68012,68025]
atom_expr [67964,67977]
===
match
---
name: end_date [39122,39130]
name: end_date [39074,39082]
===
match
---
trailer [14047,14059]
trailer [14047,14059]
===
match
---
trailer [12963,12971]
trailer [12963,12971]
===
match
---
trailer [42440,42447]
trailer [42392,42399]
===
match
---
operator: = [92147,92148]
operator: = [92099,92100]
===
match
---
name: creating_job_id [74649,74664]
name: creating_job_id [74601,74616]
===
match
---
dotted_name [1884,1905]
dotted_name [1884,1905]
===
match
---
atom_expr [68238,68269]
atom_expr [68190,68221]
===
match
---
param [31214,31224]
param [31166,31176]
===
match
---
param [75022,75034]
param [74974,74986]
===
match
---
operator: , [57697,57698]
operator: , [57649,57650]
===
match
---
trailer [25268,25270]
trailer [25220,25222]
===
match
---
expr_stmt [53057,53099]
expr_stmt [53009,53051]
===
match
---
name: property [30063,30071]
name: property [30015,30023]
===
match
---
suite [80316,80549]
suite [80268,80501]
===
match
---
simple_stmt [24884,24896]
simple_stmt [24836,24848]
===
match
---
name: session [80275,80282]
name: session [80227,80234]
===
match
---
trailer [41681,41700]
trailer [41633,41652]
===
match
---
trailer [84935,84957]
trailer [84887,84909]
===
match
---
suite [76477,76857]
suite [76429,76809]
===
match
---
name: cron [20759,20763]
name: cron [20759,20763]
===
match
---
expr_stmt [15654,15676]
expr_stmt [15654,15676]
===
match
---
name: functools [807,816]
name: functools [807,816]
===
match
---
name: self [31060,31064]
name: self [31012,31016]
===
match
---
name: params [11480,11486]
name: params [11480,11486]
===
match
---
atom_expr [15388,15404]
atom_expr [15388,15404]
===
match
---
suite [32980,33341]
suite [32932,33293]
===
match
---
trailer [73867,73879]
trailer [73819,73831]
===
match
---
trailer [91254,91264]
trailer [91206,91216]
===
match
---
operator: <= [52811,52813]
operator: <= [52763,52765]
===
match
---
decorator [32499,32509]
decorator [32451,32461]
===
match
---
atom_expr [10561,10583]
atom_expr [10561,10583]
===
match
---
trailer [51960,51966]
trailer [51912,51918]
===
match
---
string: """Table containing DAG properties""" [85689,85726]
string: """Table containing DAG properties""" [85641,85678]
===
match
---
name: DagRun [77240,77246]
name: DagRun [77192,77198]
===
match
---
import_from [1622,1657]
import_from [1622,1657]
===
match
---
trailer [78998,79002]
trailer [78950,78954]
===
match
---
simple_stmt [81137,81154]
simple_stmt [81089,81106]
===
match
---
name: self [21506,21510]
name: self [21482,21486]
===
match
---
name: start [20066,20071]
name: start [20066,20071]
===
match
---
name: DagModel [81020,81028]
name: DagModel [80972,80980]
===
match
---
expr_stmt [43030,43113]
expr_stmt [42982,43065]
===
match
---
name: state [53000,53005]
name: state [52952,52957]
===
match
---
name: DagParam [1999,2007]
name: DagParam [1999,2007]
===
match
---
string: 'core' [69089,69095]
string: 'core' [69041,69047]
===
match
---
atom_expr [34187,34249]
atom_expr [34139,34201]
===
match
---
operator: = [48418,48419]
operator: = [48370,48371]
===
match
---
name: append [17807,17813]
name: append [17807,17813]
===
match
---
atom_expr [77892,77932]
atom_expr [77844,77884]
===
match
---
name: TaskGroup [16823,16832]
name: TaskGroup [16823,16832]
===
match
---
name: max_active_tasks [78696,78712]
name: max_active_tasks [78648,78664]
===
match
---
name: timezone [88960,88968]
name: timezone [88912,88920]
===
match
---
name: union [51932,51937]
name: union [51884,51889]
===
match
---
name: include_subdag_tasks [47213,47233]
name: include_subdag_tasks [47165,47185]
===
match
---
name: settings [1642,1650]
name: settings [1642,1650]
===
match
---
atom_expr [96105,96126]
atom_expr [96057,96078]
===
match
---
name: dag_id [16905,16911]
name: dag_id [16905,16911]
===
match
---
atom_expr [20662,20685]
atom_expr [20662,20685]
===
match
---
trailer [91766,91772]
trailer [91718,91724]
===
match
---
simple_stmt [98434,98466]
simple_stmt [98386,98418]
===
match
---
operator: = [28273,28274]
operator: = [28225,28226]
===
match
---
name: dag [78908,78911]
name: dag [78860,78863]
===
match
---
trailer [25650,25661]
trailer [25602,25613]
===
match
---
atom [44061,44084]
atom [44013,44036]
===
match
---
atom [48771,48773]
atom [48723,48725]
===
match
---
atom_expr [73712,73735]
atom_expr [73664,73687]
===
match
---
comparison [51517,51541]
comparison [51469,51493]
===
match
---
testlist_comp [23943,24008]
testlist_comp [23895,23960]
===
match
---
operator: == [17149,17151]
operator: == [17149,17151]
===
match
---
name: parent_dag [78236,78246]
name: parent_dag [78188,78198]
===
match
---
name: re [863,865]
name: re [863,865]
===
match
---
string: 'Executing dag callback function: %s' [36390,36427]
string: 'Executing dag callback function: %s' [36342,36379]
===
match
---
operator: , [90164,90165]
operator: , [90116,90117]
===
match
---
atom_expr [68622,68637]
atom_expr [68574,68589]
===
match
---
del_stmt [46979,47011]
del_stmt [46931,46963]
===
match
---
atom [87887,88042]
atom [87839,87994]
===
match
---
operator: , [83900,83901]
operator: , [83852,83853]
===
match
---
name: dict [72354,72358]
name: dict [72306,72310]
===
match
---
tfpdef [11480,11502]
tfpdef [11480,11502]
===
match
---
trailer [64631,64636]
trailer [64583,64588]
===
match
---
trailer [43982,43986]
trailer [43934,43938]
===
match
---
atom_expr [64618,64638]
atom_expr [64570,64590]
===
match
---
string: """         Given a list of known DAGs, deactivate any other DAGs that are         marked as active in the ORM          :param active_dag_ids: list of DAG IDs that are active         :type active_dag_ids: list[unicode]         :return: None         """ [80660,80912]
string: """         Given a list of known DAGs, deactivate any other DAGs that are         marked as active in the ORM          :param active_dag_ids: list of DAG IDs that are active         :type active_dag_ids: list[unicode]         :return: None         """ [80612,80864]
===
match
---
operator: = [48388,48389]
operator: = [48340,48341]
===
match
---
name: log [36806,36809]
name: log [36758,36761]
===
match
---
argument [56316,56347]
argument [56268,56299]
===
match
---
comparison [66337,66366]
comparison [66289,66318]
===
match
---
name: execution_date [38884,38898]
name: execution_date [38836,38850]
===
match
---
trailer [52795,52810]
trailer [52747,52762]
===
match
---
trailer [51586,51601]
trailer [51538,51553]
===
match
---
trailer [22311,22321]
trailer [22287,22297]
===
match
---
trailer [48026,48041]
trailer [47978,47993]
===
match
---
trailer [62101,62110]
trailer [62053,62062]
===
match
---
atom_expr [33912,33974]
atom_expr [33864,33926]
===
match
---
arglist [82743,82773]
arglist [82695,82725]
===
match
---
if_stmt [57779,58043]
if_stmt [57731,57995]
===
match
---
name: next_dagrun_create_after [94629,94653]
name: next_dagrun_create_after [94581,94605]
===
match
---
decorated [66974,67098]
decorated [66926,67050]
===
match
---
name: TI [51383,51385]
name: TI [51335,51337]
===
match
---
trailer [13751,13764]
trailer [13751,13764]
===
match
---
atom_expr [91109,91165]
atom_expr [91061,91117]
===
match
---
trailer [79282,79287]
trailer [79234,79239]
===
match
---
operator: , [92626,92627]
operator: , [92578,92579]
===
match
---
atom_expr [67478,67493]
atom_expr [67430,67445]
===
match
---
name: self [28549,28553]
name: self [28501,28505]
===
match
---
trailer [38883,38898]
trailer [38835,38850]
===
match
---
simple_stmt [877,894]
simple_stmt [877,894]
===
match
---
name: normalize_schedule [28505,28523]
name: normalize_schedule [28457,28475]
===
match
---
name: self [17298,17302]
name: self [17298,17302]
===
match
---
operator: , [59924,59925]
operator: , [59876,59877]
===
match
---
name: State [48517,48522]
name: State [48469,48474]
===
match
---
name: max_active_tasks [10812,10828]
name: max_active_tasks [10812,10828]
===
match
---
trailer [16339,16359]
trailer [16339,16359]
===
match
---
param [58211,58229]
param [58163,58181]
===
match
---
name: external_dag [55473,55485]
name: external_dag [55425,55437]
===
match
---
atom_expr [51928,52656]
atom_expr [51880,52608]
===
match
---
suite [25046,25773]
suite [24998,25725]
===
match
---
operator: , [88188,88189]
operator: , [88140,88141]
===
match
---
name: RUNNING [58379,58386]
name: RUNNING [58331,58338]
===
match
---
param [60585,60590]
param [60537,60542]
===
match
---
name: timezone [21475,21483]
name: timezone [21451,21459]
===
match
---
expr_stmt [71055,71081]
expr_stmt [71007,71033]
===
match
---
name: id [66347,66349]
name: id [66299,66301]
===
match
---
arglist [87903,87947]
arglist [87855,87899]
===
match
---
trailer [43304,43337]
trailer [43256,43289]
===
match
---
name: self [67525,67529]
name: self [67477,67481]
===
match
---
trailer [48522,48530]
trailer [48474,48482]
===
match
---
operator: , [84980,84981]
operator: , [84932,84933]
===
match
---
name: str [60999,61002]
name: str [60951,60954]
===
match
---
expr_stmt [64043,64102]
expr_stmt [63995,64054]
===
match
---
operator: = [71740,71741]
operator: = [71692,71693]
===
match
---
and_expr [51355,51411]
and_expr [51307,51363]
===
match
---
name: session [56561,56568]
name: session [56513,56520]
===
match
---
name: UtcDateTime [87852,87863]
name: UtcDateTime [87804,87815]
===
match
---
trailer [37999,38001]
trailer [37951,37953]
===
match
---
param [42858,42863]
param [42810,42815]
===
match
---
name: ti_key [53584,53590]
name: ti_key [53536,53542]
===
match
---
name: convert_to_utc [22752,22766]
name: convert_to_utc [22704,22718]
===
match
---
simple_stmt [21926,21957]
simple_stmt [21902,21933]
===
match
---
name: property [66975,66983]
name: property [66927,66935]
===
match
---
name: self [30029,30033]
name: self [29981,29985]
===
match
---
name: commit [91332,91338]
name: commit [91284,91290]
===
match
---
expr_stmt [19598,19613]
expr_stmt [19598,19613]
===
match
---
operator: , [56347,56348]
operator: , [56299,56300]
===
match
---
simple_stmt [72007,72034]
simple_stmt [71959,71986]
===
match
---
operator: , [2690,2691]
operator: , [2690,2691]
===
match
---
trailer [23987,24008]
trailer [23939,23960]
===
match
---
arglist [11107,11138]
arglist [11107,11138]
===
match
---
trailer [42758,42773]
trailer [42710,42725]
===
match
---
name: dag_id [91034,91040]
name: dag_id [90986,90992]
===
match
---
comparison [17527,17542]
comparison [17527,17542]
===
match
---
name: run [68913,68916]
name: run [68865,68868]
===
match
---
name: session [29445,29452]
name: session [29397,29404]
===
match
---
name: execution_date [3621,3635]
name: execution_date [3621,3635]
===
match
---
simple_stmt [47032,47058]
simple_stmt [46984,47010]
===
match
---
name: session [66465,66472]
name: session [66417,66424]
===
match
---
return_stmt [21354,21395]
return_stmt [21330,21371]
===
match
---
expr_stmt [3595,3643]
expr_stmt [3595,3643]
===
match
---
testlist_comp [62182,62200]
testlist_comp [62134,62152]
===
match
---
expr_stmt [16575,16629]
expr_stmt [16575,16629]
===
match
---
name: file [2432,2436]
name: file [2432,2436]
===
match
---
trailer [95244,95253]
trailer [95196,95205]
===
match
---
string: 'stacktrace' [66024,66036]
string: 'stacktrace' [65976,65988]
===
match
---
suite [23489,23608]
suite [23441,23560]
===
match
---
name: start_date [39648,39658]
name: start_date [39600,39610]
===
match
---
operator: , [11196,11197]
operator: , [11196,11197]
===
match
---
name: include_subdags [59653,59668]
name: include_subdags [59605,59620]
===
match
---
atom_expr [57177,57198]
atom_expr [57129,57150]
===
match
---
name: edge_info [84887,84896]
name: edge_info [84839,84848]
===
match
---
simple_stmt [64043,64103]
simple_stmt [63995,64055]
===
match
---
suite [96584,96649]
suite [96536,96601]
===
match
---
name: append [51348,51354]
name: append [51300,51306]
===
match
---
operator: , [2677,2678]
operator: , [2677,2678]
===
match
---
simple_stmt [2745,2802]
simple_stmt [2745,2802]
===
match
---
name: role [18958,18962]
name: role [18958,18962]
===
match
---
trailer [57749,57759]
trailer [57701,57711]
===
match
---
operator: { [65612,65613]
operator: { [65564,65565]
===
match
---
return_stmt [29262,29395]
return_stmt [29214,29347]
===
match
---
name: other [17241,17246]
name: other [17241,17246]
===
match
---
operator: @ [29778,29779]
operator: @ [29730,29731]
===
match
---
string: 'all,delete-orphan' [87497,87516]
string: 'all,delete-orphan' [87449,87468]
===
match
---
operator: , [72475,72476]
operator: , [72427,72428]
===
match
---
exprlist [60132,60136]
exprlist [60084,60088]
===
match
---
param [37337,37342]
param [37289,37294]
===
match
---
name: utcnow [66522,66528]
name: utcnow [66474,66480]
===
match
---
trailer [79350,79355]
trailer [79302,79307]
===
match
---
name: pickle_id [31173,31182]
name: pickle_id [31125,31134]
===
match
---
atom_expr [77741,77764]
atom_expr [77693,77716]
===
match
---
atom_expr [17814,17823]
atom_expr [17814,17823]
===
match
---
trailer [34095,34101]
trailer [34047,34053]
===
match
---
simple_stmt [31334,31571]
simple_stmt [31286,31523]
===
match
---
tfpdef [10463,10519]
tfpdef [10463,10519]
===
match
---
sync_comp_for [82985,83000]
sync_comp_for [82937,82952]
===
match
---
expr_stmt [22510,22552]
expr_stmt [22486,22504]
===
match
---
arglist [69089,69111]
arglist [69041,69063]
===
match
---
name: Tuple [22924,22929]
name: Tuple [22876,22881]
===
match
---
name: include_parentdag [48464,48481]
name: include_parentdag [48416,48433]
===
match
---
if_stmt [63906,64007]
if_stmt [63858,63959]
===
match
---
suite [16944,17219]
suite [16944,17219]
===
match
---
trailer [90529,90562]
trailer [90481,90514]
===
match
---
trailer [51434,51441]
trailer [51386,51393]
===
match
---
operator: = [12757,12758]
operator: = [12757,12758]
===
match
---
and_test [66265,66286]
and_test [66217,66238]
===
match
---
name: only_failed [52082,52093]
name: only_failed [52034,52045]
===
match
---
param [69016,69028]
param [68968,68980]
===
match
---
number: 2 [88514,88515]
number: 2 [88466,88467]
===
match
---
name: dumps [65789,65794]
name: dumps [65741,65746]
===
match
---
decorated [29955,30057]
decorated [29907,30009]
===
match
---
sync_comp_for [57524,57536]
sync_comp_for [57476,57488]
===
match
---
atom_expr [75433,75450]
atom_expr [75385,75402]
===
match
---
operator: } [84512,84513]
operator: } [84464,84465]
===
match
---
name: primary [53553,53560]
name: primary [53505,53512]
===
match
---
trailer [10308,10316]
trailer [10308,10316]
===
match
---
simple_stmt [39033,39054]
simple_stmt [38985,39006]
===
match
---
operator: } [15288,15289]
operator: } [15288,15289]
===
match
---
trailer [67073,67081]
trailer [67025,67033]
===
match
---
import_as_names [2136,2179]
import_as_names [2136,2179]
===
match
---
name: setattr [60270,60277]
name: setattr [60222,60229]
===
match
---
parameters [89232,89259]
parameters [89184,89211]
===
match
---
return_stmt [32318,32327]
return_stmt [32270,32279]
===
match
---
name: add [56969,56972]
name: add [56921,56924]
===
match
---
operator: = [97135,97136]
operator: = [97087,97088]
===
match
---
name: is_active [92137,92146]
name: is_active [92089,92098]
===
match
---
simple_stmt [79435,79489]
simple_stmt [79387,79441]
===
match
---
expr_stmt [27207,27270]
expr_stmt [27159,27222]
===
match
---
operator: = [88074,88075]
operator: = [88026,88027]
===
match
---
atom_expr [10640,10654]
atom_expr [10640,10654]
===
match
---
string: 'webserver' [11185,11196]
string: 'webserver' [11185,11196]
===
match
---
trailer [83369,83376]
trailer [83321,83328]
===
match
---
name: paused_dag_id [90133,90146]
name: paused_dag_id [90085,90098]
===
match
---
operator: = [76238,76239]
operator: = [76190,76191]
===
match
---
param [32009,32013]
param [31961,31965]
===
match
---
arglist [40236,40392]
arglist [40188,40344]
===
match
---
not_test [73945,73981]
not_test [73897,73933]
===
match
---
trailer [33268,33276]
trailer [33220,33228]
===
match
---
trailer [42394,42415]
trailer [42346,42367]
===
match
---
param [69291,69316]
param [69243,69268]
===
match
---
arglist [34468,34612]
arglist [34420,34564]
===
match
---
name: start_date [48301,48311]
name: start_date [48253,48263]
===
match
---
name: t [27240,27241]
name: t [27192,27193]
===
match
---
funcdef [39080,39778]
funcdef [39032,39730]
===
match
---
operator: = [88183,88184]
operator: = [88135,88136]
===
match
---
name: _access_control [30743,30758]
name: _access_control [30695,30710]
===
match
---
atom_expr [48744,48758]
atom_expr [48696,48710]
===
match
---
atom [47877,47890]
atom [47829,47842]
===
match
---
string: 'task_dict' [84067,84078]
string: 'task_dict' [84019,84030]
===
match
---
name: orm_dag [76709,76716]
name: orm_dag [76661,76668]
===
match
---
name: task_id [55054,55061]
name: task_id [55006,55013]
===
match
---
atom_expr [26962,26975]
atom_expr [26914,26927]
===
match
---
operator: , [38146,38147]
operator: , [38098,38099]
===
match
---
operator: = [87843,87844]
operator: = [87795,87796]
===
match
---
trailer [36384,36389]
trailer [36336,36341]
===
match
---
name: value [34269,34274]
name: value [34221,34226]
===
match
---
arglist [54988,55173]
arglist [54940,55125]
===
match
---
trailer [16094,16104]
trailer [16094,16104]
===
match
---
atom_expr [92539,92557]
atom_expr [92491,92509]
===
match
---
name: str [62182,62185]
name: str [62134,62137]
===
match
---
trailer [20131,20141]
trailer [20131,20141]
===
match
---
operator: ** [88226,88228]
operator: ** [88178,88180]
===
match
---
name: last_pickled [66498,66510]
name: last_pickled [66450,66462]
===
match
---
name: int [72511,72514]
name: int [72463,72466]
===
match
---
operator: , [69344,69345]
operator: , [69296,69297]
===
match
---
simple_stmt [71951,71999]
simple_stmt [71903,71951]
===
match
---
operator: , [31611,31612]
operator: , [31563,31564]
===
match
---
name: is_fixed_time_schedule [20913,20935]
name: is_fixed_time_schedule [20913,20935]
===
match
---
name: do_it [59354,59359]
name: do_it [59306,59311]
===
match
---
atom_expr [88322,88534]
atom_expr [88274,88486]
===
match
---
import_name [877,893]
import_name [877,893]
===
match
---
name: session [79855,79862]
name: session [79807,79814]
===
match
---
name: session [92539,92546]
name: session [92491,92498]
===
match
---
string: "DAG %s is at (or above) max_active_runs (%d of %d), not creating any more runs" [94415,94495]
string: "DAG %s is at (or above) max_active_runs (%d of %d), not creating any more runs" [94367,94447]
===
match
---
decorator [31885,31895]
decorator [31837,31847]
===
match
---
trailer [3640,3642]
trailer [3640,3642]
===
match
---
operator: == [38984,38986]
operator: == [38936,38938]
===
match
---
parameters [20294,20306]
parameters [20294,20306]
===
match
---
name: all_tis [59169,59176]
name: all_tis [59121,59128]
===
match
---
name: access_control [11519,11533]
name: access_control [11519,11533]
===
match
---
trailer [66049,66060]
trailer [66001,66012]
===
match
---
operator: = [47652,47653]
operator: = [47604,47605]
===
match
---
operator: { [16143,16144]
operator: { [16143,16144]
===
match
---
atom_expr [79003,79013]
atom_expr [78955,78965]
===
match
---
name: self [36945,36949]
name: self [36897,36901]
===
match
---
return_stmt [35456,35481]
return_stmt [35408,35433]
===
match
---
atom_expr [24806,24828]
atom_expr [24758,24780]
===
match
---
operator: > [26994,26995]
operator: > [26946,26947]
===
match
---
name: cls [74992,74995]
name: cls [74944,74947]
===
match
---
parameters [16868,16874]
parameters [16868,16874]
===
match
---
name: dag [78547,78550]
name: dag [78499,78502]
===
match
---
name: Column [86354,86360]
name: Column [86306,86312]
===
match
---
name: qry [83193,83196]
name: qry [83145,83148]
===
match
---
argument [51870,51893]
argument [51822,51845]
===
match
---
name: session [35569,35576]
name: session [35521,35528]
===
match
---
name: self [29999,30003]
name: self [29951,29955]
===
match
---
return_stmt [90193,90214]
return_stmt [90145,90166]
===
match
---
name: TI [33213,33215]
name: TI [33165,33167]
===
match
---
name: Optional [72169,72177]
name: Optional [72121,72129]
===
match
---
atom_expr [66397,66406]
atom_expr [66349,66358]
===
match
---
trailer [21330,21341]
trailer [21306,21317]
===
match
---
string: 'schedule_interval' [9982,10001]
string: 'schedule_interval' [9982,10001]
===
match
---
operator: == [20171,20173]
operator: == [20171,20173]
===
match
---
trailer [98061,98092]
trailer [98013,98044]
===
match
---
name: t [32735,32736]
name: t [32687,32688]
===
match
---
name: dag_id [3470,3476]
name: dag_id [3470,3476]
===
match
---
name: str [32367,32370]
name: str [32319,32322]
===
match
---
operator: , [2380,2381]
operator: , [2380,2381]
===
match
---
name: dag_id [79481,79487]
name: dag_id [79433,79439]
===
match
---
trailer [97125,97131]
trailer [97077,97083]
===
match
---
trailer [51401,51410]
trailer [51353,51362]
===
match
---
suite [17774,17825]
suite [17774,17825]
===
match
---
suite [47986,48057]
suite [47938,48009]
===
match
---
name: provide_session [47406,47421]
name: provide_session [47358,47373]
===
match
---
atom_expr [57561,57715]
atom_expr [57513,57667]
===
match
---
name: Optional [30947,30955]
name: Optional [30899,30907]
===
match
---
trailer [17813,17824]
trailer [17813,17824]
===
match
---
if_stmt [45709,45773]
if_stmt [45661,45725]
===
match
---
name: _full_filepath [29935,29949]
name: _full_filepath [29887,29901]
===
match
---
trailer [47949,47953]
trailer [47901,47905]
===
match
---
name: cls [93584,93587]
name: cls [93536,93539]
===
match
---
name: tasks [43330,43335]
name: tasks [43282,43287]
===
match
---
name: self [14713,14717]
name: self [14713,14717]
===
match
---
atom [44606,44661]
atom [44558,44613]
===
match
---
not_test [71095,71107]
not_test [71047,71059]
===
match
---
if_stmt [88701,88873]
if_stmt [88653,88825]
===
match
---
name: name [96545,96549]
name: name [96497,96501]
===
match
---
atom_expr [64079,64095]
atom_expr [64031,64047]
===
match
---
operator: = [46661,46662]
operator: = [46613,46614]
===
match
---
name: update [36677,36683]
name: update [36629,36635]
===
match
---
trailer [63279,63294]
trailer [63231,63246]
===
match
---
atom_expr [43200,43211]
atom_expr [43152,43163]
===
match
---
operator: = [55894,55895]
operator: = [55846,55847]
===
match
---
suite [32814,32898]
suite [32766,32850]
===
match
---
trailer [34226,34233]
trailer [34178,34185]
===
match
---
trailer [37779,37786]
trailer [37731,37738]
===
match
---
dotted_name [31750,31762]
dotted_name [31702,31714]
===
match
---
trailer [89657,89662]
trailer [89609,89614]
===
match
---
name: List [31679,31683]
name: List [31631,31635]
===
match
---
trailer [67081,67097]
trailer [67033,67049]
===
match
---
name: or_ [51442,51445]
name: or_ [51394,51397]
===
match
---
name: start_date [13133,13143]
name: start_date [13133,13143]
===
match
---
tfpdef [65289,65310]
tfpdef [65241,65262]
===
match
---
operator: , [85877,85878]
operator: , [85829,85830]
===
match
---
name: len [75935,75938]
name: len [75887,75890]
===
match
---
trailer [78695,78712]
trailer [78647,78664]
===
match
---
name: last_expired [86667,86679]
name: last_expired [86619,86631]
===
match
---
atom_expr [31719,31742]
atom_expr [31671,31694]
===
match
---
name: correct_maybe_zipped [92036,92056]
name: correct_maybe_zipped [91988,92008]
===
match
---
name: task [45602,45606]
name: task [45554,45558]
===
match
---
atom_expr [65394,65417]
atom_expr [65346,65369]
===
match
---
fstring [15196,15248]
fstring [15196,15248]
===
match
---
simple_stmt [26761,26849]
simple_stmt [26713,26801]
===
match
---
simple_stmt [85456,85482]
simple_stmt [85408,85434]
===
match
---
comp_if [83157,83165]
comp_if [83109,83117]
===
match
---
comparison [81653,81696]
comparison [81605,81648]
===
match
---
atom_expr [22743,22808]
atom_expr [22695,22760]
===
match
---
name: dag [63521,63524]
name: dag [63473,63476]
===
match
---
trailer [64083,64095]
trailer [64035,64047]
===
match
---
expr_stmt [33149,33287]
expr_stmt [33101,33239]
===
match
---
name: clear [48249,48254]
name: clear [48201,48206]
===
match
---
trailer [3540,3547]
trailer [3540,3547]
===
match
---
name: downstream_task_ids [64658,64677]
name: downstream_task_ids [64610,64629]
===
match
---
if_stmt [77991,78418]
if_stmt [77943,78370]
===
match
---
name: ti [53546,53548]
name: ti [53498,53500]
===
match
---
atom_expr [81020,81055]
atom_expr [80972,81007]
===
match
---
string: 'DagTag' [87479,87487]
string: 'DagTag' [87431,87439]
===
match
---
atom_expr [87845,87864]
atom_expr [87797,87816]
===
match
---
name: airflow [97190,97197]
name: airflow [97142,97149]
===
match
---
name: kwargs [95721,95727]
name: kwargs [95673,95679]
===
match
---
trailer [65884,65910]
trailer [65836,65862]
===
match
---
name: naive [22600,22605]
name: naive [22552,22557]
===
match
---
trailer [17410,17416]
trailer [17410,17416]
===
match
---
name: max_active_tasks [88252,88268]
name: max_active_tasks [88204,88220]
===
match
---
operator: = [56003,56004]
operator: = [55955,55956]
===
match
---
name: execution_date [37242,37256]
name: execution_date [37194,37208]
===
match
---
name: orm_dag [78854,78861]
name: orm_dag [78806,78813]
===
match
---
name: dag_run_state [56460,56473]
name: dag_run_state [56412,56425]
===
match
---
atom_expr [63245,63266]
atom_expr [63197,63218]
===
match
---
parameters [21567,21579]
parameters [21543,21555]
===
match
---
suite [63535,63622]
suite [63487,63574]
===
match
---
name: run_type [73834,73842]
name: run_type [73786,73794]
===
match
---
name: hour [20201,20205]
name: hour [20201,20205]
===
match
---
suite [17311,17354]
suite [17311,17354]
===
match
---
suite [62313,62400]
suite [62265,62352]
===
match
---
atom_expr [86522,86541]
atom_expr [86474,86493]
===
match
---
name: max_active_tasks [30571,30587]
name: max_active_tasks [30523,30539]
===
match
---
name: get_task [42732,42740]
name: get_task [42684,42692]
===
match
---
name: session [74725,74732]
name: session [74677,74684]
===
match
---
name: user_defined_filters [42453,42473]
name: user_defined_filters [42405,42425]
===
match
---
expr_stmt [36266,36342]
expr_stmt [36218,36294]
===
match
---
name: all_tis [58981,58988]
name: all_tis [58933,58940]
===
match
---
name: Optional [31121,31129]
name: Optional [31073,31081]
===
match
---
operator: = [56568,56569]
operator: = [56520,56521]
===
match
---
import_from [45377,45428]
import_from [45329,45380]
===
match
---
annassign [16104,16145]
annassign [16104,16145]
===
match
---
trailer [28680,28695]
trailer [28632,28647]
===
match
---
name: run_id [74166,74172]
name: run_id [74118,74124]
===
match
---
name: backref [87526,87533]
name: backref [87478,87485]
===
match
---
param [35542,35555]
param [35494,35507]
===
match
---
name: recursion_depth [52447,52462]
name: recursion_depth [52399,52414]
===
match
---
expr_stmt [77946,77978]
expr_stmt [77898,77930]
===
match
---
name: doc_md [11442,11448]
name: doc_md [11442,11448]
===
match
---
trailer [21213,21223]
trailer [21213,21223]
===
match
---
comparison [3457,3476]
comparison [3457,3476]
===
match
---
name: wrapper [95085,95092]
name: wrapper [95037,95044]
===
match
---
trailer [35113,35131]
trailer [35065,35083]
===
match
---
name: qry [83366,83369]
name: qry [83318,83321]
===
match
---
return_stmt [66604,66613]
return_stmt [66556,66565]
===
match
---
trailer [40953,40963]
trailer [40905,40915]
===
match
---
operator: , [10962,10963]
operator: , [10962,10963]
===
match
---
trailer [68897,68903]
trailer [68849,68855]
===
match
---
trailer [22206,22208]
trailer [22182,22184]
===
match
---
name: parse_args [72021,72031]
name: parse_args [71973,71983]
===
match
---
name: max_recursion_depth [56687,56706]
name: max_recursion_depth [56639,56658]
===
match
---
simple_stmt [86427,86466]
simple_stmt [86379,86418]
===
match
---
operator: , [83966,83967]
operator: , [83918,83919]
===
match
---
name: perm [18988,18992]
name: perm [18988,18992]
===
match
---
name: provide_session [89601,89616]
name: provide_session [89553,89568]
===
match
---
name: next_run_date [26532,26545]
name: next_run_date [26484,26497]
===
match
---
name: next_dagrun_create_after [93457,93481]
name: next_dagrun_create_after [93409,93433]
===
match
---
name: timezone [22371,22379]
name: timezone [22347,22355]
===
match
---
operator: , [3025,3026]
operator: , [3025,3026]
===
match
---
expr_stmt [37918,38060]
expr_stmt [37870,38012]
===
match
---
trailer [87417,87427]
trailer [87369,87379]
===
match
---
funcdef [95081,97053]
funcdef [95033,97005]
===
match
---
operator: != [29092,29094]
operator: != [29044,29046]
===
match
---
name: State [58373,58378]
name: State [58325,58330]
===
match
---
operator: = [53509,53510]
operator: = [53461,53462]
===
match
---
trailer [17642,17657]
trailer [17642,17657]
===
match
---
name: settings [32217,32225]
name: settings [32169,32177]
===
match
---
atom_expr [67862,67875]
atom_expr [67814,67827]
===
match
---
name: task_dict [13027,13036]
name: task_dict [13027,13036]
===
match
---
trailer [83058,83062]
trailer [83010,83014]
===
match
---
if_stmt [52666,52743]
if_stmt [52618,52695]
===
match
---
name: has_on_failure_callback [16385,16408]
name: has_on_failure_callback [16385,16408]
===
match
---
operator: = [87496,87497]
operator: = [87448,87449]
===
match
---
name: date_last_automated_dagrun [26332,26358]
name: date_last_automated_dagrun [26284,26310]
===
match
---
trailer [66178,66188]
trailer [66130,66140]
===
match
---
simple_stmt [2336,2413]
simple_stmt [2336,2413]
===
match
---
operator: , [58178,58179]
operator: , [58130,58131]
===
match
---
name: str [32532,32535]
name: str [32484,32487]
===
match
---
argument [71982,71997]
argument [71934,71949]
===
match
---
name: query [38077,38082]
name: query [38029,38034]
===
match
---
suite [26519,26849]
suite [26471,26801]
===
match
---
return_stmt [97014,97028]
return_stmt [96966,96980]
===
match
---
name: task_id [68188,68195]
name: task_id [68140,68147]
===
match
---
name: Dict [10649,10653]
name: Dict [10649,10653]
===
match
---
atom_expr [83424,83436]
atom_expr [83376,83388]
===
match
---
not_test [92341,92364]
not_test [92293,92316]
===
match
---
name: searchpath [41639,41649]
name: searchpath [41591,41601]
===
match
---
argument [93620,93635]
argument [93572,93587]
===
match
---
name: DagRun [39623,39629]
name: DagRun [39575,39581]
===
match
---
name: max_recursion_depth [54327,54346]
name: max_recursion_depth [54279,54298]
===
match
---
name: traceback [66040,66049]
name: traceback [65992,66001]
===
match
---
trailer [22365,22380]
trailer [22341,22356]
===
match
---
operator: @ [38097,38098]
operator: @ [38049,38050]
===
match
---
name: dag_id [96002,96008]
name: dag_id [95954,95960]
===
match
---
name: end_date [19682,19690]
name: end_date [19682,19690]
===
match
---
simple_stmt [64343,64435]
simple_stmt [64295,64387]
===
match
---
name: state [74568,74573]
name: state [74520,74525]
===
match
---
trailer [39975,39990]
trailer [39927,39942]
===
match
---
name: missing_dag_ids [76375,76390]
name: missing_dag_ids [76327,76342]
===
match
---
expr_stmt [52860,52942]
expr_stmt [52812,52894]
===
match
---
argument [60851,60863]
argument [60803,60815]
===
match
---
decorator [33346,33356]
decorator [33298,33308]
===
match
---
atom_expr [41797,41826]
atom_expr [41749,41778]
===
match
---
name: __name__ [53401,53409]
name: __name__ [53353,53361]
===
match
---
expr_stmt [96724,96753]
expr_stmt [96676,96705]
===
match
---
name: keys [17587,17591]
name: keys [17587,17591]
===
match
---
return_stmt [17257,17281]
return_stmt [17257,17281]
===
match
---
atom_expr [13180,13197]
atom_expr [13180,13197]
===
match
---
atom_expr [20908,20937]
atom_expr [20908,20937]
===
match
---
operator: , [61067,61068]
operator: , [61019,61020]
===
match
---
arglist [20726,20745]
arglist [20726,20745]
===
match
---
if_stmt [53431,53517]
if_stmt [53383,53469]
===
match
---
annassign [10112,10145]
annassign [10112,10145]
===
match
---
trailer [53400,53409]
trailer [53352,53361]
===
match
---
operator: @ [98170,98171]
operator: @ [98122,98123]
===
match
---
trailer [37938,38060]
trailer [37890,38012]
===
match
---
trailer [38180,38185]
trailer [38132,38137]
===
match
---
name: list [46693,46697]
name: list [46645,46649]
===
match
---
name: or_ [1450,1453]
name: or_ [1450,1453]
===
match
---
trailer [32721,32752]
trailer [32673,32704]
===
match
---
name: tasks [65077,65082]
name: tasks [65029,65034]
===
match
---
name: session [47508,47515]
name: session [47460,47467]
===
match
---
expr_stmt [45631,45648]
expr_stmt [45583,45600]
===
match
---
operator: @ [42814,42815]
operator: @ [42766,42767]
===
match
---
name: provide_session [37293,37308]
name: provide_session [37245,37260]
===
match
---
operator: , [55773,55774]
operator: , [55725,55726]
===
match
---
trailer [98259,98280]
trailer [98211,98232]
===
match
---
trailer [91906,91908]
trailer [91858,91860]
===
match
---
name: session [79951,79958]
name: session [79903,79910]
===
match
---
name: pickle [849,855]
name: pickle [849,855]
===
match
---
name: isinstance [62151,62161]
name: isinstance [62103,62113]
===
match
---
expr_stmt [67507,67540]
expr_stmt [67459,67492]
===
match
---
dictorsetmaker [48168,48187]
dictorsetmaker [48120,48139]
===
match
---
operator: , [81887,81888]
operator: , [81839,81840]
===
match
---
return_stmt [31579,31640]
return_stmt [31531,31592]
===
match
---
operator: , [80635,80636]
operator: , [80587,80588]
===
match
---
expr_stmt [87818,87864]
expr_stmt [87770,87816]
===
match
---
trailer [41203,41226]
trailer [41155,41178]
===
match
---
trailer [15095,15109]
trailer [15095,15109]
===
match
---
atom_expr [74725,74740]
atom_expr [74677,74692]
===
match
---
name: self [88891,88895]
name: self [88843,88847]
===
match
---
atom_expr [65782,65800]
atom_expr [65734,65752]
===
match
---
for_stmt [37189,37258]
for_stmt [37141,37210]
===
match
---
simple_stmt [42334,42379]
simple_stmt [42286,42331]
===
match
---
trailer [79073,79078]
trailer [79025,79030]
===
match
---
trailer [60144,60153]
trailer [60096,60105]
===
match
---
operator: = [79476,79477]
operator: = [79428,79429]
===
match
---
name: dttm [20680,20684]
name: dttm [20680,20684]
===
match
---
operator: @ [40044,40045]
operator: @ [39996,39997]
===
match
---
trailer [52712,52727]
trailer [52664,52679]
===
match
---
name: session [93597,93604]
name: session [93549,93556]
===
match
---
name: _type [18059,18064]
name: _type [18059,18064]
===
match
---
name: end_date [58548,58556]
name: end_date [58500,58508]
===
match
---
name: self [22003,22007]
name: self [21979,21983]
===
match
---
simple_stmt [88322,88535]
simple_stmt [88274,88487]
===
match
---
name: func [39960,39964]
name: func [39912,39916]
===
match
---
name: default_view [11078,11090]
name: default_view [11078,11090]
===
match
---
expr_stmt [51259,51274]
expr_stmt [51211,51226]
===
match
---
name: intersection [64503,64515]
name: intersection [64455,64467]
===
match
---
trailer [53088,53098]
trailer [53040,53050]
===
match
---
atom_expr [29298,29309]
atom_expr [29250,29261]
===
match
---
operator: , [60304,60305]
operator: , [60256,60257]
===
match
---
name: template_searchpath [10463,10482]
name: template_searchpath [10463,10482]
===
match
---
simple_stmt [3527,3591]
simple_stmt [3527,3591]
===
match
---
operator: = [59141,59142]
operator: = [59093,59094]
===
match
---
operator: , [56523,56524]
operator: , [56475,56476]
===
match
---
operator: , [89662,89663]
operator: , [89614,89615]
===
match
---
atom_expr [25350,25377]
atom_expr [25302,25329]
===
match
---
trailer [94628,94653]
trailer [94580,94605]
===
match
---
return_stmt [84522,84552]
return_stmt [84474,84504]
===
match
---
name: t [79281,79282]
name: t [79233,79234]
===
match
---
operator: = [57505,57506]
operator: = [57457,57458]
===
match
---
name: self [16931,16935]
name: self [16931,16935]
===
match
---
name: log [94388,94391]
name: log [94340,94343]
===
match
---
operator: = [26390,26391]
operator: = [26342,26343]
===
match
---
atom [29518,29700]
atom [29470,29652]
===
match
---
trailer [78164,78175]
trailer [78116,78127]
===
match
---
operator: , [18888,18889]
operator: , [18888,18889]
===
match
---
simple_stmt [29035,29047]
simple_stmt [28987,28999]
===
match
---
operator: = [37119,37120]
operator: = [37071,37072]
===
match
---
simple_stmt [13857,13997]
simple_stmt [13857,13997]
===
match
---
dotted_name [40640,40664]
dotted_name [40592,40616]
===
match
---
expr_stmt [78215,78252]
expr_stmt [78167,78204]
===
match
---
operator: == [53379,53381]
operator: == [53331,53333]
===
match
---
name: t [66899,66900]
name: t [66851,66852]
===
match
---
name: count [57425,57430]
name: count [57377,57382]
===
match
---
name: next_start [25283,25293]
name: next_start [25235,25245]
===
match
---
name: tis [44297,44300]
name: tis [44249,44252]
===
match
---
operator: = [56629,56630]
operator: = [56581,56582]
===
match
---
name: previous_schedule [25355,25372]
name: previous_schedule [25307,25324]
===
match
---
simple_stmt [65984,66010]
simple_stmt [65936,65962]
===
match
---
arglist [22046,22086]
arglist [22022,22062]
===
match
---
atom_expr [52997,53005]
atom_expr [52949,52957]
===
match
---
simple_stmt [22462,22494]
simple_stmt [22438,22470]
===
match
---
operator: , [76773,76774]
operator: , [76725,76726]
===
match
---
name: task_id [62290,62297]
name: task_id [62242,62249]
===
match
---
atom_expr [16704,16738]
atom_expr [16704,16738]
===
match
---
simple_stmt [71055,71082]
simple_stmt [71007,71034]
===
match
---
atom_expr [35232,35254]
atom_expr [35184,35206]
===
match
---
simple_stmt [28484,28586]
simple_stmt [28436,28538]
===
match
---
comparison [77176,77218]
comparison [77128,77170]
===
match
---
name: TaskInstance [43964,43976]
name: TaskInstance [43916,43928]
===
match
---
simple_stmt [72042,72064]
simple_stmt [71994,72016]
===
match
---
simple_stmt [22736,22809]
simple_stmt [22688,22761]
===
match
---
operator: , [33237,33238]
operator: , [33189,33190]
===
match
---
atom_expr [35142,35164]
atom_expr [35094,35116]
===
match
---
name: tis [53063,53066]
name: tis [53015,53018]
===
match
---
operator: = [59306,59307]
operator: = [59258,59259]
===
match
---
name: session [89664,89671]
name: session [89616,89623]
===
match
---
operator: == [20206,20208]
operator: == [20206,20208]
===
match
---
param [68926,68931]
param [68878,68883]
===
match
---
name: debug [26089,26094]
name: debug [26041,26046]
===
match
---
atom_expr [76832,76856]
atom_expr [76784,76808]
===
match
---
not_test [73679,73691]
not_test [73631,73643]
===
match
---
operator: == [91041,91043]
operator: == [90993,90995]
===
match
---
trailer [66550,66557]
trailer [66502,66509]
===
match
---
atom_expr [14987,15009]
atom_expr [14987,15009]
===
match
---
decorator [40456,40466]
decorator [40408,40418]
===
match
---
param [34711,34715]
param [34663,34667]
===
match
---
operator: , [29326,29327]
operator: , [29278,29279]
===
match
---
name: children [63364,63372]
name: children [63316,63324]
===
match
---
name: dttm [22349,22353]
name: dttm [22325,22329]
===
match
---
name: DeprecationWarning [33643,33661]
name: DeprecationWarning [33595,33613]
===
match
---
trailer [33718,33742]
trailer [33670,33694]
===
match
---
name: dttm [65905,65909]
name: dttm [65857,65861]
===
match
---
tfpdef [65275,65287]
tfpdef [65227,65239]
===
match
---
trailer [20200,20205]
trailer [20200,20205]
===
match
---
parameters [67115,67127]
parameters [67067,67079]
===
match
---
simple_stmt [66465,66481]
simple_stmt [66417,66433]
===
match
---
suite [57436,57458]
suite [57388,57410]
===
match
---
trailer [14453,14471]
trailer [14453,14471]
===
match
---
param [18066,18073]
param [18066,18073]
===
match
---
atom_expr [29532,29666]
atom_expr [29484,29618]
===
match
---
operator: = [68950,68951]
operator: = [68902,68903]
===
match
---
name: self [32009,32013]
name: self [31961,31965]
===
match
---
atom_expr [26503,26518]
atom_expr [26455,26470]
===
match
---
operator: = [29356,29357]
operator: = [29308,29309]
===
match
---
fstring_string: Task  [65607,65612]
fstring_string: Task  [65559,65564]
===
match
---
name: date_last_automated_dagrun [22858,22884]
name: date_last_automated_dagrun [22810,22836]
===
match
---
atom_expr [28664,28695]
atom_expr [28616,28647]
===
match
---
name: new_perm_mapping [18967,18983]
name: new_perm_mapping [18967,18983]
===
match
---
simple_stmt [33149,33288]
simple_stmt [33101,33240]
===
match
---
atom_expr [10556,10584]
atom_expr [10556,10584]
===
match
---
return_stmt [59085,59093]
return_stmt [59037,59045]
===
match
---
name: property [40045,40053]
name: property [39997,40005]
===
match
---
operator: = [93583,93584]
operator: = [93535,93536]
===
match
---
atom_expr [81760,81952]
atom_expr [81712,81904]
===
match
---
name: self [65172,65176]
name: self [65124,65128]
===
match
---
operator: = [25487,25488]
operator: = [25439,25440]
===
match
---
while_stmt [26309,26431]
while_stmt [26261,26383]
===
match
---
name: dag_id [37125,37131]
name: dag_id [37077,37083]
===
match
---
atom_expr [77952,77978]
atom_expr [77904,77930]
===
match
---
trailer [13312,13325]
trailer [13312,13325]
===
match
---
name: start_date [48045,48055]
name: start_date [47997,48007]
===
match
---
operator: , [48454,48455]
operator: , [48406,48407]
===
match
---
operator: , [1488,1489]
operator: , [1488,1489]
===
match
---
operator: , [88481,88482]
operator: , [88433,88434]
===
match
---
parameters [31111,31117]
parameters [31063,31069]
===
match
---
expr_stmt [28109,28134]
expr_stmt [28061,28086]
===
match
---
atom_expr [45716,45726]
atom_expr [45668,45678]
===
match
---
name: ForeignKey [1402,1412]
name: ForeignKey [1402,1412]
===
match
---
name: Optional [10988,10996]
name: Optional [10988,10996]
===
match
---
if_stmt [80921,80969]
if_stmt [80873,80921]
===
match
---
name: t [25919,25920]
name: t [25871,25872]
===
match
---
name: _pickle_id [31156,31166]
name: _pickle_id [31108,31118]
===
match
---
name: hasattr [13528,13535]
name: hasattr [13528,13535]
===
match
---
name: start_date [26822,26832]
name: start_date [26774,26784]
===
match
---
name: include_externally_triggered [29459,29487]
name: include_externally_triggered [29411,29439]
===
match
---
name: tii [55426,55429]
name: tii [55378,55381]
===
match
---
atom [80267,80273]
atom [80219,80225]
===
match
---
dictorsetmaker [62964,62978]
dictorsetmaker [62916,62930]
===
match
---
name: matched_tasks [62444,62457]
name: matched_tasks [62396,62409]
===
match
---
expr_stmt [78467,78511]
expr_stmt [78419,78463]
===
match
---
name: previous [22338,22346]
name: previous [22314,22322]
===
match
---
number: 2 [33686,33687]
number: 2 [33638,33639]
===
match
---
name: get [84932,84935]
name: get [84884,84887]
===
match
---
name: execution_date [39976,39990]
name: execution_date [39928,39942]
===
match
---
name: start_date [43030,43040]
name: start_date [42982,42992]
===
match
---
suite [24732,24757]
suite [24684,24709]
===
match
---
trailer [32050,32062]
trailer [32002,32014]
===
match
---
operator: = [21975,21976]
operator: = [21951,21952]
===
match
---
expr_stmt [41955,41999]
expr_stmt [41907,41951]
===
match
---
trailer [27226,27235]
trailer [27178,27187]
===
match
---
name: timedelta [42996,43005]
name: timedelta [42948,42957]
===
match
---
trailer [18913,18919]
trailer [18913,18919]
===
match
---
operator: , [22913,22914]
operator: , [22865,22866]
===
match
---
name: Optional [72455,72463]
name: Optional [72407,72415]
===
match
---
operator: = [51703,51704]
operator: = [51655,51656]
===
match
---
atom_expr [93405,93415]
atom_expr [93357,93367]
===
match
---
name: airflow [71126,71133]
name: airflow [71078,71085]
===
match
---
suite [46723,47241]
suite [46675,47193]
===
match
---
simple_stmt [87870,88043]
simple_stmt [87822,87995]
===
match
---
name: orientation [15407,15418]
name: orientation [15407,15418]
===
match
---
operator: , [48424,48425]
operator: , [48376,48377]
===
match
---
name: cron_next [20154,20163]
name: cron_next [20154,20163]
===
match
---
operator: = [58771,58772]
operator: = [58723,58724]
===
match
---
name: run [71824,71827]
name: run [71776,71779]
===
match
---
atom_expr [78983,79017]
atom_expr [78935,78969]
===
match
---
atom_expr [43596,43623]
atom_expr [43548,43575]
===
match
---
trailer [36389,36438]
trailer [36341,36390]
===
match
---
name: self [26817,26821]
name: self [26769,26773]
===
match
---
decorator [32903,32920]
decorator [32855,32872]
===
match
---
param [69249,69263]
param [69201,69215]
===
match
---
if_stmt [62148,62400]
if_stmt [62100,62352]
===
match
---
simple_stmt [75475,75861]
simple_stmt [75427,75813]
===
match
---
name: get_next [20079,20087]
name: get_next [20079,20087]
===
match
---
suite [52847,52943]
suite [52799,52895]
===
match
---
name: self [23779,23783]
name: self [23731,23735]
===
match
---
atom_expr [62288,62297]
atom_expr [62240,62249]
===
match
---
decorator [29401,29418]
decorator [29353,29370]
===
match
---
expr_stmt [33906,33974]
expr_stmt [33858,33926]
===
match
---
operator: = [66431,66432]
operator: = [66383,66384]
===
match
---
atom_expr [52866,52942]
atom_expr [52818,52894]
===
match
---
for_stmt [62435,62754]
for_stmt [62387,62706]
===
match
---
name: session [42908,42915]
name: session [42860,42867]
===
match
---
name: values [46713,46719]
name: values [46665,46671]
===
match
---
name: filter [66330,66336]
name: filter [66282,66288]
===
match
---
argument [47824,47836]
argument [47776,47788]
===
match
---
trailer [20016,20056]
trailer [20016,20056]
===
match
---
name: tii [56004,56007]
name: tii [55956,55959]
===
match
---
trailer [51571,51602]
trailer [51523,51554]
===
match
---
atom_expr [76592,76619]
atom_expr [76544,76571]
===
match
---
atom_expr [65469,65481]
atom_expr [65421,65433]
===
match
---
trailer [64944,64954]
trailer [64896,64906]
===
match
---
simple_stmt [63672,63717]
simple_stmt [63624,63669]
===
match
---
name: default_view [31018,31030]
name: default_view [30970,30982]
===
match
---
atom_expr [47598,47616]
atom_expr [47550,47568]
===
match
---
trailer [25424,25459]
trailer [25376,25411]
===
match
---
param [27499,27504]
param [27451,27456]
===
match
---
name: get [18984,18987]
name: get [18984,18987]
===
match
---
name: isinstance [63448,63458]
name: isinstance [63400,63410]
===
match
---
not_test [73708,73735]
not_test [73660,73687]
===
match
---
name: _previous_context_managed_dags [98062,98092]
name: _previous_context_managed_dags [98014,98044]
===
match
---
trailer [66233,66235]
trailer [66185,66187]
===
match
---
funcdef [44445,44662]
funcdef [44397,44614]
===
match
---
operator: , [29812,29813]
operator: , [29764,29765]
===
match
---
name: warn [12504,12508]
name: warn [12504,12508]
===
match
---
simple_stmt [20316,20460]
simple_stmt [20316,20460]
===
match
---
name: state [43750,43755]
name: state [43702,43707]
===
match
---
operator: = [56198,56199]
operator: = [56150,56151]
===
match
---
import_name [1218,1233]
import_name [1218,1233]
===
match
---
name: get_concurrency_reached [32928,32951]
name: get_concurrency_reached [32880,32903]
===
match
---
name: dag_ids [47954,47961]
name: dag_ids [47906,47913]
===
match
---
argument [19710,19749]
argument [19710,19749]
===
match
---
name: self [85282,85286]
name: self [85234,85238]
===
match
---
simple_stmt [58945,58960]
simple_stmt [58897,58912]
===
match
---
argument [56249,56278]
argument [56201,56230]
===
match
---
operator: @ [44667,44668]
operator: @ [44619,44620]
===
match
---
expr_stmt [25477,25499]
expr_stmt [25429,25451]
===
match
---
trailer [32225,32237]
trailer [32177,32189]
===
match
---
operator: = [85350,85351]
operator: = [85302,85303]
===
match
---
operator: , [94725,94726]
operator: , [94677,94678]
===
match
---
string: '_log' [60245,60251]
string: '_log' [60197,60203]
===
match
---
operator: == [33959,33961]
operator: == [33911,33913]
===
match
---
name: DagRun [48020,48026]
name: DagRun [47972,47978]
===
match
---
if_stmt [42931,43114]
if_stmt [42883,43066]
===
match
---
trailer [95706,95711]
trailer [95658,95663]
===
match
---
name: task_id [57111,57118]
name: task_id [57063,57070]
===
match
---
name: settings [32830,32838]
name: settings [32782,32790]
===
match
---
param [97998,98006]
param [97950,97958]
===
match
---
decorators [75363,75397]
decorators [75315,75349]
===
match
---
name: active_dates [37218,37230]
name: active_dates [37170,37182]
===
match
---
operator: = [48570,48571]
operator: = [48522,48523]
===
match
---
subscriptlist [16111,16139]
subscriptlist [16111,16139]
===
match
---
operator: , [85591,85592]
operator: , [85543,85544]
===
match
---
name: memo [62021,62025]
name: memo [61973,61977]
===
match
---
atom_expr [68030,68043]
atom_expr [67982,67995]
===
match
---
trailer [29284,29395]
trailer [29236,29347]
===
match
---
atom_expr [26658,26673]
atom_expr [26610,26625]
===
match
---
name: catchup [15628,15635]
name: catchup [15628,15635]
===
match
---
operator: , [45590,45591]
operator: , [45542,45543]
===
match
---
name: nullable [87582,87590]
name: nullable [87534,87542]
===
match
---
trailer [75325,75342]
trailer [75277,75294]
===
match
---
name: concurrency [88575,88586]
name: concurrency [88527,88538]
===
match
---
name: functools [95336,95345]
name: functools [95288,95297]
===
match
---
operator: , [87580,87581]
operator: , [87532,87533]
===
match
---
operator: = [44357,44358]
operator: = [44309,44310]
===
match
---
name: provide_session [29157,29172]
name: provide_session [29109,29124]
===
match
---
name: Union [2928,2933]
name: Union [2928,2933]
===
match
---
atom_expr [55116,55133]
atom_expr [55068,55085]
===
match
---
trailer [26821,26832]
trailer [26773,26784]
===
match
---
tfpdef [38240,38266]
tfpdef [38192,38218]
===
match
---
name: fileloc [78099,78106]
name: fileloc [78051,78058]
===
match
---
suite [82920,83409]
suite [82872,83361]
===
match
---
if_stmt [2803,2872]
if_stmt [2803,2872]
===
match
---
param [88190,88198]
param [88142,88150]
===
match
---
decorator [32333,32343]
decorator [32285,32295]
===
match
---
not_test [43480,43512]
not_test [43432,43464]
===
match
---
name: default_args [14269,14281]
name: default_args [14269,14281]
===
match
---
trailer [51803,51808]
trailer [51755,51760]
===
match
---
name: self [88833,88837]
name: self [88785,88789]
===
match
---
name: start_date [67512,67522]
name: start_date [67464,67474]
===
match
---
operator: = [33685,33686]
operator: = [33637,33638]
===
match
---
operator: = [69276,69277]
operator: = [69228,69229]
===
match
---
suite [40090,40451]
suite [40042,40403]
===
match
---
name: append [41026,41032]
name: append [40978,40984]
===
match
---
name: any [78786,78789]
name: any [78738,78741]
===
match
---
name: hash_components [17851,17866]
name: hash_components [17851,17866]
===
match
---
param [40482,40486]
param [40434,40438]
===
match
---
operator: = [52228,52229]
operator: = [52180,52181]
===
match
---
atom_expr [81609,81736]
atom_expr [81561,81688]
===
match
---
operator: { [36684,36685]
operator: { [36636,36637]
===
match
---
simple_stmt [18935,19019]
simple_stmt [18935,19019]
===
match
---
atom_expr [67064,67097]
atom_expr [67016,67049]
===
match
---
operator: = [78406,78407]
operator: = [78358,78359]
===
match
---
expr_stmt [14713,14750]
expr_stmt [14713,14750]
===
match
---
trailer [90039,90046]
trailer [89991,89998]
===
match
---
atom_expr [37984,38001]
atom_expr [37936,37953]
===
match
---
import_from [67012,67047]
import_from [66964,66999]
===
match
---
simple_stmt [79855,79871]
simple_stmt [79807,79823]
===
match
---
trailer [22947,22956]
trailer [22899,22908]
===
match
---
operator: == [26655,26657]
operator: == [26607,26609]
===
match
---
name: str [84600,84603]
name: str [84552,84555]
===
match
---
trailer [43156,43163]
trailer [43108,43115]
===
match
---
atom_expr [22930,22957]
atom_expr [22882,22909]
===
match
---
param [24048,24103]
param [24000,24055]
===
match
---
name: pop_context_managed_dag [98191,98214]
name: pop_context_managed_dag [98143,98166]
===
match
---
return_stmt [20254,20266]
return_stmt [20254,20266]
===
match
---
name: active_runs_of_dag [94238,94256]
name: active_runs_of_dag [94190,94208]
===
match
---
trailer [76806,76810]
trailer [76758,76762]
===
match
---
operator: , [1412,1413]
operator: , [1412,1413]
===
match
---
name: active_dates [37274,37286]
name: active_dates [37226,37238]
===
match
---
parameters [47448,47665]
parameters [47400,47617]
===
match
---
name: task_dict [31957,31966]
name: task_dict [31909,31918]
===
match
---
trailer [55417,55425]
trailer [55369,55377]
===
match
---
atom_expr [33303,33315]
atom_expr [33255,33267]
===
match
---
name: self [13725,13729]
name: self [13725,13729]
===
match
---
simple_stmt [64975,65057]
simple_stmt [64927,65009]
===
match
---
simple_stmt [68399,68435]
simple_stmt [68351,68387]
===
match
---
atom_expr [29058,29091]
atom_expr [29010,29043]
===
match
---
name: fn [32325,32327]
name: fn [32277,32279]
===
match
---
file_input [788,98594]
file_input [788,98546]
===
match
---
name: state [77657,77662]
name: state [77609,77614]
===
match
---
trailer [83292,83296]
trailer [83244,83248]
===
match
---
trailer [78146,78158]
trailer [78098,78110]
===
match
---
comparison [39623,39658]
comparison [39575,39610]
===
match
---
simple_stmt [66022,66063]
simple_stmt [65974,66015]
===
match
---
operator: = [60534,60535]
operator: = [60486,60487]
===
match
---
argument [82975,83000]
argument [82927,82952]
===
match
---
trailer [75918,75945]
trailer [75870,75897]
===
match
---
trailer [78222,78229]
trailer [78174,78181]
===
match
---
name: dag [64043,64046]
name: dag [63995,63998]
===
match
---
atom_expr [55051,55061]
atom_expr [55003,55013]
===
match
---
argument [59653,59684]
argument [59605,59636]
===
match
---
name: DagRun [47936,47942]
name: DagRun [47888,47894]
===
match
---
decorated [39783,40039]
decorated [39735,39991]
===
match
---
name: self [23964,23968]
name: self [23916,23920]
===
match
---
tfpdef [11078,11095]
tfpdef [11078,11095]
===
match
---
operator: , [58736,58737]
operator: , [58688,58689]
===
match
---
operator: , [21336,21337]
operator: , [21312,21313]
===
match
---
name: _task_group [68243,68254]
name: _task_group [68195,68206]
===
match
---
trailer [90639,90647]
trailer [90591,90599]
===
match
---
comparison [79100,79132]
comparison [79052,79084]
===
match
---
atom_expr [15623,15635]
atom_expr [15623,15635]
===
match
---
suite [16982,17198]
suite [16982,17198]
===
match
---
name: self [33789,33793]
name: self [33741,33745]
===
match
---
param [11024,11069]
param [11024,11069]
===
match
---
import_name [832,841]
import_name [832,841]
===
match
---
suite [57164,57222]
suite [57116,57174]
===
match
---
arglist [19116,19321]
arglist [19116,19321]
===
match
---
atom_expr [67507,67522]
atom_expr [67459,67474]
===
match
---
decorated [32903,33341]
decorated [32855,33293]
===
match
---
name: dag [94260,94263]
name: dag [94212,94215]
===
match
---
operator: = [37176,37177]
operator: = [37128,37129]
===
match
---
operator: , [48681,48682]
operator: , [48633,48634]
===
match
---
name: timezone [13593,13601]
name: timezone [13593,13601]
===
match
---
name: TaskInstance [43177,43189]
name: TaskInstance [43129,43141]
===
match
---
simple_stmt [2512,2569]
simple_stmt [2512,2569]
===
match
---
atom [23942,24009]
atom [23894,23961]
===
match
---
name: on_failure_callback [11372,11391]
name: on_failure_callback [11372,11391]
===
match
---
simple_stmt [1515,1558]
simple_stmt [1515,1558]
===
match
---
name: query [66313,66318]
name: query [66265,66270]
===
match
---
and_test [23380,23444]
and_test [23332,23396]
===
match
---
import_from [2301,2335]
import_from [2301,2335]
===
match
---
name: self [88166,88170]
name: self [88118,88122]
===
match
---
decorators [82052,82087]
decorators [82004,82039]
===
match
---
operator: = [58681,58682]
operator: = [58633,58634]
===
match
---
trailer [13808,13821]
trailer [13808,13821]
===
match
---
operator: , [14874,14875]
operator: , [14874,14875]
===
match
---
fstring_string: A cyclic dependency occurred in dag:  [47311,47348]
fstring_string: A cyclic dependency occurred in dag:  [47263,47300]
===
match
---
name: add [66473,66476]
name: add [66425,66428]
===
match
---
simple_stmt [28772,28789]
simple_stmt [28724,28741]
===
match
---
simple_stmt [15156,15329]
simple_stmt [15156,15329]
===
match
---
operator: == [34234,34236]
operator: == [34186,34188]
===
match
---
name: cron_next [20106,20115]
name: cron_next [20106,20115]
===
match
---
trailer [87963,88035]
trailer [87915,87987]
===
match
---
name: dag_run_state [58359,58372]
name: dag_run_state [58311,58324]
===
match
---
simple_stmt [80660,80913]
simple_stmt [80612,80865]
===
match
---
name: _task_group [68568,68579]
name: _task_group [68520,68531]
===
match
---
name: do_it [58998,59003]
name: do_it [58950,58955]
===
match
---
trailer [62031,62047]
trailer [61983,61999]
===
match
---
name: task_id [65409,65416]
name: task_id [65361,65368]
===
match
---
name: Optional [11535,11543]
name: Optional [11535,11543]
===
match
---
atom_expr [30442,30464]
atom_expr [30394,30416]
===
match
---
atom_expr [36277,36301]
atom_expr [36229,36253]
===
match
---
dotted_name [2517,2548]
dotted_name [2517,2548]
===
match
---
param [30415,30420]
param [30367,30372]
===
match
---
operator: = [30853,30854]
operator: = [30805,30806]
===
match
---
operator: = [68071,68072]
operator: = [68023,68024]
===
match
---
name: tasks [62249,62254]
name: tasks [62201,62206]
===
match
---
simple_stmt [1264,1313]
simple_stmt [1264,1313]
===
match
---
trailer [37230,37237]
trailer [37182,37189]
===
match
---
return_stmt [39939,40038]
return_stmt [39891,39990]
===
match
---
name: models [2068,2074]
name: models [2068,2074]
===
match
---
testlist_comp [44607,44660]
testlist_comp [44559,44612]
===
match
---
operator: , [72143,72144]
operator: , [72095,72096]
===
match
---
name: Type [1174,1178]
name: Type [1174,1178]
===
match
---
operator: , [2143,2144]
operator: , [2143,2144]
===
match
---
string: 'dag_default_view' [90543,90561]
string: 'dag_default_view' [90495,90513]
===
match
---
name: getboolean [11247,11257]
name: getboolean [11247,11257]
===
match
---
trailer [14179,14192]
trailer [14179,14192]
===
match
---
trailer [72031,72033]
trailer [71983,71985]
===
match
---
operator: = [60861,60862]
operator: = [60813,60814]
===
match
---
parameters [18052,18078]
parameters [18052,18078]
===
match
---
name: date [43011,43015]
name: date [42963,42967]
===
match
---
trailer [53369,53378]
trailer [53321,53330]
===
match
---
name: self [26187,26191]
name: self [26139,26143]
===
match
---
simple_stmt [34258,34295]
simple_stmt [34210,34247]
===
match
---
tfpdef [74997,75020]
tfpdef [74949,74972]
===
match
---
param [38202,38231]
param [38154,38183]
===
match
---
simple_stmt [16779,16796]
simple_stmt [16779,16796]
===
match
---
name: co_filename [12986,12997]
name: co_filename [12986,12997]
===
match
---
name: self [41865,41869]
name: self [41817,41821]
===
match
---
expr_stmt [72007,72033]
expr_stmt [71959,71985]
===
match
---
operator: , [71462,71463]
operator: , [71414,71415]
===
match
---
trailer [87478,87541]
trailer [87430,87493]
===
match
---
param [11157,11217]
param [11157,11217]
===
match
---
operator: = [36500,36501]
operator: = [36452,36453]
===
match
---
name: callback [36354,36362]
name: callback [36306,36314]
===
match
---
operator: , [26832,26833]
operator: , [26784,26785]
===
match
---
trailer [12335,12350]
trailer [12335,12350]
===
match
---
name: hash_components [17791,17806]
name: hash_components [17791,17806]
===
match
---
tfpdef [90714,90729]
tfpdef [90666,90681]
===
match
---
name: self [17268,17272]
name: self [17268,17272]
===
match
---
operator: = [85604,85605]
operator: = [85556,85557]
===
match
---
name: has_on_success_callback [16309,16332]
name: has_on_success_callback [16309,16332]
===
match
---
operator: @ [3671,3672]
operator: @ [3671,3672]
===
match
---
string: """Exclude tasks not included in the subdag from the given TaskGroup.""" [63122,63194]
string: """Exclude tasks not included in the subdag from the given TaskGroup.""" [63074,63146]
===
match
---
atom [40709,40711]
atom [40661,40663]
===
match
---
trailer [67529,67540]
trailer [67481,67492]
===
match
---
suite [13777,13997]
suite [13777,13997]
===
match
---
name: filter [3450,3456]
name: filter [3450,3456]
===
match
---
trailer [30981,30994]
trailer [30933,30946]
===
match
---
trailer [98343,98364]
trailer [98295,98316]
===
match
---
operator: * [96081,96082]
operator: * [96033,96034]
===
match
---
argument [96919,96929]
argument [96871,96881]
===
match
---
name: self [26658,26662]
name: self [26610,26614]
===
match
---
expr_stmt [39494,39753]
expr_stmt [39446,39705]
===
match
---
simple_stmt [41104,41122]
simple_stmt [41056,41074]
===
match
---
trailer [88335,88534]
trailer [88287,88486]
===
match
---
sync_comp_for [78821,78839]
sync_comp_for [78773,78791]
===
match
---
suite [55486,55578]
suite [55438,55530]
===
match
---
operator: = [14082,14083]
operator: = [14082,14083]
===
match
---
trailer [64722,64732]
trailer [64674,64684]
===
match
---
simple_stmt [89101,89174]
simple_stmt [89053,89126]
===
match
---
name: copy [62946,62950]
name: copy [62898,62902]
===
match
---
operator: - [36506,36507]
operator: - [36458,36459]
===
match
---
atom_expr [64759,64768]
atom_expr [64711,64720]
===
match
---
operator: == [77663,77665]
operator: == [77615,77617]
===
match
---
atom_expr [23638,23693]
atom_expr [23590,23645]
===
match
---
operator: = [14383,14384]
operator: = [14383,14384]
===
match
---
parameters [19394,19538]
parameters [19394,19538]
===
match
---
name: dag_tag [79381,79388]
name: dag_tag [79333,79340]
===
match
---
string: """     Python dag decorator. Wraps a function into an Airflow DAG.     Accepts kwargs for operator kwarg. Can be used to parametrize DAGs.      :param dag_args: Arguments for DAG object     :type dag_args: Any     :param dag_kwargs: Kwargs for DAG object.     :type dag_kwargs: Any     """ [94785,95075]
string: """     Python dag decorator. Wraps a function into an Airflow DAG.     Accepts kwargs for operator kwarg. Can be used to parametrize DAGs.      :param dag_args: Arguments for DAG object     :type dag_args: Any     :param dag_kwargs: Kwargs for DAG object.     :type dag_kwargs: Any     """ [94737,95027]
===
match
---
atom_expr [78345,78360]
atom_expr [78297,78312]
===
match
---
trailer [25372,25377]
trailer [25324,25329]
===
match
---
atom_expr [96259,96273]
atom_expr [96211,96225]
===
match
---
trailer [98137,98158]
trailer [98089,98110]
===
match
---
operator: , [40333,40334]
operator: , [40285,40286]
===
match
---
expr_stmt [22462,22493]
expr_stmt [22438,22469]
===
match
---
trailer [52792,52823]
trailer [52744,52775]
===
match
---
name: topological_sort [44911,44927]
name: topological_sort [44863,44879]
===
match
---
name: dag_by_ids [76023,76033]
name: dag_by_ids [75975,75985]
===
match
---
name: task [66795,66799]
name: task [66747,66751]
===
match
---
name: naive [20810,20815]
name: naive [20810,20815]
===
match
---
name: dag [77946,77949]
name: dag [77898,77901]
===
match
---
trailer [52999,53005]
trailer [52951,52957]
===
match
---
param [90731,90762]
param [90683,90714]
===
match
---
atom_expr [83581,83604]
atom_expr [83533,83556]
===
match
---
trailer [36887,36892]
trailer [36839,36844]
===
match
---
operator: , [54772,54773]
operator: , [54724,54725]
===
match
---
trailer [52709,52742]
trailer [52661,52694]
===
match
---
name: resolve_template_files [41204,41226]
name: resolve_template_files [41156,41178]
===
match
---
operator: = [14573,14574]
operator: = [14573,14574]
===
match
---
trailer [34217,34249]
trailer [34169,34201]
===
match
---
expr_stmt [51555,51602]
expr_stmt [51507,51554]
===
match
---
trailer [51778,51785]
trailer [51730,51737]
===
match
---
operator: , [59631,59632]
operator: , [59583,59584]
===
match
---
name: dp [66477,66479]
name: dp [66429,66431]
===
match
---
name: dag_id [90056,90062]
name: dag_id [90008,90014]
===
match
---
name: DagModel [34275,34283]
name: DagModel [34227,34235]
===
match
---
name: self [18009,18013]
name: self [18009,18013]
===
match
---
funcdef [82091,83437]
funcdef [82043,83389]
===
match
---
decorator [66974,66984]
decorator [66926,66936]
===
match
---
name: self [94110,94114]
name: self [94062,94066]
===
match
---
simple_stmt [2413,2465]
simple_stmt [2413,2465]
===
match
---
atom_expr [64941,64961]
atom_expr [64893,64913]
===
match
---
expr_stmt [22282,22321]
expr_stmt [22258,22297]
===
match
---
name: self [41797,41801]
name: self [41749,41753]
===
match
---
name: doc_md [16462,16468]
name: doc_md [16462,16468]
===
match
---
atom_expr [80924,80943]
atom_expr [80876,80895]
===
match
---
name: d [66022,66023]
name: d [65974,65975]
===
match
---
operator: , [77632,77633]
operator: , [77584,77585]
===
match
---
import_as_names [1042,1200]
import_as_names [1042,1200]
===
match
---
trailer [52702,52709]
trailer [52654,52661]
===
match
---
funcdef [84558,85022]
funcdef [84510,84974]
===
match
---
suite [17378,17869]
suite [17378,17869]
===
match
---
operator: , [47658,47659]
operator: , [47610,47611]
===
match
---
name: also_include [63034,63046]
name: also_include [62986,62998]
===
match
---
suite [73692,73888]
suite [73644,73840]
===
match
---
trailer [46712,46719]
trailer [46664,46671]
===
match
---
name: classmethod [92582,92593]
name: classmethod [92534,92545]
===
match
---
atom [76326,76366]
atom [76278,76318]
===
match
---
suite [26674,26748]
suite [26626,26700]
===
match
---
name: task_dict [68404,68413]
name: task_dict [68356,68365]
===
match
---
atom_expr [89479,89490]
atom_expr [89431,89442]
===
match
---
atom_expr [22046,22079]
atom_expr [22022,22055]
===
match
---
trailer [40900,40909]
trailer [40852,40861]
===
match
---
operator: , [58386,58387]
operator: , [58338,58339]
===
match
---
trailer [66521,66528]
trailer [66473,66480]
===
match
---
string: 'gantt' [3018,3025]
string: 'gantt' [3018,3025]
===
match
---
name: self [29901,29905]
name: self [29853,29857]
===
match
---
name: filter [37816,37822]
name: filter [37768,37774]
===
match
---
atom_expr [87265,87277]
atom_expr [87217,87229]
===
match
---
name: str [89696,89699]
name: str [89648,89651]
===
match
---
name: downstream_task_id [42543,42561]
name: downstream_task_id [42495,42513]
===
match
---
name: tii [55703,55706]
name: tii [55655,55658]
===
match
---
name: using_end_date [28109,28123]
name: using_end_date [28061,28075]
===
match
---
trailer [65516,65526]
trailer [65468,65478]
===
match
---
return_stmt [29139,29150]
return_stmt [29091,29102]
===
match
---
name: used_group_ids [68580,68594]
name: used_group_ids [68532,68546]
===
match
---
name: timezone [14084,14092]
name: timezone [14084,14092]
===
match
---
simple_stmt [91763,91862]
simple_stmt [91715,91814]
===
match
---
name: get_tis [52360,52367]
name: get_tis [52312,52319]
===
match
---
name: self [14322,14326]
name: self [14322,14326]
===
match
---
dotted_name [30571,30594]
dotted_name [30523,30546]
===
match
---
parameters [39103,39145]
parameters [39055,39097]
===
match
---
expr_stmt [15388,15418]
expr_stmt [15388,15418]
===
match
---
trailer [76560,76576]
trailer [76512,76528]
===
match
---
simple_stmt [17791,17825]
simple_stmt [17791,17825]
===
match
---
operator: , [1148,1149]
operator: , [1148,1149]
===
match
---
name: back [12921,12925]
name: back [12921,12925]
===
match
---
return_stmt [16884,16914]
return_stmt [16884,16914]
===
match
---
operator: = [75459,75460]
operator: = [75411,75412]
===
match
---
name: self [16487,16491]
name: self [16487,16491]
===
match
---
suite [58463,58912]
suite [58415,58864]
===
match
---
operator: , [83860,83861]
operator: , [83812,83813]
===
match
---
operator: = [65879,65880]
operator: = [65831,65832]
===
match
---
name: subdag_lst [41015,41025]
name: subdag_lst [40967,40977]
===
match
---
trailer [22894,22913]
trailer [22846,22865]
===
match
---
name: task [44854,44858]
name: task [44806,44810]
===
match
---
trailer [13411,13444]
trailer [13411,13444]
===
match
---
simple_stmt [75114,75307]
simple_stmt [75066,75259]
===
match
---
subscriptlist [60999,61032]
subscriptlist [60951,60984]
===
match
---
suite [85635,85661]
suite [85587,85613]
===
match
---
string: 'idx_root_dag_id' [87903,87920]
string: 'idx_root_dag_id' [87855,87872]
===
match
---
name: __serialized_fields [83585,83604]
name: __serialized_fields [83537,83556]
===
match
---
atom_expr [34275,34293]
atom_expr [34227,34245]
===
match
---
atom_expr [22580,22610]
atom_expr [22532,22562]
===
match
---
atom_expr [22349,22380]
atom_expr [22325,22356]
===
match
---
atom_expr [63672,63716]
atom_expr [63624,63668]
===
match
---
simple_stmt [65670,65677]
simple_stmt [65622,65629]
===
match
---
expr_stmt [28071,28100]
expr_stmt [28023,28052]
===
match
---
trailer [51937,52656]
trailer [51889,52608]
===
match
---
name: access_control [18587,18601]
name: access_control [18587,18601]
===
match
---
name: orm_dag [79513,79520]
name: orm_dag [79465,79472]
===
match
---
name: concurrency [10769,10780]
name: concurrency [10769,10780]
===
match
---
trailer [75342,75357]
trailer [75294,75309]
===
match
---
not_test [38629,38659]
not_test [38581,38611]
===
match
---
comparison [43854,43867]
comparison [43806,43819]
===
match
---
argument [83663,83676]
argument [83615,83628]
===
match
---
atom_expr [76393,76429]
atom_expr [76345,76381]
===
match
---
trailer [98103,98124]
trailer [98055,98076]
===
match
---
name: pendulum [22968,22976]
name: pendulum [22920,22928]
===
match
---
atom_expr [26590,26625]
atom_expr [26542,26577]
===
match
---
if_stmt [79378,79595]
if_stmt [79330,79547]
===
match
---
decorator [30570,30595]
decorator [30522,30547]
===
match
---
name: make_aware [21320,21330]
name: make_aware [21296,21306]
===
match
---
name: session [75349,75356]
name: session [75301,75308]
===
match
---
name: tis [53305,53308]
name: tis [53257,53260]
===
match
---
name: DagModel [33926,33934]
name: DagModel [33878,33886]
===
match
---
simple_stmt [77478,77868]
simple_stmt [77430,77820]
===
match
---
name: full_filepath [10418,10431]
name: full_filepath [10418,10431]
===
match
---
simple_stmt [80245,80284]
simple_stmt [80197,80236]
===
match
---
name: d [65670,65671]
name: d [65622,65623]
===
match
---
name: end_date [71345,71353]
name: end_date [71297,71305]
===
match
---
trailer [13861,13874]
trailer [13861,13874]
===
match
---
argument [56764,56779]
argument [56716,56731]
===
match
---
name: str [11170,11173]
name: str [11170,11173]
===
match
---
name: session [66305,66312]
name: session [66257,66264]
===
match
---
operator: = [42901,42902]
operator: = [42853,42854]
===
match
---
name: t [62738,62739]
name: t [62690,62691]
===
match
---
simple_stmt [40099,40201]
simple_stmt [40051,40153]
===
match
---
name: max_active_tasks [30496,30512]
name: max_active_tasks [30448,30464]
===
match
---
suite [37380,38092]
suite [37332,38044]
===
match
---
name: get_task [36573,36581]
name: get_task [36525,36533]
===
match
---
name: self [36277,36281]
name: self [36229,36233]
===
match
---
trailer [36581,36593]
trailer [36533,36545]
===
match
---
name: type [40890,40894]
name: type [40842,40846]
===
match
---
trailer [81880,81887]
trailer [81832,81839]
===
match
---
name: classmethod [58096,58107]
name: classmethod [58048,58059]
===
match
---
name: external_trigger [37343,37359]
name: external_trigger [37295,37311]
===
match
---
name: Optional [19453,19461]
name: Optional [19453,19461]
===
match
---
argument [17126,17196]
argument [17126,17196]
===
match
---
operator: = [53974,53975]
operator: = [53926,53927]
===
match
---
atom_expr [27225,27235]
atom_expr [27177,27187]
===
match
---
fstring_expr [59233,59240]
fstring_expr [59185,59192]
===
match
---
import_from [1963,2007]
import_from [1963,2007]
===
match
---
trailer [27351,27367]
trailer [27303,27319]
===
match
---
name: difference [76401,76411]
name: difference [76353,76363]
===
match
---
comparison [77650,77679]
comparison [77602,77631]
===
match
---
trailer [96746,96753]
trailer [96698,96705]
===
match
---
trailer [53076,53084]
trailer [53028,53036]
===
match
---
name: DagRun [37101,37107]
name: DagRun [37053,37059]
===
match
---
trailer [33966,33973]
trailer [33918,33925]
===
match
---
name: self [13308,13312]
name: self [13308,13312]
===
match
---
simple_stmt [92394,92421]
simple_stmt [92346,92373]
===
match
---
operator: == [55062,55064]
operator: == [55014,55016]
===
match
---
trailer [26210,26238]
trailer [26162,26190]
===
match
---
atom_expr [63576,63589]
atom_expr [63528,63541]
===
match
---
name: int [10830,10833]
name: int [10830,10833]
===
match
---
name: is_paused [86142,86151]
name: is_paused [86094,86103]
===
match
---
name: end_date [52814,52822]
name: end_date [52766,52774]
===
match
---
trailer [80406,80419]
trailer [80358,80371]
===
match
---
name: tis [43123,43126]
name: tis [43075,43078]
===
match
---
name: task_dict [65517,65526]
name: task_dict [65469,65478]
===
match
---
name: append [37231,37237]
name: append [37183,37189]
===
match
---
suite [17674,17745]
suite [17674,17745]
===
match
---
param [81241,81253]
param [81193,81205]
===
match
---
trailer [48117,48132]
trailer [48069,48084]
===
match
---
name: self [24806,24810]
name: self [24758,24762]
===
match
---
dictorsetmaker [62935,63046]
dictorsetmaker [62887,62998]
===
match
---
atom_expr [22003,22016]
atom_expr [21979,21992]
===
match
---
atom_expr [44624,44634]
atom_expr [44576,44586]
===
match
---
name: self [45610,45614]
name: self [45562,45566]
===
match
---
name: end_date [52040,52048]
name: end_date [51992,52000]
===
match
---
dotted_name [2470,2491]
dotted_name [2470,2491]
===
match
---
operator: @ [89582,89583]
operator: @ [89534,89535]
===
match
---
expr_stmt [95686,95728]
expr_stmt [95638,95680]
===
match
---
trailer [95942,95951]
trailer [95894,95903]
===
match
---
operator: = [10914,10915]
operator: = [10914,10915]
===
match
---
name: execution_date [38634,38648]
name: execution_date [38586,38600]
===
match
---
atom_expr [48111,48132]
atom_expr [48063,48084]
===
match
---
trailer [60355,60375]
trailer [60307,60327]
===
match
---
name: updated_access_control [18844,18866]
name: updated_access_control [18844,18866]
===
match
---
suite [92365,92421]
suite [92317,92373]
===
match
---
name: task_ids [82876,82884]
name: task_ids [82828,82836]
===
match
---
name: visited_external_tis [53434,53454]
name: visited_external_tis [53386,53406]
===
match
---
operator: , [26607,26608]
operator: , [26559,26560]
===
match
---
arglist [40788,40808]
arglist [40740,40760]
===
match
---
funcdef [93643,94745]
funcdef [93595,94697]
===
match
---
operator: = [55360,55361]
operator: = [55312,55313]
===
match
---
operator: , [40391,40392]
operator: , [40343,40344]
===
match
---
name: airflow [1786,1793]
name: airflow [1786,1793]
===
match
---
operator: , [60287,60288]
operator: , [60239,60240]
===
match
---
name: dagrun [2075,2081]
name: dagrun [2075,2081]
===
match
---
operator: , [11556,11557]
operator: , [11556,11557]
===
match
---
argument [31624,31639]
argument [31576,31591]
===
match
---
trailer [36322,36342]
trailer [36274,36294]
===
match
---
atom_expr [98256,98280]
atom_expr [98208,98232]
===
match
---
name: filter [44119,44125]
name: filter [44071,44077]
===
match
---
name: provide_session [80573,80588]
name: provide_session [80525,80540]
===
match
---
operator: >= [94257,94259]
operator: >= [94209,94211]
===
match
---
if_stmt [57466,57770]
if_stmt [57418,57722]
===
match
---
name: staticmethod [80555,80567]
name: staticmethod [80507,80519]
===
match
---
name: tasks [41183,41188]
name: tasks [41135,41140]
===
match
---
trailer [90562,90568]
trailer [90514,90520]
===
match
---
name: task [68322,68326]
name: task [68274,68278]
===
match
---
name: dag [75968,75971]
name: dag [75920,75923]
===
match
---
suite [54347,54849]
suite [54299,54801]
===
match
---
name: copy [11969,11973]
name: copy [11969,11973]
===
match
---
name: session [79943,79950]
name: session [79895,79902]
===
match
---
trailer [18098,18122]
trailer [18098,18122]
===
match
---
name: DAG [98548,98551]
name: DAG [98500,98503]
===
match
---
trailer [38969,39024]
trailer [38921,38976]
===
match
---
name: next_run_date [26416,26429]
name: next_run_date [26368,26381]
===
match
---
name: NativeEnvironment [41961,41978]
name: NativeEnvironment [41913,41930]
===
match
---
trailer [65686,65702]
trailer [65638,65654]
===
match
---
name: Optional [10738,10746]
name: Optional [10738,10746]
===
match
---
trailer [25300,25319]
trailer [25252,25271]
===
match
---
expr_stmt [64447,64542]
expr_stmt [64399,64494]
===
match
---
trailer [33162,33168]
trailer [33114,33120]
===
match
---
comparison [3548,3589]
comparison [3548,3589]
===
match
---
parameters [60584,60607]
parameters [60536,60559]
===
match
---
name: datetime [10392,10400]
name: datetime [10392,10400]
===
match
---
trailer [42352,42378]
trailer [42304,42330]
===
match
---
name: self [15388,15392]
name: self [15388,15392]
===
match
---
name: start_date [25940,25950]
name: start_date [25892,25902]
===
match
---
name: normalized_schedule_interval [22779,22807]
name: normalized_schedule_interval [22731,22759]
===
match
---
atom_expr [65954,65971]
atom_expr [65906,65923]
===
match
---
name: str [13043,13046]
name: str [13043,13046]
===
match
---
name: provide_session [72070,72085]
name: provide_session [72022,72037]
===
match
---
name: self [68926,68930]
name: self [68878,68882]
===
match
---
expr_stmt [64652,64740]
expr_stmt [64604,64692]
===
match
---
simple_stmt [1826,1879]
simple_stmt [1826,1879]
===
match
---
name: end_date [14073,14081]
name: end_date [14073,14081]
===
match
---
name: dag_obj [97021,97028]
name: dag_obj [96973,96980]
===
match
---
name: tis [36502,36505]
name: tis [36454,36457]
===
match
---
name: tis [57021,57024]
name: tis [56973,56976]
===
match
---
param [61043,61068]
param [60995,61020]
===
match
---
operator: = [87885,87886]
operator: = [87837,87838]
===
match
---
string: 'task_ids' [17532,17542]
string: 'task_ids' [17532,17542]
===
match
---
name: query [39040,39045]
name: query [38992,38997]
===
match
---
trailer [56972,56980]
trailer [56924,56932]
===
match
---
operator: = [33802,33803]
operator: = [33754,33755]
===
match
---
expr_stmt [12331,12391]
expr_stmt [12331,12391]
===
match
---
decorator [80572,80589]
decorator [80524,80541]
===
match
---
expr_stmt [46944,46958]
expr_stmt [46896,46910]
===
match
---
test [37984,38045]
test [37936,37997]
===
match
---
suite [84646,85022]
suite [84598,84974]
===
match
---
name: self [35232,35236]
name: self [35184,35188]
===
match
---
return_stmt [32039,32062]
return_stmt [31991,32014]
===
match
---
simple_stmt [1313,1362]
simple_stmt [1313,1362]
===
match
---
trailer [89138,89165]
trailer [89090,89117]
===
match
---
trailer [58059,58066]
trailer [58011,58018]
===
match
---
annassign [14728,14750]
annassign [14728,14750]
===
match
---
atom_expr [22470,22493]
atom_expr [22446,22469]
===
match
---
trailer [65857,65878]
trailer [65809,65830]
===
match
---
operator: , [59733,59734]
operator: , [59685,59686]
===
match
---
name: is_ [83059,83062]
name: is_ [83011,83014]
===
match
---
trailer [43300,43304]
trailer [43252,43256]
===
match
---
decorator [29156,29173]
decorator [29108,29125]
===
match
---
arglist [89479,89566]
arglist [89431,89518]
===
match
---
name: DagRun [74335,74341]
name: DagRun [74287,74293]
===
match
---
name: val [17560,17563]
name: val [17560,17563]
===
match
---
name: dag_id [10187,10193]
name: dag_id [10187,10193]
===
match
---
name: tasks [27250,27255]
name: tasks [27202,27207]
===
match
---
decorated [90669,91341]
decorated [90621,91293]
===
match
---
name: dag [65115,65118]
name: dag [65067,65070]
===
match
---
trailer [81935,81937]
trailer [81887,81889]
===
match
---
string: """         Return (and lock) a list of Dag objects that are due to create a new DagRun.          This will return a resultset of rows  that is row-level-locked with a "SELECT ... FOR UPDATE" query,         you should ensure that any scheduling decisions are made in a single transaction -- as soon as the         transaction is committed it will be unlocked.         """ [92655,93026]
string: """         Return (and lock) a list of Dag objects that are due to create a new DagRun.          This will return a resultset of rows  that is row-level-locked with a "SELECT ... FOR UPDATE" query,         you should ensure that any scheduling decisions are made in a single transaction -- as soon as the         transaction is committed it will be unlocked.         """ [92607,92978]
===
match
---
name: settings [13604,13612]
name: settings [13604,13612]
===
match
---
simple_stmt [97185,97246]
simple_stmt [97137,97198]
===
match
---
trailer [79002,79017]
trailer [78954,78969]
===
match
---
simple_stmt [42026,42108]
simple_stmt [41978,42060]
===
match
---
trailer [85921,85937]
trailer [85873,85889]
===
match
---
name: is_paused [91266,91275]
name: is_paused [91218,91227]
===
match
---
param [65172,65177]
param [65124,65129]
===
match
---
atom_expr [10738,10752]
atom_expr [10738,10752]
===
match
---
string: 'core' [88657,88663]
string: 'core' [88609,88615]
===
match
---
name: timezone [22580,22588]
name: timezone [22532,22540]
===
match
---
operator: { [55702,55703]
operator: { [55654,55655]
===
match
---
name: dag [78408,78411]
name: dag [78360,78363]
===
match
---
atom_expr [40949,40963]
atom_expr [40901,40915]
===
match
---
name: self [85651,85655]
name: self [85603,85607]
===
match
---
param [10418,10454]
param [10418,10454]
===
match
---
name: EdgeInfoType [16126,16138]
name: EdgeInfoType [16126,16138]
===
match
---
trailer [30446,30464]
trailer [30398,30416]
===
match
---
atom_expr [85282,85349]
atom_expr [85234,85301]
===
match
---
name: first [66228,66233]
name: first [66180,66185]
===
match
---
operator: @ [31749,31750]
operator: @ [31701,31702]
===
match
---
expr_stmt [63759,63808]
expr_stmt [63711,63760]
===
match
---
name: is_paused [34284,34293]
name: is_paused [34236,34245]
===
match
---
operator: = [3601,3602]
operator: = [3601,3602]
===
match
---
trailer [82755,82762]
trailer [82707,82714]
===
match
---
name: _parent_group [63315,63328]
name: _parent_group [63267,63280]
===
match
---
name: str [21788,21791]
name: str [21764,21767]
===
match
---
simple_stmt [95221,95255]
simple_stmt [95173,95207]
===
match
---
atom_expr [36318,36342]
atom_expr [36270,36294]
===
match
---
name: setter [31756,31762]
name: setter [31708,31714]
===
match
---
name: execution_date [43238,43252]
name: execution_date [43190,43204]
===
match
---
operator: = [83128,83129]
operator: = [83080,83081]
===
match
---
name: start_date [27505,27515]
name: start_date [27457,27467]
===
match
---
comp_op [92000,92006]
comp_op [91952,91958]
===
match
---
operator: == [91150,91152]
operator: == [91102,91104]
===
match
---
suite [35181,35292]
suite [35133,35244]
===
match
---
string: 'reason' [36685,36693]
string: 'reason' [36637,36645]
===
match
---
name: conf [80448,80452]
name: conf [80400,80404]
===
match
---
suite [63480,63717]
suite [63432,63669]
===
match
---
atom_expr [67878,67891]
atom_expr [67830,67843]
===
match
---
name: rerun_failed_tasks [69291,69309]
name: rerun_failed_tasks [69243,69261]
===
match
---
trailer [96266,96273]
trailer [96218,96225]
===
match
---
trailer [81039,81055]
trailer [80991,81007]
===
match
---
comparison [79381,79409]
comparison [79333,79361]
===
match
---
operator: = [76017,76018]
operator: = [75969,75970]
===
match
---
atom_expr [94624,94653]
atom_expr [94576,94605]
===
match
---
name: self [31112,31116]
name: self [31064,31068]
===
match
---
atom_expr [62029,62047]
atom_expr [61981,61999]
===
match
---
arglist [96636,96647]
arglist [96588,96599]
===
match
---
name: run_id [38929,38935]
name: run_id [38881,38887]
===
match
---
trailer [93348,93353]
trailer [93300,93305]
===
match
---
comp_if [62255,62298]
comp_if [62207,62250]
===
match
---
name: dttm [28963,28967]
name: dttm [28915,28919]
===
match
---
atom_expr [74335,74691]
atom_expr [74287,74643]
===
match
---
simple_stmt [44297,44345]
simple_stmt [44249,44297]
===
match
---
name: property [34301,34309]
name: property [34253,34261]
===
match
---
operator: , [19473,19474]
operator: , [19473,19474]
===
match
---
string: """Return nodes with no children. These are last to execute and are called leaves or leaf nodes.""" [44729,44828]
string: """Return nodes with no children. These are last to execute and are called leaves or leaf nodes.""" [44681,44780]
===
match
---
atom_expr [67835,67848]
atom_expr [67787,67800]
===
match
---
expr_stmt [15091,15129]
expr_stmt [15091,15129]
===
match
---
name: task [66992,66996]
name: task [66944,66948]
===
match
---
name: self [88969,88973]
name: self [88921,88925]
===
match
---
operator: , [42541,42542]
operator: , [42493,42494]
===
match
---
atom_expr [88621,88642]
atom_expr [88573,88594]
===
match
---
name: reason [35556,35562]
name: reason [35508,35514]
===
match
---
name: tasks [68865,68870]
name: tasks [68817,68822]
===
match
---
atom_expr [62964,62973]
atom_expr [62916,62925]
===
match
---
trailer [22929,22987]
trailer [22881,22939]
===
match
---
if_stmt [38626,38749]
if_stmt [38578,38701]
===
match
---
operator: -> [29826,29828]
operator: -> [29778,29780]
===
match
---
simple_stmt [65813,65844]
simple_stmt [65765,65796]
===
match
---
name: orm_dag [78626,78633]
name: orm_dag [78578,78585]
===
match
---
name: _previous_context_managed_dags [97895,97925]
name: _previous_context_managed_dags [97847,97877]
===
match
---
if_stmt [98017,98126]
if_stmt [97969,98078]
===
match
---
name: str [29740,29743]
name: str [29692,29695]
===
match
---
string: 'RL' [3079,3083]
string: 'RL' [3079,3083]
===
match
---
if_stmt [79235,79595]
if_stmt [79187,79547]
===
match
---
tfpdef [72376,72406]
tfpdef [72328,72358]
===
match
---
decorator [91346,91359]
decorator [91298,91311]
===
match
---
name: jinja_environment_kwargs [41802,41826]
name: jinja_environment_kwargs [41754,41778]
===
match
---
name: is_active [86342,86351]
name: is_active [86294,86303]
===
match
---
atom_expr [78303,78320]
atom_expr [78255,78272]
===
match
---
annassign [12799,12821]
annassign [12799,12821]
===
match
---
decorated [98494,98594]
decorated [98446,98546]
===
match
---
name: orm_dag [78345,78352]
name: orm_dag [78297,78304]
===
match
---
operator: == [43197,43199]
operator: == [43149,43151]
===
match
---
trailer [16579,16603]
trailer [16579,16603]
===
match
---
atom_expr [78363,78374]
atom_expr [78315,78326]
===
match
---
trailer [82875,82885]
trailer [82827,82837]
===
match
---
name: Column [87265,87271]
name: Column [87217,87223]
===
match
---
parameters [41254,41260]
parameters [41206,41212]
===
match
---
name: airflow [2101,2108]
name: airflow [2101,2108]
===
match
---
name: str [29821,29824]
name: str [29773,29776]
===
match
---
param [33789,33794]
param [33741,33746]
===
match
---
parameters [88165,88199]
parameters [88117,88151]
===
match
---
string: 'dag_default_view' [80470,80488]
string: 'dag_default_view' [80422,80440]
===
match
---
name: cast [53825,53829]
name: cast [53777,53781]
===
match
---
name: dag [78598,78601]
name: dag [78550,78553]
===
match
---
name: result [60062,60068]
name: result [60014,60020]
===
match
---
operator: , [13540,13541]
operator: , [13540,13541]
===
match
---
name: name [96614,96618]
name: name [96566,96570]
===
match
---
operator: = [56459,56460]
operator: = [56411,56412]
===
match
---
name: start_date [67530,67540]
name: start_date [67482,67492]
===
match
---
name: self [16779,16783]
name: self [16779,16783]
===
match
---
simple_stmt [98340,98408]
simple_stmt [98292,98360]
===
match
---
simple_stmt [16380,16448]
simple_stmt [16380,16448]
===
match
---
import_from [70983,71041]
import_from [70935,70993]
===
match
---
trailer [40222,40402]
trailer [40174,40354]
===
match
---
suite [29502,29701]
suite [29454,29653]
===
match
---
name: query [39954,39959]
name: query [39906,39911]
===
match
---
trailer [41411,41418]
trailer [41363,41370]
===
match
---
import_from [40635,40686]
import_from [40587,40638]
===
match
---
number: 2 [40390,40391]
number: 2 [40342,40343]
===
match
---
trailer [74122,74148]
trailer [74074,74100]
===
match
---
trailer [11102,11106]
trailer [11102,11106]
===
match
---
simple_stmt [93190,93543]
simple_stmt [93142,93495]
===
match
---
param [58396,58410]
param [58348,58362]
===
match
---
name: self [16304,16308]
name: self [16304,16308]
===
match
---
param [95093,95104]
param [95045,95056]
===
match
---
name: count [58969,58974]
name: count [58921,58926]
===
match
---
trailer [81028,81035]
trailer [80980,80987]
===
match
---
trailer [79912,79929]
trailer [79864,79881]
===
match
---
operator: , [42879,42880]
operator: , [42831,42832]
===
match
---
name: Column [87729,87735]
name: Column [87681,87687]
===
match
---
funcdef [74972,75358]
funcdef [74924,75310]
===
match
---
name: dag_id [33216,33222]
name: dag_id [33168,33174]
===
match
---
param [68988,69007]
param [68940,68959]
===
match
---
name: session [93628,93635]
name: session [93580,93587]
===
match
---
operator: -> [32806,32808]
operator: -> [32758,32760]
===
match
---
expr_stmt [14660,14704]
expr_stmt [14660,14704]
===
match
---
if_stmt [14305,14440]
if_stmt [14305,14440]
===
match
---
atom_expr [65069,65083]
atom_expr [65021,65035]
===
match
---
simple_stmt [65143,65154]
simple_stmt [65095,65106]
===
match
---
parameters [41153,41159]
parameters [41105,41111]
===
match
---
trailer [54958,55199]
trailer [54910,55151]
===
match
---
atom_expr [72169,72187]
atom_expr [72121,72139]
===
match
---
name: warnings [75114,75122]
name: warnings [75066,75074]
===
match
---
operator: , [58530,58531]
operator: , [58482,58483]
===
match
---
trailer [68226,68234]
trailer [68178,68186]
===
match
---
name: query [3603,3608]
name: query [3603,3608]
===
match
---
expr_stmt [83618,84513]
expr_stmt [83570,84465]
===
match
---
trailer [55905,56923]
trailer [55857,56875]
===
match
---
simple_stmt [36606,36657]
simple_stmt [36558,36609]
===
match
---
name: conf [74544,74548]
name: conf [74496,74500]
===
match
---
operator: = [2878,2879]
operator: = [2878,2879]
===
match
---
atom_expr [74005,74078]
atom_expr [73957,74030]
===
match
---
name: Optional [10383,10391]
name: Optional [10383,10391]
===
match
---
atom_expr [97095,97134]
atom_expr [97047,97086]
===
match
---
if_stmt [14156,14297]
if_stmt [14156,14297]
===
match
---
name: airflow [67017,67024]
name: airflow [66969,66976]
===
match
---
try_stmt [65718,66063]
try_stmt [65670,66015]
===
match
---
trailer [26507,26518]
trailer [26459,26470]
===
match
---
name: DagModel [89122,89130]
name: DagModel [89074,89082]
===
match
---
name: provide_session [90670,90685]
name: provide_session [90622,90637]
===
match
---
operator: @ [31172,31173]
operator: @ [31124,31125]
===
match
---
operator: == [57431,57433]
operator: == [57383,57385]
===
match
---
atom_expr [3618,3642]
atom_expr [3618,3642]
===
match
---
parameters [42518,42562]
parameters [42470,42514]
===
match
---
parameters [29196,29252]
parameters [29148,29204]
===
match
---
decorated [48224,58090]
decorated [48176,58042]
===
match
---
name: schedule_interval [25016,25033]
name: schedule_interval [24968,24985]
===
match
---
atom_expr [63974,63988]
atom_expr [63926,63940]
===
match
---
string: """         Returns a boolean indicating whether the max_active_tasks limit for this DAG         has been reached         """ [32989,33114]
string: """         Returns a boolean indicating whether the max_active_tasks limit for this DAG         has been reached         """ [32941,33066]
===
match
---
operator: , [59497,59498]
operator: , [59449,59450]
===
match
---
fstring [88913,88936]
fstring [88865,88888]
===
match
---
name: DagRun [38877,38883]
name: DagRun [38829,38835]
===
match
---
operator: , [58606,58607]
operator: , [58558,58559]
===
match
---
decorator [74951,74968]
decorator [74903,74920]
===
match
---
dotted_name [2750,2769]
dotted_name [2750,2769]
===
match
---
trailer [39959,39992]
trailer [39911,39944]
===
match
---
operator: , [84603,84604]
operator: , [84555,84556]
===
match
---
string: """Returns dttm + interval unless dttm is first interval then it returns dttm""" [28838,28918]
string: """Returns dttm + interval unless dttm is first interval then it returns dttm""" [28790,28870]
===
match
---
argument [55751,55773]
argument [55703,55725]
===
match
---
parameters [29438,29493]
parameters [29390,29445]
===
match
---
name: fileloc [87116,87123]
name: fileloc [87068,87075]
===
match
---
name: Optional [72307,72315]
name: Optional [72259,72267]
===
match
---
atom_expr [60487,60508]
atom_expr [60439,60460]
===
match
---
simple_stmt [32318,32328]
simple_stmt [32270,32280]
===
match
---
trailer [13565,13574]
trailer [13565,13574]
===
match
---
expr_stmt [67862,67891]
expr_stmt [67814,67843]
===
match
---
name: full_filepath [12370,12383]
name: full_filepath [12370,12383]
===
match
---
decorator [72069,72086]
decorator [72021,72038]
===
match
---
name: concurrency [30403,30414]
name: concurrency [30355,30366]
===
match
---
name: end_date [27517,27525]
name: end_date [27469,27477]
===
match
---
parameters [84575,84629]
parameters [84527,84581]
===
match
---
operator: -> [93781,93783]
operator: -> [93733,93735]
===
match
---
trailer [71981,71998]
trailer [71933,71950]
===
match
---
funcdef [67103,68660]
funcdef [67055,68612]
===
match
---
operator: = [69235,69236]
operator: = [69187,69188]
===
match
---
comp_op [51672,51678]
comp_op [51624,51630]
===
match
---
operator: , [2157,2158]
operator: , [2157,2158]
===
match
---
expr_stmt [64885,64962]
expr_stmt [64837,64914]
===
match
---
trailer [14899,14915]
trailer [14899,14915]
===
match
---
operator: , [58649,58650]
operator: , [58601,58602]
===
match
---
simple_stmt [42429,42475]
simple_stmt [42381,42427]
===
match
---
name: is_paused_upon_creation [16580,16603]
name: is_paused_upon_creation [16580,16603]
===
match
---
trailer [71823,71827]
trailer [71775,71779]
===
match
---
name: get_task_instances [36464,36482]
name: get_task_instances [36416,36434]
===
match
---
name: DateTime [24094,24102]
name: DateTime [24046,24054]
===
match
---
name: utils [11794,11799]
name: utils [11794,11799]
===
match
---
name: pickle_id [66357,66366]
name: pickle_id [66309,66318]
===
match
---
atom_expr [98340,98364]
atom_expr [98292,98316]
===
match
---
atom_expr [48007,48056]
atom_expr [47959,48008]
===
match
---
suite [92526,92576]
suite [92478,92528]
===
match
---
trailer [83621,83641]
trailer [83573,83593]
===
match
---
trailer [17331,17338]
trailer [17331,17338]
===
match
---
name: query [93190,93195]
name: query [93142,93147]
===
match
---
name: upstream_group_ids [64376,64394]
name: upstream_group_ids [64328,64346]
===
match
---
suite [32030,32063]
suite [31982,32015]
===
match
---
atom_expr [76550,76576]
atom_expr [76502,76528]
===
match
---
suite [73736,73822]
suite [73688,73774]
===
match
---
name: get_tis [56993,57000]
name: get_tis [56945,56952]
===
match
---
name: orm_dag [78139,78146]
name: orm_dag [78091,78098]
===
match
---
import_from [2253,2300]
import_from [2253,2300]
===
match
---
operator: , [32304,32305]
operator: , [32256,32257]
===
match
---
atom_expr [51517,51526]
atom_expr [51469,51478]
===
match
---
name: next_run_date [26641,26654]
name: next_run_date [26593,26606]
===
match
---
name: str [61028,61031]
name: str [60980,60983]
===
match
---
trailer [63566,63575]
trailer [63518,63527]
===
match
---
name: str [10442,10445]
name: str [10442,10445]
===
match
---
name: DeprecationWarning [19272,19290]
name: DeprecationWarning [19272,19290]
===
match
---
operator: = [57691,57692]
operator: = [57643,57644]
===
match
---
atom_expr [64680,64740]
atom_expr [64632,64692]
===
match
---
name: staticmethod [81160,81172]
name: staticmethod [81112,81124]
===
match
---
tfpdef [85051,85072]
tfpdef [85003,85024]
===
match
---
name: dag_id [89070,89076]
name: dag_id [89022,89028]
===
match
---
operator: , [42523,42524]
operator: , [42475,42476]
===
match
---
name: _description [30982,30994]
name: _description [30934,30946]
===
match
---
atom_expr [60522,60533]
atom_expr [60474,60485]
===
match
---
name: sys [873,876]
name: sys [873,876]
===
match
---
funcdef [18040,18125]
funcdef [18040,18125]
===
match
---
return_stmt [20233,20244]
return_stmt [20233,20244]
===
match
---
operator: = [43715,43716]
operator: = [43667,43668]
===
match
---
trailer [66442,66452]
trailer [66394,66404]
===
match
---
trailer [78032,78042]
trailer [77984,77994]
===
match
---
trailer [52876,52942]
trailer [52828,52894]
===
match
---
comparison [54988,55021]
comparison [54940,54973]
===
match
---
trailer [64534,64539]
trailer [64486,64491]
===
match
---
trailer [21757,21786]
trailer [21733,21762]
===
match
---
atom_expr [68092,68105]
atom_expr [68044,68057]
===
match
---
trailer [43488,43512]
trailer [43440,43464]
===
match
---
atom_expr [20209,20219]
atom_expr [20209,20219]
===
match
---
fstring_start: f' [15265,15267]
fstring_start: f' [15265,15267]
===
match
---
expr_stmt [43711,43756]
expr_stmt [43663,43708]
===
match
---
operator: = [11008,11009]
operator: = [11008,11009]
===
match
---
trailer [81730,81734]
trailer [81682,81686]
===
match
---
atom_expr [65239,65249]
atom_expr [65191,65201]
===
match
---
simple_stmt [55326,55367]
simple_stmt [55278,55319]
===
match
---
sync_comp_for [43906,43920]
sync_comp_for [43858,43872]
===
match
---
trailer [93295,93301]
trailer [93247,93253]
===
match
---
name: result [60448,60454]
name: result [60400,60406]
===
match
---
simple_stmt [59046,59073]
simple_stmt [58998,59025]
===
match
---
name: Optional [10693,10701]
name: Optional [10693,10701]
===
match
---
atom_expr [52699,52742]
atom_expr [52651,52694]
===
match
---
simple_stmt [1204,1218]
simple_stmt [1204,1218]
===
match
---
name: tasks [32745,32750]
name: tasks [32697,32702]
===
match
---
param [10536,10610]
param [10536,10610]
===
match
---
operator: @ [35487,35488]
operator: @ [35439,35440]
===
match
---
name: max_active_runs [94264,94279]
name: max_active_runs [94216,94231]
===
match
---
name: self [66997,67001]
name: self [66949,66953]
===
match
---
simple_stmt [71907,71942]
simple_stmt [71859,71894]
===
match
---
atom_expr [84529,84552]
atom_expr [84481,84504]
===
match
---
suite [82168,83437]
suite [82120,83389]
===
match
---
operator: = [85746,85747]
operator: = [85698,85699]
===
match
---
name: question [57550,57558]
name: question [57502,57510]
===
match
---
name: filter [89132,89138]
name: filter [89084,89090]
===
match
---
param [11442,11471]
param [11442,11471]
===
match
---
fstring [74016,74077]
fstring [73968,74029]
===
match
---
simple_stmt [29511,29701]
simple_stmt [29463,29653]
===
match
---
string: 'user_defined_macros' [60188,60209]
string: 'user_defined_macros' [60140,60161]
===
match
---
simple_stmt [89904,90106]
simple_stmt [89856,90058]
===
match
---
suite [52763,52824]
suite [52715,52776]
===
match
---
name: task_type [40954,40963]
name: task_type [40906,40915]
===
match
---
trailer [3445,3449]
trailer [3445,3449]
===
match
---
name: self [23380,23384]
name: self [23332,23336]
===
match
---
trailer [45614,45620]
trailer [45566,45572]
===
match
---
trailer [12943,12950]
trailer [12943,12950]
===
match
---
name: downstream_task_id [85330,85348]
name: downstream_task_id [85282,85300]
===
match
---
name: end_date [56060,56068]
name: end_date [56012,56020]
===
match
---
argument [79943,79958]
argument [79895,79910]
===
match
---
name: unique [87935,87941]
name: unique [87887,87893]
===
match
---
trailer [65076,65082]
trailer [65028,65034]
===
match
---
trailer [77747,77764]
trailer [77699,77716]
===
match
---
atom_expr [79570,79594]
atom_expr [79522,79546]
===
match
---
suite [41456,41508]
suite [41408,41460]
===
match
---
trailer [62936,62944]
trailer [62888,62896]
===
match
---
string: "DAG" [75014,75019]
string: "DAG" [74966,74971]
===
match
---
name: dag_id [83663,83669]
name: dag_id [83615,83621]
===
match
---
string: '/' [32240,32243]
string: '/' [32192,32195]
===
match
---
string: 'max_dagruns_to_create_per_loop' [88101,88133]
string: 'max_dagruns_to_create_per_loop' [88053,88085]
===
match
---
simple_stmt [24114,24676]
simple_stmt [24066,24628]
===
match
---
return_stmt [32823,32897]
return_stmt [32775,32849]
===
match
---
name: expiration_date [81681,81696]
name: expiration_date [81633,81648]
===
match
---
name: Optional [38210,38218]
name: Optional [38162,38170]
===
match
---
simple_stmt [92539,92558]
simple_stmt [92491,92510]
===
match
---
name: subdag [41038,41044]
name: subdag [40990,40996]
===
match
---
name: timezone [21977,21985]
name: timezone [21953,21961]
===
match
---
name: warnings [30152,30160]
name: warnings [30104,30112]
===
match
---
trailer [96635,96648]
trailer [96587,96600]
===
match
---
name: dag_id [54991,54997]
name: dag_id [54943,54949]
===
match
---
operator: == [33223,33225]
operator: == [33175,33177]
===
match
---
atom_expr [38077,38091]
atom_expr [38029,38043]
===
match
---
name: state [44327,44332]
name: state [44279,44284]
===
match
---
simple_stmt [67137,67255]
simple_stmt [67089,67207]
===
match
---
name: str [47647,47650]
name: str [47599,47602]
===
match
---
name: property [44432,44440]
name: property [44384,44392]
===
match
---
name: edge_info [84922,84931]
name: edge_info [84874,84883]
===
match
---
operator: , [11269,11270]
operator: , [11269,11270]
===
match
---
arglist [60711,60864]
arglist [60663,60816]
===
match
---
trailer [27000,27009]
trailer [26952,26961]
===
match
---
name: self [30977,30981]
name: self [30929,30933]
===
match
---
atom_expr [54491,54818]
atom_expr [54443,54770]
===
match
---
operator: , [87647,87648]
operator: , [87599,87600]
===
match
---
trailer [43204,43211]
trailer [43156,43163]
===
match
---
name: group [64476,64481]
name: group [64428,64433]
===
match
---
name: log [94670,94673]
name: log [94622,94625]
===
match
---
name: external_dag_id [55006,55021]
name: external_dag_id [54958,54973]
===
match
---
name: normalize_schedule [28798,28816]
name: normalize_schedule [28750,28768]
===
match
---
atom_expr [87466,87541]
atom_expr [87418,87493]
===
match
---
atom_expr [93731,93748]
atom_expr [93683,93700]
===
match
---
suite [31788,31880]
suite [31740,31832]
===
match
---
expr_stmt [87188,87217]
expr_stmt [87140,87169]
===
match
---
atom_expr [66513,66530]
atom_expr [66465,66482]
===
match
---
operator: = [76722,76723]
operator: = [76674,76675]
===
match
---
simple_stmt [17973,18015]
simple_stmt [17973,18015]
===
match
---
trailer [14870,14886]
trailer [14870,14886]
===
match
---
atom_expr [13397,13444]
atom_expr [13397,13444]
===
match
---
simple_stmt [53057,53100]
simple_stmt [53009,53052]
===
match
---
name: convert_to_utc [21484,21498]
name: convert_to_utc [21460,21474]
===
match
---
name: following [21299,21308]
name: following [21275,21284]
===
match
---
decorator [40044,40054]
decorator [39996,40006]
===
match
---
name: Iterable [61019,61027]
name: Iterable [60971,60979]
===
match
---
name: session [79154,79161]
name: session [79106,79113]
===
match
---
atom_expr [65813,65828]
atom_expr [65765,65780]
===
match
---
name: cls [98531,98534]
name: cls [98483,98486]
===
match
---
simple_stmt [53141,53202]
simple_stmt [53093,53154]
===
match
---
trailer [41087,41095]
trailer [41039,41047]
===
match
---
param [29203,29216]
param [29155,29168]
===
match
---
trailer [63606,63621]
trailer [63558,63573]
===
match
---
atom_expr [94214,94233]
atom_expr [94166,94185]
===
match
---
trailer [76116,76160]
trailer [76068,76112]
===
match
---
operator: = [59576,59577]
operator: = [59528,59529]
===
match
---
name: State [33263,33268]
name: State [33215,33220]
===
match
---
trailer [81968,81978]
trailer [81920,81930]
===
match
---
name: external_trigger [74492,74508]
name: external_trigger [74444,74460]
===
match
---
atom [62963,62979]
atom [62915,62931]
===
match
---
trailer [64515,64542]
trailer [64467,64494]
===
match
---
atom_expr [77240,77255]
atom_expr [77192,77207]
===
match
---
name: visited_external_tis [56948,56968]
name: visited_external_tis [56900,56920]
===
match
---
simple_stmt [19807,19964]
simple_stmt [19807,19964]
===
match
---
trailer [63707,63715]
trailer [63659,63667]
===
match
---
name: repr [17814,17818]
name: repr [17814,17818]
===
match
---
string: """         Creates a dag run from this dag including the tasks associated with this dag.         Returns the dag run.          :param run_id: defines the run id for this dag run         :type run_id: str         :param run_type: type of DagRun         :type run_type: airflow.utils.types.DagRunType         :param execution_date: the execution date of this dag run         :type execution_date: datetime.datetime         :param state: the state of the dag run         :type state: airflow.utils.state.State         :param start_date: the date this dag run should be evaluated         :type start_date: datetime         :param external_trigger: whether this dag run is externally triggered         :type external_trigger: bool         :param conf: Dict containing configuration/parameters to pass to the DAG         :type conf: dict         :param creating_job_id: id of the job creating this DagRun         :type creating_job_id: int         :param session: database session         :type session: sqlalchemy.orm.session.Session         :param dag_hash: Hash of Serialized DAG         :type dag_hash: str         """ [72539,73656]
string: """         Creates a dag run from this dag including the tasks associated with this dag.         Returns the dag run.          :param run_id: defines the run id for this dag run         :type run_id: str         :param run_type: type of DagRun         :type run_type: airflow.utils.types.DagRunType         :param execution_date: the execution date of this dag run         :type execution_date: datetime.datetime         :param state: the state of the dag run         :type state: airflow.utils.state.State         :param start_date: the date this dag run should be evaluated         :type start_date: datetime         :param external_trigger: whether this dag run is externally triggered         :type external_trigger: bool         :param conf: Dict containing configuration/parameters to pass to the DAG         :type conf: dict         :param creating_job_id: id of the job creating this DagRun         :type creating_job_id: int         :param session: database session         :type session: sqlalchemy.orm.session.Session         :param dag_hash: Hash of Serialized DAG         :type dag_hash: str         """ [72491,73608]
===
match
---
name: StrictUndefined [10568,10583]
name: StrictUndefined [10568,10583]
===
match
---
trailer [13729,13742]
trailer [13729,13742]
===
match
---
name: full_filepath [32479,32492]
name: full_filepath [32431,32444]
===
match
---
name: int [30522,30525]
name: int [30474,30477]
===
match
---
name: DagRun [2089,2095]
name: DagRun [2089,2095]
===
match
---
name: self [47878,47882]
name: self [47830,47834]
===
match
---
name: execution_date [77044,77058]
name: execution_date [76996,77010]
===
match
---
name: clear [58486,58491]
name: clear [58438,58443]
===
match
---
name: ti [57088,57090]
name: ti [57040,57042]
===
match
---
string: 'dag_id' [9900,9908]
string: 'dag_id' [9900,9908]
===
match
---
suite [42416,42475]
suite [42368,42427]
===
match
---
operator: = [51102,51103]
operator: = [51054,51055]
===
match
---
expr_stmt [79435,79488]
expr_stmt [79387,79440]
===
match
---
trailer [83196,83203]
trailer [83148,83155]
===
match
---
simple_stmt [60096,60120]
simple_stmt [60048,60072]
===
match
---
parameters [31207,31225]
parameters [31159,31177]
===
match
---
operator: = [48759,48760]
operator: = [48711,48712]
===
match
---
expr_stmt [12734,12775]
expr_stmt [12734,12775]
===
match
---
name: self [16639,16643]
name: self [16639,16643]
===
match
---
string: '__dot__' [90653,90662]
string: '__dot__' [90605,90614]
===
match
---
trailer [26730,26747]
trailer [26682,26699]
===
match
---
operator: , [86105,86106]
operator: , [86057,86058]
===
match
---
operator: = [78230,78231]
operator: = [78182,78183]
===
match
---
name: dag [78715,78718]
name: dag [78667,78670]
===
match
---
name: new_start [25633,25642]
name: new_start [25585,25594]
===
match
---
simple_stmt [58002,58043]
simple_stmt [57954,57995]
===
match
---
decorators [81159,81194]
decorators [81111,81146]
===
match
---
trailer [18987,18999]
trailer [18987,18999]
===
match
---
operator: @ [29156,29157]
operator: @ [29108,29109]
===
match
---
fstring [59201,59287]
fstring [59153,59239]
===
match
---
operator: { [62921,62922]
operator: { [62873,62874]
===
match
---
name: kwargs [60600,60606]
name: kwargs [60552,60558]
===
match
---
operator: { [83689,83690]
operator: { [83641,83642]
===
match
---
string: "This attribute is deprecated. Please use `airflow.models.DAG.get_latest_execution_date` method." [40236,40333]
string: "This attribute is deprecated. Please use `airflow.models.DAG.get_latest_execution_date` method." [40188,40285]
===
match
---
atom_expr [10988,11007]
atom_expr [10988,11007]
===
match
---
string: 'has_on_success_callback' [84430,84455]
string: 'has_on_success_callback' [84382,84407]
===
match
---
name: timezone [66513,66521]
name: timezone [66465,66473]
===
match
---
operator: , [94559,94560]
operator: , [94511,94512]
===
match
---
name: orm_tag [79214,79221]
name: orm_tag [79166,79173]
===
match
---
atom_expr [14409,14438]
atom_expr [14409,14438]
===
match
---
trailer [30160,30165]
trailer [30112,30117]
===
match
---
comparison [26315,26358]
comparison [26267,26310]
===
match
---
if_stmt [14500,14597]
if_stmt [14500,14597]
===
match
---
name: start_date [67299,67309]
name: start_date [67251,67261]
===
match
---
operator: , [81239,81240]
operator: , [81191,81192]
===
match
---
arglist [86361,86383]
arglist [86313,86335]
===
match
---
suite [91962,92472]
suite [91914,92424]
===
match
---
atom_expr [53305,53314]
atom_expr [53257,53266]
===
match
---
name: dttm [29146,29150]
name: dttm [29098,29102]
===
match
---
name: filter [48104,48110]
name: filter [48056,48062]
===
match
---
simple_stmt [13457,13512]
simple_stmt [13457,13512]
===
match
---
name: count [33174,33179]
name: count [33126,33131]
===
match
---
name: ti [36616,36618]
name: ti [36568,36570]
===
match
---
param [39132,39144]
param [39084,39096]
===
match
---
operator: , [10934,10935]
operator: , [10934,10935]
===
match
---
name: most_recent_dag_run [94181,94200]
name: most_recent_dag_run [94133,94152]
===
match
---
name: parent_dag [14718,14728]
name: parent_dag [14718,14728]
===
match
---
simple_stmt [64652,64741]
simple_stmt [64604,64693]
===
match
---
simple_stmt [20655,20686]
simple_stmt [20655,20686]
===
match
---
simple_stmt [29753,29773]
simple_stmt [29705,29725]
===
match
---
string: "Sync %s DAGs" [75919,75933]
string: "Sync %s DAGs" [75871,75885]
===
match
---
simple_stmt [35456,35482]
simple_stmt [35408,35434]
===
match
---
expr_stmt [16304,16371]
expr_stmt [16304,16371]
===
match
---
suite [88897,88937]
suite [88849,88889]
===
match
---
atom_expr [11969,12002]
atom_expr [11969,12002]
===
match
---
name: Optional [10433,10441]
name: Optional [10433,10441]
===
match
---
atom_expr [11098,11147]
atom_expr [11098,11147]
===
match
---
name: dag_bag [48669,48676]
name: dag_bag [48621,48628]
===
match
---
operator: , [68930,68931]
operator: , [68882,68883]
===
match
---
operator: , [12637,12638]
operator: , [12637,12638]
===
match
---
return_stmt [31053,31078]
return_stmt [31005,31030]
===
match
---
name: f_sig [95686,95691]
name: f_sig [95638,95643]
===
match
---
atom_expr [43728,43746]
atom_expr [43680,43698]
===
match
---
atom_expr [66305,66375]
atom_expr [66257,66327]
===
match
---
trailer [33820,33826]
trailer [33772,33778]
===
match
---
name: in_timezone [22354,22365]
name: in_timezone [22330,22341]
===
match
---
atom_expr [30647,30669]
atom_expr [30599,30621]
===
match
---
string: """This attribute is deprecated. Please use `airflow.models.DAG.get_latest_execution_date` method.""" [40099,40200]
string: """This attribute is deprecated. Please use `airflow.models.DAG.get_latest_execution_date` method.""" [40051,40152]
===
match
---
operator: , [51852,51853]
operator: , [51804,51805]
===
match
---
name: external_trigger [37876,37892]
name: external_trigger [37828,37844]
===
match
---
name: concurrency [30376,30387]
name: concurrency [30328,30339]
===
match
---
name: in_ [83252,83255]
name: in_ [83204,83207]
===
match
---
name: dag [81076,81079]
name: dag [81028,81031]
===
match
---
name: p_dag [51955,51960]
name: p_dag [51907,51912]
===
match
---
name: params [60469,60475]
name: params [60421,60427]
===
match
---
name: group [64652,64657]
name: group [64604,64609]
===
match
---
name: classmethod [98171,98182]
name: classmethod [98123,98134]
===
match
---
name: self [12139,12143]
name: self [12139,12143]
===
match
---
operator: , [89076,89077]
operator: , [89028,89029]
===
match
---
name: num [19705,19708]
name: num [19705,19708]
===
match
---
name: dag_obj [96131,96138]
name: dag_obj [96083,96090]
===
match
---
argument [29578,29593]
argument [29530,29545]
===
match
---
name: DAG [97932,97935]
name: DAG [97884,97887]
===
match
---
not_test [24990,25045]
not_test [24942,24997]
===
match
---
atom_expr [41015,41045]
atom_expr [40967,40997]
===
match
---
decorator [44431,44441]
decorator [44383,44393]
===
match
---
expr_stmt [21926,21956]
expr_stmt [21902,21932]
===
match
---
atom_expr [71066,71081]
atom_expr [71018,71033]
===
match
---
param [84605,84628]
param [84557,84580]
===
match
---
trailer [83399,83407]
trailer [83351,83359]
===
match
---
suite [29914,29950]
suite [29866,29902]
===
match
---
operator: , [61033,61034]
operator: , [60985,60986]
===
match
---
atom_expr [37926,38060]
atom_expr [37878,38012]
===
match
---
operator: } [85327,85328]
operator: } [85279,85280]
===
match
---
name: is_subdag [28554,28563]
name: is_subdag [28506,28515]
===
match
---
trailer [45715,45727]
trailer [45667,45679]
===
match
---
atom_expr [75910,75945]
atom_expr [75862,75897]
===
match
---
string: "This attribute is deprecated. Please use `airflow.models.DAG.get_concurrency_reached` method." [33534,33629]
string: "This attribute is deprecated. Please use `airflow.models.DAG.get_concurrency_reached` method." [33486,33581]
===
match
---
trailer [68187,68195]
trailer [68139,68147]
===
match
---
name: DagRun [77528,77534]
name: DagRun [77480,77486]
===
match
---
operator: { [15555,15556]
operator: { [15555,15556]
===
match
---
param [31777,31782]
param [31729,31734]
===
match
---
arglist [66899,66907]
arglist [66851,66859]
===
match
---
string: """         Save attributes about this DAG to the DB. Note that this method         can be called for both DAGs and SubDAGs. A SubDag is actually a         SubDagOperator.          :return: None         """ [80030,80236]
string: """         Save attributes about this DAG to the DB. Note that this method         can be called for both DAGs and SubDAGs. A SubDag is actually a         SubDagOperator.          :return: None         """ [79982,80188]
===
match
---
name: graph_sorted [45759,45771]
name: graph_sorted [45711,45723]
===
match
---
name: task [44880,44884]
name: task [44832,44836]
===
match
---
atom_expr [55525,55577]
atom_expr [55477,55529]
===
match
---
arglist [67716,67748]
arglist [67668,67700]
===
match
---
name: level [66743,66748]
name: level [66695,66700]
===
match
---
simple_stmt [31053,31079]
simple_stmt [31005,31031]
===
match
---
arglist [12526,12668]
arglist [12526,12668]
===
match
---
operator: , [77279,77280]
operator: , [77231,77232]
===
match
---
expr_stmt [60522,60545]
expr_stmt [60474,60497]
===
match
---
name: dag_id [14856,14862]
name: dag_id [14856,14862]
===
match
---
name: dag [75980,75983]
name: dag [75932,75935]
===
match
---
name: run [74750,74753]
name: run [74702,74705]
===
match
---
raise_stmt [31797,31879]
raise_stmt [31749,31831]
===
match
---
name: upstream_task_id [84936,84952]
name: upstream_task_id [84888,84904]
===
match
---
name: following_schedule [20276,20294]
name: following_schedule [20276,20294]
===
match
---
arith_expr [83644,84513]
arith_expr [83596,84465]
===
match
---
name: warn [30161,30165]
name: warn [30113,30117]
===
match
---
trailer [45582,45590]
trailer [45534,45542]
===
match
---
param [47588,47624]
param [47540,47576]
===
match
---
operator: = [11758,11759]
operator: = [11758,11759]
===
match
---
name: schedule_interval [23784,23801]
name: schedule_interval [23736,23753]
===
match
---
trailer [89994,90004]
trailer [89946,89956]
===
match
---
trailer [42740,42758]
trailer [42692,42710]
===
match
---
name: tasks [62359,62364]
name: tasks [62311,62316]
===
match
---
name: jinja_environment_kwargs [41870,41894]
name: jinja_environment_kwargs [41822,41846]
===
match
---
atom_expr [72386,72406]
atom_expr [72338,72358]
===
match
---
name: values [64321,64327]
name: values [64273,64279]
===
match
---
atom_expr [11450,11463]
atom_expr [11450,11463]
===
match
---
trailer [26662,26673]
trailer [26614,26625]
===
match
---
trailer [66356,66366]
trailer [66308,66318]
===
match
---
name: start_date [55993,56003]
name: start_date [55945,55955]
===
match
---
name: executor [71055,71063]
name: executor [71007,71015]
===
match
---
atom_expr [47878,47889]
atom_expr [47830,47841]
===
match
---
name: provide_session [2603,2618]
name: provide_session [2603,2618]
===
match
---
if_stmt [52832,52943]
if_stmt [52784,52895]
===
match
---
trailer [12015,12022]
trailer [12015,12022]
===
match
---
name: flush [79863,79868]
name: flush [79815,79820]
===
match
---
name: clear_task_instances [57801,57821]
name: clear_task_instances [57753,57773]
===
match
---
trailer [64705,64718]
trailer [64657,64670]
===
match
---
suite [92180,92421]
suite [92132,92373]
===
match
---
suite [46826,46857]
suite [46778,46809]
===
match
---
name: filter [93244,93250]
name: filter [93196,93202]
===
match
---
name: self [84882,84886]
name: self [84834,84838]
===
match
---
atom [62028,62082]
atom [61980,62034]
===
match
---
trailer [65221,65229]
trailer [65173,65181]
===
match
---
simple_stmt [48791,51091]
simple_stmt [48743,51043]
===
match
---
name: TI [51506,51508]
name: TI [51458,51460]
===
match
---
trailer [26769,26775]
trailer [26721,26727]
===
match
---
param [89644,89663]
param [89596,89615]
===
match
---
name: upstream_task_id [85051,85067]
name: upstream_task_id [85003,85019]
===
match
---
simple_stmt [89710,89896]
simple_stmt [89662,89848]
===
match
---
arglist [94679,94743]
arglist [94631,94695]
===
match
---
atom_expr [12170,12217]
atom_expr [12170,12217]
===
match
---
name: dag_id [12284,12290]
name: dag_id [12284,12290]
===
match
---
trailer [89978,89985]
trailer [89930,89937]
===
match
---
comp_op [22711,22717]
comp_op [22663,22669]
===
match
---
testlist_comp [23596,23606]
testlist_comp [23548,23558]
===
match
---
return_stmt [30970,30994]
return_stmt [30922,30946]
===
match
---
string: """     These items are stored in the database for state related information     """ [85758,85842]
string: """     These items are stored in the database for state related information     """ [85710,85794]
===
match
---
param [89246,89258]
param [89198,89210]
===
match
---
operator: , [55717,55718]
operator: , [55669,55670]
===
match
---
trailer [72046,72051]
trailer [71998,72003]
===
match
---
name: default_args [11954,11966]
name: default_args [11954,11966]
===
match
---
name: logging [2880,2887]
name: logging [2880,2887]
===
match
---
suite [20220,20245]
suite [20220,20245]
===
match
---
name: OrderedDict [934,945]
name: OrderedDict [934,945]
===
match
---
expr_stmt [31243,31266]
expr_stmt [31195,31218]
===
match
---
funcdef [39804,40039]
funcdef [39756,39991]
===
match
---
simple_stmt [64223,64281]
simple_stmt [64175,64233]
===
match
---
operator: , [26815,26816]
operator: , [26767,26768]
===
match
---
name: expiration_date [81224,81239]
name: expiration_date [81176,81191]
===
match
---
name: self [42774,42778]
name: self [42726,42730]
===
match
---
atom [76724,76726]
atom [76676,76678]
===
match
---
operator: = [38832,38833]
operator: = [38784,38785]
===
match
---
trailer [22976,22985]
trailer [22928,22937]
===
match
---
atom_expr [20118,20141]
atom_expr [20118,20141]
===
match
---
name: dag [62975,62978]
name: dag [62927,62930]
===
match
---
arglist [84936,84956]
arglist [84888,84908]
===
match
---
atom_expr [13412,13443]
atom_expr [13412,13443]
===
match
---
param [65178,65190]
param [65130,65142]
===
match
---
name: include_subdags [48434,48449]
name: include_subdags [48386,48401]
===
match
---
name: next_run_date [27462,27475]
name: next_run_date [27414,27427]
===
match
---
trailer [82729,82783]
trailer [82681,82735]
===
match
---
name: dag_id [89958,89964]
name: dag_id [89910,89916]
===
match
---
name: group_id [63980,63988]
name: group_id [63932,63940]
===
match
---
trailer [10346,10356]
trailer [10346,10356]
===
match
---
name: tis [51922,51925]
name: tis [51874,51877]
===
match
---
string: " " [66772,66775]
string: " " [66724,66727]
===
match
---
string: """A tag name per dag, to allow quick filtering in the DAG view.""" [85383,85450]
string: """A tag name per dag, to allow quick filtering in the DAG view.""" [85335,85402]
===
match
---
simple_stmt [64020,64034]
simple_stmt [63972,63986]
===
match
---
comp_op [21443,21449]
comp_op [21419,21425]
===
match
---
name: orm_dag [79194,79201]
name: orm_dag [79146,79153]
===
match
---
trailer [68016,68025]
trailer [67968,67977]
===
match
---
atom_expr [79513,79545]
atom_expr [79465,79497]
===
match
---
name: dag_id [3460,3466]
name: dag_id [3460,3466]
===
match
---
trailer [24084,24103]
trailer [24036,24055]
===
match
---
name: self [20295,20299]
name: self [20295,20299]
===
match
---
parameters [30619,30637]
parameters [30571,30589]
===
match
---
simple_stmt [18023,18035]
simple_stmt [18023,18035]
===
match
---
name: session [3173,3180]
name: session [3173,3180]
===
match
---
name: owner [78412,78417]
name: owner [78364,78369]
===
match
---
operator: = [25251,25252]
operator: = [25203,25204]
===
match
---
operator: { [15267,15268]
operator: { [15267,15268]
===
match
---
operator: = [21017,21018]
operator: = [21017,21018]
===
match
---
simple_stmt [21354,21396]
simple_stmt [21330,21372]
===
match
---
argument [60910,60915]
argument [60862,60867]
===
match
---
name: __tablename__ [85456,85469]
name: __tablename__ [85408,85421]
===
match
---
trailer [68594,68598]
trailer [68546,68550]
===
match
---
suite [92646,93638]
suite [92598,93590]
===
match
---
funcdef [32513,32753]
funcdef [32465,32705]
===
match
---
or_test [47866,47890]
or_test [47818,47842]
===
match
---
operator: = [53544,53545]
operator: = [53496,53497]
===
match
---
comparison [53584,53618]
comparison [53536,53570]
===
match
---
name: include_parentdag [58326,58343]
name: include_parentdag [58278,58295]
===
match
---
comparison [82743,82772]
comparison [82695,82724]
===
match
---
trailer [72315,72321]
trailer [72267,72273]
===
match
---
expr_stmt [65670,65676]
expr_stmt [65622,65628]
===
match
---
trailer [87210,87216]
trailer [87162,87168]
===
match
---
argument [52360,52372]
argument [52312,52324]
===
match
---
atom_expr [37725,37853]
atom_expr [37677,37805]
===
match
---
name: jobs [70898,70902]
name: jobs [70850,70854]
===
match
---
name: state [83390,83395]
name: state [83342,83347]
===
match
---
name: classmethod [91347,91358]
name: classmethod [91299,91310]
===
match
---
suite [21580,22809]
suite [21556,22761]
===
match
---
name: dag_tag [79461,79468]
name: dag_tag [79413,79420]
===
match
---
name: tis [51561,51564]
name: tis [51513,51516]
===
match
---
atom_expr [13227,13244]
atom_expr [13227,13244]
===
match
---
name: order_by [3609,3617]
name: order_by [3609,3617]
===
match
---
atom_expr [66353,66366]
atom_expr [66305,66318]
===
match
---
operator: @ [72069,72070]
operator: @ [72021,72022]
===
match
---
trailer [38839,38846]
trailer [38791,38798]
===
match
---
name: get_default_view [90224,90240]
name: get_default_view [90176,90192]
===
match
---
atom_expr [74362,74373]
atom_expr [74314,74325]
===
match
---
trailer [42300,42320]
trailer [42252,42272]
===
match
---
operator: , [44197,44198]
operator: , [44149,44150]
===
match
---
name: self [68399,68403]
name: self [68351,68355]
===
match
---
name: DagBag [55336,55342]
name: DagBag [55288,55294]
===
match
---
expr_stmt [16779,16795]
expr_stmt [16779,16795]
===
match
---
expr_stmt [28258,28310]
expr_stmt [28210,28262]
===
match
---
operator: = [21198,21199]
operator: = [21198,21199]
===
match
---
operator: , [72279,72280]
operator: , [72231,72232]
===
match
---
name: task [67507,67511]
name: task [67459,67463]
===
match
---
name: task [40895,40899]
name: task [40847,40851]
===
match
---
name: stacklevel [12655,12665]
name: stacklevel [12655,12665]
===
match
---
simple_stmt [817,832]
simple_stmt [817,832]
===
match
---
suite [83002,83070]
suite [82954,83022]
===
match
---
name: conf [74539,74543]
name: conf [74491,74495]
===
match
---
operator: } [48187,48188]
operator: } [48139,48140]
===
match
---
exprlist [96545,96556]
exprlist [96497,96508]
===
match
---
trailer [92403,92413]
trailer [92355,92365]
===
match
---
simple_stmt [41015,41046]
simple_stmt [40967,40998]
===
match
---
or_test [68119,68269]
or_test [68071,68221]
===
match
---
name: str [10230,10233]
name: str [10230,10233]
===
match
---
name: t [57521,57522]
name: t [57473,57474]
===
match
---
and_test [35098,35180]
and_test [35050,35132]
===
match
---
operator: = [90755,90756]
operator: = [90707,90708]
===
match
---
name: DagParam [31586,31594]
name: DagParam [31538,31546]
===
match
---
atom_expr [20154,20170]
atom_expr [20154,20170]
===
match
---
if_stmt [67263,67750]
if_stmt [67215,67702]
===
match
---
name: query [48098,48103]
name: query [48050,48055]
===
match
---
suite [65722,65911]
suite [65674,65863]
===
match
---
atom [96522,96524]
atom [96474,96476]
===
match
---
operator: = [48676,48677]
operator: = [48628,48629]
===
match
---
param [69122,69145]
param [69074,69097]
===
match
---
trailer [55899,55905]
trailer [55851,55857]
===
match
---
name: utcnow [25262,25268]
name: utcnow [25214,25220]
===
match
---
lambdef [77913,77931]
lambdef [77865,77883]
===
match
---
name: count [59892,59897]
name: count [59844,59849]
===
match
---
parameters [80309,80315]
parameters [80261,80267]
===
match
---
trailer [64407,64434]
trailer [64359,64386]
===
match
---
name: UtcDateTime [86453,86464]
name: UtcDateTime [86405,86416]
===
match
---
name: next_run_date [28484,28497]
name: next_run_date [28436,28449]
===
match
---
name: concurrency [12714,12725]
name: concurrency [12714,12725]
===
match
---
atom_expr [44464,44482]
atom_expr [44416,44434]
===
match
---
simple_stmt [78626,78676]
simple_stmt [78578,78628]
===
match
---
name: keys [64427,64431]
name: keys [64379,64383]
===
match
---
arglist [14514,14538]
arglist [14514,14538]
===
match
---
atom_expr [91437,91446]
atom_expr [91389,91398]
===
match
---
operator: == [23403,23405]
operator: == [23355,23357]
===
match
---
operator: , [39108,39109]
operator: , [39060,39061]
===
match
---
name: self [62058,62062]
name: self [62010,62014]
===
match
---
name: run_id [38202,38208]
name: run_id [38154,38160]
===
match
---
atom_expr [36457,36484]
atom_expr [36409,36436]
===
match
---
name: BaseOperator [44469,44481]
name: BaseOperator [44421,44433]
===
match
---
expr_stmt [86781,86813]
expr_stmt [86733,86765]
===
match
---
simple_stmt [14605,14652]
simple_stmt [14605,14652]
===
match
---
suite [70970,71082]
suite [70922,71034]
===
match
---
simple_stmt [22030,22088]
simple_stmt [22006,22064]
===
match
---
name: hash_components [17717,17732]
name: hash_components [17717,17732]
===
match
---
if_stmt [53032,53100]
if_stmt [52984,53052]
===
match
---
simple_stmt [94670,94745]
simple_stmt [94622,94697]
===
match
---
string: 'landing_times' [3027,3042]
string: 'landing_times' [3027,3042]
===
match
---
name: dag_id [89484,89490]
name: dag_id [89436,89442]
===
match
---
name: dag_id [91049,91055]
name: dag_id [91001,91007]
===
match
---
name: isinstance [14503,14513]
name: isinstance [14503,14513]
===
match
---
suite [34334,34659]
suite [34286,34611]
===
match
---
trailer [59147,59152]
trailer [59099,59104]
===
match
---
atom_expr [54873,54894]
atom_expr [54825,54846]
===
match
---
for_stmt [46740,47241]
for_stmt [46692,47193]
===
match
---
expr_stmt [26691,26747]
expr_stmt [26643,26699]
===
match
---
operator: - [83687,83688]
operator: - [83639,83640]
===
match
---
decorated [37292,38092]
decorated [37244,38044]
===
match
---
comparison [66196,66226]
comparison [66148,66178]
===
match
---
argument [76262,76273]
argument [76214,76225]
===
match
---
parameters [92622,92645]
parameters [92574,92597]
===
match
---
simple_stmt [34111,34173]
simple_stmt [34063,34125]
===
match
---
atom_expr [36801,36865]
atom_expr [36753,36817]
===
match
---
name: perm [18994,18998]
name: perm [18994,18998]
===
match
---
string: 'webserver' [90530,90541]
string: 'webserver' [90482,90493]
===
match
---
name: Boolean [1385,1392]
name: Boolean [1385,1392]
===
match
---
name: dagruns [39770,39777]
name: dagruns [39722,39729]
===
match
---
trailer [57110,57118]
trailer [57062,57070]
===
match
---
simple_stmt [68057,68107]
simple_stmt [68009,68059]
===
match
---
trailer [86098,86137]
trailer [86050,86089]
===
match
---
arglist [17643,17656]
arglist [17643,17656]
===
match
---
name: self [27245,27249]
name: self [27197,27201]
===
match
---
operator: , [38875,38876]
operator: , [38827,38828]
===
match
---
name: qry [33990,33993]
name: qry [33942,33945]
===
match
---
comp_op [92076,92082]
comp_op [92028,92034]
===
match
---
operator: + [63032,63033]
operator: + [62984,62985]
===
match
---
atom_expr [21019,21042]
atom_expr [21019,21042]
===
match
---
suite [91096,91166]
suite [91048,91118]
===
match
---
expr_stmt [51486,51542]
expr_stmt [51438,51494]
===
match
---
simple_stmt [47999,48057]
simple_stmt [47951,48009]
===
match
---
operator: = [59004,59005]
operator: = [58956,58957]
===
match
---
trailer [23384,23402]
trailer [23336,23354]
===
match
---
param [48404,48425]
param [48356,48377]
===
match
---
atom_expr [62526,62562]
atom_expr [62478,62514]
===
match
---
trailer [88708,88736]
trailer [88660,88688]
===
match
---
operator: , [77025,77026]
operator: , [76977,76978]
===
match
---
name: last_start [25337,25347]
name: last_start [25289,25299]
===
match
---
dictorsetmaker [76327,76365]
dictorsetmaker [76279,76317]
===
match
---
operator: = [76152,76153]
operator: = [76104,76105]
===
match
---
suite [88745,88873]
suite [88697,88825]
===
match
---
name: get [78999,79002]
name: get [78951,78954]
===
match
---
operator: = [87263,87264]
operator: = [87215,87216]
===
match
---
trailer [41032,41045]
trailer [40984,40997]
===
match
---
name: state [83141,83146]
name: state [83093,83098]
===
match
---
name: x [82975,82976]
name: x [82927,82928]
===
match
---
expr_stmt [42026,42091]
expr_stmt [41978,42043]
===
match
---
name: include_subdags [65429,65444]
name: include_subdags [65381,65396]
===
match
---
argument [48190,48217]
argument [48142,48169]
===
match
---
name: UtcDateTime [2666,2677]
name: UtcDateTime [2666,2677]
===
match
---
operator: , [78965,78966]
operator: , [78917,78918]
===
match
---
name: run_id [72204,72210]
name: run_id [72156,72162]
===
match
---
operator: = [75965,75966]
operator: = [75917,75918]
===
match
---
name: tis [36451,36454]
name: tis [36403,36406]
===
match
---
expr_stmt [57728,57769]
expr_stmt [57680,57721]
===
match
---
atom_expr [33962,33973]
atom_expr [33914,33925]
===
match
---
comparison [66397,66414]
comparison [66349,66366]
===
match
---
string: """Returns a boolean indicating whether this DAG is active""" [33836,33897]
string: """Returns a boolean indicating whether this DAG is active""" [33788,33849]
===
match
---
operator: = [78713,78714]
operator: = [78665,78666]
===
match
---
atom_expr [31243,31258]
atom_expr [31195,31210]
===
match
---
name: hash_components [17387,17402]
name: hash_components [17387,17402]
===
match
---
simple_stmt [67862,67892]
simple_stmt [67814,67844]
===
match
---
name: lower [80490,80495]
name: lower [80442,80447]
===
match
---
name: executor [69037,69045]
name: executor [68989,68997]
===
match
---
name: task_ids_or_regex [60974,60991]
name: task_ids_or_regex [60926,60943]
===
match
---
decorator [74934,74947]
decorator [74886,74899]
===
match
---
for_stmt [53327,56981]
for_stmt [53279,56933]
===
match
---
name: partial_subset [55632,55646]
name: partial_subset [55584,55598]
===
match
---
name: airflow [2060,2067]
name: airflow [2060,2067]
===
match
---
name: typing_compat [2266,2279]
name: typing_compat [2266,2279]
===
match
---
name: get_last_dagrun [29269,29284]
name: get_last_dagrun [29221,29236]
===
match
---
operator: , [1500,1501]
operator: , [1500,1501]
===
match
---
name: commit [81145,81151]
name: commit [81097,81103]
===
match
---
name: orm_dag [76327,76334]
name: orm_dag [76279,76286]
===
match
---
name: include_subdags [58296,58311]
name: include_subdags [58248,58263]
===
match
---
trailer [78755,78783]
trailer [78707,78735]
===
match
---
operator: -> [90247,90249]
operator: -> [90199,90201]
===
match
---
atom_expr [54774,54784]
atom_expr [54726,54736]
===
match
---
name: property [32759,32767]
name: property [32711,32719]
===
match
---
trailer [13490,13504]
trailer [13490,13504]
===
match
---
simple_stmt [45746,45773]
simple_stmt [45698,45725]
===
match
---
name: value [29858,29863]
name: value [29810,29815]
===
match
---
string: '__dot__' [14876,14885]
string: '__dot__' [14876,14885]
===
match
---
atom_expr [78929,78965]
atom_expr [78881,78917]
===
match
---
name: result [60278,60284]
name: result [60230,60236]
===
match
---
atom_expr [55065,55086]
atom_expr [55017,55038]
===
match
---
name: FAILED [52899,52905]
name: FAILED [52851,52857]
===
match
---
name: Column [86682,86688]
name: Column [86634,86640]
===
match
---
trailer [65021,65034]
trailer [64973,64986]
===
match
---
trailer [78833,78839]
trailer [78785,78791]
===
match
---
trailer [66318,66329]
trailer [66270,66281]
===
match
---
simple_stmt [81760,81953]
simple_stmt [81712,81905]
===
match
---
name: session [34070,34077]
name: session [34022,34029]
===
match
---
operator: = [11464,11465]
operator: = [11464,11465]
===
match
---
atom_expr [87197,87217]
atom_expr [87149,87169]
===
match
---
operator: , [19531,19532]
operator: , [19531,19532]
===
match
---
simple_stmt [85689,85727]
simple_stmt [85641,85679]
===
match
---
simple_stmt [84655,84789]
simple_stmt [84607,84741]
===
match
---
trailer [83296,83302]
trailer [83248,83254]
===
match
---
atom_expr [23964,24008]
atom_expr [23916,23960]
===
match
---
operator: = [43127,43128]
operator: = [43079,43080]
===
match
---
suite [68871,68904]
suite [68823,68856]
===
match
---
name: c [17430,17431]
name: c [17430,17431]
===
match
---
trailer [11841,11861]
trailer [11841,11861]
===
match
---
trailer [13477,13490]
trailer [13477,13490]
===
match
---
operator: , [89236,89237]
operator: , [89188,89189]
===
match
---
name: on_success_callback [36282,36301]
name: on_success_callback [36234,36253]
===
match
---
atom_expr [77768,77786]
atom_expr [77720,77738]
===
match
---
name: orm_dags [76229,76237]
name: orm_dags [76181,76189]
===
match
---
operator: , [55830,55831]
operator: , [55782,55783]
===
match
---
return_stmt [23935,24009]
return_stmt [23887,23961]
===
match
---
atom_expr [83644,83686]
atom_expr [83596,83638]
===
match
---
decorator [31000,31010]
decorator [30952,30962]
===
match
---
operator: = [71636,71637]
operator: = [71588,71589]
===
match
---
trailer [22588,22599]
trailer [22540,22551]
===
match
---
testlist_comp [79281,79309]
testlist_comp [79233,79261]
===
match
---
name: task_ids [51402,51410]
name: task_ids [51354,51362]
===
match
---
trailer [78098,78106]
trailer [78050,78058]
===
match
---
name: task [41076,41080]
name: task [41028,41032]
===
match
---
name: dag_id [77831,77837]
name: dag_id [77783,77789]
===
match
---
operator: -> [84630,84632]
operator: -> [84582,84584]
===
match
---
operator: = [74393,74394]
operator: = [74345,74346]
===
match
---
import_as_names [1481,1514]
import_as_names [1481,1514]
===
match
---
expr_stmt [97895,97941]
expr_stmt [97847,97893]
===
match
---
operator: = [10357,10358]
operator: = [10357,10358]
===
match
---
trailer [64046,64058]
trailer [63998,64010]
===
match
---
atom_expr [36582,36592]
atom_expr [36534,36544]
===
match
---
arith_expr [42976,43009]
arith_expr [42928,42961]
===
match
---
tfpdef [24048,24103]
tfpdef [24000,24055]
===
match
---
trailer [40021,40028]
trailer [39973,39980]
===
match
---
name: isinstance [35098,35108]
name: isinstance [35050,35060]
===
match
---
operator: , [42906,42907]
operator: , [42858,42859]
===
match
---
name: task_ids_or_regex [55680,55697]
name: task_ids_or_regex [55632,55649]
===
match
---
operator: = [69000,69001]
operator: = [68952,68953]
===
match
---
name: session [91448,91455]
name: session [91400,91407]
===
match
---
atom_expr [11393,11425]
atom_expr [11393,11425]
===
match
---
param [10326,10364]
param [10326,10364]
===
match
---
trailer [91441,91446]
trailer [91393,91398]
===
match
---
name: group [63404,63409]
name: group [63356,63361]
===
match
---
name: update [48160,48166]
name: update [48112,48118]
===
match
---
name: templates [42040,42049]
name: templates [41992,42001]
===
match
---
param [17235,17240]
param [17235,17240]
===
match
---
suite [63109,64034]
suite [63061,63986]
===
match
---
name: filter [43721,43727]
name: filter [43673,43679]
===
match
---
trailer [11458,11463]
trailer [11458,11463]
===
match
---
param [38156,38193]
param [38108,38145]
===
match
---
name: execution_date [39683,39697]
name: execution_date [39635,39649]
===
match
---
name: operators [40648,40657]
name: operators [40600,40609]
===
match
---
atom_expr [89139,89154]
atom_expr [89091,89106]
===
match
---
trailer [65962,65968]
trailer [65914,65920]
===
match
---
param [29999,30004]
param [29951,29956]
===
match
---
trailer [30351,30369]
trailer [30303,30321]
===
match
---
atom_expr [63521,63534]
atom_expr [63473,63486]
===
match
---
if_stmt [59102,59342]
if_stmt [59054,59294]
===
match
---
trailer [53548,53552]
trailer [53500,53504]
===
match
---
operator: , [33793,33794]
operator: , [33745,33746]
===
match
---
operator: , [47462,47463]
operator: , [47414,47415]
===
match
---
comparison [37823,37852]
comparison [37775,37804]
===
match
---
trailer [76778,76785]
trailer [76730,76737]
===
match
---
operator: = [10585,10586]
operator: = [10585,10586]
===
match
---
name: SubDagOperator [40794,40808]
name: SubDagOperator [40746,40760]
===
match
---
suite [89701,90215]
suite [89653,90167]
===
match
---
arglist [77899,77931]
arglist [77851,77883]
===
match
---
name: kwargs [96120,96126]
name: kwargs [96072,96078]
===
match
---
suite [88975,89009]
suite [88927,88961]
===
match
---
trailer [44884,44900]
trailer [44836,44852]
===
match
---
name: all [43892,43895]
name: all [43844,43847]
===
match
---
name: TIMEZONE [89000,89008]
name: TIMEZONE [88952,88960]
===
match
---
operator: + [66789,66790]
operator: + [66741,66742]
===
match
---
name: getattr [17126,17133]
name: getattr [17126,17133]
===
match
---
name: getattr [17635,17642]
name: getattr [17635,17642]
===
match
---
name: task_id [65502,65509]
name: task_id [65454,65461]
===
match
---
atom_expr [94388,94611]
atom_expr [94340,94563]
===
match
---
name: provide_session [82071,82086]
name: provide_session [82023,82038]
===
match
---
name: cli_parser [71931,71941]
name: cli_parser [71883,71893]
===
match
---
name: __name__ [54764,54772]
name: __name__ [54716,54724]
===
match
---
name: params [12025,12031]
name: params [12025,12031]
===
match
---
trailer [15627,15635]
trailer [15627,15635]
===
match
---
operator: = [66587,66588]
operator: = [66539,66540]
===
match
---
simple_stmt [57211,57222]
simple_stmt [57163,57174]
===
match
---
arglist [21753,21791]
arglist [21729,21767]
===
match
---
if_stmt [43668,44345]
if_stmt [43620,44297]
===
match
---
name: last_start [25489,25499]
name: last_start [25441,25451]
===
match
---
operator: , [75020,75021]
operator: , [74972,74973]
===
match
---
name: root_dag_id [87922,87933]
name: root_dag_id [87874,87885]
===
match
---
name: Base [1821,1825]
name: Base [1821,1825]
===
match
---
atom_expr [62905,62918]
atom_expr [62857,62870]
===
match
---
name: run [37238,37241]
name: run [37190,37193]
===
match
---
trailer [59409,59415]
trailer [59361,59367]
===
match
---
operator: -> [30944,30946]
operator: -> [30896,30898]
===
match
---
trailer [53514,53516]
trailer [53466,53468]
===
match
---
trailer [60418,60439]
trailer [60370,60391]
===
match
---
name: tags [76137,76141]
name: tags [76089,76093]
===
match
---
trailer [45720,45726]
trailer [45672,45678]
===
match
---
return_stmt [57014,57024]
return_stmt [56966,56976]
===
match
---
atom_expr [30738,30758]
atom_expr [30690,30710]
===
match
---
name: self [22774,22778]
name: self [22726,22730]
===
match
---
trailer [91128,91165]
trailer [91080,91117]
===
match
---
name: session [77514,77521]
name: session [77466,77473]
===
match
---
operator: @ [30062,30063]
operator: @ [30014,30015]
===
match
---
operator: @ [81159,81160]
operator: @ [81111,81112]
===
match
---
name: self [23638,23642]
name: self [23590,23594]
===
match
---
atom_expr [34441,34622]
atom_expr [34393,34574]
===
match
---
trailer [81763,81768]
trailer [81715,81720]
===
match
---
atom_expr [30977,30994]
atom_expr [30929,30946]
===
match
---
name: cls [60033,60036]
name: cls [59985,59988]
===
match
---
operator: @ [32903,32904]
operator: @ [32855,32856]
===
match
---
name: last_loaded [14797,14808]
name: last_loaded [14797,14808]
===
match
---
param [29439,29444]
param [29391,29396]
===
match
---
atom_expr [25011,25033]
atom_expr [24963,24985]
===
match
---
name: dag_id [94517,94523]
name: dag_id [94469,94475]
===
match
---
operator: , [58153,58154]
operator: , [58105,58106]
===
match
---
return_stmt [27434,27445]
return_stmt [27386,27397]
===
match
---
tfpdef [47472,47482]
tfpdef [47424,47434]
===
match
---
name: in_ [76197,76200]
name: in_ [76149,76152]
===
match
---
name: self [26503,26507]
name: self [26455,26459]
===
match
---
operator: == [93282,93284]
operator: == [93234,93236]
===
match
---
and_test [68012,68043]
and_test [67964,67995]
===
match
---
operator: = [16789,16790]
operator: = [16789,16790]
===
match
---
suite [67681,67750]
suite [67633,67702]
===
match
---
decorators [89014,89049]
decorators [88966,89001]
===
match
---
trailer [28301,28308]
trailer [28253,28260]
===
match
---
operator: = [51888,51889]
operator: = [51840,51841]
===
match
---
trailer [91048,91055]
trailer [91000,91007]
===
match
---
simple_stmt [87251,87278]
simple_stmt [87203,87230]
===
match
---
name: filter_task_group [63070,63087]
name: filter_task_group [63022,63039]
===
match
---
operator: , [10316,10317]
operator: , [10316,10317]
===
match
---
name: scheduler_lock [86781,86795]
name: scheduler_lock [86733,86747]
===
match
---
operator: , [22848,22849]
operator: , [22800,22801]
===
match
---
atom_expr [82743,82762]
atom_expr [82695,82714]
===
match
---
name: visited_external_tis [52603,52623]
name: visited_external_tis [52555,52575]
===
match
---
name: state [33254,33259]
name: state [33206,33211]
===
match
---
operator: , [62185,62186]
operator: , [62137,62138]
===
match
---
operator: , [1436,1437]
operator: , [1436,1437]
===
match
---
name: session [72423,72430]
name: session [72375,72382]
===
match
---
name: max_active_runs [10893,10908]
name: max_active_runs [10893,10908]
===
match
---
trailer [29302,29309]
trailer [29254,29261]
===
match
---
operator: = [14916,14917]
operator: = [14916,14917]
===
match
---
factor [81019,81055]
factor [80971,81007]
===
match
---
decorator [30683,30693]
decorator [30635,30645]
===
match
---
atom_expr [96082,96101]
atom_expr [96034,96053]
===
match
---
simple_stmt [97095,97143]
simple_stmt [97047,97095]
===
match
---
operator: -> [31037,31039]
operator: -> [30989,30991]
===
match
---
if_stmt [62471,62563]
if_stmt [62423,62515]
===
match
---
name: default_args [13368,13380]
name: default_args [13368,13380]
===
match
---
number: 30 [43006,43008]
number: 30 [42958,42960]
===
match
---
suite [66287,66376]
suite [66239,66328]
===
match
---
param [29217,29251]
param [29169,29203]
===
match
---
param [98215,98218]
param [98167,98170]
===
match
---
simple_stmt [35352,35378]
simple_stmt [35304,35330]
===
match
---
suite [22988,24010]
suite [22940,23962]
===
match
---
trailer [20486,20515]
trailer [20486,20515]
===
match
---
atom_expr [78598,78613]
atom_expr [78550,78565]
===
match
---
or_test [12025,12037]
or_test [12025,12037]
===
match
---
name: include_externally_triggered [89538,89566]
name: include_externally_triggered [89490,89518]
===
match
---
name: cls [92623,92626]
name: cls [92575,92578]
===
match
---
name: dag_id [39599,39605]
name: dag_id [39551,39557]
===
match
---
name: self [13857,13861]
name: self [13857,13861]
===
match
---
name: airflow [2830,2837]
name: airflow [2830,2837]
===
match
---
name: end_date [19598,19606]
name: end_date [19598,19606]
===
match
---
atom_expr [38970,38983]
atom_expr [38922,38935]
===
match
---
operator: , [61002,61003]
operator: , [60954,60955]
===
match
---
trailer [81018,81056]
trailer [80970,81008]
===
match
---
name: self [67116,67120]
name: self [67068,67072]
===
match
---
string: """         Figures out if the DAG schedule has a fixed time (e.g. 3 AM).          :return: True if the schedule has a fixed time, False if not.         """ [19807,19963]
string: """         Figures out if the DAG schedule has a fixed time (e.g. 3 AM).          :return: True if the schedule has a fixed time, False if not.         """ [19807,19963]
===
match
---
arglist [95712,95727]
arglist [95664,95679]
===
match
---
name: session [75452,75459]
name: session [75404,75411]
===
match
---
trailer [21204,21213]
trailer [21204,21213]
===
match
---
name: only_failed [52835,52846]
name: only_failed [52787,52798]
===
match
---
expr_stmt [59300,59341]
expr_stmt [59252,59293]
===
match
---
trailer [42731,42740]
trailer [42683,42692]
===
match
---
name: value [30005,30010]
name: value [29957,29962]
===
match
---
name: task_id [54777,54784]
name: task_id [54729,54736]
===
match
---
if_stmt [15337,15615]
if_stmt [15337,15615]
===
match
---
name: task_id [65222,65229]
name: task_id [65174,65181]
===
match
---
trailer [63793,63808]
trailer [63745,63760]
===
match
---
suite [69352,71830]
suite [69304,71782]
===
match
---
name: value [30816,30821]
name: value [30768,30773]
===
match
---
name: FrozenSet [1101,1110]
name: FrozenSet [1101,1110]
===
match
---
trailer [78861,78890]
trailer [78813,78842]
===
match
---
operator: , [58286,58287]
operator: , [58238,58239]
===
match
---
number: 3 [19319,19320]
number: 3 [19319,19320]
===
match
---
name: _access_control [30837,30852]
name: _access_control [30789,30804]
===
match
---
name: question [59190,59198]
name: question [59142,59150]
===
match
---
string: 'params' [12127,12135]
string: 'params' [12127,12135]
===
match
---
arglist [21331,21340]
arglist [21307,21316]
===
match
---
trailer [31817,31879]
trailer [31769,31831]
===
match
---
expr_stmt [47999,48056]
expr_stmt [47951,48008]
===
match
---
name: dag_id [90633,90639]
name: dag_id [90585,90591]
===
match
---
atom_expr [37956,37979]
atom_expr [37908,37931]
===
match
---
operator: = [72360,72361]
operator: = [72312,72313]
===
match
---
simple_stmt [80524,80549]
simple_stmt [80476,80501]
===
match
---
name: configuration [1671,1684]
name: configuration [1671,1684]
===
match
---
trailer [22050,22079]
trailer [22026,22055]
===
match
---
arglist [77597,77787]
arglist [77549,77739]
===
match
---
atom_expr [68057,68070]
atom_expr [68009,68022]
===
match
---
expr_stmt [20759,20816]
expr_stmt [20759,20816]
===
match
---
name: include_downstream [61043,61061]
name: include_downstream [60995,61013]
===
match
---
tfpdef [85074,85097]
tfpdef [85026,85049]
===
match
---
operator: , [23903,23904]
operator: , [23855,23856]
===
match
---
simple_stmt [20254,20267]
simple_stmt [20254,20267]
===
match
---
name: dag [78363,78366]
name: dag [78315,78318]
===
match
---
operator: == [80944,80946]
operator: == [80896,80898]
===
match
---
name: DagRun [77098,77104]
name: DagRun [77050,77056]
===
match
---
trailer [38962,38969]
trailer [38914,38921]
===
match
---
suite [31044,31079]
suite [30996,31031]
===
match
---
decorator [32758,32768]
decorator [32710,32720]
===
match
---
name: self [90628,90632]
name: self [90580,90584]
===
match
---
name: node [46998,47002]
name: node [46950,46954]
===
match
---
name: dag_id [43190,43196]
name: dag_id [43142,43148]
===
match
---
name: task_group [64248,64258]
name: task_group [64200,64210]
===
match
---
atom_expr [89986,90004]
atom_expr [89938,89956]
===
match
---
trailer [65053,65055]
trailer [65005,65007]
===
match
---
atom_expr [25924,25934]
atom_expr [25876,25886]
===
match
---
trailer [68326,68334]
trailer [68278,68286]
===
match
---
atom_expr [12331,12350]
atom_expr [12331,12350]
===
match
---
dotted_name [1663,1684]
dotted_name [1663,1684]
===
match
---
atom_expr [66846,66866]
atom_expr [66798,66818]
===
match
---
atom_expr [39040,39053]
atom_expr [38992,39005]
===
match
---
trailer [51372,51379]
trailer [51324,51331]
===
match
---
name: back [13001,13005]
name: back [13001,13005]
===
match
---
name: str [20517,20520]
name: str [20517,20520]
===
match
---
name: self [28939,28943]
name: self [28891,28895]
===
match
---
name: state [43649,43654]
name: state [43601,43606]
===
match
---
simple_stmt [92463,92472]
simple_stmt [92415,92424]
===
match
---
operator: { [85326,85327]
operator: { [85278,85279]
===
match
---
name: count [58084,58089]
name: count [58036,58041]
===
match
---
trailer [89465,89576]
trailer [89417,89528]
===
match
---
suite [25845,26145]
suite [25797,26097]
===
match
---
name: SCHEDULED [77270,77279]
name: SCHEDULED [77222,77231]
===
match
---
funcdef [31272,31641]
funcdef [31224,31593]
===
match
---
operator: , [20050,20051]
operator: , [20050,20051]
===
match
---
simple_stmt [51337,51413]
simple_stmt [51289,51365]
===
match
---
name: int [30101,30104]
name: int [30053,30056]
===
match
---
name: str [2934,2937]
name: str [2934,2937]
===
match
---
simple_stmt [30340,30370]
simple_stmt [30292,30322]
===
match
---
trailer [66794,66800]
trailer [66746,66752]
===
match
---
name: end_date [48136,48144]
name: end_date [48088,48096]
===
match
---
name: next_dagrun_create_after [93377,93401]
name: next_dagrun_create_after [93329,93353]
===
match
---
comp_op [37893,37899]
comp_op [37845,37851]
===
match
---
name: value [96642,96647]
name: value [96594,96599]
===
match
---
name: f_code [12979,12985]
name: f_code [12979,12985]
===
match
---
simple_stmt [97848,97891]
simple_stmt [97800,97843]
===
match
---
name: get_current_dag [98515,98530]
name: get_current_dag [98467,98482]
===
match
---
param [75452,75464]
param [75404,75416]
===
match
---
atom_expr [63607,63620]
atom_expr [63559,63572]
===
match
---
name: dags [75427,75431]
name: dags [75379,75383]
===
match
---
name: Optional [72345,72353]
name: Optional [72297,72305]
===
match
---
name: schedule_interval [35310,35327]
name: schedule_interval [35262,35279]
===
match
---
name: dag [76775,76778]
name: dag [76727,76730]
===
match
---
name: self [60039,60043]
name: self [59991,59995]
===
match
---
argument [62649,62662]
argument [62601,62614]
===
match
---
trailer [64278,64280]
trailer [64230,64232]
===
match
---
name: x [82989,82990]
name: x [82941,82942]
===
match
---
suite [83490,84553]
suite [83442,84505]
===
match
---
name: self [22366,22370]
name: self [22342,22346]
===
match
---
trailer [88625,88642]
trailer [88577,88594]
===
match
---
operator: = [63329,63330]
operator: = [63281,63282]
===
match
---
name: self [90708,90712]
name: self [90660,90664]
===
match
---
expr_stmt [25247,25270]
expr_stmt [25199,25222]
===
match
---
comparison [37773,37801]
comparison [37725,37753]
===
match
---
name: cron [22470,22474]
name: cron [22446,22450]
===
match
---
trailer [91338,91340]
trailer [91290,91292]
===
match
---
trailer [37124,37131]
trailer [37076,37083]
===
match
---
atom_expr [74871,74908]
atom_expr [74823,74860]
===
match
---
return_stmt [32705,32752]
return_stmt [32657,32704]
===
match
---
name: query [80996,81001]
name: query [80948,80953]
===
match
---
trailer [89165,89171]
trailer [89117,89123]
===
match
---
name: add [76807,76810]
name: add [76759,76762]
===
match
---
trailer [62161,62202]
trailer [62113,62154]
===
match
---
simple_stmt [74871,74909]
simple_stmt [74823,74861]
===
match
---
name: Optional [11043,11051]
name: Optional [11043,11051]
===
match
---
sync_comp_for [17176,17196]
sync_comp_for [17176,17196]
===
match
---
comparison [20154,20186]
comparison [20154,20186]
===
match
---
simple_stmt [14792,14829]
simple_stmt [14792,14829]
===
match
---
name: bool [72316,72320]
name: bool [72268,72272]
===
match
---
name: ask_yesno [59322,59331]
name: ask_yesno [59274,59283]
===
match
---
operator: = [91455,91456]
operator: = [91407,91408]
===
match
---
expr_stmt [91871,91908]
expr_stmt [91823,91860]
===
match
---
name: __exit__ [18044,18052]
name: __exit__ [18044,18052]
===
match
---
name: scalar [33307,33313]
name: scalar [33259,33265]
===
match
---
param [10173,10178]
param [10173,10178]
===
match
---
comparison [82936,82950]
comparison [82888,82902]
===
match
---
name: deepcopy [62102,62110]
name: deepcopy [62054,62062]
===
match
---
operator: = [21077,21078]
operator: = [21077,21078]
===
match
---
param [42864,42880]
param [42816,42832]
===
match
---
name: arguments [95917,95926]
name: arguments [95869,95878]
===
match
---
operator: = [12815,12816]
operator: = [12815,12816]
===
match
---
trailer [92354,92364]
trailer [92306,92316]
===
match
---
operator: , [13954,13955]
operator: , [13954,13955]
===
match
---
expr_stmt [14449,14491]
expr_stmt [14449,14491]
===
match
---
decorator [88942,88952]
decorator [88894,88904]
===
match
---
name: staticmethod [89583,89595]
name: staticmethod [89535,89547]
===
match
---
trailer [14032,14047]
trailer [14032,14047]
===
match
---
expr_stmt [44044,44084]
expr_stmt [43996,44036]
===
match
---
atom_expr [14385,14439]
atom_expr [14385,14439]
===
match
---
if_stmt [80399,80549]
if_stmt [80351,80501]
===
match
---
atom_expr [20008,20056]
atom_expr [20008,20056]
===
match
---
trailer [43189,43196]
trailer [43141,43148]
===
match
---
operator: , [34068,34069]
operator: , [34020,34021]
===
match
---
decorator [75363,75376]
decorator [75315,75328]
===
match
---
name: dagcode [1940,1947]
name: dagcode [1940,1947]
===
match
---
testlist_comp [43306,43335]
testlist_comp [43258,43287]
===
match
---
name: downstream_group_ids [64482,64502]
name: downstream_group_ids [64434,64454]
===
match
---
atom_expr [29565,29576]
atom_expr [29517,29528]
===
match
---
name: dag_id [33231,33237]
name: dag_id [33183,33189]
===
match
---
trailer [93456,93481]
trailer [93408,93433]
===
match
---
decorated [40044,40451]
decorated [39996,40403]
===
match
---
trailer [55156,55171]
trailer [55108,55123]
===
match
---
name: now [19987,19990]
name: now [19987,19990]
===
match
---
operator: = [82147,82148]
operator: = [82099,82100]
===
match
---
suite [47269,47364]
suite [47221,47316]
===
match
---
trailer [36572,36581]
trailer [36524,36533]
===
match
---
atom_expr [62935,62944]
atom_expr [62887,62896]
===
match
---
operator: = [26705,26706]
operator: = [26657,26658]
===
match
---
suite [28829,29151]
suite [28781,29103]
===
match
---
simple_stmt [2965,3044]
simple_stmt [2965,3044]
===
match
---
operator: = [11862,11863]
operator: = [11862,11863]
===
match
---
trailer [14841,14853]
trailer [14841,14853]
===
match
---
atom_expr [80531,80548]
atom_expr [80483,80500]
===
match
---
name: ExecutorLoader [71167,71181]
name: ExecutorLoader [71119,71133]
===
match
---
trailer [19501,19511]
trailer [19501,19511]
===
match
---
trailer [46697,46722]
trailer [46649,46674]
===
match
---
name: self [12189,12193]
name: self [12189,12193]
===
match
---
operator: , [71685,71686]
operator: , [71637,71638]
===
match
---
trailer [11746,11757]
trailer [11746,11757]
===
match
---
simple_stmt [72539,73657]
simple_stmt [72491,73609]
===
match
---
trailer [17818,17823]
trailer [17818,17823]
===
match
---
simple_stmt [74329,74692]
simple_stmt [74281,74644]
===
match
---
arglist [10848,10882]
arglist [10848,10882]
===
match
---
decorator [83442,83455]
decorator [83394,83407]
===
match
---
operator: , [39130,39131]
operator: , [39082,39083]
===
match
---
operator: , [3016,3017]
operator: , [3016,3017]
===
match
---
name: dag [64719,64722]
name: dag [64671,64674]
===
match
---
operator: = [66303,66304]
operator: = [66255,66256]
===
match
---
param [42881,42895]
param [42833,42847]
===
match
---
operator: == [37787,37789]
operator: == [37739,37741]
===
match
---
operator: , [83719,83720]
operator: , [83671,83672]
===
match
---
atom_expr [17845,17867]
atom_expr [17845,17867]
===
match
---
expr_stmt [38949,39024]
expr_stmt [38901,38976]
===
match
---
name: env [41955,41958]
name: env [41907,41910]
===
match
---
expr_stmt [85901,85937]
expr_stmt [85853,85889]
===
match
---
name: int [30633,30636]
name: int [30585,30588]
===
match
---
name: self [47349,47353]
name: self [47301,47305]
===
match
---
name: str [29910,29913]
name: str [29862,29865]
===
match
---
name: conditions [51337,51347]
name: conditions [51289,51299]
===
match
---
name: following_schedule [28944,28962]
name: following_schedule [28896,28914]
===
match
---
trailer [75913,75918]
trailer [75865,75870]
===
match
---
operator: , [65273,65274]
operator: , [65225,65226]
===
match
---
operator: , [64095,64096]
operator: , [64047,64048]
===
match
---
atom_expr [31803,31879]
atom_expr [31755,31831]
===
match
---
name: self [42448,42452]
name: self [42400,42404]
===
match
---
name: cron [21200,21204]
name: cron [21200,21204]
===
match
---
simple_stmt [13588,13622]
simple_stmt [13588,13622]
===
match
---
number: 3 [47835,47836]
number: 3 [47787,47788]
===
match
---
trailer [68403,68413]
trailer [68355,68365]
===
match
---
name: children [63567,63575]
name: children [63519,63527]
===
match
---
expr_stmt [16639,16695]
expr_stmt [16639,16695]
===
match
---
atom_expr [34087,34101]
atom_expr [34039,34053]
===
match
---
operator: -> [90777,90779]
operator: -> [90729,90731]
===
match
---
fstring_string: Invalid values of dag.default_view: only support  [15198,15247]
fstring_string: Invalid values of dag.default_view: only support  [15198,15247]
===
match
---
operator: , [20299,20300]
operator: , [20299,20300]
===
match
---
operator: , [36427,36428]
operator: , [36379,36380]
===
match
---
atom_expr [37238,37256]
atom_expr [37190,37208]
===
match
---
name: d [65984,65985]
name: d [65936,65937]
===
match
---
name: get_prev [22303,22311]
name: get_prev [22279,22287]
===
match
---
operator: , [83764,83765]
operator: , [83716,83717]
===
match
---
name: airflow [2013,2020]
name: airflow [2013,2020]
===
match
---
name: isinstance [43671,43681]
name: isinstance [43623,43633]
===
match
---
simple_stmt [65115,65134]
simple_stmt [65067,65086]
===
match
---
atom_expr [32217,32237]
atom_expr [32169,32189]
===
match
---
tfpdef [72242,72272]
tfpdef [72194,72224]
===
match
---
name: dag_bound_args [95902,95916]
name: dag_bound_args [95854,95868]
===
match
---
atom_expr [77027,77059]
atom_expr [76979,77011]
===
match
---
atom_expr [18712,18739]
atom_expr [18712,18739]
===
match
---
atom_expr [79607,79630]
atom_expr [79559,79582]
===
match
---
funcdef [16920,17219]
funcdef [16920,17219]
===
match
---
name: task_id [65208,65215]
name: task_id [65160,65167]
===
match
---
operator: , [11292,11293]
operator: , [11292,11293]
===
match
---
name: self [65469,65473]
name: self [65421,65425]
===
match
---
suite [62493,62563]
suite [62445,62515]
===
match
---
name: query [38834,38839]
name: query [38786,38791]
===
match
---
if_stmt [21739,22809]
if_stmt [21715,22761]
===
match
---
param [32523,32527]
param [32475,32479]
===
match
---
atom_expr [11892,11917]
atom_expr [11892,11917]
===
match
---
return_stmt [3648,3668]
return_stmt [3648,3668]
===
match
---
name: partial [67074,67081]
name: partial [67026,67033]
===
match
---
except_clause [17757,17773]
except_clause [17757,17773]
===
match
---
operator: = [58519,58520]
operator: = [58471,58472]
===
match
---
operator: , [3083,3084]
operator: , [3083,3084]
===
match
---
name: __repr__ [16860,16868]
name: __repr__ [16860,16868]
===
match
---
argument [89509,89566]
argument [89461,89518]
===
match
---
name: AirflowException [15451,15467]
name: AirflowException [15451,15467]
===
match
---
name: apply_defaults [95810,95824]
name: apply_defaults [95762,95776]
===
match
---
param [31912,31916]
param [31864,31868]
===
match
---
atom [27224,27270]
atom [27176,27222]
===
match
---
simple_stmt [42572,42719]
simple_stmt [42524,42671]
===
match
---
parameters [33383,33389]
parameters [33335,33341]
===
match
---
operator: , [79941,79942]
operator: , [79893,79894]
===
match
---
operator: , [32243,32244]
operator: , [32195,32196]
===
match
---
atom_expr [52877,52941]
atom_expr [52829,52893]
===
match
---
atom_expr [21742,21792]
atom_expr [21718,21768]
===
match
---
simple_stmt [14713,14784]
simple_stmt [14713,14784]
===
match
---
name: self [66117,66121]
name: self [66069,66073]
===
match
---
trailer [39629,39644]
trailer [39581,39596]
===
match
---
expr_stmt [14206,14296]
expr_stmt [14206,14296]
===
match
---
suite [27010,27035]
suite [26962,26987]
===
match
---
suite [74173,74320]
suite [74125,74272]
===
match
---
name: date_range [2382,2392]
name: date_range [2382,2392]
===
match
---
arglist [77528,77558]
arglist [77480,77510]
===
match
---
name: dag_id [77019,77025]
name: dag_id [76971,76977]
===
match
---
name: dttm [22767,22771]
name: dttm [22719,22723]
===
match
---
suite [53410,56981]
suite [53362,56933]
===
match
---
name: str [65284,65287]
name: str [65236,65239]
===
match
---
param [39110,39121]
param [39062,39073]
===
match
---
simple_stmt [57014,57025]
simple_stmt [56966,56977]
===
match
---
name: self [30347,30351]
name: self [30299,30303]
===
match
---
name: dag_models [91951,91961]
name: dag_models [91903,91913]
===
match
---
string: '.' [14871,14874]
string: '.' [14871,14874]
===
match
---
name: dag_obj [96622,96629]
name: dag_obj [96574,96581]
===
match
---
name: dag_id [33952,33958]
name: dag_id [33904,33910]
===
match
---
atom_expr [60351,60375]
atom_expr [60303,60327]
===
match
---
trailer [76173,76180]
trailer [76125,76132]
===
match
---
name: session [89108,89115]
name: session [89060,89067]
===
match
---
atom_expr [42334,42378]
atom_expr [42286,42330]
===
match
---
name: subdags [40474,40481]
name: subdags [40426,40433]
===
match
---
trailer [79346,79356]
trailer [79298,79308]
===
match
---
expr_stmt [65813,65843]
expr_stmt [65765,65795]
===
match
---
trailer [93271,93281]
trailer [93223,93233]
===
match
---
decorated [82052,83437]
decorated [82004,83389]
===
match
---
operator: = [59762,59763]
operator: = [59714,59715]
===
match
---
name: self [25011,25015]
name: self [24963,24967]
===
match
---
name: airflow [2624,2631]
name: airflow [2624,2631]
===
match
---
atom_expr [10504,10517]
atom_expr [10504,10517]
===
match
---
operator: , [72366,72367]
operator: , [72318,72319]
===
match
---
operator: = [62919,62920]
operator: = [62871,62872]
===
match
---
decorated [30683,30759]
decorated [30635,30711]
===
match
---
name: memo [60306,60310]
name: memo [60258,60262]
===
match
---
simple_stmt [26691,26748]
simple_stmt [26643,26700]
===
match
---
operator: * [60591,60592]
operator: * [60543,60544]
===
match
---
atom_expr [24717,24731]
atom_expr [24669,24683]
===
match
---
name: merge [82007,82012]
name: merge [81959,81964]
===
match
---
atom_expr [79644,79702]
atom_expr [79596,79654]
===
match
---
name: with_row_locks [2692,2706]
name: with_row_locks [2692,2706]
===
match
---
name: session [66165,66172]
name: session [66117,66124]
===
match
---
simple_stmt [894,910]
simple_stmt [894,910]
===
match
---
name: __enter__ [17948,17957]
name: __enter__ [17948,17957]
===
match
---
decorated [74934,75358]
decorated [74886,75310]
===
match
---
comparison [35305,35338]
comparison [35257,35290]
===
match
---
suite [80651,81154]
suite [80603,81106]
===
match
---
name: dag_run_state [59706,59719]
name: dag_run_state [59658,59671]
===
match
---
param [74997,75021]
param [74949,74973]
===
match
---
name: is_subdag [24722,24731]
name: is_subdag [24674,24683]
===
match
---
if_stmt [23776,23926]
if_stmt [23728,23878]
===
match
---
param [48326,48340]
param [48278,48292]
===
match
---
operator: = [58480,58481]
operator: = [58432,58433]
===
match
---
name: session [56569,56576]
name: session [56521,56528]
===
match
---
atom_expr [12139,12156]
atom_expr [12139,12156]
===
match
---
argument [59480,59497]
argument [59432,59449]
===
match
---
name: cls [97993,97996]
name: cls [97945,97948]
===
match
---
operator: @ [89337,89338]
operator: @ [89289,89290]
===
match
---
suite [29253,29396]
suite [29205,29348]
===
match
---
trailer [89329,89331]
trailer [89281,89283]
===
match
---
name: root_dag_id [91138,91149]
name: root_dag_id [91090,91101]
===
match
---
param [48563,48576]
param [48515,48528]
===
match
---
name: self [22533,22537]
name: self [22491,22495]
===
match
---
name: is_subdag [51642,51651]
name: is_subdag [51594,51603]
===
match
---
simple_stmt [92484,92501]
simple_stmt [92436,92453]
===
match
---
trailer [75122,75127]
trailer [75074,75079]
===
match
---
suite [25460,25500]
suite [25412,25452]
===
match
---
arglist [81653,81716]
arglist [81605,81668]
===
match
---
trailer [19093,19098]
trailer [19093,19098]
===
match
---
atom [85019,85021]
atom [84971,84973]
===
match
---
operator: , [59542,59543]
operator: , [59494,59495]
===
match
---
operator: { [47348,47349]
operator: { [47300,47301]
===
match
---
name: self [88704,88708]
name: self [88656,88660]
===
match
---
suite [23734,23767]
suite [23686,23719]
===
match
---
simple_stmt [987,1017]
simple_stmt [987,1017]
===
match
---
trailer [22537,22546]
trailer [22495,22504]
===
match
---
atom_expr [68073,68106]
atom_expr [68025,68058]
===
match
---
simple_stmt [14942,14979]
simple_stmt [14942,14979]
===
match
---
name: len [68640,68643]
name: len [68592,68595]
===
match
---
name: tags [87459,87463]
name: tags [87411,87415]
===
match
---
atom_expr [77037,77058]
atom_expr [76989,77010]
===
match
---
name: start_date [67275,67285]
name: start_date [67227,67237]
===
match
---
atom_expr [12011,12022]
atom_expr [12011,12022]
===
match
---
atom_expr [90628,90663]
atom_expr [90580,90615]
===
match
---
simple_stmt [91871,91909]
simple_stmt [91823,91861]
===
match
---
string: '_log' [60501,60507]
string: '_log' [60453,60459]
===
match
---
trailer [91197,91204]
trailer [91149,91156]
===
match
---
simple_stmt [36451,36485]
simple_stmt [36403,36437]
===
match
---
operator: = [74361,74362]
operator: = [74313,74314]
===
match
---
if_stmt [42293,42379]
if_stmt [42245,42331]
===
match
---
name: task [68430,68434]
name: task [68382,68386]
===
match
---
trailer [14664,14683]
trailer [14664,14683]
===
match
---
operator: = [58311,58312]
operator: = [58263,58264]
===
match
---
name: self [66215,66219]
name: self [66167,66171]
===
match
---
parameters [32522,32528]
parameters [32474,32480]
===
match
---
expr_stmt [20698,20746]
expr_stmt [20698,20746]
===
match
---
atom_expr [22895,22912]
atom_expr [22847,22864]
===
match
---
name: updated_access_control [19049,19071]
name: updated_access_control [19049,19071]
===
match
---
atom_expr [66589,66594]
atom_expr [66541,66546]
===
match
---
string: '' [12389,12391]
string: '' [12389,12391]
===
match
---
suite [95392,97029]
suite [95344,96981]
===
match
---
simple_stmt [98134,98165]
simple_stmt [98086,98117]
===
match
---
name: k [60286,60287]
name: k [60238,60239]
===
match
---
param [30716,30720]
param [30668,30672]
===
match
---
simple_stmt [86142,86201]
simple_stmt [86094,86153]
===
match
---
param [39840,39852]
param [39792,39804]
===
match
---
arglist [75141,75296]
arglist [75093,75248]
===
match
---
decorated [29706,29773]
decorated [29658,29725]
===
match
---
simple_stmt [21192,21224]
simple_stmt [21192,21224]
===
match
---
name: resolve_template_files [41131,41153]
name: resolve_template_files [41083,41105]
===
match
---
trailer [89483,89490]
trailer [89435,89442]
===
match
---
funcdef [35508,36920]
funcdef [35460,36872]
===
match
---
name: permissions [2209,2220]
name: permissions [2209,2220]
===
match
---
operator: = [12351,12352]
operator: = [12351,12352]
===
match
---
name: airflow [1604,1611]
name: airflow [1604,1611]
===
match
---
atom_expr [79100,79112]
atom_expr [79052,79064]
===
match
---
trailer [37794,37801]
trailer [37746,37753]
===
match
---
name: acyclic [47261,47268]
name: acyclic [47213,47220]
===
match
---
name: of [93581,93583]
name: of [93533,93535]
===
match
---
trailer [43142,43156]
trailer [43094,43108]
===
match
---
name: next_dagrun_create_after [87818,87842]
name: next_dagrun_create_after [87770,87794]
===
match
---
name: dag_id [91158,91164]
name: dag_id [91110,91116]
===
match
---
name: self [25745,25749]
name: self [25697,25701]
===
match
---
suite [31234,31267]
suite [31186,31219]
===
match
---
operator: = [22468,22469]
operator: = [22444,22445]
===
match
---
name: max_active_runs [14918,14933]
name: max_active_runs [14918,14933]
===
match
---
trailer [64604,64617]
trailer [64556,64569]
===
match
---
atom_expr [97277,97309]
atom_expr [97229,97261]
===
match
---
atom_expr [12734,12756]
atom_expr [12734,12756]
===
match
---
operator: <= [43624,43626]
operator: <= [43576,43578]
===
match
---
operator: = [91882,91883]
operator: = [91834,91835]
===
match
---
trailer [75938,75944]
trailer [75890,75896]
===
match
---
param [93751,93774]
param [93703,93726]
===
match
---
trailer [96792,96799]
trailer [96744,96751]
===
match
---
name: tis [44303,44306]
name: tis [44255,44258]
===
match
---
param [34064,34069]
param [34016,34021]
===
match
---
trailer [39583,39590]
trailer [39535,39542]
===
match
---
trailer [28962,28968]
trailer [28914,28920]
===
match
---
trailer [2933,2964]
trailer [2933,2964]
===
match
---
name: value [31214,31219]
name: value [31166,31171]
===
match
---
trailer [15658,15668]
trailer [15658,15668]
===
match
---
argument [57885,57893]
argument [57837,57845]
===
match
---
arglist [86258,86280]
arglist [86210,86232]
===
match
---
operator: = [37924,37925]
operator: = [37876,37877]
===
match
---
name: synchronize_session [48190,48209]
name: synchronize_session [48142,48161]
===
match
---
atom_expr [85915,85937]
atom_expr [85867,85889]
===
match
---
name: self [72058,72062]
name: self [72010,72014]
===
match
---
atom_expr [76649,76666]
atom_expr [76601,76618]
===
match
---
tfpdef [11679,11714]
tfpdef [11679,11714]
===
match
---
atom_expr [86446,86465]
atom_expr [86398,86417]
===
match
---
trailer [82871,82875]
trailer [82823,82827]
===
match
---
operator: = [22347,22348]
operator: = [22323,22324]
===
match
---
name: state [52884,52889]
name: state [52836,52841]
===
match
---
return_stmt [37267,37286]
return_stmt [37219,37238]
===
match
---
comparison [12127,12156]
comparison [12127,12156]
===
match
---
atom [58436,58438]
atom [58388,58390]
===
match
---
trailer [47606,47616]
trailer [47558,47568]
===
match
---
name: expression [1585,1595]
name: expression [1585,1595]
===
match
---
decorator [29778,29793]
decorator [29730,29745]
===
match
---
name: only_running [58238,58250]
name: only_running [58190,58202]
===
match
---
expr_stmt [78066,78106]
expr_stmt [78018,78058]
===
match
---
operator: } [16144,16145]
operator: } [16144,16145]
===
match
---
comparison [39577,39605]
comparison [39529,39557]
===
match
---
atom_expr [25938,25950]
atom_expr [25890,25902]
===
match
---
name: value [31261,31266]
name: value [31213,31218]
===
match
---
trailer [12788,12799]
trailer [12788,12799]
===
match
---
argument [71437,71462]
argument [71389,71414]
===
match
---
atom_expr [73759,73821]
atom_expr [73711,73773]
===
match
---
param [69154,69188]
param [69106,69140]
===
match
---
name: value [96551,96556]
name: value [96503,96508]
===
match
---
trailer [82006,82012]
trailer [81958,81964]
===
match
---
suite [25662,25711]
suite [25614,25663]
===
match
---
operator: , [78911,78912]
operator: , [78863,78864]
===
match
---
simple_stmt [58052,58069]
simple_stmt [58004,58021]
===
match
---
suite [51320,51413]
suite [51272,51365]
===
match
---
decorator [89196,89213]
decorator [89148,89165]
===
match
---
atom_expr [38847,38860]
atom_expr [38799,38812]
===
match
---
simple_stmt [52693,52743]
simple_stmt [52645,52695]
===
match
---
operator: , [17168,17169]
operator: , [17168,17169]
===
match
---
operator: , [91276,91277]
operator: , [91228,91229]
===
match
---
name: searchpath [41393,41403]
name: searchpath [41345,41355]
===
match
---
expr_stmt [65735,65759]
expr_stmt [65687,65711]
===
match
---
name: start_date [52669,52679]
name: start_date [52621,52631]
===
match
---
simple_stmt [66814,66825]
simple_stmt [66766,66777]
===
match
---
name: utils [57736,57741]
name: utils [57688,57693]
===
match
---
name: not_none_state [44044,44058]
name: not_none_state [43996,44010]
===
match
---
name: DR [3457,3459]
name: DR [3457,3459]
===
match
---
expr_stmt [96770,96827]
expr_stmt [96722,96779]
===
match
---
name: task_id [63708,63715]
name: task_id [63660,63667]
===
match
---
operator: = [74098,74099]
operator: = [74050,74051]
===
match
---
name: tis [52980,52983]
name: tis [52932,52935]
===
match
---
fstring_expr [16899,16912]
fstring_expr [16899,16912]
===
match
---
simple_stmt [35592,36258]
simple_stmt [35544,36210]
===
match
---
name: self [21753,21757]
name: self [21729,21733]
===
match
---
name: self [32867,32871]
name: self [32819,32823]
===
match
---
argument [71670,71685]
argument [71622,71637]
===
match
---
name: self [68092,68096]
name: self [68044,68048]
===
match
---
trailer [94163,94180]
trailer [94115,94132]
===
match
---
operator: = [37373,37374]
operator: = [37325,37326]
===
match
---
return_stmt [34258,34294]
return_stmt [34210,34246]
===
match
---
operator: = [74467,74468]
operator: = [74419,74420]
===
match
---
name: paused_dag_ids [90115,90129]
name: paused_dag_ids [90067,90081]
===
match
---
trailer [37237,37257]
trailer [37189,37209]
===
match
---
name: run [74329,74332]
name: run [74281,74284]
===
match
---
operator: = [42915,42916]
operator: = [42867,42868]
===
match
---
try_stmt [36716,36920]
try_stmt [36668,36872]
===
match
---
trailer [28308,28310]
trailer [28260,28262]
===
match
---
operator: , [58201,58202]
operator: , [58153,58154]
===
match
---
name: dag [81877,81880]
name: dag [81829,81832]
===
match
---
atom_expr [78215,78229]
atom_expr [78167,78181]
===
match
---
fstring_end: ' [15535,15536]
fstring_end: ' [15535,15536]
===
match
---
name: filter [51565,51571]
name: filter [51517,51523]
===
match
---
trailer [33168,33192]
trailer [33120,33144]
===
match
---
atom_expr [23380,23402]
atom_expr [23332,23354]
===
match
---
name: start_date [25750,25760]
name: start_date [25702,25712]
===
match
---
test [96788,96827]
test [96740,96779]
===
match
---
name: tags [79128,79132]
name: tags [79080,79084]
===
match
---
or_test [38634,38658]
or_test [38586,38610]
===
match
---
atom_expr [78654,78675]
atom_expr [78606,78627]
===
match
---
name: normalize_schedule [26712,26730]
name: normalize_schedule [26664,26682]
===
match
---
trailer [55425,55437]
trailer [55377,55389]
===
match
---
trailer [78718,78735]
trailer [78670,78687]
===
match
---
name: self [17572,17576]
name: self [17572,17576]
===
match
---
if_stmt [47254,47364]
if_stmt [47206,47316]
===
match
---
name: timezone [22630,22638]
name: timezone [22582,22590]
===
match
---
name: existing_dag_ids [76307,76323]
name: existing_dag_ids [76259,76275]
===
match
---
name: dag_id [29303,29309]
name: dag_id [29255,29261]
===
match
---
simple_stmt [84910,84986]
simple_stmt [84862,84938]
===
match
---
name: delta [22282,22287]
name: delta [22258,22263]
===
match
---
comparison [43596,43635]
comparison [43548,43587]
===
match
---
name: property [34665,34673]
name: property [34617,34625]
===
match
---
name: path [32276,32280]
name: path [32228,32232]
===
match
---
if_stmt [55278,55367]
if_stmt [55230,55319]
===
match
---
expr_stmt [2909,2964]
expr_stmt [2909,2964]
===
match
---
atom_expr [53546,53560]
atom_expr [53498,53512]
===
match
---
trailer [68643,68659]
trailer [68595,68611]
===
match
---
name: __tablename__ [91847,91860]
name: __tablename__ [91799,91812]
===
match
---
name: self [85629,85633]
name: self [85581,85585]
===
match
---
name: copied [63357,63363]
name: copied [63309,63315]
===
match
---
name: child [63607,63612]
name: child [63559,63564]
===
match
---
atom_expr [68133,68145]
atom_expr [68085,68097]
===
match
---
simple_stmt [43526,43567]
simple_stmt [43478,43519]
===
match
---
dotted_name [2306,2319]
dotted_name [2306,2319]
===
match
---
operator: , [56649,56650]
operator: , [56601,56602]
===
match
---
string: 'params' [12252,12260]
string: 'params' [12252,12260]
===
match
---
trailer [3581,3587]
trailer [3581,3587]
===
match
---
simple_stmt [73999,74079]
simple_stmt [73951,74031]
===
match
---
name: end_date [68062,68070]
name: end_date [68014,68022]
===
match
---
name: utcnow [78503,78509]
name: utcnow [78455,78461]
===
match
---
string: '_full_filepath' [83844,83860]
string: '_full_filepath' [83796,83812]
===
match
---
trailer [68418,68426]
trailer [68370,68378]
===
match
---
trailer [43976,43982]
trailer [43928,43934]
===
match
---
trailer [77997,78007]
trailer [77949,77959]
===
match
---
name: collections [915,926]
name: collections [915,926]
===
match
---
operator: = [87342,87343]
operator: = [87294,87295]
===
match
---
trailer [38688,38748]
trailer [38640,38700]
===
match
---
name: self [30415,30419]
name: self [30367,30371]
===
match
---
name: Column [87126,87132]
name: Column [87078,87084]
===
match
---
annassign [53802,53941]
annassign [53754,53893]
===
match
---
name: RePatternType [61004,61017]
name: RePatternType [60956,60969]
===
match
---
name: f [95704,95705]
name: f [95656,95657]
===
match
---
operator: } [68334,68335]
operator: } [68286,68287]
===
match
---
trailer [53902,53914]
trailer [53854,53866]
===
match
---
atom_expr [64885,64905]
atom_expr [64837,64857]
===
match
---
name: TI [33251,33253]
name: TI [33203,33205]
===
match
---
name: has_task_concurrency_limits [78756,78783]
name: has_task_concurrency_limits [78708,78735]
===
match
---
name: deactivate_deleted_dags [91388,91411]
name: deactivate_deleted_dags [91340,91363]
===
match
---
expr_stmt [57401,57413]
expr_stmt [57353,57365]
===
match
---
trailer [12503,12508]
trailer [12503,12508]
===
match
---
trailer [65363,65373]
trailer [65315,65325]
===
match
---
name: type [74061,74065]
name: type [74013,74017]
===
match
---
name: only_running [56199,56211]
name: only_running [56151,56163]
===
match
---
operator: -> [30012,30014]
operator: -> [29964,29966]
===
match
---
operator: , [1392,1393]
operator: , [1392,1393]
===
match
---
trailer [36892,36919]
trailer [36844,36871]
===
match
---
name: getint [10841,10847]
name: getint [10841,10847]
===
match
---
name: success [35542,35549]
name: success [35494,35501]
===
match
---
name: airflow [2574,2581]
name: airflow [2574,2581]
===
match
---
name: Interval [87418,87426]
name: Interval [87370,87378]
===
match
---
name: stacklevel [88503,88513]
name: stacklevel [88455,88465]
===
match
---
operator: += [41480,41482]
operator: += [41432,41434]
===
match
---
simple_stmt [94110,94202]
simple_stmt [94062,94154]
===
match
---
name: get_num_task_instances [82095,82117]
name: get_num_task_instances [82047,82069]
===
match
---
name: calculate_dagrun_date_fields [78862,78890]
name: calculate_dagrun_date_fields [78814,78842]
===
match
---
name: orm_dag [78748,78755]
name: orm_dag [78700,78707]
===
match
---
name: dag [62905,62908]
name: dag [62857,62860]
===
match
---
name: include_subdags [59669,59684]
name: include_subdags [59621,59636]
===
match
---
name: qry [33303,33306]
name: qry [33255,33258]
===
match
---
name: execution_date [52713,52727]
name: execution_date [52665,52679]
===
match
---
trailer [77326,77335]
trailer [77278,77287]
===
match
---
atom_expr [56069,56087]
atom_expr [56021,56039]
===
match
---
operator: = [72469,72470]
operator: = [72421,72422]
===
match
---
name: confirm_prompt [52177,52191]
name: confirm_prompt [52129,52143]
===
match
---
trailer [64762,64768]
trailer [64714,64720]
===
match
---
atom_expr [43549,43566]
atom_expr [43501,43518]
===
match
---
decorated [32758,32898]
decorated [32710,32850]
===
match
---
argument [95301,95310]
argument [95253,95262]
===
match
---
name: args [95376,95380]
name: args [95328,95332]
===
match
---
if_stmt [70944,71244]
if_stmt [70896,71196]
===
match
---
operator: = [80014,80015]
operator: = [79966,79967]
===
match
---
expr_stmt [78576,78613]
expr_stmt [78528,78565]
===
match
---
operator: = [57924,57925]
operator: = [57876,57877]
===
match
---
simple_stmt [27455,27476]
simple_stmt [27407,27428]
===
match
---
name: self [67270,67274]
name: self [67222,67226]
===
match
---
trailer [34283,34293]
trailer [34235,34245]
===
match
---
name: schedule_interval [35237,35254]
name: schedule_interval [35189,35206]
===
match
---
trailer [78550,78563]
trailer [78502,78515]
===
match
---
trailer [36819,36865]
trailer [36771,36817]
===
match
---
atom_expr [65555,65577]
atom_expr [65507,65529]
===
match
---
operator: ** [95382,95384]
operator: ** [95334,95336]
===
match
---
trailer [44336,44343]
trailer [44288,44295]
===
match
---
expr_stmt [16487,16566]
expr_stmt [16487,16566]
===
match
---
name: max_recursion_depth [56707,56726]
name: max_recursion_depth [56659,56678]
===
match
---
trailer [14393,14408]
trailer [14393,14408]
===
match
---
operator: = [69201,69202]
operator: = [69153,69154]
===
match
---
trailer [43104,43109]
trailer [43056,43061]
===
match
---
comparison [33251,33276]
comparison [33203,33228]
===
match
---
trailer [71827,71829]
trailer [71779,71781]
===
match
---
subscriptlist [2934,2963]
subscriptlist [2934,2963]
===
match
---
name: cls [93502,93505]
name: cls [93454,93457]
===
match
---
not_test [75872,75880]
not_test [75824,75832]
===
match
---
name: query [54942,54947]
name: query [54894,54899]
===
match
---
suite [29744,29773]
suite [29696,29725]
===
match
---
fstring_string: Could not find dag  [55544,55563]
fstring_string: Could not find dag  [55496,55515]
===
match
---
atom_expr [68399,68427]
atom_expr [68351,68379]
===
match
---
param [69037,69051]
param [68989,69003]
===
match
---
tfpdef [19418,19438]
tfpdef [19418,19438]
===
match
---
param [18074,18077]
param [18074,18077]
===
match
---
name: self [13588,13592]
name: self [13588,13592]
===
match
---
operator: , [57842,57843]
operator: , [57794,57795]
===
match
---
operator: , [11118,11119]
operator: , [11118,11119]
===
match
---
name: normalized_schedule_interval [19721,19749]
name: normalized_schedule_interval [19721,19749]
===
match
---
name: pool [71599,71603]
name: pool [71551,71555]
===
match
---
fstring_end: " [16913,16914]
fstring_end: " [16913,16914]
===
match
---
name: State [52919,52924]
name: State [52871,52876]
===
match
---
decorator [47405,47422]
decorator [47357,47374]
===
match
---
param [3173,3181]
param [3173,3181]
===
match
---
suite [60608,60927]
suite [60560,60879]
===
match
---
atom_expr [88704,88736]
atom_expr [88656,88688]
===
match
---
trailer [21384,21395]
trailer [21360,21371]
===
match
---
funcdef [31767,31880]
funcdef [31719,31832]
===
match
---
atom [12035,12037]
atom [12035,12037]
===
match
---
name: next_execution_date [23884,23903]
name: next_execution_date [23836,23855]
===
match
---
comparison [54305,54346]
comparison [54257,54298]
===
match
---
number: 4 [66786,66787]
number: 4 [66738,66739]
===
match
---
operator: , [56022,56023]
operator: , [55974,55975]
===
match
---
operator: , [56473,56474]
operator: , [56425,56426]
===
match
---
simple_stmt [18615,18627]
simple_stmt [18615,18627]
===
match
---
operator: , [48530,48531]
operator: , [48482,48483]
===
match
---
arglist [51753,51894]
arglist [51705,51846]
===
match
---
operator: = [9888,9889]
operator: = [9888,9889]
===
match
---
name: timezone [13956,13964]
name: timezone [13956,13964]
===
match
---
fstring_start: f" [88913,88915]
fstring_start: f" [88865,88867]
===
match
---
param [80310,80314]
param [80262,80266]
===
match
---
trailer [63612,63620]
trailer [63564,63572]
===
match
---
simple_stmt [27541,28039]
simple_stmt [27493,27991]
===
match
---
parameters [91411,91461]
parameters [91363,91413]
===
match
---
atom_expr [65220,65229]
atom_expr [65172,65181]
===
match
---
trailer [20736,20745]
trailer [20736,20745]
===
match
---
if_stmt [60484,60546]
if_stmt [60436,60498]
===
match
---
name: query [66173,66178]
name: query [66125,66130]
===
match
---
argument [41979,41998]
argument [41931,41950]
===
match
---
operator: == [25034,25036]
operator: == [24986,24988]
===
match
---
trailer [60894,60909]
trailer [60846,60861]
===
match
---
name: _log [60529,60533]
name: _log [60481,60485]
===
match
---
name: combine [43072,43079]
name: combine [43024,43031]
===
match
---
simple_stmt [65685,65710]
simple_stmt [65637,65662]
===
match
---
name: start_date [19659,19669]
name: start_date [19659,19669]
===
match
---
trailer [76672,76696]
trailer [76624,76648]
===
match
---
trailer [44221,44227]
trailer [44173,44179]
===
match
---
strings [54491,54679]
strings [54443,54631]
===
match
---
parameters [90605,90611]
parameters [90557,90563]
===
match
---
trailer [77579,77801]
trailer [77531,77753]
===
match
---
name: naive [21969,21974]
name: naive [21945,21950]
===
match
---
for_stmt [59373,59788]
for_stmt [59325,59740]
===
match
---
name: filter [77074,77080]
name: filter [77026,77032]
===
match
---
atom_expr [41264,41282]
atom_expr [41216,41234]
===
match
---
atom_expr [48168,48180]
atom_expr [48120,48132]
===
match
---
operator: , [94596,94597]
operator: , [94548,94549]
===
match
---
trailer [37962,37979]
trailer [37914,37931]
===
match
---
name: start_date [67721,67731]
name: start_date [67673,67683]
===
match
---
arglist [11258,11291]
arglist [11258,11291]
===
match
---
operator: = [3210,3211]
operator: = [3210,3211]
===
match
---
name: key [53549,53552]
name: key [53501,53504]
===
match
---
atom_expr [59836,59876]
atom_expr [59788,59828]
===
match
---
arglist [48167,48217]
arglist [48119,48169]
===
match
---
string: '*' [77554,77557]
string: '*' [77506,77509]
===
match
---
simple_stmt [78576,78614]
simple_stmt [78528,78566]
===
match
---
operator: , [67120,67121]
operator: , [67072,67073]
===
match
---
operator: @ [30908,30909]
operator: @ [30860,30861]
===
match
---
operator: } [36701,36702]
operator: } [36653,36654]
===
match
---
atom_expr [80988,81062]
atom_expr [80940,81014]
===
match
---
operator: , [85565,85566]
operator: , [85517,85518]
===
match
---
atom_expr [10299,10316]
atom_expr [10299,10316]
===
match
---
name: bulk_sync_to_db [79652,79667]
name: bulk_sync_to_db [79604,79619]
===
match
---
trailer [51966,52642]
trailer [51918,52594]
===
match
---
import_from [1313,1361]
import_from [1313,1361]
===
match
---
operator: , [69262,69263]
operator: , [69214,69215]
===
match
---
trailer [77342,77349]
trailer [77294,77301]
===
match
---
name: copied [63672,63678]
name: copied [63624,63630]
===
match
---
trailer [67511,67522]
trailer [67463,67474]
===
match
---
simple_stmt [76229,76298]
simple_stmt [76181,76250]
===
match
---
dotted_name [1520,1542]
dotted_name [1520,1542]
===
match
---
operator: = [76056,76057]
operator: = [76008,76009]
===
match
---
name: Column [86522,86528]
name: Column [86474,86480]
===
match
---
name: dict [77496,77500]
name: dict [77448,77452]
===
match
---
suite [79357,79595]
suite [79309,79547]
===
match
---
name: start_date [42864,42874]
name: start_date [42816,42826]
===
match
---
name: access_control [18260,18274]
name: access_control [18260,18274]
===
match
---
expr_stmt [82669,82783]
expr_stmt [82621,82735]
===
match
---
funcdef [90220,90571]
funcdef [90172,90523]
===
match
---
operator: , [93579,93580]
operator: , [93531,93532]
===
match
---
if_stmt [15038,15329]
if_stmt [15038,15329]
===
match
---
parameters [44454,44460]
parameters [44406,44412]
===
match
---
trailer [77036,77059]
trailer [76988,77011]
===
match
---
atom_expr [95241,95253]
atom_expr [95193,95205]
===
match
---
operator: = [10796,10797]
operator: = [10796,10797]
===
match
---
operator: = [15405,15406]
operator: = [15405,15406]
===
match
---
operator: , [10026,10027]
operator: , [10026,10027]
===
match
---
name: DagRunType [72395,72405]
name: DagRunType [72347,72357]
===
match
---
string: "" [13011,13013]
string: "" [13011,13013]
===
match
---
atom_expr [39969,39990]
atom_expr [39921,39942]
===
match
---
atom_expr [81076,81089]
atom_expr [81028,81041]
===
match
---
atom_expr [17791,17824]
atom_expr [17791,17824]
===
match
---
param [61077,61099]
param [61029,61051]
===
match
---
name: all_tis [58426,58433]
name: all_tis [58378,58385]
===
match
---
operator: , [18739,18740]
operator: , [18739,18740]
===
match
---
simple_stmt [67057,67098]
simple_stmt [67009,67050]
===
match
---
simple_stmt [70885,70935]
simple_stmt [70837,70887]
===
match
---
suite [36951,37287]
suite [36903,37239]
===
match
---
atom [89921,90105]
atom [89873,90057]
===
match
---
name: catchup [25000,25007]
name: catchup [24952,24959]
===
match
---
name: user_defined_macros [60356,60375]
name: user_defined_macros [60308,60327]
===
match
---
name: permissions [18712,18723]
name: permissions [18712,18723]
===
match
---
operator: = [69021,69022]
operator: = [68973,68974]
===
match
---
name: session [3432,3439]
name: session [3432,3439]
===
match
---
name: dag_obj [96770,96777]
name: dag_obj [96722,96729]
===
match
---
param [58149,58154]
param [58101,58106]
===
match
---
trailer [78087,78098]
trailer [78039,78050]
===
match
---
trailer [56072,56087]
trailer [56024,56039]
===
match
---
name: property [31886,31894]
name: property [31838,31846]
===
match
---
trailer [64078,64102]
trailer [64030,64054]
===
match
---
atom_expr [60993,61033]
atom_expr [60945,60985]
===
match
---
atom_expr [13249,13280]
atom_expr [13249,13280]
===
match
---
name: count [77548,77553]
name: count [77500,77505]
===
match
---
name: query [89943,89948]
name: query [89895,89900]
===
match
---
operator: = [17633,17634]
operator: = [17633,17634]
===
match
---
atom_expr [91324,91340]
atom_expr [91276,91292]
===
match
---
trailer [93225,93230]
trailer [93177,93182]
===
match
---
not_test [28545,28563]
not_test [28497,28515]
===
match
---
atom_expr [57517,57523]
atom_expr [57469,57475]
===
match
---
simple_stmt [19085,19336]
simple_stmt [19085,19336]
===
match
---
name: task_dict [65399,65408]
name: task_dict [65351,65360]
===
match
---
name: all [81731,81734]
name: all [81683,81686]
===
match
---
simple_stmt [1017,1203]
simple_stmt [1017,1203]
===
match
---
parameters [27498,27531]
parameters [27450,27483]
===
match
---
operator: = [31617,31618]
operator: = [31569,31570]
===
match
---
name: filter [89979,89985]
name: filter [89931,89937]
===
match
---
operator: = [57734,57735]
operator: = [57686,57687]
===
match
---
name: parent_dag [78088,78098]
name: parent_dag [78040,78050]
===
match
---
simple_stmt [39155,39486]
simple_stmt [39107,39438]
===
match
---
atom_expr [88922,88933]
atom_expr [88874,88885]
===
match
---
operator: = [43535,43536]
operator: = [43487,43488]
===
match
---
name: timezone [13889,13897]
name: timezone [13889,13897]
===
match
---
atom_expr [2928,2964]
atom_expr [2928,2964]
===
match
---
name: child [63504,63509]
name: child [63456,63461]
===
match
---
simple_stmt [23747,23767]
simple_stmt [23699,23719]
===
match
---
param [28823,28827]
param [28775,28779]
===
match
---
name: active_dag_ids [80621,80635]
name: active_dag_ids [80573,80587]
===
match
---
expr_stmt [74329,74691]
expr_stmt [74281,74643]
===
match
---
name: tii [55229,55232]
name: tii [55181,55184]
===
match
---
operator: = [52503,52504]
operator: = [52455,52456]
===
match
---
operator: = [71311,71312]
operator: = [71263,71264]
===
match
---
expr_stmt [63357,63377]
expr_stmt [63309,63329]
===
match
---
trailer [89301,89323]
trailer [89253,89275]
===
match
---
argument [52484,52523]
argument [52436,52475]
===
match
---
operator: , [38998,38999]
operator: , [38950,38951]
===
match
---
name: property [33347,33355]
name: property [33299,33307]
===
match
---
atom_expr [3457,3466]
atom_expr [3457,3466]
===
match
---
return_stmt [60554,60567]
return_stmt [60506,60519]
===
match
---
operator: , [56278,56279]
operator: , [56230,56231]
===
match
---
operator: = [28937,28938]
operator: = [28889,28890]
===
match
---
name: __serialized_fields [84533,84552]
name: __serialized_fields [84485,84504]
===
match
---
funcdef [31098,31167]
funcdef [31050,31119]
===
match
---
operator: @ [40456,40457]
operator: @ [40408,40409]
===
match
---
name: warnings [901,909]
name: warnings [901,909]
===
match
---
operator: , [79013,79014]
operator: , [78965,78966]
===
match
---
operator: = [27346,27347]
operator: = [27298,27299]
===
match
---
name: session [82030,82037]
name: session [81982,81989]
===
match
---
simple_stmt [12831,12863]
simple_stmt [12831,12863]
===
match
---
name: states [82913,82919]
name: states [82865,82871]
===
match
---
trailer [31718,31743]
trailer [31670,31695]
===
match
---
simple_stmt [97251,97310]
simple_stmt [97203,97262]
===
match
---
trailer [95926,95930]
trailer [95878,95882]
===
match
---
operator: = [35213,35214]
operator: = [35165,35166]
===
match
---
return_stmt [29923,29949]
return_stmt [29875,29901]
===
match
---
string: 'start_date' [13211,13223]
string: 'start_date' [13211,13223]
===
match
---
name: min_task_end_date [27399,27416]
name: min_task_end_date [27351,27368]
===
match
---
trailer [48159,48166]
trailer [48111,48118]
===
match
---
name: group [63226,63231]
name: group [63178,63183]
===
match
---
operator: = [62657,62658]
operator: = [62609,62610]
===
match
---
name: self [12011,12015]
name: self [12011,12015]
===
match
---
operator: , [1766,1767]
operator: , [1766,1767]
===
match
---
trailer [12251,12261]
trailer [12251,12261]
===
match
---
expr_stmt [51125,51148]
expr_stmt [51077,51100]
===
match
---
trailer [64718,64740]
trailer [64670,64692]
===
match
---
name: FileSystemLoader [41622,41638]
name: FileSystemLoader [41574,41590]
===
match
---
name: DEFAULT_VIEW_PRESETS [2965,2985]
name: DEFAULT_VIEW_PRESETS [2965,2985]
===
match
---
name: dag_id [51791,51797]
name: dag_id [51743,51749]
===
match
---
operator: , [17141,17142]
operator: , [17141,17142]
===
match
---
name: _default_view [31065,31078]
name: _default_view [31017,31030]
===
match
---
trailer [64586,64604]
trailer [64538,64556]
===
match
---
param [82154,82166]
param [82106,82118]
===
match
---
name: t [66922,66923]
name: t [66874,66875]
===
match
---
name: next_run_date [25782,25795]
name: next_run_date [25734,25747]
===
match
---
trailer [33935,33942]
trailer [33887,33894]
===
match
---
trailer [11139,11145]
trailer [11139,11145]
===
match
---
name: RUNNING [37845,37852]
name: RUNNING [37797,37804]
===
match
---
atom_expr [35305,35327]
atom_expr [35257,35279]
===
match
---
name: get_is_active [33775,33788]
name: get_is_active [33727,33740]
===
match
---
name: datetime [72178,72186]
name: datetime [72130,72138]
===
match
---
decorated [40456,41122]
decorated [40408,41074]
===
match
---
operator: = [11503,11504]
operator: = [11503,11504]
===
match
---
trailer [60043,60053]
trailer [59995,60005]
===
match
---
operator: , [56726,56727]
operator: , [56678,56679]
===
match
---
name: ignore_task_deps [71476,71492]
name: ignore_task_deps [71428,71444]
===
match
---
except_clause [36767,36783]
except_clause [36719,36735]
===
match
---
trailer [67839,67848]
trailer [67791,67800]
===
match
---
trailer [63979,63988]
trailer [63931,63940]
===
match
---
argument [87518,87540]
argument [87470,87492]
===
match
---
operator: = [41404,41405]
operator: = [41356,41357]
===
match
---
if_stmt [36351,36920]
if_stmt [36303,36872]
===
match
---
operator: = [89537,89538]
operator: = [89489,89490]
===
match
---
name: self [36568,36572]
name: self [36520,36524]
===
match
---
for_stmt [46681,47241]
for_stmt [46633,47193]
===
match
---
atom_expr [72254,72272]
atom_expr [72206,72224]
===
match
---
suite [32108,32328]
suite [32060,32280]
===
match
---
name: downstream_group_ids [64453,64473]
name: downstream_group_ids [64405,64425]
===
match
---
name: graph_unsorted [46983,46997]
name: graph_unsorted [46935,46949]
===
match
---
name: date_last_automated_dagrun [24048,24074]
name: date_last_automated_dagrun [24000,24026]
===
match
---
arglist [88088,88146]
arglist [88040,88098]
===
match
---
name: dry_run [57156,57163]
name: dry_run [57108,57115]
===
match
---
operator: = [10834,10835]
operator: = [10834,10835]
===
match
---
atom_expr [81905,81937]
atom_expr [81857,81889]
===
match
---
atom_expr [65984,66001]
atom_expr [65936,65953]
===
match
---
operator: , [10453,10454]
operator: , [10453,10454]
===
match
---
simple_stmt [54919,55200]
simple_stmt [54871,55152]
===
match
---
name: get_dagmodel [89057,89069]
name: get_dagmodel [89009,89021]
===
match
---
name: task [67716,67720]
name: task [67668,67672]
===
match
---
name: owner [32517,32522]
name: owner [32469,32474]
===
match
---
operator: , [72121,72122]
operator: , [72073,72074]
===
match
---
not_test [42934,42948]
not_test [42886,42900]
===
match
---
operator: -> [33809,33811]
operator: -> [33761,33763]
===
match
---
name: query [37733,37738]
name: query [37685,37690]
===
match
---
operator: = [31606,31607]
operator: = [31558,31559]
===
match
---
arglist [64079,64101]
arglist [64031,64053]
===
match
---
string: 'pickling_duration' [65858,65877]
string: 'pickling_duration' [65810,65829]
===
match
---
name: include_subdag_tasks [44934,44954]
name: include_subdag_tasks [44886,44906]
===
match
---
name: task_id [68138,68145]
name: task_id [68090,68097]
===
match
---
name: dag_id [29570,29576]
name: dag_id [29522,29528]
===
match
---
name: false [3582,3587]
name: false [3582,3587]
===
match
---
trailer [28242,28248]
trailer [28194,28200]
===
match
---
atom_expr [41483,41507]
atom_expr [41435,41459]
===
match
---
name: TI [51572,51574]
name: TI [51524,51526]
===
match
---
operator: , [52009,52010]
operator: , [51961,51962]
===
match
---
name: type [17406,17410]
name: type [17406,17410]
===
match
---
trailer [87533,87540]
trailer [87485,87492]
===
match
---
name: backref [1481,1488]
name: backref [1481,1488]
===
match
---
trailer [20725,20746]
trailer [20725,20746]
===
match
---
name: dag_models [91871,91881]
name: dag_models [91823,91833]
===
match
---
expr_stmt [78391,78417]
expr_stmt [78343,78369]
===
match
---
expr_stmt [36606,36656]
expr_stmt [36558,36608]
===
match
---
name: owners [78223,78229]
name: owners [78175,78181]
===
match
---
operator: , [21572,21573]
operator: , [21548,21549]
===
match
---
string: "Next run date based on tasks %s" [26095,26128]
string: "Next run date based on tasks %s" [26047,26080]
===
match
---
trailer [65604,65633]
trailer [65556,65585]
===
match
---
operator: , [1199,1200]
operator: , [1199,1200]
===
match
---
comparison [62368,62398]
comparison [62320,62350]
===
match
---
trailer [34449,34454]
trailer [34401,34406]
===
match
---
atom_expr [17840,17868]
atom_expr [17840,17868]
===
match
---
suite [67494,67541]
suite [67446,67493]
===
match
---
name: TaskInstance [43280,43292]
name: TaskInstance [43232,43244]
===
match
---
atom_expr [32046,32062]
atom_expr [31998,32014]
===
match
---
name: DagTag [85365,85371]
name: DagTag [85317,85323]
===
match
---
name: __init__ [10155,10163]
name: __init__ [10155,10163]
===
match
---
operator: = [48654,48655]
operator: = [48606,48607]
===
match
---
suite [81063,81129]
suite [81015,81081]
===
match
---
name: is_subdag [78311,78320]
name: is_subdag [78263,78272]
===
match
---
if_stmt [67828,68107]
if_stmt [67780,68059]
===
match
---
comp_op [57119,57125]
comp_op [57071,57077]
===
match
---
suite [26158,26239]
suite [26110,26191]
===
match
---
atom_expr [68599,68611]
atom_expr [68551,68563]
===
match
---
trailer [98405,98407]
trailer [98357,98359]
===
match
---
name: airflow [42032,42039]
name: airflow [41984,41991]
===
match
---
trailer [77784,77786]
trailer [77736,77738]
===
match
---
trailer [14092,14107]
trailer [14092,14107]
===
match
---
trailer [15747,15755]
trailer [15747,15755]
===
match
---
name: safe_dag_id [14842,14853]
name: safe_dag_id [14842,14853]
===
match
---
if_stmt [16953,17198]
if_stmt [16953,17198]
===
match
---
name: end_date [19691,19699]
name: end_date [19691,19699]
===
match
---
expr_stmt [43947,43993]
expr_stmt [43899,43945]
===
match
---
trailer [53066,53073]
trailer [53018,53025]
===
match
---
atom_expr [16779,16788]
atom_expr [16779,16788]
===
match
---
tfpdef [10619,10654]
tfpdef [10619,10654]
===
match
---
name: Union [10493,10498]
name: Union [10493,10498]
===
match
---
param [44692,44696]
param [44644,44648]
===
match
---
and_test [70947,70969]
and_test [70899,70921]
===
match
---
for_stmt [80977,81129]
for_stmt [80929,81081]
===
match
---
name: t [25902,25903]
name: t [25854,25855]
===
match
---
name: extend [58900,58906]
name: extend [58852,58858]
===
match
---
name: filter [51435,51441]
name: filter [51387,51393]
===
match
---
number: 0 [41773,41774]
number: 0 [41725,41726]
===
match
---
name: start_date [59448,59458]
name: start_date [59400,59410]
===
match
---
operator: , [86265,86266]
operator: , [86217,86218]
===
match
---
atom_expr [64516,64541]
atom_expr [64468,64493]
===
match
---
simple_stmt [30029,30057]
simple_stmt [29981,30009]
===
match
---
parameters [37336,37379]
parameters [37288,37331]
===
match
---
operator: , [67731,67732]
operator: , [67683,67684]
===
match
---
operator: , [83939,83940]
operator: , [83891,83892]
===
match
---
if_stmt [48065,48146]
if_stmt [48017,48098]
===
match
---
trailer [87639,87664]
trailer [87591,87616]
===
match
---
not_test [29008,29021]
not_test [28960,28973]
===
match
---
if_stmt [29005,29047]
if_stmt [28957,28999]
===
match
---
name: normalized_schedule_interval [21414,21442]
name: normalized_schedule_interval [21390,21418]
===
match
---
simple_stmt [97038,97053]
simple_stmt [96990,97005]
===
match
---
param [60974,61034]
param [60926,60986]
===
match
---
parameters [17234,17247]
parameters [17234,17247]
===
match
---
simple_stmt [33399,33499]
simple_stmt [33351,33451]
===
match
---
name: dag_by_ids [76550,76560]
name: dag_by_ids [76502,76512]
===
match
---
sync_comp_for [57091,57142]
sync_comp_for [57043,57094]
===
match
---
param [48726,48775]
param [48678,48727]
===
match
---
import_from [1920,1962]
import_from [1920,1962]
===
match
---
name: DateTime [22948,22956]
name: DateTime [22900,22908]
===
match
---
name: operator [53370,53378]
name: operator [53322,53330]
===
match
---
name: self [80245,80249]
name: self [80197,80201]
===
match
---
operator: } [84955,84956]
operator: } [84907,84908]
===
match
---
operator: = [62422,62423]
operator: = [62374,62375]
===
match
---
name: self [22844,22848]
name: self [22796,22800]
===
match
---
operator: = [85854,85855]
operator: = [85806,85807]
===
match
---
name: Text [1438,1442]
name: Text [1438,1442]
===
match
---
funcdef [17944,18035]
funcdef [17944,18035]
===
match
---
name: run_type [77247,77255]
name: run_type [77199,77207]
===
match
---
name: num [19448,19451]
name: num [19448,19451]
===
match
---
if_stmt [3482,3591]
if_stmt [3482,3591]
===
match
---
name: tags [16784,16788]
name: tags [16784,16788]
===
match
---
name: ExternalTaskMarker [54745,54763]
name: ExternalTaskMarker [54697,54715]
===
match
---
atom_expr [68640,68659]
atom_expr [68592,68611]
===
match
---
name: DagStateChangeCallback [11402,11424]
name: DagStateChangeCallback [11402,11424]
===
match
---
arglist [85500,85529]
arglist [85452,85481]
===
match
---
name: args [72052,72056]
name: args [72004,72008]
===
match
---
operator: , [23962,23963]
operator: , [23914,23915]
===
match
---
name: self [31282,31286]
name: self [31234,31238]
===
match
---
name: self [66447,66451]
name: self [66399,66403]
===
match
---
trailer [66898,66908]
trailer [66850,66860]
===
match
---
name: next_run_date [26001,26014]
name: next_run_date [25953,25966]
===
match
---
name: in_ [90063,90066]
name: in_ [90015,90018]
===
match
---
trailer [93452,93482]
trailer [93404,93434]
===
match
---
operator: -> [66639,66641]
operator: -> [66591,66593]
===
match
---
name: tii [55564,55567]
name: tii [55516,55519]
===
match
---
operator: = [57382,57383]
operator: = [57334,57335]
===
match
---
decorated [31646,31744]
decorated [31598,31696]
===
match
---
name: v [60135,60136]
name: v [60087,60088]
===
match
---
name: info [36385,36389]
name: info [36337,36341]
===
match
---
name: pickle_id [86860,86869]
name: pickle_id [86812,86821]
===
match
---
name: dag_model [92127,92136]
name: dag_model [92079,92088]
===
match
---
name: verbose [71678,71685]
name: verbose [71630,71637]
===
match
---
name: all [44401,44404]
name: all [44353,44356]
===
match
---
name: or_ [52877,52880]
name: or_ [52829,52832]
===
match
---
name: donot_pickle [71437,71449]
name: donot_pickle [71389,71401]
===
match
---
operator: { [74060,74061]
operator: { [74012,74013]
===
match
---
funcdef [66988,67098]
funcdef [66940,67050]
===
match
---
if_stmt [56990,57025]
if_stmt [56942,56977]
===
match
---
for_stmt [64750,65057]
for_stmt [64702,65009]
===
match
---
name: user_defined_macros [11864,11883]
name: user_defined_macros [11864,11883]
===
match
---
name: expression [93338,93348]
name: expression [93290,93300]
===
match
---
atom [83689,84513]
atom [83641,84465]
===
match
---
trailer [47882,47889]
trailer [47834,47841]
===
match
---
trailer [88330,88335]
trailer [88282,88287]
===
match
---
simple_stmt [60033,60054]
simple_stmt [59985,60006]
===
match
---
name: orm_dag [76346,76353]
name: orm_dag [76298,76305]
===
match
---
simple_stmt [12170,12218]
simple_stmt [12170,12218]
===
match
---
name: RUNNING [47491,47498]
name: RUNNING [47443,47450]
===
match
---
simple_stmt [12271,12292]
simple_stmt [12271,12292]
===
match
---
operator: } [73818,73819]
operator: } [73770,73771]
===
match
---
param [93685,93690]
param [93637,93642]
===
match
---
expr_stmt [86860,86887]
expr_stmt [86812,86839]
===
match
---
trailer [60103,60109]
trailer [60055,60061]
===
match
---
trailer [34200,34210]
trailer [34152,34162]
===
match
---
trailer [53552,53560]
trailer [53504,53512]
===
match
---
name: setter [30588,30594]
name: setter [30540,30546]
===
match
---
atom_expr [64343,64367]
atom_expr [64295,64319]
===
match
---
name: session [75022,75029]
name: session [74974,74981]
===
match
---
name: task [68183,68187]
name: task [68135,68139]
===
match
---
name: count [82694,82699]
name: count [82646,82651]
===
match
---
arglist [60303,60310]
arglist [60255,60262]
===
match
---
name: x [43910,43911]
name: x [43862,43863]
===
match
---
trailer [12738,12756]
trailer [12738,12756]
===
match
---
name: on_failure_callback [36323,36342]
name: on_failure_callback [36275,36294]
===
match
---
atom_expr [77259,77279]
atom_expr [77211,77231]
===
match
---
name: task [68222,68226]
name: task [68174,68178]
===
match
---
atom_expr [87126,87146]
atom_expr [87078,87098]
===
match
---
simple_stmt [47373,47400]
simple_stmt [47325,47352]
===
match
---
trailer [33323,33340]
trailer [33275,33292]
===
match
---
funcdef [30791,30903]
funcdef [30743,30855]
===
match
---
name: inspect [992,999]
name: inspect [992,999]
===
match
---
name: run [74871,74874]
name: run [74823,74826]
===
match
---
trailer [52883,52889]
trailer [52835,52841]
===
match
---
trailer [44125,44254]
trailer [44077,44206]
===
match
---
atom_expr [78232,78252]
atom_expr [78184,78204]
===
match
---
name: _dag_id [29848,29855]
name: _dag_id [29800,29807]
===
match
---
name: t [62628,62629]
name: t [62580,62581]
===
match
---
param [88172,88189]
param [88124,88141]
===
match
---
name: ti_key [53537,53543]
name: ti_key [53489,53495]
===
match
---
param [66743,66750]
param [66695,66702]
===
match
---
expr_stmt [35404,35447]
expr_stmt [35356,35399]
===
match
---
name: is_fixed_time_schedule [19769,19791]
name: is_fixed_time_schedule [19769,19791]
===
match
---
name: DagRun [38779,38785]
name: DagRun [38731,38737]
===
match
---
atom_expr [37120,37131]
atom_expr [37072,37083]
===
match
---
operator: -> [89689,89691]
operator: -> [89641,89643]
===
match
---
operator: == [39591,39593]
operator: == [39543,39545]
===
match
---
atom_expr [32474,32492]
atom_expr [32426,32444]
===
match
---
param [72153,72195]
param [72105,72147]
===
match
---
argument [56385,56408]
argument [56337,56360]
===
match
---
operator: @ [18201,18202]
operator: @ [18201,18202]
===
match
---
name: __name__ [2898,2906]
name: __name__ [2898,2906]
===
match
---
name: dag_run_state [52311,52324]
name: dag_run_state [52263,52276]
===
match
---
name: cascade [87489,87496]
name: cascade [87441,87448]
===
match
---
string: 'LR' [3067,3071]
string: 'LR' [3067,3071]
===
match
---
trailer [76656,76666]
trailer [76608,76618]
===
match
---
trailer [47914,47920]
trailer [47866,47872]
===
match
---
atom_expr [31947,31974]
atom_expr [31899,31926]
===
match
---
atom [45646,45648]
atom [45598,45600]
===
match
---
trailer [85329,85349]
trailer [85281,85301]
===
match
---
name: get_task [65260,65268]
name: get_task [65212,65220]
===
match
---
operator: , [34585,34586]
operator: , [34537,34538]
===
match
---
trailer [75013,75020]
trailer [74965,74972]
===
match
---
operator: , [75425,75426]
operator: , [75377,75378]
===
match
---
name: self [29760,29764]
name: self [29712,29716]
===
match
---
trailer [68309,68372]
trailer [68261,68324]
===
match
---
trailer [87132,87146]
trailer [87084,87098]
===
match
---
trailer [22474,22483]
trailer [22450,22459]
===
match
---
name: State [53009,53014]
name: State [52961,52966]
===
match
---
for_stmt [79880,79960]
for_stmt [79832,79912]
===
match
---
operator: += [62735,62737]
operator: += [62687,62689]
===
match
---
name: str [72221,72224]
name: str [72173,72176]
===
match
---
atom_expr [17126,17148]
atom_expr [17126,17148]
===
match
---
expr_stmt [38826,38917]
expr_stmt [38778,38869]
===
match
---
name: Optional [11450,11458]
name: Optional [11450,11458]
===
match
---
name: Optional [19493,19501]
name: Optional [19493,19501]
===
match
---
string: """This attribute is deprecated. Please use `airflow.models.DAG.get_concurrency_reached` method.""" [33399,33498]
string: """This attribute is deprecated. Please use `airflow.models.DAG.get_concurrency_reached` method.""" [33351,33450]
===
match
---
operator: , [10759,10760]
operator: , [10759,10760]
===
match
---
atom_expr [16380,16408]
atom_expr [16380,16408]
===
match
---
name: t [62233,62234]
name: t [62185,62186]
===
match
---
name: airflow [2517,2524]
name: airflow [2517,2524]
===
match
---
name: dag [94214,94217]
name: dag [94166,94169]
===
match
---
name: self [66927,66931]
name: self [66879,66883]
===
match
---
name: EdgeInfoType [2789,2801]
name: EdgeInfoType [2789,2801]
===
match
---
operator: = [29585,29586]
operator: = [29537,29538]
===
match
---
operator: , [47498,47499]
operator: , [47450,47451]
===
match
---
atom_expr [79930,79941]
atom_expr [79882,79893]
===
match
---
operator: , [48716,48717]
operator: , [48668,48669]
===
match
---
raise_stmt [68283,68372]
raise_stmt [68235,68324]
===
match
---
name: RUNNING [33269,33276]
name: RUNNING [33221,33228]
===
match
---
name: self [33962,33966]
name: self [33914,33918]
===
match
---
atom_expr [38864,38875]
atom_expr [38816,38827]
===
match
---
trailer [35227,35231]
trailer [35179,35183]
===
match
---
and_test [13118,13150]
and_test [13118,13150]
===
match
---
simple_stmt [76050,76221]
simple_stmt [76002,76173]
===
match
---
name: DagRun [77012,77018]
name: DagRun [76964,76970]
===
match
---
trailer [13612,13621]
trailer [13612,13621]
===
match
---
atom_expr [96077,96127]
atom_expr [96029,96079]
===
match
---
name: description [87251,87262]
name: description [87203,87214]
===
match
---
suite [41827,41896]
suite [41779,41848]
===
match
---
return_stmt [30535,30564]
return_stmt [30487,30516]
===
match
---
param [17304,17309]
param [17304,17309]
===
match
---
operator: = [29245,29246]
operator: = [29197,29198]
===
match
---
name: _task_group [32051,32062]
name: _task_group [32003,32014]
===
match
---
atom_expr [94110,94126]
atom_expr [94062,94078]
===
match
---
simple_stmt [65548,65578]
simple_stmt [65500,65530]
===
match
---
name: result [60113,60119]
name: result [60065,60071]
===
match
---
atom_expr [31151,31166]
atom_expr [31103,31118]
===
match
---
trailer [40736,40742]
trailer [40688,40694]
===
match
---
trailer [85928,85936]
trailer [85880,85888]
===
match
---
if_stmt [46792,46857]
if_stmt [46744,46809]
===
match
---
trailer [64327,64329]
trailer [64279,64281]
===
match
---
operator: = [78448,78449]
operator: = [78400,78401]
===
match
---
tfpdef [89644,89662]
tfpdef [89596,89614]
===
match
---
simple_stmt [41469,41508]
simple_stmt [41421,41460]
===
match
---
simple_stmt [98562,98594]
simple_stmt [98514,98546]
===
match
---
trailer [64886,64905]
trailer [64838,64857]
===
match
---
name: pool [71594,71598]
name: pool [71546,71550]
===
match
---
name: next_run_date [26282,26295]
name: next_run_date [26234,26247]
===
match
---
name: self [30738,30742]
name: self [30690,30694]
===
match
---
name: self [16335,16339]
name: self [16335,16339]
===
match
---
arglist [76128,76158]
arglist [76080,76110]
===
match
---
operator: = [87525,87526]
operator: = [87477,87478]
===
match
---
name: most_recent_dag_run [93701,93720]
name: most_recent_dag_run [93653,93672]
===
match
---
expr_stmt [29843,29863]
expr_stmt [29795,29815]
===
match
---
comparison [68168,68208]
comparison [68120,68160]
===
match
---
name: e [65969,65970]
name: e [65921,65922]
===
match
---
decorator [80554,80568]
decorator [80506,80520]
===
match
---
name: tasks [65244,65249]
name: tasks [65196,65201]
===
match
---
trailer [76127,76159]
trailer [76079,76111]
===
match
---
name: recursion_depth [54009,54024]
name: recursion_depth [53961,53976]
===
match
---
param [10463,10527]
param [10463,10527]
===
match
---
expr_stmt [33123,33140]
expr_stmt [33075,33092]
===
match
---
name: copied [63245,63251]
name: copied [63197,63203]
===
match
---
operator: = [58820,58821]
operator: = [58772,58773]
===
match
---
name: orm_dag [78066,78073]
name: orm_dag [78018,78025]
===
match
---
simple_stmt [25337,25378]
simple_stmt [25289,25330]
===
match
---
operator: = [67523,67524]
operator: = [67475,67476]
===
match
---
simple_stmt [62409,62427]
simple_stmt [62361,62379]
===
match
---
atom_expr [64975,64997]
atom_expr [64927,64949]
===
match
---
string: 'start_date' [13491,13503]
string: 'start_date' [13491,13503]
===
match
---
simple_stmt [71121,71182]
simple_stmt [71073,71134]
===
match
---
simple_stmt [1920,1963]
simple_stmt [1920,1963]
===
match
---
operator: = [12665,12666]
operator: = [12665,12666]
===
match
---
tfpdef [22858,22913]
tfpdef [22810,22865]
===
match
---
comp_op [53591,53597]
comp_op [53543,53549]
===
match
---
trailer [79168,79177]
trailer [79120,79129]
===
match
---
tfpdef [72289,72321]
tfpdef [72241,72273]
===
match
---
trailer [12305,12313]
trailer [12305,12313]
===
match
---
trailer [33199,33287]
trailer [33151,33239]
===
match
---
for_stmt [68853,68904]
for_stmt [68805,68856]
===
match
---
atom_expr [51786,51811]
atom_expr [51738,51763]
===
match
---
trailer [93413,93415]
trailer [93365,93367]
===
match
---
operator: } [59239,59240]
operator: } [59191,59192]
===
match
---
atom_expr [93321,93334]
atom_expr [93273,93286]
===
match
---
atom_expr [12928,12950]
atom_expr [12928,12950]
===
match
---
trailer [53308,53312]
trailer [53260,53264]
===
match
---
simple_stmt [1558,1596]
simple_stmt [1558,1596]
===
match
---
string: 'template_undefined' [84250,84270]
string: 'template_undefined' [84202,84222]
===
match
---
operator: == [17273,17275]
operator: == [17273,17275]
===
match
---
trailer [60540,60545]
trailer [60492,60497]
===
match
---
name: count [37744,37749]
name: count [37696,37701]
===
match
---
operator: == [17529,17531]
operator: == [17529,17531]
===
match
---
suite [97329,98594]
suite [97281,98546]
===
match
---
name: next_run_date [28708,28721]
name: next_run_date [28660,28673]
===
match
---
param [58163,58179]
param [58115,58131]
===
match
---
operator: -> [98220,98222]
operator: -> [98172,98174]
===
match
---
simple_stmt [28708,28763]
simple_stmt [28660,28715]
===
match
---
trailer [23783,23801]
trailer [23735,23753]
===
match
---
fstring_string: > [16912,16913]
fstring_string: > [16912,16913]
===
match
---
atom_expr [11176,11216]
atom_expr [11176,11216]
===
match
---
arglist [17160,17174]
arglist [17160,17174]
===
match
---
trailer [14796,14808]
trailer [14796,14808]
===
match
---
name: cls [98434,98437]
name: cls [98386,98389]
===
match
---
atom_expr [44862,44872]
atom_expr [44814,44824]
===
match
---
simple_stmt [40209,40403]
simple_stmt [40161,40355]
===
match
---
expr_stmt [96511,96524]
expr_stmt [96463,96476]
===
match
---
simple_stmt [76375,76430]
simple_stmt [76327,76382]
===
match
---
raise_stmt [15445,15614]
raise_stmt [15445,15614]
===
match
---
argument [58509,58530]
argument [58461,58482]
===
match
---
name: STATICA_HACK [97075,97087]
name: STATICA_HACK [97027,97039]
===
match
---
name: only_failed [48349,48360]
name: only_failed [48301,48312]
===
match
---
atom_expr [86682,86701]
atom_expr [86634,86653]
===
match
---
name: self [15743,15747]
name: self [15743,15747]
===
match
---
funcdef [30076,30370]
funcdef [30028,30322]
===
match
---
atom_expr [13604,13621]
atom_expr [13604,13621]
===
match
---
name: Optional [10270,10278]
name: Optional [10270,10278]
===
match
---
name: session [74700,74707]
name: session [74652,74659]
===
match
---
suite [31698,31744]
suite [31650,31696]
===
match
---
name: self [51705,51709]
name: self [51657,51661]
===
match
---
param [69216,69240]
param [69168,69192]
===
match
---
trailer [54941,54947]
trailer [54893,54899]
===
match
---
operator: = [10447,10448]
operator: = [10447,10448]
===
match
---
atom_expr [12831,12848]
atom_expr [12831,12848]
===
match
---
operator: , [1124,1125]
operator: , [1124,1125]
===
match
---
name: bool [32809,32813]
name: bool [32761,32765]
===
match
---
operator: = [56837,56838]
operator: = [56789,56790]
===
match
---
if_stmt [20901,21342]
if_stmt [20901,21318]
===
match
---
name: self [30442,30446]
name: self [30394,30398]
===
match
---
name: self [42519,42523]
name: self [42471,42475]
===
match
---
name: session [76072,76079]
name: session [76024,76031]
===
match
---
atom_expr [91884,91908]
atom_expr [91836,91860]
===
match
---
simple_stmt [92655,93027]
simple_stmt [92607,92979]
===
match
---
trailer [11401,11425]
trailer [11401,11425]
===
match
---
name: include_externally_triggered [89509,89537]
name: include_externally_triggered [89461,89489]
===
match
---
and_test [47081,47138]
and_test [47033,47090]
===
match
---
name: end_date [68082,68090]
name: end_date [68034,68042]
===
match
---
name: partial_subset [60936,60950]
name: partial_subset [60888,60902]
===
match
---
name: copy [62097,62101]
name: copy [62049,62053]
===
match
---
operator: , [11470,11471]
operator: , [11470,11471]
===
match
---
simple_stmt [22510,22553]
simple_stmt [22486,22505]
===
match
---
trailer [64732,64737]
trailer [64684,64689]
===
match
---
trailer [82693,82699]
trailer [82645,82651]
===
match
---
trailer [60328,60348]
trailer [60280,60300]
===
match
---
name: self [21568,21572]
name: self [21544,21548]
===
match
---
atom [37983,38046]
atom [37935,37998]
===
match
---
operator: = [71703,71704]
operator: = [71655,71656]
===
match
---
simple_stmt [45548,45622]
simple_stmt [45500,45574]
===
match
---
name: self [25546,25550]
name: self [25498,25502]
===
match
---
atom_expr [85922,85936]
atom_expr [85874,85888]
===
match
---
name: type [16970,16974]
name: type [16970,16974]
===
match
---
funcdef [30922,30995]
funcdef [30874,30947]
===
match
---
tfpdef [10373,10401]
tfpdef [10373,10401]
===
match
---
decorated [31980,32063]
decorated [31932,32015]
===
match
---
name: node [46752,46756]
name: node [46704,46708]
===
match
---
raise_stmt [15156,15328]
raise_stmt [15156,15328]
===
match
---
atom_expr [44701,44719]
atom_expr [44653,44671]
===
match
---
name: task [44845,44849]
name: task [44797,44801]
===
match
---
string: 'params' [12207,12215]
string: 'params' [12207,12215]
===
match
---
trailer [72020,72031]
trailer [71972,71983]
===
match
---
name: t [62368,62369]
name: t [62320,62321]
===
match
---
operator: , [17138,17139]
operator: , [17138,17139]
===
match
---
expr_stmt [79264,79310]
expr_stmt [79216,79262]
===
match
---
name: dag_id [76190,76196]
name: dag_id [76142,76148]
===
match
---
arglist [79930,79958]
arglist [79882,79910]
===
match
---
arglist [75343,75356]
arglist [75295,75308]
===
match
---
atom_expr [43280,43337]
atom_expr [43232,43289]
===
match
---
arith_expr [22290,22321]
arith_expr [22266,22297]
===
match
---
name: context [36746,36753]
name: context [36698,36705]
===
match
---
atom_expr [64043,64058]
atom_expr [63995,64010]
===
match
---
name: ID_LEN [85558,85564]
name: ID_LEN [85510,85516]
===
match
---
name: self [44692,44696]
name: self [44644,44648]
===
match
---
name: dry_run [58924,58931]
name: dry_run [58876,58883]
===
match
---
name: state [37133,37138]
name: state [37085,37090]
===
match
---
atom_expr [64719,64739]
atom_expr [64671,64691]
===
match
---
string: """         Clears a set of task instances associated with the current dag for         a specified date range.          :param task_ids: List of task ids to clear         :type task_ids: List[str]         :param start_date: The minimum execution_date to clear         :type start_date: datetime.datetime or None         :param end_date: The maximum execution_date to clear         :type end_date: datetime.datetime or None         :param only_failed: Only clear failed tasks         :type only_failed: bool         :param only_running: Only clear running tasks.         :type only_running: bool         :param confirm_prompt: Ask for confirmation         :type confirm_prompt: bool         :param include_subdags: Clear tasks in subdags and clear external tasks             indicated by ExternalTaskMarker         :type include_subdags: bool         :param include_parentdag: Clear tasks in the parent dag of the subdag.         :type include_parentdag: bool         :param dag_run_state: state to set DagRun to. If set to False, dagrun state will not             be changed.         :param dry_run: Find the tasks to clear but don't clear them.         :type dry_run: bool         :param session: The sqlalchemy session to use         :type session: sqlalchemy.orm.session.Session         :param get_tis: Return the sqlalchemy query for finding the TaskInstance without clearing the tasks         :type get_tis: bool         :param recursion_depth: The recursion depth of nested calls to DAG.clear().         :type recursion_depth: int         :param max_recursion_depth: The maximum recursion depth allowed. This is determined by the             first encountered ExternalTaskMarker. Default is None indicating no ExternalTaskMarker             has been encountered.         :type max_recursion_depth: int         :param dag_bag: The DagBag used to find the dags         :type dag_bag: airflow.models.dagbag.DagBag         :param visited_external_tis: A set used internally to keep track of the visited TaskInstance when             clearing tasks across multiple DAGs linked by ExternalTaskMarker to avoid redundant work.         :type visited_external_tis: set         :param exclude_task_ids: A set of ``task_id`` that should not be cleared         :type exclude_task_ids: frozenset         """ [48791,51090]
string: """         Clears a set of task instances associated with the current dag for         a specified date range.          :param task_ids: List of task ids to clear         :type task_ids: List[str]         :param start_date: The minimum execution_date to clear         :type start_date: datetime.datetime or None         :param end_date: The maximum execution_date to clear         :type end_date: datetime.datetime or None         :param only_failed: Only clear failed tasks         :type only_failed: bool         :param only_running: Only clear running tasks.         :type only_running: bool         :param confirm_prompt: Ask for confirmation         :type confirm_prompt: bool         :param include_subdags: Clear tasks in subdags and clear external tasks             indicated by ExternalTaskMarker         :type include_subdags: bool         :param include_parentdag: Clear tasks in the parent dag of the subdag.         :type include_parentdag: bool         :param dag_run_state: state to set DagRun to. If set to False, dagrun state will not             be changed.         :param dry_run: Find the tasks to clear but don't clear them.         :type dry_run: bool         :param session: The sqlalchemy session to use         :type session: sqlalchemy.orm.session.Session         :param get_tis: Return the sqlalchemy query for finding the TaskInstance without clearing the tasks         :type get_tis: bool         :param recursion_depth: The recursion depth of nested calls to DAG.clear().         :type recursion_depth: int         :param max_recursion_depth: The maximum recursion depth allowed. This is determined by the             first encountered ExternalTaskMarker. Default is None indicating no ExternalTaskMarker             has been encountered.         :type max_recursion_depth: int         :param dag_bag: The DagBag used to find the dags         :type dag_bag: airflow.models.dagbag.DagBag         :param visited_external_tis: A set used internally to keep track of the visited TaskInstance when             clearing tasks across multiple DAGs linked by ExternalTaskMarker to avoid redundant work.         :type visited_external_tis: set         :param exclude_task_ids: A set of ``task_id`` that should not be cleared         :type exclude_task_ids: frozenset         """ [48743,51042]
===
match
---
name: dag [81905,81908]
name: dag [81857,81860]
===
match
---
atom_expr [58002,58042]
atom_expr [57954,57994]
===
match
---
trailer [64320,64327]
trailer [64272,64279]
===
match
---
atom_expr [22037,22087]
atom_expr [22013,22063]
===
match
---
funcdef [32924,33341]
funcdef [32876,33293]
===
match
---
name: AirflowException [47292,47308]
name: AirflowException [47244,47260]
===
match
---
testlist_comp [91025,91056]
testlist_comp [90977,91008]
===
match
---
atom_expr [14240,14296]
atom_expr [14240,14296]
===
match
---
expr_stmt [88048,88147]
expr_stmt [88000,88099]
===
match
---
trailer [37844,37852]
trailer [37796,37804]
===
match
---
operator: , [84580,84581]
operator: , [84532,84533]
===
match
---
name: active_dag_ids [81040,81054]
name: active_dag_ids [80992,81006]
===
match
---
string: 'core' [86099,86105]
string: 'core' [86051,86057]
===
match
---
name: normalized_schedule_interval [34682,34710]
name: normalized_schedule_interval [34634,34662]
===
match
---
if_stmt [26638,26748]
if_stmt [26590,26700]
===
match
---
name: max_active_tasks [30603,30619]
name: max_active_tasks [30555,30571]
===
match
---
funcdef [98187,98489]
funcdef [98139,98441]
===
match
---
name: graph_unsorted [45837,45851]
name: graph_unsorted [45789,45803]
===
match
---
operator: = [81090,81091]
operator: = [81042,81043]
===
match
---
name: DagModel [66196,66204]
name: DagModel [66148,66156]
===
match
---
name: DAG [98003,98006]
name: DAG [97955,97958]
===
match
---
name: orm_dag [78576,78583]
name: orm_dag [78528,78535]
===
match
---
trailer [39682,39697]
trailer [39634,39649]
===
match
---
fstring_end: ' [15599,15600]
fstring_end: ' [15599,15600]
===
match
---
trailer [26396,26415]
trailer [26348,26367]
===
match
---
argument [74355,74373]
argument [74307,74325]
===
match
---
name: cls [91412,91415]
name: cls [91364,91367]
===
match
---
name: session [80988,80995]
name: session [80940,80947]
===
match
---
name: self [12170,12174]
name: self [12170,12174]
===
match
---
operator: , [69315,69316]
operator: , [69267,69268]
===
match
---
suite [54030,54277]
suite [53982,54229]
===
match
---
trailer [74891,74908]
trailer [74843,74860]
===
match
---
atom_expr [67733,67748]
atom_expr [67685,67700]
===
match
---
trailer [42773,42808]
trailer [42725,42760]
===
match
---
operator: = [97088,97089]
operator: = [97040,97041]
===
match
---
name: dag_bag [56772,56779]
name: dag_bag [56724,56731]
===
match
---
operator: = [88573,88574]
operator: = [88525,88526]
===
match
---
suite [19798,20267]
suite [19798,20267]
===
match
---
operator: = [76548,76549]
operator: = [76500,76501]
===
match
---
atom_expr [77528,77541]
atom_expr [77480,77493]
===
match
---
operator: { [41591,41592]
operator: { [41543,41544]
===
match
---
dotted_name [1702,1720]
dotted_name [1702,1720]
===
match
---
dotted_name [31173,31189]
dotted_name [31125,31141]
===
match
---
trailer [79862,79868]
trailer [79814,79820]
===
match
---
operator: = [16409,16410]
operator: = [16409,16410]
===
match
---
tfpdef [11157,11173]
tfpdef [11157,11173]
===
match
---
trailer [93243,93250]
trailer [93195,93202]
===
match
---
arglist [79456,79487]
arglist [79408,79439]
===
match
---
name: utils [59308,59313]
name: utils [59260,59265]
===
match
---
name: dag_tag_orm [79533,79544]
name: dag_tag_orm [79485,79496]
===
match
---
operator: = [98365,98366]
operator: = [98317,98318]
===
match
---
string: """         Get information about the next DagRun of this dag after ``date_last_automated_dagrun`` -- the         execution date, and the earliest it could be scheduled          :param date_last_automated_dagrun: The max(execution_date) of existing             "automated" DagRuns for this dag (scheduled or backfill, but not             manual)         """ [22997,23354]
string: """         Get information about the next DagRun of this dag after ``date_last_automated_dagrun`` -- the         execution date, and the earliest it could be scheduled          :param date_last_automated_dagrun: The max(execution_date) of existing             "automated" DagRuns for this dag (scheduled or backfill, but not             manual)         """ [22949,23306]
===
match
---
trailer [38846,38917]
trailer [38798,38869]
===
match
---
argument [51830,51852]
argument [51782,51804]
===
match
---
atom_expr [28549,28563]
atom_expr [28501,28515]
===
match
---
name: self [16961,16965]
name: self [16961,16965]
===
match
---
trailer [77043,77058]
trailer [76995,77010]
===
match
---
trailer [22653,22663]
trailer [22605,22615]
===
match
---
trailer [66557,66559]
trailer [66509,66511]
===
match
---
trailer [76079,76085]
trailer [76031,76037]
===
match
---
expr_stmt [68622,68659]
expr_stmt [68574,68611]
===
match
---
testlist_comp [65220,65249]
testlist_comp [65172,65201]
===
match
---
trailer [63225,63232]
trailer [63177,63184]
===
match
---
atom_expr [64370,64434]
atom_expr [64322,64386]
===
match
---
operator: = [34609,34610]
operator: = [34561,34562]
===
match
---
name: min [26041,26044]
name: min [25993,25996]
===
match
---
funcdef [38118,39054]
funcdef [38070,39006]
===
match
---
trailer [57516,57537]
trailer [57468,57489]
===
match
---
name: isinstance [13793,13803]
name: isinstance [13793,13803]
===
match
---
param [80621,80636]
param [80573,80588]
===
match
---
atom_expr [14084,14117]
atom_expr [14084,14117]
===
match
---
param [48540,48554]
param [48492,48506]
===
match
---
argument [71699,71708]
argument [71651,71660]
===
match
---
expr_stmt [14987,15029]
expr_stmt [14987,15029]
===
match
---
string: "or there may be a cyclic dependency." [54641,54679]
string: "or there may be a cyclic dependency." [54593,54631]
===
match
---
fstring_expr [47348,47361]
fstring_expr [47300,47313]
===
match
---
atom_expr [33180,33190]
atom_expr [33132,33142]
===
match
---
trailer [40029,40036]
trailer [39981,39988]
===
match
---
name: task [55065,55069]
name: task [55017,55021]
===
match
---
trailer [10229,10234]
trailer [10229,10234]
===
match
---
fstring_start: fr" [55698,55701]
fstring_start: fr" [55650,55653]
===
match
---
operator: , [16114,16115]
operator: , [16114,16115]
===
match
---
simple_stmt [17629,17658]
simple_stmt [17629,17658]
===
match
---
trailer [60082,60087]
trailer [60034,60039]
===
match
---
operator: , [19254,19255]
operator: , [19254,19255]
===
match
---
funcdef [36925,37287]
funcdef [36877,37239]
===
match
---
arglist [90648,90662]
arglist [90600,90614]
===
match
---
name: states [83150,83156]
name: states [83102,83108]
===
match
---
trailer [71220,71241]
trailer [71172,71193]
===
match
---
decorator [34025,34042]
decorator [33977,33994]
===
match
---
suite [34102,34295]
suite [34054,34247]
===
match
---
name: str [91442,91445]
name: str [91394,91397]
===
match
---
trailer [37931,37938]
trailer [37883,37890]
===
match
---
suite [40998,41096]
suite [40950,41048]
===
match
---
argument [52162,52191]
argument [52114,52143]
===
match
---
expr_stmt [20066,20097]
expr_stmt [20066,20097]
===
match
---
name: include_externally_triggered [29624,29652]
name: include_externally_triggered [29576,29604]
===
match
---
name: cls [98569,98572]
name: cls [98521,98524]
===
match
---
operator: , [11147,11148]
operator: , [11147,11148]
===
match
---
name: folder [32351,32357]
name: folder [32303,32309]
===
match
---
name: task [68077,68081]
name: task [68029,68033]
===
match
---
import_from [2008,2054]
import_from [2008,2054]
===
match
---
simple_stmt [9881,10088]
simple_stmt [9881,10088]
===
match
---
atom_expr [43484,43512]
atom_expr [43436,43464]
===
match
---
trailer [12193,12206]
trailer [12193,12206]
===
match
---
name: start_date [14048,14058]
name: start_date [14048,14058]
===
match
---
operator: = [71677,71678]
operator: = [71629,71630]
===
match
---
name: SubDagOperator [45414,45428]
name: SubDagOperator [45366,45380]
===
match
---
param [88166,88171]
param [88118,88123]
===
match
---
name: timedelta [2939,2948]
name: timedelta [2939,2948]
===
match
---
param [47541,47579]
param [47493,47531]
===
match
---
string: "This method is deprecated and will be removed in a future version. Please use bulk_write_to_db" [75141,75237]
string: "This method is deprecated and will be removed in a future version. Please use bulk_write_to_db" [75093,75189]
===
match
---
arglist [72052,72062]
arglist [72004,72014]
===
match
---
name: self [65239,65243]
name: self [65191,65195]
===
match
---
simple_stmt [16304,16372]
simple_stmt [16304,16372]
===
match
---
name: DagModel [76500,76508]
name: DagModel [76452,76460]
===
match
---
parameters [59919,59931]
parameters [59871,59883]
===
match
---
name: get_active_runs [36929,36944]
name: get_active_runs [36881,36896]
===
match
---
name: num_active_runs [78983,78998]
name: num_active_runs [78935,78950]
===
match
---
suite [31931,31975]
suite [31883,31927]
===
match
---
name: property [29870,29878]
name: property [29822,29830]
===
match
---
name: logging [824,831]
name: logging [824,831]
===
match
---
atom_expr [78626,78651]
atom_expr [78578,78603]
===
match
---
operator: { [32722,32723]
operator: { [32674,32675]
===
match
---
operator: == [38899,38901]
operator: == [38851,38853]
===
match
---
name: format [57679,57685]
name: format [57631,57637]
===
match
---
name: self [41178,41182]
name: self [41130,41134]
===
match
---
decorated [32068,32328]
decorated [32020,32280]
===
match
---
suite [30961,30995]
suite [30913,30947]
===
match
---
atom_expr [14811,14828]
atom_expr [14811,14828]
===
match
---
simple_stmt [87818,87865]
simple_stmt [87770,87817]
===
match
---
name: state [43682,43687]
name: state [43634,43639]
===
match
---
name: self [74362,74366]
name: self [74314,74318]
===
match
---
name: query [48090,48095]
name: query [48042,48047]
===
match
---
operator: = [89391,89392]
operator: = [89343,89344]
===
match
---
simple_stmt [41955,42000]
simple_stmt [41907,41952]
===
match
---
simple_stmt [24745,24757]
simple_stmt [24697,24709]
===
match
---
trailer [72353,72359]
trailer [72305,72311]
===
match
---
name: default_args [10724,10736]
name: default_args [10724,10736]
===
match
---
string: 'end_date' [13711,13721]
string: 'end_date' [13711,13721]
===
match
---
operator: = [72516,72517]
operator: = [72468,72469]
===
match
---
name: mark_success [71380,71392]
name: mark_success [71332,71344]
===
match
---
name: DuplicateTaskIdFound [68289,68309]
name: DuplicateTaskIdFound [68241,68261]
===
match
---
operator: , [17239,17240]
operator: , [17239,17240]
===
match
---
name: expression [93285,93295]
name: expression [93237,93247]
===
match
---
name: default [31632,31639]
name: default [31584,31591]
===
match
---
operator: , [82124,82125]
operator: , [82076,82077]
===
match
---
suite [36784,36920]
suite [36736,36872]
===
match
---
trailer [17125,17197]
trailer [17125,17197]
===
match
---
funcdef [97964,98165]
funcdef [97916,98117]
===
match
---
trailer [94731,94743]
trailer [94683,94695]
===
match
---
name: full_filepath [32195,32208]
name: full_filepath [32147,32160]
===
match
---
trailer [84961,84985]
trailer [84913,84937]
===
match
---
trailer [62739,62753]
trailer [62691,62705]
===
match
---
atom_expr [87411,87427]
atom_expr [87363,87379]
===
match
---
trailer [58378,58386]
trailer [58330,58338]
===
match
---
trailer [14946,14961]
trailer [14946,14961]
===
match
---
atom_expr [95804,95826]
atom_expr [95756,95778]
===
match
---
name: self [60140,60144]
name: self [60092,60096]
===
match
---
decorated [18201,19375]
decorated [18201,19375]
===
match
---
name: runs [37200,37204]
name: runs [37152,37156]
===
match
---
expr_stmt [65772,65800]
expr_stmt [65724,65752]
===
match
---
name: query [47899,47904]
name: query [47851,47856]
===
match
---
trailer [54686,54818]
trailer [54638,54770]
===
match
---
atom_expr [64244,64280]
atom_expr [64196,64232]
===
match
---
name: dag [76592,76595]
name: dag [76544,76547]
===
match
---
annassign [15109,15129]
annassign [15109,15129]
===
match
---
name: TI [52997,52999]
name: TI [52949,52951]
===
match
---
operator: , [66900,66901]
operator: , [66852,66853]
===
match
---
operator: , [41650,41651]
operator: , [41602,41603]
===
match
---
name: airflow [11786,11793]
name: airflow [11786,11793]
===
match
---
name: name [31288,31292]
name: name [31240,31244]
===
match
---
name: not_none_states [83112,83127]
name: not_none_states [83064,83079]
===
match
---
atom_expr [93608,93636]
atom_expr [93560,93588]
===
match
---
argument [88135,88146]
argument [88087,88098]
===
match
---
param [72445,72476]
param [72397,72428]
===
match
---
trailer [12174,12181]
trailer [12174,12181]
===
match
---
trailer [25903,25914]
trailer [25855,25866]
===
match
---
name: old_dag [98246,98253]
name: old_dag [98198,98205]
===
match
---
string: """         Returns a list of dag run execution dates currently running          :return: List of execution dates         """ [36960,37085]
string: """         Returns a list of dag run execution dates currently running          :return: List of execution dates         """ [36912,37037]
===
match
---
name: convert_to_utc [14394,14408]
name: convert_to_utc [14394,14408]
===
match
---
atom_expr [55619,55861]
atom_expr [55571,55813]
===
match
---
operator: = [16469,16470]
operator: = [16469,16470]
===
match
---
simple_stmt [1218,1234]
simple_stmt [1218,1234]
===
match
---
trailer [95287,95300]
trailer [95239,95252]
===
match
---
atom_expr [51431,51459]
atom_expr [51383,51411]
===
match
---
operator: , [84020,84021]
operator: , [83972,83973]
===
match
---
atom_expr [79449,79488]
atom_expr [79401,79440]
===
match
---
operator: = [18867,18868]
operator: = [18867,18868]
===
match
---
atom_expr [76181,76209]
atom_expr [76133,76161]
===
match
---
operator: = [16333,16334]
operator: = [16333,16334]
===
match
---
operator: = [14684,14685]
operator: = [14684,14685]
===
match
---
name: orm_dag [78467,78474]
name: orm_dag [78419,78426]
===
match
---
name: default_args [14211,14223]
name: default_args [14211,14223]
===
match
---
trailer [93443,93452]
trailer [93395,93404]
===
match
---
fstring [15553,15600]
fstring [15553,15600]
===
match
---
suite [42949,43114]
suite [42901,43066]
===
match
---
trailer [47308,47363]
trailer [47260,47315]
===
match
---
trailer [78601,78613]
trailer [78553,78565]
===
match
---
name: self [30092,30096]
name: self [30044,30048]
===
match
---
name: getint [88650,88656]
name: getint [88602,88608]
===
match
---
if_stmt [53109,56981]
if_stmt [53061,56933]
===
match
---
simple_stmt [25283,25325]
simple_stmt [25235,25277]
===
match
---
atom_expr [77012,77025]
atom_expr [76964,76977]
===
match
---
argument [74539,74548]
argument [74491,74500]
===
match
---
name: cron [22030,22034]
name: cron [22006,22010]
===
match
---
name: c [17527,17528]
name: c [17527,17528]
===
match
---
trailer [30858,30895]
trailer [30810,30847]
===
match
---
if_stmt [65499,65578]
if_stmt [65451,65530]
===
match
---
tfpdef [11519,11549]
tfpdef [11519,11549]
===
match
---
operator: = [11096,11097]
operator: = [11096,11097]
===
match
---
name: node [47117,47121]
name: node [47069,47073]
===
match
---
trailer [76180,76210]
trailer [76132,76162]
===
match
---
tfpdef [72339,72359]
tfpdef [72291,72311]
===
match
---
trailer [13042,13061]
trailer [13042,13061]
===
match
---
decorated [30062,30370]
decorated [30014,30322]
===
match
---
suite [97179,97310]
suite [97131,97262]
===
match
---
name: classmethod [75364,75375]
name: classmethod [75316,75327]
===
match
---
name: self [26996,27000]
name: self [26948,26952]
===
match
---
name: tasks [28243,28248]
name: tasks [28195,28200]
===
match
---
name: default_args [14180,14192]
name: default_args [14180,14192]
===
match
---
expr_stmt [25782,25802]
expr_stmt [25734,25754]
===
match
---
string: 'is_picklable' [65687,65701]
string: 'is_picklable' [65639,65653]
===
match
---
name: pickle [66110,66116]
name: pickle [66062,66068]
===
match
---
name: parser [71951,71957]
name: parser [71903,71909]
===
match
---
name: isinstance [25414,25424]
name: isinstance [25366,25376]
===
match
---
name: task_id [63613,63620]
name: task_id [63565,63572]
===
match
---
expr_stmt [13164,13197]
expr_stmt [13164,13197]
===
match
---
name: DagRunType [73844,73854]
name: DagRunType [73796,73806]
===
match
---
atom_expr [44199,44227]
atom_expr [44151,44179]
===
match
---
operator: , [82772,82773]
operator: , [82724,82725]
===
match
---
if_stmt [26500,26849]
if_stmt [26452,26801]
===
match
---
decorated [90576,90664]
decorated [90528,90616]
===
match
---
simple_stmt [43579,43637]
simple_stmt [43531,43589]
===
match
---
name: Stats [36882,36887]
name: Stats [36834,36839]
===
match
---
name: dag_ids [47856,47863]
name: dag_ids [47808,47815]
===
match
---
name: self [34237,34241]
name: self [34189,34193]
===
match
---
name: dag_run_state [58807,58820]
name: dag_run_state [58759,58772]
===
match
---
atom_expr [13473,13511]
atom_expr [13473,13511]
===
match
---
name: dag_sig [95280,95287]
name: dag_sig [95232,95239]
===
match
---
atom_expr [3432,3477]
atom_expr [3432,3477]
===
match
---
operator: , [69239,69240]
operator: , [69191,69192]
===
match
---
trailer [31247,31258]
trailer [31199,31210]
===
match
---
expr_stmt [14837,14886]
expr_stmt [14837,14886]
===
match
---
atom_expr [78084,78106]
atom_expr [78036,78058]
===
match
---
suite [46923,47241]
suite [46875,47193]
===
match
---
comparison [43728,43755]
comparison [43680,43707]
===
match
---
name: run_id [73880,73886]
name: run_id [73832,73838]
===
match
---
name: new_perm_mapping [18635,18651]
name: new_perm_mapping [18635,18651]
===
match
---
operator: , [75933,75934]
operator: , [75885,75886]
===
match
---
parameters [80620,80650]
parameters [80572,80602]
===
match
---
trailer [44404,44406]
trailer [44356,44358]
===
match
---
name: len [57384,57387]
name: len [57336,57339]
===
match
---
operator: = [12972,12973]
operator: = [12972,12973]
===
match
---
simple_stmt [14660,14705]
simple_stmt [14660,14705]
===
match
---
atom_expr [79297,79309]
atom_expr [79249,79261]
===
match
---
name: children [63410,63418]
name: children [63362,63370]
===
match
---
trailer [74738,74740]
trailer [74690,74692]
===
match
---
name: start_date [26663,26673]
name: start_date [26615,26625]
===
match
---
trailer [83678,83683]
trailer [83630,83635]
===
match
---
simple_stmt [43123,43349]
simple_stmt [43075,43301]
===
match
---
comparison [15340,15374]
comparison [15340,15374]
===
match
---
name: start_date [67670,67680]
name: start_date [67622,67632]
===
match
---
expr_stmt [95893,95952]
expr_stmt [95845,95904]
===
match
---
trailer [59313,59321]
trailer [59265,59273]
===
match
---
name: date_last_automated_dagrun [24844,24870]
name: date_last_automated_dagrun [24796,24822]
===
match
---
fstring_end: " [65631,65632]
fstring_end: " [65583,65584]
===
match
---
trailer [41435,41455]
trailer [41387,41407]
===
match
---
atom_expr [78790,78808]
atom_expr [78742,78760]
===
match
---
expr_stmt [25882,25951]
expr_stmt [25834,25903]
===
match
---
name: dag [65035,65038]
name: dag [64987,64990]
===
match
---
name: dag [79347,79350]
name: dag [79299,79302]
===
match
---
simple_stmt [51922,52657]
simple_stmt [51874,52609]
===
match
---
simple_stmt [1697,1781]
simple_stmt [1697,1781]
===
match
---
simple_stmt [58476,58880]
simple_stmt [58428,58832]
===
match
---
name: len [58977,58980]
name: len [58929,58932]
===
match
---
name: airflow [70890,70897]
name: airflow [70842,70849]
===
match
---
atom_expr [22630,22663]
atom_expr [22582,22615]
===
match
---
trailer [26191,26210]
trailer [26143,26162]
===
match
---
operator: = [63774,63775]
operator: = [63726,63727]
===
match
---
simple_stmt [78303,78329]
simple_stmt [78255,78281]
===
match
---
atom_expr [67329,67389]
atom_expr [67281,67341]
===
match
---
operator: == [40910,40912]
operator: == [40862,40864]
===
match
---
simple_stmt [26376,26431]
simple_stmt [26328,26383]
===
match
---
name: func [72047,72051]
name: func [71999,72003]
===
match
---
atom_expr [16335,16359]
atom_expr [16335,16359]
===
match
---
suite [92102,92155]
suite [92054,92107]
===
match
---
name: dag_id [33967,33973]
name: dag_id [33919,33925]
===
match
---
trailer [89171,89173]
trailer [89123,89125]
===
match
---
suite [59120,59342]
suite [59072,59294]
===
match
---
trailer [88837,88865]
trailer [88789,88817]
===
match
---
argument [88226,88234]
argument [88178,88186]
===
match
---
expr_stmt [17387,17417]
expr_stmt [17387,17417]
===
match
---
trailer [17983,18008]
trailer [17983,18008]
===
match
---
param [58188,58202]
param [58140,58154]
===
match
---
atom_expr [59153,59159]
atom_expr [59105,59111]
===
match
---
name: graph_sorted [47164,47176]
name: graph_sorted [47116,47128]
===
match
---
name: tis [51555,51558]
name: tis [51507,51510]
===
match
---
trailer [19720,19749]
trailer [19720,19749]
===
match
---
if_stmt [27380,27446]
if_stmt [27332,27398]
===
match
---
operator: = [63373,63374]
operator: = [63325,63326]
===
match
---
number: 1 [97123,97124]
number: 1 [97075,97076]
===
match
---
decorated [33346,33745]
decorated [33298,33697]
===
match
---
name: following_schedule [25301,25319]
name: following_schedule [25253,25271]
===
match
---
param [69197,69207]
param [69149,69159]
===
match
---
operator: , [93415,93416]
operator: , [93367,93368]
===
match
---
operator: ** [93606,93608]
operator: ** [93558,93560]
===
match
---
name: active_runs_of_dag [93751,93769]
name: active_runs_of_dag [93703,93721]
===
match
---
atom_expr [47106,47138]
atom_expr [47058,47090]
===
match
---
atom_expr [42353,42377]
atom_expr [42305,42329]
===
match
---
suite [12440,12726]
suite [12440,12726]
===
match
---
name: provide_session [81178,81193]
name: provide_session [81130,81145]
===
match
---
param [93691,93700]
param [93643,93652]
===
match
---
trailer [10512,10517]
trailer [10512,10517]
===
match
---
name: level [66778,66783]
name: level [66730,66735]
===
match
---
argument [91209,91222]
argument [91161,91174]
===
match
---
trailer [78502,78509]
trailer [78454,78461]
===
match
---
simple_stmt [78748,78841]
simple_stmt [78700,78793]
===
match
---
simple_stmt [78066,78123]
simple_stmt [78018,78075]
===
match
---
atom_expr [94715,94725]
atom_expr [94667,94677]
===
match
---
name: self [40418,40422]
name: self [40370,40374]
===
match
---
name: TI [51099,51101]
name: TI [51051,51053]
===
match
---
comparison [38970,38998]
comparison [38922,38950]
===
match
---
trailer [90066,90075]
trailer [90018,90027]
===
match
---
name: __doc__ [96278,96285]
name: __doc__ [96230,96237]
===
match
---
operator: , [60284,60285]
operator: , [60236,60237]
===
match
---
operator: = [51429,51430]
operator: = [51381,51382]
===
match
---
string: """This method is deprecated in favor of partial_subset""" [60617,60675]
string: """This method is deprecated in favor of partial_subset""" [60569,60627]
===
match
---
trailer [43005,43009]
trailer [42957,42961]
===
match
---
name: on_failure_callback [15832,15851]
name: on_failure_callback [15832,15851]
===
match
---
simple_stmt [74918,74929]
simple_stmt [74870,74881]
===
match
---
argument [29328,29385]
argument [29280,29337]
===
match
---
trailer [16832,16844]
trailer [16832,16844]
===
match
---
name: start_date [13180,13190]
name: start_date [13180,13190]
===
match
---
atom_expr [72014,72033]
atom_expr [71966,71985]
===
match
---
name: other [16975,16980]
name: other [16975,16980]
===
match
---
atom [62921,63056]
atom [62873,63008]
===
match
---
simple_stmt [15091,15130]
simple_stmt [15091,15130]
===
match
---
atom_expr [10916,10962]
atom_expr [10916,10962]
===
match
---
trailer [65072,65083]
trailer [65024,65035]
===
match
---
param [89233,89237]
param [89185,89189]
===
match
---
simple_stmt [23876,23926]
simple_stmt [23828,23878]
===
match
---
operator: = [13602,13603]
operator: = [13602,13603]
===
match
---
atom_expr [24995,25007]
atom_expr [24947,24959]
===
match
---
simple_stmt [22997,23355]
simple_stmt [22949,23307]
===
match
---
name: task_ids [53035,53043]
name: task_ids [52987,52995]
===
match
---
atom [83130,83166]
atom [83082,83118]
===
match
---
name: is_active [81707,81716]
name: is_active [81659,81668]
===
match
---
name: vars [83654,83658]
name: vars [83606,83610]
===
match
---
trailer [77534,77541]
trailer [77486,77493]
===
match
---
name: Session [92637,92644]
name: Session [92589,92596]
===
match
---
not_test [22175,22208]
not_test [22151,22184]
===
match
---
operator: == [38861,38863]
operator: == [38813,38815]
===
match
---
name: upstream_list [62740,62753]
name: upstream_list [62692,62705]
===
match
---
atom_expr [31921,31930]
atom_expr [31873,31882]
===
match
---
name: dag [65073,65076]
name: dag [65025,65028]
===
match
---
name: DagCode [1955,1962]
name: DagCode [1955,1962]
===
match
---
name: self [41483,41487]
name: self [41435,41439]
===
match
---
tfpdef [11566,11605]
tfpdef [11566,11605]
===
match
---
name: t [66966,66967]
name: t [66918,66919]
===
match
---
name: start_date [71301,71311]
name: start_date [71253,71263]
===
match
---
trailer [63220,63225]
trailer [63172,63177]
===
match
---
simple_stmt [68622,68660]
simple_stmt [68574,68612]
===
match
---
name: self [17235,17239]
name: self [17235,17239]
===
match
---
suite [65102,65134]
suite [65054,65086]
===
match
---
name: dag [78161,78164]
name: dag [78113,78116]
===
match
---
name: state [83131,83136]
name: state [83083,83088]
===
match
---
name: join [57512,57516]
name: join [57464,57468]
===
match
---
name: self [67878,67882]
name: self [67830,67834]
===
match
---
argument [28216,28248]
argument [28168,28200]
===
match
---
suite [65527,65578]
suite [65479,65530]
===
match
---
comparison [76592,76631]
comparison [76544,76583]
===
match
---
trailer [53968,53973]
trailer [53920,53925]
===
match
---
funcdef [33360,33745]
funcdef [33312,33697]
===
match
---
suite [67849,67892]
suite [67801,67844]
===
match
---
operator: , [31781,31782]
operator: , [31733,31734]
===
match
---
simple_stmt [34343,34433]
simple_stmt [34295,34385]
===
match
---
atom_expr [93285,93303]
atom_expr [93237,93255]
===
match
---
trailer [53014,53022]
trailer [52966,52974]
===
match
---
parameters [66996,67002]
parameters [66948,66954]
===
match
---
trailer [68137,68145]
trailer [68089,68097]
===
match
---
operator: , [11362,11363]
operator: , [11362,11363]
===
match
---
trailer [20163,20170]
trailer [20163,20170]
===
match
---
param [48608,48626]
param [48560,48578]
===
match
---
name: previous_schedule [25551,25568]
name: previous_schedule [25503,25520]
===
match
---
param [30005,30010]
param [29957,29962]
===
match
---
string: """This attribute is deprecated. Please use `airflow.models.DAG.get_is_paused` method.""" [34343,34432]
string: """This attribute is deprecated. Please use `airflow.models.DAG.get_is_paused` method.""" [34295,34384]
===
match
---
atom_expr [63909,63932]
atom_expr [63861,63884]
===
match
---
trailer [22638,22653]
trailer [22590,22605]
===
match
---
param [44928,44933]
param [44880,44885]
===
match
---
dotted_name [70988,71020]
dotted_name [70940,70972]
===
match
---
operator: @ [31646,31647]
operator: @ [31598,31599]
===
match
---
trailer [97102,97104]
trailer [97054,97056]
===
match
---
trailer [77335,77350]
trailer [77287,77302]
===
match
---
name: get_last_dagrun [3149,3164]
name: get_last_dagrun [3149,3164]
===
match
---
trailer [44326,44332]
trailer [44278,44284]
===
match
---
trailer [83427,83434]
trailer [83379,83386]
===
match
---
trailer [16491,16507]
trailer [16491,16507]
===
match
---
simple_stmt [88621,88693]
simple_stmt [88573,88645]
===
match
---
operator: = [67710,67711]
operator: = [67662,67663]
===
match
---
decorated [58095,59898]
decorated [58047,59850]
===
match
---
sync_comp_for [63009,63046]
sync_comp_for [62961,62998]
===
match
---
name: task [67694,67698]
name: task [67646,67650]
===
match
---
name: conf [90521,90525]
name: conf [90473,90477]
===
match
---
operator: = [72407,72408]
operator: = [72359,72360]
===
match
---
name: query [48154,48159]
name: query [48106,48111]
===
match
---
trailer [65048,65053]
trailer [65000,65005]
===
match
---
operator: @ [98494,98495]
operator: @ [98446,98447]
===
match
---
number: 1 [36507,36508]
number: 1 [36459,36460]
===
match
---
name: self [26080,26084]
name: self [26032,26036]
===
match
---
trailer [13803,13839]
trailer [13803,13839]
===
match
---
operator: , [89382,89383]
operator: , [89334,89335]
===
match
---
operator: = [58173,58174]
operator: = [58125,58126]
===
match
---
trailer [17844,17868]
trailer [17844,17868]
===
match
---
argument [59153,59176]
argument [59105,59128]
===
match
---
operator: , [56408,56409]
operator: , [56360,56361]
===
match
---
trailer [88656,88692]
trailer [88608,88644]
===
match
---
name: last_pickled [86507,86519]
name: last_pickled [86459,86471]
===
match
---
operator: , [48553,48554]
operator: , [48505,48506]
===
match
---
name: task [66737,66741]
name: task [66689,66693]
===
match
---
expr_stmt [98340,98407]
expr_stmt [98292,98359]
===
match
---
atom_expr [16090,16104]
atom_expr [16090,16104]
===
match
---
name: filter [83033,83039]
name: filter [82985,82991]
===
match
---
name: provide_session [32904,32919]
name: provide_session [32856,32871]
===
match
---
name: timedelta [10997,11006]
name: timedelta [10997,11006]
===
match
---
name: template_undefined [14665,14683]
name: template_undefined [14665,14683]
===
match
---
expr_stmt [54234,54276]
expr_stmt [54186,54228]
===
match
---
trailer [66497,66510]
trailer [66449,66462]
===
match
---
simple_stmt [88906,88937]
simple_stmt [88858,88889]
===
match
---
argument [71523,71580]
argument [71475,71532]
===
match
---
comparison [17126,17175]
comparison [17126,17175]
===
match
---
suite [66938,66969]
suite [66890,66921]
===
match
---
trailer [51785,51812]
trailer [51737,51764]
===
match
---
argument [56817,56858]
argument [56769,56810]
===
match
---
suite [88200,88873]
suite [88152,88825]
===
match
---
name: utcnow [43558,43564]
name: utcnow [43510,43516]
===
match
---
name: min [27348,27351]
name: min [27300,27303]
===
match
---
name: next_dagrun_info [22818,22834]
name: next_dagrun_info [22770,22786]
===
match
---
atom_expr [83193,83325]
atom_expr [83145,83277]
===
match
---
trailer [96734,96744]
trailer [96686,96696]
===
match
---
argument [42071,42090]
argument [42023,42042]
===
match
---
simple_stmt [85644,85661]
simple_stmt [85596,85613]
===
match
---
name: copy [53884,53888]
name: copy [53836,53840]
===
match
---
if_stmt [82792,82901]
if_stmt [82744,82853]
===
match
---
operator: , [72413,72414]
operator: , [72365,72366]
===
match
---
trailer [43071,43079]
trailer [43023,43031]
===
match
---
suite [92012,92421]
suite [91964,92373]
===
match
---
number: 2 [75294,75295]
number: 2 [75246,75247]
===
match
---
name: Dict [10702,10706]
name: Dict [10702,10706]
===
match
---
name: query [93574,93579]
name: query [93526,93531]
===
match
---
name: previous_schedule [21550,21567]
name: previous_schedule [21526,21543]
===
match
---
name: DagRun [39000,39006]
name: DagRun [38952,38958]
===
match
---
expr_stmt [16704,16770]
expr_stmt [16704,16770]
===
match
---
trailer [11246,11257]
trailer [11246,11257]
===
match
---
name: DR [3446,3448]
name: DR [3446,3448]
===
match
---
trailer [88999,89008]
trailer [88951,88960]
===
match
---
name: subdags [79934,79941]
name: subdags [79886,79893]
===
match
---
expr_stmt [26532,26625]
expr_stmt [26484,26577]
===
match
---
name: start_date [26614,26624]
name: start_date [26566,26576]
===
match
---
name: String [87351,87357]
name: String [87303,87309]
===
match
---
name: args [60592,60596]
name: args [60544,60548]
===
match
---
name: session [76283,76290]
name: session [76235,76242]
===
match
---
simple_stmt [40635,40687]
simple_stmt [40587,40639]
===
match
---
suite [40743,41096]
suite [40695,41048]
===
match
---
expr_stmt [65115,65133]
expr_stmt [65067,65085]
===
match
---
name: orm_dag [78303,78310]
name: orm_dag [78255,78262]
===
match
---
trailer [71269,71811]
trailer [71221,71763]
===
match
---
operator: = [78652,78653]
operator: = [78604,78605]
===
match
---
name: Base [85678,85682]
name: Base [85630,85634]
===
match
---
trailer [28215,28249]
trailer [28167,28201]
===
match
---
simple_stmt [22282,22322]
simple_stmt [22258,22298]
===
match
---
name: count [57686,57691]
name: count [57638,57643]
===
match
---
simple_stmt [39939,40039]
simple_stmt [39891,39991]
===
match
---
name: back [96788,96792]
name: back [96740,96744]
===
match
---
simple_stmt [57376,57393]
simple_stmt [57328,57345]
===
match
---
operator: , [11014,11015]
operator: , [11014,11015]
===
match
---
trailer [22967,22986]
trailer [22919,22938]
===
match
---
trailer [39992,39999]
trailer [39944,39951]
===
match
---
simple_stmt [23616,23694]
simple_stmt [23568,23646]
===
match
---
name: dag_bound_args [95965,95979]
name: dag_bound_args [95917,95931]
===
match
---
string: 'undefined' [41664,41675]
string: 'undefined' [41616,41627]
===
match
---
atom_expr [43306,43315]
atom_expr [43258,43267]
===
match
---
simple_stmt [14895,14934]
simple_stmt [14895,14934]
===
match
---
trailer [39741,39743]
trailer [39693,39695]
===
match
---
name: get_task [42779,42787]
name: get_task [42731,42739]
===
match
---
trailer [88649,88656]
trailer [88601,88608]
===
match
---
suite [25728,25773]
suite [25680,25725]
===
match
---
name: self [13363,13367]
name: self [13363,13367]
===
match
---
name: log [2874,2877]
name: log [2874,2877]
===
match
---
atom_expr [43585,43636]
atom_expr [43537,43588]
===
match
---
name: tis [52860,52863]
name: tis [52812,52815]
===
match
---
atom_expr [69073,69112]
atom_expr [69025,69064]
===
match
---
expr_stmt [60033,60053]
expr_stmt [59985,60005]
===
match
---
operator: = [86870,86871]
operator: = [86822,86823]
===
match
---
atom_expr [31714,31743]
atom_expr [31666,31695]
===
match
---
operator: = [89499,89500]
operator: = [89451,89452]
===
match
---
name: self [45716,45720]
name: self [45668,45672]
===
match
---
name: get_last_dagrun [29532,29547]
name: get_last_dagrun [29484,29499]
===
match
---
operator: , [22957,22958]
operator: , [22909,22910]
===
match
---
comparison [20191,20219]
comparison [20191,20219]
===
match
---
name: _schedule_interval [35194,35212]
name: _schedule_interval [35146,35164]
===
match
---
name: log [26766,26769]
name: log [26718,26721]
===
match
---
name: template_searchpath [14610,14629]
name: template_searchpath [14610,14629]
===
match
---
trailer [83245,83251]
trailer [83197,83203]
===
match
---
expr_stmt [95263,95325]
expr_stmt [95215,95277]
===
match
---
string: """         Returns the number of active "running" dag runs          :param external_trigger: True for externally triggered active dag runs         :type external_trigger: bool         :param session:         :return: number greater than 0 for active dag runs         """ [37389,37660]
string: """         Returns the number of active "running" dag runs          :param external_trigger: True for externally triggered active dag runs         :type external_trigger: bool         :param session:         :return: number greater than 0 for active dag runs         """ [37341,37612]
===
match
---
simple_stmt [60522,60546]
simple_stmt [60474,60498]
===
match
---
name: back [96815,96819]
name: back [96767,96771]
===
match
---
operator: = [82673,82674]
operator: = [82625,82626]
===
match
---
name: include_parentdag [52266,52283]
name: include_parentdag [52218,52235]
===
match
---
trailer [47928,47935]
trailer [47880,47887]
===
match
---
name: Column [87845,87851]
name: Column [87797,87803]
===
match
---
expr_stmt [95221,95254]
expr_stmt [95173,95206]
===
match
---
name: tuple [17566,17571]
name: tuple [17566,17571]
===
match
---
name: append [28674,28680]
name: append [28626,28632]
===
match
---
operator: } [12000,12001]
operator: } [12000,12001]
===
match
---
simple_stmt [88048,88148]
simple_stmt [88000,88100]
===
match
---
atom_expr [15451,15614]
atom_expr [15451,15614]
===
match
---
operator: , [34553,34554]
operator: , [34505,34506]
===
match
---
simple_stmt [59085,59094]
simple_stmt [59037,59046]
===
match
---
trailer [63693,63701]
trailer [63645,63653]
===
match
---
trailer [74208,74319]
trailer [74160,74271]
===
match
---
name: Column [85493,85499]
name: Column [85445,85451]
===
match
---
name: LocalExecutor [71028,71041]
name: LocalExecutor [70980,70993]
===
match
---
suite [53128,56981]
suite [53080,56933]
===
match
---
atom_expr [17327,17338]
atom_expr [17327,17338]
===
match
---
trailer [87902,87948]
trailer [87854,87900]
===
match
---
operator: = [12023,12024]
operator: = [12023,12024]
===
match
---
param [38142,38147]
param [38094,38099]
===
match
---
name: dag_hash [74627,74635]
name: dag_hash [74579,74587]
===
match
---
atom_expr [77151,77298]
atom_expr [77103,77250]
===
match
---
name: subdag_task_groups [64223,64241]
name: subdag_task_groups [64175,64193]
===
match
---
atom_expr [16487,16507]
atom_expr [16487,16507]
===
match
---
simple_stmt [32117,32177]
simple_stmt [32069,32129]
===
match
---
parameters [32008,32014]
parameters [31960,31966]
===
match
---
name: schedule_interval [35114,35131]
name: schedule_interval [35066,35083]
===
match
---
operator: @ [80554,80555]
operator: @ [80506,80507]
===
match
---
param [24042,24047]
param [23994,23999]
===
match
---
atom_expr [67665,67680]
atom_expr [67617,67632]
===
match
---
atom_expr [33507,33698]
atom_expr [33459,33650]
===
match
---
simple_stmt [58892,58912]
simple_stmt [58844,58864]
===
match
---
suite [79080,79223]
suite [79032,79175]
===
match
---
simple_stmt [79264,79311]
simple_stmt [79216,79263]
===
match
---
name: croniter [1255,1263]
name: croniter [1255,1263]
===
match
---
atom_expr [97251,97274]
atom_expr [97203,97226]
===
match
---
trailer [44118,44125]
trailer [44070,44077]
===
match
---
name: UPSTREAM_FAILED [52925,52940]
name: UPSTREAM_FAILED [52877,52892]
===
match
---
trailer [57184,57196]
trailer [57136,57148]
===
match
---
name: task [67294,67298]
name: task [67246,67250]
===
match
---
name: convert_to_utc [22639,22653]
name: convert_to_utc [22591,22605]
===
match
---
atom_expr [60414,60439]
atom_expr [60366,60391]
===
match
---
name: dag [77994,77997]
name: dag [77946,77949]
===
match
---
trailer [22766,22808]
trailer [22718,22760]
===
match
---
operator: , [96549,96550]
operator: , [96501,96502]
===
match
---
operator: , [89244,89245]
operator: , [89196,89197]
===
match
---
number: 1 [10314,10315]
number: 1 [10314,10315]
===
match
---
atom_expr [58373,58386]
atom_expr [58325,58338]
===
match
---
name: task [55001,55005]
name: task [54953,54957]
===
match
---
operator: , [26128,26129]
operator: , [26080,26081]
===
match
---
name: all [81057,81060]
name: all [81009,81012]
===
match
---
name: session [52402,52409]
name: session [52354,52361]
===
match
---
simple_stmt [85535,85611]
simple_stmt [85487,85563]
===
match
---
name: user_defined_macros [11842,11861]
name: user_defined_macros [11842,11861]
===
match
---
operator: } [55574,55575]
operator: } [55526,55527]
===
match
---
import_from [2825,2871]
import_from [2825,2871]
===
match
---
simple_stmt [78430,78455]
simple_stmt [78382,78407]
===
match
---
atom_expr [78494,78511]
atom_expr [78446,78463]
===
match
---
operator: , [58687,58688]
operator: , [58639,58640]
===
match
---
operator: , [16935,16936]
operator: , [16935,16936]
===
match
---
name: naive [22290,22295]
name: naive [22266,22271]
===
match
---
simple_stmt [86667,86702]
simple_stmt [86619,86654]
===
match
---
simple_stmt [57449,57458]
simple_stmt [57401,57410]
===
match
---
simple_stmt [58077,58090]
simple_stmt [58029,58042]
===
match
---
atom_expr [38957,39024]
atom_expr [38909,38976]
===
match
---
expr_stmt [51697,51908]
expr_stmt [51649,51860]
===
match
---
parameters [65268,65319]
parameters [65220,65271]
===
match
---
suite [92442,92472]
suite [92394,92424]
===
match
---
atom_expr [28939,28968]
atom_expr [28891,28920]
===
match
---
suite [17964,18035]
suite [17964,18035]
===
match
---
atom_expr [55939,56893]
atom_expr [55891,56845]
===
match
---
trailer [21083,21095]
trailer [21083,21095]
===
match
---
name: delta [21113,21118]
name: delta [21113,21118]
===
match
---
import_from [70885,70934]
import_from [70837,70886]
===
match
---
funcdef [81198,82047]
funcdef [81150,81999]
===
match
---
atom_expr [51492,51542]
atom_expr [51444,51494]
===
match
---
string: 'template_searchpath' [10036,10057]
string: 'template_searchpath' [10036,10057]
===
match
---
simple_stmt [51486,51543]
simple_stmt [51438,51495]
===
match
---
simple_stmt [47899,47964]
simple_stmt [47851,47916]
===
match
---
atom_expr [66337,66349]
atom_expr [66289,66301]
===
match
---
name: arguments [96566,96575]
name: arguments [96518,96527]
===
match
---
atom_expr [52782,52823]
atom_expr [52734,52775]
===
match
---
operator: = [78784,78785]
operator: = [78736,78737]
===
match
---
operator: , [48486,48487]
operator: , [48438,48439]
===
match
---
operator: == [51366,51368]
operator: == [51318,51320]
===
match
---
return_stmt [21468,21540]
return_stmt [21444,21516]
===
match
---
operator: = [93627,93628]
operator: = [93579,93580]
===
match
---
arglist [77176,77280]
arglist [77128,77232]
===
match
---
name: Optional [22930,22938]
name: Optional [22882,22890]
===
match
---
string: 'dag_id' [95931,95939]
string: 'dag_id' [95883,95891]
===
match
---
name: self [80531,80535]
name: self [80483,80487]
===
match
---
name: task_id [43293,43300]
name: task_id [43245,43252]
===
match
---
name: utils [2426,2431]
name: utils [2426,2431]
===
match
---
name: self [20482,20486]
name: self [20482,20486]
===
match
---
name: getint [88081,88087]
name: getint [88033,88039]
===
match
---
name: t [59157,59158]
name: t [59109,59110]
===
match
---
funcdef [42500,42809]
funcdef [42452,42761]
===
match
---
trailer [27249,27255]
trailer [27201,27207]
===
match
---
funcdef [27481,28789]
funcdef [27433,28741]
===
match
---
string: """Returns a list of the subdag objects associated to this DAG""" [40497,40562]
string: """Returns a list of the subdag objects associated to this DAG""" [40449,40514]
===
match
---
trailer [34274,34294]
trailer [34226,34246]
===
match
---
name: dag_ids [47866,47873]
name: dag_ids [47818,47825]
===
match
---
name: airflow [1702,1709]
name: airflow [1702,1709]
===
match
---
operator: , [47121,47122]
operator: , [47073,47074]
===
match
---
trailer [35309,35327]
trailer [35261,35279]
===
match
---
operator: = [78596,78597]
operator: = [78548,78549]
===
match
---
arglist [31595,31639]
arglist [31547,31591]
===
match
---
atom_expr [87958,88035]
atom_expr [87910,87987]
===
match
---
atom_expr [83366,83408]
atom_expr [83318,83360]
===
match
---
operator: = [69338,69339]
operator: = [69290,69291]
===
match
---
operator: = [58250,58251]
operator: = [58202,58203]
===
match
---
operator: , [10057,10058]
operator: , [10057,10058]
===
match
---
trailer [47920,47928]
trailer [47872,47880]
===
match
---
operator: >= [39645,39647]
operator: >= [39597,39599]
===
match
---
simple_stmt [68447,68463]
simple_stmt [68399,68415]
===
match
---
trailer [18919,18921]
trailer [18919,18921]
===
match
---
trailer [92498,92500]
trailer [92450,92452]
===
match
---
name: include_externally_triggered [29595,29623]
name: include_externally_triggered [29547,29575]
===
match
---
simple_stmt [31144,31167]
simple_stmt [31096,31119]
===
match
---
name: TI [51356,51358]
name: TI [51308,51310]
===
match
---
operator: = [41959,41960]
operator: = [41911,41912]
===
match
---
atom_expr [28216,28228]
atom_expr [28168,28180]
===
match
---
name: get_concurrency_reached [33719,33742]
name: get_concurrency_reached [33671,33694]
===
match
---
name: DagStateChangeCallback [3092,3114]
name: DagStateChangeCallback [3092,3114]
===
match
---
argument [58624,58649]
argument [58576,58601]
===
match
---
simple_stmt [56948,56981]
simple_stmt [56900,56933]
===
match
---
test [28500,28585]
test [28452,28537]
===
match
---
name: scalar [40030,40036]
name: scalar [39982,39988]
===
match
---
trailer [78949,78953]
trailer [78901,78905]
===
match
---
simple_stmt [30442,30473]
simple_stmt [30394,30425]
===
match
---
param [77920,77921]
param [77872,77873]
===
match
---
operator: = [54932,54933]
operator: = [54884,54885]
===
match
---
operator: , [34611,34612]
operator: , [34563,34564]
===
match
---
name: bulk_write_to_db [75405,75421]
name: bulk_write_to_db [75357,75373]
===
match
---
operator: { [12035,12036]
operator: { [12035,12036]
===
match
---
trailer [33313,33315]
trailer [33265,33267]
===
match
---
expr_stmt [53966,53980]
expr_stmt [53918,53932]
===
match
---
name: self [90500,90504]
name: self [90452,90456]
===
match
---
atom_expr [62058,62074]
atom_expr [62010,62026]
===
match
---
atom_expr [88209,88235]
atom_expr [88161,88187]
===
match
---
name: cls [91898,91901]
name: cls [91850,91853]
===
match
---
expr_stmt [78524,78563]
expr_stmt [78476,78515]
===
match
---
name: format_exc [66050,66060]
name: format_exc [66002,66012]
===
match
---
name: self [29731,29735]
name: self [29683,29687]
===
match
---
name: subdag_task_groups [64302,64320]
name: subdag_task_groups [64254,64272]
===
match
---
name: dag_bound_args [95263,95277]
name: dag_bound_args [95215,95229]
===
match
---
simple_stmt [52860,52943]
simple_stmt [52812,52895]
===
match
---
argument [67088,67096]
argument [67040,67048]
===
match
---
operator: -> [32101,32103]
operator: -> [32053,32055]
===
match
---
name: using_start_date [28524,28540]
name: using_start_date [28476,28492]
===
match
---
operator: , [13833,13834]
operator: , [13833,13834]
===
match
---
name: task_id [82864,82871]
name: task_id [82816,82823]
===
match
---
atom [18654,18835]
atom [18654,18835]
===
match
---
name: dag_ids [76201,76208]
name: dag_ids [76153,76160]
===
match
---
decorated [3671,85357]
decorated [3671,85309]
===
match
---
trailer [28523,28541]
trailer [28475,28493]
===
match
---
operator: , [89507,89508]
operator: , [89459,89460]
===
match
---
name: set_downstream [42759,42773]
name: set_downstream [42711,42725]
===
match
---
name: SerializedDagModel [97290,97308]
name: SerializedDagModel [97242,97260]
===
match
---
operator: , [62053,62054]
operator: , [62005,62006]
===
match
---
trailer [78633,78651]
trailer [78585,78603]
===
match
---
operator: @ [32333,32334]
operator: @ [32285,32286]
===
match
---
trailer [82044,82046]
trailer [81996,81998]
===
match
---
operator: = [96729,96730]
operator: = [96681,96682]
===
match
---
name: datetime [21214,21222]
name: datetime [21214,21222]
===
match
---
name: DagModel [89139,89147]
name: DagModel [89091,89099]
===
match
---
atom_expr [55152,55171]
atom_expr [55104,55123]
===
match
---
trailer [85557,85565]
trailer [85509,85517]
===
match
---
if_stmt [66262,66376]
if_stmt [66214,66328]
===
match
---
trailer [81925,81935]
trailer [81877,81887]
===
match
---
operator: , [1419,1420]
operator: , [1419,1420]
===
match
---
name: airflow [71912,71919]
name: airflow [71864,71871]
===
match
---
operator: = [64678,64679]
operator: = [64630,64631]
===
match
---
operator: -> [32015,32017]
operator: -> [31967,31969]
===
match
---
argument [31595,31611]
argument [31547,31563]
===
match
---
arith_expr [21079,21118]
arith_expr [21079,21118]
===
match
---
atom [91245,91276]
atom [91197,91228]
===
match
---
trailer [16808,16820]
trailer [16808,16820]
===
match
---
name: timezone [78494,78502]
name: timezone [78446,78454]
===
match
---
name: get_edge_info [84562,84575]
name: get_edge_info [84514,84527]
===
match
---
name: instances [53337,53346]
name: instances [53289,53298]
===
match
---
operator: , [1055,1056]
operator: , [1055,1056]
===
match
---
funcdef [34678,35482]
funcdef [34630,35434]
===
match
---
atom_expr [52919,52940]
atom_expr [52871,52892]
===
match
---
trailer [68413,68427]
trailer [68365,68379]
===
match
---
name: session [33912,33919]
name: session [33864,33871]
===
match
---
name: self [16575,16579]
name: self [16575,16579]
===
match
---
name: default_args [13752,13764]
name: default_args [13752,13764]
===
match
---
name: jinja_environment_kwargs [16671,16695]
name: jinja_environment_kwargs [16671,16695]
===
match
---
trailer [85286,85296]
trailer [85238,85248]
===
match
---
operator: = [58594,58595]
operator: = [58546,58547]
===
match
---
name: correct_maybe_zipped [2444,2464]
name: correct_maybe_zipped [2444,2464]
===
match
---
trailer [25429,25447]
trailer [25381,25399]
===
match
---
name: is_paused_upon_creation [16606,16629]
name: is_paused_upon_creation [16606,16629]
===
match
---
operator: @ [75380,75381]
operator: @ [75332,75333]
===
match
---
name: co_filename [96800,96811]
name: co_filename [96752,96763]
===
match
---
name: self [31777,31781]
name: self [31729,31733]
===
match
---
decorator [31980,31990]
decorator [31932,31942]
===
match
---
operator: , [20730,20731]
operator: , [20730,20731]
===
match
---
expr_stmt [57376,57392]
expr_stmt [57328,57344]
===
match
---
name: execution_date [74133,74147]
name: execution_date [74085,74099]
===
match
---
trailer [79581,79594]
trailer [79533,79546]
===
match
---
name: tasks [65095,65100]
name: tasks [65047,65052]
===
match
---
param [30816,30821]
param [30768,30773]
===
match
---
operator: ** [42071,42073]
operator: ** [42023,42025]
===
match
---
decorated [30375,30473]
decorated [30327,30425]
===
match
---
decorator [30764,30787]
decorator [30716,30739]
===
match
---
trailer [17806,17813]
trailer [17806,17813]
===
match
---
for_stmt [79046,79223]
for_stmt [78998,79175]
===
match
---
trailer [31064,31078]
trailer [31016,31030]
===
match
---
sync_comp_for [32731,32750]
sync_comp_for [32683,32702]
===
match
---
simple_stmt [87547,87598]
simple_stmt [87499,87550]
===
match
---
name: tis [52776,52779]
name: tis [52728,52731]
===
match
---
trailer [65893,65900]
trailer [65845,65852]
===
match
---
trailer [64426,64431]
trailer [64378,64383]
===
match
---
operator: , [77298,77299]
operator: , [77250,77251]
===
match
---
string: """         Sets the given edge information on the DAG. Note that this will overwrite,         rather than merge with, existing info.         """ [85128,85273]
string: """         Sets the given edge information on the DAG. Note that this will overwrite,         rather than merge with, existing info.         """ [85080,85225]
===
match
---
funcdef [44907,47400]
funcdef [44859,47352]
===
match
---
parameters [98530,98535]
parameters [98482,98487]
===
match
---
operator: , [56576,56577]
operator: , [56528,56529]
===
match
---
name: dag [66265,66268]
name: dag [66217,66220]
===
match
---
simple_stmt [91174,91316]
simple_stmt [91126,91268]
===
match
---
atom_expr [78430,78447]
atom_expr [78382,78399]
===
match
---
trailer [32275,32280]
trailer [32227,32232]
===
match
---
trailer [90632,90639]
trailer [90584,90591]
===
match
---
simple_stmt [37703,37864]
simple_stmt [37655,37816]
===
match
---
name: DagModel [76181,76189]
name: DagModel [76133,76141]
===
match
---
trailer [63272,63295]
trailer [63224,63247]
===
match
---
operator: -> [44461,44463]
operator: -> [44413,44415]
===
match
---
atom_expr [89653,89662]
atom_expr [89605,89614]
===
match
---
atom_expr [20191,20205]
atom_expr [20191,20205]
===
match
---
name: query [38957,38962]
name: query [38909,38914]
===
match
---
atom_expr [20766,20816]
atom_expr [20766,20816]
===
match
---
param [3165,3172]
param [3165,3172]
===
match
---
name: next_execution_date [23988,24007]
name: next_execution_date [23940,23959]
===
match
---
trailer [66336,66367]
trailer [66288,66319]
===
match
---
operator: @ [66974,66975]
operator: @ [66926,66927]
===
match
---
expr_stmt [36497,36509]
expr_stmt [36449,36461]
===
match
---
funcdef [92598,93638]
funcdef [92550,93590]
===
match
---
fstring_start: f" [73770,73772]
fstring_start: f" [73722,73724]
===
match
---
name: __ne__ [17228,17234]
name: __ne__ [17228,17234]
===
match
---
operator: , [87933,87934]
operator: , [87885,87886]
===
match
---
name: self [22046,22050]
name: self [22022,22026]
===
match
---
atom_expr [79066,79078]
atom_expr [79018,79030]
===
match
---
atom_expr [65359,65373]
atom_expr [65311,65325]
===
match
---
name: start_date [67699,67709]
name: start_date [67651,67661]
===
match
---
tfpdef [48726,48758]
tfpdef [48678,48710]
===
match
---
name: also_include [62612,62624]
name: also_include [62564,62576]
===
match
---
string: 'BT' [3085,3089]
string: 'BT' [3085,3089]
===
match
---
operator: , [71509,71510]
operator: , [71461,71462]
===
match
---
simple_stmt [832,842]
simple_stmt [832,842]
===
match
---
trailer [91897,91902]
trailer [91849,91854]
===
match
---
simple_stmt [18635,18836]
simple_stmt [18635,18836]
===
match
---
name: filter [34211,34217]
name: filter [34163,34169]
===
match
---
name: task_id [53906,53913]
name: task_id [53858,53865]
===
match
---
decorated [34300,34659]
decorated [34252,34611]
===
match
---
name: tags [79521,79525]
name: tags [79473,79477]
===
match
---
name: Optional [38249,38257]
name: Optional [38201,38209]
===
match
---
atom_expr [16823,16850]
atom_expr [16823,16850]
===
match
---
decorators [91346,91380]
decorators [91298,91332]
===
match
---
trailer [40036,40038]
trailer [39988,39990]
===
match
---
if_stmt [92033,92421]
if_stmt [91985,92373]
===
match
---
operator: @ [33346,33347]
operator: @ [33298,33299]
===
match
---
name: self [41431,41435]
name: self [41383,41387]
===
match
---
import_as_names [2656,2706]
import_as_names [2656,2706]
===
match
---
operator: = [72188,72189]
operator: = [72140,72141]
===
match
---
operator: -> [31918,31920]
operator: -> [31870,31872]
===
match
---
name: count [59022,59027]
name: count [58974,58979]
===
match
---
argument [89492,89507]
argument [89444,89459]
===
match
---
atom [44844,44901]
atom [44796,44853]
===
match
---
name: self [15091,15095]
name: self [15091,15095]
===
match
---
operator: , [88170,88171]
operator: , [88122,88123]
===
match
---
atom_expr [40777,40809]
atom_expr [40729,40761]
===
match
---
trailer [34194,34200]
trailer [34146,34152]
===
match
---
trailer [84921,84931]
trailer [84873,84883]
===
match
---
if_stmt [91075,91166]
if_stmt [91027,91118]
===
match
---
name: query [93220,93225]
name: query [93172,93177]
===
match
---
fstring_end: " [55716,55717]
fstring_end: " [55668,55669]
===
match
---
name: ORIENTATION_PRESETS [15355,15374]
name: ORIENTATION_PRESETS [15355,15374]
===
match
---
name: Context [2136,2143]
name: Context [2136,2143]
===
match
---
name: level [66902,66907]
name: level [66854,66859]
===
match
---
suite [13281,13512]
suite [13281,13512]
===
match
---
atom_expr [14206,14237]
atom_expr [14206,14237]
===
match
---
expr_stmt [58426,58438]
expr_stmt [58378,58390]
===
match
---
name: logging_mixin [2535,2548]
name: logging_mixin [2535,2548]
===
match
---
name: _description [12836,12848]
name: _description [12836,12848]
===
match
---
import_as_names [1642,1657]
import_as_names [1642,1657]
===
match
---
operator: , [17302,17303]
operator: , [17302,17303]
===
match
---
operator: = [3533,3534]
operator: = [3533,3534]
===
match
---
name: self [66633,66637]
name: self [66585,66589]
===
match
---
try_stmt [91917,92576]
try_stmt [91869,92528]
===
match
---
expr_stmt [83187,83325]
expr_stmt [83139,83277]
===
match
---
name: task [68414,68418]
name: task [68366,68370]
===
match
---
param [38240,38274]
param [38192,38226]
===
match
---
parameters [88890,88896]
parameters [88842,88848]
===
match
---
atom_expr [62368,62377]
atom_expr [62320,62329]
===
match
---
name: searchpath [41469,41479]
name: searchpath [41421,41431]
===
match
---
if_stmt [25811,26239]
if_stmt [25763,26191]
===
match
---
raise_stmt [55519,55577]
raise_stmt [55471,55529]
===
match
---
trailer [90055,90062]
trailer [90007,90014]
===
match
---
operator: = [25899,25900]
operator: = [25851,25852]
===
match
---
operator: , [30003,30004]
operator: , [29955,29956]
===
match
---
expr_stmt [14792,14828]
expr_stmt [14792,14828]
===
match
---
trailer [30836,30852]
trailer [30788,30804]
===
match
---
trailer [81035,81039]
trailer [80987,80991]
===
match
---
operator: = [64059,64060]
operator: = [64011,64012]
===
match
---
trailer [89948,89965]
trailer [89900,89917]
===
match
---
name: models [1892,1898]
name: models [1892,1898]
===
match
---
expr_stmt [41062,41095]
expr_stmt [41014,41047]
===
match
---
name: cls [93226,93229]
name: cls [93178,93181]
===
match
---
operator: , [93587,93588]
operator: , [93539,93540]
===
match
---
comparison [59022,59032]
comparison [58974,58984]
===
match
---
name: orm_dag [78391,78398]
name: orm_dag [78343,78350]
===
match
---
comparison [13711,13742]
comparison [13711,13742]
===
match
---
name: property [29707,29715]
name: property [29659,29667]
===
match
---
operator: = [58343,58344]
operator: = [58295,58296]
===
match
---
name: Callable [11052,11060]
name: Callable [11052,11060]
===
match
---
trailer [41080,41087]
trailer [41032,41039]
===
match
---
name: path [32461,32465]
name: path [32413,32417]
===
match
---
trailer [85655,85660]
trailer [85607,85612]
===
match
---
operator: @ [89600,89601]
operator: @ [89552,89553]
===
match
---
name: self [25924,25928]
name: self [25876,25880]
===
match
---
name: DagModel [91188,91196]
name: DagModel [91140,91148]
===
match
---
expr_stmt [59814,59823]
expr_stmt [59766,59775]
===
match
---
simple_stmt [60554,60568]
simple_stmt [60506,60520]
===
match
---
simple_stmt [82669,82784]
simple_stmt [82621,82736]
===
match
---
trailer [65750,65757]
trailer [65702,65709]
===
match
---
name: FrozenSet [10123,10132]
name: FrozenSet [10123,10132]
===
match
---
operator: = [66247,66248]
operator: = [66199,66200]
===
match
---
name: task_dict [65559,65568]
name: task_dict [65511,65520]
===
match
---
name: task_ids [48278,48286]
name: task_ids [48230,48238]
===
match
---
comparison [17327,17353]
comparison [17327,17353]
===
match
---
strings [15196,15314]
strings [15196,15314]
===
match
---
trailer [26966,26975]
trailer [26918,26927]
===
match
---
trailer [51808,51811]
trailer [51760,51763]
===
match
---
import_from [2336,2412]
import_from [2336,2412]
===
match
---
dotted_name [2712,2731]
dotted_name [2712,2731]
===
match
---
dotted_name [97190,97219]
dotted_name [97142,97171]
===
match
---
simple_stmt [66604,66614]
simple_stmt [66556,66566]
===
match
---
operator: = [57986,57987]
operator: = [57938,57939]
===
match
---
name: dag_id [89148,89154]
name: dag_id [89100,89106]
===
match
---
name: Optional [24076,24084]
name: Optional [24028,24036]
===
match
---
simple_stmt [90115,90185]
simple_stmt [90067,90137]
===
match
---
name: f_sig [95804,95809]
name: f_sig [95756,95761]
===
match
---
name: self [32523,32527]
name: self [32475,32479]
===
match
---
name: Iterable [10504,10512]
name: Iterable [10504,10512]
===
match
---
atom_expr [82689,82721]
atom_expr [82641,82673]
===
match
---
if_stmt [26248,26431]
if_stmt [26200,26383]
===
match
---
name: template_undefined [10536,10554]
name: template_undefined [10536,10554]
===
match
---
operator: = [47233,47234]
operator: = [47185,47186]
===
match
---
name: stacklevel [30308,30318]
name: stacklevel [30260,30270]
===
match
---
name: task_id [36585,36592]
name: task_id [36537,36544]
===
match
---
trailer [20912,20935]
trailer [20912,20935]
===
match
---
operator: , [75295,75296]
operator: , [75247,75248]
===
match
---
return_stmt [88906,88936]
return_stmt [88858,88888]
===
match
---
trailer [37772,37802]
trailer [37724,37754]
===
match
---
simple_stmt [33707,33745]
simple_stmt [33659,33697]
===
match
---
atom_expr [73949,73981]
atom_expr [73901,73933]
===
match
---
name: start_date [10326,10336]
name: start_date [10326,10336]
===
match
---
atom_expr [52881,52889]
atom_expr [52833,52841]
===
match
---
operator: @ [29401,29402]
operator: @ [29353,29354]
===
match
---
param [58326,58350]
param [58278,58302]
===
match
---
if_stmt [59019,59094]
if_stmt [58971,59046]
===
match
---
name: DAGS_FOLDER [32226,32237]
name: DAGS_FOLDER [32178,32189]
===
match
---
arglist [38847,38916]
arglist [38799,38868]
===
match
---
testlist_comp [23884,23924]
testlist_comp [23836,23876]
===
match
---
argument [55680,55717]
argument [55632,55669]
===
match
---
name: is_ [83293,83296]
name: is_ [83245,83248]
===
match
---
trailer [19990,19992]
trailer [19990,19992]
===
match
---
name: end_date [52031,52039]
name: end_date [51983,51991]
===
match
---
arglist [13804,13838]
arglist [13804,13838]
===
match
---
suite [32536,32753]
suite [32488,32705]
===
match
---
name: handle_callback [35512,35527]
name: handle_callback [35464,35479]
===
match
---
string: 'webserver' [80457,80468]
string: 'webserver' [80409,80420]
===
match
---
operator: , [91055,91056]
operator: , [91007,91008]
===
match
---
atom_expr [96731,96753]
atom_expr [96683,96705]
===
match
---
atom_expr [38877,38898]
atom_expr [38829,38850]
===
match
---
import_name [800,816]
import_name [800,816]
===
match
---
operator: , [80468,80469]
operator: , [80420,80421]
===
match
---
trailer [51358,51365]
trailer [51310,51317]
===
match
---
simple_stmt [2180,2221]
simple_stmt [2180,2221]
===
match
---
argument [31613,31622]
argument [31565,31574]
===
match
---
name: debug [91767,91772]
name: debug [91719,91724]
===
match
---
trailer [57520,57523]
trailer [57472,57475]
===
match
---
name: pickle [65782,65788]
name: pickle [65734,65740]
===
match
---
funcdef [98511,98594]
funcdef [98463,98546]
===
match
---
trailer [62648,62663]
trailer [62600,62615]
===
match
---
trailer [47051,47057]
trailer [47003,47009]
===
match
---
expr_stmt [53293,53314]
expr_stmt [53245,53266]
===
match
---
trailer [11106,11139]
trailer [11106,11139]
===
match
---
trailer [97878,97883]
trailer [97830,97835]
===
match
---
operator: } [74075,74076]
operator: } [74027,74028]
===
match
---
name: pop [98402,98405]
name: pop [98354,98357]
===
match
---
expr_stmt [12921,12950]
expr_stmt [12921,12950]
===
match
---
name: calculate_dagrun_date_fields [93647,93675]
name: calculate_dagrun_date_fields [93599,93627]
===
match
---
atom_expr [60322,60348]
atom_expr [60274,60300]
===
match
---
operator: = [88028,88029]
operator: = [87980,87981]
===
match
---
simple_stmt [90193,90215]
simple_stmt [90145,90167]
===
match
---
operator: = [42030,42031]
operator: = [41982,41983]
===
match
---
atom_expr [44303,44344]
atom_expr [44255,44296]
===
match
---
name: dirname [32466,32473]
name: dirname [32418,32425]
===
match
---
name: self [36376,36380]
name: self [36328,36332]
===
match
---
name: replace [14863,14870]
name: replace [14863,14870]
===
match
---
name: self [60536,60540]
name: self [60488,60492]
===
match
---
name: run_dates [28779,28788]
name: run_dates [28731,28740]
===
match
---
simple_stmt [16704,16771]
simple_stmt [16704,16771]
===
match
---
dictorsetmaker [41605,41775]
dictorsetmaker [41557,41727]
===
match
---
or_test [28192,28249]
or_test [28144,28201]
===
match
---
atom_expr [37101,37153]
atom_expr [37053,37105]
===
match
---
operator: , [29593,29594]
operator: , [29545,29546]
===
match
---
atom_expr [51398,51410]
atom_expr [51350,51362]
===
match
---
name: self [29843,29847]
name: self [29795,29799]
===
match
---
suite [90612,90664]
suite [90564,90616]
===
match
---
dotted_name [1459,1473]
dotted_name [1459,1473]
===
match
---
atom_expr [53009,53022]
atom_expr [52961,52974]
===
match
---
param [16869,16873]
param [16869,16873]
===
match
---
atom_expr [12784,12799]
atom_expr [12784,12799]
===
match
---
simple_stmt [75910,75946]
simple_stmt [75862,75898]
===
match
---
decorator [89582,89596]
decorator [89534,89548]
===
match
---
name: DagRunType [2777,2787]
name: DagRunType [2777,2787]
===
match
---
name: access_control [30765,30779]
name: access_control [30717,30731]
===
match
---
name: start_date [25904,25914]
name: start_date [25856,25866]
===
match
---
name: _comps [17440,17446]
name: _comps [17440,17446]
===
match
---
operator: , [52191,52192]
operator: , [52143,52144]
===
match
---
suite [65482,65578]
suite [65434,65530]
===
match
---
fstring_string: \n\nAre you sure? (yes/no):  [59258,59286]
fstring_string: \n\nAre you sure? (yes/no):  [59210,59238]
===
match
---
trailer [83395,83399]
trailer [83347,83351]
===
match
---
operator: , [74548,74549]
operator: , [74500,74501]
===
match
---
trailer [44705,44719]
trailer [44657,44671]
===
match
---
trailer [51516,51542]
trailer [51468,51494]
===
match
---
trailer [65985,66001]
trailer [65937,65953]
===
match
---
name: str [16111,16114]
name: str [16111,16114]
===
match
---
trailer [44306,44313]
trailer [44258,44265]
===
match
---
trailer [76747,76786]
trailer [76699,76738]
===
match
---
name: tasks [45615,45620]
name: tasks [45567,45572]
===
match
---
name: creating_job_id [72485,72500]
name: creating_job_id [72437,72452]
===
match
---
trailer [62369,62377]
trailer [62321,62329]
===
match
---
decorated [66085,66614]
decorated [66037,66566]
===
match
---
string: 'dag_id' [95990,95998]
string: 'dag_id' [95942,95950]
===
match
---
name: ExecutorLoader [71206,71220]
name: ExecutorLoader [71158,71172]
===
match
---
param [21574,21578]
param [21550,21554]
===
match
---
operator: , [29309,29310]
operator: , [29261,29262]
===
match
---
operator: == [82763,82765]
operator: == [82715,82717]
===
match
---
atom_expr [98020,98044]
atom_expr [97972,97996]
===
match
---
tfpdef [72131,72143]
tfpdef [72083,72095]
===
match
---
arglist [95931,95951]
arglist [95883,95903]
===
match
---
trailer [32194,32208]
trailer [32146,32160]
===
match
---
trailer [18679,18710]
trailer [18679,18710]
===
match
---
string: 'cache_size' [41759,41771]
string: 'cache_size' [41711,41723]
===
match
---
expr_stmt [26001,26063]
expr_stmt [25953,26015]
===
match
---
name: result [60322,60328]
name: result [60274,60280]
===
match
---
operator: @ [89032,89033]
operator: @ [88984,88985]
===
match
---
param [33384,33388]
param [33336,33340]
===
match
---
operator: = [76391,76392]
operator: = [76343,76344]
===
match
---
name: task_id [53077,53084]
name: task_id [53029,53036]
===
match
---
name: task_id [47003,47010]
name: task_id [46955,46962]
===
match
---
trailer [3620,3635]
trailer [3620,3635]
===
match
---
atom_expr [17406,17416]
atom_expr [17406,17416]
===
match
---
trailer [79241,79246]
trailer [79193,79198]
===
match
---
return_stmt [33983,34019]
return_stmt [33935,33971]
===
match
---
trailer [60468,60475]
trailer [60420,60427]
===
match
---
atom_expr [41840,41895]
atom_expr [41792,41847]
===
match
---
trailer [11543,11549]
trailer [11543,11549]
===
match
---
name: set [63269,63272]
name: set [63221,63224]
===
match
---
atom [51313,51319]
atom [51265,51271]
===
match
---
name: pendulum [24085,24093]
name: pendulum [24037,24045]
===
match
---
name: bool [11235,11239]
name: bool [11235,11239]
===
match
---
operator: = [11918,11919]
operator: = [11918,11919]
===
match
---
trailer [39999,40029]
trailer [39951,39981]
===
match
---
name: user_defined_filters [60391,60411]
name: user_defined_filters [60343,60363]
===
match
---
string: """         Looks for outdated dag level actions (can_dag_read and can_dag_edit) in DAG         access_controls (for example, {'role1': {'can_dag_read'}, 'role2': {'can_dag_read', 'can_dag_edit'}})         and replaces them with updated actions (can_read and can_edit).         """ [18290,18571]
string: """         Looks for outdated dag level actions (can_dag_read and can_dag_edit) in DAG         access_controls (for example, {'role1': {'can_dag_read'}, 'role2': {'can_dag_read', 'can_dag_edit'}})         and replaces them with updated actions (can_read and can_edit).         """ [18290,18571]
===
match
---
simple_stmt [28664,28696]
simple_stmt [28616,28648]
===
match
---
for_stmt [18880,19019]
for_stmt [18880,19019]
===
match
---
simple_stmt [30832,30903]
simple_stmt [30784,30855]
===
match
---
param [32952,32957]
param [32904,32909]
===
match
---
name: Optional [10640,10648]
name: Optional [10640,10648]
===
match
---
name: most_recent_dag_runs [78929,78949]
name: most_recent_dag_runs [78881,78901]
===
match
---
testlist_comp [25902,25950]
testlist_comp [25854,25902]
===
match
---
parameters [28816,28828]
parameters [28768,28780]
===
match
---
simple_stmt [85758,85843]
simple_stmt [85710,85795]
===
match
---
name: sensors [53154,53161]
name: sensors [53106,53113]
===
match
---
name: session [38765,38772]
name: session [38717,38724]
===
match
---
trailer [43136,43142]
trailer [43088,43094]
===
match
---
atom_expr [15654,15668]
atom_expr [15654,15668]
===
match
---
operator: = [65311,65312]
operator: = [65263,65264]
===
match
---
operator: , [48188,48189]
operator: , [48140,48141]
===
match
---
trailer [86160,86200]
trailer [86112,86152]
===
match
---
argument [58852,58864]
argument [58804,58816]
===
match
---
expr_stmt [60322,60375]
expr_stmt [60274,60327]
===
match
---
atom_expr [61019,61032]
atom_expr [60971,60984]
===
match
---
name: qry [34181,34184]
name: qry [34133,34136]
===
match
---
return_stmt [98562,98593]
return_stmt [98514,98545]
===
match
---
expr_stmt [83360,83408]
expr_stmt [83312,83360]
===
match
---
funcdef [40470,41122]
funcdef [40422,41074]
===
match
---
atom_expr [86872,86887]
atom_expr [86824,86839]
===
match
---
simple_stmt [40411,40451]
simple_stmt [40363,40403]
===
match
---
atom_expr [31679,31697]
atom_expr [31631,31649]
===
match
---
simple_stmt [25745,25773]
simple_stmt [25697,25725]
===
match
---
operator: , [32956,32957]
operator: , [32908,32909]
===
match
---
simple_stmt [79154,79178]
simple_stmt [79106,79130]
===
match
---
suite [18602,18627]
suite [18602,18627]
===
match
---
atom_expr [22774,22807]
atom_expr [22726,22759]
===
match
---
name: expression [77768,77778]
name: expression [77720,77730]
===
match
---
name: staticmethod [89015,89027]
name: staticmethod [88967,88979]
===
match
---
suite [19557,19760]
suite [19557,19760]
===
match
---
name: Column [1394,1400]
name: Column [1394,1400]
===
match
---
name: visited_external_tis [53488,53508]
name: visited_external_tis [53440,53460]
===
match
---
suite [17612,17658]
suite [17612,17658]
===
match
---
expr_stmt [15743,15763]
expr_stmt [15743,15763]
===
match
---
operator: @ [74934,74935]
operator: @ [74886,74887]
===
match
---
operator: = [52127,52128]
operator: = [52079,52080]
===
match
---
name: session [36640,36647]
name: session [36592,36599]
===
match
---
name: timezone [65885,65893]
name: timezone [65837,65845]
===
match
---
import_name [788,799]
import_name [788,799]
===
match
---
name: dag [97998,98001]
name: dag [97950,97953]
===
match
---
atom_expr [53074,53098]
atom_expr [53026,53050]
===
match
---
arglist [62162,62201]
arglist [62114,62153]
===
match
---
trailer [96096,96101]
trailer [96048,96053]
===
match
---
name: dag_id [76335,76341]
name: dag_id [76287,76293]
===
match
---
operator: = [74567,74568]
operator: = [74519,74520]
===
match
---
operator: = [90770,90771]
operator: = [90722,90723]
===
match
---
trailer [14072,14081]
trailer [14072,14081]
===
match
---
suite [78286,78418]
suite [78238,78370]
===
match
---
trailer [3456,3477]
trailer [3456,3477]
===
match
---
name: dags [58458,58462]
name: dags [58410,58414]
===
match
---
param [29808,29813]
param [29760,29765]
===
match
---
if_stmt [59351,59877]
if_stmt [59303,59829]
===
match
---
operator: = [11240,11241]
operator: = [11240,11241]
===
match
---
name: dag [94160,94163]
name: dag [94112,94115]
===
match
---
atom_expr [21933,21956]
atom_expr [21909,21932]
===
match
---
atom_expr [14713,14728]
atom_expr [14713,14728]
===
match
---
sync_comp_for [19000,19017]
sync_comp_for [19000,19017]
===
match
---
trailer [63425,63427]
trailer [63377,63379]
===
match
---
name: task_ids [82795,82803]
name: task_ids [82747,82755]
===
match
---
simple_stmt [85383,85451]
simple_stmt [85335,85403]
===
match
---
trailer [35236,35254]
trailer [35188,35206]
===
match
---
string: "Deactivating DAGs (for which DAG files are deleted) from %s table " [91773,91841]
string: "Deactivating DAGs (for which DAG files are deleted) from %s table " [91725,91793]
===
match
---
suite [30526,30565]
suite [30478,30517]
===
match
---
fstring_expr [59249,59258]
fstring_expr [59201,59210]
===
match
---
operator: , [43687,43688]
operator: , [43639,43640]
===
match
---
arglist [36390,36437]
arglist [36342,36389]
===
match
---
string: """         Returns a subset of the current dag as a deep copy of the current dag         based on a regex that should match one or many tasks, and includes         upstream and downstream neighbours based on the flag passed.          :param task_ids_or_regex: Either a list of task_ids, or a regex to             match against task ids (as a string, or compiled regex pattern).         :type task_ids_or_regex: [str] or str or re.Pattern         :param include_downstream: Include all downstream tasks of matched             tasks, in addition to matched tasks.         :param include_upstream: Include all upstream tasks of matched tasks,             in addition to matched tasks.         """ [61154,61848]
string: """         Returns a subset of the current dag as a deep copy of the current dag         based on a regex that should match one or many tasks, and includes         upstream and downstream neighbours based on the flag passed.          :param task_ids_or_regex: Either a list of task_ids, or a regex to             match against task ids (as a string, or compiled regex pattern).         :type task_ids_or_regex: [str] or str or re.Pattern         :param include_downstream: Include all downstream tasks of matched             tasks, in addition to matched tasks.         :param include_upstream: Include all upstream tasks of matched tasks,             in addition to matched tasks.         """ [61106,61800]
===
match
---
name: latest_execution_date [40062,40083]
name: latest_execution_date [40014,40035]
===
match
---
operator: = [13471,13472]
operator: = [13471,13472]
===
match
---
simple_stmt [1658,1697]
simple_stmt [1658,1697]
===
match
---
param [10208,10242]
param [10208,10242]
===
match
---
name: run_type [74066,74074]
name: run_type [74018,74026]
===
match
---
funcdef [42835,44426]
funcdef [42787,44378]
===
match
---
name: schedule_interval [23463,23480]
name: schedule_interval [23415,23432]
===
match
---
operator: + [51311,51312]
operator: + [51263,51264]
===
match
---
name: cls [98292,98295]
name: cls [98244,98247]
===
match
---
expr_stmt [74750,74764]
expr_stmt [74702,74716]
===
match
---
atom_expr [12234,12261]
atom_expr [12234,12261]
===
match
---
operator: , [52372,52373]
operator: , [52324,52325]
===
match
---
name: get [11103,11106]
name: get [11103,11106]
===
match
---
decorators [89582,89617]
decorators [89534,89569]
===
match
---
operator: , [85511,85512]
operator: , [85463,85464]
===
match
---
arglist [58509,58865]
arglist [58461,58817]
===
match
---
operator: = [83027,83028]
operator: = [82979,82980]
===
match
---
expr_stmt [88833,88872]
expr_stmt [88785,88824]
===
match
---
trailer [90504,90517]
trailer [90456,90469]
===
match
---
trailer [77080,77313]
trailer [77032,77265]
===
match
---
trailer [12206,12216]
trailer [12206,12216]
===
match
---
simple_stmt [29139,29151]
simple_stmt [29091,29103]
===
match
---
name: parent_group [63331,63343]
name: parent_group [63283,63295]
===
match
---
simple_stmt [12230,12262]
simple_stmt [12230,12262]
===
match
---
del_stmt [12230,12261]
del_stmt [12230,12261]
===
match
---
trailer [76291,76295]
trailer [76243,76247]
===
match
---
operator: = [16739,16740]
operator: = [16739,16740]
===
match
---
simple_stmt [85282,85357]
simple_stmt [85234,85309]
===
match
---
expr_stmt [30647,30677]
expr_stmt [30599,30629]
===
match
---
suite [38936,39025]
suite [38888,38977]
===
match
---
simple_stmt [38949,39025]
simple_stmt [38901,38977]
===
match
---
name: _upgrade_outdated_dag_access_control [30859,30895]
name: _upgrade_outdated_dag_access_control [30811,30847]
===
match
---
sync_comp_for [45598,45620]
sync_comp_for [45550,45572]
===
match
---
name: self [17134,17138]
name: self [17134,17138]
===
match
---
name: self [34638,34642]
name: self [34590,34594]
===
match
---
if_stmt [41794,41896]
if_stmt [41746,41848]
===
match
---
name: self [21409,21413]
name: self [21385,21389]
===
match
---
atom_expr [12974,12997]
atom_expr [12974,12997]
===
match
---
operator: , [84952,84953]
operator: , [84904,84905]
===
match
---
name: all [17122,17125]
name: all [17122,17125]
===
match
---
argument [85879,85895]
argument [85831,85847]
===
match
---
operator: = [28124,28125]
operator: = [28076,28077]
===
match
---
operator: = [87195,87196]
operator: = [87147,87148]
===
match
---
name: bulk_sync_to_db [74976,74991]
name: bulk_sync_to_db [74928,74943]
===
match
---
suite [65941,66063]
suite [65893,66015]
===
match
---
atom_expr [12271,12291]
atom_expr [12271,12291]
===
match
---
comparison [93373,93415]
comparison [93325,93367]
===
match
---
simple_stmt [84522,84553]
simple_stmt [84474,84505]
===
match
---
trailer [66227,66233]
trailer [66179,66185]
===
match
---
name: is_subdag [77998,78007]
name: is_subdag [77950,77959]
===
match
---
operator: = [58280,58281]
operator: = [58232,58233]
===
match
---
atom_expr [12495,12682]
atom_expr [12495,12682]
===
match
---
param [72289,72330]
param [72241,72282]
===
match
---
atom_expr [24691,24713]
atom_expr [24643,24665]
===
match
---
atom_expr [59143,59177]
atom_expr [59095,59129]
===
match
---
trailer [26775,26848]
trailer [26727,26800]
===
match
---
atom_expr [45610,45620]
atom_expr [45562,45572]
===
match
---
name: dag [79930,79933]
name: dag [79882,79885]
===
match
---
operator: = [48334,48335]
operator: = [48286,48287]
===
match
---
name: sorted [77892,77898]
name: sorted [77844,77850]
===
match
---
parameters [34327,34333]
parameters [34279,34285]
===
match
---
operator: , [47578,47579]
operator: , [47530,47531]
===
match
---
name: max_active_tasks [87547,87563]
name: max_active_tasks [87499,87515]
===
match
---
operator: , [93749,93750]
operator: , [93701,93702]
===
match
---
simple_stmt [15445,15615]
simple_stmt [15445,15615]
===
match
---
operator: = [27525,27526]
operator: = [27477,27478]
===
match
---
trailer [14223,14237]
trailer [14223,14237]
===
match
---
name: conf [86083,86087]
name: conf [86035,86039]
===
match
---
name: tags [76717,76721]
name: tags [76669,76673]
===
match
---
name: session [37725,37732]
name: session [37677,37684]
===
match
---
name: dttm [28823,28827]
name: dttm [28775,28779]
===
match
---
trailer [88080,88087]
trailer [88032,88039]
===
match
---
suite [40488,41122]
suite [40440,41074]
===
match
---
trailer [62527,62546]
trailer [62479,62498]
===
match
---
trailer [34656,34658]
trailer [34608,34610]
===
match
---
name: dag [66273,66276]
name: dag [66225,66228]
===
match
---
name: next_run_date [26980,26993]
name: next_run_date [26932,26945]
===
match
---
decorated [88942,89009]
decorated [88894,88961]
===
match
---
if_stmt [52951,53024]
if_stmt [52903,52976]
===
match
---
operator: = [10655,10656]
operator: = [10655,10656]
===
match
---
raise_stmt [73753,73821]
raise_stmt [73705,73773]
===
match
---
name: List [31921,31925]
name: List [31873,31877]
===
match
---
operator: , [88441,88442]
operator: , [88393,88394]
===
match
---
suite [65336,65634]
suite [65288,65586]
===
match
---
trailer [55949,55955]
trailer [55901,55907]
===
match
---
if_stmt [41904,42108]
if_stmt [41856,42060]
===
match
---
simple_stmt [17717,17745]
simple_stmt [17717,17745]
===
match
---
trailer [78791,78808]
trailer [78743,78760]
===
match
---
name: dttm [21997,22001]
name: dttm [21973,21977]
===
match
---
suite [38813,38918]
suite [38765,38870]
===
match
---
name: including_subdags [91078,91095]
name: including_subdags [91030,91047]
===
match
---
trailer [91224,91231]
trailer [91176,91183]
===
match
---
expr_stmt [28484,28585]
expr_stmt [28436,28537]
===
match
---
string: """         Returns a list of dates between the interval received as parameter using this         dag's schedule interval. Returned dates can be used for execution dates.          :param start_date: the start date of the interval         :type start_date: datetime         :param end_date: the end date of the interval, defaults to timezone.utcnow()         :type end_date: datetime         :return: a list of dates within the interval following the dag's schedule         :rtype: list         """ [27541,28038]
string: """         Returns a list of dates between the interval received as parameter using this         dag's schedule interval. Returned dates can be used for execution dates.          :param start_date: the start date of the interval         :type start_date: datetime         :param end_date: the end date of the interval, defaults to timezone.utcnow()         :type end_date: datetime         :return: a list of dates within the interval following the dag's schedule         :rtype: list         """ [27493,27990]
===
match
---
name: following [29120,29129]
name: following [29072,29081]
===
match
---
atom_expr [92394,92413]
atom_expr [92346,92365]
===
match
---
name: property [44668,44676]
name: property [44620,44628]
===
match
---
name: taskinstance [2116,2128]
name: taskinstance [2116,2128]
===
match
---
operator: , [51812,51813]
operator: , [51764,51765]
===
match
---
operator: = [18652,18653]
operator: = [18652,18653]
===
match
---
operator: , [40365,40366]
operator: , [40317,40318]
===
match
---
trailer [74106,74122]
trailer [74058,74074]
===
match
---
name: subdag [45400,45406]
name: subdag [45352,45358]
===
match
---
operator: , [74680,74681]
operator: , [74632,74633]
===
match
---
name: exclude_task_ids [48726,48742]
name: exclude_task_ids [48678,48694]
===
match
---
operator: { [75967,75968]
operator: { [75919,75920]
===
match
---
name: confirm_prompt [59105,59119]
name: confirm_prompt [59057,59071]
===
match
---
operator: , [69206,69207]
operator: , [69158,69159]
===
match
---
argument [71773,71800]
argument [71725,71752]
===
match
---
operator: = [64998,64999]
operator: = [64950,64951]
===
match
---
arglist [55680,55831]
arglist [55632,55783]
===
match
---
name: old_dag [98481,98488]
name: old_dag [98433,98440]
===
match
---
expr_stmt [17560,17594]
expr_stmt [17560,17594]
===
match
---
simple_stmt [21299,21342]
simple_stmt [21275,21318]
===
match
---
operator: = [86520,86521]
operator: = [86472,86473]
===
match
---
name: default [86267,86274]
name: default [86219,86226]
===
match
---
trailer [62289,62297]
trailer [62241,62249]
===
match
---
simple_stmt [58426,58439]
simple_stmt [58378,58391]
===
match
---
trailer [51534,51541]
trailer [51486,51493]
===
match
---
trailer [96229,96237]
trailer [96181,96189]
===
match
---
name: order_by [44363,44371]
name: order_by [44315,44323]
===
match
---
operator: = [29210,29211]
operator: = [29162,29163]
===
match
---
string: """Exposes a CLI specific to this DAG""" [71858,71898]
string: """Exposes a CLI specific to this DAG""" [71810,71850]
===
match
---
name: print [58002,58007]
name: print [57954,57959]
===
match
---
trailer [10840,10847]
trailer [10840,10847]
===
match
---
name: DagModel [81623,81631]
name: DagModel [81575,81583]
===
match
---
simple_stmt [75954,76001]
simple_stmt [75906,75953]
===
match
---
name: self [68168,68172]
name: self [68120,68124]
===
match
---
funcdef [19765,20267]
funcdef [19765,20267]
===
match
---
name: self [26761,26765]
name: self [26713,26717]
===
match
---
param [82126,82140]
param [82078,82092]
===
match
---
trailer [87203,87217]
trailer [87155,87169]
===
match
---
name: dag_ids [76393,76400]
name: dag_ids [76345,76352]
===
match
---
name: self [31670,31674]
name: self [31622,31626]
===
match
---
fstring_string: `run_id` expected to be a str is  [73772,73805]
fstring_string: `run_id` expected to be a str is  [73724,73757]
===
match
---
name: end_date [43526,43534]
name: end_date [43478,43486]
===
match
---
operator: = [22513,22514]
operator: = [22489,22490]
===
match
---
atom_expr [25425,25447]
atom_expr [25377,25399]
===
match
---
simple_stmt [86507,86542]
simple_stmt [86459,86494]
===
match
---
expr_stmt [55890,56923]
expr_stmt [55842,56875]
===
match
---
operator: - [65903,65904]
operator: - [65855,65856]
===
match
---
name: ti_list [59133,59140]
name: ti_list [59085,59092]
===
match
---
expr_stmt [59190,59287]
expr_stmt [59142,59239]
===
match
---
param [74992,74996]
param [74944,74948]
===
match
---
simple_stmt [66543,66560]
simple_stmt [66495,66512]
===
match
---
argument [43896,43920]
argument [43848,43872]
===
match
---
name: using_end_date [28275,28289]
name: using_end_date [28227,28241]
===
match
---
decorated [31885,31975]
decorated [31837,31927]
===
match
---
name: re [62258,62260]
name: re [62210,62212]
===
match
---
trailer [15178,15328]
trailer [15178,15328]
===
match
---
name: graph_unsorted [46811,46825]
name: graph_unsorted [46763,46777]
===
match
---
operator: = [74428,74429]
operator: = [74380,74381]
===
match
---
trailer [42991,42993]
trailer [42943,42945]
===
match
---
operator: = [27222,27223]
operator: = [27174,27175]
===
match
---
operator: , [72329,72330]
operator: , [72281,72282]
===
match
---
operator: = [69072,69073]
operator: = [69024,69025]
===
match
---
expr_stmt [94110,94201]
expr_stmt [94062,94153]
===
match
---
fstring [68310,68371]
fstring [68262,68323]
===
match
---
arglist [63794,63807]
arglist [63746,63759]
===
match
---
operator: = [71204,71205]
operator: = [71156,71157]
===
match
---
name: Optional [72386,72394]
name: Optional [72338,72346]
===
match
---
suite [77933,79595]
suite [77885,79547]
===
match
---
name: task_start_dates [25967,25983]
name: task_start_dates [25919,25935]
===
match
---
name: next_run_date [28619,28632]
name: next_run_date [28571,28584]
===
match
---
name: using_start_date [28173,28189]
name: using_start_date [28125,28141]
===
match
---
operator: = [10753,10754]
operator: = [10753,10754]
===
match
---
funcdef [17287,17354]
funcdef [17287,17354]
===
match
---
if_stmt [25964,26145]
if_stmt [25916,26097]
===
match
---
name: cron [21019,21023]
name: cron [21019,21023]
===
match
---
comparison [38877,38916]
comparison [38829,38868]
===
match
---
trailer [79525,79532]
trailer [79477,79484]
===
match
---
operator: } [75999,76000]
operator: } [75951,75952]
===
match
---
name: now [25247,25250]
name: now [25199,25202]
===
match
---
simple_stmt [62905,63057]
simple_stmt [62857,63009]
===
match
---
name: next_execution_date [23616,23635]
name: next_execution_date [23568,23587]
===
match
---
and_test [67266,67309]
and_test [67218,67261]
===
match
---
name: ti [53903,53905]
name: ti [53855,53857]
===
match
---
operator: * [60910,60911]
operator: * [60862,60863]
===
match
---
subscriptlist [22930,22986]
subscriptlist [22882,22938]
===
match
---
name: callback [36266,36274]
name: callback [36218,36226]
===
match
---
comparison [52997,53022]
comparison [52949,52974]
===
match
---
operator: = [19690,19691]
operator: = [19690,19691]
===
match
---
suite [79133,79178]
suite [79085,79130]
===
match
---
name: Dict [16116,16120]
name: Dict [16116,16120]
===
match
---
param [85045,85050]
param [84997,85002]
===
match
---
trailer [78310,78320]
trailer [78262,78272]
===
match
---
expr_stmt [98246,98280]
expr_stmt [98198,98232]
===
match
---
trailer [43564,43566]
trailer [43516,43518]
===
match
---
name: dag [64759,64762]
name: dag [64711,64714]
===
match
---
expr_stmt [19972,19992]
expr_stmt [19972,19992]
===
match
---
operator: -> [98536,98538]
operator: -> [98488,98490]
===
match
---
trailer [81056,81060]
trailer [81008,81012]
===
match
---
arglist [86099,86136]
arglist [86051,86088]
===
match
---
trailer [79672,79680]
trailer [79624,79632]
===
match
---
operator: == [40964,40966]
operator: == [40916,40918]
===
match
---
name: info [85099,85103]
name: info [85051,85055]
===
match
---
operator: = [56263,56264]
operator: = [56215,56216]
===
match
---
trailer [17695,17700]
trailer [17695,17700]
===
match
---
name: pendulum [93731,93739]
name: pendulum [93683,93691]
===
match
---
trailer [32716,32721]
trailer [32668,32673]
===
match
---
name: external_trigger [3551,3567]
name: external_trigger [3551,3567]
===
match
---
operator: = [47572,47573]
operator: = [47524,47525]
===
match
---
name: timezone [13566,13574]
name: timezone [13566,13574]
===
match
---
name: self [12331,12335]
name: self [12331,12335]
===
match
---
trailer [13026,13036]
trailer [13026,13036]
===
match
---
import_name [1597,1621]
import_name [1597,1621]
===
match
---
comp_op [76620,76626]
comp_op [76572,76578]
===
match
---
simple_stmt [87116,87147]
simple_stmt [87068,87099]
===
match
---
trailer [95711,95728]
trailer [95663,95680]
===
match
---
and_test [28601,28650]
and_test [28553,28602]
===
match
---
name: start_date [42938,42948]
name: start_date [42890,42900]
===
match
---
name: expunge_all [57185,57196]
name: expunge_all [57137,57148]
===
match
---
funcdef [31194,31267]
funcdef [31146,31219]
===
match
---
name: State [37839,37844]
name: State [37791,37796]
===
match
---
trailer [43237,43252]
trailer [43189,43204]
===
match
---
name: bool [11710,11714]
name: bool [11710,11714]
===
match
---
funcdef [40058,40451]
funcdef [40010,40403]
===
match
---
name: helpers [2484,2491]
name: helpers [2484,2491]
===
match
---
comp_if [27256,27269]
comp_if [27208,27221]
===
match
---
operator: = [63591,63592]
operator: = [63543,63544]
===
match
---
name: dag_obj [96259,96266]
name: dag_obj [96211,96218]
===
match
---
operator: = [82134,82135]
operator: = [82086,82087]
===
match
---
trailer [85869,85877]
trailer [85821,85829]
===
match
---
name: fileloc [78074,78081]
name: fileloc [78026,78033]
===
match
---
trailer [38218,38223]
trailer [38170,38175]
===
match
---
name: dag_id [29779,29785]
name: dag_id [29731,29737]
===
match
---
name: dag [67088,67091]
name: dag [67040,67043]
===
match
---
expr_stmt [65685,65709]
expr_stmt [65637,65661]
===
match
---
trailer [65034,65056]
trailer [64986,65008]
===
match
---
operator: <= [48133,48135]
operator: <= [48085,48087]
===
match
---
name: conf [69073,69077]
name: conf [69025,69029]
===
match
---
operator: - [22381,22382]
operator: - [22357,22358]
===
match
---
operator: , [74400,74401]
operator: , [74352,74353]
===
match
---
trailer [21369,21384]
trailer [21345,21360]
===
match
---
name: next_dagrun [94732,94743]
name: next_dagrun [94684,94695]
===
match
---
name: list [79061,79065]
name: list [79013,79017]
===
match
---
arglist [20775,20815]
arglist [20775,20815]
===
match
---
atom_expr [95965,95999]
atom_expr [95917,95951]
===
match
---
operator: = [11715,11716]
operator: = [11715,11716]
===
match
---
trailer [66172,66178]
trailer [66124,66130]
===
match
---
name: filter [89295,89301]
name: filter [89247,89253]
===
match
---
operator: , [91446,91447]
operator: , [91398,91399]
===
match
---
dotted_name [2185,2201]
dotted_name [2185,2201]
===
match
---
atom_expr [98569,98593]
atom_expr [98521,98545]
===
match
---
argument [95712,95717]
argument [95664,95669]
===
match
---
operator: = [79460,79461]
operator: = [79412,79413]
===
match
---
name: start_date [42962,42972]
name: start_date [42914,42924]
===
match
---
operator: @ [83442,83443]
operator: @ [83394,83395]
===
match
---
name: task_end_dates [27282,27296]
name: task_end_dates [27234,27248]
===
match
---
name: info [75914,75918]
name: info [75866,75870]
===
match
---
operator: = [68638,68639]
operator: = [68590,68591]
===
match
---
arglist [60495,60507]
arglist [60447,60459]
===
match
---
trailer [18808,18824]
trailer [18808,18824]
===
match
---
param [31208,31213]
param [31160,31165]
===
match
---
simple_stmt [12959,13014]
simple_stmt [12959,13014]
===
match
---
name: dagbag [1899,1905]
name: dagbag [1899,1905]
===
match
---
name: start_date [25688,25698]
name: start_date [25640,25650]
===
match
---
operator: , [71392,71393]
operator: , [71344,71345]
===
match
---
name: v [60303,60304]
name: v [60255,60256]
===
match
---
name: cls [79909,79912]
name: cls [79861,79864]
===
match
---
name: Column [85915,85921]
name: Column [85867,85873]
===
match
---
trailer [43595,43636]
trailer [43547,43588]
===
match
---
atom_expr [25253,25270]
atom_expr [25205,25222]
===
match
---
if_stmt [75869,75901]
if_stmt [75821,75853]
===
match
---
trailer [76200,76209]
trailer [76152,76161]
===
match
---
operator: , [23759,23760]
operator: , [23711,23712]
===
match
---
name: TaskInstance [83274,83286]
name: TaskInstance [83226,83238]
===
match
---
operator: == [24829,24831]
operator: == [24781,24783]
===
match
---
name: STORE_DAG_CODE [79616,79630]
name: STORE_DAG_CODE [79568,79582]
===
match
---
param [91417,91447]
param [91369,91399]
===
match
---
name: name [31613,31617]
name: name [31565,31569]
===
match
---
name: task_ids [82126,82134]
name: task_ids [82078,82086]
===
match
---
name: Union [1184,1189]
name: Union [1184,1189]
===
match
---
name: pendulum [1225,1233]
name: pendulum [1225,1233]
===
match
---
name: query [47915,47920]
name: query [47867,47872]
===
match
---
arglist [88657,88691]
arglist [88609,88643]
===
match
---
trailer [25928,25934]
trailer [25880,25886]
===
match
---
name: e [65939,65940]
name: e [65891,65892]
===
match
---
name: dag_id [79470,79476]
name: dag_id [79422,79428]
===
match
---
name: dag_id [77604,77610]
name: dag_id [77556,77562]
===
match
---
atom_expr [44359,44406]
atom_expr [44311,44358]
===
match
---
string: 'idx_next_dagrun_create_after' [87964,87994]
string: 'idx_next_dagrun_create_after' [87916,87946]
===
match
---
trailer [77363,77367]
trailer [77315,77319]
===
match
---
name: render_templates [54876,54892]
name: render_templates [54828,54844]
===
match
---
name: LocalExecutor [71066,71079]
name: LocalExecutor [71018,71031]
===
match
---
param [18053,18058]
param [18053,18058]
===
match
---
operator: = [47905,47906]
operator: = [47857,47858]
===
match
---
return_stmt [29511,29700]
return_stmt [29463,29652]
===
match
---
simple_stmt [63958,64007]
simple_stmt [63910,63959]
===
match
---
simple_stmt [21969,22018]
simple_stmt [21945,21994]
===
match
---
trailer [83052,83058]
trailer [83004,83010]
===
match
---
dotted_name [1563,1577]
dotted_name [1563,1577]
===
match
---
expr_stmt [2874,2907]
expr_stmt [2874,2907]
===
match
---
operator: , [19408,19409]
operator: , [19408,19409]
===
match
---
trailer [16308,16332]
trailer [16308,16332]
===
match
---
parameters [35527,35582]
parameters [35479,35534]
===
match
---
arglist [10928,10961]
arglist [10928,10961]
===
match
---
trailer [12835,12848]
trailer [12835,12848]
===
match
---
arglist [91773,91860]
arglist [91725,91812]
===
match
---
name: self [25296,25300]
name: self [25248,25252]
===
match
---
name: name [79456,79460]
name: name [79408,79412]
===
match
---
name: self [39104,39108]
name: self [39056,39060]
===
match
---
trailer [26415,26430]
trailer [26367,26382]
===
match
---
name: session [48563,48570]
name: session [48515,48522]
===
match
---
name: RePatternType [2287,2300]
name: RePatternType [2287,2300]
===
match
---
trailer [16384,16408]
trailer [16384,16408]
===
match
---
simple_stmt [81999,82018]
simple_stmt [81951,81970]
===
match
---
arglist [60910,60925]
arglist [60862,60877]
===
match
---
name: orm_tag_names [79264,79277]
name: orm_tag_names [79216,79229]
===
match
---
name: AirflowException [67329,67345]
name: AirflowException [67281,67297]
===
match
---
operator: = [3430,3431]
operator: = [3430,3431]
===
match
---
trailer [79933,79941]
trailer [79885,79893]
===
match
---
name: get_dagrun [38122,38132]
name: get_dagrun [38074,38084]
===
match
---
atom_expr [73806,73818]
atom_expr [73758,73770]
===
match
---
name: jinja_env_options [41981,41998]
name: jinja_env_options [41933,41950]
===
match
---
name: callback [36737,36745]
name: callback [36689,36697]
===
match
---
atom [97939,97941]
atom [97891,97893]
===
match
---
operator: , [33276,33277]
operator: , [33228,33229]
===
match
---
name: DagParam [31316,31324]
name: DagParam [31268,31276]
===
match
---
name: result [60522,60528]
name: result [60474,60480]
===
match
---
operator: = [65829,65830]
operator: = [65781,65782]
===
match
---
name: datetime [21033,21041]
name: datetime [21033,21041]
===
match
---
tfpdef [92628,92644]
tfpdef [92580,92596]
===
match
---
name: dag_parser [71982,71992]
name: dag_parser [71934,71944]
===
match
---
and_test [51615,51683]
and_test [51567,51635]
===
match
---
name: dag [81588,81591]
name: dag [81540,81543]
===
match
---
name: read_dags_from_db [55343,55360]
name: read_dags_from_db [55295,55312]
===
match
---
name: get_latest_execution_date [40423,40448]
name: get_latest_execution_date [40375,40400]
===
match
---
trailer [94397,94611]
trailer [94349,94563]
===
match
---
trailer [22751,22766]
trailer [22703,22718]
===
match
---
operator: * [51446,51447]
operator: * [51398,51399]
===
match
---
operator: , [9950,9951]
operator: , [9950,9951]
===
match
---
name: permissions [18797,18808]
name: permissions [18797,18808]
===
match
---
trailer [67274,67285]
trailer [67226,67237]
===
match
---
arglist [33213,33277]
arglist [33165,33229]
===
match
---
name: dag [78654,78657]
name: dag [78606,78609]
===
match
---
operator: , [66741,66742]
operator: , [66693,66694]
===
match
---
trailer [58007,58042]
trailer [57959,57994]
===
match
---
atom_expr [46752,46770]
atom_expr [46704,46722]
===
match
---
string: 'is_picklable' [65986,66000]
string: 'is_picklable' [65938,65952]
===
match
---
operator: = [19318,19319]
operator: = [19318,19319]
===
match
---
operator: , [62179,62180]
operator: , [62131,62132]
===
match
---
trailer [64657,64677]
trailer [64609,64629]
===
match
---
atom_expr [62032,62046]
atom_expr [61984,61998]
===
match
---
dotted_name [70890,70915]
dotted_name [70842,70867]
===
match
---
name: in_ [83396,83399]
name: in_ [83348,83351]
===
match
---
name: self [65359,65363]
name: self [65311,65315]
===
match
---
fstring_string: <DAG:  [16893,16899]
fstring_string: <DAG:  [16893,16899]
===
match
---
if_stmt [12400,12726]
if_stmt [12400,12726]
===
match
---
name: DagModel [85669,85677]
name: DagModel [85621,85629]
===
match
---
suite [72530,74929]
suite [72482,74881]
===
match
---
operator: = [31306,31307]
operator: = [31258,31259]
===
match
---
atom_expr [14024,14059]
atom_expr [14024,14059]
===
match
---
operator: = [83191,83192]
operator: = [83143,83144]
===
match
---
name: self [31912,31916]
name: self [31864,31868]
===
match
---
name: func [1444,1448]
name: func [1444,1448]
===
match
---
atom_expr [26731,26746]
atom_expr [26683,26698]
===
match
---
atom_expr [37839,37852]
atom_expr [37791,37804]
===
match
---
decorator [75380,75397]
decorator [75332,75349]
===
match
---
trailer [65757,65759]
trailer [65709,65711]
===
match
---
name: get [90526,90529]
name: get [90478,90481]
===
match
---
number: 0 [59092,59093]
number: 0 [59044,59045]
===
match
---
name: self [65954,65958]
name: self [65906,65910]
===
match
---
operator: = [62095,62096]
operator: = [62047,62048]
===
match
---
trailer [62268,62298]
trailer [62220,62250]
===
match
---
atom_expr [13022,13036]
atom_expr [13022,13036]
===
match
---
name: user_defined_macros [42301,42320]
name: user_defined_macros [42253,42272]
===
match
---
and_test [13711,13776]
and_test [13711,13776]
===
match
---
name: warnings [34441,34449]
name: warnings [34393,34401]
===
match
---
trailer [77610,77614]
trailer [77562,77566]
===
match
---
name: validate_key [12271,12283]
name: validate_key [12271,12283]
===
match
---
trailer [55646,55861]
trailer [55598,55813]
===
match
---
name: paused_dag_ids [90200,90214]
name: paused_dag_ids [90152,90166]
===
match
---
comparison [40949,40983]
comparison [40901,40935]
===
match
---
trailer [22302,22311]
trailer [22278,22287]
===
match
---
operator: , [38230,38231]
operator: , [38182,38183]
===
match
---
tfpdef [11622,11662]
tfpdef [11622,11662]
===
match
---
name: in_ [43301,43304]
name: in_ [43253,43256]
===
match
---
trailer [56007,56022]
trailer [55959,55974]
===
match
---
suite [96139,96931]
suite [96091,96883]
===
match
---
name: including_subdags [90731,90748]
name: including_subdags [90683,90700]
===
match
---
name: pendulum [22895,22903]
name: pendulum [22847,22855]
===
match
---
operator: = [25544,25545]
operator: = [25496,25497]
===
match
---
comparison [89302,89322]
comparison [89254,89274]
===
match
---
suite [90254,90571]
suite [90206,90523]
===
match
---
name: update [42346,42352]
name: update [42298,42304]
===
match
---
expr_stmt [20001,20056]
expr_stmt [20001,20056]
===
match
---
name: getLogger [2888,2897]
name: getLogger [2888,2897]
===
match
---
trailer [78953,78965]
trailer [78905,78917]
===
match
---
name: _context_managed_dag [98024,98044]
name: _context_managed_dag [97976,97996]
===
match
---
name: ti [54873,54875]
name: ti [54825,54827]
===
match
---
name: end_date [10373,10381]
name: end_date [10373,10381]
===
match
---
name: jinja2 [10561,10567]
name: jinja2 [10561,10567]
===
match
---
name: dag [82013,82016]
name: dag [81965,81968]
===
match
---
simple_stmt [32185,32249]
simple_stmt [32137,32201]
===
match
---
fstring_string: Task id ' [68312,68321]
fstring_string: Task id ' [68264,68273]
===
match
---
simple_stmt [53488,53517]
simple_stmt [53440,53469]
===
match
---
expr_stmt [64343,64434]
expr_stmt [64295,64386]
===
match
---
name: self [48264,48268]
name: self [48216,48220]
===
match
---
trailer [95989,95999]
trailer [95941,95951]
===
match
---
trailer [30955,30960]
trailer [30907,30912]
===
match
---
simple_stmt [46944,46959]
simple_stmt [46896,46911]
===
match
---
trailer [76810,76819]
trailer [76762,76771]
===
match
---
decorator [18201,18215]
decorator [18201,18215]
===
match
---
name: start [20209,20214]
name: start [20209,20214]
===
match
---
exprlist [90151,90165]
exprlist [90103,90117]
===
match
---
import_from [97185,97245]
import_from [97137,97197]
===
match
---
name: include_subdags [52229,52244]
name: include_subdags [52181,52196]
===
match
---
operator: , [85324,85325]
operator: , [85276,85277]
===
match
---
name: len [45712,45715]
name: len [45664,45667]
===
match
---
name: SandboxedEnvironment [42050,42070]
name: SandboxedEnvironment [42002,42022]
===
match
---
arglist [26095,26143]
arglist [26047,26095]
===
match
---
if_stmt [62575,62754]
if_stmt [62527,62706]
===
match
---
operator: , [3171,3172]
operator: , [3171,3172]
===
match
---
atom_expr [96788,96811]
atom_expr [96740,96763]
===
match
---
suite [58932,58960]
suite [58884,58912]
===
match
---
name: bool [32975,32979]
name: bool [32927,32931]
===
match
---
name: TI [52793,52795]
name: TI [52745,52747]
===
match
---
operator: = [22035,22036]
operator: = [22011,22012]
===
match
---
name: _previous_context_managed_dags [98296,98326]
name: _previous_context_managed_dags [98248,98278]
===
match
---
simple_stmt [47683,47848]
simple_stmt [47635,47800]
===
match
---
tfpdef [95093,95104]
tfpdef [95045,95056]
===
match
---
operator: @ [30683,30684]
operator: @ [30635,30636]
===
match
---
name: classmethod [74935,74946]
name: classmethod [74887,74898]
===
match
---
atom_expr [51955,52642]
atom_expr [51907,52594]
===
match
---
trailer [76254,76291]
trailer [76206,76243]
===
match
---
arith_expr [65885,65909]
arith_expr [65837,65861]
===
match
---
name: Dict [1091,1095]
name: Dict [1091,1095]
===
match
---
trailer [43608,43623]
trailer [43560,43575]
===
match
---
arith_expr [54305,54324]
arith_expr [54257,54276]
===
match
---
name: start_date [72242,72252]
name: start_date [72194,72204]
===
match
---
name: dag_id [29724,29730]
name: dag_id [29676,29682]
===
match
---
name: task_id [62937,62944]
name: task_id [62889,62896]
===
match
---
operator: , [60837,60838]
operator: , [60789,60790]
===
match
---
operator: = [89253,89254]
operator: = [89205,89206]
===
match
---
name: DagModel [91025,91033]
name: DagModel [90977,90985]
===
match
---
name: sub_dag [60577,60584]
name: sub_dag [60529,60536]
===
match
---
comp_if [44635,44660]
comp_if [44587,44612]
===
match
---
name: dag [58451,58454]
name: dag [58403,58406]
===
match
---
argument [52311,52338]
argument [52263,52290]
===
match
---
operator: = [48481,48482]
operator: = [48433,48434]
===
match
---
trailer [13592,13601]
trailer [13592,13601]
===
match
---
operator: = [80644,80645]
operator: = [80596,80597]
===
match
---
name: DagModel [90047,90055]
name: DagModel [89999,90007]
===
match
---
arglist [74355,74681]
arglist [74307,74633]
===
match
---
atom_expr [64476,64542]
atom_expr [64428,64494]
===
match
---
for_stmt [77877,79595]
for_stmt [77829,79547]
===
match
---
operator: ** [95312,95314]
operator: ** [95264,95266]
===
match
---
string: 'template_searchpath' [84096,84117]
string: 'template_searchpath' [84048,84069]
===
match
---
dotted_name [67017,67035]
dotted_name [66969,66987]
===
match
---
decorated [89582,90215]
decorated [89534,90167]
===
match
---
expr_stmt [53537,53560]
expr_stmt [53489,53512]
===
match
---
simple_stmt [80962,80969]
simple_stmt [80914,80921]
===
match
---
atom_expr [43717,43756]
atom_expr [43669,43708]
===
match
---
operator: = [87657,87658]
operator: = [87609,87610]
===
match
---
simple_stmt [12734,12776]
simple_stmt [12734,12776]
===
match
---
name: only_running [58637,58649]
name: only_running [58589,58601]
===
match
---
operator: , [10802,10803]
operator: , [10802,10803]
===
match
---
name: confirm_prompt [48404,48418]
name: confirm_prompt [48356,48370]
===
match
---
name: only_running [59577,59589]
name: only_running [59529,59541]
===
match
---
trailer [21319,21330]
trailer [21295,21306]
===
match
---
atom_expr [23779,23801]
atom_expr [23731,23753]
===
match
---
name: self [65269,65273]
name: self [65221,65225]
===
match
---
operator: = [48096,48097]
operator: = [48048,48049]
===
match
---
name: end_date [48326,48334]
name: end_date [48278,48286]
===
match
---
name: end_date [59480,59488]
name: end_date [59432,59440]
===
match
---
name: DagModel [81698,81706]
name: DagModel [81650,81658]
===
match
---
funcdef [90690,91341]
funcdef [90642,91293]
===
match
---
operator: = [26015,26016]
operator: = [25967,25968]
===
match
---
operator: , [69027,69028]
operator: , [68979,68980]
===
match
---
trailer [87357,87361]
trailer [87309,87313]
===
match
---
name: description [10208,10219]
name: description [10208,10219]
===
match
---
operator: @ [30375,30376]
operator: @ [30327,30328]
===
match
---
argument [87649,87663]
argument [87601,87615]
===
match
---
name: filter [38963,38969]
name: filter [38915,38921]
===
match
---
name: next_dagrun [94115,94126]
name: next_dagrun [94067,94078]
===
match
---
atom_expr [53382,53409]
atom_expr [53334,53361]
===
match
---
atom_expr [22924,22987]
atom_expr [22876,22939]
===
match
---
atom_expr [55001,55021]
atom_expr [54953,54973]
===
match
---
name: session [39840,39847]
name: session [39792,39799]
===
match
---
simple_stmt [60270,60313]
simple_stmt [60222,60265]
===
match
---
atom_expr [12301,12313]
atom_expr [12301,12313]
===
match
---
name: query [3527,3532]
name: query [3527,3532]
===
match
---
operator: * [95301,95302]
operator: * [95253,95254]
===
match
---
name: timezone [14811,14819]
name: timezone [14811,14819]
===
match
---
name: template_searchpath [14632,14651]
name: template_searchpath [14632,14651]
===
match
---
return_stmt [29753,29772]
return_stmt [29705,29724]
===
match
---
name: self [65394,65398]
name: self [65346,65350]
===
match
---
name: default_args [14414,14426]
name: default_args [14414,14426]
===
match
---
trailer [91157,91164]
trailer [91109,91116]
===
match
---
name: t [41202,41203]
name: t [41154,41155]
===
match
---
name: query [43137,43142]
name: query [43089,43094]
===
match
---
atom_expr [46795,46807]
atom_expr [46747,46759]
===
match
---
import_as_name [2382,2412]
import_as_name [2382,2412]
===
match
---
decorated [38097,39054]
decorated [38049,39006]
===
match
---
trailer [13405,13411]
trailer [13405,13411]
===
match
---
trailer [48103,48110]
trailer [48055,48062]
===
match
---
expr_stmt [76307,76366]
expr_stmt [76259,76318]
===
match
---
if_stmt [43889,44255]
if_stmt [43841,44207]
===
match
---
decorator [37292,37309]
decorator [37244,37261]
===
match
---
suite [51176,51460]
suite [51128,51412]
===
match
---
name: warn [34450,34454]
name: warn [34402,34406]
===
match
---
trailer [55145,55151]
trailer [55097,55103]
===
match
---
name: dagparam [1983,1991]
name: dagparam [1983,1991]
===
match
---
name: group_by [77815,77823]
name: group_by [77767,77775]
===
match
---
param [31783,31786]
param [31735,31738]
===
match
---
name: dag [65150,65153]
name: dag [65102,65105]
===
match
---
or_test [23366,23488]
or_test [23318,23440]
===
match
---
name: filter [38840,38846]
name: filter [38792,38798]
===
match
---
name: tags [16791,16795]
name: tags [16791,16795]
===
match
---
fstring_expr [88921,88934]
fstring_expr [88873,88886]
===
match
---
name: str [10195,10198]
name: str [10195,10198]
===
match
---
trailer [11973,11982]
trailer [11973,11982]
===
match
---
name: do_it [59300,59305]
name: do_it [59252,59257]
===
match
---
operator: , [11216,11217]
operator: , [11216,11217]
===
match
---
simple_stmt [21011,21051]
simple_stmt [21011,21051]
===
match
---
atom [16143,16145]
atom [16143,16145]
===
match
---
trailer [32280,32288]
trailer [32232,32240]
===
match
---
name: conf [11098,11102]
name: conf [11098,11102]
===
match
---
name: self [16704,16708]
name: self [16704,16708]
===
match
---
return_stmt [23747,23766]
return_stmt [23699,23718]
===
match
---
expr_stmt [35194,35255]
expr_stmt [35146,35207]
===
match
---
trailer [21413,21442]
trailer [21389,21418]
===
match
---
funcdef [21546,22809]
funcdef [21522,22761]
===
match
---
name: filter [83370,83376]
name: filter [83322,83328]
===
match
---
atom_expr [18935,18963]
atom_expr [18935,18963]
===
match
---
trailer [77547,77553]
trailer [77499,77505]
===
match
---
name: DagRun [77824,77830]
name: DagRun [77776,77782]
===
match
---
name: upstream_task_id [42525,42541]
name: upstream_task_id [42477,42493]
===
match
---
suite [75881,75901]
suite [75833,75853]
===
match
---
name: t [41173,41174]
name: t [41125,41126]
===
match
---
name: rerun_failed_tasks [71722,71740]
name: rerun_failed_tasks [71674,71692]
===
match
---
trailer [15392,15404]
trailer [15392,15404]
===
match
---
string: 'scheduler' [88088,88099]
string: 'scheduler' [88040,88051]
===
match
---
decorator [90576,90586]
decorator [90528,90538]
===
match
---
arglist [22600,22609]
arglist [22552,22561]
===
match
---
name: x [43896,43897]
name: x [43848,43849]
===
match
---
name: kwargs [60919,60925]
name: kwargs [60871,60877]
===
match
---
trailer [12238,12251]
trailer [12238,12251]
===
match
---
name: last_parsed_time [81662,81678]
name: last_parsed_time [81614,81630]
===
match
---
import_from [1879,1919]
import_from [1879,1919]
===
match
---
parameters [40083,40089]
parameters [40035,40041]
===
match
---
parameters [65171,65191]
parameters [65123,65143]
===
match
---
trailer [13190,13197]
trailer [13190,13197]
===
match
---
atom_expr [34218,34233]
atom_expr [34170,34185]
===
match
---
trailer [59841,59876]
trailer [59793,59828]
===
match
---
name: sqlalchemy [1367,1377]
name: sqlalchemy [1367,1377]
===
match
---
name: query [3595,3600]
name: query [3595,3600]
===
match
---
simple_stmt [92570,92576]
simple_stmt [92522,92528]
===
match
---
atom_expr [57384,57392]
atom_expr [57336,57344]
===
match
---
parameters [44691,44697]
parameters [44643,44649]
===
match
---
argument [29311,29326]
argument [29263,29278]
===
match
---
trailer [11599,11605]
trailer [11599,11605]
===
match
---
parameters [30512,30518]
parameters [30464,30470]
===
match
---
name: filter [43157,43163]
name: filter [43109,43115]
===
match
---
atom_expr [78066,78081]
atom_expr [78018,78033]
===
match
---
name: tis [44353,44356]
name: tis [44305,44308]
===
match
---
name: stacklevel [19308,19318]
name: stacklevel [19308,19318]
===
match
---
funcdef [17359,17869]
funcdef [17359,17869]
===
match
---
operator: = [52552,52553]
operator: = [52504,52505]
===
match
---
funcdef [18219,19375]
funcdef [18219,19375]
===
match
---
operator: = [31631,31632]
operator: = [31583,31584]
===
match
---
import_name [866,876]
import_name [866,876]
===
match
---
atom [36684,36702]
atom [36636,36654]
===
match
---
atom [62181,62201]
atom [62133,62153]
===
match
---
name: cls [89233,89236]
name: cls [89185,89188]
===
match
---
name: Base [85372,85376]
name: Base [85324,85328]
===
match
---
name: self [51637,51641]
name: self [51589,51593]
===
match
---
name: dag_id [76779,76785]
name: dag_id [76731,76737]
===
match
---
name: k [60178,60179]
name: k [60130,60131]
===
match
---
string: 'start_date' [14282,14294]
string: 'start_date' [14282,14294]
===
match
---
name: default [31299,31306]
name: default [31251,31258]
===
match
---
name: task_id [65348,65355]
name: task_id [65300,65307]
===
match
---
trailer [86360,86384]
trailer [86312,86336]
===
match
---
name: is_active [92404,92413]
name: is_active [92356,92365]
===
match
---
suite [66647,66969]
suite [66599,66921]
===
match
---
trailer [13929,13942]
trailer [13929,13942]
===
match
---
atom_expr [21200,21223]
atom_expr [21200,21223]
===
match
---
atom_expr [14353,14382]
atom_expr [14353,14382]
===
match
---
name: dag [78830,78833]
name: dag [78782,78785]
===
match
---
name: visited_external_tis [52582,52602]
name: visited_external_tis [52534,52554]
===
match
---
trailer [20779,20808]
trailer [20779,20808]
===
match
---
param [93701,93750]
param [93653,93702]
===
match
---
atom_expr [96917,96930]
atom_expr [96869,96882]
===
match
---
operator: -> [29907,29909]
operator: -> [29859,29861]
===
match
---
simple_stmt [2301,2336]
simple_stmt [2301,2336]
===
match
---
name: normalized_schedule_interval [20780,20808]
name: normalized_schedule_interval [20780,20808]
===
match
---
atom_expr [60464,60475]
atom_expr [60416,60427]
===
match
---
funcdef [47426,48219]
funcdef [47378,48171]
===
match
---
name: args [96097,96101]
name: args [96049,96053]
===
match
---
atom_expr [77336,77349]
atom_expr [77288,77301]
===
match
---
decorator [34300,34310]
decorator [34252,34262]
===
match
---
trailer [77154,77298]
trailer [77106,77250]
===
match
---
atom_expr [21977,22017]
atom_expr [21953,21993]
===
match
---
trailer [41801,41826]
trailer [41753,41778]
===
match
---
name: timezone [19514,19522]
name: timezone [19514,19522]
===
match
---
atom_expr [3655,3668]
atom_expr [3655,3668]
===
match
---
operator: = [44301,44302]
operator: = [44253,44254]
===
match
---
name: DagStateChangeCallback [11332,11354]
name: DagStateChangeCallback [11332,11354]
===
match
---
expr_stmt [12959,13013]
expr_stmt [12959,13013]
===
match
---
classdef [97312,98594]
classdef [97264,98546]
===
match
---
simple_stmt [30970,30995]
simple_stmt [30922,30947]
===
match
---
name: tasks [25929,25934]
name: tasks [25881,25886]
===
match
---
name: following [21067,21076]
name: following [21067,21076]
===
match
---
parameters [60950,61144]
parameters [60902,61096]
===
match
---
parameters [44927,44969]
parameters [44879,44921]
===
match
---
trailer [94516,94523]
trailer [94468,94475]
===
match
---
trailer [90018,90023]
trailer [89970,89975]
===
match
---
atom_expr [39623,39644]
atom_expr [39575,39596]
===
match
---
operator: = [2986,2987]
operator: = [2986,2987]
===
match
---
expr_stmt [17629,17657]
expr_stmt [17629,17657]
===
match
---
param [10893,10963]
param [10893,10963]
===
match
---
operator: , [975,976]
operator: , [975,976]
===
match
---
simple_stmt [88551,88587]
simple_stmt [88503,88539]
===
match
---
name: primary_key [85879,85890]
name: primary_key [85831,85842]
===
match
---
name: doc_md [16471,16477]
name: doc_md [16471,16477]
===
match
---
trailer [64375,64394]
trailer [64327,64346]
===
match
---
simple_stmt [42727,42809]
simple_stmt [42679,42761]
===
match
---
operator: = [48711,48712]
operator: = [48663,48664]
===
match
---
name: executor [71099,71107]
name: executor [71051,71059]
===
match
---
simple_stmt [1622,1658]
simple_stmt [1622,1658]
===
match
---
return_stmt [44599,44661]
return_stmt [44551,44613]
===
match
---
name: session [80007,80014]
name: session [79959,79966]
===
match
---
trailer [31594,31640]
trailer [31546,31592]
===
match
---
operator: , [43337,43338]
operator: , [43289,43290]
===
match
---
operator: , [44932,44933]
operator: , [44884,44885]
===
match
---
trailer [64481,64502]
trailer [64433,64454]
===
match
---
operator: , [52523,52524]
operator: , [52475,52476]
===
match
---
name: not_none_states [83256,83271]
name: not_none_states [83208,83223]
===
match
---
name: ti_list [57699,57706]
name: ti_list [57651,57658]
===
match
---
simple_stmt [11892,11941]
simple_stmt [11892,11941]
===
match
---
simple_stmt [3408,3420]
simple_stmt [3408,3420]
===
match
---
atom_expr [35109,35131]
atom_expr [35061,35083]
===
match
---
operator: = [14962,14963]
operator: = [14962,14963]
===
match
---
operator: = [2926,2927]
operator: = [2926,2927]
===
match
---
operator: } [19017,19018]
operator: } [19017,19018]
===
match
---
decorated [44431,44662]
decorated [44383,44614]
===
match
---
atom_expr [22886,22913]
atom_expr [22838,22865]
===
match
---
name: Column [86872,86878]
name: Column [86824,86830]
===
match
---
name: filter [39553,39559]
name: filter [39505,39511]
===
match
---
argument [85593,85609]
argument [85545,85561]
===
match
---
atom_expr [3117,3142]
atom_expr [3117,3142]
===
match
---
trailer [79929,79959]
trailer [79881,79911]
===
match
---
simple_stmt [16487,16567]
simple_stmt [16487,16567]
===
match
---
simple_stmt [25683,25711]
simple_stmt [25635,25663]
===
match
---
comp_if [62365,62398]
comp_if [62317,62350]
===
match
---
atom_expr [63593,63621]
atom_expr [63545,63573]
===
match
---
comparison [45712,45732]
comparison [45664,45684]
===
match
---
name: external_dag [55395,55407]
name: external_dag [55347,55359]
===
match
---
name: dag [79669,79672]
name: dag [79621,79624]
===
match
---
name: self [60960,60964]
name: self [60912,60916]
===
match
---
operator: += [66820,66822]
operator: += [66772,66774]
===
match
---
suite [30020,30057]
suite [29972,30009]
===
match
---
name: start_date [71312,71322]
name: start_date [71264,71274]
===
match
---
name: bool [90750,90754]
name: bool [90702,90706]
===
match
---
name: Optional [47553,47561]
name: Optional [47505,47513]
===
match
---
name: orm_dags [79692,79700]
name: orm_dags [79644,79652]
===
match
---
argument [57686,57697]
argument [57638,57649]
===
match
---
atom_expr [85500,85511]
atom_expr [85452,85463]
===
match
---
atom_expr [51131,51148]
atom_expr [51083,51100]
===
match
---
name: end_date [42881,42889]
name: end_date [42833,42841]
===
match
---
parameters [98214,98219]
parameters [98166,98171]
===
match
---
tfpdef [47588,47616]
tfpdef [47540,47568]
===
match
---
operator: = [76667,76668]
operator: = [76619,76620]
===
match
---
simple_stmt [11949,12003]
simple_stmt [11949,12003]
===
match
---
atom_expr [51572,51601]
atom_expr [51524,51553]
===
match
---
atom_expr [68289,68372]
atom_expr [68241,68324]
===
match
---
atom_expr [66196,66211]
atom_expr [66148,66163]
===
match
---
simple_stmt [81965,81987]
simple_stmt [81917,81939]
===
match
---
name: DagTag [79449,79455]
name: DagTag [79401,79407]
===
match
---
name: self [29197,29201]
name: self [29149,29153]
===
match
---
name: intersection [64605,64617]
name: intersection [64557,64569]
===
match
---
trailer [48753,48758]
trailer [48705,48710]
===
match
---
argument [51753,51812]
argument [51705,51764]
===
match
---
for_stmt [76439,76857]
for_stmt [76391,76809]
===
match
---
name: set_edge_info [85031,85044]
name: set_edge_info [84983,84996]
===
match
---
atom [90132,90184]
atom [90084,90136]
===
match
---
suite [31135,31167]
suite [31087,31119]
===
match
---
simple_stmt [36669,36704]
simple_stmt [36621,36656]
===
match
---
name: min [68073,68076]
name: min [68025,68028]
===
match
---
name: question [57760,57768]
name: question [57712,57720]
===
match
---
simple_stmt [60062,60088]
simple_stmt [60014,60040]
===
match
---
name: task_dict [68154,68163]
name: task_dict [68106,68115]
===
match
---
dotted_name [1786,1805]
dotted_name [1786,1805]
===
match
---
suite [98045,98126]
suite [97997,98078]
===
match
---
name: self [38987,38991]
name: self [38939,38943]
===
match
---
name: self [14792,14796]
name: self [14792,14796]
===
match
---
testlist_comp [62233,62298]
testlist_comp [62185,62250]
===
match
---
name: env [42334,42337]
name: env [42286,42289]
===
match
---
atom_expr [10338,10356]
atom_expr [10338,10356]
===
match
---
name: List [91437,91441]
name: List [91389,91393]
===
match
---
operator: = [52283,52284]
operator: = [52235,52236]
===
match
---
trailer [63509,63517]
trailer [63461,63469]
===
match
---
fstring [73770,73820]
fstring [73722,73772]
===
match
---
operator: , [48366,48367]
operator: , [48318,48319]
===
match
---
operator: , [2787,2788]
operator: , [2787,2788]
===
match
---
arglist [88357,88516]
arglist [88309,88468]
===
match
---
expr_stmt [78430,78454]
expr_stmt [78382,78406]
===
match
---
name: TI [53074,53076]
name: TI [53026,53028]
===
match
---
trailer [92066,92074]
trailer [92018,92026]
===
match
---
funcdef [41234,42495]
funcdef [41186,42447]
===
match
---
name: filter [53067,53073]
name: filter [53019,53025]
===
match
---
arglist [57839,57939]
arglist [57791,57891]
===
match
---
name: classmethod [89180,89191]
name: classmethod [89132,89143]
===
match
---
name: dag_run_state [57911,57924]
name: dag_run_state [57863,57876]
===
match
---
expr_stmt [57081,57143]
expr_stmt [57033,57095]
===
match
---
operator: , [74478,74479]
operator: , [74430,74431]
===
match
---
name: _pickle_id [31248,31258]
name: _pickle_id [31200,31210]
===
match
---
name: t [43306,43307]
name: t [43258,43259]
===
match
---
param [35556,35568]
param [35508,35520]
===
match
---
name: log [26085,26088]
name: log [26037,26040]
===
match
---
if_stmt [40756,41096]
if_stmt [40708,41048]
===
match
---
funcdef [30399,30473]
funcdef [30351,30425]
===
match
---
decorator [34664,34674]
decorator [34616,34626]
===
match
---
name: State [47485,47490]
name: State [47437,47442]
===
match
---
trailer [64959,64961]
trailer [64911,64913]
===
match
---
operator: = [14472,14473]
operator: = [14472,14473]
===
match
---
name: task [55152,55156]
name: task [55104,55108]
===
match
---
trailer [41638,41650]
trailer [41590,41602]
===
match
---
trailer [22681,22710]
trailer [22633,22662]
===
match
---
name: next_execution_date [23943,23962]
name: next_execution_date [23895,23914]
===
match
---
operator: , [10080,10081]
operator: , [10080,10081]
===
match
---
name: following_schedule [26192,26210]
name: following_schedule [26144,26162]
===
match
---
atom_expr [47164,47240]
atom_expr [47116,47192]
===
match
---
operator: , [90712,90713]
operator: , [90664,90665]
===
match
---
operator: = [66130,66131]
operator: = [66082,66083]
===
match
---
simple_stmt [31940,31975]
simple_stmt [31892,31927]
===
match
---
suite [51473,51603]
suite [51425,51555]
===
match
---
expr_stmt [53488,53516]
expr_stmt [53440,53468]
===
match
---
trailer [92546,92555]
trailer [92498,92507]
===
match
---
expr_stmt [68447,68462]
expr_stmt [68399,68414]
===
match
---
simple_stmt [83187,83326]
simple_stmt [83139,83278]
===
match
---
operator: { [16899,16900]
operator: { [16899,16900]
===
match
---
name: get_latest_execution_date [39808,39833]
name: get_latest_execution_date [39760,39785]
===
match
---
atom_expr [87204,87216]
atom_expr [87156,87168]
===
match
---
name: include_direct_upstream [62681,62704]
name: include_direct_upstream [62633,62656]
===
match
---
operator: = [18274,18275]
operator: = [18274,18275]
===
match
---
name: now [25320,25323]
name: now [25272,25275]
===
match
---
operator: , [93699,93700]
operator: , [93651,93652]
===
match
---
name: dag [66159,66162]
name: dag [66111,66114]
===
match
---
operator: >= [33316,33318]
operator: >= [33268,33270]
===
match
---
operator: @ [34025,34026]
operator: @ [33977,33978]
===
match
---
name: DagRunType [73857,73867]
name: DagRunType [73809,73819]
===
match
---
trailer [10391,10401]
trailer [10391,10401]
===
match
---
name: normalized_schedule_interval [20487,20515]
name: normalized_schedule_interval [20487,20515]
===
match
---
atom [41591,41785]
atom [41543,41737]
===
match
---
fstring_string: , but get  [15576,15586]
fstring_string: , but get  [15576,15586]
===
match
---
param [48349,48367]
param [48301,48319]
===
match
---
operator: = [86249,86250]
operator: = [86201,86202]
===
match
---
name: partial [15748,15755]
name: partial [15748,15755]
===
match
---
name: list [31947,31951]
name: list [31899,31903]
===
match
---
name: expression [90008,90018]
name: expression [89960,89970]
===
match
---
name: TaskInstance [43728,43740]
name: TaskInstance [43680,43692]
===
match
---
atom [79668,79701]
atom [79620,79653]
===
match
---
trailer [47212,47239]
trailer [47164,47191]
===
match
---
name: orm_dags [76357,76365]
name: orm_dags [76309,76317]
===
match
---
trailer [43557,43564]
trailer [43509,43516]
===
match
---
name: dag_id [66220,66226]
name: dag_id [66172,66178]
===
match
---
simple_stmt [78524,78564]
simple_stmt [78476,78516]
===
match
---
operator: , [28821,28822]
operator: , [28773,28774]
===
match
---
operator: , [83795,83796]
operator: , [83747,83748]
===
match
---
if_stmt [41428,41508]
if_stmt [41380,41460]
===
match
---
atom_expr [14792,14808]
atom_expr [14792,14808]
===
match
---
atom_expr [36882,36919]
atom_expr [36834,36871]
===
match
---
decorated [97947,98165]
decorated [97899,98117]
===
match
---
operator: , [90541,90542]
operator: , [90493,90494]
===
match
---
name: dag_id [77343,77349]
name: dag_id [77295,77301]
===
match
---
atom_expr [22968,22985]
atom_expr [22920,22937]
===
match
---
name: isinstance [47106,47116]
name: isinstance [47058,47068]
===
match
---
name: of [76262,76264]
name: of [76214,76216]
===
match
---
trailer [55706,55714]
trailer [55658,55666]
===
match
---
name: self [15654,15658]
name: self [15654,15658]
===
match
---
trailer [51441,51459]
trailer [51393,51411]
===
match
---
arglist [77098,77299]
arglist [77050,77251]
===
match
---
expr_stmt [85847,85896]
expr_stmt [85799,85848]
===
match
---
name: ti_key [56973,56979]
name: ti_key [56925,56931]
===
match
---
and_test [32830,32897]
and_test [32782,32849]
===
match
---
simple_stmt [19972,19993]
simple_stmt [19972,19993]
===
match
---
name: next_execution_date [23905,23924]
name: next_execution_date [23857,23876]
===
match
---
arglist [60278,60311]
arglist [60230,60263]
===
match
---
argument [51446,51457]
argument [51398,51409]
===
match
---
term [66772,66787]
term [66724,66739]
===
match
---
trailer [47691,47696]
trailer [47643,47648]
===
match
---
expr_stmt [55326,55366]
expr_stmt [55278,55318]
===
match
---
name: tis [57101,57104]
name: tis [57053,57056]
===
match
---
if_stmt [24987,25773]
if_stmt [24939,25725]
===
match
---
comparison [29058,29099]
comparison [29010,29051]
===
match
---
trailer [55631,55646]
trailer [55583,55598]
===
match
---
operator: , [19290,19291]
operator: , [19290,19291]
===
match
---
decorator [58095,58108]
decorator [58047,58060]
===
match
---
simple_stmt [13164,13198]
simple_stmt [13164,13198]
===
match
---
operator: , [58256,58257]
operator: , [58208,58209]
===
match
---
simple_stmt [34181,34250]
simple_stmt [34133,34202]
===
match
---
name: next_run_date [26130,26143]
name: next_run_date [26082,26095]
===
match
---
param [11480,11510]
param [11480,11510]
===
match
---
suite [43513,43637]
suite [43465,43589]
===
match
---
name: last_parsed_time [81909,81925]
name: last_parsed_time [81861,81877]
===
match
---
funcdef [31660,31744]
funcdef [31612,31696]
===
match
---
operator: = [59820,59821]
operator: = [59772,59773]
===
match
---
name: Optional [11738,11746]
name: Optional [11738,11746]
===
match
---
tfpdef [97998,98006]
tfpdef [97950,97958]
===
match
---
atom_expr [62738,62753]
atom_expr [62690,62705]
===
match
---
trailer [66399,66406]
trailer [66351,66358]
===
match
---
trailer [51354,51412]
trailer [51306,51364]
===
match
---
simple_stmt [85128,85274]
simple_stmt [85080,85226]
===
match
---
name: all [53309,53312]
name: all [53261,53264]
===
match
---
atom_expr [53889,53914]
atom_expr [53841,53866]
===
match
---
operator: = [56068,56069]
operator: = [56020,56021]
===
match
---
fstring [15485,15536]
fstring [15485,15536]
===
match
---
name: schedule_interval [24811,24828]
name: schedule_interval [24763,24780]
===
match
---
operator: , [3004,3005]
operator: , [3004,3005]
===
match
---
operator: = [55825,55826]
operator: = [55777,55778]
===
match
---
atom_expr [93338,93355]
atom_expr [93290,93307]
===
match
---
atom_expr [64447,64473]
atom_expr [64399,64425]
===
match
---
atom_expr [76980,77379]
atom_expr [76932,77331]
===
match
---
trailer [58906,58911]
trailer [58858,58863]
===
match
---
name: get [80453,80456]
name: get [80405,80408]
===
match
---
operator: - [22296,22297]
operator: - [22272,22273]
===
match
---
name: Session [89673,89680]
name: Session [89625,89632]
===
match
---
argument [66443,66451]
argument [66395,66403]
===
match
---
atom_expr [82823,82900]
atom_expr [82775,82852]
===
match
---
param [66997,67001]
param [66949,66953]
===
match
---
operator: , [74604,74605]
operator: , [74556,74557]
===
match
---
atom_expr [91153,91164]
atom_expr [91105,91116]
===
match
---
expr_stmt [12011,12037]
expr_stmt [12011,12037]
===
match
---
name: bind_partial [95288,95300]
name: bind_partial [95240,95252]
===
match
---
expr_stmt [36558,36593]
expr_stmt [36510,36545]
===
match
---
simple_stmt [76709,76727]
simple_stmt [76661,76679]
===
match
---
atom_expr [88551,88572]
atom_expr [88503,88524]
===
match
---
comparison [26641,26673]
comparison [26593,26625]
===
match
---
string: """Return nodes with no parents. These are first to execute and are called roots or root nodes.""" [44492,44590]
string: """Return nodes with no parents. These are first to execute and are called roots or root nodes.""" [44444,44542]
===
match
---
name: filter [44307,44313]
name: filter [44259,44265]
===
match
---
argument [71406,71423]
argument [71358,71375]
===
match
---
name: NativeEnvironment [1344,1361]
name: NativeEnvironment [1344,1361]
===
match
---
name: session [51131,51138]
name: session [51083,51090]
===
match
---
name: fn [32262,32264]
name: fn [32214,32216]
===
match
---
name: is_paused [76657,76666]
name: is_paused [76609,76618]
===
match
---
expr_stmt [96605,96648]
expr_stmt [96557,96600]
===
match
---
name: dag_id [51359,51365]
name: dag_id [51311,51317]
===
match
---
number: 25 [87358,87360]
number: 25 [87310,87312]
===
match
---
return_stmt [39033,39053]
return_stmt [38985,39005]
===
match
---
operator: = [30670,30671]
operator: = [30622,30623]
===
match
---
trailer [46799,46807]
trailer [46751,46759]
===
match
---
name: set_dependency [42504,42518]
name: set_dependency [42456,42470]
===
match
---
operator: = [79278,79279]
operator: = [79230,79231]
===
match
---
name: only_failed [56137,56148]
name: only_failed [56089,56100]
===
match
---
trailer [21032,21042]
trailer [21032,21042]
===
match
---
trailer [85550,85610]
trailer [85502,85562]
===
match
---
trailer [89957,89964]
trailer [89909,89916]
===
match
---
name: max_active_tasks [78719,78735]
name: max_active_tasks [78671,78687]
===
match
---
name: cls [98340,98343]
name: cls [98292,98295]
===
match
---
name: active_runs_of_dag [94541,94559]
name: active_runs_of_dag [94493,94511]
===
match
---
name: access_control [30701,30715]
name: access_control [30653,30667]
===
match
---
name: tasks [45721,45726]
name: tasks [45673,45678]
===
match
---
trailer [63596,63606]
trailer [63548,63558]
===
match
---
name: description [12851,12862]
name: description [12851,12862]
===
match
---
atom_expr [96560,96583]
atom_expr [96512,96535]
===
match
---
name: airflow [45382,45389]
name: airflow [45334,45341]
===
match
---
operator: = [71492,71493]
operator: = [71444,71445]
===
match
---
name: get_last_dagrun [89362,89377]
name: get_last_dagrun [89314,89329]
===
match
---
simple_stmt [17387,17418]
simple_stmt [17387,17418]
===
match
---
trailer [10560,10584]
trailer [10560,10584]
===
match
---
name: false [77779,77784]
name: false [77731,77736]
===
match
---
suite [55293,55367]
suite [55245,55319]
===
match
---
atom_expr [75935,75944]
atom_expr [75887,75896]
===
match
---
name: dag_bag [55326,55333]
name: dag_bag [55278,55285]
===
match
---
name: tags [79305,79309]
name: tags [79257,79261]
===
match
---
name: typing [1022,1028]
name: typing [1022,1028]
===
match
---
arglist [59437,59769]
arglist [59389,59721]
===
match
---
atom_expr [53511,53516]
atom_expr [53463,53468]
===
match
---
name: func [93405,93409]
name: func [93357,93361]
===
match
---
name: qry [83424,83427]
name: qry [83376,83379]
===
match
---
string: "Attempted to clear too many tasks " [54572,54608]
string: "Attempted to clear too many tasks " [54524,54560]
===
match
---
trailer [95930,95952]
trailer [95882,95904]
===
match
---
expr_stmt [67694,67749]
expr_stmt [67646,67701]
===
match
---
operator: = [87124,87125]
operator: = [87076,87077]
===
match
---
atom_expr [17572,17593]
atom_expr [17572,17593]
===
match
---
decorated [31084,31167]
decorated [31036,31119]
===
match
---
name: EdgeInfoType [84633,84645]
name: EdgeInfoType [84585,84597]
===
match
---
operator: = [85491,85492]
operator: = [85443,85444]
===
match
---
simple_stmt [38757,38787]
simple_stmt [38709,38739]
===
match
---
string: "Nothing to clear." [59052,59071]
string: "Nothing to clear." [59004,59023]
===
match
---
name: missing_dag_id [76443,76457]
name: missing_dag_id [76395,76409]
===
match
---
trailer [89305,89312]
trailer [89257,89264]
===
match
---
expr_stmt [14006,14059]
expr_stmt [14006,14059]
===
match
---
name: self [71283,71287]
name: self [71235,71239]
===
match
---
operator: , [19680,19681]
operator: , [19680,19681]
===
match
---
trailer [89115,89121]
trailer [89067,89073]
===
match
---
suite [22723,22809]
suite [22675,22761]
===
match
---
expr_stmt [83023,83069]
expr_stmt [82975,83021]
===
match
---
funcdef [31994,32063]
funcdef [31946,32015]
===
match
---
simple_stmt [42484,42495]
simple_stmt [42436,42447]
===
match
---
param [72423,72436]
param [72375,72388]
===
match
---
atom [51272,51274]
atom [51224,51226]
===
match
---
name: datetime [20132,20140]
name: datetime [20132,20140]
===
match
---
name: str [43689,43692]
name: str [43641,43644]
===
match
---
trailer [3635,3640]
trailer [3635,3640]
===
match
---
name: self [68884,68888]
name: self [68836,68840]
===
match
---
trailer [85296,85307]
trailer [85248,85259]
===
match
---
argument [57699,57714]
argument [57651,57666]
===
match
---
name: intersection [65022,65034]
name: intersection [64974,64986]
===
match
---
if_stmt [13294,13445]
if_stmt [13294,13445]
===
match
---
string: "dag.callback_exceptions" [36893,36918]
string: "dag.callback_exceptions" [36845,36870]
===
match
---
trailer [29062,29080]
trailer [29014,29032]
===
match
---
trailer [68076,68106]
trailer [68028,68058]
===
match
---
atom_expr [39960,39991]
atom_expr [39912,39943]
===
match
---
name: get [78950,78953]
name: get [78902,78905]
===
match
---
name: in_ [47950,47953]
name: in_ [47902,47905]
===
match
---
number: 0 [57988,57989]
number: 0 [57940,57941]
===
match
---
operator: = [26546,26547]
operator: = [26498,26499]
===
match
---
name: ti [36582,36584]
name: ti [36534,36536]
===
match
---
trailer [33520,33698]
trailer [33472,33650]
===
match
---
string: '@once' [24832,24839]
string: '@once' [24784,24791]
===
match
---
trailer [42432,42440]
trailer [42384,42392]
===
match
---
number: 0 [80947,80948]
number: 0 [80899,80900]
===
match
---
operator: , [89396,89397]
operator: , [89348,89349]
===
match
---
simple_stmt [76799,76820]
simple_stmt [76751,76772]
===
match
---
name: DeprecationWarning [30276,30294]
name: DeprecationWarning [30228,30246]
===
match
---
name: self [26731,26735]
name: self [26683,26687]
===
match
---
trailer [44171,44177]
trailer [44123,44129]
===
match
---
name: dag [66353,66356]
name: dag [66305,66308]
===
match
---
parameters [89643,89688]
parameters [89595,89640]
===
match
---
atom_expr [91763,91861]
atom_expr [91715,91813]
===
match
---
operator: = [59199,59200]
operator: = [59151,59152]
===
match
---
suite [53044,53100]
suite [52996,53052]
===
match
---
suite [37905,38061]
suite [37857,38013]
===
match
---
name: execution_date [43609,43623]
name: execution_date [43561,43575]
===
match
---
name: partial_subset [60895,60909]
name: partial_subset [60847,60861]
===
match
---
trailer [96629,96635]
trailer [96581,96587]
===
match
---
trailer [43292,43300]
trailer [43244,43252]
===
match
---
tfpdef [85099,85117]
tfpdef [85051,85069]
===
match
---
operator: -> [29494,29496]
operator: -> [29446,29448]
===
match
---
name: self [33226,33230]
name: self [33178,33182]
===
match
---
simple_stmt [82030,82047]
simple_stmt [81982,81999]
===
match
---
dotted_name [2013,2037]
dotted_name [2013,2037]
===
match
---
param [89384,89397]
param [89336,89349]
===
match
---
name: dag [81965,81968]
name: dag [81917,81920]
===
match
---
name: self [16380,16384]
name: self [16380,16384]
===
match
---
name: make_aware [22589,22599]
name: make_aware [22541,22551]
===
match
---
name: lower [11140,11145]
name: lower [11140,11145]
===
match
---
name: max_active_tasks [12423,12439]
name: max_active_tasks [12423,12439]
===
match
---
operator: = [16821,16822]
operator: = [16821,16822]
===
match
---
tfpdef [47541,47571]
tfpdef [47493,47523]
===
match
---
parameters [3164,3217]
parameters [3164,3217]
===
match
---
return_stmt [90621,90663]
return_stmt [90573,90615]
===
match
---
string: """         Returns Normalized Schedule Interval. This is used internally by the Scheduler to         schedule DAGs.          1. Converts Cron Preset to a Cron Expression (e.g ``@monthly`` to ``0 0 1 * *``)         2. If Schedule Interval is "@once" return "None"         3. If not (1) or (2) returns schedule_interval         """ [34756,35086]
string: """         Returns Normalized Schedule Interval. This is used internally by the Scheduler to         schedule DAGs.          1. Converts Cron Preset to a Cron Expression (e.g ``@monthly`` to ``0 0 1 * *``)         2. If Schedule Interval is "@once" return "None"         3. If not (1) or (2) returns schedule_interval         """ [34708,35038]
===
match
---
trailer [76840,76847]
trailer [76792,76799]
===
match
---
trailer [31740,31742]
trailer [31692,31694]
===
match
---
comparison [88247,88276]
comparison [88199,88228]
===
match
---
name: self [41407,41411]
name: self [41359,41363]
===
match
---
trailer [14357,14370]
trailer [14357,14370]
===
match
---
param [34070,34082]
param [34022,34034]
===
match
---
parameters [10163,11771]
parameters [10163,11771]
===
match
---
classdef [85359,85661]
classdef [85311,85613]
===
match
---
trailer [97131,97133]
trailer [97083,97085]
===
match
---
name: format [51779,51785]
name: format [51731,51737]
===
match
---
name: run_dates [28047,28056]
name: run_dates [27999,28008]
===
match
---
name: used_group_ids [63280,63294]
name: used_group_ids [63232,63246]
===
match
---
name: cli [71839,71842]
name: cli [71791,71794]
===
match
---
name: end_date [71336,71344]
name: end_date [71288,71296]
===
match
---
operator: , [1650,1651]
operator: , [1650,1651]
===
match
---
trailer [76334,76341]
trailer [76286,76293]
===
match
---
name: utils [2758,2763]
name: utils [2758,2763]
===
match
---
atom_expr [68222,68234]
atom_expr [68174,68186]
===
match
---
expr_stmt [18844,18871]
expr_stmt [18844,18871]
===
match
---
trailer [79520,79525]
trailer [79472,79477]
===
match
---
name: dag_hash [74618,74626]
name: dag_hash [74570,74578]
===
match
---
name: remove [79207,79213]
name: remove [79159,79165]
===
match
---
name: dag [62969,62972]
name: dag [62921,62924]
===
match
---
name: ExternalTaskMarker [53804,53822]
name: ExternalTaskMarker [53756,53774]
===
match
---
name: start_date [47975,47985]
name: start_date [47927,47937]
===
match
---
simple_stmt [910,946]
simple_stmt [910,946]
===
match
---
operator: , [66121,66122]
operator: , [66073,66074]
===
match
---
trailer [82682,82688]
trailer [82634,82640]
===
match
---
atom_expr [78576,78595]
atom_expr [78528,78547]
===
match
---
name: self [42390,42394]
name: self [42342,42346]
===
match
---
decorator [98494,98507]
decorator [98446,98459]
===
match
---
expr_stmt [47856,47890]
expr_stmt [47808,47842]
===
match
---
string: 'end_date' [13822,13832]
string: 'end_date' [13822,13832]
===
match
---
trailer [22903,22912]
trailer [22855,22864]
===
match
---
operator: , [56858,56859]
operator: , [56810,56811]
===
match
---
name: role [18884,18888]
name: role [18884,18888]
===
match
---
argument [57911,57938]
argument [57863,57890]
===
match
---
name: on_success_callback [16340,16359]
name: on_success_callback [16340,16359]
===
match
---
simple_stmt [58969,58990]
simple_stmt [58921,58942]
===
match
---
name: DagRun [74100,74106]
name: DagRun [74052,74058]
===
match
---
name: DagModel [66179,66187]
name: DagModel [66131,66139]
===
match
---
funcdef [32772,32898]
funcdef [32724,32850]
===
match
---
simple_stmt [75045,75106]
simple_stmt [74997,75058]
===
match
---
trailer [62248,62254]
trailer [62200,62206]
===
match
---
name: concurrency [88172,88183]
name: concurrency [88124,88135]
===
match
---
simple_stmt [31797,31880]
simple_stmt [31749,31832]
===
match
---
trailer [76508,76531]
trailer [76460,76483]
===
match
---
name: _downstream_task_ids [64977,64997]
name: _downstream_task_ids [64929,64949]
===
match
---
name: external_tis [55236,55248]
name: external_tis [55188,55200]
===
match
---
name: dag_id [81881,81887]
name: dag_id [81833,81839]
===
match
---
simple_stmt [78139,78199]
simple_stmt [78091,78151]
===
match
---
name: dp [66391,66393]
name: dp [66343,66345]
===
match
---
trailer [63575,63590]
trailer [63527,63542]
===
match
---
or_test [43468,43512]
or_test [43420,43464]
===
match
---
trailer [98370,98401]
trailer [98322,98353]
===
match
---
if_stmt [73705,73822]
if_stmt [73657,73774]
===
match
---
trailer [14281,14295]
trailer [14281,14295]
===
match
---
operator: , [61017,61018]
operator: , [60969,60970]
===
match
---
simple_stmt [51099,51117]
simple_stmt [51051,51069]
===
match
---
name: query [77522,77527]
name: query [77474,77479]
===
match
---
name: user_defined_filters [11897,11917]
name: user_defined_filters [11897,11917]
===
match
---
name: airflow [2470,2477]
name: airflow [2470,2477]
===
match
---
name: self [94128,94132]
name: self [94080,94084]
===
match
---
trailer [95703,95706]
trailer [95655,95658]
===
match
---
name: DagCode [79644,79651]
name: DagCode [79596,79603]
===
match
---
argument [56186,56211]
argument [56138,56163]
===
match
---
name: primary_key [85513,85524]
name: primary_key [85465,85476]
===
match
---
simple_stmt [38673,38749]
simple_stmt [38625,38701]
===
match
---
expr_stmt [41393,41419]
expr_stmt [41345,41371]
===
match
---
operator: = [10139,10140]
operator: = [10139,10140]
===
match
---
suite [53619,56981]
suite [53571,56933]
===
match
---
operator: == [66212,66214]
operator: == [66164,66166]
===
match
---
name: cls [84529,84532]
name: cls [84481,84484]
===
match
---
arglist [93268,93416]
arglist [93220,93368]
===
match
---
name: concurrency_reached [33364,33383]
name: concurrency_reached [33316,33335]
===
match
---
name: self [43484,43488]
name: self [43436,43440]
===
match
---
name: DagModel [97251,97259]
name: DagModel [97203,97211]
===
match
---
operator: @ [91363,91364]
operator: @ [91315,91316]
===
match
---
atom [57087,57143]
atom [57039,57095]
===
match
---
operator: = [11606,11607]
operator: = [11606,11607]
===
match
---
name: self [13457,13461]
name: self [13457,13461]
===
match
---
name: dttm [20301,20305]
name: dttm [20301,20305]
===
match
---
if_stmt [58921,58960]
if_stmt [58873,58912]
===
match
---
operator: -> [31118,31120]
operator: -> [31070,31072]
===
match
---
argument [95312,95324]
argument [95264,95276]
===
match
---
trailer [25015,25033]
trailer [24967,24985]
===
match
---
operator: = [74899,74900]
operator: = [74851,74852]
===
match
---
string: 'user_defined_filters' [60211,60233]
string: 'user_defined_filters' [60163,60185]
===
match
---
atom_expr [68149,68163]
atom_expr [68101,68115]
===
match
---
name: session [90763,90770]
name: session [90715,90722]
===
match
---
simple_stmt [57177,57199]
simple_stmt [57129,57151]
===
match
---
name: self [14068,14072]
name: self [14068,14072]
===
match
---
funcdef [85616,85661]
funcdef [85568,85613]
===
match
---
name: self [68458,68462]
name: self [68410,68414]
===
match
---
trailer [17346,17353]
trailer [17346,17353]
===
match
---
name: self [31607,31611]
name: self [31559,31563]
===
match
---
trailer [78246,78252]
trailer [78198,78204]
===
match
---
name: execution_date [55157,55171]
name: execution_date [55109,55123]
===
match
---
operator: = [93196,93197]
operator: = [93148,93149]
===
match
---
simple_stmt [14553,14597]
simple_stmt [14553,14597]
===
match
---
atom_expr [41907,41941]
atom_expr [41859,41893]
===
match
---
name: cls [91843,91846]
name: cls [91795,91798]
===
match
---
decorated [42814,44426]
decorated [42766,44378]
===
match
---
name: DAG [93696,93699]
name: DAG [93648,93651]
===
match
---
operator: -> [31313,31315]
operator: -> [31265,31267]
===
match
---
name: safe_dag_id [90594,90605]
name: safe_dag_id [90546,90557]
===
match
---
name: DeprecationWarning [40347,40365]
name: DeprecationWarning [40299,40317]
===
match
---
funcdef [79986,80284]
funcdef [79938,80236]
===
match
---
name: dag_id [77105,77111]
name: dag_id [77057,77063]
===
match
---
atom_expr [87566,87597]
atom_expr [87518,87549]
===
match
---
parameters [31911,31917]
parameters [31863,31869]
===
match
---
operator: + [54321,54322]
operator: + [54273,54274]
===
match
---
operator: = [51559,51560]
operator: = [51511,51512]
===
match
---
name: validate_key [2499,2511]
name: validate_key [2499,2511]
===
match
---
atom_expr [42996,43009]
atom_expr [42948,42961]
===
match
---
suite [30722,30759]
suite [30674,30711]
===
match
---
param [58238,58257]
param [58190,58209]
===
match
---
name: Optional [11591,11599]
name: Optional [11591,11599]
===
match
---
atom_expr [38679,38748]
atom_expr [38631,38700]
===
match
---
if_stmt [13708,13997]
if_stmt [13708,13997]
===
match
---
name: normalized_schedule_interval [22682,22710]
name: normalized_schedule_interval [22634,22662]
===
match
---
operator: = [86377,86378]
operator: = [86329,86330]
===
match
---
operator: , [69144,69145]
operator: , [69096,69097]
===
match
---
name: root_dag_id [78147,78158]
name: root_dag_id [78099,78110]
===
match
---
string: "jinja2.ext.do" [41729,41744]
string: "jinja2.ext.do" [41681,41696]
===
match
---
decorator [92581,92594]
decorator [92533,92546]
===
match
---
name: BaseOperator [31684,31696]
name: BaseOperator [31636,31648]
===
match
---
name: allow_future_exec_dates [32776,32799]
name: allow_future_exec_dates [32728,32751]
===
match
---
suite [20307,21541]
suite [20307,21517]
===
match
---
simple_stmt [79513,79546]
simple_stmt [79465,79498]
===
match
---
trailer [43681,43693]
trailer [43633,43645]
===
match
---
operator: , [48291,48292]
operator: , [48243,48244]
===
match
---
name: info [76743,76747]
name: info [76695,76699]
===
match
---
name: max [26590,26593]
name: max [26542,26545]
===
match
---
expr_stmt [66244,66253]
expr_stmt [66196,66205]
===
match
---
name: dag_id [51520,51526]
name: dag_id [51472,51478]
===
match
---
atom_expr [62628,62663]
atom_expr [62580,62615]
===
match
---
trailer [11184,11216]
trailer [11184,11216]
===
match
---
operator: -> [32529,32531]
operator: -> [32481,32483]
===
match
---
atom_expr [65685,65702]
atom_expr [65637,65654]
===
match
---
simple_stmt [78345,78375]
simple_stmt [78297,78327]
===
match
---
comparison [23706,23733]
comparison [23658,23685]
===
match
---
name: Callable [1061,1069]
name: Callable [1061,1069]
===
match
---
atom_expr [40732,40742]
atom_expr [40684,40694]
===
match
---
trailer [88214,88216]
trailer [88166,88168]
===
match
---
name: pendulum [20662,20670]
name: pendulum [20662,20670]
===
match
---
name: dag_tag_orm [79582,79593]
name: dag_tag_orm [79534,79545]
===
match
---
atom_expr [64408,64433]
atom_expr [64360,64385]
===
match
---
name: f_back [96747,96753]
name: f_back [96699,96705]
===
match
---
name: dagpickle [2028,2037]
name: dagpickle [2028,2037]
===
match
---
name: exception [36810,36819]
name: exception [36762,36771]
===
match
---
name: edge_info [85287,85296]
name: edge_info [85239,85248]
===
match
---
operator: @ [81177,81178]
operator: @ [81129,81130]
===
match
---
operator: = [69182,69183]
operator: = [69134,69135]
===
match
---
atom_expr [11535,11549]
atom_expr [11535,11549]
===
match
---
name: conf [11176,11180]
name: conf [11176,11180]
===
match
---
atom_expr [30152,30331]
atom_expr [30104,30283]
===
match
---
trailer [80495,80497]
trailer [80447,80449]
===
match
---
trailer [68598,68612]
trailer [68550,68564]
===
match
---
simple_stmt [2874,2908]
simple_stmt [2874,2908]
===
match
---
trailer [17850,17867]
trailer [17850,17867]
===
match
---
simple_stmt [83417,83437]
simple_stmt [83369,83389]
===
match
---
operator: = [15756,15757]
operator: = [15756,15757]
===
match
---
trailer [65118,65126]
trailer [65070,65078]
===
match
---
atom_expr [91174,91315]
atom_expr [91126,91267]
===
match
---
name: self [66493,66497]
name: self [66445,66449]
===
match
---
import_from [1515,1557]
import_from [1515,1557]
===
match
---
arglist [90530,90561]
arglist [90482,90513]
===
match
---
name: self [13561,13565]
name: self [13561,13565]
===
match
---
argument [13956,13978]
argument [13956,13978]
===
match
---
atom_expr [89276,89331]
atom_expr [89228,89283]
===
match
---
decorator [3671,3697]
decorator [3671,3697]
===
match
---
atom_expr [35215,35255]
atom_expr [35167,35207]
===
match
---
operator: , [39658,39659]
operator: , [39610,39611]
===
match
---
trailer [74366,74373]
trailer [74318,74325]
===
match
---
simple_stmt [44599,44662]
simple_stmt [44551,44614]
===
match
---
name: property [90577,90585]
name: property [90529,90537]
===
match
---
operator: , [16124,16125]
operator: , [16124,16125]
===
match
---
trailer [91902,91906]
trailer [91854,91858]
===
match
---
atom_expr [72345,72359]
atom_expr [72297,72311]
===
match
---
name: self [62032,62036]
name: self [61984,61988]
===
match
---
name: dag_run_state [56446,56459]
name: dag_run_state [56398,56411]
===
match
---
name: start_date [13118,13128]
name: start_date [13118,13128]
===
match
---
operator: = [52697,52698]
operator: = [52649,52650]
===
match
---
operator: == [51527,51529]
operator: == [51479,51481]
===
match
---
operator: = [52602,52603]
operator: = [52554,52555]
===
match
---
trailer [69088,69112]
trailer [69040,69064]
===
match
---
tfpdef [11226,11239]
tfpdef [11226,11239]
===
match
---
operator: - [22772,22773]
operator: - [22724,22725]
===
match
---
expr_stmt [11949,12002]
expr_stmt [11949,12002]
===
match
---
expr_stmt [68057,68106]
expr_stmt [68009,68058]
===
match
---
name: Dict [11657,11661]
name: Dict [11657,11661]
===
match
---
name: cls [75422,75425]
name: cls [75374,75377]
===
match
---
atom_expr [89949,89964]
atom_expr [89901,89916]
===
match
---
string: 'dag_default_view' [11120,11138]
string: 'dag_default_view' [11120,11138]
===
match
---
simple_stmt [97014,97029]
simple_stmt [96966,96981]
===
match
---
name: TI [52710,52712]
name: TI [52662,52664]
===
match
---
trailer [54951,54958]
trailer [54903,54910]
===
match
---
trailer [18957,18963]
trailer [18957,18963]
===
match
---
operator: = [87590,87591]
operator: = [87542,87543]
===
match
---
name: next_run_date [26594,26607]
name: next_run_date [26546,26559]
===
match
---
name: schedule_interval [25430,25447]
name: schedule_interval [25382,25399]
===
match
---
simple_stmt [33983,34020]
simple_stmt [33935,33972]
===
match
---
operator: = [37099,37100]
operator: = [37051,37052]
===
match
---
name: run [74712,74715]
name: run [74664,74667]
===
match
---
name: pool [69197,69201]
name: pool [69149,69153]
===
match
---
number: 0 [66749,66750]
number: 0 [66701,66702]
===
match
---
simple_stmt [57980,57990]
simple_stmt [57932,57942]
===
match
---
name: Optional [11488,11496]
name: Optional [11488,11496]
===
match
---
trailer [21950,21956]
trailer [21926,21932]
===
match
---
name: TaskInstance [83233,83245]
name: TaskInstance [83185,83197]
===
match
---
operator: = [48209,48210]
operator: = [48161,48162]
===
match
---
atom_expr [75322,75357]
atom_expr [75274,75309]
===
match
---
name: in_ [44333,44336]
name: in_ [44285,44288]
===
match
---
operator: == [89313,89315]
operator: == [89265,89267]
===
match
---
atom_expr [24085,24102]
atom_expr [24037,24054]
===
match
---
operator: , [68090,68091]
operator: , [68042,68043]
===
match
---
if_stmt [13521,13622]
if_stmt [13521,13622]
===
match
---
name: tags [79074,79078]
name: tags [79026,79030]
===
match
---
trailer [26552,26563]
trailer [26504,26515]
===
match
---
operator: , [48316,48317]
operator: , [48268,48269]
===
match
---
name: self [39834,39838]
name: self [39786,39790]
===
match
---
name: dag [66443,66446]
name: dag [66395,66398]
===
match
---
name: default_view [80536,80548]
name: default_view [80488,80500]
===
match
---
operator: @ [97947,97948]
operator: @ [97899,97900]
===
match
---
trailer [98231,98236]
trailer [98183,98188]
===
match
---
trailer [13266,13280]
trailer [13266,13280]
===
match
---
trailer [73769,73821]
trailer [73721,73773]
===
match
---
decorator [95335,95355]
decorator [95287,95307]
===
match
---
name: self [16411,16415]
name: self [16411,16415]
===
match
---
arith_expr [32273,32304]
arith_expr [32225,32256]
===
match
---
name: val [17696,17699]
name: val [17696,17699]
===
match
---
trailer [81011,81018]
trailer [80963,80970]
===
match
---
decorated [31000,31079]
decorated [30952,31031]
===
match
---
trailer [93730,93749]
trailer [93682,93701]
===
match
---
trailer [16120,16139]
trailer [16120,16139]
===
match
---
trailer [51445,51458]
trailer [51397,51410]
===
match
---
tfpdef [93701,93749]
tfpdef [93653,93701]
===
match
---
comparison [82975,82984]
comparison [82927,82936]
===
match
---
trailer [47696,47847]
trailer [47648,47799]
===
match
---
trailer [84931,84935]
trailer [84883,84887]
===
match
---
name: include_subdags [51160,51175]
name: include_subdags [51112,51127]
===
match
---
name: cls [60071,60074]
name: cls [60023,60026]
===
match
---
suite [43655,44345]
suite [43607,44297]
===
match
---
suite [68044,68107]
suite [67996,68059]
===
match
---
simple_stmt [20759,20817]
simple_stmt [20759,20817]
===
match
---
comparison [54009,54029]
comparison [53961,53981]
===
match
---
name: provide_session [74952,74967]
name: provide_session [74904,74919]
===
match
---
comparison [25393,25410]
comparison [25345,25362]
===
match
---
operator: , [52905,52906]
operator: , [52857,52858]
===
match
---
atom_expr [63269,63295]
atom_expr [63221,63247]
===
match
---
simple_stmt [90493,90571]
simple_stmt [90445,90523]
===
match
---
operator: , [54743,54744]
operator: , [54695,54696]
===
match
---
trailer [82974,83001]
trailer [82926,82953]
===
match
---
name: airflow [2712,2719]
name: airflow [2712,2719]
===
match
---
name: self [68149,68153]
name: self [68101,68105]
===
match
---
trailer [83032,83039]
trailer [82984,82991]
===
match
---
trailer [81734,81736]
trailer [81686,81688]
===
match
---
simple_stmt [2619,2707]
simple_stmt [2619,2707]
===
match
---
funcdef [63066,64034]
funcdef [63018,63986]
===
match
---
operator: = [52984,52985]
operator: = [52936,52937]
===
match
---
name: dag_id [77535,77541]
name: dag_id [77487,77493]
===
match
---
operator: = [3411,3412]
operator: = [3411,3412]
===
match
---
operator: = [59488,59489]
operator: = [59440,59441]
===
match
---
trailer [37112,37153]
trailer [37064,37105]
===
match
---
name: visited_external_tis [53598,53618]
name: visited_external_tis [53550,53570]
===
match
---
trailer [91991,91999]
trailer [91943,91951]
===
match
---
return_stmt [18615,18626]
return_stmt [18615,18626]
===
match
---
name: tz [22607,22609]
name: tz [22559,22561]
===
match
---
trailer [13416,13429]
trailer [13416,13429]
===
match
---
name: _upgrade_outdated_dag_access_control [16514,16550]
name: _upgrade_outdated_dag_access_control [16514,16550]
===
match
---
suite [44483,44662]
suite [44435,44614]
===
match
---
simple_stmt [14006,14060]
simple_stmt [14006,14060]
===
match
---
operator: , [57867,57868]
operator: , [57819,57820]
===
match
---
name: dags [59384,59388]
name: dags [59336,59340]
===
match
---
name: backref [87518,87525]
name: backref [87470,87477]
===
match
---
trailer [26040,26063]
trailer [25992,26015]
===
match
---
atom_expr [82851,82885]
atom_expr [82803,82837]
===
match
---
suite [43868,44255]
suite [43820,44207]
===
match
---
name: dag_id [75972,75978]
name: dag_id [75924,75930]
===
match
---
operator: >= [43253,43255]
operator: >= [43205,43207]
===
match
---
return_stmt [85644,85660]
return_stmt [85596,85612]
===
match
---
atom_expr [87526,87540]
atom_expr [87478,87492]
===
match
---
atom_expr [19978,19992]
atom_expr [19978,19992]
===
match
---
name: Dict [13038,13042]
name: Dict [13038,13042]
===
match
---
param [47472,47499]
param [47424,47451]
===
match
---
operator: = [61061,61062]
operator: = [61013,61014]
===
match
---
name: template_searchpath [14514,14533]
name: template_searchpath [14514,14533]
===
match
---
name: dag_id [89158,89164]
name: dag_id [89110,89116]
===
match
---
name: include_subdags [56316,56331]
name: include_subdags [56268,56283]
===
match
---
operator: = [81248,81249]
operator: = [81200,81201]
===
match
---
name: external_trigger [72289,72305]
name: external_trigger [72241,72257]
===
match
---
name: base [1801,1805]
name: base [1801,1805]
===
match
---
trailer [81117,81123]
trailer [81069,81075]
===
match
---
import_as_names [2777,2801]
import_as_names [2777,2801]
===
match
---
name: end_date [58188,58196]
name: end_date [58140,58148]
===
match
---
name: utcnow [19523,19529]
name: utcnow [19523,19529]
===
match
---
name: is_paused [34318,34327]
name: is_paused [34270,34279]
===
match
---
operator: = [56402,56403]
operator: = [56354,56355]
===
match
---
string: 'full_filepath' [10011,10026]
string: 'full_filepath' [10011,10026]
===
match
---
comparison [19569,19584]
comparison [19569,19584]
===
match
---
operator: , [48394,48395]
operator: , [48346,48347]
===
match
---
trailer [33942,33974]
trailer [33894,33926]
===
match
---
simple_stmt [79909,79960]
simple_stmt [79861,79912]
===
match
---
trailer [12143,12156]
trailer [12143,12156]
===
match
---
name: sla_miss_callback [15012,15029]
name: sla_miss_callback [15012,15029]
===
match
---
trailer [17591,17593]
trailer [17591,17593]
===
match
---
name: settings [88991,88999]
name: settings [88943,88951]
===
match
---
trailer [43051,43062]
trailer [43003,43014]
===
match
---
test [12974,13013]
test [12974,13013]
===
match
---
simple_stmt [44979,45369]
simple_stmt [44931,45321]
===
match
---
operator: , [47623,47624]
operator: , [47575,47576]
===
match
---
trailer [17739,17744]
trailer [17739,17744]
===
match
---
trailer [23968,23987]
trailer [23920,23939]
===
match
---
atom_expr [89450,89576]
atom_expr [89402,89528]
===
match
---
operator: , [41774,41775]
operator: , [41726,41727]
===
match
---
name: start_date [67738,67748]
name: start_date [67690,67700]
===
match
---
simple_stmt [85901,85938]
simple_stmt [85853,85890]
===
match
---
tfpdef [31288,31297]
tfpdef [31240,31249]
===
match
---
trailer [43307,43315]
trailer [43259,43267]
===
match
---
return_stmt [44415,44425]
return_stmt [44367,44377]
===
match
---
decorated [29778,29864]
decorated [29730,29816]
===
match
---
name: DagRun [37823,37829]
name: DagRun [37775,37781]
===
match
---
name: task_id [55707,55714]
name: task_id [55659,55666]
===
match
---
atom_expr [95280,95325]
atom_expr [95232,95277]
===
match
---
name: cron [20001,20005]
name: cron [20001,20005]
===
match
---
name: self [13536,13540]
name: self [13536,13540]
===
match
---
tfpdef [10187,10198]
tfpdef [10187,10198]
===
match
---
name: self [80402,80406]
name: self [80354,80358]
===
match
---
simple_stmt [2909,2965]
simple_stmt [2909,2965]
===
match
---
trailer [54892,54894]
trailer [54844,54846]
===
match
---
trailer [11656,11662]
trailer [11656,11662]
===
match
---
atom_expr [52907,52915]
atom_expr [52859,52867]
===
match
---
atom_expr [43092,43111]
atom_expr [43044,43063]
===
match
---
name: Interval [2656,2664]
name: Interval [2656,2664]
===
match
---
expr_stmt [66814,66824]
expr_stmt [66766,66776]
===
match
---
name: staticmethod [82053,82065]
name: staticmethod [82005,82017]
===
match
---
operator: , [94764,94765]
operator: , [94716,94717]
===
match
---
name: k [60132,60133]
name: k [60084,60085]
===
match
---
expr_stmt [66428,66452]
expr_stmt [66380,66404]
===
match
---
name: dag_id [34227,34233]
name: dag_id [34179,34185]
===
match
---
atom_expr [62244,62254]
atom_expr [62196,62206]
===
match
---
parameters [63087,63108]
parameters [63039,63060]
===
match
---
simple_stmt [11837,11884]
simple_stmt [11837,11884]
===
match
---
trailer [51660,51671]
trailer [51612,51623]
===
match
---
parameters [30414,30432]
parameters [30366,30384]
===
match
---
param [69060,69113]
param [69012,69065]
===
match
---
suite [76632,76697]
suite [76584,76649]
===
match
---
name: full_filepath [12353,12366]
name: full_filepath [12353,12366]
===
match
---
name: ValueError [74005,74015]
name: ValueError [73957,73967]
===
match
---
argument [79456,79468]
argument [79408,79420]
===
match
---
name: DagModel [81653,81661]
name: DagModel [81605,81613]
===
match
---
operator: , [13339,13340]
operator: , [13339,13340]
===
match
---
fstring [15265,15314]
fstring [15265,15314]
===
match
---
operator: -> [19539,19541]
operator: -> [19539,19541]
===
match
---
simple_stmt [12011,12038]
simple_stmt [12011,12038]
===
match
---
import_from [53141,53201]
import_from [53093,53153]
===
match
---
name: orm_dags [77899,77907]
name: orm_dags [77851,77859]
===
match
---
operator: , [35131,35132]
operator: , [35083,35084]
===
match
---
trailer [33925,33935]
trailer [33877,33887]
===
match
---
if_stmt [76589,76697]
if_stmt [76541,76649]
===
match
---
operator: = [85470,85471]
operator: = [85422,85423]
===
match
---
name: dag_id [55568,55574]
name: dag_id [55520,55526]
===
match
---
arglist [26594,26624]
arglist [26546,26576]
===
match
---
name: p_dag [51697,51702]
name: p_dag [51649,51654]
===
match
---
subscript [97120,97124]
subscript [97072,97076]
===
match
---
name: airflow [1884,1891]
name: airflow [1884,1891]
===
match
---
name: task_id [65569,65576]
name: task_id [65521,65528]
===
match
---
trailer [33173,33179]
trailer [33125,33131]
===
match
---
atom_expr [66022,66037]
atom_expr [65974,65989]
===
match
---
name: self [36801,36805]
name: self [36753,36757]
===
match
---
name: external_trigger [38005,38021]
name: external_trigger [37957,37973]
===
match
---
name: dag [64244,64247]
name: dag [64196,64199]
===
match
---
operator: , [30262,30263]
operator: , [30214,30215]
===
match
---
operator: , [71353,71354]
operator: , [71305,71306]
===
match
---
atom_expr [65090,65100]
atom_expr [65042,65052]
===
match
---
param [11226,11293]
param [11226,11293]
===
match
---
name: serialized_dag [97205,97219]
name: serialized_dag [97157,97171]
===
match
---
trailer [91187,91197]
trailer [91139,91149]
===
match
---
name: str [85069,85072]
name: str [85021,85024]
===
match
---
parameters [89377,89433]
parameters [89329,89385]
===
match
---
trailer [52996,53023]
trailer [52948,52975]
===
match
---
name: _upstream_task_ids [64887,64905]
name: _upstream_task_ids [64839,64857]
===
match
---
name: str [31040,31043]
name: str [30992,30995]
===
match
---
name: default_view [15117,15129]
name: default_view [15117,15129]
===
match
---
atom [37178,37180]
atom [37130,37132]
===
match
---
testlist_comp [60188,60251]
testlist_comp [60140,60203]
===
match
---
name: self [30810,30814]
name: self [30762,30766]
===
match
---
name: property [32500,32508]
name: property [32452,32460]
===
match
---
name: qry [83029,83032]
name: qry [82981,82984]
===
match
---
name: airflow [2341,2348]
name: airflow [2341,2348]
===
match
---
suite [62705,62754]
suite [62657,62706]
===
match
---
suite [13346,13445]
suite [13346,13445]
===
match
---
param [37343,37365]
param [37295,37317]
===
match
---
name: tis [57081,57084]
name: tis [57033,57036]
===
match
---
atom_expr [72455,72468]
atom_expr [72407,72420]
===
match
---
name: Tuple [1163,1168]
name: Tuple [1163,1168]
===
match
---
comparison [57425,57435]
comparison [57377,57387]
===
match
---
trailer [65038,65048]
trailer [64990,65000]
===
match
---
operator: <= [39698,39700]
operator: <= [39650,39652]
===
match
---
param [27517,27530]
param [27469,27482]
===
match
---
name: dag_sig [95221,95228]
name: dag_sig [95173,95180]
===
match
---
atom_expr [34000,34018]
atom_expr [33952,33970]
===
match
---
suite [17543,17595]
suite [17543,17595]
===
match
---
trailer [67737,67748]
trailer [67689,67700]
===
match
---
arglist [87573,87596]
arglist [87525,87548]
===
match
---
name: BaseOperator [1866,1878]
name: BaseOperator [1866,1878]
===
match
---
name: Dict [10747,10751]
name: Dict [10747,10751]
===
match
---
name: max_active_tasks [33324,33340]
name: max_active_tasks [33276,33292]
===
match
---
operator: == [66350,66352]
operator: == [66302,66304]
===
match
---
suite [66415,66595]
suite [66367,66547]
===
match
---
atom_expr [51298,51310]
atom_expr [51250,51262]
===
match
---
arglist [52881,52940]
arglist [52833,52892]
===
match
---
expr_stmt [86507,86541]
expr_stmt [86459,86493]
===
match
---
argument [37133,37152]
argument [37085,37104]
===
match
---
atom_expr [51337,51412]
atom_expr [51289,51364]
===
match
---
name: recursion_depth [56614,56629]
name: recursion_depth [56566,56581]
===
match
---
suite [80428,80498]
suite [80380,80450]
===
match
---
decorator [29869,29879]
decorator [29821,29831]
===
match
---
param [72376,72414]
param [72328,72366]
===
match
---
name: success [36305,36312]
name: success [36257,36264]
===
match
---
name: ExternalTaskMarker [53859,53877]
name: ExternalTaskMarker [53811,53829]
===
match
---
suite [48782,58090]
suite [48734,58042]
===
match
---
name: filter [76174,76180]
name: filter [76126,76132]
===
match
---
if_stmt [43646,44345]
if_stmt [43598,44297]
===
match
---
name: Optional [10114,10122]
name: Optional [10114,10122]
===
match
---
name: dag_id [74355,74361]
name: dag_id [74307,74313]
===
match
---
param [31670,31674]
param [31622,31626]
===
match
---
atom_expr [15091,15109]
atom_expr [15091,15109]
===
match
---
name: self [14206,14210]
name: self [14206,14210]
===
match
---
fstring_expr [15299,15313]
fstring_expr [15299,15313]
===
match
---
and_test [68133,68208]
and_test [68085,68160]
===
match
---
atom_expr [16510,16566]
atom_expr [16510,16566]
===
match
---
atom_expr [92057,92074]
atom_expr [92009,92026]
===
match
---
suite [39146,39778]
suite [39098,39730]
===
match
---
operator: = [74595,74596]
operator: = [74547,74548]
===
match
---
suite [13840,13997]
suite [13840,13997]
===
match
---
operator: , [74525,74526]
operator: , [74477,74478]
===
match
---
suite [17248,17282]
suite [17248,17282]
===
match
---
trailer [81144,81151]
trailer [81096,81103]
===
match
---
sync_comp_for [79288,79309]
sync_comp_for [79240,79261]
===
match
---
trailer [13874,13886]
trailer [13874,13886]
===
match
---
trailer [12978,12985]
trailer [12978,12985]
===
match
---
name: tis [44109,44112]
name: tis [44061,44064]
===
match
---
name: create_root [16833,16844]
name: create_root [16833,16844]
===
match
---
name: only_failed [59531,59542]
name: only_failed [59483,59494]
===
match
---
simple_stmt [21589,21731]
simple_stmt [21565,21707]
===
match
---
trailer [44628,44634]
trailer [44580,44586]
===
match
---
name: dag_id [38854,38860]
name: dag_id [38806,38812]
===
match
---
operator: } [85020,85021]
operator: } [84972,84973]
===
match
---
operator: } [15598,15599]
operator: } [15598,15599]
===
match
---
operator: , [77679,77680]
operator: , [77631,77632]
===
match
---
operator: , [48268,48269]
operator: , [48220,48221]
===
match
---
atom_expr [81110,81128]
atom_expr [81062,81080]
===
match
---
param [3182,3216]
param [3182,3216]
===
match
---
operator: , [10363,10364]
operator: , [10363,10364]
===
match
---
trailer [47353,47360]
trailer [47305,47312]
===
match
---
operator: , [69050,69051]
operator: , [69002,69003]
===
match
---
atom_expr [43225,43252]
atom_expr [43177,43204]
===
match
---
atom_expr [11747,11756]
atom_expr [11747,11756]
===
match
---
name: helpers [57742,57749]
name: helpers [57694,57701]
===
match
---
return_stmt [66071,66079]
return_stmt [66023,66031]
===
match
---
operator: = [30318,30319]
operator: = [30270,30271]
===
match
---
trailer [62036,62046]
trailer [61988,61998]
===
match
---
trailer [10498,10518]
trailer [10498,10518]
===
match
---
name: tis [51928,51931]
name: tis [51880,51883]
===
match
---
operator: = [28722,28723]
operator: = [28674,28675]
===
match
---
dotted_name [3672,3696]
dotted_name [3672,3696]
===
match
---
expr_stmt [12784,12821]
expr_stmt [12784,12821]
===
match
---
name: keys [76034,76038]
name: keys [75986,75990]
===
match
---
operator: = [72226,72227]
operator: = [72178,72179]
===
match
---
operator: = [18964,18965]
operator: = [18964,18965]
===
match
---
name: __repr__ [85620,85628]
name: __repr__ [85572,85580]
===
match
---
name: args [72042,72046]
name: args [71994,71998]
===
match
---
trailer [77246,77255]
trailer [77198,77207]
===
match
---
name: query [34195,34200]
name: query [34147,34152]
===
match
---
param [82141,82153]
param [82093,82105]
===
match
---
trailer [51302,51310]
trailer [51254,51262]
===
match
---
simple_stmt [2008,2055]
simple_stmt [2008,2055]
===
match
---
name: root_dag_id [85901,85912]
name: root_dag_id [85853,85864]
===
match
---
suite [43922,43994]
suite [43874,43946]
===
match
---
trailer [93505,93531]
trailer [93457,93483]
===
match
---
dotted_name [1925,1947]
dotted_name [1925,1947]
===
match
---
name: folder [41412,41418]
name: folder [41364,41370]
===
match
---
operator: , [71423,71424]
operator: , [71375,71376]
===
match
---
atom_expr [17435,17446]
atom_expr [17435,17446]
===
match
---
atom_expr [48020,48041]
atom_expr [47972,47993]
===
match
---
trailer [25261,25268]
trailer [25213,25220]
===
match
---
trailer [98547,98552]
trailer [98499,98504]
===
match
---
name: schedule_interval [78658,78675]
name: schedule_interval [78610,78627]
===
match
---
name: dag_id [79007,79013]
name: dag_id [78959,78965]
===
match
---
operator: , [65287,65288]
operator: , [65239,65240]
===
match
---
arith_expr [22349,22388]
arith_expr [22325,22364]
===
match
---
operator: = [42973,42974]
operator: = [42925,42926]
===
match
---
trailer [52924,52940]
trailer [52876,52892]
===
match
---
name: task_group [11800,11810]
name: task_group [11800,11810]
===
match
---
operator: , [48774,48775]
operator: , [48726,48727]
===
match
---
name: now [19972,19975]
name: now [19972,19975]
===
match
---
name: children [63965,63973]
name: children [63917,63925]
===
match
---
param [39104,39109]
param [39056,39061]
===
match
---
trailer [89121,89131]
trailer [89073,89083]
===
match
---
operator: , [75450,75451]
operator: , [75402,75403]
===
match
---
param [19483,19532]
param [19483,19532]
===
match
---
operator: = [10297,10298]
operator: = [10297,10298]
===
match
---
name: self [17435,17439]
name: self [17435,17439]
===
match
---
simple_stmt [17833,17869]
simple_stmt [17833,17869]
===
match
---
simple_stmt [14837,14887]
simple_stmt [14837,14887]
===
match
---
simple_stmt [65201,65251]
simple_stmt [65153,65203]
===
match
---
trailer [91208,91223]
trailer [91160,91175]
===
match
---
name: in_ [53085,53088]
name: in_ [53037,53040]
===
match
---
atom_expr [22179,22208]
atom_expr [22155,22184]
===
match
---
simple_stmt [76832,76857]
simple_stmt [76784,76809]
===
match
---
trailer [13942,13954]
trailer [13942,13954]
===
match
---
trailer [93409,93413]
trailer [93361,93365]
===
match
---
return_stmt [32451,32493]
return_stmt [32403,32445]
===
match
---
name: self [16869,16873]
name: self [16869,16873]
===
match
---
param [41255,41259]
param [41207,41211]
===
match
---
comparison [33213,33237]
comparison [33165,33189]
===
match
---
import_from [1697,1780]
import_from [1697,1780]
===
match
---
trailer [68579,68594]
trailer [68531,68546]
===
match
---
operator: , [10854,10855]
operator: , [10854,10855]
===
match
---
name: self [11949,11953]
name: self [11949,11953]
===
match
---
simple_stmt [97895,97942]
simple_stmt [97847,97894]
===
match
---
name: cls [89302,89305]
name: cls [89254,89257]
===
match
---
operator: = [19669,19670]
operator: = [19669,19670]
===
match
---
name: dagrun_timeout [14947,14961]
name: dagrun_timeout [14947,14961]
===
match
---
name: pickle_id [31102,31111]
name: pickle_id [31054,31063]
===
match
---
atom_expr [96276,96285]
atom_expr [96228,96237]
===
match
---
trailer [21023,21032]
trailer [21023,21032]
===
match
---
operator: = [78159,78160]
operator: = [78111,78112]
===
match
---
name: provide_session [91364,91379]
name: provide_session [91316,91331]
===
match
---
name: value [33994,33999]
name: value [33946,33951]
===
match
---
name: other [17304,17309]
name: other [17304,17309]
===
match
---
trailer [10132,10137]
trailer [10132,10137]
===
match
---
name: task [53969,53973]
name: task [53921,53925]
===
match
---
trailer [55053,55061]
trailer [55005,55013]
===
match
---
import_from [1658,1696]
import_from [1658,1696]
===
match
---
suite [14540,14597]
suite [14540,14597]
===
match
---
return_stmt [83417,83436]
return_stmt [83369,83388]
===
match
---
operator: , [10198,10199]
operator: , [10198,10199]
===
match
---
operator: @ [31885,31886]
operator: @ [31837,31838]
===
match
---
atom_expr [36502,36509]
atom_expr [36454,36461]
===
match
---
funcdef [65639,66080]
funcdef [65591,66032]
===
match
---
atom_expr [44115,44254]
atom_expr [44067,44206]
===
match
---
name: TaskInstance [83377,83389]
name: TaskInstance [83329,83341]
===
match
---
parameters [83484,83489]
parameters [83436,83441]
===
match
---
operator: , [74443,74444]
operator: , [74395,74396]
===
match
---
name: get_last_dagrun [29181,29196]
name: get_last_dagrun [29133,29148]
===
match
---
operator: , [93355,93356]
operator: , [93307,93308]
===
match
---
expr_stmt [25337,25377]
expr_stmt [25289,25329]
===
match
---
atom_expr [63357,63372]
atom_expr [63309,63324]
===
match
---
name: params [60455,60461]
name: params [60407,60413]
===
match
---
atom_expr [93373,93401]
atom_expr [93325,93353]
===
match
---
trailer [96080,96127]
trailer [96032,96079]
===
match
---
suite [65192,65251]
suite [65144,65203]
===
match
---
operator: , [60964,60965]
operator: , [60916,60917]
===
match
---
name: _task_group [64047,64058]
name: _task_group [63999,64010]
===
match
---
string: '_pickle_id' [83984,83996]
string: '_pickle_id' [83936,83948]
===
match
---
name: permissions [18753,18764]
name: permissions [18753,18764]
===
match
---
name: user_defined_filters [10671,10691]
name: user_defined_filters [10671,10691]
===
match
---
name: pickled [65835,65842]
name: pickled [65787,65794]
===
match
---
name: DagRun [77597,77603]
name: DagRun [77549,77555]
===
match
---
atom [40759,40997]
atom [40711,40949]
===
match
---
name: task_dict [68649,68658]
name: task_dict [68601,68610]
===
match
---
suite [67003,67098]
suite [66955,67050]
===
match
---
name: orm_dag [76649,76656]
name: orm_dag [76601,76608]
===
match
---
simple_stmt [32380,32443]
simple_stmt [32332,32395]
===
match
---
dotted_name [2258,2279]
dotted_name [2258,2279]
===
match
---
suite [73929,74149]
suite [73881,74101]
===
match
---
not_test [13524,13553]
not_test [13524,13553]
===
match
---
name: total_ordering [3682,3696]
name: total_ordering [3682,3696]
===
match
---
name: func [77027,77031]
name: func [76979,76983]
===
match
---
name: cron [20118,20122]
name: cron [20118,20122]
===
match
---
import_from [71121,71181]
import_from [71073,71133]
===
match
---
trailer [33951,33958]
trailer [33903,33910]
===
match
---
dotted_name [2060,2081]
dotted_name [2060,2081]
===
match
---
simple_stmt [90621,90664]
simple_stmt [90573,90616]
===
match
---
expr_stmt [13363,13444]
expr_stmt [13363,13444]
===
match
---
simple_stmt [26532,26626]
simple_stmt [26484,26578]
===
match
---
if_stmt [17524,17658]
if_stmt [17524,17658]
===
match
---
name: session [47907,47914]
name: session [47859,47866]
===
match
---
operator: , [52623,52624]
operator: , [52575,52576]
===
match
---
name: cls [98215,98218]
name: cls [98167,98170]
===
match
---
atom_expr [58482,58879]
atom_expr [58434,58831]
===
match
---
name: task_concurrency [78792,78808]
name: task_concurrency [78744,78760]
===
match
---
name: self [30620,30624]
name: self [30572,30576]
===
match
---
param [48464,48487]
param [48416,48439]
===
match
---
funcdef [83459,84553]
funcdef [83411,84505]
===
match
---
trailer [66204,66211]
trailer [66156,66163]
===
match
---
atom_expr [83274,83302]
atom_expr [83226,83254]
===
match
---
operator: , [74373,74374]
operator: , [74325,74326]
===
match
---
name: session [89500,89507]
name: session [89452,89459]
===
match
---
operator: , [39605,39606]
operator: , [39557,39558]
===
match
---
name: cls [93268,93271]
name: cls [93220,93223]
===
match
---
operator: , [62286,62287]
operator: , [62238,62239]
===
match
---
operator: = [58720,58721]
operator: = [58672,58673]
===
match
---
name: __table_args__ [87870,87884]
name: __table_args__ [87822,87836]
===
match
---
simple_stmt [17115,17198]
simple_stmt [17115,17198]
===
match
---
trailer [60153,60159]
trailer [60105,60111]
===
match
---
atom_expr [13038,13061]
atom_expr [13038,13061]
===
match
---
operator: , [29443,29444]
operator: , [29395,29396]
===
match
---
return_stmt [84910,84985]
return_stmt [84862,84937]
===
match
---
simple_stmt [19345,19375]
simple_stmt [19345,19375]
===
match
---
name: val [17740,17743]
name: val [17740,17743]
===
match
---
name: naive [22462,22467]
name: naive [22438,22443]
===
match
---
atom_expr [60071,60087]
atom_expr [60023,60039]
===
match
---
name: states [82141,82147]
name: states [82093,82099]
===
match
---
dotted_name [30376,30394]
dotted_name [30328,30346]
===
match
---
operator: >= [48042,48044]
operator: >= [47994,47996]
===
match
---
name: List [44701,44705]
name: List [44653,44657]
===
match
---
trailer [83389,83395]
trailer [83341,83347]
===
match
---
name: task_dict [65039,65048]
name: task_dict [64991,65000]
===
match
---
name: croniter [20766,20774]
name: croniter [20766,20774]
===
match
---
name: qry [34265,34268]
name: qry [34217,34220]
===
match
---
atom_expr [65513,65526]
atom_expr [65465,65478]
===
match
---
trailer [77656,77662]
trailer [77608,77614]
===
match
---
suite [3518,3591]
suite [3518,3591]
===
match
---
atom_expr [77994,78007]
atom_expr [77946,77959]
===
match
---
operator: = [57085,57086]
operator: = [57037,57038]
===
match
---
atom_expr [78467,78491]
atom_expr [78419,78443]
===
match
---
trailer [47183,47240]
trailer [47135,47192]
===
match
---
argument [91278,91305]
argument [91230,91257]
===
match
---
decorator [81177,81194]
decorator [81129,81146]
===
match
---
atom_expr [44155,44228]
atom_expr [44107,44180]
===
match
---
name: task [68057,68061]
name: task [68009,68013]
===
match
---
name: t [62967,62968]
name: t [62919,62920]
===
match
---
name: _full_filepath [30034,30048]
name: _full_filepath [29986,30000]
===
match
---
suite [57484,57770]
suite [57436,57722]
===
match
---
name: DagContext [17973,17983]
name: DagContext [17973,17983]
===
match
---
operator: = [87409,87410]
operator: = [87361,87362]
===
match
---
operator: = [11967,11968]
operator: = [11967,11968]
===
match
---
simple_stmt [28071,28101]
simple_stmt [28023,28053]
===
match
---
name: str [16121,16124]
name: str [16121,16124]
===
match
---
atom_expr [15827,15851]
atom_expr [15827,15851]
===
match
---
for_stmt [64289,64741]
for_stmt [64241,64693]
===
match
---
string: 'on_success_callback' [84172,84193]
string: 'on_success_callback' [84124,84145]
===
match
---
param [36945,36949]
param [36897,36901]
===
match
---
name: session [2588,2595]
name: session [2588,2595]
===
match
---
name: self [89479,89483]
name: self [89431,89435]
===
match
---
funcdef [22814,24010]
funcdef [22766,23962]
===
match
---
param [31299,31311]
param [31251,31263]
===
match
---
name: name [96636,96640]
name: name [96588,96592]
===
match
---
trailer [11051,11061]
trailer [11051,11061]
===
match
---
name: get_is_paused [34643,34656]
name: get_is_paused [34595,34608]
===
match
---
name: clear [59410,59415]
name: clear [59362,59367]
===
match
---
string: 'test' [83670,83676]
string: 'test' [83622,83628]
===
match
---
name: include_upstream [61077,61093]
name: include_upstream [61029,61045]
===
match
---
decorated [91346,92576]
decorated [91298,92528]
===
match
---
operator: , [83826,83827]
operator: , [83778,83779]
===
match
---
fstring_end: " [68370,68371]
fstring_end: " [68322,68323]
===
match
---
operator: , [60596,60597]
operator: , [60548,60549]
===
match
---
name: used_group_ids [63252,63266]
name: used_group_ids [63204,63218]
===
match
---
name: d [77920,77921]
name: d [77872,77873]
===
match
---
name: warnings [19085,19093]
name: warnings [19085,19093]
===
match
---
name: _context_managed_dag [97848,97868]
name: _context_managed_dag [97800,97820]
===
match
---
suite [79631,79703]
suite [79583,79655]
===
match
---
name: setter [29970,29976]
name: setter [29922,29928]
===
match
---
argument [56687,56726]
argument [56639,56678]
===
match
---
expr_stmt [63560,63621]
expr_stmt [63512,63573]
===
match
---
simple_stmt [81076,81098]
simple_stmt [81028,81050]
===
match
---
name: self [10173,10177]
name: self [10173,10177]
===
match
---
name: session [76275,76282]
name: session [76227,76234]
===
match
---
param [30421,30431]
param [30373,30383]
===
match
---
for_stmt [17426,17825]
for_stmt [17426,17825]
===
match
---
trailer [77521,77527]
trailer [77473,77479]
===
match
---
argument [52582,52623]
argument [52534,52575]
===
match
---
atom [68119,68218]
atom [68071,68170]
===
match
---
comparison [32867,32897]
comparison [32819,32849]
===
match
---
operator: = [55697,55698]
operator: = [55649,55650]
===
match
---
name: self [60414,60418]
name: self [60366,60370]
===
match
---
name: jinja_environment_kwargs [11622,11646]
name: jinja_environment_kwargs [11622,11646]
===
match
---
name: airflow [1831,1838]
name: airflow [1831,1838]
===
match
---
atom_expr [88076,88147]
atom_expr [88028,88099]
===
match
---
name: kwargs [88192,88198]
name: kwargs [88144,88150]
===
match
---
param [85099,85117]
param [85051,85069]
===
match
---
trailer [82037,82044]
trailer [81989,81996]
===
match
---
fstring [16891,16914]
fstring [16891,16914]
===
match
---
name: pendulum [22939,22947]
name: pendulum [22891,22899]
===
match
---
name: callback [36429,36437]
name: callback [36381,36389]
===
match
---
trailer [13143,13150]
trailer [13143,13150]
===
match
---
trailer [80249,80266]
trailer [80201,80218]
===
match
---
trailer [76033,76038]
trailer [75985,75990]
===
match
---
operator: = [74333,74334]
operator: = [74285,74286]
===
match
---
atom_expr [60140,60161]
atom_expr [60092,60113]
===
match
---
name: cls [75322,75325]
name: cls [75274,75277]
===
match
---
not_test [25814,25844]
not_test [25766,25796]
===
match
---
operator: , [94523,94524]
operator: , [94475,94476]
===
match
---
name: DagRun [77336,77342]
name: DagRun [77288,77294]
===
match
---
trailer [72510,72515]
trailer [72462,72467]
===
match
---
operator: = [83642,83643]
operator: = [83594,83595]
===
match
---
atom_expr [35425,35447]
atom_expr [35377,35399]
===
match
---
name: self [53889,53893]
name: self [53841,53845]
===
match
---
simple_stmt [54234,54277]
simple_stmt [54186,54229]
===
match
---
trailer [77104,77111]
trailer [77056,77063]
===
match
---
trailer [31971,31973]
trailer [31923,31925]
===
match
---
name: run_backwards [71787,71800]
name: run_backwards [71739,71752]
===
match
---
trailer [42787,42807]
trailer [42739,42759]
===
match
---
operator: = [19704,19705]
operator: = [19704,19705]
===
match
---
comparison [60178,60252]
comparison [60130,60204]
===
match
---
expr_stmt [89904,90105]
expr_stmt [89856,90057]
===
match
---
name: Index [87897,87902]
name: Index [87849,87854]
===
match
---
atom_expr [33251,33259]
atom_expr [33203,33211]
===
match
---
argument [93589,93604]
argument [93541,93556]
===
match
---
name: executors [71134,71143]
name: executors [71086,71095]
===
match
---
atom_expr [26392,26430]
atom_expr [26344,26382]
===
match
---
simple_stmt [2707,2745]
simple_stmt [2707,2745]
===
match
---
name: only_running [59564,59576]
name: only_running [59516,59528]
===
match
---
comparison [52710,52741]
comparison [52662,52693]
===
match
---
comparison [40890,40929]
comparison [40842,40881]
===
match
---
name: run_type [73683,73691]
name: run_type [73635,73643]
===
match
---
name: self [13965,13969]
name: self [13965,13969]
===
match
---
operator: , [67086,67087]
operator: , [67038,67039]
===
match
---
trailer [51519,51526]
trailer [51471,51478]
===
match
---
argument [58583,58606]
argument [58535,58558]
===
match
---
parameters [71842,71848]
parameters [71794,71800]
===
match
---
trailer [13897,13903]
trailer [13897,13903]
===
match
---
operator: } [65620,65621]
operator: } [65572,65573]
===
match
---
name: datetime [43092,43100]
name: datetime [43044,43052]
===
match
---
trailer [21095,21110]
trailer [21095,21110]
===
match
---
name: dag_id [47943,47949]
name: dag_id [47895,47901]
===
match
---
name: cron_presets [35215,35227]
name: cron_presets [35167,35179]
===
match
---
name: ti [36558,36560]
name: ti [36510,36512]
===
match
---
name: downstream [55939,55949]
name: downstream [55891,55901]
===
match
---
name: last_parsed_time [86427,86443]
name: last_parsed_time [86379,86395]
===
match
---
name: get_paused_dag_ids [89625,89643]
name: get_paused_dag_ids [89577,89595]
===
match
---
operator: -> [66137,66139]
operator: -> [66089,66091]
===
match
---
simple_stmt [15743,15764]
simple_stmt [15743,15764]
===
match
---
name: max [39965,39968]
name: max [39917,39920]
===
match
---
name: order_by [93444,93452]
name: order_by [93396,93404]
===
match
---
atom_expr [80245,80283]
atom_expr [80197,80235]
===
match
---
expr_stmt [14553,14596]
expr_stmt [14553,14596]
===
match
---
name: utcnow [28302,28308]
name: utcnow [28254,28260]
===
match
---
suite [44276,44345]
suite [44228,44297]
===
match
---
trailer [79615,79630]
trailer [79567,79582]
===
match
---
string: 'fetch' [48210,48217]
string: 'fetch' [48162,48169]
===
match
---
simple_stmt [66159,66236]
simple_stmt [66111,66188]
===
match
---
atom_expr [41615,41650]
atom_expr [41567,41602]
===
match
---
atom_expr [56004,56022]
atom_expr [55956,55974]
===
match
---
operator: = [87564,87565]
operator: = [87516,87517]
===
match
---
name: DEPRECATED_ACTION_CAN_DAG_READ [18680,18710]
name: DEPRECATED_ACTION_CAN_DAG_READ [18680,18710]
===
match
---
name: Optional [97870,97878]
name: Optional [97822,97830]
===
match
---
operator: = [20006,20007]
operator: = [20006,20007]
===
match
---
trailer [30546,30564]
trailer [30498,30516]
===
match
---
name: is_paused [91255,91264]
name: is_paused [91207,91216]
===
match
---
subscriptlist [16121,16138]
subscriptlist [16121,16138]
===
match
---
operator: * [95375,95376]
operator: * [95327,95328]
===
match
---
name: functools [67064,67073]
name: functools [67016,67025]
===
match
---
atom_expr [81965,81978]
atom_expr [81917,81930]
===
match
---
name: dag [79003,79006]
name: dag [78955,78958]
===
match
---
name: task_dict [17577,17586]
name: task_dict [17577,17586]
===
match
---
string: "dag_tag" [85472,85481]
string: "dag_tag" [85424,85433]
===
match
---
trailer [59331,59341]
trailer [59283,59293]
===
match
---
operator: = [48286,48287]
operator: = [48238,48239]
===
match
---
name: timezone [13169,13177]
name: timezone [13169,13177]
===
match
---
name: Session [38258,38265]
name: Session [38210,38217]
===
match
---
name: run_type [74596,74604]
name: run_type [74548,74556]
===
match
---
expr_stmt [57497,57537]
expr_stmt [57449,57489]
===
match
---
name: instance [21942,21950]
name: instance [21918,21926]
===
match
---
name: graph_sorted [47032,47044]
name: graph_sorted [46984,46996]
===
match
---
operator: = [51998,51999]
operator: = [51950,51951]
===
match
---
operator: = [85542,85543]
operator: = [85494,85495]
===
match
---
param [44455,44459]
param [44407,44411]
===
match
---
fstring_string: ' has already been added to the DAG [68335,68370]
fstring_string: ' has already been added to the DAG [68287,68322]
===
match
---
expr_stmt [59133,59177]
expr_stmt [59085,59129]
===
match
---
trailer [93353,93355]
trailer [93305,93307]
===
match
---
expr_stmt [43526,43566]
expr_stmt [43478,43518]
===
match
---
name: dag_model [92345,92354]
name: dag_model [92297,92306]
===
match
---
trailer [94132,94157]
trailer [94084,94109]
===
match
---
parameters [30937,30943]
parameters [30889,30895]
===
match
---
name: filter_query [90996,91008]
name: filter_query [90948,90960]
===
match
---
name: state [44172,44177]
name: state [44124,44129]
===
match
---
name: full_filepath [29956,29969]
name: full_filepath [29908,29921]
===
match
---
operator: = [87727,87728]
operator: = [87679,87680]
===
match
---
simple_stmt [78467,78512]
simple_stmt [78419,78464]
===
match
---
trailer [41270,41282]
trailer [41222,41234]
===
match
---
atom_expr [88833,88865]
atom_expr [88785,88817]
===
match
---
parameters [80000,80020]
parameters [79952,79972]
===
match
---
param [65269,65274]
param [65221,65226]
===
match
---
atom_expr [85493,85530]
atom_expr [85445,85482]
===
match
---
name: warn [88331,88335]
name: warn [88283,88287]
===
match
---
name: discard [63694,63701]
name: discard [63646,63653]
===
match
---
name: sql [1574,1577]
name: sql [1574,1577]
===
match
---
return_stmt [64020,64033]
return_stmt [63972,63985]
===
match
---
arglist [83233,83302]
arglist [83185,83254]
===
match
---
funcdef [68909,71830]
funcdef [68861,71782]
===
match
---
decorated [47405,48219]
decorated [47357,48171]
===
match
---
operator: @ [31000,31001]
operator: @ [30952,30953]
===
match
---
name: Text [87272,87276]
name: Text [87224,87228]
===
match
---
name: session [82154,82161]
name: session [82106,82113]
===
match
---
atom_expr [67716,67731]
atom_expr [67668,67683]
===
match
---
atom_expr [66927,66937]
atom_expr [66879,66889]
===
match
---
operator: , [18824,18825]
operator: , [18824,18825]
===
match
---
expr_stmt [28173,28249]
expr_stmt [28125,28201]
===
match
---
operator: = [43041,43042]
operator: = [42993,42994]
===
match
---
atom_expr [18753,18795]
atom_expr [18753,18795]
===
match
---
name: functools [3672,3681]
name: functools [3672,3681]
===
match
---
expr_stmt [18935,19018]
expr_stmt [18935,19018]
===
match
---
atom_expr [78748,78783]
atom_expr [78700,78735]
===
match
---
name: self [29439,29443]
name: self [29391,29395]
===
match
---
trailer [66850,66866]
trailer [66802,66818]
===
match
---
operator: = [60111,60112]
operator: = [60063,60064]
===
match
---
atom_expr [68414,68426]
atom_expr [68366,68378]
===
match
---
name: clear [51961,51966]
name: clear [51913,51918]
===
match
---
name: downstream [55606,55616]
name: downstream [55558,55568]
===
match
---
trailer [73959,73981]
trailer [73911,73933]
===
match
---
trailer [82833,82900]
trailer [82785,82852]
===
match
---
operator: == [55134,55136]
operator: == [55086,55088]
===
match
---
operator: } [65675,65676]
operator: } [65627,65628]
===
match
---
operator: = [62340,62341]
operator: = [62292,62293]
===
match
---
name: external_tis [54919,54931]
name: external_tis [54871,54883]
===
match
---
trailer [79667,79702]
trailer [79619,79654]
===
match
---
simple_stmt [54873,54895]
simple_stmt [54825,54847]
===
match
---
argument [74562,74573]
argument [74514,74525]
===
match
---
simple_stmt [63308,63344]
simple_stmt [63260,63296]
===
match
---
expr_stmt [21067,21118]
expr_stmt [21067,21118]
===
match
---
operator: == [54998,55000]
operator: == [54950,54952]
===
match
---
atom_expr [65881,65910]
atom_expr [65833,65862]
===
match
---
operator: , [69187,69188]
operator: , [69139,69140]
===
match
---
funcdef [19380,19760]
funcdef [19380,19760]
===
match
---
trailer [60390,60411]
trailer [60342,60363]
===
match
---
decorator [30062,30072]
decorator [30014,30024]
===
match
---
argument [78790,78839]
argument [78742,78791]
===
match
---
name: TYPE_CHECKING [2806,2819]
name: TYPE_CHECKING [2806,2819]
===
match
---
trailer [55541,55577]
trailer [55493,55529]
===
match
---
comparison [89986,90025]
comparison [89938,89977]
===
match
---
operator: = [76978,76979]
operator: = [76930,76931]
===
match
---
atom_expr [51383,51411]
atom_expr [51335,51363]
===
match
---
not_test [55469,55485]
not_test [55421,55437]
===
match
---
expr_stmt [78345,78374]
expr_stmt [78297,78326]
===
match
---
argument [56060,56087]
argument [56012,56039]
===
match
---
name: utils [2632,2637]
name: utils [2632,2637]
===
match
---
name: copy [63216,63220]
name: copy [63168,63172]
===
match
---
name: include_subdags [52213,52228]
name: include_subdags [52165,52180]
===
match
---
or_test [28275,28310]
or_test [28227,28262]
===
match
---
name: pickle [66400,66406]
name: pickle [66352,66358]
===
match
---
operator: = [29856,29857]
operator: = [29808,29809]
===
match
---
name: env [42491,42494]
name: env [42443,42446]
===
match
---
name: default_view [90505,90517]
name: default_view [90457,90469]
===
match
---
name: schedule_interval [23385,23402]
name: schedule_interval [23337,23354]
===
match
---
trailer [16513,16550]
trailer [16513,16550]
===
match
---
import_from [1558,1595]
import_from [1558,1595]
===
match
---
atom_expr [72502,72515]
atom_expr [72454,72467]
===
match
---
name: str [32104,32107]
name: str [32056,32059]
===
match
---
operator: = [36566,36567]
operator: = [36518,36519]
===
match
---
trailer [81661,81678]
trailer [81613,81630]
===
match
---
trailer [57678,57685]
trailer [57630,57637]
===
match
---
import_from [2569,2618]
import_from [2569,2618]
===
match
---
name: task_ids [51592,51600]
name: task_ids [51544,51552]
===
match
---
name: dags [79891,79895]
name: dags [79843,79847]
===
match
---
operator: = [75293,75294]
operator: = [75245,75246]
===
match
---
name: include_subdags [53112,53127]
name: include_subdags [53064,53079]
===
match
---
operator: = [66002,66003]
operator: = [65954,65955]
===
match
---
atom_expr [30855,30902]
atom_expr [30807,30854]
===
match
---
operator: , [73729,73730]
operator: , [73681,73682]
===
match
---
name: self [40084,40088]
name: self [40036,40040]
===
match
---
simple_stmt [18088,18125]
simple_stmt [18088,18125]
===
match
---
operator: = [89919,89920]
operator: = [89871,89872]
===
match
---
atom_expr [33263,33276]
atom_expr [33215,33228]
===
match
---
name: not_none_state [44182,44196]
name: not_none_state [44134,44148]
===
match
---
operator: -> [30098,30100]
operator: -> [30050,30052]
===
match
---
name: Optional [1140,1148]
name: Optional [1140,1148]
===
match
---
name: catchup [11226,11233]
name: catchup [11226,11233]
===
match
---
string: 'start_date' [13430,13442]
string: 'start_date' [13430,13442]
===
match
---
trailer [77924,77931]
trailer [77876,77883]
===
match
---
name: next_run_date [26171,26184]
name: next_run_date [26123,26136]
===
match
---
trailer [65814,65828]
trailer [65766,65780]
===
match
---
name: self [14006,14010]
name: self [14006,14010]
===
match
---
fstring_start: f' [15553,15555]
fstring_start: f' [15553,15555]
===
match
---
if_stmt [54302,54849]
if_stmt [54254,54801]
===
match
---
name: self [14895,14899]
name: self [14895,14899]
===
match
---
operator: ~ [81019,81020]
operator: ~ [80971,80972]
===
match
---
name: dag [81124,81127]
name: dag [81076,81079]
===
match
---
simple_stmt [23588,23608]
simple_stmt [23540,23560]
===
match
---
atom_expr [14449,14471]
atom_expr [14449,14471]
===
match
---
suite [60509,60546]
suite [60461,60498]
===
match
---
name: include_parentdag [58754,58771]
name: include_parentdag [58706,58723]
===
match
---
name: ID_LEN [85870,85876]
name: ID_LEN [85822,85828]
===
match
---
trailer [34008,34018]
trailer [33960,33970]
===
match
---
comparison [43177,43211]
comparison [43129,43163]
===
match
---
name: all [82971,82974]
name: all [82923,82926]
===
match
---
simple_stmt [51425,51460]
simple_stmt [51377,51412]
===
match
---
trailer [89695,89700]
trailer [89647,89652]
===
match
---
operator: = [65127,65128]
operator: = [65079,65080]
===
match
---
name: self [94727,94731]
name: self [94679,94683]
===
match
---
trailer [60528,60533]
trailer [60480,60485]
===
match
---
name: ti [53966,53968]
name: ti [53918,53920]
===
match
---
operator: = [77912,77913]
operator: = [77864,77865]
===
match
---
comparison [51656,51683]
comparison [51608,51635]
===
match
---
operator: , [10526,10527]
operator: , [10526,10527]
===
match
---
trailer [30895,30902]
trailer [30847,30854]
===
match
---
name: provide_session [33751,33766]
name: provide_session [33703,33718]
===
match
---
comparison [27383,27416]
comparison [27335,27368]
===
match
---
string: """         Returns edge information for the given pair of tasks if present, and         None if there is no information.         """ [84655,84788]
string: """         Returns edge information for the given pair of tasks if present, and         None if there is no information.         """ [84607,84740]
===
match
---
name: property [32334,32342]
name: property [32286,32294]
===
match
---
suite [3218,3669]
suite [3218,3669]
===
match
---
simple_stmt [94624,94661]
simple_stmt [94576,94613]
===
match
---
name: self [16804,16808]
name: self [16804,16808]
===
match
---
trailer [26593,26625]
trailer [26545,26577]
===
match
---
name: d [65813,65814]
name: d [65765,65766]
===
match
---
name: jinja_env_options [41571,41588]
name: jinja_env_options [41523,41540]
===
match
---
operator: , [52462,52463]
operator: , [52414,52415]
===
match
---
trailer [12188,12217]
trailer [12188,12217]
===
match
---
atom_expr [32190,32248]
atom_expr [32142,32200]
===
match
---
param [60591,60597]
param [60543,60549]
===
match
---
atom_expr [78954,78964]
atom_expr [78906,78916]
===
match
---
atom_expr [14006,14021]
atom_expr [14006,14021]
===
match
---
name: dags [74997,75001]
name: dags [74949,74953]
===
match
---
number: 1 [56648,56649]
number: 1 [56600,56601]
===
match
---
parameters [33788,33808]
parameters [33740,33760]
===
match
---
trailer [47942,47949]
trailer [47894,47901]
===
match
---
name: self [25425,25429]
name: self [25377,25381]
===
match
---
string: 'tree' [2989,2995]
string: 'tree' [2989,2995]
===
match
---
operator: { [63375,63376]
operator: { [63327,63328]
===
match
---
name: next_dagrun [87715,87726]
name: next_dagrun [87667,87678]
===
match
---
name: Set [89692,89695]
name: Set [89644,89647]
===
match
---
name: tasks [44867,44872]
name: tasks [44819,44824]
===
match
---
string: 'task_ids' [9918,9928]
string: 'task_ids' [9918,9928]
===
match
---
name: tags [79242,79246]
name: tags [79194,79198]
===
match
---
name: __name__ [40901,40909]
name: __name__ [40853,40861]
===
match
---
simple_stmt [20233,20245]
simple_stmt [20233,20245]
===
match
---
name: airflow [1627,1634]
name: airflow [1627,1634]
===
match
---
name: executor [71406,71414]
name: executor [71358,71366]
===
match
---
trailer [63964,63973]
trailer [63916,63925]
===
match
---
trailer [35231,35255]
trailer [35183,35207]
===
match
---
not_test [55281,55292]
not_test [55233,55244]
===
match
---
name: RUNNING [53015,53022]
name: RUNNING [52967,52974]
===
match
---
argument [58667,58687]
argument [58619,58639]
===
match
---
arglist [76748,76785]
arglist [76700,76737]
===
match
---
import_as_names [967,986]
import_as_names [967,986]
===
match
---
trailer [62959,62980]
trailer [62911,62932]
===
match
---
operator: = [59447,59448]
operator: = [59399,59400]
===
match
---
trailer [87572,87597]
trailer [87524,87549]
===
match
---
classdef [3697,85357]
classdef [3697,85309]
===
match
---
argument [76275,76290]
argument [76227,76242]
===
match
---
string: """This is only there for backward compatible jinja2 templates""" [80325,80390]
string: """This is only there for backward compatible jinja2 templates""" [80277,80342]
===
match
---
name: has_task_concurrency_limits [88709,88736]
name: has_task_concurrency_limits [88661,88688]
===
match
---
operator: , [93604,93605]
operator: , [93556,93557]
===
match
---
atom_expr [47642,47651]
atom_expr [47594,47603]
===
match
---
operator: = [22578,22579]
operator: = [22530,22531]
===
match
---
operator: , [71287,71288]
operator: , [71239,71240]
===
match
---
name: dagrun [36457,36463]
name: dagrun [36409,36415]
===
match
---
name: dag_id [78958,78964]
name: dag_id [78910,78916]
===
match
---
suite [63933,64007]
suite [63885,63959]
===
match
---
argument [58548,58565]
argument [58500,58517]
===
match
---
test [26548,26625]
test [26500,26577]
===
match
---
name: all [39738,39741]
name: all [39690,39693]
===
match
---
atom_expr [51637,51651]
atom_expr [51589,51603]
===
match
---
name: task_id [68327,68334]
name: task_id [68279,68286]
===
match
---
arglist [82851,82886]
arglist [82803,82838]
===
match
---
name: self [19404,19408]
name: self [19404,19408]
===
match
---
param [10724,10760]
param [10724,10760]
===
match
---
atom_expr [21096,21109]
atom_expr [21096,21109]
===
match
---
atom_expr [32273,32298]
atom_expr [32225,32250]
===
match
---
name: child [63459,63464]
name: child [63411,63416]
===
match
---
tfpdef [10536,10584]
tfpdef [10536,10584]
===
match
---
return_stmt [60883,60926]
return_stmt [60835,60878]
===
match
---
name: num [19701,19704]
name: num [19701,19704]
===
match
---
name: group [63088,63093]
name: group [63040,63045]
===
match
---
string: 'start_date' [13326,13338]
string: 'start_date' [13326,13338]
===
match
---
name: DateTime [93740,93748]
name: DateTime [93692,93700]
===
match
---
return_stmt [28772,28788]
return_stmt [28724,28740]
===
match
---
simple_stmt [48154,48219]
simple_stmt [48106,48171]
===
match
---
name: exclude_task_ids [57126,57142]
name: exclude_task_ids [57078,57094]
===
match
---
operator: = [10402,10403]
operator: = [10402,10403]
===
match
---
name: access_control [18899,18913]
name: access_control [18899,18913]
===
match
---
operator: , [63093,63094]
operator: , [63045,63046]
===
match
---
trailer [11496,11502]
trailer [11496,11502]
===
match
---
atom_expr [26041,26062]
atom_expr [25993,26014]
===
match
---
atom_expr [86798,86813]
atom_expr [86750,86765]
===
match
---
name: dag [57885,57888]
name: dag [57837,57840]
===
match
---
trailer [93250,93430]
trailer [93202,93382]
===
match
---
name: cls [93373,93376]
name: cls [93325,93328]
===
match
---
name: filtered_child [63909,63923]
name: filtered_child [63861,63875]
===
match
---
name: reason [36695,36701]
name: reason [36647,36653]
===
match
---
name: session [93589,93596]
name: session [93541,93548]
===
match
---
if_stmt [65066,65134]
if_stmt [65018,65086]
===
match
---
name: dag_id [89306,89312]
name: dag_id [89258,89264]
===
match
---
name: tuple [45753,45758]
name: tuple [45705,45710]
===
match
---
name: end_date [59489,59497]
name: end_date [59441,59449]
===
match
---
trailer [65001,65021]
trailer [64953,64973]
===
match
---
name: value [30896,30901]
name: value [30848,30853]
===
match
---
param [10373,10409]
param [10373,10409]
===
match
---
param [30620,30625]
param [30572,30577]
===
match
---
name: print [59836,59841]
name: print [59788,59793]
===
match
---
name: timezone [25253,25261]
name: timezone [25205,25213]
===
match
---
trailer [81616,81622]
trailer [81568,81574]
===
match
---
trailer [76196,76200]
trailer [76148,76152]
===
match
---
atom_expr [78688,78712]
atom_expr [78640,78664]
===
match
---
atom_expr [17122,17197]
atom_expr [17122,17197]
===
match
---
operator: , [84232,84233]
operator: , [84184,84185]
===
match
---
sync_comp_for [65230,65249]
sync_comp_for [65182,65201]
===
match
---
comparison [39000,39023]
comparison [38952,38975]
===
match
---
operator: = [20704,20705]
operator: = [20704,20705]
===
match
---
trailer [81123,81128]
trailer [81075,81080]
===
match
---
expr_stmt [86667,86701]
expr_stmt [86619,86653]
===
match
---
trailer [13764,13776]
trailer [13764,13776]
===
match
---
parameters [30715,30721]
parameters [30667,30673]
===
match
---
atom [38633,38659]
atom [38585,38611]
===
match
---
name: self [21263,21267]
name: self [21245,21249]
===
match
---
simple_stmt [800,817]
simple_stmt [800,817]
===
match
---
trailer [82712,82720]
trailer [82664,82672]
===
match
---
simple_stmt [39494,39754]
simple_stmt [39446,39706]
===
match
---
name: self [30647,30651]
name: self [30599,30603]
===
match
---
name: utils [2720,2725]
name: utils [2720,2725]
===
match
---
operator: , [86368,86369]
operator: , [86320,86321]
===
match
---
trailer [76108,76116]
trailer [76060,76068]
===
match
---
simple_stmt [3223,3404]
simple_stmt [3223,3404]
===
match
---
trailer [23642,23665]
trailer [23594,23617]
===
match
---
name: external_task [53162,53175]
name: external_task [53114,53127]
===
match
---
name: parent_dag [78165,78175]
name: parent_dag [78117,78127]
===
match
---
name: models [97198,97204]
name: models [97150,97156]
===
match
---
name: orm_dag [78688,78695]
name: orm_dag [78640,78647]
===
match
---
name: max_recursion_depth [54234,54253]
name: max_recursion_depth [54186,54205]
===
match
---
atom_expr [60684,60874]
atom_expr [60636,60826]
===
match
---
trailer [80927,80943]
trailer [80879,80895]
===
match
---
trailer [83683,83685]
trailer [83635,83637]
===
match
---
atom_expr [67270,67285]
atom_expr [67222,67237]
===
match
---
operator: = [74758,74759]
operator: = [74710,74711]
===
match
---
trailer [19986,19990]
trailer [19986,19990]
===
match
---
name: t [64754,64755]
name: t [64706,64707]
===
match
---
expr_stmt [85486,85530]
expr_stmt [85438,85482]
===
match
---
param [68685,68690]
param [68637,68642]
===
match
---
trailer [85506,85511]
trailer [85458,85463]
===
match
---
simple_stmt [74725,74741]
simple_stmt [74677,74693]
===
match
---
name: execution_date [48027,48041]
name: execution_date [47979,47993]
===
match
---
suite [29100,29130]
suite [29052,29082]
===
match
---
name: self [32740,32744]
name: self [32692,32696]
===
match
---
operator: += [62625,62627]
operator: += [62577,62579]
===
match
---
suite [85119,85357]
suite [85071,85309]
===
match
---
name: find [37108,37112]
name: find [37060,37064]
===
match
---
name: airflow [2418,2425]
name: airflow [2418,2425]
===
match
---
raise_stmt [67323,67389]
raise_stmt [67275,67341]
===
match
---
atom_expr [79154,79177]
atom_expr [79106,79129]
===
match
---
name: os [32273,32275]
name: os [32225,32227]
===
match
---
if_stmt [25390,25581]
if_stmt [25342,25533]
===
match
---
atom_expr [55137,55172]
atom_expr [55089,55124]
===
match
---
atom_expr [77176,77191]
atom_expr [77128,77143]
===
match
---
trailer [42070,42091]
trailer [42022,42043]
===
match
---
operator: @ [37292,37293]
operator: @ [37244,37245]
===
match
---
name: TI [51517,51519]
name: TI [51469,51471]
===
match
---
name: external_task_id [55070,55086]
name: external_task_id [55022,55038]
===
match
---
trailer [47385,47399]
trailer [47337,47351]
===
match
---
trailer [68626,68637]
trailer [68578,68589]
===
match
---
name: property [30909,30917]
name: property [30861,30869]
===
match
---
and_test [13211,13280]
and_test [13211,13280]
===
match
---
name: dry_run [58396,58403]
name: dry_run [58348,58355]
===
match
---
name: d [65685,65686]
name: d [65637,65638]
===
match
---
fstring_end: " [59286,59287]
fstring_end: " [59238,59239]
===
match
---
operator: = [60349,60350]
operator: = [60301,60302]
===
match
---
operator: { [91245,91246]
operator: { [91197,91198]
===
match
---
simple_stmt [76009,76042]
simple_stmt [75961,75994]
===
match
---
trailer [55342,55366]
trailer [55294,55318]
===
match
---
operator: , [83996,83997]
operator: , [83948,83949]
===
match
---
name: context [36606,36613]
name: context [36558,36565]
===
match
---
simple_stmt [39863,39931]
simple_stmt [39815,39883]
===
match
---
decorator [44667,44677]
decorator [44619,44629]
===
match
---
name: Union [60993,60998]
name: Union [60945,60950]
===
match
---
operator: , [58834,58835]
operator: , [58786,58787]
===
match
---
trailer [18122,18124]
trailer [18122,18124]
===
match
---
atom_expr [44314,44343]
atom_expr [44266,44295]
===
match
---
operator: = [16604,16605]
operator: = [16604,16605]
===
match
---
operator: = [12926,12927]
operator: = [12926,12927]
===
match
---
trailer [83039,83069]
trailer [82991,83021]
===
match
---
trailer [78352,78360]
trailer [78304,78312]
===
match
---
name: stacklevel [47824,47834]
name: stacklevel [47776,47786]
===
match
---
atom_expr [17973,18014]
atom_expr [17973,18014]
===
match
---
atom_expr [30347,30369]
atom_expr [30299,30321]
===
match
---
simple_stmt [63357,63378]
simple_stmt [63309,63330]
===
match
---
trailer [13367,13380]
trailer [13367,13380]
===
match
---
arglist [38970,39023]
arglist [38922,38975]
===
match
---
trailer [82722,82729]
trailer [82674,82681]
===
match
---
comparison [93268,93303]
comparison [93220,93255]
===
match
---
trailer [87350,87362]
trailer [87302,87314]
===
match
---
name: str [65187,65190]
name: str [65139,65142]
===
match
---
trailer [98572,98593]
trailer [98524,98545]
===
match
---
name: update [12182,12188]
name: update [12182,12188]
===
match
---
name: acyclic [46653,46660]
name: acyclic [46605,46612]
===
match
---
suite [51684,52657]
suite [51636,52609]
===
match
---
trailer [66476,66480]
trailer [66428,66432]
===
match
---
name: dag_id [82118,82124]
name: dag_id [82070,82076]
===
match
---
simple_stmt [41292,41326]
simple_stmt [41244,41278]
===
match
---
name: execution_date [56073,56087]
name: execution_date [56025,56039]
===
match
---
name: classmethod [98495,98506]
name: classmethod [98447,98458]
===
match
---
name: stacklevel [60851,60861]
name: stacklevel [60803,60813]
===
match
---
comparison [26980,27009]
comparison [26932,26961]
===
match
---
simple_stmt [78391,78418]
simple_stmt [78343,78370]
===
match
---
argument [71722,71759]
argument [71674,71711]
===
match
---
funcdef [88878,88937]
funcdef [88830,88889]
===
match
---
arglist [47710,47837]
arglist [47662,47789]
===
match
---
operator: @ [29706,29707]
operator: @ [29658,29659]
===
match
---
name: List [47642,47646]
name: List [47594,47598]
===
match
---
trailer [85499,85530]
trailer [85451,85482]
===
match
---
name: str [38219,38222]
name: str [38171,38174]
===
match
---
operator: = [71256,71257]
operator: = [71208,71209]
===
match
---
funcdef [29797,29864]
funcdef [29749,29816]
===
match
---
name: task_ids_or_regex [62269,62286]
name: task_ids_or_regex [62221,62238]
===
match
---
or_test [13524,13574]
or_test [13524,13574]
===
match
---
operator: , [52560,52561]
operator: , [52512,52513]
===
match
---
trailer [83203,83325]
trailer [83155,83277]
===
match
---
arglist [54724,54784]
arglist [54676,54736]
===
match
---
expr_stmt [71195,71243]
expr_stmt [71147,71195]
===
match
---
return_stmt [17833,17868]
return_stmt [17833,17868]
===
match
---
trailer [60293,60302]
trailer [60245,60254]
===
match
---
return_stmt [58077,58089]
return_stmt [58029,58041]
===
match
---
expr_stmt [97251,97309]
expr_stmt [97203,97261]
===
match
---
trailer [43109,43111]
trailer [43061,43063]
===
match
---
name: t [62935,62936]
name: t [62887,62888]
===
match
---
trailer [15467,15614]
trailer [15467,15614]
===
match
---
trailer [68242,68254]
trailer [68194,68206]
===
match
---
suite [88305,88587]
suite [88257,88539]
===
match
---
operator: = [34077,34078]
operator: = [34029,34030]
===
match
---
strings [19116,19254]
strings [19116,19254]
===
match
---
number: 0 [79015,79016]
number: 0 [78967,78968]
===
match
---
name: self [20775,20779]
name: self [20775,20779]
===
match
---
name: self [72117,72121]
name: self [72069,72073]
===
match
---
name: self [51314,51318]
name: self [51266,51270]
===
match
---
trailer [77182,77191]
trailer [77134,77143]
===
match
---
expr_stmt [68399,68434]
expr_stmt [68351,68386]
===
match
---
name: task_dict [65364,65373]
name: task_dict [65316,65325]
===
match
---
param [47633,47659]
param [47585,47611]
===
match
---
if_stmt [53364,56981]
if_stmt [53316,56933]
===
match
---
name: subdag_task_groups [64408,64426]
name: subdag_task_groups [64360,64378]
===
match
---
suite [98327,98408]
suite [98279,98360]
===
match
---
param [58296,58317]
param [58248,58269]
===
match
---
trailer [77073,77080]
trailer [77025,77032]
===
match
---
atom [60187,60252]
atom [60139,60204]
===
match
---
atom_expr [38249,38266]
atom_expr [38201,38218]
===
match
---
name: self [36318,36322]
name: self [36270,36274]
===
match
---
operator: , [1400,1401]
operator: , [1400,1401]
===
match
---
expr_stmt [88551,88586]
expr_stmt [88503,88538]
===
match
---
name: utils_date_range [2396,2412]
name: utils_date_range [2396,2412]
===
match
---
simple_stmt [93798,94102]
simple_stmt [93750,94054]
===
match
---
name: query [81617,81622]
name: query [81569,81574]
===
match
---
param [48635,48660]
param [48587,48612]
===
match
---
operator: , [17165,17166]
operator: , [17165,17166]
===
match
---
comparison [65502,65526]
comparison [65454,65478]
===
match
---
not_test [70947,70959]
not_test [70899,70911]
===
match
---
simple_stmt [51259,51275]
simple_stmt [51211,51227]
===
match
---
atom_expr [68183,68195]
atom_expr [68135,68147]
===
match
---
argument [59706,59733]
argument [59658,59685]
===
match
---
trailer [42452,42473]
trailer [42404,42425]
===
match
---
argument [56511,56523]
argument [56463,56475]
===
match
---
operator: , [31212,31213]
operator: , [31164,31165]
===
match
---
expr_stmt [66022,66062]
expr_stmt [65974,66014]
===
match
---
name: start_date [58520,58530]
name: start_date [58472,58482]
===
match
---
sync_comp_for [44064,44083]
sync_comp_for [44016,44035]
===
match
---
funcdef [28794,29151]
funcdef [28746,29103]
===
match
---
fstring_end: " [88935,88936]
fstring_end: " [88887,88888]
===
match
---
operator: @ [88942,88943]
operator: @ [88894,88895]
===
match
---
name: dag_id [38992,38998]
name: dag_id [38944,38950]
===
match
---
trailer [20670,20679]
trailer [20670,20679]
===
match
---
atom_expr [98539,98552]
atom_expr [98491,98504]
===
match
---
name: mark_success [71367,71379]
name: mark_success [71319,71331]
===
match
---
name: only_failed [59519,59530]
name: only_failed [59471,59482]
===
match
---
trailer [40006,40013]
trailer [39958,39965]
===
match
---
name: task_id [46800,46807]
name: task_id [46752,46759]
===
match
---
trailer [71079,71081]
trailer [71031,71033]
===
match
---
operator: = [40707,40708]
operator: = [40659,40660]
===
match
---
trailer [76716,76721]
trailer [76668,76673]
===
match
---
param [11679,11723]
param [11679,11723]
===
match
---
operator: = [51846,51847]
operator: = [51798,51799]
===
match
---
suite [24871,24896]
suite [24823,24848]
===
match
---
simple_stmt [90794,90988]
simple_stmt [90746,90940]
===
match
---
trailer [90062,90066]
trailer [90014,90018]
===
match
---
tfpdef [30626,30636]
tfpdef [30578,30588]
===
match
---
atom_expr [11591,11605]
atom_expr [11591,11605]
===
match
---
simple_stmt [73834,73888]
simple_stmt [73786,73840]
===
match
---
param [69325,69345]
param [69277,69297]
===
match
---
operator: * [94755,94756]
operator: * [94707,94708]
===
match
---
trailer [21996,22017]
trailer [21972,21993]
===
match
---
operator: * [66784,66785]
operator: * [66736,66737]
===
match
---
name: dag_ids [90067,90074]
name: dag_ids [90019,90026]
===
match
---
name: include_upstream [62578,62594]
name: include_upstream [62530,62546]
===
match
---
atom_expr [83618,83641]
atom_expr [83570,83593]
===
match
---
name: self [13022,13026]
name: self [13022,13026]
===
match
---
name: default [86170,86177]
name: default [86122,86129]
===
match
---
simple_stmt [95965,96009]
simple_stmt [95917,95961]
===
match
---
simple_stmt [28838,28919]
simple_stmt [28790,28871]
===
match
---
operator: , [35567,35568]
operator: , [35519,35520]
===
match
---
decorated [83442,84553]
decorated [83394,84505]
===
match
---
arglist [33534,33688]
arglist [33486,33640]
===
match
---
if_stmt [24684,24757]
if_stmt [24636,24709]
===
match
---
simple_stmt [63560,63622]
simple_stmt [63512,63574]
===
match
---
name: timezone [14385,14393]
name: timezone [14385,14393]
===
match
---
trailer [19546,19556]
trailer [19546,19556]
===
match
---
suite [94280,94661]
suite [94232,94613]
===
match
---
trailer [67882,67891]
trailer [67834,67843]
===
match
---
trailer [38778,38786]
trailer [38730,38738]
===
match
---
name: self [12234,12238]
name: self [12234,12238]
===
match
---
simple_stmt [2253,2301]
simple_stmt [2253,2301]
===
match
---
fstring_end: " [73819,73820]
fstring_end: " [73771,73772]
===
match
---
parameters [89069,89091]
parameters [89021,89043]
===
match
---
name: schedule_interval [87391,87408]
name: schedule_interval [87343,87360]
===
match
---
trailer [29764,29772]
trailer [29716,29724]
===
match
---
trailer [93739,93748]
trailer [93691,93700]
===
match
---
name: isinstance [13297,13307]
name: isinstance [13297,13307]
===
match
---
operator: , [84455,84456]
operator: , [84407,84408]
===
match
---
argument [47213,47238]
argument [47165,47190]
===
match
---
trailer [32478,32492]
trailer [32430,32444]
===
match
---
string: 'duration' [3006,3016]
string: 'duration' [3006,3016]
===
match
---
param [32958,32970]
param [32910,32922]
===
match
---
simple_stmt [41571,41786]
simple_stmt [41523,41738]
===
match
---
name: datetime [951,959]
name: datetime [951,959]
===
match
---
argument [58807,58834]
argument [58759,58786]
===
match
---
operator: + [32238,32239]
operator: + [32190,32191]
===
match
---
name: pickle_id [66577,66586]
name: pickle_id [66529,66538]
===
match
---
atom_expr [10493,10518]
atom_expr [10493,10518]
===
match
---
param [19418,19439]
param [19418,19439]
===
match
---
funcdef [41127,41229]
funcdef [41079,41181]
===
match
---
param [48585,48599]
param [48537,48551]
===
match
---
trailer [10790,10795]
trailer [10790,10795]
===
match
---
trailer [63251,63266]
trailer [63203,63218]
===
match
---
name: task [68012,68016]
name: task [67964,67968]
===
match
---
param [35534,35541]
param [35486,35493]
===
match
---
tfpdef [65178,65190]
tfpdef [65130,65142]
===
match
---
trailer [20087,20097]
trailer [20087,20097]
===
match
---
operator: } [84983,84984]
operator: } [84935,84936]
===
match
---
expr_stmt [62409,62426]
expr_stmt [62361,62378]
===
match
---
operator: @ [30570,30571]
operator: @ [30522,30523]
===
match
---
name: dag_id [77971,77977]
name: dag_id [77923,77929]
===
match
---
string: """Returns a boolean indicating whether this DAG is paused""" [34111,34172]
string: """Returns a boolean indicating whether this DAG is paused""" [34063,34124]
===
match
---
atom_expr [21263,21281]
atom_expr [21245,21258]
===
match
---
name: end_date [47588,47596]
name: end_date [47540,47548]
===
match
---
if_stmt [73942,74079]
if_stmt [73894,74031]
===
match
---
atom_expr [95231,95254]
atom_expr [95183,95206]
===
match
---
trailer [65094,65100]
trailer [65046,65052]
===
match
---
suite [19585,19614]
suite [19585,19614]
===
match
---
operator: = [76324,76325]
operator: = [76276,76277]
===
match
---
string: "You must provide either the execution_date or the run_id" [38689,38747]
string: "You must provide either the execution_date or the run_id" [38641,38699]
===
match
---
name: tree_view [66623,66632]
name: tree_view [66575,66584]
===
match
---
operator: , [93689,93690]
operator: , [93641,93642]
===
match
---
import_from [2055,2095]
import_from [2055,2095]
===
match
---
operator: , [71656,71657]
operator: , [71608,71609]
===
match
---
operator: , [68955,68956]
operator: , [68907,68908]
===
match
---
trailer [89289,89294]
trailer [89241,89246]
===
match
---
simple_stmt [34631,34659]
simple_stmt [34583,34611]
===
match
---
expr_stmt [63958,64006]
expr_stmt [63910,63958]
===
match
---
simple_stmt [68563,68613]
simple_stmt [68515,68565]
===
match
---
expr_stmt [76050,76220]
expr_stmt [76002,76172]
===
match
---
name: warnings [40209,40217]
name: warnings [40161,40169]
===
match
---
trailer [43986,43992]
trailer [43938,43944]
===
match
---
name: task_ids_or_regex [51753,51770]
name: task_ids_or_regex [51705,51722]
===
match
---
name: user_defined_filters [11920,11940]
name: user_defined_filters [11920,11940]
===
match
---
operator: = [86177,86178]
operator: = [86129,86130]
===
match
---
name: dag [51369,51372]
name: dag [51321,51324]
===
match
---
name: airflow [70988,70995]
name: airflow [70940,70947]
===
match
---
atom_expr [77514,77857]
atom_expr [77466,77809]
===
match
---
name: default_view [80407,80419]
name: default_view [80359,80371]
===
match
---
arglist [20017,20055]
arglist [20017,20055]
===
match
---
trailer [51931,51937]
trailer [51883,51889]
===
match
---
operator: = [88866,88867]
operator: = [88818,88819]
===
match
---
atom_expr [17635,17657]
atom_expr [17635,17657]
===
match
---
suite [47674,48219]
suite [47626,48171]
===
match
---
operator: , [1428,1429]
operator: , [1428,1429]
===
match
---
name: creating_job_id [74665,74680]
name: creating_job_id [74617,74632]
===
match
---
trailer [51138,51144]
trailer [51090,51096]
===
match
---
atom_expr [68168,68196]
atom_expr [68120,68148]
===
match
---
suite [42563,42809]
suite [42515,42761]
===
match
---
simple_stmt [37218,37258]
simple_stmt [37170,37210]
===
match
---
trailer [13307,13345]
trailer [13307,13345]
===
match
---
trailer [64431,64433]
trailer [64383,64385]
===
match
---
param [31282,31287]
param [31234,31239]
===
match
---
suite [91921,92501]
suite [91873,92453]
===
match
---
trailer [25939,25950]
trailer [25891,25902]
===
match
---
expr_stmt [85456,85481]
expr_stmt [85408,85433]
===
match
---
param [42519,42524]
param [42471,42476]
===
match
---
name: dry_run [48540,48547]
name: dry_run [48492,48499]
===
match
---
string: 'max_active_tasks_per_dag' [88665,88691]
string: 'max_active_tasks_per_dag' [88617,88643]
===
match
---
atom_expr [20074,20097]
atom_expr [20074,20097]
===
match
---
trailer [65558,65568]
trailer [65510,65520]
===
match
---
trailer [10996,11007]
trailer [10996,11007]
===
match
---
expr_stmt [78139,78182]
expr_stmt [78091,78134]
===
match
---
atom [42975,43010]
atom [42927,42962]
===
match
---
name: dag_id [51373,51379]
name: dag_id [51325,51331]
===
match
---
sync_comp_for [59160,59176]
sync_comp_for [59112,59128]
===
match
---
import_name [894,909]
import_name [894,909]
===
match
---
trailer [45576,45621]
trailer [45528,45573]
===
match
---
name: dttm [21499,21503]
name: dttm [21475,21479]
===
match
---
atom_expr [14503,14539]
atom_expr [14503,14539]
===
match
---
operator: { [18966,18967]
operator: { [18966,18967]
===
match
---
name: task_dict [63597,63606]
name: task_dict [63549,63558]
===
match
---
name: airflow [1925,1932]
name: airflow [1925,1932]
===
match
---
operator: = [10708,10709]
operator: = [10708,10709]
===
match
---
name: render_template_as_native_obj [11679,11708]
name: render_template_as_native_obj [11679,11708]
===
match
---
name: tis [57388,57391]
name: tis [57340,57343]
===
match
---
import_from [2619,2706]
import_from [2619,2706]
===
match
---
name: qry [83360,83363]
name: qry [83312,83315]
===
match
---
operator: { [84982,84983]
operator: { [84934,84935]
===
match
---
name: state [74562,74567]
name: state [74514,74519]
===
match
---
trailer [67669,67680]
trailer [67621,67632]
===
match
---
name: conditions [51259,51269]
name: conditions [51211,51221]
===
match
---
operator: > [27397,27398]
operator: > [27349,27350]
===
match
---
trailer [53883,53888]
trailer [53835,53840]
===
match
---
trailer [32871,32889]
trailer [32823,32841]
===
match
---
name: dry_run [59755,59762]
name: dry_run [59707,59714]
===
match
---
trailer [13461,13470]
trailer [13461,13470]
===
match
---
trailer [63409,63418]
trailer [63361,63370]
===
match
---
parameters [68678,68691]
parameters [68630,68643]
===
match
---
name: self [44862,44866]
name: self [44814,44818]
===
match
---
name: TaskInstance [2145,2157]
name: TaskInstance [2145,2157]
===
match
---
argument [85513,85529]
argument [85465,85481]
===
match
---
tfpdef [31214,31224]
tfpdef [31166,31176]
===
match
---
simple_stmt [41840,41896]
simple_stmt [41792,41848]
===
match
---
operator: , [1110,1111]
operator: , [1110,1111]
===
match
---
atom_expr [36737,36754]
atom_expr [36689,36706]
===
match
---
operator: = [71786,71787]
operator: = [71738,71739]
===
match
---
name: on_success_callback [11302,11321]
name: on_success_callback [11302,11321]
===
match
---
trailer [12985,12997]
trailer [12985,12997]
===
match
---
simple_stmt [77946,77979]
simple_stmt [77898,77931]
===
match
---
atom_expr [94160,94201]
atom_expr [94112,94153]
===
match
---
expr_stmt [78025,78049]
expr_stmt [77977,78001]
===
match
---
operator: , [11722,11723]
operator: , [11722,11723]
===
match
---
atom_expr [47184,47239]
atom_expr [47136,47191]
===
match
---
annassign [97868,97890]
annassign [97820,97842]
===
match
---
atom_expr [88991,89008]
atom_expr [88943,88960]
===
match
---
name: _context_managed_dag [98260,98280]
name: _context_managed_dag [98212,98232]
===
match
---
simple_stmt [63245,63296]
simple_stmt [63197,63248]
===
match
---
funcdef [85027,85357]
funcdef [84979,85309]
===
match
---
annassign [13036,13066]
annassign [13036,13066]
===
match
---
trailer [34454,34622]
trailer [34406,34574]
===
match
---
simple_stmt [83112,83167]
simple_stmt [83064,83119]
===
match
---
suite [42013,42108]
suite [41965,42060]
===
match
---
name: self [40732,40736]
name: self [40684,40688]
===
match
---
name: self [42727,42731]
name: self [42679,42683]
===
match
---
atom_expr [76998,77369]
atom_expr [76950,77321]
===
match
---
name: topological_sort [47196,47212]
name: topological_sort [47148,47164]
===
match
---
name: next_run_date [26571,26584]
name: next_run_date [26523,26536]
===
match
---
trailer [39964,39968]
trailer [39916,39920]
===
match
---
testlist_comp [83131,83165]
testlist_comp [83083,83117]
===
match
---
name: has_task [65163,65171]
name: has_task [65115,65123]
===
match
---
return_stmt [30731,30758]
return_stmt [30683,30710]
===
match
---
name: start_date [26508,26518]
name: start_date [26460,26470]
===
match
---
name: matched_tasks [63018,63031]
name: matched_tasks [62970,62983]
===
match
---
expr_stmt [77478,77867]
expr_stmt [77430,77819]
===
match
---
name: default_args [13254,13266]
name: default_args [13254,13266]
===
match
---
name: state [37830,37835]
name: state [37782,37787]
===
match
---
trailer [39045,39051]
trailer [38997,39003]
===
match
---
atom_expr [91246,91264]
atom_expr [91198,91216]
===
match
---
operator: = [71992,71993]
operator: = [71944,71945]
===
match
---
name: dag_run_state [52325,52338]
name: dag_run_state [52277,52290]
===
match
---
trailer [54679,54686]
trailer [54631,54638]
===
match
---
name: cli_parser [71960,71970]
name: cli_parser [71912,71922]
===
match
---
name: Stats [2247,2252]
name: Stats [2247,2252]
===
match
---
name: self [25597,25601]
name: self [25549,25553]
===
match
---
operator: , [48339,48340]
operator: , [48291,48292]
===
match
---
simple_stmt [86342,86385]
simple_stmt [86294,86337]
===
match
---
trailer [77500,77867]
trailer [77452,77819]
===
match
---
name: fileloc [96778,96785]
name: fileloc [96730,96737]
===
match
---
atom_expr [98058,98125]
atom_expr [98010,98077]
===
match
---
name: self [21096,21100]
name: self [21096,21100]
===
match
---
name: count [59814,59819]
name: count [59766,59771]
===
match
---
operator: = [21309,21310]
operator: = [21285,21286]
===
match
---
string: 'user_defined_filters' [83878,83900]
string: 'user_defined_filters' [83830,83852]
===
match
---
name: start_date [59437,59447]
name: start_date [59389,59399]
===
match
---
operator: , [77218,77219]
operator: , [77170,77171]
===
match
---
operator: @ [31084,31085]
operator: @ [31036,31037]
===
match
---
atom_expr [25646,25661]
atom_expr [25598,25613]
===
match
---
name: filter_query [91210,91222]
name: filter_query [91162,91174]
===
match
---
expr_stmt [30442,30472]
expr_stmt [30394,30424]
===
match
---
name: tis [55896,55899]
name: tis [55848,55851]
===
match
---
atom [11999,12001]
atom [11999,12001]
===
match
---
trailer [41226,41228]
trailer [41178,41180]
===
match
---
suite [95106,97053]
suite [95058,97005]
===
match
---
operator: , [1448,1449]
operator: , [1448,1449]
===
match
---
operator: , [42894,42895]
operator: , [42846,42847]
===
match
---
param [67122,67126]
param [67074,67078]
===
match
---
not_test [67831,67848]
not_test [67783,67800]
===
match
---
name: end_date [68097,68105]
name: end_date [68049,68057]
===
match
---
name: Optional [11648,11656]
name: Optional [11648,11656]
===
match
---
operator: { [96522,96523]
operator: { [96474,96475]
===
match
---
param [31031,31035]
param [30983,30987]
===
match
---
name: scalar [38083,38089]
name: scalar [38035,38041]
===
match
---
string: 'dag.dag_id' [85578,85590]
string: 'dag.dag_id' [85530,85542]
===
match
---
expr_stmt [23616,23693]
expr_stmt [23568,23645]
===
match
---
trailer [65968,65971]
trailer [65920,65923]
===
match
---
atom_expr [47553,47571]
atom_expr [47505,47523]
===
match
---
trailer [14717,14728]
trailer [14717,14728]
===
match
---
operator: = [98159,98160]
operator: = [98111,98112]
===
match
---
trailer [78583,78595]
trailer [78535,78547]
===
match
---
trailer [64954,64959]
trailer [64906,64911]
===
match
---
name: TaskInstance [33128,33140]
name: TaskInstance [33080,33092]
===
match
---
name: with_row_locks [93559,93573]
name: with_row_locks [93511,93525]
===
match
---
string: """Print an ASCII tree representation of the DAG.""" [66656,66708]
string: """Print an ASCII tree representation of the DAG.""" [66608,66660]
===
match
---
trailer [14819,14826]
trailer [14819,14826]
===
match
---
decorated [81159,82047]
decorated [81111,81999]
===
match
---
trailer [93219,93225]
trailer [93171,93177]
===
match
---
name: cls [98256,98259]
name: cls [98208,98211]
===
match
---
name: group [64581,64586]
name: group [64533,64538]
===
match
---
if_stmt [97143,97310]
if_stmt [97095,97262]
===
match
---
import_as_names [1813,1825]
import_as_names [1813,1825]
===
match
---
operator: , [3077,3078]
operator: , [3077,3078]
===
match
---
simple_stmt [75894,75901]
simple_stmt [75846,75853]
===
match
---
atom_expr [28293,28310]
atom_expr [28245,28262]
===
match
---
trailer [43015,43017]
trailer [42967,42969]
===
match
---
trailer [43720,43727]
trailer [43672,43679]
===
match
---
name: context [36669,36676]
name: context [36621,36628]
===
match
---
string: 'kcah_acitats' [97105,97119]
string: 'kcah_acitats' [97057,97071]
===
match
---
operator: = [96000,96001]
operator: = [95952,95953]
===
match
---
operator: , [2664,2665]
operator: , [2664,2665]
===
match
---
name: recursion_depth [54261,54276]
name: recursion_depth [54213,54228]
===
match
---
trailer [25687,25698]
trailer [25639,25650]
===
match
---
operator: , [11509,11510]
operator: , [11509,11510]
===
match
---
dotted_name [1318,1336]
dotted_name [1318,1336]
===
match
---
name: self [26392,26396]
name: self [26344,26348]
===
match
---
name: missing_dag_id [76561,76575]
name: missing_dag_id [76513,76527]
===
match
---
atom_expr [16457,16468]
atom_expr [16457,16468]
===
match
---
subscriptlist [13043,13060]
subscriptlist [13043,13060]
===
match
---
trailer [44400,44404]
trailer [44352,44356]
===
match
---
name: DagModel [91246,91254]
name: DagModel [91198,91206]
===
match
---
trailer [72051,72063]
trailer [72003,72015]
===
match
---
expr_stmt [58476,58879]
expr_stmt [58428,58831]
===
match
---
operator: , [1189,1190]
operator: , [1189,1190]
===
match
---
simple_stmt [33507,33699]
simple_stmt [33459,33651]
===
match
---
atom_expr [79909,79959]
atom_expr [79861,79911]
===
match
---
param [72204,72233]
param [72156,72185]
===
match
---
trailer [14413,14426]
trailer [14413,14426]
===
match
---
name: AirflowException [74192,74208]
name: AirflowException [74144,74160]
===
match
---
operator: , [31297,31298]
operator: , [31249,31250]
===
match
---
trailer [91033,91040]
trailer [90985,90992]
===
match
---
name: self [20017,20021]
name: self [20017,20021]
===
match
---
return_stmt [24884,24895]
return_stmt [24836,24847]
===
match
---
operator: = [32965,32966]
operator: = [32917,32918]
===
match
---
name: session [29319,29326]
name: session [29271,29278]
===
match
---
atom_expr [17691,17700]
atom_expr [17691,17700]
===
match
---
atom_expr [87897,87948]
atom_expr [87849,87900]
===
match
---
name: group [64343,64348]
name: group [64295,64300]
===
match
---
trailer [28673,28680]
trailer [28625,28632]
===
match
---
not_test [67474,67493]
not_test [67426,67445]
===
match
---
name: t [62349,62350]
name: t [62301,62302]
===
match
---
comparison [68133,68163]
comparison [68085,68115]
===
match
---
name: Dict [11544,11548]
name: Dict [11544,11548]
===
match
---
name: self [94624,94628]
name: self [94576,94580]
===
match
---
name: keys [83679,83683]
name: keys [83631,83635]
===
match
---
operator: , [58565,58566]
operator: , [58517,58518]
===
match
---
atom_expr [91044,91055]
atom_expr [90996,91007]
===
match
---
if_stmt [88290,88693]
if_stmt [88242,88645]
===
match
---
atom [24994,25045]
atom [24946,24997]
===
match
---
arglist [43080,43111]
arglist [43032,43063]
===
match
---
name: upstream_task_id [84582,84598]
name: upstream_task_id [84534,84550]
===
match
---
trailer [13535,13553]
trailer [13535,13553]
===
match
---
name: filter_task_group [63776,63793]
name: filter_task_group [63728,63745]
===
match
---
name: Environment [41271,41282]
name: Environment [41223,41234]
===
match
---
import_from [1454,1514]
import_from [1454,1514]
===
match
---
trailer [51499,51505]
trailer [51451,51457]
===
match
---
operator: <= [28633,28635]
operator: <= [28585,28587]
===
match
---
atom [66771,66788]
atom [66723,66740]
===
match
---
name: following [29081,29090]
name: following [29033,29042]
===
match
---
suite [38281,39054]
suite [38233,39006]
===
match
---
name: dttm [29095,29099]
name: dttm [29047,29051]
===
match
---
simple_stmt [41393,41420]
simple_stmt [41345,41372]
===
match
---
name: airflow [2306,2313]
name: airflow [2306,2313]
===
match
---
string: "" [96825,96827]
string: "" [96777,96779]
===
match
---
parameters [30091,30097]
parameters [30043,30049]
===
match
---
operator: , [47836,47837]
operator: , [47788,47789]
===
match
---
argument [77909,77931]
argument [77861,77883]
===
match
---
name: get_template_env [41238,41254]
name: get_template_env [41190,41206]
===
match
---
string: """         Calculates the following schedule for this dag in UTC.          :param dttm: utc datetime         :return: utc datetime         """ [20316,20459]
string: """         Calculates the following schedule for this dag in UTC.          :param dttm: utc datetime         :return: utc datetime         """ [20316,20459]
===
match
---
param [48434,48455]
param [48386,48407]
===
match
---
name: dag_kwargs [94768,94778]
name: dag_kwargs [94720,94730]
===
match
---
atom [84954,84956]
atom [84906,84908]
===
match
---
string: "The 'concurrency' parameter is deprecated. Please use 'max_active_tasks'." [12526,12601]
string: "The 'concurrency' parameter is deprecated. Please use 'max_active_tasks'." [12526,12601]
===
match
---
funcdef [48245,58090]
funcdef [48197,58042]
===
match
---
funcdef [32347,32494]
funcdef [32299,32446]
===
match
---
comparison [23779,23812]
comparison [23731,23764]
===
match
---
name: perms [18890,18895]
name: perms [18890,18895]
===
match
---
arglist [74123,74147]
arglist [74075,74099]
===
match
---
operator: = [10235,10236]
operator: = [10235,10236]
===
match
---
import_from [2707,2744]
import_from [2707,2744]
===
match
---
name: DagContext [97318,97328]
name: DagContext [97270,97280]
===
match
---
simple_stmt [67507,67541]
simple_stmt [67459,67493]
===
match
---
name: Index [87958,87963]
name: Index [87910,87915]
===
match
---
operator: , [79017,79018]
operator: , [78969,78970]
===
match
---
name: max_active_tasks [88626,88642]
name: max_active_tasks [88578,88594]
===
match
---
suite [30638,30678]
suite [30590,30630]
===
match
---
funcdef [88956,89009]
funcdef [88908,88961]
===
match
---
atom_expr [17341,17353]
atom_expr [17341,17353]
===
match
---
fstring [65605,65632]
fstring [65557,65584]
===
match
---
name: self [67092,67096]
name: self [67044,67048]
===
match
---
name: dag_id [40022,40028]
name: dag_id [39974,39980]
===
match
---
name: session [81609,81616]
name: session [81561,81568]
===
match
---
atom_expr [77543,77558]
atom_expr [77495,77510]
===
match
---
name: cli [71920,71923]
name: cli [71872,71875]
===
match
---
name: fn [32185,32187]
name: fn [32137,32139]
===
match
---
param [94766,94778]
param [94718,94730]
===
match
---
trailer [64348,64367]
trailer [64300,64319]
===
match
---
dictorsetmaker [18668,18825]
dictorsetmaker [18668,18825]
===
match
---
name: dag_bag [52553,52560]
name: dag_bag [52505,52512]
===
match
---
name: self [31952,31956]
name: self [31904,31908]
===
match
---
name: BaseOperator [63466,63478]
name: BaseOperator [63418,63430]
===
match
---
return_stmt [67057,67097]
return_stmt [67009,67049]
===
match
---
parameters [32357,32363]
parameters [32309,32315]
===
match
---
string: 'jinja_environment_kwargs' [84288,84314]
string: 'jinja_environment_kwargs' [84240,84266]
===
match
---
name: query [77006,77011]
name: query [76958,76963]
===
match
---
atom_expr [31060,31078]
atom_expr [31012,31030]
===
match
---
simple_stmt [2055,2096]
simple_stmt [2055,2096]
===
match
---
name: dagrun_timeout [10972,10986]
name: dagrun_timeout [10972,10986]
===
match
---
name: graph_sorted [47386,47398]
name: graph_sorted [47338,47350]
===
match
---
name: in_timezone [21084,21095]
name: in_timezone [21084,21095]
===
match
---
name: child [63576,63581]
name: child [63528,63533]
===
match
---
argument [59611,59631]
argument [59563,59583]
===
match
---
string: """         Set ``is_active=False`` on the DAGs for which the DAG files have been removed.         Additionally change ``is_active=False`` to ``True`` if the DAG file exists.          :param alive_dag_filelocs: file paths of alive DAGs         :param session: ORM Session         """ [91471,91754]
string: """         Set ``is_active=False`` on the DAGs for which the DAG files have been removed.         Additionally change ``is_active=False`` to ``True`` if the DAG file exists.          :param alive_dag_filelocs: file paths of alive DAGs         :param session: ORM Session         """ [91423,91706]
===
match
---
trailer [79577,79581]
trailer [79529,79533]
===
match
---
operator: , [3071,3072]
operator: , [3071,3072]
===
match
---
operator: = [28190,28191]
operator: = [28142,28143]
===
match
---
expr_stmt [43123,43348]
expr_stmt [43075,43300]
===
match
---
simple_stmt [46653,46669]
simple_stmt [46605,46621]
===
match
---
operator: = [52780,52781]
operator: = [52732,52733]
===
match
---
trailer [64909,64927]
trailer [64861,64879]
===
match
---
atom_expr [37823,37835]
atom_expr [37775,37787]
===
match
---
param [48301,48317]
param [48253,48269]
===
match
---
operator: = [10313,10314]
operator: = [10313,10314]
===
match
---
operator: == [3568,3570]
operator: == [3568,3570]
===
match
---
atom_expr [60096,60110]
atom_expr [60048,60062]
===
match
---
suite [3721,85357]
suite [3721,85309]
===
match
---
name: start_date [43256,43266]
name: start_date [43208,43218]
===
match
---
name: most_recent_dag_runs [76957,76977]
name: most_recent_dag_runs [76909,76929]
===
match
---
name: parse [13406,13411]
name: parse [13406,13411]
===
match
---
name: LoggingMixin [2556,2568]
name: LoggingMixin [2556,2568]
===
match
---
name: set_is_paused [90694,90707]
name: set_is_paused [90646,90659]
===
match
---
name: or_ [77151,77154]
name: or_ [77103,77106]
===
match
---
name: BaseOperator [65323,65335]
name: BaseOperator [65275,65287]
===
match
---
name: true [90019,90023]
name: true [89971,89975]
===
match
---
atom_expr [38987,38998]
atom_expr [38939,38950]
===
match
---
expr_stmt [44353,44406]
expr_stmt [44305,44358]
===
match
---
name: cls [98367,98370]
name: cls [98319,98322]
===
match
---
expr_stmt [37163,37180]
expr_stmt [37115,37132]
===
match
---
name: recursion_depth [48608,48623]
name: recursion_depth [48560,48575]
===
match
---
return_stmt [19622,19759]
return_stmt [19622,19759]
===
match
---
name: now [20052,20055]
name: now [20052,20055]
===
match
---
simple_stmt [87459,87542]
simple_stmt [87411,87494]
===
match
---
name: DagRunType [73970,73980]
name: DagRunType [73922,73932]
===
match
---
simple_stmt [17257,17282]
simple_stmt [17257,17282]
===
match
---
operator: , [48598,48599]
operator: , [48550,48551]
===
match
---
trailer [51582,51586]
trailer [51534,51538]
===
match
---
atom_expr [16116,16139]
atom_expr [16116,16139]
===
match
---
name: copy [53879,53883]
name: copy [53831,53835]
===
match
---
name: session [92484,92491]
name: session [92436,92443]
===
match
---
name: date_last_automated_dagrun [26251,26277]
name: date_last_automated_dagrun [26203,26229]
===
match
---
name: filtered_child [63759,63773]
name: filtered_child [63711,63725]
===
match
---
string: "Cancelled, nothing was cleared." [58008,58041]
string: "Cancelled, nothing was cleared." [57960,57993]
===
match
---
simple_stmt [26080,26145]
simple_stmt [26032,26097]
===
match
---
name: datetime [19502,19510]
name: datetime [19502,19510]
===
match
---
operator: , [94495,94496]
operator: , [94447,94448]
===
match
---
atom [23595,23607]
atom [23547,23559]
===
match
---
simple_stmt [52980,53024]
simple_stmt [52932,52976]
===
match
---
operator: , [10883,10884]
operator: , [10883,10884]
===
match
---
simple_stmt [12301,12323]
simple_stmt [12301,12323]
===
match
---
trailer [84957,84961]
trailer [84909,84913]
===
match
---
trailer [62950,62959]
trailer [62902,62911]
===
match
---
simple_stmt [32257,32310]
simple_stmt [32209,32262]
===
match
---
suite [98237,98489]
suite [98189,98441]
===
match
---
for_stmt [60128,60313]
for_stmt [60080,60265]
===
match
---
simple_stmt [23935,24010]
simple_stmt [23887,23962]
===
match
---
trailer [68172,68182]
trailer [68124,68134]
===
match
---
name: models [1794,1800]
name: models [1794,1800]
===
match
---
suite [41942,42000]
suite [41894,41952]
===
match
---
name: permissions [18668,18679]
name: permissions [18668,18679]
===
match
---
trailer [91204,91224]
trailer [91156,91176]
===
match
---
trailer [48174,48180]
trailer [48126,48132]
===
match
---
simple_stmt [44415,44426]
simple_stmt [44367,44378]
===
match
---
trailer [18983,18987]
trailer [18983,18987]
===
match
---
trailer [26765,26769]
trailer [26717,26721]
===
match
---
decorators [89179,89213]
decorators [89131,89165]
===
match
---
trailer [78531,78544]
trailer [78483,78496]
===
match
---
operator: , [1085,1086]
operator: , [1085,1086]
===
match
---
expr_stmt [11892,11940]
expr_stmt [11892,11940]
===
match
---
comp_if [25935,25950]
comp_if [25887,25902]
===
match
---
simple_stmt [20001,20057]
simple_stmt [20001,20057]
===
match
---
name: Optional [93722,93730]
name: Optional [93674,93682]
===
match
---
suite [59801,59877]
suite [59753,59829]
===
match
---
return_stmt [17115,17197]
return_stmt [17115,17197]
===
match
---
name: Column [86154,86160]
name: Column [86106,86112]
===
match
---
dotted_name [30765,30786]
dotted_name [30717,30738]
===
match
---
atom_expr [43964,43992]
atom_expr [43916,43944]
===
match
---
name: getattr [17152,17159]
name: getattr [17152,17159]
===
match
---
expr_stmt [85535,85610]
expr_stmt [85487,85562]
===
match
---
comparison [65208,65250]
comparison [65160,65202]
===
match
---
param [11566,11613]
param [11566,11613]
===
match
---
atom_expr [33213,33222]
atom_expr [33165,33174]
===
match
---
decorator [39059,39076]
decorator [39011,39028]
===
match
---
name: c [17180,17181]
name: c [17180,17181]
===
match
---
name: session [66123,66130]
name: session [66075,66082]
===
match
---
atom_expr [97105,97133]
atom_expr [97057,97085]
===
match
---
trailer [84532,84552]
trailer [84484,84504]
===
match
---
name: __repr__ [88882,88890]
name: __repr__ [88834,88842]
===
match
---
comparison [15041,15077]
comparison [15041,15077]
===
match
---
name: get_prev [22475,22483]
name: get_prev [22451,22459]
===
match
---
operator: = [61131,61132]
operator: = [61083,61084]
===
match
---
name: self [12831,12835]
name: self [12831,12835]
===
match
---
trailer [23462,23480]
trailer [23414,23432]
===
match
---
trailer [60302,60311]
trailer [60254,60263]
===
match
---
arglist [87479,87540]
arglist [87431,87492]
===
match
---
for_stmt [55225,56924]
for_stmt [55177,56876]
===
match
---
name: session [91174,91181]
name: session [91126,91133]
===
match
---
operator: , [12601,12602]
operator: , [12601,12602]
===
match
---
simple_stmt [16804,16851]
simple_stmt [16804,16851]
===
match
---
trailer [81079,81089]
trailer [81031,81041]
===
match
---
name: qry [83023,83026]
name: qry [82975,82978]
===
match
---
name: _max_active_tasks [30352,30369]
name: _max_active_tasks [30304,30321]
===
match
---
argument [59519,59542]
argument [59471,59494]
===
match
---
name: session [43129,43136]
name: session [43081,43088]
===
match
---
trailer [67720,67731]
trailer [67672,67683]
===
match
---
trailer [77830,77837]
trailer [77782,77789]
===
match
---
trailer [17732,17739]
trailer [17732,17739]
===
match
---
atom_expr [47349,47360]
atom_expr [47301,47312]
===
match
---
operator: , [18064,18065]
operator: , [18064,18065]
===
match
---
atom_expr [68322,68334]
atom_expr [68274,68286]
===
match
---
name: param [96630,96635]
name: param [96582,96587]
===
match
---
name: Optional [34087,34095]
name: Optional [34039,34047]
===
match
---
arglist [43682,43692]
arglist [43634,43644]
===
match
---
expr_stmt [62905,63056]
expr_stmt [62857,63008]
===
match
---
return_stmt [17320,17353]
return_stmt [17320,17353]
===
match
---
name: self [14449,14453]
name: self [14449,14453]
===
match
---
trailer [91331,91338]
trailer [91283,91290]
===
match
---
name: default [86370,86377]
name: default [86322,86329]
===
match
---
name: datetime [22312,22320]
name: datetime [22288,22296]
===
match
---
if_stmt [27279,27446]
if_stmt [27231,27398]
===
match
---
atom_expr [92127,92146]
atom_expr [92079,92098]
===
match
---
funcdef [17224,17282]
funcdef [17224,17282]
===
match
---
operator: >= [25643,25645]
operator: >= [25595,25597]
===
match
---
name: Column [86251,86257]
name: Column [86203,86209]
===
match
---
name: self [85045,85049]
name: self [84997,85001]
===
match
---
name: run_id [74394,74400]
name: run_id [74346,74352]
===
match
---
atom_expr [89935,90095]
atom_expr [89887,90047]
===
match
---
name: dag_by_ids [75954,75964]
name: dag_by_ids [75906,75916]
===
match
---
string: """         Triggers the appropriate callback depending on the value of success, namely the         on_failure_callback or on_success_callback. This method gets the context of a         single TaskInstance part of this DagRun and passes that to the callable along         with a 'reason', primarily to differentiate DagRun failures.          .. note: The logs end up in             ``$AIRFLOW_HOME/logs/scheduler/latest/PROJECT/DAG_FILE.py.log``          :param dagrun: DagRun object         :param success: Flag to specify if failure or success callback should be called         :param reason: Completion reason         :param session: Database session         """ [35592,36257]
string: """         Triggers the appropriate callback depending on the value of success, namely the         on_failure_callback or on_success_callback. This method gets the context of a         single TaskInstance part of this DagRun and passes that to the callable along         with a 'reason', primarily to differentiate DagRun failures.          .. note: The logs end up in             ``$AIRFLOW_HOME/logs/scheduler/latest/PROJECT/DAG_FILE.py.log``          :param dagrun: DagRun object         :param success: Flag to specify if failure or success callback should be called         :param reason: Completion reason         :param session: Database session         """ [35544,36209]
===
match
---
tfpdef [10251,10296]
tfpdef [10251,10296]
===
match
---
name: convert_to_utc [21370,21384]
name: convert_to_utc [21346,21360]
===
match
---
trailer [36560,36565]
trailer [36512,36517]
===
match
---
name: in_ [82872,82875]
name: in_ [82824,82827]
===
match
---
operator: = [67876,67877]
operator: = [67828,67829]
===
match
---
name: run_type [72376,72384]
name: run_type [72328,72336]
===
match
---
trailer [69077,69088]
trailer [69029,69040]
===
match
---
name: arguments [95980,95989]
name: arguments [95932,95941]
===
match
---
name: self [34711,34715]
name: self [34663,34667]
===
match
---
operator: = [71414,71415]
operator: = [71366,71367]
===
match
---
operator: , [97996,97997]
operator: , [97948,97949]
===
match
---
name: session [93620,93627]
name: session [93572,93579]
===
match
---
operator: , [63464,63465]
operator: , [63416,63417]
===
match
---
param [85629,85633]
param [85581,85585]
===
match
---
name: datetime [19430,19438]
name: datetime [19430,19438]
===
match
---
name: self [31243,31247]
name: self [31195,31199]
===
match
---
operator: } [18834,18835]
operator: } [18834,18835]
===
match
---
operator: , [2937,2938]
operator: , [2937,2938]
===
match
---
name: Dict [16106,16110]
name: Dict [16106,16110]
===
match
---
trailer [18764,18795]
trailer [18764,18795]
===
match
---
name: params [12016,12022]
name: params [12016,12022]
===
match
---
raise_stmt [74186,74319]
raise_stmt [74138,74271]
===
match
---
trailer [44646,44660]
trailer [44598,44612]
===
match
---
simple_stmt [37094,37154]
simple_stmt [37046,37106]
===
match
---
name: DagRun [39532,39538]
name: DagRun [39484,39490]
===
match
---
string: "\n" [59143,59147]
string: "\n" [59095,59099]
===
match
---
name: update [41858,41864]
name: update [41810,41816]
===
match
---
simple_stmt [96605,96649]
simple_stmt [96557,96601]
===
match
---
return_stmt [89269,89331]
return_stmt [89221,89283]
===
match
---
name: get_parser [71971,71981]
name: get_parser [71923,71933]
===
match
---
simple_stmt [65586,65634]
simple_stmt [65538,65586]
===
match
---
simple_stmt [28173,28250]
simple_stmt [28125,28202]
===
match
---
name: f [95352,95353]
name: f [95304,95305]
===
match
---
name: tzinfo [13505,13511]
name: tzinfo [13505,13511]
===
match
---
name: cls [93453,93456]
name: cls [93405,93408]
===
match
---
atom_expr [77195,77218]
atom_expr [77147,77170]
===
match
---
trailer [13231,13244]
trailer [13231,13244]
===
match
---
atom_expr [44880,44900]
atom_expr [44832,44852]
===
match
---
trailer [51564,51571]
trailer [51516,51523]
===
match
---
expr_stmt [51099,51116]
expr_stmt [51051,51068]
===
match
---
suite [33827,34020]
suite [33779,33972]
===
match
---
trailer [24999,25007]
trailer [24951,24959]
===
match
---
name: datetime [10347,10355]
name: datetime [10347,10355]
===
match
---
trailer [20679,20685]
trailer [20679,20685]
===
match
---
expr_stmt [36451,36484]
expr_stmt [36403,36436]
===
match
---
name: task [40949,40953]
name: task [40901,40905]
===
match
---
suite [94780,97073]
suite [94732,97025]
===
match
---
name: _schedule_interval [35404,35422]
name: _schedule_interval [35356,35374]
===
match
---
name: dag [64618,64621]
name: dag [64570,64573]
===
match
---
name: template_undefined [14686,14704]
name: template_undefined [14686,14704]
===
match
---
simple_stmt [46979,47012]
simple_stmt [46931,46964]
===
match
---
param [30092,30096]
param [30044,30048]
===
match
---
name: _max_active_tasks [30652,30669]
name: _max_active_tasks [30604,30621]
===
match
---
name: tags [11732,11736]
name: tags [11732,11736]
===
match
---
trailer [30033,30048]
trailer [29985,30000]
===
match
---
trailer [54947,54951]
trailer [54899,54903]
===
match
---
trailer [44371,44400]
trailer [44323,44352]
===
match
---
name: t [62526,62527]
name: t [62478,62479]
===
match
---
operator: = [57407,57408]
operator: = [57359,57360]
===
match
---
atom_expr [51530,51541]
atom_expr [51482,51493]
===
match
---
dotted_name [1604,1621]
dotted_name [1604,1621]
===
match
---
atom_expr [55426,55436]
atom_expr [55378,55388]
===
match
---
trailer [83062,83068]
trailer [83014,83020]
===
match
---
simple_stmt [76544,76577]
simple_stmt [76496,76529]
===
match
---
expr_stmt [2965,3043]
expr_stmt [2965,3043]
===
match
---
arglist [62960,62979]
arglist [62912,62931]
===
match
---
trailer [79651,79667]
trailer [79603,79619]
===
match
---
suite [59360,59788]
suite [59312,59740]
===
match
---
name: filter_task_group [64061,64078]
name: filter_task_group [64013,64030]
===
match
---
name: include_subdags [58705,58720]
name: include_subdags [58657,58672]
===
match
---
or_test [66387,66414]
or_test [66339,66366]
===
match
---
trailer [77823,77838]
trailer [77775,77790]
===
match
---
name: self [13804,13808]
name: self [13804,13808]
===
match
---
trailer [57685,57715]
trailer [57637,57667]
===
match
---
trailer [42447,42474]
trailer [42399,42426]
===
match
---
atom_expr [26080,26144]
atom_expr [26032,26096]
===
match
---
trailer [36745,36754]
trailer [36697,36706]
===
match
---
operator: = [36455,36456]
operator: = [36407,36408]
===
match
---
trailer [78890,79032]
trailer [78842,78984]
===
match
---
name: int [31130,31133]
name: int [31082,31085]
===
match
---
name: execution_date [55119,55133]
name: execution_date [55071,55085]
===
match
---
name: DeprecationWarning [12619,12637]
name: DeprecationWarning [12619,12637]
===
match
---
expr_stmt [10093,10145]
expr_stmt [10093,10145]
===
match
---
name: primary_key [85593,85604]
name: primary_key [85545,85556]
===
match
---
operator: = [56706,56707]
operator: = [56658,56659]
===
match
---
name: end_date [43627,43635]
name: end_date [43579,43587]
===
match
---
param [28817,28822]
param [28769,28774]
===
match
---
name: previous [22569,22577]
name: previous [22521,22529]
===
match
---
simple_stmt [60883,60927]
simple_stmt [60835,60879]
===
match
---
trailer [39552,39559]
trailer [39504,39511]
===
match
---
operator: { [48771,48772]
operator: { [48723,48724]
===
match
---
name: items [96576,96581]
name: items [96528,96533]
===
match
---
name: query [76255,76260]
name: query [76207,76212]
===
match
---
trailer [14370,14382]
trailer [14370,14382]
===
match
---
name: normalized_schedule_interval [21511,21539]
name: normalized_schedule_interval [21487,21515]
===
match
---
simple_stmt [96511,96525]
simple_stmt [96463,96477]
===
match
---
name: Column [87633,87639]
name: Column [87585,87591]
===
match
---
return_stmt [39763,39777]
return_stmt [39715,39729]
===
match
---
name: self [67733,67737]
name: self [67685,67689]
===
match
---
trailer [12283,12291]
trailer [12283,12291]
===
match
---
trailer [44158,44228]
trailer [44110,44180]
===
match
---
fstring_string:  not found [65621,65631]
fstring_string:  not found [65573,65583]
===
match
---
trailer [83251,83255]
trailer [83203,83207]
===
match
---
name: group_by [77327,77335]
name: group_by [77279,77287]
===
match
---
name: user_defined_macros [42358,42377]
name: user_defined_macros [42310,42329]
===
match
---
trailer [18723,18739]
trailer [18723,18739]
===
match
---
atom_expr [74061,74075]
atom_expr [74013,74027]
===
match
---
param [44934,44968]
param [44886,44920]
===
match
---
operator: = [94654,94655]
operator: = [94606,94607]
===
match
---
name: name [85656,85660]
name: name [85608,85612]
===
match
---
trailer [20935,20937]
trailer [20935,20937]
===
match
---
operator: , [84193,84194]
operator: , [84145,84146]
===
match
---
trailer [67698,67709]
trailer [67650,67661]
===
match
---
name: is_subdag [86239,86248]
name: is_subdag [86191,86200]
===
match
---
name: ValueError [73759,73769]
name: ValueError [73711,73721]
===
match
---
name: pendulum [21933,21941]
name: pendulum [21909,21917]
===
match
---
name: get_flat_relatives [62630,62648]
name: get_flat_relatives [62582,62600]
===
match
---
arglist [51988,52624]
arglist [51940,52576]
===
match
---
name: Exception [65926,65935]
name: Exception [65878,65887]
===
match
---
operator: = [69045,69046]
operator: = [68997,68998]
===
match
---
operator: = [89085,89086]
operator: = [89037,89038]
===
match
---
operator: = [55767,55768]
operator: = [55719,55720]
===
match
---
operator: @ [33750,33751]
operator: @ [33702,33703]
===
match
---
trailer [76136,76141]
trailer [76088,76093]
===
match
---
simple_stmt [21468,21541]
simple_stmt [21444,21517]
===
match
---
simple_stmt [47286,47364]
simple_stmt [47238,47316]
===
match
---
atom_expr [11242,11292]
atom_expr [11242,11292]
===
match
---
simple_stmt [25882,25952]
simple_stmt [25834,25904]
===
match
---
arglist [81786,81938]
arglist [81738,81890]
===
match
---
name: cron_next [20191,20200]
name: cron_next [20191,20200]
===
match
---
name: start_date [52731,52741]
name: start_date [52683,52693]
===
match
---
trailer [96565,96575]
trailer [96517,96527]
===
match
---
trailer [39559,39724]
trailer [39511,39676]
===
match
---
atom_expr [94727,94743]
atom_expr [94679,94695]
===
match
---
funcdef [66106,66614]
funcdef [66058,66566]
===
match
---
suite [20522,21396]
suite [20522,21372]
===
match
---
if_stmt [82933,83409]
if_stmt [82885,83361]
===
match
---
name: self [74760,74764]
name: self [74712,74716]
===
match
---
trailer [66346,66349]
trailer [66298,66301]
===
match
---
suite [39854,40039]
suite [39806,39991]
===
match
---
simple_stmt [55519,55578]
simple_stmt [55471,55530]
===
match
---
decorated [30478,30565]
decorated [30430,30517]
===
match
---
name: active_dates [37163,37175]
name: active_dates [37115,37127]
===
match
---
operator: , [10177,10178]
operator: , [10177,10178]
===
match
---
trailer [66965,66968]
trailer [66917,66920]
===
match
---
name: DagModel [81002,81010]
name: DagModel [80954,80962]
===
match
---
name: self [51298,51302]
name: self [51250,51254]
===
match
---
name: BackfillJob [70923,70934]
name: BackfillJob [70875,70886]
===
match
---
name: append [91122,91128]
name: append [91074,91080]
===
match
---
name: external_trigger [77748,77764]
name: external_trigger [77700,77716]
===
match
---
name: minute [20180,20186]
name: minute [20180,20186]
===
match
---
name: str [85094,85097]
name: str [85046,85049]
===
match
---
name: jinja2 [10587,10593]
name: jinja2 [10587,10593]
===
match
---
name: DagRun [48111,48117]
name: DagRun [48063,48069]
===
match
---
trailer [51591,51600]
trailer [51543,51552]
===
match
---
operator: = [97884,97885]
operator: = [97836,97837]
===
match
---
name: start_date [74468,74478]
name: start_date [74420,74430]
===
match
---
trailer [67715,67749]
trailer [67667,67701]
===
match
---
string: 'catchup_by_default' [11271,11291]
string: 'catchup_by_default' [11271,11291]
===
match
---
simple_stmt [71195,71244]
simple_stmt [71147,71196]
===
match
---
operator: , [86168,86169]
operator: , [86120,86121]
===
match
---
import_from [1781,1825]
import_from [1781,1825]
===
match
---
expr_stmt [21240,21282]
expr_stmt [21240,21258]
===
match
---
name: Optional [72212,72220]
name: Optional [72164,72172]
===
match
---
operator: = [11356,11357]
operator: = [11356,11357]
===
match
---
name: task [67122,67126]
name: task [67074,67078]
===
match
---
expr_stmt [76375,76429]
expr_stmt [76327,76381]
===
match
---
tfpdef [10972,11007]
tfpdef [10972,11007]
===
match
---
param [11302,11363]
param [11302,11363]
===
match
---
atom_expr [29930,29949]
atom_expr [29882,29901]
===
match
---
atom_expr [66465,66480]
atom_expr [66417,66432]
===
match
---
trailer [73722,73735]
trailer [73674,73687]
===
match
---
name: end_date [26967,26975]
name: end_date [26919,26927]
===
match
---
param [82118,82125]
param [82070,82077]
===
match
---
trailer [72394,72406]
trailer [72346,72358]
===
match
---
import_from [2413,2464]
import_from [2413,2464]
===
match
---
trailer [41864,41895]
trailer [41816,41847]
===
match
---
name: self [29058,29062]
name: self [29010,29014]
===
match
---
parameters [72107,72529]
parameters [72059,72481]
===
match
---
name: session [57177,57184]
name: session [57129,57136]
===
match
---
operator: = [12314,12315]
operator: = [12314,12315]
===
match
---
trailer [44181,44197]
trailer [44133,44149]
===
match
---
name: split [51798,51803]
name: split [51750,51755]
===
match
---
name: tzinfo [13144,13150]
name: tzinfo [13144,13150]
===
match
---
fstring_string: ^ [55701,55702]
fstring_string: ^ [55653,55654]
===
match
---
name: last_parsed_time [78475,78491]
name: last_parsed_time [78427,78443]
===
match
---
string: 'user_defined_macros' [83918,83939]
string: 'user_defined_macros' [83870,83891]
===
match
---
atom_expr [15772,15796]
atom_expr [15772,15796]
===
match
---
simple_stmt [22338,22389]
simple_stmt [22314,22365]
===
match
---
atom_expr [93268,93281]
atom_expr [93220,93233]
===
match
---
operator: , [9908,9909]
operator: , [9908,9909]
===
match
---
operator: = [85913,85914]
operator: = [85865,85866]
===
match
---
trailer [94180,94201]
trailer [94132,94153]
===
match
---
name: in_ [44178,44181]
name: in_ [44130,44133]
===
match
---
name: task [67082,67086]
name: task [67034,67038]
===
match
---
operator: @ [34300,34301]
operator: @ [34252,34253]
===
match
---
name: self [80001,80005]
name: self [79953,79957]
===
match
---
operator: = [29318,29319]
operator: = [29270,29271]
===
match
---
operator: { [59233,59234]
operator: { [59185,59186]
===
match
---
name: task [66846,66850]
name: task [66798,66802]
===
match
---
atom_expr [80402,80419]
atom_expr [80354,80371]
===
match
---
trailer [65958,65962]
trailer [65910,65914]
===
match
---
trailer [98023,98044]
trailer [97975,97996]
===
match
---
name: isinstance [73712,73722]
name: isinstance [73664,73674]
===
match
---
name: Optional [22959,22967]
name: Optional [22911,22919]
===
match
---
operator: = [62230,62231]
operator: = [62182,62183]
===
match
---
decorator [82070,82087]
decorator [82022,82039]
===
match
---
trailer [96613,96619]
trailer [96565,96571]
===
match
---
argument [52545,52560]
argument [52497,52512]
===
match
---
name: factory [97045,97052]
name: factory [96997,97004]
===
match
---
trailer [59152,59177]
trailer [59104,59129]
===
match
---
argument [76143,76158]
argument [76095,76110]
===
match
---
trailer [83434,83436]
trailer [83386,83388]
===
match
---
comparison [91129,91164]
comparison [91081,91116]
===
match
---
trailer [38991,38998]
trailer [38943,38950]
===
match
---
name: dag [94715,94718]
name: dag [94667,94670]
===
match
---
atom_expr [68884,68903]
atom_expr [68836,68855]
===
match
---
operator: } [16911,16912]
operator: } [16911,16912]
===
match
---
atom_expr [13528,13553]
atom_expr [13528,13553]
===
match
---
name: info [85352,85356]
name: info [85304,85308]
===
match
---
name: setter [30780,30786]
name: setter [30732,30738]
===
match
---
operator: , [18992,18993]
operator: , [18992,18993]
===
match
---
name: pickled [65772,65779]
name: pickled [65724,65731]
===
match
---
name: models [2109,2115]
name: models [2109,2115]
===
match
---
trailer [14210,14223]
trailer [14210,14223]
===
match
---
name: dag_run_state [58821,58834]
name: dag_run_state [58773,58786]
===
match
---
name: cls [60083,60086]
name: cls [60035,60038]
===
match
---
operator: { [65674,65675]
operator: { [65626,65627]
===
match
---
expr_stmt [37094,37153]
expr_stmt [37046,37105]
===
match
---
param [11622,11670]
param [11622,11670]
===
match
---
name: dag_id [66205,66211]
name: dag_id [66157,66163]
===
match
---
atom_expr [57108,57118]
atom_expr [57060,57070]
===
match
---
parameters [97992,98007]
parameters [97944,97959]
===
match
---
simple_stmt [17206,17219]
simple_stmt [17206,17219]
===
match
---
name: deactivate_stale_dags [81202,81223]
name: deactivate_stale_dags [81154,81175]
===
match
---
testlist_comp [44845,44900]
testlist_comp [44797,44852]
===
match
---
operator: @ [75363,75364]
operator: @ [75315,75316]
===
match
---
fstring [55698,55717]
fstring [55650,55669]
===
match
---
simple_stmt [76490,76532]
simple_stmt [76442,76484]
===
match
---
name: Iterable [1116,1124]
name: Iterable [1116,1124]
===
match
---
comparison [14308,14339]
comparison [14308,14339]
===
match
---
if_stmt [43465,43637]
if_stmt [43417,43589]
===
match
---
trailer [54457,54848]
trailer [54409,54800]
===
match
---
name: dag [76669,76672]
name: dag [76621,76624]
===
match
---
name: start_date [51988,51998]
name: start_date [51940,51950]
===
match
---
name: tis [44115,44118]
name: tis [44067,44070]
===
match
---
funcdef [30492,30565]
funcdef [30444,30517]
===
match
---
name: relationship [97277,97289]
name: relationship [97229,97241]
===
match
---
simple_stmt [21067,21119]
simple_stmt [21067,21119]
===
match
---
trailer [42345,42352]
trailer [42297,42304]
===
match
---
trailer [80452,80456]
trailer [80404,80408]
===
match
---
if_stmt [94211,94661]
if_stmt [94163,94613]
===
match
---
trailer [72177,72187]
trailer [72129,72139]
===
match
---
parameters [58126,58416]
parameters [58078,58368]
===
match
---
simple_stmt [60684,60875]
simple_stmt [60636,60827]
===
match
---
name: TI [51145,51147]
name: TI [51097,51099]
===
match
---
operator: , [62115,62116]
operator: , [62067,62068]
===
match
---
trailer [25319,25324]
trailer [25271,25276]
===
match
---
suite [15143,15329]
suite [15143,15329]
===
match
---
operator: , [56087,56088]
operator: , [56039,56040]
===
match
---
atom_expr [21361,21395]
atom_expr [21337,21371]
===
match
---
try_stmt [17670,17825]
try_stmt [17670,17825]
===
match
---
name: default_args [12144,12156]
name: default_args [12144,12156]
===
match
---
atom_expr [66165,66235]
atom_expr [66117,66187]
===
match
---
if_stmt [53581,56981]
if_stmt [53533,56933]
===
match
---
arglist [84962,84984]
arglist [84914,84936]
===
match
---
simple_stmt [51697,51909]
simple_stmt [51649,51861]
===
match
---
suite [33390,33745]
suite [33342,33697]
===
match
---
atom_expr [31586,31640]
atom_expr [31538,31592]
===
match
---
argument [59755,59768]
argument [59707,59720]
===
match
---
operator: = [87941,87942]
operator: = [87893,87894]
===
match
---
comparison [25633,25661]
comparison [25585,25613]
===
match
---
raise_stmt [38673,38748]
raise_stmt [38625,38700]
===
match
---
name: self [12959,12963]
name: self [12959,12963]
===
match
---
trailer [3125,3142]
trailer [3125,3142]
===
match
---
suite [98421,98466]
suite [98373,98418]
===
match
---
funcdef [66619,66969]
funcdef [66571,66921]
===
match
---
trailer [58066,58068]
trailer [58018,58020]
===
match
---
atom_expr [33319,33340]
atom_expr [33271,33292]
===
match
---
operator: = [30049,30050]
operator: = [30001,30002]
===
match
---
trailer [82826,82833]
trailer [82778,82785]
===
match
---
simple_stmt [62216,62300]
simple_stmt [62168,62252]
===
match
---
name: session [74900,74907]
name: session [74852,74859]
===
match
---
atom_expr [22533,22551]
atom_expr [22491,22504]
===
match
---
name: query [33920,33925]
name: query [33872,33877]
===
match
---
name: task [53798,53802]
name: task [53750,53754]
===
match
---
trailer [46756,46770]
trailer [46708,46722]
===
match
---
parameters [32799,32805]
parameters [32751,32757]
===
match
---
name: isoformat [81926,81935]
name: isoformat [81878,81887]
===
match
---
atom_expr [14068,14081]
atom_expr [14068,14081]
===
match
---
name: from_run_id [73868,73879]
name: from_run_id [73820,73831]
===
match
---
number: 0 [57434,57435]
number: 0 [57386,57387]
===
match
---
param [11519,11557]
param [11519,11557]
===
match
---
name: timezone [13970,13978]
name: timezone [13970,13978]
===
match
---
simple_stmt [76739,76787]
simple_stmt [76691,76739]
===
match
---
simple_stmt [16575,16630]
simple_stmt [16575,16630]
===
match
---
dictorsetmaker [36685,36701]
dictorsetmaker [36637,36653]
===
match
---
arglist [73723,73734]
arglist [73675,73686]
===
match
---
trailer [47176,47183]
trailer [47128,47135]
===
match
---
atom_expr [43671,43693]
atom_expr [43623,43645]
===
match
---
atom_expr [15743,15755]
atom_expr [15743,15755]
===
match
---
simple_stmt [94388,94612]
simple_stmt [94340,94564]
===
match
---
name: timezone [65742,65750]
name: timezone [65694,65702]
===
match
---
atom_expr [14942,14961]
atom_expr [14942,14961]
===
match
---
trailer [58485,58491]
trailer [58437,58443]
===
match
---
name: Session [47517,47524]
name: Session [47469,47476]
===
match
---
trailer [66576,66586]
trailer [66528,66538]
===
match
---
name: func [82689,82693]
name: func [82641,82645]
===
match
---
name: self [31208,31212]
name: self [31160,31164]
===
match
---
name: task [44607,44611]
name: task [44559,44563]
===
match
---
name: str [84625,84628]
name: str [84577,84580]
===
match
---
arglist [13536,13552]
arglist [13536,13552]
===
match
---
trailer [86528,86541]
trailer [86480,86493]
===
match
---
name: set [76019,76022]
name: set [75971,75974]
===
match
---
trailer [79201,79206]
trailer [79153,79158]
===
match
---
operator: = [69138,69139]
operator: = [69090,69091]
===
match
---
name: is_active [81969,81978]
name: is_active [81921,81930]
===
match
---
trailer [63524,63534]
trailer [63476,63486]
===
match
---
name: downstream_task_ids [65002,65021]
name: downstream_task_ids [64954,64973]
===
match
---
simple_stmt [40696,40712]
simple_stmt [40648,40664]
===
match
---
name: t [64885,64886]
name: t [64837,64838]
===
match
---
trailer [21941,21950]
trailer [21917,21926]
===
match
---
return_stmt [57449,57457]
return_stmt [57401,57409]
===
match
---
operator: = [73855,73856]
operator: = [73807,73808]
===
match
---
trailer [11145,11147]
trailer [11145,11147]
===
match
---
name: DagPickle [66337,66346]
name: DagPickle [66289,66298]
===
match
---
atom [37711,37863]
atom [37663,37815]
===
match
---
name: t [65000,65001]
name: t [64952,64953]
===
match
---
name: utils_date_range [19629,19645]
name: utils_date_range [19629,19645]
===
match
---
name: first [89166,89171]
name: first [89118,89123]
===
match
---
atom_expr [38210,38223]
atom_expr [38162,38175]
===
match
---
param [42525,42542]
param [42477,42494]
===
match
---
name: default_args [13930,13942]
name: default_args [13930,13942]
===
match
---
name: log [75910,75913]
name: log [75862,75865]
===
match
---
name: include_upstream [51830,51846]
name: include_upstream [51782,51798]
===
match
---
name: RUNNING [37145,37152]
name: RUNNING [37097,37104]
===
match
---
simple_stmt [29923,29950]
simple_stmt [29875,29902]
===
match
---
name: TYPE_CHECKING [1042,1055]
name: TYPE_CHECKING [1042,1055]
===
match
---
decorated [98170,98489]
decorated [98122,98441]
===
match
---
trailer [95916,95926]
trailer [95868,95878]
===
match
---
suite [90785,91341]
suite [90737,91293]
===
match
---
name: schedule_interval [14474,14491]
name: schedule_interval [14474,14491]
===
match
---
decorator [66085,66102]
decorator [66037,66054]
===
match
---
name: t [63013,63014]
name: t [62965,62966]
===
match
---
operator: @ [66085,66086]
operator: @ [66037,66038]
===
match
---
trailer [68034,68043]
trailer [67986,67995]
===
match
---
name: DeprecationWarning [47792,47810]
name: DeprecationWarning [47744,47762]
===
match
---
name: self [31031,31035]
name: self [30983,30987]
===
match
---
atom_expr [60289,60311]
atom_expr [60241,60263]
===
match
---
name: matched_tasks [62216,62229]
name: matched_tasks [62168,62181]
===
match
---
suite [58417,59898]
suite [58369,59850]
===
match
---
operator: = [65672,65673]
operator: = [65624,65625]
===
match
---
operator: = [59530,59531]
operator: = [59482,59483]
===
match
---
trailer [11896,11917]
trailer [11896,11917]
===
match
---
trailer [36281,36301]
trailer [36233,36253]
===
match
---
if_stmt [47078,47241]
if_stmt [47030,47193]
===
match
---
name: relativedelta [1278,1291]
name: relativedelta [1278,1291]
===
match
---
tfpdef [10812,10833]
tfpdef [10812,10833]
===
match
---
suite [57967,58043]
suite [57919,57995]
===
match
---
name: visited_external_tis [56838,56858]
name: visited_external_tis [56790,56810]
===
match
---
name: visited_external_tis [56817,56837]
name: visited_external_tis [56769,56789]
===
match
---
simple_stmt [25477,25500]
simple_stmt [25429,25452]
===
match
---
trailer [37732,37738]
trailer [37684,37690]
===
match
---
name: normalized_schedule_interval [20022,20050]
name: normalized_schedule_interval [20022,20050]
===
match
---
operator: = [91297,91298]
operator: = [91249,91250]
===
match
---
name: end_date [28126,28134]
name: end_date [28078,28086]
===
match
---
param [22844,22849]
param [22796,22801]
===
match
---
name: self [84917,84921]
name: self [84869,84873]
===
match
---
simple_stmt [59814,59824]
simple_stmt [59766,59776]
===
match
---
trailer [55069,55086]
trailer [55021,55038]
===
match
---
operator: = [77950,77951]
operator: = [77902,77903]
===
match
---
name: update [42441,42447]
name: update [42393,42399]
===
match
---
trailer [20021,20050]
trailer [20021,20050]
===
match
---
trailer [81645,81652]
trailer [81597,81604]
===
match
---
trailer [51574,51582]
trailer [51526,51534]
===
match
---
trailer [14268,14281]
trailer [14268,14281]
===
match
---
name: warnings [88322,88330]
name: warnings [88274,88282]
===
match
---
string: """         Get the next execution date after the given ``date_last_automated_dagrun``, according to         schedule_interval, start_date, end_date etc.  This doesn't check max active run or any other         "max_active_tasks" type limits, it only performs calculations based on the various date         and interval fields of this dag and it's tasks.          :param date_last_automated_dagrun: The execution_date of the last scheduler or             backfill triggered run for this dag         :type date_last_automated_dagrun: pendulum.Pendulum         """ [24114,24675]
string: """         Get the next execution date after the given ``date_last_automated_dagrun``, according to         schedule_interval, start_date, end_date etc.  This doesn't check max active run or any other         "max_active_tasks" type limits, it only performs calculations based on the various date         and interval fields of this dag and it's tasks.          :param date_last_automated_dagrun: The execution_date of the last scheduler or             backfill triggered run for this dag         :type date_last_automated_dagrun: pendulum.Pendulum         """ [24066,24627]
===
match
---
operator: = [35576,35577]
operator: = [35528,35529]
===
match
---
name: execution_date [52796,52810]
name: execution_date [52748,52762]
===
match
---
atom_expr [33943,33958]
atom_expr [33895,33910]
===
match
---
operator: , [11612,11613]
operator: , [11612,11613]
===
match
---
operator: , [87516,87517]
operator: , [87468,87469]
===
match
---
simple_stmt [66656,66709]
simple_stmt [66608,66661]
===
match
---
name: DeprecationWarning [34567,34585]
name: DeprecationWarning [34519,34537]
===
match
---
name: __deepcopy__ [59907,59919]
name: __deepcopy__ [59859,59871]
===
match
---
operator: = [23636,23637]
operator: = [23588,23589]
===
match
---
trailer [14326,14339]
trailer [14326,14339]
===
match
---
simple_stmt [33296,33341]
simple_stmt [33248,33293]
===
match
---
arglist [68077,68105]
arglist [68029,68057]
===
match
---
funcdef [68665,68904]
funcdef [68617,68856]
===
match
---
name: orm_tag_names [79396,79409]
name: orm_tag_names [79348,79361]
===
match
---
name: roots [66932,66937]
name: roots [66884,66889]
===
match
---
operator: , [58409,58410]
operator: , [58361,58362]
===
match
---
name: str [14535,14538]
name: str [14535,14538]
===
match
---
trailer [58980,58989]
trailer [58932,58941]
===
match
---
operator: , [88099,88100]
operator: , [88051,88052]
===
match
---
atom_expr [10221,10234]
atom_expr [10221,10234]
===
match
---
name: ScheduleInterval [10279,10295]
name: ScheduleInterval [10279,10295]
===
match
---
trailer [38037,38043]
trailer [37989,37995]
===
match
---
dotted_name [2418,2436]
dotted_name [2418,2436]
===
match
---
return_stmt [24745,24756]
return_stmt [24697,24708]
===
match
---
name: relationship [1502,1514]
name: relationship [1502,1514]
===
match
---
trailer [29547,29666]
trailer [29499,29618]
===
match
---
expr_stmt [63207,63232]
expr_stmt [63159,63184]
===
match
---
param [11078,11148]
param [11078,11148]
===
match
---
operator: = [69309,69310]
operator: = [69261,69262]
===
match
---
name: setdefault [85297,85307]
name: setdefault [85249,85259]
===
match
---
if_stmt [96225,96286]
if_stmt [96177,96238]
===
match
---
subscriptlist [10499,10517]
subscriptlist [10499,10517]
===
match
---
trailer [88926,88933]
trailer [88878,88885]
===
match
---
sync_comp_for [62345,62398]
sync_comp_for [62297,62350]
===
match
---
name: append [17733,17739]
name: append [17733,17739]
===
match
---
string: '' [32306,32308]
string: '' [32258,32260]
===
match
---
atom_expr [22677,22710]
atom_expr [22629,22662]
===
match
---
param [72242,72280]
param [72194,72232]
===
match
---
atom_expr [11648,11662]
atom_expr [11648,11662]
===
match
---
decorator [31646,31656]
decorator [31598,31608]
===
match
---
name: dag_bag [56764,56771]
name: dag_bag [56716,56723]
===
match
---
name: max_active_runs [94218,94233]
name: max_active_runs [94170,94185]
===
match
---
operator: , [18057,18058]
operator: , [18057,18058]
===
match
---
name: pickle_id [66277,66286]
name: pickle_id [66229,66238]
===
match
---
expr_stmt [55395,55437]
expr_stmt [55347,55389]
===
match
---
atom_expr [14175,14192]
atom_expr [14175,14192]
===
match
---
trailer [17586,17591]
trailer [17586,17591]
===
match
---
atom_expr [21506,21539]
atom_expr [21482,21515]
===
match
---
name: filter [91198,91204]
name: filter [91150,91156]
===
match
---
if_stmt [91979,92472]
if_stmt [91931,92424]
===
match
---
trailer [16844,16850]
trailer [16844,16850]
===
match
---
name: debug [26770,26775]
name: debug [26722,26727]
===
match
---
name: self [13747,13751]
name: self [13747,13751]
===
match
---
name: default_args [13862,13874]
name: default_args [13862,13874]
===
match
---
expr_stmt [87715,87748]
expr_stmt [87667,87700]
===
match
---
trailer [94718,94725]
trailer [94670,94677]
===
match
---
and_test [26251,26295]
and_test [26203,26247]
===
match
---
name: filter [52786,52792]
name: filter [52738,52744]
===
match
---
comparison [22677,22722]
comparison [22629,22674]
===
match
---
trailer [77031,77036]
trailer [76983,76988]
===
match
---
trailer [51385,51393]
trailer [51337,51345]
===
match
---
name: allow_future_exec_dates [43489,43512]
name: allow_future_exec_dates [43441,43464]
===
match
---
name: has_task_concurrency_limits [88838,88865]
name: has_task_concurrency_limits [88790,88817]
===
match
---
name: query [3535,3540]
name: query [3535,3540]
===
match
---
atom_expr [76019,76041]
atom_expr [75971,75993]
===
match
---
trailer [3449,3456]
trailer [3449,3456]
===
match
---
name: query [33163,33168]
name: query [33115,33120]
===
match
---
name: get_run_dates [27485,27498]
name: get_run_dates [27437,27450]
===
match
---
name: FrozenSet [48744,48753]
name: FrozenSet [48696,48705]
===
match
---
suite [96238,96286]
suite [96190,96238]
===
match
---
simple_stmt [20698,20747]
simple_stmt [20698,20747]
===
match
---
simple_stmt [59190,59288]
simple_stmt [59142,59240]
===
match
---
name: only_failed [56125,56136]
name: only_failed [56077,56088]
===
match
---
string: "This attribute is deprecated. Please use `airflow.models.DAG.get_is_paused` method." [34468,34553]
string: "This attribute is deprecated. Please use `airflow.models.DAG.get_is_paused` method." [34420,34505]
===
match
---
name: result [60384,60390]
name: result [60336,60342]
===
match
---
simple_stmt [20066,20098]
simple_stmt [20066,20098]
===
match
---
funcdef [10151,16851]
funcdef [10151,16851]
===
match
---
name: self [34064,34068]
name: self [34016,34020]
===
match
---
arglist [67082,67096]
arglist [67034,67048]
===
match
---
name: Collection [75433,75443]
name: Collection [75385,75395]
===
match
---
operator: , [29576,29577]
operator: , [29528,29529]
===
match
---
if_stmt [79604,79703]
if_stmt [79556,79655]
===
match
---
trailer [22007,22016]
trailer [21983,21992]
===
match
---
atom_expr [18088,18124]
atom_expr [18088,18124]
===
match
---
name: upstream [62547,62555]
name: upstream [62499,62507]
===
match
---
name: getboolean [69078,69088]
name: getboolean [69030,69040]
===
match
---
operator: , [19708,19709]
operator: , [19708,19709]
===
match
---
name: nativetypes [1325,1336]
name: nativetypes [1325,1336]
===
match
---
trailer [54875,54892]
trailer [54827,54844]
===
match
---
suite [73982,74079]
suite [73934,74031]
===
match
---
atom [28059,28061]
atom [28011,28013]
===
match
---
atom_expr [64581,64639]
atom_expr [64533,64591]
===
match
---
name: d [77923,77924]
name: d [77875,77876]
===
match
---
trailer [64502,64515]
trailer [64454,64467]
===
match
---
trailer [94391,94397]
trailer [94343,94349]
===
match
---
argument [96103,96126]
argument [96055,96078]
===
match
---
atom_expr [24076,24103]
atom_expr [24028,24055]
===
match
---
trailer [64452,64473]
trailer [64404,64425]
===
match
---
name: delay_on_limit_secs [71637,71656]
name: delay_on_limit_secs [71589,71608]
===
match
---
name: t [62288,62289]
name: t [62240,62241]
===
match
---
name: fileloc [91992,91999]
name: fileloc [91944,91951]
===
match
---
atom_expr [51656,51671]
atom_expr [51608,51623]
===
match
---
name: states [83400,83406]
name: states [83352,83358]
===
match
---
name: upstream_task_ids [64587,64604]
name: upstream_task_ids [64539,64556]
===
match
---
name: self [37337,37341]
name: self [37289,37293]
===
match
---
expr_stmt [57980,57989]
expr_stmt [57932,57941]
===
match
---
name: task [41033,41037]
name: task [40985,40989]
===
match
---
simple_stmt [55606,55862]
simple_stmt [55558,55814]
===
match
---
operator: == [33260,33262]
operator: == [33212,33214]
===
match
---
operator: = [62026,62027]
operator: = [61978,61979]
===
match
---
trailer [80456,80489]
trailer [80408,80441]
===
match
---
except_clause [92509,92525]
except_clause [92461,92477]
===
match
---
name: session [39946,39953]
name: session [39898,39905]
===
match
---
name: self [80310,80314]
name: self [80262,80266]
===
match
---
atom_expr [59308,59341]
atom_expr [59260,59293]
===
match
---
name: state [52910,52915]
name: state [52862,52867]
===
match
---
operator: , [82139,82140]
operator: , [82091,82092]
===
match
---
name: alive_dag_filelocs [91417,91435]
name: alive_dag_filelocs [91369,91387]
===
match
---
name: DagRun [37956,37962]
name: DagRun [37908,37914]
===
match
---
argument [87489,87516]
argument [87441,87468]
===
match
---
argument [40379,40391]
argument [40331,40343]
===
match
---
argument [88022,88034]
argument [87974,87986]
===
match
---
atom_expr [14322,14339]
atom_expr [14322,14339]
===
match
---
atom_expr [98292,98326]
atom_expr [98244,98278]
===
match
---
atom_expr [12801,12814]
atom_expr [12801,12814]
===
match
---
expr_stmt [65984,66009]
expr_stmt [65936,65961]
===
match
---
name: str [90250,90253]
name: str [90202,90205]
===
match
---
name: task_dict [64723,64732]
name: task_dict [64675,64684]
===
match
---
operator: == [77765,77767]
operator: == [77717,77719]
===
match
---
name: t [65220,65221]
name: t [65172,65173]
===
match
---
name: keys [64733,64737]
name: keys [64685,64689]
===
match
---
atom_expr [72212,72225]
atom_expr [72164,72177]
===
match
---
import_from [1264,1312]
import_from [1264,1312]
===
match
---
atom_expr [63776,63808]
atom_expr [63728,63760]
===
match
---
decorated [79965,80284]
decorated [79917,80236]
===
match
---
expr_stmt [86059,86137]
expr_stmt [86011,86089]
===
match
---
trailer [91137,91149]
trailer [91089,91101]
===
match
---
expr_stmt [58998,59010]
expr_stmt [58950,58962]
===
match
---
trailer [53888,53915]
trailer [53840,53867]
===
match
---
name: joinedload [76117,76127]
name: joinedload [76069,76079]
===
match
---
operator: , [35540,35541]
operator: , [35492,35493]
===
match
---
name: session [76998,77005]
name: session [76950,76957]
===
match
---
name: tis [43585,43588]
name: tis [43537,43540]
===
match
---
name: do_it [57728,57733]
name: do_it [57680,57685]
===
match
---
operator: , [1069,1070]
operator: , [1069,1070]
===
match
---
name: DeprecationWarning [60819,60837]
name: DeprecationWarning [60771,60789]
===
match
---
fstring_string: `run_type` expected to be a DagRunType is  [74018,74060]
fstring_string: `run_type` expected to be a DagRunType is  [73970,74012]
===
match
---
not_test [18583,18601]
not_test [18583,18601]
===
match
---
param [98531,98534]
param [98483,98486]
===
match
---
trailer [89294,89301]
trailer [89246,89253]
===
match
---
name: TaskInstance [51104,51116]
name: TaskInstance [51056,51068]
===
match
---
name: end_date [68035,68043]
name: end_date [67987,67995]
===
match
---
name: child [63395,63400]
name: child [63347,63352]
===
match
---
if_stmt [63445,64007]
if_stmt [63397,63959]
===
match
---
name: self [33714,33718]
name: self [33666,33670]
===
match
---
name: date_last_automated_dagrun [26211,26237]
name: date_last_automated_dagrun [26163,26189]
===
match
---
argument [58705,58736]
argument [58657,58688]
===
match
---
test [12353,12391]
test [12353,12391]
===
match
---
name: self [16845,16849]
name: self [16845,16849]
===
match
---
suite [41189,41229]
suite [41141,41181]
===
match
---
operator: = [79950,79951]
operator: = [79902,79903]
===
match
---
name: child [63794,63799]
name: child [63746,63751]
===
match
---
trailer [53893,53902]
trailer [53845,53854]
===
match
---
atom_expr [16956,16966]
atom_expr [16956,16966]
===
match
---
name: tasks [64763,64768]
name: tasks [64715,64720]
===
match
---
name: self [68622,68626]
name: self [68574,68578]
===
match
---
name: self [44624,44628]
name: self [44576,44580]
===
match
---
suite [43694,43757]
suite [43646,43709]
===
match
---
name: executors [70996,71005]
name: executors [70948,70957]
===
match
---
trailer [77269,77279]
trailer [77221,77231]
===
match
---
decorated [39059,39778]
decorated [39011,39730]
===
match
---
name: provide_session [34026,34041]
name: provide_session [33978,33993]
===
match
---
trailer [44866,44872]
trailer [44818,44824]
===
match
---
string: "This method is deprecated and will be removed in a future version. Please use partial_subset" [60711,60805]
string: "This method is deprecated and will be removed in a future version. Please use partial_subset" [60663,60757]
===
match
---
atom_expr [87133,87145]
atom_expr [87085,87097]
===
match
---
suite [71849,72064]
suite [71801,72016]
===
match
---
expr_stmt [21011,21050]
expr_stmt [21011,21050]
===
match
---
suite [16875,16915]
suite [16875,16915]
===
match
---
operator: = [60069,60070]
operator: = [60021,60022]
===
match
---
parameters [24041,24104]
parameters [23993,24056]
===
match
---
simple_stmt [34756,35087]
simple_stmt [34708,35039]
===
match
---
name: job [71252,71255]
name: job [71204,71207]
===
match
---
name: upstream_list [44647,44660]
name: upstream_list [44599,44612]
===
match
---
trailer [32724,32730]
trailer [32676,32682]
===
match
---
name: tuple [17845,17850]
name: tuple [17845,17850]
===
match
---
suite [68692,68904]
suite [68644,68856]
===
match
---
simple_stmt [64555,64640]
simple_stmt [64507,64592]
===
match
---
atom_expr [92484,92500]
atom_expr [92436,92452]
===
match
---
name: ask_yesno [57750,57759]
name: ask_yesno [57702,57711]
===
match
---
import_name [856,865]
import_name [856,865]
===
match
---
decorator [89014,89028]
decorator [88966,88980]
===
match
---
name: __doc__ [96230,96237]
name: __doc__ [96182,96189]
===
match
---
name: tis [52693,52696]
name: tis [52645,52648]
===
match
---
funcdef [37313,38092]
funcdef [37265,38044]
===
match
---
string: '/' [32301,32304]
string: '/' [32253,32256]
===
match
---
atom_expr [14605,14629]
atom_expr [14605,14629]
===
match
---
param [88969,88973]
param [88921,88925]
===
match
---
suite [93789,94745]
suite [93741,94697]
===
match
---
operator: = [85890,85891]
operator: = [85842,85843]
===
match
---
name: include_externally_triggered [29357,29385]
name: include_externally_triggered [29309,29337]
===
match
---
expr_stmt [14353,14439]
expr_stmt [14353,14439]
===
match
---
atom_expr [21409,21442]
atom_expr [21385,21418]
===
match
---
operator: , [48659,48660]
operator: , [48611,48612]
===
match
---
name: normalized_schedule_interval [22051,22079]
name: normalized_schedule_interval [22027,22055]
===
match
---
suite [79896,79960]
suite [79848,79912]
===
match
---
suite [44019,44255]
suite [43971,44207]
===
match
---
trailer [74753,74757]
trailer [74705,74709]
===
match
---
atom_expr [76072,76210]
atom_expr [76024,76162]
===
match
---
name: make_aware [43052,43062]
name: make_aware [43004,43014]
===
match
---
name: info [81764,81768]
name: info [81716,81720]
===
match
---
decorator [42814,42831]
decorator [42766,42783]
===
match
---
name: existing_dag_ids [77615,77631]
name: existing_dag_ids [77567,77583]
===
match
---
import_from [11781,11827]
import_from [11781,11827]
===
match
---
trailer [14513,14539]
trailer [14513,14539]
===
match
---
atom_expr [21475,21540]
atom_expr [21451,21516]
===
match
---
name: str [66791,66794]
name: str [66743,66746]
===
match
---
atom_expr [13588,13601]
atom_expr [13588,13601]
===
match
---
name: or_ [83229,83232]
name: or_ [83181,83184]
===
match
---
return_stmt [33707,33744]
return_stmt [33659,33696]
===
match
---
operator: = [33910,33911]
operator: = [33862,33863]
===
match
---
simple_stmt [95804,95827]
simple_stmt [95756,95779]
===
match
---
name: is_subdag [15659,15668]
name: is_subdag [15659,15668]
===
match
---
operator: = [29487,29488]
operator: = [29439,29440]
===
match
---
name: value [30051,30056]
name: value [30003,30008]
===
match
---
name: all [90090,90093]
name: all [90042,90045]
===
match
---
trailer [87851,87864]
trailer [87803,87816]
===
match
---
trailer [55429,55436]
trailer [55381,55388]
===
match
---
name: dags [75995,75999]
name: dags [75947,75951]
===
match
---
trailer [79304,79309]
trailer [79256,79261]
===
match
---
arglist [20482,20520]
arglist [20482,20520]
===
match
---
name: run_type [74123,74131]
name: run_type [74075,74083]
===
match
---
funcdef [29720,29773]
funcdef [29672,29725]
===
match
---
atom_expr [52893,52905]
atom_expr [52845,52857]
===
match
---
arith_expr [21019,21050]
arith_expr [21019,21050]
===
match
---
name: copy [60289,60293]
name: copy [60241,60245]
===
match
---
simple_stmt [44492,44591]
simple_stmt [44444,44543]
===
match
---
param [59920,59925]
param [59872,59877]
===
match
---
argument [71594,71603]
argument [71546,71555]
===
match
---
name: fileloc [78353,78360]
name: fileloc [78305,78312]
===
match
---
trailer [77671,77679]
trailer [77623,77631]
===
match
---
name: warnings [33507,33515]
name: warnings [33459,33467]
===
match
---
operator: = [38267,38268]
operator: = [38219,38220]
===
match
---
name: default_args [13478,13490]
name: default_args [13478,13490]
===
match
---
trailer [92491,92498]
trailer [92443,92450]
===
match
---
name: state [47472,47477]
name: state [47424,47429]
===
match
---
name: __file__ [32289,32297]
name: __file__ [32241,32249]
===
match
---
name: back [12974,12978]
name: back [12974,12978]
===
match
---
operator: == [90005,90007]
operator: == [89957,89959]
===
match
---
atom_expr [53063,53099]
atom_expr [53015,53051]
===
match
---
atom_expr [55410,55437]
atom_expr [55362,55389]
===
match
---
arglist [32273,32308]
arglist [32225,32260]
===
match
---
name: tis [44359,44362]
name: tis [44311,44314]
===
match
---
if_stmt [13115,13512]
if_stmt [13115,13512]
===
match
---
decorator [31172,31190]
decorator [31124,31142]
===
match
---
name: schedule_interval [10251,10268]
name: schedule_interval [10251,10268]
===
match
---
name: append [98093,98099]
name: append [98045,98051]
===
match
---
atom_expr [65073,65082]
atom_expr [65025,65034]
===
match
---
simple_stmt [842,856]
simple_stmt [842,856]
===
match
---
for_stmt [66918,66969]
for_stmt [66870,66921]
===
match
---
name: first [66368,66373]
name: first [66320,66325]
===
match
---
name: orm_dag [77881,77888]
name: orm_dag [77833,77840]
===
match
---
name: group [64293,64298]
name: group [64245,64250]
===
match
---
trailer [39598,39605]
trailer [39550,39557]
===
match
---
name: c [17649,17650]
name: c [17649,17650]
===
match
---
expr_stmt [21969,22017]
expr_stmt [21945,21993]
===
match
---
operator: = [48311,48312]
operator: = [48263,48264]
===
match
---
operator: = [90130,90131]
operator: = [90082,90083]
===
match
---
expr_stmt [97075,97094]
expr_stmt [97027,97046]
===
match
---
name: self [68030,68034]
name: self [67982,67986]
===
match
---
argument [71617,71656]
argument [71569,71608]
===
match
---
name: rollback [92547,92555]
name: rollback [92499,92507]
===
match
---
operator: , [39120,39121]
operator: , [39072,39073]
===
match
---
if_stmt [88244,88693]
if_stmt [88196,88645]
===
match
---
trailer [78474,78491]
trailer [78426,78443]
===
match
---
name: _default_view [15096,15109]
name: _default_view [15096,15109]
===
match
---
param [31288,31298]
param [31240,31250]
===
match
---
operator: = [71958,71959]
operator: = [71910,71911]
===
match
---
name: cron_presets [35168,35180]
name: cron_presets [35120,35132]
===
match
---
operator: = [28088,28089]
operator: = [28040,28041]
===
match
---
string: """         Pause/Un-pause a DAG.          :param is_paused: Is the DAG paused         :param including_subdags: whether to include the DAG's subdags         :param session: session         """ [90794,90987]
string: """         Pause/Un-pause a DAG.          :param is_paused: Is the DAG paused         :param including_subdags: whether to include the DAG's subdags         :param session: session         """ [90746,90939]
===
match
---
expr_stmt [90996,91066]
expr_stmt [90948,91018]
===
match
---
name: DagRun [39577,39583]
name: DagRun [39529,39535]
===
match
---
parameters [18259,18280]
parameters [18259,18280]
===
match
---
trailer [74015,74078]
trailer [73967,74030]
===
match
---
atom_expr [64061,64102]
atom_expr [64013,64054]
===
match
---
comparison [14159,14192]
comparison [14159,14192]
===
match
---
comparison [43225,43266]
comparison [43177,43218]
===
match
---
number: 100 [85507,85510]
number: 100 [85459,85462]
===
match
---
string: '' [32245,32247]
string: '' [32197,32199]
===
match
---
string: """         Returns the number of task instances in the given DAG.          :param session: ORM session         :param dag_id: ID of the DAG to get the task concurrency of         :type dag_id: unicode         :param task_ids: A list of valid task IDs for the given DAG         :type task_ids: list[unicode]         :param states: A list of states to filter by if supplied         :type states: list[state]         :return: The number of running tasks         :rtype: int         """ [82177,82660]
string: """         Returns the number of task instances in the given DAG.          :param session: ORM session         :param dag_id: ID of the DAG to get the task concurrency of         :type dag_id: unicode         :param task_ids: A list of valid task IDs for the given DAG         :type task_ids: list[unicode]         :param states: A list of states to filter by if supplied         :type states: list[state]         :return: The number of running tasks         :rtype: int         """ [82129,82612]
===
match
---
name: upstream_task_id [42741,42757]
name: upstream_task_id [42693,42709]
===
match
---
name: tis [52699,52702]
name: tis [52651,52654]
===
match
---
name: subdag [47189,47195]
name: subdag [47141,47147]
===
match
---
name: state [42896,42901]
name: state [42848,42853]
===
match
---
decorator [89600,89617]
decorator [89552,89569]
===
match
---
number: 0 [48624,48625]
number: 0 [48576,48577]
===
match
---
name: dag_id [51535,51541]
name: dag_id [51487,51493]
===
match
---
expr_stmt [14942,14978]
expr_stmt [14942,14978]
===
match
---
name: dag_bag [55285,55292]
name: dag_bag [55237,55244]
===
match
---
atom_expr [41202,41228]
atom_expr [41154,41180]
===
match
---
name: sqlalchemy [1563,1573]
name: sqlalchemy [1563,1573]
===
match
---
atom [62424,62426]
atom [62376,62378]
===
match
---
name: task [40724,40728]
name: task [40676,40680]
===
match
---
atom_expr [63560,63590]
atom_expr [63512,63542]
===
match
---
name: DagPickle [66319,66328]
name: DagPickle [66271,66280]
===
match
---
simple_stmt [27207,27271]
simple_stmt [27159,27223]
===
match
---
name: dag_id [37113,37119]
name: dag_id [37065,37071]
===
match
---
operator: , [88663,88664]
operator: , [88615,88616]
===
match
---
trailer [33515,33520]
trailer [33467,33472]
===
match
---
name: include_parentdag [58772,58789]
name: include_parentdag [58724,58741]
===
match
---
simple_stmt [78025,78050]
simple_stmt [77977,78002]
===
match
---
simple_stmt [19598,19614]
simple_stmt [19598,19614]
===
match
---
name: state [72131,72136]
name: state [72083,72088]
===
match
---
name: start_date [68940,68950]
name: start_date [68892,68902]
===
match
---
name: self [12784,12788]
name: self [12784,12788]
===
match
---
atom_expr [51771,51812]
atom_expr [51723,51764]
===
match
---
atom_expr [10270,10296]
atom_expr [10270,10296]
===
match
---
not_test [83577,83604]
not_test [83529,83556]
===
match
---
name: Boolean [87640,87647]
name: Boolean [87592,87599]
===
match
---
name: task_id [65178,65185]
name: task_id [65130,65137]
===
match
---
name: run [74925,74928]
name: run [74877,74880]
===
match
---
operator: = [12712,12713]
operator: = [12712,12713]
===
match
---
trailer [35429,35447]
trailer [35381,35399]
===
match
---
name: level [66814,66819]
name: level [66766,66771]
===
match
---
atom_expr [81877,81887]
atom_expr [81829,81839]
===
match
---
name: following_schedule [26397,26415]
name: following_schedule [26349,26367]
===
match
---
atom_expr [77824,77837]
atom_expr [77776,77789]
===
match
---
trailer [97289,97309]
trailer [97241,97261]
===
match
---
name: false [93296,93301]
name: false [93248,93253]
===
match
---
name: SerializedDagModel [97227,97245]
name: SerializedDagModel [97179,97197]
===
match
---
name: get_serialized_fields [83463,83484]
name: get_serialized_fields [83415,83436]
===
match
---
comparison [25011,25044]
comparison [24963,24996]
===
match
---
operator: = [25796,25797]
operator: = [25748,25749]
===
match
---
name: utils [2525,2530]
name: utils [2525,2530]
===
match
---
string: """         Get the Default DAG View, returns the default config value if DagModel does not         have a value         """ [90263,90387]
string: """         Get the Default DAG View, returns the default config value if DagModel does not         have a value         """ [90215,90339]
===
match
---
name: conf [71704,71708]
name: conf [71656,71660]
===
match
---
suite [20938,21119]
suite [20938,21119]
===
match
---
simple_stmt [36882,36920]
simple_stmt [36834,36872]
===
match
---
trailer [42778,42787]
trailer [42730,42739]
===
match
---
simple_stmt [59133,59178]
simple_stmt [59085,59130]
===
match
---
name: self [93685,93689]
name: self [93637,93641]
===
match
---
atom_expr [66273,66286]
atom_expr [66225,66238]
===
match
---
atom_expr [60536,60545]
atom_expr [60488,60497]
===
match
---
trailer [36805,36809]
trailer [36757,36761]
===
match
---
name: SubDagOperator [47123,47137]
name: SubDagOperator [47075,47089]
===
match
---
name: child [63702,63707]
name: child [63654,63659]
===
match
---
name: timedelta [10299,10308]
name: timedelta [10299,10308]
===
match
---
name: State [37139,37144]
name: State [37091,37096]
===
match
---
parameters [38132,38280]
parameters [38084,38232]
===
match
---
trailer [78509,78511]
trailer [78461,78463]
===
match
---
name: id [62029,62031]
name: id [61981,61983]
===
match
---
simple_stmt [36960,37086]
simple_stmt [36912,37038]
===
match
---
name: downstream_task_id [84605,84623]
name: downstream_task_id [84557,84575]
===
match
---
suite [22209,22389]
suite [22185,22365]
===
match
---
simple_stmt [68701,68845]
simple_stmt [68653,68797]
===
match
---
name: self [13249,13253]
name: self [13249,13253]
===
match
---
param [48691,48717]
param [48643,48669]
===
match
---
atom_expr [43063,43112]
atom_expr [43015,43064]
===
match
---
suite [57001,57025]
suite [56953,56977]
===
match
---
name: include_subdags [65289,65304]
name: include_subdags [65241,65256]
===
match
---
operator: == [93335,93337]
operator: == [93287,93289]
===
match
---
import_from [1362,1453]
import_from [1362,1453]
===
match
---
name: filter [37766,37772]
name: filter [37718,37724]
===
match
---
name: self [42353,42357]
name: self [42305,42309]
===
match
---
atom_expr [62258,62298]
atom_expr [62210,62250]
===
match
---
name: TI [52881,52883]
name: TI [52833,52835]
===
match
---
tfpdef [93751,93774]
tfpdef [93703,93726]
===
match
---
atom_expr [46998,47010]
atom_expr [46950,46962]
===
match
---
name: query [47999,48004]
name: query [47951,47956]
===
match
---
string: "Task is missing the start_date parameter" [67346,67388]
string: "Task is missing the start_date parameter" [67298,67340]
===
match
---
name: tis [43711,43714]
name: tis [43663,43666]
===
match
---
trailer [3660,3666]
trailer [3660,3666]
===
match
---
name: operators [45390,45399]
name: operators [45342,45351]
===
match
---
arith_expr [51298,51319]
arith_expr [51250,51271]
===
match
---
param [66123,66135]
param [66075,66087]
===
match
---
operator: = [74543,74544]
operator: = [74495,74496]
===
match
---
name: BACKFILL_JOB [77206,77218]
name: BACKFILL_JOB [77158,77170]
===
match
---
name: task [68599,68603]
name: task [68551,68555]
===
match
---
trailer [97931,97936]
trailer [97883,97888]
===
match
---
name: parent_dag [51661,51671]
name: parent_dag [51613,51623]
===
match
---
argument [52266,52289]
argument [52218,52241]
===
match
---
name: recursion_depth [56630,56645]
name: recursion_depth [56582,56597]
===
match
---
simple_stmt [12784,12822]
simple_stmt [12784,12822]
===
match
---
string: 'is_subdag' [84038,84049]
string: 'is_subdag' [83990,84001]
===
match
---
name: timezone [21361,21369]
name: timezone [21337,21345]
===
match
---
atom_expr [3548,3567]
atom_expr [3548,3567]
===
match
---
atom_expr [83229,83303]
atom_expr [83181,83255]
===
match
---
name: self [59920,59924]
name: self [59872,59876]
===
match
---
expr_stmt [20655,20685]
expr_stmt [20655,20685]
===
match
---
name: hash [17840,17844]
name: hash [17840,17844]
===
match
---
name: sqlalchemy [2638,2648]
name: sqlalchemy [2638,2648]
===
match
---
string: 'start_date' [14159,14171]
string: 'start_date' [14159,14171]
===
match
---
atom [2988,3043]
atom [2988,3043]
===
match
---
operator: = [25699,25700]
operator: = [25651,25652]
===
match
---
atom_expr [10587,10609]
atom_expr [10587,10609]
===
match
---
atom_expr [43892,43921]
atom_expr [43844,43873]
===
match
---
for_stmt [81584,82047]
for_stmt [81536,81999]
===
match
---
operator: = [78043,78044]
operator: = [77995,77996]
===
match
---
name: on_failure_callback [15854,15873]
name: on_failure_callback [15854,15873]
===
match
---
name: get_next [21024,21032]
name: get_next [21024,21032]
===
match
---
trailer [13903,13996]
trailer [13903,13996]
===
match
---
arglist [85551,85609]
arglist [85503,85561]
===
match
---
if_stmt [84879,85022]
if_stmt [84831,84974]
===
match
---
name: concurrency [88293,88304]
name: concurrency [88245,88256]
===
match
---
string: 'max_active_runs_per_dag' [10936,10961]
string: 'max_active_runs_per_dag' [10936,10961]
===
match
---
atom_expr [16575,16603]
atom_expr [16575,16603]
===
match
---
simple_stmt [62612,62664]
simple_stmt [62564,62616]
===
match
---
name: cls [98058,98061]
name: cls [98010,98013]
===
match
---
trailer [32465,32473]
trailer [32417,32425]
===
match
---
funcdef [80593,81154]
funcdef [80545,81106]
===
match
---
name: filter [81646,81652]
name: filter [81598,81604]
===
match
---
trailer [98401,98405]
trailer [98353,98357]
===
match
---
param [39122,39131]
param [39074,39083]
===
match
---
name: cls [98100,98103]
name: cls [98052,98055]
===
match
---
argument [59564,59589]
argument [59516,59541]
===
match
---
parameters [34063,34083]
parameters [34015,34035]
===
match
---
trailer [53905,53913]
trailer [53857,53865]
===
match
---
name: TI [55051,55053]
name: TI [55003,55005]
===
match
---
name: DagRun [40000,40006]
name: DagRun [39952,39958]
===
match
---
operator: } [76365,76366]
operator: } [76317,76318]
===
match
---
operator: = [71379,71380]
operator: = [71331,71332]
===
match
---
name: self [40017,40021]
name: self [39969,39973]
===
match
---
parameters [29807,29825]
parameters [29759,29777]
===
match
---
trailer [64617,64639]
trailer [64569,64591]
===
match
---
return_stmt [59885,59897]
return_stmt [59837,59849]
===
match
---
name: access_control [16551,16565]
name: access_control [16551,16565]
===
match
---
atom_expr [57736,57769]
atom_expr [57688,57721]
===
match
---
name: self [60464,60468]
name: self [60416,60420]
===
match
---
simple_stmt [91471,91755]
simple_stmt [91423,91707]
===
match
---
atom_expr [87633,87664]
atom_expr [87585,87616]
===
match
---
name: warn [75123,75127]
name: warn [75075,75079]
===
match
---
trailer [26711,26730]
trailer [26663,26682]
===
match
---
simple_stmt [75315,75358]
simple_stmt [75267,75310]
===
match
---
trailer [86257,86281]
trailer [86209,86233]
===
match
---
comparison [28619,28650]
comparison [28571,28602]
===
match
---
name: missing_dag_ids [76461,76476]
name: missing_dag_ids [76413,76428]
===
match
---
tfpdef [11302,11355]
tfpdef [11302,11355]
===
match
---
name: provide_session [38098,38113]
name: provide_session [38050,38065]
===
match
---
dictorsetmaker [18967,19017]
dictorsetmaker [18967,19017]
===
match
---
fstring_end: " [47361,47362]
fstring_end: " [47313,47314]
===
match
---
trailer [77367,77369]
trailer [77319,77321]
===
match
---
atom [45577,45597]
atom [45529,45549]
===
match
---
name: __hash__ [17363,17371]
name: __hash__ [17363,17371]
===
match
---
name: bulk_write_to_db [80250,80266]
name: bulk_write_to_db [80202,80218]
===
match
---
name: frozenset [83644,83653]
name: frozenset [83596,83605]
===
match
---
name: __new__ [60075,60082]
name: __new__ [60027,60034]
===
match
---
atom [25901,25951]
atom [25853,25903]
===
match
---
operator: , [27503,27504]
operator: , [27455,27456]
===
match
---
name: t [64908,64909]
name: t [64860,64861]
===
match
---
operator: = [59719,59720]
operator: = [59671,59672]
===
match
---
operator: , [83272,83273]
operator: , [83224,83225]
===
match
---
atom_expr [26548,26563]
atom_expr [26500,26515]
===
match
---
atom_expr [29843,29855]
atom_expr [29795,29807]
===
match
---
trailer [22599,22610]
trailer [22551,22562]
===
match
---
trailer [53829,53941]
trailer [53781,53893]
===
match
---
operator: } [48772,48773]
operator: } [48724,48725]
===
match
---
trailer [65568,65577]
trailer [65520,65529]
===
match
---
name: self [88247,88251]
name: self [88199,88203]
===
match
---
name: dag [79685,79688]
name: dag [79637,79640]
===
match
---
string: """Build a Jinja2 environment.""" [41292,41325]
string: """Build a Jinja2 environment.""" [41244,41277]
===
match
---
atom_expr [74750,74757]
atom_expr [74702,74709]
===
match
---
atom_expr [71820,71829]
atom_expr [71772,71781]
===
match
---
simple_stmt [3044,3091]
simple_stmt [3044,3091]
===
match
---
decorator [39783,39800]
decorator [39735,39752]
===
match
---
simple_stmt [36737,36755]
simple_stmt [36689,36707]
===
match
---
trailer [83255,83272]
trailer [83207,83224]
===
match
---
name: runs [37094,37098]
name: runs [37046,37050]
===
match
---
atom_expr [71206,71243]
atom_expr [71158,71195]
===
match
---
name: provide_session [29402,29417]
name: provide_session [29354,29369]
===
match
---
atom_expr [11837,11861]
atom_expr [11837,11861]
===
match
---
name: airflow [1968,1975]
name: airflow [1968,1975]
===
match
---
expr_stmt [62510,62562]
expr_stmt [62462,62514]
===
match
---
import_as_names [1728,1780]
import_as_names [1728,1780]
===
match
---
operator: , [84314,84315]
operator: , [84266,84267]
===
match
---
simple_stmt [1597,1622]
simple_stmt [1597,1622]
===
match
---
name: add_task [67107,67115]
name: add_task [67059,67067]
===
match
---
operator: , [55021,55022]
operator: , [54973,54974]
===
match
---
name: fileloc [78367,78374]
name: fileloc [78319,78326]
===
match
---
tfpdef [89664,89680]
tfpdef [89616,89632]
===
match
---
name: start_date [74457,74467]
name: start_date [74409,74419]
===
match
---
atom_expr [66791,66800]
atom_expr [66743,66752]
===
match
---
operator: , [71322,71323]
operator: , [71274,71275]
===
match
---
comparison [77240,77279]
comparison [77192,77231]
===
match
---
param [92623,92627]
param [92575,92579]
===
match
---
simple_stmt [57081,57144]
simple_stmt [57033,57096]
===
match
---
decorator [48224,48241]
decorator [48176,48193]
===
match
---
name: only_running [52128,52140]
name: only_running [52080,52092]
===
match
---
name: provide_session [89033,89048]
name: provide_session [88985,89000]
===
match
---
name: models [2021,2027]
name: models [2021,2027]
===
match
---
name: on_failure_callback [16416,16435]
name: on_failure_callback [16416,16435]
===
match
---
if_stmt [12124,12262]
if_stmt [12124,12262]
===
match
---
name: DeprecationWarning [75251,75269]
name: DeprecationWarning [75203,75221]
===
match
---
comparison [29532,29690]
comparison [29484,29642]
===
match
---
expr_stmt [62722,62753]
expr_stmt [62674,62705]
===
match
---
atom_expr [32712,32752]
atom_expr [32664,32704]
===
match
---
name: start_date [39110,39120]
name: start_date [39062,39072]
===
match
---
tfpdef [10671,10707]
tfpdef [10671,10707]
===
match
---
operator: + [21111,21112]
operator: + [21111,21112]
===
match
---
name: session [36648,36655]
name: session [36600,36607]
===
match
---
operator: , [11432,11433]
operator: , [11432,11433]
===
match
---
not_test [17264,17281]
not_test [17264,17281]
===
match
---
name: _context_managed_dag [98344,98364]
name: _context_managed_dag [98296,98316]
===
match
---
string: """Folder location of where the DAG object is instantiated.""" [32380,32442]
string: """Folder location of where the DAG object is instantiated.""" [32332,32394]
===
match
---
trailer [58899,58906]
trailer [58851,58858]
===
match
---
name: self [24717,24721]
name: self [24669,24673]
===
match
---
name: all [76292,76295]
name: all [76244,76247]
===
match
---
trailer [55118,55133]
trailer [55070,55085]
===
match
---
simple_stmt [62091,62139]
simple_stmt [62043,62091]
===
match
---
testlist_comp [44062,44083]
testlist_comp [44014,44035]
===
match
---
string: """This method is deprecated in favor of bulk_write_to_db""" [75045,75105]
string: """This method is deprecated in favor of bulk_write_to_db""" [74997,75057]
===
match
---
trailer [83658,83678]
trailer [83610,83630]
===
match
---
name: query [38826,38831]
name: query [38778,38783]
===
match
---
atom_expr [65086,65101]
atom_expr [65038,65053]
===
match
---
name: tis [52866,52869]
name: tis [52818,52821]
===
match
---
simple_stmt [32451,32494]
simple_stmt [32403,32446]
===
match
---
argument [56561,56576]
argument [56513,56528]
===
match
---
name: t [78790,78791]
name: t [78742,78743]
===
match
---
operator: & [51381,51382]
operator: & [51333,51334]
===
match
---
name: copied [63958,63964]
name: copied [63910,63916]
===
match
---
trailer [42337,42345]
trailer [42289,42297]
===
match
---
tfpdef [47633,47651]
tfpdef [47585,47603]
===
match
---
operator: = [16141,16142]
operator: = [16141,16142]
===
match
---
atom_expr [83377,83407]
atom_expr [83329,83359]
===
match
---
name: orm_dag [78430,78437]
name: orm_dag [78382,78389]
===
match
---
name: dag [65513,65516]
name: dag [65465,65468]
===
match
---
not_test [67290,67309]
not_test [67242,67261]
===
match
---
operator: , [11068,11069]
operator: , [11068,11069]
===
match
---
simple_stmt [51125,51149]
simple_stmt [51077,51101]
===
match
---
name: parent_group [63095,63107]
name: parent_group [63047,63059]
===
match
---
suite [89092,89174]
suite [89044,89126]
===
match
---
operator: == [77192,77194]
operator: == [77144,77146]
===
match
---
name: dag_id [89316,89322]
name: dag_id [89268,89274]
===
match
---
operator: , [35532,35533]
operator: , [35484,35485]
===
match
---
for_stmt [51287,51413]
for_stmt [51239,51365]
===
match
---
name: upstream_list [46757,46770]
name: upstream_list [46709,46722]
===
match
---
trailer [43062,43113]
trailer [43014,43065]
===
match
---
operator: = [21243,21244]
operator: = [21243,21244]
===
match
---
name: List [1130,1134]
name: List [1130,1134]
===
match
---
import_from [1234,1263]
import_from [1234,1263]
===
match
---
atom_expr [62946,62980]
atom_expr [62898,62932]
===
match
---
name: qry [82669,82672]
name: qry [82621,82624]
===
match
---
name: self [22179,22183]
name: self [22155,22159]
===
match
---
simple_stmt [43711,43757]
simple_stmt [43663,43709]
===
match
---
name: start_date [14011,14021]
name: start_date [14011,14021]
===
match
---
name: self [60495,60499]
name: self [60447,60451]
===
match
---
atom_expr [26017,26063]
atom_expr [25969,26015]
===
match
---
operator: = [86081,86082]
operator: = [86033,86034]
===
match
---
string: 'end_date' [13943,13953]
string: 'end_date' [13943,13953]
===
match
---
trailer [68061,68070]
trailer [68013,68022]
===
match
---
trailer [60692,60697]
trailer [60644,60649]
===
match
---
simple_stmt [57401,57414]
simple_stmt [57353,57366]
===
match
---
sync_comp_for [43316,43335]
sync_comp_for [43268,43287]
===
match
---
name: __eq__ [16924,16930]
name: __eq__ [16924,16930]
===
match
---
if_stmt [23363,23608]
if_stmt [23315,23560]
===
match
---
name: description [78602,78613]
name: description [78554,78565]
===
match
---
argument [52115,52140]
argument [52067,52092]
===
match
---
name: Column [86798,86804]
name: Column [86750,86756]
===
match
---
trailer [83653,83686]
trailer [83605,83638]
===
match
---
name: state [44337,44342]
name: state [44289,44294]
===
match
---
name: access_control [30795,30809]
name: access_control [30747,30761]
===
match
---
name: str [10499,10502]
name: str [10499,10502]
===
match
---
name: provide_session [48225,48240]
name: provide_session [48177,48192]
===
match
---
name: external_dag [55619,55631]
name: external_dag [55571,55583]
===
match
---
atom_expr [32740,32750]
atom_expr [32692,32702]
===
match
---
trailer [40422,40448]
trailer [40374,40400]
===
match
---
string: """         Given a list of dag_ids, get a set of Paused Dag Ids          :param dag_ids: List of Dag ids         :param session: ORM Session         :return: Paused Dag_ids         """ [89710,89895]
string: """         Given a list of dag_ids, get a set of Paused Dag Ids          :param dag_ids: List of Dag ids         :param session: ORM Session         :return: Paused Dag_ids         """ [89662,89847]
===
match
---
name: self [32952,32956]
name: self [32904,32908]
===
match
---
operator: @ [32758,32759]
operator: @ [32710,32711]
===
match
---
number: 0 [59031,59032]
number: 0 [58983,58984]
===
match
---
operator: = [66511,66512]
operator: = [66463,66464]
===
match
---
expr_stmt [76709,76726]
expr_stmt [76661,76678]
===
match
---
simple_stmt [2465,2512]
simple_stmt [2465,2512]
===
match
---
name: other [17276,17281]
name: other [17276,17281]
===
match
---
trailer [14826,14828]
trailer [14826,14828]
===
match
---
name: self [37790,37794]
name: self [37742,37746]
===
match
---
atom_expr [33990,34019]
atom_expr [33942,33971]
===
match
---
name: session [39518,39525]
name: session [39470,39477]
===
match
---
name: self [14175,14179]
name: self [14175,14179]
===
match
---
expr_stmt [76009,76041]
expr_stmt [75961,75993]
===
match
---
name: is_paused_upon_creation [76596,76619]
name: is_paused_upon_creation [76548,76571]
===
match
---
atom_expr [78524,78544]
atom_expr [78476,78496]
===
match
---
name: c [17140,17141]
name: c [17140,17141]
===
match
---
name: dag [80981,80984]
name: dag [80933,80936]
===
match
---
trailer [60277,60312]
trailer [60229,60264]
===
match
---
trailer [20481,20521]
trailer [20481,20521]
===
match
---
trailer [98092,98099]
trailer [98044,98051]
===
match
---
name: run_id [73723,73729]
name: run_id [73675,73681]
===
match
---
param [80007,80019]
param [79959,79971]
===
match
---
atom_expr [13889,13996]
atom_expr [13889,13996]
===
match
---
operator: , [80273,80274]
operator: , [80225,80226]
===
match
---
name: TaskInstance [83040,83052]
name: TaskInstance [82992,83004]
===
match
---
name: used_group_ids [63679,63693]
name: used_group_ids [63631,63645]
===
match
---
suite [62595,62664]
suite [62547,62616]
===
match
---
param [65275,65288]
param [65227,65240]
===
match
---
name: filter [83197,83203]
name: filter [83149,83155]
===
match
---
simple_stmt [14987,15030]
simple_stmt [14987,15030]
===
match
---
name: ORIENTATION_PRESETS [3044,3063]
name: ORIENTATION_PRESETS [3044,3063]
===
match
---
name: self [26609,26613]
name: self [26561,26565]
===
match
---
name: session [51492,51499]
name: session [51444,51451]
===
match
---
name: self [91044,91048]
name: self [90996,91000]
===
match
---
simple_stmt [81110,81129]
simple_stmt [81062,81081]
===
match
---
name: deepcopy [62951,62959]
name: deepcopy [62903,62911]
===
match
---
atom_expr [11043,11061]
atom_expr [11043,11061]
===
match
---
funcdef [60932,65154]
funcdef [60884,65106]
===
match
---
name: states [82944,82950]
name: states [82896,82902]
===
match
---
name: Optional [33812,33820]
name: Optional [33764,33772]
===
match
---
name: Integer [1421,1428]
name: Integer [1421,1428]
===
match
---
arith_expr [66771,66800]
arith_expr [66723,66752]
===
match
---
atom_expr [78830,78839]
atom_expr [78782,78791]
===
match
---
trailer [10746,10752]
trailer [10746,10752]
===
match
---
param [48278,48292]
param [48230,48244]
===
match
---
atom_expr [96605,96619]
atom_expr [96557,96571]
===
match
---
simple_stmt [40497,40563]
simple_stmt [40449,40515]
===
match
---
trailer [77111,77115]
trailer [77063,77067]
===
match
---
atom_expr [41033,41044]
atom_expr [40985,40996]
===
match
---
name: DagRun [39969,39975]
name: DagRun [39921,39927]
===
match
---
trailer [81652,81717]
trailer [81604,81669]
===
match
---
trailer [96777,96785]
trailer [96729,96737]
===
match
---
trailer [64539,64541]
trailer [64491,64493]
===
match
---
trailer [29934,29949]
trailer [29886,29901]
===
match
---
simple_stmt [89443,89577]
simple_stmt [89395,89529]
===
match
---
trailer [56968,56972]
trailer [56920,56924]
===
match
---
name: delay_on_limit_secs [71617,71636]
name: delay_on_limit_secs [71569,71588]
===
match
---
name: incr [36888,36892]
name: incr [36840,36844]
===
match
---
name: delete [79162,79168]
name: delete [79114,79120]
===
match
---
operator: = [12849,12850]
operator: = [12849,12850]
===
match
---
name: paused_dag_ids [89904,89918]
name: paused_dag_ids [89856,89870]
===
match
---
import_name [1204,1217]
import_name [1204,1217]
===
match
---
atom_expr [79238,79246]
atom_expr [79190,79198]
===
match
---
name: filter [52870,52876]
name: filter [52822,52828]
===
match
---
trailer [32216,32248]
trailer [32168,32200]
===
match
---
atom_expr [60101,60109]
atom_expr [60053,60061]
===
match
---
expr_stmt [51922,52656]
expr_stmt [51874,52608]
===
match
---
simple_stmt [67012,67048]
simple_stmt [66964,67000]
===
match
---
operator: } [18870,18871]
operator: } [18870,18871]
===
match
---
string: "The 'DAG.concurrency' attribute is deprecated. Please use 'DAG.max_active_tasks'." [30179,30262]
string: "The 'DAG.concurrency' attribute is deprecated. Please use 'DAG.max_active_tasks'." [30131,30214]
===
match
---
param [47458,47463]
param [47410,47415]
===
match
---
name: str [31926,31929]
name: str [31878,31881]
===
match
---
param [68940,68956]
param [68892,68908]
===
match
---
expr_stmt [48090,48145]
expr_stmt [48042,48097]
===
match
---
comparison [37876,37904]
comparison [37828,37856]
===
match
---
name: copied [63207,63213]
name: copied [63159,63165]
===
match
---
simple_stmt [60617,60676]
simple_stmt [60569,60628]
===
match
---
trailer [44177,44181]
trailer [44129,44133]
===
match
---
fstring_string: Invalid values of dag.orientation: only support  [15487,15535]
fstring_string: Invalid values of dag.orientation: only support  [15487,15535]
===
match
---
name: EdgeInfoType [85105,85117]
name: EdgeInfoType [85057,85069]
===
match
---
trailer [22353,22365]
trailer [22329,22341]
===
match
---
tfpdef [91417,91446]
tfpdef [91369,91398]
===
match
---
if_stmt [20468,21541]
if_stmt [20468,21517]
===
match
---
name: __dict__ [60145,60153]
name: __dict__ [60097,60105]
===
match
---
simple_stmt [43030,43114]
simple_stmt [42982,43066]
===
match
---
number: 1 [54323,54324]
number: 1 [54275,54276]
===
match
---
name: bind [95707,95711]
name: bind [95659,95663]
===
match
---
trailer [62260,62268]
trailer [62212,62220]
===
match
---
name: subdag_lst [41062,41072]
name: subdag_lst [41014,41024]
===
match
---
name: next_dagrun_after_date [23643,23665]
name: next_dagrun_after_date [23595,23617]
===
match
---
fstring [47309,47362]
fstring [47261,47314]
===
match
---
simple_stmt [95263,95326]
simple_stmt [95215,95278]
===
match
---
trailer [25601,25612]
trailer [25553,25564]
===
match
---
name: dag_id [47354,47360]
name: dag_id [47306,47312]
===
match
---
atom [81595,81746]
atom [81547,81698]
===
match
---
trailer [20078,20087]
trailer [20078,20087]
===
match
---
name: self [17327,17331]
name: self [17327,17331]
===
match
---
argument [74414,74443]
argument [74366,74395]
===
match
---
operator: , [17650,17651]
operator: , [17650,17651]
===
match
---
name: warn [47692,47696]
name: warn [47644,47648]
===
match
---
arith_expr [63018,63046]
arith_expr [62970,62998]
===
match
---
name: self [35305,35309]
name: self [35257,35261]
===
match
---
operator: == [39014,39016]
operator: == [38966,38968]
===
match
---
trailer [41869,41894]
trailer [41821,41846]
===
match
---
operator: ** [96919,96921]
operator: ** [96871,96873]
===
match
---
operator: , [74573,74574]
operator: , [74525,74526]
===
match
---
trailer [96918,96930]
trailer [96870,96882]
===
match
---
testlist_comp [23755,23765]
testlist_comp [23707,23717]
===
match
---
operator: != [19046,19048]
operator: != [19046,19048]
===
match
---
name: task_dict [64945,64954]
name: task_dict [64897,64906]
===
match
---
name: jinja_environment_kwargs [16644,16668]
name: jinja_environment_kwargs [16644,16668]
===
match
---
name: self [68563,68567]
name: self [68515,68519]
===
match
---
name: DagPickle [2045,2054]
name: DagPickle [2045,2054]
===
match
---
operator: = [53061,53062]
operator: = [53013,53014]
===
match
---
name: filter [66189,66195]
name: filter [66141,66147]
===
match
---
expr_stmt [87116,87146]
expr_stmt [87068,87098]
===
match
---
string: "Please use 'can_read' and 'can_edit', respectively." [19201,19254]
string: "Please use 'can_read' and 'can_edit', respectively." [19201,19254]
===
match
---
name: str [15111,15114]
name: str [15111,15114]
===
match
---
param [58266,58287]
param [58218,58239]
===
match
---
operator: } [59257,59258]
operator: } [59209,59210]
===
match
---
expr_stmt [15772,15818]
expr_stmt [15772,15818]
===
match
---
trailer [74732,74738]
trailer [74684,74690]
===
match
---
param [58359,58387]
param [58311,58339]
===
match
---
operator: = [92414,92415]
operator: = [92366,92367]
===
match
---
name: upstream_group_ids [64349,64367]
name: upstream_group_ids [64301,64319]
===
match
---
atom_expr [34265,34294]
atom_expr [34217,34246]
===
match
---
parameters [16930,16943]
parameters [16930,16943]
===
match
---
name: Optional [10221,10229]
name: Optional [10221,10229]
===
match
---
name: env [42026,42029]
name: env [41978,41981]
===
match
---
trailer [43727,43756]
trailer [43679,43708]
===
match
---
comparison [52881,52905]
comparison [52833,52857]
===
match
---
simple_stmt [25247,25271]
simple_stmt [25199,25223]
===
match
---
name: dttm [20726,20730]
name: dttm [20726,20730]
===
match
---
operator: , [84049,84050]
operator: , [84001,84002]
===
match
---
simple_stmt [79644,79703]
simple_stmt [79596,79655]
===
match
---
operator: = [63990,63991]
operator: = [63942,63943]
===
match
---
atom_expr [42727,42808]
atom_expr [42679,42760]
===
match
---
name: property [31647,31655]
name: property [31599,31607]
===
match
---
atom_expr [41076,41095]
atom_expr [41028,41047]
===
match
---
name: orientation [15393,15404]
name: orientation [15393,15404]
===
match
---
decorated [44667,44902]
decorated [44619,44854]
===
match
---
simple_stmt [60384,60440]
simple_stmt [60336,60392]
===
match
---
trailer [62966,62973]
trailer [62918,62925]
===
match
---
name: str [30956,30959]
name: str [30908,30911]
===
match
---
string: """         Returns the list of dag runs between start_date (inclusive) and end_date (inclusive).          :param start_date: The starting execution date of the DagRun to find.         :param end_date: The ending execution date of the DagRun to find.         :param session:         :return: The list of DagRuns found.         """ [39155,39485]
string: """         Returns the list of dag runs between start_date (inclusive) and end_date (inclusive).          :param start_date: The starting execution date of the DagRun to find.         :param end_date: The ending execution date of the DagRun to find.         :param session:         :return: The list of DagRuns found.         """ [39107,39437]
===
match
---
if_stmt [35095,35448]
if_stmt [35047,35400]
===
match
---
trailer [62908,62918]
trailer [62860,62870]
===
match
---
simple_stmt [85486,85531]
simple_stmt [85438,85483]
===
match
---
name: dag [64941,64944]
name: dag [64893,64896]
===
match
---
expr_stmt [16380,16447]
expr_stmt [16380,16447]
===
match
---
or_test [24995,25044]
or_test [24947,24996]
===
match
---
operator: = [83364,83365]
operator: = [83316,83317]
===
match
---
operator: = [57559,57560]
operator: = [57511,57512]
===
match
---
tfpdef [10769,10795]
tfpdef [10769,10795]
===
match
---
trailer [51735,51908]
trailer [51687,51860]
===
match
---
trailer [68603,68611]
trailer [68555,68563]
===
match
---
name: tasks [31750,31755]
name: tasks [31702,31707]
===
match
---
name: start_date [67483,67493]
name: start_date [67435,67445]
===
match
---
name: _dag_id [12306,12313]
name: _dag_id [12306,12313]
===
match
---
atom [32722,32751]
atom [32674,32703]
===
match
---
name: run_id [73668,73674]
name: run_id [73620,73626]
===
match
---
tfpdef [11372,11425]
tfpdef [11372,11425]
===
match
---
name: provide_session [39060,39075]
name: provide_session [39012,39027]
===
match
---
trailer [25550,25568]
trailer [25502,25520]
===
match
---
expr_stmt [62216,62299]
expr_stmt [62168,62251]
===
match
---
name: dp [66397,66399]
name: dp [66349,66351]
===
match
---
return_stmt [31144,31166]
return_stmt [31096,31118]
===
match
---
name: run_type [73901,73909]
name: run_type [73853,73861]
===
match
---
name: filter [90040,90046]
name: filter [89992,89998]
===
match
---
name: group [64680,64685]
name: group [64632,64637]
===
match
---
name: self [68679,68683]
name: self [68631,68635]
===
match
---
trailer [54260,54276]
trailer [54212,54228]
===
match
---
operator: = [48449,48450]
operator: = [48401,48402]
===
match
---
name: also_include [62510,62522]
name: also_include [62462,62474]
===
match
---
operator: , [22079,22080]
operator: , [22055,22056]
===
match
---
atom_expr [48098,48145]
atom_expr [48050,48097]
===
match
---
name: timezone [43043,43051]
name: timezone [42995,43003]
===
match
---
simple_stmt [12921,12951]
simple_stmt [12921,12951]
===
match
---
trailer [51347,51354]
trailer [51299,51306]
===
match
---
suite [44720,44902]
suite [44672,44854]
===
match
---
simple_stmt [19622,19760]
simple_stmt [19622,19760]
===
match
---
suite [29834,29864]
suite [29786,29816]
===
match
---
param [75427,75451]
param [75379,75403]
===
match
---
name: ForeignKey [85567,85577]
name: ForeignKey [85519,85529]
===
match
---
name: self [27499,27503]
name: self [27451,27455]
===
match
---
name: dag [78084,78087]
name: dag [78036,78039]
===
match
---
comparison [51356,51379]
comparison [51308,51331]
===
match
---
name: using_start_date [28569,28585]
name: using_start_date [28521,28537]
===
match
---
expr_stmt [60448,60475]
expr_stmt [60400,60427]
===
match
---
name: session [29311,29318]
name: session [29263,29270]
===
match
---
fstring_expr [15586,15599]
fstring_expr [15586,15599]
===
match
---
return_stmt [89101,89173]
return_stmt [89053,89125]
===
match
---
trailer [71970,71981]
trailer [71922,71933]
===
match
---
arglist [44159,44227]
arglist [44111,44179]
===
match
---
param [71843,71847]
param [71795,71799]
===
match
---
expr_stmt [25745,25772]
expr_stmt [25697,25724]
===
match
---
name: Optional [12801,12809]
name: Optional [12801,12809]
===
match
---
name: is_fixed_time_schedule [22184,22206]
name: is_fixed_time_schedule [22160,22182]
===
match
---
param [10251,10317]
param [10251,10317]
===
match
---
return_stmt [57211,57221]
return_stmt [57163,57173]
===
match
---
name: Callable [95096,95104]
name: Callable [95048,95056]
===
match
---
trailer [96575,96581]
trailer [96527,96533]
===
match
---
operator: = [64368,64369]
operator: = [64320,64321]
===
match
---
name: DateTime [22904,22912]
name: DateTime [22856,22864]
===
match
---
name: is_ [43983,43986]
name: is_ [43935,43938]
===
match
---
param [21568,21573]
param [21544,21549]
===
match
---
fstring_expr [74060,74076]
fstring_expr [74012,74028]
===
match
---
name: parse [13898,13903]
name: parse [13898,13903]
===
match
---
param [90714,90730]
param [90666,90682]
===
match
---
param [17298,17303]
param [17298,17303]
===
match
---
trailer [54990,54997]
trailer [54942,54949]
===
match
---
expr_stmt [73834,73887]
expr_stmt [73786,73839]
===
match
---
name: get_flat_relatives [62528,62546]
name: get_flat_relatives [62480,62498]
===
match
---
operator: } [63055,63056]
operator: } [63007,63008]
===
match
---
return_stmt [30340,30369]
return_stmt [30292,30321]
===
match
---
operator: { [88921,88922]
operator: { [88873,88874]
===
match
---
name: skip_locked [93608,93619]
name: skip_locked [93560,93571]
===
match
---
name: owner [32725,32730]
name: owner [32677,32682]
===
match
---
trailer [96277,96285]
trailer [96229,96237]
===
match
---
operator: , [9928,9929]
operator: , [9928,9929]
===
match
---
name: upstream_task_ids [64910,64927]
name: upstream_task_ids [64862,64879]
===
match
---
name: self [29930,29934]
name: self [29882,29886]
===
match
---
name: task_id [63510,63517]
name: task_id [63462,63469]
===
match
---
name: convert_to_utc [14093,14107]
name: convert_to_utc [14093,14107]
===
match
---
arglist [29298,29385]
arglist [29250,29337]
===
match
---
atom_expr [14856,14886]
atom_expr [14856,14886]
===
match
---
operator: ** [94766,94768]
operator: ** [94718,94720]
===
match
---
name: unique [88022,88028]
name: unique [87974,87980]
===
match
---
trailer [32744,32750]
trailer [32696,32702]
===
match
---
atom_expr [11949,11966]
atom_expr [11949,11966]
===
match
---
atom_expr [53966,53973]
atom_expr [53918,53925]
===
match
---
atom_expr [13793,13839]
atom_expr [13793,13839]
===
match
---
param [83485,83488]
param [83437,83440]
===
match
---
name: t [78825,78826]
name: t [78777,78778]
===
match
---
param [35528,35533]
param [35480,35485]
===
match
---
name: values [63419,63425]
name: values [63371,63377]
===
match
---
operator: , [55086,55087]
operator: , [55038,55039]
===
match
---
name: dag_model [92057,92066]
name: dag_model [92009,92018]
===
match
---
name: datetime [43063,43071]
name: datetime [43015,43023]
===
match
---
comparison [91982,92011]
comparison [91934,91963]
===
match
---
trailer [77814,77823]
trailer [77766,77775]
===
match
---
name: dagrun [35534,35540]
name: dagrun [35486,35492]
===
match
---
trailer [30742,30758]
trailer [30694,30710]
===
match
---
name: sys [96731,96734]
name: sys [96683,96686]
===
match
---
name: tz [21240,21242]
name: tz [21240,21242]
===
match
---
funcdef [58112,59898]
funcdef [58064,59850]
===
match
---
operator: = [48360,48361]
operator: = [48312,48313]
===
match
---
trailer [26094,26144]
trailer [26046,26096]
===
match
---
name: task [67862,67866]
name: task [67814,67818]
===
match
---
name: expression [3571,3581]
name: expression [3571,3581]
===
match
---
expr_stmt [3044,3090]
expr_stmt [3044,3090]
===
match
---
param [19404,19409]
param [19404,19409]
===
match
---
name: back [96724,96728]
name: back [96676,96680]
===
match
---
name: get_dagruns_between [39084,39103]
name: get_dagruns_between [39036,39055]
===
match
---
name: push_context_managed_dag [97968,97992]
name: push_context_managed_dag [97920,97944]
===
match
---
operator: , [68978,68979]
operator: , [68930,68931]
===
match
---
suite [75036,75358]
suite [74988,75310]
===
match
---
expr_stmt [96259,96285]
expr_stmt [96211,96237]
===
match
---
name: self [90241,90245]
name: self [90193,90197]
===
match
---
name: debug [65963,65968]
name: debug [65915,65920]
===
match
---
atom_expr [21753,21786]
atom_expr [21729,21762]
===
match
---
param [42896,42907]
param [42848,42859]
===
match
---
name: perms [19012,19017]
name: perms [19012,19017]
===
match
---
name: t [65234,65235]
name: t [65186,65187]
===
match
---
simple_stmt [65856,65911]
simple_stmt [65808,65863]
===
match
---
name: jinja2 [1211,1217]
name: jinja2 [1211,1217]
===
match
---
return_stmt [33296,33340]
return_stmt [33248,33292]
===
match
---
expr_stmt [66493,66530]
expr_stmt [66445,66482]
===
match
---
trailer [95240,95254]
trailer [95192,95206]
===
match
---
parameters [17371,17377]
parameters [17371,17377]
===
match
---
name: self [14605,14609]
name: self [14605,14609]
===
match
---
name: is_paused [93272,93281]
name: is_paused [93224,93233]
===
match
---
operator: = [38224,38225]
operator: = [38176,38177]
===
match
---
trailer [72463,72468]
trailer [72415,72420]
===
match
---
trailer [86452,86465]
trailer [86404,86417]
===
match
---
trailer [17439,17446]
trailer [17439,17446]
===
match
---
name: state [43977,43982]
name: state [43929,43934]
===
match
---
name: ScheduleInterval [2909,2925]
name: ScheduleInterval [2909,2925]
===
match
---
operator: { [15299,15300]
operator: { [15299,15300]
===
match
---
dictorsetmaker [9900,10081]
dictorsetmaker [9900,10081]
===
match
---
trailer [43895,43921]
trailer [43847,43873]
===
match
---
name: dag [79884,79887]
name: dag [79836,79839]
===
match
---
name: full_filepath [29887,29900]
name: full_filepath [29839,29852]
===
match
---
name: timezone [42976,42984]
name: timezone [42928,42936]
===
match
---
name: dag_run_state [48496,48509]
name: dag_run_state [48448,48461]
===
match
---
atom_expr [54441,54848]
atom_expr [54393,54800]
===
match
---
number: 10 [88144,88146]
number: 10 [88096,88098]
===
match
---
trailer [11751,11756]
trailer [11751,11756]
===
match
---
name: task [67835,67839]
name: task [67787,67791]
===
match
---
argument [71301,71322]
argument [71253,71274]
===
match
---
simple_stmt [15388,15419]
simple_stmt [15388,15419]
===
match
---
trailer [83662,83677]
trailer [83614,83629]
===
match
---
operator: = [98254,98255]
operator: = [98206,98207]
===
match
---
operator: , [33661,33662]
operator: , [33613,33614]
===
match
---
name: TI [33123,33125]
name: TI [33075,33077]
===
match
---
import_name [842,855]
import_name [842,855]
===
match
---
name: include_externally_triggered [3489,3517]
name: include_externally_triggered [3489,3517]
===
match
---
suite [89260,89332]
suite [89212,89284]
===
match
---
operator: = [97937,97938]
operator: = [97889,97890]
===
match
---
atom_expr [17717,17744]
atom_expr [17717,17744]
===
match
---
operator: , [59684,59685]
operator: , [59636,59637]
===
match
---
string: 'last_loaded' [83813,83826]
string: 'last_loaded' [83765,83778]
===
match
---
trailer [40894,40900]
trailer [40846,40852]
===
match
---
param [34328,34332]
param [34280,34284]
===
match
---
name: orm_dags [76832,76840]
name: orm_dags [76784,76792]
===
match
---
trailer [36505,36509]
trailer [36457,36461]
===
match
---
simple_stmt [26001,26064]
simple_stmt [25953,26016]
===
match
---
param [97993,97997]
param [97945,97949]
===
match
---
atom_expr [47936,47962]
atom_expr [47888,47914]
===
match
---
arglist [87964,88034]
arglist [87916,87986]
===
match
---
name: subdags [51303,51310]
name: subdags [51255,51262]
===
match
---
string: """         Return a DagParam object for current dag.          :param name: dag parameter name.         :param default: fallback value for dag parameter.         :return: DagParam instance for specified name and current dag.         """ [31334,31570]
string: """         Return a DagParam object for current dag.          :param name: dag parameter name.         :param default: fallback value for dag parameter.         :return: DagParam instance for specified name and current dag.         """ [31286,31522]
===
match
---
atom_expr [43129,43348]
atom_expr [43081,43300]
===
match
---
expr_stmt [12831,12862]
expr_stmt [12831,12862]
===
match
---
trailer [76411,76429]
trailer [76363,76381]
===
match
---
fstring_start: f" [16891,16893]
fstring_start: f" [16891,16893]
===
match
---
atom_expr [32723,32730]
atom_expr [32675,32682]
===
match
---
operator: , [93303,93304]
operator: , [93255,93256]
===
match
---
param [42543,42561]
param [42495,42513]
===
match
---
operator: { [11999,12000]
operator: { [11999,12000]
===
match
---
operator: = [53823,53824]
operator: = [53775,53776]
===
match
---
name: self [26017,26021]
name: self [25969,25973]
===
match
---
trailer [90089,90093]
trailer [90041,90045]
===
match
---
simple_stmt [26171,26239]
simple_stmt [26123,26191]
===
match
---
name: next_run_date [27301,27314]
name: next_run_date [27253,27266]
===
match
---
funcdef [66718,66909]
funcdef [66670,66861]
===
match
---
operator: , [88133,88134]
operator: , [88085,88086]
===
match
---
suite [91462,92576]
suite [91414,92528]
===
match
---
expr_stmt [87547,87597]
expr_stmt [87499,87549]
===
match
---
operator: , [1178,1179]
operator: , [1178,1179]
===
match
---
name: self [18053,18057]
name: self [18053,18057]
===
match
---
name: get_default_executor [71221,71241]
name: get_default_executor [71173,71193]
===
match
---
operator: , [24046,24047]
operator: , [23998,23999]
===
match
---
tfpdef [10326,10356]
tfpdef [10326,10356]
===
match
---
suite [18079,18125]
suite [18079,18125]
===
match
---
trailer [19645,19759]
trailer [19645,19759]
===
match
---
trailer [38043,38045]
trailer [37995,37997]
===
match
---
param [30938,30942]
param [30890,30894]
===
match
---
name: child [63974,63979]
name: child [63926,63931]
===
match
---
name: timezone [14240,14248]
name: timezone [14240,14248]
===
match
---
number: 0 [57456,57457]
number: 0 [57408,57409]
===
match
---
name: dag_id [38977,38983]
name: dag_id [38929,38935]
===
match
---
operator: = [51770,51771]
operator: = [51722,51723]
===
match
---
name: ti_list [57707,57714]
name: ti_list [57659,57666]
===
match
---
if_stmt [65345,65418]
if_stmt [65297,65370]
===
match
---
suite [88277,88693]
suite [88229,88645]
===
match
---
arith_expr [56630,56649]
arith_expr [56582,56601]
===
match
---
name: self [14660,14664]
name: self [14660,14664]
===
match
---
name: DEFAULT_VIEW_PRESETS [15057,15077]
name: DEFAULT_VIEW_PRESETS [15057,15077]
===
match
---
name: signature [1007,1016]
name: signature [1007,1016]
===
match
---
operator: , [85049,85050]
operator: , [85001,85002]
===
match
---
dotted_name [2101,2128]
dotted_name [2101,2128]
===
match
---
expr_stmt [66159,66235]
expr_stmt [66111,66187]
===
match
---
name: dag [51291,51294]
name: dag [51243,51246]
===
match
---
trailer [83232,83303]
trailer [83184,83255]
===
match
---
atom_expr [16106,16140]
atom_expr [16106,16140]
===
match
---
atom_expr [94260,94279]
atom_expr [94212,94231]
===
match
---
trailer [89131,89138]
trailer [89083,89090]
===
match
---
fstring_start: f" [59201,59203]
fstring_start: f" [59153,59155]
===
match
---
name: ID_LEN [85929,85935]
name: ID_LEN [85881,85887]
===
match
---
atom_expr [53825,53941]
atom_expr [53777,53893]
===
match
---
atom_expr [91129,91149]
atom_expr [91081,91101]
===
match
---
operator: , [35554,35555]
operator: , [35506,35507]
===
match
---
name: dag_id [12316,12322]
name: dag_id [12316,12322]
===
match
---
name: downstream_list [66851,66866]
name: downstream_list [66803,66818]
===
match
---
name: task [53976,53980]
name: task [53928,53932]
===
match
---
atom_expr [79194,79222]
atom_expr [79146,79174]
===
match
---
trailer [22778,22807]
trailer [22730,22759]
===
match
---
name: self [25646,25650]
name: self [25598,25602]
===
match
---
expr_stmt [98434,98465]
expr_stmt [98386,98417]
===
match
---
name: time [43105,43109]
name: time [43057,43061]
===
match
---
operator: = [13964,13965]
operator: = [13964,13965]
===
match
---
if_stmt [29055,29130]
if_stmt [29007,29082]
===
match
---
name: state [48175,48180]
name: state [48127,48132]
===
match
---
name: property [31981,31989]
name: property [31933,31941]
===
match
---
string: 'end_date' [13765,13775]
string: 'end_date' [13765,13775]
===
match
---
operator: @ [92581,92582]
operator: @ [92533,92534]
===
match
---
simple_stmt [54435,54849]
simple_stmt [54387,54801]
===
match
---
name: schedule_interval [35430,35447]
name: schedule_interval [35382,35399]
===
match
---
name: hour [20215,20219]
name: hour [20215,20219]
===
match
---
operator: -> [32364,32366]
operator: -> [32316,32318]
===
match
---
comp_op [29679,29685]
comp_op [29631,29637]
===
match
---
trailer [42049,42070]
trailer [42001,42022]
===
match
---
operator: = [62555,62556]
operator: = [62507,62508]
===
match
---
name: task [67043,67047]
name: task [66995,66999]
===
match
---
name: only_running [56186,56198]
name: only_running [56138,56150]
===
match
---
name: provide_session [75381,75396]
name: provide_session [75333,75348]
===
match
---
name: orm_dag [76490,76497]
name: orm_dag [76442,76449]
===
match
---
atom_expr [60270,60312]
atom_expr [60222,60264]
===
match
---
comparison [40000,40028]
comparison [39952,39980]
===
match
---
name: keys [65049,65053]
name: keys [65001,65005]
===
match
---
name: default_args [13417,13429]
name: default_args [13417,13429]
===
match
---
name: task [54256,54260]
name: task [54208,54212]
===
match
---
name: external_trigger [74509,74525]
name: external_trigger [74461,74477]
===
match
---
trailer [66591,66594]
trailer [66543,66546]
===
match
---
atom_expr [17185,17196]
atom_expr [17185,17196]
===
match
---
name: filter [39993,39999]
name: filter [39945,39951]
===
match
---
name: self [24691,24695]
name: self [24643,24647]
===
match
---
parameters [90707,90776]
parameters [90659,90728]
===
match
---
decorated [29869,29950]
decorated [29821,29902]
===
match
---
name: self [19716,19720]
name: self [19716,19720]
===
match
---
name: end_date [67883,67891]
name: end_date [67835,67843]
===
match
---
decorator [89179,89192]
decorator [89131,89144]
===
match
---
name: downstream_task_id [85074,85092]
name: downstream_task_id [85026,85044]
===
match
---
name: confirm_prompt [56249,56263]
name: confirm_prompt [56201,56215]
===
match
---
trailer [92555,92557]
trailer [92507,92509]
===
match
---
name: filter [77573,77579]
name: filter [77525,77531]
===
match
---
trailer [31733,31740]
trailer [31685,31692]
===
match
---
atom_expr [57801,57953]
atom_expr [57753,57905]
===
match
---
name: self [80268,80272]
name: self [80220,80224]
===
match
---
atom_expr [81137,81153]
atom_expr [81089,81105]
===
match
---
trailer [47002,47010]
trailer [46954,46962]
===
match
---
operator: = [3064,3065]
operator: = [3064,3065]
===
match
---
simple_stmt [74091,74149]
simple_stmt [74043,74101]
===
match
---
name: start_date [19670,19680]
name: start_date [19670,19680]
===
match
---
name: skip_locked [2679,2690]
name: skip_locked [2679,2690]
===
match
---
trailer [51509,51516]
trailer [51461,51468]
===
match
---
name: confirm_prompt [58266,58280]
name: confirm_prompt [58218,58232]
===
match
---
for_stmt [40720,41096]
for_stmt [40672,41048]
===
match
---
operator: , [69095,69096]
operator: , [69047,69048]
===
match
---
arglist [75919,75944]
arglist [75871,75896]
===
match
---
name: warn [40218,40222]
name: warn [40170,40174]
===
match
---
name: with_row_locks [76240,76254]
name: with_row_locks [76192,76206]
===
match
---
atom_expr [22959,22986]
atom_expr [22911,22938]
===
match
---
parameters [48254,48781]
parameters [48206,48733]
===
match
---
name: wrapper [97065,97072]
name: wrapper [97017,97024]
===
match
---
name: timezone [2327,2335]
name: timezone [2327,2335]
===
match
---
name: self [23458,23462]
name: self [23410,23414]
===
match
---
trailer [47195,47212]
trailer [47147,47164]
===
match
---
name: property [88943,88951]
name: property [88895,88903]
===
match
---
atom_expr [12959,12971]
atom_expr [12959,12971]
===
match
---
name: value [30626,30631]
name: value [30578,30583]
===
match
---
operator: @ [89014,89015]
operator: @ [88966,88967]
===
match
---
if_stmt [92338,92421]
if_stmt [92290,92373]
===
match
---
trailer [98099,98125]
trailer [98051,98077]
===
match
---
argument [60917,60925]
argument [60869,60877]
===
match
---
name: max_recursion_depth [48635,48654]
name: max_recursion_depth [48587,48606]
===
match
---
operator: = [76498,76499]
operator: = [76450,76451]
===
match
---
name: session [1535,1542]
name: session [1535,1542]
===
match
---
name: dag_id [38869,38875]
name: dag_id [38821,38827]
===
match
---
name: session [89078,89085]
name: session [89030,89037]
===
match
---
name: DagRun [77650,77656]
name: DagRun [77602,77608]
===
match
---
name: self [88551,88555]
name: self [88503,88507]
===
match
---
atom_expr [42390,42415]
atom_expr [42342,42367]
===
match
---
name: is_paused_upon_creation [11566,11589]
name: is_paused_upon_creation [11566,11589]
===
match
---
atom_expr [3603,3643]
atom_expr [3603,3643]
===
match
---
name: task_id [33183,33190]
name: task_id [33135,33142]
===
match
---
atom_expr [10383,10401]
atom_expr [10383,10401]
===
match
---
trailer [36584,36592]
trailer [36536,36544]
===
match
---
simple_stmt [66300,66376]
simple_stmt [66252,66328]
===
match
---
atom [18966,19018]
atom [18966,19018]
===
match
---
string: "This method is deprecated and will be removed in a future version." [47710,47778]
string: "This method is deprecated and will be removed in a future version." [47662,47730]
===
match
---
name: format [54680,54686]
name: format [54632,54638]
===
match
---
name: hash [17691,17695]
name: hash [17691,17695]
===
match
---
name: print [59046,59051]
name: print [58998,59003]
===
match
---
param [89664,89687]
param [89616,89639]
===
match
---
name: executor [71415,71423]
name: executor [71367,71375]
===
match
---
string: 'parent_dag' [9938,9950]
string: 'parent_dag' [9938,9950]
===
match
---
trailer [48012,48019]
trailer [47964,47971]
===
match
---
atom_expr [14837,14853]
atom_expr [14837,14853]
===
match
---
trailer [47935,47963]
trailer [47887,47915]
===
match
---
name: tis [43953,43956]
name: tis [43905,43908]
===
match
---
name: copy [63221,63225]
name: copy [63173,63177]
===
match
---
trailer [33993,33999]
trailer [33945,33951]
===
match
---
if_stmt [63501,63717]
if_stmt [63453,63669]
===
match
---
simple_stmt [14206,14297]
simple_stmt [14206,14297]
===
match
---
name: self [17185,17189]
name: self [17185,17189]
===
match
---
name: airflow [53146,53153]
name: airflow [53098,53105]
===
match
---
atom_expr [95902,95952]
atom_expr [95854,95904]
===
match
---
operator: , [85097,85098]
operator: , [85049,85050]
===
match
---
trailer [62057,62075]
trailer [62009,62027]
===
match
---
trailer [66195,66227]
trailer [66147,66179]
===
match
---
trailer [77572,77579]
trailer [77524,77531]
===
match
---
simple_stmt [87715,87749]
simple_stmt [87667,87701]
===
match
---
name: query [51139,51144]
name: query [51091,51096]
===
match
---
decorator [32068,32078]
decorator [32020,32030]
===
match
---
expr_stmt [88621,88692]
expr_stmt [88573,88644]
===
match
---
trailer [93573,93637]
trailer [93525,93589]
===
match
---
name: confirm_prompt [52162,52176]
name: confirm_prompt [52114,52128]
===
match
---
atom_expr [32867,32889]
atom_expr [32819,32841]
===
match
---
name: concurrency [12403,12414]
name: concurrency [12403,12414]
===
match
---
simple_stmt [21240,21283]
simple_stmt [21240,21259]
===
match
---
operator: -> [31226,31228]
operator: -> [31178,31180]
===
match
---
name: datetime [47607,47615]
name: datetime [47559,47567]
===
match
---
atom_expr [48154,48218]
atom_expr [48106,48170]
===
match
---
trailer [41911,41941]
trailer [41863,41893]
===
match
---
exprlist [18884,18895]
exprlist [18884,18895]
===
match
---
name: conf [10836,10840]
name: conf [10836,10840]
===
match
---
name: DagModel [33943,33951]
name: DagModel [33895,33903]
===
match
---
name: timezone [13462,13470]
name: timezone [13462,13470]
===
match
---
name: args [72007,72011]
name: args [71959,71963]
===
match
---
name: self [11892,11896]
name: self [11892,11896]
===
match
---
trailer [22045,22087]
trailer [22021,22063]
===
match
---
trailer [30165,30331]
trailer [30117,30283]
===
match
---
operator: , [43090,43091]
operator: , [43042,43043]
===
match
---
tfpdef [72485,72515]
tfpdef [72437,72467]
===
match
---
atom_expr [13297,13345]
atom_expr [13297,13345]
===
match
---
operator: -> [29737,29739]
operator: -> [29689,29691]
===
match
---
import_from [2096,2179]
import_from [2096,2179]
===
match
---
name: task [67478,67482]
name: task [67430,67434]
===
match
---
atom_expr [16304,16332]
atom_expr [16304,16332]
===
match
---
name: debug [94392,94397]
name: debug [94344,94349]
===
match
---
parameters [66116,66136]
parameters [66068,66088]
===
match
---
operator: = [11174,11175]
operator: = [11174,11175]
===
match
---
simple_stmt [66572,66595]
simple_stmt [66524,66547]
===
match
---
return_stmt [85012,85021]
return_stmt [84964,84973]
===
match
---
expr_stmt [64555,64639]
expr_stmt [64507,64591]
===
match
---
name: query [76050,76055]
name: query [76002,76007]
===
match
---
name: end_date [67867,67875]
name: end_date [67819,67827]
===
match
---
name: orm_tag [79050,79057]
name: orm_tag [79002,79009]
===
match
---
suite [66150,66614]
suite [66102,66566]
===
match
---
name: task_id [65613,65620]
name: task_id [65565,65572]
===
match
---
operator: = [67091,67092]
operator: = [67043,67044]
===
match
---
name: DR [3548,3550]
name: DR [3548,3550]
===
match
---
atom [93198,93542]
atom [93150,93494]
===
match
---
name: self [88621,88625]
name: self [88573,88577]
===
match
---
operator: = [72273,72274]
operator: = [72225,72226]
===
match
---
operator: , [58228,58229]
operator: , [58180,58181]
===
match
---
expr_stmt [78303,78328]
expr_stmt [78255,78280]
===
match
---
name: Type [10556,10560]
name: Type [10556,10560]
===
match
---
name: run_type [74587,74595]
name: run_type [74539,74547]
===
match
---
atom_expr [51369,51379]
atom_expr [51321,51331]
===
match
---
param [39834,39839]
param [39786,39791]
===
match
---
simple_stmt [83618,84514]
simple_stmt [83570,84466]
===
match
---
name: commit [58060,58066]
name: commit [58012,58018]
===
match
---
name: f [96917,96918]
name: f [96869,96870]
===
match
---
operator: @ [32068,32069]
operator: @ [32020,32021]
===
match
---
simple_stmt [94785,95076]
simple_stmt [94737,95028]
===
match
---
name: include_subdags [56332,56347]
name: include_subdags [56284,56299]
===
match
---
arglist [39577,39710]
arglist [39529,39662]
===
match
---
trailer [93501,93532]
trailer [93453,93484]
===
match
---
name: self [66572,66576]
name: self [66524,66528]
===
match
---
trailer [14991,15009]
trailer [14991,15009]
===
match
---
simple_stmt [65954,65972]
simple_stmt [65906,65924]
===
match
---
operator: , [59589,59590]
operator: , [59541,59542]
===
match
---
trailer [46997,47011]
trailer [46949,46963]
===
match
---
name: dag_ids [89644,89651]
name: dag_ids [89596,89603]
===
match
---
simple_stmt [71252,71812]
simple_stmt [71204,71764]
===
match
---
operator: = [19976,19977]
operator: = [19976,19977]
===
match
---
dictorsetmaker [62029,62081]
dictorsetmaker [61981,62033]
===
match
---
string: """         Add a task to the DAG          :param task: the task you want to add         :type task: task         """ [67137,67254]
string: """         Add a task to the DAG          :param task: the task you want to add         :type task: task         """ [67089,67206]
===
match
---
operator: = [69256,69257]
operator: = [69208,69209]
===
match
---
atom_expr [82971,83001]
atom_expr [82923,82953]
===
match
---
trailer [63418,63425]
trailer [63370,63377]
===
match
---
expr_stmt [92127,92154]
expr_stmt [92079,92106]
===
match
---
name: self [24042,24046]
name: self [23994,23998]
===
match
---
name: task_id [68419,68426]
name: task_id [68371,68378]
===
match
---
import_from [2512,2568]
import_from [2512,2568]
===
match
---
atom_expr [64302,64329]
atom_expr [64254,64281]
===
match
---
suite [79410,79595]
suite [79362,79547]
===
match
---
trailer [59321,59331]
trailer [59273,59283]
===
match
---
trailer [93495,93501]
trailer [93447,93453]
===
match
---
simple_stmt [85732,85754]
simple_stmt [85684,85706]
===
match
---
decorated [34025,34295]
decorated [33977,34247]
===
match
---
atom_expr [29760,29772]
atom_expr [29712,29724]
===
match
---
trailer [64247,64258]
trailer [64199,64210]
===
match
---
atom_expr [76669,76696]
atom_expr [76621,76648]
===
match
---
param [89378,89383]
param [89330,89335]
===
match
---
name: get [35228,35231]
name: get [35180,35183]
===
match
---
atom_expr [96770,96785]
atom_expr [96722,96737]
===
match
---
name: items [60154,60159]
name: items [60106,60111]
===
match
---
operator: , [52409,52410]
operator: , [52361,52362]
===
match
---
name: timezone [22008,22016]
name: timezone [21984,21992]
===
match
---
atom_expr [46983,47011]
atom_expr [46935,46963]
===
match
---
trailer [81706,81716]
trailer [81658,81668]
===
match
---
trailer [80995,81001]
trailer [80947,80953]
===
match
---
decorated [32499,32753]
decorated [32451,32705]
===
match
---
name: TI [52907,52909]
name: TI [52859,52861]
===
match
---
trailer [88216,88225]
trailer [88168,88177]
===
match
---
comparison [65348,65373]
comparison [65300,65325]
===
match
---
operator: = [75029,75030]
operator: = [74981,74982]
===
match
---
if_stmt [42387,42475]
if_stmt [42339,42427]
===
match
---
expr_stmt [40696,40711]
expr_stmt [40648,40663]
===
match
---
name: keys [31967,31971]
name: keys [31919,31923]
===
match
---
trailer [31956,31966]
trailer [31908,31918]
===
match
---
name: info [94674,94678]
name: info [94626,94630]
===
match
---
trailer [79127,79132]
trailer [79079,79084]
===
match
---
name: get [11181,11184]
name: get [11181,11184]
===
match
---
trailer [38868,38875]
trailer [38820,38827]
===
match
---
trailer [66472,66476]
trailer [66424,66428]
===
match
---
fstring_string: You are about to delete these  [59203,59233]
fstring_string: You are about to delete these  [59155,59185]
===
match
---
param [89398,89432]
param [89350,89384]
===
match
---
atom_expr [10484,10519]
atom_expr [10484,10519]
===
match
---
atom [23754,23766]
atom [23706,23718]
===
match
---
name: execution_date [38156,38170]
name: execution_date [38108,38122]
===
match
---
trailer [10847,10883]
trailer [10847,10883]
===
match
---
name: self [15827,15831]
name: self [15827,15831]
===
match
---
expr_stmt [46653,46668]
expr_stmt [46605,46620]
===
match
---
expr_stmt [81076,81097]
expr_stmt [81028,81049]
===
match
---
name: bulk_write_to_db [79913,79929]
name: bulk_write_to_db [79865,79881]
===
match
---
trailer [19522,19529]
trailer [19522,19529]
===
match
---
parameters [75421,75465]
parameters [75373,75417]
===
match
---
name: DagRun [39676,39682]
name: DagRun [39628,39634]
===
match
---
name: upstream [62649,62657]
name: upstream [62601,62609]
===
match
---
if_stmt [19566,19614]
if_stmt [19566,19614]
===
match
---
simple_stmt [866,877]
simple_stmt [866,877]
===
match
---
tfpdef [44934,44960]
tfpdef [44886,44912]
===
match
---
name: DEPRECATED_ACTION_CAN_DAG_EDIT [18765,18795]
name: DEPRECATED_ACTION_CAN_DAG_EDIT [18765,18795]
===
match
---
operator: , [75269,75270]
operator: , [75221,75222]
===
match
---
expr_stmt [35352,35377]
expr_stmt [35304,35329]
===
match
---
decorators [74934,74968]
decorators [74886,74920]
===
match
---
return_stmt [19345,19374]
return_stmt [19345,19374]
===
match
---
param [32800,32804]
param [32752,32756]
===
match
---
name: conditions [51447,51457]
name: conditions [51399,51409]
===
match
---
operator: = [13062,13063]
operator: = [13062,13063]
===
match
---
name: end_date [43537,43545]
name: end_date [43489,43497]
===
match
---
atom_expr [68563,68612]
atom_expr [68515,68564]
===
match
---
operator: , [39838,39839]
operator: , [39790,39791]
===
match
---
simple_stmt [45377,45454]
simple_stmt [45329,45406]
===
match
---
trailer [54776,54784]
trailer [54728,54736]
===
match
---
name: session [81241,81248]
name: session [81193,81200]
===
match
---
arglist [73960,73980]
arglist [73912,73932]
===
match
---
fstring_start: f" [65605,65607]
fstring_start: f" [65557,65559]
===
match
---
operator: , [65176,65177]
operator: , [65128,65129]
===
match
---
name: synchronize_session [91278,91297]
name: synchronize_session [91230,91249]
===
match
---
name: DagModel [34218,34226]
name: DagModel [34170,34178]
===
match
---
name: TaskInstance [44372,44384]
name: TaskInstance [44324,44336]
===
match
---
atom [9890,10087]
atom [9890,10087]
===
match
---
simple_stmt [74750,74765]
simple_stmt [74702,74717]
===
match
---
param [75422,75426]
param [75374,75378]
===
match
---
name: self [17958,17962]
name: self [17958,17962]
===
match
---
operator: , [82152,82153]
operator: , [82104,82105]
===
match
---
trailer [32272,32309]
trailer [32224,32261]
===
match
---
name: hasattr [60487,60494]
name: hasattr [60439,60446]
===
match
---
atom_expr [65592,65633]
atom_expr [65544,65585]
===
match
---
name: intersection [64706,64718]
name: intersection [64658,64670]
===
match
---
name: downstream_list [44885,44900]
name: downstream_list [44837,44852]
===
match
---
name: dict [76980,76984]
name: dict [76932,76936]
===
match
---
sync_comp_for [27236,27269]
sync_comp_for [27188,27221]
===
match
---
name: self [68644,68648]
name: self [68596,68600]
===
match
---
name: getboolean [86088,86098]
name: getboolean [86040,86050]
===
match
---
string: '_log' [84014,84020]
string: '_log' [83966,83972]
===
match
---
simple_stmt [65387,65418]
simple_stmt [65339,65370]
===
match
---
param [89238,89245]
param [89190,89197]
===
match
---
name: d [66078,66079]
name: d [66030,66031]
===
match
---
atom_expr [13164,13177]
atom_expr [13164,13177]
===
match
---
suite [24105,27476]
suite [24057,27428]
===
match
---
name: id [62055,62057]
name: id [62007,62009]
===
match
---
name: warnings [60684,60692]
name: warnings [60636,60644]
===
match
---
atom_expr [65115,65126]
atom_expr [65067,65078]
===
match
---
name: tags [79351,79355]
name: tags [79303,79307]
===
match
---
atom_expr [12189,12216]
atom_expr [12189,12216]
===
match
---
name: session [29586,29593]
name: session [29538,29545]
===
match
---
comparison [65069,65101]
comparison [65021,65053]
===
match
---
name: task [44642,44646]
name: task [44594,44598]
===
match
---
name: partial_subset [51721,51735]
name: partial_subset [51673,51687]
===
match
---
name: setter [29786,29792]
name: setter [29738,29744]
===
match
---
name: t [43320,43321]
name: t [43272,43273]
===
match
---
trailer [51505,51509]
trailer [51457,51461]
===
match
---
name: cls [89290,89293]
name: cls [89242,89245]
===
match
---
operator: , [94713,94714]
operator: , [94665,94666]
===
match
---
decorator [97947,97960]
decorator [97899,97912]
===
match
---
operator: @ [82070,82071]
operator: @ [82022,82023]
===
match
---
simple_stmt [28927,28969]
simple_stmt [28879,28921]
===
match
---
name: fileloc [12964,12971]
name: fileloc [12964,12971]
===
match
---
name: default_args [13730,13742]
name: default_args [13730,13742]
===
match
---
comparison [48020,48055]
comparison [47972,48007]
===
match
---
trailer [77962,77978]
trailer [77914,77930]
===
match
---
name: session [39132,39139]
name: session [39084,39091]
===
match
---
return_stmt [75315,75357]
return_stmt [75267,75309]
===
match
---
name: self [30716,30720]
name: self [30668,30672]
===
match
---
trailer [37822,37853]
trailer [37774,37805]
===
match
---
operator: -> [44698,44700]
operator: -> [44650,44652]
===
match
---
name: self [43200,43204]
name: self [43152,43156]
===
match
---
trailer [31129,31134]
trailer [31081,31086]
===
match
---
name: template_searchpath [41488,41507]
name: template_searchpath [41440,41459]
===
match
---
trailer [64685,64705]
trailer [64637,64657]
===
match
---
name: TIMEZONE [13613,13621]
name: TIMEZONE [13613,13621]
===
match
---
name: dag [94577,94580]
name: dag [94529,94532]
===
match
---
atom_expr [51356,51365]
atom_expr [51308,51317]
===
match
---
suite [15432,15615]
suite [15432,15615]
===
match
---
argument [19682,19699]
argument [19682,19699]
===
match
---
simple_stmt [38826,38918]
simple_stmt [38778,38870]
===
match
---
name: next_start [25393,25403]
name: next_start [25345,25355]
===
match
---
name: dttm [21951,21955]
name: dttm [21927,21931]
===
match
---
trailer [3617,3643]
trailer [3617,3643]
===
match
---
name: replace [90640,90647]
name: replace [90592,90599]
===
match
---
trailer [14263,14296]
trailer [14263,14296]
===
match
---
param [81224,81240]
param [81176,81192]
===
match
---
operator: == [53006,53008]
operator: == [52958,52960]
===
match
---
trailer [76595,76619]
trailer [76547,76571]
===
match
---
decorated [30764,30903]
decorated [30716,30855]
===
match
---
if_stmt [57422,57458]
if_stmt [57374,57410]
===
match
---
name: dag_id [81029,81035]
name: dag_id [80981,80987]
===
match
---
atom_expr [86354,86384]
atom_expr [86306,86336]
===
match
---
operator: , [1819,1820]
operator: , [1819,1820]
===
match
---
string: 'start_date' [13267,13279]
string: 'start_date' [13267,13279]
===
match
---
name: self [34328,34332]
name: self [34280,34284]
===
match
---
name: start_date [47541,47551]
name: start_date [47493,47503]
===
match
---
name: task_dict [62909,62918]
name: task_dict [62861,62870]
===
match
---
name: s [44082,44083]
name: s [44034,44035]
===
match
---
trailer [25749,25760]
trailer [25701,25712]
===
match
---
string: 'dag' [87534,87539]
string: 'dag' [87486,87491]
===
match
---
name: f [96276,96277]
name: f [96228,96229]
===
match
---
funcdef [31899,31975]
funcdef [31851,31927]
===
match
---
atom_expr [11323,11355]
atom_expr [11323,11355]
===
match
---
expr_stmt [95965,96008]
expr_stmt [95917,95960]
===
match
---
name: __lt__ [17291,17297]
name: __lt__ [17291,17297]
===
match
---
trailer [29847,29855]
trailer [29799,29807]
===
match
---
sync_comp_for [83137,83165]
sync_comp_for [83089,83117]
===
match
---
atom_expr [86083,86137]
atom_expr [86035,86089]
===
match
---
atom_expr [57507,57537]
atom_expr [57459,57489]
===
match
---
trailer [12931,12941]
trailer [12931,12941]
===
match
---
trailer [17133,17148]
trailer [17133,17148]
===
match
---
trailer [48110,48145]
trailer [48062,48097]
===
match
---
name: all [91903,91906]
name: all [91855,91858]
===
match
---
argument [55343,55365]
argument [55295,55317]
===
match
---
trailer [57511,57516]
trailer [57463,57468]
===
match
---
simple_stmt [87329,87363]
simple_stmt [87281,87315]
===
match
---
expr_stmt [87870,88042]
expr_stmt [87822,87994]
===
match
---
trailer [68888,68897]
trailer [68840,68849]
===
match
---
simple_stmt [66951,66969]
simple_stmt [66903,66921]
===
match
---
operator: , [60805,60806]
operator: , [60757,60758]
===
match
---
simple_stmt [66428,66453]
simple_stmt [66380,66405]
===
match
---
name: int [10791,10794]
name: int [10791,10794]
===
match
---
atom [65674,65676]
atom [65626,65628]
===
match
---
name: timedelta [977,986]
name: timedelta [977,986]
===
match
---
name: following_schedule [28729,28747]
name: following_schedule [28681,28699]
===
match
---
operator: , [74131,74132]
operator: , [74083,74084]
===
match
---
expr_stmt [25283,25324]
expr_stmt [25235,25276]
===
match
---
name: dag [76544,76547]
name: dag [76496,76499]
===
match
---
atom_expr [60448,60461]
atom_expr [60400,60413]
===
match
---
name: orm_dag [77963,77970]
name: orm_dag [77915,77922]
===
match
---
name: copied [63273,63279]
name: copied [63225,63231]
===
match
---
comp_if [44079,44083]
comp_if [44031,44035]
===
match
---
name: DagRun [77037,77043]
name: DagRun [76989,76995]
===
match
---
name: state [83287,83292]
name: state [83239,83244]
===
match
---
name: start_date [28090,28100]
name: start_date [28042,28052]
===
match
---
name: existing_dag_ids [76412,76428]
name: existing_dag_ids [76364,76380]
===
match
---
operator: @ [82052,82053]
operator: @ [82004,82005]
===
match
---
trailer [44217,44221]
trailer [44169,44173]
===
match
---
name: value [29814,29819]
name: value [29766,29771]
===
match
---
name: include_direct_upstream [61108,61131]
name: include_direct_upstream [61060,61083]
===
match
---
trailer [39051,39053]
trailer [39003,39005]
===
match
---
simple_stmt [71858,71899]
simple_stmt [71810,71851]
===
match
---
atom_expr [33169,33191]
atom_expr [33121,33143]
===
match
---
param [95382,95390]
param [95334,95342]
===
match
---
atom_expr [28238,28248]
atom_expr [28190,28200]
===
match
---
atom_expr [75003,75020]
atom_expr [74955,74972]
===
match
---
name: max_active_tasks [12695,12711]
name: max_active_tasks [12695,12711]
===
match
---
name: next_run_date [28681,28694]
name: next_run_date [28633,28646]
===
match
---
name: dag [74754,74757]
name: dag [74706,74709]
===
match
---
name: self [35425,35429]
name: self [35377,35381]
===
match
---
name: session [57860,57867]
name: session [57812,57819]
===
match
---
while_stmt [45831,47364]
while_stmt [45783,47316]
===
match
---
dotted_name [95336,95351]
dotted_name [95288,95303]
===
match
---
comparison [16411,16447]
comparison [16411,16447]
===
match
---
operator: > [54325,54326]
operator: > [54277,54278]
===
match
---
name: task_dict [68173,68182]
name: task_dict [68125,68134]
===
match
---
name: _value [18066,18072]
name: _value [18066,18072]
===
match
---
argument [62547,62561]
argument [62499,62513]
===
match
---
atom_expr [85551,85565]
atom_expr [85503,85517]
===
match
---
suite [75466,79960]
suite [75418,79912]
===
match
---
arglist [35109,35136]
arglist [35061,35088]
===
match
---
simple_stmt [2569,2619]
simple_stmt [2569,2619]
===
match
---
atom_expr [20775,20808]
atom_expr [20775,20808]
===
match
---
atom_expr [54256,54276]
atom_expr [54208,54228]
===
match
---
name: self [14264,14268]
name: self [14264,14268]
===
match
---
argument [95719,95727]
argument [95671,95679]
===
match
---
tfpdef [19483,19511]
tfpdef [19483,19511]
===
match
---
comparison [21409,21454]
comparison [21385,21430]
===
match
---
name: tis [53057,53060]
name: tis [53009,53012]
===
match
---
trailer [62062,62074]
trailer [62014,62026]
===
match
---
atom_expr [55564,55574]
atom_expr [55516,55526]
===
match
---
simple_stmt [69361,70877]
simple_stmt [69313,70829]
===
match
---
operator: = [76515,76516]
operator: = [76467,76468]
===
match
---
name: task_group [2844,2854]
name: task_group [2844,2854]
===
match
---
trailer [81151,81153]
trailer [81103,81105]
===
match
---
dictorsetmaker [91246,91275]
dictorsetmaker [91198,91227]
===
match
---
param [32358,32362]
param [32310,32314]
===
match
---
simple_stmt [96259,96286]
simple_stmt [96211,96238]
===
match
---
name: DAG [97879,97882]
name: DAG [97831,97834]
===
match
---
atom [13064,13066]
atom [13064,13066]
===
match
---
operator: = [86796,86797]
operator: = [86748,86749]
===
match
---
atom_expr [26187,26238]
atom_expr [26139,26190]
===
match
---
operator: = [86152,86153]
operator: = [86104,86105]
===
match
---
trailer [52869,52876]
trailer [52821,52828]
===
match
---
name: security [2193,2201]
name: security [2193,2201]
===
match
---
operator: @ [29955,29956]
operator: @ [29907,29908]
===
match
---
import_from [1826,1878]
import_from [1826,1878]
===
match
---
simple_stmt [37918,38061]
simple_stmt [37870,38013]
===
match
---
trailer [22183,22206]
trailer [22159,22182]
===
match
---
argument [71367,71392]
argument [71319,71344]
===
match
---
parameters [39833,39853]
parameters [39785,39805]
===
match
---
name: has_dag_runs [29426,29438]
name: has_dag_runs [29378,29390]
===
match
---
simple_stmt [32039,32063]
simple_stmt [31991,32015]
===
match
---
trailer [48166,48218]
trailer [48118,48170]
===
match
---
operator: = [37359,37360]
operator: = [37311,37312]
===
match
---
name: TaskInstance [82700,82712]
name: TaskInstance [82652,82664]
===
match
---
atom_expr [78786,78840]
atom_expr [78738,78792]
===
match
---
operator: == [89155,89157]
operator: == [89107,89109]
===
match
---
name: memo [62117,62121]
name: memo [62069,62073]
===
match
---
param [10812,10884]
param [10812,10884]
===
match
---
name: self [41255,41259]
name: self [41207,41211]
===
match
---
atom_expr [31121,31134]
atom_expr [31073,31086]
===
match
---
suite [57788,57954]
suite [57740,57906]
===
match
---
operator: @ [47405,47406]
operator: @ [47357,47358]
===
match
---
name: TI [54988,54990]
name: TI [54940,54942]
===
match
---
trailer [26084,26088]
trailer [26036,26040]
===
match
---
name: Boolean [86161,86168]
name: Boolean [86113,86120]
===
match
---
operator: = [66038,66039]
operator: = [65990,65991]
===
match
---
name: s [44062,44063]
name: s [44014,44015]
===
match
---
operator: = [54254,54255]
operator: = [54206,54207]
===
match
---
trailer [83376,83408]
trailer [83328,83360]
===
match
---
trailer [57741,57749]
trailer [57693,57701]
===
match
---
name: DagModel [34000,34008]
name: DagModel [33952,33960]
===
match
---
not_test [26567,26584]
not_test [26519,26536]
===
match
---
operator: , [30624,30625]
operator: , [30576,30577]
===
match
---
expr_stmt [55606,55861]
expr_stmt [55558,55813]
===
match
---
expr_stmt [60384,60439]
expr_stmt [60336,60391]
===
match
---
trailer [83584,83604]
trailer [83536,83556]
===
match
---
name: ti [57108,57110]
name: ti [57060,57062]
===
match
---
name: now [25407,25410]
name: now [25359,25362]
===
match
---
operator: -> [34084,34086]
operator: -> [34036,34038]
===
match
---
trailer [33182,33190]
trailer [33134,33142]
===
match
---
name: verbose [69249,69256]
name: verbose [69201,69208]
===
match
---
name: is_paused_at_creation [86178,86199]
name: is_paused_at_creation [86130,86151]
===
match
---
or_test [24687,24731]
or_test [24639,24683]
===
match
---
suite [66752,66909]
suite [66704,66861]
===
match
---
name: has_task_concurrency_limits [87603,87630]
name: has_task_concurrency_limits [87555,87582]
===
match
---
suite [83343,83409]
suite [83295,83361]
===
match
---
name: DR [3618,3620]
name: DR [3618,3620]
===
match
---
decorated [92581,93638]
decorated [92533,93590]
===
match
---
fstring_end: ' [15313,15314]
fstring_end: ' [15313,15314]
===
match
---
subscriptlist [3126,3141]
subscriptlist [3126,3141]
===
match
---
name: copied [63560,63566]
name: copied [63512,63518]
===
match
---
tfpdef [72204,72225]
tfpdef [72156,72177]
===
match
---
name: Integer [87573,87580]
name: Integer [87525,87532]
===
match
---
arglist [93574,93636]
arglist [93526,93588]
===
match
---
trailer [82863,82871]
trailer [82815,82823]
===
match
---
name: dag [68452,68455]
name: dag [68404,68407]
===
match
---
trailer [66528,66530]
trailer [66480,66482]
===
match
---
name: staticmethod [18202,18214]
name: staticmethod [18202,18214]
===
match
---
suite [22406,22611]
suite [22382,22563]
===
match
---
trailer [36676,36683]
trailer [36628,36635]
===
match
---
name: first [89324,89329]
name: first [89276,89281]
===
match
---
atom_expr [87729,87748]
atom_expr [87681,87700]
===
match
---
operator: = [39502,39503]
operator: = [39454,39455]
===
match
---
operator: , [69006,69007]
operator: , [68958,68959]
===
match
---
name: datetime [22484,22492]
name: datetime [22460,22468]
===
match
---
name: verify_integrity [74875,74891]
name: verify_integrity [74827,74843]
===
match
---
name: keys [64955,64959]
name: keys [64907,64911]
===
match
---
name: execution_date [48118,48132]
name: execution_date [48070,48084]
===
match
---
operator: = [86444,86445]
operator: = [86396,86397]
===
match
---
atom_expr [77963,77977]
atom_expr [77915,77929]
===
match
---
name: tis [51431,51434]
name: tis [51383,51386]
===
match
---
operator: , [51893,51894]
operator: , [51845,51846]
===
match
---
name: append [47045,47051]
name: append [46997,47003]
===
match
---
atom_expr [18899,18921]
atom_expr [18899,18921]
===
match
---
name: dttm [21926,21930]
name: dttm [21902,21906]
===
match
---
operator: , [75237,75238]
operator: , [75189,75190]
===
match
---
expr_stmt [3408,3419]
expr_stmt [3408,3419]
===
match
---
name: t [27259,27260]
name: t [27211,27212]
===
match
---
name: state [44212,44217]
name: state [44164,44169]
===
match
---
comparison [52793,52822]
comparison [52745,52774]
===
match
---
atom_expr [42975,43017]
atom_expr [42927,42969]
===
match
---
operator: , [48625,48626]
operator: , [48577,48578]
===
match
---
atom_expr [18967,18999]
atom_expr [18967,18999]
===
match
---
operator: = [13395,13396]
operator: = [13395,13396]
===
match
---
name: Integer [86879,86886]
name: Integer [86831,86838]
===
match
---
trailer [66023,66037]
trailer [65975,65989]
===
match
---
simple_stmt [14449,14492]
simple_stmt [14449,14492]
===
match
---
funcdef [29177,29396]
funcdef [29129,29348]
===
match
---
name: user_defined_macros [10619,10638]
name: user_defined_macros [10619,10638]
===
match
---
atom_expr [36616,36656]
atom_expr [36568,36608]
===
match
---
atom_expr [13804,13833]
atom_expr [13804,13833]
===
match
---
name: f_kwargs [96511,96519]
name: f_kwargs [96463,96471]
===
match
---
string: 'start_date' [9960,9972]
string: 'start_date' [9960,9972]
===
match
---
name: max_recursion_depth [52504,52523]
name: max_recursion_depth [52456,52475]
===
match
---
name: filter [48013,48019]
name: filter [47965,47971]
===
match
---
param [90606,90610]
param [90558,90562]
===
match
---
operator: , [84117,84118]
operator: , [84069,84070]
===
match
---
atom_expr [40418,40450]
atom_expr [40370,40402]
===
match
---
simple_stmt [36558,36594]
simple_stmt [36510,36546]
===
match
---
simple_stmt [62326,62400]
simple_stmt [62278,62352]
===
match
---
string: "failed to invoke dag state update callback" [36820,36864]
string: "failed to invoke dag state update callback" [36772,36816]
===
match
---
parameters [42857,42921]
parameters [42809,42873]
===
match
---
trailer [68081,68090]
trailer [68033,68042]
===
match
---
simple_stmt [22623,22664]
simple_stmt [22575,22616]
===
match
---
simple_stmt [18844,18872]
simple_stmt [18844,18872]
===
match
---
tfpdef [84582,84603]
tfpdef [84534,84555]
===
match
---
argument [56614,56649]
argument [56566,56601]
===
match
---
name: task [68133,68137]
name: task [68085,68089]
===
match
---
name: self [44928,44932]
name: self [44880,44884]
===
match
---
expr_stmt [76649,76696]
expr_stmt [76601,76648]
===
match
---
name: dag_run_state [57925,57938]
name: dag_run_state [57877,57890]
===
match
---
operator: = [85524,85525]
operator: = [85476,85477]
===
match
---
simple_stmt [64885,64963]
simple_stmt [64837,64915]
===
match
---
name: self [32474,32478]
name: self [32426,32430]
===
match
---
string: 'partial' [83957,83966]
string: 'partial' [83909,83918]
===
match
---
parameters [31281,31312]
parameters [31233,31264]
===
match
---
number: 2 [34610,34611]
number: 2 [34562,34563]
===
match
---
fstring_string:  tasks:\n [59240,59249]
fstring_string:  tasks:\n [59192,59201]
===
match
---
atom_expr [83654,83685]
atom_expr [83606,83637]
===
match
---
name: other [16937,16942]
name: other [16937,16942]
===
match
---
trailer [10441,10446]
trailer [10441,10446]
===
match
---
operator: ** [60598,60600]
operator: ** [60550,60552]
===
match
---
name: start_date [43080,43090]
name: start_date [43032,43042]
===
match
---
name: execution_date [38798,38812]
name: execution_date [38750,38764]
===
match
---
name: jinja_env_options [41840,41857]
name: jinja_env_options [41792,41809]
===
match
---
expr_stmt [13022,13066]
expr_stmt [13022,13066]
===
match
---
simple_stmt [48090,48146]
simple_stmt [48042,48098]
===
match
---
operator: , [61098,61099]
operator: , [61050,61051]
===
match
---
name: task_ids_or_regex [62381,62398]
name: task_ids_or_regex [62333,62350]
===
match
---
operator: , [17647,17648]
operator: , [17647,17648]
===
match
---
name: dag_run_state [59720,59733]
name: dag_run_state [59672,59685]
===
match
---
name: provide_session [79966,79981]
name: provide_session [79918,79933]
===
match
---
decorator [29706,29716]
decorator [29658,29668]
===
match
---
name: self [62244,62248]
name: self [62196,62200]
===
match
---
trailer [91772,91861]
trailer [91724,91813]
===
match
---
fstring_string: $ [55715,55716]
fstring_string: $ [55667,55668]
===
match
---
return_stmt [80524,80548]
return_stmt [80476,80500]
===
match
---
name: cron [22298,22302]
name: cron [22274,22278]
===
match
---
number: 1 [51809,51810]
number: 1 [51761,51762]
===
match
---
suite [46771,46857]
suite [46723,46809]
===
match
---
simple_stmt [53798,53942]
simple_stmt [53750,53894]
===
match
---
trailer [36618,36639]
trailer [36570,36591]
===
match
---
name: Boolean [86361,86368]
name: Boolean [86313,86320]
===
match
---
expr_stmt [44109,44254]
expr_stmt [44061,44206]
===
match
---
name: ACTION_CAN_EDIT [18809,18824]
name: ACTION_CAN_EDIT [18809,18824]
===
match
---
simple_stmt [66884,66909]
simple_stmt [66836,66861]
===
match
---
name: dag_kwargs [95314,95324]
name: dag_kwargs [95266,95276]
===
match
---
name: session [81999,82006]
name: session [81951,81958]
===
match
---
decorator [29955,29977]
decorator [29907,29929]
===
match
---
name: StrictUndefined [10594,10609]
name: StrictUndefined [10594,10609]
===
match
---
name: render_template_as_native_obj [41912,41941]
name: render_template_as_native_obj [41864,41893]
===
match
---
name: TI [33180,33182]
name: TI [33132,33134]
===
match
---
funcdef [90590,90664]
funcdef [90542,90616]
===
match
---
simple_stmt [83023,83070]
simple_stmt [82975,83022]
===
match
---
atom_expr [47907,47963]
atom_expr [47859,47915]
===
match
---
name: is_active [92355,92364]
name: is_active [92307,92316]
===
match
---
trailer [65794,65800]
trailer [65746,65752]
===
match
---
trailer [17189,17196]
trailer [17189,17196]
===
match
---
operator: , [31286,31287]
operator: , [31238,31239]
===
match
---
trailer [79455,79488]
trailer [79407,79440]
===
match
---
name: timezone [20737,20745]
name: timezone [20737,20745]
===
match
---
name: graph_unsorted [45548,45562]
name: graph_unsorted [45500,45514]
===
match
---
name: include_subdags [58721,58736]
name: include_subdags [58673,58688]
===
match
---
simple_stmt [58998,59011]
simple_stmt [58950,58963]
===
match
---
simple_stmt [96770,96828]
simple_stmt [96722,96780]
===
match
---
name: self [44455,44459]
name: self [44407,44411]
===
match
---
operator: = [17403,17404]
operator: = [17403,17404]
===
match
---
expr_stmt [87603,87664]
expr_stmt [87555,87616]
===
match
---
parameters [34710,34716]
parameters [34662,34668]
===
match
---
param [66633,66637]
param [66585,66589]
===
match
---
if_stmt [38926,39025]
if_stmt [38878,38977]
===
match
---
if_stmt [55466,55578]
if_stmt [55418,55530]
===
match
---
name: make_naive [20715,20725]
name: make_naive [20715,20725]
===
match
---
atom_expr [38172,38185]
atom_expr [38124,38137]
===
match
---
sliceop [97121,97124]
sliceop [97073,97076]
===
match
---
trailer [53073,53099]
trailer [53025,53051]
===
match
---
trailer [22483,22493]
trailer [22459,22469]
===
match
---
simple_stmt [38290,38618]
simple_stmt [38242,38570]
===
match
---
operator: , [77541,77542]
operator: , [77493,77494]
===
match
---
operator: = [43583,43584]
operator: = [43535,43536]
===
match
---
trailer [78235,78246]
trailer [78187,78198]
===
match
---
operator: , [52244,52245]
operator: , [52196,52197]
===
match
---
name: DagRunType [77195,77205]
name: DagRunType [77147,77157]
===
match
---
trailer [86087,86098]
trailer [86039,86050]
===
match
---
expr_stmt [28927,28968]
expr_stmt [28879,28920]
===
match
---
name: log [36381,36384]
name: log [36333,36336]
===
match
---
name: f_code [96793,96799]
name: f_code [96745,96751]
===
match
---
atom_expr [79669,79680]
atom_expr [79621,79632]
===
match
---
factor [36506,36508]
factor [36458,36460]
===
match
---
name: next_dagrun_info [94164,94180]
name: next_dagrun_info [94116,94132]
===
match
---
atom_expr [79855,79870]
atom_expr [79807,79822]
===
match
---
operator: = [95278,95279]
operator: = [95230,95231]
===
match
---
argument [56125,56148]
argument [56077,56100]
===
match
---
trailer [77851,77855]
trailer [77803,77807]
===
match
---
name: orm_dag [79066,79073]
name: orm_dag [79018,79025]
===
match
---
trailer [13429,13443]
trailer [13429,13443]
===
match
---
operator: { [90132,90133]
operator: { [90084,90085]
===
match
---
name: DagModel [91129,91137]
name: DagModel [91081,91089]
===
match
---
trailer [10122,10138]
trailer [10122,10138]
===
match
---
comparison [46795,46825]
comparison [46747,46777]
===
match
---
parameters [90240,90246]
parameters [90192,90198]
===
match
---
atom_expr [18797,18824]
atom_expr [18797,18824]
===
match
---
name: next_run_date [26315,26328]
name: next_run_date [26267,26280]
===
match
---
name: key [77909,77912]
name: key [77861,77864]
===
match
---
name: result [60561,60567]
name: result [60513,60519]
===
match
---
name: tis [51125,51128]
name: tis [51077,51080]
===
match
---
operator: = [28057,28058]
operator: = [28009,28010]
===
match
---
trailer [11982,12002]
trailer [11982,12002]
===
match
---
return_stmt [90493,90570]
return_stmt [90445,90522]
===
match
---
suite [62203,62300]
suite [62155,62252]
===
match
---
operator: , [1095,1096]
operator: , [1095,1096]
===
match
---
name: task [44616,44620]
name: task [44568,44572]
===
match
---
trailer [21483,21498]
trailer [21459,21474]
===
match
---
simple_stmt [67323,67390]
simple_stmt [67275,67342]
===
match
---
decorated [29156,29396]
decorated [29108,29348]
===
match
---
operator: @ [90576,90577]
operator: @ [90528,90529]
===
match
---
trailer [91231,91315]
trailer [91183,91267]
===
match
---
trailer [35108,35137]
trailer [35060,35089]
===
match
---
name: desc [3636,3640]
name: desc [3636,3640]
===
match
---
name: session [38240,38247]
name: session [38192,38199]
===
match
---
expr_stmt [75954,76000]
expr_stmt [75906,75952]
===
match
---
comparison [23380,23413]
comparison [23332,23365]
===
match
---
name: date_last_automated_dagrun [25818,25844]
name: date_last_automated_dagrun [25770,25796]
===
match
---
return_stmt [29035,29046]
return_stmt [28987,28998]
===
match
---
name: only_running [52954,52966]
name: only_running [52906,52918]
===
match
---
trailer [65900,65902]
trailer [65852,65854]
===
match
---
trailer [31925,31930]
trailer [31877,31882]
===
match
---
atom_expr [76327,76341]
atom_expr [76279,76293]
===
match
---
suite [64769,65057]
suite [64721,65009]
===
match
---
simple_stmt [74186,74320]
simple_stmt [74138,74272]
===
match
---
operator: ** [95719,95721]
operator: ** [95671,95673]
===
match
---
name: DagRun [38847,38853]
name: DagRun [38799,38805]
===
match
---
string: 'core' [10848,10854]
string: 'core' [10848,10854]
===
match
---
decorated [30570,30678]
decorated [30522,30630]
===
match
---
trailer [21510,21539]
trailer [21486,21515]
===
match
---
operator: , [29457,29458]
operator: , [29409,29410]
===
match
---
atom_expr [55703,55714]
atom_expr [55655,55666]
===
match
---
suite [21455,21541]
suite [21431,21517]
===
match
---
atom_expr [62354,62364]
atom_expr [62306,62316]
===
match
---
name: list [31714,31718]
name: list [31666,31670]
===
match
---
name: dag_tag_orm [79435,79446]
name: dag_tag_orm [79387,79398]
===
match
---
name: using_start_date [28192,28208]
name: using_start_date [28144,28160]
===
match
---
simple_stmt [85847,85897]
simple_stmt [85799,85849]
===
match
---
name: self [29298,29302]
name: self [29250,29254]
===
match
---
name: self [68238,68242]
name: self [68190,68194]
===
match
---
name: tis [51425,51428]
name: tis [51377,51380]
===
match
---
name: description [30926,30937]
name: description [30878,30889]
===
match
---
string: "Dag start date: %s. Next run date: %s" [26776,26815]
string: "Dag start date: %s. Next run date: %s" [26728,26767]
===
match
---
funcdef [29883,29950]
funcdef [29835,29902]
===
match
---
param [89078,89090]
param [89030,89042]
===
match
---
name: run_id [39017,39023]
name: run_id [38969,38975]
===
match
---
operator: , [88035,88036]
operator: , [87987,87988]
===
match
---
name: dag_model [92394,92403]
name: dag_model [92346,92355]
===
match
---
trailer [32208,32216]
trailer [32160,32168]
===
match
---
suite [98553,98594]
suite [98505,98546]
===
match
---
simple_stmt [41062,41096]
simple_stmt [41014,41048]
===
match
---
return_stmt [23588,23607]
return_stmt [23540,23559]
===
match
---
name: start_date [51999,52009]
name: start_date [51951,51961]
===
match
---
simple_stmt [57728,57770]
simple_stmt [57680,57722]
===
match
---
atom_expr [36568,36593]
atom_expr [36520,36545]
===
match
---
atom_expr [68447,68455]
atom_expr [68399,68407]
===
match
---
argument [58754,58789]
argument [58706,58741]
===
match
---
name: sqlalchemy [1520,1530]
name: sqlalchemy [1520,1530]
===
match
---
name: AirflowException [55525,55541]
name: AirflowException [55477,55493]
===
match
---
atom_expr [40209,40402]
atom_expr [40161,40354]
===
match
---
name: signature [95694,95703]
name: signature [95646,95655]
===
match
---
fstring_expr [55702,55715]
fstring_expr [55654,55667]
===
match
---
import_from [2180,2220]
import_from [2180,2220]
===
match
---
simple_stmt [29113,29130]
simple_stmt [29065,29082]
===
match
---
simple_stmt [11781,11828]
simple_stmt [11781,11828]
===
match
---
comparison [16335,16371]
comparison [16335,16371]
===
match
---
trailer [26088,26094]
trailer [26040,26046]
===
match
---
name: dp [66611,66613]
name: dp [66563,66565]
===
match
---
operator: , [60233,60234]
operator: , [60185,60186]
===
match
---
parameters [30809,30822]
parameters [30761,30774]
===
match
---
operator: } [91275,91276]
operator: } [91227,91228]
===
match
---
trailer [73810,73818]
trailer [73762,73770]
===
match
---
suite [18281,19375]
suite [18281,19375]
===
match
---
trailer [20714,20725]
trailer [20714,20725]
===
match
---
name: dags [58149,58153]
name: dags [58101,58105]
===
match
---
name: query [38949,38954]
name: query [38901,38906]
===
match
---
name: memo [60096,60100]
name: memo [60048,60052]
===
match
---
name: utcnow [42985,42991]
name: utcnow [42937,42943]
===
match
---
name: edge [46795,46799]
name: edge [46747,46751]
===
match
---
trailer [41182,41188]
trailer [41134,41140]
===
match
---
name: Column [87197,87203]
name: Column [87149,87155]
===
match
---
trailer [37743,37749]
trailer [37695,37701]
===
match
---
argument [74457,74478]
argument [74409,74430]
===
match
---
name: true [93349,93353]
name: true [93301,93305]
===
match
---
trailer [32838,32862]
trailer [32790,32814]
===
match
---
expr_stmt [15623,15645]
expr_stmt [15623,15645]
===
match
---
trailer [2897,2907]
trailer [2897,2907]
===
match
---
name: bool [90725,90729]
name: bool [90677,90681]
===
match
---
operator: } [62081,62082]
operator: } [62033,62034]
===
match
---
operator: = [51129,51130]
operator: = [51081,51082]
===
match
---
name: NUM_DAGS_PER_DAGRUN_QUERY [93506,93531]
name: NUM_DAGS_PER_DAGRUN_QUERY [93458,93483]
===
match
---
atom_expr [41865,41894]
atom_expr [41817,41846]
===
match
---
name: catchup [15638,15645]
name: catchup [15638,15645]
===
match
---
name: run_dates [28664,28673]
name: run_dates [28616,28625]
===
match
---
operator: @ [48224,48225]
operator: @ [48176,48177]
===
match
---
trailer [44362,44371]
trailer [44314,44323]
===
match
---
trailer [66312,66318]
trailer [66264,66270]
===
match
---
name: dag_tag [79331,79338]
name: dag_tag [79283,79290]
===
match
---
name: self [42858,42862]
name: self [42810,42814]
===
match
---
name: confirm_prompt [56264,56278]
name: confirm_prompt [56216,56230]
===
match
---
operator: , [76273,76274]
operator: , [76225,76226]
===
match
---
name: fallback [88135,88143]
name: fallback [88087,88095]
===
match
---
suite [26296,26431]
suite [26248,26383]
===
match
---
suite [85684,94745]
suite [85636,94697]
===
match
---
simple_stmt [35404,35448]
simple_stmt [35356,35400]
===
match
---
name: filter [82723,82729]
name: filter [82675,82681]
===
match
---
trailer [76038,76040]
trailer [75990,75992]
===
match
---
name: extend [47177,47183]
name: extend [47129,47135]
===
match
---
simple_stmt [3424,3478]
simple_stmt [3424,3478]
===
match
---
name: run_id [39007,39013]
name: run_id [38959,38965]
===
match
---
name: ORIENTATION_PRESETS [15556,15575]
name: ORIENTATION_PRESETS [15556,15575]
===
match
---
name: start_date [26736,26746]
name: start_date [26688,26698]
===
match
---
atom_expr [63273,63294]
atom_expr [63225,63246]
===
match
---
simple_stmt [16090,16146]
simple_stmt [16090,16146]
===
match
---
parameters [85628,85634]
parameters [85580,85586]
===
match
---
for_stmt [91934,92472]
for_stmt [91886,92424]
===
match
---
trailer [33306,33313]
trailer [33258,33265]
===
match
---
name: self [17372,17376]
name: self [17372,17376]
===
match
---
argument [74649,74680]
argument [74601,74632]
===
match
---
operator: } [63376,63377]
operator: } [63328,63329]
===
match
---
name: filter [51510,51516]
name: filter [51462,51468]
===
match
---
decorated [89337,89577]
decorated [89289,89529]
===
match
---
name: min [43101,43104]
name: min [43053,43056]
===
match
---
operator: , [14533,14534]
operator: , [14533,14534]
===
match
---
if_stmt [18580,18627]
if_stmt [18580,18627]
===
match
---
name: all [77364,77367]
name: all [77316,77319]
===
match
---
name: count [59234,59239]
name: count [59186,59191]
===
match
---
expr_stmt [60096,60119]
expr_stmt [60048,60071]
===
match
---
name: __init__ [88157,88165]
name: __init__ [88109,88117]
===
match
---
trailer [75127,75306]
trailer [75079,75258]
===
match
---
name: _schedule_interval [35352,35370]
name: _schedule_interval [35304,35322]
===
match
---
trailer [44313,44344]
trailer [44265,44296]
===
match
---
operator: = [51490,51491]
operator: = [51442,51443]
===
match
---
name: limit [93496,93501]
name: limit [93448,93453]
===
match
---
name: start_date [26553,26563]
name: start_date [26505,26515]
===
match
---
tfpdef [30421,30431]
tfpdef [30373,30383]
===
match
---
trailer [66367,66373]
trailer [66319,66325]
===
match
---
name: true [37995,37999]
name: true [37947,37951]
===
match
---
atom_expr [79120,79132]
atom_expr [79072,79084]
===
match
---
operator: = [47834,47835]
operator: = [47786,47787]
===
match
---
name: is_active [81080,81089]
name: is_active [81032,81041]
===
match
---
trailer [74341,74691]
trailer [74293,74643]
===
match
---
suite [27532,28789]
suite [27484,28741]
===
match
---
atom [84982,84984]
atom [84934,84936]
===
match
---
name: id [62964,62966]
name: id [62916,62918]
===
match
---
trailer [64621,64631]
trailer [64573,64583]
===
match
---
name: cron_presets [2368,2380]
name: cron_presets [2368,2380]
===
match
---
if_stmt [22172,22611]
if_stmt [22148,22563]
===
match
---
decorated [72069,74929]
decorated [72021,74881]
===
match
---
name: factory [95367,95374]
name: factory [95319,95326]
===
match
---
name: List [19542,19546]
name: List [19542,19546]
===
match
---
string: "@once" [23406,23413]
string: "@once" [23358,23365]
===
match
---
trailer [47116,47138]
trailer [47068,47090]
===
match
---
name: run_type [77183,77191]
name: run_type [77135,77143]
===
match
---
operator: -> [41261,41263]
operator: -> [41213,41215]
===
match
---
name: session [29203,29210]
name: session [29155,29162]
===
match
---
name: __init__ [88217,88225]
name: __init__ [88169,88177]
===
match
---
name: self [12734,12738]
name: self [12734,12738]
===
match
---
param [22858,22914]
param [22810,22866]
===
match
---
dotted_name [2341,2360]
dotted_name [2341,2360]
===
match
---
suite [80021,80284]
suite [79973,80236]
===
match
---
name: ALLOW_FUTURE_EXEC_DATES [32839,32862]
name: ALLOW_FUTURE_EXEC_DATES [32791,32814]
===
match
---
name: qry [82823,82826]
name: qry [82775,82778]
===
match
---
expr_stmt [25534,25580]
expr_stmt [25486,25532]
===
match
---
trailer [58491,58879]
trailer [58443,58831]
===
match
---
string: 'DAG.tasks can not be modified. Use dag.add_task() instead.' [31818,31878]
string: 'DAG.tasks can not be modified. Use dag.add_task() instead.' [31770,31830]
===
match
---
atom_expr [51587,51600]
atom_expr [51539,51552]
===
match
---
atom_expr [33714,33744]
atom_expr [33666,33696]
===
match
---
name: run_backwards [69325,69338]
name: run_backwards [69277,69290]
===
match
---
operator: , [10661,10662]
operator: , [10661,10662]
===
match
---
atom_expr [32262,32309]
atom_expr [32214,32261]
===
match
---
atom_expr [66765,66801]
atom_expr [66717,66753]
===
match
---
expr_stmt [13857,13996]
expr_stmt [13857,13996]
===
match
---
name: query [89284,89289]
name: query [89236,89241]
===
match
---
suite [45733,45773]
suite [45685,45725]
===
match
---
expr_stmt [37703,37863]
expr_stmt [37655,37815]
===
match
---
name: schedule_interval [32872,32889]
name: schedule_interval [32824,32841]
===
match
---
trailer [79480,79487]
trailer [79432,79439]
===
match
---
operator: , [13046,13047]
operator: , [13046,13047]
===
match
---
name: property [31001,31009]
name: property [30953,30961]
===
match
---
name: BaseOperator [13048,13060]
name: BaseOperator [13048,13060]
===
match
---
name: conf [71699,71703]
name: conf [71651,71655]
===
match
---
name: convert_to_utc [14033,14047]
name: convert_to_utc [14033,14047]
===
match
---
operator: } [15575,15576]
operator: } [15575,15576]
===
match
---
name: normalized_schedule_interval [21758,21786]
name: normalized_schedule_interval [21734,21762]
===
match
---
name: minute [20164,20170]
name: minute [20164,20170]
===
match
---
trailer [16550,16566]
trailer [16550,16566]
===
match
---
name: query [3424,3429]
name: query [3424,3429]
===
match
---
string: 'has_on_failure_callback' [84473,84498]
string: 'has_on_failure_callback' [84425,84450]
===
match
---
comparison [52907,52940]
comparison [52859,52892]
===
match
---
name: self [16900,16904]
name: self [16900,16904]
===
match
---
name: node [47184,47188]
name: node [47136,47140]
===
match
---
simple_stmt [82817,82901]
simple_stmt [82769,82853]
===
match
---
funcdef [24015,27476]
funcdef [23967,27428]
===
match
---
operator: = [28498,28499]
operator: = [28450,28451]
===
match
---
string: 'TB' [3073,3077]
string: 'TB' [3073,3077]
===
match
---
fstring_start: f' [15196,15198]
fstring_start: f' [15196,15198]
===
match
---
name: subdag_lst [41111,41121]
name: subdag_lst [41063,41073]
===
match
---
name: t [57528,57529]
name: t [57480,57481]
===
match
---
operator: = [71598,71599]
operator: = [71550,71551]
===
match
---
operator: , [22605,22606]
operator: , [22557,22558]
===
match
---
atom_expr [41961,41999]
atom_expr [41913,41951]
===
match
---
operator: == [59028,59030]
operator: == [58980,58982]
===
match
---
name: Optional [47598,47606]
name: Optional [47550,47558]
===
match
---
atom_expr [77923,77931]
atom_expr [77875,77883]
===
match
---
trailer [68096,68105]
trailer [68048,68057]
===
match
---
atom_expr [96622,96648]
atom_expr [96574,96600]
===
match
---
tfpdef [47508,47524]
tfpdef [47460,47476]
===
match
---
operator: -> [30519,30521]
operator: -> [30471,30473]
===
match
---
dictorsetmaker [83707,84499]
dictorsetmaker [83659,84451]
===
match
---
trailer [52909,52915]
trailer [52861,52867]
===
match
---
comp_op [68197,68203]
comp_op [68149,68155]
===
match
---
atom_expr [39946,40038]
atom_expr [39898,39990]
===
match
---
name: exceptions [1710,1720]
name: exceptions [1710,1720]
===
match
---
suite [29022,29047]
suite [28974,28999]
===
match
---
name: ExternalTaskMarker [53382,53400]
name: ExternalTaskMarker [53334,53352]
===
match
---
arglist [25425,25458]
arglist [25377,25410]
===
match
---
trailer [15831,15851]
trailer [15831,15851]
===
match
---
operator: = [58556,58557]
operator: = [58508,58509]
===
match
---
name: croniter [20008,20016]
name: croniter [20008,20016]
===
match
---
atom_expr [22366,22379]
atom_expr [22342,22355]
===
match
---
name: using_end_date [28258,28272]
name: using_end_date [28210,28224]
===
match
---
name: used_group_ids [68255,68269]
name: used_group_ids [68207,68221]
===
match
---
atom_expr [27245,27255]
atom_expr [27197,27207]
===
match
---
atom_expr [13363,13394]
atom_expr [13363,13394]
===
match
---
name: include_upstream [55751,55767]
name: include_upstream [55703,55719]
===
match
---
atom_expr [79061,79079]
atom_expr [79013,79031]
===
match
---
name: ignore_first_depends_on_past [71552,71580]
name: ignore_first_depends_on_past [71504,71532]
===
match
---
name: alive_dag_filelocs [92083,92101]
name: alive_dag_filelocs [92035,92053]
===
match
---
atom_expr [71258,71811]
atom_expr [71210,71763]
===
match
---
atom_expr [71960,71998]
atom_expr [71912,71950]
===
match
---
atom_expr [36558,36565]
atom_expr [36510,36517]
===
match
---
name: confirm_prompt [59611,59625]
name: confirm_prompt [59563,59577]
===
match
---
operator: = [38186,38187]
operator: = [38138,38139]
===
match
---
name: self [31151,31155]
name: self [31103,31107]
===
match
---
operator: = [52864,52865]
operator: = [52816,52817]
===
match
---
suite [63647,63717]
suite [63599,63669]
===
match
---
name: relativedelta [2950,2963]
name: relativedelta [2950,2963]
===
match
---
atom_expr [92345,92364]
atom_expr [92297,92316]
===
match
---
atom_expr [95941,95951]
atom_expr [95893,95903]
===
match
---
name: task_dict [63525,63534]
name: task_dict [63477,63486]
===
match
---
atom_expr [59406,59787]
atom_expr [59358,59739]
===
match
---
trailer [37749,37751]
trailer [37701,37703]
===
match
---
operator: -> [65320,65322]
operator: -> [65272,65274]
===
match
---
trailer [43163,43348]
trailer [43115,43300]
===
match
---
name: num [19569,19572]
name: num [19569,19572]
===
match
---
atom_expr [34638,34658]
atom_expr [34590,34610]
===
match
---
decorator [90669,90686]
decorator [90621,90638]
===
match
---
trailer [51720,51735]
trailer [51672,51687]
===
match
---
name: relationship [87466,87478]
name: relationship [87418,87430]
===
match
---
operator: , [2948,2949]
operator: , [2948,2949]
===
match
---
string: "@once" [23805,23812]
string: "@once" [23757,23764]
===
match
---
name: session [89276,89283]
name: session [89228,89235]
===
match
---
name: func [77543,77547]
name: func [77495,77499]
===
match
---
trailer [37815,37822]
trailer [37767,37774]
===
match
---
name: DAG [98232,98235]
name: DAG [98184,98187]
===
match
---
name: DAG [96077,96080]
name: DAG [96029,96032]
===
match
---
expr_stmt [15827,15873]
expr_stmt [15827,15873]
===
match
---
operator: , [90651,90652]
operator: , [90603,90604]
===
match
---
name: fileloc [79673,79680]
name: fileloc [79625,79632]
===
match
---
suite [35339,35378]
suite [35291,35330]
===
match
---
decorated [80554,81154]
decorated [80506,81106]
===
match
---
operator: = [74508,74509]
operator: = [74460,74461]
===
match
---
name: missing_dag_id [76516,76530]
name: missing_dag_id [76468,76482]
===
match
---
operator: = [66446,66447]
operator: = [66398,66399]
===
match
---
trailer [41487,41507]
trailer [41439,41459]
===
match
---
decorated [95335,97029]
decorated [95287,96981]
===
match
---
name: env [42429,42432]
name: env [42381,42384]
===
match
---
atom_expr [58892,58911]
atom_expr [58844,58863]
===
match
---
operator: = [88643,88644]
operator: = [88595,88596]
===
match
---
trailer [28747,28762]
trailer [28699,28714]
===
match
---
testlist_star_expr [94110,94157]
testlist_star_expr [94062,94109]
===
match
---
simple_stmt [86239,86282]
simple_stmt [86191,86234]
===
match
---
argument [52031,52048]
argument [51983,52000]
===
match
---
name: task_ids_or_regex [62162,62179]
name: task_ids_or_regex [62114,62131]
===
match
---
name: super [88209,88214]
name: super [88161,88166]
===
match
---
trailer [62358,62364]
trailer [62310,62316]
===
match
---
name: String [1430,1436]
name: String [1430,1436]
===
match
---
expr_stmt [85732,85753]
expr_stmt [85684,85705]
===
match
---
name: get_is_paused [34050,34063]
name: get_is_paused [34002,34015]
===
match
---
operator: , [23600,23601]
operator: , [23552,23553]
===
match
---
name: state [83246,83251]
name: state [83198,83203]
===
match
---
name: orm_tag [79100,79107]
name: orm_tag [79052,79059]
===
match
---
name: TI [54948,54950]
name: TI [54900,54902]
===
match
---
expr_stmt [14068,14117]
expr_stmt [14068,14117]
===
match
---
trailer [10927,10962]
trailer [10927,10962]
===
match
---
operator: = [57706,57707]
operator: = [57658,57659]
===
match
---
funcdef [29981,30057]
funcdef [29933,30009]
===
match
---
trailer [51641,51651]
trailer [51593,51603]
===
match
---
name: airflow [2185,2192]
name: airflow [2185,2192]
===
match
---
expr_stmt [86239,86281]
expr_stmt [86191,86233]
===
match
---
trailer [16960,16966]
trailer [16960,16966]
===
match
---
suite [68270,68373]
suite [68222,68325]
===
match
---
expr_stmt [83112,83166]
expr_stmt [83064,83118]
===
match
---
name: filter [43957,43963]
name: filter [43909,43915]
===
match
---
name: Collection [1075,1085]
name: Collection [1075,1085]
===
match
---
name: task [68857,68861]
name: task [68809,68813]
===
match
---
name: subdag [40658,40664]
name: subdag [40610,40616]
===
match
---
atom_expr [83233,83272]
atom_expr [83185,83224]
===
match
---
name: fn [32257,32259]
name: fn [32209,32211]
===
match
---
arglist [85863,85895]
arglist [85815,85847]
===
match
---
funcdef [65159,65251]
funcdef [65111,65203]
===
match
---
name: group [64447,64452]
name: group [64399,64404]
===
match
---
name: Session [1550,1557]
name: Session [1550,1557]
===
match
---
name: self [51530,51534]
name: self [51482,51486]
===
match
---
argument [52070,52093]
argument [52022,52045]
===
match
---
name: dag_ids [47633,47640]
name: dag_ids [47585,47592]
===
match
---
atom_expr [22298,22321]
atom_expr [22274,22297]
===
match
---
operator: , [10502,10503]
operator: , [10502,10503]
===
match
---
simple_stmt [68283,68373]
simple_stmt [68235,68325]
===
match
---
string: 'webserver' [11107,11118]
string: 'webserver' [11107,11118]
===
match
---
trailer [21100,21109]
trailer [21100,21109]
===
match
---
expr_stmt [87251,87277]
expr_stmt [87203,87229]
===
match
---
name: Column [86446,86452]
name: Column [86398,86404]
===
match
---
operator: , [84498,84499]
operator: , [84450,84451]
===
match
---
string: """     Returns the last dag run for a dag, None if there was none.     Last dag run can be any type of run eg. scheduled or backfilled.     Overridden DagRuns are ignored.     """ [3223,3403]
string: """     Returns the last dag run for a dag, None if there was none.     Last dag run can be any type of run eg. scheduled or backfilled.     Overridden DagRuns are ignored.     """ [3223,3403]
===
match
---
name: filter [33193,33199]
name: filter [33145,33151]
===
match
---
argument [86267,86280]
argument [86219,86232]
===
match
---
trailer [16974,16981]
trailer [16974,16981]
===
match
---
atom_expr [63216,63232]
atom_expr [63168,63184]
===
match
---
name: __tablename__ [85732,85745]
name: __tablename__ [85684,85697]
===
match
---
atom_expr [37739,37751]
atom_expr [37691,37703]
===
match
---
parameters [66736,66751]
parameters [66688,66703]
===
match
---
simple_stmt [3595,3644]
simple_stmt [3595,3644]
===
match
---
trailer [65089,65101]
trailer [65041,65053]
===
match
---
param [72117,72122]
param [72069,72074]
===
match
---
expr_stmt [54919,55199]
expr_stmt [54871,55151]
===
match
---
trailer [42357,42377]
trailer [42309,42329]
===
match
---
name: tis [44422,44425]
name: tis [44374,44377]
===
match
---
trailer [61027,61032]
trailer [60979,60984]
===
match
---
name: filter [3541,3547]
name: filter [3541,3547]
===
match
---
name: t [32723,32724]
name: t [32675,32676]
===
match
---
operator: @ [91346,91347]
operator: @ [91298,91299]
===
match
---
arglist [62269,62297]
arglist [62221,62249]
===
match
---
param [33795,33807]
param [33747,33759]
===
match
---
operator: = [93596,93597]
operator: = [93548,93549]
===
match
---
operator: = [96520,96521]
operator: = [96472,96473]
===
match
---
trailer [12508,12682]
trailer [12508,12682]
===
match
---
operator: = [29623,29624]
operator: = [29575,29576]
===
match
---
name: stacklevel [34599,34609]
name: stacklevel [34551,34561]
===
match
---
name: in_ [51583,51586]
name: in_ [51535,51538]
===
match
---
atom_expr [43325,43335]
atom_expr [43277,43287]
===
match
---
operator: = [15669,15670]
operator: = [15669,15670]
===
match
---
atom_expr [34720,34746]
atom_expr [34672,34698]
===
match
---
operator: * [66776,66777]
operator: * [66728,66729]
===
match
---
trailer [31683,31697]
trailer [31635,31649]
===
match
---
trailer [63678,63693]
trailer [63630,63645]
===
match
---
trailer [79161,79168]
trailer [79113,79120]
===
match
---
trailer [18008,18014]
trailer [18008,18014]
===
match
---
expr_stmt [21192,21223]
expr_stmt [21192,21223]
===
match
---
name: self [18030,18034]
name: self [18030,18034]
===
match
---
name: str [38181,38184]
name: str [38133,38136]
===
match
---
name: self [31719,31723]
name: self [31671,31675]
===
match
---
trailer [16643,16668]
trailer [16643,16668]
===
match
---
name: first [39046,39051]
name: first [38998,39003]
===
match
---
simple_stmt [25534,25581]
simple_stmt [25486,25533]
===
match
---
trailer [63923,63932]
trailer [63875,63884]
===
match
---
atom_expr [67525,67540]
atom_expr [67477,67492]
===
match
---
name: dag_id [17332,17338]
name: dag_id [17332,17338]
===
match
---
decorated [29401,29701]
decorated [29353,29653]
===
match
---
trailer [2887,2897]
trailer [2887,2897]
===
match
---
string: "dag" [85748,85753]
string: "dag" [85700,85705]
===
match
---
expr_stmt [14895,14933]
expr_stmt [14895,14933]
===
match
---
trailer [33919,33925]
trailer [33871,33877]
===
match
---
operator: } [12036,12037]
operator: } [12036,12037]
===
match
---
trailer [66373,66375]
trailer [66325,66327]
===
match
---
name: schedule_interval [78634,78651]
name: schedule_interval [78586,78603]
===
match
---
param [72485,72523]
param [72437,72475]
===
match
---
suite [52967,53024]
suite [52919,52976]
===
match
---
operator: , [58789,58790]
operator: , [58741,58742]
===
match
---
operator: , [11764,11765]
operator: , [11764,11765]
===
match
---
name: kwargs [95384,95390]
name: kwargs [95336,95342]
===
match
---
argument [74387,74400]
argument [74339,74352]
===
match
---
name: utcnow [14820,14826]
name: utcnow [14820,14826]
===
match
---
name: donot_pickle [69060,69072]
name: donot_pickle [69012,69024]
===
match
---
name: default [31624,31631]
name: default [31576,31583]
===
match
---
fstring_start: f" [74016,74018]
fstring_start: f" [73968,73970]
===
match
---
atom_expr [45578,45590]
atom_expr [45530,45542]
===
match
---
name: get [95927,95930]
name: get [95879,95882]
===
match
---
atom_expr [38765,38786]
atom_expr [38717,38738]
===
match
---
atom_expr [76739,76786]
atom_expr [76691,76738]
===
match
---
name: default_view [15041,15053]
name: default_view [15041,15053]
===
match
---
trailer [62546,62562]
trailer [62498,62514]
===
match
---
name: self [14353,14357]
name: self [14353,14357]
===
match
---
trailer [39006,39013]
trailer [38958,38965]
===
match
---
operator: + [21504,21505]
operator: + [21480,21481]
===
match
---
atom_expr [65856,65878]
atom_expr [65808,65830]
===
match
---
operator: , [81696,81697]
operator: , [81648,81649]
===
match
---
atom_expr [25296,25324]
atom_expr [25248,25276]
===
match
---
name: State [2739,2744]
name: State [2739,2744]
===
match
---
operator: , [19438,19439]
operator: , [19438,19439]
===
match
---
return_stmt [65201,65250]
return_stmt [65153,65202]
===
match
---
operator: , [84154,84155]
operator: , [84106,84107]
===
match
---
name: os [839,841]
name: os [839,841]
===
match
---
suite [27417,27446]
suite [27369,27398]
===
match
---
parameters [29730,29736]
parameters [29682,29688]
===
match
---
operator: , [55172,55173]
operator: , [55124,55125]
===
match
---
trailer [98437,98458]
trailer [98389,98410]
===
match
---
arglist [79003,79016]
arglist [78955,78968]
===
match
---
expr_stmt [52693,52742]
expr_stmt [52645,52694]
===
match
---
fstring_start: f" [47309,47311]
fstring_start: f" [47261,47263]
===
match
---
trailer [67482,67493]
trailer [67434,67445]
===
match
---
arglist [71283,71801]
arglist [71235,71753]
===
match
---
atom_expr [26707,26747]
atom_expr [26659,26699]
===
match
---
expr_stmt [66572,66594]
expr_stmt [66524,66546]
===
match
---
suite [30433,30473]
suite [30385,30425]
===
match
---
trailer [36639,36656]
trailer [36591,36608]
===
match
---
name: bool [65306,65310]
name: bool [65258,65262]
===
match
---
expr_stmt [87459,87541]
expr_stmt [87411,87493]
===
match
---
name: datetime [47562,47570]
name: datetime [47514,47522]
===
match
---
operator: , [87994,87995]
operator: , [87946,87947]
===
match
---
atom_expr [75114,75306]
atom_expr [75066,75258]
===
match
---
name: subdag_lst [40696,40706]
name: subdag_lst [40648,40658]
===
match
---
operator: = [52176,52177]
operator: = [52128,52129]
===
match
---
trailer [93324,93334]
trailer [93276,93286]
===
match
---
name: self [14987,14991]
name: self [14987,14991]
===
match
---
name: default_view [87329,87341]
name: default_view [87281,87293]
===
match
---
trailer [33999,34019]
trailer [33951,33971]
===
match
---
comp_op [16360,16366]
comp_op [16360,16366]
===
match
---
trailer [90093,90095]
trailer [90045,90047]
===
match
---
trailer [74065,74075]
trailer [74017,74027]
===
match
---
simple_stmt [36497,36546]
simple_stmt [36449,36498]
===
match
---
name: is_paused_upon_creation [76673,76696]
name: is_paused_upon_creation [76625,76648]
===
match
---
name: DagBag [1913,1919]
name: DagBag [1913,1919]
===
match
---
trailer [53084,53088]
trailer [53036,53040]
===
match
---
simple_stmt [37389,37661]
simple_stmt [37341,37613]
===
match
---
name: State [52893,52898]
name: State [52845,52850]
===
match
---
name: expression [37984,37994]
name: expression [37936,37946]
===
match
---
expr_stmt [57550,57715]
expr_stmt [57502,57667]
===
match
---
name: self [40482,40486]
name: self [40434,40438]
===
match
---
trailer [59051,59072]
trailer [59003,59024]
===
match
---
param [31112,31116]
param [31064,31068]
===
match
---
trailer [14408,14439]
trailer [14408,14439]
===
match
---
operator: , [60499,60500]
operator: , [60451,60452]
===
match
---
name: subdags [65474,65481]
name: subdags [65426,65433]
===
match
---
name: self [12301,12305]
name: self [12301,12305]
===
match
---
atom_expr [64652,64677]
atom_expr [64604,64629]
===
match
---
atom_expr [85651,85660]
atom_expr [85603,85612]
===
match
---
atom [41406,41419]
atom [41358,41371]
===
match
---
name: DuplicateTaskIdFound [1746,1766]
name: DuplicateTaskIdFound [1746,1766]
===
match
---
name: String [85863,85869]
name: String [85815,85821]
===
match
---
arith_expr [21499,21539]
arith_expr [21475,21515]
===
match
---
argument [86370,86383]
argument [86322,86335]
===
match
---
funcdef [3145,3669]
funcdef [3145,3669]
===
match
---
name: Index [1414,1419]
name: Index [1414,1419]
===
match
---
name: now [93410,93413]
name: now [93362,93365]
===
match
---
name: utils [2314,2319]
name: utils [2314,2319]
===
match
---
suite [21136,21342]
suite [21136,21318]
===
match
---
operator: = [10520,10521]
operator: = [10520,10521]
===
match
---
funcdef [88153,88873]
funcdef [88105,88825]
===
match
---
operator: , [20515,20516]
operator: , [20515,20516]
===
match
---
suite [14340,14440]
suite [14340,14440]
===
match
---
name: start_date [28218,28228]
name: start_date [28170,28180]
===
match
---
trailer [17571,17594]
trailer [17571,17594]
===
match
---
operator: = [65740,65741]
operator: = [65692,65693]
===
match
---
expr_stmt [26171,26238]
expr_stmt [26123,26190]
===
match
---
trailer [47044,47051]
trailer [46996,47003]
===
match
---
operator: , [60243,60244]
operator: , [60195,60196]
===
match
---
name: updated_access_control [18935,18957]
name: updated_access_control [18935,18957]
===
match
---
name: UtcDateTime [86529,86540]
name: UtcDateTime [86481,86492]
===
match
---
trailer [93619,93636]
trailer [93571,93588]
===
match
---
atom_expr [13725,13742]
atom_expr [13725,13742]
===
match
---
operator: , [41700,41701]
operator: , [41652,41653]
===
match
---
suite [67128,68660]
suite [67080,68612]
===
match
---
name: log [2531,2534]
name: log [2531,2534]
===
match
---
trailer [88225,88235]
trailer [88177,88187]
===
match
---
comparison [55051,55086]
comparison [55003,55038]
===
match
---
name: on_success_callback [15777,15796]
name: on_success_callback [15777,15796]
===
match
---
name: naive [21045,21050]
name: naive [21045,21050]
===
match
---
dotted_name [2830,2854]
dotted_name [2830,2854]
===
match
---
name: property [40457,40465]
name: property [40409,40417]
===
match
---
operator: = [30465,30466]
operator: = [30417,30418]
===
match
---
name: orm [1470,1473]
name: orm [1470,1473]
===
match
---
operator: , [57938,57939]
operator: , [57890,57891]
===
match
---
name: int [30428,30431]
name: int [30380,30383]
===
match
---
dictorsetmaker [32723,32750]
dictorsetmaker [32675,32702]
===
match
---
tfpdef [10418,10446]
tfpdef [10418,10446]
===
match
---
not_test [12419,12439]
not_test [12419,12439]
===
match
---
trailer [47561,47571]
trailer [47513,47523]
===
match
---
atom_expr [76799,76819]
atom_expr [76751,76771]
===
match
---
name: warnings [12495,12503]
name: warnings [12495,12503]
===
match
---
name: Optional [72502,72510]
name: Optional [72454,72462]
===
match
---
return_stmt [18023,18034]
return_stmt [18023,18034]
===
match
---
atom_expr [63958,63989]
atom_expr [63910,63941]
===
match
---
tfpdef [11732,11757]
tfpdef [11732,11757]
===
match
---
name: OrderedDict [45565,45576]
name: OrderedDict [45517,45528]
===
match
---
simple_stmt [76307,76367]
simple_stmt [76259,76319]
===
match
---
suite [15078,15130]
suite [15078,15130]
===
match
---
name: self [47458,47462]
name: self [47410,47414]
===
match
---
or_test [90500,90570]
or_test [90452,90522]
===
match
---
name: next_run_date [26944,26957]
name: next_run_date [26896,26909]
===
match
---
atom_expr [31952,31973]
atom_expr [31904,31925]
===
match
---
tfpdef [19448,19466]
tfpdef [19448,19466]
===
match
---
name: utcnow [65894,65900]
name: utcnow [65846,65852]
===
match
---
arglist [14871,14885]
arglist [14871,14885]
===
match
---
name: dag [79238,79241]
name: dag [79190,79193]
===
match
---
operator: } [41784,41785]
operator: } [41736,41737]
===
match
---
name: dag [94513,94516]
name: dag [94465,94468]
===
match
---
name: max_ [77032,77036]
name: max_ [76984,76988]
===
match
---
suite [67310,67390]
suite [67262,67342]
===
match
---
name: tis [43717,43720]
name: tis [43669,43672]
===
match
---
string: 'timezone' [13542,13552]
string: 'timezone' [13542,13552]
===
match
---
operator: , [84270,84271]
operator: , [84222,84223]
===
match
---
expr_stmt [82817,82900]
expr_stmt [82769,82852]
===
match
---
name: findall [62261,62268]
name: findall [62213,62220]
===
match
---
name: node [46685,46689]
name: node [46637,46641]
===
match
---
name: Column [87411,87417]
name: Column [87363,87369]
===
match
---
atom_expr [66884,66908]
atom_expr [66836,66860]
===
match
---
suite [23813,23926]
suite [23765,23878]
===
match
---
simple_stmt [80325,80391]
simple_stmt [80277,80343]
===
match
---
operator: , [63799,63800]
operator: , [63751,63752]
===
match
---
operator: = [35371,35372]
operator: = [35323,35324]
===
match
---
name: instances [53293,53302]
name: instances [53245,53254]
===
match
---
name: _previous_context_managed_dags [98371,98401]
name: _previous_context_managed_dags [98323,98353]
===
match
---
name: String [87133,87139]
name: String [87085,87091]
===
match
---
string: """         Calculate ``next_dagrun`` and `next_dagrun_create_after``          :param dag: The DAG object         :param most_recent_dag_run: DateTime of most recent run of this dag, or none if not yet scheduled.         :param active_runs_of_dag: Number of currently active runs of this dag         """ [93798,94101]
string: """         Calculate ``next_dagrun`` and `next_dagrun_create_after``          :param dag: The DAG object         :param most_recent_dag_run: DateTime of most recent run of this dag, or none if not yet scheduled.         :param active_runs_of_dag: Number of currently active runs of this dag         """ [93750,94053]
===
match
---
name: executor [71195,71203]
name: executor [71147,71155]
===
match
---
trailer [34241,34248]
trailer [34193,34200]
===
match
---
name: tz [22510,22512]
name: tz [22486,22488]
===
match
---
atom_expr [64908,64962]
atom_expr [64860,64914]
===
match
---
name: query [48007,48012]
name: query [47959,47964]
===
match
---
name: TaskNotFound [1768,1780]
name: TaskNotFound [1768,1780]
===
match
---
operator: , [27515,27516]
operator: , [27467,27468]
===
match
---
expr_stmt [90115,90184]
expr_stmt [90067,90136]
===
match
---
suite [30105,30370]
suite [30057,30322]
===
match
---
trailer [48770,48774]
trailer [48722,48726]
===
match
---
operator: , [52048,52049]
operator: , [52000,52001]
===
match
---
funcdef [34046,34295]
funcdef [33998,34247]
===
match
---
name: UtcDateTime [86689,86700]
name: UtcDateTime [86641,86652]
===
match
---
trailer [52898,52905]
trailer [52850,52857]
===
match
---
name: only_failed [58595,58606]
name: only_failed [58547,58558]
===
match
---
name: state [43915,43920]
name: state [43867,43872]
===
match
---
name: render_template_as_native_obj [16709,16738]
name: render_template_as_native_obj [16709,16738]
===
match
---
arglist [30179,30321]
arglist [30131,30273]
===
match
---
name: start_date [25651,25661]
name: start_date [25603,25613]
===
match
---
simple_stmt [98246,98281]
simple_stmt [98198,98233]
===
match
---
trailer [34642,34656]
trailer [34594,34608]
===
match
---
decorated [31749,31880]
decorated [31701,31832]
===
match
---
return_stmt [22736,22808]
return_stmt [22688,22760]
===
match
---
name: delta [22383,22388]
name: delta [22359,22364]
===
match
---
name: paused_dag_id [90151,90164]
name: paused_dag_id [90103,90116]
===
match
---
operator: = [58403,58404]
operator: = [58355,58356]
===
match
---
trailer [76022,76041]
trailer [75974,75993]
===
match
---
name: BaseOperator [44706,44718]
name: BaseOperator [44658,44670]
===
match
---
trailer [3550,3567]
trailer [3550,3567]
===
match
---
operator: = [19607,19608]
operator: = [19607,19608]
===
match
---
string: """         Deactivate any DAGs that were last touched by the scheduler before         the expiration date. These DAGs were likely deleted.          :param expiration_date: set inactive DAGs that were touched before this             time         :type expiration_date: datetime         :return: None         """ [81264,81575]
string: """         Deactivate any DAGs that were last touched by the scheduler before         the expiration date. These DAGs were likely deleted.          :param expiration_date: set inactive DAGs that were touched before this             time         :type expiration_date: datetime         :return: None         """ [81216,81527]
===
match
---
name: log [76739,76742]
name: log [76691,76694]
===
match
---
param [65655,65659]
param [65607,65611]
===
match
---
operator: = [56771,56772]
operator: = [56723,56724]
===
match
---
string: 'loader' [41605,41613]
string: 'loader' [41557,41565]
===
match
---
operator: } [55714,55715]
operator: } [55666,55667]
===
match
---
atom [14575,14596]
atom [14575,14596]
===
match
---
name: dagrun_timeout [14964,14978]
name: dagrun_timeout [14964,14978]
===
match
---
simple_stmt [1879,1920]
simple_stmt [1879,1920]
===
match
---
param [40084,40088]
param [40036,40040]
===
match
---
name: f [95941,95942]
name: f [95893,95894]
===
match
---
parameters [95374,95391]
parameters [95326,95343]
===
match
---
name: property [32069,32077]
name: property [32021,32029]
===
match
---
trailer [32473,32493]
trailer [32425,32445]
===
match
---
name: tis [52782,52785]
name: tis [52734,52737]
===
match
---
name: sla_miss_callback [11024,11041]
name: sla_miss_callback [11024,11041]
===
match
---
name: start_date [19418,19428]
name: start_date [19418,19428]
===
match
---
atom_expr [41178,41188]
atom_expr [41130,41140]
===
match
---
trailer [52880,52941]
trailer [52832,52893]
===
match
---
operator: += [41073,41075]
operator: += [41025,41027]
===
match
---
simple_stmt [14068,14118]
simple_stmt [14068,14118]
===
match
---
trailer [39737,39741]
trailer [39689,39693]
===
match
---
atom_expr [53367,53378]
atom_expr [53319,53330]
===
match
---
name: push_context_managed_dag [17984,18008]
name: push_context_managed_dag [17984,18008]
===
match
---
suite [53463,53517]
suite [53415,53469]
===
match
---
string: "The 'DagModel.concurrency' parameter is deprecated. Please use 'max_active_tasks'." [88357,88441]
string: "The 'DagModel.concurrency' parameter is deprecated. Please use 'max_active_tasks'." [88309,88393]
===
match
---
name: count [57980,57985]
name: count [57932,57937]
===
match
---
trailer [66770,66801]
trailer [66722,66753]
===
match
---
expr_stmt [12695,12725]
expr_stmt [12695,12725]
===
match
---
atom_expr [96228,96237]
atom_expr [96180,96189]
===
match
---
operator: { [18869,18870]
operator: { [18869,18870]
===
match
---
suite [45852,47364]
suite [45804,47316]
===
match
---
name: stacklevel [75283,75293]
name: stacklevel [75235,75245]
===
match
---
trailer [41978,41999]
trailer [41930,41951]
===
match
---
parameters [17297,17310]
parameters [17297,17310]
===
match
---
simple_stmt [44109,44255]
simple_stmt [44061,44207]
===
match
---
name: t [64975,64976]
name: t [64927,64928]
===
match
---
comp_op [60180,60186]
comp_op [60132,60138]
===
match
---
name: matched_tasks [62326,62339]
name: matched_tasks [62278,62291]
===
match
---
simple_stmt [81264,81576]
simple_stmt [81216,81528]
===
match
---
trailer [28553,28563]
trailer [28505,28515]
===
match
---
name: STATICA_HACK [97146,97158]
name: STATICA_HACK [97098,97110]
===
match
---
name: pickle_id [31198,31207]
name: pickle_id [31150,31159]
===
match
---
argument [34599,34611]
argument [34551,34563]
===
match
---
suite [89434,89577]
suite [89386,89529]
===
match
---
name: get_default_view [80293,80309]
name: get_default_view [80245,80261]
===
match
---
trailer [77553,77558]
trailer [77505,77510]
===
match
---
name: start_date [58163,58173]
name: start_date [58115,58125]
===
match
---
operator: = [15852,15853]
operator: = [15852,15853]
===
match
---
name: utcnow [65751,65757]
name: utcnow [65703,65709]
===
match
---
suite [65445,65578]
suite [65397,65530]
===
match
---
name: Optional [38172,38180]
name: Optional [38124,38132]
===
match
---
name: AirflowException [15162,15178]
name: AirflowException [15162,15178]
===
match
---
funcdef [89053,89174]
funcdef [89005,89126]
===
match
---
trailer [26735,26746]
trailer [26687,26698]
===
match
---
trailer [20774,20816]
trailer [20774,20816]
===
match
---
atom_expr [81698,81716]
atom_expr [81650,81668]
===
match
---
operator: = [59668,59669]
operator: = [59620,59621]
===
match
---
atom_expr [16970,16981]
atom_expr [16970,16981]
===
match
---
argument [71336,71353]
argument [71288,71305]
===
match
---
operator: = [88143,88144]
operator: = [88095,88096]
===
match
---
expr_stmt [12301,12322]
expr_stmt [12301,12322]
===
match
---
operator: = [56331,56332]
operator: = [56283,56284]
===
match
---
operator: == [35328,35330]
operator: == [35280,35282]
===
match
---
operator: , [53877,53878]
operator: , [53829,53830]
===
match
---
atom_expr [25546,25580]
atom_expr [25498,25532]
===
match
---
name: self [32190,32194]
name: self [32142,32146]
===
match
---
name: session [91324,91331]
name: session [91276,91283]
===
match
---
operator: } [90183,90184]
operator: } [90135,90136]
===
match
---
name: sla_miss_callback [14992,15009]
name: sla_miss_callback [14992,15009]
===
match
---
trailer [64560,64578]
trailer [64512,64530]
===
match
---
name: task_start_dates [26045,26061]
name: task_start_dates [25997,26013]
===
match
---
funcdef [30599,30678]
funcdef [30551,30630]
===
match
---
operator: = [20072,20073]
operator: = [20072,20073]
===
match
---
name: ti [54774,54776]
name: ti [54726,54728]
===
match
---
name: self [60104,60108]
name: self [60056,60060]
===
match
---
atom_expr [51561,51602]
atom_expr [51513,51554]
===
match
---
name: timezone [21268,21276]
name: timezone [21250,21258]
===
match
---
atom_expr [62055,62075]
atom_expr [62007,62027]
===
match
---
trailer [13969,13978]
trailer [13969,13978]
===
match
---
trailer [76742,76747]
trailer [76694,76699]
===
match
---
name: Optional [14730,14738]
name: Optional [14730,14738]
===
match
---
name: dttm [21574,21578]
name: dttm [21550,21554]
===
match
---
operator: , [87487,87488]
operator: , [87439,87440]
===
match
---
trailer [91181,91187]
trailer [91133,91139]
===
match
---
operator: , [2995,2996]
operator: , [2995,2996]
===
match
---
name: start [20174,20179]
name: start [20174,20179]
===
match
---
name: copied [63308,63314]
name: copied [63260,63266]
===
match
---
atom_expr [41677,41700]
atom_expr [41629,41652]
===
match
---
name: bool [29497,29501]
name: bool [29449,29453]
===
match
---
name: String [85500,85506]
name: String [85452,85458]
===
match
---
trailer [66060,66062]
trailer [66012,66014]
===
match
---
return_stmt [47373,47399]
return_stmt [47325,47351]
===
match
---
expr_stmt [38757,38786]
expr_stmt [38709,38738]
===
match
---
name: owner [78247,78252]
name: owner [78199,78204]
===
match
---
string: 'dags_are_paused_at_creation' [86107,86136]
string: 'dags_are_paused_at_creation' [86059,86088]
===
match
---
operator: - [42994,42995]
operator: - [42946,42947]
===
match
---
operator: - [21043,21044]
operator: - [21043,21044]
===
match
---
name: filter [52990,52996]
name: filter [52942,52948]
===
match
---
name: cls [83581,83584]
name: cls [83533,83536]
===
match
---
suite [52680,52743]
suite [52632,52695]
===
match
---
operator: , [71603,71604]
operator: , [71555,71556]
===
match
---
expr_stmt [28708,28762]
expr_stmt [28660,28714]
===
match
---
operator: } [13065,13066]
operator: } [13065,13066]
===
match
---
name: tasks [31664,31669]
name: tasks [31616,31621]
===
match
---
operator: , [29201,29202]
operator: , [29153,29154]
===
match
---
name: str [48511,48514]
name: str [48463,48466]
===
match
---
trailer [52785,52792]
trailer [52737,52744]
===
match
---
operator: = [17564,17565]
operator: = [17564,17565]
===
match
---
testlist_comp [45578,45596]
testlist_comp [45530,45548]
===
match
---
operator: , [40792,40793]
operator: , [40744,40745]
===
match
---
simple_stmt [27023,27035]
simple_stmt [26975,26987]
===
match
---
name: default_args [13313,13325]
name: default_args [13313,13325]
===
match
---
trailer [3587,3589]
trailer [3587,3589]
===
match
---
simple_stmt [22569,22611]
simple_stmt [22521,22563]
===
match
---
simple_stmt [79570,79595]
simple_stmt [79522,79547]
===
match
---
atom_expr [91843,91860]
atom_expr [91795,91812]
===
match
---
name: session [91884,91891]
name: session [91836,91843]
===
match
---
operator: , [75347,75348]
operator: , [75299,75300]
===
match
---
name: end_date [58557,58565]
name: end_date [58509,58517]
===
match
---
atom_expr [89692,89700]
atom_expr [89644,89652]
===
match
---
simple_stmt [70983,71042]
simple_stmt [70935,70994]
===
match
---
simple_stmt [15654,15734]
simple_stmt [15654,15734]
===
match
---
or_test [40777,40983]
or_test [40729,40935]
===
match
---
simple_stmt [57801,57954]
simple_stmt [57753,57906]
===
match
---
name: leaves [44685,44691]
name: leaves [44637,44643]
===
match
---
decorator [30478,30488]
decorator [30430,30440]
===
match
---
comparison [80402,80427]
comparison [80354,80379]
===
match
---
trailer [89942,89948]
trailer [89894,89900]
===
match
---
decorator [91363,91380]
decorator [91315,91332]
===
match
---
name: ti [36497,36499]
name: ti [36449,36451]
===
match
---
atom_expr [84882,84896]
atom_expr [84834,84848]
===
match
---
argument [52431,52462]
argument [52383,52414]
===
match
---
name: dag_id [40007,40013]
name: dag_id [39959,39965]
===
match
---
expr_stmt [66300,66375]
expr_stmt [66252,66327]
===
match
---
name: tis [52986,52989]
name: tis [52938,52941]
===
match
---
atom_expr [36376,36438]
atom_expr [36328,36390]
===
match
---
operator: = [25761,25762]
operator: = [25713,25714]
===
match
---
string: 'end_date' [14427,14437]
string: 'end_date' [14427,14437]
===
match
---
string: 'end_date' [14308,14318]
string: 'end_date' [14308,14318]
===
match
---
name: in_ [51394,51397]
name: in_ [51346,51349]
===
match
---
atom_expr [63702,63715]
atom_expr [63654,63667]
===
match
---
simple_stmt [36801,36866]
simple_stmt [36753,36818]
===
match
---
trailer [39953,39959]
trailer [39905,39911]
===
match
---
expr_stmt [86342,86384]
expr_stmt [86294,86336]
===
match
---
trailer [91846,91860]
trailer [91798,91812]
===
match
---
name: dp [66589,66591]
name: dp [66541,66543]
===
match
---
name: warn [60693,60697]
name: warn [60645,60649]
===
match
---
atom_expr [35098,35137]
atom_expr [35050,35089]
===
match
---
operator: = [74626,74627]
operator: = [74578,74579]
===
match
---
factor [97122,97124]
factor [97074,97076]
===
match
---
fstring_string: <DAG:  [88915,88921]
fstring_string: <DAG:  [88867,88873]
===
match
---
simple_stmt [53537,53561]
simple_stmt [53489,53513]
===
match
---
name: f_kwargs [96605,96613]
name: f_kwargs [96557,96565]
===
match
---
name: isinstance [20471,20481]
name: isinstance [20471,20481]
===
match
---
atom_expr [54988,54997]
atom_expr [54940,54949]
===
match
---
argument [59437,59458]
argument [59389,59410]
===
match
---
name: get_num_active_runs [37317,37336]
name: get_num_active_runs [37269,37288]
===
match
---
atom_expr [65035,65055]
atom_expr [64987,65007]
===
match
---
operator: , [52140,52141]
operator: , [52092,52093]
===
match
---
funcdef [75401,79960]
funcdef [75353,79912]
===
match
---
operator: == [54025,54027]
operator: == [53977,53979]
===
match
---
operator: , [81937,81938]
operator: , [81889,81890]
===
match
---
name: get_next [20123,20131]
name: get_next [20123,20131]
===
match
---
operator: , [72435,72436]
operator: , [72387,72388]
===
match
---
name: is_active [78438,78447]
name: is_active [78390,78399]
===
match
---
argument [74892,74907]
argument [74844,74859]
===
match
---
simple_stmt [95686,95729]
simple_stmt [95638,95681]
===
match
---
argument [57517,57536]
argument [57469,57488]
===
match
---
param [91448,91460]
param [91400,91412]
===
match
---
trailer [92056,92075]
trailer [92008,92027]
===
match
---
name: timezone [20706,20714]
name: timezone [20706,20714]
===
match
---
operator: , [72194,72195]
operator: , [72146,72147]
===
match
---
name: start_date [25602,25612]
name: start_date [25554,25564]
===
match
---
name: self [30513,30517]
name: self [30465,30469]
===
match
---
name: executor [70951,70959]
name: executor [70903,70911]
===
match
---
name: self [41677,41681]
name: self [41629,41633]
===
match
---
name: t [25938,25939]
name: t [25890,25891]
===
match
---
atom_expr [33812,33826]
atom_expr [33764,33778]
===
match
---
name: deepcopy [60294,60302]
name: deepcopy [60246,60254]
===
match
---
operator: ** [60917,60919]
operator: ** [60869,60871]
===
match
---
expr_stmt [78688,78735]
expr_stmt [78640,78687]
===
match
---
raise_stmt [54435,54848]
raise_stmt [54387,54800]
===
match
---
simple_stmt [62722,62754]
simple_stmt [62674,62706]
===
match
---
name: Optional [10338,10346]
name: Optional [10338,10346]
===
match
---
funcdef [72090,74929]
funcdef [72042,74881]
===
match
---
atom_expr [66433,66452]
atom_expr [66385,66404]
===
match
---
trailer [43956,43963]
trailer [43908,43915]
===
match
---
operator: } [15312,15313]
operator: } [15312,15313]
===
match
---
trailer [68451,68455]
trailer [68403,68407]
===
match
---
operator: , [72522,72523]
operator: , [72474,72475]
===
match
---
tfpdef [29814,29824]
tfpdef [29766,29776]
===
match
---
operator: + [32299,32300]
operator: + [32251,32252]
===
match
---
trailer [10701,10707]
trailer [10701,10707]
===
match
---
name: str [35133,35136]
name: str [35085,35088]
===
match
---
if_stmt [54006,54277]
if_stmt [53958,54229]
===
match
---
suite [82951,83326]
suite [82903,83278]
===
match
---
trailer [44211,44217]
trailer [44163,44169]
===
match
---
name: tasks [78834,78839]
name: tasks [78786,78791]
===
match
---
arglist [47117,47137]
arglist [47069,47089]
===
match
---
name: clear_dags [58116,58126]
name: clear_dags [58068,58078]
===
match
---
funcdef [80289,80549]
funcdef [80241,80501]
===
match
---
name: dp [66300,66302]
name: dp [66252,66254]
===
match
---
annassign [73842,73887]
annassign [73794,73839]
===
match
---
operator: = [37138,37139]
operator: = [37090,37091]
===
match
---
expr_stmt [26376,26430]
expr_stmt [26328,26382]
===
match
---
name: execution_date [44385,44399]
name: execution_date [44337,44351]
===
match
---
dotted_name [1831,1858]
dotted_name [1831,1858]
===
match
---
arglist [21997,22016]
arglist [21973,21992]
===
match
---
string: "Maximum recursion depth {} reached for {} {}. " [54491,54539]
string: "Maximum recursion depth {} reached for {} {}. " [54443,54491]
===
match
---
atom_expr [30029,30048]
atom_expr [29981,30000]
===
match
---
operator: -> [31676,31678]
operator: -> [31628,31630]
===
match
---
atom_expr [85856,85896]
atom_expr [85808,85848]
===
match
---
simple_stmt [96724,96754]
simple_stmt [96676,96706]
===
match
---
atom [75967,76000]
atom [75919,75952]
===
match
---
name: max_recursion_depth [52484,52503]
name: max_recursion_depth [52436,52455]
===
match
---
string: "DAG" [75444,75449]
string: "DAG" [75396,75401]
===
match
---
if_stmt [20151,20245]
if_stmt [20151,20245]
===
match
---
name: dag_id [37780,37786]
name: dag_id [37732,37738]
===
match
---
if_stmt [79097,79178]
if_stmt [79049,79130]
===
match
---
atom_expr [36669,36703]
atom_expr [36621,36655]
===
match
---
param [60960,60965]
param [60912,60917]
===
match
---
name: DAG [83659,83662]
name: DAG [83611,83614]
===
match
---
name: only_failed [58583,58594]
name: only_failed [58535,58546]
===
match
---
fstring_expr [68321,68335]
fstring_expr [68273,68287]
===
match
---
suite [81255,82047]
suite [81207,81999]
===
match
---
operator: @ [39059,39060]
operator: @ [39011,39012]
===
match
---
comparison [57108,57142]
comparison [57060,57094]
===
match
---
atom_expr [88247,88268]
atom_expr [88199,88220]
===
match
---
atom_expr [76709,76721]
atom_expr [76661,76673]
===
match
---
trailer [29569,29576]
trailer [29521,29528]
===
match
---
decorator [30908,30918]
decorator [30860,30870]
===
match
---
name: DagModel [34201,34209]
name: DagModel [34153,34161]
===
match
---
name: replace [32209,32216]
name: replace [32161,32168]
===
match
---
name: get_task_group_dict [64259,64278]
name: get_task_group_dict [64211,64230]
===
match
---
simple_stmt [66244,66254]
simple_stmt [66196,66206]
===
match
---
param [91412,91416]
param [91364,91368]
===
match
---
if_stmt [57153,57222]
if_stmt [57105,57174]
===
match
---
param [20301,20305]
param [20301,20305]
===
match
---
trailer [80266,80283]
trailer [80218,80235]
===
match
---
name: query [76080,76085]
name: query [76032,76037]
===
match
---
and_test [73668,73691]
and_test [73620,73643]
===
match
---
name: _task_group [64084,64095]
name: _task_group [64036,64047]
===
match
---
expr_stmt [45548,45621]
expr_stmt [45500,45573]
===
match
---
tfpdef [38156,38185]
tfpdef [38108,38137]
===
match
---
fstring_end: ' [15247,15248]
fstring_end: ' [15247,15248]
===
match
---
name: DagRun [77741,77747]
name: DagRun [77693,77699]
===
match
---
argument [56446,56473]
argument [56398,56425]
===
match
---
trailer [3608,3617]
trailer [3608,3617]
===
match
---
operator: , [3135,3136]
operator: , [3135,3136]
===
match
---
simple_stmt [85012,85022]
simple_stmt [84964,84974]
===
match
---
name: include_downstream [62474,62492]
name: include_downstream [62426,62444]
===
match
---
name: _max_active_tasks [30547,30564]
name: _max_active_tasks [30499,30516]
===
match
---
trailer [36463,36482]
trailer [36415,36434]
===
match
---
operator: == [16967,16969]
operator: == [16967,16969]
===
match
---
trailer [77603,77610]
trailer [77555,77562]
===
match
---
operator: { [55563,55564]
operator: { [55515,55516]
===
match
---
operator: = [65780,65781]
operator: = [65732,65733]
===
match
---
name: local [70964,70969]
name: local [70916,70921]
===
match
---
operator: = [14238,14239]
operator: = [14238,14239]
===
match
---
operator: , [30814,30815]
operator: , [30766,30767]
===
match
---
simple_stmt [36376,36439]
simple_stmt [36328,36391]
===
match
---
argument [52213,52244]
argument [52165,52196]
===
match
---
atom_expr [53903,53913]
atom_expr [53855,53865]
===
match
---
operator: @ [95335,95336]
operator: @ [95287,95288]
===
match
---
return_stmt [40411,40450]
return_stmt [40363,40402]
===
match
---
suite [25984,26145]
suite [25936,26097]
===
match
---
trailer [63581,63589]
trailer [63533,63541]
===
match
---
decorator [98170,98183]
decorator [98122,98135]
===
match
---
simple_stmt [60448,60476]
simple_stmt [60400,60428]
===
match
---
name: execution_date [74414,74428]
name: execution_date [74366,74380]
===
match
---
name: end_date [27261,27269]
name: end_date [27213,27221]
===
match
---
name: task_dict [62037,62046]
name: task_dict [61989,61998]
===
match
---
operator: -> [22921,22923]
operator: -> [22873,22875]
===
match
---
name: DagRun [77176,77182]
name: DagRun [77128,77134]
===
match
---
simple_stmt [15827,15874]
simple_stmt [15827,15874]
===
match
---
operator: , [52338,52339]
operator: , [52290,52291]
===
match
---
operator: , [58139,58140]
operator: , [58091,58092]
===
match
---
atom_expr [16900,16911]
atom_expr [16900,16911]
===
match
---
name: intersection [64928,64940]
name: intersection [64880,64892]
===
match
---
name: self [32358,32362]
name: self [32310,32314]
===
match
---
name: get_tis [56511,56518]
name: get_tis [56463,56470]
===
match
---
trailer [43010,43015]
trailer [42962,42967]
===
match
---
name: replace [32265,32272]
name: replace [32217,32224]
===
match
---
name: filtered_child [63992,64006]
name: filtered_child [63944,63958]
===
match
---
name: donot_pickle [71450,71462]
name: donot_pickle [71402,71414]
===
match
---
name: self [38864,38868]
name: self [38816,38820]
===
match
---
operator: = [44059,44060]
operator: = [44011,44012]
===
match
---
trailer [65473,65481]
trailer [65425,65433]
===
match
---
atom [63375,63377]
atom [63327,63329]
===
match
---
suite [85378,85661]
suite [85330,85613]
===
match
---
trailer [94678,94744]
trailer [94630,94696]
===
match
---
trailer [81060,81062]
trailer [81012,81014]
===
match
---
trailer [60909,60926]
trailer [60861,60878]
===
match
---
operator: = [95229,95230]
operator: = [95181,95182]
===
match
---
suite [21793,22664]
suite [21769,22616]
===
match
---
name: session [93212,93219]
name: session [93164,93171]
===
match
---
not_test [3485,3517]
not_test [3485,3517]
===
match
---
suite [11772,16851]
suite [11772,16851]
===
match
---
trailer [78411,78417]
trailer [78363,78369]
===
match
---
suite [48077,48146]
suite [48029,48098]
===
match
---
simple_stmt [66493,66531]
simple_stmt [66445,66483]
===
match
---
name: dag_bag [52545,52552]
name: dag_bag [52497,52504]
===
match
---
operator: } [88933,88934]
operator: } [88885,88886]
===
match
---
trailer [10648,10654]
trailer [10648,10654]
===
match
---
operator: , [60209,60210]
operator: , [60161,60162]
===
match
---
and_test [27282,27314]
and_test [27234,27266]
===
match
---
trailer [60697,60874]
trailer [60649,60826]
===
match
---
name: self [30938,30942]
name: self [30890,30894]
===
match
---
name: joinedload [1490,1500]
name: joinedload [1490,1500]
===
match
---
atom_expr [33155,33287]
atom_expr [33107,33239]
===
match
---
name: downstream_task_id [84962,84980]
name: downstream_task_id [84914,84932]
===
match
---
trailer [43588,43595]
trailer [43540,43547]
===
match
---
name: all_tis [58892,58899]
name: all_tis [58844,58851]
===
match
---
operator: , [38192,38193]
operator: , [38144,38145]
===
match
---
simple_stmt [16639,16696]
simple_stmt [16639,16696]
===
match
---
funcdef [31014,31079]
funcdef [30966,31031]
===
match
---
expr_stmt [51425,51459]
expr_stmt [51377,51411]
===
match
---
operator: { [68321,68322]
operator: { [68273,68274]
===
match
---
if_stmt [51157,51603]
if_stmt [51109,51555]
===
match
---
operator: = [15010,15011]
operator: = [15010,15011]
===
match
---
name: self [32046,32050]
name: self [31998,32002]
===
match
---
expr_stmt [93190,93542]
expr_stmt [93142,93494]
===
match
---
simple_stmt [97075,97095]
simple_stmt [97027,97047]
===
match
---
name: croniter [22037,22045]
name: croniter [22013,22021]
===
match
---
trailer [34728,34746]
trailer [34680,34698]
===
match
---
comp_if [57105,57142]
comp_if [57057,57094]
===
match
---
expr_stmt [43579,43636]
expr_stmt [43531,43588]
===
match
---
trailer [77778,77784]
trailer [77730,77736]
===
match
---
param [69272,69282]
param [69224,69234]
===
match
---
expr_stmt [76490,76531]
expr_stmt [76442,76483]
===
match
---
atom_expr [10782,10795]
atom_expr [10782,10795]
===
match
---
name: property [30479,30487]
name: property [30431,30439]
===
match
---
operator: = [16669,16670]
operator: = [16669,16670]
===
match
---
trailer [63314,63328]
trailer [63266,63280]
===
match
---
name: get_task_instances [42839,42857]
name: get_task_instances [42791,42809]
===
match
---
name: self [39594,39598]
name: self [39546,39550]
===
match
---
trailer [17576,17586]
trailer [17576,17586]
===
match
---
name: TypeError [38679,38688]
name: TypeError [38631,38640]
===
match
---
trailer [42984,42991]
trailer [42936,42943]
===
match
---
atom_expr [63404,63427]
atom_expr [63356,63379]
===
match
---
name: ignore_task_deps [71493,71509]
name: ignore_task_deps [71445,71461]
===
match
---
name: AirflowException [1728,1744]
name: AirflowException [1728,1744]
===
match
---
trailer [84886,84896]
trailer [84838,84848]
===
match
---
suite [59389,59788]
suite [59341,59740]
===
match
---
simple_stmt [97058,97073]
simple_stmt [97010,97025]
===
match
---
return_stmt [38070,38091]
return_stmt [38022,38043]
===
match
---
expr_stmt [14605,14651]
expr_stmt [14605,14651]
===
match
---
operator: , [37131,37132]
operator: , [37083,37084]
===
match
---
string: 'start_date' [13381,13393]
string: 'start_date' [13381,13393]
===
match
---
name: conf [72339,72343]
name: conf [72291,72295]
===
match
---
trailer [68254,68269]
trailer [68206,68221]
===
match
---
name: timedelta [25449,25458]
name: timedelta [25401,25410]
===
match
---
operator: = [19467,19468]
operator: = [19467,19468]
===
match
---
operator: == [37836,37838]
operator: == [37788,37790]
===
match
---
atom_expr [85863,85877]
atom_expr [85815,85829]
===
match
---
suite [32371,32494]
suite [32323,32446]
===
match
---
operator: } [96523,96524]
operator: } [96475,96476]
===
match
---
atom_expr [47292,47363]
atom_expr [47244,47315]
===
match
---
name: value [30421,30426]
name: value [30373,30378]
===
match
---
name: last_start [25569,25579]
name: last_start [25521,25531]
===
match
---
operator: = [53303,53304]
operator: = [53255,53256]
===
match
---
simple_stmt [38070,38092]
simple_stmt [38022,38044]
===
match
---
name: new_start [25763,25772]
name: new_start [25715,25724]
===
match
---
trailer [62110,62122]
trailer [62062,62074]
===
match
---
simple_stmt [41202,41229]
simple_stmt [41154,41181]
===
match
---
expr_stmt [65856,65910]
expr_stmt [65808,65862]
===
match
---
trailer [66219,66226]
trailer [66171,66178]
===
match
---
and_test [94214,94279]
and_test [94166,94231]
===
match
---
simple_stmt [96917,96931]
simple_stmt [96869,96883]
===
match
---
name: group [64555,64560]
name: group [64507,64512]
===
match
---
name: task_id [65275,65282]
name: task_id [65227,65234]
===
match
---
decorator [30375,30395]
decorator [30327,30347]
===
match
---
name: in_ [77611,77614]
name: in_ [77563,77566]
===
match
---
trailer [10593,10609]
trailer [10593,10609]
===
match
---
atom_expr [74700,74716]
atom_expr [74652,74668]
===
match
---
trailer [77115,77133]
trailer [77067,77085]
===
match
---
simple_stmt [80441,80498]
simple_stmt [80393,80450]
===
match
---
name: ID_LEN [1813,1819]
name: ID_LEN [1813,1819]
===
match
---
operator: = [14630,14631]
operator: = [14630,14631]
===
match
---
operator: @ [89196,89197]
operator: @ [89148,89149]
===
match
---
trailer [39525,39531]
trailer [39477,39483]
===
match
---
name: keys [64632,64636]
name: keys [64584,64588]
===
match
---
name: provide_session [89338,89353]
name: provide_session [89290,89305]
===
match
---
param [60598,60606]
param [60550,60558]
===
match
---
argument [76509,76530]
argument [76461,76482]
===
match
---
name: provide_session [66086,66101]
name: provide_session [66038,66053]
===
match
---
decorator [33750,33767]
decorator [33702,33719]
===
match
---
atom_expr [76128,76141]
atom_expr [76080,76093]
===
match
---
atom_expr [37773,37786]
atom_expr [37725,37738]
===
match
---
if_stmt [23703,23767]
if_stmt [23655,23719]
===
match
---
trailer [64927,64940]
trailer [64879,64892]
===
match
---
name: str [11752,11755]
name: str [11752,11755]
===
match
---
operator: = [56518,56519]
operator: = [56470,56471]
===
match
---
simple_stmt [65735,65760]
simple_stmt [65687,65712]
===
match
---
argument [74587,74604]
argument [74539,74556]
===
match
---
atom_expr [13857,13886]
atom_expr [13857,13886]
===
match
---
atom_expr [40017,40028]
atom_expr [39969,39980]
===
match
---
operator: } [47360,47361]
operator: } [47312,47313]
===
match
---
simple_stmt [34441,34623]
simple_stmt [34393,34575]
===
match
---
atom_expr [42296,42320]
atom_expr [42248,42272]
===
match
---
name: t [59164,59165]
name: t [59116,59117]
===
match
---
operator: , [81859,81860]
operator: , [81811,81812]
===
match
---
name: String [85922,85928]
name: String [85874,85880]
===
match
---
parameters [36944,36950]
parameters [36896,36902]
===
match
---
operator: , [43211,43212]
operator: , [43163,43164]
===
match
---
tfpdef [10893,10913]
tfpdef [10893,10913]
===
match
---
decorator [38097,38114]
decorator [38049,38066]
===
match
---
decorator [89337,89354]
decorator [89289,89306]
===
match
---
operator: * [91209,91210]
operator: * [91161,91162]
===
match
---
param [11732,11765]
param [11732,11765]
===
match
---
comparison [68222,68269]
comparison [68174,68221]
===
match
---
for_stmt [66837,66909]
for_stmt [66789,66861]
===
match
---
name: session [89384,89391]
name: session [89336,89343]
===
match
---
name: schedule_interval [35147,35164]
name: schedule_interval [35099,35116]
===
match
---
number: 2000 [87211,87215]
number: 2000 [87163,87167]
===
match
---
atom_expr [97870,97883]
atom_expr [97822,97835]
===
match
---
operator: = [52446,52447]
operator: = [52398,52399]
===
match
---
name: _full_filepath [12336,12350]
name: _full_filepath [12336,12350]
===
match
---
name: num_active_runs [77478,77493]
name: num_active_runs [77430,77445]
===
match
---
name: add_task [68889,68897]
name: add_task [68841,68849]
===
match
---
simple_stmt [12331,12392]
simple_stmt [12331,12392]
===
match
---
operator: , [19699,19700]
operator: , [19699,19700]
===
match
---
name: expression [38027,38037]
name: expression [37979,37989]
===
match
---
trailer [14107,14117]
trailer [14107,14117]
===
match
---
operator: == [3467,3469]
operator: == [3467,3469]
===
match
---
name: max_active_tasks [88556,88572]
name: max_active_tasks [88508,88524]
===
match
---
name: end_date [48068,48076]
name: end_date [48020,48028]
===
match
---
if_stmt [82968,83326]
if_stmt [82920,83278]
===
match
---
trailer [74874,74891]
trailer [74826,74843]
===
match
---
atom_expr [62097,62122]
atom_expr [62049,62074]
===
match
---
operator: , [10001,10002]
operator: , [10001,10002]
===
match
---
name: cron [20074,20078]
name: cron [20074,20078]
===
match
---
name: self [20732,20736]
name: self [20732,20736]
===
match
---
simple_stmt [44353,44407]
simple_stmt [44305,44359]
===
match
---
atom_expr [14660,14683]
atom_expr [14660,14683]
===
match
---
name: filters [42433,42440]
name: filters [42385,42392]
===
match
---
name: mark_success [68988,69000]
name: mark_success [68940,68952]
===
match
---
trailer [26613,26624]
trailer [26565,26576]
===
match
---
name: Optional [10484,10492]
name: Optional [10484,10492]
===
match
---
if_stmt [37873,38061]
if_stmt [37825,38013]
===
match
---
name: self [13473,13477]
name: self [13473,13477]
===
match
---
atom_expr [85567,85591]
atom_expr [85519,85543]
===
match
---
parameters [94754,94779]
parameters [94706,94731]
===
match
---
simple_stmt [89269,89332]
simple_stmt [89221,89284]
===
match
---
atom_expr [79281,79287]
atom_expr [79233,79239]
===
match
---
dictorsetmaker [90133,90183]
dictorsetmaker [90085,90135]
===
match
---
funcdef [91384,92576]
funcdef [91336,92528]
===
match
---
trailer [25568,25580]
trailer [25520,25532]
===
match
---
name: conf [1692,1696]
name: conf [1692,1696]
===
match
---
atom_expr [81999,82017]
atom_expr [81951,81969]
===
match
---
name: run_type [73960,73968]
name: run_type [73912,73920]
===
match
---
parameters [19791,19797]
parameters [19791,19797]
===
match
---
name: session [76799,76806]
name: session [76751,76758]
===
match
---
atom_expr [43043,43113]
atom_expr [42995,43065]
===
match
---
simple_stmt [98474,98489]
simple_stmt [98426,98441]
===
match
---
fstring_string: > [88934,88935]
fstring_string: > [88886,88887]
===
match
---
name: new_start [25701,25710]
name: new_start [25653,25662]
===
match
---
param [95375,95381]
param [95327,95333]
===
match
---
operator: < [81679,81680]
operator: < [81631,81632]
===
match
---
expr_stmt [81965,81986]
expr_stmt [81917,81938]
===
match
---
tfpdef [72153,72187]
tfpdef [72105,72139]
===
match
---
atom_expr [15162,15328]
atom_expr [15162,15328]
===
match
---
expr_stmt [18635,18835]
expr_stmt [18635,18835]
===
match
---
trailer [28728,28747]
trailer [28680,28699]
===
match
---
simple_stmt [63207,63233]
simple_stmt [63159,63185]
===
match
---
name: self [67665,67669]
name: self [67617,67621]
===
match
---
trailer [13168,13177]
trailer [13168,13177]
===
match
---
atom_expr [26817,26832]
atom_expr [26769,26784]
===
match
---
with_stmt [96072,96931]
with_stmt [96024,96883]
===
match
---
atom_expr [94128,94157]
atom_expr [94080,94109]
===
match
---
operator: = [78545,78546]
operator: = [78497,78498]
===
match
---
trailer [33253,33259]
trailer [33205,33211]
===
match
---
operator: = [48005,48006]
operator: = [47957,47958]
===
match
---
name: query [82683,82688]
name: query [82635,82640]
===
match
---
trailer [16415,16435]
trailer [16415,16435]
===
match
---
expr_stmt [62612,62663]
expr_stmt [62564,62615]
===
match
---
atom_expr [33226,33237]
atom_expr [33178,33189]
===
match
---
name: kwargs [88228,88234]
name: kwargs [88180,88186]
===
match
---
argument [33675,33687]
argument [33627,33639]
===
match
---
name: default_args [13809,13821]
name: default_args [13809,13821]
===
match
---
if_stmt [13790,13997]
if_stmt [13790,13997]
===
match
---
trailer [40787,40809]
trailer [40739,40761]
===
match
---
operator: , [74995,74996]
operator: , [74947,74948]
===
match
---
argument [12655,12667]
argument [12655,12667]
===
match
---
atom_expr [11738,11757]
atom_expr [11738,11757]
===
match
---
simple_stmt [1963,2008]
simple_stmt [1963,2008]
===
match
---
parameters [40481,40487]
parameters [40433,40439]
===
match
---
name: str [11092,11095]
name: str [11092,11095]
===
match
---
operator: , [84078,84079]
operator: , [84030,84031]
===
match
---
trailer [21985,21996]
trailer [21961,21972]
===
match
---
simple_stmt [91324,91341]
simple_stmt [91276,91293]
===
match
---
param [61108,61138]
param [61060,61090]
===
match
---
param [48264,48269]
param [48216,48221]
===
match
---
name: end_date [39701,39709]
name: end_date [39653,39661]
===
match
---
operator: } [32750,32751]
operator: } [32702,32703]
===
match
---
operator: = [36647,36648]
operator: = [36599,36600]
===
match
---
name: self [13412,13416]
name: self [13412,13416]
===
match
---
parameters [68916,69351]
parameters [68868,69303]
===
match
---
name: TaskGroup [11818,11827]
name: TaskGroup [11818,11827]
===
match
---
atom_expr [44372,44399]
atom_expr [44324,44351]
===
match
---
atom_expr [44642,44660]
atom_expr [44594,44612]
===
match
---
atom_expr [60384,60411]
atom_expr [60336,60363]
===
match
---
name: deactivate_unknown_dags [80597,80620]
name: deactivate_unknown_dags [80549,80572]
===
match
---
name: add [68595,68598]
name: add [68547,68550]
===
match
---
name: access_control [19031,19045]
name: access_control [19031,19045]
===
match
---
decorator [31084,31094]
decorator [31036,31046]
===
match
---
atom_expr [19493,19511]
atom_expr [19493,19511]
===
match
---
simple_stmt [28109,28135]
simple_stmt [28061,28087]
===
match
---
number: 0 [54028,54029]
number: 0 [53980,53981]
===
match
---
name: utils [1652,1657]
name: utils [1652,1657]
===
match
---
simple_stmt [2096,2180]
simple_stmt [2096,2180]
===
match
---
operator: = [33153,33154]
operator: = [33105,33106]
===
match
---
number: 0 [59822,59823]
number: 0 [59774,59775]
===
match
---
operator: = [95692,95693]
operator: = [95644,95645]
===
match
---
operator: , [76141,76142]
operator: , [76093,76094]
===
match
---
for_stmt [58447,58912]
for_stmt [58399,58864]
===
match
---
expr_stmt [86142,86200]
expr_stmt [86094,86152]
===
match
---
name: tasks [44629,44634]
name: tasks [44581,44586]
===
match
---
name: tis [57839,57842]
name: tis [57791,57794]
===
match
---
name: orientation [11157,11168]
name: orientation [11157,11168]
===
match
---
name: session [92628,92635]
name: session [92580,92587]
===
match
---
name: models [1976,1982]
name: models [1976,1982]
===
match
---
simple_stmt [59885,59898]
simple_stmt [59837,59850]
===
match
---
simple_stmt [28258,28311]
simple_stmt [28210,28263]
===
match
---
tfpdef [48496,48514]
tfpdef [48448,48466]
===
match
---
param [18059,18065]
param [18059,18065]
===
match
---
operator: , [18072,18073]
operator: , [18072,18073]
===
match
---
name: dirname [32281,32288]
name: dirname [32233,32240]
===
match
---
name: __class__ [60044,60053]
name: __class__ [59996,60005]
===
match
---
trailer [3459,3466]
trailer [3459,3466]
===
match
---
name: DAG [95241,95244]
name: DAG [95193,95196]
===
match
---
operator: = [74664,74665]
operator: = [74616,74617]
===
match
---
name: or_ [91205,91208]
name: or_ [91157,91160]
===
match
---
expr_stmt [97095,97142]
expr_stmt [97047,97094]
===
match
---
suite [47139,47241]
suite [47091,47193]
===
match
---
atom_expr [60890,60926]
atom_expr [60842,60878]
===
match
---
atom_expr [2880,2907]
atom_expr [2880,2907]
===
match
---
atom_expr [60039,60053]
atom_expr [59991,60005]
===
match
---
trailer [91121,91128]
trailer [91073,91080]
===
match
---
or_test [25393,25459]
or_test [25345,25411]
===
match
---
atom_expr [10836,10883]
atom_expr [10836,10883]
===
match
---
comp_op [79113,79119]
comp_op [79065,79071]
===
match
---
operator: = [21931,21932]
operator: = [21907,21908]
===
match
---
trailer [76984,77379]
trailer [76936,77331]
===
match
---
name: airflow [40640,40647]
name: airflow [40592,40599]
===
match
---
comparison [33943,33973]
comparison [33895,33925]
===
match
---
name: max_active_runs [14900,14915]
name: max_active_runs [14900,14915]
===
match
---
operator: , [71759,71760]
operator: , [71711,71712]
===
match
---
name: add_tasks [68669,68678]
name: add_tasks [68621,68630]
===
match
---
name: c [17167,17168]
name: c [17167,17168]
===
match
---
trailer [94673,94678]
trailer [94625,94630]
===
match
---
name: State [72138,72143]
name: State [72090,72095]
===
match
---
expr_stmt [13588,13621]
expr_stmt [13588,13621]
===
match
---
dictorsetmaker [75968,75999]
dictorsetmaker [75920,75951]
===
match
---
expr_stmt [98134,98164]
expr_stmt [98086,98116]
===
match
---
expr_stmt [62021,62082]
expr_stmt [61973,62034]
===
match
---
param [89070,89077]
param [89022,89029]
===
match
---
name: self [28500,28504]
name: self [28452,28456]
===
match
---
expr_stmt [62091,62122]
expr_stmt [62043,62074]
===
match
---
atom_expr [98434,98458]
atom_expr [98386,98410]
===
match
---
name: Exception [92516,92525]
name: Exception [92468,92477]
===
match
---
name: flush [74733,74738]
name: flush [74685,74690]
===
match
---
operator: = [66748,66749]
operator: = [66700,66701]
===
match
---
trailer [59156,59159]
trailer [59108,59111]
===
match
---
comparison [88704,88744]
comparison [88656,88696]
===
match
---
name: run_backwards [71773,71786]
name: run_backwards [71725,71738]
===
match
---
trailer [10920,10927]
trailer [10920,10927]
===
match
---
comparison [35142,35180]
comparison [35094,35132]
===
match
---
return_stmt [27023,27034]
return_stmt [26975,26986]
===
match
---
name: tasks [40737,40742]
name: tasks [40689,40694]
===
match
---
name: self [60351,60355]
name: self [60303,60307]
===
match
---
operator: , [87948,87949]
operator: , [87900,87901]
===
match
---
name: session [89246,89253]
name: session [89198,89205]
===
match
---
name: nullable [87649,87657]
name: nullable [87601,87609]
===
match
---
operator: = [22288,22289]
operator: = [22264,22265]
===
match
---
suite [43774,44345]
suite [43726,44297]
===
match
---
simple_stmt [30152,30332]
simple_stmt [30104,30284]
===
match
---
atom_expr [17152,17175]
atom_expr [17152,17175]
===
match
---
trailer [77018,77025]
trailer [76970,76977]
===
match
---
operator: , [20808,20809]
operator: , [20808,20809]
===
match
---
atom_expr [40000,40013]
atom_expr [39952,39965]
===
match
---
return_stmt [97058,97072]
return_stmt [97010,97024]
===
match
---
name: self [35528,35532]
name: self [35480,35484]
===
match
---
trailer [53312,53314]
trailer [53264,53266]
===
match
---
parameters [81223,81254]
parameters [81175,81206]
===
match
---
name: ignore_first_depends_on_past [71523,71551]
name: ignore_first_depends_on_past [71475,71503]
===
match
---
name: NUM_DAGS_PER_DAGRUN_QUERY [88048,88073]
name: NUM_DAGS_PER_DAGRUN_QUERY [88000,88025]
===
match
---
name: max_recursion_depth [54724,54743]
name: max_recursion_depth [54676,54695]
===
match
---
name: dag_id [3165,3171]
name: dag_id [3165,3171]
===
match
---
argument [55807,55830]
argument [55759,55782]
===
match
---
atom_expr [74192,74319]
atom_expr [74144,74271]
===
match
---
name: template_undefined [41682,41700]
name: template_undefined [41634,41652]
===
match
---
name: verbose [71670,71677]
name: verbose [71622,71629]
===
match
---
operator: , [85072,85073]
operator: , [85024,85025]
===
match
---
atom_expr [67694,67709]
atom_expr [67646,67661]
===
match
---
trailer [51144,51148]
trailer [51096,51100]
===
match
---
name: self [20908,20912]
name: self [20908,20912]
===
match
---
atom_expr [90047,90075]
atom_expr [89999,90027]
===
match
---
name: args [95713,95717]
name: args [95665,95669]
===
match
---
name: dag_ids [76009,76016]
name: dag_ids [75961,75968]
===
match
---
simple_stmt [63759,63809]
simple_stmt [63711,63761]
===
match
---
atom_expr [13925,13954]
atom_expr [13925,13954]
===
match
---
operator: , [39709,39710]
operator: , [39661,39662]
===
match
---
operator: , [90761,90762]
operator: , [90713,90714]
===
match
---
operator: } [62978,62979]
operator: } [62930,62931]
===
match
---
trailer [78437,78447]
trailer [78389,78399]
===
match
---
expr_stmt [32185,32248]
expr_stmt [32137,32200]
===
match
---
classdef [85663,94745]
classdef [85615,94697]
===
match
---
operator: = [89681,89682]
operator: = [89633,89634]
===
match
---
atom_expr [98367,98407]
atom_expr [98319,98359]
===
match
---
name: orm [1531,1534]
name: orm [1531,1534]
===
match
---
trailer [96744,96746]
trailer [96696,96698]
===
match
---
name: include_externally_triggered [29217,29245]
name: include_externally_triggered [29169,29197]
===
match
---
parameters [32094,32100]
parameters [32046,32052]
===
match
---
atom_expr [25597,25612]
atom_expr [25549,25564]
===
match
---
atom_expr [95694,95728]
atom_expr [95646,95680]
===
match
---
name: task_id [68604,68611]
name: task_id [68556,68563]
===
match
---
suite [15375,15419]
suite [15375,15419]
===
match
---
name: DagModel [89949,89957]
name: DagModel [89901,89909]
===
match
---
string: "Creating DagRun needs either `run_id` or both `run_type` and `execution_date`" [74226,74305]
string: "Creating DagRun needs either `run_id` or both `run_type` and `execution_date`" [74178,74257]
===
match
---
name: dag_id [77925,77931]
name: dag_id [77877,77883]
===
match
---
string: r"^{}$" [51771,51778]
string: r"^{}$" [51723,51730]
===
match
---
simple_stmt [88984,89009]
simple_stmt [88936,88961]
===
match
---
string: """Stringified DAGs and operators contain exactly these fields.""" [83499,83565]
string: """Stringified DAGs and operators contain exactly these fields.""" [83451,83517]
===
match
---
trailer [64976,64997]
trailer [64928,64949]
===
match
---
param [48376,48395]
param [48328,48347]
===
match
---
operator: + [56646,56647]
operator: + [56598,56599]
===
match
---
string: "Cancelled, nothing was cleared." [59842,59875]
string: "Cancelled, nothing was cleared." [59794,59827]
===
match
---
name: dag_id [78176,78182]
name: dag_id [78128,78134]
===
match
---
trailer [22938,22957]
trailer [22890,22909]
===
match
---
operator: = [78321,78322]
operator: = [78273,78274]
===
match
---
atom_expr [13457,13470]
atom_expr [13457,13470]
===
match
---
operator: = [71449,71450]
operator: = [71401,71402]
===
match
---
trailer [89283,89289]
trailer [89235,89241]
===
match
---
name: options [76109,76116]
name: options [76061,76068]
===
match
---
suite [18922,19019]
suite [18922,19019]
===
match
---
name: include_externally_triggered [89398,89426]
name: include_externally_triggered [89350,89378]
===
match
---
dotted_name [1269,1291]
dotted_name [1269,1291]
===
match
---
name: dates [2355,2360]
name: dates [2355,2360]
===
match
---
trailer [93376,93401]
trailer [93328,93353]
===
match
---
name: include_externally_triggered [3182,3210]
name: include_externally_triggered [3182,3210]
===
match
---
name: tz [21338,21340]
name: tz [21314,21316]
===
match
---
simple_stmt [27328,27368]
simple_stmt [27280,27320]
===
match
---
operator: = [11550,11551]
operator: = [11550,11551]
===
match
---
argument [96081,96101]
argument [96033,96053]
===
match
---
trailer [51397,51411]
trailer [51349,51363]
===
match
---
name: qry [33906,33909]
name: qry [33858,33861]
===
match
---
expr_stmt [87329,87362]
expr_stmt [87281,87314]
===
match
---
name: dags_needing_dagruns [92602,92622]
name: dags_needing_dagruns [92554,92574]
===
match
---
operator: = [64242,64243]
operator: = [64194,64195]
===
match
---
name: local [69016,69021]
name: local [68968,68973]
===
match
---
operator: , [62961,62962]
operator: , [62913,62914]
===
match
---
operator: = [35423,35424]
operator: = [35375,35376]
===
match
---
name: String [85551,85557]
name: String [85503,85509]
===
match
---
operator: { [15586,15587]
operator: { [15586,15587]
===
match
---
operator: , [71708,71709]
operator: , [71660,71661]
===
match
---
name: _task_group [16809,16820]
name: _task_group [16809,16820]
===
match
---
name: append [76841,76847]
name: append [76793,76799]
===
match
---
name: recursion_depth [54305,54320]
name: recursion_depth [54257,54272]
===
match
---
name: setter [30388,30394]
name: setter [30340,30346]
===
match
---
name: serialized_dag [97260,97274]
name: serialized_dag [97212,97226]
===
match
---
simple_stmt [44729,44829]
simple_stmt [44681,44781]
===
match
---
operator: , [71580,71581]
operator: , [71532,71533]
===
match
---
name: DagRun [37773,37779]
name: DagRun [37725,37731]
===
match
---
param [90241,90245]
param [90193,90197]
===
match
---
name: sync_to_db [79990,80000]
name: sync_to_db [79942,79952]
===
match
---
name: session [82675,82682]
name: session [82627,82634]
===
match
---
atom [18869,18871]
atom [18869,18871]
===
match
---
operator: ** [41979,41981]
operator: ** [41931,41933]
===
match
---
or_test [11983,12001]
or_test [11983,12001]
===
match
---
operator: , [31622,31623]
operator: , [31574,31575]
===
match
---
name: task [36561,36565]
name: task [36513,36517]
===
match
---
suite [26359,26431]
suite [26311,26383]
===
match
---
name: str [31294,31297]
name: str [31246,31249]
===
match
---
trailer [60494,60508]
trailer [60446,60460]
===
match
---
trailer [24721,24731]
trailer [24673,24683]
===
match
---
trailer [47188,47195]
trailer [47140,47147]
===
match
---
trailer [23665,23693]
trailer [23617,23645]
===
match
---
and_test [26944,27009]
and_test [26896,26961]
===
match
---
name: next_dagrun_create_after [87996,88020]
name: next_dagrun_create_after [87948,87972]
===
match
---
atom_expr [78547,78563]
atom_expr [78499,78515]
===
match
---
atom_expr [66215,66226]
atom_expr [66167,66178]
===
match
---
name: utils [2349,2354]
name: utils [2349,2354]
===
match
---
name: new_start [25534,25543]
name: new_start [25486,25495]
===
match
---
name: t [62239,62240]
name: t [62191,62192]
===
match
---
name: self [30832,30836]
name: self [30784,30788]
===
match
---
string: """         Calculates the previous schedule for this dag in UTC          :param dttm: utc datetime         :return: utc datetime         """ [21589,21730]
string: """         Calculates the previous schedule for this dag in UTC          :param dttm: utc datetime         :return: utc datetime         """ [21565,21706]
===
match
---
expr_stmt [22030,22087]
expr_stmt [22006,22063]
===
match
---
trailer [75443,75450]
trailer [75395,75402]
===
match
---
name: tuple [47380,47385]
name: tuple [47332,47337]
===
match
---
trailer [88555,88572]
trailer [88507,88524]
===
match
---
return_stmt [65143,65153]
return_stmt [65095,65105]
===
match
---
name: self [43325,43329]
name: self [43277,43281]
===
match
---
atom [91011,91066]
atom [90963,91018]
===
match
---
fstring_expr [65612,65621]
fstring_expr [65564,65573]
===
match
---
name: DagModel [76265,76273]
name: DagModel [76217,76225]
===
match
---
comparison [43896,43905]
comparison [43848,43857]
===
match
---
operator: , [95380,95381]
operator: , [95332,95333]
===
match
---
name: previous [22654,22662]
name: previous [22606,22614]
===
match
---
atom_expr [66493,66510]
atom_expr [66445,66462]
===
match
---
suite [27315,27446]
suite [27267,27398]
===
match
---
simple_stmt [788,800]
simple_stmt [788,800]
===
match
---
sync_comp_for [25915,25950]
sync_comp_for [25867,25902]
===
match
---
name: commit [66551,66557]
name: commit [66503,66509]
===
match
---
atom_expr [10433,10446]
atom_expr [10433,10446]
===
match
---
name: dag [58482,58485]
name: dag [58434,58437]
===
match
---
name: false [38038,38043]
name: false [37990,37995]
===
match
---
operator: = [72430,72431]
operator: = [72382,72383]
===
match
---
atom_expr [42976,42993]
atom_expr [42928,42945]
===
match
---
operator: , [42862,42863]
operator: , [42814,42815]
===
match
---
param [29814,29824]
param [29766,29776]
===
match
---
operator: , [60589,60590]
operator: , [60541,60542]
===
match
---
trailer [67298,67309]
trailer [67250,67261]
===
match
---
operator: = [58372,58373]
operator: = [58324,58325]
===
match
---
name: get_current [89221,89232]
name: get_current [89173,89184]
===
match
---
operator: == [52916,52918]
operator: == [52868,52870]
===
match
---
atom_expr [42774,42807]
atom_expr [42726,42759]
===
match
---
operator: = [14744,14745]
operator: = [14744,14745]
===
match
---
name: visited_external_tis [48691,48711]
name: visited_external_tis [48643,48663]
===
match
---
operator: = [64474,64475]
operator: = [64426,64427]
===
match
---
simple_stmt [68884,68904]
simple_stmt [68836,68856]
===
match
---
trailer [13380,13394]
trailer [13380,13394]
===
match
---
suite [14193,14297]
suite [14193,14297]
===
match
---
operator: = [20116,20117]
operator: = [20116,20117]
===
match
---
trailer [93301,93303]
trailer [93253,93255]
===
match
---
dotted_name [53146,53175]
dotted_name [53098,53127]
===
match
---
name: int [19462,19465]
name: int [19462,19465]
===
match
---
name: task_id [51386,51393]
name: task_id [51338,51345]
===
match
---
simple_stmt [14353,14440]
simple_stmt [14353,14440]
===
match
---
string: """         Simple utility method to set dependency between two tasks that         already have been added to the DAG using add_task()         """ [42572,42718]
string: """         Simple utility method to set dependency between two tasks that         already have been added to the DAG using add_task()         """ [42524,42670]
===
match
---
trailer [35146,35164]
trailer [35098,35116]
===
match
---
operator: = [58222,58223]
operator: = [58174,58175]
===
match
---
trailer [65243,65249]
trailer [65195,65201]
===
match
---
operator: , [37364,37365]
operator: , [37316,37317]
===
match
---
name: self [29565,29569]
name: self [29517,29521]
===
match
---
trailer [62968,62972]
trailer [62920,62924]
===
match
---
name: end_date [27227,27235]
name: end_date [27179,27187]
===
match
---
name: f_sig [96560,96565]
name: f_sig [96512,96517]
===
match
---
testlist_comp [27225,27269]
testlist_comp [27177,27221]
===
match
---
sync_comp_for [62235,62298]
sync_comp_for [62187,62250]
===
match
---
sync_comp_for [90147,90183]
sync_comp_for [90099,90135]
===
match
---
strings [15485,15600]
strings [15485,15600]
===
match
---
name: default_args [12194,12206]
name: default_args [12194,12206]
===
match
---
atom_expr [25414,25459]
atom_expr [25366,25411]
===
match
---
trailer [38853,38860]
trailer [38805,38812]
===
match
---
not_test [20904,20937]
not_test [20904,20937]
===
match
---
name: only_failed [52070,52081]
name: only_failed [52022,52033]
===
match
---
comparison [55116,55172]
comparison [55068,55124]
===
match
---
atom_expr [89302,89312]
atom_expr [89254,89264]
===
match
---
operator: = [72322,72323]
operator: = [72274,72275]
===
match
---
number: 0 [45731,45732]
number: 0 [45683,45684]
===
match
---
comparison [37956,38046]
comparison [37908,37998]
===
match
---
atom_expr [62967,62972]
atom_expr [62919,62924]
===
match
---
name: session [80637,80644]
name: session [80589,80596]
===
match
---
name: end_date [19483,19491]
name: end_date [19483,19491]
===
match
---
name: following_schedule [23969,23987]
name: following_schedule [23921,23939]
===
match
---
for_stmt [79327,79595]
for_stmt [79279,79547]
===
match
---
name: tis [57533,57536]
name: tis [57485,57488]
===
match
---
name: jinja2 [1318,1324]
name: jinja2 [1318,1324]
===
match
---
operator: , [10408,10409]
operator: , [10408,10409]
===
match
---
import_as_names [2368,2412]
import_as_names [2368,2412]
===
match
---
funcdef [44681,44902]
funcdef [44633,44854]
===
match
---
suite [28651,28763]
suite [28603,28715]
===
match
---
name: copied [64027,64033]
name: copied [63979,63985]
===
match
---
not_test [44638,44660]
not_test [44590,44612]
===
match
---
name: TaskInstance [82743,82755]
name: TaskInstance [82695,82707]
===
match
---
name: ignore_first_depends_on_past [69154,69182]
name: ignore_first_depends_on_past [69106,69134]
===
match
---
name: edge [46744,46748]
name: edge [46696,46700]
===
match
---
expr_stmt [97848,97890]
expr_stmt [97800,97842]
===
match
---
name: next_execution_date [23706,23725]
name: next_execution_date [23658,23677]
===
match
---
atom_expr [52986,53023]
atom_expr [52938,52975]
===
match
---
name: name [31618,31622]
name: name [31570,31574]
===
match
---
name: orm_dag [78524,78531]
name: orm_dag [78476,78483]
===
match
---
operator: = [91009,91010]
operator: = [90961,90962]
===
match
---
atom_expr [91205,91223]
atom_expr [91157,91175]
===
match
---
trailer [19098,19335]
trailer [19098,19335]
===
match
---
name: task_end_dates [27352,27366]
name: task_end_dates [27304,27318]
===
match
---
atom_expr [47032,47057]
atom_expr [46984,47009]
===
match
---
funcdef [94747,97073]
funcdef [94699,97025]
===
match
---
dotted_name [2226,2239]
dotted_name [2226,2239]
===
match
---
tfpdef [93691,93699]
tfpdef [93643,93651]
===
match
---
name: dag_id [37795,37801]
name: dag_id [37747,37753]
===
match
---
operator: = [82161,82162]
operator: = [82113,82114]
===
match
---
name: classmethod [83443,83454]
name: classmethod [83395,83406]
===
match
---
name: dag_id [47883,47889]
name: dag_id [47835,47841]
===
match
---
name: len [80924,80927]
name: len [80876,80879]
===
match
---
sync_comp_for [76342,76365]
sync_comp_for [76294,76317]
===
match
---
number: 2 [12666,12667]
number: 2 [12666,12667]
===
match
---
trailer [86804,86813]
trailer [86756,86765]
===
match
---
name: execution_date [39630,39644]
name: execution_date [39582,39596]
===
match
---
trailer [86688,86701]
trailer [86640,86653]
===
match
---
return_stmt [22623,22663]
return_stmt [22575,22615]
===
match
---
name: dagruns [39494,39501]
name: dagruns [39446,39453]
===
match
---
trailer [63363,63372]
trailer [63315,63324]
===
match
---
name: _getframe [12932,12941]
name: _getframe [12932,12941]
===
match
---
expr_stmt [30832,30902]
expr_stmt [30784,30854]
===
match
---
name: user_defined_macros [60329,60348]
name: user_defined_macros [60281,60300]
===
match
---
operator: , [56211,56212]
operator: , [56163,56164]
===
match
---
trailer [33230,33237]
trailer [33182,33189]
===
match
---
name: task [68898,68902]
name: task [68850,68854]
===
match
---
trailer [30651,30669]
trailer [30603,30621]
===
match
---
suite [55249,56924]
suite [55201,56876]
===
match
---
name: TaskInstance [44159,44171]
name: TaskInstance [44111,44123]
===
match
---
not_test [24687,24713]
not_test [24639,24665]
===
match
---
return_stmt [42484,42494]
return_stmt [42436,42446]
===
match
---
atom [57561,57678]
atom [57513,57630]
===
match
---
trailer [82012,82017]
trailer [81964,81969]
===
match
---
operator: @ [89179,89180]
operator: @ [89131,89132]
===
match
---
operator: ** [88190,88192]
operator: ** [88142,88144]
===
match
---
operator: @ [39783,39784]
operator: @ [39735,39736]
===
match
---
trailer [38772,38778]
trailer [38724,38730]
===
match
---
atom_expr [51705,51908]
atom_expr [51657,51860]
===
match
---
atom_expr [84917,84985]
atom_expr [84869,84937]
===
match
---
atom_expr [42032,42091]
atom_expr [41984,42043]
===
match
---
operator: { [9890,9891]
operator: { [9890,9891]
===
match
---
atom [76058,76220]
atom [76010,76172]
===
match
---
atom_expr [16639,16668]
atom_expr [16639,16668]
===
match
---
name: log [81760,81763]
name: log [81712,81715]
===
match
---
decorators [80554,80589]
decorators [80506,80541]
===
match
---
operator: == [37980,37982]
operator: == [37932,37934]
===
match
---
decorator [31749,31763]
decorator [31701,31715]
===
match
---
name: default_args [13232,13244]
name: default_args [13232,13244]
===
match
---
expr_stmt [16457,16477]
expr_stmt [16457,16477]
===
match
---
name: datetime [72263,72271]
name: datetime [72215,72223]
===
match
---
and_test [20154,20219]
and_test [20154,20219]
===
match
---
name: f [96228,96229]
name: f [96180,96181]
===
match
---
expr_stmt [64223,64280]
expr_stmt [64175,64232]
===
match
---
name: tasks [68685,68690]
name: tasks [68637,68642]
===
match
---
trailer [85577,85591]
trailer [85529,85543]
===
match
---
operator: = [57888,57889]
operator: = [57840,57841]
===
match
---
operator: < [65084,65085]
operator: < [65036,65037]
===
match
---
with_item [96077,96138]
with_item [96029,96090]
===
match
---
expr_stmt [76544,76576]
expr_stmt [76496,76528]
===
match
---
atom_expr [86154,86200]
atom_expr [86106,86152]
===
match
---
name: perm [19004,19008]
name: perm [19004,19008]
===
match
---
atom_expr [26761,26848]
atom_expr [26713,26800]
===
match
---
operator: = [20764,20765]
operator: = [20764,20765]
===
match
---
name: list [79342,79346]
name: list [79294,79298]
===
match
---
name: sqlalchemy [1459,1469]
name: sqlalchemy [1459,1469]
===
match
---
name: datetime [19978,19986]
name: datetime [19978,19986]
===
match
---
atom_expr [3571,3589]
atom_expr [3571,3589]
===
match
---
atom_expr [87344,87362]
atom_expr [87296,87314]
===
match
---
operator: { [62028,62029]
operator: { [61980,61981]
===
match
---
expr_stmt [30029,30056]
expr_stmt [29981,30008]
===
match
---
operator: = [47525,47526]
operator: = [47477,47478]
===
match
---
not_test [13557,13574]
not_test [13557,13574]
===
match
---
atom_expr [93453,93481]
atom_expr [93405,93433]
===
match
---
trailer [38976,38983]
trailer [38928,38935]
===
match
---
name: query [89116,89121]
name: query [89068,89073]
===
match
---
name: settings [79607,79615]
name: settings [79559,79567]
===
match
---
atom_expr [39518,39743]
atom_expr [39470,39695]
===
match
---
expr_stmt [11837,11883]
expr_stmt [11837,11883]
===
match
---
name: globals [42338,42345]
name: globals [42290,42297]
===
match
---
name: orm_tag [79169,79176]
name: orm_tag [79121,79128]
===
match
---
name: log [65959,65962]
name: log [65911,65914]
===
match
---
operator: , [58349,58350]
operator: , [58301,58302]
===
match
---
atom [23366,23454]
atom [23318,23406]
===
match
---
suite [59033,59094]
suite [58985,59046]
===
match
---
trailer [78175,78182]
trailer [78127,78134]
===
match
---
comparison [53434,53462]
comparison [53386,53414]
===
match
---
param [90763,90775]
param [90715,90727]
===
match
---
trailer [81768,81952]
trailer [81720,81904]
===
match
---
argument [30308,30320]
argument [30260,30272]
===
match
---
name: is_active [93325,93334]
name: is_active [93277,93286]
===
match
---
name: int [93771,93774]
name: int [93723,93726]
===
match
---
name: filter [33936,33942]
name: filter [33888,33894]
===
match
---
trailer [60998,61033]
trailer [60950,60985]
===
match
---
trailer [43100,43104]
trailer [43052,43056]
===
match
---
name: dag [59377,59380]
name: dag [59329,59332]
===
match
---
name: str [57517,57520]
name: str [57469,57472]
===
match
---
name: timezone [21311,21319]
name: timezone [21287,21295]
===
match
---
operator: = [58859,58860]
operator: = [58811,58812]
===
match
---
atom_expr [40890,40909]
atom_expr [40842,40861]
===
match
---
trailer [34210,34217]
trailer [34162,34169]
===
match
---
simple_stmt [17691,17701]
simple_stmt [17691,17701]
===
match
---
name: str [72464,72467]
name: str [72416,72419]
===
match
---
name: Exception [36774,36783]
name: Exception [36726,36735]
===
match
---
simple_stmt [31579,31641]
simple_stmt [31531,31593]
===
match
---
name: dags [75343,75347]
name: dags [75295,75299]
===
match
---
simple_stmt [20106,20142]
simple_stmt [20106,20142]
===
match
---
name: join [59148,59152]
name: join [59100,59104]
===
match
---
operator: = [76264,76265]
operator: = [76216,76217]
===
match
---
name: dag [78954,78957]
name: dag [78906,78909]
===
match
---
atom_expr [79477,79487]
atom_expr [79429,79439]
===
match
---
name: delay_on_limit_secs [69216,69235]
name: delay_on_limit_secs [69168,69187]
===
match
---
operator: -> [32972,32974]
operator: -> [32924,32926]
===
match
---
simple_stmt [33906,33975]
simple_stmt [33858,33927]
===
match
---
operator: , [11669,11670]
operator: , [11669,11670]
===
match
---
name: dag [94751,94754]
name: dag [94703,94706]
===
match
---
funcdef [30697,30759]
funcdef [30649,30711]
===
match
---
name: stacklevel [33675,33685]
name: stacklevel [33627,33637]
===
match
---
atom_expr [19453,19466]
atom_expr [19453,19466]
===
match
---
name: orm_dag [76848,76855]
name: orm_dag [76800,76807]
===
match
---
trailer [60100,60110]
trailer [60052,60062]
===
match
---
argument [29595,29652]
argument [29547,29604]
===
match
---
operator: @ [29869,29870]
operator: @ [29821,29822]
===
match
---
name: self [65655,65659]
name: self [65607,65611]
===
match
---
name: provide_session [39784,39799]
name: provide_session [39736,39751]
===
match
---
name: self [22677,22681]
name: self [22629,22633]
===
match
---
trailer [19529,19531]
trailer [19529,19531]
===
match
---
argument [37113,37131]
argument [37065,37083]
===
match
---
name: on_success_callback [15799,15818]
name: on_success_callback [15799,15818]
===
match
---
trailer [60159,60161]
trailer [60111,60113]
===
match
---
suite [42922,44426]
suite [42874,44378]
===
match
---
name: state [2726,2731]
name: state [2726,2731]
===
match
---
if_stmt [98289,98466]
if_stmt [98241,98418]
===
match
---
name: DEFAULT_VIEW_PRESETS [15268,15288]
name: DEFAULT_VIEW_PRESETS [15268,15288]
===
match
---
name: DagPickle [66433,66442]
name: DagPickle [66385,66394]
===
match
---
name: dp [66244,66246]
name: dp [66196,66198]
===
match
---
param [66737,66742]
param [66689,66694]
===
match
---
name: TypeError [17764,17773]
name: TypeError [17764,17773]
===
match
---
name: get_downstream [66951,66965]
name: get_downstream [66903,66917]
===
match
---
trailer [52989,52996]
trailer [52941,52948]
===
match
---
operator: = [60462,60463]
operator: = [60414,60415]
===
match
---
atom_expr [10114,10138]
atom_expr [10114,10138]
===
match
---
suite [37205,37258]
suite [37157,37210]
===
match
---
name: Set [1154,1157]
name: Set [1154,1157]
===
match
---
name: now [25373,25376]
name: now [25325,25328]
===
match
---
trailer [20179,20186]
trailer [20179,20186]
===
match
---
name: ti_list [57497,57504]
name: ti_list [57449,57456]
===
match
---
atom_expr [78408,78417]
atom_expr [78360,78369]
===
match
---
trailer [41025,41032]
trailer [40977,40984]
===
match
---
operator: , [56779,56780]
operator: , [56731,56732]
===
match
---
trailer [33192,33199]
trailer [33144,33151]
===
match
---
operator: = [61093,61094]
operator: = [61045,61046]
===
match
---
operator: = [98459,98460]
operator: = [98411,98412]
===
match
---
name: using_end_date [28636,28650]
name: using_end_date [28588,28602]
===
match
---
name: only_running [58624,58636]
name: only_running [58576,58588]
===
match
---
arglist [37113,37152]
arglist [37065,37104]
===
match
---
name: include_parentdag [51615,51632]
name: include_parentdag [51567,51584]
===
match
---
name: get [84958,84961]
name: get [84910,84913]
===
match
---
atom_expr [91025,91040]
atom_expr [90977,90992]
===
match
---
name: tis [43579,43582]
name: tis [43531,43534]
===
match
---
param [18260,18279]
param [18260,18279]
===
match
---
name: self [25350,25354]
name: self [25302,25306]
===
match
---
operator: = [39847,39848]
operator: = [39799,39800]
===
match
---
simple_stmt [76649,76697]
simple_stmt [76601,76649]
===
match
---
operator: = [31259,31260]
operator: = [31211,31212]
===
match
---
argument [19308,19320]
argument [19308,19320]
===
match
---
name: task_group [31998,32008]
name: task_group [31950,31960]
===
match
---
atom_expr [14895,14915]
atom_expr [14895,14915]
===
match
---
simple_stmt [46851,46857]
simple_stmt [46803,46809]
===
match
---
atom_expr [37790,37801]
atom_expr [37742,37753]
===
match
---
operator: = [81979,81980]
operator: = [81931,81932]
===
match
---
name: cls [98020,98023]
name: cls [97972,97975]
===
match
---
dotted_name [2624,2648]
dotted_name [2624,2648]
===
match
---
name: session [34187,34194]
name: session [34139,34146]
===
match
---
operator: , [96101,96102]
operator: , [96053,96054]
===
match
---
operator: { [13064,13065]
operator: { [13064,13065]
===
match
---
simple_stmt [90263,90388]
simple_stmt [90215,90340]
===
match
---
argument [74618,74635]
argument [74570,74587]
===
match
---
trailer [41857,41864]
trailer [41809,41816]
===
match
---
simple_stmt [78688,78736]
simple_stmt [78640,78688]
===
match
---
name: airflow [2226,2233]
name: airflow [2226,2233]
===
match
---
arglist [85308,85328]
arglist [85260,85280]
===
match
---
trailer [63973,63989]
trailer [63925,63941]
===
match
---
trailer [98295,98326]
trailer [98247,98278]
===
match
---
name: set_dag_runs_state [47430,47448]
name: set_dag_runs_state [47382,47400]
===
match
---
atom_expr [3535,3590]
atom_expr [3535,3590]
===
match
---
trailer [85307,85329]
trailer [85259,85281]
===
match
---
param [48496,48531]
param [48448,48483]
===
match
---
atom [51355,51380]
atom [51307,51332]
===
match
---
trailer [76847,76856]
trailer [76799,76808]
===
match
---
trailer [79107,79112]
trailer [79059,79064]
===
match
---
return_stmt [31707,31743]
return_stmt [31659,31695]
===
match
---
if_stmt [26941,27035]
if_stmt [26893,26987]
===
match
---
name: rerun_failed_tasks [71741,71759]
name: rerun_failed_tasks [71693,71711]
===
match
---
name: airflow [2258,2265]
name: airflow [2258,2265]
===
match
---
name: default_args [11983,11995]
name: default_args [11983,11995]
===
match
---
operator: = [77494,77495]
operator: = [77446,77447]
===
match
---
name: DeprecationWarning [88463,88481]
name: DeprecationWarning [88415,88433]
===
match
---
trailer [74707,74711]
trailer [74659,74663]
===
match
---
atom_expr [19514,19531]
atom_expr [19514,19531]
===
match
---
param [72339,72367]
param [72291,72319]
===
match
---
name: filter [47929,47935]
name: filter [47881,47887]
===
match
---
arglist [26776,26847]
arglist [26728,26799]
===
match
---
name: _context_managed_dag [98573,98593]
name: _context_managed_dag [98525,98545]
===
match
---
name: all_tis [58952,58959]
name: all_tis [58904,58911]
===
match
---
name: isinstance [21742,21752]
name: isinstance [21718,21728]
===
match
---
operator: = [47483,47484]
operator: = [47435,47436]
===
match
---
atom_expr [83659,83677]
atom_expr [83611,83629]
===
match
---
name: is_ [44218,44221]
name: is_ [44170,44173]
===
match
---
param [63095,63107]
param [63047,63059]
===
match
---
operator: >= [52728,52730]
operator: >= [52680,52682]
===
match
---
name: orm_dag [78025,78032]
name: orm_dag [77977,77984]
===
match
---
comparison [53367,53409]
comparison [53319,53361]
===
match
---
name: self [26962,26966]
name: self [26914,26918]
===
match
---
trailer [81908,81925]
trailer [81860,81877]
===
match
---
name: dag_id [29801,29807]
name: dag_id [29753,29759]
===
match
---
trailer [26044,26062]
trailer [25996,26014]
===
match
---
name: Optional [98223,98231]
name: Optional [98175,98183]
===
match
---
comparison [93321,93355]
comparison [93273,93307]
===
match
---
name: val [31783,31786]
name: val [31735,31738]
===
match
---
trailer [57759,57769]
trailer [57711,57721]
===
match
---
name: updated_access_control [19352,19374]
name: updated_access_control [19352,19374]
===
match
---
name: max [67712,67715]
name: max [67664,67667]
===
match
---
operator: , [3180,3181]
operator: , [3180,3181]
===
match
---
atom_expr [75968,75978]
atom_expr [75920,75930]
===
match
---
return_stmt [44837,44901]
return_stmt [44789,44853]
===
match
---
name: innerjoin [76143,76152]
name: innerjoin [76095,76104]
===
match
---
name: String [87204,87210]
name: String [87156,87162]
===
match
---
simple_stmt [67694,67750]
simple_stmt [67646,67702]
===
match
---
trailer [68153,68163]
trailer [68105,68115]
===
match
---
suite [12157,12262]
suite [12157,12262]
===
match
---
decorated [34664,35482]
decorated [34616,35434]
===
match
---
trailer [37829,37835]
trailer [37781,37787]
===
match
---
name: copied [63801,63807]
name: copied [63753,63759]
===
match
---
comparison [39676,39709]
comparison [39628,39661]
===
match
---
name: self [14942,14946]
name: self [14942,14946]
===
match
---
operator: = [58434,58435]
operator: = [58386,58387]
===
match
---
atom_expr [52793,52810]
atom_expr [52745,52762]
===
match
---
arglist [19659,19749]
arglist [19659,19749]
===
match
---
name: dag [59406,59409]
name: dag [59358,59361]
===
match
---
operator: = [20660,20661]
operator: = [20660,20661]
===
match
---
arglist [55993,56859]
arglist [55945,56811]
===
match
---
decorator [82052,82066]
decorator [82004,82018]
===
match
---
operator: = [25348,25349]
operator: = [25300,25301]
===
match
---
name: default_args [12239,12251]
name: default_args [12239,12251]
===
match
---
trailer [65398,65408]
trailer [65350,65360]
===
match
---
name: active_dag_ids [80928,80942]
name: active_dag_ids [80880,80894]
===
match
---
trailer [90568,90570]
trailer [90520,90522]
===
match
---
name: query [37926,37931]
name: query [37878,37883]
===
match
---
name: job [71820,71823]
name: job [71772,71775]
===
match
---
name: jinja2 [41615,41621]
name: jinja2 [41567,41573]
===
match
---
name: os [32458,32460]
name: os [32410,32412]
===
match
---
trailer [62629,62648]
trailer [62581,62600]
===
match
---
arglist [18988,18998]
arglist [18988,18998]
===
match
---
name: other [17160,17165]
name: other [17160,17165]
===
match
---
name: session [81137,81144]
name: session [81089,81096]
===
match
---
simple_stmt [31707,31744]
simple_stmt [31659,31696]
===
match
---
atom [43305,43336]
atom [43257,43288]
===
match
---
param [35569,35581]
param [35521,35533]
===
match
---
name: t [62343,62344]
name: t [62295,62296]
===
match
---
atom_expr [97927,97936]
atom_expr [97879,97888]
===
match
---
atom_expr [30832,30852]
atom_expr [30784,30804]
===
match
---
trailer [37765,37772]
trailer [37717,37724]
===
match
---
name: d [65856,65857]
name: d [65808,65809]
===
match
---
argument [19659,19680]
argument [19659,19680]
===
match
---
atom_expr [76775,76785]
atom_expr [76727,76737]
===
match
---
testlist_comp [62343,62398]
testlist_comp [62295,62350]
===
match
---
name: int [10910,10913]
name: int [10910,10913]
===
match
---
parameters [32951,32971]
parameters [32903,32923]
===
match
---
operator: , [79468,79469]
operator: , [79420,79421]
===
match
---
argument [75283,75295]
argument [75235,75247]
===
match
---
atom_expr [67712,67749]
atom_expr [67664,67701]
===
match
---
name: template_searchpath [41436,41455]
name: template_searchpath [41388,41407]
===
match
---
name: self [51587,51591]
name: self [51539,51543]
===
match
---
operator: = [94158,94159]
operator: = [94110,94111]
===
match
---
simple_stmt [32823,32898]
simple_stmt [32775,32850]
===
match
---
atom_expr [76240,76297]
atom_expr [76192,76249]
===
match
---
name: self [41154,41158]
name: self [41106,41110]
===
match
---
suite [98008,98165]
suite [97960,98117]
===
match
---
atom_expr [94577,94596]
atom_expr [94529,94548]
===
match
---
param [41154,41158]
param [41106,41110]
===
match
---
operator: = [13887,13888]
operator: = [13887,13888]
===
match
---
trailer [90647,90663]
trailer [90599,90615]
===
match
---
operator: , [58316,58317]
operator: , [58268,58269]
===
match
---
trailer [37994,37999]
trailer [37946,37951]
===
match
---
comp_if [44873,44900]
comp_if [44825,44852]
===
match
---
name: dag_id [74367,74373]
name: dag_id [74319,74325]
===
match
---
name: new_start [25477,25486]
name: new_start [25429,25438]
===
match
---
operator: = [68428,68429]
operator: = [68380,68381]
===
match
---
atom_expr [28724,28762]
atom_expr [28676,28714]
===
match
---
string: 'core' [10928,10934]
string: 'core' [10928,10934]
===
match
---
import_as_names [1385,1453]
import_as_names [1385,1453]
===
match
---
name: self [65795,65799]
name: self [65747,65751]
===
match
---
atom_expr [93212,93532]
atom_expr [93164,93484]
===
match
---
operator: = [79447,79448]
operator: = [79399,79400]
===
match
---
atom_expr [82030,82046]
atom_expr [81982,81998]
===
match
---
funcdef [89621,90215]
funcdef [89573,90167]
===
match
---
name: stats [2234,2239]
name: stats [2234,2239]
===
match
---
trailer [44468,44482]
trailer [44420,44434]
===
match
---
atom_expr [77098,77133]
atom_expr [77050,77085]
===
match
---
operator: = [32188,32189]
operator: = [32140,32141]
===
match
---
name: default_view [15300,15312]
name: default_view [15300,15312]
===
match
---
expr_stmt [71252,71811]
expr_stmt [71204,71763]
===
match
---
comp_op [16436,16442]
comp_op [16436,16442]
===
match
---
annassign [97925,97941]
annassign [97877,97893]
===
match
---
name: end_date [27001,27009]
name: end_date [26953,26961]
===
match
---
operator: = [71551,71552]
operator: = [71503,71504]
===
match
---
name: DagRun [48168,48174]
name: DagRun [48120,48126]
===
match
---
name: dag_hash [72445,72453]
name: dag_hash [72397,72405]
===
match
---
operator: = [64906,64907]
operator: = [64858,64859]
===
match
---
trailer [88087,88147]
trailer [88039,88099]
===
match
---
name: self [25683,25687]
name: self [25635,25639]
===
match
---
trailer [25354,25372]
trailer [25306,25324]
===
match
---
atom_expr [45565,45621]
atom_expr [45517,45573]
===
match
---
operator: , [82885,82886]
operator: , [82837,82838]
===
match
---
name: query [3440,3445]
name: query [3440,3445]
===
match
---
suite [88604,88693]
suite [88556,88645]
===
match
---
name: ti_list [59250,59257]
name: ti_list [59202,59209]
===
match
---
suite [44970,47400]
suite [44922,47352]
===
match
---
name: local_executor [71006,71020]
name: local_executor [70958,70972]
===
match
---
name: timezone [21101,21109]
name: timezone [21101,21109]
===
match
---
name: downstream_task_id [42788,42806]
name: downstream_task_id [42740,42758]
===
match
---
suite [13575,13622]
suite [13575,13622]
===
match
---
argument [52394,52409]
argument [52346,52361]
===
match
---
name: dag [75988,75991]
name: dag [75940,75943]
===
match
---
name: str [13835,13838]
name: str [13835,13838]
===
match
---
name: self [17643,17647]
name: self [17643,17647]
===
match
---
fstring_expr [55563,55575]
fstring_expr [55515,55527]
===
match
---
atom_expr [32830,32862]
atom_expr [32782,32814]
===
match
---
funcdef [60573,60927]
funcdef [60525,60879]
===
match
---
name: id [60101,60103]
name: id [60053,60055]
===
match
---
name: session [29578,29585]
name: session [29530,29537]
===
match
---
name: get_downstream [66884,66898]
name: get_downstream [66836,66850]
===
match
---
trailer [77855,77857]
trailer [77807,77809]
===
match
---
suite [35583,36920]
suite [35535,36872]
===
match
---
trailer [57821,57953]
trailer [57773,57905]
===
match
---
name: tags [79202,79206]
name: tags [79154,79158]
===
match
---
simple_stmt [33123,33141]
simple_stmt [33075,33093]
===
match
---
name: stacklevel [40379,40389]
name: stacklevel [40331,40341]
===
match
---
name: full_filepath [29985,29998]
name: full_filepath [29937,29950]
===
match
---
operator: = [87631,87632]
operator: = [87583,87584]
===
match
---
return_stmt [29113,29129]
return_stmt [29065,29081]
===
match
---
name: keys [64535,64539]
name: keys [64487,64491]
===
match
---
parameters [74991,75035]
parameters [74943,74987]
===
match
---
name: _context_managed_dag [98138,98158]
name: _context_managed_dag [98090,98110]
===
match
---
name: models [1933,1939]
name: models [1933,1939]
===
match
---
string: """         Return list of all owners found in DAG tasks.          :return: Comma separated list of owners in DAG tasks         :rtype: str         """ [32545,32696]
string: """         Return list of all owners found in DAG tasks.          :return: Comma separated list of owners in DAG tasks         :rtype: str         """ [32497,32648]
===
match
---
name: session [33795,33802]
name: session [33747,33754]
===
match
---
simple_stmt [37267,37287]
simple_stmt [37219,37239]
===
match
---
return_stmt [17206,17218]
return_stmt [17206,17218]
===
match
---
name: self [62111,62115]
name: self [62063,62067]
===
match
---
simple_stmt [90996,91067]
simple_stmt [90948,91019]
===
match
---
simple_stmt [53293,53315]
simple_stmt [53245,53267]
===
match
---
name: count [57692,57697]
name: count [57644,57649]
===
match
---
trailer [46719,46721]
trailer [46671,46673]
===
match
---
name: dag_id [76509,76515]
name: dag_id [76461,76467]
===
match
---
name: session [52394,52401]
name: session [52346,52353]
===
match
---
name: dttm [21079,21083]
name: dttm [21079,21083]
===
match
---
atom_expr [88645,88692]
atom_expr [88597,88644]
===
match
---
if_stmt [60175,60313]
if_stmt [60127,60265]
===
match
---
not_test [67266,67285]
not_test [67218,67237]
===
match
---
name: str [10133,10136]
name: str [10133,10136]
===
match
---
operator: <= [93402,93404]
operator: <= [93354,93356]
===
match
---
name: name [79283,79287]
name: name [79235,79239]
===
match
---
name: filter [54952,54958]
name: filter [54904,54910]
===
match
---
name: is_paused [89995,90004]
name: is_paused [89947,89956]
===
match
---
name: AttributeError [31803,31817]
name: AttributeError [31755,31769]
===
match
---
simple_stmt [946,987]
simple_stmt [946,987]
===
match
---
tfpdef [38202,38223]
tfpdef [38154,38175]
===
match
---
trailer [55567,55574]
trailer [55519,55526]
===
match
---
trailer [36482,36484]
trailer [36434,36436]
===
match
---
string: 'max_active_tasks_per_dag' [10856,10882]
string: 'max_active_tasks_per_dag' [10856,10882]
===
match
---
param [30810,30815]
param [30762,30767]
===
match
---
trailer [11331,11355]
trailer [11331,11355]
===
match
---
name: qry [33149,33152]
name: qry [33101,33104]
===
match
---
arglist [76255,76290]
arglist [76207,76242]
===
match
---
name: dag_id [82756,82762]
name: dag_id [82708,82714]
===
match
---
funcdef [32082,32328]
funcdef [32034,32280]
===
match
---
simple_stmt [83499,83566]
simple_stmt [83451,83518]
===
match
---
atom_expr [77650,77662]
atom_expr [77602,77614]
===
match
---
operator: , [52289,52290]
operator: , [52241,52242]
===
match
---
operator: = [16508,16509]
operator: = [16508,16509]
===
match
---
name: naive [22081,22086]
name: naive [22057,22062]
===
match
---
atom_expr [13308,13339]
atom_expr [13308,13339]
===
match
---
fstring [55542,55576]
fstring [55494,55528]
===
match
---
atom_expr [72042,72063]
atom_expr [71994,72015]
===
match
---
name: orientation [15587,15598]
name: orientation [15587,15598]
===
match
---
atom [3066,3090]
atom [3066,3090]
===
match
---
atom_expr [21311,21341]
atom_expr [21287,21317]
===
match
---
decorated [89014,89174]
decorated [88966,89126]
===
match
---
trailer [83286,83292]
trailer [83238,83244]
===
match
---
name: session [81110,81117]
name: session [81062,81069]
===
match
---
param [10671,10715]
param [10671,10715]
===
match
---
name: task_end_dates [27207,27221]
name: task_end_dates [27159,27173]
===
match
---
name: decorators [67025,67035]
name: decorators [66977,66987]
===
match
---
atom_expr [41407,41418]
atom_expr [41359,41370]
===
match
---
trailer [95824,95826]
trailer [95776,95778]
===
match
---
name: subdag_task_groups [64516,64534]
name: subdag_task_groups [64468,64486]
===
match
---
trailer [64940,64962]
trailer [64892,64914]
===
match
---
name: self [90606,90610]
name: self [90558,90562]
===
match
---
name: filepath [32086,32094]
name: filepath [32038,32046]
===
match
---
trailer [77970,77977]
trailer [77922,77929]
===
match
---
comparison [38847,38875]
comparison [38799,38827]
===
match
---
operator: , [37341,37342]
operator: , [37293,37294]
===
match
---
suite [62458,62754]
suite [62410,62706]
===
match
---
name: session [89492,89499]
name: session [89444,89451]
===
match
---
name: cls [93321,93324]
name: cls [93273,93276]
===
match
---
comparison [34218,34248]
comparison [34170,34200]
===
match
---
name: next_run_date [26834,26847]
name: next_run_date [26786,26799]
===
match
---
string: 'dag_orientation' [11198,11215]
string: 'dag_orientation' [11198,11215]
===
match
---
simple_stmt [87188,87218]
simple_stmt [87140,87170]
===
match
---
atom_expr [62151,62202]
atom_expr [62103,62154]
===
match
---
not_test [47257,47268]
not_test [47209,47220]
===
match
---
argument [19701,19708]
argument [19701,19708]
===
match
---
name: f_kwargs [96921,96929]
name: f_kwargs [96873,96881]
===
match
---
atom_expr [78161,78182]
atom_expr [78113,78134]
===
match
---
decorated [75363,79960]
decorated [75315,79912]
===
match
---
atom_expr [37218,37257]
atom_expr [37170,37209]
===
match
---
simple_stmt [27434,27446]
simple_stmt [27386,27398]
===
match
---
name: schedule_interval [14454,14471]
name: schedule_interval [14454,14471]
===
match
---
name: _task_group [62063,62074]
name: _task_group [62015,62026]
===
match
---
atom_expr [43177,43196]
atom_expr [43129,43148]
===
match
---
name: query [51500,51505]
name: query [51452,51457]
===
match
---
atom [62232,62299]
atom [62184,62251]
===
match
---
name: max_active_tasks [12759,12775]
name: max_active_tasks [12759,12775]
===
match
---
return_stmt [34631,34658]
return_stmt [34583,34610]
===
match
---
trailer [37738,37752]
trailer [37690,37704]
===
match
---
string: ", " [32712,32716]
string: ", " [32664,32668]
===
match
---
param [27505,27516]
param [27457,27468]
===
match
---
simple_stmt [15772,15819]
simple_stmt [15772,15819]
===
match
---
comparison [77741,77786]
comparison [77693,77738]
===
match
---
operator: = [29452,29453]
operator: = [29404,29405]
===
match
---
atom_expr [65831,65843]
atom_expr [65783,65795]
===
match
---
comparison [80924,80948]
comparison [80876,80900]
===
match
---
suite [42321,42379]
suite [42273,42331]
===
match
---
operator: , [56148,56149]
operator: , [56100,56101]
===
match
---
name: self [37120,37124]
name: self [37072,37076]
===
match
---
simple_stmt [2221,2253]
simple_stmt [2221,2253]
===
match
---
param [16937,16942]
param [16937,16942]
===
match
---
operator: = [60412,60413]
operator: = [60364,60365]
===
match
---
name: args [60911,60915]
name: args [60863,60867]
===
match
---
simple_stmt [60322,60376]
simple_stmt [60274,60328]
===
match
---
atom_expr [80448,80497]
atom_expr [80400,80449]
===
match
---
if_stmt [24803,24896]
if_stmt [24755,24848]
===
match
---
argument [10309,10315]
argument [10309,10315]
===
match
---
expr_stmt [62326,62399]
expr_stmt [62278,62351]
===
match
---
simple_stmt [17560,17595]
simple_stmt [17560,17595]
===
match
---
suite [66867,66909]
suite [66819,66861]
===
match
---
param [29445,29458]
param [29397,29410]
===
match
---
atom_expr [98100,98124]
atom_expr [98052,98076]
===
match
---
tfpdef [75427,75450]
tfpdef [75379,75402]
===
match
---
atom_expr [13561,13574]
atom_expr [13561,13574]
===
match
---
trailer [28217,28228]
trailer [28169,28180]
===
match
---
name: session [37366,37373]
name: session [37318,37325]
===
match
---
trailer [76400,76411]
trailer [76352,76363]
===
match
---
if_stmt [43851,44345]
if_stmt [43803,44297]
===
match
---
operator: = [25294,25295]
operator: = [25246,25247]
===
match
---
operator: = [63214,63215]
operator: = [63166,63167]
===
match
---
name: int [31221,31224]
name: int [31173,31176]
===
match
---
import_from [2465,2511]
import_from [2465,2511]
===
match
---
name: Column [87566,87572]
name: Column [87518,87524]
===
match
---
atom_expr [78854,79032]
atom_expr [78806,78984]
===
match
---
name: dag [62091,62094]
name: dag [62043,62046]
===
match
---
name: Optional [11323,11331]
name: Optional [11323,11331]
===
match
---
operator: == [40014,40016]
operator: == [39966,39968]
===
match
---
operator: , [10609,10610]
operator: , [10609,10610]
===
match
---
name: task_dict [64622,64631]
name: task_dict [64574,64583]
===
match
---
name: task [45578,45582]
name: task [45530,45534]
===
match
---
simple_stmt [32705,32753]
simple_stmt [32657,32705]
===
match
---
atom_expr [68077,68090]
atom_expr [68029,68042]
===
match
---
parameters [66632,66638]
parameters [66584,66590]
===
match
---
operator: , [12667,12668]
operator: , [12667,12668]
===
match
---
name: getint [10921,10927]
name: getint [10921,10927]
===
match
---
if_stmt [68116,68613]
if_stmt [68068,68565]
===
match
---
name: pop_context_managed_dag [18099,18122]
name: pop_context_managed_dag [18099,18122]
===
match
---
name: filter [82827,82833]
name: filter [82779,82785]
===
match
---
import_from [910,945]
import_from [910,945]
===
match
---
expr_stmt [76229,76297]
expr_stmt [76181,76249]
===
match
---
suite [65374,65418]
suite [65326,65370]
===
match
---
string: """         Add a list of tasks to the DAG          :param tasks: a lit of tasks you want to add         :type tasks: list of tasks         """ [68701,68844]
string: """         Add a list of tasks to the DAG          :param tasks: a lit of tasks you want to add         :type tasks: list of tasks         """ [68653,68796]
===
match
---
simple_stmt [51555,51603]
simple_stmt [51507,51555]
===
match
---
param [84582,84604]
param [84534,84556]
===
match
---
name: DagContext [18088,18098]
name: DagContext [18088,18098]
===
match
---
operator: @ [30478,30479]
operator: @ [30430,30431]
===
match
---
name: self [57889,57893]
name: self [57841,57845]
===
match
---
trailer [66188,66195]
trailer [66140,66147]
===
match
---
string: 'end_date' [13875,13885]
string: 'end_date' [13875,13885]
===
match
---
atom_expr [19542,19556]
atom_expr [19542,19556]
===
match
---
trailer [79065,79079]
trailer [79017,79031]
===
match
---
name: task_id [51575,51582]
name: task_id [51527,51534]
===
match
---
trailer [79868,79870]
trailer [79820,79822]
===
match
---
simple_stmt [86059,86138]
simple_stmt [86011,86090]
===
match
---
trailer [90525,90529]
trailer [90477,90481]
===
match
---
return_stmt [31940,31974]
return_stmt [31892,31926]
===
match
---
param [16931,16936]
param [16931,16936]
===
match
---
suite [36363,36920]
suite [36315,36872]
===
match
---
operator: = [51926,51927]
operator: = [51878,51879]
===
match
---
trailer [36683,36703]
trailer [36635,36655]
===
match
---
atom_expr [74100,74148]
atom_expr [74052,74100]
===
match
---
atom_expr [51442,51458]
atom_expr [51394,51410]
===
match
---
atom_expr [28212,28249]
atom_expr [28164,28201]
===
match
---
parameters [31776,31787]
parameters [31728,31739]
===
match
---
name: in_ [81036,81039]
name: in_ [80988,80991]
===
match
---
trailer [82688,82722]
trailer [82640,82674]
===
match
---
operator: , [69112,69113]
operator: , [69064,69065]
===
match
---
fstring_string: , but get  [15289,15299]
fstring_string: , but get  [15289,15299]
===
match
---
name: models [1839,1845]
name: models [1839,1845]
===
match
---
comp_op [79389,79395]
comp_op [79341,79347]
===
match
---
trailer [38082,38089]
trailer [38034,38041]
===
match
---
simple_stmt [80030,80237]
simple_stmt [79982,80189]
===
match
---
string: 'extensions' [41714,41726]
string: 'extensions' [41666,41678]
===
match
---
name: task_start_dates [25882,25898]
name: task_start_dates [25834,25850]
===
match
---
operator: = [15636,15637]
operator: = [15636,15637]
===
match
---
import_from [946,986]
import_from [946,986]
===
match
---
suite [60253,60313]
suite [60205,60265]
===
match
---
trailer [80535,80548]
trailer [80487,80500]
===
match
---
name: self [32095,32099]
name: self [32047,32051]
===
match
---
simple_stmt [12495,12683]
simple_stmt [12495,12683]
===
match
---
simple_stmt [55890,56924]
simple_stmt [55842,56876]
===
match
---
name: union [55900,55905]
name: union [55852,55857]
===
match
---
operator: , [43266,43267]
operator: , [43218,43219]
===
match
---
atom [62342,62399]
atom [62294,62351]
===
match
---
name: naive [21331,21336]
name: naive [21307,21312]
===
match
---
import_from [1017,1202]
import_from [1017,1202]
===
match
---
string: "\n" [57507,57511]
string: "\n" [57459,57463]
===
match
---
name: ACTION_CAN_READ [18724,18739]
name: ACTION_CAN_READ [18724,18739]
===
match
---
operator: = [58636,58637]
operator: = [58588,58589]
===
match
---
trailer [21267,21276]
trailer [21249,21258]
===
match
---
atom_expr [79347,79355]
atom_expr [79299,79307]
===
match
---
name: DAG [30855,30858]
name: DAG [30807,30810]
===
match
---
param [19792,19796]
param [19792,19796]
===
match
---
parameters [22834,22920]
parameters [22786,22872]
===
match
---
trailer [10492,10519]
trailer [10492,10519]
===
match
---
trailer [14738,14743]
trailer [14738,14743]
===
match
---
name: do_it [57401,57406]
name: do_it [57353,57358]
===
match
---
atom_expr [78139,78158]
atom_expr [78091,78110]
===
match
---
name: include_downstream [51870,51888]
name: include_downstream [51822,51840]
===
match
---
trailer [89147,89154]
trailer [89099,89106]
===
match
---
comparison [94238,94279]
comparison [94190,94231]
===
match
---
name: make_naive [21986,21996]
name: make_naive [21962,21972]
===
match
---
string: 'params' [60235,60243]
string: 'params' [60187,60195]
===
match
---
suite [65661,66080]
suite [65613,66032]
===
match
---
atom_expr [56948,56980]
atom_expr [56900,56932]
===
match
---
name: include_externally_triggered [29328,29356]
name: include_externally_triggered [29280,29308]
===
match
---
operator: { [76326,76327]
operator: { [76278,76279]
===
match
---
operator: = [13178,13179]
operator: = [13178,13179]
===
match
---
atom_expr [25902,25914]
atom_expr [25854,25866]
===
match
---
funcdef [95363,97029]
funcdef [95315,96981]
===
match
---
or_test [43537,43566]
or_test [43489,43518]
===
match
---
name: states [82994,83000]
name: states [82946,82952]
===
match
---
operator: = [78492,78493]
operator: = [78444,78445]
===
match
---
dotted_name [2574,2595]
dotted_name [2574,2595]
===
match
---
param [29731,29735]
param [29683,29687]
===
match
---
for_stmt [63391,64007]
for_stmt [63343,63959]
===
match
---
name: self [60890,60894]
name: self [60842,60846]
===
match
---
operator: , [77133,77134]
operator: , [77085,77086]
===
match
---
expr_stmt [74091,74148]
expr_stmt [74043,74100]
===
match
---
suite [34747,35482]
suite [34699,35434]
===
match
---
name: paused_dag_ids [90169,90183]
name: paused_dag_ids [90121,90135]
===
match
---
name: self [28817,28821]
name: self [28769,28773]
===
match
---
operator: = [52401,52402]
operator: = [52353,52354]
===
match
---
simple_stmt [29262,29396]
simple_stmt [29214,29348]
===
match
---
expr_stmt [34181,34249]
expr_stmt [34133,34201]
===
match
---
if_stmt [25594,25773]
if_stmt [25546,25725]
===
match
---
name: edge_info [16095,16104]
name: edge_info [16095,16104]
===
match
---
simple_stmt [44837,44902]
simple_stmt [44789,44854]
===
match
---
name: DagRunType [77259,77269]
name: DagRunType [77211,77221]
===
match
---
arglist [57686,57714]
arglist [57638,57666]
===
match
---
name: self [35109,35113]
name: self [35061,35065]
===
match
---
string: 'pickle_len' [65815,65827]
string: 'pickle_len' [65767,65779]
===
match
---
name: self [13164,13168]
name: self [13164,13168]
===
match
---
string: "Setting next_dagrun for %s to %s" [94679,94713]
string: "Setting next_dagrun for %s to %s" [94631,94665]
===
match
---
funcdef [65256,65634]
funcdef [65208,65586]
===
match
---
operator: { [59249,59250]
operator: { [59201,59202]
===
match
---
atom_expr [66951,66968]
atom_expr [66903,66920]
===
match
---
name: self [15623,15627]
name: self [15623,15627]
===
match
---
name: self [88922,88926]
name: self [88874,88878]
===
match
---
name: orm_dag [79297,79304]
name: orm_dag [79249,79256]
===
match
---
name: tis [55890,55893]
name: tis [55842,55845]
===
match
---
param [72131,72144]
param [72083,72096]
===
match
---
name: also_include [62409,62421]
name: also_include [62361,62373]
===
match
---
atom_expr [76117,76159]
atom_expr [76069,76111]
===
match
---
trailer [79206,79213]
trailer [79158,79165]
===
match
---
param [42908,42920]
param [42860,42872]
===
match
---
name: run_id [38652,38658]
name: run_id [38604,38610]
===
match
---
operator: = [86274,86275]
operator: = [86226,86227]
===
match
---
name: start_date [58509,58519]
name: start_date [58461,58471]
===
match
---
atom_expr [90500,90517]
atom_expr [90452,90469]
===
match
---
trailer [37144,37152]
trailer [37096,37104]
===
match
---
operator: <= [25404,25406]
operator: <= [25356,25358]
===
match
---
name: dag_id [88927,88933]
name: dag_id [88879,88885]
===
match
---
string: "Creating ORM DAG for %s" [76748,76773]
string: "Creating ORM DAG for %s" [76700,76725]
===
match
---
comparison [23458,23488]
comparison [23410,23440]
===
match
---
trailer [89985,90026]
trailer [89937,89978]
===
match
---
trailer [31723,31733]
trailer [31675,31685]
===
match
---
operator: , [73968,73969]
operator: , [73920,73921]
===
match
---
name: self [32800,32804]
name: self [32752,32756]
===
match
---
trailer [14862,14870]
trailer [14862,14870]
===
match
---
trailer [3439,3445]
trailer [3439,3445]
===
match
---
name: clear_task_instances [2159,2179]
name: clear_task_instances [2159,2179]
===
match
---
funcdef [71835,72064]
funcdef [71787,72016]
===
match
---
name: Dict [11497,11501]
name: Dict [11497,11501]
===
match
---
raise_stmt [65586,65633]
raise_stmt [65538,65585]
===
match
---
fstring_start: f" [68310,68312]
fstring_start: f" [68262,68264]
===
match
---
name: query [91182,91187]
name: query [91134,91139]
===
match
---
if_stmt [83574,84514]
if_stmt [83526,84466]
===
match
---
simple_stmt [61154,61849]
simple_stmt [61106,61801]
===
match
---
param [20295,20300]
param [20295,20300]
===
match
---
name: frozenset [48761,48770]
name: frozenset [48713,48722]
===
match
---
atom_expr [20482,20515]
atom_expr [20482,20515]
===
match
---
operator: - [97122,97123]
operator: - [97074,97075]
===
match
---
suite [80949,80969]
suite [80901,80921]
===
match
---
operator: = [47864,47865]
operator: = [47816,47817]
===
match
---
expr_stmt [21299,21341]
expr_stmt [21275,21317]
===
match
---
if_stmt [51612,52657]
if_stmt [51564,52609]
===
match
---
name: dag [78232,78235]
name: dag [78184,78187]
===
match
---
simple_stmt [18290,18572]
simple_stmt [18290,18572]
===
match
---
dotted_name [71126,71159]
dotted_name [71078,71111]
===
match
---
name: state [83053,83058]
name: state [83005,83010]
===
match
---
suite [30823,30903]
suite [30775,30855]
===
match
---
trailer [37241,37256]
trailer [37193,37208]
===
match
---
trailer [78789,78840]
trailer [78741,78792]
===
match
---
trailer [45758,45772]
trailer [45710,45724]
===
match
---
atom_expr [86251,86281]
atom_expr [86203,86233]
===
match
---
trailer [66329,66336]
trailer [66281,66288]
===
match
---
name: dateutil [1269,1277]
name: dateutil [1269,1277]
===
match
---
atom_expr [93559,93637]
atom_expr [93511,93589]
===
match
---
operator: <= [26329,26331]
operator: <= [26281,26283]
===
match
---
name: dry_run [58852,58859]
name: dry_run [58804,58811]
===
match
---
trailer [48019,48056]
trailer [47971,48008]
===
match
---
trailer [16708,16738]
trailer [16708,16738]
===
match
---
name: end_date [14108,14116]
name: end_date [14108,14116]
===
match
---
comparison [19031,19071]
comparison [19031,19071]
===
match
---
testlist_comp [2989,3042]
testlist_comp [2989,3042]
===
match
---
trailer [32460,32465]
trailer [32412,32417]
===
match
---
name: str [47479,47482]
name: str [47431,47434]
===
match
---
atom_expr [92036,92075]
atom_expr [91988,92027]
===
match
---
name: dag_id [82766,82772]
name: dag_id [82718,82724]
===
match
---
trailer [78073,78081]
trailer [78025,78033]
===
match
---
name: date_last_automated_dagrun [23666,23692]
name: date_last_automated_dagrun [23618,23644]
===
match
---
name: max_active_runs [94581,94596]
name: max_active_runs [94533,94548]
===
match
---
operator: , [38273,38274]
operator: , [38225,38226]
===
match
---
trailer [79532,79545]
trailer [79484,79497]
===
match
---
suite [19072,19336]
suite [19072,19336]
===
match
---
atom_expr [38027,38045]
atom_expr [37979,37997]
===
match
---
suite [79247,79595]
suite [79199,79547]
===
match
---
name: _schedule_interval [35463,35481]
name: _schedule_interval [35415,35433]
===
match
---
simple_stmt [44044,44085]
simple_stmt [43996,44037]
===
match
---
name: TaskGroup [2862,2871]
name: TaskGroup [2862,2871]
===
match
---
name: only_failed [58211,58222]
name: only_failed [58163,58174]
===
match
---
simple_stmt [71820,71830]
simple_stmt [71772,71782]
===
match
---
operator: = [51270,51271]
operator: = [51222,51223]
===
match
---
suite [82804,82901]
suite [82756,82853]
===
match
---
name: _max_active_tasks [30447,30464]
name: _max_active_tasks [30399,30416]
===
match
---
dotted_name [1968,1991]
dotted_name [1968,1991]
===
match
---
atom_expr [78715,78735]
atom_expr [78667,78687]
===
match
---
atom_expr [43953,43993]
atom_expr [43905,43945]
===
match
---
name: dags [75939,75943]
name: dags [75891,75895]
===
match
---
decorated [31172,31267]
decorated [31124,31219]
===
match
---
trailer [20214,20219]
trailer [20214,20219]
===
match
---
name: following [29012,29021]
name: following [28964,28973]
===
match
---
name: state [43741,43746]
name: state [43693,43698]
===
match
---
argument [36640,36655]
argument [36592,36607]
===
match
---
name: dag [65555,65558]
name: dag [65507,65510]
===
match
---
if_stmt [25630,25711]
if_stmt [25582,25663]
===
match
---
name: jinja_env_options [42073,42090]
name: jinja_env_options [42025,42042]
===
match
---
suite [35391,35448]
suite [35343,35400]
===
match
---
atom_expr [98134,98158]
atom_expr [98086,98110]
===
match
---
trailer [28504,28523]
trailer [28456,28475]
===
match
---
string: '@once' [25037,25044]
string: '@once' [24989,24996]
===
match
---
name: str [48754,48757]
name: str [48706,48709]
===
match
---
string: 'last_loaded' [10067,10080]
string: 'last_loaded' [10067,10080]
===
match
---
trailer [36380,36384]
trailer [36332,36336]
===
match
---
atom_expr [48517,48530]
atom_expr [48469,48482]
===
match
---
parameters [95092,95105]
parameters [95044,95057]
===
match
---
operator: = [35562,35563]
operator: = [35514,35515]
===
match
---
decorator [81159,81173]
decorator [81111,81125]
===
match
---
name: task_id [45583,45590]
name: task_id [45535,45542]
===
match
---
name: doc_md [96267,96273]
name: doc_md [96219,96225]
===
match
---
name: all [77852,77855]
name: all [77804,77807]
===
match
---
funcdef [89358,89577]
funcdef [89310,89529]
===
match
---
arglist [11185,11215]
arglist [11185,11215]
===
match
---
name: self [62354,62358]
name: self [62306,62310]
===
match
---
operator: = [32260,32261]
operator: = [32212,32213]
===
match
---
suite [61145,65154]
suite [61097,65106]
===
match
---
name: self [38142,38146]
name: self [38094,38098]
===
match
---
name: self [14409,14413]
name: self [14409,14413]
===
match
---
name: traceback [884,893]
name: traceback [884,893]
===
match
---
name: filter_query [91109,91121]
name: filter_query [91061,91073]
===
match
---
decorated [35487,36920]
decorated [35439,36872]
===
match
---
name: query [91892,91897]
name: query [91844,91849]
===
match
---
return_stmt [65387,65417]
return_stmt [65339,65369]
===
match
---
simple_stmt [3092,3143]
simple_stmt [3092,3143]
===
match
---
name: _tb [18074,18077]
name: _tb [18074,18077]
===
match
---
expr_stmt [22338,22388]
expr_stmt [22314,22364]
===
match
---
simple_stmt [86781,86814]
simple_stmt [86733,86766]
===
match
---
argument [79470,79487]
argument [79422,79439]
===
match
---
name: get_tis [48585,48592]
name: get_tis [48537,48544]
===
match
---
name: timezone [13397,13405]
name: timezone [13397,13405]
===
match
---
trailer [94580,94596]
trailer [94532,94548]
===
match
---
funcdef [20272,21541]
funcdef [20272,21517]
===
match
---
name: croniter [1239,1247]
name: croniter [1239,1247]
===
match
---
if_stmt [52751,52824]
if_stmt [52703,52776]
===
match
---
name: State [77666,77671]
name: State [77618,77623]
===
match
---
string: "TaskGroup" [32018,32029]
string: "TaskGroup" [31970,31981]
===
match
---
name: str [89658,89661]
name: str [89610,89613]
===
match
---
atom_expr [76500,76531]
atom_expr [76452,76483]
===
match
---
name: ScheduleInterval [34729,34745]
name: ScheduleInterval [34681,34697]
===
match
---
string: """         Runs the DAG.          :param start_date: the start date of the range to run         :type start_date: datetime.datetime         :param end_date: the end date of the range to run         :type end_date: datetime.datetime         :param mark_success: True to mark jobs as succeeded without running them         :type mark_success: bool         :param local: True to run the tasks using the LocalExecutor         :type local: bool         :param executor: The executor instance to run the tasks         :type executor: airflow.executor.base_executor.BaseExecutor         :param donot_pickle: True to avoid pickling DAG object and send to workers         :type donot_pickle: bool         :param ignore_task_deps: True to skip upstream tasks         :type ignore_task_deps: bool         :param ignore_first_depends_on_past: True to ignore depends_on_past             dependencies for the first set of tasks only         :type ignore_first_depends_on_past: bool         :param pool: Resource pool to use         :type pool: str         :param delay_on_limit_secs: Time in seconds to wait before next attempt to run             dag run when max_active_runs limit has been reached         :type delay_on_limit_secs: float         :param verbose: Make logging output more verbose         :type verbose: bool         :param conf: user defined dictionary passed from CLI         :type conf: dict         :param rerun_failed_tasks:         :type: bool         :param run_backwards:         :type: bool          """ [69361,70876]
string: """         Runs the DAG.          :param start_date: the start date of the range to run         :type start_date: datetime.datetime         :param end_date: the end date of the range to run         :type end_date: datetime.datetime         :param mark_success: True to mark jobs as succeeded without running them         :type mark_success: bool         :param local: True to run the tasks using the LocalExecutor         :type local: bool         :param executor: The executor instance to run the tasks         :type executor: airflow.executor.base_executor.BaseExecutor         :param donot_pickle: True to avoid pickling DAG object and send to workers         :type donot_pickle: bool         :param ignore_task_deps: True to skip upstream tasks         :type ignore_task_deps: bool         :param ignore_first_depends_on_past: True to ignore depends_on_past             dependencies for the first set of tasks only         :type ignore_first_depends_on_past: bool         :param pool: Resource pool to use         :type pool: str         :param delay_on_limit_secs: Time in seconds to wait before next attempt to run             dag run when max_active_runs limit has been reached         :type delay_on_limit_secs: float         :param verbose: Make logging output more verbose         :type verbose: bool         :param conf: user defined dictionary passed from CLI         :type conf: dict         :param rerun_failed_tasks:         :type: bool         :param run_backwards:         :type: bool          """ [69313,70828]
===
match
---
operator: = [87464,87465]
operator: = [87416,87417]
===
match
---
name: t [62439,62440]
name: t [62391,62392]
===
match
---
argument [93606,93636]
argument [93558,93588]
===
match
---
operator: , [10714,10715]
operator: , [10714,10715]
===
match
---
name: owners [78399,78405]
name: owners [78351,78357]
===
match
---
operator: = [96786,96787]
operator: = [96738,96739]
===
match
---
raise_stmt [47286,47363]
raise_stmt [47238,47315]
===
match
---
trailer [13504,13511]
trailer [13504,13511]
===
match
---
name: DAG [14739,14742]
name: DAG [14739,14742]
===
match
---
name: clear [55950,55955]
name: clear [55902,55907]
===
match
---
name: t [27225,27226]
name: t [27177,27178]
===
match
---
atom_expr [28500,28541]
atom_expr [28452,28493]
===
match
---
name: dag_id [17347,17353]
name: dag_id [17347,17353]
===
match
---
argument [45577,45620]
argument [45529,45572]
===
match
---
operator: = [48592,48593]
operator: = [48544,48545]
===
match
---
name: do_it [57782,57787]
name: do_it [57734,57739]
===
match
---
operator: , [25447,25448]
operator: , [25399,25400]
===
match
---
name: id [66592,66594]
name: id [66544,66546]
===
match
---
name: update [91225,91231]
name: update [91177,91183]
===
match
---
atom_expr [19629,19759]
atom_expr [19629,19759]
===
match
---
string: "You are about to delete these {count} tasks:\n{ti_list}\n\nAre you sure? (yes/no): " [57579,57664]
string: "You are about to delete these {count} tasks:\n{ti_list}\n\nAre you sure? (yes/no): " [57531,57616]
===
match
---
simple_stmt [82177,82661]
simple_stmt [82129,82613]
===
match
---
atom_expr [65885,65902]
atom_expr [65837,65854]
===
match
---
atom_expr [20732,20745]
atom_expr [20732,20745]
===
match
---
atom_expr [37139,37152]
atom_expr [37091,37104]
===
match
---
atom_expr [25745,25760]
atom_expr [25697,25712]
===
match
---
name: baseoperator [1846,1858]
name: baseoperator [1846,1858]
===
match
---
string: '.' [90648,90651]
string: '.' [90600,90603]
===
match
---
fstring_end: " [55575,55576]
fstring_end: " [55527,55528]
===
match
---
string: """         Returns the dag run for a given execution date or run_id if it exists, otherwise         none.          :param execution_date: The execution date of the DagRun to find.         :param run_id: The run_id of the DagRun to find.         :param session:         :return: The DagRun if found, otherwise None.         """ [38290,38617]
string: """         Returns the dag run for a given execution date or run_id if it exists, otherwise         none.          :param execution_date: The execution date of the DagRun to find.         :param run_id: The run_id of the DagRun to find.         :param session:         :return: The DagRun if found, otherwise None.         """ [38242,38569]
===
match
---
name: self [11837,11841]
name: self [11837,11841]
===
match
---
atom_expr [66543,66559]
atom_expr [66495,66511]
===
match
---
simple_stmt [10093,10146]
simple_stmt [10093,10146]
===
match
---
trailer [77527,77559]
trailer [77479,77511]
===
match
---
operator: , [48575,48576]
operator: , [48527,48528]
===
match
---
operator: , [30294,30295]
operator: , [30246,30247]
===
match
---
operator: = [59625,59626]
operator: = [59577,59578]
===
match
---
name: tis [57218,57221]
name: tis [57170,57173]
===
match
---
param [10187,10199]
param [10187,10199]
===
match
---
name: Optional [98539,98547]
name: Optional [98491,98499]
===
match
---
operator: = [44961,44962]
operator: = [44913,44914]
===
match
---
name: acyclic [46944,46951]
name: acyclic [46896,46903]
===
match
---
operator: , [47778,47779]
operator: , [47730,47731]
===
match
---
operator: , [57893,57894]
operator: , [57845,57846]
===
match
---
name: is_paused [90714,90723]
name: is_paused [90666,90675]
===
match
---
name: cls [83485,83488]
name: cls [83437,83440]
===
match
---
name: run_id [74387,74393]
name: run_id [74339,74345]
===
match
---
trailer [68182,68196]
trailer [68134,68148]
===
match
---
name: dttm [20655,20659]
name: dttm [20655,20659]
===
match
---
atom_expr [78391,78405]
atom_expr [78343,78357]
===
match
---
name: dag [98161,98164]
name: dag [98113,98116]
===
match
---
expr_stmt [63245,63295]
expr_stmt [63197,63247]
===
match
---
raise_stmt [73999,74078]
raise_stmt [73951,74030]
===
match
---
number: 2 [30319,30320]
number: 2 [30271,30272]
===
match
---
string: 'sla_miss_callback' [84135,84154]
string: 'sla_miss_callback' [84087,84106]
===
match
---
arith_expr [22767,22807]
arith_expr [22719,22759]
===
match
---
expr_stmt [25683,25710]
expr_stmt [25635,25662]
===
match
---
name: val [17629,17632]
name: val [17629,17632]
===
match
---
name: following [21385,21394]
name: following [21361,21370]
===
match
---
name: List [11747,11751]
name: List [11747,11751]
===
match
---
name: DagRun [38970,38976]
name: DagRun [38922,38928]
===
match
---
expr_stmt [3424,3477]
expr_stmt [3424,3477]
===
match
---
param [19448,19474]
param [19448,19474]
===
match
---
name: property [31085,31093]
name: property [31037,31045]
===
match
---
string: """Returns the latest date for which at least one dag run exists""" [39863,39930]
string: """Returns the latest date for which at least one dag run exists""" [39815,39882]
===
match
---
operator: , [47810,47811]
operator: , [47762,47763]
===
match
---
trailer [90023,90025]
trailer [89975,89977]
===
match
---
name: next_run_date [26691,26704]
name: next_run_date [26643,26656]
===
match
---
expr_stmt [47899,47963]
expr_stmt [47851,47915]
===
match
---
name: end_date [68965,68973]
name: end_date [68917,68925]
===
match
---
name: get_dag [55418,55425]
name: get_dag [55370,55377]
===
match
---
simple_stmt [88209,88236]
simple_stmt [88161,88188]
===
match
---
atom [85326,85328]
atom [85278,85280]
===
match
---
simple_stmt [59406,59788]
simple_stmt [59358,59740]
===
match
---
operator: = [38955,38956]
operator: = [38907,38908]
===
match
---
name: bool [11600,11604]
name: bool [11600,11604]
===
match
---
name: min_task_end_date [27328,27345]
name: min_task_end_date [27280,27297]
===
match
---
name: append [79526,79532]
name: append [79478,79484]
===
match
---
trailer [47953,47962]
trailer [47905,47914]
===
match
---
name: t [62960,62961]
name: t [62912,62913]
===
match
---
simple_stmt [66071,66080]
simple_stmt [66023,66032]
===
match
---
name: merge [81118,81123]
name: merge [81070,81075]
===
match
---
trailer [60074,60082]
trailer [60026,60034]
===
match
---
operator: = [14854,14855]
operator: = [14854,14855]
===
match
---
name: isinstance [40777,40787]
name: isinstance [40729,40739]
===
match
---
operator: = [3115,3116]
operator: = [3115,3116]
===
match
---
atom_expr [20471,20521]
atom_expr [20471,20521]
===
match
---
trailer [31951,31974]
trailer [31903,31926]
===
match
---
argument [71476,71509]
argument [71428,71461]
===
match
---
name: subdag [41081,41087]
name: subdag [41033,41039]
===
match
---
atom_expr [68644,68658]
atom_expr [68596,68610]
===
match
---
name: Boolean [86805,86812]
name: Boolean [86757,86764]
===
match
---
name: dag_id [43205,43211]
name: dag_id [43157,43163]
===
match
---
operator: , [60133,60134]
operator: , [60085,60086]
===
match
---
simple_stmt [1362,1454]
simple_stmt [1362,1454]
===
match
---
expr_stmt [78626,78675]
expr_stmt [78578,78627]
===
match
---
name: or_ [44155,44158]
name: or_ [44107,44110]
===
match
---
trailer [65834,65843]
trailer [65786,65795]
===
match
---
operator: = [14022,14023]
operator: = [14022,14023]
===
match
---
arglist [86161,86199]
arglist [86113,86151]
===
match
---
name: self [51656,51660]
name: self [51608,51612]
===
match
---
expr_stmt [58969,58989]
expr_stmt [58921,58941]
===
match
---
operator: = [11663,11664]
operator: = [11663,11664]
===
match
---
name: DAG [16510,16513]
name: DAG [16510,16513]
===
match
---
sync_comp_for [75984,75999]
sync_comp_for [75936,75951]
===
match
---
expr_stmt [20106,20141]
expr_stmt [20106,20141]
===
match
---
name: self [51786,51790]
name: self [51738,51742]
===
match
---
operator: { [84954,84955]
operator: { [84906,84907]
===
match
---
atom_expr [93722,93749]
atom_expr [93674,93701]
===
match
---
atom [23883,23925]
atom [23835,23877]
===
match
---
param [10769,10803]
param [10769,10803]
===
match
---
trailer [59415,59787]
trailer [59367,59739]
===
match
---
name: upper [97126,97131]
name: upper [97078,97083]
===
match
---
comparison [17268,17281]
comparison [17268,17281]
===
match
---
trailer [88251,88268]
trailer [88203,88220]
===
match
---
simple_stmt [1454,1515]
simple_stmt [1454,1515]
===
match
---
atom_expr [39594,39605]
atom_expr [39546,39557]
===
match
---
tfpdef [84605,84628]
tfpdef [84557,84580]
===
match
---
operator: = [58196,58197]
operator: = [58148,58149]
===
match
---
testlist_comp [57088,57142]
testlist_comp [57040,57094]
===
match
---
name: backfill_job [70903,70915]
name: backfill_job [70855,70867]
===
match
---
name: query [37918,37923]
name: query [37870,37875]
===
match
---
atom_expr [18668,18710]
atom_expr [18668,18710]
===
match
---
name: params [12175,12181]
name: params [12175,12181]
===
match
---
trailer [44332,44336]
trailer [44284,44288]
===
match
---
operator: { [85019,85020]
operator: { [84971,84972]
===
match
---
name: self [13227,13231]
name: self [13227,13231]
===
match
---
trailer [43329,43335]
trailer [43281,43287]
===
match
---
decorated [89179,89332]
decorated [89131,89284]
===
match
---
trailer [79006,79013]
trailer [78958,78965]
===
match
---
atom_expr [42429,42474]
atom_expr [42381,42426]
===
match
---
trailer [12941,12943]
trailer [12941,12943]
===
match
---
atom_expr [41431,41455]
atom_expr [41383,41407]
===
match
---
name: orientation [15340,15351]
name: orientation [15340,15351]
===
match
---
operator: = [58975,58976]
operator: = [58927,58928]
===
match
---
atom_expr [90008,90025]
atom_expr [89960,89977]
===
match
---
atom_expr [27348,27367]
atom_expr [27300,27319]
===
match
---
name: state [44073,44078]
name: state [44025,44030]
===
match
---
name: self [13925,13929]
name: self [13925,13929]
===
match
---
operator: , [22001,22002]
operator: , [21977,21978]
===
match
---
name: DagModel [76128,76136]
name: DagModel [76080,76088]
===
match
---
name: days [10309,10313]
name: days [10309,10313]
===
match
---
while_stmt [28595,28763]
while_stmt [28547,28715]
===
match
---
trailer [95300,95325]
trailer [95252,95277]
===
match
---
name: query [39526,39531]
name: query [39478,39483]
===
match
---
trailer [51393,51397]
trailer [51345,51349]
===
match
---
trailer [76189,76196]
trailer [76141,76148]
===
match
---
name: partial [65119,65126]
name: partial [65071,65078]
===
match
---
trailer [24810,24828]
trailer [24762,24780]
===
match
---
name: default_args [14358,14370]
name: default_args [14358,14370]
===
match
---
trailer [47490,47498]
trailer [47442,47450]
===
match
---
for_stmt [96541,96649]
for_stmt [96493,96601]
===
match
---
string: 'SubDagOperator' [40967,40983]
string: 'SubDagOperator' [40919,40935]
===
match
---
testlist_comp [3067,3089]
testlist_comp [3067,3089]
===
match
---
name: dp [66428,66430]
name: dp [66380,66382]
===
match
---
param [11372,11433]
param [11372,11433]
===
match
---
simple_stmt [12695,12726]
simple_stmt [12695,12726]
===
match
---
name: t [79292,79293]
name: t [79244,79245]
===
match
---
name: naive [20698,20703]
name: naive [20698,20703]
===
match
---
name: param [31276,31281]
name: param [31228,31233]
===
match
---
name: templates [1612,1621]
name: templates [1612,1621]
===
match
---
suite [68386,68613]
suite [68338,68565]
===
match
---
simple_stmt [45631,45677]
simple_stmt [45583,45629]
===
match
---
name: ignore_task_deps [69122,69138]
name: ignore_task_deps [69074,69090]
===
match
---
simple_stmt [86860,86888]
simple_stmt [86812,86840]
===
match
---
name: schedule_interval [24696,24713]
name: schedule_interval [24648,24665]
===
match
---
name: dttm [65735,65739]
name: dttm [65687,65691]
===
match
---
expr_stmt [52776,52823]
expr_stmt [52728,52775]
===
match
---
atom_expr [25683,25698]
atom_expr [25635,25650]
===
match
---
name: Optional [22886,22894]
name: Optional [22838,22846]
===
match
---
name: property [30684,30692]
name: property [30636,30644]
===
match
---
suite [78008,78269]
suite [77960,78221]
===
match
---
atom [41728,41745]
atom [41680,41697]
===
match
---
simple_stmt [1781,1826]
simple_stmt [1781,1826]
===
match
---
operator: = [14809,14810]
operator: = [14809,14810]
===
match
---
name: cls [98134,98137]
name: cls [98086,98089]
===
match
---
name: current_dag [31595,31606]
name: current_dag [31547,31558]
===
match
---
operator: @ [80572,80573]
operator: @ [80524,80525]
===
match
---
operator: , [1157,1158]
operator: , [1157,1158]
===
match
---
tfpdef [10724,10752]
tfpdef [10724,10752]
===
match
---
name: int [12810,12813]
name: int [12810,12813]
===
match
---
atom [3126,3135]
atom [3126,3135]
===
match
---
operator: , [95939,95940]
operator: , [95891,95892]
===
match
---
name: existing_dag_ids [77116,77132]
name: existing_dag_ids [77068,77084]
===
match
---
atom_expr [14730,14743]
atom_expr [14730,14743]
===
match
---
trailer [16904,16911]
trailer [16904,16911]
===
match
---
name: RePatternType [62187,62200]
name: RePatternType [62139,62152]
===
match
---
trailer [15776,15796]
trailer [15776,15796]
===
match
---
operator: = [37709,37710]
operator: = [37661,37662]
===
match
---
name: count [57376,57381]
name: count [57328,57333]
===
match
---
trailer [38089,38091]
trailer [38041,38043]
===
match
---
operator: == [23802,23804]
operator: == [23754,23756]
===
match
---
atom [39504,39753]
atom [39456,39705]
===
match
---
operator: = [66163,66164]
operator: = [66115,66116]
===
match
---
operator: = [43951,43952]
operator: = [43903,43904]
===
match
---
trailer [96799,96811]
trailer [96751,96763]
===
match
---
name: len [65086,65089]
name: len [65038,65041]
===
match
---
name: timezone [22538,22546]
name: timezone [22496,22504]
===
match
---
name: previous_schedule [29063,29080]
name: previous_schedule [29015,29032]
===
match
---
atom_expr [21079,21110]
atom_expr [21079,21110]
===
match
---
name: provide_session [89197,89212]
name: provide_session [89149,89164]
===
match
---
trailer [73879,73887]
trailer [73831,73839]
===
match
---
fstring_end: " [74076,74077]
fstring_end: " [74028,74029]
===
match
---
arglist [77012,77059]
arglist [76964,77011]
===
match
---
name: state [83160,83165]
name: state [83112,83117]
===
match
---
param [17372,17376]
param [17372,17376]
===
match
---
atom_expr [11488,11502]
atom_expr [11488,11502]
===
match
---
simple_stmt [13363,13445]
simple_stmt [13363,13445]
===
match
---
operator: == [45728,45730]
operator: == [45680,45682]
===
match
---
operator: , [95717,95718]
operator: , [95669,95670]
===
match
---
trailer [97259,97274]
trailer [97211,97226]
===
match
---
trailer [32264,32272]
trailer [32216,32224]
===
match
---
trailer [26021,26040]
trailer [25973,25992]
===
match
---
comparison [33303,33340]
comparison [33255,33292]
===
match
---
param [84576,84581]
param [84528,84533]
===
match
---
atom_expr [22939,22956]
atom_expr [22891,22908]
===
match
---
name: self [19792,19796]
name: self [19792,19796]
===
match
---
number: 2000 [87140,87144]
number: 2000 [87092,87096]
===
match
---
trailer [90046,90076]
trailer [89998,90028]
===
match
---
operator: = [52081,52082]
operator: = [52033,52034]
===
match
---
trailer [80489,80495]
trailer [80441,80447]
===
match
---
simple_stmt [2825,2872]
simple_stmt [2825,2872]
===
match
---
expr_stmt [85282,85356]
expr_stmt [85234,85308]
===
match
---
trailer [94263,94279]
trailer [94215,94231]
===
match
---
name: set [53511,53514]
name: set [53463,53466]
===
match
---
string: 'scheduler' [11258,11269]
string: 'scheduler' [11258,11269]
===
match
---
name: str [13341,13344]
name: str [13341,13344]
===
match
---
decorator [79965,79982]
decorator [79917,79934]
===
match
---
trailer [12809,12814]
trailer [12809,12814]
===
match
---
suite [25517,25581]
suite [25469,25533]
===
match
---
name: orm_dag [79120,79127]
name: orm_dag [79072,79079]
===
match
---
tfpdef [10208,10234]
tfpdef [10208,10234]
===
match
---
trailer [17159,17175]
trailer [17159,17175]
===
match
---
atom_expr [72307,72321]
atom_expr [72259,72273]
===
match
---
parameters [31669,31675]
parameters [31621,31627]
===
match
---
atom_expr [63504,63517]
atom_expr [63456,63469]
===
match
---
name: question [59332,59340]
name: question [59284,59292]
===
insert-node
---
name: DAG [3703,3706]
to
classdef [3697,85357]
at 0
===
insert-node
---
name: LoggingMixin [3707,3719]
to
classdef [3697,85357]
at 1
===
insert-tree
---
simple_stmt [3726,9876]
    string: """     A dag (directed acyclic graph) is a collection of tasks with directional     dependencies. A dag also has a schedule, a start date and an end date     (optional). For each schedule, (say daily or hourly), the DAG needs to run     each individual tasks as their dependencies are met. Certain tasks have     the property of depending on their own past, meaning that they can't run     until their previous schedule (and upstream tasks) are completed.      DAGs essentially act as namespaces for tasks. A task_id can only be     added once to a DAG.      :param dag_id: The id of the DAG; must consist exclusively of alphanumeric         characters, dashes, dots and underscores (all ASCII)     :type dag_id: str     :param description: The description for the DAG to e.g. be shown on the webserver     :type description: str     :param schedule_interval: Defines how often that DAG runs, this         timedelta object gets added to your latest task instance's         execution_date to figure out the next schedule     :type schedule_interval: datetime.timedelta or         dateutil.relativedelta.relativedelta or str that acts as a cron         expression     :param start_date: The timestamp from which the scheduler will         attempt to backfill     :type start_date: datetime.datetime     :param end_date: A date beyond which your DAG won't run, leave to None         for open ended scheduling     :type end_date: datetime.datetime     :param template_searchpath: This list of folders (non relative)         defines where jinja will look for your templates. Order matters.         Note that jinja/airflow includes the path of your DAG file by         default     :type template_searchpath: str or list[str]     :param template_undefined: Template undefined type.     :type template_undefined: jinja2.StrictUndefined     :param user_defined_macros: a dictionary of macros that will be exposed         in your jinja templates. For example, passing ``dict(foo='bar')``         to this argument allows you to ``{{ foo }}`` in all jinja         templates related to this DAG. Note that you can pass any         type of object here.     :type user_defined_macros: dict     :param user_defined_filters: a dictionary of filters that will be exposed         in your jinja templates. For example, passing         ``dict(hello=lambda name: 'Hello %s' % name)`` to this argument allows         you to ``{{ 'world' | hello }}`` in all jinja templates related to         this DAG.     :type user_defined_filters: dict     :param default_args: A dictionary of default parameters to be used         as constructor keyword parameters when initialising operators.         Note that operators have the same hook, and precede those defined         here, meaning that if your dict contains `'depends_on_past': True`         here and `'depends_on_past': False` in the operator's call         `default_args`, the actual value will be `False`.     :type default_args: dict     :param params: a dictionary of DAG level parameters that are made         accessible in templates, namespaced under `params`. These         params can be overridden at the task level.     :type params: dict     :param concurrency: the number of task instances allowed to run         concurrently     :type concurrency: int     :param max_active_runs: maximum number of active DAG runs, beyond this         number of DAG runs in a running state, the scheduler won't create         new active DAG runs     :type max_active_runs: int     :param dagrun_timeout: specify how long a DagRun should be up before         timing out / failing, so that new DagRuns can be created. The timeout         is only enforced for scheduled DagRuns.     :type dagrun_timeout: datetime.timedelta     :param sla_miss_callback: specify a function to call when reporting SLA         timeouts.     :type sla_miss_callback: types.FunctionType     :param default_view: Specify DAG default view (tree, graph, duration,                                                    gantt, landing_times), default tree     :type default_view: str     :param orientation: Specify DAG orientation in graph view (LR, TB, RL, BT), default LR     :type orientation: str     :param catchup: Perform scheduler catchup (or only run latest)? Defaults to True     :type catchup: bool     :param on_failure_callback: A function to be called when a DagRun of this dag fails.         A context dictionary is passed as a single parameter to this function.     :type on_failure_callback: callable     :param on_success_callback: Much like the ``on_failure_callback`` except         that it is executed when the dag succeeds.     :type on_success_callback: callable     :param access_control: Specify optional DAG-level actions, e.g.,         "{'role1': {'can_read'}, 'role2': {'can_read', 'can_edit'}}"     :type access_control: dict     :param is_paused_upon_creation: Specifies if the dag is paused when created for the first time.         If the dag exists already, this flag will be ignored. If this optional parameter         is not specified, the global config setting will be used.     :type is_paused_upon_creation: bool or None     :param jinja_environment_kwargs: additional configuration options to be passed to Jinja         ``Environment`` for template rendering          **Example**: to avoid Jinja from removing a trailing newline from template strings ::              DAG(dag_id='my-dag',                 jinja_environment_kwargs={                     'keep_trailing_newline': True,                     # some other jinja2 Environment options here                 }             )          **See**: `Jinja Environment documentation         <https://jinja.palletsprojects.com/en/2.11.x/api/#jinja2.Environment>`_      :type jinja_environment_kwargs: dict     :param render_template_as_native_obj: If True, uses a Jinja ```NativeEnvironment``         to render templates as native Python types. If False, a Jinja         ``Environment`` is used to render templates as string values.     :type render_template_as_native_obj: bool     :param tags: List of tags to help filtering DAGS in the UI.     :type tags: List[str]     """ [3726,9875]
to
suite [3721,85357]
at 0
===
move-tree
---
atom_expr [21263,21281]
    name: self [21263,21267]
    trailer [21267,21276]
        name: timezone [21268,21276]
    trailer [21276,21281]
        name: name [21277,21281]
to
expr_stmt [21240,21282]
at 2
===
move-tree
---
atom_expr [22533,22551]
    name: self [22533,22537]
    trailer [22537,22546]
        name: timezone [22538,22546]
    trailer [22546,22551]
        name: name [22547,22551]
to
expr_stmt [22510,22552]
at 2
===
delete-node
---
name: DAG [3703,3706]
===
===
delete-node
---
name: LoggingMixin [3707,3719]
===
===
delete-tree
---
simple_stmt [3726,9876]
    string: """     A dag (directed acyclic graph) is a collection of tasks with directional     dependencies. A dag also has a schedule, a start date and an end date     (optional). For each schedule, (say daily or hourly), the DAG needs to run     each individual tasks as their dependencies are met. Certain tasks have     the property of depending on their own past, meaning that they can't run     until their previous schedule (and upstream tasks) are completed.      DAGs essentially act as namespaces for tasks. A task_id can only be     added once to a DAG.      :param dag_id: The id of the DAG; must consist exclusively of alphanumeric         characters, dashes, dots and underscores (all ASCII)     :type dag_id: str     :param description: The description for the DAG to e.g. be shown on the webserver     :type description: str     :param schedule_interval: Defines how often that DAG runs, this         timedelta object gets added to your latest task instance's         execution_date to figure out the next schedule     :type schedule_interval: datetime.timedelta or         dateutil.relativedelta.relativedelta or str that acts as a cron         expression     :param start_date: The timestamp from which the scheduler will         attempt to backfill     :type start_date: datetime.datetime     :param end_date: A date beyond which your DAG won't run, leave to None         for open ended scheduling     :type end_date: datetime.datetime     :param template_searchpath: This list of folders (non relative)         defines where jinja will look for your templates. Order matters.         Note that jinja/airflow includes the path of your DAG file by         default     :type template_searchpath: str or list[str]     :param template_undefined: Template undefined type.     :type template_undefined: jinja2.StrictUndefined     :param user_defined_macros: a dictionary of macros that will be exposed         in your jinja templates. For example, passing ``dict(foo='bar')``         to this argument allows you to ``{{ foo }}`` in all jinja         templates related to this DAG. Note that you can pass any         type of object here.     :type user_defined_macros: dict     :param user_defined_filters: a dictionary of filters that will be exposed         in your jinja templates. For example, passing         ``dict(hello=lambda name: 'Hello %s' % name)`` to this argument allows         you to ``{{ 'world' | hello }}`` in all jinja templates related to         this DAG.     :type user_defined_filters: dict     :param default_args: A dictionary of default parameters to be used         as constructor keyword parameters when initialising operators.         Note that operators have the same hook, and precede those defined         here, meaning that if your dict contains `'depends_on_past': True`         here and `'depends_on_past': False` in the operator's call         `default_args`, the actual value will be `False`.     :type default_args: dict     :param params: a dictionary of DAG level parameters that are made         accessible in templates, namespaced under `params`. These         params can be overridden at the task level.     :type params: dict     :param concurrency: the number of task instances allowed to run         concurrently     :type concurrency: int     :param max_active_runs: maximum number of active DAG runs, beyond this         number of DAG runs in a running state, the scheduler won't create         new active DAG runs     :type max_active_runs: int     :param dagrun_timeout: specify how long a DagRun should be up before         timing out / failing, so that new DagRuns can be created. The timeout         is only enforced for scheduled DagRuns.     :type dagrun_timeout: datetime.timedelta     :param sla_miss_callback: specify a function to call when reporting SLA         timeouts.     :type sla_miss_callback: types.FunctionType     :param default_view: Specify DAG default view (tree, graph, duration,                                                    gantt, landing_times), default tree     :type default_view: str     :param orientation: Specify DAG orientation in graph view (LR, TB, RL, BT), default LR     :type orientation: str     :param catchup: Perform scheduler catchup (or only run latest)? Defaults to True     :type catchup: bool     :param on_failure_callback: A function to be called when a DagRun of this dag fails.         A context dictionary is passed as a single parameter to this function.     :type on_failure_callback: callable     :param on_success_callback: Much like the ``on_failure_callback`` except         that it is executed when the dag succeeds.     :type on_success_callback: callable     :param access_control: Specify optional DAG-level actions, e.g.,         "{'role1': {'can_read'}, 'role2': {'can_read', 'can_edit'}}"     :type access_control: dict     :param is_paused_upon_creation: Specifies if the dag is paused when created for the first time.         If the dag exists already, this flag will be ignored. If this optional parameter         is not specified, the global config setting will be used.     :type is_paused_upon_creation: bool or None     :param jinja_environment_kwargs: additional configuration options to be passed to Jinja         ``Environment`` for template rendering          **Example**: to avoid Jinja from removing a trailing newline from template strings ::              DAG(dag_id='my-dag',                 jinja_environment_kwargs={                     'keep_trailing_newline': True,                     # some other jinja2 Environment options here                 }             )          **See**: `Jinja Environment documentation         <https://jinja.palletsprojects.com/en/2.11.x/api/#jinja2.Environment>`_      :type jinja_environment_kwargs: dict     :param render_template_as_native_obj: If True, uses a Jinja ```NativeEnvironment``         to render templates as native Python types. If False, a Jinja         ``Environment`` is used to render templates as string values.     :type render_template_as_native_obj: bool     :param tags: List of tags to help filtering DAGS in the UI.     :type tags: List[str]     """ [3726,9875]
===
delete-tree
---
trailer [21276,21281]
    name: name [21277,21281]
===
delete-node
---
trailer [21262,21282]
===
===
delete-node
---
atom_expr [21245,21282]
===
===
delete-tree
---
trailer [22546,22551]
    name: name [22547,22551]
===
delete-node
---
trailer [22532,22552]
===
===
delete-node
---
atom_expr [22515,22552]
===
