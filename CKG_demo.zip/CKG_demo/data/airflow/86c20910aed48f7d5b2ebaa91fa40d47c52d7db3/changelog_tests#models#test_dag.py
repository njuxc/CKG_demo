===
match
---
operator: , [21515,21516]
operator: , [21515,21516]
===
match
---
trailer [55484,55566]
trailer [57200,57282]
===
match
---
operator: , [56650,56651]
operator: , [58366,58367]
===
match
---
trailer [44806,44818]
trailer [46522,46534]
===
match
---
name: dag_diff_name [45014,45027]
name: dag_diff_name [46730,46743]
===
match
---
assert_stmt [45160,45186]
assert_stmt [46876,46902]
===
match
---
name: dag [11850,11853]
name: dag [11850,11853]
===
match
---
name: b_index [3452,3459]
name: b_index [3452,3459]
===
match
---
name: test_dag_id [44316,44327]
name: test_dag_id [46032,46043]
===
match
---
atom_expr [34665,34680]
atom_expr [36381,36396]
===
match
---
name: utc [21939,21942]
name: utc [21939,21942]
===
match
---
operator: == [64498,64500]
operator: == [66214,66216]
===
match
---
trailer [59015,59024]
trailer [60731,60740]
===
match
---
argument [58191,58204]
argument [59907,59920]
===
match
---
argument [36317,36329]
argument [38033,38045]
===
match
---
name: task_instance_1 [53986,54001]
name: task_instance_1 [55702,55717]
===
match
---
trailer [11958,12025]
trailer [11958,12025]
===
match
---
arglist [59866,59876]
arglist [61582,61592]
===
match
---
with_stmt [35234,35611]
with_stmt [36950,37327]
===
match
---
name: state [17383,17388]
name: state [17383,17388]
===
match
---
operator: = [64705,64706]
operator: = [66421,66422]
===
match
---
name: settings [34427,34435]
name: settings [36143,36151]
===
match
---
suite [43005,43823]
suite [44721,45539]
===
match
---
name: NamedTemporaryFile [18903,18921]
name: NamedTemporaryFile [18903,18921]
===
match
---
name: DAG [17993,17996]
name: DAG [17993,17996]
===
match
---
operator: + [53341,53342]
operator: + [55057,55058]
===
match
---
operator: == [34351,34353]
operator: == [36067,36069]
===
match
---
name: weight [15032,15038]
name: weight [15032,15038]
===
match
---
argument [37129,37151]
argument [38845,38867]
===
match
---
atom_expr [54900,54932]
atom_expr [56616,56648]
===
match
---
name: dag_run_state [48138,48151]
name: dag_run_state [49854,49867]
===
match
---
simple_stmt [23005,23041]
simple_stmt [23005,23041]
===
match
---
comparison [10382,10409]
comparison [10382,10409]
===
match
---
expr_stmt [12507,12516]
expr_stmt [12507,12516]
===
match
---
string: 'dag' [5921,5926]
string: 'dag' [5921,5926]
===
match
---
string: """         Make sure DST transitions are properly observed         """ [22424,22495]
string: """         Make sure DST transitions are properly observed         """ [22424,22495]
===
match
---
argument [49991,50001]
argument [51707,51717]
===
match
---
simple_stmt [5717,5903]
simple_stmt [5717,5903]
===
match
---
name: add [65134,65137]
name: add [66850,66853]
===
match
---
comparison [60284,60326]
comparison [62000,62042]
===
match
---
operator: { [15421,15422]
operator: { [15421,15422]
===
match
---
string: 'a_child' [8225,8234]
string: 'a_child' [8225,8234]
===
match
---
operator: = [48918,48919]
operator: = [50634,50635]
===
match
---
name: owner [28975,28980]
name: owner [30691,30696]
===
match
---
assert_stmt [8338,8404]
assert_stmt [8338,8404]
===
match
---
name: dag [37645,37648]
name: dag [39361,39364]
===
match
---
operator: , [41518,41519]
operator: , [43234,43235]
===
match
---
simple_stmt [61457,61609]
simple_stmt [63173,63325]
===
match
---
dotted_name [49395,49415]
dotted_name [51111,51131]
===
match
---
string: 't2' [36651,36655]
string: 't2' [38367,38371]
===
match
---
trailer [5609,5613]
trailer [5609,5613]
===
match
---
simple_stmt [28905,28929]
simple_stmt [30621,30645]
===
match
---
name: topological_list [8387,8403]
name: topological_list [8387,8403]
===
match
---
operator: , [9492,9493]
operator: , [9492,9493]
===
match
---
trailer [65506,65515]
trailer [67222,67231]
===
match
---
atom_expr [32939,32995]
atom_expr [34655,34711]
===
match
---
trailer [48068,48076]
trailer [49784,49792]
===
match
---
string: "test_fractional_seconds" [43110,43135]
string: "test_fractional_seconds" [44826,44851]
===
match
---
argument [6384,6397]
argument [6384,6397]
===
match
---
trailer [9658,9671]
trailer [9658,9671]
===
match
---
name: next_date [57477,57486]
name: next_date [59193,59202]
===
match
---
trailer [22301,22311]
trailer [22301,22311]
===
match
---
name: dag [32852,32855]
name: dag [34568,34571]
===
match
---
name: unittest [870,878]
name: unittest [870,878]
===
match
---
trailer [34081,34089]
trailer [35797,35805]
===
match
---
argument [4961,4995]
argument [4961,4995]
===
match
---
operator: , [54799,54800]
operator: , [56515,56516]
===
match
---
trailer [38492,38506]
trailer [40208,40222]
===
match
---
name: DEFAULT_ARGS [69799,69811]
name: DEFAULT_ARGS [71515,71527]
===
match
---
suite [56254,56825]
suite [57970,58541]
===
match
---
argument [35055,35080]
argument [36771,36796]
===
match
---
number: 4 [59034,59035]
number: 4 [60750,60751]
===
match
---
string: 'child_dag' [8212,8223]
string: 'child_dag' [8212,8223]
===
match
---
expr_stmt [12543,12553]
expr_stmt [12543,12553]
===
match
---
name: topological_list [9338,9354]
name: topological_list [9338,9354]
===
match
---
param [46745,46763]
param [48461,48479]
===
match
---
trailer [21973,21981]
trailer [21973,21981]
===
match
---
operator: = [7973,7974]
operator: = [7973,7974]
===
match
---
name: session [30275,30282]
name: session [31991,31998]
===
match
---
name: start_date [29886,29896]
name: start_date [31602,31612]
===
match
---
string: 'test-dag2' [26998,27009]
string: 'test-dag2' [28714,28725]
===
match
---
operator: - [57087,57088]
operator: - [58803,58804]
===
match
---
name: dag_id [5555,5561]
name: dag_id [5555,5561]
===
match
---
trailer [20386,20395]
trailer [20386,20395]
===
match
---
testlist_comp [35531,35539]
testlist_comp [37247,37255]
===
match
---
simple_stmt [56057,56184]
simple_stmt [57773,57900]
===
match
---
simple_stmt [67350,67409]
simple_stmt [69066,69125]
===
match
---
name: calculated_weight [13747,13764]
name: calculated_weight [13747,13764]
===
match
---
name: op1 [36251,36254]
name: op1 [37967,37970]
===
match
---
funcdef [3507,3824]
funcdef [3507,3824]
===
match
---
expr_stmt [15331,15340]
expr_stmt [15331,15340]
===
match
---
param [53444,53471]
param [55160,55187]
===
match
---
arglist [48683,48736]
arglist [50399,50452]
===
match
---
name: dag [55475,55478]
name: dag [57191,57194]
===
match
---
name: DummyOperator [7017,7030]
name: DummyOperator [7017,7030]
===
match
---
name: timezone [59965,59973]
name: timezone [61681,61689]
===
match
---
trailer [70054,70063]
trailer [71770,71779]
===
match
---
operator: } [25148,25149]
operator: } [26864,26865]
===
match
---
atom_expr [43648,43666]
atom_expr [45364,45382]
===
match
---
trailer [35589,35595]
trailer [37305,37311]
===
match
---
name: flush [65319,65324]
name: flush [67035,67040]
===
match
---
name: dag_run_state [52890,52903]
name: dag_run_state [54606,54619]
===
match
---
argument [7895,7914]
argument [7895,7914]
===
match
---
trailer [65227,65231]
trailer [66943,66947]
===
match
---
operator: , [40703,40704]
operator: , [42419,42420]
===
match
---
name: timedelta [52845,52854]
name: timedelta [54561,54570]
===
match
---
number: 1 [58832,58833]
number: 1 [60548,60549]
===
match
---
name: orientation [5369,5380]
name: orientation [5369,5380]
===
match
---
string: "test" [66251,66257]
string: "test" [67967,67973]
===
match
---
trailer [54377,54412]
trailer [56093,56128]
===
match
---
trailer [60666,60835]
trailer [62382,62551]
===
match
---
name: half_an_hour_ago [57003,57019]
name: half_an_hour_ago [58719,58735]
===
match
---
name: ti [70561,70563]
name: ti [72277,72279]
===
match
---
atom_expr [26576,26592]
atom_expr [28292,28308]
===
match
---
trailer [36530,36539]
trailer [38246,38255]
===
match
---
atom_expr [17130,17139]
atom_expr [17130,17139]
===
match
---
name: dag_run [39715,39722]
name: dag_run [41431,41438]
===
match
---
trailer [8844,8857]
trailer [8844,8857]
===
match
---
name: start_date [38336,38346]
name: start_date [40052,40062]
===
match
---
atom_expr [20920,20946]
atom_expr [20920,20946]
===
match
---
argument [52532,52551]
argument [54248,54267]
===
match
---
simple_stmt [4944,4997]
simple_stmt [4944,4997]
===
match
---
atom_expr [15372,15441]
atom_expr [15372,15441]
===
match
---
trailer [47833,47940]
trailer [49549,49656]
===
match
---
name: op3 [36403,36406]
name: op3 [38119,38122]
===
match
---
name: dag_id [39000,39006]
name: dag_id [40716,40722]
===
match
---
testlist_comp [25006,25035]
testlist_comp [26722,26751]
===
match
---
trailer [50705,50722]
trailer [52421,52438]
===
match
---
argument [59639,59679]
argument [61355,61395]
===
match
---
name: task_id [51664,51671]
name: task_id [53380,53387]
===
match
---
operator: = [56700,56701]
operator: = [58416,58417]
===
match
---
operator: , [54469,54470]
operator: , [56185,56186]
===
match
---
trailer [66433,66442]
trailer [68149,68158]
===
match
---
argument [8890,8901]
argument [8890,8901]
===
match
---
comparison [6446,6467]
comparison [6446,6467]
===
match
---
operator: { [47262,47263]
operator: { [48978,48979]
===
match
---
atom_expr [3812,3822]
atom_expr [3812,3822]
===
match
---
atom_expr [2977,2986]
atom_expr [2977,2986]
===
match
---
name: name [19048,19052]
name: name [19048,19052]
===
match
---
operator: == [10531,10533]
operator: == [10531,10533]
===
match
---
arglist [7895,7932]
arglist [7895,7932]
===
match
---
name: orm_dag [34459,34466]
name: orm_dag [36175,36182]
===
match
---
name: dag [35283,35286]
name: dag [36999,37002]
===
match
---
name: dag [32567,32570]
name: dag [34283,34286]
===
match
---
trailer [38703,38706]
trailer [40419,40422]
===
match
---
operator: = [6577,6578]
operator: = [6577,6578]
===
match
---
name: next_dagrun_after_date [60235,60257]
name: next_dagrun_after_date [61951,61973]
===
match
---
atom_expr [10784,10837]
atom_expr [10784,10837]
===
match
---
string: 'owner1' [8596,8604]
string: 'owner1' [8596,8604]
===
match
---
name: execution_date [50206,50220]
name: execution_date [51922,51936]
===
match
---
trailer [23780,23843]
trailer [23780,23843]
===
match
---
number: 1 [55926,55927]
number: 1 [57642,57643]
===
match
---
name: tests [2241,2246]
name: tests [2241,2246]
===
match
---
trailer [18731,18739]
trailer [18731,18739]
===
match
---
name: DummyOperator [38001,38014]
name: DummyOperator [39717,39730]
===
match
---
name: task_id [38493,38500]
name: task_id [40209,40216]
===
match
---
operator: = [53841,53842]
operator: = [55557,55558]
===
match
---
operator: , [46485,46486]
operator: , [48201,48202]
===
match
---
trailer [49173,49180]
trailer [50889,50896]
===
match
---
operator: >> [38546,38548]
operator: >> [40262,40264]
===
match
---
name: owner [39135,39140]
name: owner [40851,40856]
===
match
---
suite [13849,15162]
suite [13849,15162]
===
match
---
name: a [3374,3375]
name: a [3374,3375]
===
match
---
trailer [44315,44347]
trailer [46031,46063]
===
match
---
parameters [65531,65537]
parameters [67247,67253]
===
match
---
name: timezone [22667,22675]
name: timezone [22667,22675]
===
match
---
arglist [18172,18246]
arglist [18172,18246]
===
match
---
expr_stmt [13593,13659]
expr_stmt [13593,13659]
===
match
---
suite [2797,3136]
suite [2797,3136]
===
match
---
operator: = [21415,21416]
operator: = [21415,21416]
===
match
---
name: DEFAULT_ARGS [67875,67887]
name: DEFAULT_ARGS [69591,69603]
===
match
---
name: query [34230,34235]
name: query [35946,35951]
===
match
---
name: create_dagrun [70192,70205]
name: create_dagrun [71908,71921]
===
match
---
name: schedule_interval [60795,60812]
name: schedule_interval [62511,62528]
===
match
---
name: dag [20610,20613]
name: dag [20610,20613]
===
match
---
name: session [18398,18405]
name: session [18398,18405]
===
match
---
parameters [7306,7312]
parameters [7306,7312]
===
match
---
name: owner [6689,6694]
name: owner [6689,6694]
===
match
---
name: airflow [1822,1829]
name: airflow [1822,1829]
===
match
---
name: dag [66807,66810]
name: dag [68523,68526]
===
match
---
string: 'value' [70390,70397]
string: 'value' [72106,72113]
===
match
---
funcdef [65522,65571]
funcdef [67238,67287]
===
match
---
name: now [57083,57086]
name: now [58799,58802]
===
match
---
name: topological_list [8312,8328]
name: topological_list [8312,8328]
===
match
---
trailer [54452,54459]
trailer [56168,56175]
===
match
---
operator: = [51918,51919]
operator: = [53634,53635]
===
match
---
expr_stmt [4363,4395]
expr_stmt [4363,4395]
===
match
---
atom_expr [13434,13461]
atom_expr [13434,13461]
===
match
---
trailer [61373,61393]
trailer [63089,63109]
===
match
---
parameters [5119,5125]
parameters [5119,5125]
===
match
---
trailer [33617,33621]
trailer [35333,35337]
===
match
---
name: b_index [3295,3302]
name: b_index [3295,3302]
===
match
---
simple_stmt [21326,21398]
simple_stmt [21326,21398]
===
match
---
operator: , [48048,48049]
operator: , [49764,49765]
===
match
---
operator: = [53879,53880]
operator: = [55595,55596]
===
match
---
argument [69484,69512]
argument [71200,71228]
===
match
---
param [32552,32556]
param [34268,34272]
===
match
---
name: start_date [63923,63933]
name: start_date [65639,65649]
===
match
---
name: airflow [1235,1242]
name: airflow [1235,1242]
===
match
---
trailer [9838,9851]
trailer [9838,9851]
===
match
---
number: 0 [14566,14567]
number: 0 [14566,14567]
===
match
---
argument [19166,19198]
argument [19166,19198]
===
match
---
atom_expr [37955,37982]
atom_expr [39671,39698]
===
match
---
assert_stmt [62724,62779]
assert_stmt [64440,64495]
===
match
---
name: dag_id [46125,46131]
name: dag_id [47841,47847]
===
match
---
name: owner [6314,6319]
name: owner [6314,6319]
===
match
---
name: dr [69555,69557]
name: dr [71271,71273]
===
match
---
string: "test_dag" [36194,36204]
string: "test_dag" [37910,37920]
===
match
---
argument [61882,61899]
argument [63598,63615]
===
match
---
parameters [67914,67916]
parameters [69630,69632]
===
match
---
name: self [70740,70744]
name: self [72456,72460]
===
match
---
simple_stmt [24015,24071]
simple_stmt [24015,24071]
===
match
---
name: dag_id [51535,51541]
name: dag_id [53251,53257]
===
match
---
simple_stmt [54888,54933]
simple_stmt [56604,56649]
===
match
---
string: 'test-dag' [25967,25977]
string: 'test-dag' [27683,27693]
===
match
---
trailer [27119,27146]
trailer [28835,28862]
===
match
---
string: 'end_date' [11782,11792]
string: 'end_date' [11782,11792]
===
match
---
trailer [35585,35596]
trailer [37301,37312]
===
match
---
name: dag [48374,48377]
name: dag [50090,50093]
===
match
---
name: DagRunType [28067,28077]
name: DagRunType [29783,29793]
===
match
---
atom_expr [25230,25276]
atom_expr [26946,26992]
===
match
---
string: 'dag-bulk-sync-0' [26829,26846]
string: 'dag-bulk-sync-0' [28545,28562]
===
match
---
atom_expr [36483,36498]
atom_expr [38199,38214]
===
match
---
if_stmt [14558,14598]
if_stmt [14558,14598]
===
match
---
parameters [68043,68048]
parameters [69759,69764]
===
match
---
name: section_1 [62295,62304]
name: section_1 [64011,64020]
===
match
---
string: 't1' [38409,38413]
string: 't1' [40125,40129]
===
match
---
expr_stmt [16813,16872]
expr_stmt [16813,16872]
===
match
---
operator: = [54898,54899]
operator: = [56614,56615]
===
match
---
operator: = [37947,37948]
operator: = [39663,39664]
===
match
---
operator: = [38638,38639]
operator: = [40354,40355]
===
match
---
trailer [12119,12128]
trailer [12119,12128]
===
match
---
name: params [71069,71075]
name: params [72785,72791]
===
match
---
trailer [43379,43586]
trailer [45095,45302]
===
match
---
trailer [19128,19199]
trailer [19128,19199]
===
match
---
return_stmt [56814,56824]
return_stmt [58530,58540]
===
match
---
operator: , [61014,61015]
operator: , [62730,62731]
===
match
---
name: is_paused [65286,65295]
name: is_paused [67002,67011]
===
match
---
name: has_task_concurrency_limits [64171,64198]
name: has_task_concurrency_limits [65887,65914]
===
match
---
operator: = [17750,17751]
operator: = [17750,17751]
===
match
---
name: dag [44868,44871]
name: dag [46584,46587]
===
match
---
trailer [35365,35379]
trailer [37081,37095]
===
match
---
operator: == [21805,21807]
operator: == [21805,21807]
===
match
---
operator: == [26701,26703]
operator: == [28417,28419]
===
match
---
trailer [24718,24720]
trailer [26434,26436]
===
match
---
trailer [67233,67235]
trailer [68949,68951]
===
match
---
argument [59721,59727]
argument [61437,61443]
===
match
---
trailer [49249,49253]
trailer [50965,50969]
===
match
---
operator: == [12426,12428]
operator: == [12426,12428]
===
match
---
name: utc [23036,23039]
name: utc [23036,23039]
===
match
---
string: 'dag-bulk-sync-0' [25948,25965]
string: 'dag-bulk-sync-0' [27664,27681]
===
match
---
name: dag_id [66836,66842]
name: dag_id [68552,68558]
===
match
---
arglist [34123,34156]
arglist [35839,35872]
===
match
---
trailer [22952,22962]
trailer [22952,22962]
===
match
---
fstring_start: f' [12976,12978]
fstring_start: f' [12976,12978]
===
match
---
name: dag [4470,4473]
name: dag [4470,4473]
===
match
---
trailer [61298,61321]
trailer [63014,63037]
===
match
---
string: 'owner1' [16534,16542]
string: 'owner1' [16534,16542]
===
match
---
param [63873,63877]
param [65589,65593]
===
match
---
atom_expr [41538,41554]
atom_expr [43254,43270]
===
match
---
name: self [22409,22413]
name: self [22409,22413]
===
match
---
operator: = [51705,51706]
operator: = [53421,53422]
===
match
---
operator: = [49689,49690]
operator: = [51405,51406]
===
match
---
name: pipeline [15860,15868]
name: pipeline [15860,15868]
===
match
---
trailer [31248,31252]
trailer [32964,32968]
===
match
---
atom_expr [47158,47175]
atom_expr [48874,48891]
===
match
---
operator: , [58783,58784]
operator: , [60499,60500]
===
match
---
trailer [19045,19053]
trailer [19045,19053]
===
match
---
name: dag [35038,35041]
name: dag [36754,36757]
===
match
---
operator: , [31653,31654]
operator: , [33369,33370]
===
match
---
argument [23803,23820]
argument [23803,23820]
===
match
---
decorated [67506,67582]
decorated [69222,69298]
===
match
---
name: days [54276,54280]
name: days [55992,55996]
===
match
---
assert_stmt [67244,67271]
assert_stmt [68960,68987]
===
match
---
operator: = [18594,18595]
operator: = [18594,18595]
===
match
---
simple_stmt [23318,23379]
simple_stmt [23318,23379]
===
match
---
string: 'tz_dag' [20620,20628]
string: 'tz_dag' [20620,20628]
===
match
---
atom_expr [54812,54841]
atom_expr [56528,56557]
===
match
---
trailer [48272,48324]
trailer [49988,50040]
===
match
---
name: dag [20697,20700]
name: dag [20697,20700]
===
match
---
name: session [64830,64837]
name: session [66546,66553]
===
match
---
import_from [1189,1228]
import_from [1189,1228]
===
match
---
number: 2 [17243,17244]
number: 2 [17243,17244]
===
match
---
name: external_trigger [43553,43569]
name: external_trigger [45269,45285]
===
match
---
trailer [55302,55311]
trailer [57018,57027]
===
match
---
trailer [8931,8943]
trailer [8931,8943]
===
match
---
trailer [26389,26393]
trailer [28105,28109]
===
match
---
atom_expr [64230,64244]
atom_expr [65946,65960]
===
match
---
trailer [29782,29788]
trailer [31498,31504]
===
match
---
operator: , [65680,65681]
operator: , [67396,67397]
===
match
---
expr_stmt [54563,54596]
expr_stmt [56279,56312]
===
match
---
name: task_id [56638,56645]
name: task_id [58354,58361]
===
match
---
simple_stmt [36297,36331]
simple_stmt [38013,38047]
===
match
---
trailer [3769,3787]
trailer [3769,3787]
===
match
---
trailer [68230,68236]
trailer [69946,69952]
===
match
---
trailer [6005,6072]
trailer [6005,6072]
===
match
---
trailer [9354,9357]
trailer [9354,9357]
===
match
---
assert_stmt [10290,10324]
assert_stmt [10290,10324]
===
match
---
trailer [35242,35279]
trailer [36958,36995]
===
match
---
name: convert [22849,22856]
name: convert [22849,22856]
===
match
---
trailer [13441,13447]
trailer [13441,13447]
===
match
---
name: task_id [48361,48368]
name: task_id [50077,50084]
===
match
---
trailer [10207,10228]
trailer [10207,10228]
===
match
---
operator: } [5984,5985]
operator: } [5984,5985]
===
match
---
name: decorators [1319,1329]
name: decorators [1319,1329]
===
match
---
name: RUNNING [43532,43539]
name: RUNNING [45248,45255]
===
match
---
string: 'a_child' [7521,7530]
string: 'a_child' [7521,7530]
===
match
---
operator: = [56645,56646]
operator: = [58361,58362]
===
match
---
name: args [61895,61899]
name: args [63611,63615]
===
match
---
trailer [2965,2969]
trailer [2965,2969]
===
match
---
expr_stmt [6104,6138]
expr_stmt [6104,6138]
===
match
---
arglist [61130,61151]
arglist [62846,62867]
===
match
---
parameters [38299,38305]
parameters [40015,40021]
===
match
---
atom_expr [26740,26776]
atom_expr [28456,28492]
===
match
---
suite [3376,3405]
suite [3376,3405]
===
match
---
param [67145,67148]
param [68861,68864]
===
match
---
argument [49923,49936]
argument [51639,51652]
===
match
---
atom_expr [13495,13509]
atom_expr [13495,13509]
===
match
---
name: RUNNING [18076,18083]
name: RUNNING [18076,18083]
===
match
---
name: merge [48637,48642]
name: merge [50353,50358]
===
match
---
with_stmt [6985,7046]
with_stmt [6985,7046]
===
match
---
simple_stmt [66217,66406]
simple_stmt [67933,68122]
===
match
---
comparison [24022,24070]
comparison [24022,24070]
===
match
---
simple_stmt [51965,51994]
simple_stmt [53681,53710]
===
match
---
trailer [26519,26522]
trailer [28235,28238]
===
match
---
atom_expr [48723,48736]
atom_expr [50439,50452]
===
match
---
operator: , [14411,14412]
operator: , [14411,14412]
===
match
---
operator: = [57225,57226]
operator: = [58941,58942]
===
match
---
name: flush [64397,64402]
name: flush [66113,66118]
===
match
---
simple_stmt [16881,16943]
simple_stmt [16881,16943]
===
match
---
operator: = [56957,56958]
operator: = [58673,58674]
===
match
---
atom_expr [32852,32871]
atom_expr [34568,34587]
===
match
---
expr_stmt [68113,68134]
expr_stmt [69829,69850]
===
match
---
name: sync_to_db [42503,42513]
name: sync_to_db [44219,44229]
===
match
---
name: previous_schedule [21081,21098]
name: previous_schedule [21081,21098]
===
match
---
number: 0 [25305,25306]
number: 0 [27021,27022]
===
match
---
argument [50920,50947]
argument [52636,52663]
===
match
---
simple_stmt [3796,3824]
simple_stmt [3796,3824]
===
match
---
string: "test_dag" [37503,37513]
string: "test_dag" [39219,39229]
===
match
---
atom_expr [64540,64555]
atom_expr [66256,66271]
===
match
---
name: dag_id [47760,47766]
name: dag_id [49476,49482]
===
match
---
name: TEST_DATE [43295,43304]
name: TEST_DATE [45011,45020]
===
match
---
operator: = [65938,65939]
operator: = [67654,67655]
===
match
---
atom_expr [47640,47651]
atom_expr [49356,49367]
===
match
---
simple_stmt [27258,27414]
simple_stmt [28974,29130]
===
match
---
parameters [66642,66648]
parameters [68358,68364]
===
match
---
operator: = [7437,7438]
operator: = [7437,7438]
===
match
---
operator: = [70739,70740]
operator: = [72455,72456]
===
match
---
assert_stmt [24745,24918]
assert_stmt [26461,26634]
===
match
---
name: DagRunType [42552,42562]
name: DagRunType [44268,44278]
===
match
---
operator: , [14052,14053]
operator: , [14052,14053]
===
match
---
suite [47357,47673]
suite [49073,49389]
===
match
---
name: datetime [795,803]
name: datetime [795,803]
===
match
---
atom_expr [61112,61152]
atom_expr [62828,62868]
===
match
---
trailer [32487,32500]
trailer [34203,34216]
===
match
---
name: start_date [43316,43326]
name: start_date [45032,45042]
===
match
---
name: start [22691,22696]
name: start [22691,22696]
===
match
---
name: set_is_paused [31738,31751]
name: set_is_paused [33454,33467]
===
match
---
name: MANUAL [47169,47175]
name: MANUAL [48885,48891]
===
match
---
name: pytest [68698,68704]
name: pytest [70414,70420]
===
match
---
operator: = [16891,16892]
operator: = [16891,16892]
===
match
---
atom_expr [48269,48324]
atom_expr [49985,50040]
===
match
---
operator: , [15575,15576]
operator: , [15575,15576]
===
match
---
argument [49840,49863]
argument [51556,51579]
===
match
---
atom_expr [62480,62496]
atom_expr [64196,64212]
===
match
---
trailer [43242,43305]
trailer [44958,45021]
===
match
---
arglist [50545,50598]
arglist [52261,52314]
===
match
---
name: DEFAULT_DATE [52518,52530]
name: DEFAULT_DATE [54234,54246]
===
match
---
suite [9443,10538]
suite [9443,10538]
===
match
---
number: 1 [3306,3307]
number: 1 [3306,3307]
===
match
---
name: params [3774,3780]
name: params [3774,3780]
===
match
---
argument [70448,70476]
argument [72164,72192]
===
match
---
trailer [52237,52404]
trailer [53953,54120]
===
match
---
comparison [37196,37231]
comparison [38912,38947]
===
match
---
operator: , [18607,18608]
operator: , [18607,18608]
===
match
---
argument [51664,51679]
argument [53380,53395]
===
match
---
name: task_id [8755,8762]
name: task_id [8755,8762]
===
match
---
operator: , [37584,37585]
operator: , [39300,39301]
===
match
---
operator: = [5258,5259]
operator: = [5258,5259]
===
match
---
string: 'op1' [19890,19895]
string: 'op1' [19890,19895]
===
match
---
assert_stmt [45683,45712]
assert_stmt [47399,47428]
===
match
---
name: ACTION_CAN_EDIT [63418,63433]
name: ACTION_CAN_EDIT [65134,65149]
===
match
---
operator: = [47553,47554]
operator: = [49269,49270]
===
match
---
decorator [68407,68454]
decorator [70123,70170]
===
match
---
operator: { [14238,14239]
operator: { [14238,14239]
===
match
---
name: op2 [35536,35539]
name: op2 [37252,37255]
===
match
---
argument [39154,39174]
argument [40870,40890]
===
match
---
name: dag_run [39682,39689]
name: dag_run [41398,41405]
===
match
---
name: task_instance [54624,54637]
name: task_instance [56340,56353]
===
match
---
trailer [29403,29405]
trailer [31119,31121]
===
match
---
sync_comp_for [15724,15748]
sync_comp_for [15724,15748]
===
match
---
simple_stmt [30434,30474]
simple_stmt [32150,32190]
===
match
---
operator: , [49480,49481]
operator: , [51196,51197]
===
match
---
suite [67917,68104]
suite [69633,69820]
===
match
---
param [45882,45886]
param [47598,47602]
===
match
---
trailer [19089,19098]
trailer [19089,19098]
===
match
---
name: num [68543,68546]
name: num [70259,70262]
===
match
---
atom_expr [50100,50123]
atom_expr [51816,51839]
===
match
---
operator: , [14294,14295]
operator: , [14294,14295]
===
match
---
name: t_1 [50545,50548]
name: t_1 [52261,52264]
===
match
---
name: DagRunType [2138,2148]
name: DagRunType [2138,2148]
===
match
---
simple_stmt [2471,2487]
simple_stmt [2471,2487]
===
match
---
string: '.template' [19382,19393]
string: '.template' [19382,19393]
===
match
---
trailer [62686,62709]
trailer [64402,64425]
===
match
---
atom_expr [14521,14540]
atom_expr [14521,14540]
===
match
---
atom_expr [71032,71049]
atom_expr [72748,72765]
===
match
---
dotted_name [1365,1383]
dotted_name [1365,1383]
===
match
---
arglist [8364,8403]
arglist [8364,8403]
===
match
---
name: dag_id [33132,33138]
name: dag_id [34848,34854]
===
match
---
operator: , [64312,64313]
operator: , [66028,66029]
===
match
---
operator: = [35511,35512]
operator: = [37227,37228]
===
match
---
string: 'op1' [6132,6137]
string: 'op1' [6132,6137]
===
match
---
operator: = [49584,49585]
operator: = [51300,51301]
===
match
---
atom_expr [68119,68134]
atom_expr [69835,69850]
===
match
---
name: state [47206,47211]
name: state [48922,48927]
===
match
---
trailer [38848,38863]
trailer [40564,40579]
===
match
---
trailer [44029,44036]
trailer [45745,45752]
===
match
---
atom_expr [70487,70504]
atom_expr [72203,72220]
===
match
---
name: default_args [35068,35080]
name: default_args [36784,36796]
===
match
---
name: test_next_dagrun_after_fake_scheduled_previous [40851,40897]
name: test_next_dagrun_after_fake_scheduled_previous [42567,42613]
===
match
---
operator: = [20966,20967]
operator: = [20966,20967]
===
match
---
operator: == [51178,51180]
operator: == [52894,52896]
===
match
---
expr_stmt [53695,53723]
expr_stmt [55411,55439]
===
match
---
trailer [29572,29579]
trailer [31288,31295]
===
match
---
simple_stmt [68565,68576]
simple_stmt [70281,70292]
===
match
---
assert_stmt [8186,8253]
assert_stmt [8186,8253]
===
match
---
name: permissions [63296,63307]
name: permissions [65012,65023]
===
match
---
name: DEFAULT_DATE [52174,52186]
name: DEFAULT_DATE [53890,53902]
===
match
---
name: j [14243,14244]
name: j [14243,14244]
===
match
---
funcdef [67534,67582]
funcdef [69250,69298]
===
match
---
suite [15897,15927]
suite [15897,15927]
===
match
---
atom_expr [17531,17549]
atom_expr [17531,17549]
===
match
---
string: 'dag-bulk-sync-3' [24810,24827]
string: 'dag-bulk-sync-3' [26526,26543]
===
match
---
name: minutes [57047,57054]
name: minutes [58763,58770]
===
match
---
name: DagModel [46096,46104]
name: DagModel [47812,47820]
===
match
---
operator: , [30187,30188]
operator: , [31903,31904]
===
match
---
simple_stmt [25655,25682]
simple_stmt [27371,27398]
===
match
---
operator: = [23788,23789]
operator: = [23788,23789]
===
match
---
operator: , [50661,50662]
operator: , [52377,52378]
===
match
---
name: session [29066,29073]
name: session [30782,30789]
===
match
---
atom_expr [29668,29690]
atom_expr [31384,31406]
===
match
---
name: TI [17170,17172]
name: TI [17170,17172]
===
match
---
simple_stmt [65311,65327]
simple_stmt [67027,67043]
===
match
---
operator: } [39647,39648]
operator: } [41363,41364]
===
match
---
atom_expr [21851,21867]
atom_expr [21851,21867]
===
match
---
simple_stmt [45401,45428]
simple_stmt [47117,47144]
===
match
---
arglist [70448,70504]
arglist [72164,72220]
===
match
---
atom_expr [35239,35279]
atom_expr [36955,36995]
===
match
---
string: '.template' [20043,20054]
string: '.template' [20043,20054]
===
match
---
name: task_id [37115,37122]
name: task_id [38831,38838]
===
match
---
name: datetime [59279,59287]
name: datetime [60995,61003]
===
match
---
operator: , [8936,8937]
operator: , [8936,8937]
===
match
---
number: 0 [27181,27182]
number: 0 [28897,28898]
===
match
---
name: remove [10338,10344]
name: remove [10338,10344]
===
match
---
operator: = [64798,64799]
operator: = [66514,66515]
===
match
---
name: datetime [55284,55292]
name: datetime [57000,57008]
===
match
---
name: paused_dags [32098,32109]
name: paused_dags [33814,33825]
===
match
---
string: 'noop_pipeline' [66844,66859]
string: 'noop_pipeline' [68560,68575]
===
match
---
name: get_num_task_instances [17600,17622]
name: get_num_task_instances [17600,17622]
===
match
---
trailer [3057,3067]
trailer [3057,3067]
===
match
---
trailer [34530,34532]
trailer [36246,36248]
===
match
---
number: 42 [66467,66469]
number: 42 [68183,68185]
===
match
---
operator: , [64963,64964]
operator: , [66679,66680]
===
match
---
expr_stmt [17014,17030]
expr_stmt [17014,17030]
===
match
---
trailer [54637,54643]
trailer [56353,56359]
===
match
---
operator: == [49212,49214]
operator: == [50928,50930]
===
match
---
atom_expr [36702,36717]
atom_expr [38418,38433]
===
match
---
trailer [54903,54926]
trailer [56619,56642]
===
match
---
simple_stmt [49308,49344]
simple_stmt [51024,51060]
===
match
---
name: MANUAL [47666,47672]
name: MANUAL [49382,49388]
===
match
---
operator: , [53586,53587]
operator: , [55302,55303]
===
match
---
operator: { [37706,37707]
operator: { [39422,39423]
===
match
---
argument [43265,43282]
argument [44981,44998]
===
match
---
trailer [56937,56994]
trailer [58653,58710]
===
match
---
name: dst_rule [22618,22626]
name: dst_rule [22618,22626]
===
match
---
operator: = [52339,52340]
operator: = [54055,54056]
===
match
---
atom_expr [64115,64125]
atom_expr [65831,65841]
===
match
---
simple_stmt [37096,37153]
simple_stmt [38812,38869]
===
match
---
argument [64930,64963]
argument [66646,66679]
===
match
---
expr_stmt [70948,70981]
expr_stmt [72664,72697]
===
match
---
comparison [55919,55940]
comparison [57635,57656]
===
match
---
name: DagModel [31499,31507]
name: DagModel [33215,33223]
===
match
---
string: """         Tests following_schedule a dag with a relativedelta schedule_interval         """ [23504,23597]
string: """         Tests following_schedule a dag with a relativedelta schedule_interval         """ [23504,23597]
===
match
---
name: tearDown [66586,66594]
name: tearDown [68302,68310]
===
match
---
trailer [24393,24400]
trailer [26109,26116]
===
match
---
atom [49466,49482]
atom [51182,51198]
===
match
---
number: 1 [49881,49882]
number: 1 [51597,51598]
===
match
---
term [55395,55413]
term [57111,57129]
===
match
---
trailer [53194,53200]
trailer [54910,54916]
===
match
---
param [30597,30602]
param [32313,32318]
===
match
---
name: test_dag_task_priority_weight_total_using_absolute [15171,15221]
name: test_dag_task_priority_weight_total_using_absolute [15171,15221]
===
match
---
trailer [10483,10486]
trailer [10483,10486]
===
match
---
name: convert [21752,21759]
name: convert [21752,21759]
===
match
---
name: State [42606,42611]
name: State [44322,44327]
===
match
---
name: op7 [7175,7178]
name: op7 [7175,7178]
===
match
---
name: DAG [25490,25493]
name: DAG [27206,27209]
===
match
---
name: timezone [64283,64291]
name: timezone [65999,66007]
===
match
---
trailer [15526,15703]
trailer [15526,15703]
===
match
---
assert_stmt [18120,18256]
assert_stmt [18120,18256]
===
match
---
name: ti_state_begin [53428,53442]
name: ti_state_begin [55144,55158]
===
match
---
dotted_name [1770,1794]
dotted_name [1770,1794]
===
match
---
name: days [59721,59725]
name: days [61437,61441]
===
match
---
simple_stmt [16724,16772]
simple_stmt [16724,16772]
===
match
---
arglist [12129,12139]
arglist [12129,12139]
===
match
---
number: 0 [56983,56984]
number: 0 [58699,58700]
===
match
---
name: airflow [1522,1529]
name: airflow [1522,1529]
===
match
---
trailer [58014,58016]
trailer [59730,59732]
===
match
---
operator: = [10660,10661]
operator: = [10660,10661]
===
match
---
operator: = [21125,21126]
operator: = [21125,21126]
===
match
---
for_stmt [14505,14756]
for_stmt [14505,14756]
===
match
---
expr_stmt [28652,28751]
expr_stmt [30368,30467]
===
match
---
operator: , [3181,3182]
operator: , [3181,3182]
===
match
---
name: run_id [39441,39447]
name: run_id [41157,41163]
===
match
---
name: BACKFILL_JOB [52064,52076]
name: BACKFILL_JOB [53780,53792]
===
match
---
name: task_id [6843,6850]
name: task_id [6843,6850]
===
match
---
atom_expr [18561,18651]
atom_expr [18561,18651]
===
match
---
param [47715,47719]
param [49431,49435]
===
match
---
name: start_date [43485,43495]
name: start_date [45201,45211]
===
match
---
name: State [53263,53268]
name: State [54979,54984]
===
match
---
operator: , [24607,24608]
operator: , [26323,26324]
===
match
---
operator: = [15420,15421]
operator: = [15420,15421]
===
match
---
atom_expr [52303,52315]
atom_expr [54019,54031]
===
match
---
simple_stmt [9452,9528]
simple_stmt [9452,9528]
===
match
---
expr_stmt [16952,17005]
expr_stmt [16952,17005]
===
match
---
simple_stmt [31137,31161]
simple_stmt [32853,32877]
===
match
---
arglist [37886,37921]
arglist [39602,39637]
===
match
---
name: dag [6659,6662]
name: dag [6659,6662]
===
match
---
operator: = [16956,16957]
operator: = [16956,16957]
===
match
---
trailer [40566,40573]
trailer [42282,42289]
===
match
---
name: dag_id [43101,43107]
name: dag_id [44817,44823]
===
match
---
name: group [14896,14901]
name: group [14896,14901]
===
match
---
simple_stmt [33421,33493]
simple_stmt [35137,35209]
===
match
---
trailer [23865,23884]
trailer [23865,23884]
===
match
---
string: "test_schedule_dag_fake_scheduled_previous" [41112,41155]
string: "test_schedule_dag_fake_scheduled_previous" [42828,42871]
===
match
---
trailer [55292,55302]
trailer [57008,57018]
===
match
---
name: State [47212,47217]
name: State [48928,48933]
===
match
---
operator: == [35597,35599]
operator: == [37313,37315]
===
match
---
name: all [25271,25274]
name: all [26987,26990]
===
match
---
operator: @ [67506,67507]
operator: @ [69222,69223]
===
match
---
atom_expr [26344,26396]
atom_expr [28060,28112]
===
match
---
simple_stmt [37169,37180]
simple_stmt [38885,38896]
===
match
---
string: "custom_is_set_to_manual" [47580,47605]
string: "custom_is_set_to_manual" [49296,49321]
===
match
---
atom_expr [69466,69541]
atom_expr [71182,71257]
===
match
---
operator: , [39294,39295]
operator: , [41010,41011]
===
match
---
atom_expr [22792,22818]
atom_expr [22792,22818]
===
match
---
trailer [64465,64469]
trailer [66181,66185]
===
match
---
name: creating_job_id [47908,47923]
name: creating_job_id [49624,49639]
===
match
---
name: child_dag_name [61646,61660]
name: child_dag_name [63362,63376]
===
match
---
name: dag_id [34684,34690]
name: dag_id [36400,36406]
===
match
---
argument [24572,24589]
argument [26288,26305]
===
match
---
expr_stmt [44013,44038]
expr_stmt [45729,45754]
===
match
---
name: value [69979,69984]
name: value [71695,71700]
===
match
---
expr_stmt [54071,54099]
expr_stmt [55787,55815]
===
match
---
operator: = [15003,15004]
operator: = [15003,15004]
===
match
---
atom_expr [34805,34839]
atom_expr [36521,36555]
===
match
---
operator: = [42605,42606]
operator: = [44321,44322]
===
match
---
trailer [68223,68230]
trailer [69939,69946]
===
match
---
trailer [17713,17759]
trailer [17713,17759]
===
match
---
operator: , [16484,16485]
operator: , [16484,16485]
===
match
---
atom_expr [34073,34091]
atom_expr [35789,35807]
===
match
---
name: session [65219,65226]
name: session [66935,66942]
===
match
---
expr_stmt [67214,67235]
expr_stmt [68930,68951]
===
match
---
operator: = [47754,47755]
operator: = [49470,49471]
===
match
---
name: DAG [15372,15375]
name: DAG [15372,15375]
===
match
---
param [36788,36792]
param [38504,38508]
===
match
---
name: ti3 [17518,17521]
name: ti3 [17518,17521]
===
match
---
atom_expr [49440,49450]
atom_expr [51156,51166]
===
match
---
operator: >> [38068,38070]
operator: >> [39784,39786]
===
match
---
arglist [31918,31959]
arglist [33634,33675]
===
match
---
operator: == [60294,60296]
operator: == [62010,62012]
===
match
---
simple_stmt [32567,32591]
simple_stmt [34283,34307]
===
match
---
trailer [42957,42965]
trailer [44673,44681]
===
match
---
name: utc [21717,21720]
name: utc [21717,21720]
===
match
---
atom_expr [28166,28193]
atom_expr [29882,29909]
===
match
---
name: prev_local [22827,22837]
name: prev_local [22827,22837]
===
match
---
name: next_dagrun [64218,64229]
name: next_dagrun [65934,65945]
===
match
---
name: dag_id [51462,51468]
name: dag_id [53178,53184]
===
match
---
expr_stmt [28487,28563]
expr_stmt [30203,30279]
===
match
---
atom_expr [45769,45788]
atom_expr [47485,47504]
===
match
---
trailer [32740,32742]
trailer [34456,34458]
===
match
---
name: op2 [6310,6313]
name: op2 [6310,6313]
===
match
---
atom [42824,42837]
atom [44540,44553]
===
match
---
trailer [22889,22899]
trailer [22889,22899]
===
match
---
operator: , [51878,51879]
operator: , [53594,53595]
===
match
---
suite [13299,13361]
suite [13299,13361]
===
match
---
atom_expr [63934,63963]
atom_expr [65650,65679]
===
match
---
argument [65906,65931]
argument [67622,67647]
===
match
---
operator: = [22737,22738]
operator: = [22737,22738]
===
match
---
atom_expr [28027,28044]
atom_expr [29743,29760]
===
match
---
name: self [67753,67757]
name: self [69469,69473]
===
match
---
name: self [66643,66647]
name: self [68359,68363]
===
match
---
operator: , [17187,17188]
operator: , [17187,17188]
===
match
---
name: airflow [1770,1777]
name: airflow [1770,1777]
===
match
---
atom_expr [32484,32500]
atom_expr [34200,34216]
===
match
---
assert_stmt [29244,29268]
assert_stmt [30960,30984]
===
match
---
name: next_date [57763,57772]
name: next_date [59479,59488]
===
match
---
name: relativedelta [1141,1154]
name: relativedelta [1141,1154]
===
match
---
name: start_date [15383,15393]
name: start_date [15383,15393]
===
match
---
number: 1 [34902,34903]
number: 1 [36618,36619]
===
match
---
trailer [60314,60326]
trailer [62030,62042]
===
match
---
atom_expr [26377,26388]
atom_expr [28093,28104]
===
match
---
name: op4 [9953,9956]
name: op4 [9953,9956]
===
match
---
atom_expr [24664,24690]
atom_expr [26380,26406]
===
match
---
atom_expr [57567,57753]
atom_expr [59283,59469]
===
match
---
trailer [32576,32590]
trailer [34292,34306]
===
match
---
name: resolve_template_files [19413,19435]
name: resolve_template_files [19413,19435]
===
match
---
name: dag [65781,65784]
name: dag [67497,67500]
===
match
---
atom_expr [56901,56928]
atom_expr [58617,58644]
===
match
---
trailer [33055,33072]
trailer [34771,34788]
===
match
---
trailer [17517,17522]
trailer [17517,17522]
===
match
---
assert_stmt [38654,38726]
assert_stmt [40370,40442]
===
match
---
operator: == [29353,29355]
operator: == [31069,31071]
===
match
---
number: 0 [3803,3804]
number: 0 [3803,3804]
===
match
---
name: jinja_env [18755,18764]
name: jinja_env [18755,18764]
===
match
---
trailer [29758,29766]
trailer [31474,31482]
===
match
---
name: params [4338,4344]
name: params [4338,4344]
===
match
---
name: settings [64049,64057]
name: settings [65765,65773]
===
match
---
arglist [4736,4794]
arglist [4736,4794]
===
match
---
dictorsetmaker [24302,24318]
dictorsetmaker [26018,26034]
===
match
---
name: remove [26467,26473]
name: remove [28183,28189]
===
match
---
atom_expr [41646,41656]
atom_expr [43362,43372]
===
match
---
atom_expr [17993,18111]
atom_expr [17993,18111]
===
match
---
atom [41645,41658]
atom [43361,43374]
===
match
---
trailer [24237,24239]
trailer [25953,25955]
===
match
---
operator: } [24917,24918]
operator: } [26633,26634]
===
match
---
trailer [59239,59251]
trailer [60955,60967]
===
match
---
fstring_end: " [47288,47289]
fstring_end: " [49004,49005]
===
match
---
argument [69294,69324]
argument [71010,71040]
===
match
---
operator: = [43360,43361]
operator: = [45076,45077]
===
match
---
name: test_dag_id [44370,44381]
name: test_dag_id [46086,46097]
===
match
---
name: owner [65933,65938]
name: owner [67649,67654]
===
match
---
atom [31614,31629]
atom [33330,33345]
===
match
---
name: DAGsubclass [44198,44209]
name: DAGsubclass [45914,45925]
===
match
---
assert_stmt [67684,67718]
assert_stmt [69400,69434]
===
match
---
name: start_date [39154,39164]
name: start_date [40870,40880]
===
match
---
name: session [31202,31209]
name: session [32918,32925]
===
match
---
operator: , [26226,26227]
operator: , [27942,27943]
===
match
---
simple_stmt [45256,45281]
simple_stmt [46972,46997]
===
match
---
arglist [11607,11705]
arglist [11607,11705]
===
match
---
name: DEFAULT_DATE [50387,50399]
name: DEFAULT_DATE [52103,52115]
===
match
---
simple_stmt [47498,47541]
simple_stmt [49214,49257]
===
match
---
trailer [69280,69456]
trailer [70996,71172]
===
match
---
name: dag_id [64108,64114]
name: dag_id [65824,65830]
===
match
---
expr_stmt [18555,18651]
expr_stmt [18555,18651]
===
match
---
operator: = [17963,17964]
operator: = [17963,17964]
===
match
---
trailer [62814,62837]
trailer [64530,64553]
===
match
---
name: test_following_previous_schedule_daily_dag_cet_to_cest [22354,22408]
name: test_following_previous_schedule_daily_dag_cet_to_cest [22354,22408]
===
match
---
name: dagrun_1 [50474,50482]
name: dagrun_1 [52190,52198]
===
match
---
operator: } [38238,38239]
operator: } [39954,39955]
===
match
---
name: test_dag_topological_sort1 [8489,8515]
name: test_dag_topological_sort1 [8489,8515]
===
match
---
atom_expr [65462,65477]
atom_expr [67178,67193]
===
match
---
name: subdag_id [30680,30689]
name: subdag_id [32396,32405]
===
match
---
atom [26095,26127]
atom [27811,27843]
===
match
---
number: 1 [60768,60769]
number: 1 [62484,62485]
===
match
---
operator: , [48076,48077]
operator: , [49792,49793]
===
match
---
name: DAG [44366,44369]
name: DAG [46082,46085]
===
match
---
trailer [38225,38233]
trailer [39941,39949]
===
match
---
name: dag [29844,29847]
name: dag [31560,31563]
===
match
---
trailer [13452,13460]
trailer [13452,13460]
===
match
---
operator: , [30899,30900]
operator: , [32615,32616]
===
match
---
atom_expr [41349,41529]
atom_expr [43065,43245]
===
match
---
name: DagRunType [52260,52270]
name: DagRunType [53976,53986]
===
match
---
trailer [50063,50077]
trailer [51779,51793]
===
match
---
suite [28478,29791]
suite [30194,31507]
===
match
---
name: start_date [35255,35265]
name: start_date [36971,36981]
===
match
---
name: op2 [35346,35349]
name: op2 [37062,37065]
===
match
---
name: DAG [35720,35723]
name: DAG [37436,37439]
===
match
---
name: tasks_count [65866,65877]
name: tasks_count [67582,67593]
===
match
---
name: dag_id [43154,43160]
name: dag_id [44870,44876]
===
match
---
simple_stmt [949,989]
simple_stmt [949,989]
===
match
---
name: dag_decorator [66659,66672]
name: dag_decorator [68375,68388]
===
match
---
operator: , [56243,56244]
operator: , [57959,57960]
===
match
---
simple_stmt [37662,37673]
simple_stmt [39378,39389]
===
match
---
name: DEFAULT_DATE [6795,6807]
name: DEFAULT_DATE [6795,6807]
===
match
---
atom [65678,65682]
atom [67394,67398]
===
match
---
name: run_type [50298,50306]
name: run_type [52014,52022]
===
match
---
arith_expr [17328,17369]
arith_expr [17328,17369]
===
match
---
assert_stmt [60963,61018]
assert_stmt [62679,62734]
===
match
---
name: dag_id [56206,56212]
name: dag_id [57922,57928]
===
match
---
name: create_session [26576,26590]
name: create_session [28292,28306]
===
match
---
import_from [989,1016]
import_from [989,1016]
===
match
---
name: e [3323,3324]
name: e [3323,3324]
===
match
---
assert_stmt [39468,39495]
assert_stmt [41184,41211]
===
match
---
operator: , [39874,39875]
operator: , [41590,41591]
===
match
---
operator: , [46609,46610]
operator: , [48325,48326]
===
match
---
simple_stmt [67618,67640]
simple_stmt [69334,69356]
===
match
---
atom_expr [29051,29082]
atom_expr [30767,30798]
===
match
---
param [56233,56244]
param [57949,57960]
===
match
---
atom_expr [47896,47906]
atom_expr [49612,49622]
===
match
---
name: datetime [20378,20386]
name: datetime [20378,20386]
===
match
---
simple_stmt [64867,65118]
simple_stmt [66583,66834]
===
match
---
atom_expr [32142,32152]
atom_expr [33858,33868]
===
match
---
name: _clean_up [48214,48223]
name: _clean_up [49930,49939]
===
match
---
trailer [40075,40077]
trailer [41791,41793]
===
match
---
name: create_dagrun [27952,27965]
name: create_dagrun [29668,29681]
===
match
---
trailer [25675,25681]
trailer [27391,27397]
===
match
---
trailer [53111,53118]
trailer [54827,54834]
===
match
---
operator: } [16542,16543]
operator: } [16542,16543]
===
match
---
operator: = [19331,19332]
operator: = [19331,19332]
===
match
---
trailer [28077,28087]
trailer [29793,29803]
===
match
---
trailer [68704,68711]
trailer [70420,70427]
===
match
---
trailer [40823,40833]
trailer [42539,42549]
===
match
---
string: 'DAG' [10905,10910]
string: 'DAG' [10905,10910]
===
match
---
simple_stmt [32841,32872]
simple_stmt [34557,34588]
===
match
---
trailer [42823,42838]
trailer [44539,44554]
===
match
---
simple_stmt [68179,68205]
simple_stmt [69895,69921]
===
match
---
import_from [1858,1892]
import_from [1858,1892]
===
match
---
operator: == [14563,14565]
operator: == [14563,14565]
===
match
---
atom [32061,32079]
atom [33777,33795]
===
match
---
name: task_dict [37693,37702]
name: task_dict [39409,39418]
===
match
---
name: set [29558,29561]
name: set [31274,31277]
===
match
---
trailer [6545,6560]
trailer [6545,6560]
===
match
---
name: next_date [60970,60979]
name: next_date [62686,62695]
===
match
---
name: next_dagrun_after_date [59160,59182]
name: next_dagrun_after_date [60876,60898]
===
match
---
number: 0 [61150,61151]
number: 0 [62866,62867]
===
match
---
trailer [66594,66596]
trailer [68310,68312]
===
match
---
operator: = [48678,48679]
operator: = [50394,50395]
===
match
---
dictorsetmaker [11980,12023]
dictorsetmaker [11980,12023]
===
match
---
trailer [29054,29065]
trailer [30770,30781]
===
match
---
expr_stmt [3274,3286]
expr_stmt [3274,3286]
===
match
---
name: weight [15311,15317]
name: weight [15311,15317]
===
match
---
simple_stmt [29459,29543]
simple_stmt [31175,31259]
===
match
---
name: self [42943,42947]
name: self [44659,44663]
===
match
---
trailer [32260,32270]
trailer [33976,33986]
===
match
---
trailer [28875,28886]
trailer [30591,30602]
===
match
---
name: sync_to_db [41542,41552]
name: sync_to_db [43258,43268]
===
match
---
name: DagModel [29133,29141]
name: DagModel [30849,30857]
===
match
---
name: op3 [38048,38051]
name: op3 [39764,39767]
===
match
---
number: 1 [49744,49745]
number: 1 [51460,51461]
===
match
---
fstring_expr [15567,15570]
fstring_expr [15567,15570]
===
match
---
param [36117,36121]
param [37833,37837]
===
match
---
name: task_id [49775,49782]
name: task_id [51491,51498]
===
match
---
testlist_comp [48063,48077]
testlist_comp [49779,49793]
===
match
---
atom [10661,10680]
atom [10661,10680]
===
match
---
string: "dag.callback_exceptions" [40763,40788]
string: "dag.callback_exceptions" [42479,42504]
===
match
---
comp_op [29305,29311]
comp_op [31021,31027]
===
match
---
name: dag [12413,12416]
name: dag [12413,12416]
===
match
---
name: op1 [37720,37723]
name: op1 [39436,39439]
===
match
---
operator: , [28973,28974]
operator: , [30689,30690]
===
match
---
fstring_expr [65927,65930]
fstring_expr [67643,67646]
===
match
---
name: self [2448,2452]
name: self [2448,2452]
===
match
---
funcdef [58452,59252]
funcdef [60168,60968]
===
match
---
atom_expr [60844,60900]
atom_expr [62560,62616]
===
match
---
trailer [29428,29440]
trailer [31144,31156]
===
match
---
import_from [1943,2008]
import_from [1943,2008]
===
match
---
trailer [43337,43344]
trailer [45053,45060]
===
match
---
name: expand [51290,51296]
name: expand [53006,53012]
===
match
---
simple_stmt [10418,10451]
simple_stmt [10418,10451]
===
match
---
operator: == [34516,34518]
operator: == [36232,36234]
===
match
---
return_stmt [69082,69092]
return_stmt [70798,70808]
===
match
---
name: owner [61257,61262]
name: owner [62973,62978]
===
match
---
operator: } [70408,70409]
operator: } [72124,72125]
===
match
---
name: dag_id [48224,48230]
name: dag_id [49940,49946]
===
match
---
name: orm_dag [34335,34342]
name: orm_dag [36051,36058]
===
match
---
name: tasks [9325,9330]
name: tasks [9325,9330]
===
match
---
trailer [9952,9957]
trailer [9952,9957]
===
match
---
operator: = [14884,14885]
operator: = [14884,14885]
===
match
---
operator: , [37127,37128]
operator: , [38843,38844]
===
match
---
operator: , [61137,61138]
operator: , [62853,62854]
===
match
---
trailer [3815,3822]
trailer [3815,3822]
===
match
---
operator: = [28980,28981]
operator: = [30696,30697]
===
match
---
atom_expr [33123,33138]
atom_expr [34839,34854]
===
match
---
operator: , [27478,27479]
operator: , [29194,29195]
===
match
---
comparison [23325,23378]
comparison [23325,23378]
===
match
---
atom_expr [11590,11715]
atom_expr [11590,11715]
===
match
---
string: 'owner1' [12893,12901]
string: 'owner1' [12893,12901]
===
match
---
simple_stmt [45043,45076]
simple_stmt [46759,46792]
===
match
---
suite [63493,63587]
suite [65209,65303]
===
match
---
string: 'dummy_task' [30810,30822]
string: 'dummy_task' [32526,32538]
===
match
---
atom_expr [50542,50599]
atom_expr [52258,52315]
===
match
---
name: start_date [52329,52339]
name: start_date [54045,54055]
===
match
---
argument [29066,29081]
argument [30782,30797]
===
match
---
expr_stmt [35038,35081]
expr_stmt [36754,36797]
===
match
---
name: op3 [35544,35547]
name: op3 [37260,37263]
===
match
---
atom [10925,10979]
atom [10925,10979]
===
match
---
trailer [8363,8404]
trailer [8363,8404]
===
match
---
trailer [47483,47488]
trailer [49199,49204]
===
match
---
trailer [48406,48414]
trailer [50122,50130]
===
match
---
name: set_upstream [9940,9952]
name: set_upstream [9940,9952]
===
match
---
name: task_states [53294,53305]
name: task_states [55010,55021]
===
match
---
name: session [18424,18431]
name: session [18424,18431]
===
match
---
name: orm_dag [33683,33690]
name: orm_dag [35399,35406]
===
match
---
name: dag [37926,37929]
name: dag [39642,39645]
===
match
---
atom_expr [7544,7576]
atom_expr [7544,7576]
===
match
---
name: exceptions [1373,1383]
name: exceptions [1373,1383]
===
match
---
name: dag [50060,50063]
name: dag [51776,51779]
===
match
---
funcdef [66904,67306]
funcdef [68620,69022]
===
match
---
operator: = [4344,4345]
operator: = [4344,4345]
===
match
---
trailer [60925,60948]
trailer [62641,62664]
===
match
---
name: enumerate [13126,13135]
name: enumerate [13126,13135]
===
match
---
name: name [35007,35011]
name: name [36723,36727]
===
match
---
trailer [44649,44687]
trailer [46365,46403]
===
match
---
atom_expr [25153,25205]
atom_expr [26869,26921]
===
match
---
name: days [48914,48918]
name: days [50630,50634]
===
match
---
atom [53343,53376]
atom [55059,55092]
===
match
---
name: get_is_paused [32639,32652]
name: get_is_paused [34355,34368]
===
match
---
atom_expr [23703,23746]
atom_expr [23703,23746]
===
match
---
name: session [18239,18246]
name: session [18239,18246]
===
match
---
name: next_date [60069,60078]
name: next_date [61785,61794]
===
match
---
name: states [18062,18068]
name: states [18062,18068]
===
match
---
name: get [28235,28238]
name: get [29951,29954]
===
match
---
string: "t1" [35328,35332]
string: "t1" [37044,37048]
===
match
---
atom [8586,8605]
atom [8586,8605]
===
match
---
atom_expr [49631,49653]
atom_expr [51347,51369]
===
match
---
name: timezone [35101,35109]
name: timezone [36817,36825]
===
match
---
simple_stmt [21775,21836]
simple_stmt [21775,21836]
===
match
---
trailer [50110,50123]
trailer [51826,51839]
===
match
---
trailer [71047,71049]
trailer [72763,72765]
===
match
---
name: dag_run_state [51438,51451]
name: dag_run_state [53154,53167]
===
match
---
name: local_tz [22189,22197]
name: local_tz [22189,22197]
===
match
---
operator: , [40651,40652]
operator: , [42367,42368]
===
match
---
name: timezone [60297,60305]
name: timezone [62013,62021]
===
match
---
trailer [9882,9887]
trailer [9882,9887]
===
match
---
simple_stmt [43177,43209]
simple_stmt [44893,44925]
===
match
---
comparison [44054,44092]
comparison [45770,45808]
===
match
---
arglist [4636,4710]
arglist [4636,4710]
===
match
---
name: name [35024,35028]
name: name [36740,36744]
===
match
---
dotted_name [1272,1293]
dotted_name [1272,1293]
===
match
---
operator: == [38131,38133]
operator: == [39847,39849]
===
match
---
argument [41295,41312]
argument [43011,43028]
===
match
---
name: DAG [47372,47375]
name: DAG [49088,49091]
===
match
---
trailer [60991,61000]
trailer [62707,62716]
===
match
---
name: dr [47427,47429]
name: dr [49143,49145]
===
match
---
expr_stmt [28869,28892]
expr_stmt [30585,30608]
===
match
---
atom_expr [61295,61327]
atom_expr [63011,63043]
===
match
---
assert_stmt [45762,45801]
assert_stmt [47478,47517]
===
match
---
expr_stmt [44613,44687]
expr_stmt [46329,46403]
===
match
---
comparison [12413,12446]
comparison [12413,12446]
===
match
---
name: TI [52579,52581]
name: TI [54295,54297]
===
match
---
atom_expr [30312,30343]
atom_expr [32028,32059]
===
match
---
simple_stmt [30654,30738]
simple_stmt [32370,32454]
===
match
---
number: 42 [47739,47741]
number: 42 [49455,49457]
===
match
---
suite [65603,65628]
suite [67319,67344]
===
match
---
operator: , [39133,39134]
operator: , [40849,40850]
===
match
---
name: task [16961,16965]
name: task [16961,16965]
===
match
---
name: subdag [49809,49815]
name: subdag [51525,51531]
===
match
---
atom_expr [70430,70505]
atom_expr [72146,72221]
===
match
---
operator: = [30854,30855]
operator: = [32570,32571]
===
match
---
trailer [36193,36230]
trailer [37909,37946]
===
match
---
trailer [12582,12604]
trailer [12582,12604]
===
match
---
argument [4304,4336]
argument [4304,4336]
===
match
---
name: timezone [66314,66322]
name: timezone [68030,68038]
===
match
---
name: DEFAULT_DATE [43941,43953]
name: DEFAULT_DATE [45657,45669]
===
match
---
parameters [67490,67492]
parameters [69206,69208]
===
match
---
trailer [70542,70545]
trailer [72258,72261]
===
match
---
operator: = [37953,37954]
operator: = [39669,39670]
===
match
---
parameters [65588,65594]
parameters [67304,67310]
===
match
---
suite [39888,40842]
suite [41604,42558]
===
match
---
arith_expr [15006,15028]
arith_expr [15006,15028]
===
match
---
string: 'owner2' [29607,29615]
string: 'owner2' [31323,31331]
===
match
---
simple_stmt [35575,35611]
simple_stmt [37291,37327]
===
match
---
name: patcher_dag_code [2723,2739]
name: patcher_dag_code [2723,2739]
===
match
---
fstring_string: stage [15562,15567]
fstring_string: stage [15562,15567]
===
match
---
trailer [49635,49645]
trailer [51351,51361]
===
match
---
atom_expr [43410,43432]
atom_expr [45126,45148]
===
match
---
simple_stmt [8026,8100]
simple_stmt [8026,8100]
===
match
---
number: 3 [65679,65680]
number: 3 [67395,67396]
===
match
---
expr_stmt [5911,5986]
expr_stmt [5911,5986]
===
match
---
operator: = [33012,33013]
operator: = [34728,34729]
===
match
---
atom [32410,32480]
atom [34126,34196]
===
match
---
operator: = [57161,57162]
operator: = [58877,58878]
===
match
---
simple_stmt [3044,3136]
simple_stmt [3044,3136]
===
match
---
expr_stmt [6151,6195]
expr_stmt [6151,6195]
===
match
---
name: session [52413,52420]
name: session [54129,54136]
===
match
---
arith_expr [55396,55404]
arith_expr [57112,57120]
===
match
---
atom [46513,46542]
atom [48229,48258]
===
match
---
atom_expr [20022,20039]
atom_expr [20022,20039]
===
match
---
simple_stmt [24513,24613]
simple_stmt [26229,26329]
===
match
---
operator: = [55773,55774]
operator: = [57489,57490]
===
match
---
name: tags [25580,25584]
name: tags [27296,27300]
===
match
---
name: utcnow [69358,69364]
name: utcnow [71074,71080]
===
match
---
operator: = [65828,65829]
operator: = [67544,67545]
===
match
---
name: test_task [17302,17311]
name: test_task [17302,17311]
===
match
---
operator: , [54283,54284]
operator: , [55999,56000]
===
match
---
name: isinstance [69968,69978]
name: isinstance [71684,71694]
===
match
---
expr_stmt [55475,55566]
expr_stmt [57191,57282]
===
match
---
operator: , [46743,46744]
operator: , [48459,48460]
===
match
---
arglist [33961,34010]
arglist [35677,35726]
===
match
---
atom_expr [6002,6072]
atom_expr [6002,6072]
===
match
---
decorator [67102,67118]
decorator [68818,68834]
===
match
---
assert_stmt [18704,18739]
assert_stmt [18704,18739]
===
match
---
expr_stmt [69106,69134]
expr_stmt [70822,70850]
===
match
---
trailer [21027,21029]
trailer [21027,21029]
===
match
---
atom_expr [17780,17864]
atom_expr [17780,17864]
===
match
---
name: VALUE [66459,66464]
name: VALUE [68175,68180]
===
match
---
trailer [47375,47418]
trailer [49091,49134]
===
match
---
parameters [68479,68486]
parameters [70195,70202]
===
match
---
simple_stmt [36389,36407]
simple_stmt [38105,38123]
===
match
---
operator: = [29935,29936]
operator: = [31651,31652]
===
match
---
operator: , [41187,41188]
operator: , [42903,42904]
===
match
---
operator: } [15569,15570]
operator: } [15569,15570]
===
match
---
suite [7486,7577]
suite [7486,7577]
===
match
---
trailer [51983,51991]
trailer [53699,53707]
===
match
---
name: FAILED [50149,50155]
name: FAILED [51865,51871]
===
match
---
name: test_create_dagrun_job_id_is_set [47682,47714]
name: test_create_dagrun_job_id_is_set [49398,49430]
===
match
---
name: info [10095,10099]
name: info [10095,10099]
===
match
---
simple_stmt [22290,22345]
simple_stmt [22290,22345]
===
match
---
atom_expr [23911,23928]
atom_expr [23911,23928]
===
match
---
trailer [12011,12023]
trailer [12011,12023]
===
match
---
operator: = [40151,40152]
operator: = [41867,41868]
===
match
---
trailer [64520,64529]
trailer [66236,66245]
===
match
---
simple_stmt [67167,67178]
simple_stmt [68883,68894]
===
match
---
trailer [32942,32995]
trailer [34658,34711]
===
match
---
name: query [2860,2865]
name: query [2860,2865]
===
match
---
arglist [47149,47222]
arglist [48865,48938]
===
match
---
name: dag_decorator [70713,70726]
name: dag_decorator [72429,72442]
===
match
---
argument [30209,30232]
argument [31925,31948]
===
match
---
trailer [17783,17806]
trailer [17783,17806]
===
match
---
name: unpaused_dags [31381,31394]
name: unpaused_dags [33097,33110]
===
match
---
atom_expr [8741,8767]
atom_expr [8741,8767]
===
match
---
trailer [24667,24684]
trailer [26383,26400]
===
match
---
atom [26810,27025]
atom [28526,28741]
===
match
---
atom_expr [21743,21765]
atom_expr [21743,21765]
===
match
---
name: end_date [55532,55540]
name: end_date [57248,57256]
===
match
---
name: session [2852,2859]
name: session [2852,2859]
===
match
---
name: job_id [47978,47984]
name: job_id [49694,49700]
===
match
---
operator: = [12933,12934]
operator: = [12933,12934]
===
match
---
suite [51453,53218]
suite [53169,54934]
===
match
---
operator: , [24545,24546]
operator: , [26261,26262]
===
match
---
trailer [17133,17139]
trailer [17133,17139]
===
match
---
name: range [14404,14409]
name: range [14404,14409]
===
match
---
operator: } [63352,63353]
operator: } [65068,65069]
===
match
---
assert_stmt [9367,9400]
assert_stmt [9367,9400]
===
match
---
expr_stmt [39054,39078]
expr_stmt [40770,40794]
===
match
---
argument [48935,48962]
argument [50651,50678]
===
match
---
trailer [40808,40810]
trailer [42524,42526]
===
match
---
parameters [66562,66568]
parameters [68278,68284]
===
match
---
operator: = [61251,61252]
operator: = [62967,62968]
===
match
---
trailer [19032,19037]
trailer [19032,19037]
===
match
---
name: dag [44875,44878]
name: dag [46591,46594]
===
match
---
name: dag [66875,66878]
name: dag [68591,68594]
===
match
---
comparison [23171,23219]
comparison [23171,23219]
===
match
---
name: Session [64849,64856]
name: Session [66565,66572]
===
match
---
name: date [55852,55856]
name: date [57568,57572]
===
match
---
string: 'dag_default_view' [5034,5052]
string: 'dag_default_view' [5034,5052]
===
match
---
name: query [46239,46244]
name: query [47955,47960]
===
match
---
atom_expr [48036,48046]
atom_expr [49752,49762]
===
match
---
argument [68926,68956]
argument [70642,70672]
===
match
---
operator: == [53201,53203]
operator: == [54917,54919]
===
match
---
trailer [47217,47222]
trailer [48933,48938]
===
match
---
expr_stmt [7322,7461]
expr_stmt [7322,7461]
===
match
---
simple_stmt [69106,69135]
simple_stmt [70822,70851]
===
match
---
argument [58797,58837]
argument [60513,60553]
===
match
---
number: 2 [61943,61944]
number: 2 [63659,63660]
===
match
---
atom [64501,64503]
atom [66217,66219]
===
match
---
operator: == [65420,65422]
operator: == [67136,67138]
===
match
---
atom_expr [10704,10726]
atom_expr [10704,10726]
===
match
---
atom_expr [42261,42282]
atom_expr [43977,43998]
===
match
---
simple_stmt [55337,55363]
simple_stmt [57053,57079]
===
match
---
name: DAG [11955,11958]
name: DAG [11955,11958]
===
match
---
trailer [37065,37079]
trailer [38781,38795]
===
match
---
operator: , [56969,56970]
operator: , [58685,58686]
===
match
---
trailer [31837,31843]
trailer [33553,33559]
===
match
---
name: default_args [10648,10660]
name: default_args [10648,10660]
===
match
---
trailer [51906,51917]
trailer [53622,53633]
===
match
---
argument [65017,65078]
argument [66733,66794]
===
match
---
atom_expr [27985,27998]
atom_expr [29701,29714]
===
match
---
atom_expr [53119,53132]
atom_expr [54835,54848]
===
match
---
atom [53255,53274]
atom [54971,54990]
===
match
---
name: SHUTDOWN [53366,53374]
name: SHUTDOWN [55082,55090]
===
match
---
name: dag_id [30403,30409]
name: dag_id [32119,32125]
===
match
---
number: 1 [52860,52861]
number: 1 [54576,54577]
===
match
---
operator: , [32040,32041]
operator: , [33756,33757]
===
match
---
atom_expr [9864,9887]
atom_expr [9864,9887]
===
match
---
name: local_tz [20968,20976]
name: local_tz [20968,20976]
===
match
---
name: DummyOperator [6370,6383]
name: DummyOperator [6370,6383]
===
match
---
trailer [14007,14029]
trailer [14007,14029]
===
match
---
operator: { [16524,16525]
operator: { [16524,16525]
===
match
---
funcdef [30571,32501]
funcdef [32287,34217]
===
match
---
name: dag2 [6290,6294]
name: dag2 [6290,6294]
===
match
---
atom_expr [21570,21600]
atom_expr [21570,21600]
===
match
---
simple_stmt [66868,66899]
simple_stmt [68584,68615]
===
match
---
name: DAG [32670,32673]
name: DAG [34386,34389]
===
match
---
name: owner [23803,23808]
name: owner [23803,23808]
===
match
---
operator: = [70018,70019]
operator: = [71734,71735]
===
match
---
assert_stmt [9109,9144]
assert_stmt [9109,9144]
===
match
---
trailer [52452,52458]
trailer [54168,54174]
===
match
---
operator: = [49880,49881]
operator: = [51596,51597]
===
match
---
trailer [9867,9882]
trailer [9867,9882]
===
match
---
operator: = [59749,59750]
operator: = [61465,61466]
===
match
---
trailer [47435,47449]
trailer [49151,49165]
===
match
---
trailer [52658,52675]
trailer [54374,54391]
===
match
---
operator: , [46542,46543]
operator: , [48258,48259]
===
match
---
argument [43243,43263]
argument [44959,44979]
===
match
---
atom_expr [44638,44687]
atom_expr [46354,46403]
===
match
---
name: b [3433,3434]
name: b [3433,3434]
===
match
---
trailer [40065,40075]
trailer [41781,41791]
===
match
---
atom_expr [22713,22775]
atom_expr [22713,22775]
===
match
---
simple_stmt [20564,20601]
simple_stmt [20564,20601]
===
match
---
name: op3 [10534,10537]
name: op3 [10534,10537]
===
match
---
name: dag [12083,12086]
name: dag [12083,12086]
===
match
---
simple_stmt [30312,30344]
simple_stmt [32028,32060]
===
match
---
atom_expr [19125,19199]
atom_expr [19125,19199]
===
match
---
name: _occur_before [8425,8438]
name: _occur_before [8425,8438]
===
match
---
operator: = [30219,30220]
operator: = [31935,31936]
===
match
---
comparison [55957,55997]
comparison [57673,57713]
===
match
---
operator: = [8784,8785]
operator: = [8784,8785]
===
match
---
for_stmt [27095,27196]
for_stmt [28811,28912]
===
match
---
trailer [40429,40487]
trailer [42145,42203]
===
match
---
name: execution_date [50634,50648]
name: execution_date [52350,52364]
===
match
---
simple_stmt [34987,35029]
simple_stmt [36703,36745]
===
match
---
trailer [57541,57548]
trailer [59257,59264]
===
match
---
name: task_id [16907,16914]
name: task_id [16907,16914]
===
match
---
string: 'dag-bulk-sync-3' [26245,26262]
string: 'dag-bulk-sync-3' [27961,27978]
===
match
---
trailer [67637,67639]
trailer [69353,69355]
===
match
---
name: success [40705,40712]
name: success [42421,42428]
===
match
---
name: op1 [10246,10249]
name: op1 [10246,10249]
===
match
---
name: task_id [36317,36324]
name: task_id [38033,38040]
===
match
---
trailer [31241,31248]
trailer [32957,32964]
===
match
---
operator: = [12110,12111]
operator: = [12110,12111]
===
match
---
trailer [29502,29536]
trailer [31218,31252]
===
match
---
name: filter [2970,2976]
name: filter [2970,2976]
===
match
---
trailer [42819,42823]
trailer [44535,44539]
===
match
---
name: DAG [24521,24524]
name: DAG [26237,26240]
===
match
---
operator: == [71085,71087]
operator: == [72801,72803]
===
match
---
name: end_date [55523,55531]
name: end_date [57239,57247]
===
match
---
string: 'owner' [16525,16532]
string: 'owner' [16525,16532]
===
match
---
trailer [17599,17622]
trailer [17599,17622]
===
match
---
param [60370,60374]
param [62086,62090]
===
match
---
name: dag [35764,35767]
name: dag [37480,37483]
===
match
---
trailer [64233,64244]
trailer [65949,65960]
===
match
---
for_stmt [25219,25320]
for_stmt [26935,27036]
===
match
---
name: op1 [35531,35534]
name: op1 [37247,37250]
===
match
---
atom_expr [24489,24504]
atom_expr [26205,26220]
===
match
---
trailer [54265,54275]
trailer [55981,55991]
===
match
---
name: DEFAULT_DATE [48880,48892]
name: DEFAULT_DATE [50596,50608]
===
match
---
string: 'owner' [15422,15429]
string: 'owner' [15422,15429]
===
match
---
name: dag_id [40834,40840]
name: dag_id [42550,42556]
===
match
---
suite [67089,67205]
suite [68805,68921]
===
match
---
atom_expr [13324,13360]
atom_expr [13324,13360]
===
match
---
operator: = [22762,22763]
operator: = [22762,22763]
===
match
---
suite [18888,19484]
suite [18888,19484]
===
match
---
dictorsetmaker [32033,32080]
dictorsetmaker [33749,33796]
===
match
---
parameters [12491,12497]
parameters [12491,12497]
===
match
---
name: set1 [10276,10280]
name: set1 [10276,10280]
===
match
---
operator: - [3284,3285]
operator: - [3284,3285]
===
match
---
name: end_date [48871,48879]
name: end_date [50587,50595]
===
match
---
argument [63923,63963]
argument [65639,65679]
===
match
---
trailer [18431,18437]
trailer [18431,18437]
===
match
---
operator: , [44667,44668]
operator: , [46383,46384]
===
match
---
operator: , [8385,8386]
operator: , [8385,8386]
===
match
---
testlist_comp [36033,36041]
testlist_comp [37749,37757]
===
match
---
funcdef [67724,68268]
funcdef [69440,69984]
===
match
---
simple_stmt [70907,70936]
simple_stmt [72623,72652]
===
match
---
expr_stmt [7822,7861]
expr_stmt [7822,7861]
===
match
---
name: orientation [5653,5664]
name: orientation [5653,5664]
===
match
---
operator: , [63323,63324]
operator: , [65039,65040]
===
match
---
trailer [35892,35906]
trailer [37608,37622]
===
match
---
assert_stmt [27882,27933]
assert_stmt [29598,29649]
===
match
---
name: dag [55775,55778]
name: dag [57491,57494]
===
match
---
name: subdag_id [31520,31529]
name: subdag_id [33236,33245]
===
match
---
name: start [2621,2626]
name: start [2621,2626]
===
match
---
argument [21648,21677]
argument [21648,21677]
===
match
---
trailer [52458,52468]
trailer [54174,54184]
===
match
---
assert_stmt [22067,22122]
assert_stmt [22067,22122]
===
match
---
name: _next [20689,20694]
name: _next [20689,20694]
===
match
---
trailer [31900,31973]
trailer [33616,33689]
===
match
---
simple_stmt [64414,64472]
simple_stmt [66130,66188]
===
match
---
name: DAG [65787,65790]
name: DAG [67503,67506]
===
match
---
atom_expr [54754,54878]
atom_expr [56470,56594]
===
match
---
name: op3 [9729,9732]
name: op3 [9729,9732]
===
match
---
argument [27480,27503]
argument [29196,29219]
===
match
---
name: include_subdag_tasks [8073,8093]
name: include_subdag_tasks [8073,8093]
===
match
---
name: default_args [4304,4316]
name: default_args [4304,4316]
===
match
---
operator: { [4317,4318]
operator: { [4317,4318]
===
match
---
number: 2 [65990,65991]
number: 2 [67706,67707]
===
match
---
name: subdag [62376,62382]
name: subdag [64092,64098]
===
match
---
argument [5953,5985]
argument [5953,5985]
===
match
---
name: test_rich_comparison_ops [44102,44126]
name: test_rich_comparison_ops [45818,45842]
===
match
---
name: test_field [19915,19925]
name: test_field [19915,19925]
===
match
---
name: dag [49938,49941]
name: dag [51654,51657]
===
match
---
trailer [21476,21484]
trailer [21476,21484]
===
match
---
expr_stmt [49685,49746]
expr_stmt [51401,51462]
===
match
---
argument [50344,50362]
argument [52060,52078]
===
match
---
operator: = [4659,4660]
operator: = [4659,4660]
===
match
---
atom_expr [28067,28087]
atom_expr [29783,29803]
===
match
---
operator: = [17117,17118]
operator: = [17117,17118]
===
match
---
assert_stmt [39426,39459]
assert_stmt [41142,41175]
===
match
---
name: start_date [6784,6794]
name: start_date [6784,6794]
===
match
---
simple_stmt [40379,40396]
simple_stmt [42095,42112]
===
match
---
name: TEST_DATE [23833,23842]
name: TEST_DATE [23833,23842]
===
match
---
simple_stmt [19637,19647]
simple_stmt [19637,19647]
===
match
---
param [69915,69918]
param [71631,71634]
===
match
---
sync_comp_for [13017,13041]
sync_comp_for [13017,13041]
===
match
---
suite [58527,59252]
suite [60243,60968]
===
match
---
expr_stmt [22132,22167]
expr_stmt [22132,22167]
===
match
---
name: depth [14472,14477]
name: depth [14472,14477]
===
match
---
operator: , [65106,65107]
operator: , [66822,66823]
===
match
---
atom_expr [52495,52552]
atom_expr [54211,54268]
===
match
---
name: delta [55560,55565]
name: delta [57276,57281]
===
match
---
name: roots [35590,35595]
name: roots [37306,37311]
===
match
---
name: DAG [49818,49821]
name: DAG [51534,51537]
===
match
---
operator: , [57624,57625]
operator: , [59340,59341]
===
match
---
comparison [57521,57550]
comparison [59237,59266]
===
match
---
parameters [54732,54738]
parameters [56448,56454]
===
match
---
trailer [67201,67204]
trailer [68917,68920]
===
match
---
name: set [29180,29183]
name: set [30896,30899]
===
match
---
name: start_date [16848,16858]
name: start_date [16848,16858]
===
match
---
operator: == [23125,23127]
operator: == [23125,23127]
===
match
---
name: jinja_udf [18640,18649]
name: jinja_udf [18640,18649]
===
match
---
trailer [22248,22250]
trailer [22248,22250]
===
match
---
simple_stmt [7198,7220]
simple_stmt [7198,7220]
===
match
---
argument [53869,53892]
argument [55585,55608]
===
match
---
atom_expr [2852,2939]
atom_expr [2852,2939]
===
match
---
trailer [22591,22600]
trailer [22591,22600]
===
match
---
comparison [9202,9230]
comparison [9202,9230]
===
match
---
name: previous_schedule [22796,22813]
name: previous_schedule [22796,22813]
===
match
---
name: dag [23236,23239]
name: dag [23236,23239]
===
match
---
name: session [26348,26355]
name: session [28064,28071]
===
match
---
atom [18630,18650]
atom [18630,18650]
===
match
---
operator: = [52889,52890]
operator: = [54605,54606]
===
match
---
name: DagModel [30394,30402]
name: DagModel [32110,32118]
===
match
---
trailer [21938,21943]
trailer [21938,21943]
===
match
---
trailer [19728,19733]
trailer [19728,19733]
===
match
---
simple_stmt [69225,69249]
simple_stmt [70941,70965]
===
match
---
simple_stmt [20689,20725]
simple_stmt [20689,20725]
===
match
---
arglist [26362,26388]
arglist [28078,28104]
===
match
---
expr_stmt [34212,34285]
expr_stmt [35928,36001]
===
match
---
name: width [15019,15024]
name: width [15019,15024]
===
match
---
argument [30913,30936]
argument [32629,32652]
===
match
---
name: set_upstream [16061,16073]
name: set_upstream [16061,16073]
===
match
---
trailer [62252,62263]
trailer [63968,63979]
===
match
---
name: prev [21851,21855]
name: prev [21851,21855]
===
match
---
name: unittest [2414,2422]
name: unittest [2414,2422]
===
match
---
trailer [51991,51993]
trailer [53707,53709]
===
match
---
operator: , [50362,50363]
operator: , [52078,52079]
===
match
---
import_from [1430,1516]
import_from [1430,1516]
===
match
---
argument [20630,20646]
argument [20630,20646]
===
match
---
name: filter [33116,33122]
name: filter [34832,34838]
===
match
---
operator: , [49450,49451]
operator: , [51166,51167]
===
match
---
funcdef [35616,36093]
funcdef [37332,37809]
===
match
---
argument [35736,35759]
argument [37452,37475]
===
match
---
name: dag [63602,63605]
name: dag [65318,65321]
===
match
---
simple_stmt [12543,12554]
simple_stmt [12543,12554]
===
match
---
expr_stmt [40147,40370]
expr_stmt [41863,42086]
===
match
---
string: 'start_date' [62416,62428]
string: 'start_date' [64132,64144]
===
match
---
name: start_date [28529,28539]
name: start_date [30245,30255]
===
match
---
name: value [68986,68991]
name: value [70702,70707]
===
match
---
comparison [24387,24421]
comparison [26103,26137]
===
match
---
name: owner [30110,30115]
name: owner [31826,31831]
===
match
---
name: template_file [19929,19942]
name: template_file [19929,19942]
===
match
---
name: max_active_tasks [64139,64155]
name: max_active_tasks [65855,65871]
===
match
---
assert_stmt [20779,20834]
assert_stmt [20779,20834]
===
match
---
operator: = [10807,10808]
operator: = [10807,10808]
===
match
---
name: DEFAULT_DATE [17204,17216]
name: DEFAULT_DATE [17204,17216]
===
match
---
name: days [58879,58883]
name: days [60595,60599]
===
match
---
name: datetime [60306,60314]
name: datetime [62022,62030]
===
match
---
atom_expr [51321,51331]
atom_expr [53037,53047]
===
match
---
name: assert_queries_count [24627,24647]
name: assert_queries_count [26343,26363]
===
match
---
operator: = [70186,70187]
operator: = [71902,71903]
===
match
---
simple_stmt [7822,7862]
simple_stmt [7822,7862]
===
match
---
name: self [45882,45886]
name: self [47598,47602]
===
match
---
string: "t3" [35901,35905]
string: "t3" [37617,37621]
===
match
---
name: task_id [15552,15559]
name: task_id [15552,15559]
===
match
---
operator: , [21519,21520]
operator: , [21519,21520]
===
match
---
atom_expr [9239,9272]
atom_expr [9239,9272]
===
match
---
name: DagModel [31442,31450]
name: DagModel [33158,33166]
===
match
---
operator: == [29519,29521]
operator: == [31235,31237]
===
match
---
operator: = [64717,64718]
operator: = [66433,66434]
===
match
---
testlist_comp [26047,26076]
testlist_comp [27763,27792]
===
match
---
param [20204,20208]
param [20204,20208]
===
match
---
comparison [53188,53217]
comparison [54904,54933]
===
match
---
name: xcom_pass_to_op [70771,70786]
name: xcom_pass_to_op [72487,72502]
===
match
---
atom_expr [36441,36454]
atom_expr [38157,38170]
===
match
---
name: session [34194,34201]
name: session [35910,35917]
===
match
---
argument [47847,47888]
argument [49563,49604]
===
match
---
atom [48062,48078]
atom [49778,49794]
===
match
---
name: operator [69172,69180]
name: operator [70888,70896]
===
match
---
assert_stmt [44047,44092]
assert_stmt [45763,45808]
===
match
---
fstring_end: ' [65930,65931]
fstring_end: ' [67646,67647]
===
match
---
name: dag [66006,66009]
name: dag [67722,67725]
===
match
---
suite [67493,67609]
suite [69209,69325]
===
match
---
arglist [68161,68169]
arglist [69877,69885]
===
match
---
operator: , [25780,25781]
operator: , [27496,27497]
===
match
---
operator: = [3303,3304]
operator: = [3303,3304]
===
match
---
name: xcom_pass_to_op [69825,69840]
name: xcom_pass_to_op [71541,71556]
===
match
---
trailer [11825,11839]
trailer [11825,11839]
===
match
---
operator: == [21189,21191]
operator: == [21189,21191]
===
match
---
name: freeze_time [59258,59269]
name: freeze_time [60974,60985]
===
match
---
trailer [6170,6195]
trailer [6170,6195]
===
match
---
name: flush [65163,65168]
name: flush [66879,66884]
===
match
---
name: task_id [7078,7085]
name: task_id [7078,7085]
===
match
---
atom_expr [33944,34020]
atom_expr [35660,35736]
===
match
---
trailer [20923,20941]
trailer [20923,20941]
===
match
---
trailer [47241,47248]
trailer [48957,48964]
===
match
---
simple_stmt [15119,15162]
simple_stmt [15119,15162]
===
match
---
simple_stmt [17873,17973]
simple_stmt [17873,17973]
===
match
---
trailer [9182,9185]
trailer [9182,9185]
===
match
---
comparison [59952,59994]
comparison [61668,61710]
===
match
---
name: DummyOperator [29985,29998]
name: DummyOperator [31701,31714]
===
match
---
name: test_new_dag_is_paused_upon_creation [32881,32917]
name: test_new_dag_is_paused_upon_creation [34597,34633]
===
match
---
name: datetime [11994,12002]
name: datetime [11994,12002]
===
match
---
parameters [55136,55142]
parameters [56852,56858]
===
match
---
operator: != [45180,45182]
operator: != [46896,46898]
===
match
---
name: dag [38186,38189]
name: dag [39902,39905]
===
match
---
name: FAILED [50356,50362]
name: FAILED [52072,52078]
===
match
---
operator: = [69115,69116]
operator: = [70831,70832]
===
match
---
string: 'webserver' [5021,5032]
string: 'webserver' [5021,5032]
===
match
---
expr_stmt [53748,53944]
expr_stmt [55464,55660]
===
match
---
arglist [28956,29004]
arglist [30672,30720]
===
match
---
argument [5334,5367]
argument [5334,5367]
===
match
---
with_stmt [26571,27196]
with_stmt [28287,28912]
===
match
---
name: access_control [63550,63564]
name: access_control [65266,65280]
===
match
---
name: dagrun_2 [52206,52214]
name: dagrun_2 [53922,53930]
===
match
---
trailer [61321,61327]
trailer [63037,63043]
===
match
---
name: test_utils [2305,2315]
name: test_utils [2305,2315]
===
match
---
name: dag_subclass [44546,44558]
name: dag_subclass [46262,46274]
===
match
---
operator: = [30283,30284]
operator: = [31999,32000]
===
match
---
expr_stmt [7946,7985]
expr_stmt [7946,7985]
===
match
---
name: AirflowException [1391,1407]
name: AirflowException [1391,1407]
===
match
---
name: expand [49409,49415]
name: expand [51125,51131]
===
match
---
simple_stmt [29173,29236]
simple_stmt [30889,30952]
===
match
---
name: start_date [70263,70273]
name: start_date [71979,71989]
===
match
---
name: minute [56951,56957]
name: minute [58667,58673]
===
match
---
trailer [65064,65078]
trailer [66780,66794]
===
match
---
name: query [28219,28224]
name: query [29935,29940]
===
match
---
name: dag_id [58055,58061]
name: dag_id [59771,59777]
===
match
---
operator: { [12376,12377]
operator: { [12376,12377]
===
match
---
with_stmt [9617,10028]
with_stmt [9617,10028]
===
match
---
simple_stmt [10784,10838]
simple_stmt [10784,10838]
===
match
---
name: dagrun [53188,53194]
name: dagrun [54904,54910]
===
match
---
operator: = [67218,67219]
operator: = [68934,68935]
===
match
---
arglist [21485,21553]
arglist [21485,21553]
===
match
---
name: merge [52453,52458]
name: merge [54169,54174]
===
match
---
argument [8755,8766]
argument [8755,8766]
===
match
---
name: f [19604,19605]
name: f [19604,19605]
===
match
---
trailer [51156,51163]
trailer [52872,52879]
===
match
---
name: dag [51685,51688]
name: dag [53401,53404]
===
match
---
string: 'dag-bulk-sync-2' [25782,25799]
string: 'dag-bulk-sync-2' [27498,27515]
===
match
---
trailer [16569,16576]
trailer [16569,16576]
===
match
---
simple_stmt [52684,52715]
simple_stmt [54400,54431]
===
match
---
trailer [19237,19252]
trailer [19237,19252]
===
match
---
parameters [27242,27248]
parameters [28958,28964]
===
match
---
operator: * [13651,13652]
operator: * [13651,13652]
===
match
---
name: days [52855,52859]
name: days [54571,54575]
===
match
---
with_item [24253,24280]
with_item [25969,25996]
===
match
---
operator: = [49315,49316]
operator: = [51031,51032]
===
match
---
assert_stmt [29325,29405]
assert_stmt [31041,31121]
===
match
---
name: self [32918,32922]
name: self [34634,34638]
===
match
---
simple_stmt [1155,1189]
simple_stmt [1155,1189]
===
match
---
argument [54297,54312]
argument [56013,56028]
===
match
---
trailer [54970,54979]
trailer [56686,56695]
===
match
---
name: when [40541,40545]
name: when [42257,42261]
===
match
---
operator: , [61140,61141]
operator: , [62856,62857]
===
match
---
trailer [13291,13298]
trailer [13291,13298]
===
match
---
simple_stmt [47232,47290]
simple_stmt [48948,49006]
===
match
---
operator: } [11704,11705]
operator: } [11704,11705]
===
match
---
number: 1 [46676,46677]
number: 1 [48392,48393]
===
match
---
assert_stmt [6617,6639]
assert_stmt [6617,6639]
===
match
---
name: datetime [57089,57097]
name: datetime [58805,58813]
===
match
---
simple_stmt [5538,5590]
simple_stmt [5538,5590]
===
match
---
operator: = [35304,35305]
operator: = [37020,37021]
===
match
---
trailer [53530,53538]
trailer [55246,55254]
===
match
---
operator: = [50179,50180]
operator: = [51895,51896]
===
match
---
name: schedule_interval [56214,56231]
name: schedule_interval [57930,57947]
===
match
---
trailer [18365,18372]
trailer [18365,18372]
===
match
---
argument [51796,51810]
argument [53512,53526]
===
match
---
operator: = [69522,69523]
operator: = [71238,71239]
===
match
---
simple_stmt [60219,60269]
simple_stmt [61935,61985]
===
match
---
for_stmt [13374,13783]
for_stmt [13374,13783]
===
match
---
operator: , [66110,66111]
operator: , [67826,67827]
===
match
---
name: dag_id [42829,42835]
name: dag_id [44545,44551]
===
match
---
name: topological_list [10345,10361]
name: topological_list [10345,10361]
===
match
---
trailer [54371,54377]
trailer [56087,56093]
===
match
---
trailer [16827,16872]
trailer [16827,16872]
===
match
---
trailer [6761,6808]
trailer [6761,6808]
===
match
---
name: test_dag_invalid_default_view [4490,4519]
name: test_dag_invalid_default_view [4490,4519]
===
match
---
name: DummyOperator [35833,35846]
name: DummyOperator [37549,37562]
===
match
---
atom_expr [40676,40718]
atom_expr [42392,42434]
===
match
---
operator: , [54312,54313]
operator: , [56028,56029]
===
match
---
name: task_id [51864,51871]
name: task_id [53580,53587]
===
match
---
name: DEFAULT_DATE [53599,53611]
name: DEFAULT_DATE [55315,55327]
===
match
---
name: end_date [52812,52820]
name: end_date [54528,54536]
===
match
---
name: DAG [16824,16827]
name: DAG [16824,16827]
===
match
---
trailer [27689,27705]
trailer [29405,29421]
===
match
---
string: 'b_parent' [8450,8460]
string: 'b_parent' [8450,8460]
===
match
---
trailer [34383,34407]
trailer [36099,36123]
===
match
---
name: params_combined [4451,4466]
name: params_combined [4451,4466]
===
match
---
name: test_dag_topological_sort_dag_without_tasks [10547,10590]
name: test_dag_topological_sort_dag_without_tasks [10547,10590]
===
match
---
operator: , [61660,61661]
operator: , [63376,63377]
===
match
---
string: 'C' [8853,8856]
string: 'C' [8853,8856]
===
match
---
atom_expr [30876,30947]
atom_expr [32592,32663]
===
match
---
simple_stmt [6104,6139]
simple_stmt [6104,6139]
===
match
---
trailer [46270,46277]
trailer [47986,47993]
===
match
---
comparison [34500,34525]
comparison [36216,36241]
===
match
---
operator: , [49701,49702]
operator: , [51417,51418]
===
match
---
expr_stmt [20913,20946]
expr_stmt [20913,20946]
===
match
---
simple_stmt [56388,56605]
simple_stmt [58104,58321]
===
match
---
trailer [54006,54062]
trailer [55722,55778]
===
match
---
trailer [52426,52436]
trailer [54142,54152]
===
match
---
trailer [7512,7531]
trailer [7512,7531]
===
match
---
name: set_downstream [9904,9918]
name: set_downstream [9904,9918]
===
match
---
expr_stmt [15311,15322]
expr_stmt [15311,15322]
===
match
---
atom_expr [8831,8857]
atom_expr [8831,8857]
===
match
---
name: dag_diff_load_time [44411,44429]
name: dag_diff_load_time [46127,46145]
===
match
---
name: prev_task [14665,14674]
name: prev_task [14665,14674]
===
match
---
name: dag_id [49822,49828]
name: dag_id [51538,51544]
===
match
---
name: dagruns [49286,49293]
name: dagruns [51002,51009]
===
match
---
simple_stmt [35484,35518]
simple_stmt [37200,37234]
===
match
---
expr_stmt [36343,36376]
expr_stmt [38059,38092]
===
match
---
name: name [25193,25197]
name: name [26909,26913]
===
match
---
fstring_end: ' [39648,39649]
fstring_end: ' [41364,41365]
===
match
---
string: 'Also fake' [39141,39152]
string: 'Also fake' [40857,40868]
===
match
---
name: op3 [35873,35876]
name: op3 [37589,37592]
===
match
---
parameters [68302,68308]
parameters [70018,70024]
===
match
---
argument [52616,52635]
argument [54332,54351]
===
match
---
assert_stmt [10460,10494]
assert_stmt [10460,10494]
===
match
---
operator: , [18372,18373]
operator: , [18372,18373]
===
match
---
name: previous_schedule [20924,20941]
name: previous_schedule [20924,20941]
===
match
---
operator: , [3780,3781]
operator: , [3780,3781]
===
match
---
operator: , [65931,65932]
operator: , [67647,67648]
===
match
---
name: subdag [28905,28911]
name: subdag [30621,30627]
===
match
---
trailer [54682,54690]
trailer [56398,56406]
===
match
---
assert_stmt [55912,55940]
assert_stmt [57628,57656]
===
match
---
arglist [6762,6807]
arglist [6762,6807]
===
match
---
number: 0 [69579,69580]
number: 0 [71295,71296]
===
match
---
name: MANUAL [40567,40573]
name: MANUAL [42283,42289]
===
match
---
atom_expr [31726,31736]
atom_expr [33442,33452]
===
match
---
operator: = [54752,54753]
operator: = [56468,56469]
===
match
---
operator: = [21614,21615]
operator: = [21614,21615]
===
match
---
trailer [26762,26769]
trailer [28478,28485]
===
match
---
comparison [34665,34690]
comparison [36381,36406]
===
match
---
funcdef [66475,66545]
funcdef [68191,68261]
===
match
---
operator: , [69445,69446]
operator: , [71161,71162]
===
match
---
name: dag_id [31508,31514]
name: dag_id [33224,33230]
===
match
---
atom_expr [41617,41659]
atom_expr [43333,43375]
===
match
---
atom_expr [32726,32742]
atom_expr [34442,34458]
===
match
---
operator: = [10633,10634]
operator: = [10633,10634]
===
match
---
trailer [8287,8329]
trailer [8287,8329]
===
match
---
decorator [51275,51381]
decorator [52991,53097]
===
match
---
argument [50899,50905]
argument [52615,52621]
===
match
---
trailer [25893,25895]
trailer [27609,27611]
===
match
---
simple_stmt [49631,49654]
simple_stmt [51347,51370]
===
match
---
name: _next [23005,23010]
name: _next [23005,23010]
===
match
---
arglist [23781,23842]
arglist [23781,23842]
===
match
---
name: dag_id [49205,49211]
name: dag_id [50921,50927]
===
match
---
atom_expr [16958,17005]
atom_expr [16958,17005]
===
match
---
trailer [9390,9393]
trailer [9390,9393]
===
match
---
parameters [70619,70625]
parameters [72335,72341]
===
match
---
atom_expr [13448,13460]
atom_expr [13448,13460]
===
match
---
name: is_subdag [31176,31185]
name: is_subdag [32892,32901]
===
match
---
name: dag [6087,6090]
name: dag [6087,6090]
===
match
---
trailer [33567,33574]
trailer [35283,35290]
===
match
---
operator: = [37122,37123]
operator: = [38838,38839]
===
match
---
name: params1 [4328,4335]
name: params1 [4328,4335]
===
match
---
trailer [38189,38199]
trailer [39905,39915]
===
match
---
atom_expr [24600,24611]
atom_expr [26316,26327]
===
match
---
operator: , [44268,44269]
operator: , [45984,45985]
===
match
---
atom_expr [24112,24127]
atom_expr [25828,25843]
===
match
---
name: start_date [55382,55392]
name: start_date [57098,57108]
===
match
---
number: 5 [15339,15340]
number: 5 [15339,15340]
===
match
---
operator: } [15573,15574]
operator: } [15573,15574]
===
match
---
name: DEFAULT_DATE [54242,54254]
name: DEFAULT_DATE [55958,55970]
===
match
---
simple_stmt [33833,33861]
simple_stmt [35549,35577]
===
match
---
string: 'test_scheduler_dagrun_once_with_timedelta_and_catchup_false' [58722,58783]
string: 'test_scheduler_dagrun_once_with_timedelta_and_catchup_false' [60438,60499]
===
match
---
trailer [27965,28127]
trailer [29681,29843]
===
match
---
trailer [64065,64067]
trailer [65781,65783]
===
match
---
operator: } [32479,32480]
operator: } [34195,34196]
===
match
---
import_from [1106,1154]
import_from [1106,1154]
===
match
---
name: DEFAULT_DATE [30220,30232]
name: DEFAULT_DATE [31936,31948]
===
match
---
trailer [8197,8211]
trailer [8197,8211]
===
match
---
atom_expr [55743,55754]
atom_expr [57459,57470]
===
match
---
param [66563,66567]
param [68279,68283]
===
match
---
name: query [34477,34482]
name: query [36193,36198]
===
match
---
atom_expr [71088,71098]
atom_expr [72804,72814]
===
match
---
name: self [70487,70491]
name: self [72203,72207]
===
match
---
comparison [3479,3501]
comparison [3479,3501]
===
match
---
name: hash [45690,45694]
name: hash [47406,47410]
===
match
---
name: SCHEDULED [28078,28087]
name: SCHEDULED [29794,29803]
===
match
---
name: dagruns [49317,49324]
name: dagruns [51033,51040]
===
match
---
comparison [46149,46175]
comparison [47865,47891]
===
match
---
name: t_1 [51644,51647]
name: t_1 [53360,53363]
===
match
---
simple_stmt [29325,29406]
simple_stmt [31041,31122]
===
match
---
atom_expr [45996,46012]
atom_expr [47712,47728]
===
match
---
testlist_comp [32453,32468]
testlist_comp [34169,34184]
===
match
---
atom_expr [69847,69857]
atom_expr [71563,71573]
===
match
---
atom_expr [25157,25204]
atom_expr [26873,26920]
===
match
---
string: 'op6' [6948,6953]
string: 'op6' [6948,6953]
===
match
---
operator: = [21665,21666]
operator: = [21665,21666]
===
match
---
name: parameterized [47991,48004]
name: parameterized [49707,49720]
===
match
---
trailer [56919,56928]
trailer [58635,58644]
===
match
---
argument [22618,22650]
argument [22618,22650]
===
match
---
operator: , [10138,10139]
operator: , [10138,10139]
===
match
---
expr_stmt [27775,27824]
expr_stmt [29491,29540]
===
match
---
atom_expr [28269,28286]
atom_expr [29985,30002]
===
match
---
simple_stmt [51551,51566]
simple_stmt [53267,53282]
===
match
---
name: pytest [1099,1105]
name: pytest [1099,1105]
===
match
---
trailer [2873,2880]
trailer [2873,2880]
===
match
---
name: is_active [29259,29268]
name: is_active [30975,30984]
===
match
---
string: 'fakename' [17821,17831]
string: 'fakename' [17821,17831]
===
match
---
simple_stmt [43596,43618]
simple_stmt [45312,45334]
===
match
---
operator: = [51973,51974]
operator: = [53689,53690]
===
match
---
arglist [14223,14352]
arglist [14223,14352]
===
match
---
number: 0 [13074,13075]
number: 0 [13074,13075]
===
match
---
name: dag_fileloc [33869,33880]
name: dag_fileloc [35585,35596]
===
match
---
name: test_normalized_schedule_interval [46705,46738]
name: test_normalized_schedule_interval [48421,48454]
===
match
---
name: task_id [35412,35419]
name: task_id [37128,37135]
===
match
---
simple_stmt [30621,30646]
simple_stmt [32337,32362]
===
match
---
name: dag [45844,45847]
name: dag [47560,47563]
===
match
---
simple_stmt [10333,10366]
simple_stmt [10333,10366]
===
match
---
simple_stmt [34295,34320]
simple_stmt [36011,36036]
===
match
---
operator: = [28108,28109]
operator: = [29824,29825]
===
match
---
funcdef [67897,68104]
funcdef [69613,69820]
===
match
---
name: f [19046,19047]
name: f [19046,19047]
===
match
---
trailer [14842,14856]
trailer [14842,14856]
===
match
---
name: test_dag_id [17912,17923]
name: test_dag_id [17912,17923]
===
match
---
name: self [70320,70324]
name: self [72036,72040]
===
match
---
name: timezone [59848,59856]
name: timezone [61564,61572]
===
match
---
argument [51592,51615]
argument [53308,53331]
===
match
---
name: delta [41207,41212]
name: delta [42923,42928]
===
match
---
name: get [5610,5613]
name: get [5610,5613]
===
match
---
name: test_dag_task_invalid_weight_rule [16371,16404]
name: test_dag_task_invalid_weight_rule [16371,16404]
===
match
---
name: permissions [63406,63417]
name: permissions [65122,65133]
===
match
---
trailer [70744,70757]
trailer [72460,72473]
===
match
---
number: 10 [60775,60777]
number: 10 [62491,62493]
===
match
---
simple_stmt [32933,32996]
simple_stmt [34649,34712]
===
match
---
name: default_args [12363,12375]
name: default_args [12363,12375]
===
match
---
trailer [14901,14904]
trailer [14901,14904]
===
match
---
name: dagrun [51068,51074]
name: dagrun [52784,52790]
===
match
---
name: deactivate_deleted_dags [34384,34407]
name: deactivate_deleted_dags [36100,36123]
===
match
---
atom [48021,48089]
atom [49737,49805]
===
match
---
return_stmt [67571,67581]
return_stmt [69287,69297]
===
match
---
assert_stmt [42301,42348]
assert_stmt [44017,44064]
===
match
---
operator: = [54046,54047]
operator: = [55762,55763]
===
match
---
name: execution_date [16977,16991]
name: execution_date [16977,16991]
===
match
---
simple_stmt [41952,41975]
simple_stmt [43668,43691]
===
match
---
atom [32424,32438]
atom [34140,34154]
===
match
---
name: dag [50796,50799]
name: dag [52512,52515]
===
match
---
expr_stmt [2519,2590]
expr_stmt [2519,2590]
===
match
---
assert_stmt [42889,42934]
assert_stmt [44605,44650]
===
match
---
name: all [24423,24426]
name: all [26139,26142]
===
match
---
name: timezone [69349,69357]
name: timezone [71065,71073]
===
match
---
string: '@once' [43201,43208]
string: '@once' [44917,44924]
===
match
---
name: op4 [6624,6627]
name: op4 [6624,6627]
===
match
---
arglist [47573,47623]
arglist [49289,49339]
===
match
---
trailer [70434,70443]
trailer [72150,72159]
===
match
---
operator: = [35396,35397]
operator: = [37112,37113]
===
match
---
comparison [27177,27195]
comparison [28893,28911]
===
match
---
operator: == [11847,11849]
operator: == [11847,11849]
===
match
---
trailer [39757,39759]
trailer [41473,41475]
===
match
---
simple_stmt [28136,28158]
simple_stmt [29852,29874]
===
match
---
trailer [37401,37479]
trailer [39117,39195]
===
match
---
operator: == [29212,29214]
operator: == [30928,30930]
===
match
---
param [65753,65758]
param [67469,67474]
===
match
---
operator: = [62150,62151]
operator: = [63866,63867]
===
match
---
name: dag [69263,69266]
name: dag [70979,70982]
===
match
---
trailer [41644,41659]
trailer [43360,43375]
===
match
---
name: task_id [23781,23788]
name: task_id [23781,23788]
===
match
---
atom_expr [33277,33294]
atom_expr [34993,35010]
===
match
---
name: DagModel [34236,34244]
name: DagModel [35952,35960]
===
match
---
string: 't1' [48250,48254]
string: 't1' [49966,49970]
===
match
---
arith_expr [43400,43432]
arith_expr [45116,45148]
===
match
---
atom [63295,63353]
atom [65011,65069]
===
match
---
name: query [25867,25872]
name: query [27583,27588]
===
match
---
name: correct_weight [15147,15161]
name: correct_weight [15147,15161]
===
match
---
name: six_hours_ago_to_the_hour [58373,58398]
name: six_hours_ago_to_the_hour [60089,60114]
===
match
---
name: run_type [47149,47157]
name: run_type [48865,48873]
===
match
---
fstring_start: f' [18530,18532]
fstring_start: f' [18530,18532]
===
match
---
name: isoformat [22239,22248]
name: isoformat [22239,22248]
===
match
---
simple_stmt [27513,27537]
simple_stmt [29229,29253]
===
match
---
trailer [40695,40718]
trailer [42411,42434]
===
match
---
operator: } [26789,26790]
operator: } [28505,28506]
===
match
---
operator: = [50564,50565]
operator: = [52280,52281]
===
match
---
operator: , [50330,50331]
operator: , [52046,52047]
===
match
---
atom_expr [67595,67608]
atom_expr [69311,69324]
===
match
---
name: session [48388,48395]
name: session [50104,50111]
===
match
---
operator: == [41903,41905]
operator: == [43619,43621]
===
match
---
operator: = [57655,57656]
operator: = [59371,59372]
===
match
---
simple_stmt [23854,23896]
simple_stmt [23854,23896]
===
match
---
name: datetime [17094,17102]
name: datetime [17094,17102]
===
match
---
trailer [25709,25711]
trailer [27425,27427]
===
match
---
name: rollback [64521,64529]
name: rollback [66237,66245]
===
match
---
trailer [19611,19624]
trailer [19611,19624]
===
match
---
param [64605,64609]
param [66321,66325]
===
match
---
assert_stmt [57891,57923]
assert_stmt [59607,59639]
===
match
---
import_from [2294,2354]
import_from [2294,2354]
===
match
---
name: hash [45703,45707]
name: hash [47419,47423]
===
match
---
atom_expr [41260,41338]
atom_expr [42976,43054]
===
match
---
comparison [42896,42934]
comparison [44612,44650]
===
match
---
trailer [19412,19435]
trailer [19412,19435]
===
match
---
assert_stmt [12406,12446]
assert_stmt [12406,12446]
===
match
---
name: session [46231,46238]
name: session [47947,47954]
===
match
---
name: xcom_arg [70907,70915]
name: xcom_arg [72623,72631]
===
match
---
name: task_id [51796,51803]
name: task_id [53512,53519]
===
match
---
number: 2 [17988,17989]
number: 2 [17988,17989]
===
match
---
name: raises [36878,36884]
name: raises [38594,38600]
===
match
---
argument [49907,49921]
argument [51623,51637]
===
match
---
operator: = [48291,48292]
operator: = [50007,50008]
===
match
---
comparison [53119,53142]
comparison [54835,54858]
===
match
---
argument [69514,69540]
argument [71230,71256]
===
match
---
name: op3 [38166,38169]
name: op3 [39882,39885]
===
match
---
arglist [14410,14418]
arglist [14410,14418]
===
match
---
argument [49728,49745]
argument [51444,51461]
===
match
---
operator: = [37050,37051]
operator: = [38766,38767]
===
match
---
atom_expr [62744,62779]
atom_expr [64460,64495]
===
match
---
trailer [9748,9761]
trailer [9748,9761]
===
match
---
string: 'dag' [29152,29157]
string: 'dag' [30868,30873]
===
match
---
string: """         Tests avoid crashes from calling dag callbacks exceptions         """ [39897,39978]
string: """         Tests avoid crashes from calling dag callbacks exceptions         """ [41613,41694]
===
match
---
trailer [40643,40667]
trailer [42359,42383]
===
match
---
comparison [58360,58398]
comparison [60076,60114]
===
match
---
name: next_date [59209,59218]
name: next_date [60925,60934]
===
match
---
atom_expr [38664,38710]
atom_expr [40380,40426]
===
match
---
name: set1 [10196,10200]
name: set1 [10196,10200]
===
match
---
trailer [34482,34492]
trailer [36198,36208]
===
match
---
arglist [59983,59993]
arglist [61699,61709]
===
match
---
argument [6171,6184]
argument [6171,6184]
===
match
---
name: settings [27622,27630]
name: settings [29338,29346]
===
match
---
string: "t3" [35420,35424]
string: "t3" [37136,37140]
===
match
---
name: dag_id [32034,32040]
name: dag_id [33750,33756]
===
match
---
operator: = [6553,6554]
operator: = [6553,6554]
===
match
---
trailer [2859,2865]
trailer [2859,2865]
===
match
---
atom_expr [47372,47418]
atom_expr [49088,49134]
===
match
---
string: 'a_parent' [7850,7860]
string: 'a_parent' [7850,7860]
===
match
---
expr_stmt [53570,53631]
expr_stmt [55286,55347]
===
match
---
trailer [65378,65387]
trailer [67094,67103]
===
match
---
name: merge [48754,48759]
name: merge [50470,50475]
===
match
---
parameters [18474,18480]
parameters [18474,18480]
===
match
---
simple_stmt [43800,43823]
simple_stmt [45516,45539]
===
match
---
operator: , [38151,38152]
operator: , [39867,39868]
===
match
---
operator: , [1486,1487]
operator: , [1486,1487]
===
match
---
name: self [4841,4845]
name: self [4841,4845]
===
match
---
trailer [52691,52697]
trailer [54407,54413]
===
match
---
parameters [33817,33823]
parameters [35533,35539]
===
match
---
name: _occur_before [8198,8211]
name: _occur_before [8198,8211]
===
match
---
operator: = [70225,70226]
operator: = [71941,71942]
===
match
---
argument [52587,52614]
argument [54303,54330]
===
match
---
atom_expr [66500,66515]
atom_expr [68216,68231]
===
match
---
name: dag_models [64414,64424]
name: dag_models [66130,66140]
===
match
---
trailer [66009,66023]
trailer [67725,67739]
===
match
---
trailer [30152,30251]
trailer [31868,31967]
===
match
---
name: ACTION_CAN_EDIT [63103,63118]
name: ACTION_CAN_EDIT [64819,64834]
===
match
---
name: dag [67262,67265]
name: dag [68978,68981]
===
match
---
trailer [34089,34091]
trailer [35805,35807]
===
match
---
operator: , [64244,64245]
operator: , [65960,65961]
===
match
---
name: schedule_interval [46745,46762]
name: schedule_interval [48461,48478]
===
match
---
name: op1 [6242,6245]
name: op1 [6242,6245]
===
match
---
simple_stmt [12034,12075]
simple_stmt [12034,12075]
===
match
---
operator: , [68196,68197]
operator: , [69912,69913]
===
match
---
name: owner [30015,30020]
name: owner [31731,31736]
===
match
---
name: start_date [62434,62444]
name: start_date [64150,64160]
===
match
---
trailer [68749,68751]
trailer [70465,70467]
===
match
---
expr_stmt [63888,63964]
expr_stmt [65604,65680]
===
match
---
trailer [25252,25269]
trailer [26968,26985]
===
match
---
assert_stmt [24015,24070]
assert_stmt [24015,24070]
===
match
---
operator: = [7849,7850]
operator: = [7849,7850]
===
match
---
operator: , [55521,55522]
operator: , [57237,57238]
===
match
---
operator: = [6850,6851]
operator: = [6850,6851]
===
match
---
comparison [63602,63643]
comparison [65318,65359]
===
match
---
simple_stmt [69550,69582]
simple_stmt [71266,71298]
===
match
---
operator: , [43282,43283]
operator: , [44998,44999]
===
match
---
operator: , [26860,26861]
operator: , [28576,28577]
===
match
---
name: set [36063,36066]
name: set [37779,37782]
===
match
---
name: dag_id [3094,3100]
name: dag_id [3094,3100]
===
match
---
name: owner [6726,6731]
name: owner [6726,6731]
===
match
---
atom_expr [28493,28563]
atom_expr [30209,30279]
===
match
---
trailer [3726,3730]
trailer [3726,3730]
===
match
---
arglist [31844,31879]
arglist [33560,33595]
===
match
---
name: row [25852,25855]
name: row [27568,27571]
===
match
---
comparison [26810,27081]
comparison [28526,28797]
===
match
---
operator: >> [37666,37668]
operator: >> [39382,39384]
===
match
---
simple_stmt [40404,40489]
simple_stmt [42120,42205]
===
match
---
param [22409,22413]
param [22409,22413]
===
match
---
with_item [12834,12910]
with_item [12834,12910]
===
match
---
name: set_upstream [8919,8931]
name: set_upstream [8919,8931]
===
match
---
simple_stmt [38654,38727]
simple_stmt [40370,40443]
===
match
---
param [18475,18479]
param [18475,18479]
===
match
---
trailer [36884,36962]
trailer [38600,38678]
===
match
---
operator: = [8897,8898]
operator: = [8897,8898]
===
match
---
trailer [12160,12169]
trailer [12160,12169]
===
match
---
simple_stmt [16780,16804]
simple_stmt [16780,16804]
===
match
---
name: pickle [846,852]
name: pickle [846,852]
===
match
---
trailer [65162,65168]
trailer [66878,66884]
===
match
---
name: timedelta [56910,56919]
name: timedelta [58626,58635]
===
match
---
name: session [27033,27040]
name: session [28749,28756]
===
match
---
expr_stmt [23273,23308]
expr_stmt [23273,23308]
===
match
---
operator: , [61381,61382]
operator: , [63097,63098]
===
match
---
operator: = [54094,54095]
operator: = [55810,55811]
===
match
---
comparison [38817,38863]
comparison [40533,40579]
===
match
---
name: DEFAULT_DATE [48597,48609]
name: DEFAULT_DATE [50313,50325]
===
match
---
atom_expr [39625,39647]
atom_expr [41341,41363]
===
match
---
operator: = [51803,51804]
operator: = [53519,53520]
===
match
---
simple_stmt [11949,12026]
simple_stmt [11949,12026]
===
match
---
name: dag [31340,31343]
name: dag [33056,33059]
===
match
---
atom_expr [18993,19002]
atom_expr [18993,19002]
===
match
---
name: owner [6450,6455]
name: owner [6450,6455]
===
match
---
name: DAG [27669,27672]
name: DAG [29385,29388]
===
match
---
name: execute [34623,34630]
name: execute [36339,36346]
===
match
---
trailer [50699,50705]
trailer [52415,52421]
===
match
---
operator: = [19889,19890]
operator: = [19889,19890]
===
match
---
name: test_task [16881,16890]
name: test_task [16881,16890]
===
match
---
comparison [9288,9316]
comparison [9288,9316]
===
match
---
operator: , [58439,58440]
operator: , [60155,60156]
===
match
---
argument [43446,43471]
argument [45162,45187]
===
match
---
simple_stmt [14873,14906]
simple_stmt [14873,14906]
===
match
---
name: timezone [2066,2074]
name: timezone [2066,2074]
===
match
---
atom_expr [51900,51917]
atom_expr [53616,53633]
===
match
---
atom [24195,24213]
atom [25911,25929]
===
match
---
parameters [10885,10891]
parameters [10885,10891]
===
match
---
name: owner [40452,40457]
name: owner [42168,42173]
===
match
---
operator: = [56755,56756]
operator: = [58471,58472]
===
match
---
name: db [2316,2318]
name: db [2316,2318]
===
match
---
name: template_ext [19366,19378]
name: template_ext [19366,19378]
===
match
---
number: 1 [55403,55404]
number: 1 [57119,57120]
===
match
---
fstring_start: f' [14231,14233]
fstring_start: f' [14231,14233]
===
match
---
simple_stmt [15331,15341]
simple_stmt [15331,15341]
===
match
---
operator: = [5915,5916]
operator: = [5915,5916]
===
match
---
string: "test-dag2" [25592,25603]
string: "test-dag2" [27308,27319]
===
match
---
name: getvalue [36531,36539]
name: getvalue [38247,38255]
===
match
---
name: dag_diff_load_time [45050,45068]
name: dag_diff_load_time [46766,46784]
===
match
---
expr_stmt [33004,33032]
expr_stmt [34720,34748]
===
match
---
argument [43986,44003]
argument [45702,45719]
===
match
---
name: topological_list [8026,8042]
name: topological_list [8026,8042]
===
match
---
number: 52 [70172,70174]
number: 52 [71888,71890]
===
match
---
simple_stmt [23755,23845]
simple_stmt [23755,23845]
===
match
---
param [44127,44131]
param [45843,45847]
===
match
---
simple_stmt [4202,4230]
simple_stmt [4202,4230]
===
match
---
name: dag [37196,37199]
name: dag [38912,38915]
===
match
---
name: dag [30962,30965]
name: dag [32678,32681]
===
match
---
name: self [33818,33822]
name: self [35534,35538]
===
match
---
atom_expr [63704,63722]
atom_expr [65420,65438]
===
match
---
simple_stmt [47550,47625]
simple_stmt [49266,49341]
===
match
---
operator: = [44310,44311]
operator: = [46026,46027]
===
match
---
trailer [2508,2510]
trailer [2508,2510]
===
match
---
classdef [66170,71099]
classdef [67886,72815]
===
match
---
trailer [54672,54682]
trailer [56388,56398]
===
match
---
name: start_date [36206,36216]
name: start_date [37922,37932]
===
match
---
atom_expr [35015,35028]
atom_expr [36731,36744]
===
match
---
trailer [48486,48499]
trailer [50202,50215]
===
match
---
name: filter [29126,29132]
name: filter [30842,30848]
===
match
---
operator: @ [30550,30551]
operator: @ [32266,32267]
===
match
---
name: io [36441,36443]
name: io [38157,38159]
===
match
---
operator: = [38022,38023]
operator: = [39738,39739]
===
match
---
trailer [39090,39099]
trailer [40806,40815]
===
match
---
suite [2661,2747]
suite [2661,2747]
===
match
---
name: DEFAULT_DATE [52340,52352]
name: DEFAULT_DATE [54056,54068]
===
match
---
name: test_leaves [35620,35631]
name: test_leaves [37336,37347]
===
match
---
simple_stmt [35827,35861]
simple_stmt [37543,37577]
===
match
---
name: pytest [37388,37394]
name: pytest [39104,39110]
===
match
---
name: DEFAULT_DATE [52821,52833]
name: DEFAULT_DATE [54537,54549]
===
match
---
operator: = [60889,60890]
operator: = [62605,62606]
===
match
---
operator: = [30923,30924]
operator: = [32639,32640]
===
match
---
operator: , [20400,20401]
operator: , [20400,20401]
===
match
---
name: DEFAULT_DATE [17079,17091]
name: DEFAULT_DATE [17079,17091]
===
match
---
argument [6784,6807]
argument [6784,6807]
===
match
---
trailer [70243,70249]
trailer [71959,71965]
===
match
---
operator: = [47612,47613]
operator: = [49328,49329]
===
match
---
operator: = [37589,37590]
operator: = [39305,39306]
===
match
---
name: test_field [19271,19281]
name: test_field [19271,19281]
===
match
---
assert_stmt [57514,57550]
assert_stmt [59230,59266]
===
match
---
operator: , [36995,36996]
operator: , [38711,38712]
===
match
---
trailer [25866,25872]
trailer [27582,27588]
===
match
---
trailer [33754,33760]
trailer [35470,35476]
===
match
---
operator: @ [58404,58405]
operator: @ [60120,60121]
===
match
---
name: filter [51157,51163]
name: filter [52873,52879]
===
match
---
import_as_names [1977,2008]
import_as_names [1977,2008]
===
match
---
trailer [54176,54182]
trailer [55892,55898]
===
match
---
operator: , [51615,51616]
operator: , [53331,53332]
===
match
---
operator: { [44249,44250]
operator: { [45965,45966]
===
match
---
operator: , [60766,60767]
operator: , [62482,62483]
===
match
---
trailer [2548,2555]
trailer [2548,2555]
===
match
---
atom [18046,18060]
atom [18046,18060]
===
match
---
simple_stmt [1306,1360]
simple_stmt [1306,1360]
===
match
---
atom_expr [9458,9527]
atom_expr [9458,9527]
===
match
---
operator: , [30092,30093]
operator: , [31808,31809]
===
match
---
atom_expr [9780,9806]
atom_expr [9780,9806]
===
match
---
argument [35458,35470]
argument [37174,37186]
===
match
---
name: task_dict [13390,13399]
name: task_dict [13390,13399]
===
match
---
name: task_id [35320,35327]
name: task_id [37036,37043]
===
match
---
atom_expr [6446,6455]
atom_expr [6446,6455]
===
match
---
operator: = [59649,59650]
operator: = [61365,61366]
===
match
---
atom_expr [33505,33521]
atom_expr [35221,35237]
===
match
---
atom_expr [70459,70476]
atom_expr [72175,72192]
===
match
---
param [3548,3552]
param [3548,3552]
===
match
---
operator: = [56925,56926]
operator: = [58641,58642]
===
match
---
name: TI [48680,48682]
name: TI [50396,50398]
===
match
---
name: raises [4629,4635]
name: raises [4629,4635]
===
match
---
operator: , [53261,53262]
operator: , [54977,54978]
===
match
---
name: session [52995,53002]
name: session [54711,54718]
===
match
---
name: dag_id [45897,45903]
name: dag_id [47613,47619]
===
match
---
name: RUNNING [52544,52551]
name: RUNNING [54260,54267]
===
match
---
operator: , [47888,47889]
operator: , [49604,49605]
===
match
---
name: append [25585,25591]
name: append [27301,27307]
===
match
---
simple_stmt [46142,46176]
simple_stmt [47858,47892]
===
match
---
operator: , [18199,18200]
operator: , [18199,18200]
===
match
---
operator: , [69412,69413]
operator: , [71128,71129]
===
match
---
name: pipeline [12924,12932]
name: pipeline [12924,12932]
===
match
---
name: dag_id [31434,31440]
name: dag_id [33150,33156]
===
match
---
name: dag_id [55485,55491]
name: dag_id [57201,57207]
===
match
---
expr_stmt [9774,9806]
expr_stmt [9774,9806]
===
match
---
expr_stmt [30353,30425]
expr_stmt [32069,32141]
===
match
---
name: models [5323,5329]
name: models [5323,5329]
===
match
---
number: 30 [57055,57057]
number: 30 [58771,58773]
===
match
---
atom_expr [35490,35517]
atom_expr [37206,37233]
===
match
---
atom_expr [54962,54991]
atom_expr [56678,56707]
===
match
---
assert_stmt [33676,33762]
assert_stmt [35392,35478]
===
match
---
simple_stmt [2356,2398]
simple_stmt [2356,2398]
===
match
---
parameters [24473,24479]
parameters [26189,26195]
===
match
---
name: next_dagrun_create_after [41878,41902]
name: next_dagrun_create_after [43594,43618]
===
match
---
atom_expr [39768,39790]
atom_expr [41484,41506]
===
match
---
name: dags [25511,25515]
name: dags [27227,27231]
===
match
---
trailer [42562,42572]
trailer [44278,44288]
===
match
---
argument [44518,44535]
argument [46234,46251]
===
match
---
assert_stmt [31593,31694]
assert_stmt [33309,33410]
===
match
---
trailer [35503,35517]
trailer [37219,37233]
===
match
---
operator: { [4248,4249]
operator: { [4248,4249]
===
match
---
testlist_comp [49439,49483]
testlist_comp [51155,51199]
===
match
---
expr_stmt [9639,9671]
expr_stmt [9639,9671]
===
match
---
name: dag [61248,61251]
name: dag [62964,62967]
===
match
---
comparison [34253,34278]
comparison [35969,35994]
===
match
---
simple_stmt [45897,45932]
simple_stmt [47613,47648]
===
match
---
name: SCHEDULED [41400,41409]
name: SCHEDULED [43116,43125]
===
match
---
operator: = [48337,48338]
operator: = [50053,50054]
===
match
---
operator: , [19164,19165]
operator: , [19164,19165]
===
match
---
name: DAG [61034,61037]
name: DAG [62750,62753]
===
match
---
atom_expr [35833,35860]
atom_expr [37549,37576]
===
match
---
number: 2020 [60100,60104]
number: 2020 [61816,61820]
===
match
---
argument [20648,20679]
argument [20648,20679]
===
match
---
operator: = [27721,27722]
operator: = [29437,29438]
===
match
---
name: id [38661,38663]
name: id [40377,40379]
===
match
---
string: "test_create_dagrun_job_id_is_set" [47854,47888]
string: "test_create_dagrun_job_id_is_set" [49570,49604]
===
match
---
atom_expr [65155,65170]
atom_expr [66871,66886]
===
match
---
string: """Test that dag param is correctly overwritten when set in dag run""" [69686,69756]
string: """Test that dag param is correctly overwritten when set in dag run""" [71402,71472]
===
match
---
simple_stmt [20843,20904]
simple_stmt [20843,20904]
===
match
---
operator: , [44716,44717]
operator: , [46432,46433]
===
match
---
name: self [54733,54737]
name: self [56449,56453]
===
match
---
name: mock [1057,1061]
name: mock [1057,1061]
===
match
---
atom_expr [19030,19053]
atom_expr [19030,19053]
===
match
---
name: is_paused_upon_creation [32688,32711]
name: is_paused_upon_creation [34404,34427]
===
match
---
param [16405,16409]
param [16405,16409]
===
match
---
name: test_dag_topological_sort2 [9410,9436]
name: test_dag_topological_sort2 [9410,9436]
===
match
---
trailer [33316,33318]
trailer [35032,35034]
===
match
---
simple_stmt [13969,13979]
simple_stmt [13969,13979]
===
match
---
expr_stmt [38427,38460]
expr_stmt [40143,40176]
===
match
---
string: 'dag-bulk-sync-1' [26096,26113]
string: 'dag-bulk-sync-1' [27812,27829]
===
match
---
simple_stmt [30771,30838]
simple_stmt [32487,32554]
===
match
---
name: t_1 [53640,53643]
name: t_1 [55356,55359]
===
match
---
name: airflow [1575,1582]
name: airflow [1575,1582]
===
match
---
operator: = [46315,46316]
operator: = [48031,48032]
===
match
---
argument [42238,42251]
argument [43954,43967]
===
match
---
parameters [36116,36122]
parameters [37832,37838]
===
match
---
simple_stmt [21228,21247]
simple_stmt [21228,21247]
===
match
---
operator: = [68434,68435]
operator: = [70150,70151]
===
match
---
name: dag [32142,32145]
name: dag [33858,33861]
===
match
---
operator: , [48499,48500]
operator: , [50215,50216]
===
match
---
operator: , [43575,43576]
operator: , [45291,45292]
===
match
---
arglist [60315,60325]
arglist [62031,62041]
===
match
---
atom_expr [32599,32615]
atom_expr [34315,34331]
===
match
---
operator: = [66142,66143]
operator: = [67858,67859]
===
match
---
argument [47376,47417]
argument [49092,49133]
===
match
---
name: DummyOperator [35306,35319]
name: DummyOperator [37022,37035]
===
match
---
name: schedule_interval [54843,54860]
name: schedule_interval [56559,56576]
===
match
---
name: task_id [6593,6600]
name: task_id [6593,6600]
===
match
---
name: test_dag_id [44573,44584]
name: test_dag_id [46289,46300]
===
match
---
name: dr [47126,47128]
name: dr [48842,48844]
===
match
---
name: session [18390,18397]
name: session [18390,18397]
===
match
---
operator: , [31629,31630]
operator: , [33345,33346]
===
match
---
name: datetime [59231,59239]
name: datetime [60947,60955]
===
match
---
name: op5 [10140,10143]
name: op5 [10140,10143]
===
match
---
arglist [52044,52187]
arglist [53760,53903]
===
match
---
operator: = [13432,13433]
operator: = [13432,13433]
===
match
---
name: session [17650,17657]
name: session [17650,17657]
===
match
---
comparison [34335,34365]
comparison [36051,36081]
===
match
---
string: 'test-dag2' [26313,26324]
string: 'test-dag2' [28029,28040]
===
match
---
assert_stmt [59828,59877]
assert_stmt [61544,61593]
===
match
---
atom_expr [36067,36077]
atom_expr [37783,37793]
===
match
---
name: correct_weight [16347,16361]
name: correct_weight [16347,16361]
===
match
---
name: orm_subdag [29729,29739]
name: orm_subdag [31445,31455]
===
match
---
operator: = [31186,31187]
operator: = [32902,32903]
===
match
---
argument [3109,3134]
argument [3109,3134]
===
match
---
operator: = [57347,57348]
operator: = [59063,59064]
===
match
---
operator: = [33840,33841]
operator: = [35556,35557]
===
match
---
name: days [17238,17242]
name: days [17238,17242]
===
match
---
name: prev_task [15994,16003]
name: prev_task [15994,16003]
===
match
---
atom_expr [69523,69540]
atom_expr [71239,71256]
===
match
---
name: test_dag_is_deactivated_upon_dagfile_deletion [33772,33817]
name: test_dag_is_deactivated_upon_dagfile_deletion [35488,35533]
===
match
---
parameters [18503,18509]
parameters [18503,18509]
===
match
---
simple_stmt [10504,10538]
simple_stmt [10504,10538]
===
match
---
operator: = [18397,18398]
operator: = [18397,18398]
===
match
---
name: dag_id [53126,53132]
name: dag_id [54842,54848]
===
match
---
number: 2016 [66443,66447]
number: 2016 [68159,68163]
===
match
---
string: "t1" [37977,37981]
string: "t1" [39693,39697]
===
match
---
argument [7078,7091]
argument [7078,7091]
===
match
---
name: DEFAULT_DATE [44284,44296]
name: DEFAULT_DATE [46000,46012]
===
match
---
atom_expr [57775,57808]
atom_expr [59491,59524]
===
match
---
name: date [55802,55806]
name: date [57518,57522]
===
match
---
simple_stmt [61963,62035]
simple_stmt [63679,63751]
===
match
---
atom_expr [60983,61018]
atom_expr [62699,62734]
===
match
---
assert_stmt [30434,30473]
assert_stmt [32150,32189]
===
match
---
trailer [24371,24379]
trailer [26087,26095]
===
match
---
string: 'dag' [29867,29872]
string: 'dag' [31583,31588]
===
match
---
funcdef [67130,67178]
funcdef [68846,68894]
===
match
---
trailer [9268,9271]
trailer [9268,9271]
===
match
---
name: dag [45443,45446]
name: dag [47159,47162]
===
match
---
name: DAG [63894,63897]
name: DAG [65610,65613]
===
match
---
suite [19591,20099]
suite [19591,20099]
===
match
---
operator: , [29872,29873]
operator: , [31588,31589]
===
match
---
trailer [38717,38726]
trailer [40433,40442]
===
match
---
funcdef [47295,47673]
funcdef [49011,49389]
===
match
---
simple_stmt [62606,62630]
simple_stmt [64322,64346]
===
match
---
testlist_comp [10135,10143]
testlist_comp [10135,10143]
===
match
---
assert_stmt [55879,55902]
assert_stmt [57595,57618]
===
match
---
trailer [3337,3344]
trailer [3337,3344]
===
match
---
name: ti4 [17545,17548]
name: ti4 [17545,17548]
===
match
---
trailer [43741,43752]
trailer [45457,45468]
===
match
---
operator: = [38477,38478]
operator: = [40193,40194]
===
match
---
name: session [30603,30610]
name: session [32319,32326]
===
match
---
atom [46373,46385]
atom [48089,48101]
===
match
---
name: dag_run_state [50934,50947]
name: dag_run_state [52650,52663]
===
match
---
name: dag [6186,6189]
name: dag [6186,6189]
===
match
---
with_stmt [33375,33624]
with_stmt [35091,35340]
===
match
---
trailer [3101,3108]
trailer [3101,3108]
===
match
---
trailer [60099,60111]
trailer [61815,61827]
===
match
---
parameters [5435,5441]
parameters [5435,5441]
===
match
---
name: conf [1301,1305]
name: conf [1301,1305]
===
match
---
name: DagModel [33106,33114]
name: DagModel [34822,34830]
===
match
---
suite [13173,13203]
suite [13173,13203]
===
match
---
operator: = [17301,17302]
operator: = [17301,17302]
===
match
---
simple_stmt [19604,19625]
simple_stmt [19604,19625]
===
match
---
assert_stmt [6205,6226]
assert_stmt [6205,6226]
===
match
---
name: relativedelta [23665,23678]
name: relativedelta [23665,23678]
===
match
---
atom_expr [45744,45753]
atom_expr [47460,47469]
===
match
---
operator: , [70575,70576]
operator: , [72291,72292]
===
match
---
argument [57679,57715]
argument [59395,59431]
===
match
---
trailer [38687,38703]
trailer [40403,40419]
===
match
---
name: TI [2966,2968]
name: TI [2966,2968]
===
match
---
trailer [31852,31859]
trailer [33568,33575]
===
match
---
name: BACKFILL_JOB [53810,53822]
name: BACKFILL_JOB [55526,55538]
===
match
---
operator: = [62681,62682]
operator: = [64397,64398]
===
match
---
operator: = [37579,37580]
operator: = [39295,39296]
===
match
---
name: dag_id [45950,45956]
name: dag_id [47666,47672]
===
match
---
name: test_params_not_passed_is_empty_dict [3511,3547]
name: test_params_not_passed_is_empty_dict [3511,3547]
===
match
---
name: correct_weight [16216,16230]
name: correct_weight [16216,16230]
===
match
---
simple_stmt [6867,6909]
simple_stmt [6867,6909]
===
match
---
atom_expr [21468,21554]
atom_expr [21468,21554]
===
match
---
operator: , [54219,54220]
operator: , [55935,55936]
===
match
---
name: state [43520,43525]
name: state [45236,45241]
===
match
---
name: self [29829,29833]
name: self [31545,31549]
===
match
---
simple_stmt [38041,38052]
simple_stmt [39757,39768]
===
match
---
simple_stmt [23969,24007]
simple_stmt [23969,24007]
===
match
---
name: noop_pipeline [68736,68749]
name: noop_pipeline [70452,70465]
===
match
---
operator: , [3178,3179]
operator: , [3178,3179]
===
match
---
operator: , [18582,18583]
operator: , [18582,18583]
===
match
---
atom_expr [63602,63620]
atom_expr [65318,65336]
===
match
---
name: args [44396,44400]
name: args [46112,46116]
===
match
---
operator: , [59987,59988]
operator: , [61703,61704]
===
match
---
name: task_id [9704,9711]
name: task_id [9704,9711]
===
match
---
name: dag_id [23714,23720]
name: dag_id [23714,23720]
===
match
---
name: task_id [37066,37073]
name: task_id [38782,38789]
===
match
---
arglist [59240,59250]
arglist [60956,60966]
===
match
---
expr_stmt [33869,33929]
expr_stmt [35585,35645]
===
match
---
atom_expr [29356,29405]
atom_expr [31072,31121]
===
match
---
simple_stmt [57003,57059]
simple_stmt [58719,58775]
===
match
---
name: filter [46255,46261]
name: filter [47971,47977]
===
match
---
name: dag [45797,45800]
name: dag [47513,47516]
===
match
---
simple_stmt [31704,31793]
simple_stmt [33420,33509]
===
match
---
name: job_id [54087,54093]
name: job_id [55803,55809]
===
match
---
number: 2020 [60315,60319]
number: 2020 [62031,62035]
===
match
---
trailer [20119,20130]
trailer [20119,20130]
===
match
---
number: 1 [62014,62015]
number: 1 [63730,63731]
===
match
---
argument [39308,39327]
argument [41024,41043]
===
match
---
trailer [43651,43666]
trailer [45367,45382]
===
match
---
comparison [16326,16361]
comparison [16326,16361]
===
match
---
param [67335,67339]
param [69051,69055]
===
match
---
name: sub_dag [38664,38671]
name: sub_dag [40380,40387]
===
match
---
operator: ... [66746,66749]
operator: ... [68462,68465]
===
match
---
argument [63550,63585]
argument [65266,65301]
===
match
---
atom_expr [12173,12190]
atom_expr [12173,12190]
===
match
---
suite [32558,32872]
suite [34274,34588]
===
match
---
trailer [32602,32613]
trailer [34318,34329]
===
match
---
name: prev [22785,22789]
name: prev [22785,22789]
===
match
---
trailer [32613,32615]
trailer [34329,34331]
===
match
---
simple_stmt [8915,8944]
simple_stmt [8915,8944]
===
match
---
simple_stmt [29014,29043]
simple_stmt [30730,30759]
===
match
---
operator: , [56513,56514]
operator: , [58229,58230]
===
match
---
argument [53790,53822]
argument [55506,55538]
===
match
---
atom_expr [15792,15807]
atom_expr [15792,15807]
===
match
---
atom_expr [20570,20600]
atom_expr [20570,20600]
===
match
---
trailer [46238,46244]
trailer [47954,47960]
===
match
---
trailer [28032,28044]
trailer [29748,29760]
===
match
---
name: section_1 [62480,62489]
name: section_1 [64196,64205]
===
match
---
trailer [40679,40695]
trailer [42395,42411]
===
match
---
name: DEFAULT_DATE [64742,64754]
name: DEFAULT_DATE [66458,66470]
===
match
---
expr_stmt [31802,32002]
expr_stmt [33518,33718]
===
match
---
atom_expr [8116,8177]
atom_expr [8116,8177]
===
match
---
suite [55866,55903]
suite [57582,57619]
===
match
---
operator: + [48893,48894]
operator: + [50609,50610]
===
match
---
atom_expr [3720,3742]
atom_expr [3720,3742]
===
match
---
name: execution_date [47177,47191]
name: execution_date [48893,48907]
===
match
---
simple_stmt [12562,12605]
simple_stmt [12562,12605]
===
match
---
operator: , [58442,58443]
operator: , [60158,60159]
===
match
---
name: self [48132,48136]
name: self [49848,49852]
===
match
---
testlist_comp [36012,36020]
testlist_comp [37728,37736]
===
match
---
simple_stmt [27649,27661]
simple_stmt [29365,29377]
===
match
---
simple_stmt [42943,42966]
simple_stmt [44659,44682]
===
match
---
string: 't2' [38455,38459]
string: 't2' [40171,40175]
===
match
---
atom_expr [20361,20451]
atom_expr [20361,20451]
===
match
---
operator: , [69512,69513]
operator: , [71228,71229]
===
match
---
trailer [41877,41902]
trailer [43593,43618]
===
match
---
operator: , [51018,51019]
operator: , [52734,52735]
===
match
---
simple_stmt [40676,40719]
simple_stmt [42392,42435]
===
match
---
name: pendulum [22627,22635]
name: pendulum [22627,22635]
===
match
---
string: '2019-06-05T00:00:00+05:00' [11642,11669]
string: '2019-06-05T00:00:00+05:00' [11642,11669]
===
match
---
name: dag [54173,54176]
name: dag [55889,55892]
===
match
---
name: dag [54748,54751]
name: dag [56464,56467]
===
match
---
comparison [15126,15161]
comparison [15126,15161]
===
match
---
string: 'test_get_num_task_instances_dag' [16738,16771]
string: 'test_get_num_task_instances_dag' [16738,16771]
===
match
---
testlist_comp [26979,27009]
testlist_comp [28695,28725]
===
match
---
name: DagModel [46262,46270]
name: DagModel [47978,47986]
===
match
---
decorated [2752,3136]
decorated [2752,3136]
===
match
---
argument [35801,35813]
argument [37517,37529]
===
match
---
trailer [45694,45699]
trailer [47410,47415]
===
match
---
expr_stmt [42261,42292]
expr_stmt [43977,44008]
===
match
---
string: 'tag-1' [24196,24203]
string: 'tag-1' [25912,25919]
===
match
---
name: op2 [8780,8783]
name: op2 [8780,8783]
===
match
---
name: current_task [13223,13235]
name: current_task [13223,13235]
===
match
---
atom [25103,25134]
atom [26819,26850]
===
match
---
trailer [25243,25270]
trailer [26959,26986]
===
match
---
operator: , [31010,31011]
operator: , [32726,32727]
===
match
---
name: DummyOperator [6532,6545]
name: DummyOperator [6532,6545]
===
match
---
name: params [4474,4480]
name: params [4474,4480]
===
match
---
operator: == [39679,39681]
operator: == [41395,41397]
===
match
---
operator: { [63061,63062]
operator: { [64777,64778]
===
match
---
trailer [17227,17237]
trailer [17227,17237]
===
match
---
name: self [69671,69675]
name: self [71387,71391]
===
match
---
name: add_task [55579,55587]
name: add_task [57295,57303]
===
match
---
operator: @ [68407,68408]
operator: @ [70123,70124]
===
match
---
operator: , [26325,26326]
operator: , [28041,28042]
===
match
---
simple_stmt [863,879]
simple_stmt [863,879]
===
match
---
trailer [68439,68452]
trailer [70155,70168]
===
match
---
name: dag [3812,3815]
name: dag [3812,3815]
===
match
---
atom [31397,31583]
atom [33113,33299]
===
match
---
operator: , [20404,20405]
operator: , [20404,20405]
===
match
---
argument [57589,57624]
argument [59305,59340]
===
match
---
expr_stmt [21952,21988]
expr_stmt [21952,21988]
===
match
---
name: basename [19734,19742]
name: basename [19734,19742]
===
match
---
name: dag [27577,27580]
name: dag [29293,29296]
===
match
---
parameters [38907,38913]
parameters [40623,40629]
===
match
---
comparison [64487,64503]
comparison [66203,66219]
===
match
---
operator: , [40183,40184]
operator: , [41899,41900]
===
match
---
name: start_date [58141,58151]
name: start_date [59857,59867]
===
match
---
number: 1 [54281,54282]
number: 1 [55997,55998]
===
match
---
name: test_schedule_dag_once [41984,42006]
name: test_schedule_dag_once [43700,43722]
===
match
---
atom_expr [34878,34924]
atom_expr [36594,36640]
===
match
---
name: dag [7179,7182]
name: dag [7179,7182]
===
match
---
atom [36082,36092]
atom [37798,37808]
===
match
---
trailer [9939,9952]
trailer [9939,9952]
===
match
---
name: task_id [9749,9756]
name: task_id [9749,9756]
===
match
---
operator: = [50584,50585]
operator: = [52300,52301]
===
match
---
simple_stmt [43101,43136]
simple_stmt [44817,44852]
===
match
---
operator: = [48991,48992]
operator: = [50707,50708]
===
match
---
atom_expr [66314,66331]
atom_expr [68030,68047]
===
match
---
trailer [53713,53721]
trailer [55429,55437]
===
match
---
simple_stmt [3714,3743]
simple_stmt [3714,3743]
===
match
---
trailer [28413,28438]
trailer [30129,30154]
===
match
---
operator: = [43294,43295]
operator: = [45010,45011]
===
match
---
name: models [3720,3726]
name: models [3720,3726]
===
match
---
argument [56492,56513]
argument [58208,58229]
===
match
---
name: test_fileloc [66630,66642]
name: test_fileloc [68346,68358]
===
match
---
trailer [70324,70337]
trailer [72040,72053]
===
match
---
trailer [44036,44038]
trailer [45752,45754]
===
match
---
trailer [41828,41840]
trailer [43544,43556]
===
match
---
simple_stmt [829,839]
simple_stmt [829,839]
===
match
---
trailer [13506,13509]
trailer [13506,13509]
===
match
---
expr_stmt [55695,55705]
expr_stmt [57411,57421]
===
match
---
name: DummyOperator [35925,35938]
name: DummyOperator [37641,37654]
===
match
---
testlist_comp [26929,26959]
testlist_comp [28645,28675]
===
match
---
operator: , [26661,26662]
operator: , [28377,28378]
===
match
---
atom_expr [6758,6808]
atom_expr [6758,6808]
===
match
---
name: xcom_arg [70964,70972]
name: xcom_arg [72680,72688]
===
match
---
argument [43284,43304]
argument [45000,45020]
===
match
---
funcdef [69900,69948]
funcdef [71616,71664]
===
match
---
name: test_dag_task_priority_weight_total_using_upstream [13792,13842]
name: test_dag_task_priority_weight_total_using_upstream [13792,13842]
===
match
---
argument [20418,20450]
argument [20418,20450]
===
match
---
simple_stmt [32726,32743]
simple_stmt [34442,34459]
===
match
---
trailer [62321,62461]
trailer [64037,64177]
===
match
---
name: test_default_dag_id [67315,67334]
name: test_default_dag_id [69031,69050]
===
match
---
name: BACKFILL_JOB [48487,48499]
name: BACKFILL_JOB [50203,50215]
===
match
---
operator: == [3430,3432]
operator: == [3430,3432]
===
match
---
name: task_id [16626,16633]
name: task_id [16626,16633]
===
match
---
trailer [29183,29211]
trailer [30899,30927]
===
match
---
expr_stmt [63015,63241]
expr_stmt [64731,64957]
===
match
---
string: ', ' [29586,29590]
string: ', ' [31302,31306]
===
match
---
suite [6091,6196]
suite [6091,6196]
===
match
---
name: catchup [56531,56538]
name: catchup [58247,58254]
===
match
---
trailer [62837,62843]
trailer [64553,64559]
===
match
---
argument [43154,43167]
argument [44870,44883]
===
match
---
simple_stmt [70128,70152]
simple_stmt [71844,71868]
===
match
---
string: 'Also fake' [55629,55640]
string: 'Also fake' [57345,57356]
===
match
---
simple_stmt [63973,64030]
simple_stmt [65689,65746]
===
match
---
name: path [19729,19733]
name: path [19729,19733]
===
match
---
simple_stmt [8780,8813]
simple_stmt [8780,8813]
===
match
---
operator: , [44731,44732]
operator: , [46447,46448]
===
match
---
name: delete [2906,2912]
name: delete [2906,2912]
===
match
---
funcdef [69821,70119]
funcdef [71537,71835]
===
match
---
operator: , [48279,48280]
operator: , [49995,49996]
===
match
---
trailer [58949,58972]
trailer [60665,60688]
===
match
---
name: merge [50700,50705]
name: merge [52416,52421]
===
match
---
number: 1 [59726,59727]
number: 1 [61442,61443]
===
match
---
trailer [34630,34692]
trailer [36346,36408]
===
match
---
comparison [57898,57923]
comparison [59614,59639]
===
match
---
operator: >> [56787,56789]
operator: >> [58503,58505]
===
match
---
name: DAG [60663,60666]
name: DAG [62379,62382]
===
match
---
name: bulk_write_to_db [26540,26556]
name: bulk_write_to_db [28256,28272]
===
match
---
assert_stmt [59945,59994]
assert_stmt [61661,61710]
===
match
---
atom_expr [58417,58446]
atom_expr [60133,60162]
===
match
---
operator: , [49551,49552]
operator: , [51267,51268]
===
match
---
operator: , [35534,35535]
operator: , [37250,37251]
===
match
---
name: dag_subclass_diff_name [44747,44769]
name: dag_subclass_diff_name [46463,46485]
===
match
---
expr_stmt [19361,19395]
expr_stmt [19361,19395]
===
match
---
simple_stmt [54147,54164]
simple_stmt [55863,55880]
===
match
---
name: patch [34110,34115]
name: patch [35826,35831]
===
match
---
argument [41273,41293]
argument [42989,43009]
===
match
---
parameters [53421,53472]
parameters [55137,55188]
===
match
---
comparison [66875,66898]
comparison [68591,68614]
===
match
---
name: DummyOperator [35398,35411]
name: DummyOperator [37114,37127]
===
match
---
name: dag_id [57155,57161]
name: dag_id [58871,58877]
===
match
---
name: ti3 [17255,17258]
name: ti3 [17255,17258]
===
match
---
trailer [28664,28751]
trailer [30380,30467]
===
match
---
atom [51320,51333]
atom [53036,53049]
===
match
---
comparison [11731,11793]
comparison [11731,11793]
===
match
---
trailer [7841,7861]
trailer [7841,7861]
===
match
---
name: dag [42308,42311]
name: dag [44024,44027]
===
match
---
name: permissions [63325,63336]
name: permissions [65041,65052]
===
match
---
trailer [2887,2894]
trailer [2887,2894]
===
match
---
name: name [19692,19696]
name: name [19692,19696]
===
match
---
name: isoformat [20861,20870]
name: isoformat [20861,20870]
===
match
---
operator: , [28250,28251]
operator: , [29966,29967]
===
match
---
argument [40430,40450]
argument [42146,42166]
===
match
---
arglist [37572,37593]
arglist [39288,39309]
===
match
---
atom_expr [51580,51635]
atom_expr [53296,53351]
===
match
---
name: dag_id [42245,42251]
name: dag_id [43961,43967]
===
match
---
argument [55542,55565]
argument [57258,57281]
===
match
---
name: task_dict [14785,14794]
name: task_dict [14785,14794]
===
match
---
name: schedule_interval [62225,62242]
name: schedule_interval [63941,63958]
===
match
---
string: "test_schedule_interval" [46813,46837]
string: "test_schedule_interval" [48529,48553]
===
match
---
operator: = [51632,51633]
operator: = [53348,53349]
===
match
---
name: SCHEDULED [47531,47540]
name: SCHEDULED [49247,49256]
===
match
---
number: 1 [16020,16021]
number: 1 [16020,16021]
===
match
---
trailer [30057,30266]
trailer [31773,31982]
===
match
---
operator: , [70476,70477]
operator: , [72192,72193]
===
match
---
string: 'test_scheduler_dagrun_once_with_timedelta_and_catchup_true' [59565,59625]
string: 'test_scheduler_dagrun_once_with_timedelta_and_catchup_true' [61281,61341]
===
match
---
atom_expr [30394,30409]
atom_expr [32110,32125]
===
match
---
operator: = [42283,42284]
operator: = [43999,44000]
===
match
---
comparison [18755,18794]
comparison [18755,18794]
===
match
---
simple_stmt [22707,22776]
simple_stmt [22707,22776]
===
match
---
comp_if [53306,53331]
comp_if [55022,55047]
===
match
---
trailer [3811,3823]
trailer [3811,3823]
===
match
---
name: op3 [9883,9886]
name: op3 [9883,9886]
===
match
---
arglist [47450,47488]
arglist [49166,49204]
===
match
---
name: TI [52495,52497]
name: TI [54211,54213]
===
match
---
operator: , [49221,49222]
operator: , [50937,50938]
===
match
---
operator: } [6070,6071]
operator: } [6070,6071]
===
match
---
trailer [37199,37209]
trailer [38915,38925]
===
match
---
simple_stmt [53547,53562]
simple_stmt [55263,55278]
===
match
---
expr_stmt [7011,7045]
expr_stmt [7011,7045]
===
match
---
operator: - [14689,14690]
operator: - [14689,14690]
===
match
---
comparison [36608,36631]
comparison [38324,38347]
===
match
---
name: dag_id [54453,54459]
name: dag_id [56169,56175]
===
match
---
operator: == [65256,65258]
operator: == [66972,66974]
===
match
---
trailer [32145,32152]
trailer [33861,33868]
===
match
---
expr_stmt [24513,24612]
expr_stmt [26229,26328]
===
match
---
assert_stmt [33632,33667]
assert_stmt [35348,35383]
===
match
---
number: 2016 [61130,61134]
number: 2016 [62846,62850]
===
match
---
expr_stmt [50253,50451]
expr_stmt [51969,52167]
===
match
---
trailer [6418,6422]
trailer [6418,6422]
===
match
---
name: DEFAULT_DATE [70464,70476]
name: DEFAULT_DATE [72180,72192]
===
match
---
trailer [27113,27119]
trailer [28829,28835]
===
match
---
name: DagModel [34665,34673]
name: DagModel [36381,36389]
===
match
---
trailer [20870,20872]
trailer [20870,20872]
===
match
---
parameters [3890,3896]
parameters [3890,3896]
===
match
---
dictorsetmaker [32424,32470]
dictorsetmaker [34140,34186]
===
match
---
expr_stmt [23606,23648]
expr_stmt [23606,23648]
===
match
---
trailer [14801,14803]
trailer [14801,14803]
===
match
---
argument [39113,39133]
argument [40829,40849]
===
match
---
dictorsetmaker [63296,63352]
dictorsetmaker [65012,65068]
===
match
---
operator: = [47094,47095]
operator: = [48810,48811]
===
match
---
name: start_date [19785,19795]
name: start_date [19785,19795]
===
match
---
name: second [56961,56967]
name: second [58677,58683]
===
match
---
name: get_num_task_instances [17691,17713]
name: get_num_task_instances [17691,17713]
===
match
---
suite [25723,26397]
suite [27439,28113]
===
match
---
simple_stmt [13677,13724]
simple_stmt [13677,13724]
===
match
---
argument [69426,69445]
argument [71142,71161]
===
match
---
string: 'airflow' [61263,61272]
string: 'airflow' [62979,62988]
===
match
---
name: op1 [35300,35303]
name: op1 [37016,37019]
===
match
---
with_item [35239,35286]
with_item [36955,37002]
===
match
---
name: start_date [69484,69494]
name: start_date [71200,71210]
===
match
---
operator: , [16975,16976]
operator: , [16975,16976]
===
match
---
name: match [13495,13500]
name: match [13495,13500]
===
match
---
simple_stmt [55320,55329]
simple_stmt [57036,57045]
===
match
---
expr_stmt [7058,7092]
expr_stmt [7058,7092]
===
match
---
number: 2019 [62169,62173]
number: 2019 [63885,63889]
===
match
---
trailer [42264,42282]
trailer [43980,43998]
===
match
---
name: next_date [60219,60228]
name: next_date [61935,61944]
===
match
---
atom_expr [24341,24348]
atom_expr [26057,26064]
===
match
---
number: 1 [17118,17119]
number: 1 [17118,17119]
===
match
---
argument [39270,39294]
argument [40986,41010]
===
match
---
dictorsetmaker [38135,38169]
dictorsetmaker [39851,39885]
===
match
---
string: "scheduled__" [47457,47470]
string: "scheduled__" [49173,49186]
===
match
---
string: "2018-03-25T01:00:00+00:00" [23192,23219]
string: "2018-03-25T01:00:00+00:00" [23192,23219]
===
match
---
expr_stmt [49955,50002]
expr_stmt [51671,51718]
===
match
---
name: op4 [6685,6688]
name: op4 [6685,6688]
===
match
---
operator: , [64204,64205]
operator: , [65920,65921]
===
match
---
assert_stmt [45721,45753]
assert_stmt [47437,47469]
===
match
---
operator: = [14142,14143]
operator: = [14142,14143]
===
match
---
string: 'test_clear_set_dagrun_state' [48171,48200]
string: 'test_clear_set_dagrun_state' [49887,49916]
===
match
---
operator: , [24789,24790]
operator: , [26505,26506]
===
match
---
atom [19381,19395]
atom [19381,19395]
===
match
---
assert_stmt [36056,36092]
assert_stmt [37772,37808]
===
match
---
name: return_num [70850,70860]
name: return_num [72566,72576]
===
match
---
atom_expr [36659,36674]
atom_expr [38375,38390]
===
match
---
name: dag_id [44072,44078]
name: dag_id [45788,45794]
===
match
---
name: new_value [70160,70169]
name: new_value [71876,71885]
===
match
---
name: next_date [58934,58943]
name: next_date [60650,60659]
===
match
---
assert_stmt [36687,36717]
assert_stmt [38403,38433]
===
match
---
arglist [32943,32994]
arglist [34659,34710]
===
match
---
string: 'start_date' [10926,10938]
string: 'start_date' [10926,10938]
===
match
---
trailer [36984,37021]
trailer [38700,38737]
===
match
---
operator: = [28209,28210]
operator: = [29925,29926]
===
match
---
string: 'owner' [43907,43914]
string: 'owner' [45623,45630]
===
match
---
operator: , [62126,62127]
operator: , [63842,63843]
===
match
---
operator: = [41065,41066]
operator: = [42781,42782]
===
match
---
operator: = [66096,66097]
operator: = [67812,67813]
===
match
---
operator: , [60107,60108]
operator: , [61823,61824]
===
match
---
name: dag [68186,68189]
name: dag [69902,69905]
===
match
---
simple_stmt [43316,43347]
simple_stmt [45032,45063]
===
match
---
argument [37641,37648]
argument [39357,39364]
===
match
---
simple_stmt [25576,25605]
simple_stmt [27292,27321]
===
match
---
trailer [43229,43306]
trailer [44945,45022]
===
match
---
operator: - [55925,55926]
operator: - [57641,57642]
===
match
---
string: "2018-10-28T02:50:00+02:00" [21033,21060]
string: "2018-10-28T02:50:00+02:00" [21033,21060]
===
match
---
name: test_task [17053,17062]
name: test_task [17053,17062]
===
match
---
name: mock_stats [39876,39886]
name: mock_stats [41592,41602]
===
match
---
name: dagrun_1 [52002,52010]
name: dagrun_1 [53718,53726]
===
match
---
simple_stmt [6235,6264]
simple_stmt [6235,6264]
===
match
---
string: '*/5 * * * *' [20666,20679]
string: '*/5 * * * *' [20666,20679]
===
match
---
argument [4654,4710]
argument [4654,4710]
===
match
---
name: one [34527,34530]
name: one [36243,36246]
===
match
---
trailer [47819,47833]
trailer [49535,49549]
===
match
---
name: dag_id [64119,64125]
name: dag_id [65835,65841]
===
match
---
simple_stmt [13951,13961]
simple_stmt [13951,13961]
===
match
---
atom_expr [31137,31154]
atom_expr [32853,32870]
===
match
---
name: t_1 [48333,48336]
name: t_1 [50049,50052]
===
match
---
comparison [2977,2996]
comparison [2977,2996]
===
match
---
trailer [27516,27532]
trailer [29232,29248]
===
match
---
operator: = [42232,42233]
operator: = [43948,43949]
===
match
---
name: DAG [40153,40156]
name: DAG [41869,41872]
===
match
---
assert_stmt [23164,23219]
assert_stmt [23164,23219]
===
match
---
name: self [70459,70463]
name: self [72175,72179]
===
match
---
name: datetime [66434,66442]
name: datetime [68150,68158]
===
match
---
name: i [15787,15788]
name: i [15787,15788]
===
match
---
name: timedelta [59711,59720]
name: timedelta [61427,61436]
===
match
---
name: op2 [35827,35830]
name: op2 [37543,37546]
===
match
---
argument [37066,37078]
argument [38782,38794]
===
match
---
name: merge [50500,50505]
name: merge [52216,52221]
===
match
---
name: task_instance_1 [54071,54086]
name: task_instance_1 [55787,55802]
===
match
---
atom_expr [38433,38460]
atom_expr [40149,40176]
===
match
---
name: dag_id [51188,51194]
name: dag_id [52904,52910]
===
match
---
name: State [52538,52543]
name: State [54254,54259]
===
match
---
trailer [25584,25591]
trailer [27300,27307]
===
match
---
name: prev_local [23273,23283]
name: prev_local [23273,23283]
===
match
---
trailer [65475,65477]
trailer [67191,67193]
===
match
---
name: default_args [69781,69793]
name: default_args [71497,71509]
===
match
---
funcdef [21252,22345]
funcdef [21252,22345]
===
match
---
name: prev_local [21007,21017]
name: prev_local [21007,21017]
===
match
---
operator: , [49145,49146]
operator: , [50861,50862]
===
match
---
string: 't1' [56646,56650]
string: 't1' [58362,58366]
===
match
---
arglist [60100,60110]
arglist [61816,61826]
===
match
---
name: session [51040,51047]
name: session [52756,52763]
===
match
---
trailer [18764,18772]
trailer [18764,18772]
===
match
---
number: 0 [17591,17592]
number: 0 [17591,17592]
===
match
---
simple_stmt [20069,20099]
simple_stmt [20069,20099]
===
match
---
name: settings [17423,17431]
name: settings [17423,17431]
===
match
---
atom_expr [18755,18781]
atom_expr [18755,18781]
===
match
---
string: "faketastic" [40438,40450]
string: "faketastic" [42154,42166]
===
match
---
atom_expr [26458,26485]
atom_expr [28174,28201]
===
match
---
name: datetime [56901,56909]
name: datetime [58617,58625]
===
match
---
atom_expr [43800,43822]
atom_expr [45516,45538]
===
match
---
atom_expr [42308,42340]
atom_expr [44024,44056]
===
match
---
string: 'Europe/Zurich' [20328,20343]
string: 'Europe/Zurich' [20328,20343]
===
match
---
simple_stmt [1092,1106]
simple_stmt [1092,1106]
===
match
---
atom_expr [14829,14856]
atom_expr [14829,14856]
===
match
---
parameters [60369,60375]
parameters [62085,62091]
===
match
---
name: test_task_id [16915,16927]
name: test_task_id [16915,16927]
===
match
---
name: following_schedule [27792,27810]
name: following_schedule [29508,29526]
===
match
---
expr_stmt [17130,17155]
expr_stmt [17130,17155]
===
match
---
trailer [46812,46875]
trailer [48528,48591]
===
match
---
argument [54801,54841]
argument [56517,56557]
===
match
---
operator: < [57531,57532]
operator: < [59247,59248]
===
match
---
name: MANUAL [69312,69318]
name: MANUAL [71028,71034]
===
match
---
atom_expr [7599,7716]
atom_expr [7599,7716]
===
match
---
name: DEFAULT_DATE [8559,8571]
name: DEFAULT_DATE [8559,8571]
===
match
---
funcdef [54696,55084]
funcdef [56412,56800]
===
match
---
with_stmt [19542,20099]
with_stmt [19542,20099]
===
match
---
name: isoformat [43421,43430]
name: isoformat [45137,45146]
===
match
---
name: self [5436,5440]
name: self [5436,5440]
===
match
---
trailer [16060,16073]
trailer [16060,16073]
===
match
---
name: task_id [13453,13460]
name: task_id [13453,13460]
===
match
---
trailer [32128,32141]
trailer [33844,33857]
===
match
---
string: 'b_child' [7566,7575]
string: 'b_child' [7566,7575]
===
match
---
atom_expr [58808,58837]
atom_expr [60524,60553]
===
match
---
operator: = [35746,35747]
operator: = [37462,37463]
===
match
---
argument [38015,38027]
argument [39731,39743]
===
match
---
operator: , [60882,60883]
operator: , [62598,62599]
===
match
---
decorated [49394,51270]
decorated [51110,52986]
===
match
---
atom_expr [41568,41584]
atom_expr [43284,43300]
===
match
---
name: depth [13969,13974]
name: depth [13969,13974]
===
match
---
simple_stmt [33041,33073]
simple_stmt [34757,34789]
===
match
---
string: 'test-dag2' [26948,26959]
string: 'test-dag2' [28664,28675]
===
match
---
trailer [64367,64371]
trailer [66083,66087]
===
match
---
name: DagModel [64427,64435]
name: DagModel [66143,66151]
===
match
---
expr_stmt [69550,69581]
expr_stmt [71266,71297]
===
match
---
atom_expr [40061,40077]
atom_expr [41777,41793]
===
match
---
name: self [49547,49551]
name: self [51263,51267]
===
match
---
operator: = [12882,12883]
operator: = [12882,12883]
===
match
---
trailer [15738,15748]
trailer [15738,15748]
===
match
---
funcdef [68462,68607]
funcdef [70178,70323]
===
match
---
trailer [24647,24650]
trailer [26363,26366]
===
match
---
name: op1 [37046,37049]
name: op1 [38762,38765]
===
match
---
parameters [2447,2453]
parameters [2447,2453]
===
match
---
string: '_neq' [44510,44516]
string: '_neq' [46226,46232]
===
match
---
string: 'task' [49983,49989]
string: 'task' [51699,51705]
===
match
---
name: dagrun [49308,49314]
name: dagrun [51024,51030]
===
match
---
atom_expr [68186,68196]
atom_expr [69902,69912]
===
match
---
name: start_date [41314,41324]
name: start_date [43030,43040]
===
match
---
operator: , [41409,41410]
operator: , [43125,43126]
===
match
---
trailer [25396,25399]
trailer [27112,27115]
===
match
---
funcdef [4486,4796]
funcdef [4486,4796]
===
match
---
operator: = [58031,58032]
operator: = [59747,59748]
===
match
---
operator: , [30013,30014]
operator: , [31729,31730]
===
match
---
string: 'dag' [8541,8546]
string: 'dag' [8541,8546]
===
match
---
suite [19844,19897]
suite [19844,19897]
===
match
---
name: parent_dag [62613,62623]
name: parent_dag [64329,64339]
===
match
---
number: 0 [15895,15896]
number: 0 [15895,15896]
===
match
---
expr_stmt [30621,30645]
expr_stmt [32337,32361]
===
match
---
string: """         Test that DagModel.next_dagrun_create_after is set to NULL when the dag cannot be created due to max         active runs being hit.         """ [27258,27413]
string: """         Test that DagModel.next_dagrun_create_after is set to NULL when the dag cannot be created due to max         active runs being hit.         """ [28974,29129]
===
match
---
name: return_num [67134,67144]
name: return_num [68850,68860]
===
match
---
operator: == [69612,69614]
operator: == [71328,71330]
===
match
---
operator: , [26014,26015]
operator: , [27730,27731]
===
match
---
operator: , [48304,48305]
operator: , [50020,50021]
===
match
---
dictorsetmaker [11628,11704]
dictorsetmaker [11628,11704]
===
match
---
string: "2018-03-24T03:00:00+01:00" [22905,22932]
string: "2018-03-24T03:00:00+01:00" [22905,22932]
===
match
---
name: all [31568,31571]
name: all [33284,33287]
===
match
---
operator: = [51469,51470]
operator: = [53185,53186]
===
match
---
atom_expr [63187,63229]
atom_expr [64903,64945]
===
match
---
trailer [69357,69364]
trailer [71073,71080]
===
match
---
name: dag [32599,32602]
name: dag [34315,34318]
===
match
---
name: timezone [12045,12053]
name: timezone [12045,12053]
===
match
---
simple_stmt [16612,16672]
simple_stmt [16612,16672]
===
match
---
name: subdag_id [32453,32462]
name: subdag_id [34169,34178]
===
match
---
atom [53344,53375]
atom [55060,55091]
===
match
---
trailer [30326,30343]
trailer [32042,32059]
===
match
---
name: return_num [70918,70928]
name: return_num [72634,72644]
===
match
---
simple_stmt [65781,65843]
simple_stmt [67497,67559]
===
match
---
argument [5253,5308]
argument [5253,5308]
===
match
---
parameters [10768,10774]
parameters [10768,10774]
===
match
---
trailer [52737,52739]
trailer [54453,54455]
===
match
---
name: session [1962,1969]
name: session [1962,1969]
===
match
---
assert_stmt [46965,47014]
assert_stmt [48681,48730]
===
match
---
trailer [2626,2628]
trailer [2626,2628]
===
match
---
name: dag [40624,40627]
name: dag [42340,42343]
===
match
---
trailer [64909,64916]
trailer [66625,66632]
===
match
---
name: DummyOperator [56679,56692]
name: DummyOperator [58395,58408]
===
match
---
name: dag [6419,6422]
name: dag [6419,6422]
===
match
---
trailer [53118,53143]
trailer [54834,54859]
===
match
---
name: paused_dags [31802,31813]
name: paused_dags [33518,33529]
===
match
---
atom [9507,9526]
atom [9507,9526]
===
match
---
atom_expr [39389,39399]
atom_expr [41105,41115]
===
match
---
atom_expr [24358,24428]
atom_expr [26074,26144]
===
match
---
name: test_dag_id [43973,43984]
name: test_dag_id [45689,45700]
===
match
---
tfpdef [53444,53471]
tfpdef [55160,55187]
===
match
---
string: """Test that dag param is correctly set when using dag decorator""" [70635,70702]
string: """Test that dag param is correctly set when using dag decorator""" [72351,72418]
===
match
---
trailer [23035,23040]
trailer [23035,23040]
===
match
---
argument [64258,64312]
argument [65974,66028]
===
match
---
expr_stmt [61742,61914]
expr_stmt [63458,63630]
===
match
---
name: self [27243,27247]
name: self [28959,28963]
===
match
---
name: dag [3714,3717]
name: dag [3714,3717]
===
match
---
number: 5 [60106,60107]
number: 5 [61822,61823]
===
match
---
number: 1 [13648,13649]
number: 1 [13648,13649]
===
match
---
operator: == [63780,63782]
operator: == [65496,65498]
===
match
---
atom_expr [52096,52108]
atom_expr [53812,53824]
===
match
---
string: 'child_dag' [8288,8299]
string: 'child_dag' [8288,8299]
===
match
---
name: isoformat [21018,21027]
name: isoformat [21018,21027]
===
match
---
name: t_1 [52498,52501]
name: t_1 [54214,54217]
===
match
---
name: template_fields [19315,19330]
name: template_fields [19315,19330]
===
match
---
atom [10808,10836]
atom [10808,10836]
===
match
---
atom_expr [21695,21721]
atom_expr [21695,21721]
===
match
---
name: updated_permissions [63624,63643]
name: updated_permissions [65340,65359]
===
match
---
name: start [21594,21599]
name: start [21594,21599]
===
match
---
name: DAG [1457,1460]
name: DAG [1457,1460]
===
match
---
atom_expr [49282,49294]
atom_expr [50998,51010]
===
match
---
operator: , [12136,12137]
operator: , [12136,12137]
===
match
---
atom_expr [42796,42838]
atom_expr [44512,44554]
===
match
---
comparison [45167,45186]
comparison [46883,46902]
===
match
---
operator: > [57487,57488]
operator: > [59203,59204]
===
match
---
simple_stmt [53748,53945]
simple_stmt [55464,55661]
===
match
---
atom [34863,34925]
atom [36579,36641]
===
match
---
atom_expr [32635,32654]
atom_expr [34351,34370]
===
match
---
trailer [26770,26774]
trailer [28486,28490]
===
match
---
name: job_id [47924,47930]
name: job_id [49640,49646]
===
match
---
trailer [62612,62623]
trailer [64328,64339]
===
match
---
simple_stmt [47078,47118]
simple_stmt [48794,48834]
===
match
---
name: op3 [6364,6367]
name: op3 [6364,6367]
===
match
---
trailer [20700,20719]
trailer [20700,20719]
===
match
---
simple_stmt [21844,21899]
simple_stmt [21844,21899]
===
match
---
trailer [6933,6936]
trailer [6933,6936]
===
match
---
operator: == [31673,31675]
operator: == [33389,33391]
===
match
---
name: period_end [28290,28300]
name: period_end [30006,30016]
===
match
---
atom_expr [14332,14351]
atom_expr [14332,14351]
===
match
---
name: DagRunType [50307,50317]
name: DagRunType [52023,52033]
===
match
---
name: dag [38117,38120]
name: dag [39833,39836]
===
match
---
atom_expr [19310,19330]
atom_expr [19310,19330]
===
match
---
comparison [41823,41856]
comparison [43539,43572]
===
match
---
for_stmt [13110,13361]
for_stmt [13110,13361]
===
match
---
trailer [27658,27660]
trailer [29374,29376]
===
match
---
operator: = [58198,58199]
operator: = [59914,59915]
===
match
---
atom_expr [31411,31573]
atom_expr [33127,33289]
===
match
---
trailer [33284,33294]
trailer [35000,35010]
===
match
---
atom_expr [46096,46133]
atom_expr [47812,47849]
===
match
---
atom_expr [27033,27080]
atom_expr [28749,28796]
===
match
---
atom_expr [41823,41840]
atom_expr [43539,43556]
===
match
---
atom [24301,24319]
atom [26017,26035]
===
match
---
simple_stmt [53482,53508]
simple_stmt [55198,55224]
===
match
---
name: dag [29968,29971]
name: dag [31684,31687]
===
match
---
name: get [42820,42823]
name: get [44536,44539]
===
match
---
operator: , [2339,2340]
operator: , [2339,2340]
===
match
---
name: self [48209,48213]
name: self [49925,49929]
===
match
---
trailer [28218,28224]
trailer [29934,29940]
===
match
---
name: filter [31226,31232]
name: filter [32942,32948]
===
match
---
name: DAGS_FOLDER [34436,34447]
name: DAGS_FOLDER [36152,36163]
===
match
---
operator: == [6885,6887]
operator: == [6885,6887]
===
match
---
name: dags_needing_dagruns [65198,65218]
name: dags_needing_dagruns [66914,66934]
===
match
---
name: task_dict [37200,37209]
name: task_dict [38916,38925]
===
match
---
with_stmt [63653,63746]
with_stmt [65369,65462]
===
match
---
name: dag [44306,44309]
name: dag [46022,46025]
===
match
---
argument [33473,33490]
argument [35189,35206]
===
match
---
name: pytest [36871,36877]
name: pytest [38587,38593]
===
match
---
name: Optional [53458,53466]
name: Optional [55174,55182]
===
match
---
name: dag [34994,34997]
name: dag [36710,36713]
===
match
---
trailer [24684,24690]
trailer [26400,26406]
===
match
---
name: DEFAULT_DATE [18595,18607]
name: DEFAULT_DATE [18595,18607]
===
match
---
simple_stmt [36644,36675]
simple_stmt [38360,38391]
===
match
---
operator: >> [37173,37175]
operator: >> [38889,38891]
===
match
---
argument [53613,53630]
argument [55329,55346]
===
match
---
expr_stmt [63704,63745]
expr_stmt [65420,65461]
===
match
---
operator: { [15571,15572]
operator: { [15571,15572]
===
match
---
operator: = [48475,48476]
operator: = [50191,50192]
===
match
---
name: DEFAULT_DATE [28540,28552]
name: DEFAULT_DATE [30256,30268]
===
match
---
trailer [33690,33707]
trailer [35406,35423]
===
match
---
name: task_id [6937,6944]
name: task_id [6937,6944]
===
match
---
name: session [46210,46217]
name: session [47926,47933]
===
match
---
expr_stmt [47750,47802]
expr_stmt [49466,49518]
===
match
---
name: security [1830,1838]
name: security [1830,1838]
===
match
---
number: 0 [13032,13033]
number: 0 [13032,13033]
===
match
---
trailer [44572,44604]
trailer [46288,46320]
===
match
---
simple_stmt [40147,40371]
simple_stmt [41863,42087]
===
match
---
argument [2913,2938]
argument [2913,2938]
===
match
---
name: datetime [22592,22600]
name: datetime [22592,22600]
===
match
---
name: next_local [21952,21962]
name: next_local [21952,21962]
===
match
---
trailer [31986,31990]
trailer [33702,33706]
===
match
---
operator: = [62103,62104]
operator: = [63819,63820]
===
match
---
simple_stmt [20779,20835]
simple_stmt [20779,20835]
===
match
---
name: template_file [19284,19297]
name: template_file [19284,19297]
===
match
---
operator: = [45904,45905]
operator: = [47620,47621]
===
match
---
suite [3345,3464]
suite [3345,3464]
===
match
---
trailer [31933,31937]
trailer [33649,33653]
===
match
---
trailer [66618,66620]
trailer [68334,68336]
===
match
---
trailer [35023,35028]
trailer [36739,36744]
===
match
---
operator: , [12991,12992]
operator: , [12991,12992]
===
match
---
operator: = [8558,8559]
operator: = [8558,8559]
===
match
---
argument [17297,17311]
argument [17297,17311]
===
match
---
name: session [52445,52452]
name: session [54161,54168]
===
match
---
trailer [9165,9186]
trailer [9165,9186]
===
match
---
argument [9469,9492]
argument [9469,9492]
===
match
---
expr_stmt [60657,60835]
expr_stmt [62373,62551]
===
match
---
name: DAG [42234,42237]
name: DAG [43950,43953]
===
match
---
atom_expr [6110,6138]
atom_expr [6110,6138]
===
match
---
for_stmt [14614,14756]
for_stmt [14614,14756]
===
match
---
operator: , [46602,46603]
operator: , [48318,48319]
===
match
---
expr_stmt [44546,44604]
expr_stmt [46262,46320]
===
match
---
name: dag_run_state [53204,53217]
name: dag_run_state [54920,54933]
===
match
---
name: DEFAULT_DATE [52602,52614]
name: DEFAULT_DATE [54318,54330]
===
match
---
operator: = [55348,55349]
operator: = [57064,57065]
===
match
---
atom_expr [30529,30544]
atom_expr [32245,32260]
===
match
---
operator: = [28629,28630]
operator: = [30345,30346]
===
match
---
operator: = [49028,49029]
operator: = [50744,50745]
===
match
---
name: isoformat [23399,23408]
name: isoformat [23399,23408]
===
match
---
argument [67433,67463]
argument [69149,69179]
===
match
---
operator: = [15355,15356]
operator: = [15355,15356]
===
match
---
simple_stmt [65336,65394]
simple_stmt [67052,67110]
===
match
---
operator: = [40506,40507]
operator: = [42222,42223]
===
match
---
name: lower [29398,29403]
name: lower [31114,31119]
===
match
---
comparison [18711,18739]
comparison [18711,18739]
===
match
---
name: dag [53570,53573]
name: dag [55286,55289]
===
match
---
name: dag_run [39186,39193]
name: dag_run [40902,40909]
===
match
---
simple_stmt [23387,23442]
simple_stmt [23387,23442]
===
match
---
simple_stmt [14821,14857]
simple_stmt [14821,14857]
===
match
---
name: settings [1258,1266]
name: settings [1258,1266]
===
match
---
operator: = [46856,46857]
operator: = [48572,48573]
===
match
---
atom [15421,15440]
atom [15421,15440]
===
match
---
operator: , [54841,54842]
operator: , [56557,56558]
===
match
---
operator: = [7597,7598]
operator: = [7597,7598]
===
match
---
name: clear_db_dags [2495,2508]
name: clear_db_dags [2495,2508]
===
match
---
parameters [13842,13848]
parameters [13842,13848]
===
match
---
dictorsetmaker [24956,25135]
dictorsetmaker [26672,26851]
===
match
---
name: op3 [38235,38238]
name: op3 [39951,39954]
===
match
---
name: normalized_schedule_interval [42312,42340]
name: normalized_schedule_interval [44028,44056]
===
match
---
operator: , [46499,46500]
operator: , [48215,48216]
===
match
---
operator: , [54984,54985]
operator: , [56700,56701]
===
match
---
string: "2018-10-28T02:00:00+01:00" [20876,20903]
string: "2018-10-28T02:00:00+01:00" [20876,20903]
===
match
---
name: subdag [50264,50270]
name: subdag [51980,51986]
===
match
---
name: pipeline [13283,13291]
name: pipeline [13283,13291]
===
match
---
operator: = [52302,52303]
operator: = [54018,54019]
===
match
---
simple_stmt [29092,29165]
simple_stmt [30808,30881]
===
match
---
trailer [65137,65146]
trailer [66853,66862]
===
match
---
operator: = [57054,57055]
operator: = [58770,58771]
===
match
---
name: topological_list [10511,10527]
name: topological_list [10511,10527]
===
match
---
trailer [32291,32364]
trailer [34007,34080]
===
match
---
string: "test_create_dagrun_job_id_is_set" [47767,47801]
string: "test_create_dagrun_job_id_is_set" [49483,49517]
===
match
---
operator: = [18928,18929]
operator: = [18928,18929]
===
match
---
argument [29886,29909]
argument [31602,31625]
===
match
---
simple_stmt [49685,49747]
simple_stmt [51401,51463]
===
match
---
simple_stmt [50796,51059]
simple_stmt [52512,52775]
===
match
---
operator: , [39256,39257]
operator: , [40972,40973]
===
match
---
atom_expr [21485,21519]
atom_expr [21485,21519]
===
match
---
operator: = [58807,58808]
operator: = [60523,60524]
===
match
---
string: 'stage(\\d*).(\\d*)' [14008,14028]
string: 'stage(\\d*).(\\d*)' [14008,14028]
===
match
---
name: tzinfo [34908,34914]
name: tzinfo [36624,36630]
===
match
---
operator: = [21075,21076]
operator: = [21075,21076]
===
match
---
name: set2 [10333,10337]
name: set2 [10333,10337]
===
match
---
name: run [43648,43651]
name: run [45364,45367]
===
match
---
operator: , [43925,43926]
operator: , [45641,45642]
===
match
---
name: subdag [28652,28658]
name: subdag [30368,30374]
===
match
---
name: DummyOperator [30771,30784]
name: DummyOperator [32487,32500]
===
match
---
number: 1 [54839,54840]
number: 1 [56555,56556]
===
match
---
name: one [30420,30423]
name: one [32136,32139]
===
match
---
operator: = [62022,62023]
operator: = [63738,63739]
===
match
---
trailer [42528,42542]
trailer [44244,44258]
===
match
---
suite [18947,19438]
suite [18947,19438]
===
match
---
atom_expr [59711,59728]
atom_expr [61427,61444]
===
match
---
operator: = [37007,37008]
operator: = [38723,38724]
===
match
---
name: op1 [37169,37172]
name: op1 [38885,38888]
===
match
---
name: t_2 [50629,50632]
name: t_2 [52345,52348]
===
match
---
name: start_date [51592,51602]
name: start_date [53308,53318]
===
match
---
arglist [48834,49064]
arglist [50550,50780]
===
match
---
name: parent_dag [51907,51917]
name: parent_dag [53623,53633]
===
match
---
trailer [32097,32110]
trailer [33813,33826]
===
match
---
simple_stmt [61283,61328]
simple_stmt [62999,63044]
===
match
---
atom_expr [68589,68606]
atom_expr [70305,70322]
===
match
---
simple_stmt [42717,42734]
simple_stmt [44433,44450]
===
match
---
name: utcnow [56849,56855]
name: utcnow [58565,58571]
===
match
---
atom_expr [3044,3135]
atom_expr [3044,3135]
===
match
---
simple_stmt [69590,69626]
simple_stmt [71306,71342]
===
match
---
file_input [788,71099]
file_input [788,72815]
===
match
---
simple_stmt [59202,59252]
simple_stmt [60918,60968]
===
match
---
number: 4 [25397,25398]
number: 4 [27113,27114]
===
match
---
name: dag [42499,42502]
name: dag [44215,44218]
===
match
---
name: datetime [12120,12128]
name: datetime [12120,12128]
===
match
---
simple_stmt [36251,36285]
simple_stmt [37967,38001]
===
match
---
atom_expr [2519,2540]
atom_expr [2519,2540]
===
match
---
name: timedelta [66378,66387]
name: timedelta [68094,68103]
===
match
---
trailer [63073,63089]
trailer [64789,64805]
===
match
---
simple_stmt [7101,7136]
simple_stmt [7101,7136]
===
match
---
operator: = [50020,50021]
operator: = [51736,51737]
===
match
---
comparison [62731,62779]
comparison [64447,64495]
===
match
---
name: new_value [70577,70586]
name: new_value [72293,72302]
===
match
---
operator: = [58944,58945]
operator: = [60660,60661]
===
match
---
expr_stmt [21688,21721]
expr_stmt [21688,21721]
===
match
---
trailer [30423,30425]
trailer [32139,32141]
===
match
---
trailer [67046,67059]
trailer [68762,68775]
===
match
---
name: Session [17432,17439]
name: Session [17432,17439]
===
match
---
number: 5 [59872,59873]
number: 5 [61588,61589]
===
match
---
simple_stmt [54333,54514]
simple_stmt [56049,56230]
===
match
---
name: TI [1514,1516]
name: TI [1514,1516]
===
match
---
operator: == [17882,17884]
operator: == [17882,17884]
===
match
---
atom_expr [65349,65393]
atom_expr [67065,67109]
===
match
---
string: """         Tests scheduling a dag with no previous runs         """ [38923,38991]
string: """         Tests scheduling a dag with no previous runs         """ [40639,40707]
===
match
---
name: operator [70435,70443]
name: operator [72151,72159]
===
match
---
trailer [33122,33164]
trailer [34838,34880]
===
match
---
operator: = [61782,61783]
operator: = [63498,63499]
===
match
---
name: dag [63704,63707]
name: dag [65420,65423]
===
match
---
simple_stmt [67191,67205]
simple_stmt [68907,68921]
===
match
---
name: RUNNING [51354,51361]
name: RUNNING [53070,53077]
===
match
---
operator: = [44801,44802]
operator: = [46517,46518]
===
match
---
atom [46436,46460]
atom [48152,48176]
===
match
---
name: DEFAULT_DATE [30714,30726]
name: DEFAULT_DATE [32430,32442]
===
match
---
for_stmt [44697,44819]
for_stmt [46413,46535]
===
match
---
operator: = [19866,19867]
operator: = [19866,19867]
===
match
---
name: timezone [66425,66433]
name: timezone [68141,68149]
===
match
---
argument [52159,52186]
argument [53875,53902]
===
match
---
name: session [50731,50738]
name: session [52447,52454]
===
match
---
trailer [47087,47117]
trailer [48803,48833]
===
match
---
atom_expr [52723,52739]
atom_expr [54439,54455]
===
match
---
parameters [70786,70804]
parameters [72502,72520]
===
match
---
suite [47069,47290]
suite [48785,49006]
===
match
---
name: state [47890,47895]
name: state [49606,49611]
===
match
---
name: default_args [44669,44681]
name: default_args [46385,46397]
===
match
---
atom_expr [7499,7531]
atom_expr [7499,7531]
===
match
---
parameters [69840,69858]
parameters [71556,71574]
===
match
---
expr_stmt [27513,27536]
expr_stmt [29229,29252]
===
match
---
atom_expr [6242,6251]
atom_expr [6242,6251]
===
match
---
atom_expr [48339,48378]
atom_expr [50055,50094]
===
match
---
name: schedule_interval [56439,56456]
name: schedule_interval [58155,58172]
===
match
---
name: DAG [21616,21619]
name: DAG [21616,21619]
===
match
---
name: clear [27653,27658]
name: clear [29369,29374]
===
match
---
name: State [39665,39670]
name: State [41381,41386]
===
match
---
atom_expr [50022,50040]
atom_expr [51738,51756]
===
match
---
name: runs [55320,55324]
name: runs [57036,57040]
===
match
---
name: create_dagrun [40512,40525]
name: create_dagrun [42228,42241]
===
match
---
testlist_comp [14184,14419]
testlist_comp [14184,14419]
===
match
---
trailer [60305,60314]
trailer [62021,62030]
===
match
---
name: test_dag_id [17623,17634]
name: test_dag_id [17623,17634]
===
match
---
simple_stmt [1106,1155]
simple_stmt [1106,1155]
===
match
---
trailer [10904,10980]
trailer [10904,10980]
===
match
---
atom_expr [70320,70337]
atom_expr [72036,72053]
===
match
---
expr_stmt [69258,69456]
expr_stmt [70974,71172]
===
match
---
operator: = [12570,12571]
operator: = [12570,12571]
===
match
---
arglist [48467,48610]
arglist [50183,50326]
===
match
---
parameters [40897,40903]
parameters [42613,42619]
===
match
---
operator: = [8585,8586]
operator: = [8585,8586]
===
match
---
atom_expr [35352,35379]
atom_expr [37068,37095]
===
match
---
trailer [32869,32871]
trailer [34585,34587]
===
match
---
atom_expr [12111,12140]
atom_expr [12111,12140]
===
match
---
operator: = [50903,50904]
operator: = [52619,52620]
===
match
---
name: next_dagrun_after_date [55961,55983]
name: next_dagrun_after_date [57677,57699]
===
match
---
argument [53906,53933]
argument [55622,55649]
===
match
---
name: redirect_stdout [36425,36440]
name: redirect_stdout [38141,38156]
===
match
---
simple_stmt [54071,54100]
simple_stmt [55787,55816]
===
match
---
name: default_view [5069,5081]
name: default_view [5069,5081]
===
match
---
operator: , [17741,17742]
operator: , [17741,17742]
===
match
---
operator: = [14091,14092]
operator: = [14091,14092]
===
match
---
expr_stmt [54888,54932]
expr_stmt [56604,56648]
===
match
---
trailer [50799,50805]
trailer [52515,52521]
===
match
---
argument [17941,17954]
argument [17941,17954]
===
match
---
simple_stmt [37682,37725]
simple_stmt [39398,39441]
===
match
---
trailer [25881,25888]
trailer [27597,27604]
===
match
---
funcdef [51385,53218]
funcdef [53101,54934]
===
match
---
expr_stmt [31381,31583]
expr_stmt [33097,33299]
===
match
---
name: timezone [21570,21578]
name: timezone [21570,21578]
===
match
---
operator: , [51727,51728]
operator: , [53443,53444]
===
match
---
name: self [66524,66528]
name: self [68240,68244]
===
match
---
trailer [47759,47802]
trailer [49475,49518]
===
match
---
name: _next [23171,23176]
name: _next [23171,23176]
===
match
---
operator: = [49929,49930]
operator: = [51645,51646]
===
match
---
name: task_dict [16114,16123]
name: task_dict [16114,16123]
===
match
---
expr_stmt [41609,41659]
expr_stmt [43325,43375]
===
match
---
name: f [18960,18961]
name: f [18960,18961]
===
match
---
trailer [41352,41366]
trailer [43068,43082]
===
match
---
operator: } [10978,10979]
operator: } [10978,10979]
===
match
---
atom_expr [28594,28639]
atom_expr [30310,30355]
===
match
---
name: DAG [44492,44495]
name: DAG [46208,46211]
===
match
---
name: next_dagrun_after_date [57354,57376]
name: next_dagrun_after_date [59070,59092]
===
match
---
simple_stmt [70050,70119]
simple_stmt [71766,71835]
===
match
---
arglist [16479,16543]
arglist [16479,16543]
===
match
---
name: file [1912,1916]
name: file [1912,1916]
===
match
---
arglist [10905,10979]
arglist [10905,10979]
===
match
---
trailer [36671,36674]
trailer [38387,38390]
===
match
---
operator: , [67027,67028]
operator: , [68743,68744]
===
match
---
argument [5369,5390]
argument [5369,5390]
===
match
---
name: suffix [19566,19572]
name: suffix [19566,19572]
===
match
---
arglist [32309,32350]
arglist [34025,34066]
===
match
---
name: Session [48407,48414]
name: Session [50123,50130]
===
match
---
name: datetime [58817,58825]
name: datetime [60533,60541]
===
match
---
trailer [29204,29210]
trailer [30920,30926]
===
match
---
atom_expr [4381,4395]
atom_expr [4381,4395]
===
match
---
name: raises [16570,16576]
name: raises [16570,16576]
===
match
---
name: dag [23755,23758]
name: dag [23755,23758]
===
match
---
name: freezegun [1160,1169]
name: freezegun [1160,1169]
===
match
---
name: dag [37493,37496]
name: dag [39209,39212]
===
match
---
arith_expr [16016,16021]
arith_expr [16016,16021]
===
match
---
expr_stmt [27943,28127]
expr_stmt [29659,29843]
===
match
---
simple_stmt [22424,22496]
simple_stmt [22424,22496]
===
match
---
operator: , [34950,34951]
operator: , [36666,36667]
===
match
---
name: DagModel [28225,28233]
name: DagModel [29941,29949]
===
match
---
name: is_subdag [51939,51948]
name: is_subdag [53655,53664]
===
match
---
simple_stmt [26536,26563]
simple_stmt [28252,28279]
===
match
---
argument [59742,59754]
argument [61458,61470]
===
match
---
operator: = [69229,69230]
operator: = [70945,70946]
===
match
---
simple_stmt [34171,34203]
simple_stmt [35887,35919]
===
match
---
number: 1 [54836,54837]
number: 1 [56552,56553]
===
match
---
trailer [51098,51104]
trailer [52814,52820]
===
match
---
name: state [50579,50584]
name: state [52295,52300]
===
match
---
operator: , [67701,67702]
operator: , [69417,69418]
===
match
---
operator: = [66763,66764]
operator: = [68479,68480]
===
match
---
atom [27690,27695]
atom [29406,29411]
===
match
---
operator: + [44662,44663]
operator: + [46378,46379]
===
match
---
assert_stmt [21775,21835]
assert_stmt [21775,21835]
===
match
---
expr_stmt [8531,8606]
expr_stmt [8531,8606]
===
match
---
expr_stmt [35300,35333]
expr_stmt [37016,37049]
===
match
---
trailer [29853,29954]
trailer [31569,31670]
===
match
---
expr_stmt [57763,57808]
expr_stmt [59479,59524]
===
match
---
name: tzinfo [11879,11885]
name: tzinfo [11879,11885]
===
match
---
atom_expr [16612,16671]
atom_expr [16612,16671]
===
match
---
trailer [25493,25510]
trailer [27209,27226]
===
match
---
operator: = [47579,47580]
operator: = [49295,49296]
===
match
---
string: """Test that dag param is correctly resolved by operator""" [68842,68901]
string: """Test that dag param is correctly resolved by operator""" [70558,70617]
===
match
---
name: execution_date [48582,48596]
name: execution_date [50298,50312]
===
match
---
operator: , [50947,50948]
operator: , [52663,52664]
===
match
---
comparison [4451,4480]
comparison [4451,4480]
===
match
---
name: t_2 [52582,52585]
name: t_2 [54298,54301]
===
match
---
string: 'owner1' [10671,10679]
string: 'owner1' [10671,10679]
===
match
---
name: make_dag [57567,57575]
name: make_dag [59283,59291]
===
match
---
testlist_comp [48036,48047]
testlist_comp [49752,49763]
===
match
---
operator: , [19808,19809]
operator: , [19808,19809]
===
match
---
with_item [38320,38367]
with_item [40036,40083]
===
match
---
operator: { [36082,36083]
operator: { [37798,37799]
===
match
---
operator: = [65913,65914]
operator: = [67629,67630]
===
match
---
name: dag_id [40177,40183]
name: dag_id [41893,41899]
===
match
---
trailer [65625,65627]
trailer [67341,67343]
===
match
---
name: TEST_DATE [2356,2365]
name: TEST_DATE [2356,2365]
===
match
---
name: DAG [26536,26539]
name: DAG [28252,28255]
===
match
---
name: task_id [37218,37225]
name: task_id [38934,38941]
===
match
---
name: state [53195,53200]
name: state [54911,54916]
===
match
---
arglist [5334,5390]
arglist [5334,5390]
===
match
---
trailer [18135,18158]
trailer [18135,18158]
===
match
---
operator: = [20426,20427]
operator: = [20426,20427]
===
match
---
trailer [47958,47974]
trailer [49674,49690]
===
match
---
name: isoformat [23177,23186]
name: isoformat [23177,23186]
===
match
---
argument [37898,37921]
argument [39614,39637]
===
match
---
atom_expr [39100,39175]
atom_expr [40816,40891]
===
match
---
number: 2 [36715,36716]
number: 2 [38431,38432]
===
match
---
classdef [44192,44233]
classdef [45908,45949]
===
match
---
string: 'Also fake' [23809,23820]
string: 'Also fake' [23809,23820]
===
match
---
string: 'noop_pipeline' [67703,67718]
string: 'noop_pipeline' [69419,69434]
===
match
---
name: delta [23657,23662]
name: delta [23657,23662]
===
match
---
testlist_comp [53345,53374]
testlist_comp [55061,55090]
===
match
---
trailer [39632,39647]
trailer [41348,41363]
===
match
---
string: 'dag_paused' [32577,32589]
string: 'dag_paused' [34293,34305]
===
match
---
suite [29835,30545]
suite [31551,32261]
===
match
---
simple_stmt [34328,34366]
simple_stmt [36044,36082]
===
match
---
arglist [70219,70410]
arglist [71935,72126]
===
match
---
comparison [38186,38239]
comparison [39902,39955]
===
match
---
atom_expr [6874,6884]
atom_expr [6874,6884]
===
match
---
arglist [4292,4352]
arglist [4292,4352]
===
match
---
name: xcom_pass_to_op [70134,70149]
name: xcom_pass_to_op [71850,71865]
===
match
---
name: sync_to_db [32603,32613]
name: sync_to_db [34319,34329]
===
match
---
name: mock_stats [40728,40738]
name: mock_stats [42444,42454]
===
match
---
simple_stmt [8186,8254]
simple_stmt [8186,8254]
===
match
---
name: ti4 [17379,17382]
name: ti4 [17379,17382]
===
match
---
atom [32329,32348]
atom [34045,34064]
===
match
---
name: self [13843,13847]
name: self [13843,13847]
===
match
---
name: self [8116,8120]
name: self [8116,8120]
===
match
---
fstring [61783,61820]
fstring [63499,63536]
===
match
---
simple_stmt [38084,38102]
simple_stmt [39800,39818]
===
match
---
funcdef [35137,35611]
funcdef [36853,37327]
===
match
---
string: "t2" [35855,35859]
string: "t2" [37571,37575]
===
match
---
name: dag_id [2888,2894]
name: dag_id [2888,2894]
===
match
---
trailer [29642,29652]
trailer [31358,31368]
===
match
---
string: 'Invalid values of dag.default_view: only support' [4660,4710]
string: 'Invalid values of dag.default_view: only support' [4660,4710]
===
match
---
name: dags_needing_dagruns [65358,65378]
name: dags_needing_dagruns [67074,67094]
===
match
---
operator: = [21640,21641]
operator: = [21640,21641]
===
match
---
trailer [25270,25274]
trailer [26986,26990]
===
match
---
name: DagTag [26362,26368]
name: DagTag [28078,28084]
===
match
---
simple_stmt [69466,69542]
simple_stmt [71182,71258]
===
match
---
arglist [36194,36229]
arglist [37910,37945]
===
match
---
name: t_2 [51844,51847]
name: t_2 [53560,53563]
===
match
---
trailer [58007,58014]
trailer [59723,59730]
===
match
---
expr_stmt [23049,23085]
expr_stmt [23049,23085]
===
match
---
trailer [38590,38645]
trailer [40306,40361]
===
match
---
operator: = [7085,7086]
operator: = [7085,7086]
===
match
---
operator: + [50878,50879]
operator: + [52594,52595]
===
match
---
name: op1 [37214,37217]
name: op1 [38930,38933]
===
match
---
name: test_get_paused_dag_ids [45858,45881]
name: test_get_paused_dag_ids [47574,47597]
===
match
---
argument [48688,48715]
argument [50404,50431]
===
match
---
atom_expr [27513,27532]
atom_expr [29229,29248]
===
match
---
string: 'airflow' [60890,60899]
string: 'airflow' [62606,62615]
===
match
---
simple_stmt [6364,6399]
simple_stmt [6364,6399]
===
match
---
operator: , [43506,43507]
operator: , [45222,45223]
===
match
---
name: op4 [35919,35922]
name: op4 [37635,37638]
===
match
---
name: task_id [40430,40437]
name: task_id [42146,42153]
===
match
---
name: DummyOperator [53646,53659]
name: DummyOperator [55362,55375]
===
match
---
name: xcom_pull [69600,69609]
name: xcom_pull [71316,71325]
===
match
---
name: one [29159,29162]
name: one [30875,30878]
===
match
---
expr_stmt [40498,40574]
expr_stmt [42214,42290]
===
match
---
param [65532,65536]
param [67248,67252]
===
match
---
simple_stmt [70883,70894]
simple_stmt [72599,72610]
===
match
---
operator: = [36522,36523]
operator: = [38238,38239]
===
match
---
operator: = [17421,17422]
operator: = [17421,17422]
===
match
---
name: task_id [27560,27567]
name: task_id [29276,29283]
===
match
---
atom_expr [29284,29304]
atom_expr [31000,31020]
===
match
---
atom [51077,51224]
atom [52793,52940]
===
match
---
name: self [42007,42011]
name: self [43723,43727]
===
match
---
operator: } [37230,37231]
operator: } [38946,38947]
===
match
---
operator: , [26077,26078]
operator: , [27793,27794]
===
match
---
atom_expr [65892,65955]
atom_expr [67608,67671]
===
match
---
operator: == [37210,37212]
operator: == [38926,38928]
===
match
---
simple_stmt [68143,68171]
simple_stmt [69859,69887]
===
match
---
atom_expr [6829,6857]
atom_expr [6829,6857]
===
match
---
name: dag [32635,32638]
name: dag [34351,34354]
===
match
---
simple_stmt [55820,55839]
simple_stmt [57536,57555]
===
match
---
suite [5442,5665]
suite [5442,5665]
===
match
---
simple_stmt [39704,39740]
simple_stmt [41420,41456]
===
match
---
atom [24520,24612]
atom [26236,26328]
===
match
---
atom_expr [37707,37718]
atom_expr [39423,39434]
===
match
---
operator: } [63433,63434]
operator: } [65149,65150]
===
match
---
comparison [5012,5081]
comparison [5012,5081]
===
match
---
atom_expr [67287,67297]
atom_expr [69003,69013]
===
match
---
operator: , [32071,32072]
operator: , [33787,33788]
===
match
---
name: catchup [58900,58907]
name: catchup [60616,60623]
===
match
---
trailer [51326,51331]
trailer [53042,53047]
===
match
---
name: dag [48370,48373]
name: dag [50086,50089]
===
match
---
name: start_date [43742,43752]
name: start_date [45458,45468]
===
match
---
expr_stmt [13478,13510]
expr_stmt [13478,13510]
===
match
---
string: "test_dag" [38324,38334]
string: "test_dag" [40040,40050]
===
match
---
name: dag_id [31615,31621]
name: dag_id [33331,33337]
===
match
---
name: DEFAULT_DATE [51740,51752]
name: DEFAULT_DATE [53456,53468]
===
match
---
string: 'should_fail' [16634,16647]
string: 'should_fail' [16634,16647]
===
match
---
comparison [5605,5664]
comparison [5605,5664]
===
match
---
trailer [32638,32652]
trailer [34354,34368]
===
match
---
arglist [69484,69540]
arglist [71200,71256]
===
match
---
number: 1 [12021,12022]
number: 1 [12021,12022]
===
match
---
operator: , [2384,2385]
operator: , [2384,2385]
===
match
---
suite [68049,68077]
suite [69765,69793]
===
match
---
assert_stmt [41865,41942]
assert_stmt [43581,43658]
===
match
---
name: session [24868,24875]
name: session [26584,26591]
===
match
---
atom [70389,70409]
atom [72105,72125]
===
match
---
simple_stmt [54108,54139]
simple_stmt [55824,55855]
===
match
---
dotted_name [1111,1133]
dotted_name [1111,1133]
===
match
---
parameters [56041,56047]
parameters [57757,57763]
===
match
---
name: session [17743,17750]
name: session [17743,17750]
===
match
---
trailer [68943,68956]
trailer [70659,70672]
===
match
---
number: 2015 [54980,54984]
number: 2015 [56696,56700]
===
match
---
atom_expr [62307,62461]
atom_expr [64023,64177]
===
match
---
operator: = [57020,57021]
operator: = [58736,58737]
===
match
---
name: dag [5649,5652]
name: dag [5649,5652]
===
match
---
operator: = [54577,54578]
operator: = [56293,56294]
===
match
---
operator: , [59679,59680]
operator: , [61395,61396]
===
match
---
name: query [24876,24881]
name: query [26592,26597]
===
match
---
arglist [57589,57743]
arglist [59305,59459]
===
match
---
atom_expr [34408,34448]
atom_expr [36124,36164]
===
match
---
trailer [20860,20870]
trailer [20860,20870]
===
match
---
operator: , [57240,57241]
operator: , [58956,58957]
===
match
---
argument [52366,52393]
argument [54082,54109]
===
match
---
operator: , [50440,50441]
operator: , [52156,52157]
===
match
---
name: session [28211,28218]
name: session [29927,29934]
===
match
---
suite [49568,51270]
suite [51284,52986]
===
match
---
name: commit [54155,54161]
name: commit [55871,55877]
===
match
---
operator: = [17657,17658]
operator: = [17657,17658]
===
match
---
trailer [38681,38687]
trailer [40397,40403]
===
match
---
name: delta [23740,23745]
name: delta [23740,23745]
===
match
---
name: test_next_dagrun_after_date_timedelta_schedule_and_catchup_false [58456,58520]
name: test_next_dagrun_after_date_timedelta_schedule_and_catchup_false [60172,60236]
===
match
---
name: DEFAULT_DATE [70325,70337]
name: DEFAULT_DATE [72041,72053]
===
match
---
name: dag [60879,60882]
name: dag [62595,62598]
===
match
---
simple_stmt [43899,43955]
simple_stmt [45615,45671]
===
match
---
fstring_string: . [12986,12987]
fstring_string: . [12986,12987]
===
match
---
argument [52044,52076]
argument [53760,53792]
===
match
---
simple_stmt [7168,7190]
simple_stmt [7168,7190]
===
match
---
atom_expr [31830,31992]
atom_expr [33546,33708]
===
match
---
string: 't3' [36694,36698]
string: 't3' [38410,38414]
===
match
---
operator: , [33967,33968]
operator: , [35683,35684]
===
match
---
name: run_type [52044,52052]
name: run_type [53760,53768]
===
match
---
name: prev_task [16074,16083]
name: prev_task [16074,16083]
===
match
---
atom_expr [10004,10027]
atom_expr [10004,10027]
===
match
---
operator: , [49726,49727]
operator: , [51442,51443]
===
match
---
trailer [69364,69366]
trailer [71080,71082]
===
match
---
expr_stmt [14133,14492]
expr_stmt [14133,14492]
===
match
---
atom_expr [48519,48531]
atom_expr [50235,50247]
===
match
---
trailer [2422,2431]
trailer [2422,2431]
===
match
---
name: _next [21908,21913]
name: _next [21908,21913]
===
match
---
simple_stmt [50770,50787]
simple_stmt [52486,52503]
===
match
---
operator: == [22251,22253]
operator: == [22251,22253]
===
match
---
trailer [33394,33396]
trailer [35110,35112]
===
match
---
name: add [33429,33432]
name: add [35145,35148]
===
match
---
funcdef [68528,68576]
funcdef [70244,70292]
===
match
---
name: DEFAULT_DATE [54027,54039]
name: DEFAULT_DATE [55743,55755]
===
match
---
operator: , [24770,24771]
operator: , [26486,26487]
===
match
---
name: pipeline [16007,16015]
name: pipeline [16007,16015]
===
match
---
argument [18922,18940]
argument [18922,18940]
===
match
---
operator: = [41300,41301]
operator: = [43016,43017]
===
match
---
simple_stmt [50608,50684]
simple_stmt [52324,52400]
===
match
---
name: BaseOperator [1557,1569]
name: BaseOperator [1557,1569]
===
match
---
name: bash [1690,1694]
name: bash [1690,1694]
===
match
---
name: DagRunType [53799,53809]
name: DagRunType [55515,55525]
===
match
---
operator: = [46675,46676]
operator: = [48391,48392]
===
match
---
name: schedule_interval [20648,20665]
name: schedule_interval [20648,20665]
===
match
---
name: DagModel [65349,65357]
name: DagModel [67065,67073]
===
match
---
trailer [29479,29485]
trailer [31195,31201]
===
match
---
parameters [47350,47356]
parameters [49066,49072]
===
match
---
arglist [21620,21677]
arglist [21620,21677]
===
match
---
name: info [9045,9049]
name: info [9045,9049]
===
match
---
trailer [34708,34714]
trailer [36424,36430]
===
match
---
operator: = [22838,22839]
operator: = [22838,22839]
===
match
---
name: execution_date [39546,39560]
name: execution_date [41262,41276]
===
match
---
operator: = [8093,8094]
operator: = [8093,8094]
===
match
---
atom_expr [34701,34716]
atom_expr [36417,36432]
===
match
---
name: expected_n_schedule_interval [46764,46792]
name: expected_n_schedule_interval [48480,48508]
===
match
---
comparison [45728,45753]
comparison [47444,47469]
===
match
---
name: DagRun [2866,2872]
name: DagRun [2866,2872]
===
match
---
name: doc_md [68224,68230]
name: doc_md [69940,69946]
===
match
---
expr_stmt [36251,36284]
expr_stmt [37967,38000]
===
match
---
trailer [7077,7092]
trailer [7077,7092]
===
match
---
operator: , [32250,32251]
operator: , [33966,33967]
===
match
---
atom_expr [34171,34202]
atom_expr [35887,35918]
===
match
---
operator: = [17043,17044]
operator: = [17043,17044]
===
match
---
argument [57638,57665]
argument [59354,59381]
===
match
---
expr_stmt [65180,65233]
expr_stmt [66896,66949]
===
match
---
operator: + [62012,62013]
operator: + [63728,63729]
===
match
---
atom_expr [2694,2709]
atom_expr [2694,2709]
===
match
---
operator: = [32205,32206]
operator: = [33921,33922]
===
match
---
simple_stmt [59887,59937]
simple_stmt [61603,61653]
===
match
---
name: value [70244,70249]
name: value [71960,71965]
===
match
---
name: dag [6874,6877]
name: dag [6874,6877]
===
match
---
name: DEFAULT_DATE [17328,17340]
name: DEFAULT_DATE [17328,17340]
===
match
---
comparison [6212,6226]
comparison [6212,6226]
===
match
---
operator: == [22902,22904]
operator: == [22902,22904]
===
match
---
operator: + [23685,23686]
operator: + [23685,23686]
===
match
---
trailer [52730,52737]
trailer [54446,54453]
===
match
---
name: dag [56656,56659]
name: dag [58372,58375]
===
match
---
simple_stmt [37320,37375]
simple_stmt [39036,39091]
===
match
---
number: 28 [20406,20408]
number: 28 [20406,20408]
===
match
---
name: DummyOperator [7499,7512]
name: DummyOperator [7499,7512]
===
match
---
name: Session [29033,29040]
name: Session [30749,30756]
===
match
---
name: DummyOperator [9825,9838]
name: DummyOperator [9825,9838]
===
match
---
operator: = [40059,40060]
operator: = [41775,41776]
===
match
---
name: prev [22132,22136]
name: prev [22132,22136]
===
match
---
string: 'Invalid values of dag.orientation: only support' [5259,5308]
string: 'Invalid values of dag.orientation: only support' [5259,5308]
===
match
---
operator: = [62655,62656]
operator: = [64371,64372]
===
match
---
operator: = [27946,27947]
operator: = [29662,29663]
===
match
---
trailer [41624,41630]
trailer [43340,43346]
===
match
---
atom [26293,26325]
atom [28009,28041]
===
match
---
name: dr [47505,47507]
name: dr [49221,49223]
===
match
---
name: task [13697,13701]
name: task [13697,13701]
===
match
---
name: permissions [63377,63388]
name: permissions [65093,65104]
===
match
---
trailer [38836,38848]
trailer [40552,40564]
===
match
---
trailer [30376,30386]
trailer [32092,32102]
===
match
---
simple_stmt [17584,17667]
simple_stmt [17584,17667]
===
match
---
simple_stmt [21564,21601]
simple_stmt [21564,21601]
===
match
---
name: op3 [36343,36346]
name: op3 [38059,38062]
===
match
---
expr_stmt [71026,71049]
expr_stmt [72742,72765]
===
match
---
testlist_comp [28240,28251]
testlist_comp [29956,29967]
===
match
---
arglist [42543,42619]
arglist [44259,44335]
===
match
---
operator: = [10610,10611]
operator: = [10610,10611]
===
match
---
argument [43520,43539]
argument [45236,45255]
===
match
---
operator: = [2932,2933]
operator: = [2932,2933]
===
match
---
arglist [61051,61198]
arglist [62767,62914]
===
match
---
name: op4 [35438,35441]
name: op4 [37154,37157]
===
match
---
operator: , [54039,54040]
operator: , [55755,55756]
===
match
---
atom_expr [21530,21553]
atom_expr [21530,21553]
===
match
---
name: filter [30387,30393]
name: filter [32103,32109]
===
match
---
name: DEFAULT_DATE [51603,51615]
name: DEFAULT_DATE [53319,53331]
===
match
---
trailer [51212,51214]
trailer [52928,52930]
===
match
---
trailer [2739,2744]
trailer [2739,2744]
===
match
---
name: dag_id [34674,34680]
name: dag_id [36390,36396]
===
match
---
operator: = [41280,41281]
operator: = [42996,42997]
===
match
---
simple_stmt [51781,51836]
simple_stmt [53497,53552]
===
match
---
name: DAG [55481,55484]
name: DAG [57197,57200]
===
match
---
operator: = [40437,40438]
operator: = [42153,42154]
===
match
---
name: states [17941,17947]
name: states [17941,17947]
===
match
---
expr_stmt [13987,14029]
expr_stmt [13987,14029]
===
match
---
trailer [23398,23408]
trailer [23398,23408]
===
match
---
assert_stmt [29625,29652]
assert_stmt [31341,31368]
===
match
---
string: 'test' [67299,67305]
string: 'test' [69015,69021]
===
match
---
atom_expr [38135,38146]
atom_expr [39851,39862]
===
match
---
operator: , [63353,63354]
operator: , [65069,65070]
===
match
---
name: session [49056,49063]
name: session [50772,50779]
===
match
---
name: dag [62430,62433]
name: dag [64146,64149]
===
match
---
operator: = [56967,56968]
operator: = [58683,58684]
===
match
---
operator: , [50632,50633]
operator: , [52348,52349]
===
match
---
assert_stmt [34328,34365]
assert_stmt [36044,36081]
===
match
---
simple_stmt [39347,39374]
simple_stmt [41063,41090]
===
match
---
operator: = [17203,17204]
operator: = [17203,17204]
===
match
---
name: BACKFILL_JOB [50111,50123]
name: BACKFILL_JOB [51827,51839]
===
match
---
name: session [50692,50699]
name: session [52408,52415]
===
match
---
atom_expr [35925,35952]
atom_expr [37641,37668]
===
match
---
argument [60858,60873]
argument [62574,62589]
===
match
---
trailer [13999,14007]
trailer [13999,14007]
===
match
---
name: commit [50778,50784]
name: commit [52494,52500]
===
match
---
trailer [7602,7716]
trailer [7602,7716]
===
match
---
operator: = [62305,62306]
operator: = [64021,64022]
===
match
---
atom_expr [70020,70037]
atom_expr [71736,71753]
===
match
---
atom_expr [36871,36962]
atom_expr [38587,38678]
===
match
---
comparison [63761,63802]
comparison [65477,65518]
===
match
---
name: _next [22161,22166]
name: _next [22161,22166]
===
match
---
name: BaseOperator [41260,41272]
name: BaseOperator [42976,42988]
===
match
---
comparison [30394,30418]
comparison [32110,32134]
===
match
---
simple_stmt [20460,20555]
simple_stmt [20460,20555]
===
match
---
name: priority_weight [12993,13008]
name: priority_weight [12993,13008]
===
match
---
atom_expr [30771,30837]
atom_expr [32487,32553]
===
match
---
simple_stmt [7946,7986]
simple_stmt [7946,7986]
===
match
---
expr_stmt [66759,66780]
expr_stmt [68475,68496]
===
match
---
operator: , [28736,28737]
operator: , [30452,30453]
===
match
---
operator: = [5380,5381]
operator: = [5380,5381]
===
match
---
param [4520,4524]
param [4520,4524]
===
match
---
trailer [4393,4395]
trailer [4393,4395]
===
match
---
name: DagTag [24372,24378]
name: DagTag [26088,26094]
===
match
---
atom_expr [20427,20450]
atom_expr [20427,20450]
===
match
---
trailer [20369,20377]
trailer [20369,20377]
===
match
---
atom_expr [26722,26728]
atom_expr [28438,28444]
===
match
---
name: isoformat [22080,22089]
name: isoformat [22080,22089]
===
match
---
import_from [1230,1266]
import_from [1230,1266]
===
match
---
name: State [70357,70362]
name: State [72073,72078]
===
match
---
trailer [20762,20769]
trailer [20762,20769]
===
match
---
trailer [50030,50038]
trailer [51746,51754]
===
match
---
operator: , [61134,61135]
operator: , [62850,62851]
===
match
---
trailer [46204,46206]
trailer [47920,47922]
===
match
---
argument [17313,17369]
argument [17313,17369]
===
match
---
operator: = [23713,23714]
operator: = [23713,23714]
===
match
---
simple_stmt [57763,57809]
simple_stmt [59479,59525]
===
match
---
arith_expr [44496,44516]
arith_expr [46212,46232]
===
match
---
string: 'test-dag' [3731,3741]
string: 'test-dag' [3731,3741]
===
match
---
simple_stmt [12253,12338]
simple_stmt [12253,12338]
===
match
---
fstring [39572,39649]
fstring [41288,41365]
===
match
---
expr_stmt [51462,51511]
expr_stmt [53178,53227]
===
match
---
atom_expr [41872,41902]
atom_expr [43588,43618]
===
match
---
trailer [13701,13723]
trailer [13701,13723]
===
match
---
operator: = [34041,34042]
operator: = [35757,35758]
===
match
---
argument [6014,6037]
argument [6014,6037]
===
match
---
param [3183,3188]
param [3183,3188]
===
match
---
operator: = [44247,44248]
operator: = [45963,45964]
===
match
---
argument [49938,49945]
argument [51654,51661]
===
match
---
trailer [23408,23410]
trailer [23408,23410]
===
match
---
simple_stmt [51068,51225]
simple_stmt [52784,52941]
===
match
---
trailer [60257,60268]
trailer [61973,61984]
===
match
---
atom_expr [4725,4795]
atom_expr [4725,4795]
===
match
---
name: delta [55276,55281]
name: delta [56992,56997]
===
match
---
operator: , [49790,49791]
operator: , [51506,51507]
===
match
---
arglist [23707,23745]
arglist [23707,23745]
===
match
---
trailer [13389,13399]
trailer [13389,13399]
===
match
---
param [23489,23493]
param [23489,23493]
===
match
---
arglist [49139,49146]
arglist [50855,50862]
===
match
---
simple_stmt [8956,8978]
simple_stmt [8956,8978]
===
match
---
atom_expr [7880,7933]
atom_expr [7880,7933]
===
match
---
name: operators [1680,1689]
name: operators [1680,1689]
===
match
---
name: dag [56652,56655]
name: dag [58368,58371]
===
match
---
name: session [64389,64396]
name: session [66105,66112]
===
match
---
fstring_end: ' [12990,12991]
fstring_end: ' [12990,12991]
===
match
---
comparison [24938,25205]
comparison [26654,26921]
===
match
---
string: "@daily" [61856,61864]
string: "@daily" [63572,63580]
===
match
---
operator: { [32019,32020]
operator: { [33735,33736]
===
match
---
name: DAG [37499,37502]
name: DAG [39215,39218]
===
match
---
name: clear_db_runs [2341,2354]
name: clear_db_runs [2341,2354]
===
match
---
name: op3 [8013,8016]
name: op3 [8013,8016]
===
match
---
name: dag [47555,47558]
name: dag [49271,49274]
===
match
---
name: side_effect [40115,40126]
name: side_effect [41831,41842]
===
match
---
name: next_date [59775,59784]
name: next_date [61491,61500]
===
match
---
trailer [2603,2620]
trailer [2603,2620]
===
match
---
name: dag [51827,51830]
name: dag [53543,53546]
===
match
---
number: 5 [60321,60322]
number: 5 [62037,62038]
===
match
---
trailer [50284,50451]
trailer [52000,52167]
===
match
---
operator: = [57113,57114]
operator: = [58829,58830]
===
match
---
operator: , [62211,62212]
operator: , [63927,63928]
===
match
---
name: dag_run [39538,39545]
name: dag_run [41254,41261]
===
match
---
name: next_dagrun_after_date [54904,54926]
name: next_dagrun_after_date [56620,56642]
===
match
---
operator: = [51871,51872]
operator: = [53587,53588]
===
match
---
trailer [2997,3004]
trailer [2997,3004]
===
match
---
operator: , [17923,17924]
operator: , [17923,17924]
===
match
---
string: "dag run execution_date loses precision" [43668,43708]
string: "dag run execution_date loses precision" [45384,45424]
===
match
---
trailer [65168,65170]
trailer [66884,66886]
===
match
---
argument [38620,38644]
argument [40336,40360]
===
match
---
atom_expr [19743,19749]
atom_expr [19743,19749]
===
match
---
number: 2018 [12012,12016]
number: 2018 [12012,12016]
===
match
---
name: task_id [30802,30809]
name: task_id [32518,32525]
===
match
---
name: task_id [6384,6391]
name: task_id [6384,6391]
===
match
---
operator: == [13765,13767]
operator: == [13765,13767]
===
match
---
name: DagModel [41631,41639]
name: DagModel [43347,43355]
===
match
---
simple_stmt [64764,64821]
simple_stmt [66480,66537]
===
match
---
expr_stmt [13426,13461]
expr_stmt [13426,13461]
===
match
---
atom_expr [19690,19696]
atom_expr [19690,19696]
===
match
---
atom [62415,62445]
atom [64131,64161]
===
match
---
name: dag_id [25178,25184]
name: dag_id [26894,26900]
===
match
---
atom_expr [19604,19624]
atom_expr [19604,19624]
===
match
---
funcdef [36723,37232]
funcdef [38439,38948]
===
match
---
atom_expr [27669,27705]
atom_expr [29385,29421]
===
match
---
name: TEST_DATE [39525,39534]
name: TEST_DATE [41241,41250]
===
match
---
suite [65993,66168]
suite [67709,67884]
===
match
---
name: default_view [33647,33659]
name: default_view [35363,35375]
===
match
---
name: operators [1728,1737]
name: operators [1728,1737]
===
match
---
name: start_date [57679,57689]
name: start_date [59395,59405]
===
match
---
name: airflow [2154,2161]
name: airflow [2154,2161]
===
match
---
operator: = [34467,34468]
operator: = [36183,36184]
===
match
---
operator: , [19346,19347]
operator: , [19346,19347]
===
match
---
expr_stmt [4202,4229]
expr_stmt [4202,4229]
===
match
---
simple_stmt [47366,47419]
simple_stmt [49082,49135]
===
match
---
trailer [21716,21721]
trailer [21716,21721]
===
match
---
trailer [62083,62274]
trailer [63799,63990]
===
match
---
name: schedule_interval [57638,57655]
name: schedule_interval [59354,59371]
===
match
---
operator: = [67622,67623]
operator: = [69338,69339]
===
match
---
name: DAG [22713,22716]
name: DAG [22713,22716]
===
match
---
argument [16626,16647]
argument [16626,16647]
===
match
---
funcdef [69045,69093]
funcdef [70761,70809]
===
match
---
string: '2019-06-01' [10940,10952]
string: '2019-06-01' [10940,10952]
===
match
---
name: DagModel [33123,33131]
name: DagModel [34839,34847]
===
match
---
name: max_active_runs [49865,49880]
name: max_active_runs [51581,51596]
===
match
---
atom_expr [29729,29747]
atom_expr [31445,31463]
===
match
---
argument [7031,7044]
argument [7031,7044]
===
match
---
name: query [2960,2965]
name: query [2960,2965]
===
match
---
name: query [3052,3057]
name: query [3052,3057]
===
match
---
name: DAG [24142,24145]
name: DAG [25858,25861]
===
match
---
operator: == [33591,33593]
operator: == [35307,35309]
===
match
---
trailer [22205,22211]
trailer [22205,22211]
===
match
---
name: session [50770,50777]
name: session [52486,52493]
===
match
---
suite [6486,6608]
suite [6486,6608]
===
match
---
simple_stmt [9970,9992]
simple_stmt [9970,9992]
===
match
---
name: set [26344,26347]
name: set [28060,28063]
===
match
---
name: op4 [35552,35555]
name: op4 [37268,37271]
===
match
---
decorated [47990,49389]
decorated [49706,51105]
===
match
---
comparison [33123,33163]
comparison [34839,34879]
===
match
---
number: 10 [20402,20404]
number: 10 [20402,20404]
===
match
---
arglist [49198,49222]
arglist [50914,50938]
===
match
---
param [27243,27247]
param [28959,28963]
===
match
---
trailer [7147,7151]
trailer [7147,7151]
===
match
---
operator: , [40539,40540]
operator: , [42255,42256]
===
match
---
name: utils [2060,2065]
name: utils [2060,2065]
===
match
---
string: """             Regular DAG documentation             """ [67930,67987]
string: """             Regular DAG documentation             """ [69646,69703]
===
match
---
name: DEFAULT_DATE [53880,53892]
name: DEFAULT_DATE [55596,55608]
===
match
---
trailer [14731,14744]
trailer [14731,14744]
===
match
---
string: 'dag-bulk-sync-2' [26663,26680]
string: 'dag-bulk-sync-2' [28379,28396]
===
match
---
name: self [63873,63877]
name: self [65589,65593]
===
match
---
name: isoformat [20792,20801]
name: isoformat [20792,20801]
===
match
---
fstring_end: ' [24544,24545]
fstring_end: ' [26260,26261]
===
match
---
name: self [68827,68831]
name: self [70543,70547]
===
match
---
name: filters [18732,18739]
name: filters [18732,18739]
===
match
---
name: prev [23394,23398]
name: prev [23394,23398]
===
match
---
trailer [12002,12011]
trailer [12002,12011]
===
match
---
comparison [54450,54469]
comparison [56166,56185]
===
match
---
name: name [26384,26388]
name: name [28100,28104]
===
match
---
arith_expr [17079,17120]
arith_expr [17079,17120]
===
match
---
name: merge [52692,52697]
name: merge [54408,54413]
===
match
---
name: start_date [7682,7692]
name: start_date [7682,7692]
===
match
---
atom_expr [70188,70420]
atom_expr [71904,72136]
===
match
---
name: bulk_write_to_db [24668,24684]
name: bulk_write_to_db [26384,26400]
===
match
---
simple_stmt [54748,54879]
simple_stmt [56464,56595]
===
match
---
atom_expr [34222,34285]
atom_expr [35938,36001]
===
match
---
simple_stmt [3295,3308]
simple_stmt [3295,3308]
===
match
---
simple_stmt [4363,4396]
simple_stmt [4363,4396]
===
match
---
name: utils [1906,1911]
name: utils [1906,1911]
===
match
---
operator: , [62173,62174]
operator: , [63889,63890]
===
match
---
number: 27 [21513,21515]
number: 27 [21513,21515]
===
match
---
operator: = [38613,38614]
operator: = [40329,40330]
===
match
---
operator: = [43495,43496]
operator: = [45211,45212]
===
match
---
argument [35893,35905]
argument [37609,37621]
===
match
---
trailer [65790,65842]
trailer [67506,67558]
===
match
---
operator: , [31440,31441]
operator: , [33156,33157]
===
match
---
operator: = [16793,16794]
operator: = [16793,16794]
===
match
---
name: self [12238,12242]
name: self [12238,12242]
===
match
---
name: is_paused_upon_creation [33981,34004]
name: is_paused_upon_creation [35697,35720]
===
match
---
simple_stmt [71026,71050]
simple_stmt [72742,72766]
===
match
---
operator: , [2390,2391]
operator: , [2390,2391]
===
match
---
name: default_args [9494,9506]
name: default_args [9494,9506]
===
match
---
arglist [5235,5308]
arglist [5235,5308]
===
match
---
name: catchup [59742,59749]
name: catchup [61458,61465]
===
match
---
simple_stmt [63015,63242]
simple_stmt [64731,64958]
===
match
---
simple_stmt [24931,25206]
simple_stmt [26647,26922]
===
match
---
trailer [53776,53944]
trailer [55492,55660]
===
match
---
expr_stmt [5538,5589]
expr_stmt [5538,5589]
===
match
---
testlist_comp [26829,26859]
testlist_comp [28545,28575]
===
match
---
trailer [55832,55838]
trailer [57548,57554]
===
match
---
operator: = [40457,40458]
operator: = [42173,42174]
===
match
---
operator: = [30082,30083]
operator: = [31798,31799]
===
match
---
name: dag [67214,67217]
name: dag [68930,68933]
===
match
---
parameters [45881,45887]
parameters [47597,47603]
===
match
---
string: "@once" [54861,54868]
string: "@once" [56577,56584]
===
match
---
atom_expr [55481,55566]
atom_expr [57197,57282]
===
match
---
name: local_tz [20361,20369]
name: local_tz [20361,20369]
===
match
---
name: test_next_dagrun_after_date_start_end_dates [55093,55136]
name: test_next_dagrun_after_date_start_end_dates [56809,56852]
===
match
---
arglist [9462,9526]
arglist [9462,9526]
===
match
---
atom_expr [53759,53944]
atom_expr [55475,55660]
===
match
---
name: dag [8531,8534]
name: dag [8531,8534]
===
match
---
name: models [4725,4731]
name: models [4725,4731]
===
match
---
atom_expr [38204,38215]
atom_expr [39920,39931]
===
match
---
trailer [32855,32869]
trailer [34571,34585]
===
match
---
trailer [54497,54501]
trailer [56213,56217]
===
match
---
atom_expr [2368,2397]
atom_expr [2368,2397]
===
match
---
atom_expr [17391,17404]
atom_expr [17391,17404]
===
match
---
trailer [60090,60099]
trailer [61806,61815]
===
match
---
string: "10 10 * * *" [61184,61197]
string: "10 10 * * *" [62900,62913]
===
match
---
name: test_fails_if_arg_not_set [68277,68302]
name: test_fails_if_arg_not_set [69993,70018]
===
match
---
name: DAG [25413,25416]
name: DAG [27129,27132]
===
match
---
name: timezone [21426,21434]
name: timezone [21426,21434]
===
match
---
name: default_args [66673,66685]
name: default_args [68389,68401]
===
match
---
parameters [47062,47068]
parameters [48778,48784]
===
match
---
operator: = [13489,13490]
operator: = [13489,13490]
===
match
---
operator: , [22608,22609]
operator: , [22608,22609]
===
match
---
simple_stmt [53640,53686]
simple_stmt [55356,55402]
===
match
---
operator: , [28989,28990]
operator: , [30705,30706]
===
match
---
name: start_date [5928,5938]
name: start_date [5928,5938]
===
match
---
argument [54041,54061]
argument [55757,55777]
===
match
---
param [61662,61666]
param [63378,63382]
===
match
---
operator: , [48997,48998]
operator: , [50713,50714]
===
match
---
operator: , [61384,61385]
operator: , [63100,63101]
===
match
---
name: DEFAULT_DATE [19796,19808]
name: DEFAULT_DATE [19796,19808]
===
match
---
number: 5 [59294,59295]
number: 5 [61010,61011]
===
match
---
trailer [43430,43432]
trailer [45146,45148]
===
match
---
name: filter [29496,29502]
name: filter [31212,31218]
===
match
---
name: hash [45769,45773]
name: hash [47485,47489]
===
match
---
argument [65092,65106]
argument [66808,66822]
===
match
---
trailer [6927,6933]
trailer [6927,6933]
===
match
---
argument [17743,17758]
argument [17743,17758]
===
match
---
name: previous_schedule [21699,21716]
name: previous_schedule [21699,21716]
===
match
---
argument [56762,56769]
argument [58478,58485]
===
match
---
atom_expr [38387,38414]
atom_expr [40103,40130]
===
match
---
name: stage [14512,14517]
name: stage [14512,14517]
===
match
---
name: filter [2874,2880]
name: filter [2874,2880]
===
match
---
simple_stmt [66524,66545]
simple_stmt [68240,68261]
===
match
---
name: value [69841,69846]
name: value [71557,71562]
===
match
---
name: test_clear_set_dagrun_state_for_parent_dag [51389,51431]
name: test_clear_set_dagrun_state_for_parent_dag [53105,53147]
===
match
---
name: lower [5054,5059]
name: lower [5054,5059]
===
match
---
with_stmt [25371,25440]
with_stmt [27087,27156]
===
match
---
operator: = [4210,4211]
operator: = [4210,4211]
===
match
---
decorator [47990,48096]
decorator [49706,49812]
===
match
---
import_from [1622,1666]
import_from [1622,1666]
===
match
---
atom_expr [24142,24214]
atom_expr [25858,25930]
===
match
---
name: task_decorator [69873,69887]
name: task_decorator [71589,71603]
===
match
---
import_from [2198,2235]
import_from [2198,2235]
===
match
---
name: start_date [37515,37525]
name: start_date [39231,39241]
===
match
---
arglist [64108,64341]
arglist [65824,66057]
===
match
---
name: pendulum [22515,22523]
name: pendulum [22515,22523]
===
match
---
comparison [35097,35131]
comparison [36813,36847]
===
match
---
trailer [50628,50683]
trailer [52344,52399]
===
match
---
argument [47472,47488]
argument [49188,49204]
===
match
---
string: "test_schedule_dag_start_end_dates" [55431,55466]
string: "test_schedule_dag_start_end_dates" [57147,57182]
===
match
---
name: tasks [9239,9244]
name: tasks [9239,9244]
===
match
---
name: datetime [58426,58434]
name: datetime [60142,60150]
===
match
---
import_as_name [1337,1359]
import_as_name [1337,1359]
===
match
---
trailer [34185,34202]
trailer [35901,35918]
===
match
---
atom [35551,35561]
atom [37267,37277]
===
match
---
name: DEFAULT_DATE [2223,2235]
name: DEFAULT_DATE [2223,2235]
===
match
---
with_stmt [6341,6399]
with_stmt [6341,6399]
===
match
---
trailer [46123,46133]
trailer [47839,47849]
===
match
---
atom_expr [17379,17388]
atom_expr [17379,17388]
===
match
---
simple_stmt [65242,65269]
simple_stmt [66958,66985]
===
match
---
testlist_comp [19334,19347]
testlist_comp [19334,19347]
===
match
---
name: timedelta [46661,46670]
name: timedelta [48377,48386]
===
match
---
operator: = [47211,47212]
operator: = [48927,48928]
===
match
---
atom_expr [61034,61208]
atom_expr [62750,62924]
===
match
---
number: 0 [49325,49326]
number: 0 [51041,51042]
===
match
---
name: execution_date [50550,50564]
name: execution_date [52266,52280]
===
match
---
operator: = [56392,56393]
operator: = [58108,58109]
===
match
---
name: DummyOperator [36303,36316]
name: DummyOperator [38019,38032]
===
match
---
name: models [4950,4956]
name: models [4950,4956]
===
match
---
string: 'owner' [14093,14100]
string: 'owner' [14093,14100]
===
match
---
string: 'test-default_default_view' [4968,4995]
string: 'test-default_default_view' [4968,4995]
===
match
---
name: dag [56707,56710]
name: dag [58423,58426]
===
match
---
string: 'dag2' [6006,6012]
string: 'dag2' [6006,6012]
===
match
---
trailer [37885,37922]
trailer [39601,39638]
===
match
---
number: 1 [48322,48323]
number: 1 [50038,50039]
===
match
---
name: parameterized [51276,51289]
name: parameterized [52992,53005]
===
match
---
number: 1 [58441,58442]
number: 1 [60157,60158]
===
match
---
atom_expr [67191,67204]
atom_expr [68907,68920]
===
match
---
name: datetime [52836,52844]
name: datetime [54552,54560]
===
match
---
assert_stmt [6678,6706]
assert_stmt [6678,6706]
===
match
---
trailer [64547,64553]
trailer [66263,66269]
===
match
---
param [68986,69002]
param [70702,70718]
===
match
---
decorator [67506,67522]
decorator [69222,69238]
===
match
---
name: dag [12157,12160]
name: dag [12157,12160]
===
match
---
parameters [66923,66929]
parameters [68639,68645]
===
match
---
name: depth [13612,13617]
name: depth [13612,13617]
===
match
---
name: start_date [30913,30923]
name: start_date [32629,32639]
===
match
---
arglist [7351,7451]
arglist [7351,7451]
===
match
---
operator: = [36216,36217]
operator: = [37932,37933]
===
match
---
expr_stmt [62471,62496]
expr_stmt [64187,64212]
===
match
---
string: '.test' [51720,51727]
string: '.test' [53436,53443]
===
match
---
simple_stmt [9325,9359]
simple_stmt [9325,9359]
===
match
---
arglist [54196,54313]
arglist [55912,56029]
===
match
---
name: dag [48811,48814]
name: dag [50527,50530]
===
match
---
trailer [30293,30301]
trailer [32009,32017]
===
match
---
name: dag [40147,40150]
name: dag [41863,41866]
===
match
---
name: subdag_id [30621,30630]
name: subdag_id [32337,32346]
===
match
---
name: task_id [7966,7973]
name: task_id [7966,7973]
===
match
---
operator: = [12375,12376]
operator: = [12375,12376]
===
match
---
name: remove [9159,9165]
name: remove [9159,9165]
===
match
---
suite [45888,46323]
suite [47604,48039]
===
match
---
arglist [30075,30252]
arglist [31791,31968]
===
match
---
arglist [58055,58205]
arglist [59771,59921]
===
match
---
name: num [70861,70864]
name: num [72577,72580]
===
match
---
atom_expr [53576,53631]
atom_expr [55292,55347]
===
match
---
name: width [15331,15336]
name: width [15331,15336]
===
match
---
operator: , [61005,61006]
operator: , [62721,62722]
===
match
---
name: num [68073,68076]
name: num [69789,69792]
===
match
---
name: timezone [34998,35006]
name: timezone [36714,36722]
===
match
---
name: op3 [8825,8828]
name: op3 [8825,8828]
===
match
---
string: "t2" [36325,36329]
string: "t2" [38041,38045]
===
match
---
simple_stmt [27882,27934]
simple_stmt [29598,29650]
===
match
---
name: start_date [40471,40481]
name: start_date [42187,42197]
===
match
---
trailer [23884,23895]
trailer [23884,23895]
===
match
---
name: dag_id [26369,26375]
name: dag_id [28085,28091]
===
match
---
trailer [19676,19681]
trailer [19676,19681]
===
match
---
comparison [21166,21219]
comparison [21166,21219]
===
match
---
argument [57108,57115]
argument [58824,58831]
===
match
---
name: task_id [7031,7038]
name: task_id [7031,7038]
===
match
---
simple_stmt [57470,57506]
simple_stmt [59186,59222]
===
match
---
name: synchronize_session [2913,2932]
name: synchronize_session [2913,2932]
===
match
---
trailer [68100,68103]
trailer [69816,69819]
===
match
---
trailer [49472,49480]
trailer [51188,51196]
===
match
---
sync_comp_for [24349,24428]
sync_comp_for [26065,26144]
===
match
---
operator: , [19942,19943]
operator: , [19942,19943]
===
match
---
name: dag [11731,11734]
name: dag [11731,11734]
===
match
---
argument [16486,16509]
argument [16486,16509]
===
match
---
operator: = [57736,57737]
operator: = [59452,59453]
===
match
---
operator: { [25823,25824]
operator: { [27539,27540]
===
match
---
operator: , [18084,18085]
operator: , [18084,18085]
===
match
---
simple_stmt [45996,46013]
simple_stmt [47712,47729]
===
match
---
param [11934,11938]
param [11934,11938]
===
match
---
simple_stmt [22067,22123]
simple_stmt [22067,22123]
===
match
---
name: DEFAULT_DATE [14065,14077]
name: DEFAULT_DATE [14065,14077]
===
match
---
name: dag [43177,43180]
name: dag [44893,44896]
===
match
---
operator: , [14470,14471]
operator: , [14470,14471]
===
match
---
name: isoformat [24028,24037]
name: isoformat [24028,24037]
===
match
---
name: dag_models [65409,65419]
name: dag_models [67125,67135]
===
match
---
name: dr [47550,47552]
name: dr [49266,49268]
===
match
---
name: session [29472,29479]
name: session [31188,31195]
===
match
---
operator: , [35604,35605]
operator: , [37320,37321]
===
match
---
operator: * [13638,13639]
operator: * [13638,13639]
===
match
---
name: dag [45483,45486]
name: dag [47199,47202]
===
match
---
atom_expr [13126,13145]
atom_expr [13126,13145]
===
match
---
name: dag_id [29142,29148]
name: dag_id [30858,30864]
===
match
---
funcdef [33768,34717]
funcdef [35484,36433]
===
match
---
arglist [58826,58836]
arglist [60542,60552]
===
match
---
operator: , [59295,59296]
operator: , [61011,61012]
===
match
---
operator: = [52215,52216]
operator: = [53931,53932]
===
match
---
name: create_dagrun [50271,50284]
name: create_dagrun [51987,52000]
===
match
---
name: orm_dag [29184,29191]
name: orm_dag [30900,30907]
===
match
---
name: DEFAULT_DATE [50865,50877]
name: DEFAULT_DATE [52581,52593]
===
match
---
simple_stmt [3906,4194]
simple_stmt [3906,4194]
===
match
---
with_stmt [24622,24691]
with_stmt [26338,26407]
===
match
---
operator: , [47175,47176]
operator: , [48891,48892]
===
match
---
operator: - [13618,13619]
operator: - [13618,13619]
===
match
---
name: orm_subdag [29562,29572]
name: orm_subdag [31278,31288]
===
match
---
fstring_expr [12983,12986]
fstring_expr [12983,12986]
===
match
---
string: '.template' [19573,19584]
string: '.template' [19573,19584]
===
match
---
comp_op [28146,28152]
comp_op [29862,29868]
===
match
---
string: 'depends_on_past' [56336,56353]
string: 'depends_on_past' [58052,58069]
===
match
---
operator: , [7705,7706]
operator: , [7705,7706]
===
match
---
trailer [14197,14374]
trailer [14197,14374]
===
match
---
string: 'E' [9847,9850]
string: 'E' [9847,9850]
===
match
---
name: isoformat [21793,21802]
name: isoformat [21793,21802]
===
match
---
arglist [62762,62778]
arglist [64478,64494]
===
match
---
dictorsetmaker [15422,15439]
dictorsetmaker [15422,15439]
===
match
---
operator: == [9394,9396]
operator: == [9394,9396]
===
match
---
operator: == [12170,12172]
operator: == [12170,12172]
===
match
---
name: datetime [62753,62761]
name: datetime [64469,64477]
===
match
---
trailer [65989,65992]
trailer [67705,67708]
===
match
---
name: dag [61252,61255]
name: dag [62968,62971]
===
match
---
name: start_date [56503,56513]
name: start_date [58219,58229]
===
match
---
argument [40170,40183]
argument [41886,41899]
===
match
---
string: 'end_date' [11867,11877]
string: 'end_date' [11867,11877]
===
match
---
name: dag_run [39481,39488]
name: dag_run [41197,41204]
===
match
---
name: RUNNING [50591,50598]
name: RUNNING [52307,52314]
===
match
---
argument [62097,62126]
argument [63813,63842]
===
match
---
atom_expr [38153,38164]
atom_expr [39869,39880]
===
match
---
suite [11039,11886]
suite [11039,11886]
===
match
---
operator: , [5367,5368]
operator: , [5367,5368]
===
match
---
name: DeprecationWarning [63671,63689]
name: DeprecationWarning [65387,65405]
===
match
---
operator: { [63038,63039]
operator: { [64754,64755]
===
match
---
name: datetime [61365,61373]
name: datetime [63081,63089]
===
match
---
simple_stmt [48811,49075]
simple_stmt [50527,50791]
===
match
---
operator: { [26624,26625]
operator: { [28340,28341]
===
match
---
atom_expr [19726,19750]
atom_expr [19726,19750]
===
match
---
name: DagRun [51164,51170]
name: DagRun [52880,52886]
===
match
---
trailer [29115,29125]
trailer [30831,30841]
===
match
---
operator: , [32079,32080]
operator: , [33795,33796]
===
match
---
name: start_date [51729,51739]
name: start_date [53445,53455]
===
match
---
argument [64804,64819]
argument [66520,66535]
===
match
---
name: params [3816,3822]
name: params [3816,3822]
===
match
---
operator: = [42588,42589]
operator: = [44304,44305]
===
match
---
name: tags [24190,24194]
name: tags [25906,25910]
===
match
---
string: '.template' [18929,18940]
string: '.template' [18929,18940]
===
match
---
simple_stmt [60657,60836]
simple_stmt [62373,62552]
===
match
---
string: 'test_scheduler_auto_align_1' [60687,60716]
string: 'test_scheduler_auto_align_1' [62403,62432]
===
match
---
trailer [69437,69445]
trailer [71153,71161]
===
match
---
name: BACKFILL_JOB [52271,52283]
name: BACKFILL_JOB [53987,53999]
===
match
---
atom_expr [59899,59936]
atom_expr [61615,61652]
===
match
---
funcdef [12452,13783]
funcdef [12452,13783]
===
match
---
number: 1 [12135,12136]
number: 1 [12135,12136]
===
match
---
expr_stmt [48425,48620]
expr_stmt [50141,50336]
===
match
---
name: flush [19639,19644]
name: flush [19639,19644]
===
match
---
string: 't1' [51561,51565]
string: 't1' [53277,53281]
===
match
---
simple_stmt [29051,29083]
simple_stmt [30767,30799]
===
match
---
arglist [37627,37648]
arglist [39343,39364]
===
match
---
expr_stmt [35392,35425]
expr_stmt [37108,37141]
===
match
---
operator: == [17684,17686]
operator: == [17684,17686]
===
match
---
atom_expr [5323,5391]
atom_expr [5323,5391]
===
match
---
argument [23781,23801]
argument [23781,23801]
===
match
---
trailer [71092,71098]
trailer [72808,72814]
===
match
---
name: self [70050,70054]
name: self [71766,71770]
===
match
---
argument [14079,14111]
argument [14079,14111]
===
match
---
name: op1 [37227,37230]
name: op1 [38943,38946]
===
match
---
operator: , [5625,5626]
operator: , [5625,5626]
===
match
---
name: get_task_instances [69558,69576]
name: get_task_instances [71274,71292]
===
match
---
operator: = [55559,55560]
operator: = [57275,57276]
===
match
---
operator: = [61238,61239]
operator: = [62954,62955]
===
match
---
simple_stmt [31340,31372]
simple_stmt [33056,33088]
===
match
---
operator: = [31001,31002]
operator: = [32717,32718]
===
match
---
name: dag_diff_load_time [45449,45467]
name: dag_diff_load_time [47165,47183]
===
match
---
name: delete [2998,3004]
name: delete [2998,3004]
===
match
---
atom_expr [50143,50155]
atom_expr [51859,51871]
===
match
---
name: set_upstream [8960,8972]
name: set_upstream [8960,8972]
===
match
---
operator: , [52585,52586]
operator: , [54301,54302]
===
match
---
name: noop_pipeline [67624,67637]
name: noop_pipeline [69340,69353]
===
match
---
operator: , [51363,51364]
operator: , [53079,53080]
===
match
---
testlist_comp [46373,46680]
testlist_comp [48089,48396]
===
match
---
name: get_num_task_instances [18136,18158]
name: get_num_task_instances [18136,18158]
===
match
---
name: max_active_runs [49728,49743]
name: max_active_runs [51444,51459]
===
match
---
simple_stmt [68066,68077]
simple_stmt [69782,69793]
===
match
---
name: values [14795,14801]
name: values [14795,14801]
===
match
---
simple_stmt [24664,24691]
simple_stmt [26380,26407]
===
match
---
operator: = [21963,21964]
operator: = [21963,21964]
===
match
---
name: operator [70953,70961]
name: operator [72669,72677]
===
match
---
name: dag [27649,27652]
name: dag [29365,29368]
===
match
---
simple_stmt [59542,59766]
simple_stmt [61258,61482]
===
match
---
name: _next [23258,23263]
name: _next [23258,23263]
===
match
---
name: start_date [56233,56243]
name: start_date [57949,57959]
===
match
---
argument [35412,35424]
argument [37128,37140]
===
match
---
expr_stmt [10606,10681]
expr_stmt [10606,10681]
===
match
---
atom_expr [10430,10449]
atom_expr [10430,10449]
===
match
---
name: DAG [45946,45949]
name: DAG [47662,47665]
===
match
---
arglist [35243,35278]
arglist [36959,36994]
===
match
---
name: datetime [59857,59865]
name: datetime [61573,61581]
===
match
---
name: DEFAULT_DATE [55350,55362]
name: DEFAULT_DATE [57066,57078]
===
match
---
simple_stmt [57560,57754]
simple_stmt [59276,59470]
===
match
---
string: "test_get_paused_dag_ids" [45906,45931]
string: "test_get_paused_dag_ids" [47622,47647]
===
match
---
atom_expr [17423,17441]
atom_expr [17423,17441]
===
match
---
operator: , [64793,64794]
operator: , [66509,66510]
===
match
---
name: DEFAULT_DATE [10634,10646]
name: DEFAULT_DATE [10634,10646]
===
match
---
suite [3554,3824]
suite [3554,3824]
===
match
---
argument [48914,48920]
argument [50630,50636]
===
match
---
sync_comp_for [26729,26776]
sync_comp_for [28445,28492]
===
match
---
simple_stmt [42228,42253]
simple_stmt [43944,43969]
===
match
---
atom_expr [68150,68170]
atom_expr [69866,69886]
===
match
---
simple_stmt [37189,37232]
simple_stmt [38905,38948]
===
match
---
simple_stmt [39658,39696]
simple_stmt [41374,41412]
===
match
---
operator: , [47204,47205]
operator: , [48920,48921]
===
match
---
trailer [30496,30509]
trailer [32212,32225]
===
match
---
name: f [19743,19744]
name: f [19743,19744]
===
match
---
operator: = [23808,23809]
operator: = [23808,23809]
===
match
---
name: op5 [10004,10007]
name: op5 [10004,10007]
===
match
---
simple_stmt [4535,4609]
simple_stmt [4535,4609]
===
match
---
name: set2 [10418,10422]
name: set2 [10418,10422]
===
match
---
number: 1 [14691,14692]
number: 1 [14691,14692]
===
match
---
name: self [39768,39772]
name: self [41484,41488]
===
match
---
string: 'airflow' [64810,64819]
string: 'airflow' [66526,66535]
===
match
---
simple_stmt [1570,1622]
simple_stmt [1570,1622]
===
match
---
operator: { [24323,24324]
operator: { [26039,26040]
===
match
---
operator: , [48531,48532]
operator: , [50247,50248]
===
match
---
trailer [14847,14855]
trailer [14847,14855]
===
match
---
name: DEFAULT_DATE [35266,35278]
name: DEFAULT_DATE [36982,36994]
===
match
---
exprlist [13114,13122]
exprlist [13114,13122]
===
match
---
name: utils [1871,1876]
name: utils [1871,1876]
===
match
---
name: dag_run_state [48949,48962]
name: dag_run_state [50665,50678]
===
match
---
name: task_dict [38121,38130]
name: task_dict [39837,39846]
===
match
---
expr_stmt [21460,21554]
expr_stmt [21460,21554]
===
match
---
simple_stmt [20955,20991]
simple_stmt [20955,20991]
===
match
---
name: model [41872,41877]
name: model [43588,43593]
===
match
---
name: DEFAULT_DATE [24558,24570]
name: DEFAULT_DATE [26274,26286]
===
match
---
simple_stmt [13324,13361]
simple_stmt [13324,13361]
===
match
---
atom_expr [70964,70981]
atom_expr [72680,72697]
===
match
---
name: dag [41349,41352]
name: dag [43065,43068]
===
match
---
operator: , [25965,25966]
operator: , [27681,27682]
===
match
---
name: model [42788,42793]
name: model [44504,44509]
===
match
---
trailer [13135,13145]
trailer [13135,13145]
===
match
---
operator: == [34269,34271]
operator: == [35985,35987]
===
match
---
expr_stmt [64414,64471]
expr_stmt [66130,66187]
===
match
---
operator: , [44327,44328]
operator: , [46043,46044]
===
match
---
name: DAG [67267,67270]
name: DAG [68983,68986]
===
match
---
name: dag_id [31950,31956]
name: dag_id [33666,33672]
===
match
---
string: 'dag' [9462,9467]
string: 'dag' [9462,9467]
===
match
---
string: 'op8' [7129,7134]
string: 'op8' [7129,7134]
===
match
---
name: enumerate [3328,3337]
name: enumerate [3328,3337]
===
match
---
operator: , [61864,61865]
operator: , [63580,63581]
===
match
---
name: DummyOperator [9780,9793]
name: DummyOperator [9780,9793]
===
match
---
argument [17238,17244]
argument [17238,17244]
===
match
---
suite [63879,64556]
suite [65595,66272]
===
match
---
not_test [32631,32654]
not_test [34347,34370]
===
match
---
operator: = [66538,66539]
operator: = [68254,68255]
===
match
---
name: isinstance [67251,67261]
name: isinstance [68967,68977]
===
match
---
string: 'dag_orientation' [5627,5644]
string: 'dag_orientation' [5627,5644]
===
match
---
name: test_create_dagrun_run_id_is_generated [47024,47062]
name: test_create_dagrun_run_id_is_generated [48740,48778]
===
match
---
argument [52951,52973]
argument [54667,54689]
===
match
---
name: execution_date [54012,54026]
name: execution_date [55728,55742]
===
match
---
number: 2 [61010,61011]
number: 2 [62726,62727]
===
match
---
name: start_date [48545,48555]
name: start_date [50261,50271]
===
match
---
trailer [39213,39338]
trailer [40929,41054]
===
match
---
name: schedule_interval [43181,43198]
name: schedule_interval [44897,44914]
===
match
---
name: session [33004,33011]
name: session [34720,34727]
===
match
---
trailer [9026,9028]
trailer [9026,9028]
===
match
---
name: start_date [16486,16496]
name: start_date [16486,16496]
===
match
---
trailer [69798,69811]
trailer [71514,71527]
===
match
---
funcdef [2634,2747]
funcdef [2634,2747]
===
match
---
expr_stmt [21730,21765]
expr_stmt [21730,21765]
===
match
---
name: isinstance [67655,67665]
name: isinstance [69371,69381]
===
match
---
operator: , [67297,67298]
operator: , [69013,69014]
===
match
---
operator: = [13957,13958]
operator: = [13957,13958]
===
match
---
simple_stmt [30275,30304]
simple_stmt [31991,32020]
===
match
---
string: 'test_pickling' [43875,43890]
string: 'test_pickling' [45591,45606]
===
match
---
operator: = [35946,35947]
operator: = [37662,37663]
===
match
---
name: dag [62278,62281]
name: dag [63994,63997]
===
match
---
name: create_session [24253,24267]
name: create_session [25969,25983]
===
match
---
fstring_start: f' [65914,65916]
fstring_start: f' [67630,67632]
===
match
---
operator: + [17092,17093]
operator: + [17092,17093]
===
match
---
atom [39511,39570]
atom [41227,41286]
===
match
---
name: dag [53677,53680]
name: dag [55393,55396]
===
match
---
name: session [65462,65469]
name: session [67178,67185]
===
match
---
trailer [13447,13461]
trailer [13447,13461]
===
match
---
trailer [29339,29352]
trailer [31055,31068]
===
match
---
name: ti2 [17491,17494]
name: ti2 [17491,17494]
===
match
---
name: local_tz [22504,22512]
name: local_tz [22504,22512]
===
match
---
simple_stmt [50524,50600]
simple_stmt [52240,52316]
===
match
---
simple_stmt [60277,60327]
simple_stmt [61993,62043]
===
match
---
atom [49439,49452]
atom [51155,51168]
===
match
---
comparison [51164,51194]
comparison [52880,52910]
===
match
---
name: filter [49174,49180]
name: filter [50890,50896]
===
match
---
import_as_names [1457,1516]
import_as_names [1457,1516]
===
match
---
argument [50298,50330]
argument [52014,52046]
===
match
---
trailer [56929,56937]
trailer [58645,58653]
===
match
---
parameters [19525,19531]
parameters [19525,19531]
===
match
---
name: convert [21136,21143]
name: convert [21136,21143]
===
match
---
suite [59379,60327]
suite [61095,62043]
===
match
---
name: t_1 [49755,49758]
name: t_1 [51471,51474]
===
match
---
expr_stmt [47126,47223]
expr_stmt [48842,48939]
===
match
---
atom_expr [6722,6731]
atom_expr [6722,6731]
===
match
---
operator: , [63548,63549]
operator: , [65264,65265]
===
match
---
name: topological_list [9288,9304]
name: topological_list [9288,9304]
===
match
---
assert_stmt [21159,21219]
assert_stmt [21159,21219]
===
match
---
name: DEFAULT_DATE [35747,35759]
name: DEFAULT_DATE [37463,37475]
===
match
---
simple_stmt [60385,60649]
simple_stmt [62101,62365]
===
match
---
operator: == [32481,32483]
operator: == [34197,34199]
===
match
---
operator: = [24175,24176]
operator: = [25891,25892]
===
match
---
operator: , [32438,32439]
operator: , [34154,34155]
===
match
---
operator: , [64125,64126]
operator: , [65841,65842]
===
match
---
name: types [2125,2130]
name: types [2125,2130]
===
match
---
trailer [65391,65393]
trailer [67107,67109]
===
match
---
atom_expr [16110,16132]
atom_expr [16110,16132]
===
match
---
atom_expr [6279,6286]
atom_expr [6279,6286]
===
match
---
argument [47908,47930]
argument [49624,49646]
===
match
---
name: start_date [19141,19151]
name: start_date [19141,19151]
===
match
---
name: has_task_concurrency_limits [64930,64957]
name: has_task_concurrency_limits [66646,66673]
===
match
---
name: session [49108,49115]
name: session [50824,50831]
===
match
---
name: DEFAULT_DATE [7438,7450]
name: DEFAULT_DATE [7438,7450]
===
match
---
argument [33442,33471]
argument [35158,35187]
===
match
---
name: add_task [42361,42369]
name: add_task [44077,44085]
===
match
---
atom_expr [23286,23308]
atom_expr [23286,23308]
===
match
---
atom_expr [54147,54163]
atom_expr [55863,55879]
===
match
---
arglist [56638,56659]
arglist [58354,58375]
===
match
---
name: dag [51831,51834]
name: dag [53547,53550]
===
match
---
expr_stmt [35827,35860]
expr_stmt [37543,37576]
===
match
---
suite [3435,3464]
suite [3435,3464]
===
match
---
assert_stmt [38179,38239]
assert_stmt [39895,39955]
===
match
---
name: default_args [11614,11626]
name: default_args [11614,11626]
===
match
---
simple_stmt [53570,53632]
simple_stmt [55286,55348]
===
match
---
trailer [41085,41094]
trailer [42801,42810]
===
match
---
with_stmt [35715,36093]
with_stmt [37431,37809]
===
match
---
simple_stmt [67280,67306]
simple_stmt [68996,69022]
===
match
---
name: new_value [70399,70408]
name: new_value [72115,72124]
===
match
---
atom_expr [2471,2486]
atom_expr [2471,2486]
===
match
---
name: sync_to_db [42721,42731]
name: sync_to_db [44437,44447]
===
match
---
trailer [43972,44004]
trailer [45688,45720]
===
match
---
arith_expr [50865,50906]
arith_expr [52581,52622]
===
match
---
name: noop_pipeline [67073,67086]
name: noop_pipeline [68789,68802]
===
match
---
operator: == [3805,3807]
operator: == [3805,3807]
===
match
---
argument [51729,51752]
argument [53445,53468]
===
match
---
string: 'B' [8808,8811]
string: 'B' [8808,8811]
===
match
---
operator: , [9089,9090]
operator: , [9089,9090]
===
match
---
dictorsetmaker [29216,29234]
dictorsetmaker [30932,30950]
===
match
---
simple_stmt [25922,26397]
simple_stmt [27638,28113]
===
match
---
atom [37213,37231]
atom [38929,38947]
===
match
---
operator: , [41312,41313]
operator: , [43028,43029]
===
match
---
param [10591,10595]
param [10591,10595]
===
match
---
name: self [7307,7311]
name: self [7307,7311]
===
match
---
assert_stmt [59202,59251]
assert_stmt [60918,60967]
===
match
---
trailer [64856,64858]
trailer [66572,66574]
===
match
---
testlist_comp [53255,53331]
testlist_comp [54971,55047]
===
match
---
name: settings [50022,50030]
name: settings [51738,51746]
===
match
---
name: dag [42228,42231]
name: dag [43944,43947]
===
match
---
name: op1 [7999,8002]
name: op1 [7999,8002]
===
match
---
number: 0 [62774,62775]
number: 0 [64490,64491]
===
match
---
assert_stmt [63595,63643]
assert_stmt [65311,65359]
===
match
---
fstring_start: f' [24525,24527]
fstring_start: f' [26241,26243]
===
match
---
simple_stmt [47633,47673]
simple_stmt [49349,49389]
===
match
---
string: 'DAG' [11607,11612]
string: 'DAG' [11607,11612]
===
match
---
name: dag [38707,38710]
name: dag [40423,40426]
===
match
---
atom_expr [69794,69811]
atom_expr [71510,71527]
===
match
---
name: dag_id [54463,54469]
name: dag_id [56179,56185]
===
match
---
name: session [48629,48636]
name: session [50345,50352]
===
match
---
name: default_args [70727,70739]
name: default_args [72443,72455]
===
match
---
operator: , [5032,5033]
operator: , [5032,5033]
===
match
---
assert_stmt [67648,67675]
assert_stmt [69364,69391]
===
match
---
name: state [50663,50668]
name: state [52379,52384]
===
match
---
name: DagModel [33433,33441]
name: DagModel [35149,35157]
===
match
---
name: default_args [67857,67869]
name: default_args [69573,69585]
===
match
---
operator: = [48518,48519]
operator: = [50234,50235]
===
match
---
atom_expr [63406,63433]
atom_expr [65122,65149]
===
match
---
name: NONE [53269,53273]
name: NONE [54985,54989]
===
match
---
argument [12993,13015]
argument [12993,13015]
===
match
---
arglist [63898,63963]
arglist [65614,65679]
===
match
---
name: assert_queries_count [26499,26519]
name: assert_queries_count [28215,28235]
===
match
---
name: compile [14000,14007]
name: compile [14000,14007]
===
match
---
parameters [18881,18887]
parameters [18881,18887]
===
match
---
string: "t3" [38023,38027]
string: "t3" [39739,39743]
===
match
---
suite [3897,4481]
suite [3897,4481]
===
match
---
trailer [43420,43430]
trailer [45136,45146]
===
match
---
assert_stmt [27170,27195]
assert_stmt [28886,28911]
===
match
---
atom_expr [42747,42763]
atom_expr [44463,44479]
===
match
---
name: DagModel [31704,31712]
name: DagModel [33420,33428]
===
match
---
trailer [41475,41483]
trailer [43191,43199]
===
match
---
trailer [49121,49160]
trailer [50837,50876]
===
match
---
operator: + [52834,52835]
operator: + [54550,54551]
===
match
---
name: DummyOperator [7544,7557]
name: DummyOperator [7544,7557]
===
match
---
string: 'owner1' [9517,9525]
string: 'owner1' [9517,9525]
===
match
---
operator: = [51075,51076]
operator: = [52791,52792]
===
match
---
name: next_dagrun_after_date [59903,59925]
name: next_dagrun_after_date [61619,61641]
===
match
---
operator: = [47853,47854]
operator: = [49569,49570]
===
match
---
operator: , [12133,12134]
operator: , [12133,12134]
===
match
---
arglist [64778,64819]
arglist [66494,66535]
===
match
---
simple_stmt [28203,28254]
simple_stmt [29919,29970]
===
match
---
name: local_tz [22840,22848]
name: local_tz [22840,22848]
===
match
---
name: start_date [54196,54206]
name: start_date [55912,55922]
===
match
---
name: task_id [49907,49914]
name: task_id [51623,51630]
===
match
---
operator: = [53667,53668]
operator: = [55383,55384]
===
match
---
expr_stmt [29459,29542]
expr_stmt [31175,31258]
===
match
---
name: dag [11765,11768]
name: dag [11765,11768]
===
match
---
atom_expr [29775,29790]
atom_expr [31491,31506]
===
match
---
name: op1 [37943,37946]
name: op1 [39659,39662]
===
match
---
expr_stmt [30847,30861]
expr_stmt [32563,32577]
===
match
---
string: "test-dag" [26474,26484]
string: "test-dag" [28190,28200]
===
match
---
name: sub_dag [38562,38569]
name: sub_dag [40278,40285]
===
match
---
string: "2018-10-28T03:00:00+01:00" [22031,22058]
string: "2018-10-28T03:00:00+01:00" [22031,22058]
===
match
---
atom [65664,65712]
atom [67380,67428]
===
match
---
string: "owner" [66242,66249]
string: "owner" [67958,67965]
===
match
---
expr_stmt [53023,53172]
expr_stmt [54739,54888]
===
match
---
simple_stmt [66759,66781]
simple_stmt [68475,68497]
===
match
---
atom [10245,10255]
atom [10245,10255]
===
match
---
trailer [55748,55754]
trailer [57464,57470]
===
match
---
simple_stmt [39987,40022]
simple_stmt [41703,41738]
===
match
---
trailer [17047,17121]
trailer [17047,17121]
===
match
---
atom [49425,49493]
atom [51141,51209]
===
match
---
name: RUNNING [48069,48076]
name: RUNNING [49785,49792]
===
match
---
operator: = [2366,2367]
operator: = [2366,2367]
===
match
---
atom_expr [49961,50002]
atom_expr [51677,51718]
===
match
---
string: 'A' [8763,8766]
string: 'A' [8763,8766]
===
match
---
name: Optional [1008,1016]
name: Optional [1008,1016]
===
match
---
operator: = [17389,17390]
operator: = [17389,17390]
===
match
---
name: State [17142,17147]
name: State [17142,17147]
===
match
---
operator: , [45956,45957]
operator: , [47672,47673]
===
match
---
trailer [2523,2540]
trailer [2523,2540]
===
match
---
operator: = [65785,65786]
operator: = [67501,67502]
===
match
---
expr_stmt [11584,11715]
expr_stmt [11584,11715]
===
match
---
atom_expr [16893,16942]
atom_expr [16893,16942]
===
match
---
operator: , [52283,52284]
operator: , [53999,54000]
===
match
---
expr_stmt [16256,16302]
expr_stmt [16256,16302]
===
match
---
name: op3 [7946,7949]
name: op3 [7946,7949]
===
match
---
trailer [16478,16544]
trailer [16478,16544]
===
match
---
operator: = [60865,60866]
operator: = [62581,62582]
===
match
---
name: isoformat [20473,20482]
name: isoformat [20473,20482]
===
match
---
operator: , [17634,17635]
operator: , [17634,17635]
===
match
---
trailer [44071,44078]
trailer [45787,45794]
===
match
---
name: schedule_interval [22745,22762]
name: schedule_interval [22745,22762]
===
match
---
name: dags [25434,25438]
name: dags [27150,27154]
===
match
---
name: catchup [57729,57736]
name: catchup [59445,59452]
===
match
---
argument [36271,36283]
argument [37987,37999]
===
match
---
trailer [36440,36455]
trailer [38156,38171]
===
match
---
argument [48834,48857]
argument [50550,50573]
===
match
---
name: dag_id [27756,27762]
name: dag_id [29472,29478]
===
match
---
simple_stmt [36687,36718]
simple_stmt [38403,38434]
===
match
---
name: datetime [64292,64300]
name: datetime [66008,66016]
===
match
---
funcdef [37237,37725]
funcdef [38953,39441]
===
match
---
trailer [27990,27998]
trailer [29706,29714]
===
match
---
return_stmt [68066,68076]
return_stmt [69782,69792]
===
match
---
trailer [34115,34122]
trailer [35831,35838]
===
match
---
operator: == [18782,18784]
operator: == [18782,18784]
===
match
---
name: self [8516,8520]
name: self [8516,8520]
===
match
---
string: "graph" [29936,29943]
string: "graph" [31652,31659]
===
match
---
trailer [19733,19742]
trailer [19733,19742]
===
match
---
simple_stmt [38542,38553]
simple_stmt [40258,40269]
===
match
---
name: DEFAULT_DATE [41325,41337]
name: DEFAULT_DATE [43041,43053]
===
match
---
name: DagModel [64877,64885]
name: DagModel [66593,66601]
===
match
---
trailer [65045,65064]
trailer [66761,66780]
===
match
---
operator: = [55308,55309]
operator: = [57024,57025]
===
match
---
name: test_dag_topological_sort_include_subdag_tasks [7260,7306]
name: test_dag_topological_sort_include_subdag_tasks [7260,7306]
===
match
---
name: list_py_file_paths [34408,34426]
name: list_py_file_paths [36124,36142]
===
match
---
decorator [70818,70834]
decorator [72534,72550]
===
match
---
operator: = [28723,28724]
operator: = [30439,30440]
===
match
---
atom_expr [43526,43539]
atom_expr [45242,45255]
===
match
---
operator: = [43460,43461]
operator: = [45176,45177]
===
match
---
trailer [52755,52761]
trailer [54471,54477]
===
match
---
operator: = [36347,36348]
operator: = [38063,38064]
===
match
---
name: all [31987,31990]
name: all [33703,33706]
===
match
---
operator: = [39235,39236]
operator: = [40951,40952]
===
match
---
suite [35158,35611]
suite [36874,37327]
===
match
---
simple_stmt [10264,10282]
simple_stmt [10264,10282]
===
match
---
trailer [19100,19105]
trailer [19100,19105]
===
match
---
operator: = [69300,69301]
operator: = [71016,71017]
===
match
---
string: "t1" [35809,35813]
string: "t1" [37525,37529]
===
match
---
operator: = [52601,52602]
operator: = [54317,54318]
===
match
---
trailer [70362,70370]
trailer [72078,72086]
===
match
---
parameters [43845,43851]
parameters [45561,45567]
===
match
---
simple_stmt [35873,35907]
simple_stmt [37589,37623]
===
match
---
name: RUNNING [39320,39327]
name: RUNNING [41036,41043]
===
match
---
atom_expr [46892,46924]
atom_expr [48608,48640]
===
match
---
trailer [17296,17370]
trailer [17296,17370]
===
match
---
simple_stmt [52749,53014]
simple_stmt [54465,54730]
===
match
---
operator: , [61820,61821]
operator: , [63536,63537]
===
match
---
name: op1 [35781,35784]
name: op1 [37497,37500]
===
match
---
name: tzinfo [11840,11846]
name: tzinfo [11840,11846]
===
match
---
name: state [69426,69431]
name: state [71142,71147]
===
match
---
trailer [18303,18415]
trailer [18303,18415]
===
match
---
suite [34158,34203]
suite [35874,35919]
===
match
---
operator: , [3321,3322]
operator: , [3321,3322]
===
match
---
name: all [27147,27150]
name: all [28863,28866]
===
match
---
string: 'owner2' [29226,29234]
string: 'owner2' [30942,30950]
===
match
---
name: State [47613,47618]
name: State [49329,49334]
===
match
---
trailer [53579,53631]
trailer [55295,55347]
===
match
---
number: 4 [67202,67203]
number: 4 [68918,68919]
===
match
---
name: execution_date [17189,17203]
name: execution_date [17189,17203]
===
match
---
name: next_date [55001,55010]
name: next_date [56717,56726]
===
match
---
argument [37115,37127]
argument [38831,38843]
===
match
---
atom_expr [62243,62263]
atom_expr [63959,63979]
===
match
---
name: self [68435,68439]
name: self [70151,70155]
===
match
---
number: 1 [53629,53630]
number: 1 [55345,55346]
===
match
---
name: parent_dag [8045,8055]
name: parent_dag [8045,8055]
===
match
---
assert_stmt [54523,54554]
assert_stmt [56239,56270]
===
match
---
number: 1 [61380,61381]
number: 1 [63096,63097]
===
match
---
operator: , [33733,33734]
operator: , [35449,35450]
===
match
---
atom_expr [54579,54596]
atom_expr [56295,56312]
===
match
---
atom [20134,20161]
atom [20134,20161]
===
match
---
funcdef [18844,19484]
funcdef [18844,19484]
===
match
---
name: test_task_id [18186,18198]
name: test_task_id [18186,18198]
===
match
---
arglist [52251,52394]
arglist [53967,54110]
===
match
---
string: 'dag-bulk-sync-3' [26979,26996]
string: 'dag-bulk-sync-3' [28695,28712]
===
match
---
name: test_clear_set_dagrun_state_for_subdag [49508,49546]
name: test_clear_set_dagrun_state_for_subdag [51224,51262]
===
match
---
suite [68309,68794]
suite [70025,70510]
===
match
---
name: dag_id [53531,53537]
name: dag_id [55247,55253]
===
match
---
testlist_comp [26879,26909]
testlist_comp [28595,28625]
===
match
---
trailer [49774,49800]
trailer [51490,51516]
===
match
---
atom_expr [66605,66620]
atom_expr [68321,68336]
===
match
---
name: commit [17566,17572]
name: commit [17566,17572]
===
match
---
atom_expr [23394,23410]
atom_expr [23394,23410]
===
match
---
name: DEFAULT_DATE [15394,15406]
name: DEFAULT_DATE [15394,15406]
===
match
---
comparison [65249,65268]
comparison [66965,66984]
===
match
---
atom_expr [17504,17522]
atom_expr [17504,17522]
===
match
---
atom [31600,31672]
atom [33316,33388]
===
match
---
operator: = [31362,31363]
operator: = [33078,33079]
===
match
---
funcdef [10986,11886]
funcdef [10986,11886]
===
match
---
trailer [28607,28639]
trailer [30323,30355]
===
match
---
name: value [70031,70036]
name: value [71747,71752]
===
match
---
operator: , [48962,48963]
operator: , [50678,50679]
===
match
---
expr_stmt [35484,35517]
expr_stmt [37200,37233]
===
match
---
for_stmt [55848,55903]
for_stmt [57564,57619]
===
match
---
atom_expr [32235,32250]
atom_expr [33951,33966]
===
match
---
name: dag_run_state [49553,49566]
name: dag_run_state [51269,51282]
===
match
---
name: session [53695,53702]
name: session [55411,55418]
===
match
---
trailer [65218,65227]
trailer [66934,66943]
===
match
---
name: merge [53961,53966]
name: merge [55677,55682]
===
match
---
name: DagModel [31233,31241]
name: DagModel [32949,32957]
===
match
---
trailer [27074,27078]
trailer [28790,28794]
===
match
---
number: 1 [59246,59247]
number: 1 [60962,60963]
===
match
---
string: 'C' [9757,9760]
string: 'C' [9757,9760]
===
match
---
assert_stmt [34541,34569]
assert_stmt [36257,36285]
===
match
---
atom_expr [56734,56770]
atom_expr [58450,58486]
===
match
---
operator: { [25743,25744]
operator: { [27459,27460]
===
match
---
trailer [14468,14478]
trailer [14468,14478]
===
match
---
string: 'Europe/Zurich' [34823,34838]
string: 'Europe/Zurich' [36539,36554]
===
match
---
trailer [10446,10449]
trailer [10446,10449]
===
match
---
name: start_date [14054,14064]
name: start_date [14054,14064]
===
match
---
string: "graph" [30513,30520]
string: "graph" [32229,32236]
===
match
---
name: including_subdags [31768,31785]
name: including_subdags [33484,33501]
===
match
---
trailer [33441,33491]
trailer [35157,35207]
===
match
---
atom_expr [37689,37702]
atom_expr [39405,39418]
===
match
---
simple_stmt [41609,41660]
simple_stmt [43325,43376]
===
match
---
operator: = [33063,33064]
operator: = [34779,34780]
===
match
---
name: local_tz [21406,21414]
name: local_tz [21406,21414]
===
match
---
argument [42600,42619]
argument [44316,44335]
===
match
---
suite [26445,26486]
suite [28161,28202]
===
match
---
name: period_end [27923,27933]
name: period_end [29639,29649]
===
match
---
operator: == [37703,37705]
operator: == [39419,39421]
===
match
---
name: delta [55408,55413]
name: delta [57124,57129]
===
match
---
simple_stmt [39426,39460]
simple_stmt [41142,41176]
===
match
---
trailer [61758,61914]
trailer [63474,63630]
===
match
---
operator: { [46167,46168]
operator: { [47883,47884]
===
match
---
number: 0 [56958,56959]
number: 0 [58674,58675]
===
match
---
operator: , [41293,41294]
operator: , [43009,43010]
===
match
---
param [12238,12242]
param [12238,12242]
===
match
---
name: op2 [8006,8009]
name: op2 [8006,8009]
===
match
---
operator: >> [56794,56796]
operator: >> [58510,58512]
===
match
---
name: DagModel [32120,32128]
name: DagModel [33836,33844]
===
match
---
expr_stmt [60219,60268]
expr_stmt [61935,61984]
===
match
---
comparison [2881,2904]
comparison [2881,2904]
===
match
---
argument [18086,18101]
argument [18086,18101]
===
match
---
trailer [60234,60257]
trailer [61950,61973]
===
match
---
atom_expr [29102,29164]
atom_expr [30818,30880]
===
match
---
atom [17925,17939]
atom [17925,17939]
===
match
---
name: DAG [54754,54757]
name: DAG [56470,56473]
===
match
---
string: "0 0 * * *" [46410,46421]
string: "0 0 * * *" [48126,48137]
===
match
---
atom_expr [69301,69324]
atom_expr [71017,71040]
===
match
---
trailer [40511,40525]
trailer [42227,42241]
===
match
---
name: clear [40803,40808]
name: clear [42519,42524]
===
match
---
name: DummyOperator [35787,35800]
name: DummyOperator [37503,37516]
===
match
---
name: state [53279,53284]
name: state [54995,55000]
===
match
---
name: extend [10269,10275]
name: extend [10269,10275]
===
match
---
arglist [28510,28553]
arglist [30226,30269]
===
match
---
comparison [45050,45075]
comparison [46766,46791]
===
match
---
string: 'owner1' [6735,6743]
string: 'owner1' [6735,6743]
===
match
---
operator: == [29593,29595]
operator: == [31309,31311]
===
match
---
simple_stmt [22132,22168]
simple_stmt [22132,22168]
===
match
---
name: datetime [57028,57036]
name: datetime [58744,58752]
===
match
---
expr_stmt [49308,49327]
expr_stmt [51024,51043]
===
match
---
simple_stmt [9077,9101]
simple_stmt [9077,9101]
===
match
---
string: 'dag_default_view' [33735,33753]
string: 'dag_default_view' [35451,35469]
===
match
---
parameters [16404,16410]
parameters [16404,16410]
===
match
---
arglist [12968,13015]
arglist [12968,13015]
===
match
---
trailer [51938,51948]
trailer [53654,53664]
===
match
---
simple_stmt [38519,38530]
simple_stmt [40235,40246]
===
match
---
arglist [5921,5985]
arglist [5921,5985]
===
match
---
name: op1 [38041,38044]
name: op1 [39757,39760]
===
match
---
name: priority_weight_total [16281,16302]
name: priority_weight_total [16281,16302]
===
match
---
trailer [32284,32291]
trailer [34000,34007]
===
match
---
trailer [19047,19052]
trailer [19047,19052]
===
match
---
operator: = [68938,68939]
operator: = [70654,70655]
===
match
---
simple_stmt [6272,6295]
simple_stmt [6272,6295]
===
match
---
atom_expr [54624,54643]
atom_expr [56340,56359]
===
match
---
arglist [16626,16670]
arglist [16626,16670]
===
match
---
name: i [24595,24596]
name: i [26311,26312]
===
match
---
number: 10 [60771,60773]
number: 10 [62487,62489]
===
match
---
argument [40471,40486]
argument [42187,42202]
===
match
---
name: task_id [41273,41280]
name: task_id [42989,42996]
===
match
---
parameters [48131,48152]
parameters [49847,49868]
===
match
---
trailer [40531,40539]
trailer [42247,42255]
===
match
---
simple_stmt [62789,62844]
simple_stmt [64505,64560]
===
match
---
simple_stmt [50460,50484]
simple_stmt [52176,52200]
===
match
---
name: datetime [60750,60758]
name: datetime [62466,62474]
===
match
---
operator: { [25929,25930]
operator: { [27645,27646]
===
match
---
trailer [18437,18439]
trailer [18437,18439]
===
match
---
argument [16961,16975]
argument [16961,16975]
===
match
---
simple_stmt [5911,5987]
simple_stmt [5911,5987]
===
match
---
name: session [65126,65133]
name: session [66842,66849]
===
match
---
atom_expr [13068,13083]
atom_expr [13068,13083]
===
match
---
name: utc [20564,20567]
name: utc [20564,20567]
===
match
---
name: create_session [46190,46204]
name: create_session [47906,47920]
===
match
---
name: BaseOperator [42370,42382]
name: BaseOperator [44086,44098]
===
match
---
name: next_date [59144,59153]
name: next_date [60860,60869]
===
match
---
comparison [47505,47540]
comparison [49221,49256]
===
match
---
simple_stmt [55276,55312]
simple_stmt [56992,57028]
===
match
---
arglist [36985,37020]
arglist [38701,38736]
===
match
---
atom_expr [70274,70291]
atom_expr [71990,72007]
===
match
---
operator: { [63272,63273]
operator: { [64988,64989]
===
match
---
operator: } [65929,65930]
operator: } [67645,67646]
===
match
---
atom_expr [17142,17155]
atom_expr [17142,17155]
===
match
---
operator: = [20040,20041]
operator: = [20040,20041]
===
match
---
simple_stmt [17531,17550]
simple_stmt [17531,17550]
===
match
---
simple_stmt [29277,29317]
simple_stmt [30993,31033]
===
match
---
atom_expr [27106,27152]
atom_expr [28822,28868]
===
match
---
name: SubDagOperator [51781,51795]
name: SubDagOperator [53497,53511]
===
match
---
comparison [60970,61018]
comparison [62686,62734]
===
match
---
operator: == [6732,6734]
operator: == [6732,6734]
===
match
---
trailer [5613,5645]
trailer [5613,5645]
===
match
---
name: session [25859,25866]
name: session [27575,27582]
===
match
---
name: args [44682,44686]
name: args [46398,46402]
===
match
---
suite [18481,18839]
suite [18481,18839]
===
match
---
argument [6843,6856]
argument [6843,6856]
===
match
---
operator: , [40450,40451]
operator: , [42166,42167]
===
match
---
operator: = [6000,6001]
operator: = [6000,6001]
===
match
---
atom_expr [31918,31958]
atom_expr [33634,33674]
===
match
---
name: days [50899,50903]
name: days [52615,52619]
===
match
---
string: 'test-dag' [25074,25084]
string: 'test-dag' [26790,26800]
===
match
---
string: 'Also fake' [40458,40469]
string: 'Also fake' [42174,42185]
===
match
---
name: tearDown [66554,66562]
name: tearDown [68270,68278]
===
match
---
name: op2 [38064,38067]
name: op2 [39780,39783]
===
match
---
suite [43852,44093]
suite [45568,45809]
===
match
---
parameters [10590,10596]
parameters [10590,10596]
===
match
---
string: "test_dag" [36985,36995]
string: "test_dag" [38701,38711]
===
match
---
operator: , [18358,18359]
operator: , [18358,18359]
===
match
---
atom_expr [8345,8404]
atom_expr [8345,8404]
===
match
---
operator: = [49959,49960]
operator: = [51675,51676]
===
match
---
arglist [49775,49799]
arglist [51491,51515]
===
match
---
name: next_dagrun_after_date [57780,57802]
name: next_dagrun_after_date [59496,59518]
===
match
---
shift_expr [35530,35561]
shift_expr [37246,37277]
===
match
---
trailer [17147,17155]
trailer [17147,17155]
===
match
---
name: subdag [7916,7922]
name: subdag [7916,7922]
===
match
---
atom_expr [64707,64755]
atom_expr [66423,66471]
===
match
---
argument [61838,61864]
argument [63554,63580]
===
match
---
operator: = [50142,50143]
operator: = [51858,51859]
===
match
---
param [68827,68831]
param [70543,70547]
===
match
---
atom_expr [15661,15680]
atom_expr [15661,15680]
===
match
---
name: test_clear_set_dagrun_state [48104,48131]
name: test_clear_set_dagrun_state [49820,49847]
===
match
---
name: dag [51920,51923]
name: dag [53636,53639]
===
match
---
name: model [42896,42901]
name: model [44612,44617]
===
match
---
arglist [16907,16941]
arglist [16907,16941]
===
match
---
name: dag_id [55492,55498]
name: dag_id [57208,57214]
===
match
---
name: DummyOperator [6829,6842]
name: DummyOperator [6829,6842]
===
match
---
name: minutes [66388,66395]
name: minutes [68104,68111]
===
match
---
trailer [22795,22813]
trailer [22795,22813]
===
match
---
trailer [19881,19896]
trailer [19881,19896]
===
match
---
operator: , [43471,43472]
operator: , [45187,45188]
===
match
---
operator: { [24301,24302]
operator: { [26017,26018]
===
match
---
string: 'dag' [14047,14052]
string: 'dag' [14047,14052]
===
match
---
name: StringIO [36444,36452]
name: StringIO [38160,38168]
===
match
---
argument [17362,17368]
argument [17362,17368]
===
match
---
funcdef [56193,56825]
funcdef [57909,58541]
===
match
---
name: dag [16929,16932]
name: dag [16929,16932]
===
match
---
name: DagTag [25186,25192]
name: DagTag [26902,26908]
===
match
---
operator: = [39194,39195]
operator: = [40910,40911]
===
match
---
operator: = [52493,52494]
operator: = [54209,54210]
===
match
---
name: self [66563,66567]
name: self [68279,68283]
===
match
---
name: dag [24223,24226]
name: dag [25939,25942]
===
match
---
simple_stmt [23504,23598]
simple_stmt [23504,23598]
===
match
---
argument [29923,29943]
argument [31639,31659]
===
match
---
name: dag_subclass_diff_name [44613,44635]
name: dag_subclass_diff_name [46329,46351]
===
match
---
name: all [26771,26774]
name: all [28487,28490]
===
match
---
atom_expr [19099,19105]
atom_expr [19099,19105]
===
match
---
simple_stmt [68318,68398]
simple_stmt [70034,70114]
===
match
---
with_stmt [16558,16672]
with_stmt [16558,16672]
===
match
---
expr_stmt [41103,41155]
expr_stmt [42819,42871]
===
match
---
name: DummyOperator [61217,61230]
name: DummyOperator [62933,62946]
===
match
---
funcdef [16677,18440]
funcdef [16677,18440]
===
match
---
operator: , [7413,7414]
operator: , [7413,7414]
===
match
---
name: basename [19090,19098]
name: basename [19090,19098]
===
match
---
operator: - [55401,55402]
operator: - [57117,57118]
===
match
---
operator: } [24543,24544]
operator: } [26259,26260]
===
match
---
suite [35768,36093]
suite [37484,37809]
===
match
---
atom_expr [25490,25516]
atom_expr [27206,27232]
===
match
---
name: dags [26557,26561]
name: dags [28273,28277]
===
match
---
operator: == [29748,29750]
operator: == [31464,31466]
===
match
---
operator: , [12361,12362]
operator: , [12361,12362]
===
match
---
expr_stmt [8987,9028]
expr_stmt [8987,9028]
===
match
---
name: dag [62390,62393]
name: dag [64106,64109]
===
match
---
operator: = [41110,41111]
operator: = [42826,42827]
===
match
---
name: task_id [38226,38233]
name: task_id [39942,39949]
===
match
---
operator: , [66073,66074]
operator: , [67789,67790]
===
match
---
atom_expr [38572,38645]
atom_expr [40288,40361]
===
match
---
simple_stmt [1817,1858]
simple_stmt [1817,1858]
===
match
---
expr_stmt [59887,59936]
expr_stmt [61603,61652]
===
match
---
param [2448,2452]
param [2448,2452]
===
match
---
assert_stmt [57470,57505]
assert_stmt [59186,59221]
===
match
---
trailer [22716,22775]
trailer [22716,22775]
===
match
---
name: next_dagrun [28033,28044]
name: next_dagrun [29749,29760]
===
match
---
suite [13245,13361]
suite [13245,13361]
===
match
---
trailer [17622,17666]
trailer [17622,17666]
===
match
---
operator: , [60873,60874]
operator: , [62589,62590]
===
match
---
arglist [12356,12396]
arglist [12356,12396]
===
match
---
atom_expr [64989,65003]
atom_expr [66705,66719]
===
match
---
name: refresh_from_db [43600,43615]
name: refresh_from_db [45316,45331]
===
match
---
trailer [17888,17911]
trailer [17888,17911]
===
match
---
operator: = [60878,60879]
operator: = [62594,62595]
===
match
---
operator: { [14092,14093]
operator: { [14092,14093]
===
match
---
argument [9749,9760]
argument [9749,9760]
===
match
---
name: dag [67666,67669]
name: dag [69382,69385]
===
match
---
name: topological_list [9050,9066]
name: topological_list [9050,9066]
===
match
---
trailer [33310,33316]
trailer [35026,35032]
===
match
---
name: stdout [36515,36521]
name: stdout [38231,38237]
===
match
---
operator: = [38431,38432]
operator: = [40147,40148]
===
match
---
operator: = [4379,4380]
operator: = [4379,4380]
===
match
---
operator: = [47814,47815]
operator: = [49530,49531]
===
match
---
param [37305,37309]
param [39021,39025]
===
match
---
string: 'owner' [56300,56307]
string: 'owner' [58016,58023]
===
match
---
assert_stmt [37189,37231]
assert_stmt [38905,38947]
===
match
---
name: owner [64013,64018]
name: owner [65729,65734]
===
match
---
argument [52090,52108]
argument [53806,53824]
===
match
---
name: dag [62626,62629]
name: dag [64342,64345]
===
match
---
atom_expr [53799,53822]
atom_expr [55515,55538]
===
match
---
simple_stmt [52645,52676]
simple_stmt [54361,54392]
===
match
---
atom [24832,24918]
atom [26548,26634]
===
match
---
name: test_dagtag_repr [24080,24096]
name: test_dagtag_repr [25796,25812]
===
match
---
operator: = [56655,56656]
operator: = [58371,58372]
===
match
---
trailer [23294,23302]
trailer [23294,23302]
===
match
---
trailer [21981,21988]
trailer [21981,21988]
===
match
---
string: 'owner' [12884,12891]
string: 'owner' [12884,12891]
===
match
---
simple_stmt [13478,13511]
simple_stmt [13478,13511]
===
match
---
operator: , [61008,61009]
operator: , [62724,62725]
===
match
---
name: DummyOperator [35490,35503]
name: DummyOperator [37206,37219]
===
match
---
name: task_instance_2 [50745,50760]
name: task_instance_2 [52461,52476]
===
match
---
name: dag_id [49646,49652]
name: dag_id [51362,51368]
===
match
---
atom_expr [52836,52862]
atom_expr [54552,54578]
===
match
---
assert_stmt [60062,60111]
assert_stmt [61778,61827]
===
match
---
trailer [5920,5986]
trailer [5920,5986]
===
match
---
simple_stmt [34459,34533]
simple_stmt [36175,36249]
===
match
---
name: return_num [68033,68043]
name: return_num [69749,69759]
===
match
---
atom_expr [11809,11846]
atom_expr [11809,11846]
===
match
---
expr_stmt [64867,65117]
expr_stmt [66583,66833]
===
match
---
funcdef [68029,68077]
funcdef [69745,69793]
===
match
---
atom [36011,36021]
atom [37727,37737]
===
match
---
operator: = [55628,55629]
operator: = [57344,57345]
===
match
---
atom_expr [31676,31694]
atom_expr [33392,33410]
===
match
---
simple_stmt [3199,3266]
simple_stmt [3199,3266]
===
match
---
operator: = [19795,19796]
operator: = [19795,19796]
===
match
---
trailer [51795,51835]
trailer [53511,53551]
===
match
---
name: AirflowException [16577,16593]
name: AirflowException [16577,16593]
===
match
---
funcdef [55089,55998]
funcdef [56805,57714]
===
match
---
operator: , [4336,4337]
operator: , [4336,4337]
===
match
---
operator: > [57908,57909]
operator: > [59624,59625]
===
match
---
comparison [22074,22122]
comparison [22074,22122]
===
match
---
operator: = [52785,52786]
operator: = [54501,54502]
===
match
---
suite [25477,25517]
suite [27193,27233]
===
match
---
testlist_comp [46400,46421]
testlist_comp [48116,48137]
===
match
---
number: 3 [22607,22608]
number: 3 [22607,22608]
===
match
---
expr_stmt [22707,22775]
expr_stmt [22707,22775]
===
match
---
import_name [1092,1105]
import_name [1092,1105]
===
match
---
number: 1 [2386,2387]
number: 1 [2386,2387]
===
match
---
number: 1 [61007,61008]
number: 1 [62723,62724]
===
match
---
name: start_date [12100,12110]
name: start_date [12100,12110]
===
match
---
argument [65947,65954]
argument [67663,67670]
===
match
---
suite [56048,58399]
suite [57764,60115]
===
match
---
trailer [46104,46123]
trailer [47820,47839]
===
match
---
operator: , [40545,40546]
operator: , [42261,42262]
===
match
---
name: schedule_interval [61166,61183]
name: schedule_interval [62882,62899]
===
match
---
argument [46296,46321]
argument [48012,48037]
===
match
---
simple_stmt [34541,34570]
simple_stmt [36257,36286]
===
match
---
atom_expr [13997,14029]
atom_expr [13997,14029]
===
match
---
operator: , [30232,30233]
operator: , [31948,31949]
===
match
---
operator: , [1256,1257]
operator: , [1256,1257]
===
match
---
name: prev_task [13350,13359]
name: prev_task [13350,13359]
===
match
---
simple_stmt [42848,42881]
simple_stmt [44564,44597]
===
match
---
param [33818,33822]
param [35534,35538]
===
match
---
name: stdout_lines [36659,36671]
name: stdout_lines [38375,38387]
===
match
---
trailer [21176,21186]
trailer [21176,21186]
===
match
---
name: dag_ [44701,44705]
name: dag_ [46417,46421]
===
match
---
expr_stmt [20955,20990]
expr_stmt [20955,20990]
===
match
---
operator: , [64729,64730]
operator: , [66445,66446]
===
match
---
name: DagRun [49139,49145]
name: DagRun [50855,50861]
===
match
---
name: params2 [4238,4245]
name: params2 [4238,4245]
===
match
---
atom_expr [67624,67639]
atom_expr [69340,69355]
===
match
---
name: start_date [27480,27490]
name: start_date [29196,29206]
===
match
---
arglist [12838,12902]
arglist [12838,12902]
===
match
---
argument [14272,14294]
argument [14272,14294]
===
match
---
name: test_dag_handle_callback_crash [39839,39869]
name: test_dag_handle_callback_crash [41555,41585]
===
match
---
name: op9 [7235,7238]
name: op9 [7235,7238]
===
match
---
operator: = [32711,32712]
operator: = [34427,34428]
===
match
---
name: task [14843,14847]
name: task [14843,14847]
===
match
---
trailer [50505,50515]
trailer [52221,52231]
===
match
---
string: 'dag-bulk-sync-3' [26682,26699]
string: 'dag-bulk-sync-3' [28398,28415]
===
match
---
trailer [69851,69857]
trailer [71567,71573]
===
match
---
name: MagicMock [40066,40075]
name: MagicMock [41782,41791]
===
match
---
trailer [2379,2397]
trailer [2379,2397]
===
match
---
atom [29215,29235]
atom [30931,30951]
===
match
---
operator: == [27920,27922]
operator: == [29636,29638]
===
match
---
operator: , [8546,8547]
operator: , [8546,8547]
===
match
---
name: dag [21695,21698]
name: dag [21695,21698]
===
match
---
suite [16023,16085]
suite [16023,16085]
===
match
---
atom_expr [22840,22862]
atom_expr [22840,22862]
===
match
---
name: split [29580,29585]
name: split [31296,31301]
===
match
---
testlist_comp [18354,18387]
testlist_comp [18354,18387]
===
match
---
trailer [49180,49236]
trailer [50896,50952]
===
match
---
name: task [17048,17052]
name: task [17048,17052]
===
match
---
operator: @ [68001,68002]
operator: @ [69717,69718]
===
match
---
param [66485,66489]
param [68201,68205]
===
match
---
operator: } [43953,43954]
operator: } [45669,45670]
===
match
---
expr_stmt [22176,22211]
expr_stmt [22176,22211]
===
match
---
operator: = [63270,63271]
operator: = [64986,64987]
===
match
---
name: dag_id [46168,46174]
name: dag_id [47884,47890]
===
match
---
simple_stmt [46965,47015]
simple_stmt [48681,48731]
===
match
---
expr_stmt [70160,70174]
expr_stmt [71876,71890]
===
match
---
name: topological_list [10297,10313]
name: topological_list [10297,10313]
===
match
---
trailer [53966,53976]
trailer [55682,55692]
===
match
---
name: subdag [1788,1794]
name: subdag [1788,1794]
===
match
---
operator: == [43735,43737]
operator: == [45451,45453]
===
match
---
trailer [8273,8287]
trailer [8273,8287]
===
match
---
name: self [56042,56046]
name: self [57758,57762]
===
match
---
expr_stmt [48162,48200]
expr_stmt [49878,49916]
===
match
---
name: is_active [29643,29652]
name: is_active [31359,31368]
===
match
---
name: loads [45303,45308]
name: loads [47019,47024]
===
match
---
name: next_subdag_date [62789,62805]
name: next_subdag_date [64505,64521]
===
match
---
operator: , [10621,10622]
operator: , [10621,10622]
===
match
---
name: dag_id [34272,34278]
name: dag_id [35988,35994]
===
match
---
name: dag_id [44086,44092]
name: dag_id [45802,45808]
===
match
---
operator: = [35042,35043]
operator: = [36758,36759]
===
match
---
parameters [35631,35637]
parameters [37347,37353]
===
match
---
name: datetime [59016,59024]
name: datetime [60732,60740]
===
match
---
name: default_args [6039,6051]
name: default_args [6039,6051]
===
match
---
simple_stmt [26458,26486]
simple_stmt [28174,28202]
===
match
---
atom_expr [35582,35596]
atom_expr [37298,37312]
===
match
---
simple_stmt [6526,6561]
simple_stmt [6526,6561]
===
match
---
atom_expr [40819,40841]
atom_expr [42535,42557]
===
match
---
trailer [10059,10076]
trailer [10059,10076]
===
match
---
param [66924,66928]
param [68640,68644]
===
match
---
name: start_date [53869,53879]
name: start_date [55585,55595]
===
match
---
arglist [51584,51634]
arglist [53300,53350]
===
match
---
name: session [27106,27113]
name: session [28822,28829]
===
match
---
argument [52775,52798]
argument [54491,54514]
===
match
---
name: task_id [51551,51558]
name: task_id [53267,53274]
===
match
---
number: 4 [10528,10529]
number: 4 [10528,10529]
===
match
---
param [68543,68546]
param [70259,70262]
===
match
---
simple_stmt [34794,34840]
simple_stmt [36510,36556]
===
match
---
name: remove [9331,9337]
name: remove [9331,9337]
===
match
---
trailer [19084,19089]
trailer [19084,19089]
===
match
---
atom_expr [28240,28250]
atom_expr [29956,29966]
===
match
---
assert_stmt [18265,18415]
assert_stmt [18265,18415]
===
match
---
name: _next [20763,20768]
name: _next [20763,20768]
===
match
---
simple_stmt [61681,61730]
simple_stmt [63397,63446]
===
match
---
operator: = [17024,17025]
operator: = [17024,17025]
===
match
---
operator: -> [2454,2456]
operator: -> [2454,2456]
===
match
---
suite [55755,55839]
suite [57471,57555]
===
match
---
name: op1 [9936,9939]
name: op1 [9936,9939]
===
match
---
name: dag [26458,26461]
name: dag [28174,28177]
===
match
---
fstring_string: dag-bulk-sync- [24527,24541]
fstring_string: dag-bulk-sync- [26243,26257]
===
match
---
string: 'owner1' [15431,15439]
string: 'owner1' [15431,15439]
===
match
---
string: 'dummy' [64786,64793]
string: 'dummy' [66502,66509]
===
match
---
atom_expr [44561,44604]
atom_expr [46277,46320]
===
match
---
name: subdag [31012,31018]
name: subdag [32728,32734]
===
match
---
trailer [24145,24214]
trailer [25861,25930]
===
match
---
number: 10 [61386,61388]
number: 10 [63102,63104]
===
match
---
operator: = [69348,69349]
operator: = [71064,71065]
===
match
---
name: pendulum [21417,21425]
name: pendulum [21417,21425]
===
match
---
string: """         Test that when 'params' is _not_ passed to a new Dag, that the params         attribute is set to an empty dictionary.         """ [3563,3705]
string: """         Test that when 'params' is _not_ passed to a new Dag, that the params         attribute is set to an empty dictionary.         """ [3563,3705]
===
match
---
name: test_following_schedule_relativedelta [23451,23488]
name: test_following_schedule_relativedelta [23451,23488]
===
match
---
atom_expr [48680,48737]
atom_expr [50396,50453]
===
match
---
operator: = [14064,14065]
operator: = [14064,14065]
===
match
---
name: jinja_udf [18494,18503]
name: jinja_udf [18494,18503]
===
match
---
name: DAG [51707,51710]
name: DAG [53423,53426]
===
match
---
operator: = [47477,47478]
operator: = [49193,49194]
===
match
---
operator: = [35969,35970]
operator: = [37685,37686]
===
match
---
name: weight [13932,13938]
name: weight [13932,13938]
===
match
---
arglist [39227,39328]
arglist [40943,41044]
===
match
---
name: subdag [52217,52223]
name: subdag [53933,53939]
===
match
---
string: 'test_dagrun_query_count' [65791,65816]
string: 'test_dagrun_query_count' [67507,67532]
===
match
---
argument [42405,42422]
argument [44121,44138]
===
match
---
name: self [20204,20208]
name: self [20204,20208]
===
match
---
expr_stmt [21406,21451]
expr_stmt [21406,21451]
===
match
---
atom_expr [34552,34569]
atom_expr [36268,36285]
===
match
---
name: merge [54116,54121]
name: merge [55832,55837]
===
match
---
dictorsetmaker [31614,31662]
dictorsetmaker [33330,33378]
===
match
---
comparison [39525,39560]
comparison [41241,41276]
===
match
---
number: 1 [14902,14903]
number: 1 [14902,14903]
===
match
---
name: pattern [13434,13441]
name: pattern [13434,13441]
===
match
---
argument [50961,50981]
argument [52677,52697]
===
match
---
trailer [51524,51534]
trailer [53240,53250]
===
match
---
string: 't1' [49672,49676]
string: 't1' [51388,51392]
===
match
---
name: start_date [60730,60740]
name: start_date [62446,62456]
===
match
---
testlist_comp [46475,46498]
testlist_comp [48191,48214]
===
match
---
name: TI [17045,17047]
name: TI [17045,17047]
===
match
---
name: datetime [34887,34895]
name: datetime [36603,36611]
===
match
---
operator: = [52011,52012]
operator: = [53727,53728]
===
match
---
string: 'tz_dag' [21620,21628]
string: 'tz_dag' [21620,21628]
===
match
---
operator: = [19724,19725]
operator: = [19724,19725]
===
match
---
operator: = [3282,3283]
operator: = [3282,3283]
===
match
---
expr_stmt [49084,49265]
expr_stmt [50800,50981]
===
match
---
name: DAG [7334,7337]
name: DAG [7334,7337]
===
match
---
number: 5 [58444,58445]
number: 5 [60160,60161]
===
match
---
trailer [56397,56604]
trailer [58113,58320]
===
match
---
argument [30110,30124]
argument [31826,31840]
===
match
---
argument [38597,38618]
argument [40313,40334]
===
match
---
trailer [30784,30837]
trailer [32500,32553]
===
match
---
simple_stmt [15349,15359]
simple_stmt [15349,15359]
===
match
---
simple_stmt [70009,70038]
simple_stmt [71725,71754]
===
match
---
operator: = [48702,48703]
operator: = [50418,50419]
===
match
---
name: dag [63888,63891]
name: dag [65604,65607]
===
match
---
atom_expr [6310,6319]
atom_expr [6310,6319]
===
match
---
name: airflow [1863,1870]
name: airflow [1863,1870]
===
match
---
operator: == [54959,54961]
operator: == [56675,56677]
===
match
---
name: isinstance [3759,3769]
name: isinstance [3759,3769]
===
match
---
suite [61946,62035]
suite [63662,63751]
===
match
---
simple_stmt [58026,58216]
simple_stmt [59742,59932]
===
match
---
name: datetime [22583,22591]
name: datetime [22583,22591]
===
match
---
name: timezone [60082,60090]
name: timezone [61798,61806]
===
match
---
operator: = [16496,16497]
operator: = [16496,16497]
===
match
---
trailer [64396,64402]
trailer [66112,66118]
===
match
---
name: dag_eq [44710,44716]
name: dag_eq [46426,46432]
===
match
---
trailer [69619,69625]
trailer [71335,71341]
===
match
---
name: datetime [2082,2090]
name: datetime [2082,2090]
===
match
---
param [46739,46744]
param [48455,48460]
===
match
---
atom_expr [66796,66816]
atom_expr [68512,68532]
===
match
---
arglist [64899,65107]
arglist [66615,66823]
===
match
---
if_stmt [3417,3464]
if_stmt [3417,3464]
===
match
---
trailer [17112,17120]
trailer [17112,17120]
===
match
---
operator: = [39140,39141]
operator: = [40856,40857]
===
match
---
atom_expr [39748,39759]
atom_expr [41464,41475]
===
match
---
simple_stmt [16048,16085]
simple_stmt [16048,16085]
===
match
---
name: State [50669,50674]
name: State [52385,52390]
===
match
---
simple_stmt [49577,49623]
simple_stmt [51293,51339]
===
match
---
trailer [10422,10429]
trailer [10422,10429]
===
match
---
simple_stmt [41816,41857]
simple_stmt [43532,43573]
===
match
---
name: num [67174,67177]
name: num [68890,68893]
===
match
---
assert_stmt [55950,55997]
assert_stmt [57666,57713]
===
match
---
expr_stmt [57560,57753]
expr_stmt [59276,59469]
===
match
---
trailer [37692,37702]
trailer [39408,39418]
===
match
---
atom_expr [9252,9271]
atom_expr [9252,9271]
===
match
---
name: args [43899,43903]
name: args [45615,45619]
===
match
---
atom [32452,32469]
atom [34168,34185]
===
match
---
operator: , [36036,36037]
operator: , [37752,37753]
===
match
---
argument [62376,62446]
argument [64092,64162]
===
match
---
number: 4 [60324,60325]
number: 4 [62040,62041]
===
match
---
trailer [42828,42835]
trailer [44544,44551]
===
match
---
name: next_date [57337,57346]
name: next_date [59053,59062]
===
match
---
operator: = [64838,64839]
operator: = [66554,66555]
===
match
---
name: subdag [62638,62644]
name: subdag [64354,64360]
===
match
---
trailer [64992,65003]
trailer [66708,66719]
===
match
---
name: subdag [62606,62612]
name: subdag [64322,64328]
===
match
---
name: period_end [27775,27785]
name: period_end [29491,29501]
===
match
---
name: execution_date [69380,69394]
name: execution_date [71096,71110]
===
match
---
name: convert [23295,23302]
name: convert [23295,23302]
===
match
---
simple_stmt [12507,12517]
simple_stmt [12507,12517]
===
match
---
name: test_dag_id [18033,18044]
name: test_dag_id [18033,18044]
===
match
---
name: self [11934,11938]
name: self [11934,11938]
===
match
---
comparison [25743,25909]
comparison [27459,27625]
===
match
---
operator: * [15030,15031]
operator: * [15030,15031]
===
match
---
name: session [64457,64464]
name: session [66173,66180]
===
match
---
name: datetime [46652,46660]
name: datetime [48368,48376]
===
match
---
parameters [67334,67340]
parameters [69050,69056]
===
match
---
name: dag [10704,10707]
name: dag [10704,10707]
===
match
---
name: dag [33041,33044]
name: dag [34757,34760]
===
match
---
name: delete [3102,3108]
name: delete [3102,3108]
===
match
---
operator: @ [47990,47991]
operator: @ [49706,49707]
===
match
---
operator: = [51684,51685]
operator: = [53400,53401]
===
match
---
argument [6039,6071]
argument [6039,6071]
===
match
---
simple_stmt [42499,42516]
simple_stmt [44215,44232]
===
match
---
argument [37969,37981]
argument [39685,39697]
===
match
---
atom_expr [69231,69248]
atom_expr [70947,70964]
===
match
---
trailer [6658,6662]
trailer [6658,6662]
===
match
---
atom [32207,32393]
atom [33923,34109]
===
match
---
name: task_id [38139,38146]
name: task_id [39855,39862]
===
match
---
trailer [64710,64755]
trailer [66426,66471]
===
match
---
name: DummyOperator [37955,37968]
name: DummyOperator [39671,39684]
===
match
---
with_item [26576,26603]
with_item [28292,28319]
===
match
---
string: """         Test that the dag file processor does not create multiple dagruns         if a dag is scheduled with 'timedelta' and catchup=False         """ [58536,58690]
string: """         Test that the dag file processor does not create multiple dagruns         if a dag is scheduled with 'timedelta' and catchup=False         """ [60252,60406]
===
match
---
argument [7513,7530]
argument [7513,7530]
===
match
---
name: test_resolve_template_files_list [19493,19525]
name: test_resolve_template_files_list [19493,19525]
===
match
---
atom [12376,12396]
atom [12376,12396]
===
match
---
atom_expr [29184,29210]
atom_expr [30900,30926]
===
match
---
atom_expr [7107,7135]
atom_expr [7107,7135]
===
match
---
assert_stmt [5005,5081]
assert_stmt [5005,5081]
===
match
---
string: "run_id_is_generated" [47095,47116]
string: "run_id_is_generated" [48811,48832]
===
match
---
operator: = [9778,9779]
operator: = [9778,9779]
===
match
---
atom_expr [69263,69456]
atom_expr [70979,71172]
===
match
---
name: op4 [8973,8976]
name: op4 [8973,8976]
===
match
---
operator: , [53892,53893]
operator: , [55608,55609]
===
match
---
simple_stmt [33676,33763]
simple_stmt [35392,35479]
===
match
---
with_item [24704,24731]
with_item [26420,26447]
===
match
---
operator: , [35734,35735]
operator: , [37450,37451]
===
match
---
decorated [68911,69216]
decorated [70627,70932]
===
match
---
operator: = [39164,39165]
operator: = [40880,40881]
===
match
---
name: dag [21916,21919]
name: dag [21916,21919]
===
match
---
atom [4248,4265]
atom [4248,4265]
===
match
---
name: DAG [44312,44315]
name: DAG [46028,46031]
===
match
---
name: depth [15349,15354]
name: depth [15349,15354]
===
match
---
trailer [64456,64465]
trailer [66172,66181]
===
match
---
expr_stmt [43899,43954]
expr_stmt [45615,45670]
===
match
---
atom_expr [24022,24039]
atom_expr [24022,24039]
===
match
---
name: dag [25551,25554]
name: dag [27267,27270]
===
match
---
arglist [44650,44686]
arglist [46366,46402]
===
match
---
trailer [70540,70542]
trailer [72256,72258]
===
match
---
name: dag [6968,6971]
name: dag [6968,6971]
===
match
---
operator: = [50099,50100]
operator: = [51815,51816]
===
match
---
expr_stmt [17379,17404]
expr_stmt [17379,17404]
===
match
---
trailer [48682,48737]
trailer [50398,50453]
===
match
---
import_from [2106,2148]
import_from [2106,2148]
===
match
---
simple_stmt [1230,1267]
simple_stmt [1230,1267]
===
match
---
trailer [27032,27081]
trailer [28748,28797]
===
match
---
import_name [1076,1091]
import_name [1076,1091]
===
match
---
simple_stmt [20108,20162]
simple_stmt [20108,20162]
===
match
---
string: 'dag' [30413,30418]
string: 'dag' [32129,32134]
===
match
---
simple_stmt [27170,27196]
simple_stmt [28886,28912]
===
match
---
import_from [1155,1188]
import_from [1155,1188]
===
match
---
string: 'webserver' [33722,33733]
string: 'webserver' [35438,35449]
===
match
---
atom_expr [10297,10316]
atom_expr [10297,10316]
===
match
---
name: RUNNING [53324,53331]
name: RUNNING [55040,55047]
===
match
---
name: task_instance_1 [50706,50721]
name: task_instance_1 [52422,52437]
===
match
---
name: days [17362,17366]
name: days [17362,17366]
===
match
---
simple_stmt [4725,4796]
simple_stmt [4725,4796]
===
match
---
simple_stmt [43356,43587]
simple_stmt [45072,45303]
===
match
---
trailer [22690,22697]
trailer [22690,22697]
===
match
---
trailer [10268,10275]
trailer [10268,10275]
===
match
---
trailer [42311,42340]
trailer [44027,44056]
===
match
---
argument [8548,8571]
argument [8548,8571]
===
match
---
trailer [27652,27658]
trailer [29368,29374]
===
match
---
argument [52855,52861]
argument [54571,54577]
===
match
---
dictorsetmaker [9508,9525]
dictorsetmaker [9508,9525]
===
match
---
simple_stmt [22504,22550]
simple_stmt [22504,22550]
===
match
---
name: default_args [11769,11781]
name: default_args [11769,11781]
===
match
---
trailer [53156,53160]
trailer [54872,54876]
===
match
---
operator: == [29441,29443]
operator: == [31157,31159]
===
match
---
trailer [40833,40841]
trailer [42549,42557]
===
match
---
trailer [52101,52108]
trailer [53817,53824]
===
match
---
operator: = [49743,49744]
operator: = [51459,51460]
===
match
---
trailer [45773,45788]
trailer [47489,47504]
===
match
---
string: 'A' [9667,9670]
string: 'A' [9667,9670]
===
match
---
trailer [46895,46924]
trailer [48611,48640]
===
match
---
atom_expr [17450,17468]
atom_expr [17450,17468]
===
match
---
atom_expr [45296,45314]
atom_expr [47012,47030]
===
match
---
name: pytest [4622,4628]
name: pytest [4622,4628]
===
match
---
parameters [44126,44132]
parameters [45842,45848]
===
match
---
name: DAG [23703,23706]
name: DAG [23703,23706]
===
match
---
simple_stmt [44411,44468]
simple_stmt [46127,46184]
===
match
---
atom_expr [48476,48499]
atom_expr [50192,50215]
===
match
---
atom_expr [69432,69445]
atom_expr [71148,71161]
===
match
---
name: state [17018,17023]
name: state [17018,17023]
===
match
---
name: self [5120,5124]
name: self [5120,5124]
===
match
---
expr_stmt [61028,61208]
expr_stmt [62744,62924]
===
match
---
trailer [50590,50598]
trailer [52306,52314]
===
match
---
operator: } [29615,29616]
operator: } [31331,31332]
===
match
---
trailer [19638,19644]
trailer [19638,19644]
===
match
---
expr_stmt [32933,32995]
expr_stmt [34649,34711]
===
match
---
operator: = [16965,16966]
operator: = [16965,16966]
===
match
---
atom_expr [5221,5309]
atom_expr [5221,5309]
===
match
---
trailer [42360,42369]
trailer [44076,44085]
===
match
---
trailer [29191,29198]
trailer [30907,30914]
===
match
---
trailer [57376,57382]
trailer [59092,59098]
===
match
---
name: tearDown [2638,2646]
name: tearDown [2638,2646]
===
match
---
operator: = [53920,53921]
operator: = [55636,55637]
===
match
---
operator: , [41212,41213]
operator: , [42928,42929]
===
match
---
trailer [68236,68238]
trailer [69952,69954]
===
match
---
param [51438,51451]
param [53154,53167]
===
match
---
string: """         Test DAG as a context manager.         When used as a context manager, Operators are automatically added to         the DAG (unless they specify a different DAG)         """ [5717,5902]
string: """         Test DAG as a context manager.         When used as a context manager, Operators are automatically added to         the DAG (unless they specify a different DAG)         """ [5717,5902]
===
match
---
trailer [25170,25198]
trailer [26886,26914]
===
match
---
name: dag [42717,42720]
name: dag [44433,44436]
===
match
---
name: state [66091,66096]
name: state [67807,67812]
===
match
---
atom_expr [51650,51689]
atom_expr [53366,53405]
===
match
---
operator: = [52932,52933]
operator: = [54648,54649]
===
match
---
trailer [42947,42957]
trailer [44663,44673]
===
match
---
operator: , [14510,14511]
operator: , [14510,14511]
===
match
---
name: all [32378,32381]
name: all [34094,34097]
===
match
---
argument [54843,54868]
argument [56559,56584]
===
match
---
name: DAG [43150,43153]
name: DAG [44866,44869]
===
match
---
import_as_name [2082,2105]
import_as_name [2082,2105]
===
match
---
name: DummyOperator [63973,63986]
name: DummyOperator [65689,65702]
===
match
---
name: self [70793,70797]
name: self [72509,72513]
===
match
---
trailer [33721,33754]
trailer [35437,35470]
===
match
---
assert_stmt [68143,68170]
assert_stmt [69859,69886]
===
match
---
trailer [59973,59982]
trailer [61689,61698]
===
match
---
name: get [27747,27750]
name: get [29463,29466]
===
match
---
operator: = [48434,48435]
operator: = [50150,50151]
===
match
---
simple_stmt [7999,8017]
simple_stmt [7999,8017]
===
match
---
operator: , [62775,62776]
operator: , [64491,64492]
===
match
---
atom_expr [52217,52404]
atom_expr [53933,54120]
===
match
---
comparison [17775,17864]
comparison [17775,17864]
===
match
---
with_stmt [30957,31027]
with_stmt [32673,32743]
===
match
---
name: dag [45276,45279]
name: dag [46992,46995]
===
match
---
name: a_index [3393,3400]
name: a_index [3393,3400]
===
match
---
name: State [53345,53350]
name: State [55061,55066]
===
match
---
string: 't1' [38682,38686]
string: 't1' [40398,40402]
===
match
---
operator: , [46580,46581]
operator: , [48296,48297]
===
match
---
param [39870,39875]
param [41586,41591]
===
match
---
argument [39135,39152]
argument [40851,40868]
===
match
---
trailer [12837,12903]
trailer [12837,12903]
===
match
---
name: filter [33568,33574]
name: filter [35284,35290]
===
match
---
name: DagRunType [47655,47665]
name: DagRunType [49371,49381]
===
match
---
name: State [18360,18365]
name: State [18360,18365]
===
match
---
atom_expr [52538,52551]
atom_expr [54254,54267]
===
match
---
operator: , [39327,39328]
operator: , [41043,41044]
===
match
---
operator: , [66353,66354]
operator: , [68069,68070]
===
match
---
operator: = [55531,55532]
operator: = [57247,57248]
===
match
---
expr_stmt [43316,43346]
expr_stmt [45032,45062]
===
match
---
operator: = [47370,47371]
operator: = [49086,49087]
===
match
---
number: 12 [65697,65699]
number: 12 [67413,67415]
===
match
---
trailer [67450,67463]
trailer [69166,69179]
===
match
---
name: dag_id [49695,49701]
name: dag_id [51411,51417]
===
match
---
arglist [20378,20450]
arglist [20378,20450]
===
match
---
name: filter [54426,54432]
name: filter [56142,56148]
===
match
---
string: """Verify tasks with Duplicate task_id raises error""" [37320,37374]
string: """Verify tasks with Duplicate task_id raises error""" [39036,39090]
===
match
---
string: """Test that checks you can set dag_id from decorator.""" [66939,66996]
string: """Test that checks you can set dag_id from decorator.""" [68655,68712]
===
match
---
expr_stmt [14988,15038]
expr_stmt [14988,15038]
===
match
---
operator: = [20308,20309]
operator: = [20308,20309]
===
match
---
name: noop_pipeline [66765,66778]
name: noop_pipeline [68481,68494]
===
match
---
name: subdag [30142,30148]
name: subdag [31858,31864]
===
match
---
operator: , [56546,56547]
operator: , [58262,58263]
===
match
---
name: match [36907,36912]
name: match [38623,38628]
===
match
---
param [43846,43850]
param [45562,45566]
===
match
---
name: next_subdag_date [62859,62875]
name: next_subdag_date [64575,64591]
===
match
---
simple_stmt [1893,1943]
simple_stmt [1893,1943]
===
match
---
arglist [37402,37478]
arglist [39118,39194]
===
match
---
operator: } [10835,10836]
operator: } [10835,10836]
===
match
---
operator: = [16858,16859]
operator: = [16858,16859]
===
match
---
assert_stmt [45007,45034]
assert_stmt [46723,46750]
===
match
---
name: task_instance_1 [48662,48677]
name: task_instance_1 [50378,50393]
===
match
---
trailer [34032,34040]
trailer [35748,35756]
===
match
---
simple_stmt [50692,50723]
simple_stmt [52408,52439]
===
match
---
name: op2 [37176,37179]
name: op2 [38892,38895]
===
match
---
simple_stmt [9367,9401]
simple_stmt [9367,9401]
===
match
---
operator: = [7404,7405]
operator: = [7404,7405]
===
match
---
arglist [27047,27073]
arglist [28763,28789]
===
match
---
param [42999,43003]
param [44715,44719]
===
match
---
trailer [49365,49371]
trailer [51081,51087]
===
match
---
string: "@yearly" [46557,46566]
string: "@yearly" [48273,48282]
===
match
---
sync_comp_for [13059,13083]
sync_comp_for [13059,13083]
===
match
---
name: DAG [10612,10615]
name: DAG [10612,10615]
===
match
---
simple_stmt [14719,14756]
simple_stmt [14719,14756]
===
match
---
atom_expr [54364,54503]
atom_expr [56080,56219]
===
match
---
param [38300,38304]
param [40016,40020]
===
match
---
name: get_dagmodel [32129,32141]
name: get_dagmodel [33845,33857]
===
match
---
number: 1 [48919,48920]
number: 1 [50635,50636]
===
match
---
operator: , [26064,26065]
operator: , [27780,27781]
===
match
---
operator: , [52315,52316]
operator: , [54031,54032]
===
match
---
atom_expr [69117,69134]
atom_expr [70833,70850]
===
match
---
funcdef [29796,30545]
funcdef [31512,32261]
===
match
---
assert_stmt [43717,43791]
assert_stmt [45433,45507]
===
match
---
arglist [58722,58914]
arglist [60438,60630]
===
match
---
name: task [19861,19865]
name: task [19861,19865]
===
match
---
name: DAG [4288,4291]
name: DAG [4288,4291]
===
match
---
name: all [27075,27078]
name: all [28791,28794]
===
match
---
name: test_user_defined_filters [18449,18474]
name: test_user_defined_filters [18449,18474]
===
match
---
trailer [31751,31792]
trailer [33467,33508]
===
match
---
name: schedule_interval [46857,46874]
name: schedule_interval [48573,48590]
===
match
---
expr_stmt [51698,51772]
expr_stmt [53414,53488]
===
match
---
simple_stmt [16256,16303]
simple_stmt [16256,16303]
===
match
---
simple_stmt [28262,28301]
simple_stmt [29978,30017]
===
match
---
name: test_dag_naive_default_args_start_date_with_timezone [34726,34778]
name: test_dag_naive_default_args_start_date_with_timezone [36442,36494]
===
match
---
name: DAG [43969,43972]
name: DAG [45685,45688]
===
match
---
operator: = [50976,50977]
operator: = [52692,52693]
===
match
---
expr_stmt [62638,62661]
expr_stmt [64354,64377]
===
match
---
operator: = [16932,16933]
operator: = [16932,16933]
===
match
---
simple_stmt [66578,66597]
simple_stmt [68294,68313]
===
match
---
suite [14804,15162]
suite [14804,15162]
===
match
---
expr_stmt [36515,36541]
expr_stmt [38231,38257]
===
match
---
name: session [64039,64046]
name: session [65755,65762]
===
match
---
trailer [69527,69540]
trailer [71243,71256]
===
match
---
name: next_date [59887,59896]
name: next_date [61603,61612]
===
match
---
operator: , [7373,7374]
operator: , [7373,7374]
===
match
---
operator: = [21568,21569]
operator: = [21568,21569]
===
match
---
suite [63691,63746]
suite [65407,65462]
===
match
---
assert_stmt [29661,29713]
assert_stmt [31377,31429]
===
match
---
name: create_dagrun [47559,47572]
name: create_dagrun [49275,49288]
===
match
---
atom_expr [30441,30461]
atom_expr [32157,32177]
===
match
---
name: self [70430,70434]
name: self [72146,72150]
===
match
---
atom_expr [43217,43306]
atom_expr [44933,45022]
===
match
---
name: dag [12346,12349]
name: dag [12346,12349]
===
match
---
name: self [58521,58525]
name: self [60237,60241]
===
match
---
name: DEFAULT_DATE [48845,48857]
name: DEFAULT_DATE [50561,50573]
===
match
---
arglist [2556,2589]
arglist [2556,2589]
===
match
---
operator: = [35465,35466]
operator: = [37181,37182]
===
match
---
name: test_clear_dag [53407,53421]
name: test_clear_dag [55123,55137]
===
match
---
name: schedule_interval [46997,47014]
name: schedule_interval [48713,48730]
===
match
---
name: task_instance [54563,54576]
name: task_instance [56279,56292]
===
match
---
operator: = [50540,50541]
operator: = [52256,52257]
===
match
---
atom_expr [9006,9028]
atom_expr [9006,9028]
===
match
---
name: hours [57108,57113]
name: hours [58824,58829]
===
match
---
argument [38447,38459]
argument [40163,40175]
===
match
---
arglist [19129,19198]
arglist [19129,19198]
===
match
---
decorated [59257,60327]
decorated [60973,62043]
===
match
---
name: task_id [55601,55608]
name: task_id [57317,57324]
===
match
---
name: following_schedule [65046,65064]
name: following_schedule [66762,66780]
===
match
---
expr_stmt [55371,55413]
expr_stmt [57087,57129]
===
match
---
assert_stmt [24294,24442]
assert_stmt [26010,26158]
===
match
---
expr_stmt [23854,23895]
expr_stmt [23854,23895]
===
match
---
trailer [31507,31514]
trailer [33223,33230]
===
match
---
name: dag_id [2980,2986]
name: dag_id [2980,2986]
===
match
---
name: run [43596,43599]
name: run [45312,45315]
===
match
---
name: dirname [19682,19689]
name: dirname [19682,19689]
===
match
---
operator: = [19028,19029]
operator: = [19028,19029]
===
match
---
name: BashOperator [37102,37114]
name: BashOperator [38818,38830]
===
match
---
operator: = [55282,55283]
operator: = [56998,56999]
===
match
---
string: 'tag-2' [24311,24318]
string: 'tag-2' [26027,26034]
===
match
---
simple_stmt [55912,55941]
simple_stmt [57628,57657]
===
match
---
name: op2 [8933,8936]
name: op2 [8933,8936]
===
match
---
argument [56707,56714]
argument [58423,58430]
===
match
---
trailer [29788,29790]
trailer [31504,31506]
===
match
---
name: dag [47816,47819]
name: dag [49532,49535]
===
match
---
name: dr [28143,28145]
name: dr [29859,29861]
===
match
---
name: default_args [11966,11978]
name: default_args [11966,11978]
===
match
---
simple_stmt [53516,53539]
simple_stmt [55232,55255]
===
match
---
arglist [13032,13040]
arglist [13032,13040]
===
match
---
suite [5708,7251]
suite [5708,7251]
===
match
---
string: "SubDags should never have DagRuns created by the scheduler" [62885,62945]
string: "SubDags should never have DagRuns created by the scheduler" [64601,64661]
===
match
---
atom_expr [51520,51542]
atom_expr [53236,53258]
===
match
---
operator: = [48321,48322]
operator: = [50037,50038]
===
match
---
trailer [29125,29132]
trailer [30841,30848]
===
match
---
name: fileloc [66879,66886]
name: fileloc [68595,68602]
===
match
---
operator: = [31814,31815]
operator: = [33530,33531]
===
match
---
name: dag_pickle [44013,44023]
name: dag_pickle [45729,45739]
===
match
---
assert_stmt [26803,27081]
assert_stmt [28519,28797]
===
match
---
string: "Pre-condition: start date is in DST" [20517,20554]
string: "Pre-condition: start date is in DST" [20517,20554]
===
match
---
expr_stmt [20564,20600]
expr_stmt [20564,20600]
===
match
---
name: session [2952,2959]
name: session [2952,2959]
===
match
---
name: query [42804,42809]
name: query [44520,44525]
===
match
---
string: 'params' [4318,4326]
string: 'params' [4318,4326]
===
match
---
arglist [32674,32716]
arglist [34390,34432]
===
match
---
simple_stmt [64039,64068]
simple_stmt [65755,65784]
===
match
---
param [5702,5706]
param [5702,5706]
===
match
---
factor [3305,3307]
factor [3305,3307]
===
match
---
trailer [42502,42513]
trailer [44218,44229]
===
match
---
atom_expr [41170,41238]
atom_expr [42886,42954]
===
match
---
number: 4 [17775,17776]
number: 4 [17775,17776]
===
match
---
name: test_existing_dag_default_view [33328,33358]
name: test_existing_dag_default_view [35044,35074]
===
match
---
operator: { [63376,63377]
operator: { [65092,65093]
===
match
---
with_stmt [2806,3136]
with_stmt [2806,3136]
===
match
---
operator: = [9643,9644]
operator: = [9643,9644]
===
match
---
operator: = [4742,4743]
operator: = [4742,4743]
===
match
---
atom [26978,27010]
atom [28694,28726]
===
match
---
with_stmt [36420,36542]
with_stmt [38136,38258]
===
match
---
name: i [13063,13064]
name: i [13063,13064]
===
match
---
atom_expr [71065,71084]
atom_expr [72781,72800]
===
match
---
string: "2018-10-28T01:00:00+00:00" [20807,20834]
string: "2018-10-28T01:00:00+00:00" [20807,20834]
===
match
---
trailer [43365,43379]
trailer [45081,45095]
===
match
---
trailer [17351,17361]
trailer [17351,17361]
===
match
---
number: 4 [68101,68102]
number: 4 [69817,69818]
===
match
---
operator: = [18207,18208]
operator: = [18207,18208]
===
match
---
name: DEFAULT_DATE [48292,48304]
name: DEFAULT_DATE [50008,50020]
===
match
---
name: catchup [56539,56546]
name: catchup [58255,58262]
===
match
---
trailer [20395,20416]
trailer [20395,20416]
===
match
---
trailer [42513,42515]
trailer [44229,44231]
===
match
---
name: dag [35586,35589]
name: dag [37302,37305]
===
match
---
simple_stmt [22785,22819]
simple_stmt [22785,22819]
===
match
---
trailer [25473,25476]
trailer [27189,27192]
===
match
---
name: query [41625,41630]
name: query [43341,43346]
===
match
---
parameters [29828,29834]
parameters [31544,31550]
===
match
---
operator: = [9846,9847]
operator: = [9846,9847]
===
match
---
name: subdag_id [31644,31653]
name: subdag_id [33360,33369]
===
match
---
trailer [19435,19437]
trailer [19435,19437]
===
match
---
trailer [19458,19469]
trailer [19458,19469]
===
match
---
expr_stmt [21114,21149]
expr_stmt [21114,21149]
===
match
---
name: dag [61028,61031]
name: dag [62744,62747]
===
match
---
operator: = [24576,24577]
operator: = [26292,26293]
===
match
---
simple_stmt [17379,17405]
simple_stmt [17379,17405]
===
match
---
name: DAG [10784,10787]
name: DAG [10784,10787]
===
match
---
name: end_date [69514,69522]
name: end_date [71230,71238]
===
match
---
trailer [54593,54596]
trailer [56309,56312]
===
match
---
name: AirflowException [5235,5251]
name: AirflowException [5235,5251]
===
match
---
name: xcom_arg [70066,70074]
name: xcom_arg [71782,71790]
===
match
---
atom [26828,26860]
atom [28544,28576]
===
match
---
name: self [12492,12496]
name: self [12492,12496]
===
match
---
parameters [42998,43004]
parameters [44714,44720]
===
match
---
trailer [29678,29690]
trailer [31394,31406]
===
match
---
expr_stmt [22827,22862]
expr_stmt [22827,22862]
===
match
---
comparison [37689,37724]
comparison [39405,39440]
===
match
---
trailer [69399,69412]
trailer [71115,71128]
===
match
---
comparison [34994,35028]
comparison [36710,36744]
===
match
---
name: task [13448,13452]
name: task [13448,13452]
===
match
---
atom_expr [36981,37021]
atom_expr [38697,38737]
===
match
---
argument [31768,31791]
argument [33484,33507]
===
match
---
suite [25400,25440]
suite [27116,27156]
===
match
---
name: expand [65648,65654]
name: expand [67364,67370]
===
match
---
name: dag [27752,27755]
name: dag [29468,29471]
===
match
---
simple_stmt [7586,7717]
simple_stmt [7586,7717]
===
match
---
name: model [28027,28032]
name: model [29743,29748]
===
match
---
simple_stmt [51462,51512]
simple_stmt [53178,53228]
===
match
---
trailer [42803,42809]
trailer [44519,44525]
===
match
---
name: op2 [37096,37099]
name: op2 [38812,38815]
===
match
---
trailer [13349,13360]
trailer [13349,13360]
===
match
---
trailer [24267,24269]
trailer [25983,25985]
===
match
---
name: paused_dag_ids [46079,46093]
name: paused_dag_ids [47795,47809]
===
match
---
name: DagModel [25244,25252]
name: DagModel [26960,26968]
===
match
---
atom_expr [20115,20130]
atom_expr [20115,20130]
===
match
---
name: _next [22074,22079]
name: _next [22074,22079]
===
match
---
name: all [26390,26393]
name: all [28106,28109]
===
match
---
name: session [54297,54304]
name: session [56013,56020]
===
match
---
fstring_end: ' [61819,61820]
fstring_end: ' [63535,63536]
===
match
---
import_from [879,917]
import_from [879,917]
===
match
---
trailer [8918,8931]
trailer [8918,8931]
===
match
---
name: orm_dag [64076,64083]
name: orm_dag [65792,65799]
===
match
---
trailer [42901,42926]
trailer [44617,44642]
===
match
---
name: dag [56711,56714]
name: dag [58427,58430]
===
match
---
name: f [19690,19691]
name: f [19690,19691]
===
match
---
operator: = [45981,45982]
operator: = [47697,47698]
===
match
---
name: DagRunType [69301,69311]
name: DagRunType [71017,71027]
===
match
---
name: template_searchpath [19810,19829]
name: template_searchpath [19810,19829]
===
match
---
name: task_id [49783,49790]
name: task_id [51499,51506]
===
match
---
operator: , [26262,26263]
operator: , [27978,27979]
===
match
---
name: microsecond [56971,56982]
name: microsecond [58687,58698]
===
match
---
name: value [68600,68605]
name: value [70316,70321]
===
match
---
name: state [49366,49371]
name: state [51082,51087]
===
match
---
string: 'owner2' [6062,6070]
string: 'owner2' [6062,6070]
===
match
---
comparison [45443,45467]
comparison [47159,47183]
===
match
---
trailer [23070,23078]
trailer [23070,23078]
===
match
---
atom_expr [70519,70545]
atom_expr [72235,72261]
===
match
---
argument [16828,16846]
argument [16828,16846]
===
match
---
comparison [29421,29449]
comparison [31137,31165]
===
match
---
name: close [34709,34714]
name: close [36425,36430]
===
match
---
trailer [4735,4795]
trailer [4735,4795]
===
match
---
name: task [14773,14777]
name: task [14773,14777]
===
match
---
trailer [65324,65326]
trailer [67040,67042]
===
match
---
name: DuplicateTaskIdFound [37402,37422]
name: DuplicateTaskIdFound [39118,39138]
===
match
---
simple_stmt [35965,35999]
simple_stmt [37681,37715]
===
match
---
operator: = [46807,46808]
operator: = [48523,48524]
===
match
---
name: b [3180,3181]
name: b [3180,3181]
===
match
---
name: width [13951,13956]
name: width [13951,13956]
===
match
---
name: os [19030,19032]
name: os [19030,19032]
===
match
---
simple_stmt [65180,65234]
simple_stmt [66896,66950]
===
match
---
arglist [50091,50234]
arglist [51807,51950]
===
match
---
argument [62339,62358]
argument [64055,64074]
===
match
---
name: task_instance_1 [50524,50539]
name: task_instance_1 [52240,52255]
===
match
---
simple_stmt [60004,60054]
simple_stmt [61720,61770]
===
match
---
fstring_expr [39624,39648]
fstring_expr [41340,41364]
===
match
---
import_name [853,862]
import_name [853,862]
===
match
---
import_from [1667,1714]
import_from [1667,1714]
===
match
---
operator: = [52132,52133]
operator: = [53848,53849]
===
match
---
argument [50169,50192]
argument [51885,51908]
===
match
---
trailer [25638,25641]
trailer [27354,27357]
===
match
---
dictorsetmaker [44250,44296]
dictorsetmaker [45966,46012]
===
match
---
trailer [10224,10227]
trailer [10224,10227]
===
match
---
name: State [48036,48041]
name: State [49752,49757]
===
match
---
name: DAG [53576,53579]
name: DAG [55292,55295]
===
match
---
dictorsetmaker [24850,24904]
dictorsetmaker [26566,26620]
===
match
---
simple_stmt [46803,46876]
simple_stmt [48519,48592]
===
match
---
name: self [53516,53520]
name: self [55232,55236]
===
match
---
name: default_args [16511,16523]
name: default_args [16511,16523]
===
match
---
name: num [68044,68047]
name: num [69760,69763]
===
match
---
operator: { [29215,29216]
operator: { [30931,30932]
===
match
---
operator: = [52968,52969]
operator: = [54684,54685]
===
match
---
trailer [44369,44401]
trailer [46085,46117]
===
match
---
name: airflow [2014,2021]
name: airflow [2014,2021]
===
match
---
simple_stmt [27612,27641]
simple_stmt [29328,29357]
===
match
---
simple_stmt [1076,1092]
simple_stmt [1076,1092]
===
match
---
trailer [65357,65378]
trailer [67073,67094]
===
match
---
comparison [20850,20903]
comparison [20850,20903]
===
match
---
name: run_type [50091,50099]
name: run_type [51807,51815]
===
match
---
name: dags [24513,24517]
name: dags [26229,26233]
===
match
---
trailer [59902,59925]
trailer [61618,61641]
===
match
---
name: dag_diff_name [44718,44731]
name: dag_diff_name [46434,46447]
===
match
---
string: 'test-default_orientation' [5562,5588]
string: 'test-default_orientation' [5562,5588]
===
match
---
assert_stmt [29414,29449]
assert_stmt [31130,31165]
===
match
---
name: dag [10606,10609]
name: dag [10606,10609]
===
match
---
simple_stmt [26803,27082]
simple_stmt [28519,28798]
===
match
---
name: QUEUED [18366,18372]
name: QUEUED [18366,18372]
===
match
---
operator: = [55701,55702]
operator: = [57417,57418]
===
match
---
name: DagModel [29116,29124]
name: DagModel [30832,30840]
===
match
---
simple_stmt [46021,46070]
simple_stmt [47737,47786]
===
match
---
suite [66569,66621]
suite [68285,68337]
===
match
---
trailer [29198,29204]
trailer [30914,30920]
===
match
---
name: self [40898,40902]
name: self [42614,42618]
===
match
---
trailer [8799,8812]
trailer [8799,8812]
===
match
---
name: operator [70075,70083]
name: operator [71791,71799]
===
match
---
operator: = [30874,30875]
operator: = [32590,32591]
===
match
---
operator: , [64002,64003]
operator: , [65718,65719]
===
match
---
trailer [69470,69479]
trailer [71186,71195]
===
match
---
suite [65546,65571]
suite [67262,67287]
===
match
---
expr_stmt [37096,37152]
expr_stmt [38812,38868]
===
match
---
name: task_id [35458,35465]
name: task_id [37174,37181]
===
match
---
simple_stmt [3563,3706]
simple_stmt [3563,3706]
===
match
---
suite [2839,3136]
suite [2839,3136]
===
match
---
assert_stmt [22290,22344]
assert_stmt [22290,22344]
===
match
---
suite [46794,47015]
suite [48510,48731]
===
match
---
operator: , [61378,61379]
operator: , [63094,63095]
===
match
---
name: leaves [36071,36077]
name: leaves [37787,37793]
===
match
---
testlist_comp [32330,32347]
testlist_comp [34046,34063]
===
match
---
name: partial_subset [38576,38590]
name: partial_subset [40292,40306]
===
match
---
argument [50206,50233]
argument [51922,51949]
===
match
---
operator: , [17831,17832]
operator: , [17831,17832]
===
match
---
comparison [23394,23441]
comparison [23394,23441]
===
match
---
name: session [31411,31418]
name: session [33127,33134]
===
match
---
arglist [47847,47930]
arglist [49563,49646]
===
match
---
name: logging [9037,9044]
name: logging [9037,9044]
===
match
---
name: session [64360,64367]
name: session [66076,66083]
===
match
---
assert_stmt [20843,20903]
assert_stmt [20843,20903]
===
match
---
trailer [27746,27750]
trailer [29462,29466]
===
match
---
trailer [63417,63433]
trailer [65133,65149]
===
match
---
argument [23722,23745]
argument [23722,23745]
===
match
---
trailer [32234,32271]
trailer [33950,33987]
===
match
---
name: j [12988,12989]
name: j [12988,12989]
===
match
---
simple_stmt [2519,2591]
simple_stmt [2519,2591]
===
match
---
assert_stmt [68213,68267]
assert_stmt [69929,69983]
===
match
---
name: task_id [3422,3429]
name: task_id [3422,3429]
===
match
---
argument [57304,57317]
argument [59020,59033]
===
match
---
operator: , [27998,27999]
operator: , [29714,29715]
===
match
---
name: State [66097,66102]
name: State [67813,67818]
===
match
---
atom_expr [36570,36588]
atom_expr [38286,38304]
===
match
---
name: BashOperator [1702,1714]
name: BashOperator [1702,1714]
===
match
---
with_item [18903,18946]
with_item [18903,18946]
===
match
---
name: merge [17512,17517]
name: merge [17512,17517]
===
match
---
name: operators [1778,1787]
name: operators [1778,1787]
===
match
---
name: self [47063,47067]
name: self [48779,48783]
===
match
---
assert_stmt [49275,49299]
assert_stmt [50991,51015]
===
match
---
argument [41214,41237]
argument [42930,42953]
===
match
---
name: self [69615,69619]
name: self [71331,71335]
===
match
---
operator: = [44395,44396]
operator: = [46111,46112]
===
match
---
simple_stmt [66410,66455]
simple_stmt [68126,68171]
===
match
---
argument [24547,24570]
argument [26263,26286]
===
match
---
operator: } [62002,62003]
operator: } [63718,63719]
===
match
---
term [13611,13645]
term [13611,13645]
===
match
---
simple_stmt [48629,48653]
simple_stmt [50345,50369]
===
match
---
name: op4 [9096,9099]
name: op4 [9096,9099]
===
match
---
operator: , [58204,58205]
operator: , [59920,59921]
===
match
---
operator: , [36015,36016]
operator: , [37731,37732]
===
match
---
decorated [69017,69093]
decorated [70733,70809]
===
match
---
name: args [44242,44246]
name: args [45958,45962]
===
match
---
trailer [27431,27504]
trailer [29147,29220]
===
match
---
argument [50663,50682]
argument [52379,52398]
===
match
---
simple_stmt [15462,15822]
simple_stmt [15462,15822]
===
match
---
assert_stmt [8413,8479]
assert_stmt [8413,8479]
===
match
---
string: 'owner1' [29216,29224]
string: 'owner1' [30932,30940]
===
match
---
argument [66673,66703]
argument [68389,68419]
===
match
---
operator: = [3401,3402]
operator: = [3401,3402]
===
match
---
operator: , [50577,50578]
operator: , [52293,52294]
===
match
---
argument [69380,69412]
argument [71096,71128]
===
match
---
simple_stmt [40799,40811]
simple_stmt [42515,42527]
===
match
---
expr_stmt [70514,70545]
expr_stmt [72230,72261]
===
match
---
simple_stmt [9936,9958]
simple_stmt [9936,9958]
===
match
---
name: expected_n_schedule_interval [46928,46956]
name: expected_n_schedule_interval [48644,48672]
===
match
---
name: prev [21760,21764]
name: prev [21760,21764]
===
match
---
operator: } [14244,14245]
operator: } [14244,14245]
===
match
---
operator: == [51253,51255]
operator: == [52969,52971]
===
match
---
atom_expr [42896,42926]
atom_expr [44612,44642]
===
match
---
name: dag_id [32146,32152]
name: dag_id [33862,33868]
===
match
---
name: prev [20985,20989]
name: prev [20985,20989]
===
match
---
string: 'new_nonexisting_dag' [33142,33163]
string: 'new_nonexisting_dag' [34858,34879]
===
match
---
classdef [63805,65478]
classdef [65521,67194]
===
match
---
trailer [22962,22964]
trailer [22962,22964]
===
match
---
name: op5 [36088,36091]
name: op5 [37804,37807]
===
match
---
operator: = [50829,50830]
operator: = [52545,52546]
===
match
---
name: orm_dag [65260,65267]
name: orm_dag [66976,66983]
===
match
---
trailer [42382,42445]
trailer [44098,44161]
===
match
---
name: DEPRECATED_ACTION_CAN_DAG_READ [63155,63185]
name: DEPRECATED_ACTION_CAN_DAG_READ [64871,64901]
===
match
---
trailer [26753,26770]
trailer [28469,28486]
===
match
---
trailer [64291,64300]
trailer [66007,66016]
===
match
---
trailer [8972,8977]
trailer [8972,8977]
===
match
---
trailer [21186,21188]
trailer [21186,21188]
===
match
---
argument [52503,52530]
argument [54219,54246]
===
match
---
trailer [47530,47540]
trailer [49246,49256]
===
match
---
simple_stmt [10691,10727]
simple_stmt [10691,10727]
===
match
---
trailer [24125,24127]
trailer [25841,25843]
===
match
---
argument [52987,53002]
argument [54703,54718]
===
match
---
name: datetime [50880,50888]
name: datetime [52596,52604]
===
match
---
name: op1 [8735,8738]
name: op1 [8735,8738]
===
match
---
operator: , [6012,6013]
operator: , [6012,6013]
===
match
---
simple_stmt [4444,4481]
simple_stmt [4444,4481]
===
match
---
operator: = [54860,54861]
operator: = [56576,56577]
===
match
---
operator: = [67041,67042]
operator: = [68757,68758]
===
match
---
simple_stmt [47811,47941]
simple_stmt [49527,49657]
===
match
---
argument [49975,49989]
argument [51691,51705]
===
match
---
trailer [53762,53776]
trailer [55478,55492]
===
match
---
operator: , [60824,60825]
operator: , [62540,62541]
===
match
---
name: TI [54395,54397]
name: TI [56111,56113]
===
match
---
suite [66649,66899]
suite [68365,68615]
===
match
---
number: 1 [23686,23687]
number: 1 [23686,23687]
===
match
---
trailer [66505,66507]
trailer [68221,68223]
===
match
---
name: dag [39087,39090]
name: dag [40803,40806]
===
match
---
funcdef [69631,70587]
funcdef [71347,72303]
===
match
---
trailer [5068,5081]
trailer [5068,5081]
===
match
---
number: 10 [21509,21511]
number: 10 [21509,21511]
===
match
---
name: State [18070,18075]
name: State [18070,18075]
===
match
---
name: test_sync_to_db_default_view [29800,29828]
name: test_sync_to_db_default_view [31516,31544]
===
match
---
atom_expr [56894,56994]
atom_expr [58610,58710]
===
match
---
name: RUNNING [40532,40539]
name: RUNNING [42248,42255]
===
match
---
name: args [44531,44535]
name: args [46247,46251]
===
match
---
operator: = [63892,63893]
operator: = [65608,65609]
===
match
---
argument [12870,12902]
argument [12870,12902]
===
match
---
trailer [34559,34569]
trailer [36275,36285]
===
match
---
operator: = [50624,50625]
operator: = [52340,52341]
===
match
---
trailer [20976,20984]
trailer [20976,20984]
===
match
---
name: _next [24022,24027]
name: _next [24022,24027]
===
match
---
atom [32033,32047]
atom [33749,33763]
===
match
---
simple_stmt [37046,37080]
simple_stmt [38762,38796]
===
match
---
name: task_instance_2 [52698,52713]
name: task_instance_2 [54414,54429]
===
match
---
trailer [13073,13083]
trailer [13073,13083]
===
match
---
simple_stmt [31593,31695]
simple_stmt [33309,33411]
===
match
---
operator: , [53933,53934]
operator: , [55649,55650]
===
match
---
string: 'Also fake' [42411,42422]
string: 'Also fake' [44127,44138]
===
match
---
name: topological_list [9374,9390]
name: topological_list [9374,9390]
===
match
---
parameters [8515,8521]
parameters [8515,8521]
===
match
---
simple_stmt [68736,68794]
simple_stmt [70452,70510]
===
match
---
operator: = [61032,61033]
operator: = [62748,62749]
===
match
---
name: dag [14116,14119]
name: dag [14116,14119]
===
match
---
expr_stmt [14821,14856]
expr_stmt [14821,14856]
===
match
---
name: job_id [47730,47736]
name: job_id [49446,49452]
===
match
---
assert_stmt [15119,15161]
assert_stmt [15119,15161]
===
match
---
atom [4212,4229]
atom [4212,4229]
===
match
---
trailer [54275,54283]
trailer [55991,55999]
===
match
---
name: query [31419,31424]
name: query [33135,33140]
===
match
---
operator: = [61894,61895]
operator: = [63610,63611]
===
match
---
operator: , [36086,36087]
operator: , [37802,37803]
===
match
---
string: "t2" [35374,35378]
string: "t2" [37090,37094]
===
match
---
argument [56693,56705]
argument [58409,58421]
===
match
---
atom [35530,35540]
atom [37246,37256]
===
match
---
operator: = [28922,28923]
operator: = [30638,30639]
===
match
---
atom_expr [14886,14905]
atom_expr [14886,14905]
===
match
---
number: 1 [66452,66453]
number: 1 [68168,68169]
===
match
---
atom_expr [9153,9186]
atom_expr [9153,9186]
===
match
---
name: paused_dag_ids [46149,46163]
name: paused_dag_ids [47865,47879]
===
match
---
atom_expr [34253,34268]
atom_expr [35969,35984]
===
match
---
arglist [44573,44603]
arglist [46289,46319]
===
match
---
operator: = [43148,43149]
operator: = [44864,44865]
===
match
---
operator: == [18274,18276]
operator: == [18274,18276]
===
match
---
trailer [20435,20450]
trailer [20435,20450]
===
match
---
string: 'test' [68198,68204]
string: 'test' [69914,69920]
===
match
---
name: self [51432,51436]
name: self [53148,53152]
===
match
---
atom_expr [9325,9358]
atom_expr [9325,9358]
===
match
---
name: max_active_runs [27517,27532]
name: max_active_runs [29233,29248]
===
match
---
name: state [27979,27984]
name: state [29695,29700]
===
match
---
operator: < [3492,3493]
operator: < [3492,3493]
===
match
---
trailer [6245,6251]
trailer [6245,6251]
===
match
---
operator: } [14240,14241]
operator: } [14240,14241]
===
match
---
string: """         Tests if a start_date of None in default_args         works.         """ [12253,12337]
string: """         Tests if a start_date of None in default_args         works.         """ [12253,12337]
===
match
---
name: convert [22575,22582]
name: convert [22575,22582]
===
match
---
string: "2015-01-02T01:00:00+00:00" [23932,23959]
string: "2015-01-02T01:00:00+00:00" [23932,23959]
===
match
---
name: i [14458,14459]
name: i [14458,14459]
===
match
---
trailer [32141,32153]
trailer [33857,33869]
===
match
---
name: return_num [69049,69059]
name: return_num [70765,70775]
===
match
---
operator: = [9506,9507]
operator: = [9506,9507]
===
match
---
trailer [52223,52237]
trailer [53939,53953]
===
match
---
operator: = [19926,19927]
operator: = [19926,19927]
===
match
---
suite [37480,37673]
suite [39196,39389]
===
match
---
operator: = [50668,50669]
operator: = [52384,52385]
===
match
---
operator: = [37644,37645]
operator: = [39360,39361]
===
match
---
name: dag_id [3084,3090]
name: dag_id [3084,3090]
===
match
---
simple_stmt [3274,3287]
simple_stmt [3274,3287]
===
match
---
name: prev [23229,23233]
name: prev [23229,23233]
===
match
---
suite [41596,41660]
suite [43312,43376]
===
match
---
string: "faketastic" [42391,42403]
string: "faketastic" [44107,44119]
===
match
---
operator: = [37100,37101]
operator: = [38816,38817]
===
match
---
with_stmt [36976,37180]
with_stmt [38692,38896]
===
match
---
name: max_active_runs [51754,51769]
name: max_active_runs [53470,53485]
===
match
---
name: return_num [68532,68542]
name: return_num [70248,70258]
===
match
---
operator: @ [68911,68912]
operator: @ [70627,70628]
===
match
---
param [49553,49566]
param [51269,51282]
===
match
---
operator: , [26311,26312]
operator: , [28027,28028]
===
match
---
name: op2 [35606,35609]
name: op2 [37322,37325]
===
match
---
argument [37627,37639]
argument [39343,39355]
===
match
---
name: dag [68113,68116]
name: dag [69829,69832]
===
match
---
fstring_string: -task- [62003,62009]
fstring_string: -task- [63719,63725]
===
match
---
argument [9794,9805]
argument [9794,9805]
===
match
---
name: i [3320,3321]
name: i [3320,3321]
===
match
---
operator: , [51361,51362]
operator: , [53077,53078]
===
match
---
argument [33056,33071]
argument [34772,34787]
===
match
---
suite [44215,44233]
suite [45931,45949]
===
match
---
name: dag_id [34509,34515]
name: dag_id [36225,36231]
===
match
---
simple_stmt [39186,39339]
simple_stmt [40902,41055]
===
match
---
name: conf [70384,70388]
name: conf [72100,72104]
===
match
---
name: bulk_write_to_db [25659,25675]
name: bulk_write_to_db [27375,27391]
===
match
---
simple_stmt [32624,32655]
simple_stmt [34340,34371]
===
match
---
operator: , [53822,53823]
operator: , [55538,55539]
===
match
---
name: fileloc [29759,29766]
name: fileloc [31475,31482]
===
match
---
operator: = [35831,35832]
operator: = [37547,37548]
===
match
---
name: start_date [55500,55510]
name: start_date [57216,57226]
===
match
---
operator: , [57715,57716]
operator: , [59431,59432]
===
match
---
trailer [17996,18019]
trailer [17996,18019]
===
match
---
trailer [30386,30393]
trailer [32102,32109]
===
match
---
arglist [50629,50682]
arglist [52345,52398]
===
match
---
simple_stmt [53181,53218]
simple_stmt [54897,54934]
===
match
---
trailer [4628,4635]
trailer [4628,4635]
===
match
---
name: dag_run_state [48935,48948]
name: dag_run_state [50651,50664]
===
match
---
atom_expr [37052,37079]
atom_expr [38768,38795]
===
match
---
atom_expr [19868,19896]
atom_expr [19868,19896]
===
match
---
name: timezone [22524,22532]
name: timezone [22524,22532]
===
match
---
number: 5 [15357,15358]
number: 5 [15357,15358]
===
match
---
name: priority_weight [14272,14287]
name: priority_weight [14272,14287]
===
match
---
testlist_comp [12953,13083]
testlist_comp [12953,13083]
===
match
---
operator: } [26699,26700]
operator: } [28415,28416]
===
match
---
atom [20042,20056]
atom [20042,20056]
===
match
---
name: session [30327,30334]
name: session [32043,32050]
===
match
---
trailer [21759,21765]
trailer [21759,21765]
===
match
---
fstring_start: f' [61985,61987]
fstring_start: f' [63701,63703]
===
match
---
name: test_sub_dag_updates_all_references_while_deepcopy [38249,38299]
name: test_sub_dag_updates_all_references_while_deepcopy [39965,40015]
===
match
---
trailer [16625,16671]
trailer [16625,16671]
===
match
---
name: is_active [65092,65101]
name: is_active [66808,66817]
===
match
---
name: timezone [60983,60991]
name: timezone [62699,62707]
===
match
---
atom_expr [46190,46206]
atom_expr [47906,47922]
===
match
---
name: next_date [58225,58234]
name: next_date [59941,59950]
===
match
---
assert_stmt [23904,23959]
assert_stmt [23904,23959]
===
match
---
name: DAG [64707,64710]
name: DAG [66423,66426]
===
match
---
atom_expr [51975,51993]
atom_expr [53691,53709]
===
match
---
atom_expr [55013,55050]
atom_expr [56729,56766]
===
match
---
name: dag_id [63898,63904]
name: dag_id [65614,65620]
===
match
---
trailer [70191,70205]
trailer [71907,71921]
===
match
---
simple_stmt [23904,23960]
simple_stmt [23904,23960]
===
match
---
name: dag [51880,51883]
name: dag [53596,53599]
===
match
---
comparison [17682,17759]
comparison [17682,17759]
===
match
---
string: 'dag-bulk-sync-1' [26879,26896]
string: 'dag-bulk-sync-1' [28595,28612]
===
match
---
atom_expr [19408,19437]
atom_expr [19408,19437]
===
match
---
expr_stmt [41164,41238]
expr_stmt [42880,42954]
===
match
---
name: dag [27581,27584]
name: dag [29297,29300]
===
match
---
name: previous_schedule [23240,23257]
name: previous_schedule [23240,23257]
===
match
---
name: DummyOperator [36257,36270]
name: DummyOperator [37973,37986]
===
match
---
atom_expr [22228,22250]
atom_expr [22228,22250]
===
match
---
atom_expr [18070,18083]
atom_expr [18070,18083]
===
match
---
trailer [69318,69324]
trailer [71034,71040]
===
match
---
trailer [28186,28193]
trailer [29902,29909]
===
match
---
name: dag [39389,39392]
name: dag [41105,41108]
===
match
---
name: query [29110,29115]
name: query [30826,30831]
===
match
---
atom_expr [60741,60781]
atom_expr [62457,62497]
===
match
---
atom_expr [40728,40789]
atom_expr [42444,42505]
===
match
---
assert_stmt [10504,10537]
assert_stmt [10504,10537]
===
match
---
trailer [63466,63472]
trailer [65182,65188]
===
match
---
name: model [27889,27894]
name: model [29605,29610]
===
match
---
trailer [31990,31992]
trailer [33706,33708]
===
match
---
atom_expr [51707,51772]
atom_expr [53423,53488]
===
match
---
for_stmt [65851,65956]
for_stmt [67567,67672]
===
match
---
argument [18062,18084]
argument [18062,18084]
===
match
---
parameters [9436,9442]
parameters [9436,9442]
===
match
---
atom_expr [67655,67675]
atom_expr [69371,69391]
===
match
---
decorator [3141,3155]
decorator [3141,3155]
===
match
---
trailer [33168,33170]
trailer [34884,34886]
===
match
---
name: DAG [19125,19128]
name: DAG [19125,19128]
===
match
---
simple_stmt [29551,29617]
simple_stmt [31267,31333]
===
match
---
name: op3 [38222,38225]
name: op3 [39938,39941]
===
match
---
simple_stmt [35300,35334]
simple_stmt [37016,37050]
===
match
---
name: dag [12041,12044]
name: dag [12041,12044]
===
match
---
simple_stmt [20610,20681]
simple_stmt [20610,20681]
===
match
---
trailer [32317,32324]
trailer [34033,34040]
===
match
---
atom_expr [10264,10281]
atom_expr [10264,10281]
===
match
---
param [65759,65770]
param [67475,67486]
===
match
---
name: NamedTemporaryFile [19547,19565]
name: NamedTemporaryFile [19547,19565]
===
match
---
operator: , [31958,31959]
operator: , [33674,33675]
===
match
---
string: 'test-invalid-default_view' [4743,4770]
string: 'test-invalid-default_view' [4743,4770]
===
match
---
name: DummyOperator [16612,16625]
name: DummyOperator [16612,16625]
===
match
---
name: f [19589,19590]
name: f [19589,19590]
===
match
---
name: task_instance_1 [52659,52674]
name: task_instance_1 [54375,54390]
===
match
---
atom_expr [26348,26395]
atom_expr [28064,28111]
===
match
---
trailer [39782,39790]
trailer [41498,41506]
===
match
---
simple_stmt [44357,44402]
simple_stmt [46073,46118]
===
match
---
name: task_id [51672,51679]
name: task_id [53388,53395]
===
match
---
operator: , [17954,17955]
operator: , [17954,17955]
===
match
---
comparison [23102,23155]
comparison [23102,23155]
===
match
---
name: RUNNING [70363,70370]
name: RUNNING [72079,72086]
===
match
---
string: 'op3' [6392,6397]
string: 'op3' [6392,6397]
===
match
---
trailer [8211,8253]
trailer [8211,8253]
===
match
---
number: 25 [22610,22612]
number: 25 [22610,22612]
===
match
---
simple_stmt [45940,45988]
simple_stmt [47656,47704]
===
match
---
name: dag [45695,45698]
name: dag [47411,47414]
===
match
---
decorator [68911,68958]
decorator [70627,70674]
===
match
---
trailer [54121,54138]
trailer [55837,55854]
===
match
---
atom_expr [70226,70249]
atom_expr [71942,71965]
===
match
---
arglist [8541,8605]
arglist [8541,8605]
===
match
---
atom [65696,65701]
atom [67412,67417]
===
match
---
argument [56961,56969]
argument [58677,58685]
===
match
---
name: args [43999,44003]
name: args [45715,45719]
===
match
---
simple_stmt [7322,7462]
simple_stmt [7322,7462]
===
match
---
simple_stmt [6151,6196]
simple_stmt [6151,6196]
===
match
---
trailer [17457,17463]
trailer [17457,17463]
===
match
---
atom_expr [66524,66537]
atom_expr [68240,68253]
===
match
---
name: op3 [38071,38074]
name: op3 [39787,39790]
===
match
---
trailer [27559,27602]
trailer [29275,29318]
===
match
---
comparison [15890,15896]
comparison [15890,15896]
===
match
---
for_stmt [13266,13361]
for_stmt [13266,13361]
===
match
---
name: TI [17294,17296]
name: TI [17294,17296]
===
match
---
suite [37930,38075]
suite [39646,39791]
===
match
---
name: external_trigger [41497,41513]
name: external_trigger [43213,43229]
===
match
---
expr_stmt [19310,19348]
expr_stmt [19310,19348]
===
match
---
arglist [15739,15747]
arglist [15739,15747]
===
match
---
argument [37424,37478]
argument [39140,39194]
===
match
---
name: stage [15841,15846]
name: stage [15841,15846]
===
match
---
expr_stmt [12562,12604]
expr_stmt [12562,12604]
===
match
---
operator: { [10925,10926]
operator: { [10925,10926]
===
match
---
atom_expr [20968,20990]
atom_expr [20968,20990]
===
match
---
simple_stmt [47750,47803]
simple_stmt [49466,49519]
===
match
---
parameters [36787,36793]
parameters [38503,38509]
===
match
---
name: needed [65180,65186]
name: needed [66896,66902]
===
match
---
string: "Regular DAG documentation" [68240,68267]
string: "Regular DAG documentation" [69956,69983]
===
match
---
atom [51347,51363]
atom [53063,53079]
===
match
---
atom_expr [5605,5645]
atom_expr [5605,5645]
===
match
---
string: 'task' [28616,28622]
string: 'task' [30332,30338]
===
match
---
simple_stmt [39054,39079]
simple_stmt [40770,40795]
===
match
---
name: TaskFail [1488,1496]
name: TaskFail [1488,1496]
===
match
---
fstring_start: f' [39572,39574]
fstring_start: f' [41288,41290]
===
match
---
name: template_searchpath [19166,19185]
name: template_searchpath [19166,19185]
===
match
---
trailer [18158,18256]
trailer [18158,18256]
===
match
---
funcdef [20167,21247]
funcdef [20167,21247]
===
match
---
atom_expr [47655,47672]
atom_expr [49371,49388]
===
match
---
trailer [29040,29042]
trailer [30756,30758]
===
match
---
comparison [55066,55083]
comparison [56782,56799]
===
match
---
trailer [17544,17549]
trailer [17544,17549]
===
match
---
simple_stmt [21070,21106]
simple_stmt [21070,21106]
===
match
---
atom_expr [65311,65326]
atom_expr [67027,67042]
===
match
---
atom_expr [18960,18980]
atom_expr [18960,18980]
===
match
---
operator: = [66423,66424]
operator: = [68139,68140]
===
match
---
expr_stmt [38562,38645]
expr_stmt [40278,40361]
===
match
---
name: UPSTREAM [14343,14351]
name: UPSTREAM [14343,14351]
===
match
---
argument [51754,51771]
argument [53470,53487]
===
match
---
expr_stmt [44784,44818]
expr_stmt [46500,46534]
===
match
---
simple_stmt [49809,49884]
simple_stmt [51525,51600]
===
match
---
trailer [50473,50483]
trailer [52189,52199]
===
match
---
trailer [37571,37594]
trailer [39287,39310]
===
match
---
operator: , [46566,46567]
operator: , [48282,48283]
===
match
---
operator: = [23684,23685]
operator: = [23684,23685]
===
match
---
name: op3 [8938,8941]
name: op3 [8938,8941]
===
match
---
atom_expr [36616,36631]
atom_expr [38332,38347]
===
match
---
name: dag [55013,55016]
name: dag [56729,56732]
===
match
---
trailer [65387,65391]
trailer [67103,67107]
===
match
---
operator: = [36301,36302]
operator: = [38017,38018]
===
match
---
string: "test_dag" [37886,37896]
string: "test_dag" [39602,39612]
===
match
---
atom_expr [21965,21988]
atom_expr [21965,21988]
===
match
---
name: op2 [36017,36020]
name: op2 [37733,37736]
===
match
---
operator: = [29100,29101]
operator: = [30816,30817]
===
match
---
trailer [3362,3370]
trailer [3362,3370]
===
match
---
name: DummyOperator [6157,6170]
name: DummyOperator [6157,6170]
===
match
---
dotted_name [65634,65654]
dotted_name [67350,67370]
===
match
---
with_item [46190,46217]
with_item [47906,47933]
===
match
---
string: 'parameter2' [4249,4261]
string: 'parameter2' [4249,4261]
===
match
---
atom_expr [23768,23843]
atom_expr [23768,23843]
===
match
---
trailer [48642,48652]
trailer [50358,50368]
===
match
---
arglist [8288,8328]
arglist [8288,8328]
===
match
---
operator: } [12395,12396]
operator: } [12395,12396]
===
match
---
with_stmt [14038,15162]
with_stmt [14038,15162]
===
match
---
string: 'owner' [5967,5974]
string: 'owner' [5967,5974]
===
match
---
atom_expr [30043,30266]
atom_expr [31759,31982]
===
match
---
for_stmt [55734,55839]
for_stmt [57450,57555]
===
match
---
string: 'tag-2' [24205,24212]
string: 'tag-2' [25921,25928]
===
match
---
simple_stmt [17130,17156]
simple_stmt [17130,17156]
===
match
---
operator: = [15660,15661]
operator: = [15660,15661]
===
match
---
trailer [2744,2746]
trailer [2744,2746]
===
match
---
arglist [37503,37538]
arglist [39219,39254]
===
match
---
atom [28239,28252]
atom [29955,29968]
===
match
---
operator: = [32177,32178]
operator: = [33893,33894]
===
match
---
name: DEFAULT_DATE [7693,7705]
name: DEFAULT_DATE [7693,7705]
===
match
---
operator: = [41513,41514]
operator: = [43229,43230]
===
match
---
arglist [18317,18405]
arglist [18317,18405]
===
match
---
name: op1 [38091,38094]
name: op1 [39807,39810]
===
match
---
operator: = [35900,35901]
operator: = [37616,37617]
===
match
---
assert_stmt [29551,29616]
assert_stmt [31267,31332]
===
match
---
operator: } [14110,14111]
operator: } [14110,14111]
===
match
---
name: dag [37586,37589]
name: dag [39302,39305]
===
match
---
trailer [19565,19585]
trailer [19565,19585]
===
match
---
trailer [19314,19330]
trailer [19314,19330]
===
match
---
fstring [65914,65931]
fstring [67630,67647]
===
match
---
name: start_date [48834,48844]
name: start_date [50550,50560]
===
match
---
name: num [67578,67581]
name: num [69294,69297]
===
match
---
expr_stmt [70183,70420]
expr_stmt [71899,72136]
===
match
---
name: task_id [64778,64785]
name: task_id [66494,66501]
===
match
---
name: DagModel [32252,32260]
name: DagModel [33968,33976]
===
match
---
trailer [26361,26389]
trailer [28077,28105]
===
match
---
atom_expr [7064,7092]
atom_expr [7064,7092]
===
match
---
name: params2 [4427,4434]
name: params2 [4427,4434]
===
match
---
operator: = [32571,32572]
operator: = [34287,34288]
===
match
---
argument [18584,18607]
argument [18584,18607]
===
match
---
operator: , [7668,7669]
operator: , [7668,7669]
===
match
---
arglist [22601,22615]
arglist [22601,22615]
===
match
---
trailer [70205,70420]
trailer [71921,72136]
===
match
---
operator: , [20515,20516]
operator: , [20515,20516]
===
match
---
name: j [13021,13022]
name: j [13021,13022]
===
match
---
name: dag_id [61776,61782]
name: dag_id [63492,63498]
===
match
---
name: utcnow [57542,57548]
name: utcnow [59258,59264]
===
match
---
name: current_task [13324,13336]
name: current_task [13324,13336]
===
match
---
simple_stmt [23229,23265]
simple_stmt [23229,23265]
===
match
---
argument [60884,60899]
argument [62600,62615]
===
match
---
operator: = [18670,18671]
operator: = [18670,18671]
===
match
---
operator: = [19245,19246]
operator: = [19245,19246]
===
match
---
operator: = [4279,4280]
operator: = [4279,4280]
===
match
---
expr_stmt [55337,55362]
expr_stmt [57053,57078]
===
match
---
name: session [34063,34070]
name: session [35779,35786]
===
match
---
expr_stmt [22504,22549]
expr_stmt [22504,22549]
===
match
---
simple_stmt [19408,19438]
simple_stmt [19408,19438]
===
match
---
name: create_dagrun [47135,47148]
name: create_dagrun [48851,48864]
===
match
---
argument [42543,42572]
argument [44259,44288]
===
match
---
name: DummyOperator [38387,38400]
name: DummyOperator [40103,40116]
===
match
---
trailer [37502,37539]
trailer [39218,39255]
===
match
---
operator: = [33448,33449]
operator: = [35164,35165]
===
match
---
simple_stmt [21000,21061]
simple_stmt [21000,21061]
===
match
---
name: DEFAULT_DATE [9480,9492]
name: DEFAULT_DATE [9480,9492]
===
match
---
argument [60795,60824]
argument [62511,62540]
===
match
---
operator: = [70319,70320]
operator: = [72035,72036]
===
match
---
atom [16524,16543]
atom [16524,16543]
===
match
---
name: settings [34073,34081]
name: settings [35789,35797]
===
match
---
operator: , [27060,27061]
operator: , [28776,28777]
===
match
---
operator: { [31600,31601]
operator: { [33316,33317]
===
match
---
operator: = [24557,24558]
operator: = [26273,26274]
===
match
---
operator: = [56280,56281]
operator: = [57996,57997]
===
match
---
name: local_tz [21468,21476]
name: local_tz [21468,21476]
===
match
---
trailer [59551,59765]
trailer [61267,61481]
===
match
---
operator: , [30124,30125]
operator: , [31840,31841]
===
match
---
trailer [50544,50599]
trailer [52260,52315]
===
match
---
operator: == [39535,39537]
operator: == [41251,41253]
===
match
---
operator: = [52517,52518]
operator: = [54233,54234]
===
match
---
atom_expr [2670,2685]
atom_expr [2670,2685]
===
match
---
comparison [58994,59036]
comparison [60710,60752]
===
match
---
operator: = [47923,47924]
operator: = [49639,49640]
===
match
---
name: dag [3770,3773]
name: dag [3770,3773]
===
match
---
name: fileloc [34343,34350]
name: fileloc [36059,36066]
===
match
---
operator: , [31621,31622]
operator: , [33337,33338]
===
match
---
trailer [6449,6455]
trailer [6449,6455]
===
match
---
name: num [69089,69092]
name: num [70805,70808]
===
match
---
expr_stmt [36555,36588]
expr_stmt [38271,38304]
===
match
---
name: dag_id [27432,27438]
name: dag_id [29148,29154]
===
match
---
operator: = [5561,5562]
operator: = [5561,5562]
===
match
---
atom_expr [70740,70757]
atom_expr [72456,72473]
===
match
---
argument [70263,70291]
argument [71979,72007]
===
match
---
string: 'role2' [63133,63140]
string: 'role2' [64849,64856]
===
match
---
simple_stmt [29775,29791]
simple_stmt [31491,31507]
===
match
---
operator: , [63956,63957]
operator: , [65672,65673]
===
match
---
atom_expr [26362,26375]
atom_expr [28078,28091]
===
match
---
name: op1 [6104,6107]
name: op1 [6104,6107]
===
match
---
expr_stmt [23005,23040]
expr_stmt [23005,23040]
===
match
---
operator: + [17341,17342]
operator: + [17341,17342]
===
match
---
trailer [27672,27689]
trailer [29388,29405]
===
match
---
comparison [39665,39695]
comparison [41381,41411]
===
match
---
name: dag [68220,68223]
name: dag [69936,69939]
===
match
---
trailer [20026,20039]
trailer [20026,20039]
===
match
---
name: dag [44803,44806]
name: dag [46519,46522]
===
match
---
trailer [65285,65295]
trailer [67001,67011]
===
match
---
name: range [14463,14468]
name: range [14463,14468]
===
match
---
name: dag [34029,34032]
name: dag [35745,35748]
===
match
---
assert_stmt [25294,25319]
assert_stmt [27010,27035]
===
match
---
trailer [68132,68134]
trailer [69848,69850]
===
match
---
testlist_comp [25948,25977]
testlist_comp [27664,27693]
===
match
---
assert_stmt [54942,54991]
assert_stmt [56658,56707]
===
match
---
operator: = [44430,44431]
operator: = [46146,46147]
===
match
---
operator: , [29909,29910]
operator: , [31625,31626]
===
match
---
assert_stmt [6917,6953]
assert_stmt [6917,6953]
===
match
---
operator: , [39570,39571]
operator: , [41286,41287]
===
match
---
argument [56951,56959]
argument [58667,58675]
===
match
---
trailer [9218,9221]
trailer [9218,9221]
===
match
---
string: """Verify correctness of dag.tree_view().""" [36132,36176]
string: """Verify correctness of dag.tree_view().""" [37848,37892]
===
match
---
trailer [42731,42733]
trailer [44447,44449]
===
match
---
operator: = [62624,62625]
operator: = [64340,64341]
===
match
---
operator: -> [65538,65540]
operator: -> [67254,67256]
===
match
---
name: name [35127,35131]
name: name [36843,36847]
===
match
---
operator: @ [68500,68501]
operator: @ [70216,70217]
===
match
---
simple_stmt [21159,21220]
simple_stmt [21159,21220]
===
match
---
name: RUNNING [48729,48736]
name: RUNNING [50445,50452]
===
match
---
trailer [33574,33617]
trailer [35290,35333]
===
match
---
name: session [27697,27704]
name: session [29413,29420]
===
match
---
trailer [12065,12074]
trailer [12065,12074]
===
match
---
argument [61776,61820]
argument [63492,63536]
===
match
---
operator: , [33471,33472]
operator: , [35187,35188]
===
match
---
trailer [26556,26562]
trailer [28272,28278]
===
match
---
arglist [11959,12024]
arglist [11959,12024]
===
match
---
trailer [54533,54549]
trailer [56249,56265]
===
match
---
argument [18609,18650]
argument [18609,18650]
===
match
---
name: dag [41164,41167]
name: dag [42880,42883]
===
match
---
import_from [2009,2046]
import_from [2009,2046]
===
match
---
number: 0 [62777,62778]
number: 0 [64493,64494]
===
match
---
trailer [17361,17369]
trailer [17361,17369]
===
match
---
name: typing [994,1000]
name: typing [994,1000]
===
match
---
trailer [3004,3031]
trailer [3004,3031]
===
match
---
name: dag [63506,63509]
name: dag [65222,65225]
===
match
---
simple_stmt [6573,6608]
simple_stmt [6573,6608]
===
match
---
expr_stmt [50524,50599]
expr_stmt [52240,52315]
===
match
---
arglist [51711,51771]
arglist [53427,53487]
===
match
---
name: task [19971,19975]
name: task [19971,19975]
===
match
---
name: dag [32664,32667]
name: dag [34380,34383]
===
match
---
name: timezone [59007,59015]
name: timezone [60723,60731]
===
match
---
with_stmt [18898,19438]
with_stmt [18898,19438]
===
match
---
simple_stmt [6205,6227]
simple_stmt [6205,6227]
===
match
---
name: task_id [9839,9846]
name: task_id [9839,9846]
===
match
---
name: dag2 [6635,6639]
name: dag2 [6635,6639]
===
match
---
name: dag [32933,32936]
name: dag [34649,34652]
===
match
---
atom_expr [42825,42835]
atom_expr [44541,44551]
===
match
---
operator: = [65950,65951]
operator: = [67666,67667]
===
match
---
simple_stmt [69082,69093]
simple_stmt [70798,70809]
===
match
---
name: topological_sort [10060,10076]
name: topological_sort [10060,10076]
===
match
---
argument [30327,30342]
argument [32043,32058]
===
match
---
name: dag [31726,31729]
name: dag [33442,33445]
===
match
---
name: prev [21070,21074]
name: prev [21070,21074]
===
match
---
atom_expr [18424,18439]
atom_expr [18424,18439]
===
match
---
name: op3 [38549,38552]
name: op3 [40265,40268]
===
match
---
name: session [34186,34193]
name: session [35902,35909]
===
match
---
string: "0 0 1 * *" [46487,46498]
string: "0 0 1 * *" [48203,48214]
===
match
---
name: task [19454,19458]
name: task [19454,19458]
===
match
---
argument [56439,56474]
argument [58155,58190]
===
match
---
name: session [53046,53053]
name: session [54762,54769]
===
match
---
operator: = [9479,9480]
operator: = [9479,9480]
===
match
---
name: NONE [48042,48046]
name: NONE [49758,49762]
===
match
---
arglist [58435,58445]
arglist [60151,60161]
===
match
---
atom_expr [56840,56857]
atom_expr [58556,58573]
===
match
---
name: Session [51984,51991]
name: Session [53700,53707]
===
match
---
name: session [50460,50467]
name: session [52176,52183]
===
match
---
name: default_args [68422,68434]
name: default_args [70138,70150]
===
match
---
trailer [36452,36454]
trailer [38168,38170]
===
match
---
assert_stmt [39504,39649]
assert_stmt [41220,41365]
===
match
---
param [56245,56252]
param [57961,57968]
===
match
---
name: dag_diff_name [45603,45616]
name: dag_diff_name [47319,47332]
===
match
---
with_item [6758,6815]
with_item [6758,6815]
===
match
---
arglist [2380,2396]
arglist [2380,2396]
===
match
---
operator: = [50058,50059]
operator: = [51774,51775]
===
match
---
name: op2 [38526,38529]
name: op2 [40242,40245]
===
match
---
trailer [21080,21098]
trailer [21080,21098]
===
match
---
name: timedelta [57037,57046]
name: timedelta [58753,58762]
===
match
---
atom_expr [23013,23040]
atom_expr [23013,23040]
===
match
---
simple_stmt [58987,59037]
simple_stmt [60703,60753]
===
match
---
number: 2018 [20396,20400]
number: 2018 [20396,20400]
===
match
---
simple_stmt [32403,32501]
simple_stmt [34119,34217]
===
match
---
suite [26604,27196]
suite [28320,28912]
===
match
---
number: 2018 [12129,12133]
number: 2018 [12129,12133]
===
match
---
number: 2 [57114,57115]
number: 2 [58830,58831]
===
match
---
name: DAG [18568,18571]
name: DAG [18568,18571]
===
match
---
string: 'tz_dag' [22717,22725]
string: 'tz_dag' [22717,22725]
===
match
---
argument [64004,64011]
argument [65720,65727]
===
match
---
name: dag [51574,51577]
name: dag [53290,53293]
===
match
---
name: subdag [30654,30660]
name: subdag [32370,32376]
===
match
---
assert_stmt [42848,42880]
assert_stmt [44564,44596]
===
match
---
operator: >> [36029,36031]
operator: >> [37745,37747]
===
match
---
operator: = [51883,51884]
operator: = [53599,53600]
===
match
---
number: 1 [62210,62211]
number: 1 [63926,63927]
===
match
---
trailer [63102,63118]
trailer [64818,64834]
===
match
---
name: next_date [57521,57530]
name: next_date [59237,59246]
===
match
---
operator: , [42598,42599]
operator: , [44314,44315]
===
match
---
operator: , [24163,24164]
operator: , [25879,25880]
===
match
---
simple_stmt [1267,1306]
simple_stmt [1267,1306]
===
match
---
operator: = [20359,20360]
operator: = [20359,20360]
===
match
---
name: dag [67287,67290]
name: dag [69003,69006]
===
match
---
expr_stmt [3714,3742]
expr_stmt [3714,3742]
===
match
---
trailer [45302,45308]
trailer [47018,47024]
===
match
---
operator: = [53644,53645]
operator: = [55360,55361]
===
match
---
atom_expr [53646,53685]
atom_expr [55362,55401]
===
match
---
atom_expr [21077,21105]
atom_expr [21077,21105]
===
match
---
number: 4 [67606,67607]
number: 4 [69322,69323]
===
match
---
name: _clean_up [39773,39782]
name: _clean_up [41489,41498]
===
match
---
atom_expr [17170,17246]
atom_expr [17170,17246]
===
match
---
trailer [19365,19378]
trailer [19365,19378]
===
match
---
name: super [66578,66583]
name: super [68294,68299]
===
match
---
operator: = [43569,43570]
operator: = [45285,45286]
===
match
---
atom_expr [66378,66398]
atom_expr [68094,68114]
===
match
---
atom_expr [20616,20680]
atom_expr [20616,20680]
===
match
---
name: dag [23697,23700]
name: dag [23697,23700]
===
match
---
trailer [33551,33557]
trailer [35267,35273]
===
match
---
trailer [29495,29502]
trailer [31211,31218]
===
match
---
string: "test_dag" [35724,35734]
string: "test_dag" [37440,37450]
===
match
---
name: dag_decorator [67007,67020]
name: dag_decorator [68723,68736]
===
match
---
atom_expr [29632,29652]
atom_expr [31348,31368]
===
match
---
expr_stmt [22661,22697]
expr_stmt [22661,22697]
===
match
---
name: DuplicateTaskIdFound [36885,36905]
name: DuplicateTaskIdFound [38601,38621]
===
match
---
trailer [14409,14419]
trailer [14409,14419]
===
match
---
arglist [69979,69994]
arglist [71695,71710]
===
match
---
name: merge [17458,17463]
name: merge [17458,17463]
===
match
---
name: merge [17539,17544]
name: merge [17539,17544]
===
match
---
string: "start_date" [66300,66312]
string: "start_date" [68016,68028]
===
match
---
name: test_dag_naive_start_end_dates_strings [10847,10885]
name: test_dag_naive_start_end_dates_strings [10847,10885]
===
match
---
simple_stmt [38562,38646]
simple_stmt [40278,40362]
===
match
---
simple_stmt [4404,4436]
simple_stmt [4404,4436]
===
match
---
atom [17820,17846]
atom [17820,17846]
===
match
---
operator: = [15471,15472]
operator: = [15471,15472]
===
match
---
name: clear_db_runs [2670,2683]
name: clear_db_runs [2670,2683]
===
match
---
simple_stmt [2852,2940]
simple_stmt [2852,2940]
===
match
---
trailer [2905,2912]
trailer [2905,2912]
===
match
---
name: now [57022,57025]
name: now [58738,58741]
===
match
---
trailer [25433,25439]
trailer [27149,27155]
===
match
---
trailer [24422,24426]
trailer [26138,26142]
===
match
---
name: self [59373,59377]
name: self [61089,61093]
===
match
---
name: default_view [33473,33485]
name: default_view [35189,35201]
===
match
---
name: remove [10201,10207]
name: remove [10201,10207]
===
match
---
trailer [49324,49327]
trailer [51040,51043]
===
match
---
trailer [16123,16130]
trailer [16123,16130]
===
match
---
name: DagModel [46245,46253]
name: DagModel [47961,47969]
===
match
---
operator: @ [67418,67419]
operator: @ [69134,69135]
===
match
---
name: dag [44082,44085]
name: dag [45798,45801]
===
match
---
operator: = [22564,22565]
operator: = [22564,22565]
===
match
---
funcdef [11891,12191]
funcdef [11891,12191]
===
match
---
trailer [49204,49211]
trailer [50920,50927]
===
match
---
atom_expr [25376,25399]
atom_expr [27092,27115]
===
match
---
atom_expr [43329,43346]
atom_expr [45045,45062]
===
match
---
trailer [41582,41584]
trailer [43298,43300]
===
match
---
operator: , [18213,18214]
operator: , [18213,18214]
===
match
---
name: dag [49991,49994]
name: dag [51707,51710]
===
match
---
trailer [3074,3101]
trailer [3074,3101]
===
match
---
name: self [10591,10595]
name: self [10591,10595]
===
match
---
testlist_comp [20135,20160]
testlist_comp [20135,20160]
===
match
---
name: session [26740,26747]
name: session [28456,28463]
===
match
---
assert_stmt [22941,22995]
assert_stmt [22941,22995]
===
match
---
simple_stmt [29722,29767]
simple_stmt [31438,31483]
===
match
---
operator: = [33881,33882]
operator: = [35597,35598]
===
match
---
trailer [70521,70540]
trailer [72237,72256]
===
match
---
arglist [43243,43304]
arglist [44959,45020]
===
match
---
name: dag [45708,45711]
name: dag [47424,47427]
===
match
---
name: dag_eq [45733,45739]
name: dag_eq [47449,47455]
===
match
---
operator: , [58886,58887]
operator: , [60602,60603]
===
match
---
operator: = [51739,51740]
operator: = [53455,53456]
===
match
---
name: schedule_interval [7387,7404]
name: schedule_interval [7387,7404]
===
match
---
name: start_date [48281,48291]
name: start_date [49997,50007]
===
match
---
testlist_comp [25997,26027]
testlist_comp [27713,27743]
===
match
---
simple_stmt [6303,6332]
simple_stmt [6303,6332]
===
match
---
name: hours [23679,23684]
name: hours [23679,23684]
===
match
---
name: query [51099,51104]
name: query [52815,52820]
===
match
---
import_name [804,813]
import_name [804,813]
===
match
---
name: dag [8718,8721]
name: dag [8718,8721]
===
match
---
decorated [51275,53218]
decorated [52991,54934]
===
match
---
param [18504,18508]
param [18504,18508]
===
match
---
name: self [70620,70624]
name: self [72336,72340]
===
match
---
trailer [23706,23746]
trailer [23706,23746]
===
match
---
atom_expr [22583,22616]
atom_expr [22583,22616]
===
match
---
name: topological_list [10208,10224]
name: topological_list [10208,10224]
===
match
---
operator: + [43408,43409]
operator: + [45124,45125]
===
match
---
name: dag [18672,18675]
name: dag [18672,18675]
===
match
---
name: dag [55957,55960]
name: dag [57673,57676]
===
match
---
name: dag [64799,64802]
name: dag [66515,66518]
===
match
---
suite [16411,16672]
suite [16411,16672]
===
match
---
arglist [31499,31540]
arglist [33215,33256]
===
match
---
name: execution_date [41423,41437]
name: execution_date [43139,43153]
===
match
---
arglist [41380,41519]
arglist [43096,43235]
===
match
---
trailer [20801,20803]
trailer [20801,20803]
===
match
---
number: 2018 [34896,34900]
number: 2018 [36612,36616]
===
match
---
simple_stmt [58353,58399]
simple_stmt [60069,60115]
===
match
---
arglist [54395,54398]
arglist [56111,56114]
===
match
---
name: op5 [35965,35968]
name: op5 [37681,37684]
===
match
---
expr_stmt [15349,15358]
expr_stmt [15349,15358]
===
match
---
trailer [66442,66454]
trailer [68158,68170]
===
match
---
trailer [51710,51772]
trailer [53426,53488]
===
match
---
name: utcnow [70283,70289]
name: utcnow [71999,72005]
===
match
---
trailer [17396,17404]
trailer [17396,17404]
===
match
---
sync_comp_for [53275,53331]
sync_comp_for [54991,55047]
===
match
---
dictorsetmaker [10662,10679]
dictorsetmaker [10662,10679]
===
match
---
atom [46623,46679]
atom [48339,48395]
===
match
---
operator: @ [53223,53224]
operator: @ [54939,54940]
===
match
---
argument [41464,41483]
argument [43180,43199]
===
match
---
decorated [3141,3502]
decorated [3141,3502]
===
match
---
name: _task_group [38837,38848]
name: _task_group [40553,40564]
===
match
---
name: State [43526,43531]
name: State [45242,45247]
===
match
---
atom_expr [58705,58924]
atom_expr [60421,60640]
===
match
---
operator: == [13168,13170]
operator: == [13168,13170]
===
match
---
operator: } [63229,63230]
operator: } [64945,64946]
===
match
---
name: op2 [38427,38430]
name: op2 [40143,40146]
===
match
---
name: query [53054,53059]
name: query [54770,54775]
===
match
---
name: create_dagrun [69267,69280]
name: create_dagrun [70983,70996]
===
match
---
atom_expr [31499,31539]
atom_expr [33215,33255]
===
match
---
name: dag [46892,46895]
name: dag [48608,48611]
===
match
---
atom_expr [63512,63586]
atom_expr [65228,65302]
===
match
---
dictorsetmaker [4213,4228]
dictorsetmaker [4213,4228]
===
match
---
operator: = [10243,10244]
operator: = [10243,10244]
===
match
---
trailer [40627,40643]
trailer [42343,42359]
===
match
---
atom_expr [64840,64858]
atom_expr [66556,66574]
===
match
---
name: models [1583,1589]
name: models [1583,1589]
===
match
---
dotted_name [1048,1061]
dotted_name [1048,1061]
===
match
---
name: session [65155,65162]
name: session [66871,66878]
===
match
---
string: 'new_nonexisting_dag' [32943,32964]
string: 'new_nonexisting_dag' [34659,34680]
===
match
---
simple_stmt [9195,9231]
simple_stmt [9195,9231]
===
match
---
param [70620,70624]
param [72336,72340]
===
match
---
name: op4 [9987,9990]
name: op4 [9987,9990]
===
match
---
trailer [66878,66886]
trailer [68594,68602]
===
match
---
operator: == [26341,26343]
operator: == [28057,28059]
===
match
---
simple_stmt [27546,27603]
simple_stmt [29262,29319]
===
match
---
atom [26244,26275]
atom [27960,27991]
===
match
---
argument [35847,35859]
argument [37563,37575]
===
match
---
trailer [30542,30544]
trailer [32258,32260]
===
match
---
number: 0 [15798,15799]
number: 0 [15798,15799]
===
match
---
atom_expr [40799,40810]
atom_expr [42515,42526]
===
match
---
name: dag_id [31927,31933]
name: dag_id [33643,33649]
===
match
---
name: operator [66529,66537]
name: operator [68245,68253]
===
match
---
name: dag_id [26763,26769]
name: dag_id [28479,28485]
===
match
---
name: RUNNING [53848,53855]
name: RUNNING [55564,55571]
===
match
---
trailer [18379,18387]
trailer [18379,18387]
===
match
---
name: test_following_previous_schedule_daily_dag_cest_to_cet [21256,21310]
name: test_following_previous_schedule_daily_dag_cest_to_cet [21256,21310]
===
match
---
atom_expr [67220,67235]
atom_expr [68936,68951]
===
match
---
argument [15408,15440]
argument [15408,15440]
===
match
---
atom_expr [51240,51252]
atom_expr [52956,52968]
===
match
---
trailer [52063,52076]
trailer [53779,53792]
===
match
---
name: resolve_template_files [20074,20096]
name: resolve_template_files [20074,20096]
===
match
---
testlist_comp [19382,19394]
testlist_comp [19382,19394]
===
match
---
assert_stmt [6235,6263]
assert_stmt [6235,6263]
===
match
---
simple_stmt [39087,39177]
simple_stmt [40803,40893]
===
match
---
operator: , [70370,70371]
operator: , [72086,72087]
===
match
---
name: dag2 [57775,57779]
name: dag2 [59491,59495]
===
match
---
comparison [39475,39495]
comparison [41191,41211]
===
match
---
operator: = [5938,5939]
operator: = [5938,5939]
===
match
---
operator: = [11626,11627]
operator: = [11626,11627]
===
match
---
string: 'creating_dag_in_cm' [6888,6908]
string: 'creating_dag_in_cm' [6888,6908]
===
match
---
operator: , [7628,7629]
operator: , [7628,7629]
===
match
---
name: dag [9622,9625]
name: dag [9622,9625]
===
match
---
name: is_paused [33285,33294]
name: is_paused [35001,35010]
===
match
---
name: stdout_lines [36702,36714]
name: stdout_lines [38418,38430]
===
match
---
atom_expr [31202,31330]
atom_expr [32918,33046]
===
match
---
name: include_subdags [52917,52932]
name: include_subdags [54633,54648]
===
match
---
trailer [38120,38130]
trailer [39836,39846]
===
match
---
for_stmt [15943,16085]
for_stmt [15943,16085]
===
match
---
comparison [22879,22932]
comparison [22879,22932]
===
match
---
atom_expr [16048,16084]
atom_expr [16048,16084]
===
match
---
simple_stmt [35392,35426]
simple_stmt [37108,37142]
===
match
---
comparison [17880,17972]
comparison [17880,17972]
===
match
---
name: query [30371,30376]
name: query [32087,32092]
===
match
---
name: local_tz [21127,21135]
name: local_tz [21127,21135]
===
match
---
atom_expr [48063,48076]
atom_expr [49779,49792]
===
match
---
name: DAG [17780,17783]
name: DAG [17780,17783]
===
match
---
operator: = [22626,22627]
operator: = [22626,22627]
===
match
---
name: test_dag_id [43861,43872]
name: test_dag_id [45577,45588]
===
match
---
argument [30075,30092]
argument [31791,31808]
===
match
---
with_item [15372,15448]
with_item [15372,15448]
===
match
---
atom_expr [43738,43752]
atom_expr [45454,45468]
===
match
---
atom_expr [39665,39678]
atom_expr [41381,41394]
===
match
---
atom_expr [44432,44467]
atom_expr [46148,46183]
===
match
---
name: _occur_before [3163,3176]
name: _occur_before [3163,3176]
===
match
---
number: 10 [15320,15322]
number: 10 [15320,15322]
===
match
---
trailer [33099,33105]
trailer [34815,34821]
===
match
---
name: DAG [66812,66815]
name: DAG [68528,68531]
===
match
---
operator: = [51848,51849]
operator: = [53564,53565]
===
match
---
name: DEFAULT_DATE [27491,27503]
name: DEFAULT_DATE [29207,29219]
===
match
---
name: op3 [56728,56731]
name: op3 [58444,58447]
===
match
---
name: tasks [9077,9082]
name: tasks [9077,9082]
===
match
---
atom_expr [47613,47623]
atom_expr [49329,49339]
===
match
---
name: priority_weight_total [13702,13723]
name: priority_weight_total [13702,13723]
===
match
---
atom_expr [3770,3780]
atom_expr [3770,3780]
===
match
---
arglist [17912,17971]
arglist [17912,17971]
===
match
---
name: DagRunType [70226,70236]
name: DagRunType [71942,71952]
===
match
---
trailer [50674,50682]
trailer [52390,52398]
===
match
---
name: return_num [68090,68100]
name: return_num [69806,69816]
===
match
---
trailer [27736,27746]
trailer [29452,29462]
===
match
---
atom_expr [36303,36330]
atom_expr [38019,38046]
===
match
---
string: 'test-dag' [19129,19139]
string: 'test-dag' [19129,19139]
===
match
---
name: SubDagOperator [62307,62321]
name: SubDagOperator [64023,64037]
===
match
---
operator: , [70409,70410]
operator: , [72125,72126]
===
match
---
name: dag_id [39064,39070]
name: dag_id [40780,40786]
===
match
---
operator: = [6108,6109]
operator: = [6108,6109]
===
match
---
decorated [39796,40842]
decorated [41512,42558]
===
match
---
trailer [6842,6857]
trailer [6842,6857]
===
match
---
name: remove [10423,10429]
name: remove [10423,10429]
===
match
---
number: 2038 [64301,64305]
number: 2038 [66017,66021]
===
match
---
trailer [64848,64856]
trailer [66564,66572]
===
match
---
atom_expr [51164,51177]
atom_expr [52880,52893]
===
match
---
string: 'DAG' [34945,34950]
string: 'DAG' [36661,36666]
===
match
---
simple_stmt [18748,18839]
simple_stmt [18748,18839]
===
match
---
atom_expr [29133,29148]
atom_expr [30849,30864]
===
match
---
atom [8932,8942]
atom [8932,8942]
===
match
---
simple_stmt [25294,25320]
simple_stmt [27010,27036]
===
match
---
expr_stmt [20689,20724]
expr_stmt [20689,20724]
===
match
---
parameters [66730,66732]
parameters [68446,68448]
===
match
---
operator: = [35067,35068]
operator: = [36783,36784]
===
match
---
simple_stmt [70430,70506]
simple_stmt [72146,72222]
===
match
---
trailer [49445,49450]
trailer [51161,51166]
===
match
---
operator: = [4316,4317]
operator: = [4316,4317]
===
match
---
name: fileloc [29740,29747]
name: fileloc [31456,31463]
===
match
---
string: "faketastic" [43251,43263]
string: "faketastic" [44967,44979]
===
match
---
trailer [32228,32234]
trailer [33944,33950]
===
match
---
name: task_instance_1 [52477,52492]
name: task_instance_1 [54193,54208]
===
match
---
trailer [41541,41552]
trailer [43257,43268]
===
match
---
operator: } [46174,46175]
operator: } [47890,47891]
===
match
---
operator: == [24829,24831]
operator: == [26545,26547]
===
match
---
operator: = [44024,44025]
operator: = [45740,45741]
===
match
---
operator: } [63240,63241]
operator: } [64956,64957]
===
match
---
comparison [30441,30473]
comparison [32157,32189]
===
match
---
atom_expr [54257,54283]
atom_expr [55973,55999]
===
match
---
operator: == [24320,24322]
operator: == [26036,26038]
===
match
---
import_as_names [1250,1266]
import_as_names [1250,1266]
===
match
---
name: model [42855,42860]
name: model [44571,44576]
===
match
---
operator: = [59154,59155]
operator: = [60870,60871]
===
match
---
name: start [20594,20599]
name: start [20594,20599]
===
match
---
operator: , [26910,26911]
operator: , [28626,28627]
===
match
---
name: session [33544,33551]
name: session [35260,35267]
===
match
---
param [48138,48151]
param [49854,49867]
===
match
---
trailer [50270,50284]
trailer [51986,52000]
===
match
---
atom [29596,29616]
atom [31312,31332]
===
match
---
name: next_dagrun [64977,64988]
name: next_dagrun [66693,66704]
===
match
---
name: dag_id [40170,40176]
name: dag_id [41886,41892]
===
match
---
operator: , [53358,53359]
operator: , [55074,55075]
===
match
---
trailer [17272,17279]
trailer [17272,17279]
===
match
---
operator: != [39478,39480]
operator: != [41194,41196]
===
match
---
trailer [17237,17245]
trailer [17237,17245]
===
match
---
simple_stmt [39748,39760]
simple_stmt [41464,41476]
===
match
---
comparison [55886,55902]
comparison [57602,57618]
===
match
---
operator: , [57194,57195]
operator: , [58910,58911]
===
match
---
operator: , [21628,21629]
operator: , [21628,21629]
===
match
---
arglist [35724,35759]
arglist [37440,37475]
===
match
---
expr_stmt [32193,32393]
expr_stmt [33909,34109]
===
match
---
trailer [6592,6607]
trailer [6592,6607]
===
match
---
atom_expr [10511,10530]
atom_expr [10511,10530]
===
match
---
name: dagrun_1 [48643,48651]
name: dagrun_1 [50359,50367]
===
match
---
param [70787,70803]
param [72503,72519]
===
match
---
dotted_name [2203,2215]
dotted_name [2203,2215]
===
match
---
argument [64795,64802]
argument [66511,66518]
===
match
---
name: dag_id [62394,62400]
name: dag_id [64110,64116]
===
match
---
operator: = [60812,60813]
operator: = [62528,62529]
===
match
---
operator: { [18630,18631]
operator: { [18630,18631]
===
match
---
arglist [44370,44400]
arglist [46086,46116]
===
match
---
expr_stmt [9819,9851]
expr_stmt [9819,9851]
===
match
---
name: mock_callback_with_exception [40030,40058]
name: mock_callback_with_exception [41746,41774]
===
match
---
arith_expr [57022,57058]
arith_expr [58738,58774]
===
match
---
simple_stmt [1715,1765]
simple_stmt [1715,1765]
===
match
---
name: prev [21235,21239]
name: prev [21235,21239]
===
match
---
trailer [31343,31354]
trailer [33059,33070]
===
match
---
name: topological_sort [10708,10724]
name: topological_sort [10708,10724]
===
match
---
name: current_task [14618,14630]
name: current_task [14618,14630]
===
match
---
trailer [59865,59877]
trailer [61581,61593]
===
match
---
number: 1 [64156,64157]
number: 1 [65872,65873]
===
match
---
operator: , [26275,26276]
operator: , [27991,27992]
===
match
---
name: split [36577,36582]
name: split [38293,38298]
===
match
---
operator: = [54811,54812]
operator: = [56527,56528]
===
match
---
arglist [53660,53684]
arglist [55376,55400]
===
match
---
expr_stmt [63250,63445]
expr_stmt [64966,65161]
===
match
---
expr_stmt [51644,51689]
expr_stmt [53360,53405]
===
match
---
trailer [34174,34185]
trailer [35890,35901]
===
match
---
arglist [29867,29944]
arglist [31583,31660]
===
match
---
testlist_comp [46437,46459]
testlist_comp [48153,48175]
===
match
---
trailer [26539,26556]
trailer [28255,28272]
===
match
---
name: default_args [11813,11825]
name: default_args [11813,11825]
===
match
---
trailer [36066,36078]
trailer [37782,37794]
===
match
---
assert_stmt [33270,33294]
assert_stmt [34986,35010]
===
match
---
string: "STORE_DAG_CODE" [2566,2582]
string: "STORE_DAG_CODE" [2566,2582]
===
match
---
simple_stmt [38473,38507]
simple_stmt [40189,40223]
===
match
---
operator: = [66685,66686]
operator: = [68401,68402]
===
match
---
operator: , [65945,65946]
operator: , [67661,67662]
===
match
---
name: timezone [1884,1892]
name: timezone [1884,1892]
===
match
---
name: DAG [51580,51583]
name: DAG [53296,53299]
===
match
---
arglist [49695,49745]
arglist [51411,51461]
===
match
---
argument [14223,14246]
argument [14223,14246]
===
match
---
name: i [15568,15569]
name: i [15568,15569]
===
match
---
fstring [12976,12991]
fstring [12976,12991]
===
match
---
dotted_name [1948,1969]
dotted_name [1948,1969]
===
match
---
name: stop [2740,2744]
name: stop [2740,2744]
===
match
---
operator: = [70916,70917]
operator: = [72632,72633]
===
match
---
name: one [53157,53160]
name: one [54873,54876]
===
match
---
atom_expr [13697,13723]
atom_expr [13697,13723]
===
match
---
name: test_dag_default_view_default_value [4805,4840]
name: test_dag_default_view_default_value [4805,4840]
===
match
---
simple_stmt [10290,10325]
simple_stmt [10290,10325]
===
match
---
simple_stmt [71058,71099]
simple_stmt [72774,72815]
===
match
---
name: RUNNING [18380,18387]
name: RUNNING [18380,18387]
===
match
---
string: """Test that @dag uses function name as default dag id.""" [67350,67408]
string: """Test that @dag uses function name as default dag id.""" [69066,69124]
===
match
---
atom_expr [68939,68956]
atom_expr [70655,70672]
===
match
---
trailer [64553,64555]
trailer [66269,66271]
===
match
---
name: session [51032,51039]
name: session [52748,52755]
===
match
---
name: pendulum [1083,1091]
name: pendulum [1083,1091]
===
match
---
operator: = [7520,7521]
operator: = [7520,7521]
===
match
---
name: DEFAULT_DATE [69528,69540]
name: DEFAULT_DATE [71244,71256]
===
match
---
funcdef [59305,60327]
funcdef [61021,62043]
===
match
---
trailer [46632,46642]
trailer [48348,48358]
===
match
---
simple_stmt [29985,30031]
simple_stmt [31701,31747]
===
match
---
trailer [38706,38710]
trailer [40422,40426]
===
match
---
name: states [18346,18352]
name: states [18346,18352]
===
match
---
simple_stmt [35781,35815]
simple_stmt [37497,37531]
===
match
---
atom_expr [11850,11885]
atom_expr [11850,11885]
===
match
---
name: DAG [38320,38323]
name: DAG [40036,40039]
===
match
---
operator: { [39624,39625]
operator: { [41340,41341]
===
match
---
name: schedule_interval [41189,41206]
name: schedule_interval [42905,42922]
===
match
---
operator: == [66887,66889]
operator: == [68603,68605]
===
match
---
atom_expr [45263,45280]
atom_expr [46979,46996]
===
match
---
atom_expr [39682,39695]
atom_expr [41398,41411]
===
match
---
operator: } [26339,26340]
operator: } [28055,28056]
===
match
---
fstring_string: stage [12978,12983]
fstring_string: stage [12978,12983]
===
match
---
argument [43553,43575]
argument [45269,45291]
===
match
---
atom_expr [6370,6398]
atom_expr [6370,6398]
===
match
---
name: datetime [12111,12119]
name: datetime [12111,12119]
===
match
---
operator: = [69161,69162]
operator: = [70877,70878]
===
match
---
name: clear_db_dags [2694,2707]
name: clear_db_dags [2694,2707]
===
match
---
string: 'test_rich_comparison_ops' [44156,44182]
string: 'test_rich_comparison_ops' [45872,45898]
===
match
---
trailer [35126,35131]
trailer [36842,36847]
===
match
---
operator: , [18229,18230]
operator: , [18229,18230]
===
match
---
name: dag [5065,5068]
name: dag [5065,5068]
===
match
---
name: permissions [63187,63198]
name: permissions [64903,64914]
===
match
---
trailer [23078,23085]
trailer [23078,23085]
===
match
---
operator: , [56360,56361]
operator: , [58076,58077]
===
match
---
argument [19882,19895]
argument [19882,19895]
===
match
---
argument [32688,32716]
argument [34404,34432]
===
match
---
name: test_field [19459,19469]
name: test_field [19459,19469]
===
match
---
param [70861,70864]
param [72577,72580]
===
match
---
atom [27751,27764]
atom [29467,29480]
===
match
---
name: used_group_ids [38849,38863]
name: used_group_ids [40565,40579]
===
match
---
trailer [7965,7985]
trailer [7965,7985]
===
match
---
name: external_trigger [39723,39739]
name: external_trigger [41439,41455]
===
match
---
name: num [68572,68575]
name: num [70288,70291]
===
match
---
operator: = [51012,51013]
operator: = [52728,52729]
===
match
---
suite [8722,8978]
suite [8722,8978]
===
match
---
string: 'airflow' [27592,27601]
string: 'airflow' [29308,29317]
===
match
---
trailer [19914,19925]
trailer [19914,19925]
===
match
---
expr_stmt [42186,42219]
expr_stmt [43902,43935]
===
match
---
operator: = [48844,48845]
operator: = [50560,50561]
===
match
---
simple_stmt [12346,12398]
simple_stmt [12346,12398]
===
match
---
name: dag [47432,47435]
name: dag [49148,49151]
===
match
---
name: dag_id [43815,43821]
name: dag_id [45531,45537]
===
match
---
name: models [4281,4287]
name: models [4281,4287]
===
match
---
expr_stmt [43177,43208]
expr_stmt [44893,44924]
===
match
---
name: DEFAULT_ARGS [66691,66703]
name: DEFAULT_ARGS [68407,68419]
===
match
---
trailer [41173,41238]
trailer [42889,42954]
===
match
---
atom_expr [40526,40539]
atom_expr [42242,42255]
===
match
---
name: self [61442,61446]
name: self [63158,63162]
===
match
---
name: run_type [28058,28066]
name: run_type [29774,29782]
===
match
---
simple_stmt [5995,6073]
simple_stmt [5995,6073]
===
match
---
import_from [949,988]
import_from [949,988]
===
match
---
trailer [11747,11761]
trailer [11747,11761]
===
match
---
trailer [32243,32250]
trailer [33959,33966]
===
match
---
simple_stmt [34701,34717]
simple_stmt [36417,36433]
===
match
---
operator: == [30410,30412]
operator: == [32126,32128]
===
match
---
name: DAG [58705,58708]
name: DAG [60421,60424]
===
match
---
operator: == [20485,20487]
operator: == [20485,20487]
===
match
---
operator: -> [65595,65597]
operator: -> [67311,67313]
===
match
---
atom_expr [52622,52635]
atom_expr [54338,54351]
===
match
---
name: run_type [53790,53798]
name: run_type [55506,55514]
===
match
---
operator: { [10661,10662]
operator: { [10661,10662]
===
match
---
string: """         Test `default_view` default value of DAG initialization         """ [4856,4935]
string: """         Test `default_view` default value of DAG initialization         """ [4856,4935]
===
match
---
name: e [3361,3362]
name: e [3361,3362]
===
match
---
atom_expr [39481,39495]
atom_expr [41197,41211]
===
match
---
name: return_num [69904,69914]
name: return_num [71620,71630]
===
match
---
name: topological_list [10037,10053]
name: topological_list [10037,10053]
===
match
---
operator: @ [67102,67103]
operator: @ [68818,68819]
===
match
---
parameters [21310,21316]
parameters [21310,21316]
===
match
---
string: 'dag_default_view' [29378,29396]
string: 'dag_default_view' [31094,31112]
===
match
---
name: session [18231,18238]
name: session [18231,18238]
===
match
---
import_as_name [1498,1516]
import_as_name [1498,1516]
===
match
---
operator: , [52393,52394]
operator: , [54109,54110]
===
match
---
trailer [70236,70243]
trailer [71952,71959]
===
match
---
name: default_args [56577,56589]
name: default_args [58293,58305]
===
match
---
assert_stmt [43627,43708]
assert_stmt [45343,45424]
===
match
---
atom_expr [27840,27857]
atom_expr [29556,29573]
===
match
---
trailer [29141,29148]
trailer [30857,30864]
===
match
---
operator: , [16927,16928]
operator: , [16927,16928]
===
match
---
name: default_args [68926,68938]
name: default_args [70642,70654]
===
match
---
name: prev [22948,22952]
name: prev [22948,22952]
===
match
---
string: 'dag-bulk-sync-2' [24791,24808]
string: 'dag-bulk-sync-2' [26507,26524]
===
match
---
trailer [26355,26361]
trailer [28071,28077]
===
match
---
name: os [19726,19728]
name: os [19726,19728]
===
match
---
simple_stmt [41059,41095]
simple_stmt [42775,42811]
===
match
---
trailer [14794,14801]
trailer [14794,14801]
===
match
---
atom_expr [54173,54323]
atom_expr [55889,56039]
===
match
---
operator: + [54255,54256]
operator: + [55971,55972]
===
match
---
trailer [29397,29403]
trailer [31113,31119]
===
match
---
atom_expr [41389,41409]
atom_expr [43105,43125]
===
match
---
name: DagRunType [39236,39246]
name: DagRunType [40952,40962]
===
match
---
atom_expr [31169,31185]
atom_expr [32885,32901]
===
match
---
name: state [39308,39313]
name: state [41024,41029]
===
match
---
operator: = [16231,16232]
operator: = [16231,16232]
===
match
---
name: op5 [6722,6725]
name: op5 [6722,6725]
===
match
---
trailer [33717,33721]
trailer [35433,35437]
===
match
---
operator: @ [69872,69873]
operator: @ [71588,71589]
===
match
---
atom_expr [41470,41483]
atom_expr [43186,43199]
===
match
---
name: self [39870,39874]
name: self [41586,41590]
===
match
---
atom_expr [48398,48416]
atom_expr [50114,50132]
===
match
---
operator: = [7128,7129]
operator: = [7128,7129]
===
match
---
argument [54233,54283]
argument [55949,55999]
===
match
---
trailer [36270,36284]
trailer [37986,38000]
===
match
---
simple_stmt [65612,65628]
simple_stmt [67328,67344]
===
match
---
name: run_type [48467,48475]
name: run_type [50183,50191]
===
match
---
atom_expr [19674,19697]
atom_expr [19674,19697]
===
match
---
simple_stmt [12150,12191]
simple_stmt [12150,12191]
===
match
---
suite [2462,2629]
suite [2462,2629]
===
match
---
simple_stmt [30529,30545]
simple_stmt [32245,32261]
===
match
---
simple_stmt [52445,52469]
simple_stmt [54161,54185]
===
match
---
operator: } [44296,44297]
operator: } [46012,46013]
===
match
---
name: update [4420,4426]
name: update [4420,4426]
===
match
---
string: 'stage(\\d*).(\\d*)' [12583,12603]
string: 'stage(\\d*).(\\d*)' [12583,12603]
===
match
---
name: noop_pipeline [68119,68132]
name: noop_pipeline [69835,69848]
===
match
---
string: 'dag-bulk-sync-2' [26146,26163]
string: 'dag-bulk-sync-2' [27862,27879]
===
match
---
argument [18346,18388]
argument [18346,18388]
===
match
---
operator: , [48686,48687]
operator: , [50402,50403]
===
match
---
name: dag_subclass [45167,45179]
name: dag_subclass [46883,46895]
===
match
---
name: DummyOperator [51850,51863]
name: DummyOperator [53566,53579]
===
match
---
string: 'owner1' [5976,5984]
string: 'owner1' [5976,5984]
===
match
---
atom_expr [33014,33032]
atom_expr [34730,34748]
===
match
---
operator: == [3371,3373]
operator: == [3371,3373]
===
match
---
atom_expr [17094,17120]
atom_expr [17094,17120]
===
match
---
atom_expr [33713,33762]
atom_expr [35429,35478]
===
match
---
shift_expr [38519,38529]
shift_expr [40235,40245]
===
match
---
atom_expr [12157,12169]
atom_expr [12157,12169]
===
match
---
name: state [52297,52302]
name: state [54013,54018]
===
match
---
name: unpaused_dags [31680,31693]
name: unpaused_dags [33396,33409]
===
match
---
name: dag [43963,43966]
name: dag [45679,45682]
===
match
---
simple_stmt [37943,37983]
simple_stmt [39659,39699]
===
match
---
atom_expr [33575,33590]
atom_expr [35291,35306]
===
match
---
name: schedule_interval [59693,59710]
name: schedule_interval [61409,61426]
===
match
---
suite [24651,24691]
suite [26367,26407]
===
match
---
operator: == [47249,47251]
operator: == [48965,48967]
===
match
---
trailer [61000,61018]
trailer [62716,62734]
===
match
---
atom_expr [34335,34350]
atom_expr [36051,36066]
===
match
---
string: """         Test `orientation` default value of DAG initialization         """ [5451,5529]
string: """         Test `orientation` default value of DAG initialization         """ [5451,5529]
===
match
---
arglist [60759,60780]
arglist [62475,62496]
===
match
---
name: DummyOperator [48339,48352]
name: DummyOperator [50055,50068]
===
match
---
operator: = [35854,35855]
operator: = [37570,37571]
===
match
---
name: op9 [7101,7104]
name: op9 [7101,7104]
===
match
---
operator: = [8829,8830]
operator: = [8829,8830]
===
match
---
trailer [52420,52426]
trailer [54136,54142]
===
match
---
operator: , [6037,6038]
operator: , [6037,6038]
===
match
---
comparison [47640,47672]
comparison [49356,49388]
===
match
---
name: isoformat [21177,21186]
name: isoformat [21177,21186]
===
match
---
name: DagModel [31918,31926]
name: DagModel [33634,33642]
===
match
---
operator: , [44447,44448]
operator: , [46163,46164]
===
match
---
operator: = [63723,63724]
operator: = [65439,65440]
===
match
---
operator: , [15623,15624]
operator: , [15623,15624]
===
match
---
operator: { [38134,38135]
operator: { [39850,39851]
===
match
---
name: prev_task [13270,13279]
name: prev_task [13270,13279]
===
match
---
operator: , [29943,29944]
operator: , [31659,31660]
===
match
---
operator: = [66047,66048]
operator: = [67763,67764]
===
match
---
atom_expr [27649,27660]
atom_expr [29365,29376]
===
match
---
atom_expr [33639,33659]
atom_expr [35355,35375]
===
match
---
operator: = [58061,58062]
operator: = [59777,59778]
===
match
---
operator: } [4335,4336]
operator: } [4335,4336]
===
match
---
name: template_dir [19830,19842]
name: template_dir [19830,19842]
===
match
---
trailer [58816,58825]
trailer [60532,60541]
===
match
---
name: next_date [59952,59961]
name: next_date [61668,61677]
===
match
---
operator: = [12531,12532]
operator: = [12531,12532]
===
match
---
operator: = [28997,28998]
operator: = [30713,30714]
===
match
---
name: DagRun [49198,49204]
name: DagRun [50914,50920]
===
match
---
expr_stmt [21070,21105]
expr_stmt [21070,21105]
===
match
---
string: 'Also fake' [43271,43282]
string: 'Also fake' [44987,44998]
===
match
---
operator: = [49914,49915]
operator: = [51630,51631]
===
match
---
operator: , [4302,4303]
operator: , [4302,4303]
===
match
---
trailer [4388,4393]
trailer [4388,4393]
===
match
---
name: op3 [38473,38476]
name: op3 [40189,40192]
===
match
---
expr_stmt [6526,6560]
expr_stmt [6526,6560]
===
match
---
simple_stmt [10087,10118]
simple_stmt [10087,10118]
===
match
---
string: "2018-10-27T01:00:00+00:00" [22317,22344]
string: "2018-10-27T01:00:00+00:00" [22317,22344]
===
match
---
operator: = [62382,62383]
operator: = [64098,64099]
===
match
---
trailer [64885,65117]
trailer [66601,66833]
===
match
---
atom_expr [4281,4353]
atom_expr [4281,4353]
===
match
---
simple_stmt [32599,32616]
simple_stmt [34315,34332]
===
match
---
operator: + [13646,13647]
operator: + [13646,13647]
===
match
---
name: op2 [7874,7877]
name: op2 [7874,7877]
===
match
---
expr_stmt [39000,39045]
expr_stmt [40716,40761]
===
match
---
atom_expr [33683,33709]
atom_expr [35399,35425]
===
match
---
operator: == [24040,24042]
operator: == [24040,24042]
===
match
---
suite [62282,62462]
suite [63998,64178]
===
match
---
name: dag_id [47376,47382]
name: dag_id [49092,49098]
===
match
---
trailer [27146,27150]
trailer [28862,28866]
===
match
---
testlist_comp [46374,46384]
testlist_comp [48090,48100]
===
match
---
name: NONE [47218,47222]
name: NONE [48934,48938]
===
match
---
operator: , [55621,55622]
operator: , [57337,57338]
===
match
---
atom_expr [53263,53273]
atom_expr [54979,54989]
===
match
---
string: 'old_existing_dag' [33842,33860]
string: 'old_existing_dag' [35558,35576]
===
match
---
suite [65772,66168]
suite [67488,67884]
===
match
---
operator: , [46446,46447]
operator: , [48162,48163]
===
match
---
operator: , [26127,26128]
operator: , [27843,27844]
===
match
---
operator: , [63089,63090]
operator: , [64805,64806]
===
match
---
trailer [30419,30423]
trailer [32135,32139]
===
match
---
for_stmt [15834,16085]
for_stmt [15834,16085]
===
match
---
operator: = [41206,41207]
operator: = [42922,42923]
===
match
---
name: state [52090,52095]
name: state [53806,53811]
===
match
---
name: self [15222,15226]
name: self [15222,15226]
===
match
---
trailer [10337,10344]
trailer [10337,10344]
===
match
---
name: RUNNING [17397,17404]
name: RUNNING [17397,17404]
===
match
---
name: self [33359,33363]
name: self [35075,35079]
===
match
---
name: group [13501,13506]
name: group [13501,13506]
===
match
---
operator: = [40330,40331]
operator: = [42046,42047]
===
match
---
name: dag2 [6346,6350]
name: dag2 [6346,6350]
===
match
---
atom_expr [23062,23085]
atom_expr [23062,23085]
===
match
---
name: DummyOperator [38433,38446]
name: DummyOperator [40149,40162]
===
match
---
expr_stmt [54748,54878]
expr_stmt [56464,56594]
===
match
---
number: 5 [12552,12553]
number: 5 [12552,12553]
===
match
---
simple_stmt [32664,32718]
simple_stmt [34380,34434]
===
match
---
name: op5 [6573,6576]
name: op5 [6573,6576]
===
match
---
name: dag [60922,60925]
name: dag [62638,62641]
===
match
---
number: 5 [12533,12534]
number: 5 [12533,12534]
===
match
---
trailer [38575,38590]
trailer [40291,40306]
===
match
---
name: state [51247,51252]
name: state [52963,52968]
===
match
---
name: start_date [64993,65003]
name: start_date [66709,66719]
===
match
---
operator: , [42835,42836]
operator: , [44551,44552]
===
match
---
trailer [32381,32383]
trailer [34097,34099]
===
match
---
atom_expr [21166,21188]
atom_expr [21166,21188]
===
match
---
argument [58055,58088]
argument [59771,59804]
===
match
---
fstring [24525,24545]
fstring [26241,26261]
===
match
---
expr_stmt [55422,55466]
expr_stmt [57138,57182]
===
match
---
simple_stmt [45160,45187]
simple_stmt [46876,46903]
===
match
---
operator: , [52973,52974]
operator: , [54689,54690]
===
match
---
name: pickle [44065,44071]
name: pickle [45781,45787]
===
match
---
param [63000,63004]
param [64716,64720]
===
match
---
name: state [53836,53841]
name: state [55552,55557]
===
match
---
operator: = [28615,28616]
operator: = [30331,30332]
===
match
---
simple_stmt [59388,59534]
simple_stmt [61104,61250]
===
match
---
name: utcnow [66323,66329]
name: utcnow [68039,68045]
===
match
---
assert_stmt [19447,19483]
assert_stmt [19447,19483]
===
match
---
name: test_task_id [18331,18343]
name: test_task_id [18331,18343]
===
match
---
operator: = [58703,58704]
operator: = [60419,60420]
===
match
---
fstring_expr [24541,24544]
fstring_expr [26257,26260]
===
match
---
string: '@once' [58120,58127]
string: '@once' [59836,59843]
===
match
---
name: dag_models [65336,65346]
name: dag_models [67052,67062]
===
match
---
expr_stmt [48263,48324]
expr_stmt [49979,50040]
===
match
---
atom_expr [27047,27060]
atom_expr [28763,28776]
===
match
---
name: session [17531,17538]
name: session [17531,17538]
===
match
---
operator: , [26113,26114]
operator: , [27829,27830]
===
match
---
name: session [17956,17963]
name: session [17956,17963]
===
match
---
trailer [10361,10364]
trailer [10361,10364]
===
match
---
name: next_date [58994,59003]
name: next_date [60710,60719]
===
match
---
operator: * [15017,15018]
operator: * [15017,15018]
===
match
---
operator: < [45412,45413]
operator: < [47128,47129]
===
match
---
comparison [57987,58016]
comparison [59703,59732]
===
match
---
name: datetime_tz [2094,2105]
name: datetime_tz [2094,2105]
===
match
---
name: op1 [38148,38151]
name: op1 [39864,39867]
===
match
---
simple_stmt [36515,36542]
simple_stmt [38231,38258]
===
match
---
arith_expr [62010,62015]
arith_expr [63726,63731]
===
match
---
name: timezone [62744,62752]
name: timezone [64460,64468]
===
match
---
string: 'subtask' [28964,28973]
string: 'subtask' [30680,30689]
===
match
---
operator: = [37429,37430]
operator: = [39145,39146]
===
match
---
argument [62019,62033]
argument [63735,63749]
===
match
---
trailer [21802,21804]
trailer [21802,21804]
===
match
---
expr_stmt [35873,35906]
expr_stmt [37589,37622]
===
match
---
operator: == [17777,17779]
operator: == [17777,17779]
===
match
---
operator: = [50427,50428]
operator: = [52143,52144]
===
match
---
decorator [39796,39831]
decorator [41512,41547]
===
match
---
expr_stmt [7101,7135]
expr_stmt [7101,7135]
===
match
---
argument [70351,70370]
argument [72067,72086]
===
match
---
number: 0 [26726,26727]
number: 0 [28442,28443]
===
match
---
name: next_local [23102,23112]
name: next_local [23102,23112]
===
match
---
name: self [35152,35156]
name: self [36868,36872]
===
match
---
trailer [35047,35081]
trailer [36763,36797]
===
match
---
assert_stmt [44978,44998]
assert_stmt [46694,46714]
===
match
---
string: 'op8' [7086,7091]
string: 'op8' [7086,7091]
===
match
---
operator: , [25761,25762]
operator: , [27477,27478]
===
match
---
arglist [16961,17004]
arglist [16961,17004]
===
match
---
name: start_date [62140,62150]
name: start_date [63856,63866]
===
match
---
expr_stmt [7874,7933]
expr_stmt [7874,7933]
===
match
---
name: dag [37025,37028]
name: dag [38741,38744]
===
match
---
operator: , [14351,14352]
operator: , [14351,14352]
===
match
---
atom_expr [14404,14419]
atom_expr [14404,14419]
===
match
---
name: dag_id [25882,25888]
name: dag_id [27598,27604]
===
match
---
name: is_paused [32261,32270]
name: is_paused [33977,33986]
===
match
---
simple_stmt [23697,23747]
simple_stmt [23697,23747]
===
match
---
simple_stmt [6439,6468]
simple_stmt [6439,6468]
===
match
---
name: prev_local [21782,21792]
name: prev_local [21782,21792]
===
match
---
atom [17948,17954]
atom [17948,17954]
===
match
---
arglist [52498,52551]
arglist [54214,54267]
===
match
---
trailer [23257,23264]
trailer [23257,23264]
===
match
---
testlist_comp [24196,24212]
testlist_comp [25912,25928]
===
match
---
dictorsetmaker [4318,4335]
dictorsetmaker [4318,4335]
===
match
---
dictorsetmaker [12884,12901]
dictorsetmaker [12884,12901]
===
match
---
simple_stmt [6829,6858]
simple_stmt [6829,6858]
===
match
---
operator: = [49850,49851]
operator: = [51566,51567]
===
match
---
number: 1 [13296,13297]
number: 1 [13296,13297]
===
match
---
atom_expr [62808,62843]
atom_expr [64524,64559]
===
match
---
parameters [20203,20209]
parameters [20203,20209]
===
match
---
operator: = [55608,55609]
operator: = [57324,57325]
===
match
---
name: dag_id [46281,46287]
name: dag_id [47997,48003]
===
match
---
funcdef [13788,15162]
funcdef [13788,15162]
===
match
---
name: task_id [53547,53554]
name: task_id [55263,55270]
===
match
---
name: task_instances [54333,54347]
name: task_instances [56049,56063]
===
match
---
parameters [68985,69003]
parameters [70701,70719]
===
match
---
operator: = [27567,27568]
operator: = [29283,29284]
===
match
---
suite [30966,31027]
suite [32682,32743]
===
match
---
comparison [28143,28157]
comparison [29859,29873]
===
match
---
name: DEFAULT_DATE [24176,24188]
name: DEFAULT_DATE [25892,25904]
===
match
---
atom_expr [28211,28253]
atom_expr [29927,29969]
===
match
---
name: task_id [9659,9666]
name: task_id [9659,9666]
===
match
---
comparison [31600,31694]
comparison [33316,33410]
===
match
---
trailer [29579,29585]
trailer [31295,31301]
===
match
---
name: setUp [66508,66513]
name: setUp [68224,68229]
===
match
---
trailer [9244,9251]
trailer [9244,9251]
===
match
---
string: "2018-10-27T03:00:00+02:00" [22254,22281]
string: "2018-10-27T03:00:00+02:00" [22254,22281]
===
match
---
operator: == [5062,5064]
operator: == [5062,5064]
===
match
---
string: "@daily" [46400,46408]
string: "@daily" [48116,48124]
===
match
---
operator: = [23613,23614]
operator: = [23613,23614]
===
match
---
name: model [41609,41614]
name: model [43325,43330]
===
match
---
string: "test_dagrun_query_count" [66048,66073]
string: "test_dagrun_query_count" [67764,67789]
===
match
---
name: freeze_time [58405,58416]
name: freeze_time [60121,60132]
===
match
---
argument [8800,8811]
argument [8800,8811]
===
match
---
number: 1 [62771,62772]
number: 1 [64487,64488]
===
match
---
atom_expr [58033,58215]
atom_expr [59749,59931]
===
match
---
expr_stmt [64039,64067]
expr_stmt [65755,65783]
===
match
---
trailer [6215,6219]
trailer [6215,6219]
===
match
---
name: create_session [33380,33394]
name: create_session [35096,35110]
===
match
---
name: DeprecationWarning [63473,63491]
name: DeprecationWarning [65189,65207]
===
match
---
trailer [23999,24006]
trailer [23999,24006]
===
match
---
name: add_task [39091,39099]
name: add_task [40807,40815]
===
match
---
name: state [47607,47612]
name: state [49323,49328]
===
match
---
atom_expr [20069,20098]
atom_expr [20069,20098]
===
match
---
expr_stmt [2356,2397]
expr_stmt [2356,2397]
===
match
---
operator: , [51679,51680]
operator: , [53395,53396]
===
match
---
operator: , [15381,15382]
operator: , [15381,15382]
===
match
---
name: assert_queries_count [25453,25473]
name: assert_queries_count [27169,27189]
===
match
---
name: DummyOperator [6579,6592]
name: DummyOperator [6579,6592]
===
match
---
operator: = [70458,70459]
operator: = [72174,72175]
===
match
---
trailer [71075,71084]
trailer [72791,72800]
===
match
---
operator: = [42244,42245]
operator: = [43960,43961]
===
match
---
simple_stmt [19971,20010]
simple_stmt [19971,20010]
===
match
---
atom_expr [25655,25681]
atom_expr [27371,27397]
===
match
---
atom_expr [20310,20344]
atom_expr [20310,20344]
===
match
---
argument [7387,7413]
argument [7387,7413]
===
match
---
string: """         Tests that a start_date string with a timezone and an end_date string without a timezone         are accepted and that the timezone from the start carries over the end          This test is a little indirect, it works by setting start and end equal except for the         timezone and then testing for equality after the DAG construction.  They'll be equal         only if the same timezone was applied to both.          An explicit check the `tzinfo` attributes for both are the same is an extra check.         """ [11048,11575]
string: """         Tests that a start_date string with a timezone and an end_date string without a timezone         are accepted and that the timezone from the start carries over the end          This test is a little indirect, it works by setting start and end equal except for the         timezone and then testing for equality after the DAG construction.  They'll be equal         only if the same timezone was applied to both.          An explicit check the `tzinfo` attributes for both are the same is an extra check.         """ [11048,11575]
===
match
---
sync_comp_for [24591,24611]
sync_comp_for [26307,26327]
===
match
---
suite [65879,65956]
suite [67595,67672]
===
match
---
number: 2020 [59288,59292]
number: 2020 [61004,61008]
===
match
---
simple_stmt [7011,7046]
simple_stmt [7011,7046]
===
match
---
name: a_index [3484,3491]
name: a_index [3484,3491]
===
match
---
simple_stmt [6648,6670]
simple_stmt [6648,6670]
===
match
---
operator: != [45836,45838]
operator: != [47552,47554]
===
match
---
trailer [8120,8134]
trailer [8120,8134]
===
match
---
atom_expr [19971,19991]
atom_expr [19971,19991]
===
match
---
name: execution_date [17313,17327]
name: execution_date [17313,17327]
===
match
---
operator: , [8448,8449]
operator: , [8448,8449]
===
match
---
operator: != [45789,45791]
operator: != [47505,47507]
===
match
---
name: DummyOperator [49761,49774]
name: DummyOperator [51477,51490]
===
match
---
atom_expr [49761,49800]
atom_expr [51477,51516]
===
match
---
dictorsetmaker [63286,63435]
dictorsetmaker [65002,65151]
===
match
---
trailer [10313,10316]
trailer [10313,10316]
===
match
---
name: Session [64058,64065]
name: Session [65774,65781]
===
match
---
atom_expr [48785,48801]
atom_expr [50501,50517]
===
match
---
name: TI [54450,54452]
name: TI [56166,56168]
===
match
---
trailer [2979,2986]
trailer [2979,2986]
===
match
---
number: 2 [22614,22615]
number: 2 [22614,22615]
===
match
---
atom_expr [21007,21029]
atom_expr [21007,21029]
===
match
---
trailer [12181,12190]
trailer [12181,12190]
===
match
---
name: dag [28577,28580]
name: dag [30293,30296]
===
match
---
name: dumps [45270,45275]
name: dumps [46986,46991]
===
match
---
atom [51306,51374]
atom [53022,53090]
===
match
---
operator: , [62883,62884]
operator: , [64599,64600]
===
match
---
argument [30994,31010]
argument [32710,32726]
===
match
---
atom_expr [29850,29954]
atom_expr [31566,31670]
===
match
---
simple_stmt [14589,14598]
simple_stmt [14589,14598]
===
match
---
name: parameterized [65634,65647]
name: parameterized [67350,67363]
===
match
---
expr_stmt [10238,10255]
expr_stmt [10238,10255]
===
match
---
atom [24577,24589]
atom [26293,26305]
===
match
---
atom [17727,17741]
atom [17727,17741]
===
match
---
atom_expr [23862,23895]
atom_expr [23862,23895]
===
match
---
simple_stmt [2670,2686]
simple_stmt [2670,2686]
===
match
---
name: op3 [38153,38156]
name: op3 [39869,39872]
===
match
---
arglist [27432,27503]
arglist [29148,29219]
===
match
---
trailer [64118,64125]
trailer [65834,65841]
===
match
---
trailer [66583,66585]
trailer [68299,68301]
===
match
---
name: state [54638,54643]
name: state [56354,56359]
===
match
---
number: 2020 [59668,59672]
number: 2020 [61384,61388]
===
match
---
assert_stmt [49352,49388]
assert_stmt [51068,51104]
===
match
---
string: """Verify if dag.roots returns the root tasks of a DAG.""" [35167,35225]
string: """Verify if dag.roots returns the root tasks of a DAG.""" [36883,36941]
===
match
---
name: airflow [1627,1634]
name: airflow [1627,1634]
===
match
---
name: DagModel [27120,27128]
name: DagModel [28836,28844]
===
match
---
simple_stmt [12083,12142]
simple_stmt [12083,12142]
===
match
---
atom_expr [17045,17121]
atom_expr [17045,17121]
===
match
---
classdef [65480,66168]
classdef [67196,67884]
===
match
---
trailer [51104,51143]
trailer [52820,52859]
===
match
---
name: orm_dag [29284,29291]
name: orm_dag [31000,31007]
===
match
---
simple_stmt [31381,31584]
simple_stmt [33097,33300]
===
match
---
simple_stmt [49662,49677]
simple_stmt [51378,51393]
===
match
---
name: utc [21243,21246]
name: utc [21243,21246]
===
match
---
name: weight [16233,16239]
name: weight [16233,16239]
===
match
---
operator: { [43906,43907]
operator: { [45622,45623]
===
match
---
comparison [45817,45848]
comparison [47533,47564]
===
match
---
operator: + [55393,55394]
operator: + [57109,57110]
===
match
---
name: start_date [56492,56502]
name: start_date [58208,58218]
===
match
---
argument [47177,47204]
argument [48893,48920]
===
match
---
trailer [18961,18967]
trailer [18961,18967]
===
match
---
argument [45958,45986]
argument [47674,47702]
===
match
---
operator: = [64047,64048]
operator: = [65763,65764]
===
match
---
trailer [9251,9272]
trailer [9251,9272]
===
match
---
name: dag_decorator [69767,69780]
name: dag_decorator [71483,71496]
===
match
---
expr_stmt [19659,19697]
expr_stmt [19659,19697]
===
match
---
trailer [18772,18781]
trailer [18772,18781]
===
match
---
operator: = [63994,63995]
operator: = [65710,65711]
===
match
---
name: self [11033,11037]
name: self [11033,11037]
===
match
---
trailer [33621,33623]
trailer [35337,35339]
===
match
---
name: dag [38572,38575]
name: dag [40288,40291]
===
match
---
name: subdag [62808,62814]
name: subdag [64524,64530]
===
match
---
name: DAG [34941,34944]
name: DAG [36657,36660]
===
match
---
atom_expr [51850,51891]
atom_expr [53566,53607]
===
match
---
name: xcom_pass_to_op [69231,69246]
name: xcom_pass_to_op [70947,70962]
===
match
---
atom_expr [6532,6560]
atom_expr [6532,6560]
===
match
---
name: return_num [67191,67201]
name: return_num [68907,68917]
===
match
---
parameters [32917,32923]
parameters [34633,34639]
===
match
---
comparison [62859,62883]
comparison [64575,64599]
===
match
---
comparison [6242,6263]
comparison [6242,6263]
===
match
---
operator: , [5926,5927]
operator: , [5926,5927]
===
match
---
operator: , [32431,32432]
operator: , [34147,34148]
===
match
---
trailer [21593,21600]
trailer [21593,21600]
===
match
---
operator: = [27786,27787]
operator: = [29502,29503]
===
match
---
expr_stmt [28203,28253]
expr_stmt [29919,29969]
===
match
---
name: airflow [1720,1727]
name: airflow [1720,1727]
===
match
---
simple_stmt [5135,5208]
simple_stmt [5135,5208]
===
match
---
atom_expr [49198,49211]
atom_expr [50914,50927]
===
match
---
simple_stmt [10153,10188]
simple_stmt [10153,10188]
===
match
---
name: DEFAULT_DATE [6025,6037]
name: DEFAULT_DATE [6025,6037]
===
match
---
arglist [30893,30937]
arglist [32609,32653]
===
match
---
trailer [23767,23844]
trailer [23767,23844]
===
match
---
operator: = [22187,22188]
operator: = [22187,22188]
===
match
---
operator: , [17939,17940]
operator: , [17939,17940]
===
match
---
atom_expr [25841,25847]
atom_expr [27557,27563]
===
match
---
name: next_dagrun_create_after [28414,28438]
name: next_dagrun_create_after [30130,30154]
===
match
---
param [65589,65593]
param [67305,67309]
===
match
---
atom_expr [59848,59877]
atom_expr [61564,61593]
===
match
---
operator: , [12098,12099]
operator: , [12098,12099]
===
match
---
name: add_task [23759,23767]
name: add_task [23759,23767]
===
match
---
name: session [42767,42774]
name: session [44483,44490]
===
match
---
trailer [29511,29518]
trailer [31227,31234]
===
match
---
name: state [2028,2033]
name: state [2028,2033]
===
match
---
argument [30015,30029]
argument [31731,31745]
===
match
---
parameters [69914,69919]
parameters [71630,71635]
===
match
---
operator: = [55011,55012]
operator: = [56727,56728]
===
match
---
simple_stmt [34935,34979]
simple_stmt [36651,36695]
===
match
---
name: merge [50468,50473]
name: merge [52184,52189]
===
match
---
argument [42383,42403]
argument [44099,44119]
===
match
---
string: "t3" [36371,36375]
string: "t3" [38087,38091]
===
match
---
trailer [9986,9991]
trailer [9986,9991]
===
match
---
atom_expr [7952,7985]
atom_expr [7952,7985]
===
match
---
operator: { [26704,26705]
operator: { [28420,28421]
===
match
---
name: sync_to_db [34175,34185]
name: sync_to_db [35891,35901]
===
match
---
simple_stmt [40913,41051]
simple_stmt [42629,42767]
===
match
---
number: 0 [56968,56969]
number: 0 [58684,58685]
===
match
---
operator: , [5951,5952]
operator: , [5951,5952]
===
match
---
operator: , [44745,44746]
operator: , [46461,46462]
===
match
---
arglist [34945,34977]
arglist [36661,36693]
===
match
---
arglist [66041,66153]
arglist [67757,67869]
===
match
---
trailer [67261,67271]
trailer [68977,68987]
===
match
---
operator: , [18328,18329]
operator: , [18328,18329]
===
match
---
simple_stmt [59828,59878]
simple_stmt [61544,61594]
===
match
---
atom_expr [5065,5081]
atom_expr [5065,5081]
===
match
---
name: ti1 [17014,17017]
name: ti1 [17014,17017]
===
match
---
name: incr [40739,40743]
name: incr [42455,42459]
===
match
---
trailer [31215,31225]
trailer [32931,32941]
===
match
---
param [55137,55141]
param [56853,56857]
===
match
---
string: 'child_dag' [7903,7914]
string: 'child_dag' [7903,7914]
===
match
---
name: timezone [61112,61120]
name: timezone [62828,62836]
===
match
---
name: DEFAULT_DATE [36217,36229]
name: DEFAULT_DATE [37933,37945]
===
match
---
trailer [25198,25202]
trailer [26914,26918]
===
match
---
suite [4712,4796]
suite [4712,4796]
===
match
---
operator: = [34939,34940]
operator: = [36655,36656]
===
match
---
name: dag_id [33584,33590]
name: dag_id [35300,35306]
===
match
---
name: following_schedule [23981,23999]
name: following_schedule [23981,23999]
===
match
---
suite [22415,23442]
suite [22415,23442]
===
match
---
name: dag [58946,58949]
name: dag [60662,60665]
===
match
---
trailer [40114,40126]
trailer [41830,41842]
===
match
---
operator: = [7062,7063]
operator: = [7062,7063]
===
match
---
operator: == [17593,17595]
operator: == [17593,17595]
===
match
---
name: run [43738,43741]
name: run [45454,45457]
===
match
---
operator: , [15799,15800]
operator: , [15799,15800]
===
match
---
string: """         Test that when 'params' exists as a key passed to the default_args dict         in addition to params being passed explicitly as an argument to the         dag, that the 'params' key of the default_args dict is merged with the         dict of the params argument.         """ [3906,4193]
string: """         Test that when 'params' exists as a key passed to the default_args dict         in addition to params being passed explicitly as an argument to the         dag, that the 'params' key of the default_args dict is merged with the         dict of the params argument.         """ [3906,4193]
===
match
---
operator: , [34131,34132]
operator: , [35847,35848]
===
match
---
trailer [39670,39678]
trailer [41386,41394]
===
match
---
simple_stmt [20353,20452]
simple_stmt [20353,20452]
===
match
---
name: State [50585,50590]
name: State [52301,52306]
===
match
---
name: dag [39748,39751]
name: dag [41464,41467]
===
match
---
assert_stmt [17873,17972]
assert_stmt [17873,17972]
===
match
---
name: conf [5605,5609]
name: conf [5605,5609]
===
match
---
expr_stmt [30275,30303]
expr_stmt [31991,32019]
===
match
---
name: dag_id [23707,23713]
name: dag_id [23707,23713]
===
match
---
name: child_dag [7476,7485]
name: child_dag [7476,7485]
===
match
---
operator: , [64011,64012]
operator: , [65727,65728]
===
match
---
name: DagModel [1462,1470]
name: DagModel [1462,1470]
===
match
---
name: next_date [55066,55075]
name: next_date [56782,56791]
===
match
---
name: parent_dag_name [61629,61644]
name: parent_dag_name [63345,63360]
===
match
---
trailer [69557,69576]
trailer [71273,71292]
===
match
---
simple_stmt [46231,46323]
simple_stmt [47947,48039]
===
match
---
arglist [55485,55565]
arglist [57201,57281]
===
match
---
trailer [36628,36631]
trailer [38344,38347]
===
match
---
assert_stmt [53181,53217]
assert_stmt [54897,54933]
===
match
---
trailer [56855,56857]
trailer [58571,58573]
===
match
---
funcdef [3829,4481]
funcdef [3829,4481]
===
match
---
operator: , [63119,63120]
operator: , [64835,64836]
===
match
---
operator: == [6695,6697]
operator: == [6695,6697]
===
match
---
simple_stmt [35438,35472]
simple_stmt [37154,37188]
===
match
---
atom_expr [2811,2827]
atom_expr [2811,2827]
===
match
---
number: 5 [26520,26521]
number: 5 [28236,28237]
===
match
---
name: dag_id [4961,4967]
name: dag_id [4961,4967]
===
match
---
name: io [811,813]
name: io [811,813]
===
match
---
trailer [33512,33519]
trailer [35228,35235]
===
match
---
operator: { [11627,11628]
operator: { [11627,11628]
===
match
---
name: match [4654,4659]
name: match [4654,4659]
===
match
---
with_stmt [29963,30267]
with_stmt [31679,31983]
===
match
---
arglist [38591,38644]
arglist [40307,40360]
===
match
---
trailer [33428,33432]
trailer [35144,35148]
===
match
---
atom_expr [35444,35471]
atom_expr [37160,37187]
===
match
---
suite [28581,29006]
suite [30297,30722]
===
match
---
atom_expr [54668,54690]
atom_expr [56384,56406]
===
match
---
name: ti1 [17464,17467]
name: ti1 [17464,17467]
===
match
---
operator: = [64905,64906]
operator: = [66621,66622]
===
match
---
name: dag [36067,36070]
name: dag [37783,37786]
===
match
---
param [3891,3895]
param [3891,3895]
===
match
---
trailer [16113,16123]
trailer [16113,16123]
===
match
---
trailer [14342,14351]
trailer [14342,14351]
===
match
---
operator: = [37634,37635]
operator: = [39350,39351]
===
match
---
operator: == [49295,49297]
operator: == [51011,51013]
===
match
---
expr_stmt [19910,19958]
expr_stmt [19910,19958]
===
match
---
operator: = [6530,6531]
operator: = [6530,6531]
===
match
---
simple_stmt [44228,44233]
simple_stmt [45944,45949]
===
match
---
operator: } [24827,24828]
operator: } [26543,26544]
===
match
---
name: dag [30312,30315]
name: dag [32028,32031]
===
match
---
comparison [23911,23959]
comparison [23911,23959]
===
match
---
atom [26046,26077]
atom [27762,27793]
===
match
---
name: stage [13239,13244]
name: stage [13239,13244]
===
match
---
suite [34785,35132]
suite [36501,36848]
===
match
---
trailer [44435,44467]
trailer [46151,46183]
===
match
---
assert_stmt [12034,12074]
assert_stmt [12034,12074]
===
match
---
operator: , [60777,60778]
operator: , [62493,62494]
===
match
---
name: test_tree_view [36102,36116]
name: test_tree_view [37818,37832]
===
match
---
name: dag [64004,64007]
name: dag [65720,65723]
===
match
---
operator: == [15144,15146]
operator: == [15144,15146]
===
match
---
atom [26928,26960]
atom [28644,28676]
===
match
---
name: op5 [9819,9822]
name: op5 [9819,9822]
===
match
---
argument [6593,6606]
argument [6593,6606]
===
match
---
name: dag_subdag [62055,62065]
name: dag_subdag [63771,63781]
===
match
---
simple_stmt [67768,67833]
simple_stmt [69484,69549]
===
match
---
operator: = [13975,13976]
operator: = [13975,13976]
===
match
---
simple_stmt [54523,54555]
simple_stmt [56239,56271]
===
match
---
trailer [59720,59728]
trailer [61436,61444]
===
match
---
assert_stmt [5598,5664]
assert_stmt [5598,5664]
===
match
---
name: dump [45309,45313]
name: dump [47025,47029]
===
match
---
name: set [25153,25156]
name: set [26869,26872]
===
match
---
trailer [53160,53162]
trailer [54876,54878]
===
match
---
operator: == [33139,33141]
operator: == [34855,34857]
===
match
---
name: DummyOperator [56734,56747]
name: DummyOperator [58450,58463]
===
match
---
trailer [39199,39213]
trailer [40915,40929]
===
match
---
string: "dag run start_date loses precision " [43754,43791]
string: "dag run start_date loses precision " [45470,45507]
===
match
---
expr_stmt [19861,19896]
expr_stmt [19861,19896]
===
match
---
with_stmt [62075,62462]
with_stmt [63791,64178]
===
match
---
operator: , [34906,34907]
operator: , [36622,36623]
===
match
---
trailer [70443,70447]
trailer [72159,72163]
===
match
---
argument [28529,28552]
argument [30245,30268]
===
match
---
name: session [64540,64547]
name: session [66256,66263]
===
match
---
trailer [69127,69134]
trailer [70843,70850]
===
match
---
operator: , [17311,17312]
operator: , [17311,17312]
===
match
---
param [30603,30610]
param [32319,32326]
===
match
---
shift_expr [37169,37179]
shift_expr [38885,38895]
===
match
---
name: dag [45996,45999]
name: dag [47712,47715]
===
match
---
trailer [37114,37152]
trailer [38830,38868]
===
match
---
name: num [69915,69918]
name: num [71631,71634]
===
match
---
trailer [18075,18083]
trailer [18075,18083]
===
match
---
trailer [20941,20946]
trailer [20941,20946]
===
match
---
argument [17956,17971]
argument [17956,17971]
===
match
---
simple_stmt [37607,37650]
simple_stmt [39323,39366]
===
match
---
name: session [52645,52652]
name: session [54361,54368]
===
match
---
trailer [25510,25516]
trailer [27226,27232]
===
match
---
param [68303,68307]
param [70019,70023]
===
match
---
funcdef [15167,16362]
funcdef [15167,16362]
===
match
---
name: run_id [43393,43399]
name: run_id [45109,45115]
===
match
---
operator: == [35115,35117]
operator: == [36831,36833]
===
match
---
atom_expr [31704,31792]
atom_expr [33420,33508]
===
match
---
name: next_dagrun_create_after [65017,65041]
name: next_dagrun_create_after [66733,66757]
===
match
---
expr_stmt [13969,13978]
expr_stmt [13969,13978]
===
match
---
name: state [39690,39695]
name: state [41406,41411]
===
match
---
name: i [24542,24543]
name: i [26258,26259]
===
match
---
atom_expr [45703,45712]
atom_expr [47419,47428]
===
match
---
suite [37789,38240]
suite [39505,39956]
===
match
---
testlist_comp [48035,48079]
testlist_comp [49751,49795]
===
match
---
atom_expr [36063,36078]
atom_expr [37779,37794]
===
match
---
operator: , [26896,26897]
operator: , [28612,28613]
===
match
---
trailer [33030,33032]
trailer [34746,34748]
===
match
---
expr_stmt [47366,47418]
expr_stmt [49082,49134]
===
match
---
operator: = [49782,49783]
operator: = [51498,51499]
===
match
---
trailer [19037,19045]
trailer [19037,19045]
===
match
---
string: "t1" [37123,37127]
string: "t1" [38839,38843]
===
match
---
argument [52917,52937]
argument [54633,54653]
===
match
---
suite [69065,69093]
suite [70781,70809]
===
match
---
arith_expr [17204,17245]
arith_expr [17204,17245]
===
match
---
trailer [23980,23999]
trailer [23980,23999]
===
match
---
string: 'section-1' [62402,62413]
string: 'section-1' [64118,64129]
===
match
---
name: DAG [5330,5333]
name: DAG [5330,5333]
===
match
---
trailer [24853,24856]
trailer [26569,26572]
===
match
---
name: params2 [4345,4352]
name: params2 [4345,4352]
===
match
---
name: row [27099,27102]
name: row [28815,28818]
===
match
---
name: model [27840,27845]
name: model [29556,29561]
===
match
---
assert_stmt [34295,34319]
assert_stmt [36011,36035]
===
match
---
simple_stmt [48662,48738]
simple_stmt [50378,50454]
===
match
---
atom_expr [17219,17245]
atom_expr [17219,17245]
===
match
---
comparison [7235,7250]
comparison [7235,7250]
===
match
---
number: 2 [59992,59993]
number: 2 [61708,61709]
===
match
---
expr_stmt [8825,8857]
expr_stmt [8825,8857]
===
match
---
atom_expr [19547,19585]
atom_expr [19547,19585]
===
match
---
simple_stmt [63888,63965]
simple_stmt [65604,65681]
===
match
---
atom_expr [45817,45835]
atom_expr [47533,47551]
===
match
---
trailer [6123,6138]
trailer [6123,6138]
===
match
---
name: session [29102,29109]
name: session [30818,30825]
===
match
---
name: clear_db_dags [24112,24125]
name: clear_db_dags [25828,25841]
===
match
---
name: dag [22792,22795]
name: dag [22792,22795]
===
match
---
atom_expr [14184,14374]
atom_expr [14184,14374]
===
match
---
name: start_date [23822,23832]
name: start_date [23822,23832]
===
match
---
name: subdag [49930,49936]
name: subdag [51646,51652]
===
match
---
simple_stmt [59775,59820]
simple_stmt [61491,61536]
===
match
---
argument [64731,64754]
argument [66447,66470]
===
match
---
name: DAG [62080,62083]
name: DAG [63796,63799]
===
match
---
name: start_date [55337,55347]
name: start_date [57053,57063]
===
match
---
atom_expr [45690,45699]
atom_expr [47406,47415]
===
match
---
atom_expr [2718,2746]
atom_expr [2718,2746]
===
match
---
operator: == [28287,28289]
operator: == [30003,30005]
===
match
---
name: op2 [38204,38207]
name: op2 [39920,39923]
===
match
---
name: dag [14781,14784]
name: dag [14781,14784]
===
match
---
atom_expr [49317,49327]
atom_expr [51033,51043]
===
match
---
operator: , [22616,22617]
operator: , [22616,22617]
===
match
---
number: 0 [54594,54595]
number: 0 [56310,56311]
===
match
---
argument [63898,63921]
argument [65614,65637]
===
match
---
trailer [53365,53374]
trailer [55081,55090]
===
match
---
atom_expr [63325,63352]
atom_expr [65041,65068]
===
match
---
name: expand [48005,48011]
name: expand [49721,49727]
===
match
---
name: orm_dag [33277,33284]
name: orm_dag [34993,35000]
===
match
---
operator: , [56212,56213]
operator: , [57928,57929]
===
match
---
dotted_name [2014,2033]
dotted_name [2014,2033]
===
match
---
trailer [48799,48801]
trailer [50515,50517]
===
match
---
name: tasks [9225,9230]
name: tasks [9225,9230]
===
match
---
name: DEFAULT_DATE [54207,54219]
name: DEFAULT_DATE [55923,55935]
===
match
---
atom [63038,63241]
atom [64754,64957]
===
match
---
simple_stmt [17768,17865]
simple_stmt [17768,17865]
===
match
---
operator: , [12868,12869]
operator: , [12868,12869]
===
match
---
suite [68487,68607]
suite [70203,70323]
===
match
---
comparison [11809,11885]
comparison [11809,11885]
===
match
---
name: DagRun [53119,53125]
name: DagRun [54835,54841]
===
match
---
string: 'start_date' [11628,11640]
string: 'start_date' [11628,11640]
===
match
---
operator: { [12987,12988]
operator: { [12987,12988]
===
match
---
funcdef [67069,67205]
funcdef [68785,68921]
===
match
---
atom_expr [27029,27081]
atom_expr [28745,28797]
===
match
---
atom_expr [54004,54062]
atom_expr [55720,55778]
===
match
---
trailer [50738,50744]
trailer [52454,52460]
===
match
---
name: sub_dag [38829,38836]
name: sub_dag [40545,40552]
===
match
---
name: pipeline [14531,14539]
name: pipeline [14531,14539]
===
match
---
operator: = [6600,6601]
operator: = [6600,6601]
===
match
---
operator: , [26028,26029]
operator: , [27744,27745]
===
match
---
simple_stmt [1943,2009]
simple_stmt [1943,2009]
===
match
---
operator: = [32989,32990]
operator: = [34705,34706]
===
match
---
simple_stmt [10460,10495]
simple_stmt [10460,10495]
===
match
---
with_item [33380,33407]
with_item [35096,35123]
===
match
---
expr_stmt [6364,6398]
expr_stmt [6364,6398]
===
match
---
argument [54276,54282]
argument [55992,55998]
===
match
---
assert_stmt [55059,55083]
assert_stmt [56775,56799]
===
match
---
simple_stmt [34063,34092]
simple_stmt [35779,35808]
===
match
---
name: DAG [35239,35242]
name: DAG [36955,36958]
===
match
---
name: model [28203,28208]
name: model [29919,29924]
===
match
---
simple_stmt [29661,29714]
simple_stmt [31377,31430]
===
match
---
atom_expr [22627,22650]
atom_expr [22627,22650]
===
match
---
name: xcom_pass_to_op [71032,71047]
name: xcom_pass_to_op [72748,72763]
===
match
---
import_name [839,852]
import_name [839,852]
===
match
---
name: timedelta [48904,48913]
name: timedelta [50620,50629]
===
match
---
trailer [21865,21867]
trailer [21865,21867]
===
match
---
suite [26523,26563]
suite [28239,28279]
===
match
---
operator: = [37073,37074]
operator: = [38789,38790]
===
match
---
comparison [51240,51269]
comparison [52956,52985]
===
match
---
operator: = [58868,58869]
operator: = [60584,60585]
===
match
---
trailer [55600,55641]
trailer [57316,57357]
===
match
---
operator: , [66450,66451]
operator: , [68166,68167]
===
match
---
atom [14092,14111]
atom [14092,14111]
===
match
---
arglist [39113,39174]
arglist [40829,40890]
===
match
---
decorated [66658,66750]
decorated [68374,68466]
===
match
---
comp_op [39362,39368]
comp_op [41078,41084]
===
match
---
operator: , [57317,57318]
operator: , [59033,59034]
===
match
---
atom_expr [66686,66703]
atom_expr [68402,68419]
===
match
---
param [29829,29833]
param [31545,31549]
===
match
---
atom_expr [23977,24006]
atom_expr [23977,24006]
===
match
---
simple_stmt [1667,1715]
simple_stmt [1667,1715]
===
match
---
term [15006,15024]
term [15006,15024]
===
match
---
simple_stmt [60062,60112]
simple_stmt [61778,61828]
===
match
---
name: owner [41295,41300]
name: owner [43011,43016]
===
match
---
trailer [46295,46322]
trailer [48011,48038]
===
match
---
operator: @ [39796,39797]
operator: @ [41512,41513]
===
match
---
name: models [18561,18567]
name: models [18561,18567]
===
match
---
sync_comp_for [24857,24904]
sync_comp_for [26573,26620]
===
match
---
name: dag_id [29512,29518]
name: dag_id [31228,31234]
===
match
---
name: dag [64906,64909]
name: dag [66622,66625]
===
match
---
expr_stmt [54333,54513]
expr_stmt [56049,56229]
===
match
---
funcdef [7256,8480]
funcdef [7256,8480]
===
match
---
trailer [66690,66703]
trailer [68406,68419]
===
match
---
simple_stmt [60963,61019]
simple_stmt [62679,62735]
===
match
---
atom_expr [19082,19106]
atom_expr [19082,19106]
===
match
---
decorated [67102,67178]
decorated [68818,68894]
===
match
---
name: DagRunType [47158,47168]
name: DagRunType [48874,48884]
===
match
---
expr_stmt [13932,13942]
expr_stmt [13932,13942]
===
match
---
trailer [30879,30947]
trailer [32595,32663]
===
match
---
dictorsetmaker [66242,66399]
dictorsetmaker [67958,68115]
===
match
---
atom_expr [5917,5986]
atom_expr [5917,5986]
===
match
---
name: in_ [31934,31937]
name: in_ [33650,33653]
===
match
---
operator: = [23739,23740]
operator: = [23739,23740]
===
match
---
name: op2 [56673,56676]
name: op2 [58389,58392]
===
match
---
name: DagParam [1658,1666]
name: DagParam [1658,1666]
===
match
---
operator: , [28044,28045]
operator: , [29760,29761]
===
match
---
argument [38401,38413]
argument [40117,40129]
===
match
---
atom_expr [10160,10179]
atom_expr [10160,10179]
===
match
---
string: "2015-01-02T02:00:00+00:00" [24043,24070]
string: "2015-01-02T02:00:00+00:00" [24043,24070]
===
match
---
expr_stmt [59775,59819]
expr_stmt [61491,61535]
===
match
---
atom_expr [22189,22211]
atom_expr [22189,22211]
===
match
---
name: range [15792,15797]
name: range [15792,15797]
===
match
---
trailer [60019,60042]
trailer [61735,61758]
===
match
---
simple_stmt [57126,57329]
simple_stmt [58842,59045]
===
match
---
operator: = [8043,8044]
operator: = [8043,8044]
===
match
---
operator: { [24832,24833]
operator: { [26548,26549]
===
match
---
operator: = [7826,7827]
operator: = [7826,7827]
===
match
---
atom_expr [17885,17972]
atom_expr [17885,17972]
===
match
---
operator: * [55406,55407]
operator: * [57122,57123]
===
match
---
name: pendulum [20310,20318]
name: pendulum [20310,20318]
===
match
---
suite [10597,10727]
suite [10597,10727]
===
match
---
trailer [11839,11846]
trailer [11839,11846]
===
match
---
expr_stmt [4944,4996]
expr_stmt [4944,4996]
===
match
---
number: 5 [13959,13960]
number: 5 [13959,13960]
===
match
---
atom_expr [68736,68751]
atom_expr [70452,70467]
===
match
---
name: DummyOperator [49961,49974]
name: DummyOperator [51677,51690]
===
match
---
funcdef [63829,64556]
funcdef [65545,66272]
===
match
---
name: dag [32726,32729]
name: dag [34442,34445]
===
match
---
argument [57254,57290]
argument [58970,59006]
===
match
---
name: DAG [32939,32942]
name: DAG [34655,34658]
===
match
---
trailer [18280,18303]
trailer [18280,18303]
===
match
---
trailer [57036,57046]
trailer [58752,58762]
===
match
---
name: FAILED [48525,48531]
name: FAILED [50241,50247]
===
match
---
operator: = [70962,70963]
operator: = [72678,72679]
===
match
---
name: pickle [45263,45269]
name: pickle [46979,46985]
===
match
---
import_from [1267,1305]
import_from [1267,1305]
===
match
---
parameters [39869,39887]
parameters [41585,41603]
===
match
---
name: task_id [6171,6178]
name: task_id [6171,6178]
===
match
---
trailer [33131,33138]
trailer [34847,34854]
===
match
---
with_stmt [36866,37180]
with_stmt [38582,38896]
===
match
---
expr_stmt [35781,35814]
expr_stmt [37497,37530]
===
match
---
fstring_string: dummy_task_ [65916,65927]
fstring_string: dummy_task_ [67632,67643]
===
match
---
argument [50550,50577]
argument [52266,52293]
===
match
---
name: logging [10087,10094]
name: logging [10087,10094]
===
match
---
atom_expr [29985,30030]
atom_expr [31701,31746]
===
match
---
atom_expr [12572,12604]
atom_expr [12572,12604]
===
match
---
testlist_comp [32034,32046]
testlist_comp [33750,33762]
===
match
---
atom [25996,26028]
atom [27712,27744]
===
match
---
atom_expr [53516,53538]
atom_expr [55232,55254]
===
match
---
atom_expr [47239,47248]
atom_expr [48955,48964]
===
match
---
trailer [19644,19646]
trailer [19644,19646]
===
match
---
operator: , [49838,49839]
operator: , [51554,51555]
===
match
---
name: DummyOperator [1751,1764]
name: DummyOperator [1751,1764]
===
match
---
expr_stmt [51068,51224]
expr_stmt [52784,52940]
===
match
---
name: self [69147,69151]
name: self [70863,70867]
===
match
---
expr_stmt [51932,51955]
expr_stmt [53648,53671]
===
match
---
name: path [19033,19037]
name: path [19033,19037]
===
match
---
operator: = [3460,3461]
operator: = [3460,3461]
===
match
---
operator: = [30361,30362]
operator: = [32077,32078]
===
match
---
operator: == [59219,59221]
operator: == [60935,60937]
===
match
---
operator: = [67869,67870]
operator: = [69585,69586]
===
match
---
name: ABSOLUTE [15672,15680]
name: ABSOLUTE [15672,15680]
===
match
---
trailer [43804,43814]
trailer [45520,45530]
===
match
---
name: run_type [40547,40555]
name: run_type [42263,42271]
===
match
---
name: test_dag_id [16724,16735]
name: test_dag_id [16724,16735]
===
match
---
string: 'owner2' [28981,28989]
string: 'owner2' [30697,30705]
===
match
---
name: dag_run [40696,40703]
name: dag_run [42412,42419]
===
match
---
arglist [61977,62033]
arglist [63693,63749]
===
match
---
simple_stmt [50492,50516]
simple_stmt [52208,52232]
===
match
---
number: 1 [51633,51634]
number: 1 [53349,53350]
===
match
---
simple_stmt [52477,52553]
simple_stmt [54193,54269]
===
match
---
testlist_comp [31939,31956]
testlist_comp [33655,33672]
===
match
---
decorator [49394,49500]
decorator [51110,51216]
===
match
---
trailer [24502,24504]
trailer [26218,26220]
===
match
---
simple_stmt [7544,7577]
simple_stmt [7544,7577]
===
match
---
name: _clean_up [51525,51534]
name: _clean_up [53241,53250]
===
match
---
name: session [34701,34708]
name: session [36417,36424]
===
match
---
simple_stmt [6408,6431]
simple_stmt [6408,6431]
===
match
---
string: 'dag.subtask' [30174,30187]
string: 'dag.subtask' [31890,31903]
===
match
---
trailer [37968,37982]
trailer [39684,39698]
===
match
---
assert_stmt [23095,23155]
assert_stmt [23095,23155]
===
match
---
name: DAG [68166,68169]
name: DAG [69882,69885]
===
match
---
simple_stmt [70948,71017]
simple_stmt [72664,72733]
===
match
---
name: DEFAULT_DATE [41844,41856]
name: DEFAULT_DATE [43560,43572]
===
match
---
number: 2 [2389,2390]
number: 2 [2389,2390]
===
match
---
operator: } [4264,4265]
operator: } [4264,4265]
===
match
---
name: owners [29192,29198]
name: owners [30908,30914]
===
match
---
name: start_date [12845,12855]
name: start_date [12845,12855]
===
match
---
suite [16133,16362]
suite [16133,16362]
===
match
---
simple_stmt [70160,70175]
simple_stmt [71876,71891]
===
match
---
arglist [8439,8478]
arglist [8439,8478]
===
match
---
name: dag [41247,41250]
name: dag [42963,42966]
===
match
---
trailer [24027,24037]
trailer [24027,24037]
===
match
---
atom_expr [37613,37649]
atom_expr [39329,39365]
===
match
---
name: raises [68705,68711]
name: raises [70421,70427]
===
match
---
name: include_parentdag [50995,51012]
name: include_parentdag [52711,52728]
===
match
---
trailer [24890,24897]
trailer [26606,26613]
===
match
---
name: dag [60875,60878]
name: dag [62591,62594]
===
match
---
name: WeightRule [14332,14342]
name: WeightRule [14332,14342]
===
match
---
name: get_num_task_instances [18281,18303]
name: get_num_task_instances [18281,18303]
===
match
---
operator: , [20411,20412]
operator: , [20411,20412]
===
match
---
operator: , [38595,38596]
operator: , [40311,40312]
===
match
---
atom_expr [24521,24590]
atom_expr [26237,26306]
===
match
---
name: patch [39797,39802]
name: patch [41513,41518]
===
match
---
name: t [24353,24354]
name: t [26069,26070]
===
match
---
trailer [48453,48620]
trailer [50169,50336]
===
match
---
name: dag [21610,21613]
name: dag [21610,21613]
===
match
---
operator: = [9823,9824]
operator: = [9823,9824]
===
match
---
number: 2016 [60759,60763]
number: 2016 [62475,62479]
===
match
---
number: 3 [18127,18128]
number: 3 [18127,18128]
===
match
---
arith_expr [49822,49838]
arith_expr [51538,51554]
===
match
---
number: 1 [64307,64308]
number: 1 [66023,66024]
===
match
---
dictorsetmaker [6053,6070]
dictorsetmaker [6053,6070]
===
match
---
name: configuration [1280,1293]
name: configuration [1280,1293]
===
match
---
number: 1 [13507,13508]
number: 1 [13507,13508]
===
match
---
name: isoformat [22953,22962]
name: isoformat [22953,22962]
===
match
---
name: session [54147,54154]
name: session [55863,55870]
===
match
---
operator: , [20628,20629]
operator: , [20628,20629]
===
match
---
trailer [53293,53305]
trailer [55009,55021]
===
match
---
dictorsetmaker [14093,14110]
dictorsetmaker [14093,14110]
===
match
---
string: 'dag-bulk-sync-0' [24957,24974]
string: 'dag-bulk-sync-0' [26673,26690]
===
match
---
operator: } [12985,12986]
operator: } [12985,12986]
===
match
---
operator: , [32349,32350]
operator: , [34065,34066]
===
match
---
simple_stmt [54668,54691]
simple_stmt [56384,56407]
===
match
---
name: session [54364,54371]
name: session [56080,56087]
===
match
---
name: task [19361,19365]
name: task [19361,19365]
===
match
---
arglist [37115,37151]
arglist [38831,38867]
===
match
---
simple_stmt [8870,8903]
simple_stmt [8870,8903]
===
match
---
name: dag [9006,9009]
name: dag [9006,9009]
===
match
---
trailer [65442,65451]
trailer [67158,67167]
===
match
---
string: 'dag_with_outdated_perms' [63523,63548]
string: 'dag_with_outdated_perms' [65239,65264]
===
match
---
name: settings [51975,51983]
name: settings [53691,53699]
===
match
---
trailer [36582,36588]
trailer [38298,38304]
===
match
---
operator: = [47191,47192]
operator: = [48907,48908]
===
match
---
string: "@monthly" [46475,46485]
string: "@monthly" [48191,48201]
===
match
---
name: dag_run [39625,39632]
name: dag_run [41341,41348]
===
match
---
name: days [17113,17117]
name: days [17113,17117]
===
match
---
name: task [20022,20026]
name: task [20022,20026]
===
match
---
number: 0 [14410,14411]
number: 0 [14410,14411]
===
match
---
simple_stmt [13426,13462]
simple_stmt [13426,13462]
===
match
---
atom_expr [46262,46277]
atom_expr [47978,47993]
===
match
---
expr_stmt [31137,31160]
expr_stmt [32853,32876]
===
match
---
atom_expr [65612,65627]
atom_expr [67328,67343]
===
match
---
simple_stmt [34029,34055]
simple_stmt [35745,35771]
===
match
---
trailer [26393,26395]
trailer [28109,28111]
===
match
---
string: 'end_date' [11671,11681]
string: 'end_date' [11671,11681]
===
match
---
dictorsetmaker [70390,70408]
dictorsetmaker [72106,72124]
===
match
---
operator: = [23832,23833]
operator: = [23832,23833]
===
match
---
trailer [66387,66398]
trailer [68103,68114]
===
match
---
name: commit [52731,52737]
name: commit [54447,54453]
===
match
---
operator: , [63434,63435]
operator: , [65150,65151]
===
match
---
operator: == [59962,59964]
operator: == [61678,61680]
===
match
---
atom [9085,9100]
atom [9085,9100]
===
match
---
atom [6052,6071]
atom [6052,6071]
===
match
---
comparison [7175,7189]
comparison [7175,7189]
===
match
---
string: "@once" [46595,46602]
string: "@once" [48311,48318]
===
match
---
operator: , [28622,28623]
operator: , [30338,30339]
===
match
---
trailer [69599,69609]
trailer [71315,71325]
===
match
---
atom_expr [17294,17370]
atom_expr [17294,17370]
===
match
---
atom_expr [28408,28438]
atom_expr [30124,30154]
===
match
---
name: convert [20755,20762]
name: convert [20755,20762]
===
match
---
testlist_comp [26245,26274]
testlist_comp [27961,27990]
===
match
---
testlist_comp [51348,51362]
testlist_comp [53064,53078]
===
match
---
string: 'dag-test-dagtag' [24404,24421]
string: 'dag-test-dagtag' [26120,26137]
===
match
---
name: get_template_env [18676,18692]
name: get_template_env [18676,18692]
===
match
---
name: is_subdag [28912,28921]
name: is_subdag [30628,30637]
===
match
---
atom_expr [55775,55807]
atom_expr [57491,57523]
===
match
---
operator: == [46164,46166]
operator: == [47880,47882]
===
match
---
atom_expr [36190,36230]
atom_expr [37906,37946]
===
match
---
name: next_dagrun_after_date [59791,59813]
name: next_dagrun_after_date [61507,61529]
===
match
---
atom_expr [65498,65515]
atom_expr [67214,67231]
===
match
---
operator: = [62209,62210]
operator: = [63925,63926]
===
match
---
atom_expr [6212,6219]
atom_expr [6212,6219]
===
match
---
operator: , [2393,2394]
operator: , [2393,2394]
===
match
---
name: query [27114,27119]
name: query [28830,28835]
===
match
---
name: timedelta [17228,17237]
name: timedelta [17228,17237]
===
match
---
operator: = [48373,48374]
operator: = [50089,50090]
===
match
---
name: next_date [62671,62680]
name: next_date [64387,64396]
===
match
---
operator: , [28116,28117]
operator: , [29832,29833]
===
match
---
for_stmt [14661,14756]
for_stmt [14661,14756]
===
match
---
name: self [69794,69798]
name: self [71510,71514]
===
match
---
trailer [31281,31330]
trailer [32997,33046]
===
match
---
argument [53836,53855]
argument [55552,55571]
===
match
---
name: task [16276,16280]
name: task [16276,16280]
===
match
---
trailer [8072,8099]
trailer [8072,8099]
===
match
---
name: dag_id [48162,48168]
name: dag_id [49878,49884]
===
match
---
operator: } [62444,62445]
operator: } [64160,64161]
===
match
---
name: topological_list [10430,10446]
name: topological_list [10430,10446]
===
match
---
name: op3 [8956,8959]
name: op3 [8956,8959]
===
match
---
name: dag_id [34519,34525]
name: dag_id [36235,36241]
===
match
---
name: dag [47366,47369]
name: dag [49082,49085]
===
match
---
name: session [52723,52730]
name: session [54439,54446]
===
match
---
name: local_tz [34794,34802]
name: local_tz [36510,36518]
===
match
---
trailer [43531,43539]
trailer [45247,45255]
===
match
---
name: raises [37395,37401]
name: raises [39111,39117]
===
match
---
name: convert_to_utc [20579,20593]
name: convert_to_utc [20579,20593]
===
match
---
trailer [53125,53132]
trailer [54841,54848]
===
match
---
name: next_dagrun_after_date [60926,60948]
name: next_dagrun_after_date [62642,62664]
===
match
---
name: last_loaded [44807,44818]
name: last_loaded [46523,46534]
===
match
---
operator: = [43998,43999]
operator: = [45714,45715]
===
match
---
operator: = [69394,69395]
operator: = [71110,71111]
===
match
---
name: dag [23013,23016]
name: dag [23013,23016]
===
match
---
name: DagModel [64086,64094]
name: DagModel [65802,65810]
===
match
---
operator: , [29224,29225]
operator: , [30940,30941]
===
match
---
name: parameterized [53224,53237]
name: parameterized [54940,54953]
===
match
---
argument [34186,34201]
argument [35902,35917]
===
match
---
string: 'subdag' [31002,31010]
string: 'subdag' [32718,32726]
===
match
---
name: timedelta [55293,55302]
name: timedelta [57009,57018]
===
match
---
operator: = [57773,57774]
operator: = [59489,59490]
===
match
---
operator: = [6794,6795]
operator: = [6794,6795]
===
match
---
name: NONE [47484,47488]
name: NONE [49200,49204]
===
match
---
atom_expr [58869,58886]
atom_expr [60585,60602]
===
match
---
name: op2 [38098,38101]
name: op2 [39814,39817]
===
match
---
string: 'op6' [6851,6856]
string: 'op6' [6851,6856]
===
match
---
number: 1 [62178,62179]
number: 1 [63894,63895]
===
match
---
sync_comp_for [25848,25895]
sync_comp_for [27564,27611]
===
match
---
operator: - [56899,56900]
operator: - [58615,58616]
===
match
---
trailer [29536,29540]
trailer [31252,31256]
===
match
---
number: 1 [10362,10363]
number: 1 [10362,10363]
===
match
---
atom_expr [13026,13041]
atom_expr [13026,13041]
===
match
---
expr_stmt [65278,65302]
expr_stmt [66994,67018]
===
match
---
trailer [46975,46993]
trailer [48691,48709]
===
match
---
simple_stmt [6917,6954]
simple_stmt [6917,6954]
===
match
---
atom_expr [12413,12425]
atom_expr [12413,12425]
===
match
---
simple_stmt [19015,19054]
simple_stmt [19015,19054]
===
match
---
param [12492,12496]
param [12492,12496]
===
match
---
argument [63516,63548]
argument [65232,65264]
===
match
---
assert_stmt [24931,25205]
assert_stmt [26647,26921]
===
match
---
name: DAG [16475,16478]
name: DAG [16475,16478]
===
match
---
string: """         Test to check that a DAG with catchup = False only schedules beginning now, not back to the start date         """ [56057,56183]
string: """         Test to check that a DAG with catchup = False only schedules beginning now, not back to the start date         """ [57773,57899]
===
match
---
number: 1 [15027,15028]
number: 1 [15027,15028]
===
match
---
arglist [24606,24610]
arglist [26322,26326]
===
match
---
operator: = [27438,27439]
operator: = [29154,29155]
===
match
---
atom_expr [39060,39078]
atom_expr [40776,40794]
===
match
---
comparison [61343,61393]
comparison [63059,63109]
===
match
---
name: State [49440,49445]
name: State [51156,51161]
===
match
---
name: run [69480,69483]
name: run [71196,71199]
===
match
---
trailer [65318,65324]
trailer [67034,67040]
===
match
---
comparison [46892,46956]
comparison [48608,48672]
===
match
---
trailer [12092,12141]
trailer [12092,12141]
===
match
---
name: end_date [55371,55379]
name: end_date [57087,57095]
===
match
---
atom_expr [62383,62446]
atom_expr [64099,64162]
===
match
---
expr_stmt [47427,47489]
expr_stmt [49143,49205]
===
match
---
atom_expr [40624,40667]
atom_expr [42340,42383]
===
match
---
name: match [37424,37429]
name: match [39140,39145]
===
match
---
name: dag_id [39071,39077]
name: dag_id [40787,40793]
===
match
---
name: DEFAULT_ARGS [68440,68452]
name: DEFAULT_ARGS [70156,70168]
===
match
---
simple_stmt [17255,17280]
simple_stmt [17255,17280]
===
match
---
suite [4847,5082]
suite [4847,5082]
===
match
---
name: start_date [70448,70458]
name: start_date [72164,72174]
===
match
---
name: start [20641,20646]
name: start [20641,20646]
===
match
---
string: 'op4' [6554,6559]
string: 'op4' [6554,6559]
===
match
---
name: synchronize_session [46296,46315]
name: synchronize_session [48012,48031]
===
match
---
name: settings [12057,12065]
name: settings [12057,12065]
===
match
---
trailer [23186,23188]
trailer [23186,23188]
===
match
---
string: 'airflow' [44259,44268]
string: 'airflow' [45975,45984]
===
match
---
atom_expr [42357,42446]
atom_expr [44073,44162]
===
match
---
string: 'owner2' [6459,6467]
string: 'owner2' [6459,6467]
===
match
---
operator: = [4784,4785]
operator: = [4784,4785]
===
match
---
trailer [21493,21502]
trailer [21493,21502]
===
match
---
simple_stmt [55001,55051]
simple_stmt [56717,56767]
===
match
---
name: TestCase [2423,2431]
name: TestCase [2423,2431]
===
match
---
param [11033,11037]
param [11033,11037]
===
match
---
testlist_comp [46624,46678]
testlist_comp [48340,48394]
===
match
---
simple_stmt [49275,49300]
simple_stmt [50991,51016]
===
match
---
name: mock_callback_with_exception [40331,40359]
name: mock_callback_with_exception [42047,42075]
===
match
---
fstring_end: ' [15574,15575]
fstring_end: ' [15574,15575]
===
match
---
name: start_date [41214,41224]
name: start_date [42930,42940]
===
match
---
operator: , [62180,62181]
operator: , [63896,63897]
===
match
---
atom_expr [29251,29268]
atom_expr [30967,30984]
===
match
---
argument [64977,65003]
argument [66693,66719]
===
match
---
name: State [49467,49472]
name: State [51183,51188]
===
match
---
name: session [33064,33071]
name: session [34780,34787]
===
match
---
atom_expr [22566,22651]
atom_expr [22566,22651]
===
match
---
atom [15491,15766]
atom [15491,15766]
===
match
---
suite [15228,16362]
suite [15228,16362]
===
match
---
operator: = [54026,54027]
operator: = [55742,55743]
===
match
---
expr_stmt [67618,67639]
expr_stmt [69334,69355]
===
match
---
operator: = [20640,20641]
operator: = [20640,20641]
===
match
---
for_stmt [26429,26486]
for_stmt [28145,28202]
===
match
---
name: clear [54177,54182]
name: clear [55893,55898]
===
match
---
fstring [61985,62017]
fstring [63701,63733]
===
match
---
operator: = [47382,47383]
operator: = [49098,49099]
===
match
---
expr_stmt [4275,4353]
expr_stmt [4275,4353]
===
match
---
name: create_session [42747,42761]
name: create_session [44463,44477]
===
match
---
simple_stmt [52002,52198]
simple_stmt [53718,53914]
===
match
---
name: dag [70128,70131]
name: dag [71844,71847]
===
match
---
dictorsetmaker [34864,34924]
dictorsetmaker [36580,36640]
===
match
---
trailer [10094,10099]
trailer [10094,10099]
===
match
---
operator: , [56589,56590]
operator: , [58305,58306]
===
match
---
trailer [62752,62761]
trailer [64468,64477]
===
match
---
simple_stmt [43144,43169]
simple_stmt [44860,44885]
===
match
---
argument [31752,31766]
argument [33468,33482]
===
match
---
trailer [34476,34482]
trailer [36192,36198]
===
match
---
operator: = [6391,6392]
operator: = [6391,6392]
===
match
---
name: DAG [41170,41173]
name: DAG [42886,42889]
===
match
---
atom_expr [9202,9221]
atom_expr [9202,9221]
===
match
---
name: paused_dags [32193,32204]
name: paused_dags [33909,33920]
===
match
---
string: 'a_parent' [8135,8145]
string: 'a_parent' [8135,8145]
===
match
---
suite [30612,32501]
suite [32328,34217]
===
match
---
trailer [41075,41085]
trailer [42791,42801]
===
match
---
name: noop_pipeline [67901,67914]
name: noop_pipeline [69617,69630]
===
match
---
operator: == [47652,47654]
operator: == [49368,49370]
===
match
---
trailer [34252,34279]
trailer [35968,35995]
===
match
---
atom_expr [70948,70961]
atom_expr [72664,72677]
===
match
---
atom_expr [33433,33491]
atom_expr [35149,35207]
===
match
---
name: dag [7209,7212]
name: dag [7209,7212]
===
match
---
name: dag_id [30893,30899]
name: dag_id [32609,32615]
===
match
---
trailer [59813,59819]
trailer [61529,61535]
===
match
---
name: execution_date [52503,52517]
name: execution_date [54219,54233]
===
match
---
operator: = [66230,66231]
operator: = [67946,67947]
===
match
---
name: execution_date [66128,66142]
name: execution_date [67844,67858]
===
match
---
operator: = [30020,30021]
operator: = [31736,31737]
===
match
---
argument [40311,40359]
argument [42027,42075]
===
match
---
operator: = [14331,14332]
operator: = [14331,14332]
===
match
---
dotted_name [1575,1593]
dotted_name [1575,1593]
===
match
---
name: pipeline [15462,15470]
name: pipeline [15462,15470]
===
match
---
operator: = [19151,19152]
operator: = [19151,19152]
===
match
---
operator: } [29234,29235]
operator: } [30950,30951]
===
match
---
operator: , [63404,63405]
operator: , [65120,65121]
===
match
---
comparison [57477,57505]
comparison [59193,59221]
===
match
---
number: 1 [58835,58836]
number: 1 [60551,60552]
===
match
---
name: DEFAULT_DATE [65065,65077]
name: DEFAULT_DATE [66781,66793]
===
match
---
number: 0 [2392,2393]
number: 0 [2392,2393]
===
match
---
operator: , [10793,10794]
operator: , [10793,10794]
===
match
---
arglist [59565,59755]
arglist [61281,61471]
===
match
---
name: orm_dag [29332,29339]
name: orm_dag [31048,31055]
===
match
---
trailer [34822,34839]
trailer [36538,36555]
===
match
---
operator: = [8739,8740]
operator: = [8739,8740]
===
match
---
simple_stmt [8825,8858]
simple_stmt [8825,8858]
===
match
---
expr_stmt [34459,34532]
expr_stmt [36175,36248]
===
match
---
expr_stmt [8780,8812]
expr_stmt [8780,8812]
===
match
---
import_from [1043,1074]
import_from [1043,1074]
===
match
---
trailer [70149,70151]
trailer [71865,71867]
===
match
---
parameters [70860,70865]
parameters [72576,72581]
===
match
---
expr_stmt [35919,35952]
expr_stmt [37635,37668]
===
match
---
name: get_num_task_instances [17784,17806]
name: get_num_task_instances [17784,17806]
===
match
---
assert_stmt [6648,6669]
assert_stmt [6648,6669]
===
match
---
comparison [69597,69625]
comparison [71313,71341]
===
match
---
operator: = [57689,57690]
operator: = [59405,59406]
===
match
---
name: merge [50739,50744]
name: merge [52455,52460]
===
match
---
name: RUNNING [52628,52635]
name: RUNNING [54344,54351]
===
match
---
with_stmt [6499,6561]
with_stmt [6499,6561]
===
match
---
name: ti_state_begin [54047,54061]
name: ti_state_begin [55763,55777]
===
match
---
name: datetime [12003,12011]
name: datetime [12003,12011]
===
match
---
argument [28713,28736]
argument [30429,30452]
===
match
---
trailer [65469,65475]
trailer [67185,67191]
===
match
---
arglist [12093,12140]
arglist [12093,12140]
===
match
---
argument [62194,62211]
argument [63910,63927]
===
match
---
name: filter [3068,3074]
name: filter [3068,3074]
===
match
---
operator: = [10054,10055]
operator: = [10054,10055]
===
match
---
name: stage [13117,13122]
name: stage [13117,13122]
===
match
---
trailer [12355,12397]
trailer [12355,12397]
===
match
---
operator: , [25134,25135]
operator: , [26850,26851]
===
match
---
parameters [59372,59378]
parameters [61088,61094]
===
match
---
operator: , [32469,32470]
operator: , [34185,34186]
===
match
---
expr_stmt [56866,56994]
expr_stmt [58582,58710]
===
match
---
operator: == [5646,5648]
operator: == [5646,5648]
===
match
---
string: """         Test invalid `default_view` of DAG initialization         """ [4535,4608]
string: """         Test invalid `default_view` of DAG initialization         """ [4535,4608]
===
match
---
number: 5 [59249,59250]
number: 5 [60965,60966]
===
match
---
expr_stmt [7144,7158]
expr_stmt [7144,7158]
===
match
---
name: now [56834,56837]
name: now [58550,58553]
===
match
---
simple_stmt [55059,55084]
simple_stmt [56775,56800]
===
match
---
tfpdef [2784,2795]
tfpdef [2784,2795]
===
match
---
name: subdag [30751,30757]
name: subdag [32467,32473]
===
match
---
name: dag_id [53136,53142]
name: dag_id [54852,54858]
===
match
---
operator: = [51949,51950]
operator: = [53665,53666]
===
match
---
string: "4 5 * * *" [60813,60824]
string: "4 5 * * *" [62529,62540]
===
match
---
operator: = [15393,15394]
operator: = [15393,15394]
===
match
---
operator: = [42434,42435]
operator: = [44150,44151]
===
match
---
simple_stmt [52723,52740]
simple_stmt [54439,54456]
===
match
---
argument [67857,67887]
argument [69573,69603]
===
match
---
name: dag [49792,49795]
name: dag [51508,51511]
===
match
---
name: self [3891,3895]
name: self [3891,3895]
===
match
---
operator: , [34903,34904]
operator: , [36619,36620]
===
match
---
param [37783,37787]
param [39499,39503]
===
match
---
name: isoformat [23113,23122]
name: isoformat [23113,23122]
===
match
---
operator: -> [2653,2655]
operator: -> [2653,2655]
===
match
---
trailer [26747,26753]
trailer [28463,28469]
===
match
---
trailer [39063,39078]
trailer [40779,40794]
===
match
---
argument [67029,67059]
argument [68745,68775]
===
match
---
name: topological_list [8987,9003]
name: topological_list [8987,9003]
===
match
---
name: test_dags_needing_dagruns_not_too_early [63833,63872]
name: test_dags_needing_dagruns_not_too_early [65549,65588]
===
match
---
simple_stmt [16952,17006]
simple_stmt [16952,17006]
===
match
---
dotted_name [2052,2074]
dotted_name [2052,2074]
===
match
---
simple_stmt [30353,30426]
simple_stmt [32069,32142]
===
match
---
atom_expr [24868,24904]
atom_expr [26584,26620]
===
match
---
factor [23685,23687]
factor [23685,23687]
===
match
---
dotted_name [1720,1743]
dotted_name [1720,1743]
===
match
---
atom_expr [63894,63964]
atom_expr [65610,65680]
===
match
---
argument [16511,16543]
argument [16511,16543]
===
match
---
operator: , [46762,46763]
operator: , [48478,48479]
===
match
---
trailer [68711,68722]
trailer [70427,70438]
===
match
---
operator: , [66447,66448]
operator: , [68163,68164]
===
match
---
operator: , [62769,62770]
operator: , [64485,64486]
===
match
---
name: state [70351,70356]
name: state [72067,72072]
===
match
---
name: start_date [50376,50386]
name: start_date [52092,52102]
===
match
---
name: test_duplicate_task_ids_for_same_task_is_allowed [37734,37782]
name: test_duplicate_task_ids_for_same_task_is_allowed [39450,39498]
===
match
---
arglist [10616,10680]
arglist [10616,10680]
===
match
---
expr_stmt [20733,20769]
expr_stmt [20733,20769]
===
match
---
argument [39064,39077]
argument [40780,40793]
===
match
---
argument [12968,12991]
argument [12968,12991]
===
match
---
trailer [36443,36452]
trailer [38159,38168]
===
match
---
name: state [41464,41469]
name: state [43180,43185]
===
match
---
simple_stmt [2599,2629]
simple_stmt [2599,2629]
===
match
---
atom_expr [25413,25439]
atom_expr [27129,27155]
===
match
---
assert_stmt [61336,61393]
assert_stmt [63052,63109]
===
match
---
name: session [18094,18101]
name: session [18094,18101]
===
match
---
name: dag [27422,27425]
name: dag [29138,29141]
===
match
---
name: prev [20913,20917]
name: prev [20913,20917]
===
match
---
name: session [31363,31370]
name: session [33079,33086]
===
match
---
trailer [40738,40743]
trailer [42454,42459]
===
match
---
atom_expr [18672,18694]
atom_expr [18672,18694]
===
match
---
simple_stmt [26617,26791]
simple_stmt [28333,28507]
===
match
---
name: model [28408,28413]
name: model [30124,30129]
===
match
---
parameters [65752,65771]
parameters [67468,67487]
===
match
---
operator: , [60104,60105]
operator: , [61820,61821]
===
match
---
operator: , [60319,60320]
operator: , [62035,62036]
===
match
---
atom_expr [53360,53374]
atom_expr [55076,55090]
===
match
---
trailer [64435,64456]
trailer [66151,66172]
===
match
---
name: ti2 [17130,17133]
name: ti2 [17130,17133]
===
match
---
atom_expr [62606,62623]
atom_expr [64322,64339]
===
match
---
string: 'B' [9712,9715]
string: 'B' [9712,9715]
===
match
---
operator: = [7878,7879]
operator: = [7878,7879]
===
match
---
atom_expr [45792,45801]
atom_expr [47508,47517]
===
match
---
number: 2020 [59866,59870]
number: 2020 [61582,61586]
===
match
---
operator: , [53002,53003]
operator: , [54718,54719]
===
match
---
atom_expr [30489,30509]
atom_expr [32205,32225]
===
match
---
name: i [3403,3404]
name: i [3403,3404]
===
match
---
operator: = [57565,57566]
operator: = [59281,59282]
===
match
---
operator: , [48046,48047]
operator: , [49762,49763]
===
match
---
simple_stmt [45683,45713]
simple_stmt [47399,47429]
===
match
---
name: dag [54900,54903]
name: dag [56616,56619]
===
match
---
name: run [70444,70447]
name: run [72160,72163]
===
match
---
operator: = [55510,55511]
operator: = [57226,57227]
===
match
---
atom [26194,26226]
atom [27910,27942]
===
match
---
operator: = [19379,19380]
operator: = [19379,19380]
===
match
---
argument [51032,51047]
argument [52748,52763]
===
match
---
name: DEFAULT_ARGS [67451,67463]
name: DEFAULT_ARGS [69167,69179]
===
match
---
name: self [69495,69499]
name: self [71211,71215]
===
match
---
name: all [24899,24902]
name: all [26615,26618]
===
match
---
comp_op [30462,30468]
comp_op [32178,32184]
===
match
---
trailer [19975,19991]
trailer [19975,19991]
===
match
---
trailer [24898,24902]
trailer [26614,26618]
===
match
---
name: op4 [9774,9777]
name: op4 [9774,9777]
===
match
---
name: dag [60657,60660]
name: dag [62373,62376]
===
match
---
simple_stmt [8987,9029]
simple_stmt [8987,9029]
===
match
---
trailer [35938,35952]
trailer [37654,37668]
===
match
---
operator: == [23411,23413]
operator: == [23411,23413]
===
match
---
atom [31253,31272]
atom [32969,32988]
===
match
---
argument [15383,15406]
argument [15383,15406]
===
match
---
comparison [6655,6669]
comparison [6655,6669]
===
match
---
name: dagrun [49359,49365]
name: dagrun [51075,51081]
===
match
---
name: clear_db_runs [66605,66618]
name: clear_db_runs [68321,68334]
===
match
---
trailer [4731,4735]
trailer [4731,4735]
===
match
---
operator: = [35877,35878]
operator: = [37593,37594]
===
match
---
atom_expr [60922,60954]
atom_expr [62638,62670]
===
match
---
name: start_date [8548,8558]
name: start_date [8548,8558]
===
match
---
decorator [69017,69033]
decorator [70733,70749]
===
match
---
dictorsetmaker [29597,29615]
dictorsetmaker [31313,31331]
===
match
---
trailer [48792,48799]
trailer [50508,50515]
===
match
---
testlist_comp [31254,31271]
testlist_comp [32970,32987]
===
match
---
trailer [34622,34630]
trailer [36338,36346]
===
match
---
argument [48976,48997]
argument [50692,50713]
===
match
---
name: timezone [58808,58816]
name: timezone [60524,60532]
===
match
---
argument [31295,31320]
argument [33011,33036]
===
match
---
name: dag_id [39987,39993]
name: dag_id [41703,41709]
===
match
---
expr_stmt [45940,45987]
expr_stmt [47656,47703]
===
match
---
trailer [60857,60900]
trailer [62573,62616]
===
match
---
operator: , [43984,43985]
operator: , [45700,45701]
===
match
---
name: datetime [20387,20395]
name: datetime [20387,20395]
===
match
---
operator: , [55498,55499]
operator: , [57214,57215]
===
match
---
atom [25005,25036]
atom [26721,26752]
===
match
---
suite [36238,36718]
suite [37954,38434]
===
match
---
atom_expr [6924,6944]
atom_expr [6924,6944]
===
match
---
trailer [70928,70935]
trailer [72644,72651]
===
match
---
name: session [34469,34476]
name: session [36185,36192]
===
match
---
name: state [52616,52621]
name: state [54332,54337]
===
match
---
suite [6994,7046]
suite [6994,7046]
===
match
---
string: "2018-10-26T01:00:00+00:00" [21871,21898]
string: "2018-10-26T01:00:00+00:00" [21871,21898]
===
match
---
operator: { [24752,24753]
operator: { [26468,26469]
===
match
---
operator: = [9733,9734]
operator: = [9733,9734]
===
match
---
assert_stmt [12150,12190]
assert_stmt [12150,12190]
===
match
---
name: clear [39752,39757]
name: clear [41468,41473]
===
match
---
name: task_instances [54534,54548]
name: task_instances [56250,56264]
===
match
---
suite [46218,46323]
suite [47934,48039]
===
match
---
number: 5 [12515,12516]
number: 5 [12515,12516]
===
match
---
string: 'test-dag2' [26848,26859]
string: 'test-dag2' [28564,28575]
===
match
---
operator: = [50864,50865]
operator: = [52580,52581]
===
match
---
simple_stmt [52413,52437]
simple_stmt [54129,54153]
===
match
---
argument [27577,27584]
argument [29293,29300]
===
match
---
trailer [7557,7576]
trailer [7557,7576]
===
match
---
trailer [46254,46261]
trailer [47970,47977]
===
match
---
string: 'fakename' [17637,17647]
string: 'fakename' [17637,17647]
===
match
---
trailer [20578,20593]
trailer [20578,20593]
===
match
---
argument [18201,18229]
argument [18201,18229]
===
match
---
arglist [53580,53630]
arglist [55296,55346]
===
match
---
funcdef [18445,18839]
funcdef [18445,18839]
===
match
---
name: self [66485,66489]
name: self [68201,68205]
===
match
---
operator: = [42193,42194]
operator: = [43909,43910]
===
match
---
name: op1 [56783,56786]
name: op1 [58499,58502]
===
match
---
simple_stmt [17039,17122]
simple_stmt [17039,17122]
===
match
---
name: DAG [49691,49694]
name: DAG [51407,51410]
===
match
---
name: DagRun [1472,1478]
name: DagRun [1472,1478]
===
match
---
name: filters [18765,18772]
name: filters [18765,18772]
===
match
---
operator: = [10132,10133]
operator: = [10132,10133]
===
match
---
name: DummyOperator [37613,37626]
name: DummyOperator [39329,39342]
===
match
---
name: self [38908,38912]
name: self [40624,40628]
===
match
---
simple_stmt [47126,47224]
simple_stmt [48842,48940]
===
match
---
expr_stmt [9452,9527]
expr_stmt [9452,9527]
===
match
---
name: task_decorator [68501,68515]
name: task_decorator [70217,70231]
===
match
---
name: unittest [65498,65506]
name: unittest [67214,67222]
===
match
---
trailer [38138,38146]
trailer [39854,39862]
===
match
---
operator: = [11588,11589]
operator: = [11588,11589]
===
match
---
atom_expr [28661,28751]
atom_expr [30377,30467]
===
match
---
name: dag [31157,31160]
name: dag [32873,32876]
===
match
---
name: self [28472,28476]
name: self [30188,30192]
===
match
---
argument [58851,58886]
argument [60567,60602]
===
match
---
name: session [52684,52691]
name: session [54400,54407]
===
match
---
trailer [51170,51177]
trailer [52886,52893]
===
match
---
name: dag_id [33961,33967]
name: dag_id [35677,35683]
===
match
---
trailer [5227,5234]
trailer [5227,5234]
===
match
---
operator: } [10679,10680]
operator: } [10679,10680]
===
match
---
argument [48513,48531]
argument [50229,50247]
===
match
---
atom_expr [35971,35998]
atom_expr [37687,37714]
===
match
---
atom_expr [25301,25307]
atom_expr [27017,27023]
===
match
---
name: State [17267,17272]
name: State [17267,17272]
===
match
---
name: State [52303,52308]
name: State [54019,54024]
===
match
---
operator: { [8586,8587]
operator: { [8586,8587]
===
match
---
name: subdag_id [32330,32339]
name: subdag_id [34046,34055]
===
match
---
operator: , [12019,12020]
operator: , [12019,12020]
===
match
---
name: i [15838,15839]
name: i [15838,15839]
===
match
---
operator: @ [2752,2753]
operator: @ [2752,2753]
===
match
---
arglist [66807,66815]
arglist [68523,68531]
===
match
---
funcdef [47020,47290]
funcdef [48736,49006]
===
match
---
trailer [61037,61208]
trailer [62753,62924]
===
match
---
arith_expr [13612,13636]
arith_expr [13612,13636]
===
match
---
atom_expr [44803,44818]
atom_expr [46519,46534]
===
match
---
operator: , [56474,56475]
operator: , [58190,58191]
===
match
---
string: "depends_on_past" [66267,66284]
string: "depends_on_past" [67983,68000]
===
match
---
name: dag2 [57560,57564]
name: dag2 [59276,59280]
===
match
---
name: dag [53681,53684]
name: dag [55397,55400]
===
match
---
simple_stmt [44013,44039]
simple_stmt [45729,45755]
===
match
---
operator: , [21646,21647]
operator: , [21646,21647]
===
match
---
name: access_control [63708,63722]
name: access_control [65424,65438]
===
match
---
simple_stmt [53023,53173]
simple_stmt [54739,54889]
===
match
---
parameters [23488,23494]
parameters [23488,23494]
===
match
---
atom_expr [8045,8099]
atom_expr [8045,8099]
===
match
---
name: DagTag [26377,26383]
name: DagTag [28093,28099]
===
match
---
shift_expr [38542,38552]
shift_expr [40258,40268]
===
match
---
simple_stmt [66789,66817]
simple_stmt [68505,68533]
===
match
---
string: 'dag-bulk-sync-3' [25104,25121]
string: 'dag-bulk-sync-3' [26820,26837]
===
match
---
operator: , [19783,19784]
operator: , [19783,19784]
===
match
---
atom_expr [61356,61393]
atom_expr [63072,63109]
===
match
---
assert_stmt [13740,13782]
assert_stmt [13740,13782]
===
match
---
trailer [58041,58215]
trailer [59757,59931]
===
match
---
number: 5 [24648,24649]
number: 5 [26364,26365]
===
match
---
simple_stmt [25736,25910]
simple_stmt [27452,27626]
===
match
---
name: create_dagrun [43366,43379]
name: create_dagrun [45082,45095]
===
match
---
suite [14120,15162]
suite [14120,15162]
===
match
---
simple_stmt [35530,35562]
simple_stmt [37246,37278]
===
match
---
atom_expr [19224,19252]
atom_expr [19224,19252]
===
match
---
simple_stmt [23049,23086]
simple_stmt [23049,23086]
===
match
---
shift_expr [7999,8016]
shift_expr [7999,8016]
===
match
---
name: assert_called_with [40744,40762]
name: assert_called_with [42460,42478]
===
match
---
expr_stmt [38381,38414]
expr_stmt [40097,40130]
===
match
---
name: permissions [63143,63154]
name: permissions [64859,64870]
===
match
---
trailer [41640,41644]
trailer [43356,43360]
===
match
---
arglist [27690,27704]
arglist [29406,29420]
===
match
---
operator: == [46278,46280]
operator: == [47994,47996]
===
match
---
operator: == [22314,22316]
operator: == [22314,22316]
===
match
---
trailer [31725,31737]
trailer [33441,33453]
===
match
---
trailer [55578,55587]
trailer [57294,57303]
===
match
---
decorated [68500,68576]
decorated [70216,70292]
===
match
---
name: op4 [6526,6529]
name: op4 [6526,6529]
===
match
---
string: "test_schedule_dag_no_previous_runs" [39009,39045]
string: "test_schedule_dag_no_previous_runs" [40725,40761]
===
match
---
string: 'task' [51872,51878]
string: 'task' [53588,53594]
===
match
---
name: local_tz [22566,22574]
name: local_tz [22566,22574]
===
match
---
operator: , [32686,32687]
operator: , [34402,34403]
===
match
---
operator: = [44598,44599]
operator: = [46314,46315]
===
match
---
simple_stmt [49755,49801]
simple_stmt [51471,51517]
===
match
---
atom_expr [20467,20484]
atom_expr [20467,20484]
===
match
---
simple_stmt [1517,1570]
simple_stmt [1517,1570]
===
match
---
string: 'b_child' [8301,8310]
string: 'b_child' [8301,8310]
===
match
---
operator: = [30713,30714]
operator: = [32429,32430]
===
match
---
arglist [51122,51129]
arglist [52838,52845]
===
match
---
name: session [17964,17971]
name: session [17964,17971]
===
match
---
trailer [48524,48531]
trailer [50240,50247]
===
match
---
argument [30703,30726]
argument [32419,32442]
===
match
---
dictorsetmaker [16525,16542]
dictorsetmaker [16525,16542]
===
match
---
arglist [30802,30823]
arglist [32518,32539]
===
match
---
funcdef [40847,41975]
funcdef [42563,43691]
===
match
---
trailer [70463,70476]
trailer [72179,72192]
===
match
---
comparison [39389,39417]
comparison [41105,41133]
===
match
---
number: 10 [61390,61392]
number: 10 [63106,63108]
===
match
---
simple_stmt [65435,65454]
simple_stmt [67151,67170]
===
match
---
operator: , [2387,2388]
operator: , [2387,2388]
===
match
---
name: date [55886,55890]
name: date [57602,57606]
===
match
---
number: 1 [36672,36673]
number: 1 [38388,38389]
===
match
---
name: DEFAULT_DATE [38347,38359]
name: DEFAULT_DATE [40063,40075]
===
match
---
atom_expr [52684,52714]
atom_expr [54400,54430]
===
match
---
simple_stmt [27715,27766]
simple_stmt [29431,29482]
===
match
---
trailer [19689,19697]
trailer [19689,19697]
===
match
---
name: _clean_up [41957,41966]
name: _clean_up [43673,43682]
===
match
---
argument [64326,64340]
argument [66042,66056]
===
match
---
arglist [34896,34923]
arglist [36612,36639]
===
match
---
decorator [2752,2766]
decorator [2752,2766]
===
match
---
atom [13610,13650]
atom [13610,13650]
===
match
---
name: dag_id [55422,55428]
name: dag_id [57138,57144]
===
match
---
simple_stmt [39000,39046]
simple_stmt [40716,40762]
===
match
---
param [4841,4845]
param [4841,4845]
===
match
---
atom_expr [7828,7861]
atom_expr [7828,7861]
===
match
---
operator: = [63933,63934]
operator: = [65649,65650]
===
match
---
simple_stmt [33505,33522]
simple_stmt [35221,35238]
===
match
---
assert_stmt [41816,41856]
assert_stmt [43532,43572]
===
match
---
name: user_defined_filters [18609,18629]
name: user_defined_filters [18609,18629]
===
match
---
name: session [25715,25722]
name: session [27431,27438]
===
match
---
trailer [40525,40574]
trailer [42241,42290]
===
match
---
name: int [14886,14889]
name: int [14886,14889]
===
match
---
operator: = [69793,69794]
operator: = [71509,71510]
===
match
---
comparison [28408,28446]
comparison [30124,30162]
===
match
---
operator: = [63036,63037]
operator: = [64752,64753]
===
match
---
atom [19333,19348]
atom [19333,19348]
===
match
---
trailer [57046,57058]
trailer [58762,58774]
===
match
---
trailer [12574,12582]
trailer [12574,12582]
===
match
---
simple_stmt [28652,28752]
simple_stmt [30368,30468]
===
match
---
arglist [5614,5644]
arglist [5614,5644]
===
match
---
operator: , [32964,32965]
operator: , [34680,34681]
===
match
---
string: 'D' [8898,8901]
string: 'D' [8898,8901]
===
match
---
fstring_expr [12987,12990]
fstring_expr [12987,12990]
===
match
---
operator: == [4467,4469]
operator: == [4467,4469]
===
match
---
name: execution_date [39633,39647]
name: execution_date [41349,41363]
===
match
---
name: on_success_callback [40268,40287]
name: on_success_callback [41984,42003]
===
match
---
operator: } [63118,63119]
operator: } [64834,64835]
===
match
---
atom_expr [47478,47488]
atom_expr [49194,49204]
===
match
---
name: clear [48815,48820]
name: clear [50531,50536]
===
match
---
argument [48717,48736]
argument [50433,50452]
===
match
---
trailer [66329,66331]
trailer [68045,68047]
===
match
---
suite [5126,5392]
suite [5126,5392]
===
match
---
name: dag [45408,45411]
name: dag [47124,47127]
===
match
---
simple_stmt [19861,19897]
simple_stmt [19861,19897]
===
match
---
dictorsetmaker [5967,5984]
dictorsetmaker [5967,5984]
===
match
---
name: orm_dag [33082,33089]
name: orm_dag [34798,34805]
===
match
---
operator: - [57026,57027]
operator: - [58742,58743]
===
match
---
trailer [36576,36582]
trailer [38292,38298]
===
match
---
name: isoformat [22302,22311]
name: isoformat [22302,22311]
===
match
---
trailer [25237,25243]
trailer [26953,26959]
===
match
---
atom_expr [59156,59193]
atom_expr [60872,60909]
===
match
---
name: DummyOperator [6110,6123]
name: DummyOperator [6110,6123]
===
match
---
simple_stmt [65402,65426]
simple_stmt [67118,67142]
===
match
---
atom_expr [67691,67701]
atom_expr [69407,69417]
===
match
---
atom_expr [52749,53013]
atom_expr [54465,54729]
===
match
---
param [9437,9441]
param [9437,9441]
===
match
---
atom_expr [7144,7151]
atom_expr [7144,7151]
===
match
---
expr_stmt [37995,38028]
expr_stmt [39711,39744]
===
match
---
trailer [22311,22313]
trailer [22311,22313]
===
match
---
simple_stmt [32193,32394]
simple_stmt [33909,34110]
===
match
---
funcdef [56003,58399]
funcdef [57719,60115]
===
match
---
simple_stmt [65462,65478]
simple_stmt [67178,67194]
===
match
---
expr_stmt [56673,56715]
expr_stmt [58389,58431]
===
match
---
atom_expr [65969,65992]
atom_expr [67685,67708]
===
match
---
trailer [45821,45835]
trailer [47537,47551]
===
match
---
expr_stmt [22558,22651]
expr_stmt [22558,22651]
===
match
---
operator: , [46837,46838]
operator: , [48553,48554]
===
match
---
name: next_dagrun_after_date [55017,55039]
name: next_dagrun_after_date [56733,56755]
===
match
---
decorator [66658,66705]
decorator [68374,68421]
===
match
---
simple_stmt [67930,67988]
simple_stmt [69646,69704]
===
match
---
name: start_date [22727,22737]
name: start_date [22727,22737]
===
match
---
name: self [34779,34783]
name: self [36495,36499]
===
match
---
name: pattern [13987,13994]
name: pattern [13987,13994]
===
match
---
simple_stmt [17288,17371]
simple_stmt [17288,17371]
===
match
---
name: last_loaded [44789,44800]
name: last_loaded [46505,46516]
===
match
---
name: test_task_id [18047,18059]
name: test_task_id [18047,18059]
===
match
---
operator: , [53675,53676]
operator: , [55391,55392]
===
match
---
operator: = [34803,34804]
operator: = [36519,36520]
===
match
---
trailer [63707,63722]
trailer [65423,65438]
===
match
---
operator: = [42410,42411]
operator: = [44126,44127]
===
match
---
name: name [19101,19105]
name: name [19101,19105]
===
match
---
assert_stmt [45289,45321]
assert_stmt [47005,47037]
===
match
---
name: jinja_env [18722,18731]
name: jinja_env [18722,18731]
===
match
---
expr_stmt [10037,10078]
expr_stmt [10037,10078]
===
match
---
argument [57155,57194]
argument [58871,58910]
===
match
---
simple_stmt [9729,9762]
simple_stmt [9729,9762]
===
match
---
expr_stmt [47078,47117]
expr_stmt [48794,48833]
===
match
---
name: local_tz [35015,35023]
name: local_tz [36731,36739]
===
match
---
string: 'start_date' [43927,43939]
string: 'start_date' [45643,45655]
===
match
---
trailer [27810,27824]
trailer [29526,29540]
===
match
---
name: half_an_hour_ago [57489,57505]
name: half_an_hour_ago [59205,59221]
===
match
---
operator: = [21466,21467]
operator: = [21466,21467]
===
match
---
name: dag [1590,1593]
name: dag [1590,1593]
===
match
---
atom_expr [12352,12397]
atom_expr [12352,12397]
===
match
---
operator: == [61353,61355]
operator: == [63069,63071]
===
match
---
operator: = [41224,41225]
operator: = [42940,42941]
===
match
---
arglist [12012,12022]
arglist [12012,12022]
===
match
---
decorator [30550,30567]
decorator [32266,32283]
===
match
---
trailer [13031,13041]
trailer [13031,13041]
===
match
---
atom_expr [48811,49074]
atom_expr [50527,50790]
===
match
---
operator: , [57742,57743]
operator: , [59458,59459]
===
match
---
trailer [26368,26375]
trailer [28084,28091]
===
match
---
simple_stmt [18960,18981]
simple_stmt [18960,18981]
===
match
---
simple_stmt [10037,10079]
simple_stmt [10037,10079]
===
match
---
operator: , [56318,56319]
operator: , [58034,58035]
===
match
---
atom_expr [70357,70370]
atom_expr [72073,72086]
===
match
---
expr_stmt [66410,66454]
expr_stmt [68126,68170]
===
match
---
trailer [9009,9026]
trailer [9009,9026]
===
match
---
operator: , [59625,59626]
operator: , [61341,61342]
===
match
---
number: 2 [10399,10400]
number: 2 [10399,10400]
===
match
---
assert_stmt [66868,66898]
assert_stmt [68584,68614]
===
match
---
name: DEFAULT_DATE [70492,70504]
name: DEFAULT_DATE [72208,72220]
===
match
---
trailer [29291,29304]
trailer [31007,31020]
===
match
---
expr_stmt [13951,13960]
expr_stmt [13951,13960]
===
match
---
operator: = [31395,31396]
operator: = [33111,33112]
===
match
---
comparison [43634,43666]
comparison [45350,45382]
===
match
---
trailer [17572,17574]
trailer [17572,17574]
===
match
---
atom_expr [61755,61914]
atom_expr [63471,63630]
===
match
---
argument [49048,49063]
argument [50764,50779]
===
match
---
operator: == [6945,6947]
operator: == [6945,6947]
===
match
---
name: convert [21477,21484]
name: convert [21477,21484]
===
match
---
term [15005,15038]
term [15005,15038]
===
match
---
operator: = [19080,19081]
operator: = [19080,19081]
===
match
---
operator: , [51128,51129]
operator: , [52844,52845]
===
match
---
expr_stmt [19266,19297]
expr_stmt [19266,19297]
===
match
---
name: test_get_num_task_instances [16681,16708]
name: test_get_num_task_instances [16681,16708]
===
match
---
name: DagRunType [50100,50110]
name: DagRunType [51816,51826]
===
match
---
dotted_name [2111,2130]
dotted_name [2111,2130]
===
match
---
name: dag1 [57126,57130]
name: dag1 [58842,58846]
===
match
---
operator: , [48715,48716]
operator: , [50431,50432]
===
match
---
argument [17064,17120]
argument [17064,17120]
===
match
---
trailer [62709,62715]
trailer [64425,64431]
===
match
---
trailer [6383,6398]
trailer [6383,6398]
===
match
---
operator: , [59032,59033]
operator: , [60748,60749]
===
match
---
assert_stmt [46885,46956]
assert_stmt [48601,48672]
===
match
---
argument [36206,36229]
argument [37922,37945]
===
match
---
name: local_tz [35118,35126]
name: local_tz [36834,36842]
===
match
---
simple_stmt [1043,1075]
simple_stmt [1043,1075]
===
match
---
atom_expr [35118,35131]
atom_expr [36834,36847]
===
match
---
atom [24323,24442]
atom [26039,26158]
===
match
---
operator: == [54644,54646]
operator: == [56360,56362]
===
match
---
trailer [57107,57116]
trailer [58823,58832]
===
match
---
simple_stmt [65126,65147]
simple_stmt [66842,66863]
===
match
---
argument [50137,50155]
argument [51853,51871]
===
match
---
name: dag [7239,7242]
name: dag [7239,7242]
===
match
---
expr_stmt [38473,38506]
expr_stmt [40189,40222]
===
match
---
name: DAG [20616,20619]
name: DAG [20616,20619]
===
match
---
simple_stmt [35038,35082]
simple_stmt [36754,36798]
===
match
---
simple_stmt [64389,64405]
simple_stmt [66105,66121]
===
match
---
name: DummyOperator [38479,38492]
name: DummyOperator [40195,40208]
===
match
---
atom_expr [46809,46875]
atom_expr [48525,48591]
===
match
---
operator: = [48360,48361]
operator: = [50076,50077]
===
match
---
trailer [70074,70083]
trailer [71790,71799]
===
match
---
operator: = [8874,8875]
operator: = [8874,8875]
===
match
---
name: test_fractional_seconds [42975,42998]
name: test_fractional_seconds [44691,44714]
===
match
---
operator: = [42390,42391]
operator: = [44106,44107]
===
match
---
expr_stmt [19710,19750]
expr_stmt [19710,19750]
===
match
---
trailer [51353,51361]
trailer [53069,53077]
===
match
---
expr_stmt [20299,20344]
expr_stmt [20299,20344]
===
match
---
operator: = [5542,5543]
operator: = [5542,5543]
===
match
---
argument [62140,62180]
argument [63856,63896]
===
match
---
name: dag_id [49577,49583]
name: dag_id [51293,51299]
===
match
---
trailer [70573,70575]
trailer [72289,72291]
===
match
---
operator: = [35373,35374]
operator: = [37089,37090]
===
match
---
trailer [16576,16594]
trailer [16576,16594]
===
match
---
name: local_tz [21965,21973]
name: local_tz [21965,21973]
===
match
---
operator: == [47975,47977]
operator: == [49691,49693]
===
match
---
name: DummyOperator [8786,8799]
name: DummyOperator [8786,8799]
===
match
---
assert_stmt [34987,35028]
assert_stmt [36703,36744]
===
match
---
atom_expr [31425,31440]
atom_expr [33141,33156]
===
match
---
simple_stmt [7058,7093]
simple_stmt [7058,7093]
===
match
---
comparison [13747,13782]
comparison [13747,13782]
===
match
---
name: self [10769,10773]
name: self [10769,10773]
===
match
---
simple_stmt [55768,55808]
simple_stmt [57484,57524]
===
match
---
argument [5928,5951]
argument [5928,5951]
===
match
---
atom_expr [30663,30737]
atom_expr [32379,32453]
===
match
---
expr_stmt [23657,23688]
expr_stmt [23657,23688]
===
match
---
name: creating_job_id [47959,47974]
name: creating_job_id [49675,49690]
===
match
---
name: args [61662,61666]
name: args [63378,63382]
===
match
---
name: DagRunType [48476,48486]
name: DagRunType [50192,50202]
===
match
---
name: datetime [60091,60099]
name: datetime [61807,61815]
===
match
---
argument [55303,55310]
argument [57019,57026]
===
match
---
trailer [20377,20451]
trailer [20377,20451]
===
match
---
number: 1 [46648,46649]
number: 1 [48364,48365]
===
match
---
name: task_depth [13478,13488]
name: task_depth [13478,13488]
===
match
---
string: 'Also fake' [41301,41312]
string: 'Also fake' [43017,43028]
===
match
---
fstring_start: f" [47252,47254]
fstring_start: f" [48968,48970]
===
match
---
name: dr [27943,27945]
name: dr [29659,29661]
===
match
---
operator: = [41469,41470]
operator: = [43185,43186]
===
match
---
trailer [12044,12053]
trailer [12044,12053]
===
match
---
simple_stmt [56673,56716]
simple_stmt [58389,58432]
===
match
---
operator: == [46994,46996]
operator: == [48710,48712]
===
match
---
argument [49703,49726]
argument [51419,51442]
===
match
---
atom [26145,26176]
atom [27861,27892]
===
match
---
expr_stmt [46803,46875]
expr_stmt [48519,48591]
===
match
---
trailer [67290,67297]
trailer [69006,69013]
===
match
---
operator: , [35253,35254]
operator: , [36969,36970]
===
match
---
name: State [27985,27990]
name: State [29701,29706]
===
match
---
atom_expr [11955,12025]
atom_expr [11955,12025]
===
match
---
trailer [15080,15102]
trailer [15080,15102]
===
match
---
name: dag [59156,59159]
name: dag [60872,60875]
===
match
---
operator: = [28026,28027]
operator: = [29742,29743]
===
match
---
simple_stmt [55475,55567]
simple_stmt [57191,57283]
===
match
---
operator: , [25085,25086]
operator: , [26801,26802]
===
match
---
name: session [31830,31837]
name: session [33546,33553]
===
match
---
name: hash [45728,45732]
name: hash [47444,47448]
===
match
---
string: "2018-03-24T02:00:00+00:00" [22968,22995]
string: "2018-03-24T02:00:00+00:00" [22968,22995]
===
match
---
trailer [52543,52551]
trailer [54259,54267]
===
match
---
string: "STORE_DAG_CODE" [34133,34149]
string: "STORE_DAG_CODE" [35849,35865]
===
match
---
name: default_args [67029,67041]
name: default_args [68745,68757]
===
match
---
name: dag [66832,66835]
name: dag [68548,68551]
===
match
---
trailer [24875,24881]
trailer [26591,26597]
===
match
---
name: schedule_interval [57208,57225]
name: schedule_interval [58924,58941]
===
match
---
expr_stmt [33082,33170]
expr_stmt [34798,34886]
===
match
---
name: task_id [35366,35373]
name: task_id [37082,37089]
===
match
---
name: op1 [37662,37665]
name: op1 [39378,39381]
===
match
---
suite [24103,24443]
suite [25819,26159]
===
match
---
trailer [5016,5020]
trailer [5016,5020]
===
match
---
param [19526,19530]
param [19526,19530]
===
match
---
name: compile [12575,12582]
name: compile [12575,12582]
===
match
---
simple_stmt [36056,36093]
simple_stmt [37772,37809]
===
match
---
decorator [58404,58448]
decorator [60120,60164]
===
match
---
simple_stmt [22872,22933]
simple_stmt [22872,22933]
===
match
---
name: dag [65042,65045]
name: dag [66758,66761]
===
match
---
name: needed [65249,65255]
name: needed [66965,66971]
===
match
---
expr_stmt [9729,9761]
expr_stmt [9729,9761]
===
match
---
name: synchronize_session [31295,31314]
name: synchronize_session [33011,33030]
===
match
---
atom [24752,24828]
atom [26468,26544]
===
match
---
assert_stmt [39347,39373]
assert_stmt [41063,41089]
===
match
---
simple_stmt [6678,6707]
simple_stmt [6678,6707]
===
match
---
name: lower [33755,33760]
name: lower [35471,35476]
===
match
---
trailer [14530,14540]
trailer [14530,14540]
===
match
---
name: tasks [9139,9144]
name: tasks [9139,9144]
===
match
---
operator: , [24203,24204]
operator: , [25919,25920]
===
match
---
name: dag_id [41967,41973]
name: dag_id [43683,43689]
===
match
---
name: dag_id [63516,63522]
name: dag_id [65232,65238]
===
match
---
trailer [56637,56660]
trailer [58353,58376]
===
match
---
name: task_id [38157,38164]
name: task_id [39873,39880]
===
match
---
trailer [4426,4435]
trailer [4426,4435]
===
match
---
name: utils [2119,2124]
name: utils [2119,2124]
===
match
---
name: op2 [37669,37672]
name: op2 [39385,39388]
===
match
---
atom_expr [66765,66780]
atom_expr [68481,68496]
===
match
---
atom_expr [46231,46322]
atom_expr [47947,48038]
===
match
---
name: session [17848,17855]
name: session [17848,17855]
===
match
---
simple_stmt [57980,58017]
simple_stmt [59696,59733]
===
match
---
name: PRE_TRANSITION [21539,21553]
name: PRE_TRANSITION [21539,21553]
===
match
---
trailer [18994,19000]
trailer [18994,19000]
===
match
---
name: __table__ [34640,34649]
name: __table__ [36356,36365]
===
match
---
expr_stmt [50049,50244]
expr_stmt [51765,51960]
===
match
---
name: dag_id [51584,51590]
name: dag_id [53300,53306]
===
match
---
arglist [20396,20415]
arglist [20396,20415]
===
match
---
name: DEFAULT_DATE [50649,50661]
name: DEFAULT_DATE [52365,52377]
===
match
---
trailer [31474,31481]
trailer [33190,33197]
===
match
---
name: default_args [44329,44341]
name: default_args [46045,46057]
===
match
---
atom_expr [14843,14855]
atom_expr [14843,14855]
===
match
---
name: default_args [11735,11747]
name: default_args [11735,11747]
===
match
---
parameters [61628,61667]
parameters [63344,63383]
===
match
---
name: create_session [1977,1991]
name: create_session [1977,1991]
===
match
---
name: child_dag [7322,7331]
name: child_dag [7322,7331]
===
match
---
argument [44329,44346]
argument [46045,46062]
===
match
---
trailer [19605,19611]
trailer [19605,19611]
===
match
---
trailer [16015,16022]
trailer [16015,16022]
===
match
---
comparison [45690,45712]
comparison [47406,47428]
===
match
---
operator: = [19185,19186]
operator: = [19185,19186]
===
match
---
simple_stmt [68842,68902]
simple_stmt [70558,70618]
===
match
---
string: """         Make sure DST transitions are properly observed         """ [21326,21397]
string: """         Make sure DST transitions are properly observed         """ [21326,21397]
===
match
---
expr_stmt [55276,55311]
expr_stmt [56992,57027]
===
match
---
name: utcnow [58008,58014]
name: utcnow [59724,59730]
===
match
---
atom_expr [23236,23264]
atom_expr [23236,23264]
===
match
---
atom_expr [5544,5589]
atom_expr [5544,5589]
===
match
---
operator: , [25121,25122]
operator: , [26837,26838]
===
match
---
operator: = [37611,37612]
operator: = [39327,39328]
===
match
---
name: dag_id [24891,24897]
name: dag_id [26607,26613]
===
match
---
decorator [68001,68017]
decorator [69717,69733]
===
match
---
decorated [69766,70119]
decorated [71482,71835]
===
match
---
trailer [32153,32167]
trailer [33869,33883]
===
match
---
expr_stmt [28905,28928]
expr_stmt [30621,30644]
===
match
---
name: DEFAULT_DATE [37008,37020]
name: DEFAULT_DATE [38724,38736]
===
match
---
atom_expr [59650,59679]
atom_expr [61366,61395]
===
match
---
trailer [37626,37649]
trailer [39342,39365]
===
match
---
string: "run_type_is_obtained_from_run_id" [47383,47417]
string: "run_type_is_obtained_from_run_id" [49099,49133]
===
match
---
with_stmt [28572,29006]
with_stmt [30288,30722]
===
match
---
name: clear_db_dags [2326,2339]
name: clear_db_dags [2326,2339]
===
match
---
name: get_default_view [33691,33707]
name: get_default_view [35407,35423]
===
match
---
number: 1 [49298,49299]
number: 1 [51014,51015]
===
match
---
dictorsetmaker [63377,63433]
dictorsetmaker [65093,65149]
===
match
---
number: 0 [10177,10178]
number: 0 [10177,10178]
===
match
---
param [2784,2795]
param [2784,2795]
===
match
---
expr_stmt [8735,8767]
expr_stmt [8735,8767]
===
match
---
comparison [32019,32110]
comparison [33735,33826]
===
match
---
trailer [19742,19750]
trailer [19742,19750]
===
match
---
arglist [13074,13082]
arglist [13074,13082]
===
match
---
name: start_date [28713,28723]
name: start_date [30429,30439]
===
match
---
operator: = [65296,65297]
operator: = [67012,67013]
===
match
---
name: dag [45940,45943]
name: dag [47656,47659]
===
match
---
name: DagTag [27047,27053]
name: DagTag [28763,28769]
===
match
---
simple_stmt [9639,9672]
simple_stmt [9639,9672]
===
match
---
name: self [64605,64609]
name: self [66321,66325]
===
match
---
name: params_combined [4404,4419]
name: params_combined [4404,4419]
===
match
---
trailer [42809,42819]
trailer [44525,44535]
===
match
---
name: orm_dag [29251,29258]
name: orm_dag [30967,30974]
===
match
---
name: op4 [36033,36036]
name: op4 [37749,37752]
===
match
---
name: op2 [56790,56793]
name: op2 [58506,58509]
===
match
---
operator: , [48857,48858]
operator: , [50573,50574]
===
match
---
operator: = [63510,63511]
operator: = [65226,65227]
===
match
---
simple_stmt [8735,8768]
simple_stmt [8735,8768]
===
match
---
param [16709,16713]
param [16709,16713]
===
match
---
operator: , [26176,26177]
operator: , [27892,27893]
===
match
---
with_item [35720,35767]
with_item [37436,37483]
===
match
---
name: _next [23079,23084]
name: _next [23079,23084]
===
match
---
operator: , [60773,60774]
operator: , [62489,62490]
===
match
---
trailer [46244,46254]
trailer [47960,47970]
===
match
---
comparison [49282,49299]
comparison [50998,51015]
===
match
---
name: i [13292,13293]
name: i [13292,13293]
===
match
---
number: 1 [4227,4228]
number: 1 [4227,4228]
===
match
---
name: dag [6223,6226]
name: dag [6223,6226]
===
match
---
argument [30142,30251]
argument [31858,31967]
===
match
---
simple_stmt [33938,34021]
simple_stmt [35654,35737]
===
match
---
operator: == [59004,59006]
operator: == [60720,60722]
===
match
---
operator: , [58088,58089]
operator: , [59804,59805]
===
match
---
atom_expr [21616,21678]
atom_expr [21616,21678]
===
match
---
operator: , [26946,26947]
operator: , [28662,28663]
===
match
---
name: enumerate [14521,14530]
name: enumerate [14521,14530]
===
match
---
operator: = [38408,38409]
operator: = [40124,40125]
===
match
---
operator: = [53757,53758]
operator: = [55473,55474]
===
match
---
param [24474,24478]
param [26190,26194]
===
match
---
name: dag_id [31853,31859]
name: dag_id [33569,33575]
===
match
---
name: self [23489,23493]
name: self [23489,23493]
===
match
---
string: 'creating_dag_in_cm' [6762,6782]
string: 'creating_dag_in_cm' [6762,6782]
===
match
---
operator: { [6052,6053]
operator: { [6052,6053]
===
match
---
trailer [57575,57753]
trailer [59291,59469]
===
match
---
trailer [71068,71075]
trailer [72784,72791]
===
match
---
atom_expr [63973,64029]
atom_expr [65689,65745]
===
match
---
trailer [31869,31879]
trailer [33585,33595]
===
match
---
name: self [37783,37787]
name: self [39499,39503]
===
match
---
name: add_task [43221,43229]
name: add_task [44937,44945]
===
match
---
operator: = [43904,43905]
operator: = [45620,45621]
===
match
---
operator: , [22605,22606]
operator: , [22605,22606]
===
match
---
name: State [50143,50148]
name: State [51859,51864]
===
match
---
argument [65933,65945]
argument [67649,67661]
===
match
---
fstring_end: ' [14245,14246]
fstring_end: ' [14245,14246]
===
match
---
number: 1 [55309,55310]
number: 1 [57025,57026]
===
match
---
name: dag_id [27054,27060]
name: dag_id [28770,28776]
===
match
---
name: pytest [63658,63664]
name: pytest [65374,65380]
===
match
---
trailer [43599,43615]
trailer [45315,45331]
===
match
---
name: query [32229,32234]
name: query [33945,33950]
===
match
---
name: _occur_before [8121,8134]
name: _occur_before [8121,8134]
===
match
---
name: execution_date [42574,42588]
name: execution_date [44290,44304]
===
match
---
operator: , [59873,59874]
operator: , [61589,61590]
===
match
---
expr_stmt [56618,56660]
expr_stmt [58334,58376]
===
match
---
name: NamedTemporaryFile [970,988]
name: NamedTemporaryFile [970,988]
===
match
---
name: dag [55575,55578]
name: dag [57291,57294]
===
match
---
name: BaseOperator [55588,55600]
name: BaseOperator [57304,57316]
===
match
---
param [34779,34783]
param [36495,36499]
===
match
---
atom_expr [46972,46993]
atom_expr [48688,48709]
===
match
---
parameters [67144,67149]
parameters [68860,68865]
===
match
---
expr_stmt [63506,63586]
expr_stmt [65222,65302]
===
match
---
name: models [1635,1641]
name: models [1635,1641]
===
match
---
operator: , [8310,8311]
operator: , [8310,8311]
===
match
---
comparison [30489,30520]
comparison [32205,32236]
===
match
---
suite [15449,16362]
suite [15449,16362]
===
match
---
simple_stmt [30870,30948]
simple_stmt [32586,32664]
===
match
---
name: DEFAULT_DATE [37526,37538]
name: DEFAULT_DATE [39242,39254]
===
match
---
name: test_dags_needing_dagruns_only_unpaused [64565,64604]
name: test_dags_needing_dagruns_only_unpaused [66281,66320]
===
match
---
operator: = [60686,60687]
operator: = [62402,62403]
===
match
---
name: DEFAULT_DATE [48556,48568]
name: DEFAULT_DATE [50272,50284]
===
match
---
trailer [10200,10207]
trailer [10200,10207]
===
match
---
operator: { [24938,24939]
operator: { [26654,26655]
===
match
---
name: DAG [36190,36193]
name: DAG [37906,37909]
===
match
---
name: models [1250,1256]
name: models [1250,1256]
===
match
---
simple_stmt [6715,6744]
simple_stmt [6715,6744]
===
match
---
atom_expr [52053,52076]
atom_expr [53769,53792]
===
match
---
name: dagrun_1 [53748,53756]
name: dagrun_1 [55464,55472]
===
match
---
trailer [47901,47906]
trailer [49617,49622]
===
match
---
string: 'start_date' [11748,11760]
string: 'start_date' [11748,11760]
===
match
---
suite [15870,16085]
suite [15870,16085]
===
match
---
argument [56748,56760]
argument [58464,58476]
===
match
---
name: start_date [57254,57264]
name: start_date [58970,58980]
===
match
---
trailer [68160,68170]
trailer [69876,69886]
===
match
---
string: 'owner' [9508,9515]
string: 'owner' [9508,9515]
===
match
---
name: test_sync_to_db [28456,28471]
name: test_sync_to_db [30172,30187]
===
match
---
name: create_dagrun [50064,50077]
name: create_dagrun [51780,51793]
===
match
---
name: noop_pipeline [68466,68479]
name: noop_pipeline [70182,70195]
===
match
---
trailer [25156,25205]
trailer [26872,26921]
===
match
---
argument [50091,50123]
argument [51807,51839]
===
match
---
operator: , [15740,15741]
operator: , [15740,15741]
===
match
---
comparison [60069,60111]
comparison [61785,61827]
===
match
---
operator: - [13294,13295]
operator: - [13294,13295]
===
match
---
number: 0 [9133,9134]
number: 0 [9133,9134]
===
match
---
argument [6186,6194]
argument [6186,6194]
===
match
---
trailer [2865,2873]
trailer [2865,2873]
===
match
---
name: dag3 [58237,58241]
name: dag3 [59953,59957]
===
match
---
with_stmt [15367,16362]
with_stmt [15367,16362]
===
match
---
trailer [60948,60954]
trailer [62664,62670]
===
match
---
atom_expr [22515,22549]
atom_expr [22515,22549]
===
match
---
argument [50995,51018]
argument [52711,52734]
===
match
---
operator: == [21868,21870]
operator: == [21868,21870]
===
match
---
trailer [30448,30461]
trailer [32164,32177]
===
match
---
name: value [68480,68485]
name: value [70196,70201]
===
match
---
name: dag [43362,43365]
name: dag [45078,45081]
===
match
---
name: dag [45619,45622]
name: dag [47335,47338]
===
match
---
atom_expr [34427,34447]
atom_expr [36143,36163]
===
match
---
argument [4736,4770]
argument [4736,4770]
===
match
---
number: 0 [36629,36630]
number: 0 [38345,38346]
===
match
---
name: VALUE [68997,69002]
name: VALUE [70713,70718]
===
match
---
funcdef [66713,66750]
funcdef [68429,68466]
===
match
---
param [47351,47355]
param [49067,49071]
===
match
---
operator: , [35555,35556]
operator: , [37271,37272]
===
match
---
assert_stmt [54617,54659]
assert_stmt [56333,56375]
===
match
---
trailer [19681,19689]
trailer [19681,19689]
===
match
---
dictorsetmaker [18631,18649]
dictorsetmaker [18631,18649]
===
match
---
simple_stmt [66605,66621]
simple_stmt [68321,68337]
===
match
---
operator: == [60079,60081]
operator: == [61795,61797]
===
match
---
atom_expr [37214,37225]
atom_expr [38930,38941]
===
match
---
name: row [24861,24864]
name: row [26577,26580]
===
match
---
operator: , [42422,42423]
operator: , [44138,44139]
===
match
---
trailer [22160,22167]
trailer [22160,22167]
===
match
---
name: updated_permissions [63783,63802]
name: updated_permissions [65499,65518]
===
match
---
argument [35255,35278]
argument [36971,36994]
===
match
---
testlist_comp [14162,14478]
testlist_comp [14162,14478]
===
match
---
string: 'test' [65939,65945]
string: 'test' [67655,67661]
===
match
---
simple_stmt [804,814]
simple_stmt [804,814]
===
match
---
name: dag [26433,26436]
name: dag [28149,28152]
===
match
---
operator: = [44490,44491]
operator: = [46206,46207]
===
match
---
operator: , [2564,2565]
operator: , [2564,2565]
===
match
---
simple_stmt [34615,34693]
simple_stmt [36331,36409]
===
match
---
atom_expr [17255,17264]
atom_expr [17255,17264]
===
match
---
string: "retries" [66341,66350]
string: "retries" [68057,68066]
===
match
---
name: is_paused [32168,32177]
name: is_paused [33884,33893]
===
match
---
name: task_instance_2 [52561,52576]
name: task_instance_2 [54277,54292]
===
match
---
name: op5 [35557,35560]
name: op5 [37273,37276]
===
match
---
operator: = [20744,20745]
operator: = [20744,20745]
===
match
---
name: list_ [3338,3343]
name: list_ [3338,3343]
===
match
---
with_stmt [37877,38075]
with_stmt [39593,39791]
===
match
---
atom [18330,18344]
atom [18330,18344]
===
match
---
name: task_id [35893,35900]
name: task_id [37609,37616]
===
match
---
simple_stmt [45436,45468]
simple_stmt [47152,47184]
===
match
---
name: utc [20720,20723]
name: utc [20720,20723]
===
match
---
trailer [69311,69318]
trailer [71027,71034]
===
match
---
number: 2 [4263,4264]
number: 2 [4263,4264]
===
match
---
name: default_view [30497,30509]
name: default_view [32213,32225]
===
match
---
name: next_date [60258,60267]
name: next_date [61974,61983]
===
match
---
arglist [17714,17758]
arglist [17714,17758]
===
match
---
atom_expr [23665,23688]
atom_expr [23665,23688]
===
match
---
trailer [45748,45753]
trailer [47464,47469]
===
match
---
funcdef [8485,9401]
funcdef [8485,9401]
===
match
---
name: f [18993,18994]
name: f [18993,18994]
===
match
---
expr_stmt [56388,56604]
expr_stmt [58104,58320]
===
match
---
name: subdag_id [31254,31263]
name: subdag_id [32970,32979]
===
match
---
suite [36466,36542]
suite [38182,38258]
===
match
---
name: op2 [38217,38220]
name: op2 [39933,39936]
===
match
---
expr_stmt [48388,48416]
expr_stmt [50104,50132]
===
match
---
funcdef [60332,61394]
funcdef [62048,63110]
===
match
---
argument [24165,24188]
argument [25881,25904]
===
match
---
assert_stmt [65402,65425]
assert_stmt [67118,67141]
===
match
---
atom_expr [2952,3031]
atom_expr [2952,3031]
===
match
---
expr_stmt [16216,16239]
expr_stmt [16216,16239]
===
match
---
return_stmt [68565,68575]
return_stmt [70281,70291]
===
match
---
name: start_date [24547,24557]
name: start_date [26263,26273]
===
match
---
atom_expr [33092,33170]
atom_expr [34808,34886]
===
match
---
assert_stmt [35575,35610]
assert_stmt [37291,37326]
===
match
---
name: task_id [35985,35992]
name: task_id [37701,37708]
===
match
---
param [68044,68047]
param [69760,69763]
===
match
---
operator: = [43327,43328]
operator: = [45043,45044]
===
match
---
simple_stmt [24489,24505]
simple_stmt [26205,26221]
===
match
---
expr_stmt [44242,44297]
expr_stmt [45958,46013]
===
match
---
suite [42775,42839]
suite [44491,44555]
===
match
---
name: i [3462,3463]
name: i [3462,3463]
===
match
---
name: isoformat [23336,23345]
name: isoformat [23336,23345]
===
match
---
name: provide_session [30551,30566]
name: provide_session [32267,32282]
===
match
---
simple_stmt [9900,9924]
simple_stmt [9900,9924]
===
match
---
trailer [27040,27046]
trailer [28756,28762]
===
match
---
simple_stmt [50049,50245]
simple_stmt [51765,51961]
===
match
---
funcdef [67311,67719]
funcdef [69027,69435]
===
match
---
argument [9494,9526]
argument [9494,9526]
===
match
---
name: subdag [28991,28997]
name: subdag [30707,30713]
===
match
---
name: dag [6924,6927]
name: dag [6924,6927]
===
match
---
name: filter [34246,34252]
name: filter [35962,35968]
===
match
---
atom_expr [52260,52283]
atom_expr [53976,53999]
===
match
---
atom_expr [39196,39338]
atom_expr [40912,41054]
===
match
---
name: DAG [44210,44213]
name: DAG [45926,45929]
===
match
---
param [56042,56046]
param [57758,57762]
===
match
---
simple_stmt [42186,42220]
simple_stmt [43902,43936]
===
match
---
atom_expr [42370,42445]
atom_expr [44086,44161]
===
match
---
trailer [22025,22027]
trailer [22025,22027]
===
match
---
atom_expr [23171,23188]
atom_expr [23171,23188]
===
match
---
name: return_num [67595,67605]
name: return_num [69311,69321]
===
match
---
name: dags [25676,25680]
name: dags [27392,27396]
===
match
---
atom [46594,46609]
atom [48310,48325]
===
match
---
string: 'test-dag' [26066,26076]
string: 'test-dag' [27782,27792]
===
match
---
argument [36363,36375]
argument [38079,38091]
===
match
---
parameters [35151,35157]
parameters [36867,36873]
===
match
---
name: DagRun [53077,53083]
name: DagRun [54793,54799]
===
match
---
atom_expr [64283,64312]
atom_expr [65999,66028]
===
match
---
name: DEFAULT_DATE [47192,47204]
name: DEFAULT_DATE [48908,48920]
===
match
---
name: dag [60231,60234]
name: dag [61947,61950]
===
match
---
name: task_instance_1 [54122,54137]
name: task_instance_1 [55838,55853]
===
match
---
dotted_name [47991,48011]
dotted_name [49707,49727]
===
match
---
argument [14320,14351]
argument [14320,14351]
===
match
---
name: start_date [43724,43734]
name: start_date [45440,45450]
===
match
---
operator: , [46650,46651]
operator: , [48366,48367]
===
match
---
name: dr [70519,70521]
name: dr [72235,72237]
===
match
---
operator: < [57997,57998]
operator: < [59713,59714]
===
match
---
atom_expr [19046,19052]
atom_expr [19046,19052]
===
match
---
simple_stmt [8338,8405]
simple_stmt [8338,8405]
===
match
---
atom_expr [47505,47516]
atom_expr [49221,49232]
===
match
---
expr_stmt [34029,34054]
expr_stmt [35745,35770]
===
match
---
string: 'airflow.models.dag.Stats' [39803,39829]
string: 'airflow.models.dag.Stats' [41519,41545]
===
match
---
simple_stmt [44613,44688]
simple_stmt [46329,46404]
===
match
---
trailer [63664,63670]
trailer [65380,65386]
===
match
---
operator: , [65757,65758]
operator: , [67473,67474]
===
match
---
parameters [12237,12243]
parameters [12237,12243]
===
match
---
trailer [31209,31215]
trailer [32925,32931]
===
match
---
name: dates [55860,55865]
name: dates [57576,57581]
===
match
---
suite [68833,69626]
suite [70549,71342]
===
match
---
name: list_py_file_paths [1924,1942]
name: list_py_file_paths [1924,1942]
===
match
---
name: relativedelta [1120,1133]
name: relativedelta [1120,1133]
===
match
---
trailer [39722,39739]
trailer [41438,41455]
===
match
---
simple_stmt [18523,18546]
simple_stmt [18523,18546]
===
match
---
operator: , [65003,65004]
operator: , [66719,66720]
===
match
---
operator: == [27858,27860]
operator: == [29574,29576]
===
match
---
operator: == [22965,22967]
operator: == [22965,22967]
===
match
---
string: 'dag__dot__subtask' [29694,29713]
string: 'dag__dot__subtask' [31410,31429]
===
match
---
name: dag_id [67291,67297]
name: dag_id [69007,69013]
===
match
---
expr_stmt [8026,8099]
expr_stmt [8026,8099]
===
match
---
fstring_string: manual__ [47254,47262]
fstring_string: manual__ [48970,48978]
===
match
---
operator: = [17292,17293]
operator: = [17292,17293]
===
match
---
operator: = [43199,43200]
operator: = [44915,44916]
===
match
---
funcdef [28452,29791]
funcdef [30168,31507]
===
match
---
operator: == [25150,25152]
operator: == [26866,26868]
===
match
---
name: dag_id [68190,68196]
name: dag_id [69906,69912]
===
match
---
name: create_dagrun [66010,66023]
name: create_dagrun [67726,67739]
===
match
---
operator: , [54397,54398]
operator: , [56113,56114]
===
match
---
name: start_date [64234,64244]
name: start_date [65950,65960]
===
match
---
atom_expr [55588,55641]
atom_expr [57304,57357]
===
match
---
assert_stmt [58987,59036]
assert_stmt [60703,60752]
===
match
---
name: include_subdags [48976,48991]
name: include_subdags [50692,50707]
===
match
---
funcdef [48100,49389]
funcdef [49816,51105]
===
match
---
atom_expr [55284,55311]
atom_expr [57000,57027]
===
match
---
trailer [15375,15441]
trailer [15375,15441]
===
match
---
atom_expr [54071,54093]
atom_expr [55787,55809]
===
match
---
funcdef [67473,67609]
funcdef [69189,69325]
===
match
---
name: Session [34082,34089]
name: Session [35798,35805]
===
match
---
trailer [23758,23767]
trailer [23758,23767]
===
match
---
name: pattern [12562,12569]
name: pattern [12562,12569]
===
match
---
trailer [49906,49946]
trailer [51622,51662]
===
match
---
name: when [40482,40486]
name: when [42198,42202]
===
match
---
name: run_type [47508,47516]
name: run_type [49224,49232]
===
match
---
trailer [13406,13408]
trailer [13406,13408]
===
match
---
atom_expr [47212,47222]
atom_expr [48928,48938]
===
match
---
name: execution_date [52366,52380]
name: execution_date [54082,54096]
===
match
---
name: super [66500,66505]
name: super [68216,68221]
===
match
---
atom_expr [65042,65078]
atom_expr [66758,66794]
===
match
---
name: default_view [4772,4784]
name: default_view [4772,4784]
===
match
---
simple_stmt [37493,37540]
simple_stmt [39209,39256]
===
match
---
if_stmt [3358,3405]
if_stmt [3358,3405]
===
match
---
operator: , [11669,11670]
operator: , [11669,11670]
===
match
---
operator: = [23234,23235]
operator: = [23234,23235]
===
match
---
suite [27249,28447]
suite [28965,30163]
===
match
---
name: parent_dag [7586,7596]
name: parent_dag [7586,7596]
===
match
---
trailer [8055,8072]
trailer [8055,8072]
===
match
---
argument [41497,41518]
argument [43213,43234]
===
match
---
trailer [34261,34268]
trailer [35977,35984]
===
match
---
name: DAG [36981,36984]
name: DAG [38697,38700]
===
match
---
trailer [18921,18941]
trailer [18921,18941]
===
match
---
number: 10 [61146,61148]
number: 10 [62862,62864]
===
match
---
trailer [58264,58270]
trailer [59980,59986]
===
match
---
simple_stmt [48746,48777]
simple_stmt [50462,50493]
===
match
---
name: filter [34493,34499]
name: filter [36209,36215]
===
match
---
atom_expr [7205,7212]
atom_expr [7205,7212]
===
match
---
operator: = [5965,5966]
operator: = [5965,5966]
===
match
---
name: int [13491,13494]
name: int [13491,13494]
===
match
---
operator: = [55325,55326]
operator: = [57041,57042]
===
match
---
with_stmt [5216,5392]
with_stmt [5216,5392]
===
match
---
name: timedelta [58869,58878]
name: timedelta [60585,60594]
===
match
---
name: settings [2556,2564]
name: settings [2556,2564]
===
match
---
operator: , [54834,54835]
operator: , [56550,56551]
===
match
---
name: dagrun_2 [50506,50514]
name: dagrun_2 [52222,52230]
===
match
---
arith_expr [13292,13297]
arith_expr [13292,13297]
===
match
---
operator: = [7659,7660]
operator: = [7659,7660]
===
match
---
string: 'b_parent' [8375,8385]
string: 'b_parent' [8375,8385]
===
match
---
name: test_set_dag_id [66908,66923]
name: test_set_dag_id [68624,68639]
===
match
---
trailer [24881,24898]
trailer [26597,26614]
===
match
---
name: task_id [14223,14230]
name: task_id [14223,14230]
===
match
---
atom_expr [28941,29005]
atom_expr [30657,30721]
===
match
---
simple_stmt [62638,62662]
simple_stmt [64354,64378]
===
match
---
simple_stmt [42357,42447]
simple_stmt [44073,44163]
===
match
---
arglist [18033,18101]
arglist [18033,18101]
===
match
---
expr_stmt [58699,58924]
expr_stmt [60415,60640]
===
match
---
name: State [40526,40531]
name: State [42242,42247]
===
match
---
atom_expr [12089,12141]
atom_expr [12089,12141]
===
match
---
name: timezone [12417,12425]
name: timezone [12417,12425]
===
match
---
argument [59693,59728]
argument [61409,61444]
===
match
---
string: 'test_scheduler_dagrun_once' [54771,54799]
string: 'test_scheduler_dagrun_once' [56487,56515]
===
match
---
name: dag_pickle [44054,44064]
name: dag_pickle [45770,45780]
===
match
---
assert_stmt [69590,69625]
assert_stmt [71306,71341]
===
match
---
trailer [69479,69483]
trailer [71195,71199]
===
match
---
operator: = [27620,27621]
operator: = [29336,29337]
===
match
---
name: dag [40799,40802]
name: dag [42515,42518]
===
match
---
trailer [54432,54484]
trailer [56148,56200]
===
match
---
name: DAG [32573,32576]
name: DAG [34289,34292]
===
match
---
expr_stmt [5995,6072]
expr_stmt [5995,6072]
===
match
---
expr_stmt [16724,16771]
expr_stmt [16724,16771]
===
match
---
trailer [34426,34448]
trailer [36142,36164]
===
match
---
simple_stmt [43963,44005]
simple_stmt [45679,45721]
===
match
---
number: 1 [12138,12139]
number: 1 [12138,12139]
===
match
---
string: 'owner2' [6323,6331]
string: 'owner2' [6323,6331]
===
match
---
name: TIMEZONE [12066,12074]
name: TIMEZONE [12066,12074]
===
match
---
operator: = [9004,9005]
operator: = [9004,9005]
===
match
---
name: start_date [61101,61111]
name: start_date [62817,62827]
===
match
---
name: task [13378,13382]
name: task [13378,13382]
===
match
---
operator: } [47287,47288]
operator: } [49003,49004]
===
match
---
name: filter [31475,31481]
name: filter [33191,33197]
===
match
---
factor [55925,55927]
factor [57641,57643]
===
match
---
name: test_dag_invalid_orientation [5091,5119]
name: test_dag_invalid_orientation [5091,5119]
===
match
---
suite [67150,67178]
suite [68866,68894]
===
match
---
import_from [1893,1942]
import_from [1893,1942]
===
match
---
trailer [20472,20482]
trailer [20472,20482]
===
match
---
fstring_expr [61785,61802]
fstring_expr [63501,63518]
===
match
---
argument [24190,24213]
argument [25906,25929]
===
match
---
name: dag [34171,34174]
name: dag [35887,35890]
===
match
---
assert_stmt [30482,30520]
assert_stmt [32198,32236]
===
match
---
atom_expr [30285,30303]
atom_expr [32001,32019]
===
match
---
operator: = [57131,57132]
operator: = [58847,58848]
===
match
---
expr_stmt [51900,51923]
expr_stmt [53616,53639]
===
match
---
name: next_dagrun_after_date [62687,62709]
name: next_dagrun_after_date [64403,64425]
===
match
---
operator: = [16660,16661]
operator: = [16660,16661]
===
match
---
argument [41423,41450]
argument [43139,43166]
===
match
---
dotted_name [53224,53244]
dotted_name [54940,54960]
===
match
---
atom_expr [9338,9357]
atom_expr [9338,9357]
===
match
---
operator: { [61785,61786]
operator: { [63501,63502]
===
match
---
name: DEFAULT_DATE [49714,49726]
name: DEFAULT_DATE [51430,51442]
===
match
---
argument [50376,50399]
argument [52092,52115]
===
match
---
name: RUNNING [66103,66110]
name: RUNNING [67819,67826]
===
match
---
trailer [31354,31371]
trailer [33070,33087]
===
match
---
atom_expr [8915,8943]
atom_expr [8915,8943]
===
match
---
trailer [47507,47516]
trailer [49223,49232]
===
match
---
operator: , [1460,1461]
operator: , [1460,1461]
===
match
---
name: i [65928,65929]
name: i [67644,67645]
===
match
---
name: next_dagrun [28275,28286]
name: next_dagrun [29991,30002]
===
match
---
operator: } [56374,56375]
operator: } [58090,58091]
===
match
---
trailer [26347,26396]
trailer [28063,28112]
===
match
---
atom_expr [46028,46057]
atom_expr [47744,47773]
===
match
---
suite [32924,33319]
suite [34640,35035]
===
match
---
operator: == [17990,17992]
operator: == [17990,17992]
===
match
---
atom_expr [69597,69611]
atom_expr [71313,71327]
===
match
---
argument [19141,19164]
argument [19141,19164]
===
match
---
simple_stmt [15311,15323]
simple_stmt [15311,15323]
===
match
---
name: self [21311,21315]
name: self [21311,21315]
===
match
---
operator: } [36091,36092]
operator: } [37807,37808]
===
match
---
operator: , [52076,52077]
operator: , [53792,53793]
===
match
---
name: op1 [9864,9867]
name: op1 [9864,9867]
===
match
---
name: query [33552,33557]
name: query [35268,35273]
===
match
---
atom [4317,4336]
atom [4317,4336]
===
match
---
name: start_date [49840,49850]
name: start_date [51556,51566]
===
match
---
simple_stmt [28594,28640]
simple_stmt [30310,30356]
===
match
---
name: op1 [37552,37555]
name: op1 [39268,39271]
===
match
---
name: state [53309,53314]
name: state [55025,55030]
===
match
---
atom_expr [2881,2894]
atom_expr [2881,2894]
===
match
---
operator: + [13632,13633]
operator: + [13632,13633]
===
match
---
atom_expr [42855,42872]
atom_expr [44571,44588]
===
match
---
name: settings [30285,30293]
name: settings [32001,32009]
===
match
---
operator: = [64741,64742]
operator: = [66457,66458]
===
match
---
string: 'test_subdag_operator' [62104,62126]
string: 'test_subdag_operator' [63820,63842]
===
match
---
comparison [10511,10537]
comparison [10511,10537]
===
match
---
trailer [18220,18228]
trailer [18220,18228]
===
match
---
name: task_id [37711,37718]
name: task_id [39427,39434]
===
match
---
name: DummyOperator [8831,8844]
name: DummyOperator [8831,8844]
===
match
---
operator: = [33542,33543]
operator: = [35258,35259]
===
match
---
param [53422,53427]
param [55138,55143]
===
match
---
name: dr [69258,69260]
name: dr [70974,70976]
===
match
---
operator: , [7914,7915]
operator: , [7914,7915]
===
match
---
name: TI [16958,16960]
name: TI [16958,16960]
===
match
---
argument [57047,57057]
argument [58763,58773]
===
match
---
atom_expr [27177,27183]
atom_expr [28893,28899]
===
match
---
with_stmt [46185,46323]
with_stmt [47901,48039]
===
match
---
atom_expr [56394,56604]
atom_expr [58110,58320]
===
match
---
simple_stmt [17477,17496]
simple_stmt [17477,17496]
===
match
---
name: timezone [61356,61364]
name: timezone [63072,63080]
===
match
---
atom_expr [33421,33492]
atom_expr [35137,35208]
===
match
---
name: dag_id [64910,64916]
name: dag_id [66626,66632]
===
match
---
comparison [12041,12074]
comparison [12041,12074]
===
match
---
name: dag_id [31242,31248]
name: dag_id [32958,32964]
===
match
---
funcdef [70592,71099]
funcdef [72308,72815]
===
match
---
name: get [5017,5020]
name: get [5017,5020]
===
match
---
assert_stmt [23387,23441]
assert_stmt [23387,23441]
===
match
---
name: orm_dag [29751,29758]
name: orm_dag [31467,31474]
===
match
---
name: get_num_task_instances [17997,18019]
name: get_num_task_instances [17997,18019]
===
match
---
name: Exception [40129,40138]
name: Exception [41845,41854]
===
match
---
expr_stmt [44476,44536]
expr_stmt [46192,46252]
===
match
---
simple_stmt [21114,21150]
simple_stmt [21114,21150]
===
match
---
arglist [53077,53084]
arglist [54793,54800]
===
match
---
string: 'DAG' [12356,12361]
string: 'DAG' [12356,12361]
===
match
---
operator: = [17168,17169]
operator: = [17168,17169]
===
match
---
trailer [35846,35860]
trailer [37562,37576]
===
match
---
name: all [64466,64469]
name: all [66182,66185]
===
match
---
operator: = [35350,35351]
operator: = [37066,37067]
===
match
---
suite [16715,18440]
suite [16715,18440]
===
match
---
name: max_active_runs [62194,62209]
name: max_active_runs [63910,63925]
===
match
---
trailer [65133,65137]
trailer [66849,66853]
===
match
---
param [13843,13847]
param [13843,13847]
===
match
---
argument [8845,8856]
argument [8845,8856]
===
match
---
trailer [22600,22616]
trailer [22600,22616]
===
match
---
name: test_task_id [17728,17740]
name: test_task_id [17728,17740]
===
match
---
name: t_1 [54007,54010]
name: t_1 [55723,55726]
===
match
---
string: 'start_date' [34864,34876]
string: 'start_date' [36580,36592]
===
match
---
trailer [6725,6731]
trailer [6725,6731]
===
match
---
name: test_duplicate_task_ids_not_allowed_with_dag_context_manager [36727,36787]
name: test_duplicate_task_ids_not_allowed_with_dag_context_manager [38443,38503]
===
match
---
operator: = [35327,35328]
operator: = [37043,37044]
===
match
---
argument [27432,27478]
argument [29148,29194]
===
match
---
argument [51864,51878]
argument [53580,53594]
===
match
---
suite [19200,19253]
suite [19200,19253]
===
match
---
name: test_next_dagrun_after_date_once [54700,54732]
name: test_next_dagrun_after_date_once [56416,56448]
===
match
---
operator: = [8852,8853]
operator: = [8852,8853]
===
match
---
string: 'test_' [43400,43407]
string: 'test_' [45116,45123]
===
match
---
funcdef [61399,62946]
funcdef [63115,64662]
===
match
---
number: 1 [62175,62176]
number: 1 [63891,63892]
===
match
---
simple_stmt [4275,4354]
simple_stmt [4275,4354]
===
match
---
expr_stmt [34848,34925]
expr_stmt [36564,36641]
===
match
---
operator: { [63295,63296]
operator: { [65011,65012]
===
match
---
name: append [55826,55832]
name: append [57542,57548]
===
match
---
name: xcom_pull [70564,70573]
name: xcom_pull [72280,72289]
===
match
---
atom_expr [9735,9761]
atom_expr [9735,9761]
===
match
---
name: model [28269,28274]
name: model [29985,29990]
===
match
---
operator: , [46385,46386]
operator: , [48101,48102]
===
match
---
operator: , [31859,31860]
operator: , [33575,33576]
===
match
---
atom_expr [29751,29766]
atom_expr [31467,31482]
===
match
---
parameters [4840,4846]
parameters [4840,4846]
===
match
---
simple_stmt [43717,43792]
simple_stmt [45433,45508]
===
match
---
string: 'hello' [18711,18718]
string: 'hello' [18711,18718]
===
match
---
trailer [42369,42446]
trailer [44085,44162]
===
match
---
operator: = [37556,37557]
operator: = [39272,39273]
===
match
---
name: subdag [49995,50001]
name: subdag [51711,51717]
===
match
---
trailer [65231,65233]
trailer [66947,66949]
===
match
---
string: """         Test scheduling a dag where there is a prior DagRun         which has the same run_id as the next run should have         """ [40913,41050]
string: """         Test scheduling a dag where there is a prior DagRun         which has the same run_id as the next run should have         """ [42629,42766]
===
match
---
sync_comp_for [14454,14478]
sync_comp_for [14454,14478]
===
match
---
name: DEFAULT_DATE [52786,52798]
name: DEFAULT_DATE [54502,54514]
===
match
---
operator: = [6131,6132]
operator: = [6131,6132]
===
match
---
name: test_next_dagrun_after_not_for_subdags [61403,61441]
name: test_next_dagrun_after_not_for_subdags [63119,63157]
===
match
---
operator: = [69494,69495]
operator: = [71210,71211]
===
match
---
trailer [34245,34252]
trailer [35961,35968]
===
match
---
trailer [14895,14901]
trailer [14895,14901]
===
match
---
suite [38306,38864]
suite [40022,40580]
===
match
---
name: self [49631,49635]
name: self [51347,51351]
===
match
---
param [54733,54737]
param [56449,56453]
===
match
---
trailer [45269,45275]
trailer [46985,46991]
===
match
---
simple_stmt [839,853]
simple_stmt [839,853]
===
match
---
argument [33981,34009]
argument [35697,35725]
===
match
---
trailer [63472,63492]
trailer [65188,65208]
===
match
---
comparison [38117,38170]
comparison [39833,39886]
===
match
---
operator: = [68117,68118]
operator: = [69833,69834]
===
match
---
operator: <= [3481,3483]
operator: <= [3481,3483]
===
match
---
name: task_id [9794,9801]
name: task_id [9794,9801]
===
match
---
if_stmt [13163,13203]
if_stmt [13163,13203]
===
match
---
argument [37572,37584]
argument [39288,39300]
===
match
---
atom_expr [36257,36284]
atom_expr [37973,38000]
===
match
---
argument [21630,21646]
argument [21630,21646]
===
match
---
trailer [49694,49746]
trailer [51410,51462]
===
match
---
string: "0 0 1 1 *" [46568,46579]
string: "0 0 1 1 *" [48284,48295]
===
match
---
argument [28975,28989]
argument [30691,30705]
===
match
---
name: execution_date [48688,48702]
name: execution_date [50404,50418]
===
match
---
name: session [51091,51098]
name: session [52807,52814]
===
match
---
arglist [38324,38359]
arglist [40040,40075]
===
match
---
fstring_start: f' [61783,61785]
fstring_start: f' [63499,63501]
===
match
---
atom_expr [24882,24897]
atom_expr [26598,26613]
===
match
---
decorator [67006,67061]
decorator [68722,68777]
===
match
---
name: max_active_runs [48306,48321]
name: max_active_runs [50022,50037]
===
match
---
operator: = [40712,40713]
operator: = [42428,42429]
===
match
---
simple_stmt [33303,33319]
simple_stmt [35019,35035]
===
match
---
simple_stmt [50253,50452]
simple_stmt [51969,52168]
===
match
---
arglist [52775,53003]
arglist [54491,54719]
===
match
---
name: value [70787,70792]
name: value [72503,72508]
===
match
---
name: pipeline [14678,14686]
name: pipeline [14678,14686]
===
match
---
trailer [17565,17572]
trailer [17565,17572]
===
match
---
name: create_dagrun [42529,42542]
name: create_dagrun [44245,44258]
===
match
---
operator: , [24188,24189]
operator: , [25904,25905]
===
match
---
name: run_type [42543,42551]
name: run_type [44259,44267]
===
match
---
operator: , [46526,46527]
operator: , [48242,48243]
===
match
---
simple_stmt [31169,31193]
simple_stmt [32885,32909]
===
match
---
simple_stmt [45289,45322]
simple_stmt [47005,47038]
===
match
---
name: range [13068,13073]
name: range [13068,13073]
===
match
---
name: owner [64804,64809]
name: owner [66520,66525]
===
match
---
name: default_args [14079,14091]
name: default_args [14079,14091]
===
match
---
argument [47607,47623]
argument [49323,49339]
===
match
---
name: next_dagrun [27846,27857]
name: next_dagrun [29562,29573]
===
match
---
name: owners [29573,29579]
name: owners [31289,31295]
===
match
---
string: 'dag_without_catchup_once' [58062,58088]
string: 'dag_without_catchup_once' [59778,59804]
===
match
---
with_stmt [63455,63587]
with_stmt [65171,65303]
===
match
---
name: DagModel [65189,65197]
name: DagModel [66905,66913]
===
match
---
comparison [42308,42348]
comparison [44024,44064]
===
match
---
name: self [67870,67874]
name: self [69586,69590]
===
match
---
atom_expr [3420,3429]
atom_expr [3420,3429]
===
match
---
name: test_documentation_added [67728,67752]
name: test_documentation_added [69444,69468]
===
match
---
name: dag [11949,11952]
name: dag [11949,11952]
===
match
---
name: sync_to_db [24227,24237]
name: sync_to_db [25943,25953]
===
match
---
argument [52876,52903]
argument [54592,54619]
===
match
---
trailer [40407,40416]
trailer [42123,42132]
===
match
---
argument [7121,7134]
argument [7121,7134]
===
match
---
name: dag [28487,28490]
name: dag [30203,30206]
===
match
---
with_stmt [6477,6608]
with_stmt [6477,6608]
===
match
---
string: 'owner1' [29597,29605]
string: 'owner1' [31313,31321]
===
match
---
atom_expr [68090,68103]
atom_expr [69806,69819]
===
match
---
trailer [63670,63690]
trailer [65386,65406]
===
match
---
simple_stmt [27422,27505]
simple_stmt [29138,29221]
===
match
---
name: dag_decorator [67419,67432]
name: dag_decorator [69135,69148]
===
match
---
atom_expr [32573,32590]
atom_expr [34289,34306]
===
match
---
number: 2016 [61374,61378]
number: 2016 [63090,63094]
===
match
---
simple_stmt [30847,30862]
simple_stmt [32563,32578]
===
match
---
trailer [38323,38360]
trailer [40039,40076]
===
match
---
name: State [53318,53323]
name: State [55034,55039]
===
match
---
operator: } [61818,61819]
operator: } [63534,63535]
===
match
---
operator: , [70249,70250]
operator: , [71965,71966]
===
match
---
name: DAG [12834,12837]
name: DAG [12834,12837]
===
match
---
argument [7558,7575]
argument [7558,7575]
===
match
---
name: DummyOperator [64764,64777]
name: DummyOperator [66480,66493]
===
match
---
expr_stmt [17164,17246]
expr_stmt [17164,17246]
===
match
---
name: mock [1038,1042]
name: mock [1038,1042]
===
match
---
suite [6972,7093]
suite [6972,7093]
===
match
---
trailer [60042,60053]
trailer [61758,61769]
===
match
---
string: '*/10 * * * *' [57226,57240]
string: '*/10 * * * *' [58942,58956]
===
match
---
suite [5310,5392]
suite [5310,5392]
===
match
---
name: datetime [41067,41075]
name: datetime [42783,42791]
===
match
---
name: commit [48793,48799]
name: commit [50509,50515]
===
match
---
trailer [69483,69541]
trailer [71199,71257]
===
match
---
param [56206,56213]
param [57922,57929]
===
match
---
atom_expr [58237,58270]
atom_expr [59953,59986]
===
match
---
operator: = [22711,22712]
operator: = [22711,22712]
===
match
---
comparison [39354,39373]
comparison [41070,41089]
===
match
---
name: topological_list [8160,8176]
name: topological_list [8160,8176]
===
match
---
atom_expr [18722,18739]
atom_expr [18722,18739]
===
match
---
comparison [21235,21246]
comparison [21235,21246]
===
match
---
operator: , [59728,59729]
operator: , [61444,61445]
===
match
---
trailer [36486,36496]
trailer [38202,38212]
===
match
---
param [39876,39886]
param [41592,41602]
===
match
---
number: 4 [17682,17683]
number: 4 [17682,17683]
===
match
---
name: all [65388,65391]
name: all [67104,67107]
===
match
---
string: 'task' [30007,30013]
string: 'task' [31723,31729]
===
match
---
operator: = [47456,47457]
operator: = [49172,49173]
===
match
---
trailer [10527,10530]
trailer [10527,10530]
===
match
---
name: convert [23071,23078]
name: convert [23071,23078]
===
match
---
operator: = [13695,13696]
operator: = [13695,13696]
===
match
---
trailer [24379,24386]
trailer [26095,26102]
===
match
---
atom [24938,25149]
atom [26654,26865]
===
match
---
number: 1 [13634,13635]
number: 1 [13634,13635]
===
match
---
operator: == [62741,62743]
operator: == [64457,64459]
===
match
---
string: 'dag-bulk-sync-2' [26929,26946]
string: 'dag-bulk-sync-2' [28645,28662]
===
match
---
arglist [56415,56590]
arglist [58131,58306]
===
match
---
name: op7 [7011,7014]
name: op7 [7011,7014]
===
match
---
string: 'test-dag' [25025,25035]
string: 'test-dag' [26741,26751]
===
match
---
name: dag [45318,45321]
name: dag [47034,47037]
===
match
---
trailer [26725,26728]
trailer [28441,28444]
===
match
---
name: xcom_arg [69106,69114]
name: xcom_arg [70822,70830]
===
match
---
string: '{{ ds }}' [19473,19483]
string: '{{ ds }}' [19473,19483]
===
match
---
operator: , [28087,28088]
operator: , [29803,29804]
===
match
---
atom [35600,35610]
atom [37316,37326]
===
match
---
operator: , [61144,61145]
operator: , [62860,62861]
===
match
---
operator: , [25799,25800]
operator: , [27515,27516]
===
match
---
expr_stmt [56834,56857]
expr_stmt [58550,58573]
===
match
---
operator: = [33090,33091]
operator: = [34806,34807]
===
match
---
number: 0 [24854,24855]
number: 0 [26570,26571]
===
match
---
assert_stmt [39382,39417]
assert_stmt [41098,41133]
===
match
---
assert_stmt [11802,11885]
assert_stmt [11802,11885]
===
match
---
operator: = [44341,44342]
operator: = [46057,46058]
===
match
---
operator: = [56838,56839]
operator: = [58554,58555]
===
match
---
arglist [29999,30029]
arglist [31715,31745]
===
match
---
operator: , [16509,16510]
operator: , [16509,16510]
===
match
---
dictorsetmaker [62416,62444]
dictorsetmaker [64132,64160]
===
match
---
name: DAG [12352,12355]
name: DAG [12352,12355]
===
match
---
trailer [67665,67675]
trailer [69381,69391]
===
match
---
trailer [17538,17544]
trailer [17538,17544]
===
match
---
name: catchup [56245,56252]
name: catchup [57961,57968]
===
match
---
name: utc [20942,20945]
name: utc [20942,20945]
===
match
---
name: run_id [47573,47579]
name: run_id [49289,49295]
===
match
---
name: DagModel [42810,42818]
name: DagModel [44526,44534]
===
match
---
trailer [28224,28234]
trailer [29940,29950]
===
match
---
sync_comp_for [15783,15807]
sync_comp_for [15783,15807]
===
match
---
simple_stmt [9153,9187]
simple_stmt [9153,9187]
===
match
---
name: next_dagrun [42861,42872]
name: next_dagrun [44577,44588]
===
match
---
expr_stmt [33833,33860]
expr_stmt [35549,35576]
===
match
---
operator: == [18129,18131]
operator: == [18129,18131]
===
match
---
name: BaseOperator [43230,43242]
name: BaseOperator [44946,44958]
===
match
---
name: include_subdags [50961,50976]
name: include_subdags [52677,52692]
===
match
---
import_name [814,828]
import_name [814,828]
===
match
---
trailer [12416,12425]
trailer [12416,12425]
===
match
---
operator: @ [3141,3142]
operator: @ [3141,3142]
===
match
---
name: create_dagrun [47820,47833]
name: create_dagrun [49536,49549]
===
match
---
trailer [34508,34515]
trailer [36224,36231]
===
match
---
operator: == [6320,6322]
operator: == [6320,6322]
===
match
---
assert_stmt [45810,45848]
assert_stmt [47526,47564]
===
match
---
name: dag [22707,22710]
name: dag [22707,22710]
===
match
---
expr_stmt [69225,69248]
expr_stmt [70941,70964]
===
match
---
simple_stmt [23606,23649]
simple_stmt [23606,23649]
===
match
---
atom_expr [6579,6607]
atom_expr [6579,6607]
===
match
---
arglist [69294,69446]
arglist [71010,71162]
===
match
---
argument [41086,41093]
argument [42802,42809]
===
match
---
arglist [52582,52635]
arglist [54298,54351]
===
match
---
name: normalized_schedule_interval [46896,46924]
name: normalized_schedule_interval [48612,48640]
===
match
---
atom_expr [54530,54549]
atom_expr [56246,56265]
===
match
---
string: 'test-dag2' [26115,26126]
string: 'test-dag2' [27831,27842]
===
match
---
trailer [35109,35114]
trailer [36825,36830]
===
match
---
name: test_bulk_write_to_db_max_active_runs [27205,27242]
name: test_bulk_write_to_db_max_active_runs [28921,28958]
===
match
---
operator: = [43160,43161]
operator: = [44876,44877]
===
match
---
arglist [31752,31791]
arglist [33468,33507]
===
match
---
number: 1 [34905,34906]
number: 1 [36621,36622]
===
match
---
name: return_num [69117,69127]
name: return_num [70833,70843]
===
match
---
trailer [70797,70803]
trailer [72513,72519]
===
match
---
name: runs [55749,55753]
name: runs [57465,57469]
===
match
---
number: 1 [54553,54554]
number: 1 [56269,56270]
===
match
---
assert_stmt [47633,47672]
assert_stmt [49349,49388]
===
match
---
atom_expr [38186,38199]
atom_expr [39902,39915]
===
match
---
atom_expr [21782,21804]
atom_expr [21782,21804]
===
match
---
name: prev_local [21730,21740]
name: prev_local [21730,21740]
===
match
---
operator: , [59029,59030]
operator: , [60745,60746]
===
match
---
name: self [3548,3552]
name: self [3548,3552]
===
match
---
operator: = [28659,28660]
operator: = [30375,30376]
===
match
---
simple_stmt [27775,27825]
simple_stmt [29491,29541]
===
match
---
name: query [26356,26361]
name: query [28072,28077]
===
match
---
operator: == [38200,38202]
operator: == [39916,39918]
===
match
---
name: hash [45839,45843]
name: hash [47555,47559]
===
match
---
name: task_id [61231,61238]
name: task_id [62947,62954]
===
match
---
operator: = [12855,12856]
operator: = [12855,12856]
===
match
---
decorated [69872,69948]
decorated [71588,71664]
===
match
---
atom_expr [48895,48921]
atom_expr [50611,50637]
===
match
---
simple_stmt [39468,39496]
simple_stmt [41184,41212]
===
match
---
simple_stmt [24136,24215]
simple_stmt [25852,25931]
===
match
---
trailer [55016,55039]
trailer [56732,56755]
===
match
---
arglist [17807,17863]
arglist [17807,17863]
===
match
---
arglist [19773,19842]
arglist [19773,19842]
===
match
---
comparison [10698,10726]
comparison [10698,10726]
===
match
---
name: state [42600,42605]
name: state [44316,44321]
===
match
---
suite [6816,6858]
suite [6816,6858]
===
match
---
operator: , [59870,59871]
operator: , [61586,61587]
===
match
---
operator: = [23975,23976]
operator: = [23975,23976]
===
match
---
name: airflow [1311,1318]
name: airflow [1311,1318]
===
match
---
simple_stmt [55371,55414]
simple_stmt [57087,57130]
===
match
---
import_from [1306,1359]
import_from [1306,1359]
===
match
---
trailer [69499,69512]
trailer [71215,71228]
===
match
---
number: 2019 [62762,62766]
number: 2019 [64478,64482]
===
match
---
trailer [48213,48223]
trailer [49929,49939]
===
match
---
simple_stmt [18555,18652]
simple_stmt [18555,18652]
===
match
---
parameters [62999,63005]
parameters [64715,64721]
===
match
---
operator: = [58883,58884]
operator: = [60599,60600]
===
match
---
parameters [37304,37310]
parameters [39020,39026]
===
match
---
name: DAG [9458,9461]
name: DAG [9458,9461]
===
match
---
arglist [67262,67270]
arglist [68978,68986]
===
match
---
atom_expr [9288,9307]
atom_expr [9288,9307]
===
match
---
trailer [61942,61945]
trailer [63658,63661]
===
match
---
expr_stmt [8870,8902]
expr_stmt [8870,8902]
===
match
---
operator: = [12087,12088]
operator: = [12087,12088]
===
match
---
name: patch [1069,1074]
name: patch [1069,1074]
===
match
---
name: num [67549,67552]
name: num [69265,69268]
===
match
---
atom_expr [57349,57382]
atom_expr [59065,59098]
===
match
---
number: 1 [60765,60766]
number: 1 [62481,62482]
===
match
---
name: dag [36234,36237]
name: dag [37950,37953]
===
match
---
decorated [30550,32501]
decorated [32266,34217]
===
match
---
number: 3 [13941,13942]
number: 3 [13941,13942]
===
match
---
name: session [27723,27730]
name: session [29439,29446]
===
match
---
atom [13611,13637]
atom [13611,13637]
===
match
---
trailer [23122,23124]
trailer [23122,23124]
===
match
---
atom_expr [38117,38130]
atom_expr [39833,39846]
===
match
---
string: 'test-dag' [19773,19783]
string: 'test-dag' [19773,19783]
===
match
---
atom_expr [50350,50362]
atom_expr [52066,52078]
===
match
---
parameters [51431,51452]
parameters [53147,53168]
===
match
---
atom_expr [9374,9393]
atom_expr [9374,9393]
===
match
---
trailer [34235,34245]
trailer [35951,35961]
===
match
---
simple_stmt [11724,11794]
simple_stmt [11724,11794]
===
match
---
atom_expr [3328,3344]
atom_expr [3328,3344]
===
match
---
operator: , [30822,30823]
operator: , [32538,32539]
===
match
---
parameters [15221,15227]
parameters [15221,15227]
===
match
---
operator: , [34149,34150]
operator: , [35865,35866]
===
match
---
argument [55601,55621]
argument [57317,57337]
===
match
---
atom_expr [6415,6422]
atom_expr [6415,6422]
===
match
---
atom_expr [12834,12903]
atom_expr [12834,12903]
===
match
---
name: DAG [67671,67674]
name: DAG [69387,69390]
===
match
---
suite [70805,71017]
suite [72521,72733]
===
match
---
name: _clean_up [42948,42957]
name: _clean_up [44664,44673]
===
match
---
assert_stmt [3752,3787]
assert_stmt [3752,3787]
===
match
---
trailer [12437,12446]
trailer [12437,12446]
===
match
---
name: dict [3782,3786]
name: dict [3782,3786]
===
match
---
name: schedule_interval [58102,58119]
name: schedule_interval [59818,59835]
===
match
---
operator: , [52186,52187]
operator: , [53902,53903]
===
match
---
argument [12845,12868]
argument [12845,12868]
===
match
---
name: WeightRule [2187,2197]
name: WeightRule [2187,2197]
===
match
---
arith_expr [44650,44667]
arith_expr [46366,46383]
===
match
---
simple_stmt [33004,33033]
simple_stmt [34720,34749]
===
match
---
trailer [70952,70961]
trailer [72668,72677]
===
match
---
string: "0 0 * * 0" [46448,46459]
string: "0 0 * * 0" [48164,48175]
===
match
---
trailer [49285,49294]
trailer [51001,51010]
===
match
---
suite [37029,37180]
suite [38745,38896]
===
match
---
name: object [2549,2555]
name: object [2549,2555]
===
match
---
name: prev_local [21166,21176]
name: prev_local [21166,21176]
===
match
---
name: name [19745,19749]
name: name [19745,19749]
===
match
---
simple_stmt [1189,1229]
simple_stmt [1189,1229]
===
match
---
trailer [15859,15869]
trailer [15859,15869]
===
match
---
operator: { [18538,18539]
operator: { [18538,18539]
===
match
---
operator: , [24987,24988]
operator: , [26703,26704]
===
match
---
trailer [2555,2590]
trailer [2555,2590]
===
match
---
operator: = [65347,65348]
operator: = [67063,67064]
===
match
---
name: suffix [18922,18928]
name: suffix [18922,18928]
===
match
---
trailer [14686,14693]
trailer [14686,14693]
===
match
---
comparison [6624,6639]
comparison [6624,6639]
===
match
---
operator: = [70388,70389]
operator: = [72104,72105]
===
match
---
atom_expr [3361,3370]
atom_expr [3361,3370]
===
match
---
atom_expr [38222,38233]
atom_expr [39938,39949]
===
match
---
argument [53660,53675]
argument [55376,55391]
===
match
---
name: i [65855,65856]
name: i [67571,67572]
===
match
---
name: DummyOperator [37052,37065]
name: DummyOperator [38768,38781]
===
match
---
simple_stmt [56834,56858]
simple_stmt [58550,58574]
===
match
---
name: run_type [47643,47651]
name: run_type [49359,49367]
===
match
---
string: 't1' [53557,53561]
string: 't1' [55273,55277]
===
match
---
name: op1 [9639,9642]
name: op1 [9639,9642]
===
match
---
atom_expr [60231,60268]
atom_expr [61947,61984]
===
match
---
name: RUNNING [17148,17155]
name: RUNNING [17148,17155]
===
match
---
name: session [3044,3051]
name: session [3044,3051]
===
match
---
name: timedelta [54266,54275]
name: timedelta [55982,55991]
===
match
---
param [69671,69675]
param [71387,71391]
===
match
---
operator: = [47430,47431]
operator: = [49146,49147]
===
match
---
name: run_id [66041,66047]
name: run_id [67757,67763]
===
match
---
name: TestDagModel [63811,63823]
name: TestDagModel [65527,65539]
===
match
---
trailer [47275,47285]
trailer [48991,49001]
===
match
---
simple_stmt [44242,44298]
simple_stmt [45958,46014]
===
match
---
assert_stmt [6867,6908]
assert_stmt [6867,6908]
===
match
---
name: self [69466,69470]
name: self [71182,71186]
===
match
---
name: pipeline [14133,14141]
name: pipeline [14133,14141]
===
match
---
atom_expr [20697,20724]
atom_expr [20697,20724]
===
match
---
operator: { [11979,11980]
operator: { [11979,11980]
===
match
---
name: DEFAULT_DATE [16497,16509]
name: DEFAULT_DATE [16497,16509]
===
match
---
operator: , [52798,52799]
operator: , [54514,54515]
===
match
---
operator: = [27426,27427]
operator: = [29142,29143]
===
match
---
assert_stmt [32841,32871]
assert_stmt [34557,34587]
===
match
---
name: dag [40508,40511]
name: dag [42224,42227]
===
match
---
string: 'parameter1' [4213,4225]
string: 'parameter1' [4213,4225]
===
match
---
name: local_tz [20746,20754]
name: local_tz [20746,20754]
===
match
---
param [61646,61661]
param [63362,63377]
===
match
---
trailer [20719,20724]
trailer [20719,20724]
===
match
---
argument [62253,62262]
argument [63969,63978]
===
match
---
operator: = [64809,64810]
operator: = [66525,66526]
===
match
---
name: task_id [61977,61984]
name: task_id [63693,63700]
===
match
---
operator: , [61087,61088]
operator: , [62803,62804]
===
match
---
string: "2018-03-24T02:00:00+00:00" [23414,23441]
string: "2018-03-24T02:00:00+00:00" [23414,23441]
===
match
---
number: 1 [54989,54990]
number: 1 [56705,56706]
===
match
---
name: task_id [35801,35808]
name: task_id [37517,37524]
===
match
---
string: 'webserver' [5614,5625]
string: 'webserver' [5614,5625]
===
match
---
name: write [19606,19611]
name: write [19606,19611]
===
match
---
atom_expr [29503,29518]
atom_expr [31219,31234]
===
match
---
fstring [15560,15575]
fstring [15560,15575]
===
match
---
atom_expr [69395,69412]
atom_expr [71111,71128]
===
match
---
atom [24956,24987]
atom [26672,26703]
===
match
---
testlist_comp [12954,13041]
testlist_comp [12954,13041]
===
match
---
name: local_tz [21743,21751]
name: local_tz [21743,21751]
===
match
---
expr_stmt [70128,70151]
expr_stmt [71844,71867]
===
match
---
name: t_1 [48683,48686]
name: t_1 [50399,50402]
===
match
---
name: clear_db_runs [65612,65625]
name: clear_db_runs [67328,67341]
===
match
---
name: timezone [43329,43337]
name: timezone [45045,45053]
===
match
---
argument [60680,60716]
argument [62396,62432]
===
match
---
trailer [9918,9923]
trailer [9918,9923]
===
match
---
string: 'owner1' [28630,28638]
string: 'owner1' [30346,30354]
===
match
---
param [67549,67552]
param [69265,69268]
===
match
---
number: 1 [61383,61384]
number: 1 [63099,63100]
===
match
---
atom_expr [41067,41094]
atom_expr [42783,42810]
===
match
---
simple_stmt [17413,17442]
simple_stmt [17413,17442]
===
match
---
operator: == [60980,60982]
operator: == [62696,62698]
===
match
---
name: session [33092,33099]
name: session [34808,34815]
===
match
---
return_stmt [67167,67177]
return_stmt [68883,68893]
===
match
---
assert_stmt [29722,29766]
assert_stmt [31438,31482]
===
match
---
atom_expr [54108,54138]
atom_expr [55824,55854]
===
match
---
argument [9839,9850]
argument [9839,9850]
===
match
---
simple_stmt [36483,36499]
simple_stmt [38199,38215]
===
match
---
funcdef [34722,35132]
funcdef [36438,36848]
===
match
---
atom_expr [11765,11793]
atom_expr [11765,11793]
===
match
---
name: task_id [38447,38454]
name: task_id [40163,40170]
===
match
---
name: session [65311,65318]
name: session [67027,67034]
===
match
---
with_item [62080,62281]
with_item [63796,63997]
===
match
---
string: 'test_scheduler_auto_align_2' [61058,61087]
string: 'test_scheduler_auto_align_2' [62774,62803]
===
match
---
name: self [70948,70952]
name: self [72664,72668]
===
match
---
with_stmt [16470,16672]
with_stmt [16470,16672]
===
match
---
name: task_id [19238,19245]
name: task_id [19238,19245]
===
match
---
expr_stmt [49755,49800]
expr_stmt [51471,51516]
===
match
---
atom_expr [17343,17369]
atom_expr [17343,17369]
===
match
---
param [40898,40902]
param [42614,42618]
===
match
---
operator: , [49452,49453]
operator: , [51168,51169]
===
match
---
expr_stmt [62671,62715]
expr_stmt [64387,64431]
===
match
---
operator: == [7243,7245]
operator: == [7243,7245]
===
match
---
name: airflow [1365,1372]
name: airflow [1365,1372]
===
match
---
trailer [64300,64312]
trailer [66016,66028]
===
match
---
atom [15005,15029]
atom [15005,15029]
===
match
---
assert_stmt [32012,32110]
assert_stmt [33728,33826]
===
match
---
name: dag [60016,60019]
name: dag [61732,61735]
===
match
---
name: task_decorator [69018,69032]
name: task_decorator [70734,70748]
===
match
---
param [18882,18886]
param [18882,18886]
===
match
---
atom_expr [10056,10078]
atom_expr [10056,10078]
===
match
---
name: task_id [62339,62346]
name: task_id [64055,64062]
===
match
---
trailer [39772,39782]
trailer [41488,41498]
===
match
---
name: DAG [6758,6761]
name: DAG [6758,6761]
===
match
---
atom_expr [62638,62654]
atom_expr [64354,64370]
===
match
---
operator: = [29848,29849]
operator: = [31564,31565]
===
match
---
arglist [14047,14111]
arglist [14047,14111]
===
match
---
name: state [48513,48518]
name: state [50229,50234]
===
match
---
name: start_date [7427,7437]
name: start_date [7427,7437]
===
match
---
operator: = [17366,17367]
operator: = [17366,17367]
===
match
---
import_from [1765,1816]
import_from [1765,1816]
===
match
---
name: self [19526,19530]
name: self [19526,19530]
===
match
---
name: task_id [38208,38215]
name: task_id [39924,39931]
===
match
---
assert_stmt [60277,60326]
assert_stmt [61993,62042]
===
match
---
argument [22727,22743]
argument [22727,22743]
===
match
---
trailer [68599,68606]
trailer [70315,70322]
===
match
---
string: 'start_date' [10809,10821]
string: 'start_date' [10809,10821]
===
match
---
trailer [18571,18651]
trailer [18571,18651]
===
match
---
operator: , [60763,60764]
operator: , [62479,62480]
===
match
---
name: task_id [37627,37634]
name: task_id [39343,39350]
===
match
---
funcdef [5087,5392]
funcdef [5087,5392]
===
match
---
dictorsetmaker [25744,25818]
dictorsetmaker [27460,27534]
===
match
---
atom_expr [7334,7461]
atom_expr [7334,7461]
===
match
---
name: dag_eq [44985,44991]
name: dag_eq [46701,46707]
===
match
---
atom_expr [27120,27145]
atom_expr [28836,28861]
===
match
---
testlist_comp [49440,49451]
testlist_comp [51156,51167]
===
match
---
fstring_end: ' [18544,18545]
fstring_end: ' [18544,18545]
===
match
---
operator: = [6024,6025]
operator: = [6024,6025]
===
match
---
operator: , [50399,50400]
operator: , [52115,52116]
===
match
---
name: ti_state_end [53444,53456]
name: ti_state_end [55160,55172]
===
match
---
expr_stmt [46079,46133]
expr_stmt [47795,47849]
===
match
---
string: 'test-dag' [4292,4302]
string: 'test-dag' [4292,4302]
===
match
---
comparison [35582,35610]
comparison [37298,37326]
===
match
---
trailer [40802,40808]
trailer [42518,42524]
===
match
---
name: datetime [62151,62159]
name: datetime [63867,63875]
===
match
---
argument [46671,46677]
argument [48387,48393]
===
match
---
operator: , [23720,23721]
operator: , [23720,23721]
===
match
---
name: test_dag_id [17714,17725]
name: test_dag_id [17714,17725]
===
match
---
atom_expr [36425,36455]
atom_expr [38141,38171]
===
match
---
simple_stmt [35167,35226]
simple_stmt [36883,36942]
===
match
---
trailer [17484,17490]
trailer [17484,17490]
===
match
---
name: success [40653,40660]
name: success [42369,42376]
===
match
---
argument [28991,29004]
argument [30707,30720]
===
match
---
suite [6509,6561]
suite [6509,6561]
===
match
---
name: topological_list [10160,10176]
name: topological_list [10160,10176]
===
match
---
operator: = [56456,56457]
operator: = [58172,58173]
===
match
---
name: dag [38364,38367]
name: dag [40080,40083]
===
match
---
suite [70866,70894]
suite [72582,72610]
===
match
---
name: now [56895,56898]
name: now [58611,58614]
===
match
---
comparison [38661,38726]
comparison [40377,40442]
===
match
---
parameters [66484,66490]
parameters [68200,68206]
===
match
---
argument [36997,37020]
argument [38713,38736]
===
match
---
name: DagModel [29486,29494]
name: DagModel [31202,31210]
===
match
---
name: dag [37590,37593]
name: dag [39306,39309]
===
match
---
atom_expr [59787,59819]
atom_expr [61503,61535]
===
match
---
funcdef [23447,24071]
funcdef [23447,24071]
===
match
---
atom_expr [65435,65453]
atom_expr [67151,67169]
===
match
---
string: "test_dag" [35243,35253]
string: "test_dag" [36959,36969]
===
match
---
for_stmt [25547,25605]
for_stmt [27263,27321]
===
match
---
atom_expr [42606,42619]
atom_expr [44322,44335]
===
match
---
simple_stmt [1017,1043]
simple_stmt [1017,1043]
===
match
---
name: dag1 [57349,57353]
name: dag1 [59065,59069]
===
match
---
atom_expr [40556,40573]
atom_expr [42272,42289]
===
match
---
atom_expr [31442,31460]
atom_expr [33158,33176]
===
match
---
string: 'op5' [6601,6606]
string: 'op5' [6601,6606]
===
match
---
string: 'test-dag' [25123,25133]
string: 'test-dag' [26839,26849]
===
match
---
operator: = [14230,14231]
operator: = [14230,14231]
===
match
---
atom_expr [46652,46678]
atom_expr [48368,48394]
===
match
---
operator: = [54241,54242]
operator: = [55957,55958]
===
match
---
string: 'dag_without_catchup_hourly' [57596,57624]
string: 'dag_without_catchup_hourly' [59312,59340]
===
match
---
simple_stmt [52561,52637]
simple_stmt [54277,54353]
===
match
---
name: convert [20977,20984]
name: convert [20977,20984]
===
match
---
argument [64711,64729]
argument [66427,66445]
===
match
---
operator: = [63904,63905]
operator: = [65620,65621]
===
match
---
atom_expr [10382,10401]
atom_expr [10382,10401]
===
match
---
name: datetime_tz [2368,2379]
name: datetime_tz [2368,2379]
===
match
---
name: dag [4275,4278]
name: dag [4275,4278]
===
match
---
name: test_schedule_dag_no_previous_runs [38873,38907]
name: test_schedule_dag_no_previous_runs [40589,40623]
===
match
---
trailer [59790,59813]
trailer [61506,61529]
===
match
---
operator: , [52862,52863]
operator: , [54578,54579]
===
match
---
suite [33365,33763]
suite [35081,35479]
===
match
---
atom_expr [14463,14478]
atom_expr [14463,14478]
===
match
---
operator: , [50842,50843]
operator: , [52558,52559]
===
match
---
operator: , [51825,51826]
operator: , [53541,53542]
===
match
---
name: template_fields [19976,19991]
name: template_fields [19976,19991]
===
match
---
name: utils [2022,2027]
name: utils [2022,2027]
===
match
---
name: self [71088,71092]
name: self [72804,72808]
===
match
---
number: 1 [27535,27536]
number: 1 [29251,29252]
===
match
---
name: self [68992,68996]
name: self [70708,70712]
===
match
---
atom_expr [53842,53855]
atom_expr [55558,55571]
===
match
---
name: dagrun_1 [50049,50057]
name: dagrun_1 [51765,51773]
===
match
---
atom_expr [18374,18387]
atom_expr [18374,18387]
===
match
---
operator: = [70517,70518]
operator: = [72233,72234]
===
match
---
assert_stmt [6715,6743]
assert_stmt [6715,6743]
===
match
---
name: dag [53759,53762]
name: dag [55475,55478]
===
match
---
name: TaskInstance [1498,1510]
name: TaskInstance [1498,1510]
===
match
---
trailer [44064,44071]
trailer [45780,45787]
===
match
---
simple_stmt [69961,69996]
simple_stmt [71677,71712]
===
match
---
trailer [38156,38164]
trailer [39872,39880]
===
match
---
name: write [18962,18967]
name: write [18962,18967]
===
match
---
operator: , [66331,66332]
operator: , [68047,68048]
===
match
---
expr_stmt [14873,14905]
expr_stmt [14873,14905]
===
match
---
trailer [26383,26388]
trailer [28099,28104]
===
match
---
name: task_id [12968,12975]
name: task_id [12968,12975]
===
match
---
operator: == [44872,44874]
operator: == [46588,46590]
===
match
---
atom_expr [53318,53331]
atom_expr [55034,55047]
===
match
---
name: dagrun [51240,51246]
name: dagrun [52956,52962]
===
match
---
name: convert_to_utc [22676,22690]
name: convert_to_utc [22676,22690]
===
match
---
operator: = [29073,29074]
operator: = [30789,30790]
===
match
---
operator: = [15337,15338]
operator: = [15337,15338]
===
match
---
argument [51681,51688]
argument [53397,53404]
===
match
---
name: create_dagrun [47436,47449]
name: create_dagrun [49152,49165]
===
match
---
operator: , [31948,31949]
operator: , [33664,33665]
===
match
---
name: task_decorator [1345,1359]
name: task_decorator [1345,1359]
===
match
---
name: dag_id [32244,32250]
name: dag_id [33960,33966]
===
match
---
name: dag [64989,64992]
name: dag [66705,66708]
===
match
---
name: DummyOperator [56624,56637]
name: DummyOperator [58340,58353]
===
match
---
string: 'op7' [7039,7044]
string: 'op7' [7039,7044]
===
match
---
operator: , [18388,18389]
operator: , [18388,18389]
===
match
---
parameters [69670,69676]
parameters [71386,71392]
===
match
---
string: 'test' [51804,51810]
string: 'test' [53520,53526]
===
match
---
assert_stmt [23318,23378]
assert_stmt [23318,23378]
===
match
---
name: orm_dag [30353,30360]
name: orm_dag [32069,32076]
===
match
---
name: DagModel [34500,34508]
name: DagModel [36216,36224]
===
match
---
name: permissions [63062,63073]
name: permissions [64778,64789]
===
match
---
name: prev [23303,23307]
name: prev [23303,23307]
===
match
---
funcdef [24076,24443]
funcdef [25792,26159]
===
match
---
name: VALUE [70798,70803]
name: VALUE [72514,72519]
===
match
---
name: SCHEDULED [42563,42572]
name: SCHEDULED [44279,44288]
===
match
---
param [10886,10890]
param [10886,10890]
===
match
---
atom_expr [37196,37209]
atom_expr [38912,38925]
===
match
---
atom_expr [36349,36376]
atom_expr [38065,38092]
===
match
---
name: b_index [3494,3501]
name: b_index [3494,3501]
===
match
---
name: task_id [36271,36278]
name: task_id [37987,37994]
===
match
---
number: 4 [24609,24610]
number: 4 [26325,26326]
===
match
---
name: topological_list [9166,9182]
name: topological_list [9166,9182]
===
match
---
name: hours [56920,56925]
name: hours [58636,58641]
===
match
---
operator: , [58127,58128]
operator: , [59843,59844]
===
match
---
operator: , [50233,50234]
operator: , [51949,51950]
===
match
---
funcdef [38245,38864]
funcdef [39961,40580]
===
match
---
name: value [70929,70934]
name: value [72645,72650]
===
match
---
arglist [60680,60825]
arglist [62396,62541]
===
match
---
trailer [57802,57808]
trailer [59518,59524]
===
match
---
parameters [34778,34784]
parameters [36494,36500]
===
match
---
name: range [55743,55748]
name: range [57459,57464]
===
match
---
name: TI [50626,50628]
name: TI [52342,52344]
===
match
---
arith_expr [54242,54283]
arith_expr [55958,55999]
===
match
---
assert_stmt [39704,39739]
assert_stmt [41420,41455]
===
match
---
trailer [69609,69611]
trailer [71325,71327]
===
match
---
argument [28101,28116]
argument [29817,29832]
===
match
---
name: task_id [29999,30006]
name: task_id [31715,31722]
===
match
---
decorated [67418,67609]
decorated [69134,69325]
===
match
---
atom_expr [24627,24650]
atom_expr [26343,26366]
===
match
---
number: 1 [17880,17881]
number: 1 [17880,17881]
===
match
---
operator: , [68238,68239]
operator: , [69954,69955]
===
match
---
operator: = [70486,70487]
operator: = [72202,72203]
===
match
---
name: date [55768,55772]
name: date [57484,57488]
===
match
---
arglist [41174,41237]
arglist [42890,42953]
===
match
---
simple_stmt [65155,65171]
simple_stmt [66871,66887]
===
match
---
name: dag_id [28244,28250]
name: dag_id [29960,29966]
===
match
---
number: 0 [3479,3480]
number: 0 [3479,3480]
===
match
---
operator: = [47766,47767]
operator: = [49482,49483]
===
match
---
funcdef [70846,70894]
funcdef [72562,72610]
===
match
---
with_item [2811,2838]
with_item [2811,2838]
===
match
---
name: DAG [24664,24667]
name: DAG [26380,26383]
===
match
---
operator: , [48078,48079]
operator: , [49794,49795]
===
match
---
string: 'airflow' [4785,4794]
string: 'airflow' [4785,4794]
===
match
---
param [69841,69857]
param [71557,71573]
===
match
---
name: dag [49942,49945]
name: dag [51658,51661]
===
match
---
parameters [16708,16714]
parameters [16708,16714]
===
match
---
operator: , [66842,66843]
operator: , [68558,68559]
===
match
---
string: '0 3 * * *' [22763,22774]
string: '0 3 * * *' [22763,22774]
===
match
---
operator: = [15318,15319]
operator: = [15318,15319]
===
match
---
argument [15601,15623]
argument [15601,15623]
===
match
---
atom_expr [8786,8812]
atom_expr [8786,8812]
===
match
---
atom [31938,31957]
atom [33654,33673]
===
match
---
operator: = [44461,44462]
operator: = [46177,46178]
===
match
---
expr_stmt [30654,30737]
expr_stmt [32370,32453]
===
match
---
name: create_dagrun [39200,39213]
name: create_dagrun [40916,40929]
===
match
---
trailer [47449,47489]
trailer [49165,49205]
===
match
---
argument [49865,49882]
argument [51581,51598]
===
match
---
name: execution_date [52159,52173]
name: execution_date [53875,53889]
===
match
---
atom_expr [58946,58978]
atom_expr [60662,60694]
===
match
---
operator: , [43539,43540]
operator: , [45255,45256]
===
match
---
trailer [66835,66842]
trailer [68551,68558]
===
match
---
parameters [24096,24102]
parameters [25812,25818]
===
match
---
expr_stmt [29844,29954]
expr_stmt [31560,31670]
===
match
---
trailer [17511,17517]
trailer [17511,17517]
===
match
---
trailer [9337,9358]
trailer [9337,9358]
===
match
---
arglist [48353,48377]
arglist [50069,50093]
===
match
---
parameters [2646,2652]
parameters [2646,2652]
===
match
---
expr_stmt [69147,69180]
expr_stmt [70863,70896]
===
match
---
argument [37586,37593]
argument [39302,39309]
===
match
---
name: match [13442,13447]
name: match [13442,13447]
===
match
---
fstring_string: Hello  [18532,18538]
fstring_string: Hello  [18532,18538]
===
match
---
fstring_string: . [15570,15571]
fstring_string: . [15570,15571]
===
match
---
parameters [3176,3189]
parameters [3176,3189]
===
match
---
operator: + [51718,51719]
operator: + [53434,53435]
===
match
---
name: dag [18555,18558]
name: dag [18555,18558]
===
match
---
argument [48871,48921]
argument [50587,50637]
===
match
---
atom_expr [37388,37479]
atom_expr [39104,39195]
===
match
---
argument [61101,61152]
argument [62817,62868]
===
match
---
name: orm_dag [34552,34559]
name: orm_dag [36268,36275]
===
match
---
atom_expr [27889,27919]
atom_expr [29605,29635]
===
match
---
operator: { [26810,26811]
operator: { [28526,28527]
===
match
---
expr_stmt [64076,64351]
expr_stmt [65792,66067]
===
match
---
simple_stmt [64620,64693]
simple_stmt [66336,66409]
===
match
---
atom_expr [31233,31273]
atom_expr [32949,32989]
===
match
---
argument [55523,55540]
argument [57239,57256]
===
match
---
operator: , [50155,50156]
operator: , [51871,51872]
===
match
---
name: airflow [2052,2059]
name: airflow [2052,2059]
===
match
---
simple_stmt [17558,17575]
simple_stmt [17558,17575]
===
match
---
comparison [10297,10324]
comparison [10297,10324]
===
match
---
string: '.test' [49831,49838]
string: '.test' [51547,51554]
===
match
---
atom_expr [51932,51948]
atom_expr [53648,53664]
===
match
---
operator: == [29149,29151]
operator: == [30865,30867]
===
match
---
trailer [3083,3090]
trailer [3083,3090]
===
match
---
trailer [61120,61129]
trailer [62836,62845]
===
match
---
operator: , [64802,64803]
operator: , [66518,66519]
===
match
---
operator: = [61111,61112]
operator: = [62827,62828]
===
match
---
operator: = [20614,20615]
operator: = [20614,20615]
===
match
---
operator: = [6155,6156]
operator: = [6155,6156]
===
match
---
trailer [6877,6884]
trailer [6877,6884]
===
match
---
arglist [31425,31460]
arglist [33141,33176]
===
match
---
trailer [22848,22856]
trailer [22848,22856]
===
match
---
operator: = [43399,43400]
operator: = [45115,45116]
===
match
---
name: DAG [10901,10904]
name: DAG [10901,10904]
===
match
---
trailer [56692,56715]
trailer [58408,58431]
===
match
---
name: bulk_write_to_db [25494,25510]
name: bulk_write_to_db [27210,27226]
===
match
---
name: f [18945,18946]
name: f [18945,18946]
===
match
---
operator: = [48879,48880]
operator: = [50595,50596]
===
match
---
param [3177,3179]
param [3177,3179]
===
match
---
name: orm_subdag [29632,29642]
name: orm_subdag [31348,31358]
===
match
---
name: state [52532,52537]
name: state [54248,54253]
===
match
---
name: ti [69550,69552]
name: ti [71266,71268]
===
match
---
trailer [52844,52854]
trailer [54560,54570]
===
match
---
suite [10775,10838]
suite [10775,10838]
===
match
---
operator: = [48722,48723]
operator: = [50438,50439]
===
match
---
operator: @ [67006,67007]
operator: @ [68722,68723]
===
match
---
name: schedule_interval [61838,61855]
name: schedule_interval [63554,63571]
===
match
---
simple_stmt [62671,62716]
simple_stmt [64387,64432]
===
match
---
atom_expr [66578,66596]
atom_expr [68294,68312]
===
match
---
atom_expr [60297,60326]
atom_expr [62013,62042]
===
match
---
atom_expr [22297,22313]
atom_expr [22297,22313]
===
match
---
name: ti2 [17039,17042]
name: ti2 [17039,17042]
===
match
---
simple_stmt [63595,63644]
simple_stmt [65311,65360]
===
match
---
number: 0 [70543,70544]
number: 0 [72259,72260]
===
match
---
name: session [32221,32228]
name: session [33937,33944]
===
match
---
expr_stmt [20022,20056]
expr_stmt [20022,20056]
===
match
---
name: default_args [67433,67445]
name: default_args [69149,69161]
===
match
---
trailer [65905,65955]
trailer [67621,67671]
===
match
---
simple_stmt [41349,41530]
simple_stmt [43065,43246]
===
match
---
trailer [21135,21143]
trailer [21135,21143]
===
match
---
name: convert_to_utc [21579,21593]
name: convert_to_utc [21579,21593]
===
match
---
assert_stmt [71058,71098]
assert_stmt [72774,72814]
===
match
---
atom_expr [11994,12023]
atom_expr [11994,12023]
===
match
---
testlist_comp [9086,9099]
testlist_comp [9086,9099]
===
match
---
dictorsetmaker [37214,37230]
dictorsetmaker [38930,38946]
===
match
---
atom [46167,46175]
atom [47883,47891]
===
match
---
name: dag_id [6878,6884]
name: dag_id [6878,6884]
===
match
---
name: freeze_time [1177,1188]
name: freeze_time [1177,1188]
===
match
---
operator: = [20918,20919]
operator: = [20918,20919]
===
match
---
trailer [47168,47175]
trailer [48884,48891]
===
match
---
argument [47206,47222]
argument [48922,48938]
===
match
---
name: prev [21688,21692]
name: prev [21688,21692]
===
match
---
name: child_dag_name [61988,62002]
name: child_dag_name [63704,63718]
===
match
---
trailer [41259,41339]
trailer [42975,43055]
===
match
---
atom_expr [29558,29592]
atom_expr [31274,31308]
===
match
---
name: orm_dag [64372,64379]
name: orm_dag [66088,66095]
===
match
---
name: dag [29051,29054]
name: dag [30767,30770]
===
match
---
operator: = [59897,59898]
operator: = [61613,61614]
===
match
---
string: "retry_delay" [66363,66376]
string: "retry_delay" [68079,68092]
===
match
---
trailer [13336,13349]
trailer [13336,13349]
===
match
---
name: state [48717,48722]
name: state [50433,50438]
===
match
---
name: DagModel [31425,31433]
name: DagModel [33141,33149]
===
match
---
comparison [3075,3100]
comparison [3075,3100]
===
match
---
name: len [3808,3811]
name: len [3808,3811]
===
match
---
name: prev_task [14745,14754]
name: prev_task [14745,14754]
===
match
---
simple_stmt [38179,38240]
simple_stmt [39895,39956]
===
match
---
simple_stmt [17014,17031]
simple_stmt [17014,17031]
===
match
---
operator: = [3128,3129]
operator: = [3128,3129]
===
match
---
argument [16649,16670]
argument [16649,16670]
===
match
---
name: parameterized [1194,1207]
name: parameterized [1194,1207]
===
match
---
name: self [5702,5706]
name: self [5702,5706]
===
match
---
trailer [21143,21149]
trailer [21143,21149]
===
match
---
trailer [69578,69581]
trailer [71294,71297]
===
match
---
operator: == [7183,7185]
operator: == [7183,7185]
===
match
---
name: DagTag [27062,27068]
name: DagTag [28778,28784]
===
match
---
simple_stmt [11802,11886]
simple_stmt [11802,11886]
===
match
---
name: task_id [49975,49982]
name: task_id [51691,51698]
===
match
---
atom_expr [6655,6662]
atom_expr [6655,6662]
===
match
---
name: test_task_id [17926,17938]
name: test_task_id [17926,17938]
===
match
---
atom [31519,31538]
atom [33235,33254]
===
match
---
operator: , [6782,6783]
operator: , [6782,6783]
===
match
---
name: all [25890,25893]
name: all [27606,27609]
===
match
---
name: downstream_list [38688,38703]
name: downstream_list [40404,40419]
===
match
---
operator: = [69431,69432]
operator: = [71147,71148]
===
match
---
name: execution_date [43652,43666]
name: execution_date [45368,45382]
===
match
---
operator: = [18559,18560]
operator: = [18559,18560]
===
match
---
simple_stmt [13987,14030]
simple_stmt [13987,14030]
===
match
---
name: timezone [60741,60749]
name: timezone [62457,62465]
===
match
---
argument [10623,10646]
argument [10623,10646]
===
match
---
trailer [26774,26776]
trailer [28490,28492]
===
match
---
name: current_task [15947,15959]
name: current_task [15947,15959]
===
match
---
arglist [17623,17665]
arglist [17623,17665]
===
match
---
atom [18353,18388]
atom [18353,18388]
===
match
---
name: prev [22297,22301]
name: prev [22297,22301]
===
match
---
funcdef [49504,51270]
funcdef [51220,52986]
===
match
---
comparison [21782,21835]
comparison [21782,21835]
===
match
---
operator: , [14077,14078]
operator: , [14077,14078]
===
match
---
name: _clean_up [43805,43814]
name: _clean_up [45521,45530]
===
match
---
name: timezone [59650,59658]
name: timezone [61366,61374]
===
match
---
operator: = [20695,20696]
operator: = [20695,20696]
===
match
---
parameters [46738,46793]
parameters [48454,48509]
===
match
---
suite [66733,66750]
suite [68449,68466]
===
match
---
decorated [67842,68104]
decorated [69558,69820]
===
match
---
comparison [25929,26396]
comparison [27645,28112]
===
match
---
comparison [21851,21898]
comparison [21851,21898]
===
match
---
argument [52251,52283]
argument [53967,53999]
===
match
---
suite [19532,20162]
suite [19532,20162]
===
match
---
simple_stmt [50731,50762]
simple_stmt [52447,52478]
===
match
---
atom_expr [19361,19378]
atom_expr [19361,19378]
===
match
---
operator: , [48568,48569]
operator: , [50284,50285]
===
match
---
name: airflow [2111,2118]
name: airflow [2111,2118]
===
match
---
atom [55703,55705]
atom [57419,57421]
===
match
---
argument [49792,49799]
argument [51508,51515]
===
match
---
operator: , [8234,8235]
operator: , [8234,8235]
===
match
---
name: expand [46343,46349]
name: expand [48059,48065]
===
match
---
name: dag_id [51171,51177]
name: dag_id [52887,52893]
===
match
---
atom_expr [50796,51058]
atom_expr [52512,52774]
===
match
---
simple_stmt [39768,39791]
simple_stmt [41484,41507]
===
match
---
arglist [51796,51834]
arglist [53512,53550]
===
match
---
name: local_tz [34915,34923]
name: local_tz [36631,36639]
===
match
---
atom_expr [21417,21451]
atom_expr [21417,21451]
===
match
---
trailer [59159,59182]
trailer [60875,60898]
===
match
---
string: 'test-dag2' [26016,26027]
string: 'test-dag2' [27732,27743]
===
match
---
atom_expr [3759,3787]
atom_expr [3759,3787]
===
match
---
trailer [41966,41974]
trailer [43682,43690]
===
match
---
dictorsetmaker [63052,63231]
dictorsetmaker [64768,64947]
===
match
---
string: 'dummy' [61239,61246]
string: 'dummy' [62955,62962]
===
match
---
simple_stmt [19310,19349]
simple_stmt [19310,19349]
===
match
---
operator: = [44364,44365]
operator: = [46080,46081]
===
match
---
name: dag_id [5334,5340]
name: dag_id [5334,5340]
===
match
---
trailer [8424,8438]
trailer [8424,8438]
===
match
---
suite [24480,27196]
suite [26196,28912]
===
match
---
atom_expr [20786,20803]
atom_expr [20786,20803]
===
match
---
argument [36907,36961]
argument [38623,38677]
===
match
---
name: dag_id [67695,67701]
name: dag_id [69411,69417]
===
match
---
funcdef [46701,47015]
funcdef [48417,48731]
===
match
---
operator: , [22743,22744]
operator: , [22743,22744]
===
match
---
operator: = [16822,16823]
operator: = [16822,16823]
===
match
---
operator: = [30334,30335]
operator: = [32050,32051]
===
match
---
operator: , [15839,15840]
operator: , [15839,15840]
===
match
---
operator: = [56622,56623]
operator: = [58338,58339]
===
match
---
param [7307,7311]
param [7307,7311]
===
match
---
atom [65423,65425]
atom [67139,67141]
===
match
---
argument [48281,48304]
argument [49997,50020]
===
match
---
testlist_comp [26096,26126]
testlist_comp [27812,27842]
===
match
---
name: num [67145,67148]
name: num [68861,68864]
===
match
---
name: t_2 [49955,49958]
name: t_2 [51671,51674]
===
match
---
suite [61668,62066]
suite [63384,63782]
===
match
---
trailer [66507,66513]
trailer [68223,68229]
===
match
---
name: task_id [7842,7849]
name: task_id [7842,7849]
===
match
---
operator: = [51602,51603]
operator: = [53318,53319]
===
match
---
operator: = [52859,52860]
operator: = [54575,54576]
===
match
---
simple_stmt [33632,33668]
simple_stmt [35348,35384]
===
match
---
trailer [31274,31281]
trailer [32990,32997]
===
match
---
operator: = [55491,55492]
operator: = [57207,57208]
===
match
---
atom_expr [42717,42733]
atom_expr [44433,44449]
===
match
---
operator: , [58177,58178]
operator: , [59893,59894]
===
match
---
operator: , [1470,1471]
operator: , [1470,1471]
===
match
---
arglist [22717,22774]
arglist [22717,22774]
===
match
---
expr_stmt [43144,43168]
expr_stmt [44860,44884]
===
match
---
string: 'role1' [63052,63059]
string: 'role1' [64768,64775]
===
match
---
argument [63987,64002]
argument [65703,65718]
===
match
---
atom_expr [14678,14693]
atom_expr [14678,14693]
===
match
---
expr_stmt [62606,62629]
expr_stmt [64322,64345]
===
match
---
string: 'section-1' [62347,62358]
string: 'section-1' [64063,64074]
===
match
---
argument [16977,17004]
argument [16977,17004]
===
match
---
name: create_session [24704,24718]
name: create_session [26420,26434]
===
match
---
param [35152,35156]
param [36868,36872]
===
match
---
operator: = [22665,22666]
operator: = [22665,22666]
===
match
---
string: "faketastic" [39121,39133]
string: "faketastic" [40837,40849]
===
match
---
name: BaseOperator [39100,39112]
name: BaseOperator [40816,40828]
===
match
---
suite [68723,68794]
suite [70439,70510]
===
match
---
atom_expr [70918,70935]
atom_expr [72634,72651]
===
match
---
name: synchronize_session [3109,3128]
name: synchronize_session [3109,3128]
===
match
---
parameters [69059,69064]
parameters [70775,70780]
===
match
---
trailer [66023,66167]
trailer [67739,67883]
===
match
---
name: name [18504,18508]
name: name [18504,18508]
===
match
---
simple_stmt [51574,51636]
simple_stmt [53290,53352]
===
match
---
trailer [4956,4960]
trailer [4956,4960]
===
match
---
name: FAILED [52309,52315]
name: FAILED [54025,54031]
===
match
---
trailer [2969,2976]
trailer [2969,2976]
===
match
---
name: self [2599,2603]
name: self [2599,2603]
===
match
---
param [3180,3182]
param [3180,3182]
===
match
---
trailer [34997,35006]
trailer [36713,36722]
===
match
---
suite [12498,13783]
suite [12498,13783]
===
match
---
suite [33824,34717]
suite [35540,36433]
===
match
---
atom_expr [32221,32383]
atom_expr [33937,34099]
===
match
---
name: dag_subdag [61742,61752]
name: dag_subdag [63458,63468]
===
match
---
comparison [45408,45427]
comparison [47124,47143]
===
match
---
atom_expr [65787,65842]
atom_expr [67503,67558]
===
match
---
atom_expr [10345,10364]
atom_expr [10345,10364]
===
match
---
name: t [24346,24347]
name: t [26062,26063]
===
match
---
atom_expr [14781,14803]
atom_expr [14781,14803]
===
match
---
expr_stmt [66217,66405]
expr_stmt [67933,68121]
===
match
---
name: datetime [21494,21502]
name: datetime [21494,21502]
===
match
---
name: return_num [67538,67548]
name: return_num [69254,69264]
===
match
---
expr_stmt [34935,34978]
expr_stmt [36651,36694]
===
match
---
name: task_id [53660,53667]
name: task_id [55376,55383]
===
match
---
name: current_task [14719,14731]
name: current_task [14719,14731]
===
match
---
name: days [46643,46647]
name: days [48359,48363]
===
match
---
name: DEFAULT_ARGS [68944,68956]
name: DEFAULT_ARGS [70660,70672]
===
match
---
name: isoformat [22890,22899]
name: isoformat [22890,22899]
===
match
---
trailer [34886,34895]
trailer [36602,36611]
===
match
---
param [66643,66647]
param [68359,68363]
===
match
---
trailer [45732,45740]
trailer [47448,47456]
===
match
---
operator: { [70389,70390]
operator: { [72105,72106]
===
match
---
name: session [33400,33407]
name: session [35116,35123]
===
match
---
name: self [69523,69527]
name: self [71239,71243]
===
match
---
name: op1 [9397,9400]
name: op1 [9397,9400]
===
match
---
atom_expr [53953,53976]
atom_expr [55669,55692]
===
match
---
operator: = [65101,65102]
operator: = [66817,66818]
===
match
---
comparison [33575,33616]
comparison [35291,35332]
===
match
---
simple_stmt [69258,69457]
simple_stmt [70974,71173]
===
match
---
atom_expr [69555,69581]
atom_expr [71271,71297]
===
match
---
testlist_comp [26146,26175]
testlist_comp [27862,27891]
===
match
---
argument [7916,7932]
argument [7916,7932]
===
match
---
operator: , [10910,10911]
operator: , [10910,10911]
===
match
---
with_stmt [7471,7577]
with_stmt [7471,7577]
===
match
---
atom_expr [18215,18228]
atom_expr [18215,18228]
===
match
---
argument [48582,48609]
argument [50298,50325]
===
match
---
operator: = [35808,35809]
operator: = [37524,37525]
===
match
---
name: dag [37689,37692]
name: dag [39405,39408]
===
match
---
funcdef [38869,39791]
funcdef [40585,41507]
===
match
---
trailer [46642,46650]
trailer [48358,48366]
===
match
---
name: set_is_paused [32154,32167]
name: set_is_paused [33870,33883]
===
match
---
name: previous_schedule [22143,22160]
name: previous_schedule [22143,22160]
===
match
---
string: "t4" [35466,35470]
string: "t4" [37182,37186]
===
match
---
name: timedelta [50889,50898]
name: timedelta [52605,52614]
===
match
---
name: session [48746,48753]
name: session [50462,50469]
===
match
---
atom_expr [65860,65878]
atom_expr [67576,67594]
===
match
---
atom_expr [70066,70083]
atom_expr [71782,71799]
===
match
---
operator: = [42551,42552]
operator: = [44267,44268]
===
match
---
string: 't3' [38817,38821]
string: 't3' [40533,40537]
===
match
---
comparison [36063,36092]
comparison [37779,37808]
===
match
---
string: "t1" [37635,37639]
string: "t1" [39351,39355]
===
match
---
name: query [31838,31843]
name: query [33554,33559]
===
match
---
simple_stmt [55575,55643]
simple_stmt [57291,57359]
===
match
---
name: run_type [52251,52259]
name: run_type [53967,53975]
===
match
---
operator: , [52501,52502]
operator: , [54217,54218]
===
match
---
assert_stmt [62852,62945]
assert_stmt [64568,64661]
===
match
---
atom_expr [33544,33623]
atom_expr [35260,35339]
===
match
---
operator: == [44079,44081]
operator: == [45795,45797]
===
match
---
arglist [36885,36961]
arglist [38601,38677]
===
match
---
operator: == [12054,12056]
operator: == [12054,12056]
===
match
---
trailer [53323,53331]
trailer [55039,55047]
===
match
---
name: dagparam [1642,1650]
name: dagparam [1642,1650]
===
match
---
name: DummyOperator [61963,61976]
name: DummyOperator [63679,63692]
===
match
---
number: 5 [25639,25640]
number: 5 [27355,27356]
===
match
---
operator: = [3024,3025]
operator: = [3024,3025]
===
match
---
operator: @ [59257,59258]
operator: @ [60973,60974]
===
match
---
name: task_id [63987,63994]
name: task_id [65703,65710]
===
match
---
trailer [31567,31571]
trailer [33283,33287]
===
match
---
name: row [26722,26725]
name: row [28438,28441]
===
match
---
name: start [22738,22743]
name: start [22738,22743]
===
match
---
name: str [2792,2795]
name: str [2792,2795]
===
match
---
simple_stmt [22661,22698]
simple_stmt [22661,22698]
===
match
---
trailer [8540,8606]
trailer [8540,8606]
===
match
---
arglist [5021,5052]
arglist [5021,5052]
===
match
---
simple_stmt [35647,35707]
simple_stmt [37363,37423]
===
match
---
operator: , [30601,30602]
operator: , [32317,32318]
===
match
---
name: TEST_DATE [23885,23894]
name: TEST_DATE [23885,23894]
===
match
---
number: 2 [9355,9356]
number: 2 [9355,9356]
===
match
---
arith_expr [52821,52862]
arith_expr [54537,54578]
===
match
---
trailer [24902,24904]
trailer [26618,26620]
===
match
---
name: schedule_interval [56457,56474]
name: schedule_interval [58173,58190]
===
match
---
trailer [39246,39256]
trailer [40962,40972]
===
match
---
atom_expr [9645,9671]
atom_expr [9645,9671]
===
match
---
operator: = [17177,17178]
operator: = [17177,17178]
===
match
---
simple_stmt [16216,16240]
simple_stmt [16216,16240]
===
match
---
name: filter [32285,32291]
name: filter [34001,34007]
===
match
---
argument [29999,30013]
argument [31715,31729]
===
match
---
arglist [35048,35080]
arglist [36764,36796]
===
match
---
name: SubDagOperator [30043,30057]
name: SubDagOperator [31759,31773]
===
match
---
expr_stmt [49809,49883]
expr_stmt [51525,51599]
===
match
---
assert_stmt [70554,70586]
assert_stmt [72270,72302]
===
match
---
name: hash [45792,45796]
name: hash [47508,47512]
===
match
---
for_stmt [15990,16085]
for_stmt [15990,16085]
===
match
---
string: 'child_dag' [8147,8158]
string: 'child_dag' [8147,8158]
===
match
---
simple_stmt [62295,62462]
simple_stmt [64011,64178]
===
match
---
string: 'tag-1' [24302,24309]
string: 'tag-1' [26018,26025]
===
match
---
operator: = [7902,7903]
operator: = [7902,7903]
===
match
---
name: dag [11584,11587]
name: dag [11584,11587]
===
match
---
atom_expr [51348,51361]
atom_expr [53064,53077]
===
match
---
shift_expr [38041,38051]
shift_expr [39757,39767]
===
match
---
operator: , [26996,26997]
operator: , [28712,28713]
===
match
---
suite [33408,33624]
suite [35124,35340]
===
match
---
string: 't2' [38591,38595]
string: 't2' [40307,40311]
===
match
---
name: name [18539,18543]
name: name [18539,18543]
===
match
---
name: unittest [1022,1030]
name: unittest [1022,1030]
===
match
---
decorator [70712,70759]
decorator [72428,72475]
===
match
---
name: datetime [17343,17351]
name: datetime [17343,17351]
===
match
---
assert_stmt [45436,45467]
assert_stmt [47152,47183]
===
match
---
operator: , [62772,62773]
operator: , [64488,64489]
===
match
---
operator: = [60014,60015]
operator: = [61730,61731]
===
match
---
name: DagTag [25171,25177]
name: DagTag [26887,26893]
===
match
---
simple_stmt [7874,7934]
simple_stmt [7874,7934]
===
match
---
operator: = [3718,3719]
operator: = [3718,3719]
===
match
---
simple_stmt [45476,45512]
simple_stmt [47192,47228]
===
match
---
name: dirname [19038,19045]
name: dirname [19038,19045]
===
match
---
operator: , [64308,64309]
operator: , [66024,66025]
===
match
---
operator: = [5340,5341]
operator: = [5340,5341]
===
match
---
expr_stmt [70009,70037]
expr_stmt [71725,71753]
===
match
---
atom_expr [21916,21943]
atom_expr [21916,21943]
===
match
---
name: dag_diff_name [44476,44489]
name: dag_diff_name [46192,46205]
===
match
---
trailer [55039,55050]
trailer [56755,56766]
===
match
---
trailer [49115,49121]
trailer [50831,50837]
===
match
---
atom_expr [47263,47287]
atom_expr [48979,49003]
===
match
---
operator: , [49936,49937]
operator: , [51652,51653]
===
match
---
arglist [24525,24589]
arglist [26241,26305]
===
match
---
expr_stmt [43101,43135]
expr_stmt [44817,44851]
===
match
---
atom_expr [22005,22027]
atom_expr [22005,22027]
===
match
---
operator: = [6368,6369]
operator: = [6368,6369]
===
match
---
argument [49775,49790]
argument [51491,51506]
===
match
---
trailer [22574,22582]
trailer [22574,22582]
===
match
---
testlist_comp [10246,10254]
testlist_comp [10246,10254]
===
match
---
name: timedelta [57098,57107]
name: timedelta [58814,58823]
===
match
---
name: one [34280,34283]
name: one [35996,35999]
===
match
---
operator: = [55380,55381]
operator: = [57096,57097]
===
match
---
name: pendulum [34805,34813]
name: pendulum [36521,36529]
===
match
---
string: "faketastic" [41281,41293]
string: "faketastic" [42997,43009]
===
match
---
trailer [29109,29115]
trailer [30825,30831]
===
match
---
argument [10912,10979]
argument [10912,10979]
===
match
---
arglist [62169,62179]
arglist [63885,63895]
===
match
---
operator: , [46679,46680]
operator: , [48395,48396]
===
match
---
trailer [57779,57802]
trailer [59495,59518]
===
match
---
argument [7842,7860]
argument [7842,7860]
===
match
---
operator: } [15439,15440]
operator: } [15439,15440]
===
match
---
name: dag_run [40498,40505]
name: dag_run [42214,42221]
===
match
---
expr_stmt [39987,40021]
expr_stmt [41703,41737]
===
match
---
name: self [30597,30601]
name: self [32313,32317]
===
match
---
comparison [29284,29316]
comparison [31000,31032]
===
match
---
trailer [21434,21451]
trailer [21434,21451]
===
match
---
trailer [21751,21759]
trailer [21751,21759]
===
match
---
operator: , [17846,17847]
operator: , [17846,17847]
===
match
---
operator: , [59292,59293]
operator: , [61008,61009]
===
match
---
number: 1 [40296,40297]
number: 1 [42012,42013]
===
match
---
operator: = [54002,54003]
operator: = [55718,55719]
===
match
---
trailer [45949,45987]
trailer [47665,47703]
===
match
---
operator: != [45028,45030]
operator: != [46744,46746]
===
match
---
expr_stmt [58225,58270]
expr_stmt [59941,59986]
===
match
---
trailer [13494,13510]
trailer [13494,13510]
===
match
---
name: split [29199,29204]
name: split [30915,30920]
===
match
---
trailer [39392,39399]
trailer [41108,41115]
===
match
---
name: next_dagrun_create_after [27895,27919]
name: next_dagrun_create_after [29611,29635]
===
match
---
simple_stmt [19910,19959]
simple_stmt [19910,19959]
===
match
---
name: TEST_DATE [39165,39174]
name: TEST_DATE [40881,40890]
===
match
---
operator: { [62009,62010]
operator: { [63725,63726]
===
match
---
name: task_depth [13621,13631]
name: task_depth [13621,13631]
===
match
---
name: DagModel [34253,34261]
name: DagModel [35969,35977]
===
match
---
name: settings [48398,48406]
name: settings [50114,50122]
===
match
---
name: conf [5012,5016]
name: conf [5012,5016]
===
match
---
trailer [25304,25307]
trailer [27020,27023]
===
match
---
with_item [41568,41595]
with_item [43284,43311]
===
match
---
trailer [2976,2997]
trailer [2976,2997]
===
match
---
atom_expr [48746,48776]
atom_expr [50462,50492]
===
match
---
name: State [18374,18379]
name: State [18374,18379]
===
match
---
comparison [21007,21060]
comparison [21007,21060]
===
match
---
expr_stmt [3452,3463]
expr_stmt [3452,3463]
===
match
---
name: DEFAULT_DATE [28724,28736]
name: DEFAULT_DATE [30440,30452]
===
match
---
simple_stmt [18424,18440]
simple_stmt [18424,18440]
===
match
---
operator: { [10808,10809]
operator: { [10808,10809]
===
match
---
simple_stmt [51844,51892]
simple_stmt [53560,53608]
===
match
---
comparison [17591,17666]
comparison [17591,17666]
===
match
---
simple_stmt [1765,1817]
simple_stmt [1765,1817]
===
match
---
name: query [25165,25170]
name: query [26881,26886]
===
match
---
string: 'dag.subtask' [28682,28695]
string: 'dag.subtask' [30398,30411]
===
match
---
for_stmt [3316,3464]
for_stmt [3316,3464]
===
match
---
name: dag [47750,47753]
name: dag [49466,49469]
===
match
---
string: 'some_string' [20147,20160]
string: 'some_string' [20147,20160]
===
match
---
expr_stmt [39186,39338]
expr_stmt [40902,41054]
===
match
---
name: dag_id [42238,42244]
name: dag_id [43954,43960]
===
match
---
simple_stmt [64480,64504]
simple_stmt [66196,66220]
===
match
---
trailer [67605,67608]
trailer [69321,69324]
===
match
---
expr_stmt [44357,44401]
expr_stmt [46073,46117]
===
match
---
number: 5 [59674,59675]
number: 5 [61390,61391]
===
match
---
argument [54012,54039]
argument [55728,55755]
===
match
---
name: set_upstream [13337,13349]
name: set_upstream [13337,13349]
===
match
---
simple_stmt [56267,56376]
simple_stmt [57983,58092]
===
match
---
simple_stmt [51520,51543]
simple_stmt [53236,53259]
===
match
---
number: 1 [66449,66450]
number: 1 [68165,68166]
===
match
---
operator: , [21507,21508]
operator: , [21507,21508]
===
match
---
name: values [16124,16130]
name: values [16124,16130]
===
match
---
argument [52812,52862]
argument [54528,54578]
===
match
---
trailer [2912,2939]
trailer [2912,2939]
===
match
---
name: dag_id [31730,31736]
name: dag_id [33446,33452]
===
match
---
name: test_dag_as_context_manager [5674,5701]
name: test_dag_as_context_manager [5674,5701]
===
match
---
fstring_string: dag_run.execution_date did not match expectation:  [39574,39624]
fstring_string: dag_run.execution_date did not match expectation:  [41290,41340]
===
match
---
string: "2018-10-28T02:00:00+00:00" [22095,22122]
string: "2018-10-28T02:00:00+00:00" [22095,22122]
===
match
---
operator: , [32339,32340]
operator: , [34055,34056]
===
match
---
dictorsetmaker [10926,10978]
dictorsetmaker [10926,10978]
===
match
---
name: query [31210,31215]
name: query [32926,32931]
===
match
---
string: "t1" [36279,36283]
string: "t1" [37995,37999]
===
match
---
atom [25054,25085]
atom [26770,26801]
===
match
---
name: xcom_arg [69163,69171]
name: xcom_arg [70879,70887]
===
match
---
trailer [50077,50244]
trailer [51793,51960]
===
match
---
operator: { [35600,35601]
operator: { [37316,37317]
===
match
---
name: DEFAULT_DATE [37909,37921]
name: DEFAULT_DATE [39625,39637]
===
match
---
name: range [61937,61942]
name: range [63653,63658]
===
match
---
operator: { [65927,65928]
operator: { [67643,67644]
===
match
---
atom_expr [43969,44004]
atom_expr [45685,45720]
===
match
---
argument [41314,41337]
argument [43030,43053]
===
match
---
name: dag_id [39393,39399]
name: dag_id [41109,41115]
===
match
---
trailer [62489,62496]
trailer [64205,64212]
===
match
---
operator: = [64282,64283]
operator: = [65998,65999]
===
match
---
arglist [27560,27601]
arglist [29276,29317]
===
match
---
trailer [7208,7212]
trailer [7208,7212]
===
match
---
parameters [68542,68547]
parameters [70258,70263]
===
match
---
name: subdag [51884,51890]
name: subdag [53600,53606]
===
match
---
name: setUp [66479,66484]
name: setUp [68195,68200]
===
match
---
name: dag_id [32341,32347]
name: dag_id [34057,34063]
===
match
---
name: width [13035,13040]
name: width [13035,13040]
===
match
---
operator: = [47895,47896]
operator: = [49611,49612]
===
match
---
operator: = [6189,6190]
operator: = [6189,6190]
===
match
---
atom_expr [19454,19469]
atom_expr [19454,19469]
===
match
---
expr_stmt [57126,57328]
expr_stmt [58842,59044]
===
match
---
trailer [7238,7242]
trailer [7238,7242]
===
match
---
name: RUNNING [39671,39678]
name: RUNNING [41387,41394]
===
match
---
expr_stmt [64830,64858]
expr_stmt [66546,66574]
===
match
---
trailer [17431,17439]
trailer [17431,17439]
===
match
---
operator: = [53574,53575]
operator: = [55290,55291]
===
match
---
name: add [64368,64371]
name: add [66084,66087]
===
match
---
operator: >> [38045,38047]
operator: >> [39761,39763]
===
match
---
exprlist [14509,14517]
exprlist [14509,14517]
===
match
---
name: session [17751,17758]
name: session [17751,17758]
===
match
---
operator: = [30809,30810]
operator: = [32525,32526]
===
match
---
name: session [29074,29081]
name: session [30790,30797]
===
match
---
trailer [48903,48913]
trailer [50619,50629]
===
match
---
name: subdag [28869,28875]
name: subdag [30585,30591]
===
match
---
suite [64611,65478]
suite [66327,67194]
===
match
---
name: hash [45817,45821]
name: hash [47533,47537]
===
match
---
expr_stmt [17039,17121]
expr_stmt [17039,17121]
===
match
---
operator: = [41437,41438]
operator: = [43153,43154]
===
match
---
string: 'dag-bulk-sync-1' [24772,24789]
string: 'dag-bulk-sync-1' [26488,26505]
===
match
---
trailer [33557,33567]
trailer [35273,35283]
===
match
---
name: dag2 [7154,7158]
name: dag2 [7154,7158]
===
match
---
name: datetime [54971,54979]
name: datetime [56687,56695]
===
match
---
operator: = [14287,14288]
operator: = [14287,14288]
===
match
---
name: State [52622,52627]
name: State [54338,54343]
===
match
---
simple_stmt [48209,48232]
simple_stmt [49925,49948]
===
match
---
suite [69677,70587]
suite [71393,72303]
===
match
---
simple_stmt [33270,33295]
simple_stmt [34986,35011]
===
match
---
argument [38336,38359]
argument [40052,40075]
===
match
---
operator: , [12016,12017]
operator: , [12016,12017]
===
match
---
atom_expr [10418,10450]
atom_expr [10418,10450]
===
match
---
expr_stmt [37552,37594]
expr_stmt [39268,39310]
===
match
---
argument [52297,52315]
argument [54013,54031]
===
match
---
trailer [55825,55832]
trailer [57541,57548]
===
match
---
simple_stmt [41103,41156]
simple_stmt [42819,42872]
===
match
---
with_stmt [41563,41660]
with_stmt [43279,43376]
===
match
---
operator: = [36324,36325]
operator: = [38040,38041]
===
match
---
name: six_hours_ago_to_the_hour [57265,57290]
name: six_hours_ago_to_the_hour [58981,59006]
===
match
---
operator: = [22790,22791]
operator: = [22790,22791]
===
match
---
trailer [47148,47223]
trailer [48864,48939]
===
match
---
name: start_date [43496,43506]
name: start_date [45212,45222]
===
match
---
atom_expr [38829,38863]
atom_expr [40545,40579]
===
match
---
argument [28012,28044]
argument [29728,29760]
===
match
---
with_stmt [4617,4796]
with_stmt [4617,4796]
===
match
---
trailer [28238,28253]
trailer [29954,29969]
===
match
---
name: rollback [65443,65451]
name: rollback [67159,67167]
===
match
---
name: DummyOperator [7107,7120]
name: DummyOperator [7107,7120]
===
match
---
name: DagModel [31861,31869]
name: DagModel [33577,33585]
===
match
---
arith_expr [51711,51727]
arith_expr [53427,53443]
===
match
---
testlist_comp [31520,31537]
testlist_comp [33236,33253]
===
match
---
trailer [30315,30326]
trailer [32031,32042]
===
match
---
trailer [31252,31273]
trailer [32968,32989]
===
match
---
trailer [17490,17495]
trailer [17490,17495]
===
match
---
operator: = [11953,11954]
operator: = [11953,11954]
===
match
---
atom [55395,55405]
atom [57111,57121]
===
match
---
argument [61257,61272]
argument [62973,62988]
===
match
---
name: DagTag [24387,24393]
name: DagTag [26103,26109]
===
match
---
string: 'subtask' [30083,30092]
string: 'subtask' [31799,31808]
===
match
---
operator: } [12901,12902]
operator: } [12901,12902]
===
match
---
name: DAG [33944,33947]
name: DAG [35660,35663]
===
match
---
operator: , [32462,32463]
operator: , [34178,34179]
===
match
---
trailer [21855,21865]
trailer [21855,21865]
===
match
---
operator: = [37999,38000]
operator: = [39715,39716]
===
match
---
atom_expr [10901,10980]
atom_expr [10901,10980]
===
match
---
trailer [39440,39447]
trailer [41156,41163]
===
match
---
name: merge [52421,52426]
name: merge [54137,54142]
===
match
---
name: execution_date [17064,17078]
name: execution_date [17064,17078]
===
match
---
operator: == [11762,11764]
operator: == [11762,11764]
===
match
---
operator: == [33710,33712]
operator: == [35426,35428]
===
match
---
trailer [36362,36376]
trailer [38078,38092]
===
match
---
trailer [28496,28563]
trailer [30212,30279]
===
match
---
atom_expr [25576,25604]
atom_expr [27292,27320]
===
match
---
atom [25743,25819]
atom [27459,27535]
===
match
---
operator: = [61262,61263]
operator: = [62978,62979]
===
match
---
name: models [1443,1449]
name: models [1443,1449]
===
match
---
name: dag [43217,43220]
name: dag [44933,44936]
===
match
---
name: value [69319,69324]
name: value [71035,71040]
===
match
---
expr_stmt [21610,21678]
expr_stmt [21610,21678]
===
match
---
name: state [17134,17139]
name: state [17134,17139]
===
match
---
simple_stmt [67595,67609]
simple_stmt [69311,69325]
===
match
---
atom [31643,31661]
atom [33359,33377]
===
match
---
atom_expr [43177,43198]
atom_expr [44893,44914]
===
match
---
name: dag_run [39403,39410]
name: dag_run [41119,41126]
===
match
---
param [2647,2651]
param [2647,2651]
===
match
---
name: task_id [7895,7902]
name: task_id [7895,7902]
===
match
---
shift_expr [56783,56800]
shift_expr [58499,58516]
===
match
---
name: next_dagrun_after_date [61299,61321]
name: next_dagrun_after_date [63015,63037]
===
match
---
simple_stmt [44978,44999]
simple_stmt [46694,46715]
===
match
---
name: include_parentdag [52951,52968]
name: include_parentdag [54667,54684]
===
match
---
name: dag [62019,62022]
name: dag [63735,63738]
===
match
---
name: DummyOperator [37558,37571]
name: DummyOperator [39274,39287]
===
match
---
name: DEFAULT_DATE [50428,50440]
name: DEFAULT_DATE [52144,52156]
===
match
---
trailer [44788,44800]
trailer [46504,46516]
===
match
---
name: default_args [44518,44530]
name: default_args [46234,46246]
===
match
---
simple_stmt [4856,4936]
simple_stmt [4856,4936]
===
match
---
name: all [25199,25202]
name: all [26915,26918]
===
match
---
fstring_string: stage [14233,14238]
fstring_string: stage [14233,14238]
===
match
---
name: dag_id [61051,61057]
name: dag_id [62767,62773]
===
match
---
name: pendulum [21530,21538]
name: pendulum [21530,21538]
===
match
---
expr_stmt [64701,64755]
expr_stmt [66417,66471]
===
match
---
trailer [70282,70289]
trailer [71998,72005]
===
match
---
name: subdag [62490,62496]
name: subdag [64206,64212]
===
match
---
operator: @ [65633,65634]
operator: @ [67349,67350]
===
match
---
simple_stmt [17450,17469]
simple_stmt [17450,17469]
===
match
---
string: "faketastic" [23789,23801]
string: "faketastic" [23789,23801]
===
match
---
name: datetime [63943,63951]
name: datetime [65659,65667]
===
match
---
operator: , [70291,70292]
operator: , [72007,72008]
===
match
---
atom_expr [15850,15869]
atom_expr [15850,15869]
===
match
---
name: session [30529,30536]
name: session [32245,32252]
===
match
---
name: following_schedule [20701,20719]
name: following_schedule [20701,20719]
===
match
---
dictorsetmaker [38204,38238]
dictorsetmaker [39920,39954]
===
match
---
comparison [17988,18111]
comparison [17988,18111]
===
match
---
name: dag_id [31531,31537]
name: dag_id [33247,33253]
===
match
---
trailer [63154,63185]
trailer [64870,64901]
===
match
---
trailer [48820,49074]
trailer [50536,50790]
===
match
---
trailer [33105,33115]
trailer [34821,34831]
===
match
---
comp_op [38822,38828]
comp_op [40538,40544]
===
match
---
arglist [22583,22650]
arglist [22583,22650]
===
match
---
operator: , [51333,51334]
operator: , [53049,53050]
===
match
---
testlist_comp [24521,24611]
testlist_comp [26237,26327]
===
match
---
operator: = [57311,57312]
operator: = [59027,59028]
===
match
---
name: e [3420,3421]
name: e [3420,3421]
===
match
---
operator: , [46422,46423]
operator: , [48138,48139]
===
match
---
atom_expr [18277,18415]
atom_expr [18277,18415]
===
match
---
param [8516,8520]
param [8516,8520]
===
match
---
simple_stmt [22176,22212]
simple_stmt [22176,22212]
===
match
---
operator: = [30631,30632]
operator: = [32347,32348]
===
match
---
atom_expr [2599,2628]
atom_expr [2599,2628]
===
match
---
argument [9659,9670]
argument [9659,9670]
===
match
---
trailer [8889,8902]
trailer [8889,8902]
===
match
---
name: _next [23854,23859]
name: _next [23854,23859]
===
match
---
if_stmt [15887,15927]
if_stmt [15887,15927]
===
match
---
name: dag_diff_name [45414,45427]
name: dag_diff_name [47130,47143]
===
match
---
trailer [25416,25433]
trailer [27132,27149]
===
match
---
argument [35504,35516]
argument [37220,37232]
===
match
---
funcdef [10732,10838]
funcdef [10732,10838]
===
match
---
arglist [49975,50001]
arglist [51691,51717]
===
match
---
name: session [34615,34622]
name: session [36331,36338]
===
match
---
assert_stmt [6272,6294]
assert_stmt [6272,6294]
===
match
---
import_as_name [1601,1621]
import_as_name [1601,1621]
===
match
---
name: fileloc [34033,34040]
name: fileloc [35749,35756]
===
match
---
name: topological_list [10100,10116]
name: topological_list [10100,10116]
===
match
---
comp_op [25308,25314]
comp_op [27024,27030]
===
match
---
string: 'dag' [15376,15381]
string: 'dag' [15376,15381]
===
match
---
simple_stmt [28401,28447]
simple_stmt [30117,30163]
===
match
---
argument [61166,61197]
argument [62882,62913]
===
match
---
name: DummyOperator [12954,12967]
name: DummyOperator [12954,12967]
===
match
---
name: Session [53714,53721]
name: Session [55430,55437]
===
match
---
trailer [52697,52714]
trailer [54413,54430]
===
match
---
dotted_name [51276,51296]
dotted_name [52992,53012]
===
match
---
operator: { [12883,12884]
operator: { [12883,12884]
===
match
---
operator: = [60920,60921]
operator: = [62636,62637]
===
match
---
argument [70219,70249]
argument [71935,71965]
===
match
---
operator: , [32047,32048]
operator: , [33763,33764]
===
match
---
simple_stmt [10127,10145]
simple_stmt [10127,10145]
===
match
---
with_stmt [7793,8017]
with_stmt [7793,8017]
===
match
---
atom_expr [16007,16022]
atom_expr [16007,16022]
===
match
---
parameters [67752,67758]
parameters [69468,69474]
===
match
---
name: session [65379,65386]
name: session [67095,67102]
===
match
---
name: include_downstream [38620,38638]
name: include_downstream [40336,40354]
===
match
---
trailer [34229,34235]
trailer [35945,35951]
===
match
---
name: j [14399,14400]
name: j [14399,14400]
===
match
---
trailer [47134,47148]
trailer [48850,48864]
===
match
---
trailer [21698,21716]
trailer [21698,21716]
===
match
---
operator: = [11978,11979]
operator: = [11978,11979]
===
match
---
trailer [42611,42619]
trailer [44327,44335]
===
match
---
string: '@hourly' [57656,57665]
string: '@hourly' [59372,59381]
===
match
---
arglist [65906,65954]
arglist [67622,67670]
===
match
---
atom_expr [70793,70803]
atom_expr [72509,72519]
===
match
---
assert_stmt [22872,22932]
assert_stmt [22872,22932]
===
match
---
trailer [54425,54432]
trailer [56141,56148]
===
match
---
name: dag [59542,59545]
name: dag [61258,61261]
===
match
---
simple_stmt [17504,17523]
simple_stmt [17504,17523]
===
match
---
name: default_args [11854,11866]
name: default_args [11854,11866]
===
match
---
atom_expr [64360,64380]
atom_expr [66076,66096]
===
match
---
name: orm_subdag [29459,29469]
name: orm_subdag [31175,31185]
===
match
---
name: dag [71026,71029]
name: dag [72742,72745]
===
match
---
atom [54350,54513]
atom [56066,56229]
===
match
---
name: default_args [12870,12882]
name: default_args [12870,12882]
===
match
---
atom_expr [25873,25888]
atom_expr [27589,27604]
===
match
---
number: 4 [59297,59298]
number: 4 [61013,61014]
===
match
---
trailer [29561,29592]
trailer [31277,31308]
===
match
---
funcdef [19489,20162]
funcdef [19489,20162]
===
match
---
trailer [59667,59679]
trailer [61383,61395]
===
match
---
name: when [40379,40383]
name: when [42095,42099]
===
match
---
operator: , [51047,51048]
operator: , [52763,52764]
===
match
---
simple_stmt [43014,43093]
simple_stmt [44730,44809]
===
match
---
name: calculated_weight [15056,15073]
name: calculated_weight [15056,15073]
===
match
---
operator: = [43250,43251]
operator: = [44966,44967]
===
match
---
name: operator [70973,70981]
name: operator [72689,72697]
===
match
---
trailer [66585,66594]
trailer [68301,68310]
===
match
---
dictorsetmaker [26722,26776]
dictorsetmaker [28438,28492]
===
match
---
atom_expr [49892,49946]
atom_expr [51608,51662]
===
match
---
operator: = [19829,19830]
operator: = [19829,19830]
===
match
---
operator: , [24309,24310]
operator: , [26025,26026]
===
match
---
name: self [63000,63004]
name: self [64716,64720]
===
match
---
name: session [33056,33063]
name: session [34772,34779]
===
match
---
trailer [21619,21678]
trailer [21619,21678]
===
match
---
atom_expr [38479,38506]
atom_expr [40195,40222]
===
match
---
operator: + [49829,49830]
operator: + [51545,51546]
===
match
---
suite [69859,70119]
suite [71575,71835]
===
match
---
operator: } [27024,27025]
operator: } [28740,28741]
===
match
---
funcdef [53403,54691]
funcdef [55119,56407]
===
match
---
assert_stmt [45043,45075]
assert_stmt [46759,46791]
===
match
---
operator: , [37896,37897]
operator: , [39612,39613]
===
match
---
operator: , [37639,37640]
operator: , [39355,39356]
===
match
---
expr_stmt [23229,23264]
expr_stmt [23229,23264]
===
match
---
atom_expr [21127,21149]
atom_expr [21127,21149]
===
match
---
name: utils [1956,1961]
name: utils [1956,1961]
===
match
---
string: 'dag-bulk-sync-1' [26047,26064]
string: 'dag-bulk-sync-1' [27763,27780]
===
match
---
name: DAG [47084,47087]
name: DAG [48800,48803]
===
match
---
arglist [24146,24213]
arglist [25862,25929]
===
match
---
name: i [14561,14562]
name: i [14561,14562]
===
match
---
trailer [24386,24422]
trailer [26102,26138]
===
match
---
suite [36794,37232]
suite [38510,38948]
===
match
---
atom_expr [40508,40574]
atom_expr [42224,42290]
===
match
---
argument [17189,17245]
argument [17189,17245]
===
match
---
trailer [42720,42731]
trailer [44436,44447]
===
match
---
expr_stmt [9077,9100]
expr_stmt [9077,9100]
===
match
---
operator: , [56231,56232]
operator: , [57947,57948]
===
match
---
atom_expr [35720,35760]
atom_expr [37436,37476]
===
match
---
operator: = [24194,24195]
operator: = [25910,25911]
===
match
---
name: _next [21982,21987]
name: _next [21982,21987]
===
match
---
name: len [54530,54533]
name: len [56246,56249]
===
match
---
name: dag [21077,21080]
name: dag [21077,21080]
===
match
---
name: dag_id [39783,39789]
name: dag_id [41499,41505]
===
match
---
comparison [33683,33762]
comparison [35399,35478]
===
match
---
trailer [28911,28921]
trailer [30627,30637]
===
match
---
expr_stmt [30870,30947]
expr_stmt [32586,32663]
===
match
---
string: "t1" [37074,37078]
string: "t1" [38790,38794]
===
match
---
atom_expr [49467,49480]
atom_expr [51183,51196]
===
match
---
simple_stmt [59945,59995]
simple_stmt [61661,61711]
===
match
---
trailer [27845,27857]
trailer [29561,29573]
===
match
---
atom_expr [11731,11761]
atom_expr [11731,11761]
===
match
---
simple_stmt [22221,22282]
simple_stmt [22221,22282]
===
match
---
simple_stmt [19361,19396]
simple_stmt [19361,19396]
===
match
---
trailer [17911,17972]
trailer [17911,17972]
===
match
---
trailer [70563,70573]
trailer [72279,72289]
===
match
---
arglist [53790,53934]
arglist [55506,55650]
===
match
---
atom_expr [64906,64916]
atom_expr [66622,66632]
===
match
---
trailer [14046,14112]
trailer [14046,14112]
===
match
---
atom_expr [16563,16594]
atom_expr [16563,16594]
===
match
---
assert_stmt [45401,45427]
assert_stmt [47117,47143]
===
match
---
operator: = [52259,52260]
operator: = [53975,53976]
===
match
---
dictorsetmaker [12377,12395]
dictorsetmaker [12377,12395]
===
match
---
operator: , [18344,18345]
operator: , [18344,18345]
===
match
---
atom_expr [23755,23844]
atom_expr [23755,23844]
===
match
---
atom_expr [66425,66454]
atom_expr [68141,68170]
===
match
---
name: filter [24380,24386]
name: filter [26096,26102]
===
match
---
name: in_ [31515,31518]
name: in_ [33231,33234]
===
match
---
operator: = [37908,37909]
operator: = [39624,39625]
===
match
---
name: TestQueries [65486,65497]
name: TestQueries [67202,67213]
===
match
---
name: get_dagmodel [46037,46049]
name: get_dagmodel [47753,47765]
===
match
---
operator: , [56760,56761]
operator: , [58476,58477]
===
match
---
number: 2018 [22601,22605]
number: 2018 [22601,22605]
===
match
---
comparison [32410,32500]
comparison [34126,34216]
===
match
---
argument [4338,4352]
argument [4338,4352]
===
match
---
name: task_id [38015,38022]
name: task_id [39731,39738]
===
match
---
simple_stmt [42301,42349]
simple_stmt [44017,44065]
===
match
---
trailer [43615,43617]
trailer [45331,45333]
===
match
---
atom_expr [18360,18372]
atom_expr [18360,18372]
===
match
---
trailer [58241,58264]
trailer [59957,59980]
===
match
---
number: 1 [51770,51771]
number: 1 [53486,53487]
===
match
---
simple_stmt [55695,55706]
simple_stmt [57411,57422]
===
match
---
name: dag [56762,56765]
name: dag [58478,58481]
===
match
---
operator: , [58837,58838]
operator: , [60553,60554]
===
match
---
name: _clean_up [40824,40833]
name: _clean_up [42540,42549]
===
match
---
operator: = [27580,27581]
operator: = [29296,29297]
===
match
---
string: 'owner' [6053,6060]
string: 'owner' [6053,6060]
===
match
---
name: self [60370,60374]
name: self [62086,62090]
===
match
---
operator: , [50123,50124]
operator: , [51839,51840]
===
match
---
name: test_pickling [43832,43845]
name: test_pickling [45548,45561]
===
match
---
simple_stmt [38923,38992]
simple_stmt [40639,40708]
===
match
---
trailer [10724,10726]
trailer [10724,10726]
===
match
---
comparison [20115,20161]
comparison [20115,20161]
===
match
---
name: DummyOperator [36349,36362]
name: DummyOperator [38065,38078]
===
match
---
name: dag [9452,9455]
name: dag [9452,9455]
===
match
---
operator: = [31785,31786]
operator: = [33501,33502]
===
match
---
string: 'dag_default_view_old' [33594,33616]
string: 'dag_default_view_old' [35310,35332]
===
match
---
atom_expr [22667,22697]
atom_expr [22667,22697]
===
match
---
trailer [53960,53966]
trailer [55676,55682]
===
match
---
name: dag [59787,59790]
name: dag [61503,61506]
===
match
---
name: SUCCESS [42612,42619]
name: SUCCESS [44328,44335]
===
match
---
expr_stmt [51551,51565]
expr_stmt [53267,53281]
===
match
---
name: datetime [54821,54829]
name: datetime [56537,56545]
===
match
---
simple_stmt [31202,31331]
simple_stmt [32918,33047]
===
match
---
operator: } [12023,12024]
operator: } [12023,12024]
===
match
---
operator: = [37141,37142]
operator: = [38857,38858]
===
match
---
operator: , [28695,28696]
operator: , [30411,30412]
===
match
---
name: task_depth [14873,14883]
name: task_depth [14873,14883]
===
match
---
operator: , [53442,53443]
operator: , [55158,55159]
===
match
---
simple_stmt [1858,1893]
simple_stmt [1858,1893]
===
match
---
argument [12100,12140]
argument [12100,12140]
===
match
---
funcdef [42971,43823]
funcdef [44687,45539]
===
match
---
operator: , [61644,61645]
operator: , [63360,63361]
===
match
---
operator: = [39284,39285]
operator: = [41000,41001]
===
match
---
name: child_dag [7923,7932]
name: child_dag [7923,7932]
===
match
---
operator: { [4212,4213]
operator: { [4212,4213]
===
match
---
argument [23679,23687]
argument [23679,23687]
===
match
---
atom [44709,44770]
atom [46425,46486]
===
match
---
operator: , [20646,20647]
operator: , [20646,20647]
===
match
---
operator: = [48948,48949]
operator: = [50664,50665]
===
match
---
name: set_downstream [9868,9882]
name: set_downstream [9868,9882]
===
match
---
operator: = [28491,28492]
operator: = [30207,30208]
===
match
---
name: merge [17485,17490]
name: merge [17485,17490]
===
match
---
name: DAG [59548,59551]
name: DAG [61264,61267]
===
match
---
name: create_session [41568,41582]
name: create_session [43284,43298]
===
match
---
simple_stmt [61028,61209]
simple_stmt [62744,62925]
===
match
---
atom_expr [50307,50330]
atom_expr [52023,52046]
===
match
---
operator: , [62176,62177]
operator: , [63892,63893]
===
match
---
name: DummyOperator [7064,7077]
name: DummyOperator [7064,7077]
===
match
---
operator: = [47129,47130]
operator: = [48845,48846]
===
match
---
operator: = [64084,64085]
operator: = [65800,65801]
===
match
---
name: DAGsubclass [44561,44572]
name: DAGsubclass [46277,46288]
===
match
---
string: '@daily' [7660,7668]
string: '@daily' [7660,7668]
===
match
---
arglist [30174,30233]
arglist [31890,31949]
===
match
---
expr_stmt [58934,58978]
expr_stmt [60650,60694]
===
match
---
funcdef [3159,3502]
funcdef [3159,3502]
===
match
---
suite [36123,36718]
suite [37839,38434]
===
match
---
suite [6351,6399]
suite [6351,6399]
===
match
---
name: set_downstream [10008,10022]
name: set_downstream [10008,10022]
===
match
---
argument [17848,17863]
argument [17848,17863]
===
match
---
trailer [34499,34526]
trailer [36215,36242]
===
match
---
trailer [52016,52030]
trailer [53732,53746]
===
match
---
name: params1 [4381,4388]
name: params1 [4381,4388]
===
match
---
param [28472,28476]
param [30188,30192]
===
match
---
name: dags [26440,26444]
name: dags [28156,28160]
===
match
---
name: calculated_weight [13677,13694]
name: calculated_weight [13677,13694]
===
match
---
name: execution_date [53906,53920]
name: execution_date [55622,55636]
===
match
---
operator: , [48609,48610]
operator: , [50325,50326]
===
match
---
name: weight_rule [14320,14331]
name: weight_rule [14320,14331]
===
match
---
arglist [59288,59298]
arglist [61004,61014]
===
match
---
name: dag [41538,41541]
name: dag [43254,43257]
===
match
---
name: timedelta [41076,41085]
name: timedelta [42792,42801]
===
match
---
suite [12244,12447]
suite [12244,12447]
===
match
---
parameters [5701,5707]
parameters [5701,5707]
===
match
---
trailer [61364,61373]
trailer [63080,63089]
===
match
---
operator: = [23284,23285]
operator: = [23284,23285]
===
match
---
name: State [53842,53847]
name: State [55558,55563]
===
match
---
atom_expr [63761,63779]
atom_expr [65477,65495]
===
match
---
name: dag [46972,46975]
name: dag [48688,48691]
===
match
---
testlist_comp [42825,42836]
testlist_comp [44541,44552]
===
match
---
name: next_date [60004,60013]
name: next_date [61720,61729]
===
match
---
string: "sleep 1" [37142,37151]
string: "sleep 1" [38858,38867]
===
match
---
import_from [918,948]
import_from [918,948]
===
match
---
trailer [38400,38414]
trailer [40116,40130]
===
match
---
comparison [54624,54659]
comparison [56340,56375]
===
match
---
name: DagTag [1480,1486]
name: DagTag [1480,1486]
===
match
---
name: provide_session [1993,2008]
name: provide_session [1993,2008]
===
match
---
expr_stmt [65336,65393]
expr_stmt [67052,67109]
===
match
---
trailer [19691,19696]
trailer [19691,19696]
===
match
---
operator: = [31018,31019]
operator: = [32734,32735]
===
match
---
name: subdag [62471,62477]
name: subdag [64187,64193]
===
match
---
name: task [17173,17177]
name: task [17173,17177]
===
match
---
string: 'test' [49915,49921]
string: 'test' [51631,51637]
===
match
---
argument [55485,55498]
argument [57201,57214]
===
match
---
with_item [36425,36465]
with_item [38141,38181]
===
match
---
simple_stmt [18704,18740]
simple_stmt [18704,18740]
===
match
---
atom_expr [53705,53723]
atom_expr [55421,55439]
===
match
---
trailer [6936,6944]
trailer [6936,6944]
===
match
---
funcdef [24448,27196]
funcdef [26164,28912]
===
match
---
trailer [9903,9918]
trailer [9903,9918]
===
match
---
atom_expr [40404,40488]
atom_expr [42120,42204]
===
match
---
name: TIMEZONE [12182,12190]
name: TIMEZONE [12182,12190]
===
match
---
trailer [16906,16942]
trailer [16906,16942]
===
match
---
atom_expr [22074,22091]
atom_expr [22074,22091]
===
match
---
assert_stmt [46021,46069]
assert_stmt [47737,47785]
===
match
---
expr_stmt [51965,51993]
expr_stmt [53681,53709]
===
match
---
operator: = [37497,37498]
operator: = [39213,39214]
===
match
---
simple_stmt [2047,2106]
simple_stmt [2047,2106]
===
match
---
suite [14640,14756]
suite [14640,14756]
===
match
---
string: 'DAG' [12093,12098]
string: 'DAG' [12093,12098]
===
match
---
name: DagParam [69986,69994]
name: DagParam [71702,71710]
===
match
---
string: """Verify tasks with Duplicate task_id raises error""" [36803,36857]
string: """Verify tasks with Duplicate task_id raises error""" [38519,38573]
===
match
---
arglist [54007,54061]
arglist [55723,55777]
===
match
---
testlist_comp [19929,19957]
testlist_comp [19929,19957]
===
match
---
name: stdout [36524,36530]
name: stdout [38240,38246]
===
match
---
name: test_dag_id [18317,18328]
name: test_dag_id [18317,18328]
===
match
---
name: in_ [32325,32328]
name: in_ [34041,34044]
===
match
---
name: range [24600,24605]
name: range [26316,26321]
===
match
---
operator: = [50386,50387]
operator: = [52102,52103]
===
match
---
string: 't3' [56756,56760]
string: 't3' [58472,58476]
===
match
---
funcdef [10843,10981]
funcdef [10843,10981]
===
match
---
operator: , [56705,56706]
operator: , [58421,58422]
===
match
---
name: params1 [4202,4209]
name: params1 [4202,4209]
===
match
---
name: all [65228,65231]
name: all [66944,66947]
===
match
---
trailer [55960,55983]
trailer [57676,57699]
===
match
---
trailer [11878,11885]
trailer [11878,11885]
===
match
---
atom_expr [31861,31879]
atom_expr [33577,33595]
===
match
---
name: dates [55919,55924]
name: dates [57635,57640]
===
match
---
trailer [33519,33521]
trailer [35235,35237]
===
match
---
name: task [19310,19314]
name: task [19310,19314]
===
match
---
operator: , [26960,26961]
operator: , [28676,28677]
===
match
---
name: dag [40676,40679]
name: dag [42392,42395]
===
match
---
trailer [17439,17441]
trailer [17439,17441]
===
match
---
atom_expr [64764,64820]
atom_expr [66480,66536]
===
match
---
operator: = [35923,35924]
operator: = [37639,37640]
===
match
---
string: 'dag-bulk-sync-2' [26195,26212]
string: 'dag-bulk-sync-2' [27911,27928]
===
match
---
string: 'dag-bulk-sync-1' [26644,26661]
string: 'dag-bulk-sync-1' [28360,28377]
===
match
---
string: '2019-06-05' [10966,10978]
string: '2019-06-05' [10966,10978]
===
match
---
atom_expr [52413,52436]
atom_expr [54129,54152]
===
match
---
comparison [14561,14567]
comparison [14561,14567]
===
match
---
atom_expr [64049,64067]
atom_expr [65765,65783]
===
match
---
operator: = [48267,48268]
operator: = [49983,49984]
===
match
---
import_from [2047,2105]
import_from [2047,2105]
===
match
---
argument [10648,10680]
argument [10648,10680]
===
match
---
name: schedule_interval [7642,7659]
name: schedule_interval [7642,7659]
===
match
---
name: task_id [49662,49669]
name: task_id [51378,51385]
===
match
---
assert_stmt [26617,26790]
assert_stmt [28333,28506]
===
match
---
string: 'test_scheduler_verify_max_active_runs' [27439,27478]
string: 'test_scheduler_verify_max_active_runs' [29155,29194]
===
match
---
name: op2 [10251,10254]
name: op2 [10251,10254]
===
match
---
operator: = [9666,9667]
operator: = [9666,9667]
===
match
---
name: DAG [44432,44435]
name: DAG [46148,46151]
===
match
---
name: f [19637,19638]
name: f [19637,19638]
===
match
---
simple_stmt [21406,21452]
simple_stmt [21406,21452]
===
match
---
atom_expr [32120,32183]
atom_expr [33836,33899]
===
match
---
simple_stmt [33869,33930]
simple_stmt [35585,35646]
===
match
---
string: 'dag_without_catchup_ten_minute' [57162,57194]
string: 'dag_without_catchup_ten_minute' [58878,58910]
===
match
---
name: row [25841,25844]
name: row [27557,27560]
===
match
---
arglist [64301,64311]
arglist [66017,66027]
===
match
---
operator: , [13115,13116]
operator: , [13115,13116]
===
match
---
arglist [63516,63585]
arglist [65232,65301]
===
match
---
decorated [67006,67205]
decorated [68722,68921]
===
match
---
trailer [28234,28238]
trailer [29950,29954]
===
match
---
operator: = [49759,49760]
operator: = [51475,51476]
===
match
---
trailer [65568,65570]
trailer [67284,67286]
===
match
---
trailer [22856,22862]
trailer [22856,22862]
===
match
---
name: depth [15801,15806]
name: depth [15801,15806]
===
match
---
assert_stmt [35090,35131]
assert_stmt [36806,36847]
===
match
---
atom_expr [27622,27640]
atom_expr [29338,29356]
===
match
---
name: next_local [20733,20743]
name: next_local [20733,20743]
===
match
---
operator: { [24541,24542]
operator: { [26257,26258]
===
match
---
name: TEST_DATE [40386,40395]
name: TEST_DATE [42102,42111]
===
match
---
dotted_name [1863,1876]
dotted_name [1863,1876]
===
match
---
import_from [2236,2293]
import_from [2236,2293]
===
match
---
comparison [25301,25319]
comparison [27017,27035]
===
match
---
name: dag_subdag [62023,62033]
name: dag_subdag [63739,63749]
===
match
---
operator: = [6051,6052]
operator: = [6051,6052]
===
match
---
trailer [27150,27152]
trailer [28866,28868]
===
match
---
arglist [66443,66453]
arglist [68159,68169]
===
match
---
name: dag_id [16828,16834]
name: dag_id [16828,16834]
===
match
---
parameters [30596,30611]
parameters [32312,32327]
===
match
---
argument [56564,56589]
argument [58280,58305]
===
match
---
trailer [20482,20484]
trailer [20482,20484]
===
match
---
name: dag [46803,46806]
name: dag [48519,48522]
===
match
---
atom_expr [64513,64531]
atom_expr [66229,66247]
===
match
---
name: session [49048,49055]
name: session [50764,50771]
===
match
---
argument [32966,32994]
argument [34682,34710]
===
match
---
param [15222,15226]
param [15222,15226]
===
match
---
name: xcom_arg [70009,70017]
name: xcom_arg [71725,71733]
===
match
---
string: 'dag-test-dagtag' [24146,24163]
string: 'dag-test-dagtag' [25862,25879]
===
match
---
atom_expr [33303,33318]
atom_expr [35019,35034]
===
match
---
name: session [33303,33310]
name: session [35019,35026]
===
match
---
atom_expr [63658,63690]
atom_expr [65374,65406]
===
match
---
trailer [34342,34350]
trailer [36058,36066]
===
match
---
arglist [65791,65841]
arglist [67507,67557]
===
match
---
name: State [51321,51326]
name: State [53037,53042]
===
match
---
atom [13620,13636]
atom [13620,13636]
===
match
---
trailer [27755,27762]
trailer [29471,29478]
===
match
---
number: 2015 [2380,2384]
number: 2015 [2380,2384]
===
match
---
name: close [64548,64553]
name: close [66264,66269]
===
match
---
number: 1 [61139,61140]
number: 1 [62855,62856]
===
match
---
simple_stmt [36132,36177]
simple_stmt [37848,37893]
===
match
---
name: DagModel [24882,24890]
name: DagModel [26598,26606]
===
match
---
expr_stmt [48240,48254]
expr_stmt [49956,49970]
===
match
---
name: owner [42405,42410]
name: owner [44121,44126]
===
match
---
name: dag [6812,6815]
name: dag [6812,6815]
===
match
---
argument [56652,56659]
argument [58368,58375]
===
match
---
trailer [5550,5554]
trailer [5550,5554]
===
match
---
name: dag [23862,23865]
name: dag [23862,23865]
===
match
---
atom [46359,46690]
atom [48075,48406]
===
match
---
assert_stmt [17981,18111]
assert_stmt [17981,18111]
===
match
---
operator: = [16523,16524]
operator: = [16523,16524]
===
match
---
trailer [5053,5059]
trailer [5053,5059]
===
match
---
suite [3190,3502]
suite [3190,3502]
===
match
---
string: """         Test if the schedule_interval will be auto aligned with the start_date         such that if the start_date coincides with the schedule the first         execution_date will be start_date, otherwise it will be start_date +         interval.         """ [60385,60648]
string: """         Test if the schedule_interval will be auto aligned with the start_date         such that if the start_date coincides with the schedule the first         execution_date will be start_date, otherwise it will be start_date +         interval.         """ [62101,62364]
===
match
---
testlist_comp [27752,27763]
testlist_comp [29468,29479]
===
match
---
operator: , [7450,7451]
operator: , [7450,7451]
===
match
---
operator: = [70064,70065]
operator: = [71780,71781]
===
match
---
name: self [65753,65757]
name: self [67469,67473]
===
match
---
name: orm_dag [64867,64874]
name: orm_dag [66583,66590]
===
match
---
name: following_schedule [23017,23035]
name: following_schedule [23017,23035]
===
match
---
trailer [11593,11715]
trailer [11593,11715]
===
match
---
operator: = [16633,16634]
operator: = [16633,16634]
===
match
---
name: dag [45031,45034]
name: dag [46747,46750]
===
match
---
expr_stmt [20610,20680]
expr_stmt [20610,20680]
===
match
---
expr_stmt [66459,66469]
expr_stmt [68175,68185]
===
match
---
name: test_field [20120,20130]
name: test_field [20120,20130]
===
match
---
arglist [62390,62445]
arglist [64106,64161]
===
match
---
trailer [19270,19281]
trailer [19270,19281]
===
match
---
sync_comp_for [14395,14419]
sync_comp_for [14395,14419]
===
match
---
arglist [62097,62264]
arglist [63813,63980]
===
match
---
name: parent_dag [31144,31154]
name: parent_dag [32860,32870]
===
match
---
atom_expr [27752,27762]
atom_expr [29468,29478]
===
match
---
comparison [28269,28300]
comparison [29985,30016]
===
match
---
operator: = [15559,15560]
operator: = [15559,15560]
===
match
---
simple_stmt [5598,5665]
simple_stmt [5598,5665]
===
match
---
operator: , [18060,18061]
operator: , [18060,18061]
===
match
---
name: test_task_id [16780,16792]
name: test_task_id [16780,16792]
===
match
---
name: tasks [9153,9158]
name: tasks [9153,9158]
===
match
---
operator: == [36079,36081]
operator: == [37795,37797]
===
match
---
atom_expr [39236,39256]
atom_expr [40952,40972]
===
match
---
arglist [50819,51048]
arglist [52535,52764]
===
match
---
name: bulk_write_to_db [28170,28186]
name: bulk_write_to_db [29886,29902]
===
match
---
trailer [4287,4291]
trailer [4287,4291]
===
match
---
string: 'airflow' [43916,43925]
string: 'airflow' [45632,45641]
===
match
---
operator: , [4652,4653]
operator: , [4652,4653]
===
match
---
comparison [27840,27873]
comparison [29556,29589]
===
match
---
string: """Test that @dag decorated function fails if positional argument is not set""" [68318,68397]
string: """Test that @dag decorated function fails if positional argument is not set""" [70034,70113]
===
match
---
argument [28608,28622]
argument [30324,30338]
===
match
---
simple_stmt [48263,48325]
simple_stmt [49979,50041]
===
match
---
name: DagModel [27737,27745]
name: DagModel [29453,29461]
===
match
---
operator: = [49092,49093]
operator: = [50808,50809]
===
match
---
expr_stmt [47811,47940]
expr_stmt [49527,49656]
===
match
---
atom_expr [9825,9851]
atom_expr [9825,9851]
===
match
---
name: subdag [31137,31143]
name: subdag [32853,32859]
===
match
---
name: VALUE [71093,71098]
name: VALUE [72809,72814]
===
match
---
argument [52122,52145]
argument [53838,53861]
===
match
---
operator: , [49863,49864]
operator: , [51579,51580]
===
match
---
name: default_args [15408,15420]
name: default_args [15408,15420]
===
match
---
name: handle_callback [40680,40695]
name: handle_callback [42396,42411]
===
match
---
operator: = [20568,20569]
operator: = [20568,20569]
===
match
---
operator: , [57290,57291]
operator: , [59006,59007]
===
match
---
name: start_date [9469,9479]
name: start_date [9469,9479]
===
match
---
operator: = [49795,49796]
operator: = [51511,51512]
===
match
---
name: strip [68231,68236]
name: strip [69947,69952]
===
match
---
name: SubDagOperator [7880,7894]
name: SubDagOperator [7880,7894]
===
match
---
atom_expr [10467,10486]
atom_expr [10467,10486]
===
match
---
name: mock_callback_with_exception [40086,40114]
name: mock_callback_with_exception [41802,41830]
===
match
---
operator: = [66395,66396]
operator: = [68111,68112]
===
match
---
simple_stmt [35346,35380]
simple_stmt [37062,37096]
===
match
---
operator: = [41180,41181]
operator: = [42896,42897]
===
match
---
name: dagrun_2 [50253,50261]
name: dagrun_2 [51969,51977]
===
match
---
name: DagRunType [41389,41399]
name: DagRunType [43105,43115]
===
match
---
trailer [35984,35998]
trailer [37700,37714]
===
match
---
operator: = [32937,32938]
operator: = [34653,34654]
===
match
---
argument [47149,47175]
argument [48865,48891]
===
match
---
assert_stmt [38810,38863]
assert_stmt [40526,40579]
===
match
---
trailer [34309,34319]
trailer [36025,36035]
===
match
---
operator: == [35012,35014]
operator: == [36728,36730]
===
match
---
string: """         We should never create dagruns for unpaused DAGs         """ [64620,64692]
string: """         We should never create dagruns for unpaused DAGs         """ [66336,66408]
===
match
---
simple_stmt [61336,61394]
simple_stmt [63052,63110]
===
match
---
expr_stmt [21908,21943]
expr_stmt [21908,21943]
===
match
---
atom_expr [34615,34692]
atom_expr [36331,36408]
===
match
---
name: dag_decorator [68408,68421]
name: dag_decorator [70124,70137]
===
match
---
operator: } [66404,66405]
operator: } [68120,68121]
===
match
---
name: self [16709,16713]
name: self [16709,16713]
===
match
---
name: session [17413,17420]
name: session [17413,17420]
===
match
---
argument [57208,57240]
argument [58924,58956]
===
match
---
trailer [52497,52552]
trailer [54213,54268]
===
match
---
atom_expr [34469,34532]
atom_expr [36185,36248]
===
match
---
testlist_comp [15513,15748]
testlist_comp [15513,15748]
===
match
---
argument [43393,43432]
argument [45109,45148]
===
match
---
name: self [46739,46743]
name: self [48455,48459]
===
match
---
name: dag [22139,22142]
name: dag [22139,22142]
===
match
---
operator: , [27584,27585]
operator: , [29300,29301]
===
match
---
operator: , [62413,62414]
operator: , [64129,64130]
===
match
---
dotted_name [2241,2265]
dotted_name [2241,2265]
===
match
---
name: task [16102,16106]
name: task [16102,16106]
===
match
---
trailer [59925,59936]
trailer [61641,61652]
===
match
---
operator: = [62346,62347]
operator: = [64062,64063]
===
match
---
operator: == [21030,21032]
operator: == [21030,21032]
===
match
---
number: 1 [62768,62769]
number: 1 [64484,64485]
===
match
---
trailer [29998,30030]
trailer [31714,31746]
===
match
---
arith_expr [55382,55413]
arith_expr [57098,57129]
===
match
---
name: dag_id [53580,53586]
name: dag_id [55296,55302]
===
match
---
trailer [19744,19749]
trailer [19744,19749]
===
match
---
operator: = [7950,7951]
operator: = [7950,7951]
===
match
---
atom [56894,56929]
atom [58610,58645]
===
match
---
argument [47573,47605]
argument [49289,49321]
===
match
---
operator: { [34863,34864]
operator: { [36579,36580]
===
match
---
trailer [64094,64351]
trailer [65810,66067]
===
match
---
operator: = [53598,53599]
operator: = [55314,55315]
===
match
---
simple_stmt [64360,64381]
simple_stmt [66076,66097]
===
match
---
name: self [2718,2722]
name: self [2718,2722]
===
match
---
trailer [34895,34924]
trailer [36611,36640]
===
match
---
atom [31816,32002]
atom [33532,33718]
===
match
---
name: query [29480,29485]
name: query [31196,31201]
===
match
---
string: """Test that @dag uses function docs as doc_md for DAG object""" [67768,67832]
string: """Test that @dag uses function docs as doc_md for DAG object""" [69484,69548]
===
match
---
name: test_next_dagrun_after_date_catcup [56007,56041]
name: test_next_dagrun_after_date_catcup [57723,57757]
===
match
---
atom_expr [49359,49371]
atom_expr [51075,51087]
===
match
---
trailer [50805,51058]
trailer [52521,52774]
===
match
---
operator: = [52621,52622]
operator: = [54337,54338]
===
match
---
name: RUNNING [69438,69445]
name: RUNNING [71154,71161]
===
match
---
name: hours [41086,41091]
name: hours [42802,42807]
===
match
---
operator: , [40359,40360]
operator: , [42075,42076]
===
match
---
trailer [2722,2739]
trailer [2722,2739]
===
match
---
suite [29972,30267]
suite [31688,31983]
===
match
---
simple_stmt [879,918]
simple_stmt [879,918]
===
match
---
trailer [61129,61152]
trailer [62845,62868]
===
match
---
string: 'owner2' [6698,6706]
string: 'owner2' [6698,6706]
===
match
---
name: dag [6482,6485]
name: dag [6482,6485]
===
match
---
comparison [45296,45321]
comparison [47012,47037]
===
match
---
operator: = [56502,56503]
operator: = [58218,58219]
===
match
---
funcdef [36098,36718]
funcdef [37814,38434]
===
match
---
operator: = [50349,50350]
operator: = [52065,52066]
===
match
---
simple_stmt [51644,51690]
simple_stmt [53360,53406]
===
match
---
atom_expr [55957,55989]
atom_expr [57673,57705]
===
match
---
param [61442,61446]
param [63158,63162]
===
match
---
argument [15552,15575]
argument [15552,15575]
===
match
---
operator: = [45944,45945]
operator: = [47660,47661]
===
match
---
name: subdag [49923,49929]
name: subdag [51639,51645]
===
match
---
name: start [21641,21646]
name: start [21641,21646]
===
match
---
trailer [21538,21553]
trailer [21538,21553]
===
match
---
string: 'op2' [6179,6184]
string: 'op2' [6179,6184]
===
match
---
funcdef [45854,46323]
funcdef [47570,48039]
===
match
---
trailer [25192,25197]
trailer [26908,26913]
===
match
---
operator: , [13033,13034]
operator: , [13033,13034]
===
match
---
dotted_name [1311,1329]
dotted_name [1311,1329]
===
match
---
parameters [64604,64610]
parameters [66320,66326]
===
match
---
trailer [28243,28250]
trailer [29959,29966]
===
match
---
name: default_view [30449,30461]
name: default_view [32165,32177]
===
match
---
argument [7642,7668]
argument [7642,7668]
===
match
---
testlist_comp [8933,8941]
testlist_comp [8933,8941]
===
match
---
comparison [6279,6294]
comparison [6279,6294]
===
match
---
simple_stmt [62471,62497]
simple_stmt [64187,64213]
===
match
---
param [67753,67757]
param [69469,69473]
===
match
---
suite [7809,8017]
suite [7809,8017]
===
match
---
operator: = [63522,63523]
operator: = [65238,65239]
===
match
---
name: width [15742,15747]
name: width [15742,15747]
===
match
---
funcdef [2438,2629]
funcdef [2438,2629]
===
match
---
simple_stmt [48425,48621]
simple_stmt [50141,50337]
===
match
---
name: values [13400,13406]
name: values [13400,13406]
===
match
---
argument [5555,5588]
argument [5555,5588]
===
match
---
atom_expr [29180,29211]
atom_expr [30896,30927]
===
match
---
string: '2' [44664,44667]
string: '2' [46380,46383]
===
match
---
suite [66212,71099]
suite [67928,72815]
===
match
---
expr_stmt [58026,58215]
expr_stmt [59742,59931]
===
match
---
name: task_id [3363,3370]
name: task_id [3363,3370]
===
match
---
operator: = [44559,44560]
operator: = [46275,46276]
===
match
---
name: object [34116,34122]
name: object [35832,35838]
===
match
---
name: priority_weight_total [15081,15102]
name: priority_weight_total [15081,15102]
===
match
---
name: self [47351,47355]
name: self [49067,49071]
===
match
---
trailer [9304,9307]
trailer [9304,9307]
===
match
---
trailer [46261,46288]
trailer [47977,48004]
===
match
---
name: self [66686,66690]
name: self [68402,68406]
===
match
---
argument [56920,56927]
argument [58636,58643]
===
match
---
comparison [20467,20515]
comparison [20467,20515]
===
match
---
name: add_task [40408,40416]
name: add_task [42124,42132]
===
match
---
operator: , [19393,19394]
operator: , [19393,19394]
===
match
---
argument [23822,23842]
argument [23822,23842]
===
match
---
simple_stmt [48162,48201]
simple_stmt [49878,49917]
===
match
---
operator: , [61246,61247]
operator: , [62962,62963]
===
match
---
name: test_dag [16933,16941]
name: test_dag [16933,16941]
===
match
---
trailer [20984,20990]
trailer [20984,20990]
===
match
---
assert_stmt [17768,17864]
assert_stmt [17768,17864]
===
match
---
trailer [31679,31694]
trailer [33395,33410]
===
match
---
simple_stmt [19066,19107]
simple_stmt [19066,19107]
===
match
---
name: test_dag_param_dagrun_parameterized [69635,69670]
name: test_dag_param_dagrun_parameterized [71351,71386]
===
match
---
decorator [65633,65719]
decorator [67349,67435]
===
match
---
operator: = [10924,10925]
operator: = [10924,10925]
===
match
---
name: schedule_interval [46976,46993]
name: schedule_interval [48692,48709]
===
match
---
operator: = [56677,56678]
operator: = [58393,58394]
===
match
---
trailer [63336,63352]
trailer [65052,65068]
===
match
---
name: session [33505,33512]
name: session [35221,35228]
===
match
---
trailer [57097,57107]
trailer [58813,58823]
===
match
---
name: DEFAULT_DATE [50221,50233]
name: DEFAULT_DATE [51937,51949]
===
match
---
number: 0 [13171,13172]
number: 0 [13171,13172]
===
match
---
simple_stmt [47730,47742]
simple_stmt [49446,49458]
===
match
---
operator: = [61293,61294]
operator: = [63009,63010]
===
match
---
trailer [34283,34285]
trailer [35999,36001]
===
match
---
name: tasks [6928,6933]
name: tasks [6928,6933]
===
match
---
operator: } [32089,32090]
operator: } [33805,33806]
===
match
---
operator: , [65682,65683]
operator: , [67398,67399]
===
match
---
name: dag [7216,7219]
name: dag [7216,7219]
===
match
---
name: _next [20786,20791]
name: _next [20786,20791]
===
match
---
name: dag [5538,5541]
name: dag [5538,5541]
===
match
---
trailer [41928,41942]
trailer [43644,43658]
===
match
---
name: dag_id [51711,51717]
name: dag_id [53427,53433]
===
match
---
name: test_existing_dag_is_paused_upon_creation [32510,32551]
name: test_existing_dag_is_paused_upon_creation [34226,34267]
===
match
---
trailer [36539,36541]
trailer [38255,38257]
===
match
---
name: TI [54004,54006]
name: TI [55720,55722]
===
match
---
simple_stmt [24112,24128]
simple_stmt [25828,25844]
===
match
---
argument [31355,31370]
argument [33071,33086]
===
match
---
operator: = [55479,55480]
operator: = [57195,57196]
===
match
---
parameters [68826,68832]
parameters [70542,70548]
===
match
---
string: "@weekly" [46437,46446]
string: "@weekly" [48153,48162]
===
match
---
arglist [28682,28737]
arglist [30398,30453]
===
match
---
name: airflow [1898,1905]
name: airflow [1898,1905]
===
match
---
name: self [8345,8349]
name: self [8345,8349]
===
match
---
atom_expr [10333,10365]
atom_expr [10333,10365]
===
match
---
name: self [40819,40823]
name: self [42535,42539]
===
match
---
atom_expr [50770,50786]
atom_expr [52486,52502]
===
match
---
name: query [24366,24371]
name: query [26082,26087]
===
match
---
trailer [2683,2685]
trailer [2683,2685]
===
match
---
operator: != [45069,45071]
operator: != [46785,46787]
===
match
---
name: next_dagrun_after_date [58242,58264]
name: next_dagrun_after_date [59958,59980]
===
match
---
simple_stmt [67244,67272]
simple_stmt [68960,68988]
===
match
---
operator: , [17818,17819]
operator: , [17818,17819]
===
match
---
name: start_date [52122,52132]
name: start_date [53838,53848]
===
match
---
operator: { [9507,9508]
operator: { [9507,9508]
===
match
---
trailer [47558,47572]
trailer [49274,49288]
===
match
---
atom_expr [65555,65570]
atom_expr [67271,67286]
===
match
---
string: 'faketastic' [55609,55621]
string: 'faketastic' [57325,57337]
===
match
---
name: raises [5228,5234]
name: raises [5228,5234]
===
match
---
name: DummyOperator [15513,15526]
name: DummyOperator [15513,15526]
===
match
---
operator: = [51039,51040]
operator: = [52755,52756]
===
match
---
atom_expr [65189,65233]
atom_expr [66905,66949]
===
match
---
name: set2 [10320,10324]
name: set2 [10320,10324]
===
match
---
name: schedule_interval [46839,46856]
name: schedule_interval [48555,48572]
===
match
---
trailer [23302,23308]
trailer [23302,23308]
===
match
---
trailer [42761,42763]
trailer [44477,44479]
===
match
---
string: 'dag' [30856,30861]
string: 'dag' [32572,32577]
===
match
---
name: query [27041,27046]
name: query [28757,28762]
===
match
---
simple_stmt [2149,2198]
simple_stmt [2149,2198]
===
match
---
name: DagRunType [47520,47530]
name: DagRunType [49236,49246]
===
match
---
simple_stmt [48388,48417]
simple_stmt [50104,50133]
===
match
---
name: dag_id [48273,48279]
name: dag_id [49989,49995]
===
match
---
trailer [31225,31232]
trailer [32941,32948]
===
match
---
assert_stmt [29173,29235]
assert_stmt [30889,30951]
===
match
---
simple_stmt [31802,32003]
simple_stmt [33518,33719]
===
match
---
name: topological_sort [8056,8072]
name: topological_sort [8056,8072]
===
match
---
trailer [10076,10078]
trailer [10076,10078]
===
match
---
atom_expr [8420,8479]
atom_expr [8420,8479]
===
match
---
name: tests [2299,2304]
name: tests [2299,2304]
===
match
---
string: 'dag-bulk-sync-0' [25997,26014]
string: 'dag-bulk-sync-0' [27713,27730]
===
match
---
assert_stmt [10153,10187]
assert_stmt [10153,10187]
===
match
---
simple_stmt [43217,43307]
simple_stmt [44933,45023]
===
match
---
atom_expr [60016,60053]
atom_expr [61732,61769]
===
match
---
atom_expr [59007,59036]
atom_expr [60723,60752]
===
match
---
name: session [29014,29021]
name: session [30730,30737]
===
match
---
operator: , [53611,53612]
operator: , [55327,55328]
===
match
---
name: timezone [63934,63942]
name: timezone [65650,65658]
===
match
---
atom_expr [55820,55838]
atom_expr [57536,57554]
===
match
---
comparison [12157,12190]
comparison [12157,12190]
===
match
---
atom_expr [19266,19281]
atom_expr [19266,19281]
===
match
---
suite [44133,45849]
suite [45849,47565]
===
match
---
expr_stmt [37607,37649]
expr_stmt [39323,39365]
===
match
---
name: start_date [69338,69348]
name: start_date [71054,71064]
===
match
---
operator: , [44516,44517]
operator: , [46232,46233]
===
match
---
operator: = [48169,48170]
operator: = [49885,49886]
===
match
---
trailer [25164,25170]
trailer [26880,26886]
===
match
---
simple_stmt [17981,18112]
simple_stmt [17981,18112]
===
match
---
simple_stmt [8413,8480]
simple_stmt [8413,8480]
===
match
---
argument [56971,56984]
argument [58687,58700]
===
match
---
operator: = [48596,48597]
operator: = [50312,50313]
===
match
---
name: dagruns [49084,49091]
name: dagruns [50800,50807]
===
match
---
trailer [22813,22818]
trailer [22813,22818]
===
match
---
comparison [53309,53331]
comparison [55025,55047]
===
match
---
operator: = [8762,8763]
operator: = [8762,8763]
===
match
---
name: DEFAULT_DATE [52133,52145]
name: DEFAULT_DATE [53849,53861]
===
match
---
expr_stmt [17288,17370]
expr_stmt [17288,17370]
===
match
---
atom_expr [67251,67271]
atom_expr [68967,68987]
===
match
---
trailer [21919,21938]
trailer [21919,21938]
===
match
---
simple_stmt [11584,11716]
simple_stmt [11584,11716]
===
match
---
name: make_dag [56197,56205]
name: make_dag [57913,57921]
===
match
---
name: State [18215,18220]
name: State [18215,18220]
===
match
---
string: """         Test that the dag file processor creates multiple dagruns         if a dag is scheduled with 'timedelta' and catchup=True         """ [59388,59533]
string: """         Test that the dag file processor creates multiple dagruns         if a dag is scheduled with 'timedelta' and catchup=True         """ [61104,61249]
===
match
---
operator: = [39058,39059]
operator: = [40774,40775]
===
match
---
argument [54196,54219]
argument [55912,55935]
===
match
---
expr_stmt [44306,44347]
expr_stmt [46022,46063]
===
match
---
operator: = [19282,19283]
operator: = [19282,19283]
===
match
---
number: 5 [61013,61014]
number: 5 [62729,62730]
===
match
---
simple_stmt [38110,38171]
simple_stmt [39826,39887]
===
match
---
string: 'airflow' [64019,64028]
string: 'airflow' [65735,65744]
===
match
---
trailer [43220,43229]
trailer [44936,44945]
===
match
---
name: weight [15617,15623]
name: weight [15617,15623]
===
match
---
argument [17048,17062]
argument [17048,17062]
===
match
---
trailer [25202,25204]
trailer [26918,26920]
===
match
---
atom_expr [28869,28886]
atom_expr [30585,30602]
===
match
---
name: DEFAULT_DATE [19152,19164]
name: DEFAULT_DATE [19152,19164]
===
match
---
name: two_hours_ago [57910,57923]
name: two_hours_ago [59626,59639]
===
match
---
atom_expr [39314,39327]
atom_expr [41030,41043]
===
match
---
trailer [25889,25893]
trailer [27605,27609]
===
match
---
atom [49094,49265]
atom [50810,50981]
===
match
---
with_item [37882,37929]
with_item [39598,39645]
===
match
---
string: """         Test invalid `orientation` of DAG initialization         """ [5135,5207]
string: """         Test invalid `orientation` of DAG initialization         """ [5135,5207]
===
match
---
simple_stmt [16319,16362]
simple_stmt [16319,16362]
===
match
---
atom [38134,38170]
atom [39850,39886]
===
match
---
name: mock [34105,34109]
name: mock [35821,35825]
===
match
---
operator: = [50933,50934]
operator: = [52649,52650]
===
match
---
operator: = [31761,31762]
operator: = [33477,33478]
===
match
---
simple_stmt [54173,54324]
simple_stmt [55889,56040]
===
match
---
name: op2 [36396,36399]
name: op2 [38112,38115]
===
match
---
simple_stmt [21688,21722]
simple_stmt [21688,21722]
===
match
---
name: session [17658,17665]
name: session [17658,17665]
===
match
---
name: all [54498,54501]
name: all [56214,56217]
===
match
---
argument [35939,35951]
argument [37655,37667]
===
match
---
name: ACTION_CAN_EDIT [63337,63352]
name: ACTION_CAN_EDIT [65053,65068]
===
match
---
name: handle_callback [40628,40643]
name: handle_callback [42344,42359]
===
match
---
name: start_date [37898,37908]
name: start_date [39614,39624]
===
match
---
name: xcom_pass_to_op [68970,68985]
name: xcom_pass_to_op [70686,70701]
===
match
---
name: dag [41646,41649]
name: dag [43362,43365]
===
match
---
comparison [6722,6743]
comparison [6722,6743]
===
match
---
name: test_utils [2247,2257]
name: test_utils [2247,2257]
===
match
---
name: op1 [6212,6215]
name: op1 [6212,6215]
===
match
---
trailer [51246,51252]
trailer [52962,52968]
===
match
---
argument [7427,7450]
argument [7427,7450]
===
match
---
operator: , [60716,60717]
operator: , [62432,62433]
===
match
---
testlist_comp [26195,26225]
testlist_comp [27911,27941]
===
match
---
operator: = [64007,64008]
operator: = [65723,65724]
===
match
---
suite [67759,68268]
suite [69475,69984]
===
match
---
name: task_id [39113,39120]
name: task_id [40829,40836]
===
match
---
number: 1 [63961,63962]
number: 1 [65677,65678]
===
match
---
operator: = [52994,52995]
operator: = [54710,54711]
===
match
---
simple_stmt [12525,12535]
simple_stmt [12525,12535]
===
match
---
argument [69338,69366]
argument [71054,71082]
===
match
---
simple_stmt [49955,50003]
simple_stmt [51671,51719]
===
match
---
string: 'test_dags' [64718,64729]
string: 'test_dags' [66434,66445]
===
match
---
argument [64139,64157]
argument [65855,65873]
===
match
---
operator: , [28552,28553]
operator: , [30268,30269]
===
match
---
simple_stmt [44784,44819]
simple_stmt [46500,46535]
===
match
---
suite [35638,36093]
suite [37354,37809]
===
match
---
atom_expr [27948,28127]
atom_expr [29664,29843]
===
match
---
name: default_args [5953,5965]
name: default_args [5953,5965]
===
match
---
name: dag2 [6190,6194]
name: dag2 [6190,6194]
===
match
---
name: local_tz [20299,20307]
name: local_tz [20299,20307]
===
match
---
atom_expr [57533,57550]
atom_expr [59249,59266]
===
match
---
trailer [70972,70981]
trailer [72688,72697]
===
match
---
expr_stmt [45256,45280]
expr_stmt [46972,46996]
===
match
---
atom_expr [18132,18256]
atom_expr [18132,18256]
===
match
---
name: test_dag_task_priority_weight_total [12456,12491]
name: test_dag_task_priority_weight_total [12456,12491]
===
match
---
name: default_args [61882,61894]
name: default_args [63598,63610]
===
match
---
name: weight [14288,14294]
name: weight [14288,14294]
===
match
---
name: DAG [61755,61758]
name: DAG [63471,63474]
===
match
---
name: dr [70183,70185]
name: dr [71899,71901]
===
match
---
argument [16848,16871]
argument [16848,16871]
===
match
---
argument [11614,11705]
argument [11614,11705]
===
match
---
simple_stmt [54563,54609]
simple_stmt [56279,56325]
===
match
---
trailer [31418,31424]
trailer [33134,33140]
===
match
---
simple_stmt [41164,41239]
simple_stmt [42880,42955]
===
match
---
string: '@daily' [7405,7413]
string: '@daily' [7405,7413]
===
match
---
name: create_dagrun [41353,41366]
name: create_dagrun [43069,43082]
===
match
---
name: topological_list [10467,10483]
name: topological_list [10467,10483]
===
match
---
name: task [1337,1341]
name: task [1337,1341]
===
match
---
trailer [15797,15807]
trailer [15797,15807]
===
match
---
operator: = [59710,59711]
operator: = [61426,61427]
===
match
---
operator: , [34009,34010]
operator: , [35725,35726]
===
match
---
name: session [52987,52994]
name: session [54703,54710]
===
match
---
atom_expr [20378,20416]
atom_expr [20378,20416]
===
match
---
trailer [69576,69578]
trailer [71292,71294]
===
match
---
name: width [12507,12512]
name: width [12507,12512]
===
match
---
name: start_date [10623,10633]
name: start_date [10623,10633]
===
match
---
name: baseoperator [1537,1549]
name: baseoperator [1537,1549]
===
match
---
operator: = [49816,49817]
operator: = [51532,51533]
===
match
---
funcdef [41980,42966]
funcdef [43696,44682]
===
match
---
trailer [54757,54878]
trailer [56473,56594]
===
match
---
name: DEFAULT_DATE [48703,48715]
name: DEFAULT_DATE [50419,50431]
===
match
---
name: session [54305,54312]
name: session [56021,56028]
===
match
---
operator: , [64916,64917]
operator: , [66632,66633]
===
match
---
exprlist [15838,15846]
exprlist [15838,15846]
===
match
---
name: default_args [56564,56576]
name: default_args [58280,58292]
===
match
---
expr_stmt [32664,32717]
expr_stmt [34380,34433]
===
match
---
with_stmt [34100,34203]
with_stmt [35816,35919]
===
match
---
atom_expr [55919,55928]
atom_expr [57635,57644]
===
match
---
simple_stmt [53953,53977]
simple_stmt [55669,55693]
===
match
---
operator: = [24518,24519]
operator: = [26234,26235]
===
match
---
atom_expr [57133,57328]
atom_expr [58849,59044]
===
match
---
name: j [15728,15729]
name: j [15728,15729]
===
match
---
trailer [34664,34691]
trailer [36380,36407]
===
match
---
trailer [50898,50906]
trailer [52614,52622]
===
match
---
with_stmt [24699,25320]
with_stmt [26415,27036]
===
match
---
atom_expr [43230,43305]
atom_expr [44946,45021]
===
match
---
operator: = [36912,36913]
operator: = [38628,38629]
===
match
---
name: noop_pipeline [66717,66730]
name: noop_pipeline [68433,68446]
===
match
---
name: create_dagrun [52224,52237]
name: create_dagrun [53940,53953]
===
match
---
param [46764,46792]
param [48480,48508]
===
match
---
atom [25947,25978]
atom [27663,27694]
===
match
---
trailer [23335,23345]
trailer [23335,23345]
===
match
---
funcdef [5670,7251]
funcdef [5670,7251]
===
match
---
name: RUNNING [53351,53358]
name: RUNNING [55067,55074]
===
match
---
arglist [16828,16871]
arglist [16828,16871]
===
match
---
trailer [31843,31880]
trailer [33559,33596]
===
match
---
name: make_dag [58033,58041]
name: make_dag [59749,59757]
===
match
---
name: ti1 [16952,16955]
name: ti1 [16952,16955]
===
match
---
name: pickle [44030,44036]
name: pickle [45746,45752]
===
match
---
name: is_subdag [62645,62654]
name: is_subdag [64361,64370]
===
match
---
name: SCHEDULED [39247,39256]
name: SCHEDULED [40963,40972]
===
match
---
simple_stmt [57891,57924]
simple_stmt [59607,59640]
===
match
---
trailer [39751,39757]
trailer [41467,41473]
===
match
---
simple_stmt [28869,28893]
simple_stmt [30585,30609]
===
match
---
simple_stmt [39897,39979]
simple_stmt [41613,41695]
===
match
---
name: create_session [2811,2825]
name: create_session [2811,2825]
===
match
---
name: dag [30870,30873]
name: dag [32586,32589]
===
match
---
name: DummyOperator [35971,35984]
name: DummyOperator [37687,37700]
===
match
---
trailer [39488,39495]
trailer [41204,41211]
===
match
---
name: session [51965,51972]
name: session [53681,53688]
===
match
---
name: FAILED [52102,52108]
name: FAILED [53818,53824]
===
match
---
trailer [22015,22025]
trailer [22015,22025]
===
match
---
operator: = [64198,64199]
operator: = [65914,65915]
===
match
---
number: 10 [61142,61144]
number: 10 [62858,62860]
===
match
---
name: DAG [5917,5920]
name: DAG [5917,5920]
===
match
---
name: pytest [63460,63466]
name: pytest [65176,65182]
===
match
---
name: session [50012,50019]
name: session [51728,51735]
===
match
---
trailer [36496,36498]
trailer [38212,38214]
===
match
---
operator: , [51810,51811]
operator: , [53526,53527]
===
match
---
arglist [56951,56984]
arglist [58667,58700]
===
match
---
name: enumerate [15850,15859]
name: enumerate [15850,15859]
===
match
---
name: DEFAULT_DATE [29897,29909]
name: DEFAULT_DATE [31613,31625]
===
match
---
string: "@quarterly" [46514,46526]
string: "@quarterly" [48230,48242]
===
match
---
operator: , [58913,58914]
operator: , [60629,60630]
===
match
---
name: ti [69597,69599]
name: ti [71313,71315]
===
match
---
trailer [70030,70037]
trailer [71746,71753]
===
match
---
trailer [53268,53273]
trailer [54984,54989]
===
match
---
name: models [2209,2215]
name: models [2209,2215]
===
match
---
simple_stmt [70514,70546]
simple_stmt [72230,72262]
===
match
---
dotted_name [2299,2318]
dotted_name [2299,2318]
===
match
---
atom [66232,66405]
atom [67948,68121]
===
match
---
funcdef [47678,47985]
funcdef [49394,49701]
===
match
---
arglist [33442,33490]
arglist [35158,35206]
===
match
---
operator: = [52052,52053]
operator: = [53768,53769]
===
match
---
operator: + [17217,17218]
operator: + [17217,17218]
===
match
---
name: next_date [62731,62740]
name: next_date [64447,64456]
===
match
---
trailer [27638,27640]
trailer [29354,29356]
===
match
---
name: task_id [53668,53675]
name: task_id [55384,55391]
===
match
---
simple_stmt [63250,63446]
simple_stmt [64966,65162]
===
match
---
atom_expr [35097,35114]
atom_expr [36813,36830]
===
match
---
operator: @ [69766,69767]
operator: @ [71482,71483]
===
match
---
operator: = [17078,17079]
operator: = [17078,17079]
===
match
---
number: 2015 [58826,58830]
number: 2015 [60542,60546]
===
match
---
simple_stmt [66746,66750]
simple_stmt [68462,68466]
===
match
---
name: DEFAULT_DATE [69500,69512]
name: DEFAULT_DATE [71216,71228]
===
match
---
name: settings [34123,34131]
name: settings [35839,35847]
===
match
---
string: "2018-03-25T03:00:00+02:00" [23128,23155]
string: "2018-03-25T03:00:00+02:00" [23128,23155]
===
match
---
atom_expr [51181,51194]
atom_expr [52897,52910]
===
match
---
name: DagModel [34483,34491]
name: DagModel [36199,36207]
===
match
---
name: priority_weight [15601,15616]
name: priority_weight [15601,15616]
===
match
---
operator: , [23801,23802]
operator: , [23801,23802]
===
match
---
with_stmt [36185,36718]
with_stmt [37901,38434]
===
match
---
operator: { [61987,61988]
operator: { [63703,63704]
===
match
---
name: DAG [37882,37885]
name: DAG [39598,39601]
===
match
---
operator: , [1496,1497]
operator: , [1496,1497]
===
match
---
name: return_num [68589,68599]
name: return_num [70305,70315]
===
match
---
operator: = [53703,53704]
operator: = [55419,55420]
===
match
---
simple_stmt [25490,25517]
simple_stmt [27206,27233]
===
match
---
atom_expr [67446,67463]
atom_expr [69162,69179]
===
match
---
expr_stmt [33534,33623]
expr_stmt [35250,35339]
===
match
---
name: self [4520,4524]
name: self [4520,4524]
===
match
---
expr_stmt [32567,32590]
expr_stmt [34283,34306]
===
match
---
name: subdag [51812,51818]
name: subdag [53528,53534]
===
match
---
operator: , [31539,31540]
operator: , [33255,33256]
===
match
---
simple_stmt [9239,9273]
simple_stmt [9239,9273]
===
match
---
operator: = [41168,41169]
operator: = [42884,42885]
===
match
---
comparison [71065,71098]
comparison [72781,72814]
===
match
---
trailer [16073,16084]
trailer [16073,16084]
===
match
---
trailer [55924,55928]
trailer [57640,57644]
===
match
---
arglist [54830,54840]
arglist [56546,56556]
===
match
---
simple_stmt [19447,19484]
simple_stmt [19447,19484]
===
match
---
expr_stmt [43356,43586]
expr_stmt [45072,45302]
===
match
---
name: dag_id [53482,53488]
name: dag_id [55198,55204]
===
match
---
name: set [32094,32097]
name: set [33810,33813]
===
match
---
name: DagModel [26754,26762]
name: DagModel [28470,28478]
===
match
---
operator: , [16846,16847]
operator: , [16846,16847]
===
match
---
simple_stmt [66939,66997]
simple_stmt [68655,68713]
===
match
---
operator: = [52577,52578]
operator: = [54293,54294]
===
match
---
atom_expr [41952,41974]
atom_expr [43668,43690]
===
match
---
operator: = [33942,33943]
operator: = [35658,35659]
===
match
---
param [59373,59377]
param [61089,61093]
===
match
---
assert_stmt [3796,3823]
assert_stmt [3796,3823]
===
match
---
atom [56282,56375]
atom [57998,58091]
===
match
---
name: State [51348,51353]
name: State [53064,53069]
===
match
---
trailer [54979,54991]
trailer [56695,56707]
===
match
---
operator: , [17725,17726]
operator: , [17725,17726]
===
match
---
simple_stmt [3393,3405]
simple_stmt [3393,3405]
===
match
---
name: get_task_instances [70522,70540]
name: get_task_instances [72238,72256]
===
match
---
name: AirflowException [4636,4652]
name: AirflowException [4636,4652]
===
match
---
import_from [1517,1569]
import_from [1517,1569]
===
match
---
operator: , [59244,59245]
operator: , [60960,60961]
===
match
---
name: template_file [19066,19079]
name: template_file [19066,19079]
===
match
---
name: dst_rule [21521,21529]
name: dst_rule [21521,21529]
===
match
---
dictorsetmaker [36083,36091]
dictorsetmaker [37799,37807]
===
match
---
name: days [46671,46675]
name: days [48387,48391]
===
match
---
name: task_id [6124,6131]
name: task_id [6124,6131]
===
match
---
comparison [42855,42880]
comparison [44571,44596]
===
match
---
trailer [52270,52283]
trailer [53986,53999]
===
match
---
name: os [19674,19676]
name: os [19674,19676]
===
match
---
simple_stmt [36555,36589]
simple_stmt [38271,38305]
===
match
---
name: six_hours_ago_to_the_hour [58152,58177]
name: six_hours_ago_to_the_hour [59868,59893]
===
match
---
name: dagrun_1 [52427,52435]
name: dagrun_1 [54143,54151]
===
match
---
with_item [36981,37028]
with_item [38697,38744]
===
match
---
operator: = [38385,38386]
operator: = [40101,40102]
===
match
---
atom [43906,43954]
atom [45622,45670]
===
match
---
name: make_dag [57133,57141]
name: make_dag [58849,58857]
===
match
---
operator: , [51590,51591]
operator: , [53306,53307]
===
match
---
trailer [12128,12140]
trailer [12128,12140]
===
match
---
expr_stmt [44411,44467]
expr_stmt [46127,46183]
===
match
---
simple_stmt [10375,10410]
simple_stmt [10375,10410]
===
match
---
param [68480,68485]
param [70196,70201]
===
match
---
atom_expr [10196,10228]
atom_expr [10196,10228]
===
match
---
atom_expr [8876,8902]
atom_expr [8876,8902]
===
match
---
name: self [2647,2651]
name: self [2647,2651]
===
match
---
expr_stmt [57337,57382]
expr_stmt [59053,59098]
===
match
---
atom_expr [25186,25197]
atom_expr [26902,26913]
===
match
---
name: task_dict [38190,38199]
name: task_dict [39906,39915]
===
match
---
trailer [53053,53059]
trailer [54769,54775]
===
match
---
parameters [2783,2796]
parameters [2783,2796]
===
match
---
string: 'dag' [12838,12843]
string: 'dag' [12838,12843]
===
match
---
name: test_task [16966,16975]
name: test_task [16966,16975]
===
match
---
number: 2018 [21503,21507]
number: 2018 [21503,21507]
===
match
---
expr_stmt [70050,70083]
expr_stmt [71766,71799]
===
match
---
testlist_comp [65697,65700]
testlist_comp [67413,67416]
===
match
---
simple_stmt [63506,63587]
simple_stmt [65222,65303]
===
match
---
trailer [16280,16302]
trailer [16280,16302]
===
match
---
testlist_comp [24957,24986]
testlist_comp [26673,26702]
===
match
---
simple_stmt [44047,44093]
simple_stmt [45763,45809]
===
match
---
trailer [35006,35011]
trailer [36722,36727]
===
match
---
operator: = [17140,17141]
operator: = [17140,17141]
===
match
---
operator: , [38618,38619]
operator: , [40334,40335]
===
match
---
name: dr [47811,47813]
name: dr [49527,49529]
===
match
---
name: dag2 [6426,6430]
name: dag2 [6426,6430]
===
match
---
dictorsetmaker [24753,24827]
dictorsetmaker [26469,26543]
===
match
---
name: NONE [47902,47906]
name: NONE [49618,49622]
===
match
---
argument [16929,16941]
argument [16929,16941]
===
match
---
comparison [22297,22344]
comparison [22297,22344]
===
match
---
simple_stmt [1622,1667]
simple_stmt [1622,1667]
===
match
---
operator: = [53628,53629]
operator: = [55344,55345]
===
match
---
expr_stmt [60910,60954]
expr_stmt [62626,62670]
===
match
---
name: pytest [16563,16569]
name: pytest [16563,16569]
===
match
---
name: session [24358,24365]
name: session [26074,26081]
===
match
---
operator: = [38500,38501]
operator: = [40216,40217]
===
match
---
trailer [7894,7933]
trailer [7894,7933]
===
match
---
trailer [38207,38215]
trailer [39923,39931]
===
match
---
operator: , [13075,13076]
operator: , [13075,13076]
===
match
---
simple_stmt [10901,10981]
simple_stmt [10901,10981]
===
match
---
name: DEFAULT_DATE [27811,27823]
name: DEFAULT_DATE [29527,29539]
===
match
---
funcdef [5397,5665]
funcdef [5397,5665]
===
match
---
string: 'b_child' [8439,8448]
string: 'b_child' [8439,8448]
===
match
---
operator: == [41841,41843]
operator: == [43557,43559]
===
match
---
atom_expr [31844,31859]
atom_expr [33560,33575]
===
match
---
name: num [70890,70893]
name: num [72606,72609]
===
match
---
name: dag_fileloc [34354,34365]
name: dag_fileloc [36070,36081]
===
match
---
argument [66041,66073]
argument [67757,67789]
===
match
---
atom_expr [64877,65117]
atom_expr [66593,66833]
===
match
---
name: timezone [59222,59230]
name: timezone [60938,60946]
===
match
---
comparison [45483,45511]
comparison [47199,47227]
===
match
---
name: all [49250,49253]
name: all [50966,50969]
===
match
---
name: session [2831,2838]
name: session [2831,2838]
===
match
---
name: schedule_interval [21648,21665]
name: schedule_interval [21648,21665]
===
match
---
operator: >> [35548,35550]
operator: >> [37264,37266]
===
match
---
name: dag_id [24394,24400]
name: dag_id [26110,26116]
===
match
---
operator: = [49941,49942]
operator: = [51657,51658]
===
match
---
name: args [44462,44466]
name: args [46178,46182]
===
match
---
trailer [52308,52315]
trailer [54024,54031]
===
match
---
argument [47450,47470]
argument [49166,49186]
===
match
---
atom [12935,13097]
atom [12935,13097]
===
match
---
import_name [863,878]
import_name [863,878]
===
match
---
name: delete [31275,31281]
name: delete [32991,32997]
===
match
---
comparison [39433,39459]
comparison [41149,41175]
===
match
---
trailer [34813,34822]
trailer [36529,36538]
===
match
---
trailer [34639,34649]
trailer [36355,36365]
===
match
---
expr_stmt [18660,18694]
expr_stmt [18660,18694]
===
match
---
name: correct_weight [13768,13782]
name: correct_weight [13768,13782]
===
match
---
operator: = [37976,37977]
operator: = [39692,39693]
===
match
---
number: 5 [13977,13978]
number: 5 [13977,13978]
===
match
---
name: run_id [69294,69300]
name: run_id [71010,71016]
===
match
---
name: DagModel [25873,25881]
name: DagModel [27589,27597]
===
match
---
operator: , [44584,44585]
operator: , [46300,46301]
===
match
---
with_item [14043,14119]
with_item [14043,14119]
===
match
---
name: dag [6666,6669]
name: dag [6666,6669]
===
match
---
name: get_dagmodel [31713,31725]
name: get_dagmodel [33429,33441]
===
match
---
shift_expr [37662,37672]
shift_expr [39378,39388]
===
match
---
simple_stmt [23095,23156]
simple_stmt [23095,23156]
===
match
---
operator: , [35053,35054]
operator: , [36769,36770]
===
match
---
operator: == [2895,2897]
operator: == [2895,2897]
===
match
---
name: task_id [56748,56755]
name: task_id [58464,58471]
===
match
---
name: session [29775,29782]
name: session [31491,31498]
===
match
---
param [35632,35636]
param [37348,37352]
===
match
---
atom_expr [13283,13298]
atom_expr [13283,13298]
===
match
---
arith_expr [57083,57116]
arith_expr [58799,58832]
===
match
---
number: 1 [9269,9270]
number: 1 [9269,9270]
===
match
---
name: dag [65951,65954]
name: dag [67667,67670]
===
match
---
trailer [14744,14755]
trailer [14744,14755]
===
match
---
string: "\n" [36583,36587]
string: "\n" [38299,38303]
===
match
---
operator: , [16647,16648]
operator: , [16647,16648]
===
match
---
string: 'far_future_dag' [63905,63921]
string: 'far_future_dag' [65621,65637]
===
match
---
operator: = [20665,20666]
operator: = [20665,20666]
===
match
---
operator: == [23189,23191]
operator: == [23189,23191]
===
match
---
operator: = [19672,19673]
operator: = [19672,19673]
===
match
---
operator: , [69324,69325]
operator: , [71040,71041]
===
match
---
expr_stmt [40379,40395]
expr_stmt [42095,42111]
===
match
---
atom_expr [34994,35011]
atom_expr [36710,36727]
===
match
---
suite [60376,61394]
suite [62092,63110]
===
match
---
string: b'{{ ds }}' [19612,19623]
string: b'{{ ds }}' [19612,19623]
===
match
---
trailer [2620,2626]
trailer [2620,2626]
===
match
---
with_item [42747,42774]
with_item [44463,44490]
===
match
---
atom_expr [14719,14755]
atom_expr [14719,14755]
===
match
---
name: task_decorator [70819,70833]
name: task_decorator [72535,72549]
===
match
---
decorator [67418,67465]
decorator [69134,69181]
===
match
---
arglist [44316,44346]
arglist [46032,46062]
===
match
---
dotted_name [1672,1694]
dotted_name [1672,1694]
===
match
---
name: query [54372,54377]
name: query [56088,56093]
===
match
---
name: State [2041,2046]
name: State [2041,2046]
===
match
---
operator: = [2541,2542]
operator: = [2541,2542]
===
match
---
comparison [29729,29766]
comparison [31445,31482]
===
match
---
name: clear_db_runs [2471,2484]
name: clear_db_runs [2471,2484]
===
match
---
comparison [20786,20834]
comparison [20786,20834]
===
match
---
operator: = [45261,45262]
operator: = [46977,46978]
===
match
---
trailer [35723,35760]
trailer [37439,37476]
===
match
---
operator: == [7213,7215]
operator: == [7213,7215]
===
match
---
name: subdag [51900,51906]
name: subdag [53616,53622]
===
match
---
simple_stmt [32012,32111]
simple_stmt [33728,33827]
===
match
---
argument [56531,56546]
argument [58247,58262]
===
match
---
atom_expr [45946,45987]
atom_expr [47662,47703]
===
match
---
trailer [33432,33492]
trailer [35148,35208]
===
match
---
name: dag [61295,61298]
name: dag [63011,63014]
===
match
---
fstring_start: f' [15560,15562]
fstring_start: f' [15560,15562]
===
match
---
operator: , [38334,38335]
operator: , [40050,40051]
===
match
---
trailer [68996,69002]
trailer [70712,70718]
===
match
---
name: RUNNING [49473,49480]
name: RUNNING [51189,51196]
===
match
---
name: DummyOperator [19224,19237]
name: DummyOperator [19224,19237]
===
match
---
name: timezone [54812,54820]
name: timezone [56528,56536]
===
match
---
name: contextlib [884,894]
name: contextlib [884,894]
===
match
---
name: end_date [50856,50864]
name: end_date [52572,52580]
===
match
---
atom [63061,63119]
atom [64777,64835]
===
match
---
expr_stmt [4238,4265]
expr_stmt [4238,4265]
===
match
---
term [13610,13659]
term [13610,13659]
===
match
---
name: self [42999,43003]
name: self [44715,44719]
===
match
---
atom_expr [3808,3823]
atom_expr [3808,3823]
===
match
---
argument [58879,58885]
argument [60595,60601]
===
match
---
operator: , [49989,49990]
operator: , [51705,51706]
===
match
---
argument [18390,18405]
argument [18390,18405]
===
match
---
name: self [9437,9441]
name: self [9437,9441]
===
match
---
name: datetime [60992,61000]
name: datetime [62708,62716]
===
match
---
name: timezone [20570,20578]
name: timezone [20570,20578]
===
match
---
for_stmt [13219,13361]
for_stmt [13219,13361]
===
match
---
argument [6546,6559]
argument [6546,6559]
===
match
---
name: op2 [36297,36300]
name: op2 [38013,38016]
===
match
---
name: calculated_weight [16326,16343]
name: calculated_weight [16326,16343]
===
match
---
name: start_date [35736,35746]
name: start_date [37452,37462]
===
match
---
exprlist [3320,3324]
exprlist [3320,3324]
===
match
---
atom_expr [62151,62180]
atom_expr [63867,63896]
===
match
---
trailer [20096,20098]
trailer [20096,20098]
===
match
---
name: op1 [36389,36392]
name: op1 [38105,38108]
===
match
---
trailer [10429,10450]
trailer [10429,10450]
===
match
---
atom_expr [48436,48620]
atom_expr [50152,50336]
===
match
---
operator: == [10701,10703]
operator: == [10701,10703]
===
match
---
expr_stmt [53482,53507]
expr_stmt [55198,55223]
===
match
---
parameters [67548,67553]
parameters [69264,69269]
===
match
---
suite [14568,14598]
suite [14568,14598]
===
match
---
comparison [6924,6953]
comparison [6924,6953]
===
match
---
operator: , [56959,56960]
operator: , [58675,58676]
===
match
---
name: test_dag_none_default_args_start_date [12200,12237]
name: test_dag_none_default_args_start_date [12200,12237]
===
match
---
atom_expr [68698,68722]
atom_expr [70414,70438]
===
match
---
expr_stmt [47550,47624]
expr_stmt [49266,49340]
===
match
---
string: 'dag-bulk-sync-1' [25763,25780]
string: 'dag-bulk-sync-1' [27479,27496]
===
match
---
name: task [19217,19221]
name: task [19217,19221]
===
match
---
testlist_comp [49467,49481]
testlist_comp [51183,51197]
===
match
---
name: len [49282,49285]
name: len [50998,51001]
===
match
---
simple_stmt [989,1017]
simple_stmt [989,1017]
===
match
---
name: staticmethod [2753,2765]
name: staticmethod [2753,2765]
===
match
---
parameters [56205,56253]
parameters [57921,57969]
===
match
---
name: session [17558,17565]
name: session [17558,17565]
===
match
---
name: next_date [60910,60919]
name: next_date [62626,62635]
===
match
---
operator: = [64785,64786]
operator: = [66501,66502]
===
match
---
name: self [2519,2523]
name: self [2519,2523]
===
match
---
with_stmt [65964,66168]
with_stmt [67680,67884]
===
match
---
trailer [53350,53358]
trailer [55066,55074]
===
match
---
trailer [28955,29005]
trailer [30671,30721]
===
match
---
name: test_count_number_queries [65727,65752]
name: test_count_number_queries [67443,67468]
===
match
---
assert_stmt [46142,46175]
assert_stmt [47858,47891]
===
match
---
argument [17113,17119]
argument [17113,17119]
===
match
---
string: 'start_date' [44270,44282]
string: 'start_date' [45986,45998]
===
match
---
string: 'start_date' [11826,11838]
string: 'start_date' [11826,11838]
===
match
---
name: dates [55695,55700]
name: dates [57411,57416]
===
match
---
trailer [39689,39695]
trailer [41405,41411]
===
match
---
import_from [1017,1042]
import_from [1017,1042]
===
match
---
operator: = [17052,17053]
operator: = [17052,17053]
===
match
---
name: dag_id [54683,54689]
name: dag_id [56399,56405]
===
match
---
name: task_instance_2 [50608,50623]
name: task_instance_2 [52324,52339]
===
match
---
simple_stmt [50012,50041]
simple_stmt [51728,51757]
===
match
---
operator: = [9688,9689]
operator: = [9688,9689]
===
match
---
expr_stmt [37046,37079]
expr_stmt [38762,38795]
===
match
---
trailer [46010,46012]
trailer [47726,47728]
===
match
---
operator: = [49670,49671]
operator: = [51386,51387]
===
match
---
expr_stmt [62295,62461]
expr_stmt [64011,64177]
===
match
---
assert_stmt [37682,37724]
assert_stmt [39398,39440]
===
match
---
name: DEFAULT_DATE [41225,41237]
name: DEFAULT_DATE [42941,42953]
===
match
---
simple_stmt [30043,30267]
simple_stmt [31759,31983]
===
match
---
string: "test_dag_callback_crash" [39996,40021]
string: "test_dag_callback_crash" [41712,41737]
===
match
---
trailer [29364,29397]
trailer [31080,31113]
===
match
---
suite [24281,24443]
suite [25997,26159]
===
match
---
atom_expr [8537,8606]
atom_expr [8537,8606]
===
match
---
operator: = [51559,51560]
operator: = [53275,53276]
===
match
---
simple_stmt [15056,15103]
simple_stmt [15056,15103]
===
match
---
simple_stmt [46079,46134]
simple_stmt [47795,47850]
===
match
---
trailer [10344,10365]
trailer [10344,10365]
===
match
---
number: 2 [10447,10448]
number: 2 [10447,10448]
===
match
---
trailer [35411,35425]
trailer [37127,37141]
===
match
---
trailer [65451,65453]
trailer [67167,67169]
===
match
---
simple_stmt [30482,30521]
simple_stmt [32198,32237]
===
match
---
simple_stmt [2952,3032]
simple_stmt [2952,3032]
===
match
---
string: 'webserver' [29365,29376]
string: 'webserver' [31081,31092]
===
match
---
name: DagModel [31844,31852]
name: DagModel [33560,33568]
===
match
---
operator: = [12513,12514]
operator: = [12513,12514]
===
match
---
name: dag2 [6504,6508]
name: dag2 [6504,6508]
===
match
---
name: a [3177,3178]
name: a [3177,3178]
===
match
---
name: DagModel [31216,31224]
name: DagModel [32932,32940]
===
match
---
name: delete [46289,46295]
name: delete [48005,48011]
===
match
---
operator: } [61801,61802]
operator: } [63517,63518]
===
match
---
atom_expr [49691,49746]
atom_expr [51407,51462]
===
match
---
operator: == [16344,16346]
operator: == [16344,16346]
===
match
---
name: self [65532,65536]
name: self [67248,67252]
===
match
---
name: DagModel [32309,32317]
name: DagModel [34025,34033]
===
match
---
name: op9 [7144,7147]
name: op9 [7144,7147]
===
match
---
operator: == [6456,6458]
operator: == [6456,6458]
===
match
---
operator: , [69366,69367]
operator: , [71082,71083]
===
match
---
suite [54739,55084]
suite [56455,56800]
===
match
---
name: _next [24000,24005]
name: _next [24000,24005]
===
match
---
arglist [55601,55640]
arglist [57317,57356]
===
match
---
name: synchronize_session [3005,3024]
name: synchronize_session [3005,3024]
===
match
---
string: 'owner' [44250,44257]
string: 'owner' [45966,45973]
===
match
---
arglist [61374,61392]
arglist [63090,63108]
===
match
---
trailer [22523,22532]
trailer [22523,22532]
===
match
---
atom [12953,13042]
atom [12953,13042]
===
match
---
trailer [24037,24039]
trailer [24037,24039]
===
match
---
simple_stmt [24745,24919]
simple_stmt [26461,26635]
===
match
---
name: schedule_interval [23722,23739]
name: schedule_interval [23722,23739]
===
match
---
atom_expr [43150,43168]
atom_expr [44866,44884]
===
match
---
atom [11627,11705]
atom [11627,11705]
===
match
---
assert_stmt [51233,51269]
assert_stmt [52949,52985]
===
match
---
simple_stmt [70183,70421]
simple_stmt [71899,72137]
===
match
---
name: start_date [50169,50179]
name: start_date [51885,51895]
===
match
---
trailer [10787,10837]
trailer [10787,10837]
===
match
---
name: task [19408,19412]
name: task [19408,19412]
===
match
---
name: one [33618,33621]
name: one [35334,35337]
===
match
---
atom [18069,18084]
atom [18069,18084]
===
match
---
string: 'Europe/Zurich' [22533,22548]
string: 'Europe/Zurich' [22533,22548]
===
match
---
name: dag [62683,62686]
name: dag [64399,64402]
===
match
---
name: max_active_runs [51617,51632]
name: max_active_runs [53333,53348]
===
match
---
name: op3 [56797,56800]
name: op3 [58513,58516]
===
match
---
comp_op [46058,46064]
comp_op [47774,47780]
===
match
---
name: six_hours_ago_to_the_hour [57690,57715]
name: six_hours_ago_to_the_hour [59406,59431]
===
match
---
simple_stmt [814,829]
simple_stmt [814,829]
===
match
---
operator: = [64018,64019]
operator: = [65734,65735]
===
match
---
number: 1 [10314,10315]
number: 1 [10314,10315]
===
match
---
dictorsetmaker [26828,27011]
dictorsetmaker [28544,28727]
===
match
---
operator: , [50192,50193]
operator: , [51908,51909]
===
match
---
number: 1 [9219,9220]
number: 1 [9219,9220]
===
match
---
operator: = [21693,21694]
operator: = [21693,21694]
===
match
---
trailer [67874,67887]
trailer [69590,69603]
===
match
---
name: i [13114,13115]
name: i [13114,13115]
===
match
---
comp_op [39448,39454]
comp_op [41164,41170]
===
match
---
trailer [59658,59667]
trailer [61374,61383]
===
match
---
name: start_date [58797,58807]
name: start_date [60513,60523]
===
match
---
argument [52329,52352]
argument [54045,54068]
===
match
---
name: op2 [38542,38545]
name: op2 [40258,40261]
===
match
---
operator: = [30115,30116]
operator: = [31831,31832]
===
match
---
operator: = [39070,39071]
operator: = [40786,40787]
===
match
---
simple_stmt [17675,17760]
simple_stmt [17675,17760]
===
match
---
trailer [54829,54841]
trailer [56545,56557]
===
match
---
decorator [69872,69888]
decorator [71588,71604]
===
match
---
atom_expr [60082,60111]
atom_expr [61798,61827]
===
match
---
atom [25823,25909]
atom [27539,27625]
===
match
---
name: TestDagDecorator [66176,66192]
name: TestDagDecorator [67892,67908]
===
match
---
operator: , [59990,59991]
operator: , [61706,61707]
===
match
---
trailer [20619,20680]
trailer [20619,20680]
===
match
---
expr_stmt [37943,37982]
expr_stmt [39659,39698]
===
match
---
operator: = [69846,69847]
operator: = [71562,71563]
===
match
---
atom [46124,46132]
atom [47840,47848]
===
match
---
name: subdag [51698,51704]
name: subdag [53414,53420]
===
match
---
name: session [33421,33428]
name: session [35137,35144]
===
match
---
testlist_comp [46514,46541]
testlist_comp [48230,48257]
===
match
---
simple_stmt [10004,10028]
simple_stmt [10004,10028]
===
match
---
expr_stmt [56267,56375]
expr_stmt [57983,58091]
===
match
---
trailer [12967,13016]
trailer [12967,13016]
===
match
---
operator: == [47517,47519]
operator: == [49233,49235]
===
match
---
name: VALUE [69620,69625]
name: VALUE [71336,71341]
===
match
---
name: task_id [8800,8807]
name: task_id [8800,8807]
===
match
---
atom_expr [63143,63185]
atom_expr [64859,64901]
===
match
---
suite [8522,9401]
suite [8522,9401]
===
match
---
trailer [5234,5309]
trailer [5234,5309]
===
match
---
atom_expr [35398,35425]
atom_expr [37114,37141]
===
match
---
string: 'parent_dag' [7616,7628]
string: 'parent_dag' [7616,7628]
===
match
---
trailer [8754,8767]
trailer [8754,8767]
===
match
---
atom_expr [53458,53471]
atom_expr [55174,55187]
===
match
---
name: default_args [44586,44598]
name: default_args [46302,46314]
===
match
---
operator: = [53555,53556]
operator: = [55271,55272]
===
match
---
atom_expr [62080,62274]
atom_expr [63796,63990]
===
match
---
name: session [26596,26603]
name: session [28312,28319]
===
match
---
number: 4 [18272,18273]
number: 4 [18272,18273]
===
match
---
name: start_date [55511,55521]
name: start_date [57227,57237]
===
match
---
simple_stmt [55714,55726]
simple_stmt [57430,57442]
===
match
---
atom_expr [53188,53200]
atom_expr [54904,54916]
===
match
---
parameters [58520,58526]
parameters [60236,60242]
===
match
---
name: end_date [70478,70486]
name: end_date [72194,72202]
===
match
---
operator: = [52820,52821]
operator: = [54536,54537]
===
match
---
operator: = [41615,41616]
operator: = [43331,43332]
===
match
---
name: minutes [62253,62260]
name: minutes [63969,63976]
===
match
---
name: dag [45072,45075]
name: dag [46788,46791]
===
match
---
atom_expr [42234,42252]
atom_expr [43950,43968]
===
match
---
name: num [69060,69063]
name: num [70776,70779]
===
match
---
trailer [32377,32381]
trailer [34093,34097]
===
match
---
operator: , [22612,22613]
operator: , [22612,22613]
===
match
---
name: TEST_DATE [66143,66152]
name: TEST_DATE [67859,67868]
===
match
---
operator: , [61011,61012]
operator: , [62727,62728]
===
match
---
with_stmt [25613,25682]
with_stmt [27329,27398]
===
match
---
trailer [25844,25847]
trailer [27560,27563]
===
match
---
with_stmt [25690,26397]
with_stmt [27406,28113]
===
match
---
name: set_upstream [9974,9986]
name: set_upstream [9974,9986]
===
match
---
simple_stmt [21730,21766]
simple_stmt [21730,21766]
===
match
---
name: State [47478,47483]
name: State [49194,49199]
===
match
---
string: 'dag_default_view_old' [33449,33471]
string: 'dag_default_view_old' [35165,35187]
===
match
---
name: timedelta [939,948]
name: timedelta [939,948]
===
match
---
simple_stmt [22558,22652]
simple_stmt [22558,22652]
===
match
---
name: DummyOperator [8741,8754]
name: DummyOperator [8741,8754]
===
match
---
name: BaseOperator [40417,40429]
name: BaseOperator [42133,42145]
===
match
---
name: orm_dag [65278,65285]
name: orm_dag [66994,67001]
===
match
---
name: _occur_before [8350,8363]
name: _occur_before [8350,8363]
===
match
---
name: set [35582,35585]
name: set [37298,37301]
===
match
---
param [58521,58525]
param [60237,60241]
===
match
---
trailer [20327,20344]
trailer [20327,20344]
===
match
---
trailer [7178,7182]
trailer [7178,7182]
===
match
---
expr_stmt [19015,19053]
expr_stmt [19015,19053]
===
match
---
name: DAG [56394,56397]
name: DAG [58110,58113]
===
match
---
trailer [30993,31026]
trailer [32709,32742]
===
match
---
name: State [17391,17396]
name: State [17391,17396]
===
match
---
simple_stmt [30979,31027]
simple_stmt [32695,32743]
===
match
---
expr_stmt [50608,50683]
expr_stmt [52324,52399]
===
match
---
atom_expr [44784,44800]
atom_expr [46500,46516]
===
match
---
name: orm_dag [33534,33541]
name: orm_dag [35250,35257]
===
match
---
simple_stmt [38381,38415]
simple_stmt [40097,40131]
===
match
---
name: task [19910,19914]
name: task [19910,19914]
===
match
---
simple_stmt [19710,19751]
simple_stmt [19710,19751]
===
match
---
comparison [26624,26790]
comparison [28340,28506]
===
match
---
name: DAG [17596,17599]
name: DAG [17596,17599]
===
match
---
name: task_id [28956,28963]
name: task_id [30672,30679]
===
match
---
name: dag [63761,63764]
name: dag [65477,65480]
===
match
---
number: 3 [21517,21518]
number: 3 [21517,21518]
===
match
---
operator: } [18543,18544]
operator: } [18543,18544]
===
match
---
name: delete [34650,34656]
name: delete [36366,36372]
===
match
---
name: dummy [1738,1743]
name: dummy [1738,1743]
===
match
---
simple_stmt [62724,62780]
simple_stmt [64440,64496]
===
match
---
name: prev [21144,21148]
name: prev [21144,21148]
===
match
---
name: PRE_TRANSITION [20436,20450]
name: PRE_TRANSITION [20436,20450]
===
match
---
trailer [50499,50505]
trailer [52215,52221]
===
match
---
funcdef [9406,10538]
funcdef [9406,10538]
===
match
---
operator: , [39152,39153]
operator: , [40868,40869]
===
match
---
trailer [4291,4353]
trailer [4291,4353]
===
match
---
name: DagModel [33558,33566]
name: DagModel [35274,35282]
===
match
---
name: DAG [46809,46812]
name: DAG [48525,48528]
===
match
---
operator: = [64114,64115]
operator: = [65830,65831]
===
match
---
operator: = [13939,13940]
operator: = [13939,13940]
===
match
---
arglist [63987,64028]
arglist [65703,65744]
===
match
---
string: 'test_field' [19334,19346]
string: 'test_field' [19334,19346]
===
match
---
simple_stmt [42022,42178]
simple_stmt [43738,43894]
===
match
---
atom_expr [25695,25711]
atom_expr [27411,27427]
===
match
---
operator: = [65041,65042]
operator: = [66757,66758]
===
match
---
name: op2 [9086,9089]
name: op2 [9086,9089]
===
match
---
name: next_local [22005,22015]
name: next_local [22005,22015]
===
match
---
arglist [29365,29396]
arglist [31081,31112]
===
match
---
trailer [63897,63964]
trailer [65613,65680]
===
match
---
comparison [38091,38101]
comparison [39807,39817]
===
match
---
name: session [64513,64520]
name: session [66229,66236]
===
match
---
name: DEFAULT_DATE [41438,41450]
name: DEFAULT_DATE [43154,43166]
===
match
---
string: 'owner' [10662,10669]
string: 'owner' [10662,10669]
===
match
---
operator: == [22028,22030]
operator: == [22028,22030]
===
match
---
number: 2020 [59983,59987]
number: 2020 [61699,61703]
===
match
---
operator: , [8373,8374]
operator: , [8373,8374]
===
match
---
name: State [69432,69437]
name: State [71148,71153]
===
match
---
name: self [43846,43850]
name: self [45562,45566]
===
match
---
operator: = [23701,23702]
operator: = [23701,23702]
===
match
---
name: self [69847,69851]
name: self [71563,71567]
===
match
---
name: patcher_dag_code [2604,2620]
name: patcher_dag_code [2604,2620]
===
match
---
operator: = [8807,8808]
operator: = [8807,8808]
===
match
---
trailer [39112,39175]
trailer [40828,40891]
===
match
---
operator: , [52903,52904]
operator: , [54619,54620]
===
match
---
name: j [15572,15573]
name: j [15572,15573]
===
match
---
name: _clean_up [49636,49645]
name: _clean_up [51352,51361]
===
match
---
name: __file__ [66890,66898]
name: __file__ [68606,68614]
===
match
---
operator: , [61152,61153]
operator: , [62868,62869]
===
match
---
atom_expr [63091,63118]
atom_expr [64807,64834]
===
match
---
decorated [68001,68077]
decorated [69717,69793]
===
match
---
name: test_dag_param_resolves [68803,68826]
name: test_dag_param_resolves [70519,70542]
===
match
---
string: 'test-dag' [26165,26175]
string: 'test-dag' [27881,27891]
===
match
---
comparison [18272,18415]
comparison [18272,18415]
===
match
---
operator: = [60661,60662]
operator: = [62377,62378]
===
match
---
name: timezone [56840,56848]
name: timezone [58556,58564]
===
match
---
operator: = [27533,27534]
operator: = [29249,29250]
===
match
---
name: dag [45749,45752]
name: dag [47465,47468]
===
match
---
funcdef [2770,3136]
funcdef [2770,3136]
===
match
---
name: self [67042,67046]
name: self [68758,68762]
===
match
---
comparison [22948,22995]
comparison [22948,22995]
===
match
---
name: ACTION_CAN_READ [63389,63404]
name: ACTION_CAN_READ [65105,65120]
===
match
---
name: start_date [18584,18594]
name: start_date [18584,18594]
===
match
---
name: set [31676,31679]
name: set [33392,33395]
===
match
---
name: test_dag_naive_default_args_start_date [11895,11933]
name: test_dag_naive_default_args_start_date [11895,11933]
===
match
---
operator: = [49713,49714]
operator: = [51429,51430]
===
match
---
simple_stmt [27669,27706]
simple_stmt [29385,29422]
===
match
---
name: DEFAULT_DATE [69400,69412]
name: DEFAULT_DATE [71116,71128]
===
match
---
trailer [27128,27145]
trailer [28844,28861]
===
match
---
operator: = [56538,56539]
operator: = [58254,58255]
===
match
---
trailer [23016,23035]
trailer [23016,23035]
===
match
---
name: default_args [10912,10924]
name: default_args [10912,10924]
===
match
---
operator: , [54837,54838]
operator: , [56553,56554]
===
match
---
suite [38914,39791]
suite [40630,41507]
===
match
---
expr_stmt [43963,44004]
expr_stmt [45679,45720]
===
match
---
name: setUp [2442,2447]
name: setUp [2442,2447]
===
match
---
atom_expr [67870,67887]
atom_expr [69586,69603]
===
match
---
number: 2016 [61001,61005]
number: 2016 [62717,62721]
===
match
---
trailer [10022,10027]
trailer [10022,10027]
===
match
---
name: correct_weight [13593,13607]
name: correct_weight [13593,13607]
===
match
---
operator: = [38570,38571]
operator: = [40286,40287]
===
match
---
argument [60730,60781]
argument [62446,62497]
===
match
---
operator: = [28539,28540]
operator: = [30255,30256]
===
match
---
trailer [22675,22690]
trailer [22675,22690]
===
match
---
comparison [46262,46287]
comparison [47978,48003]
===
match
---
name: start_date [52775,52785]
name: start_date [54491,54501]
===
match
---
name: self [35632,35636]
name: self [37348,37352]
===
match
---
name: max_active_runs [53613,53628]
name: max_active_runs [55329,55344]
===
match
---
name: session [17504,17511]
name: session [17504,17511]
===
match
---
dictorsetmaker [63143,63229]
dictorsetmaker [64859,64945]
===
match
---
dotted_name [2154,2179]
dotted_name [2154,2179]
===
match
---
name: orm_dag [30441,30448]
name: orm_dag [32157,32164]
===
match
---
name: hash [45744,45748]
name: hash [47460,47464]
===
match
---
name: utc [22814,22817]
name: utc [22814,22817]
===
match
---
name: i [12984,12985]
name: i [12984,12985]
===
match
---
name: task_instance_1 [48760,48775]
name: task_instance_1 [50476,50491]
===
match
---
atom_expr [56624,56660]
atom_expr [58340,58376]
===
match
---
simple_stmt [9684,9717]
simple_stmt [9684,9717]
===
match
---
operator: = [39313,39314]
operator: = [41029,41030]
===
match
---
trailer [30666,30737]
trailer [32382,32453]
===
match
---
operator: , [24570,24571]
operator: , [26286,26287]
===
match
---
name: dag_run [39354,39361]
name: dag_run [41070,41077]
===
match
---
assert_stmt [47949,47984]
assert_stmt [49665,49700]
===
match
---
name: is_paused [31870,31879]
name: is_paused [33586,33595]
===
match
---
simple_stmt [11048,11576]
simple_stmt [11048,11576]
===
match
---
arglist [51664,51688]
arglist [53380,53404]
===
match
---
name: SubDagOperator [49892,49906]
name: SubDagOperator [51608,51622]
===
match
---
trailer [28274,28286]
trailer [29990,30002]
===
match
---
string: 'dag' [16479,16484]
string: 'dag' [16479,16484]
===
match
---
trailer [51208,51212]
trailer [52924,52928]
===
match
---
simple_stmt [5323,5392]
simple_stmt [5323,5392]
===
match
---
trailer [16130,16132]
trailer [16130,16132]
===
match
---
trailer [41649,41656]
trailer [43365,43372]
===
match
---
name: datetime [48895,48903]
name: datetime [50611,50619]
===
match
---
simple_stmt [41538,41555]
simple_stmt [43254,43271]
===
match
---
trailer [9132,9135]
trailer [9132,9135]
===
match
---
name: weight_rule [15649,15660]
name: weight_rule [15649,15660]
===
match
---
simple_stmt [63704,63746]
simple_stmt [65420,65462]
===
match
---
simple_stmt [38427,38461]
simple_stmt [40143,40177]
===
match
---
name: model [27715,27720]
name: model [29431,29436]
===
match
---
trailer [23926,23928]
trailer [23926,23928]
===
match
---
simple_stmt [24223,24240]
simple_stmt [25939,25956]
===
match
---
name: owner [27586,27591]
name: owner [29302,29307]
===
match
---
suite [25277,25320]
suite [26993,27036]
===
match
---
operator: = [8535,8536]
operator: = [8535,8536]
===
match
---
operator: = [32668,32669]
operator: = [34384,34385]
===
match
---
for_stmt [61928,62035]
for_stmt [63644,63751]
===
match
---
arglist [54450,54470]
arglist [56166,56186]
===
match
---
simple_stmt [37995,38029]
simple_stmt [39711,39745]
===
match
---
name: dag [42525,42528]
name: dag [44241,44244]
===
match
---
trailer [48753,48759]
trailer [50469,50475]
===
match
---
name: test_dag_id [44496,44507]
name: test_dag_id [46212,46223]
===
match
---
number: 2020 [59240,59244]
number: 2020 [60956,60960]
===
match
---
operator: = [47737,47738]
operator: = [49453,49454]
===
match
---
funcdef [37730,38240]
funcdef [39446,39956]
===
match
---
atom_expr [48629,48652]
atom_expr [50345,50368]
===
match
---
name: TaskFail [3075,3083]
name: TaskFail [3075,3083]
===
match
---
operator: = [43873,43874]
operator: = [45589,45590]
===
match
---
trailer [56848,56855]
trailer [58564,58571]
===
match
---
simple_stmt [18660,18695]
simple_stmt [18660,18695]
===
match
---
with_item [25695,25722]
with_item [27411,27438]
===
match
---
name: i [61932,61933]
name: i [63648,63649]
===
match
---
name: self [36117,36121]
name: self [37833,37837]
===
match
---
suite [44771,44819]
suite [46487,46535]
===
match
---
atom_expr [47956,47974]
atom_expr [49672,49690]
===
match
---
name: dag_subclass_diff_name [45489,45511]
name: dag_subclass_diff_name [47205,47227]
===
match
---
name: dag [39196,39199]
name: dag [40912,40915]
===
match
---
operator: { [5966,5967]
operator: { [5966,5967]
===
match
---
name: op1 [38519,38522]
name: op1 [40235,40238]
===
match
---
trailer [21792,21802]
trailer [21792,21802]
===
match
---
string: 'airflow' [5381,5390]
string: 'airflow' [5381,5390]
===
match
---
string: """Verify that same tasks with Duplicate task_id do not raise error""" [37798,37868]
string: """Verify that same tasks with Duplicate task_id do not raise error""" [39514,39584]
===
match
---
name: create_session [25695,25709]
name: create_session [27411,27425]
===
match
---
name: DAG [27428,27431]
name: DAG [29144,29147]
===
match
---
atom [38203,38239]
atom [39919,39955]
===
match
---
name: noop_pipeline [67477,67490]
name: noop_pipeline [69193,69206]
===
match
---
operator: = [57264,57265]
operator: = [58980,58981]
===
match
---
atom_expr [39538,39560]
atom_expr [41254,41276]
===
match
---
number: 123 [54096,54099]
number: 123 [55812,55815]
===
match
---
atom_expr [39715,39739]
atom_expr [41431,41455]
===
match
---
comparison [24301,24442]
comparison [26017,26158]
===
match
---
trailer [57548,57550]
trailer [59264,59266]
===
match
---
simple_stmt [28941,29006]
simple_stmt [30657,30722]
===
match
---
trailer [54182,54323]
trailer [55898,56039]
===
match
---
argument [64108,64125]
argument [65824,65841]
===
match
---
name: start_date [36997,37007]
name: start_date [38713,38723]
===
match
---
name: session [24273,24280]
name: session [25989,25996]
===
match
---
parameters [49546,49567]
parameters [51262,51283]
===
match
---
arglist [15552,15681]
arglist [15552,15681]
===
match
---
operator: = [46094,46095]
operator: = [47810,47811]
===
match
---
name: WeightRule [15661,15671]
name: WeightRule [15661,15671]
===
match
---
name: dag [20920,20923]
name: dag [20920,20923]
===
match
---
comparison [3420,3434]
comparison [3420,3434]
===
match
---
name: airflow [1672,1679]
name: airflow [1672,1679]
===
match
---
trailer [48728,48736]
trailer [50444,50452]
===
match
---
atom_expr [57028,57058]
atom_expr [58744,58774]
===
match
---
name: remove [9245,9251]
name: remove [9245,9251]
===
match
---
comparison [6685,6706]
comparison [6685,6706]
===
match
---
trailer [41956,41966]
trailer [43672,43682]
===
match
---
operator: = [54206,54207]
operator: = [55922,55923]
===
match
---
number: 0 [14469,14470]
number: 0 [14469,14470]
===
match
---
name: DAG [8537,8540]
name: DAG [8537,8540]
===
match
---
operator: = [17947,17948]
operator: = [17947,17948]
===
match
---
atom_expr [10208,10227]
atom_expr [10208,10227]
===
match
---
name: start_date [65818,65828]
name: start_date [67534,67544]
===
match
---
return_stmt [3472,3501]
return_stmt [3472,3501]
===
match
---
operator: , [51436,51437]
operator: , [53152,53153]
===
match
---
name: run_id [39489,39495]
name: run_id [41205,41211]
===
match
---
atom [25929,26340]
atom [27645,28056]
===
match
---
atom_expr [47084,47117]
atom_expr [48800,48833]
===
match
---
atom_expr [52579,52636]
atom_expr [54295,54352]
===
match
---
trailer [65865,65878]
trailer [67581,67594]
===
match
---
atom_expr [23102,23124]
atom_expr [23102,23124]
===
match
---
name: expand [53238,53244]
name: expand [54954,54960]
===
match
---
trailer [48913,48921]
trailer [50629,50637]
===
match
---
trailer [34435,34447]
trailer [36151,36163]
===
match
---
number: 1 [12018,12019]
number: 1 [12018,12019]
===
match
---
assert_stmt [47498,47540]
assert_stmt [49214,49256]
===
match
---
trailer [17172,17246]
trailer [17172,17246]
===
match
---
name: width [14413,14418]
name: width [14413,14418]
===
match
---
name: dag_run [39433,39440]
name: dag_run [41149,41156]
===
match
---
operator: = [58119,58120]
operator: = [59835,59836]
===
match
---
suite [61448,62946]
suite [63164,64662]
===
match
---
comparison [10160,10187]
comparison [10160,10187]
===
match
---
with_stmt [6753,6858]
with_stmt [6753,6858]
===
match
---
operator: = [59546,59547]
operator: = [61262,61263]
===
match
---
operator: @ [66658,66659]
operator: @ [68374,68375]
===
match
---
trailer [46660,46670]
trailer [48376,48386]
===
match
---
trailer [33044,33055]
trailer [34760,34771]
===
match
---
name: self [16405,16409]
name: self [16405,16409]
===
match
---
assert_stmt [10375,10409]
assert_stmt [10375,10409]
===
match
---
name: op8 [7205,7208]
name: op8 [7205,7208]
===
match
---
operator: = [18629,18630]
operator: = [18629,18630]
===
match
---
name: settings [12173,12181]
name: settings [12173,12181]
===
match
---
trailer [19098,19106]
trailer [19098,19106]
===
match
---
atom [12883,12902]
atom [12883,12902]
===
match
---
simple_stmt [66500,66516]
simple_stmt [68216,68232]
===
match
---
name: run_type [41380,41388]
name: run_type [43096,43104]
===
match
---
operator: = [34964,34965]
operator: = [36680,36681]
===
match
---
name: dag [49685,49688]
name: dag [51401,51404]
===
match
---
name: get_num_task_instances [17889,17911]
name: get_num_task_instances [17889,17911]
===
match
---
atom_expr [29421,29440]
atom_expr [31137,31156]
===
match
---
operator: = [71030,71031]
operator: = [72746,72747]
===
match
---
simple_stmt [53986,54063]
simple_stmt [55702,55779]
===
match
---
name: models [1530,1536]
name: models [1530,1536]
===
match
---
name: default_args [8573,8585]
name: default_args [8573,8585]
===
match
---
string: 'dag-bulk-sync-1' [25006,25023]
string: 'dag-bulk-sync-1' [26722,26739]
===
match
---
simple_stmt [9109,9145]
simple_stmt [9109,9145]
===
match
---
operator: = [70132,70133]
operator: = [71848,71849]
===
match
---
simple_stmt [4238,4266]
simple_stmt [4238,4266]
===
match
---
funcdef [70767,71017]
funcdef [72483,72733]
===
match
---
simple_stmt [9281,9317]
simple_stmt [9281,9317]
===
match
---
name: op2 [9684,9687]
name: op2 [9684,9687]
===
match
---
operator: = [50220,50221]
operator: = [51936,51937]
===
match
---
argument [19785,19808]
argument [19785,19808]
===
match
---
name: session [17477,17484]
name: session [17477,17484]
===
match
---
trailer [58425,58434]
trailer [60141,60150]
===
match
---
atom_expr [38661,38711]
atom_expr [40377,40427]
===
match
---
operator: , [30251,30252]
operator: , [31967,31968]
===
match
---
name: schedule_interval [42265,42282]
name: schedule_interval [43981,43998]
===
match
---
operator: = [16914,16915]
operator: = [16914,16915]
===
match
---
name: start_date [30209,30219]
name: start_date [31925,31935]
===
match
---
arglist [30994,31025]
arglist [32710,32741]
===
match
---
name: subdag [31169,31175]
name: subdag [32885,32891]
===
match
---
atom_expr [51781,51835]
atom_expr [53497,53551]
===
match
---
name: datetime [59659,59667]
name: datetime [61375,61383]
===
match
---
name: in_ [31249,31252]
name: in_ [32965,32968]
===
match
---
expr_stmt [35965,35998]
expr_stmt [37681,37714]
===
match
---
number: 0 [10225,10226]
number: 0 [10225,10226]
===
match
---
operator: = [13608,13609]
operator: = [13608,13609]
===
match
---
arglist [49907,49945]
arglist [51623,51661]
===
match
---
simple_stmt [57514,57551]
simple_stmt [59230,59267]
===
match
---
name: jinja_udf [18785,18794]
name: jinja_udf [18785,18794]
===
match
---
simple_stmt [42788,42839]
simple_stmt [44504,44555]
===
match
---
argument [8573,8605]
argument [8573,8605]
===
match
---
assert_stmt [28401,28446]
assert_stmt [30117,30162]
===
match
---
name: dag [65947,65950]
name: dag [67663,67666]
===
match
---
expr_stmt [61283,61327]
expr_stmt [62999,63043]
===
match
---
name: execution_date [52587,52601]
name: execution_date [54303,54317]
===
match
---
name: task_instances [54579,54593]
name: task_instances [56295,56309]
===
match
---
operator: , [66257,66258]
operator: , [67973,67974]
===
match
---
trailer [8349,8363]
trailer [8349,8363]
===
match
---
argument [41174,41187]
argument [42890,42903]
===
match
---
operator: = [56982,56983]
operator: = [58698,58699]
===
match
---
trailer [32328,32349]
trailer [34044,34065]
===
match
---
name: DAG [25655,25658]
name: DAG [27371,27374]
===
match
---
name: owner [28624,28629]
name: owner [30340,30345]
===
match
---
trailer [6627,6631]
trailer [6627,6631]
===
match
---
operator: = [62478,62479]
operator: = [64194,64195]
===
match
---
name: NONE [49446,49450]
name: NONE [51162,51166]
===
match
---
name: timedelta [17103,17112]
name: timedelta [17103,17112]
===
match
---
string: "test_schedule_dag_relativedelta" [23615,23648]
string: "test_schedule_dag_relativedelta" [23615,23648]
===
match
---
trailer [6313,6319]
trailer [6313,6319]
===
match
---
atom [14162,14437]
atom [14162,14437]
===
match
---
testlist_comp [44710,44769]
testlist_comp [46426,46485]
===
match
---
testlist_comp [46557,46579]
testlist_comp [48273,48295]
===
match
---
trailer [54115,54121]
trailer [55831,55837]
===
match
---
atom_expr [50264,50451]
atom_expr [51980,52167]
===
match
---
operator: , [40469,40470]
operator: , [42185,42186]
===
match
---
simple_stmt [22941,22996]
simple_stmt [22941,22996]
===
match
---
expr_stmt [55768,55807]
expr_stmt [57484,57523]
===
match
---
trailer [54501,54503]
trailer [56217,56219]
===
match
---
number: 5 [59989,59990]
number: 5 [61705,61706]
===
match
---
simple_stmt [7144,7159]
simple_stmt [7144,7159]
===
match
---
trailer [43344,43346]
trailer [45060,45062]
===
match
---
simple_stmt [12406,12447]
simple_stmt [12406,12447]
===
match
---
trailer [52030,52197]
trailer [53746,53913]
===
match
---
operator: = [40384,40385]
operator: = [42100,42101]
===
match
---
name: _next [23969,23974]
name: _next [23969,23974]
===
match
---
name: prev_local [20955,20965]
name: prev_local [20955,20965]
===
match
---
trailer [64469,64471]
trailer [66185,66187]
===
match
---
operator: { [37213,37214]
operator: { [38929,38930]
===
match
---
simple_stmt [55950,55998]
simple_stmt [57666,57714]
===
match
---
string: """             Create a subdag.             """ [61681,61729]
string: """             Create a subdag.             """ [63397,63445]
===
match
---
assert_stmt [67280,67305]
assert_stmt [68996,69021]
===
match
---
operator: , [9094,9095]
operator: , [9094,9095]
===
match
---
atom_expr [19637,19646]
atom_expr [19637,19646]
===
match
---
atom_expr [64427,64471]
atom_expr [66143,66187]
===
match
---
name: DAG [28493,28496]
name: DAG [30209,30212]
===
match
---
string: "2018-03-24T03:00:00+01:00" [23351,23378]
string: "2018-03-24T03:00:00+01:00" [23351,23378]
===
match
---
name: topological_list [8462,8478]
name: topological_list [8462,8478]
===
match
---
assert_stmt [21000,21060]
assert_stmt [21000,21060]
===
match
---
suite [42013,42966]
suite [43729,44682]
===
match
---
name: set1 [10127,10131]
name: set1 [10127,10131]
===
match
---
operator: = [64229,64230]
operator: = [65945,65946]
===
match
---
name: DagRun [2881,2887]
name: DagRun [2881,2887]
===
match
---
name: dag_id [42958,42964]
name: dag_id [44674,44680]
===
match
---
assert_stmt [28262,28300]
assert_stmt [29978,30016]
===
match
---
operator: == [63621,63623]
operator: == [65337,65339]
===
match
---
operator: = [40127,40128]
operator: = [41843,41844]
===
match
---
name: op8 [7058,7061]
name: op8 [7058,7061]
===
match
---
name: test_next_dagrun_after_date_timedelta_schedule_and_catchup_true [59309,59372]
name: test_next_dagrun_after_date_timedelta_schedule_and_catchup_true [61025,61088]
===
match
---
name: safe_dag_id [29429,29440]
name: safe_dag_id [31145,31156]
===
match
---
operator: , [65701,65702]
operator: , [67417,67418]
===
match
---
trailer [55983,55989]
trailer [57699,57705]
===
match
---
name: timezone [20319,20327]
name: timezone [20319,20327]
===
match
---
string: "Task id 't1' has already been added to the DAG" [37430,37478]
string: "Task id 't1' has already been added to the DAG" [39146,39194]
===
match
---
operator: , [62017,62018]
operator: , [63733,63734]
===
match
---
name: orm_dag [29421,29428]
name: orm_dag [31137,31144]
===
match
---
operator: = [12975,12976]
operator: = [12975,12976]
===
match
---
name: prev [22206,22210]
name: prev [22206,22210]
===
match
---
name: i [15890,15891]
name: i [15890,15891]
===
match
---
string: 'value' [71076,71083]
string: 'value' [72792,72799]
===
match
---
name: next_dagrun_after_date [60020,60042]
name: next_dagrun_after_date [61736,61758]
===
match
---
simple_stmt [788,804]
simple_stmt [788,804]
===
match
---
trailer [40416,40488]
trailer [42132,42204]
===
match
---
operator: = [34193,34194]
operator: = [35909,35910]
===
match
---
testlist_comp [20043,20055]
testlist_comp [20043,20055]
===
match
---
testlist_comp [32425,32437]
testlist_comp [34141,34153]
===
match
---
name: dag [70188,70191]
name: dag [71904,71907]
===
match
---
operator: - [16018,16019]
operator: - [16018,16019]
===
match
---
name: self [24097,24101]
name: self [25813,25817]
===
match
---
string: """         Tests that an attempt to schedule a task after the Dag's end_date         does not succeed.         """ [55152,55267]
string: """         Tests that an attempt to schedule a task after the Dag's end_date         does not succeed.         """ [56868,56983]
===
match
---
simple_stmt [44142,44183]
simple_stmt [45858,45899]
===
match
---
operator: , [31661,31662]
operator: , [33377,33378]
===
match
---
trailer [43153,43168]
trailer [44869,44884]
===
match
---
testlist_comp [35552,35560]
testlist_comp [37268,37276]
===
match
---
name: tests [2203,2208]
name: tests [2203,2208]
===
match
---
name: op3 [6415,6418]
name: op3 [6415,6418]
===
match
---
trailer [11768,11781]
trailer [11768,11781]
===
match
---
name: a_index [3274,3281]
name: a_index [3274,3281]
===
match
---
trailer [22197,22205]
trailer [22197,22205]
===
match
---
atom_expr [8193,8253]
atom_expr [8193,8253]
===
match
---
name: orm_subdag [29668,29678]
name: orm_subdag [31384,31394]
===
match
---
operator: = [35785,35786]
operator: = [37501,37502]
===
match
---
operator: = [17265,17266]
operator: = [17265,17266]
===
match
---
simple_stmt [20913,20947]
simple_stmt [20913,20947]
===
match
---
name: dag [7148,7151]
name: dag [7148,7151]
===
match
---
trailer [53809,53822]
trailer [55525,55538]
===
match
---
name: op2 [6151,6154]
name: op2 [6151,6154]
===
match
---
name: dag [47078,47081]
name: dag [48794,48797]
===
match
---
trailer [34122,34157]
trailer [35838,35873]
===
match
---
name: DEFAULT_DATE [52381,52393]
name: DEFAULT_DATE [54097,54109]
===
match
---
argument [70727,70757]
argument [72443,72473]
===
match
---
trailer [47572,47624]
trailer [49288,49340]
===
match
---
operator: , [52937,52938]
operator: , [54653,54654]
===
match
---
trailer [9049,9067]
trailer [9049,9067]
===
match
---
trailer [21017,21027]
trailer [21017,21027]
===
match
---
operator: > [45447,45448]
operator: > [47163,47164]
===
match
---
name: op1 [36012,36015]
name: op1 [37728,37731]
===
match
---
operator: @ [69017,69018]
operator: @ [70733,70734]
===
match
---
simple_stmt [2718,2747]
simple_stmt [2718,2747]
===
match
---
name: dag_id [2784,2790]
name: dag_id [2784,2790]
===
match
---
expr_stmt [34794,34839]
expr_stmt [36510,36555]
===
match
---
operator: , [2582,2583]
operator: , [2582,2583]
===
match
---
trailer [30393,30419]
trailer [32109,32135]
===
match
---
number: 1 [58884,58885]
number: 1 [60600,60601]
===
match
---
name: op2 [37607,37610]
name: op2 [39323,39326]
===
match
---
name: utc [22661,22664]
name: utc [22661,22664]
===
match
---
operator: , [27695,27696]
operator: , [29411,29412]
===
match
---
assert_stmt [7168,7189]
assert_stmt [7168,7189]
===
match
---
operator: , [9467,9468]
operator: , [9467,9468]
===
match
---
name: self [18882,18886]
name: self [18882,18886]
===
match
---
name: catchup [58191,58198]
name: catchup [59907,59914]
===
match
---
fstring_expr [62009,62016]
fstring_expr [63725,63732]
===
match
---
argument [23707,23720]
argument [23707,23720]
===
match
---
comparison [36651,36674]
comparison [38367,38390]
===
match
---
name: return_num [70020,70030]
name: return_num [71736,71746]
===
match
---
trailer [29540,29542]
trailer [31256,31258]
===
match
---
string: 'a_child' [8364,8373]
string: 'a_child' [8364,8373]
===
match
---
operator: } [4228,4229]
operator: } [4228,4229]
===
match
---
dictorsetmaker [26625,26699]
dictorsetmaker [28341,28415]
===
match
---
trailer [5333,5391]
trailer [5333,5391]
===
match
---
atom_expr [12057,12074]
atom_expr [12057,12074]
===
match
---
operator: } [8604,8605]
operator: } [8604,8605]
===
match
---
name: dag [47131,47134]
name: dag [48847,48850]
===
match
---
atom_expr [7175,7182]
atom_expr [7175,7182]
===
match
---
expr_stmt [12083,12141]
expr_stmt [12083,12141]
===
match
---
name: task_id [8845,8852]
name: task_id [8845,8852]
===
match
---
name: DummyOperator [65892,65905]
name: DummyOperator [67608,67621]
===
match
---
param [21311,21315]
param [21311,21315]
===
match
---
operator: = [51671,51672]
operator: = [53387,53388]
===
match
---
simple_stmt [64540,64556]
simple_stmt [66256,66272]
===
match
---
number: 1 [61136,61137]
number: 1 [62852,62853]
===
match
---
operator: == [23348,23350]
operator: == [23348,23350]
===
match
---
operator: , [23820,23821]
operator: , [23820,23821]
===
match
---
operator: { [32410,32411]
operator: { [34126,34127]
===
match
---
operator: = [49994,49995]
operator: = [51710,51711]
===
match
---
operator: = [12550,12551]
operator: = [12550,12551]
===
match
---
operator: , [14246,14247]
operator: , [14246,14247]
===
match
---
string: 'role2' [63367,63374]
string: 'role2' [65083,65090]
===
match
---
atom_expr [23325,23347]
atom_expr [23325,23347]
===
match
---
name: session [28109,28116]
name: session [29825,29832]
===
match
---
argument [51880,51890]
argument [53596,53606]
===
match
---
trailer [2825,2827]
trailer [2825,2827]
===
match
---
operator: = [57595,57596]
operator: = [59311,59312]
===
match
---
argument [14054,14077]
argument [14054,14077]
===
match
---
trailer [41366,41529]
trailer [43082,43245]
===
match
---
name: stdout [36459,36465]
name: stdout [38175,38181]
===
match
---
with_stmt [25448,25517]
with_stmt [27164,27233]
===
match
---
name: last_parsed_time [27129,27145]
name: last_parsed_time [28845,28861]
===
match
---
simple_stmt [40086,40139]
simple_stmt [41802,41855]
===
match
---
simple_stmt [52206,52405]
simple_stmt [53922,54121]
===
match
---
name: dag_id [33833,33839]
name: dag_id [35549,35555]
===
match
---
operator: = [16834,16835]
operator: = [16834,16835]
===
match
---
not_test [32848,32871]
not_test [34564,34587]
===
match
---
name: dag_subclass [44733,44745]
name: dag_subclass [46449,46461]
===
match
---
name: tearDown [65580,65588]
name: tearDown [67296,67304]
===
match
---
comparison [49359,49388]
comparison [51075,51104]
===
match
---
name: dag [4944,4947]
name: dag [4944,4947]
===
match
---
simple_stmt [45596,45623]
simple_stmt [47312,47339]
===
match
---
atom_expr [62683,62715]
atom_expr [64399,64431]
===
match
---
name: op1 [38381,38384]
name: op1 [40097,40100]
===
match
---
atom_expr [5649,5664]
atom_expr [5649,5664]
===
match
---
trailer [6282,6286]
trailer [6282,6286]
===
match
---
name: DAG [4732,4735]
name: DAG [4732,4735]
===
match
---
atom_expr [66832,66842]
atom_expr [68548,68558]
===
match
---
operator: , [61148,61149]
operator: , [62864,62865]
===
match
---
simple_stmt [13932,13943]
simple_stmt [13932,13943]
===
match
---
name: next_date [60284,60293]
name: next_date [62000,62009]
===
match
---
number: 0 [60779,60780]
number: 0 [62495,62496]
===
match
---
name: get_paused_dag_ids [46105,46123]
name: get_paused_dag_ids [47821,47839]
===
match
---
expr_stmt [27422,27504]
expr_stmt [29138,29220]
===
match
---
name: Session [50031,50038]
name: Session [51747,51754]
===
match
---
name: next_date [57987,57996]
name: next_date [59703,59712]
===
match
---
trailer [66201,66210]
trailer [67917,67926]
===
match
---
trailer [34279,34283]
trailer [35995,35999]
===
match
---
trailer [7120,7135]
trailer [7120,7135]
===
match
---
operator: , [19139,19140]
operator: , [19139,19140]
===
match
---
name: next_local [20850,20860]
name: next_local [20850,20860]
===
match
---
trailer [57353,57376]
trailer [59069,59092]
===
match
---
name: test_following_previous_schedule [20171,20203]
name: test_following_previous_schedule [20171,20203]
===
match
---
atom_expr [27546,27602]
atom_expr [29262,29318]
===
match
---
param [49547,49552]
param [51263,51268]
===
match
---
trailer [9158,9165]
trailer [9158,9165]
===
match
---
name: assert_queries_count [2273,2293]
name: assert_queries_count [2273,2293]
===
match
---
suite [9626,10028]
suite [9626,10028]
===
match
---
comparison [9116,9144]
comparison [9116,9144]
===
match
---
operator: } [31671,31672]
operator: } [33387,33388]
===
match
---
funcdef [10543,10727]
funcdef [10543,10727]
===
match
---
trailer [61976,62034]
trailer [63692,63750]
===
match
---
name: stage [15963,15968]
name: stage [15963,15968]
===
match
---
assert_stmt [38084,38101]
assert_stmt [39800,39817]
===
match
---
simple_stmt [2236,2294]
simple_stmt [2236,2294]
===
match
---
comparison [54949,54991]
comparison [56665,56707]
===
match
---
name: dag [49796,49799]
name: dag [51512,51515]
===
match
---
name: timezone [34814,34822]
name: timezone [36530,36538]
===
match
---
operator: == [15892,15894]
operator: == [15892,15894]
===
match
---
number: 2038 [63952,63956]
number: 2038 [65668,65672]
===
match
---
name: subdag [51932,51938]
name: subdag [53648,53654]
===
match
---
import_from [1360,1429]
import_from [1360,1429]
===
match
---
operator: , [46378,46379]
operator: , [48094,48095]
===
match
---
atom_expr [44082,44092]
atom_expr [45798,45808]
===
match
---
number: 1 [63958,63959]
number: 1 [65674,65675]
===
match
---
trailer [48814,48820]
trailer [50530,50536]
===
match
---
expr_stmt [15462,15821]
expr_stmt [15462,15821]
===
match
---
arglist [30680,30727]
arglist [32396,32443]
===
match
---
name: default_view [29923,29935]
name: default_view [31639,31651]
===
match
---
arith_expr [53254,53376]
arith_expr [54970,55092]
===
match
---
trailer [31143,31154]
trailer [32859,32870]
===
match
---
atom_expr [69349,69366]
atom_expr [71065,71082]
===
match
---
name: value [69128,69133]
name: value [70844,70849]
===
match
---
number: 1 [59875,59876]
number: 1 [61591,61592]
===
match
---
string: '0 3 * * *' [21666,21677]
string: '0 3 * * *' [21666,21677]
===
match
---
name: task_decorator [67103,67117]
name: task_decorator [68819,68833]
===
match
---
simple_stmt [38810,38864]
simple_stmt [40526,40580]
===
match
---
argument [42574,42598]
argument [44290,44314]
===
match
---
operator: = [56732,56733]
operator: = [58448,58449]
===
match
---
operator: = [56576,56577]
operator: = [58292,58293]
===
match
---
simple_stmt [48333,48379]
simple_stmt [50049,50095]
===
match
---
suite [37311,37725]
suite [39027,39441]
===
match
---
trailer [64402,64404]
trailer [66118,66120]
===
match
---
operator: , [52530,52531]
operator: , [54246,54247]
===
match
---
assert_stmt [64480,64503]
assert_stmt [66196,66219]
===
match
---
operator: = [66465,66466]
operator: = [68181,68182]
===
match
---
name: self [53422,53426]
name: self [55138,55142]
===
match
---
string: 'dag' [29444,29449]
string: 'dag' [31160,31165]
===
match
---
argument [40547,40573]
argument [42263,42289]
===
match
---
trailer [70447,70505]
trailer [72163,72221]
===
match
---
atom_expr [26754,26769]
atom_expr [28470,28485]
===
match
---
trailer [62389,62446]
trailer [64105,64162]
===
match
---
atom_expr [29562,29591]
atom_expr [31278,31307]
===
match
---
name: ti4 [17288,17291]
name: ti4 [17288,17291]
===
match
---
operator: = [14827,14828]
operator: = [14827,14828]
===
match
---
trailer [34109,34115]
trailer [35825,35831]
===
match
---
assert_stmt [25736,25909]
assert_stmt [27452,27625]
===
match
---
name: next_date [59835,59844]
name: next_date [61551,61560]
===
match
---
trailer [47642,47651]
trailer [49358,49367]
===
match
---
suite [15969,16085]
suite [15969,16085]
===
match
---
number: 0 [2395,2396]
number: 0 [2395,2396]
===
match
---
name: next_date [54949,54958]
name: next_date [56665,56674]
===
match
---
for_stmt [16098,16362]
for_stmt [16098,16362]
===
match
---
assert_stmt [6439,6467]
assert_stmt [6439,6467]
===
match
---
atom_expr [44492,44536]
atom_expr [46208,46252]
===
match
---
simple_stmt [2694,2710]
simple_stmt [2694,2710]
===
match
---
parameters [33358,33364]
parameters [35074,35080]
===
match
---
name: dagrun_1 [53967,53975]
name: dagrun_1 [55683,55691]
===
match
---
atom_expr [69495,69512]
atom_expr [71211,71228]
===
match
---
name: dag_id [32425,32431]
name: dag_id [34141,34147]
===
match
---
name: sync_to_db [30316,30326]
name: sync_to_db [32032,32042]
===
match
---
operator: , [47906,47907]
operator: , [49622,49623]
===
match
---
name: dag [10056,10059]
name: dag [10056,10059]
===
match
---
name: task_id [30075,30082]
name: task_id [31791,31798]
===
match
---
trailer [29485,29495]
trailer [31201,31211]
===
match
---
name: SubDagOperator [28941,28955]
name: SubDagOperator [30657,30671]
===
match
---
simple_stmt [42261,42293]
simple_stmt [43977,44009]
===
match
---
operator: = [56710,56711]
operator: = [58426,58427]
===
match
---
trailer [23345,23347]
trailer [23345,23347]
===
match
---
simple_stmt [69147,69216]
simple_stmt [70863,70932]
===
match
---
expr_stmt [65781,65842]
expr_stmt [67497,67558]
===
match
---
trailer [25658,25675]
trailer [27374,27391]
===
match
---
name: is_paused_upon_creation [32966,32989]
name: is_paused_upon_creation [34682,34705]
===
match
---
string: 'dag-bulk-sync-2' [25055,25072]
string: 'dag-bulk-sync-2' [26771,26788]
===
match
---
name: start_date [20630,20640]
name: start_date [20630,20640]
===
match
---
arglist [59668,59678]
arglist [61384,61394]
===
match
---
name: self [44127,44131]
name: self [45843,45847]
===
match
---
name: DEPRECATED_ACTION_CAN_DAG_EDIT [63199,63229]
name: DEPRECATED_ACTION_CAN_DAG_EDIT [64915,64945]
===
match
---
name: sync_to_db [31344,31354]
name: sync_to_db [33060,33070]
===
match
---
operator: , [63230,63231]
operator: , [64946,64947]
===
match
---
testlist_comp [26294,26324]
testlist_comp [28010,28040]
===
match
---
name: is_active [34560,34569]
name: is_active [36276,36285]
===
match
---
atom_expr [15076,15102]
atom_expr [15076,15102]
===
match
---
name: states [18201,18207]
name: states [18201,18207]
===
match
---
fstring_expr [14238,14241]
fstring_expr [14238,14241]
===
match
---
string: 'b_parent' [7974,7984]
string: 'b_parent' [7974,7984]
===
match
---
arglist [40170,40360]
arglist [41886,42076]
===
match
---
operator: , [34900,34901]
operator: , [36616,36617]
===
match
---
name: self [43800,43804]
name: self [45516,45520]
===
match
---
atom_expr [2543,2590]
atom_expr [2543,2590]
===
match
---
simple_stmt [22827,22863]
simple_stmt [22827,22863]
===
match
---
string: 'some_string' [19944,19957]
string: 'some_string' [19944,19957]
===
match
---
atom_expr [62430,62444]
atom_expr [64146,64160]
===
match
---
simple_stmt [2106,2149]
simple_stmt [2106,2149]
===
match
---
trailer [46036,46049]
trailer [47752,47765]
===
match
---
trailer [21502,21519]
trailer [21502,21519]
===
match
---
trailer [29258,29268]
trailer [30974,30984]
===
match
---
trailer [51863,51891]
trailer [53579,53607]
===
match
---
simple_stmt [60844,60901]
simple_stmt [62560,62617]
===
match
---
name: datetime [21485,21493]
name: datetime [21485,21493]
===
match
---
name: State [47896,47901]
name: State [49612,49617]
===
match
---
name: test_params_passed_and_params_in_default_args_no_override [3833,3890]
name: test_params_passed_and_params_in_default_args_no_override [3833,3890]
===
match
---
simple_stmt [7228,7251]
simple_stmt [7228,7251]
===
match
---
argument [44449,44466]
argument [46165,46182]
===
match
---
factor [3284,3286]
factor [3284,3286]
===
match
---
expr_stmt [40030,40077]
expr_stmt [41746,41793]
===
match
---
atom_expr [29332,29352]
atom_expr [31048,31068]
===
match
---
name: dag_run_state [49375,49388]
name: dag_run_state [51091,51104]
===
match
---
operator: , [62766,62767]
operator: , [64482,64483]
===
match
---
atom [48035,48048]
atom [49751,49764]
===
match
---
string: "2018-10-28T02:55:00+02:00" [21192,21219]
string: "2018-10-28T02:55:00+02:00" [21192,21219]
===
match
---
operator: == [30510,30512]
operator: == [32226,32228]
===
match
---
operator: , [43432,43433]
operator: , [45148,45149]
===
match
---
name: name [35110,35114]
name: name [36826,36830]
===
match
---
operator: , [48136,48137]
operator: , [49852,49853]
===
match
---
name: run [43356,43359]
name: run [45072,45075]
===
match
---
trailer [45308,45314]
trailer [47024,47030]
===
match
---
operator: = [69553,69554]
operator: = [71269,71270]
===
match
---
simple_stmt [9819,9852]
simple_stmt [9819,9852]
===
match
---
operator: { [38203,38204]
operator: { [39919,39920]
===
match
---
name: RUNNING [50675,50682]
name: RUNNING [52391,52398]
===
match
---
operator: = [34914,34915]
operator: = [36630,36631]
===
match
---
expr_stmt [53986,54062]
expr_stmt [55702,55778]
===
match
---
trailer [25872,25889]
trailer [27588,27605]
===
match
---
simple_stmt [65555,65571]
simple_stmt [67271,67287]
===
match
---
trailer [25591,25604]
trailer [27307,27320]
===
match
---
trailer [27053,27060]
trailer [28769,28776]
===
match
---
operator: @ [46328,46329]
operator: @ [48044,48045]
===
match
---
atom_expr [53288,53305]
atom_expr [55004,55021]
===
match
---
simple_stmt [2294,2355]
simple_stmt [2294,2355]
===
match
---
argument [12363,12396]
argument [12363,12396]
===
match
---
atom [65259,65268]
atom [66975,66984]
===
match
---
name: test_duplicate_task_ids_not_allowed_without_dag_context_manager [37241,37304]
name: test_duplicate_task_ids_not_allowed_without_dag_context_manager [38957,39020]
===
match
---
simple_stmt [20299,20345]
simple_stmt [20299,20345]
===
match
---
simple_stmt [56866,56995]
simple_stmt [58582,58711]
===
match
---
trailer [4635,4711]
trailer [4635,4711]
===
match
---
name: replace [56930,56937]
name: replace [58646,58653]
===
match
---
operator: < [45487,45488]
operator: < [47203,47204]
===
match
---
arglist [21503,21518]
arglist [21503,21518]
===
match
---
trailer [69151,69160]
trailer [70867,70876]
===
match
---
trailer [50784,50786]
trailer [52500,52502]
===
match
---
trailer [63388,63404]
trailer [65104,65120]
===
match
---
with_stmt [19764,19897]
with_stmt [19764,19897]
===
match
---
trailer [3421,3429]
trailer [3421,3429]
===
match
---
simple_stmt [67648,67676]
simple_stmt [69364,69392]
===
match
---
name: end_date [54233,54241]
name: end_date [55949,55957]
===
match
---
string: 'test-dag' [18572,18582]
string: 'test-dag' [18572,18582]
===
match
---
string: '@once' [42285,42292]
string: '@once' [44001,44008]
===
match
---
trailer [41552,41554]
trailer [43268,43270]
===
match
---
operator: = [4246,4247]
operator: = [4246,4247]
===
match
---
operator: { [66232,66233]
operator: { [67948,67949]
===
match
---
name: execution_date [70305,70319]
name: execution_date [72021,72035]
===
match
---
expr_stmt [20353,20451]
expr_stmt [20353,20451]
===
match
---
name: DEFAULT_DATE [65829,65841]
name: DEFAULT_DATE [67545,67557]
===
match
---
name: test_dag [16813,16821]
name: test_dag [16813,16821]
===
match
---
comparison [13166,13172]
comparison [13166,13172]
===
match
---
trailer [62644,62654]
trailer [64360,64370]
===
match
---
for_stmt [14769,15162]
for_stmt [14769,15162]
===
match
---
simple_stmt [8109,8178]
simple_stmt [8109,8178]
===
match
---
name: task_id [43243,43250]
name: task_id [44959,44966]
===
match
---
argument [37515,37538]
argument [39231,39254]
===
match
---
name: DummyOperator [7952,7965]
name: DummyOperator [7952,7965]
===
match
---
name: DAG [30876,30879]
name: DAG [32592,32595]
===
match
---
trailer [10176,10179]
trailer [10176,10179]
===
match
---
name: session [25230,25237]
name: session [26946,26953]
===
match
---
name: prev_local [22176,22186]
name: prev_local [22176,22186]
===
match
---
operator: , [47470,47471]
operator: , [49186,49187]
===
match
---
argument [15649,15680]
argument [15649,15680]
===
match
---
name: include_parentdag [49011,49028]
name: include_parentdag [50727,50744]
===
match
---
name: settings [29024,29032]
name: settings [30740,30748]
===
match
---
name: dag_run [40644,40651]
name: dag_run [42360,42367]
===
match
---
trailer [42542,42620]
trailer [44258,44336]
===
match
---
operator: , [60322,60323]
operator: , [62038,62039]
===
match
---
assert_stmt [36644,36674]
assert_stmt [38360,38390]
===
match
---
operator: = [64155,64156]
operator: = [65871,65872]
===
match
---
suite [38368,38553]
suite [40084,40269]
===
match
---
name: merge [52653,52658]
name: merge [54369,54374]
===
match
---
trailer [45275,45280]
trailer [46991,46996]
===
match
---
name: _next [23911,23916]
name: _next [23911,23916]
===
match
---
suite [40904,41975]
suite [42620,43691]
===
match
---
name: assert_queries_count [65969,65989]
name: assert_queries_count [67685,67705]
===
match
---
param [53428,53443]
param [55144,55159]
===
match
---
trailer [21578,21593]
trailer [21578,21593]
===
match
---
name: flush [18995,19000]
name: flush [18995,19000]
===
match
---
name: start_date [24165,24175]
name: start_date [25881,25891]
===
match
---
argument [35985,35997]
argument [37701,37713]
===
match
---
atom_expr [10087,10117]
atom_expr [10087,10117]
===
match
---
atom_expr [4470,4480]
atom_expr [4470,4480]
===
match
---
name: dag_models [64487,64497]
name: dag_models [66203,66213]
===
match
---
atom_expr [9900,9923]
atom_expr [9900,9923]
===
match
---
name: start_date [59639,59649]
name: start_date [61355,61365]
===
match
---
argument [49011,49034]
argument [50727,50750]
===
match
---
name: schedule_interval [55542,55559]
name: schedule_interval [57258,57275]
===
match
---
atom [46474,46499]
atom [48190,48215]
===
match
---
operator: , [61197,61198]
operator: , [62913,62914]
===
match
---
simple_stmt [64830,64859]
simple_stmt [66546,66575]
===
match
---
name: re [13997,13999]
name: re [13997,13999]
===
match
---
name: dag_id [41650,41656]
name: dag_id [43366,43372]
===
match
---
operator: , [8571,8572]
operator: , [8571,8572]
===
match
---
name: test_create_dagrun_run_type_is_obtained_from_run_id [47299,47350]
name: test_create_dagrun_run_type_is_obtained_from_run_id [49015,49066]
===
match
---
atom_expr [47432,47489]
atom_expr [49148,49205]
===
match
---
string: 'no rule' [16661,16670]
string: 'no rule' [16661,16670]
===
match
---
simple_stmt [43627,43709]
simple_stmt [45343,45425]
===
match
---
atom_expr [35044,35081]
atom_expr [36760,36797]
===
match
---
atom_expr [13491,13510]
atom_expr [13491,13510]
===
match
---
atom_expr [35787,35814]
atom_expr [37503,37530]
===
match
---
name: dag_id [30847,30853]
name: dag_id [32563,32569]
===
match
---
assert_stmt [20108,20161]
assert_stmt [20108,20161]
===
match
---
string: 'owner1' [14102,14110]
string: 'owner1' [14102,14110]
===
match
---
argument [47088,47116]
argument [48804,48832]
===
match
---
name: self [8269,8273]
name: self [8269,8273]
===
match
---
trailer [64371,64380]
trailer [66087,66096]
===
match
---
trailer [45843,45848]
trailer [47559,47564]
===
match
---
name: ACTION_CAN_READ [63074,63089]
name: ACTION_CAN_READ [64790,64805]
===
match
---
name: orm_dag [33639,33646]
name: orm_dag [35355,35362]
===
match
---
expr_stmt [49577,49622]
expr_stmt [51293,51338]
===
match
---
atom_expr [9037,9067]
atom_expr [9037,9067]
===
match
---
arglist [17173,17245]
arglist [17173,17245]
===
match
---
name: pickle [45296,45302]
name: pickle [47012,47018]
===
match
---
operator: == [46925,46927]
operator: == [48641,48643]
===
match
---
trailer [22142,22160]
trailer [22142,22160]
===
match
---
operator: , [30689,30690]
operator: , [32405,32406]
===
match
---
name: settings [53705,53713]
name: settings [55421,55429]
===
match
---
trailer [49821,49883]
trailer [51537,51599]
===
match
---
simple_stmt [13194,13203]
simple_stmt [13194,13203]
===
match
---
atom_expr [57999,58016]
atom_expr [59715,59732]
===
match
---
operator: , [50906,50907]
operator: , [52622,52623]
===
match
---
name: weight [13653,13659]
name: weight [13653,13659]
===
match
---
simple_stmt [55879,55903]
simple_stmt [57595,57619]
===
match
---
assert_stmt [44861,44878]
assert_stmt [46577,46594]
===
match
---
atom_expr [65278,65295]
atom_expr [66994,67011]
===
match
---
name: execution_date [50413,50427]
name: execution_date [52129,52143]
===
match
---
name: dag_id [60680,60686]
name: dag_id [62396,62402]
===
match
---
suite [65517,66168]
suite [67233,67884]
===
match
---
atom_expr [47756,47802]
atom_expr [49472,49518]
===
match
---
expr_stmt [57003,57058]
expr_stmt [58719,58774]
===
match
---
name: session [17450,17457]
name: session [17450,17457]
===
match
---
name: prev [22857,22861]
name: prev [22857,22861]
===
match
---
funcdef [61618,62066]
funcdef [63334,63782]
===
match
---
name: re [860,862]
name: re [860,862]
===
match
---
operator: , [49482,49483]
operator: , [51198,51199]
===
match
---
comparison [19454,19483]
comparison [19454,19483]
===
match
---
simple_stmt [33082,33171]
simple_stmt [34798,34887]
===
match
---
operator: = [40481,40482]
operator: = [42197,42198]
===
match
---
name: isoformat [23917,23926]
name: isoformat [23917,23926]
===
match
---
name: settings [12429,12437]
name: settings [12429,12437]
===
match
---
dictorsetmaker [63062,63118]
dictorsetmaker [64778,64834]
===
match
---
name: ACTION_CAN_READ [63308,63323]
name: ACTION_CAN_READ [65024,65039]
===
match
---
name: logging [821,828]
name: logging [821,828]
===
match
---
atom [26878,26910]
atom [28594,28626]
===
match
---
expr_stmt [55714,55725]
expr_stmt [57430,57441]
===
match
---
trailer [4419,4426]
trailer [4419,4426]
===
match
---
trailer [49974,50002]
trailer [51690,51718]
===
match
---
atom_expr [33380,33396]
atom_expr [35096,35112]
===
match
---
trailer [51187,51194]
trailer [52903,52910]
===
match
---
number: 1 [54986,54987]
number: 1 [56702,56703]
===
match
---
suite [67554,67582]
suite [69270,69298]
===
match
---
atom_expr [65126,65146]
atom_expr [66842,66862]
===
match
---
name: warns [63467,63472]
name: warns [65183,65188]
===
match
---
trailer [27750,27765]
trailer [29466,29481]
===
match
---
trailer [3773,3780]
trailer [3773,3780]
===
match
---
trailer [19000,19002]
trailer [19000,19002]
===
match
---
arglist [8212,8252]
arglist [8212,8252]
===
match
---
with_stmt [30746,30838]
with_stmt [32462,32554]
===
match
---
simple_stmt [51900,51924]
simple_stmt [53616,53640]
===
match
---
name: self [65589,65593]
name: self [67305,67309]
===
match
---
name: dr [47640,47642]
name: dr [49356,49358]
===
match
---
name: dag [28240,28243]
name: dag [29956,29959]
===
match
---
operator: = [48396,48397]
operator: = [50112,50113]
===
match
---
name: test_task [17178,17187]
name: test_task [17178,17187]
===
match
---
simple_stmt [44546,44605]
simple_stmt [46262,46321]
===
match
---
assert_stmt [9281,9316]
assert_stmt [9281,9316]
===
match
---
atom [63272,63445]
atom [64988,65161]
===
match
---
argument [70384,70409]
argument [72100,72125]
===
match
---
argument [8073,8098]
argument [8073,8098]
===
match
---
string: '2019-06-05T00:00:00' [11683,11704]
string: '2019-06-05T00:00:00' [11683,11704]
===
match
---
trailer [69978,69995]
trailer [71694,71711]
===
match
---
trailer [70289,70291]
trailer [72005,72007]
===
match
---
operator: , [60769,60770]
operator: , [62485,62486]
===
match
---
trailer [31514,31518]
trailer [33230,33234]
===
match
---
name: start_date [21630,21640]
name: start_date [21630,21640]
===
match
---
arglist [10788,10836]
arglist [10788,10836]
===
match
---
string: 'parent_dag.child_dag' [7351,7373]
string: 'parent_dag.child_dag' [7351,7373]
===
match
---
suite [69920,69948]
suite [71636,71664]
===
match
---
trailer [45707,45712]
trailer [47423,47428]
===
match
---
atom [5966,5985]
atom [5966,5985]
===
match
---
number: 1 [50904,50905]
number: 1 [52620,52621]
===
match
---
name: task_id [48240,48247]
name: task_id [49956,49963]
===
match
---
name: DAG [18132,18135]
name: DAG [18132,18135]
===
match
---
name: dag [6283,6286]
name: dag [6283,6286]
===
match
---
argument [40268,40297]
argument [41984,42013]
===
match
---
funcdef [27201,28447]
funcdef [28917,30163]
===
match
---
comparison [7205,7219]
comparison [7205,7219]
===
match
---
arglist [8135,8176]
arglist [8135,8176]
===
match
---
arglist [60858,60899]
arglist [62574,62615]
===
match
---
trailer [20318,20327]
trailer [20318,20327]
===
match
---
operator: == [58370,58372]
operator: == [60086,60088]
===
match
---
operator: = [7565,7566]
operator: = [7565,7566]
===
match
---
parameters [61441,61447]
parameters [63157,63163]
===
match
---
atom_expr [12429,12446]
atom_expr [12429,12446]
===
match
---
trailer [22532,22549]
trailer [22532,22549]
===
match
---
argument [40705,40717]
argument [42421,42433]
===
match
---
name: state [53256,53261]
name: state [54972,54977]
===
match
---
name: datetime [62160,62168]
name: datetime [63876,63884]
===
match
---
name: catchup [57304,57311]
name: catchup [59020,59027]
===
match
---
simple_stmt [65892,65956]
simple_stmt [67608,67672]
===
match
---
comparison [3803,3823]
comparison [3803,3823]
===
match
---
simple_stmt [51698,51773]
simple_stmt [53414,53489]
===
match
---
trailer [9973,9986]
trailer [9973,9986]
===
match
---
name: bulk_write_to_db [25417,25433]
name: bulk_write_to_db [27133,27149]
===
match
---
number: 0 [9183,9184]
number: 0 [9183,9184]
===
match
---
operator: == [20804,20806]
operator: == [20804,20806]
===
match
---
simple_stmt [63754,63803]
simple_stmt [65470,65519]
===
match
---
atom_expr [66006,66167]
atom_expr [67722,67883]
===
match
---
name: create_dagrun [53763,53776]
name: create_dagrun [55479,55492]
===
match
---
string: "2018-10-28T02:55:00+02:00" [20488,20515]
string: "2018-10-28T02:55:00+02:00" [20488,20515]
===
match
---
name: timezone [58417,58425]
name: timezone [60133,60141]
===
match
---
param [5120,5124]
param [5120,5124]
===
match
---
simple_stmt [66006,66168]
simple_stmt [67722,67884]
===
match
---
name: DAG [17687,17690]
name: DAG [17687,17690]
===
match
---
string: 'dag.subtask' [29522,29535]
string: 'dag.subtask' [31238,31251]
===
match
---
dotted_name [1898,1916]
dotted_name [1898,1916]
===
match
---
name: topological_list [9252,9268]
name: topological_list [9252,9268]
===
match
---
trailer [17690,17713]
trailer [17690,17713]
===
match
---
atom_expr [50492,50515]
atom_expr [52208,52231]
===
match
---
name: dag_id [2990,2996]
name: dag_id [2990,2996]
===
match
---
name: params_combined [4363,4378]
name: params_combined [4363,4378]
===
match
---
operator: = [35488,35489]
operator: = [37204,37205]
===
match
---
name: close [29783,29788]
name: close [31499,31504]
===
match
---
name: row [25301,25304]
name: row [27017,27020]
===
match
---
name: op1 [56618,56621]
name: op1 [58334,58337]
===
match
---
name: DummyOperator [14184,14197]
name: DummyOperator [14184,14197]
===
match
---
simple_stmt [68113,68135]
simple_stmt [69829,69851]
===
match
---
name: RUNNING [18221,18228]
name: RUNNING [18221,18228]
===
match
---
string: """         Assert that a occurs before b in the list.         """ [3199,3265]
string: """         Assert that a occurs before b in the list.         """ [3199,3265]
===
match
---
operator: } [63444,63445]
operator: } [65160,65161]
===
match
---
string: 'dummy' [60866,60873]
string: 'dummy' [62582,62589]
===
match
---
name: task_id [28608,28615]
name: task_id [30324,30331]
===
match
---
simple_stmt [7499,7532]
simple_stmt [7499,7532]
===
match
---
name: local_tz [23062,23070]
name: local_tz [23062,23070]
===
match
---
name: op3 [6446,6449]
name: op3 [6446,6449]
===
match
---
atom_expr [61963,62034]
atom_expr [63679,63750]
===
match
---
operator: , [26680,26681]
operator: , [28396,28397]
===
match
---
trailer [5652,5664]
trailer [5652,5664]
===
match
---
trailer [63942,63951]
trailer [65658,65667]
===
match
---
operator: , [52145,52146]
operator: , [53861,53862]
===
match
---
argument [38493,38505]
argument [40209,40221]
===
match
---
expr_stmt [52477,52552]
expr_stmt [54193,54268]
===
match
---
name: self [41952,41956]
name: self [43668,43672]
===
match
---
trailer [17017,17023]
trailer [17017,17023]
===
match
---
operator: = [56765,56766]
operator: = [58481,58482]
===
match
---
operator: , [27010,27011]
operator: , [28726,28727]
===
match
---
atom_expr [53046,53162]
atom_expr [54762,54878]
===
match
---
name: one [51209,51212]
name: one [52925,52928]
===
match
---
string: 'DAG' [11959,11964]
string: 'DAG' [11959,11964]
===
match
---
string: 'test' [67021,67027]
string: 'test' [68737,68743]
===
match
---
return_stmt [70883,70893]
return_stmt [72599,72609]
===
match
---
name: utc [21564,21567]
name: utc [21564,21567]
===
match
---
operator: } [24441,24442]
operator: } [26157,26158]
===
match
---
suite [13146,13361]
suite [13146,13361]
===
match
---
parameters [28471,28477]
parameters [30187,30193]
===
match
---
funcdef [68273,68794]
funcdef [69989,70510]
===
match
---
atom_expr [49108,49255]
atom_expr [50824,50971]
===
match
---
name: template_dir [19659,19671]
name: template_dir [19659,19671]
===
match
---
name: dag_fileloc [34043,34054]
name: dag_fileloc [35759,35770]
===
match
---
name: topological_list [9202,9218]
name: topological_list [9202,9218]
===
match
---
operator: = [63564,63565]
operator: = [65280,65281]
===
match
---
atom_expr [45728,45740]
atom_expr [47444,47456]
===
match
---
atom_expr [64389,64404]
atom_expr [66105,66120]
===
match
---
operator: = [34220,34221]
operator: = [35936,35937]
===
match
---
shift_expr [36389,36406]
shift_expr [38105,38122]
===
match
---
testlist_comp [53256,53273]
testlist_comp [54972,54989]
===
match
---
name: run_id [47450,47456]
name: run_id [49166,49172]
===
match
---
atom_expr [39433,39447]
atom_expr [41149,41163]
===
match
---
operator: , [20054,20055]
operator: , [20054,20055]
===
match
---
string: 'test-dag2' [26214,26225]
string: 'test-dag2' [27930,27941]
===
match
---
name: is_paused_upon_creation [45958,45981]
name: is_paused_upon_creation [47674,47697]
===
match
---
simple_stmt [32120,32184]
simple_stmt [33836,33900]
===
match
---
name: dag [35097,35100]
name: dag [36813,36816]
===
match
---
simple_stmt [2009,2047]
simple_stmt [2009,2047]
===
match
---
trailer [39545,39560]
trailer [41261,41276]
===
match
---
name: test_dag_id [44142,44153]
name: test_dag_id [45858,45869]
===
match
---
argument [46839,46874]
argument [48555,48590]
===
match
---
name: dag_id [57589,57595]
name: dag_id [59305,59311]
===
match
---
operator: = [22513,22514]
operator: = [22513,22514]
===
match
---
arglist [40644,40666]
arglist [42360,42382]
===
match
---
string: 'D' [9802,9805]
string: 'D' [9802,9805]
===
match
---
operator: = [37525,37526]
operator: = [39241,39242]
===
match
---
name: owner [43265,43270]
name: owner [44981,44986]
===
match
---
name: default_view [29292,29304]
name: default_view [31008,31020]
===
match
---
operator: == [19470,19472]
operator: == [19470,19472]
===
match
---
atom_expr [35306,35333]
atom_expr [37022,37049]
===
match
---
name: dag_id [2898,2904]
name: dag_id [2898,2904]
===
match
---
atom_expr [17477,17495]
atom_expr [17477,17495]
===
match
---
operator: = [23011,23012]
operator: = [23011,23012]
===
match
---
name: dag_run_state [52876,52889]
name: dag_run_state [54592,54605]
===
match
---
atom_expr [16475,16544]
atom_expr [16475,16544]
===
match
---
atom_expr [34631,34691]
atom_expr [36347,36407]
===
match
---
operator: , [64157,64158]
operator: , [65873,65874]
===
match
---
suite [20210,21247]
suite [20210,21247]
===
match
---
atom [46399,46422]
atom [48115,48138]
===
match
---
name: datetime [17219,17227]
name: datetime [17219,17227]
===
match
---
funcdef [66550,66621]
funcdef [68266,68337]
===
match
---
operator: , [66290,66291]
operator: , [68006,68007]
===
match
---
name: model [41823,41828]
name: model [43539,43544]
===
match
---
fstring_expr [14242,14245]
fstring_expr [14242,14245]
===
match
---
trailer [31737,31751]
trailer [33453,33467]
===
match
---
atom_expr [40086,40126]
atom_expr [41802,41842]
===
match
---
operator: , [64305,64306]
operator: , [66021,66022]
===
match
---
simple_stmt [58934,58979]
simple_stmt [60650,60695]
===
match
---
operator: + [44508,44509]
operator: + [46224,46225]
===
match
---
atom_expr [2414,2431]
atom_expr [2414,2431]
===
match
---
operator: { [15567,15568]
operator: { [15567,15568]
===
match
---
name: safe_dag_id [29679,29690]
name: safe_dag_id [31395,31406]
===
match
---
simple_stmt [14988,15039]
simple_stmt [14988,15039]
===
match
---
name: topological_list [10382,10398]
name: topological_list [10382,10398]
===
match
---
name: orm_dag [34212,34219]
name: orm_dag [35928,35935]
===
match
---
decorated [46328,47015]
decorated [48044,48731]
===
match
---
name: dag_id [41174,41180]
name: dag_id [42890,42896]
===
match
---
return_stmt [69937,69947]
return_stmt [71653,71663]
===
match
---
name: airflow [1435,1442]
name: airflow [1435,1442]
===
match
---
comparison [29332,29405]
comparison [31048,31121]
===
match
---
simple_stmt [5005,5082]
simple_stmt [5005,5082]
===
match
---
name: settings [64840,64848]
name: settings [66556,66564]
===
match
---
name: dag [40404,40407]
name: dag [42120,42123]
===
match
---
name: self [8420,8424]
name: self [8420,8424]
===
match
---
name: op3 [9919,9922]
name: op3 [9919,9922]
===
match
---
name: stdout_lines [36555,36567]
name: stdout_lines [38271,38283]
===
match
---
dotted_name [1627,1650]
dotted_name [1627,1650]
===
match
---
name: topological_list [9116,9132]
name: topological_list [9116,9132]
===
match
---
name: datetime [59974,59982]
name: datetime [61690,61698]
===
match
---
operator: = [53030,53031]
operator: = [54746,54747]
===
match
---
trailer [10615,10681]
trailer [10615,10681]
===
match
---
atom_expr [22948,22964]
atom_expr [22948,22964]
===
match
---
assert_stmt [7198,7219]
assert_stmt [7198,7219]
===
match
---
name: subdag_id [31939,31948]
name: subdag_id [33655,33664]
===
match
---
name: State [52096,52101]
name: State [53812,53817]
===
match
---
name: DummyOperator [9645,9658]
name: DummyOperator [9645,9658]
===
match
---
operator: , [51331,51332]
operator: , [53047,53048]
===
match
---
trailer [17382,17388]
trailer [17382,17388]
===
match
---
operator: = [34004,34005]
operator: = [35720,35721]
===
match
---
trailer [35100,35109]
trailer [36816,36825]
===
match
---
trailer [18675,18692]
trailer [18675,18692]
===
match
---
name: DEFAULT_DATE [16859,16871]
name: DEFAULT_DATE [16859,16871]
===
match
---
name: pendulum [20427,20435]
name: pendulum [20427,20435]
===
match
---
name: subdag [28998,29004]
name: subdag [30714,30720]
===
match
---
operator: = [17242,17243]
operator: = [17242,17243]
===
match
---
suite [68548,68576]
suite [70264,70292]
===
match
---
arith_expr [48880,48921]
arith_expr [50596,50637]
===
match
---
atom_expr [39403,39417]
atom_expr [41119,41133]
===
match
---
argument [64778,64793]
argument [66494,66509]
===
match
---
expr_stmt [44142,44182]
expr_stmt [45858,45898]
===
match
---
operator: = [48248,48249]
operator: = [49964,49965]
===
match
---
trailer [17102,17112]
trailer [17102,17112]
===
match
---
argument [32168,32182]
argument [33884,33898]
===
match
---
operator: , [67265,67266]
operator: , [68981,68982]
===
match
---
name: start_date [30703,30713]
name: start_date [32419,32429]
===
match
---
string: 'owner2' [30116,30124]
string: 'owner2' [31832,31840]
===
match
---
expr_stmt [56728,56770]
expr_stmt [58444,58486]
===
match
---
operator: , [41450,41451]
operator: , [43166,43167]
===
match
---
atom_expr [66097,66110]
atom_expr [67813,67826]
===
match
---
trailer [10398,10401]
trailer [10398,10401]
===
match
---
string: 'test_clear_dag' [53491,53507]
string: 'test_clear_dag' [55207,55223]
===
match
---
operator: = [16274,16275]
operator: = [16274,16275]
===
match
---
trailer [53847,53855]
trailer [55563,55571]
===
match
---
operator: == [45700,45702]
operator: == [47416,47418]
===
match
---
fstring_string: . [61802,61803]
fstring_string: . [63518,63519]
===
match
---
argument [58102,58127]
argument [59818,59843]
===
match
---
operator: = [38454,38455]
operator: = [40170,40171]
===
match
---
name: op3 [10023,10026]
name: op3 [10023,10026]
===
match
---
trailer [22899,22901]
trailer [22899,22901]
===
match
---
name: DagModel [46028,46036]
name: DagModel [47744,47752]
===
match
---
simple_stmt [10606,10682]
simple_stmt [10606,10682]
===
match
---
name: DEFAULT_DATE [50180,50192]
name: DEFAULT_DATE [51896,51908]
===
match
---
atom_expr [10612,10681]
atom_expr [10612,10681]
===
match
---
name: pattern [14829,14836]
name: pattern [14829,14836]
===
match
---
name: _clean_up [2774,2783]
name: _clean_up [2774,2783]
===
match
---
operator: = [61753,61754]
operator: = [63469,63470]
===
match
---
operator: { [61803,61804]
operator: { [63519,63520]
===
match
---
simple_stmt [28487,28564]
simple_stmt [30203,30280]
===
match
---
name: dag_run_state [51256,51269]
name: dag_run_state [52972,52985]
===
match
---
operator: } [24318,24319]
operator: } [26034,26035]
===
match
---
name: dag [6628,6631]
name: dag [6628,6631]
===
match
---
operator: = [52095,52096]
operator: = [53811,53812]
===
match
---
argument [55500,55521]
argument [57216,57237]
===
match
---
name: access_control [63765,63779]
name: access_control [65481,65495]
===
match
---
trailer [34526,34530]
trailer [36242,36246]
===
match
---
operator: , [61899,61900]
operator: , [63615,63616]
===
match
---
simple_stmt [68589,68607]
simple_stmt [70305,70323]
===
match
---
name: op1 [8915,8918]
name: op1 [8915,8918]
===
match
---
expr_stmt [23697,23746]
expr_stmt [23697,23746]
===
match
---
atom_expr [3075,3090]
atom_expr [3075,3090]
===
match
---
atom_expr [61217,61273]
atom_expr [62933,62989]
===
match
---
testlist_comp [15491,15807]
testlist_comp [15491,15807]
===
match
---
trailer [29132,29158]
trailer [30848,30874]
===
match
---
name: dag [56388,56391]
name: dag [58104,58107]
===
match
---
operator: , [54987,54988]
operator: , [56703,56704]
===
match
---
operator: = [64957,64958]
operator: = [66673,66674]
===
match
---
number: 1 [3285,3286]
number: 1 [3285,3286]
===
match
---
atom_expr [38001,38028]
atom_expr [39717,39744]
===
match
---
simple_stmt [29844,29955]
simple_stmt [31560,31671]
===
match
---
simple_stmt [21952,21989]
simple_stmt [21952,21989]
===
match
---
trailer [24605,24611]
trailer [26321,26327]
===
match
---
name: DagModel [34375,34383]
name: DagModel [36091,36099]
===
match
---
trailer [29360,29364]
trailer [31076,31080]
===
match
---
fstring [14231,14246]
fstring [14231,14246]
===
match
---
trailer [23239,23257]
trailer [23239,23257]
===
match
---
name: template_dir [19186,19198]
name: template_dir [19186,19198]
===
match
---
name: get_is_paused [32856,32869]
name: get_is_paused [34572,34585]
===
match
---
name: dag [33938,33941]
name: dag [35654,35657]
===
match
---
name: isinstance [68150,68160]
name: isinstance [69866,69876]
===
match
---
simple_stmt [20022,20057]
simple_stmt [20022,20057]
===
match
---
name: DummyOperator [16893,16906]
name: DummyOperator [16893,16906]
===
match
---
expr_stmt [9684,9716]
expr_stmt [9684,9716]
===
match
---
atom_expr [59222,59251]
atom_expr [60938,60967]
===
match
---
name: airflow [1948,1955]
name: airflow [1948,1955]
===
match
---
simple_stmt [36803,36858]
simple_stmt [38519,38574]
===
match
---
operator: { [14242,14243]
operator: { [14242,14243]
===
match
---
operator: = [12350,12351]
operator: = [12350,12351]
===
match
---
name: weight [12543,12549]
name: weight [12543,12549]
===
match
---
simple_stmt [20219,20291]
simple_stmt [20219,20291]
===
match
---
name: next_date [61343,61352]
name: next_date [63059,63068]
===
match
---
name: where [34659,34664]
name: where [36375,36380]
===
match
---
name: next_date [61283,61292]
name: next_date [62999,63008]
===
match
---
operator: = [55719,55720]
operator: = [57435,57436]
===
match
---
string: 'end_date' [10954,10964]
string: 'end_date' [10954,10964]
===
match
---
expr_stmt [51844,51891]
expr_stmt [53560,53607]
===
match
---
number: 1 [66352,66353]
number: 1 [68068,68069]
===
match
---
name: next_dagrun_after_date [58950,58972]
name: next_dagrun_after_date [60666,60688]
===
match
---
trailer [14784,14794]
trailer [14784,14794]
===
match
---
name: test_dag_id [44650,44661]
name: test_dag_id [46366,46377]
===
match
---
name: Session [33023,33030]
name: Session [34739,34746]
===
match
---
suite [69004,69216]
suite [70720,70932]
===
match
---
name: path [19677,19681]
name: path [19677,19681]
===
match
---
name: State [50350,50355]
name: State [52066,52071]
===
match
---
name: create_dagrun [48440,48453]
name: create_dagrun [50156,50169]
===
match
---
name: str [53467,53470]
name: str [55183,55186]
===
match
---
funcdef [32506,32872]
funcdef [34222,34588]
===
match
---
name: DAG [35044,35047]
name: DAG [36760,36763]
===
match
---
operator: , [1991,1992]
operator: , [1991,1992]
===
match
---
argument [40653,40666]
argument [42369,42382]
===
match
---
operator: @ [51275,51276]
operator: @ [52991,52992]
===
match
---
argument [17173,17187]
argument [17173,17187]
===
match
---
name: ti_state_end [54647,54659]
name: ti_state_end [56363,56375]
===
match
---
argument [51617,51634]
argument [53333,53350]
===
match
---
funcdef [43828,44093]
funcdef [45544,45809]
===
match
---
expr_stmt [27612,27640]
expr_stmt [29328,29356]
===
match
---
name: DAG [6002,6005]
name: DAG [6002,6005]
===
match
---
assert_stmt [47232,47289]
assert_stmt [48948,49005]
===
match
---
name: state [54041,54046]
name: state [55757,55762]
===
match
---
name: sync_to_db [32730,32740]
name: sync_to_db [34446,34456]
===
match
---
expr_stmt [48662,48737]
expr_stmt [50378,50453]
===
match
---
string: 'dag-bulk-sync-0' [24753,24770]
string: 'dag-bulk-sync-0' [26469,26486]
===
match
---
operator: , [6184,6185]
operator: , [6184,6185]
===
match
---
argument [65818,65841]
argument [67534,67557]
===
match
---
name: State [53288,53293]
name: State [55004,55009]
===
match
---
testlist_comp [51321,51332]
testlist_comp [53037,53048]
===
match
---
comp_op [27184,27190]
comp_op [28900,28906]
===
match
---
argument [68422,68452]
argument [70138,70168]
===
match
---
name: subdag [51819,51825]
name: subdag [53535,53541]
===
match
---
assert_stmt [9195,9230]
assert_stmt [9195,9230]
===
match
---
number: 3 [55327,55328]
number: 3 [57043,57044]
===
match
---
simple_stmt [58225,58271]
simple_stmt [59941,59987]
===
match
---
operator: } [9525,9526]
operator: } [9525,9526]
===
match
---
string: 'Europe/Zurich' [21435,21450]
string: 'Europe/Zurich' [21435,21450]
===
match
---
number: 3 [60109,60110]
number: 3 [61825,61826]
===
match
---
operator: = [70792,70793]
operator: = [72508,72509]
===
match
---
atom [10134,10144]
atom [10134,10144]
===
match
---
atom_expr [26536,26562]
atom_expr [28252,28278]
===
match
---
name: dag_id [32318,32324]
name: dag_id [34034,34040]
===
match
---
trailer [3108,3135]
trailer [3108,3135]
===
match
---
argument [42424,42444]
argument [44140,44160]
===
match
---
atom_expr [38715,38726]
atom_expr [40431,40442]
===
match
---
trailer [59024,59036]
trailer [60740,60752]
===
match
---
operator: = [40176,40177]
operator: = [41892,41893]
===
match
---
argument [4772,4794]
argument [4772,4794]
===
match
---
trailer [70491,70504]
trailer [72207,72220]
===
match
---
trailer [65197,65218]
trailer [66913,66934]
===
match
---
arith_expr [13611,13649]
arith_expr [13611,13649]
===
match
---
fstring_expr [18538,18544]
fstring_expr [18538,18544]
===
match
---
trailer [50355,50362]
trailer [52071,52078]
===
match
---
name: bulk_write_to_db [27673,27689]
name: bulk_write_to_db [29389,29405]
===
match
---
trailer [23176,23186]
trailer [23176,23186]
===
match
---
name: DEFAULT_DATE [5939,5951]
name: DEFAULT_DATE [5939,5951]
===
match
---
name: session [18086,18093]
name: session [18086,18093]
===
match
---
trailer [58434,58446]
trailer [60150,60162]
===
match
---
name: correct_weight [14988,15002]
name: correct_weight [14988,15002]
===
match
---
assert_stmt [58353,58398]
assert_stmt [60069,60114]
===
match
---
trailer [20073,20096]
trailer [20073,20096]
===
match
---
comparison [45603,45622]
comparison [47319,47338]
===
match
---
operator: = [52380,52381]
operator: = [54096,54097]
===
match
---
atom_expr [67042,67059]
atom_expr [68758,68775]
===
match
---
trailer [30402,30409]
trailer [32118,32125]
===
match
---
name: DAG [3727,3730]
name: DAG [3727,3730]
===
match
---
name: dag [64701,64704]
name: dag [66417,66420]
===
match
---
operator: , [64340,64341]
operator: , [66056,66057]
===
match
---
atom [19994,20009]
atom [19994,20009]
===
match
---
simple_stmt [17164,17247]
simple_stmt [17164,17247]
===
match
---
testlist_comp [18209,18228]
testlist_comp [18209,18228]
===
match
---
trailer [51583,51635]
trailer [53299,53351]
===
match
---
name: tasks [9311,9316]
name: tasks [9311,9316]
===
match
---
name: default_args [35055,35067]
name: default_args [36771,36783]
===
match
---
decorated [70818,70894]
decorated [72534,72610]
===
match
---
expr_stmt [16881,16942]
expr_stmt [16881,16942]
===
match
---
simple_stmt [46885,46957]
simple_stmt [48601,48673]
===
match
---
simple_stmt [62852,62946]
simple_stmt [64568,64662]
===
match
---
atom_expr [44366,44401]
atom_expr [46082,46117]
===
match
---
operator: = [46647,46648]
operator: = [48363,48364]
===
match
---
string: "/usr/local/airflow/dags/non_existing_path.py" [33883,33929]
string: "/usr/local/airflow/dags/non_existing_path.py" [35599,35645]
===
match
---
trailer [32652,32654]
trailer [34368,34370]
===
match
---
name: i [13166,13167]
name: i [13166,13167]
===
match
---
expr_stmt [50012,50040]
expr_stmt [51728,51756]
===
match
---
name: task_decorator [68002,68016]
name: task_decorator [69718,69732]
===
match
---
name: DAG [19769,19772]
name: DAG [19769,19772]
===
match
---
atom_expr [40153,40370]
atom_expr [41869,42086]
===
match
---
name: DAG [12089,12092]
name: DAG [12089,12092]
===
match
---
operator: { [63142,63143]
operator: { [64858,64859]
===
match
---
with_stmt [26494,26563]
with_stmt [28210,28279]
===
match
---
name: os [19082,19084]
name: os [19082,19084]
===
match
---
trailer [66778,66780]
trailer [68494,68496]
===
match
---
operator: = [9801,9802]
operator: = [9801,9802]
===
match
---
atom_expr [35586,35595]
atom_expr [37302,37311]
===
match
---
trailer [36877,36884]
trailer [38593,38600]
===
match
---
atom [53032,53172]
atom [54748,54888]
===
match
---
name: add_task [41251,41259]
name: add_task [42967,42975]
===
match
---
simple_stmt [10196,10229]
simple_stmt [10196,10229]
===
match
---
atom_expr [26499,26522]
atom_expr [28215,28238]
===
match
---
name: subdag [31019,31025]
name: subdag [32735,32741]
===
match
---
argument [7682,7705]
argument [7682,7705]
===
match
---
operator: , [70337,70338]
operator: , [72053,72054]
===
match
---
operator: = [30148,30149]
operator: = [31864,31865]
===
match
---
name: task_id [7121,7128]
name: task_id [7121,7128]
===
match
---
atom_expr [9970,9991]
atom_expr [9970,9991]
===
match
---
name: timedelta [46633,46642]
name: timedelta [48349,48358]
===
match
---
name: TI [50542,50544]
name: TI [52258,52260]
===
match
---
name: self [10886,10890]
name: self [10886,10890]
===
match
---
arglist [25171,25197]
arglist [26887,26913]
===
match
---
import_from [2149,2197]
import_from [2149,2197]
===
match
---
trailer [8134,8177]
trailer [8134,8177]
===
match
---
name: next_date [60043,60052]
name: next_date [61759,61768]
===
match
---
name: test_dag_id [16835,16846]
name: test_dag_id [16835,16846]
===
match
---
operator: = [51578,51579]
operator: = [53294,53295]
===
match
---
number: 3 [17367,17368]
number: 3 [17367,17368]
===
match
---
name: _clean_up [53521,53530]
name: _clean_up [55237,55246]
===
match
---
name: task [19266,19270]
name: task [19266,19270]
===
match
---
simple_stmt [36343,36377]
simple_stmt [38059,38093]
===
match
---
name: ti [70514,70516]
name: ti [72230,72232]
===
match
---
name: dag [58699,58702]
name: dag [60415,60418]
===
match
---
operator: , [10646,10647]
operator: , [10646,10647]
===
match
---
operator: = [18068,18069]
operator: = [18068,18069]
===
match
---
atom_expr [27723,27765]
atom_expr [29439,29481]
===
match
---
name: dagrun_1 [48425,48433]
name: dagrun_1 [50141,50149]
===
match
---
operator: = [54304,54305]
operator: = [56020,56021]
===
match
---
number: 6 [56926,56927]
number: 6 [58642,58643]
===
match
---
name: DummyOperator [28594,28607]
name: DummyOperator [30310,30323]
===
match
---
suite [30758,30838]
suite [32474,32554]
===
match
---
trailer [50888,50898]
trailer [52604,52614]
===
match
---
name: next_dagrun_create_after [42902,42926]
name: next_dagrun_create_after [44618,44642]
===
match
---
name: _clean_up [54673,54682]
name: _clean_up [56389,56398]
===
match
---
operator: = [13995,13996]
operator: = [13995,13996]
===
match
---
string: "hello" [18631,18638]
string: "hello" [18631,18638]
===
match
---
string: 'test_clear_set_dagrun_state_parent_dag' [51471,51511]
string: 'test_clear_set_dagrun_state_parent_dag' [53187,53227]
===
match
---
operator: = [58235,58236]
operator: = [59951,59952]
===
match
---
name: i [14687,14688]
name: i [14687,14688]
===
match
---
name: op4 [36083,36086]
name: op4 [37799,37802]
===
match
---
simple_stmt [69937,69948]
simple_stmt [71653,71664]
===
match
---
name: dag_id [4736,4742]
name: dag_id [4736,4742]
===
match
---
expr_stmt [55320,55328]
expr_stmt [57036,57044]
===
match
---
operator: >> [8003,8005]
operator: >> [8003,8005]
===
match
---
name: test_dag_id [17807,17818]
name: test_dag_id [17807,17818]
===
match
---
testlist_comp [31644,31660]
testlist_comp [33360,33376]
===
match
---
operator: == [55929,55931]
operator: == [57645,57647]
===
match
---
operator: = [59725,59726]
operator: = [61441,61442]
===
match
---
operator: , [52614,52615]
operator: , [54330,54331]
===
match
---
atom_expr [20746,20769]
atom_expr [20746,20769]
===
match
---
simple_stmt [64513,64532]
simple_stmt [66229,66248]
===
match
---
decorator [53223,53399]
decorator [54939,55115]
===
match
---
operator: , [30726,30727]
operator: , [32442,32443]
===
match
---
name: i [14239,14240]
name: i [14239,14240]
===
match
---
argument [51827,51834]
argument [53543,53550]
===
match
---
suite [13409,13783]
suite [13409,13783]
===
match
---
name: DEFAULT_ARGS [67047,67059]
name: DEFAULT_ARGS [68763,68775]
===
match
---
name: dag [56766,56769]
name: dag [58482,58485]
===
match
---
atom_expr [50460,50483]
atom_expr [52176,52199]
===
match
---
name: conf [29356,29360]
name: conf [31072,31076]
===
match
---
trailer [59230,59239]
trailer [60946,60955]
===
match
---
name: dag [45183,45186]
name: dag [46899,46902]
===
match
---
atom_expr [34105,34157]
atom_expr [35821,35873]
===
match
---
simple_stmt [19659,19698]
simple_stmt [19659,19698]
===
match
---
assert_stmt [17675,17759]
assert_stmt [17675,17759]
===
match
---
dictorsetmaker [37707,37723]
dictorsetmaker [39423,39439]
===
match
---
trailer [54926,54932]
trailer [56642,56648]
===
match
---
operator: == [25820,25822]
operator: == [27536,27538]
===
match
---
parameters [22408,22414]
parameters [22408,22414]
===
match
---
assert_stmt [21998,22058]
assert_stmt [21998,22058]
===
match
---
arglist [61776,61900]
arglist [63492,63616]
===
match
---
name: DAG [18277,18280]
name: DAG [18277,18280]
===
match
---
arglist [14469,14477]
arglist [14469,14477]
===
match
---
param [32918,32922]
param [34634,34638]
===
match
---
name: dag [25576,25579]
name: dag [27292,27295]
===
match
---
atom_expr [25618,25641]
atom_expr [27334,27357]
===
match
---
fstring_expr [15571,15574]
fstring_expr [15571,15574]
===
match
---
argument [64171,64204]
argument [65887,65920]
===
match
---
trailer [24426,24428]
trailer [26142,26144]
===
match
---
name: next_local [23049,23059]
name: next_local [23049,23059]
===
match
---
operator: = [53680,53681]
operator: = [55396,55397]
===
match
---
name: dag [27691,27694]
name: dag [29407,29410]
===
match
---
arglist [59025,59035]
arglist [60741,60751]
===
match
---
operator: == [34681,34683]
operator: == [36397,36399]
===
match
---
name: datetime [34878,34886]
name: datetime [36594,36602]
===
match
---
name: session [54108,54115]
name: session [55824,55831]
===
match
---
name: close [33311,33316]
name: close [35027,35032]
===
match
---
operator: @ [70712,70713]
operator: @ [72428,72429]
===
match
---
name: Session [30294,30301]
name: Session [32010,32017]
===
match
---
operator: , [42572,42573]
operator: , [44288,44289]
===
match
---
name: datetime [923,931]
name: datetime [923,931]
===
match
---
simple_stmt [34848,34926]
simple_stmt [36564,36642]
===
match
---
name: task_id [37969,37976]
name: task_id [39685,39692]
===
match
---
operator: , [22725,22726]
operator: , [22725,22726]
===
match
---
name: task_id [6546,6553]
name: task_id [6546,6553]
===
match
---
name: sync_to_db [33045,33055]
name: sync_to_db [34761,34771]
===
match
---
argument [31012,31025]
argument [32728,32741]
===
match
---
name: DAG [28661,28664]
name: DAG [30377,30380]
===
match
---
operator: , [8158,8159]
operator: , [8158,8159]
===
match
---
trailer [45999,46010]
trailer [47715,47726]
===
match
---
trailer [34658,34664]
trailer [36374,36380]
===
match
---
simple_stmt [62048,62066]
simple_stmt [63764,63782]
===
match
---
simple_stmt [36011,36043]
simple_stmt [37727,37759]
===
match
---
name: is_active [34310,34319]
name: is_active [36026,36035]
===
match
---
trailer [2959,2965]
trailer [2959,2965]
===
match
---
argument [70478,70504]
argument [72194,72220]
===
match
---
simple_stmt [51932,51956]
simple_stmt [53648,53672]
===
match
---
atom_expr [63460,63492]
atom_expr [65176,65208]
===
match
---
funcdef [16367,16672]
funcdef [16367,16672]
===
match
---
trailer [38663,38711]
trailer [40379,40427]
===
match
---
operator: = [35265,35266]
operator: = [36981,36982]
===
match
---
name: DEFAULT_DATE [53921,53933]
name: DEFAULT_DATE [55637,55649]
===
match
---
expr_stmt [23969,24006]
expr_stmt [23969,24006]
===
match
---
trailer [62433,62444]
trailer [64149,64160]
===
match
---
name: i [62010,62011]
name: i [63726,63727]
===
match
---
name: prev_local [22879,22889]
name: prev_local [22879,22889]
===
match
---
name: i [14509,14510]
name: i [14509,14510]
===
match
---
argument [58900,58913]
argument [60616,60629]
===
match
---
name: self [55137,55141]
name: self [56853,56857]
===
match
---
operator: = [67445,67446]
operator: = [69161,69162]
===
match
---
operator: = [61984,61985]
operator: = [63700,63701]
===
match
---
name: start_date [43634,43644]
name: start_date [45350,45360]
===
match
---
expr_stmt [10127,10144]
expr_stmt [10127,10144]
===
match
---
operator: , [43666,43667]
operator: , [45382,45383]
===
match
---
operator: , [58833,58834]
operator: , [60549,60550]
===
match
---
comparison [49198,49221]
comparison [50914,50937]
===
match
---
trailer [31450,31460]
trailer [33166,33176]
===
match
---
name: weight_rule [16649,16660]
name: weight_rule [16649,16660]
===
match
---
atom_expr [52445,52468]
atom_expr [54161,54184]
===
match
---
operator: > [45617,45618]
operator: > [47333,47334]
===
match
---
name: dag [39054,39057]
name: dag [40770,40773]
===
match
---
name: dag_id [46271,46277]
name: dag_id [47987,47993]
===
match
---
simple_stmt [13740,13783]
simple_stmt [13740,13783]
===
match
---
trailer [34944,34978]
trailer [36660,36694]
===
match
---
operator: } [37723,37724]
operator: } [39439,39440]
===
match
---
name: dag [6990,6993]
name: dag [6990,6993]
===
match
---
trailer [24226,24237]
trailer [25942,25953]
===
match
---
name: dag [23977,23980]
name: dag [23977,23980]
===
match
---
name: op2 [6279,6282]
name: op2 [6279,6282]
===
match
---
atom_expr [50060,50244]
atom_expr [51776,51960]
===
match
---
decorator [67842,67889]
decorator [69558,69605]
===
match
---
trailer [23112,23122]
trailer [23112,23122]
===
match
---
trailer [58972,58978]
trailer [60688,60694]
===
match
---
atom [46556,46580]
atom [48272,48296]
===
match
---
testlist_comp [17821,17845]
testlist_comp [17821,17845]
===
match
---
atom_expr [68220,68238]
atom_expr [69936,69954]
===
match
---
name: DEFAULT_DATE [16992,17004]
name: DEFAULT_DATE [16992,17004]
===
match
---
trailer [58825,58837]
trailer [60541,60553]
===
match
---
name: datetime [46624,46632]
name: datetime [48340,48348]
===
match
---
operator: , [65699,65700]
operator: , [67415,67416]
===
match
---
operator: = [40555,40556]
operator: = [42271,42272]
===
match
---
atom [14144,14492]
atom [14144,14492]
===
match
---
atom_expr [25859,25895]
atom_expr [27575,27611]
===
match
---
name: DAG [47756,47759]
name: DAG [49472,49475]
===
match
---
operator: , [29605,29606]
operator: , [31321,31322]
===
match
---
operator: , [52352,52353]
operator: , [54068,54069]
===
match
---
name: start_date [6014,6024]
name: start_date [6014,6024]
===
match
---
operator: = [64875,64876]
operator: = [66591,66592]
===
match
---
name: hours [55303,55308]
name: hours [57019,57024]
===
match
---
trailer [21484,21554]
trailer [21484,21554]
===
match
---
assert_stmt [28136,28157]
assert_stmt [29852,29873]
===
match
---
name: start_date [42424,42434]
name: start_date [44140,44150]
===
match
---
operator: , [31766,31767]
operator: , [33482,33483]
===
match
---
name: patcher_dag_code [2524,2540]
name: patcher_dag_code [2524,2540]
===
match
---
atom_expr [4622,4711]
atom_expr [4622,4711]
===
match
---
argument [35320,35332]
argument [37036,37048]
===
match
---
operator: == [22092,22094]
operator: == [22092,22094]
===
match
---
trailer [59287,59299]
trailer [61003,61015]
===
match
---
simple_stmt [13593,13660]
simple_stmt [13593,13660]
===
match
---
param [56214,56232]
param [57930,57948]
===
match
---
number: 1 [59677,59678]
number: 1 [61393,61394]
===
match
---
name: dag_id [62097,62103]
name: dag_id [63813,63819]
===
match
---
name: dag [42825,42828]
name: dag [44541,44544]
===
match
---
name: start_date [53588,53598]
name: start_date [55304,55314]
===
match
---
trailer [64777,64820]
trailer [66493,66536]
===
match
---
comparison [47239,47289]
comparison [48955,49005]
===
match
---
string: 'dag' [10616,10621]
string: 'dag' [10616,10621]
===
match
---
atom_expr [7235,7242]
atom_expr [7235,7242]
===
match
---
arglist [62339,62447]
arglist [64055,64163]
===
match
---
name: dag [27788,27791]
name: dag [29504,29507]
===
match
---
name: start_date [43461,43471]
name: start_date [45177,45187]
===
match
---
assert_stmt [29277,29316]
assert_stmt [30993,31032]
===
match
---
shift_expr [36011,36042]
shift_expr [37727,37758]
===
match
---
operator: = [15074,15075]
operator: = [15074,15075]
===
match
---
trailer [55587,55642]
trailer [57303,57358]
===
match
---
arglist [67666,67674]
arglist [69382,69390]
===
match
---
not_test [39711,39739]
not_test [41427,41455]
===
match
---
simple_stmt [3752,3788]
simple_stmt [3752,3788]
===
match
---
name: mock [40061,40065]
name: mock [41777,41781]
===
match
---
atom_expr [43596,43617]
atom_expr [45312,45333]
===
match
---
operator: , [29376,29377]
operator: , [31092,31093]
===
match
---
name: get [33718,33721]
name: get [35434,35437]
===
match
---
operator: , [26163,26164]
operator: , [27879,27880]
===
match
---
parameters [4519,4525]
parameters [4519,4525]
===
match
---
trailer [52627,52635]
trailer [54343,54351]
===
match
---
trailer [63986,64029]
trailer [65702,65745]
===
match
---
operator: , [44381,44382]
operator: , [46097,46098]
===
match
---
operator: , [61255,61256]
operator: , [62971,62972]
===
match
---
name: default_args [34952,34964]
name: default_args [36668,36680]
===
match
---
name: child_dag_name [61804,61818]
name: child_dag_name [63520,63534]
===
match
---
comparison [29668,29713]
comparison [31384,31429]
===
match
---
trailer [47618,47623]
trailer [49334,49339]
===
match
---
atom_expr [2495,2510]
atom_expr [2495,2510]
===
match
---
trailer [27791,27810]
trailer [29507,29526]
===
match
---
decorator [69766,69813]
decorator [71482,71529]
===
match
---
name: date [55714,55718]
name: date [57430,57434]
===
match
---
trailer [33115,33122]
trailer [34831,34838]
===
match
---
name: two_hours_ago [57067,57080]
name: two_hours_ago [58783,58796]
===
match
---
simple_stmt [58536,58691]
simple_stmt [60252,60407]
===
match
---
trailer [38671,38681]
trailer [40387,40397]
===
match
---
trailer [64529,64531]
trailer [66245,66247]
===
match
---
trailer [27046,27074]
trailer [28762,28790]
===
match
---
trailer [31481,31554]
trailer [33197,33270]
===
match
---
simple_stmt [70554,70587]
simple_stmt [72270,72303]
===
match
---
atom_expr [5012,5061]
atom_expr [5012,5061]
===
match
---
name: name [27069,27073]
name: name [28785,28789]
===
match
---
argument [64899,64916]
argument [66615,66632]
===
match
---
name: DuplicateTaskIdFound [1409,1429]
name: DuplicateTaskIdFound [1409,1429]
===
match
---
assert_stmt [65242,65268]
assert_stmt [66958,66984]
===
match
---
operator: , [54010,54011]
operator: , [55726,55727]
===
match
---
name: dag [67691,67694]
name: dag [69407,69410]
===
match
---
operator: = [44636,44637]
operator: = [46352,46353]
===
match
---
import_from [1715,1764]
import_from [1715,1764]
===
match
---
operator: , [5251,5252]
operator: , [5251,5252]
===
match
---
atom_expr [61937,61945]
atom_expr [63653,63661]
===
match
---
atom_expr [32094,32110]
atom_expr [33810,33826]
===
match
---
trailer [20791,20801]
trailer [20791,20801]
===
match
---
atom_expr [63062,63089]
atom_expr [64778,64805]
===
match
---
assert_stmt [32624,32654]
assert_stmt [34340,34370]
===
match
---
name: execution_date [39270,39284]
name: execution_date [40986,41000]
===
match
---
operator: = [51830,51831]
operator: = [53546,53547]
===
match
---
trailer [42237,42252]
trailer [43953,43968]
===
match
---
name: start_date [54801,54811]
name: start_date [56517,56527]
===
match
---
operator: = [40287,40288]
operator: = [42003,42004]
===
match
---
assert_stmt [27833,27873]
assert_stmt [29549,29589]
===
match
---
string: 'owner1' [6255,6263]
string: 'owner1' [6255,6263]
===
match
---
trailer [51534,51542]
trailer [53250,53258]
===
match
---
comparison [33639,33667]
comparison [35355,35383]
===
match
---
atom_expr [55575,55642]
atom_expr [57291,57358]
===
match
---
argument [34952,34977]
argument [36668,36693]
===
match
---
simple_stmt [37552,37595]
simple_stmt [39268,39311]
===
match
---
name: pytest [5221,5227]
name: pytest [5221,5227]
===
match
---
trailer [26466,26473]
trailer [28182,28189]
===
match
---
operator: , [20145,20146]
operator: , [20145,20146]
===
match
---
number: 1 [59031,59032]
number: 1 [60747,60748]
===
match
---
expr_stmt [59542,59765]
expr_stmt [61258,61481]
===
match
---
atom_expr [39087,39176]
atom_expr [40803,40892]
===
match
---
expr_stmt [52002,52197]
expr_stmt [53718,53913]
===
match
---
atom_expr [42552,42572]
atom_expr [44268,44288]
===
match
---
name: outdated_permissions [63565,63585]
name: outdated_permissions [65281,65301]
===
match
---
atom_expr [37102,37152]
atom_expr [38818,38868]
===
match
---
simple_stmt [1430,1517]
simple_stmt [1430,1517]
===
match
---
comparison [9374,9400]
comparison [9374,9400]
===
match
---
trailer [33022,33030]
trailer [34738,34746]
===
match
---
string: 'start_date' [11980,11992]
string: 'start_date' [11980,11992]
===
match
---
name: dagrun_2 [52459,52467]
name: dagrun_2 [54175,54183]
===
match
---
name: template_file [19710,19723]
name: template_file [19710,19723]
===
match
---
name: last_parsed_time [25253,25269]
name: last_parsed_time [26969,26985]
===
match
---
atom_expr [41906,41942]
atom_expr [43622,43658]
===
match
---
operator: , [60781,60782]
operator: , [62497,62498]
===
match
---
trailer [4960,4996]
trailer [4960,4996]
===
match
---
name: session [41588,41595]
name: session [43304,43311]
===
match
---
classdef [2400,63803]
classdef [2400,65519]
===
match
---
number: 4 [25474,25475]
number: 4 [27190,27191]
===
match
---
name: orm_dag [34302,34309]
name: orm_dag [36018,36025]
===
match
---
operator: , [18183,18184]
operator: , [18183,18184]
===
match
---
simple_stmt [57067,57117]
simple_stmt [58783,58833]
===
match
---
import_from [1817,1857]
import_from [1817,1857]
===
match
---
name: clear [52756,52761]
name: clear [54472,54477]
===
match
---
operator: , [42403,42404]
operator: , [44119,44120]
===
match
---
name: timedelta [62243,62252]
name: timedelta [63959,63968]
===
match
---
trailer [16960,17005]
trailer [16960,17005]
===
match
---
operator: = [70170,70171]
operator: = [71886,71887]
===
match
---
arith_expr [14687,14692]
arith_expr [14687,14692]
===
match
---
name: dag [48263,48266]
name: dag [49979,49982]
===
match
---
name: tempfile [954,962]
name: tempfile [954,962]
===
match
---
name: dag [67618,67621]
name: dag [69334,69337]
===
match
---
argument [55623,55640]
argument [57339,57356]
===
match
---
operator: , [62358,62359]
operator: , [64074,64075]
===
match
---
operator: = [7015,7016]
operator: = [7015,7016]
===
match
---
comparison [65409,65425]
comparison [67125,67141]
===
match
---
comparison [27889,27933]
comparison [29605,29649]
===
match
---
atom_expr [44054,44078]
atom_expr [45770,45794]
===
match
---
trailer [69246,69248]
trailer [70962,70964]
===
match
---
arglist [51864,51890]
arglist [53580,53606]
===
match
---
trailer [69171,69180]
trailer [70887,70896]
===
match
---
atom_expr [52645,52675]
atom_expr [54361,54391]
===
match
---
name: paused_dags [32488,32499]
name: paused_dags [34204,34215]
===
match
---
name: timezone [59270,59278]
name: timezone [60986,60994]
===
match
---
trailer [52854,52862]
trailer [54570,54578]
===
match
---
assert_stmt [18748,18794]
assert_stmt [18748,18794]
===
match
---
atom [28187,28192]
atom [29903,29908]
===
match
---
argument [66091,66110]
argument [67807,67826]
===
match
---
operator: = [50306,50307]
operator: = [52022,52023]
===
match
---
argument [7966,7984]
argument [7966,7984]
===
match
---
name: session [30363,30370]
name: session [32079,32086]
===
match
---
simple_stmt [69686,69757]
simple_stmt [71402,71473]
===
match
---
operator: , [65078,65079]
operator: , [66794,66795]
===
match
---
expr_stmt [37493,37539]
expr_stmt [39209,39255]
===
match
---
name: dag_id [49215,49221]
name: dag_id [50931,50937]
===
match
---
operator: = [64335,64336]
operator: = [66051,66052]
===
match
---
name: dates [55820,55825]
name: dates [57536,57541]
===
match
---
trailer [27951,27965]
trailer [29667,29681]
===
match
---
name: session [48785,48792]
name: session [50501,50508]
===
match
---
simple_stmt [70635,70703]
simple_stmt [72351,72419]
===
match
---
trailer [68189,68196]
trailer [69905,69912]
===
match
---
string: 'dag-bulk-sync-3' [25801,25818]
string: 'dag-bulk-sync-3' [27517,27534]
===
match
---
operator: = [18093,18094]
operator: = [18093,18094]
===
match
---
argument [46643,46649]
argument [48359,48365]
===
match
---
arglist [6171,6194]
arglist [6171,6194]
===
match
---
comparison [46028,46069]
comparison [47744,47785]
===
match
---
name: dag [66759,66762]
name: dag [68475,68478]
===
match
---
with_stmt [6082,6196]
with_stmt [6082,6196]
===
match
---
simple_stmt [39382,39418]
simple_stmt [41098,41134]
===
match
---
string: 'test-dag' [26264,26274]
string: 'test-dag' [27980,27990]
===
match
---
name: TEST_DATE [39285,39294]
name: TEST_DATE [41001,41010]
===
match
---
name: weight [13009,13015]
name: weight [13009,13015]
===
match
---
trailer [11734,11747]
trailer [11734,11747]
===
match
---
name: dag_eq [44357,44363]
name: dag_eq [46073,46079]
===
match
---
parameters [32551,32557]
parameters [34267,34273]
===
match
---
simple_stmt [55422,55467]
simple_stmt [57138,57183]
===
match
---
atom_expr [25244,25269]
atom_expr [26960,26985]
===
match
---
arglist [18572,18650]
arglist [18572,18650]
===
match
---
trailer [60749,60758]
trailer [62465,62474]
===
match
---
name: args [44342,44346]
name: args [46058,46062]
===
match
---
simple_stmt [29625,29653]
simple_stmt [31341,31369]
===
match
---
operator: { [56282,56283]
operator: { [57998,57999]
===
match
---
trailer [35319,35333]
trailer [37035,37049]
===
match
---
trailer [22089,22091]
trailer [22089,22091]
===
match
---
assert_stmt [68179,68204]
assert_stmt [69895,69920]
===
match
---
name: query [25238,25243]
name: query [26954,26959]
===
match
---
decorated [58404,59252]
decorated [60120,60968]
===
match
---
expr_stmt [35346,35379]
expr_stmt [37062,37095]
===
match
---
operator: = [59785,59786]
operator: = [61501,61502]
===
match
---
name: dag_diff_name [45774,45787]
name: dag_diff_name [47490,47503]
===
match
---
fstring_expr [61987,62003]
fstring_expr [63703,63719]
===
match
---
trailer [57141,57328]
trailer [58857,59044]
===
match
---
name: test_dag_orientation_default_value [5401,5435]
name: test_dag_orientation_default_value [5401,5435]
===
match
---
string: 'test_field' [19995,20007]
string: 'test_field' [19995,20007]
===
match
---
trailer [32729,32740]
trailer [34445,34456]
===
match
---
trailer [13399,13406]
trailer [13399,13406]
===
match
---
argument [50579,50598]
argument [52295,52314]
===
match
---
trailer [50777,50784]
trailer [52493,52500]
===
match
---
simple_stmt [21908,21944]
simple_stmt [21908,21944]
===
match
---
name: _next [21099,21104]
name: _next [21099,21104]
===
match
---
name: copy [4389,4393]
name: copy [4389,4393]
===
match
---
operator: , [25072,25073]
operator: , [26788,26789]
===
match
---
number: 0 [24606,24607]
number: 0 [26322,26323]
===
match
---
atom_expr [24704,24720]
atom_expr [26420,26436]
===
match
---
atom_expr [15513,15703]
atom_expr [15513,15703]
===
match
---
atom [63376,63434]
atom [65092,65150]
===
match
---
name: DEFAULT_ARGS [66217,66229]
name: DEFAULT_ARGS [67933,67945]
===
match
---
comparison [24752,24918]
comparison [26468,26634]
===
match
---
name: next_date [59183,59192]
name: next_date [60899,60908]
===
match
---
simple_stmt [42889,42935]
simple_stmt [44605,44651]
===
match
---
expr_stmt [12346,12397]
expr_stmt [12346,12397]
===
match
---
atom_expr [36524,36541]
atom_expr [38240,38257]
===
match
---
trailer [18967,18980]
trailer [18967,18980]
===
match
---
operator: , [65816,65817]
operator: , [67532,67533]
===
match
---
name: next_dagrun_after_date [62815,62837]
name: next_dagrun_after_date [64531,64553]
===
match
---
name: DEFAULT_DATE [41929,41941]
name: DEFAULT_DATE [43645,43657]
===
match
---
trailer [15671,15680]
trailer [15671,15680]
===
match
---
operator: , [10249,10250]
operator: , [10249,10250]
===
match
---
name: test_task_id [17833,17845]
name: test_task_id [17833,17845]
===
match
---
operator: == [43645,43647]
operator: == [45361,45363]
===
match
---
simple_stmt [15918,15927]
simple_stmt [15918,15927]
===
match
---
name: local_tz [23286,23294]
name: local_tz [23286,23294]
===
match
---
trailer [52581,52636]
trailer [54297,54352]
===
match
---
atom_expr [44026,44038]
atom_expr [45742,45754]
===
match
---
string: 'test_clear_set_dagrun_state_subdag' [49586,49622]
string: 'test_clear_set_dagrun_state_subdag' [51302,51338]
===
match
---
name: os [836,838]
name: os [836,838]
===
match
---
suite [4526,4796]
suite [4526,4796]
===
match
---
operator: - [3305,3306]
operator: - [3305,3306]
===
match
---
name: six_hours_ago_to_the_hour [56866,56891]
name: six_hours_ago_to_the_hour [58582,58607]
===
match
---
name: test_roots [35141,35151]
name: test_roots [36857,36867]
===
match
---
assert_stmt [20460,20554]
assert_stmt [20460,20554]
===
match
---
name: width [13640,13645]
name: width [13640,13645]
===
match
---
name: dateutil [1111,1119]
name: dateutil [1111,1119]
===
match
---
simple_stmt [21610,21679]
simple_stmt [21610,21679]
===
match
---
trailer [39319,39327]
trailer [41035,41043]
===
match
---
arglist [44496,44535]
arglist [46212,46251]
===
match
---
comparison [22005,22058]
comparison [22005,22058]
===
match
---
atom_expr [53345,53358]
atom_expr [55061,55074]
===
match
---
name: dump [45256,45260]
name: dump [46972,46976]
===
match
---
simple_stmt [1360,1430]
simple_stmt [1360,1430]
===
match
---
name: DAG [17885,17888]
name: DAG [17885,17888]
===
match
---
name: DEFAULT_DATE [27861,27873]
name: DEFAULT_DATE [29577,29589]
===
match
---
simple_stmt [8262,8330]
simple_stmt [8262,8330]
===
match
---
name: State [48063,48068]
name: State [49779,49784]
===
match
---
trailer [50467,50473]
trailer [52183,52189]
===
match
---
name: test_dag_id [18172,18183]
name: test_dag_id [18172,18183]
===
match
---
operator: = [61855,61856]
operator: = [63571,63572]
===
match
---
argument [19566,19584]
argument [19566,19584]
===
match
---
atom_expr [32309,32349]
atom_expr [34025,34065]
===
match
---
name: task_id [35847,35854]
name: task_id [37563,37570]
===
match
---
name: self [66924,66928]
name: self [68640,68644]
===
match
---
argument [44669,44686]
argument [46385,46402]
===
match
---
atom_expr [70134,70151]
atom_expr [71850,71867]
===
match
---
simple_stmt [40624,40668]
simple_stmt [42340,42384]
===
match
---
operator: = [29022,29023]
operator: = [30738,30739]
===
match
---
atom_expr [50669,50682]
atom_expr [52385,52398]
===
match
---
name: session [65435,65442]
name: session [67151,67158]
===
match
---
operator: == [53133,53135]
operator: == [54849,54851]
===
match
---
name: dag [64008,64011]
name: dag [65724,65727]
===
match
---
name: utils [2162,2167]
name: utils [2162,2167]
===
match
---
operator: == [27026,27028]
operator: == [28742,28744]
===
match
---
trailer [36070,36077]
trailer [37786,37793]
===
match
---
name: op3 [36025,36028]
name: op3 [37741,37744]
===
match
---
name: settings [33014,33022]
name: settings [34730,34738]
===
match
---
name: task_id [65906,65913]
name: task_id [67622,67629]
===
match
---
argument [64218,64244]
argument [65934,65960]
===
match
---
argument [62225,62263]
argument [63941,63979]
===
match
---
trailer [6688,6694]
trailer [6688,6694]
===
match
---
name: datetime [61121,61129]
name: datetime [62837,62845]
===
match
---
operator: == [45741,45743]
operator: == [47457,47459]
===
match
---
atom_expr [49818,49883]
atom_expr [51534,51599]
===
match
---
name: include_upstream [38597,38613]
name: include_upstream [40313,40329]
===
match
---
trailer [2880,2905]
trailer [2880,2905]
===
match
---
operator: , [25036,25037]
operator: , [26752,26753]
===
match
---
operator: = [65187,65188]
operator: = [66903,66904]
===
match
---
comparison [29180,29235]
comparison [30896,30951]
===
match
---
name: tags [24572,24576]
name: tags [26288,26292]
===
match
---
testlist_comp [31615,31628]
testlist_comp [33331,33344]
===
match
---
simple_stmt [51233,51270]
simple_stmt [52949,52986]
===
match
---
string: 'owner1' [30021,30029]
string: 'owner1' [31737,31745]
===
match
---
name: self [32552,32556]
name: self [34268,34272]
===
match
---
trailer [26461,26466]
trailer [28177,28182]
===
match
---
suite [23495,24071]
suite [23495,24071]
===
match
---
operator: , [37513,37514]
operator: , [39229,39230]
===
match
---
trailer [41272,41338]
trailer [42988,43054]
===
match
---
suite [27153,27196]
suite [28869,28912]
===
match
---
name: TEST_DATE [42435,42444]
name: TEST_DATE [44151,44160]
===
match
---
name: self [51520,51524]
name: self [53236,53240]
===
match
---
argument [22745,22774]
argument [22745,22774]
===
match
---
operator: = [31314,31315]
operator: = [33030,33031]
===
match
---
trailer [22582,22651]
trailer [22582,22651]
===
match
---
name: session [30335,30342]
name: session [32051,32058]
===
match
---
name: dag [44026,44029]
name: dag [45742,45745]
===
match
---
atom_expr [30979,31026]
atom_expr [32695,32742]
===
match
---
string: """         Make sure DST transitions are properly observed         """ [20219,20290]
string: """         Make sure DST transitions are properly observed         """ [20219,20290]
===
match
---
suite [14541,14756]
suite [14541,14756]
===
match
---
number: 0 [38704,38705]
number: 0 [40420,40421]
===
match
---
atom [63142,63230]
atom [64858,64946]
===
match
---
name: task_id [37572,37579]
name: task_id [39288,39295]
===
match
---
operator: , [27762,27763]
operator: , [29478,29479]
===
match
---
funcdef [18490,18546]
funcdef [18490,18546]
===
match
---
name: dag_id [34262,34268]
name: dag_id [35978,35984]
===
match
---
operator: == [44992,44994]
operator: == [46708,46710]
===
match
---
operator: = [36278,36279]
operator: = [37994,37995]
===
match
---
name: row [26733,26736]
name: row [28449,28452]
===
match
---
name: datetime [54257,54265]
name: datetime [55973,55981]
===
match
---
operator: = [64425,64426]
operator: = [66141,66142]
===
match
---
name: DAG [30663,30666]
name: DAG [32379,32382]
===
match
---
name: op1 [37707,37710]
name: op1 [39423,39426]
===
match
---
name: dag [12907,12910]
name: dag [12907,12910]
===
match
---
atom_expr [4404,4435]
atom_expr [4404,4435]
===
match
---
name: orm_dag [29092,29099]
name: orm_dag [30808,30815]
===
match
---
trailer [3067,3074]
trailer [3067,3074]
===
match
---
simple_stmt [19266,19298]
simple_stmt [19266,19298]
===
match
---
simple_stmt [56728,56771]
simple_stmt [58444,58487]
===
match
---
name: op2 [9900,9903]
name: op2 [9900,9903]
===
match
---
expr_stmt [42228,42252]
expr_stmt [43944,43968]
===
match
---
operator: , [69984,69985]
operator: , [71700,71701]
===
match
---
with_stmt [8713,8978]
with_stmt [8713,8978]
===
match
---
name: dag [6216,6219]
name: dag [6216,6219]
===
match
---
trailer [9461,9527]
trailer [9461,9527]
===
match
---
operator: = [44530,44531]
operator: = [46246,46247]
===
match
---
simple_stmt [27943,28128]
simple_stmt [29659,29844]
===
match
---
name: parent_dag [28876,28886]
name: parent_dag [30592,30602]
===
match
---
arglist [41273,41337]
arglist [42989,43053]
===
match
---
decorated [68407,68607]
decorated [70123,70323]
===
match
---
number: 2020 [59025,59029]
number: 2020 [60741,60745]
===
match
---
name: op1 [38135,38138]
name: op1 [39851,39854]
===
match
---
operator: = [52173,52174]
operator: = [53889,53890]
===
match
---
name: State [48723,48728]
name: State [50439,50444]
===
match
---
trailer [18019,18111]
trailer [18019,18111]
===
match
---
name: patch [2543,2548]
name: patch [2543,2548]
===
match
---
trailer [45796,45801]
trailer [47512,47517]
===
match
---
name: dag_id [64711,64717]
name: dag_id [66427,66433]
===
match
---
name: test_bulk_write_to_db [24452,24473]
name: test_bulk_write_to_db [26168,26189]
===
match
---
operator: == [20873,20875]
operator: == [20873,20875]
===
match
---
name: dags [24685,24689]
name: dags [26401,26405]
===
match
---
arglist [61231,61272]
arglist [62947,62988]
===
match
---
trailer [11812,11825]
trailer [11812,11825]
===
match
---
string: "2018-10-26T03:00:00+02:00" [21808,21835]
string: "2018-10-26T03:00:00+02:00" [21808,21835]
===
match
---
simple_stmt [56618,56661]
simple_stmt [58334,58377]
===
match
---
name: set2 [10238,10242]
name: set2 [10238,10242]
===
match
---
trailer [11866,11878]
trailer [11866,11878]
===
match
---
trailer [66322,66329]
trailer [68038,68045]
===
match
---
name: DEFAULT_DATE [47263,47275]
name: DEFAULT_DATE [48979,48991]
===
match
---
name: State [39314,39319]
name: State [41030,41035]
===
match
---
name: convert [20370,20377]
name: convert [20370,20377]
===
match
---
string: 'role1' [63286,63293]
string: 'role1' [65002,65009]
===
match
---
argument [58141,58177]
argument [59857,59893]
===
match
---
simple_stmt [49084,49266]
simple_stmt [50800,50982]
===
match
---
operator: , [47605,47606]
operator: , [49321,49322]
===
match
---
operator: == [45315,45317]
operator: == [47031,47033]
===
match
---
name: self [67335,67339]
name: self [69051,69055]
===
match
---
atom_expr [59548,59765]
atom_expr [61264,61481]
===
match
---
expr_stmt [52561,52636]
expr_stmt [54277,54352]
===
match
---
name: dag [28889,28892]
name: dag [30605,30608]
===
match
---
arglist [44436,44466]
arglist [46152,46182]
===
match
---
trailer [46049,46057]
trailer [47765,47773]
===
match
---
param [33359,33363]
param [35075,35079]
===
match
---
name: task_id [7513,7520]
name: task_id [7513,7520]
===
match
---
arith_expr [56895,56928]
arith_expr [58611,58644]
===
match
---
trailer [4473,4480]
trailer [4473,4480]
===
match
---
name: DEFAULT_DATE [50830,50842]
name: DEFAULT_DATE [52546,52558]
===
match
---
atom_expr [25171,25184]
atom_expr [26887,26900]
===
match
---
name: dag [44995,44998]
name: dag [46711,46714]
===
match
---
operator: = [16991,16992]
operator: = [16991,16992]
===
match
---
simple_stmt [49892,49947]
simple_stmt [51608,51663]
===
match
---
string: 'test-dag2' [26898,26909]
string: 'test-dag2' [28614,28625]
===
match
---
operator: = [54280,54281]
operator: = [55996,55997]
===
match
---
name: parameterized [49395,49408]
name: parameterized [51111,51124]
===
match
---
name: NONE [51327,51331]
name: NONE [53043,53047]
===
match
---
name: dag [24136,24139]
name: dag [25852,25855]
===
match
---
string: "t1" [37580,37584]
string: "t1" [39296,39300]
===
match
---
with_stmt [19120,19253]
with_stmt [19120,19253]
===
match
---
name: start [22558,22563]
name: start [22558,22563]
===
match
---
name: dag_id [46050,46056]
name: dag_id [47766,47772]
===
match
---
name: session [50492,50499]
name: session [52208,52215]
===
match
---
argument [3005,3030]
argument [3005,3030]
===
match
---
operator: , [24808,24809]
operator: , [26524,26525]
===
match
---
atom_expr [69615,69625]
atom_expr [71331,71341]
===
match
---
simple_stmt [18265,18416]
simple_stmt [18265,18416]
===
match
---
operator: , [26642,26643]
operator: , [28358,28359]
===
match
---
string: 'hello' [18773,18780]
string: 'hello' [18773,18780]
===
match
---
suite [16595,16672]
suite [16595,16672]
===
match
---
name: stdout [36570,36576]
name: stdout [38286,38292]
===
match
---
simple_stmt [5451,5530]
simple_stmt [5451,5530]
===
match
---
name: parent_dag [7798,7808]
name: parent_dag [7798,7808]
===
match
---
atom [53254,53332]
atom [54970,55048]
===
match
---
name: subdag [62383,62389]
name: subdag [64099,64105]
===
match
---
simple_stmt [65278,65303]
simple_stmt [66994,67019]
===
match
---
decorator [59257,59301]
decorator [60973,61017]
===
match
---
arglist [64711,64754]
arglist [66427,66470]
===
match
---
name: next_date [57898,57907]
name: next_date [59614,59623]
===
match
---
param [61629,61645]
param [63345,63361]
===
match
---
name: default_args [10795,10807]
name: default_args [10795,10807]
===
match
---
simple_stmt [16813,16873]
simple_stmt [16813,16873]
===
match
---
arglist [49822,49882]
arglist [51538,51598]
===
match
---
operator: = [29896,29897]
operator: = [31612,31613]
===
match
---
operator: , [53083,53084]
operator: , [54799,54800]
===
match
---
name: execution_date [28012,28026]
name: execution_date [29728,29742]
===
match
---
operator: == [2987,2989]
operator: == [2987,2989]
===
match
---
simple_stmt [12924,13098]
simple_stmt [12924,13098]
===
match
---
trailer [47285,47287]
trailer [49001,49003]
===
match
---
argument [48467,48499]
argument [50183,50215]
===
match
---
trailer [25177,25184]
trailer [26893,26900]
===
match
---
atom_expr [14890,14904]
atom_expr [14890,14904]
===
match
---
trailer [7337,7461]
trailer [7337,7461]
===
match
---
argument [61051,61087]
argument [62767,62803]
===
match
---
assert_stmt [38110,38170]
assert_stmt [39826,39886]
===
match
---
import_from [1570,1621]
import_from [1570,1621]
===
match
---
param [10769,10773]
param [10769,10773]
===
match
---
trailer [18567,18571]
trailer [18567,18571]
===
match
---
name: dag_id [31265,31271]
name: dag_id [32981,32987]
===
match
---
simple_stmt [47427,47490]
simple_stmt [49143,49206]
===
match
---
name: DEFAULT_ARGS [70745,70757]
name: DEFAULT_ARGS [72461,72473]
===
match
---
funcdef [12196,12447]
funcdef [12196,12447]
===
match
---
string: """Verify if dag.leaves returns the leaf tasks of a DAG.""" [35647,35706]
string: """Verify if dag.leaves returns the leaf tasks of a DAG.""" [37363,37422]
===
match
---
operator: , [57665,57666]
operator: , [59381,59382]
===
match
---
name: isinstance [66796,66806]
name: isinstance [68512,68522]
===
match
---
operator: == [38712,38714]
operator: == [40428,40430]
===
match
---
operator: , [26375,26376]
operator: , [28091,28092]
===
match
---
trailer [62393,62400]
trailer [64109,64116]
===
match
---
operator: = [54348,54349]
operator: = [56064,56065]
===
match
---
expr_stmt [22785,22818]
expr_stmt [22785,22818]
===
match
---
trailer [30301,30303]
trailer [32017,32019]
===
match
---
operator: , [41483,41484]
operator: , [43199,43200]
===
match
---
operator: = [36255,36256]
operator: = [37971,37972]
===
match
---
dictorsetmaker [24341,24428]
dictorsetmaker [26057,26144]
===
match
---
suite [66491,66545]
suite [68207,68261]
===
match
---
funcdef [4801,5082]
funcdef [4801,5082]
===
match
---
arglist [27979,28117]
arglist [29695,29833]
===
match
---
argument [28058,28087]
argument [29774,29803]
===
match
---
name: default_args [44449,44461]
name: default_args [46165,46177]
===
match
---
name: following_schedule [21920,21938]
name: following_schedule [21920,21938]
===
match
---
argument [56638,56650]
argument [58354,58366]
===
match
---
argument [47760,47801]
argument [49476,49517]
===
match
---
argument [19238,19251]
argument [19238,19251]
===
match
---
name: TestCase [65507,65515]
name: TestCase [67223,67231]
===
match
---
operator: = [61057,61058]
operator: = [62773,62774]
===
match
---
simple_stmt [49352,49389]
simple_stmt [51068,51105]
===
match
---
operator: , [63921,63922]
operator: , [65637,65638]
===
match
---
operator: = [60229,60230]
operator: = [61945,61946]
===
match
---
operator: = [42794,42795]
operator: = [44510,44511]
===
match
---
parameters [11933,11939]
parameters [11933,11939]
===
match
---
arglist [40430,40486]
arglist [42146,42202]
===
match
---
dotted_name [46329,46349]
dotted_name [48045,48065]
===
match
---
operator: = [23060,23061]
operator: = [23060,23061]
===
match
---
name: id [38715,38717]
name: id [40431,40433]
===
match
---
operator: = [34071,34072]
operator: = [35787,35788]
===
match
---
operator: = [56892,56893]
operator: = [58608,58609]
===
match
---
trailer [61230,61273]
trailer [62946,62989]
===
match
---
argument [50819,50842]
argument [52535,52558]
===
match
---
name: tasks_count [65759,65770]
name: tasks_count [67475,67486]
===
match
---
operator: = [50648,50649]
operator: = [52364,52365]
===
match
---
atom_expr [9116,9135]
atom_expr [9116,9135]
===
match
---
atom [44249,44297]
atom [45965,46013]
===
match
---
expr_stmt [17255,17279]
expr_stmt [17255,17279]
===
match
---
expr_stmt [60004,60053]
expr_stmt [61720,61769]
===
match
---
simple_stmt [66459,66470]
simple_stmt [68175,68186]
===
match
---
atom_expr [54450,54459]
atom_expr [56166,56175]
===
match
---
trailer [37217,37225]
trailer [38933,38941]
===
match
---
name: DummyOperator [9735,9748]
name: DummyOperator [9735,9748]
===
match
---
trailer [9703,9716]
trailer [9703,9716]
===
match
---
name: DummyOperator [35352,35365]
name: DummyOperator [37068,37081]
===
match
---
operator: = [36370,36371]
operator: = [38086,38087]
===
match
---
name: TypeError [68712,68721]
name: TypeError [70428,70437]
===
match
---
operator: = [35992,35993]
operator: = [37708,37709]
===
match
---
operator: , [25184,25185]
operator: , [26900,26901]
===
match
---
name: DagModel [30377,30385]
name: DagModel [32093,32101]
===
match
---
operator: = [7692,7693]
operator: = [7692,7693]
===
match
---
name: unittest [1048,1056]
name: unittest [1048,1056]
===
match
---
simple_stmt [40728,40790]
simple_stmt [42444,42506]
===
match
---
trailer [42860,42872]
trailer [44576,44588]
===
match
---
name: DummyOperator [7828,7841]
name: DummyOperator [7828,7841]
===
match
---
trailer [56909,56919]
trailer [58625,58635]
===
match
---
arith_expr [13621,13635]
arith_expr [13621,13635]
===
match
---
simple_stmt [58699,58925]
simple_stmt [60415,60641]
===
match
---
atom_expr [70561,70575]
atom_expr [72277,72291]
===
match
---
trailer [51663,51689]
trailer [53379,53405]
===
match
---
testlist_comp [65678,65702]
testlist_comp [67394,67418]
===
match
---
string: "Task id 't1' has already been added to the DAG" [36913,36961]
string: "Task id 't1' has already been added to the DAG" [38629,38677]
===
match
---
trailer [53520,53530]
trailer [55236,55246]
===
match
---
trailer [9330,9337]
trailer [9330,9337]
===
match
---
comparison [29133,29157]
comparison [30849,30873]
===
match
---
operator: , [25978,25979]
operator: , [27694,27695]
===
match
---
simple_stmt [9037,9068]
simple_stmt [9037,9068]
===
match
---
operator: == [23929,23931]
operator: == [23929,23931]
===
match
---
assert_stmt [57980,58016]
assert_stmt [59696,59732]
===
match
---
atom_expr [29472,29542]
atom_expr [31188,31258]
===
match
---
operator: != [53315,53317]
operator: != [55031,55033]
===
match
---
suite [35287,35611]
suite [37003,37327]
===
match
---
atom_expr [63377,63404]
atom_expr [65093,65120]
===
match
---
name: QUEUED [17273,17279]
name: QUEUED [17273,17279]
===
match
---
param [38908,38912]
param [40624,40628]
===
match
---
funcdef [65723,66168]
funcdef [67439,67884]
===
match
---
simple_stmt [9864,9888]
simple_stmt [9864,9888]
===
match
---
name: task_depth [15006,15016]
name: task_depth [15006,15016]
===
match
---
operator: , [12843,12844]
operator: , [12843,12844]
===
match
---
atom_expr [69163,69180]
atom_expr [70879,70896]
===
match
---
trailer [24365,24371]
trailer [26081,26087]
===
match
---
operator: = [9711,9712]
operator: = [9711,9712]
===
match
---
atom_expr [34375,34449]
atom_expr [36091,36165]
===
match
---
suite [63006,63803]
suite [64722,65519]
===
match
---
simple_stmt [68213,68268]
simple_stmt [69929,69984]
===
match
---
atom_expr [50626,50683]
atom_expr [52342,52399]
===
match
---
funcdef [66626,66899]
funcdef [68342,68615]
===
match
---
name: dag [71065,71068]
name: dag [72781,72784]
===
match
---
operator: = [68991,68992]
operator: = [70707,70708]
===
match
---
string: 'DAG' [10788,10793]
string: 'DAG' [10788,10793]
===
match
---
atom [37706,37724]
atom [39422,39440]
===
match
---
trailer [59278,59287]
trailer [60994,61003]
===
match
---
parameters [37782,37788]
parameters [39498,39504]
===
match
---
trailer [54820,54829]
trailer [56536,56545]
===
match
---
trailer [37394,37401]
trailer [39110,39117]
===
match
---
name: jinja_env [18660,18669]
name: jinja_env [18660,18669]
===
match
---
name: noop_pipeline [67220,67233]
name: noop_pipeline [68936,68949]
===
match
---
string: 'test-dag' [24976,24986]
string: 'test-dag' [26692,26702]
===
match
---
return_stmt [62048,62065]
return_stmt [63764,63781]
===
match
---
argument [64013,64028]
argument [65729,65744]
===
match
---
operator: , [67669,67670]
operator: , [69385,69386]
===
match
---
atom_expr [34941,34978]
atom_expr [36657,36694]
===
match
---
trailer [48414,48416]
trailer [50130,50132]
===
match
---
name: match [5253,5258]
name: match [5253,5258]
===
match
---
atom_expr [30149,30251]
atom_expr [31865,31967]
===
match
---
name: is_paused [31752,31761]
name: is_paused [33468,33477]
===
match
---
operator: = [4948,4949]
operator: = [4948,4949]
===
match
---
name: timezone [54962,54970]
name: timezone [56678,56686]
===
match
---
name: start [21460,21465]
name: start [21460,21465]
===
match
---
atom_expr [9166,9185]
atom_expr [9166,9185]
===
match
---
atom_expr [25453,25476]
atom_expr [27169,27192]
===
match
---
name: self [54668,54672]
name: self [56384,56388]
===
match
---
operator: = [18238,18239]
operator: = [18238,18239]
===
match
---
operator: = [7038,7039]
operator: = [7038,7039]
===
match
---
atom [11979,12024]
atom [11979,12024]
===
match
---
assert_stmt [11724,11793]
assert_stmt [11724,11793]
===
match
---
funcdef [65576,65628]
funcdef [67292,67344]
===
match
---
simple_stmt [59144,59194]
simple_stmt [60860,60910]
===
match
---
number: 0 [6934,6935]
number: 0 [6934,6935]
===
match
---
argument [19810,19842]
argument [19810,19842]
===
match
---
simple_stmt [53695,53740]
simple_stmt [55411,55456]
===
match
---
atom_expr [17687,17759]
atom_expr [17687,17759]
===
match
---
name: test_replace_outdated_access_control_actions [62955,62999]
name: test_replace_outdated_access_control_actions [64671,64715]
===
match
---
trailer [5020,5053]
trailer [5020,5053]
===
match
---
name: TEST_DATE [42589,42598]
name: TEST_DATE [44305,44314]
===
match
---
simple_stmt [34212,34286]
simple_stmt [35928,36002]
===
match
---
operator: = [29470,29471]
operator: = [31186,31187]
===
match
---
simple_stmt [41865,41943]
simple_stmt [43581,43659]
===
match
---
suite [53473,54691]
suite [55189,56407]
===
match
---
trailer [59856,59865]
trailer [61572,61581]
===
match
---
trailer [50038,50040]
trailer [51754,51756]
===
match
---
suite [11940,12191]
suite [11940,12191]
===
match
---
trailer [29162,29164]
trailer [30878,30880]
===
match
---
atom [18208,18229]
atom [18208,18229]
===
match
---
name: start_date [49703,49713]
name: start_date [51419,51429]
===
match
---
argument [48545,48568]
argument [50261,50284]
===
match
---
name: RUNNING [27991,27998]
name: RUNNING [29707,29714]
===
match
---
shift_expr [38064,38074]
shift_expr [39780,39790]
===
match
---
name: dag_id [41103,41109]
name: dag_id [42819,42825]
===
match
---
argument [50856,50906]
argument [52572,52622]
===
match
---
operator: = [19572,19573]
operator: = [19572,19573]
===
match
---
operator: == [29691,29693]
operator: == [31407,31409]
===
match
---
simple_stmt [40030,40078]
simple_stmt [41746,41794]
===
match
---
atom_expr [34302,34319]
atom_expr [36018,36035]
===
match
---
simple_stmt [21998,22059]
simple_stmt [21998,22059]
===
match
---
name: dag [16110,16113]
name: dag [16110,16113]
===
match
---
name: default_args [34965,34977]
name: default_args [36681,36693]
===
match
---
name: parent_dag_name [61786,61801]
name: parent_dag_name [63502,63517]
===
match
---
expr_stmt [43861,43890]
expr_stmt [45577,45606]
===
match
---
argument [50634,50661]
argument [52350,52377]
===
match
---
name: parameterized [1215,1228]
name: parameterized [1215,1228]
===
match
---
name: operator [70055,70063]
name: operator [71771,71779]
===
match
---
operator: = [41091,41092]
operator: = [42807,42808]
===
match
---
trailer [29585,29591]
trailer [31301,31307]
===
match
---
trailer [34407,34449]
trailer [36123,36165]
===
match
---
name: TestCase [66202,66210]
name: TestCase [67918,67926]
===
match
---
name: owner [6246,6251]
name: owner [6246,6251]
===
match
---
expr_stmt [15056,15102]
expr_stmt [15056,15102]
===
match
---
funcdef [22350,23442]
funcdef [22350,23442]
===
match
---
name: dag_id [39411,39417]
name: dag_id [41127,41133]
===
match
---
trailer [31712,31725]
trailer [33428,33441]
===
match
---
name: dag [48436,48439]
name: dag [50152,50155]
===
match
---
dictorsetmaker [25947,26326]
dictorsetmaker [27663,28042]
===
match
---
operator: = [58907,58908]
operator: = [60623,60624]
===
match
---
name: start_date [64731,64741]
name: start_date [66447,66457]
===
match
---
trailer [10007,10022]
trailer [10007,10022]
===
match
---
atom [26704,26790]
atom [28420,28506]
===
match
---
parameters [63872,63878]
parameters [65588,65594]
===
match
---
operator: == [6252,6254]
operator: == [6252,6254]
===
match
---
atom_expr [59270,59299]
atom_expr [60986,61015]
===
match
---
import_name [788,803]
import_name [788,803]
===
match
---
name: task_id [56693,56700]
name: task_id [58409,58416]
===
match
---
operator: , [36204,36205]
operator: , [37920,37921]
===
match
---
name: run_id [70219,70225]
name: run_id [71935,71941]
===
match
---
name: BACKFILL_JOB [50318,50330]
name: BACKFILL_JOB [52034,52046]
===
match
---
comp_op [55891,55897]
comp_op [57607,57613]
===
match
---
name: dag [27948,27951]
name: dag [29664,29667]
===
match
---
suite [10892,10981]
suite [10892,10981]
===
match
---
operator: = [28066,28067]
operator: = [29782,29783]
===
match
---
name: dag [15445,15448]
name: dag [15445,15448]
===
match
---
decorated [53223,54691]
decorated [54939,56407]
===
match
---
name: DagModel [32235,32243]
name: DagModel [33951,33959]
===
match
---
number: 2 [64310,64311]
number: 2 [66026,66027]
===
match
---
name: task_id [42383,42390]
name: task_id [44099,44106]
===
match
---
trailer [17258,17264]
trailer [17258,17264]
===
match
---
string: "test_schedule_dag_once" [42195,42219]
string: "test_schedule_dag_once" [43911,43935]
===
match
---
trailer [14836,14842]
trailer [14836,14842]
===
match
---
simple_stmt [64076,64352]
simple_stmt [65792,66068]
===
match
---
argument [6124,6137]
argument [6124,6137]
===
match
---
argument [69781,69811]
argument [71497,71527]
===
match
---
simple_stmt [20733,20770]
simple_stmt [20733,20770]
===
match
---
operator: = [51769,51770]
operator: = [53485,53486]
===
match
---
operator: = [52537,52538]
operator: = [54253,54254]
===
match
---
atom_expr [37882,37922]
atom_expr [39598,39638]
===
match
---
name: row [24850,24853]
name: row [26566,26569]
===
match
---
atom_expr [42499,42515]
atom_expr [44215,44231]
===
match
---
atom_expr [24253,24269]
atom_expr [25969,25985]
===
match
---
dictorsetmaker [43907,43953]
dictorsetmaker [45623,45669]
===
match
---
string: "0 0 1 */3 *" [46528,46541]
string: "0 0 1 */3 *" [48244,48257]
===
match
---
name: DAG [14043,14046]
name: DAG [14043,14046]
===
match
---
trailer [62761,62779]
trailer [64477,64495]
===
match
---
name: parameterized [46329,46342]
name: parameterized [48045,48058]
===
match
---
argument [16907,16927]
argument [16907,16927]
===
match
---
name: close [65470,65475]
name: close [67186,67191]
===
match
---
name: DagRunType [52053,52063]
name: DagRunType [53769,53779]
===
match
---
operator: , [40297,40298]
operator: , [42013,42014]
===
match
---
trailer [25579,25584]
trailer [27295,27300]
===
match
---
arglist [56748,56769]
arglist [58464,58485]
===
match
---
expr_stmt [21564,21600]
expr_stmt [21564,21600]
===
match
---
operator: , [8145,8146]
operator: , [8145,8146]
===
match
---
simple_stmt [45762,45802]
simple_stmt [47478,47518]
===
match
---
simple_stmt [3452,3464]
simple_stmt [3452,3464]
===
match
---
name: timezone [57533,57541]
name: timezone [59249,59257]
===
match
---
fstring [47252,47289]
fstring [48968,49005]
===
match
---
name: task_id [14848,14855]
name: task_id [14848,14855]
===
match
---
operator: } [34924,34925]
operator: } [36640,36641]
===
match
---
atom_expr [12041,12053]
atom_expr [12041,12053]
===
match
---
name: DagRun [51122,51128]
name: DagRun [52838,52844]
===
match
---
simple_stmt [23657,23689]
simple_stmt [23657,23689]
===
match
---
suite [66930,67306]
suite [68646,69022]
===
match
---
name: dag [7186,7189]
name: dag [7186,7189]
===
match
---
name: dag [64230,64233]
name: dag [65946,65949]
===
match
---
simple_stmt [48785,48802]
simple_stmt [50501,50518]
===
match
---
trailer [63198,63229]
trailer [64914,64945]
===
match
---
suite [48153,49389]
suite [49869,51105]
===
match
---
operator: } [62015,62016]
operator: } [63731,63732]
===
match
---
name: num [69944,69947]
name: num [71660,71663]
===
match
---
trailer [60758,60781]
trailer [62474,62497]
===
match
---
name: depth [13077,13082]
name: depth [13077,13082]
===
match
---
trailer [48439,48453]
trailer [50155,50169]
===
match
---
operator: , [1478,1479]
operator: , [1478,1479]
===
match
---
name: following_schedule [41910,41928]
name: following_schedule [43626,43644]
===
match
---
name: dag [11809,11812]
name: dag [11809,11812]
===
match
---
operator: , [51752,51753]
operator: , [53468,53469]
===
match
---
expr_stmt [48333,48378]
expr_stmt [50049,50094]
===
match
---
simple_stmt [64701,64756]
simple_stmt [66417,66472]
===
match
---
arglist [40696,40717]
arglist [42412,42433]
===
match
---
operator: = [47082,47083]
operator: = [48798,48799]
===
match
---
trailer [38446,38460]
trailer [40162,40176]
===
match
---
argument [41189,41212]
argument [42905,42928]
===
match
---
trailer [34673,34680]
trailer [36389,36396]
===
match
---
name: one [29537,29540]
name: one [31253,31256]
===
match
---
atom_expr [50692,50722]
atom_expr [52408,52438]
===
match
---
trailer [52761,53013]
trailer [54477,54729]
===
match
---
operator: = [7922,7923]
operator: = [7922,7923]
===
match
---
operator: = [70356,70357]
operator: = [72072,72073]
===
match
---
trailer [50148,50155]
trailer [51864,51871]
===
match
---
atom_expr [24223,24239]
atom_expr [25939,25955]
===
match
---
operator: = [43270,43271]
operator: = [44986,44987]
===
match
---
name: start_date [43410,43420]
name: start_date [45126,45136]
===
match
---
string: """         Tests scheduling a dag scheduled for @once - should be scheduled the first time         it is called, and not scheduled the second.         """ [42022,42177]
string: """         Tests scheduling a dag scheduled for @once - should be scheduled the first time         it is called, and not scheduled the second.         """ [43738,43893]
===
match
---
name: BaseOperator [23768,23780]
name: BaseOperator [23768,23780]
===
match
---
operator: , [48921,48922]
operator: , [50637,50638]
===
match
---
argument [60875,60882]
argument [62591,62598]
===
match
---
operator: = [41388,41389]
operator: = [43104,43105]
===
match
---
testlist_comp [25104,25133]
testlist_comp [26820,26849]
===
match
---
name: dag_run_state [50920,50933]
name: dag_run_state [52636,52649]
===
match
---
dictorsetmaker [35601,35609]
dictorsetmaker [37317,37325]
===
match
---
trailer [3730,3742]
trailer [3730,3742]
===
match
---
string: 't3' [38501,38505]
string: 't3' [40217,40221]
===
match
---
trailer [24345,24348]
trailer [26061,26064]
===
match
---
expr_stmt [53547,53561]
expr_stmt [55263,55277]
===
match
---
simple_stmt [56814,56825]
simple_stmt [58530,58541]
===
match
---
name: TIMEZONE [12438,12446]
name: TIMEZONE [12438,12446]
===
match
---
trailer [11853,11866]
trailer [11853,11866]
===
match
---
name: PRE_TRANSITION [22636,22650]
name: PRE_TRANSITION [22636,22650]
===
match
---
string: 'dag-bulk-sync-0' [25744,25761]
string: 'dag-bulk-sync-0' [27460,27477]
===
match
---
comparison [54530,54554]
comparison [56246,56270]
===
match
---
name: dag [69225,69228]
name: dag [70941,70944]
===
match
---
name: args [44599,44603]
name: args [46315,46319]
===
match
---
expr_stmt [47730,47741]
expr_stmt [49446,49457]
===
match
---
operator: , [30936,30937]
operator: , [32652,32653]
===
match
---
operator: } [25818,25819]
operator: } [27534,27535]
===
match
---
trailer [54086,54093]
trailer [55802,55809]
===
match
---
name: TaskFail [3058,3066]
name: TaskFail [3058,3066]
===
match
---
name: list_ [3183,3188]
name: list_ [3183,3188]
===
match
---
argument [50413,50440]
argument [52129,52156]
===
match
---
trailer [23678,23688]
trailer [23678,23688]
===
match
---
trailer [14889,14905]
trailer [14889,14905]
===
match
---
name: DummyOperator [35444,35457]
name: DummyOperator [37160,37173]
===
match
---
simple_stmt [8531,8607]
simple_stmt [8531,8607]
===
match
---
string: '{{ ds }}' [20135,20145]
string: '{{ ds }}' [20135,20145]
===
match
---
trailer [24524,24590]
trailer [26240,26306]
===
match
---
name: dag2 [5995,5999]
name: dag2 [5995,5999]
===
match
---
assert_stmt [39658,39695]
assert_stmt [41374,41411]
===
match
---
name: f [19099,19100]
name: f [19099,19100]
===
match
---
operator: , [50548,50549]
operator: , [52264,52265]
===
match
---
atom_expr [19769,19843]
atom_expr [19769,19843]
===
match
---
arglist [3770,3786]
arglist [3770,3786]
===
match
---
operator: = [43108,43109]
operator: = [44824,44825]
===
match
---
name: DAGsubclass [44638,44649]
name: DAGsubclass [46354,46365]
===
match
---
trailer [41909,41928]
trailer [43625,43644]
===
match
---
name: DagModel [33575,33583]
name: DagModel [35291,35299]
===
match
---
trailer [41250,41259]
trailer [42966,42975]
===
match
---
simple_stmt [45810,45849]
simple_stmt [47526,47565]
===
match
---
name: query [26748,26753]
name: query [28464,28469]
===
match
---
string: "t5" [35512,35516]
string: "t5" [37228,37232]
===
match
---
with_stmt [6963,7093]
with_stmt [6963,7093]
===
match
---
name: path [19085,19089]
name: path [19085,19089]
===
match
---
testlist_comp [25055,25084]
testlist_comp [26771,26800]
===
match
---
assert_stmt [45596,45622]
assert_stmt [47312,47338]
===
match
---
not_test [34548,34569]
not_test [36264,36285]
===
match
---
atom [36032,36042]
atom [37748,37758]
===
match
---
name: DAG [11590,11593]
name: DAG [11590,11593]
===
match
---
atom_expr [37499,37539]
atom_expr [39215,39255]
===
match
---
expr_stmt [35438,35471]
expr_stmt [37154,37187]
===
match
---
comparison [44985,44998]
comparison [46701,46714]
===
match
---
atom_expr [27788,27824]
atom_expr [29504,29540]
===
match
---
name: query [49116,49121]
name: query [50832,50837]
===
match
---
name: task_id [19882,19889]
name: task_id [19882,19889]
===
match
---
name: query [33100,33105]
name: query [34816,34821]
===
match
---
trailer [10707,10724]
trailer [10707,10724]
===
match
---
name: start_date [43284,43294]
name: start_date [45000,45010]
===
match
---
name: dag [1601,1604]
name: dag [1601,1604]
===
match
---
trailer [10275,10281]
trailer [10275,10281]
===
match
---
param [69060,69063]
param [70776,70779]
===
match
---
expr_stmt [70907,70935]
expr_stmt [72623,72651]
===
match
---
trailer [31893,31900]
trailer [33609,33616]
===
match
---
name: default_args [56267,56279]
name: default_args [57983,57995]
===
match
---
trailer [8959,8972]
trailer [8959,8972]
===
match
---
dictorsetmaker [8587,8604]
dictorsetmaker [8587,8604]
===
match
---
name: session [27612,27619]
name: session [29328,29335]
===
match
---
name: match [14890,14895]
name: match [14890,14895]
===
match
---
name: test_dag_naive_start_date_string [10736,10768]
name: test_dag_naive_start_date_string [10736,10768]
===
match
---
trailer [32324,32328]
trailer [34040,34044]
===
match
---
suite [25642,25682]
suite [27358,27398]
===
match
---
operator: , [27575,27576]
operator: , [29291,29292]
===
match
---
trailer [32167,32183]
trailer [33883,33899]
===
match
---
expr_stmt [33938,34020]
expr_stmt [35654,35736]
===
match
---
operator: , [11612,11613]
operator: , [11612,11613]
===
match
---
trailer [9044,9049]
trailer [9044,9049]
===
match
---
atom_expr [30363,30425]
atom_expr [32079,32141]
===
match
---
atom_expr [7017,7045]
atom_expr [7017,7045]
===
match
---
arglist [20620,20679]
arglist [20620,20679]
===
match
---
simple_stmt [18120,18257]
simple_stmt [18120,18257]
===
match
---
name: default_view [29340,29352]
name: default_view [31056,31068]
===
match
---
name: op5 [35484,35487]
name: op5 [37200,37203]
===
match
---
param [42007,42011]
param [43723,43727]
===
match
---
atom_expr [24850,24856]
atom_expr [26566,26572]
===
match
---
atom_expr [9936,9957]
atom_expr [9936,9957]
===
match
---
name: dag_id [42186,42192]
name: dag_id [43902,43908]
===
match
---
simple_stmt [918,949]
simple_stmt [918,949]
===
match
---
name: operator [69471,69479]
name: operator [71187,71195]
===
match
---
assert_stmt [32403,32500]
assert_stmt [34119,34216]
===
match
---
operator: , [49034,49035]
operator: , [50750,50751]
===
match
---
suite [21317,22345]
suite [21317,22345]
===
match
---
argument [53588,53611]
argument [55304,55327]
===
match
---
operator: , [58830,58831]
operator: , [60546,60547]
===
match
---
name: runs [55396,55400]
name: runs [57112,57116]
===
match
---
trailer [33583,33590]
trailer [35299,35306]
===
match
---
argument [34908,34923]
argument [36624,36639]
===
match
---
trailer [40762,40789]
trailer [42478,42505]
===
match
---
operator: = [61183,61184]
operator: = [62899,62900]
===
match
---
arglist [54771,54868]
arglist [56487,56584]
===
match
---
with_stmt [12829,13783]
with_stmt [12829,13783]
===
match
---
name: task_id [60858,60865]
name: task_id [62574,62581]
===
match
---
operator: , [46408,46409]
operator: , [48124,48125]
===
match
---
trailer [2707,2709]
trailer [2707,2709]
===
match
---
arglist [43393,43576]
arglist [45109,45292]
===
match
---
name: set2 [10264,10268]
name: set2 [10264,10268]
===
match
---
arglist [6006,6071]
arglist [6006,6071]
===
match
---
name: outdated_permissions [63015,63035]
name: outdated_permissions [64731,64751]
===
match
---
name: DAG [29850,29853]
name: DAG [31566,31569]
===
match
---
name: sub_dag [38718,38725]
name: sub_dag [40434,40441]
===
match
---
name: sync_to_db [46000,46010]
name: sync_to_db [47716,47726]
===
match
---
string: "test-dag" [24578,24588]
string: "test-dag" [26294,26304]
===
match
---
simple_stmt [57337,57383]
simple_stmt [59053,59099]
===
match
---
name: dag2 [7246,7250]
name: dag2 [7246,7250]
===
match
---
name: default_args [34848,34860]
name: default_args [36564,36576]
===
match
---
name: DAG [48269,48272]
name: DAG [49985,49988]
===
match
---
name: filter [31894,31900]
name: filter [33610,33616]
===
match
---
name: task_decorator [67507,67521]
name: task_decorator [69223,69237]
===
match
---
simple_stmt [19217,19253]
simple_stmt [19217,19253]
===
match
---
name: get [41641,41644]
name: get [43357,43360]
===
match
---
operator: = [36568,36569]
operator: = [38284,38285]
===
match
---
trailer [35800,35814]
trailer [37516,37530]
===
match
---
operator: = [53798,53799]
operator: = [55514,55515]
===
match
---
decorated [70712,71017]
decorated [72428,72733]
===
match
---
expr_stmt [17413,17441]
expr_stmt [17413,17441]
===
match
---
atom [32019,32090]
atom [33735,33806]
===
match
---
string: "t4" [35947,35951]
string: "t4" [37663,37667]
===
match
---
expr_stmt [42788,42838]
expr_stmt [44504,44554]
===
match
---
suite [18510,18546]
suite [18510,18546]
===
match
---
name: assert_queries_count [25376,25396]
name: assert_queries_count [27092,27112]
===
match
---
funcdef [62951,63803]
funcdef [64667,65519]
===
match
---
argument [66128,66152]
argument [67844,67868]
===
match
---
operator: , [68164,68165]
operator: , [69880,69881]
===
match
---
operator: , [50981,50982]
operator: , [52697,52698]
===
match
---
simple_stmt [10238,10256]
simple_stmt [10238,10256]
===
match
---
trailer [29065,29082]
trailer [30781,30798]
===
match
---
name: test_is_paused_subdag [30575,30596]
name: test_is_paused_subdag [32291,32312]
===
match
---
operator: { [29596,29597]
operator: { [31312,31313]
===
match
---
operator: = [35442,35443]
operator: = [37158,37159]
===
match
---
operator: = [64988,64989]
operator: = [66704,66705]
===
match
---
operator: , [46460,46461]
operator: , [48176,48177]
===
match
---
name: prev_local [23325,23335]
name: prev_local [23325,23335]
===
match
---
operator: = [47157,47158]
operator: = [48873,48874]
===
match
---
atom_expr [35879,35906]
atom_expr [37595,37622]
===
match
---
trailer [33646,33659]
trailer [35362,35375]
===
match
---
trailer [39410,39417]
trailer [41126,41133]
===
match
---
simple_stmt [23273,23309]
simple_stmt [23273,23309]
===
match
---
expr_stmt [16780,16803]
expr_stmt [16780,16803]
===
match
---
name: prev_local [22228,22238]
name: prev_local [22228,22238]
===
match
---
operator: = [33485,33486]
operator: = [35201,35202]
===
match
---
number: 1 [66396,66397]
number: 1 [68112,68113]
===
match
---
expr_stmt [57067,57116]
expr_stmt [58783,58832]
===
match
---
simple_stmt [35919,35953]
simple_stmt [37635,37669]
===
match
---
operator: == [20131,20133]
operator: == [20131,20133]
===
match
---
atom_expr [52013,52197]
atom_expr [53729,53913]
===
match
---
simple_stmt [23164,23220]
simple_stmt [23164,23220]
===
match
---
operator: , [61388,61389]
operator: , [63104,63105]
===
match
---
atom_expr [4950,4996]
atom_expr [4950,4996]
===
match
---
operator: @ [49394,49395]
operator: @ [51110,51111]
===
match
---
operator: = [49055,49056]
operator: = [50771,50772]
===
match
---
comparison [10467,10494]
comparison [10467,10494]
===
match
---
arglist [15798,15806]
arglist [15798,15806]
===
match
---
expr_stmt [59144,59193]
expr_stmt [60860,60909]
===
match
---
name: isoformat [47276,47285]
name: isoformat [48992,49001]
===
match
---
operator: == [38095,38097]
operator: == [39811,39813]
===
match
---
argument [11966,12024]
argument [11966,12024]
===
match
---
name: DummyOperator [8876,8889]
name: DummyOperator [8876,8889]
===
match
---
name: clear_db_runs [65555,65568]
name: clear_db_runs [67271,67284]
===
match
---
fstring_string: . [14241,14242]
fstring_string: . [14241,14242]
===
match
---
comparison [47956,47984]
comparison [49672,49700]
===
match
---
name: self [68303,68307]
name: self [70019,70023]
===
match
---
atom_expr [22879,22901]
atom_expr [22879,22901]
===
match
---
arglist [43973,44003]
arglist [45689,45719]
===
match
---
name: tags [26462,26466]
name: tags [28178,28182]
===
match
---
name: redirect_stdout [902,917]
name: redirect_stdout [902,917]
===
match
---
trailer [58708,58924]
trailer [60424,60640]
===
match
---
string: '' [39475,39477]
string: '' [41191,41193]
===
match
---
simple_stmt [47949,47985]
simple_stmt [49665,49701]
===
match
---
atom [10698,10700]
atom [10698,10700]
===
match
---
expr_stmt [31169,31192]
expr_stmt [32885,32908]
===
match
---
operator: = [70273,70274]
operator: = [71989,71990]
===
match
---
name: op4 [10135,10138]
name: op4 [10135,10138]
===
match
---
name: DEFAULT_DATE [30924,30936]
name: DEFAULT_DATE [32640,32652]
===
match
---
trailer [43814,43822]
trailer [45530,45538]
===
match
---
name: DummyOperator [9690,9703]
name: DummyOperator [9690,9703]
===
match
---
name: query [27731,27736]
name: query [29447,29452]
===
match
---
operator: >> [8010,8012]
operator: >> [8010,8012]
===
match
---
operator: , [43752,43753]
operator: , [45468,45469]
===
match
---
arglist [42383,42444]
arglist [44099,44160]
===
match
---
string: """         Test the subdags are never marked to have dagruns created, as they are         handled by the SubDagOperator, not the scheduler         """ [61457,61608]
string: """         Test the subdags are never marked to have dagruns created, as they are         handled by the SubDagOperator, not the scheduler         """ [63173,63324]
===
match
---
atom_expr [59965,59994]
atom_expr [61681,61710]
===
match
---
name: session [41617,41624]
name: session [43333,43340]
===
match
---
name: depth [12525,12530]
name: depth [12525,12530]
===
match
---
trailer [31937,31958]
trailer [33653,33674]
===
match
---
name: close [18432,18437]
name: close [18432,18437]
===
match
---
decorator [46328,46697]
decorator [48044,48413]
===
match
---
name: template_ext [20027,20039]
name: template_ext [20027,20039]
===
match
---
string: 'DAG' [35048,35053]
string: 'DAG' [36764,36769]
===
match
---
simple_stmt [55152,55268]
simple_stmt [56868,56984]
===
match
---
fstring_expr [47262,47288]
fstring_expr [48978,49004]
===
match
---
operator: = [27490,27491]
operator: = [29206,29207]
===
match
---
name: updated_permissions [63250,63269]
name: updated_permissions [64966,64985]
===
match
---
name: topological_sort [9010,9026]
name: topological_sort [9010,9026]
===
match
---
name: repr [24341,24345]
name: repr [26057,26061]
===
match
---
name: following_schedule [23866,23884]
name: following_schedule [23866,23884]
===
match
---
trailer [66513,66515]
trailer [68229,68231]
===
match
---
operator: } [35609,35610]
operator: } [37325,37326]
===
match
---
trailer [44085,44092]
trailer [45801,45808]
===
match
---
trailer [7030,7045]
trailer [7030,7045]
===
match
---
name: unittest [66193,66201]
name: unittest [67909,67917]
===
match
---
name: dag [42261,42264]
name: dag [43977,43980]
===
match
---
name: DEFAULT_DATE [50565,50577]
name: DEFAULT_DATE [52281,52293]
===
match
---
name: VALUE [69852,69857]
name: VALUE [71568,71573]
===
match
---
argument [10795,10836]
argument [10795,10836]
===
match
---
operator: , [59672,59673]
operator: , [61388,61389]
===
match
---
fstring_expr [61803,61819]
fstring_expr [63519,63535]
===
match
---
dictorsetmaker [4249,4264]
dictorsetmaker [4249,4264]
===
match
---
dictorsetmaker [10809,10835]
dictorsetmaker [10809,10835]
===
match
---
name: dag [51681,51684]
name: dag [53397,53400]
===
match
---
atom_expr [27428,27504]
atom_expr [29144,29220]
===
match
---
dictorsetmaker [56300,56361]
dictorsetmaker [58016,58077]
===
match
---
atom_expr [24387,24400]
atom_expr [26103,26116]
===
match
---
trailer [26473,26485]
trailer [28189,28201]
===
match
---
suite [25563,25605]
suite [27279,27321]
===
match
---
trailer [66102,66110]
trailer [67818,67826]
===
match
---
operator: , [17062,17063]
operator: , [17062,17063]
===
match
---
trailer [56747,56770]
trailer [58463,58486]
===
match
---
comparison [6415,6430]
comparison [6415,6430]
===
match
---
argument [48306,48323]
argument [50022,50039]
===
match
---
assert_stmt [66789,66816]
assert_stmt [68505,68532]
===
match
---
arglist [57155,57318]
arglist [58871,59034]
===
match
---
operator: = [18352,18353]
operator: = [18352,18353]
===
match
---
name: filter [53112,53118]
name: filter [54828,54834]
===
match
---
name: run_id [47847,47853]
name: run_id [49563,49569]
===
match
---
operator: == [54460,54462]
operator: == [56176,56178]
===
match
---
name: bash_command [37129,37141]
name: bash_command [38845,38857]
===
match
---
string: 'task_1' [16795,16803]
string: 'task_1' [16795,16803]
===
match
---
trailer [48352,48378]
trailer [50068,50094]
===
match
---
trailer [31175,31185]
trailer [32891,32901]
===
match
---
simple_stmt [44306,44348]
simple_stmt [46022,46064]
===
match
---
argument [44383,44400]
argument [46099,46116]
===
match
---
operator: , [38220,38221]
operator: , [39936,39937]
===
match
---
simple_stmt [21460,21555]
simple_stmt [21460,21555]
===
match
---
simple_stmt [35090,35132]
simple_stmt [36806,36848]
===
match
---
name: op3 [35392,35395]
name: op3 [37108,37111]
===
match
---
atom_expr [16824,16872]
atom_expr [16824,16872]
===
match
---
name: self [67446,67450]
name: self [69162,69166]
===
match
---
name: range [15733,15738]
name: range [15733,15738]
===
match
---
name: subdag [51181,51187]
name: subdag [52897,52903]
===
match
---
name: date [55984,55988]
name: date [57700,57704]
===
match
---
argument [17650,17665]
argument [17650,17665]
===
match
---
name: assert_queries_count [25618,25638]
name: assert_queries_count [27334,27354]
===
match
---
atom_expr [8956,8977]
atom_expr [8956,8977]
===
match
---
simple_stmt [37798,37869]
simple_stmt [39514,39585]
===
match
---
assert_stmt [10691,10726]
assert_stmt [10691,10726]
===
match
---
name: dag [64115,64118]
name: dag [65831,65834]
===
match
---
name: op5 [36038,36041]
name: op5 [37754,37757]
===
match
---
operator: = [43525,43526]
operator: = [45241,45242]
===
match
---
name: state [50137,50142]
name: state [51853,51858]
===
match
---
name: DummyOperator [35879,35892]
name: DummyOperator [37595,37608]
===
match
---
trailer [23916,23926]
trailer [23916,23926]
===
match
---
name: topological_list [8236,8252]
name: topological_list [8236,8252]
===
match
---
operator: , [26846,26847]
operator: , [28562,28563]
===
match
---
name: owner [60884,60889]
name: owner [62600,62605]
===
match
---
operator: , [15680,15681]
operator: , [15680,15681]
===
match
---
name: task_id [48353,48360]
name: task_id [50069,50076]
===
match
---
trailer [62168,62180]
trailer [63884,63896]
===
match
---
atom_expr [34500,34515]
atom_expr [36216,36231]
===
match
---
name: dag [5911,5914]
name: dag [5911,5914]
===
match
---
operator: , [62263,62264]
operator: , [63979,63980]
===
match
---
operator: = [53489,53490]
operator: = [55205,55206]
===
match
---
simple_stmt [41247,41340]
simple_stmt [42963,43056]
===
match
---
trailer [31729,31736]
trailer [33445,33452]
===
match
---
name: end_date [55932,55940]
name: end_date [57648,57656]
===
match
---
trailer [43180,43198]
trailer [44896,44914]
===
match
---
operator: >> [36022,36024]
operator: >> [37738,37740]
===
match
---
operator: } [18649,18650]
operator: } [18649,18650]
===
match
---
operator: , [28515,28516]
operator: , [30231,30232]
===
match
---
string: 'owner' [8587,8594]
string: 'owner' [8587,8594]
===
match
---
trailer [5059,5061]
trailer [5059,5061]
===
match
---
operator: , [37422,37423]
operator: , [39138,39139]
===
match
---
operator: = [23663,23664]
operator: = [23663,23664]
===
match
---
string: 'dag_paused' [32674,32686]
string: 'dag_paused' [34390,34402]
===
match
---
name: dag [34935,34938]
name: dag [36651,36654]
===
match
---
suite [7313,8480]
suite [7313,8480]
===
match
---
name: set1 [10183,10187]
name: set1 [10183,10187]
===
match
---
name: calculated_weight [16256,16273]
name: calculated_weight [16256,16273]
===
match
---
argument [30802,30822]
argument [32518,32538]
===
match
---
name: current_task [16048,16060]
name: current_task [16048,16060]
===
match
---
atom_expr [33041,33072]
atom_expr [34757,34788]
===
match
---
operator: = [7152,7153]
operator: = [7152,7153]
===
match
---
name: self [8193,8197]
name: self [8193,8197]
===
match
---
trailer [31518,31539]
trailer [33234,33255]
===
match
---
operator: { [62415,62416]
operator: { [64131,64132]
===
match
---
operator: = [35419,35420]
operator: = [37135,37136]
===
match
---
name: dag [52013,52016]
name: dag [53729,53732]
===
match
---
name: dag [43144,43147]
name: dag [44860,44863]
===
match
---
expr_stmt [41059,41094]
expr_stmt [42775,42810]
===
match
---
suite [36963,37180]
suite [38679,38896]
===
match
---
argument [27560,27575]
argument [29276,29291]
===
match
---
argument [61977,62017]
argument [63693,63733]
===
match
---
name: task_id [36363,36370]
name: task_id [38079,38086]
===
match
---
decorator [68500,68516]
decorator [70216,70232]
===
match
---
with_stmt [37383,37673]
with_stmt [39099,39389]
===
match
---
testlist_comp [51320,51364]
testlist_comp [53036,53080]
===
match
---
name: self [38300,38304]
name: self [40016,40020]
===
match
---
name: session [28101,28108]
name: session [29817,29824]
===
match
---
expr_stmt [7586,7716]
expr_stmt [7586,7716]
===
match
---
name: setUp [65526,65531]
name: setUp [67242,67247]
===
match
---
comparison [59209,59251]
comparison [60925,60967]
===
match
---
expr_stmt [45897,45931]
expr_stmt [47613,47647]
===
match
---
trailer [48759,48776]
trailer [50475,50492]
===
match
---
string: ', ' [29205,29209]
string: ', ' [30921,30925]
===
match
---
trailer [27730,27736]
trailer [29446,29452]
===
match
---
name: task_dict [38672,38681]
name: task_dict [40388,40397]
===
match
---
suite [47721,47985]
suite [49437,49701]
===
match
---
trailer [13500,13506]
trailer [13500,13506]
===
match
---
name: task_id [8890,8897]
name: task_id [8890,8897]
===
match
---
name: operator [69152,69160]
name: operator [70868,70876]
===
match
---
name: range [65860,65865]
name: range [67576,67581]
===
match
---
comparison [45769,45801]
comparison [47485,47517]
===
match
---
with_item [19547,19590]
with_item [19547,19590]
===
match
---
operator: == [39400,39402]
operator: == [41116,41118]
===
match
---
expr_stmt [3393,3404]
expr_stmt [3393,3404]
===
match
---
atom_expr [48209,48231]
atom_expr [49925,49947]
===
match
---
expr_stmt [55001,55050]
expr_stmt [56717,56766]
===
match
---
atom_expr [27062,27073]
atom_expr [28778,28789]
===
match
---
expr_stmt [51574,51635]
expr_stmt [53290,53351]
===
match
---
simple_stmt [25413,25440]
simple_stmt [27129,27156]
===
match
---
name: convert [22198,22205]
name: convert [22198,22205]
===
match
---
name: dag [28188,28191]
name: dag [29904,29907]
===
match
---
trailer [11781,11793]
trailer [11781,11793]
===
match
---
simple_stmt [43861,43891]
simple_stmt [45577,45607]
===
match
---
name: create_dagrun [52017,52030]
name: create_dagrun [53733,53746]
===
match
---
name: range [13026,13031]
name: range [13026,13031]
===
match
---
name: _occur_before [8274,8287]
name: _occur_before [8274,8287]
===
match
---
comparison [44868,44878]
comparison [46584,46594]
===
match
---
trailer [49253,49255]
trailer [50969,50971]
===
match
---
suite [55143,55998]
suite [56859,57714]
===
match
---
trailer [28169,28186]
trailer [29885,29902]
===
match
---
atom_expr [69147,69160]
atom_expr [70863,70876]
===
match
---
operator: = [28887,28888]
operator: = [30603,30604]
===
match
---
atom_expr [42943,42965]
atom_expr [44659,44681]
===
match
---
name: set2 [10405,10409]
name: set2 [10405,10409]
===
match
---
name: DummyOperator [51650,51663]
name: DummyOperator [53366,53379]
===
match
---
name: task [20115,20119]
name: task [20115,20119]
===
match
---
operator: = [17855,17856]
operator: = [17855,17856]
===
match
---
trailer [18692,18694]
trailer [18692,18694]
===
match
---
trailer [3051,3057]
trailer [3051,3057]
===
match
---
string: """         Tests if fractional seconds are stored in the database         """ [43014,43092]
string: """         Tests if fractional seconds are stored in the database         """ [44730,44808]
===
match
---
name: dag [42357,42360]
name: dag [44073,44076]
===
match
---
name: next_dagrun_after_date [55779,55801]
name: next_dagrun_after_date [57495,57517]
===
match
---
arglist [48273,48323]
arglist [49989,50039]
===
match
---
trailer [53466,53471]
trailer [55182,55187]
===
match
---
operator: = [4967,4968]
operator: = [4967,4968]
===
match
---
lambdef [40288,40297]
lambdef [42004,42013]
===
match
---
number: 1 [62261,62262]
number: 1 [63977,63978]
===
match
---
trailer [31926,31933]
trailer [33642,33649]
===
match
---
simple_stmt [45007,45035]
simple_stmt [46723,46751]
===
match
---
name: dag [56821,56824]
name: dag [58537,58540]
===
match
---
trailer [2484,2486]
trailer [2484,2486]
===
match
---
operator: = [62242,62243]
operator: = [63958,63959]
===
match
---
expr_stmt [3295,3307]
expr_stmt [3295,3307]
===
match
---
trailer [17463,17468]
trailer [17463,17468]
===
match
---
simple_stmt [39504,39650]
simple_stmt [41220,41366]
===
match
---
name: warns [63665,63670]
name: warns [65381,65386]
===
match
---
name: DAG [7599,7602]
name: DAG [7599,7602]
===
match
---
name: timezone [12161,12169]
name: timezone [12161,12169]
===
match
---
argument [43485,43506]
argument [45201,45222]
===
match
---
name: set_upstream [14732,14744]
name: set_upstream [14732,14744]
===
match
---
with_item [36190,36237]
with_item [37906,37953]
===
match
---
operator: == [49372,49374]
operator: == [51088,51090]
===
match
---
operator: , [1407,1408]
operator: , [1407,1408]
===
match
---
operator: , [53855,53856]
operator: , [55571,55572]
===
match
---
simple_stmt [34375,34450]
simple_stmt [36091,36166]
===
match
---
expr_stmt [29092,29164]
expr_stmt [30808,30880]
===
match
---
name: timezone [70274,70282]
name: timezone [71990,71998]
===
match
---
trailer [40156,40370]
trailer [41872,42086]
===
match
---
name: dag_ [44784,44788]
name: dag_ [46500,46504]
===
match
---
simple_stmt [67214,67236]
simple_stmt [68930,68952]
===
match
---
name: prev_local [21114,21124]
name: prev_local [21114,21124]
===
match
---
simple_stmt [2495,2511]
simple_stmt [2495,2511]
===
match
---
expr_stmt [53640,53685]
expr_stmt [55356,55401]
===
match
---
operator: , [18044,18045]
operator: , [18044,18045]
===
match
---
string: 'start_date' [12377,12389]
string: 'start_date' [12377,12389]
===
match
---
operator: = [51818,51819]
operator: = [53534,53535]
===
match
---
expr_stmt [36297,36330]
expr_stmt [38013,38046]
===
match
---
trailer [31571,31573]
trailer [33287,33289]
===
match
---
atom_expr [32252,32270]
atom_expr [33968,33986]
===
match
---
name: task_id [38401,38408]
name: task_id [40117,40124]
===
match
---
arglist [46813,46874]
arglist [48529,48590]
===
match
---
operator: = [50262,50263]
operator: = [51978,51979]
===
match
---
name: op4 [8870,8873]
name: op4 [8870,8873]
===
match
---
name: schedule_interval [58851,58868]
name: schedule_interval [60567,60584]
===
match
---
arglist [32235,32270]
arglist [33951,33986]
===
match
---
trailer [31424,31461]
trailer [33140,33177]
===
match
---
assert_stmt [25922,26396]
assert_stmt [27638,28112]
===
match
---
comparison [18127,18256]
comparison [18127,18256]
===
match
---
arglist [67021,67059]
arglist [68737,68775]
===
match
---
name: conf [33713,33717]
name: conf [35429,35433]
===
match
---
operator: , [20007,20008]
operator: , [20007,20008]
===
match
---
operator: , [11964,11965]
operator: , [11964,11965]
===
match
---
atom_expr [47555,47624]
atom_expr [49271,49340]
===
match
---
atom_expr [70050,70063]
atom_expr [71766,71779]
===
match
---
trailer [36316,36330]
trailer [38032,38046]
===
match
---
atom_expr [45839,45848]
atom_expr [47555,47564]
===
match
---
name: dag_decorator [1608,1621]
name: dag_decorator [1608,1621]
===
match
---
atom [15473,15821]
atom [15473,15821]
===
match
---
name: convert [21974,21981]
name: convert [21974,21981]
===
match
---
trailer [33760,33762]
trailer [35476,35478]
===
match
---
name: set2 [10490,10494]
name: set2 [10490,10494]
===
match
---
trailer [40743,40762]
trailer [42459,42478]
===
match
---
trailer [19772,19843]
trailer [19772,19843]
===
match
---
name: session [31355,31362]
name: session [33071,33078]
===
match
---
trailer [27630,27638]
trailer [29346,29354]
===
match
---
string: 'dummy' [63995,64002]
string: 'dummy' [65711,65718]
===
match
---
trailer [53721,53723]
trailer [55437,55439]
===
match
---
argument [18231,18246]
argument [18231,18246]
===
match
---
trailer [50317,50330]
trailer [52033,52046]
===
match
---
name: op3 [9091,9094]
name: op3 [9091,9094]
===
match
---
operator: , [31529,31530]
operator: , [33245,33246]
===
match
---
expr_stmt [29014,29042]
expr_stmt [30730,30758]
===
match
---
number: 2015 [54830,54834]
number: 2015 [56546,56550]
===
match
---
simple_stmt [68090,68104]
simple_stmt [69806,69820]
===
match
---
trailer [33164,33168]
trailer [34880,34884]
===
match
---
atom_expr [50731,50761]
atom_expr [52447,52477]
===
match
---
trailer [30370,30376]
trailer [32086,32092]
===
match
---
argument [35366,35378]
argument [37082,37094]
===
match
---
atom_expr [50880,50906]
atom_expr [52596,52622]
===
match
---
name: DAG [30149,30152]
name: DAG [31865,31868]
===
match
---
argument [27979,27998]
argument [29695,29714]
===
match
---
name: DagRunType [40556,40566]
name: DagRunType [42272,42282]
===
match
---
assert_stmt [6408,6430]
assert_stmt [6408,6430]
===
match
---
name: dag_decorator [68912,68925]
name: dag_decorator [70628,70641]
===
match
---
atom_expr [66193,66210]
atom_expr [67909,67926]
===
match
---
name: dags_needing_dagruns [64436,64456]
name: dags_needing_dagruns [66152,66172]
===
match
---
operator: = [62260,62261]
operator: = [63976,63977]
===
match
---
name: task_id [30994,31001]
name: task_id [32710,32717]
===
match
---
operator: , [62400,62401]
operator: , [64116,64117]
===
match
---
param [24097,24101]
param [25813,25817]
===
match
---
name: ti3 [17164,17167]
name: ti3 [17164,17167]
===
match
---
name: owner [55623,55628]
name: owner [57339,57344]
===
match
---
string: 'airflow' [56309,56318]
string: 'airflow' [58025,58034]
===
match
---
name: re [12572,12574]
name: re [12572,12574]
===
match
---
name: DagModel [29503,29511]
name: DagModel [31219,31227]
===
match
---
operator: = [21914,21915]
operator: = [21914,21915]
===
match
---
operator: , [20416,20417]
operator: , [20416,20417]
===
match
---
arglist [45950,45986]
arglist [47666,47702]
===
match
---
name: is_active [64326,64335]
name: is_active [66042,66051]
===
match
---
name: staticmethod [3142,3154]
name: staticmethod [3142,3154]
===
match
---
operator: = [30661,30662]
operator: = [32377,32378]
===
match
---
name: State [41470,41475]
name: State [43186,43191]
===
match
---
operator: @ [70818,70819]
operator: @ [72534,72535]
===
match
---
name: dag_id [47088,47094]
name: dag_id [48804,48810]
===
match
---
string: 't2' [56701,56705]
string: 't2' [58417,58421]
===
match
---
expr_stmt [12525,12534]
expr_stmt [12525,12534]
===
match
---
atom_expr [46624,46650]
atom_expr [48340,48366]
===
match
---
name: session [53953,53960]
name: session [55669,55676]
===
match
---
assert_stmt [8109,8177]
assert_stmt [8109,8177]
===
match
---
name: DAG [5551,5554]
name: DAG [5551,5554]
===
match
---
operator: = [7105,7106]
operator: = [7105,7106]
===
match
---
name: dr [47956,47958]
name: dr [49672,49674]
===
match
---
name: permissions [63091,63102]
name: permissions [64807,64818]
===
match
---
string: 'op1' [19246,19251]
string: 'op1' [19246,19251]
===
match
---
assert_stmt [36601,36631]
assert_stmt [38317,38347]
===
match
---
expr_stmt [11949,12025]
expr_stmt [11949,12025]
===
match
---
name: run_type [39227,39235]
name: run_type [40943,40951]
===
match
---
name: dag3 [58026,58030]
name: dag3 [59742,59746]
===
match
---
operator: @ [67842,67843]
operator: @ [69558,69559]
===
match
---
trailer [8438,8479]
trailer [8438,8479]
===
match
---
funcdef [64561,65478]
funcdef [66277,67194]
===
match
---
trailer [47665,47672]
trailer [49381,49388]
===
match
---
simple_stmt [38064,38075]
simple_stmt [39780,39791]
===
match
---
name: run_id [47242,47248]
name: run_id [48958,48964]
===
match
---
param [5436,5440]
param [5436,5440]
===
match
---
operator: , [24974,24975]
operator: , [26690,26691]
===
match
---
name: DAG [39060,39063]
name: DAG [40776,40779]
===
match
---
operator: = [6178,6179]
operator: = [6178,6179]
===
match
---
name: task_id [35504,35511]
name: task_id [37220,37227]
===
match
---
assert_stmt [66825,66859]
assert_stmt [68541,68575]
===
match
---
operator: = [17327,17328]
operator: = [17327,17328]
===
match
---
trailer [53059,53098]
trailer [54775,54814]
===
match
---
trailer [63515,63586]
trailer [65231,65302]
===
match
---
name: session [25157,25164]
name: session [26873,26880]
===
match
---
expr_stmt [19066,19106]
expr_stmt [19066,19106]
===
match
---
atom_expr [37558,37594]
atom_expr [39274,39310]
===
match
---
simple_stmt [48240,48255]
simple_stmt [49956,49971]
===
match
---
name: match [13426,13431]
name: match [13426,13431]
===
match
---
trailer [25274,25276]
trailer [26990,26992]
===
match
---
assert_stmt [21228,21246]
assert_stmt [21228,21246]
===
match
---
operator: , [41656,41657]
operator: , [43372,43373]
===
match
---
name: state [50344,50349]
name: state [52060,52065]
===
match
---
operator: = [55429,55430]
operator: = [57145,57146]
===
match
---
comparison [22228,22281]
comparison [22228,22281]
===
match
---
simple_stmt [33534,33624]
simple_stmt [35250,35340]
===
match
---
suite [16545,16672]
suite [16545,16672]
===
match
---
return_stmt [18523,18545]
return_stmt [18523,18545]
===
match
---
name: op1 [35601,35604]
name: op1 [37317,37320]
===
match
---
name: subdag [61622,61628]
name: subdag [63338,63344]
===
match
---
name: State [48519,48524]
name: State [50235,50240]
===
match
---
operator: , [66398,66399]
operator: , [68114,68115]
===
match
---
name: next_date [59926,59935]
name: next_date [61642,61651]
===
match
---
operator: = [49982,49983]
operator: = [51698,51699]
===
match
---
simple_stmt [6617,6640]
simple_stmt [6617,6640]
===
match
---
operator: = [40660,40661]
operator: = [42376,42377]
===
match
---
atom_expr [16276,16302]
atom_expr [16276,16302]
===
match
---
operator: >> [36400,36402]
operator: >> [38116,38118]
===
match
---
number: 2 [9305,9306]
number: 2 [9305,9306]
===
match
---
simple_stmt [3472,3502]
simple_stmt [3472,3502]
===
match
---
expr_stmt [34063,34091]
expr_stmt [35779,35807]
===
match
---
name: dag_id [33442,33448]
name: dag_id [35158,35164]
===
match
---
name: outdated_permissions [63725,63745]
name: outdated_permissions [65441,65461]
===
match
---
operator: , [59675,59676]
operator: , [61391,61392]
===
match
---
suite [67341,67719]
suite [69057,69435]
===
match
---
trailer [51163,51195]
trailer [52879,52911]
===
match
---
name: dag_subclass [45822,45834]
name: dag_subclass [47538,47550]
===
match
---
trailer [22238,22248]
trailer [22238,22248]
===
match
---
name: op5 [6655,6658]
name: op5 [6655,6658]
===
match
---
atom_expr [19910,19925]
atom_expr [19910,19925]
===
match
---
trailer [59982,59994]
trailer [61698,61710]
===
match
---
comparison [29503,29535]
comparison [31219,31251]
===
match
---
simple_stmt [56783,56801]
simple_stmt [58499,58517]
===
match
---
funcdef [68799,69626]
funcdef [70515,71342]
===
match
---
string: 'dag-bulk-sync-3' [26294,26311]
string: 'dag-bulk-sync-3' [28010,28027]
===
match
---
name: next_date [58360,58369]
name: next_date [60076,60085]
===
match
---
name: tree_view [36487,36496]
name: tree_view [38203,38212]
===
match
---
operator: == [54550,54552]
operator: == [56266,56268]
===
match
---
operator: = [21529,21530]
operator: = [21529,21530]
===
match
---
trailer [53659,53685]
trailer [55375,55401]
===
match
---
arglist [15376,15440]
arglist [15376,15440]
===
match
---
trailer [59182,59193]
trailer [60898,60909]
===
match
---
operator: , [8460,8461]
operator: , [8460,8461]
===
match
---
fstring [18530,18545]
fstring [18530,18545]
===
match
---
argument [28624,28638]
argument [30340,30354]
===
match
---
number: 2 [20410,20411]
number: 2 [20410,20411]
===
match
---
trailer [34714,34716]
trailer [36430,36432]
===
match
---
name: i [16016,16017]
name: i [16016,16017]
===
match
---
operator: = [58151,58152]
operator: = [59867,59868]
===
match
---
atom_expr [6157,6195]
atom_expr [6157,6195]
===
match
---
name: start [20353,20358]
name: start [20353,20358]
===
match
---
operator: == [21240,21242]
operator: == [21240,21242]
===
match
---
simple_stmt [29414,29450]
simple_stmt [31130,31166]
===
match
---
testlist_comp [46595,46608]
testlist_comp [48311,48324]
===
match
---
name: DEFAULT_DATE [49851,49863]
name: DEFAULT_DATE [51567,51579]
===
match
---
fstring_end: ' [62016,62017]
fstring_end: ' [63732,63733]
===
match
---
trailer [48636,48642]
trailer [50352,50358]
===
match
---
trailer [63307,63323]
trailer [65023,65039]
===
match
---
simple_stmt [40819,40842]
simple_stmt [42535,42558]
===
match
---
operator: , [31263,31264]
operator: , [32979,32980]
===
match
---
operator: , [59247,59248]
operator: , [60963,60964]
===
match
---
assert_stmt [8262,8329]
assert_stmt [8262,8329]
===
match
---
assert_stmt [45476,45511]
assert_stmt [47192,47227]
===
match
---
operator: , [21511,21512]
operator: , [21511,21512]
===
match
---
trailer [29158,29162]
trailer [30874,30878]
===
match
---
operator: , [66810,66811]
operator: , [68526,68527]
===
match
---
testlist_comp [65679,65681]
testlist_comp [67395,67397]
===
match
---
simple_stmt [67684,67719]
simple_stmt [69400,69435]
===
match
---
comparison [46972,47014]
comparison [48688,48730]
===
match
---
name: test_resolve_template_files_value [18848,18881]
name: test_resolve_template_files_value [18848,18881]
===
match
---
operator: = [30006,30007]
operator: = [31722,31723]
===
match
---
expr_stmt [40086,40138]
expr_stmt [41802,41854]
===
match
---
name: DummyOperator [60844,60857]
name: DummyOperator [62560,62573]
===
match
---
operator: , [49063,49064]
operator: , [50779,50780]
===
match
---
name: State [53360,53365]
name: State [55076,55081]
===
match
---
name: set [27029,27032]
name: set [28745,28748]
===
match
---
argument [47890,47906]
argument [49606,49622]
===
match
---
operator: , [55540,55541]
operator: , [57256,57257]
===
match
---
name: set [32484,32487]
name: set [34200,34203]
===
match
---
name: dag [36483,36486]
name: dag [38199,38202]
===
match
---
trailer [26590,26592]
trailer [28306,28308]
===
match
---
name: orm_dag [30489,30496]
name: orm_dag [32205,32212]
===
match
---
operator: = [19992,19993]
operator: = [19992,19993]
===
match
---
name: on_failure_callback [40311,40330]
name: on_failure_callback [42027,42046]
===
match
---
trailer [41399,41409]
trailer [43115,43125]
===
match
---
atom_expr [44312,44347]
atom_expr [46028,46063]
===
match
---
name: stage [14634,14639]
name: stage [14634,14639]
===
match
---
name: models [5544,5550]
name: models [5544,5550]
===
match
---
name: NONE [47619,47623]
name: NONE [49335,49339]
===
match
---
trailer [35457,35471]
trailer [37173,37187]
===
match
---
argument [53677,53684]
argument [55393,55400]
===
match
---
name: op2 [9970,9973]
name: op2 [9970,9973]
===
match
---
atom_expr [17014,17023]
atom_expr [17014,17023]
===
match
---
trailer [44495,44536]
trailer [46211,46252]
===
match
---
name: isoformat [21856,21865]
name: isoformat [21856,21865]
===
match
---
operator: == [24401,24403]
operator: == [26117,26119]
===
match
---
operator: , [10952,10953]
operator: , [10952,10953]
===
match
---
name: self [18475,18479]
name: self [18475,18479]
===
match
---
import_as_names [2326,2354]
import_as_names [2326,2354]
===
match
---
expr_stmt [24136,24214]
expr_stmt [25852,25930]
===
match
---
name: _ [55738,55739]
name: _ [57454,57455]
===
match
---
atom_expr [57089,57116]
atom_expr [58805,58832]
===
match
---
operator: , [26212,26213]
operator: , [27928,27929]
===
match
---
dotted_name [1822,1838]
dotted_name [1822,1838]
===
match
---
arglist [7616,7706]
arglist [7616,7706]
===
match
---
name: next_dagrun [41829,41840]
name: next_dagrun [43545,43556]
===
match
---
name: next_date [54888,54897]
name: next_date [56604,56613]
===
match
---
expr_stmt [19971,20009]
expr_stmt [19971,20009]
===
match
---
atom_expr [34029,34040]
atom_expr [35745,35756]
===
match
---
operator: , [20408,20409]
operator: , [20408,20409]
===
match
---
number: 3 [9391,9392]
number: 3 [9391,9392]
===
match
---
atom_expr [32670,32717]
atom_expr [34386,34433]
===
match
---
trailer [33707,33709]
trailer [35423,35425]
===
match
---
name: self [47715,47719]
name: self [49431,49435]
===
match
---
argument [40452,40469]
argument [42168,42185]
===
match
---
name: start_date [50819,50829]
name: start_date [52535,52545]
===
match
---
string: 'dag.subdag' [30633,30645]
string: 'dag.subdag' [32349,32361]
===
match
---
arglist [33722,33753]
arglist [35438,35469]
===
match
---
trailer [30536,30542]
trailer [32252,32258]
===
match
---
parameters [11032,11038]
parameters [11032,11038]
===
match
---
trailer [46288,46295]
trailer [48004,48011]
===
match
---
name: dag_id [64899,64905]
name: dag_id [66615,66621]
===
match
---
operator: , [48368,48369]
operator: , [50084,50085]
===
match
---
operator: = [39994,39995]
operator: = [41710,41711]
===
match
---
name: sync_to_db [29055,29065]
name: sync_to_db [30771,30781]
===
match
---
string: "t5" [35993,35997]
string: "t5" [37709,37713]
===
match
---
operator: } [25908,25909]
operator: } [27624,27625]
===
match
---
assert_stmt [16319,16361]
assert_stmt [16319,16361]
===
match
---
arglist [50298,50441]
arglist [52014,52157]
===
match
---
trailer [10099,10117]
trailer [10099,10117]
===
match
---
expr_stmt [27715,27765]
expr_stmt [29431,29481]
===
match
---
suite [2433,63803]
suite [2433,65519]
===
match
---
simple_stmt [61217,61274]
simple_stmt [62933,62990]
===
match
---
operator: = [15616,15617]
operator: = [15616,15617]
===
match
---
trailer [9793,9806]
trailer [9793,9806]
===
match
---
with_stmt [68693,68794]
with_stmt [70409,70510]
===
match
---
atom_expr [29024,29042]
atom_expr [30740,30758]
===
match
---
atom_expr [56679,56715]
atom_expr [58395,58431]
===
match
---
trailer [20593,20600]
trailer [20593,20600]
===
match
---
operator: , [53426,53427]
operator: , [55142,55143]
===
match
---
name: subdag_id [32062,32071]
name: subdag_id [33778,33787]
===
match
---
trailer [27180,27183]
trailer [28896,28899]
===
match
---
operator: = [19222,19223]
operator: = [19222,19223]
===
match
---
arglist [56693,56714]
arglist [58409,58430]
===
match
---
trailer [54161,54163]
trailer [55877,55879]
===
match
---
name: dag [59899,59902]
name: dag [61615,61618]
===
match
---
trailer [31232,31274]
trailer [32948,32990]
===
match
---
argument [9704,9715]
argument [9704,9715]
===
match
---
suite [70626,71099]
suite [72342,72815]
===
match
---
simple_stmt [36601,36632]
simple_stmt [38317,38348]
===
match
---
trailer [34656,34658]
trailer [36372,36374]
===
match
---
string: 'test-invalid-orientation' [5341,5367]
string: 'test-invalid-orientation' [5341,5367]
===
match
---
name: DAG [63512,63515]
name: DAG [65228,65231]
===
match
---
argument [41380,41409]
argument [43096,43125]
===
match
---
trailer [55801,55807]
trailer [57517,57523]
===
match
---
comparison [6310,6331]
comparison [6310,6331]
===
match
---
trailer [49645,49653]
trailer [51361,51369]
===
match
---
trailer [21425,21434]
trailer [21425,21434]
===
match
---
atom_expr [66875,66886]
atom_expr [68591,68602]
===
match
---
name: test_dag_start_date_propagates_to_end_date [10990,11032]
name: test_dag_start_date_propagates_to_end_date [10990,11032]
===
match
---
expr_stmt [12924,13097]
expr_stmt [12924,13097]
===
match
---
atom_expr [43362,43586]
atom_expr [45078,45302]
===
match
---
name: execution_date [43446,43460]
name: execution_date [45162,45176]
===
match
---
comparison [29558,29616]
comparison [31274,31332]
===
match
---
atom_expr [47520,47540]
atom_expr [49236,49256]
===
match
---
argument [44586,44603]
argument [46302,46319]
===
match
---
name: row [27177,27180]
name: row [28893,28896]
===
match
---
name: match [14837,14842]
name: match [14837,14842]
===
match
---
trailer [63605,63620]
trailer [65321,65336]
===
match
---
operator: == [3091,3093]
operator: == [3091,3093]
===
match
---
name: default_args [43986,43998]
name: default_args [45702,45714]
===
match
---
name: dr [47239,47241]
name: dr [48955,48957]
===
match
---
operator: , [56421,56422]
operator: , [58137,58138]
===
match
---
arglist [54980,54990]
arglist [56696,56706]
===
match
---
suite [24732,25320]
suite [26448,27036]
===
match
---
operator: >> [36393,36395]
operator: >> [38109,38111]
===
match
---
operator: = [24140,24141]
operator: = [25856,25857]
===
match
---
name: dst_rule [20418,20426]
name: dst_rule [20418,20426]
===
match
---
assert_stmt [22221,22281]
assert_stmt [22221,22281]
===
match
---
funcdef [32877,33319]
funcdef [34593,35035]
===
match
---
atom_expr [13386,13408]
atom_expr [13386,13408]
===
match
---
name: DummyOperator [27546,27559]
name: DummyOperator [29262,29275]
===
match
---
trailer [46670,46678]
trailer [48386,48394]
===
match
---
trailer [52652,52658]
trailer [54368,54374]
===
match
---
param [47063,47067]
param [48779,48783]
===
match
---
assert_stmt [69961,69995]
assert_stmt [71677,71711]
===
match
---
name: close [30537,30542]
name: close [32253,32258]
===
match
---
name: next_dagrun_create_after [64258,64282]
name: next_dagrun_create_after [65974,65998]
===
match
---
decorated [65633,66168]
decorated [67349,67884]
===
match
---
name: dag [64795,64798]
name: dag [66511,66514]
===
match
---
name: task_id [35939,35946]
name: task_id [37655,37662]
===
match
---
atom_expr [47131,47223]
atom_expr [48847,48939]
===
match
---
funcdef [39835,40842]
funcdef [41551,42558]
===
match
---
suite [14694,14756]
suite [14694,14756]
===
match
---
name: subdag [52749,52755]
name: subdag [54465,54471]
===
match
---
expr_stmt [19217,19252]
expr_stmt [19217,19252]
===
match
---
trailer [48223,48231]
trailer [49939,49947]
===
match
---
number: 1 [41092,41093]
number: 1 [42808,42809]
===
match
---
atom [26624,26700]
atom [28340,28416]
===
match
---
operator: , [66152,66153]
operator: , [67868,67869]
===
match
---
trailer [31433,31440]
trailer [33149,33156]
===
match
---
trailer [50744,50761]
trailer [52460,52477]
===
match
---
name: test_set_params_for_dag [70596,70619]
name: test_set_params_for_dag [72312,72335]
===
match
---
atom_expr [17596,17666]
atom_expr [17596,17666]
===
match
---
name: self [24474,24478]
name: self [26190,26194]
===
match
---
trailer [63951,63963]
trailer [65667,65679]
===
match
---
comparison [41872,41942]
comparison [43588,43658]
===
match
---
simple_stmt [44476,44537]
simple_stmt [46192,46253]
===
match
---
atom_expr [41247,41339]
atom_expr [42963,43055]
===
match
---
parameters [47714,47720]
parameters [49430,49436]
===
match
---
argument [48370,48377]
argument [50086,50093]
===
match
---
expr_stmt [6573,6607]
expr_stmt [6573,6607]
===
match
---
expr_stmt [52206,52404]
expr_stmt [53922,54120]
===
match
---
name: state [47472,47477]
name: state [49188,49193]
===
match
---
simple_stmt [45721,45754]
simple_stmt [47437,47470]
===
match
---
name: match [14821,14826]
name: match [14821,14826]
===
match
---
name: self [36788,36792]
name: self [38504,38508]
===
match
---
simple_stmt [54942,54992]
simple_stmt [56658,56708]
===
match
---
simple_stmt [27833,27874]
simple_stmt [29549,29590]
===
match
---
operator: = [38346,38347]
operator: = [40062,40063]
===
match
---
name: self [37305,37309]
name: self [39021,39025]
===
match
---
testlist_comp [41646,41657]
testlist_comp [43362,43373]
===
match
---
operator: = [62806,62807]
operator: = [64522,64523]
===
match
---
atom_expr [17267,17279]
atom_expr [17267,17279]
===
match
---
atom_expr [22139,22167]
atom_expr [22139,22167]
===
match
---
parameters [67086,67088]
parameters [68802,68804]
===
match
---
dotted_name [1522,1549]
dotted_name [1522,1549]
===
match
---
name: TI [2977,2979]
name: TI [2977,2979]
===
match
---
name: test_dag_id [44436,44447]
name: test_dag_id [46152,46163]
===
match
---
expr_stmt [13677,13723]
expr_stmt [13677,13723]
===
match
---
number: 3 [10484,10485]
number: 3 [10484,10485]
===
match
---
atom_expr [14043,14112]
atom_expr [14043,14112]
===
match
---
name: commit [33513,33519]
name: commit [35229,35235]
===
match
---
assert_stmt [4444,4480]
assert_stmt [4444,4480]
===
match
---
operator: , [4770,4771]
operator: , [4770,4771]
===
match
---
trailer [34492,34499]
trailer [36208,36215]
===
match
---
atom_expr [20850,20872]
atom_expr [20850,20872]
===
match
---
name: dag_id [23606,23612]
name: dag_id [23606,23612]
===
match
---
argument [51812,51825]
argument [53528,53541]
===
match
---
comparison [3361,3375]
comparison [3361,3375]
===
match
---
simple_stmt [24294,24443]
simple_stmt [26010,26159]
===
match
---
assert_stmt [63754,63802]
assert_stmt [65470,65518]
===
match
---
operator: , [59754,59755]
operator: , [61470,61471]
===
match
---
trailer [62159,62168]
trailer [63875,63884]
===
match
---
string: 'dag-bulk-sync-0' [26625,26642]
string: 'dag-bulk-sync-0' [28341,28358]
===
match
---
operator: = [48555,48556]
operator: = [50271,50272]
===
match
---
argument [21521,21553]
argument [21521,21553]
===
match
---
trailer [58878,58886]
trailer [60594,60602]
===
match
---
trailer [67694,67701]
trailer [69410,69417]
===
match
---
trailer [27078,27080]
trailer [28794,28796]
===
match
---
name: default_args [44383,44395]
name: default_args [46099,46111]
===
match
---
comparison [43724,43752]
comparison [45440,45468]
===
match
---
operator: = [16736,16737]
operator: = [16736,16737]
===
match
---
name: task [17297,17301]
name: task [17297,17301]
===
match
---
name: dag [41906,41909]
name: dag [43622,43625]
===
match
---
argument [48353,48368]
argument [50069,50084]
===
match
---
name: DAG [28166,28169]
name: DAG [29882,29885]
===
match
---
comparison [59835,59877]
comparison [61551,61593]
===
match
---
name: task_id [7558,7565]
name: task_id [7558,7565]
===
match
---
name: airflow [1272,1279]
name: airflow [1272,1279]
===
match
---
name: session [17856,17863]
name: session [17856,17863]
===
match
---
operator: >> [38523,38525]
operator: >> [40239,40241]
===
match
---
arglist [61001,61017]
arglist [62717,62733]
===
match
---
operator: = [28963,28964]
operator: = [30679,30680]
===
match
---
operator: = [22137,22138]
operator: = [22137,22138]
===
match
---
trailer [36714,36717]
trailer [38430,38433]
===
match
---
operator: == [59845,59847]
operator: == [61561,61563]
===
match
---
atom_expr [47816,47940]
atom_expr [49532,49656]
===
match
---
trailer [69266,69280]
trailer [70982,70996]
===
match
---
number: 55 [20413,20415]
number: 55 [20413,20415]
===
match
---
testlist_comp [19995,20008]
testlist_comp [19995,20008]
===
match
---
name: task [20069,20073]
name: task [20069,20073]
===
match
---
name: weight_rule [2168,2179]
name: weight_rule [2168,2179]
===
match
---
atom_expr [50585,50598]
atom_expr [52301,52314]
===
match
---
assert_stmt [21844,21898]
assert_stmt [21844,21898]
===
match
---
operator: , [63959,63960]
operator: , [65675,65676]
===
match
---
name: utcnow [43338,43344]
name: utcnow [45054,45060]
===
match
---
import_name [829,838]
import_name [829,838]
===
match
---
name: state [17259,17264]
name: state [17259,17264]
===
match
---
name: dag [68161,68164]
name: dag [69877,69880]
===
match
---
name: task [15076,15080]
name: task [15076,15080]
===
match
---
arglist [17048,17120]
arglist [17048,17120]
===
match
---
operator: = [43967,43968]
operator: = [45683,45684]
===
match
---
trailer [39099,39176]
trailer [40815,40892]
===
match
---
operator: = [44154,44155]
operator: = [45870,45871]
===
match
---
trailer [63764,63779]
trailer [65480,65495]
===
match
---
atom [18185,18199]
atom [18185,18199]
===
match
---
argument [27586,27601]
argument [29302,29317]
===
match
---
name: session [42796,42803]
name: session [44512,44519]
===
match
---
name: dag [27513,27516]
name: dag [29229,29232]
===
match
---
number: 0 [15739,15740]
number: 0 [15739,15740]
===
match
---
name: self [69395,69399]
name: self [71111,71115]
===
match
---
with_stmt [24248,24443]
with_stmt [25964,26159]
===
match
---
trailer [20754,20762]
trailer [20754,20762]
===
match
---
name: get [29361,29364]
name: get [31077,31080]
===
match
---
name: date [55833,55837]
name: date [57549,57553]
===
match
---
arglist [63952,63962]
arglist [65668,65678]
===
match
---
funcdef [33324,33763]
funcdef [35040,35479]
===
match
---
atom [17636,17648]
atom [17636,17648]
===
match
---
name: SubDagOperator [30979,30993]
name: SubDagOperator [32695,32709]
===
match
---
operator: = [39007,39008]
operator: = [40723,40724]
===
match
---
name: DagModel [34631,34639]
name: DagModel [36347,36355]
===
match
---
name: dag_decorator [67843,67856]
name: dag_decorator [69559,69572]
===
match
---
operator: = [69261,69262]
operator: = [70977,70978]
===
match
---
name: one [33165,33168]
name: one [34881,34884]
===
match
---
operator: + [15025,15026]
operator: + [15025,15026]
===
match
---
name: SubDagOperator [1802,1816]
name: SubDagOperator [1802,1816]
===
match
---
trailer [55778,55801]
trailer [57494,57517]
===
match
---
operator: = [27591,27592]
operator: = [29307,29308]
===
match
---
operator: = [21741,21742]
operator: = [21741,21742]
===
match
---
operator: { [12983,12984]
operator: { [12983,12984]
===
match
---
atom_expr [68992,69002]
atom_expr [70708,70718]
===
match
---
trailer [5554,5589]
trailer [5554,5589]
===
match
---
name: dag [13386,13389]
name: dag [13386,13389]
===
match
---
string: b'{{ ds }}' [18968,18979]
string: b'{{ ds }}' [18968,18979]
===
match
---
trailer [48041,48046]
trailer [49757,49762]
===
match
---
trailer [38014,38028]
trailer [39730,39744]
===
match
---
argument [28956,28973]
argument [30672,30689]
===
match
---
operator: , [25023,25024]
operator: , [26739,26740]
===
match
---
trailer [66528,66537]
trailer [68244,68253]
===
match
---
simple_stmt [9774,9807]
simple_stmt [9774,9807]
===
match
---
name: op2 [37949,37952]
name: op2 [39665,39668]
===
match
---
operator: >> [35541,35543]
operator: >> [37257,37259]
===
match
---
atom_expr [64086,64351]
atom_expr [65802,66067]
===
match
---
trailer [34649,34656]
trailer [36365,36372]
===
match
---
operator: = [31155,31156]
operator: = [32871,32872]
===
match
---
assert_stmt [17584,17666]
assert_stmt [17584,17666]
===
match
---
operator: } [38169,38170]
operator: } [39885,39886]
===
match
---
trailer [22635,22650]
trailer [22635,22650]
===
match
---
name: isoformat [22016,22025]
name: isoformat [22016,22025]
===
match
---
comparison [36694,36717]
comparison [38410,38433]
===
match
---
atom_expr [28905,28921]
atom_expr [30621,30637]
===
match
---
name: dag_id [41181,41187]
name: dag_id [42897,42903]
===
match
---
operator: = [9756,9757]
operator: = [9756,9757]
===
match
---
trailer [29032,29040]
trailer [30748,30756]
===
match
---
assert_stmt [7228,7250]
assert_stmt [7228,7250]
===
match
---
operator: , [43263,43264]
operator: , [44979,44980]
===
match
---
trailer [17806,17864]
trailer [17806,17864]
===
match
---
operator: = [13008,13009]
operator: = [13008,13009]
===
match
---
atom_expr [18903,18941]
atom_expr [18903,18941]
===
match
---
name: stdout_lines [36616,36628]
name: stdout_lines [38332,38344]
===
match
---
operator: = [60740,60741]
operator: = [62456,62457]
===
match
---
param [51432,51437]
param [53148,53153]
===
match
---
parameters [3547,3553]
parameters [3547,3553]
===
match
---
operator: , [36905,36906]
operator: , [38621,38622]
===
match
---
assert_stmt [6303,6331]
assert_stmt [6303,6331]
===
match
---
trailer [66806,66816]
trailer [68522,68532]
===
match
---
string: 'dummy' [27568,27575]
string: 'dummy' [29284,29291]
===
match
---
name: op1 [7822,7825]
name: op1 [7822,7825]
===
match
---
simple_stmt [2198,2236]
simple_stmt [2198,2236]
===
match
---
name: MANUAL [70237,70243]
name: MANUAL [71953,71959]
===
match
---
trailer [27068,27073]
trailer [28784,28789]
===
match
---
argument [70305,70337]
argument [72021,72053]
===
match
---
trailer [33947,34020]
trailer [35663,35736]
===
match
---
funcdef [68966,69216]
funcdef [70682,70932]
===
match
---
atom_expr [38320,38360]
atom_expr [40036,40076]
===
match
---
string: '2019-06-01' [10823,10835]
string: '2019-06-01' [10823,10835]
===
match
---
atom_expr [42525,42620]
atom_expr [44241,44336]
===
match
---
name: timedelta [17352,17361]
name: timedelta [17352,17361]
===
match
---
trailer [37710,37718]
trailer [39426,39434]
===
match
---
operator: , [63185,63186]
operator: , [64901,64902]
===
match
---
operator: , [17648,17649]
operator: , [17648,17649]
===
match
---
atom_expr [17558,17574]
atom_expr [17558,17574]
===
match
---
operator: , [49921,49922]
operator: , [51637,51638]
===
match
---
operator: = [9456,9457]
operator: = [9456,9457]
===
match
---
arglist [28608,28638]
arglist [30324,30354]
===
match
---
atom_expr [15733,15748]
atom_expr [15733,15748]
===
match
---
atom_expr [63296,63323]
atom_expr [65012,65039]
===
match
---
simple_stmt [44861,44921]
simple_stmt [46577,46637]
===
match
---
name: dags [25558,25562]
name: dags [27274,27278]
===
match
---
simple_stmt [42525,42621]
simple_stmt [44241,44337]
===
match
---
operator: } [12989,12990]
operator: } [12989,12990]
===
match
---
simple_stmt [60910,60955]
simple_stmt [62626,62671]
===
match
---
atom_expr [69968,69995]
atom_expr [71684,71711]
===
match
---
number: 4 [61016,61017]
number: 4 [62732,62733]
===
match
---
atom_expr [8269,8329]
atom_expr [8269,8329]
===
match
---
atom_expr [31340,31371]
atom_expr [33056,33087]
===
match
---
argument [66388,66397]
argument [68104,68113]
===
match
---
simple_stmt [14133,14493]
simple_stmt [14133,14493]
===
match
---
expr_stmt [49662,49676]
expr_stmt [51378,51392]
===
match
---
funcdef [44098,45849]
funcdef [45814,47565]
===
match
---
atom_expr [12954,13016]
atom_expr [12954,13016]
===
match
---
dictorsetmaker [25841,25895]
dictorsetmaker [27557,27611]
===
match
---
name: self [68939,68943]
name: self [70655,70659]
===
match
---
name: SUCCESS [41476,41483]
name: SUCCESS [43192,43199]
===
match
---
name: timezone [57999,58007]
name: timezone [59715,59723]
===
match
---
atom_expr [40417,40487]
atom_expr [42133,42203]
===
match
---
name: session [24724,24731]
name: session [26440,26447]
===
match
---
name: row [25223,25226]
name: row [26939,26942]
===
match
---
name: DEFAULT_DATE [12856,12868]
name: DEFAULT_DATE [12856,12868]
===
match
---
operator: , [52108,52109]
operator: , [53824,53825]
===
match
---
operator: = [51648,51649]
operator: = [53364,53365]
===
match
---
atom_expr [51091,51214]
atom_expr [52807,52930]
===
match
---
simple_stmt [40498,40575]
simple_stmt [42214,42291]
===
match
---
trailer [5329,5333]
trailer [5329,5333]
===
match
---
expr_stmt [66524,66544]
expr_stmt [68240,68260]
===
match
---
operator: , [8299,8300]
operator: , [8299,8300]
===
match
---
number: 0 [25845,25846]
number: 0 [27561,27562]
===
match
---
trailer [64057,64065]
trailer [65773,65781]
===
match
---
simple_stmt [66825,66860]
simple_stmt [68541,68576]
===
match
---
with_stmt [38315,38553]
with_stmt [40031,40269]
===
match
---
trailer [21098,21105]
trailer [21098,21105]
===
match
---
number: 2020 [58435,58439]
number: 2020 [60151,60155]
===
match
---
name: op3 [37995,37998]
name: op3 [39711,39714]
===
match
---
operator: , [15406,15407]
operator: , [15406,15407]
===
match
---
name: DEFAULT_DATE [66410,66422]
name: DEFAULT_DATE [68126,68138]
===
match
---
operator: == [32091,32093]
operator: == [33807,33809]
===
match
---
argument [39227,39256]
argument [40943,40972]
===
match
---
atom_expr [9690,9716]
atom_expr [9690,9716]
===
match
---
testlist_comp [32062,32078]
testlist_comp [33778,33794]
===
match
---
simple_stmt [853,863]
simple_stmt [853,863]
===
match
---
argument [61248,61255]
argument [62964,62971]
===
match
---
import_as_names [1391,1429]
import_as_names [1391,1429]
===
match
---
simple_stmt [61742,61915]
simple_stmt [63458,63631]
===
match
---
atom_expr [60663,60835]
atom_expr [62379,62551]
===
match
---
operator: = [44681,44682]
operator: = [46397,46398]
===
match
---
name: template_dir [19015,19027]
name: template_dir [19015,19027]
===
match
---
name: clear_db_dags [24489,24502]
name: clear_db_dags [26205,26218]
===
match
---
name: asserts [2258,2265]
name: asserts [2258,2265]
===
match
---
name: orm_dag [65138,65145]
name: orm_dag [66854,66861]
===
match
---
name: DummyOperator [19868,19881]
name: DummyOperator [19868,19881]
===
match
---
operator: = [27984,27985]
operator: = [29700,29701]
===
match
---
atom_expr [6685,6694]
atom_expr [6685,6694]
===
match
---
name: dagrun [53023,53029]
name: dagrun [54739,54745]
===
match
---
trailer [41630,41640]
trailer [43346,43356]
===
match
---
name: dag [37641,37644]
name: dag [39357,39360]
===
match
---
atom_expr [68435,68452]
atom_expr [70151,70168]
===
match
---
trailer [29739,29747]
trailer [31455,31463]
===
match
---
with_stmt [42742,42839]
with_stmt [44458,44555]
===
match
---
name: test_next_dagrun_after_auto_align [60336,60369]
name: test_next_dagrun_after_auto_align [62052,62085]
===
match
---
atom [19928,19958]
atom [19928,19958]
===
match
---
expr_stmt [62789,62843]
expr_stmt [64505,64559]
===
match
---
argument [57729,57742]
argument [59445,59458]
===
match
---
atom_expr [62390,62400]
atom_expr [64106,64116]
===
match
---
suite [12911,13783]
suite [12911,13783]
===
match
---
suite [63824,65478]
suite [65540,67194]
===
match
---
name: dag_id [56415,56421]
name: dag_id [58131,58137]
===
match
---
argument [61231,61246]
argument [62947,62962]
===
match
---
name: Session [27631,27638]
name: Session [29347,29354]
===
match
---
simple_stmt [67571,67582]
simple_stmt [69287,69298]
===
match
---
name: pipeline [13136,13144]
name: pipeline [13136,13144]
===
match
---
name: permissions [1846,1857]
name: permissions [1846,1857]
===
match
---
simple_stmt [28166,28194]
simple_stmt [29882,29910]
===
match
---
name: is_paused [31451,31460]
name: is_paused [33167,33176]
===
match
---
operator: , [8223,8224]
operator: , [8223,8224]
===
match
---
comparison [6874,6908]
comparison [6874,6908]
===
match
---
operator: = [23860,23861]
operator: = [23860,23861]
===
match
---
operator: = [34861,34862]
operator: = [36577,36578]
===
match
---
string: 'dag' [28510,28515]
string: 'dag' [30226,30231]
===
match
---
comparison [45014,45034]
comparison [46730,46750]
===
match
---
trailer [32673,32717]
trailer [34389,34433]
===
match
---
operator: , [62446,62447]
operator: , [64162,64163]
===
match
---
simple_stmt [29244,29269]
simple_stmt [30960,30985]
===
match
---
name: delta [41059,41064]
name: delta [42775,42780]
===
match
---
name: DAG [4957,4960]
name: DAG [4957,4960]
===
match
---
trailer [22079,22089]
trailer [22079,22089]
===
match
---
arglist [17297,17369]
arglist [17297,17369]
===
match
---
param [48132,48137]
param [49848,49853]
===
match
---
name: dag_id [43161,43167]
name: dag_id [44877,44883]
===
match
---
parameters [42006,42012]
parameters [43722,43728]
===
match
---
string: 't1' [36608,36612]
string: 't1' [38324,38328]
===
match
---
operator: = [41324,41325]
operator: = [43040,43041]
===
match
---
trailer [54154,54161]
trailer [55870,55877]
===
match
---
name: clear [50800,50805]
name: clear [52516,52521]
===
match
---
simple_stmt [54617,54660]
simple_stmt [56333,56376]
===
match
---
atom_expr [6624,6631]
atom_expr [6624,6631]
===
match
---
name: calculated_weight [15126,15143]
name: calculated_weight [15126,15143]
===
match
---
trailer [27894,27919]
trailer [29610,29635]
===
match
---
dotted_name [1435,1449]
dotted_name [1435,1449]
===
match
---
operator: = [7332,7333]
operator: = [7332,7333]
===
match
---
operator: = [57081,57082]
operator: = [58797,58798]
===
match
---
operator: = [39120,39121]
operator: = [40836,40837]
===
match
---
operator: = [9083,9084]
operator: = [9083,9084]
===
match
---
name: access_control [63606,63620]
name: access_control [65322,65336]
===
match
---
name: next_date [55040,55049]
name: next_date [56756,56765]
===
match
---
name: start [20467,20472]
name: start [20467,20472]
===
match
---
name: session [34222,34229]
name: session [35938,35945]
===
match
---
arglist [40526,40573]
arglist [42242,42289]
===
match
---
simple_stmt [18993,19003]
simple_stmt [18993,19003]
===
insert-node
---
name: TestDag [2406,2413]
to
classdef [2400,63803]
at 0
===
insert-tree
---
funcdef [24076,24468]
    name: test_previous_schedule_datetime_timezone [24080,24120]
    parameters [24120,24126]
        param [24121,24125]
            name: self [24121,24125]
    suite [24127,24468]
        simple_stmt [24214,24286]
            expr_stmt [24214,24285]
                name: start [24214,24219]
                operator: = [24220,24221]
                atom_expr [24222,24285]
                    name: datetime [24222,24230]
                    trailer [24230,24239]
                        name: datetime [24231,24239]
                    trailer [24239,24285]
                        arglist [24240,24284]
                            number: 2018 [24240,24244]
                            operator: , [24244,24245]
                            number: 3 [24246,24247]
                            operator: , [24247,24248]
                            number: 25 [24249,24251]
                            operator: , [24251,24252]
                            number: 2 [24253,24254]
                            operator: , [24254,24255]
                            argument [24256,24284]
                                name: tzinfo [24256,24262]
                                operator: = [24262,24263]
                                atom_expr [24263,24284]
                                    name: datetime [24263,24271]
                                    trailer [24271,24280]
                                        name: timezone [24272,24280]
                                    trailer [24280,24284]
                                        name: utc [24281,24284]
        simple_stmt [24294,24361]
            expr_stmt [24294,24360]
                name: dag [24294,24297]
                operator: = [24298,24299]
                atom_expr [24300,24360]
                    name: DAG [24300,24303]
                    trailer [24303,24360]
                        arglist [24304,24359]
                            string: 'tz_dag' [24304,24312]
                            operator: , [24312,24313]
                            argument [24314,24330]
                                name: start_date [24314,24324]
                                operator: = [24324,24325]
                                name: start [24325,24330]
                            operator: , [24330,24331]
                            argument [24332,24359]
                                name: schedule_interval [24332,24349]
                                operator: = [24349,24350]
                                string: '@hourly' [24350,24359]
        simple_stmt [24369,24405]
            expr_stmt [24369,24404]
                name: when [24369,24373]
                operator: = [24374,24375]
                atom_expr [24376,24404]
                    name: dag [24376,24379]
                    trailer [24379,24397]
                        name: previous_schedule [24380,24397]
                    trailer [24397,24404]
                        name: start [24398,24403]
        simple_stmt [24413,24468]
            assert_stmt [24413,24467]
                comparison [24420,24467]
                    atom_expr [24420,24436]
                        name: when [24420,24424]
                        trailer [24424,24434]
                            name: isoformat [24425,24434]
                        trailer [24434,24436]
                    operator: == [24437,24439]
                    string: "2018-03-25T01:00:00+00:00" [24440,24467]
to
suite [2433,63803]
at 32
===
insert-tree
---
funcdef [24473,24867]
    name: test_following_schedule_datetime_timezone [24477,24518]
    parameters [24518,24524]
        param [24519,24523]
            name: self [24519,24523]
    suite [24525,24867]
        simple_stmt [24612,24684]
            expr_stmt [24612,24683]
                name: start [24612,24617]
                operator: = [24618,24619]
                atom_expr [24620,24683]
                    name: datetime [24620,24628]
                    trailer [24628,24637]
                        name: datetime [24629,24637]
                    trailer [24637,24683]
                        arglist [24638,24682]
                            number: 2018 [24638,24642]
                            operator: , [24642,24643]
                            number: 3 [24644,24645]
                            operator: , [24645,24646]
                            number: 25 [24647,24649]
                            operator: , [24649,24650]
                            number: 2 [24651,24652]
                            operator: , [24652,24653]
                            argument [24654,24682]
                                name: tzinfo [24654,24660]
                                operator: = [24660,24661]
                                atom_expr [24661,24682]
                                    name: datetime [24661,24669]
                                    trailer [24669,24678]
                                        name: timezone [24670,24678]
                                    trailer [24678,24682]
                                        name: utc [24679,24682]
        simple_stmt [24692,24759]
            expr_stmt [24692,24758]
                name: dag [24692,24695]
                operator: = [24696,24697]
                atom_expr [24698,24758]
                    name: DAG [24698,24701]
                    trailer [24701,24758]
                        arglist [24702,24757]
                            string: 'tz_dag' [24702,24710]
                            operator: , [24710,24711]
                            argument [24712,24728]
                                name: start_date [24712,24722]
                                operator: = [24722,24723]
                                name: start [24723,24728]
                            operator: , [24728,24729]
                            argument [24730,24757]
                                name: schedule_interval [24730,24747]
                                operator: = [24747,24748]
                                string: '@hourly' [24748,24757]
        simple_stmt [24767,24804]
            expr_stmt [24767,24803]
                name: when [24767,24771]
                operator: = [24772,24773]
                atom_expr [24774,24803]
                    name: dag [24774,24777]
                    trailer [24777,24796]
                        name: following_schedule [24778,24796]
                    trailer [24796,24803]
                        name: start [24797,24802]
        simple_stmt [24812,24867]
            assert_stmt [24812,24866]
                comparison [24819,24866]
                    atom_expr [24819,24835]
                        name: when [24819,24823]
                        trailer [24823,24833]
                            name: isoformat [24824,24833]
                        trailer [24833,24835]
                    operator: == [24836,24838]
                    string: "2018-03-25T03:00:00+00:00" [24839,24866]
to
suite [2433,63803]
at 33
===
insert-tree
---
funcdef [24872,25787]
    name: test_following_schedule_datetime_timezone_utc0530 [24876,24925]
    parameters [24925,24931]
        param [24926,24930]
            name: self [24926,24930]
    suite [24932,25787]
        classdef [25018,25534]
            name: UTC0530 [25024,25031]
            atom_expr [25032,25047]
                name: datetime [25032,25040]
                trailer [25040,25047]
                    name: tzinfo [25041,25047]
            suite [25049,25534]
                simple_stmt [25062,25133]
                    string: """tzinfo derived concrete class named "+0530" with offset of 19800""" [25062,25132]
                simple_stmt [25183,25227]
                    expr_stmt [25183,25226]
                        name: _offset [25183,25190]
                        operator: = [25191,25192]
                        atom_expr [25193,25226]
                            name: datetime [25193,25201]
                            trailer [25201,25211]
                                name: timedelta [25202,25211]
                            trailer [25211,25226]
                                argument [25212,25225]
                                    name: seconds [25212,25219]
                                    operator: = [25219,25220]
                                    number: 19800 [25220,25225]
                simple_stmt [25239,25268]
                    expr_stmt [25239,25267]
                        name: _dst [25239,25243]
                        operator: = [25244,25245]
                        atom_expr [25246,25267]
                            name: datetime [25246,25254]
                            trailer [25254,25264]
                                name: timedelta [25255,25264]
                            trailer [25264,25267]
                                number: 0 [25265,25266]
                simple_stmt [25280,25296]
                    expr_stmt [25280,25295]
                        name: _name [25280,25285]
                        operator: = [25286,25287]
                        string: "+0530" [25288,25295]
                funcdef [25309,25380]
                    name: utcoffset [25313,25322]
                    parameters [25322,25332]
                        param [25323,25328]
                            name: self [25323,25327]
                            operator: , [25327,25328]
                        param [25329,25331]
                            name: dt [25329,25331]
                    suite [25333,25380]
                        simple_stmt [25350,25380]
                            return_stmt [25350,25379]
                                atom_expr [25357,25379]
                                    name: self [25357,25361]
                                    trailer [25361,25371]
                                        name: __class__ [25362,25371]
                                    trailer [25371,25379]
                                        name: _offset [25372,25379]
                funcdef [25393,25455]
                    name: dst [25397,25400]
                    parameters [25400,25410]
                        param [25401,25406]
                            name: self [25401,25405]
                            operator: , [25405,25406]
                        param [25407,25409]
                            name: dt [25407,25409]
                    suite [25411,25455]
                        simple_stmt [25428,25455]
                            return_stmt [25428,25454]
                                atom_expr [25435,25454]
                                    name: self [25435,25439]
                                    trailer [25439,25449]
                                        name: __class__ [25440,25449]
                                    trailer [25449,25454]
                                        name: _dst [25450,25454]
                funcdef [25468,25534]
                    name: tzname [25472,25478]
                    parameters [25478,25488]
                        param [25479,25484]
                            name: self [25479,25483]
                            operator: , [25483,25484]
                        param [25485,25487]
                            name: dt [25485,25487]
                    suite [25489,25534]
                        simple_stmt [25506,25534]
                            return_stmt [25506,25533]
                                atom_expr [25513,25533]
                                    name: self [25513,25517]
                                    trailer [25517,25527]
                                        name: __class__ [25518,25527]
                                    trailer [25527,25533]
                                        name: _name [25528,25533]
        simple_stmt [25543,25604]
            expr_stmt [25543,25603]
                name: start [25543,25548]
                operator: = [25549,25550]
                atom_expr [25551,25603]
                    name: datetime [25551,25559]
                    trailer [25559,25568]
                        name: datetime [25560,25568]
                    trailer [25568,25603]
                        arglist [25569,25602]
                            number: 2018 [25569,25573]
                            operator: , [25573,25574]
                            number: 3 [25575,25576]
                            operator: , [25576,25577]
                            number: 25 [25578,25580]
                            operator: , [25580,25581]
                            number: 10 [25582,25584]
                            operator: , [25584,25585]
                            argument [25586,25602]
                                name: tzinfo [25586,25592]
                                operator: = [25592,25593]
                                atom_expr [25593,25602]
                                    name: UTC0530 [25593,25600]
                                    trailer [25600,25602]
        simple_stmt [25612,25679]
            expr_stmt [25612,25678]
                name: dag [25612,25615]
                operator: = [25616,25617]
                atom_expr [25618,25678]
                    name: DAG [25618,25621]
                    trailer [25621,25678]
                        arglist [25622,25677]
                            string: 'tz_dag' [25622,25630]
                            operator: , [25630,25631]
                            argument [25632,25648]
                                name: start_date [25632,25642]
                                operator: = [25642,25643]
                                name: start [25643,25648]
                            operator: , [25648,25649]
                            argument [25650,25677]
                                name: schedule_interval [25650,25667]
                                operator: = [25667,25668]
                                string: '@hourly' [25668,25677]
        simple_stmt [25687,25724]
            expr_stmt [25687,25723]
                name: when [25687,25691]
                operator: = [25692,25693]
                atom_expr [25694,25723]
                    name: dag [25694,25697]
                    trailer [25697,25716]
                        name: following_schedule [25698,25716]
                    trailer [25716,25723]
                        name: start [25717,25722]
        simple_stmt [25732,25787]
            assert_stmt [25732,25786]
                comparison [25739,25786]
                    atom_expr [25739,25755]
                        name: when [25739,25743]
                        trailer [25743,25753]
                            name: isoformat [25744,25753]
                        trailer [25753,25755]
                    operator: == [25756,25758]
                    string: "2018-03-25T05:30:00+00:00" [25759,25786]
to
suite [2433,63803]
at 34
===
delete-node
---
name: TestDag [2406,2413]
===
