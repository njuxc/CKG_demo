===
match
---
trailer [5297,5313]
trailer [5304,5320]
===
match
---
param [4307,4312]
param [4314,4319]
===
match
---
name: key [4605,4608]
name: key [4612,4615]
===
match
---
name: self [1714,1718]
name: self [1714,1718]
===
match
---
import_from [958,1002]
import_from [958,1002]
===
match
---
string: "Setting %s to %s" [2188,2206]
string: "Setting %s to %s" [2188,2206]
===
match
---
name: key [4818,4821]
name: key [4825,4828]
===
match
---
arglist [2957,2983]
arglist [2957,2983]
===
match
---
operator: = [4202,4203]
operator: = [4209,4210]
===
match
---
trailer [5283,5314]
trailer [5290,5321]
===
match
---
name: range [4681,4686]
name: range [4688,4693]
===
match
---
dictorsetmaker [4218,4273]
dictorsetmaker [4225,4280]
===
match
---
trailer [2584,2597]
trailer [2584,2597]
===
match
---
trailer [5154,5205]
trailer [5161,5212]
===
match
---
operator: { [1773,1774]
operator: { [1773,1774]
===
match
---
parameters [4926,4932]
parameters [4933,4939]
===
match
---
trailer [1718,1731]
trailer [1718,1731]
===
match
---
trailer [3918,3933]
trailer [3925,3940]
===
match
---
name: State [3155,3160]
name: State [3155,3160]
===
match
---
dotted_name [1048,1079]
dotted_name [1048,1079]
===
match
---
atom_expr [5284,5290]
atom_expr [5291,5297]
===
match
---
name: task_instance [4183,4196]
name: task_instance [4190,4203]
===
match
---
atom [4691,4727]
atom [4698,4734]
===
match
---
simple_stmt [1249,1498]
simple_stmt [1249,1498]
===
match
---
atom_expr [2507,2519]
atom_expr [2507,2519]
===
match
---
trailer [2597,2619]
trailer [2597,2619]
===
match
---
atom_expr [2255,2290]
atom_expr [2255,2290]
===
match
---
name: pop [4814,4817]
name: pop [4821,4824]
===
match
---
trailer [5377,5379]
trailer [5384,5386]
===
match
---
param [3478,3510]
param [3485,3517]
===
match
---
name: self [4165,4169]
name: self [4172,4176]
===
match
---
simple_stmt [1714,1776]
simple_stmt [1714,1776]
===
match
---
name: key [2502,2505]
name: key [2502,2505]
===
match
---
suite [4338,4914]
suite [4345,4921]
===
match
---
atom_expr [5470,5529]
atom_expr [5477,5536]
===
match
---
trailer [4886,4893]
trailer [4893,4900]
===
match
---
operator: -> [5453,5455]
operator: -> [5460,5462]
===
match
---
trailer [4620,4623]
trailer [4627,4630]
===
match
---
atom_expr [3230,3257]
atom_expr [3230,3264]
===
match
---
trailer [2966,2973]
trailer [2966,2973]
===
match
---
name: ti [2325,2327]
name: ti [2325,2327]
===
match
---
trailer [4196,4200]
trailer [4203,4207]
===
match
---
atom_expr [5571,5593]
atom_expr [5578,5600]
===
match
---
trailer [2273,2289]
trailer [2273,2289]
===
match
---
operator: = [3666,3667]
operator: = [3673,3674]
===
match
---
name: key [2601,2604]
name: key [2601,2604]
===
match
---
operator: , [3432,3433]
operator: , [3439,3440]
===
match
---
trailer [2733,2737]
trailer [2733,2737]
===
match
---
param [3442,3469]
param [3449,3476]
===
match
---
tfpdef [2763,2779]
tfpdef [2763,2779]
===
match
---
trailer [2549,2563]
trailer [2549,2563]
===
match
---
trailer [2512,2519]
trailer [2512,2519]
===
match
---
name: key [2211,2214]
name: key [2211,2214]
===
match
---
trailer [5588,5593]
trailer [5595,5600]
===
match
---
trailer [2187,2238]
trailer [2187,2238]
===
match
---
name: self [3391,3395]
name: self [3398,3402]
===
match
---
trailer [4182,4201]
trailer [4189,4208]
===
match
---
if_stmt [2116,2381]
if_stmt [2116,2381]
===
match
---
name: List [1614,1618]
name: List [1614,1618]
===
match
---
string: """Queues task instance with empty command because we do not need it.""" [3774,3846]
string: """Queues task instance with empty command because we do not need it.""" [3781,3853]
===
match
---
trailer [3497,3502]
trailer [3504,3509]
===
match
---
trailer [3209,3216]
trailer [3209,3216]
===
match
---
name: TaskInstance [1140,1152]
name: TaskInstance [1140,1152]
===
match
---
arglist [5155,5204]
arglist [5162,5211]
===
match
---
simple_stmt [2174,2239]
simple_stmt [2174,2239]
===
match
---
trailer [2123,2133]
trailer [2123,2133]
===
match
---
name: task [4022,4026]
name: task [4029,4033]
===
match
---
suite [4730,4914]
suite [4737,4921]
===
match
---
name: self [1553,1557]
name: self [1553,1557]
===
match
---
simple_stmt [1568,1587]
simple_stmt [1568,1587]
===
match
---
simple_stmt [958,1003]
simple_stmt [958,1003]
===
match
---
trailer [2324,2355]
trailer [2324,2355]
===
match
---
trailer [2327,2331]
trailer [2327,2331]
===
match
---
trailer [4589,4591]
trailer [4596,4598]
===
match
---
atom_expr [2894,2927]
atom_expr [2894,2927]
===
match
---
atom_expr [3047,3074]
atom_expr [3047,3074]
===
match
---
operator: , [980,981]
operator: , [980,981]
===
match
---
name: _run_finished_callback [3233,3255]
name: _run_finished_callback [3233,3255]
===
match
---
name: threading [948,957]
name: threading [948,957]
===
match
---
operator: , [4311,4312]
operator: , [4318,4319]
===
match
---
number: 1 [4621,4622]
number: 1 [4628,4629]
===
match
---
expr_stmt [2007,2028]
expr_stmt [2007,2028]
===
match
---
name: task_succeeded [2007,2021]
name: task_succeeded [2007,2021]
===
match
---
trailer [3288,3327]
trailer [3295,3334]
===
match
---
import_from [1170,1207]
import_from [1170,1207]
===
match
---
simple_stmt [2702,2738]
simple_stmt [2702,2738]
===
match
---
name: FAILED [3161,3167]
name: FAILED [3161,3167]
===
match
---
name: e [3127,3128]
name: e [3127,3128]
===
match
---
operator: = [3541,3542]
operator: = [3548,3549]
===
match
---
name: info [2449,2453]
name: info [2449,2453]
===
match
---
subscriptlist [1760,1768]
subscriptlist [1760,1768]
===
match
---
suite [5348,5380]
suite [5355,5387]
===
match
---
atom_expr [4704,4726]
atom_expr [4711,4733]
===
match
---
operator: , [1753,1754]
operator: , [1753,1754]
===
match
---
operator: , [2761,2762]
operator: , [2761,2762]
===
match
---
name: change_state [5271,5283]
name: change_state [5278,5290]
===
match
---
simple_stmt [3340,3353]
simple_stmt [3347,3360]
===
match
---
trailer [4026,4048]
trailer [4033,4055]
===
match
---
name: self [5470,5474]
name: self [5477,5481]
===
match
---
arglist [3015,3033]
arglist [3015,3033]
===
match
---
funcdef [4289,4914]
funcdef [4296,4921]
===
match
---
name: change_state [3002,3014]
name: change_state [3002,3014]
===
match
---
name: queued_tasks [4801,4813]
name: queued_tasks [4808,4820]
===
match
---
operator: = [4067,4068]
operator: = [4074,4075]
===
match
---
name: info [2183,2187]
name: info [2183,2187]
===
match
---
expr_stmt [1714,1775]
expr_stmt [1714,1775]
===
match
---
simple_stmt [1043,1100]
simple_stmt [1043,1100]
===
match
---
suite [2789,3353]
suite [2789,3360]
===
match
---
trailer [4776,4780]
trailer [4783,4787]
===
match
---
trailer [5286,5290]
trailer [5293,5297]
===
match
---
suite [2061,2738]
suite [2061,2738]
===
match
---
arglist [3199,3216]
arglist [3199,3216]
===
match
---
name: log [5146,5149]
name: log [5153,5156]
===
match
---
name: set [5374,5377]
name: set [5381,5384]
===
match
---
name: fail_fast [2124,2133]
name: fail_fast [2124,2133]
===
match
---
name: set_state [2258,2267]
name: set_state [2258,2267]
===
match
---
name: bool [3582,3586]
name: bool [3589,3593]
===
match
---
name: ti [2499,2501]
name: ti [2499,2501]
===
match
---
operator: , [5601,5602]
operator: , [5608,5609]
===
match
---
param [3405,3433]
param [3412,3440]
===
match
---
operator: , [1824,1825]
operator: , [1824,1825]
===
match
---
trailer [3072,3074]
trailer [3072,3074]
===
match
---
trailer [2311,2324]
trailer [2311,2324]
===
match
---
name: UPSTREAM_FAILED [5298,5313]
name: UPSTREAM_FAILED [5305,5320]
===
match
---
name: self [3270,3274]
name: self [3277,3281]
===
match
---
name: str [3320,3323]
name: str [3327,3330]
===
match
---
atom_expr [2798,2838]
atom_expr [2798,2838]
===
match
---
name: bool [3536,3540]
name: bool [3543,3547]
===
match
---
trailer [4552,4663]
trailer [4559,4670]
===
match
---
for_stmt [5100,5315]
for_stmt [5107,5322]
===
match
---
trailer [2911,2915]
trailer [2911,2915]
===
match
---
name: priority [3999,4007]
name: priority [4006,4014]
===
match
---
operator: , [3318,3319]
operator: , [3325,3326]
===
match
---
name: self [2894,2898]
name: self [2894,2898]
===
match
---
suite [1244,5608]
suite [1244,5615]
===
match
---
name: __init__ [1576,1584]
name: __init__ [1576,1584]
===
match
---
trailer [2723,2733]
trailer [2723,2733]
===
match
---
trailer [3737,3742]
trailer [3744,3749]
===
match
---
name: airflow [1105,1112]
name: airflow [1105,1112]
===
match
---
name: UPSTREAM_FAILED [5237,5252]
name: UPSTREAM_FAILED [5244,5259]
===
match
---
trailer [1575,1584]
trailer [1575,1584]
===
match
---
tfpdef [3478,3502]
tfpdef [3485,3509]
===
match
---
name: cfg_path [3719,3727]
name: cfg_path [3726,3734]
===
match
---
operator: = [1771,1772]
operator: = [1771,1772]
===
match
---
operator: = [2892,2893]
operator: = [2892,2893]
===
match
---
suite [2872,3099]
suite [2872,3099]
===
match
---
trailer [2956,2984]
trailer [2956,2984]
===
match
---
suite [2423,2689]
suite [2423,2689]
===
match
---
trailer [4623,4626]
trailer [4630,4633]
===
match
---
trailer [1618,1632]
trailer [1618,1632]
===
match
---
name: self [2757,2761]
name: self [2757,2761]
===
match
---
name: self [2798,2802]
name: self [2798,2802]
===
match
---
trailer [2182,2187]
trailer [2182,2187]
===
match
---
return_stmt [3340,3352]
return_stmt [3347,3359]
===
match
---
parameters [1552,1558]
parameters [1552,1558]
===
match
---
operator: = [3627,3628]
operator: = [3634,3635]
===
match
---
name: ti [2835,2837]
name: ti [2835,2837]
===
match
---
name: Event [1527,1532]
name: Event [1527,1532]
===
match
---
name: pickle_id [3478,3487]
name: pickle_id [3485,3494]
===
match
---
trailer [3144,3154]
trailer [3144,3154]
===
match
---
name: conf [1038,1042]
name: conf [1038,1042]
===
match
---
trailer [4086,4092]
trailer [4093,4099]
===
match
---
simple_stmt [1784,1839]
simple_stmt [1784,1839]
===
match
---
name: x [4616,4617]
name: x [4623,4624]
===
match
---
name: _ [4676,4677]
name: _ [4683,4684]
===
match
---
name: key [3199,3202]
name: key [3199,3202]
===
match
---
trailer [2267,2290]
trailer [2267,2290]
===
match
---
param [4927,4931]
param [4934,4938]
===
match
---
name: _run_finished_callback [3050,3072]
name: _run_finished_callback [3050,3072]
===
match
---
operator: , [4246,4247]
operator: , [4253,4254]
===
match
---
name: task_instance [3405,3418]
name: task_instance [3412,3425]
===
match
---
trailer [2600,2604]
trailer [2600,2604]
===
match
---
name: taskinstance [1120,1132]
name: taskinstance [1120,1132]
===
match
---
operator: , [3202,3203]
operator: , [3202,3203]
===
match
---
expr_stmt [1595,1637]
expr_stmt [1595,1637]
===
match
---
name: log [3275,3278]
name: log [3282,3285]
===
match
---
name: airflow [1048,1055]
name: airflow [1048,1055]
===
match
---
name: self [5357,5361]
name: self [5364,5368]
===
match
---
param [3391,3396]
param [3398,3403]
===
match
---
name: pool [4268,4272]
name: pool [4275,4279]
===
match
---
trailer [2806,2812]
trailer [2806,2812]
===
match
---
name: State [3020,3025]
name: State [3020,3025]
===
match
---
atom_expr [2397,2422]
atom_expr [2397,2422]
===
match
---
operator: , [5440,5441]
operator: , [5447,5448]
===
match
---
annassign [1731,1775]
annassign [1731,1775]
===
match
---
atom_expr [5357,5379]
atom_expr [5364,5386]
===
match
---
arglist [5485,5528]
arglist [5492,5535]
===
match
---
name: typing [963,969]
name: typing [963,969]
===
match
---
atom_expr [2043,2060]
atom_expr [2043,2060]
===
match
---
trailer [2855,2859]
trailer [2855,2859]
===
match
---
tfpdef [5408,5428]
tfpdef [5415,5435]
===
match
---
operator: , [3018,3019]
operator: , [3018,3019]
===
match
---
name: SUCCESS [3026,3033]
name: SUCCESS [3026,3033]
===
match
---
name: reverse [4640,4647]
name: reverse [4647,4654]
===
match
---
atom_expr [2174,2238]
atom_expr [2174,2238]
===
match
---
name: running [5543,5550]
name: running [5550,5557]
===
match
---
atom_expr [5218,5253]
atom_expr [5225,5260]
===
match
---
atom_expr [3270,3327]
atom_expr [3277,3334]
===
match
---
trailer [4081,4086]
trailer [4088,4093]
===
match
---
name: Exception [3114,3123]
name: Exception [3114,3123]
===
match
---
trailer [2448,2453]
trailer [2448,2453]
===
match
---
operator: = [4762,4763]
operator: = [4769,4770]
===
match
---
atom [2924,2926]
atom [2924,2926]
===
match
---
name: ti [4894,4896]
name: ti [4901,4903]
===
match
---
name: info [5150,5154]
name: info [5157,5161]
===
match
---
suite [5128,5315]
suite [5135,5322]
===
match
---
atom_expr [1517,1534]
atom_expr [1517,1534]
===
match
---
name: bool [3661,3665]
name: bool [3668,3672]
===
match
---
simple_stmt [2636,2664]
simple_stmt [2636,2664]
===
match
---
number: 0 [2101,2102]
number: 0 [2101,2102]
===
match
---
operator: , [1763,1764]
operator: , [1763,1764]
===
match
---
atom_expr [4764,4783]
atom_expr [4771,4790]
===
match
---
trailer [4839,4847]
trailer [4846,4854]
===
match
---
simple_stmt [4347,4523]
simple_stmt [4354,4530]
===
match
---
simple_stmt [2940,2985]
simple_stmt [2940,2985]
===
match
---
trailer [1737,1770]
trailer [1737,1770]
===
match
---
name: TaskInstance [1619,1631]
name: TaskInstance [1619,1631]
===
match
---
atom_expr [1614,1632]
atom_expr [1614,1632]
===
match
---
trailer [4707,4726]
trailer [4714,4733]
===
match
---
param [1875,1883]
param [1875,1883]
===
match
---
parameters [1861,1884]
parameters [1861,1884]
===
match
---
operator: , [3634,3635]
operator: , [3641,3642]
===
match
---
operator: , [3594,3595]
operator: , [3601,3602]
===
match
---
simple_stmt [3774,3847]
simple_stmt [3781,3854]
===
match
---
name: key [5558,5561]
name: key [5565,5568]
===
match
---
trailer [5484,5529]
trailer [5491,5536]
===
match
---
string: """The method is replaced by custom trigger_task implementation.""" [1902,1969]
string: """The method is replaced by custom trigger_task implementation.""" [1902,1969]
===
match
---
name: self [5110,5114]
name: self [5117,5121]
===
match
---
trailer [2420,2422]
trailer [2420,2422]
===
match
---
name: tasks_to_run [2084,2096]
name: tasks_to_run [2084,2096]
===
match
---
name: Optional [3729,3737]
name: Optional [3736,3744]
===
match
---
operator: , [4753,4754]
operator: , [4760,4761]
===
match
---
name: self [1784,1788]
name: self [1784,1788]
===
match
---
operator: } [1774,1775]
operator: } [1774,1775]
===
match
---
argument [4062,4092]
argument [4069,4099]
===
match
---
trailer [2611,2618]
trailer [2611,2618]
===
match
---
atom_expr [4068,4092]
atom_expr [4075,4099]
===
match
---
param [3519,3549]
param [3526,3556]
===
match
---
expr_stmt [5571,5607]
expr_stmt [5578,5614]
===
match
---
trailer [5270,5283]
trailer [5277,5290]
===
match
---
atom_expr [4796,4822]
atom_expr [4803,4829]
===
match
---
param [5334,5338]
param [5341,5345]
===
match
---
atom_expr [2964,2973]
atom_expr [2964,2973]
===
match
---
for_stmt [4672,4914]
for_stmt [4679,4921]
===
match
---
while_stmt [2037,2738]
while_stmt [2037,2738]
===
match
---
simple_stmt [3142,3169]
simple_stmt [3142,3169]
===
match
---
annassign [1612,1637]
annassign [1612,1637]
===
match
---
trailer [1759,1769]
trailer [1759,1769]
===
match
---
atom_expr [1801,1838]
atom_expr [1801,1838]
===
match
---
trailer [5230,5253]
trailer [5237,5260]
===
match
---
name: FAILED [2556,2562]
name: FAILED [2556,2562]
===
match
---
operator: , [986,987]
operator: , [986,987]
===
match
---
atom_expr [3204,3216]
atom_expr [3204,3216]
===
match
---
atom_expr [2216,2237]
atom_expr [2216,2237]
===
match
---
testlist_comp [4692,4726]
testlist_comp [4699,4733]
===
match
---
param [5430,5441]
param [5437,5448]
===
match
---
trailer [2047,2060]
trailer [2047,2060]
===
match
---
simple_stmt [4531,4664]
simple_stmt [4538,4671]
===
match
---
name: Dict [1733,1737]
name: Dict [1733,1737]
===
match
---
atom_expr [1784,1798]
atom_expr [1784,1798]
===
match
---
name: self [2119,2123]
name: self [2119,2123]
===
match
---
simple_stmt [2997,3035]
simple_stmt [2997,3035]
===
match
---
atom_expr [5183,5204]
atom_expr [5190,5211]
===
match
---
trailer [3323,3326]
trailer [3330,3333]
===
match
---
operator: , [2331,2332]
operator: , [2331,2332]
===
match
---
name: FAILED [2612,2618]
name: FAILED [2612,2618]
===
match
---
param [5408,5429]
param [5415,5436]
===
match
---
testlist_comp [4749,4760]
testlist_comp [4756,4767]
===
match
---
trailer [3014,3034]
trailer [3014,3034]
===
match
---
arglist [4566,4653]
arglist [4573,4660]
===
match
---
atom_expr [4183,4200]
atom_expr [4190,4207]
===
match
---
name: key [4197,4200]
name: key [4204,4207]
===
match
---
operator: , [2206,2207]
operator: , [2206,2207]
===
match
---
arglist [3887,4093]
arglist [3894,4100]
===
match
---
trailer [3025,3033]
trailer [3025,3033]
===
match
---
trailer [4570,4583]
trailer [4577,4590]
===
match
---
name: sorted_queue [4531,4543]
name: sorted_queue [4538,4550]
===
match
---
expr_stmt [4165,4283]
expr_stmt [4172,4290]
===
match
---
name: self [4869,4873]
name: self [4876,4880]
===
match
---
name: Dict [1755,1759]
name: Dict [1755,1759]
===
match
---
trailer [1584,1586]
trailer [1584,1586]
===
match
---
name: BaseExecutor [1230,1242]
name: BaseExecutor [1230,1242]
===
match
---
name: queue [4062,4067]
name: queue [4069,4074]
===
match
---
string: "Executor is terminated! Stopping %s to %s" [2454,2497]
string: "Executor is terminated! Stopping %s to %s" [2454,2497]
===
match
---
name: pool [3683,3687]
name: pool [3690,3694]
===
match
---
name: tasks_to_run [5115,5127]
name: tasks_to_run [5122,5134]
===
match
---
operator: = [4007,4008]
operator: = [4014,4015]
===
match
---
atom_expr [2606,2618]
atom_expr [2606,2618]
===
match
---
name: ti [3230,3232]
name: ti [3230,3232]
===
match
---
dotted_name [1175,1194]
dotted_name [1175,1194]
===
match
---
atom_expr [4687,4728]
atom_expr [4694,4735]
===
match
---
param [1553,1557]
param [1553,1557]
===
match
---
name: mark_success [3442,3454]
name: mark_success [3449,3461]
===
match
---
atom_expr [3181,3217]
atom_expr [3181,3217]
===
match
---
trailer [3185,3198]
trailer [3185,3198]
===
match
---
atom_expr [2307,2355]
atom_expr [2307,2355]
===
match
---
simple_stmt [1902,1970]
simple_stmt [1902,1970]
===
match
---
atom_expr [3142,3168]
atom_expr [3142,3168]
===
match
---
simple_stmt [2680,2689]
simple_stmt [2680,2689]
===
match
---
simple_stmt [2307,2356]
simple_stmt [2307,2356]
===
match
---
simple_stmt [1004,1043]
simple_stmt [1004,1043]
===
match
---
name: TaskInstance [2767,2779]
name: TaskInstance [2767,2779]
===
match
---
name: str [3915,3918]
name: str [3922,3925]
===
match
---
operator: , [3509,3510]
operator: , [3516,3517]
===
match
---
param [4616,4617]
param [4623,4624]
===
match
---
name: min [4687,4690]
name: min [4694,4697]
===
match
---
operator: , [3468,3469]
operator: , [3475,3476]
===
match
---
name: key [5287,5290]
name: key [5294,5297]
===
match
---
name: items [4584,4589]
name: items [4591,4596]
===
match
---
tfpdef [3719,3742]
tfpdef [3726,3749]
===
match
---
atom_expr [2268,2289]
atom_expr [2268,2289]
===
match
---
string: "Setting %s to %s" [5155,5173]
string: "Setting %s to %s" [5162,5180]
===
match
---
atom_expr [3155,3167]
atom_expr [3155,3167]
===
match
---
simple_stmt [4950,5092]
simple_stmt [4957,5099]
===
match
---
name: trigger_tasks [4293,4306]
name: trigger_tasks [4300,4313]
===
match
---
simple_stmt [1170,1208]
simple_stmt [1170,1208]
===
match
---
name: TaskInstanceKey [1738,1753]
name: TaskInstanceKey [1738,1753]
===
match
---
name: state [1189,1194]
name: state [1189,1194]
===
match
---
atom_expr [2636,2663]
atom_expr [2636,2663]
===
match
---
simple_stmt [5266,5315]
simple_stmt [5273,5322]
===
match
---
trailer [5550,5557]
trailer [5557,5564]
===
match
---
param [1862,1867]
param [1862,1867]
===
match
---
atom_expr [5110,5127]
atom_expr [5117,5134]
===
match
---
operator: = [5594,5595]
operator: = [5601,5602]
===
match
---
testlist_star_expr [5596,5607]
testlist_star_expr [5603,5614]
===
match
---
name: ignore_ti_state [3644,3659]
name: ignore_ti_state [3651,3666]
===
match
---
name: _terminated [2402,2413]
name: _terminated [2402,2413]
===
match
---
operator: * [1868,1869]
operator: * [1868,1869]
===
match
---
simple_stmt [5470,5530]
simple_stmt [5477,5537]
===
match
---
atom_expr [3489,3502]
atom_expr [3496,3509]
===
match
---
operator: , [2497,2498]
operator: , [2497,2498]
===
match
---
name: change_state [2585,2597]
name: change_state [2585,2597]
===
match
---
expr_stmt [2885,2927]
expr_stmt [2885,2927]
===
match
---
name: log [5475,5478]
name: log [5482,5485]
===
match
---
name: set_state [3145,3154]
name: set_state [3145,3154]
===
match
---
atom_expr [1755,1769]
atom_expr [1755,1769]
===
match
---
operator: = [1633,1634]
operator: = [1633,1634]
===
match
---
name: kwargs [1877,1883]
name: kwargs [1877,1883]
===
match
---
atom_expr [5175,5181]
atom_expr [5182,5188]
===
match
---
trailer [2444,2448]
trailer [2444,2448]
===
match
---
trailer [2638,2661]
trailer [2638,2661]
===
match
---
argument [3999,4048]
argument [4006,4055]
===
match
---
atom_expr [2079,2103]
atom_expr [2079,2103]
===
match
---
name: sorted [4546,4552]
name: sorted [4553,4559]
===
match
---
trailer [5177,5181]
trailer [5184,5188]
===
match
---
name: params [2885,2891]
name: params [2885,2891]
===
match
---
atom_expr [3855,4103]
atom_expr [3862,4110]
===
match
---
simple_stmt [3270,3328]
simple_stmt [3277,3335]
===
match
---
name: change_state [5389,5401]
name: change_state [5396,5408]
===
match
---
trailer [5474,5478]
trailer [5481,5485]
===
match
---
name: task_instance [3887,3900]
name: task_instance [3894,3907]
===
match
---
param [2763,2779]
param [2763,2779]
===
match
---
simple_stmt [2537,2564]
simple_stmt [2537,2564]
===
match
---
trailer [2661,2663]
trailer [2661,2663]
===
match
---
name: open_slots [4692,4702]
name: open_slots [4699,4709]
===
match
---
name: log [2803,2806]
name: log [2803,2806]
===
match
---
simple_stmt [3181,3218]
simple_stmt [3181,3218]
===
match
---
string: "pool" [4260,4266]
string: "pool" [4267,4273]
===
match
---
suite [2157,2381]
suite [2157,2381]
===
match
---
trailer [1788,1798]
trailer [1788,1798]
===
match
---
string: "mark_success" [4218,4232]
string: "mark_success" [4225,4239]
===
match
---
operator: ** [2975,2977]
operator: ** [2975,2977]
===
match
---
name: ti [2537,2539]
name: ti [2537,2539]
===
match
---
arglist [2916,2926]
arglist [2916,2926]
===
match
---
atom_expr [2499,2505]
atom_expr [2499,2505]
===
match
---
funcdef [5320,5380]
funcdef [5327,5387]
===
match
---
name: ti [2734,2736]
name: ti [2734,2736]
===
match
---
funcdef [3358,4284]
funcdef [3365,4291]
===
match
---
name: e [3324,3325]
name: e [3331,3332]
===
match
---
string: """     This executor is meant for debugging purposes. It can be used with SQLite.      It executes one task instance at time. Additionally to support working     with sensors, all sensors ``mode`` will be automatically set to "reschedule".     """ [1249,1497]
string: """     This executor is meant for debugging purposes. It can be used with SQLite.      It executes one task instance at time. Additionally to support working     with sensors, all sensors ``mode`` will be automatically set to "reschedule".     """ [1249,1497]
===
match
---
parameters [5401,5452]
parameters [5408,5459]
===
match
---
name: queue_task_instance [3362,3381]
name: queue_task_instance [3369,3388]
===
match
---
name: key [5408,5411]
name: key [5415,5418]
===
match
---
operator: -> [3757,3759]
operator: -> [3764,3766]
===
match
---
name: self [2719,2723]
name: self [2719,2723]
===
match
---
name: ti [2074,2076]
name: ti [2074,2076]
===
match
---
name: ti [4758,4760]
name: ti [4765,4767]
===
match
---
simple_stmt [1503,1535]
simple_stmt [1503,1535]
===
match
---
name: key [2328,2331]
name: key [2328,2331]
===
match
---
simple_stmt [2580,2620]
simple_stmt [2580,2620]
===
match
---
simple_stmt [3087,3099]
simple_stmt [3087,3099]
===
match
---
operator: } [2925,2926]
operator: } [2925,2926]
===
match
---
param [3558,3595]
param [3565,3602]
===
match
---
name: UPSTREAM_FAILED [2274,2289]
name: UPSTREAM_FAILED [2274,2289]
===
match
---
except_clause [3107,3128]
except_clause [3107,3128]
===
match
---
atom_expr [2550,2562]
atom_expr [2550,2562]
===
match
---
name: self [2174,2178]
name: self [2174,2178]
===
match
---
parameters [4306,4329]
parameters [4313,4336]
===
match
---
name: task_instance [4068,4081]
name: task_instance [4075,4088]
===
match
---
suite [4941,5315]
suite [4948,5322]
===
match
---
atom_expr [5266,5314]
atom_expr [5273,5321]
===
match
---
import_from [1004,1042]
import_from [1004,1042]
===
match
---
name: pop [4777,4780]
name: pop [4784,4787]
===
match
---
trailer [2257,2267]
trailer [2257,2267]
===
match
---
name: State [2606,2611]
name: State [2606,2611]
===
match
---
atom_expr [2440,2520]
atom_expr [2440,2520]
===
match
---
suite [5461,5608]
suite [5468,5615]
===
match
---
operator: , [2833,2834]
operator: , [2833,2834]
===
match
---
subscriptlist [1738,1769]
subscriptlist [1738,1769]
===
match
---
name: debug [2807,2812]
name: debug [2807,2812]
===
match
---
operator: = [4544,4545]
operator: = [4551,4552]
===
match
---
name: self [3855,3859]
name: self [3862,3866]
===
match
---
simple_stmt [2440,2521]
simple_stmt [2440,2521]
===
match
---
name: ti [5104,5106]
name: ti [5111,5113]
===
match
---
argument [4605,4626]
argument [4612,4633]
===
match
---
trailer [2178,2182]
trailer [2178,2182]
===
match
---
operator: , [4048,4049]
operator: , [4055,4056]
===
match
---
trailer [5149,5154]
trailer [5156,5161]
===
match
---
expr_stmt [2702,2737]
expr_stmt [2702,2737]
===
match
---
name: remove [5551,5557]
name: remove [5558,5564]
===
match
---
name: ti [2208,2210]
name: ti [2208,2210]
===
match
---
name: FAILED [3210,3216]
name: FAILED [3210,3216]
===
match
---
atom_expr [2997,3034]
atom_expr [2997,3034]
===
match
---
name: fail_fast [1789,1798]
name: fail_fast [1789,1798]
===
match
---
name: str [3738,3741]
name: str [3745,3748]
===
match
---
name: open_slots [4313,4323]
name: open_slots [4320,4330]
===
match
---
name: job_id [2957,2963]
name: job_id [2957,2963]
===
match
---
name: str [3698,3701]
name: str [3705,3708]
===
match
---
name: State [5183,5188]
name: State [5190,5195]
===
match
---
parameters [5333,5339]
parameters [5340,5346]
===
match
---
tfpdef [3405,3432]
tfpdef [3412,3439]
===
match
---
operator: -> [1990,1992]
operator: -> [1990,1992]
===
match
---
name: add [4848,4851]
name: add [4855,4858]
===
match
---
name: List [988,992]
name: List [988,992]
===
match
---
suite [1559,1839]
suite [1559,1839]
===
match
---
trailer [4583,4589]
trailer [4590,4596]
===
match
---
name: event_buffer [5576,5588]
name: event_buffer [5583,5595]
===
match
---
name: State [5292,5297]
name: State [5299,5304]
===
match
---
argument [2975,2983]
argument [2975,2983]
===
match
---
operator: , [5406,5407]
operator: , [5413,5414]
===
match
---
name: sync [1979,1983]
name: sync [1979,1983]
===
match
---
atom_expr [4835,4856]
atom_expr [4842,4863]
===
match
---
atom_expr [4681,4729]
atom_expr [4688,4736]
===
match
---
name: set_state [2540,2549]
name: set_state [2540,2549]
===
match
---
string: "fail_fast" [1826,1837]
string: "fail_fast" [1826,1837]
===
match
---
operator: { [4204,4205]
operator: { [4211,4212]
===
match
---
name: ti [2853,2855]
name: ti [2853,2855]
===
match
---
simple_stmt [4869,4914]
simple_stmt [4876,4921]
===
match
---
not_test [2138,2156]
not_test [2138,2156]
===
match
---
dotted_name [1105,1132]
dotted_name [1105,1132]
===
match
---
atom_expr [4008,4048]
atom_expr [4015,4055]
===
match
---
simple_stmt [2847,2860]
simple_stmt [2847,2860]
===
match
---
name: self [3181,3185]
name: self [3181,3185]
===
match
---
name: __init__ [1544,1552]
name: __init__ [1544,1552]
===
match
---
name: info [5603,5607]
name: info [5610,5614]
===
match
---
trailer [3232,3255]
trailer [3232,3255]
===
match
---
operator: , [2604,2605]
operator: , [2604,2605]
===
match
---
param [2757,2762]
param [2757,2762]
===
match
---
simple_stmt [941,958]
simple_stmt [941,958]
===
match
---
name: _ [4755,4756]
name: _ [4762,4763]
===
match
---
operator: , [1152,1153]
operator: , [1152,1153]
===
match
---
operator: = [2851,2852]
operator: = [2851,2852]
===
match
---
name: task_instance [3919,3932]
name: task_instance [3926,3939]
===
match
---
param [3683,3710]
param [3690,3717]
===
match
---
name: change_state [3186,3198]
name: change_state [3186,3198]
===
match
---
name: self [2307,2311]
name: self [2307,2311]
===
match
---
trailer [2413,2420]
trailer [2413,2420]
===
match
---
atom_expr [2940,2984]
atom_expr [2940,2984]
===
match
---
atom_expr [4546,4663]
atom_expr [4553,4670]
===
match
---
name: ti [5284,5286]
name: ti [5291,5293]
===
match
---
operator: , [3548,3549]
operator: , [3555,3556]
===
match
---
name: airflow [1175,1182]
name: airflow [1175,1182]
===
match
---
trailer [4847,4851]
trailer [4854,4858]
===
match
---
string: "debug" [1817,1824]
string: "debug" [1817,1824]
===
match
---
parameters [1983,1989]
parameters [1983,1989]
===
match
---
name: self [1862,1866]
name: self [1862,1866]
===
match
---
atom_expr [3320,3326]
atom_expr [3327,3333]
===
match
---
name: key [2847,2850]
name: key [2847,2850]
===
match
---
arglist [2188,2237]
arglist [2188,2237]
===
match
---
name: self [4796,4800]
name: self [4803,4807]
===
match
---
operator: = [1799,1800]
operator: = [1799,1800]
===
match
---
param [1868,1874]
param [1868,1874]
===
match
---
name: State [2333,2338]
name: State [2333,2338]
===
match
---
operator: = [3743,3744]
operator: = [3750,3751]
===
match
---
name: FAILED [2513,2519]
name: FAILED [2513,2519]
===
match
---
funcdef [5385,5608]
funcdef [5392,5615]
===
match
---
trailer [5478,5484]
trailer [5485,5491]
===
match
---
dotted_name [1009,1030]
dotted_name [1009,1030]
===
match
---
operator: , [2922,2923]
operator: , [2922,2923]
===
match
---
atom_expr [1733,1770]
atom_expr [1733,1770]
===
match
---
trailer [1526,1532]
trailer [1526,1532]
===
match
---
trailer [1573,1575]
trailer [1573,1575]
===
match
---
name: tasks_to_run [1600,1612]
name: tasks_to_run [1600,1612]
===
match
---
tfpdef [3519,3540]
tfpdef [3526,3547]
===
match
---
suite [1998,2738]
suite [1998,2738]
===
match
---
name: ignore_task_deps [3604,3620]
name: ignore_task_deps [3611,3627]
===
match
---
name: str [5437,5440]
name: str [5444,5447]
===
match
---
expr_stmt [2847,2859]
expr_stmt [2847,2859]
===
match
---
name: state [5596,5601]
name: state [5603,5608]
===
match
---
atom_expr [5231,5252]
atom_expr [5238,5259]
===
match
---
string: "Popping %s from executor task queue." [5485,5523]
string: "Popping %s from executor task queue." [5492,5530]
===
match
---
operator: -> [4330,4332]
operator: -> [4337,4339]
===
match
---
expr_stmt [4531,4663]
expr_stmt [4538,4670]
===
match
---
simple_stmt [4796,4823]
simple_stmt [4803,4830]
===
match
---
name: self [4835,4839]
name: self [4842,4846]
===
match
---
trailer [2555,2562]
trailer [2555,2562]
===
match
---
name: task_succeeded [2142,2156]
name: task_succeeded [2142,2156]
===
match
---
name: super [1568,1573]
name: super [1568,1573]
===
match
---
name: base_executor [1066,1079]
name: base_executor [1066,1079]
===
match
---
name: threading [1517,1526]
name: threading [1517,1526]
===
match
---
trailer [4780,4783]
trailer [4787,4790]
===
match
---
name: self [2440,2444]
name: self [2440,2444]
===
match
---
name: ti [2636,2638]
name: ti [2636,2638]
===
match
---
trailer [3001,3014]
trailer [3001,3014]
===
match
---
name: running [4840,4847]
name: running [4847,4854]
===
match
---
return_stmt [3087,3098]
return_stmt [3087,3098]
===
match
---
operator: , [4272,4273]
operator: , [4279,4280]
===
match
---
argument [4640,4652]
argument [4647,4659]
===
match
---
operator: , [4652,4653]
operator: , [4659,4660]
===
match
---
name: ignore_depends_on_past [3558,3580]
name: ignore_depends_on_past [3565,3587]
===
match
---
arglist [2813,2837]
arglist [2813,2837]
===
match
---
operator: = [2022,2023]
operator: = [2022,2023]
===
match
---
atom_expr [2580,2619]
atom_expr [2580,2619]
===
match
---
simple_stmt [4165,4284]
simple_stmt [4172,4291]
===
match
---
operator: , [4756,4757]
operator: , [4763,4764]
===
match
---
name: terminate [5324,5333]
name: terminate [5331,5340]
===
match
---
string: """         Triggers tasks. Instead of calling exec_async we just         add task instance to tasks_to_run queue.          :param open_slots: Number of open slots         """ [4347,4522]
string: """         Triggers tasks. Instead of calling exec_async we just         add task instance to tasks_to_run queue.          :param open_slots: Number of open slots         """ [4354,4529]
===
match
---
trailer [3873,4103]
trailer [3880,4110]
===
match
---
operator: } [4282,4283]
operator: } [4289,4290]
===
match
---
expr_stmt [1784,1838]
expr_stmt [1784,1838]
===
match
---
trailer [5557,5562]
trailer [5564,5569]
===
match
---
trailer [5575,5588]
trailer [5582,5595]
===
match
---
tfpdef [3644,3665]
tfpdef [3651,3672]
===
match
---
trailer [4690,4728]
trailer [4697,4735]
===
match
---
file_input [787,5608]
file_input [787,5615]
===
match
---
trailer [5145,5149]
trailer [5152,5156]
===
match
---
name: log [2179,2182]
name: log [2179,2182]
===
match
---
name: Any [977,980]
name: Any [977,980]
===
match
---
string: """ DebugExecutor  .. seealso::     For more information on how the DebugExecutor works, take a look at the guide:     :ref:`executor:DebugExecutor` """ [787,939]
string: """ DebugExecutor  .. seealso::     For more information on how the DebugExecutor works, take a look at the guide:     :ref:`executor:DebugExecutor` """ [787,939]
===
match
---
trailer [3198,3217]
trailer [3198,3217]
===
match
---
name: exception [3279,3288]
name: exception [3286,3295]
===
match
---
name: self [5334,5338]
name: self [5341,5345]
===
match
---
simple_stmt [2372,2381]
simple_stmt [2372,2381]
===
match
---
operator: , [4092,4093]
operator: , [4099,4100]
===
match
---
name: key [4852,4855]
name: key [4859,4862]
===
match
---
name: Optional [3689,3697]
name: Optional [3696,3704]
===
match
---
name: ti [2598,2600]
name: ti [2598,2600]
===
match
---
atom_expr [4708,4725]
atom_expr [4715,4732]
===
match
---
atom [4748,4761]
atom [4755,4768]
===
match
---
name: _terminated [1503,1514]
name: _terminated [1503,1514]
===
match
---
param [3604,3635]
param [3611,3642]
===
match
---
lambdef [4609,4626]
lambdef [4616,4633]
===
match
---
simple_stmt [5357,5380]
simple_stmt [5364,5387]
===
match
---
trailer [3255,3257]
trailer [3255,3264]
===
match
---
operator: , [5181,5182]
operator: , [5188,5189]
===
match
---
simple_stmt [2255,2291]
simple_stmt [2255,2291]
===
match
---
trailer [3274,3278]
trailer [3281,3285]
===
match
---
name: self [4708,4712]
name: self [4715,4719]
===
match
---
name: executors [1056,1065]
name: executors [1056,1065]
===
match
---
name: tasks_params [1719,1731]
name: tasks_params [1719,1731]
===
match
---
operator: , [3900,3901]
operator: , [3907,3908]
===
match
---
name: self [2580,2584]
name: self [2580,2584]
===
match
---
trailer [5373,5377]
trailer [5380,5384]
===
match
---
name: ti [2916,2918]
name: ti [2916,2918]
===
match
---
trailer [2221,2237]
trailer [2221,2237]
===
match
---
name: args [1869,1873]
name: args [1869,1873]
===
match
---
import_as_names [977,1002]
import_as_names [977,1002]
===
match
---
name: self [1595,1599]
name: self [1595,1599]
===
match
---
name: int [4325,4328]
name: int [4332,4335]
===
match
---
name: str [3498,3501]
name: str [3505,3508]
===
match
---
trailer [2812,2838]
trailer [2812,2838]
===
match
---
operator: = [2717,2718]
operator: = [2717,2718]
===
match
---
simple_stmt [5141,5206]
simple_stmt [5148,5213]
===
match
---
name: task_succeeded [2702,2716]
name: task_succeeded [2702,2716]
===
match
---
testlist_star_expr [4743,4761]
testlist_star_expr [4750,4768]
===
match
---
name: task [4082,4086]
name: task [4089,4093]
===
match
---
operator: , [4746,4747]
operator: , [4753,4754]
===
match
---
name: self [4566,4570]
name: self [4573,4577]
===
match
---
simple_stmt [5538,5563]
simple_stmt [5545,5570]
===
match
---
trailer [3278,3288]
trailer [3285,3295]
===
match
---
name: change_state [2312,2324]
name: change_state [2312,2324]
===
match
---
operator: , [4626,4627]
operator: , [4633,4634]
===
match
---
operator: , [3934,3935]
operator: , [3941,3942]
===
match
---
operator: = [4647,4648]
operator: = [4654,4655]
===
match
---
atom_expr [1714,1731]
atom_expr [1714,1731]
===
match
---
simple_stmt [787,940]
simple_stmt [787,940]
===
match
---
try_stmt [2868,3353]
try_stmt [2868,3360]
===
match
---
tfpdef [3558,3586]
tfpdef [3565,3593]
===
match
---
trailer [5188,5204]
trailer [5195,5211]
===
match
---
name: Any [1765,1768]
name: Any [1765,1768]
===
match
---
operator: = [2077,2078]
operator: = [2077,2078]
===
match
---
name: bool [3456,3460]
name: bool [3463,3467]
===
match
---
funcdef [1844,1970]
funcdef [1844,1970]
===
match
---
atom_expr [1595,1612]
atom_expr [1595,1612]
===
match
---
name: _terminated [5362,5373]
name: _terminated [5369,5380]
===
match
---
name: self [2079,2083]
name: self [2079,2083]
===
match
---
funcdef [1975,2738]
funcdef [1975,2738]
===
match
---
name: key [2856,2859]
name: key [2856,2859]
===
match
---
trailer [2100,2103]
trailer [2100,2103]
===
match
---
name: _run_raw_task [2943,2956]
name: _run_raw_task [2943,2956]
===
match
---
operator: , [4750,4751]
operator: , [4757,4758]
===
match
---
tfpdef [3442,3460]
tfpdef [3449,3467]
===
match
---
simple_stmt [1595,1638]
simple_stmt [1595,1638]
===
match
---
name: DebugExecutor [1216,1229]
name: DebugExecutor [1216,1229]
===
match
---
operator: -> [4933,4935]
operator: -> [4940,4942]
===
match
---
name: State [3204,3209]
name: State [3204,3209]
===
match
---
name: ti [2964,2966]
name: ti [2964,2966]
===
match
---
atom_expr [2719,2737]
atom_expr [2719,2737]
===
match
---
simple_stmt [1100,1170]
simple_stmt [1100,1170]
===
match
---
trailer [3049,3072]
trailer [3049,3072]
===
match
---
atom_expr [2208,2214]
atom_expr [2208,2214]
===
match
---
trailer [3154,3168]
trailer [3154,3168]
===
match
---
trailer [2210,2214]
trailer [2210,2214]
===
match
---
trailer [2453,2520]
trailer [2453,2520]
===
match
---
param [5442,5451]
param [5449,5458]
===
match
---
name: queued_tasks [4571,4583]
name: queued_tasks [4578,4590]
===
match
---
name: key [5525,5528]
name: key [5532,5535]
===
match
---
trailer [2501,2505]
trailer [2501,2505]
===
match
---
name: sorted_queue [4764,4776]
name: sorted_queue [4771,4783]
===
match
---
parameters [2756,2780]
parameters [2756,2780]
===
match
---
name: queued_tasks [4713,4725]
name: queued_tasks [4720,4732]
===
match
---
operator: -> [2781,2783]
operator: -> [2781,2783]
===
match
---
name: ti [5175,5177]
name: ti [5182,5184]
===
match
---
number: 0 [4781,4782]
number: 0 [4788,4789]
===
match
---
operator: -> [5340,5342]
operator: -> [5347,5349]
===
match
---
trailer [2802,2806]
trailer [2802,2806]
===
match
---
name: pop [2097,2100]
name: pop [2097,2100]
===
match
---
atom_expr [1568,1586]
atom_expr [1568,1586]
===
match
---
atom [1773,1775]
atom [1773,1775]
===
match
---
name: getboolean [1806,1816]
name: getboolean [1806,1816]
===
match
---
simple_stmt [3047,3075]
simple_stmt [3047,3075]
===
match
---
name: State [2507,2512]
name: State [2507,2512]
===
match
---
atom_expr [4165,4201]
atom_expr [4172,4208]
===
match
---
operator: , [4591,4592]
operator: , [4598,4599]
===
match
---
operator: , [1873,1874]
operator: , [1873,1874]
===
match
---
operator: , [3749,3750]
operator: , [3756,3757]
===
match
---
and_test [2119,2156]
and_test [2119,2156]
===
match
---
name: self [2997,3001]
name: self [2997,3001]
===
match
---
funcdef [4919,5315]
funcdef [4926,5322]
===
match
---
trailer [2083,2096]
trailer [2083,2096]
===
match
---
tfpdef [3604,3626]
tfpdef [3611,3633]
===
match
---
name: self [5402,5406]
name: self [5409,5413]
===
match
---
name: self [5571,5575]
name: self [5578,5582]
===
match
---
expr_stmt [1503,1534]
expr_stmt [1503,1534]
===
match
---
operator: -> [1885,1887]
operator: -> [1885,1887]
===
match
---
operator: = [3503,3504]
operator: = [3510,3511]
===
match
---
name: self [4927,4931]
name: self [4934,4938]
===
match
---
funcdef [1540,1839]
funcdef [1540,1839]
===
match
---
simple_stmt [5571,5608]
simple_stmt [5578,5615]
===
match
---
name: job_id [2967,2973]
name: job_id [2967,2973]
===
match
---
name: tasks_params [4170,4182]
name: tasks_params [4177,4189]
===
match
---
name: State [2550,2555]
name: State [2550,2555]
===
match
---
operator: = [5446,5447]
operator: = [5453,5454]
===
match
---
simple_stmt [2798,2839]
simple_stmt [2798,2839]
===
match
---
atom [1635,1637]
atom [1635,1637]
===
match
---
operator: , [1866,1867]
operator: , [1866,1867]
===
match
---
atom_expr [5538,5562]
atom_expr [5545,5569]
===
match
---
trailer [1816,1838]
trailer [1816,1838]
===
match
---
trailer [2096,2100]
trailer [2096,2100]
===
match
---
name: state [5430,5435]
name: state [5437,5442]
===
match
---
name: tasks_params [2899,2911]
name: tasks_params [2899,2911]
===
match
---
param [1984,1988]
param [1984,1988]
===
match
---
name: State [2216,2221]
name: State [2216,2221]
===
match
---
atom [4204,4283]
atom [4211,4290]
===
match
---
trailer [4851,4856]
trailer [4858,4863]
===
match
---
operator: ** [1875,1877]
operator: ** [1875,1877]
===
match
---
name: _run_finished_callback [2639,2661]
name: _run_finished_callback [2639,2661]
===
match
---
name: key [3015,3018]
name: key [3015,3018]
===
match
---
suite [3765,4284]
suite [3772,4291]
===
match
---
name: self [5538,5542]
name: self [5545,5549]
===
match
---
trailer [4021,4026]
trailer [4028,4033]
===
match
---
name: self [5141,5145]
name: self [5148,5152]
===
match
---
name: queue [4087,4092]
name: queue [4094,4099]
===
match
---
name: _run_task [2724,2733]
name: _run_task [2724,2733]
===
match
---
trailer [5361,5373]
trailer [5368,5380]
===
match
---
simple_stmt [3855,4104]
simple_stmt [3862,4111]
===
match
---
name: UPSTREAM_FAILED [2222,2237]
name: UPSTREAM_FAILED [2222,2237]
===
match
---
name: TaskInstance [3420,3432]
name: TaskInstance [3427,3439]
===
match
---
name: ti [2940,2942]
name: ti [2940,2942]
===
match
---
trailer [3859,3873]
trailer [3866,3880]
===
match
---
name: self [2043,2047]
name: self [2043,2047]
===
match
---
name: State [2268,2273]
name: State [2268,2273]
===
match
---
name: execute_async [1848,1861]
name: execute_async [1848,1861]
===
match
---
name: ti [5218,5220]
name: ti [5225,5227]
===
match
---
name: State [5231,5236]
name: State [5238,5243]
===
match
---
operator: , [2973,2974]
operator: , [2973,2974]
===
match
---
arglist [3289,3326]
arglist [3296,3333]
===
match
---
arglist [1817,1837]
arglist [1817,1837]
===
match
---
string: "Executing task: %s" [2813,2833]
string: "Executing task: %s" [2813,2833]
===
match
---
atom_expr [2333,2354]
atom_expr [2333,2354]
===
match
---
expr_stmt [4743,4783]
expr_stmt [4750,4790]
===
match
---
arglist [2454,2519]
arglist [2454,2519]
===
match
---
trailer [4817,4822]
trailer [4824,4829]
===
match
---
atom_expr [2916,2922]
atom_expr [2916,2922]
===
match
---
trailer [4893,4897]
trailer [4900,4904]
===
match
---
name: utils [1183,1188]
name: utils [1183,1188]
===
match
---
operator: = [4608,4609]
operator: = [4615,4616]
===
match
---
atom_expr [2537,2563]
atom_expr [2537,2563]
===
match
---
name: TaskInstanceKey [5413,5428]
name: TaskInstanceKey [5420,5435]
===
match
---
tfpdef [3683,3702]
tfpdef [3690,3709]
===
match
---
trailer [4169,4182]
trailer [4176,4189]
===
match
---
atom_expr [2598,2604]
atom_expr [2598,2604]
===
match
---
name: set_state [5221,5230]
name: set_state [5228,5237]
===
match
---
name: UPSTREAM_FAILED [2339,2354]
name: UPSTREAM_FAILED [2339,2354]
===
match
---
simple_stmt [4835,4857]
simple_stmt [4842,4864]
===
match
---
simple_stmt [2074,2104]
simple_stmt [2074,2104]
===
match
---
trailer [2918,2922]
trailer [2918,2922]
===
match
---
name: Optional [994,1002]
name: Optional [994,1002]
===
match
---
operator: , [3673,3674]
operator: , [3680,3681]
===
match
---
name: self [4307,4311]
name: self [4314,4318]
===
match
---
operator: , [5173,5174]
operator: , [5180,5181]
===
match
---
name: priority_weight_total [4027,4048]
name: priority_weight_total [4034,4055]
===
match
---
tfpdef [4313,4328]
tfpdef [4320,4335]
===
match
---
trailer [5114,5127]
trailer [5121,5134]
===
match
---
name: x [4619,4620]
name: x [4626,4627]
===
match
---
trailer [4800,4813]
trailer [4807,4820]
===
match
---
atom_expr [4619,4626]
atom_expr [4626,4633]
===
match
---
trailer [2401,2413]
trailer [2401,2413]
===
match
---
operator: = [3703,3704]
operator: = [3710,3711]
===
match
---
name: ignore_all_deps [3519,3534]
name: ignore_all_deps [3526,3541]
===
match
---
tfpdef [5430,5440]
tfpdef [5437,5447]
===
match
---
atom_expr [2325,2331]
atom_expr [2325,2331]
===
match
---
name: _ [4752,4753]
name: _ [4759,4760]
===
match
---
if_stmt [2394,2689]
if_stmt [2394,2689]
===
match
---
operator: , [5523,5524]
operator: , [5530,5531]
===
match
---
expr_stmt [2074,2103]
expr_stmt [2074,2103]
===
match
---
operator: , [3395,3396]
operator: , [3402,3403]
===
match
---
name: Dict [982,986]
name: Dict [982,986]
===
match
---
name: pop [2912,2915]
name: pop [2912,2915]
===
match
---
name: self [5266,5270]
name: self [5273,5277]
===
match
---
atom_expr [3689,3702]
atom_expr [3696,3709]
===
match
---
name: queue_command [3860,3873]
name: queue_command [3867,3880]
===
match
---
atom_expr [3915,3933]
atom_expr [3922,3940]
===
match
---
import_from [1043,1099]
import_from [1043,1099]
===
match
---
name: tasks_to_run [2048,2060]
name: tasks_to_run [2048,2060]
===
match
---
operator: = [2963,2964]
operator: = [2963,2964]
===
match
---
trailer [2338,2354]
trailer [2338,2354]
===
match
---
name: self [2397,2401]
name: self [2397,2401]
===
match
---
name: ti [2255,2257]
name: ti [2255,2257]
===
match
---
name: info [5442,5446]
name: info [5449,5453]
===
match
---
atom_expr [4869,4897]
atom_expr [4876,4904]
===
match
---
arglist [2325,2354]
arglist [2325,2354]
===
match
---
name: tasks_to_run [4874,4886]
name: tasks_to_run [4881,4893]
===
match
---
param [3644,3674]
param [3651,3681]
===
match
---
simple_stmt [4743,4784]
simple_stmt [4750,4791]
===
match
---
name: key [5178,5181]
name: key [5185,5188]
===
match
---
name: len [4704,4707]
name: len [4711,4714]
===
match
---
param [3719,3750]
param [3726,3757]
===
match
---
name: key [5589,5592]
name: key [5596,5599]
===
match
---
trailer [3160,3167]
trailer [3160,3167]
===
match
---
parameters [3381,3756]
parameters [3388,3763]
===
match
---
trailer [5542,5550]
trailer [5549,5557]
===
match
---
operator: , [5290,5291]
operator: , [5297,5298]
===
match
---
classdef [1210,5608]
classdef [1210,5615]
===
match
---
operator: = [3461,3462]
operator: = [3468,3469]
===
match
---
name: log [2445,2448]
name: log [2445,2448]
===
match
---
operator: , [2214,2215]
operator: , [2214,2215]
===
match
---
name: ti [3047,3049]
name: ti [3047,3049]
===
match
---
name: str [1760,1763]
name: str [1760,1763]
===
match
---
trailer [4686,4729]
trailer [4693,4736]
===
match
---
atom_expr [5141,5205]
atom_expr [5148,5212]
===
match
---
string: "Failed to execute task: %s." [3289,3318]
string: "Failed to execute task: %s." [3296,3325]
===
match
---
atom_expr [4566,4591]
atom_expr [4573,4598]
===
match
---
argument [2957,2973]
argument [2957,2973]
===
match
---
operator: , [2505,2506]
operator: , [2505,2506]
===
match
---
name: bool [3622,3626]
name: bool [3629,3633]
===
match
---
trailer [2539,2549]
trailer [2539,2549]
===
match
---
name: debug [5479,5484]
name: debug [5486,5491]
===
match
---
name: is_set [2414,2420]
name: is_set [2414,2420]
===
match
---
name: BaseExecutor [1087,1099]
name: BaseExecutor [1087,1099]
===
match
---
operator: , [4702,4703]
operator: , [4709,4710]
===
match
---
operator: , [992,993]
operator: , [992,993]
===
match
---
operator: = [1515,1516]
operator: = [1515,1516]
===
match
---
operator: = [3587,3588]
operator: = [3594,3595]
===
match
---
simple_stmt [3230,3258]
simple_stmt [3230,3265]
===
match
---
atom_expr [5292,5313]
atom_expr [5299,5320]
===
match
---
trailer [1532,1534]
trailer [1532,1534]
===
match
---
atom_expr [3020,3033]
atom_expr [3020,3033]
===
match
---
name: airflow [1009,1016]
name: airflow [1009,1016]
===
match
---
simple_stmt [2007,2029]
simple_stmt [2007,2029]
===
match
---
name: conf [1801,1805]
name: conf [1801,1805]
===
match
---
trailer [4873,4886]
trailer [4880,4893]
===
match
---
param [5402,5407]
param [5409,5414]
===
match
---
import_as_names [1140,1169]
import_as_names [1140,1169]
===
match
---
simple_stmt [5218,5254]
simple_stmt [5225,5261]
===
match
---
atom_expr [2853,2859]
atom_expr [2853,2859]
===
match
---
operator: , [5428,5429]
operator: , [5435,5436]
===
match
---
trailer [5220,5230]
trailer [5227,5237]
===
match
---
arglist [5284,5313]
arglist [5291,5320]
===
match
---
name: key [4743,4746]
name: key [4750,4753]
===
match
---
import_from [1100,1169]
import_from [1100,1169]
===
match
---
trailer [1599,1612]
trailer [1599,1612]
===
match
---
name: State [1202,1207]
name: State [1202,1207]
===
match
---
trailer [1805,1816]
trailer [1805,1816]
===
match
---
name: self [1984,1988]
name: self [1984,1988]
===
match
---
import_name [941,957]
import_name [941,957]
===
match
---
trailer [5236,5252]
trailer [5243,5259]
===
match
---
atom_expr [2119,2133]
atom_expr [2119,2133]
===
match
---
name: append [4887,4893]
name: append [4894,4900]
===
match
---
trailer [2942,2956]
trailer [2942,2956]
===
match
---
atom [3914,3934]
atom [3921,3941]
===
match
---
name: UPSTREAM_FAILED [5189,5204]
name: UPSTREAM_FAILED [5196,5211]
===
match
---
number: 1 [4624,4625]
number: 1 [4631,4632]
===
match
---
param [4313,4328]
param [4320,4335]
===
match
---
trailer [4712,4725]
trailer [4719,4732]
===
match
---
name: configuration [1017,1030]
name: configuration [1017,1030]
===
match
---
name: ti [3142,3144]
name: ti [3142,3144]
===
match
---
name: TaskInstanceKey [1154,1169]
name: TaskInstanceKey [1154,1169]
===
match
---
name: ti [2763,2765]
name: ti [2763,2765]
===
match
---
name: end [4923,4926]
name: end [4930,4933]
===
match
---
name: task_instance [4008,4021]
name: task_instance [4015,4028]
===
match
---
trailer [3697,3702]
trailer [3704,3709]
===
match
---
suite [3129,3353]
suite [3129,3360]
===
match
---
operator: { [2924,2925]
operator: { [2924,2925]
===
match
---
name: params [2977,2983]
name: params [2977,2983]
===
match
---
name: bool [2784,2788]
name: bool [2784,2788]
===
match
---
string: """         When the method is called we just set states of queued tasks         to UPSTREAM_FAILED marking them as not executed.         """ [4950,5091]
string: """         When the method is called we just set states of queued tasks         to UPSTREAM_FAILED marking them as not executed.         """ [4957,5098]
===
match
---
trailer [4813,4817]
trailer [4820,4824]
===
match
---
suite [1893,1970]
suite [1893,1970]
===
match
---
atom_expr [3729,3742]
atom_expr [3736,3749]
===
match
---
name: key [2919,2922]
name: key [2919,2922]
===
match
---
name: _ [4749,4750]
name: _ [4756,4757]
===
match
---
name: mark_success [4234,4246]
name: mark_success [4241,4253]
===
match
---
trailer [2898,2911]
trailer [2898,2911]
===
match
---
name: Optional [3489,3497]
name: Optional [3496,3504]
===
match
---
name: _run_task [2747,2756]
name: _run_task [2747,2756]
===
match
---
trailer [2915,2927]
trailer [2915,2927]
===
match
---
operator: , [3709,3710]
operator: , [3716,3717]
===
match
---
simple_stmt [2885,2928]
simple_stmt [2885,2928]
===
match
---
name: models [1113,1119]
name: models [1113,1119]
===
match
---
arglist [2598,2618]
arglist [2598,2618]
===
match
---
funcdef [2743,3353]
funcdef [2743,3360]
===
insert-tree
---
argument [3256,3263]
    name: error [3256,3261]
    operator: = [3261,3262]
    name: e [3262,3263]
to
trailer [3255,3257]
at 0
