===
match
---
comparison [6974,6994]
comparison [6974,6994]
===
match
---
simple_stmt [7887,7920]
simple_stmt [7887,7920]
===
match
---
name: host_block [7076,7086]
name: host_block [7076,7086]
===
match
---
operator: , [12627,12628]
operator: , [12627,12628]
===
match
---
expr_stmt [7126,7165]
expr_stmt [7126,7165]
===
match
---
operator: , [3966,3967]
operator: , [3966,3967]
===
match
---
operator: = [6568,6569]
operator: = [6568,6569]
===
match
---
name: Column [988,994]
name: Column [988,994]
===
match
---
suite [5360,5614]
suite [5360,5614]
===
match
---
name: import_string [1480,1493]
name: import_string [1480,1493]
===
match
---
expr_stmt [10646,10796]
expr_stmt [10646,10796]
===
match
---
trailer [4564,4576]
trailer [4564,4576]
===
match
---
name: extra [4732,4737]
name: extra [4732,4737]
===
match
---
name: self [5275,5279]
name: self [5275,5279]
===
match
---
trailer [8405,8415]
trailer [8405,8415]
===
match
---
name: _parse_from_uri [5059,5074]
name: _parse_from_uri [5059,5074]
===
match
---
parameters [7854,7860]
parameters [7854,7860]
===
match
---
if_stmt [10312,10437]
if_stmt [10312,10437]
===
match
---
simple_stmt [10365,10437]
simple_stmt [10365,10437]
===
match
---
expr_stmt [7044,7066]
expr_stmt [7044,7066]
===
match
---
name: bytes [8327,8332]
name: bytes [8327,8332]
===
match
---
operator: = [5674,5675]
operator: = [5674,5675]
===
match
---
name: args [1686,1690]
name: args [1686,1690]
===
match
---
string: """Return connection in URI format""" [6627,6664]
string: """Return connection in URI format""" [6627,6664]
===
match
---
atom_expr [9365,9375]
atom_expr [9365,9375]
===
match
---
atom_expr [10501,10512]
atom_expr [10501,10512]
===
match
---
name: property [12751,12759]
name: property [12751,12759]
===
match
---
name: Boolean [3889,3896]
name: Boolean [3889,3896]
===
match
---
operator: = [3904,3905]
operator: = [3904,3905]
===
match
---
arglist [10137,10165]
arglist [10137,10165]
===
match
---
name: quoted_schema [6085,6098]
name: quoted_schema [6085,6098]
===
match
---
arglist [12544,12734]
arglist [12544,12734]
===
match
---
name: decode [9760,9766]
name: decode [9760,9766]
===
match
---
name: hostname [2218,2226]
name: hostname [2218,2226]
===
match
---
atom_expr [4010,4033]
atom_expr [4010,4033]
===
match
---
trailer [6304,6309]
trailer [6304,6309]
===
match
---
atom_expr [11983,12000]
atom_expr [11983,12000]
===
match
---
raise_stmt [8059,8292]
raise_stmt [8059,8292]
===
match
---
name: self [8242,8246]
name: self [8242,8246]
===
match
---
argument [12408,12420]
argument [12408,12420]
===
match
---
arglist [9743,9757]
arglist [9743,9757]
===
match
---
name: login [6840,6845]
name: login [6840,6845]
===
match
---
trailer [5963,5974]
trailer [5963,5974]
===
match
---
name: self [11869,11873]
name: self [11869,11873]
===
match
---
name: is_encrypted [8029,8041]
name: is_encrypted [8029,8041]
===
match
---
name: extra [5309,5314]
name: extra [5309,5314]
===
match
---
name: self [9521,9525]
name: self [9521,9525]
===
match
---
trailer [3512,3514]
trailer [3512,3514]
===
match
---
fstring_start: f" [6679,6681]
fstring_start: f" [6679,6681]
===
match
---
and_test [7931,7967]
and_test [7931,7967]
===
match
---
expr_stmt [7707,7725]
expr_stmt [7707,7725]
===
match
---
trailer [7788,7798]
trailer [7788,7798]
===
match
---
name: _extra [9858,9864]
name: _extra [9858,9864]
===
match
---
operator: , [12733,12734]
operator: , [12733,12734]
===
match
---
name: Optional [4242,4250]
name: Optional [4242,4250]
===
match
---
trailer [8326,8358]
trailer [8326,8358]
===
match
---
name: declared_attr [1057,1070]
name: declared_attr [1057,1070]
===
match
---
operator: , [10150,10151]
operator: , [10150,10151]
===
match
---
param [9552,9557]
param [9552,9557]
===
match
---
operator: , [10661,10662]
operator: , [10661,10662]
===
match
---
trailer [11268,11276]
trailer [11268,11276]
===
match
---
atom_expr [5586,5613]
atom_expr [5586,5613]
===
match
---
arglist [3808,3832]
arglist [3808,3832]
===
match
---
name: str [4474,4477]
name: str [4474,4477]
===
match
---
atom_expr [6026,6037]
atom_expr [6026,6037]
===
match
---
atom_expr [3498,3533]
atom_expr [3498,3533]
===
match
---
trailer [3859,3861]
trailer [3859,3861]
===
match
---
name: parse_qsl [908,917]
name: parse_qsl [908,917]
===
match
---
operator: = [2085,2086]
operator: = [2085,2086]
===
match
---
operator: = [3698,3699]
operator: = [3698,3699]
===
match
---
simple_stmt [10931,10975]
simple_stmt [10931,10975]
===
match
---
name: self [5891,5895]
name: self [5891,5895]
===
match
---
atom_expr [13439,13486]
atom_expr [13400,13447]
===
match
---
atom_expr [3623,3634]
atom_expr [3623,3634]
===
match
---
name: Optional [4163,4171]
name: Optional [4163,4171]
===
match
---
operator: == [5748,5750]
operator: == [5748,5750]
===
match
---
trailer [3681,3687]
trailer [3681,3687]
===
match
---
trailer [10400,10410]
trailer [10400,10410]
===
match
---
name: self [12641,12645]
name: self [12641,12645]
===
match
---
trailer [11898,11904]
trailer [11898,11904]
===
match
---
operator: , [10767,10768]
operator: , [10767,10768]
===
match
---
operator: = [2017,2018]
operator: = [2017,2018]
===
match
---
name: fernet [8557,8563]
name: fernet [8557,8563]
===
match
---
trailer [10732,10796]
trailer [10732,10796]
===
match
---
trailer [11801,11809]
trailer [11801,11809]
===
match
---
atom_expr [3616,3651]
atom_expr [3616,3651]
===
match
---
name: conn_type [5777,5786]
name: conn_type [5777,5786]
===
match
---
atom_expr [10704,10796]
atom_expr [10704,10796]
===
match
---
trailer [10140,10150]
trailer [10140,10150]
===
match
---
expr_stmt [4529,4551]
expr_stmt [4529,4551]
===
match
---
atom_expr [4319,4332]
atom_expr [4319,4332]
===
match
---
name: host [11828,11832]
name: host [11828,11832]
===
match
---
name: warnings [11462,11470]
name: warnings [11462,11470]
===
match
---
atom_expr [7990,8002]
atom_expr [7990,8002]
===
match
---
trailer [7107,7112]
trailer [7107,7112]
===
match
---
name: authority_block [6974,6989]
name: authority_block [6974,6989]
===
match
---
simple_stmt [1652,1702]
simple_stmt [1652,1702]
===
match
---
name: stacklevel [12408,12418]
name: stacklevel [12408,12418]
===
match
---
name: str [4439,4442]
name: str [4439,4442]
===
match
---
trailer [12217,12222]
trailer [12217,12222]
===
match
---
name: port [7260,7264]
name: port [7260,7264]
===
match
---
name: self [10501,10505]
name: self [10501,10505]
===
match
---
return_stmt [8883,8967]
return_stmt [8883,8967]
===
match
---
string: """Return hook based on conn_type.""" [10600,10637]
string: """Return hook based on conn_type.""" [10600,10637]
===
match
---
atom_expr [7643,7689]
atom_expr [7643,7689]
===
match
---
name: query [6400,6405]
name: query [6400,6405]
===
match
---
param [1861,1870]
param [1861,1870]
===
match
---
trailer [6707,6709]
trailer [6707,6709]
===
match
---
atom_expr [1584,1647]
atom_expr [1584,1647]
===
match
---
if_stmt [5034,5323]
if_stmt [5034,5323]
===
match
---
name: query [6581,6586]
name: query [6581,6586]
===
match
---
simple_stmt [8557,8579]
simple_stmt [8557,8579]
===
match
---
number: 500 [3714,3717]
number: 500 [3714,3717]
===
match
---
trailer [5058,5074]
trailer [5058,5074]
===
match
---
name: Text [3677,3681]
name: Text [3677,3681]
===
match
---
name: str [4172,4175]
name: str [4172,4175]
===
match
---
expr_stmt [6557,6587]
expr_stmt [6557,6587]
===
match
---
funcdef [12027,12745]
funcdef [12027,12745]
===
match
---
trailer [3622,3651]
trailer [3622,3651]
===
match
---
name: utils [1395,1400]
name: utils [1395,1400]
===
match
---
trailer [1684,1701]
trailer [1684,1701]
===
match
---
expr_stmt [7008,7030]
expr_stmt [7008,7030]
===
match
---
trailer [6013,6017]
trailer [6013,6017]
===
match
---
name: self [5106,5110]
name: self [5106,5110]
===
match
---
operator: } [7264,7265]
operator: } [7264,7265]
===
match
---
name: self [9552,9556]
name: self [9552,9556]
===
match
---
string: """Encrypt password and set in object attribute.""" [8475,8526]
string: """Encrypt password and set in object attribute.""" [8475,8526]
===
match
---
operator: = [3843,3844]
operator: = [3843,3844]
===
match
---
operator: += [6826,6828]
operator: += [6826,6828]
===
match
---
name: port [7325,7329]
name: port [7325,7329]
===
match
---
operator: = [3592,3593]
operator: = [3592,3593]
===
match
---
name: self [12950,12954]
name: self [12950,12954]
===
match
---
arglist [11797,12011]
arglist [11797,12011]
===
match
---
simple_stmt [816,849]
simple_stmt [816,849]
===
match
---
string: "connection" [3475,3487]
string: "connection" [3475,3487]
===
match
---
name: models [1295,1301]
name: models [1295,1301]
===
match
---
suite [7567,7597]
suite [7567,7597]
===
match
---
name: self [9456,9460]
name: self [9456,9460]
===
match
---
strings [4801,5011]
strings [4801,5011]
===
match
---
name: self [4099,4103]
name: self [4099,4103]
===
match
---
suite [5093,5323]
suite [5093,5323]
===
match
---
simple_stmt [5926,5975]
simple_stmt [5926,5975]
===
match
---
name: parse_qsl [7648,7657]
name: parse_qsl [7648,7657]
===
match
---
trailer [12620,12627]
trailer [12620,12627]
===
match
---
funcdef [13170,13617]
funcdef [13131,13578]
===
match
---
atom_expr [6273,6291]
atom_expr [6273,6291]
===
match
---
decorated [9922,10168]
decorated [9922,10168]
===
match
---
name: parse_netloc_to_hostname [1500,1524]
name: parse_netloc_to_hostname [1500,1524]
===
match
---
suite [5655,6588]
suite [5655,6588]
===
match
---
name: extra [6493,6498]
name: extra [6493,6498]
===
match
---
parameters [11294,11300]
parameters [11294,11300]
===
match
---
trailer [3561,3569]
trailer [3561,3569]
===
match
---
trailer [3826,3832]
trailer [3826,3832]
===
match
---
name: query [6501,6506]
name: query [6501,6506]
===
match
---
name: conn_type [10751,10760]
name: conn_type [10751,10760]
===
match
---
atom_expr [6375,6431]
atom_expr [6375,6431]
===
match
---
name: base [1257,1261]
name: base [1257,1261]
===
match
---
number: 1 [2111,2112]
number: 1 [2111,2112]
===
match
---
parameters [6604,6610]
parameters [6604,6610]
===
match
---
trailer [2028,2035]
trailer [2028,2035]
===
match
---
arglist [8898,8966]
arglist [8898,8966]
===
match
---
name: extra [6562,6567]
name: extra [6562,6567]
===
match
---
operator: , [12556,12557]
operator: , [12556,12557]
===
match
---
name: classmethod [13154,13165]
name: classmethod [13115,13126]
===
match
---
param [4309,4340]
param [4309,4340]
===
match
---
decorated [12750,13148]
decorated [12750,13109]
===
match
---
name: package_name [10678,10690]
name: package_name [10678,10690]
===
match
---
import_from [1439,1493]
import_from [1439,1493]
===
match
---
name: __repr__ [11233,11241]
name: __repr__ [11233,11241]
===
match
---
trailer [9339,9397]
trailer [9339,9397]
===
match
---
operator: , [3896,3897]
operator: , [3896,3897]
===
match
---
operator: ** [5607,5609]
operator: ** [5607,5609]
===
match
---
tfpdef [5645,5653]
tfpdef [5645,5653]
===
match
---
name: self [7146,7150]
name: self [7146,7150]
===
match
---
simple_stmt [1382,1439]
simple_stmt [1382,1439]
===
match
---
trailer [6580,6587]
trailer [6580,6587]
===
match
---
suite [8466,8707]
suite [8466,8707]
===
match
---
operator: = [3799,3800]
operator: = [3799,3800]
===
match
---
name: decode [9479,9485]
name: decode [9479,9485]
===
match
---
operator: = [4293,4294]
operator: = [4293,4294]
===
match
---
trailer [4518,4520]
trailer [4518,4520]
===
match
---
simple_stmt [3493,3534]
simple_stmt [3493,3534]
===
match
---
name: get_connection_from_secrets [13174,13201]
name: get_connection_from_secrets [13135,13162]
===
match
---
name: Dict [868,872]
name: Dict [868,872]
===
match
---
operator: , [1690,1691]
operator: , [1690,1691]
===
match
---
trailer [9449,9478]
trailer [9449,9478]
===
match
---
expr_stmt [9708,9768]
expr_stmt [9708,9768]
===
match
---
trailer [7397,7404]
trailer [7397,7404]
===
match
---
trailer [6942,6951]
trailer [6942,6951]
===
match
---
comparison [2125,2140]
comparison [2125,2140]
===
match
---
string: "@" [2047,2050]
string: "@" [2047,2050]
===
match
---
name: conn_id [13207,13214]
name: conn_id [13168,13175]
===
match
---
name: host [12575,12579]
name: host [12575,12579]
===
match
---
trailer [6561,6567]
trailer [6561,6567]
===
match
---
argument [3571,3582]
argument [3571,3582]
===
match
---
suite [11248,11277]
suite [11248,11277]
===
match
---
name: self [8438,8442]
name: self [8438,8442]
===
match
---
string: '_password' [8898,8909]
string: '_password' [8898,8909]
===
match
---
name: str [4131,4134]
name: str [4131,4134]
===
match
---
decorator [13153,13166]
decorator [13114,13127]
===
match
---
for_stmt [13372,13536]
for_stmt [13333,13497]
===
match
---
trailer [10533,10540]
trailer [10533,10540]
===
match
---
funcdef [7838,8416]
funcdef [7838,8416]
===
match
---
trailer [10728,10732]
trailer [10728,10732]
===
match
---
name: schema [11874,11880]
name: schema [11874,11880]
===
match
---
name: hook_class_name [10958,10973]
name: hook_class_name [10958,10973]
===
match
---
name: warn [11471,11475]
name: warn [11471,11475]
===
match
---
trailer [4473,4478]
trailer [4473,4478]
===
match
---
string: 'utf-8' [10548,10555]
string: 'utf-8' [10548,10555]
===
match
---
expr_stmt [13432,13486]
expr_stmt [13393,13447]
===
match
---
name: lower [6702,6707]
name: lower [6702,6707]
===
match
---
name: uri_parts [2019,2028]
name: uri_parts [2019,2028]
===
match
---
operator: = [6758,6759]
operator: = [6758,6759]
===
match
---
name: login [3757,3762]
name: login [3757,3762]
===
match
---
name: is_encrypted [8672,8684]
name: is_encrypted [8672,8684]
===
match
---
param [8438,8443]
param [8438,8443]
===
match
---
trailer [9332,9339]
trailer [9332,9339]
===
match
---
trailer [10557,10564]
trailer [10557,10564]
===
match
---
name: self [5639,5643]
name: self [5639,5643]
===
match
---
name: self [11983,11987]
name: self [11983,11987]
===
match
---
trailer [9485,9487]
trailer [9485,9487]
===
match
---
import_from [1071,1105]
import_from [1071,1105]
===
match
---
name: AirflowException [9193,9209]
name: AirflowException [9193,9209]
===
match
---
atom_expr [7255,7264]
atom_expr [7255,7264]
===
match
---
operator: = [9681,9682]
operator: = [9681,9682]
===
match
---
raise_stmt [4761,5025]
raise_stmt [4761,5025]
===
match
---
trailer [8652,8654]
trailer [8652,8654]
===
match
---
suite [10918,10975]
suite [10918,10975]
===
match
---
name: declared_attr [9923,9936]
name: declared_attr [9923,9936]
===
match
---
simple_stmt [8591,8655]
simple_stmt [8591,8655]
===
match
---
name: is_encrypted [3867,3879]
name: is_encrypted [3867,3879]
===
match
---
atom_expr [8667,8684]
atom_expr [8667,8684]
===
match
---
string: ':' [6926,6929]
string: ':' [6926,6929]
===
match
---
name: conn_id [11802,11809]
name: conn_id [11802,11809]
===
match
---
param [13207,13219]
param [13168,13180]
===
match
---
operator: -> [8993,8995]
operator: -> [8993,8995]
===
match
---
trailer [12683,12692]
trailer [12683,12692]
===
match
---
trailer [7782,7812]
trailer [7782,7812]
===
match
---
arglist [3623,3650]
arglist [3623,3650]
===
match
---
name: self [7855,7859]
name: self [7855,7859]
===
match
---
name: conn_id [12549,12556]
name: conn_id [12549,12556]
===
match
---
trailer [5246,5253]
trailer [5246,5253]
===
match
---
trailer [1597,1647]
trailer [1597,1647]
===
match
---
operator: } [6727,6728]
operator: } [6727,6728]
===
match
---
operator: = [9865,9866]
operator: = [9865,9866]
===
match
---
trailer [5178,5184]
trailer [5178,5184]
===
match
---
expr_stmt [3693,3719]
expr_stmt [3693,3719]
===
match
---
atom_expr [7146,7155]
atom_expr [7146,7155]
===
match
---
atom_expr [8327,8357]
atom_expr [8327,8357]
===
match
---
atom_expr [6507,6521]
atom_expr [6507,6521]
===
match
---
operator: , [10760,10761]
operator: , [10760,10761]
===
match
---
trailer [3746,3751]
trailer [3746,3751]
===
match
---
operator: = [3614,3615]
operator: = [3614,3615]
===
match
---
if_stmt [9053,9533]
if_stmt [9053,9533]
===
match
---
name: Optional [4279,4287]
name: Optional [4279,4287]
===
match
---
suite [9001,9533]
suite [9001,9533]
===
match
---
trailer [7872,7877]
trailer [7872,7877]
===
match
---
expr_stmt [3931,3996]
expr_stmt [3931,3996]
===
match
---
suite [9840,9917]
suite [9840,9917]
===
match
---
simple_stmt [13057,13128]
simple_stmt [13014,13089]
===
match
---
expr_stmt [6300,6326]
expr_stmt [6300,6326]
===
match
---
name: format [11777,11783]
name: format [11777,11783]
===
match
---
trailer [6872,6881]
trailer [6872,6881]
===
match
---
name: conn_type [5908,5917]
name: conn_type [5908,5917]
===
match
---
operator: = [3880,3881]
operator: = [3880,3881]
===
match
---
trailer [4171,4176]
trailer [4171,4176]
===
match
---
atom_expr [4465,4478]
atom_expr [4465,4478]
===
match
---
name: rotate [10389,10395]
name: rotate [10389,10395]
===
match
---
param [5347,5352]
param [5347,5352]
===
match
---
expr_stmt [8591,8654]
expr_stmt [8591,8654]
===
match
---
name: authority_block [6810,6825]
name: authority_block [6810,6825]
===
match
---
testlist_comp [10763,10785]
testlist_comp [10763,10785]
===
match
---
trailer [6206,6215]
trailer [6206,6215]
===
match
---
name: unquote [6218,6225]
name: unquote [6218,6225]
===
match
---
if_stmt [8015,8293]
if_stmt [8015,8293]
===
match
---
simple_stmt [2008,2036]
simple_stmt [2008,2036]
===
match
---
name: self [11932,11936]
name: self [11932,11936]
===
match
---
atom_expr [3882,3926]
atom_expr [3882,3926]
===
match
---
string: "This method is deprecated. You can read each field individually or " [12236,12305]
string: "This method is deprecated. You can read each field individually or " [12236,12305]
===
match
---
param [1532,1540]
param [1532,1540]
===
match
---
simple_stmt [7008,7031]
simple_stmt [7008,7031]
===
match
---
atom_expr [11209,11221]
atom_expr [11209,11221]
===
match
---
and_test [9056,9095]
and_test [9056,9095]
===
match
---
name: self [5174,5178]
name: self [5174,5178]
===
match
---
fstring [7383,7416]
fstring [7383,7416]
===
match
---
name: hostname [2154,2162]
name: hostname [2154,2162]
===
match
---
name: Column [4010,4016]
name: Column [4010,4016]
===
match
---
arglist [11489,11674]
arglist [11489,11674]
===
match
---
param [12042,12046]
param [12042,12046]
===
match
---
atom_expr [13395,13418]
atom_expr [13356,13379]
===
match
---
suite [10201,10567]
suite [10201,10567]
===
match
---
operator: = [1940,1941]
operator: = [1940,1941]
===
match
---
trailer [11470,11475]
trailer [11470,11475]
===
match
---
name: conn_id [4113,4120]
name: conn_id [4113,4120]
===
match
---
name: self [10396,10400]
name: self [10396,10400]
===
match
---
trailer [8209,8216]
trailer [8209,8216]
===
match
---
name: conn_id_param [11194,11207]
name: conn_id_param [11194,11207]
===
match
---
atom_expr [5174,5184]
atom_expr [5174,5184]
===
match
---
name: conn_id [11214,11221]
name: conn_id [11214,11221]
===
match
---
atom_expr [10448,10459]
atom_expr [10448,10459]
===
match
---
atom_expr [6570,6587]
atom_expr [6570,6587]
===
match
---
atom_expr [8591,8605]
atom_expr [8591,8605]
===
match
---
name: parse [895,900]
name: parse [895,900]
===
match
---
atom_expr [3707,3718]
atom_expr [3707,3718]
===
match
---
name: Column [3952,3958]
name: Column [3952,3958]
===
match
---
operator: , [8347,8348]
operator: , [8347,8348]
===
match
---
atom_expr [1942,1975]
atom_expr [1942,1975]
===
match
---
name: self [12781,12785]
name: self [12781,12785]
===
match
---
trailer [13574,13616]
trailer [13535,13577]
===
match
---
atom_expr [9450,9477]
atom_expr [9450,9477]
===
match
---
name: is_encrypted [8694,8706]
name: is_encrypted [8694,8706]
===
match
---
atom_expr [6501,6522]
atom_expr [6501,6522]
===
match
---
suite [9501,9533]
suite [9501,9533]
===
match
---
name: self [6507,6511]
name: self [6507,6511]
===
match
---
atom_expr [11869,11880]
atom_expr [11869,11880]
===
match
---
trailer [6258,6267]
trailer [6258,6267]
===
match
---
operator: , [12394,12395]
operator: , [12394,12395]
===
match
---
atom_expr [6300,6309]
atom_expr [6300,6309]
===
match
---
suite [13419,13536]
suite [13380,13497]
===
match
---
name: unquote [6120,6127]
name: unquote [6120,6127]
===
match
---
test [11918,11955]
test [11918,11955]
===
match
---
fstring_expr [7254,7265]
fstring_expr [7254,7265]
===
match
---
atom_expr [6249,6267]
atom_expr [6249,6267]
===
match
---
name: TypeError [7557,7566]
name: TypeError [7557,7566]
===
match
---
name: get [10729,10732]
name: get [10729,10732]
===
match
---
parameters [10584,10590]
parameters [10584,10590]
===
match
---
trailer [4401,4406]
trailer [4401,4406]
===
match
---
atom_expr [9456,9467]
atom_expr [9456,9467]
===
match
---
name: urlencode [7509,7518]
name: urlencode [7509,7518]
===
match
---
operator: , [10115,10116]
operator: , [10115,10116]
===
match
---
atom_expr [10887,10901]
atom_expr [10887,10901]
===
match
---
parameters [12041,12047]
parameters [12041,12047]
===
match
---
trailer [6030,6037]
trailer [6030,6037]
===
match
---
name: JSONDecodeError [833,848]
name: JSONDecodeError [833,848]
===
match
---
name: uri [7044,7047]
name: uri [7044,7047]
===
match
---
name: value [9743,9748]
name: value [9743,9748]
===
match
---
name: is_extra_encrypted [3931,3949]
name: is_extra_encrypted [3931,3949]
===
match
---
operator: -> [7861,7863]
operator: -> [7861,7863]
===
match
---
string: "This method is deprecated." [1598,1626]
string: "This method is deprecated." [1598,1626]
===
match
---
funcdef [12764,13148]
funcdef [12764,13109]
===
match
---
name: EXTRA_KEY [7789,7798]
name: EXTRA_KEY [7789,7798]
===
match
---
if_stmt [6971,7067]
if_stmt [6971,7067]
===
match
---
argument [1685,1690]
argument [1685,1690]
===
match
---
name: self [10365,10369]
name: self [10365,10369]
===
match
---
param [4349,4378]
param [4349,4378]
===
match
---
simple_stmt [9853,9873]
simple_stmt [9853,9873]
===
match
---
trailer [8216,8274]
trailer [8216,8274]
===
match
---
if_stmt [6771,6856]
if_stmt [6771,6856]
===
match
---
expr_stmt [5174,5192]
expr_stmt [5174,5192]
===
match
---
argument [3636,3650]
argument [3636,3650]
===
match
---
fstring_start: f" [7383,7385]
fstring_start: f" [7383,7385]
===
match
---
name: self [6202,6206]
name: self [6202,6206]
===
match
---
operator: { [6681,6682]
operator: { [6681,6682]
===
match
---
operator: , [7404,7405]
operator: , [7404,7405]
===
match
---
string: "You can't mix these two ways to create this object." [4958,5011]
string: "You can't mix these two ways to create this object." [4958,5011]
===
match
---
name: conn_type [5123,5132]
name: conn_type [5123,5132]
===
match
---
name: conn_id [11269,11276]
name: conn_id [11269,11276]
===
match
---
argument [3982,3995]
argument [3982,3995]
===
match
---
number: 1 [2108,2109]
number: 1 [2108,2109]
===
match
---
name: ID_LEN [3562,3568]
name: ID_LEN [3562,3568]
===
match
---
name: safe [7406,7410]
name: safe [7406,7410]
===
match
---
trailer [10957,10974]
trailer [10957,10974]
===
match
---
fstring_string: @: [7317,7319]
fstring_string: @: [7317,7319]
===
match
---
name: self [8591,8595]
name: self [8591,8595]
===
match
---
suite [13237,13617]
suite [13198,13578]
===
match
---
operator: = [5285,5286]
operator: = [5285,5286]
===
match
---
return_stmt [7822,7832]
return_stmt [7822,7832]
===
match
---
simple_stmt [9187,9416]
simple_stmt [9187,9416]
===
match
---
trailer [12943,12949]
trailer [12943,12949]
===
match
---
name: self [9056,9060]
name: self [9056,9060]
===
match
---
arglist [3505,3532]
arglist [3505,3532]
===
match
---
operator: = [3950,3951]
operator: = [3950,3951]
===
match
---
if_stmt [12885,13128]
if_stmt [12885,13089]
===
match
---
trailer [6379,6431]
trailer [6379,6431]
===
match
---
operator: = [6677,6678]
operator: = [6677,6678]
===
match
---
return_stmt [13137,13147]
return_stmt [13098,13108]
===
match
---
name: quote [6829,6834]
name: quote [6829,6834]
===
match
---
suite [13002,13128]
suite [12997,13089]
===
match
---
operator: , [1275,1276]
operator: , [1275,1276]
===
match
---
import_from [816,848]
import_from [816,848]
===
match
---
fstring_end: " [13614,13615]
fstring_end: " [13575,13576]
===
match
---
trailer [5149,5154]
trailer [5149,5154]
===
match
---
name: host_block [7204,7214]
name: host_block [7204,7214]
===
match
---
simple_stmt [10282,10304]
simple_stmt [10282,10304]
===
match
---
atom_expr [6686,6700]
atom_expr [6686,6700]
===
match
---
operator: = [3577,3578]
operator: = [3577,3578]
===
match
---
operator: = [7410,7411]
operator: = [7410,7411]
===
match
---
simple_stmt [2199,2228]
simple_stmt [2199,2228]
===
match
---
suite [7113,7166]
suite [7113,7166]
===
match
---
operator: , [944,945]
operator: , [944,945]
===
match
---
name: self [9853,9857]
name: self [9853,9857]
===
match
---
parameters [8743,8748]
parameters [8743,8748]
===
match
---
operator: , [4226,4227]
operator: , [4226,4227]
===
match
---
operator: , [2106,2107]
operator: , [2106,2107]
===
match
---
operator: += [7048,7050]
operator: += [7048,7050]
===
match
---
name: self [7931,7935]
name: self [7931,7935]
===
match
---
atom_expr [11823,11832]
atom_expr [11823,11832]
===
match
---
trailer [10505,10512]
trailer [10505,10512]
===
match
---
atom_expr [5145,5154]
atom_expr [5145,5154]
===
match
---
string: "XXXXXXXX" [11918,11928]
string: "XXXXXXXX" [11918,11928]
===
match
---
atom_expr [4529,4541]
atom_expr [4529,4541]
===
match
---
name: uri_parts [1950,1959]
name: uri_parts [1950,1959]
===
match
---
trailer [4365,4370]
trailer [4365,4370]
===
match
---
name: conn_id [13470,13477]
name: conn_id [13431,13438]
===
match
---
atom_expr [5054,5079]
atom_expr [5054,5079]
===
match
---
name: extra_dejson [12721,12733]
name: extra_dejson [12721,12733]
===
match
---
name: parse_from_uri [5332,5346]
name: parse_from_uri [5332,5346]
===
match
---
name: self [12888,12892]
name: self [12888,12892]
===
match
---
name: description [4579,4590]
name: description [4579,4590]
===
match
---
expr_stmt [7501,7537]
expr_stmt [7501,7537]
===
match
---
atom_expr [5205,5218]
atom_expr [5205,5218]
===
match
---
name: DeprecationWarning [11629,11647]
name: DeprecationWarning [11629,11647]
===
match
---
simple_stmt [13432,13487]
simple_stmt [13393,13448]
===
match
---
atom_expr [2019,2035]
atom_expr [2019,2035]
===
match
---
expr_stmt [9853,9872]
expr_stmt [9853,9872]
===
match
---
simple_stmt [11173,11224]
simple_stmt [11173,11224]
===
match
---
atom_expr [3677,3687]
atom_expr [3677,3687]
===
match
---
trailer [9209,9415]
trailer [9209,9415]
===
match
---
simple_stmt [9010,9045]
simple_stmt [9010,9045]
===
match
---
param [4099,4104]
param [4099,4104]
===
match
---
param [6605,6609]
param [6605,6609]
===
match
---
operator: += [7312,7314]
operator: += [7312,7314]
===
match
---
name: Optional [8451,8459]
name: Optional [8451,8459]
===
match
---
name: password [6259,6267]
name: password [6259,6267]
===
match
---
trailer [12574,12579]
trailer [12574,12579]
===
match
---
name: conn_type [5698,5707]
name: conn_type [5698,5707]
===
match
---
suite [11002,11165]
suite [11002,11165]
===
match
---
operator: = [13437,13438]
operator: = [13398,13399]
===
match
---
name: schema [3724,3730]
name: schema [3724,3730]
===
match
---
name: AirflowException [1194,1210]
name: AirflowException [1194,1210]
===
match
---
name: self [8667,8671]
name: self [8667,8671]
===
match
---
suite [7878,8416]
suite [7878,8416]
===
match
---
trailer [6389,6430]
trailer [6389,6430]
===
match
---
operator: = [5997,5998]
operator: = [5997,5998]
===
match
---
name: json [821,825]
name: json [821,825]
===
match
---
operator: = [7682,7683]
operator: = [7682,7683]
===
match
---
tfpdef [4236,4255]
tfpdef [4236,4255]
===
match
---
name: urlencode [935,944]
name: urlencode [935,944]
===
match
---
operator: , [12010,12011]
operator: , [12010,12011]
===
match
---
trailer [6282,6291]
trailer [6282,6291]
===
match
---
name: self [5242,5246]
name: self [5242,5246]
===
match
---
name: primary_key [3516,3527]
name: primary_key [3516,3527]
===
match
---
trailer [8358,8365]
trailer [8358,8365]
===
match
---
fstring_expr [7319,7330]
fstring_expr [7319,7330]
===
match
---
if_stmt [2122,2191]
if_stmt [2122,2191]
===
match
---
trailer [2217,2227]
trailer [2217,2227]
===
match
---
name: password [6943,6951]
name: password [6943,6951]
===
match
---
simple_stmt [1282,1327]
simple_stmt [1282,1327]
===
match
---
simple_stmt [1327,1382]
simple_stmt [1327,1382]
===
match
---
trailer [9813,9826]
trailer [9813,9826]
===
match
---
return_stmt [1652,1701]
return_stmt [1652,1701]
===
match
---
atom_expr [7773,7812]
atom_expr [7773,7812]
===
match
---
trailer [3778,3783]
trailer [3778,3783]
===
match
---
name: typing [854,860]
name: typing [854,860]
===
match
---
simple_stmt [5983,6018]
simple_stmt [5983,6018]
===
match
---
atom_expr [6202,6215]
atom_expr [6202,6215]
===
match
---
suite [2063,2114]
suite [2063,2114]
===
match
---
name: LoggingMixin [1426,1438]
name: LoggingMixin [1426,1438]
===
match
---
trailer [10750,10760]
trailer [10750,10760]
===
match
---
operator: = [10702,10703]
operator: = [10702,10703]
===
match
---
import_from [1327,1381]
import_from [1327,1381]
===
match
---
name: Column [3733,3739]
name: Column [3733,3739]
===
match
---
trailer [2102,2110]
trailer [2102,2110]
===
match
---
expr_stmt [7981,8002]
expr_stmt [7981,8002]
===
match
---
trailer [6701,6707]
trailer [6701,6707]
===
match
---
simple_stmt [1107,1163]
simple_stmt [1107,1163]
===
match
---
parameters [8986,8992]
parameters [8986,8992]
===
match
---
simple_stmt [3693,3720]
simple_stmt [3693,3720]
===
match
---
name: port [7183,7187]
name: port [7183,7187]
===
match
---
name: _password [10320,10329]
name: _password [10320,10329]
===
match
---
trailer [7324,7329]
trailer [7324,7329]
===
match
---
name: self [9885,9889]
name: self [9885,9889]
===
match
---
operator: = [2163,2164]
operator: = [2163,2164]
===
match
---
atom_expr [5710,5726]
atom_expr [5710,5726]
===
match
---
param [9558,9568]
param [9558,9568]
===
match
---
name: Column [3498,3504]
name: Column [3498,3504]
===
match
---
trailer [10395,10427]
trailer [10395,10427]
===
match
---
name: schema [4349,4355]
name: schema [4349,4355]
===
match
---
suite [9170,9416]
suite [9170,9416]
===
match
---
param [4152,4184]
param [4152,4184]
===
match
---
operator: , [4299,4300]
operator: , [4299,4300]
===
match
---
operator: , [924,925]
operator: , [924,925]
===
match
---
trailer [6492,6498]
trailer [6492,6498]
===
match
---
name: get_hook [10576,10584]
name: get_hook [10576,10584]
===
match
---
trailer [11987,12000]
trailer [11987,12000]
===
match
---
string: '' [6958,6960]
string: '' [6958,6960]
===
match
---
trailer [9785,9804]
trailer [9785,9804]
===
match
---
and_test [4602,4747]
and_test [4602,4747]
===
match
---
name: secrets_backend [13376,13391]
name: secrets_backend [13337,13352]
===
match
---
operator: } [10901,10902]
operator: } [10901,10902]
===
match
---
operator: ** [1532,1534]
operator: ** [1532,1534]
===
match
---
name: self [6300,6304]
name: self [6300,6304]
===
match
---
trailer [8952,8965]
trailer [8952,8965]
===
match
---
atom_expr [4242,4255]
atom_expr [4242,4255]
===
match
---
string: """Returns the extra property by deserializing json.""" [12804,12859]
string: """Returns the extra property by deserializing json.""" [12804,12859]
===
match
---
suite [7690,7726]
suite [7690,7726]
===
match
---
name: _parse_netloc_to_hostname [1659,1684]
name: _parse_netloc_to_hostname [1659,1684]
===
match
---
name: conn_type [4152,4161]
name: conn_type [4152,4161]
===
match
---
trailer [8595,8605]
trailer [8595,8605]
===
match
---
operator: , [9467,9468]
operator: , [9467,9468]
===
match
---
name: sqlalchemy [1023,1033]
name: sqlalchemy [1023,1033]
===
match
---
trailer [9766,9768]
trailer [9766,9768]
===
match
---
name: rotate_fernet_key [10177,10194]
name: rotate_fernet_key [10177,10194]
===
match
---
expr_stmt [6026,6098]
expr_stmt [6026,6098]
===
match
---
name: cls [13202,13205]
name: cls [13163,13166]
===
match
---
name: hostname [2239,2247]
name: hostname [2239,2247]
===
match
---
name: host [4685,4689]
name: host [4685,4689]
===
match
---
simple_stmt [7237,7267]
simple_stmt [7237,7267]
===
match
---
atom_expr [9118,9130]
atom_expr [9118,9130]
===
match
---
operator: @ [12750,12751]
operator: @ [12750,12751]
===
match
---
test [6040,6098]
test [6040,6098]
===
match
---
trailer [5279,5284]
trailer [5279,5284]
===
match
---
operator: , [9748,9749]
operator: , [9748,9749]
===
match
---
param [4423,4451]
param [4423,4451]
===
match
---
name: login [5179,5184]
name: login [5179,5184]
===
match
---
operator: = [11671,11672]
operator: = [11671,11672]
===
match
---
operator: , [3582,3583]
operator: , [3582,3583]
===
match
---
trailer [7804,7810]
trailer [7804,7810]
===
match
---
tfpdef [4423,4443]
tfpdef [4423,4443]
===
match
---
operator: == [7640,7642]
operator: == [7640,7642]
===
match
---
operator: = [13477,13478]
operator: = [13438,13439]
===
match
---
operator: { [7386,7387]
operator: { [7386,7387]
===
match
---
simple_stmt [4560,4591]
simple_stmt [4560,4591]
===
match
---
string: '_extra' [10107,10115]
string: '_extra' [10107,10115]
===
match
---
name: host_block [7369,7379]
name: host_block [7369,7379]
===
match
---
parameters [12780,12786]
parameters [12780,12786]
===
match
---
dotted_name [1168,1186]
dotted_name [1168,1186]
===
match
---
trailer [10434,10436]
trailer [10434,10436]
===
match
---
trailer [6834,6855]
trailer [6834,6855]
===
match
---
name: self [10887,10891]
name: self [10887,10891]
===
match
---
atom [10762,10786]
atom [10762,10786]
===
match
---
atom_expr [7784,7798]
atom_expr [7784,7798]
===
match
---
number: 2 [12419,12420]
number: 2 [12419,12420]
===
match
---
expr_stmt [5275,5291]
expr_stmt [5275,5291]
===
match
---
arglist [8333,8356]
arglist [8333,8356]
===
match
---
funcdef [8421,8707]
funcdef [8421,8707]
===
match
---
atom_expr [7950,7967]
atom_expr [7950,7967]
===
match
---
string: '' [7217,7219]
string: '' [7217,7219]
===
match
---
operator: , [4377,4378]
operator: , [4377,4378]
===
match
---
name: extra [12893,12898]
name: extra [12893,12898]
===
match
---
simple_stmt [13137,13148]
simple_stmt [13098,13109]
===
match
---
funcdef [4039,5323]
funcdef [4039,5323]
===
match
---
trailer [12523,12530]
trailer [12523,12530]
===
match
---
name: airflow [1112,1119]
name: airflow [1112,1119]
===
match
---
name: self [11894,11898]
name: self [11894,11898]
===
match
---
name: uri [7829,7832]
name: uri [7829,7832]
===
match
---
name: error [13066,13071]
name: exception [13023,13032]
===
match
---
return_stmt [8394,8415]
return_stmt [8394,8415]
===
match
---
return_stmt [11257,11276]
return_stmt [11257,11276]
===
match
---
atom_expr [3952,3996]
atom_expr [3952,3996]
===
match
---
name: hostname [2008,2016]
name: hostname [2008,2016]
===
match
---
name: __init__ [4043,4051]
name: __init__ [4043,4051]
===
match
---
name: fernet [10282,10288]
name: fernet [10282,10288]
===
match
---
operator: , [12651,12652]
operator: , [12651,12652]
===
match
---
name: self [7344,7348]
name: self [7344,7348]
===
match
---
fstring_string: / [7385,7386]
fstring_string: / [7385,7386]
===
match
---
argument [3516,3532]
argument [3516,3532]
===
match
---
operator: += [7380,7382]
operator: += [7380,7382]
===
match
---
suite [12795,13148]
suite [12795,13109]
===
match
---
name: login [5187,5192]
name: login [5187,5192]
===
match
---
atom_expr [6932,6961]
atom_expr [6932,6961]
===
match
---
atom_expr [4430,4443]
atom_expr [4430,4443]
===
match
---
operator: = [4542,4543]
operator: = [4542,4543]
===
match
---
or_test [4672,4737]
or_test [4672,4737]
===
match
---
atom_expr [5855,5882]
atom_expr [5855,5882]
===
match
---
name: self [11209,11213]
name: self [11209,11213]
===
match
---
simple_stmt [3789,3834]
simple_stmt [3789,3834]
===
match
---
name: self [10464,10468]
name: self [10464,10468]
===
match
---
import_from [1382,1438]
import_from [1382,1438]
===
match
---
atom_expr [4026,4032]
atom_expr [4026,4032]
===
match
---
trailer [9742,9758]
trailer [9742,9758]
===
match
---
name: fernet [9722,9728]
name: fernet [9722,9728]
===
match
---
name: nullable [3584,3592]
name: nullable [3584,3592]
===
match
---
name: json [12939,12943]
name: json [12939,12943]
===
match
---
name: hostname [2054,2062]
name: hostname [2054,2062]
===
match
---
atom_expr [10515,10566]
atom_expr [10515,10566]
===
match
---
parameters [8437,8465]
parameters [8437,8465]
===
match
---
atom_expr [8687,8706]
atom_expr [8687,8706]
===
match
---
name: obj [13144,13147]
name: obj [13105,13108]
===
match
---
trailer [8337,8347]
trailer [8337,8347]
===
match
---
atom_expr [2087,2113]
atom_expr [2087,2113]
===
match
---
arglist [6938,6960]
arglist [6938,6960]
===
match
---
name: decode [10428,10434]
name: decode [10428,10434]
===
match
---
tfpdef [4460,4478]
tfpdef [4460,4478]
===
match
---
name: declarative [1038,1049]
name: declarative [1038,1049]
===
match
---
argument [7406,7413]
argument [7406,7413]
===
match
---
operator: @ [9922,9923]
operator: @ [9922,9923]
===
match
---
arith_expr [7714,7725]
arith_expr [7714,7725]
===
match
---
operator: = [4333,4334]
operator: = [4333,4334]
===
match
---
name: airflow [1168,1175]
name: airflow [1168,1175]
===
match
---
name: orm [1087,1090]
name: orm [1087,1090]
===
match
---
expr_stmt [7237,7266]
expr_stmt [7237,7266]
===
match
---
operator: = [7988,7989]
operator: = [7988,7989]
===
match
---
import_from [1237,1281]
import_from [1237,1281]
===
match
---
name: self [5347,5351]
name: self [5347,5351]
===
match
---
name: warnings [12209,12217]
name: warnings [12209,12217]
===
match
---
simple_stmt [10600,10638]
simple_stmt [10600,10638]
===
match
---
if_stmt [1980,2228]
if_stmt [1980,2228]
===
match
---
fstring_start: f' [7251,7253]
fstring_start: f' [7251,7253]
===
match
---
name: str [4288,4291]
name: str [4288,4291]
===
match
---
trailer [13061,13065]
trailer [13018,13022]
===
match
---
atom_expr [9521,9532]
atom_expr [9521,9532]
===
match
---
fstring_end: " [6731,6732]
fstring_end: " [6731,6732]
===
match
---
atom_expr [9708,9719]
atom_expr [9708,9719]
===
match
---
param [4236,4263]
param [4236,4263]
===
match
---
name: self [7255,7259]
name: self [7255,7259]
===
match
---
operator: , [10676,10677]
operator: , [10676,10677]
===
match
---
name: uri_parts [5710,5719]
name: uri_parts [5710,5719]
===
match
---
simple_stmt [3867,3927]
simple_stmt [3867,3927]
===
match
---
expr_stmt [9885,9916]
expr_stmt [9885,9916]
===
match
---
operator: = [8606,8607]
operator: = [8606,8607]
===
match
---
name: fernet [7981,7987]
name: fernet [7981,7987]
===
match
---
if_stmt [4599,5026]
if_stmt [4599,5026]
===
match
---
trailer [8459,8464]
trailer [8459,8464]
===
match
---
name: self [10585,10589]
name: self [10585,10589]
===
match
---
if_stmt [7928,8416]
if_stmt [7928,8416]
===
match
---
atom_expr [6938,6951]
atom_expr [6938,6951]
===
match
---
name: uri [7426,7429]
name: uri [7426,7429]
===
match
---
trailer [6717,6727]
trailer [6717,6727]
===
match
---
suite [7284,7332]
suite [7284,7332]
===
match
---
string: "Failed parsing the json for conn_id %s" [13072,13112]
string: "Failed parsing the json for conn_id %s" [13033,13073]
===
match
---
atom_expr [5926,5935]
atom_expr [5926,5935]
===
match
---
atom_expr [12447,12744]
atom_expr [12447,12744]
===
match
---
operator: @ [13153,13154]
operator: @ [13114,13115]
===
match
---
name: dict [6375,6379]
name: dict [6375,6379]
===
match
---
name: safe [6953,6957]
name: safe [6953,6957]
===
match
---
name: value [8538,8543]
name: value [8538,8543]
===
match
---
simple_stmt [1237,1282]
simple_stmt [1237,1282]
===
match
---
simple_stmt [1877,1927]
simple_stmt [1877,1927]
===
match
---
simple_stmt [12868,12877]
simple_stmt [12868,12877]
===
match
---
name: package_name [11120,11132]
name: package_name [11120,11132]
===
match
---
if_stmt [7175,7332]
if_stmt [7175,7332]
===
match
---
name: uri [4602,4605]
name: uri [4602,4605]
===
match
---
name: self [7519,7523]
name: self [7519,7523]
===
match
---
atom_expr [6151,6169]
atom_expr [6151,6169]
===
match
---
name: self [13057,13061]
name: self [13014,13018]
===
match
---
name: host [5157,5161]
name: host [5157,5161]
===
match
---
simple_stmt [12057,12201]
simple_stmt [12057,12201]
===
match
---
trailer [4016,4033]
trailer [4016,4033]
===
match
---
trailer [11028,11146]
trailer [11028,11146]
===
match
---
suite [1542,1702]
suite [1542,1702]
===
match
---
name: dict [7643,7647]
name: dict [7643,7647]
===
match
---
name: cls [10137,10140]
name: cls [10137,10140]
===
match
---
trailer [5308,5314]
trailer [5308,5314]
===
match
---
trailer [9060,9067]
trailer [9060,9067]
===
match
---
name: conn_type [5896,5905]
name: conn_type [5896,5905]
===
match
---
name: _extra [9461,9467]
name: _extra [9461,9467]
===
match
---
trailer [3676,3688]
trailer [3676,3688]
===
match
---
name: decrypt [8319,8326]
name: decrypt [8319,8326]
===
match
---
operator: , [994,995]
operator: , [994,995]
===
match
---
trailer [8246,8252]
trailer [8246,8252]
===
match
---
name: conn_type [5820,5829]
name: conn_type [5820,5829]
===
match
---
name: set_password [8953,8965]
name: set_password [8953,8965]
===
match
---
name: quoted_schema [6048,6061]
name: quoted_schema [6048,6061]
===
match
---
string: "XXXXXXXX" [12665,12675]
string: "XXXXXXXX" [12665,12675]
===
match
---
name: port [4724,4728]
name: port [4724,4728]
===
match
---
name: unique [3968,3974]
name: unique [3968,3974]
===
match
---
parameters [5638,5654]
parameters [5638,5654]
===
match
---
simple_stmt [6202,6292]
simple_stmt [6202,6292]
===
match
---
operator: = [6310,6311]
operator: = [6310,6311]
===
match
---
name: airflow [1287,1294]
name: airflow [1287,1294]
===
match
---
name: DeprecationWarning [1628,1646]
name: DeprecationWarning [1628,1646]
===
match
---
trailer [4327,4332]
trailer [4327,4332]
===
match
---
name: conn_type [4672,4681]
name: conn_type [4672,4681]
===
match
---
suite [12916,12962]
suite [12916,12962]
===
match
---
atom_expr [3740,3751]
atom_expr [3740,3751]
===
match
---
simple_stmt [1547,1580]
simple_stmt [1547,1580]
===
match
---
operator: = [7087,7088]
operator: = [7087,7088]
===
match
---
operator: } [12875,12876]
operator: } [12875,12876]
===
match
---
name: is_encrypted [9814,9826]
name: is_encrypted [9814,9826]
===
match
---
simple_stmt [9428,9488]
simple_stmt [9428,9488]
===
match
---
trailer [3629,3634]
trailer [3629,3634]
===
match
---
simple_stmt [2076,2114]
simple_stmt [2076,2114]
===
match
---
name: kwargs [1694,1700]
name: kwargs [1694,1700]
===
match
---
operator: , [3634,3635]
operator: , [3634,3635]
===
match
---
name: conn [13531,13535]
name: conn [13492,13496]
===
match
---
name: host [5150,5154]
name: host [5150,5154]
===
match
---
name: username [6161,6169]
name: username [6161,6169]
===
match
---
operator: , [1011,1012]
operator: , [1011,1012]
===
match
---
trailer [1949,1975]
trailer [1949,1975]
===
match
---
trailer [11213,11221]
trailer [11213,11221]
===
match
---
trailer [10564,10566]
trailer [10564,10566]
===
match
---
operator: = [9909,9910]
operator: = [9909,9910]
===
match
---
name: Optional [4357,4365]
name: Optional [4357,4365]
===
match
---
atom_expr [12544,12556]
atom_expr [12544,12556]
===
match
---
param [5639,5644]
param [5639,5644]
===
match
---
name: hostname [2076,2084]
name: hostname [2076,2084]
===
match
---
trailer [4507,4509]
trailer [4507,4509]
===
match
---
name: schema [7349,7355]
name: schema [7349,7355]
===
match
---
trailer [13469,13486]
trailer [13430,13447]
===
match
---
atom_expr [10396,10426]
atom_expr [10396,10426]
===
match
---
if_stmt [10806,10906]
if_stmt [10806,10906]
===
match
---
trailer [4214,4219]
trailer [4214,4219]
===
match
---
atom_expr [7387,7414]
atom_expr [7387,7414]
===
match
---
trailer [8671,8684]
trailer [8671,8684]
===
match
---
atom_expr [6682,6727]
atom_expr [6682,6727]
===
match
---
trailer [8576,8578]
trailer [8576,8578]
===
match
---
name: value [9867,9872]
name: value [9867,9872]
===
match
---
arglist [10746,10786]
arglist [10746,10786]
===
match
---
name: get_uri [6597,6604]
name: get_uri [6597,6604]
===
match
---
try_stmt [12912,13128]
try_stmt [12912,13089]
===
match
---
name: conn_type [5843,5852]
name: conn_type [5843,5852]
===
match
---
simple_stmt [6107,6194]
simple_stmt [6107,6194]
===
match
---
and_test [7612,7689]
and_test [7612,7689]
===
match
---
simple_stmt [6367,6432]
simple_stmt [6367,6432]
===
match
---
name: self [7103,7107]
name: self [7103,7107]
===
match
---
name: str [9565,9568]
name: str [9565,9568]
===
match
---
atom_expr [3548,3599]
atom_expr [3548,3599]
===
match
---
simple_stmt [4502,4521]
simple_stmt [4502,4521]
===
match
---
name: cls [9951,9954]
name: cls [9951,9954]
===
match
---
import_name [800,815]
import_name [800,815]
===
match
---
arglist [7393,7413]
arglist [7393,7413]
===
match
---
name: _parse_netloc_to_hostname [1835,1860]
name: _parse_netloc_to_hostname [1835,1860]
===
match
---
simple_stmt [3838,3863]
simple_stmt [3838,3863]
===
match
---
operator: , [4103,4104]
operator: , [4103,4104]
===
match
---
name: get_password [8935,8947]
name: get_password [8935,8947]
===
match
---
trailer [2187,2190]
trailer [2187,2190]
===
match
---
atom_expr [4122,4135]
atom_expr [4122,4135]
===
match
---
argument [3912,3925]
argument [3912,3925]
===
match
---
name: airflow [1444,1451]
name: airflow [1444,1451]
===
match
---
name: login [12646,12651]
name: login [12646,12651]
===
match
---
name: AirflowNotFoundException [1212,1236]
name: AirflowNotFoundException [1212,1236]
===
match
---
operator: , [4339,4340]
operator: , [4339,4340]
===
match
---
arglist [13072,13126]
arglist [13033,13087]
===
match
---
trailer [6008,6013]
trailer [6008,6013]
===
match
---
trailer [6160,6169]
trailer [6160,6169]
===
match
---
trailer [7626,7639]
trailer [7626,7639]
===
match
---
atom_expr [9853,9864]
atom_expr [9853,9864]
===
match
---
string: '__extra__' [3442,3453]
string: '__extra__' [3442,3453]
===
match
---
suite [11301,12022]
suite [11301,12022]
===
match
---
name: _parse_from_uri [5591,5606]
name: _parse_from_uri [5591,5606]
===
match
---
name: Integer [996,1003]
name: Integer [996,1003]
===
match
---
expr_stmt [5777,5799]
expr_stmt [5777,5799]
===
match
---
trailer [5872,5882]
trailer [5872,5882]
===
match
---
trailer [7657,7688]
trailer [7657,7688]
===
match
---
dotted_name [1444,1472]
dotted_name [1444,1472]
===
match
---
operator: = [5155,5156]
operator: = [5155,5156]
===
match
---
atom_expr [1659,1701]
atom_expr [1659,1701]
===
match
---
tfpdef [13207,13219]
tfpdef [13168,13180]
===
match
---
if_stmt [13499,13536]
if_stmt [13460,13497]
===
match
---
simple_stmt [2154,2191]
simple_stmt [2154,2191]
===
match
---
name: is_extra_encrypted [9786,9804]
name: is_extra_encrypted [9786,9804]
===
match
---
name: bytes [9737,9742]
name: bytes [9737,9742]
===
match
---
return_stmt [2232,2247]
return_stmt [2232,2247]
===
match
---
simple_stmt [11693,12022]
simple_stmt [11693,12022]
===
match
---
tfpdef [4152,4176]
tfpdef [4152,4176]
===
match
---
name: __init__ [4510,4518]
name: __init__ [4510,4518]
===
match
---
trailer [7935,7945]
trailer [7935,7945]
===
match
---
atom_expr [9435,9487]
atom_expr [9435,9487]
===
match
---
name: uri [5609,5612]
name: uri [5609,5612]
===
match
---
simple_stmt [1439,1494]
simple_stmt [1439,1494]
===
match
---
expr_stmt [6367,6431]
expr_stmt [6367,6431]
===
match
---
operator: = [3644,3645]
operator: = [3644,3645]
===
match
---
name: obj [12868,12871]
name: obj [12868,12871]
===
match
---
suite [4748,5026]
suite [4748,5026]
===
match
---
suite [8785,8968]
suite [8785,8968]
===
match
---
atom_expr [4560,4576]
atom_expr [4560,4576]
===
match
---
simple_stmt [5275,5292]
simple_stmt [5275,5292]
===
match
---
operator: , [917,918]
operator: , [917,918]
===
match
---
if_stmt [5735,5883]
if_stmt [5735,5883]
===
match
---
arglist [6835,6854]
arglist [6835,6854]
===
match
---
import_from [1163,1236]
import_from [1163,1236]
===
match
---
operator: , [1210,1211]
operator: , [1210,1211]
===
match
---
dotted_name [888,900]
dotted_name [888,900]
===
match
---
trailer [11475,11684]
trailer [11475,11684]
===
match
---
string: "You must create an object using the URI or individual values " [4801,4864]
string: "You must create an object using the URI or individual values " [4801,4864]
===
match
---
name: conn_id [13119,13126]
name: conn_id [13080,13087]
===
match
---
suite [6618,7833]
suite [6618,7833]
===
match
---
expr_stmt [7426,7443]
expr_stmt [7426,7443]
===
match
---
name: hook_class [10931,10941]
name: hook_class [10931,10941]
===
match
---
expr_stmt [3838,3862]
expr_stmt [3838,3862]
===
match
---
name: get_connection [13455,13469]
name: get_connection [13416,13430]
===
match
---
param [5353,5358]
param [5353,5358]
===
match
---
operator: , [10779,10780]
operator: , [10779,10780]
===
match
---
name: fernet [8608,8614]
name: fernet [8608,8614]
===
match
---
arglist [3555,3598]
arglist [3555,3598]
===
match
---
atom_expr [10137,10150]
atom_expr [10137,10150]
===
match
---
atom_expr [6390,6405]
atom_expr [6390,6405]
===
match
---
operator: , [4142,4143]
operator: , [4142,4143]
===
match
---
operator: += [6923,6925]
operator: += [6923,6925]
===
match
---
parameters [1524,1541]
parameters [1524,1541]
===
match
---
simple_stmt [6627,6665]
simple_stmt [6627,6665]
===
match
---
expr_stmt [7369,7416]
expr_stmt [7369,7416]
===
match
---
name: fernet [8312,8318]
name: fernet [8312,8318]
===
match
---
trailer [11850,11855]
trailer [11850,11855]
===
match
---
name: _extra [10453,10459]
name: _extra [10453,10459]
===
match
---
simple_stmt [5777,5800]
simple_stmt [5777,5800]
===
match
---
operator: , [11118,11119]
operator: , [11118,11119]
===
match
---
simple_stmt [849,883]
simple_stmt [849,883]
===
match
---
name: uri [5075,5078]
name: uri [5075,5078]
===
match
---
suite [6894,6962]
suite [6894,6962]
===
match
---
trailer [6451,6461]
trailer [6451,6461]
===
match
---
fstring_start: f" [13575,13577]
fstring_start: f" [13536,13538]
===
match
---
simple_stmt [10501,10567]
simple_stmt [10501,10567]
===
match
---
atom_expr [12939,12961]
atom_expr [12939,12961]
===
match
---
trailer [6225,6245]
trailer [6225,6245]
===
match
---
comparison [5738,5763]
comparison [5738,5763]
===
match
---
operator: = [4136,4137]
operator: = [4136,4137]
===
match
---
name: self [5304,5308]
name: self [5304,5308]
===
match
---
suite [5764,5800]
suite [5764,5800]
===
match
---
import_as_names [1194,1236]
import_as_names [1194,1236]
===
match
---
name: Column [3882,3888]
name: Column [3882,3888]
===
match
---
name: fernet [9674,9680]
name: fernet [9674,9680]
===
match
---
trailer [7145,7165]
trailer [7145,7165]
===
match
---
expr_stmt [5664,5689]
expr_stmt [5664,5689]
===
match
---
trailer [11776,11783]
trailer [11776,11783]
===
match
---
argument [6847,6854]
argument [6847,6854]
===
match
---
simple_stmt [3604,3652]
simple_stmt [3604,3652]
===
match
---
string: '' [7411,7413]
string: '' [7411,7413]
===
match
---
trailer [3958,3996]
trailer [3958,3996]
===
match
---
name: Optional [4122,4130]
name: Optional [4122,4130]
===
match
---
name: is_encrypted [7955,7967]
name: is_encrypted [7955,7967]
===
match
---
expr_stmt [7301,7331]
expr_stmt [7301,7331]
===
match
---
name: self [9365,9369]
name: self [9365,9369]
===
match
---
atom_expr [12679,12692]
atom_expr [12679,12692]
===
match
---
name: uri [5355,5358]
name: uri [5355,5358]
===
match
---
atom_expr [10315,10329]
atom_expr [10315,10329]
===
match
---
name: conn [13432,13436]
name: conn [13393,13397]
===
match
---
param [13202,13206]
param [13163,13167]
===
match
---
name: self [9781,9785]
name: self [9781,9785]
===
match
---
simple_stmt [7044,7067]
simple_stmt [7044,7067]
===
match
---
atom_expr [5242,5253]
atom_expr [5242,5253]
===
match
---
param [11295,11299]
param [11295,11299]
===
match
---
name: Column [3548,3554]
name: Column [3548,3554]
===
match
---
name: property [10128,10136]
name: property [10128,10136]
===
match
---
expr_stmt [6742,6762]
expr_stmt [6742,6762]
===
match
---
trailer [9712,9719]
trailer [9712,9719]
===
match
---
trailer [3771,3784]
trailer [3771,3784]
===
match
---
string: "This method is deprecated. Please use uri parameter in constructor." [5478,5547]
string: "This method is deprecated. Please use uri parameter in constructor." [5478,5547]
===
match
---
operator: -> [6611,6613]
operator: -> [6611,6613]
===
match
---
atom_expr [4502,4520]
atom_expr [4502,4520]
===
match
---
name: schema [4714,4720]
name: schema [4714,4720]
===
match
---
name: login [9370,9375]
name: login [9370,9375]
===
match
---
tfpdef [4387,4406]
tfpdef [4387,4406]
===
match
---
name: log [1401,1404]
name: log [1401,1404]
===
match
---
simple_stmt [10646,10797]
simple_stmt [10646,10797]
===
match
---
name: ensure_secrets_loaded [1141,1162]
name: ensure_secrets_loaded [1141,1162]
===
match
---
fstring_expr [10886,10902]
fstring_expr [10886,10902]
===
match
---
simple_stmt [7760,7813]
simple_stmt [7760,7813]
===
match
---
try_stmt [10914,11165]
try_stmt [10914,11165]
===
match
---
simple_stmt [5698,5727]
simple_stmt [5698,5727]
===
match
---
name: bytes [9450,9455]
name: bytes [9450,9455]
===
match
---
name: _extra [10506,10512]
name: _extra [10506,10512]
===
match
---
name: conn_id [4544,4551]
name: conn_id [4544,4551]
===
match
---
operator: += [7024,7026]
operator: += [7024,7026]
===
match
---
trailer [6574,6580]
trailer [6574,6580]
===
match
---
name: keep_blank_values [7665,7682]
name: keep_blank_values [7665,7682]
===
match
---
trailer [4250,4255]
trailer [4250,4255]
===
match
---
name: query [7501,7506]
name: query [7501,7506]
===
match
---
argument [6953,6960]
argument [6953,6960]
===
match
---
name: keep_blank_values [6407,6424]
name: keep_blank_values [6407,6424]
===
match
---
name: json [6570,6574]
name: json [6570,6574]
===
match
---
name: get_fernet [10291,10301]
name: get_fernet [10291,10301]
===
match
---
expr_stmt [5205,5229]
expr_stmt [5205,5229]
===
match
---
string: '' [6760,6762]
string: '' [6760,6762]
===
match
---
trailer [8628,8644]
trailer [8628,8644]
===
match
---
trailer [6839,6845]
trailer [6839,6845]
===
match
---
operator: , [3980,3981]
operator: , [3980,3981]
===
match
---
name: self [11846,11850]
name: self [11846,11850]
===
match
---
operator: { [7319,7320]
operator: { [7319,7320]
===
match
---
param [4272,4300]
param [4272,4300]
===
match
---
trailer [7150,7155]
trailer [7150,7155]
===
match
---
expr_stmt [9781,9826]
expr_stmt [9781,9826]
===
match
---
return_stmt [13524,13535]
return_stmt [13485,13496]
===
match
---
name: get_extra [8977,8986]
name: get_extra [8977,8986]
===
match
---
name: uri_parts [6151,6160]
name: uri_parts [6151,6160]
===
match
---
trailer [12954,12960]
trailer [12954,12960]
===
match
---
name: fernet [9807,9813]
name: fernet [9807,9813]
===
match
---
and_test [10448,10487]
and_test [10448,10487]
===
match
---
name: fernet [8687,8693]
name: fernet [8687,8693]
===
match
---
fstring_end: ' [10903,10904]
fstring_end: ' [10903,10904]
===
match
---
name: kwargs [1534,1540]
name: kwargs [1534,1540]
===
match
---
name: cls [8931,8934]
name: cls [8931,8934]
===
match
---
atom_expr [4163,4176]
atom_expr [4163,4176]
===
match
---
name: is_encrypted [9157,9169]
name: is_encrypted [9157,9169]
===
match
---
operator: { [7254,7255]
operator: { [7254,7255]
===
match
---
funcdef [9538,9917]
funcdef [9538,9917]
===
match
---
operator: , [3514,3515]
operator: , [3514,3515]
===
match
---
atom_expr [6447,6461]
atom_expr [6447,6461]
===
match
---
fstring_string: ` isn't defined [13599,13614]
fstring_string: ` isn't defined [13560,13575]
===
match
---
expr_stmt [5926,5974]
expr_stmt [5926,5974]
===
match
---
argument [11191,11222]
argument [11191,11222]
===
match
---
simple_stmt [5451,5578]
simple_stmt [5451,5578]
===
match
---
atom_expr [6040,6062]
atom_expr [6040,6062]
===
match
---
name: crypto [1302,1308]
name: crypto [1302,1308]
===
match
---
if_stmt [9143,9416]
if_stmt [9143,9416]
===
match
---
name: description [4565,4576]
name: description [4565,4576]
===
match
---
param [4460,4486]
param [4460,4486]
===
match
---
name: loads [12944,12949]
name: loads [12944,12949]
===
match
---
name: stacklevel [11661,11671]
name: stacklevel [11661,11671]
===
match
---
simple_stmt [7822,7833]
simple_stmt [7822,7833]
===
match
---
not_test [10809,10828]
not_test [10809,10828]
===
match
---
suite [7484,7538]
suite [7484,7538]
===
match
---
number: 500 [3747,3750]
number: 500 [3747,3750]
===
match
---
name: hook_class_name [11092,11107]
name: hook_class_name [11092,11107]
===
match
---
name: login [6112,6117]
name: login [6112,6117]
===
match
---
return_stmt [10092,10167]
return_stmt [10092,10167]
===
match
---
operator: = [3731,3732]
operator: = [3731,3732]
===
match
---
trailer [8081,8292]
trailer [8081,8292]
===
match
---
number: 1 [2185,2186]
number: 1 [2185,2186]
===
match
---
operator: , [11673,11674]
operator: , [11673,11674]
===
match
---
operator: , [872,873]
operator: , [872,873]
===
match
---
operator: + [7718,7719]
operator: + [7718,7719]
===
match
---
tfpdef [8444,8464]
tfpdef [8444,8464]
===
match
---
trailer [2179,2187]
trailer [2179,2187]
===
match
---
atom_expr [11700,12021]
atom_expr [11700,12021]
===
match
---
atom_expr [9807,9826]
atom_expr [9807,9826]
===
match
---
test [6218,6291]
test [6218,6291]
===
match
---
operator: += [7248,7250]
operator: += [7248,7250]
===
match
---
operator: = [4407,4408]
operator: = [4407,4408]
===
match
---
name: port [5280,5284]
name: port [5280,5284]
===
match
---
name: port [11851,11855]
name: port [11851,11855]
===
match
---
testlist_star_expr [10646,10701]
testlist_star_expr [10646,10701]
===
match
---
atom_expr [2165,2190]
atom_expr [2165,2190]
===
match
---
trailer [12720,12733]
trailer [12720,12733]
===
match
---
operator: = [9116,9117]
operator: = [9116,9117]
===
match
---
name: host_block [7126,7136]
name: host_block [7126,7136]
===
match
---
name: EXTRA_KEY [3430,3439]
name: EXTRA_KEY [3430,3439]
===
match
---
name: _password [10370,10379]
name: _password [10370,10379]
===
match
---
name: str [4366,4369]
name: str [4366,4369]
===
match
---
simple_stmt [11310,11454]
simple_stmt [11310,11454]
===
match
---
atom_expr [9737,9758]
atom_expr [9737,9758]
===
match
---
atom_expr [9072,9095]
atom_expr [9072,9095]
===
match
---
name: get_fernet [9118,9128]
name: get_fernet [9118,9128]
===
match
---
operator: = [3974,3975]
operator: = [3974,3975]
===
match
---
name: bytes [8623,8628]
name: bytes [8623,8628]
===
match
---
atom_expr [10291,10303]
atom_expr [10291,10303]
===
match
---
trailer [5864,5872]
trailer [5864,5872]
===
match
---
trailer [3739,3752]
trailer [3739,3752]
===
match
---
expr_stmt [3538,3599]
expr_stmt [3538,3599]
===
match
---
name: username [6138,6146]
name: username [6138,6146]
===
match
---
suite [8544,8707]
suite [8544,8707]
===
match
---
trailer [7954,7967]
trailer [7954,7967]
===
match
---
name: Text [1013,1017]
name: Text [1013,1017]
===
match
---
trailer [9736,9759]
trailer [9736,9759]
===
match
---
expr_stmt [2154,2190]
expr_stmt [2154,2190]
===
match
---
name: conn [13502,13506]
name: conn [13463,13467]
===
match
---
suite [10591,11224]
suite [10591,11224]
===
match
---
param [4387,4414]
param [4387,4414]
===
match
---
except_clause [10983,11001]
except_clause [10983,11001]
===
match
---
operator: , [11809,11810]
operator: , [11809,11810]
===
match
---
operator: , [11904,11905]
operator: , [11904,11905]
===
match
---
name: unquote [6040,6047]
name: unquote [6040,6047]
===
match
---
trailer [3807,3833]
trailer [3807,3833]
===
match
---
dictorsetmaker [7784,7810]
dictorsetmaker [7784,7810]
===
match
---
trailer [12548,12556]
trailer [12548,12556]
===
match
---
name: self [10529,10533]
name: self [10529,10533]
===
match
---
string: "use the default representation (__repr__)." [11571,11615]
string: "use the default representation (__repr__)." [11571,11615]
===
match
---
name: encrypt [8615,8622]
name: encrypt [8615,8622]
===
match
---
name: extra [4423,4428]
name: extra [4423,4428]
===
match
---
atom_expr [6218,6245]
atom_expr [6218,6245]
===
match
---
atom_expr [8333,8347]
atom_expr [8333,8347]
===
match
---
name: hook_name [10692,10701]
name: hook_name [10692,10701]
===
match
---
atom_expr [5451,5577]
atom_expr [5451,5577]
===
match
---
trailer [8028,8041]
trailer [8028,8041]
===
match
---
string: "Can't decrypt encrypted password for login={}, \                     FERNET_KEY configuration is missing" [8103,8209]
string: "Can't decrypt encrypted password for login={}, \                     FERNET_KEY configuration is missing" [8103,8209]
===
match
---
name: hostname [2087,2095]
name: hostname [2087,2095]
===
match
---
name: self [10195,10199]
name: self [10195,10199]
===
match
---
name: password [6236,6244]
name: password [6236,6244]
===
match
---
operator: , [2183,2184]
operator: , [2183,2184]
===
match
---
operator: = [4444,4445]
operator: = [4444,4445]
===
match
---
name: quote [6932,6937]
name: quote [6932,6937]
===
match
---
comparison [2047,2062]
comparison [2047,2062]
===
match
---
atom_expr [12641,12651]
atom_expr [12641,12651]
===
match
---
trailer [9369,9375]
trailer [9369,9375]
===
match
---
simple_stmt [7301,7332]
simple_stmt [7301,7332]
===
match
---
string: """Encrypt extra-data and save in object attribute to object.""" [9579,9643]
string: """Encrypt extra-data and save in object attribute to object.""" [9579,9643]
===
match
---
name: self [12544,12548]
name: self [12544,12548]
===
match
---
name: cls [10152,10155]
name: cls [10152,10155]
===
match
---
expr_stmt [8557,8578]
expr_stmt [8557,8578]
===
match
---
operator: , [12362,12363]
operator: , [12362,12363]
===
match
---
simple_stmt [6557,6588]
simple_stmt [6557,6588]
===
match
---
argument [13470,13485]
argument [13431,13446]
===
match
---
name: login [11899,11904]
name: login [11899,11904]
===
match
---
suite [12899,13128]
suite [12899,13089]
===
match
---
trailer [1592,1597]
trailer [1592,1597]
===
match
---
name: self [9072,9076]
name: self [9072,9076]
===
match
---
param [8744,8747]
param [8744,8747]
===
match
---
name: self [11242,11246]
name: self [11242,11246]
===
match
---
name: fernet [9109,9115]
name: fernet [9109,9115]
===
match
---
trailer [3851,3862]
trailer [3851,3862]
===
match
---
atom_expr [11462,11684]
atom_expr [11462,11684]
===
match
---
string: '_' [5878,5881]
string: '_' [5878,5881]
===
match
---
atom_expr [7509,7537]
atom_expr [7509,7537]
===
match
---
trailer [9128,9130]
trailer [9128,9130]
===
match
---
dotted_name [1112,1133]
dotted_name [1112,1133]
===
match
---
expr_stmt [7584,7596]
expr_stmt [7584,7596]
===
match
---
test [12665,12702]
test [12665,12702]
===
match
---
string: 'Connection' [13224,13236]
string: 'Connection' [13185,13197]
===
match
---
name: unquote [2210,2217]
name: unquote [2210,2217]
===
match
---
trailer [3713,3718]
trailer [3713,3718]
===
match
---
atom_expr [5106,5120]
atom_expr [5106,5120]
===
match
---
suite [12048,12745]
suite [12048,12745]
===
match
---
expr_stmt [6907,6961]
expr_stmt [6907,6961]
===
match
---
simple_stmt [3931,3997]
simple_stmt [3931,3997]
===
match
---
if_stmt [7100,7166]
if_stmt [7100,7166]
===
match
---
name: parse_qsl [6380,6389]
name: parse_qsl [6380,6389]
===
match
---
simple_stmt [5664,5690]
simple_stmt [5664,5690]
===
match
---
operator: = [7590,7591]
operator: = [7590,7591]
===
match
---
atom_expr [8931,8947]
atom_expr [8931,8947]
===
match
---
trailer [7647,7689]
trailer [7647,7689]
===
match
---
simple_stmt [6810,6856]
simple_stmt [6810,6856]
===
match
---
name: property [8922,8930]
name: property [8922,8930]
===
match
---
string: 'extra' [4017,4024]
string: 'extra' [4017,4024]
===
match
---
name: DeprecationWarning [5549,5567]
name: DeprecationWarning [5549,5567]
===
match
---
operator: = [4008,4009]
operator: = [4008,4009]
===
match
---
tfpdef [4193,4219]
tfpdef [4193,4219]
===
match
---
simple_stmt [1163,1237]
simple_stmt [1163,1237]
===
match
---
import_as_names [908,954]
import_as_names [908,954]
===
match
---
string: """This method is deprecated. Please use uri parameter in constructor.""" [5369,5442]
string: """This method is deprecated. Please use uri parameter in constructor.""" [5369,5442]
===
match
---
trailer [6511,6521]
trailer [6511,6521]
===
match
---
number: 500 [3630,3633]
number: 500 [3630,3633]
===
match
---
fstring_start: f' [10865,10867]
fstring_start: f' [10865,10867]
===
match
---
trailer [8000,8002]
trailer [8000,8002]
===
match
---
atom_expr [7103,7112]
atom_expr [7103,7112]
===
match
---
trailer [11827,11832]
trailer [11827,11832]
===
match
---
atom_expr [5275,5284]
atom_expr [5275,5284]
===
match
---
name: safe [6847,6851]
name: safe [6847,6851]
===
match
---
param [9951,9954]
param [9951,9954]
===
match
---
operator: , [4183,4184]
operator: , [4183,4184]
===
match
---
name: unique [3571,3577]
name: unique [3571,3577]
===
match
---
operator: , [11832,11833]
operator: , [11832,11833]
===
match
---
trailer [9857,9864]
trailer [9857,9864]
===
match
---
operator: += [7137,7139]
operator: += [7137,7139]
===
match
---
name: self [6774,6778]
name: self [6774,6778]
===
match
---
atom [12874,12876]
atom [12874,12876]
===
match
---
operator: = [5219,5220]
operator: = [5219,5220]
===
match
---
atom_expr [6175,6193]
atom_expr [6175,6193]
===
match
---
expr_stmt [9674,9695]
expr_stmt [9674,9695]
===
match
---
simple_stmt [5843,5883]
simple_stmt [5843,5883]
===
match
---
fstring_start: f' [7315,7317]
fstring_start: f' [7315,7317]
===
match
---
trailer [12530,12744]
trailer [12530,12744]
===
match
---
string: "@" [2103,2106]
string: "@" [2103,2106]
===
match
---
simple_stmt [8794,8875]
simple_stmt [8794,8875]
===
match
---
operator: = [6373,6374]
operator: = [6373,6374]
===
match
---
if_stmt [7609,7813]
if_stmt [7609,7813]
===
match
---
operator: , [13205,13206]
operator: , [13166,13167]
===
match
---
suite [5830,5883]
suite [5830,5883]
===
match
---
suite [6354,6588]
suite [6354,6588]
===
match
---
atom_expr [5938,5974]
atom_expr [5938,5974]
===
match
---
operator: , [11880,11881]
operator: , [11880,11881]
===
match
---
string: "use the default representation (__repr__)." [12318,12362]
string: "use the default representation (__repr__)." [12318,12362]
===
match
---
name: unique [3898,3904]
name: unique [3898,3904]
===
match
---
name: utils [1452,1457]
name: utils [1452,1457]
===
match
---
if_stmt [2044,2114]
if_stmt [2044,2114]
===
match
---
name: AirflowNotFoundException [13550,13574]
name: AirflowNotFoundException [13511,13535]
===
match
---
simple_stmt [1931,1976]
simple_stmt [1931,1976]
===
match
---
simple_stmt [5891,5918]
simple_stmt [5891,5918]
===
match
---
name: is_extra_encrypted [9890,9908]
name: is_extra_encrypted [9890,9908]
===
match
---
name: Boolean [3959,3966]
name: Boolean [3959,3966]
===
match
---
suite [7188,7332]
suite [7188,7332]
===
match
---
name: set_extra [10156,10165]
name: set_extra [10156,10165]
===
match
---
suite [2335,13617]
suite [2335,13578]
===
match
---
name: self [12042,12046]
name: self [12042,12046]
===
match
---
atom_expr [3852,3861]
atom_expr [3852,3861]
===
match
---
trailer [11873,11880]
trailer [11873,11880]
===
match
---
trailer [10427,10434]
trailer [10427,10434]
===
match
---
operator: { [10886,10887]
operator: { [10886,10887]
===
match
---
name: login [4693,4698]
name: login [4693,4698]
===
match
---
trailer [6690,6700]
trailer [6690,6700]
===
match
---
atom_expr [7519,7536]
atom_expr [7519,7536]
===
match
---
argument [1692,1700]
argument [1692,1700]
===
match
---
arglist [6718,6726]
arglist [6718,6726]
===
match
---
name: airflow [1242,1249]
name: airflow [1242,1249]
===
match
---
name: quote [919,924]
name: quote [919,924]
===
match
---
name: decrypt [9442,9449]
name: decrypt [9442,9449]
===
match
---
name: quote [7387,7392]
name: quote [7387,7392]
===
match
---
name: self [6835,6839]
name: self [6835,6839]
===
match
---
atom_expr [12716,12733]
atom_expr [12716,12733]
===
match
---
suite [4493,5323]
suite [4493,5323]
===
match
---
import_from [883,954]
import_from [883,954]
===
match
---
suite [7220,7267]
suite [7220,7267]
===
match
---
name: self [6107,6111]
name: self [6107,6111]
===
match
---
name: urlencode [7773,7782]
name: urlencode [7773,7782]
===
match
---
trailer [8318,8326]
trailer [8318,8326]
===
match
---
string: '_' [6718,6721]
string: '_' [6718,6721]
===
match
---
name: get_fernet [9683,9693]
name: get_fernet [9683,9693]
===
match
---
fstring [7251,7266]
fstring [7251,7266]
===
match
---
operator: , [8947,8948]
operator: , [8947,8948]
===
match
---
name: EXTRA_KEY [6512,6521]
name: EXTRA_KEY [6512,6521]
===
match
---
simple_stmt [6673,6733]
simple_stmt [6673,6733]
===
match
---
atom_expr [9885,9908]
atom_expr [9885,9908]
===
match
---
name: urllib [888,894]
name: urllib [888,894]
===
match
---
return_stmt [11173,11223]
return_stmt [11173,11223]
===
match
---
name: self [4560,4564]
name: self [4560,4564]
===
match
---
trailer [4130,4135]
trailer [4130,4135]
===
match
---
comp_op [6785,6791]
comp_op [6785,6791]
===
match
---
operator: , [6405,6406]
operator: , [6405,6406]
===
match
---
fstring_expr [7386,7415]
fstring_expr [7386,7415]
===
match
---
atom_expr [13114,13126]
atom_expr [13075,13087]
===
match
---
trailer [4533,4541]
trailer [4533,4541]
===
match
---
simple_stmt [1071,1106]
simple_stmt [1071,1106]
===
match
---
import_from [1107,1162]
import_from [1107,1162]
===
match
---
operator: * [1525,1526]
operator: * [1525,1526]
===
match
---
operator: = [6118,6119]
operator: = [6118,6119]
===
match
---
operator: , [12702,12703]
operator: , [12702,12703]
===
match
---
simple_stmt [7707,7726]
simple_stmt [7707,7726]
===
match
---
name: String [3555,3561]
name: String [3555,3561]
===
match
---
simple_stmt [883,955]
simple_stmt [883,955]
===
match
---
name: str [7873,7876]
name: str [7873,7876]
===
match
---
argument [5607,5612]
argument [5607,5612]
===
match
---
dictorsetmaker [11194,11221]
dictorsetmaker [11194,11221]
===
match
---
trailer [11783,12021]
trailer [11783,12021]
===
match
---
name: warn [11024,11028]
name: warn [11024,11028]
===
match
---
name: self [8333,8337]
name: self [8333,8337]
===
match
---
name: uri_parts [6312,6321]
name: uri_parts [6312,6321]
===
match
---
name: AirflowException [10848,10864]
name: AirflowException [10848,10864]
===
match
---
simple_stmt [10210,10274]
simple_stmt [10210,10274]
===
match
---
name: schema [5256,5262]
name: schema [5256,5262]
===
match
---
name: self [12616,12620]
name: self [12616,12620]
===
match
---
trailer [4509,4518]
trailer [4509,4518]
===
match
---
string: "This method is deprecated. You can read each field individually or " [11489,11558]
string: "This method is deprecated. You can read each field individually or " [11489,11558]
===
match
---
comparison [1983,1998]
comparison [1983,1998]
===
match
---
name: uri_parts [1861,1870]
name: uri_parts [1861,1870]
===
match
---
name: conn_type [6691,6700]
name: conn_type [6691,6700]
===
match
---
name: value [8629,8634]
name: value [8629,8634]
===
match
---
operator: , [5351,5352]
operator: , [5351,5352]
===
match
---
trailer [2095,2102]
trailer [2095,2102]
===
match
---
name: self [12679,12683]
name: self [12679,12683]
===
match
---
trailer [10319,10329]
trailer [10319,10329]
===
match
---
simple_stmt [11015,11147]
simple_stmt [11015,11147]
===
match
---
expr_stmt [6488,6522]
expr_stmt [6488,6522]
===
match
---
suite [2141,2191]
suite [2141,2191]
===
match
---
return_stmt [9428,9487]
return_stmt [9428,9487]
===
match
---
name: rsplit [2096,2102]
name: rsplit [2096,2102]
===
match
---
atom_expr [11264,11276]
atom_expr [11264,11276]
===
match
---
name: hook_class_name [10813,10828]
name: hook_class_name [10813,10828]
===
match
---
suite [8042,8293]
suite [8042,8293]
===
match
---
param [5645,5653]
param [5645,5653]
===
match
---
arglist [8629,8643]
arglist [8629,8643]
===
match
---
trailer [13071,13127]
trailer [13032,13088]
===
match
---
trailer [10547,10556]
trailer [10547,10556]
===
match
---
name: port [4387,4391]
name: port [4387,4391]
===
match
---
or_test [1950,1974]
or_test [1950,1974]
===
match
---
if_stmt [7201,7332]
if_stmt [7201,7332]
===
match
---
name: EXTRA_KEY [6452,6461]
name: EXTRA_KEY [6452,6461]
===
match
---
operator: = [9805,9806]
operator: = [9805,9806]
===
match
---
expr_stmt [12868,12876]
expr_stmt [12868,12876]
===
match
---
name: authority_block [6907,6922]
name: authority_block [6907,6922]
===
match
---
name: self [11823,11827]
name: self [11823,11827]
===
match
---
operator: = [4577,4578]
operator: = [4577,4578]
===
match
---
expr_stmt [5106,5132]
expr_stmt [5106,5132]
===
match
---
simple_stmt [5242,5263]
simple_stmt [5242,5263]
===
match
---
arglist [7658,7687]
arglist [7658,7687]
===
match
---
simple_stmt [4529,4552]
simple_stmt [4529,4552]
===
match
---
atom_expr [8103,8274]
atom_expr [8103,8274]
===
match
---
simple_stmt [6300,6327]
simple_stmt [6300,6327]
===
match
---
name: password [11937,11945]
name: password [11937,11945]
===
match
---
name: self [5586,5590]
name: self [5586,5590]
===
match
---
atom_expr [2210,2227]
atom_expr [2210,2227]
===
match
---
atom_expr [6226,6244]
atom_expr [6226,6244]
===
match
---
simple_stmt [11159,11165]
simple_stmt [11159,11165]
===
match
---
arith_expr [6926,6961]
arith_expr [6926,6961]
===
match
---
simple_stmt [7126,7166]
simple_stmt [7126,7166]
===
match
---
atom_expr [3801,3833]
atom_expr [3801,3833]
===
match
---
name: Column [3700,3706]
name: Column [3700,3706]
===
match
---
name: password [6207,6215]
name: password [6207,6215]
===
match
---
fstring_string: Unknown hook type " [10867,10886]
fstring_string: Unknown hook type " [10867,10886]
===
match
---
suite [6797,6856]
suite [6797,6856]
===
match
---
operator: = [6957,6958]
operator: = [6957,6958]
===
match
---
parameters [9950,9955]
parameters [9950,9955]
===
match
---
name: get_fernet [8566,8576]
name: get_fernet [8566,8576]
===
match
---
expr_stmt [10365,10436]
expr_stmt [10365,10436]
===
match
---
operator: = [8921,8922]
operator: = [8921,8922]
===
match
---
atom_expr [6835,6845]
atom_expr [6835,6845]
===
match
---
simple_stmt [6907,6962]
simple_stmt [6907,6962]
===
match
---
argument [3898,3910]
argument [3898,3910]
===
match
---
atom_expr [11180,11223]
atom_expr [11180,11223]
===
match
---
fstring_end: ' [7265,7266]
fstring_end: ' [7265,7266]
===
match
---
trailer [7392,7414]
trailer [7392,7414]
===
match
---
name: str [13216,13219]
name: str [13177,13180]
===
match
---
operator: , [12602,12603]
operator: , [12602,12603]
===
match
---
param [7855,7859]
param [7855,7859]
===
match
---
operator: ** [1692,1694]
operator: ** [1692,1694]
===
match
---
name: extra_dejson [12768,12780]
name: extra_dejson [12768,12780]
===
match
---
operator: , [13112,13113]
operator: , [13073,13074]
===
match
---
name: AirflowException [8065,8081]
name: AirflowException [8065,8081]
===
match
---
name: format [8210,8216]
name: format [8210,8216]
===
match
---
name: uri_parts [6175,6184]
name: uri_parts [6175,6184]
===
match
---
name: schema [5247,5253]
name: schema [5247,5253]
===
match
---
name: Optional [4393,4401]
name: Optional [4393,4401]
===
match
---
operator: , [9556,9557]
operator: , [9556,9557]
===
match
---
name: hostname [2199,2207]
name: hostname [2199,2207]
===
match
---
atom [11193,11222]
atom [11193,11222]
===
match
---
name: conn_type [3604,3613]
name: conn_type [3604,3613]
===
match
---
trailer [6137,6146]
trailer [6137,6146]
===
match
---
suite [6995,7067]
suite [6995,7067]
===
match
---
name: host_block [7237,7247]
name: host_block [7237,7247]
===
match
---
name: password [6873,6881]
name: password [6873,6881]
===
match
---
name: set_extra [9542,9551]
name: set_extra [9542,9551]
===
match
---
trailer [9478,9485]
trailer [9478,9485]
===
match
---
trailer [3706,3719]
trailer [3706,3719]
===
match
---
name: query [6367,6372]
name: query [6367,6372]
===
match
---
simple_stmt [800,816]
simple_stmt [800,816]
===
match
---
operator: = [10127,10128]
operator: = [10127,10128]
===
match
---
number: 0 [2188,2189]
number: 0 [2188,2189]
===
match
---
comparison [7622,7689]
comparison [7622,7689]
===
match
---
number: 500 [3779,3782]
number: 500 [3779,3782]
===
match
---
operator: = [4177,4178]
operator: = [4177,4178]
===
match
---
trailer [4287,4292]
trailer [4287,4292]
===
match
---
name: password [4702,4710]
name: password [4702,4710]
===
match
---
expr_stmt [6107,6193]
expr_stmt [6107,6193]
===
match
---
name: format [9333,9339]
name: format [9333,9339]
===
match
---
import_as_names [1269,1281]
import_as_names [1269,1281]
===
match
---
name: authority_block [7008,7023]
name: authority_block [7008,7023]
===
match
---
operator: { [7783,7784]
operator: { [7783,7784]
===
match
---
operator: , [8909,8910]
operator: , [8909,8910]
===
match
---
operator: = [5853,5854]
operator: = [5853,5854]
===
match
---
name: _password [10401,10410]
name: _password [10401,10410]
===
match
---
name: _parse_from_uri [5623,5638]
name: _parse_from_uri [5623,5638]
===
match
---
trailer [4030,4032]
trailer [4030,4032]
===
match
---
operator: = [5936,5937]
operator: = [5936,5937]
===
match
---
atom_expr [10746,10760]
atom_expr [10746,10760]
===
match
---
name: hostname [1990,1998]
name: hostname [1990,1998]
===
match
---
string: '@' [7027,7030]
string: '@' [7027,7030]
===
match
---
name: authority_block [7051,7066]
name: authority_block [7051,7066]
===
match
---
name: decode [8646,8652]
name: decode [8646,8652]
===
match
---
simple_stmt [4761,5026]
simple_stmt [4761,5026]
===
match
---
string: 'postgres' [5789,5799]
string: 'postgres' [5789,5799]
===
match
---
name: unquote [1942,1949]
name: unquote [1942,1949]
===
match
---
name: safe [7157,7161]
name: safe [7157,7161]
===
match
---
funcdef [10572,11224]
funcdef [10572,11224]
===
match
---
atom_expr [5676,5689]
atom_expr [5676,5689]
===
match
---
atom_expr [6312,6326]
atom_expr [6312,6326]
===
match
---
name: port [6305,6309]
name: port [6305,6309]
===
match
---
atom_expr [12950,12960]
atom_expr [12950,12960]
===
match
---
trailer [8897,8967]
trailer [8897,8967]
===
match
---
expr_stmt [6202,6291]
expr_stmt [6202,6291]
===
match
---
atom_expr [10848,10905]
atom_expr [10848,10905]
===
match
---
name: conn_type [5111,5120]
name: conn_type [5111,5120]
===
match
---
trailer [9889,9908]
trailer [9889,9908]
===
match
---
trailer [5110,5120]
trailer [5110,5120]
===
match
---
simple_stmt [7501,7538]
simple_stmt [7501,7538]
===
match
---
operator: = [12418,12419]
operator: = [12418,12419]
===
match
---
atom_expr [9150,9169]
atom_expr [9150,9169]
===
match
---
name: debug_info [12031,12041]
name: debug_info [12031,12041]
===
match
---
name: ProvidersManager [1365,1381]
name: ProvidersManager [1365,1381]
===
match
---
decorated [8712,8968]
decorated [8712,8968]
===
match
---
string: """         Get connection by conn_id.          :param conn_id: connection id         :return: connection         """ [13246,13363]
string: """         Get connection by conn_id.          :param conn_id: connection id         :return: connection         """ [13207,13324]
===
match
---
trailer [5606,5613]
trailer [5606,5613]
===
match
---
name: __tablename__ [3459,3472]
name: __tablename__ [3459,3472]
===
match
---
operator: , [6951,6952]
operator: , [6951,6952]
===
match
---
name: hook_class_name [10646,10661]
name: hook_class_name [10646,10661]
===
match
---
name: self [6557,6561]
name: self [6557,6561]
===
match
---
operator: = [4479,4480]
operator: = [4479,4480]
===
match
---
expr_stmt [9109,9130]
expr_stmt [9109,9130]
===
match
---
operator: = [6851,6852]
operator: = [6851,6852]
===
match
---
operator: , [6721,6722]
operator: , [6721,6722]
===
match
---
trailer [6184,6193]
trailer [6184,6193]
===
match
---
file_input [788,13617]
file_input [788,13578]
===
match
---
name: port [12598,12602]
name: port [12598,12602]
===
match
---
name: self [7456,7460]
name: self [7456,7460]
===
match
---
operator: , [7663,7664]
operator: , [7663,7664]
===
match
---
simple_stmt [8475,8527]
simple_stmt [8475,8527]
===
match
---
name: id [3493,3495]
name: id [3493,3495]
===
match
---
atom_expr [3820,3832]
atom_expr [3820,3832]
===
match
---
suite [7968,8368]
suite [7968,8368]
===
match
---
name: quoted_schema [5983,5996]
name: quoted_schema [5983,5996]
===
match
---
suite [9570,9917]
suite [9570,9917]
===
match
---
trailer [7182,7187]
trailer [7182,7187]
===
match
---
name: self [10746,10750]
name: self [10746,10750]
===
match
---
simple_stmt [5304,5323]
simple_stmt [5304,5323]
===
match
---
trailer [12892,12898]
trailer [12892,12898]
===
match
---
name: fernet [8022,8028]
name: fernet [8022,8028]
===
match
---
name: configuration [1120,1133]
name: configuration [1120,1133]
===
match
---
name: self [5145,5149]
name: self [5145,5149]
===
match
---
string: 'utf-8' [8349,8356]
string: 'utf-8' [8349,8356]
===
match
---
fstring_expr [13590,13599]
fstring_expr [13551,13560]
===
match
---
if_stmt [7453,7813]
if_stmt [7453,7813]
===
match
---
string: '' [6992,6994]
string: '' [6992,6994]
===
match
---
name: nullable [3636,3644]
name: nullable [3636,3644]
===
match
---
name: models [1250,1256]
name: models [1250,1256]
===
match
---
param [11242,11246]
param [11242,11246]
===
match
---
name: replace [5865,5872]
name: replace [5865,5872]
===
match
---
suite [9661,9827]
suite [9661,9827]
===
match
---
param [12781,12785]
param [12781,12785]
===
match
---
operator: = [6038,6039]
operator: = [6038,6039]
===
match
---
operator: , [6845,6846]
operator: , [6845,6846]
===
match
---
atom_expr [13057,13127]
atom_expr [13014,13088]
===
match
---
expr_stmt [12933,12961]
expr_stmt [12933,12961]
===
match
---
simple_stmt [5369,5443]
simple_stmt [5369,5443]
===
match
---
arith_expr [7767,7812]
arith_expr [7767,7812]
===
match
---
import_from [849,882]
import_from [849,882]
===
match
---
trailer [10468,10487]
trailer [10468,10487]
===
match
---
name: Optional [4430,4438]
name: Optional [4430,4438]
===
match
---
operator: = [5787,5788]
operator: = [5787,5788]
===
match
---
string: """Return encrypted password.""" [7887,7919]
string: """Return encrypted password.""" [7887,7919]
===
match
---
name: declared_attr [8713,8726]
name: declared_attr [8713,8726]
===
match
---
expr_stmt [7760,7812]
expr_stmt [7760,7812]
===
match
---
name: quoted_schema [6066,6079]
name: quoted_schema [6066,6079]
===
match
---
simple_stmt [7584,7597]
simple_stmt [7584,7597]
===
match
---
name: extra [7805,7810]
name: extra [7805,7810]
===
match
---
return_stmt [8305,8367]
return_stmt [8305,8367]
===
match
---
dotted_name [1242,1261]
dotted_name [1242,1261]
===
match
---
operator: = [5708,5709]
operator: = [5708,5709]
===
match
---
simple_stmt [9885,9917]
simple_stmt [9885,9917]
===
match
---
name: str [6682,6685]
name: str [6682,6685]
===
match
---
comparison [6868,6893]
comparison [6868,6893]
===
match
---
atom [7783,7811]
atom [7783,7811]
===
match
---
name: format [12524,12530]
name: format [12524,12530]
===
match
---
expr_stmt [4560,4590]
expr_stmt [4560,4590]
===
match
---
string: """Encrypts data with a new key. See: :ref:`security/fernet`""" [10210,10273]
string: """Encrypts data with a new key. See: :ref:`security/fernet`""" [10210,10273]
===
match
---
operator: = [5315,5316]
operator: = [5315,5316]
===
match
---
test [6120,6193]
test [6120,6193]
===
match
---
simple_stmt [10092,10168]
simple_stmt [10092,10168]
===
match
---
name: Dict [8996,9000]
name: Dict [8996,9000]
===
match
---
name: self [7393,7397]
name: self [7393,7397]
===
match
---
arglist [6390,6429]
arglist [6390,6429]
===
match
---
number: 1 [6014,6015]
number: 1 [6014,6015]
===
match
---
name: uri [4460,4463]
name: uri [4460,4463]
===
match
---
simple_stmt [5054,5080]
simple_stmt [5054,5080]
===
match
---
name: self [7178,7182]
name: self [7178,7182]
===
match
---
arglist [3889,3925]
arglist [3889,3925]
===
match
---
operator: = [3440,3441]
operator: = [3440,3441]
===
match
---
trailer [6399,6405]
trailer [6399,6405]
===
match
---
number: 5000 [3682,3686]
number: 5000 [3682,3686]
===
match
---
fstring [6679,6732]
fstring [6679,6732]
===
match
---
dotted_name [1332,1357]
dotted_name [1332,1357]
===
match
---
string: ":" [2180,2183]
string: ":" [2180,2183]
===
match
---
name: hook_name [11109,11118]
name: hook_name [11109,11118]
===
match
---
trailer [5895,5905]
trailer [5895,5905]
===
match
---
simple_stmt [9674,9696]
simple_stmt [9674,9696]
===
match
---
trailer [9693,9695]
trailer [9693,9695]
===
match
---
name: uri [7760,7763]
name: uri [7760,7763]
===
match
---
suite [10488,10567]
suite [10488,10567]
===
match
---
atom_expr [3555,3569]
atom_expr [3555,3569]
===
match
---
atom_expr [6774,6784]
atom_expr [6774,6784]
===
match
---
name: sqlalchemy [1076,1086]
name: sqlalchemy [1076,1086]
===
match
---
name: login [4272,4277]
name: login [4272,4277]
===
match
---
name: host_block [7433,7443]
name: host_block [7433,7443]
===
match
---
atom_expr [11015,11146]
atom_expr [11015,11146]
===
match
---
name: hook_class [11180,11190]
name: hook_class [11180,11190]
===
match
---
operator: , [11955,11956]
operator: , [11955,11956]
===
match
---
name: schema [7398,7404]
name: schema [7398,7404]
===
match
---
name: uri_parts [5664,5673]
name: uri_parts [5664,5673]
===
match
---
atom_expr [6120,6147]
atom_expr [6120,6147]
===
match
---
atom_expr [8566,8578]
atom_expr [8566,8578]
===
match
---
tfpdef [4349,4370]
tfpdef [4349,4370]
===
match
---
name: _password [8338,8347]
name: _password [8338,8347]
===
match
---
name: username [6185,6193]
name: username [6185,6193]
===
match
---
name: self [11295,11299]
name: self [11295,11299]
===
match
---
dotted_name [1023,1049]
dotted_name [1023,1049]
===
match
---
operator: , [8634,8635]
operator: , [8634,8635]
===
match
---
operator: = [3496,3497]
operator: = [3496,3497]
===
match
---
operator: = [12937,12938]
operator: = [12937,12938]
===
match
---
name: ID_LEN [1269,1275]
name: ID_LEN [1269,1275]
===
match
---
trailer [9728,9736]
trailer [9728,9736]
===
match
---
name: value [8444,8449]
name: value [8444,8449]
===
match
---
atom_expr [7344,7355]
atom_expr [7344,7355]
===
match
---
simple_stmt [1584,1648]
simple_stmt [1584,1648]
===
match
---
argument [7157,7164]
argument [7157,7164]
===
match
---
name: self [6868,6872]
name: self [6868,6872]
===
match
---
name: ext [1034,1037]
name: ext [1034,1037]
===
match
---
simple_stmt [788,800]
simple_stmt [788,800]
===
match
---
name: DeprecationWarning [12376,12394]
name: DeprecationWarning [12376,12394]
===
match
---
operator: , [11647,11648]
operator: , [11647,11648]
===
match
---
name: self [6447,6451]
name: self [6447,6451]
===
match
---
expr_stmt [3430,3453]
expr_stmt [3430,3453]
===
match
---
subscript [6014,6016]
subscript [6014,6016]
===
match
---
name: Column [3616,3622]
name: Column [3616,3622]
===
match
---
name: str [4215,4218]
name: str [4215,4218]
===
match
---
arglist [2103,2109]
arglist [2103,2109]
===
match
---
name: query [6348,6353]
name: query [6348,6353]
===
match
---
arglist [10107,10166]
arglist [10107,10166]
===
match
---
name: json [795,799]
name: json [795,799]
===
match
---
name: extra_dejson [7524,7536]
name: extra_dejson [7524,7536]
===
match
---
arglist [12236,12421]
arglist [12236,12421]
===
match
---
name: query [7584,7589]
name: query [7584,7589]
===
match
---
trailer [9076,9095]
trailer [9076,9095]
===
match
---
name: conn_id [3538,3545]
name: conn_id [3538,3545]
===
match
---
operator: , [4413,4414]
operator: , [4413,4414]
===
match
---
name: self [6026,6030]
name: self [6026,6030]
===
match
---
atom_expr [4206,4219]
atom_expr [4206,4219]
===
match
---
trailer [8332,8357]
trailer [8332,8357]
===
match
---
name: conn_id [13591,13598]
name: conn_id [13552,13559]
===
match
---
suite [1872,2248]
suite [1872,2248]
===
match
---
simple_stmt [2232,2248]
simple_stmt [2232,2248]
===
match
---
funcdef [5328,5614]
funcdef [5328,5614]
===
match
---
name: uri_parts [6390,6399]
name: uri_parts [6390,6399]
===
match
---
atom_expr [3700,3719]
atom_expr [3700,3719]
===
match
---
name: str [4328,4331]
name: str [4328,4331]
===
match
---
funcdef [5619,6588]
funcdef [5619,6588]
===
match
---
decorator [8712,8727]
decorator [8712,8727]
===
match
---
string: """Extra data. The value is decrypted/encrypted when reading/setting the value.""" [10001,10083]
string: """Extra data. The value is decrypted/encrypted when reading/setting the value.""" [10001,10083]
===
match
---
fstring_end: " [7415,7416]
fstring_end: " [7415,7416]
===
match
---
name: Optional [4319,4327]
name: Optional [4319,4327]
===
match
---
operator: , [1626,1627]
operator: , [1626,1627]
===
match
---
name: uri_parts [6273,6282]
name: uri_parts [6273,6282]
===
match
---
trailer [8614,8622]
trailer [8614,8622]
===
match
---
dotted_name [1076,1090]
dotted_name [1076,1090]
===
match
---
operator: = [7161,7162]
operator: = [7161,7162]
===
match
---
name: Dict [12790,12794]
name: Dict [12790,12794]
===
match
---
trailer [8365,8367]
trailer [8365,8367]
===
match
---
operator: = [3919,3920]
operator: = [3919,3920]
===
match
---
operator: , [3569,3570]
operator: , [3569,3570]
===
match
---
atom_expr [10099,10167]
atom_expr [10099,10167]
===
match
---
name: String [3740,3746]
name: String [3740,3746]
===
match
---
string: 'utf-8' [9469,9476]
string: 'utf-8' [9469,9476]
===
match
---
arglist [8931,8965]
arglist [8931,8965]
===
match
---
name: str [5650,5653]
name: str [5650,5653]
===
match
---
string: '' [7089,7091]
string: '' [7089,7091]
===
match
---
atom_expr [4357,4370]
atom_expr [4357,4370]
===
match
---
name: uri_parts [5964,5973]
name: uri_parts [5964,5973]
===
match
---
atom_expr [7622,7639]
atom_expr [7622,7639]
===
match
---
operator: , [5547,5548]
operator: , [5547,5548]
===
match
---
atom_expr [11797,11809]
atom_expr [11797,11809]
===
match
---
name: replace [6710,6717]
name: replace [6710,6717]
===
match
---
trailer [5719,5726]
trailer [5719,5726]
===
match
---
name: synonym [10099,10106]
name: synonym [10099,10106]
===
match
---
trailer [10388,10395]
trailer [10388,10395]
===
match
---
name: _extra [9713,9719]
name: _extra [9713,9719]
===
match
---
trailer [8622,8645]
trailer [8622,8645]
===
match
---
number: 2 [11672,11673]
number: 2 [11672,11673]
===
match
---
operator: += [7430,7432]
operator: += [7430,7432]
===
match
---
string: '-' [5813,5816]
string: '-' [5813,5816]
===
match
---
name: _extra [4001,4007]
name: _extra [4001,4007]
===
match
---
atom_expr [10128,10166]
atom_expr [10128,10166]
===
match
---
tfpdef [9558,9568]
tfpdef [9558,9568]
===
match
---
parameters [9551,9569]
parameters [9551,9569]
===
match
---
name: args [1526,1530]
name: args [1526,1530]
===
match
---
operator: , [3910,3911]
operator: , [3910,3911]
===
match
---
atom_expr [10152,10165]
atom_expr [10152,10165]
===
match
---
name: synonym [1098,1105]
name: synonym [1098,1105]
===
match
---
name: warnings [1584,1592]
name: warnings [1584,1592]
===
match
---
name: query [7658,7663]
name: query [7658,7663]
===
match
---
suite [10829,10906]
suite [10829,10906]
===
match
---
atom_expr [9781,9804]
atom_expr [9781,9804]
===
match
---
suite [9992,10168]
suite [9992,10168]
===
match
---
name: get_fernet [7990,8000]
name: get_fernet [7990,8000]
===
match
---
except_clause [7550,7566]
except_clause [7550,7566]
===
match
---
expr_stmt [5242,5262]
expr_stmt [5242,5262]
===
match
---
name: Column [3670,3676]
name: Column [3670,3676]
===
match
---
suite [5041,5080]
suite [5041,5080]
===
match
---
simple_stmt [7076,7092]
simple_stmt [7076,7092]
===
match
---
string: 'utf-8' [9750,9757]
string: 'utf-8' [9750,9757]
===
match
---
atom_expr [5999,6017]
atom_expr [5999,6017]
===
match
---
trailer [10369,10379]
trailer [10369,10379]
===
match
---
arglist [1598,1646]
arglist [1598,1646]
===
match
---
name: hostname [2132,2140]
name: hostname [2132,2140]
===
match
---
funcdef [6593,7833]
funcdef [6593,7833]
===
match
---
name: fernet [10515,10521]
name: fernet [10515,10521]
===
match
---
atom_expr [10382,10436]
atom_expr [10382,10436]
===
match
---
simple_stmt [7369,7417]
simple_stmt [7369,7417]
===
match
---
atom_expr [8065,8292]
atom_expr [8065,8292]
===
match
---
operator: , [11090,11091]
operator: , [11090,11091]
===
match
---
name: rotate [10522,10528]
name: rotate [10522,10528]
===
match
---
atom_expr [6107,6117]
atom_expr [6107,6117]
===
match
---
name: warn [5460,5464]
name: warn [5460,5464]
===
match
---
trailer [7259,7264]
trailer [7259,7264]
===
match
---
operator: { [12874,12875]
operator: { [12874,12875]
===
match
---
funcdef [11229,11277]
funcdef [11229,11277]
===
match
---
atom_expr [5304,5314]
atom_expr [5304,5314]
===
match
---
name: password [5221,5229]
name: password [5221,5229]
===
match
---
atom_expr [9722,9768]
atom_expr [9722,9768]
===
match
---
raise_stmt [10842,10905]
raise_stmt [10842,10905]
===
match
---
if_stmt [6444,6588]
if_stmt [6444,6588]
===
match
---
funcdef [10173,10567]
funcdef [10173,10567]
===
match
---
name: warnings [5451,5459]
name: warnings [5451,5459]
===
match
---
operator: , [11615,11616]
operator: , [11615,11616]
===
match
---
name: Base [1277,1281]
name: Base [1277,1281]
===
match
---
simple_stmt [5586,5614]
simple_stmt [5586,5614]
===
match
---
arglist [4017,4032]
arglist [4017,4032]
===
match
---
name: login [8247,8252]
name: login [8247,8252]
===
match
---
expr_stmt [10501,10566]
expr_stmt [10501,10566]
===
match
---
atom_expr [8022,8041]
atom_expr [8022,8041]
===
match
---
name: uri_parts [6226,6235]
name: uri_parts [6226,6235]
===
match
---
name: host [5931,5935]
name: host [5931,5935]
===
match
---
name: extra [12955,12960]
name: extra [12955,12960]
===
match
---
name: warn [12218,12222]
name: warn [12218,12222]
===
match
---
fstring [13575,13615]
fstring [13536,13576]
===
match
---
name: encode [10541,10547]
name: encode [10541,10547]
===
match
---
operator: , [5643,5644]
operator: , [5643,5644]
===
match
---
atom_expr [6557,6567]
atom_expr [6557,6567]
===
match
---
trailer [6937,6961]
trailer [6937,6961]
===
match
---
dotted_name [1387,1418]
dotted_name [1387,1418]
===
match
---
name: self [9708,9712]
name: self [9708,9712]
===
match
---
arglist [9456,9476]
arglist [9456,9476]
===
match
---
decorator [12750,12760]
decorator [12750,12760]
===
match
---
trailer [10891,10901]
trailer [10891,10901]
===
match
---
operator: , [7155,7156]
operator: , [7155,7156]
===
match
---
name: self [10334,10338]
name: self [10334,10338]
===
match
---
name: self [12716,12720]
name: self [12716,12720]
===
match
---
name: schema [6031,6037]
name: schema [6031,6037]
===
match
---
name: self [12570,12574]
name: self [12570,12574]
===
match
---
string: """Return encrypted extra-data.""" [9010,9044]
string: """Return encrypted extra-data.""" [9010,9044]
===
match
---
string: '-' [6723,6726]
string: '-' [6723,6726]
===
match
---
operator: , [4262,4263]
operator: , [4262,4263]
===
match
---
name: uri [7707,7710]
name: uri [7707,7710]
===
match
---
parameters [13201,13220]
parameters [13162,13181]
===
match
---
fstring_string: The conn_id ` [13577,13590]
fstring_string: The conn_id ` [13538,13551]
===
match
---
operator: @ [8712,8713]
operator: @ [8712,8713]
===
match
---
string: "id: {}. Host: {}, Port: {}, Schema: {}, Login: {}, Password: {}, extra: {}" [12447,12523]
string: "id: {}. Host: {}, Port: {}, Schema: {}, Login: {}, Password: {}, extra: {}" [12447,12523]
===
match
---
trailer [5464,5577]
trailer [5464,5577]
===
match
---
trailer [5459,5464]
trailer [5459,5464]
===
match
---
simple_stmt [9579,9644]
simple_stmt [9579,9644]
===
match
---
expr_stmt [5304,5322]
expr_stmt [5304,5322]
===
match
---
name: password [5210,5218]
name: password [5210,5218]
===
match
---
simple_stmt [6742,6763]
simple_stmt [6742,6763]
===
match
---
name: import_string [10944,10957]
name: import_string [10944,10957]
===
match
---
operator: { [13590,13591]
operator: { [13551,13552]
===
match
---
trailer [10452,10459]
trailer [10452,10459]
===
match
---
string: "id: {}. Host: {}, Port: {}, Schema: {}, Login: {}, Password: {}, extra: {}" [11700,11776]
string: "id: {}. Host: {}, Port: {}, Schema: {}, Login: {}, Password: {}, extra: {}" [11700,11776]
===
match
---
atom_expr [10365,10379]
atom_expr [10365,10379]
===
match
---
operator: = [10513,10514]
operator: = [10513,10514]
===
match
---
trailer [10521,10528]
trailer [10521,10528]
===
match
---
operator: , [10690,10691]
operator: , [10690,10691]
===
match
---
atom_expr [10334,10351]
atom_expr [10334,10351]
===
match
---
simple_stmt [6026,6099]
simple_stmt [6026,6099]
===
match
---
name: conn_type [5738,5747]
name: conn_type [5738,5747]
===
match
---
string: '/' [1983,1986]
string: '/' [1983,1986]
===
match
---
atom_expr [4767,5025]
atom_expr [4767,5025]
===
match
---
name: urlparse [5676,5684]
name: urlparse [5676,5684]
===
match
---
expr_stmt [2008,2035]
expr_stmt [2008,2035]
===
match
---
simple_stmt [8667,8707]
simple_stmt [8667,8707]
===
match
---
string: '' [7162,7164]
string: '' [7162,7164]
===
match
---
trailer [13454,13469]
trailer [13415,13430]
===
match
---
parameters [5346,5359]
parameters [5346,5359]
===
match
---
expr_stmt [5145,5161]
expr_stmt [5145,5161]
===
match
---
decorator [9922,9937]
decorator [9922,9937]
===
match
---
expr_stmt [3604,3651]
expr_stmt [3604,3651]
===
match
---
and_test [10315,10351]
and_test [10315,10351]
===
match
---
name: uri [5645,5648]
name: uri [5645,5648]
===
match
---
trailer [6347,6353]
trailer [6347,6353]
===
match
---
simple_stmt [956,1018]
simple_stmt [956,1018]
===
match
---
fstring_string: " [10902,10903]
fstring_string: " [10902,10903]
===
match
---
name: fernet [9150,9156]
name: fernet [9150,9156]
===
match
---
simple_stmt [3656,3689]
simple_stmt [3656,3689]
===
match
---
trailer [13118,13126]
trailer [13079,13087]
===
match
---
name: is_encrypted [10339,10351]
name: is_encrypted [10339,10351]
===
match
---
atom_expr [9056,9067]
atom_expr [9056,9067]
===
match
---
simple_stmt [3459,3488]
simple_stmt [3459,3488]
===
match
---
atom_expr [7178,7187]
atom_expr [7178,7187]
===
match
---
operator: = [3668,3669]
operator: = [3668,3669]
===
match
---
name: urlparse [946,954]
name: urlparse [946,954]
===
match
---
name: JSONDecodeError [12981,12996]
name: JSONDecodeError [12981,12996]
===
match
---
operator: = [6424,6425]
operator: = [6424,6425]
===
match
---
expr_stmt [3656,3688]
expr_stmt [3656,3688]
===
match
---
trailer [5684,5689]
trailer [5684,5689]
===
match
---
suite [7356,7417]
suite [7356,7417]
===
match
---
atom_expr [7140,7165]
atom_expr [7140,7165]
===
match
---
simple_stmt [8394,8416]
simple_stmt [8394,8416]
===
match
---
operator: } [7329,7330]
operator: } [7329,7330]
===
match
---
atom_expr [12888,12898]
atom_expr [12888,12898]
===
match
---
name: str [4251,4254]
name: str [4251,4254]
===
match
---
atom_expr [8451,8464]
atom_expr [8451,8464]
===
match
---
trailer [12949,12961]
trailer [12949,12961]
===
match
---
simple_stmt [9708,9769]
simple_stmt [9708,9769]
===
match
---
name: default [3912,3919]
name: default [3912,3919]
===
match
---
import_from [956,1017]
import_from [956,1017]
===
match
---
name: str [8460,8463]
name: str [8460,8463]
===
match
---
trailer [9455,9477]
trailer [9455,9477]
===
match
---
name: is_extra_encrypted [10469,10487]
name: is_extra_encrypted [10469,10487]
===
match
---
name: String [3820,3826]
name: String [3820,3826]
===
match
---
trailer [6778,6784]
trailer [6778,6784]
===
match
---
name: hooks [10723,10728]
name: hooks [10723,10728]
===
match
---
operator: = [7507,7508]
operator: = [7507,7508]
===
match
---
if_stmt [9652,9917]
if_stmt [9652,9917]
===
match
---
atom_expr [6868,6881]
atom_expr [6868,6881]
===
match
---
atom_expr [6829,6855]
atom_expr [6829,6855]
===
match
---
simple_stmt [9514,9533]
simple_stmt [9514,9533]
===
match
---
suite [8381,8416]
suite [8381,8416]
===
match
---
name: uri_parts [6338,6347]
name: uri_parts [6338,6347]
===
match
---
name: get_password [7842,7854]
name: get_password [7842,7854]
===
match
---
name: login [6779,6784]
name: login [6779,6784]
===
match
---
name: split [2174,2179]
name: split [2174,2179]
===
match
---
if_stmt [10445,10567]
if_stmt [10445,10567]
===
match
---
suite [6471,6523]
suite [6471,6523]
===
match
---
name: AirflowException [4767,4783]
name: AirflowException [4767,4783]
===
match
---
name: conn_id [13478,13485]
name: conn_id [13439,13446]
===
match
---
trailer [12645,12651]
trailer [12645,12651]
===
match
---
trailer [5209,5218]
trailer [5209,5218]
===
match
---
suite [7467,7813]
suite [7467,7813]
===
match
---
trailer [13416,13418]
trailer [13377,13379]
===
match
---
operator: ** [5353,5355]
operator: ** [5353,5355]
===
match
---
operator: = [3527,3528]
operator: = [3527,3528]
===
match
---
trailer [6685,6701]
trailer [6685,6701]
===
match
---
name: uri [5685,5688]
name: uri [5685,5688]
===
match
---
name: set_password [8425,8437]
name: set_password [8425,8437]
===
match
---
trailer [9156,9169]
trailer [9156,9169]
===
match
---
expr_stmt [8667,8706]
expr_stmt [8667,8706]
===
match
---
operator: = [10942,10943]
operator: = [10942,10943]
===
match
---
name: conn_id_param [10663,10676]
name: conn_id_param [10663,10676]
===
match
---
import_from [1282,1326]
import_from [1282,1326]
===
match
---
atom_expr [1950,1968]
atom_expr [1950,1968]
===
match
---
simple_stmt [11462,11685]
simple_stmt [11462,11685]
===
match
---
atom_expr [9231,9397]
atom_expr [9231,9397]
===
match
---
atom_expr [7648,7688]
atom_expr [7648,7688]
===
match
---
operator: , [5876,5877]
operator: , [5876,5877]
===
match
---
name: _password [7936,7945]
name: _password [7936,7945]
===
match
---
name: is_extra_encrypted [9077,9095]
name: is_extra_encrypted [9077,9095]
===
match
---
param [1525,1531]
param [1525,1531]
===
match
---
trailer [6321,6326]
trailer [6321,6326]
===
match
---
atom_expr [6128,6146]
atom_expr [6128,6146]
===
match
---
string: 'utf-8' [8636,8643]
string: 'utf-8' [8636,8643]
===
match
---
simple_stmt [8883,8968]
simple_stmt [8883,8968]
===
match
---
operator: = [3473,3474]
operator: = [3473,3474]
===
match
---
operator: , [12420,12421]
operator: , [12420,12421]
===
match
---
simple_stmt [7981,8003]
simple_stmt [7981,8003]
===
match
---
classdef [2250,13617]
classdef [2250,13578]
===
match
---
atom_expr [9683,9695]
atom_expr [9683,9695]
===
match
---
suite [1999,2228]
suite [1999,2228]
===
match
---
trailer [8934,8947]
trailer [8934,8947]
===
match
---
operator: = [6216,6217]
operator: = [6216,6217]
===
match
---
trailer [10301,10303]
trailer [10301,10303]
===
match
---
atom_expr [8922,8966]
atom_expr [8922,8966]
===
match
---
trailer [9441,9449]
trailer [9441,9449]
===
match
---
operator: = [2208,2209]
operator: = [2208,2209]
===
match
---
comparison [7204,7219]
comparison [7204,7219]
===
match
---
string: """         This method is deprecated. You can read each field individually or use the         default representation (`__repr__`).         """ [12057,12200]
string: """         This method is deprecated. You can read each field individually or use the         default representation (`__repr__`).         """ [12057,12200]
===
match
---
name: extra_dejson [11988,12000]
name: extra_dejson [11988,12000]
===
match
---
param [4193,4227]
param [4193,4227]
===
match
---
name: self [8401,8405]
name: self [8401,8405]
===
match
---
import_as_names [868,882]
import_as_names [868,882]
===
match
---
expr_stmt [5983,6017]
expr_stmt [5983,6017]
===
match
---
trailer [1959,1968]
trailer [1959,1968]
===
match
---
name: ImportError [10990,11001]
name: ImportError [10990,11001]
===
match
---
trailer [4438,4443]
trailer [4438,4443]
===
match
---
trailer [6709,6717]
trailer [6709,6717]
===
match
---
name: self [7800,7804]
name: self [7800,7804]
===
match
---
trailer [9460,9467]
trailer [9460,9467]
===
match
---
name: Column [3845,3851]
name: Column [3845,3851]
===
match
---
operator: , [1003,1004]
operator: , [1003,1004]
===
match
---
import_as_names [979,1017]
import_as_names [979,1017]
===
match
---
name: self [7950,7954]
name: self [7950,7954]
===
match
---
test [11969,12010]
test [11969,12010]
===
match
---
operator: } [11221,11222]
operator: } [11221,11222]
===
match
---
tfpdef [4113,4135]
tfpdef [4113,4135]
===
match
---
name: scheme [5720,5726]
name: scheme [5720,5726]
===
match
---
name: fernet [9435,9441]
name: fernet [9435,9441]
===
match
---
simple_stmt [12440,12745]
simple_stmt [12440,12745]
===
match
---
operator: > [7215,7216]
operator: > [7215,7216]
===
match
---
name: Text [4026,4030]
name: Text [4026,4030]
===
match
---
trailer [6111,6117]
trailer [6111,6117]
===
match
---
trailer [7348,7355]
trailer [7348,7355]
===
match
---
name: Integer [3505,3512]
name: Integer [3505,3512]
===
match
---
name: host [7108,7112]
name: host [7108,7112]
===
match
---
name: _password [3789,3798]
name: _password [3789,3798]
===
match
---
if_stmt [6865,6962]
if_stmt [6865,6962]
===
match
---
atom_expr [7864,7877]
atom_expr [7864,7877]
===
match
---
simple_stmt [9109,9131]
simple_stmt [9109,9131]
===
match
---
atom_expr [12616,12627]
atom_expr [12616,12627]
===
match
---
trailer [4783,5025]
trailer [4783,5025]
===
match
---
name: get_extra [10141,10150]
name: get_extra [10141,10150]
===
match
---
raise_stmt [13544,13616]
raise_stmt [13505,13577]
===
match
---
name: Optional [4465,4473]
name: Optional [4465,4473]
===
match
---
name: ProvidersManager [10704,10720]
name: ProvidersManager [10704,10720]
===
match
---
trailer [3504,3533]
trailer [3504,3533]
===
match
---
funcdef [8973,9533]
funcdef [8973,9533]
===
match
---
name: _parse_netloc_to_hostname [5938,5963]
name: _parse_netloc_to_hostname [5938,5963]
===
match
---
fstring_expr [6681,6728]
fstring_expr [6681,6728]
===
match
---
strings [12236,12362]
strings [12236,12362]
===
match
---
atom_expr [4393,4406]
atom_expr [4393,4406]
===
match
---
name: dumps [6575,6580]
name: dumps [6575,6580]
===
match
---
name: self [6686,6690]
name: self [6686,6690]
===
match
---
trailer [10106,10167]
trailer [10106,10167]
===
match
---
string: ":" [2125,2128]
string: ":" [2125,2128]
===
match
---
operator: = [4256,4257]
operator: = [4256,4257]
===
match
---
expr_stmt [3724,3752]
expr_stmt [3724,3752]
===
match
---
trailer [10720,10722]
trailer [10720,10722]
===
match
---
trailer [11190,11223]
trailer [11190,11223]
===
match
---
simple_stmt [8059,8293]
simple_stmt [8059,8293]
===
match
---
fstring_end: ' [7330,7331]
fstring_end: ' [7330,7331]
===
match
---
argument [11661,11673]
argument [11661,11673]
===
match
---
trailer [2173,2179]
trailer [2173,2179]
===
match
---
trailer [10864,10905]
trailer [10864,10905]
===
match
---
atom_expr [7931,7945]
atom_expr [7931,7945]
===
match
---
suite [7743,7813]
suite [7743,7813]
===
match
---
atom_expr [8890,8967]
atom_expr [8890,8967]
===
match
---
arglist [2180,2186]
arglist [2180,2186]
===
match
---
trailer [12597,12602]
trailer [12597,12602]
===
match
---
name: port [6322,6326]
name: port [6322,6326]
===
match
---
name: value [9655,9660]
name: value [9655,9660]
===
match
---
tfpdef [4309,4332]
tfpdef [4309,4332]
===
match
---
expr_stmt [3757,3784]
expr_stmt [3757,3784]
===
match
---
operator: * [1685,1686]
operator: * [1685,1686]
===
match
---
name: secrets_backend [13439,13454]
name: secrets_backend [13400,13415]
===
match
---
param [10195,10199]
param [10195,10199]
===
match
---
param [8444,8464]
param [8444,8464]
===
match
---
simple_stmt [13544,13617]
simple_stmt [13505,13578]
===
match
---
atom_expr [3772,3783]
atom_expr [3772,3783]
===
match
---
name: Optional [874,882]
name: Optional [874,882]
===
match
---
operator: = [8564,8565]
operator: = [8564,8565]
===
match
---
atom_expr [8312,8367]
atom_expr [8312,8367]
===
match
---
simple_stmt [5205,5230]
simple_stmt [5205,5230]
===
match
---
atom_expr [8401,8415]
atom_expr [8401,8415]
===
match
---
name: schema [12621,12627]
name: schema [12621,12627]
===
match
---
if_stmt [8535,8707]
if_stmt [8535,8707]
===
match
---
trailer [10155,10165]
trailer [10155,10165]
===
match
---
simple_stmt [8305,8368]
simple_stmt [8305,8368]
===
match
---
name: _password [8406,8415]
name: _password [8406,8415]
===
match
---
operator: } [7414,7415]
operator: } [7414,7415]
===
match
---
expr_stmt [6673,6732]
expr_stmt [6673,6732]
===
match
---
name: extra [5317,5322]
name: extra [5317,5322]
===
match
---
atom_expr [12209,12431]
atom_expr [12209,12431]
===
match
---
operator: = [5906,5907]
operator: = [5906,5907]
===
match
---
name: warnings [807,815]
name: warnings [807,815]
===
match
---
argument [3968,3980]
argument [3968,3980]
===
match
---
operator: , [986,987]
operator: , [986,987]
===
match
---
argument [6407,6429]
argument [6407,6429]
===
match
---
fstring_string: : [7253,7254]
fstring_string: : [7253,7254]
===
match
---
operator: , [4024,4025]
operator: , [4024,4025]
===
match
---
atom_expr [11894,11904]
atom_expr [11894,11904]
===
match
---
atom_expr [3670,3688]
atom_expr [3670,3688]
===
match
---
name: authority_block [6742,6757]
name: authority_block [6742,6757]
===
match
---
operator: = [5254,5255]
operator: = [5254,5255]
===
match
---
name: cls [8744,8747]
name: cls [8744,8747]
===
match
---
simple_stmt [7426,7444]
simple_stmt [7426,7444]
===
match
---
name: Optional [4206,4214]
name: Optional [4206,4214]
===
match
---
name: obj [12933,12936]
name: obj [12933,12936]
===
match
---
expr_stmt [1931,1975]
expr_stmt [1931,1975]
===
match
---
name: extra [7461,7466]
name: extra [7461,7466]
===
match
---
name: _extra [9061,9067]
name: _extra [9061,9067]
===
match
---
name: _password [8596,8605]
name: _password [8596,8605]
===
match
---
import_from [1018,1070]
import_from [1018,1070]
===
match
---
simple_stmt [5145,5162]
simple_stmt [5145,5162]
===
match
---
name: synonym [8890,8897]
name: synonym [8890,8897]
===
match
---
fstring_string: :// [6728,6731]
fstring_string: :// [6728,6731]
===
match
---
atom_expr [7800,7810]
atom_expr [7800,7810]
===
match
---
atom_expr [7320,7329]
atom_expr [7320,7329]
===
match
---
operator: = [10380,10381]
operator: = [10380,10381]
===
match
---
atom_expr [8608,8654]
atom_expr [8608,8654]
===
match
---
argument [10117,10166]
argument [10117,10166]
===
match
---
name: encrypt [9729,9736]
name: encrypt [9729,9736]
===
match
---
name: self [6488,6492]
name: self [6488,6492]
===
match
---
name: warn [1593,1597]
name: warn [1593,1597]
===
match
---
atom_expr [7456,7466]
atom_expr [7456,7466]
===
match
---
name: conn_id [4534,4541]
name: conn_id [4534,4541]
===
match
---
operator: = [6499,6500]
operator: = [6499,6500]
===
match
---
atom_expr [9193,9415]
atom_expr [9193,9415]
===
match
---
simple_stmt [13524,13536]
simple_stmt [13485,13497]
===
match
---
name: host_block [7301,7311]
name: host_block [7301,7311]
===
match
---
expr_stmt [3459,3487]
expr_stmt [3459,3487]
===
match
---
trailer [6506,6522]
trailer [6506,6522]
===
match
---
suite [6540,6588]
suite [6540,6588]
===
match
---
funcdef [8731,8968]
funcdef [8731,8968]
===
match
---
atom_expr [11932,11945]
atom_expr [11932,11945]
===
match
---
comparison [6447,6470]
comparison [6447,6470]
===
match
---
name: str [6614,6617]
name: str [6614,6617]
===
match
---
parameters [10194,10200]
parameters [10194,10200]
===
match
---
name: query [7720,7725]
name: query [7720,7725]
===
match
---
expr_stmt [10931,10974]
expr_stmt [10931,10974]
===
match
---
tfpdef [4272,4292]
tfpdef [4272,4292]
===
match
---
operator: += [7711,7713]
operator: += [7711,7713]
===
match
---
name: hostname [2165,2173]
name: hostname [2165,2173]
===
match
---
name: self [7622,7626]
name: self [7622,7626]
===
match
---
name: get_fernet [1316,1326]
name: get_fernet [1316,1326]
===
match
---
name: self [6605,6609]
name: self [6605,6609]
===
match
---
operator: = [10289,10290]
operator: = [10289,10290]
===
match
---
atom_expr [3845,3862]
atom_expr [3845,3862]
===
match
---
simple_stmt [4001,4034]
simple_stmt [4001,4034]
===
match
---
operator: = [5121,5122]
operator: = [5121,5122]
===
match
---
expr_stmt [2076,2113]
expr_stmt [2076,2113]
===
match
---
arglist [11046,11132]
arglist [11046,11132]
===
match
---
not_test [8018,8041]
not_test [8018,8041]
===
match
---
operator: + [6930,6931]
operator: + [6930,6931]
===
match
---
operator: , [12579,12580]
operator: , [12579,12580]
===
match
---
expr_stmt [3493,3533]
expr_stmt [3493,3533]
===
match
---
operator: = [3989,3990]
operator: = [3989,3990]
===
match
---
arglist [5478,5567]
arglist [5478,5567]
===
match
---
string: 'utf-8' [10418,10425]
string: 'utf-8' [10418,10425]
===
match
---
name: airflow [1387,1394]
name: airflow [1387,1394]
===
match
---
name: self [5205,5209]
name: self [5205,5209]
===
match
---
name: self [7320,7324]
name: self [7320,7324]
===
match
---
expr_stmt [3789,3833]
expr_stmt [3789,3833]
===
match
---
simple_stmt [10842,10906]
simple_stmt [10842,10906]
===
match
---
string: '?' [7714,7717]
string: '?' [7714,7717]
===
match
---
trailer [5590,5606]
trailer [5590,5606]
===
match
---
name: unquote [926,933]
name: unquote [926,933]
===
match
---
name: description [4193,4204]
name: description [4193,4204]
===
match
---
name: self [5926,5930]
name: self [5926,5930]
===
match
---
return_stmt [9514,9532]
return_stmt [9514,9532]
===
match
---
name: log_info [11286,11294]
name: log_info [11286,11294]
===
match
---
funcdef [11282,12022]
funcdef [11282,12022]
===
match
---
operator: , [933,934]
operator: , [933,934]
===
match
---
name: fernet [10382,10388]
name: fernet [10382,10388]
===
match
---
name: extra [9945,9950]
name: extra [9945,9950]
===
match
---
name: value [9558,9563]
name: value [9558,9563]
===
match
---
param [4113,4143]
param [4113,4143]
===
match
---
name: descriptor [10117,10127]
name: descriptor [10117,10127]
===
match
---
operator: = [9720,9721]
operator: = [9720,9721]
===
match
---
trailer [9759,9766]
trailer [9759,9766]
===
match
---
name: _extra [10534,10540]
name: _extra [10534,10540]
===
match
---
trailer [8693,8706]
trailer [8693,8706]
===
match
---
simple_stmt [12933,12962]
simple_stmt [12933,12962]
===
match
---
simple_stmt [11257,11277]
simple_stmt [11257,11277]
===
match
---
name: port [5287,5291]
name: port [5287,5291]
===
match
---
simple_stmt [10001,10084]
simple_stmt [10001,10084]
===
match
---
operator: = [4220,4221]
operator: = [4220,4221]
===
match
---
atom_expr [10464,10487]
atom_expr [10464,10487]
===
match
---
expr_stmt [10282,10303]
expr_stmt [10282,10303]
===
match
---
trailer [7460,7466]
trailer [7460,7466]
===
match
---
name: log [13062,13065]
name: log [13019,13022]
===
match
---
trailer [13065,13071]
trailer [13022,13032]
===
match
---
simple_stmt [12209,12432]
simple_stmt [12209,12432]
===
match
---
decorated [13153,13617]
decorated [13114,13578]
===
match
---
name: host [4236,4240]
name: host [4236,4240]
===
match
---
name: exceptions [1176,1186]
name: exceptions [1176,1186]
===
match
---
name: Column [3801,3807]
name: Column [3801,3807]
===
match
---
name: self [7784,7788]
name: self [7784,7788]
===
match
---
name: logging_mixin [1405,1418]
name: logging_mixin [1405,1418]
===
match
---
operator: = [3546,3547]
operator: = [3546,3547]
===
match
---
operator: , [10773,10774]
operator: , [10773,10774]
===
match
---
name: uri_parts [6128,6137]
name: uri_parts [6128,6137]
===
match
---
funcdef [9941,10168]
funcdef [9941,10168]
===
match
---
argument [8911,8966]
argument [8911,8966]
===
match
---
atom_expr [12570,12579]
atom_expr [12570,12579]
===
match
---
name: String [3772,3778]
name: String [3772,3778]
===
match
---
name: self [6938,6942]
name: self [6938,6942]
===
match
---
name: uri [6673,6676]
name: uri [6673,6676]
===
match
---
string: """         This method is deprecated. You can read each field individually or use the         default representation (`__repr__`).         """ [11310,11453]
string: """         This method is deprecated. You can read each field individually or use the         default representation (`__repr__`).         """ [11310,11453]
===
match
---
operator: { [11193,11194]
operator: { [11193,11194]
===
match
---
dotted_name [1287,1308]
dotted_name [1287,1308]
===
match
---
string: '' [6852,6854]
string: '' [6852,6854]
===
match
---
atom_expr [13550,13616]
atom_expr [13511,13577]
===
match
---
name: self [11264,11268]
name: self [11264,11268]
===
match
---
atom_expr [10944,10974]
atom_expr [10944,10974]
===
match
---
arglist [7146,7164]
arglist [7146,7164]
===
match
---
atom_expr [6488,6498]
atom_expr [6488,6498]
===
match
---
return_stmt [12440,12744]
return_stmt [12440,12744]
===
match
---
parameters [4051,4492]
parameters [4051,4492]
===
match
---
simple_stmt [1018,1071]
simple_stmt [1018,1071]
===
match
---
argument [7665,7687]
argument [7665,7687]
===
match
---
atom_expr [11846,11855]
atom_expr [11846,11855]
===
match
---
trailer [7523,7536]
trailer [7523,7536]
===
match
---
name: self [13114,13118]
name: self [13075,13079]
===
match
---
fstring [10865,10904]
fstring [10865,10904]
===
match
---
atom_expr [8242,8252]
atom_expr [8242,8252]
===
match
---
name: self [10315,10319]
name: self [10315,10319]
===
match
---
simple_stmt [12804,12860]
simple_stmt [12804,12860]
===
match
---
string: """Password. The value is decrypted/encrypted when reading/setting the value.""" [8794,8874]
string: """Password. The value is decrypted/encrypted when reading/setting the value.""" [8794,8874]
===
match
---
trailer [6047,6062]
trailer [6047,6062]
===
match
---
operator: -> [12787,12789]
operator: -> [12787,12789]
===
match
---
name: uri_parts [6249,6258]
name: uri_parts [6249,6258]
===
match
---
string: '' [1972,1974]
string: '' [1972,1974]
===
match
---
operator: = [3763,3764]
operator: = [3763,3764]
===
match
---
name: Column [3765,3771]
name: Column [3765,3771]
===
match
---
string: """This method is deprecated.""" [1547,1579]
string: """This method is deprecated.""" [1547,1579]
===
match
---
funcdef [1831,2248]
funcdef [1831,2248]
===
match
---
simple_stmt [3538,3600]
simple_stmt [3538,3600]
===
match
---
operator: > [6990,6991]
operator: > [6990,6991]
===
match
---
try_stmt [7480,7597]
try_stmt [7480,7597]
===
match
---
atom_expr [3733,3752]
atom_expr [3733,3752]
===
match
---
operator: , [4485,4486]
operator: , [4485,4486]
===
match
---
name: hostname [1960,1968]
name: hostname [1960,1968]
===
match
---
operator: = [12872,12873]
operator: = [12872,12873]
===
match
---
string: '-' [5873,5876]
string: '-' [5873,5876]
===
match
---
arglist [3959,3995]
arglist [3959,3995]
===
match
---
name: self [11797,11801]
name: self [11797,11801]
===
match
---
name: host [3693,3697]
name: host [3693,3697]
===
match
---
name: decode [8359,8365]
name: decode [8359,8365]
===
match
---
atom_expr [6380,6430]
atom_expr [6380,6430]
===
match
---
trailer [11936,11945]
trailer [11936,11945]
===
match
---
simple_stmt [6488,6523]
simple_stmt [6488,6523]
===
match
---
name: quote [7140,7145]
name: quote [7140,7145]
===
match
---
expr_stmt [4001,4033]
expr_stmt [4001,4033]
===
match
---
suite [10352,10437]
suite [10352,10437]
===
match
---
string: 'password' [3808,3818]
string: 'password' [3808,3818]
===
match
---
suite [13507,13536]
suite [13468,13497]
===
match
---
trailer [10417,10426]
trailer [10417,10426]
===
match
---
operator: ** [11191,11193]
operator: ** [11191,11193]
===
match
---
trailer [7518,7537]
trailer [7518,7537]
===
match
---
string: "(conn_type, host, login, password, schema, port or extra)." [4881,4941]
string: "(conn_type, host, login, password, schema, port or extra)." [4881,4941]
===
match
---
expr_stmt [5843,5882]
expr_stmt [5843,5882]
===
match
---
strings [11489,11615]
strings [11489,11615]
===
match
---
trailer [10722,10728]
trailer [10722,10728]
===
match
---
arglist [1685,1700]
arglist [1685,1700]
===
match
---
trailer [10540,10547]
trailer [10540,10547]
===
match
---
name: uri [5037,5040]
name: uri [5037,5040]
===
match
---
simple_stmt [5106,5133]
simple_stmt [5106,5133]
===
match
---
funcdef [1496,1702]
funcdef [1496,1702]
===
match
---
expr_stmt [5698,5726]
expr_stmt [5698,5726]
===
match
---
name: ensure_secrets_loaded [13395,13416]
name: ensure_secrets_loaded [13356,13377]
===
match
---
atom_expr [4279,4292]
atom_expr [4279,4292]
===
match
---
name: super [4502,4507]
name: super [4502,4507]
===
match
---
name: self [4529,4533]
name: self [4529,4533]
===
match
---
trailer [6235,6244]
trailer [6235,6244]
===
match
---
operator: -> [13221,13223]
operator: -> [13182,13184]
===
match
---
name: self [8987,8991]
name: self [8987,8991]
===
match
---
comparison [5813,5829]
comparison [5813,5829]
===
match
---
name: host [7151,7155]
name: host [7151,7155]
===
match
---
operator: , [8442,8443]
operator: , [8442,8443]
===
match
---
trailer [8930,8966]
trailer [8930,8966]
===
match
---
name: query [7612,7617]
name: query [7612,7617]
===
match
---
name: uri_parts [5999,6008]
name: uri_parts [5999,6008]
===
match
---
name: encode [10411,10417]
name: encode [10411,10417]
===
match
---
name: default [3982,3989]
name: default [3982,3989]
===
match
---
name: self [5054,5058]
name: self [5054,5058]
===
match
---
trailer [10528,10557]
trailer [10528,10557]
===
match
---
operator: } [7810,7811]
operator: } [7810,7811]
===
match
---
trailer [8645,8652]
trailer [8645,8652]
===
match
---
name: String [1005,1011]
name: String [1005,1011]
===
match
---
string: "Could not import %s when discovering %s %s" [11046,11090]
string: "Could not import %s when discovering %s %s" [11046,11090]
===
match
---
arglist [5873,5881]
arglist [5873,5881]
===
match
---
comparison [6774,6796]
comparison [6774,6796]
===
match
---
name: Boolean [979,986]
name: Boolean [979,986]
===
match
---
operator: = [5185,5186]
operator: = [5185,5186]
===
match
---
simple_stmt [13246,13364]
simple_stmt [13207,13325]
===
match
---
atom_expr [6338,6353]
atom_expr [6338,6353]
===
match
---
name: password [12684,12692]
name: password [12684,12692]
===
match
---
name: netloc [2029,2035]
name: netloc [2029,2035]
===
match
---
simple_stmt [5174,5193]
simple_stmt [5174,5193]
===
match
---
name: Integer [3852,3859]
name: Integer [3852,3859]
===
match
---
simple_stmt [3724,3753]
simple_stmt [3724,3753]
===
match
---
trailer [10338,10351]
trailer [10338,10351]
===
match
---
atom [4610,4747]
atom [4610,4747]
===
match
---
string: """Parse a URI string to get correct Hostname.""" [1877,1926]
string: """Parse a URI string to get correct Hostname.""" [1877,1926]
===
match
---
name: conn_type [10892,10901]
name: conn_type [10892,10901]
===
match
---
name: sqlalchemy [961,971]
name: sqlalchemy [961,971]
===
match
---
string: "Can't decrypt `extra` params for login={},\                     FERNET_KEY configuration is missing" [9231,9332]
string: "Can't decrypt `extra` params for login={},\                     FERNET_KEY configuration is missing" [9231,9332]
===
match
---
trailer [12222,12431]
trailer [12222,12431]
===
match
---
expr_stmt [5891,5917]
expr_stmt [5891,5917]
===
match
---
string: "XXXXXXXX" [11969,11979]
string: "XXXXXXXX" [11969,11979]
===
match
---
atom_expr [3505,3514]
atom_expr [3505,3514]
===
match
---
name: path [6009,6013]
name: path [6009,6013]
===
match
---
simple_stmt [3757,3785]
simple_stmt [3757,3785]
===
match
---
argument [3584,3598]
argument [3584,3598]
===
match
---
comp_op [6882,6888]
comp_op [6882,6888]
===
match
---
name: warnings [11015,11023]
name: warnings [11015,11023]
===
match
---
name: port [3838,3842]
name: port [3838,3842]
===
match
---
if_stmt [7341,7417]
if_stmt [7341,7417]
===
match
---
parameters [11241,11247]
parameters [11241,11247]
===
match
---
name: Optional [7864,7872]
name: Optional [7864,7872]
===
match
---
trailer [9525,9532]
trailer [9525,9532]
===
match
---
operator: , [11855,11856]
operator: , [11855,11856]
===
match
---
atom_expr [3765,3784]
atom_expr [3765,3784]
===
match
---
trailer [11023,11028]
trailer [11023,11028]
===
match
---
string: 'postgresql' [5751,5763]
string: 'postgresql' [5751,5763]
===
match
---
name: providers_manager [1340,1357]
name: providers_manager [1340,1357]
===
match
---
name: decode [10558,10564]
name: decode [10558,10564]
===
match
---
atom_expr [8949,8965]
atom_expr [8949,8965]
===
match
---
name: description [3656,3667]
name: description [3656,3667]
===
match
---
trailer [2110,2113]
trailer [2110,2113]
===
match
---
trailer [3554,3599]
trailer [3554,3599]
===
match
---
expr_stmt [6810,6855]
expr_stmt [6810,6855]
===
match
---
suite [9096,9488]
suite [9096,9488]
===
match
---
simple_stmt [3430,3454]
simple_stmt [3430,3454]
===
match
---
fstring [7315,7331]
fstring [7315,7331]
===
match
---
name: cls [8949,8952]
name: cls [8949,8952]
===
match
---
trailer [5930,5935]
trailer [5930,5935]
===
match
---
name: password [8735,8743]
name: password [8735,8743]
===
match
---
param [8987,8991]
param [8987,8991]
===
match
---
atom_expr [12593,12602]
atom_expr [12593,12602]
===
match
---
raise_stmt [9187,9415]
raise_stmt [9187,9415]
===
match
---
string: '?' [7767,7770]
string: '?' [7767,7770]
===
match
---
name: extra_dejson [7627,7639]
name: extra_dejson [7627,7639]
===
match
---
operator: += [7764,7766]
operator: += [7764,7766]
===
match
---
name: airflow [1332,1339]
name: airflow [1332,1339]
===
match
---
operator: } [13598,13599]
operator: } [13559,13560]
===
match
---
return_stmt [11693,12021]
return_stmt [11693,12021]
===
match
---
param [10585,10589]
param [10585,10589]
===
match
---
operator: , [11107,11108]
operator: , [11107,11108]
===
match
---
name: descriptor [8911,8921]
name: descriptor [8911,8921]
===
match
---
number: 5000 [3827,3831]
number: 5000 [3827,3831]
===
match
---
operator: + [7771,7772]
operator: + [7771,7772]
===
match
---
name: module_loading [1458,1472]
name: module_loading [1458,1472]
===
match
---
not_test [9146,9169]
not_test [9146,9169]
===
match
---
atom_expr [5891,5905]
atom_expr [5891,5905]
===
match
---
expr_stmt [7076,7091]
expr_stmt [7076,7091]
===
match
---
name: int [4402,4405]
name: int [4402,4405]
===
match
---
name: self [10448,10452]
name: self [10448,10452]
===
match
---
trailer [5074,5079]
trailer [5074,5079]
===
match
---
trailer [6127,6147]
trailer [6127,6147]
===
match
---
name: String [3707,3713]
name: String [3707,3713]
===
match
---
name: self [12593,12597]
name: self [12593,12597]
===
match
---
atom_expr [8623,8644]
atom_expr [8623,8644]
===
match
---
except_clause [12974,13001]
except_clause [12974,12996]
===
match
---
parameters [1860,1871]
parameters [1860,1871]
===
match
---
name: _extra [9526,9532]
name: _extra [9526,9532]
===
match
---
simple_stmt [9781,9827]
simple_stmt [9781,9827]
===
match
---
trailer [10410,10417]
trailer [10410,10417]
===
match
---
import_name [788,799]
import_name [788,799]
===
match
---
operator: , [3818,3819]
operator: , [3818,3819]
===
match
---
name: String [3623,3629]
name: String [3623,3629]
===
match
---
atom_expr [7393,7404]
atom_expr [7393,7404]
===
match
---
name: hostname [1931,1939]
name: hostname [1931,1939]
===
match
---
operator: , [1530,1531]
operator: , [1530,1531]
===
match
---
operator: , [4450,4451]
operator: , [4450,4451]
===
match
---
trailer [3888,3926]
trailer [3888,3926]
===
match
---
expr_stmt [2199,2227]
expr_stmt [2199,2227]
===
match
---
operator: = [8685,8686]
operator: = [8685,8686]
===
match
---
expr_stmt [3867,3926]
expr_stmt [3867,3926]
===
match
---
name: password [4309,4317]
name: password [4309,4317]
===
match
---
atom_expr [10529,10556]
atom_expr [10529,10556]
===
match
---
operator: = [4371,4372]
operator: = [4371,4372]
===
match
---
name: conn_type [5855,5864]
name: conn_type [5855,5864]
===
match
---
if_stmt [6335,6588]
if_stmt [6335,6588]
===
match
---
name: password [6283,6291]
name: password [6283,6291]
===
match
---
name: query [6465,6470]
name: query [6465,6470]
===
match
---
trailer [10136,10166]
trailer [10136,10166]
===
insert-node
---
name: Connection [2256,2266]
to
classdef [2250,13617]
at 0
===
insert-tree
---
arglist [2267,2285]
    name: Base [2267,2271]
    operator: , [2271,2272]
    name: LoggingMixin [2273,2285]
to
classdef [2250,13617]
at 1
===
insert-tree
---
simple_stmt [2340,3425]
    string: """     Placeholder to store information about different database instances     connection information. The idea here is that scripts use references to     database instances (conn_id) instead of hard coding hostname, logins and     passwords when using operators or hooks.      .. seealso::         For more information on how to use this class, see: :doc:`/howto/connection`      :param conn_id: The connection ID.     :type conn_id: str     :param conn_type: The connection type.     :type conn_type: str     :param description: The connection description.     :type description: str     :param host: The host.     :type host: str     :param login: The login.     :type login: str     :param password: The password.     :type password: str     :param schema: The schema.     :type schema: str     :param port: The port number.     :type port: int     :param extra: Extra metadata. Non-standard data such as private/SSH keys can be saved here. JSON         encoded object.     :type extra: str     :param uri: URI address describing connection parameters.     :type uri: str     """ [2340,3424]
to
suite [2335,13617]
at 0
===
update-node
---
name: error [13066,13071]
replace error by exception
===
delete-node
---
name: Connection [2256,2266]
===
===
delete-tree
---
arglist [2267,2285]
    name: Base [2267,2271]
    operator: , [2271,2272]
    name: LoggingMixin [2273,2285]
===
delete-tree
---
simple_stmt [2340,3425]
    string: """     Placeholder to store information about different database instances     connection information. The idea here is that scripts use references to     database instances (conn_id) instead of hard coding hostname, logins and     passwords when using operators or hooks.      .. seealso::         For more information on how to use this class, see: :doc:`/howto/connection`      :param conn_id: The connection ID.     :type conn_id: str     :param conn_type: The connection type.     :type conn_type: str     :param description: The connection description.     :type description: str     :param host: The host.     :type host: str     :param login: The login.     :type login: str     :param password: The password.     :type password: str     :param schema: The schema.     :type schema: str     :param port: The port number.     :type port: int     :param extra: Extra metadata. Non-standard data such as private/SSH keys can be saved here. JSON         encoded object.     :type extra: str     :param uri: URI address describing connection parameters.     :type uri: str     """ [2340,3424]
===
delete-node
---
name: e [13000,13001]
===
===
delete-tree
---
simple_stmt [13019,13041]
    atom_expr [13019,13040]
        name: self [13019,13023]
        trailer [13023,13027]
            name: log [13024,13027]
        trailer [13027,13037]
            name: exception [13028,13037]
        trailer [13037,13040]
            name: e [13038,13039]
