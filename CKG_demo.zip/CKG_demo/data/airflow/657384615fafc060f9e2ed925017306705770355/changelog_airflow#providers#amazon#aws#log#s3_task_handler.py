===
match
---
operator: + [5519,5520]
operator: + [5561,5562]
===
match
---
arglist [8126,8175]
arglist [8143,8192]
===
match
---
name: self [4581,4585]
name: self [4581,4585]
===
match
---
simple_stmt [3370,3436]
simple_stmt [3370,3436]
===
match
---
if_stmt [6808,6852]
if_stmt [6850,6894]
===
match
---
simple_stmt [2604,2638]
simple_stmt [2604,2638]
===
match
---
try_stmt [1787,2337]
try_stmt [1787,2337]
===
match
---
operator: , [2246,2247]
operator: , [2246,2247]
===
match
---
atom_expr [7552,7585]
atom_expr [7594,7627]
===
match
---
arglist [5480,5494]
arglist [5522,5536]
===
match
---
simple_stmt [5860,5912]
simple_stmt [5902,5954]
===
match
---
name: s3_read [7557,7564]
name: s3_read [7599,7606]
===
match
---
return_stmt [5332,5364]
return_stmt [5374,5406]
===
match
---
trailer [3416,3434]
trailer [3416,3434]
===
match
---
name: return_error [5222,5234]
name: return_error [5264,5276]
===
match
---
expr_stmt [3370,3435]
expr_stmt [3370,3435]
===
match
---
param [6904,6929]
param [6946,6971]
===
match
---
trailer [8111,8115]
trailer [8128,8132]
===
match
---
param [1339,1344]
param [1339,1344]
===
match
---
operator: , [5482,5483]
operator: , [5524,5525]
===
match
---
expr_stmt [7542,7585]
expr_stmt [7584,7627]
===
match
---
name: hook [5872,5876]
name: hook [5914,5918]
===
match
---
operator: } [4923,4924]
operator: } [4965,4966]
===
match
---
if_stmt [2787,2888]
if_stmt [2787,2888]
===
match
---
operator: , [1755,1756]
operator: , [1755,1756]
===
match
---
operator: , [8021,8022]
operator: , [8038,8039]
===
match
---
simple_stmt [1481,1514]
simple_stmt [1481,1514]
===
match
---
name: s3_log_exists [7490,7503]
name: s3_log_exists [7532,7545]
===
match
---
name: upload_on_close [3325,3340]
name: upload_on_close [3325,3340]
===
match
---
name: conf [948,952]
name: conf [948,952]
===
match
---
suite [1127,8177]
suite [1127,8194]
===
match
---
name: logfile [3662,3669]
name: logfile [3662,3669]
===
match
---
name: S3Hook [1881,1887]
name: S3Hook [1881,1887]
===
match
---
name: open [3643,3647]
name: open [3643,3647]
===
match
---
param [5564,5569]
param [5606,5611]
===
match
---
return_stmt [2325,2336]
return_stmt [2325,2336]
===
match
---
operator: , [2859,2860]
operator: , [2859,2860]
===
match
---
name: old_log [7542,7549]
name: old_log [7584,7591]
===
match
---
expr_stmt [3832,3850]
expr_stmt [3832,3850]
===
match
---
atom_expr [2829,2865]
atom_expr [2829,2865]
===
match
---
funcdef [6875,8177]
funcdef [6917,8194]
===
match
---
expr_stmt [1612,1639]
expr_stmt [1612,1639]
===
match
---
trailer [1427,1436]
trailer [1427,1436]
===
match
---
name: __init__ [1428,1436]
name: __init__ [1428,1436]
===
match
---
fstring [4856,4927]
fstring [4903,4969]
===
match
---
name: upload_on_close [2609,2624]
name: upload_on_close [2609,2624]
===
match
---
name: closed [3837,3843]
name: closed [3837,3843]
===
match
---
trailer [2583,2594]
trailer [2583,2594]
===
match
---
name: str [1406,1409]
name: str [1406,1409]
===
match
---
fstring_expr [4897,4909]
fstring_expr [4944,4956]
===
match
---
suite [7525,7654]
suite [7567,7696]
===
match
---
expr_stmt [2530,2595]
expr_stmt [2530,2595]
===
match
---
if_stmt [3313,3361]
if_stmt [3313,3361]
===
match
---
name: airflow [958,965]
name: airflow [958,965]
===
match
---
name: remote_base [1486,1497]
name: remote_base [1486,1497]
===
match
---
name: replace [7938,7945]
name: replace [7955,7962]
===
match
---
arglist [5210,5239]
arglist [5252,5281]
===
match
---
testlist [5339,5364]
testlist [5381,5406]
===
match
---
name: _render_filename [2560,2576]
name: _render_filename [2560,2576]
===
match
---
name: log_relative_path [2535,2552]
name: log_relative_path [2535,2552]
===
match
---
operator: = [6943,6944]
operator: = [6985,6986]
===
match
---
name: _render_filename [4514,4530]
name: _render_filename [4514,4530]
===
match
---
fstring_end: ' [4926,4927]
fstring_end: ' [4968,4969]
===
match
---
suite [2909,3851]
suite [2909,3851]
===
match
---
string: """Close and upload local log file to remote storage S3.""" [2918,2977]
string: """Close and upload local log file to remote storage S3.""" [2918,2977]
===
match
---
simple_stmt [953,1017]
simple_stmt [953,1017]
===
match
---
name: handler [2839,2846]
name: handler [2839,2846]
===
match
---
string: 'w' [2861,2864]
string: 'w' [2861,2864]
===
match
---
trailer [4580,4617]
trailer [4580,4617]
===
match
---
atom [1925,1947]
atom [1925,1947]
===
match
---
string: """         Returns the log found at the remote_log_location. Returns '' if no         logs are found or there is an error.          :param remote_log_location: the log's location in remote storage         :type remote_log_location: str (path)         :param return_error: if True, returns a string error message if an             error occurs. Otherwise returns '' when an error occurs.         :type return_error: bool         :return: the log found at the remote_log_location         """ [6005,6495]
string: """         Returns the log found at the remote_log_location. Returns '' if no         logs are found or there is an error.          :param remote_log_location: the log's location in remote storage         :type remote_log_location: str (path)         :param return_error: if True, returns a string error message if an             error occurs. Otherwise returns '' when an error occurs.         :type return_error: bool         :return: the log found at the remote_log_location         """ [6047,6537]
===
match
---
return_stmt [6841,6851]
return_stmt [6883,6893]
===
match
---
suite [802,845]
suite [802,845]
===
match
---
operator: , [8154,8155]
operator: , [8171,8172]
===
match
---
name: self [5564,5568]
name: self [5606,5610]
===
match
---
simple_stmt [869,913]
simple_stmt [869,913]
===
match
---
import_from [869,912]
import_from [869,912]
===
match
---
except_clause [6576,6601]
except_clause [6618,6643]
===
match
---
fstring [6653,6722]
fstring [6695,6764]
===
match
---
trailer [8115,8125]
trailer [8132,8142]
===
match
---
name: log_relative_path [1527,1544]
name: log_relative_path [1527,1544]
===
match
---
name: exception [4821,4830]
name: exception [4821,4830]
===
match
---
name: self [3395,3399]
name: self [3395,3399]
===
match
---
name: conf [7976,7980]
name: conf [7993,7997]
===
match
---
suite [7720,7811]
suite [7753,7828]
===
match
---
name: remote_log_location [5891,5910]
name: remote_log_location [5933,5952]
===
match
---
name: join [3390,3394]
name: join [3390,3394]
===
match
---
trailer [5479,5495]
trailer [5521,5537]
===
match
---
simple_stmt [4689,4733]
simple_stmt [4689,4733]
===
match
---
suite [3670,3708]
suite [3670,3708]
===
match
---
tfpdef [5961,5979]
tfpdef [6003,6021]
===
match
---
decorated [1645,2337]
decorated [1645,2337]
===
match
---
operator: , [5959,5960]
operator: , [6001,6002]
===
match
---
arglist [1746,1777]
arglist [1746,1777]
===
match
---
name: self [4702,4706]
name: self [4702,4706]
===
match
---
name: ti [2581,2583]
name: ti [2581,2583]
===
match
---
suite [3341,3361]
suite [3341,3361]
===
match
---
parameters [6887,6950]
parameters [6929,6992]
===
match
---
expr_stmt [1720,1778]
expr_stmt [1720,1778]
===
match
---
simple_stmt [5508,5541]
simple_stmt [5550,5583]
===
match
---
operator: , [2362,2363]
operator: , [2362,2363]
===
match
---
name: key [7897,7900]
name: key [7914,7917]
===
match
---
fstring_string: \n [5316,5318]
fstring_string: \n [5358,5360]
===
match
---
string: 'ENCRYPT_S3_LOGS' [8003,8020]
string: 'ENCRYPT_S3_LOGS' [8020,8037]
===
match
---
operator: = [2553,2554]
operator: = [2553,2554]
===
match
---
trailer [2794,2810]
trailer [2794,2810]
===
match
---
atom_expr [1558,1568]
atom_expr [1558,1568]
===
match
---
operator: } [4908,4909]
operator: } [4955,4956]
===
match
---
expr_stmt [5184,5240]
expr_stmt [5226,5282]
===
match
---
simple_stmt [1420,1473]
simple_stmt [1420,1473]
===
match
---
trailer [3474,3486]
trailer [3474,3486]
===
match
---
return_stmt [6521,6567]
return_stmt [6563,6609]
===
match
---
name: self [2834,2838]
name: self [2834,2838]
===
match
---
name: local_log [5521,5530]
name: local_log [5563,5572]
===
match
---
name: hook [6533,6537]
name: hook [6575,6579]
===
match
---
expr_stmt [6647,6722]
expr_stmt [6689,6764]
===
match
---
atom_expr [7608,7633]
atom_expr [7650,7675]
===
match
---
trailer [1526,1544]
trailer [1526,1544]
===
match
---
name: remote_loc [4555,4565]
name: remote_loc [4555,4565]
===
match
---
fstring_start: f' [5259,5261]
fstring_start: f' [5301,5303]
===
match
---
operator: } [1946,1947]
operator: } [1946,1947]
===
match
---
operator: , [6928,6929]
operator: , [6970,6971]
===
match
---
suite [6634,6852]
suite [6676,6894]
===
match
---
operator: { [1925,1926]
operator: { [1925,1926]
===
match
---
name: closed [3252,3258]
name: closed [3252,3258]
===
match
---
name: metadata [3888,3896]
name: metadata [3888,3896]
===
match
---
name: self [5197,5201]
name: self [5239,5243]
===
match
---
atom_expr [5466,5495]
atom_expr [5508,5537]
===
match
---
trailer [3251,3258]
trailer [3251,3258]
===
match
---
expr_stmt [1481,1513]
expr_stmt [1481,1513]
===
match
---
name: try_number [3876,3886]
name: try_number [3876,3886]
===
match
---
atom_expr [3412,3434]
atom_expr [3412,3434]
===
match
---
operator: = [1924,1925]
operator: = [1924,1925]
===
match
---
funcdef [5917,6870]
funcdef [5959,6912]
===
match
---
string: 'the S3 connection exists. Exception : "%s"' [2202,2246]
string: 'the S3 connection exists. Exception : "%s"' [2202,2246]
===
match
---
operator: , [1111,1112]
operator: , [1111,1112]
===
match
---
operator: , [5568,5569]
operator: , [5610,5611]
===
match
---
not_test [3316,3340]
not_test [3316,3340]
===
match
---
string: '\n' [7608,7612]
string: '\n' [7650,7654]
===
match
---
atom_expr [2581,2594]
atom_expr [2581,2594]
===
match
---
param [2903,2907]
param [2903,2907]
===
match
---
atom_expr [1584,1595]
atom_expr [1584,1595]
===
match
---
name: old_log [7637,7644]
name: old_log [7679,7686]
===
match
---
name: str [1382,1385]
name: str [1382,1385]
===
match
---
atom_expr [1481,1497]
atom_expr [1481,1497]
===
match
---
suite [8094,8177]
suite [8111,8194]
===
match
---
name: load_string [7847,7858]
name: load_string [7864,7875]
===
match
---
if_stmt [7471,7654]
if_stmt [7513,7696]
===
match
---
simple_stmt [3444,3512]
simple_stmt [3444,3512]
===
match
---
name: log_relative_path [4599,4616]
name: log_relative_path [4599,4616]
===
match
---
simple_stmt [5613,5852]
simple_stmt [5655,5894]
===
match
---
operator: = [7900,7901]
operator: = [7917,7918]
===
match
---
name: upload_on_close [2795,2810]
name: upload_on_close [2795,2810]
===
match
---
operator: = [5234,5235]
operator: = [5276,5277]
===
match
---
simple_stmt [6521,6568]
simple_stmt [6563,6610]
===
match
---
simple_stmt [7602,7654]
simple_stmt [7644,7696]
===
match
---
name: super [1420,1425]
name: super [1420,1425]
===
match
---
name: s3_read [5202,5209]
name: s3_read [5244,5251]
===
match
---
name: remote_log_location [7901,7920]
name: remote_log_location [7918,7937]
===
match
---
simple_stmt [3288,3304]
simple_stmt [3288,3304]
===
match
---
name: read_key [6538,6546]
name: read_key [6580,6588]
===
match
---
name: self [1339,1343]
name: self [1339,1343]
===
match
---
trailer [7991,8021]
trailer [8008,8038]
===
match
---
classdef [1076,8177]
classdef [1076,8194]
===
match
---
name: filename_template [1387,1404]
name: filename_template [1387,1404]
===
match
---
name: log [7602,7605]
name: log [7644,7647]
===
match
---
trailer [7617,7633]
trailer [7659,7675]
===
match
---
operator: -> [5989,5991]
operator: -> [6031,6033]
===
match
---
suite [3549,3751]
suite [3549,3751]
===
match
---
operator: = [3380,3381]
operator: = [3380,3381]
===
match
---
name: getboolean [7981,7991]
name: getboolean [7998,8008]
===
match
---
name: logfile [3693,3700]
name: logfile [3693,3700]
===
match
---
name: return_error [6811,6823]
name: return_error [6853,6865]
===
match
---
name: set_context [2346,2357]
name: set_context [2346,2357]
===
match
---
simple_stmt [7837,8037]
simple_stmt [7854,8054]
===
match
---
atom_expr [3523,3548]
atom_expr [3523,3548]
===
match
---
name: bool [5975,5979]
name: bool [6017,6021]
===
match
---
suite [5996,6870]
suite [6038,6912]
===
match
---
name: str [5591,5594]
name: str [5633,5636]
===
match
---
trailer [2576,2595]
trailer [2576,2595]
===
match
---
name: s3_write [3725,3733]
name: s3_write [3725,3733]
===
match
---
string: '*** Falling back to local log\n' [5398,5431]
string: '*** Falling back to local log\n' [5440,5473]
===
match
---
trailer [6532,6537]
trailer [6574,6579]
===
match
---
trailer [4720,4732]
trailer [4720,4732]
===
match
---
name: log [4817,4820]
name: log [4817,4820]
===
match
---
simple_stmt [1690,1712]
simple_stmt [1690,1712]
===
match
---
name: log [2029,2032]
name: log [2029,2032]
===
match
---
name: remote_conn_id [1888,1902]
name: remote_conn_id [1888,1902]
===
match
---
simple_stmt [5332,5365]
simple_stmt [5374,5407]
===
match
---
fstring_string: .\n [5301,5304]
fstring_string: .\n [5343,5346]
===
match
---
param [1367,1386]
param [1367,1386]
===
match
---
simple_stmt [1612,1640]
simple_stmt [1612,1640]
===
match
---
simple_stmt [2530,2596]
simple_stmt [2530,2596]
===
match
---
name: local_base [3400,3410]
name: local_base [3400,3410]
===
match
---
string: """Returns S3Hook.""" [1690,1711]
string: """Returns S3Hook.""" [1690,1711]
===
match
---
dotted_name [1809,1846]
dotted_name [1809,1846]
===
match
---
import_from [1017,1073]
import_from [1017,1073]
===
match
---
suite [4799,4928]
suite [4799,4970]
===
match
---
trailer [2042,2312]
trailer [2042,2312]
===
match
---
trailer [3384,3389]
trailer [3384,3389]
===
match
---
atom_expr [3320,3340]
atom_expr [3320,3340]
===
match
---
trailer [3301,3303]
trailer [3301,3303]
===
match
---
name: log_relative_path [4489,4506]
name: log_relative_path [4489,4506]
===
match
---
name: self [6735,6739]
name: self [6777,6781]
===
match
---
fstring_string:  with error:  [6701,6714]
fstring_string:  with error:  [6743,6756]
===
match
---
name: self [1584,1588]
name: self [1584,1588]
===
match
---
trailer [1562,1568]
trailer [1562,1568]
===
match
---
dotted_name [958,993]
dotted_name [958,993]
===
match
---
operator: , [3737,3738]
operator: , [3737,3738]
===
match
---
atom_expr [3693,3707]
atom_expr [3693,3707]
===
match
---
name: msg [6754,6757]
name: msg [6796,6799]
===
match
---
operator: { [5289,5290]
operator: { [5331,5332]
===
match
---
name: S3TaskHandler [1082,1095]
name: S3TaskHandler [1082,1095]
===
match
---
trailer [2384,2396]
trailer [2384,2396]
===
match
---
param [3888,3901]
param [3888,3901]
===
match
---
parameters [1674,1680]
parameters [1674,1680]
===
match
---
operator: = [3455,3456]
operator: = [3455,3456]
===
match
---
name: log_relative_path [3417,3434]
name: log_relative_path [3417,3434]
===
match
---
operator: = [4700,4701]
operator: = [4700,4701]
===
match
---
trailer [4706,4720]
trailer [4706,4720]
===
match
---
expr_stmt [1522,1549]
expr_stmt [1522,1549]
===
match
---
simple_stmt [3832,3851]
simple_stmt [3832,3851]
===
match
---
name: _read [5474,5479]
name: _read [5516,5521]
===
match
---
trailer [1741,1745]
trailer [1741,1745]
===
match
---
name: encrypt [7968,7975]
name: encrypt [7985,7992]
===
match
---
operator: , [2297,2298]
operator: , [2297,2298]
===
match
---
suite [5604,5912]
suite [5646,5954]
===
match
---
name: cached_property [897,912]
name: cached_property [897,912]
===
match
---
simple_stmt [4489,4547]
simple_stmt [4489,4547]
===
match
---
name: close [3296,3301]
name: close [3296,3301]
===
match
---
atom_expr [3395,3410]
atom_expr [3395,3410]
===
match
---
name: path [3460,3464]
name: path [3460,3464]
===
match
---
name: local_log [5444,5453]
name: local_log [5486,5495]
===
match
---
simple_stmt [6860,6870]
simple_stmt [6902,6912]
===
match
---
operator: , [7920,7921]
operator: , [7937,7938]
===
match
---
not_test [2627,2637]
not_test [2627,2637]
===
match
---
trailer [5876,5890]
trailer [5918,5932]
===
match
---
trailer [3530,3537]
trailer [3530,3537]
===
match
---
param [2358,2363]
param [2358,2363]
===
match
---
name: airflow [1022,1029]
name: airflow [1022,1029]
===
match
---
name: os [3382,3384]
name: os [3382,3384]
===
match
---
name: remote_loc [3444,3454]
name: remote_loc [3444,3454]
===
match
---
trailer [2534,2552]
trailer [2534,2552]
===
match
---
param [5935,5960]
param [5977,6002]
===
match
---
suite [5378,5541]
suite [5420,5583]
===
match
---
name: msg [6647,6650]
name: msg [6689,6692]
===
match
---
simple_stmt [2883,2888]
simple_stmt [2883,2888]
===
match
---
if_stmt [3520,3751]
if_stmt [3520,3751]
===
match
---
operator: @ [1645,1646]
operator: @ [1645,1646]
===
match
---
param [5961,5987]
param [6003,6029]
===
match
---
operator: = [4566,4567]
operator: = [4566,4567]
===
match
---
simple_stmt [7542,7586]
simple_stmt [7584,7628]
===
match
---
operator: = [7550,7551]
operator: = [7592,7593]
===
match
---
expr_stmt [2604,2637]
expr_stmt [2604,2637]
===
match
---
operator: , [6892,6893]
operator: , [6934,6935]
===
match
---
name: str [5992,5995]
name: str [6034,6037]
===
match
---
trailer [4570,4575]
trailer [4570,4575]
===
match
---
name: log [1036,1039]
name: log [1036,1039]
===
match
---
name: self [7485,7489]
name: self [7527,7531]
===
match
---
simple_stmt [1874,1949]
simple_stmt [1874,1949]
===
match
---
arglist [3395,3434]
arglist [3395,3434]
===
match
---
suite [3259,3279]
suite [3259,3279]
===
match
---
expr_stmt [4850,4927]
expr_stmt [4897,4969]
===
match
---
atom_expr [4702,4732]
atom_expr [4702,4732]
===
match
---
name: self [4812,4816]
name: self [4812,4816]
===
match
---
name: log [4850,4853]
name: log [4897,4900]
===
match
---
name: upload_on_close [1617,1632]
name: upload_on_close [1617,1632]
===
match
---
operator: } [5300,5301]
operator: } [5342,5343]
===
match
---
param [6930,6949]
param [6972,6991]
===
match
---
suite [3903,5541]
suite [3903,5583]
===
match
---
name: s3_write [6879,6887]
name: s3_write [6921,6929]
===
match
---
fstring_start: f' [6653,6655]
fstring_start: f' [6695,6697]
===
match
---
atom_expr [5867,5911]
atom_expr [5909,5953]
===
match
---
name: self [2903,2907]
name: self [2903,2907]
===
match
---
arglist [1437,1471]
arglist [1437,1471]
===
match
---
trailer [7858,8036]
trailer [7875,8053]
===
match
---
name: log [7876,7879]
name: log [7893,7896]
===
match
---
arglist [2834,2864]
arglist [2834,2864]
===
match
---
trailer [6753,6758]
trailer [6795,6800]
===
match
---
except_clause [8045,8061]
except_clause [8062,8078]
===
match
---
trailer [2833,2865]
trailer [2833,2865]
===
match
---
simple_stmt [1017,1074]
simple_stmt [1017,1074]
===
match
---
operator: , [6902,6903]
operator: , [6944,6945]
===
match
---
simple_stmt [1522,1550]
simple_stmt [1522,1550]
===
match
---
operator: , [4597,4598]
operator: , [4597,4598]
===
match
---
name: self [5867,5871]
name: self [5909,5913]
===
match
---
name: filename_template [1454,1471]
name: filename_template [1454,1471]
===
match
---
simple_stmt [6960,7446]
simple_stmt [7002,7488]
===
match
---
return_stmt [5508,5540]
return_stmt [5550,5582]
===
match
---
name: join [4576,4580]
name: join [4576,4580]
===
match
---
param [3876,3887]
param [3876,3887]
===
match
---
suite [2811,2888]
suite [2811,2888]
===
match
---
name: log [5339,5342]
name: log [5381,5384]
===
match
---
name: self [8107,8111]
name: self [8124,8128]
===
match
---
operator: = [5257,5258]
operator: = [5299,5300]
===
match
---
name: exception [8116,8125]
name: exception [8133,8142]
===
match
---
parameters [3865,3902]
parameters [3865,3902]
===
match
---
trailer [3389,3394]
trailer [3389,3394]
===
match
---
operator: { [6680,6681]
operator: { [6722,6723]
===
match
---
name: super [5466,5471]
name: super [5508,5513]
===
match
---
name: Exception [7669,7678]
name: Exception [7711,7720]
===
match
---
trailer [3733,3750]
trailer [3733,3750]
===
match
---
fstring_expr [6714,6721]
fstring_expr [6756,6763]
===
match
---
fstring_expr [5289,5301]
fstring_expr [5331,5343]
===
match
---
string: """         Writes the log to the remote_log_location. Fails silently if no hook         was created.          :param log: the log to write to the remote_log_location         :type log: str         :param remote_log_location: the log's location in remote storage         :type remote_log_location: str (path)         :param append: if False, any existing log file is overwritten. If True,             the new log is appended to any existing logs.         :type append: bool         """ [6960,7445]
string: """         Writes the log to the remote_log_location. Fails silently if no hook         was created.          :param log: the log to write to the remote_log_location         :type log: str         :param remote_log_location: the log's location in remote storage         :type remote_log_location: str (path)         :param append: if False, any existing log file is overwritten. If True,             the new log is appended to any existing logs.         :type append: bool         """ [7002,7487]
===
match
---
name: log_exists [4940,4950]
name: log_exists [4982,4992]
===
match
---
suite [4951,5365]
suite [4993,5407]
===
match
---
operator: = [1596,1597]
operator: = [1596,1597]
===
match
---
fstring_end: ' [6721,6722]
fstring_end: ' [6763,6764]
===
match
---
name: log [7738,7741]
name: log [7771,7774]
===
match
---
name: local_loc [3648,3657]
name: local_loc [3648,3657]
===
match
---
name: self [1481,1485]
name: self [1481,1485]
===
match
---
fstring_start: f' [4856,4858]
fstring_start: f' [4903,4905]
===
match
---
argument [1904,1947]
argument [1904,1947]
===
match
---
expr_stmt [3687,3707]
expr_stmt [3687,3707]
===
match
---
simple_stmt [8107,8177]
simple_stmt [8124,8194]
===
match
---
trailer [3394,3435]
trailer [3394,3435]
===
match
---
name: self [3320,3324]
name: self [3320,3324]
===
match
---
name: log [6740,6743]
name: log [6782,6785]
===
match
---
atom [5344,5364]
atom [5386,5406]
===
match
---
name: Exception [4748,4757]
name: Exception [4748,4757]
===
match
---
name: str [6925,6928]
name: str [6967,6970]
===
match
---
atom_expr [2377,2400]
atom_expr [2377,2400]
===
match
---
expr_stmt [4555,4617]
expr_stmt [4555,4617]
===
match
---
dictorsetmaker [5345,5363]
dictorsetmaker [5387,5405]
===
match
---
name: transfer_config_args [1904,1924]
name: transfer_config_args [1904,1924]
===
match
---
name: log [972,975]
name: log [972,975]
===
match
---
funcdef [1326,1640]
funcdef [1326,1640]
===
match
---
operator: , [3486,3487]
operator: , [3486,3487]
===
match
---
simple_stmt [3687,3708]
simple_stmt [3687,3708]
===
match
---
param [6894,6903]
param [6936,6945]
===
match
---
try_stmt [4672,4928]
try_stmt [4672,4970]
===
match
---
name: check_for_key [5877,5890]
name: check_for_key [5919,5932]
===
match
---
name: join [7613,7617]
name: join [7655,7659]
===
match
---
simple_stmt [4555,4618]
simple_stmt [4555,4618]
===
match
---
expr_stmt [7602,7653]
expr_stmt [7644,7695]
===
match
---
trailer [2559,2576]
trailer [2559,2576]
===
match
---
atom_expr [3457,3511]
atom_expr [3457,3511]
===
match
---
trailer [7564,7585]
trailer [7606,7627]
===
match
---
name: self [5929,5933]
name: self [5971,5975]
===
match
---
trailer [4830,4837]
trailer [4830,4884]
===
match
---
name: e [1977,1978]
name: e [1977,1978]
===
match
---
operator: { [4897,4898]
operator: { [4944,4945]
===
match
---
funcdef [5546,5912]
funcdef [5588,5954]
===
match
---
name: error [4761,4766]
name: error [4761,4766]
===
match
---
suite [7458,7654]
suite [7500,7696]
===
match
---
operator: = [6651,6652]
operator: = [6693,6694]
===
match
---
atom_expr [3488,3510]
atom_expr [3488,3510]
===
match
---
param [1387,1409]
param [1387,1409]
===
match
---
name: os [3523,3525]
name: os [3523,3525]
===
match
---
operator: = [4638,4639]
operator: = [4638,4639]
===
match
---
suite [2368,2888]
suite [2368,2888]
===
match
---
suite [1681,2337]
suite [1681,2337]
===
match
---
suite [4676,4733]
suite [4676,4733]
===
match
---
suite [2866,2888]
suite [2866,2888]
===
match
---
atom_expr [6528,6567]
atom_expr [6570,6609]
===
match
---
name: exception [2033,2042]
name: exception [2033,2042]
===
match
---
string: '' [1547,1549]
string: '' [1547,1549]
===
match
---
name: open [2829,2833]
name: open [2829,2833]
===
match
---
arglist [2577,2594]
arglist [2577,2594]
===
match
---
trailer [8125,8176]
trailer [8142,8193]
===
match
---
name: s3_log_exists [4707,4720]
name: s3_log_exists [4707,4720]
===
match
---
name: log [5253,5256]
name: log [5295,5298]
===
match
---
trailer [5471,5473]
trailer [5513,5515]
===
match
---
name: self [7837,7841]
name: self [7854,7858]
===
match
---
name: remote_conn_id [1720,1734]
name: remote_conn_id [1720,1734]
===
match
---
name: self [2790,2794]
name: self [2790,2794]
===
match
---
simple_stmt [1132,1321]
simple_stmt [1132,1321]
===
match
---
trailer [3647,3658]
trailer [3647,3658]
===
match
---
name: log [7628,7631]
name: log [7670,7673]
===
match
---
name: path [3385,3389]
name: path [3385,3389]
===
match
---
atom [7618,7632]
atom [7660,7674]
===
match
---
name: logging_mixin [1040,1053]
name: logging_mixin [1040,1053]
===
match
---
name: file_task_handler [976,993]
name: file_task_handler [976,993]
===
match
---
arglist [1096,1125]
arglist [1096,1125]
===
match
---
fstring_string: *** Reading remote log from  [5261,5289]
fstring_string: *** Reading remote log from  [5303,5331]
===
match
---
trailer [4816,4820]
trailer [4816,4820]
===
match
---
atom_expr [4581,4597]
atom_expr [4581,4597]
===
match
---
name: ti [2577,2579]
name: ti [2577,2579]
===
match
---
name: log_exists [4689,4699]
name: log_exists [4689,4699]
===
match
---
fstring_end: ' [5318,5319]
fstring_end: ' [5360,5361]
===
match
---
arglist [3734,3749]
arglist [3734,3749]
===
match
---
name: self [2604,2608]
name: self [2604,2608]
===
match
---
operator: = [7945,7946]
operator: = [7962,7963]
===
match
---
tfpdef [5935,5959]
tfpdef [5977,6001]
===
match
---
name: os [3457,3459]
name: os [3457,3459]
===
match
---
operator: = [3896,3897]
operator: = [3896,3897]
===
match
---
dotted_name [919,940]
dotted_name [919,940]
===
match
---
operator: , [2278,2279]
operator: , [2278,2279]
===
match
---
operator: , [3870,3871]
operator: , [3870,3871]
===
match
---
simple_stmt [5391,5432]
simple_stmt [5433,5474]
===
match
---
argument [7968,8021]
argument [7985,8038]
===
match
---
atom_expr [1420,1472]
atom_expr [1420,1472]
===
match
---
except_clause [845,863]
except_clause [845,863]
===
match
---
name: amazon [1827,1833]
name: amazon [1827,1833]
===
match
---
return_stmt [6860,6869]
return_stmt [6902,6911]
===
match
---
simple_stmt [2918,2978]
simple_stmt [2918,2978]
===
match
---
trailer [4575,4580]
trailer [4575,4580]
===
match
---
trailer [3836,3843]
trailer [3836,3843]
===
match
---
name: log [5515,5518]
name: log [5557,5560]
===
match
---
param [5929,5934]
param [5971,5976]
===
match
---
name: log_relative_path [3493,3510]
name: log_relative_path [3493,3510]
===
match
---
simple_stmt [807,845]
simple_stmt [807,845]
===
match
---
simple_stmt [1804,1861]
simple_stmt [1804,1861]
===
match
---
string: """         Check if remote_log_location exists in remote storage          :param remote_log_location: log's location in remote storage         :type remote_log_location: str         :return: True if location exists else False         """ [5613,5851]
string: """         Check if remote_log_location exists in remote storage          :param remote_log_location: log's location in remote storage         :type remote_log_location: str         :return: True if location exists else False         """ [5655,5893]
===
match
---
name: remote_base [3475,3486]
name: remote_base [3475,3486]
===
match
---
trailer [7556,7564]
trailer [7598,7606]
===
match
---
suite [7824,8037]
suite [7841,8054]
===
match
---
name: s3 [1844,1846]
name: s3 [1844,1846]
===
match
---
atom_expr [2555,2595]
atom_expr [2555,2595]
===
match
---
atom_expr [5197,5240]
atom_expr [5239,5282]
===
match
---
tfpdef [6930,6942]
tfpdef [6972,6984]
===
match
---
simple_stmt [914,953]
simple_stmt [914,953]
===
match
---
arglist [7876,8022]
arglist [7893,8039]
===
match
---
name: remote_loc [4898,4908]
name: remote_loc [4945,4955]
===
match
---
parameters [2902,2908]
parameters [2902,2908]
===
match
---
name: remote_log [5184,5194]
name: remote_log [5226,5236]
===
match
---
name: FileTaskHandler [1096,1111]
name: FileTaskHandler [1096,1111]
===
match
---
name: close [2897,2902]
name: close [2897,2902]
===
match
---
param [1675,1679]
param [1675,1679]
===
match
---
name: remote_loc [5210,5220]
name: remote_loc [5252,5262]
===
match
---
import_name [787,796]
import_name [787,796]
===
match
---
tfpdef [6904,6928]
tfpdef [6946,6970]
===
match
---
name: self [1612,1616]
name: self [1612,1616]
===
match
---
operator: , [7879,7880]
operator: , [7896,7897]
===
match
---
atom_expr [2834,2859]
atom_expr [2834,2859]
===
match
---
arglist [2060,2298]
arglist [2060,2298]
===
match
---
name: LoggingMixin [1061,1073]
name: LoggingMixin [1061,1073]
===
match
---
name: try_number [5484,5494]
name: try_number [5526,5536]
===
match
---
operator: = [1545,1546]
operator: = [1545,1546]
===
match
---
fstring_string: Could not read logs from  [6655,6680]
fstring_string: Could not read logs from  [6697,6722]
===
match
---
name: providers [1817,1826]
name: providers [1817,1826]
===
match
---
name: self [3470,3474]
name: self [3470,3474]
===
match
---
import_from [807,844]
import_from [807,844]
===
match
---
operator: { [6714,6715]
operator: { [6756,6757]
===
match
---
simple_stmt [6647,6723]
simple_stmt [6689,6765]
===
match
---
name: metadata [5532,5540]
name: metadata [5574,5582]
===
match
---
name: try_number [2584,2594]
name: try_number [2584,2594]
===
match
---
name: LoggingMixin [1113,1125]
name: LoggingMixin [1113,1125]
===
match
---
name: get [1742,1745]
name: get [1742,1745]
===
match
---
trailer [3459,3464]
trailer [3459,3464]
===
match
---
operator: } [6720,6721]
operator: } [6762,6763]
===
match
---
name: log [4654,4657]
name: log [4654,4657]
===
match
---
expr_stmt [4627,4645]
expr_stmt [4627,4645]
===
match
---
simple_stmt [4850,4928]
simple_stmt [4897,4970]
===
match
---
if_stmt [4937,5541]
if_stmt [4979,5583]
===
match
---
name: log [3687,3690]
name: log [3687,3690]
===
match
---
trailer [7841,7846]
trailer [7858,7863]
===
match
---
trailer [2028,2032]
trailer [2028,2032]
===
match
---
atom_expr [3382,3435]
atom_expr [3382,3435]
===
match
---
name: s3_log_folder [1367,1380]
name: s3_log_folder [1367,1380]
===
match
---
name: self [3247,3251]
name: self [3247,3251]
===
match
---
trailer [3295,3301]
trailer [3295,3301]
===
match
---
atom_expr [1522,1544]
atom_expr [1522,1544]
===
match
---
name: ImportError [852,863]
name: ImportError [852,863]
===
match
---
simple_stmt [1584,1604]
simple_stmt [1584,1604]
===
match
---
name: local_loc [3538,3547]
name: local_loc [3538,3547]
===
match
---
operator: , [5530,5531]
operator: , [5572,5573]
===
match
---
simple_stmt [5184,5241]
simple_stmt [5226,5283]
===
match
---
operator: , [5453,5454]
operator: , [5495,5496]
===
match
---
trailer [3700,3705]
trailer [3700,3705]
===
match
---
name: configuration [927,940]
name: configuration [927,940]
===
match
---
except_clause [7662,7687]
except_clause [7704,7720]
===
match
---
name: utils [1030,1035]
name: utils [1030,1035]
===
match
---
suite [6951,8177]
suite [6993,8194]
===
match
---
name: conf [1737,1741]
name: conf [1737,1741]
===
match
---
import_from [1804,1860]
import_from [1804,1860]
===
match
---
name: self [2555,2559]
name: self [2555,2559]
===
match
---
atom_expr [3247,3258]
atom_expr [3247,3258]
===
match
---
param [1345,1366]
param [1345,1366]
===
match
---
tfpdef [1367,1385]
tfpdef [1367,1385]
===
match
---
operator: = [1735,1736]
operator: = [1735,1736]
===
match
---
string: """         Read logs of given task instance and try_number from S3 remote storage.         If failed, read the log from task instance host machine.          :param ti: task instance object         :param try_number: task instance try_number to read logs from         :param metadata: log metadata,                          can be used for steaming log reading and auto-tailing.         """ [3912,4302]
string: """         Read logs of given task instance and try_number from S3 remote storage.         If failed, read the log from task instance host machine.          :param ti: task instance object         :param try_number: task instance try_number to read logs from         :param metadata: log metadata,                          can be used for steaming log reading and auto-tailing.         """ [3912,4302]
===
match
---
string: """     S3TaskHandler is a python log handler that handles and reads     task instance logs. It extends airflow FileTaskHandler and     uploads to and reads from S3 remote storage.     """ [1132,1320]
string: """     S3TaskHandler is a python log handler that handles and reads     task instance logs. It extends airflow FileTaskHandler and     uploads to and reads from S3 remote storage.     """ [1132,1320]
===
match
---
name: str [5956,5959]
name: str [5998,6001]
===
match
---
name: airflow [1809,1816]
name: airflow [1809,1816]
===
match
---
name: self [6528,6532]
name: self [6570,6574]
===
match
---
operator: = [7606,7607]
operator: = [7648,7649]
===
match
---
atom_expr [7733,7810]
atom_expr [7766,7827]
===
match
---
name: remote_log_location [5570,5589]
name: remote_log_location [5612,5631]
===
match
---
name: bool [5599,5603]
name: bool [5641,5645]
===
match
---
expr_stmt [1558,1575]
expr_stmt [1558,1575]
===
match
---
trailer [7737,7741]
trailer [7770,7774]
===
match
---
name: old_log [7619,7626]
name: old_log [7661,7668]
===
match
---
name: cached_property [874,889]
name: cached_property [874,889]
===
match
---
atom_expr [7485,7524]
atom_expr [7527,7566]
===
match
---
name: self [1675,1679]
name: self [1675,1679]
===
match
---
operator: , [7950,7951]
operator: , [7967,7968]
===
match
---
dotted_name [1022,1053]
dotted_name [1022,1053]
===
match
---
name: self [6888,6892]
name: self [6930,6934]
===
match
---
test [7608,7653]
test [7650,7695]
===
match
---
expr_stmt [3444,3511]
expr_stmt [3444,3511]
===
match
---
name: log [3734,3737]
name: log [3734,3737]
===
match
---
name: self [3832,3836]
name: self [3832,3836]
===
match
---
name: closed [1589,1595]
name: closed [1589,1595]
===
match
---
trailer [5871,5876]
trailer [5913,5918]
===
match
---
operator: } [5315,5316]
operator: } [5357,5358]
===
match
---
operator: , [2579,2580]
operator: , [2579,2580]
===
match
---
simple_stmt [6841,6852]
simple_stmt [6883,6894]
===
match
---
argument [7897,7920]
argument [7914,7937]
===
match
---
name: remote_log_location [6547,6566]
name: remote_log_location [6589,6608]
===
match
---
operator: = [7975,7976]
operator: = [7992,7993]
===
match
---
name: append [7474,7480]
name: append [7516,7522]
===
match
---
name: hooks [1838,1843]
name: hooks [1838,1843]
===
match
---
trailer [4820,4830]
trailer [4820,4830]
===
match
---
param [3866,3871]
param [3866,3871]
===
match
---
operator: = [4507,4508]
operator: = [4507,4508]
===
match
---
decorator [1645,1662]
decorator [1645,1662]
===
match
---
name: str [1362,1365]
name: str [1362,1365]
===
match
---
simple_stmt [4812,4838]
simple_stmt [4812,4885]
===
match
---
name: _hook [1563,1568]
name: _hook [1563,1568]
===
match
---
name: remote_base [4586,4597]
name: remote_base [4586,4597]
===
match
---
trailer [7980,7991]
trailer [7997,8008]
===
match
---
operator: } [5363,5364]
operator: } [5405,5406]
===
match
---
name: raw [2634,2637]
name: raw [2634,2637]
===
match
---
trailer [6537,6546]
trailer [6579,6588]
===
match
---
atom_expr [4509,4546]
atom_expr [4509,4546]
===
match
---
operator: , [1343,1344]
operator: , [1343,1344]
===
match
---
name: local_loc [3370,3379]
name: local_loc [3370,3379]
===
match
---
tfpdef [6894,6902]
tfpdef [6936,6944]
===
match
---
operator: , [8001,8002]
operator: , [8018,8019]
===
match
---
simple_stmt [2024,2313]
simple_stmt [2024,2313]
===
match
---
name: ti [2631,2633]
name: ti [2631,2633]
===
match
---
simple_stmt [6735,6759]
simple_stmt [6777,6801]
===
match
---
suite [6824,6852]
suite [6866,6894]
===
match
---
name: super [3288,3293]
name: super [3288,3293]
===
match
---
name: airflow [919,926]
name: airflow [919,926]
===
match
---
operator: = [1498,1499]
operator: = [1498,1499]
===
match
---
testlist_comp [7619,7631]
testlist_comp [7661,7673]
===
match
---
fstring_expr [5304,5316]
fstring_expr [5346,5358]
===
match
---
name: ti [4531,4533]
name: ti [4531,4533]
===
match
---
name: remote_loc [4721,4731]
name: remote_loc [4721,4731]
===
match
---
name: try_number [4535,4545]
name: try_number [4535,4545]
===
match
---
name: os [4568,4570]
name: os [4568,4570]
===
match
---
simple_stmt [3720,3751]
simple_stmt [3720,3751]
===
match
---
trailer [6546,6567]
trailer [6588,6609]
===
match
---
trailer [2838,2846]
trailer [2838,2846]
===
match
---
tfpdef [5570,5594]
tfpdef [5612,5636]
===
match
---
name: remote_log_location [6904,6923]
name: remote_log_location [6946,6965]
===
match
---
operator: -> [5596,5598]
operator: -> [5638,5640]
===
match
---
simple_stmt [3354,3361]
simple_stmt [3354,3361]
===
match
---
simple_stmt [1558,1576]
simple_stmt [1558,1576]
===
match
---
expr_stmt [5391,5431]
expr_stmt [5433,5473]
===
match
---
operator: , [3410,3411]
operator: , [3410,3411]
===
match
---
file_input [787,8177]
file_input [787,8194]
===
match
---
simple_stmt [2377,2401]
simple_stmt [2377,2401]
===
match
---
name: base_log_folder [1437,1452]
name: base_log_folder [1437,1452]
===
match
---
simple_stmt [4627,4646]
simple_stmt [4627,4646]
===
match
---
atom_expr [3288,3303]
atom_expr [3288,3303]
===
match
---
string: 'logging' [7992,8001]
string: 'logging' [8009,8018]
===
match
---
name: super [2377,2382]
name: super [2377,2382]
===
match
---
funcdef [2342,2888]
funcdef [2342,2888]
===
match
---
atom_expr [7837,8036]
atom_expr [7854,8053]
===
match
---
name: ti [2397,2399]
name: ti [2397,2399]
===
match
---
string: 'Please make sure that airflow[aws] is installed and ' [2131,2185]
string: 'Please make sure that airflow[aws] is installed and ' [2131,2185]
===
match
---
funcdef [1666,2337]
funcdef [1666,2337]
===
match
---
trailer [1436,1472]
trailer [1436,1472]
===
match
---
simple_stmt [3272,3279]
simple_stmt [3272,3279]
===
match
---
try_stmt [7454,7811]
try_stmt [7496,7828]
===
match
---
expr_stmt [5253,5319]
expr_stmt [5295,5361]
===
match
---
argument [7938,7950]
argument [7955,7967]
===
match
---
simple_stmt [2325,2337]
simple_stmt [2325,2337]
===
match
---
simple_stmt [787,797]
simple_stmt [787,797]
===
match
---
suite [6508,6568]
suite [6550,6610]
===
match
---
atom_expr [2604,2624]
atom_expr [2604,2624]
===
match
---
atom_expr [8107,8176]
atom_expr [8124,8193]
===
match
---
trailer [2608,2624]
trailer [2608,2624]
===
match
---
name: error [4831,4836]
name: remote_loc [4873,4883]
===
match
---
with_stmt [3638,3708]
with_stmt [3638,3708]
===
match
---
name: path [4571,4575]
name: path [4571,4575]
===
match
---
trailer [3705,3707]
trailer [3705,3707]
===
match
---
fstring_string: .\n [4909,4912]
fstring_string: .\n [4956,4959]
===
match
---
simple_stmt [1720,1779]
simple_stmt [1720,1779]
===
match
---
simple_stmt [4654,4663]
simple_stmt [4654,4663]
===
match
---
trailer [4513,4530]
trailer [4513,4530]
===
match
---
operator: { [5344,5345]
operator: { [5386,5387]
===
match
---
atom_expr [1737,1778]
atom_expr [1737,1778]
===
match
---
atom_expr [7976,8021]
atom_expr [7993,8038]
===
match
---
trailer [7612,7617]
trailer [7654,7659]
===
match
---
trailer [2396,2400]
trailer [2396,2400]
===
match
---
if_stmt [3244,3279]
if_stmt [3244,3279]
===
match
---
name: self [3412,3416]
name: self [3412,3416]
===
match
---
trailer [3469,3511]
trailer [3469,3511]
===
match
---
simple_stmt [6005,6496]
simple_stmt [6047,6538]
===
match
---
fstring_string: \n [4924,4926]
fstring_string: \n [4966,4968]
===
match
---
trailer [7489,7503]
trailer [7531,7545]
===
match
---
arglist [4581,4616]
arglist [4581,4616]
===
match
---
atom_expr [6735,6758]
atom_expr [6777,6800]
===
match
---
name: log_exists [4627,4637]
name: log_exists [4627,4637]
===
match
---
atom_expr [2530,2552]
atom_expr [2530,2552]
===
match
---
name: remote_log_location [5935,5954]
name: remote_log_location [5977,5996]
===
match
---
try_stmt [7820,8177]
try_stmt [7837,8194]
===
match
---
trailer [2382,2384]
trailer [2382,2384]
===
match
---
operator: = [1569,1570]
operator: = [1569,1570]
===
match
---
trailer [3492,3510]
trailer [3492,3510]
===
match
---
atom_expr [3832,3843]
atom_expr [3832,3843]
===
match
---
name: base_log_folder [1345,1360]
name: base_log_folder [1345,1360]
===
match
---
trailer [6743,6753]
trailer [6785,6795]
===
match
---
name: s3_log_folder [1500,1513]
name: s3_log_folder [1500,1513]
===
match
---
simple_stmt [5253,5320]
simple_stmt [5295,5362]
===
match
---
funcdef [2893,3851]
funcdef [2893,3851]
===
match
---
name: remote_loc [3739,3749]
name: remote_loc [3739,3749]
===
match
---
name: s3_read [5921,5928]
name: s3_read [5963,5970]
===
match
---
name: remote_log_location [7504,7523]
name: remote_log_location [7546,7565]
===
match
---
simple_stmt [7733,7811]
simple_stmt [7766,7828]
===
match
---
atom_expr [3643,3658]
atom_expr [3643,3658]
===
match
---
fstring_expr [4912,4924]
fstring_expr [4959,4966]
===
match
---
try_stmt [798,913]
try_stmt [798,913]
===
match
---
trailer [3324,3340]
trailer [3324,3340]
===
match
---
name: error [6715,6720]
name: error [6757,6762]
===
match
---
atom_expr [3720,3750]
atom_expr [3720,3750]
===
match
---
arglist [3470,3510]
arglist [3470,3510]
===
match
---
name: set_context [2385,2396]
name: set_context [2385,2396]
===
match
---
trailer [3537,3548]
trailer [3537,3548]
===
match
---
string: "use_threads" [1926,1939]
string: "use_threads" [1926,1939]
===
match
---
name: functools [812,821]
name: functools [812,821]
===
match
---
atom_expr [2631,2637]
atom_expr [2631,2637]
===
match
---
name: self [7552,7556]
name: self [7594,7598]
===
match
---
name: aws [1834,1837]
name: aws [1834,1837]
===
match
---
trailer [6739,6743]
trailer [6781,6785]
===
match
---
name: return_error [5961,5973]
name: return_error [6003,6015]
===
match
---
import_from [953,1016]
import_from [953,1016]
===
match
---
name: self [3720,3724]
name: self [3720,3724]
===
match
---
name: bool [6938,6942]
name: bool [6980,6984]
===
match
---
name: remote_log [5305,5315]
name: remote_log [5347,5357]
===
match
---
and_test [7474,7524]
and_test [7516,7566]
===
match
---
arglist [7992,8020]
arglist [8009,8037]
===
match
---
name: utils [966,971]
name: utils [966,971]
===
match
---
trailer [2633,2637]
trailer [2633,2637]
===
match
---
trailer [1425,1427]
trailer [1425,1427]
===
match
---
strings [2060,2246]
strings [2060,2246]
===
match
---
name: FileTaskHandler [1001,1016]
name: FileTaskHandler [1001,1016]
===
match
---
parameters [2357,2367]
parameters [2357,2367]
===
match
---
with_stmt [2824,2888]
with_stmt [2824,2888]
===
match
---
operator: } [6700,6701]
operator: } [6742,6743]
===
match
---
simple_stmt [5444,5496]
simple_stmt [5486,5538]
===
match
---
operator: = [4854,4855]
operator: = [4901,4902]
===
match
---
name: metadata [5455,5463]
name: metadata [5497,5505]
===
match
---
parameters [5928,5988]
parameters [5970,6030]
===
match
---
name: Exception [6583,6592]
name: Exception [6625,6634]
===
match
---
atom_expr [3470,3486]
atom_expr [3470,3486]
===
match
---
operator: , [7626,7627]
operator: , [7668,7669]
===
match
---
expr_stmt [4654,4662]
expr_stmt [4654,4662]
===
match
---
arglist [4531,4545]
arglist [4531,4545]
===
match
---
trailer [7741,7751]
trailer [7774,7784]
===
match
---
atom_expr [4812,4837]
atom_expr [4812,4884]
===
match
---
string: 'REMOTE_LOG_CONN_ID' [1757,1777]
string: 'REMOTE_LOG_CONN_ID' [1757,1777]
===
match
---
suite [2011,2337]
suite [2011,2337]
===
match
---
arglist [1888,1947]
arglist [1888,1947]
===
match
---
fstring_expr [6680,6701]
fstring_expr [6722,6743]
===
match
---
trailer [4585,4597]
trailer [4585,4597]
===
match
---
trailer [3525,3530]
trailer [3525,3530]
===
match
---
trailer [1616,1632]
trailer [1616,1632]
===
match
---
trailer [7503,7524]
trailer [7545,7566]
===
match
---
fstring_string: *** Failed to verify remote log exists  [4858,4897]
fstring_string: *** Failed to verify remote log exists  [4905,4944]
===
match
---
name: error [4917,4922]
name: error [4960,4965]
===
match
---
testlist_star_expr [5444,5463]
testlist_star_expr [5486,5505]
===
match
---
string: "" [4660,4662]
string: "" [4660,4662]
===
match
---
suite [1791,1949]
suite [1791,1949]
===
match
---
param [2364,2366]
param [2364,2366]
===
match
---
atom_expr [2024,2312]
atom_expr [2024,2312]
===
match
---
name: __init__ [1330,1338]
name: __init__ [1330,1338]
===
match
---
atom_expr [1612,1632]
atom_expr [1612,1632]
===
match
---
string: 'Could not write logs to %s' [8126,8154]
string: 'Could not write logs to %s' [8143,8171]
===
match
---
operator: , [5342,5343]
operator: , [5384,5385]
===
match
---
string: 'Could not verify previous log to append: %s' [7752,7797]
string: 'Could not verify previous log to append' [7785,7826]
===
match
---
expr_stmt [4689,4732]
expr_stmt [4689,4732]
===
match
---
import_from [914,952]
import_from [914,952]
===
match
---
name: remote_loc [5290,5300]
name: remote_loc [5332,5342]
===
match
---
parameters [5563,5595]
parameters [5605,5637]
===
match
---
trailer [1745,1778]
trailer [1745,1778]
===
match
---
name: s3_log_exists [5550,5563]
name: s3_log_exists [5592,5605]
===
match
---
param [3872,3875]
param [3872,3875]
===
match
---
name: self [1522,1526]
name: self [1522,1526]
===
match
---
name: exists [3531,3537]
name: exists [3531,3537]
===
match
---
name: baseFilename [2847,2859]
name: baseFilename [2847,2859]
===
match
---
name: hook [1670,1674]
name: hook [1670,1674]
===
match
---
name: read [3701,3705]
name: read [3701,3705]
===
match
---
name: ti [2364,2366]
name: ti [2364,2366]
===
match
---
suite [1411,1640]
suite [1411,1640]
===
match
---
name: msg [6848,6851]
name: msg [6890,6893]
===
match
---
except_clause [1957,1978]
except_clause [1957,1978]
===
match
---
trailer [5473,5479]
trailer [5515,5521]
===
match
---
operator: = [1633,1634]
operator: = [1633,1634]
===
match
---
param [6888,6893]
param [6930,6935]
===
match
---
name: str [6899,6902]
name: str [6941,6944]
===
match
---
parameters [1338,1410]
parameters [1338,1410]
===
match
---
name: self [2358,2362]
name: self [2358,2362]
===
match
---
name: e [2296,2297]
name: e [2296,2297]
===
match
---
operator: = [4658,4659]
operator: = [4658,4659]
===
match
---
simple_stmt [3912,4303]
simple_stmt [3912,4303]
===
match
---
atom_expr [2790,2810]
atom_expr [2790,2810]
===
match
---
with_item [3643,3669]
with_item [3643,3669]
===
match
---
name: S3Hook [1854,1860]
name: S3Hook [1854,1860]
===
match
---
trailer [2846,2859]
trailer [2846,2859]
===
match
---
atom_expr [1881,1948]
atom_expr [1881,1948]
===
match
---
name: _read [3860,3865]
name: _read [3860,3865]
===
match
---
trailer [1588,1595]
trailer [1588,1595]
===
match
---
trailer [4530,4546]
trailer [4530,4546]
===
match
---
string: 'end_of_log' [5345,5357]
string: 'end_of_log' [5387,5399]
===
match
---
expr_stmt [4489,4546]
expr_stmt [4489,4546]
===
match
---
operator: , [3874,3875]
operator: , [3874,3875]
===
match
---
operator: = [3844,3845]
operator: = [3844,3845]
===
match
---
name: log [8112,8115]
name: log [8129,8132]
===
match
---
tfpdef [1387,1409]
tfpdef [1387,1409]
===
match
---
trailer [3724,3733]
trailer [3724,3733]
===
match
---
testlist [5515,5540]
testlist [5557,5582]
===
match
---
operator: , [1452,1453]
operator: , [1452,1453]
===
match
---
except_clause [4741,4766]
except_clause [4741,4766]
===
match
---
operator: = [2625,2626]
operator: = [2625,2626]
===
match
---
try_stmt [6504,6852]
try_stmt [6546,6894]
===
match
---
trailer [7751,7810]
trailer [7784,7827]
===
match
---
trailer [3399,3410]
trailer [3399,3410]
===
match
---
return_stmt [5860,5911]
return_stmt [5902,5953]
===
match
---
operator: { [5304,5305]
operator: { [5346,5347]
===
match
---
name: error [6596,6601]
name: error [6638,6643]
===
match
---
atom_expr [4568,4617]
atom_expr [4568,4617]
===
match
---
name: remote_conn_id [2264,2278]
name: remote_conn_id [2264,2278]
===
match
---
expr_stmt [1584,1603]
expr_stmt [1584,1603]
===
match
---
operator: = [3691,3692]
operator: = [3691,3692]
===
match
---
tfpdef [1345,1365]
tfpdef [1345,1365]
===
match
---
operator: { [4912,4913]
operator: { [4959,4960]
===
match
---
trailer [5890,5911]
trailer [5932,5953]
===
match
---
string: '' [6867,6869]
string: '' [6909,6911]
===
match
---
operator: , [1365,1366]
operator: , [1365,1366]
===
match
---
name: self [1558,1562]
name: self [1558,1562]
===
match
---
arith_expr [5515,5530]
arith_expr [5557,5572]
===
match
---
operator: , [1385,1386]
operator: , [1385,1386]
===
match
---
operator: = [5980,5981]
operator: = [6022,6023]
===
match
---
name: hook [7842,7846]
name: hook [7859,7863]
===
match
---
suite [864,913]
suite [864,913]
===
match
---
trailer [3464,3469]
trailer [3464,3469]
===
match
---
return_stmt [1874,1948]
return_stmt [1874,1948]
===
match
---
name: self [3488,3492]
name: self [3488,3492]
===
match
---
trailer [5209,5240]
trailer [5251,5282]
===
match
---
operator: += [5395,5397]
operator: += [5437,5439]
===
match
---
name: os [794,796]
name: os [794,796]
===
match
---
name: path [3526,3530]
name: path [3526,3530]
===
match
---
expr_stmt [5444,5495]
expr_stmt [5486,5537]
===
match
---
name: ti [5480,5482]
name: ti [5522,5524]
===
match
---
operator: , [4533,4534]
operator: , [4533,4534]
===
match
---
operator: = [5195,5196]
operator: = [5237,5238]
===
match
---
trailer [3293,3295]
trailer [3293,3295]
===
match
---
name: remote_log_location [6681,6700]
name: remote_log_location [6723,6742]
===
match
---
name: join [3465,3469]
name: join [3465,3469]
===
match
---
name: cached_property [829,844]
name: cached_property [829,844]
===
match
---
name: log [7650,7653]
name: log [7692,7695]
===
match
---
operator: = [5464,5465]
operator: = [5506,5507]
===
match
---
name: self [2530,2534]
name: self [2530,2534]
===
match
---
trailer [1887,1948]
trailer [1887,1948]
===
match
---
string: 'Could not create an S3Hook with connection id "%s". ' [2060,2114]
string: 'Could not create an S3Hook with connection id "%s". ' [2060,2114]
===
match
---
name: log [6894,6897]
name: log [6936,6939]
===
match
---
name: self [7733,7737]
name: self [7766,7770]
===
match
---
name: log [5391,5394]
name: log [5433,5436]
===
match
---
param [5570,5594]
param [5612,5636]
===
match
---
name: remote_log_location [8156,8175]
name: remote_log_location [8173,8192]
===
match
---
name: self [4509,4513]
name: self [4509,4513]
===
match
---
trailer [7846,7858]
trailer [7863,7875]
===
match
---
name: Exception [8052,8061]
name: Exception [8069,8078]
===
match
---
operator: , [5220,5221]
operator: , [5262,5263]
===
match
---
argument [5222,5239]
argument [5264,5281]
===
match
---
name: append [6930,6936]
name: append [6972,6978]
===
match
---
name: self [3866,3870]
name: self [3866,3870]
===
match
---
funcdef [3856,5541]
funcdef [3856,5583]
===
match
---
trailer [2032,2042]
trailer [2032,2042]
===
match
---
operator: , [5933,5934]
operator: , [5975,5976]
===
match
---
name: exception [7742,7751]
name: exception [7775,7784]
===
match
---
fstring [5259,5319]
fstring [5301,5361]
===
match
---
string: 'logging' [1746,1755]
string: 'logging' [1746,1755]
===
match
---
name: exception [6744,6753]
name: exception [6786,6795]
===
match
---
operator: , [3886,3887]
operator: , [3886,3887]
===
match
---
name: self [2024,2028]
name: self [2024,2028]
===
match
---
name: cached_property [1646,1661]
name: cached_property [1646,1661]
===
match
---
name: remote_log_location [7565,7584]
name: remote_log_location [7607,7626]
===
match
---
dictorsetmaker [1926,1946]
dictorsetmaker [1926,1946]
===
match
---
trailer [1485,1497]
trailer [1485,1497]
===
match
---
name: Exception [1964,1973]
name: Exception [1964,1973]
===
match
---
name: ti [3872,3874]
name: ti [3872,3874]
===
match
---
operator: , [1902,1903]
operator: , [1902,1903]
===
match
---
trailer [5201,5209]
trailer [5243,5251]
===
insert-node
---
arglist [4831,4883]
to
trailer [4830,4837]
at 0
===
update-node
---
string: 'Could not verify previous log to append: %s' [7752,7797]
replace 'Could not verify previous log to append: %s' by 'Could not verify previous log to append'
===
move-tree
---
string: 'Could not verify previous log to append: %s' [7752,7797]
to
trailer [7751,7810]
at 0
===
update-node
---
name: error [4831,4836]
replace error by remote_loc
===
move-tree
---
name: error [4831,4836]
to
arglist [4831,4883]
at 2
===
move-tree
---
name: error [4917,4922]
to
fstring_expr [4912,4924]
at 1
===
delete-node
---
trailer [4916,4923]
===
===
delete-node
---
atom_expr [4913,4923]
===
===
delete-node
---
name: error [7682,7687]
===
===
delete-node
---
arglist [7752,7809]
===
