===
match
---
import_from [839,900]
import_from [839,900]
===
match
---
and_test [27888,27944]
and_test [27888,27944]
===
match
---
atom_expr [7362,7375]
atom_expr [7362,7375]
===
match
---
trailer [28208,28259]
trailer [28208,28259]
===
match
---
name: _application_args [15722,15739]
name: _application_args [15722,15739]
===
match
---
name: _keytab [28231,28238]
name: _keytab [28231,28238]
===
match
---
trailer [12971,12983]
trailer [12971,12983]
===
match
---
expr_stmt [14278,14341]
expr_stmt [14278,14341]
===
match
---
param [5598,5637]
param [5598,5637]
===
match
---
name: info [27576,27580]
name: info [27576,27580]
===
match
---
operator: = [23071,23072]
operator: = [23071,23072]
===
match
---
trailer [12333,12343]
trailer [12333,12343]
===
match
---
atom_expr [6745,6771]
atom_expr [6745,6771]
===
match
---
name: extra [9489,9494]
name: extra [9489,9494]
===
match
---
operator: = [9545,9546]
operator: = [9545,9546]
===
match
---
trailer [8087,8092]
trailer [8087,8092]
===
match
---
atom [16962,17002]
atom [16962,17002]
===
match
---
trailer [9705,9737]
trailer [9705,9737]
===
match
---
name: str [12908,12911]
name: str [12908,12911]
===
match
---
atom_expr [6503,6526]
atom_expr [6503,6526]
===
match
---
simple_stmt [20674,20694]
simple_stmt [20674,20694]
===
match
---
trailer [15212,15224]
trailer [15212,15224]
===
match
---
atom_expr [6194,6208]
atom_expr [6194,6208]
===
match
---
string: 'deploy_mode' [15512,15525]
string: 'deploy_mode' [15512,15525]
===
match
---
trailer [10057,10070]
trailer [10057,10070]
===
match
---
simple_stmt [25093,25337]
simple_stmt [25093,25337]
===
match
---
atom_expr [15043,15059]
atom_expr [15043,15059]
===
match
---
trailer [26975,27007]
trailer [26975,27007]
===
match
---
name: self [8652,8656]
name: self [8652,8656]
===
match
---
if_stmt [13866,13934]
if_stmt [13866,13934]
===
match
---
trailer [8139,8144]
trailer [8139,8144]
===
match
---
if_stmt [9989,10114]
if_stmt [9989,10114]
===
match
---
name: int [6104,6107]
name: int [6104,6107]
===
match
---
comparison [19339,19362]
comparison [19339,19362]
===
match
---
trailer [16476,16492]
trailer [16476,16492]
===
match
---
tfpdef [5351,5374]
tfpdef [5351,5374]
===
match
---
if_stmt [7673,7917]
if_stmt [7673,7917]
===
match
---
atom_expr [25946,25955]
atom_expr [25946,25955]
===
match
---
operator: , [23123,23124]
operator: , [23123,23124]
===
match
---
trailer [14486,14502]
trailer [14486,14502]
===
match
---
atom_expr [6619,6633]
atom_expr [6619,6633]
===
match
---
name: self [29109,29113]
name: self [29109,29113]
===
match
---
expr_stmt [14916,14966]
expr_stmt [14916,14966]
===
match
---
operator: , [11805,11806]
operator: , [11805,11806]
===
match
---
trailer [6623,6633]
trailer [6623,6633]
===
match
---
trailer [21131,21192]
trailer [21131,21192]
===
match
---
atom_expr [18818,18839]
atom_expr [18818,18839]
===
match
---
name: self [6849,6853]
name: self [6849,6853]
===
match
---
name: int [5767,5770]
name: int [5767,5770]
===
match
---
operator: , [27435,27436]
operator: , [27435,27436]
===
match
---
name: _build_spark_driver_kill_command [27198,27230]
name: _build_spark_driver_kill_command [27198,27230]
===
match
---
string: "--conf" [12408,12416]
string: "--conf" [12408,12416]
===
match
---
atom_expr [9610,9633]
atom_expr [9610,9633]
===
match
---
atom_expr [11943,11952]
atom_expr [11943,11952]
===
match
---
trailer [27660,27671]
trailer [27660,27671]
===
match
---
simple_stmt [10657,10709]
simple_stmt [10657,10709]
===
match
---
trailer [8062,8077]
trailer [8062,8077]
===
match
---
trailer [25768,25775]
trailer [25768,25775]
===
match
---
name: _submit_sp [18335,18345]
name: _submit_sp [18335,18345]
===
match
---
expr_stmt [7607,7664]
expr_stmt [7607,7664]
===
match
---
trailer [21612,21617]
trailer [21612,21617]
===
match
---
atom_expr [14950,14965]
atom_expr [14950,14965]
===
match
---
trailer [7751,7916]
trailer [7751,7916]
===
match
---
atom_expr [10544,10574]
atom_expr [10544,10574]
===
match
---
name: _submit_sp [18273,18283]
name: _submit_sp [18273,18283]
===
match
---
name: returncode [25836,25846]
name: returncode [25836,25846]
===
match
---
suite [10811,11879]
suite [10811,11879]
===
match
---
comparison [27888,27912]
comparison [27888,27912]
===
match
---
name: self [16859,16863]
name: self [16859,16863]
===
match
---
atom_expr [13869,13879]
atom_expr [13869,13879]
===
match
---
comparison [9992,10034]
comparison [9992,10034]
===
match
---
trailer [7227,7237]
trailer [7227,7237]
===
match
---
operator: , [26832,26833]
operator: , [26832,26833]
===
match
---
trailer [28428,28533]
trailer [28428,28533]
===
match
---
arglist [9706,9736]
arglist [9706,9736]
===
match
---
name: self [6469,6473]
name: self [6469,6473]
===
match
---
simple_stmt [8012,8050]
simple_stmt [8012,8050]
===
match
---
expr_stmt [10496,10630]
expr_stmt [10496,10630]
===
match
---
expr_stmt [6503,6546]
expr_stmt [6503,6546]
===
match
---
trailer [7654,7664]
trailer [7654,7664]
===
match
---
operator: , [14771,14772]
operator: , [14771,14772]
===
match
---
trailer [23190,23194]
trailer [23190,23194]
===
match
---
trailer [7588,7598]
trailer [7588,7598]
===
match
---
operator: += [14192,14194]
operator: += [14192,14194]
===
match
---
name: self [16094,16098]
name: self [16094,16098]
===
match
---
atom_expr [16132,16160]
atom_expr [16132,16160]
===
match
---
testlist_comp [12408,12449]
testlist_comp [12408,12449]
===
match
---
operator: = [26524,26525]
operator: = [26524,26525]
===
match
---
simple_stmt [28987,29265]
simple_stmt [28987,29265]
===
match
---
name: files [5314,5319]
name: files [5314,5319]
===
match
---
tfpdef [5646,5673]
tfpdef [5646,5673]
===
match
---
operator: += [12301,12303]
operator: += [12301,12303]
===
match
---
operator: = [6598,6599]
operator: = [6598,6599]
===
match
---
name: jars [6568,6572]
name: jars [6568,6572]
===
match
---
trailer [14597,14614]
trailer [14597,14614]
===
match
---
name: conf [5227,5231]
name: conf [5227,5231]
===
match
---
name: _should_track_driver_status [22207,22234]
name: _should_track_driver_status [22207,22234]
===
match
---
name: _name [15130,15135]
name: _name [15130,15135]
===
match
---
expr_stmt [16174,16228]
expr_stmt [16174,16228]
===
match
---
arglist [28450,28515]
arglist [28450,28515]
===
match
---
name: self [12505,12509]
name: self [12505,12509]
===
match
---
name: log [27360,27363]
name: log [27360,27363]
===
match
---
expr_stmt [27738,27810]
expr_stmt [27738,27810]
===
match
---
expr_stmt [8012,8049]
expr_stmt [8012,8049]
===
match
---
operator: = [25277,25278]
operator: = [25277,25278]
===
match
---
operator: , [5264,5265]
operator: , [5264,5265]
===
match
---
name: connection_cmd [26742,26756]
name: connection_cmd [26742,26756]
===
match
---
tfpdef [6082,6107]
tfpdef [6082,6107]
===
match
---
simple_stmt [17192,17367]
simple_stmt [17192,17367]
===
match
---
trailer [26320,26334]
trailer [26320,26334]
===
match
---
trailer [10230,10235]
trailer [10230,10235]
===
match
---
suite [27053,27491]
suite [27053,27491]
===
match
---
name: _env [17873,17877]
name: _env [17873,17877]
===
match
---
fstring [9259,9285]
fstring [9259,9285]
===
match
---
arglist [26812,26848]
arglist [26812,26848]
===
match
---
operator: = [7142,7143]
operator: = [7142,7143]
===
match
---
atom_expr [27454,27472]
atom_expr [27454,27472]
===
match
---
atom_expr [5850,5863]
atom_expr [5850,5863]
===
match
---
atom_expr [21860,21881]
atom_expr [21860,21881]
===
match
---
trailer [27073,27084]
trailer [27073,27084]
===
match
---
parameters [25936,25942]
parameters [25936,25942]
===
match
---
trailer [22545,22551]
trailer [22545,22551]
===
match
---
trailer [13837,13856]
trailer [13837,13856]
===
match
---
string: r'\s*pod name: ((.+?)-([a-z0-9]+)-driver)' [21440,21482]
string: r'\s*pod name: ((.+?)-([a-z0-9]+)-driver)' [21440,21482]
===
match
---
name: stderr [25228,25234]
name: stderr [25228,25234]
===
match
---
name: self [13727,13731]
name: self [13727,13731]
===
match
---
simple_stmt [13791,13858]
simple_stmt [13791,13858]
===
match
---
simple_stmt [18914,19116]
simple_stmt [18914,19116]
===
match
---
name: strip [22901,22906]
name: strip [22901,22906]
===
match
---
name: _process_spark_status_log [22561,22586]
name: _process_spark_status_log [22561,22586]
===
match
---
trailer [19922,19929]
trailer [19922,19929]
===
match
---
atom_expr [24884,24910]
atom_expr [24884,24910]
===
match
---
name: self [8108,8112]
name: self [8108,8112]
===
match
---
operator: = [5415,5416]
operator: = [5415,5416]
===
match
---
operator: , [5825,5826]
operator: , [5825,5826]
===
match
---
string: 'deploy_mode' [20913,20926]
string: 'deploy_mode' [20913,20926]
===
match
---
operator: , [15206,15207]
operator: , [15206,15207]
===
match
---
name: _driver_status [23056,23070]
name: _driver_status [23056,23070]
===
match
---
trailer [10077,10083]
trailer [10077,10083]
===
match
---
name: kube_client [7700,7711]
name: kube_client [7700,7711]
===
match
---
name: bool [6235,6239]
name: bool [6235,6239]
===
match
---
atom_expr [7173,7195]
atom_expr [7173,7195]
===
match
---
atom_expr [9180,9193]
atom_expr [9180,9193]
===
match
---
trailer [8184,8194]
trailer [8184,8194]
===
match
---
trailer [21170,21191]
trailer [21170,21191]
===
match
---
name: search [21433,21439]
name: search [21433,21439]
===
match
---
operator: = [28284,28285]
operator: = [28284,28285]
===
match
---
operator: , [14860,14861]
operator: , [14860,14861]
===
match
---
name: _is_kubernetes [12487,12501]
name: _is_kubernetes [12487,12501]
===
match
---
trailer [9266,9271]
trailer [9266,9271]
===
match
---
atom [14646,14690]
atom [14646,14690]
===
match
---
name: str [8185,8188]
name: str [8185,8188]
===
match
---
simple_stmt [17376,17437]
simple_stmt [17376,17437]
===
match
---
atom_expr [13922,13932]
atom_expr [13922,13932]
===
match
---
testlist_comp [16963,17001]
testlist_comp [16963,17001]
===
match
---
name: AirflowException [13181,13197]
name: AirflowException [13181,13197]
===
match
---
expr_stmt [9237,9285]
expr_stmt [9237,9285]
===
match
---
string: 'queue' [15393,15400]
string: 'queue' [15393,15400]
===
match
---
trailer [24888,24910]
trailer [24888,24910]
===
match
---
name: self [28684,28688]
name: self [28684,28688]
===
match
---
name: self [15787,15791]
name: self [15787,15791]
===
match
---
testlist_comp [24735,24785]
testlist_comp [24735,24785]
===
match
---
atom_expr [7420,7433]
atom_expr [7420,7433]
===
match
---
operator: , [12906,12907]
operator: , [12906,12907]
===
match
---
simple_stmt [10123,10140]
simple_stmt [10123,10140]
===
match
---
atom_expr [15072,15082]
atom_expr [15072,15082]
===
match
---
trailer [23055,23070]
trailer [23055,23070]
===
match
---
name: subprocess [25235,25245]
name: subprocess [25235,25245]
===
match
---
argument [25298,25321]
argument [25298,25321]
===
match
---
expr_stmt [6653,6694]
expr_stmt [6653,6694]
===
match
---
atom_expr [9775,9797]
atom_expr [9775,9797]
===
match
---
funcdef [17473,20032]
funcdef [17473,20032]
===
match
---
name: conf [936,940]
name: conf [936,940]
===
match
---
name: wait [25450,25454]
name: wait [25450,25454]
===
match
---
string: 'namespace' [9785,9796]
string: 'namespace' [9785,9796]
===
match
---
testlist_comp [13810,13856]
testlist_comp [13810,13856]
===
match
---
suite [12845,12935]
suite [12845,12935]
===
match
---
trailer [13197,13270]
trailer [13197,13270]
===
match
---
trailer [6347,6353]
trailer [6347,6353]
===
match
---
and_test [12462,12519]
and_test [12462,12519]
===
match
---
name: packages [6636,6644]
name: packages [6636,6644]
===
match
---
atom_expr [7289,7304]
atom_expr [7289,7304]
===
match
---
string: "Spark-Kill cmd: %s" [26812,26832]
string: "Spark-Kill cmd: %s" [26812,26832]
===
match
---
name: _num_executors [14325,14339]
name: _num_executors [14325,14339]
===
match
---
atom_expr [21430,21489]
atom_expr [21430,21489]
===
match
---
name: str [5537,5540]
name: str [5537,5540]
===
match
---
name: Optional [5321,5329]
name: Optional [5321,5329]
===
match
---
name: host [9267,9271]
name: host [9267,9271]
===
match
---
param [5742,5779]
param [5742,5779]
===
match
---
fstring [12418,12449]
fstring [12418,12449]
===
match
---
simple_stmt [15346,15403]
simple_stmt [15346,15403]
===
match
---
trailer [26643,26655]
trailer [26643,26655]
===
match
---
atom_expr [13499,13510]
atom_expr [13499,13510]
===
match
---
operator: = [9158,9159]
operator: = [9158,9159]
===
match
---
name: subprocess [28412,28422]
name: subprocess [28412,28422]
===
match
---
name: curl_max_wait_time [16049,16067]
name: curl_max_wait_time [16049,16067]
===
match
---
for_stmt [12819,12935]
for_stmt [12819,12935]
===
match
---
trailer [15380,15392]
trailer [15380,15392]
===
match
---
suite [4946,5111]
suite [4946,5111]
===
match
---
trailer [8016,8027]
trailer [8016,8027]
===
match
---
operator: , [5732,5733]
operator: , [5732,5733]
===
match
---
operator: += [15361,15363]
operator: += [15361,15363]
===
match
---
name: format [25769,25775]
name: format [25769,25775]
===
match
---
trailer [14563,14579]
trailer [14563,14579]
===
match
---
atom_expr [5888,5901]
atom_expr [5888,5901]
===
match
---
trailer [27106,27110]
trailer [27106,27110]
===
match
---
operator: , [18054,18055]
operator: , [18054,18055]
===
match
---
name: status_poll_interval [7144,7164]
name: status_poll_interval [7144,7164]
===
match
---
name: self [10073,10077]
name: self [10073,10077]
===
match
---
simple_stmt [6897,6933]
simple_stmt [6897,6933]
===
match
---
simple_stmt [8058,8100]
simple_stmt [8058,8100]
===
match
---
operator: { [6364,6365]
operator: { [6364,6365]
===
match
---
testlist_comp [16276,16436]
testlist_comp [16276,16436]
===
match
---
operator: , [6202,6203]
operator: , [6202,6203]
===
match
---
argument [11819,11829]
argument [11819,11829]
===
match
---
if_stmt [23009,23173]
if_stmt [23009,23173]
===
match
---
trailer [6559,6565]
trailer [6559,6565]
===
match
---
name: error [29439,29444]
name: exception [29434,29443]
===
match
---
name: self [18772,18776]
name: self [18772,18776]
===
match
---
atom_expr [29169,29204]
atom_expr [29169,29204]
===
match
---
classdef [1298,29538]
classdef [1298,29494]
===
match
---
name: _mask_cmd [10749,10758]
name: _mask_cmd [10749,10758]
===
match
---
name: security [1058,1066]
name: security [1058,1066]
===
match
---
name: self [19613,19617]
name: self [19613,19617]
===
match
---
name: Optional [5712,5720]
name: Optional [5712,5720]
===
match
---
name: log [26966,26969]
name: log [26966,26969]
===
match
---
name: _packages [13950,13959]
name: _packages [13950,13959]
===
match
---
name: Any [20087,20090]
name: Any [20087,20090]
===
match
---
trailer [28964,28966]
trailer [28964,28966]
===
match
---
expr_stmt [21052,21097]
expr_stmt [21052,21097]
===
match
---
trailer [14558,14580]
trailer [14558,14580]
===
match
---
trailer [5813,5818]
trailer [5813,5818]
===
match
---
name: _connection [26440,26451]
name: _connection [26440,26451]
===
match
---
suite [10644,10709]
suite [10644,10709]
===
match
---
operator: = [7509,7510]
operator: = [7509,7510]
===
match
---
comparison [7562,7598]
comparison [7562,7598]
===
match
---
operator: , [5949,5950]
operator: , [5949,5950]
===
match
---
name: self [15307,15311]
name: self [15307,15311]
===
match
---
name: verbose [6226,6233]
name: verbose [6226,6233]
===
match
---
atom_expr [26396,26426]
atom_expr [26396,26426]
===
match
---
name: conn_type [4842,4851]
name: conn_type [4842,4851]
===
match
---
operator: -> [20093,20095]
operator: -> [20093,20095]
===
match
---
name: self [14805,14809]
name: self [14805,14809]
===
match
---
operator: = [6108,6109]
operator: = [6108,6109]
===
match
---
trailer [26412,26426]
trailer [26412,26426]
===
match
---
name: _keytab [27893,27900]
name: _keytab [27893,27900]
===
match
---
name: __init__ [6324,6332]
name: __init__ [6324,6332]
===
match
---
except_clause [1207,1238]
except_clause [1207,1238]
===
match
---
atom [16258,16450]
atom [16258,16450]
===
match
---
name: log [24930,24933]
name: log [24930,24933]
===
match
---
operator: , [17419,17420]
operator: , [17419,17420]
===
match
---
if_stmt [25470,25895]
if_stmt [25470,25895]
===
match
---
atom [6364,6366]
atom [6364,6366]
===
match
---
name: self [9843,9847]
name: self [9843,9847]
===
match
---
name: _driver_id [27153,27163]
name: _driver_id [27153,27163]
===
match
---
parameters [23350,23356]
parameters [23350,23356]
===
match
---
operator: = [16256,16257]
operator: = [16256,16257]
===
match
---
string: 'spark_binary' [9656,9670]
string: 'spark_binary' [9656,9670]
===
match
---
atom_expr [23073,23136]
atom_expr [23073,23136]
===
match
---
operator: = [12572,12573]
operator: = [12572,12573]
===
match
---
name: str [14438,14441]
name: str [14438,14441]
===
match
---
name: self [27567,27571]
name: self [27567,27571]
===
match
---
name: self [6653,6657]
name: self [6653,6657]
===
match
---
atom_expr [9320,9339]
atom_expr [9320,9339]
===
match
---
trailer [27307,27312]
trailer [27307,27312]
===
match
---
atom_expr [9237,9256]
atom_expr [9237,9256]
===
match
---
atom [12880,12934]
atom [12880,12934]
===
match
---
trailer [22900,22906]
trailer [22900,22906]
===
match
---
operator: } [9271,9272]
operator: } [9271,9272]
===
match
---
name: kill_cmd [27182,27190]
name: kill_cmd [27182,27190]
===
match
---
name: self [22388,22392]
name: self [22388,22392]
===
match
---
operator: , [14436,14437]
operator: , [14436,14437]
===
match
---
name: kill [27672,27676]
name: kill [27672,27676]
===
match
---
trailer [22536,22540]
trailer [22536,22540]
===
match
---
operator: += [15193,15195]
operator: += [15193,15195]
===
match
---
operator: += [15714,15716]
operator: += [15714,15716]
===
match
---
name: self [13499,13503]
name: self [13499,13503]
===
match
---
operator: , [10574,10575]
operator: , [10574,10575]
===
match
---
operator: -> [8254,8256]
operator: -> [8254,8256]
===
match
---
operator: = [9257,9258]
operator: = [9257,9258]
===
match
---
trailer [17814,17842]
trailer [17814,17842]
===
match
---
parameters [5203,6298]
parameters [5203,6298]
===
match
---
trailer [26395,26468]
trailer [26395,26468]
===
match
---
decorator [4891,4905]
decorator [4891,4905]
===
match
---
simple_stmt [22276,22332]
simple_stmt [22276,22332]
===
match
---
arith_expr [17236,17348]
arith_expr [17236,17348]
===
match
---
atom_expr [19339,19354]
atom_expr [19339,19354]
===
match
---
name: time [834,838]
name: time [834,838]
===
match
---
expr_stmt [6897,6932]
expr_stmt [6897,6932]
===
match
---
name: self [7492,7496]
name: self [7492,7496]
===
match
---
operator: = [7056,7057]
operator: = [7056,7057]
===
match
---
name: connection_cmd [16944,16958]
name: connection_cmd [16944,16958]
===
match
---
simple_stmt [6849,6889]
simple_stmt [6849,6889]
===
match
---
name: connection_cmd [26608,26622]
name: connection_cmd [26608,26622]
===
match
---
trailer [13670,13680]
trailer [13670,13680]
===
match
---
name: self [28730,28734]
name: self [28730,28734]
===
match
---
name: info [22463,22467]
name: info [22463,22467]
===
match
---
param [17484,17489]
param [17484,17489]
===
match
---
atom_expr [16094,16120]
atom_expr [16094,16120]
===
match
---
name: str [6199,6202]
name: str [6199,6202]
===
match
---
atom_expr [14555,14580]
atom_expr [14555,14580]
===
match
---
trailer [12916,12926]
trailer [12916,12926]
===
match
---
operator: = [25234,25235]
operator: = [25234,25235]
===
match
---
simple_stmt [13175,13271]
simple_stmt [13175,13271]
===
match
---
name: stdout [28469,28475]
name: stdout [28469,28475]
===
match
---
annassign [8077,8099]
annassign [8077,8099]
===
match
---
name: self [7391,7395]
name: self [7391,7395]
===
match
---
simple_stmt [16463,16493]
simple_stmt [16463,16493]
===
match
---
trailer [28734,28757]
trailer [28734,28757]
===
match
---
string: 'master' [8786,8794]
string: 'master' [8786,8794]
===
match
---
trailer [12430,12447]
trailer [12430,12447]
===
match
---
name: self [15663,15667]
name: self [15663,15667]
===
match
---
if_stmt [13663,13743]
if_stmt [13663,13743]
===
match
---
or_test [6356,6366]
or_test [6356,6366]
===
match
---
name: renew_from_kt [1083,1096]
name: renew_from_kt [1083,1096]
===
match
---
atom_expr [12908,12932]
atom_expr [12908,12932]
===
match
---
simple_stmt [27355,27491]
simple_stmt [27355,27491]
===
match
---
suite [15333,15403]
suite [15333,15403]
===
match
---
operator: = [27747,27748]
operator: = [27747,27748]
===
match
---
atom_expr [13282,13301]
atom_expr [13282,13301]
===
match
---
arglist [19955,19991]
arglist [19955,19991]
===
match
---
name: AirflowException [17198,17214]
name: AirflowException [17198,17214]
===
match
---
name: self [14214,14218]
name: self [14214,14218]
===
match
---
name: PIPE [27332,27336]
name: PIPE [27332,27336]
===
match
---
operator: , [28728,28729]
operator: , [28728,28729]
===
match
---
name: STDOUT [25246,25252]
name: STDOUT [25246,25252]
===
match
---
comparison [12967,13011]
comparison [12967,13011]
===
match
---
name: self [14887,14891]
name: self [14887,14891]
===
match
---
name: self [28226,28230]
name: self [28226,28230]
===
match
---
expr_stmt [17110,17157]
expr_stmt [17110,17157]
===
match
---
string: "SUBMITTED" [19635,19646]
string: "SUBMITTED" [19635,19646]
===
match
---
and_test [20878,20940]
and_test [20878,20940]
===
match
---
trailer [24877,24883]
trailer [24877,24883]
===
match
---
tfpdef [5598,5629]
tfpdef [5598,5629]
===
match
---
arglist [25805,25846]
arglist [25805,25846]
===
match
---
trailer [7293,7304]
trailer [7293,7304]
===
match
---
atom_expr [26639,26665]
atom_expr [26639,26665]
===
match
---
trailer [16205,16228]
trailer [16205,16228]
===
match
---
trailer [27676,27678]
trailer [27676,27678]
===
match
---
name: _submit_sp [27508,27518]
name: _submit_sp [27508,27518]
===
match
---
string: """         Polls the driver based on self._driver_id to get the status.         Finish successfully when the status is FINISHED.         Finish failed when the status is ERROR/UNKNOWN/KILLED/FAILED.          Possible status:          SUBMITTED             Submitted but not yet scheduled on a worker         RUNNING             Has been allocated to a worker to run         FINISHED             Previously ran and exited cleanly         RELAUNCHING             Exited non-zero or due to worker failure, but has not yet             started running again         UNKNOWN             The status of the driver is temporarily not known due to             master failure recovery         KILLED             A user manually killed this driver         FAILED             The driver exited non-zero and was not supervised         ERROR             Unable to run or restart due to an unrecoverable error             (e.g. missing jar file)         """ [23374,24316]
string: """         Polls the driver based on self._driver_id to get the status.         Finish successfully when the status is FINISHED.         Finish failed when the status is ERROR/UNKNOWN/KILLED/FAILED.          Possible status:          SUBMITTED             Submitted but not yet scheduled on a worker         RUNNING             Has been allocated to a worker to run         FINISHED             Previously ran and exited cleanly         RELAUNCHING             Exited non-zero or due to worker failure, but has not yet             started running again         UNKNOWN             The status of the driver is temporarily not known due to             master failure recovery         KILLED             A user manually killed this driver         FAILED             The driver exited non-zero and was not supervised         ERROR             Unable to run or restart due to an unrecoverable error             (e.g. missing jar file)         """ [23374,24316]
===
match
---
trailer [29299,29354]
trailer [29299,29354]
===
match
---
string: 'master' [16111,16119]
string: 'master' [16111,16119]
===
match
---
name: _get_spark_binary_path [12214,12236]
name: _get_spark_binary_path [12214,12236]
===
match
---
suite [21031,21193]
suite [21031,21193]
===
match
---
name: ApiException [29391,29403]
name: ApiException [29391,29403]
===
match
---
simple_stmt [7115,7165]
simple_stmt [7115,7165]
===
match
---
name: spark_submit_cmd [17791,17807]
name: spark_submit_cmd [17791,17807]
===
match
---
name: missed_job_status_reports [25504,25529]
name: missed_job_status_reports [25504,25529]
===
match
---
operator: = [27191,27192]
operator: = [27191,27192]
===
match
---
atom_expr [24707,24726]
atom_expr [24707,24726]
===
match
---
string: 'spark_default' [5289,5304]
string: 'spark_default' [5289,5304]
===
match
---
name: _driver_status [19618,19632]
name: _driver_status [19618,19632]
===
match
---
name: base [1024,1028]
name: base [1024,1028]
===
match
---
atom [12407,12450]
atom [12407,12450]
===
match
---
name: _is_kubernetes [13287,13301]
name: _is_kubernetes [13287,13301]
===
match
---
name: conn_data [8760,8769]
name: conn_data [8760,8769]
===
match
---
operator: , [27452,27453]
operator: , [27452,27453]
===
match
---
name: info [22541,22545]
name: info [22541,22545]
===
match
---
string: 'spark.kubernetes.namespace' [10084,10112]
string: 'spark.kubernetes.namespace' [10084,10112]
===
match
---
name: _kubernetes_driver_pod [21541,21563]
name: _kubernetes_driver_pod [21541,21563]
===
match
---
trailer [27197,27230]
trailer [27197,27230]
===
match
---
string: "SparkSubmitHook env_vars is not supported in standalone-cluster mode." [13198,13269]
string: "SparkSubmitHook env_vars is not supported in standalone-cluster mode." [13198,13269]
===
match
---
name: self [6555,6559]
name: self [6555,6559]
===
match
---
trailer [12834,12844]
trailer [12834,12844]
===
match
---
param [10759,10764]
param [10759,10764]
===
match
---
atom_expr [17961,17974]
atom_expr [17961,17974]
===
match
---
if_stmt [15145,15226]
if_stmt [15145,15226]
===
match
---
simple_stmt [17110,17158]
simple_stmt [17110,17158]
===
match
---
name: str [5247,5250]
name: str [5247,5250]
===
match
---
operator: = [8145,8146]
operator: = [8145,8146]
===
match
---
expr_stmt [15008,15060]
expr_stmt [15008,15060]
===
match
---
name: self [14668,14672]
name: self [14668,14672]
===
match
---
name: key [12442,12445]
name: key [12442,12445]
===
match
---
trailer [14114,14132]
trailer [14114,14132]
===
match
---
name: connection_cmd_masked [11857,11878]
name: connection_cmd_masked [11857,11878]
===
match
---
operator: = [28475,28476]
operator: = [28475,28476]
===
match
---
name: self [24884,24888]
name: self [24884,24888]
===
match
---
trailer [27855,27860]
trailer [27855,27860]
===
match
---
testlist_comp [13385,13473]
testlist_comp [13385,13473]
===
match
---
parameters [10216,10222]
parameters [10216,10222]
===
match
---
operator: = [5464,5465]
operator: = [5464,5465]
===
match
---
expr_stmt [19613,19646]
expr_stmt [19613,19646]
===
match
---
trailer [26385,26390]
trailer [26385,26390]
===
match
---
name: self [14145,14149]
name: self [14145,14149]
===
match
---
atom [13911,13933]
atom [13911,13933]
===
match
---
operator: = [6484,6485]
operator: = [6484,6485]
===
match
---
operator: + [17300,17301]
operator: + [17300,17301]
===
match
---
trailer [22462,22467]
trailer [22462,22467]
===
match
---
string: "--master" [12305,12315]
string: "--master" [12305,12315]
===
match
---
name: self [6619,6623]
name: self [6619,6623]
===
match
---
operator: += [14846,14848]
operator: += [14846,14848]
===
match
---
parameters [26897,26903]
parameters [26897,26903]
===
match
---
name: _verbose [15242,15250]
name: _verbose [15242,15250]
===
match
---
atom_expr [5528,5541]
atom_expr [5528,5541]
===
match
---
atom_expr [13666,13680]
atom_expr [13666,13680]
===
match
---
simple_stmt [9520,9572]
simple_stmt [9520,9572]
===
match
---
suite [15686,15740]
suite [15686,15740]
===
match
---
trailer [19005,19097]
trailer [19005,19097]
===
match
---
atom_expr [12427,12447]
atom_expr [12427,12447]
===
match
---
name: log [29291,29294]
name: log [29291,29294]
===
match
---
operator: { [13440,13441]
operator: { [13440,13441]
===
match
---
operator: , [5680,5681]
operator: , [5680,5681]
===
match
---
name: _env [13030,13034]
name: _env [13030,13034]
===
match
---
name: str [14555,14558]
name: str [14555,14558]
===
match
---
name: connection_cmd [15802,15816]
name: connection_cmd [15802,15816]
===
match
---
trailer [17081,17092]
trailer [17081,17092]
===
match
---
simple_stmt [15576,15608]
simple_stmt [15576,15608]
===
match
---
trailer [10456,10468]
trailer [10456,10468]
===
match
---
operator: = [6450,6451]
operator: = [6450,6451]
===
match
---
name: self [6803,6807]
name: self [6803,6807]
===
match
---
atom_expr [8661,8675]
atom_expr [8661,8675]
===
match
---
operator: } [27867,27868]
operator: } [27867,27868]
===
match
---
arith_expr [19424,19514]
arith_expr [19424,19514]
===
match
---
parameters [15893,15899]
parameters [15893,15899]
===
match
---
name: Optional [8171,8179]
name: Optional [8171,8179]
===
match
---
atom_expr [29430,29495]
atom_expr [29425,29493]
===
match
---
atom [14753,14793]
atom [14753,14793]
===
match
---
name: debug [26970,26975]
name: debug [26970,26975]
===
match
---
if_stmt [21022,21193]
if_stmt [21022,21193]
===
match
---
trailer [16886,16888]
trailer [16886,16888]
===
match
---
name: kube_client [28937,28948]
name: kube_client [28937,28948]
===
match
---
operator: , [14004,14005]
operator: , [14004,14005]
===
match
---
operator: { [9261,9262]
operator: { [9261,9262]
===
match
---
atom_expr [27102,27164]
atom_expr [27102,27164]
===
match
---
name: self [6941,6945]
name: self [6941,6945]
===
match
---
name: List [15903,15907]
name: List [15903,15907]
===
match
---
name: self [8924,8928]
name: self [8924,8928]
===
match
---
trailer [5369,5374]
trailer [5369,5374]
===
match
---
simple_stmt [6469,6495]
simple_stmt [6469,6495]
===
match
---
trailer [15392,15401]
trailer [15392,15401]
===
match
---
operator: = [22292,22293]
operator: = [22292,22293]
===
match
---
fstring_end: " [16434,16435]
fstring_end: " [16434,16435]
===
match
---
name: Optional [5486,5494]
name: Optional [5486,5494]
===
match
---
simple_stmt [25583,25614]
simple_stmt [25583,25614]
===
match
---
operator: , [25252,25253]
operator: , [25252,25253]
===
match
---
string: 'bin' [26428,26433]
string: 'bin' [26428,26433]
===
match
---
name: stderr [18104,18110]
name: stderr [18104,18110]
===
match
---
simple_stmt [8526,8623]
simple_stmt [8526,8623]
===
match
---
simple_stmt [17927,17949]
simple_stmt [17927,17949]
===
match
---
name: subprocess [27263,27273]
name: subprocess [27263,27273]
===
match
---
string: "YARN app killed with return code: %s" [28565,28603]
string: "YARN app killed with return code: %s" [28565,28603]
===
match
---
atom_expr [26797,26849]
atom_expr [26797,26849]
===
match
---
trailer [27538,27543]
trailer [27538,27543]
===
match
---
atom_expr [18232,18292]
atom_expr [18232,18292]
===
match
---
if_stmt [10449,10709]
if_stmt [10449,10709]
===
match
---
trailer [18588,18603]
trailer [18588,18603]
===
match
---
atom_expr [9646,9671]
atom_expr [9646,9671]
===
match
---
atom_expr [27749,27810]
atom_expr [27749,27810]
===
match
---
string: 'spark_binary' [10600,10614]
string: 'spark_binary' [10600,10614]
===
match
---
atom_expr [18075,18090]
atom_expr [18075,18090]
===
match
---
atom_expr [11825,11829]
atom_expr [11825,11829]
===
match
---
name: Any [8190,8193]
name: Any [8190,8193]
===
match
---
name: get [28357,28360]
name: get [28357,28360]
===
match
---
if_stmt [13942,14022]
if_stmt [13942,14022]
===
match
---
trailer [6198,6208]
trailer [6198,6208]
===
match
---
trailer [7862,7874]
trailer [7862,7874]
===
match
---
operator: , [14314,14315]
operator: , [14314,14315]
===
match
---
suite [28868,29355]
suite [28868,29355]
===
match
---
expr_stmt [10048,10113]
expr_stmt [10048,10113]
===
match
---
fstring_end: " [9284,9285]
fstring_end: " [9284,9285]
===
match
---
name: self [27656,27660]
name: self [27656,27660]
===
match
---
name: STDOUT [18122,18128]
name: STDOUT [18122,18128]
===
match
---
suite [13880,13934]
suite [13880,13934]
===
match
---
operator: , [20071,20072]
operator: , [20071,20072]
===
match
---
operator: = [25316,25317]
operator: = [25316,25317]
===
match
---
atom_expr [6185,6209]
atom_expr [6185,6209]
===
match
---
operator: += [15279,15281]
operator: += [15279,15281]
===
match
---
name: str [11948,11951]
name: str [11948,11951]
===
match
---
trailer [28564,28622]
trailer [28564,28622]
===
match
---
trailer [28697,28758]
trailer [28697,28758]
===
match
---
trailer [13322,13335]
trailer [13322,13335]
===
match
---
operator: -> [15900,15902]
operator: -> [15900,15902]
===
match
---
expr_stmt [21743,21803]
expr_stmt [21743,21803]
===
match
---
atom [1214,1238]
atom [1214,1238]
===
match
---
atom [26626,26666]
atom [26626,26666]
===
match
---
name: str [5980,5983]
name: str [5980,5983]
===
match
---
trailer [9678,9692]
trailer [9678,9692]
===
match
---
if_stmt [19336,19533]
if_stmt [19336,19533]
===
match
---
if_stmt [19287,20032]
if_stmt [19287,20032]
===
match
---
name: _connection [7643,7654]
name: _connection [7643,7654]
===
match
---
trailer [15511,15526]
trailer [15511,15526]
===
match
---
name: _driver_id [26776,26786]
name: _driver_id [26776,26786]
===
match
---
if_stmt [12459,13271]
if_stmt [12459,13271]
===
match
---
expr_stmt [12862,12934]
expr_stmt [12862,12934]
===
match
---
name: I [11828,11829]
name: I [11828,11829]
===
match
---
string: "FAILED" [24768,24776]
string: "FAILED" [24768,24776]
===
match
---
trailer [8563,8573]
trailer [8563,8573]
===
match
---
suite [21405,21917]
suite [21405,21917]
===
match
---
argument [18142,18152]
argument [18142,18152]
===
match
---
atom_expr [7449,7467]
atom_expr [7449,7467]
===
match
---
simple_stmt [17990,18223]
simple_stmt [17990,18223]
===
match
---
simple_stmt [29286,29355]
simple_stmt [29286,29355]
===
match
---
operator: { [12420,12421]
operator: { [12420,12421]
===
match
---
string: 'kerberos' [28361,28371]
string: 'kerberos' [28361,28371]
===
match
---
simple_stmt [14069,14134]
simple_stmt [14069,14134]
===
match
---
suite [26729,26788]
suite [26729,26788]
===
match
---
suite [14615,14691]
suite [14615,14691]
===
match
---
operator: = [24586,24587]
operator: = [24586,24587]
===
match
---
string: "--kill" [26761,26769]
string: "--kill" [26761,26769]
===
match
---
trailer [29179,29186]
trailer [29179,29186]
===
match
---
operator: { [9273,9274]
operator: { [9273,9274]
===
match
---
not_test [23250,23266]
not_test [23250,23266]
===
match
---
operator: += [13621,13623]
operator: += [13621,13623]
===
match
---
name: connection_cmd [14393,14407]
name: connection_cmd [14393,14407]
===
match
---
name: path [10534,10538]
name: path [10534,10538]
===
match
---
simple_stmt [1097,1154]
simple_stmt [1097,1154]
===
match
---
atom_expr [5660,5673]
atom_expr [5660,5673]
===
match
---
atom_expr [12704,12713]
atom_expr [12704,12713]
===
match
---
simple_stmt [14628,14691]
simple_stmt [14628,14691]
===
match
---
operator: , [26433,26434]
operator: , [26433,26434]
===
match
---
operator: -> [10804,10806]
operator: -> [10804,10806]
===
match
---
name: _build_track_driver_status_command [15859,15893]
name: _build_track_driver_status_command [15859,15893]
===
match
---
string: 'spark_home' [10469,10481]
string: 'spark_home' [10469,10481]
===
match
---
param [10765,10802]
param [10765,10802]
===
match
---
operator: , [867,868]
operator: , [867,868]
===
match
---
simple_stmt [7173,7215]
simple_stmt [7173,7215]
===
match
---
or_test [27851,27866]
or_test [27851,27866]
===
match
---
operator: , [17511,17512]
operator: , [17511,17512]
===
match
---
operator: , [28458,28459]
operator: , [28458,28459]
===
match
---
trailer [5241,5257]
trailer [5241,5257]
===
match
---
atom_expr [27069,27084]
atom_expr [27069,27084]
===
match
---
operator: { [27864,27865]
operator: { [27864,27865]
===
match
---
name: _is_yarn [12510,12518]
name: _is_yarn [12510,12518]
===
match
---
trailer [14446,14468]
trailer [14446,14468]
===
match
---
atom_expr [29379,29403]
atom_expr [29379,29403]
===
match
---
name: utils [1110,1115]
name: utils [1110,1115]
===
match
---
atom [15282,15295]
atom [15282,15295]
===
match
---
simple_stmt [28324,28383]
simple_stmt [28324,28383]
===
match
---
param [15894,15898]
param [15894,15898]
===
match
---
name: application [17843,17854]
name: application [17843,17854]
===
match
---
operator: += [14931,14933]
operator: += [14931,14933]
===
match
---
simple_stmt [26921,26953]
simple_stmt [26921,26953]
===
match
---
operator: = [6419,6420]
operator: = [6419,6420]
===
match
---
trailer [22421,22428]
trailer [22421,22428]
===
match
---
trailer [7515,7535]
trailer [7515,7535]
===
match
---
name: _executor_cores [14487,14502]
name: _executor_cores [14487,14502]
===
match
---
name: log [29435,29438]
name: log [29430,29433]
===
match
---
trailer [18272,18283]
trailer [18272,18283]
===
match
---
name: _connection [7497,7508]
name: _connection [7497,7508]
===
match
---
suite [21839,21917]
suite [21839,21917]
===
match
---
fstring_expr [9261,9272]
fstring_expr [9261,9272]
===
match
---
string: r'\1******\3' [11754,11767]
string: r'\1******\3' [11754,11767]
===
match
---
name: name [6001,6005]
name: name [6001,6005]
===
match
---
string: "cluster" [13152,13161]
string: "cluster" [13152,13161]
===
match
---
simple_stmt [11962,12184]
simple_stmt [11962,12184]
===
match
---
if_stmt [26301,26561]
if_stmt [26301,26561]
===
match
---
simple_stmt [15922,16041]
simple_stmt [15922,16041]
===
match
---
operator: = [5630,5631]
operator: = [5630,5631]
===
match
---
trailer [12926,12931]
trailer [12926,12931]
===
match
---
operator: , [26769,26770]
operator: , [26769,26770]
===
match
---
param [26898,26902]
param [26898,26902]
===
match
---
expr_stmt [6581,6610]
expr_stmt [6581,6610]
===
match
---
atom_expr [16859,16888]
atom_expr [16859,16888]
===
match
---
operator: = [29236,29237]
operator: = [29236,29237]
===
match
---
name: _name [15077,15082]
name: _name [15077,15082]
===
match
---
param [5314,5342]
param [5314,5342]
===
match
---
name: AirflowException [16645,16661]
name: AirflowException [16645,16661]
===
match
---
param [5646,5681]
param [5646,5681]
===
match
---
if_stmt [13279,13488]
if_stmt [13279,13488]
===
match
---
name: self [6971,6975]
name: self [6971,6975]
===
match
---
atom_expr [8108,8129]
atom_expr [8108,8129]
===
match
---
operator: != [12999,13001]
operator: != [12999,13001]
===
match
---
string: "UNKNOWN" [24747,24756]
string: "UNKNOWN" [24747,24756]
===
match
---
atom_expr [16975,17001]
atom_expr [16975,17001]
===
match
---
and_test [18516,18566]
and_test [18516,18566]
===
match
---
operator: , [16216,16217]
operator: , [16216,16217]
===
match
---
trailer [22430,22433]
trailer [22430,22433]
===
match
---
name: self [12365,12369]
name: self [12365,12369]
===
match
---
atom_expr [7007,7023]
atom_expr [7007,7023]
===
match
---
testlist_comp [1215,1237]
testlist_comp [1215,1237]
===
match
---
name: connection_cmd [15835,15849]
name: connection_cmd [15835,15849]
===
match
---
string: 'namespace' [10058,10069]
string: 'namespace' [10058,10069]
===
match
---
name: self [26639,26643]
name: self [26639,26643]
===
match
---
name: num_executors [6037,6050]
name: num_executors [6037,6050]
===
match
---
name: _java_class [15213,15224]
name: _java_class [15213,15224]
===
match
---
tfpdef [6037,6065]
tfpdef [6037,6065]
===
match
---
string: 'deploy_mode' [15431,15444]
string: 'deploy_mode' [15431,15444]
===
match
---
name: join [26391,26395]
name: join [26391,26395]
===
match
---
string: "KILLED" [24758,24766]
string: "KILLED" [24758,24766]
===
match
---
name: exclude_packages [5598,5614]
name: exclude_packages [5598,5614]
===
match
---
name: self [13639,13643]
name: self [13639,13643]
===
match
---
string: 'spark_home' [9594,9606]
string: 'spark_home' [9594,9606]
===
match
---
operator: , [10581,10582]
operator: , [10581,10582]
===
match
---
name: _kubernetes_driver_pod [21658,21680]
name: _kubernetes_driver_pod [21658,21680]
===
match
---
string: r'(driver-[0-9\-]+)' [22304,22324]
string: r'(driver-[0-9\-]+)' [22304,22324]
===
match
---
operator: = [7560,7561]
operator: = [7560,7561]
===
match
---
simple_stmt [15264,15296]
simple_stmt [15264,15296]
===
match
---
simple_stmt [14735,14794]
simple_stmt [14735,14794]
===
match
---
name: _principal [28214,28224]
name: _principal [28214,28224]
===
match
---
atom_expr [25195,25210]
atom_expr [25195,25210]
===
match
---
atom_expr [18920,19115]
atom_expr [18920,19115]
===
match
---
atom_expr [26771,26786]
atom_expr [26771,26786]
===
match
---
trailer [28614,28619]
trailer [28614,28619]
===
match
---
trailer [19976,19991]
trailer [19976,19991]
===
match
---
testlist_comp [13912,13932]
testlist_comp [13912,13932]
===
match
---
name: driver_kill [27454,27465]
name: driver_kill [27454,27465]
===
match
---
simple_stmt [25015,25081]
simple_stmt [25015,25081]
===
match
---
atom [13624,13654]
atom [13624,13654]
===
match
---
expr_stmt [6343,6366]
expr_stmt [6343,6366]
===
match
---
atom_expr [14006,14020]
atom_expr [14006,14020]
===
match
---
if_stmt [14699,14794]
if_stmt [14699,14794]
===
match
---
atom_expr [7045,7055]
atom_expr [7045,7055]
===
match
---
name: AirflowException [18627,18643]
name: AirflowException [18627,18643]
===
match
---
name: _driver_status [19785,19799]
name: _driver_status [19785,19799]
===
match
---
string: "--class" [15197,15206]
string: "--class" [15197,15206]
===
match
---
atom_expr [27020,27052]
atom_expr [27020,27052]
===
match
---
simple_stmt [25422,25457]
simple_stmt [25422,25457]
===
match
---
name: log [21609,21612]
name: log [21609,21612]
===
match
---
name: re [21761,21763]
name: re [21761,21763]
===
match
---
name: _process_spark_status_log [25355,25380]
name: _process_spark_status_log [25355,25380]
===
match
---
string: "http://" [16218,16227]
string: "http://" [16218,16227]
===
match
---
name: _get_spark_binary_path [16864,16886]
name: _get_spark_binary_path [16864,16886]
===
match
---
name: log [27107,27110]
name: log [27107,27110]
===
match
---
name: self [15717,15721]
name: self [15717,15721]
===
match
---
name: self [24925,24929]
name: self [24925,24929]
===
match
---
suite [19323,20032]
suite [19323,20032]
===
match
---
atom_expr [6941,6953]
atom_expr [6941,6953]
===
match
---
atom [26526,26560]
atom [26526,26560]
===
match
---
trailer [7119,7141]
trailer [7119,7141]
===
match
---
trailer [9214,9219]
trailer [9214,9219]
===
match
---
name: Any [10167,10170]
name: Any [10167,10170]
===
match
---
trailer [18520,18535]
trailer [18520,18535]
===
match
---
trailer [19959,19970]
trailer [19959,19970]
===
match
---
name: Dict [863,867]
name: Dict [863,867]
===
match
---
name: _driver_id [26718,26728]
name: _driver_id [26718,26728]
===
match
---
trailer [20882,20891]
trailer [20882,20891]
===
match
---
trailer [27543,27545]
trailer [27543,27545]
===
match
---
name: self [16418,16422]
name: self [16418,16422]
===
match
---
simple_stmt [7546,7599]
simple_stmt [7546,7599]
===
match
---
atom_expr [17077,17092]
atom_expr [17077,17092]
===
match
---
operator: = [6210,6211]
operator: = [6210,6211]
===
match
---
name: self [18584,18588]
name: self [18584,18588]
===
match
---
atom_expr [6139,6158]
atom_expr [6139,6158]
===
match
---
atom_expr [18627,18879]
atom_expr [18627,18879]
===
match
---
name: self [7071,7075]
name: self [7071,7075]
===
match
---
name: spark_binary [7470,7482]
name: spark_binary [7470,7482]
===
match
---
name: self [27355,27359]
name: self [27355,27359]
===
match
---
atom_expr [5401,5414]
atom_expr [5401,5414]
===
match
---
atom [14296,14341]
atom [14296,14341]
===
match
---
name: itr [22593,22596]
name: itr [22593,22596]
===
match
---
name: client [28928,28934]
name: client [28928,28934]
===
match
---
operator: ** [27834,27836]
operator: ** [27834,27836]
===
match
---
operator: , [23105,23106]
operator: , [23105,23106]
===
match
---
name: self [28551,28555]
name: self [28551,28555]
===
match
---
name: join [11785,11789]
name: join [11785,11789]
===
match
---
name: num_executors [7093,7106]
name: num_executors [7093,7106]
===
match
---
string: 'spark_default' [4822,4837]
string: 'spark_default' [4822,4837]
===
match
---
atom_expr [9674,9692]
atom_expr [9674,9692]
===
match
---
trailer [21608,21612]
trailer [21608,21612]
===
match
---
name: endswith [16143,16151]
name: endswith [16143,16151]
===
match
---
operator: = [27831,27832]
operator: = [27831,27832]
===
match
---
operator: = [22813,22814]
operator: = [22813,22814]
===
match
---
operator: , [27312,27313]
operator: , [27312,27313]
===
match
---
trailer [21580,21583]
trailer [21580,21583]
===
match
---
simple_stmt [6343,6367]
simple_stmt [6343,6367]
===
match
---
expr_stmt [28928,28966]
expr_stmt [28928,28966]
===
match
---
trailer [16471,16476]
trailer [16471,16476]
===
match
---
name: self [21604,21608]
name: self [21604,21608]
===
match
---
simple_stmt [28280,28304]
simple_stmt [28280,28304]
===
match
---
name: line [21484,21488]
name: line [21484,21488]
===
match
---
suite [14722,14794]
suite [14722,14794]
===
match
---
name: Any [7315,7318]
name: Any [7315,7318]
===
match
---
name: _archives [13671,13680]
name: _archives [13671,13680]
===
match
---
expr_stmt [6469,6494]
expr_stmt [6469,6494]
===
match
---
name: connection_cmd [13791,13805]
name: connection_cmd [13791,13805]
===
match
---
suite [14995,15061]
suite [14995,15061]
===
match
---
name: self [27193,27197]
name: self [27193,27197]
===
match
---
trailer [19402,19532]
trailer [19402,19532]
===
match
---
string: "--py-files" [13625,13637]
string: "--py-files" [13625,13637]
===
match
---
tfpdef [5690,5725]
tfpdef [5690,5725]
===
match
---
simple_stmt [7449,7483]
simple_stmt [7449,7483]
===
match
---
name: spark_host [16383,16393]
name: spark_host [16383,16393]
===
match
---
trailer [25400,25407]
trailer [25400,25407]
===
match
---
name: subprocess [25195,25205]
name: subprocess [25195,25205]
===
match
---
atom_expr [19167,19199]
atom_expr [19167,19199]
===
match
---
name: Popen [25126,25131]
name: Popen [25126,25131]
===
match
---
trailer [21122,21126]
trailer [21122,21126]
===
match
---
trailer [23101,23110]
trailer [23101,23110]
===
match
---
name: self [14978,14982]
name: self [14978,14982]
===
match
---
string: 'Killing pod %s on Kubernetes' [28698,28728]
string: 'Killing pod %s on Kubernetes' [28698,28728]
===
match
---
trailer [14866,14874]
trailer [14866,14874]
===
match
---
name: _py_files [13644,13653]
name: _py_files [13644,13653]
===
match
---
operator: = [6871,6872]
operator: = [6871,6872]
===
match
---
string: "--exclude-packages" [14088,14108]
string: "--exclude-packages" [14088,14108]
===
match
---
atom_expr [15125,15135]
atom_expr [15125,15135]
===
match
---
atom [12304,12344]
atom [12304,12344]
===
match
---
trailer [7535,7537]
trailer [7535,7537]
===
match
---
param [6226,6248]
param [6226,6248]
===
match
---
atom_expr [6316,6334]
atom_expr [6316,6334]
===
match
---
name: self [7007,7011]
name: self [7007,7011]
===
match
---
operator: = [5287,5288]
operator: = [5287,5288]
===
match
---
trailer [28643,28666]
trailer [28643,28666]
===
match
---
name: Dict [4941,4945]
name: Dict [4941,4945]
===
match
---
name: self [21536,21540]
name: self [21536,21540]
===
match
---
atom_expr [8012,8027]
atom_expr [8012,8027]
===
match
---
operator: , [9720,9721]
operator: , [9720,9721]
===
match
---
trailer [23077,23083]
trailer [23077,23083]
===
match
---
string: "--num-executors" [14297,14314]
string: "--num-executors" [14297,14314]
===
match
---
name: str [5938,5941]
name: str [5938,5941]
===
match
---
trailer [29113,29125]
trailer [29113,29125]
===
match
---
trailer [7314,7319]
trailer [7314,7319]
===
match
---
expr_stmt [8058,8099]
expr_stmt [8058,8099]
===
match
---
suite [22621,23312]
suite [22621,23312]
===
match
---
name: line [23073,23077]
name: line [23073,23077]
===
match
---
trailer [7453,7467]
trailer [7453,7467]
===
match
---
name: self [6503,6507]
name: self [6503,6507]
===
match
---
name: _executor_cores [6808,6823]
name: _executor_cores [6808,6823]
===
match
---
trailer [13758,13777]
trailer [13758,13777]
===
match
---
name: _env_vars [12721,12730]
name: _env_vars [12721,12730]
===
match
---
fstring_expr [27774,27801]
fstring_expr [27774,27801]
===
match
---
operator: , [27608,27609]
operator: , [27608,27609]
===
match
---
expr_stmt [15264,15295]
expr_stmt [15264,15295]
===
match
---
operator: = [4820,4821]
operator: = [4820,4821]
===
match
---
atom_expr [28476,28491]
atom_expr [28476,28491]
===
match
---
testlist_comp [15365,15401]
testlist_comp [15365,15401]
===
match
---
annassign [8027,8049]
annassign [8027,8049]
===
match
---
name: groups [22422,22428]
name: groups [22422,22428]
===
match
---
raise_stmt [17192,17366]
raise_stmt [17192,17366]
===
match
---
trailer [9655,9671]
trailer [9655,9671]
===
match
---
name: connection_cmd [12862,12876]
name: connection_cmd [12862,12876]
===
match
---
name: search [20969,20975]
name: search [20969,20975]
===
match
---
trailer [28948,28964]
trailer [28948,28964]
===
match
---
try_stmt [9012,9980]
try_stmt [9012,9980]
===
match
---
operator: = [8043,8044]
operator: = [8043,8044]
===
match
---
if_stmt [27017,27491]
if_stmt [27017,27491]
===
match
---
atom_expr [28412,28533]
atom_expr [28412,28533]
===
match
---
suite [15251,15296]
suite [15251,15296]
===
match
---
trailer [27331,27336]
trailer [27331,27336]
===
match
---
simple_stmt [1164,1207]
simple_stmt [1164,1207]
===
match
---
name: groups [21086,21092]
name: groups [21086,21092]
===
match
---
trailer [18544,18561]
trailer [18544,18561]
===
match
---
name: kube_client [29379,29390]
name: kube_client [29379,29390]
===
match
---
name: _connection [8552,8563]
name: _connection [8552,8563]
===
match
---
trailer [17145,17156]
trailer [17145,17156]
===
match
---
name: _files [13559,13565]
name: _files [13559,13565]
===
match
---
trailer [14982,14994]
trailer [14982,14994]
===
match
---
name: subprocess [18111,18121]
name: subprocess [18111,18121]
===
match
---
simple_stmt [7257,7281]
simple_stmt [7257,7281]
===
match
---
name: _connection [15500,15511]
name: _connection [15500,15511]
===
match
---
operator: += [15023,15025]
operator: += [15023,15025]
===
match
---
atom [10674,10708]
atom [10674,10708]
===
match
---
trailer [18776,18786]
trailer [18776,18786]
===
match
---
suite [22367,22519]
suite [22367,22519]
===
match
---
string: "Cannot execute: {}. Error code is: {}. Kubernetes spark exit code is: {}" [18665,18739]
string: "Cannot execute: {}. Error code is: {}. Kubernetes spark exit code is: {}" [18665,18739]
===
match
---
name: self [13945,13949]
name: self [13945,13949]
===
match
---
trailer [7836,7902]
trailer [7836,7902]
===
match
---
string: r"(?:secret|password)" [11115,11137]
string: r"(?:secret|password)" [11115,11137]
===
match
---
name: _driver_id [24990,25000]
name: _driver_id [24990,25000]
===
match
---
name: missed_job_status_reports [25583,25608]
name: missed_job_status_reports [25583,25608]
===
match
---
operator: = [5726,5727]
operator: = [5726,5727]
===
match
---
atom_expr [17376,17436]
atom_expr [17376,17436]
===
match
---
name: _env_vars [12467,12476]
name: _env_vars [12467,12476]
===
match
---
operator: , [24983,24984]
operator: , [24983,24984]
===
match
---
suite [25635,25895]
suite [25635,25895]
===
match
---
trailer [26390,26395]
trailer [26390,26395]
===
match
---
operator: , [5341,5342]
operator: , [5341,5342]
===
match
---
operator: , [22500,22501]
operator: , [22500,22501]
===
match
---
operator: , [16435,16436]
operator: , [16435,16436]
===
match
---
import_from [902,956]
import_from [902,956]
===
match
---
name: proxy_user [7026,7036]
name: proxy_user [7026,7036]
===
match
---
atom_expr [8924,8942]
atom_expr [8924,8942]
===
match
---
expr_stmt [25422,25456]
expr_stmt [25422,25456]
===
match
---
string: 'queue' [8816,8823]
string: 'queue' [8816,8823]
===
match
---
trailer [12720,12730]
trailer [12720,12730]
===
match
---
string: 'queue' [9478,9485]
string: 'queue' [9478,9485]
===
match
---
argument [25188,25210]
argument [25188,25210]
===
match
---
simple_stmt [8108,8152]
simple_stmt [8108,8152]
===
match
---
operator: , [10790,10791]
operator: , [10790,10791]
===
match
---
param [5690,5733]
param [5690,5733]
===
match
---
trailer [27279,27337]
trailer [27279,27337]
===
match
---
annassign [7304,7326]
annassign [7304,7326]
===
match
---
name: Any [858,861]
name: Any [858,861]
===
match
---
atom [5038,5069]
atom [5038,5069]
===
match
---
trailer [27671,27676]
trailer [27671,27676]
===
match
---
atom_expr [6435,6449]
atom_expr [6435,6449]
===
match
---
name: self [14702,14706]
name: self [14702,14706]
===
match
---
operator: = [5500,5501]
operator: = [5500,5501]
===
match
---
name: re [22294,22296]
name: re [22294,22296]
===
match
---
operator: , [18816,18817]
operator: , [18816,18817]
===
match
---
atom_expr [10073,10113]
atom_expr [10073,10113]
===
match
---
trailer [14441,14469]
trailer [14441,14469]
===
match
---
simple_stmt [7071,7107]
simple_stmt [7071,7107]
===
match
---
operator: , [5304,5305]
operator: , [5304,5305]
===
match
---
if_stmt [25501,25895]
if_stmt [25501,25895]
===
match
---
operator: = [12714,12715]
operator: = [12714,12715]
===
match
---
trailer [14010,14020]
trailer [14010,14020]
===
match
---
return_stmt [8526,8622]
return_stmt [8526,8622]
===
match
---
name: re [11825,11827]
name: re [11825,11827]
===
match
---
operator: = [7091,7092]
operator: = [7091,7092]
===
match
---
name: str [5495,5498]
name: str [5495,5498]
===
match
---
trailer [10543,10616]
trailer [10543,10616]
===
match
---
trailer [21092,21094]
trailer [21092,21094]
===
match
---
string: r"(?:=|\s+)" [11302,11314]
string: r"(?:=|\s+)" [11302,11314]
===
match
---
name: conn [9438,9442]
name: conn [9438,9442]
===
match
---
name: self [8547,8551]
name: self [8547,8551]
===
match
---
operator: , [27846,27847]
operator: , [27846,27847]
===
match
---
atom [24734,24786]
atom [24734,24786]
===
match
---
name: self [6703,6707]
name: self [6703,6707]
===
match
---
operator: -> [11940,11942]
operator: -> [11940,11942]
===
match
---
name: _conn_id [9185,9193]
name: _conn_id [9185,9193]
===
match
---
argument [28460,28467]
argument [28460,28467]
===
match
---
name: log [28689,28692]
name: log [28689,28692]
===
match
---
atom_expr [12536,12549]
atom_expr [12536,12549]
===
match
---
name: conn_data [9946,9955]
name: conn_data [9946,9955]
===
match
---
name: Optional [5971,5979]
name: Optional [5971,5979]
===
match
---
name: _submit_sp [27661,27671]
name: _submit_sp [27661,27671]
===
match
---
name: self [7115,7119]
name: self [7115,7119]
===
match
---
operator: , [8829,8830]
operator: , [8829,8830]
===
match
---
trailer [8001,8003]
trailer [8001,8003]
===
match
---
atom_expr [20878,20891]
atom_expr [20878,20891]
===
match
---
operator: , [25280,25281]
operator: , [25280,25281]
===
match
---
or_test [8924,8960]
or_test [8924,8960]
===
match
---
trailer [15791,15801]
trailer [15791,15801]
===
match
---
trailer [27368,27490]
trailer [27368,27490]
===
match
---
atom_expr [25435,25456]
atom_expr [25435,25456]
===
match
---
arglist [21771,21802]
arglist [21771,21802]
===
match
---
name: self [17810,17814]
name: self [17810,17814]
===
match
---
name: _spark_binary [8929,8942]
name: _spark_binary [8929,8942]
===
match
---
simple_stmt [17891,17915]
simple_stmt [17891,17915]
===
match
---
suite [11953,15850]
suite [11953,15850]
===
match
---
name: Dict [5242,5246]
name: Dict [5242,5246]
===
match
---
name: _build_track_driver_status_command [25044,25078]
name: _build_track_driver_status_command [25044,25078]
===
match
---
simple_stmt [9430,9456]
simple_stmt [9430,9456]
===
match
---
name: log [9848,9851]
name: log [9848,9851]
===
match
---
trailer [15323,15332]
trailer [15323,15332]
===
match
---
operator: { [27833,27834]
operator: { [27833,27834]
===
match
---
name: self [28209,28213]
name: self [28209,28213]
===
match
---
name: _connection [26309,26320]
name: _connection [26309,26320]
===
match
---
name: env [17891,17894]
name: env [17891,17894]
===
match
---
trailer [17930,17937]
trailer [17930,17937]
===
match
---
operator: , [5506,5507]
operator: , [5506,5507]
===
match
---
simple_stmt [6503,6547]
simple_stmt [6503,6547]
===
match
---
trailer [7874,7884]
trailer [7874,7884]
===
match
---
operator: = [20964,20965]
operator: = [20964,20965]
===
match
---
operator: = [5943,5944]
operator: = [5943,5944]
===
match
---
arglist [17391,17435]
arglist [17391,17435]
===
match
---
atom_expr [29002,29264]
atom_expr [29002,29264]
===
match
---
atom_expr [28639,28666]
atom_expr [28639,28666]
===
match
---
trailer [21085,21092]
trailer [21085,21092]
===
match
---
atom [18515,18567]
atom [18515,18567]
===
match
---
name: connection_cmd [10725,10739]
name: connection_cmd [10725,10739]
===
match
---
operator: += [14750,14752]
operator: += [14750,14752]
===
match
---
name: self [13554,13558]
name: self [13554,13558]
===
match
---
testlist_comp [14535,14580]
testlist_comp [14535,14580]
===
match
---
atom_expr [13037,13051]
atom_expr [13037,13051]
===
match
---
operator: , [25834,25835]
operator: , [25834,25835]
===
match
---
trailer [27779,27800]
trailer [27779,27800]
===
match
---
trailer [13029,13034]
trailer [13029,13034]
===
match
---
name: api_response [28987,28999]
name: api_response [28987,28999]
===
match
---
expr_stmt [4802,4837]
expr_stmt [4802,4837]
===
match
---
atom_expr [19125,19200]
atom_expr [19125,19200]
===
match
---
operator: -> [6299,6301]
operator: -> [6299,6301]
===
match
---
argument [28469,28491]
argument [28469,28491]
===
match
---
name: conn_data [10048,10057]
name: conn_data [10048,10057]
===
match
---
name: _is_yarn [20883,20891]
name: _is_yarn [20883,20891]
===
match
---
trailer [21887,21916]
trailer [21887,21916]
===
match
---
name: _driver_class_path [6508,6526]
name: _driver_class_path [6508,6526]
===
match
---
suite [20661,22552]
suite [20661,22552]
===
match
---
trailer [13873,13879]
trailer [13873,13879]
===
match
---
comp_op [24727,24733]
comp_op [24727,24733]
===
match
---
string: """         Construct the spark-submit command to kill a driver.         :return: full command to kill a driver         """ [25965,26088]
string: """         Construct the spark-submit command to kill a driver.         :return: full command to kill a driver         """ [25965,26088]
===
match
---
trailer [14809,14817]
trailer [14809,14817]
===
match
---
string: 'Spark' [4878,4885]
string: 'Spark' [4878,4885]
===
match
---
name: subprocess [27297,27307]
name: subprocess [27297,27307]
===
match
---
name: _resolve_should_track_driver_status [7966,8001]
name: _resolve_should_track_driver_status [7966,8001]
===
match
---
name: logging_mixin [1120,1133]
name: logging_mixin [1120,1133]
===
match
---
string: r'\s*[eE]xit code: (\d+)' [21771,21796]
string: r'\s*[eE]xit code: (\d+)' [21771,21796]
===
match
---
trailer [27575,27580]
trailer [27575,27580]
===
match
---
string: "KRB5CCNAME" [28328,28340]
string: "KRB5CCNAME" [28328,28340]
===
match
---
operator: , [6216,6217]
operator: , [6216,6217]
===
match
---
trailer [9847,9851]
trailer [9847,9851]
===
match
---
param [5918,5950]
param [5918,5950]
===
match
---
import_as_name [936,956]
import_as_name [936,956]
===
match
---
name: archives [5391,5399]
name: archives [5391,5399]
===
match
---
suite [28667,29538]
suite [28667,29494]
===
match
---
simple_stmt [9646,9738]
simple_stmt [9646,9738]
===
match
---
name: _kubernetes_driver_pod [28644,28666]
name: _kubernetes_driver_pod [28644,28666]
===
match
---
trailer [15907,15912]
trailer [15907,15912]
===
match
---
expr_stmt [7115,7164]
expr_stmt [7115,7164]
===
match
---
string: "--master" [16963,16973]
string: "--master" [16963,16973]
===
match
---
trailer [23200,23237]
trailer [23200,23237]
===
match
---
simple_stmt [9237,9286]
simple_stmt [9237,9286]
===
match
---
atom_expr [28605,28621]
atom_expr [28605,28621]
===
match
---
fstring_string: yarn application -kill  [27751,27774]
fstring_string: yarn application -kill  [27751,27774]
===
match
---
atom_expr [12209,12238]
atom_expr [12209,12238]
===
match
---
name: self [16975,16979]
name: self [16975,16979]
===
match
---
atom_expr [6555,6565]
atom_expr [6555,6565]
===
match
---
if_stmt [22348,22519]
if_stmt [22348,22519]
===
match
---
operator: = [6527,6528]
operator: = [6527,6528]
===
match
---
trailer [11789,11805]
trailer [11789,11805]
===
match
---
simple_stmt [6745,6795]
simple_stmt [6745,6795]
===
match
---
arglist [23201,23236]
arglist [23201,23236]
===
match
---
name: self [13098,13102]
name: self [13098,13102]
===
match
---
string: "--conf" [12881,12889]
string: "--conf" [12881,12889]
===
match
---
name: _total_executor_cores [14447,14468]
name: _total_executor_cores [14447,14468]
===
match
---
name: self [15237,15241]
name: self [15237,15241]
===
match
---
trailer [19133,19139]
trailer [19133,19139]
===
match
---
simple_stmt [28400,28534]
simple_stmt [28400,28534]
===
match
---
name: self [14559,14563]
name: self [14559,14563]
===
match
---
trailer [6707,6721]
trailer [6707,6721]
===
match
---
string: '(application[0-9_]+)' [20976,20998]
string: '(application[0-9_]+)' [20976,20998]
===
match
---
name: Optional [6052,6060]
name: Optional [6052,6060]
===
match
---
if_stmt [19777,20032]
if_stmt [19777,20032]
===
match
---
name: List [25946,25950]
name: List [25946,25950]
===
match
---
name: _connection [16980,16991]
name: _connection [16980,16991]
===
match
---
name: BaseHook [1036,1044]
name: BaseHook [1036,1044]
===
match
---
name: driver_class_path [6529,6546]
name: driver_class_path [6529,6546]
===
match
---
expr_stmt [6941,6962]
expr_stmt [6941,6962]
===
match
---
import_name [809,826]
import_name [809,826]
===
match
---
name: kubernetes [28896,28906]
name: kubernetes [28896,28906]
===
match
---
name: executor_cores [6826,6840]
name: executor_cores [6826,6840]
===
match
---
name: self [27695,27699]
name: self [27695,27699]
===
match
---
name: Any [22607,22610]
name: Any [22607,22610]
===
match
---
arglist [28565,28621]
arglist [28565,28621]
===
match
---
trailer [7370,7375]
trailer [7370,7375]
===
match
---
simple_stmt [4866,4886]
simple_stmt [4866,4886]
===
match
---
operator: , [15123,15124]
operator: , [15123,15124]
===
match
---
name: port [9279,9283]
name: port [9279,9283]
===
match
---
name: _driver_id [16572,16582]
name: _driver_id [16572,16582]
===
match
---
atom_expr [8131,8144]
atom_expr [8131,8144]
===
match
---
operator: = [12207,12208]
operator: = [12207,12208]
===
match
---
trailer [14954,14965]
trailer [14954,14965]
===
match
---
tfpdef [6121,6158]
tfpdef [6121,6158]
===
match
---
name: str [5459,5462]
name: str [5459,5462]
===
match
---
simple_stmt [4771,4798]
simple_stmt [4771,4798]
===
match
---
name: self [21166,21170]
name: self [21166,21170]
===
match
---
expr_stmt [7391,7440]
expr_stmt [7391,7440]
===
match
---
tfpdef [5314,5334]
tfpdef [5314,5334]
===
match
---
simple_stmt [14278,14342]
simple_stmt [14278,14342]
===
match
---
name: kubernetes [1177,1187]
name: kubernetes [1177,1187]
===
match
---
operator: , [5069,5070]
operator: , [5069,5070]
===
match
---
trailer [15801,15817]
trailer [15801,15817]
===
match
---
atom [14195,14233]
atom [14195,14233]
===
match
---
string: 'spark_binary' [10692,10706]
string: 'spark_binary' [10692,10706]
===
match
---
operator: = [4786,4787]
operator: = [4786,4787]
===
match
---
trailer [6975,6986]
trailer [6975,6986]
===
match
---
suite [25484,25895]
suite [25484,25895]
===
match
---
simple_stmt [6971,6999]
simple_stmt [6971,6999]
===
match
---
dotted_name [1102,1133]
dotted_name [1102,1133]
===
match
---
simple_stmt [23186,23238]
simple_stmt [23186,23238]
===
match
---
simple_stmt [12765,12807]
simple_stmt [12765,12807]
===
match
---
name: self [21052,21056]
name: self [21052,21056]
===
match
---
simple_stmt [12192,12239]
simple_stmt [12192,12239]
===
match
---
simple_stmt [6555,6573]
simple_stmt [6555,6573]
===
match
---
string: 'queue' [9499,9506]
string: 'queue' [9499,9506]
===
match
---
operator: , [5047,5048]
operator: , [5047,5048]
===
match
---
operator: = [6011,6012]
operator: = [6011,6012]
===
match
---
simple_stmt [22889,22909]
simple_stmt [22889,22909]
===
match
---
atom_expr [24925,25001]
atom_expr [24925,25001]
===
match
---
operator: , [25321,25322]
operator: , [25321,25322]
===
match
---
trailer [12983,12998]
trailer [12983,12998]
===
match
---
operator: , [13920,13921]
operator: , [13920,13921]
===
match
---
trailer [11015,11840]
trailer [11015,11840]
===
match
---
suite [12748,12807]
suite [12748,12807]
===
match
---
trailer [9784,9797]
trailer [9784,9797]
===
match
---
operator: = [28342,28343]
operator: = [28342,28343]
===
match
---
simple_stmt [8160,8203]
simple_stmt [8160,8203]
===
match
---
for_stmt [22860,23238]
for_stmt [22860,23238]
===
match
---
trailer [7965,8001]
trailer [7965,8001]
===
match
---
operator: + [19486,19487]
operator: + [19486,19487]
===
match
---
name: self [19955,19959]
name: self [19955,19959]
===
match
---
atom [14934,14966]
atom [14934,14966]
===
match
---
trailer [29390,29403]
trailer [29390,29403]
===
match
---
suite [16161,16814]
suite [16161,16814]
===
match
---
fstring_expr [16382,16394]
fstring_expr [16382,16394]
===
match
---
param [6175,6217]
param [6175,6217]
===
match
---
operator: = [6676,6677]
operator: = [6676,6677]
===
match
---
name: self [27503,27507]
name: self [27503,27507]
===
match
---
string: r"\S*?" [11232,11239]
string: r"\S*?" [11232,11239]
===
match
---
trailer [26965,26969]
trailer [26965,26969]
===
match
---
arglist [21132,21191]
arglist [21132,21191]
===
match
---
suite [26912,29538]
suite [26912,29494]
===
match
---
name: _driver_id [22507,22517]
name: _driver_id [22507,22517]
===
match
---
name: Optional [5528,5536]
name: Optional [5528,5536]
===
match
---
atom_expr [27836,27846]
atom_expr [27836,27846]
===
match
---
atom_expr [9342,9351]
atom_expr [9342,9351]
===
match
---
name: self [28639,28643]
name: self [28639,28643]
===
match
---
name: _env_vars [12917,12926]
name: _env_vars [12917,12926]
===
match
---
atom [15196,15225]
atom [15196,15225]
===
match
---
atom_expr [9547,9571]
atom_expr [9547,9571]
===
match
---
expr_stmt [20958,21005]
expr_stmt [20958,21005]
===
match
---
fstring_start: f" [27749,27751]
fstring_start: f" [27749,27751]
===
match
---
trailer [6901,6916]
trailer [6901,6916]
===
match
---
trailer [26439,26451]
trailer [26439,26451]
===
match
---
name: itr [20657,20660]
name: itr [20657,20660]
===
match
---
operator: += [26623,26625]
operator: += [26623,26625]
===
match
---
name: kill_cmd [28450,28458]
name: kill_cmd [28450,28458]
===
match
---
name: info [27111,27115]
name: info [27111,27115]
===
match
---
string: 'spark_binary' [27627,27641]
string: 'spark_binary' [27627,27641]
===
match
---
expr_stmt [13973,14021]
expr_stmt [13973,14021]
===
match
---
atom_expr [12948,12962]
atom_expr [12948,12962]
===
match
---
string: "FINISHED" [19803,19813]
string: "FINISHED" [19803,19813]
===
match
---
string: "Exception when attempting to kill Spark on K8s:" [29445,29494]
string: "Exception when attempting to kill Spark on K8s" [29444,29492]
===
match
---
atom_expr [25039,25080]
atom_expr [25039,25080]
===
match
---
name: _principal [6976,6986]
name: _principal [6976,6986]
===
match
---
dotted_name [1169,1187]
dotted_name [1169,1187]
===
match
---
name: self [18330,18334]
name: self [18330,18334]
===
match
---
trailer [5858,5863]
trailer [5858,5863]
===
match
---
name: str [5577,5580]
name: str [5577,5580]
===
match
---
suite [10171,10185]
suite [10171,10185]
===
match
---
name: List [10226,10230]
name: List [10226,10230]
===
match
---
trailer [18262,18292]
trailer [18262,18292]
===
match
---
expr_stmt [28987,29264]
expr_stmt [28987,29264]
===
match
---
expr_stmt [7223,7248]
expr_stmt [7223,7248]
===
match
---
name: kubernetes [29169,29179]
name: kubernetes [29169,29179]
===
match
---
name: str [15908,15911]
name: str [15908,15911]
===
match
---
operator: , [22324,22325]
operator: , [22324,22325]
===
match
---
trailer [9179,9194]
trailer [9179,9194]
===
match
---
name: status_poll_interval [6082,6102]
name: status_poll_interval [6082,6102]
===
match
---
suite [15165,15226]
suite [15165,15226]
===
match
---
comparison [27917,27944]
comparison [27917,27944]
===
match
---
name: extra [9610,9615]
name: extra [9610,9615]
===
match
---
name: int [21884,21887]
name: int [21884,21887]
===
match
---
expr_stmt [24598,24632]
expr_stmt [24598,24632]
===
match
---
trailer [21617,21681]
trailer [21617,21681]
===
match
---
name: self [23351,23355]
name: self [23351,23355]
===
match
---
trailer [28296,28301]
trailer [28296,28301]
===
match
---
atom_expr [14593,14614]
atom_expr [14593,14614]
===
match
---
name: self [26898,26902]
name: self [26898,26902]
===
match
---
atom [14849,14875]
atom [14849,14875]
===
match
---
name: _executor_cores [14564,14579]
name: _executor_cores [14564,14579]
===
match
---
expr_stmt [7173,7214]
expr_stmt [7173,7214]
===
match
---
string: "Kill Command is being called" [26976,27006]
string: "Kill Command is being called" [26976,27006]
===
match
---
suite [17175,17367]
suite [17175,17367]
===
match
---
name: self [13666,13670]
name: self [13666,13670]
===
match
---
trailer [20912,20927]
trailer [20912,20927]
===
match
---
name: log [22459,22462]
name: log [22459,22462]
===
match
---
atom_expr [19780,19799]
atom_expr [19780,19799]
===
match
---
name: self [15125,15129]
name: self [15125,15129]
===
match
---
atom_expr [12891,12933]
atom_expr [12891,12933]
===
match
---
atom_expr [7391,7418]
atom_expr [7391,7418]
===
match
---
expr_stmt [17791,17855]
expr_stmt [17791,17855]
===
match
---
atom_expr [26713,26728]
atom_expr [26713,26728]
===
match
---
string: 'namespace' [8974,8985]
string: 'namespace' [8974,8985]
===
match
---
simple_stmt [9843,9980]
simple_stmt [9843,9980]
===
match
---
atom_expr [18584,18603]
atom_expr [18584,18603]
===
match
---
testlist_comp [13543,13565]
testlist_comp [13543,13565]
===
match
---
atom_expr [27148,27163]
atom_expr [27148,27163]
===
match
---
trailer [5246,5256]
trailer [5246,5256]
===
match
---
name: self [15043,15047]
name: self [15043,15047]
===
match
---
name: self [23051,23055]
name: self [23051,23055]
===
match
---
name: _connection [8583,8594]
name: _connection [8583,8594]
===
match
---
string: 'spark_binary' [8908,8922]
string: 'spark_binary' [8908,8922]
===
match
---
name: _yarn_application_id [27780,27800]
name: _yarn_application_id [27780,27800]
===
match
---
atom_expr [14353,14379]
atom_expr [14353,14379]
===
match
---
name: py_files [5351,5359]
name: py_files [5351,5359]
===
match
---
atom_expr [22454,22518]
atom_expr [22454,22518]
===
match
---
param [11916,11921]
param [11916,11921]
===
match
---
name: Any [17523,17526]
name: Any [17523,17526]
===
match
---
name: connection_cmd [13524,13538]
name: connection_cmd [13524,13538]
===
match
---
fstring_string: = [12425,12426]
fstring_string: = [12425,12426]
===
match
---
operator: , [5250,5251]
operator: , [5250,5251]
===
match
---
name: env [28324,28327]
name: env [28324,28327]
===
match
---
atom_expr [13639,13653]
atom_expr [13639,13653]
===
match
---
name: self [10583,10587]
name: self [10583,10587]
===
match
---
name: re [11009,11011]
name: re [11009,11011]
===
match
---
suite [9303,9352]
suite [9303,9352]
===
match
---
if_stmt [14350,14471]
if_stmt [14350,14471]
===
match
---
return_stmt [11850,11878]
return_stmt [11850,11878]
===
match
---
name: stderr [27314,27320]
name: stderr [27314,27320]
===
match
---
name: connection_cmd [13606,13620]
name: connection_cmd [13606,13620]
===
match
---
tfpdef [5431,5463]
tfpdef [5431,5463]
===
match
---
name: self [27888,27892]
name: self [27888,27892]
===
match
---
string: "ERROR : Driver {} badly exited with status {}" [19875,19922]
string: "ERROR : Driver {} badly exited with status {}" [19875,19922]
===
match
---
number: 1 [25279,25280]
number: 1 [25279,25280]
===
match
---
operator: = [6634,6635]
operator: = [6634,6635]
===
match
---
atom_expr [21761,21803]
atom_expr [21761,21803]
===
match
---
expr_stmt [26742,26787]
expr_stmt [26742,26787]
===
match
---
atom_expr [27775,27800]
atom_expr [27775,27800]
===
match
---
name: _env_vars [12953,12962]
name: _env_vars [12953,12962]
===
match
---
name: match [21080,21085]
name: match [21080,21085]
===
match
---
if_stmt [15304,15403]
if_stmt [15304,15403]
===
match
---
atom_expr [15749,15818]
atom_expr [15749,15818]
===
match
---
name: info [21613,21617]
name: info [21613,21617]
===
match
---
operator: , [10763,10764]
operator: , [10763,10764]
===
match
---
name: strip [20686,20691]
name: strip [20686,20691]
===
match
---
operator: = [18006,18007]
operator: = [18006,18007]
===
match
---
trailer [22303,22331]
trailer [22303,22331]
===
match
---
string: ' ' [11781,11784]
string: ' ' [11781,11784]
===
match
---
trailer [19853,20031]
trailer [19853,20031]
===
match
---
operator: = [21564,21565]
operator: = [21564,21565]
===
match
---
trailer [13121,13133]
trailer [13121,13133]
===
match
---
argument [18068,18090]
argument [18068,18090]
===
match
---
atom_expr [10048,10070]
atom_expr [10048,10070]
===
match
---
name: connection_cmd [16477,16491]
name: connection_cmd [16477,16491]
===
match
---
expr_stmt [22388,22433]
expr_stmt [22388,22433]
===
match
---
operator: , [18189,18190]
operator: , [18189,18190]
===
match
---
simple_stmt [8760,9003]
simple_stmt [8760,9003]
===
match
---
trailer [28619,28621]
trailer [28619,28621]
===
match
---
tfpdef [22593,22611]
tfpdef [22593,22611]
===
match
---
trailer [15129,15135]
trailer [15129,15135]
===
match
---
atom_expr [22243,22258]
atom_expr [22243,22258]
===
match
---
atom_expr [28324,28341]
atom_expr [28324,28341]
===
match
---
string: """         Processes the log files and extracts useful information out of it.          If the deploy-mode is 'client', log the output of the submit command as those         are the output logs of the Spark worker directly.          Remark: If the driver needs to be tracked for its status, the log-level of the         spark deploy needs to be at least INFO (log4j.logger.org.apache.spark.deploy=INFO)          :param itr: An iterator which iterates over the input of the subprocess         """ [20110,20605]
string: """         Processes the log files and extracts useful information out of it.          If the deploy-mode is 'client', log the output of the submit command as those         are the output logs of the Spark worker directly.          Remark: If the driver needs to be tracked for its status, the log-level of the         spark deploy needs to be at least INFO (log4j.logger.org.apache.spark.deploy=INFO)          :param itr: An iterator which iterates over the input of the subprocess         """ [20110,20605]
===
match
---
operator: = [6722,6723]
operator: = [6722,6723]
===
match
---
name: Iterator [22598,22606]
name: Iterator [22598,22606]
===
match
---
operator: , [12416,12417]
operator: , [12416,12417]
===
match
---
string: '\"' [23119,23123]
string: '\"' [23119,23123]
===
match
---
name: self [24985,24989]
name: self [24985,24989]
===
match
---
import_from [1005,1044]
import_from [1005,1044]
===
match
---
name: debug [19134,19139]
name: debug [19134,19139]
===
match
---
annassign [7418,7440]
annassign [7418,7440]
===
match
---
name: extra [9696,9701]
name: extra [9696,9701]
===
match
---
operator: , [25210,25211]
operator: , [25210,25211]
===
match
---
name: _driver_status [23285,23299]
name: _driver_status [23285,23299]
===
match
---
fstring_expr [12420,12425]
fstring_expr [12420,12425]
===
match
---
name: body [29164,29168]
name: body [29164,29168]
===
match
---
trailer [6473,6483]
trailer [6473,6483]
===
match
---
string: 'login' [5049,5056]
string: 'login' [5049,5056]
===
match
---
name: _resolve_connection [8632,8651]
name: _resolve_connection [8632,8651]
===
match
---
atom_expr [22388,22403]
atom_expr [22388,22403]
===
match
---
atom [13809,13857]
atom [13809,13857]
===
match
---
atom [15026,15060]
atom [15026,15060]
===
match
---
name: stdout [25401,25407]
name: stdout [25401,25407]
===
match
---
expr_stmt [12765,12806]
expr_stmt [12765,12806]
===
match
---
fstring_expr [12426,12448]
fstring_expr [12426,12448]
===
match
---
name: verbose [7273,7280]
name: verbose [7273,7280]
===
match
---
trailer [19929,20013]
trailer [19929,20013]
===
match
---
atom_expr [7071,7090]
atom_expr [7071,7090]
===
match
---
atom_expr [19290,19322]
atom_expr [19290,19322]
===
match
---
atom_expr [28500,28515]
atom_expr [28500,28515]
===
match
---
name: _spark_exit_code [8113,8129]
name: _spark_exit_code [8113,8129]
===
match
---
arith_expr [16683,16795]
arith_expr [16683,16795]
===
match
---
trailer [27808,27810]
trailer [27808,27810]
===
match
---
name: _is_kubernetes [21390,21404]
name: _is_kubernetes [21390,21404]
===
match
---
atom_expr [10226,10235]
atom_expr [10226,10235]
===
match
---
operator: < [25530,25531]
operator: < [25530,25531]
===
match
---
not_test [22239,22258]
not_test [22239,22258]
===
match
---
string: 'queue' [15324,15331]
string: 'queue' [15324,15331]
===
match
---
trailer [18345,18350]
trailer [18345,18350]
===
match
---
arglist [29056,29242]
arglist [29056,29242]
===
match
---
atom_expr [24873,24911]
atom_expr [24873,24911]
===
match
---
atom_expr [7257,7270]
atom_expr [7257,7270]
===
match
---
name: _proxy_user [7012,7023]
name: _proxy_user [7012,7023]
===
match
---
name: _keytab [6946,6953]
name: _keytab [6946,6953]
===
match
---
expr_stmt [17891,17914]
expr_stmt [17891,17914]
===
match
---
fstring_string: spark.kubernetes.namespace= [13413,13440]
fstring_string: spark.kubernetes.namespace= [13413,13440]
===
match
---
name: stdout [25188,25194]
name: stdout [25188,25194]
===
match
---
simple_stmt [8271,8518]
simple_stmt [8271,8518]
===
match
---
name: str [5669,5672]
name: str [5669,5672]
===
match
---
name: self [7173,7177]
name: self [7173,7177]
===
match
---
expr_stmt [25093,25336]
expr_stmt [25093,25336]
===
match
---
atom_expr [22598,22611]
atom_expr [22598,22611]
===
match
---
operator: = [9340,9341]
operator: = [9340,9341]
===
match
---
name: _repositories [14150,14163]
name: _repositories [14150,14163]
===
match
---
simple_stmt [13606,13655]
simple_stmt [13606,13655]
===
match
---
operator: = [18184,18185]
operator: = [18184,18185]
===
match
---
operator: = [7196,7197]
operator: = [7196,7197]
===
match
---
string: "--conf" [13385,13393]
string: "--conf" [13385,13393]
===
match
---
fstring_start: f" [12418,12420]
fstring_start: f" [12418,12420]
===
match
---
name: _application_args [7178,7195]
name: _application_args [7178,7195]
===
match
---
name: copy [28297,28301]
name: copy [28297,28301]
===
match
---
atom_expr [12912,12931]
atom_expr [12912,12931]
===
match
---
simple_stmt [26797,26850]
simple_stmt [26797,26850]
===
match
---
parameters [20066,20092]
parameters [20066,20092]
===
match
---
atom_expr [20681,20693]
atom_expr [20681,20693]
===
match
---
name: int [8140,8143]
name: int [8140,8143]
===
match
---
atom_expr [18772,18804]
atom_expr [18772,18804]
===
match
---
atom_expr [9262,9271]
atom_expr [9262,9271]
===
match
---
name: re [20966,20968]
name: re [20966,20968]
===
match
---
suite [13162,13271]
suite [13162,13271]
===
match
---
arglist [21440,21488]
arglist [21440,21488]
===
match
---
expr_stmt [13791,13857]
expr_stmt [13791,13857]
===
match
---
name: self [13441,13445]
name: self [13441,13445]
===
match
---
simple_stmt [6435,6461]
simple_stmt [6435,6461]
===
match
---
trailer [29294,29299]
trailer [29294,29299]
===
match
---
name: repositories [5646,5658]
name: repositories [5646,5658]
===
match
---
trailer [28692,28697]
trailer [28692,28697]
===
match
---
name: str [5410,5413]
name: str [5410,5413]
===
match
---
simple_stmt [6581,6611]
simple_stmt [6581,6611]
===
match
---
name: log [21123,21126]
name: log [21123,21126]
===
match
---
trailer [23194,23200]
trailer [23194,23200]
===
match
---
trailer [6853,6870]
trailer [6853,6870]
===
match
---
name: super [6316,6321]
name: super [6316,6321]
===
match
---
atom_expr [12716,12730]
atom_expr [12716,12730]
===
match
---
expr_stmt [25583,25613]
expr_stmt [25583,25613]
===
match
---
operator: , [6027,6028]
operator: , [6027,6028]
===
match
---
operator: , [15785,15786]
operator: , [15785,15786]
===
match
---
expr_stmt [4866,4885]
expr_stmt [4866,4885]
===
match
---
trailer [17390,17436]
trailer [17390,17436]
===
match
---
operator: + [16747,16748]
operator: + [16747,16748]
===
match
---
name: self [10675,10679]
name: self [10675,10679]
===
match
---
operator: , [6291,6292]
operator: , [6291,6292]
===
match
---
operator: = [26363,26364]
operator: = [26363,26364]
===
match
---
simple_stmt [10985,11841]
simple_stmt [10985,11841]
===
match
---
name: self [17868,17872]
name: self [17868,17872]
===
match
---
operator: , [15374,15375]
operator: , [15374,15375]
===
match
---
atom_expr [28195,28259]
atom_expr [28195,28259]
===
match
---
trailer [13926,13932]
trailer [13926,13932]
===
match
---
name: get [9553,9556]
name: get [9553,9556]
===
match
---
trailer [7680,7695]
trailer [7680,7695]
===
match
---
expr_stmt [16842,16888]
expr_stmt [16842,16888]
===
match
---
expr_stmt [9750,9797]
expr_stmt [9750,9797]
===
match
---
funcdef [11884,15850]
funcdef [11884,15850]
===
match
---
operator: , [6072,6073]
operator: , [6072,6073]
===
match
---
name: self [13833,13837]
name: self [13833,13837]
===
match
---
simple_stmt [9584,9634]
simple_stmt [9584,9634]
===
match
---
atom_expr [28551,28622]
atom_expr [28551,28622]
===
match
---
string: r"(" [11029,11033]
string: r"(" [11029,11033]
===
match
---
name: _is_kubernetes [7681,7695]
name: _is_kubernetes [7681,7695]
===
match
---
name: conn_data [9750,9759]
name: conn_data [9750,9759]
===
match
---
operator: = [5819,5820]
operator: = [5819,5820]
===
match
---
simple_stmt [789,799]
simple_stmt [789,799]
===
match
---
atom_expr [14316,14340]
atom_expr [14316,14340]
===
match
---
name: log [16468,16471]
name: log [16468,16471]
===
match
---
fstring_start: f" [16380,16382]
fstring_start: f" [16380,16382]
===
match
---
name: _should_track_driver_status [19172,19199]
name: _should_track_driver_status [19172,19199]
===
match
---
name: _connection [10680,10691]
name: _connection [10680,10691]
===
match
---
string: """         Parses the logs of the spark driver status query process          :param itr: An iterator which iterates over the input of the subprocess         """ [22630,22791]
string: """         Parses the logs of the spark driver status query process          :param itr: An iterator which iterates over the input of the subprocess         """ [22630,22791]
===
match
---
funcdef [22557,23312]
funcdef [22557,23312]
===
match
---
name: connection_cmd [14069,14083]
name: connection_cmd [14069,14083]
===
match
---
atom_expr [19955,19970]
atom_expr [19955,19970]
===
match
---
name: info [21127,21131]
name: info [21127,21131]
===
match
---
operator: , [11767,11768]
operator: , [11767,11768]
===
match
---
atom_expr [21884,21916]
atom_expr [21884,21916]
===
match
---
atom_expr [5616,5629]
atom_expr [5616,5629]
===
match
---
name: info [15758,15762]
name: info [15758,15762]
===
match
---
atom_expr [6271,6284]
atom_expr [6271,6284]
===
match
---
atom_expr [7638,7664]
atom_expr [7638,7664]
===
match
---
name: get [9781,9784]
name: get [9781,9784]
===
match
---
tfpdef [6001,6010]
tfpdef [6001,6010]
===
match
---
expr_stmt [12286,12344]
expr_stmt [12286,12344]
===
match
---
name: connection_cmd [14177,14191]
name: connection_cmd [14177,14191]
===
match
---
operator: , [19165,19166]
operator: , [19165,19166]
===
match
---
name: staticmethod [4892,4904]
name: staticmethod [4892,4904]
===
match
---
trailer [28288,28296]
trailer [28288,28296]
===
match
---
atom_expr [9520,9544]
atom_expr [9520,9544]
===
match
---
trailer [14777,14792]
trailer [14777,14792]
===
match
---
simple_stmt [13025,13085]
simple_stmt [13025,13085]
===
match
---
suite [27085,27491]
suite [27085,27491]
===
match
---
trailer [5896,5901]
trailer [5896,5901]
===
match
---
name: jars [5480,5484]
name: jars [5480,5484]
===
match
---
number: 0 [21095,21096]
number: 0 [21095,21096]
===
match
---
operator: , [16362,16363]
operator: , [16362,16363]
===
match
---
name: driver_found [23254,23266]
name: driver_found [23254,23266]
===
match
---
operator: { [5007,5008]
operator: { [5007,5008]
===
match
---
operator: = [27320,27321]
operator: = [27320,27321]
===
match
---
string: 'default-name' [6013,6027]
string: 'default-name' [6013,6027]
===
match
---
string: "spark-submit" [9722,9736]
string: "spark-submit" [9722,9736]
===
match
---
atom_expr [9750,9772]
atom_expr [9750,9772]
===
match
---
name: join [10539,10543]
name: join [10539,10543]
===
match
---
name: self [22243,22247]
name: self [22243,22247]
===
match
---
trailer [7075,7090]
trailer [7075,7090]
===
match
---
name: application_args [7198,7214]
name: application_args [7198,7214]
===
match
---
param [5788,5826]
param [5788,5826]
===
match
---
simple_stmt [24598,24633]
simple_stmt [24598,24633]
===
match
---
name: _kubernetes_driver_pod [7396,7418]
name: _kubernetes_driver_pod [7396,7418]
===
match
---
operator: = [16068,16069]
operator: = [16068,16069]
===
match
---
simple_stmt [21536,21584]
simple_stmt [21536,21584]
===
match
---
number: 10 [24630,24632]
number: 10 [24630,24632]
===
match
---
name: key [12823,12826]
name: key [12823,12826]
===
match
---
trailer [28301,28303]
trailer [28301,28303]
===
match
---
name: self [6407,6411]
name: self [6407,6411]
===
match
---
trailer [5329,5334]
trailer [5329,5334]
===
match
---
atom_expr [18330,18352]
atom_expr [18330,18352]
===
match
---
trailer [9494,9498]
trailer [9494,9498]
===
match
---
trailer [15311,15323]
trailer [15311,15323]
===
match
---
parameters [10157,10163]
parameters [10157,10163]
===
match
---
simple_stmt [902,957]
simple_stmt [902,957]
===
match
---
raise_stmt [19831,20031]
raise_stmt [19831,20031]
===
match
---
trailer [9529,9544]
trailer [9529,9544]
===
match
---
name: key [12927,12930]
name: key [12927,12930]
===
match
---
trailer [6147,6158]
trailer [6147,6158]
===
match
---
name: self [7511,7515]
name: self [7511,7515]
===
match
---
operator: = [7468,7469]
operator: = [7468,7469]
===
match
---
simple_stmt [22630,22792]
simple_stmt [22630,22792]
===
match
---
expr_stmt [21536,21583]
expr_stmt [21536,21583]
===
match
---
name: exit_on_fail [28240,28252]
name: exit_on_fail [28240,28252]
===
match
---
name: _jars [13874,13879]
name: _jars [13874,13879]
===
match
---
name: self [15148,15152]
name: self [15148,15152]
===
match
---
suite [14903,14967]
suite [14903,14967]
===
match
---
suite [25956,26881]
suite [25956,26881]
===
match
---
trailer [7261,7270]
trailer [7261,7270]
===
match
---
argument [28493,28515]
argument [28493,28515]
===
match
---
name: self [7546,7550]
name: self [7546,7550]
===
match
---
operator: -> [25943,25945]
operator: -> [25943,25945]
===
match
---
or_test [12482,12518]
or_test [12482,12518]
===
match
---
name: _driver_id [17146,17156]
name: _driver_id [17146,17156]
===
match
---
trailer [9246,9256]
trailer [9246,9256]
===
match
---
suite [18897,19116]
suite [18897,19116]
===
match
---
string: "UNKNOWN" [23302,23311]
string: "UNKNOWN" [23302,23311]
===
match
---
name: principal [5918,5927]
name: principal [5918,5927]
===
match
---
trailer [13041,13051]
trailer [13041,13051]
===
match
---
atom_expr [17810,17855]
atom_expr [17810,17855]
===
match
---
operator: , [26637,26638]
operator: , [26637,26638]
===
match
---
trailer [7550,7559]
trailer [7550,7559]
===
match
---
name: spark_submit_cmd [19046,19062]
name: spark_submit_cmd [19046,19062]
===
match
---
fstring_string: : [9272,9273]
fstring_string: : [9272,9273]
===
match
---
name: self [13754,13758]
name: self [13754,13758]
===
match
---
name: _connection [27615,27626]
name: _connection [27615,27626]
===
match
---
string: "polling status of spark driver with id %s" [24940,24983]
string: "polling status of spark driver with id %s" [24940,24983]
===
match
---
number: 30 [16070,16072]
number: 30 [16070,16072]
===
match
---
name: List [11943,11947]
name: List [11943,11947]
===
match
---
if_stmt [15411,15528]
if_stmt [15411,15528]
===
match
---
simple_stmt [17545,17783]
simple_stmt [17545,17783]
===
match
---
fstring_end: " [12448,12449]
fstring_end: " [12448,12449]
===
match
---
expr_stmt [7492,7537]
expr_stmt [7492,7537]
===
match
---
operator: } [9001,9002]
operator: } [9001,9002]
===
match
---
atom_expr [12830,12844]
atom_expr [12830,12844]
===
match
---
return_stmt [5000,5110]
return_stmt [5000,5110]
===
match
---
name: _driver_id [8017,8027]
name: _driver_id [8017,8027]
===
match
---
simple_stmt [23374,24317]
simple_stmt [23374,24317]
===
match
---
trailer [21770,21803]
trailer [21770,21803]
===
match
---
name: Optional [8131,8139]
name: Optional [8131,8139]
===
match
---
operator: , [8862,8863]
operator: , [8862,8863]
===
match
---
dotted_name [962,980]
dotted_name [962,980]
===
match
---
atom_expr [13098,13112]
atom_expr [13098,13112]
===
match
---
name: tmpl [12765,12769]
name: tmpl [12765,12769]
===
match
---
simple_stmt [26859,26881]
simple_stmt [26859,26881]
===
match
---
operator: += [14643,14645]
operator: += [14643,14645]
===
match
---
atom_expr [20896,20927]
atom_expr [20896,20927]
===
match
---
name: spark_binary [6257,6269]
name: spark_binary [6257,6269]
===
match
---
name: _should_track_driver_status [27025,27052]
name: _should_track_driver_status [27025,27052]
===
match
---
name: self [10024,10028]
name: self [10024,10028]
===
match
---
trailer [10796,10801]
trailer [10796,10801]
===
match
---
atom_expr [5450,5463]
atom_expr [5450,5463]
===
match
---
trailer [8037,8042]
trailer [8037,8042]
===
match
---
string: "--queue" [15365,15374]
string: "--queue" [15365,15374]
===
match
---
trailer [20975,21005]
trailer [20975,21005]
===
match
---
atom_expr [9489,9507]
atom_expr [9489,9507]
===
match
---
simple_stmt [7289,7327]
simple_stmt [7289,7327]
===
match
---
name: self [25039,25043]
name: self [25039,25043]
===
match
---
name: _num_executors [14250,14264]
name: _num_executors [14250,14264]
===
match
---
tfpdef [20073,20091]
tfpdef [20073,20091]
===
match
---
operator: = [8196,8197]
operator: = [8196,8197]
===
match
---
trailer [21910,21912]
trailer [21910,21912]
===
match
---
simple_stmt [24560,24590]
simple_stmt [24560,24590]
===
match
---
operator: = [6566,6567]
operator: = [6566,6567]
===
match
---
atom_expr [5486,5499]
atom_expr [5486,5499]
===
match
---
operator: = [7627,7628]
operator: = [7627,7628]
===
match
---
string: 'spark://' [8533,8543]
string: 'spark://' [8533,8543]
===
match
---
argument [18104,18128]
argument [18104,18128]
===
match
---
trailer [15721,15739]
trailer [15721,15739]
===
match
---
fstring_start: f" [9259,9261]
fstring_start: f" [9259,9261]
===
match
---
name: info [27364,27368]
name: info [27364,27368]
===
match
---
name: log [15754,15757]
name: log [15754,15757]
===
match
---
name: self [12317,12321]
name: self [12317,12321]
===
match
---
name: str [10787,10790]
name: str [10787,10790]
===
match
---
parameters [8651,8657]
parameters [8651,8657]
===
match
---
expr_stmt [8160,8202]
expr_stmt [8160,8202]
===
match
---
operator: , [1226,1227]
operator: , [1226,1227]
===
match
---
name: wait [27466,27470]
name: wait [27466,27470]
===
match
---
name: port [9215,9219]
name: port [9215,9219]
===
match
---
trailer [10028,10034]
trailer [10028,10034]
===
match
---
trailer [7930,7958]
trailer [7930,7958]
===
match
---
trailer [28356,28360]
trailer [28356,28360]
===
match
---
dotted_name [1050,1075]
dotted_name [1050,1075]
===
match
---
name: self [12431,12435]
name: self [12431,12435]
===
match
---
trailer [15762,15818]
trailer [15762,15818]
===
match
---
trailer [18786,18804]
trailer [18786,18804]
===
match
---
param [5880,5909]
param [5880,5909]
===
match
---
fstring_end: " [27801,27802]
fstring_end: " [27801,27802]
===
match
---
name: self [13869,13873]
name: self [13869,13873]
===
match
---
atom_expr [6581,6597]
atom_expr [6581,6597]
===
match
---
import_name [789,798]
import_name [789,798]
===
match
---
operator: , [8894,8895]
operator: , [8894,8895]
===
match
---
operator: , [11920,11921]
operator: , [11920,11921]
===
match
---
simple_stmt [16081,16121]
simple_stmt [16081,16121]
===
match
---
annassign [8129,8151]
annassign [8129,8151]
===
match
---
name: _connection [26401,26412]
name: _connection [26401,26412]
===
match
---
operator: = [27296,27297]
operator: = [27296,27297]
===
match
---
name: self [10544,10548]
name: self [10544,10548]
===
match
---
atom_expr [21888,21915]
atom_expr [21888,21915]
===
match
---
string: '' [23125,23127]
string: '' [23125,23127]
===
match
---
operator: = [5772,5773]
operator: = [5772,5773]
===
match
---
param [8248,8252]
param [8248,8252]
===
match
---
atom_expr [6803,6823]
atom_expr [6803,6823]
===
match
---
name: split [23078,23083]
name: split [23078,23083]
===
match
---
name: _files [6412,6418]
name: _files [6412,6418]
===
match
---
string: 'spark_home' [26413,26425]
string: 'spark_home' [26413,26425]
===
match
---
operator: , [18211,18212]
operator: , [18211,18212]
===
match
---
trailer [29125,29138]
trailer [29125,29138]
===
match
---
trailer [18643,18879]
trailer [18643,18879]
===
match
---
trailer [10548,10560]
trailer [10548,10560]
===
match
---
arglist [24940,25000]
arglist [24940,25000]
===
match
---
name: self [8058,8062]
name: self [8058,8062]
===
match
---
trailer [17994,18005]
trailer [17994,18005]
===
match
---
atom_expr [24985,25000]
atom_expr [24985,25000]
===
match
---
trailer [7496,7508]
trailer [7496,7508]
===
match
---
name: airflow [962,969]
name: airflow [962,969]
===
match
---
operator: , [19063,19064]
operator: , [19063,19064]
===
match
---
trailer [29202,29204]
trailer [29202,29204]
===
match
---
trailer [14357,14379]
trailer [14357,14379]
===
match
---
name: Any [25109,25112]
name: Any [25109,25112]
===
match
---
operator: += [16959,16961]
operator: += [16959,16961]
===
match
---
trailer [27230,27232]
trailer [27230,27232]
===
match
---
atom_expr [9438,9455]
atom_expr [9438,9455]
===
match
---
trailer [25131,25336]
trailer [25131,25336]
===
match
---
atom_expr [6971,6986]
atom_expr [6971,6986]
===
match
---
trailer [25950,25955]
trailer [25950,25955]
===
match
---
trailer [12540,12549]
trailer [12540,12549]
===
match
---
expr_stmt [13893,13933]
expr_stmt [13893,13933]
===
match
---
name: _num_executors [7076,7090]
name: _num_executors [7076,7090]
===
match
---
param [20073,20091]
param [20073,20091]
===
match
---
name: application [11922,11933]
name: application [11922,11933]
===
match
---
name: self [14033,14037]
name: self [14033,14037]
===
match
---
name: application [17490,17501]
name: application [17490,17501]
===
match
---
if_stmt [16564,16814]
if_stmt [16564,16814]
===
match
---
trailer [26717,26728]
trailer [26717,26728]
===
match
---
simple_stmt [21860,21917]
simple_stmt [21860,21917]
===
match
---
trailer [27580,27643]
trailer [27580,27643]
===
match
---
name: _connection [12322,12333]
name: _connection [12322,12333]
===
match
---
name: yarn_kill [28400,28409]
name: yarn_kill [28400,28409]
===
match
---
expr_stmt [12389,12450]
expr_stmt [12389,12450]
===
match
---
operator: { [16417,16418]
operator: { [16417,16418]
===
match
---
name: self [20878,20882]
name: self [20878,20882]
===
match
---
name: str [5859,5862]
name: str [5859,5862]
===
match
---
testlist_comp [17129,17156]
testlist_comp [17129,17156]
===
match
---
name: LoggingMixin [1141,1153]
name: LoggingMixin [1141,1153]
===
match
---
suite [17536,20032]
suite [17536,20032]
===
match
---
expr_stmt [12704,12730]
expr_stmt [12704,12730]
===
match
---
atom_expr [21385,21404]
atom_expr [21385,21404]
===
match
---
trailer [16197,16205]
trailer [16197,16205]
===
match
---
name: __init__ [5195,5203]
name: __init__ [5195,5203]
===
match
---
name: _connection [20901,20912]
name: _connection [20901,20912]
===
match
---
name: _java_class [15153,15164]
name: _java_class [15153,15164]
===
match
---
name: _principal [14892,14902]
name: _principal [14892,14902]
===
match
---
operator: , [18090,18091]
operator: , [18090,18091]
===
match
---
trailer [18236,18262]
trailer [18236,18262]
===
match
---
suite [16828,17367]
suite [16828,17367]
===
match
---
name: connection_cmd [14916,14930]
name: connection_cmd [14916,14930]
===
match
---
param [6037,6073]
param [6037,6073]
===
match
---
name: kwargs [17515,17521]
name: kwargs [17515,17521]
===
match
---
atom_expr [13441,13470]
atom_expr [13441,13470]
===
match
---
name: self [27523,27527]
name: self [27523,27527]
===
match
---
name: line [22896,22900]
name: line [22896,22900]
===
match
---
name: conn [9153,9157]
name: conn [9153,9157]
===
match
---
simple_stmt [14916,14967]
simple_stmt [14916,14967]
===
match
---
name: kill_cmd [27280,27288]
name: kill_cmd [27280,27288]
===
match
---
name: self [14320,14324]
name: self [14320,14324]
===
match
---
operator: = [28463,28464]
operator: = [28463,28464]
===
match
---
name: self [27020,27024]
name: self [27020,27024]
===
match
---
trailer [22906,22908]
trailer [22906,22908]
===
match
---
simple_stmt [7335,7383]
simple_stmt [7335,7383]
===
match
---
if_stmt [14242,14342]
if_stmt [14242,14342]
===
match
---
arglist [23102,23109]
arglist [23102,23109]
===
match
---
operator: = [9436,9437]
operator: = [9436,9437]
===
match
---
name: self [17990,17994]
name: self [17990,17994]
===
match
---
string: """Returns custom field behaviour""" [4955,4991]
string: """Returns custom field behaviour""" [4955,4991]
===
match
---
name: self [7335,7339]
name: self [7335,7339]
===
match
---
testlist_comp [13992,14020]
testlist_comp [13992,14020]
===
match
---
string: """Kill Spark submit command""" [26921,26952]
string: """Kill Spark submit command""" [26921,26952]
===
match
---
name: _spark_exit_code [18545,18561]
name: _spark_exit_code [18545,18561]
===
match
---
name: replace [23094,23101]
name: replace [23094,23101]
===
match
---
trailer [9477,9486]
trailer [9477,9486]
===
match
---
operator: , [24756,24757]
operator: , [24756,24757]
===
match
---
atom [5097,5099]
atom [5097,5099]
===
match
---
trailer [27838,27846]
trailer [27838,27846]
===
match
---
return_stmt [10123,10139]
return_stmt [10123,10139]
===
match
---
trailer [27614,27626]
trailer [27614,27626]
===
match
---
string: "cluster" [13002,13011]
string: "cluster" [13002,13011]
===
match
---
trailer [28486,28491]
trailer [28486,28491]
===
match
---
name: _mask_cmd [18777,18786]
name: _mask_cmd [18777,18786]
===
match
---
operator: += [13988,13990]
operator: += [13988,13990]
===
match
---
string: "Identified spark driver id: %s" [21132,21164]
string: "Identified spark driver id: %s" [21132,21164]
===
match
---
name: _driver_id [17082,17092]
name: _driver_id [17082,17092]
===
match
---
atom_expr [15237,15250]
atom_expr [15237,15250]
===
match
---
name: _exclude_packages [6658,6675]
name: _exclude_packages [6658,6675]
===
match
---
atom_expr [6407,6418]
atom_expr [6407,6418]
===
match
---
name: _jars [6560,6565]
name: _jars [6560,6565]
===
match
---
name: client [29002,29008]
name: client [29002,29008]
===
match
---
fstring_expr [9273,9284]
fstring_expr [9273,9284]
===
match
---
atom_expr [25386,25407]
atom_expr [25386,25407]
===
match
---
funcdef [10745,11879]
funcdef [10745,11879]
===
match
---
suite [17093,17158]
suite [17093,17158]
===
match
---
simple_stmt [15828,15850]
simple_stmt [15828,15850]
===
match
---
factor [18150,18152]
factor [18150,18152]
===
match
---
name: _connection [26532,26543]
name: _connection [26532,26543]
===
match
---
name: _process_spark_submit_log [18237,18262]
name: _process_spark_submit_log [18237,18262]
===
match
---
trailer [19171,19199]
trailer [19171,19199]
===
match
---
name: _driver_memory [14778,14792]
name: _driver_memory [14778,14792]
===
match
---
string: "--packages" [13992,14004]
string: "--packages" [13992,14004]
===
match
---
name: extra [9775,9780]
name: extra [9775,9780]
===
match
---
operator: += [12877,12879]
operator: += [12877,12879]
===
match
---
atom_expr [7739,7916]
atom_expr [7739,7916]
===
match
---
name: universal_newlines [18166,18184]
name: universal_newlines [18166,18184]
===
match
---
operator: , [5421,5422]
operator: , [5421,5422]
===
match
---
atom_expr [29056,29083]
atom_expr [29056,29083]
===
match
---
name: self [9674,9678]
name: self [9674,9678]
===
match
---
atom_expr [9468,9486]
atom_expr [9468,9486]
===
match
---
operator: } [6365,6366]
operator: } [6365,6366]
===
match
---
operator: -> [17528,17530]
operator: -> [17528,17530]
===
match
---
name: self [12948,12952]
name: self [12948,12952]
===
match
---
trailer [9856,9979]
trailer [9856,9979]
===
match
---
suite [18604,18880]
suite [18604,18880]
===
match
---
name: returncode [18806,18816]
name: returncode [18806,18816]
===
match
---
simple_stmt [15459,15528]
simple_stmt [15459,15528]
===
match
---
name: _verbose [7262,7270]
name: _verbose [7262,7270]
===
match
---
operator: = [25194,25195]
operator: = [25194,25195]
===
match
---
string: "--proxy-user" [15027,15041]
string: "--proxy-user" [15027,15041]
===
match
---
testlist_comp [15197,15224]
testlist_comp [15197,15224]
===
match
---
trailer [5937,5942]
trailer [5937,5942]
===
match
---
operator: = [22404,22405]
operator: = [22404,22405]
===
match
---
operator: = [18149,18150]
operator: = [18149,18150]
===
match
---
expr_stmt [26608,26666]
expr_stmt [26608,26666]
===
match
---
arglist [25149,25322]
arglist [25149,25322]
===
match
---
trailer [23118,23128]
trailer [23118,23128]
===
match
---
name: returncode [25422,25432]
name: returncode [25422,25432]
===
match
---
atom_expr [5242,5256]
atom_expr [5242,5256]
===
match
---
name: airflow [1169,1176]
name: airflow [1169,1176]
===
match
---
operator: } [27800,27801]
operator: } [27800,27801]
===
match
---
simple_stmt [13973,14022]
simple_stmt [13973,14022]
===
match
---
name: str [6007,6010]
name: str [6007,6010]
===
match
---
atom [5007,5110]
atom [5007,5110]
===
match
---
atom_expr [5805,5818]
atom_expr [5805,5818]
===
match
---
expr_stmt [22889,22908]
expr_stmt [22889,22908]
===
match
---
name: _conf [10029,10034]
name: _conf [10029,10034]
===
match
---
name: _driver_id [27442,27452]
name: _driver_id [27442,27452]
===
match
---
if_stmt [17865,17981]
if_stmt [17865,17981]
===
match
---
simple_stmt [19831,20032]
simple_stmt [19831,20032]
===
match
---
name: _proxy_user [15048,15059]
name: _proxy_user [15048,15059]
===
match
---
name: self [12912,12916]
name: self [12912,12916]
===
match
---
comparison [20896,20940]
comparison [20896,20940]
===
match
---
trailer [22296,22303]
trailer [22296,22303]
===
match
---
trailer [5494,5499]
trailer [5494,5499]
===
match
---
tfpdef [5788,5818]
tfpdef [5788,5818]
===
match
---
atom_expr [25115,25336]
atom_expr [25115,25336]
===
match
---
trailer [12895,12902]
trailer [12895,12902]
===
match
---
if_stmt [14975,15061]
if_stmt [14975,15061]
===
match
---
atom_expr [7676,7695]
atom_expr [7676,7695]
===
match
---
trailer [25125,25131]
trailer [25125,25131]
===
match
---
name: principal [6989,6998]
name: principal [6989,6998]
===
match
---
trailer [26400,26412]
trailer [26400,26412]
===
match
---
operator: , [5470,5471]
operator: , [5470,5471]
===
match
---
funcdef [15855,17468]
funcdef [15855,17468]
===
match
---
atom [26365,26482]
atom [26365,26482]
===
match
---
name: _driver_id [19960,19970]
name: _driver_id [19960,19970]
===
match
---
operator: = [6354,6355]
operator: = [6354,6355]
===
match
---
name: log [27572,27575]
name: log [27572,27575]
===
match
---
name: _env_vars [7228,7237]
name: _env_vars [7228,7237]
===
match
---
name: _process_spark_submit_log [20041,20066]
name: _process_spark_submit_log [20041,20066]
===
match
---
name: self [22587,22591]
name: self [22587,22591]
===
match
---
suite [22876,23238]
suite [22876,23238]
===
match
---
operator: = [28252,28253]
operator: = [28252,28253]
===
match
---
name: self [18818,18822]
name: self [18818,18822]
===
match
---
simple_stmt [29430,29496]
simple_stmt [29425,29494]
===
match
---
operator: , [5381,5382]
operator: , [5381,5382]
===
match
---
atom_expr [7335,7360]
atom_expr [7335,7360]
===
match
---
trailer [9619,9633]
trailer [9619,9633]
===
match
---
operator: , [13831,13832]
operator: , [13831,13832]
===
match
---
atom_expr [6897,6916]
atom_expr [6897,6916]
===
match
---
name: _build_spark_submit_command [17815,17842]
name: _build_spark_submit_command [17815,17842]
===
match
---
operator: = [16092,16093]
operator: = [16092,16093]
===
match
---
trailer [21657,21680]
trailer [21657,21680]
===
match
---
name: returncode [25473,25483]
name: returncode [25473,25483]
===
match
---
trailer [9780,9784]
trailer [9780,9784]
===
match
---
operator: , [5636,5637]
operator: , [5636,5637]
===
match
---
string: ':6066' [16152,16159]
string: ':6066' [16152,16159]
===
match
---
operator: = [6159,6160]
operator: = [6159,6160]
===
match
---
expr_stmt [4771,4797]
expr_stmt [4771,4797]
===
match
---
comparison [27523,27553]
comparison [27523,27553]
===
match
---
atom_expr [22532,22551]
atom_expr [22532,22551]
===
match
---
name: Any [8671,8674]
name: Any [8671,8674]
===
match
---
name: self [7676,7680]
name: self [7676,7680]
===
match
---
name: os [17897,17899]
name: os [17897,17899]
===
match
---
atom_expr [22202,22234]
atom_expr [22202,22234]
===
match
---
name: self [27610,27614]
name: self [27610,27614]
===
match
---
atom_expr [18111,18128]
atom_expr [18111,18128]
===
match
---
atom_expr [12365,12375]
atom_expr [12365,12375]
===
match
---
suite [26496,26561]
suite [26496,26561]
===
match
---
name: _driver_class_path [13759,13777]
name: _driver_class_path [13759,13777]
===
match
---
trailer [21763,21770]
trailer [21763,21770]
===
match
---
trailer [23284,23299]
trailer [23284,23299]
===
match
---
suite [1344,29538]
suite [1344,29494]
===
match
---
suite [27554,29538]
suite [27554,29494]
===
match
---
name: connection_cmd [12192,12206]
name: connection_cmd [12192,12206]
===
match
---
name: _driver_status [24712,24726]
name: _driver_status [24712,24726]
===
match
---
name: self [14593,14597]
name: self [14593,14597]
===
match
---
string: "Spark driver %s killed with return code: %s" [27390,27435]
string: "Spark driver %s killed with return code: %s" [27390,27435]
===
match
---
name: self [15894,15898]
name: self [15894,15898]
===
match
---
name: log [1116,1119]
name: log [1116,1119]
===
match
---
suite [13778,13858]
suite [13778,13858]
===
match
---
atom_expr [12317,12343]
atom_expr [12317,12343]
===
match
---
name: self [9931,9935]
name: self [9931,9935]
===
match
---
param [8652,8656]
param [8652,8656]
===
match
---
name: Optional [5361,5369]
name: Optional [5361,5369]
===
match
---
operator: = [5902,5903]
operator: = [5902,5903]
===
match
---
atom_expr [6148,6157]
atom_expr [6148,6157]
===
match
---
name: self [6745,6749]
name: self [6745,6749]
===
match
---
simple_stmt [1045,1097]
simple_stmt [1045,1097]
===
match
---
operator: = [28499,28500]
operator: = [28499,28500]
===
match
---
operator: - [25278,25279]
operator: - [25278,25279]
===
match
---
atom_expr [6343,6353]
atom_expr [6343,6353]
===
match
---
name: Union [895,900]
name: Union [895,900]
===
match
---
atom_expr [6469,6483]
atom_expr [6469,6483]
===
match
---
name: conn [9274,9278]
name: conn [9274,9278]
===
match
---
tfpdef [6226,6239]
tfpdef [6226,6239]
===
match
---
dotted_name [907,928]
dotted_name [907,928]
===
match
---
trailer [5979,5984]
trailer [5979,5984]
===
match
---
name: subprocess [25115,25125]
name: subprocess [25115,25125]
===
match
---
atom_expr [15717,15739]
atom_expr [15717,15739]
===
match
---
name: AirflowException [9813,9829]
name: AirflowException [9813,9829]
===
match
---
trailer [5668,5673]
trailer [5668,5673]
===
match
---
name: _keytab [14867,14874]
name: _keytab [14867,14874]
===
match
---
operator: , [5588,5589]
operator: , [5588,5589]
===
match
---
suite [27721,28623]
suite [27721,28623]
===
match
---
name: str [10231,10234]
name: str [10231,10234]
===
match
---
operator: , [28467,28468]
operator: , [28467,28468]
===
match
---
name: line [21000,21004]
name: line [21000,21004]
===
match
---
operator: = [21882,21883]
operator: = [21882,21883]
===
match
---
operator: , [8669,8670]
operator: , [8669,8670]
===
match
---
name: _spark_binary [7454,7467]
name: _spark_binary [7454,7467]
===
match
---
name: conn_data [10130,10139]
name: conn_data [10130,10139]
===
match
---
trailer [17912,17914]
trailer [17912,17914]
===
match
---
name: subprocess [18008,18018]
name: subprocess [18008,18018]
===
match
---
suite [18568,19116]
suite [18568,19116]
===
match
---
atom_expr [13025,13034]
atom_expr [13025,13034]
===
match
---
expr_stmt [6375,6398]
expr_stmt [6375,6398]
===
match
---
name: self [15414,15418]
name: self [15414,15418]
===
match
---
param [5480,5507]
param [5480,5507]
===
match
---
operator: = [13035,13036]
operator: = [13035,13036]
===
match
---
string: "--keytab" [14850,14860]
string: "--keytab" [14850,14860]
===
match
---
name: Optional [5616,5624]
name: Optional [5616,5624]
===
match
---
atom_expr [6052,6065]
atom_expr [6052,6065]
===
match
---
name: _executor_memory [6854,6870]
name: _executor_memory [6854,6870]
===
match
---
name: line [21798,21802]
name: line [21798,21802]
===
match
---
suite [14164,14234]
suite [14164,14234]
===
match
---
tfpdef [5391,5414]
tfpdef [5391,5414]
===
match
---
trailer [16142,16151]
trailer [16142,16151]
===
match
---
name: host [9347,9351]
name: host [9347,9351]
===
match
---
name: self [12716,12720]
name: self [12716,12720]
===
match
---
name: connection_cmd [15008,15022]
name: connection_cmd [15008,15022]
===
match
---
name: _driver_status [19977,19991]
name: _driver_status [19977,19991]
===
match
---
simple_stmt [7223,7249]
simple_stmt [7223,7249]
===
match
---
trailer [9615,9619]
trailer [9615,9619]
===
match
---
trailer [18822,18839]
trailer [18822,18839]
===
match
---
name: _start_driver_status_tracking [23321,23350]
name: _start_driver_status_tracking [23321,23350]
===
match
---
simple_stmt [16600,16605]
simple_stmt [16600,16605]
===
match
---
name: java_class [6600,6610]
name: java_class [6600,6610]
===
match
---
name: str [5283,5286]
name: str [5283,5286]
===
match
---
simple_stmt [20110,20606]
simple_stmt [20110,20606]
===
match
---
name: str [6280,6283]
name: str [6280,6283]
===
match
---
name: Optional [8029,8037]
name: Optional [8029,8037]
===
match
---
operator: = [25037,25038]
operator: = [25037,25038]
===
match
---
simple_stmt [12862,12935]
simple_stmt [12862,12935]
===
match
---
operator: , [29204,29205]
operator: , [29204,29205]
===
match
---
suite [13681,13743]
suite [13681,13743]
===
match
---
name: self [14950,14954]
name: self [14950,14954]
===
match
---
name: exceptions [970,980]
name: exceptions [970,980]
===
match
---
name: line [22864,22868]
name: line [22864,22868]
===
match
---
trailer [18267,18291]
trailer [18267,18291]
===
match
---
name: self [10759,10763]
name: self [10759,10763]
===
match
---
name: str [11935,11938]
name: str [11935,11938]
===
match
---
param [6121,6166]
param [6121,6166]
===
match
---
atom_expr [21080,21097]
atom_expr [21080,21097]
===
match
---
trailer [25385,25408]
trailer [25385,25408]
===
match
---
operator: = [10511,10512]
operator: = [10511,10512]
===
match
---
suite [13593,13655]
suite [13593,13655]
===
match
---
name: subprocess [816,826]
name: subprocess [816,826]
===
match
---
string: """         Construct the command to poll the driver status.          :return: full command to be executed         """ [15922,16040]
string: """         Construct the command to poll the driver status.          :return: full command to be executed         """ [15922,16040]
===
match
---
operator: } [16433,16434]
operator: } [16433,16434]
===
match
---
name: itr [20073,20076]
name: itr [20073,20076]
===
match
---
name: spark_host [16132,16142]
name: spark_host [16132,16142]
===
match
---
trailer [27626,27642]
trailer [27626,27642]
===
match
---
name: _principal [27922,27932]
name: _principal [27922,27932]
===
match
---
name: flags [11819,11824]
name: flags [11819,11824]
===
match
---
name: match [21509,21514]
name: match [21509,21514]
===
match
---
string: '' [23107,23109]
string: '' [23107,23109]
===
match
---
name: self [9180,9184]
name: self [9180,9184]
===
match
---
for_stmt [20645,22552]
for_stmt [20645,22552]
===
match
---
expr_stmt [6555,6572]
expr_stmt [6555,6572]
===
match
---
atom [14087,14133]
atom [14087,14133]
===
match
---
atom_expr [18268,18290]
atom_expr [18268,18290]
===
match
---
arglist [22304,22330]
arglist [22304,22330]
===
match
---
param [5516,5549]
param [5516,5549]
===
match
---
name: debug [26806,26811]
name: debug [26806,26811]
===
match
---
suite [19363,19533]
suite [19363,19533]
===
match
---
string: "Poll driver status cmd: %s" [17391,17419]
string: "Poll driver status cmd: %s" [17391,17419]
===
match
---
testlist_comp [14297,14340]
testlist_comp [14297,14340]
===
match
---
strings [11029,11712]
strings [11029,11712]
===
match
---
name: Optional [6185,6193]
name: Optional [6185,6193]
===
match
---
operator: , [11712,11713]
operator: , [11712,11713]
===
match
---
trailer [26531,26543]
trailer [26531,26543]
===
match
---
and_test [13098,13161]
and_test [13098,13161]
===
match
---
operator: { [27774,27775]
operator: { [27774,27775]
===
match
---
name: match_exit_code [21888,21903]
name: match_exit_code [21888,21903]
===
match
---
name: configuration [915,928]
name: configuration [915,928]
===
match
---
name: sub [11012,11015]
name: sub [11012,11015]
===
match
---
atom_expr [9274,9283]
atom_expr [9274,9283]
===
match
---
trailer [12435,12441]
trailer [12435,12441]
===
match
---
annassign [8169,8202]
annassign [8169,8202]
===
match
---
string: "--name" [15115,15123]
string: "--name" [15115,15123]
===
match
---
name: connection_cmd [26509,26523]
name: connection_cmd [26509,26523]
===
match
---
tfpdef [10765,10802]
tfpdef [10765,10802]
===
match
---
name: connection_cmd [15699,15713]
name: connection_cmd [15699,15713]
===
match
---
string: "env" [17968,17973]
string: "env" [17968,17973]
===
match
---
trailer [18085,18090]
trailer [18085,18090]
===
match
---
atom_expr [19727,19763]
atom_expr [19727,19763]
===
match
---
trailer [12236,12238]
trailer [12236,12238]
===
match
---
name: self [14110,14114]
name: self [14110,14114]
===
match
---
simple_stmt [21422,21490]
simple_stmt [21422,21490]
===
match
---
name: stdout [18284,18290]
name: stdout [18284,18290]
===
match
---
string: "Cannot execute: {}. Error code is: {}." [18958,18998]
string: "Cannot execute: {}. Error code is: {}." [18958,18998]
===
match
---
name: os [10531,10533]
name: os [10531,10533]
===
match
---
simple_stmt [13524,13567]
simple_stmt [13524,13567]
===
match
---
atom_expr [25350,25409]
atom_expr [25350,25409]
===
match
---
tfpdef [5959,5984]
tfpdef [5959,5984]
===
match
---
name: Any [6204,6207]
name: Any [6204,6207]
===
match
---
trailer [8582,8594]
trailer [8582,8594]
===
match
---
name: _driver_id [22248,22258]
name: _driver_id [22248,22258]
===
match
---
operator: { [12426,12427]
operator: { [12426,12427]
===
match
---
if_stmt [17074,17367]
if_stmt [17074,17367]
===
match
---
operator: , [24766,24767]
operator: , [24766,24767]
===
match
---
string: 'master' [9330,9338]
string: 'master' [9330,9338]
===
match
---
simple_stmt [4955,4992]
simple_stmt [4955,4992]
===
match
---
if_stmt [21820,21917]
if_stmt [21820,21917]
===
match
---
if_stmt [18498,19116]
if_stmt [18498,19116]
===
match
---
trailer [7428,7433]
trailer [7428,7433]
===
match
---
testlist_comp [14412,14469]
testlist_comp [14412,14469]
===
match
---
simple_stmt [7733,7917]
simple_stmt [7733,7917]
===
match
---
name: get_kube_client [28949,28964]
name: get_kube_client [28949,28964]
===
match
---
simple_stmt [21604,21682]
simple_stmt [21604,21682]
===
match
---
name: driver_class_path [5431,5448]
name: driver_class_path [5431,5448]
===
match
---
string: 'spark_home' [26321,26333]
string: 'spark_home' [26321,26333]
===
match
---
operator: = [6987,6988]
operator: = [6987,6988]
===
match
---
atom_expr [15663,15685]
atom_expr [15663,15685]
===
match
---
name: Optional [5450,5458]
name: Optional [5450,5458]
===
match
---
comparison [24707,24786]
comparison [24707,24786]
===
match
---
name: self [12536,12540]
name: self [12536,12540]
===
match
---
string: 'bin' [10576,10581]
string: 'bin' [10576,10581]
===
match
---
atom_expr [15307,15332]
atom_expr [15307,15332]
===
match
---
atom_expr [14978,14994]
atom_expr [14978,14994]
===
match
---
comparison [13117,13161]
comparison [13117,13161]
===
match
---
operator: , [6247,6248]
operator: , [6247,6248]
===
match
---
trailer [27507,27518]
trailer [27507,27518]
===
match
---
trailer [5624,5629]
trailer [5624,5629]
===
match
---
string: "--jars" [13912,13920]
string: "--jars" [13912,13920]
===
match
---
argument [29230,29241]
argument [29230,29241]
===
match
---
name: status_process [25435,25449]
name: status_process [25435,25449]
===
match
---
operator: , [28224,28225]
operator: , [28224,28225]
===
match
---
name: _driver_memory [6902,6916]
name: _driver_memory [6902,6916]
===
match
---
atom [13712,13742]
atom [13712,13742]
===
match
---
trailer [14218,14232]
trailer [14218,14232]
===
match
---
atom_expr [8547,8573]
atom_expr [8547,8573]
===
match
---
operator: , [9929,9930]
operator: , [9929,9930]
===
match
---
name: log [26802,26805]
name: log [26802,26805]
===
match
---
name: self [20896,20900]
name: self [20896,20900]
===
match
---
atom_expr [17927,17948]
atom_expr [17927,17948]
===
match
---
trailer [13731,13741]
trailer [13731,13741]
===
match
---
trailer [22606,22611]
trailer [22606,22611]
===
match
---
import_from [1097,1153]
import_from [1097,1153]
===
match
---
string: "Invalid status: attempted to poll driver " [16683,16726]
string: "Invalid status: attempted to poll driver " [16683,16726]
===
match
---
name: executor_memory [5788,5803]
name: executor_memory [5788,5803]
===
match
---
string: ' : ' [23084,23089]
string: ' : ' [23084,23089]
===
match
---
if_stmt [12533,12807]
if_stmt [12533,12807]
===
match
---
expr_stmt [9430,9455]
expr_stmt [9430,9455]
===
match
---
name: self [14862,14866]
name: self [14862,14866]
===
match
---
expr_stmt [23051,23136]
expr_stmt [23051,23136]
===
match
---
if_stmt [27692,28623]
if_stmt [27692,28623]
===
match
---
name: wait [18346,18350]
name: wait [18346,18350]
===
match
---
name: connection_cmd [15096,15110]
name: connection_cmd [15096,15110]
===
match
---
name: proxy_user [5959,5969]
name: proxy_user [5959,5969]
===
match
---
simple_stmt [16944,17003]
simple_stmt [16944,17003]
===
match
---
comp_op [27901,27907]
comp_op [27901,27907]
===
match
---
trailer [18998,19005]
trailer [18998,19005]
===
match
---
expr_stmt [7257,7280]
expr_stmt [7257,7280]
===
match
---
atom_expr [14668,14689]
atom_expr [14668,14689]
===
match
---
operator: , [28491,28492]
operator: , [28491,28492]
===
match
---
trailer [25678,25894]
trailer [25678,25894]
===
match
---
atom_expr [6849,6870]
atom_expr [6849,6870]
===
match
---
arglist [28698,28757]
arglist [28698,28757]
===
match
---
name: _connection [26644,26655]
name: _connection [26644,26655]
===
match
---
name: self [18540,18544]
name: self [18540,18544]
===
match
---
expr_stmt [16081,16120]
expr_stmt [16081,16120]
===
match
---
name: connection_cmd [15459,15473]
name: connection_cmd [15459,15473]
===
match
---
trailer [16151,16160]
trailer [16151,16160]
===
match
---
testlist_comp [13625,13653]
testlist_comp [13625,13653]
===
match
---
expr_stmt [14735,14793]
expr_stmt [14735,14793]
===
match
---
trailer [17937,17948]
trailer [17937,17948]
===
match
---
tfpdef [11922,11938]
tfpdef [11922,11938]
===
match
---
string: "--executor-cores" [14535,14553]
string: "--executor-cores" [14535,14553]
===
match
---
funcdef [5191,8203]
funcdef [5191,8203]
===
match
---
atom_expr [16567,16582]
atom_expr [16567,16582]
===
match
---
string: "--deploy-mode" [15478,15493]
string: "--deploy-mode" [15478,15493]
===
match
---
atom_expr [22896,22908]
atom_expr [22896,22908]
===
match
---
name: status_process [25386,25400]
name: status_process [25386,25400]
===
match
---
string: 'master' [7875,7883]
string: 'master' [7875,7883]
===
match
---
name: _connection [10588,10599]
name: _connection [10588,10599]
===
match
---
number: 1 [23091,23092]
number: 1 [23091,23092]
===
match
---
trailer [24711,24726]
trailer [24711,24726]
===
match
---
expr_stmt [6407,6426]
expr_stmt [6407,6426]
===
match
---
raise_stmt [7733,7916]
raise_stmt [7733,7916]
===
match
---
name: self [13025,13029]
name: self [13025,13029]
===
match
---
operator: = [6285,6286]
operator: = [6285,6286]
===
match
---
name: self [27069,27073]
name: self [27069,27073]
===
match
---
name: V1DeleteOptions [29187,29202]
name: V1DeleteOptions [29187,29202]
===
match
---
string: 'namespace' [13323,13334]
string: 'namespace' [13323,13334]
===
match
---
string: 'spark_binary' [26544,26558]
string: 'spark_binary' [26544,26558]
===
match
---
trailer [10538,10543]
trailer [10538,10543]
===
match
---
trailer [25354,25380]
trailer [25354,25380]
===
match
---
simple_stmt [26608,26667]
simple_stmt [26608,26667]
===
match
---
factor [25278,25280]
factor [25278,25280]
===
match
---
name: line [20649,20653]
name: line [20649,20653]
===
match
---
param [10217,10221]
param [10217,10221]
===
match
---
atom [15364,15402]
atom [15364,15402]
===
match
---
trailer [23083,23090]
trailer [23083,23090]
===
match
---
name: spark_submit_cmd [18787,18803]
name: spark_submit_cmd [18787,18803]
===
match
---
name: str [8088,8091]
name: str [8088,8091]
===
match
---
trailer [29438,29444]
trailer [29433,29443]
===
match
---
trailer [6279,6284]
trailer [6279,6284]
===
match
---
name: client [29180,29186]
name: client [29180,29186]
===
match
---
atom_expr [27503,27518]
atom_expr [27503,27518]
===
match
---
simple_stmt [839,901]
simple_stmt [839,901]
===
match
---
name: _driver_id [27074,27084]
name: _driver_id [27074,27084]
===
match
---
simple_stmt [6316,6335]
simple_stmt [6316,6335]
===
match
---
suite [15083,15137]
suite [15083,15137]
===
match
---
tfpdef [5558,5581]
tfpdef [5558,5581]
===
match
---
arglist [19140,19199]
arglist [19140,19199]
===
match
---
suite [13012,13085]
suite [13012,13085]
===
match
---
name: submit [17477,17483]
name: submit [17477,17483]
===
match
---
name: self [27851,27855]
name: self [27851,27855]
===
match
---
name: self [14245,14249]
name: self [14245,14249]
===
match
---
trailer [27110,27115]
trailer [27110,27115]
===
match
---
atom_expr [12462,12476]
atom_expr [12462,12476]
===
match
---
operator: == [20928,20930]
operator: == [20928,20930]
===
match
---
trailer [26801,26805]
trailer [26801,26805]
===
match
---
simple_stmt [28928,28967]
simple_stmt [28928,28967]
===
match
---
if_stmt [27066,27491]
if_stmt [27066,27491]
===
match
---
suite [14503,14582]
suite [14503,14582]
===
match
---
expr_stmt [6435,6460]
expr_stmt [6435,6460]
===
match
---
name: self [27148,27152]
name: self [27148,27152]
===
match
---
string: "--files" [13543,13552]
string: "--files" [13543,13552]
===
match
---
string: 'spark_home' [10561,10573]
string: 'spark_home' [10561,10573]
===
match
---
string: "hidden_fields" [5021,5036]
string: "hidden_fields" [5021,5036]
===
match
---
trailer [12902,12933]
trailer [12902,12933]
===
match
---
simple_stmt [6803,6841]
simple_stmt [6803,6841]
===
match
---
name: self [8578,8582]
name: self [8578,8582]
===
match
---
atom_expr [27193,27232]
atom_expr [27193,27232]
===
match
---
name: self [23186,23190]
name: self [23186,23190]
===
match
---
name: self [24707,24711]
name: self [24707,24711]
===
match
---
expr_stmt [23280,23311]
expr_stmt [23280,23311]
===
match
---
operator: = [25113,25114]
operator: = [25113,25114]
===
match
---
name: self [6435,6439]
name: self [6435,6439]
===
match
---
operator: += [15111,15113]
operator: += [15111,15113]
===
match
---
expr_stmt [6971,6998]
expr_stmt [6971,6998]
===
match
---
atom_expr [7306,7319]
atom_expr [7306,7319]
===
match
---
name: get_connection [9165,9179]
name: get_connection [9165,9179]
===
match
---
operator: = [5258,5259]
operator: = [5258,5259]
===
match
---
except_clause [9806,9829]
except_clause [9806,9829]
===
match
---
name: connection_cmd [15346,15360]
name: connection_cmd [15346,15360]
===
match
---
operator: -> [8658,8660]
operator: -> [8658,8660]
===
match
---
expr_stmt [7449,7482]
expr_stmt [7449,7482]
===
match
---
trailer [19129,19133]
trailer [19129,19133]
===
match
---
name: bufsize [18142,18149]
name: bufsize [18142,18149]
===
match
---
expr_stmt [12567,12605]
expr_stmt [12567,12605]
===
match
---
trailer [20086,20091]
trailer [20086,20091]
===
match
---
name: self [12830,12834]
name: self [12830,12834]
===
match
---
trailer [26451,26467]
trailer [26451,26467]
===
match
---
name: os [27836,27838]
name: os [27836,27838]
===
match
---
testlist_comp [14754,14792]
testlist_comp [14754,14792]
===
match
---
trailer [15152,15164]
trailer [15152,15164]
===
match
---
atom_expr [5361,5374]
atom_expr [5361,5374]
===
match
---
operator: , [6165,6166]
operator: , [6165,6166]
===
match
---
suite [8676,10140]
suite [8676,10140]
===
match
---
testlist_comp [13713,13741]
testlist_comp [13713,13741]
===
match
---
expr_stmt [12192,12238]
expr_stmt [12192,12238]
===
match
---
name: self [15495,15499]
name: self [15495,15499]
===
match
---
trailer [18350,18352]
trailer [18350,18352]
===
match
---
name: _name [7050,7055]
name: _name [7050,7055]
===
match
---
import_name [827,838]
import_name [827,838]
===
match
---
name: self [5213,5217]
name: self [5213,5217]
===
match
---
fstring_string: /v1/submissions/status/ [16394,16417]
fstring_string: /v1/submissions/status/ [16394,16417]
===
match
---
trailer [29434,29438]
trailer [29429,29433]
===
match
---
simple_stmt [16842,16889]
simple_stmt [16842,16889]
===
match
---
name: line [23232,23236]
name: line [23232,23236]
===
match
---
name: self [19727,19731]
name: self [19727,19731]
===
match
---
name: conn_data [9320,9329]
name: conn_data [9320,9329]
===
match
---
name: env [28280,28283]
name: env [28280,28283]
===
match
---
trailer [10599,10615]
trailer [10599,10615]
===
match
---
trailer [18334,18345]
trailer [18334,18345]
===
match
---
atom [8772,9002]
atom [8772,9002]
===
match
---
expr_stmt [8760,9002]
expr_stmt [8760,9002]
===
match
---
name: self [7289,7293]
name: self [7289,7293]
===
match
---
string: "--archives" [13713,13725]
string: "--archives" [13713,13725]
===
match
---
string: "{} specified by kubernetes dependencies are not installed!" [7769,7829]
string: "{} specified by kubernetes dependencies are not installed!" [7769,7829]
===
match
---
name: Optional [6271,6279]
name: Optional [6271,6279]
===
match
---
name: Optional [885,893]
name: Optional [885,893]
===
match
---
atom_expr [25662,25894]
atom_expr [25662,25894]
===
match
---
simple_stmt [27827,27869]
simple_stmt [27827,27869]
===
match
---
trailer [15418,15430]
trailer [15418,15430]
===
match
---
expr_stmt [21860,21916]
expr_stmt [21860,21916]
===
match
---
comparison [8578,8622]
comparison [8578,8622]
===
match
---
name: conn_data [9584,9593]
name: conn_data [9584,9593]
===
match
---
name: self [15072,15076]
name: self [15072,15076]
===
match
---
name: tmpl [12567,12571]
name: tmpl [12567,12571]
===
match
---
simple_stmt [27738,27811]
simple_stmt [27738,27811]
===
match
---
trailer [22467,22518]
trailer [22467,22518]
===
match
---
expr_stmt [15699,15739]
expr_stmt [15699,15739]
===
match
---
name: self [22502,22506]
name: self [22502,22506]
===
match
---
name: connection_cmd_masked [10985,11006]
name: connection_cmd_masked [10985,11006]
===
match
---
operator: = [24628,24629]
operator: = [24628,24629]
===
match
---
operator: , [9944,9945]
operator: , [9944,9945]
===
match
---
name: self [7045,7049]
name: self [7045,7049]
===
match
---
suite [16622,16814]
suite [16622,16814]
===
match
---
operator: { [8772,8773]
operator: { [8772,8773]
===
match
---
trailer [28559,28564]
trailer [28559,28564]
===
match
---
trailer [13286,13301]
trailer [13286,13301]
===
match
---
trailer [9442,9455]
trailer [9442,9455]
===
match
---
trailer [25449,25454]
trailer [25449,25454]
===
match
---
trailer [27470,27472]
trailer [27470,27472]
===
match
---
suite [14265,14342]
suite [14265,14342]
===
match
---
operator: = [9608,9609]
operator: = [9608,9609]
===
match
---
string: r"(['\"]?)" [11408,11419]
string: r"(['\"]?)" [11408,11419]
===
match
---
name: kube_client [1195,1206]
name: kube_client [1195,1206]
===
match
---
name: ImportError [1215,1226]
name: ImportError [1215,1226]
===
match
---
name: Optional [8079,8087]
name: Optional [8079,8087]
===
match
---
simple_stmt [7045,7063]
simple_stmt [7045,7063]
===
match
---
trailer [16991,17001]
trailer [16991,17001]
===
match
---
trailer [9346,9351]
trailer [9346,9351]
===
match
---
simple_stmt [11850,11879]
simple_stmt [11850,11879]
===
match
---
param [23351,23355]
param [23351,23355]
===
match
---
name: _executor_memory [14598,14614]
name: _executor_memory [14598,14614]
===
match
---
comparison [23012,23033]
comparison [23012,23033]
===
match
---
name: airflow [907,914]
name: airflow [907,914]
===
match
---
trailer [22540,22545]
trailer [22540,22545]
===
match
---
string: 'master' [9956,9964]
string: 'master' [9956,9964]
===
match
---
trailer [26969,26975]
trailer [26969,26975]
===
match
---
atom_expr [5712,5725]
atom_expr [5712,5725]
===
match
---
trailer [7611,7626]
trailer [7611,7626]
===
match
---
operator: = [28410,28411]
operator: = [28410,28411]
===
match
---
trailer [17872,17877]
trailer [17872,17877]
===
match
---
name: _archives [13732,13741]
name: _archives [13732,13741]
===
match
---
name: _connection [10457,10468]
name: _connection [10457,10468]
===
match
---
name: self [18232,18236]
name: self [18232,18236]
===
match
---
testlist_comp [12881,12933]
testlist_comp [12881,12933]
===
match
---
atom_expr [9843,9979]
atom_expr [9843,9979]
===
match
---
comp_op [27933,27939]
comp_op [27933,27939]
===
match
---
name: kerberos [1067,1075]
name: kerberos [1067,1075]
===
match
---
name: Optional [5850,5858]
name: Optional [5850,5858]
===
match
---
atom_expr [14887,14902]
atom_expr [14887,14902]
===
match
---
name: connection_cmd [16842,16856]
name: connection_cmd [16842,16856]
===
match
---
name: PIPE [18086,18090]
name: PIPE [18086,18090]
===
match
---
atom_expr [13117,13148]
atom_expr [13117,13148]
===
match
---
name: connection_cmd [14278,14292]
name: connection_cmd [14278,14292]
===
match
---
if_stmt [27885,28383]
if_stmt [27885,28383]
===
match
---
name: str [5625,5628]
name: str [5625,5628]
===
match
---
trailer [9552,9556]
trailer [9552,9556]
===
match
---
trailer [15430,15445]
trailer [15430,15445]
===
match
---
name: self [29286,29290]
name: self [29286,29290]
===
match
---
name: str [25951,25954]
name: str [25951,25954]
===
match
---
trailer [19617,19632]
trailer [19617,19632]
===
match
---
if_stmt [13751,13858]
if_stmt [13751,13858]
===
match
---
string: r"(?:(?!\2\s).)*" [11537,11554]
string: r"(?:(?!\2\s).)*" [11537,11554]
===
match
---
name: self [23280,23284]
name: self [23280,23284]
===
match
---
name: connection_cmd [16241,16255]
name: connection_cmd [16241,16255]
===
match
---
atom_expr [18516,18535]
atom_expr [18516,18535]
===
match
---
name: info [28560,28564]
name: info [28560,28564]
===
match
---
name: connection_cmd [14831,14845]
name: connection_cmd [14831,14845]
===
match
---
trailer [23128,23134]
trailer [23128,23134]
===
match
---
if_stmt [27500,29538]
if_stmt [27500,29494]
===
match
---
name: spark_host [16187,16197]
name: spark_host [16187,16197]
===
match
---
atom_expr [5233,5257]
atom_expr [5233,5257]
===
match
---
string: "--master" [26627,26637]
string: "--master" [26627,26637]
===
match
---
name: self [25350,25354]
name: self [25350,25354]
===
match
---
atom_expr [27610,27642]
atom_expr [27610,27642]
===
match
---
name: sleep [24878,24883]
name: sleep [24878,24883]
===
match
---
operator: , [17488,17489]
operator: , [17488,17489]
===
match
---
dictorsetmaker [5021,5100]
dictorsetmaker [5021,5100]
===
match
---
trailer [6657,6675]
trailer [6657,6675]
===
match
---
trailer [14672,14689]
trailer [14672,14689]
===
match
---
string: "spark.yarn.appMasterEnv.{}={}" [12574,12605]
string: "spark.yarn.appMasterEnv.{}={}" [12574,12605]
===
match
---
trailer [13445,13457]
trailer [13445,13457]
===
match
---
string: 'Killing driver %s on cluster' [27116,27146]
string: 'Killing driver %s on cluster' [27116,27146]
===
match
---
trailer [18121,18128]
trailer [18121,18128]
===
match
---
simple_stmt [9153,9195]
simple_stmt [9153,9195]
===
match
---
atom_expr [13306,13335]
atom_expr [13306,13335]
===
match
---
name: self [17141,17145]
name: self [17141,17145]
===
match
---
trailer [28688,28692]
trailer [28688,28692]
===
match
---
param [22587,22592]
param [22587,22592]
===
match
---
arglist [23119,23127]
arglist [23119,23127]
===
match
---
atom_expr [5321,5334]
atom_expr [5321,5334]
===
match
---
atom_expr [14214,14232]
atom_expr [14214,14232]
===
match
---
string: "spark://" [16206,16216]
string: "spark://" [16206,16216]
===
match
---
name: airflow_conf [28344,28356]
name: airflow_conf [28344,28356]
===
match
---
expr_stmt [9468,9507]
expr_stmt [9468,9507]
===
match
---
expr_stmt [23153,23172]
expr_stmt [23153,23172]
===
match
---
simple_stmt [13694,13743]
simple_stmt [13694,13743]
===
match
---
testlist_comp [15027,15059]
testlist_comp [15027,15059]
===
match
---
simple_stmt [26742,26788]
simple_stmt [26742,26788]
===
match
---
trailer [13102,13112]
trailer [13102,13112]
===
match
---
param [17490,17512]
param [17490,17512]
===
match
---
expr_stmt [26509,26560]
expr_stmt [26509,26560]
===
match
---
atom [15594,15607]
atom [15594,15607]
===
match
---
name: poll_drive_status_cmd [25015,25036]
name: poll_drive_status_cmd [25015,25036]
===
match
---
name: _status_poll_interval [7120,7141]
name: _status_poll_interval [7120,7141]
===
match
---
suite [14380,14471]
suite [14380,14471]
===
match
---
trailer [13643,13653]
trailer [13643,13653]
===
match
---
name: self [29056,29060]
name: self [29056,29060]
===
match
---
suite [27945,28383]
suite [27945,28383]
===
match
---
atom_expr [10781,10802]
atom_expr [10781,10802]
===
match
---
name: _yarn_application_id [7340,7360]
name: _yarn_application_id [7340,7360]
===
match
---
string: 'spark-binary' [9706,9720]
string: 'spark-binary' [9706,9720]
===
match
---
trailer [15753,15757]
trailer [15753,15757]
===
match
---
string: "--verbose" [15283,15294]
string: "--verbose" [15283,15294]
===
match
---
trailer [8164,8169]
trailer [8164,8169]
===
match
---
atom_expr [27263,27337]
atom_expr [27263,27337]
===
match
---
name: self [29430,29434]
name: self [29425,29429]
===
match
---
trailer [17380,17384]
trailer [17380,17384]
===
match
---
operator: , [26426,26427]
operator: , [26426,26427]
===
match
---
name: str [16339,16342]
name: str [16339,16342]
===
match
---
trailer [29444,29495]
trailer [29443,29493]
===
match
---
subscriptlist [8185,8193]
subscriptlist [8185,8193]
===
match
---
atom_expr [9160,9194]
atom_expr [9160,9194]
===
match
---
testlist_comp [15478,15526]
testlist_comp [15478,15526]
===
match
---
trailer [23093,23101]
trailer [23093,23101]
===
match
---
atom_expr [8058,8077]
atom_expr [8058,8077]
===
match
---
name: env [28464,28467]
name: env [28464,28467]
===
match
---
atom_expr [12482,12501]
atom_expr [12482,12501]
===
match
---
string: 'schema' [5039,5047]
string: 'schema' [5039,5047]
===
match
---
atom_expr [18665,18861]
atom_expr [18665,18861]
===
match
---
trailer [26775,26786]
trailer [26775,26786]
===
match
---
raise_stmt [18621,18879]
raise_stmt [18621,18879]
===
match
---
param [22593,22611]
param [22593,22611]
===
match
---
number: 0 [21913,21914]
number: 0 [21913,21914]
===
match
---
name: info [28693,28697]
name: info [28693,28697]
===
match
---
trailer [17214,17366]
trailer [17214,17366]
===
match
---
name: _kubernetes_driver_pod [29061,29083]
name: _kubernetes_driver_pod [29061,29083]
===
match
---
operator: , [5991,5992]
operator: , [5991,5992]
===
match
---
trailer [8665,8675]
trailer [8665,8675]
===
match
---
name: self [14773,14777]
name: self [14773,14777]
===
match
---
atom_expr [26961,27007]
atom_expr [26961,27007]
===
match
---
operator: } [16393,16394]
operator: } [16393,16394]
===
match
---
trailer [25078,25080]
trailer [25078,25080]
===
match
---
name: _get_spark_binary_path [10194,10216]
name: _get_spark_binary_path [10194,10216]
===
match
---
if_stmt [28636,29538]
if_stmt [28636,29494]
===
match
---
trailer [16863,16886]
trailer [16863,16886]
===
match
---
arglist [18038,18212]
arglist [18038,18212]
===
match
---
name: poll_drive_status_cmd [25149,25170]
name: poll_drive_status_cmd [25149,25170]
===
match
---
name: groups [21904,21910]
name: groups [21904,21910]
===
match
---
operator: , [24745,24746]
operator: , [24745,24746]
===
match
---
trailer [10587,10599]
trailer [10587,10599]
===
match
---
simple_stmt [7391,7441]
simple_stmt [7391,7441]
===
match
---
string: 'yarn' [7562,7568]
string: 'yarn' [7562,7568]
===
match
---
name: _files [13504,13510]
name: _files [13504,13510]
===
match
---
name: List [6148,6152]
name: List [6148,6152]
===
match
---
arglist [10544,10615]
arglist [10544,10615]
===
match
---
operator: != [18562,18564]
operator: != [18562,18564]
===
match
---
name: format [18740,18746]
name: format [18740,18746]
===
match
---
simple_stmt [24873,24912]
simple_stmt [24873,24912]
===
match
---
name: str [10797,10800]
name: str [10797,10800]
===
match
---
atom_expr [23186,23237]
atom_expr [23186,23237]
===
match
---
atom_expr [28730,28757]
atom_expr [28730,28757]
===
match
---
atom_expr [15414,15445]
atom_expr [15414,15445]
===
match
---
name: _packages [6624,6633]
name: _packages [6624,6633]
===
match
---
name: str [8666,8669]
name: str [8666,8669]
===
match
---
simple_stmt [957,1005]
simple_stmt [957,1005]
===
match
---
trailer [28327,28341]
trailer [28327,28341]
===
match
---
name: PIPE [28487,28491]
name: PIPE [28487,28491]
===
match
---
comparison [19780,19813]
comparison [19780,19813]
===
match
---
operator: = [7434,7435]
operator: = [7434,7435]
===
match
---
trailer [24933,24939]
trailer [24933,24939]
===
match
---
atom_expr [21566,21583]
atom_expr [21566,21583]
===
match
---
trailer [9593,9607]
trailer [9593,9607]
===
match
---
string: 'spark_binary' [26452,26466]
string: 'spark_binary' [26452,26466]
===
match
---
suite [9016,9798]
suite [9016,9798]
===
match
---
operator: = [28935,28936]
operator: = [28935,28936]
===
match
---
trailer [29186,29202]
trailer [29186,29202]
===
match
---
operator: = [6917,6918]
operator: = [6917,6918]
===
match
---
operator: , [5778,5779]
operator: , [5778,5779]
===
match
---
if_stmt [15660,15740]
if_stmt [15660,15740]
===
match
---
operator: = [22894,22895]
operator: = [22894,22895]
===
match
---
trailer [27152,27163]
trailer [27152,27163]
===
match
---
tfpdef [6175,6209]
tfpdef [6175,6209]
===
match
---
name: get_ui_field_behaviour [4913,4935]
name: get_ui_field_behaviour [4913,4935]
===
match
---
simple_stmt [16639,16814]
simple_stmt [16639,16814]
===
match
---
fstring_start: f" [13411,13413]
fstring_start: f" [13411,13413]
===
match
---
trailer [6323,6332]
trailer [6323,6332]
===
match
---
atom_expr [7223,7237]
atom_expr [7223,7237]
===
match
---
operator: = [5582,5583]
operator: = [5582,5583]
===
match
---
atom_expr [29109,29138]
atom_expr [29109,29138]
===
match
---
try_stmt [28864,29538]
try_stmt [28864,29494]
===
match
---
atom_expr [13945,13959]
atom_expr [13945,13959]
===
match
---
name: kwargs [17961,17967]
name: kwargs [17961,17967]
===
match
---
simple_stmt [12704,12731]
simple_stmt [12704,12731]
===
match
---
trailer [21389,21404]
trailer [21389,21404]
===
match
---
simple_stmt [19380,19533]
simple_stmt [19380,19533]
===
match
---
name: extra [9430,9435]
name: extra [9430,9435]
===
match
---
suite [7720,7917]
suite [7720,7917]
===
match
---
trailer [22247,22258]
trailer [22247,22258]
===
match
---
annassign [25107,25336]
annassign [25107,25336]
===
match
---
arglist [28361,28381]
arglist [28361,28381]
===
match
---
trailer [6945,6953]
trailer [6945,6953]
===
match
---
name: self [26527,26531]
name: self [26527,26531]
===
match
---
trailer [6807,6823]
trailer [6807,6823]
===
match
---
name: _connection [7577,7588]
name: _connection [7577,7588]
===
match
---
name: self [19339,19343]
name: self [19339,19343]
===
match
---
operator: = [5864,5865]
operator: = [5864,5865]
===
match
---
testlist_comp [26761,26786]
testlist_comp [26761,26786]
===
match
---
string: """         Determines whether or not this hook should poll the spark driver status through         subsequent spark-submit status requests after the initial spark-submit request         :return: if the driver status should be tracked         """ [8271,8517]
string: """         Determines whether or not this hook should poll the spark driver status through         subsequent spark-submit status requests after the initial spark-submit request         :return: if the driver status should be tracked         """ [8271,8517]
===
match
---
and_test [7676,7719]
and_test [7676,7719]
===
match
---
string: "/usr/bin/curl" [16276,16291]
string: "/usr/bin/curl" [16276,16291]
===
match
---
trailer [13310,13322]
trailer [13310,13322]
===
match
---
param [5835,5871]
param [5835,5871]
===
match
---
operator: = [6240,6241]
operator: = [6240,6241]
===
match
---
trailer [8179,8195]
trailer [8179,8195]
===
match
---
trailer [28555,28559]
trailer [28555,28559]
===
match
---
string: 'deploy_mode' [13134,13147]
string: 'deploy_mode' [13134,13147]
===
match
---
name: executor_memory [6873,6888]
name: executor_memory [6873,6888]
===
match
---
name: int [6061,6064]
name: int [6061,6064]
===
match
---
operator: @ [4891,4892]
operator: @ [4891,4892]
===
match
---
name: _connection [13446,13457]
name: _connection [13446,13457]
===
match
---
atom_expr [7607,7626]
atom_expr [7607,7626]
===
match
---
atom_expr [10024,10034]
atom_expr [10024,10034]
===
match
---
trailer [16422,16433]
trailer [16422,16433]
===
match
---
atom_expr [7858,7884]
atom_expr [7858,7884]
===
match
---
funcdef [25900,26881]
funcdef [25900,26881]
===
match
---
subscriptlist [10787,10801]
subscriptlist [10787,10801]
===
match
---
operator: , [29339,29340]
operator: , [29339,29340]
===
match
---
trailer [17384,17390]
trailer [17384,17390]
===
match
---
atom_expr [10452,10482]
atom_expr [10452,10482]
===
match
---
arglist [15763,15817]
arglist [15763,15817]
===
match
---
trailer [6411,6418]
trailer [6411,6418]
===
match
---
trailer [12952,12962]
trailer [12952,12962]
===
match
---
atom_expr [14438,14469]
atom_expr [14438,14469]
===
match
---
operator: += [14408,14410]
operator: += [14408,14410]
===
match
---
simple_stmt [7007,7037]
simple_stmt [7007,7037]
===
match
---
operator: , [8188,8189]
operator: , [8188,8189]
===
match
---
atom_expr [27567,27643]
atom_expr [27567,27643]
===
match
---
while_stmt [24701,25895]
while_stmt [24701,25895]
===
match
---
trailer [27441,27452]
trailer [27441,27452]
===
match
---
name: conn_data [9468,9477]
name: conn_data [9468,9477]
===
match
---
name: subprocess [28500,28510]
name: subprocess [28500,28510]
===
match
---
trailer [12441,12446]
trailer [12441,12446]
===
match
---
name: log [28556,28559]
name: log [28556,28559]
===
match
---
operator: , [13393,13394]
operator: , [13393,13394]
===
match
---
name: _jars [13927,13932]
name: _jars [13927,13932]
===
match
---
string: "--max-time" [16309,16321]
string: "--max-time" [16309,16321]
===
match
---
name: environ [27839,27846]
name: environ [27839,27846]
===
match
---
and_test [8533,8622]
and_test [8533,8622]
===
match
---
trailer [27527,27538]
trailer [27527,27538]
===
match
---
try_stmt [1155,1249]
try_stmt [1155,1249]
===
match
---
atom_expr [6703,6721]
atom_expr [6703,6721]
===
match
---
atom_expr [14033,14055]
atom_expr [14033,14055]
===
match
---
simple_stmt [12286,12345]
simple_stmt [12286,12345]
===
match
---
import_from [1045,1096]
import_from [1045,1096]
===
match
---
name: path [26386,26390]
name: path [26386,26390]
===
match
---
name: bufsize [25270,25277]
name: bufsize [25270,25277]
===
match
---
atom_expr [17141,17156]
atom_expr [17141,17156]
===
match
---
string: "FINISHED" [24735,24745]
string: "FINISHED" [24735,24745]
===
match
---
simple_stmt [9750,9798]
simple_stmt [9750,9798]
===
match
---
atom_expr [27355,27490]
atom_expr [27355,27490]
===
match
---
atom_expr [8171,8195]
atom_expr [8171,8195]
===
match
---
name: _archives [6474,6483]
name: _archives [6474,6483]
===
match
---
atom [27850,27867]
atom [27850,27867]
===
match
---
operator: += [15591,15593]
operator: += [15591,15593]
===
match
---
expr_stmt [9646,9737]
expr_stmt [9646,9737]
===
match
---
name: self [17484,17488]
name: self [17484,17488]
===
match
---
expr_stmt [7546,7598]
expr_stmt [7546,7598]
===
match
---
name: conf [6356,6360]
name: conf [6356,6360]
===
match
---
except_clause [29372,29408]
except_clause [29372,29403]
===
match
---
name: _is_kubernetes [18589,18603]
name: _is_kubernetes [18589,18603]
===
match
---
name: _executor_memory [14673,14689]
name: _executor_memory [14673,14689]
===
match
---
name: _driver_memory [14707,14721]
name: _driver_memory [14707,14721]
===
match
---
name: str [10807,10810]
name: str [10807,10810]
===
match
---
atom_expr [13727,13741]
atom_expr [13727,13741]
===
match
---
name: AirflowException [19837,19853]
name: AirflowException [19837,19853]
===
match
---
operator: == [13149,13151]
operator: == [13149,13151]
===
match
---
atom_expr [21052,21077]
atom_expr [21052,21077]
===
match
---
string: "Could not load connection string %s, defaulting to %s" [9874,9929]
string: "Could not load connection string %s, defaulting to %s" [9874,9929]
===
match
---
operator: += [13908,13910]
operator: += [13908,13910]
===
match
---
simple_stmt [10496,10631]
simple_stmt [10496,10631]
===
match
---
expr_stmt [28400,28533]
expr_stmt [28400,28533]
===
match
---
string: "Should track driver: %s" [19140,19165]
string: "Should track driver: %s" [19140,19165]
===
match
---
trailer [29060,29083]
trailer [29060,29083]
===
match
---
trailer [28422,28428]
trailer [28422,28428]
===
match
---
name: connection_cmd [15178,15192]
name: connection_cmd [15178,15192]
===
match
---
name: match [21566,21571]
name: match [21566,21571]
===
match
---
trailer [19761,19763]
trailer [19761,19763]
===
match
---
tfpdef [5880,5901]
tfpdef [5880,5901]
===
match
---
name: self [12482,12486]
name: self [12482,12486]
===
match
---
name: debug [23195,23200]
name: debug [23195,23200]
===
match
---
operator: != [19800,19802]
operator: != [19800,19802]
===
match
---
trailer [21864,21881]
trailer [21864,21881]
===
match
---
suite [10035,10114]
suite [10035,10114]
===
match
---
parameters [22586,22612]
parameters [22586,22612]
===
match
---
operator: -> [10223,10225]
operator: -> [10223,10225]
===
match
---
number: 1 [6110,6111]
number: 1 [6110,6111]
===
match
---
name: airflow [1010,1017]
name: airflow [1010,1017]
===
match
---
simple_stmt [16241,16451]
simple_stmt [16241,16451]
===
match
---
name: Optional [5805,5813]
name: Optional [5805,5813]
===
match
---
name: connection_cmd [26866,26880]
name: connection_cmd [26866,26880]
===
match
---
trailer [9851,9856]
trailer [9851,9856]
===
match
---
name: connection_cmd [17421,17435]
name: connection_cmd [17421,17435]
===
match
---
name: self [7858,7862]
name: self [7858,7862]
===
match
---
string: "relabeling" [5083,5095]
string: "relabeling" [5083,5095]
===
match
---
atom_expr [16645,16813]
atom_expr [16645,16813]
===
match
---
name: env [17927,17930]
name: env [17927,17930]
===
match
---
name: info [16472,16476]
name: info [16472,16476]
===
match
---
suite [13511,13567]
suite [13511,13567]
===
match
---
string: 'yarn' [8796,8802]
string: 'yarn' [8796,8802]
===
match
---
name: on_kill [26890,26897]
name: on_kill [26890,26897]
===
match
---
operator: += [12404,12406]
operator: += [12404,12406]
===
match
---
name: connection_cmd [11790,11804]
name: connection_cmd [11790,11804]
===
match
---
name: _build_spark_driver_kill_command [25904,25936]
name: _build_spark_driver_kill_command [25904,25936]
===
match
---
string: 'master' [12334,12342]
string: 'master' [12334,12342]
===
match
---
operator: , [21651,21652]
operator: , [21651,21652]
===
match
---
name: match [21025,21030]
name: match [21025,21030]
===
match
---
name: search [22297,22303]
name: search [22297,22303]
===
match
---
arglist [27581,27642]
arglist [27581,27642]
===
match
---
name: Optional [5888,5896]
name: Optional [5888,5896]
===
match
---
name: match [21422,21427]
name: match [21422,21427]
===
match
---
trailer [22458,22462]
trailer [22458,22462]
===
match
---
atom_expr [18540,18561]
atom_expr [18540,18561]
===
match
---
name: self [14006,14010]
name: self [14006,14010]
===
match
---
trailer [26655,26665]
trailer [26655,26665]
===
match
---
name: RuntimeError [7739,7751]
name: RuntimeError [7739,7751]
===
match
---
and_test [27503,27553]
and_test [27503,27553]
===
match
---
atom_expr [15903,15912]
atom_expr [15903,15912]
===
match
---
arglist [18772,18839]
arglist [18772,18839]
===
match
---
arglist [28209,28258]
arglist [28209,28258]
===
match
---
trailer [14324,14339]
trailer [14324,14339]
===
match
---
name: self [19972,19976]
name: self [19972,19976]
===
match
---
name: _application_args [15668,15685]
name: _application_args [15668,15685]
===
match
---
atom_expr [19613,19632]
atom_expr [19613,19632]
===
match
---
atom_expr [5929,5942]
atom_expr [5929,5942]
===
match
---
atom_expr [9210,9219]
atom_expr [9210,9219]
===
match
---
tfpdef [6257,6284]
tfpdef [6257,6284]
===
match
---
name: Dict [6194,6198]
name: Dict [6194,6198]
===
match
---
name: returncode [18501,18511]
name: returncode [18501,18511]
===
match
---
name: _exclude_packages [14115,14132]
name: _exclude_packages [14115,14132]
===
match
---
atom_expr [14482,14502]
atom_expr [14482,14502]
===
match
---
argument [27290,27312]
argument [27290,27312]
===
match
---
operator: -> [23357,23359]
operator: -> [23357,23359]
===
match
---
atom_expr [7492,7508]
atom_expr [7492,7508]
===
match
---
suite [9830,9980]
suite [9830,9980]
===
match
---
atom_expr [14805,14817]
atom_expr [14805,14817]
===
match
---
trailer [19784,19799]
trailer [19784,19799]
===
match
---
name: info [29295,29299]
name: info [29295,29299]
===
match
---
tfpdef [5274,5286]
tfpdef [5274,5286]
===
match
---
atom_expr [7572,7598]
atom_expr [7572,7598]
===
match
---
name: self [6343,6347]
name: self [6343,6347]
===
match
---
simple_stmt [14831,14876]
simple_stmt [14831,14876]
===
match
---
name: self [12967,12971]
name: self [12967,12971]
===
match
---
operator: = [21428,21429]
operator: = [21428,21429]
===
match
---
name: conn_name_attr [4771,4785]
name: conn_name_attr [4771,4785]
===
match
---
name: PIPE [28511,28515]
name: PIPE [28511,28515]
===
match
---
param [5391,5422]
param [5391,5422]
===
match
---
name: driver_kill [27249,27260]
name: driver_kill [27249,27260]
===
match
---
trailer [15667,15685]
trailer [15667,15685]
===
match
---
trailer [26308,26320]
trailer [26308,26320]
===
match
---
operator: = [10672,10673]
operator: = [10672,10673]
===
match
---
trailer [29030,29264]
trailer [29030,29264]
===
match
---
operator: , [28603,28604]
operator: , [28603,28604]
===
match
---
name: _env_vars [12835,12844]
name: _env_vars [12835,12844]
===
match
---
name: strip [23129,23134]
name: strip [23129,23134]
===
match
---
simple_stmt [12567,12606]
simple_stmt [12567,12606]
===
match
---
string: "--total-executor-cores" [14412,14436]
string: "--total-executor-cores" [14412,14436]
===
match
---
atom_expr [12967,12998]
atom_expr [12967,12998]
===
match
---
trailer [19731,19761]
trailer [19731,19761]
===
match
---
trailer [23090,23093]
trailer [23090,23093]
===
match
---
atom_expr [17897,17914]
atom_expr [17897,17914]
===
match
---
simple_stmt [25965,26089]
simple_stmt [25965,26089]
===
match
---
name: _driver_status [8063,8077]
name: _driver_status [8063,8077]
===
match
---
operator: -> [10164,10166]
operator: -> [10164,10166]
===
match
---
param [5959,5992]
param [5959,5992]
===
match
---
expr_stmt [7926,8003]
expr_stmt [7926,8003]
===
match
---
name: self [19031,19035]
name: self [19031,19035]
===
match
---
name: self [7257,7261]
name: self [7257,7261]
===
match
---
operator: == [8610,8612]
operator: == [8610,8612]
===
match
---
operator: , [18152,18153]
operator: , [18152,18153]
===
match
---
name: _connection [15312,15323]
name: _connection [15312,15323]
===
match
---
simple_stmt [799,809]
simple_stmt [799,809]
===
match
---
arglist [20976,21004]
arglist [20976,21004]
===
match
---
simple_stmt [7926,8004]
simple_stmt [7926,8004]
===
match
---
simple_stmt [28889,28907]
simple_stmt [28889,28907]
===
match
---
name: line [20674,20678]
name: line [20674,20678]
===
match
---
trailer [25380,25409]
trailer [25380,25409]
===
match
---
trailer [11947,11952]
trailer [11947,11952]
===
match
---
return_stmt [15828,15849]
return_stmt [15828,15849]
===
match
---
atom_expr [29286,29354]
atom_expr [29286,29354]
===
match
---
name: self [6581,6585]
name: self [6581,6585]
===
match
---
atom [14534,14581]
atom [14534,14581]
===
match
---
expr_stmt [7071,7106]
expr_stmt [7071,7106]
===
match
---
name: self [22202,22206]
name: self [22202,22206]
===
match
---
trailer [22428,22430]
trailer [22428,22430]
===
match
---
name: copy [17908,17912]
name: copy [17908,17912]
===
match
---
operator: = [19633,19634]
operator: = [19633,19634]
===
match
---
operator: , [21164,21165]
operator: , [21164,21165]
===
match
---
for_stmt [12354,12451]
for_stmt [12354,12451]
===
match
---
atom_expr [17938,17947]
atom_expr [17938,17947]
===
match
---
name: Popen [27274,27279]
name: Popen [27274,27279]
===
match
---
name: self [7449,7453]
name: self [7449,7453]
===
match
---
string: "No driver id is known: something went wrong when executing " [19424,19485]
string: "No driver id is known: something went wrong when executing " [19424,19485]
===
match
---
name: _is_yarn [7551,7559]
name: _is_yarn [7551,7559]
===
match
---
name: status_process [25093,25107]
name: status_process [25093,25107]
===
match
---
name: self [15749,15753]
name: self [15749,15753]
===
match
---
operator: += [25609,25611]
operator: += [25609,25611]
===
match
---
atom_expr [28937,28966]
atom_expr [28937,28966]
===
match
---
string: 'conn_id' [4788,4797]
string: 'conn_id' [4788,4797]
===
match
---
trailer [6585,6597]
trailer [6585,6597]
===
match
---
name: Union [10781,10786]
name: Union [10781,10786]
===
match
---
fstring [13411,13472]
fstring [13411,13472]
===
match
---
trailer [7576,7588]
trailer [7576,7588]
===
match
---
name: self [10217,10221]
name: self [10217,10221]
===
match
---
name: _yarn_application_id [21171,21191]
name: _yarn_application_id [21171,21191]
===
match
---
arglist [26396,26467]
arglist [26396,26467]
===
match
---
atom_expr [14702,14721]
atom_expr [14702,14721]
===
match
---
name: _kubernetes_driver_pod [28735,28757]
name: _kubernetes_driver_pod [28735,28757]
===
match
---
name: Optional [5660,5668]
name: Optional [5660,5668]
===
match
---
name: str [14316,14319]
name: str [14316,14319]
===
match
---
simple_stmt [16049,16073]
simple_stmt [16049,16073]
===
match
---
trailer [21578,21580]
trailer [21578,21580]
===
match
---
fstring [27749,27802]
fstring [27749,27802]
===
match
---
trailer [16979,16991]
trailer [16979,16991]
===
match
---
trailer [25454,25456]
trailer [25454,25456]
===
match
---
atom_expr [26527,26559]
atom_expr [26527,26559]
===
match
---
name: spark_host [16081,16091]
name: spark_host [16081,16091]
===
match
---
atom_expr [19837,20031]
atom_expr [19837,20031]
===
match
---
string: ',' [23102,23105]
string: ',' [23102,23105]
===
match
---
string: "" [17509,17511]
string: "" [17509,17511]
===
match
---
simple_stmt [5000,5111]
simple_stmt [5000,5111]
===
match
---
expr_stmt [27249,27337]
expr_stmt [27249,27337]
===
match
---
trailer [21056,21077]
trailer [21056,21077]
===
match
---
atom [26760,26787]
atom [26760,26787]
===
match
---
name: connection_cmd [10657,10671]
name: connection_cmd [10657,10671]
===
match
---
trailer [12708,12713]
trailer [12708,12713]
===
match
---
fstring_expr [13440,13471]
fstring_expr [13440,13471]
===
match
---
tfpdef [5918,5942]
tfpdef [5918,5942]
===
match
---
name: PIPE [25206,25210]
name: PIPE [25206,25210]
===
match
---
name: self [18268,18272]
name: self [18268,18272]
===
match
---
tfpdef [5516,5541]
tfpdef [5516,5541]
===
match
---
operator: = [5985,5986]
operator: = [5985,5986]
===
match
---
name: conn_id [6391,6398]
name: conn_id [6391,6398]
===
match
---
atom_expr [5758,5771]
atom_expr [5758,5771]
===
match
---
name: self [16567,16571]
name: self [16567,16571]
===
match
---
atom [14411,14470]
atom [14411,14470]
===
match
---
dotted_name [1010,1028]
dotted_name [1010,1028]
===
match
---
simple_stmt [827,839]
simple_stmt [827,839]
===
match
---
name: connection_cmd [15264,15278]
name: connection_cmd [15264,15278]
===
match
---
expr_stmt [13694,13742]
expr_stmt [13694,13742]
===
match
---
trailer [9701,9705]
trailer [9701,9705]
===
match
---
operator: , [17139,17140]
operator: , [17139,17140]
===
match
---
trailer [22506,22517]
trailer [22506,22517]
===
match
---
name: connection_cmd [13973,13987]
name: connection_cmd [13973,13987]
===
match
---
simple_stmt [18621,18880]
simple_stmt [18621,18880]
===
match
---
suite [20101,22552]
suite [20101,22552]
===
match
---
name: self [19125,19129]
name: self [19125,19129]
===
match
---
string: "--executor-memory" [14647,14666]
string: "--executor-memory" [14647,14666]
===
match
---
raise_stmt [25656,25894]
raise_stmt [25656,25894]
===
match
---
name: self [27775,27779]
name: self [27775,27779]
===
match
---
string: 'namespace' [13458,13469]
string: 'namespace' [13458,13469]
===
match
---
simple_stmt [28684,28759]
simple_stmt [28684,28759]
===
match
---
tfpdef [17490,17506]
tfpdef [17490,17506]
===
match
---
trailer [27571,27575]
trailer [27571,27575]
===
match
---
name: py_files [6452,6460]
name: py_files [6452,6460]
===
match
---
param [5227,5265]
param [5227,5265]
===
match
---
atom_expr [7115,7141]
atom_expr [7115,7141]
===
match
---
trailer [15241,15250]
trailer [15241,15250]
===
match
---
import_name [28889,28906]
import_name [28889,28906]
===
match
---
atom_expr [10792,10801]
atom_expr [10792,10801]
===
match
---
name: env [28460,28463]
name: env [28460,28463]
===
match
---
trailer [9184,9193]
trailer [9184,9193]
===
match
---
param [5431,5471]
param [5431,5471]
===
match
---
trailer [7642,7654]
trailer [7642,7654]
===
match
---
string: """         Construct the spark-submit command to execute.          :param application: command to append to the spark-submit command         :type application: str         :return: full command to be executed         """ [11962,12183]
string: """         Construct the spark-submit command to execute.          :param application: command to append to the spark-submit command         :type application: str         :return: full command to be executed         """ [11962,12183]
===
match
---
operator: = [21078,21079]
operator: = [21078,21079]
===
match
---
name: get [9495,9498]
name: get [9495,9498]
===
match
---
name: self [6375,6379]
name: self [6375,6379]
===
match
---
simple_stmt [27102,27165]
simple_stmt [27102,27165]
===
match
---
name: connection_cmd [14628,14642]
name: connection_cmd [14628,14642]
===
match
---
trailer [27921,27932]
trailer [27921,27932]
===
match
---
atom_expr [7769,7902]
atom_expr [7769,7902]
===
match
---
name: iter [18263,18267]
name: iter [18263,18267]
===
match
---
suite [23267,23312]
suite [23267,23312]
===
match
---
atom_expr [13578,13592]
atom_expr [13578,13592]
===
match
---
string: 'cluster' [8613,8622]
string: 'cluster' [8613,8622]
===
match
---
suite [15913,17468]
suite [15913,17468]
===
match
---
if_stmt [9207,9352]
if_stmt [9207,9352]
===
match
---
atom_expr [14110,14132]
atom_expr [14110,14132]
===
match
---
name: _resolve_should_track_driver_status [8212,8247]
name: _resolve_should_track_driver_status [8212,8247]
===
match
---
name: connection_cmd [10496,10510]
name: connection_cmd [10496,10510]
===
match
---
simple_stmt [9320,9352]
simple_stmt [9320,9352]
===
match
---
atom_expr [8079,8092]
atom_expr [8079,8092]
===
match
---
name: _submit_sp [17995,18005]
name: _submit_sp [17995,18005]
===
match
---
suite [14056,14134]
suite [14056,14134]
===
match
---
param [6001,6028]
param [6001,6028]
===
match
---
name: os [26383,26385]
name: os [26383,26385]
===
match
---
name: conn_data [9237,9246]
name: conn_data [9237,9246]
===
match
---
name: _submit_sp [27528,27538]
name: _submit_sp [27528,27538]
===
match
---
atom_expr [27917,27932]
atom_expr [27917,27932]
===
match
---
expr_stmt [17961,17980]
expr_stmt [17961,17980]
===
match
---
operator: = [17808,17809]
operator: = [17808,17809]
===
match
---
atom [27864,27866]
atom [27864,27866]
===
match
---
operator: = [9487,9488]
operator: = [9487,9488]
===
match
---
atom_expr [16339,16362]
atom_expr [16339,16362]
===
match
---
atom_expr [23280,23299]
atom_expr [23280,23299]
===
match
---
name: files [6421,6426]
name: files [6421,6426]
===
match
---
operator: , [29138,29139]
operator: , [29138,29139]
===
match
---
atom_expr [28286,28303]
atom_expr [28286,28303]
===
match
---
trailer [5458,5463]
trailer [5458,5463]
===
match
---
atom_expr [19386,19532]
atom_expr [19386,19532]
===
match
---
operator: , [27288,27289]
operator: , [27288,27289]
===
match
---
subscriptlist [8666,8674]
subscriptlist [8666,8674]
===
match
---
simple_stmt [19613,19647]
simple_stmt [19613,19647]
===
match
---
operator: -> [4938,4940]
operator: -> [4938,4940]
===
match
---
raise_stmt [16639,16813]
raise_stmt [16639,16813]
===
match
---
simple_stmt [6941,6963]
simple_stmt [6941,6963]
===
match
---
name: _conf [12436,12441]
name: _conf [12436,12441]
===
match
---
expr_stmt [22800,22820]
expr_stmt [22800,22820]
===
match
---
name: total_executor_cores [6774,6794]
name: total_executor_cores [6774,6794]
===
match
---
name: self [21860,21864]
name: self [21860,21864]
===
match
---
operator: } [13470,13471]
operator: } [13470,13471]
===
match
---
atom_expr [22294,22331]
atom_expr [22294,22331]
===
match
---
string: "spark-submit" [8946,8960]
string: "spark-submit" [8946,8960]
===
match
---
operator: , [883,884]
operator: , [883,884]
===
match
---
testlist_comp [14935,14965]
testlist_comp [14935,14965]
===
match
---
trailer [8112,8129]
trailer [8112,8129]
===
match
---
suite [25562,25614]
suite [25562,25614]
===
match
---
operator: , [14108,14109]
operator: , [14108,14109]
===
match
---
simple_stmt [7607,7665]
simple_stmt [7607,7665]
===
match
---
trailer [15757,15762]
trailer [15757,15762]
===
match
---
simple_stmt [17791,17856]
simple_stmt [17791,17856]
===
match
---
operator: , [5099,5100]
operator: , [5099,5100]
===
match
---
argument [18203,18211]
argument [18203,18211]
===
match
---
and_test [12948,13011]
and_test [12948,13011]
===
match
---
atom_expr [17990,18005]
atom_expr [17990,18005]
===
match
---
trailer [14149,14163]
trailer [14149,14163]
===
match
---
string: "the spark submit command" [19488,19514]
string: "the spark submit command" [19488,19514]
===
match
---
trailer [15499,15511]
trailer [15499,15511]
===
match
---
string: 'ccache' [28373,28381]
string: 'ccache' [28373,28381]
===
match
---
suite [8262,8623]
suite [8262,8623]
===
match
---
atom [10513,10630]
atom [10513,10630]
===
match
---
name: debug [24934,24939]
name: debug [24934,24939]
===
match
---
trailer [6439,6449]
trailer [6439,6449]
===
match
---
trailer [12213,12236]
trailer [12213,12236]
===
match
---
operator: , [28238,28239]
operator: , [28238,28239]
===
match
---
suite [1239,1249]
suite [1239,1249]
===
match
---
trailer [9556,9571]
trailer [9556,9571]
===
match
---
arglist [29300,29353]
arglist [29300,29353]
===
match
---
name: _should_track_driver_status [19295,19322]
name: _should_track_driver_status [19295,19322]
===
match
---
trailer [8928,8942]
trailer [8928,8942]
===
match
---
string: 'Sending kill signal to %s' [27581,27608]
string: 'Sending kill signal to %s' [27581,27608]
===
match
---
atom_expr [15376,15401]
atom_expr [15376,15401]
===
match
---
operator: = [21759,21760]
operator: = [21759,21760]
===
match
---
trailer [18746,18861]
trailer [18746,18861]
===
match
---
name: match_driver_id [22406,22421]
name: match_driver_id [22406,22421]
===
match
---
suite [12520,12935]
suite [12520,12935]
===
match
---
trailer [12369,12375]
trailer [12369,12375]
===
match
---
trailer [19294,19322]
trailer [19294,19322]
===
match
---
trailer [24929,24933]
trailer [24929,24933]
===
match
---
operator: = [5542,5543]
operator: = [5542,5543]
===
match
---
suite [10483,10631]
suite [10483,10631]
===
match
---
name: api_response [29341,29353]
name: api_response [29341,29353]
===
match
---
trailer [25775,25872]
trailer [25775,25872]
===
match
---
if_stmt [14802,14876]
if_stmt [14802,14876]
===
match
---
name: repositories [6724,6736]
name: repositories [6724,6736]
===
match
---
expr_stmt [7289,7326]
expr_stmt [7289,7326]
===
match
---
operator: , [15493,15494]
operator: , [15493,15494]
===
match
---
operator: = [18074,18075]
operator: = [18074,18075]
===
match
---
name: format [12896,12902]
name: format [12896,12902]
===
match
---
operator: = [9773,9774]
operator: = [9773,9774]
===
match
---
name: _conn_id [6380,6388]
name: _conn_id [6380,6388]
===
match
---
name: Optional [5568,5576]
name: Optional [5568,5576]
===
match
---
atom_expr [22502,22517]
atom_expr [22502,22517]
===
match
---
trailer [11011,11015]
trailer [11011,11015]
===
match
---
name: _resolve_connection [7516,7535]
name: _resolve_connection [7516,7535]
===
match
---
operator: , [24776,24777]
operator: , [24776,24777]
===
match
---
name: self [22532,22536]
name: self [22532,22536]
===
match
---
trailer [24989,25000]
trailer [24989,25000]
===
match
---
expr_stmt [7045,7062]
expr_stmt [7045,7062]
===
match
---
operator: += [13539,13541]
operator: += [13539,13541]
===
match
---
trailer [19045,19063]
trailer [19045,19063]
===
match
---
operator: = [10071,10072]
operator: = [10071,10072]
===
match
---
atom_expr [28684,28758]
atom_expr [28684,28758]
===
match
---
expr_stmt [18317,18352]
expr_stmt [18317,18352]
===
match
---
simple_stmt [23051,23137]
simple_stmt [23051,23137]
===
match
---
operator: = [27261,27262]
operator: = [27261,27262]
===
match
---
name: self [13306,13310]
name: self [13306,13310]
===
match
---
name: _connection [13311,13322]
name: _connection [13311,13322]
===
match
---
string: "status but no driver id is known. Giving up." [16749,16795]
string: "status but no driver id is known. Giving up." [16749,16795]
===
match
---
name: self [13922,13926]
name: self [13922,13926]
===
match
---
trailer [26805,26811]
trailer [26805,26811]
===
match
---
expr_stmt [14393,14470]
expr_stmt [14393,14470]
===
match
---
name: keytab [5880,5886]
name: keytab [5880,5886]
===
match
---
operator: } [9283,9284]
operator: } [9283,9284]
===
match
---
arglist [27116,27163]
arglist [27116,27163]
===
match
---
simple_stmt [16174,16229]
simple_stmt [16174,16229]
===
match
---
funcdef [10145,10185]
funcdef [10145,10185]
===
match
---
operator: , [22591,22592]
operator: , [22591,22592]
===
match
---
name: _py_files [13583,13592]
name: _py_files [13583,13592]
===
match
---
operator: , [21482,21483]
operator: , [21482,21483]
===
match
---
trailer [20968,20975]
trailer [20968,20975]
===
match
---
trailer [13558,13565]
trailer [13558,13565]
===
match
---
string: "--driver-memory" [14754,14771]
string: "--driver-memory" [14754,14771]
===
match
---
operator: , [6111,6112]
operator: , [6111,6112]
===
match
---
name: _yarn_application_id [27700,27720]
name: _yarn_application_id [27700,27720]
===
match
---
simple_stmt [6703,6737]
simple_stmt [6703,6737]
===
match
---
return_stmt [17446,17467]
return_stmt [17446,17467]
===
match
---
trailer [21126,21131]
trailer [21126,21131]
===
match
---
expr_stmt [6745,6794]
expr_stmt [6745,6794]
===
match
---
name: _driver_class_path [13838,13856]
name: _driver_class_path [13838,13856]
===
match
---
trailer [14037,14055]
trailer [14037,14055]
===
match
---
tfpdef [5480,5499]
tfpdef [5480,5499]
===
match
---
atom_expr [7546,7559]
atom_expr [7546,7559]
===
match
---
string: 'master' [16992,17000]
string: 'master' [16992,17000]
===
match
---
string: "driverState" [23012,23025]
string: "driverState" [23012,23025]
===
match
---
atom [15477,15527]
atom [15477,15527]
===
match
---
expr_stmt [10985,11840]
expr_stmt [10985,11840]
===
match
---
trailer [28213,28224]
trailer [28213,28224]
===
match
---
operator: , [12889,12890]
operator: , [12889,12890]
===
match
---
simple_stmt [14516,14582]
simple_stmt [14516,14582]
===
match
---
name: _driver_id [16423,16433]
name: _driver_id [16423,16433]
===
match
---
number: 1 [18151,18152]
number: 1 [18151,18152]
===
match
---
trailer [25245,25252]
trailer [25245,25252]
===
match
---
simple_stmt [19727,19764]
simple_stmt [19727,19764]
===
match
---
argument [28240,28258]
argument [28240,28258]
===
match
---
name: executor_cores [5742,5756]
name: executor_cores [5742,5756]
===
match
---
operator: = [23300,23301]
operator: = [23300,23301]
===
match
---
operator: , [19970,19971]
operator: , [19970,19971]
===
match
---
name: key [12903,12906]
name: key [12903,12906]
===
match
---
fstring [16380,16435]
fstring [16380,16435]
===
match
---
number: 0 [22431,22432]
number: 0 [22431,22432]
===
match
---
name: self [13578,13582]
name: self [13578,13582]
===
match
---
name: str [7371,7374]
name: str [7371,7374]
===
match
---
name: int [5721,5724]
name: int [5721,5724]
===
match
---
string: 'k8s' [7629,7634]
string: 'k8s' [7629,7634]
===
match
---
name: self [21653,21657]
name: self [21653,21657]
===
match
---
name: time [24873,24877]
name: time [24873,24877]
===
match
---
operator: , [14553,14554]
operator: , [14553,14554]
===
match
---
operator: += [14293,14295]
operator: += [14293,14295]
===
match
---
name: str [8038,8041]
name: str [8038,8041]
===
match
---
trailer [13457,13470]
trailer [13457,13470]
===
match
---
simple_stmt [10180,10185]
simple_stmt [10180,10185]
===
match
---
operator: = [17895,17896]
operator: = [17895,17896]
===
match
---
name: Optional [7420,7428]
name: Optional [7420,7428]
===
match
---
name: self [27102,27106]
name: self [27102,27106]
===
match
---
atom_expr [21653,21680]
atom_expr [21653,21680]
===
match
---
name: self [10158,10162]
name: self [10158,10162]
===
match
---
suite [29409,29538]
suite [29404,29494]
===
match
---
name: airflow_conf [944,956]
name: airflow_conf [944,956]
===
match
---
atom_expr [9946,9965]
atom_expr [9946,9965]
===
match
---
operator: , [13552,13553]
operator: , [13552,13553]
===
match
---
atom_expr [25381,25408]
atom_expr [25381,25408]
===
match
---
name: self [7572,7576]
name: self [7572,7576]
===
match
---
name: str [5897,5900]
name: str [5897,5900]
===
match
---
simple_stmt [6619,6645]
simple_stmt [6619,6645]
===
match
---
name: self [19780,19784]
name: self [19780,19784]
===
match
---
operator: = [18328,18329]
operator: = [18328,18329]
===
match
---
string: "Spark-Submit cmd: %s" [15763,15785]
string: "Spark-Submit cmd: %s" [15763,15785]
===
match
---
arglist [27390,27472]
arglist [27390,27472]
===
match
---
name: _proxy_user [14983,14994]
name: _proxy_user [14983,14994]
===
match
---
name: connection_cmd [15576,15590]
name: connection_cmd [15576,15590]
===
match
---
operator: = [23166,23167]
operator: = [23166,23167]
===
match
---
trailer [17842,17855]
trailer [17842,17855]
===
match
---
operator: = [8093,8094]
operator: = [8093,8094]
===
match
---
name: self [7638,7642]
name: self [7638,7642]
===
match
---
atom_expr [19875,20013]
atom_expr [19875,20013]
===
match
---
suite [14818,14876]
suite [14818,14876]
===
match
---
name: self [17077,17081]
name: self [17077,17081]
===
match
---
string: 'deploy_mode' [8595,8608]
string: 'deploy_mode' [8595,8608]
===
match
---
operator: = [7238,7239]
operator: = [7238,7239]
===
match
---
operator: = [7271,7272]
operator: = [7271,7272]
===
match
---
name: conn_id [5274,5281]
name: conn_id [5274,5281]
===
match
---
name: self [26304,26308]
name: self [26304,26308]
===
match
---
trailer [28360,28382]
trailer [28360,28382]
===
match
---
name: spark_submit_cmd [18038,18054]
name: spark_submit_cmd [18038,18054]
===
match
---
expr_stmt [13524,13566]
expr_stmt [13524,13566]
===
match
---
name: _exclude_packages [14038,14055]
name: _exclude_packages [14038,14055]
===
match
---
name: self [26797,26801]
name: self [26797,26801]
===
match
---
operator: -> [26904,26906]
operator: -> [26904,26906]
===
match
---
name: line [23029,23033]
name: line [23029,23033]
===
match
---
trailer [23110,23118]
trailer [23110,23118]
===
match
---
comparison [7629,7664]
comparison [7629,7664]
===
match
---
name: _principal [14955,14965]
name: _principal [14955,14965]
===
match
---
operator: += [14531,14533]
operator: += [14531,14533]
===
match
---
expr_stmt [6619,6644]
expr_stmt [6619,6644]
===
match
---
simple_stmt [26348,26483]
simple_stmt [26348,26483]
===
match
---
if_stmt [15069,15137]
if_stmt [15069,15137]
===
match
---
name: _conf [6348,6353]
name: _conf [6348,6353]
===
match
---
operator: , [14666,14667]
operator: , [14666,14667]
===
match
---
suite [19814,20032]
suite [19814,20032]
===
match
---
atom_expr [27523,27545]
atom_expr [27523,27545]
===
match
---
name: self [14442,14446]
name: self [14442,14446]
===
match
---
name: connection_cmd [26348,26362]
name: connection_cmd [26348,26362]
===
match
---
simple_stmt [22388,22434]
simple_stmt [22388,22434]
===
match
---
trailer [17967,17974]
trailer [17967,17974]
===
match
---
atom_expr [13554,13565]
atom_expr [13554,13565]
===
match
---
argument [25228,25252]
argument [25228,25252]
===
match
---
name: Any [5252,5255]
name: Any [5252,5255]
===
match
---
parameters [10758,10803]
parameters [10758,10803]
===
match
---
name: self [14353,14357]
name: self [14353,14357]
===
match
---
name: AirflowException [25662,25678]
name: AirflowException [25662,25678]
===
match
---
trailer [11827,11829]
trailer [11827,11829]
===
match
---
import_from [957,1004]
import_from [957,1004]
===
match
---
name: extra_dejson [9443,9455]
name: extra_dejson [9443,9455]
===
match
---
name: driver_memory [6919,6932]
name: driver_memory [6919,6932]
===
match
---
atom_expr [16418,16433]
atom_expr [16418,16433]
===
match
---
param [11922,11938]
param [11922,11938]
===
match
---
if_stmt [13496,13567]
if_stmt [13496,13567]
===
match
---
number: 0 [24588,24589]
number: 0 [24588,24589]
===
match
---
trailer [15076,15082]
trailer [15076,15082]
===
match
---
string: "ERROR" [24778,24785]
string: "ERROR" [24778,24785]
===
match
---
name: conn [9210,9214]
name: conn [9210,9214]
===
match
---
suite [24787,25895]
suite [24787,25895]
===
match
---
atom_expr [26435,26467]
atom_expr [26435,26467]
===
match
---
name: _env_vars [13103,13112]
name: _env_vars [13103,13112]
===
match
---
atom_expr [5971,5984]
atom_expr [5971,5984]
===
match
---
atom_expr [10675,10707]
atom_expr [10675,10707]
===
match
---
trailer [21432,21439]
trailer [21432,21439]
===
match
---
simple_stmt [809,827]
simple_stmt [809,827]
===
match
---
parameters [8247,8253]
parameters [8247,8253]
===
match
---
suite [23365,25895]
suite [23365,25895]
===
match
---
dictorsetmaker [27834,27867]
dictorsetmaker [27834,27867]
===
match
---
simple_stmt [6375,6399]
simple_stmt [6375,6399]
===
match
---
name: max_missed_job_status_reports [25805,25834]
name: max_missed_job_status_reports [25805,25834]
===
match
---
name: self [17938,17942]
name: self [17938,17942]
===
match
---
string: 'spark' [4854,4861]
string: 'spark' [4854,4861]
===
match
---
trailer [25043,25078]
trailer [25043,25078]
===
match
---
name: hooks [1018,1023]
name: hooks [1018,1023]
===
match
---
trailer [28230,28238]
trailer [28230,28238]
===
match
---
operator: , [18804,18805]
operator: , [18804,18805]
===
match
---
arglist [22468,22517]
arglist [22468,22517]
===
match
---
simple_stmt [6653,6695]
simple_stmt [6653,6695]
===
match
---
trailer [27699,27720]
trailer [27699,27720]
===
match
---
operator: } [27865,27866]
operator: } [27865,27866]
===
match
---
operator: - [18150,18151]
operator: - [18150,18151]
===
match
---
suite [12550,12731]
suite [12550,12731]
===
match
---
simple_stmt [15749,15819]
simple_stmt [15749,15819]
===
match
---
atom [27833,27868]
atom [27833,27868]
===
match
---
operator: += [14084,14086]
operator: += [14084,14086]
===
match
---
expr_stmt [7007,7036]
expr_stmt [7007,7036]
===
match
---
import_name [799,808]
import_name [799,808]
===
match
---
name: yarn_kill [28605,28614]
name: yarn_kill [28605,28614]
===
match
---
name: self [11916,11920]
name: self [11916,11920]
===
match
---
name: connection_cmd [13694,13708]
name: connection_cmd [13694,13708]
===
match
---
operator: , [16973,16974]
operator: , [16973,16974]
===
match
---
trailer [12911,12932]
trailer [12911,12932]
===
match
---
string: r"\S*?" [11046,11053]
string: r"\S*?" [11046,11053]
===
match
---
string: r")" [11471,11475]
string: r")" [11471,11475]
===
match
---
simple_stmt [22454,22519]
simple_stmt [22454,22519]
===
match
---
fstring_expr [16417,16434]
fstring_expr [16417,16434]
===
match
---
name: self [8248,8252]
name: self [8248,8252]
===
match
---
name: format [18999,19005]
name: format [18999,19005]
===
match
---
trailer [5536,5541]
trailer [5536,5541]
===
match
---
operator: = [6066,6067]
operator: = [6066,6067]
===
match
---
atom_expr [22406,22433]
atom_expr [22406,22433]
===
match
---
trailer [27892,27900]
trailer [27892,27900]
===
match
---
operator: , [28371,28372]
operator: , [28371,28372]
===
match
---
expr_stmt [27827,27868]
expr_stmt [27827,27868]
===
match
---
trailer [18936,19115]
trailer [18936,19115]
===
match
---
name: conn [9262,9266]
name: conn [9262,9266]
===
match
---
name: conn [9342,9346]
name: conn [9342,9346]
===
match
---
testlist_comp [14850,14874]
testlist_comp [14850,14874]
===
match
---
expr_stmt [25015,25080]
expr_stmt [25015,25080]
===
match
---
trailer [17899,17907]
trailer [17899,17907]
===
match
---
operator: , [25170,25171]
operator: , [25170,25171]
===
match
---
name: _total_executor_cores [14358,14379]
name: _total_executor_cores [14358,14379]
===
match
---
name: _env [8165,8169]
name: _env [8165,8169]
===
match
---
name: format [19923,19929]
name: format [19923,19929]
===
match
---
name: stdout [18068,18074]
name: stdout [18068,18074]
===
match
---
string: 'cluster' [20931,20940]
string: 'cluster' [20931,20940]
===
match
---
name: connection_cmd [13893,13907]
name: connection_cmd [13893,13907]
===
match
---
simple_stmt [21743,21804]
simple_stmt [21743,21804]
===
match
---
expr_stmt [21422,21489]
expr_stmt [21422,21489]
===
match
---
name: airflow [1050,1057]
name: airflow [1050,1057]
===
match
---
name: Optional [5401,5409]
name: Optional [5401,5409]
===
match
---
name: env_vars [6175,6183]
name: env_vars [6175,6183]
===
match
---
atom_expr [10583,10615]
atom_expr [10583,10615]
===
match
---
trailer [7829,7836]
trailer [7829,7836]
===
match
---
name: self [27917,27921]
name: self [27917,27921]
===
match
---
simple_stmt [28195,28260]
simple_stmt [28195,28260]
===
match
---
name: self [26396,26400]
name: self [26396,26400]
===
match
---
string: "spark.kubernetes.driverEnv.{}={}" [12772,12806]
string: "spark.kubernetes.driverEnv.{}={}" [12772,12806]
===
match
---
expr_stmt [16049,16072]
expr_stmt [16049,16072]
===
match
---
trailer [6321,6323]
trailer [6321,6323]
===
match
---
funcdef [10190,10740]
funcdef [10190,10740]
===
match
---
suite [21515,21682]
suite [21515,21682]
===
match
---
name: packages [5558,5566]
name: packages [5558,5566]
===
match
---
name: driver_memory [5835,5848]
name: driver_memory [5835,5848]
===
match
---
name: str [5330,5333]
name: str [5330,5333]
===
match
---
trailer [10691,10707]
trailer [10691,10707]
===
match
---
trailer [5576,5581]
trailer [5576,5581]
===
match
---
trailer [5766,5771]
trailer [5766,5771]
===
match
---
operator: = [16185,16186]
operator: = [16185,16186]
===
match
---
name: _env_vars [13042,13051]
name: _env_vars [13042,13051]
===
match
---
name: spark_host [16174,16184]
name: spark_host [16174,16184]
===
match
---
string: 'spark.kubernetes.namespace' [9992,10020]
string: 'spark.kubernetes.namespace' [9992,10020]
===
match
---
name: str [7429,7432]
name: str [7429,7432]
===
match
---
expr_stmt [14177,14233]
expr_stmt [14177,14233]
===
match
---
funcdef [23317,25895]
funcdef [23317,25895]
===
match
---
atom_expr [21166,21191]
atom_expr [21166,21191]
===
match
---
trailer [27024,27052]
trailer [27024,27052]
===
match
---
suite [26335,26483]
suite [26335,26483]
===
match
---
name: _env [27856,27860]
name: _env [27856,27860]
===
match
---
atom_expr [10531,10616]
atom_expr [10531,10616]
===
match
---
name: self [25937,25941]
name: self [25937,25941]
===
match
---
simple_stmt [15096,15137]
simple_stmt [15096,15137]
===
match
---
operator: = [7959,7960]
operator: = [7959,7960]
===
match
---
string: "spark driver status log: %s" [23201,23230]
string: "spark driver status log: %s" [23201,23230]
===
match
---
name: connection_cmd [13349,13363]
name: connection_cmd [13349,13363]
===
match
---
name: format [7830,7836]
name: format [7830,7836]
===
match
---
name: _env [17943,17947]
name: _env [17943,17947]
===
match
---
atom_expr [12505,12518]
atom_expr [12505,12518]
===
match
---
operator: , [13725,13726]
operator: , [13725,13726]
===
match
---
atom_expr [15495,15526]
atom_expr [15495,15526]
===
match
---
name: _spark_exit_code [18823,18839]
name: _spark_exit_code [18823,18839]
===
match
---
name: List [10792,10796]
name: List [10792,10796]
===
match
---
trailer [7395,7418]
trailer [7395,7418]
===
match
---
trailer [21912,21915]
trailer [21912,21915]
===
match
---
trailer [19035,19045]
trailer [19035,19045]
===
match
---
name: self [16463,16467]
name: self [16463,16467]
===
match
---
name: log [17381,17384]
name: log [17381,17384]
===
match
---
name: _should_track_driver_status [7931,7958]
name: _should_track_driver_status [7931,7958]
===
match
---
arglist [16206,16227]
arglist [16206,16227]
===
match
---
trailer [5720,5725]
trailer [5720,5725]
===
match
---
trailer [13582,13592]
trailer [13582,13592]
===
match
---
trailer [14249,14264]
trailer [14249,14264]
===
match
---
tfpdef [17515,17526]
tfpdef [17515,17526]
===
match
---
name: env_vars [7240,7248]
name: env_vars [7240,7248]
===
match
---
name: self [18516,18520]
name: self [18516,18520]
===
match
---
name: returncode [19065,19075]
name: returncode [19065,19075]
===
match
---
expr_stmt [9320,9351]
expr_stmt [9320,9351]
===
match
---
operator: , [13637,13638]
operator: , [13637,13638]
===
match
---
name: match_driver_id [22276,22291]
name: match_driver_id [22276,22291]
===
match
---
atom [13991,14021]
atom [13991,14021]
===
match
---
atom [17128,17157]
atom [17128,17157]
===
match
---
trailer [18018,18024]
trailer [18018,18024]
===
match
---
name: _connection [13122,13133]
name: _connection [13122,13133]
===
match
---
string: "Invalid status: attempted to poll driver " [17236,17279]
string: "Invalid status: attempted to poll driver " [17236,17279]
===
match
---
name: _spark_binary [9679,9692]
name: _spark_binary [9679,9692]
===
match
---
trailer [14319,14340]
trailer [14319,14340]
===
match
---
comparison [8533,8573]
comparison [8533,8573]
===
match
---
suite [17878,17981]
suite [17878,17981]
===
match
---
operator: = [18110,18111]
operator: = [18110,18111]
===
match
---
name: _start_driver_status_tracking [19732,19761]
name: _start_driver_status_tracking [19732,19761]
===
match
---
trailer [23134,23136]
trailer [23134,23136]
===
match
---
trailer [27802,27808]
trailer [27802,27808]
===
match
---
operator: += [13806,13808]
operator: += [13806,13808]
===
match
---
testlist_comp [14196,14232]
testlist_comp [14196,14232]
===
match
---
param [6257,6292]
param [6257,6292]
===
match
---
name: poll [27539,27543]
name: poll [27539,27543]
===
match
---
simple_stmt [9468,9508]
simple_stmt [9468,9508]
===
match
---
trailer [6332,6334]
trailer [6332,6334]
===
match
---
string: 'master' [8564,8572]
string: 'master' [8564,8572]
===
match
---
trailer [16110,16120]
trailer [16110,16120]
===
match
---
simple_stmt [1244,1249]
simple_stmt [1244,1249]
===
match
---
trailer [7011,7023]
trailer [7011,7023]
===
match
---
number: 0 [18565,18566]
number: 0 [18565,18566]
===
match
---
name: match_exit_code [21823,21838]
name: match_exit_code [21823,21838]
===
match
---
simple_stmt [19125,19201]
simple_stmt [19125,19201]
===
match
---
expr_stmt [6703,6736]
expr_stmt [6703,6736]
===
match
---
expr_stmt [13025,13051]
expr_stmt [13025,13051]
===
match
---
atom_expr [18008,18222]
atom_expr [18008,18222]
===
match
---
name: Optional [7306,7314]
name: Optional [7306,7314]
===
match
---
operator: ** [17513,17515]
operator: ** [17513,17515]
===
match
---
operator: , [14212,14213]
operator: , [14212,14213]
===
match
---
expr_stmt [8108,8151]
expr_stmt [8108,8151]
===
match
---
name: re [806,808]
name: re [806,808]
===
match
---
parameters [17483,17527]
parameters [17483,17527]
===
match
---
if_stmt [14030,14134]
if_stmt [14030,14134]
===
match
---
if_stmt [21506,21682]
if_stmt [21506,21682]
===
match
---
name: _is_yarn [12541,12549]
name: _is_yarn [12541,12549]
===
match
---
trailer [29290,29294]
trailer [29290,29294]
===
match
---
operator: , [11829,11830]
operator: , [11829,11830]
===
match
---
trailer [7049,7055]
trailer [7049,7055]
===
match
---
name: self [22454,22458]
name: self [22454,22458]
===
match
---
param [25937,25941]
param [25937,25941]
===
match
---
name: self [21385,21389]
name: self [21385,21389]
===
match
---
trailer [6749,6771]
trailer [6749,6771]
===
match
---
name: hook_name [4866,4875]
name: hook_name [4866,4875]
===
match
---
name: _connection [15419,15430]
name: _connection [15419,15430]
===
match
---
string: "--status" [17129,17139]
string: "--status" [17129,17139]
===
match
---
atom [12481,12519]
atom [12481,12519]
===
match
---
name: environ [28289,28296]
name: environ [28289,28296]
===
match
---
operator: = [7376,7377]
operator: = [7376,7377]
===
match
---
expr_stmt [14516,14581]
expr_stmt [14516,14581]
===
match
---
trailer [9955,9965]
trailer [9955,9965]
===
match
---
name: keytab [6956,6962]
name: keytab [6956,6962]
===
match
---
tfpdef [5742,5771]
tfpdef [5742,5771]
===
match
---
expr_stmt [6803,6840]
expr_stmt [6803,6840]
===
match
---
trailer [14706,14721]
trailer [14706,14721]
===
match
---
name: driver_found [22800,22812]
name: driver_found [22800,22812]
===
match
---
name: NameError [1228,1237]
name: NameError [1228,1237]
===
match
---
atom_expr [14862,14874]
atom_expr [14862,14874]
===
match
---
param [10158,10162]
param [10158,10162]
===
match
---
simple_stmt [18232,18309]
simple_stmt [18232,18309]
===
match
---
name: self [27437,27441]
name: self [27437,27441]
===
match
---
atom_expr [17868,17877]
atom_expr [17868,17877]
===
match
---
trailer [9935,9944]
trailer [9935,9944]
===
match
---
name: _py_files [6440,6449]
name: _py_files [6440,6449]
===
match
---
trailer [14891,14902]
trailer [14891,14902]
===
match
---
string: 'deploy_mode' [8843,8856]
string: 'deploy_mode' [8843,8856]
===
match
---
trailer [6193,6209]
trailer [6193,6209]
===
match
---
suite [22259,22519]
suite [22259,22519]
===
match
---
trailer [29008,29030]
trailer [29008,29030]
===
match
---
operator: = [11824,11825]
operator: = [11824,11825]
===
match
---
name: self [15208,15212]
name: self [15208,15212]
===
match
---
atom_expr [15787,15817]
atom_expr [15787,15817]
===
match
---
atom_expr [27321,27336]
atom_expr [27321,27336]
===
match
---
name: airflow [1102,1109]
name: airflow [1102,1109]
===
match
---
simple_stmt [27656,27679]
simple_stmt [27656,27679]
===
match
---
name: connection_cmd [14735,14749]
name: connection_cmd [14735,14749]
===
match
---
name: typing [844,850]
name: typing [844,850]
===
match
---
operator: , [29241,29242]
operator: , [29241,29242]
===
match
---
funcdef [8628,10140]
funcdef [8628,10140]
===
match
---
name: line [20681,20685]
name: line [20681,20685]
===
match
---
name: str [17503,17506]
name: str [17503,17506]
===
match
---
operator: += [13364,13366]
operator: += [13364,13366]
===
match
---
name: pretty [29230,29236]
name: pretty [29230,29236]
===
match
---
operator: = [16857,16858]
operator: = [16857,16858]
===
match
---
name: _java_class [6586,6597]
name: _java_class [6586,6597]
===
match
---
atom_expr [8180,8194]
atom_expr [8180,8194]
===
match
---
name: line [22546,22550]
name: line [22546,22550]
===
match
---
name: _env [12709,12713]
name: _env [12709,12713]
===
match
---
expr_stmt [15096,15136]
expr_stmt [15096,15136]
===
match
---
atom_expr [25235,25252]
atom_expr [25235,25252]
===
match
---
operator: ** [18203,18205]
operator: ** [18203,18205]
===
match
---
atom_expr [13833,13856]
atom_expr [13833,13856]
===
match
---
name: self [6897,6901]
name: self [6897,6901]
===
match
---
atom_expr [28209,28224]
atom_expr [28209,28224]
===
match
---
trailer [21903,21910]
trailer [21903,21910]
===
match
---
trailer [13503,13510]
trailer [13503,13510]
===
match
---
name: environ [17900,17907]
name: environ [17900,17907]
===
match
---
simple_stmt [14393,14471]
simple_stmt [14393,14471]
===
match
---
atom_expr [25704,25872]
atom_expr [25704,25872]
===
match
---
expr_stmt [15459,15527]
expr_stmt [15459,15527]
===
match
---
string: 'deploy_mode' [12984,12997]
string: 'deploy_mode' [12984,12997]
===
match
---
atom_expr [5568,5581]
atom_expr [5568,5581]
===
match
---
trailer [21571,21578]
trailer [21571,21578]
===
match
---
name: kwargs [18205,18211]
name: kwargs [18205,18211]
===
match
---
atom_expr [9584,9607]
atom_expr [9584,9607]
===
match
---
name: self [13282,13286]
name: self [13282,13286]
===
match
---
name: self [19167,19171]
name: self [19167,19171]
===
match
---
param [17513,17526]
param [17513,17526]
===
match
---
string: "Identified spark driver pod: %s" [21618,21651]
string: "Identified spark driver pod: %s" [21618,21651]
===
match
---
atom_expr [6653,6675]
atom_expr [6653,6675]
===
match
---
atom_expr [14145,14163]
atom_expr [14145,14163]
===
match
---
atom_expr [18263,18291]
atom_expr [18263,18291]
===
match
---
atom_expr [26383,26468]
atom_expr [26383,26468]
===
match
---
arglist [19031,19075]
arglist [19031,19075]
===
match
---
atom_expr [18958,19097]
atom_expr [18958,19097]
===
match
---
suite [16583,16605]
suite [16583,16605]
===
match
---
expr_stmt [20674,20693]
expr_stmt [20674,20693]
===
match
---
simple_stmt [18317,18353]
simple_stmt [18317,18353]
===
match
---
name: key [12421,12424]
name: key [12421,12424]
===
match
---
trailer [17942,17947]
trailer [17942,17947]
===
match
---
name: AirflowException [19386,19402]
name: AirflowException [19386,19402]
===
match
---
argument [18166,18189]
argument [18166,18189]
===
match
---
operator: { [16382,16383]
operator: { [16382,16383]
===
match
---
name: connection_cmd [12389,12403]
name: connection_cmd [12389,12403]
===
match
---
operator: = [7024,7025]
operator: = [7024,7025]
===
match
---
name: _connection [16099,16110]
name: _connection [16099,16110]
===
match
---
trailer [19343,19354]
trailer [19343,19354]
===
match
---
name: _repositories [6708,6721]
name: _repositories [6708,6721]
===
match
---
and_test [22202,22258]
and_test [22202,22258]
===
match
---
simple_stmt [24925,25002]
simple_stmt [24925,25002]
===
match
---
operator: } [5098,5099]
operator: } [5098,5099]
===
match
---
name: line [22326,22330]
name: line [22326,22330]
===
match
---
simple_stmt [21118,21193]
simple_stmt [21118,21193]
===
match
---
name: Popen [28423,28428]
name: Popen [28423,28428]
===
match
---
suite [6307,8203]
suite [6307,8203]
===
match
---
atom_expr [19972,19991]
atom_expr [19972,19991]
===
match
---
operator: = [6824,6825]
operator: = [6824,6825]
===
match
---
simple_stmt [15008,15061]
simple_stmt [15008,15061]
===
match
---
trailer [21094,21097]
trailer [21094,21097]
===
match
---
comparison [25504,25561]
comparison [25504,25561]
===
match
---
simple_stmt [17446,17468]
simple_stmt [17446,17468]
===
match
---
name: get [9702,9705]
name: get [9702,9705]
===
match
---
atom_expr [11009,11840]
atom_expr [11009,11840]
===
match
---
simple_stmt [22532,22552]
simple_stmt [22532,22552]
===
match
---
if_stmt [26710,26788]
if_stmt [26710,26788]
===
match
---
atom_expr [17198,17366]
atom_expr [17198,17366]
===
match
---
atom_expr [9931,9944]
atom_expr [9931,9944]
===
match
---
name: PIPE [27308,27312]
name: PIPE [27308,27312]
===
match
---
name: _repositories [14219,14232]
name: _repositories [14219,14232]
===
match
---
name: self [7961,7965]
name: self [7961,7965]
===
match
---
name: re [21430,21432]
name: re [21430,21432]
===
match
---
atom_expr [23051,23070]
atom_expr [23051,23070]
===
match
---
operator: ** [27848,27850]
operator: ** [27848,27850]
===
match
---
name: self [7223,7227]
name: self [7223,7227]
===
match
---
string: 'master' [9247,9255]
string: 'master' [9247,9255]
===
match
---
operator: += [26757,26759]
operator: += [26757,26759]
===
match
---
name: Optional [5758,5766]
name: Optional [5758,5766]
===
match
---
name: self [12209,12213]
name: self [12209,12213]
===
match
---
simple_stmt [6407,6427]
simple_stmt [6407,6427]
===
match
---
expr_stmt [22276,22331]
expr_stmt [22276,22331]
===
match
---
trailer [10083,10113]
trailer [10083,10113]
===
match
---
operator: = [8770,8771]
operator: = [8770,8771]
===
match
---
operator: , [23230,23231]
operator: , [23230,23231]
===
match
---
string: 'namespace' [29126,29137]
string: 'namespace' [29126,29137]
===
match
---
operator: = [17975,17976]
operator: = [17975,17976]
===
match
---
string: 'master' [7655,7663]
string: 'master' [7655,7663]
===
match
---
argument [27314,27336]
argument [27314,27336]
===
match
---
trailer [20685,20691]
trailer [20685,20691]
===
match
---
name: self [7926,7930]
name: self [7926,7930]
===
match
---
fstring_end: " [13471,13472]
fstring_end: " [13471,13472]
===
match
---
trailer [7339,7360]
trailer [7339,7360]
===
match
---
simple_stmt [10048,10114]
simple_stmt [10048,10114]
===
match
---
suite [13960,14022]
suite [13960,14022]
===
match
---
atom_expr [21118,21192]
atom_expr [21118,21192]
===
match
---
simple_stmt [26509,26561]
simple_stmt [26509,26561]
===
match
---
name: _mask_cmd [19036,19045]
name: _mask_cmd [19036,19045]
===
match
---
name: connection_cmd [26834,26848]
name: connection_cmd [26834,26848]
===
match
---
trailer [16467,16471]
trailer [16467,16471]
===
match
---
or_test [9674,9737]
or_test [9674,9737]
===
match
---
string: "--repositories" [14196,14212]
string: "--repositories" [14196,14212]
===
match
---
simple_stmt [25656,25895]
simple_stmt [25656,25895]
===
match
---
name: extra [9547,9552]
name: extra [9547,9552]
===
match
---
expr_stmt [9520,9571]
expr_stmt [9520,9571]
===
match
---
if_stmt [13575,13655]
if_stmt [13575,13655]
===
match
---
number: 0 [21581,21582]
number: 0 [21581,21582]
===
match
---
expr_stmt [13606,13654]
expr_stmt [13606,13654]
===
match
---
operator: = [5375,5376]
operator: = [5375,5376]
===
match
---
comparison [7700,7719]
comparison [7700,7719]
===
match
---
atom_expr [7961,8003]
atom_expr [7961,8003]
===
match
---
trailer [13133,13148]
trailer [13133,13148]
===
match
---
atom_expr [13181,13270]
atom_expr [13181,13270]
===
match
---
simple_stmt [27249,27338]
simple_stmt [27249,27338]
===
match
---
simple_stmt [21052,21098]
simple_stmt [21052,21098]
===
match
---
name: replace [16198,16205]
name: replace [16198,16205]
===
match
---
operator: , [18128,18129]
operator: , [18128,18129]
===
match
---
trailer [15047,15059]
trailer [15047,15059]
===
match
---
name: self [26435,26439]
name: self [26435,26439]
===
match
---
trailer [21439,21489]
trailer [21439,21489]
===
match
---
simple_stmt [4802,4838]
simple_stmt [4802,4838]
===
match
---
parameters [4935,4937]
parameters [4935,4937]
===
match
---
operator: , [8991,8992]
operator: , [8991,8992]
===
match
---
dictorsetmaker [8786,8992]
dictorsetmaker [8786,8992]
===
match
---
atom_expr [6375,6388]
atom_expr [6375,6388]
===
match
---
suite [10236,10740]
suite [10236,10740]
===
match
---
expr_stmt [28324,28382]
expr_stmt [28324,28382]
===
match
---
name: Dict [8180,8184]
name: Dict [8180,8184]
===
match
---
name: List [879,883]
name: List [879,883]
===
match
---
simple_stmt [12389,12451]
simple_stmt [12389,12451]
===
match
---
name: connection_cmd [17110,17124]
name: connection_cmd [17110,17124]
===
match
---
name: _conf [12370,12375]
name: _conf [12370,12375]
===
match
---
simple_stmt [28551,28623]
simple_stmt [28551,28623]
===
match
---
name: self [20067,20071]
name: self [20067,20071]
===
match
---
name: _connection [15381,15392]
name: _connection [15381,15392]
===
match
---
operator: , [893,894]
operator: , [893,894]
===
match
---
simple_stmt [13349,13488]
simple_stmt [13349,13488]
===
match
---
name: self [10452,10456]
name: self [10452,10456]
===
match
---
name: _connection [29114,29125]
name: _connection [29114,29125]
===
match
---
trailer [19139,19200]
trailer [19139,19200]
===
match
---
operator: = [20679,20680]
operator: = [20679,20680]
===
match
---
operator: , [12315,12316]
operator: , [12315,12316]
===
match
---
trailer [12486,12501]
trailer [12486,12501]
===
match
---
atom_expr [9696,9737]
atom_expr [9696,9737]
===
match
---
raise_stmt [13175,13270]
raise_stmt [13175,13270]
===
match
---
operator: = [6389,6390]
operator: = [6389,6390]
===
match
---
trailer [10560,10574]
trailer [10560,10574]
===
match
---
name: split [27803,27808]
name: split [27803,27808]
===
match
---
name: kill_cmd [27738,27746]
name: kill_cmd [27738,27746]
===
match
---
param [20067,20072]
param [20067,20072]
===
match
---
param [5558,5589]
param [5558,5589]
===
match
---
operator: , [861,862]
operator: , [861,862]
===
match
---
arglist [12903,12932]
arglist [12903,12932]
===
match
---
name: Optional [5929,5937]
name: Optional [5929,5937]
===
match
---
name: get_conn [10149,10157]
name: get_conn [10149,10157]
===
match
---
if_stmt [14142,14234]
if_stmt [14142,14234]
===
match
---
atom_expr [27695,27720]
atom_expr [27695,27720]
===
match
---
name: conn_data [9646,9655]
name: conn_data [9646,9655]
===
match
---
name: Optional [6139,6147]
name: Optional [6139,6147]
===
match
---
name: itr [22872,22875]
name: itr [22872,22875]
===
match
---
trailer [27273,27279]
trailer [27273,27279]
===
match
---
name: curl_max_wait_time [16343,16361]
name: curl_max_wait_time [16343,16361]
===
match
---
name: self [8160,8164]
name: self [8160,8164]
===
match
---
trailer [26543,26559]
trailer [26543,26559]
===
match
---
expr_stmt [27182,27232]
expr_stmt [27182,27232]
===
match
---
name: _yarn_application_id [21057,21077]
name: _yarn_application_id [21057,21077]
===
match
---
operator: } [12447,12448]
operator: } [12447,12448]
===
match
---
simple_stmt [23153,23173]
simple_stmt [23153,23173]
===
match
---
atom_expr [21536,21563]
atom_expr [21536,21563]
===
match
---
simple_stmt [15699,15740]
simple_stmt [15699,15740]
===
match
---
annassign [7360,7382]
annassign [7360,7382]
===
match
---
trailer [10533,10538]
trailer [10533,10538]
===
match
---
name: _is_kubernetes [18521,18535]
name: _is_kubernetes [18521,18535]
===
match
---
operator: = [25433,25434]
operator: = [25433,25434]
===
match
---
name: self [9160,9164]
name: self [9160,9164]
===
match
---
name: update [17931,17937]
name: update [17931,17937]
===
match
---
name: Any [6153,6156]
name: Any [6153,6156]
===
match
---
trailer [10786,10802]
trailer [10786,10802]
===
match
---
trailer [16571,16582]
trailer [16571,16582]
===
match
---
name: _driver_id [22393,22403]
name: _driver_id [22393,22403]
===
match
---
atom_expr [15208,15224]
atom_expr [15208,15224]
===
match
---
operator: = [6772,6773]
operator: = [6772,6773]
===
match
---
name: _connection [7863,7874]
name: _connection [7863,7874]
===
match
---
operator: , [877,878]
operator: , [877,878]
===
match
---
suite [13336,13488]
suite [13336,13488]
===
match
---
name: _total_executor_cores [6750,6771]
name: _total_executor_cores [6750,6771]
===
match
---
return_stmt [26859,26880]
return_stmt [26859,26880]
===
match
---
name: log [19130,19133]
name: log [19130,19133]
===
match
---
name: max_missed_job_status_reports [24598,24627]
name: max_missed_job_status_reports [24598,24627]
===
match
---
tfpdef [5227,5257]
tfpdef [5227,5257]
===
match
---
string: "identified spark driver id: %s" [22468,22500]
string: "identified spark driver id: %s" [22468,22500]
===
match
---
name: match [20958,20963]
name: match [20958,20963]
===
match
---
suite [9220,9286]
suite [9220,9286]
===
match
---
name: str [5814,5817]
name: str [5814,5817]
===
match
---
atom_expr [28344,28382]
atom_expr [28344,28382]
===
match
---
name: info [9852,9856]
name: info [9852,9856]
===
match
---
name: Dict [8661,8665]
name: Dict [8661,8665]
===
match
---
trailer [6379,6388]
trailer [6379,6388]
===
match
---
name: self [15376,15380]
name: self [15376,15380]
===
match
---
expr_stmt [6849,6888]
expr_stmt [6849,6888]
===
match
---
operator: = [29000,29001]
operator: = [29000,29001]
===
match
---
atom_expr [26304,26334]
atom_expr [26304,26334]
===
match
---
string: "status but no driver id is known. Giving up." [17302,17348]
string: "status but no driver id is known. Giving up." [17302,17348]
===
match
---
name: _submit_sp [7294,7304]
name: _submit_sp [7294,7304]
===
match
---
testlist_comp [5039,5068]
testlist_comp [5039,5068]
===
match
---
operator: = [7320,7321]
operator: = [7320,7321]
===
match
---
name: log [23191,23194]
name: log [23191,23194]
===
match
---
expr_stmt [14069,14133]
expr_stmt [14069,14133]
===
match
---
name: key [12358,12361]
name: key [12358,12361]
===
match
---
name: groups [21572,21578]
name: groups [21572,21578]
===
match
---
name: match_driver_id [22351,22366]
name: match_driver_id [22351,22366]
===
match
---
trailer [28510,28515]
trailer [28510,28515]
===
match
---
name: self [7607,7611]
name: self [7607,7611]
===
match
---
name: Optional [5233,5241]
name: Optional [5233,5241]
===
match
---
operator: , [5908,5909]
operator: , [5908,5909]
===
match
---
atom_expr [28226,28238]
atom_expr [28226,28238]
===
match
---
expr_stmt [14831,14875]
expr_stmt [14831,14875]
===
match
---
trailer [18283,18290]
trailer [18283,18290]
===
match
---
name: exclude_packages [6678,6694]
name: exclude_packages [6678,6694]
===
match
---
string: 'master' [26656,26664]
string: 'master' [26656,26664]
===
match
---
atom_expr [8578,8609]
atom_expr [8578,8609]
===
match
---
name: str [12427,12430]
name: str [12427,12430]
===
match
---
funcdef [20037,22552]
funcdef [20037,22552]
===
match
---
name: _conn_id [9936,9944]
name: _conn_id [9936,9944]
===
match
---
name: driver_found [23153,23165]
name: driver_found [23153,23165]
===
match
---
name: _status_poll_interval [24889,24910]
name: _status_poll_interval [24889,24910]
===
match
---
operator: , [5217,5218]
operator: , [5217,5218]
===
match
---
param [5274,5305]
param [5274,5305]
===
match
---
suite [1159,1207]
suite [1159,1207]
===
match
---
arglist [11029,11830]
arglist [11029,11830]
===
match
---
name: stderr [28493,28499]
name: stderr [28493,28499]
===
match
---
expr_stmt [13349,13487]
expr_stmt [13349,13487]
===
match
---
name: max_missed_job_status_reports [25532,25561]
name: max_missed_job_status_reports [25532,25561]
===
match
---
subscriptlist [5247,5255]
subscriptlist [5247,5255]
===
match
---
atom_expr [14442,14468]
atom_expr [14442,14468]
===
match
---
simple_stmt [10718,10740]
simple_stmt [10718,10740]
===
match
---
name: connection_cmd [10765,10779]
name: connection_cmd [10765,10779]
===
match
---
trailer [20900,20912]
trailer [20900,20912]
===
match
---
parameters [11915,11939]
parameters [11915,11939]
===
match
---
expr_stmt [15178,15225]
expr_stmt [15178,15225]
===
match
---
name: tmpl [12891,12895]
name: tmpl [12891,12895]
===
match
---
atom_expr [7511,7537]
atom_expr [7511,7537]
===
match
---
trailer [12466,12476]
trailer [12466,12476]
===
match
---
name: stdout [27290,27296]
name: stdout [27290,27296]
===
match
---
name: self [17376,17380]
name: self [17376,17380]
===
match
---
trailer [11784,11789]
trailer [11784,11789]
===
match
---
operator: , [16321,16322]
operator: , [16321,16322]
===
match
---
trailer [12509,12518]
trailer [12509,12518]
===
match
---
name: returncode [18317,18327]
name: returncode [18317,18327]
===
match
---
atom_expr [11781,11805]
atom_expr [11781,11805]
===
match
---
atom_expr [20078,20091]
atom_expr [20078,20091]
===
match
---
name: replace [23111,23118]
name: replace [23111,23118]
===
match
---
arglist [9874,9965]
arglist [9874,9965]
===
match
---
suite [15446,15528]
suite [15446,15528]
===
match
---
name: _is_kubernetes [7612,7626]
name: _is_kubernetes [7612,7626]
===
match
---
name: AirflowException [18920,18936]
name: AirflowException [18920,18936]
===
match
---
operator: -> [22613,22615]
operator: -> [22613,22615]
===
match
---
name: connection_cmd [17453,17467]
name: connection_cmd [17453,17467]
===
match
---
atom_expr [27656,27678]
atom_expr [27656,27678]
===
match
---
operator: += [13709,13711]
operator: += [13709,13711]
===
match
---
simple_stmt [23280,23312]
simple_stmt [23280,23312]
===
match
---
operator: = [17507,17508]
operator: = [17507,17508]
===
match
---
name: delete_namespaced_pod [29009,29030]
name: delete_namespaced_pod [29009,29030]
===
match
---
operator: , [8802,8803]
operator: , [8802,8803]
===
match
---
expr_stmt [7335,7382]
expr_stmt [7335,7382]
===
match
---
name: self [26713,26717]
name: self [26713,26717]
===
match
---
trailer [5409,5414]
trailer [5409,5414]
===
match
---
if_stmt [23247,23312]
if_stmt [23247,23312]
===
match
---
atom_expr [14245,14264]
atom_expr [14245,14264]
===
match
---
atom_expr [14320,14339]
atom_expr [14320,14339]
===
match
---
name: subprocess [28476,28486]
name: subprocess [28476,28486]
===
match
---
string: 'deploy-mode' [9557,9570]
string: 'deploy-mode' [9557,9570]
===
match
---
name: self [12704,12708]
name: self [12704,12708]
===
match
---
name: self [19290,19294]
name: self [19290,19294]
===
match
---
name: line [22889,22893]
name: line [22889,22893]
===
match
---
operator: , [14948,14949]
operator: , [14948,14949]
===
match
---
operator: , [5870,5871]
operator: , [5870,5871]
===
match
---
name: self [8012,8016]
name: self [8012,8016]
===
match
---
suite [23034,23173]
suite [23034,23173]
===
match
---
operator: += [15474,15476]
operator: += [15474,15476]
===
match
---
name: application_args [6121,6137]
name: application_args [6121,6137]
===
match
---
trailer [20691,20693]
trailer [20691,20693]
===
match
---
expr_stmt [4842,4861]
expr_stmt [4842,4861]
===
match
---
atom_expr [14773,14792]
atom_expr [14773,14792]
===
match
---
simple_stmt [22800,22821]
simple_stmt [22800,22821]
===
match
---
atom_expr [8029,8042]
atom_expr [8029,8042]
===
match
---
argument [29164,29204]
argument [29164,29204]
===
match
---
name: env [17977,17980]
name: env [17977,17980]
===
match
---
trailer [24939,25001]
trailer [24939,25001]
===
match
---
trailer [17907,17912]
trailer [17907,17912]
===
match
---
expr_stmt [15346,15402]
expr_stmt [15346,15402]
===
match
---
simple_stmt [7492,7538]
simple_stmt [7492,7538]
===
match
---
import_as_names [858,900]
import_as_names [858,900]
===
match
---
trailer [27363,27368]
trailer [27363,27368]
===
match
---
simple_stmt [26961,27008]
simple_stmt [26961,27008]
===
match
---
atom_expr [16187,16228]
atom_expr [16187,16228]
===
match
---
operator: = [11007,11008]
operator: = [11007,11008]
===
match
---
if_stmt [14479,14582]
if_stmt [14479,14582]
===
match
---
operator: } [12424,12425]
operator: } [12424,12425]
===
match
---
name: self [21118,21122]
name: self [21118,21122]
===
match
---
name: _keytab [14810,14817]
name: _keytab [14810,14817]
===
match
---
string: 'spark-home' [9620,9632]
string: 'spark-home' [9620,9632]
===
match
---
name: connection_cmd [12286,12300]
name: connection_cmd [12286,12300]
===
match
---
name: total_executor_cores [5690,5710]
name: total_executor_cores [5690,5710]
===
match
---
trailer [16342,16362]
trailer [16342,16362]
===
match
---
param [6082,6112]
param [6082,6112]
===
match
---
trailer [10679,10691]
trailer [10679,10691]
===
match
---
expr_stmt [17990,18222]
expr_stmt [17990,18222]
===
match
---
name: self [13117,13121]
name: self [13117,13121]
===
match
---
trailer [13949,13959]
trailer [13949,13959]
===
match
---
atom [15114,15136]
atom [15114,15136]
===
match
---
name: _spark_exit_code [21865,21881]
name: _spark_exit_code [21865,21881]
===
match
---
name: connection_cmd [14516,14530]
name: connection_cmd [14516,14530]
===
match
---
testlist_comp [14647,14689]
testlist_comp [14647,14689]
===
match
---
expr_stmt [9584,9633]
expr_stmt [9584,9633]
===
match
---
subscriptlist [6199,6207]
subscriptlist [6199,6207]
===
match
---
atom_expr [19031,19063]
atom_expr [19031,19063]
===
match
---
trailer [27465,27470]
trailer [27465,27470]
===
match
---
name: _driver_id [19344,19354]
name: _driver_id [19344,19354]
===
match
---
atom_expr [14559,14579]
atom_expr [14559,14579]
===
match
---
operator: += [17125,17127]
operator: += [17125,17127]
===
match
---
name: universal_newlines [25298,25316]
name: universal_newlines [25298,25316]
===
match
---
operator: = [5335,5336]
operator: = [5335,5336]
===
match
---
atom_expr [16463,16492]
atom_expr [16463,16492]
===
match
---
name: archives [6486,6494]
name: archives [6486,6494]
===
match
---
simple_stmt [13893,13934]
simple_stmt [13893,13934]
===
match
---
decorated [4891,5111]
decorated [4891,5111]
===
match
---
operator: , [29083,29084]
operator: , [29083,29084]
===
match
---
atom_expr [13754,13777]
atom_expr [13754,13777]
===
match
---
name: subprocess [18075,18085]
name: subprocess [18075,18085]
===
match
---
testlist_comp [12305,12343]
testlist_comp [12305,12343]
===
match
---
expr_stmt [10657,10708]
expr_stmt [10657,10708]
===
match
---
if_stmt [14884,14967]
if_stmt [14884,14967]
===
match
---
trailer [7177,7195]
trailer [7177,7195]
===
match
---
trailer [6060,6065]
trailer [6060,6065]
===
match
---
atom [13542,13566]
atom [13542,13566]
===
match
---
funcdef [26886,29538]
funcdef [26886,29494]
===
match
---
suite [20941,21193]
suite [20941,21193]
===
match
---
name: _conf [10078,10083]
name: _conf [10078,10083]
===
match
---
expr_stmt [15576,15607]
expr_stmt [15576,15607]
===
match
---
atom_expr [27851,27860]
atom_expr [27851,27860]
===
match
---
operator: , [15041,15042]
operator: , [15041,15042]
===
match
---
comparison [18540,18566]
comparison [18540,18566]
===
match
---
atom_expr [27297,27312]
atom_expr [27297,27312]
===
match
---
simple_stmt [25350,25410]
simple_stmt [25350,25410]
===
match
---
expr_stmt [28280,28303]
expr_stmt [28280,28303]
===
match
---
atom_expr [7926,7958]
atom_expr [7926,7958]
===
match
---
simple_stmt [4842,4862]
simple_stmt [4842,4862]
===
match
---
simple_stmt [17961,17981]
simple_stmt [17961,17981]
===
match
---
name: default_conn_name [4802,4819]
name: default_conn_name [4802,4819]
===
match
---
return_stmt [10718,10739]
return_stmt [10718,10739]
===
match
---
string: r"(\2)" [11705,11712]
string: r"(\2)" [11705,11712]
===
match
---
if_stmt [15234,15296]
if_stmt [15234,15296]
===
match
---
name: java_class [5516,5526]
name: java_class [5516,5526]
===
match
---
trailer [9498,9507]
trailer [9498,9507]
===
match
---
name: log [22537,22540]
name: log [22537,22540]
===
match
---
name: _mask_cmd [15792,15801]
name: _mask_cmd [15792,15801]
===
match
---
name: missed_job_status_reports [24560,24585]
name: missed_job_status_reports [24560,24585]
===
match
---
name: Optional [7362,7370]
name: Optional [7362,7370]
===
match
---
operator: , [13472,13473]
operator: , [13472,13473]
===
match
---
trailer [16661,16813]
trailer [16661,16813]
===
match
---
trailer [6507,6526]
trailer [6507,6526]
===
match
---
name: Iterator [869,877]
name: Iterator [869,877]
===
match
---
simple_stmt [27567,27644]
simple_stmt [27567,27644]
===
match
---
atom_expr [27888,27900]
atom_expr [27888,27900]
===
match
---
string: """         Remote Popen to execute the spark-submit job          :param application: Submitted application, jar or py file         :type application: str         :param kwargs: extra arguments to Popen (see subprocess.Popen)         """ [17545,17782]
string: """         Remote Popen to execute the spark-submit job          :param application: Submitted application, jar or py file         :type application: str         :param kwargs: extra arguments to Popen (see subprocess.Popen)         """ [17545,17782]
===
match
---
trailer [18739,18746]
trailer [18739,18746]
===
match
---
trailer [8594,8609]
trailer [8594,8609]
===
match
---
expr_stmt [24560,24589]
expr_stmt [24560,24589]
===
match
---
name: search [21764,21770]
name: search [21764,21770]
===
match
---
string: "Failed to poll for the driver status {} times: returncode = {}" [25704,25768]
string: "Failed to poll for the driver status {} times: returncode = {}" [25704,25768]
===
match
---
trailer [9329,9339]
trailer [9329,9339]
===
match
---
operator: = [4852,4853]
operator: = [4852,4853]
===
match
---
tfpdef [5835,5863]
tfpdef [5835,5863]
===
match
---
name: debug [17385,17390]
name: debug [17385,17390]
===
match
---
string: 'deploy_mode' [9530,9543]
string: 'deploy_mode' [9530,9543]
===
match
---
arglist [27280,27336]
arglist [27280,27336]
===
match
---
import_from [1164,1206]
import_from [1164,1206]
===
match
---
name: str [5370,5373]
name: str [5370,5373]
===
match
---
param [5213,5218]
param [5213,5218]
===
match
---
name: _connection [10549,10560]
name: _connection [10549,10560]
===
match
---
expr_stmt [16944,17002]
expr_stmt [16944,17002]
===
match
---
trailer [16098,16110]
trailer [16098,16110]
===
match
---
funcdef [8208,8623]
funcdef [8208,8623]
===
match
---
trailer [21540,21563]
trailer [21540,21563]
===
match
---
name: self [26771,26775]
name: self [26771,26775]
===
match
---
simple_stmt [27182,27233]
simple_stmt [27182,27233]
===
match
---
operator: = [29168,29169]
operator: = [29168,29169]
===
match
---
trailer [27115,27164]
trailer [27115,27164]
===
match
---
operator: = [4876,4877]
operator: = [4876,4877]
===
match
---
arglist [21618,21680]
arglist [21618,21680]
===
match
---
name: os [28286,28288]
name: os [28286,28288]
===
match
---
name: self [12462,12466]
name: self [12462,12466]
===
match
---
atom_expr [20966,21005]
atom_expr [20966,21005]
===
match
---
name: get [9616,9619]
name: get [9616,9619]
===
match
---
if_stmt [16129,17367]
if_stmt [16129,17367]
===
match
---
trailer [9759,9772]
trailer [9759,9772]
===
match
---
name: name [7058,7062]
name: name [7058,7062]
===
match
---
operator: = [12770,12771]
operator: = [12770,12771]
===
match
---
operator: { [5097,5098]
operator: { [5097,5098]
===
match
---
expr_stmt [14628,14690]
expr_stmt [14628,14690]
===
match
---
trailer [12321,12333]
trailer [12321,12333]
===
match
---
operator: , [16291,16292]
operator: , [16291,16292]
===
match
---
operator: , [27146,27147]
operator: , [27146,27147]
===
match
---
name: AirflowException [988,1004]
name: AirflowException [988,1004]
===
match
---
string: "--driver-class-path" [13810,13831]
string: "--driver-class-path" [13810,13831]
===
match
---
simple_stmt [15178,15226]
simple_stmt [15178,15226]
===
match
---
name: _connection [12972,12983]
name: _connection [12972,12983]
===
match
---
operator: = [6954,6955]
operator: = [6954,6955]
===
match
---
expr_stmt [16241,16450]
expr_stmt [16241,16450]
===
match
---
simple_stmt [1005,1045]
simple_stmt [1005,1045]
===
match
---
name: conn_data [9520,9529]
name: conn_data [9520,9529]
===
match
---
funcdef [4909,5111]
funcdef [4909,5111]
===
match
---
trailer [9164,9179]
trailer [9164,9179]
===
match
---
operator: , [21796,21797]
operator: , [21796,21797]
===
match
---
atom_expr [12431,12446]
atom_expr [12431,12446]
===
match
---
name: self [13037,13041]
name: self [13037,13041]
===
match
---
trailer [22206,22234]
trailer [22206,22234]
===
match
---
argument [25270,25280]
argument [25270,25280]
===
match
---
name: env [27827,27830]
name: env [27827,27830]
===
match
---
atom_expr [15148,15164]
atom_expr [15148,15164]
===
match
---
operator: , [5056,5057]
operator: , [5056,5057]
===
match
---
trailer [27359,27363]
trailer [27359,27363]
===
match
---
name: os [796,798]
name: os [796,798]
===
match
---
string: 'password' [5058,5068]
string: 'password' [5058,5068]
===
match
---
atom_expr [21604,21681]
atom_expr [21604,21681]
===
match
---
testlist_comp [14088,14132]
testlist_comp [14088,14132]
===
match
---
if_stmt [18581,19116]
if_stmt [18581,19116]
===
match
---
operator: , [20998,20999]
operator: , [20998,20999]
===
match
---
suite [12376,12451]
suite [12376,12451]
===
match
---
trailer [24883,24911]
trailer [24883,24911]
===
match
---
trailer [25205,25210]
trailer [25205,25210]
===
match
---
simple_stmt [14177,14234]
simple_stmt [14177,14234]
===
match
---
string: 'spark_home' [8876,8888]
string: 'spark_home' [8876,8888]
===
match
---
if_stmt [14590,14691]
if_stmt [14590,14691]
===
match
---
file_input [789,29538]
file_input [789,29494]
===
match
---
testlist_comp [26627,26665]
testlist_comp [26627,26665]
===
match
---
if_stmt [20875,22519]
if_stmt [20875,22519]
===
match
---
string: "--principal" [14935,14948]
string: "--principal" [14935,14948]
===
match
---
atom_expr [8160,8169]
atom_expr [8160,8169]
===
match
---
expr_stmt [9153,9194]
expr_stmt [9153,9194]
===
match
---
name: Popen [18019,18024]
name: Popen [18019,18024]
===
match
---
name: subprocess [27321,27331]
name: subprocess [27321,27331]
===
match
---
number: 1 [25612,25613]
number: 1 [25612,25613]
===
match
---
operator: , [5548,5549]
operator: , [5548,5549]
===
match
---
trailer [10468,10482]
trailer [10468,10482]
===
match
---
and_test [13282,13335]
and_test [13282,13335]
===
match
---
operator: } [5109,5110]
operator: } [5109,5110]
===
match
---
simple_stmt [20958,21006]
simple_stmt [20958,21006]
===
match
---
raise_stmt [18914,19115]
raise_stmt [18914,19115]
===
match
---
string: 'master' [7589,7597]
string: 'master' [7589,7597]
===
match
---
trailer [18024,18222]
trailer [18024,18222]
===
match
---
name: iter [25381,25385]
name: iter [25381,25385]
===
match
---
operator: , [8960,8961]
operator: , [8960,8961]
===
match
---
name: renew_from_kt [28195,28208]
name: renew_from_kt [28195,28208]
===
match
---
name: bool [8257,8261]
name: bool [8257,8261]
===
match
---
operator: = [9672,9673]
operator: = [9672,9673]
===
match
---
trailer [22392,22403]
trailer [22392,22403]
===
match
---
name: _build_spark_submit_command [11888,11915]
name: _build_spark_submit_command [11888,11915]
===
match
---
trailer [9278,9283]
trailer [9278,9283]
===
match
---
name: _packages [14011,14020]
name: _packages [14011,14020]
===
match
---
raise_stmt [19380,19532]
raise_stmt [19380,19532]
===
match
---
param [5351,5382]
param [5351,5382]
===
match
---
name: self [14482,14486]
name: self [14482,14486]
===
match
---
atom_expr [27437,27452]
atom_expr [27437,27452]
===
match
---
trailer [6152,6157]
trailer [6152,6157]
===
match
---
or_test [18501,18567]
or_test [18501,18567]
===
match
---
name: wait [28615,28619]
name: wait [28615,28619]
===
match
---
trailer [8551,8563]
trailer [8551,8563]
===
match
---
atom [13367,13487]
atom [13367,13487]
===
match
---
trailer [26811,26849]
trailer [26811,26849]
===
match
---
expr_stmt [26348,26482]
expr_stmt [26348,26482]
===
match
---
name: application [15595,15606]
name: application [15595,15606]
===
match
---
operator: = [5674,5675]
operator: = [5674,5675]
===
match
---
name: Iterator [20078,20086]
name: Iterator [20078,20086]
===
match
---
string: 'namespace' [9760,9771]
string: 'namespace' [9760,9771]
===
match
---
string: "Spark on K8s killed with response: %s" [29300,29339]
string: "Spark on K8s killed with response: %s" [29300,29339]
===
match
---
name: match_exit_code [21743,21758]
name: match_exit_code [21743,21758]
===
match
---
name: self [26961,26965]
name: self [26961,26965]
===
match
---
testlist_comp [15115,15135]
testlist_comp [15115,15135]
===
insert-node
---
name: SparkSubmitHook [1304,1319]
to
classdef [1298,29538]
at 0
===
insert-tree
---
arglist [1320,1342]
    name: BaseHook [1320,1328]
    operator: , [1328,1329]
    name: LoggingMixin [1330,1342]
to
classdef [1298,29538]
at 1
===
insert-tree
---
simple_stmt [1349,4766]
    string: """     This hook is a wrapper around the spark-submit binary to kick off a spark-submit job.     It requires that the "spark-submit" binary is in the PATH or the spark_home to be     supplied.      :param conf: Arbitrary Spark configuration properties     :type conf: dict     :param conn_id: The connection id as configured in Airflow administration. When an         invalid connection_id is supplied, it will default to yarn.     :type conn_id: str     :param files: Upload additional files to the executor running the job, separated by a         comma. Files will be placed in the working directory of each executor.         For example, serialized objects.     :type files: str     :param py_files: Additional python files used by the job, can be .zip, .egg or .py.     :type py_files: str     :param: archives: Archives that spark should unzip (and possibly tag with #ALIAS) into         the application working directory.     :param driver_class_path: Additional, driver-specific, classpath settings.     :type driver_class_path: str     :param jars: Submit additional jars to upload and place them in executor classpath.     :type jars: str     :param java_class: the main class of the Java application     :type java_class: str     :param packages: Comma-separated list of maven coordinates of jars to include on the         driver and executor classpaths     :type packages: str     :param exclude_packages: Comma-separated list of maven coordinates of jars to exclude         while resolving the dependencies provided in 'packages'     :type exclude_packages: str     :param repositories: Comma-separated list of additional remote repositories to search         for the maven coordinates given with 'packages'     :type repositories: str     :param total_executor_cores: (Standalone & Mesos only) Total cores for all executors         (Default: all the available cores on the worker)     :type total_executor_cores: int     :param executor_cores: (Standalone, YARN and Kubernetes only) Number of cores per         executor (Default: 2)     :type executor_cores: int     :param executor_memory: Memory per executor (e.g. 1000M, 2G) (Default: 1G)     :type executor_memory: str     :param driver_memory: Memory allocated to the driver (e.g. 1000M, 2G) (Default: 1G)     :type driver_memory: str     :param keytab: Full path to the file that contains the keytab     :type keytab: str     :param principal: The name of the kerberos principal used for keytab     :type principal: str     :param proxy_user: User to impersonate when submitting the application     :type proxy_user: str     :param name: Name of the job (default airflow-spark)     :type name: str     :param num_executors: Number of executors to launch     :type num_executors: int     :param status_poll_interval: Seconds to wait between polls of driver status in cluster         mode (Default: 1)     :type status_poll_interval: int     :param application_args: Arguments for the application being submitted     :type application_args: list     :param env_vars: Environment variables for spark-submit. It         supports yarn and k8s mode too.     :type env_vars: dict     :param verbose: Whether to pass the verbose flag to spark-submit process for debugging     :type verbose: bool     :param spark_binary: The command to use for spark submit.                          Some distros may use spark2-submit.     :type spark_binary: str     """ [1349,4765]
to
suite [1344,29538]
at 0
===
update-node
---
name: error [29439,29444]
replace error by exception
===
update-node
---
string: "Exception when attempting to kill Spark on K8s:" [29445,29494]
replace "Exception when attempting to kill Spark on K8s:" by "Exception when attempting to kill Spark on K8s"
===
delete-node
---
name: SparkSubmitHook [1304,1319]
===
===
delete-tree
---
arglist [1320,1342]
    name: BaseHook [1320,1328]
    operator: , [1328,1329]
    name: LoggingMixin [1330,1342]
===
delete-tree
---
simple_stmt [1349,4766]
    string: """     This hook is a wrapper around the spark-submit binary to kick off a spark-submit job.     It requires that the "spark-submit" binary is in the PATH or the spark_home to be     supplied.      :param conf: Arbitrary Spark configuration properties     :type conf: dict     :param conn_id: The connection id as configured in Airflow administration. When an         invalid connection_id is supplied, it will default to yarn.     :type conn_id: str     :param files: Upload additional files to the executor running the job, separated by a         comma. Files will be placed in the working directory of each executor.         For example, serialized objects.     :type files: str     :param py_files: Additional python files used by the job, can be .zip, .egg or .py.     :type py_files: str     :param: archives: Archives that spark should unzip (and possibly tag with #ALIAS) into         the application working directory.     :param driver_class_path: Additional, driver-specific, classpath settings.     :type driver_class_path: str     :param jars: Submit additional jars to upload and place them in executor classpath.     :type jars: str     :param java_class: the main class of the Java application     :type java_class: str     :param packages: Comma-separated list of maven coordinates of jars to include on the         driver and executor classpaths     :type packages: str     :param exclude_packages: Comma-separated list of maven coordinates of jars to exclude         while resolving the dependencies provided in 'packages'     :type exclude_packages: str     :param repositories: Comma-separated list of additional remote repositories to search         for the maven coordinates given with 'packages'     :type repositories: str     :param total_executor_cores: (Standalone & Mesos only) Total cores for all executors         (Default: all the available cores on the worker)     :type total_executor_cores: int     :param executor_cores: (Standalone, YARN and Kubernetes only) Number of cores per         executor (Default: 2)     :type executor_cores: int     :param executor_memory: Memory per executor (e.g. 1000M, 2G) (Default: 1G)     :type executor_memory: str     :param driver_memory: Memory allocated to the driver (e.g. 1000M, 2G) (Default: 1G)     :type driver_memory: str     :param keytab: Full path to the file that contains the keytab     :type keytab: str     :param principal: The name of the kerberos principal used for keytab     :type principal: str     :param proxy_user: User to impersonate when submitting the application     :type proxy_user: str     :param name: Name of the job (default airflow-spark)     :type name: str     :param num_executors: Number of executors to launch     :type num_executors: int     :param status_poll_interval: Seconds to wait between polls of driver status in cluster         mode (Default: 1)     :type status_poll_interval: int     :param application_args: Arguments for the application being submitted     :type application_args: list     :param env_vars: Environment variables for spark-submit. It         supports yarn and k8s mode too.     :type env_vars: dict     :param verbose: Whether to pass the verbose flag to spark-submit process for debugging     :type verbose: bool     :param spark_binary: The command to use for spark submit.                          Some distros may use spark2-submit.     :type spark_binary: str     """ [1349,4765]
===
delete-node
---
name: e [29407,29408]
===
===
delete-tree
---
simple_stmt [29516,29538]
    atom_expr [29516,29537]
        name: self [29516,29520]
        trailer [29520,29524]
            name: log [29521,29524]
        trailer [29524,29534]
            name: exception [29525,29534]
        trailer [29534,29537]
            name: e [29535,29536]
