===
match
---
name: self [1907,1911]
name: self [1907,1911]
===
match
---
operator: , [4080,4081]
operator: , [4045,4046]
===
match
---
trailer [4768,4805]
trailer [4733,4770]
===
match
---
name: self [7396,7400]
name: self [7320,7324]
===
match
---
name: join [3486,3490]
name: join [3451,3455]
===
match
---
trailer [5642,5647]
trailer [5607,5612]
===
match
---
trailer [5309,5315]
trailer [5274,5280]
===
match
---
operator: = [6549,6550]
operator: = [6509,6510]
===
match
---
suite [2627,2899]
suite [2592,2864]
===
match
---
expr_stmt [1871,1898]
expr_stmt [1871,1898]
===
match
---
operator: = [5097,5098]
operator: = [5062,5063]
===
match
---
name: super [2636,2641]
name: super [2601,2606]
===
match
---
name: self [1738,1742]
name: self [1738,1742]
===
match
---
operator: = [7513,7514]
operator: = [7437,7438]
===
match
---
operator: @ [1955,1956]
operator: @ [1955,1956]
===
match
---
atom_expr [1632,1684]
atom_expr [1632,1684]
===
match
---
trailer [7400,7416]
trailer [7324,7340]
===
match
---
name: FileTaskHandler [1194,1209]
name: FileTaskHandler [1194,1209]
===
match
---
return_stmt [2195,2226]
return_stmt [2195,2226]
===
match
---
atom_expr [4072,4087]
atom_expr [4037,4052]
===
match
---
name: log_relative_path [3514,3531]
name: log_relative_path [3479,3496]
===
match
---
name: self [1871,1875]
name: self [1871,1875]
===
match
---
param [2615,2617]
param [2580,2582]
===
match
---
trailer [5113,5144]
trailer [5078,5109]
===
match
---
name: exception [6622,6631]
name: exception [6582,6591]
===
match
---
except_clause [5752,5773]
except_clause [5717,5738]
===
match
---
name: super [5302,5307]
name: super [5267,5272]
===
match
---
operator: -> [4058,4060]
operator: -> [4023,4025]
===
match
---
atom_expr [3741,3786]
atom_expr [3706,3751]
===
match
---
name: set_context [2597,2608]
name: set_context [2562,2573]
===
match
---
and_test [7385,7437]
and_test [7309,7361]
===
match
---
operator: = [4695,4696]
operator: = [4660,4661]
===
match
---
name: self [7762,7766]
name: self [7686,7690]
===
match
---
name: utils [1062,1067]
name: utils [1062,1067]
===
match
---
suite [7749,7832]
suite [7673,7756]
===
match
---
name: log_relative_path [4787,4804]
name: log_relative_path [4752,4769]
===
match
---
suite [6532,6788]
suite [6492,6712]
===
match
---
name: remote_log_location [6579,6598]
name: remote_log_location [6539,6558]
===
match
---
return_stmt [5869,5881]
return_stmt [5834,5846]
===
match
---
name: ti [2615,2617]
name: ti [2580,2582]
===
match
---
name: wasb_log_folder [1494,1509]
name: wasb_log_folder [1494,1509]
===
match
---
trailer [5791,5795]
trailer [5756,5760]
===
match
---
trailer [3872,3883]
trailer [3837,3848]
===
match
---
operator: = [3712,3713]
operator: = [3677,3678]
===
match
---
atom_expr [3714,3728]
atom_expr [3679,3693]
===
match
---
arglist [5663,5703]
arglist [5628,5668]
===
match
---
tfpdef [1524,1543]
tfpdef [1524,1543]
===
match
---
atom_expr [5638,5704]
atom_expr [5603,5669]
===
match
---
name: local_loc [3669,3678]
name: local_loc [3634,3643]
===
match
---
name: self [2609,2613]
name: self [2574,2578]
===
match
---
param [5357,5362]
param [5322,5327]
===
match
---
operator: -> [6871,6873]
operator: -> [6795,6797]
===
match
---
operator: , [6474,6475]
operator: , [6439,6440]
===
match
---
arglist [3757,3785]
arglist [3722,3750]
===
match
---
name: ti [4005,4007]
name: ti [3970,3972]
===
match
---
operator: , [1607,1608]
operator: , [1607,1608]
===
match
---
trailer [1742,1754]
trailer [1742,1754]
===
match
---
suite [5397,5882]
suite [5362,5847]
===
match
---
tfpdef [5363,5387]
tfpdef [5328,5352]
===
match
---
import_from [1010,1048]
import_from [1010,1048]
===
match
---
fstring [5163,5223]
fstring [5128,5188]
===
match
---
name: self [6808,6812]
name: self [6732,6736]
===
match
---
param [6814,6823]
param [6738,6747]
===
match
---
simple_stmt [1010,1049]
simple_stmt [1010,1049]
===
match
---
operator: , [5856,5857]
operator: , [5821,5822]
===
match
---
param [1985,1989]
param [1985,1989]
===
match
---
name: path [4759,4763]
name: path [4724,4728]
===
match
---
name: conf [2049,2053]
name: conf [2049,2053]
===
match
---
name: super [3309,3314]
name: super [3274,3279]
===
match
---
name: self [3491,3495]
name: self [3456,3460]
===
match
---
trailer [6631,6672]
trailer [6591,6596]
===
match
---
operator: , [2840,2841]
operator: , [2805,2806]
===
match
---
suite [4089,5332]
suite [4054,5297]
===
match
---
if_stmt [4815,5332]
if_stmt [4780,5297]
===
match
---
name: self [2865,2869]
name: self [2830,2834]
===
match
---
trailer [2869,2885]
trailer [2834,2850]
===
match
---
simple_stmt [3391,3457]
simple_stmt [3356,3422]
===
match
---
trailer [3410,3415]
trailer [3375,3380]
===
match
---
trailer [4076,4087]
trailer [4041,4052]
===
match
---
if_stmt [3800,3885]
if_stmt [3765,3850]
===
match
---
name: remote_conn_id [2515,2529]
name: remote_conn_id [2499,2513]
===
match
---
name: wasb_read [7466,7475]
name: wasb_read [7390,7399]
===
match
---
param [4026,4056]
param [3991,4021]
===
match
---
argument [5126,5143]
argument [5091,5108]
===
match
---
operator: = [7459,7460]
operator: = [7383,7384]
===
match
---
simple_stmt [1871,1899]
simple_stmt [1871,1899]
===
match
---
funcdef [5887,6788]
funcdef [5852,6712]
===
match
---
dotted_name [1015,1036]
dotted_name [1015,1036]
===
match
---
trailer [7766,7770]
trailer [7690,7694]
===
match
---
atom_expr [3268,3279]
atom_expr [3233,3244]
===
match
---
funcdef [2904,3984]
funcdef [2869,3949]
===
match
---
string: """Close and upload local log file to remote storage Wasb.""" [2937,2998]
string: """Close and upload local log file to remote storage Wasb.""" [2902,2963]
===
match
---
return_stmt [5295,5331]
return_stmt [5260,5296]
===
match
---
dotted_name [1118,1149]
dotted_name [1118,1149]
===
match
---
return_stmt [5631,5704]
return_stmt [5596,5669]
===
match
---
name: append [7385,7391]
name: append [7309,7315]
===
match
---
simple_stmt [1113,1170]
simple_stmt [1113,1170]
===
match
---
operator: , [5246,5247]
operator: , [5211,5212]
===
match
---
name: upload_on_close [1876,1891]
name: upload_on_close [1876,1891]
===
match
---
name: raw [2895,2898]
name: raw [2860,2863]
===
match
---
parameters [3998,4057]
parameters [3963,4022]
===
match
---
simple_stmt [1738,1773]
simple_stmt [1738,1773]
===
match
---
operator: = [4050,4051]
operator: = [4015,4016]
===
match
---
name: remote_log_location [5363,5382]
name: remote_log_location [5328,5347]
===
match
---
suite [5774,5861]
suite [5739,5826]
===
match
---
suite [3826,3885]
suite [3791,3850]
===
match
---
tfpdef [1553,1575]
tfpdef [1553,1575]
===
match
---
suite [3691,3729]
suite [3656,3694]
===
match
---
simple_stmt [7587,7719]
simple_stmt [7511,7643]
===
match
---
trailer [3322,3324]
trailer [3287,3289]
===
match
---
arglist [5802,5859]
arglist [5767,5824]
===
match
---
trailer [1911,1929]
trailer [1911,1929]
===
match
---
name: self [3341,3345]
name: self [3306,3310]
===
match
---
name: os [3403,3405]
name: os [3368,3370]
===
match
---
atom_expr [2791,2813]
atom_expr [2756,2778]
===
match
---
operator: = [3780,3781]
operator: = [3745,3746]
===
match
---
name: try_number [4723,4733]
name: try_number [4688,4698]
===
match
---
name: base_log_folder [1649,1664]
name: base_log_folder [1649,1664]
===
match
---
arglist [2058,2089]
arglist [2058,2089]
===
match
---
name: remote_conn_id [2211,2225]
name: remote_conn_id [2211,2225]
===
match
---
operator: = [3401,3402]
operator: = [3366,3367]
===
match
---
trailer [2053,2057]
trailer [2053,2057]
===
match
---
param [6824,6849]
param [6748,6773]
===
match
---
name: read_file [6445,6454]
name: read_file [6410,6419]
===
match
---
param [1585,1608]
param [1585,1608]
===
match
---
atom_expr [1843,1854]
atom_expr [1843,1854]
===
match
---
operator: , [6822,6823]
operator: , [6746,6747]
===
match
---
name: self [3741,3745]
name: self [3706,3710]
===
match
---
trailer [6439,6444]
trailer [6404,6409]
===
match
---
expr_stmt [7509,7560]
expr_stmt [7433,7484]
===
match
---
atom_expr [2049,2090]
atom_expr [2049,2090]
===
match
---
suite [6415,6497]
suite [6380,6462]
===
match
---
name: msg [6545,6548]
name: msg [6505,6508]
===
match
---
simple_stmt [2000,2024]
simple_stmt [2000,2024]
===
match
---
atom_expr [4818,4850]
atom_expr [4783,4815]
===
match
---
suite [6879,7832]
suite [6803,7756]
===
match
---
name: self [2791,2795]
name: self [2756,2760]
===
match
---
simple_stmt [5631,5705]
simple_stmt [5596,5670]
===
match
---
suite [5961,6788]
suite [5926,6712]
===
match
---
parameters [6807,6870]
parameters [6731,6794]
===
match
---
atom_expr [3857,3883]
atom_expr [3822,3848]
===
match
---
arglist [2838,2855]
arglist [2803,2820]
===
match
---
with_stmt [3659,3729]
with_stmt [3624,3694]
===
match
---
trailer [3745,3756]
trailer [3710,3721]
===
match
---
trailer [4066,4088]
trailer [4031,4053]
===
match
---
param [5933,5959]
param [5898,5924]
===
match
---
name: LoggingMixin [1157,1169]
name: LoggingMixin [1157,1169]
===
match
---
atom_expr [7515,7540]
atom_expr [7439,7464]
===
match
---
trailer [4773,4785]
trailer [4738,4750]
===
match
---
expr_stmt [5086,5144]
expr_stmt [5051,5109]
===
match
---
param [3999,4004]
param [3964,3969]
===
match
---
simple_stmt [5787,5861]
simple_stmt [5752,5826]
===
match
---
name: super [1632,1637]
name: super [1632,1637]
===
match
---
name: close [3317,3322]
name: close [3282,3287]
===
match
---
name: set_context [2644,2655]
name: set_context [2609,2620]
===
match
---
expr_stmt [3708,3728]
expr_stmt [3673,3693]
===
match
---
name: delete_local_copy [1585,1602]
name: delete_local_copy [1585,1602]
===
match
---
name: self [3999,4003]
name: self [3964,3968]
===
match
---
name: str [6845,6848]
name: str [6769,6772]
===
match
---
name: upload_on_close [3346,3361]
name: upload_on_close [3311,3326]
===
match
---
if_stmt [3541,3885]
if_stmt [3506,3850]
===
match
---
atom_expr [4036,4049]
atom_expr [4001,4014]
===
match
---
trailer [3668,3679]
trailer [3633,3644]
===
match
---
name: ti [2656,2658]
name: ti [2621,2623]
===
match
---
operator: = [2814,2815]
operator: = [2779,2780]
===
match
---
suite [3280,3300]
suite [3245,3265]
===
match
---
name: remote_log_location [7684,7703]
name: remote_log_location [7608,7627]
===
match
---
trailer [7416,7437]
trailer [7340,7361]
===
match
---
name: metadata [4026,4034]
name: metadata [3991,3999]
===
match
---
string: 'Could not write logs to %s' [7781,7809]
string: 'Could not write logs to %s' [7705,7733]
===
match
---
trailer [3490,3532]
trailer [3455,3497]
===
match
---
not_test [2888,2898]
not_test [2853,2863]
===
match
---
operator: , [5905,5906]
operator: , [5870,5871]
===
match
---
arglist [7626,7704]
arglist [7550,7628]
===
match
---
trailer [3272,3279]
trailer [3237,3244]
===
match
---
simple_stmt [3309,3325]
simple_stmt [3274,3290]
===
match
---
trailer [4838,4850]
trailer [4803,4815]
===
match
---
simple_stmt [5406,5606]
simple_stmt [5371,5571]
===
match
---
param [1464,1485]
param [1464,1485]
===
match
---
expr_stmt [1817,1834]
expr_stmt [1817,1834]
===
match
---
atom_expr [3341,3361]
atom_expr [3306,3326]
===
match
---
name: log [1132,1135]
name: log [1132,1135]
===
match
---
name: msg [6665,6668]
name: msg [6592,6595]
===
match
---
strings [2307,2497]
strings [2306,2481]
===
match
---
return_stmt [5236,5268]
return_stmt [5201,5233]
===
match
---
except_clause [941,959]
except_clause [941,959]
===
match
---
name: FileTaskHandler [1097,1112]
name: FileTaskHandler [1097,1112]
===
match
---
atom_expr [1738,1754]
atom_expr [1738,1754]
===
match
---
suite [1991,2588]
suite [1991,2553]
===
match
---
name: self [1693,1697]
name: self [1693,1697]
===
match
---
trailer [3558,3569]
trailer [3523,3534]
===
match
---
name: dirname [3865,3872]
name: dirname [3830,3837]
===
match
---
parameters [5356,5388]
parameters [5321,5353]
===
match
---
name: remote_log_location [7476,7495]
name: remote_log_location [7400,7419]
===
match
---
testlist [5243,5268]
testlist [5208,5233]
===
match
---
name: ti [5316,5318]
name: ti [5281,5283]
===
match
---
atom_expr [4697,4734]
atom_expr [4662,4699]
===
match
---
decorator [1955,1972]
decorator [1955,1972]
===
match
---
simple_stmt [965,1009]
simple_stmt [965,1009]
===
match
---
simple_stmt [7451,7497]
simple_stmt [7375,7421]
===
match
---
simple_stmt [6888,7374]
simple_stmt [6812,7298]
===
match
---
operator: = [6863,6864]
operator: = [6787,6788]
===
match
---
operator: = [5138,5139]
operator: = [5103,5104]
===
match
---
name: remote_loc [3465,3475]
name: remote_loc [3430,3440]
===
match
---
name: local_base [3421,3431]
name: local_base [3386,3396]
===
match
---
name: os [3857,3859]
name: os [3822,3824]
===
match
---
atom_expr [3843,3884]
atom_expr [3808,3849]
===
match
---
name: wasb_container [6460,6474]
name: wasb_container [6425,6439]
===
match
---
operator: , [1484,1485]
operator: , [1484,1485]
===
match
---
arglist [7781,7830]
arglist [7705,7754]
===
match
---
trailer [3485,3490]
trailer [3450,3455]
===
match
---
simple_stmt [1693,1730]
simple_stmt [1693,1730]
===
match
---
name: hook [1980,1984]
name: hook [1980,1984]
===
match
---
name: Tuple [846,851]
name: Tuple [846,851]
===
match
---
trailer [6444,6454]
trailer [6409,6419]
===
match
---
operator: } [5219,5220]
operator: } [5184,5185]
===
match
---
name: join [7520,7524]
name: join [7444,7448]
===
match
---
test [7515,7560]
test [7439,7484]
===
match
---
name: conf [1044,1048]
name: conf [1044,1048]
===
match
---
name: airflow [1118,1125]
name: airflow [1118,1125]
===
match
---
operator: , [3772,3773]
operator: , [3737,3738]
===
match
---
tfpdef [1494,1514]
tfpdef [1494,1514]
===
match
---
operator: = [1855,1856]
operator: = [1855,1856]
===
match
---
operator: } [5267,5268]
operator: } [5232,5233]
===
match
---
name: try_number [4009,4019]
name: try_number [3974,3984]
===
match
---
fstring_expr [6578,6599]
fstring_expr [6538,6559]
===
match
---
simple_stmt [5086,5145]
simple_stmt [5051,5110]
===
match
---
operator: = [2886,2887]
operator: = [2851,2852]
===
match
---
simple_stmt [6545,6601]
simple_stmt [6505,6561]
===
match
---
name: bool [6858,6862]
name: bool [6782,6786]
===
match
---
trailer [7465,7475]
trailer [7389,7399]
===
match
---
name: old_log [7526,7533]
name: old_log [7450,7457]
===
match
---
name: _hook [1822,1827]
name: _hook [1822,1827]
===
match
---
name: remote_base [3496,3507]
name: remote_base [3461,3472]
===
match
---
operator: , [4003,4004]
operator: , [3968,3969]
===
match
---
name: self [5663,5667]
name: self [5628,5632]
===
match
---
arglist [5114,5143]
arglist [5079,5108]
===
match
---
name: self [7647,7651]
name: self [7571,7575]
===
match
---
name: ti [2892,2894]
name: ti [2857,2859]
===
match
---
trailer [4701,4718]
trailer [4666,4683]
===
match
---
suite [7438,7561]
suite [7362,7485]
===
match
---
trailer [7519,7524]
trailer [7443,7448]
===
match
---
param [5363,5387]
param [5328,5352]
===
match
---
name: self [2914,2918]
name: self [2879,2883]
===
match
---
trailer [1785,1803]
trailer [1785,1803]
===
match
---
trailer [3405,3410]
trailer [3370,3375]
===
match
---
trailer [7608,7718]
trailer [7532,7642]
===
match
---
fstring_string: .\n [5205,5208]
fstring_string: .\n [5170,5173]
===
match
---
if_stmt [3265,3300]
if_stmt [3230,3265]
===
match
---
simple_stmt [4743,4806]
simple_stmt [4708,4771]
===
match
---
operator: , [2613,2614]
operator: , [2578,2579]
===
match
---
operator: -> [2619,2621]
operator: -> [2584,2586]
===
match
---
name: hook [5643,5647]
name: hook [5608,5612]
===
match
---
name: microsoft [2139,2148]
name: microsoft [2139,2148]
===
match
---
simple_stmt [3293,3300]
simple_stmt [3258,3265]
===
match
---
operator: = [4754,4755]
operator: = [4719,4720]
===
match
---
trailer [4718,4734]
trailer [4683,4699]
===
match
---
return_stmt [6755,6765]
return_stmt [6679,6689]
===
match
---
import_from [1049,1112]
import_from [1049,1112]
===
match
---
name: self [7461,7465]
name: self [7385,7389]
===
match
---
tfpdef [6824,6848]
tfpdef [6748,6772]
===
match
---
name: log [6618,6621]
name: log [6578,6581]
===
match
---
import_from [1113,1169]
import_from [1113,1169]
===
match
---
string: 'the Wasb connection exists. Exception "%s"' [2453,2497]
string: ' and the Wasb connection exists.' [2447,2481]
===
match
---
atom_expr [2275,2563]
atom_expr [2270,2528]
===
match
---
atom_expr [3965,3976]
atom_expr [3930,3941]
===
match
---
atom_expr [1693,1712]
atom_expr [1693,1712]
===
match
---
import_name [787,796]
import_name [787,796]
===
match
---
classdef [1172,7832]
classdef [1172,7756]
===
match
---
name: join [3411,3415]
name: join [3376,3380]
===
match
---
name: self [5099,5103]
name: self [5064,5068]
===
match
---
param [6808,6813]
param [6732,6737]
===
match
---
trailer [3721,3726]
trailer [3686,3691]
===
match
---
tfpdef [5933,5951]
tfpdef [5898,5916]
===
match
---
name: bool [5947,5951]
name: bool [5912,5916]
===
match
---
name: debug [5796,5801]
name: debug [5761,5766]
===
match
---
name: path [3481,3485]
name: path [3446,3450]
===
match
---
atom_expr [4061,4088]
atom_expr [4026,4053]
===
match
---
trailer [5795,5801]
trailer [5760,5766]
===
match
---
simple_stmt [1049,1113]
simple_stmt [1049,1113]
===
match
---
simple_stmt [2195,2227]
simple_stmt [2195,2227]
===
match
---
name: remote_loc [3762,3772]
name: remote_loc [3727,3737]
===
match
---
name: self [4769,4773]
name: self [4734,4738]
===
match
---
trailer [5103,5113]
trailer [5068,5078]
===
match
---
simple_stmt [3741,3787]
simple_stmt [3706,3752]
===
match
---
string: """     WasbTaskHandler is a python log handler that handles and reads     task instance logs. It extends airflow FileTaskHandler and     uploads to and reads from Wasb remote storage.     """ [1230,1422]
string: """     WasbTaskHandler is a python log handler that handles and reads     task instance logs. It extends airflow FileTaskHandler and     uploads to and reads from Wasb remote storage.     """ [1230,1422]
===
match
---
operator: = [1892,1893]
operator: = [1892,1893]
===
match
---
trailer [4758,4763]
trailer [4723,4728]
===
match
---
name: self [6435,6439]
name: self [6400,6404]
===
match
---
atom_expr [5787,5860]
atom_expr [5752,5825]
===
match
---
name: remote_base [1743,1754]
name: remote_base [1743,1754]
===
match
---
operator: , [4070,4071]
operator: , [4035,4036]
===
match
---
trailer [1648,1684]
trailer [1648,1684]
===
match
---
subscriptlist [4077,4086]
subscriptlist [4042,4051]
===
match
---
simple_stmt [787,797]
simple_stmt [787,797]
===
match
---
name: old_log [7451,7458]
name: old_log [7375,7382]
===
match
---
atom_expr [3416,3431]
atom_expr [3381,3396]
===
match
---
name: self [1843,1847]
name: self [1843,1847]
===
match
---
tfpdef [1464,1484]
tfpdef [1464,1484]
===
match
---
operator: , [3431,3432]
operator: , [3396,3397]
===
match
---
name: filename_template [1666,1683]
name: filename_template [1666,1683]
===
match
---
name: str [1540,1543]
name: str [1540,1543]
===
match
---
operator: , [1543,1544]
operator: , [1543,1544]
===
match
---
trailer [3864,3872]
trailer [3829,3837]
===
match
---
arglist [1194,1223]
arglist [1194,1223]
===
match
---
name: log_relative_path [3438,3455]
name: log_relative_path [3403,3420]
===
match
---
atom_expr [7762,7831]
atom_expr [7686,7755]
===
match
---
name: wasb_write [3746,3756]
name: wasb_write [3711,3721]
===
match
---
return_stmt [2576,2587]
return_stmt [2541,2552]
===
match
---
name: remote_conn_id [2032,2046]
name: remote_conn_id [2032,2046]
===
match
---
trailer [7770,7780]
trailer [7694,7704]
===
match
---
subscriptlist [4067,4087]
subscriptlist [4032,4052]
===
match
---
atom_expr [7461,7496]
atom_expr [7385,7420]
===
match
---
string: """         Writes the log to the remote_log_location. Fails silently if no hook         was created.          :param log: the log to write to the remote_log_location         :type log: str         :param remote_log_location: the log's location in remote storage         :type remote_log_location: str (path)         :param append: if False, any existing log file is overwritten. If True,             the new log is appended to any existing logs.         :type append: bool         """ [6888,7373]
string: """         Writes the log to the remote_log_location. Fails silently if no hook         was created.          :param log: the log to write to the remote_log_location         :type log: str         :param remote_log_location: the log's location in remote storage         :type remote_log_location: str (path)         :param append: if False, any existing log file is overwritten. If True,             the new log is appended to any existing logs.         :type append: bool         """ [6812,7297]
===
match
---
atom_expr [3478,3532]
atom_expr [3443,3497]
===
match
---
name: wasb_log_folder [1757,1772]
name: wasb_log_folder [1757,1772]
===
match
---
trailer [2283,2289]
trailer [2278,2288]
===
match
---
trailer [2210,2226]
trailer [2210,2226]
===
match
---
operator: , [834,835]
operator: , [834,835]
===
match
---
operator: , [4721,4722]
operator: , [4686,4687]
===
match
---
expr_stmt [1781,1808]
expr_stmt [1781,1808]
===
match
---
operator: = [2047,2048]
operator: = [2047,2048]
===
match
---
simple_stmt [2116,2182]
simple_stmt [2116,2182]
===
match
---
suite [2103,2227]
suite [2103,2227]
===
match
---
name: self [7587,7591]
name: self [7511,7515]
===
match
---
name: log [7767,7770]
name: log [7691,7694]
===
match
---
name: azure [2149,2154]
name: azure [2149,2154]
===
match
---
name: remote_loc [5114,5124]
name: remote_loc [5079,5089]
===
match
---
name: log_relative_path [2796,2813]
name: log_relative_path [2761,2778]
===
match
---
simple_stmt [2032,2091]
simple_stmt [2032,2091]
===
match
---
trailer [2655,2659]
trailer [2620,2624]
===
match
---
name: bool [5392,5396]
name: bool [5357,5361]
===
match
---
trailer [7524,7540]
trailer [7448,7464]
===
match
---
trailer [2641,2643]
trailer [2606,2608]
===
match
---
parameters [2913,2919]
parameters [2878,2884]
===
match
---
string: 'REMOTE_LOG_CONN_ID' [2069,2089]
string: 'REMOTE_LOG_CONN_ID' [2069,2089]
===
match
---
suite [2262,2588]
suite [2257,2553]
===
match
---
try_stmt [894,1009]
try_stmt [894,1009]
===
match
---
string: 'Could not create an WasbHook with connection id "%s". ' [2307,2363]
string: 'Could not create an WasbHook with connection id "%s".' [2306,2361]
===
match
---
funcdef [2593,2899]
funcdef [2558,2864]
===
match
---
name: path [3406,3410]
name: path [3371,3375]
===
match
---
trailer [6617,6621]
trailer [6577,6581]
===
match
---
trailer [7591,7596]
trailer [7515,7520]
===
match
---
atom_expr [3664,3679]
atom_expr [3629,3644]
===
match
---
name: log [7626,7629]
name: log [7550,7553]
===
match
---
name: self [6455,6459]
name: self [6420,6424]
===
match
---
import_as_names [830,851]
import_as_names [830,851]
===
match
---
simple_stmt [5236,5269]
simple_stmt [5201,5234]
===
match
---
if_stmt [6722,6766]
if_stmt [6646,6690]
===
match
---
name: self [1985,1989]
name: self [1985,1989]
===
match
---
if_stmt [3334,3382]
if_stmt [3299,3347]
===
match
---
suite [960,1009]
suite [960,1009]
===
match
---
name: self [3803,3807]
name: self [3768,3772]
===
match
---
name: log [5792,5795]
name: log [5757,5760]
===
match
---
string: """         Check if remote_log_location exists in remote storage          :param remote_log_location: log's location in remote storage         :return: True if location exists else False         """ [5406,5605]
string: """         Check if remote_log_location exists in remote storage          :param remote_log_location: log's location in remote storage         :return: True if location exists else False         """ [5371,5570]
===
match
---
name: str [4077,4080]
name: str [4042,4045]
===
match
---
name: utils [1126,1131]
name: utils [1126,1131]
===
match
---
name: __init__ [1640,1648]
name: __init__ [1640,1648]
===
match
---
trailer [1847,1854]
trailer [1847,1854]
===
match
---
tfpdef [5907,5931]
tfpdef [5872,5896]
===
match
---
atom [5248,5268]
atom [5213,5233]
===
match
---
name: e [5772,5773]
name: e [5737,5738]
===
match
---
name: self [2275,2279]
name: self [2270,2274]
===
match
---
simple_stmt [7762,7832]
simple_stmt [7686,7756]
===
match
---
trailer [2837,2856]
trailer [2802,2821]
===
match
---
expr_stmt [7451,7496]
expr_stmt [7375,7420]
===
match
---
atom_expr [2816,2856]
atom_expr [2781,2821]
===
match
---
arglist [4719,4733]
arglist [4684,4698]
===
match
---
import_from [2116,2181]
import_from [2116,2181]
===
match
---
operator: , [1664,1665]
operator: , [1664,1665]
===
match
---
operator: , [2497,2498]
operator: , [2481,2482]
===
match
---
name: join [4764,4768]
name: join [4729,4733]
===
match
---
try_stmt [5614,5861]
try_stmt [5579,5826]
===
match
---
name: configuration [1023,1036]
name: configuration [1023,1036]
===
match
---
expr_stmt [1738,1772]
expr_stmt [1738,1772]
===
match
---
name: base_log_folder [1464,1479]
name: base_log_folder [1464,1479]
===
match
---
name: check_for_blob [5648,5662]
name: check_for_blob [5613,5627]
===
match
---
operator: , [4007,4008]
operator: , [3972,3973]
===
match
---
operator: -> [2920,2922]
operator: -> [2885,2887]
===
match
---
atom [7525,7539]
atom [7449,7463]
===
match
---
trailer [6454,6496]
trailer [6419,6461]
===
match
---
simple_stmt [4677,4735]
simple_stmt [4642,4700]
===
match
---
fstring_start: f' [6551,6553]
fstring_start: f' [6511,6513]
===
match
---
operator: = [3977,3978]
operator: = [3942,3943]
===
match
---
name: log_relative_path [1786,1803]
name: log_relative_path [1786,1803]
===
match
---
tfpdef [4009,4024]
tfpdef [3974,3989]
===
match
---
simple_stmt [3708,3729]
simple_stmt [3673,3694]
===
match
---
simple_stmt [2865,2899]
simple_stmt [2830,2864]
===
match
---
import_from [853,892]
import_from [853,892]
===
match
---
operator: , [3507,3508]
operator: , [3472,3473]
===
match
---
operator: , [6812,6813]
operator: , [6736,6737]
===
match
---
name: os [4756,4758]
name: os [4721,4723]
===
match
---
param [1524,1544]
param [1524,1544]
===
match
---
atom_expr [1907,1929]
atom_expr [1907,1929]
===
match
---
name: close [2908,2913]
name: close [2873,2878]
===
match
---
name: load_string [7597,7608]
name: load_string [7521,7532]
===
match
---
atom_expr [2842,2855]
atom_expr [2807,2820]
===
match
---
trailer [5315,5331]
trailer [5280,5296]
===
match
---
name: remote_log [5086,5096]
name: remote_log [5051,5061]
===
match
---
atom_expr [7587,7718]
atom_expr [7511,7642]
===
match
---
atom_expr [2636,2659]
atom_expr [2601,2624]
===
match
---
name: self [5901,5905]
name: self [5866,5870]
===
match
---
name: common [864,870]
name: common [864,870]
===
match
---
name: str [5384,5387]
name: str [5349,5352]
===
match
---
operator: , [1575,1576]
operator: , [1575,1576]
===
match
---
name: os [794,796]
name: os [794,796]
===
match
---
simple_stmt [853,893]
simple_stmt [853,893]
===
match
---
name: return_error [5933,5945]
name: return_error [5898,5910]
===
match
---
try_stmt [2099,2588]
try_stmt [2099,2553]
===
match
---
name: wasb_write [6797,6807]
name: wasb_write [6721,6731]
===
match
---
name: filename_template [1553,1570]
name: filename_template [1553,1570]
===
match
---
string: """Returns WasbHook.""" [2000,2023]
string: """Returns WasbHook.""" [2000,2023]
===
match
---
atom_expr [6613,6672]
atom_expr [6573,6596]
===
match
---
simple_stmt [6778,6788]
simple_stmt [6702,6712]
===
match
---
fstring_string: \n [5220,5222]
fstring_string: \n [5185,5187]
===
match
---
operator: -> [1615,1617]
operator: -> [1615,1617]
===
match
---
name: delete_local_copy [1932,1949]
name: delete_local_copy [1932,1949]
===
match
---
atom_expr [2202,2226]
atom_expr [2202,2226]
===
match
---
simple_stmt [3965,3984]
simple_stmt [3930,3949]
===
match
---
operator: = [5952,5953]
operator: = [5917,5918]
===
match
---
trailer [5801,5860]
trailer [5766,5825]
===
match
---
simple_stmt [1230,1423]
simple_stmt [1230,1423]
===
match
---
import_from [965,1008]
import_from [965,1008]
===
match
---
name: ti [4719,4721]
name: ti [4684,4686]
===
match
---
trailer [1875,1891]
trailer [1875,1891]
===
match
---
atom_expr [3803,3825]
atom_expr [3768,3790]
===
match
---
trailer [3415,3456]
trailer [3380,3421]
===
match
---
name: try_number [5320,5330]
name: try_number [5285,5295]
===
match
---
suite [7574,7719]
suite [7498,7643]
===
match
---
name: ti [2842,2844]
name: ti [2807,2809]
===
match
---
atom_expr [3433,3455]
atom_expr [3398,3420]
===
match
---
atom_expr [3403,3456]
atom_expr [3368,3421]
===
match
---
operator: = [1930,1931]
operator: = [1930,1931]
===
match
---
name: self [5638,5642]
name: self [5603,5607]
===
match
---
name: AzureHttpError [2242,2256]
name: AzureHttpError [2242,2256]
===
match
---
suite [5282,5332]
suite [5247,5297]
===
match
---
testlist_comp [7526,7538]
testlist_comp [7450,7462]
===
match
---
trailer [3437,3455]
trailer [3402,3420]
===
match
---
name: wasb_read [5891,5900]
name: wasb_read [5856,5865]
===
match
---
arglist [6455,6495]
arglist [6420,6460]
===
match
---
funcdef [1428,1950]
funcdef [1428,1950]
===
match
---
name: exception [7771,7780]
name: exception [7695,7704]
===
match
---
name: remote_log_location [5907,5926]
name: remote_log_location [5872,5891]
===
match
---
name: cached_property [925,940]
name: cached_property [925,940]
===
match
---
name: remote_log_location [7417,7436]
name: remote_log_location [7341,7360]
===
match
---
suite [3570,3885]
suite [3535,3850]
===
match
---
name: str [6819,6822]
name: str [6743,6746]
===
match
---
name: append [6850,6856]
name: append [6774,6780]
===
match
---
argument [3774,3785]
argument [3739,3750]
===
match
---
expr_stmt [2865,2898]
expr_stmt [2830,2863]
===
match
---
name: rmtree [3850,3856]
name: rmtree [3815,3821]
===
match
---
operator: , [7666,7667]
operator: , [7590,7591]
===
match
---
name: delete_local_copy [1912,1929]
name: delete_local_copy [1912,1929]
===
match
---
param [1553,1576]
param [1553,1576]
===
match
---
operator: = [1828,1829]
operator: = [1828,1829]
===
match
---
operator: , [7809,7810]
operator: , [7733,7734]
===
match
---
name: log_relative_path [4677,4694]
name: log_relative_path [4642,4659]
===
match
---
name: _render_filename [4702,4718]
name: _render_filename [4667,4683]
===
match
---
string: 'end_of_log' [5249,5261]
string: 'end_of_log' [5214,5226]
===
match
---
arglist [5316,5330]
arglist [5281,5295]
===
match
---
operator: -> [5389,5391]
operator: -> [5354,5356]
===
match
---
name: log [6814,6817]
name: log [6738,6741]
===
match
---
name: os [3544,3546]
name: os [3509,3511]
===
match
---
name: local_loc [3559,3568]
name: local_loc [3524,3533]
===
match
---
operator: { [5248,5249]
operator: { [5213,5214]
===
match
---
trailer [2279,2283]
trailer [2274,2278]
===
match
---
except_clause [2235,2261]
except_clause [2235,2256]
===
match
---
simple_stmt [2937,2999]
simple_stmt [2902,2964]
===
match
---
operator: , [5318,5319]
operator: , [5283,5284]
===
match
---
not_test [3337,3361]
not_test [3302,3326]
===
match
---
simple_stmt [2791,2857]
simple_stmt [2756,2822]
===
match
---
name: wasb_log_exists [4823,4838]
name: wasb_log_exists [4788,4803]
===
match
---
suite [4851,5269]
suite [4816,5234]
===
match
---
name: delete_local_copy [3808,3825]
name: delete_local_copy [3773,3790]
===
match
---
trailer [2820,2837]
trailer [2785,2802]
===
match
---
name: upload_on_close [2870,2885]
name: upload_on_close [2835,2850]
===
match
---
simple_stmt [6755,6766]
simple_stmt [6679,6690]
===
match
---
fstring_end: ' [5222,5223]
fstring_end: ' [5187,5188]
===
match
---
param [4009,4025]
param [3974,3990]
===
match
---
name: self [4697,4701]
name: self [4662,4666]
===
match
---
name: providers [2129,2138]
name: providers [2129,2138]
===
match
---
expr_stmt [2791,2856]
expr_stmt [2756,2821]
===
match
---
string: '\n' [7515,7519]
string: '\n' [7439,7443]
===
match
---
name: str [1481,1484]
name: str [1481,1484]
===
match
---
operator: , [1514,1515]
operator: , [1514,1515]
===
match
---
name: path [3860,3864]
name: path [3825,3829]
===
match
---
name: wasb_read [5104,5113]
name: wasb_read [5069,5078]
===
match
---
name: wasb_container [1715,1729]
name: wasb_container [1715,1729]
===
match
---
suite [5618,5705]
suite [5583,5670]
===
match
---
atom_expr [3491,3507]
atom_expr [3456,3472]
===
match
---
name: _read [3993,3998]
name: _read [3958,3963]
===
match
---
simple_stmt [3375,3382]
simple_stmt [3340,3347]
===
match
---
name: str [4021,4024]
name: str [3986,3989]
===
match
---
suite [6738,6766]
suite [6662,6690]
===
match
---
name: azure [858,863]
name: azure [858,863]
===
match
---
operator: , [2529,2530]
operator: , [2513,2514]
===
match
---
trailer [3969,3976]
trailer [3934,3941]
===
match
---
simple_stmt [5157,5224]
simple_stmt [5122,5189]
===
match
---
operator: } [5204,5205]
operator: } [5169,5170]
===
match
---
trailer [3551,3558]
trailer [3516,3523]
===
match
---
trailer [2289,2563]
trailer [2288,2528]
===
match
---
name: shutil [3843,3849]
name: shutil [3808,3814]
===
match
---
atom_expr [4769,4785]
atom_expr [4734,4750]
===
match
---
tfpdef [4026,4049]
tfpdef [3991,4014]
===
match
---
simple_stmt [6613,6673]
simple_stmt [6573,6597]
===
match
---
name: self [1781,1785]
name: self [1781,1785]
===
match
---
name: remote_log_location [5684,5703]
name: remote_log_location [5649,5668]
===
match
---
trailer [3345,3361]
trailer [3310,3326]
===
match
---
expr_stmt [5157,5223]
expr_stmt [5122,5188]
===
match
---
atom_expr [3544,3569]
atom_expr [3509,3534]
===
match
---
name: wasb_log_exists [7401,7416]
name: wasb_log_exists [7325,7340]
===
match
---
name: hooks [2155,2160]
name: hooks [2155,2160]
===
match
---
name: str [4045,4048]
name: str [4010,4013]
===
match
---
simple_stmt [903,941]
simple_stmt [903,941]
===
match
---
name: wasb_container [5668,5682]
name: wasb_container [5633,5647]
===
match
---
simple_stmt [3465,3533]
simple_stmt [3430,3498]
===
match
---
arglist [3491,3531]
arglist [3456,3496]
===
match
---
param [6850,6869]
param [6774,6793]
===
match
---
expr_stmt [4677,4734]
expr_stmt [4642,4699]
===
match
---
name: log [3757,3760]
name: log [3722,3725]
===
match
---
name: self [2816,2820]
name: self [2781,2785]
===
match
---
trailer [1697,1712]
trailer [1697,1712]
===
match
---
fstring_expr [5193,5205]
fstring_expr [5158,5170]
===
match
---
name: logging_mixin [1136,1149]
name: logging_mixin [1136,1149]
===
match
---
name: remote_loc [5194,5204]
name: remote_loc [5159,5169]
===
match
---
name: remote_loc [4743,4753]
name: remote_loc [4708,4718]
===
match
---
parameters [1440,1614]
parameters [1440,1614]
===
match
---
suite [3362,3382]
suite [3327,3347]
===
match
---
string: 'Exception when trying to check remote location: "%s"' [5802,5856]
string: 'Exception when trying to check remote location: "%s"' [5767,5821]
===
match
---
trailer [4822,4838]
trailer [4787,4803]
===
match
---
name: WasbHook [2202,2210]
name: WasbHook [2202,2210]
===
match
---
name: remote_loc [4839,4849]
name: remote_loc [4804,4814]
===
match
---
atom_expr [7396,7437]
atom_expr [7320,7361]
===
match
---
funcdef [1976,2588]
funcdef [1976,2553]
===
match
---
except_clause [6505,6531]
except_clause [6470,6491]
===
match
---
trailer [3807,3825]
trailer [3772,3790]
===
match
---
operator: = [1804,1805]
operator: = [1804,1805]
===
match
---
simple_stmt [7509,7561]
simple_stmt [7433,7485]
===
match
---
name: Dict [830,834]
name: Dict [830,834]
===
match
---
name: read [3722,3726]
name: read [3687,3691]
===
match
---
simple_stmt [797,811]
simple_stmt [797,811]
===
match
---
operator: , [6848,6849]
operator: , [6772,6773]
===
match
---
trailer [4044,4049]
trailer [4009,4014]
===
match
---
name: Optional [836,844]
name: Optional [836,844]
===
match
---
funcdef [5337,5882]
funcdef [5302,5847]
===
match
---
param [5907,5932]
param [5872,5897]
===
match
---
name: wasb_log_exists [5341,5356]
name: wasb_log_exists [5306,5321]
===
match
---
expr_stmt [6545,6600]
expr_stmt [6505,6560]
===
match
---
operator: { [5208,5209]
operator: { [5173,5174]
===
match
---
name: logfile [3714,3721]
name: logfile [3679,3686]
===
match
---
name: remote_log_location [6824,6843]
name: remote_log_location [6748,6767]
===
match
---
name: self [6613,6617]
name: self [6573,6577]
===
match
---
trailer [1639,1648]
trailer [1639,1648]
===
match
---
param [4005,4008]
param [3970,3973]
===
match
---
operator: { [6578,6579]
operator: { [6538,6539]
===
match
---
parameters [5900,5960]
parameters [5865,5925]
===
match
---
trailer [3316,3322]
trailer [3281,3287]
===
match
---
trailer [5647,5662]
trailer [5612,5627]
===
match
---
name: str [4067,4070]
name: str [4032,4035]
===
match
---
trailer [5662,5704]
trailer [5627,5669]
===
match
---
operator: , [7703,7704]
operator: , [7627,7628]
===
match
---
atom_expr [4756,4805]
atom_expr [4721,4770]
===
match
---
name: __init__ [1432,1440]
name: __init__ [1432,1440]
===
match
---
name: log [5243,5246]
name: log [5208,5211]
===
match
---
parameters [1984,1990]
parameters [1984,1990]
===
match
---
operator: = [5161,5162]
operator: = [5126,5127]
===
match
---
simple_stmt [1781,1809]
simple_stmt [1781,1809]
===
match
---
dictorsetmaker [5249,5267]
dictorsetmaker [5214,5232]
===
match
---
operator: , [4024,4025]
operator: , [3989,3990]
===
match
---
trailer [2795,2813]
trailer [2760,2778]
===
match
---
string: '' [6785,6787]
string: '' [6709,6711]
===
match
---
tfpdef [6814,6822]
tfpdef [6738,6746]
===
match
---
name: log [7509,7512]
name: log [7433,7436]
===
match
---
name: old_log [7544,7551]
name: old_log [7468,7475]
===
match
---
atom_expr [3309,3324]
atom_expr [3274,3289]
===
match
---
name: msg [6762,6765]
name: msg [6686,6689]
===
match
---
trailer [4763,4768]
trailer [4728,4733]
===
match
---
expr_stmt [3465,3532]
expr_stmt [3430,3497]
===
match
---
atom_expr [6455,6474]
atom_expr [6420,6439]
===
match
---
name: self [5357,5361]
name: self [5322,5326]
===
match
---
suite [2928,3984]
suite [2893,3949]
===
match
---
funcdef [3989,5332]
funcdef [3954,5297]
===
match
---
operator: , [844,845]
operator: , [844,845]
===
match
---
trailer [3849,3856]
trailer [3814,3821]
===
match
---
trailer [7596,7608]
trailer [7520,7532]
===
match
---
simple_stmt [5970,6403]
simple_stmt [5935,6368]
===
match
---
name: str [1511,1514]
name: str [1511,1514]
===
match
---
name: path [3547,3551]
name: path [3512,3516]
===
match
---
name: os [3478,3480]
name: os [3443,3445]
===
match
---
operator: , [3760,3761]
operator: , [3725,3726]
===
match
---
trailer [1637,1639]
trailer [1637,1639]
===
match
---
funcdef [6793,7832]
funcdef [6717,7756]
===
match
---
param [1494,1515]
param [1494,1515]
===
match
---
operator: } [6598,6599]
operator: } [6558,6559]
===
match
---
param [2609,2614]
param [2574,2579]
===
match
---
name: AzureHttpError [7734,7748]
name: AzureHttpError [7658,7672]
===
match
---
simple_stmt [811,852]
simple_stmt [811,852]
===
match
---
if_stmt [7382,7561]
if_stmt [7306,7485]
===
match
---
name: self [3433,3437]
name: self [3398,3402]
===
match
---
param [1450,1455]
param [1450,1455]
===
match
---
name: log [7557,7560]
name: log [7481,7484]
===
match
---
return_stmt [6778,6787]
return_stmt [6702,6711]
===
match
---
name: wasb_container [7652,7666]
name: wasb_container [7576,7590]
===
match
---
trailer [2057,2090]
trailer [2057,2090]
===
match
---
trailer [2844,2855]
trailer [2809,2820]
===
match
---
trailer [5667,5682]
trailer [5632,5647]
===
match
---
simple_stmt [2636,2660]
simple_stmt [2601,2625]
===
match
---
dotted_name [858,870]
dotted_name [858,870]
===
match
---
operator: = [3476,3477]
operator: = [3441,3442]
===
match
---
name: self [3268,3272]
name: self [3233,3237]
===
match
---
trailer [6459,6474]
trailer [6424,6439]
===
match
---
name: self [1450,1454]
name: self [1450,1454]
===
match
---
name: shutil [804,810]
name: shutil [804,810]
===
match
---
operator: = [1713,1714]
operator: = [1713,1714]
===
match
---
name: return_error [6725,6737]
name: return_error [6649,6661]
===
match
---
name: Optional [4036,4044]
name: Optional [4001,4009]
===
match
---
name: remote_log_location [6476,6495]
name: remote_log_location [6441,6460]
===
match
---
operator: , [5682,5683]
operator: , [5647,5648]
===
match
---
name: log [3708,3711]
name: log [3673,3676]
===
match
---
name: cached_property [970,985]
name: cached_property [970,985]
===
match
---
dotted_name [2121,2165]
dotted_name [2121,2165]
===
match
---
atom_expr [2892,2898]
atom_expr [2857,2863]
===
match
---
name: self [5787,5791]
name: self [5752,5756]
===
match
---
trailer [3420,3431]
trailer [3385,3396]
===
match
---
atom_expr [1817,1827]
atom_expr [1817,1827]
===
match
---
simple_stmt [2275,2564]
simple_stmt [2270,2529]
===
match
---
simple_stmt [1843,1863]
simple_stmt [1843,1863]
===
match
---
fstring_end: ' [6599,6600]
fstring_end: ' [6559,6560]
===
match
---
expr_stmt [3391,3456]
expr_stmt [3356,3421]
===
match
---
try_stmt [7570,7832]
try_stmt [7494,7756]
===
match
---
name: _render_filename [2821,2837]
name: _render_filename [2786,2802]
===
match
---
fstring_string: *** Reading remote log from  [5165,5193]
fstring_string: *** Reading remote log from  [5130,5158]
===
match
---
arglist [2307,2549]
arglist [2306,2514]
===
match
---
trailer [5307,5309]
trailer [5272,5274]
===
match
---
suite [898,941]
suite [898,941]
===
match
---
name: file_task_handler [1072,1089]
name: file_task_handler [1072,1089]
===
match
---
arglist [3416,3455]
arglist [3381,3420]
===
match
---
arglist [4769,4804]
arglist [4734,4769]
===
match
---
operator: , [7629,7630]
operator: , [7553,7554]
===
match
---
expr_stmt [3965,3983]
expr_stmt [3930,3948]
===
match
---
parameters [2608,2618]
parameters [2573,2583]
===
match
---
simple_stmt [2576,2588]
simple_stmt [2541,2553]
===
match
---
trailer [1821,1827]
trailer [1821,1827]
===
match
---
name: LoggingMixin [1211,1223]
name: LoggingMixin [1211,1223]
===
match
---
name: _read [5310,5315]
name: _read [5275,5280]
===
match
---
import_from [811,851]
import_from [811,851]
===
match
---
import_from [903,940]
import_from [903,940]
===
match
---
name: AzureHttpError [6512,6526]
name: AzureHttpError [6477,6491]
===
match
---
name: self [3509,3513]
name: self [3474,3478]
===
match
---
name: local_loc [3873,3882]
name: local_loc [3838,3847]
===
match
---
name: bool [4082,4086]
name: bool [4047,4051]
===
match
---
operator: = [1755,1756]
operator: = [1755,1756]
===
match
---
name: airflow [1015,1022]
name: airflow [1015,1022]
===
match
---
string: """         Read logs of given task instance and try_number from Wasb remote storage.         If failed, read the log from task instance host machine.          :param ti: task instance object         :param try_number: task instance try_number to read logs from         :param metadata: log metadata,                          can be used for steaming log reading and auto-tailing.         """ [4098,4490]
string: """         Read logs of given task instance and try_number from Wasb remote storage.         If failed, read the log from task instance host machine.          :param ti: task instance object         :param try_number: task instance try_number to read logs from         :param metadata: log metadata,                          can be used for steaming log reading and auto-tailing.         """ [4063,4455]
===
match
---
expr_stmt [1693,1729]
expr_stmt [1693,1729]
===
match
---
operator: , [4785,4786]
operator: , [4750,4751]
===
match
---
simple_stmt [5295,5332]
simple_stmt [5260,5297]
===
match
---
name: remote_base [4774,4785]
name: remote_base [4739,4750]
===
match
---
operator: , [1209,1210]
operator: , [1209,1210]
===
match
---
simple_stmt [6428,6497]
simple_stmt [6393,6462]
===
match
---
name: append [3774,3780]
name: append [3739,3745]
===
match
---
trailer [7651,7666]
trailer [7575,7590]
===
match
---
simple_stmt [5869,5882]
simple_stmt [5834,5847]
===
match
---
name: remote_log [5209,5219]
name: remote_log [5174,5184]
===
match
---
name: remote_log_location [7811,7830]
name: remote_log_location [7735,7754]
===
match
---
name: typing [816,822]
name: typing [816,822]
===
match
---
name: logfile [3683,3690]
name: logfile [3648,3655]
===
match
---
trailer [3495,3507]
trailer [3460,3472]
===
match
---
string: 'logging' [2058,2067]
string: 'logging' [2058,2067]
===
match
---
name: closed [1848,1854]
name: closed [1848,1854]
===
match
---
name: self [3965,3969]
name: self [3930,3934]
===
match
---
name: airflow [2121,2128]
name: airflow [2121,2128]
===
match
---
name: WasbHook [2173,2181]
name: WasbHook [2173,2181]
===
match
---
trailer [3513,3531]
trailer [3478,3496]
===
match
---
trailer [2894,2898]
trailer [2859,2863]
===
match
---
fstring_string: Could not read logs from  [6553,6578]
fstring_string: Could not read logs from  [6513,6538]
===
match
---
name: WasbTaskHandler [1178,1193]
name: WasbTaskHandler [1178,1193]
===
match
---
name: error [2284,2289]
name: exception [2279,2288]
===
match
---
name: Exception [5759,5768]
name: Exception [5724,5733]
===
match
---
except_clause [7727,7748]
except_clause [7651,7672]
===
match
---
name: AzureHttpError [878,892]
name: AzureHttpError [878,892]
===
match
---
name: e [5858,5859]
name: e [5823,5824]
===
match
---
name: airflow [1054,1061]
name: airflow [1054,1061]
===
match
---
name: log [2280,2283]
name: log [2275,2278]
===
match
---
trailer [3859,3864]
trailer [3824,3829]
===
match
---
fstring_start: f' [5163,5165]
fstring_start: f' [5128,5130]
===
match
---
atom_expr [1781,1803]
atom_expr [1781,1803]
===
match
---
name: return_error [5126,5138]
name: return_error [5091,5103]
===
match
---
atom_expr [6435,6496]
atom_expr [6400,6461]
===
match
---
name: wasb_container [1524,1538]
name: wasb_container [1524,1538]
===
match
---
name: Dict [4072,4076]
name: Dict [4037,4041]
===
match
---
name: open [3664,3668]
name: open [3629,3633]
===
match
---
operator: , [1454,1455]
operator: , [1454,1455]
===
match
---
simple_stmt [1907,1950]
simple_stmt [1907,1950]
===
match
---
trailer [3726,3728]
trailer [3691,3693]
===
match
---
string: 'Please make sure that airflow[azure] is installed and ' [2380,2436]
string: ' Please make sure that airflow[azure] is installed' [2378,2430]
===
match
---
atom_expr [5663,5682]
atom_expr [5628,5647]
===
match
---
trailer [3314,3316]
trailer [3279,3281]
===
match
---
trailer [7475,7496]
trailer [7399,7420]
===
match
---
atom_expr [5099,5144]
atom_expr [5064,5109]
===
match
---
name: wasb_container [1698,1712]
name: wasb_container [1698,1712]
===
match
---
name: local_loc [3391,3400]
name: local_loc [3356,3365]
===
match
---
expr_stmt [4743,4805]
expr_stmt [4708,4770]
===
match
---
fstring [6551,6600]
fstring [6511,6560]
===
match
---
decorated [1955,2588]
decorated [1955,2553]
===
match
---
trailer [3856,3884]
trailer [3821,3849]
===
match
---
trailer [7780,7831]
trailer [7704,7755]
===
match
---
name: cached_property [1956,1971]
name: cached_property [1956,1971]
===
match
---
trailer [3546,3551]
trailer [3511,3516]
===
match
---
operator: , [5124,5125]
operator: , [5089,5090]
===
match
---
atom_expr [3509,3531]
atom_expr [3474,3496]
===
match
---
name: exists [3552,3558]
name: exists [3517,3523]
===
match
---
simple_stmt [3843,3885]
simple_stmt [3808,3850]
===
match
---
try_stmt [6411,6788]
try_stmt [6376,6712]
===
match
---
expr_stmt [1907,1949]
expr_stmt [1907,1949]
===
match
---
with_item [3664,3690]
with_item [3629,3655]
===
match
---
name: closed [3273,3279]
name: closed [3238,3244]
===
match
---
name: str [5928,5931]
name: str [5893,5896]
===
match
---
atom_expr [2865,2885]
atom_expr [2830,2850]
===
match
---
operator: , [7533,7534]
operator: , [7457,7458]
===
match
---
dotted_name [1054,1089]
dotted_name [1054,1089]
===
match
---
name: hook [7592,7596]
name: hook [7516,7520]
===
match
---
name: str [1604,1607]
name: str [1604,1607]
===
match
---
simple_stmt [1817,1835]
simple_stmt [1817,1835]
===
match
---
param [5901,5906]
param [5866,5871]
===
match
---
atom_expr [7647,7666]
atom_expr [7571,7590]
===
match
---
name: self [1817,1821]
name: self [1817,1821]
===
match
---
atom_expr [1871,1891]
atom_expr [1871,1891]
===
match
---
operator: { [5193,5194]
operator: { [5158,5159]
===
match
---
name: str [1572,1575]
name: str [1572,1575]
===
match
---
tfpdef [6850,6862]
tfpdef [6774,6786]
===
match
---
name: self [3416,3420]
name: self [3381,3385]
===
match
---
name: log [7535,7538]
name: log [7459,7462]
===
match
---
name: try_number [2845,2855]
name: try_number [2810,2820]
===
match
---
name: ti [2838,2840]
name: ti [2803,2805]
===
match
---
expr_stmt [1843,1862]
expr_stmt [1843,1862]
===
match
---
operator: , [5361,5362]
operator: , [5326,5327]
===
match
---
name: log [1068,1071]
name: log [1068,1071]
===
match
---
name: cached_property [993,1008]
name: cached_property [993,1008]
===
match
---
name: wasb [2161,2165]
name: wasb [2161,2165]
===
match
---
file_input [787,7832]
file_input [787,7756]
===
match
---
string: '' [1806,1808]
string: '' [1806,1808]
===
match
---
name: self [4818,4822]
name: self [4783,4787]
===
match
---
simple_stmt [4098,4491]
simple_stmt [4063,4456]
===
match
---
name: log [5157,5160]
name: log [5122,5125]
===
match
---
operator: , [5931,5932]
operator: , [5896,5897]
===
match
---
name: Tuple [4061,4066]
name: Tuple [4026,4031]
===
match
---
suite [1623,1950]
suite [1623,1950]
===
match
---
string: """         Returns the log found at the remote_log_location. Returns '' if no         logs are found or there is an error.          :param remote_log_location: the log's location in remote storage         :type remote_log_location: str (path)         :param return_error: if True, returns a string error message if an             error occurs. Otherwise returns '' when an error occurs.         :type return_error: bool         """ [5970,6402]
string: """         Returns the log found at the remote_log_location. Returns '' if no         logs are found or there is an error.          :param remote_log_location: the log's location in remote storage         :type remote_log_location: str (path)         :param return_error: if True, returns a string error message if an             error occurs. Otherwise returns '' when an error occurs.         :type return_error: bool         """ [5935,6367]
===
match
---
simple_stmt [1632,1685]
simple_stmt [1632,1685]
===
match
---
import_name [797,810]
import_name [797,810]
===
match
---
name: closed [3970,3976]
name: closed [3935,3941]
===
match
---
suite [1225,7832]
suite [1225,7756]
===
match
---
name: ImportError [948,959]
name: ImportError [948,959]
===
match
---
param [2914,2918]
param [2879,2883]
===
match
---
arglist [1649,1683]
arglist [1649,1683]
===
match
---
atom_expr [5302,5331]
atom_expr [5267,5296]
===
match
---
trailer [3480,3485]
trailer [3445,3450]
===
match
---
name: hook [6440,6444]
name: hook [6405,6409]
===
match
---
name: functools [908,917]
name: functools [908,917]
===
match
---
fstring_expr [5208,5220]
fstring_expr [5173,5185]
===
match
---
trailer [2643,2655]
trailer [2608,2620]
===
match
---
name: get [2054,2057]
name: get [2054,2057]
===
match
---
trailer [3756,3786]
trailer [3721,3751]
===
match
---
trailer [6621,6631]
trailer [6581,6591]
===
match
---
operator: , [2067,2068]
operator: , [2067,2068]
===
match
---
return_stmt [6428,6496]
return_stmt [6393,6461]
===
match
---
expr_stmt [2032,2090]
expr_stmt [2032,2090]
===
match
---
tfpdef [1585,1607]
tfpdef [1585,1607]
===
move-tree
---
name: msg [6665,6668]
to
trailer [6631,6672]
at 0
===
update-node
---
name: error [2284,2289]
replace error by exception
===
update-node
---
string: 'Could not create an WasbHook with connection id "%s". ' [2307,2363]
replace 'Could not create an WasbHook with connection id "%s". ' by 'Could not create an WasbHook with connection id "%s".'
===
update-node
---
string: 'Please make sure that airflow[azure] is installed and ' [2380,2436]
replace 'Please make sure that airflow[azure] is installed and ' by ' Please make sure that airflow[azure] is installed'
===
update-node
---
string: 'the Wasb connection exists. Exception "%s"' [2453,2497]
replace 'the Wasb connection exists. Exception "%s"' by ' and the Wasb connection exists.'
===
delete-node
---
name: e [2260,2261]
===
===
delete-node
---
name: e [2547,2548]
===
===
delete-node
---
operator: , [2548,2549]
===
===
delete-node
---
name: e [6530,6531]
===
===
delete-node
---
arglist [6632,6671]
===
