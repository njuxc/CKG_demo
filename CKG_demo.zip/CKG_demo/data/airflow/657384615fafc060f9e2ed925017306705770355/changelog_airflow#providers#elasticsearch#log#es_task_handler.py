===
match
---
trailer [7802,7808]
trailer [7802,7808]
===
match
---
return_stmt [13733,13743]
return_stmt [13709,13719]
===
match
---
name: self [7857,7861]
name: self [7857,7861]
===
match
---
atom_expr [7893,7909]
atom_expr [7893,7909]
===
match
---
arith_expr [13669,13724]
arith_expr [13645,13700]
===
match
---
trailer [7149,7171]
trailer [7149,7171]
===
match
---
simple_stmt [12773,12801]
simple_stmt [12749,12777]
===
match
---
name: super [11592,11597]
name: super [11568,11573]
===
match
---
trailer [3810,3832]
trailer [3810,3832]
===
match
---
trailer [3429,3447]
trailer [3429,3447]
===
match
---
trailer [3514,3527]
trailer [3514,3527]
===
match
---
trailer [12946,12955]
trailer [12922,12931]
===
match
---
or_test [12381,12438]
or_test [12357,12414]
===
match
---
operator: = [3607,3608]
operator: = [3607,3608]
===
match
---
trailer [13702,13724]
trailer [13678,13700]
===
match
---
trailer [7850,7855]
trailer [7850,7855]
===
match
---
simple_stmt [12062,12069]
simple_stmt [12038,12045]
===
match
---
tfpdef [5330,5354]
tfpdef [5330,5354]
===
match
---
name: get_external_log_url [12965,12985]
name: get_external_log_url [12941,12961]
===
match
---
operator: >= [7244,7246]
operator: >= [7244,7246]
===
match
---
string: 'gt' [9414,9418]
string: 'gt' [9414,9418]
===
match
---
name: self [12412,12416]
name: self [12388,12392]
===
match
---
name: stream [12425,12431]
name: stream [12401,12407]
===
match
---
trailer [5028,5033]
trailer [5028,5033]
===
match
---
name: logs_by_host [6036,6048]
name: logs_by_host [6036,6048]
===
match
---
expr_stmt [10490,10525]
expr_stmt [10466,10501]
===
match
---
name: context_set [11190,11201]
name: context_set [11166,11177]
===
match
---
argument [13565,13608]
argument [13541,13584]
===
match
---
name: item [6685,6689]
name: item [6685,6689]
===
match
---
suite [9850,9944]
suite [9850,9944]
===
match
---
trailer [10213,10278]
trailer [10208,10254]
===
match
---
if_stmt [11944,11979]
if_stmt [11920,11955]
===
match
---
name: self [11995,11999]
name: self [11971,11975]
===
match
---
operator: -> [10345,10347]
operator: -> [10321,10323]
===
match
---
trailer [7550,7558]
trailer [7550,7558]
===
match
---
atom_expr [5937,5972]
atom_expr [5937,5972]
===
match
---
trailer [9706,9708]
trailer [9706,9708]
===
match
---
name: self [11663,11667]
name: self [11639,11643]
===
match
---
operator: = [9299,9300]
operator: = [9299,9300]
===
match
---
comparison [7313,7355]
comparison [7313,7355]
===
match
---
dotted_name [1380,1412]
dotted_name [1380,1412]
===
match
---
name: log_line [8499,8507]
name: log_line [8499,8507]
===
match
---
name: staticmethod [4835,4847]
name: staticmethod [4835,4847]
===
match
---
atom_expr [10568,10582]
atom_expr [10544,10558]
===
match
---
operator: , [2895,2896]
operator: , [2895,2896]
===
match
---
name: closed [12036,12042]
name: closed [12012,12018]
===
match
---
param [5289,5294]
param [5289,5294]
===
match
---
name: log [5041,5044]
name: log [5041,5044]
===
match
---
operator: ** [13984,13986]
operator: ** [13960,13962]
===
match
---
simple_stmt [3846,3888]
simple_stmt [3846,3888]
===
match
---
atom_expr [11534,11548]
atom_expr [11510,11524]
===
match
---
trailer [12815,12817]
trailer [12791,12793]
===
match
---
name: __init__ [13950,13958]
name: __init__ [13926,13934]
===
match
---
name: elasticsearch [3334,3347]
name: elasticsearch [3334,3347]
===
match
---
trailer [5993,6001]
trailer [5993,6001]
===
match
---
operator: , [2684,2685]
operator: , [2684,2685]
===
match
---
param [13021,13036]
param [12997,13012]
===
match
---
name: self [11011,11015]
name: self [10987,10991]
===
match
---
simple_stmt [4142,4189]
simple_stmt [4142,4189]
===
match
---
operator: = [5879,5880]
operator: = [5879,5880]
===
match
---
name: file_task_handler [1334,1351]
name: file_task_handler [1334,1351]
===
match
---
name: items [5128,5133]
name: items [5128,5133]
===
match
---
name: str [2795,2798]
name: str [2795,2798]
===
match
---
simple_stmt [5406,5749]
simple_stmt [5406,5749]
===
match
---
funcdef [8710,10300]
funcdef [8710,10276]
===
match
---
name: offset [9713,9719]
name: offset [9713,9719]
===
match
---
trailer [3986,3993]
trailer [3986,3993]
===
match
---
name: execution_date [10910,10924]
name: execution_date [10886,10900]
===
match
---
string: 'try_number' [3914,3926]
string: 'try_number' [3914,3926]
===
match
---
atom_expr [9649,9671]
atom_expr [9649,9671]
===
match
---
arglist [5115,5185]
arglist [5115,5185]
===
match
---
suite [5773,5811]
suite [5773,5811]
===
match
---
name: get_template_context [3865,3885]
name: get_template_context [3865,3885]
===
match
---
name: append [5034,5040]
name: append [5034,5040]
===
match
---
expr_stmt [3392,3416]
expr_stmt [3392,3416]
===
match
---
trailer [3138,3147]
trailer [3138,3147]
===
match
---
name: search [9674,9680]
name: search [9674,9680]
===
match
---
trailer [11628,11640]
trailer [11604,11616]
===
match
---
import_from [880,901]
import_from [880,901]
===
match
---
trailer [7879,7882]
trailer [7879,7882]
===
match
---
name: strip [7803,7808]
name: strip [7803,7808]
===
match
---
name: conf [1175,1179]
name: conf [1175,1179]
===
match
---
name: log_id_template [3294,3309]
name: log_id_template [3294,3309]
===
match
---
name: offset [8741,8747]
name: offset [8741,8747]
===
match
---
trailer [12486,12492]
trailer [12462,12468]
===
match
---
atom_expr [3806,3832]
atom_expr [3806,3832]
===
match
---
name: format [8458,8464]
name: format [8458,8464]
===
match
---
not_test [6790,6798]
not_test [6790,6798]
===
match
---
atom_expr [10778,10792]
atom_expr [10754,10768]
===
match
---
string: 'max_offset' [7341,7353]
string: 'max_offset' [7341,7353]
===
match
---
name: sort [9350,9354]
name: sort [9350,9354]
===
match
---
name: json_format [3570,3581]
name: json_format [3570,3581]
===
match
---
atom_expr [7206,7243]
atom_expr [7206,7243]
===
match
---
name: json_fields [3595,3606]
name: json_fields [3595,3606]
===
match
---
string: "localhost:5601" [2801,2817]
string: "localhost:5601" [2801,2817]
===
match
---
trailer [7134,7140]
trailer [7134,7140]
===
match
---
simple_stmt [1524,1561]
simple_stmt [1524,1561]
===
match
---
name: grouped_logs [5115,5127]
name: grouped_logs [5115,5127]
===
match
---
expr_stmt [9953,9962]
expr_stmt [9953,9962]
===
match
---
name: lines [7820,7825]
name: lines [7820,7825]
===
match
---
expr_stmt [5982,6027]
expr_stmt [5982,6027]
===
match
---
trailer [3621,3623]
trailer [3621,3623]
===
match
---
name: str [8749,8752]
name: str [8749,8752]
===
match
---
name: kwargs [13986,13992]
name: kwargs [13962,13968]
===
match
---
name: str [2653,2656]
name: str [2653,2656]
===
match
---
expr_stmt [7514,7558]
expr_stmt [7514,7558]
===
match
---
name: parse_template_string [1289,1310]
name: parse_template_string [1289,1310]
===
match
---
trailer [11472,11478]
trailer [11448,11454]
===
match
---
trailer [13467,13654]
trailer [13443,13630]
===
match
---
suite [9628,9720]
suite [9628,9720]
===
match
---
tfpdef [3752,3768]
tfpdef [3752,3768]
===
match
---
string: 'Elasticsearch' [2449,2464]
string: 'Elasticsearch' [2449,2464]
===
match
---
trailer [5159,5185]
trailer [5159,5185]
===
match
---
trailer [8331,8343]
trailer [8331,8343]
===
match
---
name: self [3551,3555]
name: self [3551,3555]
===
match
---
param [2721,2738]
param [2721,2738]
===
match
---
atom_expr [3610,3623]
atom_expr [3610,3623]
===
match
---
operator: = [5899,5900]
operator: = [5899,5900]
===
match
---
trailer [8478,8518]
trailer [8478,8518]
===
match
---
funcdef [4369,4829]
funcdef [4369,4829]
===
match
---
trailer [6653,6656]
trailer [6653,6656]
===
match
---
if_stmt [9480,9944]
if_stmt [9480,9944]
===
match
---
trailer [9304,9311]
trailer [9304,9311]
===
match
---
name: try_number [5313,5323]
name: try_number [5313,5323]
===
match
---
if_stmt [7063,7417]
if_stmt [7063,7417]
===
match
---
trailer [11599,11611]
trailer [11575,11587]
===
match
---
atom_expr [11446,11479]
atom_expr [11422,11455]
===
match
---
param [13965,13983]
param [13941,13959]
===
match
---
name: metadata [7090,7098]
name: metadata [7090,7098]
===
match
---
atom_expr [3960,4010]
atom_expr [3960,4010]
===
match
---
name: strip [6730,6735]
name: strip [6730,6735]
===
match
---
operator: = [10704,10705]
operator: = [10680,10681]
===
match
---
operator: , [11049,11050]
operator: , [11025,11026]
===
match
---
trailer [7212,7217]
trailer [7212,7217]
===
match
---
atom_expr [10961,10979]
atom_expr [10937,10955]
===
match
---
atom_expr [12649,12696]
atom_expr [12625,12672]
===
match
---
name: metadata [7141,7149]
name: metadata [7141,7149]
===
match
---
name: staticmethod [4352,4364]
name: staticmethod [4352,4364]
===
match
---
atom_expr [3131,3183]
atom_expr [3131,3183]
===
match
---
operator: = [3860,3861]
operator: = [3860,3861]
===
match
---
trailer [11538,11548]
trailer [11514,11524]
===
match
---
name: level [11473,11478]
name: level [11449,11454]
===
match
---
dictorsetmaker [9414,9431]
dictorsetmaker [9414,9431]
===
match
---
trailer [12416,12424]
trailer [12392,12400]
===
match
---
atom_expr [12835,12846]
atom_expr [12811,12822]
===
match
---
operator: , [5311,5312]
operator: , [5311,5312]
===
match
---
atom [7931,8001]
atom [7931,8001]
===
match
---
parameters [3745,3786]
parameters [3745,3786]
===
match
---
comparison [7206,7248]
comparison [7206,7248]
===
match
---
suite [13766,14106]
suite [13742,14082]
===
match
---
name: Exception [10131,10140]
name: Exception [10131,10140]
===
match
---
operator: } [3121,3122]
operator: } [3121,3122]
===
match
---
name: es_kwargs [3372,3381]
name: es_kwargs [3372,3381]
===
match
---
simple_stmt [1180,1220]
simple_stmt [1180,1220]
===
match
---
name: _clean_execution_date [4373,4394]
name: _clean_execution_date [4373,4394]
===
match
---
operator: , [13508,13509]
operator: , [13484,13485]
===
match
---
parameters [12985,13037]
parameters [12961,13013]
===
match
---
name: __dict__ [14082,14090]
name: __dict__ [14058,14066]
===
match
---
trailer [10070,10075]
trailer [10070,10075]
===
match
---
number: 1 [7768,7769]
number: 1 [7768,7769]
===
match
---
atom_expr [11081,11104]
atom_expr [11057,11080]
===
match
---
name: ti [10965,10967]
name: ti [10941,10943]
===
match
---
name: str [4424,4427]
name: str [4424,4427]
===
match
---
atom_expr [7141,7171]
atom_expr [7141,7171]
===
match
---
name: handler [11451,11458]
name: handler [11427,11434]
===
match
---
trailer [11512,11520]
trailer [11488,11496]
===
match
---
name: self [12649,12653]
name: self [12625,12629]
===
match
---
name: str [2753,2756]
name: str [2753,2756]
===
match
---
decorator [4351,4365]
decorator [4351,4365]
===
match
---
name: execution_date [4781,4795]
name: execution_date [4781,4795]
===
match
---
funcdef [8041,8705]
funcdef [8041,8705]
===
match
---
name: jinja_context [3900,3913]
name: jinja_context [3900,3913]
===
match
---
factor [9709,9711]
factor [9709,9711]
===
match
---
name: execution_date [4162,4176]
name: execution_date [4162,4176]
===
match
---
operator: = [11641,11642]
operator: = [11617,11618]
===
match
---
atom_expr [3334,3382]
atom_expr [3334,3382]
===
match
---
name: airflow [1316,1323]
name: airflow [1316,1323]
===
match
---
trailer [7340,7354]
trailer [7340,7354]
===
match
---
string: 'try_number' [10947,10959]
string: 'try_number' [10923,10935]
===
match
---
trailer [7432,7440]
trailer [7432,7440]
===
match
---
atom_expr [11358,11370]
atom_expr [11334,11346]
===
match
---
atom [9413,9432]
atom [9413,9432]
===
match
---
tfpdef [5295,5311]
tfpdef [5295,5311]
===
match
---
simple_stmt [9867,9944]
simple_stmt [9867,9944]
===
match
---
except_clause [10124,10145]
except_clause [10124,10140]
===
match
---
trailer [10203,10213]
trailer [10198,10208]
===
match
---
operator: , [9404,9405]
operator: , [9404,9405]
===
match
---
operator: , [8739,8740]
operator: , [8739,8740]
===
match
---
string: '' [14065,14067]
string: '' [14041,14043]
===
match
---
name: write_stdout [3530,3542]
name: write_stdout [3530,3542]
===
match
---
suite [4129,4189]
suite [4129,4189]
===
match
---
name: defaultdict [4906,4917]
name: defaultdict [4906,4917]
===
match
---
name: self [12381,12385]
name: self [12357,12361]
===
match
---
operator: - [7753,7754]
operator: - [7753,7754]
===
match
---
name: metadata [9649,9657]
name: metadata [9649,9657]
===
match
---
name: datetime [4411,4419]
name: datetime [4411,4419]
===
match
---
arglist [9886,9942]
arglist [9886,9942]
===
match
---
name: utils [1447,1452]
name: utils [1447,1452]
===
match
---
trailer [5127,5133]
trailer [5127,5133]
===
match
---
name: log_id [13703,13709]
name: log_id [13679,13685]
===
match
---
suite [12899,12956]
suite [12875,12932]
===
match
---
name: elasticsearch [1073,1086]
name: elasticsearch [1073,1086]
===
match
---
operator: = [7410,7411]
operator: = [7410,7411]
===
match
---
name: self [10568,10572]
name: self [10544,10548]
===
match
---
expr_stmt [3697,3721]
expr_stmt [3697,3721]
===
match
---
operator: = [7929,7930]
operator: = [7929,7930]
===
match
---
operator: = [12043,12044]
operator: = [12019,12020]
===
match
---
simple_stmt [7112,7173]
simple_stmt [7112,7173]
===
match
---
name: self [3960,3964]
name: self [3960,3964]
===
match
---
import_from [1103,1139]
import_from [1103,1139]
===
match
---
trailer [5114,5186]
trailer [5114,5186]
===
match
---
name: PAGE [2396,2400]
name: PAGE [2396,2400]
===
match
---
name: es_kwargs [3107,3116]
name: es_kwargs [3107,3116]
===
match
---
operator: , [9934,9935]
operator: , [9934,9935]
===
match
---
trailer [13715,13723]
trailer [13691,13699]
===
match
---
name: try_number [13622,13632]
name: try_number [13598,13608]
===
match
---
name: self [10538,10542]
name: self [10514,10518]
===
match
---
comp_if [6682,6737]
comp_if [6682,6737]
===
match
---
operator: > [9624,9625]
operator: > [9624,9625]
===
match
---
name: log_range [7729,7738]
name: log_range [7729,7738]
===
match
---
name: offset [5892,5898]
name: offset [5892,5898]
===
match
---
trailer [12385,12393]
trailer [12361,12369]
===
match
---
operator: = [2799,2800]
operator: = [2799,2800]
===
match
---
name: client [3325,3331]
name: client [3325,3331]
===
match
---
name: self [12740,12744]
name: self [12716,12720]
===
match
---
simple_stmt [7514,7559]
simple_stmt [7514,7559]
===
match
---
name: log_id_jinja_template [3965,3986]
name: log_id_jinja_template [3965,3986]
===
match
---
trailer [6429,6439]
trailer [6429,6439]
===
match
---
trailer [6445,6458]
trailer [6445,6458]
===
match
---
import_name [803,813]
import_name [803,813]
===
match
---
atom_expr [10907,10924]
atom_expr [10883,10900]
===
match
---
trailer [9770,9784]
trailer [9770,9784]
===
match
---
name: handler [12386,12393]
name: handler [12362,12369]
===
match
---
string: 'match_phrase' [9319,9333]
string: 'match_phrase' [9319,9333]
===
match
---
trailer [7819,7826]
trailer [7819,7826]
===
match
---
argument [4283,4312]
argument [4283,4312]
===
match
---
operator: = [2401,2402]
operator: = [2401,2402]
===
match
---
simple_stmt [3697,3722]
simple_stmt [3697,3722]
===
match
---
name: search [10034,10040]
name: search [10034,10040]
===
match
---
trailer [11089,11091]
trailer [11065,11067]
===
match
---
name: execution_date [13565,13579]
name: execution_date [13541,13555]
===
match
---
comparison [9483,9510]
comparison [9483,9510]
===
match
---
name: strftime [4796,4804]
name: strftime [4796,4804]
===
match
---
string: 'task_id' [10814,10823]
string: 'task_id' [10790,10799]
===
match
---
name: context_set [11629,11640]
name: context_set [11605,11616]
===
match
---
operator: , [2737,2738]
operator: , [2737,2738]
===
match
---
if_stmt [9971,10279]
if_stmt [9971,10255]
===
match
---
simple_stmt [11972,11979]
simple_stmt [11948,11955]
===
match
---
operator: , [4281,4282]
operator: , [4281,4282]
===
match
---
operator: = [3682,3683]
operator: = [3682,3683]
===
match
---
name: execution_date [4298,4312]
name: execution_date [4298,4312]
===
match
---
string: 'last_log_timestamp' [7150,7170]
string: 'last_log_timestamp' [7150,7170]
===
match
---
name: TaskInstance [13007,13019]
name: TaskInstance [12983,12995]
===
match
---
simple_stmt [13663,13725]
simple_stmt [13639,13701]
===
match
---
suite [12159,12210]
suite [12135,12186]
===
match
---
atom_expr [10825,10840]
atom_expr [10801,10816]
===
match
---
operator: != [9987,9989]
operator: != [9987,9989]
===
match
---
operator: , [2564,2565]
operator: , [2564,2565]
===
match
---
string: 'last_log_timestamp' [7066,7086]
string: 'last_log_timestamp' [7066,7086]
===
match
---
name: log [10200,10203]
name: log [10195,10198]
===
match
---
expr_stmt [7112,7172]
expr_stmt [7112,7172]
===
match
---
name: execute [9699,9706]
name: execute [9699,9706]
===
match
---
atom_expr [6649,6656]
atom_expr [6649,6656]
===
match
---
comparison [6685,6737]
comparison [6685,6737]
===
match
---
import_from [1311,1374]
import_from [1311,1374]
===
match
---
name: next_offset [6091,6102]
name: next_offset [6091,6102]
===
match
---
expr_stmt [9762,9788]
expr_stmt [9762,9788]
===
match
---
name: log_id [8728,8734]
name: log_id [8728,8734]
===
match
---
atom [6635,6747]
atom [6635,6747]
===
match
---
name: self [8327,8331]
name: self [8327,8331]
===
match
---
trailer [3913,3927]
trailer [3913,3927]
===
match
---
name: int [3782,3785]
name: int [3782,3785]
===
match
---
name: log_id_template [3226,3241]
name: log_id_template [3226,3241]
===
match
---
param [8063,8071]
param [8063,8071]
===
match
---
operator: , [4978,4979]
operator: , [4978,4979]
===
match
---
name: self [4070,4074]
name: self [4070,4074]
===
match
---
trailer [6001,6027]
trailer [6001,6027]
===
match
---
atom_expr [13488,13508]
atom_expr [13464,13484]
===
match
---
name: join [7851,7855]
name: join [7851,7855]
===
match
---
suite [10353,11648]
suite [10329,11624]
===
match
---
operator: = [13632,13633]
operator: = [13608,13609]
===
match
---
operator: = [13709,13710]
operator: = [13685,13686]
===
match
---
dotted_name [1146,1167]
dotted_name [1146,1167]
===
match
---
funcdef [4852,5210]
funcdef [4852,5210]
===
match
---
name: end_of_log_mark [7787,7802]
name: end_of_log_mark [7787,7802]
===
match
---
operator: = [9958,9959]
operator: = [9958,9959]
===
match
---
name: filename_template [3165,3182]
name: filename_template [3165,3182]
===
match
---
trailer [10542,10554]
trailer [10518,10530]
===
match
---
not_test [11991,12017]
not_test [11967,11993]
===
match
---
operator: != [7441,7443]
operator: != [7441,7443]
===
match
---
name: handler [3674,3681]
name: handler [3674,3681]
===
match
---
operator: = [5140,5141]
operator: = [5140,5141]
===
match
---
trailer [10040,10101]
trailer [10040,10101]
===
match
---
name: metadata [6421,6429]
name: metadata [6421,6429]
===
match
---
name: int [7313,7316]
name: int [7313,7316]
===
match
---
atom_expr [10078,10100]
atom_expr [10078,10100]
===
match
---
operator: = [3568,3569]
operator: = [3568,3569]
===
match
---
name: json_fields [3637,3648]
name: json_fields [3637,3648]
===
match
---
name: self [11534,11538]
name: self [11510,11514]
===
match
---
trailer [13686,13695]
trailer [13662,13671]
===
match
---
trailer [11037,11048]
trailer [11013,11024]
===
match
---
name: self [11446,11450]
name: self [11422,11426]
===
match
---
trailer [10082,10100]
trailer [10082,10100]
===
match
---
trailer [4161,4176]
trailer [4161,4176]
===
match
---
number: 1000 [2429,2433]
number: 1000 [2429,2433]
===
match
---
simple_stmt [4774,4829]
simple_stmt [4774,4829]
===
match
---
name: search [9278,9284]
name: search [9278,9284]
===
match
---
expr_stmt [4891,4923]
expr_stmt [4891,4923]
===
match
---
trailer [9396,9433]
trailer [9396,9433]
===
match
---
trailer [13444,13460]
trailer [13420,13436]
===
match
---
import_from [902,942]
import_from [902,942]
===
match
---
name: try_number [13633,13643]
name: try_number [13609,13619]
===
match
---
simple_stmt [6756,6828]
simple_stmt [6756,6828]
===
match
---
string: 'max_offset' [7268,7280]
string: 'max_offset' [7268,7280]
===
match
---
operator: , [2626,2627]
operator: , [2626,2627]
===
match
---
name: metadata [7514,7522]
name: metadata [7514,7522]
===
match
---
trailer [10709,10721]
trailer [10685,10697]
===
match
---
name: dag_id [13481,13487]
name: dag_id [13457,13463]
===
match
---
name: str [2623,2626]
name: str [2623,2626]
===
match
---
simple_stmt [3669,3689]
simple_stmt [3669,3689]
===
match
---
simple_stmt [8011,8036]
simple_stmt [8011,8036]
===
match
---
atom_expr [7328,7355]
atom_expr [7328,7355]
===
match
---
name: setLevel [11459,11467]
name: setLevel [11435,11443]
===
match
---
name: MAX_LINE_PER_PAGE [10083,10100]
name: MAX_LINE_PER_PAGE [10083,10100]
===
match
---
trailer [11155,11168]
trailer [11131,11144]
===
match
---
sync_comp_for [7884,7909]
sync_comp_for [7884,7909]
===
match
---
simple_stmt [13054,13423]
simple_stmt [13030,13399]
===
match
---
simple_stmt [10568,11139]
simple_stmt [10544,11115]
===
match
---
trailer [12464,12471]
trailer [12440,12447]
===
match
---
name: conf [2855,2859]
name: conf [2855,2859]
===
match
---
name: ti [11035,11037]
name: ti [11011,11013]
===
match
---
trailer [7855,7911]
trailer [7855,7911]
===
match
---
name: utils [1388,1393]
name: utils [1388,1393]
===
match
---
string: 'max_offset' [9658,9670]
string: 'max_offset' [9658,9670]
===
match
---
trailer [3654,3659]
trailer [3654,3659]
===
match
---
atom_expr [9762,9784]
atom_expr [9762,9784]
===
match
---
atom_expr [3392,3405]
atom_expr [3392,3405]
===
match
---
trailer [10831,10839]
trailer [10807,10815]
===
match
---
trailer [3196,3203]
trailer [3196,3203]
===
match
---
dotted_name [948,960]
dotted_name [948,960]
===
match
---
name: self [3590,3594]
name: self [3590,3594]
===
match
---
simple_stmt [12740,12761]
simple_stmt [12716,12737]
===
match
---
operator: = [13529,13530]
operator: = [13505,13506]
===
match
---
simple_stmt [3463,3502]
simple_stmt [3463,3502]
===
match
---
parameters [8056,8072]
parameters [8056,8072]
===
match
---
decorator [12859,12869]
decorator [12835,12845]
===
match
---
trailer [9523,9540]
trailer [9523,9540]
===
match
---
dotted_name [1316,1351]
dotted_name [1316,1351]
===
match
---
operator: , [10925,10926]
operator: , [10901,10902]
===
match
---
name: json_format [10543,10554]
name: json_format [10519,10530]
===
match
---
trailer [4254,4261]
trailer [4254,4261]
===
match
---
argument [9406,9432]
argument [9406,9432]
===
match
---
name: log_id [9936,9942]
name: log_id [9936,9942]
===
match
---
operator: , [2711,2712]
operator: , [2711,2712]
===
match
---
name: diff [7213,7217]
name: diff [7213,7217]
===
match
---
expr_stmt [2409,2433]
expr_stmt [2409,2433]
===
match
---
name: item [6649,6653]
name: item [6649,6653]
===
match
---
operator: -> [5368,5370]
operator: -> [5368,5370]
===
match
---
trailer [4186,4188]
trailer [4186,4188]
===
match
---
name: log [1330,1333]
name: log [1330,1333]
===
match
---
import_from [1220,1254]
import_from [1220,1254]
===
match
---
return_stmt [5196,5209]
return_stmt [5196,5209]
===
match
---
simple_stmt [13733,13744]
simple_stmt [13709,13720]
===
match
---
name: metadata [6756,6764]
name: metadata [6756,6764]
===
match
---
arglist [5957,5971]
arglist [5957,5971]
===
match
---
operator: = [13487,13488]
operator: = [13463,13464]
===
match
---
argument [8497,8517]
argument [8497,8517]
===
match
---
name: getsection [2860,2870]
name: getsection [2860,2870]
===
match
---
suite [13045,13744]
suite [13021,13720]
===
match
---
trailer [9871,9875]
trailer [9871,9875]
===
match
---
sync_comp_for [6657,6737]
sync_comp_for [6657,6737]
===
match
---
name: str [12895,12898]
name: str [12871,12874]
===
match
---
expr_stmt [12172,12190]
expr_stmt [12148,12166]
===
match
---
import_from [1255,1310]
import_from [1255,1310]
===
match
---
string: 'offset' [11071,11079]
string: 'offset' [11047,11055]
===
match
---
trailer [11189,11201]
trailer [11165,11177]
===
match
---
trailer [7770,7778]
trailer [7770,7778]
===
match
---
simple_stmt [10288,10300]
simple_stmt [10264,10276]
===
match
---
name: _render_log_id [3731,3745]
name: _render_log_id [3731,3745]
===
match
---
if_stmt [10535,11139]
if_stmt [10511,11115]
===
match
---
import_from [850,879]
import_from [850,879]
===
match
---
dotted_name [1439,1470]
dotted_name [1439,1470]
===
match
---
trailer [11380,11394]
trailer [11356,11370]
===
match
---
trailer [13501,13508]
trailer [13477,13484]
===
match
---
trailer [5941,5956]
trailer [5941,5956]
===
match
---
atom_expr [6421,6439]
atom_expr [6421,6439]
===
match
---
name: try_number [10968,10978]
name: try_number [10944,10954]
===
match
---
return_stmt [3953,4010]
return_stmt [3953,4010]
===
match
---
trailer [3864,3885]
trailer [3864,3885]
===
match
---
name: kv [5160,5162]
name: kv [5160,5162]
===
match
---
name: utils [1233,1238]
name: utils [1233,1238]
===
match
---
name: ti [11031,11033]
name: ti [11007,11009]
===
match
---
trailer [9463,9469]
trailer [9463,9469]
===
match
---
name: metadata [7332,7340]
name: metadata [7332,7340]
===
match
---
simple_stmt [2409,2434]
simple_stmt [2409,2434]
===
match
---
trailer [9875,9885]
trailer [9875,9885]
===
match
---
simple_stmt [1255,1311]
simple_stmt [1255,1311]
===
match
---
name: host [7968,7972]
name: host [7968,7972]
===
match
---
name: helpers [1274,1281]
name: helpers [1274,1281]
===
match
---
name: JSONFormatter [10585,10598]
name: JSONFormatter [10561,10574]
===
match
---
operator: * [11092,11093]
operator: * [11068,11069]
===
match
---
name: Tuple [5371,5376]
name: Tuple [5371,5376]
===
match
---
for_stmt [14003,14069]
for_stmt [13979,14045]
===
match
---
expr_stmt [3192,3211]
expr_stmt [3192,3211]
===
match
---
name: filter [9390,9396]
name: filter [9390,9396]
===
match
---
operator: , [2775,2776]
operator: , [2775,2776]
===
match
---
simple_stmt [3131,3184]
simple_stmt [3131,3184]
===
match
---
name: int [13033,13036]
name: int [13009,13012]
===
match
---
trailer [6858,6860]
trailer [6858,6860]
===
match
---
name: try_number [3770,3780]
name: try_number [3770,3780]
===
match
---
atom_expr [9867,9943]
atom_expr [9867,9943]
===
match
---
trailer [7786,7802]
trailer [7786,7802]
===
match
---
not_test [10515,10525]
not_test [10491,10501]
===
match
---
atom_expr [3463,3483]
atom_expr [3463,3483]
===
match
---
trailer [4795,4804]
trailer [4795,4804]
===
match
---
atom_expr [4097,4114]
atom_expr [4097,4114]
===
match
---
operator: , [9333,9334]
operator: , [9333,9334]
===
match
---
atom_expr [6685,6705]
atom_expr [6685,6705]
===
match
---
name: write_stdout [12714,12726]
name: write_stdout [12690,12702]
===
match
---
string: "elasticsearch_configs" [2871,2894]
string: "elasticsearch_configs" [2871,2894]
===
match
---
operator: ** [8497,8499]
operator: ** [8497,8499]
===
match
---
name: datetime [871,879]
name: datetime [871,879]
===
match
---
tfpdef [2785,2798]
tfpdef [2785,2798]
===
match
---
string: """         Returns the logs matching log_id in Elasticsearch and next offset.         Returns '' if no log is found or there was an error.          :param log_id: the log_id of the log to read.         :type log_id: str         :param offset: the offset start to read log from.         :type offset: str         :param metadata: log metadata, used for steaming log download.         :type metadata: dict         """ [8787,9203]
string: """         Returns the logs matching log_id in Elasticsearch and next offset.         Returns '' if no log is found or there was an error.          :param log_id: the log_id of the log to read.         :type log_id: str         :param offset: the offset start to read log from.         :type offset: str         :param metadata: log metadata, used for steaming log download.         :type metadata: dict         """ [8787,9203]
===
match
---
operator: = [12847,12848]
operator: = [12823,12824]
===
match
---
atom_expr [10490,10512]
atom_expr [10466,10488]
===
match
---
name: self [5989,5993]
name: self [5989,5993]
===
match
---
tfpdef [4395,4419]
tfpdef [4395,4419]
===
match
---
simple_stmt [11358,11434]
simple_stmt [11334,11410]
===
match
---
name: end_of_log_mark [3486,3501]
name: end_of_log_mark [3486,3501]
===
match
---
operator: , [8025,8026]
operator: , [8025,8026]
===
match
---
name: TaskInstance [1207,1219]
name: TaskInstance [1207,1219]
===
match
---
operator: , [6008,6009]
operator: , [6008,6009]
===
match
---
name: LOG_NAME [12947,12955]
name: LOG_NAME [12923,12931]
===
match
---
simple_stmt [10362,10482]
simple_stmt [10338,10458]
===
match
---
trailer [3247,3269]
trailer [3247,3269]
===
match
---
atom_expr [3697,3713]
atom_expr [3697,3713]
===
match
---
comp_op [9558,9564]
comp_op [9558,9564]
===
match
---
trailer [11467,11479]
trailer [11443,11455]
===
match
---
param [4876,4880]
param [4876,4880]
===
match
---
name: log_id_jinja_template [3248,3269]
name: log_id_jinja_template [3248,3269]
===
match
---
trailer [8457,8464]
trailer [8457,8464]
===
match
---
name: urllib [948,954]
name: urllib [948,954]
===
match
---
atom_expr [10041,10063]
atom_expr [10041,10063]
===
match
---
simple_stmt [3425,3455]
simple_stmt [3425,3455]
===
match
---
name: log [4975,4978]
name: log [4975,4978]
===
match
---
operator: = [10032,10033]
operator: = [10032,10033]
===
match
---
operator: , [3768,3769]
operator: , [3768,3769]
===
match
---
string: 'message' [5170,5179]
string: 'message' [5170,5179]
===
match
---
trailer [7522,7544]
trailer [7522,7544]
===
match
---
trailer [4074,4096]
trailer [4074,4096]
===
match
---
trailer [3964,3986]
trailer [3964,3986]
===
match
---
decorator [4834,4848]
decorator [4834,4848]
===
match
---
atom_expr [12942,12955]
atom_expr [12918,12931]
===
match
---
comparison [12138,12158]
comparison [12114,12134]
===
match
---
simple_stmt [9374,9434]
simple_stmt [9374,9434]
===
match
---
name: JSONFormatter [1420,1433]
name: JSONFormatter [1420,1433]
===
match
---
testlist [8018,8035]
testlist [8018,8035]
===
match
---
simple_stmt [3221,3311]
simple_stmt [3221,3311]
===
match
---
name: task_instance [13530,13543]
name: task_instance [13506,13519]
===
match
---
param [3770,3785]
param [3770,3785]
===
match
---
decorated [12859,12956]
decorated [12835,12932]
===
match
---
trailer [9712,9719]
trailer [9712,9719]
===
match
---
name: grouped_logs [4891,4903]
name: grouped_logs [4891,4903]
===
match
---
operator: = [12184,12185]
operator: = [12160,12161]
===
match
---
trailer [11520,11533]
trailer [11496,11509]
===
match
---
operator: , [13643,13644]
operator: , [13619,13620]
===
match
---
trailer [10909,10924]
trailer [10885,10900]
===
match
---
name: json_format [2694,2705]
name: json_format [2694,2705]
===
match
---
suite [5244,5265]
suite [5244,5265]
===
match
---
subscript [10041,10100]
subscript [10041,10100]
===
match
---
atom_expr [10034,10111]
atom_expr [10034,10111]
===
match
---
trailer [3701,3713]
trailer [3701,3713]
===
match
---
comparison [7761,7810]
comparison [7761,7810]
===
match
---
atom_expr [3272,3310]
atom_expr [3272,3310]
===
match
---
operator: = [3406,3407]
operator: = [3406,3407]
===
match
---
name: end_of_log_mark [3468,3483]
name: end_of_log_mark [3468,3483]
===
match
---
if_stmt [5819,5883]
if_stmt [5819,5883]
===
match
---
name: execution_date [4283,4297]
name: execution_date [4283,4297]
===
match
---
simple_stmt [943,974]
simple_stmt [943,974]
===
match
---
simple_stmt [10195,10279]
simple_stmt [10190,10255]
===
match
---
name: execution_date [13594,13608]
name: execution_date [13570,13584]
===
match
---
name: TaskInstance [10331,10343]
name: TaskInstance [10307,10319]
===
match
---
param [10321,10326]
param [10297,10302]
===
match
---
name: self [11468,11472]
name: self [11444,11448]
===
match
---
name: self [13440,13444]
name: self [13416,13420]
===
match
---
trailer [10967,10978]
trailer [10943,10954]
===
match
---
param [2636,2657]
param [2636,2657]
===
match
---
trailer [12142,12150]
trailer [12118,12126]
===
match
---
trailer [11015,11030]
trailer [10991,11006]
===
match
---
trailer [7766,7770]
trailer [7766,7770]
===
match
---
name: self [3320,3324]
name: self [3320,3324]
===
match
---
parameters [5279,5367]
parameters [5279,5367]
===
match
---
name: self [10078,10082]
name: self [10078,10082]
===
match
---
atom_expr [4906,4923]
atom_expr [4906,4923]
===
match
---
trailer [8515,8517]
trailer [8515,8517]
===
match
---
name: base_log_folder [3148,3163]
name: base_log_folder [3148,3163]
===
match
---
operator: , [5179,5180]
operator: , [5179,5180]
===
match
---
name: metadata [8027,8035]
name: metadata [8027,8035]
===
match
---
trailer [9469,9471]
trailer [9469,9471]
===
match
---
name: _fmt [10635,10639]
name: _fmt [10611,10615]
===
match
---
trailer [12744,12752]
trailer [12720,12728]
===
match
---
if_stmt [3803,4011]
if_stmt [3803,4011]
===
match
---
atom_expr [10880,10925]
atom_expr [10856,10901]
===
match
---
param [8728,8740]
param [8728,8740]
===
match
---
operator: { [3120,3121]
operator: { [3120,3121]
===
match
---
name: log_id [10263,10269]
name: log_id [10247,10253]
===
match
---
or_test [7429,7500]
or_test [7429,7500]
===
match
---
trailer [14090,14097]
trailer [14066,14073]
===
match
---
trailer [2859,2870]
trailer [2859,2870]
===
match
---
param [8741,8753]
param [8741,8753]
===
match
---
name: jinja_context [3846,3859]
name: jinja_context [3846,3859]
===
match
---
trailer [5376,5396]
trailer [5376,5396]
===
match
---
simple_stmt [1434,1491]
simple_stmt [1434,1491]
===
match
---
operator: = [10583,10584]
operator: = [10559,10560]
===
match
---
name: count [9464,9469]
name: count [9464,9469]
===
match
---
expr_stmt [3463,3501]
expr_stmt [3463,3501]
===
match
---
name: str [3790,3793]
name: str [3790,3793]
===
match
---
import_from [1375,1433]
import_from [1375,1433]
===
match
---
factor [7767,7769]
factor [7767,7769]
===
match
---
operator: = [1537,1538]
operator: = [1537,1538]
===
match
---
expr_stmt [7387,7416]
expr_stmt [7387,7416]
===
match
---
param [8754,8768]
param [8754,8768]
===
match
---
operator: = [10619,10620]
operator: = [10595,10596]
===
match
---
name: metadata [5901,5909]
name: metadata [5901,5909]
===
match
---
operator: @ [4351,4352]
operator: @ [4351,4352]
===
match
---
trailer [6735,6737]
trailer [6735,6737]
===
match
---
atom_expr [7782,7810]
atom_expr [7782,7810]
===
match
---
simple_stmt [9953,9963]
simple_stmt [9953,9963]
===
match
---
atom_expr [10782,10791]
atom_expr [10758,10767]
===
match
---
name: self [3746,3750]
name: self [3746,3750]
===
match
---
atom_expr [4252,4261]
atom_expr [4252,4261]
===
match
---
trailer [7950,7962]
trailer [7950,7962]
===
match
---
name: self [3463,3467]
name: self [3463,3467]
===
match
---
simple_stmt [8082,8161]
simple_stmt [8082,8161]
===
match
---
atom_expr [6129,6144]
atom_expr [6129,6144]
===
match
---
name: self [3669,3673]
name: self [3669,3673]
===
match
---
operator: = [13579,13580]
operator: = [13555,13556]
===
match
---
name: log_id_template [4209,4224]
name: log_id_template [4209,4224]
===
match
---
name: log_id [9335,9341]
name: log_id [9335,9341]
===
match
---
trailer [8464,8519]
trailer [8464,8519]
===
match
---
trailer [5033,5040]
trailer [5033,5040]
===
match
---
name: using [9294,9299]
name: using [9294,9299]
===
match
---
name: typing [907,913]
name: typing [907,913]
===
match
---
simple_stmt [5892,5920]
simple_stmt [5892,5920]
===
match
---
operator: -> [8770,8772]
operator: -> [8770,8772]
===
match
---
trailer [12035,12042]
trailer [12011,12018]
===
match
---
trailer [11999,12017]
trailer [11975,11993]
===
match
---
atom [5797,5810]
atom [5797,5810]
===
match
---
suite [12727,12801]
suite [12703,12777]
===
match
---
simple_stmt [6036,6082]
simple_stmt [6036,6082]
===
match
---
name: self [3510,3514]
name: self [3510,3514]
===
match
---
operator: + [13680,13681]
operator: + [13656,13657]
===
match
---
operator: , [5293,5294]
operator: , [5293,5294]
===
match
---
simple_stmt [6421,6459]
simple_stmt [6421,6459]
===
match
---
factor [6690,6692]
factor [6690,6692]
===
match
---
name: getattr [5152,5159]
name: getattr [5152,5159]
===
match
---
name: configuration [1154,1167]
name: configuration [1154,1167]
===
match
---
trailer [3147,3183]
trailer [3147,3183]
===
match
---
operator: = [3484,3485]
operator: = [3484,3485]
===
match
---
simple_stmt [1141,1180]
simple_stmt [1141,1180]
===
match
---
import_name [788,802]
import_name [788,802]
===
match
---
operator: = [9341,9342]
operator: = [9341,9342]
===
match
---
trailer [7861,7873]
trailer [7861,7873]
===
match
---
operator: { [10746,10747]
operator: { [10722,10723]
===
match
---
atom_expr [10538,10554]
atom_expr [10514,10530]
===
match
---
name: offset [9424,9430]
name: offset [9424,9430]
===
match
---
operator: , [5135,5136]
operator: , [5135,5136]
===
match
---
operator: , [10979,10980]
operator: , [10955,10956]
===
match
---
operator: , [12990,12991]
operator: , [12966,12967]
===
match
---
name: key [5137,5140]
name: key [5137,5140]
===
match
---
operator: , [2534,2535]
operator: , [2534,2535]
===
match
---
expr_stmt [3669,3688]
expr_stmt [3669,3688]
===
match
---
factor [6134,6136]
factor [6134,6136]
===
match
---
trailer [10828,10840]
trailer [10804,10816]
===
match
---
operator: = [4297,4298]
operator: = [4297,4298]
===
match
---
argument [10616,10639]
argument [10592,10615]
===
match
---
name: self [3192,3196]
name: self [3192,3196]
===
match
---
param [5295,5312]
param [5295,5312]
===
match
---
atom_expr [11011,11049]
atom_expr [10987,11025]
===
match
---
operator: , [3368,3369]
operator: , [3368,3369]
===
match
---
return_stmt [5253,5264]
return_stmt [5253,5264]
===
match
---
name: defaultdict [838,849]
name: defaultdict [838,849]
===
match
---
argument [3994,4009]
argument [3994,4009]
===
match
---
name: dict [2847,2851]
name: dict [2847,2851]
===
match
---
name: self [10041,10045]
name: self [10041,10045]
===
match
---
trailer [7316,7324]
trailer [7316,7324]
===
match
---
trailer [10572,10582]
trailer [10548,10558]
===
match
---
operator: = [3928,3929]
operator: = [3928,3929]
===
match
---
name: cur_ts [7206,7212]
name: cur_ts [7206,7212]
===
match
---
number: 0 [5808,5809]
number: 0 [5808,5809]
===
match
---
operator: = [6049,6050]
operator: = [6049,6050]
===
match
---
return_stmt [8429,8519]
return_stmt [8429,8519]
===
match
---
name: self [6709,6713]
name: self [6709,6713]
===
match
---
name: lines [7874,7879]
name: lines [7874,7879]
===
match
---
suite [14028,14069]
suite [14004,14045]
===
match
---
operator: = [11401,11402]
operator: = [11377,11378]
===
match
---
arglist [3362,3381]
arglist [3362,3381]
===
match
---
name: logs [4943,4947]
name: logs [4943,4947]
===
match
---
name: json_fields [13965,13976]
name: json_fields [13941,13952]
===
match
---
operator: * [10064,10065]
operator: * [10064,10065]
===
match
---
dictorsetmaker [10768,11105]
dictorsetmaker [10744,11081]
===
match
---
simple_stmt [814,850]
simple_stmt [814,850]
===
match
---
tfpdef [2721,2737]
tfpdef [2721,2737]
===
match
---
if_stmt [12706,12801]
if_stmt [12682,12777]
===
match
---
atom_expr [11151,11168]
atom_expr [11127,11144]
===
match
---
param [2747,2776]
param [2747,2776]
===
match
---
name: closed [12432,12438]
name: closed [12408,12414]
===
match
---
suite [11579,11616]
suite [11555,11592]
===
match
---
suite [1625,13744]
suite [1625,13720]
===
match
---
import_name [1087,1102]
import_name [1087,1102]
===
match
---
operator: , [3163,3164]
operator: , [3163,3164]
===
match
---
name: fmt [10616,10619]
name: fmt [10592,10595]
===
match
---
name: try_number [5961,5971]
name: try_number [5961,5971]
===
match
---
trailer [6133,6137]
trailer [6133,6137]
===
match
---
trailer [8450,8457]
trailer [8450,8457]
===
match
---
suite [10555,11139]
suite [10531,11115]
===
match
---
name: try_number [4325,4335]
name: try_number [4325,4335]
===
match
---
name: ti [11612,11614]
name: ti [11588,11590]
===
match
---
trailer [12823,12825]
trailer [12799,12801]
===
match
---
name: metadata [5764,5772]
name: metadata [5764,5772]
===
match
---
name: metadata [5838,5846]
name: metadata [5838,5846]
===
match
---
arglist [8479,8517]
arglist [8479,8517]
===
match
---
name: formatter [11539,11548]
name: formatter [11515,11524]
===
match
---
atom_expr [3669,3681]
atom_expr [3669,3681]
===
match
---
name: datetime [855,863]
name: datetime [855,863]
===
match
---
operator: -> [4421,4423]
operator: -> [4421,4423]
===
match
---
name: quote [968,973]
name: quote [968,973]
===
match
---
name: list [8773,8777]
name: list [8773,8777]
===
match
---
atom_expr [11085,11091]
atom_expr [11061,11067]
===
match
---
atom_expr [10519,10525]
atom_expr [10495,10501]
===
match
---
name: ti [10327,10329]
name: ti [10303,10305]
===
match
---
simple_stmt [11338,11345]
simple_stmt [11314,11321]
===
match
---
try_stmt [9587,9944]
try_stmt [9587,9944]
===
match
---
param [2785,2818]
param [2785,2818]
===
match
---
operator: ** [3370,3372]
operator: ** [3370,3372]
===
match
---
name: log [1394,1397]
name: log [1394,1397]
===
match
---
param [3746,3751]
param [3746,3751]
===
match
---
name: self [12835,12839]
name: self [12811,12815]
===
match
---
trailer [6713,6729]
trailer [6713,6729]
===
match
---
param [5148,5150]
param [5148,5150]
===
match
---
argument [10739,11123]
argument [10715,11099]
===
match
---
name: write_stdout [3515,3527]
name: write_stdout [3515,3527]
===
match
---
atom_expr [12474,12494]
atom_expr [12450,12470]
===
match
---
atom_expr [3425,3447]
atom_expr [3425,3447]
===
match
---
return_stmt [12935,12955]
return_stmt [12911,12931]
===
match
---
tfpdef [13021,13036]
tfpdef [12997,13012]
===
match
---
operator: , [5389,5390]
operator: , [5389,5390]
===
match
---
string: 'last_log_timestamp' [7523,7543]
string: 'last_log_timestamp' [7523,7543]
===
match
---
operator: , [5168,5169]
operator: , [5168,5169]
===
match
---
name: result [5203,5209]
name: result [5203,5209]
===
match
---
tfpdef [12992,13019]
tfpdef [12968,12995]
===
match
---
and_test [9483,9573]
and_test [9483,9573]
===
match
---
trailer [3555,3567]
trailer [3555,3567]
===
match
---
trailer [10634,10639]
trailer [10610,10615]
===
match
---
name: in_minutes [7231,7241]
name: in_minutes [7231,7241]
===
match
---
name: EsLogMsgType [1524,1536]
name: EsLogMsgType [1524,1536]
===
match
---
name: execution_date [4142,4156]
name: execution_date [4142,4156]
===
match
---
tfpdef [2636,2656]
tfpdef [2636,2656]
===
match
---
name: collections [819,830]
name: collections [819,830]
===
match
---
trailer [12752,12758]
trailer [12728,12734]
===
match
---
trailer [3993,4010]
trailer [3993,4010]
===
match
---
trailer [11405,11416]
trailer [11381,11392]
===
match
---
name: key [5029,5032]
name: key [5029,5032]
===
match
---
string: 'end_of_log' [6765,6777]
string: 'end_of_log' [6765,6777]
===
match
---
string: "localhost:9200" [2759,2775]
string: "localhost:9200" [2759,2775]
===
match
---
trailer [7745,7752]
trailer [7745,7752]
===
match
---
name: client [9305,9311]
name: client [9305,9311]
===
match
---
trailer [7241,7243]
trailer [7241,7243]
===
match
---
name: logs [10027,10031]
name: logs [10027,10031]
===
match
---
atom_expr [12031,12042]
atom_expr [12007,12018]
===
match
---
operator: - [9694,9695]
operator: - [9694,9695]
===
match
---
not_test [5760,5772]
not_test [5760,5772]
===
match
---
operator: = [4251,4252]
operator: = [4251,4252]
===
match
---
simple_stmt [880,902]
simple_stmt [880,902]
===
match
---
testlist_comp [3610,3659]
testlist_comp [3610,3659]
===
match
---
atom [7741,7757]
atom [7741,7757]
===
match
---
simple_stmt [6837,6861]
simple_stmt [6837,6861]
===
match
---
tfpdef [2574,2596]
tfpdef [2574,2596]
===
match
---
atom_expr [13440,13654]
atom_expr [13416,13630]
===
match
---
name: next_offset [6446,6457]
name: next_offset [6446,6457]
===
match
---
name: dict [5391,5395]
name: dict [5391,5395]
===
match
---
operator: = [2757,2758]
operator: = [2757,2758]
===
match
---
argument [9294,9311]
argument [9294,9311]
===
match
---
if_stmt [5757,5811]
if_stmt [5757,5811]
===
match
---
simple_stmt [5196,5210]
simple_stmt [5196,5210]
===
match
---
trailer [12393,12400]
trailer [12369,12376]
===
match
---
operator: , [14063,14064]
operator: , [14039,14040]
===
match
---
expr_stmt [7921,8001]
expr_stmt [7921,8001]
===
match
---
operator: , [5328,5329]
operator: , [5328,5329]
===
match
---
name: max_log_line [9611,9623]
name: max_log_line [9611,9623]
===
match
---
funcdef [7693,7912]
funcdef [7693,7912]
===
match
---
simple_stmt [902,943]
simple_stmt [902,943]
===
match
---
trailer [10101,10109]
trailer [10101,10109]
===
match
---
expr_stmt [13663,13724]
expr_stmt [13639,13700]
===
match
---
tfpdef [2747,2756]
tfpdef [2747,2756]
===
match
---
operator: = [9455,9456]
operator: = [9455,9456]
===
match
---
name: metadata [8754,8762]
name: metadata [8754,8762]
===
match
---
atom_expr [9420,9431]
atom_expr [9420,9431]
===
match
---
trailer [12758,12760]
trailer [12734,12736]
===
match
---
name: utils [1324,1329]
name: utils [1324,1329]
===
match
---
param [4395,4419]
param [4395,4419]
===
match
---
operator: = [10513,10514]
operator: = [10489,10490]
===
match
---
string: '\n' [7846,7850]
string: '\n' [7846,7850]
===
match
---
operator: -> [12892,12894]
operator: -> [12868,12870]
===
match
---
name: set_context [11600,11611]
name: set_context [11576,11587]
===
match
---
atom_expr [11402,11416]
atom_expr [11378,11392]
===
match
---
atom_expr [5016,5045]
atom_expr [5016,5045]
===
match
---
atom_expr [7429,7440]
atom_expr [7429,7440]
===
match
---
trailer [14097,14105]
trailer [14073,14081]
===
match
---
operator: = [11371,11372]
operator: = [11347,11348]
===
match
---
name: __stdout__ [12790,12800]
name: __stdout__ [12766,12776]
===
match
---
name: last_log_ts [7218,7229]
name: last_log_ts [7218,7229]
===
match
---
atom [3362,3368]
atom [3362,3368]
===
match
---
atom_expr [3510,3527]
atom_expr [3510,3527]
===
match
---
trailer [9423,9431]
trailer [9423,9431]
===
match
---
testlist_star_expr [3221,3269]
testlist_star_expr [3221,3269]
===
match
---
name: self [3806,3810]
name: self [3806,3810]
===
match
---
operator: = [4068,4069]
operator: = [4068,4069]
===
match
---
simple_stmt [8681,8705]
simple_stmt [8681,8705]
===
match
---
name: execution_date [4100,4114]
name: execution_date [4100,4114]
===
match
---
name: dict [5349,5353]
name: dict [5349,5353]
===
match
---
name: frontend [3408,3416]
name: frontend [3408,3416]
===
match
---
return_stmt [7839,7911]
return_stmt [7839,7911]
===
match
---
atom [7188,7369]
atom [7188,7369]
===
match
---
operator: , [8495,8496]
operator: , [8495,8496]
===
match
---
suite [2903,3722]
suite [2903,3722]
===
match
---
param [8057,8062]
param [8057,8062]
===
match
---
operator: == [7779,7781]
operator: == [7779,7781]
===
match
---
atom_expr [6804,6822]
atom_expr [6804,6822]
===
match
---
if_stmt [7185,7417]
if_stmt [7185,7417]
===
match
---
operator: = [3714,3715]
operator: = [3714,3715]
===
match
---
name: offset [7433,7439]
name: offset [7433,7439]
===
match
---
name: str [7547,7550]
name: str [7547,7550]
===
match
---
name: self [13682,13686]
name: self [13658,13662]
===
match
---
name: max_log_line [9681,9693]
name: max_log_line [9681,9693]
===
match
---
dotted_name [1260,1281]
dotted_name [1260,1281]
===
match
---
expr_stmt [3095,3122]
expr_stmt [3095,3122]
===
match
---
testlist_comp [7932,8000]
testlist_comp [7932,8000]
===
match
---
trailer [10494,10512]
trailer [10470,10488]
===
match
---
name: self [2530,2534]
name: self [2530,2534]
===
match
---
name: log [9872,9875]
name: log [9872,9875]
===
match
---
name: logs [6129,6133]
name: logs [6129,6133]
===
match
---
arglist [13481,13644]
arglist [13457,13620]
===
match
---
name: raw [10522,10525]
name: raw [10498,10501]
===
match
---
trailer [4099,4114]
trailer [4099,4114]
===
match
---
argument [9335,9348]
argument [9335,9348]
===
match
---
trailer [12679,12695]
trailer [12655,12671]
===
match
---
name: frontend [2785,2793]
name: frontend [2785,2793]
===
match
---
trailer [9389,9396]
trailer [9389,9396]
===
match
---
funcdef [2470,3722]
funcdef [2470,3722]
===
match
---
name: str [8736,8739]
name: str [8736,8739]
===
match
---
operator: == [6823,6825]
operator: == [6823,6825]
===
match
---
try_stmt [10005,10279]
try_stmt [10005,10255]
===
match
---
name: log_id_template [2606,2621]
name: log_id_template [2606,2621]
===
match
---
atom_expr [5901,5919]
atom_expr [5901,5919]
===
match
---
operator: = [4270,4271]
operator: = [4270,4271]
===
match
---
name: sys [12773,12776]
name: sys [12749,12752]
===
match
---
name: offset [6010,6016]
name: offset [6010,6016]
===
match
---
arglist [5160,5184]
arglist [5160,5184]
===
match
---
expr_stmt [9374,9433]
expr_stmt [9374,9433]
===
match
---
name: mark_end_on_close [3430,3447]
name: mark_end_on_close [3430,3447]
===
match
---
atom_expr [3320,3331]
atom_expr [3320,3331]
===
match
---
name: log_id_template [13445,13460]
name: log_id_template [13421,13436]
===
match
---
string: 'max_offset' [9545,9557]
string: 'max_offset' [9545,9557]
===
match
---
simple_stmt [4891,4924]
simple_stmt [4891,4924]
===
match
---
operator: ** [3994,3996]
operator: ** [3994,3996]
===
match
---
name: str [1555,1558]
name: str [1555,1558]
===
match
---
name: elasticsearch_dsl [1108,1125]
name: elasticsearch_dsl [1108,1125]
===
match
---
arglist [4245,4335]
arglist [4245,4335]
===
match
---
trailer [6075,6081]
trailer [6075,6081]
===
match
---
operator: = [4965,4966]
operator: = [4965,4966]
===
match
---
dotted_name [1225,1238]
dotted_name [1225,1238]
===
match
---
trailer [11951,11958]
trailer [11927,11934]
===
match
---
if_stmt [11148,11616]
if_stmt [11124,11592]
===
match
---
suite [9574,9944]
suite [9574,9944]
===
match
---
argument [13522,13551]
argument [13498,13527]
===
match
---
name: Exception [8539,8548]
name: Exception [8539,8548]
===
match
---
number: 9 [11101,11102]
number: 9 [11077,11078]
===
match
---
if_stmt [9608,9789]
if_stmt [9608,9789]
===
match
---
trailer [10521,10525]
trailer [10497,10501]
===
match
---
atom_expr [6442,6458]
atom_expr [6442,6458]
===
match
---
name: self [8722,8726]
name: self [8722,8726]
===
match
---
atom_expr [3243,3269]
atom_expr [3243,3269]
===
match
---
expr_stmt [9278,9364]
expr_stmt [9278,9364]
===
match
---
number: 1 [9696,9697]
number: 1 [9696,9697]
===
match
---
name: log_id_jinja_template [3811,3832]
name: log_id_jinja_template [3811,3832]
===
match
---
atom [11094,11103]
atom [11070,11079]
===
match
---
name: models [1193,1199]
name: models [1193,1199]
===
match
---
name: range [7893,7898]
name: range [7893,7898]
===
match
---
name: try_number [4314,4324]
name: try_number [4314,4324]
===
match
---
name: closed [3197,3203]
name: closed [3197,3203]
===
match
---
simple_stmt [11624,11648]
simple_stmt [11600,11624]
===
match
---
tfpdef [10327,10343]
tfpdef [10303,10319]
===
match
---
name: List [921,925]
name: List [921,925]
===
match
---
return_stmt [10288,10299]
return_stmt [10264,10275]
===
match
---
atom_expr [13682,13724]
atom_expr [13658,13700]
===
match
---
string: 'offset' [5822,5830]
string: 'offset' [5822,5830]
===
match
---
name: timezone [1246,1254]
name: timezone [1246,1254]
===
match
---
trailer [11394,11417]
trailer [11370,11393]
===
match
---
name: logs [6119,6123]
name: logs [6119,6123]
===
match
---
name: max_log_line [9442,9454]
name: max_log_line [9442,9454]
===
match
---
param [10327,10343]
param [10303,10319]
===
match
---
name: time [11085,11089]
name: time [11061,11065]
===
match
---
name: __init__ [2474,2482]
name: __init__ [2474,2482]
===
match
---
suite [3794,4346]
suite [3794,4346]
===
match
---
expr_stmt [3221,3310]
expr_stmt [3221,3310]
===
match
---
trailer [4176,4186]
trailer [4176,4186]
===
match
---
trailer [9657,9671]
trailer [9657,9671]
===
match
---
simple_stmt [9762,9789]
simple_stmt [9762,9789]
===
match
---
operator: , [6016,6017]
operator: , [6016,6017]
===
match
---
funcdef [13946,14106]
funcdef [13922,14082]
===
match
---
name: LoggingMixin [1478,1490]
name: LoggingMixin [1478,1490]
===
match
---
atom_expr [9515,9540]
atom_expr [9515,9540]
===
match
---
operator: = [3270,3271]
operator: = [3270,3271]
===
match
---
name: str [6442,6445]
name: str [6442,6445]
===
match
---
atom_expr [12138,12150]
atom_expr [12114,12126]
===
match
---
name: ti [3862,3864]
name: ti [3862,3864]
===
match
---
trailer [12776,12783]
trailer [12752,12759]
===
match
---
param [11663,11667]
param [11639,11643]
===
match
---
suite [11959,11979]
suite [11935,11955]
===
match
---
name: _render_log_id [11016,11030]
name: _render_log_id [10992,11006]
===
match
---
operator: = [6633,6634]
operator: = [6633,6634]
===
match
---
operator: , [11123,11124]
operator: , [11099,11100]
===
match
---
simple_stmt [3320,3383]
simple_stmt [3320,3383]
===
match
---
atom_expr [7761,7778]
atom_expr [7761,7778]
===
match
---
atom_expr [10965,10978]
atom_expr [10941,10954]
===
match
---
name: int [9420,9423]
name: int [9420,9423]
===
match
---
tfpdef [8754,8768]
tfpdef [8754,8768]
===
match
---
name: self [14041,14045]
name: self [14017,14021]
===
match
---
expr_stmt [5099,5186]
expr_stmt [5099,5186]
===
match
---
name: timezone [7126,7134]
name: timezone [7126,7134]
===
match
---
import_from [943,973]
import_from [943,973]
===
match
---
suite [9741,9789]
suite [9741,9789]
===
match
---
string: 'offset' [9355,9363]
string: 'offset' [9355,9363]
===
match
---
operator: , [925,926]
operator: , [925,926]
===
match
---
name: stream [12465,12471]
name: stream [12441,12447]
===
match
---
name: self [11508,11512]
name: self [11484,11488]
===
match
---
name: airflow [1185,1192]
name: airflow [1185,1192]
===
match
---
tfpdef [2666,2684]
tfpdef [2666,2684]
===
match
---
name: self [11624,11628]
name: self [11600,11604]
===
match
---
atom_expr [5860,5878]
atom_expr [5860,5878]
===
match
---
operator: , [8061,8062]
operator: , [8061,8062]
===
match
---
name: logs [10295,10299]
name: logs [10271,10275]
===
match
---
suite [10178,10279]
suite [10173,10255]
===
match
---
suite [8344,8608]
suite [8344,8608]
===
match
---
string: """         Clean up an execution date so that it is safe to query in elasticsearch         by removing reserved characters.         # https://www.elastic.co/guide/en/elasticsearch/reference/current/query-dsl-query-string-query.html#_reserved_characters          :param execution_date: execution date of the dag run.         """ [4437,4765]
string: """         Clean up an execution date so that it is safe to query in elasticsearch         by removing reserved characters.         # https://www.elastic.co/guide/en/elasticsearch/reference/current/query-dsl-query-string-query.html#_reserved_characters          :param execution_date: execution date of the dag run.         """ [4437,4765]
===
match
---
name: self [11185,11189]
name: self [11161,11165]
===
match
---
name: strip [3616,3621]
name: strip [3616,3621]
===
match
---
atom_expr [7742,7752]
atom_expr [7742,7752]
===
match
---
funcdef [5215,5265]
funcdef [5215,5265]
===
match
---
trailer [7873,7883]
trailer [7873,7883]
===
match
---
atom_expr [6756,6778]
atom_expr [6756,6778]
===
match
---
name: int [5325,5328]
name: int [5325,5328]
===
match
---
suite [8361,8520]
suite [8361,8520]
===
match
---
name: self [12675,12679]
name: self [12651,12655]
===
match
---
atom_expr [8465,8518]
atom_expr [8465,8518]
===
match
---
name: metadata [7492,7500]
name: metadata [7492,7500]
===
match
---
name: write [12669,12674]
name: write [12645,12650]
===
match
---
name: task_instance [13580,13593]
name: task_instance [13556,13569]
===
match
---
atom_expr [12810,12825]
atom_expr [12786,12801]
===
match
---
operator: , [13551,13552]
operator: , [13527,13528]
===
match
---
name: es_kwargs [2827,2836]
name: es_kwargs [2827,2836]
===
match
---
simple_stmt [2438,2465]
simple_stmt [2438,2465]
===
match
---
operator: , [13019,13020]
operator: , [12995,12996]
===
match
---
atom_expr [12773,12783]
atom_expr [12749,12759]
===
match
---
name: last_log_ts [7112,7123]
name: last_log_ts [7112,7123]
===
match
---
argument [5137,5185]
argument [5137,5185]
===
match
---
expr_stmt [4053,4115]
expr_stmt [4053,4115]
===
match
---
name: time [897,901]
name: time [897,901]
===
match
---
atom_expr [7874,7882]
atom_expr [7874,7882]
===
match
---
atom_expr [9674,9719]
atom_expr [9674,9719]
===
match
---
name: self [12942,12946]
name: self [12918,12922]
===
match
---
name: concat_logs [7697,7708]
name: concat_logs [7697,7708]
===
match
---
name: log [4936,4939]
name: log [4936,4939]
===
match
---
param [2827,2896]
param [2827,2896]
===
match
---
trailer [11458,11467]
trailer [11434,11443]
===
match
---
trailer [9680,9698]
trailer [9680,9698]
===
match
---
expr_stmt [10568,11138]
expr_stmt [10544,11114]
===
match
---
trailer [7898,7909]
trailer [7898,7909]
===
match
---
trailer [7447,7460]
trailer [7447,7460]
===
match
---
operator: = [10745,10746]
operator: = [10721,10722]
===
match
---
name: log_name [12877,12885]
name: log_name [12853,12861]
===
match
---
operator: - [6134,6135]
operator: - [6134,6135]
===
match
---
name: field [14058,14063]
name: field [14034,14039]
===
match
---
dictorsetmaker [5798,5809]
dictorsetmaker [5798,5809]
===
match
---
operator: = [2427,2428]
operator: = [2427,2428]
===
match
---
atom_expr [11035,11048]
atom_expr [11011,11024]
===
match
---
name: self [12474,12478]
name: self [12450,12454]
===
match
---
trailer [6729,6735]
trailer [6729,6735]
===
match
---
simple_stmt [8429,8520]
simple_stmt [8429,8520]
===
match
---
name: execution_date [4395,4409]
name: execution_date [4395,4409]
===
match
---
operator: { [5797,5798]
operator: { [5797,5798]
===
match
---
atom_expr [6709,6737]
atom_expr [6709,6737]
===
match
---
name: log_id [5928,5934]
name: log_id [5928,5934]
===
match
---
operator: - [9709,9710]
operator: - [9709,9710]
===
match
---
trailer [12424,12431]
trailer [12400,12407]
===
match
---
simple_stmt [11592,11616]
simple_stmt [11568,11592]
===
match
---
trailer [10964,10979]
trailer [10940,10955]
===
match
---
name: str [2561,2564]
name: str [2561,2564]
===
match
---
trailer [10784,10791]
trailer [10760,10767]
===
match
---
name: metadata [5860,5868]
name: metadata [5860,5868]
===
match
---
arglist [10616,11124]
arglist [10592,11100]
===
match
---
operator: = [13667,13668]
operator: = [13643,13644]
===
match
---
operator: , [7972,7973]
operator: , [7972,7973]
===
match
---
operator: = [5106,5107]
operator: = [5106,5107]
===
match
---
name: write_stdout [2666,2678]
name: write_stdout [2666,2678]
===
match
---
trailer [9708,9712]
trailer [9708,9712]
===
match
---
atom_expr [4070,4115]
atom_expr [4070,4115]
===
match
---
simple_stmt [3510,3543]
simple_stmt [3510,3543]
===
match
---
trailer [7331,7355]
trailer [7331,7355]
===
match
---
suite [8073,8705]
suite [8073,8705]
===
match
---
param [12986,12991]
param [12962,12967]
===
match
---
atom_expr [7387,7409]
atom_expr [7387,7409]
===
match
---
argument [10693,10721]
argument [10669,10697]
===
match
---
name: try_number [13021,13031]
name: try_number [12997,13007]
===
match
---
trailer [10045,10063]
trailer [10045,10063]
===
match
---
atom_expr [7547,7558]
atom_expr [7547,7558]
===
match
---
trailer [3361,3382]
trailer [3361,3382]
===
match
---
param [12992,13020]
param [12968,12996]
===
match
---
name: message [8018,8025]
name: message [8018,8025]
===
match
---
trailer [6055,6075]
trailer [6055,6075]
===
match
---
name: airflow [1439,1446]
name: airflow [1439,1446]
===
match
---
name: self [12031,12035]
name: self [12007,12011]
===
match
---
name: metadata [7387,7395]
name: metadata [7387,7395]
===
match
---
atom_expr [14077,14105]
atom_expr [14053,14081]
===
match
---
operator: , [8726,8727]
operator: , [8726,8727]
===
match
---
atom_expr [12709,12726]
atom_expr [12685,12702]
===
match
---
operator: = [7124,7125]
operator: = [7124,7125]
===
match
---
number: 5 [7247,7248]
number: 5 [7247,7248]
===
match
---
atom_expr [10585,11138]
atom_expr [10561,11114]
===
match
---
name: task_instance [12992,13005]
name: task_instance [12968,12981]
===
match
---
name: dag_id [4255,4261]
name: dag_id [4255,4261]
===
match
---
name: self [3425,3429]
name: self [3425,3429]
===
match
---
name: host [2747,2751]
name: host [2747,2751]
===
match
---
string: 'last_log_timestamp' [7464,7484]
string: 'last_log_timestamp' [7464,7484]
===
match
---
name: logs [6794,6798]
name: logs [6794,6798]
===
match
---
term [10041,10075]
term [10041,10075]
===
match
---
name: self [10620,10624]
name: self [10596,10600]
===
match
---
trailer [3396,3405]
trailer [3396,3405]
===
match
---
simple_stmt [2396,2405]
simple_stmt [2396,2405]
===
match
---
atom_expr [10195,10278]
atom_expr [10190,10254]
===
match
---
name: query [9313,9318]
name: query [9313,9318]
===
match
---
name: logs [6076,6080]
name: logs [6076,6080]
===
match
---
atom_expr [8499,8517]
atom_expr [8499,8517]
===
match
---
simple_stmt [11446,11496]
simple_stmt [11422,11472]
===
match
---
simple_stmt [1066,1087]
simple_stmt [1066,1087]
===
match
---
name: log_id [13716,13722]
name: log_id [13692,13698]
===
match
---
expr_stmt [12835,12853]
expr_stmt [12811,12829]
===
match
---
name: task_id [4274,4281]
name: task_id [4274,4281]
===
match
---
number: 0 [9626,9627]
number: 0 [9626,9627]
===
match
---
trailer [4208,4224]
trailer [4208,4224]
===
match
---
name: self [12138,12142]
name: self [12114,12118]
===
match
---
number: 1 [6691,6692]
number: 1 [6691,6692]
===
match
---
name: json_format [4028,4039]
name: json_format [4028,4039]
===
match
---
simple_stmt [12935,12956]
simple_stmt [12911,12932]
===
match
---
argument [3370,3381]
argument [3370,3381]
===
match
---
name: metadata [9502,9510]
name: metadata [9502,9510]
===
match
---
name: self [10880,10884]
name: self [10856,10860]
===
match
---
name: str [10778,10781]
name: str [10754,10757]
===
match
---
atom_expr [7332,7354]
atom_expr [7332,7354]
===
match
---
name: handler [12745,12752]
name: handler [12721,12728]
===
match
---
trailer [11030,11049]
trailer [11006,11025]
===
match
---
simple_stmt [4197,4346]
simple_stmt [4197,4346]
===
match
---
name: pendulum [6846,6854]
name: pendulum [6846,6854]
===
match
---
term [11085,11103]
term [11061,11079]
===
match
---
operator: } [9431,9432]
operator: } [9431,9432]
===
match
---
arglist [11031,11048]
arglist [11007,11024]
===
match
---
name: setFormatter [11521,11533]
name: setFormatter [11497,11509]
===
match
---
name: jinja_context [3996,4009]
name: jinja_context [3996,4009]
===
match
---
operator: -> [11669,11671]
operator: -> [11645,11647]
===
match
---
name: TaskInstance [5299,5311]
name: TaskInstance [5299,5311]
===
match
---
simple_stmt [850,880]
simple_stmt [850,880]
===
match
---
suite [8778,10300]
suite [8778,10276]
===
match
---
atom_expr [3221,3241]
atom_expr [3221,3241]
===
match
---
atom_expr [10829,10839]
atom_expr [10805,10815]
===
match
---
name: hosted_log [7974,7984]
name: hosted_log [7974,7984]
===
match
---
expr_stmt [6837,6860]
expr_stmt [6837,6860]
===
match
---
name: ti [10519,10521]
name: ti [10495,10497]
===
match
---
operator: , [10721,10722]
operator: , [10697,10698]
===
match
---
name: len [7742,7745]
name: len [7742,7745]
===
match
---
operator: = [9672,9673]
operator: = [9672,9673]
===
match
---
operator: = [3448,3449]
operator: = [3448,3449]
===
match
---
trailer [3615,3621]
trailer [3615,3621]
===
match
---
param [12886,12890]
param [12862,12866]
===
match
---
atom_expr [8479,8495]
atom_expr [8479,8495]
===
match
---
simple_stmt [3392,3417]
simple_stmt [3392,3417]
===
match
---
name: closed [11952,11958]
name: closed [11928,11934]
===
match
---
name: logs_by_host [6669,6681]
name: logs_by_host [6669,6681]
===
match
---
operator: = [9785,9786]
operator: = [9785,9786]
===
match
---
trailer [12817,12823]
trailer [12793,12799]
===
match
---
atom_expr [11185,11201]
atom_expr [11161,11177]
===
match
---
simple_stmt [6619,6748]
simple_stmt [6619,6748]
===
match
---
name: ti [4252,4254]
name: ti [4252,4254]
===
match
---
name: lines [7746,7751]
name: lines [7746,7751]
===
match
---
name: i [7888,7889]
name: i [7888,7889]
===
match
---
simple_stmt [13771,13852]
simple_stmt [13747,13828]
===
match
---
string: 'offset' [6430,6438]
string: 'offset' [6430,6438]
===
match
---
name: execution_date [4053,4067]
name: execution_date [4053,4067]
===
match
---
comp_op [7485,7491]
comp_op [7485,7491]
===
match
---
name: self [7782,7786]
name: self [7782,7786]
===
match
---
for_stmt [4932,5046]
for_stmt [4932,5046]
===
match
---
name: stream [12662,12668]
name: stream [12638,12644]
===
match
---
operator: = [7545,7546]
operator: = [7545,7546]
===
match
---
arith_expr [7742,7756]
arith_expr [7742,7756]
===
match
---
name: handler [12417,12424]
name: handler [12393,12400]
===
match
---
operator: , [4261,4262]
operator: , [4261,4262]
===
match
---
operator: , [8752,8753]
operator: , [8752,8753]
===
match
---
name: MAX_LINE_PER_PAGE [10046,10063]
name: MAX_LINE_PER_PAGE [10046,10063]
===
match
---
suite [4428,4829]
suite [4428,4829]
===
match
---
argument [13703,13723]
argument [13679,13699]
===
match
---
name: self [12986,12990]
name: self [12962,12966]
===
match
---
atom_expr [10620,10639]
atom_expr [10596,10615]
===
match
---
name: self [11947,11951]
name: self [11923,11927]
===
match
---
if_stmt [11988,12069]
if_stmt [11964,12045]
===
match
---
number: 1 [6135,6136]
number: 1 [6135,6136]
===
match
---
simple_stmt [12908,12927]
simple_stmt [12884,12903]
===
match
---
trailer [3225,3241]
trailer [3225,3241]
===
match
---
suite [13994,14106]
suite [13970,14082]
===
match
---
suite [11169,11566]
suite [11145,11542]
===
match
---
name: ti [4271,4273]
name: ti [4271,4273]
===
match
---
name: sorted [5108,5114]
name: sorted [5108,5114]
===
match
---
not_test [6115,6123]
not_test [6115,6123]
===
match
---
name: len [7816,7819]
name: len [7816,7819]
===
match
---
param [8722,8727]
param [8722,8727]
===
match
---
operator: = [7739,7740]
operator: = [7739,7740]
===
match
---
operator: , [13982,13983]
operator: , [13958,13959]
===
match
---
number: 0 [9990,9991]
number: 0 [9990,9991]
===
match
---
name: end_of_log_mark [6714,6729]
name: end_of_log_mark [6714,6729]
===
match
---
param [3752,3769]
param [3752,3769]
===
match
---
string: 'default_host' [4988,5002]
string: 'default_host' [4988,5002]
===
match
---
name: self [11151,11155]
name: self [11127,11131]
===
match
---
name: self [8436,8440]
name: self [8436,8440]
===
match
---
name: StreamHandler [11381,11394]
name: StreamHandler [11357,11370]
===
match
---
operator: , [2817,2818]
operator: , [2817,2818]
===
match
---
atom [3120,3122]
atom [3120,3122]
===
match
---
expr_stmt [3510,3542]
expr_stmt [3510,3542]
===
match
---
atom_expr [6051,6081]
atom_expr [6051,6081]
===
match
---
operator: { [9413,9414]
operator: { [9413,9414]
===
match
---
atom_expr [10705,10721]
atom_expr [10681,10697]
===
match
---
simple_stmt [7839,7912]
simple_stmt [7839,7912]
===
match
---
name: logging_mixin [1457,1470]
name: logging_mixin [1457,1470]
===
match
---
trailer [12653,12661]
trailer [12629,12637]
===
match
---
operator: } [5809,5810]
operator: } [5809,5810]
===
match
---
classdef [1563,13744]
classdef [1563,13720]
===
match
---
name: self [5289,5293]
name: self [5289,5293]
===
match
---
argument [13622,13643]
argument [13598,13619]
===
match
---
expr_stmt [5928,5972]
expr_stmt [5928,5972]
===
match
---
name: try_number [3930,3940]
name: try_number [3930,3940]
===
match
---
name: _clean_execution_date [10885,10906]
name: _clean_execution_date [10861,10882]
===
match
---
atom_expr [7846,7911]
atom_expr [7846,7911]
===
match
---
atom [7856,7910]
atom [7856,7910]
===
match
---
operator: = [3528,3529]
operator: = [3528,3529]
===
match
---
expr_stmt [5786,5810]
expr_stmt [5786,5810]
===
match
---
name: str [10825,10828]
name: str [10801,10804]
===
match
---
operator: , [7937,7938]
operator: , [7937,7938]
===
match
---
funcdef [3727,4346]
funcdef [3727,4346]
===
match
---
name: metadata [5330,5338]
name: metadata [5330,5338]
===
match
---
operator: - [6690,6691]
operator: - [6690,6691]
===
match
---
trailer [6689,6693]
trailer [6689,6693]
===
match
---
name: format [13461,13467]
name: format [13437,13443]
===
match
---
simple_stmt [12649,12697]
simple_stmt [12625,12673]
===
match
---
expr_stmt [6421,6458]
expr_stmt [6421,6458]
===
match
---
trailer [4027,4039]
trailer [4027,4039]
===
match
---
name: label [3628,3633]
name: label [3628,3633]
===
match
---
trailer [10598,11138]
trailer [10574,11114]
===
match
---
sync_comp_for [3624,3659]
sync_comp_for [3624,3659]
===
match
---
name: _format_msg [8045,8056]
name: _format_msg [8045,8056]
===
match
---
operator: = [9381,9382]
operator: = [9381,9382]
===
match
---
number: 0 [5166,5167]
number: 0 [5166,5167]
===
match
---
decorated [4834,5210]
decorated [4834,5210]
===
match
---
atom_expr [4781,4828]
atom_expr [4781,4828]
===
match
---
simple_stmt [12835,12854]
simple_stmt [12811,12830]
===
match
---
name: LOG_NAME [2438,2446]
name: LOG_NAME [2438,2446]
===
match
---
name: message [7771,7778]
name: message [7771,7778]
===
match
---
suite [3833,4011]
suite [3833,4011]
===
match
---
trailer [7140,7172]
trailer [7140,7172]
===
match
---
trailer [3347,3361]
trailer [3347,3361]
===
match
---
dotted_name [1185,1199]
dotted_name [1185,1199]
===
match
---
parameters [7708,7715]
parameters [7708,7715]
===
match
---
trailer [7395,7409]
trailer [7395,7409]
===
match
---
trailer [6137,6144]
trailer [6137,6144]
===
match
---
name: Tuple [1544,1549]
name: Tuple [1544,1549]
===
match
---
trailer [8483,8495]
trailer [8483,8495]
===
match
---
name: self [13959,13963]
name: self [13935,13939]
===
match
---
atom_expr [9457,9471]
atom_expr [9457,9471]
===
match
---
trailer [5956,5972]
trailer [5956,5972]
===
match
---
simple_stmt [14041,14069]
simple_stmt [14017,14045]
===
match
---
exprlist [7968,7984]
exprlist [7968,7984]
===
match
---
simple_stmt [3953,4011]
simple_stmt [3953,4011]
===
match
---
atom_expr [9287,9364]
atom_expr [9287,9364]
===
match
---
atom_expr [13530,13551]
atom_expr [13506,13527]
===
match
---
parameters [11662,11668]
parameters [11638,11644]
===
match
---
string: "," [3655,3658]
string: "," [3655,3658]
===
match
---
simple_stmt [12172,12191]
simple_stmt [12148,12167]
===
match
---
name: str [2593,2596]
name: str [2593,2596]
===
match
---
trailer [1543,1560]
trailer [1543,1560]
===
match
---
atom_expr [7816,7826]
atom_expr [7816,7826]
===
match
---
lambdef [5141,5185]
lambdef [5141,5185]
===
match
---
name: json_fields [10693,10704]
name: json_fields [10669,10680]
===
match
---
atom_expr [11508,11549]
atom_expr [11484,11525]
===
match
---
comp_op [5831,5837]
comp_op [5831,5837]
===
match
---
trailer [14057,14068]
trailer [14033,14044]
===
match
---
name: log_id [6002,6008]
name: log_id [6002,6008]
===
match
---
name: cur_ts [7551,7557]
name: cur_ts [7551,7557]
===
match
---
expr_stmt [13431,13654]
expr_stmt [13407,13630]
===
match
---
expr_stmt [12773,12800]
expr_stmt [12749,12776]
===
match
---
trailer [8696,8704]
trailer [8696,8704]
===
match
---
name: task_instance [13488,13501]
name: task_instance [13464,13477]
===
match
---
name: parse_template_string [3272,3293]
name: parse_template_string [3272,3293]
===
match
---
simple_stmt [5786,5811]
simple_stmt [5786,5811]
===
match
---
name: url [13740,13743]
name: url [13716,13719]
===
match
---
name: self [12452,12456]
name: self [12428,12432]
===
match
---
return_stmt [8681,8704]
return_stmt [8681,8704]
===
match
---
expr_stmt [6036,6081]
expr_stmt [6036,6081]
===
match
---
name: json_format [8332,8343]
name: json_format [8332,8343]
===
match
---
name: logs [4876,4880]
name: logs [4876,4880]
===
match
---
simple_stmt [12031,12050]
simple_stmt [12007,12026]
===
match
---
operator: , [10639,10640]
operator: , [10615,10616]
===
match
---
atom_expr [5371,5396]
atom_expr [5371,5396]
===
match
---
name: formatter [10573,10582]
name: formatter [10549,10558]
===
match
---
name: offset [7317,7323]
name: offset [7317,7323]
===
match
---
suite [7716,7912]
suite [7716,7912]
===
match
---
name: log [1453,1456]
name: log [1453,1456]
===
match
---
expr_stmt [3425,3454]
expr_stmt [3425,3454]
===
match
---
atom_expr [9300,9311]
atom_expr [9300,9311]
===
match
---
simple_stmt [6091,6145]
simple_stmt [6091,6145]
===
match
---
name: key [4961,4964]
name: key [4961,4964]
===
match
---
string: 'Could not get current log size with log_id: %s' [9886,9934]
string: 'Could not get current log size with log_id: %s' [9886,9934]
===
match
---
name: self [10066,10070]
name: self [10066,10070]
===
match
---
trailer [6764,6778]
trailer [6764,6778]
===
match
---
operator: = [5987,5988]
operator: = [5987,5988]
===
match
---
trailer [3324,3331]
trailer [3324,3331]
===
match
---
atom_expr [3590,3606]
atom_expr [3590,3606]
===
match
---
sync_comp_for [7964,8000]
sync_comp_for [7964,8000]
===
match
---
atom_expr [12412,12438]
atom_expr [12388,12414]
===
match
---
operator: = [4324,4325]
operator: = [4324,4325]
===
match
---
test [6781,6827]
test [6781,6827]
===
match
---
name: metadata [7284,7292]
name: metadata [7284,7292]
===
match
---
trailer [5162,5165]
trailer [5162,5165]
===
match
---
operator: } [11122,11123]
operator: } [11098,11099]
===
match
---
name: dag_id [4245,4251]
name: dag_id [4245,4251]
===
match
---
number: 0 [5881,5882]
number: 0 [5881,5882]
===
match
---
arglist [14058,14067]
arglist [14034,14043]
===
match
---
name: self [14077,14081]
name: self [14053,14057]
===
match
---
atom_expr [8688,8704]
atom_expr [8688,8704]
===
match
---
name: __stdout__ [11406,11416]
name: __stdout__ [11382,11392]
===
match
---
name: int [7444,7447]
name: int [7444,7447]
===
match
---
operator: = [3105,3106]
operator: = [3105,3106]
===
match
---
name: List [1539,1543]
name: List [1539,1543]
===
match
---
return_stmt [4197,4345]
return_stmt [4197,4345]
===
match
---
argument [4263,4281]
argument [4263,4281]
===
match
---
number: 0 [9787,9788]
number: 0 [9787,9788]
===
match
---
name: PAGE [10071,10075]
name: PAGE [10071,10075]
===
match
---
param [5330,5361]
param [5330,5361]
===
match
---
expr_stmt [6091,6144]
expr_stmt [6091,6144]
===
match
---
simple_stmt [3192,3212]
simple_stmt [3192,3212]
===
match
---
name: handler [12143,12150]
name: handler [12119,12126]
===
match
---
name: offset [6138,6144]
name: offset [6138,6144]
===
match
---
trailer [11611,11615]
trailer [11587,11591]
===
match
---
name: closed [12840,12846]
name: closed [12816,12822]
===
match
---
operator: = [13438,13439]
operator: = [13414,13415]
===
match
---
name: self [10705,10709]
name: self [10681,10685]
===
match
---
name: self [10321,10325]
name: self [10297,10301]
===
match
---
name: self [5238,5242]
name: self [5238,5242]
===
match
---
trailer [9349,9354]
trailer [9349,9354]
===
match
---
name: host [7933,7937]
name: host [7933,7937]
===
match
---
expr_stmt [7729,7826]
expr_stmt [7729,7826]
===
match
---
name: _read [5274,5279]
name: _read [5274,5279]
===
match
---
operator: , [3750,3751]
operator: , [3750,3751]
===
match
---
string: 'download_logs' [9524,9539]
string: 'download_logs' [9524,9539]
===
match
---
number: 0 [6826,6827]
number: 0 [6826,6827]
===
match
---
argument [4314,4335]
argument [4314,4335]
===
match
---
name: logs [5982,5986]
name: logs [5982,5986]
===
match
---
atom_expr [5115,5135]
atom_expr [5115,5135]
===
match
---
operator: = [2853,2854]
operator: = [2853,2854]
===
match
---
operator: , [11033,11034]
operator: , [11009,11010]
===
match
---
operator: != [6706,6708]
operator: != [6706,6708]
===
match
---
arglist [4975,5002]
arglist [4975,5002]
===
match
---
tfpdef [2694,2711]
tfpdef [2694,2711]
===
match
---
if_stmt [8324,8608]
if_stmt [8324,8608]
===
match
---
try_stmt [8357,8608]
try_stmt [8357,8608]
===
match
---
name: Optional [927,935]
name: Optional [927,935]
===
match
---
argument [11395,11416]
argument [11371,11392]
===
match
---
name: self [3243,3247]
name: self [3243,3247]
===
match
---
name: es_read [5994,6001]
name: es_read [5994,6001]
===
match
---
name: Optional [2838,2846]
name: Optional [2838,2846]
===
match
---
if_stmt [12135,12210]
if_stmt [12111,12186]
===
match
---
param [2606,2627]
param [2606,2627]
===
match
---
trailer [10781,10792]
trailer [10757,10768]
===
match
---
suite [11202,11345]
suite [11178,11321]
===
match
---
simple_stmt [788,803]
simple_stmt [788,803]
===
match
---
operator: = [6779,6780]
operator: = [6779,6780]
===
match
---
arglist [3148,3182]
arglist [3148,3182]
===
match
---
classdef [13746,14106]
classdef [13722,14082]
===
match
---
expr_stmt [12452,12494]
expr_stmt [12428,12470]
===
match
---
expr_stmt [4961,5003]
expr_stmt [4961,5003]
===
match
---
trailer [10109,10111]
trailer [10109,10111]
===
match
---
name: __init__ [3139,3147]
name: __init__ [3139,3147]
===
match
---
name: airflow [1146,1153]
name: airflow [1146,1153]
===
match
---
number: 0 [6654,6655]
number: 0 [6654,6655]
===
match
---
atom_expr [7939,7962]
atom_expr [7939,7962]
===
match
---
name: self [12172,12176]
name: self [12148,12152]
===
match
---
simple_stmt [12452,12531]
simple_stmt [12428,12507]
===
match
---
trailer [11450,11458]
trailer [11426,11434]
===
match
---
atom_expr [4967,5003]
atom_expr [4967,5003]
===
match
---
name: logging [795,802]
name: logging [795,802]
===
match
---
name: max_log_line [9974,9986]
name: max_log_line [9974,9986]
===
match
---
atom_expr [12675,12695]
atom_expr [12651,12671]
===
match
---
tfpdef [5313,5328]
tfpdef [5313,5328]
===
match
---
name: _format_msg [7862,7873]
name: _format_msg [7862,7873]
===
match
---
atom_expr [3192,3203]
atom_expr [3192,3203]
===
match
---
name: self [5937,5941]
name: self [5937,5941]
===
match
---
trailer [8440,8450]
trailer [8440,8450]
===
match
---
simple_stmt [12810,12826]
simple_stmt [12786,12802]
===
match
---
simple_stmt [9649,9720]
simple_stmt [9649,9720]
===
match
---
simple_stmt [7387,7417]
simple_stmt [7387,7417]
===
match
---
subscriptlist [5377,5395]
subscriptlist [5377,5395]
===
match
---
name: getattr [4967,4974]
name: getattr [4967,4974]
===
match
---
name: kwargs [14098,14104]
name: kwargs [14074,14080]
===
match
---
name: metadata [9565,9573]
name: metadata [9565,9573]
===
match
---
atom_expr [1539,1560]
atom_expr [1539,1560]
===
match
---
operator: = [5795,5796]
operator: = [5795,5796]
===
match
---
name: task_id [13544,13551]
name: task_id [13520,13527]
===
match
---
simple_stmt [5016,5046]
simple_stmt [5016,5046]
===
match
---
name: field [14007,14012]
name: field [13983,13988]
===
match
---
param [13984,13992]
param [13960,13968]
===
match
---
trailer [9318,9349]
trailer [9318,9349]
===
match
---
trailer [12431,12438]
trailer [12407,12414]
===
match
---
simple_stmt [5099,5187]
simple_stmt [5099,5187]
===
match
---
trailer [9354,9364]
trailer [9354,9364]
===
match
---
name: self [8479,8483]
name: self [8479,8483]
===
match
---
if_stmt [4020,4189]
if_stmt [4020,4189]
===
match
---
name: mark_end_on_close [10495,10512]
name: mark_end_on_close [10471,10488]
===
match
---
suite [4948,5046]
suite [4948,5046]
===
match
---
name: time [885,889]
name: time [885,889]
===
match
---
atom_expr [8327,8343]
atom_expr [8327,8343]
===
match
---
name: self [12886,12890]
name: self [12862,12866]
===
match
---
expr_stmt [3590,3660]
expr_stmt [3590,3660]
===
match
---
testlist_comp [7857,7909]
testlist_comp [7857,7909]
===
match
---
string: """         Provide task_instance context to airflow task handler.          :param ti: task instance object         """ [10362,10481]
string: """         Provide task_instance context to airflow task handler.          :param ti: task instance object         """ [10338,10457]
===
match
---
name: ti [5957,5959]
name: ti [5957,5959]
===
match
---
import_from [1141,1179]
import_from [1141,1179]
===
match
---
trailer [11084,11104]
trailer [11060,11080]
===
match
---
funcdef [10305,11648]
funcdef [10281,11624]
===
match
---
suite [9992,10279]
suite [9992,10255]
===
match
---
expr_stmt [10027,10111]
expr_stmt [10027,10111]
===
match
---
atom_expr [11947,11958]
atom_expr [11923,11934]
===
match
---
trailer [4231,4345]
trailer [4231,4345]
===
match
---
name: self [6051,6055]
name: self [6051,6055]
===
match
---
atom_expr [12786,12800]
atom_expr [12762,12776]
===
match
---
tfpdef [8741,8752]
tfpdef [8741,8752]
===
match
---
simple_stmt [803,814]
simple_stmt [803,814]
===
match
---
atom [10746,11123]
atom [10722,11099]
===
match
---
trailer [9293,9312]
trailer [9293,9312]
===
match
---
parameters [12885,12891]
parameters [12861,12867]
===
match
---
parameters [10320,10344]
parameters [10296,10320]
===
match
---
name: self [4023,4027]
name: self [4023,4027]
===
match
---
trailer [6807,6822]
trailer [6807,6822]
===
match
---
suite [10009,10112]
suite [10009,10112]
===
match
---
name: stdout [12777,12783]
name: stdout [12753,12759]
===
match
---
name: metadata [9515,9523]
name: metadata [9515,9523]
===
match
---
name: json_fields [10710,10721]
name: json_fields [10686,10697]
===
match
---
name: super [12810,12815]
name: super [12786,12791]
===
match
---
atom_expr [13580,13608]
atom_expr [13556,13584]
===
match
---
name: mark_end_on_close [12000,12017]
name: mark_end_on_close [11976,11993]
===
match
---
name: close [11657,11662]
name: close [11633,11638]
===
match
---
expr_stmt [6619,6747]
expr_stmt [6619,6747]
===
match
---
simple_stmt [5928,5973]
simple_stmt [5928,5973]
===
match
---
argument [13481,13508]
argument [13457,13484]
===
match
---
param [2574,2597]
param [2574,2597]
===
match
---
name: ti [5295,5297]
name: ti [5295,5297]
===
match
---
name: parse [7135,7140]
name: parse [7135,7140]
===
match
---
name: lines [7761,7766]
name: lines [7761,7766]
===
match
---
name: update [14091,14097]
name: update [14067,14073]
===
match
---
name: _clean_execution_date [4075,4096]
name: _clean_execution_date [4075,4096]
===
match
---
testlist_comp [7933,7962]
testlist_comp [7933,7962]
===
match
---
arglist [6002,6026]
arglist [6002,6026]
===
match
---
expr_stmt [2396,2404]
expr_stmt [2396,2404]
===
match
---
string: 'end_of_log' [7396,7408]
string: 'end_of_log' [7396,7408]
===
match
---
simple_stmt [3095,3123]
simple_stmt [3095,3123]
===
match
---
trailer [8507,8515]
trailer [8507,8515]
===
match
---
parameters [4394,4420]
parameters [4394,4420]
===
match
---
name: filename_template [2574,2591]
name: filename_template [2574,2591]
===
match
---
atom_expr [12452,12471]
atom_expr [12428,12447]
===
match
---
name: sys [12786,12789]
name: sys [12762,12765]
===
match
---
operator: = [12784,12785]
operator: = [12760,12761]
===
match
---
atom_expr [14041,14068]
atom_expr [14017,14044]
===
match
---
name: Search [9287,9293]
name: Search [9287,9293]
===
match
---
funcdef [12873,12956]
funcdef [12849,12932]
===
match
---
comparison [7429,7460]
comparison [7429,7460]
===
match
---
name: ti [4159,4161]
name: ti [4159,4161]
===
match
---
operator: , [2596,2597]
operator: , [2596,2597]
===
match
---
comparison [9611,9627]
comparison [9611,9627]
===
match
---
atom_expr [3862,3887]
atom_expr [3862,3887]
===
match
---
atom_expr [5989,6027]
atom_expr [5989,6027]
===
match
---
suite [5397,8036]
suite [5397,8036]
===
match
---
trailer [10199,10203]
trailer [10194,10198]
===
match
---
trailer [10884,10906]
trailer [10860,10882]
===
match
---
simple_stmt [3551,3582]
simple_stmt [3551,3582]
===
match
---
atom_expr [5340,5354]
atom_expr [5340,5354]
===
match
---
name: ti [10907,10909]
name: ti [10883,10885]
===
match
---
name: concat_logs [7939,7950]
name: concat_logs [7939,7950]
===
match
---
import_from [814,849]
import_from [814,849]
===
match
---
atom_expr [12740,12760]
atom_expr [12716,12736]
===
match
---
name: split [3649,3654]
name: split [3649,3654]
===
match
---
operator: = [4904,4905]
operator: = [4904,4905]
===
match
---
atom_expr [5108,5186]
atom_expr [5108,5186]
===
match
---
param [5313,5329]
param [5313,5329]
===
match
---
name: message [6698,6705]
name: message [6698,6705]
===
match
---
simple_stmt [1087,1103]
simple_stmt [1087,1103]
===
match
---
name: ti [4097,4099]
name: ti [4097,4099]
===
match
---
simple_stmt [1220,1255]
simple_stmt [1220,1255]
===
match
---
atom_expr [9383,9433]
atom_expr [9383,9433]
===
match
---
name: formatter [10625,10634]
name: formatter [10601,10610]
===
match
---
number: 0 [2403,2404]
number: 0 [2403,2404]
===
match
---
name: TaskInstance [3756,3768]
name: TaskInstance [3756,3768]
===
match
---
name: hosted_log [7951,7961]
name: hosted_log [7951,7961]
===
match
---
string: """         Creates an address for an external log collecting service.          :param task_instance: task instance object         :type: task_instance: TaskInstance         :param try_number: task instance try_number to read logs from.         :type try_number: Optional[int]         :return: URL to the external log collection service         :rtype: str         """ [13054,13422]
string: """         Creates an address for an external log collecting service.          :param task_instance: task instance object         :type: task_instance: TaskInstance         :param try_number: task instance try_number to read logs from.         :type try_number: Optional[int]         :return: URL to the external log collection service         :rtype: str         """ [13030,13398]
===
match
---
name: len [6804,6807]
name: len [6804,6807]
===
match
---
name: Optional [5340,5348]
name: Optional [5340,5348]
===
match
---
simple_stmt [10027,10112]
simple_stmt [10027,10112]
===
match
---
name: log_range [7899,7908]
name: log_range [7899,7908]
===
match
---
name: closed [12177,12183]
name: closed [12153,12159]
===
match
---
name: _read_grouped_logs [5219,5237]
name: _read_grouped_logs [5219,5237]
===
match
---
tfpdef [3770,3785]
tfpdef [3770,3785]
===
match
---
simple_stmt [2912,3087]
simple_stmt [2912,3087]
===
match
---
trailer [13460,13467]
trailer [13436,13443]
===
match
---
trailer [14081,14090]
trailer [14057,14066]
===
match
---
suite [12439,12531]
suite [12415,12507]
===
match
---
operator: , [13963,13964]
operator: , [13939,13940]
===
match
---
name: next_offset [7448,7459]
name: next_offset [7448,7459]
===
match
---
atom_expr [3900,3927]
atom_expr [3900,3927]
===
match
---
name: self [8057,8061]
name: self [8057,8061]
===
match
---
trailer [14045,14057]
trailer [14021,14033]
===
match
---
simple_stmt [7729,7827]
simple_stmt [7729,7827]
===
match
---
atom_expr [7514,7544]
atom_expr [7514,7544]
===
match
---
name: exception [10204,10213]
name: exception [10199,10208]
===
match
---
trailer [12176,12183]
trailer [12152,12159]
===
match
---
trailer [6697,6705]
trailer [6697,6705]
===
match
---
name: format [13696,13702]
name: format [13672,13678]
===
match
---
comparison [7464,7500]
comparison [7464,7500]
===
match
---
operator: ** [11098,11100]
operator: ** [11074,11076]
===
match
---
operator: = [6844,6845]
operator: = [6844,6845]
===
match
---
expr_stmt [3551,3581]
expr_stmt [3551,3581]
===
match
---
name: parse [955,960]
name: parse [955,960]
===
match
---
name: property [12860,12868]
name: property [12836,12844]
===
match
---
name: str [1550,1553]
name: str [1550,1553]
===
match
---
string: "%Y_%m_%dT%H_%M_%S_%f" [4805,4827]
string: "%Y_%m_%dT%H_%M_%S_%f" [4805,4827]
===
match
---
name: close [12753,12758]
name: close [12729,12734]
===
match
---
operator: >= [7325,7327]
operator: >= [7325,7327]
===
match
---
trailer [5348,5354]
trailer [5348,5354]
===
match
---
name: search [9383,9389]
name: search [9383,9389]
===
match
---
operator: = [4157,4158]
operator: = [4157,4158]
===
match
---
expr_stmt [3846,3887]
expr_stmt [3846,3887]
===
match
---
name: kv [5148,5150]
name: kv [5148,5150]
===
match
---
name: ti [10829,10831]
name: ti [10805,10807]
===
match
---
atom_expr [11624,11640]
atom_expr [11600,11616]
===
match
---
name: offset [9406,9412]
name: offset [9406,9412]
===
match
---
name: _ESJsonLogFmt [8465,8478]
name: _ESJsonLogFmt [8465,8478]
===
match
---
expr_stmt [5860,5882]
expr_stmt [5860,5882]
===
match
---
name: json_formatter [1398,1412]
name: json_formatter [1398,1412]
===
match
---
operator: , [935,936]
operator: , [935,936]
===
match
---
trailer [9312,9318]
trailer [9312,9318]
===
match
---
trailer [6693,6697]
trailer [6693,6697]
===
match
---
test [6105,6144]
test [6105,6144]
===
match
---
name: handler [12479,12486]
name: handler [12455,12462]
===
match
---
operator: = [2447,2448]
operator: = [2447,2448]
===
match
---
name: search [9457,9463]
name: search [9457,9463]
===
match
---
simple_stmt [14077,14106]
simple_stmt [14053,14082]
===
match
---
trailer [10906,10925]
trailer [10882,10901]
===
match
---
name: end_of_log_mark [12680,12695]
name: end_of_log_mark [12656,12671]
===
match
---
operator: = [6440,6441]
operator: = [6440,6441]
===
match
---
trailer [12668,12674]
trailer [12644,12650]
===
match
---
if_stmt [11182,11345]
if_stmt [11158,11321]
===
match
---
name: logs_by_host [7988,8000]
name: logs_by_host [7988,8000]
===
match
---
name: self [9867,9871]
name: self [9867,9871]
===
match
---
tfpdef [2827,2852]
tfpdef [2827,2852]
===
match
---
if_stmt [12378,12531]
if_stmt [12354,12507]
===
match
---
name: dag_id [13502,13508]
name: dag_id [13478,13484]
===
match
---
name: _render_log_id [5942,5956]
name: _render_log_id [5942,5956]
===
match
---
name: task_id [10832,10839]
name: task_id [10808,10815]
===
match
---
name: isoformat [4177,4186]
name: isoformat [4177,4186]
===
match
---
trailer [3293,3310]
trailer [3293,3310]
===
match
---
suite [7370,7417]
suite [7370,7417]
===
match
---
parameters [4875,4881]
parameters [4875,4881]
===
match
---
param [2666,2685]
param [2666,2685]
===
match
---
expr_stmt [9442,9471]
expr_stmt [9442,9471]
===
match
---
except_clause [9801,9817]
except_clause [9801,9817]
===
match
---
operator: , [4312,4313]
operator: , [4312,4313]
===
match
---
name: str [2734,2737]
name: str [2734,2737]
===
match
---
name: EsLogMsgType [5377,5389]
name: EsLogMsgType [5377,5389]
===
match
---
return_stmt [8011,8035]
return_stmt [8011,8035]
===
match
---
operator: , [13608,13609]
operator: , [13584,13585]
===
match
---
name: _group_logs_by_host [6056,6075]
name: _group_logs_by_host [6056,6075]
===
match
---
simple_stmt [5253,5265]
simple_stmt [5253,5265]
===
match
---
name: i [7880,7881]
name: i [7880,7881]
===
match
---
name: _ESJsonLogFmt [13752,13765]
name: _ESJsonLogFmt [13728,13741]
===
match
---
name: lines [7709,7714]
name: lines [7709,7714]
===
match
---
atom_expr [13710,13723]
atom_expr [13686,13699]
===
match
---
import_from [1180,1219]
import_from [1180,1219]
===
match
---
atom_expr [3551,3567]
atom_expr [3551,3567]
===
match
---
trailer [5040,5045]
trailer [5040,5045]
===
match
---
tfpdef [2544,2564]
tfpdef [2544,2564]
===
match
---
operator: = [3332,3333]
operator: = [3332,3333]
===
match
---
trailer [3885,3887]
trailer [3885,3887]
===
match
---
funcdef [5270,8036]
funcdef [5270,8036]
===
match
---
operator: = [5935,5936]
operator: = [5935,5936]
===
match
---
atom_expr [7313,7324]
atom_expr [7313,7324]
===
match
---
name: self [3221,3225]
name: self [3221,3225]
===
match
---
or_test [7206,7355]
or_test [7206,7355]
===
match
---
name: int [7328,7331]
name: int [7328,7331]
===
match
---
trailer [4974,5003]
trailer [4974,5003]
===
match
---
name: int [11081,11084]
name: int [11057,11060]
===
match
---
string: """         :param base_log_folder: base folder to store logs locally         :param log_id_template: log id template         :param host: Elasticsearch host name         """ [2912,3086]
string: """         :param base_log_folder: base folder to store logs locally         :param log_id_template: log id template         :param host: Elasticsearch host name         """ [2912,3086]
===
match
---
name: pendulum [1094,1102]
name: pendulum [1094,1102]
===
match
---
simple_stmt [3900,3941]
simple_stmt [3900,3941]
===
match
---
name: task_id [4263,4270]
name: task_id [4263,4270]
===
match
---
suite [11677,12854]
suite [11653,12830]
===
match
---
parameters [5237,5243]
parameters [5237,5243]
===
match
---
comparison [9545,9573]
comparison [9545,9573]
===
match
---
number: 10 [11095,11097]
number: 10 [11071,11073]
===
match
---
suite [4040,4116]
suite [4040,4116]
===
match
---
name: airflow [1380,1387]
name: airflow [1380,1387]
===
match
---
simple_stmt [8603,8608]
simple_stmt [8603,8608]
===
match
---
name: _open [12487,12492]
name: _open [12463,12468]
===
match
---
operator: , [11104,11105]
operator: , [11080,11081]
===
match
---
factor [6694,6696]
factor [6694,6696]
===
match
---
name: __setattr__ [14046,14057]
name: __setattr__ [14022,14033]
===
match
---
name: super [3131,3136]
name: super [3131,3136]
===
match
---
expr_stmt [11358,11417]
expr_stmt [11334,11393]
===
match
---
atom [9960,9962]
atom [9960,9962]
===
match
---
name: FileTaskHandler [1359,1374]
name: FileTaskHandler [1359,1374]
===
match
---
param [2544,2565]
param [2544,2565]
===
match
---
atom_expr [11373,11417]
atom_expr [11349,11393]
===
match
---
name: task_id [13522,13529]
name: task_id [13498,13505]
===
match
---
expr_stmt [12031,12049]
expr_stmt [12007,12025]
===
match
---
name: context_set [3702,3713]
name: context_set [3702,3713]
===
match
---
simple_stmt [12203,12210]
simple_stmt [12179,12186]
===
match
---
name: result [5099,5105]
name: result [5099,5105]
===
match
---
suite [12018,12069]
suite [11994,12045]
===
match
---
comparison [12381,12408]
comparison [12357,12384]
===
match
---
name: execute [10102,10109]
name: execute [10102,10109]
===
match
---
and_test [7268,7355]
and_test [7268,7355]
===
match
---
name: self [9300,9304]
name: self [9300,9304]
===
match
---
expr_stmt [5892,5919]
expr_stmt [5892,5919]
===
match
---
name: List [13978,13982]
name: List [13954,13958]
===
match
---
string: 'https://' [13669,13679]
string: 'https://' [13645,13655]
===
match
---
comparison [6804,6827]
comparison [6804,6827]
===
match
---
tfpdef [8728,8739]
tfpdef [8728,8739]
===
match
---
trailer [13593,13608]
trailer [13569,13584]
===
match
---
number: 1 [9710,9711]
number: 1 [9710,9711]
===
match
---
name: int [7429,7432]
name: int [7429,7432]
===
match
---
string: """The log name""" [12908,12926]
string: """The log name""" [12884,12902]
===
match
---
operator: = [12472,12473]
operator: = [12448,12449]
===
match
---
expr_stmt [1524,1560]
expr_stmt [1524,1560]
===
match
---
trailer [2846,2852]
trailer [2846,2852]
===
match
---
name: log_id [13431,13437]
name: log_id [13407,13413]
===
match
---
name: dag_id [10785,10791]
name: dag_id [10761,10767]
===
match
---
subscriptlist [1550,1558]
subscriptlist [1550,1558]
===
match
---
import_as_names [921,942]
import_as_names [921,942]
===
match
---
trailer [12839,12846]
trailer [12815,12822]
===
match
---
trailer [3648,3654]
trailer [3648,3654]
===
match
---
trailer [12492,12494]
trailer [12468,12470]
===
match
---
if_stmt [7426,7559]
if_stmt [7426,7559]
===
match
---
name: _group_logs_by_host [4856,4875]
name: _group_logs_by_host [4856,4875]
===
match
---
name: airflow [1260,1267]
name: airflow [1260,1267]
===
match
---
string: 'host' [4980,4986]
string: 'host' [4980,4986]
===
match
---
operator: , [10325,10326]
operator: , [10301,10302]
===
match
---
name: now [6855,6858]
name: now [6855,6858]
===
match
---
import_name [1066,1086]
import_name [1066,1086]
===
match
---
atom_expr [1544,1559]
atom_expr [1544,1559]
===
match
---
name: frontend [3397,3405]
name: frontend [3397,3405]
===
match
---
comparison [7066,7098]
comparison [7066,7098]
===
match
---
string: 'range' [9397,9404]
string: 'range' [9397,9404]
===
match
---
param [2530,2535]
param [2530,2535]
===
match
---
name: dict [8764,8768]
name: dict [8764,8768]
===
match
---
expr_stmt [2438,2464]
expr_stmt [2438,2464]
===
match
---
suite [7099,7417]
suite [7099,7417]
===
match
---
atom_expr [7126,7172]
atom_expr [7126,7172]
===
match
---
trailer [12456,12464]
trailer [12432,12440]
===
match
---
name: metadata [9762,9770]
name: metadata [9762,9770]
===
match
---
name: loading_hosts [6808,6821]
name: loading_hosts [6808,6821]
===
match
---
trailer [7230,7241]
trailer [7230,7241]
===
match
---
suite [8586,8608]
suite [8586,8608]
===
match
---
expr_stmt [4142,4188]
expr_stmt [4142,4188]
===
match
---
name: es_kwargs [3095,3104]
name: es_kwargs [3095,3104]
===
match
---
name: to_dict [8508,8515]
name: to_dict [8508,8515]
===
match
---
power [11095,11102]
power [11071,11078]
===
match
---
name: formatter [8441,8450]
name: formatter [8441,8450]
===
match
---
atom_expr [5160,5168]
atom_expr [5160,5168]
===
match
---
trailer [7217,7230]
trailer [7217,7230]
===
match
---
operator: , [2656,2657]
operator: , [2656,2657]
===
match
---
parameters [8721,8769]
parameters [8721,8769]
===
match
---
atom_expr [3637,3659]
atom_expr [3637,3659]
===
match
---
string: 'log_id' [11001,11009]
string: 'log_id' [10977,10985]
===
match
---
trailer [4224,4231]
trailer [4224,4231]
===
match
---
name: sys [810,813]
name: sys [810,813]
===
match
---
number: 1 [7755,7756]
number: 1 [7755,7756]
===
match
---
trailer [13695,13702]
trailer [13671,13678]
===
match
---
trailer [12789,12800]
trailer [12765,12776]
===
match
---
operator: @ [12859,12860]
operator: @ [12835,12836]
===
match
---
name: utils [1268,1273]
name: utils [1268,1273]
===
match
---
name: Search [1133,1139]
name: Search [1133,1139]
===
match
---
atom_expr [4023,4039]
atom_expr [4023,4039]
===
match
---
except_clause [8532,8548]
except_clause [8532,8548]
===
match
---
name: close [12818,12823]
name: close [12794,12799]
===
match
---
operator: -> [13038,13040]
operator: -> [13014,13016]
===
match
---
atom_expr [2838,2852]
atom_expr [2838,2852]
===
match
---
trailer [5909,5919]
trailer [5909,5919]
===
match
---
string: 'Could not read log with log_id: %s, error: %s' [10214,10261]
string: 'Could not read log with log_id: %s' [10209,10245]
===
match
---
trailer [11597,11599]
trailer [11573,11575]
===
match
---
funcdef [11653,12854]
funcdef [11629,12830]
===
match
---
name: str [13041,13044]
name: str [13017,13020]
===
match
---
name: list [4918,4922]
name: list [4918,4922]
===
match
---
name: json_fields [14016,14027]
name: json_fields [13992,14003]
===
match
---
name: json_fields [2721,2732]
name: json_fields [2721,2732]
===
match
---
operator: , [4986,4987]
operator: , [4986,4987]
===
match
---
name: set_context [10309,10320]
name: set_context [10285,10296]
===
match
---
simple_stmt [10490,10526]
simple_stmt [10466,10502]
===
match
---
simple_stmt [13431,13655]
simple_stmt [13407,13631]
===
match
---
name: handler [11513,11520]
name: handler [11489,11496]
===
match
---
name: self [10195,10199]
name: self [10190,10194]
===
match
---
operator: = [9285,9286]
operator: = [9285,9286]
===
match
---
simple_stmt [4961,5004]
simple_stmt [4961,5004]
===
match
---
atom_expr [2855,2895]
atom_expr [2855,2895]
===
match
---
trailer [1549,1559]
trailer [1549,1559]
===
match
---
decorated [4351,4829]
decorated [4351,4829]
===
match
---
trailer [2870,2895]
trailer [2870,2895]
===
match
---
string: '_' [5181,5184]
string: '_' [5181,5184]
===
match
---
string: """Helper class to read ES Logs and re-format it to match settings.LOG_FORMAT""" [13771,13851]
string: """Helper class to read ES Logs and re-format it to match settings.LOG_FORMAT""" [13747,13827]
===
match
---
operator: @ [4834,4835]
operator: @ [4834,4835]
===
match
---
name: stream [11395,11401]
name: stream [11371,11377]
===
match
---
name: render [3987,3993]
name: render [3987,3993]
===
match
---
name: offset [6105,6111]
name: offset [6105,6111]
===
match
---
trailer [4917,4923]
trailer [4917,4923]
===
match
---
name: handler [12654,12661]
name: handler [12630,12637]
===
match
---
name: logging [11373,11380]
name: logging [11349,11356]
===
match
---
operator: - [7767,7768]
operator: - [7767,7768]
===
match
---
comparison [7268,7292]
comparison [7268,7292]
===
match
---
expr_stmt [11624,11647]
expr_stmt [11600,11623]
===
match
---
trailer [4273,4281]
trailer [4273,4281]
===
match
---
atom_expr [5152,5185]
atom_expr [5152,5185]
===
match
---
param [7709,7714]
param [7709,7714]
===
match
---
name: base_log_folder [2544,2559]
name: base_log_folder [2544,2559]
===
match
---
trailer [11533,11549]
trailer [11509,11525]
===
match
---
atom_expr [4159,4188]
atom_expr [4159,4188]
===
match
---
name: message [7921,7928]
name: message [7921,7928]
===
match
---
trailer [6854,6858]
trailer [6854,6858]
===
match
---
name: bool [2707,2711]
name: bool [2707,2711]
===
match
---
simple_stmt [1103,1140]
simple_stmt [1103,1140]
===
match
---
name: json_fields [8484,8495]
name: json_fields [8484,8495]
===
match
---
arith_expr [9681,9697]
arith_expr [9681,9697]
===
match
---
string: """Format ES Record to match settings.LOG_FORMAT when used with json_format""" [8082,8160]
string: """Format ES Record to match settings.LOG_FORMAT when used with json_format""" [8082,8160]
===
match
---
trailer [10624,10634]
trailer [10600,10610]
===
match
---
simple_stmt [4053,4116]
simple_stmt [4053,4116]
===
match
---
atom_expr [11995,12017]
atom_expr [11971,11993]
===
match
---
trailer [12478,12486]
trailer [12454,12462]
===
match
---
name: metadata [6018,6026]
name: metadata [6018,6026]
===
match
---
testlist_comp [6649,6737]
testlist_comp [6649,6737]
===
match
---
string: 'execution_date' [10862,10878]
string: 'execution_date' [10838,10854]
===
match
---
name: self [11358,11362]
name: self [11334,11338]
===
match
---
name: handler [11363,11370]
name: handler [11339,11346]
===
match
---
name: log_id [9342,9348]
name: log_id [9342,9348]
===
match
---
funcdef [12961,13744]
funcdef [12937,13720]
===
match
---
simple_stmt [9442,9472]
simple_stmt [9442,9472]
===
match
---
trailer [7808,7810]
trailer [7808,7810]
===
match
---
operator: , [1553,1554]
operator: , [1553,1554]
===
match
---
name: airflow [1225,1232]
name: airflow [1225,1232]
===
match
---
name: Elasticsearch [3348,3361]
name: Elasticsearch [3348,3361]
===
match
---
operator: , [10840,10841]
operator: , [10816,10817]
===
match
---
name: extras [10739,10745]
name: extras [10715,10721]
===
match
---
simple_stmt [5860,5883]
simple_stmt [5860,5883]
===
match
---
name: url [13663,13666]
name: url [13639,13642]
===
match
---
expr_stmt [9649,9719]
expr_stmt [9649,9719]
===
match
---
atom_expr [12172,12183]
atom_expr [12148,12159]
===
match
---
expr_stmt [6756,6827]
expr_stmt [6756,6827]
===
match
---
string: 'max_offset' [9771,9783]
string: 'max_offset' [9771,9783]
===
match
---
atom_expr [6846,6860]
atom_expr [6846,6860]
===
match
---
simple_stmt [7921,8002]
simple_stmt [7921,8002]
===
match
---
trailer [13543,13551]
trailer [13519,13527]
===
match
---
parameters [13958,13993]
parameters [13934,13969]
===
match
---
parameters [2482,2902]
parameters [2482,2902]
===
match
---
file_input [788,14106]
file_input [788,14082]
===
match
---
atom_expr [4271,4281]
atom_expr [4271,4281]
===
match
---
name: log_line [8063,8071]
name: log_line [8063,8071]
===
match
---
name: json_format [3556,3567]
name: json_format [3556,3567]
===
match
---
string: 'offset' [5798,5806]
string: 'offset' [5798,5806]
===
match
---
string: 'download_logs' [9483,9498]
string: 'download_logs' [9483,9498]
===
match
---
name: es_read [8714,8721]
name: es_read [8714,8721]
===
match
---
expr_stmt [3900,3940]
expr_stmt [3900,3940]
===
match
---
name: logs [9953,9957]
name: logs [9953,9957]
===
match
---
simple_stmt [3590,3661]
simple_stmt [3590,3661]
===
match
---
name: label [3610,3615]
name: label [3610,3615]
===
match
---
simple_stmt [9278,9365]
simple_stmt [9278,9365]
===
match
---
operator: = [5355,5356]
operator: = [5355,5356]
===
match
---
trailer [4804,4828]
trailer [4804,4828]
===
match
---
or_test [3107,3122]
or_test [3107,3122]
===
match
---
name: host [3363,3367]
name: host [3363,3367]
===
match
---
simple_stmt [8787,9204]
simple_stmt [8787,9204]
===
match
---
name: self [3392,3396]
name: self [3392,3396]
===
match
---
name: loading_hosts [6619,6632]
name: loading_hosts [6619,6632]
===
match
---
simple_stmt [4437,4766]
simple_stmt [4437,4766]
===
match
---
trailer [9885,9943]
trailer [9885,9943]
===
match
---
name: metadata [5786,5794]
name: metadata [5786,5794]
===
match
---
atom [7932,7963]
atom [7932,7963]
===
match
---
trailer [12674,12696]
trailer [12650,12672]
===
match
---
atom_expr [8436,8519]
atom_expr [8436,8519]
===
match
---
operator: , [5959,5960]
operator: , [5959,5960]
===
match
---
name: frontend [13687,13695]
name: frontend [13663,13671]
===
match
---
trailer [3594,3606]
trailer [3594,3606]
===
match
---
suite [4882,5210]
suite [4882,5210]
===
match
---
name: format [4225,4231]
name: format [4225,4231]
===
match
---
suite [5847,5883]
suite [5847,5883]
===
match
---
atom_expr [7444,7460]
atom_expr [7444,7460]
===
match
---
name: self [3697,3701]
name: self [3697,3701]
===
match
---
return_stmt [4774,4828]
return_stmt [4774,4828]
===
match
---
number: 1 [6695,6696]
number: 1 [6695,6696]
===
match
---
name: str [10961,10964]
name: str [10937,10940]
===
match
---
trailer [3673,3681]
trailer [3673,3681]
===
match
---
name: bool [2680,2684]
name: bool [2680,2684]
===
match
---
simple_stmt [1311,1375]
simple_stmt [1311,1375]
===
match
---
trailer [3467,3483]
trailer [3467,3483]
===
match
---
name: ti [10782,10784]
name: ti [10758,10760]
===
match
---
trailer [4096,4115]
trailer [4096,4115]
===
match
---
operator: = [9412,9413]
operator: = [9412,9413]
===
match
---
trailer [5868,5878]
trailer [5868,5878]
===
match
---
name: Exception [9808,9817]
name: Exception [9808,9817]
===
match
---
simple_stmt [5982,6028]
simple_stmt [5982,6028]
===
match
---
simple_stmt [1375,1434]
simple_stmt [1375,1434]
===
match
---
atom_expr [11468,11478]
atom_expr [11444,11454]
===
match
---
test [7741,7826]
test [7741,7826]
===
match
---
atom_expr [4204,4345]
atom_expr [4204,4345]
===
match
---
name: end_of_log_mark [2636,2651]
name: end_of_log_mark [2636,2651]
===
match
---
param [5238,5242]
param [5238,5242]
===
match
---
simple_stmt [11508,11566]
simple_stmt [11484,11542]
===
match
---
name: quote [13710,13715]
name: quote [13686,13691]
===
match
---
comparison [9974,9991]
comparison [9974,9991]
===
match
---
trailer [9698,9706]
trailer [9698,9706]
===
match
---
trailer [11362,11370]
trailer [11338,11346]
===
match
---
name: self [4204,4208]
name: self [4204,4208]
===
match
---
string: """         Endpoint for streaming log.          :param ti: task instance object         :param try_number: try_number of the task instance         :param metadata: log metadata,                          can be used for steaming log reading and auto-tailing.         :return: a list of tuple with host and log documents, metadata.         """ [5406,5748]
string: """         Endpoint for streaming log.          :param ti: task instance object         :param try_number: try_number of the task instance         :param metadata: log metadata,                          can be used for steaming log reading and auto-tailing.         :return: a list of tuple with host and log documents, metadata.         """ [5406,5748]
===
match
---
trailer [5165,5168]
trailer [5165,5168]
===
match
---
name: self [12709,12713]
name: self [12685,12689]
===
match
---
name: try_number [11038,11048]
name: try_number [11014,11024]
===
match
---
name: sys [11402,11405]
name: sys [11378,11381]
===
match
---
suite [7501,7559]
suite [7501,7559]
===
match
---
name: Tuple [937,942]
name: Tuple [937,942]
===
match
---
name: ti [3752,3754]
name: ti [3752,3754]
===
match
---
name: MAX_LINE_PER_PAGE [2409,2426]
name: MAX_LINE_PER_PAGE [2409,2426]
===
match
---
trailer [12713,12726]
trailer [12689,12702]
===
match
---
string: 'offset' [5910,5918]
string: 'offset' [5910,5918]
===
match
---
name: handler [12457,12464]
name: handler [12433,12440]
===
match
---
name: exception [9876,9885]
name: exception [9876,9885]
===
match
---
arglist [9397,9432]
arglist [9397,9432]
===
match
---
name: message [8697,8704]
name: message [8697,8704]
===
match
---
name: _style [8451,8457]
name: _style [8451,8457]
===
match
---
name: log_line [8688,8696]
name: log_line [8688,8696]
===
match
---
number: 1 [5163,5164]
number: 1 [5163,5164]
===
match
---
tfpdef [2606,2626]
tfpdef [2606,2626]
===
match
---
suite [9591,9789]
suite [9591,9789]
===
match
---
operator: -> [3787,3789]
operator: -> [3787,3789]
===
match
---
argument [4245,4261]
argument [4245,4261]
===
match
---
trailer [12661,12668]
trailer [12637,12644]
===
match
---
tfpdef [13965,13982]
tfpdef [13941,13958]
===
match
---
import_from [1434,1490]
import_from [1434,1490]
===
match
---
atom_expr [11592,11615]
atom_expr [11568,11591]
===
match
---
name: search [9374,9380]
name: search [9374,9380]
===
match
---
operator: , [10261,10262]
operator: , [10245,10246]
===
match
---
string: 'offset' [5869,5877]
string: 'offset' [5869,5877]
===
match
---
atom_expr [7857,7883]
atom_expr [7857,7883]
===
match
---
operator: , [3241,3242]
operator: , [3241,3242]
===
match
---
atom [3609,3660]
atom [3609,3660]
===
match
---
operator: = [6103,6104]
operator: = [6103,6104]
===
match
---
string: 'dag_id' [10768,10776]
string: 'dag_id' [10744,10752]
===
match
---
arglist [10214,10277]
arglist [10209,10253]
===
match
---
name: self [10490,10494]
name: self [10466,10470]
===
match
---
param [2694,2712]
param [2694,2712]
===
match
---
param [13959,13964]
param [13935,13940]
===
match
---
trailer [5133,5135]
trailer [5133,5135]
===
match
---
atom_expr [10066,10075]
atom_expr [10066,10075]
===
match
---
operator: , [10792,10793]
operator: , [10768,10769]
===
match
---
arglist [9319,9348]
arglist [9319,9348]
===
match
---
expr_stmt [3320,3382]
expr_stmt [3320,3382]
===
match
---
name: stream [12394,12400]
name: stream [12370,12376]
===
match
---
name: write_stdout [11156,11168]
name: write_stdout [11132,11144]
===
match
---
atom_expr [12381,12400]
atom_expr [12357,12376]
===
match
---
trailer [3136,3138]
trailer [3136,3138]
===
match
---
operator: = [3204,3205]
operator: = [3204,3205]
===
match
---
comparison [5822,5846]
comparison [5822,5846]
===
match
---
operator: - [6694,6695]
operator: - [6694,6695]
===
match
---
name: item [6661,6665]
name: item [6661,6665]
===
match
---
name: cur_ts [6837,6843]
name: cur_ts [6837,6843]
===
match
---
name: grouped_logs [5016,5028]
name: grouped_logs [5016,5028]
===
insert-node
---
name: ElasticsearchTaskHandler [1569,1593]
to
classdef [1563,13744]
at 0
===
insert-tree
---
arglist [1594,1623]
    name: FileTaskHandler [1594,1609]
    operator: , [1609,1610]
    name: LoggingMixin [1611,1623]
to
classdef [1563,13744]
at 1
===
insert-tree
---
simple_stmt [1630,2391]
    string: """     ElasticsearchTaskHandler is a python log handler that     reads logs from Elasticsearch. Note logs are not directly     indexed into Elasticsearch. Instead, it flushes logs     into local files. Additional software setup is required     to index the log into Elasticsearch, such as using     Filebeat and Logstash.     To efficiently query and sort Elasticsearch results, we assume each     log message has a field `log_id` consists of ti primary keys:     `log_id = {dag_id}-{task_id}-{execution_date}-{try_number}`     Log messages with specific log_id are sorted based on `offset`,     which is a unique integer indicates log message's order.     Timestamp here are unreliable because multiple log messages     might have the same timestamp.     """ [1630,2390]
to
suite [1625,13744]
at 0
===
update-node
---
string: 'Could not read log with log_id: %s, error: %s' [10214,10261]
replace 'Could not read log with log_id: %s, error: %s' by 'Could not read log with log_id: %s'
===
delete-node
---
name: ElasticsearchTaskHandler [1569,1593]
===
===
delete-tree
---
arglist [1594,1623]
    name: FileTaskHandler [1594,1609]
    operator: , [1609,1610]
    name: LoggingMixin [1611,1623]
===
delete-tree
---
simple_stmt [1630,2391]
    string: """     ElasticsearchTaskHandler is a python log handler that     reads logs from Elasticsearch. Note logs are not directly     indexed into Elasticsearch. Instead, it flushes logs     into local files. Additional software setup is required     to index the log into Elasticsearch, such as using     Filebeat and Logstash.     To efficiently query and sort Elasticsearch results, we assume each     log message has a field `log_id` consists of ti primary keys:     `log_id = {dag_id}-{task_id}-{execution_date}-{try_number}`     Log messages with specific log_id are sorted based on `offset`,     which is a unique integer indicates log message's order.     Timestamp here are unreliable because multiple log messages     might have the same timestamp.     """ [1630,2390]
===
delete-node
---
name: e [10144,10145]
===
===
delete-node
---
operator: , [10269,10270]
===
===
delete-tree
---
atom_expr [10271,10277]
    name: str [10271,10274]
    trailer [10274,10277]
        name: e [10275,10276]
