===
match
---
name: self [1266,1270]
name: self [1266,1270]
===
match
---
operator: , [1839,1840]
operator: , [1815,1816]
===
match
---
name: seconds [1665,1672]
name: seconds [1665,1672]
===
match
---
suite [1879,1932]
suite [1855,1908]
===
match
---
try_stmt [1543,1817]
try_stmt [1543,1793]
===
match
---
trailer [1980,1984]
trailer [1951,1955]
===
match
---
operator: , [1853,1854]
operator: , [1829,1830]
===
match
---
operator: , [1436,1437]
operator: , [1436,1437]
===
match
---
atom_expr [1489,1507]
atom_expr [1489,1507]
===
match
---
number: 1 [1081,1082]
number: 1 [1081,1082]
===
match
---
simple_stmt [1623,1674]
simple_stmt [1623,1674]
===
match
---
operator: , [1071,1072]
operator: , [1071,1072]
===
match
---
trailer [1238,1240]
trailer [1238,1240]
===
match
---
simple_stmt [1176,1242]
simple_stmt [1176,1242]
===
match
---
trailer [1397,1401]
trailer [1397,1401]
===
match
---
param [1084,1107]
param [1084,1107]
===
match
---
try_stmt [1875,2075]
try_stmt [1851,2027]
===
match
---
suite [1547,1674]
suite [1547,1674]
===
match
---
param [1073,1083]
param [1073,1083]
===
match
---
name: setitimer [1899,1908]
name: setitimer [1875,1884]
===
match
---
operator: = [1158,1159]
operator: = [1158,1159]
===
match
---
name: error_message [1197,1210]
name: error_message [1197,1210]
===
match
---
param [1855,1864]
param [1831,1840]
===
match
---
name: self [1489,1493]
name: self [1489,1493]
===
match
---
arglist [1408,1454]
arglist [1408,1454]
===
match
---
name: log [1398,1401]
name: log [1398,1401]
===
match
---
name: self [1528,1532]
name: self [1528,1532]
===
match
---
name: signal [1560,1566]
name: signal [1560,1566]
===
match
---
name: seconds [1073,1080]
name: seconds [1073,1080]
===
match
---
name: type_ [1841,1846]
name: type_ [1817,1822]
===
match
---
name: ITIMER_REAL [1916,1927]
name: ITIMER_REAL [1892,1903]
===
match
---
raise_stmt [1464,1508]
raise_stmt [1464,1508]
===
match
---
trailer [1444,1451]
trailer [1444,1451]
===
match
---
name: logging_mixin [886,899]
name: logging_mixin [886,899]
===
match
---
trailer [1125,1134]
trailer [1125,1134]
===
match
---
name: ValueError [1947,1957]
name: ValueError [1923,1933]
===
match
---
trailer [1566,1573]
trailer [1566,1573]
===
match
---
operator: , [1846,1847]
operator: , [1822,1823]
===
match
---
atom_expr [1590,1609]
atom_expr [1590,1609]
===
match
---
name: super [1118,1123]
name: super [1118,1123]
===
match
---
simple_stmt [1560,1611]
simple_stmt [1560,1611]
===
match
---
suite [1963,2075]
suite [1934,2027]
===
match
---
trailer [1664,1672]
trailer [1664,1672]
===
match
---
name: frame [1280,1285]
name: frame [1280,1285]
===
match
---
name: str [1438,1441]
name: str [1438,1441]
===
match
---
name: exceptions [826,836]
name: exceptions [826,836]
===
match
---
import_from [813,862]
import_from [813,862]
===
match
---
trailer [1734,1782]
trailer [1729,1792]
===
match
---
operator: , [1588,1589]
operator: , [1588,1589]
===
match
---
except_clause [1940,1962]
except_clause [1916,1933]
===
match
---
name: self [1145,1149]
name: self [1145,1149]
===
match
---
name: utils [876,881]
name: utils [876,881]
===
match
---
operator: , [1927,1928]
operator: , [1903,1904]
===
match
---
trailer [1228,1241]
trailer [1228,1241]
===
match
---
suite [1534,1817]
suite [1534,1793]
===
match
---
param [1266,1271]
param [1266,1271]
===
match
---
trailer [1407,1455]
trailer [1407,1455]
===
match
---
operator: = [1080,1081]
operator: = [1080,1081]
===
match
---
name: self [1718,1722]
name: self [1713,1717]
===
match
---
trailer [1493,1507]
trailer [1493,1507]
===
match
---
name: LoggingMixin [936,948]
name: LoggingMixin [936,948]
===
match
---
trailer [1451,1453]
trailer [1451,1453]
===
match
---
funcdef [1822,2075]
funcdef [1798,2027]
===
match
---
name: getpid [1445,1451]
name: getpid [1445,1451]
===
match
---
name: error_message [1084,1097]
name: error_message [1084,1097]
===
match
---
atom_expr [1438,1454]
atom_expr [1438,1454]
===
match
---
param [1280,1285]
param [1280,1285]
===
match
---
atom_expr [1640,1658]
atom_expr [1640,1658]
===
match
---
param [1835,1840]
param [1811,1816]
===
match
---
simple_stmt [788,798]
simple_stmt [788,798]
===
match
---
name: signal [1892,1898]
name: signal [1868,1874]
===
match
---
dotted_name [868,899]
dotted_name [868,899]
===
match
---
except_clause [1682,1704]
except_clause [1682,1699]
===
match
---
atom_expr [1145,1157]
atom_expr [1145,1157]
===
match
---
import_name [798,811]
import_name [798,811]
===
match
---
string: ', PID: ' [1213,1222]
string: ', PID: ' [1213,1222]
===
match
---
trailer [1726,1734]
trailer [1721,1729]
===
match
---
name: signal [1567,1573]
name: signal [1567,1573]
===
match
---
name: handle_timeout [1595,1609]
name: handle_timeout [1595,1609]
===
match
---
atom_expr [1623,1673]
atom_expr [1623,1673]
===
match
---
parameters [1265,1286]
parameters [1265,1286]
===
match
---
name: setitimer [1630,1639]
name: setitimer [1630,1639]
===
match
---
name: self [1660,1664]
name: self [1660,1664]
===
match
---
trailer [1594,1609]
trailer [1594,1609]
===
match
---
name: LoggingMixin [907,919]
name: LoggingMixin [907,919]
===
match
---
simple_stmt [1118,1137]
simple_stmt [1118,1137]
===
match
---
trailer [1984,1992]
trailer [1955,1963]
===
match
---
simple_stmt [1718,1783]
simple_stmt [1713,1793]
===
match
---
arglist [1909,1930]
arglist [1885,1906]
===
match
---
file_input [788,2075]
file_input [788,2027]
===
match
---
trailer [1573,1610]
trailer [1573,1610]
===
match
---
trailer [1992,2040]
trailer [1963,2026]
===
match
---
operator: + [1211,1212]
operator: + [1211,1212]
===
match
---
trailer [1629,1639]
trailer [1629,1639]
===
match
---
string: "timeout can't be used in the current context" [1735,1781]
string: "timeout can't be used in the current context" [1730,1776]
===
match
---
name: ValueError [1689,1699]
name: ValueError [1689,1699]
===
match
---
name: __exit__ [1826,1834]
name: __exit__ [1802,1810]
===
match
---
name: log [882,885]
name: log [882,885]
===
match
---
suite [1322,1509]
suite [1322,1509]
===
match
---
name: signal [805,811]
name: signal [805,811]
===
match
---
name: self [1176,1180]
name: self [1176,1180]
===
match
---
name: signal [1574,1580]
name: signal [1574,1580]
===
match
---
param [1272,1279]
param [1272,1279]
===
match
---
atom_expr [1909,1927]
atom_expr [1885,1903]
===
match
---
name: signum [1272,1278]
name: signum [1272,1278]
===
match
---
parameters [1066,1108]
parameters [1066,1108]
===
match
---
suite [982,2075]
suite [982,2027]
===
match
---
name: error [1402,1407]
name: error [1402,1407]
===
match
---
name: self [1067,1071]
name: self [1067,1071]
===
match
---
operator: , [1082,1083]
operator: , [1082,1083]
===
match
---
arith_expr [1197,1241]
arith_expr [1197,1241]
===
match
---
name: AirflowTaskTimeout [844,862]
name: AirflowTaskTimeout [844,862]
===
match
---
string: 'Timeout' [1098,1107]
string: 'Timeout' [1098,1107]
===
match
---
funcdef [1247,1509]
funcdef [1247,1509]
===
match
---
atom_expr [1229,1240]
atom_expr [1229,1240]
===
match
---
arglist [1574,1609]
arglist [1574,1609]
===
match
---
param [1848,1854]
param [1824,1830]
===
match
---
simple_stmt [987,1049]
simple_stmt [987,1049]
===
match
---
param [1528,1532]
param [1528,1532]
===
match
---
atom_expr [1976,2040]
atom_expr [1947,2026]
===
match
---
funcdef [1514,1817]
funcdef [1514,1793]
===
match
---
suite [1109,1242]
suite [1109,1242]
===
match
---
name: os [1229,1231]
name: os [1229,1231]
===
match
---
classdef [922,2075]
classdef [922,2027]
===
match
---
operator: = [1097,1098]
operator: = [1097,1098]
===
match
---
name: airflow [818,825]
name: airflow [818,825]
===
match
---
number: 0 [1929,1930]
number: 0 [1905,1906]
===
match
---
name: log [1981,1984]
name: log [1952,1955]
===
match
---
atom_expr [1892,1931]
atom_expr [1868,1907]
===
match
---
atom_expr [1118,1136]
atom_expr [1118,1136]
===
match
---
operator: , [1278,1279]
operator: , [1278,1279]
===
match
---
param [1841,1847]
param [1817,1823]
===
match
---
simple_stmt [1464,1509]
simple_stmt [1464,1509]
===
match
---
simple_stmt [1331,1385]
simple_stmt [1331,1385]
===
match
---
name: traceback [1855,1864]
name: traceback [1831,1840]
===
match
---
name: str [1225,1228]
name: str [1225,1228]
===
match
---
parameters [1527,1533]
parameters [1527,1533]
===
match
---
atom_expr [1470,1508]
atom_expr [1470,1508]
===
match
---
name: error_message [1181,1194]
name: error_message [1181,1194]
===
match
---
simple_stmt [1892,1932]
simple_stmt [1868,1908]
===
match
---
operator: , [1658,1659]
operator: , [1658,1659]
===
match
---
arglist [1640,1672]
arglist [1640,1672]
===
match
---
trailer [1898,1908]
trailer [1874,1884]
===
match
---
atom_expr [1225,1241]
atom_expr [1225,1241]
===
match
---
name: __init__ [1126,1134]
name: __init__ [1126,1134]
===
match
---
trailer [1639,1673]
trailer [1639,1673]
===
match
---
simple_stmt [798,812]
simple_stmt [798,812]
===
match
---
atom_expr [1393,1455]
atom_expr [1393,1455]
===
match
---
simple_stmt [863,920]
simple_stmt [863,920]
===
match
---
trailer [1915,1927]
trailer [1891,1903]
===
match
---
name: self [1835,1839]
name: self [1811,1815]
===
match
---
string: "Process timed out, PID: %s" [1408,1436]
string: "Process timed out, PID: %s" [1408,1436]
===
match
---
name: self [1590,1594]
name: self [1590,1594]
===
match
---
name: log [1723,1726]
name: log [1718,1721]
===
match
---
name: value [1848,1853]
name: value [1824,1829]
===
match
---
trailer [1441,1454]
trailer [1441,1454]
===
match
---
name: timeout [928,935]
name: timeout [928,935]
===
match
---
simple_stmt [1393,1456]
simple_stmt [1393,1456]
===
match
---
parameters [1834,1865]
parameters [1810,1841]
===
match
---
trailer [1488,1508]
trailer [1488,1508]
===
match
---
trailer [1580,1588]
trailer [1580,1588]
===
match
---
atom_expr [1718,1782]
atom_expr [1713,1792]
===
match
---
trailer [1401,1407]
trailer [1401,1407]
===
match
---
expr_stmt [1145,1167]
expr_stmt [1145,1167]
===
match
---
simple_stmt [813,863]
simple_stmt [813,863]
===
match
---
name: ITIMER_REAL [1647,1658]
name: ITIMER_REAL [1647,1658]
===
match
---
funcdef [1054,1242]
funcdef [1054,1242]
===
match
---
name: seconds [1160,1167]
name: seconds [1160,1167]
===
match
---
name: __enter__ [1518,1527]
name: __enter__ [1518,1527]
===
match
---
name: airflow [868,875]
name: airflow [868,875]
===
match
---
trailer [1722,1726]
trailer [1717,1721]
===
match
---
name: AirflowTaskTimeout [1470,1488]
name: AirflowTaskTimeout [1470,1488]
===
match
---
simple_stmt [1145,1168]
simple_stmt [1145,1168]
===
match
---
trailer [1123,1125]
trailer [1123,1125]
===
match
---
name: signal [1640,1646]
name: signal [1640,1646]
===
match
---
atom_expr [1660,1672]
atom_expr [1660,1672]
===
match
---
trailer [1646,1658]
trailer [1646,1658]
===
match
---
atom_expr [1442,1453]
atom_expr [1442,1453]
===
match
---
import_from [863,919]
import_from [863,919]
===
match
---
expr_stmt [1176,1241]
expr_stmt [1176,1241]
===
match
---
atom_expr [1560,1610]
atom_expr [1560,1610]
===
match
---
name: warning [1727,1734]
name: warning [1722,1729]
===
match
---
import_name [788,797]
import_name [788,797]
===
match
---
name: handle_timeout [1251,1265]
name: handle_timeout [1251,1265]
===
match
---
string: """To be used in a ``with`` block and timeout its content.""" [987,1048]
string: """To be used in a ``with`` block and timeout its content.""" [987,1048]
===
match
---
trailer [1908,1931]
trailer [1884,1907]
===
match
---
atom_expr [1574,1588]
atom_expr [1574,1588]
===
match
---
simple_stmt [1976,2041]
simple_stmt [1947,2027]
===
match
---
name: warning [1985,1992]
name: warning [1956,1963]
===
match
---
name: os [795,797]
name: os [795,797]
===
match
---
name: error_message [1494,1507]
name: error_message [1494,1507]
===
match
---
trailer [1149,1157]
trailer [1149,1157]
===
match
---
name: signal [1909,1915]
name: signal [1885,1891]
===
match
---
string: "timeout can't be used in the current context" [1993,2039]
string: "timeout can't be used in the current context" [1964,2010]
===
match
---
name: seconds [1150,1157]
name: seconds [1150,1157]
===
match
---
name: self [1976,1980]
name: self [1947,1951]
===
match
---
name: __init__ [1058,1066]
name: __init__ [1058,1066]
===
match
---
atom_expr [1176,1194]
atom_expr [1176,1194]
===
match
---
suite [1705,1817]
suite [1700,1793]
===
match
---
name: SIGALRM [1581,1588]
name: SIGALRM [1581,1588]
===
match
---
trailer [1180,1194]
trailer [1180,1194]
===
match
---
dotted_name [818,836]
dotted_name [818,836]
===
match
---
name: getpid [1232,1238]
name: getpid [1232,1238]
===
match
---
operator: , [1270,1271]
operator: , [1270,1271]
===
match
---
operator: + [1223,1224]
operator: + [1223,1224]
===
match
---
operator: = [1195,1196]
operator: = [1195,1196]
===
match
---
name: signal [1623,1629]
name: signal [1623,1629]
===
match
---
name: self [1393,1397]
name: self [1393,1397]
===
match
---
name: os [1442,1444]
name: os [1442,1444]
===
match
---
trailer [1134,1136]
trailer [1134,1136]
===
match
---
trailer [1231,1238]
trailer [1231,1238]
===
match
---
string: """Logs information and raises AirflowTaskTimeout.""" [1331,1384]
string: """Logs information and raises AirflowTaskTimeout.""" [1331,1384]
===
match
---
param [1067,1072]
param [1067,1072]
===
match
---
suite [1866,2075]
suite [1842,2027]
===
insert-node
---
arglist [1730,1791]
to
trailer [1734,1782]
at 0
===
insert-node
---
arglist [1964,2025]
to
trailer [1992,2040]
at 0
===
move-tree
---
string: "timeout can't be used in the current context" [1735,1781]
to
arglist [1730,1791]
at 0
===
move-tree
---
string: "timeout can't be used in the current context" [1993,2039]
to
arglist [1964,2025]
at 0
===
delete-node
---
name: e [1703,1704]
===
===
delete-tree
---
simple_stmt [1795,1817]
    atom_expr [1795,1816]
        name: self [1795,1799]
        trailer [1799,1803]
            name: log [1800,1803]
        trailer [1803,1813]
            name: exception [1804,1813]
        trailer [1813,1816]
            name: e [1814,1815]
===
delete-node
---
name: e [1961,1962]
===
===
delete-tree
---
simple_stmt [2053,2075]
    atom_expr [2053,2074]
        name: self [2053,2057]
        trailer [2057,2061]
            name: log [2058,2061]
        trailer [2061,2071]
            name: exception [2062,2071]
        trailer [2071,2074]
            name: e [2072,2073]
