===
match
---
trailer [4942,4973]
trailer [4942,4973]
===
match
---
number: 0 [5010,5011]
number: 0 [5010,5011]
===
match
---
trailer [5063,5065]
trailer [5063,5065]
===
match
---
name: to_flush [7000,7008]
name: to_flush [7000,7008]
===
match
---
string: """         Refresh sensor instances need to be handled by this operator. Create smart sensor         internal object based on the information persisted in the sensor_instance table.          """ [12633,12828]
string: """         Refresh sensor instances need to be handled by this operator. Create smart sensor         internal object based on the information persisted in the sensor_instance table.          """ [12633,12828]
===
match
---
trailer [15980,15989]
trailer [15922,15931]
===
match
---
dictorsetmaker [4210,4258]
dictorsetmaker [4210,4258]
===
match
---
trailer [7810,7833]
trailer [7810,7833]
===
match
---
name: update_ti_hostname_with_count [15059,15088]
name: update_ti_hostname_with_count [15001,15030]
===
match
---
trailer [17207,17213]
trailer [17149,17155]
===
match
---
funcdef [14159,15208]
funcdef [14101,15150]
===
match
---
parameters [18690,18707]
parameters [18649,18666]
===
match
---
trailer [27377,27396]
trailer [27290,27309]
===
match
---
string: "Sensor Timeout" [21835,21851]
string: "Sensor Timeout" [21748,21764]
===
match
---
name: self [30381,30385]
name: self [30240,30244]
===
match
---
name: task_id [14486,14493]
name: task_id [14428,14435]
===
match
---
trailer [6860,6866]
trailer [6860,6866]
===
match
---
funcdef [2862,3606]
funcdef [2862,3606]
===
match
---
name: sensor_work [29830,29841]
name: sensor_work [29689,29700]
===
match
---
argument [10190,10200]
argument [10190,10200]
===
match
---
expr_stmt [29384,29414]
expr_stmt [29243,29273]
===
match
---
trailer [14787,14802]
trailer [14729,14744]
===
match
---
operator: = [7590,7591]
operator: = [7590,7591]
===
match
---
name: is_infra_failure [26323,26339]
name: is_infra_failure [26236,26252]
===
match
---
atom_expr [29049,29121]
atom_expr [28962,29034]
===
match
---
atom_expr [3790,3802]
atom_expr [3790,3802]
===
match
---
trailer [16498,16504]
trailer [16440,16446]
===
match
---
atom_expr [14762,14771]
atom_expr [14704,14713]
===
match
---
and_test [19248,19386]
and_test [19207,19345]
===
match
---
name: dag_id [19556,19562]
name: dag_id [19515,19521]
===
match
---
name: cached_work [28289,28300]
name: cached_work [28202,28213]
===
match
---
name: _mark_multi_state [24998,25015]
name: _mark_multi_state [24911,24928]
===
match
---
trailer [29595,29600]
trailer [29454,29459]
===
match
---
name: sensor_work [21108,21119]
name: sensor_work [21062,21073]
===
match
---
simple_stmt [29804,29843]
simple_stmt [29663,29702]
===
match
---
trailer [20551,20558]
trailer [20510,20517]
===
match
---
operator: , [20905,20906]
operator: , [20864,20865]
===
match
---
name: self [9209,9213]
name: self [9209,9213]
===
match
---
operator: = [21682,21683]
operator: = [21595,21596]
===
match
---
operator: , [1237,1238]
operator: , [1237,1238]
===
match
---
name: filter [20123,20129]
name: filter [20082,20088]
===
match
---
expr_stmt [4342,4413]
expr_stmt [4342,4413]
===
match
---
simple_stmt [11638,11672]
simple_stmt [11638,11672]
===
match
---
operator: + [9354,9355]
operator: + [9354,9355]
===
match
---
trailer [20910,20930]
trailer [20869,20889]
===
match
---
string: 'email' [19378,19385]
string: 'email' [19337,19344]
===
match
---
name: float [12446,12451]
name: float [12446,12451]
===
match
---
string: 'email' [18400,18407]
string: 'email' [18409,18416]
===
match
---
name: Exception [29137,29146]
name: Exception [29050,29059]
===
match
---
name: settings [1137,1145]
name: settings [1137,1145]
===
match
---
name: log [19420,19423]
name: log [19379,19382]
===
match
---
name: set_infra_failure_timeout [8809,8834]
name: set_infra_failure_timeout [8809,8834]
===
match
---
if_stmt [18721,19530]
if_stmt [18680,19489]
===
match
---
name: json [3069,3073]
name: json [3069,3073]
===
match
---
name: _process_sensor_work_with_cached_state [24627,24665]
name: _process_sensor_work_with_cached_state [24540,24578]
===
match
---
name: _infra_failure_timeout [9262,9284]
name: _infra_failure_timeout [9262,9284]
===
match
---
name: self [12253,12257]
name: self [12253,12257]
===
match
---
name: log [20817,20820]
name: log [20776,20779]
===
match
---
name: info [23312,23316]
name: info [23225,23229]
===
match
---
name: shard_max [12125,12134]
name: shard_max [12125,12134]
===
match
---
if_stmt [18890,19171]
if_stmt [18849,19130]
===
match
---
name: self [15156,15160]
name: self [15098,15102]
===
match
---
expr_stmt [7639,7676]
expr_stmt [7639,7676]
===
match
---
string: """         Update task instance hostname for new sensor works.          :param sensor_works: Smart sensor internal object for a sensor task.         :param session: The sqlalchemy session.         """ [14226,14427]
string: """         Update task instance hostname for new sensor works.          :param sensor_works: Smart sensor internal object for a sensor task.         :param session: The sqlalchemy session.         """ [14168,14369]
===
match
---
operator: = [29355,29356]
operator: = [29214,29215]
===
match
---
name: self [14933,14937]
name: self [14875,14879]
===
match
---
name: sensor_work [20434,20445]
name: sensor_work [20393,20404]
===
match
---
atom_expr [16412,16429]
atom_expr [16354,16371]
===
match
---
name: get [22188,22191]
name: get [22101,22104]
===
match
---
trailer [16308,16315]
trailer [16250,16257]
===
match
---
atom_expr [24223,24244]
atom_expr [24136,24157]
===
match
---
name: encoded_poke_context [15283,15303]
name: encoded_poke_context [15225,15245]
===
match
---
atom_expr [3258,3285]
atom_expr [3258,3285]
===
match
---
atom_expr [12986,12999]
atom_expr [12986,12999]
===
match
---
suite [18803,19171]
suite [18762,19130]
===
match
---
trailer [23909,23932]
trailer [23822,23845]
===
match
---
name: self [21986,21990]
name: self [21899,21903]
===
match
---
string: "Poking with arguments: %s" [24139,24166]
string: "Poking with arguments: %s" [24052,24079]
===
match
---
operator: = [12100,12101]
operator: = [12100,12101]
===
match
---
suite [28549,28595]
suite [28462,28508]
===
match
---
trailer [16343,16351]
trailer [16285,16293]
===
match
---
expr_stmt [11344,11364]
expr_stmt [11344,11364]
===
match
---
arith_expr [4943,4972]
arith_expr [4943,4972]
===
match
---
trailer [21796,21798]
trailer [21709,21711]
===
match
---
name: TI [14762,14764]
name: TI [14704,14706]
===
match
---
name: _infra_failure_timeout [10146,10168]
name: _infra_failure_timeout [10146,10168]
===
match
---
simple_stmt [15335,15805]
simple_stmt [15277,15747]
===
match
---
operator: = [9237,9238]
operator: = [9237,9238]
===
match
---
atom_expr [5319,5330]
atom_expr [5319,5330]
===
match
---
trailer [29721,29734]
trailer [29580,29593]
===
match
---
operator: , [14493,14494]
operator: , [14435,14436]
===
match
---
trailer [18978,18982]
trailer [18937,18941]
===
match
---
name: provide_session [12561,12576]
name: provide_session [12561,12576]
===
match
---
trailer [4429,4442]
trailer [4429,4442]
===
match
---
atom_expr [8845,8866]
atom_expr [8845,8866]
===
match
---
name: args [11599,11603]
name: args [11599,11603]
===
match
---
trailer [18926,18944]
trailer [18885,18903]
===
match
---
name: fail_current_run [27084,27100]
name: fail_current_run [26997,27013]
===
match
---
operator: = [20383,20384]
operator: = [20342,20343]
===
match
---
trailer [18982,19029]
trailer [18941,18988]
===
match
---
suite [27134,27199]
suite [27047,27112]
===
match
---
atom_expr [15156,15207]
atom_expr [15098,15149]
===
match
---
if_stmt [12408,12555]
if_stmt [12408,12555]
===
match
---
trailer [10136,10138]
trailer [10136,10138]
===
match
---
simple_stmt [19205,19229]
simple_stmt [19164,19188]
===
match
---
name: all [13126,13129]
name: all [13126,13129]
===
match
---
import_from [1399,1453]
import_from [1399,1453]
===
match
---
atom_expr [20972,21005]
atom_expr [20931,20964]
===
match
---
atom_expr [28289,28306]
atom_expr [28202,28219]
===
match
---
expr_stmt [15026,15125]
expr_stmt [14968,15067]
===
match
---
name: execution_context [18905,18922]
name: execution_context [18864,18881]
===
match
---
name: log [30416,30419]
name: log [30275,30278]
===
match
---
trailer [30000,30013]
trailer [29859,29872]
===
match
---
name: self [3482,3486]
name: self [3482,3486]
===
match
---
suite [28058,28382]
suite [27971,28295]
===
match
---
trailer [27184,27198]
trailer [27097,27111]
===
match
---
name: self [5319,5323]
name: self [5319,5323]
===
match
---
trailer [23672,23674]
trailer [23585,23587]
===
match
---
expr_stmt [6494,6520]
expr_stmt [6494,6520]
===
match
---
not_test [12238,12286]
not_test [12238,12286]
===
match
---
name: log_id [4771,4777]
name: log_id [4771,4777]
===
match
---
name: soft_fail [11500,11509]
name: soft_fail [11500,11509]
===
match
---
operator: = [1646,1647]
operator: = [1646,1647]
===
match
---
name: execution_date [19808,19822]
name: execution_date [19767,19781]
===
match
---
atom_expr [20581,20598]
atom_expr [20540,20557]
===
match
---
parameters [15828,15849]
parameters [15770,15791]
===
match
---
funcdef [30486,30518]
funcdef [30345,30377]
===
match
---
trailer [23145,23149]
trailer [23058,23062]
===
match
---
name: task_id [5829,5836]
name: task_id [5829,5836]
===
match
---
operator: = [16920,16921]
operator: = [16862,16863]
===
match
---
name: sensor_works [29722,29734]
name: sensor_works [29581,29593]
===
match
---
name: int [12274,12277]
name: int [12274,12277]
===
match
---
operator: = [3420,3421]
operator: = [3420,3421]
===
match
---
trailer [23159,23212]
trailer [23072,23125]
===
match
---
trailer [3750,3757]
trailer [3750,3757]
===
match
---
operator: > [9578,9579]
operator: > [9578,9579]
===
match
---
comparison [28078,28103]
comparison [27991,28016]
===
match
---
atom_expr [3157,3189]
atom_expr [3157,3189]
===
match
---
simple_stmt [26574,26615]
simple_stmt [26487,26528]
===
match
---
atom_expr [24679,24696]
atom_expr [24592,24609]
===
match
---
expr_stmt [20641,20673]
expr_stmt [20600,20632]
===
match
---
name: handler_config [4134,4148]
name: handler_config [4134,4148]
===
match
---
name: POKE_EXCEPTION [28320,28334]
name: POKE_EXCEPTION [28233,28247]
===
match
---
trailer [3864,3879]
trailer [3864,3879]
===
match
---
name: cached_work [25450,25461]
name: cached_work [25363,25374]
===
match
---
name: set_state [26112,26121]
name: set_state [26025,26034]
===
match
---
string: """:return: exception msg.""" [9661,9690]
string: """:return: exception msg.""" [9661,9690]
===
match
---
name: self [30242,30246]
name: self [30101,30105]
===
match
---
expr_stmt [2926,2951]
expr_stmt [2926,2951]
===
match
---
param [11426,11444]
param [11426,11444]
===
match
---
name: state [15305,15310]
name: state [15247,15252]
===
match
---
operator: { [4209,4210]
operator: { [4209,4210]
===
match
---
name: ti_key [14818,14824]
name: ti_key [14760,14766]
===
match
---
operator: == [20333,20335]
operator: == [20292,20294]
===
match
---
trailer [30362,30376]
trailer [30221,30235]
===
match
---
name: datetime [10171,10179]
name: datetime [10171,10179]
===
match
---
suite [16788,17214]
suite [16730,17156]
===
match
---
name: _emit_loop_stats [30196,30212]
name: _emit_loop_stats [30055,30071]
===
match
---
name: _infra_failure_retry_window [7740,7767]
name: _infra_failure_retry_window [7740,7767]
===
match
---
trailer [3082,3095]
trailer [3082,3095]
===
match
---
name: execution_context [3137,3154]
name: execution_context [3137,3154]
===
match
---
simple_stmt [5117,5141]
simple_stmt [5117,5141]
===
match
---
operator: = [6479,6480]
operator: = [6479,6480]
===
match
---
trailer [21068,21072]
trailer [21022,21026]
===
match
---
trailer [13129,13131]
trailer [13129,13131]
===
match
---
simple_stmt [8845,8900]
simple_stmt [8845,8900]
===
match
---
suite [20304,21006]
suite [20263,20965]
===
match
---
name: timezone [29357,29365]
name: timezone [29216,29224]
===
match
---
comparison [16955,16980]
comparison [16897,16922]
===
match
---
atom_expr [15863,15871]
atom_expr [15805,15813]
===
match
---
operator: @ [9732,9733]
operator: @ [9732,9733]
===
match
---
name: SI [19805,19807]
name: SI [19764,19766]
===
match
---
simple_stmt [21864,21897]
simple_stmt [21777,21810]
===
match
---
suite [1730,1804]
suite [1730,1804]
===
match
---
simple_stmt [16908,16936]
simple_stmt [16850,16878]
===
match
---
suite [21044,21184]
suite [20998,21097]
===
match
---
name: SensorExceptionInfo [7272,7291]
name: SensorExceptionInfo [7272,7291]
===
match
---
name: AirflowException [21022,21038]
name: AirflowException [20981,20997]
===
match
---
operator: < [13038,13039]
operator: < [13038,13039]
===
match
---
atom_expr [26122,26146]
atom_expr [26035,26059]
===
match
---
name: dag_id [20133,20139]
name: dag_id [20092,20098]
===
match
---
trailer [13904,13908]
trailer [13846,13850]
===
match
---
arglist [26013,26034]
arglist [25926,25947]
===
match
---
atom_expr [6856,6866]
atom_expr [6856,6866]
===
match
---
trailer [14858,14860]
trailer [14800,14802]
===
match
---
atom [4209,4259]
atom [4209,4259]
===
match
---
trailer [26578,26601]
trailer [26491,26514]
===
match
---
import_from [1043,1123]
import_from [1043,1123]
===
match
---
arglist [17487,17566]
arglist [17496,17575]
===
match
---
param [14579,14585]
param [14521,14527]
===
match
---
suite [27232,27772]
suite [27145,27685]
===
match
---
classdef [1950,6026]
classdef [1950,6026]
===
match
---
name: TI [16391,16393]
name: TI [16333,16335]
===
match
---
name: exception_info [7981,7995]
name: exception_info [7981,7995]
===
match
---
name: ti_key [23620,23626]
name: ti_key [23533,23539]
===
match
---
name: query [16182,16187]
name: query [16124,16129]
===
match
---
suite [14595,15017]
suite [14537,14959]
===
match
---
trailer [19947,19956]
trailer [19906,19915]
===
match
---
name: is_expired [9923,9933]
name: is_expired [9923,9933]
===
match
---
operator: = [6752,6753]
operator: = [6752,6753]
===
match
---
except_clause [17253,17274]
except_clause [17195,17211]
===
match
---
simple_stmt [1735,1804]
simple_stmt [1735,1804]
===
match
---
name: TI [20130,20132]
name: TI [20089,20091]
===
match
---
name: self [6436,6440]
name: self [6436,6440]
===
match
---
name: sensor_work [21057,21068]
name: sensor_work [21011,21022]
===
match
---
decorated [9613,9727]
decorated [9613,9727]
===
match
---
atom_expr [3132,3154]
atom_expr [3132,3154]
===
match
---
trailer [27745,27771]
trailer [27658,27684]
===
match
---
string: """          :return: If the exception is an infra failure         :type: boolean         """ [9782,9875]
string: """          :return: If the exception is an infra failure         :type: boolean         """ [9782,9875]
===
match
---
atom_expr [16955,16963]
atom_expr [16897,16905]
===
match
---
name: log [15161,15164]
name: log [15103,15106]
===
match
---
operator: * [11477,11478]
operator: * [11477,11478]
===
match
---
name: airflow [1348,1355]
name: airflow [1348,1355]
===
match
---
for_stmt [16748,17214]
for_stmt [16690,17156]
===
match
---
operator: , [1022,1023]
operator: , [1022,1023]
===
match
---
name: duration [30081,30089]
name: duration [29940,29948]
===
match
---
name: _check_and_handle_ti_timeout [23803,23831]
name: _check_and_handle_ti_timeout [23716,23744]
===
match
---
arglist [5254,5346]
arglist [5254,5346]
===
match
---
name: items [27043,27048]
name: items [26956,26961]
===
match
---
simple_stmt [6732,6772]
simple_stmt [6732,6772]
===
match
---
trailer [21119,21126]
trailer [21073,21080]
===
match
---
name: error [22328,22333]
name: error [22241,22246]
===
match
---
name: sensor_work [18949,18960]
name: sensor_work [18908,18919]
===
match
---
simple_stmt [29344,29375]
simple_stmt [29203,29234]
===
match
---
name: airflow [1459,1466]
name: airflow [1459,1466]
===
match
---
name: TaskInstance [19626,19638]
name: TaskInstance [19585,19597]
===
match
---
trailer [23577,23582]
trailer [23490,23495]
===
match
---
name: dag_id [16309,16315]
name: dag_id [16251,16257]
===
match
---
trailer [18757,18768]
trailer [18716,18727]
===
match
---
trailer [23204,23211]
trailer [23117,23124]
===
match
---
expr_stmt [13964,14038]
expr_stmt [13906,13980]
===
match
---
param [23982,23993]
param [23895,23906]
===
match
---
trailer [27518,27524]
trailer [27431,27437]
===
match
---
operator: , [29990,29991]
operator: , [29849,29850]
===
match
---
sync_comp_for [14814,14835]
sync_comp_for [14756,14777]
===
match
---
name: sensor_work [23608,23619]
name: sensor_work [23521,23532]
===
match
---
name: sensor_work [27397,27408]
name: sensor_work [27310,27321]
===
match
---
operator: = [21473,21474]
operator: = [21386,21387]
===
match
---
simple_stmt [18426,18467]
simple_stmt [18435,18476]
===
match
---
name: k [4149,4150]
name: k [4149,4150]
===
match
---
name: sensor_work [19408,19419]
name: sensor_work [19367,19378]
===
match
---
atom [12037,12039]
atom [12037,12039]
===
match
---
trailer [24507,24513]
trailer [24420,24426]
===
match
---
name: poke_start_time [29888,29903]
name: poke_start_time [29747,29762]
===
match
---
name: TaskInstance [16077,16089]
name: TaskInstance [16019,16031]
===
match
---
simple_stmt [12487,12555]
simple_stmt [12487,12555]
===
match
---
name: sensor_work [18893,18904]
name: sensor_work [18852,18863]
===
match
---
simple_stmt [30513,30518]
simple_stmt [30372,30377]
===
match
---
name: State [15946,15951]
name: State [15888,15893]
===
match
---
atom_expr [25191,25204]
atom_expr [25104,25117]
===
match
---
trailer [28879,28942]
trailer [28792,28855]
===
match
---
trailer [3766,3773]
trailer [3766,3773]
===
match
---
name: total_seconds [29905,29918]
name: total_seconds [29764,29777]
===
match
---
expr_stmt [18844,18873]
expr_stmt [18803,18832]
===
match
---
operator: , [19562,19563]
operator: , [19521,19522]
===
match
---
trailer [13832,13836]
trailer [13827,13831]
===
match
---
string: "The poke_interval must be a non-negative number" [12349,12398]
string: "The poke_interval must be a non-negative number" [12349,12398]
===
match
---
arglist [20130,20209]
arglist [20089,20168]
===
match
---
simple_stmt [3008,3040]
simple_stmt [3008,3040]
===
match
---
comparison [20151,20172]
comparison [20110,20131]
===
match
---
trailer [22187,22191]
trailer [22100,22104]
===
match
---
string: """         This function set the latest exception information for sensor exception. If the exception         implies an infra failure, this function will check the recorded infra failure timeout         which was set at the first infra failure exception arrives. There is a 6 hours window         for retry without failing current run.          :param exception_info: Details of the exception information.         :param is_infra_failure: If current exception was caused by transient infra failure.             There is a retry window _infra_failure_retry_window that the smart sensor will             retry poke function without failing current task run.         """ [8030,8698]
string: """         This function set the latest exception information for sensor exception. If the exception         implies an infra failure, this function will check the recorded infra failure timeout         which was set at the first infra failure exception arrives. There is a 6 hours window         for retry without failing current run.          :param exception_info: Details of the exception information.         :param is_infra_failure: If current exception was caused by transient infra failure.             There is a retry window _infra_failure_retry_window that the smart sensor will             retry poke function without failing current task run.         """ [8030,8698]
===
match
---
name: is_infra_failure [7997,8013]
name: is_infra_failure [7997,8013]
===
match
---
name: cached_exception [28477,28493]
name: cached_exception [28390,28406]
===
match
---
atom [27530,27564]
atom [27443,27477]
===
match
---
trailer [16488,16495]
trailer [16430,16437]
===
match
---
name: key [13833,13836]
name: key [13828,13831]
===
match
---
comparison [28289,28334]
comparison [28202,28247]
===
match
---
decorator [15213,15230]
decorator [15155,15172]
===
match
---
operator: + [4964,4965]
operator: + [4964,4965]
===
match
---
name: state [23523,23528]
name: state [23436,23441]
===
match
---
name: exceptions [988,998]
name: exceptions [988,998]
===
match
---
and_test [28477,28548]
and_test [28390,28461]
===
match
---
number: 1 [28593,28594]
number: 1 [28506,28507]
===
match
---
operator: - [30303,30304]
operator: - [30162,30163]
===
match
---
name: self [23050,23054]
name: self [22963,22967]
===
match
---
name: task_timeout [21460,21472]
name: task_timeout [21373,21385]
===
match
---
name: cache_key [26164,26173]
name: cache_key [26077,26086]
===
match
---
atom_expr [19467,19485]
atom_expr [19426,19444]
===
match
---
trailer [15907,15913]
trailer [15849,15855]
===
match
---
arglist [16188,16194]
arglist [16130,16136]
===
match
---
name: operator_class [27673,27687]
name: operator_class [27586,27600]
===
match
---
operator: = [27482,27483]
operator: = [27395,27396]
===
match
---
atom_expr [14709,14860]
atom_expr [14651,14802]
===
match
---
name: error [23263,23268]
name: error [23176,23181]
===
match
---
trailer [30034,30041]
trailer [29893,29900]
===
match
---
name: self [8804,8808]
name: self [8804,8808]
===
match
---
name: pop [25608,25611]
name: pop [25521,25524]
===
match
---
param [11613,11622]
param [11613,11622]
===
match
---
simple_stmt [23562,23629]
simple_stmt [23475,23542]
===
match
---
expr_stmt [21460,21533]
expr_stmt [21373,21446]
===
match
---
testlist_comp [14473,14534]
testlist_comp [14415,14476]
===
match
---
name: k [4210,4211]
name: k [4210,4211]
===
match
---
funcdef [6556,6772]
funcdef [6556,6772]
===
match
---
trailer [28319,28334]
trailer [28232,28247]
===
match
---
suite [20620,20674]
suite [20579,20633]
===
match
---
name: ti [20371,20373]
name: ti [20330,20332]
===
match
---
simple_stmt [15978,16001]
simple_stmt [15920,15943]
===
match
---
name: log [19063,19066]
name: log [19022,19025]
===
match
---
atom [11994,11996]
atom [11994,11996]
===
match
---
operator: @ [17573,17574]
operator: @ [17582,17583]
===
match
---
arglist [17013,17051]
arglist [16955,16993]
===
match
---
name: self [12155,12159]
name: self [12155,12159]
===
match
---
atom_expr [30155,30177]
atom_expr [30014,30036]
===
match
---
name: log [29202,29205]
name: log [29110,29113]
===
match
---
funcdef [12581,14133]
funcdef [12581,14075]
===
match
---
expr_stmt [16908,16935]
expr_stmt [16850,16877]
===
match
---
atom_expr [23905,23945]
atom_expr [23818,23858]
===
match
---
trailer [6769,6771]
trailer [6769,6771]
===
match
---
atom_expr [29384,29397]
atom_expr [29243,29256]
===
match
---
atom_expr [4134,4151]
atom_expr [4134,4151]
===
match
---
name: ti [16955,16957]
name: ti [16897,16899]
===
match
---
operator: , [27541,27542]
operator: , [27454,27455]
===
match
---
operator: } [11995,11996]
operator: } [11995,11996]
===
match
---
name: cached_work [27435,27446]
name: cached_work [27348,27359]
===
match
---
expr_stmt [27472,27565]
expr_stmt [27385,27478]
===
match
---
atom_expr [23296,23377]
atom_expr [23209,23290]
===
match
---
atom_expr [3590,3605]
atom_expr [3590,3605]
===
match
---
name: kwargs [11615,11621]
name: kwargs [11615,11621]
===
match
---
name: execution_date [16415,16429]
name: execution_date [16357,16371]
===
match
---
name: self [20385,20389]
name: self [20344,20348]
===
match
---
name: get [18979,18982]
name: get [18938,18941]
===
match
---
atom_expr [11871,11900]
atom_expr [11871,11900]
===
match
---
name: ti [18844,18846]
name: ti [18803,18805]
===
match
---
and_test [3746,3931]
and_test [3746,3931]
===
match
---
expr_stmt [28150,28165]
expr_stmt [28063,28078]
===
match
---
name: utils [1356,1361]
name: utils [1356,1361]
===
match
---
string: """         Fail task if accumulated exceptions exceeds retries.          :param sensor_work: SensorWork         """ [22014,22130]
string: """         Fail task if accumulated exceptions exceeds retries.          :param sensor_work: SensorWork         """ [21927,22043]
===
match
---
trailer [20101,20105]
trailer [20060,20064]
===
match
---
param [26657,26661]
param [26570,26574]
===
match
---
name: hostname [16911,16919]
name: hostname [16853,16861]
===
match
---
atom_expr [5811,5822]
atom_expr [5811,5822]
===
match
---
trailer [20389,20398]
trailer [20348,20357]
===
match
---
trailer [22282,22286]
trailer [22195,22199]
===
match
---
name: operator [3501,3509]
name: operator [3501,3509]
===
match
---
name: sensor_instance [15833,15848]
name: sensor_instance [15775,15790]
===
match
---
trailer [25015,25227]
trailer [24928,25140]
===
match
---
param [30498,30502]
param [30357,30361]
===
match
---
expr_stmt [27857,27879]
expr_stmt [27770,27792]
===
match
---
operator: == [19823,19825]
operator: == [19782,19784]
===
match
---
operator: , [18215,18216]
operator: , [18224,18225]
===
match
---
name: utcnow [9569,9575]
name: utcnow [9569,9575]
===
match
---
name: error [21827,21832]
name: error [21740,21745]
===
match
---
trailer [30246,30260]
trailer [30105,30119]
===
match
---
name: duration [30305,30313]
name: duration [30164,30172]
===
match
---
trailer [3661,3680]
trailer [3661,3680]
===
match
---
simple_stmt [9437,9516]
simple_stmt [9437,9516]
===
match
---
trailer [5594,5596]
trailer [5594,5596]
===
match
---
operator: , [20930,20931]
operator: , [20889,20890]
===
match
---
trailer [27083,27100]
trailer [26996,27013]
===
match
---
with_item [12870,12892]
with_item [12870,12892]
===
match
---
and_test [18893,19029]
and_test [18852,18988]
===
match
---
trailer [20132,20139]
trailer [20091,20098]
===
match
---
name: set_to_flush [6883,6895]
name: set_to_flush [6883,6895]
===
match
---
atom_expr [26574,26614]
atom_expr [26487,26527]
===
match
---
trailer [7254,7256]
trailer [7254,7256]
===
match
---
name: logger [5373,5379]
name: logger [5373,5379]
===
match
---
operator: += [28590,28592]
operator: += [28503,28505]
===
match
---
name: _emit_loop_stats [27781,27797]
name: _emit_loop_stats [27694,27710]
===
match
---
string: 'execution_timeout' [21601,21620]
string: 'execution_timeout' [21514,21533]
===
match
---
trailer [19971,19980]
trailer [19930,19939]
===
match
---
trailer [16589,16596]
trailer [16531,16538]
===
match
---
string: """     Wrapper class for the poke work inside smart sensor. It saves     the sensor_task used to poke and recent poke result state.     state: poke state.     sensor_task: The cached object for executing the poke function.     last_poke_time: The latest time this cached work being called.     to_flush: If we should flush the cached work.     """ [6054,6402]
string: """     Wrapper class for the poke work inside smart sensor. It saves     the sensor_task used to poke and recent poke result state.     state: poke state.     sensor_task: The cached object for executing the poke function.     last_poke_time: The latest time this cached work being called.     to_flush: If we should flush the cached work.     """ [6054,6402]
===
match
---
name: finished [15952,15960]
name: finished [15894,15902]
===
match
---
name: self [6856,6860]
name: self [6856,6860]
===
match
---
trailer [10129,10136]
trailer [10129,10136]
===
match
---
param [18202,18216]
param [18211,18225]
===
match
---
name: self [12220,12224]
name: self [12220,12224]
===
match
---
atom_expr [4780,4907]
atom_expr [4780,4907]
===
match
---
simple_stmt [20045,20052]
simple_stmt [20004,20011]
===
match
---
atom_expr [1754,1803]
atom_expr [1754,1803]
===
match
---
trailer [25471,25493]
trailer [25384,25406]
===
match
---
operator: , [15831,15832]
operator: , [15773,15774]
===
match
---
atom_expr [11968,11991]
atom_expr [11968,11991]
===
match
---
param [12220,12224]
param [12220,12224]
===
match
---
atom [20070,20284]
atom [20029,20243]
===
match
---
name: sensor_work [27494,27505]
name: sensor_work [27407,27418]
===
match
---
trailer [26601,26614]
trailer [26514,26527]
===
match
---
atom_expr [6995,7008]
atom_expr [6995,7008]
===
match
---
simple_stmt [20737,20755]
simple_stmt [20696,20714]
===
match
---
trailer [5039,5063]
trailer [5039,5063]
===
match
---
name: sensor_work [21934,21945]
name: sensor_work [21847,21858]
===
match
---
operator: , [25204,25205]
operator: , [25117,25118]
===
match
---
expr_stmt [2894,2917]
expr_stmt [2894,2917]
===
match
---
atom_expr [26100,26147]
atom_expr [26013,26060]
===
match
---
comparison [16341,16365]
comparison [16283,16307]
===
match
---
name: task_id [20154,20161]
name: task_id [20113,20120]
===
match
---
name: self [21222,21226]
name: self [21135,21139]
===
match
---
operator: , [16429,16430]
operator: , [16371,16372]
===
match
---
name: cached_dedup_works [26872,26890]
name: cached_dedup_works [26785,26803]
===
match
---
name: Exception [25644,25653]
name: Exception [25557,25566]
===
match
---
name: airflow [1552,1559]
name: airflow [1552,1559]
===
match
---
name: is_expired [27121,27131]
name: is_expired [27034,27044]
===
match
---
atom_expr [15004,15016]
atom_expr [14946,14958]
===
match
---
atom_expr [29804,29842]
atom_expr [29663,29701]
===
match
---
trailer [2984,2999]
trailer [2984,2999]
===
match
---
number: 1 [28164,28165]
number: 1 [28077,28078]
===
match
---
simple_stmt [28150,28166]
simple_stmt [28063,28079]
===
match
---
name: state [26952,26957]
name: state [26865,26870]
===
match
---
atom_expr [19719,19901]
atom_expr [19678,19860]
===
match
---
string: """Key for the task instance that maps to the sensor work.""" [5734,5795]
string: """Key for the task instance that maps to the sensor work.""" [5734,5795]
===
match
---
name: log [29939,29942]
name: log [29798,29801]
===
match
---
name: join [16213,16217]
name: join [16155,16159]
===
match
---
name: sensor_work [23296,23307]
name: sensor_work [23209,23220]
===
match
---
operator: , [25970,25971]
operator: , [25883,25884]
===
match
---
trailer [25196,25204]
trailer [25109,25117]
===
match
---
funcdef [7950,8900]
funcdef [7950,8900]
===
match
---
simple_stmt [27970,27994]
simple_stmt [27883,27907]
===
match
---
name: ti_key [22559,22565]
name: ti_key [22472,22478]
===
match
---
simple_stmt [15156,15208]
simple_stmt [15098,15150]
===
match
---
string: 'formatters' [1761,1773]
string: 'formatters' [1761,1773]
===
match
---
name: SI [16547,16549]
name: SI [16489,16491]
===
match
---
testlist_comp [12274,12284]
testlist_comp [12274,12284]
===
match
---
name: soft_fail [11809,11818]
name: soft_fail [11809,11818]
===
match
---
name: cached_exception [28614,28630]
name: cached_exception [28527,28543]
===
match
---
atom_expr [7735,7767]
atom_expr [7735,7767]
===
match
---
trailer [20487,20493]
trailer [20446,20452]
===
match
---
atom_expr [10171,10201]
atom_expr [10171,10201]
===
match
---
name: self [3746,3750]
name: self [3746,3750]
===
match
---
name: all [14855,14858]
name: all [14797,14800]
===
match
---
trailer [3195,3213]
trailer [3195,3213]
===
match
---
trailer [23311,23316]
trailer [23224,23229]
===
match
---
expr_stmt [1735,1803]
expr_stmt [1735,1803]
===
match
---
trailer [6736,6751]
trailer [6736,6751]
===
match
---
name: self [17618,17622]
name: self [17627,17631]
===
match
---
simple_stmt [12120,12147]
simple_stmt [12120,12147]
===
match
---
name: log [18631,18634]
name: log [18566,18569]
===
match
---
operator: = [10197,10198]
operator: = [10197,10198]
===
match
---
operator: , [5998,5999]
operator: , [5998,5999]
===
match
---
suite [12893,13132]
suite [12893,13132]
===
match
---
trailer [7739,7767]
trailer [7739,7767]
===
match
---
atom_expr [7639,7659]
atom_expr [7639,7659]
===
match
---
simple_stmt [7735,7797]
simple_stmt [7735,7797]
===
match
---
arglist [21934,21952]
arglist [21847,21865]
===
match
---
param [7981,7996]
param [7981,7996]
===
match
---
suite [6427,6551]
suite [6427,6551]
===
match
---
atom_expr [13764,13837]
atom_expr [13759,13832]
===
match
---
name: max_tries [18793,18802]
name: max_tries [18752,18761]
===
match
---
trailer [5379,5384]
trailer [5379,5384]
===
match
---
trailer [26121,26147]
trailer [26034,26060]
===
match
---
expr_stmt [4916,4973]
expr_stmt [4916,4973]
===
match
---
operator: = [1882,1883]
operator: = [1882,1883]
===
match
---
operator: == [23864,23866]
operator: == [23777,23779]
===
match
---
simple_stmt [1343,1399]
simple_stmt [1343,1399]
===
match
---
atom_expr [20737,20754]
atom_expr [20696,20713]
===
match
---
name: encoded_poke_context [25145,25165]
name: encoded_poke_context [25058,25078]
===
match
---
atom_expr [13040,13054]
atom_expr [13040,13054]
===
match
---
simple_stmt [15863,15880]
simple_stmt [15805,15822]
===
match
---
name: isinstance [3651,3661]
name: isinstance [3651,3661]
===
match
---
atom_expr [15034,15125]
atom_expr [14976,15067]
===
match
---
expr_stmt [29344,29374]
expr_stmt [29203,29233]
===
match
---
simple_stmt [1172,1204]
simple_stmt [1172,1204]
===
match
---
name: cached_exception [28398,28414]
name: cached_exception [28311,28327]
===
match
---
parameters [29319,29334]
parameters [29178,29193]
===
match
---
trailer [7609,7622]
trailer [7609,7622]
===
match
---
atom_expr [20641,20662]
atom_expr [20600,20621]
===
match
---
trailer [17234,17241]
trailer [17176,17183]
===
match
---
name: minutes [7610,7617]
name: minutes [7610,7617]
===
match
---
name: timeout [24748,24755]
name: timeout [24661,24668]
===
match
---
suite [6049,7264]
suite [6049,7264]
===
match
---
name: timezone [20543,20551]
name: timezone [20502,20510]
===
match
---
name: count_poke_exception [27892,27912]
name: count_poke_exception [27805,27825]
===
match
---
except_clause [18479,18500]
except_clause [18488,18504]
===
match
---
name: traceback [839,848]
name: traceback [839,848]
===
match
---
name: sensor_works [13571,13583]
name: sensor_works [13571,13583]
===
match
---
trailer [20501,20508]
trailer [20460,20467]
===
match
---
or_test [7182,7263]
or_test [7182,7263]
===
match
---
name: init_args [27472,27481]
name: init_args [27385,27394]
===
match
---
trailer [29600,29650]
trailer [29459,29509]
===
match
---
trailer [21913,21933]
trailer [21826,21846]
===
match
---
simple_stmt [832,849]
simple_stmt [832,849]
===
match
---
operator: == [16505,16507]
operator: == [16447,16449]
===
match
---
trailer [12089,12099]
trailer [12089,12099]
===
match
---
trailer [4932,4942]
trailer [4932,4942]
===
match
---
name: hashcode [25099,25107]
name: hashcode [25012,25020]
===
match
---
for_stmt [26974,27199]
for_stmt [26887,27112]
===
match
---
name: state [19208,19213]
name: state [19167,19172]
===
match
---
name: close_sensor_logger [23653,23672]
name: close_sensor_logger [23566,23585]
===
match
---
comparison [3790,3819]
comparison [3790,3819]
===
match
---
trailer [19753,19760]
trailer [19712,19719]
===
match
---
atom_expr [2982,2999]
atom_expr [2982,2999]
===
match
---
operator: , [23602,23603]
operator: , [23515,23516]
===
match
---
name: operator [15262,15270]
name: operator [15204,15212]
===
match
---
decorated [9732,9914]
decorated [9732,9914]
===
match
---
trailer [28960,28966]
trailer [28873,28879]
===
match
---
simple_stmt [11749,11784]
simple_stmt [11749,11784]
===
match
---
arglist [19072,19126]
arglist [19031,19085]
===
match
---
string: """     Hold sensor exception information and the type of exception. For possible transient     infra failure, give the task more chance to retry before fail it.     """ [7297,7466]
string: """     Hold sensor exception information and the type of exception. For possible transient     infra failure, give the task more chance to retry before fail it.     """ [7297,7466]
===
match
---
suite [21814,21954]
suite [21727,21867]
===
match
---
atom_expr [12332,12399]
atom_expr [12332,12399]
===
match
---
name: self [15256,15260]
name: self [15198,15202]
===
match
---
trailer [16926,16935]
trailer [16868,16877]
===
match
---
atom_expr [23193,23211]
atom_expr [23106,23124]
===
match
---
atom_expr [27006,27050]
atom_expr [26919,26963]
===
match
---
expr_stmt [27970,27993]
expr_stmt [27883,27906]
===
match
---
operator: , [29980,29981]
operator: , [29839,29840]
===
match
---
trailer [16654,16656]
trailer [16596,16598]
===
match
---
param [29320,29325]
param [29179,29184]
===
match
---
atom_expr [3518,3535]
atom_expr [3518,3535]
===
match
---
atom_expr [27489,27527]
atom_expr [27402,27440]
===
match
---
name: get [21597,21600]
name: get [21510,21513]
===
match
---
operator: , [16241,16242]
operator: , [16183,16184]
===
match
---
name: sensor_work [26602,26613]
name: sensor_work [26515,26526]
===
match
---
name: ti_key [24025,24031]
name: ti_key [23938,23944]
===
match
---
number: 30 [10198,10200]
number: 30 [10198,10200]
===
match
---
for_stmt [26746,26965]
for_stmt [26659,26878]
===
match
---
trailer [12976,12982]
trailer [12976,12982]
===
match
---
operator: , [30079,30080]
operator: , [29938,29939]
===
match
---
param [5891,5895]
param [5891,5895]
===
match
---
name: _check_and_handle_ti_timeout [23395,23423]
name: _check_and_handle_ti_timeout [23308,23336]
===
match
---
name: handlers [5538,5546]
name: handlers [5538,5546]
===
match
---
operator: , [26898,26899]
operator: , [26811,26812]
===
match
---
atom_expr [24109,24120]
atom_expr [24022,24033]
===
match
---
suite [18533,18663]
suite [18537,18622]
===
match
---
atom_expr [19051,19127]
atom_expr [19010,19086]
===
match
---
simple_stmt [789,805]
simple_stmt [789,805]
===
match
---
trailer [24423,24425]
trailer [24336,24338]
===
match
---
trailer [21003,21005]
trailer [20962,20964]
===
match
---
name: ti_keys [14462,14469]
name: ti_keys [14404,14411]
===
match
---
trailer [29553,29572]
trailer [29412,29431]
===
match
---
string: "-" [4780,4783]
string: "-" [4780,4783]
===
match
---
operator: = [9334,9335]
operator: = [9334,9335]
===
match
---
name: cached_sensor_exceptions [22163,22187]
name: cached_sensor_exceptions [22076,22100]
===
match
---
arglist [13025,13086]
arglist [13025,13086]
===
match
---
expr_stmt [24004,24031]
expr_stmt [23917,23944]
===
match
---
operator: += [28694,28696]
operator: += [28607,28609]
===
match
---
trailer [30339,30346]
trailer [30198,30205]
===
match
---
atom_expr [27609,27633]
atom_expr [27522,27546]
===
match
---
atom_expr [13056,13068]
atom_expr [13056,13068]
===
match
---
trailer [18436,18466]
trailer [18445,18475]
===
match
---
parameters [8934,8940]
parameters [8934,8940]
===
match
---
atom_expr [29769,29786]
atom_expr [29628,29645]
===
match
---
name: logger [5189,5195]
name: logger [5189,5195]
===
match
---
name: exc_info [17450,17458]
name: exc_info [17445,17453]
===
match
---
trailer [28790,28796]
trailer [28703,28709]
===
match
---
funcdef [26620,27199]
funcdef [26533,27112]
===
match
---
param [27219,27230]
param [27132,27143]
===
match
---
operator: , [14783,14784]
operator: , [14725,14726]
===
match
---
simple_stmt [17002,17053]
simple_stmt [16944,16995]
===
match
---
operator: == [16409,16411]
operator: == [16351,16353]
===
match
---
arglist [13155,13219]
arglist [13155,13219]
===
match
---
or_test [24046,24073]
or_test [23959,23986]
===
match
---
param [11453,11491]
param [11453,11491]
===
match
---
name: exception [13773,13782]
name: exception [13768,13777]
===
match
---
name: Stats [1198,1203]
name: Stats [1198,1203]
===
match
---
name: airflow [1048,1055]
name: airflow [1048,1055]
===
match
---
name: self [14020,14024]
name: self [13962,13966]
===
match
---
name: session [12932,12939]
name: session [12932,12939]
===
match
---
trailer [9261,9284]
trailer [9261,9284]
===
match
---
name: count_infra_failure [28570,28589]
name: count_infra_failure [28483,28502]
===
match
---
simple_stmt [14959,14976]
simple_stmt [14901,14918]
===
match
---
string: "Performance query %s tis, time: %.3f" [13155,13193]
string: "Performance query %s tis, time: %.3f" [13155,13193]
===
match
---
name: log [5534,5537]
name: log [5534,5537]
===
match
---
string: 'formatter' [1790,1801]
string: 'formatter' [1790,1801]
===
match
---
name: sensor_work [27543,27554]
name: sensor_work [27456,27467]
===
match
---
trailer [19355,19373]
trailer [19314,19332]
===
match
---
param [15272,15282]
param [15214,15224]
===
match
---
operator: , [26984,26985]
operator: , [26897,26898]
===
match
---
expr_stmt [3361,3376]
expr_stmt [3361,3376]
===
match
---
name: self [7849,7853]
name: self [7849,7853]
===
match
---
trailer [23054,23073]
trailer [22967,22986]
===
match
---
name: self [9535,9539]
name: self [9535,9539]
===
match
---
trailer [29674,29736]
trailer [29533,29595]
===
match
---
name: filter [12967,12973]
name: filter [12967,12973]
===
match
---
for_stmt [29750,29843]
for_stmt [29609,29702]
===
match
---
trailer [14475,14482]
trailer [14417,14424]
===
match
---
trailer [24997,25015]
trailer [24910,24928]
===
match
---
name: PokeState [24954,24963]
name: PokeState [24867,24876]
===
match
---
suite [19188,19530]
suite [19147,19489]
===
match
---
name: _infra_failure_timeout [9585,9607]
name: _infra_failure_timeout [9585,9607]
===
match
---
atom_expr [6436,6446]
atom_expr [6436,6446]
===
match
---
name: timezone [6754,6762]
name: timezone [6754,6762]
===
match
---
name: exception_info [7662,7676]
name: exception_info [7662,7676]
===
match
---
operator: @ [9613,9614]
operator: @ [9613,9614]
===
match
---
operator: , [18442,18443]
operator: , [18451,18452]
===
match
---
trailer [12973,13000]
trailer [12973,13000]
===
match
---
operator: = [26063,26064]
operator: = [25976,25977]
===
match
---
expr_stmt [11968,11996]
expr_stmt [11968,11996]
===
match
---
trailer [26793,26798]
trailer [26706,26711]
===
match
---
simple_stmt [20641,20674]
simple_stmt [20600,20633]
===
match
---
name: TI [20174,20176]
name: TI [20133,20135]
===
match
---
name: poke [27208,27212]
name: poke [27121,27125]
===
match
---
name: sensor_works [29636,29648]
name: sensor_works [29495,29507]
===
match
---
trailer [30415,30419]
trailer [30274,30278]
===
match
---
atom [3121,3123]
atom [3121,3123]
===
match
---
name: sensor_work [24046,24057]
name: sensor_work [23959,23970]
===
match
---
atom_expr [13645,13680]
atom_expr [13645,13680]
===
match
---
name: DictConfigurator [1923,1939]
name: DictConfigurator [1923,1939]
===
match
---
operator: = [16047,16048]
operator: = [15989,15990]
===
match
---
name: timedelta [7600,7609]
name: timedelta [7600,7609]
===
match
---
trailer [15169,15207]
trailer [15111,15149]
===
match
---
trailer [5200,5212]
trailer [5200,5212]
===
match
---
name: operator_class [27578,27592]
name: operator_class [27491,27505]
===
match
---
suite [29184,29303]
suite [29092,29162]
===
match
---
expr_stmt [8845,8899]
expr_stmt [8845,8899]
===
match
---
atom_expr [13936,13953]
atom_expr [13878,13895]
===
match
---
expr_stmt [25942,26035]
expr_stmt [25855,25948]
===
match
---
name: utils [1510,1515]
name: utils [1510,1515]
===
match
---
expr_stmt [11827,11862]
expr_stmt [11827,11862]
===
match
---
atom_expr [12493,12554]
atom_expr [12493,12554]
===
match
---
param [15262,15271]
param [15204,15213]
===
match
---
decorated [15213,17568]
decorated [15155,17577]
===
match
---
operator: == [16964,16966]
operator: == [16906,16908]
===
match
---
param [4505,4510]
param [4505,4510]
===
match
---
param [11572,11589]
param [11572,11589]
===
match
---
trailer [28873,28879]
trailer [28786,28792]
===
match
---
atom_expr [17400,17414]
atom_expr [17370,17384]
===
match
---
suite [13628,13681]
suite [13628,13681]
===
match
---
simple_stmt [10114,10202]
simple_stmt [10114,10202]
===
match
---
for_stmt [28006,28382]
for_stmt [27919,28295]
===
match
---
funcdef [15234,17568]
funcdef [15176,17577]
===
match
---
name: self [6570,6574]
name: self [6570,6574]
===
match
---
import_name [817,831]
import_name [817,831]
===
match
---
operator: = [26958,26959]
operator: = [26871,26872]
===
match
---
name: cached_work [28185,28196]
name: cached_work [28098,28109]
===
match
---
parameters [15255,15325]
parameters [15197,15267]
===
match
---
trailer [9344,9351]
trailer [9344,9351]
===
match
---
trailer [14024,14037]
trailer [13966,13979]
===
match
---
name: sensor_work [17624,17635]
name: sensor_work [17633,17644]
===
match
---
name: stats [1185,1190]
name: stats [1185,1190]
===
match
---
trailer [4884,4895]
trailer [4884,4895]
===
match
---
name: e [5686,5687]
name: e [5686,5687]
===
match
---
name: ti_key [5324,5330]
name: ti_key [5324,5330]
===
match
---
atom_expr [28310,28334]
atom_expr [28223,28247]
===
match
---
trailer [23149,23159]
trailer [23062,23072]
===
match
---
atom_expr [4925,4973]
atom_expr [4925,4973]
===
match
---
name: self [6494,6498]
name: self [6494,6498]
===
match
---
atom_expr [25578,25628]
atom_expr [25491,25541]
===
match
---
simple_stmt [1248,1300]
simple_stmt [1248,1300]
===
match
---
simple_stmt [5154,5177]
simple_stmt [5154,5177]
===
match
---
exprlist [26978,27002]
exprlist [26891,26915]
===
match
---
name: dag_id [5816,5822]
name: dag_id [5816,5822]
===
match
---
operator: = [11439,11440]
operator: = [11439,11440]
===
match
---
string: "%s sending email alert for failure" [19429,19465]
string: "%s sending email alert for failure" [19388,19424]
===
match
---
parameters [3621,3634]
parameters [3621,3634]
===
match
---
name: timezone [10121,10129]
name: timezone [10121,10129]
===
match
---
operator: , [15281,15282]
operator: , [15223,15224]
===
match
---
name: minutes [10190,10197]
name: minutes [10190,10197]
===
match
---
suite [23549,23675]
suite [23462,23588]
===
match
---
name: time [914,918]
name: time [914,918]
===
match
---
arglist [24139,24200]
arglist [24052,24113]
===
match
---
name: poke_interval [30247,30260]
name: poke_interval [30106,30119]
===
match
---
atom_expr [29587,29650]
atom_expr [29446,29509]
===
match
---
name: self [3406,3410]
name: self [3406,3410]
===
match
---
name: self [16922,16926]
name: self [16864,16868]
===
match
---
name: filter [13018,13024]
name: filter [13018,13024]
===
match
---
operator: = [18364,18365]
operator: = [18373,18374]
===
match
---
trailer [19373,19377]
trailer [19332,19336]
===
match
---
name: utcnow [29877,29883]
name: utcnow [29736,29742]
===
match
---
trailer [7240,7254]
trailer [7240,7254]
===
match
---
name: session [14959,14966]
name: session [14901,14908]
===
match
---
trailer [27035,27040]
trailer [26948,26953]
===
match
---
param [6896,6900]
param [6896,6900]
===
match
---
testlist_comp [13984,14037]
testlist_comp [13926,13979]
===
match
---
suite [15326,17568]
suite [15268,17577]
===
match
---
trailer [3794,3802]
trailer [3794,3802]
===
match
---
name: total_seconds [21783,21796]
name: total_seconds [21696,21709]
===
match
---
operator: = [1921,1922]
operator: = [1921,1922]
===
match
---
atom_expr [19590,19608]
atom_expr [19549,19567]
===
match
---
atom_expr [21739,21756]
atom_expr [21652,21669]
===
match
---
operator: = [20068,20069]
operator: = [20027,20028]
===
match
---
if_stmt [28474,28595]
if_stmt [28387,28508]
===
match
---
name: formatter_config [1735,1751]
name: formatter_config [1735,1751]
===
match
---
trailer [19277,19281]
trailer [19236,19240]
===
match
---
return_stmt [9524,9607]
return_stmt [9524,9607]
===
match
---
parameters [7035,7041]
parameters [7035,7041]
===
match
---
name: AirflowTaskTimeout [26016,26034]
name: AirflowTaskTimeout [25929,25947]
===
match
---
atom_expr [20907,20930]
atom_expr [20866,20889]
===
match
---
trailer [21875,21879]
trailer [21788,21792]
===
match
---
atom_expr [24273,24296]
atom_expr [24186,24209]
===
match
---
name: sensor_work [21228,21239]
name: sensor_work [21141,21152]
===
match
---
name: _infra_failure_timeout [9311,9333]
name: _infra_failure_timeout [9311,9333]
===
match
---
operator: , [3626,3627]
operator: , [3626,3627]
===
match
---
operator: , [15100,15101]
operator: , [15042,15043]
===
match
---
name: cached_dedup_works [23055,23073]
name: cached_dedup_works [22968,22986]
===
match
---
name: execution_date [14788,14802]
name: execution_date [14730,14744]
===
match
---
expr_stmt [19683,19915]
expr_stmt [19642,19874]
===
match
---
name: execution_context [19260,19277]
name: execution_context [19219,19236]
===
match
---
expr_stmt [26048,26087]
expr_stmt [25961,26000]
===
match
---
name: is_infra_failure [28494,28510]
name: is_infra_failure [28407,28423]
===
match
---
name: log [23574,23577]
name: log [23487,23490]
===
match
---
suite [14217,15208]
suite [14159,15150]
===
match
---
name: self [9891,9895]
name: self [9891,9895]
===
match
---
operator: ** [11613,11615]
operator: ** [11613,11615]
===
match
---
expr_stmt [22139,22214]
expr_stmt [22052,22127]
===
match
---
operator: , [21167,21168]
operator: , [21080,21081]
===
match
---
suite [3348,3398]
suite [3348,3398]
===
match
---
trailer [3540,3553]
trailer [3540,3553]
===
match
---
name: soft_fail [11797,11806]
name: soft_fail [11797,11806]
===
match
---
simple_stmt [7890,7945]
simple_stmt [7890,7945]
===
match
---
simple_stmt [29663,29737]
simple_stmt [29522,29596]
===
match
---
funcdef [18186,18663]
funcdef [18195,18622]
===
match
---
name: sensor_work [18691,18702]
name: sensor_work [18650,18661]
===
match
---
name: len [29992,29995]
name: len [29851,29854]
===
match
---
name: exc_info [21169,21177]
name: exc_info [21082,21090]
===
match
---
name: PokeState [28310,28319]
name: PokeState [28223,28232]
===
match
---
atom_expr [27543,27562]
atom_expr [27456,27475]
===
match
---
operator: = [5033,5034]
operator: = [5033,5034]
===
match
---
trailer [13154,13220]
trailer [13154,13220]
===
match
---
name: self [8707,8711]
name: self [8707,8711]
===
match
---
name: exception_info [26493,26507]
name: exception_info [26406,26420]
===
match
---
trailer [24690,24696]
trailer [24603,24609]
===
match
---
simple_stmt [5581,5597]
simple_stmt [5581,5597]
===
match
---
trailer [25518,25547]
trailer [25431,25460]
===
match
---
name: state [17561,17566]
name: state [17570,17575]
===
match
---
operator: = [7617,7618]
operator: = [7617,7618]
===
match
---
string: "smart_sensor_operator.infra_failures" [29061,29099]
string: "smart_sensor_operator.infra_failures" [28974,29012]
===
match
---
trailer [7853,7879]
trailer [7853,7879]
===
match
---
simple_stmt [18844,18874]
simple_stmt [18803,18833]
===
match
---
name: apply_defaults [1285,1299]
name: apply_defaults [1285,1299]
===
match
---
operator: , [12277,12278]
operator: , [12277,12278]
===
match
---
trailer [26253,26264]
trailer [26166,26177]
===
match
---
operator: = [29463,29464]
operator: = [29322,29323]
===
match
---
name: poke_interval [11426,11439]
name: poke_interval [11426,11439]
===
match
---
name: self [30191,30195]
name: self [30050,30054]
===
match
---
trailer [18630,18634]
trailer [18565,18569]
===
match
---
except_clause [21015,21043]
except_clause [20974,20997]
===
match
---
name: self [24449,24453]
name: self [24362,24366]
===
match
---
trailer [25282,25290]
trailer [25195,25203]
===
match
---
return_stmt [27710,27771]
return_stmt [27623,27684]
===
match
---
number: 7 [11489,11490]
number: 7 [11489,11490]
===
match
---
expr_stmt [19651,19670]
expr_stmt [19610,19629]
===
match
---
suite [23117,23213]
suite [23030,23126]
===
match
---
expr_stmt [16141,16693]
expr_stmt [16083,16635]
===
match
---
operator: += [28161,28163]
operator: += [28074,28076]
===
match
---
trailer [29829,29842]
trailer [29688,29701]
===
match
---
operator: = [3256,3257]
operator: = [3256,3257]
===
match
---
name: log [3366,3369]
name: log [3366,3369]
===
match
---
operator: = [11555,11556]
operator: = [11555,11556]
===
match
---
operator: , [1098,1099]
operator: , [1098,1099]
===
match
---
suite [21241,21954]
suite [21154,21867]
===
match
---
atom_expr [27717,27771]
atom_expr [27630,27684]
===
match
---
trailer [9213,9236]
trailer [9213,9236]
===
match
---
name: task_timeout [21801,21813]
name: task_timeout [21714,21726]
===
match
---
name: ti_key [23205,23211]
name: ti_key [23118,23124]
===
match
---
if_stmt [26161,26561]
if_stmt [26074,26474]
===
match
---
name: self [24993,24997]
name: self [24906,24910]
===
match
---
arglist [28797,28854]
arglist [28710,28767]
===
match
---
operator: != [16837,16839]
operator: != [16779,16781]
===
match
---
parameters [23484,23510]
parameters [23397,23423]
===
match
---
operator: == [3856,3858]
operator: == [3856,3858]
===
match
---
name: cached_dedup_works [24278,24296]
name: cached_dedup_works [24191,24209]
===
match
---
trailer [25481,25492]
trailer [25394,25405]
===
match
---
name: timedelta [10180,10189]
name: timedelta [10180,10189]
===
match
---
trailer [2898,2905]
trailer [2898,2905]
===
match
---
simple_stmt [26940,26965]
simple_stmt [26853,26878]
===
match
---
name: sensor_work [21567,21578]
name: sensor_work [21480,21491]
===
match
---
atom_expr [21909,21953]
atom_expr [21822,21866]
===
match
---
name: CachedPokeWork [24409,24423]
name: CachedPokeWork [24322,24336]
===
match
---
atom_expr [24449,24483]
atom_expr [24362,24396]
===
match
---
name: query [12940,12945]
name: query [12940,12945]
===
match
---
if_stmt [12235,12400]
if_stmt [12235,12400]
===
match
---
simple_stmt [7849,7882]
simple_stmt [7849,7882]
===
match
---
operator: == [3912,3914]
operator: == [3912,3914]
===
match
---
simple_stmt [11792,11819]
simple_stmt [11792,11819]
===
match
---
atom_expr [20805,20955]
atom_expr [20764,20914]
===
match
---
suite [12313,12400]
suite [12313,12400]
===
match
---
trailer [4852,4876]
trailer [4852,4876]
===
match
---
atom_expr [4278,4333]
atom_expr [4278,4333]
===
match
---
for_stmt [5514,5689]
for_stmt [5514,5689]
===
match
---
trailer [18395,18399]
trailer [18404,18408]
===
match
---
operator: = [19214,19215]
operator: = [19173,19174]
===
match
---
name: SI [16355,16357]
name: SI [16297,16299]
===
match
---
name: Stats [29663,29668]
name: Stats [29522,29527]
===
match
---
atom_expr [14474,14482]
atom_expr [14416,14424]
===
match
---
name: log [3252,3255]
name: log [3252,3255]
===
match
---
atom_expr [28614,28647]
atom_expr [28527,28560]
===
match
---
name: self [27151,27155]
name: self [27064,27068]
===
match
---
trailer [4828,4843]
trailer [4828,4843]
===
match
---
if_stmt [28182,28382]
if_stmt [28095,28295]
===
match
---
suite [3995,4477]
suite [3995,4477]
===
match
---
suite [7292,10202]
suite [7292,10202]
===
match
---
trailer [27493,27527]
trailer [27406,27440]
===
match
---
name: exception [29206,29215]
name: exception [29114,29123]
===
match
---
operator: @ [15213,15214]
operator: @ [15155,15156]
===
match
---
name: count_poke [28761,28771]
name: count_poke [28674,28684]
===
match
---
atom_expr [30242,30260]
atom_expr [30101,30119]
===
match
---
simple_stmt [3247,3286]
simple_stmt [3247,3286]
===
match
---
number: 0 [12311,12312]
number: 0 [12311,12312]
===
match
---
expr_stmt [21669,21725]
expr_stmt [21582,21638]
===
match
---
trailer [3251,3255]
trailer [3251,3255]
===
match
---
name: ti_key [19602,19608]
name: ti_key [19561,19567]
===
match
---
number: 0 [27915,27916]
number: 0 [27828,27829]
===
match
---
name: addHandler [5085,5095]
name: addHandler [5085,5095]
===
match
---
trailer [3161,3167]
trailer [3161,3167]
===
match
---
suite [20350,20599]
suite [20309,20558]
===
match
---
operator: = [11840,11841]
operator: = [11840,11841]
===
match
---
atom_expr [30029,30090]
atom_expr [29888,29949]
===
match
---
name: shard_min [11525,11534]
name: shard_min [11525,11534]
===
match
---
name: count_poke_success [28836,28854]
name: count_poke_success [28749,28767]
===
match
---
param [11546,11563]
param [11546,11563]
===
match
---
name: log [23308,23311]
name: log [23221,23224]
===
match
---
trailer [25098,25107]
trailer [25011,25020]
===
match
---
name: timeout [21525,21532]
name: timeout [21438,21445]
===
match
---
number: 0 [16114,16115]
number: 0 [16056,16057]
===
match
---
if_stmt [19929,20052]
if_stmt [19888,20011]
===
match
---
operator: , [26507,26508]
operator: , [26420,26421]
===
match
---
arglist [29061,29120]
arglist [28974,29033]
===
match
---
trailer [24943,24953]
trailer [24856,24866]
===
match
---
name: cached_sensor_exceptions [26414,26438]
name: cached_sensor_exceptions [26327,26351]
===
match
---
name: poke_context [3054,3066]
name: poke_context [3054,3066]
===
match
---
name: dag_id [19774,19780]
name: dag_id [19733,19739]
===
match
---
expr_stmt [4268,4333]
expr_stmt [4268,4333]
===
match
---
simple_stmt [29934,30016]
simple_stmt [29793,29875]
===
match
---
suite [11629,12188]
suite [11629,12188]
===
match
---
name: Exception [18486,18495]
name: Exception [18495,18504]
===
match
---
operator: , [19162,19163]
operator: , [19121,19122]
===
match
---
name: self [8753,8757]
name: self [8753,8757]
===
match
---
trailer [30195,30212]
trailer [30054,30071]
===
match
---
trailer [7689,7707]
trailer [7689,7707]
===
match
---
name: count [15026,15031]
name: count [14968,14973]
===
match
---
trailer [19899,19901]
trailer [19858,19860]
===
match
---
simple_stmt [28669,28699]
simple_stmt [28582,28612]
===
match
---
atom_expr [22271,22334]
atom_expr [22184,22247]
===
match
---
name: self [11937,11941]
name: self [11937,11941]
===
match
---
operator: = [11955,11956]
operator: = [11955,11956]
===
match
---
simple_stmt [9661,9691]
simple_stmt [9661,9691]
===
match
---
operator: , [22326,22327]
operator: , [22239,22240]
===
match
---
atom_expr [3193,3213]
atom_expr [3193,3213]
===
match
---
name: x [14495,14496]
name: x [14437,14438]
===
match
---
atom_expr [29868,29885]
atom_expr [29727,29744]
===
match
---
name: formatter_config [4213,4229]
name: formatter_config [4213,4229]
===
match
---
comparison [12457,12473]
comparison [12457,12473]
===
match
---
import_from [1124,1171]
import_from [1124,1171]
===
match
---
name: started_at [29344,29354]
name: started_at [29203,29213]
===
match
---
simple_stmt [27578,27635]
simple_stmt [27491,27548]
===
match
---
decorator [3947,3961]
decorator [3947,3961]
===
match
---
atom_expr [4213,4232]
atom_expr [4213,4232]
===
match
---
operator: = [7912,7913]
operator: = [7912,7913]
===
match
---
trailer [13913,13954]
trailer [13855,13896]
===
match
---
name: _load_sensor_works [12585,12603]
name: _load_sensor_works [12585,12603]
===
match
---
name: session [12610,12617]
name: session [12610,12617]
===
match
---
name: ti [20529,20531]
name: ti [20488,20490]
===
match
---
expr_stmt [6705,6723]
expr_stmt [6705,6723]
===
match
---
trailer [19807,19822]
trailer [19766,19781]
===
match
---
atom [4802,4897]
atom [4802,4897]
===
match
---
simple_stmt [16017,16035]
simple_stmt [15959,15977]
===
match
---
atom_expr [14100,14117]
atom_expr [14042,14059]
===
match
---
atom_expr [16355,16365]
atom_expr [16297,16307]
===
match
---
name: utils [1412,1417]
name: utils [1412,1417]
===
match
---
string: """         Change single task state for sensor task. For final state, set the end_date.         Since smart sensor take care all retries in one process. Failed sensor tasks         logically experienced all retries and the try_number should be set to max_tries.          :param sensor_work: The sensor_work with exception.         :type sensor_work: SensorWork         :param error: The error message for this sensor_work.         :type error: str.         :param session: The sqlalchemy session.         """ [17667,18176]
string: """         Change single task state for sensor task. For final state, set the end_date.         Since smart sensor take care all retries in one process. Failed sensor tasks         logically experienced all retries and the try_number should be set to max_tries.          :param sensor_work: The sensor_work with exception.         :type sensor_work: SensorWork         :param error: The error message for this sensor_work.         :type error: str.         :param session: The sqlalchemy session.         """ [17676,18185]
===
match
---
name: info [5380,5384]
name: info [5380,5384]
===
match
---
param [3622,3627]
param [3622,3627]
===
match
---
param [15829,15832]
param [15771,15774]
===
match
---
atom [14472,14535]
atom [14414,14477]
===
match
---
trailer [6762,6769]
trailer [6762,6769]
===
match
---
expr_stmt [2960,2999]
expr_stmt [2960,2999]
===
match
---
name: state [20488,20493]
name: state [20447,20452]
===
match
---
name: AirflowException [12332,12348]
name: AirflowException [12332,12348]
===
match
---
atom_expr [16718,16735]
atom_expr [16660,16677]
===
match
---
trailer [5236,5360]
trailer [5236,5360]
===
match
---
funcdef [18672,19530]
funcdef [18631,19489]
===
match
---
name: self [9173,9177]
name: self [9173,9177]
===
match
---
parameters [12219,12225]
parameters [12219,12225]
===
match
---
atom_expr [23012,23033]
atom_expr [22925,22946]
===
match
---
trailer [3028,3039]
trailer [3028,3039]
===
match
---
name: cache_key [27409,27418]
name: cache_key [27322,27331]
===
match
---
atom_expr [12049,12071]
atom_expr [12049,12071]
===
match
---
name: self [24372,24376]
name: self [24285,24289]
===
match
---
name: cached_work [26940,26951]
name: cached_work [26853,26864]
===
match
---
atom_expr [8707,8727]
atom_expr [8707,8727]
===
match
---
name: cached_dedup_works [26775,26793]
name: cached_dedup_works [26688,26706]
===
match
---
operator: , [965,966]
operator: , [965,966]
===
match
---
name: total_seconds [30363,30376]
name: total_seconds [30222,30235]
===
match
---
arglist [19761,19840]
arglist [19720,19799]
===
match
---
name: log [24040,24043]
name: log [23953,23956]
===
match
---
name: self [11871,11875]
name: self [11871,11875]
===
match
---
trailer [22203,22213]
trailer [22116,22126]
===
match
---
name: state [24508,24513]
name: state [24421,24426]
===
match
---
name: self [3562,3566]
name: self [3562,3566]
===
match
---
trailer [24472,24483]
trailer [24385,24396]
===
match
---
trailer [7879,7881]
trailer [7879,7881]
===
match
---
name: task_instance [18290,18303]
name: task_instance [18299,18312]
===
match
---
name: cached_sensor_exceptions [26229,26253]
name: cached_sensor_exceptions [26142,26166]
===
match
---
name: and_ [16263,16267]
name: and_ [16205,16209]
===
match
---
suite [19981,20052]
suite [19940,20011]
===
match
---
name: shard_max [11546,11555]
name: shard_max [11546,11555]
===
match
---
name: ti [15863,15865]
name: ti [15805,15807]
===
match
---
simple_stmt [6462,6486]
simple_stmt [6462,6486]
===
match
---
simple_stmt [26224,26375]
simple_stmt [26137,26288]
===
match
---
param [7975,7980]
param [7975,7980]
===
match
---
comparison [16293,16315]
comparison [16235,16257]
===
match
---
name: ti [18773,18775]
name: ti [18732,18734]
===
match
---
name: flush_cached_sensor_poke_results [29501,29533]
name: flush_cached_sensor_poke_results [29360,29392]
===
match
---
name: SensorWork [3669,3679]
name: SensorWork [3669,3679]
===
match
---
trailer [21600,21621]
trailer [21513,21534]
===
match
---
trailer [16357,16365]
trailer [16299,16307]
===
match
---
name: State [19216,19221]
name: State [19175,19180]
===
match
---
name: with_for_update [16639,16654]
name: with_for_update [16581,16596]
===
match
---
name: timezone [9336,9344]
name: timezone [9336,9344]
===
match
---
name: timeout [11832,11839]
name: timeout [11832,11839]
===
match
---
name: query_result [16141,16153]
name: query_result [16083,16095]
===
match
---
suite [9196,9244]
suite [9196,9244]
===
match
---
funcdef [27777,29303]
funcdef [27690,29162]
===
match
---
comparison [16597,16620]
comparison [16539,16562]
===
match
---
simple_stmt [6705,6724]
simple_stmt [6705,6724]
===
match
---
not_test [27431,27458]
not_test [27344,27371]
===
match
---
operator: = [17203,17204]
operator: = [17145,17146]
===
match
---
name: poke_interval [11770,11783]
name: poke_interval [11770,11783]
===
match
---
name: SensorExceptionInfo [26452,26471]
name: SensorExceptionInfo [26365,26384]
===
match
---
import_from [849,892]
import_from [849,892]
===
match
---
atom_expr [14048,14090]
atom_expr [13990,14032]
===
match
---
name: sensor_exception [22397,22413]
name: sensor_exception [22310,22326]
===
match
---
trailer [16414,16429]
trailer [16356,16371]
===
match
---
trailer [29054,29060]
trailer [28967,28973]
===
match
---
name: self [29934,29938]
name: self [29793,29797]
===
match
---
trailer [3522,3535]
trailer [3522,3535]
===
match
---
if_stmt [19245,19530]
if_stmt [19204,19489]
===
match
---
trailer [24626,24665]
trailer [24539,24578]
===
match
---
name: ti_key [14807,14813]
name: ti_key [14749,14755]
===
match
---
name: x [13984,13985]
name: x [13926,13927]
===
match
---
name: session [19719,19726]
name: session [19678,19685]
===
match
---
name: SI [16192,16194]
name: SI [16134,16136]
===
match
---
suite [6583,6772]
suite [6583,6772]
===
match
---
trailer [8849,8866]
trailer [8849,8866]
===
match
---
exprlist [26750,26766]
exprlist [26663,26679]
===
match
---
arglist [18437,18465]
arglist [18446,18474]
===
match
---
operator: { [11994,11995]
operator: { [11994,11995]
===
match
---
parameters [21985,22004]
parameters [21898,21917]
===
match
---
name: try_number [3029,3039]
name: try_number [3029,3039]
===
match
---
name: execution_date [19573,19587]
name: execution_date [19532,19546]
===
match
---
name: get_email_subject_content [18304,18329]
name: get_email_subject_content [18313,18338]
===
match
---
number: 1 [17089,17090]
number: 1 [17031,17032]
===
match
---
name: poke_start_time [29447,29462]
name: poke_start_time [29306,29321]
===
match
---
number: 1 [28697,28698]
number: 1 [28610,28611]
===
match
---
name: self [26770,26774]
name: self [26683,26687]
===
match
---
trailer [4881,4896]
trailer [4881,4896]
===
match
---
trailer [26012,26035]
trailer [25925,25948]
===
match
---
atom_expr [14933,14946]
atom_expr [14875,14888]
===
match
---
name: gauge [28718,28723]
name: gauge [28631,28636]
===
match
---
atom_expr [16808,16836]
atom_expr [16750,16778]
===
match
---
operator: , [5330,5331]
operator: , [5330,5331]
===
match
---
operator: = [7834,7835]
operator: = [7834,7835]
===
match
---
operator: = [6514,6515]
operator: = [6514,6515]
===
match
---
comparison [30330,30393]
comparison [30189,30252]
===
match
---
name: tuple_ [14755,14761]
name: tuple_ [14697,14703]
===
match
---
name: SI [12946,12948]
name: SI [12946,12948]
===
match
---
trailer [29876,29883]
trailer [29735,29742]
===
match
---
name: SI [16412,16414]
name: SI [16354,16356]
===
match
---
operator: = [29865,29866]
operator: = [29724,29725]
===
match
---
atom_expr [16597,16608]
atom_expr [16539,16550]
===
match
---
suite [30546,30599]
suite [30405,30458]
===
match
---
atom_expr [2894,2905]
atom_expr [2894,2905]
===
match
---
name: LOGGING_CLASS_PATH [1662,1680]
name: LOGGING_CLASS_PATH [1662,1680]
===
match
---
operator: * [11598,11599]
operator: * [11598,11599]
===
match
---
trailer [16638,16654]
trailer [16580,16596]
===
match
---
trailer [12252,12286]
trailer [12252,12286]
===
match
---
atom_expr [16174,16679]
atom_expr [16116,16621]
===
match
---
name: print [3389,3394]
name: print [3389,3394]
===
match
---
testlist [5811,5857]
testlist [5811,5857]
===
match
---
name: all [16674,16677]
name: all [16616,16619]
===
match
---
name: _mark_multi_state [15238,15255]
name: _mark_multi_state [15180,15197]
===
match
---
name: self [17320,17324]
name: self [17257,17261]
===
match
---
atom_expr [5838,5857]
atom_expr [5838,5857]
===
match
---
atom_expr [14959,14975]
atom_expr [14901,14917]
===
match
---
operator: , [26321,26322]
operator: , [26234,26235]
===
match
---
name: sensor_instance [17036,17051]
name: sensor_instance [16978,16993]
===
match
---
name: query [12906,12911]
name: query [12906,12911]
===
match
---
trailer [14716,14722]
trailer [14658,14664]
===
match
---
operator: != [19957,19959]
operator: != [19916,19918]
===
match
---
trailer [4843,4852]
trailer [4843,4852]
===
match
---
expr_stmt [5025,5065]
expr_stmt [5025,5065]
===
match
---
trailer [5842,5857]
trailer [5842,5857]
===
match
---
trailer [20778,20785]
trailer [20737,20744]
===
match
---
simple_stmt [5906,5970]
simple_stmt [5906,5970]
===
match
---
name: si [2941,2943]
name: si [2941,2943]
===
match
---
simple_stmt [7639,7677]
simple_stmt [7639,7677]
===
match
---
name: infra_failure_retry_window [7770,7796]
name: infra_failure_retry_window [7770,7796]
===
match
---
atom_expr [15892,15913]
atom_expr [15834,15855]
===
match
---
name: isinstance [12415,12425]
name: isinstance [12415,12425]
===
match
---
name: sleep [926,931]
name: sleep [926,931]
===
match
---
simple_stmt [1204,1248]
simple_stmt [1204,1248]
===
match
---
operator: , [17540,17541]
operator: , [17549,17550]
===
match
---
name: si [3026,3028]
name: si [3026,3028]
===
match
---
comp_op [24266,24272]
comp_op [24179,24185]
===
match
---
name: exception_info [22248,22262]
name: exception_info [22161,22175]
===
match
---
name: self [7182,7186]
name: self [7182,7186]
===
match
---
atom_expr [20529,20540]
atom_expr [20488,20499]
===
match
---
name: TI [16341,16343]
name: TI [16283,16285]
===
match
---
name: error_info [18217,18227]
name: error_info [18226,18236]
===
match
---
trailer [4805,4812]
trailer [4805,4812]
===
match
---
return_stmt [7175,7263]
return_stmt [7175,7263]
===
match
---
not_test [12411,12453]
not_test [12411,12453]
===
match
---
name: task_id [16344,16351]
name: task_id [16286,16293]
===
match
---
simple_stmt [10094,10106]
simple_stmt [10094,10106]
===
match
---
trailer [12966,12973]
trailer [12966,12973]
===
match
---
trailer [29947,30015]
trailer [29806,29874]
===
match
---
atom_expr [24803,24825]
atom_expr [24716,24738]
===
match
---
atom_expr [5373,5396]
atom_expr [5373,5396]
===
match
---
name: TI [14785,14787]
name: TI [14727,14729]
===
match
---
atom [13983,14038]
atom [13925,13980]
===
match
---
name: dag_id [2899,2905]
name: dag_id [2899,2905]
===
match
---
suite [9773,9914]
suite [9773,9914]
===
match
---
operator: , [15270,15271]
operator: , [15212,15213]
===
match
---
atom_expr [3442,3457]
atom_expr [3442,3457]
===
match
---
string: """         :return: Should the sensor fail         :type: boolean         """ [9437,9515]
string: """         :return: Should the sensor fail         :type: boolean         """ [9437,9515]
===
match
---
comparison [20324,20349]
comparison [20283,20308]
===
match
---
string: """     This class stores a sensor work with decoded context value. It is only used     inside of smart sensor. Create a sensor work based on sensor instance record.     A sensor work object has the following attributes:     `dag_id`: sensor_instance dag_id.     `task_id`: sensor_instance task_id.     `execution_date`: sensor_instance execution_date.     `try_number`: sensor_instance try_number     `poke_context`: Decoded poke_context for the sensor task.     `execution_context`: Decoded execution_context.     `hashcode`: This is the signature of poking job.     `operator`: The sensor operator class.     `op_classpath`: The sensor operator class path     `encoded_poke_context`: The raw data from sensor_instance poke_context column.     `log`: The sensor work logger which will mock the corresponding task instance log.      :param si: The sensor_instance ORM object.     """ [1972,2856]
string: """     This class stores a sensor work with decoded context value. It is only used     inside of smart sensor. Create a sensor work based on sensor instance record.     A sensor work object has the following attributes:     `dag_id`: sensor_instance dag_id.     `task_id`: sensor_instance task_id.     `execution_date`: sensor_instance execution_date.     `try_number`: sensor_instance try_number     `poke_context`: Decoded poke_context for the sensor task.     `execution_context`: Decoded execution_context.     `hashcode`: This is the signature of poking job.     `operator`: The sensor operator class.     `op_classpath`: The sensor operator class path     `encoded_poke_context`: The raw data from sensor_instance poke_context column.     `log`: The sensor work logger which will mock the corresponding task instance log.      :param si: The sensor_instance ORM object.     """ [1972,2856]
===
match
---
atom_expr [9336,9353]
atom_expr [9336,9353]
===
match
---
sync_comp_for [13986,14037]
sync_comp_for [13928,13979]
===
match
---
number: 0 [11535,11536]
number: 0 [11535,11536]
===
match
---
name: isinstance [26002,26012]
name: isinstance [25915,25925]
===
match
---
trailer [29201,29205]
trailer [29109,29113]
===
match
---
trailer [25582,25607]
trailer [25495,25520]
===
match
---
name: __init__ [11646,11654]
name: __init__ [11646,11654]
===
match
---
trailer [20153,20161]
trailer [20112,20120]
===
match
---
trailer [3394,3397]
trailer [3394,3397]
===
match
---
name: ti [15978,15980]
name: ti [15920,15922]
===
match
---
string: "-" [5167,5170]
string: "-" [5167,5170]
===
match
---
name: session [14709,14716]
name: session [14651,14658]
===
match
---
atom_expr [16391,16408]
atom_expr [16333,16350]
===
match
---
name: execute [30587,30594]
name: execute [30446,30453]
===
match
---
simple_stmt [14462,14536]
simple_stmt [14404,14478]
===
match
---
name: sensor_work [22271,22282]
name: sensor_work [22184,22195]
===
match
---
name: self [27006,27010]
name: self [26919,26923]
===
match
---
name: self [28418,28422]
name: self [28331,28335]
===
match
---
number: 180 [11440,11443]
number: 180 [11440,11443]
===
match
---
atom_expr [21864,21896]
atom_expr [21777,21809]
===
match
---
name: with_for_update [19859,19874]
name: with_for_update [19818,19833]
===
match
---
simple_stmt [4462,4477]
simple_stmt [4462,4477]
===
match
---
simple_stmt [16882,16891]
simple_stmt [16824,16833]
===
match
---
try_stmt [5560,5689]
try_stmt [5560,5689]
===
match
---
trailer [4788,4907]
trailer [4788,4907]
===
match
---
arith_expr [14996,15016]
arith_expr [14938,14958]
===
match
---
atom_expr [11827,11839]
atom_expr [11827,11839]
===
match
---
name: log [21876,21879]
name: log [21789,21792]
===
match
---
expr_stmt [3562,3605]
expr_stmt [3562,3605]
===
match
---
simple_stmt [30191,30215]
simple_stmt [30050,30074]
===
match
---
name: get [18396,18399]
name: get [18405,18408]
===
match
---
import_from [1204,1247]
import_from [1204,1247]
===
match
---
argument [11662,11670]
argument [11662,11670]
===
match
---
trailer [29635,29648]
trailer [29494,29507]
===
match
---
return_stmt [4462,4476]
return_stmt [4462,4476]
===
match
---
arith_expr [7200,7239]
arith_expr [7200,7239]
===
match
---
simple_stmt [11968,11997]
simple_stmt [11968,11997]
===
match
---
name: clear_state [6781,6792]
name: clear_state [6781,6792]
===
match
---
atom_expr [29713,29735]
atom_expr [29572,29594]
===
match
---
name: ti [19519,19521]
name: ti [19478,19480]
===
match
---
string: "Loaded %s sensor_works" [29601,29625]
string: "Loaded %s sensor_works" [29460,29484]
===
match
---
atom_expr [30191,30214]
atom_expr [30050,30073]
===
match
---
trailer [24812,24825]
trailer [24725,24738]
===
match
---
trailer [29808,29829]
trailer [29667,29688]
===
match
---
atom_expr [5225,5360]
atom_expr [5225,5360]
===
match
---
name: execution_date [19826,19840]
name: execution_date [19785,19799]
===
match
---
trailer [2964,2979]
trailer [2964,2979]
===
match
---
suite [8941,9389]
suite [8941,9389]
===
match
---
arglist [25258,25290]
arglist [25171,25203]
===
match
---
name: self [29631,29635]
name: self [29490,29494]
===
match
---
name: exception [21880,21889]
name: exception [21793,21802]
===
match
---
string: "Exception on failing %s" [21081,21106]
string: "Exception on failing %s" [21035,21060]
===
match
---
simple_stmt [23000,23034]
simple_stmt [22913,22947]
===
match
---
expr_stmt [26940,26964]
expr_stmt [26853,26877]
===
match
---
name: query [13120,13125]
name: query [13120,13125]
===
match
---
string: "smart_sensor_operator.exception_failures" [28967,29009]
string: "smart_sensor_operator.exception_failures" [28880,28922]
===
match
---
name: poke_interval [12295,12308]
name: poke_interval [12295,12308]
===
match
---
trailer [4715,4719]
trailer [4715,4719]
===
match
---
name: try_number [3921,3931]
name: try_number [3921,3931]
===
match
---
simple_stmt [16072,16090]
simple_stmt [16014,16032]
===
match
---
atom_expr [28477,28510]
atom_expr [28390,28423]
===
match
---
trailer [5537,5546]
trailer [5537,5546]
===
match
---
simple_stmt [1124,1172]
simple_stmt [1124,1172]
===
match
---
name: SENSING [16973,16980]
name: SENSING [16915,16922]
===
match
---
operator: , [21700,21701]
operator: , [21613,21614]
===
match
---
atom_expr [23696,23716]
atom_expr [23609,23629]
===
match
---
comparison [23858,23891]
comparison [23771,23804]
===
match
---
return_stmt [14989,15016]
return_stmt [14931,14958]
===
match
---
name: task_id [19796,19803]
name: task_id [19755,19762]
===
match
---
simple_stmt [933,974]
simple_stmt [933,974]
===
match
---
trailer [19518,19529]
trailer [19477,19488]
===
match
---
name: si [3080,3082]
name: si [3080,3082]
===
match
---
if_stmt [9166,9389]
if_stmt [9166,9389]
===
match
---
simple_stmt [23050,23100]
simple_stmt [22963,23013]
===
match
---
trailer [22459,22463]
trailer [22372,22376]
===
match
---
name: self [10058,10062]
name: self [10058,10062]
===
match
---
operator: = [27671,27672]
operator: = [27584,27585]
===
match
---
param [11412,11417]
param [11412,11417]
===
match
---
operator: = [27841,27842]
operator: = [27754,27755]
===
match
---
atom_expr [22231,22262]
atom_expr [22144,22175]
===
match
---
suite [26850,26906]
suite [26763,26819]
===
match
---
trailer [19601,19608]
trailer [19560,19567]
===
match
---
name: _infra_failure_timeout [9214,9236]
name: _infra_failure_timeout [9214,9236]
===
match
---
dotted_name [1209,1222]
dotted_name [1209,1222]
===
match
---
operator: , [16190,16191]
operator: , [16132,16133]
===
match
---
name: sensor_work [25548,25559]
name: sensor_work [25461,25472]
===
match
---
operator: , [21106,21107]
operator: , [21060,21061]
===
match
---
simple_stmt [4422,4454]
simple_stmt [4422,4454]
===
match
---
name: self [6705,6709]
name: self [6705,6709]
===
match
---
atom_expr [3008,3023]
atom_expr [3008,3023]
===
match
---
name: commit [14967,14973]
name: commit [14909,14915]
===
match
---
name: session [17227,17234]
name: session [17169,17176]
===
match
---
suite [22431,23100]
suite [22344,23013]
===
match
---
name: handler_config_copy [4108,4127]
name: handler_config_copy [4108,4127]
===
match
---
name: POKE_EXCEPTION [26132,26146]
name: POKE_EXCEPTION [26045,26059]
===
match
---
name: models [1056,1062]
name: models [1056,1062]
===
match
---
funcdef [7021,7264]
funcdef [7021,7264]
===
match
---
name: timer [12876,12881]
name: timer [12876,12881]
===
match
---
arglist [23583,23627]
arglist [23496,23540]
===
match
---
atom_expr [29934,30015]
atom_expr [29793,29874]
===
match
---
name: html_content [18272,18284]
name: html_content [18281,18293]
===
match
---
import_from [1596,1637]
import_from [1596,1637]
===
match
---
atom_expr [6705,6715]
atom_expr [6705,6715]
===
match
---
simple_stmt [8030,8699]
simple_stmt [8030,8699]
===
match
---
name: ti_keys [14586,14593]
name: ti_keys [14528,14535]
===
match
---
operator: * [5171,5172]
operator: * [5171,5172]
===
match
---
simple_stmt [4004,4100]
simple_stmt [4004,4100]
===
match
---
trailer [29883,29885]
trailer [29742,29744]
===
match
---
atom_expr [25133,25165]
atom_expr [25046,25078]
===
match
---
name: PokeState [25472,25481]
name: PokeState [25385,25394]
===
match
---
name: self [9580,9584]
name: self [9580,9584]
===
match
---
suite [17658,21184]
suite [17667,21097]
===
match
---
name: smart_sensor_timeout [11842,11862]
name: smart_sensor_timeout [11842,11862]
===
match
---
name: POKE_EXCEPTION [23877,23891]
name: POKE_EXCEPTION [23790,23804]
===
match
---
name: utils [1467,1472]
name: utils [1467,1472]
===
match
---
trailer [26951,26957]
trailer [26864,26870]
===
match
---
simple_stmt [28570,28595]
simple_stmt [28483,28508]
===
match
---
trailer [27180,27184]
trailer [27093,27097]
===
match
---
name: self [21520,21524]
name: self [21433,21437]
===
match
---
name: self [26867,26871]
name: self [26780,26784]
===
match
---
trailer [18303,18329]
trailer [18312,18338]
===
match
---
name: other [3761,3766]
name: other [3761,3766]
===
match
---
trailer [3073,3079]
trailer [3073,3079]
===
match
---
trailer [20558,20560]
trailer [20517,20519]
===
match
---
name: sensor_work [20972,20983]
name: sensor_work [20931,20942]
===
match
---
expr_stmt [16072,16089]
expr_stmt [16014,16031]
===
match
---
name: poke_timeout [11572,11584]
name: poke_timeout [11572,11584]
===
match
---
name: NotImplemented [3701,3715]
name: NotImplemented [3701,3715]
===
match
---
trailer [13017,13024]
trailer [13017,13024]
===
match
---
string: "%Y_%m_%dT%H_%M_%S_%f" [4853,4875]
string: "%Y_%m_%dT%H_%M_%S_%f" [4853,4875]
===
match
---
operator: , [17018,17019]
operator: , [16960,16961]
===
match
---
atom_expr [12085,12099]
atom_expr [12085,12099]
===
match
---
simple_stmt [22271,22335]
simple_stmt [22184,22248]
===
match
---
testlist_comp [27532,27562]
testlist_comp [27445,27475]
===
match
---
parameters [6895,6901]
parameters [6895,6901]
===
match
---
trailer [19377,19386]
trailer [19336,19345]
===
match
---
name: first [19894,19899]
name: first [19853,19858]
===
match
---
name: count_poke_exception [28356,28376]
name: count_poke_exception [28269,28289]
===
match
---
trailer [20697,20703]
trailer [20656,20662]
===
match
---
name: _update_ti_hostname [14163,14182]
name: _update_ti_hostname [14105,14124]
===
match
---
operator: = [2939,2940]
operator: = [2939,2940]
===
match
---
name: join [4784,4788]
name: join [4784,4788]
===
match
---
name: FAILED [20502,20508]
name: FAILED [20461,20467]
===
match
---
simple_stmt [1972,2857]
simple_stmt [1972,2857]
===
match
---
trailer [5323,5330]
trailer [5323,5330]
===
match
---
atom_expr [7914,7944]
atom_expr [7914,7944]
===
match
---
atom_expr [23225,23269]
atom_expr [23138,23182]
===
match
---
name: on_kill [30490,30497]
name: on_kill [30349,30356]
===
match
---
simple_stmt [6911,6987]
simple_stmt [6911,6987]
===
match
---
simple_stmt [25312,25346]
simple_stmt [25225,25259]
===
match
---
name: self [23905,23909]
name: self [23818,23822]
===
match
---
name: str [20907,20910]
name: str [20866,20869]
===
match
---
trailer [26285,26374]
trailer [26198,26287]
===
match
---
name: get [18754,18757]
name: get [18713,18716]
===
match
---
simple_stmt [19621,19639]
simple_stmt [19580,19598]
===
match
---
atom [29867,29904]
atom [29726,29763]
===
match
---
param [12610,12622]
param [12610,12622]
===
match
---
simple_stmt [27892,27917]
simple_stmt [27805,27830]
===
match
---
trailer [29572,29574]
trailer [29431,29433]
===
match
---
trailer [23023,23033]
trailer [22936,22946]
===
match
---
name: cache_key [24211,24220]
name: cache_key [24124,24133]
===
match
---
atom_expr [8804,8836]
atom_expr [8804,8836]
===
match
---
operator: == [20162,20164]
operator: == [20121,20123]
===
match
---
atom_expr [7685,7707]
atom_expr [7685,7707]
===
match
---
atom_expr [3859,3879]
atom_expr [3859,3879]
===
match
---
simple_stmt [1596,1638]
simple_stmt [1596,1638]
===
match
---
simple_stmt [24130,24202]
simple_stmt [24043,24115]
===
match
---
or_test [12411,12473]
or_test [12411,12473]
===
match
---
name: sensor_work [27746,27757]
name: sensor_work [27659,27670]
===
match
---
simple_stmt [19051,19128]
simple_stmt [19010,19087]
===
match
---
trailer [19874,19876]
trailer [19833,19835]
===
match
---
simple_stmt [19683,19916]
simple_stmt [19642,19875]
===
match
---
raise_stmt [12487,12554]
raise_stmt [12487,12554]
===
match
---
trailer [27010,27035]
trailer [26923,26948]
===
match
---
name: op_classpath [3541,3553]
name: op_classpath [3541,3553]
===
match
---
name: query_result [16775,16787]
name: query_result [16717,16729]
===
match
---
name: get [19278,19281]
name: get [19237,19240]
===
match
---
try_stmt [27813,29303]
try_stmt [27726,29162]
===
match
---
if_stmt [4983,5397]
if_stmt [4983,5397]
===
match
---
trailer [13125,13129]
trailer [13125,13129]
===
match
---
simple_stmt [14436,14454]
simple_stmt [14378,14396]
===
match
---
name: count_exception_failures [28669,28693]
name: count_exception_failures [28582,28606]
===
match
---
expr_stmt [3442,3473]
expr_stmt [3442,3473]
===
match
---
or_test [25961,26035]
or_test [25874,25948]
===
match
---
name: provide_session [15214,15229]
name: provide_session [15156,15171]
===
match
---
param [15283,15304]
param [15225,15246]
===
match
---
operator: + [10169,10170]
operator: + [10169,10170]
===
match
---
trailer [3262,3281]
trailer [3262,3281]
===
match
---
arglist [25612,25627]
arglist [25525,25540]
===
match
---
name: logger [5129,5135]
name: logger [5129,5135]
===
match
---
trailer [29995,30014]
trailer [29854,29873]
===
match
---
name: task_id [3795,3802]
name: task_id [3795,3802]
===
match
---
name: self [3790,3794]
name: self [3790,3794]
===
match
---
name: mark_state [15818,15828]
name: mark_state [15760,15770]
===
match
---
atom_expr [29992,30014]
atom_expr [29851,29873]
===
match
---
simple_stmt [2926,2952]
simple_stmt [2926,2952]
===
match
---
atom_expr [3651,3680]
atom_expr [3651,3680]
===
match
---
string: "Task %s got an error: %s. Set the state to failed. Exit." [20847,20905]
string: "Task %s got an error: %s. Set the state to failed. Exit." [20806,20864]
===
match
---
operator: , [25277,25278]
operator: , [25190,25191]
===
match
---
param [6793,6797]
param [6793,6797]
===
match
---
trailer [20750,20754]
trailer [20709,20713]
===
match
---
simple_stmt [5734,5796]
simple_stmt [5734,5796]
===
match
---
operator: , [28919,28920]
operator: , [28832,28833]
===
match
---
not_test [10054,10080]
not_test [10054,10080]
===
match
---
expr_stmt [16707,16735]
expr_stmt [16649,16677]
===
match
---
operator: = [14689,14690]
operator: = [14631,14632]
===
match
---
atom_expr [24409,24425]
atom_expr [24322,24338]
===
match
---
arglist [23250,23268]
arglist [23163,23181]
===
match
---
name: utcnow [9345,9351]
name: utcnow [9345,9351]
===
match
---
suite [18229,18663]
suite [18238,18622]
===
match
---
operator: = [4207,4208]
operator: = [4207,4208]
===
match
---
name: started_at [30351,30361]
name: started_at [30210,30220]
===
match
---
simple_stmt [12085,12112]
simple_stmt [12085,12112]
===
match
---
suite [26809,26965]
suite [26722,26878]
===
match
---
name: operator [16612,16620]
name: operator [16554,16562]
===
match
---
name: dag_id [4806,4812]
name: dag_id [4806,4812]
===
match
---
name: timezone [30331,30339]
name: timezone [30190,30198]
===
match
---
suite [3635,3942]
suite [3635,3942]
===
match
---
name: info [20821,20825]
name: info [20780,20784]
===
match
---
simple_stmt [14919,14947]
simple_stmt [14861,14889]
===
match
---
simple_stmt [9524,9608]
simple_stmt [9524,9608]
===
match
---
name: AirflowException [1006,1022]
name: AirflowException [1006,1022]
===
match
---
try_stmt [18242,18663]
try_stmt [18251,18622]
===
match
---
funcdef [5708,5858]
funcdef [5708,5858]
===
match
---
atom_expr [9560,9577]
atom_expr [9560,9577]
===
match
---
trailer [28422,28447]
trailer [28335,28360]
===
match
---
atom_expr [10121,10138]
atom_expr [10121,10138]
===
match
---
trailer [27608,27634]
trailer [27521,27547]
===
match
---
operator: , [15199,15200]
operator: , [15141,15142]
===
match
---
operator: = [5165,5166]
operator: = [5165,5166]
===
match
---
operator: = [22156,22157]
operator: = [22069,22070]
===
match
---
testlist_star_expr [18263,18287]
testlist_star_expr [18272,18296]
===
match
---
atom_expr [17002,17052]
atom_expr [16944,16994]
===
match
---
string: "smart_sensor_operator.executed_tasks" [30115,30153]
string: "smart_sensor_operator.executed_tasks" [29974,30012]
===
match
---
name: handler_config [1682,1696]
name: handler_config [1682,1696]
===
match
---
name: html_content [18453,18465]
name: html_content [18462,18474]
===
match
---
string: "Exception at getting loop stats %s" [29216,29252]
string: "Exception at getting loop stats %s" [29124,29160]
===
match
---
name: email_alert [19148,19159]
name: email_alert [19107,19118]
===
match
---
trailer [20262,20268]
trailer [20221,20227]
===
match
---
name: sensor_instance [20472,20487]
name: sensor_instance [20431,20446]
===
match
---
operator: + [4958,4959]
operator: + [4958,4959]
===
match
---
operator: = [19588,19589]
operator: = [19547,19548]
===
match
---
atom_expr [25450,25493]
atom_expr [25363,25406]
===
match
---
operator: = [27913,27914]
operator: = [27826,27827]
===
match
---
trailer [1661,1681]
trailer [1661,1681]
===
match
---
trailer [3365,3369]
trailer [3365,3369]
===
match
---
name: import_string [27595,27608]
name: import_string [27508,27521]
===
match
---
number: 1 [28380,28381]
number: 1 [28293,28294]
===
match
---
name: should_fail_current_run [7919,7942]
name: should_fail_current_run [7919,7942]
===
match
---
atom_expr [4803,4812]
atom_expr [4803,4812]
===
match
---
expr_stmt [6995,7015]
expr_stmt [6995,7015]
===
match
---
name: provide_session [17574,17589]
name: provide_session [17583,17598]
===
match
---
atom_expr [3026,3039]
atom_expr [3026,3039]
===
match
---
simple_stmt [7297,7467]
simple_stmt [7297,7467]
===
match
---
name: self [8869,8873]
name: self [8869,8873]
===
match
---
simple_stmt [8950,9085]
simple_stmt [8950,9085]
===
match
---
name: gauge [29669,29674]
name: gauge [29528,29533]
===
match
---
trailer [29372,29374]
trailer [29231,29233]
===
match
---
string: "Task %s succeeded" [23583,23602]
string: "Task %s succeeded" [23496,23515]
===
match
---
name: self [3258,3262]
name: self [3258,3262]
===
match
---
param [17624,17636]
param [17633,17645]
===
match
---
name: si [2881,2883]
name: si [2881,2883]
===
match
---
name: SensorWork [13665,13675]
name: SensorWork [13665,13675]
===
match
---
atom_expr [3538,3553]
atom_expr [3538,3553]
===
match
---
trailer [18377,18395]
trailer [18386,18404]
===
match
---
suite [25367,25561]
suite [25280,25474]
===
match
---
name: execution_context [3196,3213]
name: execution_context [3196,3213]
===
match
---
operator: - [7218,7219]
operator: - [7218,7219]
===
match
---
name: count_poke_success [27857,27875]
name: count_poke_success [27770,27788]
===
match
---
trailer [20922,20929]
trailer [20881,20888]
===
match
---
name: LOGGING_CLASS_PATH [1153,1171]
name: LOGGING_CLASS_PATH [1153,1171]
===
match
---
suite [27804,29303]
suite [27717,29162]
===
match
---
name: sensor_work [23982,23993]
name: sensor_work [23895,23906]
===
match
---
atom_expr [14785,14802]
atom_expr [14727,14744]
===
match
---
trailer [29365,29372]
trailer [29224,29231]
===
match
---
atom_expr [1699,1725]
atom_expr [1699,1725]
===
match
---
name: self [9422,9426]
name: self [9422,9426]
===
match
---
atom_expr [21684,21725]
atom_expr [21597,21638]
===
match
---
name: encoded_poke_context [3567,3587]
name: encoded_poke_context [3567,3587]
===
match
---
trailer [24085,24090]
trailer [23998,24003]
===
match
---
comparison [16547,16571]
comparison [16489,16513]
===
match
---
name: handler [5581,5588]
name: handler [5581,5588]
===
match
---
name: try_number [3901,3911]
name: try_number [3901,3911]
===
match
---
name: operator [3487,3495]
name: operator [3487,3495]
===
match
---
name: line_break [5154,5164]
name: line_break [5154,5164]
===
match
---
decorator [9732,9742]
decorator [9732,9742]
===
match
---
name: poke_hash [17404,17413]
name: poke_hash [17374,17383]
===
match
---
name: other [3915,3920]
name: other [3915,3920]
===
match
---
trailer [15160,15164]
trailer [15102,15106]
===
match
---
simple_stmt [4342,4414]
simple_stmt [4342,4414]
===
match
---
name: self [26224,26228]
name: self [26137,26141]
===
match
---
operator: , [22545,22546]
operator: , [22458,22459]
===
match
---
name: Stats [30103,30108]
name: Stats [29962,29967]
===
match
---
name: sensor_work [24813,24824]
name: sensor_work [24726,24737]
===
match
---
dotted_name [1129,1145]
dotted_name [1129,1145]
===
match
---
operator: , [15260,15261]
operator: , [15202,15203]
===
match
---
atom_expr [14484,14493]
atom_expr [14426,14435]
===
match
---
operator: = [26525,26526]
operator: = [26438,26439]
===
match
---
simple_stmt [4713,4763]
simple_stmt [4713,4763]
===
match
---
name: info [15165,15169]
name: info [15107,15111]
===
match
---
number: 0 [12472,12473]
number: 0 [12472,12473]
===
match
---
simple_stmt [22448,22584]
simple_stmt [22361,22497]
===
match
---
trailer [12124,12134]
trailer [12124,12134]
===
match
---
comparison [16496,16521]
comparison [16438,16463]
===
match
---
operator: = [3588,3589]
operator: = [3588,3589]
===
match
---
expr_stmt [28669,28698]
expr_stmt [28582,28611]
===
match
---
name: should_fail_current_run [8874,8897]
name: should_fail_current_run [8874,8897]
===
match
---
suite [19030,19171]
suite [18989,19130]
===
match
---
name: self [23798,23802]
name: self [23711,23715]
===
match
---
suite [30394,30481]
suite [30253,30340]
===
match
---
name: log [17478,17481]
name: log [17487,17490]
===
match
---
simple_stmt [16141,16694]
simple_stmt [16083,16636]
===
match
---
comparison [12974,12999]
comparison [12974,12999]
===
match
---
trailer [6709,6715]
trailer [6709,6715]
===
match
---
name: poke_interval [11754,11767]
name: poke_interval [11754,11767]
===
match
---
atom_expr [29996,30013]
atom_expr [29855,29872]
===
match
---
parameters [9645,9651]
parameters [9645,9651]
===
match
---
name: count [15201,15206]
name: count [15143,15148]
===
match
---
name: set_state [25462,25471]
name: set_state [25375,25384]
===
match
---
trailer [24963,24970]
trailer [24876,24883]
===
match
---
name: self [9767,9771]
name: self [9767,9771]
===
match
---
parameters [5447,5453]
parameters [5447,5453]
===
match
---
trailer [21747,21754]
trailer [21660,21667]
===
match
---
param [15312,15324]
param [15254,15266]
===
match
---
name: task_id [4817,4824]
name: task_id [4817,4824]
===
match
---
name: poke_context [3103,3115]
name: poke_context [3103,3115]
===
match
---
simple_stmt [1547,1596]
simple_stmt [1547,1596]
===
match
---
atom_expr [28206,28222]
atom_expr [28119,28135]
===
match
---
simple_stmt [18619,18663]
simple_stmt [18554,18622]
===
match
---
trailer [16217,16471]
trailer [16159,16413]
===
match
---
name: state [28301,28306]
name: state [28214,28219]
===
match
---
trailer [3486,3495]
trailer [3486,3495]
===
match
---
name: sensor_work [24223,24234]
name: sensor_work [24136,24147]
===
match
---
atom_expr [19960,19980]
atom_expr [19919,19939]
===
match
---
trailer [12430,12438]
trailer [12430,12438]
===
match
---
trailer [26085,26087]
trailer [25998,26000]
===
match
---
name: timeout [30386,30393]
name: timeout [30245,30252]
===
match
---
name: Stats [28712,28717]
name: Stats [28625,28630]
===
match
---
name: dict [27484,27488]
name: dict [27397,27401]
===
match
---
string: 'task' [1718,1724]
string: 'task' [1718,1724]
===
match
---
name: self [5838,5842]
name: self [5838,5842]
===
match
---
name: err [1899,1902]
name: err [1899,1902]
===
match
---
trailer [26471,26560]
trailer [26384,26473]
===
match
---
simple_stmt [26672,26738]
simple_stmt [26585,26651]
===
match
---
trailer [9177,9195]
trailer [9177,9195]
===
match
---
trailer [20703,20720]
trailer [20662,20679]
===
match
---
operator: = [26339,26340]
operator: = [26252,26253]
===
match
---
arith_expr [9336,9388]
arith_expr [9336,9388]
===
match
---
trailer [19760,19841]
trailer [19719,19800]
===
match
---
atom_expr [3915,3931]
atom_expr [3915,3931]
===
match
---
name: state [28090,28095]
name: state [28003,28008]
===
match
---
name: ti [17016,17018]
name: ti [16958,16960]
===
match
---
name: close_sensor_logger [20984,21003]
name: close_sensor_logger [20943,20962]
===
match
---
operator: , [17448,17449]
operator: , [17384,17385]
===
match
---
name: datetime [7591,7599]
name: datetime [7591,7599]
===
match
---
name: info [30420,30424]
name: info [30279,30283]
===
match
---
name: log [24082,24085]
name: log [23995,23998]
===
match
---
simple_stmt [29384,29415]
simple_stmt [29243,29274]
===
match
---
trailer [29591,29595]
trailer [29450,29454]
===
match
---
trailer [11972,11991]
trailer [11972,11991]
===
match
---
simple_stmt [1893,1904]
simple_stmt [1893,1904]
===
match
---
comparison [10121,10201]
comparison [10121,10201]
===
match
---
operator: * [11655,11656]
operator: * [11655,11656]
===
match
---
name: poke_timeout [12160,12172]
name: poke_timeout [12160,12172]
===
match
---
trailer [15164,15169]
trailer [15106,15111]
===
match
---
operator: , [5135,5136]
operator: , [5135,5136]
===
match
---
operator: = [6867,6868]
operator: = [6867,6868]
===
match
---
trailer [13768,13772]
trailer [13763,13767]
===
match
---
name: self [2875,2879]
name: self [2875,2879]
===
match
---
name: cached_work [24496,24507]
name: cached_work [24409,24420]
===
match
---
name: hostname [16927,16935]
name: hostname [16869,16877]
===
match
---
name: task_id [2944,2951]
name: task_id [2944,2951]
===
match
---
name: total_seconds [7241,7254]
name: total_seconds [7241,7254]
===
match
---
atom_expr [20419,20450]
atom_expr [20378,20409]
===
match
---
name: info [13909,13913]
name: info [13851,13855]
===
match
---
atom_expr [13025,13037]
atom_expr [13025,13037]
===
match
---
trailer [9539,9556]
trailer [9539,9556]
===
match
---
test [3157,3221]
test [3157,3221]
===
match
---
name: is_infra_failure [9540,9556]
name: is_infra_failure [9540,9556]
===
match
---
operator: += [28377,28379]
operator: += [28290,28292]
===
match
---
atom [13586,13588]
atom [13586,13588]
===
match
---
name: __init__ [11394,11402]
name: __init__ [11394,11402]
===
match
---
import_from [1547,1595]
import_from [1547,1595]
===
match
---
name: self [29717,29721]
name: self [29576,29580]
===
match
---
name: ti_key [20923,20929]
name: ti_key [20882,20888]
===
match
---
operator: = [3067,3068]
operator: = [3067,3068]
===
match
---
operator: == [12983,12985]
operator: == [12983,12985]
===
match
---
trailer [4442,4453]
trailer [4442,4453]
===
match
---
simple_stmt [6592,6697]
simple_stmt [6592,6697]
===
match
---
atom_expr [16263,16452]
atom_expr [16205,16394]
===
match
---
trailer [17481,17486]
trailer [17490,17495]
===
match
---
atom_expr [19932,19956]
atom_expr [19891,19915]
===
match
---
if_stmt [30228,30315]
if_stmt [30087,30174]
===
match
---
argument [18648,18661]
argument [18607,18620]
===
match
---
number: 100000 [11556,11562]
number: 100000 [11556,11562]
===
match
---
trailer [7918,7942]
trailer [7918,7942]
===
match
---
expr_stmt [15892,15921]
expr_stmt [15834,15863]
===
match
---
trailer [29473,29480]
trailer [29332,29339]
===
match
---
trailer [21754,21756]
trailer [21667,21669]
===
match
---
simple_stmt [22223,22263]
simple_stmt [22136,22176]
===
match
---
name: ui_color [11344,11352]
name: ui_color [11344,11352]
===
match
---
name: self [5824,5828]
name: self [5824,5828]
===
match
---
operator: , [13203,13204]
operator: , [13203,13204]
===
match
---
atom_expr [29627,29649]
atom_expr [29486,29508]
===
match
---
expr_stmt [12120,12146]
expr_stmt [12120,12146]
===
match
---
trailer [23831,23844]
trailer [23744,23757]
===
match
---
name: handlers [4997,5005]
name: handlers [4997,5005]
===
match
---
operator: = [20663,20664]
operator: = [20622,20623]
===
match
---
name: self [14183,14187]
name: self [14125,14129]
===
match
---
string: "" [11925,11927]
string: "" [11925,11927]
===
match
---
trailer [21770,21781]
trailer [21683,21694]
===
match
---
except_clause [29130,29151]
except_clause [29043,29059]
===
match
---
decorated [14138,15208]
decorated [14080,15150]
===
match
---
sync_comp_for [14513,14534]
sync_comp_for [14455,14476]
===
match
---
simple_stmt [11909,11928]
simple_stmt [11909,11928]
===
match
---
name: sensor_works [14189,14201]
name: sensor_works [14131,14143]
===
match
---
string: """Close log handler for a sensor work.""" [5463,5505]
string: """Close log handler for a sensor work.""" [5463,5505]
===
match
---
param [8935,8939]
param [8935,8939]
===
match
---
operator: = [18288,18289]
operator: = [18297,18298]
===
match
---
parameters [9933,9939]
parameters [9933,9939]
===
match
---
name: sensor_works [14522,14534]
name: sensor_works [14464,14476]
===
match
---
trailer [12875,12881]
trailer [12875,12881]
===
match
---
suite [27459,27701]
suite [27372,27614]
===
match
---
suite [9428,9608]
suite [9428,9608]
===
match
---
simple_stmt [1682,1726]
simple_stmt [1682,1726]
===
match
---
expr_stmt [8753,8794]
expr_stmt [8753,8794]
===
match
---
arith_expr [29868,29903]
arith_expr [29727,29762]
===
match
---
trailer [11831,11839]
trailer [11831,11839]
===
match
---
simple_stmt [21669,21726]
simple_stmt [21582,21639]
===
match
---
atom_expr [21520,21532]
atom_expr [21433,21445]
===
match
---
atom_expr [24954,24970]
atom_expr [24867,24883]
===
match
---
name: error [22223,22228]
name: error [22136,22141]
===
match
---
simple_stmt [20690,20721]
simple_stmt [20649,20680]
===
match
---
name: staticmethod [3948,3960]
name: staticmethod [3948,3960]
===
match
---
atom_expr [29465,29482]
atom_expr [29324,29341]
===
match
---
classdef [7266,10202]
classdef [7266,10202]
===
match
---
atom_expr [25472,25492]
atom_expr [25385,25405]
===
match
---
arith_expr [10141,10201]
arith_expr [10141,10201]
===
match
---
trailer [29668,29674]
trailer [29527,29533]
===
match
---
atom_expr [3069,3096]
atom_expr [3069,3096]
===
match
---
name: init_args [27690,27699]
name: init_args [27603,27612]
===
match
---
atom_expr [18366,18408]
atom_expr [18375,18417]
===
match
---
simple_stmt [3442,3474]
simple_stmt [3442,3474]
===
match
---
trailer [17486,17567]
trailer [17495,17576]
===
match
---
param [14586,14593]
param [14528,14535]
===
match
---
simple_stmt [9209,9244]
simple_stmt [9209,9244]
===
match
---
trailer [20596,20598]
trailer [20555,20557]
===
match
---
name: ti_keys [15008,15015]
name: ti_keys [14950,14957]
===
match
---
name: cached_work [24932,24943]
name: cached_work [24845,24856]
===
match
---
string: "smart_sensor_operator.loop_duration" [30042,30079]
string: "smart_sensor_operator.loop_duration" [29901,29938]
===
match
---
trailer [12053,12071]
trailer [12053,12071]
===
match
---
atom_expr [27484,27565]
atom_expr [27397,27478]
===
match
---
trailer [22286,22296]
trailer [22199,22209]
===
match
---
trailer [5128,5140]
trailer [5128,5140]
===
match
---
trailer [17241,17243]
trailer [17183,17185]
===
match
---
testlist_star_expr [19556,19587]
testlist_star_expr [19515,19546]
===
match
---
suite [29335,30481]
suite [29194,30340]
===
match
---
trailer [30288,30302]
trailer [30147,30161]
===
match
---
operator: , [7498,7499]
operator: , [7498,7499]
===
match
---
suite [7042,7264]
suite [7042,7264]
===
match
---
string: "Task %s failed by exceptions." [23160,23191]
string: "Task %s failed by exceptions." [23073,23104]
===
match
---
argument [27688,27699]
argument [27601,27612]
===
match
---
atom_expr [9173,9195]
atom_expr [9173,9195]
===
match
---
name: info [29596,29600]
name: info [29455,29459]
===
match
---
suite [29787,29843]
suite [29646,29702]
===
match
---
atom_expr [28025,28057]
atom_expr [27938,27970]
===
match
---
name: self [12120,12124]
name: self [12120,12124]
===
match
---
number: 0 [27956,27957]
number: 0 [27869,27870]
===
match
---
name: shardcode [13059,13068]
name: shardcode [13059,13068]
===
match
---
name: timezone [1239,1247]
name: timezone [1239,1247]
===
match
---
expr_stmt [3049,3123]
expr_stmt [3049,3123]
===
match
---
name: sensor_work [19344,19355]
name: sensor_work [19303,19314]
===
match
---
name: state [23504,23509]
name: state [23417,23422]
===
match
---
string: 'timeout' [21509,21518]
string: 'timeout' [21422,21431]
===
match
---
name: self [4505,4509]
name: self [4505,4509]
===
match
---
suite [22381,23270]
suite [22294,23183]
===
match
---
param [27798,27802]
param [27711,27715]
===
match
---
name: len [29713,29716]
name: len [29572,29575]
===
match
---
operator: , [15310,15311]
operator: , [15252,15253]
===
match
---
trailer [14496,14511]
trailer [14438,14453]
===
match
---
name: x [14517,14518]
name: x [14459,14460]
===
match
---
name: _handle_poke_exception [21963,21985]
name: _handle_poke_exception [21876,21898]
===
match
---
operator: = [3496,3497]
operator: = [3496,3497]
===
match
---
string: 'handlers' [1706,1716]
string: 'handlers' [1706,1716]
===
match
---
atom_expr [13205,13219]
atom_expr [13205,13219]
===
match
---
atom_expr [30278,30314]
atom_expr [30137,30173]
===
match
---
simple_stmt [27710,27772]
simple_stmt [27623,27685]
===
match
---
operator: = [25959,25960]
operator: = [25872,25873]
===
match
---
trailer [27048,27050]
trailer [26961,26963]
===
match
---
name: si [3168,3170]
name: si [3168,3170]
===
match
---
trailer [25968,25998]
trailer [25881,25911]
===
match
---
trailer [20983,21003]
trailer [20942,20962]
===
match
---
expr_stmt [6732,6771]
expr_stmt [6732,6771]
===
match
---
name: try_number [18776,18786]
name: try_number [18735,18745]
===
match
---
name: si [5137,5139]
name: si [5137,5139]
===
match
---
trailer [18644,18662]
trailer [18577,18621]
===
match
---
expr_stmt [24211,24244]
expr_stmt [24124,24157]
===
match
---
name: state [17208,17213]
name: state [17150,17155]
===
match
---
atom_expr [3836,3855]
atom_expr [3836,3855]
===
match
---
atom_expr [9356,9388]
atom_expr [9356,9388]
===
match
---
if_stmt [30520,30599]
if_stmt [30379,30458]
===
match
---
trailer [25323,25343]
trailer [25236,25256]
===
match
---
operator: @ [14138,14139]
operator: @ [14080,14081]
===
match
---
name: self [6896,6900]
name: self [6896,6900]
===
match
---
simple_stmt [8707,8745]
simple_stmt [8707,8745]
===
match
---
operator: = [19654,19655]
operator: = [19613,19614]
===
match
---
name: self [29769,29773]
name: self [29628,29632]
===
match
---
operator: @ [3947,3948]
operator: @ [3947,3948]
===
match
---
trailer [3170,3188]
trailer [3170,3188]
===
match
---
name: logger [5078,5084]
name: logger [5078,5084]
===
match
---
funcdef [8905,9389]
funcdef [8905,9389]
===
match
---
name: sensor_task [27659,27670]
name: sensor_task [27572,27583]
===
match
---
trailer [30419,30424]
trailer [30278,30283]
===
match
---
name: logger [5412,5418]
name: logger [5412,5418]
===
match
---
trailer [12009,12034]
trailer [12009,12034]
===
match
---
atom_expr [6462,6478]
atom_expr [6462,6478]
===
match
---
name: tuple_ [967,973]
name: tuple_ [967,973]
===
match
---
name: state [20668,20673]
name: state [20627,20632]
===
match
---
name: ti [16908,16910]
name: ti [16850,16852]
===
match
---
operator: , [24677,24678]
operator: , [24590,24591]
===
match
---
name: self [11968,11972]
name: self [11968,11972]
===
match
---
atom_expr [4713,4719]
atom_expr [4713,4719]
===
match
---
atom_expr [8753,8775]
atom_expr [8753,8775]
===
match
---
name: to_flush [7187,7195]
name: to_flush [7187,7195]
===
match
---
return_stmt [5804,5857]
return_stmt [5804,5857]
===
match
---
string: "smart_sensor_operator.poked_success" [28797,28834]
string: "smart_sensor_operator.poked_success" [28710,28747]
===
match
---
trailer [24768,24781]
trailer [24681,24694]
===
match
---
atom_expr [23798,23844]
atom_expr [23711,23757]
===
match
---
trailer [16957,16963]
trailer [16899,16905]
===
match
---
name: timing [30035,30041]
name: timing [29894,29900]
===
match
---
arith_expr [30331,30361]
arith_expr [30190,30220]
===
match
---
atom_expr [21057,21127]
atom_expr [21011,21096]
===
match
---
name: SensorInstance [19656,19670]
name: SensorInstance [19615,19629]
===
match
---
name: set_duration [16020,16032]
name: set_duration [15962,15974]
===
match
---
suite [26207,26375]
suite [26120,26288]
===
match
---
suite [9293,9389]
suite [9293,9389]
===
match
---
atom_expr [28868,28942]
atom_expr [28781,28855]
===
match
---
suite [27051,27199]
suite [26964,27112]
===
match
---
simple_stmt [20371,20399]
simple_stmt [20330,20358]
===
match
---
trailer [14937,14946]
trailer [14879,14888]
===
match
---
arglist [30115,30177]
arglist [29974,30036]
===
match
---
trailer [14104,14117]
trailer [14046,14059]
===
match
---
param [5719,5723]
param [5719,5723]
===
match
---
import_from [909,931]
import_from [909,931]
===
match
---
name: sensor_task [27447,27458]
name: sensor_task [27360,27371]
===
match
---
expr_stmt [6436,6453]
expr_stmt [6436,6453]
===
match
---
string: "Exception _mark_multi_state in smart sensor for hashcode %s" [17337,17398]
string: "Exception _mark_multi_state in smart sensor for hashcode %s" [17291,17352]
===
match
---
operator: = [16716,16717]
operator: = [16658,16659]
===
match
---
atom_expr [6732,6751]
atom_expr [6732,6751]
===
match
---
trailer [8873,8897]
trailer [8873,8897]
===
match
---
trailer [22363,22380]
trailer [22276,22293]
===
match
---
except_clause [25637,25658]
except_clause [25550,25571]
===
match
---
trailer [11875,11898]
trailer [11875,11898]
===
match
---
atom_expr [3389,3397]
atom_expr [3389,3397]
===
match
---
trailer [16599,16608]
trailer [16541,16550]
===
match
---
atom_expr [27673,27700]
atom_expr [27586,27613]
===
match
---
atom_expr [3806,3819]
atom_expr [3806,3819]
===
match
---
atom [7199,7240]
atom [7199,7240]
===
match
---
name: first [20263,20268]
name: first [20222,20227]
===
match
---
name: ti_key [19479,19485]
name: ti_key [19438,19444]
===
match
---
if_stmt [10051,10106]
if_stmt [10051,10106]
===
match
---
try_stmt [13624,13891]
try_stmt [13624,13833]
===
match
---
name: state [6710,6715]
name: state [6710,6715]
===
match
---
atom_expr [2908,2917]
atom_expr [2908,2917]
===
match
---
name: sensor_work [23134,23145]
name: sensor_work [23047,23058]
===
match
---
operator: , [14771,14772]
operator: , [14713,14714]
===
match
---
name: config [862,868]
name: config [862,868]
===
match
---
name: self [10141,10145]
name: self [10141,10145]
===
match
---
name: count_poke_exception [28921,28941]
name: count_poke_exception [28834,28854]
===
match
---
atom_expr [2960,2979]
atom_expr [2960,2979]
===
match
---
name: ti [17205,17207]
name: ti [17147,17149]
===
match
---
name: max_tis_per_query [12054,12071]
name: max_tis_per_query [12054,12071]
===
match
---
arglist [26307,26356]
arglist [26220,26269]
===
match
---
dotted_name [1253,1277]
dotted_name [1253,1277]
===
match
---
trailer [27728,27740]
trailer [27641,27653]
===
match
---
trailer [20656,20662]
trailer [20615,20621]
===
match
---
param [11500,11516]
param [11500,11516]
===
match
---
expr_stmt [29856,29920]
expr_stmt [29715,29779]
===
match
---
arglist [13914,13953]
arglist [13856,13895]
===
match
---
operator: , [13934,13935]
operator: , [13876,13877]
===
match
---
arglist [13783,13836]
arglist [13778,13831]
===
match
---
atom_expr [3460,3473]
atom_expr [3460,3473]
===
match
---
name: e [25657,25658]
name: e [25570,25571]
===
match
---
trailer [28029,28048]
trailer [27942,27961]
===
match
---
name: context [29326,29333]
name: context [29185,29192]
===
match
---
name: cached_work [26755,26766]
name: cached_work [26668,26679]
===
match
---
arglist [19160,19169]
arglist [19119,19128]
===
match
---
trailer [24024,24031]
trailer [23937,23944]
===
match
---
atom_expr [16922,16935]
atom_expr [16864,16877]
===
match
---
name: isinstance [12242,12252]
name: isinstance [12242,12252]
===
match
---
name: reduce_in_chunks [15042,15058]
name: reduce_in_chunks [14984,15000]
===
match
---
name: _is_infra_failure [10063,10080]
name: _is_infra_failure [10063,10080]
===
match
---
operator: = [17651,17652]
operator: = [17660,17661]
===
match
---
atom_expr [16496,16504]
atom_expr [16438,16446]
===
match
---
name: cache_key [23074,23083]
name: cache_key [22987,22996]
===
match
---
operator: = [11768,11769]
operator: = [11768,11769]
===
match
---
comparison [12290,12312]
comparison [12290,12312]
===
match
---
name: encoded_poke_context [16840,16860]
name: encoded_poke_context [16782,16802]
===
match
---
atom_expr [14773,14783]
atom_expr [14715,14725]
===
match
---
atom_expr [5189,5212]
atom_expr [5189,5212]
===
match
---
name: state [15937,15942]
name: state [15879,15884]
===
match
---
name: __init__ [6412,6420]
name: __init__ [6412,6420]
===
match
---
suite [24526,24717]
suite [24439,24630]
===
match
---
atom_expr [4814,4824]
atom_expr [4814,4824]
===
match
---
name: self [30498,30502]
name: self [30357,30361]
===
match
---
trailer [30346,30348]
trailer [30205,30207]
===
match
---
operator: == [16609,16611]
operator: == [16551,16553]
===
match
---
atom_expr [14919,14930]
atom_expr [14861,14872]
===
match
---
if_stmt [27064,27199]
if_stmt [26977,27112]
===
match
---
atom_expr [29197,29253]
atom_expr [29105,29161]
===
match
---
param [7508,7523]
param [7508,7523]
===
match
---
comparison [23523,23548]
comparison [23436,23461]
===
match
---
name: sensor_work [19467,19478]
name: sensor_work [19426,19437]
===
match
---
operator: , [21990,21991]
operator: , [21903,21904]
===
match
---
name: self [3442,3446]
name: self [3442,3446]
===
match
---
name: formatter [4342,4351]
name: formatter [4342,4351]
===
match
---
parameters [7974,8020]
parameters [7974,8020]
===
match
---
name: _is_infra_failure [9896,9913]
name: _is_infra_failure [9896,9913]
===
match
---
operator: > [10139,10140]
operator: > [10139,10140]
===
match
---
name: flush_cached_sensor_poke_results [26624,26656]
name: flush_cached_sensor_poke_results [26537,26569]
===
match
---
trailer [4229,4232]
trailer [4229,4232]
===
match
---
string: "Sensing ti: %s" [24091,24107]
string: "Sensing ti: %s" [24004,24020]
===
match
---
trailer [27554,27562]
trailer [27467,27475]
===
match
---
name: self [12457,12461]
name: self [12457,12461]
===
match
---
trailer [24453,24472]
trailer [24366,24385]
===
match
---
operator: , [17559,17560]
operator: , [17568,17569]
===
match
---
param [21992,22003]
param [21905,21916]
===
match
---
name: cached_sensor_exceptions [26182,26206]
name: cached_sensor_exceptions [26095,26119]
===
match
---
expr_stmt [19205,19228]
expr_stmt [19164,19187]
===
match
---
trailer [13664,13680]
trailer [13664,13680]
===
match
---
name: infra_failure_retry_window [7564,7590]
name: infra_failure_retry_window [7564,7590]
===
match
---
atom_expr [26224,26374]
atom_expr [26137,26287]
===
match
---
name: other [3806,3811]
name: other [3806,3811]
===
match
---
name: poke_timeout [24769,24781]
name: poke_timeout [24682,24694]
===
match
---
string: 'email_on_failure' [19303,19321]
string: 'email_on_failure' [19262,19280]
===
match
---
funcdef [9394,9608]
funcdef [9394,9608]
===
match
---
name: info [19424,19428]
name: info [19383,19387]
===
match
---
operator: = [8728,8729]
operator: = [8728,8729]
===
match
---
import_name [805,816]
import_name [805,816]
===
match
---
atom_expr [18724,18768]
atom_expr [18683,18727]
===
match
---
simple_stmt [26409,26561]
simple_stmt [26322,26474]
===
match
---
operator: = [21833,21834]
operator: = [21746,21747]
===
match
---
trailer [29942,29947]
trailer [29801,29806]
===
match
---
trailer [23316,23377]
trailer [23229,23290]
===
match
---
operator: += [17086,17088]
operator: += [17028,17030]
===
match
---
name: SI [19782,19784]
name: SI [19741,19743]
===
match
---
trailer [26438,26449]
trailer [26351,26362]
===
match
---
atom_expr [9580,9607]
atom_expr [9580,9607]
===
match
---
expr_stmt [6529,6550]
expr_stmt [6529,6550]
===
match
---
trailer [13782,13837]
trailer [13777,13832]
===
match
---
name: hostname [14922,14930]
name: hostname [14864,14872]
===
match
---
trailer [30114,30178]
trailer [29973,30037]
===
match
---
simple_stmt [5680,5689]
simple_stmt [5680,5689]
===
match
---
name: min [21684,21687]
name: min [21597,21600]
===
match
---
simple_stmt [28868,28943]
simple_stmt [28781,28856]
===
match
---
atom_expr [28185,28202]
atom_expr [28098,28115]
===
match
---
trailer [19423,19428]
trailer [19382,19387]
===
match
---
trailer [3410,3419]
trailer [3410,3419]
===
match
---
name: end_date [15981,15989]
name: end_date [15923,15931]
===
match
---
arglist [15059,15124]
arglist [15001,15066]
===
match
---
trailer [5231,5236]
trailer [5231,5236]
===
match
---
name: self [30159,30163]
name: self [30018,30022]
===
match
---
if_stmt [15134,15208]
if_stmt [15076,15150]
===
match
---
operator: , [11536,11537]
operator: , [11536,11537]
===
match
---
operator: = [21565,21566]
operator: = [21478,21479]
===
match
---
name: self [2894,2898]
name: self [2894,2898]
===
match
---
name: sqlalchemy [938,948]
name: sqlalchemy [938,948]
===
match
---
name: cached_sensor_exceptions [25583,25607]
name: cached_sensor_exceptions [25496,25520]
===
match
---
parameters [5718,5724]
parameters [5718,5724]
===
match
---
param [6570,6575]
param [6570,6575]
===
match
---
comparison [30231,30260]
comparison [30090,30119]
===
match
---
atom_expr [3100,3115]
atom_expr [3100,3115]
===
match
---
parameters [21221,21240]
parameters [21134,21153]
===
match
---
name: dag_id [2911,2917]
name: dag_id [2911,2917]
===
match
---
name: self [17473,17477]
name: self [17482,17486]
===
match
---
trailer [28196,28202]
trailer [28109,28115]
===
match
---
name: sensor_work [24013,24024]
name: sensor_work [23926,23937]
===
match
---
atom_expr [13120,13131]
atom_expr [13120,13131]
===
match
---
name: self [29320,29324]
name: self [29179,29183]
===
match
---
trailer [13027,13037]
trailer [13027,13037]
===
match
---
trailer [24112,24120]
trailer [24025,24033]
===
match
---
atom_expr [21759,21781]
atom_expr [21672,21694]
===
match
---
name: utcnow [10130,10136]
name: utcnow [10130,10136]
===
match
---
name: property [5695,5703]
name: property [5695,5703]
===
match
---
operator: = [13584,13585]
operator: = [13584,13585]
===
match
---
trailer [26894,26905]
trailer [26807,26818]
===
match
---
name: k [4131,4132]
name: k [4131,4132]
===
match
---
trailer [16733,16735]
trailer [16675,16677]
===
match
---
operator: , [23489,23490]
operator: , [23402,23403]
===
match
---
trailer [14052,14072]
trailer [13994,14014]
===
match
---
name: get_hostname [5332,5344]
name: get_hostname [5332,5344]
===
match
---
simple_stmt [23134,23213]
simple_stmt [23047,23126]
===
match
---
trailer [28531,28548]
trailer [28444,28461]
===
match
---
trailer [4148,4151]
trailer [4148,4151]
===
match
---
simple_stmt [20805,20956]
simple_stmt [20764,20915]
===
match
---
name: Stats [28955,28960]
name: Stats [28868,28873]
===
match
---
name: op_classpath [27621,27633]
name: op_classpath [27534,27546]
===
match
---
name: sensor_works [30001,30013]
name: sensor_works [29860,29872]
===
match
---
name: handler [4268,4275]
name: handler [4268,4275]
===
match
---
name: count_marked [17073,17085]
name: count_marked [17015,17027]
===
match
---
name: append [13658,13664]
name: append [13658,13664]
===
match
---
operator: , [11515,11516]
operator: , [11515,11516]
===
match
---
atom_expr [22347,22380]
atom_expr [22260,22293]
===
match
---
name: sensor_work [23933,23944]
name: sensor_work [23846,23857]
===
match
---
simple_stmt [28955,29037]
simple_stmt [28868,28950]
===
match
---
name: session [20771,20778]
name: session [20730,20737]
===
match
---
trailer [24376,24395]
trailer [24289,24308]
===
match
---
simple_stmt [4268,4334]
simple_stmt [4268,4334]
===
match
---
name: state [17197,17202]
name: state [17139,17144]
===
match
---
arglist [21081,21126]
arglist [21035,21095]
===
match
---
simple_stmt [26048,26088]
simple_stmt [25961,26001]
===
match
---
trailer [22463,22473]
trailer [22376,22386]
===
match
---
atom_expr [4878,4896]
atom_expr [4878,4896]
===
match
---
funcdef [17594,21184]
funcdef [17603,21097]
===
match
---
for_stmt [14888,14947]
for_stmt [14830,14889]
===
match
---
name: FAILED [19222,19228]
name: FAILED [19181,19187]
===
match
---
suite [17307,17465]
suite [17244,17474]
===
match
---
trailer [16019,16032]
trailer [15961,15974]
===
match
---
dotted_name [1177,1190]
dotted_name [1177,1190]
===
match
---
operator: >= [13069,13071]
operator: >= [13069,13071]
===
match
---
operator: } [12038,12039]
operator: } [12038,12039]
===
match
---
param [7036,7040]
param [7036,7040]
===
match
---
trailer [17328,17336]
trailer [17265,17273]
===
match
---
name: line_break [5385,5395]
name: line_break [5385,5395]
===
match
---
comp_op [24514,24520]
comp_op [24427,24433]
===
match
---
trailer [9351,9353]
trailer [9351,9353]
===
match
---
name: loads [3074,3079]
name: loads [3074,3079]
===
match
---
name: _retry_or_fail_task [21914,21933]
name: _retry_or_fail_task [21827,21846]
===
match
---
trailer [19062,19066]
trailer [19021,19025]
===
match
---
comp_if [14008,14037]
comp_if [13950,13979]
===
match
---
operator: = [29398,29399]
operator: = [29257,29258]
===
match
---
trailer [12425,12453]
trailer [12425,12453]
===
match
---
name: state [16958,16963]
name: state [16900,16905]
===
match
---
name: count_marked [16099,16111]
name: count_marked [16041,16053]
===
match
---
with_stmt [12865,13132]
with_stmt [12865,13132]
===
match
---
trailer [21933,21953]
trailer [21846,21866]
===
match
---
atom_expr [24065,24073]
atom_expr [23978,23986]
===
match
---
name: self [9706,9710]
name: self [9706,9710]
===
match
---
import_from [1172,1203]
import_from [1172,1203]
===
match
---
name: info [23578,23582]
name: info [23491,23495]
===
match
---
name: execute [29312,29319]
name: execute [29171,29178]
===
match
---
name: ti_key [24113,24119]
name: ti_key [24026,24032]
===
match
---
trailer [24953,24971]
trailer [24866,24884]
===
match
---
name: count [14579,14584]
name: count [14521,14526]
===
match
---
expr_stmt [12085,12111]
expr_stmt [12085,12111]
===
match
---
name: items [27519,27524]
name: items [27432,27437]
===
match
---
name: utcnow [6763,6769]
name: utcnow [6763,6769]
===
match
---
atom_expr [14020,14037]
atom_expr [13962,13979]
===
match
---
atom_expr [18844,18852]
atom_expr [18803,18811]
===
match
---
atom_expr [24082,24121]
atom_expr [23995,24034]
===
match
---
name: timeout [12431,12438]
name: timeout [12431,12438]
===
match
---
name: x [14474,14475]
name: x [14416,14417]
===
match
---
trailer [11796,11806]
trailer [11796,11806]
===
match
---
name: sensor_instance [17181,17196]
name: sensor_instance [17123,17138]
===
match
---
trailer [19784,19792]
trailer [19743,19751]
===
match
---
operator: = [11807,11808]
operator: = [11807,11808]
===
match
---
name: values [28049,28055]
name: values [27962,27968]
===
match
---
name: ti_key [5712,5718]
name: ti_key [5712,5718]
===
match
---
string: """Mark this poke work to be popped from cached dict after current loop.""" [6911,6986]
string: """Mark this poke work to be popped from cached dict after current loop.""" [6911,6986]
===
match
---
name: TI [14723,14725]
name: TI [14665,14667]
===
match
---
expr_stmt [24435,24483]
expr_stmt [24348,24396]
===
match
---
name: self [24622,24626]
name: self [24535,24539]
===
match
---
string: "smart_sensor_operator.poked_tasks" [28724,28759]
string: "smart_sensor_operator.poked_tasks" [28637,28672]
===
match
---
trailer [28493,28510]
trailer [28406,28423]
===
match
---
arglist [26493,26542]
arglist [26406,26455]
===
match
---
name: poke_context [3593,3605]
name: poke_context [3593,3605]
===
match
---
name: log [24058,24061]
name: log [23971,23974]
===
match
---
trailer [10179,10189]
trailer [10179,10189]
===
match
---
name: cache_key [26439,26448]
name: cache_key [26352,26361]
===
match
---
atom_expr [19344,19386]
atom_expr [19303,19345]
===
match
---
trailer [4312,4333]
trailer [4312,4333]
===
match
---
operator: = [16154,16155]
operator: = [16096,16097]
===
match
---
name: cache_key [23024,23033]
name: cache_key [22937,22946]
===
match
---
name: SI [19651,19653]
name: SI [19610,19612]
===
match
---
operator: , [4812,4813]
operator: , [4812,4813]
===
match
---
name: fail_current_run [22364,22380]
name: fail_current_run [22277,22293]
===
match
---
param [23504,23509]
param [23417,23422]
===
match
---
operator: = [4128,4129]
operator: = [4128,4129]
===
match
---
name: TI [14773,14775]
name: TI [14715,14717]
===
match
---
atom [12273,12285]
atom [12273,12285]
===
match
---
operator: , [5822,5823]
operator: , [5822,5823]
===
match
---
name: sensor_work [25312,25323]
name: sensor_work [25225,25236]
===
match
---
trailer [10062,10080]
trailer [10062,10080]
===
match
---
if_stmt [30327,30481]
if_stmt [30186,30340]
===
match
---
funcdef [6879,7016]
funcdef [6879,7016]
===
match
---
operator: = [2906,2907]
operator: = [2906,2907]
===
match
---
name: op_classpath [3523,3535]
name: op_classpath [3523,3535]
===
match
---
name: SI [12837,12839]
name: SI [12837,12839]
===
match
---
trailer [28630,28647]
trailer [28543,28560]
===
match
---
operator: , [28834,28835]
operator: , [28747,28748]
===
match
---
name: Exception [13700,13709]
name: Exception [13700,13709]
===
match
---
atom_expr [26409,26449]
atom_expr [26322,26362]
===
match
---
suite [6799,6874]
suite [6799,6874]
===
match
---
name: count_exception_failures [29011,29035]
name: count_exception_failures [28924,28948]
===
match
---
trailer [26413,26438]
trailer [26326,26351]
===
match
---
name: ti [18704,18706]
name: ti [18663,18665]
===
match
---
name: x [13990,13991]
name: x [13932,13933]
===
match
---
funcdef [23442,23946]
funcdef [23355,23859]
===
match
---
trailer [28447,28454]
trailer [28360,28367]
===
match
---
name: self [29996,30000]
name: self [29855,29859]
===
match
---
name: NOT_LANDED [25482,25492]
name: NOT_LANDED [25395,25405]
===
match
---
atom_expr [15978,15989]
atom_expr [15920,15931]
===
match
---
name: self [13764,13768]
name: self [13759,13763]
===
match
---
atom_expr [3896,3911]
atom_expr [3896,3911]
===
match
---
expr_stmt [4108,4176]
expr_stmt [4108,4176]
===
match
---
trailer [5084,5095]
trailer [5084,5095]
===
match
---
atom_expr [20911,20929]
atom_expr [20870,20888]
===
match
---
trailer [24665,24697]
trailer [24578,24610]
===
match
---
name: duration [30231,30239]
name: duration [30090,30098]
===
match
---
string: '__main__' [30535,30545]
string: '__main__' [30394,30404]
===
match
---
operator: = [14439,14440]
operator: = [14381,14382]
===
match
---
expr_stmt [13114,13131]
expr_stmt [13114,13131]
===
match
---
name: execution_context [18961,18978]
name: execution_context [18920,18937]
===
match
---
name: self [13072,13076]
name: self [13072,13076]
===
match
---
name: execution_context [19356,19373]
name: execution_context [19315,19332]
===
match
---
name: self [5811,5815]
name: self [5811,5815]
===
match
---
arglist [29601,29649]
arglist [29460,29508]
===
match
---
name: sensor_exception [27067,27083]
name: sensor_exception [26980,26996]
===
match
---
name: e [3314,3315]
name: e [3314,3315]
===
match
---
name: TI [16188,16190]
name: TI [16130,16132]
===
match
---
operator: , [14584,14585]
operator: , [14526,14527]
===
match
---
operator: = [12135,12136]
operator: = [12135,12136]
===
match
---
name: cached_sensor_exceptions [27156,27180]
name: cached_sensor_exceptions [27069,27093]
===
match
---
trailer [13058,13068]
trailer [13058,13068]
===
match
---
atom_expr [20324,20332]
atom_expr [20283,20291]
===
match
---
name: is_expired [26837,26847]
name: is_expired [26750,26760]
===
match
---
atom_expr [20088,20270]
atom_expr [20047,20229]
===
match
---
trailer [26890,26894]
trailer [26803,26807]
===
match
---
return_stmt [3725,3941]
return_stmt [3725,3941]
===
match
---
name: sensor_works [30164,30176]
name: sensor_works [30023,30035]
===
match
---
trailer [19281,19339]
trailer [19240,19298]
===
match
---
name: filter [16540,16546]
name: filter [16482,16488]
===
match
---
name: sensor_instance [20641,20656]
name: sensor_instance [20600,20615]
===
match
---
decorator [5863,5873]
decorator [5863,5873]
===
match
---
name: cached_dedup_works [11973,11991]
name: cached_dedup_works [11973,11991]
===
match
---
simple_stmt [3482,3510]
simple_stmt [3482,3510]
===
match
---
expr_stmt [12005,12039]
expr_stmt [12005,12039]
===
match
---
name: ti [16017,16019]
name: ti [15959,15961]
===
match
---
expr_stmt [24040,24073]
expr_stmt [23953,23986]
===
match
---
number: 0 [15099,15100]
number: 0 [15041,15042]
===
match
---
name: _is_infra_failure [9178,9195]
name: _is_infra_failure [9178,9195]
===
match
---
number: 0 [27878,27879]
number: 0 [27791,27792]
===
match
---
name: _execute_sensor_work [29809,29829]
name: _execute_sensor_work [29668,29688]
===
match
---
operator: = [3370,3371]
operator: = [3370,3371]
===
match
---
string: """Return logger for a sensor instance object.""" [4524,4573]
string: """Return logger for a sensor instance object.""" [4524,4573]
===
match
---
comparison [19761,19780]
comparison [19720,19739]
===
match
---
name: TI [16072,16074]
name: TI [16014,16016]
===
match
---
operator: } [30596,30597]
operator: } [30455,30456]
===
match
---
simple_stmt [14989,15017]
simple_stmt [14931,14959]
===
match
---
operator: , [15303,15304]
operator: , [15245,15246]
===
match
---
atom_expr [26002,26035]
atom_expr [25915,25948]
===
match
---
return_stmt [9699,9726]
return_stmt [9699,9726]
===
match
---
expr_stmt [27647,27700]
expr_stmt [27560,27613]
===
match
---
atom_expr [12253,12271]
atom_expr [12253,12271]
===
match
---
operator: = [1697,1698]
operator: = [1697,1698]
===
match
---
name: ti_key [26978,26984]
name: ti_key [26891,26897]
===
match
---
name: self [25578,25582]
name: self [25491,25495]
===
match
---
arglist [30042,30089]
arglist [29901,29948]
===
match
---
trailer [15041,15058]
trailer [14983,15000]
===
match
---
name: or_ [14751,14754]
name: or_ [14693,14696]
===
match
---
while_stmt [29423,30481]
while_stmt [29282,30340]
===
match
---
atom [30330,30362]
atom [30189,30221]
===
match
---
name: SI [16496,16498]
name: SI [16438,16440]
===
match
---
name: sensor_work [18619,18630]
name: sensor_work [18554,18565]
===
match
---
file_input [789,30599]
file_input [789,30458]
===
match
---
simple_stmt [13900,13955]
simple_stmt [13842,13897]
===
match
---
name: close_sensor_logger [5428,5447]
name: close_sensor_logger [5428,5447]
===
match
---
name: import_string [1648,1661]
name: import_string [1648,1661]
===
match
---
name: self [9257,9261]
name: self [9257,9261]
===
match
---
name: State [16967,16972]
name: State [16909,16914]
===
match
---
parameters [7484,7629]
parameters [7484,7629]
===
match
---
name: task_id [16358,16365]
name: task_id [16300,16307]
===
match
---
name: self [26409,26413]
name: self [26322,26326]
===
match
---
name: self [12005,12009]
name: self [12005,12009]
===
match
---
name: gauge [29055,29060]
name: gauge [28968,28973]
===
match
---
name: sensor_works [13995,14007]
name: sensor_works [13937,13949]
===
match
---
expr_stmt [14685,14874]
expr_stmt [14627,14816]
===
match
---
name: state [28197,28202]
name: state [28110,28115]
===
match
---
trailer [10189,10201]
trailer [10189,10201]
===
match
---
simple_stmt [4771,4908]
simple_stmt [4771,4908]
===
match
---
simple_stmt [20581,20599]
simple_stmt [20540,20558]
===
match
---
simple_stmt [14048,14091]
simple_stmt [13990,14033]
===
match
---
simple_stmt [5373,5397]
simple_stmt [5373,5397]
===
match
---
operator: , [19521,19522]
operator: , [19480,19481]
===
match
---
param [9934,9938]
param [9934,9938]
===
match
---
operator: = [2980,2981]
operator: = [2980,2981]
===
match
---
name: hashcode [3425,3433]
name: hashcode [3425,3433]
===
match
---
trailer [16539,16546]
trailer [16481,16488]
===
match
---
name: ti [14892,14894]
name: ti [14834,14836]
===
match
---
parameters [5890,5896]
parameters [5890,5896]
===
match
---
name: ti [13676,13678]
name: ti [13676,13678]
===
match
---
name: cache_key [24396,24405]
name: cache_key [24309,24318]
===
match
---
string: """         The cached task object expires if there is no poke for 20 minutes.         :return: Boolean         """ [7051,7166]
string: """         The cached task object expires if there is no poke for 20 minutes.         :return: Boolean         """ [7051,7166]
===
match
---
trailer [19119,19126]
trailer [19078,19085]
===
match
---
name: airflow [1177,1184]
name: airflow [1177,1184]
===
match
---
name: self [12085,12089]
name: self [12085,12089]
===
match
---
atom_expr [29867,29920]
atom_expr [29726,29779]
===
match
---
name: sensor_work [29754,29765]
name: sensor_work [29613,29624]
===
match
---
trailer [20326,20332]
trailer [20285,20291]
===
match
---
name: hashcode [19948,19956]
name: hashcode [19907,19915]
===
match
---
arglist [20847,20937]
arglist [20806,20896]
===
match
---
argument [21169,21182]
argument [21082,21095]
===
match
---
atom_expr [7182,7195]
atom_expr [7182,7195]
===
match
---
trailer [23876,23891]
trailer [23789,23804]
===
match
---
simple_stmt [3406,3434]
simple_stmt [3406,3434]
===
match
---
atom_expr [27151,27198]
atom_expr [27064,27111]
===
match
---
trailer [11913,11922]
trailer [11913,11922]
===
match
---
trailer [7894,7911]
trailer [7894,7911]
===
match
---
operator: = [17035,17036]
operator: = [16977,16978]
===
match
---
trailer [20744,20750]
trailer [20703,20709]
===
match
---
string: """         Set state for cached poke work.         :param state: The sensor_instance state.         """ [6592,6696]
string: """         Set state for cached poke work.         :param state: The sensor_instance state.         """ [6592,6696]
===
match
---
trailer [19858,19874]
trailer [19817,19833]
===
match
---
name: _check_and_handle_ti_timeout [25519,25547]
name: _check_and_handle_ti_timeout [25432,25460]
===
match
---
atom_expr [13141,13220]
atom_expr [13141,13220]
===
match
---
expr_stmt [14436,14453]
expr_stmt [14378,14395]
===
match
---
trailer [27505,27518]
trailer [27418,27431]
===
match
---
simple_stmt [27472,27566]
simple_stmt [27385,27479]
===
match
---
arglist [24666,24696]
arglist [24579,24609]
===
match
---
operator: == [23693,23695]
operator: == [23606,23608]
===
match
---
dotted_name [980,998]
dotted_name [980,998]
===
match
---
trailer [25607,25611]
trailer [25520,25524]
===
match
---
if_stmt [21735,21954]
if_stmt [21648,21867]
===
match
---
name: module_loading [1418,1432]
name: module_loading [1418,1432]
===
match
---
trailer [17403,17414]
trailer [17373,17384]
===
match
---
name: session [20690,20697]
name: session [20649,20656]
===
match
---
operator: , [23502,23503]
operator: , [23415,23416]
===
match
---
name: set_latest_exception [26265,26285]
name: set_latest_exception [26178,26198]
===
match
---
atom_expr [6754,6771]
atom_expr [6754,6771]
===
match
---
comparison [23687,23716]
comparison [23600,23629]
===
match
---
name: json [812,816]
name: json [812,816]
===
match
---
name: TI [19621,19623]
name: TI [19580,19582]
===
match
---
simple_stmt [20065,20285]
simple_stmt [20024,20244]
===
match
---
operator: , [19465,19466]
operator: , [19424,19425]
===
match
---
trailer [3811,3819]
trailer [3811,3819]
===
match
---
name: __init__ [7476,7484]
name: __init__ [7476,7484]
===
match
---
string: """         Create task log handler for a sensor work.         :return: log handler         """ [4004,4099]
string: """         Create task log handler for a sensor work.         :return: log handler         """ [4004,4099]
===
match
---
trailer [24133,24138]
trailer [24046,24051]
===
match
---
operator: , [17622,17623]
operator: , [17631,17632]
===
match
---
operator: = [14931,14932]
operator: = [14873,14874]
===
match
---
operator: @ [11370,11371]
operator: @ [11370,11371]
===
match
---
name: cached_work [27647,27658]
name: cached_work [27560,27571]
===
match
---
operator: = [3024,3025]
operator: = [3024,3025]
===
match
---
string: 'email' [19004,19011]
string: 'email' [18963,18970]
===
match
---
expr_stmt [16099,16115]
expr_stmt [16041,16057]
===
match
---
atom_expr [26940,26957]
atom_expr [26853,26870]
===
match
---
name: copy [27036,27040]
name: copy [26949,26953]
===
match
---
trailer [21596,21600]
trailer [21509,21513]
===
match
---
name: execution_context [18736,18753]
name: execution_context [18695,18712]
===
match
---
string: "Exception at creating sensor work for ti %s" [13783,13828]
string: "Exception at creating sensor work for ti %s" [13778,13823]
===
match
---
simple_stmt [27151,27199]
simple_stmt [27064,27112]
===
match
---
trailer [16032,16034]
trailer [15974,15976]
===
match
---
operator: , [7622,7623]
operator: , [7622,7623]
===
match
---
dotted_name [1404,1432]
dotted_name [1404,1432]
===
match
---
trailer [4989,5006]
trailer [4989,5006]
===
match
---
atom_expr [18426,18466]
atom_expr [18435,18475]
===
match
---
trailer [3167,3189]
trailer [3167,3189]
===
match
---
name: dictConfigurator [4278,4294]
name: dictConfigurator [4278,4294]
===
match
---
if_stmt [16805,16891]
if_stmt [16747,16833]
===
match
---
trailer [29388,29397]
trailer [29247,29256]
===
match
---
name: SensorWork [1956,1966]
name: SensorWork [1956,1966]
===
match
---
name: airflow [1209,1216]
name: airflow [1209,1216]
===
match
---
atom_expr [28515,28548]
atom_expr [28428,28461]
===
match
---
operator: , [11660,11661]
operator: , [11660,11661]
===
match
---
name: info [24134,24138]
name: info [24047,24051]
===
match
---
atom_expr [23867,23891]
atom_expr [23780,23804]
===
match
---
name: si [3538,3540]
name: si [3538,3540]
===
match
---
operator: , [7522,7523]
operator: , [7522,7523]
===
match
---
trailer [13024,13087]
trailer [13024,13087]
===
match
---
name: self [14100,14104]
name: self [14042,14046]
===
match
---
trailer [25052,25061]
trailer [24965,24974]
===
match
---
name: sensor_instance [15892,15907]
name: sensor_instance [15834,15849]
===
match
---
name: timer [13205,13210]
name: timer [13205,13210]
===
match
---
trailer [12159,12172]
trailer [12159,12172]
===
match
---
operator: = [13118,13119]
operator: = [13118,13119]
===
match
---
name: _ [18286,18287]
name: _ [18295,18296]
===
match
---
name: email [18358,18363]
name: email [18367,18372]
===
match
---
atom_expr [7199,7256]
atom_expr [7199,7256]
===
match
---
name: tis [13114,13117]
name: tis [13114,13117]
===
match
---
testlist_comp [4803,4896]
testlist_comp [4803,4896]
===
match
---
trailer [3446,3457]
trailer [3446,3457]
===
match
---
expr_stmt [27359,27419]
expr_stmt [27272,27332]
===
match
---
comparison [16391,16429]
comparison [16333,16371]
===
match
---
operator: , [18270,18271]
operator: , [18279,18280]
===
match
---
operator: = [11534,11535]
operator: = [11534,11535]
===
match
---
atom_expr [16967,16980]
atom_expr [16909,16922]
===
match
---
parameters [6420,6426]
parameters [6420,6426]
===
match
---
name: cached_sensor_exceptions [28423,28447]
name: cached_sensor_exceptions [28336,28360]
===
match
---
name: property [9614,9622]
name: property [9614,9622]
===
match
---
name: handle_failure [20419,20433]
name: handle_failure [20378,20392]
===
match
---
name: Stats [28868,28873]
name: Stats [28781,28786]
===
match
---
string: """         Set the time point when the sensor should be failed if it kept getting infra         failure.         :return:         """ [8950,9084]
string: """         Set the time point when the sensor should be failed if it kept getting infra         failure.         :return:         """ [8950,9084]
===
match
---
atom_expr [12120,12134]
atom_expr [12120,12134]
===
match
---
operator: = [27593,27594]
operator: = [27506,27507]
===
match
---
name: sensor_works [11942,11954]
name: sensor_works [11942,11954]
===
match
---
trailer [19159,19170]
trailer [19118,19129]
===
match
---
name: config [1699,1705]
name: config [1699,1705]
===
match
---
operator: , [17635,17636]
operator: , [17644,17645]
===
match
---
trailer [6004,6025]
trailer [6004,6025]
===
match
---
operator: = [24011,24012]
operator: = [23924,23925]
===
match
---
atom_expr [25249,25291]
atom_expr [25162,25204]
===
match
---
name: len [15004,15007]
name: len [14946,14949]
===
match
---
operator: { [3121,3122]
operator: { [3121,3122]
===
match
---
atom_expr [24168,24200]
atom_expr [24081,24113]
===
match
---
suite [24730,25629]
suite [24643,25542]
===
match
---
parameters [27797,27803]
parameters [27710,27716]
===
match
---
name: self [7685,7689]
name: self [7685,7689]
===
match
---
name: BaseOperator [1070,1082]
name: BaseOperator [1070,1082]
===
match
---
atom_expr [27746,27770]
atom_expr [27659,27683]
===
match
---
name: count_infra_failure [27970,27989]
name: count_infra_failure [27883,27902]
===
match
---
trailer [26806,26808]
trailer [26719,26721]
===
match
---
name: si [3498,3500]
name: si [3498,3500]
===
match
---
name: CachedPokeWork [6034,6048]
name: CachedPokeWork [6034,6048]
===
match
---
simple_stmt [21909,21954]
simple_stmt [21822,21867]
===
match
---
name: exception_info [26048,26062]
name: exception_info [25961,25975]
===
match
---
operator: = [17015,17016]
operator: = [16957,16958]
===
match
---
if_stmt [22344,23437]
if_stmt [22257,23350]
===
match
---
trailer [29630,29649]
trailer [29489,29508]
===
match
---
expr_stmt [3406,3433]
expr_stmt [3406,3433]
===
match
---
for_stmt [13597,13891]
for_stmt [13597,13833]
===
match
---
if_stmt [24253,24426]
if_stmt [24166,24339]
===
match
---
trailer [12348,12399]
trailer [12348,12399]
===
match
---
atom_expr [3247,3255]
atom_expr [3247,3255]
===
match
---
trailer [19763,19770]
trailer [19722,19729]
===
match
---
name: e [25969,25970]
name: e [25882,25883]
===
match
---
simple_stmt [6529,6551]
simple_stmt [6529,6551]
===
match
---
simple_stmt [22139,22215]
simple_stmt [22052,22128]
===
match
---
name: state [23858,23863]
name: state [23771,23776]
===
match
---
string: """         :return: If current exception need to be kept.         :type: boolean         """ [9949,10042]
string: """         :return: If current exception need to be kept.         :type: boolean         """ [9949,10042]
===
match
---
dotted_name [1601,1622]
dotted_name [1601,1622]
===
match
---
trailer [7208,7215]
trailer [7208,7215]
===
match
---
name: sensor_task [27729,27740]
name: sensor_task [27642,27653]
===
match
---
trailer [26871,26890]
trailer [26784,26803]
===
match
---
expr_stmt [1904,1947]
expr_stmt [1904,1947]
===
match
---
name: session [16174,16181]
name: session [16116,16123]
===
match
---
atom_expr [5035,5065]
atom_expr [5035,5065]
===
match
---
name: count_poke [27830,27840]
name: count_poke [27743,27753]
===
match
---
atom_expr [26770,26808]
atom_expr [26683,26721]
===
match
---
atom [11957,11959]
atom [11957,11959]
===
match
---
trailer [14750,14837]
trailer [14692,14779]
===
match
---
name: cached_sensor_exceptions [12010,12034]
name: cached_sensor_exceptions [12010,12034]
===
match
---
name: task_id [27555,27562]
name: task_id [27468,27475]
===
match
---
trailer [13908,13913]
trailer [13850,13855]
===
match
---
name: si [2908,2910]
name: si [2908,2910]
===
match
---
name: self [5891,5895]
name: self [5891,5895]
===
match
---
trailer [3920,3931]
trailer [3920,3931]
===
match
---
trailer [25547,25560]
trailer [25460,25473]
===
match
---
number: 50 [12074,12076]
number: 50 [12074,12076]
===
match
---
atom_expr [11638,11671]
atom_expr [11638,11671]
===
match
---
name: utcnow [21748,21754]
name: utcnow [21661,21667]
===
match
---
name: self [9934,9938]
name: self [9934,9938]
===
match
---
sync_comp_for [4233,4258]
sync_comp_for [4233,4258]
===
match
---
name: log [17325,17328]
name: log [17262,17265]
===
match
---
simple_stmt [20419,20451]
simple_stmt [20378,20410]
===
match
---
name: last_poke_time [6499,6513]
name: last_poke_time [6499,6513]
===
match
---
simple_stmt [17073,17091]
simple_stmt [17015,17033]
===
match
---
trailer [19221,19228]
trailer [19180,19187]
===
match
---
expr_stmt [4185,4259]
expr_stmt [4185,4259]
===
match
---
suite [19543,21006]
suite [19502,20965]
===
match
---
trailer [24234,24244]
trailer [24147,24157]
===
match
---
simple_stmt [21827,21852]
simple_stmt [21740,21765]
===
match
---
atom_expr [29663,29736]
atom_expr [29522,29595]
===
match
---
name: log_id [4966,4972]
name: log_id [4966,4972]
===
match
---
name: hostname [20390,20398]
name: hostname [20349,20357]
===
match
---
operator: , [19106,19107]
operator: , [19065,19066]
===
match
---
atom_expr [9706,9726]
atom_expr [9706,9726]
===
match
---
with_stmt [24743,25629]
with_stmt [24656,25542]
===
match
---
argument [11655,11660]
argument [11655,11660]
===
match
---
simple_stmt [7806,7841]
simple_stmt [7806,7841]
===
match
---
trailer [20373,20382]
trailer [20332,20341]
===
match
---
classdef [10204,30518]
classdef [10204,30377]
===
match
---
return_stmt [5405,5418]
return_stmt [5405,5418]
===
match
---
trailer [9575,9577]
trailer [9575,9577]
===
match
---
operator: == [16303,16305]
operator: == [16245,16247]
===
match
---
atom_expr [24372,24406]
atom_expr [24285,24319]
===
match
---
operator: - [29886,29887]
operator: - [29745,29746]
===
match
---
or_test [27067,27133]
or_test [26980,27046]
===
match
---
trailer [27155,27180]
trailer [27068,27093]
===
match
---
trailer [27446,27458]
trailer [27359,27371]
===
match
---
expr_stmt [9209,9243]
expr_stmt [9209,9243]
===
match
---
trailer [9568,9575]
trailer [9568,9575]
===
match
---
simple_stmt [20972,21006]
simple_stmt [20931,20965]
===
match
---
simple_stmt [5978,6026]
simple_stmt [5978,6026]
===
match
---
trailer [14921,14930]
trailer [14863,14872]
===
match
---
trailer [19732,19736]
trailer [19691,19695]
===
match
---
name: shard_min [12090,12099]
name: shard_min [12090,12099]
===
match
---
decorator [9613,9623]
decorator [9613,9623]
===
match
---
funcdef [7472,7945]
funcdef [7472,7945]
===
match
---
classdef [6028,7264]
classdef [6028,7264]
===
match
---
operator: , [29711,29712]
operator: , [29570,29571]
===
match
---
trailer [21687,21725]
trailer [21600,21638]
===
match
---
string: "Marked %s tasks out of %s to state %s" [17487,17526]
string: "Marked %s tasks out of %s to state %s" [17496,17535]
===
match
---
dictorsetmaker [4131,4175]
dictorsetmaker [4131,4175]
===
match
---
operator: = [16112,16113]
operator: = [16054,16055]
===
match
---
name: args [11656,11660]
name: args [11656,11660]
===
match
---
name: self [22158,22162]
name: self [22071,22075]
===
match
---
operator: { [30595,30596]
operator: { [30454,30455]
===
match
---
name: formatter_config [4242,4258]
name: formatter_config [4242,4258]
===
match
---
operator: , [25990,25991]
operator: , [25903,25904]
===
match
---
trailer [19893,19899]
trailer [19852,19858]
===
match
---
name: is_infra_failure [7710,7726]
name: is_infra_failure [7710,7726]
===
match
---
name: filter [19754,19760]
name: filter [19713,19719]
===
match
---
param [9646,9650]
param [9646,9650]
===
match
---
simple_stmt [7175,7264]
simple_stmt [7175,7264]
===
match
---
name: exception [23150,23159]
name: exception [23063,23072]
===
match
---
string: "The timeout must be a non-negative number" [12510,12553]
string: "The timeout must be a non-negative number" [12510,12553]
===
match
---
name: ti [19205,19207]
name: ti [19164,19166]
===
match
---
except_clause [1804,1827]
except_clause [1804,1827]
===
match
---
atom_expr [21108,21126]
atom_expr [21062,21080]
===
match
---
suite [28457,28699]
suite [28370,28612]
===
match
---
atom [27531,27563]
atom [27444,27476]
===
match
---
name: SensorInstance [1084,1098]
name: SensorInstance [1084,1098]
===
match
---
atom_expr [1648,1681]
atom_expr [1648,1681]
===
match
---
suite [1967,6026]
suite [1967,6026]
===
match
---
name: State [18855,18860]
name: State [18814,18819]
===
match
---
name: _is_infra_failure [7690,7707]
name: _is_infra_failure [7690,7707]
===
match
---
name: state [18847,18852]
name: state [18806,18811]
===
match
---
trailer [1717,1725]
trailer [1717,1725]
===
match
---
simple_stmt [1399,1454]
simple_stmt [1399,1454]
===
match
---
name: k [4230,4231]
name: k [4230,4231]
===
match
---
trailer [27658,27670]
trailer [27571,27583]
===
match
---
atom_expr [18893,18944]
atom_expr [18852,18903]
===
match
---
simple_stmt [24622,24698]
simple_stmt [24535,24611]
===
match
---
name: __name__ [30523,30531]
name: __name__ [30382,30390]
===
match
---
operator: < [30240,30241]
operator: < [30099,30100]
===
match
---
name: AirflowException [12493,12509]
name: AirflowException [12493,12509]
===
match
---
atom_expr [30284,30302]
atom_expr [30143,30161]
===
match
---
atom_expr [26867,26905]
atom_expr [26780,26818]
===
match
---
name: self [11792,11796]
name: self [11792,11796]
===
match
---
suite [27817,29122]
suite [27730,29035]
===
match
---
arglist [23160,23211]
arglist [23073,23124]
===
match
---
number: 60 [11479,11481]
number: 60 [11479,11481]
===
match
---
if_stmt [23684,23946]
if_stmt [23597,23859]
===
match
---
simple_stmt [27359,27420]
simple_stmt [27272,27333]
===
match
---
simple_stmt [24932,24972]
simple_stmt [24845,24885]
===
match
---
name: self [7036,7040]
name: self [7036,7040]
===
match
---
trailer [5588,5594]
trailer [5588,5594]
===
match
---
simple_stmt [4916,4974]
simple_stmt [4916,4974]
===
match
---
name: Stats [12870,12875]
name: Stats [12870,12875]
===
match
---
trailer [9360,9388]
trailer [9360,9388]
===
match
---
funcdef [9746,9914]
funcdef [9746,9914]
===
match
---
name: sensor_work [19590,19601]
name: sensor_work [19549,19560]
===
match
---
string: 'email_on_retry' [18927,18943]
string: 'email_on_retry' [18886,18902]
===
match
---
simple_stmt [23225,23270]
simple_stmt [23138,23183]
===
match
---
atom_expr [19761,19770]
atom_expr [19720,19729]
===
match
---
name: with_for_update [20228,20243]
name: with_for_update [20187,20202]
===
match
---
trailer [6440,6446]
trailer [6440,6446]
===
match
---
atom_expr [2926,2938]
atom_expr [2926,2938]
===
match
---
operator: < [12309,12310]
operator: < [12309,12310]
===
match
---
name: log [23146,23149]
name: log [23059,23062]
===
match
---
name: sensor_work [23250,23261]
name: sensor_work [23163,23174]
===
match
---
simple_stmt [22014,22131]
simple_stmt [21927,22044]
===
match
---
atom_expr [22397,22430]
atom_expr [22310,22343]
===
match
---
string: """Clear state for cached poke work.""" [6808,6847]
string: """Clear state for cached poke work.""" [6808,6847]
===
match
---
name: sensor_work [19051,19062]
name: sensor_work [19010,19021]
===
match
---
name: items [26801,26806]
name: items [26714,26719]
===
match
---
trailer [23307,23311]
trailer [23220,23224]
===
match
---
name: _infra_failure_timeout [7811,7833]
name: _infra_failure_timeout [7811,7833]
===
match
---
name: handler [4422,4429]
name: handler [4422,4429]
===
match
---
string: 'is_infra_failure' [25972,25990]
string: 'is_infra_failure' [25885,25903]
===
match
---
import_from [1454,1496]
import_from [1454,1496]
===
match
---
operator: , [30153,30154]
operator: , [30012,30013]
===
match
---
name: si [4511,4513]
name: si [4511,4513]
===
match
---
expr_stmt [26409,26560]
expr_stmt [26322,26473]
===
match
---
name: state [12977,12982]
name: state [12977,12982]
===
match
---
operator: = [27990,27991]
operator: = [27903,27904]
===
match
---
operator: = [27371,27372]
operator: = [27284,27285]
===
match
---
name: _exception_info [8712,8727]
name: _exception_info [8712,8727]
===
match
---
argument [30571,30585]
argument [30430,30444]
===
match
---
name: sensor_instance [16756,16771]
name: sensor_instance [16698,16713]
===
match
---
simple_stmt [14685,14875]
simple_stmt [14627,14817]
===
match
---
suite [18708,19530]
suite [18667,19489]
===
match
---
name: state [16499,16504]
name: state [16441,16446]
===
match
---
name: duration [29982,29990]
name: duration [29841,29849]
===
match
---
expr_stmt [28356,28381]
expr_stmt [28269,28294]
===
match
---
trailer [24807,24812]
trailer [24720,24725]
===
match
---
decorator [12560,12577]
decorator [12560,12577]
===
match
---
trailer [24057,24061]
trailer [23970,23974]
===
match
---
name: to_flush [6534,6542]
name: to_flush [6534,6542]
===
match
---
trailer [18775,18786]
trailer [18734,18745]
===
match
---
parameters [9421,9427]
parameters [9421,9427]
===
match
---
name: ti [13830,13832]
name: ti [13825,13827]
===
match
---
trailer [20816,20820]
trailer [20775,20779]
===
match
---
operator: = [27876,27877]
operator: = [27789,27790]
===
match
---
name: self [6732,6736]
name: self [6732,6736]
===
match
---
operator: , [4876,4877]
operator: , [4876,4877]
===
match
---
name: timeout [1615,1622]
name: timeout [1615,1622]
===
match
---
name: SI [12974,12976]
name: SI [12974,12976]
===
match
---
trailer [16546,16572]
trailer [16488,16514]
===
match
---
trailer [14973,14975]
trailer [14915,14917]
===
match
---
name: cache_key [24235,24244]
name: cache_key [24148,24157]
===
match
---
parameters [30497,30503]
parameters [30356,30362]
===
match
---
expr_stmt [21542,21621]
expr_stmt [21455,21534]
===
match
---
comparison [30523,30545]
comparison [30382,30404]
===
match
---
expr_stmt [9306,9388]
expr_stmt [9306,9388]
===
match
---
name: sensor_work [21759,21770]
name: sensor_work [21672,21683]
===
match
---
name: _get_sensor_logger [4486,4504]
name: _get_sensor_logger [4486,4504]
===
match
---
name: log [25249,25252]
name: log [25162,25165]
===
match
---
name: PokeState [23696,23705]
name: PokeState [23609,23618]
===
match
---
argument [17013,17018]
argument [16955,16960]
===
match
---
name: gauge [30109,30114]
name: gauge [29968,29973]
===
match
---
name: handler [5096,5103]
name: handler [5096,5103]
===
match
---
operator: = [8867,8868]
operator: = [8867,8868]
===
match
---
trailer [22162,22187]
trailer [22075,22100]
===
match
---
operator: = [24221,24222]
operator: = [24134,24135]
===
match
---
name: hashcode [16550,16558]
name: hashcode [16492,16500]
===
match
---
import_from [1248,1299]
import_from [1248,1299]
===
match
---
atom_expr [16547,16558]
atom_expr [16489,16500]
===
match
---
name: hostname [29389,29397]
name: hostname [29248,29256]
===
match
---
operator: - [30349,30350]
operator: - [30208,30209]
===
match
---
atom_expr [30551,30598]
atom_expr [30410,30457]
===
match
---
name: session [20737,20744]
name: session [20696,20703]
===
match
---
trailer [16295,16302]
trailer [16237,16244]
===
match
---
operator: , [4824,4825]
operator: , [4824,4825]
===
match
---
operator: = [20494,20495]
operator: = [20453,20454]
===
match
---
name: hashcode [3411,3419]
name: hashcode [3411,3419]
===
match
---
trailer [26798,26800]
trailer [26711,26713]
===
match
---
name: session [14203,14210]
name: session [14145,14152]
===
match
---
expr_stmt [12837,12856]
expr_stmt [12837,12856]
===
match
---
arglist [28724,28771]
arglist [28637,28684]
===
match
---
operator: = [6543,6544]
operator: = [6543,6544]
===
match
---
expr_stmt [4771,4907]
expr_stmt [4771,4907]
===
match
---
trailer [27408,27418]
trailer [27321,27331]
===
match
---
arglist [3662,3679]
arglist [3662,3679]
===
match
---
simple_stmt [3694,3716]
simple_stmt [3694,3716]
===
match
---
param [15256,15261]
param [15198,15203]
===
match
---
string: '#e6f1f2' [11355,11364]
string: '#e6f1f2' [11355,11364]
===
match
---
string: """         Function that the sensors defined while deriving this class should         override.          """ [27241,27350]
string: """         Function that the sensors defined while deriving this class should         override.          """ [27154,27263]
===
match
---
name: task_instance [18202,18215]
name: task_instance [18211,18224]
===
match
---
name: getattr [25961,25968]
name: getattr [25874,25881]
===
match
---
comparison [14755,14813]
comparison [14697,14755]
===
match
---
comparison [21738,21813]
comparison [21651,21726]
===
match
---
arglist [28967,29035]
arglist [28880,28948]
===
match
---
name: SensorInstance [16049,16063]
name: SensorInstance [15991,16005]
===
match
---
operator: == [16559,16561]
operator: == [16501,16503]
===
match
---
simple_stmt [27857,27880]
simple_stmt [27770,27793]
===
match
---
name: self [5529,5533]
name: self [5529,5533]
===
match
---
trailer [1760,1774]
trailer [1760,1774]
===
match
---
decorated [12560,14133]
decorated [12560,14075]
===
match
---
trailer [29773,29786]
trailer [29632,29645]
===
match
---
operator: == [20192,20194]
operator: == [20151,20153]
===
match
---
suite [17112,17214]
suite [17054,17156]
===
match
---
trailer [16181,16187]
trailer [16123,16129]
===
match
---
atom_expr [12290,12308]
atom_expr [12290,12308]
===
match
---
name: TI [20151,20153]
name: TI [20110,20112]
===
match
---
simple_stmt [14226,14428]
simple_stmt [14168,14370]
===
match
---
trailer [18329,18341]
trailer [18338,18350]
===
match
---
atom_expr [19782,19792]
atom_expr [19741,19751]
===
match
---
atom_expr [23050,23099]
atom_expr [22963,23012]
===
match
---
trailer [23073,23084]
trailer [22986,22997]
===
match
---
trailer [20341,20349]
trailer [20300,20308]
===
match
---
if_stmt [20321,20674]
if_stmt [20280,20633]
===
match
---
trailer [12945,12949]
trailer [12945,12949]
===
match
---
trailer [21889,21896]
trailer [21802,21809]
===
match
---
name: sensor_instance [17020,17035]
name: sensor_instance [16962,16977]
===
match
---
atom_expr [20690,20720]
atom_expr [20649,20679]
===
match
---
operator: , [18451,18452]
operator: , [18460,18461]
===
match
---
trailer [25611,25628]
trailer [25524,25541]
===
match
---
trailer [13044,13054]
trailer [13044,13054]
===
match
---
sync_comp_for [4152,4175]
sync_comp_for [4152,4175]
===
match
---
name: count_poke [28150,28160]
name: count_poke [28063,28073]
===
match
---
operator: , [16365,16366]
operator: , [16307,16308]
===
match
---
atom_expr [12155,12172]
atom_expr [12155,12172]
===
match
---
atom_expr [3746,3757]
atom_expr [3746,3757]
===
match
---
arglist [14762,14802]
arglist [14704,14744]
===
match
---
name: dag_id [3767,3773]
name: dag_id [3767,3773]
===
match
---
operator: , [11603,11604]
operator: , [11603,11604]
===
match
---
name: _is_infra_failure [8758,8775]
name: _is_infra_failure [8758,8775]
===
match
---
expr_stmt [27892,27916]
expr_stmt [27805,27829]
===
match
---
name: info [5232,5236]
name: info [5232,5236]
===
match
---
trailer [5828,5836]
trailer [5828,5836]
===
match
---
name: count_infra_failure [29101,29120]
name: count_infra_failure [29014,29033]
===
match
---
simple_stmt [909,932]
simple_stmt [909,932]
===
match
---
comparison [20130,20149]
comparison [20089,20108]
===
match
---
trailer [20176,20191]
trailer [20135,20150]
===
match
---
name: ti [13601,13603]
name: ti [13601,13603]
===
match
---
name: str [24109,24112]
name: str [24022,24025]
===
match
---
funcdef [6777,6874]
funcdef [6777,6874]
===
match
---
atom [14691,14874]
atom [14633,14816]
===
match
---
atom_expr [4990,5005]
atom_expr [4990,5005]
===
match
---
name: execution_date [20195,20209]
name: execution_date [20154,20168]
===
match
---
trailer [15951,15960]
trailer [15893,15902]
===
match
---
simple_stmt [29049,29122]
simple_stmt [28962,29035]
===
match
---
name: start_date [21771,21781]
name: start_date [21684,21694]
===
match
---
name: poke [27741,27745]
name: poke [27654,27658]
===
match
---
expr_stmt [7735,7796]
expr_stmt [7735,7796]
===
match
---
atom_expr [24013,24031]
atom_expr [23926,23944]
===
match
---
expr_stmt [7806,7840]
expr_stmt [7806,7840]
===
match
---
suite [28335,28382]
suite [28248,28295]
===
match
---
name: utcnow [7209,7215]
name: utcnow [7209,7215]
===
match
---
name: sensor_instance [19683,19698]
name: sensor_instance [19642,19657]
===
match
---
trailer [18846,18852]
trailer [18805,18811]
===
match
---
name: getLogger [4933,4942]
name: getLogger [4933,4942]
===
match
---
param [14183,14188]
param [14125,14130]
===
match
---
name: config [1940,1946]
name: config [1940,1946]
===
match
---
name: State [25191,25196]
name: State [25104,25109]
===
match
---
simple_stmt [18358,18409]
simple_stmt [18367,18418]
===
match
---
simple_stmt [4524,4574]
simple_stmt [4524,4574]
===
match
---
simple_stmt [21460,21534]
simple_stmt [21373,21447]
===
match
---
name: self [24273,24277]
name: self [24186,24190]
===
match
---
trailer [5533,5537]
trailer [5533,5537]
===
match
---
operator: = [4352,4353]
operator: = [4352,4353]
===
match
---
simple_stmt [20771,20788]
simple_stmt [20730,20747]
===
match
---
name: _check_and_handle_ti_timeout [21193,21221]
name: _check_and_handle_ti_timeout [21106,21134]
===
match
---
atom_expr [23641,23674]
atom_expr [23554,23587]
===
match
---
atom_expr [11792,11806]
atom_expr [11792,11806]
===
match
---
operator: = [18656,18657]
operator: = [18615,18616]
===
match
---
operator: , [1082,1083]
operator: , [1082,1083]
===
match
---
atom_expr [16017,16034]
atom_expr [15959,15976]
===
match
---
name: cached_work [26100,26111]
name: cached_work [26013,26024]
===
match
---
name: Exception [5616,5625]
name: Exception [5616,5625]
===
match
---
expr_stmt [11909,11927]
expr_stmt [11909,11927]
===
match
---
if_stmt [22394,23213]
if_stmt [22307,23126]
===
match
---
name: shard_max [13045,13054]
name: shard_max [13045,13054]
===
match
---
name: set_state [6560,6569]
name: set_state [6560,6569]
===
match
---
import_from [1300,1342]
import_from [1300,1342]
===
match
---
suite [9652,9727]
suite [9652,9727]
===
match
---
name: _retry_or_fail_task [23230,23249]
name: _retry_or_fail_task [23143,23162]
===
match
---
operator: = [24044,24045]
operator: = [23957,23958]
===
match
---
trailer [16726,16733]
trailer [16668,16675]
===
match
---
trailer [1774,1803]
trailer [1774,1803]
===
match
---
name: or_ [962,965]
name: or_ [962,965]
===
match
---
simple_stmt [17667,18177]
simple_stmt [17676,18186]
===
match
---
name: self [29496,29500]
name: self [29355,29359]
===
match
---
simple_stmt [23641,23675]
simple_stmt [23554,23588]
===
match
---
comparison [3896,3931]
comparison [3896,3931]
===
match
---
name: handler_config_copy [4313,4332]
name: handler_config_copy [4313,4332]
===
match
---
trailer [9310,9333]
trailer [9310,9333]
===
match
---
param [21228,21239]
param [21141,21152]
===
match
---
simple_stmt [5189,5213]
simple_stmt [5189,5213]
===
match
---
atom_expr [17181,17202]
atom_expr [17123,17144]
===
match
---
name: configure_formatter [4371,4390]
name: configure_formatter [4371,4390]
===
match
---
atom_expr [7200,7217]
atom_expr [7200,7217]
===
match
---
name: e [5629,5630]
name: e [5629,5630]
===
match
---
trailer [26264,26285]
trailer [26177,26198]
===
match
---
param [27213,27218]
param [27126,27131]
===
match
---
trailer [28048,28055]
trailer [27961,27968]
===
match
---
operator: , [12438,12439]
operator: , [12438,12439]
===
match
---
name: self [23485,23489]
name: self [23398,23402]
===
match
---
name: self [7806,7810]
name: self [7806,7810]
===
match
---
name: logger [4990,4996]
name: logger [4990,4996]
===
match
---
name: error [17637,17642]
name: error [17646,17651]
===
match
---
name: dag_id [20143,20149]
name: dag_id [20102,20108]
===
match
---
expr_stmt [16044,16063]
expr_stmt [15986,16005]
===
match
---
expr_stmt [20065,20284]
expr_stmt [20024,20243]
===
match
---
atom_expr [14495,14511]
atom_expr [14437,14453]
===
match
---
trailer [23619,23626]
trailer [23532,23539]
===
match
---
name: fail_current_run [28532,28548]
name: fail_current_run [28445,28461]
===
match
---
atom_expr [27595,27634]
atom_expr [27508,27547]
===
match
---
trailer [23394,23423]
trailer [23307,23336]
===
match
---
name: AirflowTaskTimeout [1024,1042]
name: AirflowTaskTimeout [1024,1042]
===
match
---
try_stmt [16124,17465]
try_stmt [16066,17474]
===
match
---
atom_expr [29631,29648]
atom_expr [29490,29507]
===
match
---
name: state [15866,15871]
name: state [15808,15813]
===
match
---
name: get [19374,19377]
name: get [19333,19336]
===
match
---
name: get [21505,21508]
name: get [21418,21421]
===
match
---
operator: == [30532,30534]
operator: == [30391,30393]
===
match
---
exprlist [16752,16771]
exprlist [16694,16713]
===
match
---
simple_stmt [19408,19487]
simple_stmt [19367,19446]
===
match
---
operator: } [4258,4259]
operator: } [4258,4259]
===
match
---
trailer [12991,12999]
trailer [12991,12999]
===
match
---
name: len [17542,17545]
name: len [17551,17554]
===
match
---
trailer [5344,5346]
trailer [5344,5346]
===
match
---
name: self [6462,6466]
name: self [6462,6466]
===
match
---
argument [17450,17463]
argument [17445,17458]
===
match
---
name: poke_interval [30289,30302]
name: poke_interval [30148,30161]
===
match
---
name: is_infra_failure [22414,22430]
name: is_infra_failure [22327,22343]
===
match
---
name: cached_dedup_works [24454,24472]
name: cached_dedup_works [24367,24385]
===
match
---
operator: = [24447,24448]
operator: = [24360,24361]
===
match
---
trailer [19428,19486]
trailer [19387,19445]
===
match
---
name: hostname [11914,11922]
name: hostname [11914,11922]
===
match
---
name: task_id [30571,30578]
name: task_id [30430,30437]
===
match
---
atom_expr [8869,8899]
atom_expr [8869,8899]
===
match
---
name: query [20096,20101]
name: query [20055,20060]
===
match
---
name: utils [1261,1266]
name: utils [1261,1266]
===
match
---
trailer [3900,3911]
trailer [3900,3911]
===
match
---
trailer [1705,1717]
trailer [1705,1717]
===
match
---
trailer [3462,3473]
trailer [3462,3473]
===
match
---
param [15833,15848]
param [15775,15790]
===
match
---
testlist_comp [12441,12451]
testlist_comp [12441,12451]
===
match
---
atom_expr [18790,18802]
atom_expr [18749,18761]
===
match
---
param [23491,23503]
param [23404,23416]
===
match
---
name: State [16508,16513]
name: State [16450,16455]
===
match
---
operator: == [23529,23531]
operator: == [23442,23444]
===
match
---
operator: == [3758,3760]
operator: == [3758,3760]
===
match
---
simple_stmt [21542,21622]
simple_stmt [21455,21535]
===
match
---
decorated [17573,21184]
decorated [17582,21097]
===
match
---
argument [26323,26356]
argument [26236,26269]
===
match
---
simple_stmt [1300,1343]
simple_stmt [1300,1343]
===
match
---
atom_expr [23608,23626]
atom_expr [23521,23539]
===
match
---
atom_expr [28418,28456]
atom_expr [28331,28369]
===
match
---
atom_expr [12932,13087]
atom_expr [12932,13087]
===
match
---
operator: > [21799,21800]
operator: > [21712,21713]
===
match
---
trailer [20433,20450]
trailer [20392,20409]
===
match
---
name: self [23976,23980]
name: self [23889,23893]
===
match
---
operator: = [26450,26451]
operator: = [26363,26364]
===
match
---
operator: = [3458,3459]
operator: = [3458,3459]
===
match
---
operator: , [26014,26015]
operator: , [25927,25928]
===
match
---
name: SENSING [20342,20349]
name: SENSING [20301,20308]
===
match
---
atom_expr [22158,22214]
atom_expr [22071,22127]
===
match
---
name: logging_mixin [1366,1379]
name: logging_mixin [1366,1379]
===
match
---
param [21986,21991]
param [21899,21904]
===
match
---
number: 0 [27992,27993]
number: 0 [27905,27906]
===
match
---
name: cached_dedup_works [24377,24395]
name: cached_dedup_works [24290,24308]
===
match
---
if_stmt [24493,24717]
if_stmt [24406,24630]
===
match
---
name: format_exc [26075,26085]
name: format_exc [25988,25998]
===
match
---
name: DictConfigurator [876,892]
name: DictConfigurator [876,892]
===
match
---
atom_expr [4422,4453]
atom_expr [4422,4453]
===
match
---
name: SENSING [16514,16521]
name: SENSING [16456,16463]
===
match
---
simple_stmt [17473,17568]
simple_stmt [17482,17577]
===
match
---
term [5167,5176]
term [5167,5176]
===
match
---
operator: = [12072,12073]
operator: = [12072,12073]
===
match
---
simple_stmt [5405,5419]
simple_stmt [5405,5419]
===
match
---
string: "Task %s succeeded" [25258,25277]
string: "Task %s succeeded" [25171,25190]
===
match
---
atom_expr [26177,26206]
atom_expr [26090,26119]
===
match
---
trailer [13145,13149]
trailer [13145,13149]
===
match
---
trailer [27620,27633]
trailer [27533,27546]
===
match
---
atom [3219,3221]
atom [3219,3221]
===
match
---
operator: = [14210,14211]
operator: = [14152,14153]
===
match
---
name: sensor_work [19108,19119]
name: sensor_work [19067,19078]
===
match
---
name: timezone [16718,16726]
name: timezone [16660,16668]
===
match
---
simple_stmt [12326,12400]
simple_stmt [12326,12400]
===
match
---
trailer [12509,12554]
trailer [12509,12554]
===
match
---
trailer [13198,13203]
trailer [13198,13203]
===
match
---
trailer [30376,30378]
trailer [30235,30237]
===
match
---
expr_stmt [12049,12076]
expr_stmt [12049,12076]
===
match
---
name: ti [20301,20303]
name: ti [20260,20262]
===
match
---
operator: { [4130,4131]
operator: { [4130,4131]
===
match
---
operator: , [19780,19781]
operator: , [19739,19740]
===
match
---
operator: , [23261,23262]
operator: , [23174,23175]
===
match
---
trailer [22296,22334]
trailer [22209,22247]
===
match
---
atom_expr [21738,21798]
atom_expr [21651,21711]
===
match
---
atom_expr [12974,12982]
atom_expr [12974,12982]
===
match
---
trailer [1898,1903]
trailer [1898,1903]
===
match
---
name: cached_work [27359,27370]
name: cached_work [27272,27283]
===
match
---
operator: , [12444,12445]
operator: , [12444,12445]
===
match
---
simple_stmt [29447,29483]
simple_stmt [29306,29342]
===
match
---
atom_expr [6000,6025]
atom_expr [6000,6025]
===
match
---
trailer [7599,7609]
trailer [7599,7609]
===
match
---
simple_stmt [23905,23946]
simple_stmt [23818,23859]
===
match
---
parameters [6569,6582]
parameters [6569,6582]
===
match
---
name: self [7735,7739]
name: self [7735,7739]
===
match
---
trailer [3102,3115]
trailer [3102,3115]
===
match
---
name: operator [25053,25061]
name: operator [24966,24974]
===
match
---
expr_stmt [17073,17090]
expr_stmt [17015,17032]
===
match
---
atom_expr [3498,3509]
atom_expr [3498,3509]
===
match
---
suite [26392,26561]
suite [26305,26474]
===
match
---
name: info [5196,5200]
name: info [5196,5200]
===
match
---
name: exception [18635,18644]
name: warning [18570,18577]
===
match
---
atom_expr [10058,10080]
atom_expr [10058,10080]
===
match
---
name: duration [13211,13219]
name: duration [13211,13219]
===
match
---
comparison [28185,28222]
comparison [28098,28135]
===
match
---
arglist [25041,25205]
arglist [24954,25118]
===
match
---
string: """Flush outdated cached sensor states saved in previous loop.""" [26672,26737]
string: """Flush outdated cached sensor states saved in previous loop.""" [26585,26650]
===
match
---
atom_expr [21475,21533]
atom_expr [21388,21446]
===
match
---
name: handler_config [1775,1789]
name: handler_config [1775,1789]
===
match
---
name: _retry_or_fail_task [17598,17617]
name: _retry_or_fail_task [17607,17626]
===
match
---
atom_expr [27435,27458]
atom_expr [27348,27371]
===
match
---
operator: = [18853,18854]
operator: = [18812,18813]
===
match
---
name: airflow [1129,1136]
name: airflow [1129,1136]
===
match
---
funcdef [11390,12188]
funcdef [11390,12188]
===
match
---
name: handler [5518,5525]
name: handler [5518,5525]
===
match
---
trailer [7224,7239]
trailer [7224,7239]
===
match
---
operator: = [7708,7709]
operator: = [7708,7709]
===
match
---
atom_expr [10141,10168]
atom_expr [10141,10168]
===
match
---
name: log [22283,22286]
name: log [22196,22199]
===
match
---
dotted_name [1305,1324]
dotted_name [1305,1324]
===
match
---
name: dag_id [14765,14771]
name: dag_id [14707,14713]
===
match
---
trailer [21578,21596]
trailer [21491,21509]
===
match
---
funcdef [29308,30481]
funcdef [29167,30340]
===
match
---
string: "Taking %s to execute %s tasks." [29948,29980]
string: "Taking %s to execute %s tasks." [29807,29839]
===
match
---
operator: , [19571,19572]
operator: , [19530,19531]
===
match
---
name: session [17644,17651]
name: session [17653,17660]
===
match
---
operator: , [20172,20173]
operator: , [20131,20132]
===
match
---
operator: = [12617,12618]
operator: = [12617,12618]
===
match
---
simple_stmt [7685,7727]
simple_stmt [7685,7727]
===
match
---
import_as_names [1579,1595]
import_as_names [1579,1595]
===
match
---
name: state [15874,15879]
name: state [15816,15821]
===
match
---
simple_stmt [805,817]
simple_stmt [805,817]
===
match
---
string: 'task_id' [27532,27541]
string: 'task_id' [27445,27454]
===
match
---
operator: = [17458,17459]
operator: = [17453,17454]
===
match
---
operator: * [11482,11483]
operator: * [11482,11483]
===
match
---
suite [13611,13891]
suite [13611,13833]
===
match
---
name: self [29587,29591]
name: self [29446,29450]
===
match
---
trailer [28300,28306]
trailer [28213,28219]
===
match
---
simple_stmt [6995,7016]
simple_stmt [6995,7016]
===
match
---
atom_expr [7591,7622]
atom_expr [7591,7622]
===
match
---
operator: , [11562,11563]
operator: , [11562,11563]
===
match
---
suite [15961,16035]
suite [15903,15977]
===
match
---
arglist [25969,25997]
arglist [25882,25910]
===
match
---
atom_expr [18773,18786]
atom_expr [18732,18745]
===
match
---
operator: , [12271,12272]
operator: , [12271,12272]
===
match
---
trailer [17196,17202]
trailer [17138,17144]
===
match
---
name: set_latest_exception [7954,7974]
name: set_latest_exception [7954,7974]
===
match
---
param [5448,5452]
param [5448,5452]
===
match
---
name: self [6421,6425]
name: self [6421,6425]
===
match
---
atom_expr [5529,5546]
atom_expr [5529,5546]
===
match
---
atom_expr [1893,1903]
atom_expr [1893,1903]
===
match
---
simple_stmt [28125,28134]
simple_stmt [28038,28047]
===
match
---
trailer [21486,21504]
trailer [21399,21417]
===
match
---
name: str [4878,4881]
name: str [4878,4881]
===
match
---
name: key [26750,26753]
name: key [26663,26666]
===
match
---
arglist [26895,26904]
arglist [26808,26817]
===
match
---
operator: += [28263,28265]
operator: += [28176,28178]
===
match
---
decorated [11370,12188]
decorated [11370,12188]
===
match
---
name: Stats [30029,30034]
name: Stats [29888,29893]
===
match
---
operator: , [11416,11417]
operator: , [11416,11417]
===
match
---
name: error [20932,20937]
name: error [20891,20896]
===
match
---
trailer [15007,15016]
trailer [14949,14958]
===
match
---
comparison [15937,15960]
comparison [15879,15902]
===
match
---
name: sensor_work [19248,19259]
name: sensor_work [19207,19218]
===
match
---
name: config [1639,1645]
name: config [1639,1645]
===
match
---
operator: , [960,961]
operator: , [960,961]
===
match
---
name: e [26013,26014]
name: e [25926,25927]
===
match
---
name: execution_date [14497,14511]
name: execution_date [14439,14453]
===
match
---
suite [12226,12555]
suite [12226,12555]
===
match
---
trailer [27524,27526]
trailer [27437,27439]
===
match
---
name: utcnow [29474,29480]
name: utcnow [29333,29339]
===
match
---
name: duration [29856,29864]
name: duration [29715,29723]
===
match
---
name: si [4882,4884]
name: si [4882,4884]
===
match
---
expr_stmt [14462,14535]
expr_stmt [14404,14477]
===
match
---
expr_stmt [27578,27634]
expr_stmt [27491,27547]
===
match
---
expr_stmt [20472,20508]
expr_stmt [20431,20467]
===
match
---
except_clause [5609,5630]
except_clause [5609,5630]
===
match
---
simple_stmt [29549,29575]
simple_stmt [29408,29434]
===
match
---
trailer [23802,23831]
trailer [23715,23744]
===
match
---
simple_stmt [24435,24484]
simple_stmt [24348,24397]
===
match
---
string: 'retries' [18758,18767]
string: 'retries' [18717,18726]
===
match
---
name: set_infra_failure_timeout [8909,8934]
name: set_infra_failure_timeout [8909,8934]
===
match
---
name: logging [824,831]
name: logging [824,831]
===
match
---
trailer [25343,25345]
trailer [25256,25258]
===
match
---
name: last_poke_time [7225,7239]
name: last_poke_time [7225,7239]
===
match
---
expr_stmt [3008,3039]
expr_stmt [3008,3039]
===
match
---
name: filter [14744,14750]
name: filter [14686,14692]
===
match
---
atom_expr [20543,20560]
atom_expr [20502,20519]
===
match
---
simple_stmt [23798,23845]
simple_stmt [23711,23758]
===
match
---
name: task_id [19564,19571]
name: task_id [19523,19530]
===
match
---
name: logger [5225,5231]
name: logger [5225,5231]
===
match
---
operator: = [20541,20542]
operator: = [20500,20501]
===
match
---
operator: , [20149,20150]
operator: , [20108,20109]
===
match
---
atom_expr [24932,24971]
atom_expr [24845,24884]
===
match
---
operator: ** [11662,11664]
operator: ** [11662,11664]
===
match
---
simple_stmt [8804,8837]
simple_stmt [8804,8837]
===
match
---
atom [12440,12452]
atom [12440,12452]
===
match
---
string: "Processing sensor task %s in smart sensor service on host: %s" [5254,5317]
string: "Processing sensor task %s in smart sensor service on host: %s" [5254,5317]
===
match
---
atom_expr [19205,19213]
atom_expr [19164,19172]
===
match
---
operator: { [3219,3220]
operator: { [3219,3220]
===
match
---
name: is_infra_failure [8778,8794]
name: is_infra_failure [8778,8794]
===
match
---
trailer [25257,25291]
trailer [25170,25204]
===
match
---
number: 60 [11474,11476]
number: 60 [11474,11476]
===
match
---
operator: = [8013,8014]
operator: = [8013,8014]
===
match
---
trailer [6466,6478]
trailer [6466,6478]
===
match
---
string: "smart_sensor_operator.poked_exception" [28880,28919]
string: "smart_sensor_operator.poked_exception" [28793,28832]
===
match
---
name: formatter [4443,4452]
name: formatter [4443,4452]
===
match
---
name: ti_key [25283,25289]
name: ti_key [25196,25202]
===
match
---
name: si [3422,3424]
name: si [3422,3424]
===
match
---
trailer [14775,14783]
trailer [14717,14725]
===
match
---
simple_stmt [28712,28773]
simple_stmt [28625,28686]
===
match
---
name: execution_date [3865,3879]
name: execution_date [3865,3879]
===
match
---
name: gauge [28874,28879]
name: gauge [28787,28792]
===
match
---
simple_stmt [1497,1547]
simple_stmt [1497,1547]
===
match
---
name: sensor_work [22547,22558]
name: sensor_work [22460,22471]
===
match
---
simple_stmt [21250,21452]
simple_stmt [21163,21365]
===
match
---
name: query [14717,14722]
name: query [14659,14664]
===
match
---
trailer [7643,7659]
trailer [7643,7659]
===
match
---
name: is_infra_failure [7532,7548]
name: is_infra_failure [7532,7548]
===
match
---
name: state [15908,15913]
name: state [15850,15855]
===
match
---
name: log [22460,22463]
name: log [22373,22376]
===
match
---
arith_expr [21739,21781]
arith_expr [21652,21694]
===
match
---
suite [5897,6026]
suite [5897,6026]
===
match
---
name: log [21069,21072]
name: log [21023,21026]
===
match
---
name: task_timeout [21669,21681]
name: task_timeout [21582,21594]
===
match
---
name: set_context [1387,1398]
name: set_context [1387,1398]
===
match
---
name: filter [16590,16596]
name: filter [16532,16538]
===
match
---
name: SI [13025,13027]
name: SI [13025,13027]
===
match
---
name: set_infra_failure_timeout [7854,7879]
name: set_infra_failure_timeout [7854,7879]
===
match
---
atom_expr [20771,20787]
atom_expr [20730,20746]
===
match
---
suite [15143,15208]
suite [15085,15150]
===
match
---
trailer [18399,18408]
trailer [18408,18417]
===
match
---
simple_stmt [29496,29536]
simple_stmt [29355,29395]
===
match
---
operator: , [15088,15089]
operator: , [15030,15031]
===
match
---
name: si [3282,3284]
name: si [3282,3284]
===
match
---
name: si [2982,2984]
name: si [2982,2984]
===
match
---
operator: = [3536,3537]
operator: = [3536,3537]
===
match
---
operator: = [15990,15991]
operator: = [15932,15933]
===
match
---
simple_stmt [3132,3222]
simple_stmt [3132,3222]
===
match
---
not_test [3647,3680]
not_test [3647,3680]
===
match
---
expr_stmt [24372,24425]
expr_stmt [24285,24338]
===
match
---
name: ti [20751,20753]
name: ti [20710,20712]
===
match
---
name: sensor_exception [26986,27002]
name: sensor_exception [26899,26915]
===
match
---
funcdef [15814,16035]
funcdef [15756,15977]
===
match
---
atom_expr [24496,24513]
atom_expr [24409,24426]
===
match
---
suite [5012,5397]
suite [5012,5397]
===
match
---
name: self [25514,25518]
name: self [25427,25431]
===
match
---
operator: , [25165,25166]
operator: , [25078,25079]
===
match
---
trailer [16823,16836]
trailer [16765,16778]
===
match
---
trailer [10145,10168]
trailer [10145,10168]
===
match
---
name: cache_key [24256,24265]
name: cache_key [24169,24178]
===
match
---
trailer [20227,20243]
trailer [20186,20202]
===
match
---
trailer [14072,14090]
trailer [14014,14032]
===
match
---
arglist [20434,20449]
arglist [20393,20408]
===
match
---
name: cache_key [25612,25621]
name: cache_key [25525,25534]
===
match
---
atom_expr [27373,27419]
atom_expr [27286,27332]
===
match
---
trailer [17477,17481]
trailer [17486,17490]
===
match
---
name: tis [14685,14688]
name: tis [14627,14630]
===
match
---
name: str [25279,25282]
name: str [25192,25195]
===
match
---
atom_expr [19108,19126]
atom_expr [19067,19085]
===
match
---
name: sleep [30278,30283]
name: sleep [30137,30142]
===
match
---
dotted_name [1552,1571]
dotted_name [1552,1571]
===
match
---
atom_expr [18619,18662]
atom_expr [18554,18621]
===
match
---
operator: , [19803,19804]
operator: , [19762,19763]
===
match
---
trailer [6999,7008]
trailer [6999,7008]
===
match
---
suite [28104,28134]
suite [28017,28047]
===
match
---
name: SI [16044,16046]
name: SI [15986,15988]
===
match
---
expr_stmt [3132,3221]
expr_stmt [3132,3221]
===
match
---
trailer [26847,26849]
trailer [26760,26762]
===
match
---
suite [5454,5689]
suite [5454,5689]
===
match
---
atom_expr [23390,23436]
atom_expr [23303,23349]
===
match
---
name: SI [19733,19735]
name: SI [19692,19694]
===
match
---
import_as_names [1230,1247]
import_as_names [1230,1247]
===
match
---
name: sensor_work [22192,22203]
name: sensor_work [22105,22116]
===
match
---
name: self [12426,12430]
name: self [12426,12430]
===
match
---
suite [5547,5689]
suite [5547,5689]
===
match
---
name: last_poke_time [6737,6751]
name: last_poke_time [6737,6751]
===
match
---
atom_expr [4354,4413]
atom_expr [4354,4413]
===
match
---
trailer [6533,6542]
trailer [6533,6542]
===
match
---
operator: , [7554,7555]
operator: , [7554,7555]
===
match
---
name: self [6995,6999]
name: self [6995,6999]
===
match
---
trailer [25252,25257]
trailer [25165,25170]
===
match
---
trailer [29918,29920]
trailer [29777,29779]
===
match
---
name: k [4237,4238]
name: k [4237,4238]
===
match
---
name: sensor_works [14105,14117]
name: sensor_works [14047,14059]
===
match
---
decorated [5863,6026]
decorated [5863,6026]
===
match
---
name: execution_date [3841,3855]
name: execution_date [3841,3855]
===
match
---
name: exc_info [18648,18656]
name: exc_info [18607,18615]
===
match
---
operator: > [30379,30380]
operator: > [30238,30239]
===
match
---
name: seconds [24756,24763]
name: seconds [24669,24676]
===
match
---
name: cached_work [26825,26836]
name: cached_work [26738,26749]
===
match
---
name: log [24070,24073]
name: log [23983,23986]
===
match
---
name: sensor_works [13940,13952]
name: sensor_works [13882,13894]
===
match
---
trailer [13149,13154]
trailer [13149,13154]
===
match
---
simple_stmt [1904,1948]
simple_stmt [1904,1948]
===
match
---
name: self [7639,7643]
name: self [7639,7643]
===
match
---
name: self [2960,2964]
name: self [2960,2964]
===
match
---
name: apply_defaults [11371,11385]
name: apply_defaults [11371,11385]
===
match
---
name: self [12290,12294]
name: self [12290,12294]
===
match
---
name: _exception_info [9711,9726]
name: _exception_info [9711,9726]
===
match
---
parameters [2874,2884]
parameters [2874,2884]
===
match
---
name: SkipMixin [1100,1109]
name: SkipMixin [1100,1109]
===
match
---
name: hostname [14938,14946]
name: hostname [14880,14888]
===
match
---
comparison [13056,13086]
comparison [13056,13086]
===
match
---
trailer [1939,1947]
trailer [1939,1947]
===
match
---
trailer [11645,11654]
trailer [11645,11654]
===
match
---
name: fail_current_run [7895,7911]
name: fail_current_run [7895,7911]
===
match
---
expr_stmt [3482,3509]
expr_stmt [3482,3509]
===
match
---
number: 24 [11484,11486]
number: 24 [11484,11486]
===
match
---
name: self [3622,3626]
name: self [3622,3626]
===
match
---
name: cache_key [5881,5890]
name: cache_key [5881,5890]
===
match
---
name: SUCCESS [25197,25204]
name: SUCCESS [25110,25117]
===
match
---
name: query_result [17546,17558]
name: query_result [17555,17567]
===
match
---
trailer [3079,3096]
trailer [3079,3096]
===
match
---
name: ti_keys [15090,15097]
name: ti_keys [15032,15039]
===
match
---
return_stmt [5978,6025]
return_stmt [5978,6025]
===
match
---
name: query [19727,19732]
name: query [19686,19691]
===
match
---
name: sensor_work [23424,23435]
name: sensor_work [23337,23348]
===
match
---
atom_expr [23532,23548]
atom_expr [23445,23461]
===
match
---
atom_expr [29496,29535]
atom_expr [29355,29394]
===
match
---
comparison [9257,9292]
comparison [9257,9292]
===
match
---
operator: , [25107,25108]
operator: , [25020,25021]
===
match
---
name: is_infra_failure [26340,26356]
name: is_infra_failure [26253,26269]
===
match
---
name: warning [21073,21080]
name: warning [21027,21034]
===
match
---
trailer [16267,16452]
trailer [16209,16394]
===
match
---
number: 1 [28266,28267]
number: 1 [28179,28180]
===
match
---
raise_stmt [12326,12399]
raise_stmt [12326,12399]
===
match
---
simple_stmt [26867,26906]
simple_stmt [26780,26819]
===
match
---
operator: , [17642,17643]
operator: , [17651,17652]
===
match
---
name: print [1893,1898]
name: print [1893,1898]
===
match
---
name: poke_context [3083,3095]
name: poke_context [3083,3095]
===
match
---
simple_stmt [1454,1497]
simple_stmt [1454,1497]
===
match
---
trailer [8757,8775]
trailer [8757,8775]
===
match
---
name: NOT_LANDED [23706,23716]
name: NOT_LANDED [23619,23629]
===
match
---
operator: , [28759,28760]
operator: , [28672,28673]
===
match
---
trailer [13076,13086]
trailer [13076,13086]
===
match
---
name: sensor_works [14120,14132]
name: sensor_works [14062,14074]
===
match
---
trailer [27040,27042]
trailer [26953,26955]
===
match
---
suite [3234,3286]
suite [3234,3286]
===
match
---
trailer [4783,4788]
trailer [4783,4788]
===
match
---
trailer [21879,21889]
trailer [21792,21802]
===
match
---
trailer [16187,16195]
trailer [16129,16137]
===
match
---
atom_expr [27067,27100]
atom_expr [26980,27013]
===
match
---
name: close_sensor_logger [25324,25343]
name: close_sensor_logger [25237,25256]
===
match
---
operator: = [4276,4277]
operator: = [4276,4277]
===
match
---
trailer [5685,5688]
trailer [5685,5688]
===
match
---
name: sensor_exception [22347,22363]
name: sensor_exception [22260,22276]
===
match
---
simple_stmt [23390,23437]
simple_stmt [23303,23350]
===
match
---
name: self [3008,3012]
name: self [3008,3012]
===
match
---
atom_expr [22192,22213]
atom_expr [22105,22126]
===
match
---
param [6576,6581]
param [6576,6581]
===
match
---
expr_stmt [13571,13588]
expr_stmt [13571,13588]
===
match
---
parameters [11402,11628]
parameters [11402,11628]
===
match
---
name: self [29549,29553]
name: self [29408,29412]
===
match
---
name: is_infra_failure [26509,26525]
name: is_infra_failure [26422,26438]
===
match
---
trailer [24138,24201]
trailer [24051,24114]
===
match
---
name: airflow [1502,1509]
name: airflow [1502,1509]
===
match
---
arglist [29948,30014]
arglist [29807,29873]
===
match
---
arglist [21688,21724]
arglist [21601,21637]
===
match
---
atom_expr [30159,30176]
atom_expr [30018,30035]
===
match
---
atom_expr [22547,22565]
atom_expr [22460,22478]
===
match
---
simple_stmt [849,909]
simple_stmt [849,909]
===
match
---
atom_expr [20472,20493]
atom_expr [20431,20452]
===
match
---
comparison [20174,20209]
comparison [20133,20168]
===
match
---
name: get [18923,18926]
name: get [18882,18885]
===
match
---
name: x [14484,14485]
name: x [14426,14427]
===
match
---
name: and_ [956,960]
name: and_ [956,960]
===
match
---
return_stmt [3694,3715]
return_stmt [3694,3715]
===
match
---
name: self [7494,7498]
name: self [7494,7498]
===
match
---
simple_stmt [27929,27958]
simple_stmt [27842,27871]
===
match
---
name: cached_work [24435,24446]
name: cached_work [24348,24359]
===
match
---
name: str [17400,17403]
name: str [17370,17373]
===
match
---
name: self [24803,24807]
name: self [24716,24720]
===
match
---
name: TI [16293,16295]
name: TI [16235,16237]
===
match
---
number: 6.0 [11585,11588]
number: 6.0 [11585,11588]
===
match
---
or_test [9531,9607]
or_test [9531,9607]
===
match
---
name: si [4803,4805]
name: si [4803,4805]
===
match
---
name: utils [1313,1318]
name: utils [1313,1318]
===
match
---
expr_stmt [20371,20398]
expr_stmt [20330,20357]
===
match
---
try_stmt [1726,1904]
try_stmt [1726,1904]
===
match
---
suite [5663,5689]
suite [5663,5689]
===
match
---
expr_stmt [15978,16000]
expr_stmt [15920,15942]
===
match
---
atom_expr [20665,20673]
atom_expr [20624,20632]
===
match
---
trailer [12294,12308]
trailer [12294,12308]
===
match
---
dotted_name [854,868]
dotted_name [854,868]
===
match
---
atom_expr [5332,5346]
atom_expr [5332,5346]
===
match
---
atom_expr [28712,28772]
atom_expr [28625,28685]
===
match
---
name: self [7890,7894]
name: self [7890,7894]
===
match
---
comparison [16808,16860]
comparison [16750,16802]
===
match
---
trailer [13210,13219]
trailer [13210,13219]
===
match
---
trailer [30158,30177]
trailer [30017,30036]
===
match
---
trailer [14966,14973]
trailer [14908,14915]
===
match
---
name: try_number [3013,3023]
name: try_number [3013,3023]
===
match
---
trailer [29480,29482]
trailer [29339,29341]
===
match
---
trailer [18960,18978]
trailer [18919,18937]
===
match
---
simple_stmt [17227,17244]
simple_stmt [17169,17186]
===
match
---
operator: , [23191,23192]
operator: , [23104,23105]
===
match
---
trailer [20122,20129]
trailer [20081,20088]
===
match
---
name: len [4986,4989]
name: len [4986,4989]
===
match
---
simple_stmt [12049,12077]
simple_stmt [12049,12077]
===
match
---
operator: = [7660,7661]
operator: = [7660,7661]
===
match
---
trailer [30283,30314]
trailer [30142,30173]
===
match
---
name: log [24130,24133]
name: log [24043,24046]
===
match
---
operator: , [4509,4510]
operator: , [4509,4510]
===
match
---
decorator [11370,11386]
decorator [11370,11386]
===
match
---
trailer [26836,26847]
trailer [26749,26760]
===
match
---
name: cached_sensor_exceptions [27011,27035]
name: cached_sensor_exceptions [26924,26948]
===
match
---
atom_expr [11749,11767]
atom_expr [11749,11767]
===
match
---
name: sensor_instance [16808,16823]
name: sensor_instance [16750,16765]
===
match
---
name: SENSING [12992,12999]
name: SENSING [12992,12999]
===
match
---
name: provide_session [1531,1546]
name: provide_session [1531,1546]
===
match
---
operator: , [1588,1589]
operator: , [1588,1589]
===
match
---
name: mark_state [17002,17012]
name: mark_state [16944,16954]
===
match
---
name: timezone [9560,9568]
name: timezone [9560,9568]
===
match
---
name: net [1473,1476]
name: net [1473,1476]
===
match
---
simple_stmt [29856,29921]
simple_stmt [29715,29780]
===
match
---
suite [28223,28268]
suite [28136,28181]
===
match
---
atom_expr [13665,13679]
atom_expr [13665,13679]
===
match
---
name: str [23604,23607]
name: str [23517,23520]
===
match
---
atom_expr [16908,16919]
atom_expr [16850,16861]
===
match
---
name: key [26895,26898]
name: key [26808,26811]
===
match
---
comparison [4986,5011]
comparison [4986,5011]
===
match
---
name: operator [5990,5998]
name: operator [5990,5998]
===
match
---
simple_stmt [5804,5858]
simple_stmt [5804,5858]
===
match
---
operator: = [4923,4924]
operator: = [4923,4924]
===
match
---
name: TI [20102,20104]
name: TI [20061,20063]
===
match
---
atom_expr [17205,17213]
atom_expr [17147,17155]
===
match
---
trailer [21504,21508]
trailer [21417,21421]
===
match
---
suite [4515,5419]
suite [4515,5419]
===
match
---
name: timeout [12462,12469]
name: timeout [12462,12469]
===
match
---
atom_expr [5117,5140]
atom_expr [5117,5140]
===
match
---
atom_expr [25087,25107]
atom_expr [25000,25020]
===
match
---
name: _update_ti_hostname [14053,14072]
name: _update_ti_hostname [13995,14014]
===
match
---
trailer [16513,16521]
trailer [16455,16463]
===
match
---
trailer [25144,25165]
trailer [25057,25078]
===
match
---
string: "Handling poke exception: %s" [22297,22326]
string: "Handling poke exception: %s" [22210,22239]
===
match
---
atom [21738,21782]
atom [21651,21695]
===
match
---
name: sensor_work [27219,27230]
name: sensor_work [27132,27143]
===
match
---
name: self [27373,27377]
name: self [27286,27290]
===
match
---
trailer [19259,19277]
trailer [19218,19236]
===
match
---
param [6421,6425]
param [6421,6425]
===
match
---
name: create_new_task_handler [3969,3992]
name: create_new_task_handler [3969,3992]
===
match
---
suite [19387,19530]
suite [19346,19489]
===
match
---
atom_expr [3422,3433]
atom_expr [3422,3433]
===
match
---
name: shardcode [13028,13037]
name: shardcode [13028,13037]
===
match
---
name: email [1319,1324]
name: email [1319,1324]
===
match
---
name: self [3518,3522]
name: self [3518,3522]
===
match
---
trailer [16677,16679]
trailer [16619,16621]
===
match
---
suite [9940,10202]
suite [9940,10202]
===
match
---
name: TI [16239,16241]
name: TI [16181,16183]
===
match
---
atom_expr [20385,20398]
atom_expr [20344,20357]
===
match
---
suite [5725,5858]
suite [5725,5858]
===
match
---
arglist [22495,22565]
arglist [22408,22478]
===
match
---
simple_stmt [27241,27351]
simple_stmt [27154,27264]
===
match
---
name: SI [19761,19763]
name: SI [19720,19722]
===
match
---
name: info [24086,24090]
name: info [23999,24003]
===
match
---
suite [6902,7016]
suite [6902,7016]
===
match
---
atom_expr [11909,11922]
atom_expr [11909,11922]
===
match
---
name: sensor_work [20911,20922]
name: sensor_work [20870,20881]
===
match
---
name: info [29943,29947]
name: info [29802,29806]
===
match
---
trailer [13657,13664]
trailer [13657,13664]
===
match
---
operator: + [27528,27529]
operator: + [27441,27442]
===
match
---
simple_stmt [30411,30458]
simple_stmt [30270,30317]
===
match
---
name: sensor_work [25133,25144]
name: sensor_work [25046,25057]
===
match
---
operator: = [12173,12174]
operator: = [12173,12174]
===
match
---
name: self [11827,11831]
name: self [11827,11831]
===
match
---
operator: * [11487,11488]
operator: * [11487,11488]
===
match
---
trailer [20243,20245]
trailer [20202,20204]
===
match
---
simple_stmt [5225,5361]
simple_stmt [5225,5361]
===
match
---
simple_stmt [13114,13132]
simple_stmt [13114,13132]
===
match
---
suite [26663,27199]
suite [26576,27112]
===
match
---
atom_expr [27494,27526]
atom_expr [27407,27439]
===
match
---
name: self [26177,26181]
name: self [26090,26094]
===
match
---
operator: + [15002,15003]
operator: + [14944,14945]
===
match
---
name: _exception_info [7644,7659]
name: _exception_info [7644,7659]
===
match
---
atom_expr [7890,7911]
atom_expr [7890,7911]
===
match
---
simple_stmt [5078,5105]
simple_stmt [5078,5105]
===
match
---
name: set_to_flush [23085,23097]
name: set_to_flush [22998,23010]
===
match
---
operator: , [14187,14188]
operator: , [14129,14130]
===
match
---
name: exception_info [8730,8744]
name: exception_info [8730,8744]
===
match
---
name: utils [1560,1565]
name: utils [1560,1565]
===
match
---
simple_stmt [30103,30179]
simple_stmt [29962,30038]
===
match
---
name: self [7975,7979]
name: self [7975,7979]
===
match
---
atom_expr [24993,25227]
atom_expr [24906,25140]
===
match
---
trailer [16673,16677]
trailer [16615,16619]
===
match
---
name: end_date [15992,16000]
name: end_date [15934,15942]
===
match
---
simple_stmt [12906,13102]
simple_stmt [12906,13102]
===
match
---
name: self [3361,3365]
name: self [3361,3365]
===
match
---
simple_stmt [19556,19609]
simple_stmt [19515,19568]
===
match
---
comparison [24496,24525]
comparison [24409,24438]
===
match
---
name: __eq__ [3615,3621]
name: __eq__ [3615,3621]
===
match
---
trailer [6498,6513]
trailer [6498,6513]
===
match
---
param [9422,9426]
param [9422,9426]
===
match
---
atom_expr [15102,15124]
atom_expr [15044,15066]
===
match
---
simple_stmt [24993,25228]
simple_stmt [24906,25141]
===
match
---
name: values [28448,28454]
name: values [28361,28367]
===
match
---
comparison [26164,26206]
comparison [26077,26119]
===
match
---
expr_stmt [14100,14132]
expr_stmt [14042,14074]
===
match
---
name: PokeState [1579,1588]
name: PokeState [1579,1588]
===
match
---
simple_stmt [16044,16064]
simple_stmt [15986,16006]
===
match
---
simple_stmt [9949,10043]
simple_stmt [9949,10043]
===
match
---
name: merge [20745,20750]
name: merge [20704,20709]
===
match
---
operator: , [16315,16316]
operator: , [16257,16258]
===
match
---
trailer [29904,29918]
trailer [29763,29777]
===
match
---
operator: , [18702,18703]
operator: , [18661,18662]
===
match
---
simple_stmt [24004,24032]
simple_stmt [23917,23945]
===
match
---
simple_stmt [6808,6848]
simple_stmt [6808,6848]
===
match
---
name: airflow [1404,1411]
name: airflow [1404,1411]
===
match
---
trailer [28717,28723]
trailer [28630,28636]
===
match
---
name: self [30284,30288]
name: self [30143,30147]
===
match
---
parameters [14578,14594]
parameters [14520,14536]
===
match
---
atom_expr [17473,17567]
atom_expr [17482,17576]
===
match
---
suite [3681,3716]
suite [3681,3716]
===
match
---
name: subject [18263,18270]
name: subject [18272,18279]
===
match
---
atom_expr [26065,26087]
atom_expr [25978,26000]
===
match
---
name: len [30155,30158]
name: len [30014,30017]
===
match
---
atom [3732,3941]
atom [3732,3941]
===
match
---
trailer [26228,26253]
trailer [26141,26166]
===
match
---
operator: = [11509,11510]
operator: = [11509,11510]
===
match
---
trailer [28723,28772]
trailer [28636,28685]
===
match
---
name: self [24764,24768]
name: self [24677,24681]
===
match
---
operator: == [14804,14806]
operator: == [14746,14748]
===
match
---
simple_stmt [9782,9876]
simple_stmt [9782,9876]
===
match
---
operator: , [13054,13055]
operator: , [13054,13055]
===
match
---
trailer [24179,24200]
trailer [24092,24113]
===
match
---
simple_stmt [4185,4260]
simple_stmt [4185,4260]
===
match
---
name: self [23390,23394]
name: self [23303,23307]
===
match
---
atom_expr [29400,29414]
atom_expr [29259,29273]
===
match
---
atom_expr [1775,1802]
atom_expr [1775,1802]
===
match
---
param [7494,7499]
param [7494,7499]
===
match
---
trailer [1789,1802]
trailer [1789,1802]
===
match
---
name: log [29592,29595]
name: log [29451,29454]
===
match
---
operator: - [21757,21758]
operator: - [21670,21671]
===
match
---
suite [16981,17091]
suite [16923,17033]
===
match
---
name: get_hostname [29400,29412]
name: get_hostname [29259,29271]
===
match
---
trailer [23229,23249]
trailer [23142,23162]
===
match
---
name: pop [27181,27184]
name: pop [27094,27097]
===
match
---
atom_expr [20151,20161]
atom_expr [20110,20120]
===
match
---
atom_expr [29357,29374]
atom_expr [29216,29233]
===
match
---
arglist [11655,11670]
arglist [11655,11670]
===
match
---
simple_stmt [13764,13838]
simple_stmt [13759,13833]
===
match
---
operator: , [17398,17399]
operator: , [17352,17353]
===
match
---
atom_expr [23562,23628]
atom_expr [23475,23541]
===
match
---
name: self [3896,3900]
name: self [3896,3900]
===
match
---
name: json [3157,3161]
name: json [3157,3161]
===
match
---
simple_stmt [2960,3000]
simple_stmt [2960,3000]
===
match
---
trailer [18904,18922]
trailer [18863,18881]
===
match
---
name: self [11749,11753]
name: self [11749,11753]
===
match
---
operator: = [4720,4721]
operator: = [4720,4721]
===
match
---
name: state [15916,15921]
name: state [15858,15863]
===
match
---
test [3069,3123]
test [3069,3123]
===
match
---
if_stmt [28611,28699]
if_stmt [28524,28612]
===
match
---
name: error [21890,21895]
name: error [21803,21808]
===
match
---
simple_stmt [19651,19671]
simple_stmt [19610,19630]
===
match
---
name: _validate_input_values [11876,11898]
name: _validate_input_values [11876,11898]
===
match
---
name: k [4156,4157]
name: k [4156,4157]
===
match
---
operator: = [11353,11354]
operator: = [11353,11354]
===
match
---
name: smart_sensor_timeout [11453,11473]
name: smart_sensor_timeout [11453,11473]
===
match
---
name: _infra_failure_retry_window [9361,9388]
name: _infra_failure_retry_window [9361,9388]
===
match
---
name: handler [5025,5032]
name: handler [5025,5032]
===
match
---
trailer [28796,28855]
trailer [28709,28768]
===
match
---
parameters [6792,6798]
parameters [6792,6798]
===
match
---
name: airflow [980,987]
name: airflow [980,987]
===
match
---
name: hashcode [19972,19980]
name: hashcode [19931,19939]
===
match
---
name: count_marked [17528,17540]
name: count_marked [17537,17549]
===
match
---
name: execution_context [21579,21596]
name: execution_context [21492,21509]
===
match
---
trailer [24069,24073]
trailer [23982,23986]
===
match
---
name: _handle_poke_exception [26579,26601]
name: _handle_poke_exception [26492,26514]
===
match
---
simple_stmt [28244,28268]
simple_stmt [28157,28181]
===
match
---
trailer [27488,27565]
trailer [27401,27478]
===
match
---
simple_stmt [25249,25292]
simple_stmt [25162,25205]
===
match
---
atom_expr [5078,5104]
atom_expr [5078,5104]
===
match
---
expr_stmt [4713,4727]
expr_stmt [4713,4727]
===
match
---
expr_stmt [19621,19638]
expr_stmt [19580,19597]
===
match
---
simple_stmt [25514,25561]
simple_stmt [25427,25474]
===
match
---
expr_stmt [11937,11959]
expr_stmt [11937,11959]
===
match
---
atom_expr [7806,7833]
atom_expr [7806,7833]
===
match
---
expr_stmt [6856,6873]
expr_stmt [6856,6873]
===
match
---
operator: , [21518,21519]
operator: , [21431,21432]
===
match
---
param [3628,3633]
param [3628,3633]
===
match
---
simple_stmt [12005,12040]
simple_stmt [12005,12040]
===
match
---
name: Exception [3301,3310]
name: Exception [3301,3310]
===
match
---
simple_stmt [26100,26148]
simple_stmt [26013,26061]
===
match
---
name: airflow [1305,1312]
name: airflow [1305,1312]
===
match
---
name: other [3859,3864]
name: other [3859,3864]
===
match
---
name: execution_date [5843,5857]
name: execution_date [5843,5857]
===
match
---
name: info [17482,17486]
name: info [17491,17495]
===
match
---
name: sensor_work [23193,23204]
name: sensor_work [23106,23117]
===
match
---
except_clause [3294,3315]
except_clause [3294,3315]
===
match
---
trailer [3840,3855]
trailer [3840,3855]
===
match
---
trailer [30570,30586]
trailer [30429,30445]
===
match
---
trailer [16393,16408]
trailer [16335,16350]
===
match
---
atom_expr [14755,14803]
atom_expr [14697,14745]
===
match
---
name: State [20496,20501]
name: State [20455,20460]
===
match
---
operator: , [1109,1110]
operator: , [1109,1110]
===
match
---
expr_stmt [11749,11783]
expr_stmt [11749,11783]
===
match
---
simple_stmt [27830,27845]
simple_stmt [27743,27758]
===
match
---
atom_expr [25279,25290]
atom_expr [25192,25203]
===
match
---
simple_stmt [24211,24245]
simple_stmt [24124,24158]
===
match
---
trailer [19071,19127]
trailer [19030,19086]
===
match
---
arglist [12253,12285]
arglist [12253,12285]
===
match
---
name: formatter_config_copy [4391,4412]
name: formatter_config_copy [4391,4412]
===
match
---
trailer [5815,5822]
trailer [5815,5822]
===
match
---
simple_stmt [25450,25494]
simple_stmt [25363,25407]
===
match
---
name: self [21909,21913]
name: self [21822,21826]
===
match
---
name: commit [20779,20785]
name: commit [20738,20744]
===
match
---
arglist [28880,28941]
arglist [28793,28854]
===
match
---
atom_expr [26825,26849]
atom_expr [26738,26762]
===
match
---
name: session [20088,20095]
name: session [20047,20054]
===
match
---
trailer [5195,5200]
trailer [5195,5200]
===
match
---
trailer [30586,30594]
trailer [30445,30453]
===
match
---
trailer [28055,28057]
trailer [27968,27970]
===
match
---
operator: , [23980,23981]
operator: , [23893,23894]
===
match
---
name: is_infra_failure [9750,9766]
name: is_infra_failure [9750,9766]
===
match
---
trailer [8897,8899]
trailer [8897,8899]
===
match
---
trailer [30594,30598]
trailer [30453,30457]
===
match
---
name: sensor_work [19960,19971]
name: sensor_work [19919,19930]
===
match
---
name: log [13146,13149]
name: log [13146,13149]
===
match
---
name: timezone [29465,29473]
name: timezone [29324,29332]
===
match
---
name: timeout [1630,1637]
name: timeout [1630,1637]
===
match
---
name: handler_config [4161,4175]
name: handler_config [4161,4175]
===
match
---
trailer [4294,4312]
trailer [4294,4312]
===
match
---
name: poke_hash [15272,15281]
name: poke_hash [15214,15223]
===
match
---
trailer [18860,18873]
trailer [18819,18832]
===
match
---
comparison [9560,9607]
comparison [9560,9607]
===
match
---
simple_stmt [12837,12857]
simple_stmt [12837,12857]
===
match
---
atom_expr [25312,25345]
atom_expr [25225,25258]
===
match
---
name: pop [26891,26894]
name: pop [26804,26807]
===
match
---
trailer [29412,29414]
trailer [29271,29273]
===
match
---
operator: == [19793,19795]
operator: == [19752,19754]
===
match
---
name: utcnow [30340,30346]
name: utcnow [30199,30205]
===
match
---
trailer [3566,3587]
trailer [3566,3587]
===
match
---
atom_expr [18855,18873]
atom_expr [18814,18832]
===
match
---
expr_stmt [12906,13101]
expr_stmt [12906,13101]
===
match
---
name: sensor_work [20805,20816]
name: sensor_work [20764,20775]
===
match
---
name: self [6000,6004]
name: self [6000,6004]
===
match
---
name: is_infra_failure [26526,26542]
name: is_infra_failure [26439,26455]
===
match
---
and_test [18724,18802]
and_test [18683,18761]
===
match
---
param [17618,17623]
param [17627,17632]
===
match
---
trailer [18922,18926]
trailer [18881,18885]
===
match
---
name: dag_id [16296,16302]
name: dag_id [16238,16244]
===
match
---
name: email [18437,18442]
name: email [18446,18451]
===
match
---
operator: == [3803,3805]
operator: == [3803,3805]
===
match
---
simple_stmt [17181,17214]
simple_stmt [17123,17156]
===
match
---
atom_expr [21567,21621]
atom_expr [21480,21534]
===
match
---
name: ti [14919,14921]
name: ti [14861,14863]
===
match
---
dotted_name [1348,1379]
dotted_name [1348,1379]
===
match
---
trailer [11643,11645]
trailer [11643,11645]
===
match
---
atom_expr [27647,27670]
atom_expr [27560,27583]
===
match
---
trailer [28454,28456]
trailer [28367,28369]
===
match
---
atom_expr [30103,30178]
atom_expr [29962,30037]
===
match
---
name: is_infra_failure [25942,25958]
name: is_infra_failure [25855,25871]
===
match
---
return_stmt [10114,10201]
return_stmt [10114,10201]
===
match
---
trailer [20825,20955]
trailer [20784,20914]
===
match
---
name: traceback [26065,26074]
name: traceback [25978,25987]
===
match
---
name: self [7914,7918]
name: self [7914,7918]
===
match
---
name: ti [20447,20449]
name: ti [20406,20408]
===
match
---
name: poke_context [16824,16836]
name: poke_context [16766,16778]
===
match
---
trailer [26074,26085]
trailer [25987,25998]
===
match
---
atom_expr [19805,19822]
atom_expr [19764,19781]
===
match
---
trailer [18753,18757]
trailer [18712,18716]
===
match
---
name: timezone [7200,7208]
name: timezone [7200,7208]
===
match
---
name: decorators [1267,1277]
name: decorators [1267,1277]
===
match
---
name: self [13040,13044]
name: self [13040,13044]
===
match
---
atom_expr [13195,13203]
atom_expr [13195,13203]
===
match
---
name: cache_key [22204,22213]
name: cache_key [22117,22126]
===
match
---
simple_stmt [30474,30481]
simple_stmt [30333,30340]
===
match
---
trailer [3136,3154]
trailer [3136,3154]
===
match
---
atom_expr [11937,11954]
atom_expr [11937,11954]
===
match
---
simple_stmt [14100,14133]
simple_stmt [14042,14075]
===
match
---
atom_expr [20174,20191]
atom_expr [20133,20150]
===
match
---
simple_stmt [30278,30315]
simple_stmt [30137,30174]
===
match
---
name: self [30411,30415]
name: self [30270,30274]
===
match
---
name: State [1590,1595]
name: State [1590,1595]
===
match
---
operator: , [25621,25622]
operator: , [25534,25535]
===
match
---
operator: = [15319,15320]
operator: = [15261,15262]
===
match
---
trailer [29060,29121]
trailer [28973,29034]
===
match
---
trailer [27687,27700]
trailer [27600,27613]
===
match
---
name: strftime [4844,4852]
name: strftime [4844,4852]
===
match
---
trailer [20531,20540]
trailer [20490,20499]
===
match
---
name: email_alert [18190,18201]
name: email_alert [18199,18210]
===
match
---
trailer [8834,8836]
trailer [8834,8836]
===
match
---
atom_expr [16341,16351]
atom_expr [16283,16293]
===
match
---
atom_expr [28078,28095]
atom_expr [27991,28008]
===
match
---
trailer [29500,29533]
trailer [29359,29392]
===
match
---
operator: , [11490,11491]
operator: , [11490,11491]
===
match
---
testlist [5985,6025]
testlist [5985,6025]
===
match
---
trailer [23541,23548]
trailer [23454,23461]
===
match
---
trailer [16495,16522]
trailer [16437,16464]
===
match
---
term [11474,11490]
term [11474,11490]
===
match
---
atom_expr [27397,27418]
atom_expr [27310,27331]
===
match
---
name: exception_info [26307,26321]
name: exception_info [26220,26234]
===
match
---
trailer [22558,22565]
trailer [22471,22478]
===
match
---
name: create_new_task_handler [5040,5063]
name: create_new_task_handler [5040,5063]
===
match
---
atom_expr [24622,24697]
atom_expr [24535,24610]
===
match
---
trailer [20095,20101]
trailer [20054,20060]
===
match
---
trailer [18634,18644]
trailer [18569,18577]
===
match
---
arglist [29675,29735]
arglist [29534,29594]
===
match
---
name: other [3662,3667]
name: other [3662,3667]
===
match
---
name: State [12986,12991]
name: State [12986,12991]
===
match
---
name: raw [4716,4719]
name: raw [4716,4719]
===
match
---
simple_stmt [28356,28382]
simple_stmt [28269,28295]
===
match
---
name: logging [4925,4932]
name: logging [4925,4932]
===
match
---
name: self [24065,24069]
name: self [23978,23982]
===
match
---
name: self [6529,6533]
name: self [6529,6533]
===
match
---
operator: @ [12560,12561]
operator: @ [12560,12561]
===
match
---
name: execution_date [4829,4843]
name: execution_date [4829,4843]
===
match
---
expr_stmt [23000,23033]
expr_stmt [22913,22946]
===
match
---
suite [5564,5597]
suite [5564,5597]
===
match
---
string: "%s sending email alert for retry" [19072,19106]
string: "%s sending email alert for retry" [19031,19065]
===
match
---
expr_stmt [14919,14946]
expr_stmt [14861,14888]
===
match
---
trailer [20268,20270]
trailer [20227,20229]
===
match
---
name: sensor_work [21864,21875]
name: sensor_work [21777,21788]
===
match
---
name: state [6861,6866]
name: state [6861,6866]
===
match
---
name: datetime [796,804]
name: datetime [796,804]
===
match
---
name: import_string [1440,1453]
name: import_string [1440,1453]
===
match
---
atom_expr [18290,18341]
atom_expr [18299,18350]
===
match
---
name: error_info [18330,18340]
name: error_info [18339,18349]
===
match
---
name: other [3628,3633]
name: other [3628,3633]
===
match
---
name: task_execution_timeout [21542,21564]
name: task_execution_timeout [21455,21477]
===
match
---
name: shard_max [12137,12146]
name: shard_max [12137,12146]
===
match
---
name: ti [20065,20067]
name: ti [20024,20026]
===
match
---
name: timer [12887,12892]
name: timer [12887,12892]
===
match
---
parameters [26656,26662]
parameters [26569,26575]
===
match
---
atom_expr [24748,24782]
atom_expr [24661,24695]
===
match
---
atom_expr [9891,9913]
atom_expr [9891,9913]
===
match
---
trailer [30385,30393]
trailer [30244,30252]
===
match
---
name: self [29804,29808]
name: self [29663,29667]
===
match
---
expr_stmt [1682,1725]
expr_stmt [1682,1725]
===
match
---
funcdef [3611,3942]
funcdef [3611,3942]
===
match
---
string: '.' [4960,4963]
string: '.' [4960,4963]
===
match
---
name: line_break [5201,5211]
name: line_break [5201,5211]
===
match
---
trailer [12939,12945]
trailer [12939,12945]
===
match
---
atom_expr [4826,4876]
atom_expr [4826,4876]
===
match
---
simple_stmt [24710,24717]
simple_stmt [24623,24630]
===
match
---
if_stmt [16952,17214]
if_stmt [16894,17156]
===
match
---
argument [17020,17051]
argument [16962,16993]
===
match
---
name: cache_key [26254,26263]
name: cache_key [26167,26176]
===
match
---
operator: @ [5863,5864]
operator: @ [5863,5864]
===
match
---
atom_expr [26452,26560]
atom_expr [26365,26473]
===
match
---
trailer [25461,25471]
trailer [25374,25384]
===
match
---
name: self [9356,9360]
name: self [9356,9360]
===
match
---
suite [23995,26615]
suite [23908,26528]
===
match
---
name: self [2926,2930]
name: self [2926,2930]
===
match
---
name: self [12049,12053]
name: self [12049,12053]
===
match
---
string: 'test' [30579,30585]
string: 'test' [30438,30444]
===
match
---
simple_stmt [3361,3377]
simple_stmt [3361,3377]
===
match
---
operator: } [3122,3123]
operator: } [3122,3123]
===
match
---
operator: ** [27688,27690]
operator: ** [27601,27603]
===
match
---
atom_expr [15946,15960]
atom_expr [15888,15902]
===
match
---
expr_stmt [11792,11818]
expr_stmt [11792,11818]
===
match
---
name: sensor_exception [22139,22155]
name: sensor_exception [22052,22068]
===
match
---
atom_expr [4986,5006]
atom_expr [4986,5006]
===
match
---
trailer [4996,5005]
trailer [4996,5005]
===
match
---
name: session [15312,15319]
name: session [15254,15261]
===
match
---
name: sensor_work [18724,18735]
name: sensor_work [18683,18694]
===
match
---
name: state [6718,6723]
name: state [6718,6723]
===
match
---
trailer [27042,27048]
trailer [26955,26961]
===
match
---
funcdef [21959,23437]
funcdef [21872,23350]
===
match
---
atom_expr [3168,3188]
atom_expr [3168,3188]
===
match
---
trailer [9895,9913]
trailer [9895,9913]
===
match
---
dotted_name [1459,1476]
dotted_name [1459,1476]
===
match
---
expr_stmt [27830,27844]
expr_stmt [27743,27757]
===
match
---
trailer [30108,30114]
trailer [29967,29973]
===
match
---
name: state [23687,23692]
name: state [23600,23605]
===
match
---
operator: = [22229,22230]
operator: = [22142,22143]
===
match
---
name: info [13150,13154]
name: info [13150,13154]
===
match
---
name: Exception [17260,17269]
name: Exception [17202,17211]
===
match
---
name: ti_key [27185,27191]
name: ti_key [27098,27104]
===
match
---
trailer [19207,19213]
trailer [19166,19172]
===
match
---
comparison [7199,7263]
comparison [7199,7263]
===
match
---
arglist [27185,27197]
arglist [27098,27110]
===
match
---
trailer [14764,14771]
trailer [14706,14713]
===
match
---
param [12604,12609]
param [12604,12609]
===
match
---
return_stmt [10094,10105]
return_stmt [10094,10105]
===
match
---
atom_expr [20336,20349]
atom_expr [20295,20308]
===
match
---
simple_stmt [29587,29651]
simple_stmt [29446,29510]
===
match
---
trailer [27757,27770]
trailer [27670,27683]
===
match
---
atom_expr [13900,13954]
atom_expr [13842,13896]
===
match
---
param [15305,15311]
param [15247,15253]
===
match
---
funcdef [23951,26615]
funcdef [23864,26528]
===
match
---
atom_expr [19248,19339]
atom_expr [19207,19298]
===
match
---
atom_expr [3080,3095]
atom_expr [3080,3095]
===
match
---
import_as_names [1006,1042]
import_as_names [1006,1042]
===
match
---
if_stmt [20298,21006]
if_stmt [20257,20965]
===
match
---
atom_expr [23134,23212]
atom_expr [23047,23125]
===
match
---
trailer [19419,19423]
trailer [19378,19382]
===
match
---
trailer [27396,27419]
trailer [27309,27332]
===
match
---
name: logger [4916,4922]
name: logger [4916,4922]
===
match
---
simple_stmt [13571,13589]
simple_stmt [13571,13589]
===
match
---
operator: = [11992,11993]
operator: = [11992,11993]
===
match
---
comparison [13025,13054]
comparison [13025,13054]
===
match
---
arith_expr [27489,27564]
arith_expr [27402,27477]
===
match
---
name: handler [4469,4476]
name: handler [4469,4476]
===
match
---
comparison [18773,18802]
comparison [18732,18761]
===
match
---
trailer [19066,19071]
trailer [19025,19030]
===
match
---
simple_stmt [1865,1889]
simple_stmt [1865,1889]
===
match
---
name: self [11412,11416]
name: self [11412,11416]
===
match
---
name: self [5985,5989]
name: self [5985,5989]
===
match
---
simple_stmt [6494,6521]
simple_stmt [6494,6521]
===
match
---
atom_expr [18949,19029]
atom_expr [18908,18988]
===
match
---
name: x [14011,14012]
name: x [13953,13954]
===
match
---
parameters [12603,12623]
parameters [12603,12623]
===
match
---
atom_expr [17542,17559]
atom_expr [17551,17568]
===
match
---
name: sensor_work [24666,24677]
name: sensor_work [24579,24590]
===
match
---
name: logging [854,861]
name: logging [854,861]
===
match
---
name: si [3460,3462]
name: si [3460,3462]
===
match
---
operator: = [24763,24764]
operator: = [24676,24677]
===
match
---
trailer [29716,29735]
trailer [29575,29594]
===
match
---
name: task_execution_timeout [21633,21655]
name: task_execution_timeout [21546,21568]
===
match
---
operator: = [15872,15873]
operator: = [15814,15815]
===
match
---
if_stmt [27428,27701]
if_stmt [27341,27614]
===
match
---
name: Stats [28785,28790]
name: Stats [28698,28703]
===
match
---
number: 130 [7618,7621]
number: 130 [7618,7621]
===
match
---
operator: , [21226,21227]
operator: , [21139,21140]
===
match
---
simple_stmt [11871,11901]
simple_stmt [11871,11901]
===
match
---
name: utcnow [20552,20558]
name: utcnow [20511,20517]
===
match
---
operator: @ [5694,5695]
operator: @ [5694,5695]
===
match
---
name: poke_context [27758,27770]
name: poke_context [27671,27683]
===
match
---
operator: , [12608,12609]
operator: , [12608,12609]
===
match
---
trailer [24277,24296]
trailer [24190,24209]
===
match
---
atom_expr [19408,19486]
atom_expr [19367,19445]
===
match
---
trailer [17545,17559]
trailer [17554,17568]
===
match
---
suite [24783,25629]
suite [24696,25542]
===
match
---
trailer [17012,17052]
trailer [16954,16994]
===
match
---
expr_stmt [3518,3553]
expr_stmt [3518,3553]
===
match
---
atom_expr [7849,7881]
atom_expr [7849,7881]
===
match
---
name: sensor_work [23491,23502]
name: sensor_work [23404,23415]
===
match
---
import_from [933,973]
import_from [933,973]
===
match
---
if_stmt [28075,28134]
if_stmt [27988,28047]
===
match
---
name: ti [19160,19162]
name: ti [19119,19121]
===
match
---
name: _execute_sensor_work [23955,23975]
name: _execute_sensor_work [23868,23888]
===
match
---
atom_expr [12870,12883]
atom_expr [12870,12883]
===
match
---
atom_expr [7220,7239]
atom_expr [7220,7239]
===
match
---
name: cached_dedup_works [28030,28048]
name: cached_dedup_works [27943,27961]
===
match
---
suite [15850,16035]
suite [15792,15977]
===
match
---
name: dag_id [14476,14482]
name: dag_id [14418,14424]
===
match
---
return_stmt [9884,9913]
return_stmt [9884,9913]
===
match
---
operator: , [26753,26754]
operator: , [26666,26667]
===
match
---
parameters [17617,17657]
parameters [17626,17666]
===
match
---
name: helpers [1230,1237]
name: helpers [1230,1237]
===
match
---
name: property [9733,9741]
name: property [9733,9741]
===
match
---
operator: , [5836,5837]
operator: , [5836,5837]
===
match
---
simple_stmt [24040,24074]
simple_stmt [23953,23987]
===
match
---
name: info [25253,25257]
name: info [25166,25170]
===
match
---
name: dictConfigurator [4354,4370]
name: dictConfigurator [4354,4370]
===
match
---
name: si [4814,4816]
name: si [4814,4816]
===
match
---
operator: == [19771,19773]
operator: == [19730,19732]
===
match
---
expr_stmt [12155,12187]
expr_stmt [12155,12187]
===
match
---
operator: = [14118,14119]
operator: = [14060,14061]
===
match
---
suite [26923,26965]
suite [26836,26878]
===
match
---
atom_expr [20371,20382]
atom_expr [20330,20341]
===
match
---
expr_stmt [17181,17213]
expr_stmt [17123,17155]
===
match
---
name: super [11638,11643]
name: super [11638,11643]
===
match
---
trailer [28089,28095]
trailer [28002,28008]
===
match
---
trailer [13939,13953]
trailer [13881,13895]
===
match
---
name: copy [26794,26798]
name: copy [26707,26711]
===
match
---
trailer [27120,27131]
trailer [27033,27044]
===
match
---
name: execution_date [20177,20191]
name: execution_date [20136,20150]
===
match
---
trailer [11898,11900]
trailer [11898,11900]
===
match
---
operator: = [19624,19625]
operator: = [19583,19584]
===
match
---
trailer [23097,23099]
trailer [23010,23012]
===
match
---
trailer [24395,24406]
trailer [24308,24319]
===
match
---
atom_expr [3406,3419]
atom_expr [3406,3419]
===
match
---
if_stmt [24800,25561]
if_stmt [24713,25474]
===
match
---
trailer [19726,19732]
trailer [19685,19691]
===
match
---
operator: , [29009,29010]
operator: , [28922,28923]
===
match
---
simple_stmt [7051,7167]
simple_stmt [7051,7167]
===
match
---
trailer [13675,13679]
trailer [13675,13679]
===
match
---
comparison [14011,14037]
comparison [13953,13979]
===
match
---
import_from [975,1042]
import_from [975,1042]
===
match
---
atom_expr [9535,9556]
atom_expr [9535,9556]
===
match
---
decorator [5694,5704]
decorator [5694,5704]
===
match
---
param [18691,18703]
param [18650,18662]
===
match
---
name: cache_key [23000,23009]
name: cache_key [22913,22922]
===
match
---
name: close [5589,5594]
name: close [5589,5594]
===
match
---
parameters [27212,27231]
parameters [27125,27144]
===
match
---
name: loads [3162,3167]
name: loads [3162,3167]
===
match
---
atom_expr [6529,6542]
atom_expr [6529,6542]
===
match
---
import_name [832,848]
import_name [832,848]
===
match
---
name: exception_info [7508,7522]
name: exception_info [7508,7522]
===
match
---
name: subject [18444,18451]
name: subject [18453,18460]
===
match
---
if_stmt [3644,3716]
if_stmt [3644,3716]
===
match
---
name: si [3100,3102]
name: si [3100,3102]
===
match
---
trailer [7942,7944]
trailer [7942,7944]
===
match
---
name: self [13141,13145]
name: self [13141,13145]
===
match
---
name: _process_sensor_work_with_cached_state [23446,23484]
name: _process_sensor_work_with_cached_state [23359,23397]
===
match
---
import_as_names [956,973]
import_as_names [956,973]
===
match
---
expr_stmt [6462,6485]
expr_stmt [6462,6485]
===
match
---
arglist [5129,5139]
arglist [5129,5139]
===
match
---
trailer [20820,20825]
trailer [20779,20784]
===
match
---
trailer [23652,23672]
trailer [23565,23585]
===
match
---
import_from [1497,1546]
import_from [1497,1546]
===
match
---
trailer [14761,14803]
trailer [14703,14745]
===
match
---
parameters [3992,3994]
parameters [3992,3994]
===
match
---
trailer [23084,23097]
trailer [22997,23010]
===
match
---
atom_expr [19148,19170]
atom_expr [19107,19129]
===
match
---
trailer [18792,18802]
trailer [18751,18761]
===
match
---
name: self [3836,3840]
name: self [3836,3840]
===
match
---
operator: , [24107,24108]
operator: , [24020,24021]
===
match
---
name: poke_interval [12258,12271]
name: poke_interval [12258,12271]
===
match
---
atom_expr [5824,5836]
atom_expr [5824,5836]
===
match
---
operator: , [29324,29325]
operator: , [29183,29184]
===
match
---
trailer [14754,14836]
trailer [14696,14778]
===
match
---
name: SI [16597,16599]
name: SI [16539,16541]
===
match
---
trailer [3500,3509]
trailer [3500,3509]
===
match
---
operator: == [28203,28205]
operator: == [28116,28118]
===
match
---
arglist [12426,12452]
arglist [12426,12452]
===
match
---
name: send_email [18426,18436]
name: send_email [18435,18445]
===
match
---
name: self [27798,27802]
name: self [27711,27715]
===
match
---
simple_stmt [25578,25629]
simple_stmt [25491,25542]
===
match
---
simple_stmt [1639,1682]
simple_stmt [1639,1682]
===
match
---
name: len [13936,13939]
name: len [13878,13881]
===
match
---
trailer [12881,12883]
trailer [12881,12883]
===
match
---
simple_stmt [16099,16116]
simple_stmt [16041,16058]
===
match
---
expr_stmt [20529,20560]
expr_stmt [20488,20519]
===
match
---
atom_expr [1923,1947]
atom_expr [1923,1947]
===
match
---
suite [16128,17244]
suite [16070,17186]
===
match
---
trailer [28215,28222]
trailer [28128,28135]
===
match
---
operator: , [2879,2880]
operator: , [2879,2880]
===
match
---
operator: , [20445,20446]
operator: , [20404,20405]
===
match
---
operator: { [12037,12038]
operator: { [12037,12038]
===
match
---
operator: , [7979,7980]
operator: , [7979,7980]
===
match
---
name: cached_work [28010,28021]
name: cached_work [27923,27934]
===
match
---
atom_expr [5680,5688]
atom_expr [5680,5688]
===
match
---
expr_stmt [1865,1888]
expr_stmt [1865,1888]
===
match
---
name: dictConfigurator [1904,1920]
name: dictConfigurator [1904,1920]
===
match
---
trailer [21782,21796]
trailer [21695,21709]
===
match
---
name: dag_id [3751,3757]
name: dag_id [3751,3757]
===
match
---
name: state [6576,6581]
name: state [6576,6581]
===
match
---
name: self [26574,26578]
name: self [26487,26491]
===
match
---
trailer [24090,24121]
trailer [24003,24034]
===
match
---
simple_stmt [5025,5066]
simple_stmt [5025,5066]
===
match
---
name: tis [13607,13610]
name: tis [13607,13610]
===
match
---
name: start_date [3447,3457]
name: start_date [3447,3457]
===
match
---
name: log [1362,1365]
name: log [1362,1365]
===
match
---
name: property [5864,5872]
name: property [5864,5872]
===
match
---
suite [12624,14133]
suite [12624,14075]
===
match
---
name: airflow [1601,1608]
name: airflow [1601,1608]
===
match
---
atom_expr [16306,16315]
atom_expr [16248,16257]
===
match
---
operator: , [11443,11444]
operator: , [11443,11444]
===
match
---
name: is_expired [7025,7035]
name: is_expired [7025,7035]
===
match
---
operator: } [3220,3221]
operator: } [3220,3221]
===
match
---
name: Stats [29049,29054]
name: Stats [28962,28967]
===
match
---
arglist [24091,24120]
arglist [24004,24033]
===
match
---
param [14203,14215]
param [14145,14157]
===
match
---
name: config [1754,1760]
name: config [1754,1760]
===
match
---
name: set_state [24944,24953]
name: set_state [24857,24866]
===
match
---
atom_expr [30330,30378]
atom_expr [30189,30237]
===
match
---
operator: = [12035,12036]
operator: = [12035,12036]
===
match
---
decorated [5694,5858]
decorated [5694,5858]
===
match
---
name: ti [20665,20667]
name: ti [20624,20626]
===
match
---
trailer [3281,3285]
trailer [3281,3285]
===
match
---
name: end_date [20532,20540]
name: end_date [20491,20499]
===
match
---
atom_expr [24130,24201]
atom_expr [24043,24114]
===
match
---
trailer [24755,24782]
trailer [24668,24695]
===
match
---
try_stmt [24726,26615]
try_stmt [24639,26528]
===
match
---
name: task_execution_timeout [21702,21724]
name: task_execution_timeout [21615,21637]
===
match
---
name: __init__ [2866,2874]
name: __init__ [2866,2874]
===
match
---
name: sensor_work [24168,24179]
name: sensor_work [24081,24092]
===
match
---
arglist [15170,15206]
arglist [15112,15148]
===
match
---
expr_stmt [7685,7726]
expr_stmt [7685,7726]
===
match
---
name: ti [20581,20583]
name: ti [20540,20542]
===
match
---
atom_expr [5985,5998]
atom_expr [5985,5998]
===
match
---
name: sensor_work [25087,25098]
name: sensor_work [25000,25011]
===
match
---
simple_stmt [24082,24122]
simple_stmt [23995,24035]
===
match
---
name: shard_min [12102,12111]
name: shard_min [12102,12111]
===
match
---
name: log [13905,13908]
name: log [13847,13850]
===
match
---
trailer [21524,21532]
trailer [21437,21445]
===
match
---
name: count [15137,15142]
name: count [15079,15084]
===
match
---
name: self [13900,13904]
name: self [13842,13846]
===
match
---
atom_expr [30331,30348]
atom_expr [30190,30207]
===
match
---
name: sensor_exception [27104,27120]
name: sensor_exception [27017,27033]
===
match
---
atom_expr [25041,25061]
atom_expr [24954,24974]
===
match
---
param [7564,7623]
param [7564,7623]
===
match
---
simple_stmt [8753,8795]
simple_stmt [8753,8795]
===
match
---
name: start_date [3463,3473]
name: start_date [3463,3473]
===
match
---
name: fail_current_run [8850,8866]
name: fail_current_run [8850,8866]
===
match
---
trailer [26131,26146]
trailer [26044,26059]
===
match
---
expr_stmt [28244,28267]
expr_stmt [28157,28180]
===
match
---
operator: , [27217,27218]
operator: , [27130,27131]
===
match
---
trailer [22473,22583]
trailer [22386,22496]
===
match
---
simple_stmt [3562,3606]
simple_stmt [3562,3606]
===
match
---
comparison [19805,19840]
comparison [19764,19799]
===
match
---
atom_expr [3049,3066]
atom_expr [3049,3066]
===
match
---
operator: , [5317,5318]
operator: , [5317,5318]
===
match
---
atom_expr [25514,25560]
atom_expr [25427,25473]
===
match
---
simple_stmt [19148,19171]
simple_stmt [19107,19130]
===
match
---
expr_stmt [28570,28594]
expr_stmt [28483,28507]
===
match
---
simple_stmt [11827,11863]
simple_stmt [11827,11863]
===
match
---
name: LANDED [23542,23548]
name: LANDED [23455,23461]
===
match
---
simple_stmt [3049,3124]
simple_stmt [3049,3124]
===
match
---
trailer [16212,16217]
trailer [16154,16159]
===
match
---
expr_stmt [19556,19608]
expr_stmt [19515,19567]
===
match
---
simple_stmt [9884,9914]
simple_stmt [9884,9914]
===
match
---
operator: = [15914,15915]
operator: = [15856,15857]
===
match
---
trailer [14485,14493]
trailer [14427,14435]
===
match
---
expr_stmt [18263,18341]
expr_stmt [18272,18350]
===
match
---
simple_stmt [3725,3942]
simple_stmt [3725,3942]
===
match
---
name: ti [15829,15831]
name: ti [15771,15773]
===
match
---
atom_expr [14751,14836]
atom_expr [14693,14778]
===
match
---
trailer [29205,29215]
trailer [29113,29123]
===
match
---
name: self [3132,3136]
name: self [3132,3136]
===
match
---
atom_expr [29549,29574]
atom_expr [29408,29433]
===
match
---
name: formatter_config_copy [4185,4206]
name: formatter_config_copy [4185,4206]
===
match
---
atom_expr [4882,4895]
atom_expr [4882,4895]
===
match
---
trailer [16910,16919]
trailer [16852,16861]
===
match
---
name: new_sensor_works [13964,13980]
name: new_sensor_works [13906,13922]
===
match
---
name: count [14996,15001]
name: count [14938,14943]
===
match
---
argument [7610,7621]
argument [7610,7621]
===
match
---
operator: = [21177,21178]
operator: = [21090,21091]
===
match
---
param [9767,9771]
param [9767,9771]
===
match
---
simple_stmt [3518,3554]
simple_stmt [3518,3554]
===
match
---
trailer [14854,14858]
trailer [14796,14800]
===
match
---
trailer [16549,16558]
trailer [16491,16500]
===
match
---
funcdef [4482,5419]
funcdef [4482,5419]
===
match
---
trailer [12461,12469]
trailer [12461,12469]
===
match
---
name: encoded_poke_context [6005,6025]
name: encoded_poke_context [6005,6025]
===
match
---
trailer [30424,30457]
trailer [30283,30316]
===
match
---
trailer [29215,29253]
trailer [29123,29161]
===
match
---
param [2881,2883]
param [2881,2883]
===
match
---
name: send_email [1332,1342]
name: send_email [1332,1342]
===
match
---
name: set_duration [20584,20596]
name: set_duration [20543,20555]
===
match
---
if_stmt [23520,23675]
if_stmt [23433,23588]
===
match
---
name: self [29384,29388]
name: self [29243,29247]
===
match
---
name: task_id [14776,14783]
name: task_id [14718,14725]
===
match
---
trailer [8711,8727]
trailer [8711,8727]
===
match
---
name: self [3049,3053]
name: self [3049,3053]
===
match
---
operator: , [13193,13194]
operator: , [13193,13194]
===
match
---
atom_expr [24764,24781]
atom_expr [24677,24694]
===
match
---
suite [21656,21726]
suite [21569,21639]
===
match
---
name: _load_sensor_works [29554,29572]
name: _load_sensor_works [29413,29431]
===
match
---
funcdef [9919,10202]
funcdef [9919,10202]
===
match
---
trailer [11941,11954]
trailer [11941,11954]
===
match
---
testlist_comp [14474,14511]
testlist_comp [14416,14453]
===
match
---
atom_expr [16293,16302]
atom_expr [16235,16244]
===
match
---
param [11598,11604]
param [11598,11604]
===
match
---
parameters [14182,14216]
parameters [14124,14158]
===
match
---
name: commit [17235,17241]
name: commit [17177,17183]
===
match
---
operator: , [11588,11589]
operator: , [11588,11589]
===
match
---
expr_stmt [3247,3285]
expr_stmt [3247,3285]
===
match
---
comp_op [14013,14019]
comp_op [13955,13961]
===
match
---
operator: = [12912,12913]
operator: = [12912,12913]
===
match
---
name: sensor_work [27609,27620]
name: sensor_work [27522,27533]
===
match
---
name: self [7220,7224]
name: self [7220,7224]
===
match
---
number: 1200 [7259,7263]
number: 1200 [7259,7263]
===
match
---
atom_expr [30381,30393]
atom_expr [30240,30252]
===
match
---
string: "Exception detected, retrying without failing current run." [23317,23376]
string: "Exception detected, retrying without failing current run." [23230,23289]
===
match
---
name: execution_date [2985,2999]
name: execution_date [2985,2999]
===
match
---
param [7532,7555]
param [7532,7555]
===
match
---
param [21222,21227]
param [21135,21140]
===
match
---
atom_expr [24046,24061]
atom_expr [23959,23974]
===
match
---
operator: = [3155,3156]
operator: = [3155,3156]
===
match
---
simple_stmt [975,1043]
simple_stmt [975,1043]
===
match
---
arglist [22297,22333]
arglist [22210,22246]
===
match
---
name: end_date [16707,16715]
name: end_date [16649,16657]
===
match
---
name: poke_hash [16562,16571]
name: poke_hash [16504,16513]
===
match
---
trailer [20667,20673]
trailer [20626,20632]
===
match
---
name: sensor_works [29774,29786]
name: sensor_works [29633,29645]
===
match
---
number: 0 [27843,27844]
number: 0 [27756,27757]
===
match
---
trailer [30212,30214]
trailer [30071,30073]
===
match
---
atom_expr [23604,23627]
atom_expr [23517,23540]
===
match
---
simple_stmt [29197,29254]
simple_stmt [29105,29162]
===
match
---
expr_stmt [5154,5176]
expr_stmt [5154,5176]
===
match
---
name: max_tis_per_query [15107,15124]
name: max_tis_per_query [15049,15066]
===
match
---
expr_stmt [27929,27957]
expr_stmt [27842,27870]
===
match
---
operator: , [21945,21946]
operator: , [21858,21859]
===
match
---
name: self [15102,15106]
name: self [15044,15048]
===
match
---
simple_stmt [5463,5506]
simple_stmt [5463,5506]
===
match
---
trailer [13772,13782]
trailer [13767,13777]
===
match
---
name: err [1824,1827]
name: err [1824,1827]
===
match
---
operator: = [19699,19700]
operator: = [19658,19659]
===
match
---
simple_stmt [817,832]
simple_stmt [817,832]
===
match
---
atom_expr [12457,12469]
atom_expr [12457,12469]
===
match
---
name: self [8845,8849]
name: self [8845,8849]
===
match
---
try_stmt [19539,21184]
try_stmt [19498,21097]
===
match
---
suite [24826,25346]
suite [24739,25259]
===
match
---
operator: = [8776,8777]
operator: = [8776,8777]
===
match
---
param [2875,2880]
param [2875,2880]
===
match
---
simple_stmt [9306,9389]
simple_stmt [9306,9389]
===
match
---
name: helpers [15034,15041]
name: helpers [14976,14983]
===
match
---
trailer [23705,23716]
trailer [23618,23629]
===
match
---
name: sensor_task [6467,6478]
name: sensor_task [6467,6478]
===
match
---
operator: , [14482,14483]
operator: , [14424,14425]
===
match
---
operator: > [7257,7258]
operator: > [7257,7258]
===
match
---
suite [22005,23437]
suite [21918,23350]
===
match
---
operator: , [17526,17527]
operator: , [17535,17536]
===
match
---
name: error [19164,19169]
name: error [19123,19128]
===
match
---
trailer [4816,4824]
trailer [4816,4824]
===
match
---
trailer [17324,17328]
trailer [17261,17265]
===
match
---
operator: = [4778,4779]
operator: = [4778,4779]
===
match
---
name: log [13769,13772]
name: log [13764,13767]
===
match
---
simple_stmt [6856,6874]
simple_stmt [6856,6874]
===
match
---
name: len [13195,13198]
name: len [13195,13198]
===
match
---
comparison [3836,3879]
comparison [3836,3879]
===
match
---
name: si [4713,4715]
name: si [4713,4715]
===
match
---
operator: = [14470,14471]
operator: = [14412,14413]
===
match
---
simple_stmt [4108,4177]
simple_stmt [4108,4177]
===
match
---
trailer [23423,23436]
trailer [23336,23349]
===
match
---
for_stmt [28394,28699]
for_stmt [28307,28612]
===
match
---
arglist [21509,21532]
arglist [21422,21445]
===
match
---
trailer [11654,11671]
trailer [11654,11671]
===
match
---
simple_stmt [23296,23378]
simple_stmt [23209,23291]
===
match
---
trailer [3012,3023]
trailer [3012,3023]
===
match
---
simple_stmt [6436,6454]
simple_stmt [6436,6454]
===
match
---
trailer [4370,4390]
trailer [4370,4390]
===
match
---
name: execution_context [3171,3188]
name: execution_context [3171,3188]
===
match
---
parameters [18201,18228]
parameters [18210,18237]
===
match
---
suite [24297,24426]
suite [24210,24339]
===
match
---
atom [16156,16693]
atom [16098,16635]
===
match
---
name: ti [16752,16754]
name: ti [16694,16696]
===
match
---
string: """Key used to query in smart sensor for cached sensor work.""" [5906,5969]
string: """Key used to query in smart sensor for cached sensor work.""" [5906,5969]
===
match
---
param [17644,17656]
param [17653,17665]
===
match
---
expr_stmt [8707,8744]
expr_stmt [8707,8744]
===
match
---
name: task_timeout [21688,21700]
name: task_timeout [21601,21613]
===
match
---
trailer [3592,3605]
trailer [3592,3605]
===
match
---
simple_stmt [12633,12829]
simple_stmt [12633,12829]
===
match
---
name: Exception [1811,1820]
name: Exception [1811,1820]
===
match
---
name: poke [24808,24812]
name: poke [24721,24725]
===
match
---
atom_expr [25961,25998]
atom_expr [25874,25911]
===
match
---
name: ti [20324,20326]
name: ti [20283,20285]
===
match
---
operator: , [3667,3668]
operator: , [3667,3668]
===
match
---
atom_expr [2941,2951]
atom_expr [2941,2951]
===
match
---
suite [16861,16891]
suite [16803,16833]
===
match
---
number: 120 [5173,5176]
number: 120 [5173,5176]
===
match
---
string: "%d tasks detected." [13914,13934]
string: "%d tasks detected." [13856,13876]
===
match
---
trailer [14722,14726]
trailer [14664,14668]
===
match
---
atom_expr [16508,16521]
atom_expr [16450,16463]
===
match
---
atom_expr [12415,12453]
atom_expr [12415,12453]
===
match
---
trailer [21072,21080]
trailer [21026,21034]
===
match
---
name: merge [20698,20703]
name: merge [20657,20662]
===
match
---
operator: = [27954,27955]
operator: = [27867,27868]
===
match
---
name: kwargs [11664,11670]
name: kwargs [11664,11670]
===
match
---
expr_stmt [15863,15879]
expr_stmt [15805,15821]
===
match
---
suite [7630,7945]
suite [7630,7945]
===
match
---
trailer [19478,19485]
trailer [19437,19444]
===
match
---
string: "smart_sensor_operator.loaded_tasks" [29675,29711]
string: "smart_sensor_operator.loaded_tasks" [29534,29570]
===
match
---
trailer [22413,22430]
trailer [22326,22343]
===
match
---
not_test [9531,9556]
not_test [9531,9556]
===
match
---
name: setFormatter [4430,4442]
name: setFormatter [4430,4442]
===
match
---
atom_expr [20496,20508]
atom_expr [20455,20467]
===
match
---
name: PokeState [28206,28215]
name: PokeState [28119,28128]
===
match
---
operator: , [15097,15098]
operator: , [15039,15040]
===
match
---
name: self [9646,9650]
name: self [9646,9650]
===
match
---
operator: <= [18787,18789]
operator: <= [18746,18748]
===
match
---
name: shard_min [13077,13086]
name: shard_min [13077,13086]
===
match
---
try_stmt [3230,3398]
try_stmt [3230,3398]
===
match
---
name: state [20327,20332]
name: state [20286,20291]
===
match
---
trailer [29938,29942]
trailer [29797,29801]
===
match
---
atom_expr [3562,3587]
atom_expr [3562,3587]
===
match
---
name: self [5448,5452]
name: self [5448,5452]
===
match
---
atom_expr [12005,12034]
atom_expr [12005,12034]
===
match
---
trailer [28966,29036]
trailer [28879,28949]
===
match
---
name: self [5035,5039]
name: self [5035,5039]
===
match
---
name: len [29627,29630]
name: len [29486,29489]
===
match
---
name: hostname [20374,20382]
name: hostname [20333,20341]
===
match
---
name: sensor_work [23641,23652]
name: sensor_work [23554,23565]
===
match
---
operator: , [24166,24167]
operator: , [24079,24080]
===
match
---
name: info [19067,19071]
name: info [19026,19030]
===
match
---
operator: = [7548,7549]
operator: = [7548,7549]
===
match
---
name: gauge [28961,28966]
name: gauge [28874,28879]
===
match
---
trailer [26800,26806]
trailer [26713,26719]
===
match
---
operator: = [16075,16076]
operator: = [16017,16018]
===
match
---
name: SI [13056,13058]
name: SI [13056,13058]
===
match
---
simple_stmt [6054,6403]
simple_stmt [6054,6403]
===
match
---
name: count_exception_failures [27929,27953]
name: count_exception_failures [27842,27866]
===
match
---
funcdef [27204,27772]
funcdef [27117,27685]
===
match
---
argument [14755,14835]
argument [14697,14777]
===
match
---
trailer [11753,11767]
trailer [11753,11767]
===
match
---
trailer [29533,29535]
trailer [29392,29394]
===
match
---
trailer [4390,4413]
trailer [4390,4413]
===
match
---
name: PokeState [26122,26131]
name: PokeState [26035,26044]
===
match
---
name: utils [1217,1222]
name: utils [1217,1222]
===
match
---
operator: = [23010,23011]
operator: = [22923,22924]
===
match
---
operator: , [18284,18285]
operator: , [18293,18294]
===
match
---
funcdef [5424,5689]
funcdef [5424,5689]
===
match
---
suite [1860,1904]
suite [1860,1904]
===
match
---
arglist [16239,16453]
arglist [16181,16395]
===
match
---
name: sensor_exception [22231,22247]
name: sensor_exception [22144,22160]
===
match
---
param [17637,17643]
param [17646,17652]
===
match
---
trailer [2910,2917]
trailer [2910,2917]
===
match
---
suite [14902,14947]
suite [14844,14889]
===
match
---
name: fail_current_run [28631,28647]
name: fail_current_run [28544,28560]
===
match
---
name: self [6793,6797]
name: self [6793,6797]
===
match
---
name: self [27213,27217]
name: self [27126,27130]
===
match
---
operator: = [6447,6448]
operator: = [6447,6448]
===
match
---
name: new_sensor_works [14073,14089]
name: new_sensor_works [14015,14031]
===
match
---
trailer [15865,15871]
trailer [15807,15813]
===
match
---
string: "Time is out for smart sensor." [30425,30456]
string: "Time is out for smart sensor." [30284,30315]
===
match
---
name: execution_context [18378,18395]
name: execution_context [18387,18404]
===
match
---
operator: == [28307,28309]
operator: == [28220,28222]
===
match
---
name: execution_context [21487,21504]
name: execution_context [21400,21417]
===
match
---
comparison [19782,19803]
comparison [19741,19762]
===
match
---
atom_expr [6494,6513]
atom_expr [6494,6513]
===
match
---
name: encoded_poke_context [24180,24200]
name: encoded_poke_context [24093,24113]
===
match
---
name: sensor_work [18366,18377]
name: sensor_work [18375,18386]
===
match
---
operator: , [13828,13829]
operator: , [13823,13824]
===
match
---
simple_stmt [9699,9727]
simple_stmt [9699,9727]
===
match
---
name: configure_handler [4295,4312]
name: configure_handler [4295,4312]
===
match
---
trailer [14743,14750]
trailer [14685,14692]
===
match
---
import_name [789,804]
import_name [789,804]
===
match
---
name: timezone [29868,29876]
name: timezone [29727,29735]
===
match
---
trailer [30163,30176]
trailer [30022,30035]
===
match
---
name: state [24691,24696]
name: state [24604,24609]
===
match
---
name: sensor_work [23562,23573]
name: sensor_work [23475,23486]
===
match
---
atom_expr [9209,9236]
atom_expr [9209,9236]
===
match
---
simple_stmt [21057,21128]
simple_stmt [21011,21097]
===
match
---
decorated [3947,4477]
decorated [3947,4477]
===
match
---
if_stmt [15934,16035]
if_stmt [15876,15977]
===
match
---
name: execution_date [16394,16408]
name: execution_date [16336,16350]
===
match
---
param [4511,4513]
param [4511,4513]
===
match
---
name: cached_work [28078,28089]
name: cached_work [27991,28002]
===
match
---
name: print [5680,5685]
name: print [5680,5685]
===
match
---
atom_expr [12426,12438]
atom_expr [12426,12438]
===
match
---
trailer [16596,16621]
trailer [16538,16563]
===
match
---
except_clause [13693,13714]
except_clause [13693,13709]
===
match
---
param [29326,29333]
param [29185,29192]
===
match
---
name: gauge [28791,28796]
name: gauge [28704,28709]
===
match
---
parameters [4504,4514]
parameters [4504,4514]
===
match
---
trailer [23573,23577]
trailer [23486,23490]
===
match
---
trailer [5384,5396]
trailer [5384,5396]
===
match
---
suite [29434,30481]
suite [29293,30340]
===
match
---
param [14189,14202]
param [14131,14144]
===
match
---
operator: , [6574,6575]
operator: , [6574,6575]
===
match
---
param [23485,23490]
param [23398,23403]
===
match
---
name: LANDED [24964,24970]
name: LANDED [24877,24883]
===
match
---
atom [4130,4176]
atom [4130,4176]
===
match
---
simple_stmt [12155,12188]
simple_stmt [12155,12188]
===
match
---
name: state [20657,20662]
name: state [20616,20621]
===
match
---
name: self [8935,8939]
name: self [8935,8939]
===
match
---
name: _handle_poke_exception [23910,23932]
name: _handle_poke_exception [23823,23845]
===
match
---
name: ti [18790,18792]
name: ti [18749,18751]
===
match
---
suite [23511,23946]
suite [23424,23859]
===
match
---
operator: } [4175,4176]
operator: } [4175,4176]
===
match
---
suite [2885,3606]
suite [2885,3606]
===
match
---
name: task_id [20165,20172]
name: task_id [20124,20131]
===
match
---
operator: , [16452,16453]
operator: , [16394,16395]
===
match
---
name: cached_exception [28515,28531]
name: cached_exception [28428,28444]
===
match
---
funcdef [3965,4477]
funcdef [3965,4477]
===
match
---
name: session [1516,1523]
name: session [1516,1523]
===
match
---
simple_stmt [20529,20561]
simple_stmt [20488,20520]
===
match
---
operator: < [12470,12471]
operator: < [12470,12471]
===
match
---
simple_stmt [13645,13681]
simple_stmt [13645,13681]
===
match
---
trailer [26181,26206]
trailer [26094,26119]
===
match
---
funcdef [5877,6026]
funcdef [5877,6026]
===
match
---
dotted_name [1502,1523]
dotted_name [1502,1523]
===
match
---
atom_expr [12242,12286]
atom_expr [12242,12286]
===
match
---
name: should_fail_current_run [9398,9421]
name: should_fail_current_run [9398,9421]
===
match
---
suite [18246,18467]
suite [18255,18476]
===
match
---
operator: , [27191,27192]
operator: , [27104,27105]
===
match
---
name: SmartSensorOperator [30551,30570]
name: SmartSensorOperator [30410,30429]
===
match
---
simple_stmt [18263,18342]
simple_stmt [18272,18351]
===
match
---
operator: = [11923,11924]
operator: = [11923,11924]
===
match
---
string: "Updated hostname on %s tis." [15170,15199]
string: "Updated hostname on %s tis." [15112,15141]
===
match
---
trailer [3053,3066]
trailer [3053,3066]
===
match
---
name: PokeState [23532,23541]
name: PokeState [23445,23454]
===
match
---
name: sensor_instance [19932,19947]
name: sensor_instance [19891,19906]
===
match
---
simple_stmt [11937,11960]
simple_stmt [11937,11960]
===
match
---
name: TaskInstance [14441,14453]
name: TaskInstance [14383,14395]
===
match
---
simple_stmt [15026,15126]
simple_stmt [14968,15068]
===
match
---
arglist [19429,19485]
arglist [19388,19444]
===
match
---
trailer [18735,18753]
trailer [18694,18712]
===
match
---
operator: = [13981,13982]
operator: = [13923,13924]
===
match
---
operator: = [12840,12841]
operator: = [12840,12841]
===
match
---
trailer [21508,21533]
trailer [21421,21446]
===
match
---
expr_stmt [22223,22262]
expr_stmt [22136,22175]
===
match
---
name: sensor_works [13645,13657]
name: sensor_works [13645,13657]
===
match
---
trailer [7215,7217]
trailer [7215,7217]
===
match
---
name: self [12604,12608]
name: self [12604,12608]
===
match
---
name: get_hostname [1484,1496]
name: get_hostname [1484,1496]
===
match
---
operator: == [20140,20142]
operator: == [20099,20101]
===
match
---
operator: , [18646,18647]
operator: , [18605,18606]
===
match
---
operator: , [29625,29626]
operator: , [29484,29485]
===
match
---
name: ti_key [19120,19126]
name: ti_key [19079,19085]
===
match
---
suite [28648,28699]
suite [28561,28612]
===
match
---
trailer [3424,3433]
trailer [3424,3433]
===
match
---
operator: , [14201,14202]
operator: , [14143,14144]
===
match
---
argument [24756,24781]
argument [24669,24694]
===
match
---
name: float [12279,12284]
name: float [12279,12284]
===
match
---
suite [10081,10106]
suite [10081,10106]
===
match
---
atom_expr [29717,29734]
atom_expr [29576,29593]
===
match
---
name: warning [17329,17336]
name: warning [17266,17273]
===
match
---
operator: = [7768,7769]
operator: = [7768,7769]
===
match
---
arith_expr [30284,30313]
arith_expr [30143,30172]
===
match
---
name: sensor_work [23832,23843]
name: sensor_work [23745,23756]
===
match
---
name: sensor_work [25041,25052]
name: sensor_work [24954,24965]
===
match
---
trailer [8808,8834]
trailer [8808,8834]
===
match
---
name: error [21947,21952]
name: error [21860,21865]
===
match
---
dotted_name [1048,1062]
dotted_name [1048,1062]
===
match
---
name: list [27489,27493]
name: list [27402,27406]
===
match
---
name: LANDED [28216,28222]
name: LANDED [28129,28135]
===
match
---
if_stmt [21630,21726]
if_stmt [21543,21639]
===
match
---
name: self [9306,9310]
name: self [9306,9310]
===
match
---
atom_expr [20130,20139]
atom_expr [20089,20098]
===
match
---
name: ti_key [21120,21126]
name: ti_key [21074,21080]
===
match
---
funcdef [12193,12555]
funcdef [12193,12555]
===
match
---
name: int [12441,12444]
name: int [12441,12444]
===
match
---
name: count_poke_success [28244,28262]
name: count_poke_success [28157,28175]
===
match
---
name: ti_key [24004,24010]
name: ti_key [23917,23923]
===
match
---
operator: = [15032,15033]
operator: = [14974,14975]
===
match
---
trailer [22191,22214]
trailer [22104,22127]
===
match
---
expr_stmt [29447,29482]
expr_stmt [29306,29341]
===
match
---
trailer [2930,2938]
trailer [2930,2938]
===
match
---
trailer [21080,21127]
trailer [21034,21096]
===
match
---
name: ti_keys [14828,14835]
name: ti_keys [14770,14777]
===
match
---
name: try_number [4885,4895]
name: try_number [4885,4895]
===
match
---
simple_stmt [24372,24426]
simple_stmt [24285,24339]
===
match
---
name: self [11909,11913]
name: self [11909,11913]
===
match
---
comparison [19932,19980]
comparison [19891,19939]
===
match
---
trailer [30041,30090]
trailer [29900,29949]
===
match
---
name: self [29197,29201]
name: self [29105,29109]
===
match
---
name: sensor_instance [20704,20719]
name: sensor_instance [20663,20678]
===
match
---
import_as_names [1070,1123]
import_as_names [1070,1123]
===
match
---
name: UP_FOR_RETRY [18861,18873]
name: UP_FOR_RETRY [18820,18832]
===
match
---
trailer [5095,5104]
trailer [5095,5104]
===
match
---
operator: , [29099,29100]
operator: , [29012,29013]
===
match
---
simple_stmt [1043,1124]
simple_stmt [1043,1124]
===
match
---
name: sensor_works [14025,14037]
name: sensor_works [13967,13979]
===
match
---
trailer [5989,5998]
trailer [5989,5998]
===
match
---
operator: == [16352,16354]
operator: == [16294,16296]
===
match
---
name: cached_dedup_works [27378,27396]
name: cached_dedup_works [27291,27309]
===
match
---
trailer [22247,22262]
trailer [22160,22175]
===
match
---
expr_stmt [18358,18408]
expr_stmt [18367,18417]
===
match
---
name: tis [13199,13202]
name: tis [13199,13202]
===
match
---
trailer [23607,23627]
trailer [23520,23540]
===
match
---
simple_stmt [30029,30091]
simple_stmt [29888,29950]
===
match
---
atom_expr [17227,17243]
atom_expr [17169,17185]
===
match
---
comparison [3746,3773]
comparison [3746,3773]
===
match
---
atom_expr [9306,9333]
atom_expr [9306,9333]
===
match
---
name: task_id [19785,19792]
name: task_id [19744,19751]
===
match
---
simple_stmt [25942,26036]
simple_stmt [25855,25949]
===
match
---
suite [30261,30315]
suite [30120,30174]
===
match
---
atom_expr [19216,19228]
atom_expr [19175,19187]
===
match
---
import_from [1343,1398]
import_from [1343,1398]
===
match
---
name: timezone [21739,21747]
name: timezone [21652,21660]
===
match
---
trailer [27740,27745]
trailer [27653,27658]
===
match
---
simple_stmt [13964,14039]
simple_stmt [13906,13981]
===
match
---
expr_stmt [7890,7944]
expr_stmt [7890,7944]
===
match
---
string: 'airflow.task' [4943,4957]
string: 'airflow.task' [4943,4957]
===
match
---
name: self [5719,5723]
name: self [5719,5723]
===
match
---
name: cache_key [24473,24482]
name: cache_key [24386,24395]
===
match
---
simple_stmt [30551,30599]
simple_stmt [30410,30458]
===
match
---
if_stmt [26822,26965]
if_stmt [26735,26878]
===
match
---
suite [25691,26615]
suite [25604,26528]
===
match
---
decorator [17573,17590]
decorator [17582,17599]
===
match
---
simple_stmt [3389,3398]
simple_stmt [3389,3398]
===
match
---
param [18704,18706]
param [18663,18665]
===
match
---
name: SI [16306,16308]
name: SI [16248,16250]
===
match
---
name: ti [17013,17015]
name: ti [16955,16957]
===
match
---
name: filter [16489,16495]
name: filter [16431,16437]
===
match
---
simple_stmt [27647,27701]
simple_stmt [27560,27614]
===
match
---
simple_stmt [15892,15922]
simple_stmt [15834,15864]
===
match
---
name: provide_session [14139,14154]
name: provide_session [14081,14096]
===
match
---
name: self [14048,14052]
name: self [13990,13994]
===
match
---
param [7997,8019]
param [7997,8019]
===
match
---
name: dag_id [19764,19770]
name: dag_id [19723,19729]
===
match
---
atom [30595,30597]
atom [30454,30456]
===
match
---
name: sensor_work [23012,23023]
name: sensor_work [22925,22936]
===
match
---
atom [12914,13101]
atom [12914,13101]
===
match
---
name: self [28025,28029]
name: self [27938,27942]
===
match
---
trailer [20583,20596]
trailer [20542,20555]
===
match
---
name: utcnow [29366,29372]
name: utcnow [29225,29231]
===
match
---
suite [23717,23845]
suite [23630,23758]
===
match
---
atom [19701,19915]
atom [19660,19874]
===
match
---
name: sensor_work [21992,22003]
name: sensor_work [21905,21916]
===
match
---
expr_stmt [21827,21851]
expr_stmt [21740,21764]
===
match
---
atom_expr [27104,27133]
atom_expr [27017,27046]
===
match
---
funcdef [21189,21954]
funcdef [21102,21867]
===
match
---
name: si [3193,3195]
name: si [3193,3195]
===
match
---
suite [23283,23437]
suite [23196,23350]
===
match
---
suite [12474,12555]
suite [12474,12555]
===
match
---
suite [23892,23946]
suite [23805,23859]
===
match
---
name: self [23225,23229]
name: self [23138,23142]
===
match
---
atom_expr [9257,9284]
atom_expr [9257,9284]
===
match
---
name: _get_sensor_logger [3263,3281]
name: _get_sensor_logger [3263,3281]
===
match
---
name: set_context [5117,5128]
name: set_context [5117,5128]
===
match
---
name: state [6441,6446]
name: state [6441,6446]
===
match
---
name: email_alert [19507,19518]
name: email_alert [19466,19477]
===
match
---
trailer [2943,2951]
trailer [2943,2951]
===
match
---
operator: , [11621,11622]
operator: , [11621,11622]
===
match
---
name: TI [14436,14438]
name: TI [14378,14380]
===
match
---
trailer [27131,27133]
trailer [27044,27046]
===
match
---
funcdef [14545,15017]
funcdef [14487,14959]
===
match
---
arglist [18645,18661]
arglist [18578,18620]
===
match
---
operator: = [6716,6717]
operator: = [6716,6717]
===
match
---
name: exception [22464,22473]
name: exception [22377,22386]
===
match
---
trailer [15058,15125]
trailer [15000,15067]
===
match
---
name: sensor_work [21475,21486]
name: sensor_work [21388,21399]
===
match
---
name: SensorInstance [12842,12856]
name: SensorInstance [12842,12856]
===
match
---
trailer [23249,23269]
trailer [23162,23182]
===
match
---
name: task_id [3812,3819]
name: task_id [3812,3819]
===
match
---
arglist [19519,19528]
arglist [19478,19487]
===
match
---
atom_expr [28955,29036]
atom_expr [28868,28949]
===
match
---
operator: = [11473,11474]
operator: = [11473,11474]
===
match
---
operator: = [7009,7010]
operator: = [7009,7010]
===
match
---
string: """         Check if a sensor task in smart sensor is timeout. Could be either sensor operator timeout         or general operator execution_timeout.          :param sensor_work: SensorWork         """ [21250,21451]
string: """         Check if a sensor task in smart sensor is timeout. Could be either sensor operator timeout         or general operator execution_timeout.          :param sensor_work: SensorWork         """ [21163,21364]
===
match
---
simple_stmt [13141,13221]
simple_stmt [13141,13221]
===
match
---
decorator [14138,14155]
decorator [14080,14097]
===
match
---
name: exception [22287,22296]
name: exception [22200,22209]
===
match
---
operator: , [16754,16755]
operator: , [16696,16697]
===
match
---
name: e [3395,3396]
name: e [3395,3396]
===
match
---
suite [10255,30518]
suite [10255,30377]
===
match
---
funcdef [6408,6551]
funcdef [6408,6551]
===
match
---
trailer [7186,7195]
trailer [7186,7195]
===
match
---
atom_expr [3482,3495]
atom_expr [3482,3495]
===
match
---
expr_stmt [1639,1681]
expr_stmt [1639,1681]
===
match
---
name: si [4826,4828]
name: si [4826,4828]
===
match
---
atom_expr [22448,22583]
atom_expr [22361,22496]
===
match
---
or_test [12238,12312]
or_test [12238,12312]
===
match
---
suite [30504,30518]
suite [30363,30377]
===
match
---
trailer [23932,23945]
trailer [23845,23858]
===
match
---
suite [8021,8900]
suite [8021,8900]
===
match
---
name: sensor_work [22448,22459]
name: sensor_work [22361,22372]
===
match
---
param [11525,11537]
param [11525,11537]
===
match
---
name: self [3247,3251]
name: self [3247,3251]
===
match
---
operator: = [24407,24408]
operator: = [24320,24321]
===
match
---
string: """         Mark state for multiple tasks in the task_instance table to a new state if they have         the same signature as the poke_hash.          :param operator: The sensor's operator class name.         :param poke_hash: The hash code generated from sensor's poke context.         :param encoded_poke_context: The raw encoded poke_context.         :param state: Set multiple sensor tasks to this state.         :param session: The sqlalchemy session.         """ [15335,15804]
string: """         Mark state for multiple tasks in the task_instance table to a new state if they have         the same signature as the poke_hash.          :param operator: The sensor's operator class name.         :param poke_hash: The hash code generated from sensor's poke context.         :param encoded_poke_context: The raw encoded poke_context.         :param state: Set multiple sensor tasks to this state.         :param session: The sqlalchemy session.         """ [15277,15746]
===
match
---
name: execution_date [2965,2979]
name: execution_date [2965,2979]
===
match
---
trailer [15106,15124]
trailer [15048,15066]
===
match
---
trailer [9710,9726]
trailer [9710,9726]
===
match
---
atom_expr [30411,30457]
atom_expr [30270,30316]
===
match
---
trailer [26111,26121]
trailer [26024,26034]
===
match
---
argument [26509,26542]
argument [26422,26455]
===
match
---
name: operator [16600,16608]
name: operator [16542,16550]
===
match
---
name: poke_timeout [12175,12187]
name: poke_timeout [12175,12187]
===
match
---
name: airflow [1253,1260]
name: airflow [1253,1260]
===
match
---
simple_stmt [19507,19530]
simple_stmt [19466,19489]
===
match
---
trailer [20129,20210]
trailer [20088,20169]
===
match
---
simple_stmt [2894,2918]
simple_stmt [2894,2918]
===
match
---
trailer [20785,20787]
trailer [20744,20746]
===
match
---
atom_expr [13072,13086]
atom_expr [13072,13086]
===
match
---
param [18217,18227]
param [18226,18236]
===
match
---
name: utcnow [16727,16733]
name: utcnow [16669,16675]
===
match
---
parameters [23975,23994]
parameters [23888,23907]
===
match
---
name: _validate_input_values [12197,12219]
name: _validate_input_values [12197,12219]
===
match
---
operator: = [11584,11585]
operator: = [11584,11585]
===
match
---
arglist [16293,16430]
arglist [16235,16372]
===
match
---
simple_stmt [11344,11365]
simple_stmt [11344,11365]
===
match
---
name: poke_context [27506,27518]
name: poke_context [27419,27431]
===
match
---
operator: = [1752,1753]
operator: = [1752,1753]
===
match
---
name: utils [1609,1614]
name: utils [1609,1614]
===
match
---
string: "Task %s failed by infra failure in smart sensor." [22495,22545]
string: "Task %s failed by infra failure in smart sensor." [22408,22458]
===
match
---
name: task_id [2931,2938]
name: task_id [2931,2938]
===
match
---
name: cached_work [24679,24690]
name: cached_work [24592,24603]
===
match
---
simple_stmt [20472,20509]
simple_stmt [20431,20468]
===
match
---
param [23976,23981]
param [23889,23894]
===
match
---
name: TaskInstance [1111,1123]
name: TaskInstance [1111,1123]
===
match
---
simple_stmt [16707,16736]
simple_stmt [16649,16678]
===
match
---
operator: == [5007,5009]
operator: == [5007,5009]
===
match
---
name: self [26657,26661]
name: self [26570,26574]
===
match
---
atom [14473,14512]
atom [14415,14454]
===
match
---
name: PokeState [23867,23876]
name: PokeState [23780,23789]
===
match
---
trailer [9584,9607]
trailer [9584,9607]
===
match
---
name: si [3590,3592]
name: si [3590,3592]
===
match
---
name: tis [14898,14901]
name: tis [14840,14843]
===
match
---
name: exception_info [9631,9645]
name: exception_info [9631,9645]
===
match
---
operator: = [30578,30579]
operator: = [30437,30438]
===
match
---
name: cached_work [27717,27728]
name: cached_work [27630,27641]
===
match
---
atom_expr [28785,28855]
atom_expr [28698,28768]
===
match
---
name: handle_failure [18676,18690]
name: handle_failure [18635,18649]
===
match
---
operator: , [7995,7996]
operator: , [7995,7996]
===
match
---
trailer [16972,16980]
trailer [16914,16922]
===
match
---
funcdef [9627,9727]
funcdef [9627,9727]
===
match
---
operator: , [25061,25062]
operator: , [24974,24975]
===
match
---
simple_stmt [28785,28856]
simple_stmt [28698,28769]
===
match
---
suite [13747,13891]
suite [13742,13833]
===
match
---
trailer [12257,12271]
trailer [12257,12271]
===
match
---
name: State [20336,20341]
name: State [20295,20300]
===
match
---
comparison [24256,24296]
comparison [24169,24209]
===
match
---
atom_expr [5581,5596]
atom_expr [5581,5596]
===
match
---
atom_expr [19507,19529]
atom_expr [19466,19488]
===
match
---
trailer [26774,26793]
trailer [26687,26706]
===
match
---
parameters [9766,9772]
parameters [9766,9772]
===
match
---
name: error [19523,19528]
name: error [19482,19487]
===
match
---
name: formatter_config [1865,1881]
name: formatter_config [1865,1881]
===
match
---
not_test [9169,9195]
not_test [9169,9195]
===
match
---
atom_expr [13830,13836]
atom_expr [13825,13831]
===
match
---
trailer [23582,23628]
trailer [23495,23541]
===
match
---
name: update_ti_hostname_with_count [14549,14578]
name: update_ti_hostname_with_count [14491,14520]
===
match
---
name: state [1566,1571]
name: state [1566,1571]
===
match
---
atom_expr [3361,3369]
atom_expr [3361,3369]
===
match
---
atom_expr [3761,3773]
atom_expr [3761,3773]
===
insert-node
---
name: SmartSensorOperator [10210,10229]
to
classdef [10204,30518]
at 0
===
insert-tree
---
arglist [10230,10253]
    name: BaseOperator [10230,10242]
    operator: , [10242,10243]
    name: SkipMixin [10244,10253]
to
classdef [10204,30518]
at 1
===
insert-tree
---
simple_stmt [10260,11339]
    string: """     Smart sensor operators are derived from this class.      Smart Sensor operators keep refresh a dictionary by visiting DB.     Taking qualified active sensor tasks. Different from sensor operator,     Smart sensor operators poke for all sensor tasks in the dictionary at     a time interval. When a criteria is met or fail by time out, it update     all sensor task state in task_instance table      :param soft_fail: Set to true to mark the task as SKIPPED on failure     :type soft_fail: bool     :param poke_interval: Time in seconds that the job should wait in         between each tries.     :type poke_interval: int     :param smart_sensor_timeout: Time, in seconds before the internal sensor         job times out if poke_timeout is not defined.     :type smart_sensor_timeout: float     :param shard_min: shard code lower bound (inclusive)     :type shard_min: int     :param shard_max: shard code upper bound (exclusive)     :type shard_max: int     :param poke_timeout: Time, in seconds before the task times out and fails.     :type poke_timeout: float     """ [10260,11338]
to
suite [10255,30518]
at 0
===
insert-node
---
simple_stmt [17257,17474]
to
suite [17307,17465]
at 0
===
insert-node
---
atom_expr [17257,17473]
to
simple_stmt [17257,17474]
at 0
===
move-tree
---
name: self [17320,17324]
to
atom_expr [17257,17473]
at 0
===
move-tree
---
trailer [17324,17328]
    name: log [17325,17328]
to
atom_expr [17257,17473]
at 1
===
move-tree
---
trailer [17328,17336]
    name: warning [17329,17336]
to
atom_expr [17257,17473]
at 2
===
insert-node
---
trailer [17273,17473]
to
atom_expr [17257,17473]
at 3
===
insert-node
---
arglist [17291,17459]
to
trailer [17273,17473]
at 0
===
move-tree
---
string: "Exception _mark_multi_state in smart sensor for hashcode %s" [17337,17398]
to
arglist [17291,17459]
at 0
===
move-tree
---
operator: , [17398,17399]
to
arglist [17291,17459]
at 1
===
move-tree
---
atom_expr [17400,17414]
    name: str [17400,17403]
    trailer [17403,17414]
        name: poke_hash [17404,17413]
to
arglist [17291,17459]
at 2
===
move-tree
---
operator: , [17448,17449]
to
arglist [17291,17459]
at 3
===
move-tree
---
argument [17450,17463]
    name: exc_info [17450,17458]
    operator: = [17458,17459]
to
arglist [17291,17459]
at 4
===
move-tree
---
operator: , [21167,21168]
to
arglist [21081,21126]
at 3
===
move-tree
---
argument [21169,21182]
    name: exc_info [21169,21177]
    operator: = [21177,21178]
to
arglist [21081,21126]
at 4
===
update-node
---
name: exception [18635,18644]
replace exception by warning
===
insert-node
---
string: "Exception alerting email." [18578,18605]
to
arglist [18645,18661]
at 0
===
delete-node
---
name: SmartSensorOperator [10210,10229]
===
===
delete-tree
---
arglist [10230,10253]
    name: BaseOperator [10230,10242]
    operator: , [10242,10243]
    name: SkipMixin [10244,10253]
===
delete-tree
---
simple_stmt [10260,11339]
    string: """     Smart sensor operators are derived from this class.      Smart Sensor operators keep refresh a dictionary by visiting DB.     Taking qualified active sensor tasks. Different from sensor operator,     Smart sensor operators poke for all sensor tasks in the dictionary at     a time interval. When a criteria is met or fail by time out, it update     all sensor task state in task_instance table      :param soft_fail: Set to true to mark the task as SKIPPED on failure     :type soft_fail: bool     :param poke_interval: Time in seconds that the job should wait in         between each tries.     :type poke_interval: int     :param smart_sensor_timeout: Time, in seconds before the internal sensor         job times out if poke_timeout is not defined.     :type smart_sensor_timeout: float     :param shard_min: shard code lower bound (inclusive)     :type shard_min: int     :param shard_max: shard code upper bound (exclusive)     :type shard_max: int     :param poke_timeout: Time, in seconds before the task times out and fails.     :type poke_timeout: float     """ [10260,11338]
===
delete-node
---
name: e [13713,13714]
===
===
delete-tree
---
simple_stmt [13854,13891]
    atom_expr [13854,13890]
        name: self [13854,13858]
        trailer [13858,13862]
            name: log [13859,13862]
        trailer [13862,13872]
            name: exception [13863,13872]
        trailer [13872,13890]
            arglist [13873,13889]
                name: e [13873,13874]
                operator: , [13874,13875]
                argument [13876,13889]
                    name: exc_info [13876,13884]
                    operator: = [13884,13885]
===
delete-node
---
name: e [17273,17274]
===
===
delete-node
---
arglist [17337,17414]
===
===
delete-node
---
trailer [17336,17415]
===
===
delete-node
---
atom_expr [17320,17415]
===
===
delete-node
---
simple_stmt [17320,17416]
===
===
delete-node
---
arglist [17447,17463]
===
===
delete-node
---
trailer [17446,17464]
===
===
delete-node
---
atom_expr [17428,17464]
===
===
delete-node
---
simple_stmt [17428,17465]
===
===
delete-node
---
name: e [18499,18500]
===
===
delete-tree
---
simple_stmt [18550,18603]
    atom_expr [18550,18602]
        name: sensor_work [18550,18561]
        trailer [18561,18565]
            name: log [18562,18565]
        trailer [18565,18573]
            name: warning [18566,18573]
        trailer [18573,18602]
            string: "Exception alerting email." [18574,18601]
===
delete-node
---
name: e [18645,18646]
===
===
delete-node
---
name: e [21042,21043]
===
===
delete-node
---
arglist [21166,21182]
===
===
delete-node
---
trailer [21165,21183]
===
===
delete-node
---
atom_expr [21140,21183]
===
===
delete-node
---
simple_stmt [21140,21184]
===
===
delete-node
---
name: e [29150,29151]
===
===
delete-tree
---
simple_stmt [29266,29303]
    atom_expr [29266,29302]
        name: self [29266,29270]
        trailer [29270,29274]
            name: log [29271,29274]
        trailer [29274,29284]
            name: exception [29275,29284]
        trailer [29284,29302]
            arglist [29285,29301]
                name: e [29285,29286]
                operator: , [29286,29287]
                argument [29288,29301]
                    name: exc_info [29288,29296]
                    operator: = [29296,29297]
