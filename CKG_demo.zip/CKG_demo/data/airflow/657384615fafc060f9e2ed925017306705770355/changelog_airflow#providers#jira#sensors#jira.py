===
match
---
operator: } [4056,4057]
operator: } [4056,4057]
===
match
---
arglist [5485,5552]
arglist [5484,5551]
===
match
---
name: result_processor [2350,2366]
name: result_processor [2350,2366]
===
match
---
name: JiraSensor [1067,1077]
name: JiraSensor [1067,1077]
===
match
---
operator: , [1703,1704]
operator: , [1703,1704]
===
match
---
name: str [3294,3297]
name: str [3294,3297]
===
match
---
suite [3440,3787]
suite [3440,3787]
===
match
---
trailer [4172,4178]
trailer [4172,4178]
===
match
---
trailer [4480,4487]
trailer [4480,4487]
===
match
---
decorated [1576,2400]
decorated [1576,2400]
===
match
---
name: method_name [2276,2287]
name: method_name [2276,2287]
===
match
---
expr_stmt [4455,4500]
expr_stmt [4455,4500]
===
match
---
string: """Check issue using different conditions to prepare to evaluate sensor.""" [4188,4263]
string: """Check issue using different conditions to prepare to evaluate sensor.""" [4188,4263]
===
match
---
trailer [3944,3956]
trailer [3944,3956]
===
match
---
operator: , [5531,5532]
operator: , [5530,5531]
===
match
---
name: self [5729,5733]
name: self [5694,5698]
===
match
---
name: Exception [5410,5419]
name: Exception [5410,5419]
===
match
---
atom_expr [2052,2068]
atom_expr [2052,2068]
===
match
---
name: self [2271,2275]
name: self [2271,2275]
===
match
---
name: field_val [4778,4787]
name: field_val [4778,4787]
===
match
---
name: expected_value [4923,4937]
name: expected_value [4923,4937]
===
match
---
name: self [4020,4024]
name: self [4020,4024]
===
match
---
param [1812,1821]
param [1812,1821]
===
match
---
expr_stmt [2091,2125]
expr_stmt [2091,2125]
===
match
---
name: sensors [968,975]
name: sensors [968,975]
===
match
---
trailer [4793,4795]
trailer [4793,4795]
===
match
---
operator: * [3182,3183]
operator: * [3182,3183]
===
match
---
tfpdef [1669,1686]
tfpdef [1669,1686]
===
match
---
atom_expr [3901,3915]
atom_expr [3901,3915]
===
match
---
operator: = [3400,3401]
operator: = [3400,3401]
===
match
---
operator: , [3738,3739]
operator: , [3738,3739]
===
match
---
name: field [4051,4056]
name: field [4051,4056]
===
match
---
param [3801,3806]
param [3801,3806]
===
match
---
operator: = [3299,3300]
operator: = [3299,3300]
===
match
---
trailer [2322,2336]
trailer [2322,2336]
===
match
---
operator: = [3506,3507]
operator: = [3506,3507]
===
match
---
name: list [4588,4592]
name: list [4588,4592]
===
match
---
name: jira [919,923]
name: jira [919,923]
===
match
---
comparison [4918,4971]
comparison [4918,4971]
===
match
---
trailer [2056,2068]
trailer [2056,2068]
===
match
---
name: result [5599,5605]
name: result [5564,5570]
===
match
---
name: ticket_id [4025,4034]
name: ticket_id [4025,4034]
===
match
---
trailer [4772,4774]
trailer [4772,4774]
===
match
---
operator: , [1802,1803]
operator: , [1802,1803]
===
match
---
suite [1836,2400]
suite [1836,2400]
===
match
---
expr_stmt [3491,3517]
expr_stmt [3491,3517]
===
match
---
name: lower [4788,4793]
name: lower [4788,4793]
===
match
---
name: poke [4084,4088]
name: poke [4084,4088]
===
match
---
trailer [2095,2109]
trailer [2095,2109]
===
match
---
operator: , [5234,5235]
operator: , [5234,5235]
===
match
---
expr_stmt [3088,3120]
expr_stmt [3088,3120]
===
match
---
simple_stmt [2052,2083]
simple_stmt [2052,2083]
===
match
---
name: Resource [871,879]
name: Resource [871,879]
===
match
---
name: info [5798,5802]
name: info [5763,5767]
===
match
---
name: self [4747,4751]
name: self [4747,4751]
===
match
---
comparison [4628,4660]
comparison [4628,4660]
===
match
---
name: log [5475,5478]
name: log [5470,5473]
===
match
---
parameters [4140,4160]
parameters [4140,4160]
===
match
---
atom_expr [3285,3298]
atom_expr [3285,3298]
===
match
---
param [4141,4146]
param [4141,4146]
===
match
---
parameters [3158,3431]
parameters [3158,3431]
===
match
---
operator: ** [3777,3779]
operator: ** [3777,3779]
===
match
---
suite [4179,5910]
suite [4179,5875]
===
match
---
name: apply_defaults [1577,1591]
name: apply_defaults [1577,1591]
===
match
---
name: expected_value [3575,3589]
name: expected_value [3575,3589]
===
match
---
expr_stmt [2134,2399]
expr_stmt [2134,2399]
===
match
---
trailer [3557,3572]
trailer [3557,3572]
===
match
---
name: dict [1737,1741]
name: dict [1737,1741]
===
match
---
name: __init__ [3150,3158]
name: __init__ [3150,3158]
===
match
---
trailer [1925,1942]
trailer [1925,1942]
===
match
---
operator: , [3118,3119]
operator: , [3118,3119]
===
match
---
name: JiraSensor [4073,4083]
name: JiraSensor [4073,4083]
===
match
---
suite [4594,4661]
suite [4594,4661]
===
match
---
operator: = [2317,2318]
operator: = [2317,2318]
===
match
---
name: self [4405,4409]
name: self [4405,4409]
===
match
---
operator: , [4145,4146]
operator: , [4145,4146]
===
match
---
operator: , [2245,2246]
operator: , [2245,2246]
===
match
---
operator: == [4775,4777]
operator: == [4775,4777]
===
match
---
operator: * [1632,1633]
operator: * [1632,1633]
===
match
---
name: jira_conn_id [3713,3725]
name: jira_conn_id [3713,3725]
===
match
---
operator: , [4034,4035]
operator: , [4034,4035]
===
match
---
import_from [1007,1058]
import_from [1007,1058]
===
match
---
trailer [5319,5323]
trailer [5319,5323]
===
match
---
comparison [4405,4436]
comparison [4405,4436]
===
match
---
simple_stmt [2091,2126]
simple_stmt [2091,2126]
===
match
---
suite [5776,5888]
suite [5741,5853]
===
match
---
name: jira_conn_id [3470,3482]
name: jira_conn_id [3470,3482]
===
match
---
atom_expr [4918,4945]
atom_expr [4918,4945]
===
match
---
operator: , [5381,5382]
operator: , [5381,5382]
===
match
---
name: context [2485,2492]
name: context [2485,2492]
===
match
---
simple_stmt [5789,5888]
simple_stmt [5754,5853]
===
match
---
atom_expr [4073,4111]
atom_expr [4073,4111]
===
match
---
name: issue_field_checker [4121,4140]
name: issue_field_checker [4121,4140]
===
match
---
trailer [5474,5478]
trailer [5469,5473]
===
match
---
argument [3740,3775]
argument [3740,3775]
===
match
---
string: """     Monitors a jira ticket for given change in terms of function.      :param jira_conn_id: reference to a pre-defined Jira Connection     :type jira_conn_id: str     :param ticket_id: id of the ticket to be monitored     :type ticket_id: str     :param field: field of the ticket to be monitored     :type field: str     :param expected_value: expected value of the field     :type expected_value: str     :param result_processor: function that return boolean and act as a sensor response     :type result_processor: function     """ [2544,3082]
string: """     Monitors a jira ticket for given change in terms of function.      :param jira_conn_id: reference to a pre-defined Jira Connection     :type jira_conn_id: str     :param ticket_id: id of the ticket to be monitored     :type ticket_id: str     :param field: field of the ticket to be monitored     :type field: str     :param expected_value: expected value of the field     :type expected_value: str     :param result_processor: function that return boolean and act as a sensor response     :type result_processor: function     """ [2544,3082]
===
match
---
trailer [2007,2024]
trailer [2007,2024]
===
match
---
simple_stmt [3450,3483]
simple_stmt [3450,3483]
===
match
---
import_from [787,835]
import_from [787,835]
===
match
---
name: field [5722,5727]
name: field [5687,5692]
===
match
---
trailer [4766,4772]
trailer [4766,4772]
===
match
---
string: "is neither string nor list nor Jira Resource" [5148,5194]
string: "is neither string nor list nor Jira Resource" [5148,5194]
===
match
---
operator: = [3262,3263]
operator: = [3262,3263]
===
match
---
name: fields [4481,4487]
name: fields [4481,4487]
===
match
---
simple_stmt [3088,3121]
simple_stmt [3088,3121]
===
match
---
name: field [4494,4499]
name: field [4494,4499]
===
match
---
suite [3628,3687]
suite [3628,3687]
===
match
---
operator: , [4093,4094]
operator: , [4093,4094]
===
match
---
atom_expr [5855,5865]
atom_expr [5820,5830]
===
match
---
operator: = [4279,4280]
operator: = [4279,4280]
===
match
---
string: "ticket_id" [3107,3118]
string: "ticket_id" [3107,3118]
===
match
---
name: self [3901,3905]
name: self [3901,3905]
===
match
---
trailer [5228,5234]
trailer [5228,5234]
===
match
---
trailer [4632,4647]
trailer [4632,4647]
===
match
---
operator: = [2227,2228]
operator: = [2227,2228]
===
match
---
simple_stmt [1880,1913]
simple_stmt [1880,1913]
===
match
---
operator: , [3172,3173]
operator: , [3172,3173]
===
match
---
operator: , [3183,3184]
operator: , [3183,3184]
===
match
---
atom_expr [4164,4178]
atom_expr [4164,4178]
===
match
---
name: str [1683,1686]
name: str [1683,1686]
===
match
---
tfpdef [3315,3344]
tfpdef [3315,3344]
===
match
---
trailer [2167,2399]
trailer [2167,2399]
===
match
---
arglist [5658,5748]
arglist [5623,5713]
===
match
---
name: jira_conn_id [3193,3205]
name: jira_conn_id [3193,3205]
===
match
---
name: Optional [3248,3256]
name: Optional [3248,3256]
===
match
---
atom_expr [5867,5886]
atom_expr [5832,5851]
===
match
---
trailer [4937,4943]
trailer [4937,4943]
===
match
---
name: issue [4356,4361]
name: issue [4356,4361]
===
match
---
name: field [3539,3544]
name: field [3539,3544]
===
match
---
return_stmt [4066,4111]
return_stmt [4066,4111]
===
match
---
param [2420,2433]
param [2420,2433]
===
match
---
import_from [955,1006]
import_from [955,1006]
===
match
---
operator: , [3775,3776]
operator: , [3775,3776]
===
match
---
name: jira_operator [3980,3993]
name: jira_operator [3980,3993]
===
match
---
operator: = [3660,3661]
operator: = [3660,3661]
===
match
---
operator: @ [1576,1577]
operator: @ [1576,1577]
===
match
---
operator: = [4916,4917]
operator: = [4916,4917]
===
match
---
param [1618,1623]
param [1618,1623]
===
match
---
suite [1098,2502]
suite [1098,2502]
===
match
---
operator: = [1743,1744]
operator: = [1743,1744]
===
match
---
atom_expr [2003,2024]
atom_expr [2003,2024]
===
match
---
name: method_name [2057,2068]
name: method_name [2057,2068]
===
match
---
trailer [4943,4945]
trailer [4943,4945]
===
match
---
tfpdef [3193,3210]
tfpdef [3193,3210]
===
match
---
operator: == [4946,4948]
operator: == [4946,4948]
===
match
---
atom_expr [5627,5762]
atom_expr [5592,5727]
===
match
---
trailer [2476,2484]
trailer [2476,2484]
===
match
---
atom_expr [5315,5394]
atom_expr [5315,5394]
===
match
---
trailer [5640,5762]
trailer [5605,5727]
===
match
---
simple_stmt [2003,2044]
simple_stmt [2003,2044]
===
match
---
name: JIRAError [931,940]
name: JIRAError [931,940]
===
match
---
simple_stmt [4188,4264]
simple_stmt [4188,4264]
===
match
---
atom_expr [2367,2388]
atom_expr [2367,2388]
===
match
---
name: method_name [2071,2082]
name: method_name [2071,2082]
===
match
---
name: expected_value [5872,5886]
name: expected_value [5837,5851]
===
match
---
suite [2442,2502]
suite [2442,2502]
===
match
---
tfpdef [3361,3399]
tfpdef [3361,3399]
===
match
---
name: expected_value [5538,5552]
name: expected_value [5537,5551]
===
match
---
name: field_val [4832,4841]
name: field_val [4832,4841]
===
match
---
name: result_processor [1759,1775]
name: result_processor [1759,1775]
===
match
---
trailer [1850,1852]
trailer [1850,1852]
===
match
---
trailer [1785,1795]
trailer [1785,1795]
===
match
---
name: utils [1020,1025]
name: utils [1020,1025]
===
match
---
name: str [3340,3343]
name: str [3340,3343]
===
match
---
string: 'name' [4876,4882]
string: 'name' [4876,4882]
===
match
---
atom_expr [4949,4971]
atom_expr [4949,4971]
===
match
---
atom_expr [4020,4034]
atom_expr [4020,4034]
===
match
---
operator: = [4745,4746]
operator: = [4745,4746]
===
match
---
name: result_processor [1926,1942]
name: result_processor [1926,1942]
===
match
---
string: "Error while checking with expected value %s:" [5485,5531]
string: "Error while checking with expected value %s:" [5484,5530]
===
match
---
name: __init__ [1600,1608]
name: __init__ [1600,1608]
===
match
---
if_stmt [4563,5262]
if_stmt [4563,5262]
===
match
---
operator: , [4841,4842]
operator: , [4841,4842]
===
match
---
operator: ** [3416,3418]
operator: ** [3416,3418]
===
match
---
name: __init__ [3704,3712]
name: __init__ [3704,3712]
===
match
---
name: jira_conn_id [3726,3738]
name: jira_conn_id [3726,3738]
===
match
---
trailer [4382,4388]
trailer [4382,4388]
===
match
---
operator: -> [1828,1830]
operator: -> [1828,1830]
===
match
---
name: expected_value [4633,4647]
name: expected_value [4633,4647]
===
match
---
if_stmt [3598,3687]
if_stmt [3598,3687]
===
match
---
name: result_processor [2372,2388]
name: result_processor [2372,2388]
===
match
---
trailer [3851,3916]
trailer [3851,3916]
===
match
---
classdef [1061,2502]
classdef [1061,2502]
===
match
---
name: self [2367,2371]
name: self [2367,2371]
===
match
---
operator: = [2025,2026]
operator: = [2025,2026]
===
match
---
arglist [4697,4711]
arglist [4697,4711]
===
match
---
name: JiraTicketSensor [2510,2526]
name: JiraTicketSensor [2510,2526]
===
match
---
name: Optional [3285,3293]
name: Optional [3285,3293]
===
match
---
simple_stmt [5896,5910]
simple_stmt [5861,5875]
===
match
---
name: result [5903,5909]
name: result [5868,5874]
===
match
---
comp_op [1978,1984]
comp_op [1978,1984]
===
match
---
string: 'fields' [4036,4044]
string: 'fields' [4036,4044]
===
match
---
name: JiraSensor [2527,2537]
name: JiraSensor [2527,2537]
===
match
---
param [4147,4159]
param [4147,4159]
===
match
---
trailer [4969,4971]
trailer [4969,4971]
===
match
---
tfpdef [4147,4159]
tfpdef [4147,4159]
===
match
---
arglist [3852,3915]
arglist [3852,3915]
===
match
---
name: jira_operator [2463,2476]
name: jira_operator [2463,2476]
===
match
---
name: self [5533,5537]
name: self [5532,5536]
===
match
---
operator: , [869,870]
operator: , [869,870]
===
match
---
name: result [4738,4744]
name: result [4738,4744]
===
match
---
name: field [5229,5234]
name: field [5229,5234]
===
match
---
name: decorators [1026,1036]
name: decorators [1026,1036]
===
match
---
name: self [2091,2095]
name: self [2091,2095]
===
match
---
argument [3777,3785]
argument [3777,3785]
===
match
---
suite [4437,5262]
suite [4437,5262]
===
match
---
trailer [1861,1871]
trailer [1861,1871]
===
match
---
atom_expr [5729,5748]
atom_expr [5694,5713]
===
match
---
simple_stmt [3491,3518]
simple_stmt [3491,3518]
===
match
---
simple_stmt [2544,3083]
simple_stmt [2544,3083]
===
match
---
operator: -> [2435,2437]
operator: -> [2435,2437]
===
match
---
operator: = [1898,1899]
operator: = [1898,1899]
===
match
---
name: log [5632,5635]
name: log [5597,5600]
===
match
---
and_test [4356,4436]
and_test [4356,4436]
===
match
---
tfpdef [1713,1742]
tfpdef [1713,1742]
===
match
---
import_from [837,879]
import_from [837,879]
===
match
---
trailer [3930,3944]
trailer [3930,3944]
===
match
---
simple_stmt [4066,4112]
simple_stmt [4066,4112]
===
match
---
return_stmt [2451,2501]
return_stmt [2451,2501]
===
match
---
operator: = [2492,2493]
operator: = [2492,2493]
===
match
---
atom_expr [2458,2501]
atom_expr [2458,2501]
===
match
---
name: Resource [4843,4851]
name: Resource [4843,4851]
===
match
---
trailer [5871,5886]
trailer [5836,5851]
===
match
---
argument [1862,1870]
argument [1862,1870]
===
match
---
simple_stmt [5627,5763]
simple_stmt [5592,5728]
===
match
---
operator: , [3305,3306]
operator: , [3305,3306]
===
match
---
trailer [4576,4593]
trailer [4576,4593]
===
match
---
param [1643,1660]
param [1643,1660]
===
match
---
name: Issue [864,869]
name: Issue [864,869]
===
match
---
operator: , [2201,2202]
operator: , [2201,2202]
===
match
---
operator: -> [3822,3824]
operator: -> [3822,3824]
===
match
---
operator: = [2188,2189]
operator: = [2188,2189]
===
match
---
import_as_names [806,835]
import_as_names [806,835]
===
match
---
return_stmt [5896,5909]
return_stmt [5861,5874]
===
match
---
name: result [4619,4625]
name: result [4619,4625]
===
match
---
argument [2485,2500]
argument [2485,2500]
===
match
---
name: ticket_id [3237,3246]
name: ticket_id [3237,3246]
===
match
---
decorator [1576,1592]
decorator [1576,1592]
===
match
---
name: self [5855,5859]
name: self [5820,5824]
===
match
---
arglist [2181,2389]
arglist [2181,2389]
===
match
---
operator: = [3211,3212]
operator: = [3211,3212]
===
match
---
operator: , [4874,4875]
operator: , [4874,4875]
===
match
---
name: log [3843,3846]
name: log [3843,3846]
===
match
---
name: issue [4475,4480]
name: issue [4475,4480]
===
match
---
name: template_fields [3088,3103]
name: template_fields [3088,3103]
===
match
---
operator: = [4011,4012]
operator: = [4011,4012]
===
match
---
name: self [1880,1884]
name: self [1880,1884]
===
match
---
suite [4713,4796]
suite [4713,4796]
===
match
---
name: jira_conn_id [1885,1897]
name: jira_conn_id [1885,1897]
===
match
---
name: str [3207,3210]
name: str [3207,3210]
===
match
---
trailer [5802,5887]
trailer [5767,5852]
===
match
---
trailer [4474,4500]
trailer [4474,4500]
===
match
---
name: str [1656,1659]
name: str [1656,1659]
===
match
---
trailer [3389,3399]
trailer [3389,3399]
===
match
---
name: JiraOperator [2155,2167]
name: JiraOperator [2155,2167]
===
match
---
suite [5302,5395]
suite [5302,5395]
===
match
---
atom_expr [2271,2287]
atom_expr [2271,2287]
===
match
---
trailer [3666,3686]
trailer [3666,3686]
===
match
---
operator: , [1749,1750]
operator: , [1749,1750]
===
match
---
trailer [2462,2476]
trailer [2462,2476]
===
match
---
operator: , [3268,3269]
operator: , [3268,3269]
===
match
---
tfpdef [1759,1795]
tfpdef [1759,1795]
===
match
---
simple_stmt [4619,4661]
simple_stmt [4619,4661]
===
match
---
name: Optional [1777,1785]
name: Optional [1777,1785]
===
match
---
atom_expr [4857,4883]
atom_expr [4857,4883]
===
match
---
param [3168,3173]
param [3168,3173]
===
match
---
comparison [4378,4400]
comparison [4378,4400]
===
match
---
trailer [3293,3298]
trailer [3293,3298]
===
match
---
expr_stmt [4909,4971]
expr_stmt [4909,4971]
===
match
---
string: "Issue field %s has expected value %s, returning success" [5658,5715]
string: "Issue field %s has expected value %s, returning success" [5623,5680]
===
match
---
arglist [5803,5886]
arglist [5768,5851]
===
match
---
name: airflow [1012,1019]
name: airflow [1012,1019]
===
match
---
name: method_name [3945,3956]
name: method_name [3945,3956]
===
match
---
name: airflow [886,893]
name: airflow [886,893]
===
match
---
name: Optional [3381,3389]
name: Optional [3381,3389]
===
match
---
operator: = [4102,4103]
operator: = [4102,4103]
===
match
---
name: self [5022,5026]
name: self [5022,5026]
===
match
---
trailer [5793,5797]
trailer [5758,5762]
===
match
---
simple_stmt [4738,4796]
simple_stmt [4738,4796]
===
match
---
name: apply_defaults [3127,3141]
name: apply_defaults [3127,3141]
===
match
---
param [3416,3425]
param [3416,3425]
===
match
---
atom_expr [1728,1742]
atom_expr [1728,1742]
===
match
---
operator: = [1796,1797]
operator: = [1796,1797]
===
match
---
name: issue [4147,4152]
name: issue [4147,4152]
===
match
---
tfpdef [3237,3261]
tfpdef [3237,3261]
===
match
---
import_as_names [864,879]
import_as_names [864,879]
===
match
---
name: log [5027,5030]
name: log [5027,5030]
===
match
---
name: self [3801,3805]
name: self [3801,3805]
===
match
---
suite [4340,5262]
suite [4340,5262]
===
match
---
arglist [4089,4110]
arglist [4089,4110]
===
match
---
strings [5068,5194]
strings [5068,5194]
===
match
---
operator: = [2270,2271]
operator: = [2270,2271]
===
match
---
name: Dict [2429,2433]
name: Dict [2429,2433]
===
match
---
expr_stmt [1921,1949]
expr_stmt [1921,1949]
===
match
---
name: isinstance [4821,4831]
name: isinstance [4821,4831]
===
match
---
atom_expr [5789,5887]
atom_expr [5754,5852]
===
match
---
trailer [5733,5748]
trailer [5698,5713]
===
match
---
atom [3106,3120]
atom [3106,3120]
===
match
---
name: Issue [4154,4159]
name: Issue [4154,4159]
===
match
---
operator: , [3227,3228]
operator: , [3227,3228]
===
match
---
param [3237,3269]
param [3237,3269]
===
match
---
name: self [2458,2462]
name: self [2458,2462]
===
match
---
suite [5614,5763]
suite [5579,5728]
===
match
---
name: jira [842,846]
name: jira [842,846]
===
match
---
param [3807,3820]
param [3807,3820]
===
match
---
trailer [5721,5727]
trailer [5686,5692]
===
match
---
name: result [4272,4278]
name: result [4272,4278]
===
match
---
name: jira_method_args [2301,2317]
name: jira_method_args [2301,2317]
===
match
---
arglist [4832,4851]
arglist [4832,4851]
===
match
---
arglist [4865,4882]
arglist [4865,4882]
===
match
---
parameters [2413,2434]
parameters [2413,2434]
===
match
---
simple_stmt [3553,3590]
simple_stmt [3553,3590]
===
match
---
param [3315,3352]
param [3315,3352]
===
match
---
dotted_name [842,856]
dotted_name [842,856]
===
match
---
name: field_checker_func [3641,3659]
name: field_checker_func [3641,3659]
===
match
---
decorator [3126,3142]
decorator [3126,3142]
===
match
---
name: bool [4173,4177]
name: bool [4173,4177]
===
match
---
name: context [2420,2427]
name: context [2420,2427]
===
match
---
trailer [4958,4963]
trailer [4958,4963]
===
match
---
except_clause [5271,5301]
except_clause [5271,5301]
===
match
---
name: jira [904,908]
name: jira [904,908]
===
match
---
name: self [5470,5474]
name: self [5465,5469]
===
match
---
expr_stmt [3553,3589]
expr_stmt [3553,3589]
===
match
---
trailer [4088,4111]
trailer [4088,4111]
===
match
---
simple_stmt [3526,3545]
simple_stmt [3526,3545]
===
match
---
param [1669,1704]
param [1669,1704]
===
match
---
name: self [3662,3666]
name: self [3662,3666]
===
match
---
funcdef [2405,2502]
funcdef [2405,2502]
===
match
---
name: self [2414,2418]
name: self [2414,2418]
===
match
---
atom_expr [1777,1795]
atom_expr [1777,1795]
===
match
---
name: super [3696,3701]
name: super [3696,3701]
===
match
---
simple_stmt [3975,4058]
simple_stmt [3975,4058]
===
match
---
simple_stmt [2451,2502]
simple_stmt [2451,2502]
===
match
---
name: str [4708,4711]
name: str [4708,4711]
===
match
---
name: result_processor [1961,1977]
name: result_processor [1961,1977]
===
match
---
funcdef [3146,3787]
funcdef [3146,3787]
===
match
---
if_stmt [1958,2044]
if_stmt [1958,2044]
===
match
---
name: kwargs [1864,1870]
name: kwargs [1864,1870]
===
match
---
expr_stmt [3926,3966]
expr_stmt [3926,3966]
===
match
---
atom_expr [2228,2245]
atom_expr [2228,2245]
===
match
---
expr_stmt [2003,2043]
expr_stmt [2003,2043]
===
match
---
trailer [2138,2152]
trailer [2138,2152]
===
match
---
operator: , [3899,3900]
operator: , [3899,3900]
===
match
---
trailer [5537,5552]
trailer [5536,5551]
===
match
---
name: getattr [4857,4864]
name: getattr [4857,4864]
===
match
---
arglist [5068,5235]
arglist [5068,5235]
===
match
---
trailer [3842,3846]
trailer [3842,3846]
===
match
---
name: info [5636,5640]
name: info [5601,5605]
===
match
---
comp_op [4389,4395]
comp_op [4389,4395]
===
match
---
param [3193,3228]
param [3193,3228]
===
match
---
name: Callable [3390,3398]
name: Callable [3390,3398]
===
match
---
trailer [3454,3467]
trailer [3454,3467]
===
match
---
operator: , [2418,2419]
operator: , [2418,2419]
===
match
---
file_input [787,5910]
file_input [787,5875]
===
match
---
atom_expr [4747,4774]
atom_expr [4747,4774]
===
match
---
operator: = [1687,1688]
operator: = [1687,1688]
===
match
---
string: "Not implemented checker for issue field %s which " [5068,5119]
string: "Not implemented checker for issue field %s which " [5068,5119]
===
match
---
atom_expr [3381,3399]
atom_expr [3381,3399]
===
match
---
comparison [1961,1989]
comparison [1961,1989]
===
match
---
operator: = [2069,2070]
operator: = [2069,2070]
===
match
---
funcdef [1596,2400]
funcdef [1596,2400]
===
match
---
name: Any [806,809]
name: Any [806,809]
===
match
---
operator: , [4487,4488]
operator: , [4487,4488]
===
match
---
name: jira_conn_id [2233,2245]
name: jira_conn_id [2233,2245]
===
match
---
atom_expr [3331,3344]
atom_expr [3331,3344]
===
match
---
operator: , [5194,5195]
operator: , [5194,5195]
===
match
---
param [3278,3306]
param [3278,3306]
===
match
---
operator: = [2366,2367]
operator: = [2366,2367]
===
match
---
name: str [3257,3260]
name: str [3257,3260]
===
match
---
funcdef [3792,4112]
funcdef [3792,4112]
===
match
---
name: __init__ [1853,1861]
name: __init__ [1853,1861]
===
match
---
trailer [5030,5038]
trailer [5030,5038]
===
match
---
operator: , [809,810]
operator: , [809,810]
===
match
---
arglist [5330,5393]
arglist [5330,5393]
===
match
---
comparison [4356,4373]
comparison [4356,4373]
===
match
---
name: ticket_id [3496,3505]
name: ticket_id [3496,3505]
===
match
---
operator: = [3725,3726]
operator: = [3725,3726]
===
match
---
atom_expr [4378,4388]
atom_expr [4378,4388]
===
match
---
if_stmt [4353,5262]
if_stmt [4353,5262]
===
match
---
trailer [5631,5635]
trailer [5596,5600]
===
match
---
trailer [4493,4499]
trailer [4493,4499]
===
match
---
name: Dict [821,825]
name: Dict [821,825]
===
match
---
trailer [5859,5865]
trailer [5824,5830]
===
match
---
trailer [3712,3786]
trailer [3712,3786]
===
match
---
operator: , [3805,3806]
operator: , [3805,3806]
===
match
---
decorated [3126,3787]
decorated [3126,3787]
===
match
---
arglist [3713,3785]
arglist [3713,3785]
===
match
---
expr_stmt [3641,3686]
expr_stmt [3641,3686]
===
match
---
name: Optional [4164,4172]
name: Optional [4164,4172]
===
match
---
simple_stmt [3838,3917]
simple_stmt [3838,3917]
===
match
---
atom_expr [2318,2336]
atom_expr [2318,2336]
===
match
---
name: expected_value [4752,4766]
name: expected_value [4752,4766]
===
match
---
name: warning [5031,5038]
name: warning [5031,5038]
===
match
---
atom_expr [4475,4487]
atom_expr [4475,4487]
===
match
---
name: self [1921,1925]
name: self [1921,1925]
===
match
---
operator: , [3424,3425]
operator: , [3424,3425]
===
match
---
operator: , [3406,3407]
operator: , [3406,3407]
===
match
---
name: self [3553,3557]
name: self [3553,3557]
===
match
---
name: isinstance [4686,4696]
name: isinstance [4686,4696]
===
match
---
name: field_val [4697,4706]
name: field_val [4697,4706]
===
match
---
operator: , [5865,5866]
operator: , [5830,5831]
===
match
---
argument [3713,3738]
argument [3713,3738]
===
match
---
simple_stmt [1007,1059]
simple_stmt [1007,1059]
===
match
---
name: field [3278,3283]
name: field [3278,3283]
===
match
---
string: 'id' [4014,4018]
string: 'id' [4014,4018]
===
match
---
name: jira_error [5383,5393]
name: jira_error [5383,5393]
===
match
---
name: issue_field_checker [3667,3686]
name: issue_field_checker [3667,3686]
===
match
---
name: self [2003,2007]
name: self [2003,2007]
===
match
---
atom_expr [5533,5552]
atom_expr [5532,5551]
===
match
---
name: jira_conn_id [3455,3467]
name: jira_conn_id [3455,3467]
===
match
---
argument [2301,2336]
argument [2301,2336]
===
match
---
trailer [5038,5261]
trailer [5038,5261]
===
match
---
operator: = [3537,3538]
operator: = [3537,3538]
===
match
---
name: Callable [1786,1794]
name: Callable [1786,1794]
===
match
---
name: task_id [2181,2188]
name: task_id [2181,2188]
===
match
---
name: self [4918,4922]
name: self [4918,4922]
===
match
---
trailer [4787,4793]
trailer [4787,4793]
===
match
---
name: field_val [4949,4958]
name: field_val [4949,4958]
===
match
---
atom_expr [2091,2109]
atom_expr [2091,2109]
===
match
---
simple_stmt [881,955]
simple_stmt [881,955]
===
match
---
trailer [3256,3261]
trailer [3256,3261]
===
match
---
param [3361,3407]
param [3361,3407]
===
match
---
name: Callable [811,819]
name: Callable [811,819]
===
match
---
expr_stmt [3450,3482]
expr_stmt [3450,3482]
===
match
---
trailer [3979,3993]
trailer [3979,3993]
===
match
---
name: airflow [960,967]
name: airflow [960,967]
===
match
---
expr_stmt [4272,4285]
expr_stmt [4272,4285]
===
match
---
operator: , [2388,2389]
operator: , [2388,2389]
===
match
---
name: self [4489,4493]
name: self [4489,4493]
===
match
---
simple_stmt [1845,1872]
simple_stmt [1845,1872]
===
match
---
trailer [3530,3536]
trailer [3530,3536]
===
match
---
simple_stmt [3696,3787]
simple_stmt [3696,3787]
===
match
---
name: self [4628,4632]
name: self [4628,4632]
===
match
---
name: info [3847,3851]
name: info [3847,3851]
===
match
---
expr_stmt [4738,4795]
expr_stmt [4738,4795]
===
match
---
name: resources [847,856]
name: resources [847,856]
===
match
---
if_stmt [4517,5262]
if_stmt [4517,5262]
===
match
---
trailer [4963,4969]
trailer [4963,4969]
===
match
---
parameters [1608,1827]
parameters [1608,1827]
===
match
---
name: expected_value [5734,5748]
name: expected_value [5699,5713]
===
match
---
name: expected_value [3315,3329]
name: expected_value [3315,3329]
===
match
---
argument [2259,2287]
argument [2259,2287]
===
match
---
name: kwargs [3418,3424]
name: kwargs [3418,3424]
===
match
---
comp_op [4530,4536]
comp_op [4530,4536]
===
match
---
name: name [4959,4963]
name: name [4959,4963]
===
match
---
name: self [5224,5228]
name: self [5224,5228]
===
match
---
argument [2350,2388]
argument [2350,2388]
===
match
---
name: jira_operator [3931,3944]
name: jira_operator [3931,3944]
===
match
---
name: context [2493,2500]
name: context [2493,2500]
===
match
---
trailer [5329,5394]
trailer [5329,5394]
===
match
---
expr_stmt [3975,4057]
expr_stmt [3975,4057]
===
match
---
name: ticket_id [3508,3517]
name: ticket_id [3508,3517]
===
match
---
name: jira_conn_id [1900,1912]
name: jira_conn_id [1900,1912]
===
match
---
trailer [2371,2388]
trailer [2371,2388]
===
match
---
tfpdef [1643,1659]
tfpdef [1643,1659]
===
match
---
trailer [3993,4010]
trailer [3993,4010]
===
match
---
name: lower [4767,4772]
name: lower [4767,4772]
===
match
---
name: self [2318,2322]
name: self [2318,2322]
===
match
---
atom_expr [4778,4795]
atom_expr [4778,4795]
===
match
---
name: JIRAError [5278,5287]
name: JIRAError [5278,5287]
===
match
---
name: execute [2477,2484]
name: execute [2477,2484]
===
match
---
operator: = [3468,3469]
operator: = [3468,3469]
===
match
---
atom_expr [4566,4593]
atom_expr [4566,4593]
===
match
---
suite [4884,4972]
suite [4884,4972]
===
match
---
operator: -> [4161,4163]
operator: -> [4161,4163]
===
match
---
param [2414,2419]
param [2414,2419]
===
match
---
operator: , [1659,1660]
operator: , [1659,1660]
===
match
---
name: self [1618,1622]
name: self [1618,1622]
===
match
---
except_clause [5403,5424]
except_clause [5403,5419]
===
match
---
comparison [4747,4795]
comparison [4747,4795]
===
match
---
atom_expr [1880,1897]
atom_expr [1880,1897]
===
match
---
operator: = [2110,2111]
operator: = [2110,2111]
===
match
---
expr_stmt [2052,2082]
expr_stmt [2052,2082]
===
match
---
name: task_id [2194,2201]
name: task_id [2194,2201]
===
match
---
name: self [2134,2138]
name: self [2134,2138]
===
match
---
operator: , [3351,3352]
operator: , [3351,3352]
===
match
---
classdef [2504,5910]
classdef [2504,5875]
===
match
---
string: 'jira_default' [3213,3227]
string: 'jira_default' [3213,3227]
===
match
---
name: log [5320,5323]
name: log [5320,5323]
===
match
---
param [1713,1750]
param [1713,1750]
===
match
---
trailer [4696,4712]
trailer [4696,4712]
===
match
---
atom_expr [3526,3536]
atom_expr [3526,3536]
===
match
---
trailer [4409,4424]
trailer [4409,4424]
===
match
---
name: expected_value [4410,4424]
name: expected_value [4410,4424]
===
match
---
trailer [4751,4766]
trailer [4751,4766]
===
match
---
name: self [3838,3842]
name: self [3838,3842]
===
match
---
operator: = [4626,4627]
operator: = [4626,4627]
===
match
---
funcdef [4117,5910]
funcdef [4117,5875]
===
match
---
name: self [3975,3979]
name: self [3975,3979]
===
match
---
name: self [5315,5319]
name: self [5315,5319]
===
match
---
name: self [2052,2056]
name: self [2052,2056]
===
match
---
name: kwargs [1814,1820]
name: kwargs [1814,1820]
===
match
---
name: self [3168,3172]
name: self [3168,3172]
===
match
---
suite [4997,5262]
suite [4997,5262]
===
match
---
argument [2215,2245]
argument [2215,2245]
===
match
---
name: self [5789,5793]
name: self [5754,5758]
===
match
---
name: BaseSensorOperator [988,1006]
name: BaseSensorOperator [988,1006]
===
match
---
atom_expr [4405,4424]
atom_expr [4405,4424]
===
match
---
name: context [4103,4110]
name: context [4103,4110]
===
match
---
name: BaseSensorOperator [1078,1096]
name: BaseSensorOperator [1078,1096]
===
match
---
name: ticket_id [3906,3915]
name: ticket_id [3906,3915]
===
match
---
name: self [4141,4145]
name: self [4141,4145]
===
match
---
name: Optional [827,835]
name: Optional [827,835]
===
match
---
import_from [881,954]
import_from [881,954]
===
match
---
name: field_val [4651,4660]
name: field_val [4651,4660]
===
match
---
simple_stmt [4272,4286]
simple_stmt [4272,4286]
===
match
---
string: """     Monitors a jira ticket for any change.      :param jira_conn_id: reference to a pre-defined Jira Connection     :type jira_conn_id: str     :param method_name: method name from jira-python-sdk to be execute     :type method_name: str     :param method_params: parameters for the method method_name     :type method_params: dict     :param result_processor: function that return boolean and act as a sensor response     :type result_processor: function     """ [1103,1570]
string: """     Monitors a jira ticket for any change.      :param jira_conn_id: reference to a pre-defined Jira Connection     :type jira_conn_id: str     :param method_name: method name from jira-python-sdk to be execute     :type method_name: str     :param method_params: parameters for the method method_name     :type method_params: dict     :param result_processor: function that return boolean and act as a sensor response     :type result_processor: function     """ [1103,1570]
===
match
---
name: jira_error [5291,5301]
name: jira_error [5291,5301]
===
match
---
atom_expr [3838,3916]
atom_expr [3838,3916]
===
match
---
trailer [1736,1742]
trailer [1736,1742]
===
match
---
operator: , [4586,4587]
operator: , [4586,4587]
===
match
---
name: result_processor [2008,2024]
name: result_processor [2008,2024]
===
match
---
name: field [5860,5865]
name: field [5825,5830]
===
match
---
name: method_params [1713,1726]
name: method_params [1713,1726]
===
match
---
operator: , [1820,1821]
operator: , [1820,1821]
===
match
---
trailer [5797,5802]
trailer [5762,5767]
===
match
---
name: Optional [1728,1736]
name: Optional [1728,1736]
===
match
---
name: field_val [4455,4464]
name: field_val [4455,4464]
===
match
---
name: self [5867,5871]
name: self [5832,5836]
===
match
---
name: field [3531,3536]
name: field [3531,3536]
===
match
---
atom_expr [4046,4056]
atom_expr [4046,4056]
===
match
---
name: jira_conn_id [1669,1681]
name: jira_conn_id [1669,1681]
===
match
---
name: getattr [4467,4474]
name: getattr [4467,4474]
===
match
---
trailer [3905,3915]
trailer [3905,3915]
===
match
---
name: operators [909,918]
name: operators [909,918]
===
match
---
name: context [3807,3814]
name: context [3807,3814]
===
match
---
atom_expr [1921,1942]
atom_expr [1921,1942]
===
match
---
operator: @ [3126,3127]
operator: @ [3126,3127]
===
match
---
operator: , [940,941]
operator: , [940,941]
===
match
---
trailer [3339,3344]
trailer [3339,3344]
===
match
---
atom_expr [3662,3686]
atom_expr [3662,3686]
===
match
---
simple_stmt [5022,5262]
simple_stmt [5022,5262]
===
match
---
trailer [5323,5329]
trailer [5323,5329]
===
match
---
operator: , [5727,5728]
operator: , [5692,5693]
===
match
---
atom [4013,4057]
atom [4013,4057]
===
match
---
dotted_name [960,980]
dotted_name [960,980]
===
match
---
atom_expr [2189,2201]
atom_expr [2189,2201]
===
match
---
trailer [3701,3703]
trailer [3701,3703]
===
match
---
dictorsetmaker [4014,4056]
dictorsetmaker [4014,4056]
===
match
---
comp_op [4425,4431]
comp_op [4425,4431]
===
match
---
string: "Jira error while checking with expected value: %s" [5330,5381]
string: "Jira error while checking with expected value: %s" [5330,5381]
===
match
---
suite [4542,5262]
suite [4542,5262]
===
match
---
name: field_val [4577,4586]
name: field_val [4577,4586]
===
match
---
suite [3829,4112]
suite [3829,4112]
===
match
---
comparison [5599,5613]
comparison [5564,5578]
===
match
---
name: lower [4964,4969]
name: lower [4964,4969]
===
match
---
operator: = [3756,3757]
operator: = [3756,3757]
===
match
---
operator: , [2287,2288]
operator: , [2287,2288]
===
match
---
simple_stmt [5470,5554]
simple_stmt [5465,5553]
===
match
---
atom_expr [3553,3572]
atom_expr [3553,3572]
===
match
---
name: method_params [2096,2109]
name: method_params [2096,2109]
===
match
---
simple_stmt [2134,2400]
simple_stmt [2134,2400]
===
match
---
name: field_checker_func [3757,3775]
name: field_checker_func [3757,3775]
===
match
---
name: self [4378,4382]
name: self [4378,4382]
===
match
---
expr_stmt [1880,1912]
expr_stmt [1880,1912]
===
match
---
name: field [4383,4388]
name: field [4383,4388]
===
match
---
name: self [3926,3930]
name: self [3926,3930]
===
match
---
trailer [1852,1861]
trailer [1852,1861]
===
match
---
atom_expr [4467,4500]
atom_expr [4467,4500]
===
match
---
name: typing [792,798]
name: typing [792,798]
===
match
---
name: result_processor [3740,3756]
name: result_processor [3740,3756]
===
match
---
import_as_names [931,954]
import_as_names [931,954]
===
match
---
operator: = [3573,3574]
operator: = [3573,3574]
===
match
---
string: "Issue field %s don't have expected value %s yet." [5803,5853]
string: "Issue field %s don't have expected value %s yet." [5768,5818]
===
match
---
name: self [5717,5721]
name: self [5682,5686]
===
match
---
atom_expr [3696,3786]
atom_expr [3696,3786]
===
match
---
operator: = [2153,2154]
operator: = [2153,2154]
===
match
---
name: field_checker_func [3601,3619]
name: field_checker_func [3601,3619]
===
match
---
name: self [4046,4050]
name: self [4046,4050]
===
match
---
name: providers [894,903]
name: providers [894,903]
===
match
---
operator: = [3345,3346]
operator: = [3345,3346]
===
match
---
name: log [5794,5797]
name: log [5759,5762]
===
match
---
tfpdef [3278,3298]
tfpdef [3278,3298]
===
match
---
operator: , [819,820]
operator: , [819,820]
===
match
---
simple_stmt [3926,3967]
simple_stmt [3926,3967]
===
match
---
trailer [5478,5484]
trailer [5473,5483]
===
match
---
tfpdef [2420,2433]
tfpdef [2420,2433]
===
match
---
expr_stmt [4619,4660]
expr_stmt [4619,4660]
===
match
---
trailer [5026,5030]
trailer [5026,5030]
===
match
---
name: field_checker_func [3361,3379]
name: field_checker_func [3361,3379]
===
match
---
operator: , [1633,1634]
operator: , [1633,1634]
===
match
---
atom_expr [3926,3956]
atom_expr [3926,3956]
===
match
---
operator: ** [1812,1814]
operator: ** [1812,1814]
===
match
---
atom_expr [2155,2399]
atom_expr [2155,2399]
===
match
---
comparison [4520,4541]
comparison [4520,4541]
===
match
---
trailer [3846,3851]
trailer [3846,3851]
===
match
---
trailer [2484,2501]
trailer [2484,2501]
===
match
---
name: method_name [1643,1654]
name: method_name [1643,1654]
===
match
---
trailer [2275,2287]
trailer [2275,2287]
===
match
---
simple_stmt [787,836]
simple_stmt [787,836]
===
match
---
atom_expr [3491,3505]
atom_expr [3491,3505]
===
match
---
comparison [3601,3627]
comparison [3601,3627]
===
match
---
name: error [5479,5484]
name: exception [5474,5483]
===
match
---
suite [2539,5910]
suite [2539,5875]
===
match
---
name: isinstance [4566,4576]
name: isinstance [4566,4576]
===
match
---
comp_op [4362,4368]
comp_op [4362,4368]
===
match
---
simple_stmt [3641,3687]
simple_stmt [3641,3687]
===
match
---
atom_expr [1845,1871]
atom_expr [1845,1871]
===
match
---
name: self [5627,5631]
name: self [5592,5596]
===
match
---
try_stmt [4294,5588]
try_stmt [4294,5553]
===
match
---
trailer [4864,4883]
trailer [4864,4883]
===
match
---
trailer [5484,5553]
trailer [5483,5552]
===
match
---
trailer [4831,4852]
trailer [4831,4852]
===
match
---
name: super [1845,1850]
name: super [1845,1850]
===
match
---
name: base [976,980]
name: base [976,980]
===
match
---
trailer [5635,5640]
trailer [5600,5605]
===
match
---
name: apply_defaults [1044,1058]
name: apply_defaults [1044,1058]
===
match
---
operator: -> [3432,3434]
operator: -> [3432,3434]
===
match
---
trailer [4050,4056]
trailer [4050,4056]
===
match
---
and_test [4821,4883]
and_test [4821,4883]
===
match
---
name: method_params [2323,2336]
name: method_params [2323,2336]
===
match
---
operator: , [5715,5716]
operator: , [5680,5681]
===
match
---
suite [5457,5588]
suite [5452,5553]
===
match
---
name: poke [2409,2413]
name: poke [2409,2413]
===
match
---
argument [4095,4110]
argument [4095,4110]
===
match
---
name: lower [4938,4943]
name: lower [4938,4943]
===
match
---
trailer [2193,2201]
trailer [2193,2201]
===
match
---
atom_expr [3450,3467]
atom_expr [3450,3467]
===
match
---
name: method_params [2112,2125]
name: method_params [2112,2125]
===
match
---
trailer [3495,3505]
trailer [3495,3505]
===
match
---
simple_stmt [837,880]
simple_stmt [837,880]
===
match
---
testlist_comp [3107,3119]
testlist_comp [3107,3119]
===
match
---
if_stmt [5596,5888]
if_stmt [5561,5853]
===
match
---
string: "issue" [3959,3966]
string: "issue" [3959,3966]
===
match
---
trailer [4083,4088]
trailer [4083,4088]
===
match
---
name: self [3526,3530]
name: self [3526,3530]
===
match
---
atom_expr [3975,4010]
atom_expr [3975,4010]
===
match
---
simple_stmt [5315,5395]
simple_stmt [5315,5395]
===
match
---
name: self [3491,3495]
name: self [3491,3495]
===
match
---
trailer [4024,4034]
trailer [4024,4034]
===
match
---
trailer [1884,1897]
trailer [1884,1897]
===
match
---
name: kwargs [3779,3785]
name: kwargs [3779,3785]
===
match
---
atom_expr [5717,5727]
atom_expr [5682,5692]
===
match
---
atom_expr [3248,3261]
atom_expr [3248,3261]
===
match
---
name: error [5324,5329]
name: error [5324,5329]
===
match
---
name: self [3450,3454]
name: self [3450,3454]
===
match
---
expr_stmt [3526,3544]
expr_stmt [3526,3544]
===
match
---
trailer [4922,4937]
trailer [4922,4937]
===
match
---
atom_expr [4489,4499]
atom_expr [4489,4499]
===
match
---
name: result [4909,4915]
name: result [4909,4915]
===
match
---
atom_expr [5022,5261]
atom_expr [5022,5261]
===
match
---
operator: = [1943,1944]
operator: = [1943,1944]
===
match
---
simple_stmt [955,1007]
simple_stmt [955,1007]
===
match
---
name: jira_method_args [3994,4010]
name: jira_method_args [3994,4010]
===
match
---
atom_expr [5224,5234]
atom_expr [5224,5234]
===
match
---
atom_expr [2134,2152]
atom_expr [2134,2152]
===
match
---
name: jira_method [2259,2270]
name: jira_method [2259,2270]
===
match
---
arglist [4577,4592]
arglist [4577,4592]
===
match
---
name: Any [2438,2441]
name: Any [2438,2441]
===
match
---
operator: = [3957,3958]
operator: = [3957,3958]
===
match
---
param [1759,1803]
param [1759,1803]
===
match
---
trailer [2232,2245]
trailer [2232,2245]
===
match
---
dotted_name [1012,1036]
dotted_name [1012,1036]
===
match
---
simple_stmt [1103,1571]
simple_stmt [1103,1571]
===
match
---
operator: ** [1862,1864]
operator: ** [1862,1864]
===
match
---
name: context [4095,4102]
name: context [4095,4102]
===
match
---
dotted_name [886,923]
dotted_name [886,923]
===
match
---
name: poke [3796,3800]
name: poke [3796,3800]
===
match
---
parameters [3800,3821]
parameters [3800,3821]
===
match
---
name: JiraOperator [942,954]
name: JiraOperator [942,954]
===
match
---
atom_expr [4628,4647]
atom_expr [4628,4647]
===
match
---
operator: , [4706,4707]
operator: , [4706,4707]
===
match
---
simple_stmt [4455,4501]
simple_stmt [4455,4501]
===
match
---
tfpdef [3807,3820]
tfpdef [3807,3820]
===
match
---
operator: { [4013,4014]
operator: { [4013,4014]
===
match
---
name: self [4089,4093]
name: self [4089,4093]
===
match
---
suite [1990,2044]
suite [1990,2044]
===
match
---
name: self [2228,2232]
name: self [2228,2232]
===
match
---
operator: , [2336,2337]
operator: , [2336,2337]
===
match
---
name: Dict [3816,3820]
name: Dict [3816,3820]
===
match
---
name: result_processor [2027,2043]
name: result_processor [2027,2043]
===
match
---
name: expected_value [3558,3572]
name: expected_value [3558,3572]
===
match
---
simple_stmt [4909,4972]
simple_stmt [4909,4972]
===
match
---
atom_expr [5470,5553]
atom_expr [5465,5552]
===
match
---
name: Optional [3331,3339]
name: Optional [3331,3339]
===
match
---
operator: , [825,826]
operator: , [825,826]
===
match
---
name: field_val [4865,4874]
name: field_val [4865,4874]
===
match
---
arglist [4475,4499]
arglist [4475,4499]
===
match
---
name: jira_conn_id [2215,2227]
name: jira_conn_id [2215,2227]
===
match
---
operator: , [1622,1623]
operator: , [1622,1623]
===
match
---
simple_stmt [1921,1950]
simple_stmt [1921,1950]
===
match
---
name: field_val [4520,4529]
name: field_val [4520,4529]
===
match
---
name: Any [3825,3828]
name: Any [3825,3828]
===
match
---
atom_expr [4821,4852]
atom_expr [4821,4852]
===
match
---
string: 'jira_default' [1689,1703]
string: 'jira_default' [1689,1703]
===
match
---
argument [2181,2201]
argument [2181,2201]
===
match
---
operator: , [5853,5854]
operator: , [5818,5819]
===
match
---
name: self [2189,2193]
name: self [2189,2193]
===
match
---
operator: = [4465,4466]
operator: = [4465,4466]
===
match
---
atom_expr [4686,4712]
atom_expr [4686,4712]
===
match
---
name: jira_operator [2139,2152]
name: jira_operator [2139,2152]
===
match
---
operator: = [3104,3105]
operator: = [3104,3105]
===
match
---
string: 'Jira Sensor checking for change in ticket: %s' [3852,3899]
string: 'Jira Sensor checking for change in ticket: %s' [3852,3899]
===
match
---
trailer [3703,3712]
trailer [3703,3712]
===
update-node
---
name: error [5479,5484]
replace error by exception
===
delete-node
---
name: e [5423,5424]
===
===
delete-tree
---
simple_stmt [5566,5588]
    atom_expr [5566,5587]
        name: self [5566,5570]
        trailer [5570,5574]
            name: log [5571,5574]
        trailer [5574,5584]
            name: exception [5575,5584]
        trailer [5584,5587]
            name: e [5585,5586]
