===
match
---
atom_expr [8292,8303]
atom_expr [8292,8303]
===
match
---
name: get_previous_scheduled_dagrun [27808,27837]
name: get_previous_scheduled_dagrun [27808,27837]
===
match
---
trailer [43659,43664]
trailer [43659,43664]
===
match
---
operator: , [43855,43856]
operator: , [43855,43856]
===
match
---
tfpdef [35944,35962]
tfpdef [35944,35962]
===
match
---
name: getboolean [45861,45871]
name: getboolean [45861,45871]
===
match
---
trailer [43932,43947]
trailer [43932,43947]
===
match
---
trailer [41013,41015]
trailer [41013,41015]
===
match
---
name: ignore_depends_on_past [54024,54046]
name: ignore_depends_on_past [54023,54045]
===
match
---
trailer [34642,34646]
trailer [34642,34646]
===
match
---
name: DagRun [60401,60407]
name: DagRun [60353,60359]
===
match
---
atom_expr [62540,62596]
atom_expr [62492,62548]
===
match
---
try_stmt [42980,45056]
try_stmt [42980,45056]
===
match
---
name: context [52165,52172]
name: context [52203,52210]
===
match
---
string: """         Get datetime of the next retry if the task instance fails. For exponential         backoff, retry_delay is used as base and will be converted to seconds.         """ [33139,33316]
string: """         Get datetime of the next retry if the task instance fails. For exponential         backoff, retry_delay is used as base and will be converted to seconds.         """ [33139,33316]
===
match
---
atom_expr [6680,6689]
atom_expr [6680,6689]
===
match
---
operator: , [14276,14277]
operator: , [14276,14277]
===
match
---
atom_expr [8780,8792]
atom_expr [8780,8792]
===
match
---
atom_expr [80162,80180]
atom_expr [80114,80132]
===
match
---
operator: = [11038,11039]
operator: = [11038,11039]
===
match
---
name: models [35370,35376]
name: models [35370,35376]
===
match
---
name: ignore_task_deps [18347,18363]
name: ignore_task_deps [18347,18363]
===
match
---
string: 'dag' [64653,64658]
string: 'dag' [64605,64610]
===
match
---
fstring_expr [67702,67705]
fstring_expr [67654,67657]
===
match
---
name: info [31812,31816]
name: info [31812,31816]
===
match
---
name: self [13296,13300]
name: self [13296,13300]
===
match
---
name: str [53797,53800]
name: str [53796,53799]
===
match
---
if_stmt [72870,73033]
if_stmt [72822,72985]
===
match
---
name: PodGenerator [3141,3153]
name: PodGenerator [3141,3153]
===
match
---
operator: = [69499,69500]
operator: = [69451,69452]
===
match
---
expr_stmt [12012,12048]
expr_stmt [12012,12048]
===
match
---
arglist [63569,63598]
arglist [63521,63550]
===
match
---
operator: = [22094,22095]
operator: = [22094,22095]
===
match
---
name: unixname [12091,12099]
name: unixname [12091,12099]
===
match
---
trailer [49914,49929]
trailer [49914,49929]
===
match
---
trailer [52255,52259]
trailer [52286,52290]
===
match
---
simple_stmt [80280,80315]
simple_stmt [80232,80267]
===
match
---
atom [37998,38008]
atom [37998,38008]
===
match
---
name: items [66580,66585]
name: items [66532,66537]
===
match
---
comparison [52897,52924]
comparison [52896,52923]
===
match
---
name: dag [61428,61431]
name: dag [61380,61383]
===
match
---
simple_stmt [40455,40475]
simple_stmt [40455,40475]
===
match
---
operator: = [36035,36036]
operator: = [36035,36036]
===
match
---
decorator [28579,28589]
decorator [28579,28589]
===
match
---
trailer [71103,71111]
trailer [71055,71063]
===
match
---
simple_stmt [48066,48085]
simple_stmt [48066,48085]
===
match
---
name: self [66456,66460]
name: self [66408,66412]
===
match
---
name: str [63329,63332]
name: str [63281,63284]
===
match
---
return_stmt [41418,41429]
return_stmt [41418,41429]
===
match
---
exprlist [49376,49380]
exprlist [49376,49380]
===
match
---
simple_stmt [13953,13983]
simple_stmt [13953,13983]
===
match
---
name: task_id [5465,5472]
name: task_id [5465,5472]
===
match
---
name: self [81116,81120]
name: self [81068,81072]
===
match
---
operator: , [9518,9519]
operator: , [9518,9519]
===
match
---
param [31028,31041]
param [31028,31041]
===
match
---
trailer [22886,22892]
trailer [22886,22892]
===
match
---
name: self [54836,54840]
name: self [54835,54839]
===
match
---
string: 'TaskInstance' [26570,26584]
string: 'TaskInstance' [26570,26584]
===
match
---
import_from [7340,7381]
import_from [7340,7381]
===
match
---
not_test [37765,37784]
not_test [37765,37784]
===
match
---
operator: = [21590,21591]
operator: = [21590,21591]
===
match
---
operator: , [54161,54162]
operator: , [54160,54161]
===
match
---
argument [78666,78736]
argument [78618,78688]
===
match
---
name: default_html_content [71288,71308]
name: default_html_content [71240,71260]
===
match
---
atom_expr [37722,37735]
atom_expr [37722,37735]
===
match
---
name: self [80632,80636]
name: self [80584,80588]
===
match
---
name: try_number [12691,12701]
name: try_number [12691,12701]
===
match
---
import_as_names [2088,2109]
import_as_names [2088,2109]
===
match
---
trailer [6137,6141]
trailer [6137,6141]
===
match
---
argument [29618,29629]
argument [29618,29629]
===
match
---
trailer [82235,82251]
trailer [82187,82203]
===
match
---
trailer [71374,71386]
trailer [71326,71338]
===
match
---
name: pickle_id [18172,18181]
name: pickle_id [18172,18181]
===
match
---
trailer [29692,29716]
trailer [29692,29716]
===
match
---
trailer [26337,26345]
trailer [26337,26345]
===
match
---
name: execution_date [11917,11931]
name: execution_date [11917,11931]
===
match
---
simple_stmt [47246,47340]
simple_stmt [47246,47340]
===
match
---
trailer [33046,33054]
trailer [33046,33054]
===
match
---
operator: = [59308,59309]
operator: = [59260,59261]
===
match
---
atom_expr [64530,64596]
atom_expr [64482,64548]
===
match
---
suite [18750,18799]
suite [18750,18799]
===
match
---
name: prev_ti [30162,30169]
name: prev_ti [30162,30169]
===
match
---
name: error [4475,4480]
name: error [4475,4480]
===
match
---
atom_expr [71266,71333]
atom_expr [71218,71285]
===
match
---
param [29780,29785]
param [29780,29785]
===
match
---
argument [38463,38496]
argument [38463,38496]
===
match
---
operator: = [68656,68657]
operator: = [68608,68609]
===
match
---
return_stmt [4237,4275]
return_stmt [4237,4275]
===
match
---
simple_stmt [41342,41410]
simple_stmt [41342,41410]
===
match
---
trailer [64538,64542]
trailer [64490,64494]
===
match
---
funcdef [81344,81395]
funcdef [81296,81347]
===
match
---
name: html_content_err [72777,72793]
name: html_content_err [72729,72745]
===
match
---
name: self [81070,81074]
name: self [81022,81026]
===
match
---
name: State [52911,52916]
name: State [52910,52915]
===
match
---
atom_expr [45620,45636]
atom_expr [45620,45636]
===
match
---
parameters [62977,62983]
parameters [62929,62935]
===
match
---
operator: = [39078,39079]
operator: = [39078,39079]
===
match
---
and_test [14650,14671]
and_test [14650,14671]
===
match
---
trailer [19126,19133]
trailer [19126,19133]
===
match
---
trailer [25989,26009]
trailer [25989,26009]
===
match
---
trailer [29273,29292]
trailer [29273,29292]
===
match
---
simple_stmt [81138,81157]
simple_stmt [81090,81109]
===
match
---
name: Optional [56274,56282]
name: Optional [56273,56281]
===
match
---
atom_expr [72662,72677]
atom_expr [72614,72629]
===
match
---
simple_stmt [48554,48609]
simple_stmt [48554,48609]
===
match
---
suite [20687,21010]
suite [20687,21010]
===
match
---
name: task [33371,33375]
name: task [33371,33375]
===
match
---
name: Float [1291,1296]
name: Float [1291,1296]
===
match
---
trailer [66703,66720]
trailer [66655,66672]
===
match
---
name: ti [22530,22532]
name: ti [22530,22532]
===
match
---
operator: = [5370,5371]
operator: = [5370,5371]
===
match
---
expr_stmt [69484,69537]
expr_stmt [69436,69489]
===
match
---
trailer [74207,74211]
trailer [74159,74163]
===
match
---
trailer [15945,15950]
trailer [15945,15950]
===
match
---
simple_stmt [27276,27352]
simple_stmt [27276,27352]
===
match
---
if_stmt [18050,18110]
if_stmt [18050,18110]
===
match
---
name: innerjoin [11078,11087]
name: innerjoin [11078,11087]
===
match
---
trailer [29617,29647]
trailer [29617,29647]
===
match
---
trailer [7409,7415]
trailer [7409,7415]
===
match
---
name: plugins_manager [2123,2138]
name: plugins_manager [2123,2138]
===
match
---
name: TaskInstance [26074,26086]
name: TaskInstance [26074,26086]
===
match
---
trailer [10249,10262]
trailer [10249,10262]
===
match
---
trailer [37537,37555]
trailer [37537,37555]
===
match
---
name: exception [70812,70821]
name: exception [70764,70773]
===
match
---
trailer [8798,8813]
trailer [8798,8813]
===
match
---
tfpdef [29194,29214]
tfpdef [29194,29214]
===
match
---
decorator [77395,77412]
decorator [77347,77364]
===
match
---
name: SEEK_SET [4064,4072]
name: SEEK_SET [4064,4072]
===
match
---
name: info [43660,43664]
name: info [43660,43664]
===
match
---
operator: , [32380,32381]
operator: , [32380,32381]
===
match
---
trailer [28555,28571]
trailer [28555,28571]
===
match
---
name: error [54864,54869]
name: error [54863,54868]
===
match
---
name: ti [79875,79877]
name: ti [79827,79829]
===
match
---
trailer [30109,30113]
trailer [30109,30113]
===
match
---
trailer [71838,71840]
trailer [71790,71792]
===
match
---
operator: = [58109,58110]
operator: = [58108,58109]
===
match
---
name: e [47780,47781]
name: e [47780,47781]
===
match
---
arglist [57203,57260]
arglist [57202,57259]
===
match
---
atom_expr [64198,64206]
atom_expr [64150,64158]
===
match
---
operator: = [27134,27135]
operator: = [27134,27135]
===
match
---
param [14234,14256]
param [14234,14256]
===
match
---
name: task_id [24344,24351]
name: task_id [24344,24351]
===
match
---
name: dag_id [68571,68577]
name: dag_id [68523,68529]
===
match
---
arglist [39894,39948]
arglist [39894,39948]
===
match
---
atom_expr [18240,18251]
atom_expr [18240,18251]
===
match
---
decorated [59110,59481]
decorated [59062,59433]
===
match
---
name: self [22633,22637]
name: self [22633,22637]
===
match
---
name: reason [32864,32870]
name: reason [32864,32870]
===
match
---
name: strftime [60815,60823]
name: strftime [60767,60775]
===
match
---
argument [39936,39948]
argument [39936,39948]
===
match
---
trailer [4469,4474]
trailer [4469,4474]
===
match
---
name: self [20931,20935]
name: self [20931,20935]
===
match
---
operator: = [48991,48992]
operator: = [48991,48992]
===
match
---
operator: , [81628,81629]
operator: , [81580,81581]
===
match
---
string: "Rescheduling due to concurrency limits reached " [40093,40142]
string: "Rescheduling due to concurrency limits reached " [40093,40142]
===
match
---
atom_expr [12102,12111]
atom_expr [12102,12111]
===
match
---
trailer [77314,77316]
trailer [77266,77268]
===
match
---
trailer [50648,50699]
trailer [50686,50737]
===
match
---
suite [76422,76456]
suite [76374,76408]
===
match
---
expr_stmt [72156,72209]
expr_stmt [72108,72161]
===
match
---
tfpdef [53511,53532]
tfpdef [53510,53531]
===
match
---
name: tis [7747,7750]
name: tis [7747,7750]
===
match
---
operator: @ [80753,80754]
operator: @ [80705,80706]
===
match
---
expr_stmt [37693,37713]
expr_stmt [37693,37713]
===
match
---
operator: = [39978,39979]
operator: = [39978,39979]
===
match
---
operator: = [64367,64368]
operator: = [64319,64320]
===
match
---
simple_stmt [80813,80841]
simple_stmt [80765,80793]
===
match
---
expr_stmt [82603,82646]
expr_stmt [82555,82598]
===
match
---
atom [70158,70519]
atom [70110,70471]
===
match
---
name: self [50482,50486]
name: self [50520,50524]
===
match
---
operator: -> [80711,80713]
operator: -> [80663,80665]
===
match
---
operator: = [41776,41777]
operator: = [41776,41777]
===
match
---
trailer [61537,61552]
trailer [61489,61504]
===
match
---
string: 'Try {{try_number}} out of {{max_tries + 1}}<br>' [69791,69840]
string: 'Try {{try_number}} out of {{max_tries + 1}}<br>' [69743,69792]
===
match
---
if_stmt [7320,7511]
if_stmt [7320,7511]
===
match
---
name: dep_status [32814,32824]
name: dep_status [32814,32824]
===
match
---
simple_stmt [33806,34092]
simple_stmt [33806,34092]
===
match
---
atom_expr [22308,22323]
atom_expr [22308,22323]
===
match
---
operator: = [74627,74628]
operator: = [74579,74580]
===
match
---
arglist [41526,41536]
arglist [41526,41536]
===
match
---
atom_expr [27136,27178]
atom_expr [27136,27178]
===
match
---
name: clear_task_instances [4715,4735]
name: clear_task_instances [4715,4735]
===
match
---
name: warnings [892,900]
name: warnings [892,900]
===
match
---
simple_stmt [28288,28536]
simple_stmt [28288,28536]
===
match
---
tfpdef [63323,63332]
tfpdef [63275,63284]
===
match
---
operator: = [31965,31966]
operator: = [31965,31966]
===
match
---
simple_stmt [18650,18679]
simple_stmt [18650,18679]
===
match
---
name: _prepare_and_execute_task_with_callbacks [48094,48134]
name: _prepare_and_execute_task_with_callbacks [48094,48134]
===
match
---
name: engine [41132,41138]
name: engine [41132,41138]
===
match
---
expr_stmt [46094,46360]
expr_stmt [46094,46360]
===
match
---
simple_stmt [50708,50735]
simple_stmt [50746,50773]
===
match
---
if_stmt [73927,74194]
if_stmt [73879,74146]
===
match
---
atom_expr [54994,55022]
atom_expr [54993,55021]
===
match
---
name: end_date [25036,25044]
name: end_date [25036,25044]
===
match
---
testlist_comp [44837,44865]
testlist_comp [44837,44865]
===
match
---
trailer [20972,20978]
trailer [20972,20978]
===
match
---
dotted_name [1454,1476]
dotted_name [1454,1476]
===
match
---
trailer [6902,6910]
trailer [6902,6910]
===
match
---
operator: , [49659,49660]
operator: , [49659,49660]
===
match
---
name: handle_failure [59343,59357]
name: handle_failure [59295,59309]
===
match
---
if_stmt [18511,18567]
if_stmt [18511,18567]
===
match
---
import_from [2237,2287]
import_from [2237,2287]
===
match
---
name: bool [74700,74704]
name: bool [74652,74656]
===
match
---
suite [80804,80841]
suite [80756,80793]
===
match
---
name: refresh_from_db [37630,37645]
name: refresh_from_db [37630,37645]
===
match
---
operator: , [15682,15683]
operator: , [15682,15683]
===
match
---
name: subject [72542,72549]
name: subject [72494,72501]
===
match
---
atom_expr [22564,22571]
atom_expr [22564,22571]
===
match
---
dotted_name [41658,41678]
dotted_name [41658,41678]
===
match
---
name: ti [79383,79385]
name: ti [79335,79337]
===
match
---
name: self [11732,11736]
name: self [11732,11736]
===
match
---
arglist [26117,26348]
arglist [26117,26348]
===
match
---
dotted_name [1959,1988]
dotted_name [1959,1988]
===
match
---
name: self [23669,23673]
name: self [23669,23673]
===
match
---
trailer [27925,27955]
trailer [27925,27955]
===
match
---
name: info [41351,41355]
name: info [41351,41355]
===
match
---
operator: , [4799,4800]
operator: , [4799,4800]
===
match
---
string: 'kcah_acitats' [82432,82446]
string: 'kcah_acitats' [82384,82398]
===
match
---
name: first [39240,39245]
name: first [39240,39245]
===
match
---
argument [6742,7117]
argument [6742,7117]
===
match
---
name: State [39127,39132]
name: State [39127,39132]
===
match
---
tfpdef [15622,15646]
tfpdef [15622,15646]
===
match
---
name: email [58972,58977]
name: email [58966,58971]
===
match
---
name: task [42942,42946]
name: task [42942,42946]
===
match
---
simple_stmt [42833,42864]
simple_stmt [42833,42864]
===
match
---
name: test_mode [57082,57091]
name: test_mode [57081,57090]
===
match
---
name: task_reschedule [39168,39183]
name: task_reschedule [39168,39183]
===
match
---
trailer [10715,10734]
trailer [10715,10734]
===
match
---
atom_expr [23400,23420]
atom_expr [23400,23420]
===
match
---
name: str [8198,8201]
name: str [8198,8201]
===
match
---
expr_stmt [61652,61702]
expr_stmt [61604,61654]
===
match
---
name: max_tries [5580,5589]
name: max_tries [5580,5589]
===
match
---
atom_expr [50482,50520]
atom_expr [50520,50558]
===
match
---
name: setattr [66605,66612]
name: setattr [66557,66564]
===
match
---
operator: = [26836,26837]
operator: = [26836,26837]
===
match
---
name: bool [53689,53693]
name: bool [53688,53692]
===
match
---
funcdef [63891,63943]
funcdef [63843,63895]
===
match
---
trailer [20507,20511]
trailer [20507,20511]
===
match
---
funcdef [13362,13899]
funcdef [13362,13899]
===
match
---
suite [39283,39349]
suite [39283,39349]
===
match
---
name: logging [827,834]
name: logging [827,834]
===
match
---
name: ti [5241,5243]
name: ti [5241,5243]
===
match
---
name: pool [36051,36055]
name: pool [36051,36055]
===
match
---
operator: = [9681,9682]
operator: = [9681,9682]
===
match
---
name: task_id [78903,78910]
name: task_id [78855,78862]
===
match
---
param [67806,67813]
param [67758,67765]
===
match
---
simple_stmt [19588,19633]
simple_stmt [19588,19633]
===
match
---
trailer [46721,46741]
trailer [46721,46741]
===
match
---
name: dump [4470,4474]
name: dump [4470,4474]
===
match
---
dotted_name [1581,1602]
dotted_name [1581,1602]
===
match
---
name: key [71865,71868]
name: key [71817,71820]
===
match
---
annassign [80518,80534]
annassign [80470,80486]
===
match
---
trailer [52786,52788]
trailer [52785,52787]
===
match
---
argument [59371,59390]
argument [59323,59342]
===
match
---
operator: , [54260,54261]
operator: , [54259,54260]
===
match
---
name: filter [21620,21626]
name: filter [21620,21626]
===
match
---
name: mark_success_url [19466,19482]
name: mark_success_url [19466,19482]
===
match
---
trailer [20875,20881]
trailer [20875,20881]
===
match
---
name: _try_number [13323,13334]
name: _try_number [13323,13334]
===
match
---
atom_expr [82432,82460]
atom_expr [82384,82412]
===
match
---
name: execution_date [60728,60742]
name: execution_date [60680,60694]
===
match
---
name: verbose [31820,31827]
name: verbose [31820,31827]
===
match
---
trailer [50890,50896]
trailer [50928,50934]
===
match
---
expr_stmt [79586,79637]
expr_stmt [79538,79589]
===
match
---
trailer [74211,74429]
trailer [74163,74381]
===
match
---
operator: } [19133,19134]
operator: } [19133,19134]
===
match
---
trailer [22556,22561]
trailer [22556,22561]
===
match
---
name: state [11156,11161]
name: state [11156,11161]
===
match
---
name: mark_success [35944,35956]
name: mark_success [35944,35956]
===
match
---
atom_expr [9895,9910]
atom_expr [9895,9910]
===
match
---
operator: , [74257,74258]
operator: , [74209,74210]
===
match
---
comparison [59744,59762]
comparison [59696,59714]
===
match
---
name: state [24437,24442]
name: state [24437,24442]
===
match
---
name: Optional [16002,16010]
name: Optional [16002,16010]
===
match
---
operator: = [10202,10203]
operator: = [10202,10203]
===
match
---
name: dag [27730,27733]
name: dag [27730,27733]
===
match
---
name: provide_session [59111,59126]
name: provide_session [59063,59078]
===
match
---
atom_expr [62167,62212]
atom_expr [62119,62164]
===
match
---
trailer [52916,52924]
trailer [52915,52923]
===
match
---
operator: + [34189,34190]
operator: + [34189,34190]
===
match
---
operator: , [15184,15185]
operator: , [15184,15185]
===
match
---
name: self [66613,66617]
name: self [66565,66569]
===
match
---
name: timezone [39080,39088]
name: timezone [39080,39088]
===
match
---
operator: } [42968,42969]
operator: } [42968,42969]
===
match
---
operator: , [64547,64548]
operator: , [64499,64500]
===
match
---
name: _run_raw_task [54449,54462]
name: _run_raw_task [54448,54461]
===
match
---
atom_expr [46662,46900]
atom_expr [46662,46900]
===
match
---
return_stmt [29064,29112]
return_stmt [29064,29112]
===
match
---
name: airflow [1552,1559]
name: airflow [1552,1559]
===
match
---
operator: = [68437,68438]
operator: = [68389,68390]
===
match
---
name: log [29531,29534]
name: log [29531,29534]
===
match
---
name: Optional [30439,30447]
name: Optional [30439,30447]
===
match
---
name: try_number [8131,8141]
name: try_number [8131,8141]
===
match
---
name: start_date [57235,57245]
name: start_date [57234,57244]
===
match
---
trailer [35108,35110]
trailer [35108,35110]
===
match
---
param [48141,48149]
param [48141,48149]
===
match
---
name: self [46256,46260]
name: self [46256,46260]
===
match
---
expr_stmt [22807,22824]
expr_stmt [22807,22824]
===
match
---
name: end_date [57252,57260]
name: end_date [57251,57259]
===
match
---
if_stmt [52694,52884]
if_stmt [52693,52883]
===
match
---
operator: = [68697,68698]
operator: = [68649,68650]
===
match
---
argument [39688,39733]
argument [39688,39733]
===
match
---
name: task [34807,34811]
name: task [34807,34811]
===
match
---
or_test [57866,57911]
or_test [57865,57910]
===
match
---
simple_stmt [40524,40537]
simple_stmt [40524,40537]
===
match
---
name: self [14091,14095]
name: self [14091,14095]
===
match
---
simple_stmt [11946,12003]
simple_stmt [11946,12003]
===
match
---
arith_expr [25031,25062]
arith_expr [25031,25062]
===
match
---
arglist [64543,64595]
arglist [64495,64547]
===
match
---
operator: , [65572,65573]
operator: , [65524,65525]
===
match
---
name: self [28551,28555]
name: self [28551,28555]
===
match
---
trailer [29683,29692]
trailer [29683,29692]
===
match
---
operator: , [4785,4786]
operator: , [4785,4786]
===
match
---
param [67798,67805]
param [67750,67757]
===
match
---
suite [62488,62528]
suite [62440,62480]
===
match
---
name: self [24133,24137]
name: self [24133,24137]
===
match
---
expr_stmt [11255,11282]
expr_stmt [11255,11282]
===
match
---
trailer [49719,49721]
trailer [49719,49721]
===
match
---
simple_stmt [67227,67272]
simple_stmt [67179,67224]
===
match
---
trailer [52812,52825]
trailer [52811,52824]
===
match
---
decorator [19448,19458]
decorator [19448,19458]
===
match
---
name: retry_exponential_backoff [33376,33401]
name: retry_exponential_backoff [33376,33401]
===
match
---
operator: = [61789,61790]
operator: = [61741,61742]
===
match
---
name: render [71858,71864]
name: render [71810,71816]
===
match
---
simple_stmt [22080,22108]
simple_stmt [22080,22108]
===
match
---
string: """     Sets the current execution context to the provided context object.     This method should be called once per Task execution, before calling operator.execute.     """ [3389,3562]
string: """     Sets the current execution context to the provided context object.     This method should be called once per Task execution, before calling operator.execute.     """ [3389,3562]
===
match
---
atom_expr [56274,56287]
atom_expr [56273,56286]
===
match
---
name: passed [32825,32831]
name: passed [32825,32831]
===
match
---
trailer [80557,80561]
trailer [80509,80513]
===
match
---
name: kube_image [68646,68656]
name: kube_image [68598,68608]
===
match
---
name: execution_date [33949,33963]
name: execution_date [33949,33963]
===
match
---
name: execution_date [8102,8116]
name: execution_date [8102,8116]
===
match
---
name: int [81050,81053]
name: int [81002,81005]
===
match
---
operator: } [19148,19149]
operator: } [19148,19149]
===
match
---
expr_stmt [5268,5293]
expr_stmt [5268,5293]
===
match
---
atom_expr [20460,20479]
atom_expr [20460,20479]
===
match
---
operator: , [11701,11702]
operator: , [11701,11702]
===
match
---
atom_expr [10871,10897]
atom_expr [10871,10897]
===
match
---
name: dag_id [8069,8075]
name: dag_id [8069,8075]
===
match
---
simple_stmt [71950,71980]
simple_stmt [71902,71932]
===
match
---
classdef [62691,63600]
classdef [62643,63552]
===
match
---
trailer [61799,61808]
trailer [61751,61760]
===
match
---
name: execution_date [60674,60688]
name: execution_date [60626,60640]
===
match
---
name: airflow [2448,2455]
name: airflow [2448,2455]
===
match
---
trailer [6122,6137]
trailer [6122,6137]
===
match
---
name: raw [15967,15970]
name: raw [15967,15970]
===
match
---
atom_expr [38676,38692]
atom_expr [38676,38692]
===
match
---
simple_stmt [18216,18254]
simple_stmt [18216,18254]
===
match
---
atom_expr [66605,66651]
atom_expr [66557,66603]
===
match
---
import_from [2205,2236]
import_from [2205,2236]
===
match
---
trailer [19262,19277]
trailer [19262,19277]
===
match
---
trailer [72983,72985]
trailer [72935,72937]
===
match
---
operator: = [12623,12624]
operator: = [12623,12624]
===
match
---
name: dag [5452,5455]
name: dag [5452,5455]
===
match
---
string: """Is task instance is eligible for retry""" [59526,59570]
string: """Is task instance is eligible for retry""" [59478,59522]
===
match
---
string: "Failed to load task run error" [4244,4275]
string: "Failed to load task run error" [4244,4275]
===
match
---
name: check_and_change_state_before_execution [53897,53936]
name: check_and_change_state_before_execution [53896,53935]
===
match
---
tfpdef [64350,64366]
tfpdef [64302,64318]
===
match
---
atom_expr [55672,55708]
atom_expr [55671,55707]
===
match
---
name: queue [81348,81353]
name: queue [81300,81305]
===
match
---
simple_stmt [45591,45611]
simple_stmt [45591,45611]
===
match
---
name: execution_date [76520,76534]
name: execution_date [76472,76486]
===
match
---
name: DepContext [39572,39582]
name: DepContext [39572,39582]
===
match
---
trailer [24325,24390]
trailer [24325,24390]
===
match
---
name: TaskInstance [79411,79423]
name: TaskInstance [79363,79375]
===
match
---
name: exception [69221,69230]
name: exception [69173,69182]
===
match
---
trailer [3979,3995]
trailer [3979,3995]
===
match
---
atom_expr [39190,39247]
atom_expr [39190,39247]
===
match
---
simple_stmt [18597,18621]
simple_stmt [18597,18621]
===
match
---
funcdef [50761,51145]
funcdef [50799,51183]
===
match
---
argument [62665,62680]
argument [62617,62632]
===
match
---
name: task [56894,56898]
name: task [56893,56897]
===
match
---
name: from_string [71186,71197]
name: from_string [71138,71149]
===
match
---
parameters [80957,80963]
parameters [80909,80915]
===
match
---
param [15692,15722]
param [15692,15722]
===
match
---
name: fd [4705,4707]
name: fd [4705,4707]
===
match
---
trailer [4474,4485]
trailer [4474,4485]
===
match
---
trailer [74015,74193]
trailer [73967,74145]
===
match
---
atom_expr [40702,40730]
atom_expr [40702,40730]
===
match
---
operator: } [7828,7829]
operator: } [7828,7829]
===
match
---
trailer [5464,5473]
trailer [5464,5473]
===
match
---
simple_stmt [82512,82553]
simple_stmt [82464,82505]
===
match
---
name: dag_id [76407,76413]
name: dag_id [76359,76365]
===
match
---
suite [11541,12003]
suite [11541,12003]
===
match
---
atom_expr [60669,60709]
atom_expr [60621,60661]
===
match
---
or_test [74352,74389]
or_test [74304,74341]
===
match
---
name: ignore_depends_on_past [15731,15753]
name: ignore_depends_on_past [15731,15753]
===
match
---
trailer [20403,20411]
trailer [20403,20411]
===
match
---
trailer [48302,48324]
trailer [48302,48324]
===
match
---
arglist [30193,30221]
arglist [30193,30221]
===
match
---
comp_op [53226,53232]
comp_op [53225,53231]
===
match
---
string: '-' [61748,61751]
string: '-' [61700,61703]
===
match
---
return_stmt [28078,28089]
return_stmt [28078,28089]
===
match
---
name: query [77593,77598]
name: query [77545,77550]
===
match
---
parameters [80785,80791]
parameters [80737,80743]
===
match
---
name: task [23292,23296]
name: task [23292,23296]
===
match
---
import_from [3019,3091]
import_from [3019,3091]
===
match
---
expr_stmt [79953,79995]
expr_stmt [79905,79947]
===
match
---
name: self [40402,40406]
name: self [40402,40406]
===
match
---
name: utils [2603,2608]
name: utils [2603,2608]
===
match
---
trailer [55576,55588]
trailer [55575,55587]
===
match
---
string: 'Marking task as SKIPPED. ' [43682,43709]
string: 'Marking task as SKIPPED. ' [43682,43709]
===
match
---
number: 1 [5623,5624]
number: 1 [5623,5624]
===
match
---
param [64011,64021]
param [63963,63973]
===
match
---
operator: , [8628,8629]
operator: , [8628,8629]
===
match
---
operator: = [30874,30875]
operator: = [30874,30875]
===
match
---
name: exception_html [70843,70857]
name: exception_html [70795,70809]
===
match
---
operator: @ [24396,24397]
operator: @ [24396,24397]
===
match
---
operator: , [32174,32175]
operator: , [32174,32175]
===
match
---
atom_expr [35113,35130]
atom_expr [35113,35130]
===
match
---
simple_stmt [1547,1576]
simple_stmt [1547,1576]
===
match
---
name: commit [21001,21007]
name: commit [21001,21007]
===
match
---
atom_expr [3226,3240]
atom_expr [3226,3240]
===
match
---
trailer [11826,11831]
trailer [11826,11831]
===
match
---
operator: , [9668,9669]
operator: , [9668,9669]
===
match
---
name: dag_run [82616,82623]
name: dag_run [82568,82575]
===
match
---
string: 'task' [69468,69474]
string: 'task' [69420,69426]
===
match
---
dotted_name [1620,1638]
dotted_name [1620,1638]
===
match
---
trailer [78035,78068]
trailer [77987,78020]
===
match
---
name: error_file [56811,56821]
name: error_file [56810,56820]
===
match
---
name: str [16047,16050]
name: str [16047,16050]
===
match
---
suite [59517,59642]
suite [59469,59594]
===
match
---
operator: , [1338,1339]
operator: , [1338,1339]
===
match
---
test [60556,60591]
test [60508,60543]
===
match
---
name: Stats [57041,57046]
name: Stats [57040,57045]
===
match
---
if_stmt [51804,51916]
if_stmt [51842,51954]
===
match
---
operator: , [32294,32295]
operator: , [32294,32295]
===
match
---
trailer [54815,54821]
trailer [54814,54820]
===
match
---
name: orm [1465,1468]
name: orm [1465,1468]
===
match
---
operator: , [10772,10773]
operator: , [10772,10773]
===
match
---
name: RUNNING [40822,40829]
name: RUNNING [40822,40829]
===
match
---
name: RenderedTaskInstanceFields [67380,67406]
name: RenderedTaskInstanceFields [67332,67358]
===
match
---
name: filter [7684,7690]
name: filter [7684,7690]
===
match
---
operator: , [74571,74572]
operator: , [74523,74524]
===
match
---
operator: = [68105,68106]
operator: = [68057,68058]
===
match
---
trailer [11320,11338]
trailer [11320,11338]
===
match
---
trailer [49629,49651]
trailer [49629,49651]
===
match
---
string: '' [41628,41630]
string: '' [41628,41630]
===
match
---
suite [18819,18869]
suite [18819,18869]
===
match
---
trailer [10820,10861]
trailer [10820,10861]
===
match
---
name: date [41582,41586]
name: date [41582,41586]
===
match
---
trailer [37555,37581]
trailer [37555,37581]
===
match
---
operator: , [10781,10782]
operator: , [10781,10782]
===
match
---
name: schedulable_tis [47246,47261]
name: schedulable_tis [47246,47261]
===
match
---
name: ignore_ti_state [54130,54145]
name: ignore_ti_state [54129,54144]
===
match
---
param [59187,59216]
param [59139,59168]
===
match
---
operator: == [79002,79004]
operator: == [78954,78956]
===
match
---
trailer [23874,23878]
trailer [23874,23878]
===
match
---
name: run_id [60547,60553]
name: run_id [60499,60505]
===
match
---
return_stmt [35609,35618]
return_stmt [35609,35618]
===
match
---
arglist [9505,9555]
arglist [9505,9555]
===
match
---
name: session [1469,1476]
name: session [1469,1476]
===
match
---
string: """Sets the log context.""" [77891,77918]
string: """Sets the log context.""" [77843,77870]
===
match
---
operator: } [19757,19758]
operator: } [19757,19758]
===
match
---
name: query [7657,7662]
name: query [7657,7662]
===
match
---
atom_expr [14604,14617]
atom_expr [14604,14617]
===
match
---
trailer [18553,18566]
trailer [18553,18566]
===
match
---
suite [48841,50629]
suite [48841,50667]
===
match
---
name: self [42701,42705]
name: self [42701,42705]
===
match
---
comparison [47166,47210]
comparison [47166,47210]
===
match
---
trailer [32668,32889]
trailer [32668,32889]
===
match
---
if_stmt [61616,61830]
if_stmt [61568,61782]
===
match
---
operator: , [18011,18012]
operator: , [18011,18012]
===
match
---
fstring_string: <TaskInstance:  [33012,33027]
fstring_string: <TaskInstance:  [33012,33027]
===
match
---
trailer [15012,15020]
trailer [15012,15020]
===
match
---
parameters [72816,72822]
parameters [72768,72774]
===
match
---
atom_expr [50965,50984]
atom_expr [51003,51022]
===
match
---
operator: -> [21099,21101]
operator: -> [21099,21101]
===
match
---
atom_expr [76920,76942]
atom_expr [76872,76894]
===
match
---
name: context [49652,49659]
name: context [49652,49659]
===
match
---
arglist [28835,29045]
arglist [28835,29045]
===
match
---
operator: , [44774,44775]
operator: , [44774,44775]
===
match
---
name: String [9808,9814]
name: String [9808,9814]
===
match
---
name: task_copy [54982,54991]
name: task_copy [54981,54990]
===
match
---
atom_expr [14729,14741]
atom_expr [14729,14741]
===
match
---
atom_expr [82422,82461]
atom_expr [82374,82413]
===
match
---
trailer [41809,41814]
trailer [41809,41814]
===
match
---
simple_stmt [21586,21800]
simple_stmt [21586,21800]
===
match
---
arglist [32023,32175]
arglist [32023,32175]
===
match
---
name: k [49376,49377]
name: k [49376,49377]
===
match
---
trailer [64812,64827]
trailer [64764,64779]
===
match
---
trailer [12395,12399]
trailer [12395,12399]
===
match
---
name: task_id [5375,5382]
name: task_id [5375,5382]
===
match
---
name: self [81214,81218]
name: self [81166,81170]
===
match
---
expr_stmt [9488,9556]
expr_stmt [9488,9556]
===
match
---
operator: = [80394,80395]
operator: = [80346,80347]
===
match
---
name: kube_image [68669,68679]
name: kube_image [68621,68631]
===
match
---
trailer [41350,41355]
trailer [41350,41355]
===
match
---
name: provide_session [53392,53407]
name: provide_session [53391,53406]
===
match
---
name: self [13152,13156]
name: self [13152,13156]
===
match
---
name: log [31808,31811]
name: log [31808,31811]
===
match
---
name: datetime [79971,79979]
name: datetime [79923,79931]
===
match
---
name: write [48933,48938]
name: write [48933,48938]
===
match
---
trailer [80118,80124]
trailer [80070,80076]
===
match
---
fstring_string: operator_failures_ [56990,57008]
fstring_string: operator_failures_ [56989,57007]
===
match
---
operator: , [64758,64759]
operator: , [64710,64711]
===
match
---
trailer [41138,41146]
trailer [41138,41146]
===
match
---
suite [72727,72795]
suite [72679,72747]
===
match
---
name: defaultdict [5110,5121]
name: defaultdict [5110,5121]
===
match
---
atom_expr [27805,27854]
atom_expr [27805,27854]
===
match
---
name: cmd [18294,18297]
name: cmd [18294,18297]
===
match
---
simple_stmt [50473,50521]
simple_stmt [50511,50559]
===
match
---
name: dag_id [10632,10638]
name: dag_id [10632,10638]
===
match
---
operator: { [44654,44655]
operator: { [44654,44655]
===
match
---
string: 'previously_succeeded' [37865,37887]
string: 'previously_succeeded' [37865,37887]
===
match
---
atom_expr [12012,12031]
atom_expr [12012,12031]
===
match
---
name: default_var [63575,63586]
name: default_var [63527,63538]
===
match
---
test [54728,54794]
test [54727,54793]
===
match
---
parameters [68330,68336]
parameters [68282,68288]
===
match
---
operator: = [70571,70572]
operator: = [70523,70524]
===
match
---
decorated [81330,81395]
decorated [81282,81347]
===
match
---
expr_stmt [34589,34667]
expr_stmt [34589,34667]
===
match
---
decorator [24174,24184]
decorator [24174,24184]
===
match
---
simple_stmt [37854,37895]
simple_stmt [37854,37895]
===
match
---
operator: -> [81047,81049]
operator: -> [80999,81001]
===
match
---
trailer [44343,44397]
trailer [44343,44397]
===
match
---
simple_stmt [5490,5517]
simple_stmt [5490,5517]
===
match
---
name: log [40619,40622]
name: log [40619,40622]
===
match
---
name: integrate_macros_plugins [2146,2170]
name: integrate_macros_plugins [2146,2170]
===
match
---
name: namespace [68895,68904]
name: namespace [68847,68856]
===
match
---
param [31004,31009]
param [31004,31009]
===
match
---
name: dr [27805,27807]
name: dr [27805,27807]
===
match
---
name: stats [2218,2223]
name: stats [2218,2223]
===
match
---
expr_stmt [38190,38511]
expr_stmt [38190,38511]
===
match
---
atom_expr [77702,77722]
atom_expr [77654,77674]
===
match
---
operator: = [62065,62066]
operator: = [62017,62018]
===
match
---
name: timeout [51444,51451]
name: timeout [51482,51489]
===
match
---
name: datetime [73224,73232]
name: datetime [73176,73184]
===
match
---
arglist [32265,32300]
arglist [32265,32300]
===
match
---
term [34191,34212]
term [34191,34212]
===
match
---
atom_expr [74613,74626]
atom_expr [74565,74578]
===
match
---
trailer [78372,78379]
trailer [78324,78331]
===
match
---
simple_stmt [60359,60535]
simple_stmt [60311,60487]
===
match
---
operator: = [68410,68411]
operator: = [68362,68363]
===
match
---
name: dag_id [74605,74611]
name: dag_id [74557,74563]
===
match
---
atom_expr [28808,29055]
atom_expr [28808,29055]
===
match
---
name: provide_session [81562,81577]
name: provide_session [81514,81529]
===
match
---
name: self [40055,40059]
name: self [40055,40059]
===
match
---
name: Tuple [1090,1095]
name: Tuple [1090,1095]
===
match
---
simple_stmt [73012,73033]
simple_stmt [72964,72985]
===
match
---
string: """Prepare Task for Execution""" [48165,48197]
string: """Prepare Task for Execution""" [48165,48197]
===
match
---
name: attr [41492,41496]
name: attr [41492,41496]
===
match
---
name: task [14609,14613]
name: task [14609,14613]
===
match
---
name: provide_session [24397,24412]
name: provide_session [24397,24412]
===
match
---
name: session [20993,21000]
name: session [20993,21000]
===
match
---
trailer [39582,39848]
trailer [39582,39848]
===
match
---
atom_expr [19252,19290]
atom_expr [19252,19290]
===
match
---
name: dep_context [31903,31914]
name: dep_context [31903,31914]
===
match
---
atom_expr [23358,23373]
atom_expr [23358,23373]
===
match
---
name: qry [82046,82049]
name: qry [81998,82001]
===
match
---
name: timeout [2872,2879]
name: timeout [2872,2879]
===
match
---
name: conf [62540,62544]
name: conf [62492,62496]
===
match
---
subscriptlist [56161,56175]
subscriptlist [56160,56174]
===
match
---
name: self [80097,80101]
name: self [80049,80053]
===
match
---
name: String [9969,9975]
name: String [9969,9975]
===
match
---
if_stmt [40770,40838]
if_stmt [40770,40838]
===
match
---
number: 1 [50694,50695]
number: 1 [50732,50733]
===
match
---
operator: = [20680,20681]
operator: = [20680,20681]
===
match
---
name: Any [3236,3239]
name: Any [3236,3239]
===
match
---
name: default_html_content [72269,72289]
name: default_html_content [72221,72241]
===
match
---
name: TaskInstance [82100,82112]
name: TaskInstance [82052,82064]
===
match
---
trailer [14613,14617]
trailer [14613,14617]
===
match
---
if_stmt [56483,56643]
if_stmt [56482,56642]
===
match
---
operator: = [76647,76648]
operator: = [76599,76600]
===
match
---
suite [51194,51938]
suite [51232,51976]
===
match
---
string: 'ti_dag_date' [10662,10675]
string: 'ti_dag_date' [10662,10675]
===
match
---
name: AirflowException [66811,66827]
name: AirflowException [66763,66779]
===
match
---
atom_expr [26165,26215]
atom_expr [26165,26215]
===
match
---
name: ti [82304,82306]
name: ti [82256,82258]
===
match
---
operator: , [32751,32752]
operator: , [32751,32752]
===
match
---
name: _run_as_user [80194,80206]
name: _run_as_user [80146,80158]
===
match
---
not_test [14650,14663]
not_test [14650,14663]
===
match
---
name: run_as_user [23482,23493]
name: run_as_user [23482,23493]
===
match
---
trailer [5968,5978]
trailer [5968,5978]
===
match
---
arglist [6871,6924]
arglist [6871,6924]
===
match
---
name: State [53139,53144]
name: State [53138,53143]
===
match
---
name: self [65322,65326]
name: self [65274,65278]
===
match
---
name: ti [22780,22782]
name: ti [22780,22782]
===
match
---
arglist [44762,44797]
arglist [44762,44797]
===
match
---
import_from [901,936]
import_from [901,936]
===
match
---
name: from_obj [68805,68813]
name: from_obj [68757,68765]
===
match
---
name: TaskReschedule [3201,3215]
name: TaskReschedule [3201,3215]
===
match
---
name: yesterday_ds [62308,62320]
name: yesterday_ds [62260,62272]
===
match
---
parameters [48134,48155]
parameters [48134,48155]
===
match
---
name: job_id [22521,22527]
name: job_id [22521,22527]
===
match
---
name: self [33366,33370]
name: self [33366,33370]
===
match
---
parameters [32375,32413]
parameters [32375,32413]
===
match
---
string: "Marking task as FAILED." [58111,58136]
string: "Marking task as FAILED." [58110,58135]
===
match
---
name: self [77673,77677]
name: self [77625,77629]
===
match
---
name: include_prior_dates [74679,74698]
name: include_prior_dates [74631,74650]
===
match
---
name: TaskInstance [20429,20441]
name: TaskInstance [20429,20441]
===
match
---
testlist_comp [18228,18251]
testlist_comp [18228,18251]
===
match
---
trailer [39985,39990]
trailer [39985,39990]
===
match
---
suite [53158,53386]
suite [53157,53385]
===
match
---
name: mark_success [54480,54492]
name: mark_success [54479,54491]
===
match
---
name: ignore_task_deps [15151,15167]
name: ignore_task_deps [15151,15167]
===
match
---
trailer [42723,42749]
trailer [42723,42749]
===
match
---
atom_expr [66613,66622]
atom_expr [66565,66574]
===
match
---
parameters [69214,69231]
parameters [69166,69183]
===
match
---
suite [40787,40838]
suite [40787,40838]
===
match
---
return_stmt [81207,81224]
return_stmt [81159,81176]
===
match
---
name: log [40060,40063]
name: log [40060,40063]
===
match
---
return_stmt [8744,8826]
return_stmt [8744,8826]
===
match
---
expr_stmt [19588,19632]
expr_stmt [19588,19632]
===
match
---
decorator [74435,74452]
decorator [74387,74404]
===
match
---
suite [78195,78220]
suite [78147,78172]
===
match
---
param [15817,15847]
param [15817,15847]
===
match
---
atom_expr [46140,46298]
atom_expr [46140,46298]
===
match
---
expr_stmt [5093,5168]
expr_stmt [5093,5168]
===
match
---
expr_stmt [6628,7216]
expr_stmt [6628,7216]
===
match
---
operator: , [72677,72678]
operator: , [72629,72630]
===
match
---
trailer [53059,53061]
trailer [53058,53060]
===
match
---
name: jobs [7353,7357]
name: jobs [7353,7357]
===
match
---
trailer [79155,79170]
trailer [79107,79122]
===
match
---
name: self [25031,25035]
name: self [25031,25035]
===
match
---
trailer [33969,33980]
trailer [33969,33980]
===
match
---
name: str [3980,3983]
name: str [3980,3983]
===
match
---
name: Index [10656,10661]
name: Index [10656,10661]
===
match
---
trailer [24821,24832]
trailer [24821,24832]
===
match
---
name: Stats [48773,48778]
name: Stats [48773,48778]
===
match
---
argument [9868,9877]
argument [9868,9877]
===
match
---
trailer [24929,24942]
trailer [24929,24942]
===
match
---
name: Stats [44989,44994]
name: Stats [44989,44994]
===
match
---
trailer [68916,68935]
trailer [68868,68887]
===
match
---
name: and_ [6658,6662]
name: and_ [6658,6662]
===
match
---
simple_stmt [21116,21510]
simple_stmt [21116,21510]
===
match
---
param [23669,23674]
param [23669,23674]
===
match
---
atom_expr [26260,26279]
atom_expr [26260,26279]
===
match
---
name: set_duration [55394,55406]
name: set_duration [55393,55405]
===
match
---
trailer [33698,33712]
trailer [33698,33712]
===
match
---
name: Column [10243,10249]
name: Column [10243,10249]
===
match
---
name: params [60237,60243]
name: params [60189,60195]
===
match
---
argument [29092,29111]
argument [29092,29111]
===
match
---
arglist [44344,44396]
arglist [44344,44396]
===
match
---
trailer [22084,22093]
trailer [22084,22093]
===
match
---
name: context [48885,48892]
name: context [48885,48892]
===
match
---
name: ti [22690,22692]
name: ti [22690,22692]
===
match
---
decorated [29722,30379]
decorated [29722,30379]
===
match
---
operator: { [62435,62436]
operator: { [62387,62388]
===
match
---
import_name [1186,1201]
import_name [1186,1201]
===
match
---
operator: , [28050,28051]
operator: , [28050,28051]
===
match
---
name: var [64203,64206]
name: var [64155,64158]
===
match
---
name: getpid [40895,40901]
name: getpid [40895,40901]
===
match
---
atom_expr [10211,10223]
atom_expr [10211,10223]
===
match
---
expr_stmt [77927,77941]
expr_stmt [77879,77893]
===
match
---
trailer [7260,7266]
trailer [7260,7266]
===
match
---
name: airflow [45951,45958]
name: airflow [45951,45958]
===
match
---
operator: == [21660,21662]
operator: == [21660,21662]
===
match
---
name: in_ [26312,26315]
name: in_ [26312,26315]
===
match
---
name: task_copy [48811,48820]
name: task_copy [48811,48820]
===
match
---
for_stmt [5173,6154]
for_stmt [5173,6154]
===
match
---
atom_expr [72005,72015]
atom_expr [71957,71967]
===
match
---
arith_expr [19648,19868]
arith_expr [19648,19868]
===
match
---
name: self [42648,42652]
name: self [42648,42652]
===
match
---
name: test_mode [59381,59390]
name: test_mode [59333,59342]
===
match
---
name: Variable [64530,64538]
name: Variable [64482,64490]
===
match
---
operator: + [60879,60880]
operator: + [60831,60832]
===
match
---
operator: , [53734,53735]
operator: , [53733,53734]
===
match
---
expr_stmt [71166,71238]
expr_stmt [71118,71190]
===
match
---
name: raw [14310,14313]
name: raw [14310,14313]
===
match
---
name: max_tries [70946,70955]
name: max_tries [70898,70907]
===
match
---
atom_expr [32853,32870]
atom_expr [32853,32870]
===
match
---
trailer [5949,5959]
trailer [5949,5959]
===
match
---
name: hasattr [69454,69461]
name: hasattr [69406,69413]
===
match
---
simple_stmt [61715,61757]
simple_stmt [61667,61709]
===
match
---
comparison [78780,78809]
comparison [78732,78761]
===
match
---
name: task [62476,62480]
name: task [62428,62432]
===
match
---
name: execution_date [79156,79170]
name: execution_date [79108,79122]
===
match
---
string: "Current context is not equal to the state at context stack. Expected=%s, got=%s" [3771,3852]
string: "Current context is not equal to the state at context stack. Expected=%s, got=%s" [3771,3852]
===
match
---
name: AirflowTaskTimeout [51581,51599]
name: AirflowTaskTimeout [51619,51637]
===
match
---
atom_expr [67632,67707]
atom_expr [67584,67659]
===
match
---
return_stmt [30299,30378]
return_stmt [30299,30378]
===
match
---
trailer [62075,62084]
trailer [62027,62036]
===
match
---
atom_expr [33683,33746]
atom_expr [33683,33746]
===
match
---
name: check_and_change_state_before_execution [35649,35688]
name: check_and_change_state_before_execution [35649,35688]
===
match
---
name: self [81463,81467]
name: self [81415,81419]
===
match
---
trailer [50167,50177]
trailer [50024,50032]
===
match
---
operator: , [76614,76615]
operator: , [76566,76567]
===
match
---
name: task [41383,41387]
name: task [41383,41387]
===
match
---
trailer [24882,24888]
trailer [24882,24888]
===
match
---
name: exc [1366,1369]
name: exc [1366,1369]
===
match
---
argument [62650,62663]
argument [62602,62615]
===
match
---
name: timedelta [34688,34697]
name: timedelta [34688,34697]
===
match
---
name: filter [20299,20305]
name: filter [20299,20305]
===
match
---
operator: @ [29722,29723]
operator: @ [29722,29723]
===
match
---
parameters [15531,16105]
parameters [15531,16105]
===
match
---
simple_stmt [80051,80089]
simple_stmt [80003,80041]
===
match
---
fstring_expr [19745,19758]
fstring_expr [19745,19758]
===
match
---
funcdef [3927,4276]
funcdef [3927,4276]
===
match
---
simple_stmt [64187,64208]
simple_stmt [64139,64160]
===
match
---
name: filter [77626,77632]
name: filter [77578,77584]
===
match
---
operator: = [38252,38253]
operator: = [38252,38253]
===
match
---
name: dag_id [68479,68485]
name: dag_id [68431,68437]
===
match
---
trailer [43655,43659]
trailer [43655,43659]
===
match
---
name: ignore_schedule [27646,27661]
name: ignore_schedule [27646,27661]
===
match
---
name: UtcDateTime [9747,9758]
name: UtcDateTime [9747,9758]
===
match
---
trailer [59444,59467]
trailer [59396,59419]
===
match
---
name: os [19035,19037]
name: os [19035,19037]
===
match
---
simple_stmt [42758,42796]
simple_stmt [42758,42796]
===
match
---
string: """Key used to identify task instance.""" [8022,8063]
string: """Key used to identify task instance.""" [8022,8063]
===
match
---
suite [32414,32970]
suite [32414,32970]
===
match
---
name: dep_context [32382,32393]
name: dep_context [32382,32393]
===
match
---
atom_expr [8522,8533]
atom_expr [8522,8533]
===
match
---
simple_stmt [18079,18110]
simple_stmt [18079,18110]
===
match
---
arglist [46197,46276]
arglist [46197,46276]
===
match
---
simple_stmt [22476,22504]
simple_stmt [22476,22504]
===
match
---
atom [70573,70585]
atom [70525,70537]
===
match
---
trailer [55035,55040]
trailer [55034,55039]
===
match
---
trailer [18842,18868]
trailer [18842,18868]
===
match
---
operator: , [29254,29255]
operator: , [29254,29255]
===
match
---
atom_expr [31803,31816]
atom_expr [31803,31816]
===
match
---
operator: = [74251,74252]
operator: = [74203,74204]
===
match
---
string: """         Pull XComs that optionally meet certain criteria.          The default value for `key` limits the search to XComs         that were returned by other tasks (as opposed to those that were pushed         manually). To remove this filter, pass key=None (or any desired value).          If a single task_id string is provided, the result is the value of the         most recent matching XCom from that task_id. If multiple task_ids are         provided, a tuple of matching values is returned. None is returned         whenever no matches are found.          :param key: A key for the XCom. If provided, only XComs with matching             keys will be returned. The default key is 'return_value', also             available as a constant XCOM_RETURN_KEY. This key is automatically             given to XComs returned by tasks (as opposed to being pushed             manually). To remove the filter, pass key=None.         :type key: str         :param task_ids: Only XComs from tasks with matching ids will be             pulled. Can pass None to remove the filter.         :type task_ids: str or iterable of strings (representing task_ids)         :param dag_id: If provided, only pulls XComs from this DAG.             If None (default), the DAG of the calling task is used.         :type dag_id: str         :param include_prior_dates: If False, only XComs from the current             execution_date are returned. If True, XComs from previous dates             are returned as well.         :type include_prior_dates: bool         :param session: Sqlalchemy ORM Session         :type session: Session         """ [74769,76395]
string: """         Pull XComs that optionally meet certain criteria.          The default value for `key` limits the search to XComs         that were returned by other tasks (as opposed to those that were pushed         manually). To remove this filter, pass key=None (or any desired value).          If a single task_id string is provided, the result is the value of the         most recent matching XCom from that task_id. If multiple task_ids are         provided, a tuple of matching values is returned. None is returned         whenever no matches are found.          :param key: A key for the XCom. If provided, only XComs with matching             keys will be returned. The default key is 'return_value', also             available as a constant XCOM_RETURN_KEY. This key is automatically             given to XComs returned by tasks (as opposed to being pushed             manually). To remove the filter, pass key=None.         :type key: str         :param task_ids: Only XComs from tasks with matching ids will be             pulled. Can pass None to remove the filter.         :type task_ids: str or iterable of strings (representing task_ids)         :param dag_id: If provided, only pulls XComs from this DAG.             If None (default), the DAG of the calling task is used.         :type dag_id: str         :param include_prior_dates: If False, only XComs from the current             execution_date are returned. If True, XComs from previous dates             are returned as well.         :type include_prior_dates: bool         :param session: Sqlalchemy ORM Session         :type session: Session         """ [74721,76347]
===
match
---
name: dag_run [60141,60148]
name: dag_run [60093,60100]
===
match
---
parameters [67211,67217]
parameters [67163,67169]
===
match
---
name: self [68566,68570]
name: self [68518,68522]
===
match
---
simple_stmt [51617,51637]
simple_stmt [51655,51675]
===
match
---
name: get_dagrun [35161,35171]
name: get_dagrun [35161,35171]
===
match
---
simple_stmt [805,820]
simple_stmt [805,820]
===
match
---
sync_comp_for [77179,77202]
sync_comp_for [77131,77154]
===
match
---
name: path [19038,19042]
name: path [19038,19042]
===
match
---
name: on_retry_callback [53208,53225]
name: on_retry_callback [53207,53224]
===
match
---
expr_stmt [72222,72290]
expr_stmt [72174,72242]
===
match
---
expr_stmt [29587,29647]
expr_stmt [29587,29647]
===
match
---
trailer [62386,62395]
trailer [62338,62347]
===
match
---
trailer [22000,22011]
trailer [22000,22011]
===
match
---
atom_expr [64194,64207]
atom_expr [64146,64159]
===
match
---
expr_stmt [61862,61883]
expr_stmt [61814,61835]
===
match
---
name: airflow [1620,1627]
name: airflow [1620,1627]
===
match
---
atom_expr [24790,24800]
atom_expr [24790,24800]
===
match
---
name: Optional [29201,29209]
name: Optional [29201,29209]
===
match
---
operator: , [41821,41822]
operator: , [41821,41822]
===
match
---
atom_expr [73966,73985]
atom_expr [73918,73937]
===
match
---
trailer [21849,21865]
trailer [21849,21865]
===
match
---
fstring_string: __ [62449,62451]
fstring_string: __ [62401,62403]
===
match
---
suite [47394,47548]
suite [47394,47548]
===
match
---
fstring_end: ' [45053,45054]
fstring_end: ' [45053,45054]
===
match
---
operator: == [6690,6692]
operator: == [6690,6692]
===
match
---
name: AirflowException [48560,48576]
name: AirflowException [48560,48576]
===
match
---
argument [15106,15137]
argument [15106,15137]
===
match
---
name: iso [19791,19794]
name: iso [19791,19794]
===
match
---
operator: = [55219,55220]
operator: = [55218,55219]
===
match
---
operator: , [74533,74534]
operator: , [74485,74486]
===
match
---
argument [28512,28524]
argument [28512,28524]
===
match
---
trailer [6103,6122]
trailer [6103,6122]
===
match
---
arglist [39217,39238]
arglist [39217,39238]
===
match
---
name: value [77100,77105]
name: value [77052,77057]
===
match
---
name: airflow [2242,2249]
name: airflow [2242,2249]
===
match
---
operator: , [24079,24080]
operator: , [24079,24080]
===
match
---
import_name [857,870]
import_name [857,870]
===
match
---
argument [54274,54283]
argument [54273,54282]
===
match
---
operator: == [79329,79331]
operator: == [79281,79283]
===
match
---
trailer [9711,9724]
trailer [9711,9724]
===
match
---
name: update [71535,71541]
name: update [71487,71493]
===
match
---
testlist [72396,72435]
testlist [72348,72387]
===
match
---
if_stmt [43501,43545]
if_stmt [43501,43545]
===
match
---
name: log [41235,41238]
name: log [41235,41238]
===
match
---
decorator [77979,77993]
decorator [77931,77945]
===
match
---
name: log_message [58259,58270]
name: log_message [58258,58269]
===
match
---
simple_stmt [10063,10119]
simple_stmt [10063,10119]
===
match
---
name: self [80786,80790]
name: self [80738,80742]
===
match
---
string: 'scheduler' [45872,45883]
string: 'scheduler' [45872,45883]
===
match
---
operator: -> [8647,8649]
operator: -> [8647,8649]
===
match
---
atom_expr [29675,29716]
atom_expr [29675,29716]
===
match
---
name: DeprecationWarning [30832,30850]
name: DeprecationWarning [30832,30850]
===
match
---
name: task_copy [51527,51536]
name: task_copy [51565,51574]
===
match
---
name: _handle_reschedule [44145,44163]
name: _handle_reschedule [44145,44163]
===
match
---
name: self [56010,56014]
name: self [56009,56013]
===
match
---
operator: @ [81478,81479]
operator: @ [81430,81431]
===
match
---
string: """             This attribute is deprecated.             Please use `airflow.models.taskinstance.TaskInstance.get_previous_start_date` method.             """ [30659,30818]
string: """             This attribute is deprecated.             Please use `airflow.models.taskinstance.TaskInstance.get_previous_start_date` method.             """ [30659,30818]
===
match
---
simple_stmt [41621,41631]
simple_stmt [41621,41631]
===
match
---
operator: , [63573,63574]
operator: , [63525,63526]
===
match
---
name: dag_id [60436,60442]
name: dag_id [60388,60394]
===
match
---
parameters [13937,13943]
parameters [13937,13943]
===
match
---
name: self [30903,30907]
name: self [30903,30907]
===
match
---
decorated [32327,32970]
decorated [32327,32970]
===
match
---
trailer [58622,58633]
trailer [58621,58632]
===
match
---
if_stmt [11477,12003]
if_stmt [11477,12003]
===
match
---
expr_stmt [67360,67429]
expr_stmt [67312,67381]
===
match
---
name: self [80909,80913]
name: self [80861,80865]
===
match
---
name: try_number [68622,68632]
name: try_number [68574,68584]
===
match
---
trailer [18766,18773]
trailer [18766,18773]
===
match
---
name: execution_date [73930,73944]
name: execution_date [73882,73896]
===
match
---
atom_expr [69454,69475]
atom_expr [69406,69427]
===
match
---
trailer [45097,45106]
trailer [45097,45106]
===
match
---
atom_expr [59987,59996]
atom_expr [59939,59948]
===
match
---
simple_stmt [23279,23303]
simple_stmt [23279,23303]
===
match
---
atom_expr [80357,80378]
atom_expr [80309,80330]
===
match
---
name: Integer [10083,10090]
name: Integer [10083,10090]
===
match
---
trailer [47578,47591]
trailer [47578,47591]
===
match
---
expr_stmt [80051,80088]
expr_stmt [80003,80040]
===
match
---
name: pool [16032,16036]
name: pool [16032,16036]
===
match
---
name: utcnow [55372,55378]
name: utcnow [55371,55377]
===
match
---
name: construct_pod [68452,68465]
name: construct_pod [68404,68417]
===
match
---
except_clause [66735,66787]
except_clause [66687,66739]
===
match
---
fstring_string: .duration [48829,48838]
fstring_string: .duration [48829,48838]
===
match
---
name: _queue [80512,80518]
name: _queue [80464,80470]
===
match
---
trailer [40885,40889]
trailer [40885,40889]
===
match
---
trailer [69145,69150]
trailer [69097,69102]
===
match
---
name: Index [10871,10876]
name: Index [10871,10876]
===
match
---
name: ti [5177,5179]
name: ti [5177,5179]
===
match
---
trailer [9656,9687]
trailer [9656,9687]
===
match
---
operator: + [34865,34866]
operator: + [34865,34866]
===
match
---
simple_stmt [47479,47548]
simple_stmt [47479,47548]
===
match
---
string: "--subdir" [18775,18785]
string: "--subdir" [18775,18785]
===
match
---
atom_expr [5490,5516]
atom_expr [5490,5516]
===
match
---
simple_stmt [21518,21577]
simple_stmt [21518,21577]
===
match
---
funcdef [19180,19443]
funcdef [19180,19443]
===
match
---
name: pid [22812,22815]
name: pid [22812,22815]
===
match
---
trailer [77169,77178]
trailer [77121,77130]
===
match
---
operator: @ [18893,18894]
operator: @ [18893,18894]
===
match
---
name: conf [68040,68044]
name: conf [67992,67996]
===
match
---
comparison [26399,26437]
comparison [26399,26437]
===
match
---
name: context [53103,53110]
name: context [53102,53109]
===
match
---
name: task_type [50681,50690]
name: task_type [50719,50728]
===
match
---
operator: = [54398,54399]
operator: = [54397,54398]
===
match
---
comparison [24910,24942]
comparison [24910,24942]
===
match
---
name: self [79894,79898]
name: self [79846,79850]
===
match
---
param [63215,63219]
param [63167,63171]
===
match
---
name: self [25388,25392]
name: self [25388,25392]
===
match
---
atom_expr [80507,80518]
atom_expr [80459,80470]
===
match
---
suite [14848,14886]
suite [14848,14886]
===
match
---
sync_comp_for [49372,49412]
sync_comp_for [49372,49412]
===
match
---
name: cfg_path [18858,18866]
name: cfg_path [18858,18866]
===
match
---
name: self [21712,21716]
name: self [21712,21716]
===
match
---
atom_expr [26561,26585]
atom_expr [26561,26585]
===
match
---
trailer [62015,62023]
trailer [61967,61975]
===
match
---
name: DeprecationWarning [28480,28498]
name: DeprecationWarning [28480,28498]
===
match
---
name: id [7440,7442]
name: id [7440,7442]
===
match
---
operator: = [59363,59364]
operator: = [59315,59316]
===
match
---
name: list [78336,78340]
name: list [78288,78292]
===
match
---
name: self [70905,70909]
name: self [70857,70861]
===
match
---
parameters [30429,30435]
parameters [30429,30435]
===
match
---
argument [71124,71139]
argument [71076,71091]
===
match
---
atom_expr [20867,20922]
atom_expr [20867,20922]
===
match
---
name: self [30172,30176]
name: self [30172,30176]
===
match
---
atom_expr [8577,8592]
atom_expr [8577,8592]
===
match
---
expr_stmt [59693,59732]
expr_stmt [59645,59684]
===
match
---
name: session [40455,40462]
name: session [40455,40462]
===
match
---
trailer [76990,76998]
trailer [76942,76950]
===
match
---
trailer [7721,7725]
trailer [7721,7725]
===
match
---
name: self [80004,80008]
name: self [79956,79960]
===
match
---
atom_expr [11316,11344]
atom_expr [11316,11344]
===
match
---
arglist [45872,45931]
arglist [45872,45931]
===
match
---
name: overwrite_params_with_dag_run_conf [67757,67791]
name: overwrite_params_with_dag_run_conf [67709,67743]
===
match
---
suite [21828,21876]
suite [21828,21876]
===
match
---
suite [19489,19869]
suite [19489,19869]
===
match
---
simple_stmt [22633,22655]
simple_stmt [22633,22655]
===
match
---
operator: , [28986,28987]
operator: , [28986,28987]
===
match
---
argument [48975,48997]
argument [48975,48997]
===
match
---
operator: , [10734,10735]
operator: , [10734,10735]
===
match
---
name: _dag_id [82128,82135]
name: _dag_id [82080,82087]
===
match
---
string: """         Construct a TaskInstance from the database based on the primary key          :param session: DB session.         :param lock_for_update: if True, indicates that the database should             lock the TaskInstance (issuing a FOR UPDATE clause) until the             session is committed.         :return: the task instance constructed         """ [81678,82037]
string: """         Construct a TaskInstance from the database based on the primary key          :param session: DB session.         :param lock_for_update: if True, indicates that the database should             lock the TaskInstance (issuing a FOR UPDATE clause) until the             session is committed.         :return: the task instance constructed         """ [81630,81989]
===
match
---
name: task [11827,11831]
name: task [11827,11831]
===
match
---
expr_stmt [33665,33747]
expr_stmt [33665,33747]
===
match
---
name: actual_start_date [44164,44181]
name: actual_start_date [44164,44181]
===
match
---
if_stmt [60201,60268]
if_stmt [60153,60220]
===
match
---
trailer [37832,37840]
trailer [37832,37840]
===
match
---
trailer [40661,40672]
trailer [40661,40672]
===
match
---
operator: , [15767,15768]
operator: , [15767,15768]
===
match
---
suite [28131,28574]
suite [28131,28574]
===
match
---
name: warn [28297,28301]
name: warn [28297,28301]
===
match
---
operator: , [18670,18671]
operator: , [18670,18671]
===
match
---
name: self [11353,11357]
name: self [11353,11357]
===
match
---
raise_stmt [48554,48608]
raise_stmt [48554,48608]
===
match
---
argument [76548,76555]
argument [76500,76507]
===
match
---
name: exception [50168,50177]
name: warning [50025,50032]
===
match
---
name: pickler [10368,10375]
name: pickler [10368,10375]
===
match
---
operator: = [9994,9995]
operator: = [9994,9995]
===
match
---
trailer [9939,9945]
trailer [9939,9945]
===
match
---
name: DepContext [38220,38230]
name: DepContext [38220,38230]
===
match
---
operator: -> [80881,80883]
operator: -> [80833,80835]
===
match
---
operator: , [56502,56503]
operator: , [56501,56502]
===
match
---
trailer [69504,69515]
trailer [69456,69467]
===
match
---
name: self [62610,62614]
name: self [62562,62566]
===
match
---
string: "Failed when executing execute callback" [52266,52306]
string: "Failed when executing execute callback" [52301,52341]
===
match
---
trailer [40406,40418]
trailer [40406,40418]
===
match
---
name: autoescape [71124,71134]
name: autoescape [71076,71086]
===
match
---
trailer [33891,34010]
trailer [33891,34010]
===
match
---
operator: = [60721,60722]
operator: = [60673,60674]
===
match
---
string: '%Y%m%dT%H%M%S' [58706,58721]
string: '%Y%m%dT%H%M%S' [58705,58720]
===
match
---
atom_expr [48560,48608]
atom_expr [48560,48608]
===
match
---
name: relationship [1436,1448]
name: relationship [1436,1448]
===
match
---
name: utcnow [24702,24708]
name: utcnow [24702,24708]
===
match
---
decorated [28095,28574]
decorated [28095,28574]
===
match
---
name: session [39927,39934]
name: session [39927,39934]
===
match
---
name: property [80932,80940]
name: property [80884,80892]
===
match
---
suite [27872,27956]
suite [27872,27956]
===
match
---
name: State [65361,65366]
name: State [65313,65318]
===
match
---
param [21056,21061]
param [21056,21061]
===
match
---
arglist [6772,7027]
arglist [6772,7027]
===
match
---
trailer [44675,44682]
trailer [44675,44682]
===
match
---
atom_expr [53354,53385]
atom_expr [53353,53384]
===
match
---
name: job_id [54247,54253]
name: job_id [54246,54252]
===
match
---
name: test_mode [37595,37604]
name: test_mode [37595,37604]
===
match
---
operator: + [5606,5607]
operator: + [5606,5607]
===
match
---
name: job_id [54567,54573]
name: job_id [54566,54572]
===
match
---
tfpdef [15926,15950]
tfpdef [15926,15950]
===
match
---
string: '-' [62252,62255]
string: '-' [62204,62207]
===
match
---
name: self [41389,41393]
name: self [41389,41393]
===
match
---
arglist [47932,48031]
arglist [47932,48031]
===
match
---
atom_expr [43651,44025]
atom_expr [43651,44025]
===
match
---
simple_stmt [56949,56969]
simple_stmt [56948,56968]
===
match
---
operator: -> [28623,28625]
operator: -> [28623,28625]
===
match
---
name: models [2069,2075]
name: models [2069,2075]
===
match
---
expr_stmt [19025,19093]
expr_stmt [19025,19093]
===
match
---
name: str [15946,15949]
name: str [15946,15949]
===
match
---
name: hostname [22455,22463]
name: hostname [22455,22463]
===
match
---
operator: , [57133,57134]
operator: , [57132,57133]
===
match
---
trailer [61739,61747]
trailer [61691,61699]
===
match
---
simple_stmt [44105,44128]
simple_stmt [44105,44128]
===
match
---
trailer [21619,21626]
trailer [21619,21626]
===
match
---
name: self [24878,24882]
name: self [24878,24882]
===
match
---
operator: , [56138,56139]
operator: , [56137,56138]
===
match
---
operator: , [41921,41922]
operator: , [41921,41922]
===
match
---
atom [17992,18041]
atom [17992,18041]
===
match
---
operator: , [40829,40830]
operator: , [40829,40830]
===
match
---
operator: = [14270,14271]
operator: = [14270,14271]
===
match
---
name: base [1833,1837]
name: base [1833,1837]
===
match
---
name: expunge_all [60612,60623]
name: expunge_all [60564,60575]
===
match
---
trailer [45315,45323]
trailer [45315,45323]
===
match
---
name: str [56283,56286]
name: str [56282,56285]
===
match
---
operator: = [39604,39605]
operator: = [39604,39605]
===
match
---
param [8178,8182]
param [8178,8182]
===
match
---
name: error [52828,52833]
name: error [52827,52832]
===
match
---
name: STATICA_HACK [82473,82485]
name: STATICA_HACK [82425,82437]
===
match
---
simple_stmt [40846,40873]
simple_stmt [40846,40873]
===
match
---
name: provide_session [41637,41652]
name: provide_session [41637,41652]
===
match
---
name: get_rendered_k8s_spec [67190,67211]
name: get_rendered_k8s_spec [67142,67163]
===
match
---
operator: == [52908,52910]
operator: == [52907,52909]
===
match
---
name: downstream_task_ids [46722,46741]
name: downstream_task_ids [46722,46741]
===
match
---
operator: @ [15493,15494]
operator: @ [15493,15494]
===
match
---
atom_expr [63245,63258]
atom_expr [63197,63210]
===
match
---
name: min [34798,34801]
name: min [34798,34801]
===
match
---
trailer [72895,72906]
trailer [72847,72858]
===
match
---
string: "Task received SIGTERM signal" [48577,48607]
string: "Task received SIGTERM signal" [48577,48607]
===
match
---
name: one [46355,46358]
name: one [46355,46358]
===
match
---
operator: , [7752,7753]
operator: , [7752,7753]
===
match
---
atom_expr [82123,82135]
atom_expr [82075,82087]
===
match
---
operator: , [24337,24338]
operator: , [24337,24338]
===
match
---
trailer [42762,42778]
trailer [42762,42778]
===
match
---
name: Variable [64369,64377]
name: Variable [64321,64329]
===
match
---
expr_stmt [31780,31847]
expr_stmt [31780,31847]
===
match
---
name: dag_id [76577,76583]
name: dag_id [76529,76535]
===
match
---
simple_stmt [61483,61554]
simple_stmt [61435,61506]
===
match
---
operator: = [31719,31720]
operator: = [31719,31720]
===
match
---
arith_expr [13998,14018]
arith_expr [13998,14018]
===
match
---
atom_expr [22737,22748]
atom_expr [22737,22748]
===
match
---
name: self [58528,58532]
name: self [58527,58531]
===
match
---
trailer [54637,54642]
trailer [54636,54641]
===
match
---
name: self [27301,27305]
name: self [27301,27305]
===
match
---
atom_expr [80133,80154]
atom_expr [80085,80106]
===
match
---
operator: , [7026,7027]
operator: , [7026,7027]
===
match
---
atom_expr [11732,11751]
atom_expr [11732,11751]
===
match
---
name: execution_date [33062,33076]
name: execution_date [33062,33076]
===
match
---
name: has_option [71904,71914]
name: has_option [71856,71866]
===
match
---
atom_expr [33333,33354]
atom_expr [33333,33354]
===
match
---
string: '%Y%m%dT%H%M%S' [62196,62211]
string: '%Y%m%dT%H%M%S' [62148,62163]
===
match
---
suite [14742,14792]
suite [14742,14792]
===
match
---
simple_stmt [2490,2547]
simple_stmt [2490,2547]
===
match
---
operator: = [53495,53496]
operator: = [53494,53495]
===
match
---
operator: = [32393,32394]
operator: = [32393,32394]
===
match
---
expr_stmt [55347,55380]
expr_stmt [55346,55379]
===
match
---
parameters [50793,50813]
parameters [50831,50851]
===
match
---
fstring_end: " [33093,33094]
fstring_end: " [33093,33094]
===
match
---
name: first [82331,82336]
name: first [82283,82288]
===
match
---
name: warning [40016,40023]
name: warning [40016,40023]
===
match
---
name: Tuple [8187,8192]
name: Tuple [8187,8192]
===
match
---
decorated [63272,63600]
decorated [63224,63552]
===
match
---
name: next_execution_date [61662,61681]
name: next_execution_date [61614,61633]
===
match
---
name: var [63254,63257]
name: var [63206,63209]
===
match
---
operator: = [15951,15952]
operator: = [15951,15952]
===
match
---
name: execute [51537,51544]
name: execute [51575,51582]
===
match
---
name: prev_ds [61928,61935]
name: prev_ds [61880,61887]
===
match
---
arglist [40628,40692]
arglist [40628,40692]
===
match
---
suite [59684,59822]
suite [59636,59774]
===
match
---
atom_expr [78780,78799]
atom_expr [78732,78751]
===
match
---
name: task [55513,55517]
name: task [55512,55516]
===
match
---
if_stmt [41550,41613]
if_stmt [41550,41613]
===
match
---
trailer [3745,3753]
trailer [3745,3753]
===
match
---
name: utcnow [56932,56938]
name: utcnow [56931,56937]
===
match
---
simple_stmt [81678,82038]
simple_stmt [81630,81990]
===
match
---
name: Column [1283,1289]
name: Column [1283,1289]
===
match
---
simple_stmt [40971,40991]
simple_stmt [40971,40991]
===
match
---
import_from [2443,2489]
import_from [2443,2489]
===
match
---
name: self [80705,80709]
name: self [80657,80661]
===
match
---
name: start_date [39067,39077]
name: start_date [39067,39077]
===
match
---
argument [11078,11092]
argument [11078,11092]
===
match
---
trailer [37629,37645]
trailer [37629,37645]
===
match
---
name: cmd [18216,18219]
name: cmd [18216,18219]
===
match
---
atom_expr [18144,18184]
atom_expr [18144,18184]
===
match
---
if_stmt [82470,82702]
if_stmt [82422,82654]
===
match
---
simple_stmt [18144,18185]
simple_stmt [18144,18185]
===
match
---
trailer [6836,7026]
trailer [6836,7026]
===
match
---
funcdef [26464,28090]
funcdef [26464,28090]
===
match
---
suite [5187,6154]
suite [5187,6154]
===
match
---
name: self [56907,56911]
name: self [56906,56910]
===
match
---
funcdef [80621,80674]
funcdef [80573,80626]
===
match
---
name: merge [20973,20978]
name: merge [20973,20978]
===
match
---
operator: == [78800,78802]
operator: == [78752,78754]
===
match
---
trailer [40590,40605]
trailer [40590,40605]
===
match
---
trailer [73045,73049]
trailer [72997,73001]
===
match
---
param [55210,55226]
param [55209,55225]
===
match
---
trailer [59342,59357]
trailer [59294,59309]
===
match
---
name: execution_date [60784,60798]
name: execution_date [60736,60750]
===
match
---
operator: , [15395,15396]
operator: , [15395,15396]
===
match
---
operator: , [74162,74163]
operator: , [74114,74115]
===
match
---
param [12702,12706]
param [12702,12706]
===
match
---
param [48150,48154]
param [48150,48154]
===
match
---
operator: , [18002,18003]
operator: , [18002,18003]
===
match
---
name: execution_date [20465,20479]
name: execution_date [20465,20479]
===
match
---
name: try_number [80078,80088]
name: try_number [80030,80040]
===
match
---
name: XCom [74203,74207]
name: XCom [74155,74159]
===
match
---
simple_stmt [37590,37617]
simple_stmt [37590,37617]
===
match
---
name: _priority_weight [81308,81324]
name: _priority_weight [81260,81276]
===
match
---
operator: , [1044,1045]
operator: , [1044,1045]
===
match
---
operator: , [8568,8569]
operator: , [8568,8569]
===
match
---
name: test_mode [45653,45662]
name: test_mode [45653,45662]
===
match
---
trailer [52854,52874]
trailer [52853,52873]
===
match
---
suite [54707,54877]
suite [54706,54876]
===
match
---
name: _start_date [79958,79969]
name: _start_date [79910,79921]
===
match
---
suite [12530,12668]
suite [12530,12668]
===
match
---
name: self [70956,70960]
name: self [70908,70912]
===
match
---
atom_expr [44640,44650]
atom_expr [44640,44650]
===
match
---
arglist [57121,57139]
arglist [57120,57138]
===
match
---
name: airflow [60010,60017]
name: airflow [59962,59969]
===
match
---
arglist [22893,22926]
arglist [22893,22926]
===
match
---
atom_expr [57925,57935]
atom_expr [57924,57934]
===
match
---
name: DateTime [29866,29874]
name: DateTime [29866,29874]
===
match
---
name: self [20667,20671]
name: self [20667,20671]
===
match
---
name: open [4408,4412]
name: open [4408,4412]
===
match
---
suite [38659,38722]
suite [38659,38722]
===
match
---
trailer [50713,50718]
trailer [50751,50756]
===
match
---
name: State [54750,54755]
name: State [54749,54754]
===
match
---
name: self [59440,59444]
name: self [59392,59396]
===
match
---
trailer [24090,24097]
trailer [24090,24097]
===
match
---
name: str [64017,64020]
name: str [63969,63972]
===
match
---
operator: = [7961,7962]
operator: = [7961,7962]
===
match
---
trailer [10876,10897]
trailer [10876,10897]
===
match
---
name: self [73147,73151]
name: self [73099,73103]
===
match
---
name: self [8794,8798]
name: self [8794,8798]
===
match
---
string: 'prev_ds_nodash' [65140,65156]
string: 'prev_ds_nodash' [65092,65108]
===
match
---
operator: , [54573,54574]
operator: , [54572,54573]
===
match
---
trailer [7115,7117]
trailer [7115,7117]
===
match
---
name: Log [45556,45559]
name: Log [45556,45559]
===
match
---
operator: = [17949,17950]
operator: = [17949,17950]
===
match
---
atom_expr [41276,41285]
atom_expr [41276,41285]
===
match
---
fstring_expr [14776,14790]
fstring_expr [14776,14790]
===
match
---
atom_expr [10744,10805]
atom_expr [10744,10805]
===
match
---
trailer [40267,40278]
trailer [40267,40278]
===
match
---
trailer [68570,68577]
trailer [68522,68529]
===
match
---
suite [5225,5336]
suite [5225,5336]
===
match
---
comparison [20429,20479]
comparison [20429,20479]
===
match
---
param [71865,71869]
param [71817,71821]
===
match
---
trailer [24343,24351]
trailer [24343,24351]
===
match
---
trailer [21000,21007]
trailer [21000,21007]
===
match
---
trailer [16046,16051]
trailer [16046,16051]
===
match
---
if_stmt [13149,13217]
if_stmt [13149,13217]
===
match
---
test [31803,31847]
test [31803,31847]
===
match
---
simple_stmt [847,857]
simple_stmt [847,857]
===
match
---
not_test [37789,37808]
not_test [37789,37808]
===
match
---
operator: @ [24174,24175]
operator: @ [24174,24175]
===
match
---
name: ti [20535,20537]
name: ti [20535,20537]
===
match
---
name: ds_nodash [62115,62124]
name: ds_nodash [62067,62076]
===
match
---
atom_expr [30632,30887]
atom_expr [30632,30887]
===
match
---
name: self [68072,68076]
name: self [68024,68028]
===
match
---
name: items [7110,7115]
name: items [7110,7115]
===
match
---
string: 'macros' [64877,64885]
string: 'macros' [64829,64837]
===
match
---
arglist [50649,50698]
arglist [50687,50736]
===
match
---
fstring_expr [33079,33091]
fstring_expr [33079,33091]
===
match
---
operator: , [55208,55209]
operator: , [55207,55208]
===
match
---
suite [81447,81473]
suite [81399,81425]
===
match
---
atom_expr [74370,74389]
atom_expr [74322,74341]
===
match
---
operator: = [71955,71956]
operator: = [71907,71908]
===
match
---
simple_stmt [12391,12408]
simple_stmt [12391,12408]
===
match
---
operator: , [10683,10684]
operator: , [10683,10684]
===
match
---
suite [58080,58137]
suite [58079,58136]
===
match
---
operator: = [36094,36095]
operator: = [36094,36095]
===
match
---
simple_stmt [68364,68390]
simple_stmt [68316,68342]
===
match
---
operator: = [46930,46931]
operator: = [46930,46931]
===
match
---
trailer [21652,21659]
trailer [21652,21659]
===
match
---
name: job_id [42809,42815]
name: job_id [42809,42815]
===
match
---
string: 'end_date' [45455,45465]
string: 'end_date' [45455,45465]
===
match
---
name: task_id [47166,47173]
name: task_id [47166,47173]
===
match
---
name: incr [56983,56987]
name: incr [56982,56986]
===
match
---
name: task [11235,11239]
name: task [11235,11239]
===
match
---
name: task_id [15600,15607]
name: task_id [15600,15607]
===
match
---
name: session [27846,27853]
name: session [27846,27853]
===
match
---
name: self [37693,37697]
name: self [37693,37697]
===
match
---
expr_stmt [79854,79885]
expr_stmt [79806,79837]
===
match
---
name: pool_slots [23363,23373]
name: pool_slots [23363,23373]
===
match
---
operator: = [77936,77937]
operator: = [77888,77889]
===
match
---
decorator [30958,30975]
decorator [30958,30975]
===
match
---
name: yesterday_ds_nodash [66159,66178]
name: yesterday_ds_nodash [66111,66130]
===
match
---
name: self [31874,31878]
name: self [31874,31878]
===
match
---
trailer [47429,47453]
trailer [47429,47453]
===
match
---
name: pool_override [37562,37575]
name: pool_override [37562,37575]
===
match
---
classdef [63609,64597]
classdef [63561,64549]
===
match
---
simple_stmt [45544,45579]
simple_stmt [45544,45579]
===
match
---
name: kubernetes [3109,3119]
name: kubernetes [3109,3119]
===
match
---
atom_expr [63420,63459]
atom_expr [63372,63411]
===
match
---
atom_expr [9996,10011]
atom_expr [9996,10011]
===
match
---
atom_expr [45556,45577]
atom_expr [45556,45577]
===
match
---
string: 'Rescheduling task, marking task as UP_FOR_RESCHEDULE' [56024,56078]
string: 'Rescheduling task, marking task as UP_FOR_RESCHEDULE' [56023,56077]
===
match
---
atom_expr [47422,47453]
atom_expr [47422,47453]
===
match
---
trailer [66018,66020]
trailer [65970,65972]
===
match
---
trailer [74621,74626]
trailer [74573,74578]
===
match
---
dotted_name [2966,2996]
dotted_name [2966,2996]
===
match
---
atom_expr [42849,42863]
atom_expr [42849,42863]
===
match
---
name: Any [74756,74759]
name: Any [74708,74711]
===
match
---
operator: = [15307,15308]
operator: = [15307,15308]
===
match
---
comparison [53203,53237]
comparison [53202,53236]
===
match
---
trailer [43069,43071]
trailer [43069,43071]
===
match
---
name: AirflowException [44431,44447]
name: AirflowException [44431,44447]
===
match
---
atom_expr [65322,65375]
atom_expr [65274,65327]
===
match
---
atom_expr [54836,54876]
atom_expr [54835,54875]
===
match
---
name: start_date [25052,25062]
name: start_date [25052,25062]
===
match
---
arglist [14983,15477]
arglist [14983,15477]
===
match
---
name: or_ [1346,1349]
name: or_ [1346,1349]
===
match
---
simple_stmt [42919,42972]
simple_stmt [42919,42972]
===
match
---
name: Iterable [74573,74581]
name: Iterable [74525,74533]
===
match
---
trailer [56160,56176]
trailer [56159,56175]
===
match
---
name: String [10211,10217]
name: String [10211,10217]
===
match
---
name: item [64011,64015]
name: item [63963,63967]
===
match
---
operator: , [14359,14360]
operator: , [14359,14360]
===
match
---
operator: = [31021,31022]
operator: = [31021,31022]
===
match
---
simple_stmt [26367,26384]
simple_stmt [26367,26384]
===
match
---
atom_expr [43979,44010]
atom_expr [43979,44010]
===
match
---
atom_expr [53752,53765]
atom_expr [53751,53764]
===
match
---
sync_comp_for [79019,79031]
sync_comp_for [78971,78983]
===
match
---
name: ti_key_str [65672,65682]
name: ti_key_str [65624,65634]
===
match
---
trailer [22637,22643]
trailer [22637,22643]
===
match
---
operator: , [3877,3878]
operator: , [3877,3878]
===
match
---
expr_stmt [79894,79944]
expr_stmt [79846,79896]
===
match
---
funcdef [21036,22928]
funcdef [21036,22928]
===
match
---
trailer [7442,7446]
trailer [7442,7446]
===
match
---
trailer [32533,32538]
trailer [32533,32538]
===
match
---
atom_expr [56010,56079]
atom_expr [56009,56078]
===
match
---
name: self [54736,54740]
name: self [54735,54739]
===
match
---
name: _key [80548,80552]
name: _key [80500,80504]
===
match
---
tfpdef [59225,59250]
tfpdef [59177,59202]
===
match
---
name: self [80734,80738]
name: self [80686,80690]
===
match
---
name: ignore_task_deps [54100,54116]
name: ignore_task_deps [54099,54115]
===
match
---
trailer [79087,79094]
trailer [79039,79046]
===
match
---
name: execution_date [61360,61374]
name: execution_date [61312,61326]
===
match
---
name: pickle_id [14654,14663]
name: pickle_id [14654,14663]
===
match
---
string: 'execution_date' [58570,58586]
string: 'execution_date' [58569,58585]
===
match
---
simple_stmt [49805,49824]
simple_stmt [49805,49824]
===
match
---
operator: , [39621,39622]
operator: , [39621,39622]
===
match
---
simple_stmt [3742,3925]
simple_stmt [3742,3925]
===
match
---
operator: = [62656,62657]
operator: = [62608,62609]
===
match
---
funcdef [80945,81007]
funcdef [80897,80959]
===
match
---
simple_stmt [48165,48198]
simple_stmt [48165,48198]
===
match
---
string: 'var' [65965,65970]
string: 'var' [65917,65922]
===
match
---
trailer [30645,30887]
trailer [30645,30887]
===
match
---
name: try_number [59613,59623]
name: try_number [59565,59575]
===
match
---
atom_expr [35061,35079]
atom_expr [35061,35079]
===
match
---
trailer [47591,47608]
trailer [47591,47608]
===
match
---
name: _try_number [81075,81086]
name: _try_number [81027,81038]
===
match
---
name: self [22308,22312]
name: self [22308,22312]
===
match
---
name: self [43044,43048]
name: self [43044,43048]
===
match
---
atom_expr [61355,61374]
atom_expr [61307,61326]
===
match
---
expr_stmt [27791,27854]
expr_stmt [27791,27854]
===
match
---
trailer [60903,60915]
trailer [60855,60867]
===
match
---
name: self [11291,11295]
name: self [11291,11295]
===
match
---
name: Optional [68340,68348]
name: Optional [68292,68300]
===
match
---
trailer [3753,3924]
trailer [3753,3924]
===
match
---
name: count [26367,26372]
name: count [26367,26372]
===
match
---
operator: = [6639,6640]
operator: = [6639,6640]
===
match
---
operator: , [14095,14096]
operator: , [14095,14096]
===
match
---
atom_expr [55776,55799]
atom_expr [55775,55798]
===
match
---
name: executor_config [10332,10347]
name: executor_config [10332,10347]
===
match
---
name: dag_run [46967,46974]
name: dag_run [46967,46974]
===
match
---
operator: , [8317,8318]
operator: , [8317,8318]
===
match
---
trailer [24839,24850]
trailer [24839,24850]
===
match
---
trailer [61532,61553]
trailer [61484,61505]
===
match
---
suite [78738,78954]
suite [78690,78906]
===
match
---
operator: = [70955,70956]
operator: = [70907,70908]
===
match
---
string: "rendering of template_fields." [67124,67155]
string: "rendering of template_fields." [67076,67107]
===
match
---
suite [63636,64597]
suite [63588,64549]
===
match
---
parameters [63971,64035]
parameters [63923,63987]
===
match
---
string: 'webserver' [19319,19330]
string: 'webserver' [19319,19330]
===
match
---
operator: == [78706,78708]
operator: == [78658,78660]
===
match
---
operator: , [65064,65065]
operator: , [65016,65017]
===
match
---
trailer [49038,49057]
trailer [49038,49057]
===
match
---
expr_stmt [58149,58188]
expr_stmt [58148,58187]
===
match
---
name: dag_id [79322,79328]
name: dag_id [79274,79280]
===
match
---
name: self [52945,52949]
name: self [52944,52948]
===
match
---
name: should_pass_filepath [14805,14825]
name: should_pass_filepath [14805,14825]
===
match
---
simple_stmt [9764,9789]
simple_stmt [9764,9789]
===
match
---
not_test [43000,43016]
not_test [43000,43016]
===
match
---
simple_stmt [63173,63189]
simple_stmt [63125,63141]
===
match
---
simple_stmt [53855,53878]
simple_stmt [53854,53877]
===
match
---
fstring_expr [33056,33077]
fstring_expr [33056,33077]
===
match
---
name: self [35510,35514]
name: self [35510,35514]
===
match
---
argument [68731,68758]
argument [68683,68710]
===
match
---
suite [27226,27259]
suite [27226,27259]
===
match
---
if_stmt [42997,43149]
if_stmt [42997,43149]
===
match
---
name: SUCCESS [26338,26345]
name: SUCCESS [26338,26345]
===
match
---
argument [39894,39917]
argument [39894,39917]
===
match
---
operator: , [64722,64723]
operator: , [64674,64675]
===
match
---
operator: @ [59827,59828]
operator: @ [59779,59780]
===
match
---
name: all [78965,78968]
name: all [78917,78920]
===
match
---
name: signal [48625,48631]
name: signal [48625,48631]
===
match
---
funcdef [77416,77839]
funcdef [77368,77791]
===
match
---
name: get_hostname [2577,2589]
name: get_hostname [2577,2589]
===
match
---
name: e [44344,44345]
name: e [44344,44345]
===
match
---
trailer [61808,61829]
trailer [61760,61781]
===
match
---
atom_expr [27158,27177]
atom_expr [27158,27177]
===
match
---
annassign [8116,8126]
annassign [8116,8126]
===
match
---
simple_stmt [31985,32190]
simple_stmt [31985,32190]
===
match
---
string: 'utf-8' [34018,34025]
string: 'utf-8' [34018,34025]
===
match
---
name: lazy_object_proxy [1168,1185]
name: lazy_object_proxy [1168,1185]
===
match
---
atom_expr [23458,23474]
atom_expr [23458,23474]
===
match
---
argument [10368,10380]
argument [10368,10380]
===
match
---
param [36051,36078]
param [36051,36078]
===
match
---
arglist [10030,10057]
arglist [10030,10057]
===
match
---
suite [29876,30379]
suite [29876,30379]
===
match
---
if_stmt [76404,76456]
if_stmt [76356,76408]
===
match
---
name: get_template_context [71485,71505]
name: get_template_context [71437,71457]
===
match
---
not_test [27198,27225]
not_test [27198,27225]
===
match
---
name: task_ids [6970,6978]
name: task_ids [6970,6978]
===
match
---
name: log_message [58097,58108]
name: log_message [58096,58107]
===
match
---
operator: , [80422,80423]
operator: , [80374,80375]
===
match
---
name: state [26306,26311]
name: state [26306,26311]
===
match
---
tfpdef [74605,74626]
tfpdef [74557,74578]
===
match
---
argument [10103,10117]
argument [10103,10117]
===
match
---
decorator [81162,81172]
decorator [81114,81124]
===
match
---
name: retries [23524,23531]
name: retries [23524,23531]
===
match
---
dotted_name [1399,1413]
dotted_name [1399,1413]
===
match
---
trailer [45490,45503]
trailer [45490,45503]
===
match
---
operator: = [77155,77156]
operator: = [77107,77108]
===
match
---
name: jinja_env [71266,71275]
name: jinja_env [71218,71227]
===
match
---
return_stmt [25340,25410]
return_stmt [25340,25410]
===
match
---
trailer [11741,11749]
trailer [11741,11749]
===
match
---
name: dict [70776,70780]
name: dict [70728,70732]
===
match
---
trailer [26315,26347]
trailer [26315,26347]
===
match
---
decorator [73103,73120]
decorator [73055,73072]
===
match
---
name: pool [22557,22561]
name: pool [22557,22561]
===
match
---
argument [71065,71122]
argument [71017,71074]
===
match
---
name: session [47724,47731]
name: session [47724,47731]
===
match
---
name: expected_state [3652,3666]
name: expected_state [3652,3666]
===
match
---
name: property [19167,19175]
name: property [19167,19175]
===
match
---
name: prev_ds [62008,62015]
name: prev_ds [61960,61967]
===
match
---
operator: = [22054,22055]
operator: = [22054,22055]
===
match
---
atom_expr [45591,45610]
atom_expr [45591,45610]
===
match
---
name: post_execute [50584,50596]
name: post_execute [50622,50634]
===
match
---
name: error_file [41867,41877]
name: error_file [41867,41877]
===
match
---
operator: = [60084,60085]
operator: = [60036,60037]
===
match
---
expr_stmt [26880,26917]
expr_stmt [26880,26917]
===
match
---
dictorsetmaker [7797,7828]
dictorsetmaker [7797,7828]
===
match
---
trailer [71197,71214]
trailer [71149,71166]
===
match
---
param [80786,80790]
param [80738,80742]
===
match
---
operator: , [20671,20672]
operator: , [20671,20672]
===
match
---
name: max_tries [5969,5978]
name: max_tries [5969,5978]
===
match
---
simple_stmt [4120,4132]
simple_stmt [4120,4132]
===
match
---
name: Stats [50708,50713]
name: Stats [50746,50751]
===
match
---
expr_stmt [52751,52788]
expr_stmt [52750,52787]
===
match
---
name: dag_run [62673,62680]
name: dag_run [62625,62632]
===
match
---
name: hasattr [80240,80247]
name: hasattr [80192,80199]
===
match
---
name: result [50614,50620]
name: result [50652,50658]
===
match
---
number: 0 [26381,26382]
number: 0 [26381,26382]
===
match
---
simple_stmt [11291,11308]
simple_stmt [11291,11308]
===
match
---
simple_stmt [59812,59822]
simple_stmt [59764,59774]
===
match
---
operator: , [71868,71869]
operator: , [71820,71821]
===
match
---
name: session [28052,28059]
name: session [28052,28059]
===
match
---
operator: == [82170,82172]
operator: == [82122,82124]
===
match
---
name: ti [22133,22135]
name: ti [22133,22135]
===
match
---
string: 'subject_template' [72173,72191]
string: 'subject_template' [72125,72143]
===
match
---
name: session [39223,39230]
name: session [39223,39230]
===
match
---
operator: , [40655,40656]
operator: , [40655,40656]
===
match
---
parameters [31003,31056]
parameters [31003,31056]
===
match
---
parameters [77450,77465]
parameters [77402,77417]
===
match
---
trailer [10002,10011]
trailer [10002,10011]
===
match
---
trailer [19318,19343]
trailer [19318,19343]
===
match
---
name: AirflowSkipException [1732,1752]
name: AirflowSkipException [1732,1752]
===
match
---
atom_expr [77756,77774]
atom_expr [77708,77726]
===
match
---
name: UP_FOR_RETRY [35067,35079]
name: UP_FOR_RETRY [35067,35079]
===
match
---
argument [6658,7206]
argument [6658,7206]
===
match
---
dotted_name [2176,2190]
dotted_name [2176,2190]
===
match
---
name: dr [7947,7949]
name: dr [7947,7949]
===
match
---
operator: , [81614,81615]
operator: , [81566,81567]
===
match
---
param [11118,11123]
param [11118,11123]
===
match
---
name: task [56882,56886]
name: task [56881,56885]
===
match
---
simple_stmt [71521,71787]
simple_stmt [71473,71739]
===
match
---
atom_expr [33930,33942]
atom_expr [33930,33942]
===
match
---
operator: , [38496,38497]
operator: , [38496,38497]
===
match
---
string: "Recording the task instance as FAILED" [20882,20921]
string: "Recording the task instance as FAILED" [20882,20921]
===
match
---
testlist_comp [67564,67602]
testlist_comp [67516,67554]
===
match
---
atom_expr [72056,72064]
atom_expr [72008,72016]
===
match
---
name: IO [1037,1039]
name: IO [1037,1039]
===
match
---
suite [19940,20631]
suite [19940,20631]
===
match
---
operator: , [11016,11017]
operator: , [11016,11017]
===
match
---
tfpdef [35178,35194]
tfpdef [35178,35194]
===
match
---
string: 'TaskInstanceKey' [8379,8396]
string: 'TaskInstanceKey' [8379,8396]
===
match
---
trailer [4057,4073]
trailer [4057,4073]
===
match
---
name: params [62650,62656]
name: params [62602,62608]
===
match
---
name: ValueError [74005,74015]
name: ValueError [73957,73967]
===
match
---
operator: , [19072,19073]
operator: , [19072,19073]
===
match
---
argument [15360,15374]
argument [15360,15374]
===
match
---
simple_stmt [49535,49574]
simple_stmt [49535,49574]
===
match
---
simple_stmt [71251,71334]
simple_stmt [71203,71286]
===
match
---
testlist_comp [47265,47338]
testlist_comp [47265,47338]
===
match
---
testlist_comp [18844,18866]
testlist_comp [18844,18866]
===
match
---
operator: = [71687,71688]
operator: = [71639,71640]
===
match
---
name: self [39868,39872]
name: self [39868,39872]
===
match
---
term [37999,38007]
term [37999,38007]
===
match
---
arith_expr [60779,60813]
arith_expr [60731,60765]
===
match
---
funcdef [24188,24391]
funcdef [24188,24391]
===
match
---
name: self [77968,77972]
name: self [77920,77924]
===
match
---
name: quote [19541,19546]
name: quote [19541,19546]
===
match
---
atom [18155,18183]
atom [18155,18183]
===
match
---
atom_expr [78021,78069]
atom_expr [77973,78021]
===
match
---
simple_stmt [81063,81087]
simple_stmt [81015,81039]
===
match
---
number: 1000 [9940,9944]
number: 1000 [9940,9944]
===
match
---
tfpdef [41831,41850]
tfpdef [41831,41850]
===
match
---
arglist [71915,71927]
arglist [71867,71879]
===
match
---
parameters [79782,79806]
parameters [79734,79758]
===
match
---
operator: , [15374,15375]
operator: , [15374,15375]
===
match
---
atom_expr [82603,82623]
atom_expr [82555,82575]
===
match
---
atom_expr [26412,26436]
atom_expr [26412,26436]
===
match
---
atom_expr [71365,71436]
atom_expr [71317,71388]
===
match
---
atom_expr [60556,60570]
atom_expr [60508,60522]
===
match
---
atom_expr [53034,53061]
atom_expr [53033,53060]
===
match
---
string: 'prev_execution_date_success' [65242,65271]
string: 'prev_execution_date_success' [65194,65223]
===
match
---
operator: = [30213,30214]
operator: = [30213,30214]
===
match
---
name: _try_number [13237,13248]
name: _try_number [13237,13248]
===
match
---
trailer [32590,32607]
trailer [32590,32607]
===
match
---
name: utcnow [35122,35128]
name: utcnow [35122,35128]
===
match
---
name: res [54339,54342]
name: res [54338,54341]
===
match
---
atom_expr [78827,78854]
atom_expr [78779,78806]
===
match
---
lambdef [65314,65375]
lambdef [65266,65327]
===
match
---
operator: { [62451,62452]
operator: { [62403,62404]
===
match
---
try_stmt [4136,4276]
try_stmt [4136,4276]
===
match
---
simple_stmt [72046,72065]
simple_stmt [71998,72017]
===
match
---
atom_expr [35493,35506]
atom_expr [35493,35506]
===
match
---
simple_stmt [22436,22464]
simple_stmt [22436,22464]
===
match
---
operator: , [53471,53472]
operator: , [53470,53471]
===
match
---
name: current_state [19899,19912]
name: current_state [19899,19912]
===
match
---
atom_expr [29526,29578]
atom_expr [29526,29578]
===
match
---
operator: , [59666,59667]
operator: , [59618,59619]
===
match
---
operator: = [53176,53177]
operator: = [53175,53176]
===
match
---
simple_stmt [22851,22869]
simple_stmt [22851,22869]
===
match
---
name: self [66699,66703]
name: self [66651,66655]
===
match
---
name: test_mode [56442,56451]
name: test_mode [56441,56450]
===
match
---
name: execution_date [12017,12031]
name: execution_date [12017,12031]
===
match
---
name: catchup [27734,27741]
name: catchup [27734,27741]
===
match
---
name: int [33816,33819]
name: int [33816,33819]
===
match
---
name: property [81163,81171]
name: property [81115,81123]
===
match
---
param [15926,15958]
param [15926,15958]
===
match
---
trailer [66434,66455]
trailer [66386,66407]
===
match
---
operator: = [37678,37679]
operator: = [37678,37679]
===
match
---
operator: = [22131,22132]
operator: = [22131,22132]
===
match
---
trailer [7204,7206]
trailer [7204,7206]
===
match
---
name: __repr__ [63206,63214]
name: __repr__ [63158,63166]
===
match
---
name: pendulum [29675,29683]
name: pendulum [29675,29683]
===
match
---
suite [13944,14019]
suite [13944,14019]
===
match
---
name: airflow [2370,2377]
name: airflow [2370,2377]
===
match
---
operator: == [77723,77725]
operator: == [77675,77677]
===
match
---
import_from [1103,1133]
import_from [1103,1133]
===
match
---
name: in_ [26186,26189]
name: in_ [26186,26189]
===
match
---
operator: = [80222,80223]
operator: = [80174,80175]
===
match
---
name: ready_for_retry [34882,34897]
name: ready_for_retry [34882,34897]
===
match
---
string: 'ti_state' [10716,10726]
string: 'ti_state' [10716,10726]
===
match
---
name: self [81512,81516]
name: self [81464,81468]
===
match
---
tfpdef [74643,74651]
tfpdef [74595,74603]
===
match
---
if_stmt [18193,18254]
if_stmt [18193,18254]
===
match
---
name: str [8077,8080]
name: str [8077,8080]
===
match
---
name: from_string [71375,71386]
name: from_string [71327,71338]
===
match
---
name: ignore_depends_on_past [39711,39733]
name: ignore_depends_on_past [39711,39733]
===
match
---
atom_expr [24693,24710]
atom_expr [24693,24710]
===
match
---
operator: , [44846,44847]
operator: , [44846,44847]
===
match
---
string: 'logging' [19063,19072]
string: 'logging' [19063,19072]
===
match
---
name: task_tries [6982,6992]
name: task_tries [6982,6992]
===
match
---
number: 20 [9815,9817]
number: 20 [9815,9817]
===
match
---
param [53744,53773]
param [53743,53772]
===
match
---
suite [7545,7981]
suite [7545,7981]
===
match
---
simple_stmt [53886,54324]
simple_stmt [53885,54323]
===
match
---
trailer [43877,43892]
trailer [43877,43892]
===
match
---
trailer [22124,22130]
trailer [22124,22130]
===
match
---
fstring_end: " [19758,19759]
fstring_end: " [19758,19759]
===
match
---
return_stmt [28001,28068]
return_stmt [28001,28068]
===
match
---
argument [30932,30951]
argument [30932,30951]
===
match
---
operator: , [56176,56177]
operator: , [56175,56176]
===
match
---
argument [79154,79183]
argument [79106,79135]
===
match
---
name: finished [24898,24906]
name: finished [24898,24906]
===
match
---
trailer [71534,71541]
trailer [71486,71493]
===
match
---
funcdef [56106,59105]
funcdef [56105,59057]
===
match
---
string: "tasks" [18004,18011]
string: "tasks" [18004,18011]
===
match
---
decorator [64221,64235]
decorator [64173,64187]
===
match
---
trailer [26889,26900]
trailer [26889,26900]
===
match
---
number: 1 [70923,70924]
number: 1 [70875,70876]
===
match
---
decorator [29722,29739]
decorator [29722,29739]
===
match
---
atom_expr [22633,22643]
atom_expr [22633,22643]
===
match
---
simple_stmt [78751,78954]
simple_stmt [78703,78906]
===
match
---
simple_stmt [81376,81395]
simple_stmt [81328,81347]
===
match
---
operator: = [76442,76443]
operator: = [76394,76395]
===
match
---
name: and_ [78758,78762]
name: and_ [78710,78714]
===
match
---
fstring_start: f" [19696,19698]
fstring_start: f" [19696,19698]
===
match
---
trailer [47983,47993]
trailer [47983,47993]
===
match
---
simple_stmt [12196,12216]
simple_stmt [12196,12216]
===
match
---
trailer [7949,7960]
trailer [7949,7960]
===
match
---
name: ignore_ti_state [38367,38382]
name: ignore_ti_state [38367,38382]
===
match
---
name: task [52697,52701]
name: task [52696,52700]
===
match
---
simple_stmt [3652,3692]
simple_stmt [3652,3692]
===
match
---
trailer [60652,60654]
trailer [60604,60606]
===
match
---
atom_expr [68905,68935]
atom_expr [68857,68887]
===
match
---
argument [34698,34730]
argument [34698,34730]
===
match
---
name: tis [78733,78736]
name: tis [78685,78688]
===
match
---
trailer [11239,11246]
trailer [11239,11246]
===
match
---
number: 1000 [9976,9980]
number: 1000 [9976,9980]
===
match
---
name: session [35451,35458]
name: session [35451,35458]
===
match
---
trailer [7858,7862]
trailer [7858,7862]
===
match
---
expr_stmt [17986,18041]
expr_stmt [17986,18041]
===
match
---
atom_expr [20965,20984]
atom_expr [20965,20984]
===
match
---
name: self [43528,43532]
name: self [43528,43532]
===
match
---
expr_stmt [76435,76455]
expr_stmt [76387,76407]
===
match
---
operator: @ [77395,77396]
operator: @ [77347,77348]
===
match
---
name: self [82231,82235]
name: self [82183,82187]
===
match
---
operator: , [54200,54201]
operator: , [54199,54200]
===
match
---
try_stmt [51418,51659]
try_stmt [51456,51697]
===
match
---
atom_expr [48066,48084]
atom_expr [48066,48084]
===
match
---
simple_stmt [8744,8827]
simple_stmt [8744,8827]
===
match
---
expr_stmt [20597,20609]
expr_stmt [20597,20609]
===
match
---
name: context [68192,68199]
name: context [68144,68151]
===
match
---
name: error [52382,52387]
name: error [52381,52386]
===
match
---
atom_expr [12196,12215]
atom_expr [12196,12215]
===
match
---
trailer [28634,28650]
trailer [28634,28650]
===
match
---
operator: , [49332,49333]
operator: , [49332,49333]
===
match
---
name: task [53203,53207]
name: task [53202,53206]
===
match
---
operator: = [63936,63937]
operator: = [63888,63889]
===
match
---
name: handle_failure [44329,44343]
name: handle_failure [44329,44343]
===
match
---
trailer [66579,66585]
trailer [66531,66537]
===
match
---
argument [59468,59479]
argument [59420,59431]
===
match
---
string: "--mark-success" [18091,18107]
string: "--mark-success" [18091,18107]
===
match
---
name: try_number [8582,8592]
name: try_number [8582,8592]
===
match
---
name: TaskInstance [78780,78792]
name: TaskInstance [78732,78744]
===
match
---
operator: = [23374,23375]
operator: = [23374,23375]
===
match
---
atom [18718,18727]
atom [18718,18727]
===
match
---
name: init_on_load [12511,12523]
name: init_on_load [12511,12523]
===
match
---
name: signum [48385,48391]
name: signum [48385,48391]
===
match
---
name: self [41710,41714]
name: self [41710,41714]
===
match
---
name: self [22516,22520]
name: self [22516,22520]
===
match
---
parameters [64254,64431]
parameters [64206,64383]
===
match
---
suite [12708,13253]
suite [12708,13253]
===
match
---
name: defaultdict [5150,5161]
name: defaultdict [5150,5161]
===
match
---
if_stmt [52967,53112]
if_stmt [52966,53111]
===
match
---
name: dep_context [32461,32472]
name: dep_context [32461,32472]
===
match
---
trailer [23315,23320]
trailer [23315,23320]
===
match
---
name: task [59980,59984]
name: task [59932,59936]
===
match
---
string: "airflow" [17993,18002]
string: "airflow" [17993,18002]
===
match
---
name: datetime [80967,80975]
name: datetime [80919,80927]
===
match
---
name: log [21523,21526]
name: log [21523,21526]
===
match
---
atom [60858,60894]
atom [60810,60846]
===
match
---
name: self [12196,12200]
name: self [12196,12200]
===
match
---
atom_expr [48792,48808]
atom_expr [48792,48808]
===
match
---
name: str [74568,74571]
name: str [74520,74523]
===
match
---
expr_stmt [3216,3240]
expr_stmt [3216,3240]
===
match
---
name: airflow [2405,2412]
name: airflow [2405,2412]
===
match
---
name: dag_run [46918,46925]
name: dag_run [46918,46925]
===
match
---
simple_stmt [22552,22572]
simple_stmt [22552,22572]
===
match
---
simple_stmt [22516,22540]
simple_stmt [22516,22540]
===
match
---
name: VariableJsonAccessor [63615,63635]
name: VariableJsonAccessor [63567,63587]
===
match
---
param [77457,77464]
param [77409,77416]
===
match
---
expr_stmt [62405,62463]
expr_stmt [62357,62415]
===
match
---
name: ti [22564,22566]
name: ti [22564,22566]
===
match
---
trailer [65326,65354]
trailer [65278,65306]
===
match
---
simple_stmt [3242,3279]
simple_stmt [3242,3279]
===
match
---
argument [71222,71237]
argument [71174,71189]
===
match
---
atom_expr [31833,31847]
atom_expr [31833,31847]
===
match
---
name: self [43216,43220]
name: self [43216,43220]
===
match
---
atom_expr [49625,49666]
atom_expr [49625,49666]
===
match
---
if_stmt [44637,44821]
if_stmt [44637,44821]
===
match
---
return_stmt [33003,33094]
return_stmt [33003,33094]
===
match
---
trailer [43505,43510]
trailer [43505,43510]
===
match
---
simple_stmt [66805,67181]
simple_stmt [66757,67133]
===
match
---
arglist [41356,41408]
arglist [41356,41408]
===
match
---
name: reconstructor [1421,1434]
name: reconstructor [1421,1434]
===
match
---
simple_stmt [82603,82647]
simple_stmt [82555,82599]
===
match
---
simple_stmt [25088,25108]
simple_stmt [25088,25108]
===
match
---
trailer [25095,25101]
trailer [25095,25101]
===
match
---
suite [30467,30953]
suite [30467,30953]
===
match
---
param [64272,64282]
param [64224,64234]
===
match
---
name: execution_date [6793,6807]
name: execution_date [6793,6807]
===
match
---
name: conf [64635,64639]
name: conf [64587,64591]
===
match
---
expr_stmt [10193,10224]
expr_stmt [10193,10224]
===
match
---
name: String [9505,9511]
name: String [9505,9511]
===
match
---
operator: = [40857,40858]
operator: = [40857,40858]
===
match
---
operator: -> [78071,78073]
operator: -> [78023,78025]
===
match
---
trailer [30943,30951]
trailer [30943,30951]
===
match
---
operator: , [34056,34057]
operator: , [34056,34057]
===
match
---
name: job_id [18196,18202]
name: job_id [18196,18202]
===
match
---
name: in_ [7443,7446]
name: in_ [7443,7446]
===
match
---
name: dag_run [60574,60581]
name: dag_run [60526,60533]
===
match
---
simple_stmt [52446,52614]
simple_stmt [52445,52613]
===
match
---
trailer [11201,11210]
trailer [11201,11210]
===
match
---
import_as_names [1845,1873]
import_as_names [1845,1873]
===
match
---
operator: , [44203,44204]
operator: , [44203,44204]
===
match
---
trailer [60673,60688]
trailer [60625,60640]
===
match
---
atom [64613,66189]
atom [64565,66141]
===
match
---
name: run_as_user [23463,23474]
name: run_as_user [23463,23474]
===
match
---
operator: @ [63272,63273]
operator: @ [63224,63225]
===
match
---
name: html_content_err [72303,72319]
name: html_content_err [72255,72271]
===
match
---
tfpdef [64272,64281]
tfpdef [64224,64233]
===
match
---
name: xcom_push [51871,51880]
name: xcom_push [51909,51918]
===
match
---
atom_expr [19541,19579]
atom_expr [19541,19579]
===
match
---
name: Column [9498,9504]
name: Column [9498,9504]
===
match
---
operator: = [59473,59474]
operator: = [59425,59426]
===
match
---
trailer [53269,53290]
trailer [53268,53289]
===
match
---
tfpdef [29231,29247]
tfpdef [29231,29247]
===
match
---
operator: , [11154,11155]
operator: , [11154,11155]
===
match
---
operator: @ [12673,12674]
operator: @ [12673,12674]
===
match
---
name: ds_nodash [64749,64758]
name: ds_nodash [64701,64710]
===
match
---
name: hostname [37727,37735]
name: hostname [37727,37735]
===
match
---
name: self [20346,20350]
name: self [20346,20350]
===
match
---
operator: , [55517,55518]
operator: , [55516,55517]
===
match
---
tfpdef [68078,68104]
tfpdef [68030,68056]
===
match
---
trailer [44470,44486]
trailer [44470,44486]
===
match
---
tfpdef [56148,56176]
tfpdef [56147,56175]
===
match
---
decorated [19166,19443]
decorated [19166,19443]
===
match
---
name: following_schedule [61514,61532]
name: following_schedule [61466,61484]
===
match
---
name: execution_date [27312,27326]
name: execution_date [27312,27326]
===
match
---
name: dag [14614,14617]
name: dag [14614,14617]
===
match
---
name: local [18578,18583]
name: local [18578,18583]
===
match
---
simple_stmt [61333,61375]
simple_stmt [61285,61327]
===
match
---
name: RUNNING_DEPS [38253,38265]
name: RUNNING_DEPS [38253,38265]
===
match
---
param [81354,81358]
param [81306,81310]
===
match
---
simple_stmt [49262,49430]
simple_stmt [49262,49430]
===
match
---
name: tomorrow_ds_nodash [65823,65841]
name: tomorrow_ds_nodash [65775,65793]
===
match
---
suite [24943,25080]
suite [24943,25080]
===
match
---
name: datetime [80884,80892]
name: datetime [80836,80844]
===
match
---
operator: , [35970,35971]
operator: , [35970,35971]
===
match
---
operator: = [25957,25958]
operator: = [25957,25958]
===
match
---
trailer [60400,60408]
trailer [60352,60360]
===
match
---
simple_stmt [2288,2365]
simple_stmt [2288,2365]
===
match
---
simple_stmt [1018,1103]
simple_stmt [1018,1103]
===
match
---
name: with_entities [77067,77080]
name: with_entities [77019,77032]
===
match
---
name: next_execution_date [65008,65027]
name: next_execution_date [64960,64979]
===
match
---
name: _update_ti_state_for_sensing [50347,50375]
name: _update_ti_state_for_sensing [50385,50413]
===
match
---
name: merge [50973,50978]
name: merge [51011,51016]
===
match
---
name: item [64272,64276]
name: item [64224,64228]
===
match
---
atom_expr [50159,50195]
atom_expr [50016,50233]
===
match
---
name: self [37533,37537]
name: self [37533,37537]
===
match
---
raise_stmt [67626,67714]
raise_stmt [67578,67666]
===
match
---
trailer [37864,37894]
trailer [37864,37894]
===
match
---
simple_stmt [53171,53188]
simple_stmt [53170,53187]
===
match
---
simple_stmt [56907,56941]
simple_stmt [56906,56940]
===
match
---
trailer [21599,21605]
trailer [21599,21605]
===
match
---
trailer [42929,42971]
trailer [42929,42971]
===
match
---
suite [59763,59804]
suite [59715,59756]
===
match
---
name: dry_run [55104,55111]
name: dry_run [55103,55110]
===
match
---
trailer [34646,34660]
trailer [34646,34660]
===
match
---
name: self [41454,41458]
name: self [41454,41458]
===
match
---
trailer [55645,55654]
trailer [55644,55653]
===
match
---
operator: @ [30384,30385]
operator: @ [30384,30385]
===
match
---
trailer [4092,4094]
trailer [4092,4094]
===
match
---
name: execution_date [78691,78705]
name: execution_date [78643,78657]
===
match
---
name: render [71413,71419]
name: render [71365,71371]
===
match
---
expr_stmt [22552,22571]
expr_stmt [22552,22571]
===
match
---
name: NONE [39986,39990]
name: NONE [39986,39990]
===
match
---
trailer [57251,57260]
trailer [57250,57259]
===
match
---
name: self [24835,24839]
name: self [24835,24839]
===
match
---
name: cmd [18462,18465]
name: cmd [18462,18465]
===
match
---
atom_expr [58364,58733]
atom_expr [58363,58732]
===
match
---
atom_expr [42919,42971]
atom_expr [42919,42971]
===
match
---
simple_stmt [27110,27179]
simple_stmt [27110,27179]
===
match
---
name: utils [2670,2675]
name: utils [2670,2675]
===
match
---
trailer [57112,57116]
trailer [57111,57115]
===
match
---
name: partial_subset [46676,46690]
name: partial_subset [46676,46690]
===
match
---
name: self [19547,19551]
name: self [19547,19551]
===
match
---
name: executor_config [68819,68834]
name: executor_config [68771,68786]
===
match
---
operator: , [24435,24436]
operator: , [24435,24436]
===
match
---
atom_expr [9577,9609]
atom_expr [9577,9609]
===
match
---
trailer [78839,78854]
trailer [78791,78806]
===
match
---
name: and_ [6742,6746]
name: and_ [6742,6746]
===
match
---
operator: , [58965,58966]
operator: , [58959,58960]
===
match
---
atom [77157,77203]
atom [77109,77155]
===
match
---
trailer [36029,36034]
trailer [36029,36034]
===
match
---
atom_expr [48522,48541]
atom_expr [48522,48541]
===
match
---
trailer [72924,72933]
trailer [72876,72885]
===
match
---
decorator [15493,15507]
decorator [15493,15507]
===
match
---
name: self [59608,59612]
name: self [59560,59564]
===
match
---
name: ignore_depends_on_past [18426,18448]
name: ignore_depends_on_past [18426,18448]
===
match
---
return_stmt [63549,63599]
return_stmt [63501,63551]
===
match
---
trailer [70758,71003]
trailer [70710,70955]
===
match
---
atom_expr [80004,80018]
atom_expr [79956,79970]
===
match
---
name: pool_override [42730,42743]
name: pool_override [42730,42743]
===
match
---
simple_stmt [23592,23623]
simple_stmt [23592,23623]
===
match
---
expr_stmt [80189,80228]
expr_stmt [80141,80180]
===
match
---
operator: = [12475,12476]
operator: = [12475,12476]
===
match
---
trailer [50831,50836]
trailer [50869,50874]
===
match
---
trailer [80996,81006]
trailer [80948,80958]
===
match
---
operator: = [42681,42682]
operator: = [42681,42682]
===
match
---
trailer [62480,62487]
trailer [62432,62439]
===
match
---
operator: = [53579,53580]
operator: = [53578,53579]
===
match
---
operator: , [36099,36100]
operator: , [36099,36100]
===
match
---
trailer [10356,10382]
trailer [10356,10382]
===
match
---
operator: , [55654,55655]
operator: , [55653,55654]
===
match
---
name: next_execution_date [61619,61638]
name: next_execution_date [61571,61590]
===
match
---
name: instance [29684,29692]
name: instance [29684,29692]
===
match
---
atom_expr [22646,22654]
atom_expr [22646,22654]
===
match
---
operator: { [67702,67703]
operator: { [67654,67655]
===
match
---
atom_expr [23423,23449]
atom_expr [23423,23449]
===
match
---
name: e [43504,43505]
name: e [43504,43505]
===
match
---
expr_stmt [22436,22463]
expr_stmt [22436,22463]
===
match
---
string: 'inlets' [64842,64850]
string: 'inlets' [64794,64802]
===
match
---
operator: = [51884,51885]
operator: = [51922,51923]
===
match
---
param [14369,14383]
param [14369,14383]
===
match
---
name: filepath [14733,14741]
name: filepath [14733,14741]
===
match
---
simple_stmt [871,885]
simple_stmt [871,885]
===
match
---
atom_expr [3965,3996]
atom_expr [3965,3996]
===
match
---
number: 1 [8574,8575]
number: 1 [8574,8575]
===
match
---
atom_expr [7184,7206]
atom_expr [7184,7206]
===
match
---
name: dag_run [46094,46101]
name: dag_run [46094,46101]
===
match
---
operator: , [7135,7136]
operator: , [7135,7136]
===
match
---
name: DagRun [7588,7594]
name: DagRun [7588,7594]
===
match
---
name: BaseJob [82693,82700]
name: BaseJob [82645,82652]
===
match
---
parameters [12523,12529]
parameters [12523,12529]
===
match
---
simple_stmt [80543,80562]
simple_stmt [80495,80514]
===
match
---
operator: , [45374,45375]
operator: , [45374,45375]
===
match
---
simple_stmt [2205,2237]
simple_stmt [2205,2237]
===
match
---
simple_stmt [54836,54877]
simple_stmt [54835,54876]
===
match
---
name: html_content_err [72419,72435]
name: html_content_err [72371,72387]
===
match
---
name: dispose [41139,41146]
name: dispose [41139,41146]
===
match
---
name: session [29231,29238]
name: session [29231,29238]
===
match
---
trailer [62519,62526]
trailer [62471,62478]
===
match
---
operator: = [42816,42817]
operator: = [42816,42817]
===
match
---
simple_stmt [41418,41430]
simple_stmt [41418,41430]
===
match
---
comp_op [52995,53001]
comp_op [52994,53000]
===
match
---
funcdef [72441,72795]
funcdef [72393,72747]
===
match
---
expr_stmt [22040,22067]
expr_stmt [22040,22067]
===
match
---
name: dep_context [2258,2269]
name: dep_context [2258,2269]
===
match
---
simple_stmt [76435,76456]
simple_stmt [76387,76408]
===
match
---
trailer [65453,65542]
trailer [65405,65494]
===
match
---
if_stmt [82272,82382]
if_stmt [82224,82334]
===
match
---
operator: = [41851,41852]
operator: = [41851,41852]
===
match
---
name: tis [4741,4744]
name: tis [4741,4744]
===
match
---
name: ti [79982,79984]
name: ti [79934,79936]
===
match
---
operator: = [56435,56436]
operator: = [56434,56435]
===
match
---
name: primaryjoin [10964,10975]
name: primaryjoin [10964,10975]
===
match
---
operator: = [82307,82308]
operator: = [82259,82260]
===
match
---
simple_stmt [61586,61608]
simple_stmt [61538,61560]
===
match
---
decorator [81092,81102]
decorator [81044,81054]
===
match
---
operator: , [43796,43797]
operator: , [43796,43797]
===
match
---
trailer [20978,20984]
trailer [20978,20984]
===
match
---
param [50794,50799]
param [50832,50837]
===
match
---
string: 'Failed to send email to: %s' [58936,58965]
string: 'Failed to send email to: %s' [58930,58959]
===
match
---
operator: , [1296,1297]
operator: , [1296,1297]
===
match
---
arglist [80420,80441]
arglist [80372,80393]
===
match
---
trailer [68269,68292]
trailer [68221,68244]
===
match
---
trailer [7431,7456]
trailer [7431,7456]
===
match
---
number: 0 [78346,78347]
number: 0 [78298,78299]
===
match
---
simple_stmt [68018,68046]
simple_stmt [67970,67998]
===
match
---
trailer [6644,7216]
trailer [6644,7216]
===
match
---
name: try_number [81030,81040]
name: try_number [80982,80992]
===
match
---
name: queue [22649,22654]
name: queue [22649,22654]
===
match
---
name: try_number [70910,70920]
name: try_number [70862,70872]
===
match
---
name: refresh_from_db [42763,42778]
name: refresh_from_db [42763,42778]
===
match
---
name: on_execute_callback [52145,52164]
name: on_execute_callback [52183,52202]
===
match
---
operator: , [68717,68718]
operator: , [68669,68670]
===
match
---
name: self [42758,42762]
name: self [42758,42762]
===
match
---
arglist [32690,32871]
arglist [32690,32871]
===
match
---
import_as_names [2787,2814]
import_as_names [2787,2814]
===
match
---
name: state [24915,24920]
name: state [24915,24920]
===
match
---
name: ti [80162,80164]
name: ti [80114,80116]
===
match
---
trailer [80547,80552]
trailer [80499,80504]
===
match
---
expr_stmt [23400,23449]
expr_stmt [23400,23449]
===
match
---
return_stmt [80902,80925]
return_stmt [80854,80877]
===
match
---
tfpdef [35750,35763]
tfpdef [35750,35763]
===
match
---
arglist [49217,49248]
arglist [49217,49248]
===
match
---
trailer [26129,26136]
trailer [26129,26136]
===
match
---
operator: , [34076,34077]
operator: , [34076,34077]
===
match
---
trailer [53796,53801]
trailer [53795,53800]
===
match
---
trailer [10029,10058]
trailer [10029,10058]
===
match
---
name: pod_generator [3120,3133]
name: pod_generator [3120,3133]
===
match
---
trailer [44761,44798]
trailer [44761,44798]
===
match
---
name: State [25361,25366]
name: State [25361,25366]
===
match
---
name: PodGenerator [68965,68977]
name: PodGenerator [68917,68929]
===
match
---
atom_expr [29265,29292]
atom_expr [29265,29292]
===
match
---
trailer [47190,47210]
trailer [47190,47210]
===
match
---
name: previous_ti [28113,28124]
name: previous_ti [28113,28124]
===
match
---
name: local [15308,15313]
name: local [15308,15313]
===
match
---
name: String [9933,9939]
name: String [9933,9939]
===
match
---
name: self [66228,66232]
name: self [66180,66184]
===
match
---
simple_stmt [24133,24169]
simple_stmt [24133,24169]
===
match
---
expr_stmt [80543,80561]
expr_stmt [80495,80513]
===
match
---
suite [45531,45611]
suite [45531,45611]
===
match
---
name: exception [70802,70811]
name: exception [70754,70763]
===
match
---
trailer [47901,47905]
trailer [47901,47905]
===
match
---
name: is_premature [25131,25143]
name: is_premature [25131,25143]
===
match
---
name: RenderedTaskInstanceFields [48939,48965]
name: RenderedTaskInstanceFields [48939,48965]
===
match
---
trailer [61431,61449]
trailer [61383,61401]
===
match
---
string: 'Mark success: <a href="{{ti.mark_success_url}}">Link</a><br>' [70049,70111]
string: 'Mark success: <a href="{{ti.mark_success_url}}">Link</a><br>' [70001,70063]
===
match
---
operator: , [77738,77739]
operator: , [77690,77691]
===
match
---
trailer [35464,35472]
trailer [35464,35472]
===
match
---
operator: , [50612,50613]
operator: , [50650,50651]
===
match
---
trailer [82059,82065]
trailer [82011,82017]
===
match
---
operator: = [55041,55042]
operator: = [55040,55041]
===
match
---
operator: , [66634,66635]
operator: , [66586,66587]
===
match
---
trailer [40498,40505]
trailer [40498,40505]
===
match
---
operator: == [37824,37826]
operator: == [37824,37826]
===
match
---
expr_stmt [68398,68424]
expr_stmt [68350,68376]
===
match
---
atom_expr [33679,33747]
atom_expr [33679,33747]
===
match
---
trailer [39066,39077]
trailer [39066,39077]
===
match
---
arglist [62269,62276]
arglist [62221,62228]
===
match
---
operator: , [32870,32871]
operator: , [32870,32871]
===
match
---
simple_stmt [33003,33095]
simple_stmt [33003,33095]
===
match
---
string: '%Y%m%dT%H%M%S' [41596,41611]
string: '%Y%m%dT%H%M%S' [41596,41611]
===
match
---
name: property [30385,30393]
name: property [30385,30393]
===
match
---
name: has_task [5410,5418]
name: has_task [5410,5418]
===
match
---
name: session [38623,38630]
name: session [38623,38630]
===
match
---
trailer [79134,79149]
trailer [79086,79101]
===
match
---
atom_expr [7947,7960]
atom_expr [7947,7960]
===
match
---
atom_expr [69051,69082]
atom_expr [69003,69034]
===
match
---
decorated [8344,8599]
decorated [8344,8599]
===
match
---
name: get_previous_start_date [29747,29770]
name: get_previous_start_date [29747,29770]
===
match
---
name: start_date [9692,9702]
name: start_date [9692,9702]
===
match
---
param [72817,72821]
param [72769,72773]
===
match
---
or_test [24972,25001]
or_test [24972,25001]
===
match
---
name: str [74582,74585]
name: str [74534,74537]
===
match
---
name: task [62421,62425]
name: task [62373,62377]
===
match
---
atom_expr [78336,78348]
atom_expr [78288,78300]
===
match
---
trailer [71316,71333]
trailer [71268,71285]
===
match
---
atom_expr [72751,72766]
atom_expr [72703,72718]
===
match
---
not_test [57078,57091]
not_test [57077,57090]
===
match
---
name: previous_ti_success [28597,28616]
name: previous_ti_success [28597,28616]
===
match
---
suite [32636,32970]
suite [32636,32970]
===
match
---
simple_stmt [11880,11933]
simple_stmt [11880,11933]
===
match
---
suite [59047,59080]
suite [58999,59032]
===
match
---
expr_stmt [22584,22620]
expr_stmt [22584,22620]
===
match
---
name: use_default [69436,69447]
name: use_default [69388,69399]
===
match
---
operator: = [35996,35997]
operator: = [35996,35997]
===
match
---
name: bool [15670,15674]
name: bool [15670,15674]
===
match
---
atom_expr [53078,53111]
atom_expr [53077,53110]
===
match
---
trailer [82615,82623]
trailer [82567,82575]
===
match
---
simple_stmt [43528,43545]
simple_stmt [43528,43545]
===
match
---
operator: , [34631,34632]
operator: , [34631,34632]
===
match
---
trailer [11805,11845]
trailer [11805,11845]
===
match
---
name: task_id [5362,5369]
name: task_id [5362,5369]
===
match
---
name: task [23519,23523]
name: task [23519,23523]
===
match
---
name: test_mode [54523,54532]
name: test_mode [54522,54531]
===
match
---
trailer [58339,58354]
trailer [58338,58353]
===
match
---
or_test [32475,32502]
or_test [32475,32502]
===
match
---
tfpdef [15656,15674]
tfpdef [15656,15674]
===
match
---
trailer [61747,61756]
trailer [61699,61708]
===
match
---
atom_expr [29793,29806]
atom_expr [29793,29806]
===
match
---
name: dag_id [45018,45024]
name: dag_id [45018,45024]
===
match
---
name: Optional [41837,41845]
name: Optional [41837,41845]
===
match
---
name: session [4750,4757]
name: session [4750,4757]
===
match
---
if_stmt [20532,20610]
if_stmt [20532,20610]
===
match
---
name: data [4169,4173]
name: data [4169,4173]
===
match
---
name: self [67918,67922]
name: self [67870,67874]
===
match
---
name: Stats [37854,37859]
name: Stats [37854,37859]
===
match
---
name: try_number [40662,40672]
name: try_number [40662,40672]
===
match
---
name: TaskInstance [79309,79321]
name: TaskInstance [79261,79273]
===
match
---
name: iso [17945,17948]
name: iso [17945,17948]
===
match
---
name: rendered_task_instance_fields [66550,66579]
name: rendered_task_instance_fields [66502,66531]
===
match
---
operator: , [1859,1860]
operator: , [1859,1860]
===
match
---
operator: = [15800,15801]
operator: = [15800,15801]
===
match
---
name: end_date [9729,9737]
name: end_date [9729,9737]
===
match
---
trailer [38683,38690]
trailer [38683,38690]
===
match
---
trailer [40811,40837]
trailer [40811,40837]
===
match
---
name: datetime [15638,15646]
name: datetime [15638,15646]
===
match
---
name: session [31028,31035]
name: session [31028,31035]
===
match
---
operator: == [77670,77672]
operator: == [77622,77624]
===
match
---
trailer [52102,52122]
trailer [52140,52160]
===
match
---
operator: = [42847,42848]
operator: = [42847,42848]
===
match
---
param [41793,41822]
param [41793,41822]
===
match
---
atom_expr [14830,14847]
atom_expr [14830,14847]
===
match
---
suite [18364,18415]
suite [18364,18415]
===
match
---
name: dag [14598,14601]
name: dag [14598,14601]
===
match
---
operator: , [15721,15722]
operator: , [15721,15722]
===
match
---
trailer [33375,33401]
trailer [33375,33401]
===
match
---
name: content [72110,72117]
name: content [72062,72069]
===
match
---
string: '' [59819,59821]
string: '' [59771,59773]
===
match
---
simple_stmt [1492,1546]
simple_stmt [1492,1546]
===
match
---
sync_comp_for [7163,7206]
sync_comp_for [7163,7206]
===
match
---
string: "Marking task as UP_FOR_RETRY." [58273,58304]
string: "Marking task as UP_FOR_RETRY." [58272,58303]
===
match
---
return_stmt [41621,41630]
return_stmt [41621,41630]
===
match
---
trailer [10424,10450]
trailer [10424,10450]
===
match
---
string: 'ts_nodash' [65877,65888]
string: 'ts_nodash' [65829,65840]
===
match
---
trailer [57193,57262]
trailer [57192,57261]
===
match
---
trailer [55371,55378]
trailer [55370,55377]
===
match
---
operator: , [1060,1061]
operator: , [1060,1061]
===
match
---
fstring_start: f" [19370,19372]
fstring_start: f" [19370,19372]
===
match
---
trailer [56938,56940]
trailer [56937,56939]
===
match
---
atom_expr [79982,79995]
atom_expr [79934,79947]
===
match
---
name: self [76515,76519]
name: self [76467,76471]
===
match
---
name: self [64198,64202]
name: self [64150,64154]
===
match
---
trailer [50947,50954]
trailer [50985,50992]
===
match
---
suite [58793,58834]
suite [58792,58833]
===
match
---
trailer [24115,24122]
trailer [24115,24122]
===
match
---
name: OperationalError [1377,1393]
name: OperationalError [1377,1393]
===
match
---
atom_expr [73215,73233]
atom_expr [73167,73185]
===
match
---
operator: , [82186,82187]
operator: , [82138,82139]
===
match
---
operator: , [2103,2104]
operator: , [2103,2104]
===
match
---
trailer [41887,41892]
trailer [41887,41892]
===
match
---
name: task_id [47111,47118]
name: task_id [47111,47118]
===
match
---
name: OperationalError [47760,47776]
name: OperationalError [47760,47776]
===
match
---
name: timezone [7963,7971]
name: timezone [7963,7971]
===
match
---
operator: , [54600,54601]
operator: , [54599,54600]
===
match
---
operator: = [61421,61422]
operator: = [61373,61374]
===
match
---
argument [50597,50612]
argument [50635,50650]
===
match
---
arglist [10425,10449]
arglist [10425,10449]
===
match
---
name: delete_qry [7303,7313]
name: delete_qry [7303,7313]
===
match
---
atom_expr [77950,77973]
atom_expr [77902,77925]
===
match
---
operator: , [33942,33943]
operator: , [33942,33943]
===
match
---
name: self [82173,82177]
name: self [82125,82129]
===
match
---
name: task_id [78994,79001]
name: task_id [78946,78953]
===
match
---
operator: , [65542,65543]
operator: , [65494,65495]
===
match
---
name: dag [14708,14711]
name: dag [14708,14711]
===
match
---
operator: , [10861,10862]
operator: , [10861,10862]
===
match
---
trailer [52701,52721]
trailer [52700,52720]
===
match
---
trailer [22648,22654]
trailer [22648,22654]
===
match
---
trailer [7251,7258]
trailer [7251,7258]
===
match
---
name: lazy_object_proxy [65273,65290]
name: lazy_object_proxy [65225,65242]
===
match
---
fstring_expr [49367,49370]
fstring_expr [49367,49370]
===
match
---
operator: , [27310,27311]
operator: , [27310,27311]
===
match
---
name: dep_context [31721,31732]
name: dep_context [31721,31732]
===
match
---
name: e [43542,43543]
name: e [43542,43543]
===
match
---
trailer [6058,6064]
trailer [6058,6064]
===
match
---
parameters [29770,29844]
parameters [29770,29844]
===
match
---
trailer [56023,56079]
trailer [56022,56078]
===
match
---
trailer [69116,69118]
trailer [69068,69070]
===
match
---
name: state [30199,30204]
name: state [30199,30204]
===
match
---
expr_stmt [61769,61829]
expr_stmt [61721,61781]
===
match
---
atom_expr [22014,22027]
atom_expr [22014,22027]
===
match
---
name: error [20876,20881]
name: error [20876,20881]
===
match
---
trailer [45392,45407]
trailer [45392,45407]
===
match
---
simple_stmt [8102,8127]
simple_stmt [8102,8127]
===
match
---
name: full_filepath [14872,14885]
name: full_filepath [14872,14885]
===
match
---
name: dag_id [33033,33039]
name: dag_id [33033,33039]
===
match
---
name: self [8522,8526]
name: self [8522,8526]
===
match
---
name: self [24972,24976]
name: self [24972,24976]
===
match
---
name: ID_LEN [9584,9590]
name: ID_LEN [9584,9590]
===
match
---
name: upper [82453,82458]
name: upper [82405,82410]
===
match
---
name: raw [15392,15395]
name: raw [15392,15395]
===
match
---
name: _state [80102,80108]
name: _state [80054,80060]
===
match
---
string: 'next_ds' [64907,64916]
string: 'next_ds' [64859,64868]
===
match
---
name: job_id [5328,5334]
name: job_id [5328,5334]
===
match
---
trailer [24708,24710]
trailer [24708,24710]
===
match
---
name: KeyboardInterrupt [44848,44865]
name: KeyboardInterrupt [44848,44865]
===
match
---
operator: @ [3315,3316]
operator: @ [3315,3316]
===
match
---
simple_stmt [11221,11247]
simple_stmt [11221,11247]
===
match
---
name: pendulum [29274,29282]
name: pendulum [29274,29282]
===
match
---
simple_stmt [78208,78220]
simple_stmt [78160,78172]
===
match
---
atom_expr [71072,71122]
atom_expr [71024,71074]
===
match
---
name: __init__ [11202,11210]
name: __init__ [11202,11210]
===
match
---
name: task [26190,26194]
name: task [26190,26194]
===
match
---
expr_stmt [11221,11246]
expr_stmt [11221,11246]
===
match
---
fstring_end: " [47994,47995]
fstring_end: " [47994,47995]
===
match
---
operator: , [65389,65390]
operator: , [65341,65342]
===
match
---
operator: , [68497,68498]
operator: , [68449,68450]
===
match
---
expr_stmt [72542,72625]
expr_stmt [72494,72577]
===
match
---
trailer [37817,37823]
trailer [37817,37823]
===
match
---
name: Float [9782,9787]
name: Float [9782,9787]
===
match
---
name: get_hostname [42849,42861]
name: get_hostname [42849,42861]
===
match
---
trailer [60255,60259]
trailer [60207,60211]
===
match
---
expr_stmt [80323,80348]
expr_stmt [80275,80300]
===
match
---
with_item [4408,4436]
with_item [4408,4436]
===
match
---
parameters [52375,52428]
parameters [52374,52427]
===
match
---
atom_expr [78405,78425]
atom_expr [78357,78377]
===
match
---
trailer [26411,26437]
trailer [26411,26437]
===
match
---
atom_expr [8187,8212]
atom_expr [8187,8212]
===
match
---
suite [77882,77974]
suite [77834,77926]
===
match
---
name: State [2847,2852]
name: State [2847,2852]
===
match
---
name: ti [48966,48968]
name: ti [48966,48968]
===
match
---
trailer [78970,78977]
trailer [78922,78929]
===
match
---
arglist [50501,50519]
arglist [50539,50557]
===
match
---
atom_expr [40846,40856]
atom_expr [40846,40856]
===
match
---
operator: , [28498,28499]
operator: , [28498,28499]
===
match
---
suite [22987,23623]
suite [22987,23623]
===
match
---
atom_expr [23340,23349]
atom_expr [23340,23349]
===
match
---
trailer [6144,6152]
trailer [6144,6152]
===
match
---
simple_stmt [27365,27378]
simple_stmt [27365,27378]
===
match
---
name: provide_session [55120,55135]
name: provide_session [55119,55134]
===
match
---
name: self [45572,45576]
name: self [45572,45576]
===
match
---
param [67212,67216]
param [67164,67168]
===
match
---
simple_stmt [41123,41165]
simple_stmt [41123,41165]
===
match
---
name: _safe_date [58683,58693]
name: _safe_date [58682,58692]
===
match
---
trailer [34801,34835]
trailer [34801,34835]
===
match
---
simple_stmt [80507,80535]
simple_stmt [80459,80487]
===
match
---
operator: , [15552,15553]
operator: , [15552,15553]
===
match
---
operator: = [14602,14603]
operator: = [14602,14603]
===
match
---
trailer [39893,39949]
trailer [39893,39949]
===
match
---
suite [67815,68046]
suite [67767,67998]
===
match
---
and_test [72873,72906]
and_test [72825,72858]
===
match
---
parameters [59872,59892]
parameters [59824,59844]
===
match
---
sync_comp_for [7737,7750]
sync_comp_for [7737,7750]
===
match
---
operator: , [32612,32613]
operator: , [32612,32613]
===
match
---
if_stmt [41475,41613]
if_stmt [41475,41613]
===
match
---
name: datetime [942,950]
name: datetime [942,950]
===
match
---
trailer [56982,56987]
trailer [56981,56986]
===
match
---
atom_expr [62610,62681]
atom_expr [62562,62633]
===
match
---
name: property [80608,80616]
name: property [80560,80568]
===
match
---
atom_expr [25014,25027]
atom_expr [25014,25027]
===
match
---
name: property [28580,28588]
name: property [28580,28588]
===
match
---
atom_expr [64369,64408]
atom_expr [64321,64360]
===
match
---
atom_expr [23563,23583]
atom_expr [23563,23583]
===
match
---
trailer [78082,78101]
trailer [78034,78053]
===
match
---
expr_stmt [43216,43242]
expr_stmt [43216,43242]
===
match
---
trailer [56496,56514]
trailer [56495,56513]
===
match
---
name: update [70752,70758]
name: update [70704,70710]
===
match
---
name: TaskInstanceKey [24205,24220]
name: TaskInstanceKey [24205,24220]
===
match
---
dotted_name [82517,82537]
dotted_name [82469,82489]
===
match
---
name: self [41230,41234]
name: self [41230,41234]
===
match
---
trailer [19433,19440]
trailer [19433,19440]
===
match
---
param [56304,56317]
param [56303,56316]
===
match
---
atom_expr [5310,5335]
atom_expr [5310,5335]
===
match
---
name: self [80133,80137]
name: self [80085,80089]
===
match
---
param [63989,63994]
param [63941,63946]
===
match
---
atom_expr [71739,71753]
atom_expr [71691,71705]
===
match
---
name: self [40657,40661]
name: self [40657,40661]
===
match
---
name: _try_number [40744,40755]
name: _try_number [40744,40755]
===
match
---
name: incr [57047,57051]
name: incr [57046,57050]
===
match
---
arglist [4475,4484]
arglist [4475,4484]
===
match
---
name: debug [21527,21532]
name: debug [21527,21532]
===
match
---
trailer [48462,48509]
trailer [48462,48509]
===
match
---
param [80632,80636]
param [80584,80588]
===
match
---
simple_stmt [40491,40508]
simple_stmt [40491,40508]
===
match
---
name: ts_nodash [62155,62164]
name: ts_nodash [62107,62116]
===
match
---
trailer [19140,19148]
trailer [19140,19148]
===
match
---
operator: , [54312,54313]
operator: , [54311,54312]
===
match
---
operator: = [54304,54305]
operator: = [54303,54304]
===
match
---
name: execution_date [55540,55554]
name: execution_date [55539,55553]
===
match
---
expr_stmt [13318,13342]
expr_stmt [13318,13342]
===
match
---
argument [54660,54675]
argument [54659,54674]
===
match
---
trailer [16010,16015]
trailer [16010,16015]
===
match
---
atom_expr [10030,10041]
atom_expr [10030,10041]
===
match
---
name: DepContext [31736,31746]
name: DepContext [31736,31746]
===
match
---
name: ignore_task_deps [39768,39784]
name: ignore_task_deps [39768,39784]
===
match
---
atom_expr [73041,73097]
atom_expr [72993,73049]
===
match
---
name: self [21518,21522]
name: self [21518,21522]
===
match
---
name: var [63932,63935]
name: var [63884,63887]
===
match
---
except_clause [44829,44871]
except_clause [44829,44871]
===
match
---
name: self [24060,24064]
name: self [24060,24064]
===
match
---
operator: = [70156,70157]
operator: = [70108,70109]
===
match
---
simple_stmt [61839,61854]
simple_stmt [61791,61806]
===
match
---
simple_stmt [5310,5336]
simple_stmt [5310,5336]
===
match
---
operator: , [8778,8779]
operator: , [8778,8779]
===
match
---
trailer [60065,60067]
trailer [60017,60019]
===
match
---
number: 1 [82450,82451]
number: 1 [82402,82403]
===
match
---
atom_expr [53265,53292]
atom_expr [53264,53291]
===
match
---
name: failed [31757,31763]
name: failed [31757,31763]
===
match
---
trailer [57213,57228]
trailer [57212,57227]
===
match
---
funcdef [4711,7981]
funcdef [4711,7981]
===
match
---
parameters [63305,63482]
parameters [63257,63434]
===
match
---
param [14105,14124]
param [14105,14124]
===
match
---
atom_expr [4463,4485]
atom_expr [4463,4485]
===
match
---
name: are_dependents_done [25441,25460]
name: are_dependents_done [25441,25460]
===
match
---
name: pickle [4681,4687]
name: pickle [4681,4687]
===
match
---
string: 'TaskInstanceKey' [8650,8667]
string: 'TaskInstanceKey' [8650,8667]
===
match
---
expr_stmt [26832,26851]
expr_stmt [26832,26851]
===
match
---
tfpdef [11156,11176]
tfpdef [11156,11176]
===
match
---
operator: , [15984,15985]
operator: , [15984,15985]
===
match
---
tfpdef [24437,24447]
tfpdef [24437,24447]
===
match
---
trailer [78993,79001]
trailer [78945,78953]
===
match
---
expr_stmt [21996,22027]
expr_stmt [21996,22027]
===
match
---
name: delete_qry [7226,7236]
name: delete_qry [7226,7236]
===
match
---
trailer [82429,82431]
trailer [82381,82383]
===
match
---
argument [59358,59369]
argument [59310,59321]
===
match
---
decorated [21015,22928]
decorated [21015,22928]
===
match
---
arith_expr [19359,19442]
arith_expr [19359,19442]
===
match
---
trailer [22398,22408]
trailer [22398,22408]
===
match
---
operator: } [49365,49366]
operator: } [49365,49366]
===
match
---
operator: = [35848,35849]
operator: = [35848,35849]
===
match
---
name: file_path [15360,15369]
name: file_path [15360,15369]
===
match
---
name: Stats [56977,56982]
name: Stats [56976,56981]
===
match
---
tfpdef [53550,53578]
tfpdef [53549,53577]
===
match
---
trailer [21605,21619]
trailer [21605,21619]
===
match
---
name: session [57105,57112]
name: session [57104,57111]
===
match
---
name: session [7402,7409]
name: session [7402,7409]
===
match
---
trailer [23567,23583]
trailer [23567,23583]
===
match
---
simple_stmt [72651,72702]
simple_stmt [72603,72654]
===
match
---
trailer [26194,26214]
trailer [26194,26214]
===
match
---
atom_expr [78666,78674]
atom_expr [78618,78626]
===
match
---
suite [80718,80748]
suite [80670,80700]
===
match
---
trailer [46208,46215]
trailer [46208,46215]
===
match
---
trailer [71035,71047]
trailer [70987,70999]
===
match
---
name: getboolean [62545,62555]
name: getboolean [62497,62507]
===
match
---
simple_stmt [69547,69589]
simple_stmt [69499,69541]
===
match
---
name: deps [38248,38252]
name: deps [38248,38252]
===
match
---
fstring_string: . [33040,33041]
fstring_string: . [33040,33041]
===
match
---
name: Session [26537,26544]
name: Session [26537,26544]
===
match
---
name: self [57247,57251]
name: self [57246,57250]
===
match
---
return_stmt [63238,63258]
return_stmt [63190,63210]
===
match
---
param [73250,73274]
param [73202,73226]
===
match
---
simple_stmt [60280,60346]
simple_stmt [60232,60298]
===
match
---
atom_expr [79927,79944]
atom_expr [79879,79896]
===
match
---
operator: , [9537,9538]
operator: , [9537,9538]
===
match
---
trailer [5270,5276]
trailer [5270,5276]
===
match
---
name: error [59468,59473]
name: error [59420,59425]
===
match
---
name: job_ids [5310,5317]
name: job_ids [5310,5317]
===
match
---
if_stmt [59030,59080]
if_stmt [58982,59032]
===
match
---
operator: , [44010,44011]
operator: , [44010,44011]
===
match
---
trailer [67648,67707]
trailer [67600,67659]
===
match
---
atom_expr [41287,41306]
atom_expr [41287,41306]
===
match
---
atom_expr [22120,22130]
atom_expr [22120,22130]
===
match
---
simple_stmt [60844,60916]
simple_stmt [60796,60868]
===
match
---
atom_expr [32914,32931]
atom_expr [32914,32931]
===
match
---
string: """         Return the try number that this task number will be when it is actually         run.          If the TaskInstance is currently running, this will match the column in the         database, in all other cases this will be incremented.         """ [12717,12973]
string: """         Return the try number that this task number will be when it is actually         run.          If the TaskInstance is currently running, this will match the column in the         database, in all other cases this will be incremented.         """ [12717,12973]
===
match
---
name: state [22856,22861]
name: state [22856,22861]
===
match
---
simple_stmt [34680,34732]
simple_stmt [34680,34732]
===
match
---
parameters [51968,51998]
parameters [52006,52036]
===
match
---
name: dr [7887,7889]
name: dr [7887,7889]
===
match
---
name: ApiClient [69107,69116]
name: ApiClient [69059,69068]
===
match
---
name: max_tries [5950,5959]
name: max_tries [5950,5959]
===
match
---
simple_stmt [19535,19580]
simple_stmt [19535,19580]
===
match
---
name: TaskInstance [26229,26241]
name: TaskInstance [26229,26241]
===
match
---
trailer [8296,8303]
trailer [8296,8303]
===
match
---
operator: } [14789,14790]
operator: } [14789,14790]
===
match
---
trailer [18243,18251]
trailer [18243,18251]
===
match
---
atom_expr [8506,8598]
atom_expr [8506,8598]
===
match
---
atom_expr [77927,77935]
atom_expr [77879,77887]
===
match
---
atom_expr [36021,36034]
atom_expr [36021,36034]
===
match
---
name: jinja_env [71365,71374]
name: jinja_env [71317,71326]
===
match
---
operator: -> [81653,81655]
operator: -> [81605,81607]
===
match
---
expr_stmt [51518,51561]
expr_stmt [51556,51599]
===
match
---
name: jinja_context [72128,72141]
name: jinja_context [72080,72093]
===
match
---
atom_expr [80300,80314]
atom_expr [80252,80266]
===
match
---
operator: -> [73281,73283]
operator: -> [73233,73235]
===
match
---
name: retries [59596,59603]
name: retries [59548,59555]
===
match
---
name: String [10418,10424]
name: String [10418,10424]
===
match
---
operator: = [74589,74590]
operator: = [74541,74542]
===
match
---
trailer [57888,57909]
trailer [57887,57908]
===
match
---
operator: = [70904,70905]
operator: = [70856,70857]
===
match
---
trailer [18546,18553]
trailer [18546,18553]
===
match
---
atom_expr [57209,57228]
atom_expr [57208,57227]
===
match
---
param [81264,81268]
param [81216,81220]
===
match
---
trailer [6910,6914]
trailer [6910,6914]
===
match
---
suite [81054,81087]
suite [81006,81039]
===
match
---
tfpdef [41793,41814]
tfpdef [41793,41814]
===
match
---
expr_stmt [32461,32502]
expr_stmt [32461,32502]
===
match
---
name: Proxy [65291,65296]
name: Proxy [65243,65248]
===
match
---
trailer [65447,65453]
trailer [65399,65405]
===
match
---
argument [78915,78937]
argument [78867,78889]
===
match
---
arglist [69524,69536]
arglist [69476,69488]
===
match
---
suite [62984,63017]
suite [62936,62969]
===
match
---
simple_stmt [55331,55338]
simple_stmt [55330,55337]
===
match
---
trailer [3292,3302]
trailer [3292,3302]
===
match
---
operator: , [65863,65864]
operator: , [65815,65816]
===
match
---
name: xcom [77270,77274]
name: xcom [77222,77226]
===
match
---
expr_stmt [3196,3215]
expr_stmt [3196,3215]
===
match
---
name: test_mode [35980,35989]
name: test_mode [35980,35989]
===
match
---
operator: = [14313,14314]
operator: = [14313,14314]
===
match
---
operator: , [33963,33964]
operator: , [33963,33964]
===
match
---
argument [53979,54010]
argument [53978,54009]
===
match
---
name: self [56615,56619]
name: self [56614,56618]
===
match
---
trailer [11372,11382]
trailer [11372,11382]
===
match
---
suite [44092,44235]
suite [44092,44235]
===
match
---
atom [7796,7829]
atom [7796,7829]
===
match
---
name: ignore_all_deps [38302,38317]
name: ignore_all_deps [38302,38317]
===
match
---
annassign [80378,80400]
annassign [80330,80352]
===
match
---
name: self [80661,80665]
name: self [80613,80617]
===
match
---
string: '' [62334,62336]
string: '' [62286,62288]
===
match
---
trailer [22739,22748]
trailer [22739,22748]
===
match
---
string: 'execution_date' [45357,45373]
string: 'execution_date' [45357,45373]
===
match
---
operator: + [40315,40316]
operator: + [40315,40316]
===
match
---
name: html_content [72222,72234]
name: html_content [72174,72186]
===
match
---
name: e [67607,67608]
name: e [67559,67560]
===
match
---
param [35178,35201]
param [35178,35201]
===
match
---
trailer [54998,55020]
trailer [54997,55019]
===
match
---
expr_stmt [42804,42824]
expr_stmt [42804,42824]
===
match
---
name: ti [22096,22098]
name: ti [22096,22098]
===
match
---
funcdef [80693,80748]
funcdef [80645,80700]
===
match
---
name: self [48335,48339]
name: self [48335,48339]
===
match
---
atom_expr [34616,34667]
atom_expr [34616,34667]
===
match
---
trailer [63428,63459]
trailer [63380,63411]
===
match
---
name: UP_FOR_RESCHEDULE [55782,55799]
name: UP_FOR_RESCHEDULE [55781,55798]
===
match
---
dotted_name [3101,3133]
dotted_name [3101,3133]
===
match
---
name: VariableJsonAccessor [65998,66018]
name: VariableJsonAccessor [65950,65970]
===
match
---
name: self [12086,12090]
name: self [12086,12090]
===
match
---
expr_stmt [70131,70519]
expr_stmt [70083,70471]
===
match
---
name: self [56889,56893]
name: self [56888,56892]
===
match
---
trailer [67899,67904]
trailer [67851,67856]
===
match
---
string: 'start_date' [43948,43960]
string: 'start_date' [43948,43960]
===
match
---
trailer [40370,40385]
trailer [40370,40385]
===
match
---
trailer [70960,70970]
trailer [70912,70922]
===
match
---
trailer [61248,61265]
trailer [61200,61217]
===
match
---
name: t [78992,78993]
name: t [78944,78945]
===
match
---
arglist [19063,19091]
arglist [19063,19091]
===
match
---
annassign [39183,39247]
annassign [39183,39247]
===
match
---
name: jinja_context [71319,71332]
name: jinja_context [71271,71284]
===
match
---
atom_expr [33724,33739]
atom_expr [33724,33739]
===
match
---
expr_stmt [31958,31971]
expr_stmt [31958,31971]
===
match
---
name: ti [22326,22328]
name: ti [22326,22328]
===
match
---
simple_stmt [72303,72380]
simple_stmt [72255,72332]
===
match
---
operator: = [24801,24802]
operator: = [24801,24802]
===
match
---
trailer [49651,49666]
trailer [49651,49666]
===
match
---
name: num [47702,47705]
name: num [47702,47705]
===
match
---
name: log [43309,43312]
name: log [43309,43312]
===
match
---
name: provide_session [29119,29134]
name: provide_session [29119,29134]
===
match
---
operator: = [34705,34706]
operator: = [34705,34706]
===
match
---
operator: -> [59321,59323]
operator: -> [59273,59275]
===
match
---
name: self [22436,22440]
name: self [22436,22440]
===
match
---
operator: , [44763,44764]
operator: , [44763,44764]
===
match
---
operator: , [71707,71708]
operator: , [71659,71660]
===
match
---
operator: , [50692,50693]
operator: , [50730,50731]
===
match
---
name: ti [80555,80557]
name: ti [80507,80509]
===
match
---
trailer [20511,20513]
trailer [20511,20513]
===
match
---
name: info [49271,49275]
name: info [49271,49275]
===
match
---
name: self [35172,35176]
name: self [35172,35176]
===
match
---
import_from [82557,82597]
import_from [82509,82549]
===
match
---
simple_stmt [67280,67351]
simple_stmt [67232,67303]
===
match
---
atom_expr [5241,5250]
atom_expr [5241,5250]
===
match
---
atom_expr [70905,70920]
atom_expr [70857,70872]
===
match
---
subscriptlist [8193,8211]
subscriptlist [8193,8211]
===
match
---
atom_expr [24972,24985]
atom_expr [24972,24985]
===
match
---
decorator [59827,59844]
decorator [59779,59796]
===
match
---
operator: = [30937,30938]
operator: = [30937,30938]
===
match
---
operator: , [73273,73274]
operator: , [73225,73226]
===
match
---
trailer [51544,51561]
trailer [51582,51599]
===
match
---
string: """         Clears all XCom data from the database for the task instance          :param session: SQLAlchemy ORM Session         :type session: Session         """ [23698,23861]
string: """         Clears all XCom data from the database for the task instance          :param session: SQLAlchemy ORM Session         :type session: Session         """ [23698,23861]
===
match
---
operator: = [77275,77276]
operator: = [77227,77228]
===
match
---
parameters [73137,73280]
parameters [73089,73232]
===
match
---
name: exc_info [48017,48025]
name: exc_info [48017,48025]
===
match
---
name: task_copy [49535,49544]
name: task_copy [49535,49544]
===
match
---
not_test [69450,69475]
not_test [69402,69427]
===
match
---
operator: = [61877,61878]
operator: = [61829,61830]
===
match
---
trailer [7460,7462]
trailer [7460,7462]
===
match
---
name: self [44742,44746]
name: self [44742,44746]
===
match
---
name: executor_namespace [68917,68935]
name: executor_namespace [68869,68887]
===
match
---
name: _pool [80328,80333]
name: _pool [80280,80285]
===
match
---
simple_stmt [41230,41308]
simple_stmt [41230,41308]
===
match
---
trailer [47638,47706]
trailer [47638,47706]
===
match
---
atom_expr [40055,40337]
atom_expr [40055,40337]
===
match
---
trailer [12173,12182]
trailer [12173,12182]
===
match
---
name: str [56161,56164]
name: str [56160,56163]
===
match
---
trailer [33712,33714]
trailer [33712,33714]
===
match
---
trailer [68523,68531]
trailer [68475,68483]
===
match
---
string: 'Host: {{ti.hostname}}<br>' [69961,69988]
string: 'Host: {{ti.hostname}}<br>' [69913,69940]
===
match
---
string: 'value' [66038,66045]
string: 'value' [65990,65997]
===
match
---
param [19192,19196]
param [19192,19196]
===
match
---
operator: , [71922,71923]
operator: , [71874,71875]
===
match
---
atom_expr [46256,46275]
atom_expr [46256,46275]
===
match
---
simple_stmt [10267,10302]
simple_stmt [10267,10302]
===
match
---
trailer [50978,50984]
trailer [51016,51022]
===
match
---
atom_expr [5548,5560]
atom_expr [5548,5560]
===
match
---
trailer [82112,82119]
trailer [82064,82071]
===
match
---
trailer [27157,27178]
trailer [27157,27178]
===
match
---
simple_stmt [52008,52070]
simple_stmt [52046,52108]
===
match
---
trailer [59067,59073]
trailer [59019,59025]
===
match
---
atom_expr [35451,35589]
atom_expr [35451,35589]
===
match
---
argument [54523,54542]
argument [54522,54541]
===
match
---
operator: , [58586,58587]
operator: , [58585,58586]
===
match
---
name: self [77726,77730]
name: self [77678,77682]
===
match
---
expr_stmt [7947,7980]
expr_stmt [7947,7980]
===
match
---
argument [42779,42794]
argument [42779,42794]
===
match
---
operator: , [53808,53809]
operator: , [53807,53808]
===
match
---
operator: = [37513,37514]
operator: = [37513,37514]
===
match
---
name: task_reschedule [39322,39337]
name: task_reschedule [39322,39337]
===
match
---
string: "previous_execution_date was called" [29541,29577]
string: "previous_execution_date was called" [29541,29577]
===
match
---
trailer [28571,28573]
trailer [28571,28573]
===
match
---
atom_expr [29857,29874]
atom_expr [29857,29874]
===
match
---
name: TaskInstance [21606,21618]
name: TaskInstance [21606,21618]
===
match
---
suite [63910,63943]
suite [63862,63895]
===
match
---
name: error [56624,56629]
name: error [56623,56628]
===
match
---
trailer [11835,11844]
trailer [11835,11844]
===
match
---
name: cmd [18597,18600]
name: cmd [18597,18600]
===
match
---
dotted_name [2495,2526]
dotted_name [2495,2526]
===
match
---
operator: , [78872,78873]
operator: , [78824,78825]
===
match
---
name: execution_date [27163,27177]
name: execution_date [27163,27177]
===
match
---
trailer [52644,52651]
trailer [52643,52650]
===
match
---
name: self [23970,23974]
name: self [23970,23974]
===
match
---
expr_stmt [12460,12482]
expr_stmt [12460,12482]
===
match
---
name: task [52098,52102]
name: task [52136,52140]
===
match
---
name: self [23458,23462]
name: self [23458,23462]
===
match
---
name: TaskReschedule [55476,55490]
name: TaskReschedule [55475,55489]
===
match
---
param [80875,80879]
param [80827,80831]
===
match
---
suite [58904,59021]
suite [58894,58973]
===
match
---
string: 'run_id' [65556,65564]
string: 'run_id' [65508,65516]
===
match
---
name: duration [9764,9772]
name: duration [9764,9772]
===
match
---
or_test [22602,22620]
or_test [22602,22620]
===
match
---
trailer [51095,51144]
trailer [51133,51182]
===
match
---
name: info [40711,40715]
name: info [40711,40715]
===
match
---
not_test [39864,39949]
not_test [39864,39949]
===
match
---
atom_expr [23279,23289]
atom_expr [23279,23289]
===
match
---
name: AirflowRescheduleException [1700,1726]
name: AirflowRescheduleException [1700,1726]
===
match
---
name: self [19429,19433]
name: self [19429,19433]
===
match
---
name: bool [41738,41742]
name: bool [41738,41742]
===
match
---
name: session [50993,51000]
name: session [51031,51038]
===
match
---
operator: = [68551,68552]
operator: = [68503,68504]
===
match
---
param [26528,26551]
param [26528,26551]
===
match
---
trailer [24064,24079]
trailer [24064,24079]
===
match
---
parameters [18923,18929]
parameters [18923,18929]
===
match
---
operator: = [69563,69564]
operator: = [69515,69516]
===
match
---
trailer [40710,40715]
trailer [40710,40715]
===
match
---
operator: } [45052,45053]
operator: } [45052,45053]
===
match
---
param [74643,74670]
param [74595,74622]
===
match
---
argument [68511,68531]
argument [68463,68483]
===
match
---
operator: , [29813,29814]
operator: , [29813,29814]
===
match
---
name: is_container [2477,2489]
name: is_container [2477,2489]
===
match
---
name: seek [4053,4057]
name: seek [4053,4057]
===
match
---
name: dr [27365,27367]
name: dr [27365,27367]
===
match
---
trailer [40071,40337]
trailer [40071,40337]
===
match
---
param [74722,74746]
param [74674,74698]
===
match
---
exprlist [66520,66546]
exprlist [66472,66498]
===
match
---
simple_stmt [11316,11345]
simple_stmt [11316,11345]
===
match
---
name: DagRun [35523,35529]
name: DagRun [35523,35529]
===
match
---
trailer [44144,44163]
trailer [44144,44163]
===
match
---
simple_stmt [32244,32302]
simple_stmt [32244,32302]
===
match
---
operator: } [33076,33077]
operator: } [33076,33077]
===
match
---
string: '' [62143,62145]
string: '' [62095,62097]
===
match
---
trailer [45598,45604]
trailer [45598,45604]
===
match
---
name: quote [1128,1133]
name: quote [1128,1133]
===
match
---
simple_stmt [38190,38512]
simple_stmt [38190,38512]
===
match
---
trailer [64377,64408]
trailer [64329,64360]
===
match
---
trailer [6682,6689]
trailer [6682,6689]
===
match
---
name: task_id [77731,77738]
name: task_id [77683,77690]
===
match
---
suite [66665,67181]
suite [66617,67133]
===
match
---
name: raw [77932,77935]
name: raw [77884,77887]
===
match
---
expr_stmt [54982,55022]
expr_stmt [54981,55021]
===
match
---
atom_expr [77277,77316]
atom_expr [77229,77268]
===
match
---
argument [27312,27350]
argument [27312,27350]
===
match
---
name: airflow [2595,2602]
name: airflow [2595,2602]
===
match
---
trailer [74567,74587]
trailer [74519,74539]
===
match
---
suite [13309,13343]
suite [13309,13343]
===
match
---
atom_expr [24956,24969]
atom_expr [24956,24969]
===
match
---
operator: = [68865,68866]
operator: = [68817,68818]
===
match
---
trailer [20881,20922]
trailer [20881,20922]
===
match
---
name: self [58618,58622]
name: self [58617,58621]
===
match
---
name: context [43134,43141]
name: context [43134,43141]
===
match
---
param [62978,62982]
param [62930,62934]
===
match
---
string: """Returns SQLAlchemy filter to query selected task instances""" [78111,78175]
string: """Returns SQLAlchemy filter to query selected task instances""" [78063,78127]
===
match
---
decorator [19166,19176]
decorator [19166,19176]
===
match
---
arglist [53950,54313]
arglist [53949,54312]
===
match
---
name: mark_success [43004,43016]
name: mark_success [43004,43016]
===
match
---
name: self [64129,64133]
name: self [64081,64085]
===
match
---
name: operator_helpers [2609,2625]
name: operator_helpers [2609,2625]
===
match
---
decorator [56085,56102]
decorator [56084,56101]
===
match
---
atom_expr [41582,41612]
atom_expr [41582,41612]
===
match
---
trailer [18380,18387]
trailer [18380,18387]
===
match
---
suite [72638,72702]
suite [72590,72654]
===
match
---
suite [82506,82702]
suite [82458,82654]
===
match
---
argument [76500,76534]
argument [76452,76486]
===
match
---
param [55227,55239]
param [55226,55238]
===
match
---
return_stmt [27247,27258]
return_stmt [27247,27258]
===
match
---
simple_stmt [55031,55053]
simple_stmt [55030,55052]
===
match
---
operator: , [45883,45884]
operator: , [45883,45884]
===
match
---
name: operator [22726,22734]
name: operator [22726,22734]
===
match
---
return_stmt [59812,59821]
return_stmt [59764,59773]
===
match
---
name: Column [10204,10210]
name: Column [10204,10210]
===
match
---
trailer [49275,49429]
trailer [49275,49429]
===
match
---
fstring_expr [19707,19721]
fstring_expr [19707,19721]
===
match
---
name: utils [2866,2871]
name: utils [2866,2871]
===
match
---
name: airflow [2293,2300]
name: airflow [2293,2300]
===
match
---
suite [48156,50735]
suite [48156,50773]
===
match
---
name: rendered_k8s_spec [67497,67514]
name: rendered_k8s_spec [67449,67466]
===
match
---
argument [29032,29044]
argument [29032,29044]
===
match
---
name: get_template_context [53039,53059]
name: get_template_context [53038,53058]
===
match
---
name: get_email_subject_content [69189,69214]
name: get_email_subject_content [69141,69166]
===
match
---
trailer [51386,51404]
trailer [51424,51442]
===
match
---
operator: = [22816,22817]
operator: = [22816,22817]
===
match
---
suite [52652,52884]
suite [52651,52883]
===
match
---
name: prepare_for_execution [54999,55020]
name: prepare_for_execution [54998,55019]
===
match
---
name: TaskInstance [82603,82615]
name: TaskInstance [82555,82567]
===
match
---
trailer [10661,10700]
trailer [10661,10700]
===
match
---
arglist [33837,34077]
arglist [33837,34077]
===
match
---
name: TR [6900,6902]
name: TR [6900,6902]
===
match
---
trailer [65296,65389]
trailer [65248,65341]
===
match
---
simple_stmt [66699,66723]
simple_stmt [66651,66675]
===
match
---
name: session [38676,38683]
name: session [38676,38683]
===
match
---
name: from_string [71276,71287]
name: from_string [71228,71239]
===
match
---
operator: == [5208,5210]
operator: == [5208,5210]
===
match
---
name: SUCCESS [44661,44668]
name: SUCCESS [44661,44668]
===
match
---
atom_expr [39868,39949]
atom_expr [39868,39949]
===
match
---
operator: , [54505,54506]
operator: , [54504,54505]
===
match
---
decorator [41657,41679]
decorator [41657,41679]
===
match
---
name: ignore_all_deps [15106,15121]
name: ignore_all_deps [15106,15121]
===
match
---
trailer [5327,5334]
trailer [5327,5334]
===
match
---
operator: -> [8376,8378]
operator: -> [8376,8378]
===
match
---
parameters [3946,3961]
parameters [3946,3961]
===
match
---
simple_stmt [33139,33317]
simple_stmt [33139,33317]
===
match
---
simple_stmt [18877,18888]
simple_stmt [18877,18888]
===
match
---
simple_stmt [39304,39349]
simple_stmt [39304,39349]
===
match
---
expr_stmt [14861,14885]
expr_stmt [14861,14885]
===
match
---
name: task_id [47305,47312]
name: task_id [47305,47312]
===
match
---
operator: , [46275,46276]
operator: , [46275,46276]
===
match
---
trailer [25101,25107]
trailer [25101,25107]
===
match
---
funcdef [20657,21010]
funcdef [20657,21010]
===
match
---
name: session [37646,37653]
name: session [37646,37653]
===
match
---
operator: = [5084,5085]
operator: = [5084,5085]
===
match
---
trailer [59631,59641]
trailer [59583,59593]
===
match
---
atom_expr [9926,9946]
atom_expr [9926,9946]
===
match
---
simple_stmt [29656,29717]
simple_stmt [29656,29717]
===
match
---
if_stmt [18118,18185]
if_stmt [18118,18185]
===
match
---
name: ti [22818,22820]
name: ti [22818,22820]
===
match
---
param [51174,51182]
param [51212,51220]
===
match
---
atom_expr [44742,44798]
atom_expr [44742,44798]
===
match
---
trailer [52949,52954]
trailer [52948,52953]
===
match
---
name: ignore_task_deps [15168,15184]
name: ignore_task_deps [15168,15184]
===
match
---
name: self [48737,48741]
name: self [48737,48741]
===
match
---
operator: = [16052,16053]
operator: = [16052,16053]
===
match
---
trailer [59467,59480]
trailer [59419,59432]
===
match
---
name: _run_finished_callback [54841,54863]
name: _run_finished_callback [54840,54862]
===
match
---
operator: = [5108,5109]
operator: = [5108,5109]
===
match
---
operator: = [22778,22779]
operator: = [22778,22779]
===
match
---
name: dag_run [61241,61248]
name: dag_run [61193,61200]
===
match
---
name: airflow [1581,1588]
name: airflow [1581,1588]
===
match
---
name: Column [9650,9656]
name: Column [9650,9656]
===
match
---
expr_stmt [40846,40872]
expr_stmt [40846,40872]
===
match
---
funcdef [8604,8827]
funcdef [8604,8827]
===
match
---
trailer [8573,8597]
trailer [8573,8597]
===
match
---
operator: -> [68337,68339]
operator: -> [68289,68291]
===
match
---
operator: = [11062,11063]
operator: = [11062,11063]
===
match
---
name: task_type [57014,57023]
name: task_type [57013,57022]
===
match
---
operator: , [14340,14341]
operator: , [14340,14341]
===
match
---
simple_stmt [71166,71239]
simple_stmt [71118,71191]
===
match
---
operator: , [45272,45273]
operator: , [45272,45273]
===
match
---
name: mark_success [38039,38051]
name: mark_success [38039,38051]
===
match
---
simple_stmt [31757,31772]
simple_stmt [31757,31772]
===
match
---
simple_stmt [61279,61321]
simple_stmt [61231,61273]
===
match
---
simple_stmt [44701,44708]
simple_stmt [44701,44708]
===
match
---
name: contextmanager [3327,3341]
name: contextmanager [3327,3341]
===
match
---
param [13938,13942]
param [13938,13942]
===
match
---
comparison [56394,56411]
comparison [56393,56410]
===
match
---
trailer [11225,11232]
trailer [11225,11232]
===
match
---
name: external_trigger [61249,61265]
name: external_trigger [61201,61217]
===
match
---
name: state [7488,7493]
name: state [7488,7493]
===
match
---
atom_expr [82200,82227]
atom_expr [82152,82179]
===
match
---
simple_stmt [2853,2895]
simple_stmt [2853,2895]
===
match
---
trailer [42946,42953]
trailer [42946,42953]
===
match
---
string: 'test_mode' [65696,65707]
string: 'test_mode' [65648,65659]
===
match
---
operator: = [20942,20943]
operator: = [20942,20943]
===
match
---
trailer [19576,19578]
trailer [19576,19578]
===
match
---
name: start_date [50926,50936]
name: start_date [50964,50974]
===
match
---
import_name [1161,1185]
import_name [1161,1185]
===
match
---
expr_stmt [67497,67543]
expr_stmt [67449,67495]
===
match
---
name: debug [32663,32668]
name: debug [32663,32668]
===
match
---
trailer [65713,65723]
trailer [65665,65675]
===
match
---
name: try_number [5595,5605]
name: try_number [5595,5605]
===
match
---
trailer [55692,55708]
trailer [55691,55707]
===
match
---
simple_stmt [60141,60156]
simple_stmt [60093,60108]
===
match
---
name: set_duration [45491,45503]
name: set_duration [45491,45503]
===
match
---
name: self [35736,35740]
name: self [35736,35740]
===
match
---
trailer [79858,79867]
trailer [79810,79819]
===
match
---
name: task_id [20404,20411]
name: task_id [20404,20411]
===
match
---
name: fmt [59679,59682]
name: fmt [59631,59634]
===
match
---
operator: = [39905,39906]
operator: = [39905,39906]
===
match
---
name: self [12012,12016]
name: self [12012,12016]
===
match
---
operator: - [72951,72952]
operator: - [72903,72904]
===
match
---
trailer [40618,40622]
trailer [40618,40622]
===
match
---
atom_expr [29597,29647]
atom_expr [29597,29647]
===
match
---
trailer [66617,66622]
trailer [66569,66574]
===
match
---
atom_expr [40614,40693]
atom_expr [40614,40693]
===
match
---
param [59173,59178]
param [59125,59130]
===
match
---
decorated [81162,81225]
decorated [81114,81177]
===
match
---
name: provide_session [21016,21031]
name: provide_session [21016,21031]
===
match
---
operator: - [34663,34664]
operator: - [34663,34664]
===
match
---
comparison [21688,21724]
comparison [21688,21724]
===
match
---
name: dep_status [32914,32924]
name: dep_status [32914,32924]
===
match
---
name: session [26049,26056]
name: session [26049,26056]
===
match
---
funcdef [51943,52344]
funcdef [51981,52343]
===
match
---
name: test_mode [44347,44356]
name: test_mode [44347,44356]
===
match
---
name: session [45591,45598]
name: session [45591,45598]
===
match
---
suite [19198,19443]
suite [19198,19443]
===
match
---
trailer [6125,6136]
trailer [6125,6136]
===
match
---
decorator [23628,23645]
decorator [23628,23645]
===
match
---
name: sqlalchemy [2769,2779]
name: sqlalchemy [2769,2779]
===
match
---
string: 'email' [71915,71922]
string: 'email' [71867,71874]
===
match
---
operator: = [6026,6027]
operator: = [6026,6027]
===
match
---
operator: == [20396,20398]
operator: == [20396,20398]
===
match
---
name: mark_success [15656,15668]
name: mark_success [15656,15668]
===
match
---
trailer [19287,19289]
trailer [19287,19289]
===
match
---
atom_expr [76444,76455]
atom_expr [76396,76407]
===
match
---
name: force_fail [56228,56238]
name: force_fail [56227,56237]
===
match
---
trailer [40023,40038]
trailer [40023,40038]
===
match
---
name: dag_id [8527,8533]
name: dag_id [8527,8533]
===
match
---
name: state [35052,35057]
name: state [35052,35057]
===
match
---
name: _end_date [80997,81006]
name: _end_date [80949,80958]
===
match
---
atom [18227,18252]
atom [18227,18252]
===
match
---
decorated [73103,74430]
decorated [73055,74382]
===
match
---
name: strftime [62187,62195]
name: strftime [62139,62147]
===
match
---
trailer [45117,45124]
trailer [45117,45124]
===
match
---
argument [68479,68497]
argument [68431,68449]
===
match
---
trailer [57046,57051]
trailer [57045,57050]
===
match
---
fstring_expr [50670,50691]
fstring_expr [50708,50729]
===
match
---
name: error_fd [54389,54397]
name: error_fd [54388,54396]
===
match
---
atom_expr [45286,45297]
atom_expr [45286,45297]
===
match
---
name: k [49364,49365]
name: k [49364,49365]
===
match
---
expr_stmt [60844,60915]
expr_stmt [60796,60867]
===
match
---
import_from [2011,2055]
import_from [2011,2055]
===
match
---
expr_stmt [60141,60155]
expr_stmt [60093,60107]
===
match
---
name: dag_id [78981,78987]
name: dag_id [78933,78939]
===
match
---
operator: = [49816,49817]
operator: = [49816,49817]
===
match
---
name: int [15905,15908]
name: int [15905,15908]
===
match
---
operator: , [57245,57246]
operator: , [57244,57245]
===
match
---
param [53818,53831]
param [53817,53830]
===
match
---
trailer [34044,34054]
trailer [34044,34054]
===
match
---
name: content [71870,71877]
name: content [71822,71829]
===
match
---
atom_expr [55763,55773]
atom_expr [55762,55772]
===
match
---
parameters [53419,53837]
parameters [53418,53836]
===
match
---
name: state [30932,30937]
name: state [30932,30937]
===
match
---
name: self [20867,20871]
name: self [20867,20871]
===
match
---
parameters [24430,24462]
parameters [24430,24462]
===
match
---
operator: { [62420,62421]
operator: { [62372,62373]
===
match
---
atom_expr [57182,57262]
atom_expr [57181,57261]
===
match
---
atom_expr [7797,7814]
atom_expr [7797,7814]
===
match
---
trailer [67541,67543]
trailer [67493,67495]
===
match
---
trailer [37519,37524]
trailer [37519,37524]
===
match
---
atom_expr [64064,64105]
atom_expr [64016,64057]
===
match
---
trailer [30447,30466]
trailer [30447,30466]
===
match
---
simple_stmt [44742,44799]
simple_stmt [44742,44799]
===
match
---
name: airflow [66301,66308]
name: airflow [66253,66260]
===
match
---
comparison [39113,39150]
comparison [39113,39150]
===
match
---
name: self [45605,45609]
name: self [45605,45609]
===
match
---
name: all [7457,7460]
name: all [7457,7460]
===
match
---
name: Any [1041,1044]
name: Any [1041,1044]
===
match
---
arglist [10616,10645]
arglist [10616,10645]
===
match
---
suite [61639,61830]
suite [61591,61782]
===
match
---
name: item [63151,63155]
name: item [63103,63107]
===
match
---
name: session [55957,55964]
name: session [55956,55963]
===
match
---
name: relationship [82626,82638]
name: relationship [82578,82590]
===
match
---
arglist [10662,10699]
arglist [10662,10699]
===
match
---
name: Session [35187,35194]
name: Session [35187,35194]
===
match
---
name: convert_to_utc [11972,11986]
name: convert_to_utc [11972,11986]
===
match
---
trailer [49057,49084]
trailer [49057,49084]
===
match
---
name: self [24790,24794]
name: self [24790,24794]
===
match
---
name: self [46712,46716]
name: self [46712,46716]
===
match
---
operator: = [30170,30171]
operator: = [30170,30171]
===
match
---
simple_stmt [41511,41538]
simple_stmt [41511,41538]
===
match
---
atom_expr [22080,22093]
atom_expr [22080,22093]
===
match
---
comparison [35084,35130]
comparison [35084,35130]
===
match
---
name: job [7484,7487]
name: job [7484,7487]
===
match
---
name: Optional [15896,15904]
name: Optional [15896,15904]
===
match
---
name: log [43533,43536]
name: log [43533,43536]
===
match
---
name: bool [35922,35926]
name: bool [35922,35926]
===
match
---
name: base_job [82529,82537]
name: base_job [82481,82489]
===
match
---
name: Sentry [2198,2204]
name: Sentry [2198,2204]
===
match
---
comparison [25347,25379]
comparison [25347,25379]
===
match
---
param [32988,32992]
param [32988,32992]
===
match
---
string: "Task failed with exception" [56551,56579]
string: "Task failed with exception" [56550,56578]
===
match
---
simple_stmt [60121,60133]
simple_stmt [60073,60085]
===
match
---
name: str [63245,63248]
name: str [63197,63200]
===
match
---
simple_stmt [10306,10328]
simple_stmt [10306,10328]
===
match
---
name: total_seconds [51480,51493]
name: total_seconds [51518,51531]
===
match
---
name: dag_id [19751,19757]
name: dag_id [19751,19757]
===
match
---
name: field_name [66520,66530]
name: field_name [66472,66482]
===
match
---
trailer [58826,58833]
trailer [58825,58832]
===
match
---
decorator [81012,81022]
decorator [80964,80974]
===
match
---
tfpdef [74679,74704]
tfpdef [74631,74656]
===
match
---
atom_expr [48335,48344]
atom_expr [48335,48344]
===
match
---
name: provide_session [50741,50756]
name: provide_session [50779,50794]
===
match
---
name: self [32988,32992]
name: self [32988,32992]
===
match
---
simple_stmt [40881,40904]
simple_stmt [40881,40904]
===
match
---
name: num [47565,47568]
name: num [47565,47568]
===
match
---
name: _execution_date [80825,80840]
name: _execution_date [80777,80792]
===
match
---
trailer [61449,61470]
trailer [61401,61422]
===
match
---
operator: , [20357,20358]
operator: , [20357,20358]
===
match
---
name: tis [79497,79500]
name: tis [79449,79452]
===
match
---
simple_stmt [63001,63017]
simple_stmt [62953,62969]
===
match
---
trailer [39337,39348]
trailer [39337,39348]
===
match
---
trailer [30349,30358]
trailer [30349,30358]
===
match
---
name: dependencies_deps [2309,2326]
name: dependencies_deps [2309,2326]
===
match
---
expr_stmt [34163,34212]
expr_stmt [34163,34212]
===
match
---
name: next_execution_date [61333,61352]
name: next_execution_date [61285,61304]
===
match
---
simple_stmt [26595,26824]
simple_stmt [26595,26824]
===
match
---
trailer [19004,19014]
trailer [19004,19014]
===
match
---
atom_expr [65052,65064]
atom_expr [65004,65016]
===
match
---
atom_expr [25361,25379]
atom_expr [25361,25379]
===
match
---
dotted_name [2595,2625]
dotted_name [2595,2625]
===
match
---
suite [53007,53112]
suite [53006,53111]
===
match
---
simple_stmt [22807,22825]
simple_stmt [22807,22825]
===
match
---
atom_expr [48855,48893]
atom_expr [48855,48893]
===
match
---
name: test_mode [12465,12474]
name: test_mode [12465,12474]
===
match
---
simple_stmt [39558,39849]
simple_stmt [39558,39849]
===
match
---
name: mark_success [41200,41212]
name: mark_success [41200,41212]
===
match
---
name: self [22721,22725]
name: self [22721,22725]
===
match
---
name: utcnow [50948,50954]
name: utcnow [50986,50992]
===
match
---
atom_expr [64053,64061]
atom_expr [64005,64013]
===
match
---
trailer [22566,22571]
trailer [22566,22571]
===
match
---
trailer [65483,65507]
trailer [65435,65459]
===
match
---
string: 'ti_state_lkp' [10750,10764]
string: 'ti_state_lkp' [10750,10764]
===
match
---
operator: = [22980,22981]
operator: = [22980,22981]
===
match
---
name: self [42833,42837]
name: self [42833,42837]
===
match
---
operator: , [54010,54011]
operator: , [54009,54010]
===
match
---
name: incr [42925,42929]
name: incr [42925,42929]
===
match
---
operator: = [39943,39944]
operator: = [39943,39944]
===
match
---
name: session [46140,46147]
name: session [46140,46147]
===
match
---
name: session [45620,45627]
name: session [45620,45627]
===
match
---
operator: , [62390,62391]
operator: , [62342,62343]
===
match
---
trailer [26086,26094]
trailer [26086,26094]
===
match
---
name: self [71812,71816]
name: self [71764,71768]
===
match
---
name: execution_date [64813,64827]
name: execution_date [64765,64779]
===
match
---
operator: = [82462,82463]
operator: = [82414,82415]
===
match
---
expr_stmt [56882,56898]
expr_stmt [56881,56897]
===
match
---
return_stmt [41575,41612]
return_stmt [41575,41612]
===
match
---
arglist [4413,4429]
arglist [4413,4429]
===
match
---
not_test [47418,47453]
not_test [47418,47453]
===
match
---
name: conf [1610,1614]
name: conf [1610,1614]
===
match
---
expr_stmt [69547,69588]
expr_stmt [69499,69540]
===
match
---
argument [44776,44797]
argument [44776,44797]
===
match
---
param [20673,20685]
param [20673,20685]
===
match
---
atom_expr [68032,68044]
atom_expr [67984,67996]
===
match
---
atom_expr [57247,57260]
atom_expr [57246,57259]
===
match
---
name: self [81185,81189]
name: self [81137,81141]
===
match
---
operator: = [53263,53264]
operator: = [53262,53263]
===
match
---
simple_stmt [21996,22028]
simple_stmt [21996,22028]
===
match
---
return_stmt [77354,77389]
return_stmt [77306,77341]
===
match
---
parameters [11117,11184]
parameters [11117,11184]
===
match
---
string: """Get Airflow Variable value""" [63500,63532]
string: """Get Airflow Variable value""" [63452,63484]
===
match
---
comparison [35493,35521]
comparison [35493,35521]
===
match
---
arglist [9512,9536]
arglist [9512,9536]
===
match
---
trailer [33061,33076]
trailer [33061,33076]
===
match
---
atom_expr [9498,9556]
atom_expr [9498,9556]
===
match
---
trailer [4687,4692]
trailer [4687,4692]
===
match
---
simple_stmt [42701,42750]
simple_stmt [42701,42750]
===
match
---
name: self [58810,58814]
name: self [58809,58813]
===
match
---
atom_expr [80380,80393]
atom_expr [80332,80345]
===
match
---
name: error [48457,48462]
name: error [48457,48462]
===
match
---
name: elements [1512,1520]
name: elements [1512,1520]
===
match
---
trailer [77662,77669]
trailer [77614,77621]
===
match
---
suite [41498,41613]
suite [41498,41613]
===
match
---
atom_expr [44885,44941]
atom_expr [44885,44941]
===
match
---
trailer [5579,5589]
trailer [5579,5589]
===
match
---
tfpdef [41760,41775]
tfpdef [41760,41775]
===
match
---
name: IO [3951,3953]
name: IO [3951,3953]
===
match
---
operator: , [79184,79185]
operator: , [79136,79137]
===
match
---
name: t [78969,78970]
name: t [78921,78922]
===
match
---
name: self [81354,81358]
name: self [81306,81310]
===
match
---
name: self [19407,19411]
name: self [19407,19411]
===
match
---
trailer [30176,30192]
trailer [30176,30192]
===
match
---
name: provide_session [59828,59843]
name: provide_session [59780,59795]
===
match
---
name: self [58921,58925]
name: self [58911,58915]
===
match
---
name: render [72119,72125]
name: render [72071,72077]
===
match
---
name: iso [19535,19538]
name: iso [19535,19538]
===
match
---
trailer [47523,47547]
trailer [47523,47547]
===
match
---
string: """Returns a tuple that identifies the task instance uniquely""" [24230,24294]
string: """Returns a tuple that identifies the task instance uniquely""" [24230,24294]
===
match
---
atom_expr [72873,72886]
atom_expr [72825,72838]
===
match
---
name: str [74648,74651]
name: str [74600,74603]
===
match
---
operator: = [7633,7634]
operator: = [7633,7634]
===
match
---
operator: , [8575,8576]
operator: , [8575,8576]
===
match
---
simple_stmt [40999,41016]
simple_stmt [40999,41016]
===
match
---
name: get [77166,77169]
name: get [77118,77121]
===
match
---
atom_expr [80189,80206]
atom_expr [80141,80158]
===
match
---
funcdef [59848,66190]
funcdef [59800,66142]
===
match
---
param [81630,81651]
param [81582,81603]
===
match
---
atom_expr [80240,80266]
atom_expr [80192,80218]
===
match
---
atom_expr [24374,24389]
atom_expr [24374,24389]
===
match
---
arglist [47639,47705]
arglist [47639,47705]
===
match
---
atom_expr [64660,64668]
atom_expr [64612,64620]
===
match
---
name: task [53171,53175]
name: task [53170,53174]
===
match
---
operator: , [44373,44374]
operator: , [44373,44374]
===
match
---
name: tempfile [983,991]
name: tempfile [983,991]
===
match
---
operator: , [71122,71123]
operator: , [71074,71075]
===
match
---
operator: = [46825,46826]
operator: = [46825,46826]
===
match
---
name: models [67293,67299]
name: models [67245,67251]
===
match
---
operator: = [46255,46256]
operator: = [46255,46256]
===
match
---
name: self [56949,56953]
name: self [56948,56952]
===
match
---
param [77451,77456]
param [77403,77408]
===
match
---
import_as_names [2334,2364]
import_as_names [2334,2364]
===
match
---
expr_stmt [62115,62146]
expr_stmt [62067,62098]
===
match
---
name: DagRun [82591,82597]
name: DagRun [82543,82549]
===
match
---
atom_expr [6641,7216]
atom_expr [6641,7216]
===
match
---
trailer [23974,23981]
trailer [23974,23981]
===
match
---
name: info [56019,56023]
name: info [56018,56022]
===
match
---
name: queued_by_job_id [10267,10283]
name: queued_by_job_id [10267,10283]
===
match
---
name: self [73083,73087]
name: self [73035,73039]
===
match
---
simple_stmt [50823,50878]
simple_stmt [50861,50916]
===
match
---
expr_stmt [78358,78379]
expr_stmt [78310,78331]
===
match
---
name: property [81231,81239]
name: property [81183,81191]
===
match
---
argument [70802,70821]
argument [70754,70773]
===
match
---
string: '%Y-%m-%d' [60904,60914]
string: '%Y-%m-%d' [60856,60866]
===
match
---
if_stmt [62537,62682]
if_stmt [62489,62634]
===
match
---
trailer [77954,77967]
trailer [77906,77919]
===
match
---
name: state [25352,25357]
name: state [25352,25357]
===
match
---
suite [18584,18621]
suite [18584,18621]
===
match
---
simple_stmt [82422,82470]
simple_stmt [82374,82422]
===
match
---
name: res [53886,53889]
name: res [53885,53888]
===
match
---
atom_expr [74143,74162]
atom_expr [74095,74114]
===
match
---
decorator [59110,59127]
decorator [59062,59079]
===
match
---
name: datetime [80795,80803]
name: datetime [80747,80755]
===
match
---
trailer [71692,71703]
trailer [71644,71655]
===
match
---
name: str [4327,4330]
name: str [4327,4330]
===
match
---
atom_expr [23477,23493]
atom_expr [23477,23493]
===
match
---
name: _run_raw_task [41687,41700]
name: _run_raw_task [41687,41700]
===
match
---
name: TaskInstance [77650,77662]
name: TaskInstance [77602,77614]
===
match
---
name: filter [35486,35492]
name: filter [35486,35492]
===
match
---
name: kubernetes [2910,2920]
name: kubernetes [2910,2920]
===
match
---
argument [74403,74418]
argument [74355,74370]
===
match
---
name: task [66618,66622]
name: task [66570,66574]
===
match
---
name: state [12123,12128]
name: state [12123,12128]
===
match
---
name: ignore_all_deps [38318,38333]
name: ignore_all_deps [38318,38333]
===
match
---
fstring_string: . [45025,45026]
fstring_string: . [45025,45026]
===
match
---
trailer [64072,64076]
trailer [64024,64028]
===
match
---
name: getattr [41518,41525]
name: getattr [41518,41525]
===
match
---
name: context [50605,50612]
name: context [50643,50650]
===
match
---
name: prev_execution_date [61895,61914]
name: prev_execution_date [61847,61866]
===
match
---
operator: @ [77979,77980]
operator: @ [77931,77932]
===
match
---
atom_expr [48632,48646]
atom_expr [48632,48646]
===
match
---
name: dag_id [46197,46203]
name: dag_id [46197,46203]
===
match
---
trailer [39239,39245]
trailer [39239,39245]
===
match
---
name: job_id [22533,22539]
name: job_id [22533,22539]
===
match
---
name: set_current_context [50427,50446]
name: set_current_context [50465,50484]
===
match
---
trailer [48859,48876]
trailer [48859,48876]
===
match
---
name: error [59358,59363]
name: error [59310,59315]
===
match
---
funcdef [80860,80926]
funcdef [80812,80878]
===
match
---
trailer [82079,82086]
trailer [82031,82038]
===
match
---
simple_stmt [82651,82702]
simple_stmt [82603,82654]
===
match
---
operator: , [72775,72776]
operator: , [72727,72728]
===
match
---
name: hr_line_break [40591,40604]
name: hr_line_break [40591,40604]
===
match
---
trailer [34697,34731]
trailer [34697,34731]
===
match
---
param [53636,53666]
param [53635,53665]
===
match
---
trailer [60890,60893]
trailer [60842,60845]
===
match
---
annassign [80018,80042]
annassign [79970,79994]
===
match
---
decorator [63272,63286]
decorator [63224,63238]
===
match
---
name: conditions [7267,7277]
name: conditions [7267,7277]
===
match
---
trailer [50583,50596]
trailer [50621,50634]
===
match
---
trailer [69461,69475]
trailer [69413,69427]
===
match
---
expr_stmt [12169,12187]
expr_stmt [12169,12187]
===
match
---
suite [67463,67715]
suite [67415,67667]
===
match
---
name: self [29597,29601]
name: self [29597,29601]
===
match
---
expr_stmt [61401,61470]
expr_stmt [61353,61422]
===
match
---
dotted_name [1914,1937]
dotted_name [1914,1937]
===
match
---
name: exception [72463,72472]
name: exception [72415,72424]
===
match
---
name: DagRun [46154,46160]
name: DagRun [46154,46160]
===
match
---
name: str [80110,80113]
name: str [80062,80065]
===
match
---
name: Proxy [65448,65453]
name: Proxy [65400,65405]
===
match
---
name: lock_for_update [21812,21827]
name: lock_for_update [21812,21827]
===
match
---
name: Index [1298,1303]
name: Index [1298,1303]
===
match
---
if_stmt [39861,40537]
if_stmt [39861,40537]
===
match
---
trailer [72755,72760]
trailer [72707,72712]
===
match
---
trailer [79984,79995]
trailer [79936,79947]
===
match
---
name: refresh_from_task [37538,37555]
name: refresh_from_task [37538,37555]
===
match
---
trailer [38535,38556]
trailer [38535,38556]
===
match
---
name: dag_id [15541,15547]
name: dag_id [15541,15547]
===
match
---
operator: = [62306,62307]
operator: = [62258,62259]
===
match
---
trailer [81467,81472]
trailer [81419,81424]
===
match
---
trailer [68804,68813]
trailer [68756,68765]
===
match
---
arglist [72662,72700]
arglist [72614,72652]
===
match
---
operator: , [10805,10806]
operator: , [10805,10806]
===
match
---
expr_stmt [49865,49929]
expr_stmt [49865,49929]
===
match
---
name: state [10728,10733]
name: state [10728,10733]
===
match
---
argument [76569,76583]
argument [76521,76535]
===
match
---
name: expected_state [3895,3909]
name: expected_state [3895,3909]
===
match
---
name: execution_date [61306,61320]
name: execution_date [61258,61272]
===
match
---
suite [72999,73033]
suite [72951,72985]
===
match
---
atom_expr [50427,50455]
atom_expr [50465,50493]
===
match
---
operator: , [39934,39935]
operator: , [39934,39935]
===
match
---
atom_expr [22394,22408]
atom_expr [22394,22408]
===
match
---
trailer [53129,53135]
trailer [53128,53134]
===
match
---
funcdef [12687,13253]
funcdef [12687,13253]
===
match
---
operator: , [3983,3984]
operator: , [3983,3984]
===
match
---
operator: = [54566,54567]
operator: = [54565,54566]
===
match
---
name: State [5279,5284]
name: State [5279,5284]
===
match
---
name: session [21062,21069]
name: session [21062,21069]
===
match
---
operator: , [39784,39785]
operator: , [39784,39785]
===
match
---
operator: , [70970,70971]
operator: , [70922,70923]
===
match
---
trailer [35051,35057]
trailer [35051,35057]
===
match
---
atom_expr [26317,26330]
atom_expr [26317,26330]
===
match
---
funcdef [59647,59822]
funcdef [59599,59774]
===
match
---
name: values_ordered_by_id [77223,77243]
name: values_ordered_by_id [77175,77195]
===
match
---
atom [10600,10904]
atom [10600,10904]
===
match
---
name: pickle_id [15327,15336]
name: pickle_id [15327,15336]
===
match
---
if_stmt [77329,77390]
if_stmt [77281,77342]
===
match
---
operator: -> [3962,3964]
operator: -> [3962,3964]
===
match
---
expr_stmt [26367,26383]
expr_stmt [26367,26383]
===
match
---
operator: = [68735,68736]
operator: = [68687,68688]
===
match
---
name: dag_id [43819,43825]
name: dag_id [43819,43825]
===
match
---
name: refresh_from_task [22937,22954]
name: refresh_from_task [22937,22954]
===
match
---
name: dag_run [67880,67887]
name: dag_run [67832,67839]
===
match
---
name: self [59338,59342]
name: self [59290,59294]
===
match
---
operator: @ [21015,21016]
operator: @ [21015,21016]
===
match
---
argument [54130,54161]
argument [54129,54160]
===
match
---
trailer [7456,7460]
trailer [7456,7460]
===
match
---
name: execution_date [74352,74366]
name: execution_date [74304,74318]
===
match
---
expr_stmt [37975,38008]
expr_stmt [37975,38008]
===
match
---
name: t [79023,79024]
name: t [78975,78976]
===
match
---
name: _CURRENT_CONTEXT [3242,3258]
name: _CURRENT_CONTEXT [3242,3258]
===
match
---
atom_expr [6093,6102]
atom_expr [6093,6102]
===
match
---
name: super [11194,11199]
name: super [11194,11199]
===
match
---
name: str [64278,64281]
name: str [64230,64233]
===
match
---
expr_stmt [82651,82701]
expr_stmt [82603,82653]
===
match
---
trailer [73087,73096]
trailer [73039,73048]
===
match
---
trailer [41845,41850]
trailer [41845,41850]
===
match
---
operator: = [15839,15840]
operator: = [15839,15840]
===
match
---
name: self [40674,40678]
name: self [40674,40678]
===
match
---
operator: , [4423,4424]
operator: , [4423,4424]
===
match
---
name: airflow_context_vars [49384,49404]
name: airflow_context_vars [49384,49404]
===
match
---
simple_stmt [37508,37525]
simple_stmt [37508,37525]
===
match
---
atom_expr [80661,80673]
atom_expr [80613,80625]
===
match
---
trailer [68227,68248]
trailer [68179,68200]
===
match
---
atom_expr [55535,55554]
atom_expr [55534,55553]
===
match
---
simple_stmt [18543,18567]
simple_stmt [18543,18567]
===
match
---
name: get [63565,63568]
name: get [63517,63520]
===
match
---
fstring_string: operator_successes_ [50651,50670]
fstring_string: operator_successes_ [50689,50708]
===
match
---
parameters [55162,55240]
parameters [55161,55239]
===
match
---
param [41724,41751]
param [41724,41751]
===
match
---
name: read [4088,4092]
name: read [4088,4092]
===
match
---
name: nullable [10043,10051]
name: nullable [10043,10051]
===
match
---
trailer [71412,71419]
trailer [71364,71371]
===
match
---
name: airflow [67285,67292]
name: airflow [67237,67244]
===
match
---
trailer [39192,39216]
trailer [39192,39216]
===
match
---
name: session [50800,50807]
name: session [50838,50845]
===
match
---
name: self [13882,13886]
name: self [13882,13886]
===
match
---
name: self [81534,81538]
name: self [81486,81490]
===
match
---
simple_stmt [27646,27715]
simple_stmt [27646,27715]
===
match
---
trailer [45860,45871]
trailer [45860,45871]
===
match
---
name: dag_id [23975,23981]
name: dag_id [23975,23981]
===
match
---
simple_stmt [3096,3154]
simple_stmt [3096,3154]
===
match
---
comparison [73949,73985]
comparison [73901,73937]
===
match
---
name: should_pass_filepath [14683,14703]
name: should_pass_filepath [14683,14703]
===
match
---
trailer [61513,61532]
trailer [61465,61484]
===
match
---
name: incr [50644,50648]
name: incr [50682,50686]
===
match
---
simple_stmt [39168,39248]
simple_stmt [39168,39248]
===
match
---
name: self [74370,74374]
name: self [74322,74326]
===
match
---
name: self [45042,45046]
name: self [45042,45046]
===
match
---
trailer [66827,67173]
trailer [66779,67125]
===
match
---
operator: == [79380,79382]
operator: == [79332,79334]
===
match
---
atom_expr [60237,60267]
atom_expr [60189,60219]
===
match
---
name: test_mode [40777,40786]
name: test_mode [40777,40786]
===
match
---
simple_stmt [25159,25275]
simple_stmt [25159,25275]
===
match
---
trailer [72097,72109]
trailer [72049,72061]
===
match
---
operator: , [26279,26280]
operator: , [26279,26280]
===
match
---
for_stmt [32569,32970]
for_stmt [32569,32970]
===
match
---
name: context [53309,53316]
name: context [53308,53315]
===
match
---
if_stmt [56461,56873]
if_stmt [56460,56872]
===
match
---
trailer [11905,11916]
trailer [11905,11916]
===
match
---
trailer [80913,80925]
trailer [80865,80877]
===
match
---
trailer [63184,63188]
trailer [63136,63140]
===
match
---
name: default_var [63587,63598]
name: default_var [63539,63550]
===
match
---
name: deserialize_value [77005,77022]
name: deserialize_value [76957,76974]
===
match
---
simple_stmt [59693,59733]
simple_stmt [59645,59685]
===
match
---
trailer [67423,67429]
trailer [67375,67381]
===
match
---
name: commit [24116,24122]
name: commit [24116,24122]
===
match
---
simple_stmt [9987,10012]
simple_stmt [9987,10012]
===
match
---
name: bool [56240,56244]
name: bool [56239,56243]
===
match
---
decorator [41636,41653]
decorator [41636,41653]
===
match
---
name: filepath [14781,14789]
name: filepath [14781,14789]
===
match
---
operator: = [39320,39321]
operator: = [39320,39321]
===
match
---
string: 'ts_nodash_with_tz' [65913,65932]
string: 'ts_nodash_with_tz' [65865,65884]
===
match
---
name: self [26838,26842]
name: self [26838,26842]
===
match
---
comparison [76407,76421]
comparison [76359,76373]
===
match
---
operator: , [67982,67983]
operator: , [67934,67935]
===
match
---
trailer [62425,62432]
trailer [62377,62384]
===
match
---
name: last_dagrun [28008,28019]
name: last_dagrun [28008,28019]
===
match
---
operator: -> [36107,36109]
operator: -> [36107,36109]
===
match
---
name: self [50921,50925]
name: self [50959,50963]
===
match
---
operator: -> [24202,24204]
operator: -> [24202,24204]
===
match
---
simple_stmt [47724,47741]
simple_stmt [47724,47741]
===
match
---
name: total_seconds [25064,25077]
name: total_seconds [25064,25077]
===
match
---
name: prev_execution_date [62045,62064]
name: prev_execution_date [61997,62016]
===
match
---
simple_stmt [55062,55086]
simple_stmt [55061,55085]
===
match
---
name: _run_as_user [80285,80297]
name: _run_as_user [80237,80249]
===
match
---
operator: } [62432,62433]
operator: } [62384,62385]
===
match
---
name: state [10838,10843]
name: state [10838,10843]
===
match
---
atom_expr [20931,20941]
atom_expr [20931,20941]
===
match
---
argument [68606,68632]
argument [68558,68584]
===
match
---
atom_expr [11163,11176]
atom_expr [11163,11176]
===
match
---
atom_expr [37738,37752]
atom_expr [37738,37752]
===
match
---
fstring_expr [48810,48829]
fstring_expr [48810,48829]
===
match
---
trailer [11916,11932]
trailer [11916,11932]
===
match
---
simple_stmt [70131,70520]
simple_stmt [70083,70472]
===
match
---
trailer [34756,34772]
trailer [34756,34772]
===
match
---
name: XCom [77081,77085]
name: XCom [77033,77037]
===
match
---
arglist [62556,62595]
arglist [62508,62547]
===
match
---
atom_expr [18650,18678]
atom_expr [18650,18678]
===
match
---
operator: , [9857,9858]
operator: , [9857,9858]
===
match
---
string: 'execution_date' [43893,43909]
string: 'execution_date' [43893,43909]
===
match
---
param [32376,32381]
param [32376,32381]
===
match
---
operator: == [24008,24010]
operator: == [24008,24010]
===
match
---
expr_stmt [60359,60534]
expr_stmt [60311,60486]
===
match
---
string: """Functions that need to be run before a Task is executed""" [52008,52069]
string: """Functions that need to be run before a Task is executed""" [52046,52107]
===
match
---
name: Session [29240,29247]
name: Session [29240,29247]
===
match
---
operator: , [44906,44907]
operator: , [44906,44907]
===
match
---
name: self [68260,68264]
name: self [68212,68216]
===
match
---
simple_stmt [42873,42911]
simple_stmt [42873,42911]
===
match
---
name: set_error_file [56839,56853]
name: set_error_file [56838,56852]
===
match
---
fstring_string: / [19134,19135]
fstring_string: / [19134,19135]
===
match
---
name: timer [48779,48784]
name: timer [48779,48784]
===
match
---
name: execution_date [78709,78723]
name: execution_date [78661,78675]
===
match
---
simple_stmt [52665,52682]
simple_stmt [52664,52681]
===
match
---
operator: , [39733,39734]
operator: , [39733,39734]
===
match
---
operator: = [14148,14149]
operator: = [14148,14149]
===
match
---
simple_stmt [19102,19161]
simple_stmt [19102,19161]
===
match
---
trailer [7294,7302]
trailer [7294,7302]
===
match
---
suite [67480,67544]
suite [67432,67496]
===
match
---
name: ti [22452,22454]
name: ti [22452,22454]
===
match
---
name: dep_context [32475,32486]
name: dep_context [32475,32486]
===
match
---
name: priority_weight [22672,22687]
name: priority_weight [22672,22687]
===
match
---
name: strftime [60895,60903]
name: strftime [60847,60855]
===
match
---
name: task [42956,42960]
name: task [42956,42960]
===
match
---
atom_expr [30341,30378]
atom_expr [30341,30378]
===
match
---
classdef [79640,82400]
classdef [79592,82352]
===
match
---
trailer [5201,5207]
trailer [5201,5207]
===
match
---
atom_expr [61505,61553]
atom_expr [61457,61505]
===
match
---
trailer [18219,18226]
trailer [18219,18226]
===
match
---
name: var [63185,63188]
name: var [63137,63140]
===
match
---
name: self [31803,31807]
name: self [31803,31807]
===
match
---
operator: = [17990,17991]
operator: = [17990,17991]
===
match
---
trailer [7662,7670]
trailer [7662,7670]
===
match
---
string: 'dag_id=%s, task_id=%s, execution_date=%s, start_date=%s, end_date=%s' [43726,43796]
string: 'dag_id=%s, task_id=%s, execution_date=%s, start_date=%s, end_date=%s' [43726,43796]
===
match
---
simple_stmt [81456,81473]
simple_stmt [81408,81425]
===
match
---
argument [48017,48030]
argument [48017,48030]
===
match
---
name: exception_html [71641,71655]
name: exception_html [71593,71607]
===
match
---
decorator [30384,30394]
decorator [30384,30394]
===
match
---
atom_expr [51694,51728]
atom_expr [51732,51766]
===
match
---
arglist [54480,54676]
arglist [54479,54675]
===
match
---
trailer [71541,71786]
trailer [71493,71738]
===
match
---
name: state [20936,20941]
name: state [20936,20941]
===
match
---
name: extend [18547,18553]
name: extend [18547,18553]
===
match
---
operator: = [23682,23683]
operator: = [23682,23683]
===
match
---
atom_expr [22584,22599]
atom_expr [22584,22599]
===
match
---
simple_stmt [60763,60836]
simple_stmt [60715,60788]
===
match
---
name: TaskReschedule [1996,2010]
name: TaskReschedule [1996,2010]
===
match
---
and_test [51807,51852]
and_test [51845,51890]
===
match
---
atom_expr [24910,24920]
atom_expr [24910,24920]
===
match
---
argument [15459,15476]
argument [15459,15476]
===
match
---
simple_stmt [19299,19344]
simple_stmt [19299,19344]
===
match
---
operator: } [19419,19420]
operator: } [19419,19420]
===
match
---
trailer [40627,40693]
trailer [40627,40693]
===
match
---
trailer [26073,26095]
trailer [26073,26095]
===
match
---
expr_stmt [69754,70121]
expr_stmt [69706,70073]
===
match
---
name: unixname [9951,9959]
name: unixname [9951,9959]
===
match
---
name: session [19919,19926]
name: session [19919,19926]
===
match
---
name: ti [80526,80528]
name: ti [80478,80480]
===
match
---
operator: = [14117,14118]
operator: = [14117,14118]
===
match
---
simple_stmt [27791,27855]
simple_stmt [27791,27855]
===
match
---
name: self [40263,40267]
name: self [40263,40267]
===
match
---
operator: = [58165,58166]
operator: = [58164,58165]
===
match
---
name: merge [40979,40984]
name: merge [40979,40984]
===
match
---
atom_expr [52672,52681]
atom_expr [52671,52680]
===
match
---
name: are_dependencies_met [39873,39893]
name: are_dependencies_met [39873,39893]
===
match
---
simple_stmt [22761,22795]
simple_stmt [22761,22795]
===
match
---
name: execution_date [26265,26279]
name: execution_date [26265,26279]
===
match
---
operator: , [23981,23982]
operator: , [23981,23982]
===
match
---
trailer [61957,61966]
trailer [61909,61918]
===
match
---
trailer [9814,9818]
trailer [9814,9818]
===
match
---
operator: , [56294,56295]
operator: , [56293,56294]
===
match
---
suite [25150,25411]
suite [25150,25411]
===
match
---
simple_stmt [77354,77390]
simple_stmt [77306,77342]
===
match
---
suite [3729,3925]
suite [3729,3925]
===
match
---
suite [66682,66723]
suite [66634,66675]
===
match
---
name: deps [32534,32538]
name: deps [32534,32538]
===
match
---
operator: == [21766,21768]
operator: == [21766,21768]
===
match
---
atom_expr [9808,9818]
atom_expr [9808,9818]
===
match
---
argument [51545,51560]
argument [51583,51598]
===
match
---
atom_expr [35510,35521]
atom_expr [35510,35521]
===
match
---
decorated [26443,28090]
decorated [26443,28090]
===
match
---
name: self [50886,50890]
name: self [50924,50928]
===
match
---
trailer [49062,49070]
trailer [49062,49070]
===
match
---
fstring_expr [42941,42954]
fstring_expr [42941,42954]
===
match
---
operator: == [35058,35060]
operator: == [35058,35060]
===
match
---
parameters [32987,32993]
parameters [32987,32993]
===
match
---
name: self [28617,28621]
name: self [28617,28621]
===
match
---
simple_stmt [9915,9947]
simple_stmt [9915,9947]
===
match
---
try_stmt [52078,52344]
try_stmt [52116,52343]
===
match
---
parameters [59661,59683]
parameters [59613,59635]
===
match
---
operator: = [64099,64100]
operator: = [64051,64052]
===
match
---
trailer [26842,26847]
trailer [26842,26847]
===
match
---
trailer [48778,48784]
trailer [48778,48784]
===
match
---
atom_expr [52140,52173]
atom_expr [52178,52211]
===
match
---
atom [18388,18413]
atom [18388,18413]
===
match
---
operator: = [34686,34687]
operator: = [34686,34687]
===
match
---
trailer [63931,63935]
trailer [63883,63887]
===
match
---
suite [18281,18336]
suite [18281,18336]
===
match
---
trailer [39132,39150]
trailer [39132,39150]
===
match
---
simple_stmt [57041,57067]
simple_stmt [57040,57066]
===
match
---
name: task [11737,11741]
name: task [11737,11741]
===
match
---
name: delay [34867,34872]
name: delay [34867,34872]
===
match
---
atom_expr [50671,50690]
atom_expr [50709,50728]
===
match
---
simple_stmt [35212,35349]
simple_stmt [35212,35349]
===
match
---
trailer [78914,78938]
trailer [78866,78890]
===
match
---
simple_stmt [10016,10059]
simple_stmt [10016,10059]
===
match
---
trailer [57013,57023]
trailer [57012,57022]
===
match
---
name: self [50671,50675]
name: self [50709,50713]
===
match
---
import_from [978,1017]
import_from [978,1017]
===
match
---
name: execution_date [24358,24372]
name: execution_date [24358,24372]
===
match
---
operator: , [15916,15917]
operator: , [15916,15917]
===
match
---
name: session [81616,81623]
name: session [81568,81575]
===
match
---
atom_expr [23311,23320]
atom_expr [23311,23320]
===
match
---
atom_expr [79287,79474]
atom_expr [79239,79426]
===
match
---
name: info [47906,47910]
name: info [47906,47910]
===
match
---
trailer [50925,50936]
trailer [50963,50974]
===
match
---
name: jinja_context [70557,70570]
name: jinja_context [70509,70522]
===
match
---
try_stmt [46025,48085]
try_stmt [46025,48085]
===
match
---
trailer [5965,6004]
trailer [5965,6004]
===
match
---
trailer [25063,25077]
trailer [25063,25077]
===
match
---
name: merge [45599,45604]
name: merge [45599,45604]
===
match
---
sync_comp_for [6954,7000]
sync_comp_for [6954,7000]
===
match
---
arglist [77081,77105]
arglist [77033,77057]
===
match
---
atom_expr [55926,55942]
atom_expr [55925,55941]
===
match
---
and_test [58745,58775]
and_test [58744,58774]
===
match
---
atom_expr [6123,6136]
atom_expr [6123,6136]
===
match
---
trailer [29091,29112]
trailer [29091,29112]
===
match
---
suite [51999,52344]
suite [52037,52343]
===
match
---
trailer [46666,46671]
trailer [46666,46671]
===
match
---
suite [80645,80674]
suite [80597,80626]
===
match
---
testlist_comp [49361,49412]
testlist_comp [49361,49412]
===
match
---
number: 1 [34665,34666]
number: 1 [34665,34666]
===
match
---
name: dagrun [7574,7580]
name: dagrun [7574,7580]
===
match
---
name: dag [14777,14780]
name: dag [14777,14780]
===
match
---
comparison [6871,6898]
comparison [6871,6898]
===
match
---
simple_stmt [857,871]
simple_stmt [857,871]
===
match
---
decorated [81092,81157]
decorated [81044,81109]
===
match
---
power [33718,33744]
power [33718,33744]
===
match
---
name: self [23400,23404]
name: self [23400,23404]
===
match
---
operator: = [28522,28523]
operator: = [28522,28523]
===
match
---
trailer [78410,78425]
trailer [78362,78377]
===
match
---
name: __repr__ [64155,64163]
name: __repr__ [64107,64115]
===
match
---
string: "Starting attempt %s of %s" [40628,40655]
string: "Starting attempt %s of %s" [40628,40655]
===
match
---
name: task_retries [5533,5545]
name: task_retries [5533,5545]
===
match
---
yield_expr [3617,3630]
yield_expr [3617,3630]
===
match
---
simple_stmt [48906,49000]
simple_stmt [48906,49000]
===
match
---
argument [54618,54642]
argument [54617,54641]
===
match
---
simple_stmt [48855,48894]
simple_stmt [48855,48894]
===
match
---
name: get_task [47515,47523]
name: get_task [47515,47523]
===
match
---
simple_stmt [20931,20957]
simple_stmt [20931,20957]
===
match
---
name: base_url [19588,19596]
name: base_url [19588,19596]
===
match
---
name: query [46148,46153]
name: query [46148,46153]
===
match
---
trailer [77004,77022]
trailer [76956,76974]
===
match
---
operator: = [15440,15441]
operator: = [15440,15441]
===
match
---
name: lock_for_update [43182,43197]
name: lock_for_update [43182,43197]
===
match
---
name: _safe_date [59651,59661]
name: _safe_date [59603,59613]
===
match
---
simple_stmt [30476,30624]
simple_stmt [30476,30624]
===
match
---
name: log [58369,58372]
name: log [58368,58371]
===
match
---
name: e [43289,43290]
name: e [43289,43290]
===
match
---
name: self [22584,22588]
name: self [22584,22588]
===
match
---
atom_expr [14940,15487]
atom_expr [14940,15487]
===
match
---
name: first [78328,78333]
name: first [78280,78285]
===
match
---
param [64164,64168]
param [64116,64120]
===
match
---
simple_stmt [24790,24809]
simple_stmt [24790,24809]
===
match
---
tfpdef [11130,11154]
tfpdef [11130,11154]
===
match
---
name: relationship [10922,10934]
name: relationship [10922,10934]
===
match
---
simple_stmt [59338,59432]
simple_stmt [59290,59384]
===
match
---
decorator [53391,53408]
decorator [53390,53407]
===
match
---
name: self [65629,65633]
name: self [65581,65585]
===
match
---
param [55188,55209]
param [55187,55208]
===
match
---
name: test_mode [56425,56434]
name: test_mode [56424,56433]
===
match
---
name: get_rendered_template_fields [66199,66227]
name: get_rendered_template_fields [66151,66179]
===
match
---
atom_expr [5962,6004]
atom_expr [5962,6004]
===
match
---
name: task_id [47079,47086]
name: task_id [47079,47086]
===
match
---
name: int [81282,81285]
name: int [81234,81237]
===
match
---
atom_expr [81303,81324]
atom_expr [81255,81276]
===
match
---
name: pendulum [61791,61799]
name: pendulum [61743,61751]
===
match
---
name: context [51712,51719]
name: context [51750,51757]
===
match
---
trailer [77625,77632]
trailer [77577,77584]
===
match
---
name: self [26260,26264]
name: self [26260,26264]
===
match
---
atom_expr [19429,19440]
atom_expr [19429,19440]
===
match
---
name: self [12391,12395]
name: self [12391,12395]
===
match
---
subscript [82447,82451]
subscript [82399,82403]
===
match
---
param [68331,68335]
param [68283,68287]
===
match
---
trailer [58814,58826]
trailer [58813,58825]
===
match
---
trailer [19551,19566]
trailer [19551,19566]
===
match
---
atom_expr [45109,45126]
atom_expr [45109,45126]
===
match
---
name: sha1 [33845,33849]
name: sha1 [33845,33849]
===
match
---
name: execution_date [74375,74389]
name: execution_date [74327,74341]
===
match
---
name: task_ids [6915,6923]
name: task_ids [6915,6923]
===
match
---
simple_stmt [80654,80674]
simple_stmt [80606,80626]
===
match
---
simple_stmt [54909,54949]
simple_stmt [54908,54948]
===
match
---
simple_stmt [43612,43639]
simple_stmt [43612,43639]
===
match
---
atom_expr [23915,24099]
atom_expr [23915,24099]
===
match
---
trailer [5317,5324]
trailer [5317,5324]
===
match
---
name: isoformat [19278,19287]
name: isoformat [19278,19287]
===
match
---
name: next_ds [61563,61570]
name: next_ds [61515,61522]
===
match
---
decorator [20636,20653]
decorator [20636,20653]
===
match
---
name: refresh_from_db [21040,21055]
name: refresh_from_db [21040,21055]
===
match
---
atom_expr [82173,82186]
atom_expr [82125,82138]
===
match
---
name: date [41511,41515]
name: date [41511,41515]
===
match
---
name: log [52256,52259]
name: log [52287,52290]
===
match
---
name: count [26068,26073]
name: count [26068,26073]
===
match
---
name: dag_id [77663,77669]
name: dag_id [77615,77621]
===
match
---
name: UndefinedError [66767,66781]
name: UndefinedError [66719,66733]
===
match
---
trailer [45407,45421]
trailer [45407,45421]
===
match
---
name: Optional [3965,3973]
name: Optional [3965,3973]
===
match
---
operator: = [62239,62240]
operator: = [62191,62192]
===
match
---
strings [74033,74135]
strings [73985,74087]
===
match
---
annassign [79867,79885]
annassign [79819,79837]
===
match
---
arglist [80248,80265]
arglist [80200,80217]
===
match
---
atom_expr [59627,59641]
atom_expr [59579,59593]
===
match
---
operator: , [30876,30877]
operator: , [30876,30877]
===
match
---
simple_stmt [14598,14618]
simple_stmt [14598,14618]
===
match
---
name: iso [18979,18982]
name: iso [18979,18982]
===
match
---
string: "exception" [52813,52824]
string: "exception" [52812,52823]
===
match
---
atom_expr [6742,7049]
atom_expr [6742,7049]
===
match
---
expr_stmt [49170,49249]
expr_stmt [49170,49249]
===
match
---
trailer [18154,18184]
trailer [18154,18184]
===
match
---
name: execution_date [78840,78854]
name: execution_date [78792,78806]
===
match
---
trailer [67406,67423]
trailer [67358,67375]
===
match
---
if_stmt [55305,55338]
if_stmt [55304,55337]
===
match
---
name: log [56620,56623]
name: log [56619,56622]
===
match
---
not_test [78187,78194]
not_test [78139,78146]
===
match
---
name: debug [24142,24147]
name: debug [24142,24147]
===
match
---
name: self [71688,71692]
name: self [71640,71644]
===
match
---
name: dag_id [77678,77684]
name: dag_id [77630,77636]
===
match
---
trailer [80361,80378]
trailer [80313,80330]
===
match
---
atom_expr [77673,77684]
atom_expr [77625,77636]
===
match
---
name: nullable [10103,10111]
name: nullable [10103,10111]
===
match
---
name: context [48141,48148]
name: context [48141,48148]
===
match
---
atom_expr [81463,81472]
atom_expr [81415,81424]
===
match
---
name: REQUEUEABLE_DEPS [38268,38284]
name: REQUEUEABLE_DEPS [38268,38284]
===
match
---
name: run [53416,53419]
name: run [53415,53418]
===
match
---
comparison [13152,13179]
comparison [13152,13179]
===
match
---
atom_expr [39967,39977]
atom_expr [39967,39977]
===
match
---
expr_stmt [20551,20570]
expr_stmt [20551,20570]
===
match
---
string: 'task' [65586,65592]
string: 'task' [65538,65544]
===
match
---
fstring_string: DAGS_FOLDER/ [14764,14776]
fstring_string: DAGS_FOLDER/ [14764,14776]
===
match
---
operator: = [54726,54727]
operator: = [54725,54726]
===
match
---
atom_expr [22552,22561]
atom_expr [22552,22561]
===
match
---
name: context [53255,53262]
name: context [53254,53261]
===
match
---
name: dag [26863,26866]
name: dag [26863,26866]
===
match
---
expr_stmt [63927,63942]
expr_stmt [63879,63894]
===
match
---
atom_expr [27903,27955]
atom_expr [27903,27955]
===
match
---
name: task [5445,5449]
name: task [5445,5449]
===
match
---
atom_expr [77000,77030]
atom_expr [76952,76982]
===
match
---
trailer [61454,61469]
trailer [61406,61421]
===
match
---
trailer [39308,39319]
trailer [39308,39319]
===
match
---
trailer [82177,82186]
trailer [82129,82138]
===
match
---
trailer [33849,34044]
trailer [33849,34044]
===
match
---
arglist [72329,72378]
arglist [72281,72330]
===
match
---
except_clause [43348,43380]
except_clause [43348,43380]
===
match
---
operator: - [25045,25046]
operator: - [25045,25046]
===
match
---
strings [69791,70111]
strings [69743,70063]
===
match
---
if_stmt [5238,5336]
if_stmt [5238,5336]
===
match
---
name: task [42653,42657]
name: task [42653,42657]
===
match
---
trailer [52676,52681]
trailer [52675,52680]
===
match
---
name: dag_id [14988,14994]
name: dag_id [14988,14994]
===
match
---
expr_stmt [82046,82262]
expr_stmt [81998,82214]
===
match
---
import_from [2961,3014]
import_from [2961,3014]
===
match
---
argument [49557,49572]
argument [49557,49572]
===
match
---
name: subject [72768,72775]
name: subject [72720,72727]
===
match
---
simple_stmt [24678,24711]
simple_stmt [24678,24711]
===
match
---
name: is_smart_sensor_compatible [49693,49719]
name: is_smart_sensor_compatible [49693,49719]
===
match
---
atom_expr [55451,55733]
atom_expr [55450,55732]
===
match
---
atom_expr [66408,66461]
atom_expr [66360,66413]
===
match
---
name: self [12702,12706]
name: self [12702,12706]
===
match
---
string: """         Returns whether or not all the conditions are met for this task instance to be run         given the context for the dependencies (e.g. a task instance being force run from         the UI will ignore some dependencies).          :param dep_context: The execution context that determines the dependencies that             should be evaluated.         :type dep_context: DepContext         :param session: database session         :type session: sqlalchemy.orm.session.Session         :param verbose: whether log details on failed dependencies on             info or debug log level         :type verbose: bool         """ [31066,31698]
string: """         Returns whether or not all the conditions are met for this task instance to be run         given the context for the dependencies (e.g. a task instance being force run from         the UI will ignore some dependencies).          :param dep_context: The execution context that determines the dependencies that             should be evaluated.         :type dep_context: DepContext         :param session: database session         :type session: sqlalchemy.orm.session.Session         :param verbose: whether log details on failed dependencies on             info or debug log level         :type verbose: bool         """ [31066,31698]
===
match
---
name: on_kill [48532,48539]
name: on_kill [48532,48539]
===
match
---
name: execution_date [11946,11960]
name: execution_date [11946,11960]
===
match
---
simple_stmt [40912,40933]
simple_stmt [40912,40933]
===
match
---
operator: = [26047,26048]
operator: = [26047,26048]
===
match
---
name: Column [10286,10292]
name: Column [10286,10292]
===
match
---
param [14350,14360]
param [14350,14360]
===
match
---
tfpdef [56228,56244]
tfpdef [56227,56243]
===
match
---
simple_stmt [22394,22424]
simple_stmt [22394,22424]
===
match
---
atom_expr [67517,67543]
atom_expr [67469,67495]
===
match
---
name: provide_session [19875,19890]
name: provide_session [19875,19890]
===
match
---
name: query [60395,60400]
name: query [60347,60352]
===
match
---
trailer [41346,41350]
trailer [41346,41350]
===
match
---
name: airflow [2552,2559]
name: airflow [2552,2559]
===
match
---
name: prev_ds [65119,65126]
name: prev_ds [65071,65078]
===
match
---
name: rendered_k8s_spec [67445,67462]
name: rendered_k8s_spec [67397,67414]
===
match
---
atom_expr [46967,47018]
atom_expr [46967,47018]
===
match
---
simple_stmt [56532,56581]
simple_stmt [56531,56580]
===
match
---
name: property [8345,8353]
name: property [8345,8353]
===
match
---
operator: = [82678,82679]
operator: = [82630,82631]
===
match
---
atom_expr [56889,56898]
atom_expr [56888,56897]
===
match
---
name: task [52677,52681]
name: task [52676,52680]
===
match
---
operator: , [70821,70822]
operator: , [70773,70774]
===
match
---
operator: { [48791,48792]
operator: { [48791,48792]
===
match
---
name: add [6138,6141]
name: add [6138,6141]
===
match
---
name: self [39967,39971]
name: self [39967,39971]
===
match
---
expr_stmt [60718,60754]
expr_stmt [60670,60706]
===
match
---
name: max_tries [40305,40314]
name: max_tries [40305,40314]
===
match
---
operator: = [54992,54993]
operator: = [54991,54992]
===
match
---
operator: } [42953,42954]
operator: } [42953,42954]
===
match
---
operator: , [24351,24352]
operator: , [24351,24352]
===
match
---
operator: , [2798,2799]
operator: , [2798,2799]
===
match
---
name: self [77451,77455]
name: self [77403,77407]
===
match
---
name: refresh_from_task [42706,42723]
name: refresh_from_task [42706,42723]
===
match
---
name: pool [42744,42748]
name: pool [42744,42748]
===
match
---
operator: = [26520,26521]
operator: = [26520,26521]
===
match
---
trailer [8539,8547]
trailer [8539,8547]
===
match
---
name: Tuple [79610,79615]
name: Tuple [79562,79567]
===
match
---
name: include_upstream [46809,46825]
name: include_upstream [46809,46825]
===
match
---
arglist [72173,72208]
arglist [72125,72160]
===
match
---
trailer [80077,80088]
trailer [80029,80040]
===
match
---
trailer [71505,71507]
trailer [71457,71459]
===
match
---
atom_expr [12058,12073]
atom_expr [12058,12073]
===
match
---
except_clause [44243,44275]
except_clause [44243,44275]
===
match
---
arglist [10821,10860]
arglist [10821,10860]
===
match
---
name: models [48219,48225]
name: models [48219,48225]
===
match
---
name: utcnow [7972,7978]
name: utcnow [7972,7978]
===
match
---
simple_stmt [82046,82263]
simple_stmt [81998,82215]
===
match
---
string: """         Based on this instance's try_number, this will calculate         the number of previously attempted tries, defaulting to 0.         """ [13402,13549]
string: """         Based on this instance's try_number, this will calculate         the number of previously attempted tries, defaulting to 0.         """ [13402,13549]
===
match
---
simple_stmt [10388,10452]
simple_stmt [10388,10452]
===
match
---
except_clause [72710,72726]
except_clause [72662,72678]
===
match
---
operator: { [14776,14777]
operator: { [14776,14777]
===
match
---
trailer [34054,34056]
trailer [34054,34056]
===
match
---
suite [55241,56080]
suite [55240,56079]
===
match
---
name: ignore_task_deps [53596,53612]
name: ignore_task_deps [53595,53611]
===
match
---
atom_expr [10710,10734]
atom_expr [10710,10734]
===
match
---
simple_stmt [74203,74430]
simple_stmt [74155,74382]
===
match
---
operator: , [63067,63068]
operator: , [63019,63020]
===
match
---
and_test [61229,61265]
and_test [61181,61217]
===
match
---
atom_expr [30439,30466]
atom_expr [30439,30466]
===
match
---
name: self [40881,40885]
name: self [40881,40885]
===
match
---
tfpdef [35819,35847]
tfpdef [35819,35847]
===
match
---
if_stmt [51374,51729]
if_stmt [51412,51767]
===
match
---
operator: , [38382,38383]
operator: , [38382,38383]
===
match
---
tfpdef [73199,73233]
tfpdef [73151,73185]
===
match
---
name: max_retry_delay [34757,34772]
name: max_retry_delay [34757,34772]
===
match
---
operator: , [68679,68680]
operator: , [68631,68632]
===
match
---
simple_stmt [37722,37753]
simple_stmt [37722,37753]
===
match
---
name: self [56532,56536]
name: self [56531,56535]
===
match
---
expr_stmt [12391,12407]
expr_stmt [12391,12407]
===
match
---
name: Session [29824,29831]
name: Session [29824,29831]
===
match
---
return_stmt [80985,81006]
return_stmt [80937,80958]
===
match
---
atom_expr [7910,7918]
atom_expr [7910,7918]
===
match
---
trailer [40468,40474]
trailer [40468,40474]
===
match
---
trailer [50346,50375]
trailer [50384,50413]
===
match
---
name: renderedtifields [48226,48242]
name: renderedtifields [48226,48242]
===
match
---
return_stmt [4149,4174]
return_stmt [4149,4174]
===
match
---
name: ignore_depends_on_past [38423,38445]
name: ignore_depends_on_past [38423,38445]
===
match
---
trailer [53936,54323]
trailer [53935,54322]
===
match
---
if_stmt [78659,78954]
if_stmt [78611,78906]
===
match
---
arglist [39600,39834]
arglist [39600,39834]
===
match
---
name: context [68078,68085]
name: context [68030,68037]
===
match
---
atom_expr [44466,44488]
atom_expr [44466,44488]
===
match
---
trailer [55970,55976]
trailer [55969,55975]
===
match
---
name: dag [14868,14871]
name: dag [14868,14871]
===
match
---
trailer [39872,39893]
trailer [39872,39893]
===
match
---
atom_expr [24310,24390]
atom_expr [24310,24390]
===
match
---
atom_expr [48737,48759]
atom_expr [48737,48759]
===
match
---
operator: @ [13348,13349]
operator: @ [13348,13349]
===
match
---
name: property [13349,13357]
name: property [13349,13357]
===
match
---
operator: = [53533,53534]
operator: = [53532,53533]
===
match
---
parameters [21055,21098]
parameters [21055,21098]
===
match
---
trailer [62251,62260]
trailer [62203,62212]
===
match
---
operator: , [15346,15347]
operator: , [15346,15347]
===
match
---
atom_expr [19122,19133]
atom_expr [19122,19133]
===
match
---
import_from [1350,1393]
import_from [1350,1393]
===
match
---
trailer [58925,58929]
trailer [58915,58919]
===
match
---
name: execution_date [26242,26256]
name: execution_date [26242,26256]
===
match
---
simple_stmt [35040,35131]
simple_stmt [35040,35131]
===
match
---
name: hostname [9915,9923]
name: hostname [9915,9923]
===
match
---
simple_stmt [6017,6039]
simple_stmt [6017,6039]
===
match
---
atom_expr [3951,3960]
atom_expr [3951,3960]
===
match
---
string: "&upstream=false" [19809,19826]
string: "&upstream=false" [19809,19826]
===
match
---
atom_expr [57009,57023]
atom_expr [57008,57022]
===
match
---
atom_expr [25959,25968]
atom_expr [25959,25968]
===
match
---
name: verbose [39936,39943]
name: verbose [39936,39943]
===
match
---
simple_stmt [55389,55409]
simple_stmt [55388,55408]
===
match
---
trailer [52629,52635]
trailer [52628,52634]
===
match
---
name: self [8178,8182]
name: self [8178,8182]
===
match
---
simple_stmt [50921,50957]
simple_stmt [50959,50995]
===
match
---
name: context [53377,53384]
name: context [53376,53383]
===
match
---
name: yesterday_ds [60763,60775]
name: yesterday_ds [60715,60727]
===
match
---
trailer [48539,48541]
trailer [48539,48541]
===
match
---
argument [59392,59413]
argument [59344,59365]
===
match
---
name: self [72937,72941]
name: self [72889,72893]
===
match
---
string: "{}#{}#{}#{}" [33871,33884]
string: "{}#{}#{}#{}" [33871,33884]
===
match
---
param [21076,21097]
param [21076,21097]
===
match
---
name: self [22394,22398]
name: self [22394,22398]
===
match
---
number: 1 [8595,8596]
number: 1 [8595,8596]
===
match
---
name: _prepare_and_execute_task_with_callbacks [43093,43133]
name: _prepare_and_execute_task_with_callbacks [43093,43133]
===
match
---
simple_stmt [12142,12161]
simple_stmt [12142,12161]
===
match
---
string: '-' [62329,62332]
string: '-' [62281,62284]
===
match
---
operator: = [53658,53659]
operator: = [53657,53658]
===
match
---
name: has_dag [11742,11749]
name: has_dag [11742,11749]
===
match
---
trailer [82458,82460]
trailer [82410,82412]
===
match
---
name: task [37520,37524]
name: task [37520,37524]
===
match
---
name: self [68223,68227]
name: self [68175,68179]
===
match
---
import_name [835,846]
import_name [835,846]
===
match
---
name: UP_FOR_RETRY [25367,25379]
name: UP_FOR_RETRY [25367,25379]
===
match
---
name: airflow [2966,2973]
name: airflow [2966,2973]
===
match
---
name: render_k8s_pod_yaml [67522,67541]
name: render_k8s_pod_yaml [67474,67493]
===
match
---
name: int [8642,8645]
name: int [8642,8645]
===
match
---
operator: = [24833,24834]
operator: = [24833,24834]
===
match
---
atom_expr [71957,71979]
atom_expr [71909,71931]
===
match
---
operator: , [3909,3910]
operator: , [3909,3910]
===
match
---
simple_stmt [28140,28280]
simple_stmt [28140,28280]
===
match
---
trailer [6662,7150]
trailer [6662,7150]
===
match
---
name: State [44655,44660]
name: State [44655,44660]
===
match
---
name: task_id [79386,79393]
name: task_id [79338,79345]
===
match
---
string: '' [62029,62031]
string: '' [61981,61983]
===
match
---
argument [15067,15092]
argument [15067,15092]
===
match
---
param [50800,50812]
param [50838,50850]
===
match
---
atom_expr [13152,13162]
atom_expr [13152,13162]
===
match
---
name: self [60475,60479]
name: self [60427,60431]
===
match
---
suite [81518,81556]
suite [81470,81508]
===
match
---
param [4297,4313]
param [4297,4313]
===
match
---
name: warning [3746,3753]
name: warning [3746,3753]
===
match
---
name: Union [78030,78035]
name: Union [77982,77987]
===
match
---
trailer [58532,58540]
trailer [58531,58539]
===
match
---
name: bool [53528,53532]
name: bool [53527,53531]
===
match
---
name: state [29618,29623]
name: state [29618,29623]
===
match
---
simple_stmt [26044,26359]
simple_stmt [26044,26359]
===
match
---
operator: = [35802,35803]
operator: = [35802,35803]
===
match
---
name: session [74403,74410]
name: session [74355,74362]
===
match
---
suite [51600,51659]
suite [51638,51697]
===
match
---
atom_expr [22326,22340]
atom_expr [22326,22340]
===
match
---
tfpdef [15856,15867]
tfpdef [15856,15867]
===
match
---
name: ti [79491,79493]
name: ti [79443,79445]
===
match
---
trailer [46147,46153]
trailer [46147,46153]
===
match
---
atom_expr [23970,23981]
atom_expr [23970,23981]
===
match
---
trailer [20464,20479]
trailer [20464,20479]
===
match
---
operator: = [20557,20558]
operator: = [20557,20558]
===
match
---
atom_expr [16078,16091]
atom_expr [16078,16091]
===
match
---
atom_expr [54629,54642]
atom_expr [54628,54641]
===
match
---
annassign [8141,8146]
annassign [8141,8146]
===
match
---
name: Column [9996,10002]
name: Column [9996,10002]
===
match
---
trailer [59590,59595]
trailer [59542,59547]
===
match
---
string: 'ti_dag_state' [10616,10630]
string: 'ti_dag_state' [10616,10630]
===
match
---
name: ti [20559,20561]
name: ti [20559,20561]
===
match
---
name: schedule_tis [47579,47591]
name: schedule_tis [47579,47591]
===
match
---
operator: ** [71420,71422]
operator: ** [71372,71374]
===
match
---
operator: , [21724,21725]
operator: , [21724,21725]
===
match
---
comp_op [27670,27676]
comp_op [27670,27676]
===
match
---
operator: { [19111,19112]
operator: { [19111,19112]
===
match
---
suite [56412,56452]
suite [56411,56451]
===
match
---
string: '%Y-%m-%d' [61967,61977]
string: '%Y-%m-%d' [61919,61929]
===
match
---
atom_expr [19708,19720]
atom_expr [19708,19720]
===
match
---
operator: = [43042,43043]
operator: = [43042,43043]
===
match
---
name: self [33724,33728]
name: self [33724,33728]
===
match
---
operator: = [10241,10242]
operator: = [10241,10242]
===
match
---
name: state [29786,29791]
name: state [29786,29791]
===
match
---
name: or_ [6641,6644]
name: or_ [6641,6644]
===
match
---
arglist [45560,45576]
arglist [45560,45576]
===
match
---
name: primary_key [9539,9550]
name: primary_key [9539,9550]
===
match
---
simple_stmt [56882,56899]
simple_stmt [56881,56898]
===
match
---
name: airflow [2705,2712]
name: airflow [2705,2712]
===
match
---
name: self [37515,37519]
name: self [37515,37519]
===
match
---
name: pool [54591,54595]
name: pool [54590,54594]
===
match
---
name: subject [72679,72686]
name: subject [72631,72638]
===
match
---
trailer [40706,40710]
trailer [40706,40710]
===
match
---
operator: , [41750,41751]
operator: , [41750,41751]
===
match
---
operator: { [19745,19746]
operator: { [19745,19746]
===
match
---
atom_expr [80323,80333]
atom_expr [80275,80285]
===
match
---
operator: = [15272,15273]
operator: = [15272,15273]
===
match
---
name: ignore_schedule [27758,27773]
name: ignore_schedule [27758,27773]
===
match
---
simple_stmt [29302,29518]
simple_stmt [29302,29518]
===
match
---
atom_expr [68698,68717]
atom_expr [68650,68669]
===
match
---
atom_expr [80909,80925]
atom_expr [80861,80877]
===
match
---
comparison [82200,82251]
comparison [82152,82203]
===
match
---
name: __table_args__ [10583,10597]
name: __table_args__ [10583,10597]
===
match
---
decorator [81230,81240]
decorator [81182,81192]
===
match
---
operator: , [42728,42729]
operator: , [42728,42729]
===
match
---
operator: <= [59624,59626]
operator: <= [59576,59578]
===
match
---
trailer [7424,7431]
trailer [7424,7431]
===
match
---
atom_expr [32587,32635]
atom_expr [32587,32635]
===
match
---
expr_stmt [78434,78463]
expr_stmt [78386,78415]
===
match
---
name: state [81110,81115]
name: state [81062,81067]
===
match
---
operator: { [33079,33080]
operator: { [33079,33080]
===
match
---
name: sanitized_pod [69166,69179]
name: sanitized_pod [69118,69131]
===
match
---
name: task [45027,45031]
name: task [45027,45031]
===
match
---
name: typing [1023,1029]
name: typing [1023,1029]
===
match
---
trailer [74147,74162]
trailer [74099,74114]
===
match
---
expr_stmt [57994,58062]
expr_stmt [57993,58061]
===
match
---
trailer [47514,47523]
trailer [47514,47523]
===
match
---
atom_expr [49058,49070]
atom_expr [49058,49070]
===
match
---
atom_expr [51444,51496]
atom_expr [51482,51534]
===
match
---
name: mark_success [41724,41736]
name: mark_success [41724,41736]
===
match
---
operator: @ [56085,56086]
operator: @ [56084,56085]
===
match
---
trailer [54418,54431]
trailer [54417,54430]
===
match
---
name: Optional [53788,53796]
name: Optional [53787,53795]
===
match
---
atom_expr [50886,50896]
atom_expr [50924,50934]
===
match
---
name: ti [5325,5327]
name: ti [5325,5327]
===
match
---
string: 'Log file: {{ti.log_filepath}}<br>' [70001,70036]
string: 'Log file: {{ti.log_filepath}}<br>' [69953,69988]
===
match
---
name: _CURRENT_CONTEXT [3567,3583]
name: _CURRENT_CONTEXT [3567,3583]
===
match
---
operator: , [63459,63460]
operator: , [63411,63412]
===
match
---
name: should_pass_filepath [14627,14647]
name: should_pass_filepath [14627,14647]
===
match
---
atom_expr [40674,40688]
atom_expr [40674,40688]
===
match
---
name: getattr [59702,59709]
name: getattr [59654,59661]
===
match
---
atom_expr [4061,4072]
atom_expr [4061,4072]
===
match
---
name: airflow [35362,35369]
name: airflow [35362,35369]
===
match
---
name: TR [6680,6682]
name: TR [6680,6682]
===
match
---
trailer [7258,7260]
trailer [7258,7260]
===
match
---
decorated [24396,25108]
decorated [24396,25108]
===
match
---
try_stmt [49840,50196]
try_stmt [49840,50234]
===
match
---
atom_expr [19407,19419]
atom_expr [19407,19419]
===
match
---
operator: , [54542,54543]
operator: , [54541,54542]
===
match
---
operator: , [44356,44357]
operator: , [44356,44357]
===
match
---
trailer [49216,49249]
trailer [49216,49249]
===
match
---
operator: , [65951,65952]
operator: , [65903,65904]
===
match
---
name: SUCCESS [52917,52924]
name: SUCCESS [52916,52923]
===
match
---
comparison [21738,21788]
comparison [21738,21788]
===
match
---
param [79789,79805]
param [79741,79757]
===
match
---
name: state [7913,7918]
name: state [7913,7918]
===
match
---
suite [74760,77390]
suite [74712,77342]
===
match
---
operator: = [76551,76552]
operator: = [76503,76504]
===
match
---
name: ignore_ti_state [14234,14249]
name: ignore_ti_state [14234,14249]
===
match
---
argument [39223,39238]
argument [39223,39238]
===
match
---
name: self [62978,62982]
name: self [62930,62934]
===
match
---
trailer [11338,11344]
trailer [11338,11344]
===
match
---
name: Exception [72717,72726]
name: Exception [72669,72678]
===
match
---
simple_stmt [72483,72534]
simple_stmt [72435,72486]
===
match
---
name: RUNNING [40865,40872]
name: RUNNING [40865,40872]
===
match
---
import_from [45946,45986]
import_from [45946,45986]
===
match
---
name: TaskInstance [21738,21750]
name: TaskInstance [21738,21750]
===
match
---
suite [41325,41410]
suite [41325,41410]
===
match
---
simple_stmt [1186,1202]
simple_stmt [1186,1202]
===
match
---
atom_expr [63556,63599]
atom_expr [63508,63551]
===
match
---
simple_stmt [31707,31749]
simple_stmt [31707,31749]
===
match
---
simple_stmt [3279,3313]
simple_stmt [3279,3313]
===
match
---
name: self [54444,54448]
name: self [54443,54447]
===
match
---
name: signal [878,884]
name: signal [878,884]
===
match
---
arglist [10716,10733]
arglist [10716,10733]
===
match
---
name: environ [49446,49453]
name: environ [49446,49453]
===
match
---
lambdef [65471,65528]
lambdef [65423,65480]
===
match
---
name: relationship [82680,82692]
name: relationship [82632,82644]
===
match
---
name: Variable [2047,2055]
name: Variable [2047,2055]
===
match
---
simple_stmt [14755,14792]
simple_stmt [14755,14792]
===
match
---
name: task [58167,58171]
name: task [58166,58170]
===
match
---
parameters [24195,24201]
parameters [24195,24201]
===
match
---
trailer [8784,8792]
trailer [8784,8792]
===
match
---
name: params [60077,60083]
name: params [60029,60035]
===
match
---
atom_expr [24892,24906]
atom_expr [24892,24906]
===
match
---
trailer [44994,44999]
trailer [44994,44999]
===
match
---
operator: { [48810,48811]
operator: { [48810,48811]
===
match
---
operator: { [33027,33028]
operator: { [33027,33028]
===
match
---
trailer [33884,33891]
trailer [33884,33891]
===
match
---
name: isoformat [17966,17975]
name: isoformat [17966,17975]
===
match
---
name: Any [80156,80159]
name: Any [80108,80111]
===
match
---
suite [7331,7511]
suite [7331,7511]
===
match
---
trailer [23612,23622]
trailer [23612,23622]
===
match
---
simple_stmt [35357,35423]
simple_stmt [35357,35423]
===
match
---
trailer [50972,50978]
trailer [51010,51016]
===
match
---
trailer [49404,49410]
trailer [49404,49410]
===
match
---
simple_stmt [67497,67544]
simple_stmt [67449,67496]
===
match
---
operator: @ [19874,19875]
operator: @ [19874,19875]
===
match
---
name: str [16011,16014]
name: str [16011,16014]
===
match
---
operator: } [33090,33091]
operator: } [33090,33091]
===
match
---
arglist [44164,44214]
arglist [44164,44214]
===
match
---
name: merge [40463,40468]
name: merge [40463,40468]
===
match
---
operator: , [64893,64894]
operator: , [64845,64846]
===
match
---
name: task_id [79215,79222]
name: task_id [79167,79174]
===
match
---
trailer [52901,52907]
trailer [52900,52906]
===
match
---
atom_expr [82309,82338]
atom_expr [82261,82290]
===
match
---
name: conf [19054,19058]
name: conf [19054,19058]
===
match
---
param [26499,26527]
param [26499,26527]
===
match
---
number: 1 [57027,57028]
number: 1 [57026,57027]
===
match
---
operator: , [49377,49378]
operator: , [49377,49378]
===
match
---
name: item [63085,63089]
name: item [63037,63041]
===
match
---
atom_expr [53139,53157]
atom_expr [53138,53156]
===
match
---
operator: , [8201,8202]
operator: , [8201,8202]
===
match
---
operator: = [10598,10599]
operator: = [10598,10599]
===
match
---
name: str [16087,16090]
name: str [16087,16090]
===
match
---
name: isoformat [19005,19014]
name: isoformat [19005,19014]
===
match
---
name: __getattr__ [63034,63045]
name: __getattr__ [62986,62997]
===
match
---
param [36087,36100]
param [36087,36100]
===
match
---
trailer [54755,54763]
trailer [54754,54762]
===
match
---
operator: , [16022,16023]
operator: , [16022,16023]
===
match
---
operator: = [27662,27663]
operator: = [27662,27663]
===
match
---
name: e [44451,44452]
name: e [44451,44452]
===
match
---
operator: = [34796,34797]
operator: = [34796,34797]
===
match
---
string: """Get failed Dependencies""" [32423,32452]
string: """Get failed Dependencies""" [32423,32452]
===
match
---
trailer [47493,47498]
trailer [47493,47498]
===
match
---
operator: @ [13258,13259]
operator: @ [13258,13259]
===
match
---
operator: @ [80607,80608]
operator: @ [80559,80560]
===
match
---
parameters [3365,3383]
parameters [3365,3383]
===
match
---
simple_stmt [50574,50629]
simple_stmt [50612,50667]
===
match
---
operator: @ [30958,30959]
operator: @ [30958,30959]
===
match
---
simple_stmt [68433,69043]
simple_stmt [68385,68995]
===
match
---
name: context [50501,50508]
name: context [50539,50546]
===
match
---
name: dr [26880,26882]
name: dr [26880,26882]
===
match
---
name: self [68814,68818]
name: self [68766,68770]
===
match
---
trailer [4052,4057]
trailer [4052,4057]
===
match
---
name: SUCCESS [29104,29111]
name: SUCCESS [29104,29111]
===
match
---
simple_stmt [81527,81556]
simple_stmt [81479,81508]
===
match
---
operator: , [32139,32140]
operator: , [32139,32140]
===
match
---
trailer [19411,19419]
trailer [19411,19419]
===
match
---
number: 0 [26378,26379]
number: 0 [26378,26379]
===
match
---
decorated [12673,13253]
decorated [12673,13253]
===
match
---
operator: , [39833,39834]
operator: , [39833,39834]
===
match
---
name: state [53130,53135]
name: state [53129,53134]
===
match
---
operator: = [36071,36072]
operator: = [36071,36072]
===
match
---
simple_stmt [62155,62213]
simple_stmt [62107,62165]
===
match
---
name: self [58215,58219]
name: self [58214,58218]
===
match
---
name: sqlalchemy [1399,1409]
name: sqlalchemy [1399,1409]
===
match
---
name: provide_session [20637,20652]
name: provide_session [20637,20652]
===
match
---
dotted_name [2405,2424]
dotted_name [2405,2424]
===
match
---
name: self [72457,72461]
name: self [72409,72413]
===
match
---
return_stmt [81456,81472]
return_stmt [81408,81424]
===
match
---
atom_expr [64129,64137]
atom_expr [64081,64089]
===
match
---
name: self [51168,51172]
name: self [51206,51210]
===
match
---
name: modded_hash [34620,34631]
name: modded_hash [34620,34631]
===
match
---
name: value [73179,73184]
name: value [73131,73136]
===
match
---
name: self [71739,71743]
name: self [71691,71695]
===
match
---
operator: == [21709,21711]
operator: == [21709,21711]
===
match
---
trailer [72243,72290]
trailer [72195,72242]
===
match
---
suite [38052,40537]
suite [38052,40537]
===
match
---
trailer [82065,82079]
trailer [82017,82031]
===
match
---
name: task [65052,65056]
name: task [65004,65008]
===
match
---
atom_expr [27685,27706]
atom_expr [27685,27706]
===
match
---
name: TR [3196,3198]
name: TR [3196,3198]
===
match
---
classdef [8829,79511]
classdef [8829,79463]
===
match
---
atom_expr [59236,59250]
atom_expr [59188,59202]
===
match
---
trailer [13886,13898]
trailer [13886,13898]
===
match
---
atom_expr [52945,52954]
atom_expr [52944,52953]
===
match
---
trailer [26322,26330]
trailer [26322,26330]
===
match
---
operator: , [15313,15314]
operator: , [15313,15314]
===
match
---
or_test [24835,24866]
or_test [24835,24866]
===
match
---
atom_expr [25030,25079]
atom_expr [25030,25079]
===
match
---
trailer [59244,59250]
trailer [59196,59202]
===
match
---
import_name [1135,1146]
import_name [1135,1146]
===
match
---
for_stmt [32511,32970]
for_stmt [32511,32970]
===
match
---
name: __init__ [79774,79782]
name: __init__ [79726,79734]
===
match
---
name: duration [73088,73096]
name: duration [73040,73048]
===
match
---
operator: , [15612,15613]
operator: , [15612,15613]
===
match
---
simple_stmt [60077,60113]
simple_stmt [60029,60065]
===
match
---
atom_expr [43612,43622]
atom_expr [43612,43622]
===
match
---
operator: = [48025,48026]
operator: = [48025,48026]
===
match
---
simple_stmt [7226,7279]
simple_stmt [7226,7279]
===
match
---
import_from [1492,1545]
import_from [1492,1545]
===
match
---
name: XCom [77095,77099]
name: XCom [77047,77051]
===
match
---
decorated [81230,81325]
decorated [81182,81277]
===
match
---
arglist [10944,11093]
arglist [10944,11093]
===
match
---
name: logging [11365,11372]
name: logging [11365,11372]
===
match
---
atom_expr [79383,79393]
atom_expr [79335,79345]
===
match
---
name: dag [11832,11835]
name: dag [11832,11835]
===
match
---
tfpdef [79789,79805]
tfpdef [79741,79757]
===
match
---
name: path [14912,14916]
name: path [14912,14916]
===
match
---
strings [66849,67155]
strings [66801,67107]
===
match
---
name: self [24374,24378]
name: self [24374,24378]
===
match
---
return_stmt [32222,32234]
return_stmt [32222,32234]
===
match
---
argument [54591,54600]
argument [54590,54599]
===
match
---
argument [28052,28067]
argument [28052,28067]
===
match
---
import_name [885,900]
import_name [885,900]
===
match
---
operator: = [54425,54426]
operator: = [54424,54425]
===
match
---
name: session [31936,31943]
name: session [31936,31943]
===
match
---
atom_expr [12086,12099]
atom_expr [12086,12099]
===
match
---
name: conf [19310,19314]
name: conf [19310,19314]
===
match
---
name: self [30430,30434]
name: self [30430,30434]
===
match
---
simple_stmt [72920,72986]
simple_stmt [72872,72938]
===
match
---
atom_expr [32541,32555]
atom_expr [32541,32555]
===
match
---
simple_stmt [69754,70122]
simple_stmt [69706,70074]
===
match
---
name: Optional [74613,74621]
name: Optional [74565,74573]
===
match
---
argument [59415,59430]
argument [59367,59382]
===
match
---
expr_stmt [27646,27714]
expr_stmt [27646,27714]
===
match
---
operator: , [58489,58490]
operator: , [58488,58489]
===
match
---
trailer [64202,64206]
trailer [64154,64158]
===
match
---
string: "Marking success for %s on %s" [41244,41274]
string: "Marking success for %s on %s" [41244,41274]
===
match
---
name: task [25952,25956]
name: task [25952,25956]
===
match
---
simple_stmt [20239,20524]
simple_stmt [20239,20524]
===
match
---
name: task_id [18028,18035]
name: task_id [18028,18035]
===
match
---
name: state [43617,43622]
name: state [43617,43622]
===
match
---
operator: , [62027,62028]
operator: , [61979,61980]
===
match
---
name: info [50832,50836]
name: info [50870,50874]
===
match
---
operator: , [1324,1325]
operator: , [1324,1325]
===
match
---
name: TaskInstanceKey [78052,78067]
name: TaskInstanceKey [78004,78019]
===
match
---
operator: = [46876,46877]
operator: = [46876,46877]
===
match
---
dictorsetmaker [44655,44682]
dictorsetmaker [44655,44682]
===
match
---
dotted_name [2552,2569]
dotted_name [2552,2569]
===
match
---
name: debug [29535,29540]
name: debug [29535,29540]
===
match
---
argument [48966,48973]
argument [48966,48973]
===
match
---
name: error [4697,4702]
name: error [4697,4702]
===
match
---
operator: , [66178,66179]
operator: , [66130,66131]
===
match
---
name: _execute_task [50487,50500]
name: _execute_task [50525,50538]
===
match
---
operator: = [53727,53728]
operator: = [53726,53727]
===
match
---
trailer [64057,64061]
trailer [64009,64013]
===
match
---
param [56148,56177]
param [56147,56176]
===
match
---
string: "Executing %s on %s" [41356,41376]
string: "Executing %s on %s" [41356,41376]
===
match
---
name: debug [22887,22892]
name: debug [22887,22892]
===
match
---
operator: = [60776,60777]
operator: = [60728,60729]
===
match
---
operator: = [71174,71175]
operator: = [71126,71127]
===
match
---
name: self [22851,22855]
name: self [22851,22855]
===
match
---
trailer [4063,4072]
trailer [4063,4072]
===
match
---
operator: = [53825,53826]
operator: = [53824,53825]
===
match
---
simple_stmt [69159,69180]
simple_stmt [69111,69132]
===
match
---
name: task [48340,48344]
name: task [48340,48344]
===
match
---
atom_expr [34798,34835]
atom_expr [34798,34835]
===
match
---
atom_expr [74312,74323]
atom_expr [74264,74275]
===
match
---
name: error [58827,58832]
name: error [58826,58831]
===
match
---
trailer [22016,22027]
trailer [22016,22027]
===
match
---
simple_stmt [60005,60032]
simple_stmt [59957,59984]
===
match
---
name: info [47634,47638]
name: info [47634,47638]
===
match
---
name: signal [48632,48638]
name: signal [48632,48638]
===
match
---
name: test_mode [44205,44214]
name: test_mode [44205,44214]
===
match
---
atom_expr [54964,54973]
atom_expr [54963,54972]
===
match
---
name: error [59187,59192]
name: error [59139,59144]
===
match
---
fstring [49361,49371]
fstring [49361,49371]
===
match
---
name: state [12155,12160]
name: state [12155,12160]
===
match
---
operator: = [76471,76472]
operator: = [76423,76424]
===
match
---
trailer [50446,50455]
trailer [50484,50493]
===
match
---
expr_stmt [10583,10904]
expr_stmt [10583,10904]
===
match
---
suite [44276,44416]
suite [44276,44416]
===
match
---
operator: = [61601,61602]
operator: = [61553,61554]
===
match
---
name: log [67923,67926]
name: log [67875,67878]
===
match
---
atom_expr [26229,26256]
atom_expr [26229,26256]
===
match
---
name: STATICA_HACK [82402,82414]
name: STATICA_HACK [82354,82366]
===
match
---
atom_expr [49193,49249]
atom_expr [49193,49249]
===
match
---
trailer [80033,80042]
trailer [79985,79994]
===
match
---
suite [63110,63189]
suite [63062,63141]
===
match
---
name: Exception [4501,4510]
name: Exception [4501,4510]
===
match
---
trailer [37594,37604]
trailer [37594,37604]
===
match
---
atom_expr [49072,49083]
atom_expr [49072,49083]
===
match
---
trailer [33728,33739]
trailer [33728,33739]
===
match
---
trailer [22671,22687]
trailer [22671,22687]
===
match
---
trailer [58769,58775]
trailer [58768,58774]
===
match
---
atom_expr [8767,8778]
atom_expr [8767,8778]
===
match
---
atom_expr [43216,43226]
atom_expr [43216,43226]
===
match
---
if_stmt [11729,11933]
if_stmt [11729,11933]
===
match
---
name: task_retries [5608,5620]
name: task_retries [5608,5620]
===
match
---
name: in_env_var_format [49226,49243]
name: in_env_var_format [49226,49243]
===
match
---
atom_expr [21640,21659]
atom_expr [21640,21659]
===
match
---
simple_stmt [82390,82400]
simple_stmt [82342,82352]
===
match
---
operator: = [54492,54493]
operator: = [54491,54492]
===
match
---
name: statement [47984,47993]
name: statement [47984,47993]
===
match
---
expr_stmt [42833,42863]
expr_stmt [42833,42863]
===
match
---
name: Index [10710,10715]
name: Index [10710,10715]
===
match
---
name: execution_date [78388,78402]
name: execution_date [78340,78354]
===
match
---
trailer [22588,22599]
trailer [22588,22599]
===
match
---
name: state [52902,52907]
name: state [52901,52906]
===
match
---
simple_stmt [1615,1813]
simple_stmt [1615,1813]
===
match
---
atom_expr [9570,9628]
atom_expr [9570,9628]
===
match
---
atom_expr [39062,39077]
atom_expr [39062,39077]
===
match
---
name: self [25014,25018]
name: self [25014,25018]
===
match
---
name: UtcDateTime [9657,9668]
name: UtcDateTime [9657,9668]
===
match
---
if_stmt [38032,40537]
if_stmt [38032,40537]
===
match
---
name: tis [78016,78019]
name: tis [77968,77971]
===
match
---
trailer [48784,48840]
trailer [48784,48840]
===
match
---
name: utils [2503,2508]
name: utils [2503,2508]
===
match
---
name: pool [54274,54278]
name: pool [54273,54277]
===
match
---
name: warning [40064,40071]
name: warning [40064,40071]
===
match
---
name: self [63001,63005]
name: self [62953,62957]
===
match
---
atom_expr [56907,56920]
atom_expr [56906,56919]
===
match
---
import_from [66296,66366]
import_from [66248,66318]
===
match
---
operator: , [15957,15958]
operator: , [15957,15958]
===
match
---
atom_expr [18707,18728]
atom_expr [18707,18728]
===
match
---
param [4791,4800]
param [4791,4800]
===
match
---
expr_stmt [46918,46943]
expr_stmt [46918,46943]
===
match
---
name: exception [71595,71604]
name: exception [71547,71556]
===
match
---
trailer [80738,80747]
trailer [80690,80699]
===
match
---
operator: = [26883,26884]
operator: = [26883,26884]
===
match
---
operator: = [10111,10112]
operator: = [10111,10112]
===
match
---
simple_stmt [1103,1134]
simple_stmt [1103,1134]
===
match
---
try_stmt [4446,4709]
try_stmt [4446,4709]
===
match
---
trailer [3583,3590]
trailer [3583,3590]
===
match
---
atom_expr [37515,37524]
atom_expr [37515,37524]
===
match
---
name: TaskInstance [77702,77714]
name: TaskInstance [77654,77666]
===
match
---
atom_expr [78915,78924]
atom_expr [78867,78876]
===
match
---
name: self [24353,24357]
name: self [24353,24357]
===
match
---
name: self [39113,39117]
name: self [39113,39117]
===
match
---
simple_stmt [4237,4276]
simple_stmt [4237,4276]
===
match
---
return_stmt [69159,69179]
return_stmt [69111,69131]
===
match
---
simple_stmt [33325,33355]
simple_stmt [33325,33355]
===
match
---
import_from [2365,2399]
import_from [2365,2399]
===
match
---
trailer [68024,68031]
trailer [67976,67983]
===
match
---
trailer [23481,23493]
trailer [23481,23493]
===
match
---
param [30430,30434]
param [30430,30434]
===
match
---
atom_expr [71899,71928]
atom_expr [71851,71880]
===
match
---
operator: @ [8152,8153]
operator: @ [8152,8153]
===
match
---
arith_expr [8577,8596]
arith_expr [8577,8596]
===
match
---
name: self [54964,54968]
name: self [54963,54967]
===
match
---
name: error [56636,56641]
name: error [56635,56640]
===
match
---
name: state [55768,55773]
name: state [55767,55772]
===
match
---
atom_expr [11503,11540]
atom_expr [11503,11540]
===
match
---
name: dag_id [20351,20357]
name: dag_id [20351,20357]
===
match
---
return_stmt [18877,18887]
return_stmt [18877,18887]
===
match
---
atom_expr [63127,63135]
atom_expr [63079,63087]
===
match
---
trailer [49460,49482]
trailer [49460,49482]
===
match
---
name: self [67792,67796]
name: self [67744,67748]
===
match
---
atom_expr [21996,22011]
atom_expr [21996,22011]
===
match
---
operator: = [42646,42647]
operator: = [42646,42647]
===
match
---
if_stmt [60164,60655]
if_stmt [60116,60607]
===
match
---
operator: , [13300,13301]
operator: , [13300,13301]
===
match
---
operator: @ [28095,28096]
operator: @ [28095,28096]
===
match
---
trailer [55512,55517]
trailer [55511,55516]
===
match
---
trailer [5982,6003]
trailer [5982,6003]
===
match
---
name: task_id [77170,77177]
name: task_id [77122,77129]
===
match
---
operator: , [68531,68532]
operator: , [68483,68484]
===
match
---
atom_expr [43873,43910]
atom_expr [43873,43910]
===
match
---
name: dr [35432,35434]
name: dr [35432,35434]
===
match
---
name: kube_config [68398,68409]
name: kube_config [68350,68361]
===
match
---
name: jinja_env [71800,71809]
name: jinja_env [71752,71761]
===
match
---
name: jinja2 [1207,1213]
name: jinja2 [1207,1213]
===
match
---
name: self [63904,63908]
name: self [63856,63860]
===
match
---
name: item [63569,63573]
name: item [63521,63525]
===
match
---
arglist [58634,58663]
arglist [58633,58662]
===
match
---
atom_expr [45435,45466]
atom_expr [45435,45466]
===
match
---
trailer [60243,60250]
trailer [60195,60202]
===
match
---
number: 1000 [10218,10222]
number: 1000 [10218,10222]
===
match
---
operator: , [79631,79632]
operator: , [79583,79584]
===
match
---
trailer [40864,40872]
trailer [40864,40872]
===
match
---
name: dag_id [68491,68497]
name: dag_id [68443,68449]
===
match
---
atom_expr [68412,68424]
atom_expr [68364,68376]
===
match
---
name: try_number [40268,40278]
name: try_number [40268,40278]
===
match
---
suite [4450,4486]
suite [4450,4486]
===
match
---
param [66228,66232]
param [66180,66184]
===
match
---
suite [81367,81395]
suite [81319,81347]
===
match
---
operator: , [49224,49225]
operator: , [49224,49225]
===
match
---
name: include_prior_dates [76628,76647]
name: include_prior_dates [76580,76599]
===
match
---
name: self [12460,12464]
name: self [12460,12464]
===
match
---
param [26493,26498]
param [26493,26498]
===
match
---
name: ti [47272,47274]
name: ti [47272,47274]
===
match
---
atom_expr [41123,41148]
atom_expr [41123,41148]
===
match
---
trailer [58507,58514]
trailer [58506,58513]
===
match
---
name: query [82060,82065]
name: query [82012,82017]
===
match
---
name: self [60859,60863]
name: self [60811,60815]
===
match
---
expr_stmt [52665,52681]
expr_stmt [52664,52680]
===
match
---
trailer [55083,55085]
trailer [55082,55084]
===
match
---
atom_expr [22602,22615]
atom_expr [22602,22615]
===
match
---
name: pool [10016,10020]
name: pool [10016,10020]
===
match
---
simple_stmt [78434,78464]
simple_stmt [78386,78416]
===
match
---
name: timedelta [34633,34642]
name: timedelta [34633,34642]
===
match
---
name: ignore_all_deps [39655,39670]
name: ignore_all_deps [39655,39670]
===
match
---
name: self [79953,79957]
name: self [79905,79909]
===
match
---
trailer [71214,71221]
trailer [71166,71173]
===
match
---
name: error_file [44386,44396]
name: error_file [44386,44396]
===
match
---
string: '' [62392,62394]
string: '' [62344,62346]
===
match
---
atom_expr [81145,81156]
atom_expr [81097,81108]
===
match
---
parameters [74469,74752]
parameters [74421,74704]
===
match
---
atom_expr [62067,62105]
atom_expr [62019,62057]
===
match
---
comparison [52697,52733]
comparison [52696,52732]
===
match
---
operator: = [5277,5278]
operator: = [5277,5278]
===
match
---
operator: , [24023,24024]
operator: , [24023,24024]
===
match
---
trailer [55351,55360]
trailer [55350,55359]
===
match
---
simple_stmt [18763,18799]
simple_stmt [18763,18799]
===
match
---
trailer [32500,32502]
trailer [32500,32502]
===
match
---
funcdef [77844,77974]
funcdef [77796,77926]
===
match
---
name: dag_id [76449,76455]
name: dag_id [76401,76407]
===
match
---
name: jinja_env [71176,71185]
name: jinja_env [71128,71137]
===
match
---
name: try_number [33970,33980]
name: try_number [33970,33980]
===
match
---
name: or_ [6833,6836]
name: or_ [6833,6836]
===
match
---
expr_stmt [60547,60591]
expr_stmt [60499,60543]
===
match
---
name: __tablename__ [9451,9464]
name: __tablename__ [9451,9464]
===
match
---
name: airflow_context_vars [49170,49190]
name: airflow_context_vars [49170,49190]
===
match
---
name: _executor_config [80138,80154]
name: _executor_config [80090,80106]
===
match
---
expr_stmt [43034,43071]
expr_stmt [43034,43071]
===
match
---
atom_expr [11786,11845]
atom_expr [11786,11845]
===
match
---
name: self [13318,13322]
name: self [13318,13322]
===
match
---
trailer [7978,7980]
trailer [7978,7980]
===
match
---
return_stmt [27276,27351]
return_stmt [27276,27351]
===
match
---
operator: = [10920,10921]
operator: = [10920,10921]
===
match
---
trailer [18773,18798]
trailer [18773,18798]
===
match
---
simple_stmt [12608,12668]
simple_stmt [12608,12668]
===
match
---
argument [26901,26916]
argument [26901,26916]
===
match
---
parameters [25143,25149]
parameters [25143,25149]
===
match
---
string: """Return task instance primary key part of the key""" [8222,8276]
string: """Return task instance primary key part of the key""" [8222,8276]
===
match
---
string: """         Checks whether the immediate dependents of this task instance have succeeded or have been skipped.         This is meant to be used by wait_for_downstream.          This is useful when you do not want to start processing the next         schedule of a task until the dependents are done. For instance,         if the task DROPs and recreates a table.          :param session: SQLAlchemy ORM Session         :type session: Session         """ [25490,25943]
string: """         Checks whether the immediate dependents of this task instance have succeeded or have been skipped.         This is meant to be used by wait_for_downstream.          This is useful when you do not want to start processing the next         schedule of a task until the dependents are done. For instance,         if the task DROPs and recreates a table.          :param session: SQLAlchemy ORM Session         :type session: Session         """ [25490,25943]
===
match
---
name: self [49262,49266]
name: self [49262,49266]
===
match
---
dotted_name [1818,1837]
dotted_name [1818,1837]
===
match
---
atom_expr [4408,4430]
atom_expr [4408,4430]
===
match
---
name: default_subject [69547,69562]
name: default_subject [69499,69514]
===
match
---
name: execution_date [46241,46255]
name: execution_date [46241,46255]
===
match
---
atom_expr [65514,65527]
atom_expr [65466,65479]
===
match
---
operator: = [12400,12401]
operator: = [12400,12401]
===
match
---
trailer [53144,53157]
trailer [53143,53156]
===
match
---
operator: , [26330,26331]
operator: , [26330,26331]
===
match
---
name: result [77051,77057]
name: result [77003,77009]
===
match
---
name: self [53034,53038]
name: self [53033,53037]
===
match
---
operator: , [15137,15138]
operator: , [15137,15138]
===
match
---
name: job_id [37698,37704]
name: job_id [37698,37704]
===
match
---
if_stmt [45853,48085]
if_stmt [45853,48085]
===
match
---
import_from [1874,1908]
import_from [1874,1908]
===
match
---
operator: = [9622,9623]
operator: = [9622,9623]
===
match
---
name: test_mode [40948,40957]
name: test_mode [40948,40957]
===
match
---
trailer [23462,23474]
trailer [23462,23474]
===
match
---
trailer [20305,20494]
trailer [20305,20494]
===
match
---
trailer [26900,26917]
trailer [26900,26917]
===
match
---
name: cfg_path [14369,14377]
name: cfg_path [14369,14377]
===
match
---
operator: , [24447,24448]
operator: , [24447,24448]
===
match
---
atom_expr [18294,18335]
atom_expr [18294,18335]
===
match
---
name: session [74722,74729]
name: session [74674,74681]
===
match
---
if_stmt [38524,38722]
if_stmt [38524,38722]
===
match
---
operator: - [82449,82450]
operator: - [82401,82402]
===
match
---
or_test [23323,23349]
or_test [23323,23349]
===
match
---
return_stmt [78751,78953]
return_stmt [78703,78905]
===
match
---
trailer [66720,66722]
trailer [66672,66674]
===
match
---
atom_expr [6900,6924]
atom_expr [6900,6924]
===
match
---
annassign [79914,79944]
annassign [79866,79896]
===
match
---
trailer [62195,62212]
trailer [62147,62164]
===
match
---
name: _Variable__NO_DEFAULT_SENTINEL [64378,64408]
name: _Variable__NO_DEFAULT_SENTINEL [64330,64360]
===
match
---
param [14286,14301]
param [14286,14301]
===
match
---
name: commit [60646,60652]
name: commit [60598,60604]
===
match
---
name: utils [2763,2768]
name: utils [2763,2768]
===
match
---
atom_expr [65273,65389]
atom_expr [65225,65341]
===
match
---
trailer [81281,81286]
trailer [81233,81238]
===
match
---
decorator [32327,32344]
decorator [32327,32344]
===
match
---
trailer [44904,44941]
trailer [44904,44941]
===
match
---
atom_expr [10173,10188]
atom_expr [10173,10188]
===
match
---
simple_stmt [46960,47019]
simple_stmt [46960,47019]
===
match
---
atom_expr [23592,23605]
atom_expr [23592,23605]
===
match
---
arglist [58936,58977]
arglist [58930,58971]
===
match
---
string: 'start_date' [58634,58646]
string: 'start_date' [58633,58645]
===
match
---
operator: , [72686,72687]
operator: , [72638,72639]
===
match
---
expr_stmt [80004,80042]
expr_stmt [79956,79994]
===
match
---
operator: = [44929,44930]
operator: = [44929,44930]
===
match
---
trailer [40505,40507]
trailer [40505,40507]
===
match
---
operator: { [19707,19708]
operator: { [19707,19708]
===
match
---
atom_expr [24108,24124]
atom_expr [24108,24124]
===
match
---
atom_expr [11822,11844]
atom_expr [11822,11844]
===
match
---
fstring_expr [19428,19441]
fstring_expr [19428,19441]
===
match
---
arglist [20323,20480]
arglist [20323,20480]
===
match
---
trailer [25366,25379]
trailer [25366,25379]
===
match
---
atom_expr [79122,79184]
atom_expr [79074,79136]
===
match
---
name: execution_date [7777,7791]
name: execution_date [7777,7791]
===
match
---
name: self [50794,50798]
name: self [50832,50836]
===
match
---
operator: , [6968,6969]
operator: , [6968,6969]
===
match
---
argument [38400,38445]
argument [38400,38445]
===
match
---
trailer [74135,74142]
trailer [74087,74094]
===
match
---
name: on_kill [51627,51634]
name: on_kill [51665,51672]
===
match
---
name: replace [62130,62137]
name: replace [62082,62089]
===
match
---
trailer [25051,25062]
trailer [25051,25062]
===
match
---
trailer [56931,56938]
trailer [56930,56937]
===
match
---
trailer [77080,77106]
trailer [77032,77058]
===
match
---
name: info [40586,40590]
name: info [40586,40590]
===
match
---
operator: = [10051,10052]
operator: = [10051,10052]
===
match
---
name: self [80958,80962]
name: self [80910,80914]
===
match
---
simple_stmt [45946,46012]
simple_stmt [45946,46012]
===
match
---
name: int [80389,80392]
name: int [80341,80344]
===
match
---
operator: = [10129,10130]
operator: = [10129,10130]
===
match
---
trailer [48876,48893]
trailer [48876,48893]
===
match
---
atom_expr [80075,80088]
atom_expr [80027,80040]
===
match
---
funcdef [41435,41631]
funcdef [41435,41631]
===
match
---
atom_expr [55094,55113]
atom_expr [55093,55112]
===
match
---
operator: = [9893,9894]
operator: = [9893,9894]
===
match
---
atom [60778,60814]
atom [60730,60766]
===
match
---
trailer [27807,27837]
trailer [27807,27837]
===
match
---
atom_expr [12391,12399]
atom_expr [12391,12399]
===
match
---
trailer [62614,62649]
trailer [62566,62601]
===
match
---
name: task_copy [51452,51461]
name: task_copy [51490,51499]
===
match
---
name: dag_id [21653,21659]
name: dag_id [21653,21659]
===
match
---
name: end_date [55352,55360]
name: end_date [55351,55359]
===
match
---
name: _try_number [55577,55588]
name: _try_number [55576,55587]
===
match
---
atom_expr [60443,60458]
atom_expr [60395,60410]
===
match
---
name: queue [10123,10128]
name: queue [10123,10128]
===
match
---
name: TaskInstance [21640,21652]
name: TaskInstance [21640,21652]
===
match
---
trailer [67932,68005]
trailer [67884,67957]
===
match
---
trailer [30931,30952]
trailer [30931,30952]
===
match
---
trailer [31841,31847]
trailer [31841,31847]
===
match
---
fstring [50649,50692]
fstring [50687,50730]
===
match
---
atom_expr [71559,71772]
atom_expr [71511,71724]
===
match
---
trailer [82212,82227]
trailer [82164,82179]
===
match
---
tfpdef [53636,53657]
tfpdef [53635,53656]
===
match
---
name: jinja_context [71224,71237]
name: jinja_context [71176,71189]
===
match
---
trailer [80247,80266]
trailer [80199,80218]
===
match
---
trailer [48339,48344]
trailer [48339,48344]
===
match
---
name: State [44670,44675]
name: State [44670,44675]
===
match
---
trailer [40901,40903]
trailer [40901,40903]
===
match
---
name: FAILED [57944,57950]
name: FAILED [57943,57949]
===
match
---
simple_stmt [10229,10263]
simple_stmt [10229,10263]
===
match
---
name: partial_dag [47122,47133]
name: partial_dag [47122,47133]
===
match
---
name: xcom_pull [74460,74469]
name: xcom_pull [74412,74421]
===
match
---
dotted_name [3316,3341]
dotted_name [3316,3341]
===
match
---
name: Variable [63138,63146]
name: Variable [63090,63098]
===
match
---
trailer [40429,40436]
trailer [40429,40436]
===
match
---
name: Iterable [1052,1060]
name: Iterable [1052,1060]
===
match
---
name: Log [40812,40815]
name: Log [40812,40815]
===
match
---
name: task [5548,5552]
name: task [5548,5552]
===
match
---
name: self [45311,45315]
name: self [45311,45315]
===
match
---
if_stmt [62473,62528]
if_stmt [62425,62480]
===
match
---
trailer [41131,41138]
trailer [41131,41138]
===
match
---
operator: , [69219,69220]
operator: , [69171,69172]
===
match
---
atom_expr [37590,37604]
atom_expr [37590,37604]
===
match
---
name: self [81145,81149]
name: self [81097,81101]
===
match
---
string: """         Make an XCom available for tasks to pull.          :param key: A key for the XCom         :type key: str         :param value: A value for the XCom. The value is pickled and stored             in the database.         :type value: any picklable object         :param execution_date: if provided, the XCom will not be visible until             this date. This can be used, for example, to send a message to a             task on a future date without it being immediately visible.         :type execution_date: datetime         :param session: Sqlalchemy ORM Session         :type session: Session         """ [73298,73918]
string: """         Make an XCom available for tasks to pull.          :param key: A key for the XCom         :type key: str         :param value: A value for the XCom. The value is pickled and stored             in the database.         :type value: any picklable object         :param execution_date: if provided, the XCom will not be visible until             this date. This can be used, for example, to send a message to a             task on a future date without it being immediately visible.         :type execution_date: datetime         :param session: Sqlalchemy ORM Session         :type session: Session         """ [73250,73870]
===
match
---
atom_expr [5372,5382]
atom_expr [5372,5382]
===
match
---
funcdef [15511,18888]
funcdef [15511,18888]
===
match
---
operator: = [56311,56312]
operator: = [56310,56311]
===
match
---
name: deserialize_model_file [68978,69000]
name: deserialize_model_file [68930,68952]
===
match
---
funcdef [72800,73098]
funcdef [72752,73050]
===
match
---
atom_expr [26190,26214]
atom_expr [26190,26214]
===
match
---
or_test [24878,24942]
or_test [24878,24942]
===
match
---
atom_expr [59088,59104]
atom_expr [59040,59056]
===
match
---
simple_stmt [53309,53338]
simple_stmt [53308,53337]
===
match
---
operator: = [46327,46328]
operator: = [46327,46328]
===
match
---
sync_comp_for [47268,47338]
sync_comp_for [47268,47338]
===
match
---
simple_stmt [18377,18415]
simple_stmt [18377,18415]
===
match
---
operator: -> [29845,29847]
operator: -> [29845,29847]
===
match
---
tfpdef [56186,56211]
tfpdef [56185,56210]
===
match
---
name: error_fd [54629,54637]
name: error_fd [54628,54636]
===
match
---
name: test_mode [42671,42680]
name: test_mode [42671,42680]
===
match
---
funcdef [25437,26438]
funcdef [25437,26438]
===
match
---
trailer [68348,68354]
trailer [68300,68306]
===
match
---
trailer [53358,53376]
trailer [53357,53375]
===
match
---
name: TaskInstanceKey [7989,8004]
name: TaskInstanceKey [7989,8004]
===
match
---
operator: = [10099,10100]
operator: = [10099,10100]
===
match
---
name: base_worker_pod [68949,68964]
name: base_worker_pod [68901,68916]
===
match
---
name: self [32747,32751]
name: self [32747,32751]
===
match
---
name: add [45552,45555]
name: add [45552,45555]
===
match
---
trailer [23296,23302]
trailer [23296,23302]
===
match
---
atom_expr [49350,49414]
atom_expr [49350,49414]
===
match
---
operator: + [19368,19369]
operator: + [19368,19369]
===
match
---
name: isoformat [60743,60752]
name: isoformat [60695,60704]
===
match
---
param [51993,51997]
param [52031,52035]
===
match
---
decorator [80931,80941]
decorator [80883,80893]
===
match
---
trailer [40362,40370]
trailer [40362,40370]
===
match
---
name: path [15370,15374]
name: path [15370,15374]
===
match
---
string: "Clearing XCom data" [23885,23905]
string: "Clearing XCom data" [23885,23905]
===
match
---
trailer [14871,14885]
trailer [14871,14885]
===
match
---
funcdef [68307,69180]
funcdef [68259,69132]
===
match
---
trailer [14608,14613]
trailer [14608,14613]
===
match
---
atom_expr [47278,47298]
atom_expr [47278,47298]
===
match
---
name: self [55163,55167]
name: self [55162,55166]
===
match
---
name: ts [62241,62243]
name: ts [62193,62195]
===
match
---
name: airflow [3101,3108]
name: airflow [3101,3108]
===
match
---
arglist [4058,4072]
arglist [4058,4072]
===
match
---
operator: = [80073,80074]
operator: = [80025,80026]
===
match
---
trailer [56441,56451]
trailer [56440,56450]
===
match
---
name: ti [80116,80118]
name: ti [80068,80070]
===
match
---
operator: -> [26558,26560]
operator: -> [26558,26560]
===
match
---
file_input [787,82702]
file_input [787,82654]
===
match
---
operator: = [23517,23518]
operator: = [23517,23518]
===
match
---
operator: , [59413,59414]
operator: , [59365,59366]
===
match
---
name: SHUTDOWN [7502,7510]
name: SHUTDOWN [7502,7510]
===
match
---
simple_stmt [7554,7620]
simple_stmt [7554,7620]
===
match
---
suite [67609,67715]
suite [67561,67667]
===
match
---
name: self [20399,20403]
name: self [20399,20403]
===
match
---
strings [19673,19858]
strings [19673,19858]
===
match
---
suite [8668,8827]
suite [8668,8827]
===
match
---
simple_stmt [787,805]
simple_stmt [787,805]
===
match
---
trailer [25351,25357]
trailer [25351,25357]
===
match
---
name: self [60723,60727]
name: self [60675,60679]
===
match
---
if_stmt [26860,28069]
if_stmt [26860,28069]
===
match
---
argument [30206,30221]
argument [30206,30221]
===
match
---
operator: , [58704,58705]
operator: , [58703,58704]
===
match
---
expr_stmt [24956,25001]
expr_stmt [24956,25001]
===
match
---
except_clause [43251,43290]
except_clause [43251,43290]
===
match
---
atom_expr [40971,40990]
atom_expr [40971,40990]
===
match
---
expr_stmt [53886,54323]
expr_stmt [53885,54322]
===
match
---
atom_expr [3669,3691]
atom_expr [3669,3691]
===
match
---
if_stmt [18423,18503]
if_stmt [18423,18503]
===
match
---
name: all [78662,78665]
name: all [78614,78617]
===
match
---
expr_stmt [71017,71153]
expr_stmt [70969,71105]
===
match
---
atom_expr [77061,77106]
atom_expr [77013,77058]
===
match
---
simple_stmt [77216,77244]
simple_stmt [77168,77196]
===
match
---
parameters [19191,19197]
parameters [19191,19197]
===
match
---
import_from [1202,1259]
import_from [1202,1259]
===
match
---
expr_stmt [46960,47018]
expr_stmt [46960,47018]
===
match
---
name: TR [7239,7241]
name: TR [7239,7241]
===
match
---
name: context [53024,53031]
name: context [53023,53030]
===
match
---
param [8370,8374]
param [8370,8374]
===
match
---
trailer [41146,41148]
trailer [41146,41148]
===
match
---
sync_comp_for [47107,47210]
sync_comp_for [47107,47210]
===
match
---
operator: = [76688,76689]
operator: = [76640,76641]
===
match
---
operator: , [14994,14995]
operator: , [14994,14995]
===
match
---
funcdef [59486,59642]
funcdef [59438,59594]
===
match
---
operator: @ [35136,35137]
operator: @ [35136,35137]
===
match
---
atom_expr [52970,52994]
atom_expr [52969,52993]
===
match
---
operator: , [58664,58665]
operator: , [58663,58664]
===
match
---
operator: = [51719,51720]
operator: = [51757,51758]
===
match
---
suite [60188,60655]
suite [60140,60607]
===
match
---
name: send_email [72740,72750]
name: send_email [72692,72702]
===
match
---
operator: { [19790,19791]
operator: { [19790,19791]
===
match
---
trailer [50486,50500]
trailer [50524,50538]
===
match
---
name: task_id [28043,28050]
name: task_id [28043,28050]
===
match
---
atom_expr [30448,30465]
atom_expr [30448,30465]
===
match
---
name: _run_execute_callback [49630,49651]
name: _run_execute_callback [49630,49651]
===
match
---
atom_expr [43814,43825]
atom_expr [43814,43825]
===
match
---
string: 'Mark success: <a href="{{ti.mark_success_url}}">Link</a><br>' [70447,70509]
string: 'Mark success: <a href="{{ti.mark_success_url}}">Link</a><br>' [70399,70461]
===
match
---
name: e [44762,44763]
name: e [44762,44763]
===
match
---
param [4314,4342]
param [4314,4342]
===
match
---
operator: , [26215,26216]
operator: , [26215,26216]
===
match
---
return_stmt [79046,79254]
return_stmt [78998,79206]
===
match
---
simple_stmt [43651,44026]
simple_stmt [43651,44026]
===
match
---
name: self [59586,59590]
name: self [59538,59542]
===
match
---
suite [43291,43340]
suite [43291,43340]
===
match
---
name: priority_weight [81248,81263]
name: priority_weight [81200,81215]
===
match
---
name: pool [53782,53786]
name: pool [53781,53785]
===
match
---
name: load_error_file [54769,54784]
name: load_error_file [54768,54783]
===
match
---
operator: = [14917,14918]
operator: = [14917,14918]
===
match
---
simple_stmt [12539,12600]
simple_stmt [12539,12600]
===
match
---
name: first [21868,21873]
name: first [21868,21873]
===
match
---
name: state [20551,20556]
name: state [20551,20556]
===
match
---
operator: = [76514,76515]
operator: = [76466,76467]
===
match
---
fstring_string: __ [62433,62435]
fstring_string: __ [62385,62387]
===
match
---
comparison [77650,77684]
comparison [77602,77636]
===
match
---
name: str [15609,15612]
name: str [15609,15612]
===
match
---
tfpdef [73161,73169]
tfpdef [73113,73121]
===
match
---
atom_expr [20399,20411]
atom_expr [20399,20411]
===
match
---
trailer [8309,8317]
trailer [8309,8317]
===
match
---
name: session [48066,48073]
name: session [48066,48073]
===
match
---
string: 'run_as_user' [80252,80265]
string: 'run_as_user' [80204,80217]
===
match
---
name: inlets [64857,64863]
name: inlets [64809,64815]
===
match
---
atom_expr [33693,33714]
atom_expr [33693,33714]
===
match
---
trailer [5216,5224]
trailer [5216,5224]
===
match
---
name: html_content [72688,72700]
name: html_content [72640,72652]
===
match
---
operator: , [64668,64669]
operator: , [64620,64621]
===
match
---
trailer [10137,10150]
trailer [10137,10150]
===
match
---
atom_expr [69501,69537]
atom_expr [69453,69489]
===
match
---
operator: == [35507,35509]
operator: == [35507,35509]
===
match
---
argument [37663,37683]
argument [37663,37683]
===
match
---
name: pickle [864,870]
name: pickle [864,870]
===
match
---
operator: } [33039,33040]
operator: } [33039,33040]
===
match
---
operator: , [10888,10889]
operator: , [10888,10889]
===
match
---
name: Sentry [41658,41664]
name: Sentry [41658,41664]
===
match
---
name: priority_weight [80483,80498]
name: priority_weight [80435,80450]
===
match
---
operator: = [27901,27902]
operator: = [27901,27902]
===
match
---
trailer [39117,39123]
trailer [39117,39123]
===
match
---
name: self [19746,19750]
name: self [19746,19750]
===
match
---
operator: = [9496,9497]
operator: = [9496,9497]
===
match
---
operator: = [61299,61300]
operator: = [61251,61252]
===
match
---
trailer [56018,56023]
trailer [56017,56022]
===
match
---
arglist [70802,70971]
arglist [70754,70923]
===
match
---
simple_stmt [14912,14924]
simple_stmt [14912,14924]
===
match
---
name: with_for_update [21850,21865]
name: with_for_update [21850,21865]
===
match
---
name: ignore_ti_state [15273,15288]
name: ignore_ti_state [15273,15288]
===
match
---
name: _safe_date [58623,58633]
name: _safe_date [58622,58632]
===
match
---
atom_expr [26506,26519]
atom_expr [26506,26519]
===
match
---
name: get_failed_dep_statuses [32352,32375]
name: get_failed_dep_statuses [32352,32375]
===
match
---
operator: , [82135,82136]
operator: , [82087,82088]
===
match
---
expr_stmt [3242,3278]
expr_stmt [3242,3278]
===
match
---
name: _try_number [13887,13898]
name: _try_number [13887,13898]
===
match
---
import_from [1615,1812]
import_from [1615,1812]
===
match
---
name: start_date [79985,79995]
name: start_date [79937,79947]
===
match
---
name: state [33085,33090]
name: state [33085,33090]
===
match
---
name: handle_failure [44747,44761]
name: handle_failure [44747,44761]
===
match
---
operator: , [54283,54284]
operator: , [54282,54283]
===
match
---
trailer [22882,22886]
trailer [22882,22886]
===
match
---
simple_stmt [1394,1449]
simple_stmt [1394,1449]
===
match
---
number: 1 [57030,57031]
number: 1 [57029,57030]
===
match
---
trailer [56205,56211]
trailer [56204,56210]
===
match
---
name: min [34616,34619]
name: min [34616,34619]
===
match
---
name: raw [12396,12399]
name: raw [12396,12399]
===
match
---
name: self [68519,68523]
name: self [68471,68475]
===
match
---
name: unixname [22495,22503]
name: unixname [22495,22503]
===
match
---
operator: = [35888,35889]
operator: = [35888,35889]
===
match
---
trailer [24723,24727]
trailer [24723,24727]
===
match
---
trailer [52403,52419]
trailer [52402,52418]
===
match
---
name: email [2419,2424]
name: email [2419,2424]
===
match
---
and_test [29663,29716]
and_test [29663,29716]
===
match
---
trailer [30456,30465]
trailer [30456,30465]
===
match
---
fstring_expr [33027,33040]
fstring_expr [33027,33040]
===
match
---
trailer [55103,55111]
trailer [55102,55110]
===
match
---
operator: = [25028,25029]
operator: = [25028,25029]
===
match
---
atom_expr [62008,62032]
atom_expr [61960,61984]
===
match
---
trailer [72877,72886]
trailer [72829,72838]
===
match
---
name: state [5271,5276]
name: state [5271,5276]
===
match
---
fstring [19772,19796]
fstring [19772,19796]
===
match
---
name: reschedule_exception [44183,44203]
name: reschedule_exception [44183,44203]
===
match
---
trailer [76932,76942]
trailer [76884,76894]
===
match
---
operator: , [8547,8548]
operator: , [8547,8548]
===
match
---
name: ti [22411,22413]
name: ti [22411,22413]
===
match
---
name: reduced [8362,8369]
name: reduced [8362,8369]
===
match
---
name: __table__ [7242,7251]
name: __table__ [7242,7251]
===
match
---
name: airflow [2176,2183]
name: airflow [2176,2183]
===
match
---
name: bool [15795,15799]
name: bool [15795,15799]
===
match
---
trailer [59789,59798]
trailer [59741,59750]
===
match
---
name: self [64164,64168]
name: self [64116,64120]
===
match
---
funcdef [68051,68302]
funcdef [68003,68254]
===
match
---
trailer [78455,78463]
trailer [78407,78415]
===
match
---
atom_expr [66811,67173]
atom_expr [66763,67125]
===
match
---
name: _date_or_empty [43933,43947]
name: _date_or_empty [43933,43947]
===
match
---
trailer [56282,56287]
trailer [56281,56286]
===
match
---
operator: = [38585,38586]
operator: = [38585,38586]
===
match
---
simple_stmt [52850,52884]
simple_stmt [52849,52883]
===
match
---
trailer [19062,19092]
trailer [19062,19092]
===
match
---
name: e [67713,67714]
name: e [67665,67666]
===
match
---
name: job_id [15994,16000]
name: job_id [15994,16000]
===
match
---
name: state [20565,20570]
name: state [20565,20570]
===
match
---
name: include_prior_dates [76648,76667]
name: include_prior_dates [76600,76619]
===
match
---
simple_stmt [20993,21010]
simple_stmt [20993,21010]
===
match
---
operator: } [49369,49370]
operator: } [49369,49370]
===
match
---
trailer [77768,77774]
trailer [77720,77726]
===
match
---
atom_expr [7649,7864]
atom_expr [7649,7864]
===
match
---
tfpdef [3947,3960]
tfpdef [3947,3960]
===
match
---
exprlist [7074,7100]
exprlist [7074,7100]
===
match
---
atom_expr [72740,72794]
atom_expr [72692,72746]
===
match
---
operator: = [41916,41917]
operator: = [41916,41917]
===
match
---
expr_stmt [39062,39097]
expr_stmt [39062,39097]
===
match
---
name: task_id [9488,9495]
name: task_id [9488,9495]
===
match
---
trailer [19058,19062]
trailer [19058,19062]
===
match
---
tfpdef [8630,8645]
tfpdef [8630,8645]
===
match
---
name: self [40007,40011]
name: self [40007,40011]
===
match
---
atom_expr [15034,15053]
atom_expr [15034,15053]
===
match
---
name: self [69462,69466]
name: self [69414,69418]
===
match
---
name: v [49368,49369]
name: v [49368,49369]
===
match
---
simple_stmt [62501,62528]
simple_stmt [62453,62480]
===
match
---
name: pid [22821,22824]
name: pid [22821,22824]
===
match
---
and_test [7519,7544]
and_test [7519,7544]
===
match
---
and_test [78969,79018]
and_test [78921,78970]
===
match
---
atom_expr [9969,9981]
atom_expr [9969,9981]
===
match
---
name: tomorrow_ds [60844,60855]
name: tomorrow_ds [60796,60807]
===
match
---
expr_stmt [61991,62032]
expr_stmt [61943,61984]
===
match
---
expr_stmt [47479,47547]
expr_stmt [47479,47547]
===
match
---
argument [50614,50627]
argument [50652,50665]
===
match
---
name: sanitized_pod [69091,69104]
name: sanitized_pod [69043,69056]
===
match
---
name: execution_date [7800,7814]
name: execution_date [7800,7814]
===
match
---
name: utils [2560,2565]
name: utils [2560,2565]
===
match
---
fstring_expr [45041,45053]
fstring_expr [45041,45053]
===
match
---
name: DagRun [35391,35397]
name: DagRun [35391,35397]
===
match
---
expr_stmt [14755,14791]
expr_stmt [14755,14791]
===
match
---
name: start_date [80864,80874]
name: start_date [80816,80826]
===
match
---
operator: = [74351,74352]
operator: = [74303,74304]
===
match
---
trailer [57234,57245]
trailer [57233,57244]
===
match
---
atom_expr [62515,62526]
atom_expr [62467,62478]
===
match
---
name: dag_id [6096,6102]
name: dag_id [6096,6102]
===
match
---
name: self [42666,42670]
name: self [42666,42670]
===
match
---
name: self [8549,8553]
name: self [8549,8553]
===
match
---
name: ApiClient [3178,3187]
name: ApiClient [3178,3187]
===
match
---
trailer [4087,4092]
trailer [4087,4092]
===
match
---
atom_expr [47479,47498]
atom_expr [47479,47498]
===
match
---
operator: , [66122,66123]
operator: , [66074,66075]
===
match
---
name: result [59693,59699]
name: result [59645,59651]
===
match
---
operator: = [3274,3275]
operator: = [3274,3275]
===
match
---
atom_expr [50708,50734]
atom_expr [50746,50772]
===
match
---
simple_stmt [24303,24391]
simple_stmt [24303,24391]
===
match
---
trailer [47731,47738]
trailer [47731,47738]
===
match
---
operator: , [65126,65127]
operator: , [65078,65079]
===
match
---
name: _state [81150,81156]
name: _state [81102,81108]
===
match
---
trailer [49270,49275]
trailer [49270,49275]
===
match
---
simple_stmt [14399,14590]
simple_stmt [14399,14590]
===
match
---
suite [66588,66652]
suite [66540,66604]
===
match
---
trailer [39971,39977]
trailer [39971,39977]
===
match
---
trailer [54740,54746]
trailer [54739,54745]
===
match
---
parameters [80704,80710]
parameters [80656,80662]
===
match
---
fstring [48785,48839]
fstring [48785,48839]
===
match
---
operator: , [4744,4745]
operator: , [4744,4745]
===
match
---
trailer [11570,11716]
trailer [11570,11716]
===
match
---
param [55169,55187]
param [55168,55186]
===
match
---
trailer [22413,22423]
trailer [22413,22423]
===
match
---
atom_expr [42956,42968]
atom_expr [42956,42968]
===
match
---
name: ignore_depends_on_past [54047,54069]
name: ignore_depends_on_past [54046,54068]
===
match
---
name: self [34851,34855]
name: self [34851,34855]
===
match
---
annassign [80067,80088]
annassign [80019,80040]
===
match
---
operator: , [73081,73082]
operator: , [73033,73034]
===
match
---
atom_expr [3260,3273]
atom_expr [3260,3273]
===
match
---
trailer [17965,17975]
trailer [17965,17975]
===
match
---
trailer [72057,72062]
trailer [72009,72014]
===
match
---
raise_stmt [51062,51144]
raise_stmt [51100,51182]
===
match
---
simple_stmt [901,937]
simple_stmt [901,937]
===
match
---
trailer [7501,7510]
trailer [7501,7510]
===
match
---
name: XCom [77361,77365]
name: XCom [77313,77317]
===
match
---
name: is_localized [11512,11524]
name: is_localized [11512,11524]
===
match
---
suite [21107,22928]
suite [21107,22928]
===
match
---
string: "--raw" [18719,18726]
string: "--raw" [18719,18726]
===
match
---
operator: , [72191,72192]
operator: , [72143,72144]
===
match
---
trailer [14002,14014]
trailer [14002,14014]
===
match
---
funcdef [67186,67748]
funcdef [67138,67700]
===
match
---
simple_stmt [11769,11846]
simple_stmt [11769,11846]
===
match
---
name: self [18924,18928]
name: self [18924,18928]
===
match
---
atom_expr [22452,22463]
atom_expr [22452,22463]
===
match
---
string: """Overwrite Task Params with DagRun.conf""" [67824,67868]
string: """Overwrite Task Params with DagRun.conf""" [67776,67820]
===
match
---
trailer [51461,51479]
trailer [51499,51517]
===
match
---
atom_expr [52897,52907]
atom_expr [52896,52906]
===
match
---
trailer [19566,19576]
trailer [19566,19576]
===
match
---
operator: -> [81428,81430]
operator: -> [81380,81382]
===
match
---
trailer [71047,71153]
trailer [70999,71105]
===
match
---
expr_stmt [3652,3691]
expr_stmt [3652,3691]
===
match
---
trailer [40015,40023]
trailer [40015,40023]
===
match
---
simple_stmt [6628,7217]
simple_stmt [6628,7217]
===
match
---
atom_expr [6833,7026]
atom_expr [6833,7026]
===
match
---
tfpdef [63401,63417]
tfpdef [63353,63369]
===
match
---
name: force_fail [57866,57876]
name: force_fail [57865,57875]
===
match
---
trailer [53082,53102]
trailer [53081,53101]
===
match
---
name: DagRun [7770,7776]
name: DagRun [7770,7776]
===
match
---
name: e [43318,43319]
name: e [43318,43319]
===
match
---
suite [32209,32235]
suite [32209,32235]
===
match
---
name: task [23563,23567]
name: task [23563,23567]
===
match
---
name: tis [78341,78344]
name: tis [78293,78296]
===
match
---
operator: , [60179,60180]
operator: , [60131,60132]
===
match
---
operator: } [66188,66189]
operator: } [66140,66141]
===
match
---
name: TaskInstance [21688,21700]
name: TaskInstance [21688,21700]
===
match
---
simple_stmt [8406,8491]
simple_stmt [8406,8491]
===
match
---
name: session [54305,54312]
name: session [54304,54311]
===
match
---
name: task_id [8785,8792]
name: task_id [8785,8792]
===
match
---
name: cfg_path [15468,15476]
name: cfg_path [15468,15476]
===
match
---
atom_expr [74203,74429]
atom_expr [74155,74381]
===
match
---
with_stmt [4403,4709]
with_stmt [4403,4709]
===
match
---
name: COLLATION_ARGS [9522,9536]
name: COLLATION_ARGS [9522,9536]
===
match
---
trailer [61966,61978]
trailer [61918,61930]
===
match
---
arglist [5966,6003]
arglist [5966,6003]
===
match
---
if_stmt [78184,78220]
if_stmt [78136,78172]
===
match
---
expr_stmt [4078,4094]
expr_stmt [4078,4094]
===
match
---
trailer [48965,48998]
trailer [48965,48998]
===
match
---
name: _date_or_empty [43878,43892]
name: _date_or_empty [43878,43892]
===
match
---
number: 16 [34074,34076]
number: 16 [34074,34076]
===
match
---
operator: , [15422,15423]
operator: , [15422,15423]
===
match
---
simple_stmt [60638,60655]
simple_stmt [60590,60607]
===
match
---
testlist_comp [17993,18040]
testlist_comp [17993,18040]
===
match
---
dictorsetmaker [7727,7750]
dictorsetmaker [7727,7750]
===
match
---
atom_expr [50342,50377]
atom_expr [50380,50415]
===
match
---
operator: = [24970,24971]
operator: = [24970,24971]
===
match
---
name: SKIPPED [26323,26330]
name: SKIPPED [26323,26330]
===
match
---
except_clause [58846,58871]
except_clause [58845,58861]
===
match
---
operator: , [1088,1089]
operator: , [1088,1089]
===
match
---
atom_expr [10023,10058]
atom_expr [10023,10058]
===
match
---
trailer [10179,10188]
trailer [10179,10188]
===
match
---
atom_expr [38220,38511]
atom_expr [38220,38511]
===
match
---
simple_stmt [62727,62952]
simple_stmt [62679,62904]
===
match
---
operator: , [36041,36042]
operator: , [36041,36042]
===
match
---
trailer [43308,43312]
trailer [43308,43312]
===
match
---
name: Exception [56504,56513]
name: Exception [56503,56512]
===
match
---
operator: - [70921,70922]
operator: - [70873,70874]
===
match
---
name: dag_id [35500,35506]
name: dag_id [35500,35506]
===
match
---
name: taskfail [1929,1937]
name: taskfail [1929,1937]
===
match
---
comparison [59608,59641]
comparison [59560,59593]
===
match
---
string: """         Immediately runs the task (without checking or changing db state         before execution) and then sets the appropriate final state after         completion and runs any post-execute callbacks. Meant to be called         only after another function changes the state to running.          :param mark_success: Don't run the task, mark its state as success         :type mark_success: bool         :param test_mode: Doesn't record success or failure in the DB         :type test_mode: bool         :param pool: specifies the pool to use to run the task instance         :type pool: str         :param session: SQLAlchemy ORM Session         :type session: Session         """ [41946,42632]
string: """         Immediately runs the task (without checking or changing db state         before execution) and then sets the appropriate final state after         completion and runs any post-execute callbacks. Meant to be called         only after another function changes the state to running.          :param mark_success: Don't run the task, mark its state as success         :type mark_success: bool         :param test_mode: Doesn't record success or failure in the DB         :type test_mode: bool         :param pool: specifies the pool to use to run the task instance         :type pool: str         :param session: SQLAlchemy ORM Session         :type session: Session         """ [41946,42632]
===
match
---
name: tomorrow_ds [65776,65787]
name: tomorrow_ds [65728,65739]
===
match
---
operator: = [62672,62673]
operator: = [62624,62625]
===
match
---
name: session [26528,26535]
name: session [26528,26535]
===
match
---
trailer [73049,73055]
trailer [73001,73007]
===
match
---
trailer [68031,68045]
trailer [67983,67997]
===
match
---
name: self [41276,41280]
name: self [41276,41280]
===
match
---
arglist [59710,59731]
arglist [59662,59683]
===
match
---
name: __file__ [71112,71120]
name: __file__ [71064,71072]
===
match
---
if_stmt [27195,27259]
if_stmt [27195,27259]
===
match
---
arglist [19319,19342]
arglist [19319,19342]
===
match
---
trailer [82328,82330]
trailer [82280,82282]
===
match
---
name: self [41486,41490]
name: self [41486,41490]
===
match
---
name: FAILED [20950,20956]
name: FAILED [20950,20956]
===
match
---
atom_expr [80820,80840]
atom_expr [80772,80792]
===
match
---
operator: , [65899,65900]
operator: , [65851,65852]
===
match
---
name: try_number [8815,8825]
name: try_number [8815,8825]
===
match
---
atom [5086,5088]
atom [5086,5088]
===
match
---
name: update [68025,68031]
name: update [67977,67983]
===
match
---
with_item [72005,72020]
with_item [71957,71972]
===
match
---
name: error [56464,56469]
name: error [56463,56468]
===
match
---
trailer [46171,46298]
trailer [46171,46298]
===
match
---
name: context [3623,3630]
name: context [3623,3630]
===
match
---
name: query [21600,21605]
name: query [21600,21605]
===
match
---
name: render_templates [48860,48876]
name: render_templates [48860,48876]
===
match
---
trailer [71287,71309]
trailer [71239,71261]
===
match
---
dotted_name [1108,1120]
dotted_name [1108,1120]
===
match
---
operator: = [9465,9466]
operator: = [9465,9466]
===
match
---
suite [41466,41631]
suite [41466,41631]
===
match
---
trailer [63131,63135]
trailer [63083,63087]
===
match
---
expr_stmt [8085,8097]
expr_stmt [8085,8097]
===
match
---
simple_stmt [37625,37685]
simple_stmt [37625,37685]
===
match
---
atom_expr [25388,25410]
atom_expr [25388,25410]
===
match
---
name: xcom [2076,2080]
name: xcom [2076,2080]
===
match
---
operator: , [59369,59370]
operator: , [59321,59322]
===
match
---
expr_stmt [12086,12111]
expr_stmt [12086,12111]
===
match
---
trailer [45356,45374]
trailer [45356,45374]
===
match
---
operator: , [53830,53831]
operator: , [53829,53830]
===
match
---
simple_stmt [5445,5474]
simple_stmt [5445,5474]
===
match
---
trailer [68977,69000]
trailer [68929,68952]
===
match
---
name: start_date [30326,30336]
name: start_date [30326,30336]
===
match
---
simple_stmt [48448,48510]
simple_stmt [48448,48510]
===
match
---
expr_stmt [62155,62212]
expr_stmt [62107,62164]
===
match
---
name: key [74643,74646]
name: key [74595,74598]
===
match
---
trailer [61359,61374]
trailer [61311,61326]
===
match
---
string: '-' [62024,62027]
string: '-' [61976,61979]
===
match
---
name: task_copy [48347,48356]
name: task_copy [48347,48356]
===
match
---
simple_stmt [55957,55977]
simple_stmt [55956,55976]
===
match
---
operator: = [35963,35964]
operator: = [35963,35964]
===
match
---
expr_stmt [5577,5624]
expr_stmt [5577,5624]
===
match
---
fstring_expr [19111,19120]
fstring_expr [19111,19120]
===
match
---
name: ti [80480,80482]
name: ti [80432,80434]
===
match
---
name: task [54969,54973]
name: task [54968,54972]
===
match
---
sync_comp_for [78925,78937]
sync_comp_for [78877,78889]
===
match
---
simple_stmt [7947,7981]
simple_stmt [7947,7981]
===
match
---
name: yesterday_ds_nodash [62286,62305]
name: yesterday_ds_nodash [62238,62257]
===
match
---
funcdef [73124,74430]
funcdef [73076,74382]
===
match
---
trailer [44163,44215]
trailer [44163,44215]
===
match
---
atom_expr [24878,24888]
atom_expr [24878,24888]
===
match
---
name: dict [71559,71563]
name: dict [71511,71515]
===
match
---
atom_expr [24835,24850]
atom_expr [24835,24850]
===
match
---
operator: -> [80638,80640]
operator: -> [80590,80592]
===
match
---
dotted_name [82562,82583]
dotted_name [82514,82535]
===
match
---
name: stacklevel [28512,28522]
name: stacklevel [28512,28522]
===
match
---
if_stmt [52622,53386]
if_stmt [52621,53385]
===
match
---
expr_stmt [20239,20523]
expr_stmt [20239,20523]
===
match
---
trailer [68264,68269]
trailer [68216,68221]
===
match
---
atom_expr [6871,6884]
atom_expr [6871,6884]
===
match
---
tfpdef [26528,26544]
tfpdef [26528,26544]
===
match
---
simple_stmt [56341,56383]
simple_stmt [56340,56382]
===
match
---
operator: = [14866,14867]
operator: = [14866,14867]
===
match
---
trailer [60645,60652]
trailer [60597,60604]
===
match
---
return_stmt [64523,64596]
return_stmt [64475,64548]
===
match
---
name: ti [6065,6067]
name: ti [6065,6067]
===
match
---
name: get_task_instance [28020,28037]
name: get_task_instance [28020,28037]
===
match
---
atom_expr [61450,61469]
atom_expr [61402,61421]
===
match
---
not_test [54335,54342]
not_test [54334,54341]
===
match
---
atom_expr [20346,20357]
atom_expr [20346,20357]
===
match
---
atom_expr [11235,11246]
atom_expr [11235,11246]
===
match
---
operator: = [77874,77875]
operator: = [77826,77827]
===
match
---
sync_comp_for [79487,79500]
sync_comp_for [79439,79452]
===
match
---
trailer [60752,60754]
trailer [60704,60706]
===
match
---
name: self [58503,58507]
name: self [58502,58506]
===
match
---
expr_stmt [48335,48356]
expr_stmt [48335,48356]
===
match
---
tfpdef [53481,53494]
tfpdef [53480,53493]
===
match
---
atom_expr [52639,52651]
atom_expr [52638,52650]
===
match
---
trailer [35458,35464]
trailer [35458,35464]
===
match
---
atom_expr [23955,23966]
atom_expr [23955,23966]
===
match
---
arglist [28038,28067]
arglist [28038,28067]
===
match
---
operator: , [32831,32832]
operator: , [32831,32832]
===
match
---
atom_expr [41879,41892]
atom_expr [41879,41892]
===
match
---
name: str [8193,8196]
name: str [8193,8196]
===
match
---
operator: , [32725,32726]
operator: , [32725,32726]
===
match
---
name: incr [44995,44999]
name: incr [44995,44999]
===
match
---
operator: * [38003,38004]
operator: * [38003,38004]
===
match
---
name: List [1062,1066]
name: List [1062,1066]
===
match
---
name: dag_id [78793,78799]
name: dag_id [78745,78751]
===
match
---
string: ':' [62269,62272]
string: ':' [62221,62224]
===
match
---
suite [13180,13217]
suite [13180,13217]
===
match
---
name: task_id [48821,48828]
name: task_id [48821,48828]
===
match
---
operator: , [35770,35771]
operator: , [35770,35771]
===
match
---
name: execution_date [60460,60474]
name: execution_date [60412,60426]
===
match
---
tfpdef [16068,16091]
tfpdef [16068,16091]
===
match
---
string: "--ignore-dependencies" [18389,18412]
string: "--ignore-dependencies" [18389,18412]
===
match
---
name: log [1894,1897]
name: log [1894,1897]
===
match
---
name: ignore_all_deps [53511,53526]
name: ignore_all_deps [53510,53525]
===
match
---
argument [15257,15288]
argument [15257,15288]
===
match
---
simple_stmt [3389,3563]
simple_stmt [3389,3563]
===
match
---
trailer [54448,54462]
trailer [54447,54461]
===
match
---
name: models [1826,1832]
name: models [1826,1832]
===
match
---
operator: = [71134,71135]
operator: = [71086,71087]
===
match
---
return_stmt [30896,30952]
return_stmt [30896,30952]
===
match
---
name: try_number [13259,13269]
name: try_number [13259,13269]
===
match
---
suite [5428,5625]
suite [5428,5625]
===
match
---
tfpdef [4314,4342]
tfpdef [4314,4342]
===
match
---
name: logging [3285,3292]
name: logging [3285,3292]
===
match
---
name: execution_date [61455,61469]
name: execution_date [61407,61421]
===
match
---
operator: , [11820,11821]
operator: , [11820,11821]
===
match
---
simple_stmt [25340,25411]
simple_stmt [25340,25411]
===
match
---
name: self [13998,14002]
name: self [13998,14002]
===
match
---
name: make_aware [11906,11916]
name: make_aware [11906,11916]
===
match
---
operator: = [59700,59701]
operator: = [59652,59653]
===
match
---
arglist [79309,79460]
arglist [79261,79412]
===
match
---
arglist [49058,49083]
arglist [49058,49083]
===
match
---
comparison [82149,82186]
comparison [82101,82138]
===
match
---
atom_expr [24133,24168]
atom_expr [24133,24168]
===
match
---
dotted_name [2016,2039]
dotted_name [2016,2039]
===
match
---
arglist [10083,10117]
arglist [10083,10117]
===
match
---
name: dag [5398,5401]
name: dag [5398,5401]
===
match
---
import_as_names [1221,1259]
import_as_names [1221,1259]
===
match
---
name: pool [14350,14354]
name: pool [14350,14354]
===
match
---
tfpdef [15541,15552]
tfpdef [15541,15552]
===
match
---
atom_expr [59702,59732]
atom_expr [59654,59684]
===
match
---
operator: = [48296,48297]
operator: = [48296,48297]
===
match
---
simple_stmt [13991,14019]
simple_stmt [13991,14019]
===
match
---
trailer [71185,71197]
trailer [71137,71149]
===
match
---
funcdef [63202,63259]
funcdef [63154,63211]
===
match
---
name: render_templates [48975,48991]
name: render_templates [48975,48991]
===
match
---
simple_stmt [48618,48664]
simple_stmt [48618,48664]
===
match
---
name: bool [15709,15713]
name: bool [15709,15713]
===
match
---
decorated [55119,56080]
decorated [55118,56079]
===
match
---
name: self [33057,33061]
name: self [33057,33061]
===
match
---
simple_stmt [2905,2956]
simple_stmt [2905,2956]
===
match
---
name: session [76689,76696]
name: session [76641,76648]
===
match
---
name: str [3231,3234]
name: str [3231,3234]
===
match
---
operator: , [58514,58515]
operator: , [58513,58514]
===
match
---
name: bool [15755,15759]
name: bool [15755,15759]
===
match
---
string: "--job-id" [18228,18238]
string: "--job-id" [18228,18238]
===
match
---
decorator [29118,29135]
decorator [29118,29135]
===
match
---
name: instance [30350,30358]
name: instance [30350,30358]
===
match
---
name: error [56866,56871]
name: error [56865,56870]
===
match
---
name: Optional [68087,68095]
name: Optional [68039,68047]
===
match
---
argument [43578,43598]
argument [43578,43598]
===
match
---
trailer [82446,82452]
trailer [82398,82404]
===
match
---
atom_expr [21769,21788]
atom_expr [21769,21788]
===
match
---
simple_stmt [40354,40386]
simple_stmt [40354,40386]
===
match
---
suite [82291,82339]
suite [82243,82291]
===
match
---
operator: == [78675,78677]
operator: == [78627,78629]
===
match
---
name: utils [2456,2461]
name: utils [2456,2461]
===
match
---
name: max_tries [70961,70970]
name: max_tries [70913,70922]
===
match
---
atom_expr [10922,11099]
atom_expr [10922,11099]
===
match
---
name: self [8535,8539]
name: self [8535,8539]
===
match
---
param [55163,55168]
param [55162,55167]
===
match
---
operator: , [11669,11670]
operator: , [11669,11670]
===
match
---
name: info [47278,47282]
name: info [47278,47282]
===
match
---
trailer [58929,58935]
trailer [58919,58929]
===
match
---
atom_expr [10131,10150]
atom_expr [10131,10150]
===
match
---
trailer [12016,12031]
trailer [12016,12031]
===
match
---
atom_expr [77599,77611]
atom_expr [77551,77563]
===
match
---
argument [78969,79031]
argument [78921,78983]
===
match
---
trailer [51000,51007]
trailer [51038,51045]
===
match
---
name: execute [7295,7302]
name: execute [7295,7302]
===
match
---
name: pickle [4463,4469]
name: pickle [4463,4469]
===
match
---
name: self [55926,55930]
name: self [55925,55929]
===
match
---
decorated [80846,80926]
decorated [80798,80878]
===
match
---
operator: } [48828,48829]
operator: } [48828,48829]
===
match
---
name: self [40300,40304]
name: self [40300,40304]
===
match
---
trailer [10417,10451]
trailer [10417,10451]
===
match
---
trailer [22454,22463]
trailer [22454,22463]
===
match
---
simple_stmt [42666,42693]
simple_stmt [42666,42693]
===
match
---
string: "Refreshed TaskInstance %s" [22893,22920]
string: "Refreshed TaskInstance %s" [22893,22920]
===
match
---
operator: = [79873,79874]
operator: = [79825,79826]
===
match
---
trailer [43317,43320]
trailer [43317,43320]
===
match
---
name: settings [69051,69059]
name: settings [69003,69011]
===
match
---
name: self [43651,43655]
name: self [43651,43655]
===
match
---
operator: , [35895,35896]
operator: , [35895,35896]
===
match
---
name: dag_model [10910,10919]
name: dag_model [10910,10919]
===
match
---
name: hashlib [33837,33844]
name: hashlib [33837,33844]
===
match
---
operator: , [30850,30851]
operator: , [30850,30851]
===
match
---
string: "--pickle" [18156,18166]
string: "--pickle" [18156,18166]
===
match
---
name: refresh_from_db [43562,43577]
name: refresh_from_db [43562,43577]
===
match
---
trailer [60208,60212]
trailer [60160,60164]
===
match
---
simple_stmt [38709,38722]
simple_stmt [38709,38722]
===
match
---
operator: = [55774,55775]
operator: = [55773,55774]
===
match
---
name: rendered_value [66636,66650]
name: rendered_value [66588,66602]
===
match
---
suite [24463,25108]
suite [24463,25108]
===
match
---
name: task_id [11260,11267]
name: task_id [11260,11267]
===
match
---
argument [70946,70970]
argument [70898,70922]
===
match
---
name: self [31833,31837]
name: self [31833,31837]
===
match
---
name: pod_id [68545,68551]
name: pod_id [68497,68503]
===
match
---
name: state [24775,24780]
name: state [24775,24780]
===
match
---
comparison [79411,79459]
comparison [79363,79411]
===
match
---
name: iso [19151,19154]
name: iso [19151,19154]
===
match
---
simple_stmt [42641,42658]
simple_stmt [42641,42658]
===
match
---
trailer [81538,81555]
trailer [81490,81507]
===
match
---
simple_stmt [69484,69538]
simple_stmt [69436,69490]
===
match
---
name: params [62481,62487]
name: params [62433,62439]
===
match
---
name: execution_date [11480,11494]
name: execution_date [11480,11494]
===
match
---
operator: = [47262,47263]
operator: = [47262,47263]
===
match
---
trailer [46260,46275]
trailer [46260,46275]
===
match
---
argument [51902,51914]
argument [51940,51952]
===
match
---
name: session [41909,41916]
name: session [41909,41916]
===
match
---
operator: = [37705,37706]
operator: = [37705,37706]
===
match
---
name: try_number [6958,6968]
name: try_number [6958,6968]
===
match
---
atom_expr [43557,43599]
atom_expr [43557,43599]
===
match
---
name: self [67212,67216]
name: self [67164,67168]
===
match
---
expr_stmt [9793,9819]
expr_stmt [9793,9819]
===
match
---
fstring_expr [19135,19149]
fstring_expr [19135,19149]
===
match
---
argument [68849,68881]
argument [68801,68833]
===
match
---
operator: = [22490,22491]
operator: = [22490,22491]
===
match
---
simple_stmt [37693,37714]
simple_stmt [37693,37714]
===
match
---
name: incr [50714,50718]
name: incr [50752,50756]
===
match
---
name: self [44885,44889]
name: self [44885,44889]
===
match
---
operator: = [12153,12154]
operator: = [12153,12154]
===
match
---
return_stmt [13991,14018]
return_stmt [13991,14018]
===
match
---
name: self [38531,38535]
name: self [38531,38535]
===
match
---
suite [81287,81325]
suite [81239,81277]
===
match
---
operator: , [35521,35522]
operator: , [35521,35522]
===
match
---
simple_stmt [73999,74194]
simple_stmt [73951,74146]
===
match
---
trailer [5161,5166]
trailer [5161,5166]
===
match
---
name: dag [27374,27377]
name: dag [27374,27377]
===
match
---
trailer [7266,7278]
trailer [7266,7278]
===
match
---
name: dag_id [35515,35521]
name: dag_id [35515,35521]
===
match
---
suite [8397,8599]
suite [8397,8599]
===
match
---
name: self [80820,80824]
name: self [80772,80776]
===
match
---
fstring_string: . [45040,45041]
fstring_string: . [45040,45041]
===
match
---
name: task [59992,59996]
name: task [59944,59948]
===
match
---
operator: = [45926,45927]
operator: = [45926,45927]
===
match
---
name: dag_id [78678,78684]
name: dag_id [78630,78636]
===
match
---
trailer [68039,68044]
trailer [67991,67996]
===
match
---
operator: = [62416,62417]
operator: = [62368,62369]
===
match
---
param [14265,14277]
param [14265,14277]
===
match
---
simple_stmt [12717,12974]
simple_stmt [12717,12974]
===
match
---
trailer [72671,72677]
trailer [72623,72629]
===
match
---
atom_expr [55389,55408]
atom_expr [55388,55407]
===
match
---
arglist [41244,41306]
arglist [41244,41306]
===
match
---
simple_stmt [9633,9688]
simple_stmt [9633,9688]
===
match
---
suite [26867,28069]
suite [26867,28069]
===
match
---
atom_expr [78367,78379]
atom_expr [78319,78331]
===
match
---
suite [18530,18567]
suite [18530,18567]
===
match
---
name: session [21592,21599]
name: session [21592,21599]
===
match
---
atom_expr [7432,7455]
atom_expr [7432,7455]
===
match
---
parameters [81421,81427]
parameters [81373,81379]
===
match
---
argument [46197,46215]
argument [46197,46215]
===
match
---
trailer [19053,19093]
trailer [19053,19093]
===
match
---
name: self [63989,63993]
name: self [63941,63945]
===
match
---
name: log [40012,40015]
name: log [40012,40015]
===
match
---
decorated [74435,77390]
decorated [74387,77342]
===
match
---
simple_stmt [20867,20923]
simple_stmt [20867,20923]
===
match
---
param [15731,15768]
param [15731,15768]
===
match
---
atom_expr [67892,67904]
atom_expr [67844,67856]
===
match
---
operator: = [15868,15869]
operator: = [15868,15869]
===
match
---
name: session [40800,40807]
name: session [40800,40807]
===
match
---
operator: , [51181,51182]
operator: , [51219,51220]
===
match
---
argument [9592,9608]
argument [9592,9608]
===
match
---
operator: { [19150,19151]
operator: { [19150,19151]
===
match
---
atom_expr [18543,18566]
atom_expr [18543,18566]
===
match
---
atom_expr [6051,6068]
atom_expr [6051,6068]
===
match
---
name: _update_ti_state_for_sensing [50765,50793]
name: _update_ti_state_for_sensing [50803,50831]
===
match
---
funcdef [24417,25108]
funcdef [24417,25108]
===
match
---
operator: , [55554,55555]
operator: , [55553,55554]
===
match
---
simple_stmt [62346,62396]
simple_stmt [62298,62348]
===
match
---
atom_expr [26140,26151]
atom_expr [26140,26151]
===
match
---
simple_stmt [49170,49250]
simple_stmt [49170,49250]
===
match
---
name: __init__ [62969,62977]
name: __init__ [62921,62929]
===
match
---
tfpdef [15692,15713]
tfpdef [15692,15713]
===
match
---
trailer [5455,5464]
trailer [5455,5464]
===
match
---
expr_stmt [9824,9878]
expr_stmt [9824,9878]
===
match
---
simple_stmt [55985,56002]
simple_stmt [55984,56001]
===
match
---
trailer [73055,73097]
trailer [73007,73049]
===
match
---
operator: = [26373,26374]
operator: = [26373,26374]
===
match
---
simple_stmt [13318,13343]
simple_stmt [13318,13343]
===
match
---
name: deserialize_value [77366,77383]
name: deserialize_value [77318,77335]
===
match
---
expr_stmt [49805,49823]
expr_stmt [49805,49823]
===
match
---
trailer [14732,14741]
trailer [14732,14741]
===
match
---
decorator [8344,8354]
decorator [8344,8354]
===
match
---
trailer [23922,23928]
trailer [23922,23928]
===
match
---
name: params [60260,60266]
name: params [60212,60218]
===
match
---
suite [18637,18679]
suite [18637,18679]
===
match
---
name: and_ [6866,6870]
name: and_ [6866,6870]
===
match
---
operator: -> [52429,52431]
operator: -> [52428,52430]
===
match
---
atom_expr [58967,58977]
atom_expr [58961,58971]
===
match
---
name: query [20266,20271]
name: query [20266,20271]
===
match
---
simple_stmt [78388,78426]
simple_stmt [78340,78378]
===
match
---
simple_stmt [48206,48277]
simple_stmt [48206,48277]
===
match
---
name: first_task_id [79005,79018]
name: first_task_id [78957,78970]
===
match
---
trailer [28019,28037]
trailer [28019,28037]
===
match
---
suite [25481,26438]
suite [25481,26438]
===
match
---
argument [27926,27941]
argument [27926,27941]
===
match
---
simple_stmt [50638,50700]
simple_stmt [50676,50738]
===
match
---
atom_expr [47302,47312]
atom_expr [47302,47312]
===
match
---
name: next_execution_date [61483,61502]
name: next_execution_date [61435,61454]
===
match
---
arglist [56854,56871]
arglist [56853,56870]
===
match
---
name: task_instance_scheduling_decisions [46975,47009]
name: task_instance_scheduling_decisions [46975,47009]
===
match
---
name: str [80714,80717]
name: str [80666,80669]
===
match
---
not_test [26992,26998]
not_test [26992,26998]
===
match
---
name: jinja2 [71072,71078]
name: jinja2 [71024,71030]
===
match
---
name: state [43221,43226]
name: state [43221,43226]
===
match
---
name: ignore_task_deps [54083,54099]
name: ignore_task_deps [54082,54098]
===
match
---
operator: = [15369,15370]
operator: = [15369,15370]
===
match
---
operator: , [56252,56253]
operator: , [56251,56252]
===
match
---
operator: , [41530,41531]
operator: , [41530,41531]
===
match
---
name: dates [7175,7180]
name: dates [7175,7180]
===
match
---
dotted_name [2820,2839]
dotted_name [2820,2839]
===
match
---
simple_stmt [26880,26918]
simple_stmt [26880,26918]
===
match
---
name: cmd [18763,18766]
name: cmd [18763,18766]
===
match
---
number: 2 [33742,33743]
number: 2 [33742,33743]
===
match
---
name: hashlib [812,819]
name: hashlib [812,819]
===
match
---
name: prev_ds_nodash [61991,62005]
name: prev_ds_nodash [61943,61957]
===
match
---
number: 0 [4058,4059]
number: 0 [4058,4059]
===
match
---
operator: = [41743,41744]
operator: = [41743,41744]
===
match
---
name: ti [20239,20241]
name: ti [20239,20241]
===
match
---
return_stmt [81376,81394]
return_stmt [81328,81346]
===
match
---
name: Column [10131,10137]
name: Column [10131,10137]
===
match
---
trailer [80327,80333]
trailer [80279,80285]
===
match
---
operator: , [31008,31009]
operator: , [31008,31009]
===
match
---
name: dep_name [32131,32139]
name: dep_name [32131,32139]
===
match
---
if_stmt [26989,27352]
if_stmt [26989,27352]
===
match
---
name: dep_status [32773,32783]
name: dep_status [32773,32783]
===
match
---
name: UP_FOR_RETRY [24930,24942]
name: UP_FOR_RETRY [24930,24942]
===
match
---
operator: = [71810,71811]
operator: = [71762,71763]
===
match
---
name: dag_run [62665,62672]
name: dag_run [62617,62624]
===
match
---
trailer [11259,11267]
trailer [11259,11267]
===
match
---
simple_stmt [79854,79886]
simple_stmt [79806,79838]
===
match
---
simple_stmt [81207,81225]
simple_stmt [81159,81177]
===
match
---
param [73147,73152]
param [73099,73104]
===
match
---
name: task [68265,68269]
name: task [68217,68221]
===
match
---
operator: == [26137,26139]
operator: == [26137,26139]
===
match
---
name: email_for_state [58745,58760]
name: email_for_state [58744,58759]
===
match
---
trailer [45454,45466]
trailer [45454,45466]
===
match
---
name: ignore_ti_state [54146,54161]
name: ignore_ti_state [54145,54160]
===
match
---
suite [16119,18888]
suite [16119,18888]
===
match
---
arglist [49293,49415]
arglist [49293,49415]
===
match
---
atom_expr [67380,67429]
atom_expr [67332,67381]
===
match
---
atom_expr [9933,9945]
atom_expr [9933,9945]
===
match
---
simple_stmt [69051,69083]
simple_stmt [69003,69035]
===
match
---
decorator [24396,24413]
decorator [24396,24413]
===
match
---
operator: , [31926,31927]
operator: , [31926,31927]
===
match
---
operator: , [77869,77870]
operator: , [77821,77822]
===
match
---
name: timezone [11836,11844]
name: timezone [11836,11844]
===
match
---
string: "Dependencies not met for %s, dependency '%s' FAILED: %s" [32023,32080]
string: "Dependencies not met for %s, dependency '%s' FAILED: %s" [32023,32080]
===
match
---
trailer [57189,57193]
trailer [57188,57192]
===
match
---
trailer [5418,5427]
trailer [5418,5427]
===
match
---
name: result [51518,51524]
name: result [51556,51562]
===
match
---
trailer [79214,79222]
trailer [79166,79174]
===
match
---
name: Exception [44837,44846]
name: Exception [44837,44846]
===
match
---
simple_stmt [45093,45127]
simple_stmt [45093,45127]
===
match
---
simple_stmt [43161,43204]
simple_stmt [43161,43204]
===
match
---
name: info [43537,43541]
name: info [43537,43541]
===
match
---
name: self [59873,59877]
name: self [59825,59829]
===
match
---
operator: - [8593,8594]
operator: - [8593,8594]
===
match
---
name: datetime [8118,8126]
name: datetime [8118,8126]
===
match
---
param [63904,63908]
param [63856,63860]
===
match
---
argument [10092,10101]
argument [10092,10101]
===
match
---
trailer [67521,67541]
trailer [67473,67493]
===
match
---
name: error [56148,56153]
name: error [56147,56152]
===
match
---
name: self [24339,24343]
name: self [24339,24343]
===
match
---
operator: = [54099,54100]
operator: = [54098,54099]
===
match
---
name: key [73161,73164]
name: key [73113,73116]
===
match
---
name: task_id [76991,76998]
name: task_id [76943,76950]
===
match
---
name: value [77302,77307]
name: value [77254,77259]
===
match
---
name: datetime [80020,80028]
name: datetime [79972,79980]
===
match
---
name: tis [7825,7828]
name: tis [7825,7828]
===
match
---
operator: = [22735,22736]
operator: = [22735,22736]
===
match
---
return_stmt [81527,81555]
return_stmt [81479,81507]
===
match
---
expr_stmt [22308,22340]
expr_stmt [22308,22340]
===
match
---
string: "Exporting the following env vars:\n%s" [49293,49332]
string: "Exporting the following env vars:\n%s" [49293,49332]
===
match
---
funcdef [77997,79511]
funcdef [77949,79463]
===
match
---
operator: = [64590,64591]
operator: = [64542,64543]
===
match
---
atom_expr [51377,51404]
atom_expr [51415,51442]
===
match
---
comparison [54736,54763]
comparison [54735,54762]
===
match
---
fstring [19735,19759]
fstring [19735,19759]
===
match
---
name: task [11303,11307]
name: task [11303,11307]
===
match
---
name: cmd [18079,18082]
name: cmd [18079,18082]
===
match
---
operator: } [45024,45025]
operator: } [45024,45025]
===
match
---
atom_expr [9505,9537]
atom_expr [9505,9537]
===
match
---
name: self [25102,25106]
name: self [25102,25106]
===
match
---
funcdef [35645,41430]
funcdef [35645,41430]
===
match
---
name: property [24175,24183]
name: property [24175,24183]
===
match
---
funcdef [81026,81087]
funcdef [80978,81039]
===
match
---
simple_stmt [2011,2056]
simple_stmt [2011,2056]
===
match
---
trailer [60174,60187]
trailer [60126,60139]
===
match
---
and_test [67880,67904]
and_test [67832,67856]
===
match
---
name: context [52751,52758]
name: context [52750,52757]
===
match
---
trailer [52765,52786]
trailer [52764,52785]
===
match
---
name: task_ids [76606,76614]
name: task_ids [76558,76566]
===
match
---
name: session [73250,73257]
name: session [73202,73209]
===
match
---
name: error [4314,4319]
name: error [4314,4319]
===
match
---
operator: + [37996,37997]
operator: + [37996,37997]
===
match
---
name: task [22961,22965]
name: task [22961,22965]
===
match
---
operator: , [65172,65173]
operator: , [65124,65125]
===
match
---
name: task [23608,23612]
name: task [23608,23612]
===
match
---
name: task [64660,64664]
name: task [64612,64616]
===
match
---
simple_stmt [40739,40761]
simple_stmt [40739,40761]
===
match
---
name: previous_start_date_success [30402,30429]
name: previous_start_date_success [30402,30429]
===
match
---
if_stmt [27727,27956]
if_stmt [27727,27956]
===
match
---
trailer [68583,68591]
trailer [68535,68543]
===
match
---
expr_stmt [58317,58354]
expr_stmt [58316,58353]
===
match
---
operator: = [37575,37576]
operator: = [37575,37576]
===
match
---
name: session [31928,31935]
name: session [31928,31935]
===
match
---
name: dag_id [48802,48808]
name: dag_id [48802,48808]
===
match
---
trailer [70909,70920]
trailer [70861,70872]
===
match
---
arith_expr [33724,33743]
arith_expr [33724,33743]
===
match
---
number: 2 [29043,29044]
number: 2 [29043,29044]
===
match
---
name: executor_config [80165,80180]
name: executor_config [80117,80132]
===
match
---
trailer [82336,82338]
trailer [82288,82290]
===
match
---
name: state [58220,58225]
name: state [58219,58224]
===
match
---
trailer [7109,7115]
trailer [7109,7115]
===
match
---
trailer [20871,20875]
trailer [20871,20875]
===
match
---
operator: , [65787,65788]
operator: , [65739,65740]
===
match
---
trailer [58971,58977]
trailer [58965,58971]
===
match
---
atom_expr [60638,60654]
atom_expr [60590,60606]
===
match
---
name: max_tries [22414,22423]
name: max_tries [22414,22423]
===
match
---
name: get_templated_fields [66435,66455]
name: get_templated_fields [66387,66407]
===
match
---
trailer [49445,49453]
trailer [49445,49453]
===
match
---
operator: , [64925,64926]
operator: , [64877,64878]
===
match
---
if_stmt [18807,18869]
if_stmt [18807,18869]
===
match
---
trailer [42908,42910]
trailer [42908,42910]
===
match
---
operator: -> [72823,72825]
operator: -> [72775,72777]
===
match
---
operator: = [22862,22863]
operator: = [22862,22863]
===
match
---
name: self [68486,68490]
name: self [68438,68442]
===
match
---
operator: , [68076,68077]
operator: , [68028,68029]
===
match
---
trailer [48073,48082]
trailer [48073,48082]
===
match
---
trailer [45871,45932]
trailer [45871,45932]
===
match
---
strings [45162,45272]
strings [45162,45272]
===
match
---
suite [20538,20571]
suite [20538,20571]
===
match
---
atom_expr [68617,68632]
atom_expr [68569,68584]
===
match
---
name: rendered_task_instance_fields [66376,66405]
name: rendered_task_instance_fields [66328,66357]
===
match
---
name: Optional [80208,80216]
name: Optional [80160,80168]
===
match
---
atom_expr [61241,61265]
atom_expr [61193,61217]
===
match
---
atom_expr [77726,77738]
atom_expr [77678,77690]
===
match
---
simple_stmt [39967,39991]
simple_stmt [39967,39991]
===
match
---
atom_expr [11194,11212]
atom_expr [11194,11212]
===
match
---
atom_expr [20559,20570]
atom_expr [20559,20570]
===
match
---
name: Optional [41801,41809]
name: Optional [41801,41809]
===
match
---
simple_stmt [29587,29648]
simple_stmt [29587,29648]
===
match
---
trailer [49887,49914]
trailer [49887,49914]
===
match
---
name: TaskInstance [20272,20284]
name: TaskInstance [20272,20284]
===
match
---
operator: , [18166,18167]
operator: , [18166,18167]
===
match
---
operator: = [62165,62166]
operator: = [62117,62118]
===
match
---
string: """         The execution date from property previous_ti_success.          :param state: If passed, it only take into account instances of a specific state.         :param session: SQLAlchemy ORM Session         """ [29302,29517]
string: """         The execution date from property previous_ti_success.          :param state: If passed, it only take into account instances of a specific state.         :param session: SQLAlchemy ORM Session         """ [29302,29517]
===
match
---
operator: , [74595,74596]
operator: , [74547,74548]
===
match
---
atom_expr [10418,10450]
atom_expr [10418,10450]
===
match
---
name: pool [81180,81184]
name: pool [81132,81136]
===
match
---
name: FAILED [57127,57133]
name: FAILED [57126,57132]
===
match
---
name: dep_context [39894,39905]
name: dep_context [39894,39905]
===
match
---
decorated [3315,3925]
decorated [3315,3925]
===
match
---
atom_expr [60801,60813]
atom_expr [60753,60765]
===
match
---
trailer [27837,27854]
trailer [27837,27854]
===
match
---
import_from [2853,2894]
import_from [2853,2894]
===
match
---
string: """         The start date from property previous_ti_success.          :param state: If passed, it only take into account instances of a specific state.         :param session: SQLAlchemy ORM Session         """ [29885,30096]
string: """         The start date from property previous_ti_success.          :param state: If passed, it only take into account instances of a specific state.         :param session: SQLAlchemy ORM Session         """ [29885,30096]
===
match
---
name: self [72891,72895]
name: self [72843,72847]
===
match
---
string: 'html_content_template' [72329,72352]
string: 'html_content_template' [72281,72304]
===
match
---
operator: , [35809,35810]
operator: , [35809,35810]
===
match
---
name: log [56015,56018]
name: log [56014,56017]
===
match
---
name: task [23340,23344]
name: task [23340,23344]
===
match
---
name: property [80847,80855]
name: property [80799,80807]
===
match
---
name: strftime [41587,41595]
name: strftime [41587,41595]
===
match
---
trailer [8521,8598]
trailer [8521,8598]
===
match
---
operator: = [76576,76577]
operator: = [76528,76529]
===
match
---
simple_stmt [31780,31848]
simple_stmt [31780,31848]
===
match
---
name: self [33917,33921]
name: self [33917,33921]
===
match
---
suite [18203,18254]
suite [18203,18254]
===
match
---
atom_expr [24037,24056]
atom_expr [24037,24056]
===
match
---
trailer [10367,10381]
trailer [10367,10381]
===
match
---
name: exceptions [1628,1638]
name: exceptions [1628,1638]
===
match
---
name: dag_id [74305,74311]
name: dag_id [74257,74263]
===
match
---
operator: , [1078,1079]
operator: , [1078,1079]
===
match
---
name: info [45144,45148]
name: info [45144,45148]
===
match
---
number: 1 [40317,40318]
number: 1 [40317,40318]
===
match
---
atom_expr [68814,68834]
atom_expr [68766,68786]
===
match
---
operator: , [64828,64829]
operator: , [64780,64781]
===
match
---
suite [80443,80499]
suite [80395,80451]
===
match
---
name: error [54870,54875]
name: error [54869,54874]
===
match
---
number: 0 [9876,9877]
number: 0 [9876,9877]
===
match
---
name: job_id [53744,53750]
name: job_id [53743,53749]
===
match
---
name: task_copy [48792,48801]
name: task_copy [48792,48801]
===
match
---
atom_expr [5947,5959]
atom_expr [5947,5959]
===
match
---
name: Any [73186,73189]
name: Any [73138,73141]
===
match
---
name: self [43873,43877]
name: self [43873,43877]
===
match
---
operator: , [48139,48140]
operator: , [48139,48140]
===
match
---
operator: = [81645,81646]
operator: = [81597,81598]
===
match
---
trailer [44889,44904]
trailer [44889,44904]
===
match
---
trailer [60479,60494]
trailer [60431,60446]
===
match
---
operator: = [9960,9961]
operator: = [9960,9961]
===
match
---
operator: , [72563,72564]
operator: , [72515,72516]
===
match
---
name: prev_execution_date [61938,61957]
name: prev_execution_date [61890,61909]
===
match
---
trailer [62514,62527]
trailer [62466,62479]
===
match
---
return_stmt [38709,38721]
return_stmt [38709,38721]
===
match
---
name: on_retry_callback [53359,53376]
name: on_retry_callback [53358,53375]
===
match
---
suite [4352,4709]
suite [4352,4709]
===
match
---
trailer [67926,67932]
trailer [67878,67884]
===
match
---
operator: , [14300,14301]
operator: , [14300,14301]
===
match
---
trailer [45148,45477]
trailer [45148,45477]
===
match
---
operator: { [49363,49364]
operator: { [49363,49364]
===
match
---
expr_stmt [19535,19579]
expr_stmt [19535,19579]
===
match
---
name: self [18985,18989]
name: self [18985,18989]
===
match
---
name: debug [30114,30119]
name: debug [30114,30119]
===
match
---
atom_expr [28626,28650]
atom_expr [28626,28650]
===
match
---
name: max_tries [40679,40688]
name: max_tries [40679,40688]
===
match
---
operator: - [71704,71705]
operator: - [71656,71657]
===
match
---
name: params [68018,68024]
name: params [67970,67976]
===
match
---
argument [64549,64572]
argument [64501,64524]
===
match
---
operator: , [58464,58465]
operator: , [58463,58464]
===
match
---
if_stmt [18629,18679]
if_stmt [18629,18679]
===
match
---
trailer [56966,56968]
trailer [56965,56967]
===
match
---
atom_expr [9838,9878]
atom_expr [9838,9878]
===
match
---
atom_expr [45676,45724]
atom_expr [45676,45724]
===
match
---
operator: = [11177,11178]
operator: = [11177,11178]
===
match
---
name: airflow [1818,1825]
name: airflow [1818,1825]
===
match
---
operator: = [23321,23322]
operator: = [23321,23322]
===
match
---
name: self [45337,45341]
name: self [45337,45341]
===
match
---
atom_expr [71096,71121]
atom_expr [71048,71073]
===
match
---
operator: -> [81191,81193]
operator: -> [81143,81145]
===
match
---
simple_stmt [44954,44960]
simple_stmt [44954,44960]
===
match
---
name: conf [71899,71903]
name: conf [71851,71855]
===
match
---
suite [51497,51562]
suite [51535,51600]
===
match
---
operator: , [49414,49415]
operator: , [49414,49415]
===
match
---
atom_expr [45135,45477]
atom_expr [45135,45477]
===
match
---
name: qry [82370,82373]
name: qry [82322,82325]
===
match
---
trailer [6873,6884]
trailer [6873,6884]
===
match
---
name: pickle_id [14286,14295]
name: pickle_id [14286,14295]
===
match
---
fstring_string: . [48809,48810]
fstring_string: . [48809,48810]
===
match
---
trailer [59612,59623]
trailer [59564,59575]
===
match
---
operator: , [65094,65095]
operator: , [65046,65047]
===
match
---
arglist [24734,24780]
arglist [24734,24780]
===
match
---
expr_stmt [78328,78348]
expr_stmt [78280,78300]
===
match
---
name: airflow [2061,2068]
name: airflow [2061,2068]
===
match
---
param [41760,41784]
param [41760,41784]
===
match
---
name: queued_dttm [10229,10240]
name: queued_dttm [10229,10240]
===
match
---
fstring_start: f' [48785,48787]
fstring_start: f' [48785,48787]
===
match
---
operator: , [39917,39918]
operator: , [39917,39918]
===
match
---
suite [20584,20610]
suite [20584,20610]
===
match
---
name: test_mode [56186,56195]
name: test_mode [56185,56194]
===
match
---
atom_expr [29848,29875]
atom_expr [29848,29875]
===
match
---
name: log [58926,58929]
name: log [58916,58919]
===
match
---
subscriptlist [78036,78067]
subscriptlist [77988,78019]
===
match
---
name: DagRun [45980,45986]
name: DagRun [45980,45986]
===
match
---
name: result [50473,50479]
name: result [50511,50517]
===
match
---
simple_stmt [1350,1394]
simple_stmt [1350,1394]
===
match
---
operator: == [26405,26407]
operator: == [26405,26407]
===
match
---
name: duration [22085,22093]
name: duration [22085,22093]
===
match
---
expr_stmt [10063,10118]
expr_stmt [10063,10118]
===
match
---
name: self [23540,23544]
name: self [23540,23544]
===
match
---
simple_stmt [32953,32970]
simple_stmt [32953,32970]
===
match
---
funcdef [63956,64138]
funcdef [63908,64090]
===
match
---
simple_stmt [22878,22928]
simple_stmt [22878,22928]
===
match
---
name: dag [46672,46675]
name: dag [46672,46675]
===
match
---
name: property [81331,81339]
name: property [81283,81291]
===
match
---
name: bool [53614,53618]
name: bool [53613,53617]
===
match
---
suite [68355,69180]
suite [68307,69132]
===
match
---
name: t [78915,78916]
name: t [78867,78868]
===
match
---
suite [73289,74430]
suite [73241,74382]
===
match
---
name: self [14983,14987]
name: self [14983,14987]
===
match
---
trailer [23934,23941]
trailer [23934,23941]
===
match
---
operator: , [73189,73190]
operator: , [73141,73142]
===
match
---
operator: { [47057,47058]
operator: { [47057,47058]
===
match
---
operator: = [50189,50190]
operator: = [50205,50206]
===
match
---
string: "previous_start_date was called" [30120,30152]
string: "previous_start_date was called" [30120,30152]
===
match
---
simple_stmt [20597,20610]
simple_stmt [20597,20610]
===
match
---
name: test_mode [42683,42692]
name: test_mode [42683,42692]
===
match
---
param [15541,15553]
param [15541,15553]
===
match
---
atom_expr [13882,13898]
atom_expr [13882,13898]
===
match
---
simple_stmt [66376,66462]
simple_stmt [66328,66414]
===
match
---
name: self [68617,68621]
name: self [68569,68573]
===
match
---
trailer [47505,47510]
trailer [47505,47510]
===
match
---
atom_expr [74573,74586]
atom_expr [74525,74538]
===
match
---
suite [50814,51145]
suite [50852,51183]
===
match
---
suite [26999,27352]
suite [26999,27352]
===
match
---
name: cmd [17986,17989]
name: cmd [17986,17989]
===
match
---
name: self [55572,55576]
name: self [55571,55575]
===
match
---
name: ti [80248,80250]
name: ti [80200,80202]
===
match
---
arglist [49652,49665]
arglist [49652,49665]
===
match
---
name: TaskInstanceKey [8751,8766]
name: TaskInstanceKey [8751,8766]
===
match
---
simple_stmt [5577,5625]
simple_stmt [5577,5625]
===
match
---
parameters [72456,72473]
parameters [72408,72425]
===
match
---
atom_expr [28288,28535]
atom_expr [28288,28535]
===
match
---
raise_stmt [66805,67180]
raise_stmt [66757,67132]
===
match
---
name: state [30193,30198]
name: state [30193,30198]
===
match
---
atom_expr [40657,40672]
atom_expr [40657,40672]
===
match
---
name: set_duration [56954,56966]
name: set_duration [56953,56965]
===
match
---
name: Union [56155,56160]
name: Union [56154,56159]
===
match
---
trailer [25018,25027]
trailer [25018,25027]
===
match
---
arglist [66613,66650]
arglist [66565,66602]
===
match
---
parameters [19482,19488]
parameters [19482,19488]
===
match
---
simple_stmt [53255,53293]
simple_stmt [53254,53292]
===
match
---
atom_expr [37533,37581]
atom_expr [37533,37581]
===
match
---
lambdef [5122,5167]
lambdef [5122,5167]
===
match
---
name: timedelta [968,977]
name: timedelta [968,977]
===
match
---
fstring [45000,45054]
fstring [45000,45054]
===
match
---
trailer [72614,72625]
trailer [72566,72577]
===
match
---
name: get_template_context [52766,52786]
name: get_template_context [52765,52785]
===
match
---
operator: , [25465,25466]
operator: , [25465,25466]
===
match
---
name: make_aware [11795,11805]
name: make_aware [11795,11805]
===
match
---
trailer [74581,74586]
trailer [74533,74538]
===
match
---
name: key [24192,24195]
name: key [24192,24195]
===
match
---
number: 0 [12076,12077]
number: 0 [12076,12077]
===
match
---
suite [72474,72795]
suite [72426,72747]
===
match
---
trailer [55111,55113]
trailer [55110,55112]
===
match
---
operator: , [59177,59178]
operator: , [59129,59130]
===
match
---
name: rendered_value [66532,66546]
name: rendered_value [66484,66498]
===
match
---
decorator [18893,18903]
decorator [18893,18903]
===
match
---
operator: } [60087,60088]
operator: } [60039,60040]
===
match
---
operator: = [54962,54963]
operator: = [54961,54962]
===
match
---
name: get_previous_execution_date [29143,29170]
name: get_previous_execution_date [29143,29170]
===
match
---
name: Stats [50638,50643]
name: Stats [50676,50681]
===
match
---
operator: , [56164,56165]
operator: , [56163,56164]
===
match
---
trailer [22725,22734]
trailer [22725,22734]
===
match
---
trailer [24914,24920]
trailer [24914,24920]
===
match
---
atom_expr [79053,79254]
atom_expr [79005,79206]
===
match
---
name: log [49267,49270]
name: log [49267,49270]
===
match
---
name: session [59423,59430]
name: session [59375,59382]
===
match
---
operator: , [50870,50871]
operator: , [50908,50909]
===
match
---
atom_expr [16002,16015]
atom_expr [16002,16015]
===
match
---
trailer [79877,79885]
trailer [79829,79837]
===
match
---
name: session [55451,55458]
name: session [55450,55457]
===
match
---
operator: , [74418,74419]
operator: , [74370,74371]
===
match
---
atom_expr [68260,68301]
atom_expr [68212,68253]
===
match
---
name: get_dep_statuses [32591,32607]
name: get_dep_statuses [32591,32607]
===
match
---
operator: , [51991,51992]
operator: , [52029,52030]
===
match
---
atom_expr [13232,13248]
atom_expr [13232,13248]
===
match
---
name: log_filepath [18911,18923]
name: log_filepath [18911,18923]
===
match
---
name: dag_id [7715,7721]
name: dag_id [7715,7721]
===
match
---
expr_stmt [24678,24710]
expr_stmt [24678,24710]
===
match
---
name: utcnow [40430,40436]
name: utcnow [40430,40436]
===
match
---
name: local [15302,15307]
name: local [15302,15307]
===
match
---
name: _try_number [80056,80067]
name: _try_number [80008,80019]
===
match
---
testlist_comp [18775,18796]
testlist_comp [18775,18796]
===
match
---
name: AirflowException [67632,67648]
name: AirflowException [67584,67600]
===
match
---
name: current_time [24678,24690]
name: current_time [24678,24690]
===
match
---
name: self [51866,51870]
name: self [51904,51908]
===
match
---
tfpdef [16032,16051]
tfpdef [16032,16051]
===
match
---
argument [15302,15313]
argument [15302,15313]
===
match
---
atom_expr [72088,72142]
atom_expr [72040,72094]
===
match
---
param [25461,25466]
param [25461,25466]
===
match
---
name: self [77950,77954]
name: self [77902,77906]
===
match
---
string: '-' [62387,62390]
string: '-' [62339,62342]
===
match
---
decorated [81478,81556]
decorated [81430,81508]
===
match
---
name: dag [26832,26835]
name: dag [26832,26835]
===
match
---
trailer [8766,8826]
trailer [8766,8826]
===
match
---
operator: == [79439,79441]
operator: == [79391,79393]
===
match
---
name: dr [26996,26998]
name: dr [26996,26998]
===
match
---
string: "Received SIGTERM. Terminating subprocesses." [48463,48508]
string: "Received SIGTERM. Terminating subprocesses." [48463,48508]
===
match
---
name: delay [34790,34795]
name: delay [34790,34795]
===
match
---
name: self [34802,34806]
name: self [34802,34806]
===
match
---
operator: = [19250,19251]
operator: = [19250,19251]
===
match
---
operator: = [13335,13336]
operator: = [13335,13336]
===
match
---
funcdef [74456,77390]
funcdef [74408,77342]
===
match
---
name: net [2566,2569]
name: net [2566,2569]
===
match
---
operator: = [9836,9837]
operator: = [9836,9837]
===
match
---
param [69215,69220]
param [69167,69172]
===
match
---
name: previous_schedule [61432,61449]
name: previous_schedule [61384,61401]
===
match
---
name: dag [46926,46929]
name: dag [46926,46929]
===
match
---
return_stmt [79263,79510]
return_stmt [79215,79462]
===
match
---
operator: , [46298,46299]
operator: , [46298,46299]
===
match
---
name: dag_run [67806,67813]
name: dag_run [67758,67765]
===
match
---
operator: = [11363,11364]
operator: = [11363,11364]
===
match
---
trailer [47629,47633]
trailer [47629,47633]
===
match
---
fstring_expr [19121,19134]
fstring_expr [19121,19134]
===
match
---
name: task [37508,37512]
name: task [37508,37512]
===
match
---
sliceop [82448,82451]
sliceop [82400,82403]
===
match
---
trailer [51870,51880]
trailer [51908,51918]
===
match
---
simple_stmt [9692,9725]
simple_stmt [9692,9725]
===
match
---
decorator [80846,80856]
decorator [80798,80808]
===
match
---
comparison [77702,77738]
comparison [77654,77690]
===
match
---
return_stmt [72081,72142]
return_stmt [72033,72094]
===
match
---
atom_expr [22516,22527]
atom_expr [22516,22527]
===
match
---
operator: = [39710,39711]
operator: = [39710,39711]
===
match
---
name: TR [39185,39187]
name: TR [39185,39187]
===
match
---
string: """Remake the key by subtracting 1 from try number to match in memory information""" [8406,8490]
string: """Remake the key by subtracting 1 from try number to match in memory information""" [8406,8490]
===
match
---
atom_expr [44105,44127]
atom_expr [44105,44127]
===
match
---
comparison [27664,27681]
comparison [27664,27681]
===
match
---
simple_stmt [9488,9557]
simple_stmt [9488,9557]
===
match
---
operator: == [78978,78980]
operator: == [78930,78932]
===
match
---
trailer [49076,49083]
trailer [49076,49083]
===
match
---
trailer [33342,33354]
trailer [33342,33354]
===
match
---
simple_stmt [54720,54795]
simple_stmt [54719,54794]
===
match
---
name: session [45822,45829]
name: session [45822,45829]
===
match
---
trailer [29282,29291]
trailer [29282,29291]
===
match
---
trailer [33337,33342]
trailer [33337,33342]
===
match
---
name: task [37556,37560]
name: task [37556,37560]
===
match
---
operator: { [33041,33042]
operator: { [33041,33042]
===
match
---
simple_stmt [44410,44416]
simple_stmt [44410,44416]
===
match
---
string: """URL to mark TI success""" [19498,19526]
string: """URL to mark TI success""" [19498,19526]
===
match
---
operator: , [5978,5979]
operator: , [5978,5979]
===
match
---
name: dag_id [78373,78379]
name: dag_id [78325,78331]
===
match
---
arglist [8522,8597]
arglist [8522,8597]
===
match
---
name: task_id [8310,8317]
name: task_id [8310,8317]
===
match
---
operator: , [18238,18239]
operator: , [18238,18239]
===
match
---
name: ignore_ti_state [38351,38366]
name: ignore_ti_state [38351,38366]
===
match
---
decorated [25113,25411]
decorated [25113,25411]
===
match
---
arglist [76500,76697]
arglist [76452,76649]
===
match
---
trailer [7776,7791]
trailer [7776,7791]
===
match
---
trailer [40304,40314]
trailer [40304,40314]
===
match
---
name: self [40614,40618]
name: self [40614,40618]
===
match
---
operator: = [19926,19927]
operator: = [19926,19927]
===
match
---
if_stmt [80237,80315]
if_stmt [80189,80267]
===
match
---
atom [49360,49413]
atom [49360,49413]
===
match
---
operator: , [69031,69032]
operator: , [68983,68984]
===
match
---
name: add [57190,57193]
name: add [57189,57192]
===
match
---
name: non_requeueable_dep_context [38586,38613]
name: non_requeueable_dep_context [38586,38613]
===
match
---
expr_stmt [40912,40932]
expr_stmt [40912,40932]
===
match
---
trailer [72666,72671]
trailer [72618,72623]
===
match
---
suite [24221,24391]
suite [24221,24391]
===
match
---
atom_expr [69107,69150]
atom_expr [69059,69102]
===
match
---
decorated [80679,80748]
decorated [80631,80700]
===
match
---
parameters [4296,4343]
parameters [4296,4343]
===
match
---
trailer [22312,22323]
trailer [22312,22323]
===
match
---
fstring_string: ?task_id= [19698,19707]
fstring_string: ?task_id= [19698,19707]
===
match
---
decorated [50740,51145]
decorated [50778,51183]
===
match
---
name: result [51834,51840]
name: result [51872,51878]
===
match
---
name: settings [1567,1575]
name: settings [1567,1575]
===
match
---
name: execution_date [12034,12048]
name: execution_date [12034,12048]
===
match
---
name: self [81383,81387]
name: self [81335,81339]
===
match
---
trailer [52144,52164]
trailer [52182,52202]
===
match
---
name: self [30105,30109]
name: self [30105,30109]
===
match
---
expr_stmt [39967,39990]
expr_stmt [39967,39990]
===
match
---
operator: = [71738,71739]
operator: = [71690,71691]
===
match
---
trailer [48631,48663]
trailer [48631,48663]
===
match
---
trailer [43541,43544]
trailer [43541,43544]
===
match
---
operator: , [38445,38446]
operator: , [38445,38446]
===
match
---
atom_expr [54769,54794]
atom_expr [54768,54793]
===
match
---
operator: -> [68113,68115]
operator: -> [68065,68067]
===
match
---
name: exception_html [69484,69498]
name: exception_html [69436,69450]
===
match
---
operator: = [27845,27846]
operator: = [27845,27846]
===
match
---
name: dill [10376,10380]
name: dill [10376,10380]
===
match
---
atom_expr [26063,26095]
atom_expr [26063,26095]
===
match
---
trailer [58171,58188]
trailer [58170,58187]
===
match
---
arith_expr [34177,34212]
arith_expr [34177,34212]
===
match
---
name: scheduler_job_id [68849,68865]
name: scheduler_job_id [68801,68817]
===
match
---
trailer [43312,43317]
trailer [43312,43317]
===
match
---
operator: , [1332,1333]
operator: , [1332,1333]
===
match
---
name: Variable [63420,63428]
name: Variable [63372,63380]
===
match
---
trailer [22520,22527]
trailer [22520,22527]
===
match
---
atom_expr [71480,71507]
atom_expr [71432,71459]
===
match
---
arglist [6680,7136]
arglist [6680,7136]
===
match
---
operator: { [50670,50671]
operator: { [50708,50709]
===
match
---
name: max_tries [23507,23516]
name: max_tries [23507,23516]
===
match
---
import_as_names [958,977]
import_as_names [958,977]
===
match
---
name: total_seconds [33699,33712]
name: total_seconds [33699,33712]
===
match
---
expr_stmt [58259,58304]
expr_stmt [58258,58303]
===
match
---
operator: , [72766,72767]
operator: , [72718,72719]
===
match
---
name: conf [67900,67904]
name: conf [67852,67856]
===
match
---
name: instance [62076,62084]
name: instance [62028,62036]
===
match
---
simple_stmt [72840,72862]
simple_stmt [72792,72814]
===
match
---
name: str [81125,81128]
name: str [81077,81080]
===
match
---
operator: , [45466,45467]
operator: , [45466,45467]
===
match
---
simple_stmt [56425,56452]
simple_stmt [56424,56451]
===
match
---
trailer [40821,40829]
trailer [40821,40829]
===
match
---
atom_expr [55062,55085]
atom_expr [55061,55084]
===
match
---
name: skippable_task_ids [47320,47338]
name: skippable_task_ids [47320,47338]
===
match
---
name: verbose [31042,31049]
name: verbose [31042,31049]
===
match
---
name: actual_start_date [55606,55623]
name: actual_start_date [55605,55622]
===
match
---
name: execution_date [15039,15053]
name: execution_date [15039,15053]
===
match
---
name: ti [22646,22648]
name: ti [22646,22648]
===
match
---
name: next_ds [61652,61659]
name: next_ds [61604,61611]
===
match
---
name: create_pod_id [68552,68565]
name: create_pod_id [68504,68517]
===
match
---
name: ti [22056,22058]
name: ti [22056,22058]
===
match
---
suite [8017,8827]
suite [8017,8827]
===
match
---
name: dag [64665,64668]
name: dag [64617,64620]
===
match
---
name: self [26885,26889]
name: self [26885,26889]
===
match
---
atom_expr [37693,37704]
atom_expr [37693,37704]
===
match
---
expr_stmt [27889,27955]
expr_stmt [27889,27955]
===
match
---
atom_expr [55347,55360]
atom_expr [55346,55359]
===
match
---
atom_expr [8319,8338]
atom_expr [8319,8338]
===
match
---
name: extend [18381,18387]
name: extend [18381,18387]
===
match
---
name: start_date [22017,22027]
name: start_date [22017,22027]
===
match
---
import_name [1147,1160]
import_name [1147,1160]
===
match
---
expr_stmt [56907,56940]
expr_stmt [56906,56939]
===
match
---
name: in_ [78911,78914]
name: in_ [78863,78866]
===
match
---
trailer [49354,49359]
trailer [49354,49359]
===
match
---
trailer [3302,3312]
trailer [3302,3312]
===
match
---
trailer [35581,35587]
trailer [35581,35587]
===
match
---
trailer [53376,53385]
trailer [53375,53384]
===
match
---
expr_stmt [7910,7934]
expr_stmt [7910,7934]
===
match
---
name: TR [6772,6774]
name: TR [6772,6774]
===
match
---
name: UndefinedError [1245,1259]
name: UndefinedError [1245,1259]
===
match
---
dotted_name [66301,66332]
dotted_name [66253,66284]
===
match
---
atom_expr [40007,40038]
atom_expr [40007,40038]
===
match
---
trailer [77632,77806]
trailer [77584,77758]
===
match
---
arglist [64077,64104]
arglist [64029,64056]
===
match
---
operator: = [10074,10075]
operator: = [10074,10075]
===
match
---
string: 'execution_date' [64772,64788]
string: 'execution_date' [64724,64740]
===
match
---
simple_stmt [40577,40606]
simple_stmt [40577,40606]
===
match
---
name: value [13337,13342]
name: value [13337,13342]
===
match
---
operator: = [9550,9551]
operator: = [9550,9551]
===
match
---
name: self [8305,8309]
name: self [8305,8309]
===
match
---
trailer [29865,29874]
trailer [29865,29874]
===
match
---
simple_stmt [47565,47609]
simple_stmt [47565,47609]
===
match
---
simple_stmt [23915,24100]
simple_stmt [23915,24100]
===
match
---
name: execution_date [20442,20456]
name: execution_date [20442,20456]
===
match
---
name: cmd [18650,18653]
name: cmd [18650,18653]
===
match
---
name: value [13302,13307]
name: value [13302,13307]
===
match
---
operator: , [65682,65683]
operator: , [65634,65635]
===
match
---
name: self [49058,49062]
name: self [49058,49062]
===
match
---
trailer [14711,14725]
trailer [14711,14725]
===
match
---
suite [51672,51729]
suite [51710,51767]
===
match
---
tfpdef [35905,35926]
tfpdef [35905,35926]
===
match
---
trailer [51880,51915]
trailer [51918,51953]
===
match
---
name: delay [33325,33330]
name: delay [33325,33330]
===
match
---
atom_expr [71176,71238]
atom_expr [71128,71190]
===
match
---
simple_stmt [46918,46944]
simple_stmt [46918,46944]
===
match
---
name: XCom [23955,23959]
name: XCom [23955,23959]
===
match
---
name: dag_id [7167,7173]
name: dag_id [7167,7173]
===
match
---
name: prev_ti [29693,29700]
name: prev_ti [29693,29700]
===
match
---
name: debug [67927,67932]
name: debug [67879,67884]
===
match
---
atom_expr [55985,56001]
atom_expr [55984,56000]
===
match
---
tfpdef [41867,41892]
tfpdef [41867,41892]
===
match
---
atom_expr [79442,79459]
atom_expr [79394,79411]
===
match
---
name: str [26515,26518]
name: str [26515,26518]
===
match
---
arglist [62252,62259]
arglist [62204,62211]
===
match
---
name: do_xcom_push [51817,51829]
name: do_xcom_push [51855,51867]
===
match
---
arglist [41486,41496]
arglist [41486,41496]
===
match
---
operator: , [43910,43911]
operator: , [43910,43911]
===
match
---
name: query [35459,35464]
name: query [35459,35464]
===
match
---
name: render [72322,72328]
name: render [72274,72280]
===
match
---
trailer [60863,60878]
trailer [60815,60830]
===
match
---
operator: , [55708,55709]
operator: , [55707,55708]
===
match
---
string: "Setting task state for %s to %s" [24734,24767]
string: "Setting task state for %s to %s" [24734,24767]
===
match
---
atom_expr [22040,22053]
atom_expr [22040,22053]
===
match
---
simple_stmt [82365,82382]
simple_stmt [82317,82334]
===
match
---
try_stmt [58789,59021]
try_stmt [58788,58973]
===
match
---
simple_stmt [22721,22749]
simple_stmt [22721,22749]
===
match
---
name: send_email [72651,72661]
name: send_email [72603,72613]
===
match
---
argument [64574,64595]
argument [64526,64547]
===
match
---
name: property [28096,28104]
name: property [28096,28104]
===
match
---
name: math [33683,33687]
name: math [33683,33687]
===
match
---
name: self [19483,19487]
name: self [19483,19487]
===
match
---
atom_expr [51452,51495]
atom_expr [51490,51533]
===
match
---
comparison [79309,79341]
comparison [79261,79293]
===
match
---
name: property [80680,80688]
name: property [80632,80640]
===
match
---
operator: = [66406,66407]
operator: = [66358,66359]
===
match
---
name: test_mode [37607,37616]
name: test_mode [37607,37616]
===
match
---
arglist [58570,58603]
arglist [58569,58602]
===
match
---
name: task [41281,41285]
name: task [41281,41285]
===
match
---
trailer [9807,9819]
trailer [9807,9819]
===
match
---
trailer [78792,78799]
trailer [78744,78751]
===
match
---
name: result [59744,59750]
name: result [59696,59702]
===
match
---
name: SUCCESS [30944,30951]
name: SUCCESS [30944,30951]
===
match
---
name: task_id [79372,79379]
name: task_id [79324,79331]
===
match
---
if_stmt [4099,4132]
if_stmt [4099,4132]
===
match
---
name: defaultdict [925,936]
name: defaultdict [925,936]
===
match
---
name: replace [62261,62268]
name: replace [62213,62220]
===
match
---
name: execution_date [79445,79459]
name: execution_date [79397,79411]
===
match
---
if_stmt [57863,58355]
if_stmt [57862,58354]
===
match
---
atom_expr [69001,69030]
atom_expr [68953,68982]
===
match
---
name: email_alert [72445,72456]
name: email_alert [72397,72408]
===
match
---
atom_expr [22667,22687]
atom_expr [22667,22687]
===
match
---
parameters [81353,81359]
parameters [81305,81311]
===
match
---
string: "Task Duration set to %s" [73056,73081]
string: "Task Duration set to %s" [73008,73033]
===
match
---
name: unixname [22481,22489]
name: unixname [22481,22489]
===
match
---
name: utils [2413,2418]
name: utils [2413,2418]
===
match
---
operator: , [46831,46832]
operator: , [46831,46832]
===
match
---
name: _pool [81219,81224]
name: _pool [81171,81176]
===
match
---
suite [14390,15488]
suite [14390,15488]
===
match
---
argument [71729,71753]
argument [71681,71705]
===
match
---
name: ignore_ti_state [15257,15272]
name: ignore_ti_state [15257,15272]
===
match
---
name: Optional [29265,29273]
name: Optional [29265,29273]
===
match
---
name: UP_FOR_RETRY [58234,58246]
name: UP_FOR_RETRY [58233,58245]
===
match
---
name: ti [7727,7729]
name: ti [7727,7729]
===
match
---
param [29786,29814]
param [29786,29814]
===
match
---
simple_stmt [30896,30953]
simple_stmt [30896,30953]
===
match
---
operator: , [47700,47701]
operator: , [47700,47701]
===
match
---
operator: @ [29118,29119]
operator: @ [29118,29119]
===
match
---
name: render [71215,71221]
name: render [71167,71173]
===
match
---
atom_expr [59586,59603]
atom_expr [59538,59555]
===
match
---
simple_stmt [53024,53062]
simple_stmt [53023,53061]
===
match
---
simple_stmt [12169,12188]
simple_stmt [12169,12188]
===
match
---
expr_stmt [33806,34091]
expr_stmt [33806,34091]
===
match
---
argument [11026,11045]
argument [11026,11045]
===
match
---
suite [71451,72380]
suite [71403,72332]
===
match
---
param [18924,18928]
param [18924,18928]
===
match
---
trailer [23283,23289]
trailer [23283,23289]
===
match
---
arglist [10877,10896]
arglist [10877,10896]
===
match
---
tfpdef [15817,15838]
tfpdef [15817,15838]
===
match
---
name: task [11270,11274]
name: task [11270,11274]
===
match
---
operator: = [61936,61937]
operator: = [61888,61889]
===
match
---
operator: , [26526,26527]
operator: , [26526,26527]
===
match
---
operator: = [58226,58227]
operator: = [58225,58226]
===
match
---
operator: = [58006,58007]
operator: = [58005,58006]
===
match
---
name: actual_start_date [42873,42890]
name: actual_start_date [42873,42890]
===
match
---
name: TaskInstance [26293,26305]
name: TaskInstance [26293,26305]
===
match
---
simple_stmt [32222,32235]
simple_stmt [32222,32235]
===
match
---
operator: , [9609,9610]
operator: , [9609,9610]
===
match
---
expr_stmt [8069,8080]
expr_stmt [8069,8080]
===
match
---
name: AirflowSmartSensorException [43258,43285]
name: AirflowSmartSensorException [43258,43285]
===
match
---
return_stmt [81138,81156]
return_stmt [81090,81108]
===
match
---
trailer [76448,76455]
trailer [76400,76407]
===
match
---
argument [9520,9536]
argument [9520,9536]
===
match
---
trailer [56014,56018]
trailer [56013,56017]
===
match
---
name: self [29780,29784]
name: self [29780,29784]
===
match
---
atom_expr [78689,78705]
atom_expr [78641,78657]
===
match
---
trailer [77714,77722]
trailer [77666,77674]
===
match
---
suite [6177,7315]
suite [6177,7315]
===
match
---
parameters [28124,28130]
parameters [28124,28130]
===
match
---
atom_expr [81534,81555]
atom_expr [81486,81507]
===
match
---
atom_expr [48618,48663]
atom_expr [48618,48663]
===
match
---
atom_expr [82370,82381]
atom_expr [82322,82333]
===
match
---
atom_expr [68223,68250]
atom_expr [68175,68202]
===
match
---
atom_expr [24339,24351]
atom_expr [24339,24351]
===
match
---
name: session [54660,54667]
name: session [54659,54666]
===
match
---
name: State [43229,43234]
name: State [43229,43234]
===
match
---
name: Index [10610,10615]
name: Index [10610,10615]
===
match
---
operator: } [47993,47994]
operator: } [47993,47994]
===
match
---
name: value [51902,51907]
name: value [51940,51945]
===
match
---
name: self [24769,24773]
name: self [24769,24773]
===
match
---
trailer [41393,41408]
trailer [41393,41408]
===
match
---
operator: -> [45836,45838]
operator: -> [45836,45838]
===
match
---
trailer [8771,8778]
trailer [8771,8778]
===
match
---
name: self [12524,12528]
name: self [12524,12528]
===
match
---
trailer [47510,47514]
trailer [47510,47514]
===
match
---
trailer [68565,68592]
trailer [68517,68544]
===
match
---
simple_stmt [67723,67748]
simple_stmt [67675,67700]
===
match
---
number: 1 [37892,37893]
number: 1 [37892,37893]
===
match
---
arglist [33917,33980]
arglist [33917,33980]
===
match
---
fstring_start: f' [42930,42932]
fstring_start: f' [42930,42932]
===
match
---
operator: = [78403,78404]
operator: = [78355,78356]
===
match
---
operator: , [41490,41491]
operator: , [41490,41491]
===
match
---
name: test_mode [53711,53720]
name: test_mode [53710,53719]
===
match
---
trailer [27139,27157]
trailer [27139,27157]
===
match
---
name: _run_finished_callback [52353,52375]
name: _run_finished_callback [52352,52374]
===
match
---
name: log [11559,11562]
name: log [11559,11562]
===
match
---
name: execution_timeout [51462,51479]
name: execution_timeout [51500,51517]
===
match
---
import_from [1449,1491]
import_from [1449,1491]
===
match
---
decorator [12673,12683]
decorator [12673,12683]
===
match
---
atom_expr [50899,50912]
atom_expr [50937,50950]
===
match
---
operator: { [42955,42956]
operator: { [42955,42956]
===
match
---
name: strftime [61958,61966]
name: strftime [61910,61918]
===
match
---
simple_stmt [23358,23392]
simple_stmt [23358,23392]
===
match
---
trailer [77592,77598]
trailer [77544,77550]
===
match
---
trailer [60823,60835]
trailer [60775,60787]
===
match
---
atom_expr [78030,78068]
atom_expr [77982,78020]
===
match
---
operator: = [79834,79835]
operator: = [79786,79787]
===
match
---
expr_stmt [68213,68250]
expr_stmt [68165,68202]
===
match
---
operator: = [53032,53033]
operator: = [53031,53032]
===
match
---
name: conf [19599,19603]
name: conf [19599,19603]
===
match
---
operator: = [40926,40927]
operator: = [40926,40927]
===
match
---
simple_stmt [52140,52174]
simple_stmt [52178,52212]
===
match
---
atom [18843,18867]
atom [18843,18867]
===
match
---
expr_stmt [9883,9910]
expr_stmt [9883,9910]
===
match
---
atom_expr [76515,76534]
atom_expr [76467,76486]
===
match
---
expr_stmt [50473,50520]
expr_stmt [50511,50558]
===
match
---
operator: ** [71222,71224]
operator: ** [71174,71176]
===
match
---
atom_expr [61791,61829]
atom_expr [61743,61781]
===
match
---
name: self [47625,47629]
name: self [47625,47629]
===
match
---
argument [27838,27853]
argument [27838,27853]
===
match
---
expr_stmt [80097,80124]
expr_stmt [80049,80076]
===
match
---
operator: { [7726,7727]
operator: { [7726,7727]
===
match
---
expr_stmt [10332,10382]
expr_stmt [10332,10382]
===
match
---
operator: , [74633,74634]
operator: , [74585,74586]
===
match
---
atom_expr [58554,58604]
atom_expr [58553,58603]
===
match
---
operator: = [49564,49565]
operator: = [49564,49565]
===
match
---
name: xcom [77384,77388]
name: xcom [77336,77340]
===
match
---
arglist [50597,50627]
arglist [50635,50665]
===
match
---
trailer [82373,82379]
trailer [82325,82331]
===
match
---
trailer [26144,26151]
trailer [26144,26151]
===
match
---
simple_stmt [60604,60626]
simple_stmt [60556,60578]
===
match
---
operator: = [33677,33678]
operator: = [33677,33678]
===
match
---
name: commit [47732,47738]
name: commit [47732,47738]
===
match
---
param [29231,29255]
param [29231,29255]
===
match
---
name: priority_weight [22693,22708]
name: priority_weight [22693,22708]
===
match
---
simple_stmt [26023,26035]
simple_stmt [26023,26035]
===
match
---
name: executor_config [23545,23560]
name: executor_config [23545,23560]
===
match
---
arith_expr [60859,60893]
arith_expr [60811,60845]
===
match
---
atom_expr [11897,11932]
atom_expr [11897,11932]
===
match
---
atom_expr [33028,33039]
atom_expr [33028,33039]
===
match
---
operator: , [1312,1313]
operator: , [1312,1313]
===
match
---
string: """Executes Task (optionally with a Timeout) and pushes Xcom results""" [51203,51274]
string: """Executes Task (optionally with a Timeout) and pushes Xcom results""" [51241,51312]
===
match
---
name: self [24011,24015]
name: self [24011,24015]
===
match
---
trailer [13156,13162]
trailer [13156,13162]
===
match
---
operator: , [78938,78939]
operator: , [78890,78891]
===
match
---
name: ignore_depends_on_past [15198,15220]
name: ignore_depends_on_past [15198,15220]
===
match
---
operator: = [56921,56922]
operator: = [56920,56921]
===
match
---
name: fd [4482,4484]
name: fd [4482,4484]
===
match
---
simple_stmt [50886,50913]
simple_stmt [50924,50951]
===
match
---
operator: , [45820,45821]
operator: , [45820,45821]
===
match
---
name: ti [5490,5492]
name: ti [5490,5492]
===
match
---
name: execution_date [24065,24079]
name: execution_date [24065,24079]
===
match
---
atom [18473,18501]
atom [18473,18501]
===
match
---
trailer [55964,55970]
trailer [55963,55969]
===
match
---
param [53550,53587]
param [53549,53586]
===
match
---
atom_expr [8535,8547]
atom_expr [8535,8547]
===
match
---
trailer [55458,55462]
trailer [55457,55461]
===
match
---
simple_stmt [4808,5072]
simple_stmt [4808,5072]
===
match
---
trailer [80665,80673]
trailer [80617,80625]
===
match
---
name: Exception [49953,49962]
name: Exception [49953,49962]
===
match
---
name: execution_date [74337,74351]
name: execution_date [74289,74303]
===
match
---
atom [60086,60088]
atom [60038,60040]
===
match
---
name: staticmethod [15494,15506]
name: staticmethod [15494,15506]
===
match
---
simple_stmt [22040,22068]
simple_stmt [22040,22068]
===
match
---
funcdef [41683,45725]
funcdef [41683,45725]
===
match
---
name: session [60638,60645]
name: session [60590,60597]
===
match
---
name: get_previous_start_date [30908,30931]
name: get_previous_start_date [30908,30931]
===
match
---
arglist [47430,47452]
arglist [47430,47452]
===
match
---
argument [39751,39784]
argument [39751,39784]
===
match
---
simple_stmt [52805,52834]
simple_stmt [52804,52833]
===
match
---
name: ignore_task_deps [38463,38479]
name: ignore_task_deps [38463,38479]
===
match
---
atom_expr [39080,39097]
atom_expr [39080,39097]
===
match
---
name: task_copy [51694,51703]
name: task_copy [51732,51741]
===
match
---
operator: , [68577,68578]
operator: , [68529,68530]
===
match
---
name: PodGenerator [68792,68804]
name: PodGenerator [68744,68756]
===
match
---
name: schedulable_tis [47378,47393]
name: schedulable_tis [47378,47393]
===
match
---
param [34898,34902]
param [34898,34902]
===
match
---
name: self [31004,31008]
name: self [31004,31008]
===
match
---
atom_expr [79816,79828]
atom_expr [79768,79780]
===
match
---
name: self [80323,80327]
name: self [80275,80279]
===
match
---
name: task_copy [49683,49692]
name: task_copy [49683,49692]
===
match
---
name: self [59987,59991]
name: self [59939,59943]
===
match
---
name: exception [72615,72624]
name: exception [72567,72576]
===
match
---
name: XCom [76473,76477]
name: XCom [76425,76429]
===
match
---
name: RenderedTaskInstanceFields [48250,48276]
name: RenderedTaskInstanceFields [48250,48276]
===
match
---
funcdef [11105,12483]
funcdef [11105,12483]
===
match
---
atom_expr [45042,45052]
atom_expr [45042,45052]
===
match
---
name: airflow_context_vars [49461,49481]
name: airflow_context_vars [49461,49481]
===
match
---
funcdef [79770,80562]
funcdef [79722,80514]
===
match
---
parameters [45815,45835]
parameters [45815,45835]
===
match
---
expr_stmt [70557,70585]
expr_stmt [70509,70537]
===
match
---
string: 'prev_start_date_success' [65403,65428]
string: 'prev_start_date_success' [65355,65380]
===
match
---
suite [3608,3631]
suite [3608,3631]
===
match
---
atom_expr [18832,18868]
atom_expr [18832,18868]
===
match
---
name: TaskInstanceKey [24310,24325]
name: TaskInstanceKey [24310,24325]
===
match
---
name: base_job [7358,7366]
name: base_job [7358,7366]
===
match
---
tfpdef [15885,15909]
tfpdef [15885,15909]
===
match
---
name: execution_date [78411,78425]
name: execution_date [78363,78377]
===
match
---
trailer [66612,66651]
trailer [66564,66603]
===
match
---
arglist [62024,62031]
arglist [61976,61983]
===
match
---
name: ti [80300,80302]
name: ti [80252,80254]
===
match
---
operator: = [79925,79926]
operator: = [79877,79878]
===
match
---
trailer [56853,56872]
trailer [56852,56871]
===
match
---
operator: = [22528,22529]
operator: = [22528,22529]
===
match
---
arglist [71065,71139]
arglist [71017,71091]
===
match
---
atom_expr [43625,43638]
atom_expr [43625,43638]
===
match
---
name: execution_date [8554,8568]
name: execution_date [8554,8568]
===
match
---
atom_expr [19310,19343]
atom_expr [19310,19343]
===
match
---
simple_stmt [45486,45506]
simple_stmt [45486,45506]
===
match
---
name: state [37818,37823]
name: state [37818,37823]
===
match
---
name: self [52251,52255]
name: self [52282,52286]
===
match
---
operator: -> [4344,4346]
operator: -> [4344,4346]
===
match
---
name: ignore_depends_on_past [38400,38422]
name: ignore_depends_on_past [38400,38422]
===
match
---
name: self [57925,57929]
name: self [57924,57928]
===
match
---
simple_stmt [24230,24295]
simple_stmt [24230,24295]
===
match
---
operator: , [56316,56317]
operator: , [56315,56316]
===
match
---
name: self [43979,43983]
name: self [43979,43983]
===
match
---
operator: = [54532,54533]
operator: = [54531,54532]
===
match
---
name: stacklevel [29032,29042]
name: stacklevel [29032,29042]
===
match
---
tfpdef [73179,73189]
tfpdef [73131,73141]
===
match
---
trailer [7302,7314]
trailer [7302,7314]
===
match
---
dotted_name [2210,2223]
dotted_name [2210,2223]
===
match
---
name: session [26901,26908]
name: session [26901,26908]
===
match
---
atom_expr [62476,62487]
atom_expr [62428,62439]
===
match
---
expr_stmt [10388,10451]
expr_stmt [10388,10451]
===
match
---
operator: = [78334,78335]
operator: = [78286,78287]
===
match
---
atom_expr [10286,10301]
atom_expr [10286,10301]
===
match
---
string: "%s. State set to NONE." [40217,40241]
string: "%s. State set to NONE." [40217,40241]
===
match
---
operator: , [65747,65748]
operator: , [65699,65700]
===
match
---
suite [3384,3925]
suite [3384,3925]
===
match
---
name: frame [48393,48398]
name: frame [48393,48398]
===
match
---
name: ti [79442,79444]
name: ti [79394,79396]
===
match
---
operator: = [39188,39189]
operator: = [39188,39189]
===
match
---
or_test [31721,31748]
or_test [31721,31748]
===
match
---
trailer [40743,40755]
trailer [40743,40755]
===
match
---
name: get [64251,64254]
name: get [64203,64206]
===
match
---
name: str [53761,53764]
name: str [53760,53763]
===
match
---
atom_expr [5110,5168]
atom_expr [5110,5168]
===
match
---
funcdef [51150,51938]
funcdef [51188,51976]
===
match
---
operator: = [14760,14761]
operator: = [14760,14761]
===
match
---
atom_expr [58167,58188]
atom_expr [58166,58187]
===
match
---
name: Integer [9902,9909]
name: Integer [9902,9909]
===
match
---
trailer [46358,46360]
trailer [46358,46360]
===
match
---
operator: = [68791,68792]
operator: = [68743,68744]
===
match
---
trailer [47009,47018]
trailer [47009,47018]
===
match
---
trailer [44746,44761]
trailer [44746,44761]
===
match
---
operator: = [40419,40420]
operator: = [40419,40420]
===
match
---
name: session [59060,59067]
name: session [59012,59019]
===
match
---
name: info [40623,40627]
name: info [40623,40627]
===
match
---
trailer [19712,19720]
trailer [19712,19720]
===
match
---
name: get_k8s_pod_yaml [67407,67423]
name: get_k8s_pod_yaml [67359,67375]
===
match
---
fstring_string: / [19149,19150]
fstring_string: / [19149,19150]
===
match
---
name: execution_date [11806,11820]
name: execution_date [11806,11820]
===
match
---
parameters [63045,63109]
parameters [62997,63061]
===
match
---
atom_expr [32157,32174]
atom_expr [32157,32174]
===
match
---
fstring_string: Unable to render a k8s spec for this taskinstance:  [67651,67702]
fstring_string: Unable to render a k8s spec for this taskinstance:  [67603,67654]
===
match
---
name: execution_date [10783,10797]
name: execution_date [10783,10797]
===
match
---
parameters [54893,54899]
parameters [54892,54898]
===
match
---
simple_stmt [70557,70586]
simple_stmt [70509,70538]
===
match
---
simple_stmt [2171,2205]
simple_stmt [2171,2205]
===
match
---
expr_stmt [58097,58136]
expr_stmt [58096,58135]
===
match
---
trailer [21626,21799]
trailer [21626,21799]
===
match
---
dotted_name [7345,7366]
dotted_name [7345,7366]
===
match
---
operator: = [9924,9925]
operator: = [9924,9925]
===
match
---
name: _log [11358,11362]
name: _log [11358,11362]
===
match
---
trailer [41485,41497]
trailer [41485,41497]
===
match
---
trailer [56893,56898]
trailer [56892,56897]
===
match
---
atom_expr [78074,78101]
atom_expr [78026,78053]
===
match
---
param [4763,4786]
param [4763,4786]
===
match
---
trailer [31807,31811]
trailer [31807,31811]
===
match
---
trailer [40978,40984]
trailer [40978,40984]
===
match
---
decorated [41636,45725]
decorated [41636,45725]
===
match
---
arglist [69462,69474]
arglist [69414,69426]
===
match
---
simple_stmt [5362,5383]
simple_stmt [5362,5383]
===
match
---
suite [81669,82400]
suite [81621,82352]
===
match
---
trailer [69077,69082]
trailer [69029,69034]
===
match
---
atom_expr [50993,51009]
atom_expr [51031,51047]
===
match
---
expr_stmt [80507,80534]
expr_stmt [80459,80486]
===
match
---
fstring_string: &dag_id= [19737,19745]
fstring_string: &dag_id= [19737,19745]
===
match
---
simple_stmt [885,901]
simple_stmt [885,901]
===
match
---
and_test [27730,27773]
and_test [27730,27773]
===
match
---
simple_stmt [20618,20631]
simple_stmt [20618,20631]
===
match
---
trailer [5324,5335]
trailer [5324,5335]
===
match
---
operator: , [1303,1304]
operator: , [1303,1304]
===
match
---
atom_expr [57230,57245]
atom_expr [57229,57244]
===
match
---
name: self [33944,33948]
name: self [33944,33948]
===
match
---
decorator [13258,13277]
decorator [13258,13277]
===
match
---
simple_stmt [1260,1350]
simple_stmt [1260,1350]
===
match
---
import_name [847,856]
import_name [847,856]
===
match
---
name: base_url [19648,19656]
name: base_url [19648,19656]
===
match
---
simple_stmt [11255,11283]
simple_stmt [11255,11283]
===
match
---
operator: , [7173,7174]
operator: , [7173,7174]
===
match
---
suite [33130,34873]
suite [33130,34873]
===
match
---
simple_stmt [4463,4486]
simple_stmt [4463,4486]
===
match
---
testlist [8292,8338]
testlist [8292,8338]
===
match
---
operator: , [51172,51173]
operator: , [51210,51211]
===
match
---
simple_stmt [1135,1147]
simple_stmt [1135,1147]
===
match
---
trailer [53038,53059]
trailer [53037,53058]
===
match
---
operator: , [74323,74324]
operator: , [74275,74276]
===
match
---
name: task [53354,53358]
name: task [53353,53357]
===
match
---
name: session [2719,2726]
name: session [2719,2726]
===
match
---
name: self [24817,24821]
name: self [24817,24821]
===
match
---
name: next_ds [64918,64925]
name: next_ds [64870,64877]
===
match
---
arglist [37556,37580]
arglist [37556,37580]
===
match
---
param [59511,59515]
param [59463,59467]
===
match
---
param [41454,41459]
param [41454,41459]
===
match
---
trailer [14780,14789]
trailer [14780,14789]
===
match
---
operator: + [40689,40690]
operator: + [40689,40690]
===
match
---
operator: , [51900,51901]
operator: , [51938,51939]
===
match
---
decorated [35136,35619]
decorated [35136,35619]
===
match
---
name: RenderedTaskInstanceFields [48906,48932]
name: RenderedTaskInstanceFields [48906,48932]
===
match
---
fstring [67649,67706]
fstring [67601,67658]
===
match
---
argument [68646,68679]
argument [68598,68631]
===
match
---
trailer [40715,40730]
trailer [40715,40730]
===
match
---
argument [15327,15346]
argument [15327,15346]
===
match
---
funcdef [35157,35619]
funcdef [35157,35619]
===
match
---
name: self [40831,40835]
name: self [40831,40835]
===
match
---
simple_stmt [32423,32453]
simple_stmt [32423,32453]
===
match
---
name: ceil [33688,33692]
name: ceil [33688,33692]
===
match
---
suite [11863,11933]
suite [11863,11933]
===
match
---
name: task_id [21701,21708]
name: task_id [21701,21708]
===
match
---
name: str [74622,74625]
name: str [74574,74577]
===
match
---
fstring_start: f" [19109,19111]
fstring_start: f" [19109,19111]
===
match
---
name: pendulum [29857,29865]
name: pendulum [29857,29865]
===
match
---
name: email [72761,72766]
name: email [72713,72718]
===
match
---
name: Union [3974,3979]
name: Union [3974,3979]
===
match
---
atom_expr [58503,58514]
atom_expr [58502,58513]
===
match
---
name: params [67984,67990]
name: params [67936,67942]
===
match
---
operator: , [24372,24373]
operator: , [24372,24373]
===
match
---
arglist [46140,46336]
arglist [46140,46336]
===
match
---
trailer [71221,71238]
trailer [71173,71190]
===
match
---
operator: = [23475,23476]
operator: = [23475,23476]
===
match
---
name: urllib [1108,1114]
name: urllib [1108,1114]
===
match
---
operator: , [50179,50180]
operator: , [50171,50172]
===
match
---
operator: @ [45751,45752]
operator: @ [45751,45752]
===
match
---
name: set_state [24421,24430]
name: set_state [24421,24430]
===
match
---
name: debug [24728,24733]
name: debug [24728,24733]
===
match
---
trailer [9576,9628]
trailer [9576,9628]
===
match
---
atom_expr [79953,79969]
atom_expr [79905,79921]
===
match
---
trailer [77730,77738]
trailer [77682,77690]
===
match
---
trailer [37750,37752]
trailer [37750,37752]
===
match
---
name: ti [5947,5949]
name: ti [5947,5949]
===
match
---
atom_expr [5452,5473]
atom_expr [5452,5473]
===
match
---
name: duration [22099,22107]
name: duration [22099,22107]
===
match
---
name: log_message [57994,58005]
name: log_message [57993,58004]
===
match
---
name: dag_id [78668,78674]
name: dag_id [78620,78626]
===
match
---
name: extend [18601,18607]
name: extend [18601,18607]
===
match
---
comparison [23995,24023]
comparison [23995,24023]
===
match
---
operator: } [50690,50691]
operator: } [50728,50729]
===
match
---
trailer [19750,19757]
trailer [19750,19757]
===
match
---
name: handle_failure [56110,56124]
name: handle_failure [56109,56123]
===
match
---
string: 'BASE_LOG_FOLDER' [19074,19091]
string: 'BASE_LOG_FOLDER' [19074,19091]
===
match
---
expr_stmt [23358,23391]
expr_stmt [23358,23391]
===
match
---
atom_expr [61301,61320]
atom_expr [61253,61272]
===
match
---
tfpdef [35980,35995]
tfpdef [35980,35995]
===
match
---
name: dep_status [32959,32969]
name: dep_status [32959,32969]
===
match
---
fstring [47932,47995]
fstring [47932,47995]
===
match
---
operator: = [59284,59285]
operator: = [59236,59237]
===
match
---
simple_stmt [20696,20859]
simple_stmt [20696,20859]
===
match
---
suite [4803,7981]
suite [4803,7981]
===
match
---
string: "%d downstream tasks scheduled from follow-on schedule check" [47639,47700]
string: "%d downstream tasks scheduled from follow-on schedule check" [47639,47700]
===
match
---
decorated [13904,14019]
decorated [13904,14019]
===
match
---
operator: , [34827,34828]
operator: , [34827,34828]
===
match
---
operator: , [68592,68593]
operator: , [68544,68545]
===
match
---
name: self [49915,49919]
name: self [49915,49919]
===
match
---
operator: = [24691,24692]
operator: = [24691,24692]
===
match
---
name: self [41287,41291]
name: self [41287,41291]
===
match
---
name: helpers [2462,2469]
name: helpers [2462,2469]
===
match
---
atom_expr [45027,45039]
atom_expr [45027,45039]
===
match
---
trailer [12213,12215]
trailer [12213,12215]
===
match
---
atom_expr [77778,77791]
atom_expr [77730,77743]
===
match
---
simple_stmt [19025,19094]
simple_stmt [19025,19094]
===
match
---
atom_expr [21907,21918]
atom_expr [21907,21918]
===
match
---
name: extend [18083,18089]
name: extend [18083,18089]
===
match
---
name: session [40971,40978]
name: session [40971,40978]
===
match
---
operator: , [32792,32793]
operator: , [32792,32793]
===
match
---
name: is_container [76920,76932]
name: is_container [76872,76884]
===
match
---
name: func [1340,1344]
name: func [1340,1344]
===
match
---
trailer [57051,57066]
trailer [57050,57065]
===
match
---
atom_expr [51617,51636]
atom_expr [51655,51674]
===
match
---
decorator [8152,8162]
decorator [8152,8162]
===
match
---
operator: = [41893,41894]
operator: = [41893,41894]
===
match
---
operator: , [66622,66623]
operator: , [66574,66575]
===
match
---
string: """Render k8s pod yaml""" [68364,68389]
string: """Render k8s pod yaml""" [68316,68341]
===
match
---
operator: = [19597,19598]
operator: = [19597,19598]
===
match
---
simple_stmt [54356,54363]
simple_stmt [54355,54362]
===
match
---
name: set_duration [72804,72816]
name: set_duration [72756,72768]
===
match
---
name: str [18168,18171]
name: str [18168,18171]
===
match
---
simple_stmt [18979,19017]
simple_stmt [18979,19017]
===
match
---
name: default_html_content_err [71387,71411]
name: default_html_content_err [71339,71363]
===
match
---
name: ignore_ti_state [37793,37808]
name: ignore_ti_state [37793,37808]
===
match
---
decorator [50740,50757]
decorator [50778,50795]
===
match
---
fstring_string:  [ [33077,33079]
fstring_string:  [ [33077,33079]
===
match
---
name: qry [82309,82312]
name: qry [82261,82264]
===
match
---
atom_expr [79610,79637]
atom_expr [79562,79589]
===
match
---
name: renderedtifields [67300,67316]
name: renderedtifields [67252,67268]
===
match
---
name: hasattr [60167,60174]
name: hasattr [60119,60126]
===
match
---
name: session [60604,60611]
name: session [60556,60563]
===
match
---
atom_expr [7287,7314]
atom_expr [7287,7314]
===
match
---
name: timezone [11503,11511]
name: timezone [11503,11511]
===
match
---
expr_stmt [53309,53337]
expr_stmt [53308,53336]
===
match
---
name: expanduser [19043,19053]
name: expanduser [19043,19053]
===
match
---
trailer [72109,72118]
trailer [72061,72070]
===
match
---
name: self [44640,44644]
name: self [44640,44644]
===
match
---
decorated [80607,80674]
decorated [80559,80626]
===
match
---
simple_stmt [40007,40039]
simple_stmt [40007,40039]
===
match
---
atom_expr [55572,55588]
atom_expr [55571,55587]
===
match
---
atom_expr [76984,76998]
atom_expr [76936,76950]
===
match
---
trailer [8553,8568]
trailer [8553,8568]
===
match
---
name: utils [2828,2833]
name: utils [2828,2833]
===
match
---
trailer [28037,28068]
trailer [28037,28068]
===
match
---
name: execution_date [73971,73985]
name: execution_date [73923,73937]
===
match
---
arglist [62650,62680]
arglist [62602,62632]
===
match
---
name: registered [49805,49815]
name: registered [49805,49815]
===
match
---
name: queue [23284,23289]
name: queue [23284,23289]
===
match
---
operator: , [20479,20480]
operator: , [20479,20480]
===
match
---
operator: , [76667,76668]
operator: , [76619,76620]
===
match
---
name: error_file [56854,56864]
name: error_file [56853,56863]
===
match
---
name: XCom [23995,23999]
name: XCom [23995,23999]
===
match
---
expr_stmt [14912,14923]
expr_stmt [14912,14923]
===
match
---
name: partial_dag [46648,46659]
name: partial_dag [46648,46659]
===
match
---
parameters [25460,25480]
parameters [25460,25480]
===
match
---
atom_expr [80992,81006]
atom_expr [80944,80958]
===
match
---
name: task_id_by_key [7184,7198]
name: task_id_by_key [7184,7198]
===
match
---
name: self [65743,65747]
name: self [65695,65699]
===
match
---
name: dag [5406,5409]
name: dag [5406,5409]
===
match
---
atom_expr [62127,62146]
atom_expr [62079,62098]
===
match
---
name: task [53183,53187]
name: task [53182,53186]
===
match
---
expr_stmt [10306,10327]
expr_stmt [10306,10327]
===
match
---
trailer [10082,10118]
trailer [10082,10118]
===
match
---
name: load_error_file [3931,3946]
name: load_error_file [3931,3946]
===
match
---
name: self [40739,40743]
name: self [40739,40743]
===
match
---
tfpdef [59267,59283]
tfpdef [59219,59235]
===
match
---
name: task_id [26178,26185]
name: task_id [26178,26185]
===
match
---
name: task_id [79878,79885]
name: task_id [79830,79837]
===
match
---
argument [54214,54233]
argument [54213,54232]
===
match
---
atom_expr [25088,25107]
atom_expr [25088,25107]
===
match
---
operator: = [47569,47570]
operator: = [47569,47570]
===
match
---
trailer [18082,18089]
trailer [18082,18089]
===
match
---
name: and_ [79287,79291]
name: and_ [79239,79243]
===
match
---
trailer [22604,22615]
trailer [22604,22615]
===
match
---
name: UndefinedError [67588,67602]
name: UndefinedError [67540,67554]
===
match
---
simple_stmt [11554,11717]
simple_stmt [11554,11717]
===
match
---
operator: , [10675,10676]
operator: , [10675,10676]
===
match
---
arglist [27296,27350]
arglist [27296,27350]
===
match
---
trailer [22892,22927]
trailer [22892,22927]
===
match
---
name: log [50164,50167]
name: log [50021,50024]
===
match
---
trailer [5552,5560]
trailer [5552,5560]
===
match
---
name: task [32546,32550]
name: task [32546,32550]
===
match
---
trailer [40622,40627]
trailer [40622,40627]
===
match
---
name: self [55535,55539]
name: self [55534,55538]
===
match
---
trailer [57202,57261]
trailer [57201,57260]
===
match
---
name: ti_hash [34191,34198]
name: ti_hash [34191,34198]
===
match
---
name: staticmethod [64222,64234]
name: staticmethod [64174,64186]
===
match
---
operator: , [59291,59292]
operator: , [59243,59244]
===
match
---
name: commit [38684,38690]
name: commit [38684,38690]
===
match
---
trailer [6106,6121]
trailer [6106,6121]
===
match
---
name: task_copy [49878,49887]
name: task_copy [49878,49887]
===
match
---
name: pool [23316,23320]
name: pool [23316,23320]
===
match
---
expr_stmt [11353,11398]
expr_stmt [11353,11398]
===
match
---
name: kube_config [2985,2996]
name: kube_config [2985,2996]
===
match
---
atom_expr [61662,61702]
atom_expr [61614,61654]
===
match
---
simple_stmt [80727,80748]
simple_stmt [80679,80700]
===
match
---
name: replace [62016,62023]
name: replace [61968,61975]
===
match
---
operator: , [8303,8304]
operator: , [8303,8304]
===
match
---
expr_stmt [37508,37524]
expr_stmt [37508,37524]
===
match
---
argument [38248,38284]
argument [38248,38284]
===
match
---
simple_stmt [36124,37500]
simple_stmt [36124,37500]
===
match
---
trailer [9781,9788]
trailer [9781,9788]
===
match
---
atom_expr [42758,42795]
atom_expr [42758,42795]
===
match
---
trailer [77609,77611]
trailer [77561,77563]
===
match
---
name: start_date [24840,24850]
name: start_date [24840,24850]
===
match
---
string: """Log URL for TaskInstance""" [19207,19237]
string: """Log URL for TaskInstance""" [19207,19237]
===
match
---
string: """Return TI Context""" [59948,59971]
string: """Return TI Context""" [59900,59923]
===
match
---
trailer [18653,18660]
trailer [18653,18660]
===
match
---
dotted_name [35362,35383]
dotted_name [35362,35383]
===
match
---
name: tis [79180,79183]
name: tis [79132,79135]
===
match
---
name: self [24956,24960]
name: self [24956,24960]
===
match
---
name: previous_scheduled_date [27327,27350]
name: previous_scheduled_date [27327,27350]
===
match
---
name: property [25114,25122]
name: property [25114,25122]
===
match
---
string: "--ignore-all-dependencies" [18306,18333]
string: "--ignore-all-dependencies" [18306,18333]
===
match
---
trailer [73970,73985]
trailer [73922,73937]
===
match
---
operator: + [13249,13250]
operator: + [13249,13250]
===
match
---
name: os [854,856]
name: os [854,856]
===
match
---
name: delete_old_records [49039,49057]
name: delete_old_records [49039,49057]
===
match
---
suite [52238,52344]
suite [52269,52343]
===
match
---
operator: = [15760,15761]
operator: = [15760,15761]
===
match
---
atom_expr [62367,62395]
atom_expr [62319,62347]
===
match
---
operator: = [27933,27934]
operator: = [27933,27934]
===
match
---
number: 1 [37889,37890]
number: 1 [37889,37890]
===
match
---
arglist [43134,43147]
arglist [43134,43147]
===
match
---
trailer [60611,60623]
trailer [60563,60575]
===
match
---
operator: -> [81270,81272]
operator: -> [81222,81224]
===
match
---
suite [22838,22869]
suite [22838,22869]
===
match
---
name: dep_status [32573,32583]
name: dep_status [32573,32583]
===
match
---
atom [69777,70121]
atom [69729,70073]
===
match
---
argument [39639,39670]
argument [39639,39670]
===
match
---
atom_expr [80208,80221]
atom_expr [80160,80173]
===
match
---
name: context [51720,51727]
name: context [51758,51765]
===
match
---
name: bool [15834,15838]
name: bool [15834,15838]
===
match
---
operator: = [68485,68486]
operator: = [68437,68438]
===
match
---
operator: , [56218,56219]
operator: , [56217,56218]
===
match
---
name: mark_success [14105,14117]
name: mark_success [14105,14117]
===
match
---
trailer [68740,68756]
trailer [68692,68708]
===
match
---
name: get_many [76478,76486]
name: get_many [76430,76438]
===
match
---
suite [61266,61375]
suite [61218,61327]
===
match
---
name: extend [18220,18226]
name: extend [18220,18226]
===
match
---
name: task [72667,72671]
name: task [72619,72623]
===
match
---
name: session [23915,23922]
name: session [23915,23922]
===
match
---
atom_expr [70738,71003]
atom_expr [70690,70955]
===
match
---
operator: = [50897,50898]
operator: = [50935,50936]
===
match
---
name: self [82123,82127]
name: self [82075,82079]
===
match
---
expr_stmt [7484,7510]
expr_stmt [7484,7510]
===
match
---
name: executor_config [23568,23583]
name: executor_config [23568,23583]
===
match
---
name: State [40859,40864]
name: State [40859,40864]
===
match
---
simple_stmt [8222,8277]
simple_stmt [8222,8277]
===
match
---
name: pendulum [64790,64798]
name: pendulum [64742,64750]
===
match
---
name: pendulum [30448,30456]
name: pendulum [30448,30456]
===
match
---
name: state [22125,22130]
name: state [22125,22130]
===
match
---
name: downstream_task_ids [25990,26009]
name: downstream_task_ids [25990,26009]
===
match
---
operator: = [74652,74653]
operator: = [74604,74605]
===
match
---
simple_stmt [32461,32503]
simple_stmt [32461,32503]
===
match
---
simple_stmt [17986,18042]
simple_stmt [17986,18042]
===
match
---
if_stmt [41173,41410]
if_stmt [41173,41410]
===
match
---
argument [74337,74389]
argument [74289,74341]
===
match
---
name: try_number [6874,6884]
name: try_number [6874,6884]
===
match
---
param [29194,29222]
param [29194,29222]
===
match
---
name: state [39118,39123]
name: state [39118,39123]
===
match
---
operator: @ [74435,74436]
operator: @ [74387,74388]
===
match
---
name: BaseJob [82545,82552]
name: BaseJob [82497,82504]
===
match
---
trailer [6992,6998]
trailer [6992,6998]
===
match
---
operator: = [5960,5961]
operator: = [5960,5961]
===
match
---
parameters [35171,35202]
parameters [35171,35202]
===
match
---
argument [48877,48892]
argument [48877,48892]
===
match
---
arglist [40816,40835]
arglist [40816,40835]
===
match
---
trailer [48531,48539]
trailer [48531,48539]
===
match
---
trailer [20935,20941]
trailer [20935,20941]
===
match
---
simple_stmt [77564,77839]
simple_stmt [77516,77791]
===
match
---
trailer [17975,17977]
trailer [17975,17977]
===
match
---
simple_stmt [10193,10225]
simple_stmt [10193,10225]
===
match
---
simple_stmt [18939,18971]
simple_stmt [18939,18971]
===
match
---
atom_expr [18377,18414]
atom_expr [18377,18414]
===
match
---
name: Column [9962,9968]
name: Column [9962,9968]
===
match
---
name: xcom_push [73128,73137]
name: xcom_push [73080,73089]
===
match
---
name: self [45388,45392]
name: self [45388,45392]
===
match
---
name: Optional [26506,26514]
name: Optional [26506,26514]
===
match
---
arglist [74225,74419]
arglist [74177,74371]
===
match
---
operator: = [50480,50481]
operator: = [50518,50519]
===
match
---
trailer [67999,68004]
trailer [67951,67956]
===
match
---
trailer [61305,61320]
trailer [61257,61272]
===
match
---
name: ti [7797,7799]
name: ti [7797,7799]
===
match
---
name: dag [26848,26851]
name: dag [26848,26851]
===
match
---
name: task_id [45316,45323]
name: task_id [45316,45323]
===
match
---
decorated [13258,13343]
decorated [13258,13343]
===
match
---
suite [72907,72986]
suite [72859,72938]
===
match
---
name: str [29802,29805]
name: str [29802,29805]
===
match
---
operator: = [47499,47500]
operator: = [47499,47500]
===
match
---
name: verbose_aware_logger [31780,31800]
name: verbose_aware_logger [31780,31800]
===
match
---
simple_stmt [59980,59997]
simple_stmt [59932,59949]
===
match
---
operator: = [15336,15337]
operator: = [15336,15337]
===
match
---
if_stmt [66470,67181]
if_stmt [66422,67133]
===
match
---
name: self [65479,65483]
name: self [65431,65435]
===
match
---
name: exception [56541,56550]
name: exception [56540,56549]
===
match
---
trailer [56911,56920]
trailer [56910,56919]
===
match
---
operator: , [40241,40242]
operator: , [40241,40242]
===
match
---
expr_stmt [80456,80498]
expr_stmt [80408,80450]
===
match
---
name: ApiClient [2946,2955]
name: ApiClient [2946,2955]
===
match
---
atom_expr [44289,44311]
atom_expr [44289,44311]
===
match
---
tfpdef [56262,56287]
tfpdef [56261,56286]
===
match
---
argument [9670,9686]
argument [9670,9686]
===
match
---
trailer [8526,8533]
trailer [8526,8533]
===
match
---
operator: @ [64221,64222]
operator: @ [64173,64174]
===
match
---
name: Optional [26561,26569]
name: Optional [26561,26569]
===
match
---
name: first [78405,78410]
name: first [78357,78362]
===
match
---
name: test_mode [59371,59380]
name: test_mode [59323,59332]
===
match
---
operator: = [43197,43198]
operator: = [43197,43198]
===
match
---
tfpdef [26499,26519]
tfpdef [26499,26519]
===
match
---
import_from [60280,60320]
import_from [60232,60272]
===
match
---
operator: -> [53838,53840]
operator: -> [53837,53839]
===
match
---
name: state [24883,24888]
name: state [24883,24888]
===
match
---
name: date [41553,41557]
name: date [41553,41557]
===
match
---
name: pool_slots [22589,22599]
name: pool_slots [22589,22599]
===
match
---
name: dag_id [24331,24337]
name: dag_id [24331,24337]
===
match
---
atom_expr [77297,77307]
atom_expr [77249,77259]
===
match
---
simple_stmt [7629,7875]
simple_stmt [7629,7875]
===
match
---
name: warnings [28808,28816]
name: warnings [28808,28816]
===
match
---
trailer [33370,33375]
trailer [33370,33375]
===
match
---
name: state [6020,6025]
name: state [6020,6025]
===
match
---
name: kubernetes [3032,3042]
name: kubernetes [3032,3042]
===
match
---
operator: = [14648,14649]
operator: = [14648,14649]
===
match
---
trailer [58693,58722]
trailer [58692,58721]
===
match
---
arglist [9584,9608]
arglist [9584,9608]
===
match
---
arglist [62329,62336]
arglist [62281,62288]
===
match
---
name: task [52970,52974]
name: task [52969,52973]
===
match
---
simple_stmt [62610,62682]
simple_stmt [62562,62634]
===
match
---
param [15967,15985]
param [15967,15985]
===
match
---
trailer [73016,73025]
trailer [72968,72977]
===
match
---
simple_stmt [80902,80926]
simple_stmt [80854,80878]
===
match
---
string: "started running, please use 'airflow tasks render' for debugging the " [67032,67103]
string: "started running, please use 'airflow tasks render' for debugging the " [66984,67055]
===
match
---
atom_expr [22690,22708]
atom_expr [22690,22708]
===
match
---
simple_stmt [72081,72143]
simple_stmt [72033,72095]
===
match
---
simple_stmt [64449,64507]
simple_stmt [64401,64459]
===
match
---
string: "Refreshing TaskInstance %s from DB" [21533,21569]
string: "Refreshing TaskInstance %s from DB" [21533,21569]
===
match
---
atom_expr [68579,68591]
atom_expr [68531,68543]
===
match
---
simple_stmt [60718,60755]
simple_stmt [60670,60707]
===
match
---
name: replace [62244,62251]
name: replace [62196,62203]
===
match
---
name: task_id [68511,68518]
name: task_id [68463,68470]
===
match
---
trailer [77365,77383]
trailer [77317,77335]
===
match
---
name: self [44289,44293]
name: self [44289,44293]
===
match
---
name: AirflowSkipException [43355,43375]
name: AirflowSkipException [43355,43375]
===
match
---
operator: , [7830,7831]
operator: , [7830,7831]
===
match
---
string: '' [62274,62276]
string: '' [62226,62228]
===
match
---
name: REQUEUEABLE_DEPS [39605,39621]
name: REQUEUEABLE_DEPS [39605,39621]
===
match
---
operator: , [15092,15093]
operator: , [15092,15093]
===
match
---
operator: , [26347,26348]
operator: , [26347,26348]
===
match
---
operator: , [1752,1753]
operator: , [1752,1753]
===
match
---
name: iso [18037,18040]
name: iso [18037,18040]
===
match
---
atom_expr [28008,28068]
atom_expr [28008,28068]
===
match
---
atom_expr [71688,71703]
atom_expr [71640,71655]
===
match
---
fstring_start: f' [56988,56990]
fstring_start: f' [56987,56989]
===
match
---
if_stmt [57075,57142]
if_stmt [57074,57141]
===
match
---
name: dep_name [32784,32792]
name: dep_name [32784,32792]
===
match
---
name: base_url [19299,19307]
name: base_url [19299,19307]
===
match
---
name: RUNNING [7927,7934]
name: RUNNING [7927,7934]
===
match
---
atom_expr [28551,28573]
atom_expr [28551,28573]
===
match
---
trailer [11511,11524]
trailer [11511,11524]
===
match
---
operator: = [65360,65361]
operator: = [65312,65313]
===
match
---
name: state [24803,24808]
name: state [24803,24808]
===
match
---
name: tis [78934,78937]
name: tis [78886,78889]
===
match
---
name: self [63063,63067]
name: self [63015,63019]
===
match
---
name: max_tries [71744,71753]
name: max_tries [71696,71705]
===
match
---
operator: = [9875,9876]
operator: = [9875,9876]
===
match
---
name: raw [18690,18693]
name: raw [18690,18693]
===
match
---
param [73199,73241]
param [73151,73193]
===
match
---
operator: , [10843,10844]
operator: , [10843,10844]
===
match
---
factor [82449,82451]
factor [82401,82403]
===
match
---
expr_stmt [10016,10058]
expr_stmt [10016,10058]
===
match
---
simple_stmt [56839,56873]
simple_stmt [56838,56872]
===
match
---
simple_stmt [59088,59105]
simple_stmt [59040,59057]
===
match
---
arglist [42724,42748]
arglist [42724,42748]
===
match
---
suite [59939,66190]
suite [59891,66142]
===
match
---
atom_expr [68486,68497]
atom_expr [68438,68449]
===
match
---
simple_stmt [67824,67869]
simple_stmt [67776,67821]
===
match
---
name: execution_date [17951,17965]
name: execution_date [17951,17965]
===
match
---
simple_stmt [72222,72291]
simple_stmt [72174,72243]
===
match
---
arglist [7708,7831]
arglist [7708,7831]
===
match
---
operator: , [1066,1067]
operator: , [1066,1067]
===
match
---
dotted_name [48211,48242]
dotted_name [48211,48242]
===
match
---
name: get_template_context [59852,59872]
name: get_template_context [59804,59824]
===
match
---
trailer [33032,33039]
trailer [33032,33039]
===
match
---
if_stmt [45646,45725]
if_stmt [45646,45725]
===
match
---
operator: , [59725,59726]
operator: , [59677,59678]
===
match
---
trailer [27305,27310]
trailer [27305,27310]
===
match
---
expr_stmt [69091,69150]
expr_stmt [69043,69102]
===
match
---
fstring_expr [62420,62433]
fstring_expr [62372,62385]
===
match
---
param [8624,8629]
param [8624,8629]
===
match
---
funcdef [63030,63189]
funcdef [62982,63141]
===
match
---
parameters [59163,59320]
parameters [59115,59272]
===
match
---
name: XCOM_RETURN_KEY [2088,2103]
name: XCOM_RETURN_KEY [2088,2103]
===
match
---
fstring_end: ' [42969,42970]
fstring_end: ' [42969,42970]
===
match
---
param [15856,15876]
param [15856,15876]
===
match
---
simple_stmt [47625,47707]
simple_stmt [47625,47707]
===
match
---
funcdef [59131,59481]
funcdef [59083,59433]
===
match
---
name: SUCCESS [65367,65374]
name: SUCCESS [65319,65326]
===
match
---
string: "Task successfully registered in smart sensor." [51096,51143]
string: "Task successfully registered in smart sensor." [51134,51181]
===
match
---
except_clause [52182,52205]
except_clause [52220,52236]
===
match
---
atom_expr [56437,56451]
atom_expr [56436,56450]
===
match
---
trailer [30366,30377]
trailer [30366,30377]
===
match
---
name: state [27664,27669]
name: state [27664,27669]
===
match
---
operator: = [10284,10285]
operator: = [10284,10285]
===
match
---
name: operator [23597,23605]
name: operator [23597,23605]
===
match
---
name: prev_ti [30306,30313]
name: prev_ti [30306,30313]
===
match
---
argument [54083,54116]
argument [54082,54115]
===
match
---
decorator [45751,45773]
decorator [45751,45773]
===
match
---
argument [9539,9555]
argument [9539,9555]
===
match
---
name: _date_or_empty [43984,43998]
name: _date_or_empty [43984,43998]
===
match
---
simple_stmt [79263,79511]
simple_stmt [79215,79463]
===
match
---
simple_stmt [4357,4399]
simple_stmt [4357,4399]
===
match
---
number: 1 [60891,60892]
number: 1 [60843,60844]
===
match
---
operator: , [53701,53702]
operator: , [53700,53701]
===
match
---
operator: , [19330,19331]
operator: , [19330,19331]
===
match
---
operator: - [33740,33741]
operator: - [33740,33741]
===
match
---
return_stmt [40524,40536]
return_stmt [40524,40536]
===
match
---
trailer [22440,22449]
trailer [22440,22449]
===
match
---
trailer [24122,24124]
trailer [24122,24124]
===
match
---
name: task_id [21717,21724]
name: task_id [21717,21724]
===
match
---
suite [67218,67748]
suite [67170,67700]
===
match
---
name: task_copy [50574,50583]
name: task_copy [50612,50621]
===
match
---
operator: == [82120,82122]
operator: == [82072,82074]
===
match
---
comparison [27685,27714]
comparison [27685,27714]
===
match
---
atom_expr [5980,6003]
atom_expr [5980,6003]
===
match
---
operator: , [32102,32103]
operator: , [32102,32103]
===
match
---
atom_expr [60041,60067]
atom_expr [59993,60019]
===
match
---
trailer [34806,34811]
trailer [34806,34811]
===
match
---
name: self [49625,49629]
name: self [49625,49629]
===
match
---
except_clause [51574,51599]
except_clause [51612,51637]
===
match
---
argument [71626,71655]
argument [71578,71607]
===
match
---
name: pool_slots [10063,10073]
name: pool_slots [10063,10073]
===
match
---
operator: = [19539,19540]
operator: = [19539,19540]
===
match
---
simple_stmt [73298,73919]
simple_stmt [73250,73871]
===
match
---
trailer [23928,23934]
trailer [23928,23934]
===
match
---
operator: = [59380,59381]
operator: = [59332,59333]
===
match
---
name: prev_ds_nodash [61862,61876]
name: prev_ds_nodash [61814,61828]
===
match
---
if_stmt [5395,6005]
if_stmt [5395,6005]
===
match
---
trailer [13171,13179]
trailer [13171,13179]
===
match
---
name: _priority_weight [80362,80378]
name: _priority_weight [80314,80330]
===
match
---
operator: , [9866,9867]
operator: , [9866,9867]
===
match
---
operator: , [10726,10727]
operator: , [10726,10727]
===
match
---
atom_expr [21738,21765]
atom_expr [21738,21765]
===
match
---
param [59668,59678]
param [59620,59630]
===
match
---
name: ts_nodash [65890,65899]
name: ts_nodash [65842,65851]
===
match
---
param [11124,11129]
param [11124,11129]
===
match
---
name: self [61450,61454]
name: self [61402,61406]
===
match
---
trailer [68451,68465]
trailer [68403,68417]
===
match
---
name: Optional [1080,1088]
name: Optional [1080,1088]
===
match
---
parameters [34897,34903]
parameters [34897,34903]
===
match
---
name: context [52875,52882]
name: context [52874,52881]
===
match
---
operator: , [10700,10701]
operator: , [10700,10701]
===
match
---
name: current_time [24854,24866]
name: current_time [24854,24866]
===
match
---
name: self [12058,12062]
name: self [12058,12062]
===
match
---
not_test [32910,32931]
not_test [32910,32931]
===
match
---
trailer [78665,78737]
trailer [78617,78689]
===
match
---
name: self [52672,52676]
name: self [52671,52675]
===
match
---
atom_expr [52251,52307]
atom_expr [52282,52342]
===
match
---
decorated [45730,48085]
decorated [45730,48085]
===
match
---
name: session [77457,77464]
name: session [77409,77416]
===
match
---
name: ignore_task_deps [15777,15793]
name: ignore_task_deps [15777,15793]
===
match
---
atom_expr [10243,10262]
atom_expr [10243,10262]
===
match
---
trailer [7912,7918]
trailer [7912,7918]
===
match
---
trailer [81387,81394]
trailer [81339,81346]
===
match
---
operator: = [39230,39231]
operator: = [39230,39231]
===
match
---
name: extend [18298,18304]
name: extend [18298,18304]
===
match
---
param [59879,59891]
param [59831,59843]
===
match
---
expr_stmt [26044,26358]
expr_stmt [26044,26358]
===
match
---
name: variable [2031,2039]
name: variable [2031,2039]
===
match
---
trailer [71484,71505]
trailer [71436,71457]
===
match
---
atom [26316,26346]
atom [26316,26346]
===
match
---
name: base_url [19359,19367]
name: base_url [19359,19367]
===
match
---
trailer [34010,34017]
trailer [34010,34017]
===
match
---
name: error_file [4413,4423]
name: error_file [4413,4423]
===
match
---
simple_stmt [64053,64106]
simple_stmt [64005,64058]
===
match
---
trailer [55490,55723]
trailer [55489,55722]
===
match
---
atom [33717,33745]
atom [33717,33745]
===
match
---
name: configuration [1589,1602]
name: configuration [1589,1602]
===
match
---
name: dag_id [60452,60458]
name: dag_id [60404,60410]
===
match
---
name: extend [18466,18472]
name: extend [18466,18472]
===
match
---
operator: , [62332,62333]
operator: , [62284,62285]
===
match
---
decorator [81400,81410]
decorator [81352,81362]
===
match
---
param [35750,35771]
param [35750,35771]
===
match
---
operator: } [48808,48809]
operator: } [48808,48809]
===
match
---
atom [3276,3278]
atom [3276,3278]
===
match
---
name: get_previous_ti [30177,30192]
name: get_previous_ti [30177,30192]
===
match
---
name: VariableAccessor [62697,62713]
name: VariableAccessor [62649,62665]
===
match
---
name: State [39980,39985]
name: State [39980,39985]
===
match
---
number: 1 [50697,50698]
number: 1 [50735,50736]
===
match
---
name: key [51881,51884]
name: key [51919,51922]
===
match
---
operator: = [22688,22689]
operator: = [22688,22689]
===
match
---
name: test_mode [56394,56403]
name: test_mode [56393,56402]
===
match
---
if_stmt [14680,14924]
if_stmt [14680,14924]
===
match
---
operator: , [14224,14225]
operator: , [14224,14225]
===
match
---
name: e [44274,44275]
name: e [44274,44275]
===
match
---
expr_stmt [77270,77316]
expr_stmt [77222,77268]
===
match
---
operator: = [61847,61848]
operator: = [61799,61800]
===
match
---
comparison [78827,78872]
comparison [78779,78824]
===
match
---
name: error [59364,59369]
name: error [59316,59321]
===
match
---
import_from [1909,1953]
import_from [1909,1953]
===
match
---
simple_stmt [9883,9911]
simple_stmt [9883,9911]
===
match
---
name: sentry [2184,2190]
name: sentry [2184,2190]
===
match
---
name: self [22922,22926]
name: self [22922,22926]
===
match
---
name: previous_schedule [27140,27157]
name: previous_schedule [27140,27157]
===
match
---
param [35819,35856]
param [35819,35856]
===
match
---
operator: , [29044,29045]
operator: , [29044,29045]
===
match
---
suite [55318,55338]
suite [55317,55337]
===
match
---
name: _set_context [77955,77967]
name: _set_context [77907,77919]
===
match
---
trailer [9968,9982]
trailer [9968,9982]
===
match
---
expr_stmt [63127,63156]
expr_stmt [63079,63108]
===
match
---
simple_stmt [835,847]
simple_stmt [835,847]
===
match
---
operator: , [8792,8793]
operator: , [8792,8793]
===
match
---
name: ti [80341,80343]
name: ti [80293,80295]
===
match
---
trailer [30358,30378]
trailer [30358,30378]
===
match
---
name: task_id [45032,45039]
name: task_id [45032,45039]
===
match
---
atom_expr [65361,65374]
atom_expr [65313,65326]
===
match
---
trailer [11562,11570]
trailer [11562,11570]
===
match
---
operator: , [10041,10042]
operator: , [10041,10042]
===
match
---
atom_expr [48906,48999]
atom_expr [48906,48999]
===
match
---
operator: ** [71317,71319]
operator: ** [71269,71271]
===
match
---
name: self [64808,64812]
name: self [64760,64764]
===
match
---
name: previous_scheduled_date [27202,27225]
name: previous_scheduled_date [27202,27225]
===
match
---
operator: = [64062,64063]
operator: = [64014,64015]
===
match
---
trailer [35552,35567]
trailer [35552,35567]
===
match
---
name: ti [5980,5982]
name: ti [5980,5982]
===
match
---
operator: = [63586,63587]
operator: = [63538,63539]
===
match
---
name: ti [6123,6125]
name: ti [6123,6125]
===
match
---
name: commit [41007,41013]
name: commit [41007,41013]
===
match
---
name: execution_date [11987,12001]
name: execution_date [11987,12001]
===
match
---
name: dag_id [42947,42953]
name: dag_id [42947,42953]
===
match
---
name: Column [9740,9746]
name: Column [9740,9746]
===
match
---
name: ignore_all_deps [53979,53994]
name: ignore_all_deps [53978,53993]
===
match
---
atom_expr [5966,5978]
atom_expr [5966,5978]
===
match
---
name: models [45959,45965]
name: models [45959,45965]
===
match
---
trailer [47633,47638]
trailer [47633,47638]
===
match
---
not_test [40944,40957]
not_test [40944,40957]
===
match
---
atom_expr [5211,5224]
atom_expr [5211,5224]
===
match
---
name: or_ [79270,79273]
name: or_ [79222,79225]
===
match
---
name: t [78666,78667]
name: t [78618,78619]
===
match
---
expr_stmt [10123,10150]
expr_stmt [10123,10150]
===
match
---
name: pool [80344,80348]
name: pool [80296,80300]
===
match
---
name: Column [9926,9932]
name: Column [9926,9932]
===
match
---
operator: } [57023,57024]
operator: } [57022,57023]
===
match
---
atom_expr [82231,82251]
atom_expr [82183,82203]
===
match
---
name: verbose_aware_logger [32244,32264]
name: verbose_aware_logger [32244,32264]
===
match
---
expr_stmt [10155,10188]
expr_stmt [10155,10188]
===
match
---
argument [50181,50194]
argument [50197,50210]
===
match
---
name: self [25347,25351]
name: self [25347,25351]
===
match
---
operator: + [14015,14016]
operator: + [14015,14016]
===
match
---
string: 'schedule_after_task_execution' [45885,45916]
string: 'schedule_after_task_execution' [45885,45916]
===
match
---
name: NONE [6034,6038]
name: NONE [6034,6038]
===
match
---
operator: = [42743,42744]
operator: = [42743,42744]
===
match
---
param [77871,77880]
param [77823,77832]
===
match
---
operator: , [4703,4704]
operator: , [4703,4704]
===
match
---
atom_expr [26375,26383]
atom_expr [26375,26383]
===
match
---
operator: { [60086,60087]
operator: { [60038,60039]
===
match
---
name: self [72817,72821]
name: self [72769,72773]
===
match
---
atom_expr [23292,23302]
atom_expr [23292,23302]
===
match
---
operator: , [46741,46742]
operator: , [46741,46742]
===
match
---
expr_stmt [23502,23531]
expr_stmt [23502,23531]
===
match
---
trailer [63005,63009]
trailer [62957,62961]
===
match
---
trailer [46153,46161]
trailer [46153,46161]
===
match
---
name: Optional [80380,80388]
name: Optional [80332,80340]
===
match
---
trailer [71965,71979]
trailer [71917,71931]
===
match
---
operator: } [66079,66080]
operator: } [66031,66032]
===
match
---
simple_stmt [10123,10151]
simple_stmt [10123,10151]
===
match
---
name: get_previous_ti [26468,26483]
name: get_previous_ti [26468,26483]
===
match
---
funcdef [81492,81556]
funcdef [81444,81508]
===
match
---
atom_expr [63180,63188]
atom_expr [63132,63140]
===
match
---
string: """             Wrapper around Variable. This way you can get variables in             templates by using ``{{ var.json.variable_name }}`` or             ``{{ var.json.get('variable_name', {'fall': 'back'}) }}``.             """ [63649,63877]
string: """             Wrapper around Variable. This way you can get variables in             templates by using ``{{ var.json.variable_name }}`` or             ``{{ var.json.get('variable_name', {'fall': 'back'}) }}``.             """ [63601,63829]
===
match
---
sync_comp_for [7815,7828]
sync_comp_for [7815,7828]
===
match
---
atom_expr [52761,52788]
atom_expr [52760,52787]
===
match
---
simple_stmt [82304,82339]
simple_stmt [82256,82291]
===
match
---
name: models [2024,2030]
name: models [2024,2030]
===
match
---
atom_expr [60858,60915]
atom_expr [60810,60867]
===
match
---
name: primary [8170,8177]
name: primary [8170,8177]
===
match
---
operator: , [63332,63333]
operator: , [63284,63285]
===
match
---
trailer [6092,6103]
trailer [6092,6103]
===
match
---
expr_stmt [55031,55052]
expr_stmt [55030,55051]
===
match
---
name: dag [47511,47514]
name: dag [47511,47514]
===
match
---
simple_stmt [2400,2443]
simple_stmt [2400,2443]
===
match
---
atom_expr [7963,7980]
atom_expr [7963,7980]
===
match
---
trailer [46974,47009]
trailer [46974,47009]
===
match
---
simple_stmt [59526,59571]
simple_stmt [59478,59523]
===
match
---
atom_expr [59783,59803]
atom_expr [59735,59755]
===
match
---
name: var [64058,64061]
name: var [64010,64013]
===
match
---
name: all [7859,7862]
name: all [7859,7862]
===
match
---
simple_stmt [66243,66288]
simple_stmt [66195,66240]
===
match
---
annassign [80108,80124]
annassign [80060,80076]
===
match
---
operator: @ [80931,80932]
operator: @ [80883,80884]
===
match
---
string: 'email' [71966,71973]
string: 'email' [71918,71925]
===
match
---
name: pickle_id [15337,15346]
name: pickle_id [15337,15346]
===
match
---
name: airflow [7345,7352]
name: airflow [7345,7352]
===
match
---
name: TR [39190,39192]
name: TR [39190,39192]
===
match
---
suite [42984,43243]
suite [42984,43243]
===
match
---
atom_expr [33871,34026]
atom_expr [33871,34026]
===
match
---
operator: , [14382,14383]
operator: , [14382,14383]
===
match
---
atom_expr [6717,7135]
atom_expr [6717,7135]
===
match
---
operator: , [10431,10432]
operator: , [10431,10432]
===
match
---
simple_stmt [77927,77942]
simple_stmt [77879,77894]
===
match
---
name: ti [26044,26046]
name: ti [26044,26046]
===
match
---
name: default_var [64549,64560]
name: default_var [64501,64512]
===
match
---
name: cfg_path [15459,15467]
name: cfg_path [15459,15467]
===
match
---
atom [20244,20523]
atom [20244,20523]
===
match
---
name: queued_dttm [40407,40418]
name: queued_dttm [40407,40418]
===
match
---
expr_stmt [39168,39247]
expr_stmt [39168,39247]
===
match
---
string: """Handle Failure for the TaskInstance""" [56341,56382]
string: """Handle Failure for the TaskInstance""" [56340,56381]
===
match
---
name: append [5318,5324]
name: append [5318,5324]
===
match
---
expr_stmt [40402,40438]
expr_stmt [40402,40438]
===
match
---
name: total_seconds [72970,72983]
name: total_seconds [72922,72935]
===
match
---
name: hexdigest [34045,34054]
name: hexdigest [34045,34054]
===
match
---
name: context [49565,49572]
name: context [49565,49572]
===
match
---
atom_expr [42942,42953]
atom_expr [42942,42953]
===
match
---
string: """Fetch rendered template fields from DB""" [67227,67271]
string: """Fetch rendered template fields from DB""" [67179,67223]
===
match
---
name: self [41342,41346]
name: self [41342,41346]
===
match
---
operator: , [10797,10798]
operator: , [10797,10798]
===
match
---
suite [58776,59021]
suite [58775,58973]
===
match
---
trailer [20564,20570]
trailer [20564,20570]
===
match
---
name: test_mode [54214,54223]
name: test_mode [54213,54222]
===
match
---
name: drs [7629,7632]
name: drs [7629,7632]
===
match
---
trailer [30192,30222]
trailer [30192,30222]
===
match
---
name: duration [73017,73025]
name: duration [72969,72977]
===
match
---
name: str [41888,41891]
name: str [41888,41891]
===
match
---
trailer [68248,68250]
trailer [68200,68202]
===
match
---
simple_stmt [9451,9483]
simple_stmt [9451,9483]
===
match
---
string: 'Log file: {{ti.log_filepath}}<br>' [70399,70434]
string: 'Log file: {{ti.log_filepath}}<br>' [70351,70386]
===
match
---
expr_stmt [52938,52954]
expr_stmt [52937,52953]
===
match
---
trailer [13322,13334]
trailer [13322,13334]
===
match
---
param [53782,53809]
param [53781,53808]
===
match
---
atom_expr [77585,77828]
atom_expr [77537,77780]
===
match
---
expr_stmt [51685,51728]
expr_stmt [51723,51766]
===
match
---
parameters [81511,81517]
parameters [81463,81469]
===
match
---
name: execution_date [78858,78872]
name: execution_date [78810,78824]
===
match
---
name: job_id [5244,5250]
name: job_id [5244,5250]
===
match
---
trailer [58372,58377]
trailer [58371,58376]
===
match
---
name: on_success_callback [52975,52994]
name: on_success_callback [52974,52993]
===
match
---
suite [41558,41613]
suite [41558,41613]
===
match
---
simple_stmt [62115,62147]
simple_stmt [62067,62099]
===
match
---
simple_stmt [3567,3600]
simple_stmt [3567,3600]
===
match
---
with_stmt [50422,50521]
with_stmt [50460,50559]
===
match
---
name: max [8570,8573]
name: max [8570,8573]
===
match
---
suite [28651,29113]
suite [28651,29113]
===
match
---
operator: , [54233,54234]
operator: , [54232,54233]
===
match
---
name: sqlalchemy [1355,1365]
name: sqlalchemy [1355,1365]
===
match
---
expr_stmt [62221,62277]
expr_stmt [62173,62229]
===
match
---
operator: , [49070,49071]
operator: , [49070,49071]
===
match
---
name: session [28060,28067]
name: session [28060,28067]
===
match
---
arith_expr [13232,13252]
arith_expr [13232,13252]
===
match
---
name: task_id_by_key [6078,6092]
name: task_id_by_key [6078,6092]
===
match
---
arglist [24326,24389]
arglist [24326,24389]
===
match
---
simple_stmt [79586,79638]
simple_stmt [79538,79590]
===
match
---
name: str [79830,79833]
name: str [79782,79785]
===
match
---
name: str [4693,4696]
name: str [4693,4696]
===
match
---
trailer [3973,3996]
trailer [3973,3996]
===
match
---
name: TaskInstance [78890,78902]
name: TaskInstance [78842,78854]
===
match
---
name: VariableAccessor [66047,66063]
name: VariableAccessor [65999,66015]
===
match
---
name: prev_execution_date [65209,65228]
name: prev_execution_date [65161,65180]
===
match
---
trailer [40984,40990]
trailer [40984,40990]
===
match
---
funcdef [45777,48085]
funcdef [45777,48085]
===
match
---
operator: = [19033,19034]
operator: = [19033,19034]
===
match
---
name: end_date [80949,80957]
name: end_date [80901,80909]
===
match
---
name: task_id [8540,8547]
name: task_id [8540,8547]
===
match
---
name: self [68331,68335]
name: self [68283,68287]
===
match
---
expr_stmt [71950,71979]
expr_stmt [71902,71931]
===
match
---
operator: , [55167,55168]
operator: , [55166,55167]
===
match
---
operator: = [54187,54188]
operator: = [54186,54187]
===
match
---
name: ti [7819,7821]
name: ti [7819,7821]
===
match
---
operator: , [58722,58723]
operator: , [58721,58722]
===
match
---
name: execution_date [79135,79149]
name: execution_date [79087,79101]
===
match
---
trailer [11749,11751]
trailer [11749,11751]
===
match
---
string: "%s dependency '%s' PASSED: %s, %s" [32690,32725]
string: "%s dependency '%s' PASSED: %s, %s" [32690,32725]
===
match
---
name: property [12674,12682]
name: property [12674,12682]
===
match
---
atom_expr [59338,59431]
atom_expr [59290,59383]
===
match
---
trailer [24897,24906]
trailer [24897,24906]
===
match
---
operator: = [51552,51553]
operator: = [51590,51591]
===
match
---
name: value [74252,74257]
name: value [74204,74209]
===
match
---
name: Column [9895,9901]
name: Column [9895,9901]
===
match
---
trailer [7241,7251]
trailer [7241,7251]
===
match
---
import_from [1954,2010]
import_from [1954,2010]
===
match
---
atom_expr [78965,79032]
atom_expr [78917,78984]
===
match
---
name: add [55459,55462]
name: add [55458,55461]
===
match
---
atom_expr [5406,5427]
atom_expr [5406,5427]
===
match
---
name: task [50676,50680]
name: task [50714,50718]
===
match
---
name: context [3870,3877]
name: context [3870,3877]
===
match
---
atom_expr [56532,56580]
atom_expr [56531,56579]
===
match
---
name: self [11554,11558]
name: self [11554,11558]
===
match
---
name: staticmethod [77980,77992]
name: staticmethod [77932,77944]
===
match
---
trailer [42652,42657]
trailer [42652,42657]
===
match
---
trailer [12200,12213]
trailer [12200,12213]
===
match
---
trailer [77296,77308]
trailer [77248,77260]
===
match
---
name: ignore_task_deps [39751,39767]
name: ignore_task_deps [39751,39767]
===
match
---
operator: = [22324,22325]
operator: = [22324,22325]
===
match
---
trailer [56540,56550]
trailer [56539,56549]
===
match
---
fstring [19370,19442]
fstring [19370,19442]
===
match
---
atom_expr [12142,12152]
atom_expr [12142,12152]
===
match
---
name: task [48150,48154]
name: task [48150,48154]
===
match
---
name: ds [60664,60666]
name: ds [60616,60618]
===
match
---
name: NamedTuple [1068,1078]
name: NamedTuple [1068,1078]
===
match
---
name: execution_date [6107,6121]
name: execution_date [6107,6121]
===
match
---
name: self [23870,23874]
name: self [23870,23874]
===
match
---
arglist [34802,34834]
arglist [34802,34834]
===
match
---
param [35980,36004]
param [35980,36004]
===
match
---
atom_expr [27283,27351]
atom_expr [27283,27351]
===
match
---
name: session [7649,7656]
name: session [7649,7656]
===
match
---
operator: , [20411,20412]
operator: , [20411,20412]
===
match
---
simple_stmt [22667,22709]
simple_stmt [22667,22709]
===
match
---
string: 'ts' [65855,65859]
string: 'ts' [65807,65811]
===
match
---
name: qry [21846,21849]
name: qry [21846,21849]
===
match
---
trailer [20387,20395]
trailer [20387,20395]
===
match
---
name: datetime [79916,79924]
name: datetime [79868,79876]
===
match
---
trailer [33687,33692]
trailer [33687,33692]
===
match
---
arglist [3771,3910]
arglist [3771,3910]
===
match
---
name: self [64053,64057]
name: self [64005,64009]
===
match
---
trailer [69012,69030]
trailer [68964,68982]
===
match
---
name: self [80875,80879]
name: self [80827,80831]
===
match
---
param [25467,25479]
param [25467,25479]
===
match
---
operator: , [38613,38614]
operator: , [38613,38614]
===
match
---
trailer [6998,7000]
trailer [6998,7000]
===
match
---
name: next_execution_date [61769,61788]
name: next_execution_date [61721,61740]
===
match
---
name: self [80507,80511]
name: self [80459,80463]
===
match
---
trailer [82379,82381]
trailer [82331,82333]
===
match
---
annassign [3258,3278]
annassign [3258,3278]
===
match
---
suite [43381,44026]
suite [43381,44026]
===
match
---
trailer [68813,68835]
trailer [68765,68787]
===
match
---
name: delay [34829,34834]
name: delay [34829,34834]
===
match
---
name: LoggingMixin [2534,2546]
name: LoggingMixin [2534,2546]
===
match
---
atom_expr [57105,57141]
atom_expr [57104,57140]
===
match
---
name: state [9793,9798]
name: state [9793,9798]
===
match
---
operator: , [4330,4331]
operator: , [4330,4331]
===
match
---
name: verbose_aware_logger [31985,32005]
name: verbose_aware_logger [31985,32005]
===
match
---
atom_expr [52398,52419]
atom_expr [52397,52418]
===
match
---
arith_expr [70905,70924]
arith_expr [70857,70876]
===
match
---
trailer [50836,50877]
trailer [50874,50915]
===
match
---
trailer [32607,32635]
trailer [32607,32635]
===
match
---
name: last_dagrun [27791,27802]
name: last_dagrun [27791,27802]
===
match
---
name: task_id [24016,24023]
name: task_id [24016,24023]
===
match
---
fstring_string: &dag_id= [19420,19428]
fstring_string: &dag_id= [19420,19428]
===
match
---
arith_expr [34633,34666]
arith_expr [34633,34666]
===
match
---
name: dag_run [61229,61236]
name: dag_run [61181,61188]
===
match
---
string: 'Airflow alert: {{ti}}' [69565,69588]
string: 'Airflow alert: {{ti}}' [69517,69540]
===
match
---
trailer [47304,47312]
trailer [47304,47312]
===
match
---
operator: = [53766,53767]
operator: = [53765,53766]
===
match
---
name: dump [4688,4692]
name: dump [4688,4692]
===
match
---
atom_expr [43928,43961]
atom_expr [43928,43961]
===
match
---
name: self [48855,48859]
name: self [48855,48859]
===
match
---
name: Column [10173,10179]
name: Column [10173,10179]
===
match
---
name: execution_date [46261,46275]
name: execution_date [46261,46275]
===
match
---
name: get [19315,19318]
name: get [19315,19318]
===
match
---
and_test [30306,30378]
and_test [30306,30378]
===
match
---
name: self [59710,59714]
name: self [59662,59666]
===
match
---
atom_expr [20323,20342]
atom_expr [20323,20342]
===
match
---
name: provide_session [32328,32343]
name: provide_session [32328,32343]
===
match
---
name: default [9868,9875]
name: default [9868,9875]
===
match
---
suite [54376,54691]
suite [54375,54690]
===
match
---
name: execution_date [10685,10699]
name: execution_date [10685,10699]
===
match
---
name: task [65594,65598]
name: task [65546,65550]
===
match
---
name: query [23923,23928]
name: query [23923,23928]
===
match
---
trailer [71821,71838]
trailer [71773,71790]
===
match
---
name: clear_xcom_data [48742,48757]
name: clear_xcom_data [48742,48757]
===
match
---
name: session [77585,77592]
name: session [77537,77544]
===
match
---
trailer [77085,77093]
trailer [77037,77045]
===
match
---
fstring_string: dag. [48787,48791]
fstring_string: dag. [48787,48791]
===
match
---
name: partial_dag [46932,46943]
name: partial_dag [46932,46943]
===
match
---
trailer [77308,77314]
trailer [77260,77266]
===
match
---
name: execution_date [35530,35544]
name: execution_date [35530,35544]
===
match
---
name: self [68698,68702]
name: self [68650,68654]
===
match
---
testlist_comp [77158,77202]
testlist_comp [77110,77154]
===
match
---
import_from [2905,2955]
import_from [2905,2955]
===
match
---
atom_expr [8570,8597]
atom_expr [8570,8597]
===
match
---
expr_stmt [22633,22654]
expr_stmt [22633,22654]
===
match
---
name: ti [80420,80422]
name: ti [80372,80374]
===
match
---
name: self [47897,47901]
name: self [47897,47901]
===
match
---
comparison [78689,78723]
comparison [78641,78675]
===
match
---
operator: = [10171,10172]
operator: = [10171,10172]
===
match
---
trailer [29209,29214]
trailer [29209,29214]
===
match
---
atom_expr [59194,59215]
atom_expr [59146,59167]
===
match
---
expr_stmt [22394,22423]
expr_stmt [22394,22423]
===
match
---
simple_stmt [1874,1909]
simple_stmt [1874,1909]
===
match
---
name: queued_dttm [22766,22777]
name: queued_dttm [22766,22777]
===
match
---
arith_expr [34851,34872]
arith_expr [34851,34872]
===
match
---
name: Optional [53752,53760]
name: Optional [53751,53759]
===
match
---
param [13387,13391]
param [13387,13391]
===
match
---
atom_expr [35523,35544]
atom_expr [35523,35544]
===
match
---
operator: = [4794,4795]
operator: = [4794,4795]
===
match
---
decorator [81561,81578]
decorator [81513,81530]
===
match
---
argument [54247,54260]
argument [54246,54259]
===
match
---
atom_expr [67918,68005]
atom_expr [67870,67957]
===
match
---
funcdef [80767,80841]
funcdef [80719,80793]
===
match
---
name: ti [79332,79334]
name: ti [79284,79286]
===
match
---
trailer [34811,34827]
trailer [34811,34827]
===
match
---
name: execution_date [29701,29715]
name: execution_date [29701,29715]
===
match
---
param [64350,64409]
param [64302,64361]
===
match
---
arglist [32608,32634]
arglist [32608,32634]
===
match
---
trailer [57943,57950]
trailer [57942,57949]
===
match
---
name: _key [81468,81472]
name: _key [81420,81424]
===
match
---
trailer [40462,40468]
trailer [40462,40468]
===
match
---
expr_stmt [22080,22107]
expr_stmt [22080,22107]
===
match
---
name: execution_date [61538,61552]
name: execution_date [61490,61504]
===
match
---
fstring_start: f" [47932,47934]
fstring_start: f" [47932,47934]
===
match
---
atom_expr [7727,7736]
atom_expr [7727,7736]
===
match
---
operator: , [10830,10831]
operator: , [10830,10831]
===
match
---
argument [31903,31926]
argument [31903,31926]
===
match
---
trailer [62268,62277]
trailer [62220,62229]
===
match
---
expr_stmt [27365,27377]
expr_stmt [27365,27377]
===
match
---
simple_stmt [61401,61471]
simple_stmt [61353,61423]
===
match
---
expr_stmt [60763,60835]
expr_stmt [60715,60787]
===
match
---
operator: , [14186,14187]
operator: , [14186,14187]
===
match
---
suite [56822,56873]
suite [56821,56872]
===
match
---
operator: , [49919,49920]
operator: , [49919,49920]
===
match
---
param [14164,14187]
param [14164,14187]
===
match
---
atom_expr [79270,79510]
atom_expr [79222,79462]
===
match
---
trailer [53290,53292]
trailer [53289,53291]
===
match
---
name: pool_override [22967,22980]
name: pool_override [22967,22980]
===
match
---
if_stmt [59741,59804]
if_stmt [59693,59756]
===
match
---
trailer [43630,43638]
trailer [43630,43638]
===
match
---
name: state [2834,2839]
name: state [2834,2839]
===
match
---
operator: = [15079,15080]
operator: = [15079,15080]
===
match
---
operator: < [73964,73965]
operator: < [73916,73917]
===
match
---
name: self [47181,47185]
name: self [47181,47185]
===
match
---
atom_expr [60251,60266]
atom_expr [60203,60218]
===
match
---
import_from [60005,60031]
import_from [59957,59983]
===
match
---
operator: , [32080,32081]
operator: , [32080,32081]
===
match
---
name: timezone [55363,55371]
name: timezone [55362,55370]
===
match
---
expr_stmt [71346,71436]
expr_stmt [71298,71388]
===
match
---
name: ti [82397,82399]
name: ti [82349,82351]
===
match
---
atom_expr [22492,22503]
atom_expr [22492,22503]
===
match
---
name: default_html_content [69754,69774]
name: default_html_content [69706,69726]
===
match
---
name: self [8292,8296]
name: self [8292,8296]
===
match
---
decorator [21015,21032]
decorator [21015,21032]
===
match
---
name: kube_config [68905,68916]
name: kube_config [68857,68868]
===
match
---
name: next_retry_datetime [33104,33123]
name: next_retry_datetime [33104,33123]
===
match
---
name: cmd [18832,18835]
name: cmd [18832,18835]
===
match
---
suite [8899,79511]
suite [8899,79463]
===
match
---
trailer [51493,51495]
trailer [51531,51533]
===
match
---
operator: = [12074,12075]
operator: = [12074,12075]
===
match
---
dotted_name [2448,2469]
dotted_name [2448,2469]
===
match
---
trailer [56536,56540]
trailer [56535,56539]
===
match
---
trailer [58233,58246]
trailer [58232,58245]
===
match
---
operator: , [79104,79105]
operator: , [79056,79057]
===
match
---
decorated [23628,24169]
decorated [23628,24169]
===
match
---
trailer [10210,10224]
trailer [10210,10224]
===
match
---
simple_stmt [11194,11213]
simple_stmt [11194,11213]
===
match
---
trailer [6914,6924]
trailer [6914,6924]
===
match
---
tfpdef [15777,15799]
tfpdef [15777,15799]
===
match
---
name: str [80335,80338]
name: str [80287,80290]
===
match
---
trailer [45715,45724]
trailer [45715,45724]
===
match
---
name: error [54720,54725]
name: error [54719,54724]
===
match
---
name: State [50899,50904]
name: State [50937,50942]
===
match
---
name: dag_id [78358,78364]
name: dag_id [78310,78316]
===
match
---
trailer [19014,19016]
trailer [19014,19016]
===
match
---
name: f [72056,72057]
name: f [72008,72009]
===
match
---
name: contextlib [3316,3326]
name: contextlib [3316,3326]
===
match
---
operator: = [53890,53891]
operator: = [53889,53890]
===
match
---
fstring [56988,57025]
fstring [56987,57024]
===
match
---
expr_stmt [37590,37616]
expr_stmt [37590,37616]
===
match
---
operator: = [60667,60668]
operator: = [60619,60620]
===
match
---
atom_expr [79894,79914]
atom_expr [79846,79866]
===
match
---
atom_expr [30938,30951]
atom_expr [30938,30951]
===
match
---
trailer [62186,62195]
trailer [62138,62147]
===
match
---
name: get_failed_dep_statuses [31879,31902]
name: get_failed_dep_statuses [31879,31902]
===
match
---
atom_expr [74279,74291]
atom_expr [74231,74243]
===
match
---
operator: , [79787,79788]
operator: , [79739,79740]
===
match
---
trailer [62023,62032]
trailer [61975,61984]
===
match
---
trailer [9583,9609]
trailer [9583,9609]
===
match
---
string: 'ds' [64714,64718]
string: 'ds' [64666,64670]
===
match
---
operator: { [70573,70574]
operator: { [70525,70526]
===
match
---
dotted_name [2662,2684]
dotted_name [2662,2684]
===
match
---
name: vals_kv [77158,77165]
name: vals_kv [77110,77117]
===
match
---
name: self [80543,80547]
name: self [80495,80499]
===
match
---
name: Column [9570,9576]
name: Column [9570,9576]
===
match
---
arglist [71966,71978]
arglist [71918,71930]
===
match
---
string: 'ti_pool' [10821,10830]
string: 'ti_pool' [10821,10830]
===
match
---
trailer [60810,60813]
trailer [60762,60765]
===
match
---
simple_stmt [80189,80229]
simple_stmt [80141,80181]
===
match
---
name: task [23477,23481]
name: task [23477,23481]
===
match
---
trailer [47133,47142]
trailer [47133,47142]
===
match
---
trailer [40916,40925]
trailer [40916,40925]
===
match
---
suite [59329,59481]
suite [59281,59433]
===
match
---
trailer [81074,81086]
trailer [81026,81038]
===
match
---
name: provide_session [35625,35640]
name: provide_session [35625,35640]
===
match
---
name: task_id [68584,68591]
name: task_id [68536,68543]
===
match
---
name: String [9577,9583]
name: String [9577,9583]
===
match
---
operator: = [78448,78449]
operator: = [78400,78401]
===
match
---
suite [12129,12161]
suite [12129,12161]
===
match
---
arglist [49915,49928]
arglist [49915,49928]
===
match
---
funcdef [29743,30379]
funcdef [29743,30379]
===
match
---
suite [41184,41410]
suite [41184,41410]
===
match
---
atom_expr [13200,13216]
atom_expr [13200,13216]
===
match
---
not_test [68188,68199]
not_test [68140,68151]
===
match
---
expr_stmt [6017,6038]
expr_stmt [6017,6038]
===
match
---
atom_expr [30359,30377]
atom_expr [30359,30377]
===
match
---
name: macros [64887,64893]
name: macros [64839,64845]
===
match
---
name: bool [53722,53726]
name: bool [53721,53725]
===
match
---
name: self [33028,33032]
name: self [33028,33032]
===
match
---
trailer [49453,49460]
trailer [49453,49460]
===
match
---
strings [70172,70509]
strings [70124,70461]
===
match
---
name: isoformat [19567,19576]
name: isoformat [19567,19576]
===
match
---
name: error [59474,59479]
name: error [59426,59431]
===
match
---
name: TaskInstance [77756,77768]
name: TaskInstance [77708,77720]
===
match
---
simple_stmt [40800,40838]
simple_stmt [40800,40838]
===
match
---
name: execution_date [21774,21788]
name: execution_date [21774,21788]
===
match
---
if_stmt [24875,25080]
if_stmt [24875,25080]
===
match
---
if_stmt [25978,26035]
if_stmt [25978,26035]
===
match
---
funcdef [29139,29717]
funcdef [29139,29717]
===
match
---
name: are_dependencies_met [30983,31003]
name: are_dependencies_met [30983,31003]
===
match
---
trailer [52397,52420]
trailer [52396,52419]
===
match
---
name: self [41526,41530]
name: self [41526,41530]
===
match
---
name: self [51969,51973]
name: self [52007,52011]
===
match
---
operator: , [1095,1096]
operator: , [1095,1096]
===
match
---
expr_stmt [48286,48326]
expr_stmt [48286,48326]
===
match
---
simple_stmt [58317,58355]
simple_stmt [58316,58354]
===
match
---
name: self [55389,55393]
name: self [55388,55392]
===
match
---
name: DepContext [32490,32500]
name: DepContext [32490,32500]
===
match
---
name: pool [54596,54600]
name: pool [54595,54599]
===
match
---
simple_stmt [76956,77121]
simple_stmt [76908,77073]
===
match
---
name: e [44905,44906]
name: e [44905,44906]
===
match
---
trailer [24330,24337]
trailer [24330,24337]
===
match
---
name: ignore_all_deps [18265,18280]
name: ignore_all_deps [18265,18280]
===
match
---
name: refresh_from_db [44471,44486]
name: refresh_from_db [44471,44486]
===
match
---
name: cmd [18543,18546]
name: cmd [18543,18546]
===
match
---
atom_expr [82149,82169]
atom_expr [82101,82121]
===
match
---
string: 'Marking task as SUCCESS. ' [45162,45189]
string: 'Marking task as SUCCESS. ' [45162,45189]
===
match
---
name: extend [18767,18773]
name: extend [18767,18773]
===
match
---
name: _end_date [80009,80018]
name: _end_date [79961,79970]
===
match
---
name: _run_execute_callback [51947,51968]
name: _run_execute_callback [51985,52006]
===
match
---
simple_stmt [9561,9629]
simple_stmt [9561,9629]
===
match
---
atom_expr [45544,45578]
atom_expr [45544,45578]
===
match
---
simple_stmt [54807,54824]
simple_stmt [54806,54823]
===
match
---
name: end_date [22059,22067]
name: end_date [22059,22067]
===
match
---
name: String [1326,1332]
name: String [1326,1332]
===
match
---
operator: = [21091,21092]
operator: = [21091,21092]
===
match
---
trailer [15038,15053]
trailer [15038,15053]
===
match
---
trailer [21667,21674]
trailer [21667,21674]
===
match
---
dotted_name [3024,3070]
dotted_name [3024,3070]
===
match
---
simple_stmt [77950,77974]
simple_stmt [77902,77926]
===
match
---
operator: { [45041,45042]
operator: { [45041,45042]
===
match
---
param [22955,22960]
param [22955,22960]
===
match
---
name: dag [27685,27688]
name: dag [27685,27688]
===
match
---
expr_stmt [60077,60088]
expr_stmt [60029,60040]
===
match
---
operator: = [54869,54870]
operator: = [54868,54869]
===
match
---
name: value [74246,74251]
name: value [74198,74203]
===
match
---
operator: = [46965,46966]
operator: = [46965,46966]
===
match
---
atom_expr [80456,80477]
atom_expr [80408,80429]
===
match
---
atom_expr [26885,26917]
atom_expr [26885,26917]
===
match
---
name: task_id [5419,5426]
name: task_id [5419,5426]
===
match
---
trailer [48820,48828]
trailer [48820,48828]
===
match
---
operator: = [80553,80554]
operator: = [80505,80506]
===
match
---
name: ID_LEN [1861,1867]
name: ID_LEN [1861,1867]
===
match
---
name: date [68693,68697]
name: date [68645,68649]
===
match
---
atom_expr [66550,66587]
atom_expr [66502,66539]
===
match
---
name: default_subject [71198,71213]
name: default_subject [71150,71165]
===
match
---
dotted_name [2115,2138]
dotted_name [2115,2138]
===
match
---
operator: , [30204,30205]
operator: , [30204,30205]
===
match
---
string: """Return Number of running TIs from the DB""" [77475,77521]
string: """Return Number of running TIs from the DB""" [77427,77473]
===
match
---
string: "exception" [53317,53328]
string: "exception" [53316,53327]
===
match
---
trailer [69515,69523]
trailer [69467,69475]
===
match
---
atom_expr [68439,69042]
atom_expr [68391,68994]
===
match
---
trailer [18387,18414]
trailer [18387,18414]
===
match
---
name: self [74279,74283]
name: self [74231,74235]
===
match
---
name: self [34898,34902]
name: self [34898,34902]
===
match
---
operator: , [15476,15477]
operator: , [15476,15477]
===
match
---
name: Environment [71036,71047]
name: Environment [70988,70999]
===
match
---
string: '%s dag_id=%s, task_id=%s, execution_date=%s, start_date=%s, end_date=%s' [58391,58464]
string: '%s dag_id=%s, task_id=%s, execution_date=%s, start_date=%s, end_date=%s' [58390,58463]
===
match
---
trailer [63564,63568]
trailer [63516,63520]
===
match
---
trailer [54462,54690]
trailer [54461,54689]
===
match
---
comparison [6680,6699]
comparison [6680,6699]
===
match
---
operator: , [69528,69529]
operator: , [69480,69481]
===
match
---
operator: = [19308,19309]
operator: = [19308,19309]
===
match
---
suite [18930,19161]
suite [18930,19161]
===
match
---
name: next_ds [61732,61739]
name: next_ds [61684,61691]
===
match
---
operator: , [55186,55187]
operator: , [55185,55186]
===
match
---
atom_expr [21846,21875]
atom_expr [21846,21875]
===
match
---
param [15885,15917]
param [15885,15917]
===
match
---
name: task_id [19412,19419]
name: task_id [19412,19419]
===
match
---
name: models [1922,1928]
name: models [1922,1928]
===
match
---
simple_stmt [13193,13217]
simple_stmt [13193,13217]
===
match
---
name: self [44466,44470]
name: self [44466,44470]
===
match
---
operator: = [54667,54668]
operator: = [54666,54667]
===
match
---
name: DagRun [7708,7714]
name: DagRun [7708,7714]
===
match
---
trailer [82086,82262]
trailer [82038,82214]
===
match
---
dotted_name [2858,2879]
dotted_name [2858,2879]
===
match
---
name: _safe_date [58559,58569]
name: _safe_date [58558,58568]
===
match
---
suite [27774,27855]
suite [27774,27855]
===
match
---
trailer [37645,37684]
trailer [37645,37684]
===
match
---
suite [50227,50378]
suite [50265,50416]
===
match
---
operator: , [58540,58541]
operator: , [58539,58540]
===
match
---
name: str [69501,69504]
name: str [69453,69456]
===
match
---
name: pre_execute [49545,49556]
name: pre_execute [49545,49556]
===
match
---
trailer [30640,30645]
trailer [30640,30645]
===
match
---
name: iso [19393,19396]
name: iso [19393,19396]
===
match
---
simple_stmt [2443,2490]
simple_stmt [2443,2490]
===
match
---
name: ignore_all_deps [53995,54010]
name: ignore_all_deps [53994,54009]
===
match
---
string: '%Y%m%dT%H%M%S' [58588,58603]
string: '%Y%m%dT%H%M%S' [58587,58602]
===
match
---
operator: , [7088,7089]
operator: , [7088,7089]
===
match
---
argument [15388,15395]
argument [15388,15395]
===
match
---
param [53711,53735]
param [53710,53734]
===
match
---
parameters [23668,23688]
parameters [23668,23688]
===
match
---
name: Exception [52409,52418]
name: Exception [52408,52417]
===
match
---
name: session [57182,57189]
name: session [57181,57188]
===
match
---
trailer [78345,78348]
trailer [78297,78300]
===
match
---
fstring_string: = [49366,49367]
fstring_string: = [49366,49367]
===
match
---
name: attr [41532,41536]
name: attr [41532,41536]
===
match
---
trailer [51634,51636]
trailer [51672,51674]
===
match
---
operator: * [33715,33716]
operator: * [33715,33716]
===
match
---
trailer [34017,34026]
trailer [34017,34026]
===
match
---
simple_stmt [25952,25969]
simple_stmt [25952,25969]
===
match
---
param [22961,22966]
param [22961,22966]
===
match
---
name: schedulable_ti [47430,47444]
name: schedulable_ti [47430,47444]
===
match
---
name: TaskInstance [82200,82212]
name: TaskInstance [82152,82164]
===
match
---
expr_stmt [47246,47339]
expr_stmt [47246,47339]
===
match
---
trailer [19607,19632]
trailer [19607,19632]
===
match
---
funcdef [71854,72143]
funcdef [71806,72095]
===
match
---
atom_expr [22761,22777]
atom_expr [22761,22777]
===
match
---
operator: = [22450,22451]
operator: = [22450,22451]
===
match
---
atom_expr [74033,74179]
atom_expr [73985,74131]
===
match
---
operator: = [48884,48885]
operator: = [48884,48885]
===
match
---
operator: = [45107,45108]
operator: = [45107,45108]
===
match
---
atom [72936,72969]
atom [72888,72921]
===
match
---
trailer [41280,41285]
trailer [41280,41285]
===
match
---
arith_expr [5592,5624]
arith_expr [5592,5624]
===
match
---
operator: { [65972,65973]
operator: { [65924,65925]
===
match
---
fstring_string: ti.finish. [45002,45012]
fstring_string: ti.finish. [45002,45012]
===
match
---
argument [76597,76614]
argument [76549,76566]
===
match
---
name: next_try_number [13922,13937]
name: next_try_number [13922,13937]
===
match
---
simple_stmt [4681,4709]
simple_stmt [4681,4709]
===
match
---
name: state [20625,20630]
name: state [20625,20630]
===
match
---
import_from [2750,2814]
import_from [2750,2814]
===
match
---
string: """Filepath for TaskInstance""" [18939,18970]
string: """Filepath for TaskInstance""" [18939,18970]
===
match
---
operator: -> [29262,29264]
operator: -> [29262,29264]
===
match
---
operator: , [4757,4758]
operator: , [4757,4758]
===
match
---
expr_stmt [5076,5088]
expr_stmt [5076,5088]
===
match
---
name: ts [60718,60720]
name: ts [60670,60672]
===
match
---
atom_expr [3285,3312]
atom_expr [3285,3312]
===
match
---
dotted_name [67285,67316]
dotted_name [67237,67268]
===
match
---
name: TaskInstance [82066,82078]
name: TaskInstance [82018,82030]
===
match
---
trailer [43234,43242]
trailer [43234,43242]
===
match
---
name: kubernetes [2974,2984]
name: kubernetes [2974,2984]
===
match
---
operator: != [3718,3720]
operator: != [3718,3720]
===
match
---
operator: == [6790,6792]
operator: == [6790,6792]
===
match
---
atom_expr [5130,5167]
atom_expr [5130,5167]
===
match
---
trailer [60512,60518]
trailer [60464,60470]
===
match
---
simple_stmt [57182,57263]
simple_stmt [57181,57262]
===
match
---
funcdef [66195,67181]
funcdef [66147,67133]
===
match
---
decorated [81561,82400]
decorated [81513,82352]
===
match
---
name: get_previous_ti [29076,29091]
name: get_previous_ti [29076,29091]
===
match
---
return_stmt [13225,13252]
return_stmt [13225,13252]
===
match
---
name: start_date [24822,24832]
name: start_date [24822,24832]
===
match
---
name: task_copy [48286,48295]
name: task_copy [48286,48295]
===
match
---
name: os [4061,4063]
name: os [4061,4063]
===
match
---
arglist [21533,21575]
arglist [21533,21575]
===
match
---
atom_expr [77158,77178]
atom_expr [77110,77130]
===
match
---
name: force_fail [59392,59402]
name: force_fail [59344,59354]
===
match
---
name: airflow [2495,2502]
name: airflow [2495,2502]
===
match
---
suite [3997,4276]
suite [3997,4276]
===
match
---
dotted_name [2755,2779]
dotted_name [2755,2779]
===
match
---
param [78016,78069]
param [77968,78021]
===
match
---
testlist_comp [18156,18182]
testlist_comp [18156,18182]
===
match
---
operator: = [43623,43624]
operator: = [43623,43624]
===
match
---
atom_expr [7104,7117]
atom_expr [7104,7117]
===
match
---
name: refresh_from_db [44294,44309]
name: refresh_from_db [44294,44309]
===
match
---
simple_stmt [55347,55381]
simple_stmt [55346,55380]
===
match
---
name: hasattr [41478,41485]
name: hasattr [41478,41485]
===
match
---
trailer [21007,21009]
trailer [21007,21009]
===
match
---
name: self [58364,58368]
name: self [58363,58367]
===
match
---
name: State [37827,37832]
name: State [37827,37832]
===
match
---
name: key [74229,74232]
name: key [74181,74184]
===
match
---
atom_expr [80734,80747]
atom_expr [80686,80699]
===
match
---
name: actual_start_date [55169,55186]
name: actual_start_date [55168,55185]
===
match
---
parameters [8623,8646]
parameters [8623,8646]
===
match
---
trailer [14952,14969]
trailer [14952,14969]
===
match
---
operator: != [14726,14728]
operator: != [14726,14728]
===
match
---
name: ti_hash [33806,33813]
name: ti_hash [33806,33813]
===
match
---
name: run_id [60564,60570]
name: run_id [60516,60522]
===
match
---
decorated [28579,29113]
decorated [28579,29113]
===
match
---
trailer [77165,77169]
trailer [77117,77121]
===
match
---
operator: = [44786,44787]
operator: = [44786,44787]
===
match
---
name: FileSystemLoader [71079,71095]
name: FileSystemLoader [71031,71047]
===
match
---
expr_stmt [61279,61320]
expr_stmt [61231,61272]
===
match
---
param [56186,56219]
param [56185,56218]
===
match
---
name: self [45816,45820]
name: self [45816,45820]
===
match
---
expr_stmt [82304,82338]
expr_stmt [82256,82290]
===
match
---
trailer [64133,64137]
trailer [64085,64089]
===
match
---
operator: = [50807,50808]
operator: = [50845,50846]
===
match
---
name: self [19913,19917]
name: self [19913,19917]
===
match
---
simple_stmt [46094,46361]
simple_stmt [46094,46361]
===
match
---
name: yesterday_ds [66110,66122]
name: yesterday_ds [66062,66074]
===
match
---
operator: = [59422,59423]
operator: = [59374,59375]
===
match
---
atom_expr [9740,9759]
atom_expr [9740,9759]
===
match
---
name: render [71310,71316]
name: render [71262,71268]
===
match
---
trailer [19042,19053]
trailer [19042,19053]
===
match
---
name: state [50891,50896]
name: state [50929,50934]
===
match
---
param [80705,80709]
param [80657,80661]
===
match
---
simple_stmt [79894,79945]
simple_stmt [79846,79897]
===
match
---
string: """         Returns whether a task is in UP_FOR_RETRY state and its retry interval         has elapsed.         """ [25159,25274]
string: """         Returns whether a task is in UP_FOR_RETRY state and its retry interval         has elapsed.         """ [25159,25274]
===
match
---
name: setter [13270,13276]
name: setter [13270,13276]
===
match
---
operator: , [66065,66066]
operator: , [66017,66018]
===
match
---
expr_stmt [14598,14617]
expr_stmt [14598,14617]
===
match
---
operator: = [59402,59403]
operator: = [59354,59355]
===
match
---
simple_stmt [19498,19527]
simple_stmt [19498,19527]
===
match
---
trailer [4162,4168]
trailer [4162,4168]
===
match
---
name: KubeConfig [3004,3014]
name: KubeConfig [3004,3014]
===
match
---
trailer [6095,6102]
trailer [6095,6102]
===
match
---
testlist_comp [66743,66781]
testlist_comp [66695,66733]
===
match
---
if_stmt [27969,28069]
if_stmt [27969,28069]
===
match
---
operator: , [19619,19620]
operator: , [19619,19620]
===
match
---
return_stmt [77216,77243]
return_stmt [77168,77195]
===
match
---
operator: , [62562,62563]
operator: , [62514,62515]
===
match
---
name: bool [15972,15976]
name: bool [15972,15976]
===
match
---
name: task [54994,54998]
name: task [54993,54997]
===
match
---
operator: = [34614,34615]
operator: = [34614,34615]
===
match
---
atom_expr [47625,47706]
atom_expr [47625,47706]
===
match
---
atom_expr [82052,82262]
atom_expr [82004,82214]
===
match
---
trailer [28301,28535]
trailer [28301,28535]
===
match
---
name: ignore_all_deps [39639,39654]
name: ignore_all_deps [39639,39654]
===
match
---
name: dag_run [47571,47578]
name: dag_run [47571,47578]
===
match
---
trailer [50904,50912]
trailer [50942,50950]
===
match
---
name: replace [62321,62328]
name: replace [62273,62280]
===
match
---
suite [62597,62682]
suite [62549,62634]
===
match
---
operator: , [15243,15244]
operator: , [15243,15244]
===
match
---
name: session [55985,55992]
name: session [55984,55991]
===
match
---
name: max_retry_delay [34812,34827]
name: max_retry_delay [34812,34827]
===
match
---
trailer [26377,26380]
trailer [26377,26380]
===
match
---
string: 'next_execution_date' [64985,65006]
string: 'next_execution_date' [64937,64958]
===
match
---
comparison [47302,47338]
comparison [47302,47338]
===
match
---
trailer [34660,34662]
trailer [34660,34662]
===
match
---
expr_stmt [8131,8146]
expr_stmt [8131,8146]
===
match
---
param [59679,59682]
param [59631,59634]
===
match
---
name: reconstructor [12489,12502]
name: reconstructor [12489,12502]
===
match
---
trailer [31837,31841]
trailer [31837,31841]
===
match
---
trailer [45439,45454]
trailer [45439,45454]
===
match
---
dotted_name [45752,45772]
dotted_name [45752,45772]
===
match
---
name: math [842,846]
name: math [842,846]
===
match
---
simple_stmt [26392,26438]
simple_stmt [26392,26438]
===
match
---
simple_stmt [41946,42633]
simple_stmt [41946,42633]
===
match
---
name: session [25088,25095]
name: session [25088,25095]
===
match
---
name: outlets [65057,65064]
name: outlets [65009,65016]
===
match
---
name: AirflowTaskTimeout [1791,1809]
name: AirflowTaskTimeout [1791,1809]
===
match
---
suite [47782,48085]
suite [47782,48085]
===
match
---
trailer [58682,58693]
trailer [58681,58692]
===
match
---
name: external_executor_id [10388,10408]
name: external_executor_id [10388,10408]
===
match
---
trailer [6141,6153]
trailer [6141,6153]
===
match
---
operator: == [82228,82230]
operator: == [82180,82182]
===
match
---
trailer [66585,66587]
trailer [66537,66539]
===
match
---
name: generate_command [15515,15531]
name: generate_command [15515,15531]
===
match
---
operator: , [50695,50696]
operator: , [50733,50734]
===
match
---
atom_expr [46918,46929]
atom_expr [46918,46929]
===
match
---
name: XCOM_RETURN_KEY [51885,51900]
name: XCOM_RETURN_KEY [51923,51938]
===
match
---
operator: = [29215,29216]
operator: = [29215,29216]
===
match
---
name: queue [22638,22643]
name: queue [22638,22643]
===
match
---
trailer [41238,41243]
trailer [41238,41243]
===
match
---
operator: = [28059,28060]
operator: = [28059,28060]
===
match
---
name: default [10092,10099]
name: default [10092,10099]
===
match
---
atom_expr [12460,12474]
atom_expr [12460,12474]
===
match
---
trailer [62544,62555]
trailer [62496,62507]
===
match
---
string: 'end_date' [58694,58704]
string: 'end_date' [58693,58703]
===
match
---
operator: = [35195,35196]
operator: = [35195,35196]
===
match
---
trailer [28816,28821]
trailer [28816,28821]
===
match
---
import_name [820,834]
import_name [820,834]
===
match
---
name: self [33042,33046]
name: self [33042,33046]
===
match
---
name: exception [71585,71594]
name: exception [71537,71546]
===
match
---
name: merge [55965,55970]
name: merge [55964,55969]
===
match
---
suite [5349,6069]
suite [5349,6069]
===
match
---
operator: = [39817,39818]
operator: = [39817,39818]
===
match
---
arglist [11588,11702]
arglist [11588,11702]
===
match
---
name: bool [35883,35887]
name: bool [35883,35887]
===
match
---
suite [36115,41430]
suite [36115,41430]
===
match
---
name: dag_run [68032,68039]
name: dag_run [67984,67991]
===
match
---
name: str [41846,41849]
name: str [41846,41849]
===
match
---
operator: = [41516,41517]
operator: = [41516,41517]
===
match
---
name: commit [40499,40505]
name: commit [40499,40505]
===
match
---
atom_expr [21518,21576]
atom_expr [21518,21576]
===
match
---
fstring_expr [19406,19420]
fstring_expr [19406,19420]
===
match
---
name: local [15856,15861]
name: local [15856,15861]
===
match
---
fstring_expr [47981,47994]
fstring_expr [47981,47994]
===
match
---
name: next_ds_nodash [61715,61729]
name: next_ds_nodash [61667,61681]
===
match
---
name: jinja_env [71017,71026]
name: jinja_env [70969,70978]
===
match
---
if_stmt [7516,7981]
if_stmt [7516,7981]
===
match
---
name: skippable_task_ids [47036,47054]
name: skippable_task_ids [47036,47054]
===
match
---
simple_stmt [17945,17978]
simple_stmt [17945,17978]
===
match
---
trailer [43892,43910]
trailer [43892,43910]
===
match
---
simple_stmt [77891,77919]
simple_stmt [77843,77871]
===
match
---
name: ignore_ti_state [39802,39817]
name: ignore_ti_state [39802,39817]
===
match
---
number: 1 [55946,55947]
number: 1 [55945,55946]
===
match
---
name: f [72019,72020]
name: f [71971,71972]
===
match
---
arglist [72244,72289]
arglist [72196,72241]
===
match
---
import_from [937,977]
import_from [937,977]
===
match
---
parameters [13295,13308]
parameters [13295,13308]
===
match
---
trailer [50177,50195]
trailer [50032,50233]
===
match
---
trailer [11357,11362]
trailer [11357,11362]
===
match
---
arglist [28315,28525]
arglist [28315,28525]
===
match
---
name: log_url [19184,19191]
name: log_url [19184,19191]
===
match
---
operator: = [74705,74706]
operator: = [74657,74658]
===
match
---
operator: , [11122,11123]
operator: , [11122,11123]
===
match
---
name: context [3721,3728]
name: context [3721,3728]
===
match
---
expr_stmt [41511,41537]
expr_stmt [41511,41537]
===
match
---
trailer [7656,7662]
trailer [7656,7662]
===
match
---
string: "XCom data cleared" [24148,24167]
string: "XCom data cleared" [24148,24167]
===
match
---
name: key [74225,74228]
name: key [74177,74180]
===
match
---
trailer [78910,78914]
trailer [78862,78866]
===
match
---
and_test [37765,37840]
and_test [37765,37840]
===
match
---
operator: = [60149,60150]
operator: = [60101,60102]
===
match
---
name: _handle_reschedule [55144,55162]
name: _handle_reschedule [55143,55161]
===
match
---
trailer [32545,32550]
trailer [32545,32550]
===
match
---
atom_expr [60778,60835]
atom_expr [60730,60787]
===
match
---
trailer [74374,74389]
trailer [74326,74341]
===
match
---
suite [26010,26035]
suite [26010,26035]
===
match
---
argument [49226,49248]
argument [49226,49248]
===
match
---
atom_expr [40812,40836]
atom_expr [40812,40836]
===
match
---
string: """         Get the very latest state from the database, if a session is passed,         we use and looking up the state becomes part of the session, otherwise         a new session is used.          :param session: SQLAlchemy ORM Session         :type session: Session         """ [19949,20230]
string: """         Get the very latest state from the database, if a session is passed,         we use and looking up the state becomes part of the session, otherwise         a new session is used.          :param session: SQLAlchemy ORM Session         :type session: Session         """ [19949,20230]
===
match
---
param [14196,14225]
param [14196,14225]
===
match
---
name: job_id [14329,14335]
name: job_id [14329,14335]
===
match
---
simple_stmt [61652,61703]
simple_stmt [61604,61655]
===
match
---
trailer [23959,23966]
trailer [23959,23966]
===
match
---
suite [11752,11846]
suite [11752,11846]
===
match
---
name: dep_context [38574,38585]
name: dep_context [38574,38585]
===
match
---
name: self [14604,14608]
name: self [14604,14608]
===
match
---
name: set [5162,5165]
name: set [5162,5165]
===
match
---
param [73179,73190]
param [73131,73142]
===
match
---
trailer [35066,35079]
trailer [35066,35079]
===
match
---
simple_stmt [2815,2853]
simple_stmt [2815,2853]
===
match
---
name: dag_run [67992,67999]
name: dag_run [67944,67951]
===
match
---
operator: , [46881,46882]
operator: , [46881,46882]
===
match
---
name: property [81093,81101]
name: property [81045,81053]
===
match
---
simple_stmt [59060,59080]
simple_stmt [59012,59032]
===
match
---
subscriptlist [59200,59214]
subscriptlist [59152,59166]
===
match
---
name: PodGenerator [68439,68451]
name: PodGenerator [68391,68403]
===
match
---
name: and_ [79053,79057]
name: and_ [79005,79009]
===
match
---
simple_stmt [78358,78380]
simple_stmt [78310,78332]
===
match
---
and_test [35047,35130]
and_test [35047,35130]
===
match
---
name: is_eligible_to_retry [59490,59510]
name: is_eligible_to_retry [59442,59462]
===
match
---
operator: = [56288,56289]
operator: = [56287,56288]
===
match
---
comp_op [52722,52728]
comp_op [52721,52727]
===
match
---
name: state [40851,40856]
name: state [40851,40856]
===
match
---
name: dag_id [21668,21674]
name: dag_id [21668,21674]
===
match
---
simple_stmt [59776,59804]
simple_stmt [59728,59756]
===
match
---
fstring_end: " [49370,49371]
fstring_end: " [49370,49371]
===
match
---
trailer [37726,37735]
trailer [37726,37735]
===
match
---
parameters [80631,80637]
parameters [80583,80589]
===
match
---
trailer [7795,7830]
trailer [7795,7830]
===
match
---
argument [65355,65374]
argument [65307,65326]
===
match
---
name: TemplateAssertionError [1221,1243]
name: TemplateAssertionError [1221,1243]
===
match
---
name: airflow [1914,1921]
name: airflow [1914,1921]
===
match
---
name: defaultdict [5130,5141]
name: defaultdict [5130,5141]
===
match
---
expr_stmt [10229,10262]
expr_stmt [10229,10262]
===
match
---
name: task_id_by_key [6162,6176]
name: task_id_by_key [6162,6176]
===
match
---
name: add [57113,57116]
name: add [57112,57115]
===
match
---
expr_stmt [9987,10011]
expr_stmt [9987,10011]
===
match
---
operator: = [22644,22645]
operator: = [22644,22645]
===
match
---
trailer [29700,29715]
trailer [29700,29715]
===
match
---
name: task [46667,46671]
name: task [46667,46671]
===
match
---
name: self [28125,28129]
name: self [28125,28129]
===
match
---
trailer [20271,20285]
trailer [20271,20285]
===
match
---
simple_stmt [77134,77204]
simple_stmt [77086,77156]
===
match
---
trailer [71111,71121]
trailer [71063,71073]
===
match
---
param [25144,25148]
param [25144,25148]
===
match
---
expr_stmt [39558,39848]
expr_stmt [39558,39848]
===
match
---
name: email [72672,72677]
name: email [72624,72629]
===
match
---
arglist [59358,59430]
arglist [59310,59382]
===
match
---
if_stmt [21927,22869]
if_stmt [21927,22869]
===
match
---
trailer [65290,65296]
trailer [65242,65248]
===
match
---
name: session [40999,41006]
name: session [40999,41006]
===
match
---
parameters [68071,68112]
parameters [68023,68064]
===
match
---
simple_stmt [38676,38693]
simple_stmt [38676,38693]
===
match
---
name: verbose [41176,41183]
name: verbose [41176,41183]
===
match
---
name: ti_key_str [62405,62415]
name: ti_key_str [62357,62367]
===
match
---
trailer [60435,60495]
trailer [60387,60447]
===
match
---
name: test_mode [55210,55219]
name: test_mode [55209,55218]
===
match
---
name: lock_for_update [43578,43593]
name: lock_for_update [43578,43593]
===
match
---
param [36013,36042]
param [36013,36042]
===
match
---
suite [71879,72143]
suite [71831,72095]
===
match
---
name: Exception [4186,4195]
name: Exception [4186,4195]
===
match
---
name: self [50823,50827]
name: self [50861,50865]
===
match
---
name: dag_id [23960,23966]
name: dag_id [23960,23966]
===
match
---
name: get_num_running_task_instances [77420,77450]
name: get_num_running_task_instances [77372,77402]
===
match
---
name: task_id [78917,78924]
name: task_id [78869,78876]
===
match
---
atom_expr [67992,68004]
atom_expr [67944,67956]
===
match
---
trailer [54784,54794]
trailer [54783,54793]
===
match
---
argument [39802,39833]
argument [39802,39833]
===
match
---
atom_expr [30172,30222]
atom_expr [30172,30222]
===
match
---
suite [77337,77390]
suite [77289,77342]
===
match
---
string: """     Clears a set of task instances, but makes sure the running ones     get killed.      :param tis: a list of task instances     :param session: current session     :param activate_dag_runs: flag to check for active dag run     :param dag: DAG object     """ [4808,5071]
string: """     Clears a set of task instances, but makes sure the running ones     get killed.      :param tis: a list of task instances     :param session: current session     :param activate_dag_runs: flag to check for active dag run     :param dag: DAG object     """ [4808,5071]
===
match
---
trailer [43561,43577]
trailer [43561,43577]
===
match
---
expr_stmt [12142,12160]
expr_stmt [12142,12160]
===
match
---
name: TaskInstance [82651,82663]
name: TaskInstance [82603,82615]
===
match
---
atom_expr [40402,40418]
atom_expr [40402,40418]
===
match
---
name: self [53178,53182]
name: self [53177,53181]
===
match
---
operator: = [39926,39927]
operator: = [39926,39927]
===
match
---
arglist [67933,68004]
arglist [67885,67956]
===
match
---
name: incr [37860,37864]
name: incr [37860,37864]
===
match
---
argument [15409,15422]
argument [15409,15422]
===
match
---
name: context [51174,51181]
name: context [51212,51219]
===
match
---
operator: -> [74753,74755]
operator: -> [74705,74707]
===
match
---
name: dagrun [82577,82583]
name: dagrun [82529,82535]
===
match
---
string: """         Set TaskInstance state.          :param state: State to set for the TI         :type state: str         :param session: SQLAlchemy ORM Session         :type session: Session         """ [24472,24669]
string: """         Set TaskInstance state.          :param state: State to set for the TI         :type state: str         :param session: SQLAlchemy ORM Session         :type session: Session         """ [24472,24669]
===
match
---
operator: , [67990,67991]
operator: , [67942,67943]
===
match
---
if_stmt [67877,68046]
if_stmt [67829,67998]
===
match
---
name: end_date [72942,72950]
name: end_date [72894,72902]
===
match
---
trailer [60783,60798]
trailer [60735,60750]
===
match
---
name: self [13200,13204]
name: self [13200,13204]
===
match
---
trailer [35529,35544]
trailer [35529,35544]
===
match
---
name: self [25144,25148]
name: self [25144,25148]
===
match
---
operator: == [52636,52638]
operator: == [52635,52637]
===
match
---
name: self [55031,55035]
name: self [55030,55034]
===
match
---
trailer [80137,80154]
trailer [80089,80106]
===
match
---
fstring_expr [48791,48809]
fstring_expr [48791,48809]
===
match
---
atom_expr [29693,29715]
atom_expr [29693,29715]
===
match
---
name: first_task_id [78434,78447]
name: first_task_id [78386,78399]
===
match
---
tfpdef [78016,78069]
tfpdef [77968,78021]
===
match
---
trailer [24357,24372]
trailer [24357,24372]
===
match
---
name: self [33080,33084]
name: self [33080,33084]
===
match
---
name: str [64194,64197]
name: str [64146,64149]
===
match
---
if_stmt [41197,41410]
if_stmt [41197,41410]
===
match
---
operator: , [50508,50509]
operator: , [50546,50547]
===
match
---
param [59873,59878]
param [59825,59830]
===
match
---
expr_stmt [80280,80314]
expr_stmt [80232,80266]
===
match
---
trailer [49556,49573]
trailer [49556,49573]
===
match
---
atom_expr [80116,80124]
atom_expr [80068,80076]
===
match
---
operator: , [78809,78810]
operator: , [78761,78762]
===
match
---
simple_stmt [71017,71154]
simple_stmt [70969,71106]
===
match
---
name: attr [41460,41464]
name: attr [41460,41464]
===
match
---
tfpdef [29815,29831]
tfpdef [29815,29831]
===
match
---
name: render_templates [55067,55083]
name: render_templates [55066,55082]
===
match
---
import_from [2657,2699]
import_from [2657,2699]
===
match
---
annassign [79969,79995]
annassign [79921,79947]
===
match
---
string: 'webserver' [19608,19619]
string: 'webserver' [19608,19619]
===
match
---
operator: @ [81092,81093]
operator: @ [81044,81045]
===
match
---
name: Dict [1046,1050]
name: Dict [1046,1050]
===
match
---
fstring_expr [49363,49366]
fstring_expr [49363,49366]
===
match
---
trailer [24137,24141]
trailer [24137,24141]
===
match
---
operator: , [2350,2351]
operator: , [2350,2351]
===
match
---
trailer [40807,40811]
trailer [40807,40811]
===
match
---
atom_expr [22411,22423]
atom_expr [22411,22423]
===
match
---
operator: = [23561,23562]
operator: = [23561,23562]
===
match
---
argument [39919,39934]
argument [39919,39934]
===
match
---
operator: , [40278,40279]
operator: , [40278,40279]
===
match
---
name: execution_date [11525,11539]
name: execution_date [11525,11539]
===
match
---
expr_stmt [72046,72064]
expr_stmt [71998,72016]
===
match
---
trailer [64807,64828]
trailer [64759,64780]
===
match
---
operator: , [54642,54643]
operator: , [54641,54642]
===
match
---
name: params [60213,60219]
name: params [60165,60171]
===
match
---
name: State [57938,57943]
name: State [57937,57942]
===
match
---
atom_expr [26117,26136]
atom_expr [26117,26136]
===
match
---
name: str [4309,4312]
name: str [4309,4312]
===
match
---
name: error [53332,53337]
name: error [53331,53336]
===
match
---
suite [72021,72065]
suite [71973,72017]
===
match
---
string: 'yesterday_ds_nodash' [66136,66157]
string: 'yesterday_ds_nodash' [66088,66109]
===
match
---
name: DagRun [7663,7669]
name: DagRun [7663,7669]
===
match
---
suite [48435,48609]
suite [48435,48609]
===
match
---
fstring_string: &execution_date= [19774,19790]
fstring_string: &execution_date= [19774,19790]
===
match
---
name: self [12169,12173]
name: self [12169,12173]
===
match
---
atom_expr [62308,62337]
atom_expr [62260,62289]
===
match
---
simple_stmt [3216,3241]
simple_stmt [3216,3241]
===
match
---
atom [18554,18565]
atom [18554,18565]
===
match
---
name: signal_handler [48648,48662]
name: signal_handler [48648,48662]
===
match
---
suite [67905,68046]
suite [67857,67998]
===
match
---
name: dag [27136,27139]
name: dag [27136,27139]
===
match
---
atom_expr [40816,40829]
atom_expr [40816,40829]
===
match
---
operator: , [57207,57208]
operator: , [57206,57207]
===
match
---
argument [60436,60458]
argument [60388,60410]
===
match
---
trailer [76486,76707]
trailer [76438,76659]
===
match
---
comparison [20375,20411]
comparison [20375,20411]
===
match
---
name: task [58765,58769]
name: task [58764,58768]
===
match
---
string: "task_instance" [9467,9482]
string: "task_instance" [9467,9482]
===
match
---
string: 'task_instance_key_str' [65647,65670]
string: 'task_instance_key_str' [65599,65622]
===
match
---
expr_stmt [25014,25079]
expr_stmt [25014,25079]
===
match
---
operator: = [42891,42892]
operator: = [42891,42892]
===
match
---
name: task_id [15013,15020]
name: task_id [15013,15020]
===
match
---
string: 'json' [65990,65996]
string: 'json' [65942,65948]
===
match
---
operator: = [52943,52944]
operator: = [52942,52943]
===
match
---
funcdef [64247,64597]
funcdef [64199,64549]
===
match
---
name: bool [59279,59283]
name: bool [59231,59235]
===
match
---
atom_expr [39113,39123]
atom_expr [39113,39123]
===
match
---
atom_expr [53892,54323]
atom_expr [53891,54322]
===
match
---
operator: , [18856,18857]
operator: , [18856,18857]
===
match
---
name: self [33930,33934]
name: self [33930,33934]
===
match
---
name: args [43506,43510]
name: args [43506,43510]
===
match
---
name: fd [3947,3949]
name: fd [3947,3949]
===
match
---
operator: = [61730,61731]
operator: = [61682,61683]
===
match
---
operator: , [48391,48392]
operator: , [48391,48392]
===
match
---
name: prev_ti [29587,29594]
name: prev_ti [29587,29594]
===
match
---
name: subject [72396,72403]
name: subject [72348,72355]
===
match
---
operator: } [19396,19397]
operator: } [19396,19397]
===
match
---
name: self [41378,41382]
name: self [41378,41382]
===
match
---
simple_stmt [54982,55023]
simple_stmt [54981,55022]
===
match
---
atom_expr [40421,40438]
atom_expr [40421,40438]
===
match
---
operator: { [19121,19122]
operator: { [19121,19122]
===
match
---
operator: - [38266,38267]
operator: - [38266,38267]
===
match
---
operator: -> [41929,41931]
operator: -> [41929,41931]
===
match
---
name: and_ [1334,1338]
name: and_ [1334,1338]
===
match
---
name: provide_session [73104,73119]
name: provide_session [73056,73071]
===
match
---
atom_expr [24924,24942]
atom_expr [24924,24942]
===
match
---
atom_expr [22721,22734]
atom_expr [22721,22734]
===
match
---
name: session [46328,46335]
name: session [46328,46335]
===
match
---
string: 'Host: {{ti.hostname}}<br>' [70359,70386]
string: 'Host: {{ti.hostname}}<br>' [70311,70338]
===
match
---
name: task_copy [55094,55103]
name: task_copy [55093,55102]
===
match
---
operator: , [77791,77792]
operator: , [77743,77744]
===
match
---
name: AirflowFailException [44250,44270]
name: AirflowFailException [44250,44270]
===
match
---
decorated [35624,41430]
decorated [35624,41430]
===
match
---
atom_expr [68792,68835]
atom_expr [68744,68787]
===
match
---
expr_stmt [61715,61756]
expr_stmt [61667,61708]
===
match
---
simple_stmt [51866,51916]
simple_stmt [51904,51954]
===
match
---
simple_stmt [2110,2171]
simple_stmt [2110,2171]
===
match
---
fstring_string: /log?execution_date= [19372,19392]
fstring_string: /log?execution_date= [19372,19392]
===
match
---
name: Optional [15937,15945]
name: Optional [15937,15945]
===
match
---
fstring_start: f" [33010,33012]
fstring_start: f" [33010,33012]
===
match
---
name: result [76984,76990]
name: result [76936,76942]
===
match
---
simple_stmt [31958,31972]
simple_stmt [31958,31972]
===
match
---
atom_expr [56977,57032]
atom_expr [56976,57031]
===
match
---
name: airflow [82517,82524]
name: airflow [82469,82476]
===
match
---
operator: = [72582,72583]
operator: = [72534,72535]
===
match
---
trailer [32924,32931]
trailer [32924,32931]
===
match
---
trailer [46354,46358]
trailer [46354,46358]
===
match
---
trailer [26305,26311]
trailer [26305,26311]
===
match
---
name: self [61355,61359]
name: self [61307,61311]
===
match
---
atom_expr [54444,54690]
atom_expr [54443,54689]
===
match
---
atom_expr [45093,45106]
atom_expr [45093,45106]
===
match
---
argument [65508,65527]
argument [65460,65479]
===
match
---
trailer [40436,40438]
trailer [40436,40438]
===
match
---
name: Exception [58853,58862]
name: Exception [58852,58861]
===
match
---
name: prev_execution_date [61401,61420]
name: prev_execution_date [61353,61372]
===
match
---
name: dagrun [35377,35383]
name: dagrun [35377,35383]
===
match
---
trailer [74283,74291]
trailer [74235,74243]
===
match
---
funcdef [48366,48609]
funcdef [48366,48609]
===
match
---
simple_stmt [12058,12078]
simple_stmt [12058,12078]
===
match
---
name: session [30206,30213]
name: session [30206,30213]
===
match
---
name: TaskInstanceKey [79616,79631]
name: TaskInstanceKey [79568,79583]
===
match
---
name: context [68213,68220]
name: context [68165,68172]
===
match
---
name: file_path [18740,18749]
name: file_path [18740,18749]
===
match
---
name: error_file [56262,56272]
name: error_file [56261,56271]
===
match
---
name: test_mode [54533,54542]
name: test_mode [54532,54541]
===
match
---
atom_expr [45560,45570]
atom_expr [45560,45570]
===
match
---
atom_expr [7921,7934]
atom_expr [7921,7934]
===
match
---
operator: = [72164,72165]
operator: = [72116,72117]
===
match
---
name: provide_session [29723,29738]
name: provide_session [29723,29738]
===
match
---
trailer [55378,55380]
trailer [55377,55379]
===
match
---
param [51975,51992]
param [52013,52030]
===
match
---
import_from [82512,82552]
import_from [82464,82504]
===
match
---
atom_expr [80526,80534]
atom_expr [80478,80486]
===
match
---
param [53481,53502]
param [53480,53501]
===
match
---
name: self [11118,11122]
name: self [11118,11122]
===
match
---
atom_expr [32120,32139]
atom_expr [32120,32139]
===
match
---
operator: -= [55943,55945]
operator: -= [55942,55944]
===
match
---
atom [33723,33744]
atom [33723,33744]
===
match
---
param [15622,15647]
param [15622,15647]
===
match
---
name: Context [51984,51991]
name: Context [52022,52029]
===
match
---
name: tomorrow_ds_nodash [62346,62364]
name: tomorrow_ds_nodash [62298,62316]
===
match
---
atom_expr [42666,42680]
atom_expr [42666,42680]
===
match
---
atom_expr [40455,40474]
atom_expr [40455,40474]
===
match
---
param [15656,15683]
param [15656,15683]
===
match
---
string: 'prev_ds' [65108,65117]
string: 'prev_ds' [65060,65069]
===
match
---
name: str [8094,8097]
name: str [8094,8097]
===
match
---
operator: , [23673,23674]
operator: , [23673,23674]
===
match
---
string: "--local" [18609,18618]
string: "--local" [18609,18618]
===
match
---
string: 'execution_date is {}; received {})' [74099,74135]
string: 'execution_date is {}; received {})' [74051,74087]
===
match
---
trailer [80193,80206]
trailer [80145,80158]
===
match
---
name: self [11255,11259]
name: self [11255,11259]
===
match
---
name: task_id [77715,77722]
name: task_id [77667,77674]
===
match
---
operator: == [6885,6887]
operator: == [6885,6887]
===
match
---
trailer [26056,26062]
trailer [26056,26062]
===
match
---
operator: = [27300,27301]
operator: = [27300,27301]
===
match
---
number: 1 [14017,14018]
number: 1 [14017,14018]
===
match
---
annassign [79828,79845]
annassign [79780,79797]
===
match
---
simple_stmt [24719,24782]
simple_stmt [24719,24782]
===
match
---
arglist [72751,72793]
arglist [72703,72745]
===
match
---
param [41460,41464]
param [41460,41464]
===
match
---
suite [72831,73098]
suite [72783,73050]
===
match
---
trailer [20350,20357]
trailer [20350,20357]
===
match
---
fstring_string: / [19120,19121]
fstring_string: / [19120,19121]
===
match
---
suite [69232,72436]
suite [69184,72388]
===
match
---
name: task_ids [74543,74551]
name: task_ids [74495,74503]
===
match
---
string: 'task_instance' [65612,65627]
string: 'task_instance' [65564,65579]
===
match
---
name: session [27838,27845]
name: session [27838,27845]
===
match
---
atom_expr [9801,9819]
atom_expr [9801,9819]
===
match
---
operator: , [8813,8814]
operator: , [8813,8814]
===
match
---
name: tis [7541,7544]
name: tis [7541,7544]
===
match
---
name: dict [68349,68353]
name: dict [68301,68305]
===
match
---
atom [77571,77838]
atom [77523,77790]
===
match
---
comparison [78666,78684]
comparison [78618,78636]
===
match
---
parameters [64163,64169]
parameters [64115,64121]
===
match
---
trailer [7415,7424]
trailer [7415,7424]
===
match
---
name: ds_nodash [62452,62461]
name: ds_nodash [62404,62413]
===
match
---
name: self [22040,22044]
name: self [22040,22044]
===
match
---
name: execution_date [79424,79438]
name: execution_date [79376,79390]
===
match
---
parameters [77864,77881]
parameters [77816,77833]
===
match
---
operator: = [69775,69776]
operator: = [69727,69728]
===
match
---
name: _date_or_empty [41439,41453]
name: _date_or_empty [41439,41453]
===
match
---
string: '' [12185,12187]
string: '' [12185,12187]
===
match
---
simple_stmt [45620,45637]
simple_stmt [45620,45637]
===
match
---
name: delete [24091,24097]
name: delete [24091,24097]
===
match
---
if_stmt [37762,37895]
if_stmt [37762,37895]
===
match
---
simple_stmt [66605,66652]
simple_stmt [66557,66604]
===
match
---
name: verbose [53950,53957]
name: verbose [53949,53956]
===
match
---
string: 'priority_weight' [80424,80441]
string: 'priority_weight' [80376,80393]
===
match
---
name: self [24196,24200]
name: self [24196,24200]
===
match
---
trailer [62320,62328]
trailer [62272,62280]
===
match
---
name: session [47010,47017]
name: session [47010,47017]
===
match
---
name: self [15034,15038]
name: self [15034,15038]
===
match
---
trailer [33921,33928]
trailer [33921,33928]
===
match
---
atom_expr [60167,60187]
atom_expr [60119,60139]
===
match
---
if_stmt [18575,18621]
if_stmt [18575,18621]
===
match
---
expr_stmt [76956,77120]
expr_stmt [76908,77072]
===
match
---
operator: == [23967,23969]
operator: == [23967,23969]
===
match
---
name: self [22955,22959]
name: self [22955,22959]
===
match
---
operator: , [73151,73152]
operator: , [73103,73104]
===
match
---
simple_stmt [23540,23584]
simple_stmt [23540,23584]
===
match
---
simple_stmt [10583,10905]
simple_stmt [10583,10905]
===
match
---
trailer [24794,24800]
trailer [24794,24800]
===
match
---
operator: = [11233,11234]
operator: = [11233,11234]
===
match
---
name: try_number [24379,24389]
name: try_number [24379,24389]
===
match
---
operator: , [9590,9591]
operator: , [9590,9591]
===
match
---
operator: = [67515,67516]
operator: = [67467,67468]
===
match
---
expr_stmt [40739,40760]
expr_stmt [40739,40760]
===
match
---
string: '<br>' [69530,69536]
string: '<br>' [69482,69488]
===
match
---
name: session [20673,20680]
name: session [20673,20680]
===
match
---
dictorsetmaker [76984,77106]
dictorsetmaker [76936,77058]
===
match
---
name: self [43612,43616]
name: self [43612,43616]
===
match
---
return_stmt [64606,66189]
return_stmt [64558,66141]
===
match
---
name: iso [19246,19249]
name: iso [19246,19249]
===
match
---
trailer [44309,44311]
trailer [44309,44311]
===
match
---
param [35865,35896]
param [35865,35896]
===
match
---
dotted_name [1355,1369]
dotted_name [1355,1369]
===
match
---
suite [54343,54363]
suite [54342,54362]
===
match
---
name: mark_success [54493,54505]
name: mark_success [54492,54504]
===
match
---
name: self [73966,73970]
name: self [73918,73922]
===
match
---
trailer [15904,15909]
trailer [15904,15909]
===
match
---
trailer [68621,68632]
trailer [68573,68584]
===
match
---
return_stmt [77564,77838]
return_stmt [77516,77790]
===
match
---
argument [30193,30204]
argument [30193,30204]
===
match
---
operator: = [15714,15715]
operator: = [15714,15715]
===
match
---
name: session [38615,38622]
name: session [38615,38622]
===
match
---
trailer [65354,65375]
trailer [65306,65327]
===
match
---
name: previous_scheduled_date [27110,27133]
name: previous_scheduled_date [27110,27133]
===
match
---
name: self [23358,23362]
name: self [23358,23362]
===
match
---
comparison [77756,77791]
comparison [77708,77743]
===
match
---
name: self [62167,62171]
name: self [62119,62123]
===
match
---
atom_expr [6104,6121]
atom_expr [6104,6121]
===
match
---
parameters [12701,12707]
parameters [12701,12707]
===
match
---
name: self [35084,35088]
name: self [35084,35088]
===
match
---
name: ti [6104,6106]
name: ti [6104,6106]
===
match
---
name: merge [59068,59073]
name: merge [59020,59025]
===
match
---
name: test_mode [44765,44774]
name: test_mode [44765,44774]
===
match
---
name: state [77769,77774]
name: state [77721,77726]
===
match
---
trailer [6720,7135]
trailer [6720,7135]
===
match
---
atom [66742,66782]
atom [66694,66734]
===
match
---
string: '' [62257,62259]
string: '' [62209,62211]
===
match
---
simple_stmt [8085,8098]
simple_stmt [8085,8098]
===
match
---
atom_expr [52098,52122]
atom_expr [52136,52160]
===
match
---
name: t [78689,78690]
name: t [78641,78642]
===
match
---
atom_expr [9775,9788]
atom_expr [9775,9788]
===
match
---
try_stmt [67476,67715]
try_stmt [67428,67667]
===
match
---
name: Column [10350,10356]
name: Column [10350,10356]
===
match
---
simple_stmt [66296,66367]
simple_stmt [66248,66319]
===
match
---
atom_expr [18763,18798]
atom_expr [18763,18798]
===
match
---
name: warning [40363,40370]
name: warning [40363,40370]
===
match
---
suite [56598,56643]
suite [56597,56642]
===
match
---
simple_stmt [61769,61830]
simple_stmt [61721,61782]
===
match
---
trailer [43577,43599]
trailer [43577,43599]
===
match
---
atom_expr [55031,55040]
atom_expr [55030,55039]
===
match
---
name: task [54957,54961]
name: task [54956,54960]
===
match
---
trailer [80302,80314]
trailer [80254,80266]
===
match
---
name: max_tries [9883,9892]
name: max_tries [9883,9892]
===
match
---
operator: = [56245,56246]
operator: = [56244,56245]
===
match
---
atom_expr [57884,57911]
atom_expr [57883,57910]
===
match
---
name: task [11124,11128]
name: task [11124,11128]
===
match
---
name: e [44870,44871]
name: e [44870,44871]
===
match
---
operator: , [44917,44918]
operator: , [44917,44918]
===
match
---
name: force_fail [59403,59413]
name: force_fail [59355,59365]
===
match
---
simple_stmt [7484,7511]
simple_stmt [7484,7511]
===
match
---
operator: } [62461,62462]
operator: } [62413,62414]
===
match
---
trailer [23427,23449]
trailer [23427,23449]
===
match
---
trailer [40585,40590]
trailer [40585,40590]
===
match
---
atom_expr [52805,52825]
atom_expr [52804,52824]
===
match
---
operator: @ [20636,20637]
operator: @ [20636,20637]
===
match
---
return_stmt [63173,63188]
return_stmt [63125,63140]
===
match
---
name: TaskInstance [79122,79134]
name: TaskInstance [79074,79086]
===
match
---
trailer [32167,32174]
trailer [32167,32174]
===
match
---
operator: , [15020,15021]
operator: , [15020,15021]
===
match
---
decorated [24174,24391]
decorated [24174,24391]
===
match
---
dotted_name [1497,1520]
dotted_name [1497,1520]
===
match
---
trailer [23523,23531]
trailer [23523,23531]
===
match
---
name: try_number [68606,68616]
name: try_number [68558,68568]
===
match
---
trailer [71816,71821]
trailer [71768,71773]
===
match
---
name: self [45435,45439]
name: self [45435,45439]
===
match
---
string: "&downstream=false" [19839,19858]
string: "&downstream=false" [19839,19858]
===
match
---
name: timedelta [60801,60810]
name: timedelta [60753,60762]
===
match
---
suite [49844,49930]
suite [49844,49930]
===
match
---
name: task [5511,5515]
name: task [5511,5515]
===
match
---
string: "TaskInstance" [78036,78050]
string: "TaskInstance" [77988,78002]
===
match
---
tfpdef [15967,15976]
tfpdef [15967,15976]
===
match
---
atom_expr [8549,8568]
atom_expr [8549,8568]
===
match
---
fstring_expr [19790,19795]
fstring_expr [19790,19795]
===
match
---
name: email [58770,58775]
name: email [58769,58774]
===
match
---
expr_stmt [54720,54794]
expr_stmt [54719,54793]
===
match
---
name: SimpleTaskInstance [79646,79664]
name: SimpleTaskInstance [79598,79616]
===
match
---
trailer [24147,24168]
trailer [24147,24168]
===
match
---
atom_expr [34688,34731]
atom_expr [34688,34731]
===
match
---
name: bool [35843,35847]
name: bool [35843,35847]
===
match
---
name: dep [32515,32518]
name: dep [32515,32518]
===
match
---
simple_stmt [79670,79765]
simple_stmt [79622,79717]
===
match
---
trailer [82127,82135]
trailer [82079,82087]
===
match
---
atom_expr [72237,72290]
atom_expr [72189,72242]
===
match
---
name: timezone [2391,2399]
name: timezone [2391,2399]
===
match
---
name: state [52630,52635]
name: state [52629,52634]
===
match
---
trailer [9901,9910]
trailer [9901,9910]
===
match
---
if_stmt [40941,40991]
if_stmt [40941,40991]
===
match
---
name: warn [30641,30645]
name: warn [30641,30645]
===
match
---
simple_stmt [47897,48050]
simple_stmt [47897,48050]
===
match
---
operator: = [14295,14296]
operator: = [14295,14296]
===
match
---
operator: = [12032,12033]
operator: = [12032,12033]
===
match
---
name: COLLATION_ARGS [1845,1859]
name: COLLATION_ARGS [1845,1859]
===
match
---
name: send_email [2432,2442]
name: send_email [2432,2442]
===
match
---
operator: , [8533,8534]
operator: , [8533,8534]
===
match
---
name: first [21911,21916]
name: first [21911,21916]
===
match
---
atom_expr [6142,6152]
atom_expr [6142,6152]
===
match
---
operator: , [37661,37662]
operator: , [37661,37662]
===
match
---
funcdef [13281,13343]
funcdef [13281,13343]
===
match
---
return_stmt [13875,13898]
return_stmt [13875,13898]
===
match
---
trailer [10749,10805]
trailer [10749,10805]
===
match
---
name: self [59662,59666]
name: self [59614,59618]
===
match
---
name: state [27949,27954]
name: state [27949,27954]
===
match
---
operator: , [53586,53587]
operator: , [53585,53586]
===
match
---
comparison [27730,27749]
comparison [27730,27749]
===
match
---
operator: = [29638,29639]
operator: = [29638,29639]
===
match
---
atom_expr [81273,81286]
atom_expr [81225,81238]
===
match
---
trailer [26062,26096]
trailer [26062,26096]
===
match
---
trailer [80101,80108]
trailer [80053,80060]
===
match
---
expr_stmt [27110,27178]
expr_stmt [27110,27178]
===
match
---
trailer [25035,25044]
trailer [25035,25044]
===
match
---
annassign [80154,80180]
annassign [80106,80132]
===
match
---
suite [81129,81157]
suite [81081,81109]
===
match
---
operator: , [72352,72353]
operator: , [72304,72305]
===
match
---
operator: = [48968,48969]
operator: = [48968,48969]
===
match
---
operator: = [72054,72055]
operator: = [72006,72007]
===
match
---
trailer [59073,59079]
trailer [59025,59031]
===
match
---
return_stmt [32310,32321]
return_stmt [32310,32321]
===
match
---
trailer [44125,44127]
trailer [44125,44127]
===
match
---
operator: , [59203,59204]
operator: , [59155,59156]
===
match
---
expr_stmt [9915,9946]
expr_stmt [9915,9946]
===
match
---
name: html_content [72551,72563]
name: html_content [72503,72515]
===
match
---
string: """Fetch rendered template fields from DB""" [66243,66287]
string: """Fetch rendered template fields from DB""" [66195,66239]
===
match
---
name: dep_context [32522,32533]
name: dep_context [32522,32533]
===
match
---
string: "run" [18013,18018]
string: "run" [18013,18018]
===
match
---
name: default_subject [72193,72208]
name: default_subject [72145,72160]
===
match
---
name: execution_date [41394,41408]
name: execution_date [41394,41408]
===
match
---
atom_expr [63138,63156]
atom_expr [63090,63108]
===
match
---
name: PickleType [1314,1324]
name: PickleType [1314,1324]
===
match
---
expr_stmt [19299,19343]
expr_stmt [19299,19343]
===
match
---
name: task_id [77183,77190]
name: task_id [77135,77142]
===
match
---
atom_expr [11963,12002]
atom_expr [11963,12002]
===
match
---
name: dag_id [11039,11045]
name: dag_id [11039,11045]
===
match
---
string: "\n" [37991,37995]
string: "\n" [37991,37995]
===
match
---
name: queued_dttm [22783,22794]
name: queued_dttm [22783,22794]
===
match
---
import_from [2547,2589]
import_from [2547,2589]
===
match
---
atom_expr [68657,68679]
atom_expr [68609,68631]
===
match
---
name: log [31838,31841]
name: log [31838,31841]
===
match
---
operator: , [64281,64282]
operator: , [64233,64234]
===
match
---
name: query_for_task_instance [39193,39216]
name: query_for_task_instance [39193,39216]
===
match
---
simple_stmt [5533,5561]
simple_stmt [5533,5561]
===
match
---
param [41867,41900]
param [41867,41900]
===
match
---
name: self [25461,25465]
name: self [25461,25465]
===
match
---
name: task_id [19141,19148]
name: task_id [19141,19148]
===
match
---
name: RenderedTaskInstanceFields [49012,49038]
name: RenderedTaskInstanceFields [49012,49038]
===
match
---
suite [4228,4276]
suite [4228,4276]
===
match
---
string: '\n' [69524,69528]
string: '\n' [69476,69480]
===
match
---
name: airflow [2016,2023]
name: airflow [2016,2023]
===
match
---
atom_expr [39127,39150]
atom_expr [39127,39150]
===
match
---
trailer [43220,43226]
trailer [43220,43226]
===
match
---
comparison [51834,51852]
comparison [51872,51890]
===
match
---
name: self [34747,34751]
name: self [34747,34751]
===
match
---
name: try_number [13285,13295]
name: try_number [13285,13295]
===
match
---
atom_expr [20375,20395]
atom_expr [20375,20395]
===
match
---
name: items [6993,6998]
name: items [6993,6998]
===
match
---
atom_expr [15937,15950]
atom_expr [15937,15950]
===
match
---
trailer [61690,61702]
trailer [61642,61654]
===
match
---
name: join [49355,49359]
name: join [49355,49359]
===
match
---
name: jinja_env [72088,72097]
name: jinja_env [72040,72049]
===
match
---
argument [71317,71332]
argument [71269,71284]
===
match
---
name: Optional [52389,52397]
name: Optional [52388,52396]
===
match
---
operator: ** [9520,9522]
operator: ** [9520,9522]
===
match
---
atom_expr [33080,33090]
atom_expr [33080,33090]
===
match
---
name: context_to_airflow_vars [49193,49216]
name: context_to_airflow_vars [49193,49216]
===
match
---
name: session [27934,27941]
name: session [27934,27941]
===
match
---
trailer [40894,40901]
trailer [40894,40901]
===
match
---
operator: , [41458,41459]
operator: , [41458,41459]
===
match
---
name: session [30214,30221]
name: session [30214,30221]
===
match
---
name: debug [31842,31847]
name: debug [31842,31847]
===
match
---
simple_stmt [1909,1954]
simple_stmt [1909,1954]
===
match
---
operator: , [64863,64864]
operator: , [64815,64816]
===
match
---
name: XCom [2105,2109]
name: XCom [2105,2109]
===
match
---
expr_stmt [77134,77203]
expr_stmt [77086,77155]
===
match
---
operator: = [74739,74740]
operator: = [74691,74692]
===
match
---
trailer [82431,82461]
trailer [82383,82413]
===
match
---
trailer [80343,80348]
trailer [80295,80300]
===
match
---
name: info [43313,43317]
name: info [43313,43317]
===
match
---
expr_stmt [11769,11845]
expr_stmt [11769,11845]
===
match
---
operator: , [14255,14256]
operator: , [14255,14256]
===
match
---
expr_stmt [42873,42910]
expr_stmt [42873,42910]
===
match
---
string: 'tomorrow_ds' [65761,65774]
string: 'tomorrow_ds' [65713,65726]
===
match
---
simple_stmt [21902,21919]
simple_stmt [21902,21919]
===
match
---
atom_expr [14708,14725]
atom_expr [14708,14725]
===
match
---
name: ti [21902,21904]
name: ti [21902,21904]
===
match
---
name: RenderedTaskInstanceFields [67324,67350]
name: RenderedTaskInstanceFields [67276,67302]
===
match
---
operator: = [31049,31050]
operator: = [31049,31050]
===
match
---
name: int [8143,8146]
name: int [8143,8146]
===
match
---
suite [66788,67181]
suite [66740,67133]
===
match
---
name: Any [63414,63417]
name: Any [63366,63369]
===
match
---
name: state [29092,29097]
name: state [29092,29097]
===
match
---
fstring_expr [62435,62449]
fstring_expr [62387,62401]
===
match
---
name: state [29194,29199]
name: state [29194,29199]
===
match
---
operator: , [57025,57026]
operator: , [57024,57025]
===
match
---
trailer [23596,23605]
trailer [23596,23605]
===
match
---
name: Optional [16038,16046]
name: Optional [16038,16046]
===
match
---
name: extend [18836,18842]
name: extend [18836,18842]
===
match
---
param [81616,81629]
param [81568,81581]
===
match
---
name: ignore_ti_state [53636,53651]
name: ignore_ti_state [53635,53650]
===
match
---
trailer [62328,62337]
trailer [62280,62289]
===
match
---
name: start_date [30367,30377]
name: start_date [30367,30377]
===
match
---
name: session [54668,54675]
name: session [54667,54674]
===
match
---
name: queued_by_job [82664,82677]
name: queued_by_job [82616,82629]
===
match
---
trailer [23878,23884]
trailer [23878,23884]
===
match
---
number: 1 [22619,22620]
number: 1 [22619,22620]
===
match
---
trailer [50163,50167]
trailer [50020,50024]
===
match
---
name: execution_date [62172,62186]
name: execution_date [62124,62138]
===
match
---
dotted_name [60285,60306]
dotted_name [60237,60258]
===
match
---
atom_expr [72651,72701]
atom_expr [72603,72653]
===
match
---
name: info [58373,58377]
name: info [58372,58376]
===
match
---
if_stmt [56391,56452]
if_stmt [56390,56451]
===
match
---
trailer [6064,6068]
trailer [6064,6068]
===
match
---
expr_stmt [24817,24866]
expr_stmt [24817,24866]
===
match
---
name: datetime [8203,8211]
name: datetime [8203,8211]
===
match
---
param [71870,71877]
param [71822,71829]
===
match
---
operator: == [24057,24059]
operator: == [24057,24059]
===
match
---
trailer [35121,35128]
trailer [35121,35128]
===
match
---
string: 'next_ds_nodash' [64939,64955]
string: 'next_ds_nodash' [64891,64907]
===
match
---
operator: , [8196,8197]
operator: , [8196,8197]
===
match
---
atom_expr [6982,7000]
atom_expr [6982,7000]
===
match
---
trailer [57126,57133]
trailer [57125,57132]
===
match
---
name: is_eligible_to_retry [57889,57909]
name: is_eligible_to_retry [57888,57908]
===
match
---
simple_stmt [8131,8147]
simple_stmt [8131,8147]
===
match
---
operator: , [56634,56635]
operator: , [56633,56634]
===
match
---
atom_expr [40577,40605]
atom_expr [40577,40605]
===
match
---
trailer [43181,43203]
trailer [43181,43203]
===
match
---
name: task_id [33935,33942]
name: task_id [33935,33942]
===
match
---
name: self [23502,23506]
name: self [23502,23506]
===
match
---
suite [71929,72065]
suite [71881,72017]
===
match
---
name: self [19258,19262]
name: self [19258,19262]
===
match
---
name: self [59173,59177]
name: self [59125,59129]
===
match
---
operator: , [66765,66766]
operator: , [66717,66718]
===
match
---
trailer [50827,50831]
trailer [50865,50869]
===
match
---
name: property [81013,81021]
name: property [80965,80973]
===
match
---
trailer [14969,15487]
trailer [14969,15487]
===
match
---
name: _run_mini_scheduler_on_child_tasks [45781,45815]
name: _run_mini_scheduler_on_child_tasks [45781,45815]
===
match
---
trailer [63248,63258]
trailer [63200,63210]
===
match
---
name: render_k8s_pod_yaml [68311,68330]
name: render_k8s_pod_yaml [68263,68282]
===
match
---
name: task_copy [51377,51386]
name: task_copy [51415,51424]
===
match
---
name: self [12608,12612]
name: self [12608,12612]
===
match
---
name: raw [77871,77874]
name: raw [77823,77826]
===
match
---
suite [34904,35131]
suite [34904,35131]
===
match
---
param [35944,35971]
param [35944,35971]
===
match
---
name: self [40912,40916]
name: self [40912,40916]
===
match
---
param [16032,16059]
param [16032,16059]
===
match
---
param [24449,24461]
param [24449,24461]
===
match
---
simple_stmt [8499,8599]
simple_stmt [8499,8599]
===
match
---
trailer [56619,56623]
trailer [56618,56622]
===
match
---
simple_stmt [60041,60068]
simple_stmt [59993,60020]
===
match
---
atom_expr [53309,53329]
atom_expr [53308,53328]
===
match
---
name: pickle_id [18121,18130]
name: pickle_id [18121,18130]
===
match
---
parameters [81115,81121]
parameters [81067,81073]
===
match
---
trailer [33934,33942]
trailer [33934,33942]
===
match
---
operator: = [82368,82369]
operator: = [82320,82321]
===
match
---
atom_expr [68736,68758]
atom_expr [68688,68710]
===
match
---
if_stmt [53200,53386]
if_stmt [53199,53385]
===
match
---
name: dep [32587,32590]
name: dep [32587,32590]
===
match
---
simple_stmt [44140,44216]
simple_stmt [44140,44216]
===
match
---
atom_expr [27365,27371]
atom_expr [27365,27371]
===
match
---
trailer [74316,74323]
trailer [74268,74275]
===
match
---
atom_expr [30903,30952]
atom_expr [30903,30952]
===
match
---
atom_expr [20944,20956]
atom_expr [20944,20956]
===
match
---
name: TaskInstance [81656,81668]
name: TaskInstance [81608,81620]
===
match
---
name: prev_execution_date [61279,61298]
name: prev_execution_date [61231,61250]
===
match
---
atom_expr [79359,79379]
atom_expr [79311,79331]
===
match
---
atom_expr [10815,10861]
atom_expr [10815,10861]
===
match
---
operator: = [38639,38640]
operator: = [38639,38640]
===
match
---
operator: = [52759,52760]
operator: = [52758,52759]
===
match
---
name: cfg_path [16068,16076]
name: cfg_path [16068,16076]
===
match
---
param [13296,13301]
param [13296,13301]
===
match
---
expr_stmt [5533,5560]
expr_stmt [5533,5560]
===
match
---
atom_expr [77361,77389]
atom_expr [77313,77341]
===
match
---
operator: , [10630,10631]
operator: , [10630,10631]
===
match
---
name: UtcDateTime [2787,2798]
name: UtcDateTime [2787,2798]
===
match
---
operator: , [64572,64573]
operator: , [64524,64525]
===
match
---
operator: = [10375,10376]
operator: = [10375,10376]
===
match
---
atom_expr [77081,77093]
atom_expr [77033,77045]
===
match
---
return_stmt [4120,4131]
return_stmt [4120,4131]
===
match
---
name: session [54297,54304]
name: session [54296,54303]
===
match
---
name: init_on_load [12201,12213]
name: init_on_load [12201,12213]
===
match
---
simple_stmt [41575,41613]
simple_stmt [41575,41613]
===
match
---
atom_expr [80097,80108]
atom_expr [80049,80060]
===
match
---
tfpdef [35780,35801]
tfpdef [35780,35801]
===
match
---
operator: = [43593,43594]
operator: = [43593,43594]
===
match
---
if_stmt [67438,67715]
if_stmt [67390,67667]
===
match
---
simple_stmt [37533,37582]
simple_stmt [37533,37582]
===
match
---
operator: { [47981,47982]
operator: { [47981,47982]
===
match
---
try_stmt [2896,3195]
try_stmt [2896,3195]
===
match
---
name: job [82525,82528]
name: job [82477,82480]
===
match
---
trailer [80460,80477]
trailer [80412,80429]
===
match
---
name: delay_backoff_in_seconds [34589,34613]
name: delay_backoff_in_seconds [34589,34613]
===
match
---
trailer [41006,41013]
trailer [41006,41013]
===
match
---
name: _task_id [80739,80747]
name: _task_id [80691,80699]
===
match
---
atom_expr [10204,10224]
atom_expr [10204,10224]
===
match
---
atom_expr [26049,26358]
atom_expr [26049,26358]
===
match
---
name: with_row_locks [46104,46118]
name: with_row_locks [46104,46118]
===
match
---
decorator [25416,25433]
decorator [25416,25433]
===
match
---
operator: , [79341,79342]
operator: , [79293,79294]
===
match
---
expr_stmt [57925,57950]
expr_stmt [57924,57949]
===
match
---
name: task [48298,48302]
name: task [48298,48302]
===
match
---
simple_stmt [59440,59481]
simple_stmt [59392,59433]
===
match
---
name: self [23311,23315]
name: self [23311,23315]
===
match
---
trailer [50680,50690]
trailer [50718,50728]
===
match
---
trailer [44293,44309]
trailer [44293,44309]
===
match
---
suite [8213,8339]
suite [8213,8339]
===
match
---
operator: , [79459,79460]
operator: , [79411,79412]
===
match
---
trailer [22058,22067]
trailer [22058,22067]
===
match
---
expr_stmt [60121,60132]
expr_stmt [60073,60084]
===
match
---
suite [47454,47548]
suite [47454,47548]
===
match
---
trailer [34619,34667]
trailer [34619,34667]
===
match
---
atom_expr [50921,50936]
atom_expr [50959,50974]
===
match
---
operator: , [21074,21075]
operator: , [21074,21075]
===
match
---
operator: = [49243,49244]
operator: = [49243,49244]
===
match
---
trailer [9746,9759]
trailer [9746,9759]
===
match
---
trailer [26380,26383]
trailer [26380,26383]
===
match
---
name: ti [47265,47267]
name: ti [47265,47267]
===
match
---
trailer [13236,13248]
trailer [13236,13248]
===
match
---
operator: , [11128,11129]
operator: , [11128,11129]
===
match
---
operator: -> [56324,56326]
operator: -> [56323,56325]
===
match
---
name: task_id [20388,20395]
name: task_id [20388,20395]
===
match
---
simple_stmt [72542,72626]
simple_stmt [72494,72578]
===
match
---
atom_expr [13166,13179]
atom_expr [13166,13179]
===
match
---
expr_stmt [9764,9788]
expr_stmt [9764,9788]
===
match
---
param [56228,56253]
param [56227,56252]
===
match
---
if_stmt [80409,80499]
if_stmt [80361,80451]
===
match
---
name: force_fail [57966,57976]
name: force_fail [57965,57975]
===
match
---
name: task [72756,72760]
name: task [72708,72712]
===
match
---
operator: , [65027,65028]
operator: , [64979,64980]
===
match
---
name: self [40702,40706]
name: self [40702,40706]
===
match
---
name: drs [7893,7896]
name: drs [7893,7896]
===
match
---
trailer [72760,72766]
trailer [72712,72718]
===
match
---
trailer [80528,80534]
trailer [80480,80486]
===
match
---
param [63085,63095]
param [63037,63047]
===
match
---
name: DateTime [29283,29291]
name: DateTime [29283,29291]
===
match
---
simple_stmt [72740,72795]
simple_stmt [72692,72747]
===
match
---
name: task [53078,53082]
name: task [53077,53081]
===
match
---
trailer [26177,26185]
trailer [26177,26185]
===
match
---
param [29180,29185]
param [29180,29185]
===
match
---
name: command_as_list [14028,14043]
name: command_as_list [14028,14043]
===
match
---
name: self [45286,45290]
name: self [45286,45290]
===
match
---
name: Column [9801,9807]
name: Column [9801,9807]
===
match
---
simple_stmt [7340,7382]
simple_stmt [7340,7382]
===
match
---
parameters [28616,28622]
parameters [28616,28622]
===
match
---
name: kubernetes_helper_functions [3043,3070]
name: kubernetes_helper_functions [3043,3070]
===
match
---
operator: , [76534,76535]
operator: , [76486,76487]
===
match
---
name: task_ids [77194,77202]
name: task_ids [77146,77154]
===
match
---
name: item [63323,63327]
name: item [63275,63279]
===
match
---
name: signal_handler [48370,48384]
name: signal_handler [48370,48384]
===
match
---
name: ti [22602,22604]
name: ti [22602,22604]
===
match
---
expr_stmt [80133,80180]
expr_stmt [80085,80132]
===
match
---
name: bool [36110,36114]
name: bool [36110,36114]
===
match
---
name: get [19604,19607]
name: get [19604,19607]
===
match
---
name: verbose [35750,35757]
name: verbose [35750,35757]
===
match
---
name: with_for_update [82313,82328]
name: with_for_update [82265,82280]
===
match
---
name: jinja_context [71464,71477]
name: jinja_context [71416,71429]
===
match
---
param [41710,41715]
param [41710,41715]
===
match
---
name: self [80992,80996]
name: self [80944,80948]
===
match
---
name: getLogger [3293,3302]
name: getLogger [3293,3302]
===
match
---
name: state [13157,13162]
name: state [13157,13162]
===
match
---
if_stmt [18737,18799]
if_stmt [18737,18799]
===
match
---
simple_stmt [23698,23862]
simple_stmt [23698,23862]
===
match
---
name: ti [79927,79929]
name: ti [79879,79881]
===
match
---
name: execution_date [73949,73963]
name: execution_date [73901,73915]
===
match
---
arith_expr [37991,38008]
arith_expr [37991,38008]
===
match
---
trailer [3230,3240]
trailer [3230,3240]
===
match
---
expr_stmt [69436,69475]
expr_stmt [69388,69427]
===
match
---
name: AirflowRescheduleException [44041,44067]
name: AirflowRescheduleException [44041,44067]
===
match
---
trailer [60697,60709]
trailer [60649,60661]
===
match
---
name: duration [72925,72933]
name: duration [72877,72885]
===
match
---
atom_expr [46204,46215]
atom_expr [46204,46215]
===
match
---
name: deps [39600,39604]
name: deps [39600,39604]
===
match
---
decorator [19874,19891]
decorator [19874,19891]
===
match
---
atom_expr [60881,60893]
atom_expr [60833,60845]
===
match
---
name: self [80280,80284]
name: self [80232,80236]
===
match
---
trailer [60688,60697]
trailer [60640,60649]
===
match
---
trailer [65366,65374]
trailer [65318,65326]
===
match
---
name: failed [31958,31964]
name: failed [31958,31964]
===
match
---
operator: , [32621,32622]
operator: , [32621,32622]
===
match
---
string: "worker-config" [68866,68881]
string: "worker-config" [68818,68833]
===
match
---
operator: , [3852,3853]
operator: , [3852,3853]
===
match
---
simple_stmt [82557,82598]
simple_stmt [82509,82550]
===
match
---
trailer [71743,71753]
trailer [71695,71705]
===
match
---
name: log [40359,40362]
name: log [40359,40362]
===
match
---
atom_expr [42648,42657]
atom_expr [42648,42657]
===
match
---
operator: , [48973,48974]
operator: , [48973,48974]
===
match
---
operator: @ [8344,8345]
operator: @ [8344,8345]
===
match
---
atom_expr [61533,61552]
atom_expr [61485,61504]
===
match
---
operator: , [65841,65842]
operator: , [65793,65794]
===
match
---
arglist [50178,50194]
arglist [50058,50211]
===
match
---
name: self [11316,11320]
name: self [11316,11320]
===
match
---
operator: = [80160,80161]
operator: = [80112,80113]
===
match
---
trailer [11736,11741]
trailer [11736,11741]
===
match
---
trailer [82312,82328]
trailer [82264,82280]
===
match
---
operator: , [35934,35935]
operator: , [35934,35935]
===
match
---
name: State [77778,77783]
name: State [77730,77735]
===
match
---
fstring_expr [19150,19155]
fstring_expr [19150,19155]
===
match
---
trailer [80388,80393]
trailer [80340,80345]
===
match
---
simple_stmt [3617,3631]
simple_stmt [3617,3631]
===
match
---
simple_stmt [1147,1161]
simple_stmt [1147,1161]
===
match
---
trailer [62260,62268]
trailer [62212,62220]
===
match
---
operator: , [47444,47445]
operator: , [47444,47445]
===
match
---
return_stmt [19352,19442]
return_stmt [19352,19442]
===
match
---
expr_stmt [22516,22539]
expr_stmt [22516,22539]
===
match
---
trailer [10217,10223]
trailer [10217,10223]
===
match
---
name: self [8767,8771]
name: self [8767,8771]
===
match
---
param [11130,11155]
param [11130,11155]
===
match
---
name: pool [22567,22571]
name: pool [22567,22571]
===
match
---
name: task_id [42961,42968]
name: task_id [42961,42968]
===
match
---
name: Optional [73215,73223]
name: Optional [73167,73175]
===
match
---
trailer [20949,20956]
trailer [20949,20956]
===
match
---
simple_stmt [80133,80181]
simple_stmt [80085,80133]
===
match
---
name: verbose [53481,53488]
name: verbose [53480,53487]
===
match
---
name: self [13232,13236]
name: self [13232,13236]
===
match
---
expr_stmt [73012,73032]
expr_stmt [72964,72984]
===
match
---
operator: , [18018,18019]
operator: , [18018,18019]
===
match
---
simple_stmt [68398,68425]
simple_stmt [68350,68377]
===
match
---
trailer [77022,77030]
trailer [76974,76982]
===
match
---
trailer [43532,43536]
trailer [43532,43536]
===
match
---
fstring_string: &task_id= [19397,19406]
fstring_string: &task_id= [19397,19406]
===
match
---
name: State [30938,30943]
name: State [30938,30943]
===
match
---
argument [60460,60494]
argument [60412,60446]
===
match
---
name: tomorrow_ds [62367,62378]
name: tomorrow_ds [62319,62330]
===
match
---
expr_stmt [42641,42657]
expr_stmt [42641,42657]
===
match
---
name: session [29631,29638]
name: session [29631,29638]
===
match
---
name: ti [80075,80077]
name: ti [80027,80029]
===
match
---
simple_stmt [40055,40338]
simple_stmt [40055,40338]
===
match
---
suite [44725,44821]
suite [44725,44821]
===
match
---
name: self [21769,21773]
name: self [21769,21773]
===
match
---
name: context [3591,3598]
name: context [3591,3598]
===
match
---
atom_expr [59440,59480]
atom_expr [59392,59432]
===
match
---
arglist [78780,78939]
arglist [78732,78891]
===
match
---
atom_expr [49878,49929]
atom_expr [49878,49929]
===
match
---
name: info [41239,41243]
name: info [41239,41243]
===
match
---
trailer [44109,44125]
trailer [44109,44125]
===
match
---
operator: = [81623,81624]
operator: = [81575,81576]
===
match
---
name: log [3742,3745]
name: log [3742,3745]
===
match
---
operator: = [37653,37654]
operator: = [37653,37654]
===
match
---
simple_stmt [9793,9820]
simple_stmt [9793,9820]
===
match
---
import_from [2400,2442]
import_from [2400,2442]
===
match
---
arglist [30659,30877]
arglist [30659,30877]
===
match
---
name: fd [4085,4087]
name: fd [4085,4087]
===
match
---
atom_expr [19054,19092]
atom_expr [19054,19092]
===
match
---
name: rendered_k8s_spec [67360,67377]
name: rendered_k8s_spec [67312,67329]
===
match
---
name: BooleanClauseList [78083,78100]
name: BooleanClauseList [78035,78052]
===
match
---
operator: , [60458,60459]
operator: , [60410,60411]
===
match
---
name: dr [7910,7912]
name: dr [7910,7912]
===
match
---
param [22967,22985]
param [22967,22985]
===
match
---
atom_expr [10357,10381]
atom_expr [10357,10381]
===
match
---
name: task_copy [51183,51192]
name: task_copy [51221,51230]
===
match
---
name: expected_state [3703,3717]
name: expected_state [3703,3717]
===
match
---
name: task_id [68524,68531]
name: task_id [68476,68483]
===
match
---
arglist [43682,44011]
arglist [43682,44011]
===
match
---
name: property [80754,80762]
name: property [80706,80714]
===
match
---
suite [79033,79255]
suite [78985,79207]
===
match
---
name: NamedTemporaryFile [999,1017]
name: NamedTemporaryFile [999,1017]
===
match
---
trailer [64542,64596]
trailer [64494,64548]
===
match
---
argument [6866,7000]
argument [6866,7000]
===
match
---
string: """         This attribute is deprecated.         Please use `airflow.models.taskinstance.TaskInstance.get_previous_ti` method.         """ [28140,28279]
string: """         This attribute is deprecated.         Please use `airflow.models.taskinstance.TaskInstance.get_previous_ti` method.         """ [28140,28279]
===
match
---
name: String [10138,10144]
name: String [10138,10144]
===
match
---
operator: , [48030,48031]
operator: , [48030,48031]
===
match
---
trailer [79385,79393]
trailer [79337,79345]
===
match
---
atom_expr [54736,54746]
atom_expr [54735,54745]
===
match
---
operator: } [33054,33055]
operator: } [33054,33055]
===
match
---
simple_stmt [52751,52789]
simple_stmt [52750,52788]
===
match
---
operator: , [59390,59391]
operator: , [59342,59343]
===
match
---
trailer [62129,62137]
trailer [62081,62089]
===
match
---
name: conf [68000,68004]
name: conf [67952,67956]
===
match
---
atom_expr [72936,72985]
atom_expr [72888,72937]
===
match
---
atom_expr [82626,82646]
atom_expr [82578,82598]
===
match
---
trailer [21750,21765]
trailer [21750,21765]
===
match
---
operator: = [22012,22013]
operator: = [22012,22013]
===
match
---
atom_expr [22818,22824]
atom_expr [22818,22824]
===
match
---
name: Exception [3985,3994]
name: Exception [3985,3994]
===
match
---
simple_stmt [49865,49930]
simple_stmt [49865,49930]
===
match
---
name: pool [23345,23349]
name: pool [23345,23349]
===
match
---
trailer [53182,53187]
trailer [53181,53186]
===
match
---
expr_stmt [11291,11307]
expr_stmt [11291,11307]
===
match
---
name: first [78450,78455]
name: first [78402,78407]
===
match
---
argument [54480,54505]
argument [54479,54504]
===
match
---
operator: = [48345,48346]
operator: = [48345,48346]
===
match
---
simple_stmt [34790,34836]
simple_stmt [34790,34836]
===
match
---
trailer [51626,51634]
trailer [51664,51672]
===
match
---
atom_expr [5577,5589]
atom_expr [5577,5589]
===
match
---
operator: } [45039,45040]
operator: } [45039,45040]
===
match
---
string: 'Log: <a href="{{ti.log_url}}">Link</a><br>' [69904,69948]
string: 'Log: <a href="{{ti.log_url}}">Link</a><br>' [69856,69900]
===
match
---
if_stmt [58742,59021]
if_stmt [58741,58973]
===
match
---
argument [54175,54200]
argument [54174,54199]
===
match
---
name: dag_id [80625,80631]
name: dag_id [80577,80583]
===
match
---
name: self [53892,53896]
name: self [53891,53895]
===
match
---
expr_stmt [22120,22141]
expr_stmt [22120,22141]
===
match
---
operator: = [70857,70858]
operator: = [70809,70810]
===
match
---
name: content [72046,72053]
name: content [71998,72005]
===
match
---
name: Optional [41879,41887]
name: Optional [41879,41887]
===
match
---
name: log [45140,45143]
name: log [45140,45143]
===
match
---
trailer [24727,24733]
trailer [24727,24733]
===
match
---
trailer [77967,77973]
trailer [77919,77925]
===
match
---
trailer [44644,44650]
trailer [44644,44650]
===
match
---
atom_expr [10656,10700]
atom_expr [10656,10700]
===
match
---
name: self [61533,61537]
name: self [61485,61489]
===
match
---
name: get_previous_ti [29602,29617]
name: get_previous_ti [29602,29617]
===
match
---
argument [37646,37661]
argument [37646,37661]
===
match
---
atom_expr [10138,10149]
atom_expr [10138,10149]
===
match
---
name: stacklevel [30864,30874]
name: stacklevel [30864,30874]
===
match
---
name: session [24108,24115]
name: session [24108,24115]
===
match
---
name: self [44105,44109]
name: self [44105,44109]
===
match
---
simple_stmt [23311,23350]
simple_stmt [23311,23350]
===
match
---
dictorsetmaker [64627,66179]
dictorsetmaker [64579,66131]
===
match
---
trailer [42861,42863]
trailer [42861,42863]
===
match
---
suite [68200,68251]
suite [68152,68203]
===
match
---
trailer [43133,43148]
trailer [43133,43148]
===
match
---
trailer [22782,22794]
trailer [22782,22794]
===
match
---
trailer [49359,49414]
trailer [49359,49414]
===
match
---
name: TaskInstanceKey [81431,81446]
name: TaskInstanceKey [81383,81398]
===
match
---
operator: -> [81360,81362]
operator: -> [81312,81314]
===
match
---
operator: , [41274,41275]
operator: , [41274,41275]
===
match
---
name: os [40892,40894]
name: os [40892,40894]
===
match
---
name: self [43304,43308]
name: self [43304,43308]
===
match
---
simple_stmt [33665,33748]
simple_stmt [33665,33748]
===
match
---
trailer [21916,21918]
trailer [21916,21918]
===
match
---
name: func [77599,77603]
name: func [77551,77555]
===
match
---
atom_expr [29274,29291]
atom_expr [29274,29291]
===
match
---
operator: , [79239,79240]
operator: , [79191,79192]
===
match
---
operator: = [72320,72321]
operator: = [72272,72273]
===
match
---
operator: , [59877,59878]
operator: , [59829,59830]
===
match
---
operator: = [53802,53803]
operator: = [53801,53802]
===
match
---
name: State [35061,35066]
name: State [35061,35066]
===
match
---
name: path [14861,14865]
name: path [14861,14865]
===
match
---
name: TaskInstanceKey [8506,8521]
name: TaskInstanceKey [8506,8521]
===
match
---
suite [5251,5336]
suite [5251,5336]
===
match
---
name: command_as_list [68741,68756]
name: command_as_list [68693,68708]
===
match
---
suite [56332,59105]
suite [56331,59057]
===
match
---
atom_expr [40859,40872]
atom_expr [40859,40872]
===
match
---
name: int [33679,33682]
name: int [33679,33682]
===
match
---
simple_stmt [57105,57142]
simple_stmt [57104,57141]
===
match
---
argument [44375,44396]
argument [44375,44396]
===
match
---
atom_expr [37827,37840]
atom_expr [37827,37840]
===
match
---
param [51183,51192]
param [51221,51230]
===
match
---
operator: , [71753,71754]
operator: , [71705,71706]
===
match
---
parameters [81184,81190]
parameters [81136,81142]
===
match
---
operator: = [29042,29043]
operator: = [29042,29043]
===
match
---
operator: = [38622,38623]
operator: = [38622,38623]
===
match
---
param [56262,56295]
param [56261,56294]
===
match
---
name: task_type [23613,23622]
name: task_type [23613,23622]
===
match
---
funcdef [67753,68046]
funcdef [67705,67998]
===
match
---
name: session [40491,40498]
name: session [40491,40498]
===
match
---
trailer [29530,29534]
trailer [29530,29534]
===
match
---
name: collections [906,917]
name: collections [906,917]
===
match
---
atom_expr [57938,57950]
atom_expr [57937,57949]
===
match
---
arglist [35493,35567]
arglist [35493,35567]
===
match
---
argument [51712,51727]
argument [51750,51765]
===
match
---
argument [68949,69031]
argument [68901,68983]
===
match
---
fstring_expr [33041,33055]
fstring_expr [33041,33055]
===
match
---
operator: } [19154,19155]
operator: } [19154,19155]
===
match
---
operator: = [82624,82625]
operator: = [82576,82577]
===
match
---
name: test_mode [54224,54233]
name: test_mode [54223,54232]
===
match
---
trailer [46716,46721]
trailer [46716,46721]
===
match
---
operator: , [41783,41784]
operator: , [41783,41784]
===
match
---
trailer [47905,47910]
trailer [47905,47910]
===
match
---
name: fd [4434,4436]
name: fd [4434,4436]
===
match
---
funcdef [12507,12668]
funcdef [12507,12668]
===
match
---
name: self [37722,37726]
name: self [37722,37726]
===
match
---
simple_stmt [76465,76708]
simple_stmt [76417,76660]
===
match
---
trailer [59709,59732]
trailer [59661,59684]
===
match
---
name: Optional [56197,56205]
name: Optional [56196,56204]
===
match
---
operator: = [65513,65514]
operator: = [65465,65466]
===
match
---
name: provide_session [23629,23644]
name: provide_session [23629,23644]
===
match
---
name: params [65088,65094]
name: params [65040,65046]
===
match
---
string: 'Log: <a href="{{ti.log_url}}">Link</a><br>' [70302,70346]
string: 'Log: <a href="{{ti.log_url}}">Link</a><br>' [70254,70298]
===
match
---
name: dag_id [10677,10683]
name: dag_id [10677,10683]
===
match
---
simple_stmt [23870,23907]
simple_stmt [23870,23907]
===
match
---
operator: , [1039,1040]
operator: , [1039,1040]
===
match
---
name: task_ids [76933,76941]
name: task_ids [76885,76893]
===
match
---
trailer [62649,62681]
trailer [62601,62633]
===
match
---
name: TaskInstance [20323,20335]
name: TaskInstance [20323,20335]
===
match
---
expr_stmt [5445,5473]
expr_stmt [5445,5473]
===
match
---
name: task [52938,52942]
name: task [52937,52941]
===
match
---
name: self [54894,54898]
name: self [54893,54897]
===
match
---
name: self [67424,67428]
name: self [67376,67380]
===
match
---
param [79783,79788]
param [79735,79740]
===
match
---
if_stmt [3700,3925]
if_stmt [3700,3925]
===
match
---
name: self [22476,22480]
name: self [22476,22480]
===
match
---
name: getuser [12102,12109]
name: getuser [12102,12109]
===
match
---
trailer [45139,45143]
trailer [45139,45143]
===
match
---
name: lazy_object_proxy [65430,65447]
name: lazy_object_proxy [65382,65399]
===
match
---
decorated [81400,81473]
decorated [81352,81425]
===
match
---
atom_expr [29201,29214]
atom_expr [29201,29214]
===
match
---
name: Union [59194,59199]
name: Union [59146,59151]
===
match
---
fstring [19109,19160]
fstring [19109,19160]
===
match
---
operator: = [58333,58334]
operator: = [58332,58333]
===
match
---
name: self [32541,32545]
name: self [32541,32545]
===
match
---
simple_stmt [24817,24867]
simple_stmt [24817,24867]
===
match
---
suite [33402,34836]
suite [33402,34836]
===
match
---
atom_expr [65430,65542]
atom_expr [65382,65494]
===
match
---
atom_expr [55508,55517]
atom_expr [55507,55516]
===
match
---
operator: , [55623,55624]
operator: , [55622,55623]
===
match
---
name: ignore_all_deps [14133,14148]
name: ignore_all_deps [14133,14148]
===
match
---
name: reschedule_exception [44071,44091]
name: reschedule_exception [44071,44091]
===
match
---
name: min_backoff [34201,34212]
name: min_backoff [34201,34212]
===
match
---
trailer [48082,48084]
trailer [48082,48084]
===
match
---
decorator [13348,13358]
decorator [13348,13358]
===
match
---
simple_stmt [72156,72210]
simple_stmt [72108,72162]
===
match
---
name: Optional [36021,36029]
name: Optional [36021,36029]
===
match
---
exprlist [7167,7180]
exprlist [7167,7180]
===
match
---
simple_stmt [23458,23494]
simple_stmt [23458,23494]
===
match
---
name: self [55508,55512]
name: self [55507,55511]
===
match
---
operator: == [79095,79097]
operator: == [79047,79049]
===
match
---
name: operator [10193,10201]
name: operator [10193,10201]
===
match
---
atom_expr [11255,11267]
atom_expr [11255,11267]
===
match
---
suite [7471,7511]
suite [7471,7511]
===
match
---
funcdef [3342,3925]
funcdef [3342,3925]
===
match
---
funcdef [64151,64208]
funcdef [64103,64160]
===
match
---
name: self [22807,22811]
name: self [22807,22811]
===
match
---
fstring_expr [57008,57024]
fstring_expr [57007,57023]
===
match
---
name: State [52639,52644]
name: State [52638,52643]
===
match
---
name: self [25047,25051]
name: self [25047,25051]
===
match
---
argument [76628,76667]
argument [76580,76619]
===
match
---
not_test [27754,27773]
not_test [27754,27773]
===
match
---
fstring_start: f" [62418,62420]
fstring_start: f" [62370,62372]
===
match
---
trailer [58569,58604]
trailer [58568,58603]
===
match
---
name: UP_FOR_RETRY [53145,53157]
name: UP_FOR_RETRY [53144,53156]
===
match
---
trailer [22532,22539]
trailer [22532,22539]
===
match
---
trailer [64798,64807]
trailer [64750,64759]
===
match
---
trailer [77931,77935]
trailer [77883,77887]
===
match
---
param [52376,52381]
param [52375,52380]
===
match
---
simple_stmt [58097,58137]
simple_stmt [58096,58136]
===
match
---
param [4750,4758]
param [4750,4758]
===
match
---
name: dag_id [33922,33928]
name: dag_id [33922,33928]
===
match
---
atom_expr [22096,22107]
atom_expr [22096,22107]
===
match
---
operator: , [51973,51974]
operator: , [52011,52012]
===
match
---
name: func [26063,26067]
name: func [26063,26067]
===
match
---
name: os [71096,71098]
name: os [71048,71050]
===
match
---
name: self [63249,63253]
name: self [63201,63205]
===
match
---
operator: , [68835,68836]
operator: , [68787,68788]
===
match
---
trailer [57929,57935]
trailer [57928,57934]
===
match
---
name: AirflowFailException [1674,1694]
name: AirflowFailException [1674,1694]
===
match
---
name: UP_FOR_RESCHEDULE [39133,39150]
name: UP_FOR_RESCHEDULE [39133,39150]
===
match
---
name: schedule_interval [27689,27706]
name: schedule_interval [27689,27706]
===
match
---
name: utils [2713,2718]
name: utils [2713,2718]
===
match
---
name: with_row_locks [2800,2814]
name: with_row_locks [2800,2814]
===
match
---
return_stmt [13193,13216]
return_stmt [13193,13216]
===
match
---
operator: = [59251,59252]
operator: = [59203,59204]
===
match
---
name: dep_status [32157,32167]
name: dep_status [32157,32167]
===
match
---
operator: = [30198,30199]
operator: = [30198,30199]
===
match
---
string: 'ti_job_id' [10877,10888]
string: 'ti_job_id' [10877,10888]
===
match
---
operator: , [24773,24774]
operator: , [24773,24774]
===
match
---
name: set [74208,74211]
name: set [74160,74163]
===
match
---
name: current_time [24989,25001]
name: current_time [24989,25001]
===
match
---
atom_expr [47571,47608]
atom_expr [47571,47608]
===
match
---
atom_expr [40892,40903]
atom_expr [40892,40903]
===
match
---
atom_expr [48773,48840]
atom_expr [48773,48840]
===
match
---
name: task_id [26087,26094]
name: task_id [26087,26094]
===
match
---
atom_expr [28038,28050]
atom_expr [28038,28050]
===
match
---
simple_stmt [4078,4095]
simple_stmt [4078,4095]
===
match
---
operator: } [70584,70585]
operator: } [70536,70537]
===
match
---
name: SHUTDOWN [5285,5293]
name: SHUTDOWN [5285,5293]
===
match
---
operator: += [40756,40758]
operator: += [40756,40758]
===
match
---
simple_stmt [51653,51659]
simple_stmt [51691,51697]
===
match
---
name: ImportError [3161,3172]
name: ImportError [3161,3172]
===
match
---
trailer [43847,43855]
trailer [43847,43855]
===
match
---
name: self [81610,81614]
name: self [81562,81566]
===
match
---
fstring_end: " [67705,67706]
fstring_end: " [67657,67658]
===
match
---
trailer [8323,8338]
trailer [8323,8338]
===
match
---
simple_stmt [26832,26852]
simple_stmt [26832,26852]
===
match
---
for_stmt [7883,7981]
for_stmt [7883,7981]
===
match
---
name: TaskInstance [79359,79371]
name: TaskInstance [79311,79323]
===
match
---
name: _try_number [14003,14014]
name: _try_number [14003,14014]
===
match
---
operator: , [70924,70925]
operator: , [70876,70877]
===
match
---
name: first [82374,82379]
name: first [82326,82331]
===
match
---
name: Context [59896,59903]
name: Context [59848,59855]
===
match
---
return_stmt [67723,67747]
return_stmt [67675,67699]
===
match
---
name: pod_override_object [68772,68791]
name: pod_override_object [68724,68743]
===
match
---
trailer [22328,22340]
trailer [22328,22340]
===
match
---
except_clause [44424,44452]
except_clause [44424,44452]
===
match
---
name: data [4106,4110]
name: data [4106,4110]
===
match
---
trailer [52874,52883]
trailer [52873,52882]
===
match
---
name: quote [19252,19257]
name: quote [19252,19257]
===
match
---
simple_stmt [80097,80125]
simple_stmt [80049,80077]
===
match
---
operator: , [57228,57229]
operator: , [57227,57228]
===
match
---
tfpdef [36013,36034]
tfpdef [36013,36034]
===
match
---
trailer [18465,18472]
trailer [18465,18472]
===
match
---
name: log [47902,47905]
name: log [47902,47905]
===
match
---
trailer [7791,7795]
trailer [7791,7795]
===
match
---
trailer [35587,35589]
trailer [35587,35589]
===
match
---
operator: = [63010,63011]
operator: = [62962,62963]
===
match
---
atom_expr [51068,51144]
atom_expr [51106,51182]
===
match
---
operator: = [73234,73235]
operator: = [73186,73187]
===
match
---
operator: = [22600,22601]
operator: = [22600,22601]
===
match
---
arglist [58694,58721]
arglist [58693,58720]
===
match
---
number: 1 [10100,10101]
number: 1 [10100,10101]
===
match
---
operator: = [60442,60443]
operator: = [60394,60395]
===
match
---
name: dep_context [31010,31021]
name: dep_context [31010,31021]
===
match
---
name: ti [6017,6019]
name: ti [6017,6019]
===
match
---
name: _execution_date [82236,82251]
name: _execution_date [82188,82203]
===
match
---
atom_expr [59608,59623]
atom_expr [59560,59575]
===
match
---
operator: , [10090,10091]
operator: , [10090,10091]
===
match
---
trailer [18089,18109]
trailer [18089,18109]
===
match
---
simple_stmt [49012,49085]
simple_stmt [49012,49085]
===
match
---
param [45822,45834]
param [45822,45834]
===
match
---
name: State [24892,24897]
name: State [24892,24897]
===
match
---
name: timezone [42893,42901]
name: timezone [42893,42901]
===
match
---
operator: = [37605,37606]
operator: = [37605,37606]
===
match
---
param [24196,24200]
param [24196,24200]
===
match
---
funcdef [69185,72436]
funcdef [69137,72388]
===
match
---
name: ignore_depends_on_past [53550,53572]
name: ignore_depends_on_past [53549,53571]
===
match
---
trailer [32662,32668]
trailer [32662,32668]
===
match
---
name: task [60204,60208]
name: task [60156,60160]
===
match
---
suite [11185,12483]
suite [11185,12483]
===
match
---
name: mark_success [54188,54200]
name: mark_success [54187,54199]
===
match
---
name: loads [4163,4168]
name: loads [4163,4168]
===
match
---
parameters [41700,41928]
parameters [41700,41928]
===
match
---
name: DagRun [82639,82645]
name: DagRun [82591,82597]
===
match
---
trailer [26185,26189]
trailer [26185,26189]
===
match
---
comparison [53125,53157]
comparison [53124,53156]
===
match
---
operator: = [15167,15168]
operator: = [15167,15168]
===
match
---
trailer [71914,71928]
trailer [71866,71880]
===
match
---
operator: , [62141,62142]
operator: , [62093,62094]
===
match
---
simple_stmt [63927,63943]
simple_stmt [63879,63895]
===
match
---
atom_expr [37625,37684]
atom_expr [37625,37684]
===
match
---
funcdef [55140,56080]
funcdef [55139,56079]
===
match
---
trailer [54863,54876]
trailer [54862,54875]
===
match
---
atom_expr [23870,23906]
atom_expr [23870,23906]
===
match
---
name: default_html_content_err [70131,70155]
name: default_html_content_err [70083,70107]
===
match
---
trailer [41525,41537]
trailer [41525,41537]
===
match
---
name: task [25964,25968]
name: task [25964,25968]
===
match
---
string: "Webserver does not have access to User-defined Macros or Filters " [66849,66916]
string: "Webserver does not have access to User-defined Macros or Filters " [66801,66868]
===
match
---
fstring_start: f" [49361,49363]
fstring_start: f" [49361,49363]
===
match
---
operator: = [15910,15911]
operator: = [15910,15911]
===
match
---
name: execution_date [79930,79944]
name: execution_date [79882,79896]
===
match
---
trailer [57909,57911]
trailer [57908,57910]
===
match
---
operator: @ [32327,32328]
operator: @ [32327,32328]
===
match
---
name: execution_timeout [51387,51404]
name: execution_timeout [51425,51442]
===
match
---
name: self [72751,72755]
name: self [72703,72707]
===
match
---
operator: , [35855,35856]
operator: , [35855,35856]
===
match
---
name: State [40816,40821]
name: State [40816,40821]
===
match
---
name: execution_date [41292,41306]
name: execution_date [41292,41306]
===
match
---
name: self [63127,63131]
name: self [63079,63083]
===
match
---
atom [18608,18619]
atom [18608,18619]
===
match
---
trailer [79838,79845]
trailer [79790,79797]
===
match
---
expr_stmt [12058,12077]
expr_stmt [12058,12077]
===
match
---
name: schedulable_ti [47479,47493]
name: schedulable_ti [47479,47493]
===
match
---
name: task_id [62441,62448]
name: task_id [62393,62400]
===
match
---
argument [15151,15184]
argument [15151,15184]
===
match
---
atom_expr [23540,23560]
atom_expr [23540,23560]
===
match
---
trailer [68756,68758]
trailer [68708,68710]
===
match
---
atom_expr [80031,80042]
atom_expr [79983,79994]
===
match
---
expr_stmt [10910,11099]
expr_stmt [10910,11099]
===
match
---
name: SUCCESS [43235,43242]
name: SUCCESS [43235,43242]
===
match
---
simple_stmt [48286,48327]
simple_stmt [48286,48327]
===
match
---
trailer [19546,19579]
trailer [19546,19579]
===
match
---
name: html_content [72405,72417]
name: html_content [72357,72369]
===
match
---
atom_expr [63249,63257]
atom_expr [63201,63209]
===
match
---
name: execution_date [57214,57228]
name: execution_date [57213,57227]
===
match
---
simple_stmt [10332,10383]
simple_stmt [10332,10383]
===
match
---
name: execution_date [8324,8338]
name: execution_date [8324,8338]
===
match
---
trailer [46671,46675]
trailer [46671,46675]
===
match
---
name: hostname [22441,22449]
name: hostname [22441,22449]
===
match
---
simple_stmt [72389,72436]
simple_stmt [72341,72388]
===
match
---
atom_expr [7239,7278]
atom_expr [7239,7278]
===
match
---
expr_stmt [22721,22748]
expr_stmt [22721,22748]
===
match
---
name: key [71924,71927]
name: key [71876,71879]
===
match
---
name: hasattr [80412,80419]
name: hasattr [80364,80371]
===
match
---
name: dag_run [67892,67899]
name: dag_run [67844,67851]
===
match
---
tfpdef [29786,29806]
tfpdef [29786,29806]
===
match
---
expr_stmt [53024,53061]
expr_stmt [53023,53060]
===
match
---
return_stmt [51924,51937]
return_stmt [51962,51975]
===
match
---
trailer [18660,18678]
trailer [18660,18678]
===
match
---
name: self [32608,32612]
name: self [32608,32612]
===
match
---
trailer [7198,7204]
trailer [7198,7204]
===
match
---
name: task_id [82162,82169]
name: task_id [82114,82121]
===
match
---
trailer [12109,12111]
trailer [12109,12111]
===
match
---
suite [32994,33095]
suite [32994,33095]
===
match
---
string: 'ti' [70574,70578]
string: 'ti' [70526,70530]
===
match
---
simple_stmt [35609,35619]
simple_stmt [35609,35619]
===
match
---
atom_expr [54807,54823]
atom_expr [54806,54822]
===
match
---
return_stmt [64122,64137]
return_stmt [64074,64089]
===
match
---
arglist [48966,48997]
arglist [48966,48997]
===
match
---
trailer [37697,37704]
trailer [37697,37704]
===
match
---
atom_expr [40491,40507]
atom_expr [40491,40507]
===
match
---
operator: , [15445,15446]
operator: , [15445,15446]
===
match
---
trailer [5121,5168]
trailer [5121,5168]
===
match
---
trailer [79153,79184]
trailer [79105,79136]
===
match
---
name: log [24724,24727]
name: log [24724,24727]
===
match
---
name: end_date [56912,56920]
name: end_date [56911,56919]
===
match
---
arglist [74143,74178]
arglist [74095,74130]
===
match
---
operator: , [61751,61752]
operator: , [61703,61704]
===
match
---
name: self [22878,22882]
name: self [22878,22882]
===
match
---
decorated [19874,20631]
decorated [19874,20631]
===
match
---
name: register_in_sensor_service [49888,49914]
name: register_in_sensor_service [49888,49914]
===
match
---
atom_expr [80555,80561]
atom_expr [80507,80513]
===
match
---
fstring_start: f" [67649,67651]
fstring_start: f" [67601,67603]
===
match
---
atom [18090,18108]
atom [18090,18108]
===
match
---
name: qry [21586,21589]
name: qry [21586,21589]
===
match
---
number: 1 [40759,40760]
number: 1 [40759,40760]
===
match
---
atom_expr [58228,58246]
atom_expr [58227,58245]
===
match
---
string: 'yesterday_ds' [66094,66108]
string: 'yesterday_ds' [66046,66060]
===
match
---
argument [71420,71435]
argument [71372,71387]
===
match
---
name: self [72873,72877]
name: self [72825,72829]
===
match
---
name: log [41347,41350]
name: log [41347,41350]
===
match
---
simple_stmt [14861,14886]
simple_stmt [14861,14886]
===
match
---
name: _task_id [82178,82186]
name: _task_id [82130,82138]
===
match
---
string: '%Y%m%dT%H%M%S' [58648,58663]
string: '%Y%m%dT%H%M%S' [58647,58662]
===
match
---
operator: = [80339,80340]
operator: = [80291,80292]
===
match
---
atom_expr [42893,42910]
atom_expr [42893,42910]
===
match
---
param [81185,81189]
param [81137,81141]
===
match
---
atom_expr [40999,41015]
atom_expr [40999,41015]
===
match
---
name: self [53467,53471]
name: self [53466,53470]
===
match
---
import_as_names [1421,1448]
import_as_names [1421,1448]
===
match
---
operator: = [59985,59986]
operator: = [59937,59938]
===
match
---
expr_stmt [61563,61577]
expr_stmt [61515,61529]
===
match
---
operator: , [30818,30819]
operator: , [30818,30819]
===
match
---
operator: @ [13904,13905]
operator: @ [13904,13905]
===
match
---
name: state [27943,27948]
name: state [27943,27948]
===
match
---
name: task_ids [47134,47142]
name: task_ids [47134,47142]
===
match
---
name: State [65514,65519]
name: State [65466,65471]
===
match
---
operator: = [10310,10311]
operator: = [10310,10311]
===
match
---
atom_expr [25985,26009]
atom_expr [25985,26009]
===
match
---
operator: { [19135,19136]
operator: { [19135,19136]
===
match
---
name: force_fail [44358,44368]
name: force_fail [44358,44368]
===
match
---
decorator [26443,26460]
decorator [26443,26460]
===
match
---
name: session [27926,27933]
name: session [27926,27933]
===
match
---
argument [10433,10449]
argument [10433,10449]
===
match
---
name: session [35178,35185]
name: session [35178,35185]
===
match
---
name: self [74143,74147]
name: self [74095,74099]
===
match
---
operator: { [57008,57009]
operator: { [57007,57008]
===
match
---
operator: , [6898,6899]
operator: , [6898,6899]
===
match
---
trailer [45634,45636]
trailer [45634,45636]
===
match
---
expr_stmt [3178,3194]
expr_stmt [3178,3194]
===
match
---
name: SUCCESS [54756,54763]
name: SUCCESS [54755,54762]
===
match
---
name: merge [6059,6064]
name: merge [6059,6064]
===
match
---
name: self [35548,35552]
name: self [35548,35552]
===
match
---
atom_expr [78890,78938]
atom_expr [78842,78890]
===
match
---
name: first [35582,35587]
name: first [35582,35587]
===
match
---
atom_expr [10312,10327]
atom_expr [10312,10327]
===
match
---
atom_expr [7770,7830]
atom_expr [7770,7830]
===
match
---
trailer [63146,63150]
trailer [63098,63102]
===
match
---
fstring_string: ]> [33091,33093]
fstring_string: ]> [33091,33093]
===
match
---
name: COLLATION_ARGS [10435,10449]
name: COLLATION_ARGS [10435,10449]
===
match
---
atom_expr [70956,70970]
atom_expr [70908,70922]
===
match
---
expr_stmt [37722,37752]
expr_stmt [37722,37752]
===
match
---
trailer [51711,51728]
trailer [51749,51766]
===
match
---
operator: @ [26443,26444]
operator: @ [26443,26444]
===
match
---
name: dep_context [39558,39569]
name: dep_context [39558,39569]
===
match
---
name: self [24719,24723]
name: self [24719,24723]
===
match
---
param [59267,59292]
param [59219,59244]
===
match
---
expr_stmt [12608,12630]
expr_stmt [12608,12630]
===
match
---
name: self [81264,81268]
name: self [81216,81220]
===
match
---
operator: = [71640,71641]
operator: = [71592,71593]
===
match
---
operator: , [15288,15289]
operator: , [15288,15289]
===
match
---
operator: , [32398,32399]
operator: , [32398,32399]
===
match
---
name: bytes [3954,3959]
name: bytes [3954,3959]
===
match
---
name: task [58335,58339]
name: task [58334,58338]
===
match
---
name: email_on_retry [58340,58354]
name: email_on_retry [58339,58353]
===
match
---
name: fmt [59799,59802]
name: fmt [59751,59754]
===
match
---
name: self [11221,11225]
name: self [11221,11225]
===
match
---
trailer [22494,22503]
trailer [22494,22503]
===
match
---
name: render_templates [66704,66720]
name: render_templates [66656,66672]
===
match
---
atom_expr [9705,9724]
atom_expr [9705,9724]
===
match
---
name: Stats [2231,2236]
name: Stats [2231,2236]
===
match
---
atom_expr [79836,79845]
atom_expr [79788,79797]
===
match
---
string: """Render templates in the operator fields.""" [68130,68176]
string: """Render templates in the operator fields.""" [68082,68128]
===
match
---
name: job_id [37707,37713]
name: job_id [37707,37713]
===
match
---
name: RUNNING [77784,77791]
name: RUNNING [77736,77743]
===
match
---
atom_expr [33965,33980]
atom_expr [33965,33980]
===
match
---
operator: , [3234,3235]
operator: , [3234,3235]
===
match
---
funcdef [19462,19869]
funcdef [19462,19869]
===
match
---
operator: = [46660,46661]
operator: = [46660,46661]
===
match
---
operator: , [71655,71656]
operator: , [71607,71608]
===
match
---
operator: = [27326,27327]
operator: = [27326,27327]
===
match
---
atom_expr [55641,55654]
atom_expr [55640,55653]
===
match
---
name: ti [5577,5579]
name: ti [5577,5579]
===
match
---
atom_expr [34747,34772]
atom_expr [34747,34772]
===
match
---
name: end_date [22045,22053]
name: end_date [22045,22053]
===
match
---
trailer [80511,80518]
trailer [80463,80470]
===
match
---
atom_expr [33944,33963]
atom_expr [33944,33963]
===
match
---
trailer [60727,60742]
trailer [60679,60694]
===
match
---
name: task [23376,23380]
name: task [23376,23380]
===
match
---
name: self [8780,8784]
name: self [8780,8784]
===
match
---
simple_stmt [48737,48760]
simple_stmt [48737,48760]
===
match
---
for_stmt [66516,66652]
for_stmt [66468,66604]
===
match
---
operator: , [4059,4060]
operator: , [4059,4060]
===
match
---
name: ignore_ti_state [18514,18529]
name: ignore_ti_state [18514,18529]
===
match
---
trailer [71961,71965]
trailer [71913,71917]
===
match
---
name: dag_id [62426,62432]
name: dag_id [62378,62384]
===
match
---
name: String [10030,10036]
name: String [10030,10036]
===
match
---
name: next_execution_date [61809,61828]
name: next_execution_date [61761,61780]
===
match
---
name: in_ [7792,7795]
name: in_ [7792,7795]
===
match
---
string: """         Forces the task instance's state to FAILED in the database.          :param session: SQLAlchemy ORM Session         :type session: Session         """ [20696,20858]
string: """         Forces the task instance's state to FAILED in the database.          :param session: SQLAlchemy ORM Session         :type session: Session         """ [20696,20858]
===
match
---
suite [54900,55114]
suite [54899,55113]
===
match
---
operator: , [67586,67587]
operator: , [67538,67539]
===
match
---
trailer [53207,53225]
trailer [53206,53224]
===
match
---
trailer [48638,48646]
trailer [48638,48646]
===
match
---
operator: = [29097,29098]
operator: = [29097,29098]
===
match
---
trailer [60394,60400]
trailer [60346,60352]
===
match
---
funcdef [81244,81325]
funcdef [81196,81277]
===
match
---
trailer [27688,27706]
trailer [27688,27706]
===
match
---
atom_expr [40800,40837]
atom_expr [40800,40837]
===
match
---
simple_stmt [58149,58189]
simple_stmt [58148,58188]
===
match
---
name: api_client [2928,2938]
name: api_client [2928,2938]
===
match
---
trailer [35499,35506]
trailer [35499,35506]
===
match
---
name: debug [73050,73055]
name: debug [73002,73007]
===
match
---
expr_stmt [3279,3312]
expr_stmt [3279,3312]
===
match
---
name: Any [64363,64366]
name: Any [64315,64318]
===
match
---
operator: } [62448,62449]
operator: } [62400,62401]
===
match
---
name: error_file [54618,54628]
name: error_file [54617,54627]
===
match
---
name: result [51931,51937]
name: result [51969,51975]
===
match
---
atom [76966,77120]
atom [76918,77072]
===
match
---
for_stmt [47356,47548]
for_stmt [47356,47548]
===
match
---
name: query [7410,7415]
name: query [7410,7415]
===
match
---
suite [57912,58189]
suite [57911,58188]
===
match
---
name: self [15008,15012]
name: self [15008,15012]
===
match
---
operator: = [62125,62126]
operator: = [62077,62078]
===
match
---
name: task [49661,49665]
name: task [49661,49665]
===
match
---
arglist [62138,62145]
arglist [62090,62097]
===
match
---
name: self [33124,33128]
name: self [33124,33128]
===
match
---
arglist [56497,56513]
arglist [56496,56512]
===
match
---
trailer [77603,77609]
trailer [77555,77561]
===
match
---
simple_stmt [2590,2657]
simple_stmt [2590,2657]
===
match
---
operator: = [49876,49877]
operator: = [49876,49877]
===
match
---
operator: , [1243,1244]
operator: , [1243,1244]
===
match
---
trailer [5243,5250]
trailer [5243,5250]
===
match
---
name: session [26909,26916]
name: session [26909,26916]
===
match
---
trailer [5141,5167]
trailer [5141,5167]
===
match
---
comparison [24037,24079]
comparison [24037,24079]
===
match
---
trailer [33692,33746]
trailer [33692,33746]
===
match
---
string: "DagModel" [10944,10954]
string: "DagModel" [10944,10954]
===
match
---
operator: , [63094,63095]
operator: , [63046,63047]
===
match
---
trailer [43536,43541]
trailer [43536,43541]
===
match
---
expr_stmt [59980,59996]
expr_stmt [59932,59948]
===
match
---
comparison [78992,79018]
comparison [78944,78970]
===
match
---
atom_expr [3974,3995]
atom_expr [3974,3995]
===
match
---
name: job_ids [7323,7330]
name: job_ids [7323,7330]
===
match
---
funcdef [81414,81473]
funcdef [81366,81425]
===
match
---
name: on_failure_callback [52855,52874]
name: on_failure_callback [52854,52873]
===
match
---
operator: , [72403,72404]
operator: , [72355,72356]
===
match
---
trailer [3264,3273]
trailer [3264,3273]
===
match
---
operator: , [54675,54676]
operator: , [54674,54675]
===
match
---
name: ti [26375,26377]
name: ti [26375,26377]
===
match
---
decorated [13348,13899]
decorated [13348,13899]
===
match
---
name: dag_id [18020,18026]
name: dag_id [18020,18026]
===
match
---
trailer [35514,35521]
trailer [35514,35521]
===
match
---
atom_expr [17951,17977]
atom_expr [17951,17977]
===
match
---
operator: , [41714,41715]
operator: , [41714,41715]
===
match
---
atom_expr [68340,68354]
atom_expr [68292,68306]
===
match
---
funcdef [25127,25411]
funcdef [25127,25411]
===
match
---
name: ignore_depends_on_past [15221,15243]
name: ignore_depends_on_past [15221,15243]
===
match
---
operator: , [76696,76697]
operator: , [76648,76649]
===
match
---
operator: , [64700,64701]
operator: , [64652,64653]
===
match
---
trailer [22820,22824]
trailer [22820,22824]
===
match
---
arglist [45162,45467]
arglist [45162,45467]
===
match
---
trailer [41243,41307]
trailer [41243,41307]
===
match
---
if_stmt [5196,6069]
if_stmt [5196,6069]
===
match
---
operator: = [68964,68965]
operator: = [68916,68917]
===
match
---
trailer [45559,45577]
trailer [45559,45577]
===
match
---
name: task_id [49063,49070]
name: task_id [49063,49070]
===
match
---
param [12524,12528]
param [12524,12528]
===
match
---
decorated [20636,21010]
decorated [20636,21010]
===
match
---
trailer [59798,59803]
trailer [59750,59755]
===
match
---
name: task [45013,45017]
name: task [45013,45017]
===
match
---
name: ready_for_retry [25393,25408]
name: ready_for_retry [25393,25408]
===
match
---
if_stmt [52095,52174]
if_stmt [52133,52212]
===
match
---
trailer [66063,66065]
trailer [66015,66017]
===
match
---
arglist [37865,37893]
arglist [37865,37893]
===
match
---
name: session [42779,42786]
name: session [42779,42786]
===
match
---
name: ti [6093,6095]
name: ti [6093,6095]
===
match
---
operator: @ [50740,50741]
operator: @ [50778,50779]
===
match
---
param [20667,20672]
param [20667,20672]
===
match
---
operator: , [76555,76556]
operator: , [76507,76508]
===
match
---
operator: = [60474,60475]
operator: = [60426,60427]
===
match
---
operator: ** [9592,9594]
operator: ** [9592,9594]
===
match
---
param [81610,81615]
param [81562,81567]
===
match
---
trailer [31811,31816]
trailer [31811,31816]
===
match
---
name: provide_session [74436,74451]
name: provide_session [74388,74403]
===
match
---
name: self [50979,50983]
name: self [51017,51021]
===
match
---
trailer [49544,49556]
trailer [49544,49556]
===
match
---
name: State [13166,13171]
name: State [13166,13171]
===
match
---
name: str [79869,79872]
name: str [79821,79824]
===
match
---
name: RUNNING_DEPS [2352,2364]
name: RUNNING_DEPS [2352,2364]
===
match
---
operator: = [38366,38367]
operator: = [38366,38367]
===
match
---
operator: , [64971,64972]
operator: , [64923,64924]
===
match
---
operator: , [27941,27942]
operator: , [27941,27942]
===
match
---
trailer [59991,59996]
trailer [59943,59948]
===
match
---
atom_expr [47982,47993]
atom_expr [47982,47993]
===
match
---
trailer [6019,6025]
trailer [6019,6025]
===
match
---
trailer [22855,22861]
trailer [22855,22861]
===
match
---
expr_stmt [23279,23302]
expr_stmt [23279,23302]
===
match
---
name: task [60175,60179]
name: task [60127,60131]
===
match
---
name: task_id [24000,24007]
name: task_id [24000,24007]
===
match
---
trailer [78029,78069]
trailer [77981,78021]
===
match
---
operator: = [31035,31036]
operator: = [31035,31036]
===
match
---
param [28125,28129]
param [28125,28129]
===
match
---
expr_stmt [35432,35599]
expr_stmt [35432,35599]
===
match
---
name: property [8153,8161]
name: property [8153,8161]
===
match
---
trailer [19257,19290]
trailer [19257,19290]
===
match
---
number: 80 [38005,38007]
number: 80 [38005,38007]
===
match
---
simple_stmt [12460,12483]
simple_stmt [12460,12483]
===
match
---
simple_stmt [44228,44235]
simple_stmt [44228,44235]
===
match
---
operator: , [1694,1695]
operator: , [1694,1695]
===
match
---
name: hr_line_break [40716,40729]
name: hr_line_break [40716,40729]
===
match
---
name: path [72010,72014]
name: path [71962,71966]
===
match
---
name: retry_delay [33343,33354]
name: retry_delay [33343,33354]
===
match
---
trailer [23362,23373]
trailer [23362,23373]
===
match
---
tfpdef [63085,63094]
tfpdef [63037,63046]
===
match
---
return_stmt [80813,80840]
return_stmt [80765,80792]
===
match
---
argument [31928,31943]
argument [31928,31943]
===
match
---
name: session [20258,20265]
name: session [20258,20265]
===
match
---
trailer [26096,26103]
trailer [26096,26103]
===
match
---
name: Context [3216,3223]
name: Context [3216,3223]
===
match
---
name: pool [37576,37580]
name: pool [37576,37580]
===
match
---
name: format [33885,33891]
name: format [33885,33891]
===
match
---
suite [13393,13899]
suite [13393,13899]
===
match
---
operator: , [11045,11046]
operator: , [11045,11046]
===
match
---
atom_expr [23608,23622]
atom_expr [23608,23622]
===
match
---
simple_stmt [62221,62278]
simple_stmt [62173,62230]
===
match
---
simple_stmt [23400,23450]
simple_stmt [23400,23450]
===
match
---
operator: = [61571,61572]
operator: = [61523,61524]
===
match
---
name: _dag_id [80666,80673]
name: _dag_id [80618,80625]
===
match
---
name: task_id [80697,80704]
name: task_id [80649,80656]
===
match
---
trailer [68465,69042]
trailer [68417,68994]
===
match
---
name: email_alert [58815,58826]
name: email_alert [58814,58825]
===
match
---
atom_expr [78992,79001]
atom_expr [78944,78953]
===
match
---
atom_expr [78758,78953]
atom_expr [78710,78905]
===
match
---
name: state [45047,45052]
name: state [45047,45052]
===
match
---
param [72463,72472]
param [72415,72424]
===
match
---
name: task [58967,58971]
name: task [58961,58965]
===
match
---
name: in_ [79150,79153]
name: in_ [79102,79105]
===
match
---
atom_expr [37813,37823]
atom_expr [37813,37823]
===
match
---
trailer [12146,12152]
trailer [12146,12152]
===
match
---
name: warn [28817,28821]
name: warn [28817,28821]
===
match
---
atom_expr [45856,45932]
atom_expr [45856,45932]
===
match
---
suite [52734,52884]
suite [52733,52883]
===
match
---
name: schedulable_tis [47592,47607]
name: schedulable_tis [47592,47607]
===
match
---
trailer [32550,32555]
trailer [32550,32555]
===
match
---
operator: , [24767,24768]
operator: , [24767,24768]
===
match
---
trailer [63253,63257]
trailer [63205,63209]
===
match
---
trailer [35485,35492]
trailer [35485,35492]
===
match
---
operator: == [78855,78857]
operator: == [78807,78809]
===
match
---
atom_expr [77095,77105]
atom_expr [77047,77057]
===
match
---
operator: { [42941,42942]
operator: { [42941,42942]
===
match
---
parameters [81040,81046]
parameters [80992,80998]
===
match
---
name: context [48877,48884]
name: context [48877,48884]
===
match
---
name: Optional [74553,74561]
name: Optional [74505,74513]
===
match
---
name: dag [60448,60451]
name: dag [60400,60403]
===
match
---
atom_expr [44324,44397]
atom_expr [44324,44397]
===
match
---
argument [37562,37580]
argument [37562,37580]
===
match
---
operator: == [24921,24923]
operator: == [24921,24923]
===
match
---
trailer [10318,10327]
trailer [10318,10327]
===
match
---
testlist_comp [10610,10898]
testlist_comp [10610,10898]
===
match
---
trailer [41586,41595]
trailer [41586,41595]
===
match
---
suite [80267,80315]
suite [80219,80267]
===
match
---
name: task [71817,71821]
name: task [71769,71773]
===
match
---
trailer [80055,80067]
trailer [80007,80019]
===
match
---
if_stmt [70529,72380]
if_stmt [70481,72332]
===
match
---
operator: = [60367,60368]
operator: = [60319,60320]
===
match
---
trailer [43048,43069]
trailer [43048,43069]
===
match
---
suite [41213,41308]
suite [41213,41308]
===
match
---
name: State [29098,29103]
name: State [29098,29103]
===
match
---
funcdef [48090,50735]
funcdef [48090,50773]
===
match
---
atom_expr [45013,45024]
atom_expr [45013,45024]
===
match
---
atom_expr [49012,49084]
atom_expr [49012,49084]
===
match
---
simple_stmt [10155,10189]
simple_stmt [10155,10189]
===
match
---
name: mark_success [18053,18065]
name: mark_success [18053,18065]
===
match
---
not_test [40773,40786]
not_test [40773,40786]
===
match
---
operator: @ [80846,80847]
operator: @ [80798,80799]
===
match
---
name: self [37625,37629]
name: self [37625,37629]
===
match
---
simple_stmt [54957,54974]
simple_stmt [54956,54973]
===
match
---
name: Optional [59236,59244]
name: Optional [59188,59196]
===
match
---
atom_expr [43044,43071]
atom_expr [43044,43071]
===
match
---
name: session [36087,36094]
name: session [36087,36094]
===
match
---
atom [67563,67603]
atom [67515,67555]
===
match
---
name: state [20597,20602]
name: state [20597,20602]
===
match
---
trailer [78762,78953]
trailer [78714,78905]
===
match
---
suite [7897,7981]
suite [7897,7981]
===
match
---
simple_stmt [1202,1260]
simple_stmt [1202,1260]
===
match
---
name: try_number [12063,12073]
name: try_number [12063,12073]
===
match
---
expr_stmt [43612,43638]
expr_stmt [43612,43638]
===
match
---
trailer [30113,30119]
trailer [30113,30119]
===
match
---
trailer [72009,72015]
trailer [71961,71967]
===
match
---
name: execution_date [35553,35567]
name: execution_date [35553,35567]
===
match
---
trailer [3953,3960]
trailer [3953,3960]
===
match
---
name: FAILED [52645,52651]
name: FAILED [52644,52650]
===
match
---
name: exception_html [71626,71640]
name: exception_html [71578,71592]
===
match
---
simple_stmt [6051,6069]
simple_stmt [6051,6069]
===
match
---
expr_stmt [71800,71840]
expr_stmt [71752,71792]
===
match
---
operator: = [46203,46204]
operator: = [46203,46204]
===
match
---
trailer [78667,78674]
trailer [78619,78626]
===
match
---
operator: = [60128,60129]
operator: = [60080,60081]
===
match
---
expr_stmt [23592,23622]
expr_stmt [23592,23622]
===
match
---
operator: = [15675,15676]
operator: = [15675,15676]
===
match
---
operator: = [21844,21845]
operator: = [21844,21845]
===
match
---
trailer [31902,31944]
trailer [31902,31944]
===
match
---
name: parse [1115,1120]
name: parse [1115,1120]
===
match
---
name: strftime [61682,61690]
name: strftime [61634,61642]
===
match
---
suite [79807,80562]
suite [79759,80514]
===
match
---
name: default_var [64561,64572]
name: default_var [64513,64524]
===
match
---
trailer [25392,25408]
trailer [25392,25408]
===
match
---
simple_stmt [64122,64138]
simple_stmt [64074,64090]
===
match
---
fstring_end: ' [57024,57025]
fstring_end: ' [57023,57024]
===
match
---
name: task_copy [48522,48531]
name: task_copy [48522,48531]
===
match
---
name: default_var [64350,64361]
name: default_var [64302,64313]
===
match
---
operator: , [37560,37561]
operator: , [37560,37561]
===
match
---
import_from [67280,67350]
import_from [67232,67302]
===
match
---
atom_expr [73083,73096]
atom_expr [73035,73048]
===
match
---
trailer [20298,20305]
trailer [20298,20305]
===
match
---
name: self [70580,70584]
name: self [70532,70536]
===
match
---
argument [74305,74323]
argument [74257,74275]
===
match
---
trailer [78902,78910]
trailer [78854,78862]
===
match
---
name: self [55763,55767]
name: self [55762,55766]
===
match
---
argument [46809,46831]
argument [46809,46831]
===
match
---
arglist [31903,31943]
arglist [31903,31943]
===
match
---
atom_expr [41478,41497]
atom_expr [41478,41497]
===
match
---
name: local [14265,14270]
name: local [14265,14270]
===
match
---
name: path [14755,14759]
name: path [14755,14759]
===
match
---
name: pod_mutation_hook [69060,69077]
name: pod_mutation_hook [69012,69029]
===
match
---
name: hr_line_break [40371,40384]
name: hr_line_break [40371,40384]
===
match
---
name: task_id [6903,6910]
name: task_id [6903,6910]
===
match
---
name: str [36066,36069]
name: str [36066,36069]
===
match
---
atom_expr [79154,79170]
atom_expr [79106,79122]
===
match
---
name: int [80069,80072]
name: int [80021,80024]
===
match
---
string: """Only Renders Templates for the TI""" [54909,54948]
string: """Only Renders Templates for the TI""" [54908,54947]
===
match
---
name: task [26843,26847]
name: task [26843,26847]
===
match
---
name: self [45135,45139]
name: self [45135,45139]
===
match
---
name: self [22080,22084]
name: self [22080,22084]
===
match
---
expr_stmt [76465,76707]
expr_stmt [76417,76659]
===
match
---
name: get_template_context [68228,68248]
name: get_template_context [68180,68200]
===
match
---
parameters [19912,19932]
parameters [19912,19932]
===
match
---
operator: , [15875,15876]
operator: , [15875,15876]
===
match
---
name: self [29526,29530]
name: self [29526,29530]
===
match
---
trailer [7725,7752]
trailer [7725,7752]
===
match
---
name: pendulum [30341,30349]
name: pendulum [30341,30349]
===
match
---
name: hostname [12174,12182]
name: hostname [12174,12182]
===
match
---
atom_expr [40739,40755]
atom_expr [40739,40755]
===
match
---
arglist [34620,34666]
arglist [34620,34666]
===
match
---
expr_stmt [82402,82421]
expr_stmt [82354,82373]
===
match
---
atom_expr [56197,56211]
atom_expr [56196,56210]
===
match
---
name: registered [49865,49875]
name: registered [49865,49875]
===
match
---
import_from [2490,2546]
import_from [2490,2546]
===
match
---
trailer [45551,45555]
trailer [45551,45555]
===
match
---
atom_expr [61938,61978]
atom_expr [61890,61930]
===
match
---
trailer [65519,65527]
trailer [65471,65479]
===
match
---
testlist_comp [18662,18676]
testlist_comp [18662,18676]
===
match
---
name: log [47630,47633]
name: log [47630,47633]
===
match
---
name: cmd [18377,18380]
name: cmd [18377,18380]
===
match
---
name: task [61423,61427]
name: task [61375,61379]
===
match
---
name: reschedule_exception [55188,55208]
name: reschedule_exception [55187,55207]
===
match
---
simple_stmt [32654,32890]
simple_stmt [32654,32890]
===
match
---
trailer [9932,9946]
trailer [9932,9946]
===
match
---
string: 'TaskInstance' [28635,28649]
string: 'TaskInstance' [28635,28649]
===
match
---
name: Index [10744,10749]
name: Index [10744,10749]
===
match
---
param [41909,41922]
param [41909,41922]
===
match
---
name: timezone [45109,45117]
name: timezone [45109,45117]
===
match
---
name: _queue [81388,81394]
name: _queue [81340,81346]
===
match
---
simple_stmt [50993,51010]
simple_stmt [51031,51048]
===
match
---
trailer [50675,50680]
trailer [50713,50718]
===
match
---
trailer [71078,71095]
trailer [71030,71047]
===
match
---
import_from [2171,2204]
import_from [2171,2204]
===
match
---
number: 2 [30875,30876]
number: 2 [30875,30876]
===
match
---
param [51168,51173]
param [51206,51211]
===
match
---
import_from [1018,1102]
import_from [1018,1102]
===
match
---
name: state [5202,5207]
name: state [5202,5207]
===
match
---
name: task [46717,46721]
name: task [46717,46721]
===
match
---
trailer [43092,43133]
trailer [43092,43133]
===
match
---
operator: , [62255,62256]
operator: , [62207,62208]
===
match
---
simple_stmt [2237,2288]
simple_stmt [2237,2288]
===
match
---
trailer [79615,79637]
trailer [79567,79589]
===
match
---
trailer [21526,21532]
trailer [21526,21532]
===
match
---
arglist [68479,69032]
arglist [68431,68984]
===
match
---
string: """Initialize the attributes that aren't stored in the DB""" [12539,12599]
string: """Initialize the attributes that aren't stored in the DB""" [12539,12599]
===
match
---
name: _executor_config [81539,81555]
name: _executor_config [81491,81507]
===
match
---
atom [35437,35599]
atom [35437,35599]
===
match
---
simple_stmt [35432,35600]
simple_stmt [35432,35600]
===
match
---
atom_expr [63001,63009]
atom_expr [62953,62961]
===
match
---
fstring [42930,42970]
fstring [42930,42970]
===
match
---
name: error_file [44787,44797]
name: error_file [44787,44797]
===
match
---
atom_expr [79332,79341]
atom_expr [79284,79293]
===
match
---
name: utils [2378,2383]
name: utils [2378,2383]
===
match
---
operator: , [29784,29785]
operator: , [29784,29785]
===
match
---
name: get_template_env [71822,71838]
name: get_template_env [71774,71790]
===
match
---
simple_stmt [34589,34668]
simple_stmt [34589,34668]
===
match
---
atom_expr [79202,79222]
atom_expr [79154,79174]
===
match
---
atom_expr [23376,23391]
atom_expr [23376,23391]
===
match
---
name: pool [41831,41835]
name: pool [41831,41835]
===
match
---
name: str [29210,29213]
name: str [29210,29213]
===
match
---
name: reschedule_date [55693,55708]
name: reschedule_date [55692,55707]
===
match
---
atom_expr [15008,15020]
atom_expr [15008,15020]
===
match
---
name: session [37654,37661]
name: session [37654,37661]
===
match
---
trailer [8581,8592]
trailer [8581,8592]
===
match
---
fstring_expr [62451,62462]
fstring_expr [62403,62414]
===
match
---
trailer [11831,11835]
trailer [11831,11835]
===
match
---
name: TaskFail [1945,1953]
name: TaskFail [1945,1953]
===
match
---
trailer [9511,9537]
trailer [9511,9537]
===
match
---
name: execute [51704,51711]
name: execute [51742,51749]
===
match
---
trailer [80164,80180]
trailer [80116,80132]
===
match
---
name: REQUEUEABLE_DEPS [2334,2350]
name: REQUEUEABLE_DEPS [2334,2350]
===
match
---
trailer [47738,47740]
trailer [47738,47740]
===
match
---
argument [30864,30876]
argument [30864,30876]
===
match
---
import_from [1394,1448]
import_from [1394,1448]
===
match
---
name: self [55062,55066]
name: self [55061,55065]
===
match
---
atom_expr [62436,62448]
atom_expr [62388,62400]
===
match
---
atom_expr [24011,24023]
atom_expr [24011,24023]
===
match
---
decorated [77979,79511]
decorated [77931,79463]
===
match
---
trailer [52164,52173]
trailer [52202,52211]
===
match
---
trailer [54821,54823]
trailer [54820,54822]
===
match
---
name: self [28038,28042]
name: self [28038,28042]
===
match
---
trailer [79057,79254]
trailer [79009,79206]
===
match
---
arglist [9845,9877]
arglist [9845,9877]
===
match
---
decorated [80753,80841]
decorated [80705,80793]
===
match
---
trailer [57116,57141]
trailer [57115,57140]
===
match
---
name: conf [71957,71961]
name: conf [71909,71913]
===
match
---
trailer [21865,21867]
trailer [21865,21867]
===
match
---
simple_stmt [32310,32322]
simple_stmt [32310,32322]
===
match
---
trailer [80008,80018]
trailer [79960,79970]
===
match
---
simple_stmt [2961,3015]
simple_stmt [2961,3015]
===
match
---
operator: , [43961,43962]
operator: , [43961,43962]
===
match
---
atom_expr [56615,56642]
atom_expr [56614,56641]
===
match
---
atom [25030,25063]
atom [25030,25063]
===
match
---
name: self [22667,22671]
name: self [22667,22671]
===
match
---
parameters [35688,36106]
parameters [35688,36106]
===
match
---
name: self [65709,65713]
name: self [65661,65665]
===
match
---
name: Integer [1305,1312]
name: Integer [1305,1312]
===
match
---
operator: = [59886,59887]
operator: = [59838,59839]
===
match
---
trailer [55462,55733]
trailer [55461,55732]
===
match
---
suite [70544,71437]
suite [70496,71389]
===
match
---
parameters [51167,51193]
parameters [51205,51231]
===
match
---
operator: , [37890,37891]
operator: , [37890,37891]
===
match
---
name: count [26399,26404]
name: count [26399,26404]
===
match
---
name: task [11296,11300]
name: task [11296,11300]
===
match
---
operator: = [5450,5451]
operator: = [5450,5451]
===
match
---
trailer [5492,5510]
trailer [5492,5510]
===
match
---
name: with_entities [77283,77296]
name: with_entities [77235,77248]
===
match
---
name: TR [6871,6873]
name: TR [6871,6873]
===
match
---
operator: , [54116,54117]
operator: , [54115,54116]
===
match
---
name: task_id [78456,78463]
name: task_id [78408,78415]
===
match
---
name: dag_id [9561,9567]
name: dag_id [9561,9567]
===
match
---
return_stmt [19102,19160]
return_stmt [19102,19160]
===
match
---
operator: = [10409,10410]
operator: = [10409,10410]
===
match
---
name: timezone [35113,35121]
name: timezone [35113,35121]
===
match
---
subscriptlist [52404,52418]
subscriptlist [52403,52417]
===
match
---
string: 'dag_run_conf_overrides_params' [62564,62595]
string: 'dag_run_conf_overrides_params' [62516,62547]
===
match
---
param [4741,4745]
param [4741,4745]
===
match
---
name: query [77061,77066]
name: query [77013,77018]
===
match
---
suite [68121,68302]
suite [68073,68254]
===
match
---
name: task_id [77086,77093]
name: task_id [77038,77045]
===
match
---
name: execution_date [19552,19566]
name: execution_date [19552,19566]
===
match
---
name: taskreschedule [1974,1988]
name: taskreschedule [1974,1988]
===
match
---
simple_stmt [79953,79996]
simple_stmt [79905,79948]
===
match
---
string: """         The task instance for the task that ran before this task instance.          :param state: If passed, it only take into account instances of a specific state.         :param session: SQLAlchemy ORM Session         """ [26595,26823]
string: """         The task instance for the task that ran before this task instance.          :param state: If passed, it only take into account instances of a specific state.         :param session: SQLAlchemy ORM Session         """ [26595,26823]
===
match
---
import_as_names [1652,1810]
import_as_names [1652,1810]
===
match
---
simple_stmt [8285,8339]
simple_stmt [8285,8339]
===
match
---
string: """         This attribute is deprecated.         Please use `airflow.models.taskinstance.TaskInstance.get_previous_ti` method.         """ [28660,28799]
string: """         This attribute is deprecated.         Please use `airflow.models.taskinstance.TaskInstance.get_previous_ti` method.         """ [28660,28799]
===
match
---
atom_expr [19035,19093]
atom_expr [19035,19093]
===
match
---
expr_stmt [45093,45126]
expr_stmt [45093,45126]
===
match
---
argument [11055,11068]
argument [11055,11068]
===
match
---
operator: = [33331,33332]
operator: = [33331,33332]
===
match
---
atom_expr [50638,50699]
atom_expr [50676,50737]
===
match
---
operator: = [16016,16017]
operator: = [16016,16017]
===
match
---
atom_expr [50823,50877]
atom_expr [50861,50915]
===
match
---
atom_expr [59060,59079]
atom_expr [59012,59031]
===
match
---
atom_expr [43304,43320]
atom_expr [43304,43320]
===
match
---
name: Index [10815,10820]
name: Index [10815,10820]
===
match
---
name: State [7496,7501]
name: State [7496,7501]
===
match
---
name: e [66786,66787]
name: e [66738,66739]
===
match
---
param [59662,59667]
param [59614,59619]
===
match
---
trailer [79273,79510]
trailer [79225,79462]
===
match
---
name: task_copy [55043,55052]
name: task_copy [55042,55051]
===
match
---
comparison [35523,35567]
comparison [35523,35567]
===
match
---
operator: = [15977,15978]
operator: = [15977,15978]
===
match
---
atom_expr [73012,73025]
atom_expr [72964,72977]
===
match
---
name: context [50597,50604]
name: context [50635,50642]
===
match
---
atom_expr [25347,25357]
atom_expr [25347,25357]
===
match
---
string: '%Y-%m-%d' [60698,60708]
string: '%Y-%m-%d' [60650,60660]
===
match
---
operator: , [69466,69467]
operator: , [69418,69419]
===
match
---
name: job_id [54560,54566]
name: job_id [54559,54565]
===
match
---
operator: { [7796,7797]
operator: { [7796,7797]
===
match
---
name: session [39231,39238]
name: session [39231,39238]
===
match
---
return_stmt [14933,15487]
return_stmt [14933,15487]
===
match
---
fstring_end: " [19159,19160]
fstring_end: " [19159,19160]
===
match
---
operator: = [14249,14250]
operator: = [14249,14250]
===
match
---
name: subject [71166,71173]
name: subject [71118,71125]
===
match
---
name: self [57135,57139]
name: self [57134,57138]
===
match
---
trailer [29540,29578]
trailer [29540,29578]
===
match
---
name: State [6028,6033]
name: State [6028,6033]
===
match
---
param [33124,33128]
param [33124,33128]
===
match
---
atom_expr [4321,4342]
atom_expr [4321,4342]
===
match
---
expr_stmt [66376,66461]
expr_stmt [66328,66413]
===
match
---
name: count [77604,77609]
name: count [77556,77561]
===
match
---
name: replace [62379,62386]
name: replace [62331,62338]
===
match
---
name: log [24138,24141]
name: log [24138,24141]
===
match
---
name: var [63132,63135]
name: var [63084,63087]
===
match
---
name: execution_date [6775,6789]
name: execution_date [6775,6789]
===
match
---
trailer [22098,22107]
trailer [22098,22107]
===
match
---
name: _Variable__NO_DEFAULT_SENTINEL [63429,63459]
name: _Variable__NO_DEFAULT_SENTINEL [63381,63411]
===
match
---
decorated [53391,54877]
decorated [53390,54876]
===
match
---
operator: , [74389,74390]
operator: , [74341,74342]
===
match
---
operator: , [56864,56865]
operator: , [56863,56864]
===
match
---
trailer [50954,50956]
trailer [50992,50994]
===
match
---
fstring [14762,14791]
fstring [14762,14791]
===
match
---
name: airflow [2210,2217]
name: airflow [2210,2217]
===
match
---
operator: , [64020,64021]
operator: , [63972,63973]
===
match
---
trailer [27905,27925]
trailer [27905,27925]
===
match
---
trailer [64197,64207]
trailer [64149,64159]
===
match
---
trailer [71309,71316]
trailer [71261,71268]
===
match
---
simple_stmt [63649,63878]
simple_stmt [63601,63830]
===
match
---
fstring_string: .log [19155,19159]
fstring_string: .log [19155,19159]
===
match
---
parameters [63214,63220]
parameters [63166,63172]
===
match
---
trailer [72941,72950]
trailer [72893,72902]
===
match
---
trailer [72661,72701]
trailer [72613,72653]
===
match
---
name: set_error_file [4282,4296]
name: set_error_file [4282,4296]
===
match
---
name: try_number [6126,6136]
name: try_number [6126,6136]
===
match
---
atom_expr [54750,54763]
atom_expr [54749,54762]
===
match
---
parameters [66227,66233]
parameters [66179,66185]
===
match
---
name: overwrite_params_with_dag_run_conf [62615,62649]
name: overwrite_params_with_dag_run_conf [62567,62601]
===
match
---
suite [32932,32970]
suite [32932,32970]
===
match
---
name: BooleanClauseList [1528,1545]
name: BooleanClauseList [1528,1545]
===
match
---
operator: , [53501,53502]
operator: , [53500,53501]
===
match
---
operator: , [53540,53541]
operator: , [53539,53540]
===
match
---
trailer [32824,32831]
trailer [32824,32831]
===
match
---
expr_stmt [9633,9687]
expr_stmt [9633,9687]
===
match
---
fstring_end: " [14790,14791]
fstring_end: " [14790,14791]
===
match
---
name: execution_date [73199,73213]
name: execution_date [73151,73165]
===
match
---
simple_stmt [43333,43340]
simple_stmt [43333,43340]
===
match
---
name: end_date [24961,24969]
name: end_date [24961,24969]
===
match
---
trailer [44328,44343]
trailer [44328,44343]
===
match
---
simple_stmt [52938,52955]
simple_stmt [52937,52954]
===
match
---
name: Union [52398,52403]
name: Union [52397,52402]
===
match
---
name: DepContext [2277,2287]
name: DepContext [2277,2287]
===
match
---
name: dag_id [6683,6689]
name: dag_id [6683,6689]
===
match
---
atom_expr [68566,68577]
atom_expr [68518,68529]
===
match
---
name: List [16109,16113]
name: List [16109,16113]
===
match
---
name: State [58228,58233]
name: State [58227,58232]
===
match
---
name: task [26412,26416]
name: task [26412,26416]
===
match
---
trailer [40059,40063]
trailer [40059,40063]
===
match
---
atom_expr [65998,66020]
atom_expr [65950,65972]
===
match
---
name: self [72953,72957]
name: self [72905,72909]
===
match
---
argument [38615,38630]
argument [38615,38630]
===
match
---
name: t [78728,78729]
name: t [78680,78681]
===
match
---
operator: @ [12488,12489]
operator: @ [12488,12489]
===
match
---
arglist [44905,44940]
arglist [44905,44940]
===
match
---
not_test [45517,45530]
not_test [45517,45530]
===
match
---
name: delay [34680,34685]
name: delay [34680,34685]
===
match
---
name: are_dependencies_met [38536,38556]
name: are_dependencies_met [38536,38556]
===
match
---
name: task [62436,62440]
name: task [62388,62392]
===
match
---
atom_expr [57041,57066]
atom_expr [57040,57065]
===
match
---
operator: , [10954,10955]
operator: , [10954,10955]
===
match
---
operator: , [36003,36004]
operator: , [36003,36004]
===
match
---
expr_stmt [55763,55799]
expr_stmt [55762,55798]
===
match
---
atom_expr [40881,40889]
atom_expr [40881,40889]
===
match
---
operator: = [51907,51908]
operator: = [51945,51946]
===
match
---
operator: = [54278,54279]
operator: = [54277,54278]
===
match
---
atom_expr [72937,72950]
atom_expr [72889,72902]
===
match
---
trailer [32783,32792]
trailer [32783,32792]
===
match
---
name: Optional [36057,36065]
name: Optional [36057,36065]
===
match
---
trailer [62555,62596]
trailer [62507,62548]
===
match
---
operator: , [10101,10102]
operator: , [10101,10102]
===
match
---
name: instance [64799,64807]
name: instance [64751,64759]
===
match
---
decorators [41636,41679]
decorators [41636,41679]
===
match
---
atom_expr [24817,24832]
atom_expr [24817,24832]
===
match
---
name: dag [60256,60259]
name: dag [60208,60211]
===
match
---
simple_stmt [62405,62464]
simple_stmt [62357,62416]
===
match
---
name: xcom [77332,77336]
name: xcom [77284,77288]
===
match
---
name: TaskInstance [26117,26129]
name: TaskInstance [26117,26129]
===
match
---
atom_expr [6866,6925]
atom_expr [6866,6925]
===
match
---
trailer [79334,79341]
trailer [79286,79293]
===
match
---
expr_stmt [72303,72379]
expr_stmt [72255,72331]
===
match
---
name: self [24910,24914]
name: self [24910,24914]
===
match
---
name: State [26332,26337]
name: State [26332,26337]
===
match
---
operator: , [33928,33929]
operator: , [33928,33929]
===
match
---
simple_stmt [37975,38023]
simple_stmt [37975,38023]
===
match
---
name: Column [10023,10029]
name: Column [10023,10029]
===
match
---
comp_if [47299,47338]
comp_if [47299,47338]
===
match
---
atom_expr [57121,57133]
atom_expr [57120,57132]
===
match
---
trailer [25408,25410]
trailer [25408,25410]
===
match
---
operator: @ [25113,25114]
operator: @ [25113,25114]
===
match
---
arglist [23955,24080]
arglist [23955,24080]
===
match
---
simple_stmt [80456,80499]
simple_stmt [80408,80451]
===
match
---
trailer [8192,8212]
trailer [8192,8212]
===
match
---
trailer [45627,45634]
trailer [45627,45634]
===
match
---
name: session [59415,59422]
name: session [59367,59374]
===
match
---
operator: = [3224,3225]
operator: = [3224,3225]
===
match
---
simple_stmt [31066,31699]
simple_stmt [31066,31699]
===
match
---
string: """Get Airflow Variable after deserializing JSON value""" [64449,64506]
string: """Get Airflow Variable after deserializing JSON value""" [64401,64458]
===
match
---
operator: = [15220,15221]
operator: = [15220,15221]
===
match
---
name: prev_ti [30359,30366]
name: prev_ti [30359,30366]
===
match
---
name: queue [23297,23302]
name: queue [23297,23302]
===
match
---
name: self [63927,63931]
name: self [63879,63883]
===
match
---
name: primary_key [9611,9622]
name: primary_key [9611,9622]
===
match
---
testlist_comp [26317,26345]
testlist_comp [26317,26345]
===
match
---
and_test [11480,11540]
and_test [11480,11540]
===
match
---
name: pod [68433,68436]
name: pod [68385,68388]
===
match
---
trailer [27162,27177]
trailer [27162,27177]
===
match
---
trailer [11794,11805]
trailer [11794,11805]
===
match
---
string: """Write error into error file by path""" [4357,4398]
string: """Write error into error file by path""" [4357,4398]
===
match
---
string: 'ti_successes' [50719,50733]
string: 'ti_successes' [50757,50771]
===
match
---
subscriptlist [79616,79636]
subscriptlist [79568,79588]
===
match
---
funcdef [18907,19161]
funcdef [18907,19161]
===
match
---
annassign [80333,80348]
annassign [80285,80300]
===
match
---
name: encode [34011,34017]
name: encode [34011,34017]
===
match
---
operator: , [22920,22921]
operator: , [22920,22921]
===
match
---
operator: = [42786,42787]
operator: = [42786,42787]
===
match
---
name: dr [35616,35618]
name: dr [35616,35618]
===
match
---
name: log [40582,40585]
name: log [40582,40585]
===
match
---
operator: , [72461,72462]
operator: , [72413,72414]
===
match
---
name: Stats [42919,42924]
name: Stats [42919,42924]
===
match
---
operator: , [45297,45298]
operator: , [45297,45298]
===
match
---
operator: = [53330,53331]
operator: = [53329,53330]
===
match
---
if_stmt [71896,72065]
if_stmt [71848,72017]
===
match
---
atom_expr [66699,66722]
atom_expr [66651,66674]
===
match
---
name: default_var [63401,63412]
name: default_var [63353,63364]
===
match
---
suite [46029,47741]
suite [46029,47741]
===
match
---
expr_stmt [9451,9482]
expr_stmt [9451,9482]
===
match
---
trailer [10615,10646]
trailer [10615,10646]
===
match
---
atom_expr [23519,23531]
atom_expr [23519,23531]
===
match
---
param [53467,53472]
param [53466,53471]
===
match
---
operator: , [71973,71974]
operator: , [71925,71926]
===
match
---
trailer [3689,3691]
trailer [3689,3691]
===
match
---
name: values_ordered_by_id [77134,77154]
name: values_ordered_by_id [77086,77106]
===
match
---
funcdef [30979,32322]
funcdef [30979,32322]
===
match
---
trailer [20561,20564]
trailer [20561,20564]
===
match
---
name: self [23279,23283]
name: self [23279,23283]
===
match
---
name: self [19122,19126]
name: self [19122,19126]
===
match
---
param [69221,69230]
param [69173,69182]
===
match
---
trailer [56987,57032]
trailer [56986,57031]
===
match
---
name: self [79783,79787]
name: self [79735,79739]
===
match
---
simple_stmt [43088,43149]
simple_stmt [43088,43149]
===
match
---
name: self [56437,56441]
name: self [56436,56440]
===
match
---
string: """         Generates the shell command required to execute this task instance.          :param dag_id: DAG ID         :type dag_id: str         :param task_id: Task ID         :type task_id: str         :param execution_date: Execution date for the task         :type execution_date: datetime         :param mark_success: Whether to mark the task as successful         :type mark_success: bool         :param ignore_all_deps: Ignore all ignorable dependencies.             Overrides the other ignore_* parameters.         :type ignore_all_deps: bool         :param ignore_depends_on_past: Ignore depends_on_past parameter of DAGs             (e.g. for Backfills)         :type ignore_depends_on_past: bool         :param ignore_task_deps: Ignore task-specific dependencies such as depends_on_past             and trigger rule         :type ignore_task_deps: bool         :param ignore_ti_state: Ignore the task instance's previous failure/success         :type ignore_ti_state: bool         :param local: Whether to run the task locally         :type local: bool         :param pickle_id: If the DAG was serialized to the DB, the ID             associated with the pickled DAG         :type pickle_id: Optional[int]         :param file_path: path to the file containing the DAG definition         :type file_path: Optional[str]         :param raw: raw mode (needs more details)         :type raw: Optional[bool]         :param job_id: job ID (needs more details)         :type job_id: Optional[int]         :param pool: the Airflow pool that the task should run in         :type pool: Optional[str]         :param cfg_path: the Path to the configuration file         :type cfg_path: Optional[str]         :return: shell command that can be used to run the task instance         :rtype: list[str]         """ [16128,17936]
string: """         Generates the shell command required to execute this task instance.          :param dag_id: DAG ID         :type dag_id: str         :param task_id: Task ID         :type task_id: str         :param execution_date: Execution date for the task         :type execution_date: datetime         :param mark_success: Whether to mark the task as successful         :type mark_success: bool         :param ignore_all_deps: Ignore all ignorable dependencies.             Overrides the other ignore_* parameters.         :type ignore_all_deps: bool         :param ignore_depends_on_past: Ignore depends_on_past parameter of DAGs             (e.g. for Backfills)         :type ignore_depends_on_past: bool         :param ignore_task_deps: Ignore task-specific dependencies such as depends_on_past             and trigger rule         :type ignore_task_deps: bool         :param ignore_ti_state: Ignore the task instance's previous failure/success         :type ignore_ti_state: bool         :param local: Whether to run the task locally         :type local: bool         :param pickle_id: If the DAG was serialized to the DB, the ID             associated with the pickled DAG         :type pickle_id: Optional[int]         :param file_path: path to the file containing the DAG definition         :type file_path: Optional[str]         :param raw: raw mode (needs more details)         :type raw: Optional[bool]         :param job_id: job ID (needs more details)         :type job_id: Optional[int]         :param pool: the Airflow pool that the task should run in         :type pool: Optional[str]         :param cfg_path: the Path to the configuration file         :type cfg_path: Optional[str]         :return: shell command that can be used to run the task instance         :rtype: list[str]         """ [16128,17936]
===
match
---
operator: { [19428,19429]
operator: { [19428,19429]
===
match
---
atom_expr [49535,49573]
atom_expr [49535,49573]
===
match
---
atom_expr [24326,24337]
atom_expr [24326,24337]
===
match
---
operator: @ [28579,28580]
operator: @ [28579,28580]
===
match
---
trailer [79291,79474]
trailer [79243,79426]
===
match
---
argument [70894,70924]
argument [70846,70876]
===
match
---
return_stmt [72389,72435]
return_stmt [72341,72387]
===
match
---
expr_stmt [23311,23349]
expr_stmt [23311,23349]
===
match
---
name: lock_for_update [82275,82290]
name: lock_for_update [82227,82242]
===
match
---
name: self [22761,22765]
name: self [22761,22765]
===
match
---
operator: == [25358,25360]
operator: == [25358,25360]
===
match
---
trailer [30325,30336]
trailer [30325,30336]
===
match
---
name: dag [60209,60212]
name: dag [60161,60164]
===
match
---
operator: = [54223,54224]
operator: = [54222,54223]
===
match
---
atom_expr [45311,45323]
atom_expr [45311,45323]
===
match
---
simple_stmt [20965,20985]
simple_stmt [20965,20985]
===
match
---
fstring_end: " [62462,62463]
fstring_end: " [62414,62415]
===
match
---
simple_stmt [28544,28574]
simple_stmt [28544,28574]
===
match
---
expr_stmt [7629,7874]
expr_stmt [7629,7874]
===
match
---
name: reason [32168,32174]
name: reason [32168,32174]
===
match
---
arglist [60436,60494]
arglist [60388,60446]
===
match
---
name: session [32614,32621]
name: session [32614,32621]
===
match
---
name: self [8577,8581]
name: self [8577,8581]
===
match
---
operator: = [74410,74411]
operator: = [74362,74363]
===
match
---
name: self [80189,80193]
name: self [80141,80145]
===
match
---
not_test [4102,4110]
not_test [4102,4110]
===
match
---
name: dag [14830,14833]
name: dag [14830,14833]
===
match
---
name: TaskInstanceStateType [79586,79607]
name: TaskInstanceStateType [79538,79559]
===
match
---
trailer [73223,73233]
trailer [73175,73185]
===
match
---
operator: , [73169,73170]
operator: , [73121,73122]
===
match
---
name: pickle [4156,4162]
name: pickle [4156,4162]
===
match
---
name: _priority_weight [80461,80477]
name: _priority_weight [80413,80429]
===
match
---
decorator [80607,80617]
decorator [80559,80569]
===
match
---
if_stmt [34744,34836]
if_stmt [34744,34836]
===
match
---
return_stmt [80727,80747]
return_stmt [80679,80699]
===
match
---
atom_expr [13318,13334]
atom_expr [13318,13334]
===
match
---
suite [43511,43545]
suite [43511,43545]
===
match
---
name: cfg_path [18810,18818]
name: cfg_path [18810,18818]
===
match
---
operator: , [77455,77456]
operator: , [77407,77408]
===
match
---
term [33693,33745]
term [33693,33745]
===
match
---
if_stmt [6159,7315]
if_stmt [6159,7315]
===
match
---
name: airflow [2755,2762]
name: airflow [2755,2762]
===
match
---
operator: = [35435,35436]
operator: = [35435,35436]
===
match
---
name: Column [10076,10082]
name: Column [10076,10082]
===
match
---
name: dry_run [54886,54893]
name: dry_run [54885,54892]
===
match
---
atom_expr [72920,72933]
atom_expr [72872,72885]
===
match
---
atom_expr [80280,80297]
atom_expr [80232,80249]
===
match
---
param [24431,24436]
param [24431,24436]
===
match
---
name: execution_date [21751,21765]
name: execution_date [21751,21765]
===
match
---
name: ti [5592,5594]
name: ti [5592,5594]
===
match
---
operator: , [10836,10837]
operator: , [10836,10837]
===
match
---
expr_stmt [72920,72985]
expr_stmt [72872,72937]
===
match
---
trailer [24097,24099]
trailer [24097,24099]
===
match
---
atom_expr [55476,55723]
atom_expr [55475,55722]
===
match
---
number: 0 [20562,20563]
number: 0 [20562,20563]
===
match
---
name: dag_id [58508,58514]
name: dag_id [58507,58513]
===
match
---
simple_stmt [4002,4046]
simple_stmt [4002,4046]
===
match
---
name: prev_execution_date [62085,62104]
name: prev_execution_date [62037,62056]
===
match
---
trailer [24015,24023]
trailer [24015,24023]
===
match
---
simple_stmt [46648,46901]
simple_stmt [46648,46901]
===
match
---
trailer [44999,45055]
trailer [44999,45055]
===
match
---
name: Integer [10180,10187]
name: Integer [10180,10187]
===
match
---
trailer [10036,10041]
trailer [10036,10041]
===
match
---
name: job_id [18244,18250]
name: job_id [18244,18250]
===
match
---
trailer [48452,48456]
trailer [48452,48456]
===
match
---
name: ti [5372,5374]
name: ti [5372,5374]
===
match
---
parameters [67791,67814]
parameters [67743,67766]
===
match
---
atom_expr [45337,45374]
atom_expr [45337,45374]
===
match
---
argument [38574,38613]
argument [38574,38613]
===
match
---
simple_stmt [28660,28800]
simple_stmt [28660,28800]
===
match
---
name: self [45676,45680]
name: self [45676,45680]
===
match
---
name: test_mode [12613,12622]
name: test_mode [12613,12622]
===
match
---
name: append [3584,3590]
name: append [3584,3590]
===
match
---
trailer [58633,58664]
trailer [58632,58663]
===
match
---
operator: , [71604,71605]
operator: , [71556,71557]
===
match
---
string: """         Checks on whether the task instance is in the right state and timeframe         to be retried.         """ [34913,35031]
string: """         Checks on whether the task instance is in the right state and timeframe         to be retried.         """ [34913,35031]
===
match
---
simple_stmt [16128,17937]
simple_stmt [16128,17937]
===
match
---
atom_expr [41801,41814]
atom_expr [41801,41814]
===
match
---
trailer [26189,26215]
trailer [26189,26215]
===
match
---
trailer [33682,33747]
trailer [33682,33747]
===
match
---
atom_expr [31874,31944]
atom_expr [31874,31944]
===
match
---
simple_stmt [22120,22142]
simple_stmt [22120,22142]
===
match
---
string: 'start_date' [45408,45420]
string: 'start_date' [45408,45420]
===
match
---
simple_stmt [60547,60592]
simple_stmt [60499,60544]
===
match
---
operator: , [11068,11069]
operator: , [11068,11069]
===
match
---
atom_expr [50574,50628]
atom_expr [50612,50666]
===
match
---
name: warning [11563,11570]
name: warning [11563,11570]
===
match
---
name: models [1967,1973]
name: models [1967,1973]
===
match
---
name: log [23875,23878]
name: log [23875,23878]
===
match
---
string: 'outlets' [65041,65050]
string: 'outlets' [64993,65002]
===
match
---
name: Optional [28626,28634]
name: Optional [28626,28634]
===
match
---
name: error [52260,52265]
name: exception [52291,52300]
===
match
---
name: str [24444,24447]
name: str [24444,24447]
===
match
---
operator: = [3199,3200]
operator: = [3199,3200]
===
match
---
name: _try_number [22329,22340]
name: _try_number [22329,22340]
===
match
---
trailer [33819,34091]
trailer [33819,34091]
===
match
---
decorator [13904,13914]
decorator [13904,13914]
===
match
---
simple_stmt [58364,58734]
simple_stmt [58363,58733]
===
match
---
arglist [61748,61755]
arglist [61700,61707]
===
match
---
atom_expr [72166,72209]
atom_expr [72118,72161]
===
match
---
operator: = [56887,56888]
operator: = [56886,56887]
===
match
---
trailer [24976,24985]
trailer [24976,24985]
===
match
---
operator: = [61353,61354]
operator: = [61305,61306]
===
match
---
parameters [63903,63909]
parameters [63855,63861]
===
match
---
tfpdef [15600,15612]
tfpdef [15600,15612]
===
match
---
name: self [48135,48139]
name: self [48135,48139]
===
match
---
name: macros [60025,60031]
name: macros [59977,59983]
===
match
---
name: dag_ids [76569,76576]
name: dag_ids [76521,76528]
===
match
---
atom_expr [47524,47546]
atom_expr [47524,47546]
===
match
---
trailer [35088,35108]
trailer [35088,35108]
===
match
---
atom_expr [20258,20513]
atom_expr [20258,20513]
===
match
---
name: schedulable_tis [47283,47298]
name: schedulable_tis [47283,47298]
===
match
---
atom_expr [64852,64863]
atom_expr [64804,64815]
===
match
---
name: commit [59096,59102]
name: commit [59048,59054]
===
match
---
operator: = [15467,15468]
operator: = [15467,15468]
===
match
---
operator: { [76966,76967]
operator: { [76918,76919]
===
match
---
name: RenderedTaskInstanceFields [66340,66366]
name: RenderedTaskInstanceFields [66292,66318]
===
match
---
name: self [29071,29075]
name: self [29071,29075]
===
match
---
number: 2 [28523,28524]
number: 2 [28523,28524]
===
match
---
trailer [23380,23391]
trailer [23380,23391]
===
match
---
name: str [73166,73169]
name: str [73118,73121]
===
match
---
name: airflow [48211,48218]
name: airflow [48211,48218]
===
match
---
trailer [26416,26436]
trailer [26416,26436]
===
match
---
name: replace [69516,69523]
name: replace [69468,69475]
===
match
---
name: State [57121,57126]
name: State [57120,57125]
===
match
---
atom_expr [4681,4708]
atom_expr [4681,4708]
===
match
---
operator: = [69448,69449]
operator: = [69400,69401]
===
match
---
name: self [40846,40850]
name: self [40846,40850]
===
match
---
atom_expr [31736,31748]
atom_expr [31736,31748]
===
match
---
name: filter_by [46162,46171]
name: filter_by [46162,46171]
===
match
---
expr_stmt [63001,63016]
expr_stmt [62953,62968]
===
match
---
suite [81198,81225]
suite [81150,81177]
===
match
---
simple_stmt [43034,43072]
simple_stmt [43034,43072]
===
match
---
param [23675,23687]
param [23675,23687]
===
match
---
atom_expr [33816,34091]
atom_expr [33816,34091]
===
match
---
name: commit [55993,55999]
name: commit [55992,55998]
===
match
---
string: """Send alert email with exception information.""" [72483,72533]
string: """Send alert email with exception information.""" [72435,72485]
===
match
---
arglist [40093,40319]
arglist [40093,40319]
===
match
---
suite [80893,80926]
suite [80845,80878]
===
match
---
operator: , [1785,1786]
operator: , [1785,1786]
===
match
---
name: _date_or_empty [45393,45407]
name: _date_or_empty [45393,45407]
===
match
---
operator: = [32473,32474]
operator: = [32473,32474]
===
match
---
atom_expr [24060,24079]
atom_expr [24060,24079]
===
match
---
trailer [39088,39095]
trailer [39088,39095]
===
match
---
trailer [29601,29617]
trailer [29601,29617]
===
match
---
simple_stmt [69241,69293]
simple_stmt [69193,69245]
===
match
---
trailer [20441,20456]
trailer [20441,20456]
===
match
---
trailer [11382,11398]
trailer [11382,11398]
===
match
---
string: 'Exception:<br>{{exception_html}}<br>' [69853,69891]
string: 'Exception:<br>{{exception_html}}<br>' [69805,69843]
===
match
---
comparison [21640,21674]
comparison [21640,21674]
===
match
---
trailer [45680,45715]
trailer [45680,45715]
===
match
---
name: state [65508,65513]
name: state [65460,65465]
===
match
---
trailer [78968,79032]
trailer [78920,78984]
===
match
---
try_stmt [54372,54877]
try_stmt [54371,54876]
===
match
---
name: ti [5966,5968]
name: ti [5966,5968]
===
match
---
operator: , [29184,29185]
operator: , [29184,29185]
===
match
---
argument [44358,44373]
argument [44358,44373]
===
match
---
name: log [50828,50831]
name: log [50866,50869]
===
match
---
atom_expr [64790,64828]
atom_expr [64742,64780]
===
match
---
name: key [80558,80561]
name: key [80510,80513]
===
match
---
name: dag_id [26130,26136]
name: dag_id [26130,26136]
===
match
---
decorator [28095,28105]
decorator [28095,28105]
===
match
---
arglist [9657,9686]
arglist [9657,9686]
===
match
---
name: self [80051,80055]
name: self [80003,80007]
===
match
---
name: self [45486,45490]
name: self [45486,45490]
===
match
---
param [32382,32399]
param [32382,32399]
===
match
---
atom_expr [82100,82119]
atom_expr [82052,82071]
===
match
---
name: query [77277,77282]
name: query [77229,77234]
===
match
---
name: execution_date [68703,68717]
name: execution_date [68655,68669]
===
match
---
trailer [28821,29055]
trailer [28821,29055]
===
match
---
operator: , [36077,36078]
operator: , [36077,36078]
===
match
---
arith_expr [38253,38284]
arith_expr [38253,38284]
===
match
---
operator: = [38317,38318]
operator: = [38317,38318]
===
match
---
trailer [10144,10149]
trailer [10144,10149]
===
match
---
name: session [6051,6058]
name: session [6051,6058]
===
match
---
operator: - [60799,60800]
operator: - [60751,60752]
===
match
---
name: error_file [44919,44929]
name: error_file [44919,44929]
===
match
---
fstring_start: f" [19772,19774]
fstring_start: f" [19772,19774]
===
match
---
name: State [7921,7926]
name: State [7921,7926]
===
match
---
not_test [38035,38051]
not_test [38035,38051]
===
match
---
atom_expr [58618,58664]
atom_expr [58617,58663]
===
match
---
name: registered [50216,50226]
name: registered [50254,50264]
===
match
---
simple_stmt [60664,60710]
simple_stmt [60616,60662]
===
match
---
name: downstream_task_ids [47191,47210]
name: downstream_task_ids [47191,47210]
===
match
---
operator: , [31040,31041]
operator: , [31040,31041]
===
match
---
simple_stmt [61991,62033]
simple_stmt [61943,61985]
===
match
---
string: "/success" [19673,19683]
string: "/success" [19673,19683]
===
match
---
trailer [26103,26358]
trailer [26103,26358]
===
match
---
atom_expr [58528,58540]
atom_expr [58527,58539]
===
match
---
atom_expr [19746,19757]
atom_expr [19746,19757]
===
match
---
name: filter [7425,7431]
name: filter [7425,7431]
===
match
---
name: get_dagrun [26890,26900]
name: get_dagrun [26890,26900]
===
match
---
name: dag_id [7730,7736]
name: dag_id [7730,7736]
===
match
---
name: task [55036,55040]
name: task [55035,55039]
===
match
---
suite [53846,54877]
suite [53845,54876]
===
match
---
operator: , [6807,6808]
operator: , [6807,6808]
===
match
---
name: self [73041,73045]
name: self [72993,72997]
===
match
---
name: context [43034,43041]
name: context [43034,43041]
===
match
---
operator: == [20457,20459]
operator: == [20457,20459]
===
match
---
decorator [80679,80689]
decorator [80631,80641]
===
match
---
name: log [22883,22886]
name: log [22883,22886]
===
match
---
name: key [76552,76555]
name: key [76504,76507]
===
match
---
simple_stmt [30162,30223]
simple_stmt [30162,30223]
===
match
---
operator: = [21069,21070]
operator: = [21069,21070]
===
match
---
name: path [71099,71103]
name: path [71051,71055]
===
match
---
return_stmt [35040,35130]
return_stmt [35040,35130]
===
match
---
name: ti_deps [2250,2257]
name: ti_deps [2250,2257]
===
match
---
simple_stmt [7287,7315]
simple_stmt [7287,7315]
===
match
---
suite [45844,48085]
suite [45844,48085]
===
match
---
name: instance [61800,61808]
name: instance [61752,61760]
===
match
---
simple_stmt [29064,29113]
simple_stmt [29064,29113]
===
match
---
decorated [30384,30953]
decorated [30384,30953]
===
match
---
suite [43017,43149]
suite [43017,43149]
===
match
---
atom_expr [22807,22815]
atom_expr [22807,22815]
===
match
---
name: self [71480,71484]
name: self [71432,71436]
===
match
---
simple_stmt [5947,6005]
simple_stmt [5947,6005]
===
match
---
atom_expr [72322,72379]
atom_expr [72274,72331]
===
match
---
argument [27296,27310]
argument [27296,27310]
===
match
---
operator: = [55234,55235]
operator: = [55233,55234]
===
match
---
dotted_name [1879,1897]
dotted_name [1879,1897]
===
match
---
atom_expr [63927,63935]
atom_expr [63879,63887]
===
match
---
argument [9611,9627]
argument [9611,9627]
===
match
---
name: key [76548,76551]
name: key [76500,76503]
===
match
---
operator: -> [80792,80794]
operator: -> [80744,80746]
===
match
---
decorated [19448,19869]
decorated [19448,19869]
===
match
---
name: __getattr__ [63960,63971]
name: __getattr__ [63912,63923]
===
match
---
expr_stmt [61483,61553]
expr_stmt [61435,61505]
===
match
---
operator: = [74278,74279]
operator: = [74230,74231]
===
match
---
name: timezone [11897,11905]
name: timezone [11897,11905]
===
match
---
trailer [62507,62514]
trailer [62459,62466]
===
match
---
trailer [23941,24090]
trailer [23941,24090]
===
match
---
name: state [44645,44650]
name: state [44645,44650]
===
match
---
operator: = [79608,79609]
operator: = [79560,79561]
===
match
---
name: State [43625,43630]
name: State [43625,43630]
===
match
---
operator: , [78050,78051]
operator: , [78002,78003]
===
match
---
name: TaskInstance [79075,79087]
name: TaskInstance [79027,79039]
===
match
---
comparison [26229,26279]
comparison [26229,26279]
===
match
---
param [56134,56139]
param [56133,56138]
===
match
---
name: job_id [36013,36019]
name: job_id [36013,36019]
===
match
---
name: session [29815,29822]
name: session [29815,29822]
===
match
---
atom_expr [60387,60520]
atom_expr [60339,60472]
===
match
---
name: Context [68096,68103]
name: Context [68048,68055]
===
match
---
parameters [20666,20686]
parameters [20666,20686]
===
match
---
name: task [52140,52144]
name: task [52178,52182]
===
match
---
name: TaskInstance [79202,79214]
name: TaskInstance [79154,79166]
===
match
---
trailer [79444,79459]
trailer [79396,79411]
===
match
---
atom_expr [8751,8826]
atom_expr [8751,8826]
===
match
---
trailer [18710,18717]
trailer [18710,18717]
===
match
---
trailer [5594,5605]
trailer [5594,5605]
===
match
---
name: isinstance [56486,56496]
name: isinstance [56485,56495]
===
match
---
atom_expr [11270,11282]
atom_expr [11270,11282]
===
match
---
parameters [80874,80880]
parameters [80826,80832]
===
match
---
trailer [18304,18335]
trailer [18304,18335]
===
match
---
operator: , [74745,74746]
operator: , [74697,74698]
===
match
---
simple_stmt [49443,49483]
simple_stmt [49443,49483]
===
match
---
trailer [60623,60625]
trailer [60575,60577]
===
match
---
atom_expr [8794,8813]
atom_expr [8794,8813]
===
match
---
simple_stmt [1161,1186]
simple_stmt [1161,1186]
===
match
---
param [19483,19487]
param [19483,19487]
===
match
---
argument [71585,71604]
argument [71537,71556]
===
match
---
operator: = [34175,34176]
operator: = [34175,34176]
===
match
---
argument [38302,38333]
argument [38302,38333]
===
match
---
trailer [22044,22053]
trailer [22044,22053]
===
match
---
string: 'dag_run' [64682,64691]
string: 'dag_run' [64634,64643]
===
match
---
atom_expr [49683,49721]
atom_expr [49683,49721]
===
match
---
suite [2900,3154]
suite [2900,3154]
===
match
---
name: task_id [6145,6152]
name: task_id [6145,6152]
===
match
---
name: ti_deps [2301,2308]
name: ti_deps [2301,2308]
===
match
---
name: datetime [11146,11154]
name: datetime [11146,11154]
===
match
---
name: context [68293,68300]
name: context [68245,68252]
===
match
---
simple_stmt [51924,51938]
simple_stmt [51962,51976]
===
match
---
name: pool [18632,18636]
name: pool [18632,18636]
===
match
---
name: task [61505,61509]
name: task [61457,61461]
===
match
---
name: next_ds_nodash [64957,64971]
name: next_ds_nodash [64909,64923]
===
match
---
name: test_mode [59225,59234]
name: test_mode [59177,59186]
===
match
---
funcdef [81582,82400]
funcdef [81534,82352]
===
match
---
expr_stmt [47565,47608]
expr_stmt [47565,47608]
===
match
---
return_stmt [29656,29716]
return_stmt [29656,29716]
===
match
---
name: models [82570,82576]
name: models [82522,82528]
===
match
---
operator: , [62272,62273]
operator: , [62224,62225]
===
match
---
name: SUCCESS [37833,37840]
name: SUCCESS [37833,37840]
===
match
---
string: 'BASE_URL' [19621,19631]
string: 'BASE_URL' [19621,19631]
===
match
---
trailer [55767,55773]
trailer [55766,55772]
===
match
---
param [53511,53541]
param [53510,53540]
===
match
---
atom [65972,66080]
atom [65924,66032]
===
match
---
name: settings [41123,41131]
name: settings [41123,41131]
===
match
---
operator: } [19794,19795]
operator: } [19794,19795]
===
match
---
arglist [19608,19631]
arglist [19608,19631]
===
match
---
argument [51881,51900]
argument [51919,51938]
===
match
---
operator: , [26151,26152]
operator: , [26151,26152]
===
match
---
string: '\n' [49350,49354]
string: '\n' [49350,49354]
===
match
---
operator: = [9799,9800]
operator: = [9799,9800]
===
match
---
name: merge [25096,25101]
name: merge [25096,25101]
===
match
---
name: session [32400,32407]
name: session [32400,32407]
===
match
---
operator: , [1434,1435]
operator: , [1434,1435]
===
match
---
name: _run_finished_callback [59445,59467]
name: _run_finished_callback [59397,59419]
===
match
---
simple_stmt [11353,11399]
simple_stmt [11353,11399]
===
match
---
operator: = [23290,23291]
operator: = [23290,23291]
===
match
---
simple_stmt [69091,69151]
simple_stmt [69043,69103]
===
match
---
name: self [33965,33969]
name: self [33965,33969]
===
match
---
name: prepare_for_execution [48303,48324]
name: prepare_for_execution [48303,48324]
===
match
---
operator: } [47227,47228]
operator: } [47227,47228]
===
match
---
operator: = [52421,52422]
operator: = [52420,52421]
===
match
---
number: 1 [60811,60812]
number: 1 [60763,60764]
===
match
---
name: render [72166,72172]
name: render [72118,72124]
===
match
---
trailer [62378,62386]
trailer [62330,62338]
===
match
---
simple_stmt [63549,63600]
simple_stmt [63501,63552]
===
match
---
trailer [26264,26279]
trailer [26264,26279]
===
match
---
simple_stmt [58259,58305]
simple_stmt [58258,58304]
===
match
---
trailer [59102,59104]
trailer [59054,59056]
===
match
---
operator: = [68518,68519]
operator: = [68470,68471]
===
match
---
operator: = [62006,62007]
operator: = [61958,61959]
===
match
---
string: 'prev_execution_date' [65186,65207]
string: 'prev_execution_date' [65138,65159]
===
match
---
name: TaskInstance [82149,82161]
name: TaskInstance [82101,82113]
===
match
---
atom_expr [80341,80348]
atom_expr [80293,80300]
===
match
---
parameters [8369,8375]
parameters [8369,8375]
===
match
---
name: str [19936,19939]
name: str [19936,19939]
===
match
---
trailer [58558,58569]
trailer [58557,58568]
===
match
---
expr_stmt [31757,31771]
expr_stmt [31757,31771]
===
match
---
atom_expr [43229,43242]
atom_expr [43229,43242]
===
match
---
operator: = [9568,9569]
operator: = [9568,9569]
===
match
---
name: rollback [48074,48082]
name: rollback [48074,48082]
===
match
---
trailer [43983,43998]
trailer [43983,43998]
===
match
---
atom_expr [40300,40314]
atom_expr [40300,40314]
===
match
---
trailer [11295,11300]
trailer [11295,11300]
===
match
---
simple_stmt [9951,9983]
simple_stmt [9951,9983]
===
match
---
name: _try_number [55931,55942]
name: _try_number [55930,55941]
===
match
---
atom_expr [45388,45421]
atom_expr [45388,45421]
===
match
---
name: state [29624,29629]
name: state [29624,29629]
===
match
---
atom_expr [81070,81086]
atom_expr [81022,81038]
===
match
---
name: all [20508,20511]
name: all [20508,20511]
===
match
---
comparison [79075,79104]
comparison [79027,79056]
===
match
---
atom_expr [29071,29112]
atom_expr [29071,29112]
===
match
---
name: lock_for_update [21076,21091]
name: lock_for_update [21076,21091]
===
match
---
trailer [69059,69077]
trailer [69011,69029]
===
match
---
if_stmt [54332,54363]
if_stmt [54331,54362]
===
match
---
name: context [49557,49564]
name: context [49557,49564]
===
match
---
atom_expr [58335,58354]
atom_expr [58334,58353]
===
match
---
import_name [805,819]
import_name [805,819]
===
match
---
operator: = [20242,20243]
operator: = [20242,20243]
===
match
---
name: ti [7741,7743]
name: ti [7741,7743]
===
match
---
name: Column [10411,10417]
name: Column [10411,10417]
===
match
---
operator: } [19440,19441]
operator: } [19440,19441]
===
match
---
operator: = [9738,9739]
operator: = [9738,9739]
===
match
---
trailer [7971,7978]
trailer [7971,7978]
===
match
---
operator: = [10021,10022]
operator: = [10021,10022]
===
match
---
name: task [51993,51997]
name: task [52031,52035]
===
match
---
name: self [21571,21575]
name: self [21571,21575]
===
match
---
simple_stmt [43557,43600]
simple_stmt [43557,43600]
===
match
---
suite [61915,62106]
suite [61867,62058]
===
match
---
name: Optional [11163,11171]
name: Optional [11163,11171]
===
match
---
operator: @ [41657,41658]
operator: @ [41657,41658]
===
match
---
name: sqlalchemy [1265,1275]
name: sqlalchemy [1265,1275]
===
match
---
name: mark_success [54175,54187]
name: mark_success [54174,54186]
===
match
---
simple_stmt [71464,71508]
simple_stmt [71416,71460]
===
match
---
name: dag_id [79335,79341]
name: dag_id [79287,79293]
===
match
---
name: _start_date [80914,80925]
name: _start_date [80866,80877]
===
match
---
argument [70843,70872]
argument [70795,70824]
===
match
---
name: self [79816,79820]
name: self [79768,79772]
===
match
---
trailer [62084,62105]
trailer [62036,62057]
===
match
---
trailer [42670,42680]
trailer [42670,42680]
===
match
---
name: pickle_id [15885,15894]
name: pickle_id [15885,15894]
===
match
---
name: data [4078,4082]
name: data [4078,4082]
===
match
---
name: __name__ [3303,3311]
name: __name__ [3303,3311]
===
match
---
name: prev_ds_nodash [65158,65172]
name: prev_ds_nodash [65110,65124]
===
match
---
trailer [79957,79969]
trailer [79909,79921]
===
match
---
suite [73986,74194]
suite [73938,74146]
===
match
---
except_clause [4494,4510]
except_clause [4494,4510]
===
match
---
operator: , [39670,39671]
operator: , [39670,39671]
===
match
---
operator: , [77684,77685]
operator: , [77636,77637]
===
match
---
name: dag_id [26145,26151]
name: dag_id [26145,26151]
===
match
---
simple_stmt [44466,44489]
simple_stmt [44466,44489]
===
match
---
return_stmt [34844,34872]
return_stmt [34844,34872]
===
match
---
trailer [55066,55083]
trailer [55065,55082]
===
match
---
atom_expr [58921,58978]
atom_expr [58911,58972]
===
match
---
name: Optional [78074,78082]
name: Optional [78026,78034]
===
match
---
name: dag_id [74317,74323]
name: dag_id [74269,74275]
===
match
---
name: next_retry_datetime [35089,35108]
name: next_retry_datetime [35089,35108]
===
match
---
tfpdef [74722,74738]
tfpdef [74674,74690]
===
match
---
operator: @ [80679,80680]
operator: @ [80631,80632]
===
match
---
trailer [41595,41612]
trailer [41595,41612]
===
match
---
operator: , [1289,1290]
operator: , [1289,1290]
===
match
---
suite [4140,4175]
suite [4140,4175]
===
match
---
name: generate_command [14953,14969]
name: generate_command [14953,14969]
===
match
---
name: max_tries [71729,71738]
name: max_tries [71681,71690]
===
match
---
simple_stmt [2365,2400]
simple_stmt [2365,2400]
===
match
---
simple_stmt [2547,2590]
simple_stmt [2547,2590]
===
match
---
trailer [27295,27351]
trailer [27295,27351]
===
match
---
atom_expr [14983,14994]
atom_expr [14983,14994]
===
match
---
simple_stmt [51685,51729]
simple_stmt [51723,51767]
===
match
---
operator: -> [8184,8186]
operator: -> [8184,8186]
===
match
---
name: execution_date [11687,11701]
name: execution_date [11687,11701]
===
match
---
name: self [20460,20464]
name: self [20460,20464]
===
match
---
name: t [79154,79155]
name: t [79106,79107]
===
match
---
for_stmt [31856,32190]
for_stmt [31856,32190]
===
match
---
param [45816,45821]
param [45816,45821]
===
match
---
atom_expr [25031,25044]
atom_expr [25031,25044]
===
match
---
string: "--cfg-path" [18844,18856]
string: "--cfg-path" [18844,18856]
===
match
---
name: task_copy [51807,51816]
name: task_copy [51845,51854]
===
match
---
name: TaskInstance [26165,26177]
name: TaskInstance [26165,26177]
===
match
---
argument [46853,46881]
argument [46853,46881]
===
match
---
operator: , [22965,22966]
operator: , [22965,22966]
===
match
---
name: Dict [3226,3230]
name: Dict [3226,3230]
===
match
---
atom_expr [12608,12622]
atom_expr [12608,12622]
===
match
---
operator: = [54595,54596]
operator: = [54594,54595]
===
match
---
operator: = [10975,10976]
operator: = [10975,10976]
===
match
---
sync_comp_for [7070,7117]
sync_comp_for [7070,7117]
===
match
---
name: dag [14668,14671]
name: dag [14668,14671]
===
match
---
name: pool [54279,54283]
name: pool [54278,54282]
===
match
---
operator: , [10646,10647]
operator: , [10646,10647]
===
match
---
operator: = [32407,32408]
operator: = [32407,32408]
===
match
---
name: ignore_task_deps [14164,14180]
name: ignore_task_deps [14164,14180]
===
match
---
simple_stmt [57925,57951]
simple_stmt [57924,57950]
===
match
---
trailer [66455,66461]
trailer [66407,66413]
===
match
---
trailer [14987,14994]
trailer [14987,14994]
===
match
---
operator: , [62663,62664]
operator: , [62615,62616]
===
match
---
suite [39151,39349]
suite [39151,39349]
===
match
---
name: prev_attempted_tries [13366,13386]
name: prev_attempted_tries [13366,13386]
===
match
---
name: extend [18654,18660]
name: extend [18654,18660]
===
match
---
name: ti [21841,21843]
name: ti [21841,21843]
===
match
---
atom [44836,44866]
atom [44836,44866]
===
match
---
name: log [30110,30113]
name: log [30110,30113]
===
match
---
trailer [26241,26256]
trailer [26241,26256]
===
match
---
expr_stmt [21841,21875]
expr_stmt [21841,21875]
===
match
---
string: 'dag_id=%s, task_id=%s, execution_date=%s, start_date=%s, end_date=%s' [45202,45272]
string: 'dag_id=%s, task_id=%s, execution_date=%s, start_date=%s, end_date=%s' [45202,45272]
===
match
---
arglist [56988,57031]
arglist [56987,57030]
===
match
---
trailer [82663,82677]
trailer [82615,82629]
===
match
---
suite [66234,67181]
suite [66186,67133]
===
match
---
operator: , [43825,43826]
operator: , [43825,43826]
===
match
---
simple_stmt [18294,18336]
simple_stmt [18294,18336]
===
match
---
trailer [32264,32301]
trailer [32264,32301]
===
match
---
name: timezone [50939,50947]
name: timezone [50977,50985]
===
match
---
operator: = [80114,80115]
operator: = [80066,80067]
===
match
---
name: warnings [30632,30640]
name: warnings [30632,30640]
===
match
---
suite [79665,82400]
suite [79617,82352]
===
match
---
atom_expr [26408,26437]
atom_expr [26408,26437]
===
match
---
operator: = [31764,31765]
operator: = [31764,31765]
===
match
---
import_from [7554,7594]
import_from [7554,7594]
===
match
---
name: non_requeueable_dep_context [38190,38217]
name: non_requeueable_dep_context [38190,38217]
===
match
---
trailer [54840,54863]
trailer [54839,54862]
===
match
---
name: task_id [11275,11282]
name: task_id [11275,11282]
===
match
---
arglist [48632,48662]
arglist [48632,48662]
===
match
---
arglist [71585,71754]
arglist [71537,71706]
===
match
---
trailer [45046,45052]
trailer [45046,45052]
===
match
---
argument [45918,45931]
argument [45918,45931]
===
match
---
trailer [60425,60435]
trailer [60377,60387]
===
match
---
name: log [43656,43659]
name: log [43656,43659]
===
match
---
name: execution_date [80771,80785]
name: execution_date [80723,80737]
===
match
---
string: 'core' [62556,62562]
string: 'core' [62508,62514]
===
match
---
operator: } [67704,67705]
operator: } [67656,67657]
===
match
---
expr_stmt [61928,61978]
expr_stmt [61880,61930]
===
match
---
operator: = [76605,76606]
operator: = [76557,76558]
===
match
---
argument [27943,27954]
argument [27943,27954]
===
match
---
name: priority_weight [10155,10170]
name: priority_weight [10155,10170]
===
match
---
name: ignore_task_deps [38480,38496]
name: ignore_task_deps [38480,38496]
===
match
---
name: provide_session [56086,56101]
name: provide_session [56085,56100]
===
match
---
simple_stmt [43304,43321]
simple_stmt [43304,43321]
===
match
---
name: self [59511,59515]
name: self [59463,59467]
===
match
---
name: _date_or_empty [45440,45454]
name: _date_or_empty [45440,45454]
===
match
---
trailer [5510,5516]
trailer [5510,5516]
===
match
---
expr_stmt [71251,71333]
expr_stmt [71203,71285]
===
match
---
name: include_direct_upstream [46853,46876]
name: include_direct_upstream [46853,46876]
===
match
---
name: uselist [11055,11062]
name: uselist [11055,11062]
===
match
---
name: execution_date [60864,60878]
name: execution_date [60816,60830]
===
match
---
operator: , [43141,43142]
operator: , [43141,43142]
===
match
---
expr_stmt [24790,24808]
expr_stmt [24790,24808]
===
match
---
atom_expr [39980,39990]
atom_expr [39980,39990]
===
match
---
operator: = [82050,82051]
operator: = [82002,82003]
===
match
---
operator: = [45829,45830]
operator: = [45829,45830]
===
match
---
fstring_end: ' [50691,50692]
fstring_end: ' [50729,50730]
===
match
---
atom_expr [18168,18182]
atom_expr [18168,18182]
===
match
---
operator: , [59714,59715]
operator: , [59666,59667]
===
match
---
funcdef [28593,29113]
funcdef [28593,29113]
===
match
---
name: __repr__ [32979,32987]
name: __repr__ [32979,32987]
===
match
---
atom_expr [44655,44668]
atom_expr [44655,44668]
===
match
---
trailer [72750,72794]
trailer [72702,72746]
===
match
---
operator: = [80298,80299]
operator: = [80250,80251]
===
match
---
simple_stmt [48335,48357]
simple_stmt [48335,48357]
===
match
---
operator: = [64560,64561]
operator: = [64512,64513]
===
match
---
trailer [54968,54973]
trailer [54967,54972]
===
match
---
trailer [18147,18154]
trailer [18147,18154]
===
match
---
name: log [56537,56540]
name: log [56536,56539]
===
match
---
name: session [82052,82059]
name: session [82004,82011]
===
match
---
name: set_current_context [3346,3365]
name: set_current_context [3346,3365]
===
match
---
simple_stmt [978,1018]
simple_stmt [978,1018]
===
match
---
name: self [45093,45097]
name: self [45093,45097]
===
match
---
name: scalar [77820,77826]
name: scalar [77772,77778]
===
match
---
name: verbose [53958,53965]
name: verbose [53957,53964]
===
match
---
name: execution_date [15622,15636]
name: execution_date [15622,15636]
===
match
---
atom_expr [10411,10451]
atom_expr [10411,10451]
===
match
---
atom_expr [34851,34864]
atom_expr [34851,34864]
===
match
---
param [8630,8645]
param [8630,8645]
===
match
---
suite [31945,32190]
suite [31945,32190]
===
match
---
trailer [27733,27741]
trailer [27733,27741]
===
match
---
except_clause [3154,3172]
except_clause [3154,3172]
===
match
---
operator: , [54069,54070]
operator: , [54068,54069]
===
match
---
simple_stmt [5093,5169]
simple_stmt [5093,5169]
===
match
---
string: """         Refreshes the task instance from the database based on the primary key          :param session: SQLAlchemy ORM Session         :type session: Session         :param lock_for_update: if True, indicates that the database should             lock the TaskInstance (issuing a FOR UPDATE clause) until the             session is committed.         :type lock_for_update: bool         """ [21116,21509]
string: """         Refreshes the task instance from the database based on the primary key          :param session: SQLAlchemy ORM Session         :type session: Session         :param lock_for_update: if True, indicates that the database should             lock the TaskInstance (issuing a FOR UPDATE clause) until the             session is committed.         :type lock_for_update: bool         """ [21116,21509]
===
match
---
expr_stmt [46648,46900]
expr_stmt [46648,46900]
===
match
---
if_stmt [49680,50378]
if_stmt [49680,50416]
===
match
---
atom_expr [42833,42846]
atom_expr [42833,42846]
===
match
---
name: self [58554,58558]
name: self [58553,58557]
===
match
---
trailer [59199,59215]
trailer [59151,59167]
===
match
---
string: "Immediate failure requested. Marking task as FAILED." [58008,58062]
string: "Immediate failure requested. Marking task as FAILED." [58007,58061]
===
match
---
suite [21933,22825]
suite [21933,22825]
===
match
---
operator: , [48646,48647]
operator: , [48646,48647]
===
match
---
atom_expr [22133,22141]
atom_expr [22133,22141]
===
match
---
trailer [39245,39247]
trailer [39245,39247]
===
match
---
trailer [79149,79153]
trailer [79101,79105]
===
match
---
trailer [23884,23906]
trailer [23884,23906]
===
match
---
string: """         Returns the DagRun for this TaskInstance          :param session: SQLAlchemy ORM Session         :return: DagRun         """ [35212,35348]
string: """         Returns the DagRun for this TaskInstance          :param session: SQLAlchemy ORM Session         :return: DagRun         """ [35212,35348]
===
match
---
name: ti [82365,82367]
name: ti [82317,82319]
===
match
---
name: DagRun [60314,60320]
name: DagRun [60266,60272]
===
match
---
name: ti [22737,22739]
name: ti [22737,22739]
===
match
---
return_stmt [20618,20630]
return_stmt [20618,20630]
===
match
---
name: self [44140,44144]
name: self [44140,44144]
===
match
---
string: "execution date %s has no timezone information. Using default from dag or system" [11588,11669]
string: "execution date %s has no timezone information. Using default from dag or system" [11588,11669]
===
match
---
name: foreign_keys [11026,11038]
name: foreign_keys [11026,11038]
===
match
---
trailer [25077,25079]
trailer [25077,25079]
===
match
---
operator: = [71264,71265]
operator: = [71216,71217]
===
match
---
name: self [43161,43165]
name: self [43161,43165]
===
match
---
simple_stmt [6078,6154]
simple_stmt [6078,6154]
===
match
---
atom_expr [61423,61470]
atom_expr [61375,61422]
===
match
---
operator: = [38422,38423]
operator: = [38422,38423]
===
match
---
trailer [34751,34756]
trailer [34751,34756]
===
match
---
operator: , [68881,68882]
operator: , [68833,68834]
===
match
---
operator: = [39570,39571]
operator: = [39570,39571]
===
match
---
trailer [50643,50648]
trailer [50681,50686]
===
match
---
trailer [50718,50734]
trailer [50756,50772]
===
match
---
name: state [65355,65360]
name: state [65307,65312]
===
match
---
name: refresh_from_task [11321,11338]
name: refresh_from_task [11321,11338]
===
match
---
string: 'try_number' [9845,9857]
string: 'try_number' [9845,9857]
===
match
---
name: query [76465,76470]
name: query [76417,76422]
===
match
---
operator: = [15121,15122]
operator: = [15121,15122]
===
match
---
name: models [1887,1893]
name: models [1887,1893]
===
match
---
atom_expr [43843,43855]
atom_expr [43843,43855]
===
match
---
expr_stmt [40881,40903]
expr_stmt [40881,40903]
===
match
---
trailer [78340,78345]
trailer [78292,78297]
===
match
---
atom_expr [52697,52721]
atom_expr [52696,52720]
===
match
---
simple_stmt [4050,4074]
simple_stmt [4050,4074]
===
match
---
name: session [50965,50972]
name: session [51003,51010]
===
match
---
operator: , [59313,59314]
operator: , [59265,59266]
===
match
---
atom_expr [22878,22927]
atom_expr [22878,22927]
===
match
---
operator: , [65723,65724]
operator: , [65675,65676]
===
match
---
argument [74271,74291]
argument [74223,74243]
===
match
---
operator: == [26257,26259]
operator: == [26257,26259]
===
match
---
name: task [57203,57207]
name: task [57202,57206]
===
match
---
name: bool [35958,35962]
name: bool [35958,35962]
===
match
---
trailer [62137,62146]
trailer [62089,62098]
===
match
---
name: replace [61740,61747]
name: replace [61692,61699]
===
match
---
operator: = [27372,27373]
operator: = [27372,27373]
===
match
---
simple_stmt [70738,71004]
simple_stmt [70690,70956]
===
match
---
operator: = [54253,54254]
operator: = [54252,54253]
===
match
---
atom_expr [6078,6153]
atom_expr [6078,6153]
===
match
---
name: dag_id [79098,79104]
name: dag_id [79050,79056]
===
match
---
name: error [58930,58935]
name: exception [58920,58929]
===
match
---
name: self [81041,81045]
name: self [80993,80997]
===
match
---
name: self [74529,74533]
name: self [74481,74485]
===
match
---
atom_expr [52389,52420]
atom_expr [52388,52419]
===
match
---
trailer [32130,32139]
trailer [32130,32139]
===
match
---
name: deps [32551,32555]
name: deps [32551,32555]
===
match
---
name: self [21663,21667]
name: self [21663,21667]
===
match
---
name: context_to_airflow_vars [2633,2656]
name: context_to_airflow_vars [2633,2656]
===
match
---
param [73161,73170]
param [73113,73122]
===
match
---
param [24437,24448]
param [24437,24448]
===
match
---
arglist [79075,79240]
arglist [79027,79192]
===
match
---
string: "--pool" [18662,18670]
string: "--pool" [18662,18670]
===
match
---
name: Optional [29848,29856]
name: Optional [29848,29856]
===
match
---
string: "--force" [18555,18564]
string: "--force" [18555,18564]
===
match
---
operator: = [69105,69106]
operator: = [69057,69058]
===
match
---
name: enrich_errors [45759,45772]
name: enrich_errors [45759,45772]
===
match
---
atom_expr [47897,48049]
atom_expr [47897,48049]
===
match
---
operator: , [72549,72550]
operator: , [72501,72502]
===
match
---
simple_stmt [27247,27259]
simple_stmt [27247,27259]
===
match
---
name: self [44324,44328]
name: self [44324,44328]
===
match
---
decorator [80753,80763]
decorator [80705,80715]
===
match
---
atom_expr [11365,11398]
atom_expr [11365,11398]
===
match
---
name: ignore_ti_state [39818,39833]
name: ignore_ti_state [39818,39833]
===
match
---
trailer [80284,80297]
trailer [80236,80249]
===
match
---
trailer [24378,24389]
trailer [24378,24389]
===
match
---
operator: { [33056,33057]
operator: { [33056,33057]
===
match
---
operator: = [68616,68617]
operator: = [68568,68569]
===
match
---
sync_comp_for [78724,78736]
sync_comp_for [78676,78688]
===
match
---
argument [74246,74257]
argument [74198,74209]
===
match
---
name: ti [5268,5270]
name: ti [5268,5270]
===
match
---
simple_stmt [40702,40731]
simple_stmt [40702,40731]
===
match
---
suite [56470,56873]
suite [56469,56872]
===
match
---
suite [78102,79511]
suite [78054,79463]
===
match
---
operator: , [28466,28467]
operator: , [28466,28467]
===
match
---
atom_expr [70776,70989]
atom_expr [70728,70941]
===
match
---
trailer [45555,45578]
trailer [45555,45578]
===
match
---
argument [54864,54875]
argument [54863,54874]
===
match
---
argument [10964,11016]
argument [10964,11016]
===
match
---
name: airflow [7559,7566]
name: airflow [7559,7566]
===
match
---
name: email_for_state [58149,58164]
name: email_for_state [58148,58163]
===
match
---
name: hostname [42838,42846]
name: hostname [42838,42846]
===
match
---
param [81422,81426]
param [81374,81378]
===
match
---
name: dag_id [20336,20342]
name: dag_id [20336,20342]
===
match
---
trailer [32005,32189]
trailer [32005,32189]
===
match
---
atom_expr [76473,76707]
atom_expr [76425,76659]
===
match
---
suite [63221,63259]
suite [63173,63211]
===
match
---
param [15777,15808]
param [15777,15808]
===
match
---
atom_expr [56923,56940]
atom_expr [56922,56939]
===
match
---
param [21062,21075]
param [21062,21075]
===
match
---
argument [54560,54573]
argument [54559,54572]
===
match
---
simple_stmt [79816,79846]
simple_stmt [79768,79798]
===
match
---
trailer [52259,52265]
trailer [52290,52300]
===
match
---
name: self [68736,68740]
name: self [68688,68692]
===
match
---
arglist [77650,77792]
arglist [77602,77744]
===
match
---
string: '%Y-%m-%d' [60824,60834]
string: '%Y-%m-%d' [60776,60786]
===
match
---
name: contextlib [794,804]
name: contextlib [794,804]
===
match
---
name: context [52805,52812]
name: context [52804,52811]
===
match
---
string: """         This attribute is deprecated.         Please use `airflow.models.taskinstance.TaskInstance.get_previous_start_date` method.         """ [30476,30623]
string: """         This attribute is deprecated.         Please use `airflow.models.taskinstance.TaskInstance.get_previous_start_date` method.         """ [30476,30623]
===
match
---
name: RUNNING [5217,5224]
name: RUNNING [5217,5224]
===
match
---
operator: , [21060,21061]
operator: , [21060,21061]
===
match
---
name: Column [9775,9781]
name: Column [9775,9781]
===
match
---
expr_stmt [14627,14671]
expr_stmt [14627,14671]
===
match
---
operator: = [22562,22563]
operator: = [22562,22563]
===
match
---
decorated [29118,29717]
decorated [29118,29717]
===
match
---
trailer [19314,19318]
trailer [19314,19318]
===
match
---
return_stmt [24303,24390]
return_stmt [24303,24390]
===
match
---
name: self [13387,13391]
name: self [13387,13391]
===
match
---
operator: = [31801,31802]
operator: = [31801,31802]
===
match
---
simple_stmt [24108,24125]
simple_stmt [24108,24125]
===
match
---
atom_expr [72584,72625]
atom_expr [72536,72577]
===
match
---
operator: , [4480,4481]
operator: , [4480,4481]
===
match
---
simple_stmt [51062,51145]
simple_stmt [51100,51183]
===
match
---
if_stmt [21809,21919]
if_stmt [21809,21919]
===
match
---
name: session [56304,56311]
name: session [56303,56310]
===
match
---
operator: = [54628,54629]
operator: = [54627,54628]
===
match
---
operator: , [59677,59678]
operator: , [59629,59630]
===
match
---
name: task [47186,47190]
name: task [47186,47190]
===
match
---
string: 'tomorrow_ds_nodash' [65801,65821]
string: 'tomorrow_ds_nodash' [65753,65773]
===
match
---
name: str [18240,18243]
name: str [18240,18243]
===
match
---
simple_stmt [9824,9879]
simple_stmt [9824,9879]
===
match
---
parameters [26483,26557]
parameters [26483,26557]
===
match
---
simple_stmt [57994,58063]
simple_stmt [57993,58062]
===
match
---
decorated [12488,12668]
decorated [12488,12668]
===
match
---
trailer [45503,45505]
trailer [45503,45505]
===
match
---
trailer [45564,45570]
trailer [45564,45570]
===
match
---
argument [43182,43202]
argument [43182,43202]
===
match
---
name: dag_id [8772,8778]
name: dag_id [8772,8778]
===
match
---
operator: , [57028,57029]
operator: , [57027,57028]
===
match
---
operator: = [27803,27804]
operator: = [27803,27804]
===
match
---
trailer [6870,6925]
trailer [6870,6925]
===
match
---
if_stmt [61892,62106]
if_stmt [61844,62058]
===
match
---
name: get [64539,64542]
name: get [64491,64494]
===
match
---
atom_expr [77650,77669]
atom_expr [77602,77621]
===
match
---
name: refresh_from_db [44110,44125]
name: refresh_from_db [44110,44125]
===
match
---
operator: = [18983,18984]
operator: = [18983,18984]
===
match
---
simple_stmt [19246,19291]
simple_stmt [19246,19291]
===
match
---
name: priority_weight [10845,10860]
name: priority_weight [10845,10860]
===
match
---
trailer [12464,12474]
trailer [12464,12474]
===
match
---
atom_expr [18985,19016]
atom_expr [18985,19016]
===
match
---
name: Log [1905,1908]
name: Log [1905,1908]
===
match
---
name: result [59783,59789]
name: result [59735,59741]
===
match
---
name: airflow [3024,3031]
name: airflow [3024,3031]
===
match
---
trailer [67922,67926]
trailer [67874,67878]
===
match
---
name: ignore_all_deps [35780,35795]
name: ignore_all_deps [35780,35795]
===
match
---
name: AirflowException [1652,1668]
name: AirflowException [1652,1668]
===
match
---
trailer [46161,46171]
trailer [46161,46171]
===
match
---
simple_stmt [13402,13550]
simple_stmt [13402,13550]
===
match
---
import_as_names [1283,1349]
import_as_names [1283,1349]
===
match
---
trailer [48324,48326]
trailer [48324,48326]
===
match
---
trailer [77819,77826]
trailer [77771,77778]
===
match
---
name: Column [9838,9844]
name: Column [9838,9844]
===
match
---
trailer [41234,41238]
trailer [41234,41238]
===
match
---
name: task [64852,64856]
name: task [64804,64808]
===
match
---
trailer [79321,79328]
trailer [79273,79280]
===
match
---
expr_stmt [62045,62105]
expr_stmt [61997,62057]
===
match
---
funcdef [53412,54877]
funcdef [53411,54876]
===
match
---
fstring_string: ti.start. [42932,42941]
fstring_string: ti.start. [42932,42941]
===
match
---
trailer [41355,41409]
trailer [41355,41409]
===
match
---
name: state [12147,12152]
name: state [12147,12152]
===
match
---
name: activate_dag_runs [4763,4780]
name: activate_dag_runs [4763,4780]
===
match
---
trailer [48801,48808]
trailer [48801,48808]
===
match
---
operator: , [48148,48149]
operator: , [48148,48149]
===
match
---
if_stmt [68185,68251]
if_stmt [68137,68203]
===
match
---
decorator [3315,3342]
decorator [3315,3342]
===
match
---
operator: , [63993,63994]
operator: , [63945,63946]
===
match
---
simple_stmt [18462,18503]
simple_stmt [18462,18503]
===
match
---
name: from_string [72098,72109]
name: from_string [72050,72061]
===
match
---
simple_stmt [19352,19443]
simple_stmt [19352,19443]
===
match
---
trailer [72328,72379]
trailer [72280,72331]
===
match
---
simple_stmt [54444,54691]
simple_stmt [54443,54690]
===
match
---
import_from [2700,2749]
import_from [2700,2749]
===
match
---
suite [49968,50196]
suite [49995,50234]
===
match
---
name: params [62520,62526]
name: params [62472,62478]
===
match
---
trailer [76477,76486]
trailer [76429,76438]
===
match
---
number: 256 [10145,10148]
number: 256 [10145,10148]
===
match
---
name: pod [69078,69081]
name: pod [69030,69033]
===
match
---
name: session [55227,55234]
name: session [55226,55233]
===
match
---
trailer [19277,19287]
trailer [19277,19287]
===
match
---
atom_expr [26838,26851]
atom_expr [26838,26851]
===
match
---
name: job_id [41793,41799]
name: job_id [41793,41799]
===
match
---
dotted_name [2293,2326]
dotted_name [2293,2326]
===
match
---
name: pod [69146,69149]
name: pod [69098,69101]
===
match
---
name: task_id [74271,74278]
name: task_id [74223,74230]
===
match
---
fstring_start: f' [50649,50651]
fstring_start: f' [50687,50689]
===
match
---
trailer [11274,11282]
trailer [11274,11282]
===
match
---
simple_stmt [55763,55800]
simple_stmt [55762,55799]
===
match
---
operator: @ [19448,19449]
operator: @ [19448,19449]
===
match
---
trailer [68490,68497]
trailer [68442,68449]
===
match
---
trailer [51816,51829]
trailer [51854,51867]
===
match
---
name: dep_context [32623,32634]
name: dep_context [32623,32634]
===
match
---
name: clear_xcom_data [23653,23668]
name: clear_xcom_data [23653,23668]
===
match
---
name: ds [64720,64722]
name: ds [64672,64674]
===
match
---
name: provide_session [2734,2749]
name: provide_session [2734,2749]
===
match
---
name: Integer [10319,10326]
name: Integer [10319,10326]
===
match
---
trailer [28296,28301]
trailer [28296,28301]
===
match
---
suite [76943,77244]
suite [76895,77196]
===
match
---
suite [26586,28090]
suite [26586,28090]
===
match
---
argument [71677,71707]
argument [71629,71659]
===
match
---
atom_expr [11554,11716]
atom_expr [11554,11716]
===
match
---
simple_stmt [59579,59642]
simple_stmt [59531,59594]
===
match
---
trailer [34855,34864]
trailer [34855,34864]
===
match
---
arith_expr [72937,72968]
arith_expr [72889,72920]
===
match
---
operator: = [10348,10349]
operator: = [10348,10349]
===
match
---
simple_stmt [19207,19238]
simple_stmt [19207,19238]
===
match
---
trailer [72062,72064]
trailer [72014,72016]
===
match
---
operator: , [47995,47996]
operator: , [47995,47996]
===
match
---
name: __init__ [63895,63903]
name: __init__ [63847,63855]
===
match
---
simple_stmt [25490,25944]
simple_stmt [25490,25944]
===
match
---
atom_expr [6658,7150]
atom_expr [6658,7150]
===
match
---
atom_expr [22056,22067]
atom_expr [22056,22067]
===
match
---
atom_expr [41389,41408]
atom_expr [41389,41408]
===
match
---
atom_expr [48811,48828]
atom_expr [48811,48828]
===
match
---
atom_expr [64808,64827]
atom_expr [64760,64779]
===
match
---
expr [32522,32555]
expr [32522,32555]
===
match
---
funcdef [63298,63600]
funcdef [63250,63552]
===
match
---
atom_expr [7484,7493]
atom_expr [7484,7493]
===
match
---
trailer [26514,26519]
trailer [26514,26519]
===
match
---
suite [66503,66652]
suite [66455,66604]
===
match
---
name: job_id [54254,54260]
name: job_id [54253,54259]
===
match
---
trailer [21700,21708]
trailer [21700,21708]
===
match
---
decorated [25416,26438]
decorated [25416,26438]
===
match
---
atom_expr [9650,9687]
atom_expr [9650,9687]
===
match
---
argument [79287,79500]
argument [79239,79452]
===
match
---
argument [76681,76696]
argument [76633,76648]
===
match
---
expr_stmt [53171,53187]
expr_stmt [53170,53186]
===
match
---
trailer [47282,47298]
trailer [47282,47298]
===
match
---
trailer [29103,29111]
trailer [29103,29111]
===
match
---
simple_stmt [5268,5294]
simple_stmt [5268,5294]
===
match
---
and_test [78666,78723]
and_test [78618,78675]
===
match
---
return_stmt [26392,26437]
return_stmt [26392,26437]
===
match
---
string: "airflow.task" [11383,11397]
string: "airflow.task" [11383,11397]
===
match
---
operator: = [60554,60555]
operator: = [60506,60507]
===
match
---
and_test [5398,5427]
and_test [5398,5427]
===
match
---
atom_expr [26074,26094]
atom_expr [26074,26094]
===
match
---
operator: , [21569,21570]
operator: , [21569,21570]
===
match
---
operator: == [35545,35547]
operator: == [35545,35547]
===
match
---
name: first [60513,60518]
name: first [60465,60470]
===
match
---
string: "Dependencies all met for %s" [32265,32294]
string: "Dependencies all met for %s" [32265,32294]
===
match
---
name: error_fd [54785,54793]
name: error_fd [54784,54792]
===
match
---
expr_stmt [10267,10301]
expr_stmt [10267,10301]
===
match
---
param [74679,74713]
param [74631,74665]
===
match
---
except_clause [67556,67608]
except_clause [67508,67560]
===
match
---
name: Union [4321,4326]
name: Union [4321,4326]
===
match
---
name: _dag_id [79821,79828]
name: _dag_id [79773,79780]
===
match
---
simple_stmt [53078,53112]
simple_stmt [53077,53111]
===
match
---
operator: -> [16106,16108]
operator: -> [16106,16108]
===
match
---
atom_expr [81383,81394]
atom_expr [81335,81346]
===
match
---
name: error_file [44375,44385]
name: error_file [44375,44385]
===
match
---
name: delay [33693,33698]
name: delay [33693,33698]
===
match
---
suite [44453,44821]
suite [44453,44821]
===
match
---
argument [15198,15243]
argument [15198,15243]
===
match
---
name: passed [32925,32931]
name: passed [32925,32931]
===
match
---
name: XCom [23929,23933]
name: XCom [23929,23933]
===
match
---
argument [68772,68835]
argument [68724,68787]
===
match
---
operator: @ [81230,81231]
operator: @ [81182,81183]
===
match
---
and_test [59586,59641]
and_test [59538,59593]
===
match
---
operator: , [38630,38631]
operator: , [38630,38631]
===
match
---
trailer [68095,68104]
trailer [68047,68056]
===
match
---
operator: = [5546,5547]
operator: = [5546,5547]
===
match
---
parameters [8177,8183]
parameters [8177,8183]
===
match
---
operator: = [51525,51526]
operator: = [51563,51564]
===
match
---
name: kube_config [68657,68668]
name: kube_config [68609,68620]
===
match
---
name: vals_kv [76956,76963]
name: vals_kv [76908,76915]
===
match
---
name: ti [5199,5201]
name: ti [5199,5201]
===
match
---
funcdef [4278,4709]
funcdef [4278,4709]
===
match
---
tfpdef [52382,52420]
tfpdef [52381,52419]
===
match
---
atom_expr [82680,82701]
atom_expr [82632,82653]
===
match
---
atom_expr [40263,40278]
atom_expr [40263,40278]
===
match
---
operator: = [3188,3189]
operator: = [3188,3189]
===
match
---
name: session [53818,53825]
name: session [53817,53824]
===
match
---
simple_stmt [64606,66190]
simple_stmt [64558,66142]
===
match
---
operator: = [11087,11088]
operator: = [11087,11088]
===
match
---
trailer [40011,40015]
trailer [40011,40015]
===
match
---
arglist [60175,60186]
arglist [60127,60138]
===
match
---
simple_stmt [68213,68251]
simple_stmt [68165,68203]
===
match
---
trailer [19037,19042]
trailer [19037,19042]
===
match
---
argument [54297,54312]
argument [54296,54311]
===
match
---
name: self [53265,53269]
name: self [53264,53268]
===
match
---
expr_stmt [21586,21799]
expr_stmt [21586,21799]
===
match
---
arglist [55508,55709]
arglist [55507,55708]
===
match
---
operator: , [21674,21675]
operator: , [21674,21675]
===
match
---
name: self [80357,80361]
name: self [80309,80313]
===
match
---
name: date_attr [59668,59677]
name: date_attr [59620,59629]
===
match
---
name: self [57209,57213]
name: self [57208,57212]
===
match
---
name: read [72058,72062]
name: read [72010,72014]
===
match
---
name: self [47501,47505]
name: self [47501,47505]
===
match
---
name: Context [3265,3272]
name: Context [3265,3272]
===
match
---
trailer [11986,12002]
trailer [11986,12002]
===
match
---
trailer [78690,78705]
trailer [78642,78657]
===
match
---
name: create_pod_id [3078,3091]
name: create_pod_id [3078,3091]
===
match
---
atom_expr [41518,41537]
atom_expr [41518,41537]
===
match
---
trailer [14833,14847]
trailer [14833,14847]
===
match
---
atom_expr [47122,47142]
atom_expr [47122,47142]
===
match
---
simple_stmt [47036,47229]
simple_stmt [47036,47229]
===
match
---
param [54894,54898]
param [54893,54897]
===
match
---
number: 1 [71706,71707]
number: 1 [71658,71659]
===
match
---
atom_expr [16038,16051]
atom_expr [16038,16051]
===
match
---
name: DagRun [35465,35471]
name: DagRun [35465,35471]
===
match
---
atom_expr [29098,29111]
atom_expr [29098,29111]
===
match
---
name: raw [77938,77941]
name: raw [77890,77893]
===
match
---
parameters [4735,4802]
parameters [4735,4802]
===
match
---
name: executor_config [81496,81511]
name: executor_config [81448,81463]
===
match
---
name: self [50159,50163]
name: self [50016,50020]
===
match
---
name: State [20944,20949]
name: State [20944,20949]
===
match
---
name: session [45544,45551]
name: session [45544,45551]
===
match
---
name: self [60779,60783]
name: self [60731,60735]
===
match
---
operator: , [46335,46336]
operator: , [46335,46336]
===
match
---
name: debug [23879,23884]
name: debug [23879,23884]
===
match
---
name: Integer [9859,9866]
name: Integer [9859,9866]
===
match
---
name: context [49921,49928]
name: context [49921,49928]
===
match
---
fstring_string: Skipping mini scheduling run due to exception:  [47934,47981]
fstring_string: Skipping mini scheduling run due to exception:  [47934,47981]
===
match
---
import_from [48206,48276]
import_from [48206,48276]
===
match
---
operator: @ [35624,35625]
operator: @ [35624,35625]
===
match
---
tfpdef [36051,36070]
tfpdef [36051,36070]
===
match
---
except_clause [47753,47781]
except_clause [47753,47781]
===
match
---
operator: , [72417,72418]
operator: , [72369,72370]
===
match
---
atom_expr [23502,23516]
atom_expr [23502,23516]
===
match
---
name: renderedtifields [66316,66332]
name: renderedtifields [66268,66284]
===
match
---
expr_stmt [9561,9628]
expr_stmt [9561,9628]
===
match
---
name: session [25467,25474]
name: session [25467,25474]
===
match
---
expr_stmt [17945,17977]
expr_stmt [17945,17977]
===
match
---
name: ID_LEN [10425,10431]
name: ID_LEN [10425,10431]
===
match
---
comp_if [47163,47210]
comp_if [47163,47210]
===
match
---
funcdef [34878,35131]
funcdef [34878,35131]
===
match
---
simple_stmt [8022,8064]
simple_stmt [8022,8064]
===
match
---
name: airflow [2115,2122]
name: airflow [2115,2122]
===
match
---
name: _try_number [13205,13216]
name: _try_number [13205,13216]
===
match
---
name: self [32654,32658]
name: self [32654,32658]
===
match
---
simple_stmt [7910,7935]
simple_stmt [7910,7935]
===
match
---
atom_expr [79309,79328]
atom_expr [79261,79280]
===
match
---
expr_stmt [21902,21918]
expr_stmt [21902,21918]
===
match
---
string: 'execution_date can not be in the past (current ' [74033,74082]
string: 'execution_date can not be in the past (current ' [73985,74034]
===
match
---
argument [68693,68717]
argument [68645,68669]
===
match
---
name: jinja_context [70738,70751]
name: jinja_context [70690,70703]
===
match
---
argument [46320,46335]
argument [46320,46335]
===
match
---
name: render [72237,72243]
name: render [72189,72195]
===
match
---
name: full_filepath [14834,14847]
name: full_filepath [14834,14847]
===
match
---
arglist [37646,37683]
arglist [37646,37683]
===
match
---
trailer [22135,22141]
trailer [22135,22141]
===
match
---
name: __init__ [11109,11117]
name: __init__ [11109,11117]
===
match
---
name: enrich_errors [41665,41678]
name: enrich_errors [41665,41678]
===
match
---
atom_expr [80412,80442]
atom_expr [80364,80394]
===
match
---
operator: , [66530,66531]
operator: , [66482,66483]
===
match
---
trailer [38556,38658]
trailer [38556,38658]
===
match
---
operator: = [52826,52827]
operator: = [52825,52826]
===
match
---
param [63401,63460]
param [63353,63412]
===
match
---
funcdef [52349,53386]
funcdef [52348,53385]
===
match
---
name: execution_date [19263,19277]
name: execution_date [19263,19277]
===
match
---
name: self [58678,58682]
name: self [58677,58681]
===
match
---
return_stmt [80654,80673]
return_stmt [80606,80625]
===
match
---
name: mark_success [15080,15092]
name: mark_success [15080,15092]
===
match
---
operator: @ [81400,81401]
operator: @ [81352,81353]
===
match
---
parameters [59510,59516]
parameters [59462,59468]
===
match
---
yield_expr [32953,32969]
yield_expr [32953,32969]
===
match
---
simple_stmt [80323,80349]
simple_stmt [80275,80301]
===
match
---
if_stmt [32199,32235]
if_stmt [32199,32235]
===
match
---
name: dep_context [31707,31718]
name: dep_context [31707,31718]
===
match
---
name: test_mode [44908,44917]
name: test_mode [44908,44917]
===
match
---
name: task_id [10774,10781]
name: task_id [10774,10781]
===
match
---
operator: , [31026,31027]
operator: , [31026,31027]
===
match
---
name: dag_id [19434,19440]
name: dag_id [19434,19440]
===
match
---
arglist [38574,38644]
arglist [38574,38644]
===
match
---
name: getLogger [11373,11382]
name: getLogger [11373,11382]
===
match
---
atom_expr [33366,33401]
atom_expr [33366,33401]
===
match
---
operator: } [19720,19721]
operator: } [19720,19721]
===
match
---
name: get_previous_dagrun [27906,27925]
name: get_previous_dagrun [27906,27925]
===
match
---
atom_expr [18216,18253]
atom_expr [18216,18253]
===
match
---
atom_expr [78969,78977]
atom_expr [78921,78929]
===
match
---
atom_expr [41837,41850]
atom_expr [41837,41850]
===
match
---
name: job_id [15416,15422]
name: job_id [15416,15422]
===
match
---
param [3947,3960]
param [3947,3960]
===
match
---
atom_expr [19136,19148]
atom_expr [19136,19148]
===
match
---
name: task [52665,52669]
name: task [52664,52668]
===
match
---
name: task_id [8085,8092]
name: task_id [8085,8092]
===
match
---
atom_expr [45486,45505]
atom_expr [45486,45505]
===
match
---
dotted_name [2061,2080]
dotted_name [2061,2080]
===
match
---
operator: = [51692,51693]
operator: = [51730,51731]
===
match
---
trailer [26847,26851]
trailer [26847,26851]
===
match
---
operator: , [45570,45571]
operator: , [45570,45571]
===
match
---
dotted_name [2370,2383]
dotted_name [2370,2383]
===
match
---
decorated [15493,18888]
decorated [15493,18888]
===
match
---
trailer [24701,24708]
trailer [24701,24708]
===
match
---
trailer [60451,60458]
trailer [60403,60410]
===
match
---
simple_stmt [58921,58979]
simple_stmt [58911,58973]
===
match
---
operator: , [19917,19918]
operator: , [19917,19918]
===
match
---
name: end_date [80034,80042]
name: end_date [79986,79994]
===
match
---
trailer [57120,57140]
trailer [57119,57139]
===
match
---
name: pendulum [62067,62075]
name: pendulum [62019,62027]
===
match
---
operator: , [41376,41377]
operator: , [41376,41377]
===
match
---
name: pendulum [1193,1201]
name: pendulum [1193,1201]
===
match
---
not_test [38527,38658]
not_test [38527,38658]
===
match
---
name: airflow [1959,1966]
name: airflow [1959,1966]
===
match
---
name: get [63147,63150]
name: get [63099,63102]
===
match
---
atom_expr [24353,24372]
atom_expr [24353,24372]
===
match
---
decorators [45730,45773]
decorators [45730,45773]
===
match
---
comparison [37813,37840]
comparison [37813,37840]
===
match
---
operator: , [53772,53773]
operator: , [53771,53772]
===
match
---
name: _task_id [79859,79867]
name: _task_id [79811,79819]
===
match
---
arglist [38248,38497]
arglist [38248,38497]
===
match
---
name: state [39972,39977]
name: state [39972,39977]
===
match
---
name: pod_template_file [69013,69030]
name: pod_template_file [68965,68982]
===
match
---
trailer [9504,9556]
trailer [9504,9556]
===
match
---
comparison [23955,23981]
comparison [23955,23981]
===
match
---
atom_expr [25047,25062]
atom_expr [25047,25062]
===
match
---
atom_expr [60604,60625]
atom_expr [60556,60577]
===
match
---
atom_expr [74562,74587]
atom_expr [74514,74539]
===
match
---
subscriptlist [3231,3239]
subscriptlist [3231,3239]
===
match
---
atom_expr [66047,66065]
atom_expr [65999,66017]
===
match
---
import_from [1813,1873]
import_from [1813,1873]
===
match
---
operator: , [18785,18786]
operator: , [18785,18786]
===
match
---
operator: = [14354,14355]
operator: = [14354,14355]
===
match
---
string: 'Exception:<br>Failed attempt to attach error logs<br>' [70234,70289]
string: 'Exception:<br>Failed attempt to attach error logs<br>' [70186,70241]
===
match
---
operator: = [60856,60857]
operator: = [60808,60809]
===
match
---
name: bool [35991,35995]
name: bool [35991,35995]
===
match
---
fstring_end: " [19795,19796]
fstring_end: " [19795,19796]
===
match
---
expr_stmt [62286,62337]
expr_stmt [62238,62289]
===
match
---
name: handle_failure_with_callback [59135,59163]
name: handle_failure_with_callback [59087,59115]
===
match
---
name: state [54741,54746]
name: state [54740,54745]
===
match
---
operator: @ [25416,25417]
operator: @ [25416,25417]
===
match
---
suite [64036,64138]
suite [63988,64090]
===
match
---
expr_stmt [55926,55947]
expr_stmt [55925,55946]
===
match
---
suite [56515,56581]
suite [56514,56580]
===
match
---
return_stmt [81063,81086]
return_stmt [81015,81038]
===
match
---
name: bool [35797,35801]
name: bool [35797,35801]
===
match
---
name: add [40808,40811]
name: add [40808,40811]
===
match
---
param [80958,80962]
param [80910,80914]
===
match
---
name: timezone [24693,24701]
name: timezone [24693,24701]
===
match
---
operator: , [67796,67797]
operator: , [67748,67749]
===
match
---
name: end_date [55646,55654]
name: end_date [55645,55653]
===
match
---
trailer [77066,77080]
trailer [77018,77032]
===
match
---
atom_expr [54400,54431]
atom_expr [54399,54430]
===
match
---
simple_stmt [13225,13253]
simple_stmt [13225,13253]
===
match
---
simple_stmt [28001,28069]
simple_stmt [28001,28069]
===
match
---
name: session [20965,20972]
name: session [20965,20972]
===
match
---
name: self [8319,8323]
name: self [8319,8323]
===
match
---
trailer [29534,29540]
trailer [29534,29540]
===
match
---
trailer [44486,44488]
trailer [44486,44488]
===
match
---
param [53596,53627]
param [53595,53626]
===
match
---
name: fallback [45918,45926]
name: fallback [45918,45926]
===
match
---
name: task [43143,43147]
name: task [43143,43147]
===
match
---
trailer [33844,33849]
trailer [33844,33849]
===
match
---
expr_stmt [20931,20956]
expr_stmt [20931,20956]
===
match
---
atom_expr [34633,34662]
atom_expr [34633,34662]
===
match
---
expr_stmt [9729,9759]
expr_stmt [9729,9759]
===
match
---
name: XCom [24037,24041]
name: XCom [24037,24041]
===
match
---
simple_stmt [44885,44942]
simple_stmt [44885,44942]
===
match
---
operator: = [27948,27949]
operator: = [27948,27949]
===
match
---
expr_stmt [22761,22794]
expr_stmt [22761,22794]
===
match
---
trailer [42808,42815]
trailer [42808,42815]
===
match
---
name: self [63180,63184]
name: self [63132,63136]
===
match
---
name: Optional [16078,16086]
name: Optional [16078,16086]
===
match
---
arglist [68566,68591]
arglist [68518,68543]
===
match
---
param [15600,15613]
param [15600,15613]
===
match
---
name: state [10640,10645]
name: state [10640,10645]
===
match
---
trailer [51536,51544]
trailer [51574,51582]
===
match
---
param [68072,68077]
param [68024,68029]
===
match
---
name: self [40469,40473]
name: self [40469,40473]
===
match
---
operator: = [79980,79981]
operator: = [79932,79933]
===
match
---
arglist [82100,82252]
arglist [82052,82204]
===
match
---
suite [21889,21919]
suite [21889,21919]
===
match
---
atom_expr [55957,55976]
atom_expr [55956,55975]
===
match
---
operator: -> [81122,81124]
operator: -> [81074,81076]
===
match
---
comparison [79359,79393]
comparison [79311,79345]
===
match
---
simple_stmt [45135,45478]
simple_stmt [45135,45478]
===
match
---
atom [18305,18334]
atom [18305,18334]
===
match
---
string: '' [61753,61755]
string: '' [61705,61707]
===
match
---
param [72457,72462]
param [72409,72414]
===
match
---
name: Session [1484,1491]
name: Session [1484,1491]
===
match
---
operator: = [38218,38219]
operator: = [38218,38219]
===
match
---
decorated [30958,32322]
decorated [30958,32322]
===
match
---
name: session [39919,39926]
name: session [39919,39926]
===
match
---
tfpdef [4297,4312]
tfpdef [4297,4312]
===
match
---
operator: = [80029,80030]
operator: = [79981,79982]
===
match
---
trailer [80419,80442]
trailer [80371,80394]
===
match
---
comparison [35047,35079]
comparison [35047,35079]
===
match
---
trailer [7799,7814]
trailer [7799,7814]
===
match
---
name: context [51553,51560]
name: context [51591,51598]
===
match
---
name: str [16114,16117]
name: str [16114,16117]
===
match
---
arglist [21640,21789]
arglist [21640,21789]
===
match
---
name: property [81401,81409]
name: property [81353,81361]
===
match
---
name: where [7261,7266]
name: where [7261,7266]
===
match
---
name: task_id [47539,47546]
name: task_id [47539,47546]
===
match
---
name: try_number [71677,71687]
name: try_number [71629,71639]
===
match
---
operator: = [53957,53958]
operator: = [53956,53957]
===
match
---
name: task_ids [76597,76605]
name: task_ids [76549,76557]
===
match
---
trailer [82452,82458]
trailer [82404,82410]
===
match
---
name: filter [23935,23941]
name: filter [23935,23941]
===
match
---
suite [18066,18110]
suite [18066,18110]
===
match
---
name: Optional [81273,81281]
name: Optional [81225,81233]
===
match
---
trailer [59357,59431]
trailer [59309,59383]
===
match
---
operator: , [80250,80251]
operator: , [80202,80203]
===
match
---
trailer [11210,11212]
trailer [11210,11212]
===
match
---
name: test_mode [41760,41769]
name: test_mode [41760,41769]
===
match
---
suite [41937,45725]
suite [41937,45725]
===
match
---
trailer [74142,74179]
trailer [74094,74131]
===
match
---
trailer [46690,46900]
trailer [46690,46900]
===
match
---
expr_stmt [33325,33354]
expr_stmt [33325,33354]
===
match
---
name: Integer [10293,10300]
name: Integer [10293,10300]
===
match
---
name: on_success_callback [53083,53102]
name: on_success_callback [53082,53101]
===
match
---
name: subject [72156,72163]
name: subject [72108,72115]
===
match
---
trailer [79371,79379]
trailer [79323,79331]
===
match
---
funcdef [19895,20631]
funcdef [19895,20631]
===
match
---
simple_stmt [25014,25080]
simple_stmt [25014,25080]
===
match
---
atom [47264,47339]
atom [47264,47339]
===
match
---
name: ti [6142,6144]
name: ti [6142,6144]
===
match
---
trailer [69523,69537]
trailer [69475,69489]
===
match
---
name: task_copy [50510,50519]
name: task_copy [50548,50557]
===
match
---
tfpdef [74543,74588]
tfpdef [74495,74540]
===
match
---
name: TaskInstance [78827,78839]
name: TaskInstance [78779,78791]
===
match
---
dictorsetmaker [65990,66066]
dictorsetmaker [65942,66018]
===
match
---
param [32400,32412]
param [32400,32412]
===
match
---
atom_expr [53125,53135]
atom_expr [53124,53134]
===
match
---
operator: = [21905,21906]
operator: = [21905,21906]
===
match
---
name: get_template_context [53270,53290]
name: get_template_context [53269,53289]
===
match
---
name: airflow [2662,2669]
name: airflow [2662,2669]
===
match
---
import_from [1576,1614]
import_from [1576,1614]
===
match
---
atom_expr [50939,50956]
atom_expr [50977,50994]
===
match
---
name: provide_session [26444,26459]
name: provide_session [26444,26459]
===
match
---
annassign [8075,8080]
annassign [8075,8080]
===
match
---
import_from [2288,2364]
import_from [2288,2364]
===
match
---
name: job_id [9987,9993]
name: job_id [9987,9993]
===
match
---
operator: , [82251,82252]
operator: , [82203,82204]
===
match
---
tfpdef [51975,51991]
tfpdef [52013,52029]
===
match
---
operator: = [47055,47056]
operator: = [47055,47056]
===
match
---
simple_stmt [74769,76396]
simple_stmt [74721,76348]
===
match
---
param [48135,48140]
param [48135,48140]
===
match
---
simple_stmt [51203,51275]
simple_stmt [51241,51313]
===
match
---
operator: , [64408,64409]
operator: , [64360,64361]
===
match
---
atom_expr [4050,4073]
atom_expr [4050,4073]
===
match
---
name: dill [1142,1146]
name: dill [1142,1146]
===
match
---
param [81116,81120]
param [81068,81072]
===
match
---
atom_expr [10610,10646]
atom_expr [10610,10646]
===
match
---
argument [74225,74232]
argument [74177,74184]
===
match
---
name: t [78929,78930]
name: t [78881,78882]
===
match
---
string: 'html_content_template' [72244,72267]
string: 'html_content_template' [72196,72219]
===
match
---
name: str [80520,80523]
name: str [80472,80475]
===
match
---
operator: , [26497,26498]
operator: , [26497,26498]
===
match
---
operator: = [23606,23607]
operator: = [23606,23607]
===
match
---
trailer [48932,48938]
trailer [48932,48938]
===
match
---
name: log [2509,2512]
name: log [2509,2512]
===
match
---
operator: , [41387,41388]
operator: , [41387,41388]
===
match
---
simple_stmt [28078,28090]
simple_stmt [28078,28090]
===
match
---
operator: @ [45730,45731]
operator: @ [45730,45731]
===
match
---
atom_expr [41342,41409]
atom_expr [41342,41409]
===
match
---
atom_expr [46104,46360]
atom_expr [46104,46360]
===
match
---
trailer [82638,82646]
trailer [82590,82598]
===
match
---
atom_expr [56155,56176]
atom_expr [56154,56175]
===
match
---
operator: = [54046,54047]
operator: = [54045,54046]
===
match
---
return_stmt [8499,8598]
return_stmt [8499,8598]
===
match
---
string: 'BASE_URL' [19332,19342]
string: 'BASE_URL' [19332,19342]
===
match
---
name: delete [54419,54425]
name: delete [54418,54424]
===
match
---
import_from [1547,1575]
import_from [1547,1575]
===
match
---
atom_expr [39304,39319]
atom_expr [39304,39319]
===
match
---
suite [77257,77390]
suite [77209,77342]
===
match
---
name: job_ids [5076,5083]
name: job_ids [5076,5083]
===
match
---
name: construct_task_instance [81586,81609]
name: construct_task_instance [81538,81561]
===
match
---
name: force_fail [59267,59277]
name: force_fail [59219,59229]
===
match
---
simple_stmt [80357,80401]
simple_stmt [80309,80353]
===
match
---
atom_expr [43504,43510]
atom_expr [43504,43510]
===
match
---
trailer [6774,6789]
trailer [6774,6789]
===
match
---
name: self [72584,72588]
name: self [72536,72540]
===
match
---
operator: < [35111,35112]
operator: < [35111,35112]
===
match
---
param [14133,14155]
param [14133,14155]
===
match
---
trailer [77282,77296]
trailer [77234,77248]
===
match
---
trailer [21522,21526]
trailer [21522,21526]
===
match
---
name: get_template_context [43049,43069]
name: get_template_context [43049,43069]
===
match
---
operator: , [50798,50799]
operator: , [50836,50837]
===
match
---
trailer [23506,23516]
trailer [23506,23516]
===
match
---
name: warnings [28288,28296]
name: warnings [28288,28296]
===
match
---
atom_expr [33917,33928]
atom_expr [33917,33928]
===
match
---
funcdef [54882,55114]
funcdef [54881,55113]
===
match
---
name: tis [79028,79031]
name: tis [78980,78983]
===
match
---
trailer [56629,56642]
trailer [56628,56641]
===
match
---
atom_expr [68087,68104]
atom_expr [68039,68056]
===
match
---
name: self [63215,63219]
name: self [63167,63171]
===
match
---
argument [64083,64104]
argument [64035,64056]
===
match
---
comparison [14708,14741]
comparison [14708,14741]
===
match
---
operator: = [35764,35765]
operator: = [35764,35765]
===
match
---
string: """             Wrapper around Variable. This way you can get variables in             templates by using ``{{ var.value.variable_name }}`` or             ``{{ var.value.get('variable_name', 'fallback') }}``.             """ [62727,62951]
string: """             Wrapper around Variable. This way you can get variables in             templates by using ``{{ var.value.variable_name }}`` or             ``{{ var.value.get('variable_name', 'fallback') }}``.             """ [62679,62903]
===
match
---
simple_stmt [12012,12049]
simple_stmt [12012,12049]
===
match
---
trailer [79929,79944]
trailer [79881,79896]
===
match
---
param [31042,31055]
param [31042,31055]
===
match
---
trailer [60518,60520]
trailer [60470,60472]
===
match
---
name: pool [18672,18676]
name: pool [18672,18676]
===
match
---
trailer [5374,5382]
trailer [5374,5382]
===
match
---
simple_stmt [1576,1615]
simple_stmt [1576,1615]
===
match
---
trailer [37859,37864]
trailer [37859,37864]
===
match
---
operator: , [45916,45917]
operator: , [45916,45917]
===
match
---
atom_expr [61732,61756]
atom_expr [61684,61708]
===
match
---
name: execution_date [18990,19004]
name: execution_date [18990,19004]
===
match
---
sync_comp_for [79171,79183]
sync_comp_for [79123,79135]
===
match
---
name: qry [21907,21910]
name: qry [21907,21910]
===
match
---
name: dag_id [49077,49083]
name: dag_id [49077,49083]
===
match
---
atom_expr [57194,57261]
atom_expr [57193,57260]
===
match
---
param [35905,35935]
param [35905,35935]
===
match
---
operator: = [31935,31936]
operator: = [31935,31936]
===
match
---
operator: , [53965,53966]
operator: , [53964,53965]
===
match
---
name: run_id [60121,60127]
name: run_id [60073,60079]
===
match
---
operator: , [10638,10639]
operator: , [10638,10639]
===
match
---
atom_expr [52911,52924]
atom_expr [52910,52923]
===
match
---
fstring [33010,33094]
fstring [33010,33094]
===
match
---
name: execution_date [74148,74162]
name: execution_date [74100,74114]
===
match
---
atom_expr [43528,43544]
atom_expr [43528,43544]
===
match
---
trailer [47538,47546]
trailer [47538,47546]
===
match
---
tfpdef [3366,3382]
tfpdef [3366,3382]
===
match
---
operator: , [46787,46788]
operator: , [46787,46788]
===
match
---
trailer [44660,44668]
trailer [44660,44668]
===
match
---
name: self [32296,32300]
name: self [32296,32300]
===
match
---
return_stmt [64187,64207]
return_stmt [64139,64159]
===
match
---
name: get_previous_execution_date [65327,65354]
name: get_previous_execution_date [65279,65306]
===
match
---
name: self [52761,52765]
name: self [52760,52764]
===
match
---
name: hr_line_break [40024,40037]
name: hr_line_break [40024,40037]
===
match
---
operator: = [82415,82416]
operator: = [82367,82368]
===
match
---
string: '%Y-%m-%d' [61691,61701]
string: '%Y-%m-%d' [61643,61653]
===
match
---
name: Session [74731,74738]
name: Session [74683,74690]
===
match
---
simple_stmt [44324,44398]
simple_stmt [44324,44398]
===
match
---
name: self [77927,77931]
name: self [77879,77883]
===
match
---
atom_expr [62421,62432]
atom_expr [62373,62384]
===
match
---
atom_expr [19547,19578]
atom_expr [19547,19578]
===
match
---
name: TemplateAssertionError [66743,66765]
name: TemplateAssertionError [66695,66717]
===
match
---
trailer [7683,7690]
trailer [7683,7690]
===
match
---
tfpdef [53744,53765]
tfpdef [53743,53764]
===
match
---
name: self [26140,26144]
name: self [26140,26144]
===
match
---
name: DagRun [35493,35499]
name: DagRun [35493,35499]
===
match
---
trailer [64076,64105]
trailer [64028,64057]
===
match
---
arglist [51881,51914]
arglist [51919,51952]
===
match
---
trailer [43818,43825]
trailer [43818,43825]
===
match
---
name: dag_id [45291,45297]
name: dag_id [45291,45297]
===
match
---
name: exception_html [70858,70872]
name: exception_html [70810,70824]
===
match
---
return_stmt [82390,82399]
return_stmt [82342,82351]
===
match
---
atom_expr [68552,68592]
atom_expr [68504,68544]
===
match
---
simple_stmt [60237,60268]
simple_stmt [60189,60220]
===
match
---
name: bool [35759,35763]
name: bool [35759,35763]
===
match
---
operator: = [52670,52671]
operator: = [52669,52670]
===
match
---
operator: == [53136,53138]
operator: == [53135,53137]
===
match
---
trailer [80216,80221]
trailer [80168,80173]
===
match
---
atom_expr [52850,52883]
atom_expr [52849,52882]
===
match
---
trailer [51451,51496]
trailer [51489,51534]
===
match
---
operator: = [67378,67379]
operator: = [67330,67331]
===
match
---
name: raw [15388,15391]
name: raw [15388,15391]
===
match
---
name: TaskInstance [27283,27295]
name: TaskInstance [27283,27295]
===
match
---
argument [68895,68935]
argument [68847,68887]
===
match
---
trailer [45017,45024]
trailer [45017,45024]
===
match
---
simple_stmt [63238,63259]
simple_stmt [63190,63211]
===
match
---
trailer [11524,11540]
trailer [11524,11540]
===
match
---
name: State [5211,5216]
name: State [5211,5216]
===
match
---
trailer [20265,20271]
trailer [20265,20271]
===
match
---
trailer [77099,77105]
trailer [77051,77057]
===
match
---
atom_expr [44989,45055]
atom_expr [44989,45055]
===
match
---
trailer [36065,36070]
trailer [36065,36070]
===
match
---
name: orm [1410,1413]
name: orm [1410,1413]
===
match
---
parameters [13386,13392]
parameters [13386,13392]
===
match
---
name: TemplateAssertionError [67564,67586]
name: TemplateAssertionError [67516,67538]
===
match
---
trailer [53760,53765]
trailer [53759,53764]
===
match
---
atom_expr [52625,52635]
atom_expr [52624,52634]
===
match
---
fstring_expr [19392,19397]
fstring_expr [19392,19397]
===
match
---
argument [54024,54069]
argument [54023,54068]
===
match
---
operator: = [73267,73268]
operator: = [73219,73220]
===
match
---
strings [40093,40241]
strings [40093,40241]
===
match
---
expr_stmt [82422,82469]
expr_stmt [82374,82421]
===
match
---
string: """             This attribute is deprecated.             Please use `airflow.models.taskinstance.TaskInstance.get_previous_ti` method.             """ [28835,28986]
string: """             This attribute is deprecated.             Please use `airflow.models.taskinstance.TaskInstance.get_previous_ti` method.             """ [28835,28986]
===
match
---
name: conf [45856,45860]
name: conf [45856,45860]
===
match
---
name: path [71950,71954]
name: path [71902,71906]
===
match
---
arglist [46712,46882]
arglist [46712,46882]
===
match
---
name: var [64134,64137]
name: var [64086,64089]
===
match
---
trailer [43998,44010]
trailer [43998,44010]
===
match
---
trailer [49410,49412]
trailer [49410,49412]
===
match
---
trailer [74561,74588]
trailer [74513,74540]
===
match
---
dotted_name [45951,45972]
dotted_name [45951,45972]
===
match
---
name: getuser [2692,2699]
name: getuser [2692,2699]
===
match
---
expr_stmt [31707,31748]
expr_stmt [31707,31748]
===
match
---
simple_stmt [9729,9760]
simple_stmt [9729,9760]
===
match
---
trailer [7690,7845]
trailer [7690,7845]
===
match
---
operator: @ [53391,53392]
operator: @ [53390,53391]
===
match
---
name: self [39062,39066]
name: self [39062,39066]
===
match
---
tfpdef [15731,15759]
tfpdef [15731,15759]
===
match
---
operator: == [20343,20345]
operator: == [20343,20345]
===
match
---
comp_op [51841,51847]
comp_op [51879,51885]
===
match
---
name: utcnow [42902,42908]
name: utcnow [42902,42908]
===
match
---
name: cmd [18144,18147]
name: cmd [18144,18147]
===
match
---
trailer [82330,82336]
trailer [82282,82288]
===
match
---
name: self [52376,52380]
name: self [52375,52379]
===
match
---
expr_stmt [8102,8126]
expr_stmt [8102,8126]
===
match
---
name: property [18894,18902]
name: property [18894,18902]
===
match
---
atom_expr [32814,32831]
atom_expr [32814,32831]
===
match
---
name: context [3366,3373]
name: context [3366,3373]
===
match
---
param [16068,16099]
param [16068,16099]
===
match
---
param [41831,41858]
param [41831,41858]
===
match
---
operator: == [77775,77777]
operator: == [77727,77729]
===
match
---
expr_stmt [5362,5382]
expr_stmt [5362,5382]
===
match
---
name: job_ids [7447,7454]
name: job_ids [7447,7454]
===
match
---
trailer [21873,21875]
trailer [21873,21875]
===
match
---
operator: , [1726,1727]
operator: , [1726,1727]
===
match
---
name: task [27306,27310]
name: task [27306,27310]
===
match
---
param [51969,51974]
param [52007,52012]
===
match
---
suite [60220,60268]
suite [60172,60220]
===
match
---
name: UtcDateTime [9712,9723]
name: UtcDateTime [9712,9723]
===
match
---
name: ignore_task_deps [35865,35881]
name: ignore_task_deps [35865,35881]
===
match
---
string: '-' [62138,62141]
string: '-' [62090,62093]
===
match
---
suite [51853,51916]
suite [51891,51954]
===
match
---
suite [53238,53386]
suite [53237,53385]
===
match
---
operator: , [37887,37888]
operator: , [37887,37888]
===
match
---
trailer [45143,45148]
trailer [45143,45148]
===
match
---
simple_stmt [8069,8081]
simple_stmt [8069,8081]
===
match
---
name: self [29180,29184]
name: self [29180,29184]
===
match
---
operator: = [46102,46103]
operator: = [46102,46103]
===
match
---
atom_expr [21712,21724]
atom_expr [21712,21724]
===
match
---
with_stmt [51439,51562]
with_stmt [51477,51600]
===
match
---
simple_stmt [13875,13899]
simple_stmt [13875,13899]
===
match
---
trailer [6033,6038]
trailer [6033,6038]
===
match
---
operator: { [45012,45013]
operator: { [45012,45013]
===
match
---
name: task [60251,60255]
name: task [60203,60207]
===
match
---
name: platform [2676,2684]
name: platform [2676,2684]
===
match
---
trailer [82161,82169]
trailer [82113,82121]
===
match
---
name: result [51908,51914]
name: result [51946,51952]
===
match
---
simple_stmt [22584,22621]
simple_stmt [22584,22621]
===
match
---
operator: = [56212,56213]
operator: = [56211,56212]
===
match
---
simple_stmt [40614,40694]
simple_stmt [40614,40694]
===
match
---
simple_stmt [2700,2750]
simple_stmt [2700,2750]
===
match
---
param [15994,16023]
param [15994,16023]
===
match
---
atom_expr [81214,81224]
atom_expr [81166,81176]
===
match
---
param [53675,53702]
param [53674,53701]
===
match
---
operator: = [15391,15392]
operator: = [15391,15392]
===
match
---
name: str [11172,11175]
name: str [11172,11175]
===
match
---
comparison [52970,53006]
comparison [52969,53005]
===
match
---
expr_stmt [61839,61853]
expr_stmt [61791,61805]
===
match
---
if_stmt [47415,47548]
if_stmt [47415,47548]
===
match
---
name: self [46662,46666]
name: self [46662,46666]
===
match
---
name: test_mode [59037,59046]
name: test_mode [58989,58998]
===
match
---
atom [18661,18677]
atom [18661,18677]
===
match
---
atom_expr [33042,33054]
atom_expr [33042,33054]
===
match
---
name: state [45565,45570]
name: state [45565,45570]
===
match
---
atom_expr [37854,37894]
atom_expr [37854,37894]
===
match
---
operator: { [19406,19407]
operator: { [19406,19407]
===
match
---
operator: = [33814,33815]
operator: = [33814,33815]
===
match
---
string: """Run TaskInstance""" [53855,53877]
string: """Run TaskInstance""" [53854,53876]
===
match
---
operator: } [19119,19120]
operator: } [19119,19120]
===
match
---
trailer [56953,56966]
trailer [56952,56965]
===
match
---
param [19919,19931]
param [19919,19931]
===
match
---
name: self [33333,33337]
name: self [33333,33337]
===
match
---
trailer [50596,50628]
trailer [50634,50666]
===
match
---
return_stmt [59776,59803]
return_stmt [59728,59755]
===
match
---
trailer [82692,82701]
trailer [82644,82653]
===
match
---
name: session [76681,76688]
name: session [76633,76640]
===
match
---
trailer [32658,32662]
trailer [32658,32662]
===
match
---
funcdef [32975,33095]
funcdef [32975,33095]
===
match
---
name: email_for_state [58317,58332]
name: email_for_state [58316,58331]
===
match
---
string: 'conf' [64627,64633]
string: 'conf' [64579,64585]
===
match
---
name: run_id [65566,65572]
name: run_id [65518,65524]
===
match
---
name: self [69215,69219]
name: self [69167,69171]
===
match
---
name: the_log [19112,19119]
name: the_log [19112,19119]
===
match
---
suite [51405,51659]
suite [51443,51697]
===
match
---
name: jinja_context [71521,71534]
name: jinja_context [71473,71486]
===
match
---
decorator [35624,35641]
decorator [35624,35641]
===
match
---
name: modded_hash [34163,34174]
name: modded_hash [34163,34174]
===
match
---
name: provide_session [45731,45746]
name: provide_session [45731,45746]
===
match
---
funcdef [30398,30953]
funcdef [30398,30953]
===
match
---
operator: , [72267,72268]
operator: , [72219,72220]
===
match
---
name: item [64077,64081]
name: item [64029,64033]
===
match
---
annassign [8092,8097]
annassign [8092,8097]
===
match
---
name: key [71975,71978]
name: key [71927,71930]
===
match
---
operator: = [80524,80525]
operator: = [80476,80477]
===
match
---
operator: = [35927,35928]
operator: = [35927,35928]
===
match
---
parameters [41453,41465]
parameters [41453,41465]
===
match
---
atom_expr [42701,42749]
atom_expr [42701,42749]
===
match
---
param [52382,52427]
param [52381,52426]
===
match
---
name: session [7287,7294]
name: session [7287,7294]
===
match
---
name: timeout [2887,2894]
name: timeout [2887,2894]
===
match
---
try_stmt [3604,3925]
try_stmt [3604,3925]
===
match
---
atom_expr [58678,58722]
atom_expr [58677,58721]
===
match
---
name: State [24924,24929]
name: State [24924,24929]
===
match
---
atom_expr [27730,27741]
atom_expr [27730,27741]
===
match
---
name: bool [53490,53494]
name: bool [53489,53493]
===
match
---
trailer [45341,45356]
trailer [45341,45356]
===
match
---
arith_expr [71688,71707]
arith_expr [71640,71659]
===
match
---
trailer [40815,40836]
trailer [40815,40836]
===
match
---
name: error_fd [54807,54815]
name: error_fd [54806,54814]
===
match
---
argument [10043,10057]
argument [10043,10057]
===
match
---
param [74529,74534]
param [74481,74486]
===
match
---
trailer [40678,40688]
trailer [40678,40688]
===
match
---
name: log [48453,48456]
name: log [48453,48456]
===
match
---
name: end_date [34856,34864]
name: end_date [34856,34864]
===
match
---
trailer [31746,31748]
trailer [31746,31748]
===
match
---
name: integrate_macros_plugins [60041,60065]
name: integrate_macros_plugins [59993,60017]
===
match
---
name: dag_id [46209,46215]
name: dag_id [46209,46215]
===
match
---
operator: , [28524,28525]
operator: , [28524,28525]
===
match
---
name: execution_date [60480,60494]
name: execution_date [60432,60446]
===
match
---
simple_stmt [63127,63157]
simple_stmt [63079,63109]
===
match
---
name: session [24449,24456]
name: session [24449,24456]
===
match
---
string: 'ti_failures' [57052,57065]
string: 'ti_failures' [57051,57064]
===
match
---
simple_stmt [67360,67430]
simple_stmt [67312,67382]
===
match
---
expr_stmt [50886,50912]
expr_stmt [50924,50950]
===
match
---
name: session [59301,59308]
name: session [59253,59260]
===
match
---
operator: = [50937,50938]
operator: = [50975,50976]
===
match
---
with_stmt [72000,72065]
with_stmt [71952,72017]
===
match
---
atom [47057,47228]
atom [47057,47228]
===
match
---
name: log_message [58478,58489]
name: log_message [58477,58488]
===
match
---
param [14329,14341]
param [14329,14341]
===
match
---
name: task_id [58533,58540]
name: task_id [58532,58539]
===
match
---
name: self [25959,25963]
name: self [25959,25963]
===
match
---
operator: = [39767,39768]
operator: = [39767,39768]
===
match
---
suite [82352,82382]
suite [82304,82334]
===
match
---
name: task_id [19713,19720]
name: task_id [19713,19720]
===
match
---
operator: , [11092,11093]
operator: , [11092,11093]
===
match
---
trailer [42837,42846]
trailer [42837,42846]
===
match
---
name: pop [3686,3689]
name: pop [3686,3689]
===
match
---
comp_op [47174,47180]
comp_op [47174,47180]
===
match
---
expr_stmt [23458,23493]
expr_stmt [23458,23493]
===
match
---
name: str [81363,81366]
name: str [81315,81318]
===
match
---
simple_stmt [40402,40439]
simple_stmt [40402,40439]
===
match
---
trailer [60814,60823]
trailer [60766,60775]
===
match
---
simple_stmt [3178,3195]
simple_stmt [3178,3195]
===
match
---
expr_stmt [50921,50956]
expr_stmt [50959,50994]
===
match
---
if_stmt [18262,18336]
if_stmt [18262,18336]
===
match
---
name: deserialize_json [64574,64590]
name: deserialize_json [64526,64542]
===
match
---
operator: , [64639,64640]
operator: , [64591,64592]
===
match
---
name: self [81422,81426]
name: self [81374,81378]
===
match
---
simple_stmt [59948,59972]
simple_stmt [59900,59924]
===
match
---
trailer [62440,62448]
trailer [62392,62400]
===
match
---
operator: , [15807,15808]
operator: , [15807,15808]
===
match
---
name: task_tries [7090,7100]
name: task_tries [7090,7100]
===
match
---
simple_stmt [30299,30379]
simple_stmt [30299,30379]
===
match
---
operator: == [54747,54749]
operator: == [54746,54748]
===
match
---
funcdef [32348,32970]
funcdef [32348,32970]
===
match
---
name: dep_status [31860,31870]
name: dep_status [31860,31870]
===
match
---
name: running [13172,13179]
name: running [13172,13179]
===
match
---
trailer [24960,24969]
trailer [24960,24969]
===
match
---
fstring_string: . [42954,42955]
fstring_string: . [42954,42955]
===
match
---
name: log [32659,32662]
name: log [32659,32662]
===
match
---
decorator [45730,45747]
decorator [45730,45747]
===
match
---
name: execution_date [7074,7088]
name: execution_date [7074,7088]
===
match
---
operator: , [35740,35741]
operator: , [35740,35741]
===
match
---
operator: , [14319,14320]
operator: , [14319,14320]
===
match
---
atom_expr [11291,11300]
atom_expr [11291,11300]
===
match
---
trailer [7446,7455]
trailer [7446,7455]
===
match
---
operator: , [14123,14124]
operator: , [14123,14124]
===
match
---
name: provide_session [30959,30974]
name: provide_session [30959,30974]
===
match
---
comparison [52625,52651]
comparison [52624,52650]
===
match
---
operator: , [53665,53666]
operator: , [53664,53665]
===
match
---
trailer [45124,45126]
trailer [45124,45126]
===
match
---
operator: , [29221,29222]
operator: , [29221,29222]
===
match
---
name: lock_for_update [81630,81645]
name: lock_for_update [81582,81597]
===
match
---
trailer [43947,43961]
trailer [43947,43961]
===
match
---
operator: = [53619,53620]
operator: = [53618,53619]
===
match
---
name: execution_date [24042,24056]
name: execution_date [24042,24056]
===
match
---
suite [37841,37895]
suite [37841,37895]
===
match
---
atom_expr [57117,57140]
atom_expr [57116,57139]
===
match
---
name: min_backoff [34177,34188]
name: min_backoff [34177,34188]
===
match
---
name: self [40985,40989]
name: self [40985,40989]
===
match
---
name: task_id [33047,33054]
name: task_id [33047,33054]
===
match
---
operator: = [12100,12101]
operator: = [12100,12101]
===
match
---
name: _CURRENT_CONTEXT [3669,3685]
name: _CURRENT_CONTEXT [3669,3685]
===
match
---
operator: = [74228,74229]
operator: = [74180,74181]
===
match
---
name: ignore_ti_state [15817,15832]
name: ignore_ti_state [15817,15832]
===
match
---
comp_op [47313,47319]
comp_op [47313,47319]
===
match
---
comparison [24878,24906]
comparison [24878,24906]
===
match
---
operator: , [15053,15054]
operator: , [15053,15054]
===
match
---
operator: , [1867,1868]
operator: , [1867,1868]
===
match
---
for_stmt [7391,7511]
for_stmt [7391,7511]
===
match
---
name: pool [15436,15440]
name: pool [15436,15440]
===
match
---
name: on_failure_callback [52702,52721]
name: on_failure_callback [52701,52720]
===
match
---
expr_stmt [60664,60709]
expr_stmt [60616,60661]
===
match
---
param [35780,35810]
param [35780,35810]
===
match
---
name: filter_by [60426,60435]
name: filter_by [60378,60387]
===
match
---
param [3366,3382]
param [3366,3382]
===
match
---
operator: , [18035,18036]
operator: , [18035,18036]
===
match
---
name: job_id [42818,42824]
name: job_id [42818,42824]
===
match
---
suite [44872,44960]
suite [44872,44960]
===
match
---
arglist [11806,11844]
arglist [11806,11844]
===
match
---
simple_stmt [820,835]
simple_stmt [820,835]
===
match
---
trailer [21910,21916]
trailer [21910,21916]
===
match
---
name: self [42804,42808]
name: self [42804,42808]
===
match
---
suite [77466,77839]
suite [77418,77791]
===
match
---
name: RenderedTaskInstanceFields [66408,66434]
name: RenderedTaskInstanceFields [66360,66386]
===
match
---
trailer [29856,29875]
trailer [29856,29875]
===
match
---
atom_expr [35047,35057]
atom_expr [35047,35057]
===
match
---
simple_stmt [81296,81325]
simple_stmt [81248,81277]
===
match
---
fstring_end: " [19441,19442]
fstring_end: " [19441,19442]
===
match
---
name: self [26493,26497]
name: self [26493,26497]
===
match
---
name: start_date [72896,72906]
name: start_date [72848,72858]
===
match
---
name: self [40354,40358]
name: self [40354,40358]
===
match
---
simple_stmt [64523,64597]
simple_stmt [64475,64549]
===
match
---
atom_expr [32522,32538]
atom_expr [32522,32538]
===
match
---
simple_stmt [24956,25002]
simple_stmt [24956,25002]
===
match
---
operator: = [37989,37990]
operator: = [37989,37990]
===
match
---
string: "at task runtime. Attempt %s of " [40163,40196]
string: "at task runtime. Attempt %s of " [40163,40196]
===
match
---
name: context [49217,49224]
name: context [49217,49224]
===
match
---
atom_expr [22780,22794]
atom_expr [22780,22794]
===
match
---
simple_stmt [56615,56643]
simple_stmt [56614,56642]
===
match
---
comparison [79202,79239]
comparison [79154,79191]
===
match
---
name: job_id [15409,15415]
name: job_id [15409,15415]
===
match
---
atom_expr [5268,5276]
atom_expr [5268,5276]
===
match
---
operator: = [11784,11785]
operator: = [11784,11785]
===
match
---
operator: ** [10433,10435]
operator: ** [10433,10435]
===
match
---
name: execution_date [11130,11144]
name: execution_date [11130,11144]
===
match
---
atom_expr [5279,5293]
atom_expr [5279,5293]
===
match
---
name: refresh_from_db [43166,43181]
name: refresh_from_db [43166,43181]
===
match
---
expr_stmt [22476,22503]
expr_stmt [22476,22503]
===
match
---
suite [23689,24169]
suite [23689,24169]
===
match
---
name: error_file [44776,44786]
name: error_file [44776,44786]
===
match
---
name: task [27296,27300]
name: task [27296,27300]
===
match
---
operator: = [26545,26546]
operator: = [26545,26546]
===
match
---
trailer [19603,19607]
trailer [19603,19607]
===
match
---
atom_expr [60859,60878]
atom_expr [60811,60830]
===
match
---
trailer [31878,31902]
trailer [31878,31902]
===
match
---
trailer [7926,7934]
trailer [7926,7934]
===
match
---
sync_comp_for [77047,77106]
sync_comp_for [76999,77058]
===
match
---
name: get_previous_start_date [65484,65507]
name: get_previous_start_date [65436,65459]
===
match
---
name: SUCCESS [65520,65527]
name: SUCCESS [65472,65479]
===
match
---
suite [40958,40991]
suite [40958,40991]
===
match
---
suite [27984,28069]
suite [27984,28069]
===
match
---
if_stmt [39110,39349]
if_stmt [39110,39349]
===
match
---
parameters [81263,81269]
parameters [81215,81221]
===
match
---
trailer [45031,45039]
trailer [45031,45039]
===
match
---
trailer [3590,3599]
trailer [3590,3599]
===
match
---
operator: , [35176,35177]
operator: , [35176,35177]
===
match
---
name: dag_id [11226,11232]
name: dag_id [11226,11232]
===
match
---
string: 'dag' [60181,60186]
string: 'dag' [60133,60138]
===
match
---
name: self [56134,56138]
name: self [56133,56137]
===
match
---
atom_expr [32773,32792]
atom_expr [32773,32792]
===
match
---
name: self [52625,52629]
name: self [52624,52628]
===
match
---
trailer [12090,12099]
trailer [12090,12099]
===
match
---
trailer [70780,70989]
trailer [70732,70941]
===
match
---
name: in_ [6911,6914]
name: in_ [6911,6914]
===
match
---
name: dag [4791,4794]
name: dag [4791,4794]
===
match
---
name: job [7395,7398]
name: job [7395,7398]
===
match
---
string: """Setting Next Try Number""" [13953,13982]
string: """Setting Next Try Number""" [13953,13982]
===
match
---
trailer [71419,71436]
trailer [71371,71388]
===
match
---
number: 1 [40691,40692]
number: 1 [40691,40692]
===
match
---
return_stmt [81296,81324]
return_stmt [81248,81276]
===
match
---
operator: = [9648,9649]
operator: = [9648,9649]
===
match
---
operator: = [14335,14336]
operator: = [14335,14336]
===
match
---
fstring_expr [42955,42969]
fstring_expr [42955,42969]
===
match
---
atom_expr [43088,43148]
atom_expr [43088,43148]
===
match
---
expr_stmt [61333,61374]
expr_stmt [61285,61326]
===
match
---
name: airflow [1879,1886]
name: airflow [1879,1886]
===
match
---
funcdef [8166,8339]
funcdef [8166,8339]
===
match
---
name: self [53125,53129]
name: self [53124,53128]
===
match
---
operator: = [78365,78366]
operator: = [78317,78318]
===
match
---
atom_expr [18079,18109]
atom_expr [18079,18109]
===
match
---
expr_stmt [64053,64105]
expr_stmt [64005,64057]
===
match
---
name: log [40707,40710]
name: log [40707,40710]
===
match
---
trailer [11199,11201]
trailer [11199,11201]
===
match
---
operator: = [11268,11269]
operator: = [11268,11269]
===
match
---
atom [19659,19868]
atom [19659,19868]
===
match
---
name: task_copy [51617,51626]
name: task_copy [51655,51664]
===
match
---
simple_stmt [55451,55734]
simple_stmt [55450,55733]
===
match
---
name: execution_date [74164,74178]
name: execution_date [74116,74130]
===
match
---
trailer [39216,39239]
trailer [39216,39239]
===
match
---
operator: , [77093,77094]
operator: , [77045,77046]
===
match
---
trailer [48576,48608]
trailer [48576,48608]
===
match
---
testlist_star_expr [72542,72581]
testlist_star_expr [72494,72533]
===
match
---
name: self [80456,80460]
name: self [80408,80412]
===
match
---
trailer [11171,11176]
trailer [11171,11176]
===
match
---
trailer [60563,60570]
trailer [60515,60522]
===
match
---
param [35736,35741]
param [35736,35741]
===
match
---
simple_stmt [20551,20571]
simple_stmt [20551,20571]
===
match
---
trailer [79898,79914]
trailer [79850,79866]
===
match
---
atom_expr [68519,68531]
atom_expr [68471,68483]
===
match
---
import_from [2110,2170]
import_from [2110,2170]
===
match
---
suite [50456,50521]
suite [50494,50559]
===
match
---
fstring_end: ' [48838,48839]
fstring_end: ' [48838,48839]
===
match
---
name: dag_id [78803,78809]
name: dag_id [78755,78761]
===
match
---
suite [3643,3925]
suite [3643,3925]
===
match
---
operator: = [73026,73027]
operator: = [72978,72979]
===
match
---
operator: = [72934,72935]
operator: = [72886,72887]
===
match
---
operator: = [29623,29624]
operator: = [29623,29624]
===
match
---
trailer [4696,4703]
trailer [4696,4703]
===
match
---
subscriptlist [3980,3994]
subscriptlist [3980,3994]
===
match
---
name: self [22552,22556]
name: self [22552,22556]
===
match
---
expr_stmt [9951,9982]
expr_stmt [9951,9982]
===
match
---
operator: , [22959,22960]
operator: , [22959,22960]
===
match
---
name: ignore_depends_on_past [35819,35841]
name: ignore_depends_on_past [35819,35841]
===
match
---
return_stmt [19641,19868]
return_stmt [19641,19868]
===
match
---
trailer [81307,81324]
trailer [81259,81276]
===
match
---
trailer [42778,42795]
trailer [42778,42795]
===
match
---
suite [4437,4709]
suite [4437,4709]
===
match
---
trailer [47910,48049]
trailer [47910,48049]
===
match
---
name: self [67517,67521]
name: self [67469,67473]
===
match
---
trailer [64856,64863]
trailer [64808,64815]
===
match
---
name: ignore_ti_state [35905,35920]
name: ignore_ti_state [35905,35920]
===
match
---
name: max_tries [59632,59641]
name: max_tries [59584,59593]
===
match
---
try_stmt [66678,67181]
try_stmt [66630,67133]
===
match
---
operator: = [37736,37737]
operator: = [37736,37737]
===
match
---
atom_expr [4693,4703]
atom_expr [4693,4703]
===
match
---
name: pid [10306,10309]
name: pid [10306,10309]
===
match
---
argument [46763,46787]
argument [46763,46787]
===
match
---
name: ignore_all_deps [15122,15137]
name: ignore_all_deps [15122,15137]
===
match
---
trailer [21773,21788]
trailer [21773,21788]
===
match
---
fstring_start: f" [19735,19737]
fstring_start: f" [19735,19737]
===
match
---
atom_expr [46712,46741]
atom_expr [46712,46741]
===
match
---
trailer [52974,52994]
trailer [52973,52993]
===
match
---
atom_expr [24719,24781]
atom_expr [24719,24781]
===
match
---
name: log [20872,20875]
name: log [20872,20875]
===
match
---
trailer [21532,21576]
trailer [21532,21576]
===
match
---
atom_expr [71029,71153]
atom_expr [70981,71105]
===
match
---
atom_expr [56949,56968]
atom_expr [56948,56967]
===
match
---
name: task [34752,34756]
name: task [34752,34756]
===
match
---
name: filter [26097,26103]
name: filter [26097,26103]
===
match
---
param [68078,68111]
param [68030,68063]
===
match
---
trailer [68422,68424]
trailer [68374,68376]
===
match
---
name: Column [9705,9711]
name: Column [9705,9711]
===
match
---
operator: , [67804,67805]
operator: , [67756,67757]
===
match
---
operator: = [16092,16093]
operator: = [16092,16093]
===
match
---
trailer [38690,38692]
trailer [38690,38692]
===
match
---
operator: , [1668,1669]
operator: , [1668,1669]
===
match
---
trailer [68702,68717]
trailer [68654,68669]
===
match
---
not_test [25981,26009]
not_test [25981,26009]
===
match
---
name: format [74136,74142]
name: format [74088,74094]
===
match
---
trailer [30907,30931]
trailer [30907,30931]
===
match
---
atom_expr [5325,5334]
atom_expr [5325,5334]
===
match
---
name: provide_session [25417,25432]
name: provide_session [25417,25432]
===
match
---
name: BaseJob [7416,7423]
name: BaseJob [7416,7423]
===
match
---
name: timezone [40421,40429]
name: timezone [40421,40429]
===
match
---
operator: = [29595,29596]
operator: = [29595,29596]
===
match
---
atom_expr [14868,14885]
atom_expr [14868,14885]
===
match
---
operator: = [20603,20604]
operator: = [20603,20604]
===
match
---
name: task_reschedule [39267,39282]
name: task_reschedule [39267,39282]
===
match
---
try_stmt [72634,72795]
try_stmt [72586,72747]
===
match
---
name: Variable [64064,64072]
name: Variable [64016,64024]
===
match
---
trailer [9975,9981]
trailer [9975,9981]
===
match
---
atom_expr [7402,7462]
atom_expr [7402,7462]
===
match
---
operator: = [24456,24457]
operator: = [24456,24457]
===
match
---
suite [52925,53112]
suite [52924,53111]
===
match
---
operator: , [46215,46216]
operator: , [46215,46216]
===
match
---
decorator [25113,25123]
decorator [25113,25123]
===
match
---
name: error_file [44930,44940]
name: error_file [44930,44940]
===
match
---
operator: , [74291,74292]
operator: , [74243,74244]
===
match
---
name: sql [1508,1511]
name: sql [1508,1511]
===
match
---
trailer [51703,51711]
trailer [51741,51749]
===
match
---
suite [18449,18503]
suite [18449,18503]
===
match
---
name: queue [80529,80534]
name: queue [80481,80486]
===
match
---
operator: = [9773,9774]
operator: = [9773,9774]
===
match
---
trailer [26067,26073]
trailer [26067,26073]
===
match
---
atom_expr [22851,22861]
atom_expr [22851,22861]
===
match
---
trailer [20335,20342]
trailer [20335,20342]
===
match
---
trailer [56550,56580]
trailer [56549,56579]
===
match
---
param [35172,35177]
param [35172,35177]
===
match
---
simple_stmt [1813,1874]
simple_stmt [1813,1874]
===
match
---
operator: , [73240,73241]
operator: , [73192,73193]
===
match
---
name: self [43928,43932]
name: self [43928,43932]
===
match
---
trailer [45604,45610]
trailer [45604,45610]
===
match
---
name: use_default [70532,70543]
name: use_default [70484,70495]
===
match
---
atom_expr [32490,32502]
atom_expr [32490,32502]
===
match
---
atom_expr [68965,69031]
atom_expr [68917,68983]
===
match
---
atom_expr [21688,21708]
atom_expr [21688,21708]
===
match
---
name: item [64543,64547]
name: item [64495,64499]
===
match
---
name: dag_id [19127,19133]
name: dag_id [19127,19133]
===
match
---
dotted_name [2910,2938]
dotted_name [2910,2938]
===
match
---
name: max [5962,5965]
name: max [5962,5965]
===
match
---
name: filter [82080,82086]
name: filter [82032,82038]
===
match
---
atom_expr [71812,71840]
atom_expr [71764,71792]
===
match
---
trailer [71098,71103]
trailer [71050,71055]
===
match
---
name: utcnow [45118,45124]
name: utcnow [45118,45124]
===
match
---
name: session [74411,74418]
name: session [74363,74370]
===
match
---
trailer [11558,11562]
trailer [11558,11562]
===
match
---
atom_expr [6772,6789]
atom_expr [6772,6789]
===
match
---
name: ds [62127,62129]
name: ds [62079,62081]
===
match
---
string: """         Call callback defined for finished state change.          NOTE: Only invoke this function from caller of self._run_raw_task or         self.run         """ [52446,52613]
string: """         Call callback defined for finished state change.          NOTE: Only invoke this function from caller of self._run_raw_task or         self.run         """ [52445,52612]
===
match
---
name: KubeConfig [68412,68422]
name: KubeConfig [68364,68374]
===
match
---
atom_expr [32654,32889]
atom_expr [32654,32889]
===
match
---
trailer [65056,65064]
trailer [65008,65016]
===
match
---
comparison [44640,44683]
comparison [44640,44683]
===
match
---
suite [35203,35619]
suite [35203,35619]
===
match
---
simple_stmt [1954,2011]
simple_stmt [1954,2011]
===
match
---
name: session [59088,59095]
name: session [59040,59047]
===
match
---
trailer [80824,80840]
trailer [80776,80792]
===
match
---
name: str [81194,81197]
name: str [81146,81149]
===
match
---
operator: , [58646,58647]
operator: , [58645,58646]
===
match
---
operator: % [34199,34200]
operator: % [34199,34200]
===
match
---
trailer [81149,81156]
trailer [81101,81108]
===
match
---
operator: = [5590,5591]
operator: = [5590,5591]
===
match
---
suite [4111,4132]
suite [4111,4132]
===
match
---
simple_stmt [4149,4175]
simple_stmt [4149,4175]
===
match
---
operator: , [55225,55226]
operator: , [55224,55225]
===
match
---
name: self [59627,59631]
name: self [59579,59583]
===
match
---
import_name [787,804]
import_name [787,804]
===
match
---
simple_stmt [56010,56080]
simple_stmt [56009,56079]
===
match
---
if_stmt [76917,77390]
if_stmt [76869,77342]
===
match
---
param [48393,48398]
param [48393,48398]
===
match
---
name: _run_mini_scheduler_on_child_tasks [45681,45715]
name: _run_mini_scheduler_on_child_tasks [45681,45715]
===
match
---
trailer [53896,53936]
trailer [53895,53935]
===
match
---
trailer [13204,13216]
trailer [13204,13216]
===
match
---
string: "TaskInstance.dag_id == DagModel.dag_id" [10976,11016]
string: "TaskInstance.dag_id == DagModel.dag_id" [10976,11016]
===
match
---
simple_stmt [24472,24670]
simple_stmt [24472,24670]
===
match
---
name: get [63302,63305]
name: get [63254,63257]
===
match
---
operator: } [7750,7751]
operator: } [7750,7751]
===
match
---
name: session [29639,29646]
name: session [29639,29646]
===
match
---
strings [43682,43796]
strings [43682,43796]
===
match
---
name: primary_key [9670,9681]
name: primary_key [9670,9681]
===
match
---
operator: , [44181,44182]
operator: , [44181,44182]
===
match
---
simple_stmt [45676,45725]
simple_stmt [45676,45725]
===
match
---
atom_expr [10350,10382]
atom_expr [10350,10382]
===
match
---
not_test [67441,67462]
not_test [67393,67414]
===
match
---
name: html_content [71251,71263]
name: html_content [71203,71215]
===
match
---
name: timedelta [60881,60890]
name: timedelta [60833,60842]
===
match
---
import_as_names [1037,1102]
import_as_names [1037,1102]
===
match
---
trailer [18607,18620]
trailer [18607,18620]
===
match
---
funcdef [23649,24169]
funcdef [23649,24169]
===
match
---
atom_expr [60475,60494]
atom_expr [60427,60446]
===
match
---
name: str [79633,79636]
name: str [79585,79588]
===
match
---
name: State [55776,55781]
name: State [55775,55780]
===
match
---
operator: @ [59110,59111]
operator: @ [59062,59063]
===
match
---
operator: = [71363,71364]
operator: = [71315,71316]
===
match
---
atom_expr [21592,21799]
atom_expr [21592,21799]
===
match
---
comparison [26117,26151]
comparison [26117,26151]
===
match
---
operator: , [4312,4313]
operator: , [4312,4313]
===
match
---
name: self [52897,52901]
name: self [52896,52900]
===
match
---
suite [57092,57142]
suite [57091,57141]
===
match
---
name: self [8624,8628]
name: self [8624,8628]
===
match
---
name: airflow [2858,2865]
name: airflow [2858,2865]
===
match
---
name: self [55641,55645]
name: self [55640,55644]
===
match
---
simple_stmt [79046,79255]
simple_stmt [78998,79207]
===
match
---
trailer [23404,23420]
trailer [23404,23420]
===
match
---
atom_expr [40354,40385]
atom_expr [40354,40385]
===
match
---
trailer [81218,81224]
trailer [81170,81176]
===
match
---
name: List [3260,3264]
name: List [3260,3264]
===
match
---
param [67792,67797]
param [67744,67749]
===
match
---
atom_expr [32244,32301]
atom_expr [32244,32301]
===
match
---
operator: , [1809,1810]
operator: , [1809,1810]
===
match
---
name: Variable [63556,63564]
name: Variable [63508,63516]
===
match
---
arglist [4693,4707]
arglist [4693,4707]
===
match
---
operator: = [15415,15416]
operator: = [15415,15416]
===
match
---
operator: , [18026,18027]
operator: , [18026,18027]
===
match
---
name: self [43814,43818]
name: self [43814,43818]
===
match
---
name: self [43843,43847]
name: self [43843,43847]
===
match
---
import_from [2590,2656]
import_from [2590,2656]
===
match
---
atom_expr [30318,30336]
atom_expr [30318,30336]
===
match
---
operator: , [40318,40319]
operator: , [40318,40319]
===
match
---
suite [4543,4709]
suite [4543,4709]
===
match
---
trailer [33948,33963]
trailer [33948,33963]
===
match
---
simple_stmt [77270,77317]
simple_stmt [77222,77269]
===
match
---
decorator [55119,55136]
decorator [55118,55135]
===
match
---
name: Sentry [45752,45758]
name: Sentry [45752,45758]
===
match
---
trailer [40850,40856]
trailer [40850,40856]
===
match
---
atom_expr [22436,22449]
atom_expr [22436,22449]
===
match
---
trailer [4412,4430]
trailer [4412,4430]
===
match
---
trailer [69000,69031]
trailer [68952,68983]
===
match
---
name: context [50447,50454]
name: context [50485,50492]
===
match
---
operator: , [15846,15847]
operator: , [15846,15847]
===
match
---
and_test [25347,25410]
and_test [25347,25410]
===
match
---
simple_stmt [53354,53386]
simple_stmt [53353,53385]
===
match
---
name: update [62508,62514]
name: update [62460,62466]
===
match
---
param [63063,63068]
param [63015,63020]
===
match
---
trailer [18171,18182]
trailer [18171,18182]
===
match
---
name: task [62515,62519]
name: task [62467,62471]
===
match
---
trailer [77383,77389]
trailer [77335,77341]
===
match
---
simple_stmt [19949,20231]
simple_stmt [19949,20231]
===
match
---
simple_stmt [68130,68177]
simple_stmt [68082,68129]
===
match
---
operator: == [39124,39126]
operator: == [39124,39126]
===
match
---
name: with_try_number [8608,8623]
name: with_try_number [8608,8623]
===
match
---
atom_expr [19258,19289]
atom_expr [19258,19289]
===
match
---
name: delay_backoff_in_seconds [34706,34730]
name: delay_backoff_in_seconds [34706,34730]
===
match
---
trailer [55992,55999]
trailer [55991,55998]
===
match
---
name: self [19136,19140]
name: self [19136,19140]
===
match
---
name: rendered_task_instance_fields [66473,66502]
name: rendered_task_instance_fields [66425,66454]
===
match
---
name: duration [25019,25027]
name: duration [25019,25027]
===
match
---
number: 256 [10037,10040]
number: 256 [10037,10040]
===
match
---
name: ts_nodash_with_tz [65934,65951]
name: ts_nodash_with_tz [65886,65903]
===
match
---
atom_expr [11221,11232]
atom_expr [11221,11232]
===
match
---
name: activate_dag_runs [7519,7536]
name: activate_dag_runs [7519,7536]
===
match
---
trailer [71563,71772]
trailer [71515,71724]
===
match
---
name: dep_context [39906,39917]
name: dep_context [39906,39917]
===
match
---
return_stmt [78208,78219]
return_stmt [78160,78171]
===
match
---
name: start_date [7950,7960]
name: start_date [7950,7960]
===
match
---
operator: , [59215,59216]
operator: , [59167,59168]
===
match
---
name: self [57884,57888]
name: self [57883,57887]
===
match
---
name: dag_id [6693,6699]
name: dag_id [6693,6699]
===
match
---
funcdef [33100,34873]
funcdef [33100,34873]
===
match
---
name: logging_mixin [2513,2526]
name: logging_mixin [2513,2526]
===
match
---
name: self [23592,23596]
name: self [23592,23596]
===
match
---
name: SKIPPED [43631,43638]
name: SKIPPED [43631,43638]
===
match
---
name: error [56497,56502]
name: error [56496,56501]
===
match
---
name: prev_ti [30318,30325]
name: prev_ti [30318,30325]
===
match
---
expr_stmt [18979,19016]
expr_stmt [18979,19016]
===
match
---
param [28617,28621]
param [28617,28621]
===
match
---
name: airflow [82562,82569]
name: airflow [82514,82521]
===
match
---
trailer [23999,24007]
trailer [23999,24007]
===
match
---
trailer [51007,51009]
trailer [51045,51047]
===
match
---
suite [44976,45056]
suite [44976,45056]
===
match
---
trailer [18297,18304]
trailer [18297,18304]
===
match
---
operator: , [14154,14155]
operator: , [14154,14155]
===
match
---
simple_stmt [14933,15488]
simple_stmt [14933,15488]
===
match
---
name: commit [45628,45634]
name: commit [45628,45634]
===
match
---
name: ts [65861,65863]
name: ts [65813,65815]
===
match
---
operator: -> [19933,19935]
operator: -> [19933,19935]
===
match
---
atom_expr [74005,74193]
atom_expr [73957,74145]
===
match
---
trailer [49266,49270]
trailer [49266,49270]
===
match
---
name: self [37590,37594]
name: self [37590,37594]
===
match
---
trailer [78916,78924]
trailer [78868,78876]
===
match
---
name: TaskInstance [14940,14952]
name: TaskInstance [14940,14952]
===
match
---
name: dep_status [32853,32863]
name: dep_status [32853,32863]
===
match
---
operator: = [72235,72236]
operator: = [72187,72188]
===
match
---
param [19913,19918]
param [19913,19918]
===
match
---
fstring_start: f" [14762,14764]
fstring_start: f" [14762,14764]
===
match
---
trailer [48757,48759]
trailer [48757,48759]
===
match
---
simple_stmt [48522,48542]
simple_stmt [48522,48542]
===
match
---
name: DeprecationWarning [29000,29018]
name: DeprecationWarning [29000,29018]
===
match
---
trailer [3685,3689]
trailer [3685,3689]
===
match
---
name: session [60387,60394]
name: session [60339,60346]
===
match
---
tfpdef [35865,35887]
tfpdef [35865,35887]
===
match
---
suite [3173,3195]
suite [3173,3195]
===
match
---
trailer [22692,22708]
trailer [22692,22708]
===
match
---
if_stmt [18344,18415]
if_stmt [18344,18415]
===
match
---
name: render_templates [68055,68071]
name: render_templates [68007,68023]
===
match
---
suite [44684,44708]
suite [44684,44708]
===
match
---
name: ti [47302,47304]
name: ti [47302,47304]
===
match
---
trailer [65507,65528]
trailer [65459,65480]
===
match
---
name: task [52850,52854]
name: task [52849,52853]
===
match
---
name: property [19449,19457]
name: property [19449,19457]
===
match
---
name: execution_date [8799,8813]
name: execution_date [8799,8813]
===
match
---
operator: | [32539,32540]
operator: | [32539,32540]
===
match
---
atom_expr [3742,3924]
atom_expr [3742,3924]
===
match
---
operator: = [41815,41816]
operator: = [41815,41816]
===
match
---
string: '' [60130,60132]
string: '' [60082,60084]
===
match
---
tfpdef [59187,59215]
tfpdef [59139,59167]
===
match
---
name: provide_session [35137,35152]
name: provide_session [35137,35152]
===
match
---
name: full_filepath [14712,14725]
name: full_filepath [14712,14725]
===
match
---
name: ti [79836,79838]
name: ti [79788,79790]
===
match
---
operator: = [38479,38480]
operator: = [38479,38480]
===
match
---
fstring_expr [45026,45040]
fstring_expr [45026,45040]
===
match
---
expr_stmt [34790,34835]
expr_stmt [34790,34835]
===
match
---
name: self [22120,22124]
name: self [22120,22124]
===
match
---
name: TaskInstance [79793,79805]
name: TaskInstance [79745,79757]
===
match
---
trailer [52265,52307]
trailer [52300,52342]
===
match
---
trailer [72969,72983]
trailer [72921,72935]
===
match
---
atom_expr [49443,49482]
atom_expr [49443,49482]
===
match
---
name: operator [22740,22748]
name: operator [22740,22748]
===
match
---
name: task [60443,60447]
name: task [60395,60399]
===
match
---
name: self [68579,68583]
name: self [68531,68535]
===
match
---
name: session [23675,23682]
name: session [23675,23682]
===
match
---
atom_expr [20993,21009]
atom_expr [20993,21009]
===
match
---
name: get [19059,19062]
name: get [19059,19062]
===
match
---
operator: = [76964,76965]
operator: = [76916,76917]
===
match
---
expr_stmt [39304,39348]
expr_stmt [39304,39348]
===
match
---
operator: , [52380,52381]
operator: , [52379,52380]
===
match
---
comparison [78969,78987]
comparison [78921,78939]
===
match
---
suite [14899,14924]
suite [14899,14924]
===
match
---
operator: = [49191,49192]
operator: = [49191,49192]
===
match
---
name: jinja_context [71422,71435]
name: jinja_context [71374,71387]
===
match
---
name: airflow [60285,60292]
name: airflow [60237,60244]
===
match
---
trailer [5409,5418]
trailer [5409,5418]
===
match
---
operator: } [77119,77120]
operator: } [77071,77072]
===
match
---
name: state [57930,57935]
name: state [57929,57934]
===
match
---
operator: , [68758,68759]
operator: , [68710,68711]
===
match
---
operator: , [79393,79394]
operator: , [79345,79346]
===
match
---
tfpdef [64011,64020]
tfpdef [63963,63972]
===
match
---
name: _execute_task [51154,51167]
name: _execute_task [51192,51205]
===
match
---
tfpdef [53711,53726]
tfpdef [53710,53725]
===
match
---
simple_stmt [2750,2815]
simple_stmt [2750,2815]
===
match
---
string: 'params' [65078,65086]
string: 'params' [65030,65038]
===
match
---
if_stmt [45514,45611]
if_stmt [45514,45611]
===
match
---
operator: @ [41636,41637]
operator: @ [41636,41637]
===
match
---
not_test [11499,11540]
not_test [11499,11540]
===
match
---
trailer [39095,39097]
trailer [39095,39097]
===
match
---
trailer [40063,40071]
trailer [40063,40071]
===
match
---
expr_stmt [34680,34731]
expr_stmt [34680,34731]
===
match
---
name: state [80119,80124]
name: state [80071,80076]
===
match
---
trailer [4692,4708]
trailer [4692,4708]
===
match
---
operator: = [14218,14219]
operator: = [14218,14219]
===
match
---
trailer [72588,72614]
trailer [72540,72566]
===
match
---
atom_expr [39572,39848]
atom_expr [39572,39848]
===
match
---
operator: , [65633,65634]
operator: , [65585,65586]
===
match
---
atom_expr [41230,41307]
atom_expr [41230,41307]
===
match
---
operator: } [44682,44683]
operator: } [44682,44683]
===
match
---
simple_stmt [29526,29579]
simple_stmt [29526,29579]
===
match
---
name: dagrun [60300,60306]
name: dagrun [60252,60258]
===
match
---
atom_expr [27301,27310]
atom_expr [27301,27310]
===
match
---
name: signal [48618,48624]
name: signal [48618,48624]
===
match
---
operator: = [29807,29808]
operator: = [29807,29808]
===
match
---
trailer [7439,7442]
trailer [7439,7442]
===
match
---
trailer [72125,72142]
trailer [72077,72094]
===
match
---
arglist [8767,8825]
arglist [8767,8825]
===
match
---
atom_expr [58215,58225]
atom_expr [58214,58224]
===
match
---
atom [44654,44683]
atom [44654,44683]
===
match
---
name: prev_attempted_tries [5983,6003]
name: prev_attempted_tries [5983,6003]
===
match
---
atom_expr [80051,80067]
atom_expr [80003,80019]
===
match
---
atom_expr [33837,34056]
atom_expr [33837,34056]
===
match
---
simple_stmt [30632,30888]
simple_stmt [30632,30888]
===
match
---
parameters [78015,78070]
parameters [77967,78022]
===
match
---
name: filter_for_tis [78001,78015]
name: filter_for_tis [77953,77967]
===
match
---
atom_expr [47181,47210]
atom_expr [47181,47210]
===
match
---
name: ti [21930,21932]
name: ti [21930,21932]
===
match
---
name: task [42641,42645]
name: task [42641,42645]
===
match
---
arglist [27926,27954]
arglist [27926,27954]
===
match
---
name: BaseJob [7374,7381]
name: BaseJob [7374,7381]
===
match
---
atom_expr [36057,36070]
atom_expr [36057,36070]
===
match
---
name: self [79854,79858]
name: self [79806,79810]
===
match
---
comparison [82100,82135]
comparison [82052,82087]
===
match
---
dotted_name [13259,13276]
dotted_name [13259,13276]
===
match
---
operator: = [4780,4781]
operator: = [4780,4781]
===
match
---
suite [29293,29717]
suite [29293,29717]
===
match
---
simple_stmt [30105,30154]
simple_stmt [30105,30154]
===
match
---
trailer [40358,40362]
trailer [40358,40362]
===
match
---
name: dates [7104,7109]
name: dates [7104,7109]
===
match
---
operator: , [21788,21789]
operator: , [21788,21789]
===
match
---
simple_stmt [61928,61979]
simple_stmt [61880,61931]
===
match
---
simple_stmt [18707,18729]
simple_stmt [18707,18729]
===
match
---
simple_stmt [54389,54432]
simple_stmt [54388,54431]
===
match
---
simple_stmt [55094,55114]
simple_stmt [55093,55113]
===
match
---
name: bool [15863,15867]
name: bool [15863,15867]
===
match
---
import_from [3096,3153]
import_from [3096,3153]
===
match
---
arglist [58391,58723]
arglist [58390,58722]
===
match
---
name: loader [71065,71071]
name: loader [71017,71023]
===
match
---
except_clause [44034,44091]
except_clause [44034,44091]
===
match
---
expr_stmt [22851,22868]
expr_stmt [22851,22868]
===
match
---
decorator [35136,35153]
decorator [35136,35153]
===
match
---
operator: , [59257,59258]
operator: , [59209,59210]
===
match
---
name: Optional [29793,29801]
name: Optional [29793,29801]
===
match
---
name: ignore_depends_on_past [14196,14218]
name: ignore_depends_on_past [14196,14218]
===
match
---
name: str [80217,80220]
name: str [80169,80172]
===
match
---
trailer [22811,22815]
trailer [22811,22815]
===
match
---
suite [62714,63600]
suite [62666,63552]
===
match
---
name: dag_run [64693,64700]
name: dag_run [64645,64652]
===
match
---
atom_expr [60779,60798]
atom_expr [60731,60750]
===
match
---
simple_stmt [2657,2700]
simple_stmt [2657,2700]
===
match
---
trailer [55539,55554]
trailer [55538,55553]
===
match
---
atom_expr [72891,72906]
atom_expr [72843,72858]
===
match
---
atom_expr [51807,51829]
atom_expr [51845,51867]
===
match
---
trailer [60894,60903]
trailer [60846,60855]
===
match
---
atom_expr [42804,42815]
atom_expr [42804,42815]
===
match
---
operator: = [29832,29833]
operator: = [29832,29833]
===
match
---
operator: , [74669,74670]
operator: , [74621,74622]
===
match
---
simple_stmt [44815,44821]
simple_stmt [44815,44821]
===
match
---
name: sqlalchemy [1454,1464]
name: sqlalchemy [1454,1464]
===
match
---
argument [38351,38382]
argument [38351,38382]
===
match
---
suite [64170,64208]
suite [64122,64160]
===
match
---
trailer [48624,48631]
trailer [48624,48631]
===
match
---
trailer [70751,70758]
trailer [70703,70710]
===
match
---
name: _execution_date [79899,79914]
name: _execution_date [79851,79866]
===
match
---
name: tis [5183,5186]
name: tis [5183,5186]
===
match
---
name: execution_date [11769,11783]
name: execution_date [11769,11783]
===
match
---
simple_stmt [22308,22382]
simple_stmt [22308,22382]
===
match
---
expr_stmt [19246,19290]
expr_stmt [19246,19290]
===
match
---
trailer [63568,63599]
trailer [63520,63551]
===
match
---
name: items [7199,7204]
name: items [7199,7204]
===
match
---
name: self [76444,76448]
name: self [76396,76400]
===
match
---
parameters [22954,22986]
parameters [22954,22986]
===
match
---
operator: = [61660,61661]
operator: = [61612,61613]
===
match
---
name: downstream_task_ids [26195,26214]
name: downstream_task_ids [26195,26214]
===
match
---
operator: , [15646,15647]
operator: , [15646,15647]
===
match
---
funcdef [81176,81225]
funcdef [81128,81177]
===
match
---
atom_expr [40912,40925]
atom_expr [40912,40925]
===
match
---
trailer [49692,49719]
trailer [49692,49719]
===
match
---
operator: , [76583,76584]
operator: , [76535,76536]
===
match
---
decorated [59827,66190]
decorated [59779,66142]
===
match
---
atom_expr [51527,51561]
atom_expr [51565,51599]
===
match
---
trailer [71903,71914]
trailer [71855,71866]
===
match
---
trailer [56623,56629]
trailer [56622,56628]
===
match
---
string: "task" [47446,47452]
string: "task" [47446,47452]
===
match
---
name: dag [14729,14732]
name: dag [14729,14732]
===
match
---
param [77865,77870]
param [77817,77822]
===
match
---
string: "%s" [56630,56634]
string: "%s" [56629,56633]
===
match
---
name: dag_id [78971,78977]
name: dag_id [78923,78929]
===
match
---
trailer [25963,25968]
trailer [25963,25968]
===
match
---
number: 1 [13251,13252]
number: 1 [13251,13252]
===
match
---
name: self [48448,48452]
name: self [48448,48452]
===
match
---
operator: , [44668,44669]
operator: , [44668,44669]
===
match
---
name: airflow [2820,2827]
name: airflow [2820,2827]
===
match
---
operator: @ [73103,73104]
operator: @ [73055,73056]
===
match
---
simple_stmt [58810,58834]
simple_stmt [58809,58833]
===
match
---
suite [64432,64597]
suite [64384,64549]
===
match
---
or_test [27664,27714]
or_test [27664,27714]
===
match
---
name: task [42724,42728]
name: task [42724,42728]
===
match
---
operator: = [61503,61504]
operator: = [61455,61456]
===
match
---
atom_expr [6017,6025]
atom_expr [6017,6025]
===
match
---
name: dag_id [79839,79845]
name: dag_id [79791,79797]
===
match
---
fstring_string:   [33055,33056]
fstring_string:   [33055,33056]
===
match
---
decorator [81478,81488]
decorator [81430,81440]
===
match
---
operator: -> [59893,59895]
operator: -> [59845,59847]
===
match
---
simple_stmt [12086,12112]
simple_stmt [12086,12112]
===
match
---
atom_expr [21663,21674]
atom_expr [21663,21674]
===
match
---
name: ti [79789,79791]
name: ti [79741,79743]
===
match
---
operator: = [53694,53695]
operator: = [53693,53694]
===
match
---
atom_expr [78662,78737]
atom_expr [78614,78689]
===
match
---
atom_expr [39322,39348]
atom_expr [39322,39348]
===
match
---
tfpdef [41724,41742]
tfpdef [41724,41742]
===
match
---
atom_expr [3567,3599]
atom_expr [3567,3599]
===
match
---
name: task_id [74284,74291]
name: task_id [74236,74243]
===
match
---
name: task [25985,25989]
name: task [25985,25989]
===
match
---
string: "--ignore-depends-on-past" [18474,18500]
string: "--ignore-depends-on-past" [18474,18500]
===
match
---
param [59225,59258]
param [59177,59210]
===
match
---
atom_expr [16109,16118]
atom_expr [16109,16118]
===
match
---
trailer [24041,24056]
trailer [24041,24056]
===
match
---
operator: , [39221,39222]
operator: , [39221,39222]
===
match
---
name: total_seconds [34647,34660]
name: total_seconds [34647,34660]
===
match
---
import_from [1260,1349]
import_from [1260,1349]
===
match
---
simple_stmt [34844,34873]
simple_stmt [34844,34873]
===
match
---
atom_expr [22476,22489]
atom_expr [22476,22489]
===
match
---
name: timezone [11786,11794]
name: timezone [11786,11794]
===
match
---
name: bool [59245,59249]
name: bool [59197,59201]
===
match
---
atom_expr [38531,38658]
atom_expr [38531,38658]
===
match
---
name: context [51545,51552]
name: context [51583,51590]
===
match
---
name: ignore_all_deps [37769,37784]
name: ignore_all_deps [37769,37784]
===
match
---
name: FAILED [44676,44682]
name: FAILED [44676,44682]
===
match
---
trailer [48456,48462]
trailer [48456,48462]
===
match
---
argument [39600,39621]
argument [39600,39621]
===
match
---
name: TaskInstance [20375,20387]
name: TaskInstance [20375,20387]
===
match
---
trailer [60250,60267]
trailer [60202,60219]
===
match
---
if_stmt [12120,12161]
if_stmt [12120,12161]
===
match
---
trailer [72118,72125]
trailer [72070,72077]
===
match
---
funcdef [8358,8599]
funcdef [8358,8599]
===
match
---
trailer [45290,45297]
trailer [45290,45297]
===
match
---
trailer [28042,28050]
trailer [28042,28050]
===
match
---
name: session [45716,45723]
name: session [45716,45723]
===
match
---
suite [31057,32322]
suite [31057,32322]
===
match
---
trailer [35492,35568]
trailer [35492,35568]
===
match
---
simple_stmt [18832,18869]
simple_stmt [18832,18869]
===
match
---
name: min_backoff [33665,33676]
name: min_backoff [33665,33676]
===
match
---
name: execution_date [9633,9647]
name: execution_date [9633,9647]
===
match
---
name: hr_line_break [37975,37988]
name: hr_line_break [37975,37988]
===
match
---
param [14091,14096]
param [14091,14096]
===
match
---
trailer [18600,18607]
trailer [18600,18607]
===
match
---
name: task_id_by_key [5093,5107]
name: task_id_by_key [5093,5107]
===
match
---
atom_expr [8305,8317]
atom_expr [8305,8317]
===
match
---
trailer [18989,19004]
trailer [18989,19004]
===
match
---
name: self [20979,20983]
name: self [20979,20983]
===
match
---
name: Integer [10003,10010]
name: Integer [10003,10010]
===
match
---
trailer [68292,68301]
trailer [68244,68253]
===
match
---
param [29815,29838]
param [29815,29838]
===
match
---
atom_expr [58810,58833]
atom_expr [58809,58832]
===
match
---
name: dirname [71104,71111]
name: dirname [71056,71063]
===
match
---
suite [58202,58355]
suite [58201,58354]
===
match
---
if_stmt [33363,34836]
if_stmt [33363,34836]
===
match
---
parameters [48384,48399]
parameters [48384,48399]
===
match
---
atom_expr [58765,58775]
atom_expr [58764,58774]
===
match
---
name: self [55971,55975]
name: self [55970,55974]
===
match
---
trailer [77301,77307]
trailer [77253,77259]
===
match
---
name: v [49379,49380]
name: v [49379,49380]
===
match
---
operator: { [64613,64614]
operator: { [64565,64566]
===
match
---
import_from [35357,35397]
import_from [35357,35397]
===
match
---
trailer [11971,11986]
trailer [11971,11986]
===
match
---
name: ignore_all_deps [15692,15707]
name: ignore_all_deps [15692,15707]
===
match
---
name: render_template_fields [68270,68292]
name: render_template_fields [68222,68244]
===
match
---
operator: , [38284,38285]
operator: , [38284,38285]
===
match
---
comp_op [59751,59757]
comp_op [59703,59709]
===
match
---
suite [57977,58063]
suite [57976,58062]
===
match
---
arglist [56630,56641]
arglist [56629,56640]
===
match
---
argument [72126,72141]
argument [72078,72093]
===
match
---
name: Exception [52189,52198]
name: Exception [52227,52236]
===
match
---
name: open [72005,72009]
name: open [71957,71961]
===
match
---
name: str [36030,36033]
name: str [36030,36033]
===
match
---
simple_stmt [78328,78349]
simple_stmt [78280,78301]
===
match
---
name: error_file [4297,4307]
name: error_file [4297,4307]
===
match
---
operator: @ [81561,81562]
operator: @ [81513,81514]
===
match
---
atom_expr [5592,5605]
atom_expr [5592,5605]
===
match
---
name: start_date [22001,22011]
name: start_date [22001,22011]
===
match
---
operator: , [41857,41858]
operator: , [41857,41858]
===
match
---
simple_stmt [14627,14672]
simple_stmt [14627,14672]
===
match
---
simple_stmt [3019,3092]
simple_stmt [3019,3092]
===
match
---
operator: , [29629,29630]
operator: , [29629,29630]
===
match
---
simple_stmt [44289,44312]
simple_stmt [44289,44312]
===
match
---
return_stmt [8285,8338]
return_stmt [8285,8338]
===
match
---
trailer [16086,16091]
trailer [16086,16091]
===
match
---
atom_expr [79075,79094]
atom_expr [79027,79046]
===
match
---
name: try_number [71693,71703]
name: try_number [71645,71655]
===
match
---
name: Log [57117,57120]
name: Log [57116,57119]
===
match
---
string: 'ds_nodash' [64736,64747]
string: 'ds_nodash' [64688,64699]
===
match
---
name: lock_for_update [37663,37678]
name: lock_for_update [37663,37678]
===
match
---
atom_expr [18462,18502]
atom_expr [18462,18502]
===
match
---
suite [61388,61554]
suite [61340,61506]
===
match
---
expr_stmt [23540,23583]
expr_stmt [23540,23583]
===
match
---
trailer [35128,35130]
trailer [35128,35130]
===
match
---
parameters [29170,29261]
parameters [29170,29261]
===
match
---
expr_stmt [82365,82381]
expr_stmt [82317,82333]
===
match
---
trailer [48938,48999]
trailer [48938,48999]
===
match
---
name: failed [32202,32208]
name: failed [32202,32208]
===
match
---
name: TaskFail [57194,57202]
name: TaskFail [57193,57201]
===
match
---
atom_expr [4085,4094]
atom_expr [4085,4094]
===
match
---
exprlist [6958,6978]
exprlist [6958,6978]
===
match
---
atom_expr [20429,20456]
atom_expr [20429,20456]
===
match
---
atom_expr [18597,18620]
atom_expr [18597,18620]
===
match
---
name: self [46204,46208]
name: self [46204,46208]
===
match
---
funcdef [28109,28574]
funcdef [28109,28574]
===
match
---
atom_expr [31985,32189]
atom_expr [31985,32189]
===
match
---
name: self [37813,37817]
name: self [37813,37817]
===
match
---
name: dag_run [60359,60366]
name: dag_run [60311,60318]
===
match
---
name: params [67798,67804]
name: params [67750,67756]
===
match
---
dictorsetmaker [47079,47210]
dictorsetmaker [47079,47210]
===
match
---
trailer [42960,42968]
trailer [42960,42968]
===
match
---
trailer [43616,43622]
trailer [43616,43622]
===
match
---
trailer [16113,16118]
trailer [16113,16118]
===
match
---
atom_expr [65479,65528]
atom_expr [65431,65480]
===
match
---
suite [52437,53386]
suite [52436,53385]
===
match
---
funcdef [62965,63017]
funcdef [62917,62969]
===
match
---
simple_stmt [29885,30097]
simple_stmt [29885,30097]
===
match
---
trailer [22765,22777]
trailer [22765,22777]
===
match
---
name: deserialize_json [64083,64099]
name: deserialize_json [64035,64051]
===
match
---
name: the_log [19025,19032]
name: the_log [19025,19032]
===
match
---
expr_stmt [11946,12002]
expr_stmt [11946,12002]
===
match
---
name: pid [40886,40889]
name: pid [40886,40889]
===
match
---
operator: = [40890,40891]
operator: = [40890,40891]
===
match
---
name: str [41810,41813]
name: str [41810,41813]
===
match
---
operator: = [14377,14378]
operator: = [14377,14378]
===
match
---
trailer [50500,50520]
trailer [50538,50558]
===
match
---
trailer [77677,77684]
trailer [77629,77636]
===
match
---
operator: = [43227,43228]
operator: = [43227,43228]
===
match
---
trailer [18226,18253]
trailer [18226,18253]
===
match
---
simple_stmt [8677,8736]
simple_stmt [8677,8736]
===
match
---
name: execution_date [76500,76514]
name: execution_date [76452,76466]
===
match
---
trailer [26569,26585]
trailer [26569,26585]
===
match
---
trailer [23344,23349]
trailer [23344,23349]
===
match
---
operator: = [26908,26909]
operator: = [26908,26909]
===
match
---
operator: , [16098,16099]
operator: , [16098,16099]
===
match
---
name: Context [3375,3382]
name: Context [3375,3382]
===
match
---
atom_expr [82651,82677]
atom_expr [82603,82629]
===
match
---
atom_expr [47724,47740]
atom_expr [47724,47740]
===
match
---
name: test_mode [65714,65723]
name: test_mode [65666,65675]
===
match
---
name: start_date [72958,72968]
name: start_date [72910,72920]
===
match
---
operator: = [54145,54146]
operator: = [54144,54145]
===
match
---
trailer [10934,11099]
trailer [10934,11099]
===
match
---
trailer [23544,23560]
trailer [23544,23560]
===
match
---
arith_expr [40300,40318]
arith_expr [40300,40318]
===
match
---
name: get_previous_ti [28556,28571]
name: get_previous_ti [28556,28571]
===
match
---
param [31010,31027]
param [31010,31027]
===
match
---
operator: = [55361,55362]
operator: = [55360,55361]
===
match
---
tfpdef [53596,53618]
tfpdef [53595,53617]
===
match
---
fstring_end: " [19721,19722]
fstring_end: " [19721,19722]
===
match
---
name: downstream_task_ids [26417,26436]
name: downstream_task_ids [26417,26436]
===
match
---
name: kube_config [69001,69012]
name: kube_config [68953,68964]
===
match
---
atom_expr [56839,56872]
atom_expr [56838,56871]
===
match
---
name: task [47494,47498]
name: task [47494,47498]
===
match
---
operator: , [1344,1345]
operator: , [1344,1345]
===
match
---
name: get_task [5456,5464]
name: get_task [5456,5464]
===
match
---
simple_stmt [52251,52308]
simple_stmt [52282,52343]
===
match
---
name: models [60293,60299]
name: models [60245,60251]
===
match
---
name: e [67703,67704]
name: e [67655,67656]
===
match
---
name: email_on_failure [58172,58188]
name: email_on_failure [58171,58187]
===
match
---
suite [45933,48085]
suite [45933,48085]
===
match
---
if_stmt [57963,58137]
if_stmt [57962,58136]
===
match
---
name: first_task_id [79226,79239]
name: first_task_id [79178,79191]
===
match
---
trailer [46118,46354]
trailer [46118,46354]
===
match
---
simple_stmt [55926,55948]
simple_stmt [55925,55947]
===
match
---
expr_stmt [9692,9724]
expr_stmt [9692,9724]
===
match
---
expr_stmt [30162,30222]
expr_stmt [30162,30222]
===
match
---
operator: = [3667,3668]
operator: = [3667,3668]
===
match
---
comparison [6772,6807]
comparison [6772,6807]
===
match
---
string: "Updating task params (%s) with DagRun.conf (%s)" [67933,67982]
string: "Updating task params (%s) with DagRun.conf (%s)" [67885,67934]
===
match
---
trailer [9844,9878]
trailer [9844,9878]
===
match
---
name: DateTime [30457,30465]
name: DateTime [30457,30465]
===
match
---
comparison [3703,3728]
comparison [3703,3728]
===
match
---
name: mark_success [53675,53687]
name: mark_success [53674,53686]
===
match
---
operator: , [6699,6700]
operator: , [6699,6700]
===
match
---
operator: = [68221,68222]
operator: = [68173,68174]
===
match
---
operator: = [80478,80479]
operator: = [80430,80431]
===
match
---
trailer [68818,68834]
trailer [68770,68786]
===
match
---
trailer [79820,79828]
trailer [79772,79780]
===
match
---
decorator [81330,81340]
decorator [81282,81292]
===
match
---
name: delete [7252,7258]
name: delete [7252,7258]
===
match
---
expr_stmt [5947,6004]
expr_stmt [5947,6004]
===
match
---
atom_expr [33057,33076]
atom_expr [33057,33076]
===
match
---
name: conditions [6628,6638]
name: conditions [6628,6638]
===
match
---
trailer [18717,18728]
trailer [18717,18728]
===
match
---
simple_stmt [23502,23532]
simple_stmt [23502,23532]
===
match
---
atom_expr [71521,71786]
atom_expr [71473,71738]
===
match
---
name: try_number [70894,70904]
name: try_number [70846,70856]
===
match
---
trailer [48741,48757]
trailer [48741,48757]
===
match
---
return_stmt [26023,26034]
return_stmt [26023,26034]
===
match
---
if_stmt [78962,79255]
if_stmt [78914,79207]
===
match
---
name: end_date [45098,45106]
name: end_date [45098,45106]
===
match
---
atom_expr [48298,48326]
atom_expr [48298,48326]
===
match
---
decorated [56085,59105]
decorated [56084,59057]
===
match
---
funcdef [14024,15488]
funcdef [14024,15488]
===
match
---
trailer [77783,77791]
trailer [77735,77743]
===
match
---
atom_expr [19599,19632]
atom_expr [19599,19632]
===
match
---
simple_stmt [21841,21876]
simple_stmt [21841,21876]
===
match
---
name: ignore_depends_on_past [39688,39710]
name: ignore_depends_on_past [39688,39710]
===
match
---
expr_stmt [71464,71507]
expr_stmt [71416,71459]
===
match
---
name: get [64073,64076]
name: get [64025,64028]
===
match
---
name: last_dagrun [27889,27900]
name: last_dagrun [27889,27900]
===
match
---
name: UtcDateTime [10250,10261]
name: UtcDateTime [10250,10261]
===
match
---
name: self [48969,48973]
name: self [48969,48973]
===
match
---
operator: = [31914,31915]
operator: = [31914,31915]
===
match
---
name: result [50621,50627]
name: result [50659,50665]
===
match
---
string: """         Copy common attributes from the given task.          :param task: The task object to copy from         :type task: airflow.models.BaseOperator         :param pool_override: Use the pool_override instead of task's pool         :type pool_override: str         """ [22996,23270]
string: """         Copy common attributes from the given task.          :param task: The task object to copy from         :type task: airflow.models.BaseOperator         :param pool_override: Use the pool_override instead of task's pool         :type pool_override: str         """ [22996,23270]
===
match
---
trailer [68668,68679]
trailer [68620,68631]
===
match
---
simple_stmt [61862,61884]
simple_stmt [61814,61836]
===
match
---
name: dr [27903,27905]
name: dr [27903,27905]
===
match
---
name: jinja2 [1154,1160]
name: jinja2 [1154,1160]
===
match
---
name: self [50872,50876]
name: self [50910,50914]
===
match
---
trailer [12062,12073]
trailer [12062,12073]
===
match
---
tfpdef [53782,53801]
tfpdef [53781,53800]
===
match
---
string: """         Returns a command that can be executed anywhere where airflow is         installed. This command is part of the message sent to executors by         the orchestrator.         """ [14399,14589]
string: """         Returns a command that can be executed anywhere where airflow is         installed. This command is part of the message sent to executors by         the orchestrator.         """ [14399,14589]
===
match
---
suite [18694,18729]
suite [18694,18729]
===
match
---
name: pool_override [23323,23336]
name: pool_override [23323,23336]
===
match
---
parameters [33123,33129]
parameters [33123,33129]
===
match
---
name: try_number [33729,33739]
name: try_number [33729,33739]
===
match
---
operator: = [74311,74312]
operator: = [74263,74264]
===
match
---
atom_expr [34802,34827]
atom_expr [34802,34827]
===
match
---
operator: , [64081,64082]
operator: , [64033,64034]
===
match
---
name: state [22136,22141]
name: state [22136,22141]
===
match
---
expr_stmt [47036,47228]
expr_stmt [47036,47228]
===
match
---
operator: = [71071,71072]
operator: = [71023,71024]
===
match
---
atom_expr [5199,5207]
atom_expr [5199,5207]
===
match
---
name: verbose [38632,38639]
name: verbose [38632,38639]
===
match
---
name: init_run_context [77848,77864]
name: init_run_context [77800,77816]
===
match
---
decorated [8152,8339]
decorated [8152,8339]
===
match
---
tfpdef [53675,53693]
tfpdef [53674,53692]
===
match
---
operator: @ [55119,55120]
operator: @ [55118,55119]
===
match
---
name: models [7567,7573]
name: models [7567,7573]
===
match
---
atom_expr [53203,53225]
atom_expr [53202,53224]
===
match
---
trailer [53316,53329]
trailer [53315,53328]
===
match
---
atom_expr [80480,80498]
atom_expr [80432,80450]
===
match
---
trailer [72172,72209]
trailer [72124,72161]
===
match
---
if_stmt [56808,56873]
if_stmt [56807,56872]
===
match
---
expr_stmt [22667,22708]
expr_stmt [22667,22708]
===
match
---
operator: = [25474,25475]
operator: = [25474,25475]
===
match
---
name: e [43379,43380]
name: e [43379,43380]
===
match
---
simple_stmt [22996,23271]
simple_stmt [22996,23271]
===
match
---
name: params [62501,62507]
name: params [62453,62459]
===
match
---
name: State [26317,26322]
name: State [26317,26322]
===
match
---
operator: @ [19166,19167]
operator: @ [19166,19167]
===
match
---
trailer [63150,63156]
trailer [63102,63108]
===
match
---
name: max_tries [22399,22408]
name: max_tries [22399,22408]
===
match
---
name: self [32376,32380]
name: self [32376,32380]
===
match
---
simple_stmt [42804,42825]
simple_stmt [42804,42825]
===
match
---
name: update [60244,60250]
name: update [60196,60202]
===
match
---
name: self [39217,39221]
name: self [39217,39221]
===
match
---
trailer [42924,42929]
trailer [42924,42929]
===
match
---
param [74543,74596]
param [74495,74548]
===
match
---
name: self [72920,72924]
name: self [72872,72876]
===
match
---
trailer [59595,59603]
trailer [59547,59555]
===
match
---
name: dag [27368,27371]
name: dag [27368,27371]
===
match
---
name: retries [5553,5560]
name: retries [5553,5560]
===
match
---
simple_stmt [82402,82422]
simple_stmt [82354,82374]
===
match
---
operator: = [7919,7920]
operator: = [7919,7920]
===
match
---
name: file_path [15926,15935]
name: file_path [15926,15935]
===
match
---
atom_expr [43161,43203]
atom_expr [43161,43203]
===
match
---
name: str [15549,15552]
name: str [15549,15552]
===
match
---
trailer [18472,18502]
trailer [18472,18502]
===
match
---
string: 'ti' [65737,65741]
string: 'ti' [65689,65693]
===
match
---
trailer [58219,58225]
trailer [58218,58224]
===
match
---
atom_expr [48448,48509]
atom_expr [48448,48509]
===
match
---
simple_stmt [56977,57033]
simple_stmt [56976,57032]
===
match
---
name: on_execute_callback [52103,52122]
name: on_execute_callback [52141,52160]
===
match
---
atom_expr [35084,35110]
atom_expr [35084,35110]
===
match
---
argument [44919,44940]
argument [44919,44940]
===
match
---
name: extend [18148,18154]
name: extend [18148,18154]
===
match
---
expr_stmt [79816,79845]
expr_stmt [79768,79797]
===
match
---
simple_stmt [63500,63533]
simple_stmt [63452,63485]
===
match
---
name: fd [4050,4052]
name: fd [4050,4052]
===
match
---
string: """         Checks dependencies and then sets state to RUNNING if they are met. Returns         True if and only if state is set to RUNNING, which implies that task should be         executed, in preparation for _run_raw_task          :param verbose: whether to turn on more verbose logging         :type verbose: bool         :param ignore_all_deps: Ignore all of the non-critical dependencies, just runs         :type ignore_all_deps: bool         :param ignore_depends_on_past: Ignore depends_on_past DAG attribute         :type ignore_depends_on_past: bool         :param ignore_task_deps: Don't check the dependencies of this TaskInstance's task         :type ignore_task_deps: bool         :param ignore_ti_state: Disregards previous task instance state         :type ignore_ti_state: bool         :param mark_success: Don't run the task, mark its state as success         :type mark_success: bool         :param test_mode: Doesn't record success or failure in the DB         :type test_mode: bool         :param job_id: Job (BackfillJob / LocalTaskJob / SchedulerJob) ID         :type job_id: str         :param pool: specifies the pool to use to run the task instance         :type pool: str         :param session: SQLAlchemy ORM Session         :type session: Session         :return: whether the state was changed to running or not         :rtype: bool         """ [36124,37499]
string: """         Checks dependencies and then sets state to RUNNING if they are met. Returns         True if and only if state is set to RUNNING, which implies that task should be         executed, in preparation for _run_raw_task          :param verbose: whether to turn on more verbose logging         :type verbose: bool         :param ignore_all_deps: Ignore all of the non-critical dependencies, just runs         :type ignore_all_deps: bool         :param ignore_depends_on_past: Ignore depends_on_past DAG attribute         :type ignore_depends_on_past: bool         :param ignore_task_deps: Don't check the dependencies of this TaskInstance's task         :type ignore_task_deps: bool         :param ignore_ti_state: Disregards previous task instance state         :type ignore_ti_state: bool         :param mark_success: Don't run the task, mark its state as success         :type mark_success: bool         :param test_mode: Doesn't record success or failure in the DB         :type test_mode: bool         :param job_id: Job (BackfillJob / LocalTaskJob / SchedulerJob) ID         :type job_id: str         :param pool: specifies the pool to use to run the task instance         :type pool: str         :param session: SQLAlchemy ORM Session         :type session: Session         :return: whether the state was changed to running or not         :rtype: bool         """ [36124,37499]
===
match
---
simple_stmt [69436,69476]
simple_stmt [69388,69428]
===
match
---
operator: , [41899,41900]
operator: , [41899,41900]
===
match
---
name: self [39304,39308]
name: self [39304,39308]
===
match
---
trailer [4326,4342]
trailer [4326,4342]
===
match
---
simple_stmt [80004,80043]
simple_stmt [79956,79995]
===
match
---
trailer [64664,64668]
trailer [64616,64620]
===
match
---
expr_stmt [80357,80400]
expr_stmt [80309,80352]
===
match
---
trailer [62243,62251]
trailer [62195,62203]
===
match
---
except_clause [49946,49967]
except_clause [49946,49962]
===
match
---
expr_stmt [42666,42692]
expr_stmt [42666,42692]
===
match
---
simple_stmt [5076,5089]
simple_stmt [5076,5089]
===
match
---
name: task [23423,23427]
name: task [23423,23427]
===
match
---
name: self [11822,11826]
name: self [11822,11826]
===
match
---
trailer [30119,30153]
trailer [30119,30153]
===
match
---
name: var [63006,63009]
name: var [62958,62961]
===
match
---
atom_expr [44140,44215]
atom_expr [44140,44215]
===
match
---
name: exception [69505,69514]
name: exception [69457,69466]
===
match
---
name: prev_ds [61839,61846]
name: prev_ds [61791,61798]
===
match
---
operator: @ [81162,81163]
operator: @ [81114,81115]
===
match
---
name: dag_id [76435,76441]
name: dag_id [76387,76393]
===
match
---
name: session [46320,46327]
name: session [46320,46327]
===
match
---
operator: , [70872,70873]
operator: , [70824,70825]
===
match
---
name: last_dagrun [27972,27983]
name: last_dagrun [27972,27983]
===
match
---
name: self [32098,32102]
name: self [32098,32102]
===
match
---
operator: , [65598,65599]
operator: , [65550,65551]
===
match
---
atom_expr [14777,14789]
atom_expr [14777,14789]
===
match
---
trailer [79423,79438]
trailer [79375,79390]
===
match
---
atom_expr [55363,55380]
atom_expr [55362,55379]
===
match
---
simple_stmt [49625,49667]
simple_stmt [49625,49667]
===
match
---
trailer [58368,58372]
trailer [58367,58371]
===
match
---
name: job_id [10890,10896]
name: job_id [10890,10896]
===
match
---
operator: , [53626,53627]
operator: , [53625,53626]
===
match
---
name: task [47506,47510]
name: task [47506,47510]
===
match
---
simple_stmt [43216,43243]
simple_stmt [43216,43243]
===
match
---
atom_expr [60204,60219]
atom_expr [60156,60171]
===
match
---
name: include_downstream [46763,46781]
name: include_downstream [46763,46781]
===
match
---
trailer [6746,7049]
trailer [6746,7049]
===
match
---
operator: @ [81330,81331]
operator: @ [81282,81283]
===
match
---
subscriptlist [4327,4341]
subscriptlist [4327,4341]
===
match
---
operator: , [16058,16059]
operator: , [16058,16059]
===
match
---
if_stmt [39264,39349]
if_stmt [39264,39349]
===
match
---
name: state [24795,24800]
name: state [24795,24800]
===
match
---
name: jinja2 [71029,71035]
name: jinja2 [70981,70987]
===
match
---
name: pool_slots [22605,22615]
name: pool_slots [22605,22615]
===
match
---
annassign [80206,80228]
annassign [80158,80180]
===
match
---
operator: = [44385,44386]
operator: = [44385,44386]
===
match
---
trailer [50375,50377]
trailer [50413,50415]
===
match
---
operator: -> [30436,30438]
operator: -> [30436,30438]
===
match
---
atom_expr [13998,14014]
atom_expr [13998,14014]
===
match
---
operator: = [63136,63137]
operator: = [63088,63089]
===
match
---
name: log [73046,73049]
name: log [72998,73001]
===
match
---
atom_expr [6028,6038]
atom_expr [6028,6038]
===
match
---
name: refresh_from_task [5493,5510]
name: refresh_from_task [5493,5510]
===
match
---
name: property [13905,13913]
name: property [13905,13913]
===
match
---
simple_stmt [28808,29056]
simple_stmt [28808,29056]
===
match
---
operator: , [45323,45324]
operator: , [45323,45324]
===
match
---
and_test [73930,73985]
and_test [73882,73937]
===
match
---
trailer [55020,55022]
trailer [55019,55021]
===
match
---
trailer [55999,56001]
trailer [55998,56000]
===
match
---
atom_expr [26293,26347]
atom_expr [26293,26347]
===
match
---
string: """Get the email subject content for exceptions.""" [69241,69292]
string: """Get the email subject content for exceptions.""" [69193,69244]
===
match
---
name: XCom [77000,77004]
name: XCom [76952,76956]
===
match
---
name: query [26057,26062]
name: query [26057,26062]
===
match
---
name: hasattr [47422,47429]
name: hasattr [47422,47429]
===
match
---
name: Exception [59205,59214]
name: Exception [59157,59166]
===
match
---
trailer [41382,41387]
trailer [41382,41387]
===
match
---
operator: , [966,967]
operator: , [966,967]
===
match
---
classdef [7983,8827]
classdef [7983,8827]
===
match
---
expr_stmt [53255,53292]
expr_stmt [53254,53291]
===
match
---
suite [18131,18185]
suite [18131,18185]
===
match
---
name: mark_success [15067,15079]
name: mark_success [15067,15079]
===
match
---
atom_expr [11353,11362]
atom_expr [11353,11362]
===
match
---
trailer [43165,43181]
trailer [43165,43181]
===
match
---
argument [68545,68592]
argument [68497,68544]
===
match
---
atom_expr [80543,80552]
atom_expr [80495,80504]
===
match
---
atom_expr [62241,62277]
atom_expr [62193,62229]
===
match
---
name: dagrun [45966,45972]
name: dagrun [45966,45972]
===
match
---
simple_stmt [62286,62338]
simple_stmt [62238,62290]
===
match
---
operator: = [44368,44369]
operator: = [44368,44369]
===
match
---
import_from [2815,2852]
import_from [2815,2852]
===
match
---
simple_stmt [2056,2110]
simple_stmt [2056,2110]
===
match
---
name: dag_run [60556,60563]
name: dag_run [60508,60515]
===
match
---
operator: = [11301,11302]
operator: = [11301,11302]
===
match
---
operator: @ [81012,81013]
operator: @ [80964,80965]
===
match
---
string: """Load and return error from error file""" [4002,4045]
string: """Load and return error from error file""" [4002,4045]
===
match
---
name: pool_slots [23381,23391]
name: pool_slots [23381,23391]
===
match
---
name: field_name [66624,66634]
name: field_name [66576,66586]
===
match
---
expr_stmt [54957,54973]
expr_stmt [54956,54972]
===
match
---
atom_expr [22530,22539]
atom_expr [22530,22539]
===
match
---
name: cmd [18884,18887]
name: cmd [18884,18887]
===
match
---
name: Iterable [78021,78029]
name: Iterable [77973,77981]
===
match
---
name: next_ds_nodash [61586,61600]
name: next_ds_nodash [61538,61552]
===
match
---
name: self [13938,13942]
name: self [13938,13942]
===
match
---
string: 'Try {{try_number}} out of {{max_tries + 1}}<br>' [70172,70221]
string: 'Try {{try_number}} out of {{max_tries + 1}}<br>' [70124,70173]
===
match
---
atom_expr [23995,24007]
atom_expr [23995,24007]
===
match
---
simple_stmt [34163,34213]
simple_stmt [34163,34213]
===
match
---
operator: , [41285,41286]
operator: , [41285,41286]
===
match
---
trailer [72957,72968]
trailer [72909,72920]
===
match
---
operator: , [66080,66081]
operator: , [66032,66033]
===
match
---
name: get_email_subject_content [72589,72614]
name: get_email_subject_content [72541,72566]
===
match
---
trailer [22480,22489]
trailer [22480,22489]
===
match
---
operator: ** [33720,33722]
operator: ** [33720,33722]
===
match
---
expr_stmt [11880,11932]
expr_stmt [11880,11932]
===
match
---
name: Union [74562,74567]
name: Union [74514,74519]
===
match
---
string: "wb" [4425,4429]
string: "wb" [4425,4429]
===
match
---
name: dep_status [32120,32130]
name: dep_status [32120,32130]
===
match
---
name: dag_id [11240,11246]
name: dag_id [11240,11246]
===
match
---
param [81512,81516]
param [81464,81468]
===
match
---
name: dag_id [8297,8303]
name: dag_id [8297,8303]
===
match
---
except_clause [4179,4195]
except_clause [4179,4195]
===
match
---
if_stmt [32907,32970]
if_stmt [32907,32970]
===
match
---
name: _date_or_empty [45342,45356]
name: _date_or_empty [45342,45356]
===
match
---
trailer [4168,4174]
trailer [4168,4174]
===
match
---
name: self [43088,43092]
name: self [43088,43092]
===
match
---
name: models [66309,66315]
name: models [66261,66267]
===
match
---
name: bool [53574,53578]
name: bool [53573,53577]
===
match
---
parameters [81609,81652]
parameters [81561,81604]
===
match
---
arith_expr [40674,40692]
arith_expr [40674,40692]
===
match
---
name: self [50342,50346]
name: self [50380,50384]
===
match
---
name: schedulable_ti [47524,47538]
name: schedulable_ti [47524,47538]
===
match
---
name: self [81303,81307]
name: self [81255,81259]
===
match
---
suite [45663,45725]
suite [45663,45725]
===
match
---
operator: = [11961,11962]
operator: = [11961,11962]
===
match
---
trailer [41291,41306]
trailer [41291,41306]
===
match
---
trailer [40581,40585]
trailer [40581,40585]
===
match
---
operator: , [68935,68936]
operator: , [68887,68888]
===
match
---
name: self [12142,12146]
name: self [12142,12146]
===
match
---
suite [80976,81007]
suite [80928,80959]
===
match
---
trailer [55781,55799]
trailer [55780,55798]
===
match
---
operator: , [74232,74233]
operator: , [74184,74185]
===
match
---
simple_stmt [77475,77522]
simple_stmt [77427,77474]
===
match
---
trailer [59095,59102]
trailer [59047,59054]
===
match
---
name: html_content_err [71346,71362]
name: html_content_err [71298,71314]
===
match
---
name: state [10799,10804]
name: state [10799,10804]
===
match
---
atom_expr [44670,44682]
atom_expr [44670,44682]
===
match
---
trailer [38230,38511]
trailer [38230,38511]
===
match
---
name: datetime [958,966]
name: datetime [958,966]
===
match
---
name: file_path [18787,18796]
name: file_path [18787,18796]
===
match
---
operator: = [71594,71595]
operator: = [71546,71547]
===
match
---
atom_expr [65709,65723]
atom_expr [65661,65675]
===
match
---
name: name [54638,54642]
name: name [54637,54641]
===
match
---
name: timezone [11963,11971]
name: timezone [11963,11971]
===
match
---
fstring [62418,62463]
fstring [62370,62415]
===
match
---
string: """Set TI duration""" [72840,72861]
string: """Set TI duration""" [72792,72813]
===
match
---
expr_stmt [78388,78425]
expr_stmt [78340,78377]
===
match
---
name: try_number [6888,6898]
name: try_number [6888,6898]
===
match
---
expr_stmt [58215,58246]
expr_stmt [58214,58245]
===
match
---
name: execution_date [11880,11894]
name: execution_date [11880,11894]
===
match
---
atom [60369,60534]
atom [60321,60486]
===
match
---
name: run_as_user [80303,80314]
name: run_as_user [80255,80266]
===
match
---
name: Exception [4332,4341]
name: Exception [4332,4341]
===
match
---
trailer [60447,60451]
trailer [60399,60403]
===
match
---
operator: , [44345,44346]
operator: , [44345,44346]
===
match
---
atom_expr [51866,51915]
atom_expr [51904,51953]
===
match
---
atom_expr [15896,15909]
atom_expr [15896,15909]
===
match
---
operator: { [49367,49368]
operator: { [49367,49368]
===
match
---
operator: == [79223,79225]
operator: == [79175,79177]
===
match
---
name: try_number [8630,8640]
name: try_number [8630,8640]
===
match
---
name: self [61301,61305]
name: self [61253,61257]
===
match
---
string: """     Simplified Task Instance.      Used to send data between processes via Queues.     """ [79670,79764]
string: """     Simplified Task Instance.      Used to send data between processes via Queues.     """ [79622,79716]
===
match
---
name: str [63091,63094]
name: str [63043,63046]
===
match
---
name: self [19192,19196]
name: self [19192,19196]
===
match
---
atom_expr [53178,53187]
atom_expr [53177,53186]
===
match
---
name: task [11339,11343]
name: task [11339,11343]
===
match
---
atom_expr [41378,41387]
atom_expr [41378,41387]
===
match
---
expr_stmt [54389,54431]
expr_stmt [54388,54430]
===
match
---
lambdef [5142,5166]
lambdef [5142,5166]
===
match
---
name: pool [10832,10836]
name: pool [10832,10836]
===
match
---
atom_expr [48939,48998]
atom_expr [48939,48998]
===
match
---
name: ti [22014,22016]
name: ti [22014,22016]
===
match
---
operator: = [63418,63419]
operator: = [63370,63371]
===
match
---
name: end_date [40917,40925]
name: end_date [40917,40925]
===
match
---
name: Base [1869,1873]
name: Base [1869,1873]
===
match
---
name: os [49443,49445]
name: os [49443,49445]
===
match
---
trailer [42901,42908]
trailer [42901,42908]
===
match
---
name: ti [22492,22494]
name: ti [22492,22494]
===
match
---
decorated [81012,81087]
decorated [80964,81039]
===
match
---
trailer [29075,29091]
trailer [29075,29091]
===
match
---
name: self [27158,27162]
name: self [27158,27162]
===
match
---
with_stmt [48768,50629]
with_stmt [48768,50667]
===
match
---
fstring_start: f' [45000,45002]
fstring_start: f' [45000,45002]
===
match
---
name: strftime [59790,59798]
name: strftime [59742,59750]
===
match
---
name: handle_failure [44890,44904]
name: handle_failure [44890,44904]
===
match
---
fstring [19696,19722]
fstring [19696,19722]
===
match
---
name: dag_id [82113,82119]
name: dag_id [82065,82071]
===
match
---
name: SENSING [50905,50912]
name: SENSING [50943,50950]
===
match
---
trailer [21716,21724]
trailer [21716,21724]
===
match
---
operator: , [55588,55589]
operator: , [55587,55588]
===
match
---
atom_expr [7496,7510]
atom_expr [7496,7510]
===
match
---
operator: , [66020,66021]
operator: , [65972,65973]
===
match
---
name: ID_LEN [9512,9518]
name: ID_LEN [9512,9518]
===
match
---
name: get [71962,71965]
name: get [71914,71917]
===
match
---
argument [53950,53965]
argument [53949,53964]
===
match
---
operator: = [70811,70812]
operator: = [70763,70764]
===
match
---
operator: , [10897,10898]
operator: , [10897,10898]
===
match
---
atom_expr [53788,53801]
atom_expr [53787,53800]
===
match
---
decorated [77395,77839]
decorated [77347,77791]
===
match
---
name: in_ [7722,7725]
name: in_ [7722,7725]
===
match
---
operator: = [4083,4084]
operator: = [4083,4084]
===
match
---
param [13302,13307]
param [13302,13307]
===
match
---
atom_expr [79411,79438]
atom_expr [79363,79390]
===
match
---
name: NamedTuple [8005,8015]
name: NamedTuple [8005,8015]
===
match
---
trailer [55393,55406]
trailer [55392,55405]
===
match
---
operator: = [14180,14181]
operator: = [14180,14181]
===
match
---
dotted_name [2242,2269]
dotted_name [2242,2269]
===
match
---
string: "when Dag Serialization is enabled. Hence for the task that have not yet " [66937,67011]
string: "when Dag Serialization is enabled. Hence for the task that have not yet " [66889,66963]
===
match
---
name: params [62657,62663]
name: params [62609,62615]
===
match
---
name: start_date [39309,39319]
name: start_date [39309,39319]
===
match
---
name: task [59591,59595]
name: task [59543,59547]
===
match
---
param [63323,63333]
param [63275,63285]
===
match
---
arglist [10750,10804]
arglist [10750,10804]
===
match
---
parameters [56124,56323]
parameters [56123,56322]
===
match
---
simple_stmt [50159,50196]
simple_stmt [50016,50234]
===
match
---
fstring_expr [45012,45025]
fstring_expr [45012,45025]
===
match
---
arglist [8574,8596]
arglist [8574,8596]
===
match
---
suite [34773,34836]
suite [34773,34836]
===
match
---
atom_expr [7708,7752]
atom_expr [7708,7752]
===
match
---
simple_stmt [39062,39098]
simple_stmt [39062,39098]
===
match
---
simple_stmt [50965,50985]
simple_stmt [51003,51023]
===
match
---
atom_expr [30105,30153]
atom_expr [30105,30153]
===
match
---
suite [5642,6005]
suite [5642,6005]
===
match
---
suite [52123,52174]
suite [52161,52212]
===
match
---
trailer [61509,61513]
trailer [61461,61465]
===
match
---
param [81041,81045]
param [80993,80997]
===
match
---
trailer [60742,60752]
trailer [60694,60704]
===
match
---
simple_stmt [71346,71437]
simple_stmt [71298,71389]
===
match
---
name: rendered_k8s_spec [67730,67747]
name: rendered_k8s_spec [67682,67699]
===
match
---
argument [63575,63598]
argument [63527,63550]
===
match
---
atom_expr [49262,49429]
atom_expr [49262,49429]
===
match
---
operator: , [74712,74713]
operator: , [74664,74665]
===
match
---
name: default_html_content_err [72354,72378]
name: default_html_content_err [72306,72330]
===
match
---
name: NamedTemporaryFile [54400,54418]
name: NamedTemporaryFile [54399,54417]
===
match
---
atom_expr [49384,49412]
atom_expr [49384,49412]
===
match
---
name: execution_date [82213,82227]
name: execution_date [82165,82179]
===
match
---
name: self [60669,60673]
name: self [60621,60625]
===
match
---
string: """Returns TaskInstanceKey with provided ``try_number``""" [8677,8735]
string: """Returns TaskInstanceKey with provided ``try_number``""" [8677,8735]
===
match
---
name: dep_context [31915,31926]
name: dep_context [31915,31926]
===
match
---
not_test [25384,25410]
not_test [25384,25410]
===
match
---
name: result [51685,51691]
name: result [51723,51729]
===
match
---
trailer [32863,32870]
trailer [32863,32870]
===
match
---
expr_stmt [62346,62395]
expr_stmt [62298,62347]
===
match
---
name: update [49454,49460]
name: update [49454,49460]
===
match
---
decorated [64221,64597]
decorated [64173,64549]
===
match
---
operator: , [58604,58605]
operator: , [58603,58604]
===
match
---
name: bool [56206,56210]
name: bool [56205,56209]
===
match
---
atom_expr [79875,79885]
atom_expr [79827,79837]
===
match
---
atom_expr [72953,72968]
atom_expr [72905,72920]
===
match
---
name: e [67179,67180]
name: e [67131,67132]
===
match
---
param [14310,14320]
param [14310,14320]
===
match
---
name: self [55347,55351]
name: self [55346,55350]
===
match
---
if_stmt [61226,61554]
if_stmt [61178,61506]
===
match
---
argument [54419,54430]
argument [54418,54429]
===
match
---
simple_stmt [10910,11100]
simple_stmt [10910,11100]
===
match
---
arglist [9577,9627]
arglist [9577,9627]
===
match
---
name: staticmethod [63273,63285]
name: staticmethod [63225,63237]
===
match
---
operator: = [12183,12184]
operator: = [12183,12184]
===
match
---
atom [18774,18797]
atom [18774,18797]
===
match
---
trailer [71275,71287]
trailer [71227,71239]
===
match
---
trailer [46925,46929]
trailer [46925,46929]
===
match
---
trailer [46675,46690]
trailer [46675,46690]
===
match
---
name: or_ [6717,6720]
name: or_ [6717,6720]
===
match
---
operator: = [71478,71479]
operator: = [71430,71431]
===
match
---
name: priority_weight [23405,23420]
name: priority_weight [23405,23420]
===
match
---
name: self [40577,40581]
name: self [40577,40581]
===
match
---
name: self [21056,21060]
name: self [21056,21060]
===
match
---
trailer [53102,53111]
trailer [53101,53110]
===
match
---
name: reschedule_exception [55672,55692]
name: reschedule_exception [55671,55691]
===
match
---
trailer [7729,7736]
trailer [7729,7736]
===
match
---
trailer [61427,61431]
trailer [61379,61383]
===
match
---
name: extend [18711,18717]
name: extend [18711,18717]
===
match
---
subscriptlist [74568,74586]
subscriptlist [74520,74538]
===
match
---
operator: ** [72126,72128]
operator: ** [72078,72080]
===
match
---
trailer [80482,80498]
trailer [80434,80450]
===
match
---
name: commit [51001,51007]
name: commit [51039,51045]
===
match
---
simple_stmt [34913,35032]
simple_stmt [34913,35032]
===
match
---
decorator [12488,12503]
decorator [12488,12503]
===
match
---
name: task [57009,57013]
name: task [57008,57012]
===
match
---
dotted_name [2705,2726]
dotted_name [2705,2726]
===
match
---
argument [38632,38644]
argument [38632,38644]
===
match
---
decorated [18893,19161]
decorated [18893,19161]
===
match
---
simple_stmt [44989,45056]
simple_stmt [44989,45056]
===
match
---
name: provide_session [77396,77411]
name: provide_session [77348,77363]
===
match
---
trailer [69118,69145]
trailer [69070,69097]
===
match
---
suite [52082,52174]
suite [52120,52212]
===
match
---
atom_expr [4156,4174]
atom_expr [4156,4174]
===
match
---
trailer [61681,61690]
trailer [61633,61642]
===
match
---
simple_stmt [67626,67715]
simple_stmt [67578,67667]
===
match
---
trailer [42705,42723]
trailer [42705,42723]
===
match
---
name: Session [73259,73266]
name: Session [73211,73218]
===
match
---
trailer [5284,5293]
trailer [5284,5293]
===
match
---
trailer [62171,62186]
trailer [62123,62138]
===
match
---
operator: = [3283,3284]
operator: = [3283,3284]
===
match
---
name: SIGTERM [48639,48646]
name: SIGTERM [48639,48646]
===
match
---
name: len [26408,26411]
name: len [26408,26411]
===
match
---
parameters [14043,14389]
parameters [14043,14389]
===
match
---
trailer [21867,21873]
trailer [21867,21873]
===
match
---
trailer [55406,55408]
trailer [55405,55407]
===
match
---
name: get_hostname [37738,37750]
name: get_hostname [37738,37750]
===
match
---
name: test_mode [55308,55317]
name: test_mode [55307,55316]
===
match
---
argument [15436,15445]
argument [15436,15445]
===
match
---
simple_stmt [68260,68302]
simple_stmt [68212,68254]
===
match
---
name: first [78367,78372]
name: first [78319,78324]
===
match
---
simple_stmt [27889,27956]
simple_stmt [27889,27956]
===
match
---
expr_stmt [7226,7278]
expr_stmt [7226,7278]
===
match
---
trailer [71095,71122]
trailer [71047,71074]
===
match
---
operator: + [19657,19658]
operator: + [19657,19658]
===
match
---
name: self [21996,22000]
name: self [21996,22000]
===
match
---
trailer [43664,44025]
trailer [43664,44025]
===
match
---
name: self [45560,45564]
name: self [45560,45564]
===
match
---
name: result [77023,77029]
name: result [76975,76981]
===
match
---
raise_stmt [73999,74193]
raise_stmt [73951,74145]
===
match
---
name: log [3279,3282]
name: log [3279,3282]
===
match
---
atom [7726,7751]
atom [7726,7751]
===
match
---
atom_expr [9962,9982]
atom_expr [9962,9982]
===
match
---
trailer [77598,77612]
trailer [77550,77564]
===
match
---
simple_stmt [73041,73098]
simple_stmt [72993,73050]
===
match
---
operator: = [11895,11896]
operator: = [11895,11896]
===
match
---
param [48385,48392]
param [48385,48392]
===
match
---
name: self [19708,19712]
name: self [19708,19712]
===
match
---
atom_expr [12169,12182]
atom_expr [12169,12182]
===
match
---
argument [29631,29646]
argument [29631,29646]
===
match
---
name: timezone [56923,56931]
name: timezone [56922,56930]
===
match
---
operator: = [29248,29249]
operator: = [29248,29249]
===
match
---
atom_expr [74553,74588]
atom_expr [74505,74540]
===
match
---
name: sanitize_for_serialization [69119,69145]
name: sanitize_for_serialization [69071,69097]
===
match
---
and_test [14683,14741]
and_test [14683,14741]
===
match
---
trailer [55930,55942]
trailer [55929,55941]
===
match
---
arglist [62387,62394]
arglist [62339,62346]
===
match
---
operator: = [57936,57937]
operator: = [57935,57936]
===
match
---
atom_expr [35548,35567]
atom_expr [35548,35567]
===
match
---
operator: = [53994,53995]
operator: = [53993,53994]
===
match
---
name: ts_nodash_with_tz [62221,62238]
name: ts_nodash_with_tz [62173,62190]
===
match
---
atom_expr [78450,78463]
atom_expr [78402,78415]
===
match
---
name: dag_id [10766,10772]
name: dag_id [10766,10772]
===
match
---
name: self [77865,77869]
name: self [77817,77821]
===
match
---
funcdef [22933,23623]
funcdef [22933,23623]
===
match
---
name: error [20661,20666]
name: error [20661,20666]
===
match
---
atom [7635,7874]
atom [7635,7874]
===
match
---
name: XCom [77297,77301]
name: XCom [77249,77253]
===
match
---
name: Exception [56166,56175]
name: Exception [56165,56174]
===
match
---
trailer [47185,47190]
trailer [47185,47190]
===
match
---
name: str [52404,52407]
name: str [52403,52406]
===
match
---
name: PickleType [10357,10367]
name: PickleType [10357,10367]
===
match
---
simple_stmt [67918,68006]
simple_stmt [67870,67958]
===
match
---
string: """             This attribute is deprecated.             Please use `airflow.models.taskinstance.TaskInstance.get_previous_ti` method.             """ [28315,28466]
string: """             This attribute is deprecated.             Please use `airflow.models.taskinstance.TaskInstance.get_previous_ti` method.             """ [28315,28466]
===
match
---
trailer [76519,76534]
trailer [76471,76486]
===
match
---
simple_stmt [3196,3216]
simple_stmt [3196,3216]
===
match
---
operator: = [7494,7495]
operator: = [7494,7495]
===
match
---
trailer [24733,24781]
trailer [24733,24781]
===
match
---
name: property [81479,81487]
name: property [81431,81439]
===
match
---
operator: @ [23628,23629]
operator: @ [23628,23629]
===
match
---
simple_stmt [51518,51562]
simple_stmt [51556,51600]
===
match
---
atom_expr [68018,68045]
atom_expr [67970,67997]
===
match
---
string: 'end_date' [43999,44009]
string: 'end_date' [43999,44009]
===
match
---
number: 2 [33718,33719]
number: 2 [33718,33719]
===
match
---
operator: -> [80964,80966]
operator: -> [80916,80918]
===
match
---
name: priority_weight_total [23428,23449]
name: priority_weight_total [23428,23449]
===
match
---
operator: , [38333,38334]
operator: , [38333,38334]
===
match
---
name: prev_ti [29663,29670]
name: prev_ti [29663,29670]
===
match
---
arglist [73056,73096]
arglist [73008,73048]
===
match
---
operator: { [19392,19393]
operator: { [19392,19393]
===
match
---
name: first [77309,77314]
name: first [77261,77266]
===
match
---
operator: , [65228,65229]
operator: , [65180,65181]
===
match
---
atom_expr [79854,79867]
atom_expr [79806,79819]
===
match
---
tfpdef [73250,73266]
tfpdef [73202,73218]
===
match
---
atom_expr [56486,56514]
atom_expr [56485,56513]
===
match
---
suite [32556,32970]
suite [32556,32970]
===
match
---
name: t [79175,79176]
name: t [79127,79128]
===
match
---
atom_expr [60723,60754]
atom_expr [60675,60706]
===
match
---
name: BaseJob [7432,7439]
name: BaseJob [7432,7439]
===
match
---
import_from [2056,2109]
import_from [2056,2109]
===
match
---
operator: = [50604,50605]
operator: = [50642,50643]
===
match
---
atom_expr [10076,10118]
atom_expr [10076,10118]
===
match
---
return_stmt [59579,59641]
return_stmt [59531,59593]
===
match
---
name: Column [10312,10318]
name: Column [10312,10318]
===
match
---
name: session [42787,42794]
name: session [42787,42794]
===
match
---
name: session [59879,59886]
name: session [59831,59838]
===
match
---
name: tis [78191,78194]
name: tis [78143,78146]
===
match
---
trailer [18835,18842]
trailer [18835,18842]
===
match
---
trailer [58377,58733]
trailer [58376,58732]
===
match
---
trailer [51479,51493]
trailer [51517,51531]
===
match
---
trailer [24141,24147]
trailer [24141,24147]
===
match
---
expr_stmt [61586,61607]
expr_stmt [61538,61559]
===
match
---
name: max [34643,34646]
name: max [34643,34646]
===
match
---
suite [49722,50378]
suite [49722,50416]
===
match
---
name: client [2921,2927]
name: client [2921,2927]
===
match
---
operator: = [50620,50621]
operator: = [50658,50659]
===
match
---
simple_stmt [19641,19869]
simple_stmt [19641,19869]
===
match
---
name: bool [53653,53657]
name: bool [53652,53656]
===
match
---
if_stmt [50213,50378]
if_stmt [50251,50416]
===
match
---
expr_stmt [56425,56451]
expr_stmt [56424,56450]
===
match
---
name: self [59074,59078]
name: self [59026,59030]
===
match
---
operator: , [40672,40673]
operator: , [40672,40673]
===
match
---
name: seconds [34698,34705]
name: seconds [34698,34705]
===
match
---
trailer [71386,71412]
trailer [71338,71364]
===
match
---
name: bool [41771,41775]
name: bool [41771,41775]
===
match
---
trailer [33084,33090]
trailer [33084,33090]
===
match
---
name: sqlalchemy [1497,1507]
name: sqlalchemy [1497,1507]
===
match
---
name: Union [1097,1102]
name: Union [1097,1102]
===
match
---
name: self [43557,43561]
name: self [43557,43561]
===
match
---
simple_stmt [61563,61578]
simple_stmt [61515,61530]
===
match
---
trailer [58935,58978]
trailer [58929,58972]
===
match
---
name: dag_id [79088,79094]
name: dag_id [79040,79046]
===
match
---
name: self [49072,49076]
name: self [49072,49076]
===
match
---
name: end_date [24977,24985]
name: end_date [24977,24985]
===
match
---
name: pool [15441,15445]
name: pool [15441,15445]
===
match
---
param [59301,59314]
param [59253,59266]
===
match
---
expr_stmt [52805,52833]
expr_stmt [52804,52832]
===
match
---
name: str [80641,80644]
name: str [80593,80596]
===
match
---
simple_stmt [937,978]
simple_stmt [937,978]
===
match
---
trailer [60212,60219]
trailer [60164,60171]
===
match
---
name: test_mode [45521,45530]
name: test_mode [45521,45530]
===
match
---
operator: = [68904,68905]
operator: = [68856,68857]
===
match
---
trailer [12612,12622]
trailer [12612,12622]
===
match
---
operator: = [39654,39655]
operator: = [39654,39655]
===
match
---
dictorsetmaker [70574,70584]
dictorsetmaker [70526,70536]
===
match
---
name: task [33338,33342]
name: task [33338,33342]
===
match
---
name: utcnow [39089,39095]
name: utcnow [39089,39095]
===
match
---
name: schedulable_ti [47360,47374]
name: schedulable_ti [47360,47374]
===
match
---
atom_expr [26332,26345]
atom_expr [26332,26345]
===
match
---
trailer [10292,10301]
trailer [10292,10301]
===
match
---
name: date_attr [59716,59725]
name: date_attr [59668,59677]
===
match
---
operator: , [1050,1051]
operator: , [1050,1051]
===
match
---
trailer [60259,60266]
trailer [60211,60218]
===
match
---
name: strftime [60689,60697]
name: strftime [60641,60649]
===
match
---
name: str [59200,59203]
name: str [59152,59155]
===
match
---
name: self [24326,24330]
name: self [24326,24330]
===
match
---
name: html_content_err [72565,72581]
name: html_content_err [72517,72533]
===
match
---
name: AirflowSmartSensorException [1758,1785]
name: AirflowSmartSensorException [1758,1785]
===
match
---
dotted_name [7559,7580]
dotted_name [7559,7580]
===
match
---
atom_expr [47501,47547]
atom_expr [47501,47547]
===
match
---
operator: , [68632,68633]
operator: , [68584,68585]
===
match
---
param [11156,11183]
param [11156,11183]
===
match
---
simple_stmt [71800,71841]
simple_stmt [71752,71793]
===
match
---
trailer [7487,7493]
trailer [7487,7493]
===
match
---
expr_stmt [25952,25968]
expr_stmt [25952,25968]
===
match
---
trailer [29801,29806]
trailer [29801,29806]
===
match
---
operator: = [46781,46782]
operator: = [46781,46782]
===
match
---
operator: , [10764,10765]
operator: , [10764,10765]
===
match
---
trailer [27367,27371]
trailer [27367,27371]
===
match
---
name: self [73012,73016]
name: self [72964,72968]
===
match
---
trailer [77826,77828]
trailer [77778,77780]
===
match
---
operator: { [45026,45027]
operator: { [45026,45027]
===
match
---
trailer [26311,26315]
trailer [26311,26315]
===
match
---
suite [51422,51562]
suite [51460,51600]
===
match
---
param [74605,74634]
param [74557,74586]
===
match
---
name: context [51975,51982]
name: context [52013,52020]
===
match
---
atom_expr [62501,62527]
atom_expr [62453,62479]
===
match
---
trailer [7862,7864]
trailer [7862,7864]
===
match
---
operator: , [52407,52408]
operator: , [52406,52407]
===
match
---
simple_stmt [58215,58247]
simple_stmt [58214,58246]
===
match
---
name: self [74312,74316]
name: self [74264,74268]
===
match
---
not_test [57880,57911]
not_test [57879,57910]
===
match
---
simple_stmt [1449,1492]
simple_stmt [1449,1492]
===
match
---
operator: = [23421,23422]
operator: = [23421,23422]
===
match
---
not_test [45649,45662]
not_test [45649,45662]
===
match
---
and_test [14805,14847]
and_test [14805,14847]
===
match
---
name: state [26499,26504]
name: state [26499,26504]
===
match
---
arglist [29618,29646]
arglist [29618,29646]
===
match
---
suite [39950,40537]
suite [39950,40537]
===
match
---
name: key [81418,81421]
name: key [81370,81373]
===
match
---
name: self [8370,8374]
name: self [8370,8374]
===
match
---
name: self [35047,35051]
name: self [35047,35051]
===
match
---
operator: , [29018,29019]
operator: , [29018,29019]
===
match
---
name: end_date [72878,72886]
name: end_date [72830,72838]
===
match
---
tfpdef [15994,16015]
tfpdef [15994,16015]
===
match
---
operator: = [71027,71028]
operator: = [70979,70980]
===
match
---
name: task_id [43848,43855]
name: task_id [43848,43855]
===
match
---
operator: = [9703,9704]
operator: = [9703,9704]
===
match
---
simple_stmt [78111,78176]
simple_stmt [78063,78128]
===
match
---
name: self [72662,72666]
name: self [72614,72618]
===
match
---
parameters [71864,71878]
parameters [71816,71830]
===
match
---
argument [46241,46275]
argument [46241,46275]
===
match
---
name: ti [80031,80033]
name: ti [79983,79985]
===
match
---
string: "-" [37999,38002]
string: "-" [37999,38002]
===
match
---
simple_stmt [80985,81007]
simple_stmt [80937,80959]
===
match
---
name: COLLATION_ARGS [9594,9608]
name: COLLATION_ARGS [9594,9608]
===
match
---
expr_stmt [68433,69042]
expr_stmt [68385,68994]
===
match
---
name: close [54816,54821]
name: close [54815,54820]
===
match
---
arglist [50837,50876]
arglist [50875,50914]
===
match
---
name: globals [82422,82429]
name: globals [82374,82381]
===
match
---
name: e [47982,47983]
name: e [47982,47983]
===
match
---
simple_stmt [50342,50378]
simple_stmt [50380,50416]
===
match
---
funcdef [81106,81157]
funcdef [81058,81109]
===
match
---
name: task [52950,52954]
name: task [52949,52953]
===
match
---
name: items [49405,49410]
name: items [49405,49410]
===
match
---
operator: = [62365,62366]
operator: = [62317,62318]
===
match
---
name: cmd [18707,18710]
name: cmd [18707,18710]
===
match
---
name: info [46960,46964]
name: info [46960,46964]
===
match
---
string: 'Submitting %s to sensor service' [50837,50870]
string: 'Submitting %s to sensor service' [50875,50908]
===
match
---
name: _try_number [9824,9835]
name: _try_number [9824,9835]
===
match
---
name: exc_info [50181,50189]
name: exc_info [50197,50205]
===
match
---
atom_expr [5150,5166]
atom_expr [5150,5166]
===
match
---
name: start_date [39338,39348]
name: start_date [39338,39348]
===
match
---
name: XCOM_RETURN_KEY [74654,74669]
name: XCOM_RETURN_KEY [74606,74621]
===
match
---
suite [63483,63600]
suite [63435,63552]
===
match
---
operator: , [45421,45422]
operator: , [45421,45422]
===
match
---
operator: = [7237,7238]
operator: = [7237,7238]
===
match
---
trailer [7714,7721]
trailer [7714,7721]
===
match
---
comparison [20323,20357]
comparison [20323,20357]
===
match
---
name: args [68731,68735]
name: args [68683,68687]
===
match
---
comparison [5199,5224]
comparison [5199,5224]
===
match
---
name: AirflowSmartSensorException [51068,51095]
name: AirflowSmartSensorException [51106,51133]
===
match
---
return_stmt [28544,28573]
return_stmt [28544,28573]
===
match
---
import_name [871,884]
import_name [871,884]
===
match
---
operator: = [22409,22410]
operator: = [22409,22410]
===
match
---
simple_stmt [62045,62106]
simple_stmt [61997,62058]
===
match
---
funcdef [13918,14019]
funcdef [13918,14019]
===
match
---
operator: - [5621,5622]
operator: - [5621,5622]
===
match
---
decorated [80931,81007]
decorated [80883,80959]
===
match
---
operator: = [58271,58272]
operator: = [58270,58271]
===
match
---
name: try_number [22313,22323]
name: try_number [22313,22323]
===
match
---
name: self [57230,57234]
name: self [57229,57233]
===
match
---
not_test [59033,59046]
not_test [58985,58998]
===
match
---
name: self [24431,24435]
name: self [24431,24435]
===
match
---
if_stmt [18687,18729]
if_stmt [18687,18729]
===
match
---
argument [42730,42748]
argument [42730,42748]
===
match
---
name: dag [61510,61513]
name: dag [61462,61465]
===
insert-node
---
name: TaskInstance [8835,8847]
to
classdef [8829,79511]
at 0
===
insert-tree
---
arglist [8848,8866]
    name: Base [8848,8852]
    operator: , [8852,8853]
    name: LoggingMixin [8854,8866]
to
classdef [8829,79511]
at 1
===
insert-tree
---
simple_stmt [8904,9446]
    string: """     Task instances store the state of a task instance. This table is the     authority and single source of truth around what tasks have run and the     state they are in.      The SqlAlchemy model doesn't have a SqlAlchemy foreign key to the task or     dag model deliberately to have more control over transactions.      Database transactions on this table should insure double triggers and     any confusion around what task instances are or aren't ready to run     even while multiple schedulers may be firing task instances.     """ [8904,9445]
to
suite [8899,79511]
at 0
===
update-node
---
name: error [52260,52265]
replace error by exception
===
update-node
---
name: error [58930,58935]
replace error by exception
===
update-node
---
name: exception [50168,50177]
replace exception by warning
===
insert-tree
---
strings [50058,50171]
    string: "Failed to register in sensor service." [50058,50097]
    string: " Continue to run task in non smart sensor mode." [50122,50171]
to
arglist [50178,50194]
at 0
===
insert-node
---
operator: , [50210,50211]
to
arglist [50178,50194]
at 4
===
delete-node
---
name: TaskInstance [8835,8847]
===
===
delete-tree
---
arglist [8848,8866]
    name: Base [8848,8852]
    operator: , [8852,8853]
    name: LoggingMixin [8854,8866]
===
delete-tree
---
simple_stmt [8904,9446]
    string: """     Task instances store the state of a task instance. This table is the     authority and single source of truth around what tasks have run and the     state they are in.      The SqlAlchemy model doesn't have a SqlAlchemy foreign key to the task or     dag model deliberately to have more control over transactions.      Database transactions on this table should insure double triggers and     any confusion around what task instances are or aren't ready to run     even while multiple schedulers may be firing task instances.     """ [8904,9445]
===
delete-node
---
name: e [49966,49967]
===
===
delete-tree
---
simple_stmt [49989,50139]
    atom_expr [49989,50138]
        name: self [49989,49993]
        trailer [49993,49997]
            name: log [49994,49997]
        trailer [49997,50005]
            name: warning [49998,50005]
        trailer [50005,50138]
            string: "Failed to register in sensor service.Continue to run task in non smart sensor mode." [50031,50116]
===
delete-node
---
name: e [50178,50179]
===
===
delete-node
---
name: exc [52202,52205]
===
===
delete-tree
---
simple_stmt [52320,52344]
    atom_expr [52320,52343]
        name: self [52320,52324]
        trailer [52324,52328]
            name: log [52325,52328]
        trailer [52328,52338]
            name: exception [52329,52338]
        trailer [52338,52343]
            name: exc [52339,52342]
===
delete-node
---
name: exec2 [58866,58871]
===
===
delete-tree
---
simple_stmt [58995,59021]
    atom_expr [58995,59020]
        name: self [58995,58999]
        trailer [58999,59003]
            name: log [59000,59003]
        trailer [59003,59013]
            name: exception [59004,59013]
        trailer [59013,59020]
            name: exec2 [59014,59019]
