===
match
---
name: plugin_instance [6738,6753]
name: plugin_instance [6738,6753]
===
match
---
operator: = [1400,1401]
operator: = [1400,1401]
===
match
---
name: name [6886,6890]
name: name [6886,6890]
===
match
---
name: log [9098,9101]
name: log [9073,9076]
===
match
---
operator: = [6938,6939]
operator: = [6938,6939]
===
match
---
string: "Plugin \'%s\' may not be compatible with the current Airflow version. " [10992,11064]
string: "Plugin \'%s\' may not be compatible with the current Airflow version. " [10967,11039]
===
match
---
atom_expr [14913,14931]
atom_expr [14888,14906]
===
match
---
trailer [9304,9310]
trailer [9279,9285]
===
match
---
fstring_end: " [12270,12271]
fstring_end: " [12245,12246]
===
match
---
suite [13758,14300]
suite [13733,14275]
===
match
---
param [2848,2853]
param [2848,2853]
===
match
---
string: 'Failed to import plugin %s' [8217,8245]
string: 'Failed to import plugin %s' [8192,8220]
===
match
---
name: AirflowPluginSource [2514,2533]
name: AirflowPluginSource [2514,2533]
===
match
---
trailer [10368,10391]
trailer [10343,10366]
===
match
---
operator: = [11952,11953]
operator: = [11927,11928]
===
match
---
suite [2672,2707]
suite [2672,2707]
===
match
---
name: import_errors [1370,1383]
name: import_errors [1370,1383]
===
match
---
atom_expr [8690,8700]
atom_expr [8665,8675]
===
match
---
name: module [8734,8740]
name: module [8709,8715]
===
match
---
arglist [6844,6890]
arglist [6844,6890]
===
match
---
trailer [11796,11802]
trailer [11771,11777]
===
match
---
simple_stmt [12508,12523]
simple_stmt [12483,12498]
===
match
---
trailer [10664,10694]
trailer [10639,10669]
===
match
---
name: append [14982,14988]
name: append [14957,14963]
===
match
---
trailer [8466,8472]
trailer [8441,8447]
===
match
---
trailer [5651,5660]
trailer [5651,5660]
===
match
---
atom_expr [11993,12063]
atom_expr [11968,12038]
===
match
---
trailer [12027,12063]
trailer [12002,12038]
===
match
---
trailer [7251,7266]
trailer [7251,7266]
===
match
---
suite [13115,13270]
suite [13090,13245]
===
match
---
simple_stmt [8812,8951]
simple_stmt [8787,8926]
===
match
---
name: Any [4089,4092]
name: Any [4089,4092]
===
match
---
operator: -> [13303,13305]
operator: -> [13278,13280]
===
match
---
name: plugin [10885,10891]
name: plugin [10860,10866]
===
match
---
trailer [14552,14554]
trailer [14527,14529]
===
match
---
atom_expr [14272,14283]
atom_expr [14247,14258]
===
match
---
name: registered_operator_link_classes [11607,11639]
name: registered_operator_link_classes [11582,11614]
===
match
---
name: plugins [11711,11718]
name: plugins [11686,11693]
===
match
---
annassign [1835,1863]
annassign [1835,1863]
===
match
---
name: appbuilder_menu_items [4061,4082]
name: appbuilder_menu_items [4061,4082]
===
match
---
name: load [6509,6513]
name: load [6509,6513]
===
match
---
annassign [12973,12992]
annassign [12948,12967]
===
match
---
atom_expr [14028,14063]
atom_expr [14003,14038]
===
match
---
name: operator_extra_links [11562,11582]
name: operator_extra_links [11537,11557]
===
match
---
expr_stmt [10440,10461]
expr_stmt [10415,10436]
===
match
---
atom_expr [8565,8577]
atom_expr [8540,8552]
===
match
---
name: extend [9669,9675]
name: extend [9644,9650]
===
match
---
name: load_entrypoint_plugins [6026,6049]
name: load_entrypoint_plugins [6026,6049]
===
match
---
operator: } [1403,1404]
operator: } [1403,1404]
===
match
---
operator: } [3466,3467]
operator: } [3466,3467]
===
match
---
suite [3528,3603]
suite [3528,3603]
===
match
---
trailer [4647,4652]
trailer [4647,4652]
===
match
---
trailer [9225,9254]
trailer [9200,9229]
===
match
---
suite [6990,8304]
suite [6990,8279]
===
match
---
simple_stmt [5988,6020]
simple_stmt [5988,6020]
===
match
---
atom_expr [11793,11846]
atom_expr [11768,11821]
===
match
---
name: import_errors [8270,8283]
name: import_errors [8245,8258]
===
match
---
dotted_name [1158,1184]
dotted_name [1158,1184]
===
match
---
name: Any [3942,3945]
name: Any [3942,3945]
===
match
---
param [2854,2858]
param [2854,2858]
===
match
---
expr_stmt [13711,13730]
expr_stmt [13686,13705]
===
match
---
import_name [1020,1045]
import_name [1020,1045]
===
match
---
trailer [3909,3914]
trailer [3909,3914]
===
match
---
expr_stmt [1774,1812]
expr_stmt [1774,1812]
===
match
---
arith_expr [13033,13067]
arith_expr [13008,13042]
===
match
---
name: plugins [9631,9638]
name: plugins [9606,9613]
===
match
---
trailer [7976,7978]
trailer [7976,7978]
===
match
---
trailer [10726,10802]
trailer [10701,10777]
===
match
---
number: 1 [7422,7423]
number: 1 [7422,7423]
===
match
---
factor [8596,8598]
factor [8571,8573]
===
match
---
simple_stmt [3031,3078]
simple_stmt [3031,3078]
===
match
---
atom_expr [12869,12880]
atom_expr [12844,12855]
===
match
---
name: exec_module [7755,7766]
name: exec_module [7755,7766]
===
match
---
expr_stmt [3761,3787]
expr_stmt [3761,3787]
===
match
---
suite [7455,7477]
suite [7455,7477]
===
match
---
if_stmt [12678,12758]
if_stmt [12653,12733]
===
match
---
simple_stmt [9383,9420]
simple_stmt [9358,9395]
===
match
---
atom_expr [5502,5529]
atom_expr [5502,5529]
===
match
---
name: debug [9102,9107]
name: debug [9077,9082]
===
match
---
name: macros_module [14040,14053]
name: macros_module [14015,14028]
===
match
---
name: PLUGINS_FOLDER [2912,2926]
name: PLUGINS_FOLDER [2912,2926]
===
match
---
name: splitext [7387,7395]
name: splitext [7387,7395]
===
match
---
trailer [9761,9831]
trailer [9736,9806]
===
match
---
trailer [2888,2896]
trailer [2888,2896]
===
match
---
trailer [13931,13938]
trailer [13906,13913]
===
match
---
suite [3709,5154]
suite [3709,5154]
===
match
---
raise_stmt [12706,12757]
raise_stmt [12681,12732]
===
match
---
trailer [2873,2878]
trailer [2873,2878]
===
match
---
string: ".airflowignore" [7268,7284]
string: ".airflowignore" [7268,7284]
===
match
---
name: types [938,943]
name: types [938,943]
===
match
---
trailer [1536,1548]
trailer [1536,1548]
===
match
---
atom_expr [13979,14015]
atom_expr [13954,13990]
===
match
---
atom_expr [13809,13854]
atom_expr [13784,13829]
===
match
---
name: registered_operator_link_classes [11421,11453]
name: registered_operator_link_classes [11396,11428]
===
match
---
atom_expr [6918,6936]
atom_expr [6918,6936]
===
match
---
except_clause [6763,6784]
except_clause [6763,6784]
===
match
---
name: plugin [10597,10603]
name: plugin [10572,10578]
===
match
---
atom_expr [1837,1856]
atom_expr [1837,1856]
===
match
---
string: "appbuilder_menu_items" [2402,2425]
string: "appbuilder_menu_items" [2402,2425]
===
match
---
name: List [1902,1906]
name: List [1902,1906]
===
match
---
name: Type [1005,1009]
name: Type [1005,1009]
===
match
---
name: validate [5652,5660]
name: validate [5652,5660]
===
match
---
name: operator_extra_links [12112,12132]
name: operator_extra_links [12087,12107]
===
match
---
name: __init__ [2839,2847]
name: __init__ [2839,2847]
===
match
---
parameters [3431,3437]
parameters [3431,3437]
===
match
---
expr_stmt [14779,14796]
expr_stmt [14754,14771]
===
match
---
name: on_load [4868,4875]
name: on_load [4868,4875]
===
match
---
name: debug [6271,6276]
name: debug [6271,6276]
===
match
---
name: plugins [10550,10557]
name: plugins [10525,10532]
===
match
---
raise_stmt [2622,2647]
raise_stmt [2622,2647]
===
match
---
name: n [14929,14930]
name: n [14904,14905]
===
match
---
trailer [9755,9761]
trailer [9730,9736]
===
match
---
trailer [8626,8635]
trailer [8601,8610]
===
match
---
name: self [2666,2670]
name: self [2666,2670]
===
match
---
atom [9371,9373]
atom [9346,9348]
===
match
---
name: register_plugin [5727,5742]
name: register_plugin [5727,5742]
===
match
---
trailer [14908,14956]
trailer [14883,14931]
===
match
---
funcdef [5156,5721]
funcdef [5156,5721]
===
match
---
string: """Class used to define AirflowPlugin.""" [3714,3755]
string: """Class used to define AirflowPlugin.""" [3714,3755]
===
match
---
name: log [9260,9263]
name: log [9235,9238]
===
match
---
atom_expr [10630,10694]
atom_expr [10605,10669]
===
match
---
atom_expr [6830,6891]
atom_expr [6830,6891]
===
match
---
operator: = [13019,13020]
operator: = [12994,12995]
===
match
---
simple_stmt [9871,9913]
simple_stmt [9846,9888]
===
match
---
expr_stmt [1976,2024]
expr_stmt [1976,2024]
===
match
---
operator: = [3947,3948]
operator: = [3947,3948]
===
match
---
suite [9743,9832]
suite [9718,9807]
===
match
---
simple_stmt [7944,7979]
simple_stmt [7944,7979]
===
match
---
suite [6469,6755]
suite [6469,6755]
===
match
---
name: Optional [1747,1755]
name: Optional [1747,1755]
===
match
---
trailer [13642,13665]
trailer [13617,13640]
===
match
---
trailer [10783,10800]
trailer [10758,10775]
===
match
---
operator: , [13923,13924]
operator: , [13898,13899]
===
match
---
simple_stmt [931,944]
simple_stmt [931,944]
===
match
---
simple_stmt [7651,7695]
simple_stmt [7651,7695]
===
match
---
annassign [3798,3836]
annassign [3798,3836]
===
match
---
name: version [3365,3372]
name: version [3365,3372]
===
match
---
simple_stmt [8529,8561]
simple_stmt [8504,8536]
===
match
---
param [2607,2611]
param [2607,2611]
===
match
---
name: source [8011,8017]
name: source [8011,8017]
===
match
---
name: NotImplementedError [2687,2706]
name: NotImplementedError [2687,2706]
===
match
---
simple_stmt [12902,12954]
simple_stmt [12877,12929]
===
match
---
simple_stmt [3447,3504]
simple_stmt [3447,3504]
===
match
---
simple_stmt [9098,9149]
simple_stmt [9073,9124]
===
match
---
atom_expr [7657,7694]
atom_expr [7657,7694]
===
match
---
operator: , [14381,14382]
operator: , [14356,14357]
===
match
---
funcdef [6022,6947]
funcdef [6022,6947]
===
match
---
atom [10459,10461]
atom [10434,10436]
===
match
---
operator: -> [12403,12405]
operator: -> [12378,12380]
===
match
---
string: "name" [14864,14870]
string: "name" [14839,14845]
===
match
---
comparison [13770,13789]
comparison [13745,13764]
===
match
---
trailer [13578,13580]
trailer [13553,13555]
===
match
---
expr_stmt [3924,3951]
expr_stmt [3924,3951]
===
match
---
trailer [14878,14883]
trailer [14853,14858]
===
match
---
operator: , [2901,2902]
operator: , [2901,2902]
===
match
---
if_stmt [14702,14775]
if_stmt [14677,14750]
===
match
---
name: name [4766,4770]
name: name [4766,4770]
===
match
---
operator: = [1639,1640]
operator: = [1639,1640]
===
match
---
name: n [14936,14937]
name: n [14911,14912]
===
match
---
name: os [7396,7398]
name: os [7396,7398]
===
match
---
trailer [12176,12183]
trailer [12151,12158]
===
match
---
name: n [14910,14911]
name: n [14885,14886]
===
match
---
name: airflow [8960,8967]
name: airflow [8935,8942]
===
match
---
for_stmt [7201,8304]
for_stmt [7201,8279]
===
match
---
operator: = [7655,7656]
operator: = [7655,7656]
===
match
---
trailer [1531,1549]
trailer [1531,1549]
===
match
---
simple_stmt [2869,2928]
simple_stmt [2869,2928]
===
match
---
operator: = [13726,13727]
operator: = [13701,13702]
===
match
---
string: "Can't load plugins." [13643,13664]
string: "Can't load plugins." [13618,13639]
===
match
---
name: log [8463,8466]
name: log [8438,8441]
===
match
---
name: global_operator_extra_links [11993,12020]
name: global_operator_extra_links [11968,11995]
===
match
---
import_from [1070,1122]
import_from [1070,1122]
===
match
---
file_input [787,15019]
file_input [787,14994]
===
match
---
name: e [8301,8302]
name: e [8276,8277]
===
match
---
atom_expr [1702,1721]
atom_expr [1702,1721]
===
match
---
simple_stmt [814,831]
simple_stmt [814,831]
===
match
---
operator: , [14927,14928]
operator: , [14902,14903]
===
match
---
operator: > [9739,9740]
operator: > [9714,9715]
===
match
---
name: macros [3897,3903]
name: macros [3897,3903]
===
match
---
trailer [8543,8554]
trailer [8518,8529]
===
match
---
atom_expr [1523,1549]
atom_expr [1523,1549]
===
match
---
operator: = [1806,1807]
operator: = [1806,1807]
===
match
---
simple_stmt [1813,1864]
simple_stmt [1813,1864]
===
match
---
name: importlib [7657,7666]
name: importlib [7657,7666]
===
match
---
name: admin_views [10823,10834]
name: admin_views [10798,10809]
===
match
---
atom_expr [10665,10693]
atom_expr [10640,10668]
===
match
---
operator: = [8510,8511]
operator: = [8485,8486]
===
match
---
operator: = [4015,4016]
operator: = [4015,4016]
===
match
---
name: importlib_metadata [3224,3242]
name: importlib_metadata [3224,3242]
===
match
---
arglist [6691,6708]
arglist [6691,6708]
===
match
---
suite [1289,1334]
suite [1289,1334]
===
match
---
name: split [7404,7409]
name: split [7404,7409]
===
match
---
simple_stmt [7707,7736]
simple_stmt [7707,7736]
===
match
---
global_stmt [8992,9024]
global_stmt [8967,8999]
===
match
---
dictorsetmaker [14910,14954]
dictorsetmaker [14885,14929]
===
match
---
name: plugins [13589,13596]
name: plugins [13564,13571]
===
match
---
trailer [13674,13680]
trailer [13649,13655]
===
match
---
name: num_loaded [9695,9705]
name: num_loaded [9670,9680]
===
match
---
name: update [12177,12183]
name: update [12152,12158]
===
match
---
name: register_plugin [8070,8085]
name: register_plugin [8070,8085]
===
match
---
expr_stmt [7651,7694]
expr_stmt [7651,7694]
===
match
---
atom_expr [7719,7728]
atom_expr [7719,7728]
===
match
---
name: importlib [821,830]
name: importlib [821,830]
===
match
---
funcdef [9834,11168]
funcdef [9809,11143]
===
match
---
trailer [2883,2888]
trailer [2883,2888]
===
match
---
trailer [14031,14039]
trailer [14006,14014]
===
match
---
atom_expr [3066,3075]
atom_expr [3066,3075]
===
match
---
trailer [13831,13854]
trailer [13806,13829]
===
match
---
operator: } [2504,2505]
operator: } [2504,2505]
===
match
---
name: path [7305,7309]
name: path [7305,7309]
===
match
---
atom_expr [7748,7771]
atom_expr [7748,7771]
===
match
---
trailer [6270,6276]
trailer [6270,6276]
===
match
---
atom_expr [7396,7424]
atom_expr [7396,7424]
===
match
---
atom_expr [6394,6456]
atom_expr [6394,6456]
===
match
---
global_stmt [13391,13405]
global_stmt [13366,13380]
===
match
---
expr_stmt [9695,9720]
expr_stmt [9670,9695]
===
match
---
simple_stmt [8463,8501]
simple_stmt [8438,8476]
===
match
---
trailer [7309,7316]
trailer [7309,7316]
===
match
---
atom_expr [8297,8303]
atom_expr [8272,8278]
===
match
---
name: plugin [14272,14278]
name: plugin [14247,14253]
===
match
---
name: ModuleType [8544,8554]
name: ModuleType [8519,8529]
===
match
---
name: load_plugins_from_plugin_directory [9383,9417]
name: load_plugins_from_plugin_directory [9358,9392]
===
match
---
name: objects [8430,8437]
name: objects [8405,8412]
===
match
---
operator: , [993,994]
operator: , [993,994]
===
match
---
annassign [4003,4019]
annassign [4003,4019]
===
match
---
string: """Class used to define an AirflowPluginSource.""" [2539,2589]
string: """Class used to define an AirflowPluginSource.""" [2539,2589]
===
match
---
suite [3022,3078]
suite [3022,3078]
===
match
---
operator: } [3560,3561]
operator: } [3560,3561]
===
match
---
operator: , [9814,9815]
operator: , [9789,9790]
===
match
---
operator: } [11955,11956]
operator: } [11930,11931]
===
match
---
atom_expr [8207,8257]
atom_expr [8178,8232]
===
match
---
atom_expr [6649,6671]
atom_expr [6649,6671]
===
match
---
name: macros [13932,13938]
name: macros [13907,13913]
===
match
---
trailer [7688,7694]
trailer [7688,7694]
===
match
---
name: util [875,879]
name: util [875,879]
===
match
---
trailer [9184,9199]
trailer [9159,9174]
===
match
---
fstring_end: " [3502,3503]
fstring_end: " [3502,3503]
===
match
---
simple_stmt [3761,3788]
simple_stmt [3761,3788]
===
match
---
atom_expr [1385,1399]
atom_expr [1385,1399]
===
match
---
dotted_name [8960,8973]
dotted_name [8935,8948]
===
match
---
comparison [10315,10330]
comparison [10290,10305]
===
match
---
name: flask_appbuilder_views [10567,10589]
name: flask_appbuilder_views [10542,10564]
===
match
---
atom_expr [6343,6384]
atom_expr [6343,6384]
===
match
---
name: Any [4648,4651]
name: Any [4648,4651]
===
match
---
comparison [10128,10156]
comparison [10103,10131]
===
match
---
string: '.' [8591,8594]
string: '.' [8566,8569]
===
match
---
annassign [1700,1728]
annassign [1700,1728]
===
match
---
name: log [11793,11796]
name: log [11768,11771]
===
match
---
operator: } [14883,14884]
operator: } [14858,14859]
===
match
---
atom_expr [2903,2926]
atom_expr [2903,2926]
===
match
---
operator: = [3888,3889]
operator: = [3888,3889]
===
match
---
name: AirflowPlugin [3695,3708]
name: AirflowPlugin [3695,3708]
===
match
---
annassign [1947,1975]
annassign [1947,1975]
===
match
---
expr_stmt [1505,1556]
expr_stmt [1505,1556]
===
match
---
name: import_errors [7069,7082]
name: import_errors [7069,7082]
===
match
---
name: str [1390,1393]
name: str [1390,1393]
===
match
---
simple_stmt [10963,11168]
simple_stmt [10938,11143]
===
match
---
simple_stmt [4621,4658]
simple_stmt [4621,4658]
===
match
---
simple_stmt [14531,14555]
simple_stmt [14506,14530]
===
match
---
operator: } [13921,13922]
operator: } [13896,13897]
===
match
---
simple_stmt [6604,6637]
simple_stmt [6604,6637]
===
match
---
suite [12889,12954]
suite [12864,12929]
===
match
---
for_stmt [11962,12368]
for_stmt [11937,12343]
===
match
---
simple_stmt [7468,7477]
simple_stmt [7468,7477]
===
match
---
string: "source" [2494,2502]
string: "source" [2494,2502]
===
match
---
name: plugins [5440,5447]
name: plugins [5440,5447]
===
match
---
name: link [12246,12250]
name: link [12221,12225]
===
match
---
atom_expr [9816,9830]
atom_expr [9791,9805]
===
match
---
try_stmt [6465,6947]
try_stmt [6465,6947]
===
match
---
trailer [2911,2926]
trailer [2911,2926]
===
match
---
trailer [14345,14356]
trailer [14320,14331]
===
match
---
operator: = [14357,14358]
operator: = [14332,14333]
===
match
---
and_test [11510,11651]
and_test [11485,11626]
===
match
---
trailer [7381,7386]
trailer [7381,7386]
===
match
---
atom_expr [14256,14299]
atom_expr [14231,14274]
===
match
---
name: plugin [11966,11972]
name: plugin [11941,11947]
===
match
---
dotted_name [838,857]
dotted_name [838,857]
===
match
---
simple_stmt [10498,10531]
simple_stmt [10473,10506]
===
match
---
simple_stmt [6830,6892]
simple_stmt [6830,6892]
===
match
---
operator: = [7587,7588]
operator: = [7587,7588]
===
match
---
atom_expr [1949,1968]
atom_expr [1949,1968]
===
match
---
and_test [10128,10255]
and_test [10103,10230]
===
match
---
string: """Class used to define Plugins loaded from entrypoint.""" [3129,3187]
string: """Class used to define Plugins loaded from entrypoint.""" [3129,3187]
===
match
---
name: base [1313,1317]
name: base [1313,1317]
===
match
---
trailer [10891,10902]
trailer [10866,10877]
===
match
---
simple_stmt [13864,13940]
simple_stmt [13839,13915]
===
match
---
simple_stmt [7341,7350]
simple_stmt [7341,7350]
===
match
---
trailer [7723,7728]
trailer [7723,7728]
===
match
---
atom_expr [8666,8722]
atom_expr [8641,8697]
===
match
---
operator: , [4886,4887]
operator: , [4886,4887]
===
match
---
name: AirflowPluginException [13809,13831]
name: AirflowPluginException [13784,13806]
===
match
---
trailer [8042,8053]
trailer [8042,8053]
===
match
---
and_test [5502,5625]
and_test [5502,5625]
===
match
---
name: ensure_plugins_loaded [11679,11700]
name: ensure_plugins_loaded [11654,11675]
===
match
---
name: spec [7582,7586]
name: spec [7582,7586]
===
match
---
atom [10118,10261]
atom [10093,10236]
===
match
---
trailer [7598,7603]
trailer [7598,7603]
===
match
---
operator: , [5563,5564]
operator: , [5563,5564]
===
match
---
name: getattr [14913,14920]
name: getattr [14888,14895]
===
match
---
name: timer [9816,9821]
name: timer [9791,9796]
===
match
---
trailer [10719,10726]
trailer [10694,10701]
===
match
---
expr_stmt [8620,8645]
expr_stmt [8595,8620]
===
match
---
name: warning [10967,10974]
name: warning [10942,10949]
===
match
---
operator: = [11880,11881]
operator: = [11855,11856]
===
match
---
param [4888,4896]
param [4888,4896]
===
match
---
except_clause [8111,8132]
except_clause [8111,8132]
===
match
---
trailer [8590,8595]
trailer [8565,8570]
===
match
---
name: m [7877,7878]
name: m [7877,7878]
===
match
---
atom_expr [8512,8524]
atom_expr [8487,8499]
===
match
---
name: plugin [14872,14878]
name: plugin [14847,14853]
===
match
---
trailer [8554,8560]
trailer [8529,8535]
===
match
---
simple_stmt [14897,14957]
simple_stmt [14872,14932]
===
match
---
expr_stmt [14028,14079]
expr_stmt [14003,14054]
===
match
---
subscriptlist [14378,14386]
subscriptlist [14353,14361]
===
match
---
name: flask_appbuilder_views [1813,1835]
name: flask_appbuilder_views [1813,1835]
===
match
---
atom_expr [14531,14554]
atom_expr [14506,14529]
===
match
---
name: mod [7732,7735]
name: mod [7732,7735]
===
match
---
atom_expr [13183,13221]
atom_expr [13158,13196]
===
match
---
operator: = [14064,14065]
operator: = [14039,14040]
===
match
---
operator: , [987,988]
operator: , [987,988]
===
match
---
name: Dict [14373,14377]
name: Dict [14348,14352]
===
match
---
trailer [3364,3372]
trailer [3364,3372]
===
match
---
name: path [2884,2888]
name: path [2884,2888]
===
match
---
name: AirflowPluginSource [2738,2757]
name: AirflowPluginSource [2738,2757]
===
match
---
string: "hooks" [2310,2317]
string: "hooks" [2310,2317]
===
match
---
trailer [8522,8524]
trailer [8497,8499]
===
match
---
atom_expr [3345,3357]
atom_expr [3345,3357]
===
match
---
operator: } [3600,3601]
operator: } [3600,3601]
===
match
---
name: path [2991,2995]
name: path [2991,2995]
===
match
---
suite [7328,7350]
suite [7328,7350]
===
match
---
operator: + [13054,13055]
operator: + [13029,13030]
===
match
---
and_test [10816,10866]
and_test [10791,10841]
===
match
---
string: "Failed to import plugin %s" [6844,6872]
string: "Failed to import plugin %s" [6844,6872]
===
match
---
annassign [4082,4098]
annassign [4082,4098]
===
match
---
atom_expr [10963,11167]
atom_expr [10938,11142]
===
match
---
name: Dict [1385,1389]
name: Dict [1385,1389]
===
match
---
name: extend [10590,10596]
name: extend [10565,10571]
===
match
---
simple_stmt [3537,3603]
simple_stmt [3537,3603]
===
match
---
trailer [6737,6754]
trailer [6737,6754]
===
match
---
trailer [10657,10664]
trailer [10632,10639]
===
match
---
param [5176,5186]
param [5176,5186]
===
match
---
atom_expr [1573,1592]
atom_expr [1573,1592]
===
match
---
expr_stmt [4621,4657]
expr_stmt [4621,4657]
===
match
---
if_stmt [11708,11788]
if_stmt [11683,11763]
===
match
---
trailer [6397,6403]
trailer [6397,6403]
===
match
---
if_stmt [10115,10278]
if_stmt [10090,10253]
===
match
---
trailer [3775,3780]
trailer [3775,3780]
===
match
---
funcdef [3193,3415]
funcdef [3193,3415]
===
match
---
name: Optional [14337,14345]
name: Optional [14312,14320]
===
match
---
suite [6052,6947]
suite [6052,6947]
===
match
---
name: EntryPoint [3243,3253]
name: EntryPoint [3243,3253]
===
match
---
simple_stmt [2622,2648]
simple_stmt [2622,2648]
===
match
---
name: plugins [9963,9970]
name: plugins [9938,9945]
===
match
---
name: macros_modules [13711,13725]
name: macros_modules [13686,13700]
===
match
---
trailer [11147,11152]
trailer [11122,11127]
===
match
---
trailer [1632,1637]
trailer [1632,1637]
===
match
---
if_stmt [13586,13666]
if_stmt [13561,13641]
===
match
---
param [3255,3292]
param [3255,3292]
===
match
---
operator: { [3065,3066]
operator: { [3065,3066]
===
match
---
name: Any [2012,2015]
name: Any [2012,2015]
===
match
---
trailer [9821,9830]
trailer [9796,9805]
===
match
---
trailer [7710,7718]
trailer [7710,7718]
===
match
---
atom_expr [10397,10434]
atom_expr [10372,10409]
===
match
---
atom_expr [3551,3560]
atom_expr [3551,3560]
===
match
---
string: """Creates new module.""" [8393,8418]
string: """Creates new module.""" [8368,8393]
===
match
---
sync_comp_for [10767,10800]
sync_comp_for [10742,10775]
===
match
---
trailer [1957,1968]
trailer [1957,1968]
===
match
---
atom_expr [9652,9689]
atom_expr [9627,9664]
===
match
---
name: log [10963,10966]
name: log [10938,10941]
===
match
---
name: attrs_to_dump [14709,14722]
name: attrs_to_dump [14684,14697]
===
match
---
return_stmt [14999,15018]
return_stmt [14974,14993]
===
match
---
name: is_valid_plugin [7907,7922]
name: is_valid_plugin [7907,7922]
===
match
---
expr_stmt [6482,6515]
expr_stmt [6482,6515]
===
match
---
raise_stmt [4784,4841]
raise_stmt [4784,4841]
===
match
---
or_test [10815,10949]
or_test [10790,10924]
===
match
---
atom_expr [7907,7925]
atom_expr [7907,7925]
===
match
---
global_stmt [10003,10032]
global_stmt [9978,10007]
===
match
---
suite [3645,3687]
suite [3645,3687]
===
match
---
name: __dict__ [8673,8681]
name: __dict__ [8648,8656]
===
match
---
global_stmt [6205,6225]
global_stmt [6205,6225]
===
match
---
simple_stmt [13614,13666]
simple_stmt [13589,13641]
===
match
---
tfpdef [3255,3292]
tfpdef [3255,3292]
===
match
---
suite [8165,8304]
suite [8165,8279]
===
match
---
subscriptlist [2073,2082]
subscriptlist [2073,2082]
===
match
---
trailer [6929,6936]
trailer [6929,6936]
===
match
---
atom_expr [10737,10748]
atom_expr [10712,10723]
===
match
---
atom_expr [4643,4652]
atom_expr [4643,4652]
===
match
---
trailer [12099,12134]
trailer [12074,12109]
===
match
---
atom_expr [5958,5983]
atom_expr [5958,5983]
===
match
---
name: List [1628,1632]
name: List [1628,1632]
===
match
---
operator: , [6872,6873]
operator: , [6872,6873]
===
match
---
parameters [11214,11216]
parameters [11189,11191]
===
match
---
name: macros_module [13952,13965]
name: macros_module [13927,13940]
===
match
---
trailer [5660,5662]
trailer [5660,5662]
===
match
---
name: flask_blueprints [9982,9998]
name: flask_blueprints [9957,9973]
===
match
---
name: macros_module [14066,14079]
name: macros_module [14041,14054]
===
match
---
expr_stmt [1335,1368]
expr_stmt [1335,1368]
===
match
---
string: """         Executed when the plugin is loaded.         This method is only called once during runtime.          :param args: If future arguments are passed in on call.         :param kwargs: If future arguments are passed in on call.         """ [4907,5153]
string: """         Executed when the plugin is loaded.         This method is only called once during runtime.          :param args: If future arguments are passed in on call.         :param kwargs: If future arguments are passed in on call.         """ [4907,5153]
===
match
---
trailer [1586,1591]
trailer [1586,1591]
===
match
---
trailer [7787,7793]
trailer [7787,7793]
===
match
---
parameters [2665,2671]
parameters [2665,2671]
===
match
---
name: ValueError [9215,9225]
name: ValueError [9190,9200]
===
match
---
operator: { [12245,12246]
operator: { [12220,12221]
===
match
---
name: plugin [10843,10849]
name: plugin [10818,10824]
===
match
---
atom_expr [7123,7195]
atom_expr [7123,7195]
===
match
---
trailer [3328,3336]
trailer [3328,3336]
===
match
---
comparison [10216,10255]
comparison [10191,10230]
===
match
---
name: make_module [13880,13891]
name: make_module [13855,13866]
===
match
---
simple_stmt [7748,7772]
simple_stmt [7748,7772]
===
match
---
trailer [7395,7425]
trailer [7395,7425]
===
match
---
name: operator_extra_links [4621,4641]
name: operator_extra_links [4621,4641]
===
match
---
name: machinery [7522,7531]
name: machinery [7522,7531]
===
match
---
operator: = [9369,9370]
operator: = [9344,9345]
===
match
---
suite [8438,8459]
suite [8413,8434]
===
match
---
expr_stmt [1920,1975]
expr_stmt [1920,1975]
===
match
---
trailer [8010,8017]
trailer [8010,8017]
===
match
---
name: attrs_to_dump [14941,14954]
name: attrs_to_dump [14916,14929]
===
match
---
atom_expr [2007,2016]
atom_expr [2007,2016]
===
match
---
if_stmt [9725,9832]
if_stmt [9700,9807]
===
match
---
name: str [14378,14381]
name: str [14353,14356]
===
match
---
simple_stmt [8992,9061]
simple_stmt [8967,9036]
===
match
---
comparison [12598,12627]
comparison [12573,12602]
===
match
---
name: path [3071,3075]
name: path [3071,3075]
===
match
---
trailer [7754,7766]
trailer [7754,7766]
===
match
---
expr_stmt [3867,3892]
expr_stmt [3867,3892]
===
match
---
name: Any [3853,3856]
name: Any [3853,3856]
===
match
---
name: str [1395,1398]
name: str [1395,1398]
===
match
---
expr_stmt [14732,14774]
expr_stmt [14707,14749]
===
match
---
trailer [12987,12992]
trailer [12962,12967]
===
match
---
atom [10815,10867]
atom [10790,10842]
===
match
---
name: self [3457,3461]
name: self [3457,3461]
===
match
---
trailer [5973,5981]
trailer [5973,5981]
===
match
---
string: 'name' [10729,10735]
string: 'name' [10704,10710]
===
match
---
operator: , [14283,14284]
operator: , [14258,14259]
===
match
---
suite [14389,15019]
suite [14364,14994]
===
match
---
if_stmt [10312,10392]
if_stmt [10287,10367]
===
match
---
name: plugin [9676,9682]
name: plugin [9651,9657]
===
match
---
simple_stmt [11889,11915]
simple_stmt [11864,11890]
===
match
---
operator: = [2018,2019]
operator: = [2018,2019]
===
match
---
name: TYPE_CHECKING [1275,1288]
name: TYPE_CHECKING [1275,1288]
===
match
---
parameters [13300,13302]
parameters [13275,13277]
===
match
---
name: entry_point [6691,6702]
name: entry_point [6691,6702]
===
match
---
simple_stmt [1215,1271]
simple_stmt [1215,1271]
===
match
---
classdef [3605,3687]
classdef [3605,3687]
===
match
---
operator: = [4418,4419]
operator: = [4418,4419]
===
match
---
trailer [10603,10620]
trailer [10578,10595]
===
match
---
name: entrypoint [3491,3501]
name: entrypoint [3491,3501]
===
match
---
name: airflow [13479,13486]
name: airflow [13454,13461]
===
match
---
name: plugin [10816,10822]
name: plugin [10791,10797]
===
match
---
operator: = [12979,12980]
operator: = [12954,12955]
===
match
---
atom_expr [14337,14356]
atom_expr [14312,14331]
===
match
---
name: file_path [7410,7419]
name: file_path [7410,7419]
===
match
---
trailer [9269,9288]
trailer [9244,9263]
===
match
---
name: path [2897,2901]
name: path [2897,2901]
===
match
---
name: self [2869,2873]
name: self [2869,2873]
===
match
---
trailer [3808,3829]
trailer [3808,3829]
===
match
---
atom_expr [3878,3887]
atom_expr [3878,3887]
===
match
---
name: Optional [1619,1627]
name: Optional [1619,1627]
===
match
---
name: operator_extra_links [11389,11409]
name: operator_extra_links [11364,11384]
===
match
---
name: log [6267,6270]
name: log [6267,6270]
===
match
---
simple_stmt [858,880]
simple_stmt [858,880]
===
match
---
import_name [858,879]
import_name [858,879]
===
match
---
simple_stmt [1920,1976]
simple_stmt [1920,1976]
===
match
---
name: file [1234,1238]
name: file [1234,1238]
===
match
---
name: o [8702,8703]
name: o [8677,8678]
===
match
---
atom_expr [1747,1766]
atom_expr [1747,1766]
===
match
---
operator: @ [4663,4664]
operator: @ [4663,4664]
===
match
---
name: BaseHook [1325,1333]
name: BaseHook [1325,1333]
===
match
---
comp_op [12616,12622]
comp_op [12591,12597]
===
match
---
simple_stmt [3956,3989]
simple_stmt [3956,3989]
===
match
---
suite [9639,9690]
suite [9614,9665]
===
match
---
if_stmt [5489,5704]
if_stmt [5489,5704]
===
match
---
trailer [1581,1592]
trailer [1581,1592]
===
match
---
simple_stmt [8393,8419]
simple_stmt [8368,8394]
===
match
---
comparison [7437,7454]
comparison [7437,7454]
===
match
---
name: Optional [1523,1531]
name: Optional [1523,1531]
===
match
---
atom [10728,10766]
atom [10703,10741]
===
match
---
dictorsetmaker [14864,14883]
dictorsetmaker [14839,14858]
===
match
---
name: PluginsDirectorySource [2715,2737]
name: PluginsDirectorySource [2715,2737]
===
match
---
trailer [14278,14283]
trailer [14253,14258]
===
match
---
name: register_plugin [6722,6737]
name: register_plugin [6722,6737]
===
match
---
annassign [4406,4422]
annassign [4406,4422]
===
match
---
trailer [7126,7132]
trailer [7126,7132]
===
match
---
name: spec [7719,7723]
name: spec [7719,7723]
===
match
---
name: __html__ [3007,3015]
name: __html__ [3007,3015]
===
match
---
expr_stmt [10498,10530]
expr_stmt [10473,10505]
===
match
---
name: ensure_plugins_loaded [14531,14552]
name: ensure_plugins_loaded [14506,14527]
===
match
---
fstring_string: . [12244,12245]
fstring_string: . [12219,12220]
===
match
---
trailer [5981,5983]
trailer [5981,5983]
===
match
---
trailer [3461,3466]
trailer [3461,3466]
===
match
---
simple_stmt [10630,10695]
simple_stmt [10605,10670]
===
match
---
operator: != [7446,7448]
operator: != [7446,7448]
===
match
---
name: duration [9822,9830]
name: duration [9797,9805]
===
match
---
operator: = [8536,8537]
operator: = [8511,8512]
===
match
---
name: importlib_metadata [1104,1122]
name: importlib_metadata [1104,1122]
===
match
---
operator: = [4094,4095]
operator: = [4094,4095]
===
match
---
name: _objects [8627,8635]
name: _objects [8602,8610]
===
match
---
arglist [13033,13085]
arglist [13008,13060]
===
match
---
trailer [7671,7688]
trailer [7671,7688]
===
match
---
string: """Integrates macro plugins.""" [13316,13347]
string: """Integrates macro plugins.""" [13291,13322]
===
match
---
operator: , [7169,7170]
operator: , [7169,7170]
===
match
---
name: typing [949,955]
name: typing [949,955]
===
match
---
operator: , [8366,8367]
operator: , [8341,8342]
===
match
---
atom_expr [13069,13085]
atom_expr [13044,13060]
===
match
---
string: "Can't load plugins." [10369,10390]
string: "Can't load plugins." [10344,10365]
===
match
---
atom_expr [4084,4093]
atom_expr [4084,4093]
===
match
---
string: "macros" [2340,2348]
string: "macros" [2340,2348]
===
match
---
name: flask_blueprints [10128,10144]
name: flask_blueprints [10103,10119]
===
match
---
fstring_start: f' [13892,13894]
fstring_start: f' [13867,13869]
===
match
---
raise_stmt [13614,13665]
raise_stmt [13589,13640]
===
match
---
fstring_start: f" [3544,3546]
fstring_start: f" [3544,3546]
===
match
---
operator: , [2348,2349]
operator: , [2348,2349]
===
match
---
name: __str__ [3424,3431]
name: __str__ [3424,3431]
===
match
---
name: debug [7788,7793]
name: debug [7788,7793]
===
match
---
param [3206,3211]
param [3206,3211]
===
match
---
name: getLogger [1349,1358]
name: getLogger [1349,1358]
===
match
---
name: entrypoint [3590,3600]
name: entrypoint [3590,3600]
===
match
---
suite [3124,3603]
suite [3124,3603]
===
match
---
simple_stmt [7062,7119]
simple_stmt [7062,7119]
===
match
---
annassign [3846,3862]
annassign [3846,3862]
===
match
---
trailer [5552,5579]
trailer [5552,5579]
===
match
---
name: plugin_class [6482,6494]
name: plugin_class [6482,6494]
===
match
---
operator: } [2995,2996]
operator: } [2995,2996]
===
match
---
name: settings [2903,2911]
name: settings [2903,2911]
===
match
---
param [3522,3526]
param [3522,3526]
===
match
---
trailer [1845,1856]
trailer [1845,1856]
===
match
---
atom_expr [10346,10391]
atom_expr [10321,10366]
===
match
---
trailer [11802,11846]
trailer [11777,11821]
===
match
---
funcdef [8779,9832]
funcdef [8754,9807]
===
match
---
string: """Creates modules for loaded extension from extra operators links plugins""" [11222,11299]
string: """Creates modules for loaded extension from extra operators links plugins""" [11197,11274]
===
match
---
string: """Exception when loading plugin.""" [3650,3686]
string: """Exception when loading plugin.""" [3650,3686]
===
match
---
expr_stmt [2275,2505]
expr_stmt [2275,2505]
===
match
---
name: appbuilder_views [10850,10866]
name: appbuilder_views [10825,10841]
===
match
---
if_stmt [7434,7477]
if_stmt [7434,7477]
===
match
---
simple_stmt [1505,1557]
simple_stmt [1505,1557]
===
match
---
name: ensure_plugins_loaded [8783,8804]
name: ensure_plugins_loaded [8758,8779]
===
match
---
atom_expr [8580,8599]
atom_expr [8555,8574]
===
match
---
atom_expr [14040,14062]
atom_expr [14015,14037]
===
match
---
name: self [3551,3555]
name: self [3551,3555]
===
match
---
simple_stmt [11919,11957]
simple_stmt [11894,11932]
===
match
---
trailer [13680,13705]
trailer [13655,13680]
===
match
---
trailer [10966,10974]
trailer [10941,10949]
===
match
---
trailer [7386,7395]
trailer [7386,7395]
===
match
---
atom_expr [7995,8017]
atom_expr [7995,8017]
===
match
---
name: update [8682,8688]
name: update [8657,8663]
===
match
---
simple_stmt [9157,9164]
simple_stmt [9132,9139]
===
match
---
name: Any [1761,1764]
name: Any [1761,1764]
===
match
---
name: __init__ [3197,3205]
name: __init__ [3197,3205]
===
match
---
atom_expr [9676,9688]
atom_expr [9651,9663]
===
match
---
simple_stmt [3129,3188]
simple_stmt [3129,3188]
===
match
---
comparison [10169,10203]
comparison [10144,10178]
===
match
---
trailer [6664,6671]
trailer [6664,6671]
===
match
---
operator: , [2372,2373]
operator: , [2372,2373]
===
match
---
name: logging [1341,1348]
name: logging [1341,1348]
===
match
---
arglist [7133,7194]
arglist [7133,7194]
===
match
---
string: "Integrate executor plugins" [12773,12801]
string: "Integrate executor plugins" [12748,12776]
===
match
---
atom_expr [7589,7638]
atom_expr [7589,7638]
===
match
---
simple_stmt [1729,1774]
simple_stmt [1729,1774]
===
match
---
comp_op [5604,5610]
comp_op [5604,5610]
===
match
---
string: "Plugins folder is not set" [9226,9253]
string: "Plugins folder is not set" [9201,9228]
===
match
---
trailer [10917,10939]
trailer [10892,10914]
===
match
---
expr_stmt [4061,4098]
expr_stmt [4061,4098]
===
match
---
name: List [4042,4046]
name: List [4042,4046]
===
match
---
name: AirflowPluginException [13620,13642]
name: AirflowPluginException [13595,13617]
===
match
---
operator: } [10765,10766]
operator: } [10740,10741]
===
match
---
trailer [7409,7420]
trailer [7409,7420]
===
match
---
comparison [5678,5703]
comparison [5678,5703]
===
match
---
simple_stmt [9695,9721]
simple_stmt [9670,9696]
===
match
---
trailer [7922,7925]
trailer [7922,7925]
===
match
---
expr_stmt [11852,11884]
expr_stmt [11827,11859]
===
match
---
expr_stmt [1600,1645]
expr_stmt [1600,1645]
===
match
---
atom_expr [6674,6709]
atom_expr [6674,6709]
===
match
---
name: issubclass [5542,5552]
name: issubclass [5542,5552]
===
match
---
string: "operator_extra_links" [2466,2488]
string: "operator_extra_links" [2466,2488]
===
match
---
atom_expr [8270,8294]
atom_expr [8245,8269]
===
match
---
operator: , [3253,3254]
operator: , [3253,3254]
===
match
---
name: dist [3556,3560]
name: dist [3556,3560]
===
match
---
operator: { [3469,3470]
operator: { [3469,3470]
===
match
---
name: macros_modules [1557,1571]
name: macros_modules [1557,1571]
===
match
---
atom_expr [3848,3857]
atom_expr [3848,3857]
===
match
---
atom_expr [9428,9453]
atom_expr [9403,9428]
===
match
---
import_as_names [963,1009]
import_as_names [963,1009]
===
match
---
global_stmt [11414,11453]
global_stmt [11389,11428]
===
match
---
not_test [4758,4770]
not_test [4758,4770]
===
match
---
trailer [12250,12260]
trailer [12225,12235]
===
match
---
atom_expr [1902,1911]
atom_expr [1902,1911]
===
match
---
funcdef [2835,2928]
funcdef [2835,2928]
===
match
---
operator: , [7366,7367]
operator: , [7366,7367]
===
match
---
operator: , [981,982]
operator: , [981,982]
===
match
---
annassign [1521,1556]
annassign [1521,1556]
===
match
---
expr_stmt [8565,8599]
expr_stmt [8540,8574]
===
match
---
trailer [6365,6384]
trailer [6365,6384]
===
match
---
atom [4017,4019]
atom [4017,4019]
===
match
---
name: plugin_instance [5958,5973]
name: plugin_instance [5958,5973]
===
match
---
name: Optional [995,1003]
name: Optional [995,1003]
===
match
---
suite [2860,2928]
suite [2860,2928]
===
match
---
suite [12628,12644]
suite [12603,12619]
===
match
---
simple_stmt [1370,1405]
simple_stmt [1370,1405]
===
match
---
decorated [4663,4842]
decorated [4663,4842]
===
match
---
simple_stmt [11414,11454]
simple_stmt [11389,11429]
===
match
---
name: log [7123,7126]
name: log [7123,7126]
===
match
---
comparison [9728,9742]
comparison [9703,9717]
===
match
---
simple_stmt [2764,2830]
simple_stmt [2764,2830]
===
match
---
operator: { [1402,1403]
operator: { [1402,1403]
===
match
---
name: EntryPointSource [6674,6690]
name: EntryPointSource [6674,6690]
===
match
---
suite [3294,3415]
suite [3294,3415]
===
match
---
for_stmt [6318,6947]
for_stmt [6318,6947]
===
match
---
annassign [1996,2024]
annassign [1996,2024]
===
match
---
param [4693,4696]
param [4693,4696]
===
match
---
atom_expr [12908,12953]
atom_expr [12883,12928]
===
match
---
name: Any [1851,1854]
name: Any [1851,1854]
===
match
---
name: mod [7651,7654]
name: mod [7651,7654]
===
match
---
not_test [14705,14722]
not_test [14680,14697]
===
match
---
simple_stmt [6722,6755]
simple_stmt [6722,6755]
===
match
---
atom_expr [9752,9831]
atom_expr [9727,9806]
===
match
---
simple_stmt [1153,1215]
simple_stmt [1153,1215]
===
match
---
name: cls [4876,4879]
name: cls [4876,4879]
===
match
---
simple_stmt [895,910]
simple_stmt [895,910]
===
match
---
name: importlib [7512,7521]
name: importlib [7512,7521]
===
match
---
import_from [1215,1270]
import_from [1215,1270]
===
match
---
name: debug [7127,7132]
name: debug [7127,7132]
===
match
---
name: version [3350,3357]
name: version [3350,3357]
===
match
---
name: executors_module [13195,13211]
name: executors_module [13170,13186]
===
match
---
global_stmt [10037,10071]
global_stmt [10012,10046]
===
match
---
annassign [1891,1919]
annassign [1891,1919]
===
match
---
name: menu_links [10892,10902]
name: menu_links [10867,10877]
===
match
---
expr_stmt [1406,1420]
expr_stmt [1406,1420]
===
match
---
operator: = [10526,10527]
operator: = [10501,10502]
===
match
---
param [3432,3436]
param [3432,3436]
===
match
---
operator: , [7266,7267]
operator: , [7266,7267]
===
match
---
simple_stmt [10440,10462]
simple_stmt [10415,10437]
===
match
---
atom_expr [1958,1967]
atom_expr [1958,1967]
===
match
---
trailer [12875,12880]
trailer [12850,12855]
===
match
---
name: module [8529,8535]
name: module [8504,8510]
===
match
---
name: registered_hooks [9352,9368]
name: registered_hooks [9327,9343]
===
match
---
simple_stmt [11793,11847]
simple_stmt [11768,11822]
===
match
---
name: timer [9305,9310]
name: timer [9280,9285]
===
match
---
suite [11727,11788]
suite [11702,11763]
===
match
---
simple_stmt [12763,12803]
simple_stmt [12738,12778]
===
match
---
fstring_expr [12245,12270]
fstring_expr [12220,12245]
===
match
---
if_stmt [13095,13270]
if_stmt [13070,13245]
===
match
---
not_test [9172,9199]
not_test [9147,9174]
===
match
---
name: PLUGINS_FOLDER [7180,7194]
name: PLUGINS_FOLDER [7180,7194]
===
match
---
operator: , [11123,11124]
operator: , [11098,11099]
===
match
---
name: file_path [8284,8293]
name: file_path [8259,8268]
===
match
---
tfpdef [14322,14356]
tfpdef [14297,14331]
===
match
---
atom_expr [14559,14587]
atom_expr [14534,14562]
===
match
---
name: source [3792,3798]
name: source [3792,3798]
===
match
---
atom_expr [10597,10620]
atom_expr [10572,10595]
===
match
---
operator: = [1550,1551]
operator: = [1550,1551]
===
match
---
simple_stmt [1774,1813]
simple_stmt [1774,1813]
===
match
---
string: "Loading plugins from directory: %s" [7133,7169]
string: "Loading plugins from directory: %s" [7133,7169]
===
match
---
trailer [3882,3887]
trailer [3882,3887]
===
match
---
atom [10528,10530]
atom [10503,10505]
===
match
---
simple_stmt [6904,6947]
simple_stmt [6904,6947]
===
match
---
operator: @ [4847,4848]
operator: @ [4847,4848]
===
match
---
atom [4420,4422]
atom [4420,4422]
===
match
---
string: 'Creating module %s' [8473,8493]
string: 'Creating module %s' [8448,8468]
===
match
---
annassign [3765,3787]
annassign [3765,3787]
===
match
---
trailer [7420,7424]
trailer [7420,7424]
===
match
---
name: appbuilder_menu_items [10672,10693]
name: appbuilder_menu_items [10647,10668]
===
match
---
name: Optional [3767,3775]
name: Optional [3767,3775]
===
match
---
name: mod_attr_value [7852,7866]
name: mod_attr_value [7852,7866]
===
match
---
name: flask_appbuilder_views [10010,10032]
name: flask_appbuilder_views [9985,10007]
===
match
---
operator: = [13222,13223]
operator: = [13197,13198]
===
match
---
simple_stmt [9331,9344]
simple_stmt [9306,9319]
===
match
---
name: kwargs [4890,4896]
name: kwargs [4890,4896]
===
match
---
name: importlib [7589,7598]
name: importlib [7589,7598]
===
match
---
trailer [7316,7327]
trailer [7316,7327]
===
match
---
name: validate [4684,4692]
name: validate [4684,4692]
===
match
---
name: List [1582,1586]
name: List [1582,1586]
===
match
---
string: """     Load plugins from plugins directory and entrypoints.      Plugins are only loaded if they have not been previously loaded.     """ [8812,8950]
string: """     Load plugins from plugins directory and entrypoints.      Plugins are only loaded if they have not been previously loaded.     """ [8787,8925]
===
match
---
operator: = [8295,8296]
operator: = [8270,8271]
===
match
---
operator: - [7421,7422]
operator: - [7421,7422]
===
match
---
name: List [1795,1799]
name: List [1795,1799]
===
match
---
import_name [920,930]
import_name [920,930]
===
match
---
atom_expr [7784,7834]
atom_expr [7784,7834]
===
match
---
atom [5492,5631]
atom [5492,5631]
===
match
---
parameters [2944,2950]
parameters [2944,2950]
===
match
---
global_stmt [5903,5917]
global_stmt [5903,5917]
===
match
---
name: self [3206,3210]
name: self [3206,3210]
===
match
---
simple_stmt [6057,6201]
simple_stmt [6057,6201]
===
match
---
name: num_loaded [9804,9814]
name: num_loaded [9779,9789]
===
match
---
operator: = [4653,4654]
operator: = [4653,4654]
===
match
---
name: relpath [2889,2896]
name: relpath [2889,2896]
===
match
---
sync_comp_for [14932,14954]
sync_comp_for [14907,14929]
===
match
---
name: debug [12767,12772]
name: debug [12742,12747]
===
match
---
simple_stmt [13128,13171]
simple_stmt [13103,13146]
===
match
---
name: entrypoint [3386,3396]
name: entrypoint [3386,3396]
===
match
---
simple_stmt [14655,14698]
simple_stmt [14630,14673]
===
match
---
trailer [6917,6937]
trailer [6917,6937]
===
match
---
annassign [3972,3988]
annassign [3972,3988]
===
match
---
comp_op [13524,13530]
comp_op [13499,13505]
===
match
---
name: Optional [1786,1794]
name: Optional [1786,1794]
===
match
---
name: self [3564,3568]
name: self [3564,3568]
===
match
---
annassign [3935,3951]
annassign [3935,3951]
===
match
---
tfpdef [3212,3253]
tfpdef [3212,3253]
===
match
---
name: classmethod [4848,4859]
name: classmethod [4848,4859]
===
match
---
funcdef [5723,6020]
funcdef [5723,6020]
===
match
---
operator: = [8018,8019]
operator: = [8018,8019]
===
match
---
name: __class__ [12223,12232]
name: __class__ [12198,12207]
===
match
---
name: Dict [2068,2072]
name: Dict [2068,2072]
===
match
---
name: file_path [8043,8052]
name: file_path [8043,8052]
===
match
---
name: plugin [12028,12034]
name: plugin [12003,12009]
===
match
---
for_stmt [13736,14300]
for_stmt [13711,14275]
===
match
---
string: "Plugins are already loaded. Skipping." [9108,9147]
string: "Plugins are already loaded. Skipping." [9083,9122]
===
match
---
atom [3860,3862]
atom [3860,3862]
===
match
---
annassign [1571,1599]
annassign [1571,1599]
===
match
---
parameters [4692,4697]
parameters [4692,4697]
===
match
---
expr_stmt [13002,13086]
expr_stmt [12977,13061]
===
match
---
name: __name__ [13212,13220]
name: __name__ [13187,13195]
===
match
---
name: entrypoint [3403,3413]
name: entrypoint [3403,3413]
===
match
---
annassign [4641,4657]
annassign [4641,4657]
===
match
---
arglist [7621,7637]
arglist [7621,7637]
===
match
---
trailer [13776,13781]
trailer [13751,13756]
===
match
---
name: ImportError [1053,1064]
name: ImportError [1053,1064]
===
match
---
trailer [9310,9312]
trailer [9285,9287]
===
match
---
simple_stmt [12706,12758]
simple_stmt [12681,12733]
===
match
---
operator: = [12826,12827]
operator: = [12801,12802]
===
match
---
return_stmt [3447,3503]
return_stmt [3447,3503]
===
match
---
atom [13728,13730]
atom [13703,13705]
===
match
---
simple_stmt [10037,10072]
simple_stmt [10012,10047]
===
match
---
name: appbuilder_views [10604,10620]
name: appbuilder_views [10579,10595]
===
match
---
name: spec [7689,7693]
name: spec [7689,7693]
===
match
---
arglist [7794,7833]
arglist [7794,7833]
===
match
---
name: airflow [1299,1306]
name: airflow [1299,1306]
===
match
---
atom_expr [4408,4417]
atom_expr [4408,4417]
===
match
---
simple_stmt [4061,4099]
simple_stmt [4061,4099]
===
match
---
simple_stmt [13316,13348]
simple_stmt [13291,13323]
===
match
---
operator: { [13909,13910]
operator: { [13884,13885]
===
match
---
name: file_ext [7437,7445]
name: file_ext [7437,7445]
===
match
---
name: Any [1800,1803]
name: Any [1800,1803]
===
match
---
suite [11217,12368]
suite [11192,12343]
===
match
---
name: name [8495,8499]
name: name [8470,8474]
===
match
---
name: importlib [1075,1084]
name: importlib [1075,1084]
===
match
---
simple_stmt [880,895]
simple_stmt [880,895]
===
match
---
atom_expr [14655,14697]
atom_expr [14630,14672]
===
match
---
operator: = [3781,3782]
operator: = [3781,3782]
===
match
---
trailer [4812,4841]
trailer [4812,4841]
===
match
---
suite [2534,2707]
suite [2534,2707]
===
match
---
trailer [12104,12133]
trailer [12079,12108]
===
match
---
name: __name__ [1359,1367]
name: __name__ [1359,1367]
===
match
---
raise_stmt [10340,10391]
raise_stmt [10315,10366]
===
match
---
atom [10727,10801]
atom [10702,10776]
===
match
---
atom_expr [12649,12672]
atom_expr [12624,12647]
===
match
---
operator: = [6495,6496]
operator: = [6495,6496]
===
match
---
name: hooks [3841,3846]
name: hooks [3841,3846]
===
match
---
operator: = [3858,3859]
operator: = [3858,3859]
===
match
---
atom_expr [10703,10802]
atom_expr [10678,10777]
===
match
---
string: "Invalid plugin name" [13832,13853]
string: "Invalid plugin name" [13807,13828]
===
match
---
name: self [2607,2611]
name: self [2607,2611]
===
match
---
if_stmt [4755,4842]
if_stmt [4755,4842]
===
match
---
name: plugins_info [14969,14981]
name: plugins_info [14944,14956]
===
match
---
name: Distribution [3280,3292]
name: Distribution [3280,3292]
===
match
---
fstring [3038,3077]
fstring [3038,3077]
===
match
---
name: m [7923,7924]
name: m [7923,7924]
===
match
---
simple_stmt [7784,7835]
simple_stmt [7784,7835]
===
match
---
trailer [12260,12269]
trailer [12235,12244]
===
match
---
name: __str__ [2937,2944]
name: __str__ [2937,2944]
===
match
---
simple_stmt [13557,13581]
simple_stmt [13532,13556]
===
match
---
name: PLUGINS_FOLDER [7252,7266]
name: PLUGINS_FOLDER [7252,7266]
===
match
---
operator: = [14746,14747]
operator: = [14721,14722]
===
match
---
name: plugin_instance [8086,8101]
name: plugin_instance [8086,8101]
===
match
---
simple_stmt [6649,6710]
simple_stmt [6649,6710]
===
match
---
simple_stmt [10466,10494]
simple_stmt [10441,10469]
===
match
---
trailer [14981,14988]
trailer [14956,14963]
===
match
---
name: AirflowPluginSource [3103,3122]
name: AirflowPluginSource [3103,3122]
===
match
---
trailer [11764,11787]
trailer [11739,11762]
===
match
---
trailer [14000,14015]
trailer [13975,13990]
===
match
---
comparison [5593,5624]
comparison [5593,5624]
===
match
---
suite [12697,12758]
suite [12672,12733]
===
match
---
atom_expr [7512,7569]
atom_expr [7512,7569]
===
match
---
simple_stmt [1335,1369]
simple_stmt [1335,1369]
===
match
---
raise_stmt [2681,2706]
raise_stmt [2681,2706]
===
match
---
operator: = [6620,6621]
operator: = [6620,6621]
===
match
---
name: plugins [14835,14842]
name: plugins [14810,14817]
===
match
---
name: mod [7882,7885]
name: mod [7882,7885]
===
match
---
atom_expr [5641,5662]
atom_expr [5641,5662]
===
match
---
name: bp [10763,10765]
name: bp [10738,10740]
===
match
---
operator: -> [14365,14367]
operator: -> [14340,14342]
===
match
---
name: ensure_plugins_loaded [12649,12670]
name: ensure_plugins_loaded [12624,12645]
===
match
---
trailer [8085,8102]
trailer [8085,8102]
===
match
---
string: "Initialize Web UI plugin" [10407,10433]
string: "Initialize Web UI plugin" [10382,10408]
===
match
---
name: plugins [12681,12688]
name: plugins [12656,12663]
===
match
---
trailer [3852,3857]
trailer [3852,3857]
===
match
---
name: plugins [11976,11983]
name: plugins [11951,11958]
===
match
---
name: menu_links [3993,4003]
name: menu_links [3993,4003]
===
match
---
expr_stmt [1689,1728]
expr_stmt [1689,1728]
===
match
---
simple_stmt [12416,12465]
simple_stmt [12391,12440]
===
match
---
name: name [13917,13921]
name: name [13892,13896]
===
match
---
if_stmt [6528,6591]
if_stmt [6528,6591]
===
match
---
simple_stmt [1689,1729]
simple_stmt [1689,1729]
===
match
---
name: dist [3255,3259]
name: dist [3255,3259]
===
match
---
trailer [10974,11167]
trailer [10949,11142]
===
match
---
simple_stmt [8070,8103]
simple_stmt [8070,8103]
===
match
---
name: global_operator_extra_links [11350,11377]
name: global_operator_extra_links [11325,11352]
===
match
---
name: Optional [1998,2006]
name: Optional [1998,2006]
===
match
---
name: debug [8467,8472]
name: debug [8442,8447]
===
match
---
atom_expr [9176,9199]
atom_expr [9151,9174]
===
match
---
operator: } [12269,12270]
operator: } [12244,12245]
===
match
---
trailer [8691,8700]
trailer [8666,8675]
===
match
---
name: loader [7748,7754]
name: loader [7748,7754]
===
match
---
name: util [7667,7671]
name: util [7667,7671]
===
match
---
name: global_operator_extra_links [4379,4406]
name: global_operator_extra_links [4379,4406]
===
match
---
trailer [6843,6891]
trailer [6843,6891]
===
match
---
trailer [10304,10306]
trailer [10279,10281]
===
match
---
atom_expr [13770,13781]
atom_expr [13745,13756]
===
match
---
suite [13536,13552]
suite [13511,13527]
===
match
---
atom_expr [7243,7266]
atom_expr [7243,7266]
===
match
---
suite [6385,6947]
suite [6385,6947]
===
match
---
expr_stmt [4024,4056]
expr_stmt [4024,4056]
===
match
---
name: macros_modules [13417,13431]
name: macros_modules [13392,13406]
===
match
---
name: operator_extra_links [12323,12343]
name: operator_extra_links [12298,12318]
===
match
---
simple_stmt [14969,14995]
simple_stmt [14944,14970]
===
match
---
trailer [1794,1805]
trailer [1794,1805]
===
match
---
trailer [7179,7194]
trailer [7179,7194]
===
match
---
arglist [8473,8499]
arglist [8448,8474]
===
match
---
operator: = [2302,2303]
operator: = [2302,2303]
===
match
---
trailer [9263,9269]
trailer [9238,9244]
===
match
---
parameters [2847,2859]
parameters [2847,2859]
===
match
---
trailer [8584,8590]
trailer [8559,8565]
===
match
---
name: self [2986,2990]
name: self [2986,2990]
===
match
---
operator: } [3482,3483]
operator: } [3482,3483]
===
match
---
name: self [3016,3020]
name: self [3016,3020]
===
match
---
name: executors_modules [12534,12551]
name: executors_modules [12509,12526]
===
match
---
name: name [8512,8516]
name: name [8487,8491]
===
match
---
simple_stmt [5671,5704]
simple_stmt [5671,5704]
===
match
---
trailer [1348,1358]
trailer [1348,1358]
===
match
---
trailer [6833,6843]
trailer [6833,6843]
===
match
---
arglist [14921,14930]
arglist [14896,14905]
===
match
---
atom_expr [3457,3466]
atom_expr [3457,3466]
===
match
---
atom_expr [5988,6019]
atom_expr [5988,6019]
===
match
---
string: 'name' [3329,3335]
string: 'name' [3329,3335]
===
match
---
name: dist [6704,6708]
name: dist [6704,6708]
===
match
---
atom [14794,14796]
atom [14769,14771]
===
match
---
trailer [14920,14931]
trailer [14895,14906]
===
match
---
atom [8689,8704]
atom [8664,8679]
===
match
---
comp_op [10192,10198]
comp_op [10167,10173]
===
match
---
name: log [6394,6397]
name: log [6394,6397]
===
match
---
trailer [6508,6513]
trailer [6508,6513]
===
match
---
name: plugin [11141,11147]
name: plugin [11116,11122]
===
match
---
name: append [13994,14000]
name: append [13969,13975]
===
match
---
expr_stmt [1729,1773]
expr_stmt [1729,1773]
===
match
---
trailer [6002,6019]
trailer [6002,6019]
===
match
---
name: Optional [1702,1710]
name: Optional [1702,1710]
===
match
---
simple_stmt [4379,4423]
simple_stmt [4379,4423]
===
match
---
for_stmt [7848,8103]
for_stmt [7848,8103]
===
match
---
name: macros_module [14285,14298]
name: macros_module [14260,14273]
===
match
---
trailer [13211,13220]
trailer [13186,13195]
===
match
---
name: flask_blueprints [10784,10800]
name: flask_blueprints [10759,10775]
===
match
---
name: Any [4413,4416]
name: Any [4413,4416]
===
match
---
name: plugin_obj [5553,5563]
name: plugin_obj [5553,5563]
===
match
---
param [3016,3020]
param [3016,3020]
===
match
---
name: flask_appbuilder_menu_links [10498,10525]
name: flask_appbuilder_menu_links [10473,10500]
===
match
---
name: link [12218,12222]
name: link [12193,12197]
===
match
---
string: '.py' [7449,7454]
string: '.py' [7449,7454]
===
match
---
suite [8388,8741]
suite [8363,8716]
===
match
---
name: List [989,993]
name: List [989,993]
===
match
---
classdef [3080,3603]
classdef [3080,3603]
===
match
---
trailer [9675,9689]
trailer [9650,9664]
===
match
---
for_stmt [14821,14995]
for_stmt [14796,14970]
===
match
---
comp_if [7904,7925]
comp_if [7904,7925]
===
match
---
raise_stmt [12902,12953]
raise_stmt [12877,12928]
===
match
---
name: mod_name [7549,7557]
name: mod_name [7549,7557]
===
match
---
trailer [12277,12287]
trailer [12252,12262]
===
match
---
name: plugin [13069,13075]
name: plugin [13044,13050]
===
match
---
atom_expr [3800,3829]
atom_expr [3800,3829]
===
match
---
name: objects [8368,8375]
name: objects [8343,8350]
===
match
---
operator: , [8245,8246]
operator: , [8220,8221]
===
match
---
operator: , [2460,2461]
operator: , [2460,2461]
===
match
---
name: bp [10771,10773]
name: bp [10746,10748]
===
match
---
fstring [13892,13923]
fstring [13867,13898]
===
match
---
operator: { [3550,3551]
operator: { [3550,3551]
===
match
---
param [2945,2949]
param [2945,2949]
===
match
---
trailer [3319,3328]
trailer [3319,3328]
===
match
---
atom [3890,3892]
atom [3890,3892]
===
match
---
expr_stmt [7503,7569]
expr_stmt [7503,7569]
===
match
---
trailer [13152,13170]
trailer [13127,13145]
===
match
---
fstring_expr [3584,3601]
fstring_expr [3584,3601]
===
match
---
name: executors [3867,3876]
name: executors [3867,3876]
===
match
---
simple_stmt [11667,11674]
simple_stmt [11642,11649]
===
match
---
atom_expr [2068,2083]
atom_expr [2068,2083]
===
match
---
fstring_expr [13909,13922]
fstring_expr [13884,13897]
===
match
---
not_test [10839,10866]
not_test [10814,10841]
===
match
---
name: self [3470,3474]
name: self [3470,3474]
===
match
---
name: len [9708,9711]
name: len [9683,9686]
===
match
---
annassign [2057,2091]
annassign [2057,2091]
===
match
---
name: plugin [13910,13916]
name: plugin [13885,13891]
===
match
---
trailer [4412,4417]
trailer [4412,4417]
===
match
---
trailer [14350,14355]
trailer [14325,14330]
===
match
---
operator: , [976,977]
operator: , [976,977]
===
match
---
string: "executors" [2323,2334]
string: "executors" [2323,2334]
===
match
---
simple_stmt [10397,10435]
simple_stmt [10372,10410]
===
match
---
name: macros_module [14001,14014]
name: macros_module [13976,13989]
===
match
---
name: self [2848,2852]
name: self [2848,2852]
===
match
---
import_name [880,894]
import_name [880,894]
===
match
---
atom_expr [9215,9254]
atom_expr [9190,9229]
===
match
---
name: str [8363,8366]
name: str [8338,8341]
===
match
---
atom_expr [6940,6946]
atom_expr [6940,6946]
===
match
---
name: spec_from_loader [7604,7620]
name: spec_from_loader [7604,7620]
===
match
---
suite [5188,5721]
suite [5188,5721]
===
match
---
name: Any [1587,1590]
name: Any [1587,1590]
===
match
---
name: name [13777,13781]
name: name [13752,13756]
===
match
---
atom [4054,4056]
atom [4054,4056]
===
match
---
trailer [1962,1967]
trailer [1962,1967]
===
match
---
param [8368,8386]
param [8343,8361]
===
match
---
atom_expr [11141,11152]
atom_expr [11116,11127]
===
match
---
argument [8689,8721]
argument [8664,8696]
===
match
---
expr_stmt [12808,12830]
expr_stmt [12783,12805]
===
match
---
name: List [3878,3882]
name: List [3878,3882]
===
match
---
if_stmt [13506,13552]
if_stmt [13481,13527]
===
match
---
atom_expr [13195,13220]
atom_expr [13170,13195]
===
match
---
name: log [9752,9755]
name: log [9727,9730]
===
match
---
global_stmt [11343,11377]
global_stmt [11318,11352]
===
match
---
expr_stmt [9331,9343]
expr_stmt [9306,9318]
===
match
---
operator: = [4052,4053]
operator: = [4052,4053]
===
match
---
name: hooks [1307,1312]
name: hooks [1307,1312]
===
match
---
string: 'Importing plugin module %s' [7794,7822]
string: 'Importing plugin module %s' [7794,7822]
===
match
---
string: """Class used to define Plugins loaded from Plugins Directory.""" [2764,2829]
string: """Class used to define Plugins loaded from Plugins Directory.""" [2764,2829]
===
match
---
name: PLUGINS_ATTRIBUTES_TO_DUMP [2275,2301]
name: PLUGINS_ATTRIBUTES_TO_DUMP [2275,2301]
===
match
---
name: self [3066,3070]
name: self [3066,3070]
===
match
---
if_stmt [13949,14300]
if_stmt [13924,14275]
===
match
---
name: __name__ [14054,14062]
name: __name__ [14029,14037]
===
match
---
trailer [13075,13085]
trailer [13050,13060]
===
match
---
name: List [3905,3909]
name: List [3905,3909]
===
match
---
parameters [3521,3527]
parameters [3521,3527]
===
match
---
import_from [8955,8986]
import_from [8930,8961]
===
match
---
import_name [814,830]
import_name [814,830]
===
match
---
operator: = [13878,13879]
operator: = [13853,13854]
===
match
---
string: "flask_blueprints" [2354,2372]
string: "flask_blueprints" [2354,2372]
===
match
---
name: str [14351,14354]
name: str [14326,14329]
===
match
---
string: "Initialize extra operators links plugins" [11803,11845]
string: "Initialize extra operators links plugins" [11778,11820]
===
match
---
atom_expr [2869,2878]
atom_expr [2869,2878]
===
match
---
name: __class__ [12278,12287]
name: __class__ [12253,12262]
===
match
---
comparison [11562,11594]
comparison [11537,11569]
===
match
---
atom_expr [11679,11702]
atom_expr [11654,11677]
===
match
---
name: executors_modules [1600,1617]
name: executors_modules [1600,1617]
===
match
---
simple_stmt [8666,8723]
simple_stmt [8641,8698]
===
match
---
atom_expr [14373,14387]
atom_expr [14348,14362]
===
match
---
trailer [2067,2084]
trailer [2067,2084]
===
match
---
operator: , [2425,2426]
operator: , [2425,2426]
===
match
---
name: source [6665,6671]
name: source [6665,6671]
===
match
---
trailer [7403,7409]
trailer [7403,7409]
===
match
---
trailer [9101,9107]
trailer [9076,9082]
===
match
---
trailer [8472,8500]
trailer [8447,8475]
===
match
---
atom_expr [1998,2017]
atom_expr [1998,2017]
===
match
---
trailer [3978,3983]
trailer [3978,3983]
===
match
---
simple_stmt [8955,8987]
simple_stmt [8930,8962]
===
match
---
name: utils [1166,1171]
name: utils [1166,1171]
===
match
---
name: debug [9756,9761]
name: debug [9731,9736]
===
match
---
name: machinery [848,857]
name: machinery [848,857]
===
match
---
name: update [14902,14908]
name: update [14877,14883]
===
match
---
name: log [7784,7787]
name: log [7784,7787]
===
match
---
trailer [14053,14062]
trailer [14028,14037]
===
match
---
simple_stmt [10567,10622]
simple_stmt [10542,10597]
===
match
---
name: Any [1963,1966]
name: Any [1963,1966]
===
match
---
atom_expr [12100,12133]
atom_expr [12075,12108]
===
match
---
name: log [13671,13674]
name: log [13646,13649]
===
match
---
name: name [8357,8361]
name: name [8332,8336]
===
match
---
operator: = [7960,7961]
operator: = [7960,7961]
===
match
---
raise_stmt [13803,13854]
raise_stmt [13778,13829]
===
match
---
name: plugins [12849,12856]
name: plugins [12824,12831]
===
match
---
expr_stmt [3345,3372]
expr_stmt [3345,3372]
===
match
---
tfpdef [8368,8386]
tfpdef [8343,8361]
===
match
---
operator: = [8578,8579]
operator: = [8553,8554]
===
match
---
expr_stmt [3381,3414]
expr_stmt [3381,3414]
===
match
---
if_stmt [9169,9255]
if_stmt [9144,9230]
===
match
---
name: sys [7707,7710]
name: sys [7707,7710]
===
match
---
name: integrate_macros_plugins [13276,13300]
name: integrate_macros_plugins [13251,13275]
===
match
---
name: module [8620,8626]
name: module [8595,8601]
===
match
---
suite [9866,11168]
suite [9841,11143]
===
match
---
name: flask_appbuilder_menu_links [1864,1891]
name: flask_appbuilder_menu_links [1864,1891]
===
match
---
name: plugin_class [6622,6634]
name: plugin_class [6622,6634]
===
match
---
classdef [2508,2707]
classdef [2508,2707]
===
match
---
atom_expr [6904,6937]
atom_expr [6904,6937]
===
match
---
simple_stmt [14732,14775]
simple_stmt [14707,14750]
===
match
---
suite [12411,13270]
suite [12386,13245]
===
match
---
name: self [3381,3385]
name: self [3381,3385]
===
match
---
atom_expr [12218,12243]
atom_expr [12193,12218]
===
match
---
name: self [3432,3436]
name: self [3432,3436]
===
match
---
trailer [6450,6455]
trailer [6450,6455]
===
match
---
fstring_start: f" [12215,12217]
fstring_start: f" [12190,12192]
===
match
---
atom_expr [10911,10939]
atom_expr [10886,10914]
===
match
---
suite [1015,1046]
suite [1015,1046]
===
match
---
atom_expr [10885,10902]
atom_expr [10860,10877]
===
match
---
suite [5760,6020]
suite [5760,6020]
===
match
---
simple_stmt [944,1010]
simple_stmt [944,1010]
===
match
---
name: extend [10720,10726]
name: extend [10695,10701]
===
match
---
name: link [12273,12277]
name: link [12248,12252]
===
match
---
atom_expr [14897,14956]
atom_expr [14872,14931]
===
match
---
atom_expr [3767,3780]
atom_expr [3767,3780]
===
match
---
operator: { [2985,2986]
operator: { [2985,2986]
===
match
---
atom [11500,11657]
atom [11475,11632]
===
match
---
name: import_errors [6904,6917]
name: import_errors [6904,6917]
===
match
---
simple_stmt [13979,14016]
simple_stmt [13954,13991]
===
match
---
name: AirflowPluginException [10346,10368]
name: AirflowPluginException [10321,10343]
===
match
---
not_test [6531,6564]
not_test [6531,6564]
===
match
---
atom_expr [3564,3576]
atom_expr [3564,3576]
===
match
---
funcdef [6949,8304]
funcdef [6949,8279]
===
match
---
param [5743,5758]
param [5743,5758]
===
match
---
suite [13605,13666]
suite [13580,13641]
===
match
---
name: macros_modules [13979,13993]
name: macros_modules [13954,13968]
===
match
---
name: List [4643,4647]
name: List [4643,4647]
===
match
---
name: str [6940,6943]
name: str [6940,6943]
===
match
---
arglist [6404,6455]
arglist [6404,6455]
===
match
---
decorated [4847,5154]
decorated [4847,5154]
===
match
---
simple_stmt [10271,10278]
simple_stmt [10246,10253]
===
match
---
name: executors_module [13224,13240]
name: executors_module [13199,13215]
===
match
---
expr_stmt [3993,4019]
expr_stmt [3993,4019]
===
match
---
name: log [12763,12766]
name: log [12738,12741]
===
match
---
trailer [2011,2016]
trailer [2011,2016]
===
match
---
suite [8807,9832]
suite [8782,9807]
===
match
---
atom_expr [1628,1637]
atom_expr [1628,1637]
===
match
---
atom_expr [12105,12132]
atom_expr [12080,12107]
===
match
---
trailer [14695,14697]
trailer [14670,14672]
===
match
---
trailer [3385,3396]
trailer [3385,3396]
===
match
---
name: module_from_spec [7672,7688]
name: module_from_spec [7672,7688]
===
match
---
atom_expr [12763,12802]
atom_expr [12738,12777]
===
match
---
trailer [14648,14650]
trailer [14623,14625]
===
match
---
expr_stmt [12962,12992]
expr_stmt [12937,12967]
===
match
---
name: modules [14032,14039]
name: modules [14007,14014]
===
match
---
name: importlib [838,847]
name: importlib [838,847]
===
match
---
name: extend [12021,12027]
name: extend [11996,12002]
===
match
---
name: plugin [13740,13746]
name: plugin [13715,13721]
===
match
---
name: path [7399,7403]
name: path [7399,7403]
===
match
---
sync_comp_for [7873,7925]
sync_comp_for [7873,7925]
===
match
---
param [4881,4887]
param [4881,4887]
===
match
---
suite [12857,13270]
suite [12832,13245]
===
match
---
funcdef [4680,4842]
funcdef [4680,4842]
===
match
---
strings [10992,11123]
strings [10967,11098]
===
match
---
name: find_path_from_directory [1246,1270]
name: find_path_from_directory [1246,1270]
===
match
---
name: entry_points_with_dist [1192,1214]
name: entry_points_with_dist [1192,1214]
===
match
---
expr_stmt [1864,1919]
expr_stmt [1864,1919]
===
match
---
atom_expr [7962,7978]
atom_expr [7962,7978]
===
match
---
name: sys [14028,14031]
name: sys [14003,14006]
===
match
---
atom_expr [5542,5579]
atom_expr [5542,5579]
===
match
---
trailer [2990,2995]
trailer [2990,2995]
===
match
---
atom_expr [7171,7194]
atom_expr [7171,7194]
===
match
---
simple_stmt [6267,6313]
simple_stmt [6267,6313]
===
match
---
trailer [3349,3357]
trailer [3349,3357]
===
match
---
name: plugin [10665,10671]
name: plugin [10640,10646]
===
match
---
exprlist [6322,6339]
exprlist [6322,6339]
===
match
---
name: cls [4762,4765]
name: cls [4762,4765]
===
match
---
testlist_comp [10728,10800]
testlist_comp [10703,10775]
===
match
---
name: name [8505,8509]
name: name [8480,8484]
===
match
---
operator: , [3210,3211]
operator: , [3210,3211]
===
match
---
name: entry_point [6497,6508]
name: entry_point [6497,6508]
===
match
---
simple_stmt [9209,9255]
simple_stmt [9184,9230]
===
match
---
atom_expr [1786,1805]
atom_expr [1786,1805]
===
match
---
simple_stmt [10703,10803]
simple_stmt [10678,10778]
===
match
---
import_from [944,1009]
import_from [944,1009]
===
match
---
trailer [13145,13152]
trailer [13120,13127]
===
match
---
operator: } [3501,3502]
operator: } [3501,3502]
===
match
---
string: "Can't load plugins." [11765,11786]
string: "Can't load plugins." [11740,11761]
===
match
---
name: entry_point [6322,6333]
name: entry_point [6322,6333]
===
match
---
name: List [4005,4009]
name: List [4005,4009]
===
match
---
name: Any [978,981]
name: Any [978,981]
===
match
---
trailer [12232,12243]
trailer [12207,12218]
===
match
---
name: info [14897,14901]
name: info [14872,14876]
===
match
---
trailer [14988,14994]
trailer [14963,14969]
===
match
---
decorator [4663,4676]
decorator [4663,4676]
===
match
---
name: flask_blueprints [10703,10719]
name: flask_blueprints [10678,10694]
===
match
---
trailer [7531,7548]
trailer [7531,7548]
===
match
---
arglist [8217,8256]
arglist [8192,8231]
===
match
---
atom_expr [8070,8102]
atom_expr [8070,8102]
===
match
---
atom_expr [6439,6455]
atom_expr [6439,6455]
===
match
---
name: plugins_info [14779,14791]
name: plugins_info [14754,14766]
===
match
---
parameters [3205,3293]
parameters [3205,3293]
===
match
---
suite [4698,4842]
suite [4698,4842]
===
match
---
operator: = [1339,1340]
operator: = [1339,1340]
===
match
---
simple_stmt [831,858]
simple_stmt [831,858]
===
match
---
name: _name [8572,8577]
name: _name [8547,8552]
===
match
---
name: flask_appbuilder_views [10466,10488]
name: flask_appbuilder_views [10441,10463]
===
match
---
name: executors_module [13153,13169]
name: executors_module [13128,13144]
===
match
---
suite [9200,9255]
suite [9175,9230]
===
match
---
name: dist [3462,3466]
name: dist [3462,3466]
===
match
---
name: ensure_plugins_loaded [13557,13578]
name: ensure_plugins_loaded [13532,13553]
===
match
---
simple_stmt [2275,2506]
simple_stmt [2275,2506]
===
match
---
operator: , [1393,1394]
operator: , [1393,1394]
===
match
---
simple_stmt [1070,1123]
simple_stmt [1070,1123]
===
match
---
expr_stmt [7582,7638]
expr_stmt [7582,7638]
===
match
---
fstring_end: ' [13922,13923]
fstring_end: ' [13897,13898]
===
match
---
name: settings [1144,1152]
name: settings [1144,1152]
===
match
---
simple_stmt [11852,11885]
simple_stmt [11827,11860]
===
match
---
trailer [14585,14587]
trailer [14560,14562]
===
match
---
fstring_start: f" [2967,2969]
fstring_start: f" [2967,2969]
===
match
---
name: module [8666,8672]
name: module [8641,8647]
===
match
---
simple_stmt [10340,10392]
simple_stmt [10315,10367]
===
match
---
suite [9089,9164]
suite [9064,9139]
===
match
---
trailer [1799,1804]
trailer [1799,1804]
===
match
---
name: macros_module [13864,13877]
name: macros_module [13839,13852]
===
match
---
name: file_ext [7368,7376]
name: file_ext [7368,7376]
===
match
---
parameters [4875,4897]
parameters [4875,4897]
===
match
---
atom_expr [6267,6312]
atom_expr [6267,6312]
===
match
---
string: """Load and register Airflow Plugins from plugins directory""" [6995,7057]
string: """Load and register Airflow Plugins from plugins directory""" [6995,7057]
===
match
---
name: __class__ [12251,12260]
name: __class__ [12226,12235]
===
match
---
annassign [1617,1645]
annassign [1617,1645]
===
match
---
name: settings [9176,9184]
name: settings [9151,9159]
===
match
---
operator: , [8700,8701]
operator: , [8675,8676]
===
match
---
operator: } [3075,3076]
operator: } [3075,3076]
===
match
---
operator: = [14861,14862]
operator: = [14836,14837]
===
match
---
dotted_name [1299,1317]
dotted_name [1299,1317]
===
match
---
operator: , [8493,8494]
operator: , [8468,8469]
===
match
---
atom_expr [1619,1638]
atom_expr [1619,1638]
===
match
---
string: "Integrate DAG plugins" [13681,13704]
string: "Integrate DAG plugins" [13656,13679]
===
match
---
name: self [2945,2949]
name: self [2945,2949]
===
match
---
comp_op [11583,11589]
comp_op [11558,11564]
===
match
---
trailer [8300,8303]
trailer [8275,8278]
===
match
---
name: load_plugins_from_plugin_directory [6953,6987]
name: load_plugins_from_plugin_directory [6953,6987]
===
match
---
atom_expr [7218,7285]
atom_expr [7218,7285]
===
match
---
trailer [7304,7309]
trailer [7304,7309]
===
match
---
atom [2304,2505]
atom [2304,2505]
===
match
---
suite [4898,5154]
suite [4898,5154]
===
match
---
name: AirflowPluginException [3611,3633]
name: AirflowPluginException [3611,3633]
===
match
---
suite [14843,14995]
suite [14818,14970]
===
match
---
name: List [4408,4412]
name: List [4408,4412]
===
match
---
name: AirflowPluginException [4790,4812]
name: AirflowPluginException [4790,4812]
===
match
---
trailer [6634,6636]
trailer [6634,6636]
===
match
---
suite [13966,14300]
suite [13941,14275]
===
match
---
name: file_path [8247,8256]
name: file_path [8222,8231]
===
match
---
parameters [9863,9865]
parameters [9838,9840]
===
match
---
atom_expr [10283,10306]
atom_expr [10258,10281]
===
match
---
fstring [3454,3503]
fstring [3454,3503]
===
match
---
import_name [931,943]
import_name [931,943]
===
match
---
simple_stmt [11679,11703]
simple_stmt [11654,11678]
===
match
---
string: """     Dump plugins attributes      :param attrs_to_dump: A list of plugin attributes to dump     :type attrs_to_dump: List     """ [14394,14526]
string: """     Dump plugins attributes      :param attrs_to_dump: A list of plugin attributes to dump     :type attrs_to_dump: List     """ [14369,14501]
===
match
---
trailer [14263,14299]
trailer [14238,14274]
===
match
---
name: importlib_metadata [1027,1045]
name: importlib_metadata [1027,1045]
===
match
---
operator: = [2085,2086]
operator: = [2085,2086]
===
match
---
atom_expr [14368,14388]
atom_expr [14343,14363]
===
match
---
trailer [7521,7531]
trailer [7521,7531]
===
match
---
expr_stmt [6649,6709]
expr_stmt [6649,6709]
===
match
---
name: module [6930,6936]
name: module [6930,6936]
===
match
---
annassign [3903,3919]
annassign [3903,3919]
===
match
---
number: 1 [8597,8598]
number: 1 [8572,8573]
===
match
---
atom_expr [14346,14355]
atom_expr [14321,14330]
===
match
---
atom_expr [2986,2995]
atom_expr [2986,2995]
===
match
---
name: entry_point [6439,6450]
name: entry_point [6439,6450]
===
match
---
atom_expr [6722,6754]
atom_expr [6722,6754]
===
match
---
operator: { [3563,3564]
operator: { [3563,3564]
===
match
---
operator: , [9802,9803]
operator: , [9777,9778]
===
match
---
name: is_valid_plugin [5160,5175]
name: is_valid_plugin [5160,5175]
===
match
---
dictorsetmaker [12215,12343]
dictorsetmaker [12190,12318]
===
match
---
atom_expr [6497,6515]
atom_expr [6497,6515]
===
match
---
atom_expr [6622,6636]
atom_expr [6622,6636]
===
match
---
trailer [12020,12027]
trailer [11995,12002]
===
match
---
name: SourceFileLoader [7532,7548]
name: SourceFileLoader [7532,7548]
===
match
---
name: operator_extra_links [1976,1996]
name: operator_extra_links [1976,1996]
===
match
---
param [3212,3254]
param [3212,3254]
===
match
---
expr_stmt [7707,7735]
expr_stmt [7707,7735]
===
match
---
name: plugins [9069,9076]
name: plugins [9044,9051]
===
match
---
annassign [1383,1404]
annassign [1383,1404]
===
match
---
trailer [10671,10693]
trailer [10646,10668]
===
match
---
name: cls [4693,4696]
name: cls [4693,4696]
===
match
---
suite [11658,11674]
suite [11633,11649]
===
match
---
trailer [11700,11702]
trailer [11675,11677]
===
match
---
name: get_plugin_info [14306,14321]
name: get_plugin_info [14281,14296]
===
match
---
name: plugins [10315,10322]
name: plugins [10290,10297]
===
match
---
dictorsetmaker [2310,2503]
dictorsetmaker [2310,2503]
===
match
---
atom [3949,3951]
atom [3949,3951]
===
match
---
operator: , [2076,2077]
operator: , [2076,2077]
===
match
---
name: file_path [7559,7568]
name: file_path [7559,7568]
===
match
---
name: logging [902,909]
name: logging [902,909]
===
match
---
trailer [13194,13221]
trailer [13169,13196]
===
match
---
suite [6817,6947]
suite [6817,6947]
===
match
---
name: TYPE_CHECKING [963,976]
name: TYPE_CHECKING [963,976]
===
match
---
expr_stmt [6604,6636]
expr_stmt [6604,6636]
===
match
---
name: List [3937,3941]
name: List [3937,3941]
===
match
---
name: types [8538,8543]
name: types [8513,8518]
===
match
---
simple_stmt [8620,8662]
simple_stmt [8595,8637]
===
match
---
name: initialize_extra_operators_links_plugins [14655,14695]
name: initialize_extra_operators_links_plugins [14630,14670]
===
match
---
simple_stmt [920,931]
simple_stmt [920,931]
===
match
---
trailer [7242,7285]
trailer [7242,7285]
===
match
---
trailer [2072,2083]
trailer [2072,2083]
===
match
---
atom_expr [3399,3414]
atom_expr [3399,3414]
===
match
---
name: macros [13494,13500]
name: macros [13469,13475]
===
match
---
parameters [5742,5759]
parameters [5742,5759]
===
match
---
name: registered_hooks [1505,1521]
name: registered_hooks [1505,1521]
===
match
---
name: settings [7171,7179]
name: settings [7171,7179]
===
match
---
atom_expr [13128,13170]
atom_expr [13103,13145]
===
match
---
atom_expr [8463,8500]
atom_expr [8438,8475]
===
match
---
suite [4771,4842]
suite [4771,4842]
===
match
---
name: log [6830,6833]
name: log [6830,6833]
===
match
---
name: __html__ [3513,3521]
name: __html__ [3513,3521]
===
match
---
trailer [12183,12367]
trailer [12158,12342]
===
match
---
trailer [12772,12802]
trailer [12747,12777]
===
match
---
name: inspect [5502,5509]
name: inspect [5502,5509]
===
match
---
trailer [8283,8294]
trailer [8258,8269]
===
match
---
suite [10950,11168]
suite [10925,11143]
===
match
---
simple_stmt [12962,12993]
simple_stmt [12937,12968]
===
match
---
trailer [2896,2927]
trailer [2896,2927]
===
match
---
atom_expr [7379,7425]
atom_expr [7379,7425]
===
match
---
name: exception [6834,6843]
name: exception [6834,6843]
===
match
---
atom_expr [6874,6890]
atom_expr [6874,6890]
===
match
---
simple_stmt [2539,2590]
simple_stmt [2539,2590]
===
match
---
name: AirflowPluginException [12712,12734]
name: AirflowPluginException [12687,12709]
===
match
---
operator: ** [4888,4890]
operator: ** [4888,4890]
===
match
---
trailer [1715,1720]
trailer [1715,1720]
===
match
---
classdef [2709,3078]
classdef [2709,3078]
===
match
---
global_stmt [12508,12522]
global_stmt [12483,12497]
===
match
---
name: integrate_executor_plugins [14559,14585]
name: integrate_executor_plugins [14534,14560]
===
match
---
simple_stmt [14559,14588]
simple_stmt [14534,14563]
===
match
---
name: plugin [10777,10783]
name: plugin [10752,10758]
===
match
---
name: registered_operator_link_classes [12144,12176]
name: registered_operator_link_classes [12119,12151]
===
match
---
name: attrs_to_dump [14322,14335]
name: attrs_to_dump [14297,14310]
===
match
---
fstring [2967,2997]
fstring [2967,2997]
===
match
---
simple_stmt [9956,9971]
simple_stmt [9931,9946]
===
match
---
name: classmethod [4664,4675]
name: classmethod [4664,4675]
===
match
---
string: """Collect extension points for WEB UI""" [9871,9912]
string: """Collect extension points for WEB UI""" [9846,9887]
===
match
---
name: metadata [3320,3328]
name: metadata [3320,3328]
===
match
---
name: Optional [1837,1845]
name: Optional [1837,1845]
===
match
---
name: List [8377,8381]
name: List [8352,8356]
===
match
---
name: file_path [7317,7326]
name: file_path [7317,7326]
===
match
---
expr_stmt [3841,3862]
expr_stmt [3841,3862]
===
match
---
funcdef [11170,12368]
funcdef [11145,12343]
===
match
---
trailer [7718,7729]
trailer [7718,7729]
===
match
---
suite [1065,1123]
suite [1065,1123]
===
match
---
operator: , [7629,7630]
operator: , [7629,7630]
===
match
---
operator: , [6702,6703]
operator: , [6702,6703]
===
match
---
operator: , [2852,2853]
operator: , [2852,2853]
===
match
---
operator: { [14909,14910]
operator: { [14884,14885]
===
match
---
name: menu_links [1774,1784]
name: menu_links [1774,1784]
===
match
---
tfpdef [8357,8366]
tfpdef [8332,8341]
===
match
---
atom_expr [6535,6564]
atom_expr [6535,6564]
===
match
---
operator: , [6333,6334]
operator: , [6333,6334]
===
match
---
parameters [14321,14364]
parameters [14296,14339]
===
match
---
comparison [9069,9088]
comparison [9044,9063]
===
match
---
trailer [3307,3312]
trailer [3307,3312]
===
match
---
fstring_expr [3456,3467]
fstring_expr [3456,3467]
===
match
---
number: 0 [9741,9742]
number: 0 [9716,9717]
===
match
---
for_stmt [9617,9690]
for_stmt [9592,9665]
===
match
---
atom [3917,3919]
atom [3917,3919]
===
match
---
simple_stmt [11382,11410]
simple_stmt [11357,11385]
===
match
---
name: plugin [12981,12987]
name: plugin [12956,12962]
===
match
---
atom_expr [3974,3983]
atom_expr [3974,3983]
===
match
---
name: utils [1228,1233]
name: utils [1228,1233]
===
match
---
arglist [2897,2926]
arglist [2897,2926]
===
match
---
trailer [10400,10406]
trailer [10375,10381]
===
match
---
trailer [10849,10866]
trailer [10824,10841]
===
match
---
comp_op [11538,11544]
comp_op [11513,11519]
===
match
---
name: name [8580,8584]
name: name [8555,8559]
===
match
---
simple_stmt [10003,10033]
simple_stmt [9978,10008]
===
match
---
atom [11882,11884]
atom [11857,11859]
===
match
---
name: __dict__ [7886,7894]
name: __dict__ [7886,7894]
===
match
---
atom_expr [3303,3312]
atom_expr [3303,3312]
===
match
---
name: e [6783,6784]
name: e [6783,6784]
===
match
---
name: str [3776,3779]
name: str [3776,3779]
===
match
---
trailer [4765,4770]
trailer [4765,4770]
===
match
---
atom_expr [13671,13705]
atom_expr [13646,13680]
===
match
---
name: executors_modules [12808,12825]
name: executors_modules [12783,12800]
===
match
---
atom [3986,3988]
atom [3986,3988]
===
match
---
name: split [8585,8590]
name: split [8560,8565]
===
match
---
operator: , [13067,13068]
operator: , [13042,13043]
===
match
---
trailer [6513,6515]
trailer [6513,6515]
===
match
---
name: name [10744,10748]
name: name [10719,10723]
===
match
---
atom_expr [12273,12287]
atom_expr [12248,12262]
===
match
---
atom_expr [3486,3501]
atom_expr [3486,3501]
===
match
---
atom_expr [10816,10834]
atom_expr [10791,10809]
===
match
---
name: AirflowPlugin [5611,5624]
name: AirflowPlugin [5611,5624]
===
match
---
string: "appbuilder_views" [2378,2396]
string: "appbuilder_views" [2378,2396]
===
match
---
atom_expr [12712,12757]
atom_expr [12687,12732]
===
match
---
atom [1402,1404]
atom [1402,1404]
===
match
---
name: operator_extra_links [12072,12092]
name: operator_extra_links [12047,12067]
===
match
---
fstring_string: :  [3483,3485]
fstring_string: :  [3483,3485]
===
match
---
name: executors_module [13098,13114]
name: executors_module [13073,13089]
===
match
---
simple_stmt [3381,3415]
simple_stmt [3381,3415]
===
match
---
fstring_string: <em> [3546,3550]
fstring_string: <em> [3546,3550]
===
match
---
atom_expr [11742,11787]
atom_expr [11717,11762]
===
match
---
atom_expr [4762,4770]
atom_expr [4762,4770]
===
match
---
name: executors_modules [12598,12615]
name: executors_modules [12573,12590]
===
match
---
atom [4655,4657]
atom [4655,4657]
===
match
---
string: """     Load and register plugins AirflowPlugin subclasses from the entrypoints.     The entry_point group should be 'airflow.plugins'.     """ [6057,6200]
string: """     Load and register plugins AirflowPlugin subclasses from the entrypoints.     The entry_point group should be 'airflow.plugins'.     """ [6057,6200]
===
match
---
name: plugin_class [6551,6563]
name: plugin_class [6551,6563]
===
match
---
funcdef [3509,3603]
funcdef [3509,3603]
===
match
---
parameters [8804,8806]
parameters [8779,8781]
===
match
---
trailer [1358,1368]
trailer [1358,1368]
===
match
---
trailer [8672,8681]
trailer [8647,8656]
===
match
---
name: flask_blueprints [10440,10456]
name: flask_blueprints [10415,10431]
===
match
---
simple_stmt [13183,13270]
simple_stmt [13158,13245]
===
match
---
fstring_string: :</em>  [3577,3584]
fstring_string: :</em>  [3577,3584]
===
match
---
global_stmt [7062,7082]
global_stmt [7062,7082]
===
match
---
atom_expr [3224,3253]
atom_expr [3224,3253]
===
match
---
name: attrs_to_dump [14732,14745]
name: attrs_to_dump [14707,14720]
===
match
---
name: make_module [13021,13032]
name: make_module [12996,13007]
===
match
---
operator: , [2488,2489]
operator: , [2488,2489]
===
match
---
name: __html__ [2657,2665]
name: __html__ [2657,2665]
===
match
---
name: airflow [1220,1227]
name: airflow [1220,1227]
===
match
---
simple_stmt [11993,12064]
simple_stmt [11968,12039]
===
match
---
trailer [7620,7638]
trailer [7620,7638]
===
match
---
simple_stmt [14779,14797]
simple_stmt [14754,14772]
===
match
---
atom_expr [9383,9419]
atom_expr [9358,9394]
===
match
---
name: plugins_info [15006,15018]
name: plugins_info [14981,14993]
===
match
---
name: AirflowPluginSource [3809,3828]
name: AirflowPluginSource [3809,3828]
===
match
---
name: Optional [2059,2067]
name: Optional [2059,2067]
===
match
---
operator: = [7510,7511]
operator: = [7510,7511]
===
match
---
name: plugin [12869,12875]
name: plugin [12844,12850]
===
match
---
simple_stmt [3993,4020]
simple_stmt [3993,4020]
===
match
---
trailer [4009,4014]
trailer [4009,4014]
===
match
---
fstring_expr [3485,3502]
fstring_expr [3485,3502]
===
match
---
simple_stmt [5641,5663]
simple_stmt [5641,5663]
===
match
---
atom_expr [13557,13580]
atom_expr [13532,13555]
===
match
---
trailer [6403,6456]
trailer [6403,6456]
===
match
---
simple_stmt [9428,9454]
simple_stmt [9403,9429]
===
match
---
import_name [910,919]
import_name [910,919]
===
match
---
expr_stmt [3303,3336]
expr_stmt [3303,3336]
===
match
---
fstring_end: " [3076,3077]
fstring_end: " [3076,3077]
===
match
---
trailer [7548,7569]
trailer [7548,7569]
===
match
---
arglist [14264,14298]
arglist [14239,14273]
===
match
---
trailer [3242,3253]
trailer [3242,3253]
===
match
---
string: """Integrate executor plugins to the context.""" [12416,12464]
string: """Integrate executor plugins to the context.""" [12391,12439]
===
match
---
expr_stmt [13183,13240]
expr_stmt [13158,13215]
===
match
---
string: "Loading %d plugin(s) took %.2f seconds" [9762,9802]
string: "Loading %d plugin(s) took %.2f seconds" [9737,9777]
===
match
---
name: Optional [1573,1581]
name: Optional [1573,1581]
===
match
---
name: global_operator_extra_links [11852,11879]
name: global_operator_extra_links [11827,11854]
===
match
---
param [14322,14363]
param [14297,14338]
===
match
---
name: plugin [13770,13776]
name: plugin [13745,13751]
===
match
---
name: metadata [1092,1100]
name: metadata [1092,1100]
===
match
---
name: file_path [7205,7214]
name: file_path [7205,7214]
===
match
---
name: plugin [9621,9627]
name: plugin [9596,9602]
===
match
---
string: 'blueprint' [10750,10761]
string: 'blueprint' [10725,10736]
===
match
---
simple_stmt [4784,4842]
simple_stmt [4784,4842]
===
match
---
trailer [4046,4051]
trailer [4046,4051]
===
match
---
trailer [9711,9720]
trailer [9686,9695]
===
match
---
trailer [1760,1765]
trailer [1760,1765]
===
match
---
name: plugin [10540,10546]
name: plugin [10515,10521]
===
match
---
name: List [1711,1715]
name: List [1711,1715]
===
match
---
simple_stmt [6582,6591]
simple_stmt [6582,6591]
===
match
---
expr_stmt [8270,8303]
expr_stmt [8245,8278]
===
match
---
simple_stmt [910,920]
simple_stmt [910,920]
===
match
---
expr_stmt [1813,1863]
expr_stmt [1813,1863]
===
match
---
trailer [13891,13939]
trailer [13866,13914]
===
match
---
name: plugin [14825,14831]
name: plugin [14800,14806]
===
match
---
trailer [7603,7620]
trailer [7603,7620]
===
match
---
atom_expr [13021,13086]
atom_expr [12996,13061]
===
match
---
simple_stmt [3714,3756]
simple_stmt [3714,3756]
===
match
---
name: plugins [5910,5917]
name: plugins [5910,5917]
===
match
---
trailer [1627,1638]
trailer [1627,1638]
===
match
---
name: initialize_web_ui_plugins [14623,14648]
name: initialize_web_ui_plugins [14598,14623]
===
match
---
trailer [3589,3600]
trailer [3589,3600]
===
match
---
expr_stmt [7995,8053]
expr_stmt [7995,8053]
===
match
---
atom_expr [3360,3372]
atom_expr [3360,3372]
===
match
---
operator: = [1913,1914]
operator: = [1913,1914]
===
match
---
atom_expr [3381,3396]
atom_expr [3381,3396]
===
match
---
operator: = [1969,1970]
operator: = [1969,1970]
===
match
---
comparison [13509,13535]
comparison [13484,13510]
===
match
---
operator: , [2334,2335]
operator: , [2334,2335]
===
match
---
string: 'airflow.executors.' [13033,13053]
string: 'airflow.executors.' [13008,13028]
===
match
---
string: """     Start plugin load and register it after success initialization      :param plugin_instance: subclass of AirflowPlugin     """ [5765,5898]
string: """     Start plugin load and register it after success initialization      :param plugin_instance: subclass of AirflowPlugin     """ [5765,5898]
===
match
---
name: debug [11797,11802]
name: debug [11772,11777]
===
match
---
name: values [7895,7901]
name: values [7895,7901]
===
match
---
param [4876,4880]
param [4876,4880]
===
match
---
suite [13311,14300]
suite [13286,14275]
===
match
---
try_stmt [1011,1123]
try_stmt [1011,1123]
===
match
---
name: PLUGINS_ATTRIBUTES_TO_DUMP [14748,14774]
name: PLUGINS_ATTRIBUTES_TO_DUMP [14723,14749]
===
match
---
operator: - [8596,8597]
operator: - [8571,8572]
===
match
---
expr_stmt [1557,1599]
expr_stmt [1557,1599]
===
match
---
funcdef [12370,13270]
funcdef [12345,13245]
===
match
---
simple_stmt [12072,12135]
simple_stmt [12047,12110]
===
match
---
operator: } [3576,3577]
operator: } [3576,3577]
===
match
---
name: importlib_metadata [3261,3279]
name: importlib_metadata [3261,3279]
===
match
---
string: 'BaseHook' [1537,1547]
string: 'BaseHook' [1537,1547]
===
match
---
trailer [10596,10621]
trailer [10571,10596]
===
match
---
name: Any [14383,14386]
name: Any [14358,14361]
===
match
---
trailer [9417,9419]
trailer [9392,9394]
===
match
---
name: Any [1716,1719]
name: Any [1716,1719]
===
match
---
name: operator_extra_links [11889,11909]
name: operator_extra_links [11864,11884]
===
match
---
name: global_operator_extra_links [12035,12062]
name: global_operator_extra_links [12010,12037]
===
match
---
comparison [13589,13604]
comparison [13564,13579]
===
match
---
operator: { [3584,3585]
operator: { [3584,3585]
===
match
---
name: Any [3883,3886]
name: Any [3883,3886]
===
match
---
atom_expr [8538,8560]
atom_expr [8513,8535]
===
match
---
operator: { [12217,12218]
operator: { [12192,12193]
===
match
---
parameters [12400,12402]
parameters [12375,12377]
===
match
---
expr_stmt [6904,6946]
expr_stmt [6904,6946]
===
match
---
atom_expr [1582,1591]
atom_expr [1582,1591]
===
match
---
name: str [12975,12978]
name: str [12950,12953]
===
match
---
name: str [3399,3402]
name: str [3399,3402]
===
match
---
operator: } [12356,12357]
operator: } [12331,12332]
===
match
---
atom_expr [13925,13938]
atom_expr [13900,13913]
===
match
---
string: "Loading plugins from entrypoints" [6277,6311]
string: "Loading plugins from entrypoints" [6277,6311]
===
match
---
simple_stmt [12637,12644]
simple_stmt [12612,12619]
===
match
---
atom_expr [3585,3600]
atom_expr [3585,3600]
===
match
---
global_stmt [5433,5447]
global_stmt [5433,5447]
===
match
---
name: appbuilder_views [4024,4040]
name: appbuilder_views [4024,4040]
===
match
---
fstring_string: airflow.macros. [13894,13909]
fstring_string: airflow.macros. [13869,13884]
===
match
---
simple_stmt [3303,3337]
simple_stmt [3303,3337]
===
match
---
string: "Can't load plugins." [12735,12756]
string: "Can't load plugins." [12710,12731]
===
match
---
and_test [10885,10939]
and_test [10860,10914]
===
match
---
arglist [7243,7284]
arglist [7243,7284]
===
match
---
expr_stmt [3956,3988]
expr_stmt [3956,3988]
===
match
---
trailer [3941,3946]
trailer [3941,3946]
===
match
---
operator: = [10489,10490]
operator: = [10464,10465]
===
match
---
atom_expr [12028,12062]
atom_expr [12003,12037]
===
match
---
name: airflow [1158,1165]
name: airflow [1158,1165]
===
match
---
name: load_entrypoint_plugins [9428,9451]
name: load_entrypoint_plugins [9403,9426]
===
match
---
suite [10558,11168]
suite [10533,11143]
===
match
---
fstring_start: f" [3454,3456]
fstring_start: f" [3454,3456]
===
match
---
suite [2951,2998]
suite [2951,2998]
===
match
---
expr_stmt [4379,4422]
expr_stmt [4379,4422]
===
match
---
trailer [3568,3576]
trailer [3568,3576]
===
match
---
if_stmt [11497,11674]
if_stmt [11472,11649]
===
match
---
name: dist [3360,3364]
name: dist [3360,3364]
===
match
---
name: ensure_plugins_loaded [10283,10304]
name: ensure_plugins_loaded [10258,10279]
===
match
---
expr_stmt [9352,9373]
expr_stmt [9327,9348]
===
match
---
funcdef [2653,2707]
funcdef [2653,2707]
===
match
---
name: entry_point [6874,6885]
name: entry_point [6874,6885]
===
match
---
name: List [4084,4088]
name: List [4084,4088]
===
match
---
name: name [12988,12992]
name: name [12963,12967]
===
match
---
name: plugin_obj [5176,5186]
name: plugin_obj [5176,5186]
===
match
---
trailer [10589,10596]
trailer [10564,10571]
===
match
---
import_from [1294,1333]
import_from [1294,1333]
===
match
---
funcdef [14302,15019]
funcdef [14277,14994]
===
match
---
name: plugin_obj [5678,5688]
name: plugin_obj [5678,5688]
===
match
---
string: """     Check whether a potential object is a subclass of     the AirflowPlugin class.      :param plugin_obj: potential subclass of AirflowPlugin     :return: Whether or not the obj is a valid subclass of         AirflowPlugin     """ [5193,5428]
string: """     Check whether a potential object is a subclass of     the AirflowPlugin class.      :param plugin_obj: potential subclass of AirflowPlugin     :return: Whether or not the obj is a valid subclass of         AirflowPlugin     """ [5193,5428]
===
match
---
name: EntryPointSource [3086,3102]
name: EntryPointSource [3086,3102]
===
match
---
comp_op [11640,11646]
comp_op [11615,11621]
===
match
---
simple_stmt [7503,7570]
simple_stmt [7503,7570]
===
match
---
name: plugins [5696,5703]
name: plugins [5696,5703]
===
match
---
name: executors_modules [13128,13145]
name: executors_modules [13103,13120]
===
match
---
atom_expr [12316,12343]
atom_expr [12291,12318]
===
match
---
operator: , [1003,1004]
operator: , [1003,1004]
===
match
---
decorator [4847,4860]
decorator [4847,4860]
===
match
---
if_stmt [1272,1334]
if_stmt [1272,1334]
===
match
---
trailer [10406,10434]
trailer [10381,10409]
===
match
---
simple_stmt [10283,10307]
simple_stmt [10258,10282]
===
match
---
atom_expr [4042,4051]
atom_expr [4042,4051]
===
match
---
return_stmt [2960,2997]
return_stmt [2960,2997]
===
match
---
name: plugins [14804,14811]
name: plugins [14779,14786]
===
match
---
funcdef [8341,8741]
funcdef [8316,8716]
===
match
---
sync_comp_for [12304,12343]
sync_comp_for [12279,12318]
===
match
---
atom_expr [13880,13939]
atom_expr [13855,13914]
===
match
---
atom_expr [4790,4841]
atom_expr [4790,4841]
===
match
---
simple_stmt [1020,1046]
simple_stmt [1020,1046]
===
match
---
not_test [10907,10939]
not_test [10882,10914]
===
match
---
simple_stmt [11736,11788]
simple_stmt [11711,11763]
===
match
---
name: plugin_obj [5641,5651]
name: plugin_obj [5641,5651]
===
match
---
name: global_operator_extra_links [11510,11537]
name: global_operator_extra_links [11485,11512]
===
match
---
name: List [14368,14372]
name: List [14343,14347]
===
match
---
string: "Invalid plugin name" [12931,12952]
string: "Invalid plugin name" [12906,12927]
===
match
---
if_stmt [10812,11168]
if_stmt [10787,11143]
===
match
---
trailer [1906,1911]
trailer [1906,1911]
===
match
---
atom_expr [7882,7903]
atom_expr [7882,7903]
===
match
---
name: os [7302,7304]
name: os [7302,7304]
===
match
---
name: str [8297,8300]
name: str [8272,8275]
===
match
---
atom [14909,14955]
atom [14884,14930]
===
match
---
operator: = [6672,6673]
operator: = [6672,6673]
===
match
---
simple_stmt [9260,9289]
simple_stmt [9235,9264]
===
match
---
simple_stmt [4024,4057]
simple_stmt [4024,4057]
===
match
---
name: lower [8517,8522]
name: lower [8492,8497]
===
match
---
fstring_end: " [2996,2997]
fstring_end: " [2996,2997]
===
match
---
atom_expr [1711,1720]
atom_expr [1711,1720]
===
match
---
name: o [8709,8710]
name: o [8684,8685]
===
match
---
raise_stmt [9209,9254]
raise_stmt [9184,9229]
===
match
---
name: plugin_name [13056,13067]
name: plugin_name [13031,13042]
===
match
---
name: Stats [8981,8986]
name: Stats [8956,8961]
===
match
---
name: global_operator_extra_links [1920,1947]
name: global_operator_extra_links [1920,1947]
===
match
---
name: dist [6335,6339]
name: dist [6335,6339]
===
match
---
name: append [5996,6002]
name: append [5996,6002]
===
match
---
fstring_string: == [3467,3469]
fstring_string: == [3467,3469]
===
match
---
trailer [7666,7671]
trailer [7666,7671]
===
match
---
trailer [7885,7894]
trailer [7885,7894]
===
match
---
atom_expr [12072,12134]
atom_expr [12047,12109]
===
match
---
operator: = [1857,1858]
operator: = [1857,1858]
===
match
---
name: plugin [12316,12322]
name: plugin [12291,12297]
===
match
---
name: link [12308,12312]
name: link [12283,12287]
===
match
---
name: List [3974,3978]
name: List [3974,3978]
===
match
---
name: debug [10401,10406]
name: debug [10376,10381]
===
match
---
suite [10262,10278]
suite [10237,10253]
===
match
---
string: 'airflow.plugins' [6366,6383]
string: 'airflow.plugins' [6366,6383]
===
match
---
fstring_expr [3065,3076]
fstring_expr [3065,3076]
===
match
---
trailer [7894,7901]
trailer [7894,7901]
===
match
---
atom [5592,5625]
atom [5592,5625]
===
match
---
trailer [13916,13921]
trailer [13891,13896]
===
match
---
parameters [5175,5187]
parameters [5175,5187]
===
match
---
return_stmt [5671,5703]
return_stmt [5671,5703]
===
match
---
comp_op [5689,5695]
comp_op [5689,5695]
===
match
---
expr_stmt [2869,2927]
expr_stmt [2869,2927]
===
match
---
sync_comp_for [8705,8721]
sync_comp_for [8680,8696]
===
match
---
trailer [13032,13086]
trailer [13007,13061]
===
match
---
trailer [12670,12672]
trailer [12645,12647]
===
match
---
operator: = [7377,7378]
operator: = [7377,7378]
===
match
---
funcdef [2595,2648]
funcdef [2595,2648]
===
match
---
name: plugins [12515,12522]
name: plugins [12490,12497]
===
match
---
name: path [7382,7386]
name: path [7382,7386]
===
match
---
operator: = [1722,1723]
operator: = [1722,1723]
===
match
---
name: mod [7767,7770]
name: mod [7767,7770]
===
match
---
atom_expr [12246,12269]
atom_expr [12221,12244]
===
match
---
global_stmt [9975,9998]
global_stmt [9950,9973]
===
match
---
trailer [3555,3560]
trailer [3555,3560]
===
match
---
import_name [895,909]
import_name [895,909]
===
match
---
name: o [8690,8691]
name: o [8665,8666]
===
match
---
name: integrate_executor_plugins [12374,12400]
name: integrate_executor_plugins [12349,12375]
===
match
---
atom_expr [14623,14650]
atom_expr [14598,14625]
===
match
---
if_stmt [7295,7350]
if_stmt [7295,7350]
===
match
---
parameters [3015,3021]
parameters [3015,3021]
===
match
---
trailer [8381,8386]
trailer [8356,8361]
===
match
---
simple_stmt [1864,1920]
simple_stmt [1864,1920]
===
match
---
string: """Validates that plugin has a name.""" [4707,4746]
string: """Validates that plugin has a name.""" [4707,4746]
===
match
---
simple_stmt [8727,8741]
simple_stmt [8702,8716]
===
match
---
name: Optional [1949,1957]
name: Optional [1949,1957]
===
match
---
simple_stmt [1406,1460]
simple_stmt [1406,1460]
===
match
---
dotted_name [1220,1238]
dotted_name [1220,1238]
===
match
---
atom [9341,9343]
atom [9316,9318]
===
match
---
name: plugin [10737,10743]
name: plugin [10712,10718]
===
match
---
if_stmt [14801,14995]
if_stmt [14776,14970]
===
match
---
name: plugins [9331,9338]
name: plugins [9306,9313]
===
match
---
simple_stmt [12527,12552]
simple_stmt [12502,12527]
===
match
---
name: sys [927,930]
name: sys [927,930]
===
match
---
trailer [6943,6946]
trailer [6943,6946]
===
match
---
atom [11912,11914]
atom [11887,11889]
===
match
---
trailer [1755,1766]
trailer [1755,1766]
===
match
---
trailer [8216,8257]
trailer [8191,8232]
===
match
---
name: plugins [5988,5995]
name: plugins [5988,5995]
===
match
---
name: plugins [9712,9719]
name: plugins [9687,9694]
===
match
---
atom_expr [10777,10800]
atom_expr [10752,10775]
===
match
---
name: Any [4010,4013]
name: Any [4010,4013]
===
match
---
trailer [12034,12062]
trailer [12009,12037]
===
match
---
string: "Loading plugins" [9270,9287]
string: "Loading plugins" [9245,9262]
===
match
---
name: num_loaded [9728,9738]
name: num_loaded [9703,9713]
===
match
---
trailer [8516,8522]
trailer [8491,8497]
===
match
---
suite [5632,5704]
suite [5632,5704]
===
match
---
simple_stmt [3924,3952]
simple_stmt [3924,3952]
===
match
---
string: 'Importing entry_point plugin %s' [6404,6437]
string: 'Importing entry_point plugin %s' [6404,6437]
===
match
---
name: os [2881,2883]
name: os [2881,2883]
===
match
---
simple_stmt [3345,3373]
simple_stmt [3345,3373]
===
match
---
name: Any [3979,3982]
name: Any [3979,3982]
===
match
---
suite [6565,6591]
suite [6565,6591]
===
match
---
simple_stmt [6482,6516]
simple_stmt [6482,6516]
===
match
---
name: name [8555,8559]
name: name [8530,8534]
===
match
---
operator: = [11910,11911]
operator: = [11885,11886]
===
match
---
simple_stmt [14623,14651]
simple_stmt [14598,14626]
===
match
---
expr_stmt [1370,1404]
expr_stmt [1370,1404]
===
match
---
operator: , [6437,6438]
operator: , [6437,6438]
===
match
---
name: registered_operator_link_classes [2025,2057]
name: registered_operator_link_classes [2025,2057]
===
match
---
arglist [5553,5578]
arglist [5553,5578]
===
match
---
expr_stmt [14856,14884]
expr_stmt [14831,14859]
===
match
---
name: __str__ [2599,2606]
name: __str__ [2599,2606]
===
match
---
trailer [7793,7834]
trailer [7793,7834]
===
match
---
trailer [9107,9148]
trailer [9082,9123]
===
match
---
comp_op [10244,10250]
comp_op [10219,10225]
===
match
---
atom_expr [3315,3336]
atom_expr [3315,3336]
===
match
---
operator: = [7730,7731]
operator: = [7730,7731]
===
match
---
name: __name__ [12261,12269]
name: __name__ [12236,12244]
===
match
---
trailer [9682,9688]
trailer [9657,9663]
===
match
---
simple_stmt [6205,6262]
simple_stmt [6205,6262]
===
match
---
global_stmt [12527,12551]
global_stmt [12502,12526]
===
match
---
name: hooks [9683,9688]
name: hooks [9658,9663]
===
match
---
name: Any [8382,8385]
name: Any [8357,8360]
===
match
---
name: error [8211,8216]
name: exception [8182,8191]
===
match
---
fstring_start: f" [3038,3040]
fstring_start: f" [3038,3040]
===
match
---
name: path [2854,2858]
name: path [2854,2858]
===
match
---
simple_stmt [3792,3837]
simple_stmt [3792,3837]
===
match
---
simple_stmt [4907,5154]
simple_stmt [4907,5154]
===
match
---
simple_stmt [13803,13855]
simple_stmt [13778,13830]
===
match
---
simple_stmt [8447,8459]
simple_stmt [8422,8434]
===
match
---
suite [3438,3504]
suite [3438,3504]
===
match
---
name: plugin [12839,12845]
name: plugin [12814,12820]
===
match
---
simple_stmt [11222,11300]
simple_stmt [11197,11275]
===
match
---
name: make_module [8345,8356]
name: make_module [8320,8331]
===
match
---
expr_stmt [10466,10493]
expr_stmt [10441,10468]
===
match
---
simple_stmt [14592,14619]
simple_stmt [14567,14594]
===
match
---
trailer [13186,13194]
trailer [13161,13169]
===
match
---
name: e [8131,8132]
name: e [8131,8132]
===
match
---
trailer [12111,12132]
trailer [12086,12107]
===
match
---
name: loader [7631,7637]
name: loader [7631,7637]
===
match
---
atom_expr [1846,1855]
atom_expr [1846,1855]
===
match
---
global_stmt [11382,11409]
global_stmt [11357,11384]
===
match
---
atom_expr [4005,4014]
atom_expr [4005,4014]
===
match
---
name: os [7379,7381]
name: os [7379,7381]
===
match
---
trailer [12222,12232]
trailer [12197,12207]
===
match
---
name: List [14346,14350]
name: List [14321,14325]
===
match
---
testlist_comp [8690,8703]
testlist_comp [8665,8678]
===
match
---
fstring [12215,12271]
fstring [12190,12246]
===
match
---
expr_stmt [8505,8524]
expr_stmt [8480,8499]
===
match
---
name: Type [2078,2082]
name: Type [2078,2082]
===
match
---
name: Exception [3634,3643]
name: Exception [3634,3643]
===
match
---
atom_expr [1893,1912]
atom_expr [1893,1912]
===
match
---
name: name [14279,14283]
name: name [14254,14258]
===
match
---
name: plugin_instance [5743,5758]
name: plugin_instance [5743,5758]
===
match
---
name: registered_operator_link_classes [11919,11951]
name: registered_operator_link_classes [11894,11926]
===
match
---
trailer [10822,10834]
trailer [10797,10809]
===
match
---
atom_expr [12981,12992]
atom_expr [12956,12967]
===
match
---
expr_stmt [7358,7425]
expr_stmt [7358,7425]
===
match
---
trailer [3070,3075]
trailer [3070,3075]
===
match
---
operator: , [2396,2397]
operator: , [2396,2397]
===
match
---
trailer [6276,6312]
trailer [6276,6312]
===
match
---
fstring [3544,3602]
fstring [3544,3602]
===
match
---
expr_stmt [8529,8560]
expr_stmt [8504,8535]
===
match
---
name: plugin_instance [7944,7959]
name: plugin_instance [7944,7959]
===
match
---
name: timer [9316,9321]
name: timer [9291,9296]
===
match
---
with_item [9299,9321]
with_item [9274,9296]
===
match
---
simple_stmt [11343,11378]
simple_stmt [11318,11353]
===
match
---
name: macros [14264,14270]
name: macros [14239,14245]
===
match
---
name: util [7599,7603]
name: util [7599,7603]
===
match
---
name: PluginsDirectorySource [8020,8042]
name: PluginsDirectorySource [8020,8042]
===
match
---
simple_stmt [12649,12673]
simple_stmt [12624,12648]
===
match
---
simple_stmt [8505,8525]
simple_stmt [8480,8500]
===
match
---
name: List [1846,1850]
name: List [1846,1850]
===
match
---
simple_stmt [3650,3687]
simple_stmt [3650,3687]
===
match
---
name: appbuilder_menu_items [10918,10939]
name: appbuilder_menu_items [10893,10914]
===
match
---
name: append [13146,13152]
name: append [13121,13127]
===
match
---
operator: = [1767,1768]
operator: = [1767,1768]
===
match
---
trailer [9668,9675]
trailer [9643,9650]
===
match
---
name: entry_point [6918,6929]
name: entry_point [6918,6929]
===
match
---
expr_stmt [3897,3919]
expr_stmt [3897,3919]
===
match
---
trailer [6550,6564]
trailer [6550,6564]
===
match
---
trailer [1389,1399]
trailer [1389,1399]
===
match
---
param [8357,8367]
param [8332,8342]
===
match
---
comp_op [9077,9083]
comp_op [9052,9058]
===
match
---
parameters [2606,2612]
parameters [2606,2612]
===
match
---
import_from [1153,1214]
import_from [1153,1214]
===
match
---
testlist_comp [7871,7925]
testlist_comp [7871,7925]
===
match
---
operator: , [2502,2503]
operator: , [2502,2503]
===
match
---
name: path [2874,2878]
name: path [2874,2878]
===
match
---
simple_stmt [9652,9690]
simple_stmt [9627,9665]
===
match
---
funcdef [13272,14300]
funcdef [13247,14275]
===
match
---
name: plugin_name [12962,12973]
name: plugin_name [12937,12948]
===
match
---
parameters [6049,6051]
parameters [6049,6051]
===
match
---
import_name [831,857]
import_name [831,857]
===
match
---
operator: { [2304,2305]
operator: { [2304,2305]
===
match
---
name: plugin [14921,14927]
name: plugin [14896,14902]
===
match
---
name: import_errors [6212,6225]
name: import_errors [6212,6225]
===
match
---
name: self [3585,3589]
name: self [3585,3589]
===
match
---
simple_stmt [1294,1334]
simple_stmt [1294,1334]
===
match
---
trailer [5995,6002]
trailer [5995,6002]
===
match
---
simple_stmt [3867,3893]
simple_stmt [3867,3893]
===
match
---
operator: = [2879,2880]
operator: = [2879,2880]
===
match
---
arglist [7549,7568]
arglist [7549,7568]
===
match
---
comparison [11607,11651]
comparison [11582,11626]
===
match
---
atom_expr [1756,1765]
atom_expr [1756,1765]
===
match
---
arglist [13892,13938]
arglist [13867,13913]
===
match
---
expr_stmt [2025,2091]
expr_stmt [2025,2091]
===
match
---
fstring_string: $PLUGINS_FOLDER/ [2969,2985]
fstring_string: $PLUGINS_FOLDER/ [2969,2985]
===
match
---
name: initialize_extra_operators_links_plugins [11174,11214]
name: initialize_extra_operators_links_plugins [11149,11189]
===
match
---
name: version [3475,3482]
name: version [3475,3482]
===
match
---
simple_stmt [12144,12368]
simple_stmt [12119,12343]
===
match
---
atom_expr [2059,2084]
atom_expr [2059,2084]
===
match
---
if_stmt [9066,9164]
if_stmt [9041,9139]
===
match
---
atom_expr [14592,14618]
atom_expr [14567,14593]
===
match
---
operator: = [3984,3985]
operator: = [3984,3985]
===
match
---
atom_expr [1532,1548]
atom_expr [1532,1548]
===
match
---
simple_stmt [13391,13406]
simple_stmt [13366,13381]
===
match
---
name: extend [10658,10664]
name: extend [10633,10639]
===
match
---
trailer [7766,7771]
trailer [7766,7771]
===
match
---
name: objects [8638,8645]
name: objects [8613,8620]
===
match
---
atom_expr [9708,9720]
atom_expr [9683,9695]
===
match
---
atom [7870,7926]
atom [7870,7926]
===
match
---
simple_stmt [13474,13501]
simple_stmt [13449,13476]
===
match
---
atom_expr [10843,10866]
atom_expr [10818,10841]
===
match
---
arglist [9762,9830]
arglist [9737,9805]
===
match
---
name: AirflowPluginException [11742,11764]
name: AirflowPluginException [11717,11739]
===
match
---
name: flask_appbuilder_views [10169,10191]
name: flask_appbuilder_views [10144,10166]
===
match
---
expr_stmt [11919,11956]
expr_stmt [11894,11931]
===
match
---
atom_expr [9098,9148]
atom_expr [9073,9123]
===
match
---
simple_stmt [9752,9832]
simple_stmt [9727,9807]
===
match
---
name: entry_points [1172,1184]
name: entry_points [1172,1184]
===
match
---
raise_stmt [11736,11787]
raise_stmt [11711,11762]
===
match
---
atom [11954,11956]
atom [11929,11931]
===
match
---
atom_expr [3261,3292]
atom_expr [3261,3292]
===
match
---
name: info [14989,14993]
name: info [14964,14968]
===
match
---
operator: = [10457,10458]
operator: = [10432,10433]
===
match
---
trailer [1901,1912]
trailer [1901,1912]
===
match
---
name: name [12876,12880]
name: name [12851,12855]
===
match
---
atom_expr [3937,3946]
atom_expr [3937,3946]
===
match
---
string: "Please contact the author of the plugin." [11081,11123]
string: "Please contact the author of the plugin." [11056,11098]
===
match
---
name: Stats [9299,9304]
name: Stats [9274,9279]
===
match
---
operator: = [14792,14793]
operator: = [14767,14768]
===
match
---
name: Dict [983,987]
name: Dict [983,987]
===
match
---
name: plugin [10911,10917]
name: plugin [10886,10892]
===
match
---
trailer [14039,14063]
trailer [14014,14038]
===
match
---
simple_stmt [9352,9374]
simple_stmt [9327,9349]
===
match
---
simple_stmt [6394,6457]
simple_stmt [6394,6457]
===
match
---
suite [10331,10392]
suite [10306,10367]
===
match
---
name: list [12100,12104]
name: list [12075,12079]
===
match
---
trailer [3279,3292]
trailer [3279,3292]
===
match
---
simple_stmt [5903,5954]
simple_stmt [5903,5954]
===
match
---
operator: , [10748,10749]
operator: , [10723,10724]
===
match
---
operator: * [4881,4882]
operator: * [4881,4882]
===
match
---
operator: = [3313,3314]
operator: = [3313,3314]
===
match
---
name: List [1958,1962]
name: List [1958,1962]
===
match
---
import_as_name [1092,1122]
import_as_name [1092,1122]
===
match
---
simple_stmt [9975,9999]
simple_stmt [9950,9974]
===
match
---
atom_expr [12144,12367]
atom_expr [12119,12342]
===
match
---
name: entry_points_with_dist [6343,6365]
name: entry_points_with_dist [6343,6365]
===
match
---
return_stmt [3537,3602]
return_stmt [3537,3602]
===
match
---
name: flask_blueprints [1729,1745]
name: flask_blueprints [1729,1745]
===
match
---
simple_stmt [5193,5429]
simple_stmt [5193,5429]
===
match
---
fstring_end: " [3601,3602]
fstring_end: " [3601,3602]
===
match
---
name: Any [4047,4050]
name: Any [4047,4050]
===
match
---
operator: { [14863,14864]
operator: { [14838,14839]
===
match
---
atom_expr [10567,10621]
atom_expr [10542,10596]
===
match
---
name: self [3303,3307]
name: self [3303,3307]
===
match
---
atom_expr [1341,1368]
atom_expr [1341,1368]
===
match
---
atom_expr [14872,14883]
atom_expr [14847,14858]
===
match
---
not_test [8426,8437]
not_test [8401,8412]
===
match
---
name: file_path [7824,7833]
name: file_path [7824,7833]
===
match
---
trailer [2006,2017]
trailer [2006,2017]
===
match
---
name: mod_name [7621,7629]
name: mod_name [7621,7629]
===
match
---
name: name [14879,14883]
name: name [14854,14858]
===
match
---
trailer [14901,14908]
trailer [14876,14883]
===
match
---
trailer [12092,12099]
trailer [12067,12074]
===
match
---
simple_stmt [14256,14300]
simple_stmt [14231,14275]
===
match
---
suite [14812,14995]
suite [14787,14970]
===
match
---
atom_expr [14969,14994]
atom_expr [14944,14969]
===
match
---
operator: = [8636,8637]
operator: = [8611,8612]
===
match
---
trailer [3474,3482]
trailer [3474,3482]
===
match
---
return_stmt [3031,3077]
return_stmt [3031,3077]
===
match
---
name: plugin_instance [6003,6018]
name: plugin_instance [6003,6018]
===
match
---
fstring_expr [3469,3483]
fstring_expr [3469,3483]
===
match
---
name: inspect [887,894]
name: inspect [887,894]
===
match
---
trailer [3402,3414]
trailer [3402,3414]
===
match
---
name: Optional [3800,3808]
name: Optional [3800,3808]
===
match
---
operator: } [14954,14955]
operator: } [14929,14930]
===
match
---
trailer [8688,8722]
trailer [8663,8697]
===
match
---
expr_stmt [7944,7978]
expr_stmt [7944,7978]
===
match
---
simple_stmt [7123,7196]
simple_stmt [7123,7196]
===
match
---
global_stmt [9956,9970]
global_stmt [9931,9945]
===
match
---
factor [7421,7423]
factor [7421,7423]
===
match
---
name: plugins [1406,1413]
name: plugins [1406,1413]
===
match
---
comparison [11510,11549]
comparison [11485,11524]
===
match
---
name: plugin_instance [6649,6664]
name: plugin_instance [6649,6664]
===
match
---
name: plugins [8999,9006]
name: plugins [8974,8981]
===
match
---
trailer [9451,9453]
trailer [9426,9428]
===
match
---
operator: , [11152,11153]
operator: , [11127,11128]
===
match
---
trailer [12322,12343]
trailer [12297,12318]
===
match
---
name: plugin_obj [5518,5528]
name: plugin_obj [5518,5528]
===
match
---
atom_expr [9260,9288]
atom_expr [9235,9263]
===
match
---
simple_stmt [8207,8258]
simple_stmt [8178,8233]
===
match
---
simple_stmt [6995,7058]
simple_stmt [6995,7058]
===
match
---
name: flask_appbuilder_menu_links [10216,10243]
name: flask_appbuilder_menu_links [10191,10218]
===
match
---
annassign [1745,1773]
annassign [1745,1773]
===
match
---
simple_stmt [3897,3920]
simple_stmt [3897,3920]
===
match
---
simple_stmt [2960,2998]
simple_stmt [2960,2998]
===
match
---
atom_expr [3470,3482]
atom_expr [3470,3482]
===
match
---
except_clause [1046,1064]
except_clause [1046,1064]
===
match
---
operator: { [10728,10729]
operator: { [10703,10704]
===
match
---
simple_stmt [5765,5899]
simple_stmt [5765,5899]
===
match
---
name: AirflowPluginException [12908,12930]
name: AirflowPluginException [12883,12905]
===
match
---
simple_stmt [8565,8616]
simple_stmt [8540,8591]
===
match
---
if_stmt [13767,13855]
if_stmt [13742,13830]
===
match
---
simple_stmt [2025,2092]
simple_stmt [2025,2092]
===
match
---
dictorsetmaker [10729,10765]
dictorsetmaker [10704,10740]
===
match
---
simple_stmt [5433,5484]
simple_stmt [5433,5484]
===
match
---
fstring_expr [3563,3577]
fstring_expr [3563,3577]
===
match
---
name: flask_blueprints [3956,3972]
name: flask_blueprints [3956,3972]
===
match
---
atom_expr [8020,8053]
atom_expr [8020,8053]
===
match
---
name: find_path_from_directory [7218,7242]
name: find_path_from_directory [7218,7242]
===
match
---
annassign [4040,4056]
annassign [4040,4056]
===
match
---
trailer [4088,4093]
trailer [4088,4093]
===
match
---
suite [7286,8304]
suite [7286,8279]
===
match
---
not_test [7298,7327]
not_test [7298,7327]
===
match
---
trailer [10743,10748]
trailer [10718,10723]
===
match
---
name: debug [13675,13680]
name: debug [13650,13655]
===
match
---
name: log [10397,10400]
name: log [10372,10375]
===
match
---
name: version [3569,3576]
name: version [3569,3576]
===
match
---
simple_stmt [5958,5984]
simple_stmt [5958,5984]
===
match
---
name: plugin_obj [5593,5603]
name: plugin_obj [5593,5603]
===
match
---
trailer [8681,8688]
trailer [8656,8663]
===
match
---
name: dist [3308,3312]
name: dist [3308,3312]
===
match
---
name: Optional [1893,1901]
name: Optional [1893,1901]
===
match
---
suite [7490,8103]
suite [7490,8103]
===
match
---
name: on_load [5974,5981]
name: on_load [5974,5981]
===
match
---
name: List [3848,3852]
name: List [3848,3852]
===
match
---
atom_expr [3905,3914]
atom_expr [3905,3914]
===
match
---
name: self [3522,3526]
name: self [3522,3526]
===
match
---
name: debug [9264,9269]
name: debug [9239,9244]
===
match
---
name: macros_modules [13509,13523]
name: macros_modules [13484,13498]
===
match
---
funcdef [2933,2998]
funcdef [2933,2998]
===
match
---
name: modules [13187,13194]
name: modules [13162,13169]
===
match
---
fstring_string: == [3561,3563]
fstring_string: == [3561,3563]
===
match
---
atom [12197,12357]
atom [12172,12332]
===
match
---
name: stats [8968,8973]
name: stats [8943,8948]
===
match
---
import_from [13474,13500]
import_from [13449,13475]
===
match
---
trailer [6690,6709]
trailer [6690,6709]
===
match
---
simple_stmt [14999,15019]
simple_stmt [14974,14994]
===
match
---
suite [13790,13855]
suite [13765,13830]
===
match
---
simple_stmt [7582,7639]
simple_stmt [7582,7639]
===
match
---
expr_stmt [3792,3836]
expr_stmt [3792,3836]
===
match
---
name: is_valid_plugin [6535,6550]
name: is_valid_plugin [6535,6550]
===
match
---
name: m [7871,7872]
name: m [7871,7872]
===
match
---
simple_stmt [13711,13731]
simple_stmt [13686,13706]
===
match
---
fstring_string: <em>$PLUGINS_FOLDER/</em> [3040,3065]
fstring_string: <em>$PLUGINS_FOLDER/</em> [3040,3065]
===
match
---
name: admin_views [1689,1700]
name: admin_views [1689,1700]
===
match
---
atom [14863,14884]
atom [14838,14859]
===
match
---
trailer [1850,1855]
trailer [1850,1855]
===
match
---
name: plugin_instance [7995,8010]
name: plugin_instance [7995,8010]
===
match
---
simple_stmt [8270,8304]
simple_stmt [8245,8279]
===
match
---
operator: { [3456,3457]
operator: { [3456,3457]
===
match
---
trailer [13993,14000]
trailer [13968,13975]
===
match
---
operator: = [3358,3359]
operator: = [3358,3359]
===
match
---
simple_stmt [4707,4747]
simple_stmt [4707,4747]
===
match
---
fstring_expr [2985,2996]
fstring_expr [2985,2996]
===
match
---
comparison [11711,11726]
comparison [11686,11701]
===
match
---
parameters [6987,6989]
parameters [6987,6989]
===
match
---
name: __name__ [8692,8700]
name: __name__ [8667,8675]
===
match
---
name: plugin [12105,12111]
name: plugin [12080,12086]
===
match
---
name: executors [13076,13085]
name: executors [13051,13060]
===
match
---
trailer [14377,14387]
trailer [14352,14362]
===
match
---
name: mod_name [7358,7366]
name: mod_name [7358,7366]
===
match
---
name: plugins [13398,13405]
name: plugins [13373,13380]
===
match
---
global_stmt [13410,13431]
global_stmt [13385,13406]
===
match
---
for_stmt [10536,11168]
for_stmt [10511,11143]
===
match
---
classdef [3689,5154]
classdef [3689,5154]
===
match
---
simple_stmt [1600,1646]
simple_stmt [1600,1646]
===
match
---
name: Exception [6770,6779]
name: Exception [6770,6779]
===
match
---
name: dist [3315,3319]
name: dist [3315,3319]
===
match
---
annassign [3876,3892]
annassign [3876,3892]
===
match
---
annassign [1784,1812]
annassign [1784,1812]
===
match
---
testlist_star_expr [7358,7376]
testlist_star_expr [7358,7376]
===
match
---
string: "Your plugin needs a name." [4813,4840]
string: "Your plugin needs a name." [4813,4840]
===
match
---
for_stmt [12835,13270]
for_stmt [12810,13245]
===
match
---
arglist [10992,11153]
arglist [10967,11128]
===
match
---
name: plugin [13925,13931]
name: plugin [13900,13906]
===
match
---
trailer [8595,8599]
trailer [8570,8574]
===
match
---
expr_stmt [11889,11914]
expr_stmt [11864,11889]
===
match
---
suite [14723,14775]
suite [14698,14750]
===
match
---
name: setattr [14256,14263]
name: setattr [14231,14238]
===
match
---
name: info [14856,14860]
name: info [14831,14835]
===
match
---
name: e [6944,6945]
name: e [6944,6945]
===
match
---
atom [10871,10949]
atom [10846,10924]
===
match
---
return_stmt [8727,8740]
return_stmt [8702,8715]
===
match
---
name: Any [3910,3913]
name: Any [3910,3913]
===
match
---
operator: , [7822,7823]
operator: , [7822,7823]
===
match
---
trailer [5517,5529]
trailer [5517,5529]
===
match
---
operator: , [7557,7558]
operator: , [7557,7558]
===
match
---
name: self [3345,3349]
name: self [3345,3349]
===
match
---
suite [2613,2648]
suite [2613,2648]
===
match
---
trailer [12766,12772]
trailer [12741,12747]
===
match
---
expr_stmt [13864,13939]
expr_stmt [13839,13914]
===
match
---
atom_expr [2881,2927]
atom_expr [2881,2927]
===
match
---
name: flask_appbuilder_menu_links [10630,10657]
name: flask_appbuilder_menu_links [10605,10632]
===
match
---
atom_expr [7302,7327]
atom_expr [7302,7327]
===
match
---
name: NotImplementedError [2628,2647]
name: NotImplementedError [2628,2647]
===
match
---
name: initialize_web_ui_plugins [9838,9863]
name: initialize_web_ui_plugins [9813,9838]
===
match
---
simple_stmt [1557,1600]
simple_stmt [1557,1600]
===
match
---
if_stmt [12595,12644]
if_stmt [12570,12619]
===
match
---
name: name [7724,7728]
name: name [7724,7728]
===
match
---
name: os [917,919]
name: os [917,919]
===
match
---
atom_expr [1795,1804]
atom_expr [1795,1804]
===
match
---
name: log [1335,1338]
name: log [1335,1338]
===
match
---
trailer [14372,14388]
trailer [14347,14363]
===
match
---
atom_expr [7707,7729]
atom_expr [7707,7729]
===
match
---
name: importlib [865,874]
name: importlib [865,874]
===
match
---
trailer [12734,12757]
trailer [12709,12732]
===
match
---
trailer [1710,1721]
trailer [1710,1721]
===
match
---
operator: = [9706,9707]
operator: = [9681,9682]
===
match
---
fstring_expr [12217,12244]
fstring_expr [12192,12219]
===
match
---
operator: = [3397,3398]
operator: = [3397,3398]
===
match
---
simple_stmt [13002,13087]
simple_stmt [12977,13062]
===
match
---
name: isclass [5510,5517]
name: isclass [5510,5517]
===
match
---
name: name [11148,11152]
name: name [11123,11127]
===
match
---
param [2666,2670]
param [2666,2670]
===
match
---
simple_stmt [5708,5721]
simple_stmt [5708,5721]
===
match
---
fstring_expr [3550,3561]
fstring_expr [3550,3561]
===
match
---
suite [9322,9690]
suite [9297,9665]
===
match
---
operator: = [1414,1415]
operator: = [1414,1415]
===
match
---
atom [12828,12830]
atom [12803,12805]
===
match
---
name: debug [6398,6403]
name: debug [6398,6403]
===
match
---
atom_expr [9299,9312]
atom_expr [9274,9287]
===
match
---
comp_op [10145,10151]
comp_op [10120,10126]
===
match
---
name: modules [7711,7718]
name: modules [7711,7718]
===
match
---
trailer [14616,14618]
trailer [14591,14593]
===
match
---
name: PLUGINS_FOLDER [9185,9199]
name: PLUGINS_FOLDER [9160,9174]
===
match
---
trailer [7398,7403]
trailer [7398,7403]
===
match
---
name: flask_appbuilder_menu_links [10044,10071]
name: flask_appbuilder_menu_links [10019,10046]
===
match
---
name: mod_attr_value [7962,7976]
name: mod_attr_value [7962,7976]
===
match
---
simple_stmt [1976,2025]
simple_stmt [1976,2025]
===
match
---
name: objects [8714,8721]
name: objects [8689,8696]
===
match
---
trailer [7132,7195]
trailer [7132,7195]
===
match
---
operator: , [4879,4880]
operator: , [4879,4880]
===
match
---
funcdef [3003,3078]
funcdef [3003,3078]
===
match
---
with_stmt [9294,9690]
with_stmt [9269,9665]
===
match
---
return_stmt [8447,8458]
return_stmt [8422,8433]
===
match
---
name: Any [1907,1910]
name: Any [1907,1910]
===
match
---
if_stmt [12866,12954]
if_stmt [12841,12929]
===
match
---
operator: , [14270,14271]
operator: , [14245,14246]
===
match
---
name: registered_hooks [9652,9668]
name: registered_hooks [9627,9643]
===
match
---
name: executors_module [13002,13018]
name: executors_module [12977,12993]
===
match
---
name: log [8207,8210]
name: log [8178,8181]
===
match
---
simple_stmt [7358,7426]
simple_stmt [7358,7426]
===
match
---
atom_expr [13620,13665]
atom_expr [13595,13640]
===
match
---
name: plugin_instance [6604,6619]
name: plugin_instance [6604,6619]
===
match
---
import_from [1124,1152]
import_from [1124,1152]
===
match
---
suite [7927,8103]
suite [7927,8103]
===
match
---
name: List [1756,1760]
name: List [1756,1760]
===
match
---
simple_stmt [13671,13706]
simple_stmt [13646,13681]
===
match
---
subscriptlist [1390,1398]
subscriptlist [1390,1398]
===
match
---
name: module [8565,8571]
name: module [8540,8546]
===
match
---
simple_stmt [14028,14109]
simple_stmt [14003,14084]
===
match
---
simple_stmt [13410,13432]
simple_stmt [13385,13407]
===
match
---
name: airflow [1129,1136]
name: airflow [1129,1136]
===
match
---
comparison [12681,12696]
comparison [12656,12671]
===
match
---
simple_stmt [3841,3863]
simple_stmt [3841,3863]
===
match
---
name: isfile [7310,7316]
name: isfile [7310,7316]
===
match
---
name: Exception [8118,8127]
name: Exception [8118,8127]
===
match
---
name: __module__ [12233,12243]
name: __module__ [12208,12218]
===
match
---
operator: = [9339,9340]
operator: = [9314,9315]
===
match
---
name: Any [1633,1636]
name: Any [1633,1636]
===
match
---
simple_stmt [13545,13552]
simple_stmt [13520,13527]
===
match
---
name: name [6451,6455]
name: name [6451,6455]
===
match
---
parameters [8356,8387]
parameters [8331,8362]
===
match
---
simple_stmt [1124,1153]
simple_stmt [1124,1153]
===
match
---
name: List [2007,2011]
name: List [2007,2011]
===
match
---
operator: } [12243,12244]
operator: } [12218,12219]
===
match
---
trailer [12930,12953]
trailer [12905,12928]
===
match
---
name: extend [12093,12099]
name: extend [12068,12074]
===
match
---
dotted_name [865,879]
dotted_name [865,879]
===
match
---
operator: , [9006,9007]
operator: , [8981,8982]
===
match
---
if_stmt [8423,8459]
if_stmt [8398,8434]
===
match
---
name: self [3486,3490]
name: self [3486,3490]
===
match
---
funcdef [3420,3504]
funcdef [3420,3504]
===
match
---
operator: { [3485,3486]
operator: { [3485,3486]
===
match
---
operator: = [3830,3831]
operator: = [3830,3831]
===
match
---
trailer [7901,7903]
trailer [7901,7903]
===
match
---
try_stmt [7486,8304]
try_stmt [7486,8279]
===
match
---
trailer [8210,8216]
trailer [8181,8191]
===
match
---
atom_expr [13910,13921]
atom_expr [13885,13896]
===
match
---
suite [2759,3078]
suite [2759,3078]
===
match
---
name: loader [7503,7509]
name: loader [7503,7509]
===
match
---
operator: { [12197,12198]
operator: { [12172,12173]
===
match
---
name: admin_views [3924,3935]
name: admin_views [3924,3935]
===
match
---
trailer [3490,3501]
trailer [3490,3501]
===
match
---
name: plugins [13750,13757]
name: plugins [13725,13732]
===
match
---
atom_expr [8377,8386]
atom_expr [8352,8361]
===
match
---
comparison [12869,12888]
comparison [12844,12863]
===
match
---
trailer [6885,6890]
trailer [6885,6890]
===
match
---
operator: , [2317,2318]
operator: , [2317,2318]
===
match
---
name: AirflowPlugin [5565,5578]
name: AirflowPlugin [5565,5578]
===
match
---
simple_stmt [2681,2707]
simple_stmt [2681,2707]
===
match
---
name: sys [13183,13186]
name: sys [13158,13161]
===
match
---
atom_expr [8620,8635]
atom_expr [8595,8610]
===
match
---
name: registered_hooks [9008,9024]
name: registered_hooks [8983,8999]
===
match
---
funcdef [4864,5154]
funcdef [4864,5154]
===
match
---
trailer [8571,8577]
trailer [8546,8552]
===
match
---
atom [4096,4098]
atom [4096,4098]
===
match
---
trailer [5509,5517]
trailer [5509,5517]
===
match
---
simple_stmt [7995,8054]
simple_stmt [7995,8054]
===
match
---
operator: = [3915,3916]
operator: = [3915,3916]
===
match
---
name: name [3761,3765]
name: name [3761,3765]
===
match
---
name: entrypoint [3212,3222]
name: entrypoint [3212,3222]
===
match
---
name: args [4882,4886]
name: args [4882,4886]
===
match
---
atom [10491,10493]
atom [10466,10468]
===
match
---
string: "global_operator_extra_links" [2431,2460]
string: "global_operator_extra_links" [2431,2460]
===
match
---
suite [11984,12368]
suite [11959,12343]
===
match
---
name: str [2073,2076]
name: str [2073,2076]
===
match
---
operator: { [11954,11955]
operator: { [11929,11930]
===
match
---
name: List [1532,1536]
name: List [1532,1536]
===
match
---
return_stmt [5708,5720]
return_stmt [5708,5720]
===
match
---
operator: = [1593,1594]
operator: = [1593,1594]
===
match
---
simple_stmt [12808,12831]
simple_stmt [12783,12806]
===
match
---
name: integrate_macros_plugins [14592,14616]
name: integrate_macros_plugins [14567,14591]
===
match
---
simple_stmt [14394,14527]
simple_stmt [14369,14502]
===
match
---
simple_stmt [14856,14885]
simple_stmt [14831,14860]
===
match
---
name: settings [7243,7251]
name: settings [7243,7251]
===
insert-tree
---
simple_stmt [787,814]
    string: """Manages all plugins.""" [787,813]
to
file_input [787,15019]
at 0
===
insert-tree
---
simple_stmt [2092,2275]
    string: """Mapping of class names to class of OperatorLinks registered by plugins.  Used by the DAG serialization code to only allow specific classes to be created during deserialization """ [2092,2274]
to
file_input [787,15019]
at 30
===
update-node
---
name: error [8211,8216]
replace error by exception
===
delete-tree
---
simple_stmt [787,814]
    string: """Manages all plugins.""" [787,813]
===
delete-tree
---
simple_stmt [2092,2275]
    string: """Mapping of class names to class of OperatorLinks registered by plugins.  Used by the DAG serialization code to only allow specific classes to be created during deserialization """ [2092,2274]
===
delete-tree
---
simple_stmt [8178,8195]
    atom_expr [8178,8194]
        name: log [8178,8181]
        trailer [8181,8191]
            name: exception [8182,8191]
        trailer [8191,8194]
            name: e [8192,8193]
