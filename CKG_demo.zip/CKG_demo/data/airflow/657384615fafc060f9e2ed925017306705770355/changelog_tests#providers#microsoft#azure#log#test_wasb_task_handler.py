===
match
---
decorator [6799,6868]
decorator [6694,6763]
===
match
---
name: filename_template [5018,5035]
name: filename_template [4983,5000]
===
match
---
operator: = [5615,5616]
operator: = [5510,5511]
===
match
---
trailer [7122,7142]
trailer [7017,7037]
===
match
---
string: 'wasb_default' [2367,2381]
string: 'wasb_default' [2337,2351]
===
match
---
name: datetime [807,815]
name: datetime [807,815]
===
match
---
trailer [4160,4175]
trailer [4125,4140]
===
match
---
name: azure [1124,1129]
name: azure [1094,1099]
===
match
---
name: wasb_task_handler [3751,3768]
name: wasb_task_handler [3716,3733]
===
match
---
arglist [7372,7392]
arglist [7267,7287]
===
match
---
operator: = [2091,2092]
operator: = [2061,2062]
===
match
---
name: wasb_task_handler [3604,3621]
name: wasb_task_handler [3569,3586]
===
match
---
atom_expr [2520,2569]
atom_expr [2490,2539]
===
match
---
name: self [6422,6426]
name: self [6317,6321]
===
match
---
argument [2129,2141]
argument [2099,2111]
===
match
---
name: return_value [6075,6087]
name: return_value [5970,5982]
===
match
---
dotted_name [1030,1074]
dotted_name [1000,1044]
===
match
---
trailer [5069,5075]
trailer [5034,5040]
===
match
---
file_input [786,7850]
file_input [786,7745]
===
match
---
suite [3500,3638]
suite [3465,3603]
===
match
---
operator: == [4534,4536]
operator: == [4499,4501]
===
match
---
name: log [2864,2867]
name: log [2834,2837]
===
match
---
arglist [4156,4201]
arglist [4121,4166]
===
match
---
trailer [5425,5449]
trailer [5390,5414]
===
match
---
simple_stmt [832,858]
simple_stmt [832,858]
===
match
---
trailer [1964,1977]
trailer [1934,1947]
===
match
---
trailer [7101,7116]
trailer [6996,7011]
===
match
---
atom_expr [3956,3992]
atom_expr [3921,3957]
===
match
---
trailer [1343,1349]
trailer [1313,1319]
===
match
---
operator: , [5316,5317]
operator: , [5281,5282]
===
match
---
name: upload_on_close [3622,3637]
name: upload_on_close [3587,3602]
===
match
---
arglist [2084,2141]
arglist [2054,2111]
===
match
---
name: self [2531,2535]
name: self [2501,2505]
===
match
---
name: self [5989,5993]
name: self [5884,5888]
===
match
---
name: load_string [6088,6099]
name: load_string [5983,5994]
===
match
---
operator: , [5620,5621]
operator: , [5515,5516]
===
match
---
operator: @ [5714,5715]
operator: @ [5609,5610]
===
match
---
name: self [3746,3750]
name: self [3711,3715]
===
match
---
operator: @ [6279,6280]
operator: @ [6174,6175]
===
match
---
name: assert_called_once_with [7052,7075]
name: assert_called_once_with [6947,6970]
===
match
---
atom_expr [1548,1567]
atom_expr [1518,1537]
===
match
---
name: task [2063,2067]
name: task [2033,2037]
===
match
---
trailer [6619,6639]
trailer [6514,6534]
===
match
---
simple_stmt [5989,6057]
simple_stmt [5884,5952]
===
match
---
dictorsetmaker [2587,2636]
dictorsetmaker [2557,2606]
===
match
---
trailer [4519,4524]
trailer [4484,4489]
===
match
---
arglist [7234,7330]
arglist [7129,7225]
===
match
---
testlist_comp [4617,4758]
testlist_comp [4582,4723]
===
match
---
string: "airflow.providers.microsoft.azure.hooks.wasb.BlobServiceClient" [2400,2464]
string: "airflow.providers.microsoft.azure.hooks.wasb.BlobServiceClient" [2370,2434]
===
match
---
name: wasb_read [4432,4441]
name: wasb_read [4397,4406]
===
match
---
suite [3905,4212]
suite [3870,4177]
===
match
---
name: wasb_task_handler [4013,4030]
name: wasb_task_handler [3978,3995]
===
match
---
string: 'error' [7385,7392]
string: 'error' [7280,7287]
===
match
---
operator: , [5801,5802]
operator: , [5696,5697]
===
match
---
argument [2084,2127]
argument [2054,2097]
===
match
---
operator: , [5748,5749]
operator: , [5643,5644]
===
match
---
name: local_log_location [1722,1740]
name: local_log_location [1692,1710]
===
match
---
string: "text" [6137,6143]
string: "text" [6032,6038]
===
match
---
string: 'Could not create an WasbHook with connection id "%s". ' [3205,3261]
string: 'Could not create an WasbHook with connection id "%s".' [3175,3230]
===
match
---
name: self [1493,1497]
name: self [1463,1467]
===
match
---
name: self [4309,4313]
name: self [4274,4278]
===
match
---
trailer [5267,5279]
trailer [5232,5244]
===
match
---
trailer [1497,1516]
trailer [1467,1486]
===
match
---
expr_stmt [4335,4393]
expr_stmt [4300,4358]
===
match
---
simple_stmt [3914,3948]
simple_stmt [3879,3913]
===
match
---
atom_expr [6031,6055]
atom_expr [5926,5950]
===
match
---
import_from [1025,1090]
import_from [995,1060]
===
match
---
name: mock_hook [3894,3903]
name: mock_hook [3859,3868]
===
match
---
name: mock_log_exists [6428,6443]
name: mock_log_exists [6323,6338]
===
match
---
name: wasb_task_handler [5994,6011]
name: wasb_task_handler [5889,5906]
===
match
---
decorator [5641,5710]
decorator [5536,5605]
===
match
---
name: providers [1104,1113]
name: providers [1074,1083]
===
match
---
string: "old log\ntext" [6721,6736]
string: "old log\ntext" [6616,6631]
===
match
---
trailer [4103,4118]
trailer [4068,4083]
===
match
---
name: remote_log_location [1435,1454]
name: remote_log_location [1405,1424]
===
match
---
name: instance [3956,3964]
name: instance [3921,3929]
===
match
---
name: DummyOperator [2070,2083]
name: DummyOperator [2040,2053]
===
match
---
name: RUNNING [2267,2274]
name: RUNNING [2237,2244]
===
match
---
trailer [1874,1892]
trailer [1844,1862]
===
match
---
name: wasb [1070,1074]
name: wasb [1040,1044]
===
match
---
simple_stmt [6573,6641]
simple_stmt [6468,6536]
===
match
---
string: "wasb-container" [1570,1586]
string: "wasb-container" [1540,1556]
===
match
---
operator: = [6510,6511]
operator: = [6405,6406]
===
match
---
string: 'text' [6968,6974]
string: 'text' [6863,6869]
===
match
---
with_item [5137,5217]
with_item [5102,5182]
===
match
---
simple_stmt [3509,3528]
simple_stmt [3474,3493]
===
match
---
dictorsetmaker [4828,4846]
dictorsetmaker [4793,4811]
===
match
---
trailer [2303,2307]
trailer [2273,2277]
===
match
---
trailer [2287,2298]
trailer [2257,2268]
===
match
---
atom_expr [6649,6793]
atom_expr [6544,6688]
===
match
---
atom_expr [1986,1994]
atom_expr [1956,1964]
===
match
---
dotted_name [1180,1199]
dotted_name [1150,1169]
===
match
---
name: object [5779,5785]
name: object [5674,5680]
===
match
---
string: "wasb_log_exists" [5803,5820]
string: "wasb_log_exists" [5698,5715]
===
match
---
string: 'logging' [2333,2342]
string: 'logging' [2303,2312]
===
match
---
suite [6472,6794]
suite [6367,6689]
===
match
---
trailer [7263,7279]
trailer [7158,7174]
===
match
---
operator: , [4175,4176]
operator: , [4140,4141]
===
match
---
trailer [2704,2824]
trailer [2674,2794]
===
match
---
assert_stmt [4490,4859]
assert_stmt [4455,4824]
===
match
---
name: load_string [7547,7558]
name: load_string [7442,7453]
===
match
---
name: self [2718,2722]
name: self [2688,2692]
===
match
---
with_stmt [5060,5636]
with_stmt [5025,5531]
===
match
---
param [1321,1325]
param [1291,1295]
===
match
---
operator: = [2178,2179]
operator: = [2148,2149]
===
match
---
name: microsoft [1048,1057]
name: microsoft [1018,1027]
===
match
---
trailer [2855,2877]
trailer [2825,2847]
===
match
---
import_name [786,801]
import_name [786,801]
===
match
---
funcdef [2470,2570]
funcdef [2440,2540]
===
match
---
parameters [6421,6471]
parameters [6316,6366]
===
match
---
expr_stmt [2214,2236]
expr_stmt [2184,2206]
===
match
---
atom_expr [2214,2232]
atom_expr [2184,2202]
===
match
---
name: handler [7631,7638]
name: handler [7526,7533]
===
match
---
name: self [7658,7662]
name: self [7553,7557]
===
match
---
name: self [2765,2769]
name: self [2735,2739]
===
match
---
operator: } [4846,4847]
operator: } [4811,4812]
===
match
---
dotted_name [4218,4228]
dotted_name [4183,4193]
===
match
---
operator: , [7116,7117]
operator: , [7011,7012]
===
match
---
simple_stmt [5415,5636]
simple_stmt [5380,5531]
===
match
---
trailer [4413,4431]
trailer [4378,4396]
===
match
---
atom_expr [3032,3072]
atom_expr [3002,3042]
===
match
---
string: '{try_number}.log' [1620,1638]
string: '{try_number}.log' [1590,1608]
===
match
---
name: airflow [1030,1037]
name: airflow [1000,1007]
===
match
---
simple_stmt [5948,5981]
simple_stmt [5843,5876]
===
match
---
simple_stmt [7017,7153]
simple_stmt [6912,7048]
===
match
---
trailer [4501,4519]
trailer [4466,4484]
===
match
---
name: hook [2554,2558]
name: hook [2524,2528]
===
match
---
suite [4326,4860]
suite [4291,4825]
===
match
---
trailer [3603,3621]
trailer [3568,3586]
===
match
---
string: "airflow.providers.microsoft.azure.hooks.wasb.WasbHook" [6218,6273]
string: "airflow.providers.microsoft.azure.hooks.wasb.WasbHook" [6113,6168]
===
match
---
name: handler [5083,5090]
name: handler [5048,5055]
===
match
---
trailer [4524,4533]
trailer [4489,4498]
===
match
---
atom [4537,4859]
atom [4502,4824]
===
match
---
atom_expr [2856,2867]
atom_expr [2826,2837]
===
match
---
name: self [1986,1990]
name: self [1956,1960]
===
match
---
param [4891,4895]
param [4856,4860]
===
match
---
suite [7507,7698]
suite [7402,7593]
===
match
---
dotted_name [6207,6217]
dotted_name [6102,6112]
===
match
---
string: "airflow.providers.microsoft.azure.hooks.wasb.WasbHook" [7437,7492]
string: "airflow.providers.microsoft.azure.hooks.wasb.WasbHook" [7332,7387]
===
match
---
assert_stmt [3739,3784]
assert_stmt [3704,3749]
===
match
---
name: DAG [1997,2000]
name: DAG [1967,1970]
===
match
---
name: airflow [1096,1103]
name: airflow [1066,1073]
===
match
---
decorator [6332,6387]
decorator [6227,6282]
===
match
---
param [3888,3893]
param [3853,3858]
===
match
---
with_item [2838,2891]
with_item [2808,2861]
===
match
---
trailer [3709,3721]
trailer [3674,3686]
===
match
---
dotted_name [980,1003]
dotted_name [950,973]
===
match
---
atom_expr [3127,3139]
atom_expr [3097,3109]
===
match
---
name: patch [2915,2920]
name: patch [2885,2890]
===
match
---
number: 1 [2235,2236]
number: 1 [2205,2206]
===
match
---
name: wasb_task_handler [6939,6956]
name: wasb_task_handler [6834,6851]
===
match
---
parameters [3493,3499]
parameters [3458,3464]
===
match
---
operator: , [6613,6614]
operator: , [6508,6509]
===
match
---
trailer [7051,7075]
trailer [6946,6970]
===
match
---
name: self [2664,2668]
name: self [2634,2638]
===
match
---
name: self [4156,4160]
name: self [4121,4125]
===
match
---
name: addCleanup [2288,2298]
name: addCleanup [2258,2268]
===
match
---
name: patch [5720,5725]
name: patch [5615,5620]
===
match
---
trailer [1651,1669]
trailer [1621,1639]
===
match
---
operator: = [5976,5977]
operator: = [5871,5872]
===
match
---
operator: , [5035,5036]
operator: , [5000,5001]
===
match
---
string: 'remote/log/location/1.log' [1457,1484]
string: 'remote/log/location/1.log' [1427,1454]
===
match
---
atom_expr [7573,7613]
atom_expr [7468,7508]
===
match
---
decorated [3790,4212]
decorated [3755,4177]
===
match
---
name: mock [5768,5772]
name: mock [5663,5667]
===
match
---
operator: , [3448,3449]
operator: , [3413,3414]
===
match
---
with_item [2910,2990]
with_item [2880,2960]
===
match
---
operator: @ [6799,6800]
operator: @ [6694,6695]
===
match
---
string: "failed to connect" [7588,7607]
string: "failed to connect" [7483,7502]
===
match
---
string: 'text' [7650,7656]
string: 'text' [7545,7551]
===
match
---
expr_stmt [2151,2205]
expr_stmt [2121,2175]
===
match
---
name: self [4992,4996]
name: self [4957,4961]
===
match
---
operator: = [1618,1619]
operator: = [1588,1589]
===
match
---
name: return_value [3935,3947]
name: return_value [3900,3912]
===
match
---
trailer [6539,6552]
trailer [6434,6447]
===
match
---
decorator [2320,2384]
decorator [2290,2354]
===
match
---
trailer [6595,6606]
trailer [6490,6501]
===
match
---
decorator [6206,6275]
decorator [6101,6170]
===
match
---
name: self [7281,7285]
name: self [7176,7180]
===
match
---
number: 8 [1971,1972]
number: 8 [1941,1942]
===
match
---
trailer [7649,7697]
trailer [7544,7592]
===
match
---
name: wasb_read [5348,5357]
name: wasb_read [5313,5322]
===
match
---
name: mock_wasb_read [6445,6459]
name: mock_wasb_read [6340,6354]
===
match
---
trailer [5017,5035]
trailer [4982,5000]
===
match
---
name: self [2786,2790]
name: self [2756,2760]
===
match
---
name: wasb_log_folder [7264,7279]
name: wasb_log_folder [7159,7174]
===
match
---
name: self [3888,3892]
name: self [3853,3857]
===
match
---
parameters [4308,4325]
parameters [4273,4290]
===
match
---
name: container_name [1824,1838]
name: container_name [1794,1808]
===
match
---
simple_stmt [3588,3638]
simple_stmt [3553,3603]
===
match
---
trailer [4357,4367]
trailer [4322,4332]
===
match
---
name: self [1548,1552]
name: self [1518,1522]
===
match
---
atom_expr [1819,1838]
atom_expr [1789,1808]
===
match
---
name: object [6291,6297]
name: object [6186,6192]
===
match
---
name: self [7259,7263]
name: self [7154,7158]
===
match
---
trailer [7371,7393]
trailer [7266,7288]
===
match
---
trailer [3979,3992]
trailer [3944,3957]
===
match
---
simple_stmt [5904,5940]
simple_stmt [5799,5835]
===
match
---
name: test_hook [2474,2483]
name: test_hook [2444,2453]
===
match
---
name: test_wasb_log_exists [3867,3887]
name: test_wasb_log_exists [3832,3852]
===
match
---
name: mock_hook [4315,4324]
name: mock_hook [4280,4289]
===
match
---
name: exc_info [5607,5615]
name: exc_info [5502,5510]
===
match
---
atom_expr [2151,2158]
atom_expr [2121,2128]
===
match
---
simple_stmt [1025,1091]
simple_stmt [995,1061]
===
match
---
dotted_name [1096,1151]
dotted_name [1066,1121]
===
match
---
trailer [4441,4467]
trailer [4406,4432]
===
match
---
argument [1701,1740]
argument [1671,1710]
===
match
---
argument [2174,2183]
argument [2144,2153]
===
match
---
simple_stmt [1430,1485]
simple_stmt [1400,1455]
===
match
---
trailer [1552,1567]
trailer [1522,1537]
===
match
---
string: "text" [7089,7095]
string: "text" [6984,6990]
===
match
---
name: mock_hook [6914,6923]
name: mock_hook [6809,6818]
===
match
---
name: side_effect [3018,3029]
name: side_effect [2988,2999]
===
match
---
trailer [4949,4968]
trailer [4914,4933]
===
match
---
name: remote_log_location [6620,6639]
name: remote_log_location [6515,6534]
===
match
---
argument [2038,2053]
argument [2008,2023]
===
match
---
dotted_name [2389,2399]
dotted_name [2359,2369]
===
match
---
simple_stmt [2513,2570]
simple_stmt [2483,2540]
===
match
---
trailer [6956,6967]
trailer [6851,6862]
===
match
---
name: object [5726,5732]
name: object [5621,5627]
===
match
---
name: return_value [3980,3992]
name: return_value [3945,3957]
===
match
---
trailer [4996,5011]
trailer [4961,4976]
===
match
---
operator: = [7571,7572]
operator: = [7466,7467]
===
match
---
name: self [5358,5362]
name: self [5323,5327]
===
match
---
name: self [4945,4949]
name: self [4910,4914]
===
match
---
atom_expr [2133,2141]
atom_expr [2103,2111]
===
match
---
name: AzureHttpError [3032,3046]
name: AzureHttpError [3002,3016]
===
match
---
expr_stmt [1493,1539]
expr_stmt [1463,1509]
===
match
---
trailer [2863,2867]
trailer [2833,2837]
===
match
---
arglist [6137,6190]
arglist [6032,6085]
===
match
---
name: wasb_write [6957,6967]
name: wasb_write [6852,6862]
===
match
---
atom_expr [4008,4072]
atom_expr [3973,4037]
===
match
---
funcdef [7158,7850]
funcdef [7053,7745]
===
match
---
trailer [6496,6509]
trailer [6391,6404]
===
match
---
atom_expr [6759,6783]
atom_expr [6654,6678]
===
match
---
number: 404 [7609,7612]
number: 404 [7504,7507]
===
match
---
name: setUp [1344,1349]
name: setUp [1314,1319]
===
match
---
name: AzureHttpError [5282,5296]
name: AzureHttpError [5247,5261]
===
match
---
trailer [7026,7039]
trailer [6921,6934]
===
match
---
trailer [1434,1454]
trailer [1404,1424]
===
match
---
atom_expr [3925,3947]
atom_expr [3890,3912]
===
match
---
trailer [2137,2141]
trailer [2107,2111]
===
match
---
name: ti [2156,2158]
name: ti [2126,2128]
===
match
---
name: mock_hook [7524,7533]
name: mock_hook [7419,7428]
===
match
---
operator: , [5866,5867]
operator: , [5761,5762]
===
match
---
number: 404 [3068,3071]
number: 404 [3038,3041]
===
match
---
trailer [5357,5402]
trailer [5322,5367]
===
match
---
name: mock_hook [7017,7026]
name: mock_hook [6912,6921]
===
match
---
name: object [5076,5082]
name: object [5041,5047]
===
match
---
name: datetime [823,831]
name: datetime [823,831]
===
match
---
trailer [2747,2763]
trailer [2717,2733]
===
match
---
name: ti [2219,2221]
name: ti [2189,2191]
===
match
---
trailer [5082,5104]
trailer [5047,5069]
===
match
---
string: "wasb_read" [6315,6326]
string: "wasb_read" [6210,6221]
===
match
---
name: test_write_when_append_is_false [6876,6907]
name: test_write_when_append_is_false [6771,6802]
===
match
---
operator: { [4827,4828]
operator: { [4792,4793]
===
match
---
expr_stmt [7524,7613]
expr_stmt [7419,7508]
===
match
---
atom_expr [4177,4201]
atom_expr [4142,4166]
===
match
---
name: return_value [7534,7546]
name: return_value [7429,7441]
===
match
---
operator: , [2488,2489]
operator: , [2458,2459]
===
match
---
name: dag [2304,2307]
name: dag [2274,2277]
===
match
---
name: wasb_task_handler [3541,3558]
name: wasb_task_handler [3506,3523]
===
match
---
arglist [7588,7612]
arglist [7483,7507]
===
match
---
string: 'dag_for_testing_file_task_handler' [2001,2036]
string: 'dag_for_testing_file_task_handler' [1971,2006]
===
match
---
operator: = [5933,5934]
operator: = [5828,5829]
===
match
---
name: self [3687,3691]
name: self [3652,3656]
===
match
---
string: "airflow.providers.microsoft.azure.hooks.wasb.WasbHook" [5148,5203]
string: "airflow.providers.microsoft.azure.hooks.wasb.WasbHook" [5113,5168]
===
match
---
with_stmt [7349,7850]
with_stmt [7244,7745]
===
match
---
name: log [5091,5094]
name: log [5056,5059]
===
match
---
trailer [7238,7257]
trailer [7133,7152]
===
match
---
name: self [3494,3498]
name: self [3459,3463]
===
match
---
atom_expr [2838,2877]
atom_expr [2808,2847]
===
match
---
import_as_names [957,974]
import_as_names [927,944]
===
match
---
name: wasb_log_folder [1365,1380]
name: wasb_log_folder [1335,1350]
===
match
---
trailer [1721,1740]
trailer [1691,1710]
===
match
---
arglist [6721,6783]
arglist [6616,6678]
===
match
---
string: 'error' [2869,2876]
string: 'error' [2839,2846]
===
match
---
expr_stmt [6525,6564]
expr_stmt [6420,6459]
===
match
---
operator: , [6164,6165]
operator: , [6059,6060]
===
match
---
trailer [2769,2784]
trailer [2739,2754]
===
match
---
name: assert_called_once_with [4119,4142]
name: assert_called_once_with [4084,4107]
===
match
---
suite [5119,5636]
suite [5084,5531]
===
match
---
string: 'Could not read logs from remote/log/location/1.log' [5516,5568]
string: 'Could not read logs from remote/log/location/1.log' [5432,5484]
===
match
---
trailer [4012,4030]
trailer [3977,3995]
===
match
---
trailer [2266,2274]
trailer [2236,2244]
===
match
---
trailer [3691,3709]
trailer [3656,3674]
===
match
---
parameters [7179,7185]
parameters [7074,7080]
===
match
---
atom [2587,2620]
atom [2557,2590]
===
match
---
decorated [6206,6794]
decorated [6101,6689]
===
match
---
name: mock [7354,7358]
name: mock [7249,7253]
===
match
---
name: WasbHook [2560,2568]
name: WasbHook [2530,2538]
===
match
---
operator: , [7791,7792]
operator: , [7686,7687]
===
match
---
simple_stmt [7711,7850]
simple_stmt [7606,7745]
===
match
---
name: check_for_blob [3965,3979]
name: check_for_blob [3930,3944]
===
match
---
simple_stmt [4081,4212]
simple_stmt [4046,4177]
===
match
---
name: base_log_folder [1701,1716]
name: base_log_folder [1671,1686]
===
match
---
string: 'text' [6607,6613]
string: 'text' [6502,6508]
===
match
---
operator: = [1670,1671]
operator: = [1640,1641]
===
match
---
name: self [1870,1874]
name: self [1840,1844]
===
match
---
name: return_value [6540,6552]
name: return_value [6435,6447]
===
match
---
import_from [802,831]
import_from [802,831]
===
match
---
dotted_name [935,949]
dotted_name [905,919]
===
match
---
suite [5895,6201]
suite [5790,6096]
===
match
---
name: state [2253,2258]
name: state [2223,2228]
===
match
---
trailer [1823,1838]
trailer [1793,1808]
===
match
---
name: self [3672,3676]
name: self [3637,3641]
===
match
---
funcdef [1311,2315]
funcdef [1281,2285]
===
match
---
operator: = [1995,1996]
operator: = [1965,1966]
===
match
---
trailer [6149,6164]
trailer [6044,6059]
===
match
---
trailer [2000,2054]
trailer [1970,2024]
===
match
---
name: self [1595,1599]
name: self [1565,1569]
===
match
---
name: self [4047,4051]
name: self [4012,4016]
===
match
---
operator: , [2784,2785]
operator: , [2754,2755]
===
match
---
atom_expr [4525,4532]
atom_expr [4490,4497]
===
match
---
name: self [3599,3603]
name: self [3564,3568]
===
match
---
name: self [4970,4974]
name: self [4935,4939]
===
match
---
trailer [3726,3729]
trailer [3691,3694]
===
match
---
param [6428,6444]
param [6323,6339]
===
match
---
trailer [6980,7000]
trailer [6875,6895]
===
match
---
name: log [7380,7383]
name: log [7275,7278]
===
match
---
suite [2504,2570]
suite [2474,2540]
===
match
---
name: ti [4530,4532]
name: ti [4495,4497]
===
match
---
trailer [2218,2221]
trailer [2188,2191]
===
match
---
string: "old log" [6555,6564]
string: "old log" [6450,6459]
===
match
---
operator: , [3892,3893]
operator: , [3857,3858]
===
match
---
atom_expr [3571,3578]
atom_expr [3536,3543]
===
match
---
simple_stmt [6065,6201]
simple_stmt [5960,6096]
===
match
---
name: self [4008,4012]
name: self [3973,3977]
===
match
---
suite [1327,2315]
suite [1297,2285]
===
match
---
trailer [6967,7008]
trailer [6862,6903]
===
match
---
atom_expr [6525,6552]
atom_expr [6420,6447]
===
match
---
dotted_name [5642,5652]
dotted_name [5537,5547]
===
match
---
trailer [2535,2553]
trailer [2505,2523]
===
match
---
name: try_number [2222,2232]
name: try_number [2192,2202]
===
match
---
arglist [5083,5103]
arglist [5048,5068]
===
match
---
string: 'logging' [2588,2597]
string: 'logging' [2558,2567]
===
match
---
trailer [3134,3139]
trailer [3104,3109]
===
match
---
name: self [2283,2287]
name: self [2253,2257]
===
match
---
name: mock [7426,7430]
name: mock [7321,7325]
===
match
---
operator: = [3521,3522]
operator: = [3486,3487]
===
match
---
operator: , [7656,7657]
operator: , [7551,7552]
===
match
---
name: test_write_log [5830,5844]
name: test_write_log [5725,5739]
===
match
---
name: container_name [6150,6164]
name: container_name [6045,6059]
===
match
---
name: mock [853,857]
name: mock [853,857]
===
match
---
name: patch [5070,5075]
name: patch [5035,5040]
===
match
---
name: mock_hook [7497,7506]
name: mock_hook [7392,7401]
===
match
---
operator: @ [2320,2321]
operator: @ [2290,2291]
===
match
---
operator: , [3395,3396]
operator: , [3350,3351]
===
match
---
trailer [2083,2142]
trailer [2053,2112]
===
match
---
name: task_id [2084,2091]
name: task_id [2054,2061]
===
match
---
name: log [1130,1133]
name: log [1100,1103]
===
match
---
operator: = [3923,3924]
operator: = [3888,3889]
===
match
---
name: handler [3127,3134]
name: handler [3097,3104]
===
match
---
name: instance [3914,3922]
name: instance [3879,3887]
===
match
---
dotted_name [1218,1241]
dotted_name [1188,1211]
===
match
---
name: providers [1038,1047]
name: providers [1008,1017]
===
match
---
simple_stmt [1949,1978]
simple_stmt [1919,1948]
===
match
---
name: self [2743,2747]
name: self [2713,2717]
===
match
---
trailer [7533,7546]
trailer [7428,7441]
===
match
---
operator: { [2331,2332]
operator: { [2301,2302]
===
match
---
string: 'remote_log_conn_id' [2599,2619]
string: 'remote_log_conn_id' [2569,2589]
===
match
---
atom_expr [4047,4071]
atom_expr [4012,4036]
===
match
---
name: return_value [4345,4357]
name: return_value [4310,4322]
===
match
---
trailer [4030,4046]
trailer [3995,4011]
===
match
---
name: WasbTaskHandler [4916,4931]
name: WasbTaskHandler [4881,4896]
===
match
---
simple_stmt [2063,2143]
simple_stmt [2033,2113]
===
match
---
operator: = [5396,5397]
operator: = [5361,5362]
===
match
---
atom_expr [7205,7340]
atom_expr [7100,7235]
===
match
---
name: read_file [5258,5267]
name: read_file [5223,5232]
===
match
---
atom_expr [1997,2054]
atom_expr [1967,2024]
===
match
---
string: 'Please make sure that airflow[azure] is installed and ' [3278,3334]
string: ' Please make sure that airflow[azure] is installed' [3247,3299]
===
match
---
name: mock_wasb_read [5948,5962]
name: mock_wasb_read [5843,5857]
===
match
---
operator: = [1769,1770]
operator: = [1739,1740]
===
match
---
name: models [943,949]
name: models [913,919]
===
match
---
operator: , [1972,1973]
operator: , [1942,1943]
===
match
---
atom_expr [6145,6164]
atom_expr [6040,6059]
===
match
---
name: wasb_task_handler [4414,4431]
name: wasb_task_handler [4379,4396]
===
match
---
name: return_value [5245,5257]
name: return_value [5210,5222]
===
match
---
with_stmt [2833,3464]
with_stmt [2803,3429]
===
match
---
trailer [2790,2808]
trailer [2760,2778]
===
match
---
trailer [7662,7682]
trailer [7557,7577]
===
match
---
trailer [2530,2569]
trailer [2500,2539]
===
match
---
name: return_value [6497,6509]
name: return_value [6392,6404]
===
match
---
name: WasbTaskHandler [6351,6366]
name: WasbTaskHandler [6246,6261]
===
match
---
operator: = [1517,1518]
operator: = [1487,1488]
===
match
---
atom [4551,4812]
atom [4516,4777]
===
match
---
name: conf_vars [1249,1258]
name: conf_vars [1219,1228]
===
match
---
suite [6925,7153]
suite [6820,7048]
===
match
---
atom_expr [3008,3029]
atom_expr [2978,2999]
===
match
---
atom_expr [6934,7008]
atom_expr [6829,6903]
===
match
---
operator: @ [5767,5768]
operator: @ [5662,5663]
===
match
---
operator: = [7830,7831]
operator: = [7725,7726]
===
match
---
name: mock_hook [6649,6658]
name: mock_hook [6544,6553]
===
match
---
trailer [7075,7152]
trailer [6970,7047]
===
match
---
operator: @ [4217,4218]
operator: @ [4182,4183]
===
match
---
decorator [5767,5822]
decorator [5662,5717]
===
match
---
trailer [5449,5635]
trailer [5414,5530]
===
match
---
name: AzureHttpError [914,928]
name: AzureHttpError [884,898]
===
match
---
name: mock_hook [4335,4344]
name: mock_hook [4300,4309]
===
match
---
name: datetime [1956,1964]
name: datetime [1926,1934]
===
match
---
atom_expr [1595,1617]
atom_expr [1565,1587]
===
match
---
expr_stmt [4906,5051]
expr_stmt [4871,5016]
===
match
---
operator: @ [2388,2389]
operator: @ [2358,2359]
===
match
---
arglist [2531,2568]
arglist [2501,2538]
===
match
---
expr_stmt [1548,1586]
expr_stmt [1518,1556]
===
match
---
atom_expr [2910,2977]
atom_expr [2880,2947]
===
match
---
trailer [3046,3072]
trailer [3016,3042]
===
match
---
name: remote_log_location [5363,5382]
name: remote_log_location [5328,5347]
===
match
---
name: self [5013,5017]
name: self [4978,4982]
===
match
---
name: airflow [980,987]
name: airflow [950,957]
===
match
---
testlist_comp [2333,2364]
testlist_comp [2303,2334]
===
match
---
operator: = [1818,1819]
operator: = [1788,1789]
===
match
---
arglist [5733,5761]
arglist [5628,5656]
===
match
---
expr_stmt [3509,3527]
expr_stmt [3474,3492]
===
match
---
name: self [7097,7101]
name: self [6992,6996]
===
match
---
operator: , [4757,4758]
operator: , [4722,4723]
===
match
---
atom_expr [7118,7142]
atom_expr [7013,7037]
===
match
---
argument [7684,7696]
argument [7579,7591]
===
match
---
name: container_name [4161,4175]
name: container_name [4126,4140]
===
match
---
atom_expr [6166,6190]
atom_expr [6061,6085]
===
match
---
trailer [4046,4072]
trailer [4011,4037]
===
match
---
assert_stmt [3588,3637]
assert_stmt [3553,3602]
===
match
---
trailer [4446,4466]
trailer [4411,4431]
===
match
---
param [2664,2668]
param [2634,2638]
===
match
---
name: hooks [1064,1069]
name: hooks [1034,1039]
===
match
---
atom_expr [5340,5402]
atom_expr [5305,5367]
===
match
---
atom_expr [7711,7849]
atom_expr [7606,7744]
===
match
---
import_from [930,974]
import_from [900,944]
===
match
---
operator: , [6313,6314]
operator: , [6208,6209]
===
match
---
name: self [4442,4446]
name: self [4407,4411]
===
match
---
name: test_utils [1224,1234]
name: test_utils [1194,1204]
===
match
---
operator: , [6757,6758]
operator: , [6652,6653]
===
match
---
string: 'the Wasb connection exists. Exception "%s"' [3351,3395]
string: ' and the Wasb connection exists.' [3316,3350]
===
match
---
name: handler [2856,2863]
name: handler [2826,2833]
===
match
---
name: filename_template [2791,2808]
name: filename_template [2761,2778]
===
match
---
parameters [3887,3904]
parameters [3852,3869]
===
match
---
name: container_name [4997,5011]
name: container_name [4962,4976]
===
match
---
name: self [1717,1721]
name: self [1687,1691]
===
match
---
operator: , [5882,5883]
operator: , [5777,5778]
===
match
---
simple_stmt [5235,5323]
simple_stmt [5200,5288]
===
match
---
trailer [7745,7849]
trailer [7640,7744]
===
match
---
operator: == [4468,4470]
operator: == [4433,4435]
===
match
---
name: container_name [1553,1567]
name: container_name [1523,1537]
===
match
---
trailer [5962,5975]
trailer [5857,5870]
===
match
---
trailer [6087,6099]
trailer [5982,5994]
===
match
---
operator: , [7257,7258]
operator: , [7152,7153]
===
match
---
name: return_error [5384,5396]
name: return_error [5349,5361]
===
match
---
parameters [4890,4896]
parameters [4855,4861]
===
match
---
operator: , [7095,7096]
operator: , [6990,6991]
===
match
---
operator: , [7820,7821]
operator: , [7715,7716]
===
match
---
name: self [3509,3513]
name: self [3474,3478]
===
match
---
decorated [5641,6201]
decorated [5536,6096]
===
match
---
trailer [5919,5932]
trailer [5814,5827]
===
match
---
operator: = [2687,2688]
operator: = [2657,2658]
===
match
---
name: self [4177,4181]
name: self [4142,4146]
===
match
---
trailer [6170,6190]
trailer [6065,6085]
===
match
---
operator: , [1969,1970]
operator: , [1939,1940]
===
match
---
trailer [2249,2252]
trailer [2219,2222]
===
match
---
operator: , [5568,5569]
operator: , [5484,5485]
===
match
---
trailer [3934,3947]
trailer [3899,3912]
===
match
---
trailer [2722,2741]
trailer [2692,2711]
===
match
---
decorators [2320,2466]
decorators [2290,2436]
===
match
---
atom_expr [5083,5094]
atom_expr [5048,5059]
===
match
---
name: ti [3514,3516]
name: ti [3479,3481]
===
match
---
atom_expr [7259,7279]
atom_expr [7154,7174]
===
match
---
operator: , [1892,1893]
operator: , [1862,1863]
===
match
---
name: self [4525,4529]
name: self [4490,4494]
===
match
---
trailer [3187,3463]
trailer [3157,3428]
===
match
---
expr_stmt [1949,1977]
expr_stmt [1919,1947]
===
match
---
simple_stmt [4335,4394]
simple_stmt [4300,4359]
===
match
---
name: read [4520,4524]
name: read [4485,4489]
===
match
---
trailer [3163,3187]
trailer [3133,3157]
===
match
---
name: wasb_write [6012,6022]
name: wasb_write [5907,5917]
===
match
---
decorator [4217,4286]
decorator [4182,4251]
===
match
---
name: remote_log_location [4052,4071]
name: remote_log_location [4017,4036]
===
match
---
name: wasb_task_handler [2536,2553]
name: wasb_task_handler [2506,2523]
===
match
---
name: mock_hook [5235,5244]
name: mock_hook [5200,5209]
===
match
---
trailer [2155,2158]
trailer [2125,2128]
===
match
---
name: self [2133,2137]
name: self [2103,2107]
===
match
---
name: self [2299,2303]
name: self [2269,2273]
===
match
---
name: dag [2129,2132]
name: dag [2099,2102]
===
match
---
operator: = [3993,3994]
operator: = [3958,3959]
===
match
---
with_item [7426,7506]
with_item [7321,7401]
===
match
---
arglist [6023,6055]
arglist [5918,5950]
===
match
---
operator: = [3030,3031]
operator: = [3000,3001]
===
match
---
operator: , [7300,7301]
operator: , [7195,7196]
===
match
---
name: assert_called_once_with [3164,3187]
name: assert_called_once_with [3134,3157]
===
match
---
name: return_value [5963,5975]
name: return_value [5858,5870]
===
match
---
operator: , [4313,4314]
operator: , [4278,4279]
===
match
---
name: remote_log_location [6764,6783]
name: remote_log_location [6659,6678]
===
match
---
expr_stmt [3956,3999]
expr_stmt [3921,3964]
===
match
---
argument [5384,5401]
argument [5349,5366]
===
match
---
trailer [4142,4211]
trailer [4107,4176]
===
match
---
trailer [4090,4103]
trailer [4055,4068]
===
match
---
trailer [4974,4990]
trailer [4939,4955]
===
match
---
atom_expr [7658,7682]
atom_expr [7553,7577]
===
match
---
comparison [4409,4481]
comparison [4374,4446]
===
match
---
name: wasb_write [6596,6606]
name: wasb_write [6491,6501]
===
match
---
atom_expr [1430,1454]
atom_expr [1400,1424]
===
match
---
operator: = [1869,1870]
operator: = [1839,1840]
===
match
---
name: test_wasb_read [4294,4308]
name: test_wasb_read [4259,4273]
===
match
---
atom_expr [2245,2258]
atom_expr [2215,2228]
===
match
---
atom_expr [3687,3730]
atom_expr [3652,3695]
===
match
---
atom_expr [4156,4175]
atom_expr [4121,4140]
===
match
---
funcdef [5826,6201]
funcdef [5721,6096]
===
match
---
decorated [4217,4860]
decorated [4182,4825]
===
match
---
string: "wasb_default" [3413,3427]
string: 'wasb_default' [3368,3382]
===
match
---
operator: , [4968,4969]
operator: , [4933,4934]
===
match
---
name: mock [6280,6284]
name: mock [6175,6179]
===
match
---
atom_expr [6065,6200]
atom_expr [5960,6095]
===
match
---
name: patch [6285,6290]
name: patch [6180,6185]
===
match
---
name: AzureHttpError [7573,7587]
name: AzureHttpError [7468,7482]
===
match
---
string: '' [4617,4619]
string: '' [4582,4584]
===
match
---
atom_expr [7354,7393]
atom_expr [7249,7288]
===
match
---
expr_stmt [1647,1939]
expr_stmt [1617,1909]
===
match
---
name: common [900,906]
name: common [870,876]
===
match
---
suite [2991,3140]
suite [2961,3110]
===
match
---
string: "wasb_read" [5750,5761]
string: "wasb_read" [5645,5656]
===
match
---
number: 404 [5318,5321]
number: 404 [5283,5286]
===
match
---
trailer [4118,4142]
trailer [4083,4107]
===
match
---
name: self [6031,6035]
name: self [5926,5930]
===
match
---
trailer [2307,2313]
trailer [2277,2283]
===
match
---
name: self [7118,7122]
name: self [7013,7017]
===
match
---
arglist [2001,2053]
arglist [1971,2023]
===
match
---
name: mock_wasb_read [6525,6539]
name: mock_wasb_read [6420,6434]
===
match
---
trailer [2848,2855]
trailer [2818,2825]
===
match
---
not_test [3595,3637]
not_test [3560,3602]
===
match
---
param [6908,6913]
param [6803,6808]
===
match
---
name: set_context [3710,3721]
name: set_context [3675,3686]
===
match
---
name: mock [5715,5719]
name: mock [5610,5614]
===
match
---
name: mock_hook [6461,6470]
name: mock_hook [6356,6365]
===
match
---
name: self [6145,6149]
name: self [6040,6044]
===
match
---
string: "airflow.providers.microsoft.azure.hooks.wasb.WasbHook" [3802,3857]
string: "airflow.providers.microsoft.azure.hooks.wasb.WasbHook" [3767,3822]
===
match
---
arglist [6607,6639]
arglist [6502,6534]
===
match
---
atom_expr [5904,5932]
atom_expr [5799,5827]
===
match
---
decorator [6279,6328]
decorator [6174,6223]
===
match
---
simple_stmt [1175,1213]
simple_stmt [1145,1183]
===
match
---
funcdef [3643,3785]
funcdef [3608,3750]
===
match
---
arglist [2174,2204]
arglist [2144,2174]
===
match
---
operator: = [2159,2160]
operator: = [2129,2130]
===
match
---
trailer [5147,5204]
trailer [5112,5169]
===
match
---
string: 'wasb_default' [2622,2636]
string: 'wasb_default' [2592,2606]
===
match
---
argument [1906,1928]
argument [1876,1898]
===
match
---
expr_stmt [5904,5939]
expr_stmt [5799,5834]
===
match
---
string: 'remote_log_conn_id' [2344,2364]
string: 'remote_log_conn_id' [2314,2334]
===
match
---
name: clear [2308,2313]
name: clear [2278,2283]
===
match
---
name: dag [1991,1994]
name: dag [1961,1964]
===
match
---
arglist [5297,5321]
arglist [5262,5286]
===
match
---
name: self [4891,4895]
name: self [4856,4860]
===
match
---
param [3494,3498]
param [3459,3463]
===
match
---
name: mock [4218,4222]
name: mock [4183,4187]
===
match
---
name: WasbTaskHandler [1159,1174]
name: WasbTaskHandler [1129,1144]
===
match
---
name: handler [4906,4913]
name: handler [4871,4878]
===
match
---
operator: , [6974,6975]
operator: , [6869,6870]
===
match
---
trailer [7430,7436]
trailer [7325,7331]
===
match
---
arglist [6351,6385]
arglist [6246,6280]
===
match
---
name: mock [5137,5141]
name: mock [5102,5106]
===
match
---
name: return_value [6659,6671]
name: return_value [6554,6566]
===
match
---
operator: , [1838,1839]
operator: , [1808,1809]
===
match
---
name: conf_vars [2576,2585]
name: conf_vars [2546,2555]
===
match
---
operator: , [5011,5012]
operator: , [4976,4977]
===
match
---
name: handler [7372,7379]
name: handler [7267,7274]
===
match
---
atom_expr [5358,5382]
atom_expr [5323,5347]
===
match
---
name: wasb_log_folder [1775,1790]
name: wasb_log_folder [1745,1760]
===
match
---
name: object [2849,2855]
name: object [2819,2825]
===
match
---
simple_stmt [3536,3580]
simple_stmt [3501,3545]
===
match
---
name: self [6976,6980]
name: self [6871,6875]
===
match
---
simple_stmt [1493,1540]
simple_stmt [1463,1510]
===
match
---
operator: = [2199,2200]
operator: = [2169,2170]
===
match
---
name: load_string [6672,6683]
name: load_string [6567,6578]
===
match
---
suite [7186,7850]
suite [7081,7745]
===
match
---
simple_stmt [1336,1352]
simple_stmt [1306,1322]
===
match
---
atom [2332,2365]
atom [2302,2335]
===
match
---
name: DummyOperator [1011,1024]
name: DummyOperator [981,994]
===
match
---
trailer [4367,4380]
trailer [4332,4345]
===
match
---
atom [4569,4798]
atom [4534,4763]
===
match
---
with_stmt [7421,7698]
with_stmt [7316,7593]
===
match
---
name: task [2179,2183]
name: task [2149,2153]
===
match
---
name: upload_on_close [3769,3784]
name: upload_on_close [3734,3749]
===
match
---
name: return_value [4091,4103]
name: return_value [4056,4068]
===
match
---
assert_stmt [2513,2569]
assert_stmt [2483,2539]
===
match
---
name: local_log_location [2723,2741]
name: local_log_location [2693,2711]
===
match
---
operator: , [6029,6030]
operator: , [5924,5925]
===
match
---
name: container_name [6743,6757]
name: container_name [6638,6652]
===
match
---
operator: , [2127,2128]
operator: , [2097,2098]
===
match
---
funcdef [6872,7153]
funcdef [6767,7048]
===
match
---
name: handler [7195,7202]
name: handler [7090,7097]
===
match
---
trailer [2298,2314]
trailer [2268,2284]
===
match
---
arglist [5467,5621]
arglist [5432,5516]
===
match
---
operator: , [6459,6460]
operator: , [6354,6355]
===
match
---
number: 10 [1974,1976]
number: 10 [1944,1946]
===
match
---
simple_stmt [2679,2825]
simple_stmt [2649,2795]
===
match
---
simple_stmt [6934,7009]
simple_stmt [6829,6904]
===
match
---
simple_stmt [4008,4073]
simple_stmt [3973,4038]
===
match
---
trailer [4431,4441]
trailer [4396,4406]
===
match
---
operator: , [6143,6144]
operator: , [6038,6039]
===
match
---
name: patch [5142,5147]
name: patch [5107,5112]
===
match
---
param [4315,4324]
param [4280,4289]
===
match
---
name: remote_log_location [4182,4201]
name: remote_log_location [4147,4166]
===
match
---
trailer [4181,4201]
trailer [4146,4166]
===
match
---
suite [3678,3785]
suite [3643,3750]
===
match
---
name: patch [6805,6810]
name: patch [6700,6705]
===
match
---
arglist [1965,1976]
arglist [1935,1946]
===
match
---
argument [1754,1790]
argument [1724,1760]
===
match
---
name: self [6934,6938]
name: self [6829,6833]
===
match
---
dotted_name [5768,5785]
dotted_name [5663,5680]
===
match
---
param [5884,5893]
param [5779,5788]
===
match
---
name: mock [6333,6337]
name: mock [6228,6232]
===
match
---
trailer [7358,7364]
trailer [7253,7259]
===
match
---
operator: } [2636,2637]
operator: } [2606,2607]
===
match
---
import_from [975,1024]
import_from [945,994]
===
match
---
name: side_effect [5268,5279]
name: side_effect [5233,5244]
===
match
---
simple_stmt [1647,1940]
simple_stmt [1617,1910]
===
match
---
name: remote_log_location [7663,7682]
name: remote_log_location [7558,7577]
===
match
---
name: mock [6207,6211]
name: mock [6102,6106]
===
match
---
trailer [6658,6671]
trailer [6553,6566]
===
match
---
operator: = [6553,6554]
operator: = [6448,6449]
===
match
---
name: self [7180,7184]
name: self [7075,7079]
===
match
---
trailer [6683,6707]
trailer [6578,6602]
===
match
---
simple_stmt [1091,1175]
simple_stmt [1061,1145]
===
match
---
trailer [4051,4071]
trailer [4016,4036]
===
match
---
operator: , [2183,2184]
operator: , [2153,2154]
===
match
---
name: mock_error [7711,7721]
name: mock_error [7606,7616]
===
match
---
arglist [7650,7696]
arglist [7545,7591]
===
match
---
decorator [3790,3859]
decorator [3755,3824]
===
match
---
with_stmt [5132,5403]
with_stmt [5097,5368]
===
match
---
operator: , [5094,5095]
operator: , [5059,5060]
===
match
---
atom_expr [5235,5279]
atom_expr [5200,5244]
===
match
---
dotted_name [6333,6350]
dotted_name [6228,6245]
===
match
---
arglist [2718,2814]
arglist [2688,2784]
===
match
---
name: mock [6800,6804]
name: mock [6695,6699]
===
match
---
name: patch [6338,6343]
name: patch [6233,6238]
===
match
---
name: microsoft [1114,1123]
name: microsoft [1084,1093]
===
match
---
atom_expr [2718,2741]
atom_expr [2688,2711]
===
match
---
with_item [5065,5118]
with_item [5030,5083]
===
match
---
name: ti [3727,3729]
name: ti [3692,3694]
===
match
---
name: assert_called_once_with [7722,7745]
name: assert_called_once_with [7617,7640]
===
match
---
param [5845,5850]
param [5740,5745]
===
match
---
strings [3205,3395]
strings [3175,3350]
===
match
---
operator: = [4381,4382]
operator: = [4346,4347]
===
match
---
argument [1852,1892]
argument [1822,1862]
===
match
---
trailer [6011,6022]
trailer [5906,5917]
===
match
---
name: object [6344,6350]
name: object [6239,6245]
===
match
---
name: self [6908,6912]
name: self [6803,6807]
===
match
---
operator: , [7324,7325]
operator: , [7219,7220]
===
match
---
name: mock_log_exists [6481,6496]
name: mock_log_exists [6376,6391]
===
match
---
string: 'wasb://container/remote/log/location' [1383,1421]
string: 'wasb://container/remote/log/location' [1353,1391]
===
match
---
classdef [1261,7850]
classdef [1231,7745]
===
match
---
trailer [1599,1617]
trailer [1569,1587]
===
match
---
name: date [2200,2204]
name: date [2170,2174]
===
match
---
parameters [2663,2669]
parameters [2633,2639]
===
match
---
trailer [1687,1939]
trailer [1657,1909]
===
match
---
dotted_name [6800,6810]
dotted_name [6695,6705]
===
match
---
name: self [3571,3575]
name: self [3536,3540]
===
match
---
operator: { [2586,2587]
operator: { [2556,2557]
===
match
---
trailer [4344,4357]
trailer [4309,4322]
===
match
---
name: remote_log_location [4447,4466]
name: remote_log_location [4412,4431]
===
match
---
name: hook [3135,3139]
name: hook [3105,3109]
===
match
---
simple_stmt [930,975]
simple_stmt [900,945]
===
match
---
operator: , [2597,2598]
operator: , [2567,2568]
===
match
---
name: wasb_task_handler [4502,4519]
name: wasb_task_handler [4467,4484]
===
match
---
name: self [3722,3726]
name: self [3687,3691]
===
match
---
name: mock [2838,2842]
name: mock [2808,2812]
===
match
---
name: test_write_raises [7162,7179]
name: test_write_raises [7057,7074]
===
match
---
name: remote_log_location [6036,6055]
name: remote_log_location [5931,5950]
===
match
---
atom_expr [2299,2313]
atom_expr [2269,2283]
===
match
---
simple_stmt [1360,1422]
simple_stmt [1330,1392]
===
match
---
operator: = [1381,1382]
operator: = [1351,1352]
===
match
---
name: mock_hook [5208,5217]
name: mock_hook [5173,5182]
===
match
---
trailer [3721,3730]
trailer [3686,3695]
===
match
---
name: mock_log_exists [5904,5919]
name: mock_log_exists [5799,5814]
===
match
---
dotted_name [894,906]
dotted_name [864,876]
===
match
---
name: self [6166,6170]
name: self [6061,6065]
===
match
---
atom_expr [2689,2824]
atom_expr [2659,2794]
===
match
---
trailer [7436,7493]
trailer [7331,7388]
===
match
---
name: self [6738,6742]
name: self [6633,6637]
===
match
---
param [7180,7184]
param [7075,7079]
===
match
---
operator: , [6443,6444]
operator: , [6338,6339]
===
match
---
trailer [7587,7613]
trailer [7482,7508]
===
match
---
name: dag [2138,2141]
name: dag [2108,2111]
===
match
---
name: self [4497,4501]
name: self [4462,4466]
===
match
---
name: self [2484,2488]
name: self [2454,2458]
===
match
---
name: mock_service [2490,2502]
name: mock_service [2460,2472]
===
match
---
name: test_hook_raises [2647,2663]
name: test_hook_raises [2617,2633]
===
match
---
name: self [1647,1651]
name: self [1617,1621]
===
match
---
name: TaskInstance [2161,2173]
name: TaskInstance [2131,2143]
===
match
---
name: self [2214,2218]
name: self [2184,2188]
===
match
---
name: mock_hook [6065,6074]
name: mock_hook [5960,5969]
===
match
---
atom_expr [4916,5051]
atom_expr [4881,5016]
===
match
---
name: date [2049,2053]
name: date [2019,2023]
===
match
---
simple_stmt [3687,3731]
simple_stmt [3652,3696]
===
match
---
operator: , [4812,4813]
operator: , [4777,4778]
===
match
---
trailer [5141,5147]
trailer [5106,5112]
===
match
---
atom_expr [6976,7000]
atom_expr [6871,6895]
===
match
---
testlist_comp [2588,2619]
testlist_comp [2558,2589]
===
match
---
operator: , [1928,1929]
operator: , [1898,1899]
===
match
---
simple_stmt [2151,2206]
simple_stmt [2121,2176]
===
match
---
atom_expr [1717,1740]
atom_expr [1687,1710]
===
match
---
atom_expr [2531,2558]
atom_expr [2501,2528]
===
match
---
param [3894,3903]
param [3859,3868]
===
match
---
name: test_set_context_raw [3473,3493]
name: test_set_context_raw [3438,3458]
===
match
---
expr_stmt [2679,2824]
expr_stmt [2649,2794]
===
match
---
atom_expr [2743,2763]
atom_expr [2713,2733]
===
match
---
import_from [1091,1174]
import_from [1061,1144]
===
match
---
parameters [1320,1326]
parameters [1290,1296]
===
match
---
trailer [5244,5257]
trailer [5209,5222]
===
match
---
simple_stmt [4402,4482]
simple_stmt [4367,4447]
===
match
---
trailer [6938,6956]
trailer [6833,6851]
===
match
---
name: test_write_on_existing_log [6395,6421]
name: test_write_on_existing_log [6290,6316]
===
match
---
name: container_name [2770,2784]
name: container_name [2740,2754]
===
match
---
atom_expr [7631,7697]
atom_expr [7526,7592]
===
match
---
name: remote_log_location [6981,7000]
name: remote_log_location [6876,6895]
===
match
---
string: 'end_of_log' [4828,4840]
string: 'end_of_log' [4793,4805]
===
match
---
name: patch [3796,3801]
name: patch [3761,3766]
===
match
---
trailer [6763,6783]
trailer [6658,6678]
===
match
---
param [5851,5867]
param [5746,5762]
===
match
---
atom_expr [5065,5104]
atom_expr [5030,5069]
===
match
---
operator: = [2048,2049]
operator: = [2018,2019]
===
match
---
trailer [2842,2848]
trailer [2812,2818]
===
match
---
param [6445,6460]
param [6340,6355]
===
match
---
expr_stmt [7195,7340]
expr_stmt [7090,7235]
===
match
---
arglist [2856,2876]
arglist [2826,2846]
===
match
---
simple_stmt [802,832]
simple_stmt [802,832]
===
match
---
name: self [1770,1774]
name: self [1740,1744]
===
match
---
trailer [6123,6200]
trailer [6018,6095]
===
match
---
name: unittest [1287,1295]
name: unittest [1257,1265]
===
match
---
name: tests [1218,1223]
name: tests [1188,1193]
===
match
---
name: unittest [837,845]
name: unittest [837,845]
===
match
---
name: self [1360,1364]
name: self [1330,1334]
===
match
---
atom_expr [1672,1939]
atom_expr [1642,1909]
===
match
---
decorator [2388,2466]
decorator [2358,2436]
===
match
---
string: "wasb_log_exists" [6368,6385]
string: "wasb_log_exists" [6263,6280]
===
match
---
atom_expr [7017,7152]
atom_expr [6912,7047]
===
match
---
name: WasbTaskHandler [2689,2704]
name: WasbTaskHandler [2659,2674]
===
match
---
name: raw [3517,3520]
name: raw [3482,3485]
===
match
---
decorator [5714,5763]
decorator [5609,5658]
===
match
---
comparison [4497,4859]
comparison [4462,4824]
===
match
---
operator: , [7607,7608]
operator: , [7502,7503]
===
match
---
trailer [4931,5051]
trailer [4896,5016]
===
match
---
trailer [1295,1304]
trailer [1265,1274]
===
match
---
trailer [1349,1351]
trailer [1319,1321]
===
match
---
operator: , [2867,2868]
operator: , [2837,2838]
===
match
---
name: date [1949,1953]
name: date [1919,1923]
===
match
---
trailer [6074,6087]
trailer [5969,5982]
===
match
---
name: load_string [7040,7051]
name: load_string [6935,6946]
===
match
---
name: self [7302,7306]
name: self [7197,7201]
===
match
---
atom_expr [4992,5011]
atom_expr [4957,4976]
===
match
---
name: patch [5647,5652]
name: patch [5542,5547]
===
match
---
dotted_name [6280,6297]
dotted_name [6175,6192]
===
match
---
name: WasbTaskHandler [6298,6313]
name: WasbTaskHandler [6193,6208]
===
match
---
arglist [7763,7835]
arglist [7658,7730]
===
match
---
trailer [3017,3029]
trailer [2987,2999]
===
match
---
name: setUp [1315,1320]
name: setUp [1285,1290]
===
match
---
atom [2586,2637]
atom [2556,2607]
===
match
---
simple_stmt [1595,1639]
simple_stmt [1565,1609]
===
match
---
simple_stmt [6481,6517]
simple_stmt [6376,6412]
===
match
---
atom_expr [2161,2205]
atom_expr [2131,2175]
===
match
---
string: "airflow.providers.microsoft.azure.hooks.wasb.WasbHook" [4229,4284]
string: "airflow.providers.microsoft.azure.hooks.wasb.WasbHook" [4194,4249]
===
match
---
operator: , [5382,5383]
operator: , [5347,5348]
===
match
---
decorated [2320,2570]
decorated [2290,2540]
===
match
---
name: DAG [957,960]
name: DAG [927,930]
===
match
---
name: patch [4223,4228]
name: patch [4188,4193]
===
match
---
name: state [1194,1199]
name: state [1164,1169]
===
match
---
operator: , [2036,2037]
operator: , [2006,2007]
===
match
---
import_from [832,857]
import_from [832,857]
===
match
---
trailer [2920,2977]
trailer [2890,2947]
===
match
---
atom [2331,2382]
atom [2301,2352]
===
match
---
simple_stmt [7631,7698]
simple_stmt [7526,7593]
===
match
---
trailer [5075,5082]
trailer [5040,5047]
===
match
---
name: patch [5773,5778]
name: patch [5668,5673]
===
match
---
param [2484,2489]
param [2454,2459]
===
match
---
number: 2020 [1965,1969]
number: 2020 [1935,1939]
===
match
---
expr_stmt [6481,6516]
expr_stmt [6376,6411]
===
match
---
arglist [3047,3071]
arglist [3017,3041]
===
match
---
param [2490,2502]
param [2460,2472]
===
match
---
atom_expr [6615,6639]
atom_expr [6510,6534]
===
match
---
name: return_value [4368,4380]
name: return_value [4333,4345]
===
match
---
atom_expr [1647,1669]
atom_expr [1617,1639]
===
match
---
atom_expr [3536,3579]
atom_expr [3501,3544]
===
match
---
name: self [2245,2249]
name: self [2215,2219]
===
match
---
string: 'local/log/location' [1519,1539]
string: 'local/log/location' [1489,1509]
===
match
---
name: handler [2679,2686]
name: handler [2649,2656]
===
match
---
simple_stmt [975,1025]
simple_stmt [945,995]
===
match
---
trailer [7039,7051]
trailer [6934,6946]
===
match
---
name: ti [2250,2252]
name: ti [2220,2222]
===
match
---
parameters [6907,6924]
parameters [6802,6819]
===
match
---
name: State [2261,2266]
name: State [2231,2236]
===
match
---
name: object [7365,7371]
name: object [7260,7266]
===
match
---
parameters [3671,3677]
parameters [3636,3642]
===
match
---
name: local_log_location [1498,1516]
name: local_log_location [1468,1486]
===
match
---
assert_stmt [4402,4481]
assert_stmt [4367,4446]
===
match
---
trailer [5296,5322]
trailer [5261,5287]
===
match
---
import_from [1213,1258]
import_from [1183,1228]
===
match
---
arglist [6968,7007]
arglist [6863,6902]
===
match
---
operator: , [7383,7384]
operator: , [7278,7279]
===
match
---
operator: , [4619,4620]
operator: , [4584,4585]
===
match
---
atom_expr [2786,2808]
atom_expr [2756,2778]
===
match
---
funcdef [4290,4860]
funcdef [4255,4825]
===
match
---
expr_stmt [3914,3947]
expr_stmt [3879,3912]
===
match
---
string: "failed to connect" [5297,5316]
string: "failed to connect" [5262,5281]
===
match
---
name: side_effect [7559,7570]
name: side_effect [7454,7465]
===
match
---
name: wasb_task_handler [1134,1151]
name: wasb_task_handler [1104,1121]
===
match
---
atom_expr [7097,7116]
atom_expr [6992,7011]
===
match
---
decorators [5641,5822]
decorators [5536,5717]
===
match
---
expr_stmt [5948,5980]
expr_stmt [5843,5875]
===
match
---
arglist [4945,5041]
arglist [4910,5006]
===
match
---
dictorsetmaker [2332,2381]
dictorsetmaker [2302,2351]
===
match
---
trailer [6577,6595]
trailer [6472,6490]
===
match
---
string: 'Log line\n' [4745,4757]
string: 'Log line\n' [4710,4722]
===
match
---
atom_expr [5282,5322]
atom_expr [5247,5287]
===
match
---
simple_stmt [6525,6565]
simple_stmt [6420,6460]
===
match
---
string: "" [5978,5980]
string: "" [5873,5875]
===
match
---
name: wasb_task_handler [3692,3709]
name: wasb_task_handler [3657,3674]
===
match
---
import_from [1175,1212]
import_from [1145,1182]
===
match
---
trailer [3513,3516]
trailer [3478,3481]
===
match
---
funcdef [4865,5636]
funcdef [4830,5531]
===
match
---
atom_expr [3722,3729]
atom_expr [3687,3694]
===
match
---
operator: , [7000,7001]
operator: , [6895,6896]
===
match
---
name: mock_hook [3925,3934]
name: mock_hook [3890,3899]
===
match
---
name: self [2151,2155]
name: self [2121,2125]
===
match
---
atom_expr [2261,2274]
atom_expr [2231,2244]
===
match
---
name: wasb_log_exists [4031,4046]
name: wasb_log_exists [3996,4011]
===
match
---
trailer [7546,7558]
trailer [7441,7453]
===
match
---
trailer [5993,6011]
trailer [5888,5906]
===
match
---
expr_stmt [2063,2142]
expr_stmt [2033,2112]
===
match
---
operator: , [2342,2343]
operator: , [2312,2313]
===
match
---
name: mock_error [3153,3163]
name: mock_error [3123,3133]
===
match
---
string: 'Could not write logs to %s' [7763,7791]
string: 'Could not write logs to %s' [7658,7686]
===
match
---
name: filename_template [1852,1869]
name: filename_template [1822,1839]
===
match
---
simple_stmt [2283,2315]
simple_stmt [2253,2285]
===
match
---
name: patch [7431,7436]
name: patch [7326,7331]
===
match
---
trailer [2252,2258]
trailer [2222,2228]
===
match
---
decorators [6206,6387]
decorators [6101,6282]
===
match
---
name: WasbTaskHandler [1672,1687]
name: WasbTaskHandler [1642,1657]
===
match
---
atom_expr [4081,4211]
atom_expr [4046,4176]
===
match
---
string: 'Log line' [4383,4393]
string: 'Log line' [4348,4358]
===
match
---
operator: , [6736,6737]
operator: , [6631,6632]
===
match
---
name: handler [5340,5347]
name: handler [5305,5312]
===
match
---
atom_expr [1360,1380]
atom_expr [1330,1350]
===
match
---
argument [7822,7835]
argument [7717,7730]
===
match
---
expr_stmt [1595,1638]
expr_stmt [1565,1608]
===
match
---
atom_expr [1287,1304]
atom_expr [1257,1274]
===
match
---
suite [2670,3464]
suite [2640,3429]
===
match
---
string: "airflow.providers.microsoft.azure.hooks.wasb.WasbHook" [2921,2976]
string: "airflow.providers.microsoft.azure.hooks.wasb.WasbHook" [2891,2946]
===
match
---
name: mock_error [7397,7407]
name: mock_error [7292,7302]
===
match
---
atom_expr [2070,2142]
atom_expr [2040,2112]
===
match
---
trailer [6035,6055]
trailer [5930,5950]
===
match
---
trailer [5362,5382]
trailer [5327,5347]
===
match
---
testlist_comp [4551,4849]
testlist_comp [4516,4814]
===
match
---
trailer [7721,7745]
trailer [7616,7640]
===
match
---
trailer [6606,6640]
trailer [6501,6535]
===
match
---
operator: = [2259,2260]
operator: = [2229,2230]
===
match
---
atom_expr [7281,7300]
atom_expr [7176,7195]
===
match
---
argument [2185,2204]
argument [2155,2174]
===
match
---
atom_expr [5013,5035]
atom_expr [4978,5000]
===
match
---
name: mock [5642,5646]
name: mock [5537,5541]
===
match
---
atom_expr [4970,4990]
atom_expr [4935,4955]
===
match
---
trailer [5090,5094]
trailer [5055,5059]
===
match
---
string: 'task_for_testing_file_log_handler' [2092,2127]
string: 'task_for_testing_file_log_handler' [2062,2097]
===
match
---
simple_stmt [7195,7341]
simple_stmt [7090,7236]
===
match
---
name: mock_error [5415,5425]
name: mock_error [5380,5390]
===
match
---
name: assert_called_once_with [5426,5449]
name: assert_called_once_with [5391,5414]
===
match
---
atom [4827,4847]
atom [4792,4812]
===
match
---
string: 'remote/log/location/1.log' [7793,7820]
string: 'remote/log/location/1.log' [7688,7715]
===
match
---
name: mock [3791,3795]
name: mock [3756,3760]
===
match
---
name: remote_log_location [6171,6190]
name: remote_log_location [6066,6085]
===
match
---
atom_expr [3153,3463]
atom_expr [3123,3428]
===
match
---
atom_expr [5137,5204]
atom_expr [5102,5169]
===
match
---
simple_stmt [7524,7614]
simple_stmt [7419,7509]
===
match
---
atom_expr [1870,1892]
atom_expr [1840,1862]
===
match
---
arglist [6298,6326]
arglist [6193,6221]
===
match
---
simple_stmt [4906,5052]
simple_stmt [4871,5017]
===
match
---
expr_stmt [1986,2054]
expr_stmt [1956,2024]
===
match
---
name: TaskInstance [962,974]
name: TaskInstance [932,944]
===
match
---
name: start_date [2038,2048]
name: start_date [2008,2018]
===
match
---
param [4309,4314]
param [4274,4279]
===
match
---
name: return_value [7027,7039]
name: return_value [6922,6934]
===
match
---
name: filename_template [1875,1892]
name: filename_template [1845,1862]
===
match
---
string: "airflow.providers.microsoft.azure.hooks.wasb.WasbHook" [5653,5708]
string: "airflow.providers.microsoft.azure.hooks.wasb.WasbHook" [5548,5603]
===
match
---
atom_expr [1493,1516]
atom_expr [1463,1486]
===
match
---
name: patch [7359,7364]
name: patch [7254,7259]
===
match
---
name: delete_local_copy [1906,1923]
name: delete_local_copy [1876,1893]
===
match
---
trailer [2221,2232]
trailer [2191,2202]
===
match
---
name: WasbTaskHandler [5733,5748]
name: WasbTaskHandler [5628,5643]
===
match
---
operator: = [7690,7691]
operator: = [7585,7586]
===
match
---
trailer [3558,3570]
trailer [3523,3535]
===
match
---
trailer [3575,3578]
trailer [3540,3543]
===
match
---
suite [7408,7850]
suite [7303,7745]
===
match
---
trailer [7638,7649]
trailer [7533,7544]
===
match
---
atom_expr [6738,6757]
atom_expr [6633,6652]
===
match
---
trailer [2173,2205]
trailer [2143,2175]
===
match
---
name: self [6573,6577]
name: self [6468,6472]
===
match
---
with_stmt [2905,3140]
with_stmt [2875,3110]
===
match
---
parameters [5844,5894]
parameters [5739,5789]
===
match
---
atom_expr [6573,6640]
atom_expr [6468,6535]
===
match
---
name: utils [1188,1193]
name: utils [1158,1163]
===
match
---
import_from [889,928]
import_from [859,898]
===
match
---
atom_expr [5948,5975]
atom_expr [5843,5870]
===
match
---
trailer [3750,3768]
trailer [3715,3733]
===
match
---
atom_expr [7302,7324]
atom_expr [7197,7219]
===
match
---
name: self [7234,7238]
name: self [7129,7133]
===
match
---
name: mock_hook [3008,3017]
name: mock_hook [2978,2987]
===
match
---
operator: @ [6206,6207]
operator: @ [6101,6102]
===
match
---
operator: , [7682,7683]
operator: , [7577,7578]
===
match
---
name: patch [2843,2848]
name: patch [2813,2818]
===
match
---
operator: } [2381,2382]
operator: } [2351,2352]
===
match
---
atom_expr [4945,4968]
atom_expr [4910,4933]
===
match
---
trailer [6022,6056]
trailer [5917,5951]
===
match
---
simple_stmt [3127,3140]
simple_stmt [3097,3110]
===
match
---
name: wasb_log_folder [1754,1769]
name: wasb_log_folder [1724,1739]
===
match
---
strings [4645,4757]
strings [4610,4722]
===
match
---
operator: = [2068,2069]
operator: = [2038,2039]
===
match
---
name: assert_called_once_with [6100,6123]
name: assert_called_once_with [5995,6018]
===
match
---
operator: , [2741,2742]
operator: , [2711,2712]
===
match
---
trailer [6742,6757]
trailer [6637,6652]
===
match
---
suite [4897,5636]
suite [4862,5531]
===
match
---
trailer [3570,3579]
trailer [3535,3544]
===
match
---
name: patch [6212,6217]
name: patch [6107,6112]
===
match
---
operator: , [5849,5850]
operator: , [5744,5745]
===
match
---
trailer [3768,3784]
trailer [3733,3749]
===
match
---
name: self [6615,6619]
name: self [6510,6514]
===
match
---
simple_stmt [2245,2275]
simple_stmt [2215,2245]
===
match
---
simple_stmt [889,929]
simple_stmt [859,899]
===
match
---
trailer [7306,7324]
trailer [7201,7219]
===
match
---
name: super [1336,1341]
name: super [1306,1311]
===
match
---
operator: , [1740,1741]
operator: , [1710,1711]
===
match
---
name: remote_log_location [7123,7142]
name: remote_log_location [7018,7037]
===
match
---
operator: , [4848,4849]
operator: , [4813,4814]
===
match
---
atom_expr [3509,3520]
atom_expr [3474,3485]
===
match
---
simple_stmt [3153,3464]
simple_stmt [3123,3429]
===
match
---
trailer [5257,5267]
trailer [5222,5232]
===
match
---
simple_stmt [4490,4860]
simple_stmt [4455,4825]
===
match
---
trailer [1990,1994]
trailer [1960,1964]
===
match
---
operator: @ [2575,2576]
operator: @ [2545,2546]
===
match
---
name: airflow [935,942]
name: airflow [905,912]
===
match
---
name: patch [2394,2399]
name: patch [2364,2369]
===
match
---
simple_stmt [3739,3785]
simple_stmt [3704,3750]
===
match
---
decorated [6799,7153]
decorated [6694,7048]
===
match
---
decorator [2575,2639]
decorator [2545,2609]
===
match
---
name: mock [2389,2393]
name: mock [2359,2363]
===
match
---
name: mock_wasb_read [5868,5882]
name: mock_wasb_read [5763,5777]
===
match
---
operator: , [1790,1791]
operator: , [1760,1761]
===
match
---
name: mock [5065,5069]
name: mock [5030,5034]
===
match
---
name: filename_template [1600,1617]
name: filename_template [1570,1587]
===
match
---
atom_expr [5415,5635]
atom_expr [5380,5530]
===
match
---
atom [4591,4780]
atom [4556,4745]
===
match
---
name: WasbTaskHandler [5786,5801]
name: WasbTaskHandler [5681,5696]
===
match
---
operator: = [5280,5281]
operator: = [5245,5246]
===
match
---
param [3672,3676]
param [3637,3641]
===
match
---
name: mock_log_exists [5851,5866]
name: mock_log_exists [5746,5761]
===
match
---
expr_stmt [2245,2274]
expr_stmt [2215,2244]
===
match
---
operator: , [3066,3067]
operator: , [3036,3037]
===
match
---
operator: = [1455,1456]
operator: = [1425,1426]
===
match
---
name: self [1321,1325]
name: self [1291,1295]
===
match
---
name: test_wasb_read_raises [4869,4890]
name: test_wasb_read_raises [4834,4855]
===
match
---
trailer [7285,7300]
trailer [7180,7195]
===
match
---
name: wasb_log_folder [2748,2763]
name: wasb_log_folder [2718,2733]
===
match
---
atom_expr [3599,3637]
atom_expr [3564,3602]
===
match
---
atom_expr [1770,1790]
atom_expr [1740,1760]
===
match
---
operator: = [1923,1924]
operator: = [1893,1894]
===
match
---
atom_expr [1956,1977]
atom_expr [1926,1947]
===
match
---
suite [1306,7850]
suite [1276,7745]
===
match
---
param [6422,6427]
param [6317,6322]
===
match
---
atom_expr [6481,6509]
atom_expr [6376,6404]
===
match
---
trailer [1341,1343]
trailer [1311,1313]
===
match
---
operator: = [2233,2234]
operator: = [2203,2204]
===
match
---
name: WasbHook [1082,1090]
name: WasbHook [1052,1060]
===
match
---
trailer [7379,7383]
trailer [7274,7278]
===
match
---
name: self [5845,5849]
name: self [5740,5744]
===
match
---
param [5868,5883]
param [5763,5778]
===
match
---
simple_stmt [6649,6794]
simple_stmt [6544,6689]
===
match
---
dotted_name [5715,5732]
dotted_name [5610,5627]
===
match
---
operator: = [7203,7204]
operator: = [7098,7099]
===
match
---
dotted_name [3791,3801]
dotted_name [3756,3766]
===
match
---
arglist [5786,5820]
arglist [5681,5715]
===
match
---
trailer [7220,7340]
trailer [7115,7235]
===
match
---
trailer [6707,6793]
trailer [6602,6688]
===
match
---
operator: = [1716,1717]
operator: = [1686,1687]
===
match
---
name: airflow [1180,1187]
name: airflow [1150,1157]
===
match
---
string: 'error' [5096,5103]
string: 'error' [5061,5068]
===
match
---
decorated [2575,3464]
decorated [2545,3429]
===
match
---
trailer [3516,3520]
trailer [3481,3485]
===
match
---
operator: , [2558,2559]
operator: , [2528,2529]
===
match
---
name: wasb_container [1804,1818]
name: wasb_container [1774,1788]
===
match
---
name: container_name [7102,7116]
name: container_name [6997,7011]
===
match
---
name: wasb_log_folder [4975,4990]
name: wasb_log_folder [4940,4955]
===
match
---
name: mock_hook [2981,2990]
name: mock_hook [2951,2960]
===
match
---
name: self [1430,1434]
name: self [1400,1404]
===
match
---
name: operators [988,997]
name: operators [958,967]
===
match
---
trailer [5347,5357]
trailer [5312,5322]
===
match
---
simple_stmt [1548,1587]
simple_stmt [1518,1557]
===
match
---
name: return_value [5920,5932]
name: return_value [5815,5827]
===
match
---
name: ANY [3445,3448]
name: exc_info [3400,3408]
===
match
---
operator: @ [5641,5642]
operator: @ [5536,5537]
===
match
---
trailer [7558,7570]
trailer [7453,7465]
===
match
---
name: assert_called_once_with [6684,6707]
name: assert_called_once_with [6579,6602]
===
match
---
simple_stmt [1213,1259]
simple_stmt [1183,1229]
===
match
---
name: check_for_blob [4104,4118]
name: check_for_blob [4069,4083]
===
match
---
name: isinstance [2520,2530]
name: isinstance [2490,2500]
===
match
---
funcdef [3469,3638]
funcdef [3434,3603]
===
match
---
operator: , [2808,2809]
operator: , [2778,2779]
===
match
---
trailer [6671,6683]
trailer [6566,6578]
===
match
---
operator: , [960,961]
operator: , [930,931]
===
match
---
name: wasb_write [7639,7649]
name: wasb_write [7534,7544]
===
match
---
trailer [3964,3979]
trailer [3929,3944]
===
match
---
name: conf_vars [2321,2330]
name: conf_vars [2291,2300]
===
match
---
atom_expr [7372,7383]
atom_expr [7267,7278]
===
match
---
name: local_log_location [4950,4968]
name: local_log_location [4915,4933]
===
match
---
string: "failed to connect" [3047,3066]
string: "failed to connect" [3017,3036]
===
match
---
atom_expr [5989,6056]
atom_expr [5884,5951]
===
match
---
simple_stmt [786,802]
simple_stmt [786,802]
===
match
---
name: mock [2910,2914]
name: mock [2880,2884]
===
match
---
arglist [1701,1929]
arglist [1671,1899]
===
match
---
funcdef [2643,3464]
funcdef [2613,3429]
===
match
---
string: 'text' [6023,6029]
string: 'text' [5918,5924]
===
match
---
simple_stmt [5340,5403]
simple_stmt [5305,5368]
===
match
---
operator: , [4990,4991]
operator: , [4955,4956]
===
match
---
name: mock_hook [5884,5893]
name: mock_hook [5779,5788]
===
match
---
trailer [2914,2920]
trailer [2884,2890]
===
match
---
atom [4826,4848]
atom [4791,4813]
===
match
---
expr_stmt [1360,1421]
expr_stmt [1330,1391]
===
match
---
name: wasb_task_handler [6578,6595]
name: wasb_task_handler [6473,6490]
===
match
---
operator: @ [3790,3791]
operator: @ [3755,3756]
===
match
---
trailer [2553,2558]
trailer [2523,2528]
===
match
---
simple_stmt [3008,3073]
simple_stmt [2978,3043]
===
match
---
name: read_file [4358,4367]
name: read_file [4323,4332]
===
match
---
atom_expr [1336,1351]
atom_expr [1306,1321]
===
match
---
trailer [1364,1380]
trailer [1334,1350]
===
match
---
name: wasb_task_handler [1652,1669]
name: wasb_task_handler [1622,1639]
===
match
---
name: dummy [998,1003]
name: dummy [968,973]
===
match
---
trailer [4529,4532]
trailer [4494,4497]
===
match
---
expr_stmt [1430,1484]
expr_stmt [1400,1454]
===
match
---
atom_expr [7524,7570]
atom_expr [7419,7465]
===
match
---
operator: @ [6332,6333]
operator: @ [6227,6228]
===
match
---
operator: , [6912,6913]
operator: , [6807,6808]
===
match
---
simple_stmt [2214,2237]
simple_stmt [2184,2207]
===
match
---
arglist [3205,3449]
arglist [3175,3414]
===
match
---
name: WasbTaskHandler [7205,7220]
name: WasbTaskHandler [7100,7115]
===
match
---
operator: , [2763,2764]
operator: , [2733,2734]
===
match
---
atom_expr [4497,4533]
atom_expr [4462,4498]
===
match
---
operator: , [6426,6427]
operator: , [6321,6322]
===
match
---
simple_stmt [3956,4000]
simple_stmt [3921,3965]
===
match
---
suite [5218,5403]
suite [5183,5368]
===
match
---
trailer [3540,3558]
trailer [3505,3523]
===
match
---
string: "airflow.providers.microsoft.azure.hooks.wasb.WasbHook" [6811,6866]
string: "airflow.providers.microsoft.azure.hooks.wasb.WasbHook" [6706,6761]
===
match
---
name: config [1235,1241]
name: config [1205,1211]
===
match
---
operator: , [6366,6367]
operator: , [6261,6262]
===
match
---
name: set_context [3559,3570]
name: set_context [3524,3535]
===
match
---
trailer [3621,3637]
trailer [3586,3602]
===
match
---
name: State [1207,1212]
name: State [1177,1182]
===
match
---
expr_stmt [3008,3072]
expr_stmt [2978,3042]
===
match
---
arglist [5358,5401]
arglist [5323,5366]
===
match
---
operator: = [4914,4915]
operator: = [4879,4880]
===
match
---
name: append [7684,7690]
name: append [7579,7585]
===
match
---
expr_stmt [5235,5322]
expr_stmt [5200,5287]
===
match
---
string: '*** Reading remote log from wasb://container/remote/log/location/1.log.\n' [4645,4720]
string: '*** Reading remote log from wasb://container/remote/log/location/1.log.\n' [4610,4685]
===
match
---
name: azure [894,899]
name: azure [864,869]
===
match
---
name: execution_date [2185,2199]
name: execution_date [2155,2169]
===
match
---
name: task [2174,2178]
name: task [2144,2148]
===
match
---
name: ti [3576,3578]
name: ti [3541,3543]
===
match
---
argument [5607,5620]
argument [5502,5515]
===
match
---
atom_expr [2283,2314]
atom_expr [2253,2284]
===
match
---
suite [2892,3464]
suite [2862,3429]
===
match
---
funcdef [6391,6794]
funcdef [6286,6689]
===
match
---
atom_expr [7234,7257]
atom_expr [7129,7152]
===
match
---
trailer [7364,7371]
trailer [7259,7266]
===
match
---
operator: = [1954,1955]
operator: = [1924,1925]
===
match
---
name: self [6759,6763]
name: self [6654,6658]
===
match
---
name: self [3536,3540]
name: self [3501,3505]
===
match
---
parameters [2483,2503]
parameters [2453,2473]
===
match
---
name: azure [1058,1063]
name: azure [1028,1033]
===
match
---
name: unittest [793,801]
name: unittest [793,801]
===
match
---
name: TestCase [1296,1304]
name: TestCase [1266,1274]
===
match
---
param [6914,6923]
param [6809,6818]
===
match
---
arglist [7089,7142]
arglist [6984,7037]
===
match
---
atom_expr [4335,4380]
atom_expr [4300,4345]
===
match
---
operator: , [3427,3428]
operator: , [3382,3383]
===
match
---
simple_stmt [1986,2055]
simple_stmt [1956,2025]
===
match
---
trailer [1774,1790]
trailer [1744,1760]
===
match
---
atom_expr [4442,4466]
atom_expr [4407,4431]
===
match
---
funcdef [3863,4212]
funcdef [3828,4177]
===
match
---
with_item [7354,7407]
with_item [7249,7302]
===
match
---
atom_expr [7426,7493]
atom_expr [7321,7388]
===
match
---
string: "Log line" [4471,4481]
string: "Log line" [4436,4446]
===
match
---
name: self [4409,4413]
name: self [4374,4378]
===
match
---
atom_expr [3746,3784]
atom_expr [3711,3749]
===
match
---
param [6461,6470]
param [6356,6365]
===
match
---
name: exc_info [7822,7830]
name: exc_info [7717,7725]
===
match
---
name: mock_hook [4081,4090]
name: mock_hook [4046,4055]
===
match
---
name: self [1819,1823]
name: self [1789,1793]
===
match
---
name: filename_template [7307,7324]
name: filename_template [7202,7219]
===
match
---
name: test_set_context_not_raw [3647,3671]
name: test_set_context_not_raw [3612,3636]
===
match
---
name: mock_error [5108,5118]
name: mock_error [5073,5083]
===
match
---
atom_expr [2765,2784]
atom_expr [2735,2754]
===
match
---
operator: = [2132,2133]
operator: = [2102,2103]
===
match
---
operator: , [7279,7280]
operator: , [7174,7175]
===
match
---
operator: = [1568,1569]
operator: = [1538,1539]
===
match
---
atom_expr [4409,4467]
atom_expr [4374,4432]
===
match
---
name: container_name [7286,7300]
name: container_name [7181,7195]
===
match
---
argument [1804,1838]
argument [1774,1808]
===
match
---
name: local_log_location [7239,7257]
name: local_log_location [7134,7152]
===
match
---
trailer [6099,6123]
trailer [5994,6018]
===
match
---
name: mock_error [2881,2891]
name: mock_error [2851,2861]
===
insert-node
---
name: TestWasbTaskHandler [1237,1256]
to
classdef [1261,7850]
at 0
===
update-node
---
string: "wasb_default" [3413,3427]
replace "wasb_default" by 'wasb_default'
===
insert-node
---
argument [3400,3413]
to
arglist [3205,3449]
at 4
===
update-node
---
string: 'Could not create an WasbHook with connection id "%s". ' [3205,3261]
replace 'Could not create an WasbHook with connection id "%s". ' by 'Could not create an WasbHook with connection id "%s".'
===
update-node
---
string: 'Please make sure that airflow[azure] is installed and ' [3278,3334]
replace 'Please make sure that airflow[azure] is installed and ' by ' Please make sure that airflow[azure] is installed'
===
update-node
---
string: 'the Wasb connection exists. Exception "%s"' [3351,3395]
replace 'the Wasb connection exists. Exception "%s"' by ' and the Wasb connection exists.'
===
update-node
---
name: ANY [3445,3448]
replace ANY by exc_info
===
move-tree
---
name: ANY [3445,3448]
to
argument [3400,3413]
at 0
===
delete-tree
---
simple_stmt [858,888]
    import_from [858,887]
        dotted_name [863,876]
            name: unittest [863,871]
            name: mock [872,876]
        name: ANY [884,887]
===
delete-node
---
name: TestWasbTaskHandler [1267,1286]
===
===
delete-node
---
string: "Message: '%s', exception '%s'" [5467,5498]
===
===
delete-node
---
operator: , [5498,5499]
===
===
delete-node
---
name: ANY [5586,5589]
===
===
delete-node
---
operator: , [5589,5590]
===
