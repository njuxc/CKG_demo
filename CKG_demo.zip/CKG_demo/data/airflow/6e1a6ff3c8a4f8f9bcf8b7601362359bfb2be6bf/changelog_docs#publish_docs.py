===
match
---
string: "Filter specifying for which packages the documentation is to be built. Wildcard are supported." [2717,2813]
string: "Filter specifying for which packages the documentation is to be built. Wildcard are supported." [2717,2813]
===
match
---
file_input [809,3403]
file_input [809,3418]
===
match
---
name: available_packages [3063,3081]
name: available_packages [3063,3081]
===
match
---
trailer [2906,2908]
trailer [2906,2908]
===
match
---
star_expr [2053,2076]
star_expr [2053,2076]
===
match
---
testlist_comp [2035,2104]
testlist_comp [2035,2104]
===
match
---
if_stmt [1167,1388]
if_stmt [1167,1388]
===
match
---
name: print [3104,3109]
name: print [3104,3109]
===
match
---
string: 'should contain the path to the airflow-site repository directory. ' [1666,1734]
string: 'should contain the path to the airflow-site repository directory. ' [1666,1734]
===
match
---
trailer [1434,1440]
trailer [1434,1440]
===
match
---
name: current_packages [3020,3036]
name: current_packages [3020,3036]
===
match
---
operator: = [1823,1824]
operator: = [1823,1824]
===
match
---
trailer [1127,1135]
trailer [1127,1135]
===
match
---
fstring_expr [3132,3155]
fstring_expr [3132,3155]
===
match
---
operator: = [2215,2216]
operator: = [2215,2216]
===
match
---
argument [2556,2575]
argument [2556,2575]
===
match
---
name: parse_args [2909,2919]
name: parse_args [2909,2919]
===
match
---
argument [2673,2688]
argument [2673,2688]
===
match
---
name: AIRFLOW_SITE_DIR [1494,1510]
name: AIRFLOW_SITE_DIR [1494,1510]
===
match
---
funcdef [2852,3394]
funcdef [2852,3409]
===
match
---
expr_stmt [1936,2022]
expr_stmt [1936,2022]
===
match
---
name: AIRFLOW_SITE_DIR [1402,1418]
name: AIRFLOW_SITE_DIR [1402,1418]
===
match
---
trailer [2200,2202]
trailer [2200,2202]
===
match
---
name: add_argument [2491,2503]
name: add_argument [2491,2503]
===
match
---
operator: } [2408,2409]
operator: } [2408,2409]
===
match
---
name: SystemExit [1204,1214]
name: SystemExit [1204,1214]
===
match
---
name: argparse [2217,2225]
name: argparse [2217,2225]
===
match
---
atom [2703,2823]
atom [2703,2823]
===
match
---
funcdef [1847,2106]
funcdef [1847,2106]
===
match
---
simple_stmt [2208,2421]
simple_stmt [2208,2421]
===
match
---
expr_stmt [2131,2203]
expr_stmt [2131,2203]
===
match
---
operator: { [2384,2385]
operator: { [2384,2385]
===
match
---
trailer [2431,2447]
trailer [2431,2447]
===
match
---
operator: = [3037,3038]
operator: = [3037,3038]
===
match
---
name: environ [1128,1135]
name: environ [1128,1135]
===
match
---
argument [3320,3345]
argument [3320,3345]
===
match
---
expr_stmt [1804,1844]
expr_stmt [1804,1844]
===
match
---
trailer [1214,1387]
trailer [1214,1387]
===
match
---
name: exts [947,951]
name: exts [947,951]
===
match
---
dotted_name [877,910]
dotted_name [877,910]
===
match
---
operator: = [2679,2680]
operator: = [2679,2680]
===
match
---
arglist [1494,1526]
arglist [1494,1526]
===
match
---
expr_stmt [2208,2420]
expr_stmt [2208,2420]
===
match
---
simple_stmt [1009,1069]
simple_stmt [1009,1069]
===
match
---
name: provider_package_names [2054,2076]
name: provider_package_names [2054,2076]
===
match
---
string: "--package-filter" [2645,2663]
string: "--package-filter" [2645,2663]
===
match
---
raise_stmt [1536,1802]
raise_stmt [1536,1802]
===
match
---
atom_expr [2165,2203]
atom_expr [2165,2203]
===
match
---
name: AIRFLOW_SITE_DIR [1106,1122]
name: AIRFLOW_SITE_DIR [1106,1122]
===
match
---
trailer [2919,2921]
trailer [2919,2921]
===
match
---
name: current_packages [3184,3200]
name: current_packages [3184,3200]
===
match
---
trailer [3383,3391]
trailer [3398,3406]
===
match
---
atom_expr [2995,3014]
atom_expr [2995,3014]
===
match
---
operator: , [2322,2323]
operator: , [2322,2323]
===
match
---
name: join [1489,1493]
name: join [1489,1493]
===
match
---
name: get_available_packages [2947,2969]
name: get_available_packages [2947,2969]
===
match
---
simple_stmt [1804,1845]
simple_stmt [1804,1845]
===
match
---
operator: , [2076,2077]
operator: , [2076,2077]
===
match
---
fstring_expr [3221,3226]
fstring_expr [3221,3226]
===
match
---
suite [1876,2106]
suite [1876,2106]
===
match
---
operator: = [2261,2262]
operator: = [2261,2262]
===
match
---
simple_stmt [872,937]
simple_stmt [872,937]
===
match
---
name: len [3133,3136]
name: len [3133,3136]
===
match
---
atom [2034,2105]
atom [2034,2105]
===
match
---
name: __name__ [1170,1178]
name: __name__ [1170,1178]
===
match
---
name: load_package_data [1825,1842]
name: load_package_data [1825,1842]
===
match
---
name: docs_builder [898,910]
name: docs_builder [898,910]
===
match
---
name: docs [877,881]
name: docs [877,881]
===
match
---
name: path [1470,1474]
name: path [1470,1474]
===
match
---
string: 'Disables extra checks' [2582,2605]
string: 'Disables extra checks' [2582,2605]
===
match
---
operator: , [3345,3346]
operator: , [3345,3346]
===
match
---
parameters [1873,1875]
parameters [1873,1875]
===
match
---
operator: = [2893,2894]
operator: = [2893,2894]
===
match
---
name: for_production [3347,3361]
name: for_production [3347,3361]
===
match
---
fstring_start: f" [2339,2341]
fstring_start: f" [2339,2341]
===
match
---
name: parser [2843,2849]
name: parser [2843,2849]
===
match
---
atom_expr [1542,1802]
atom_expr [1542,1802]
===
match
---
name: package_filters [2977,2992]
name: package_filters [2977,2992]
===
match
---
string: "\n * " [2165,2172]
string: "\n * " [2165,2172]
===
match
---
name: RawTextHelpFormatter [2459,2479]
name: RawTextHelpFormatter [2459,2479]
===
match
---
name: pkg [3222,3225]
name: pkg [3222,3225]
===
match
---
expr_stmt [2926,2971]
expr_stmt [2926,2971]
===
match
---
operator: } [3154,3155]
operator: } [3154,3155]
===
match
---
arglist [3063,3098]
arglist [3063,3098]
===
match
---
string: "To run this script, run the ./build_docs.py command" [1328,1381]
string: "To run this script, run the ./build_docs.py command" [1328,1381]
===
match
---
dotted_name [1014,1043]
dotted_name [1014,1043]
===
match
---
name: parser [2208,2214]
name: parser [2208,2214]
===
match
---
string: "append" [2680,2688]
string: "append" [2680,2688]
===
match
---
operator: , [2554,2555]
operator: , [2554,2555]
===
match
---
argument [2577,2605]
argument [2577,2605]
===
match
---
trailer [1135,1139]
trailer [1135,1139]
===
match
---
name: package_name [3249,3261]
name: package_name [3249,3261]
===
match
---
name: provider_yaml_utils [1024,1043]
name: provider_yaml_utils [1024,1043]
===
match
---
atom_expr [2616,2830]
atom_expr [2616,2830]
===
match
---
trailer [3391,3393]
trailer [3406,3408]
===
match
---
name: publish [3384,3391]
name: publish [3399,3406]
===
match
---
return_stmt [2836,2849]
return_stmt [2836,2849]
===
match
---
atom [1396,1530]
atom [1396,1530]
===
match
---
fstring_end: " [3166,3167]
fstring_end: " [3166,3167]
===
match
---
trailer [2225,2240]
trailer [2225,2240]
===
match
---
atom_expr [1825,1844]
atom_expr [1825,1844]
===
match
---
comparison [1170,1192]
comparison [1170,1192]
===
match
---
trailer [1970,1986]
trailer [1970,1986]
===
match
---
name: isdir [1435,1440]
name: isdir [1435,1440]
===
match
---
string: "apache-airflow" [2035,2051]
string: "apache-airflow" [2035,2051]
===
match
---
simple_stmt [3020,3100]
simple_stmt [3020,3100]
===
match
---
suite [2126,2850]
suite [2126,2850]
===
match
---
string: 'AIRFLOW_SITE_DIRECTORY' [1140,1164]
string: 'AIRFLOW_SITE_DIRECTORY' [1140,1164]
===
match
---
name: print [3210,3215]
name: print [3210,3215]
===
match
---
name: _get_parser [2895,2906]
name: _get_parser [2895,2906]
===
match
---
fstring [2339,2410]
fstring [2339,2410]
===
match
---
trailer [2503,2611]
trailer [2503,2611]
===
match
---
operator: = [2448,2449]
operator: = [2448,2449]
===
match
---
operator: = [2581,2582]
operator: = [2581,2582]
===
match
---
simple_stmt [1936,2023]
simple_stmt [1936,2023]
===
match
---
name: provider_package_names [1936,1958]
name: provider_package_names [1936,1958]
===
match
---
simple_stmt [2926,2972]
simple_stmt [2926,2972]
===
match
---
name: os [1427,1429]
name: os [1427,1429]
===
match
---
trailer [3062,3099]
trailer [3062,3099]
===
match
---
atom_expr [3301,3367]
atom_expr [3301,3382]
===
match
---
parameters [2860,2862]
parameters [2860,2862]
===
match
---
string: 'docs-archive' [1512,1526]
string: 'docs-archive' [1512,1526]
===
match
---
testlist_comp [1962,2021]
testlist_comp [1962,2021]
===
match
---
return_stmt [2027,2105]
return_stmt [2027,2105]
===
match
---
string: """Get list of all available packages to build.""" [1881,1931]
string: """Get list of all available packages to build.""" [1881,1931]
===
match
---
name: args [2995,2999]
name: args [2995,2999]
===
match
---
simple_stmt [2836,2850]
simple_stmt [2836,2850]
===
match
---
argument [2250,2322]
argument [2250,2322]
===
match
---
fstring_string:  -  [3218,3221]
fstring_string:  -  [3218,3221]
===
match
---
trailer [3109,3168]
trailer [3109,3168]
===
match
---
string: '--disable-checks' [2513,2531]
string: '--disable-checks' [2513,2531]
===
match
---
simple_stmt [2616,2831]
simple_stmt [2616,2831]
===
match
---
operator: { [3221,3222]
operator: { [3221,3222]
===
match
---
operator: = [2155,2156]
operator: = [2155,2156]
===
match
---
atom_expr [3133,3154]
atom_expr [3133,3154]
===
match
---
trailer [2969,2971]
trailer [2969,2971]
===
match
---
fstring_string:  package(s) [3155,3166]
fstring_string:  package(s) [3155,3166]
===
match
---
simple_stmt [3376,3394]
simple_stmt [3391,3409]
===
match
---
fstring [3110,3167]
fstring [3110,3167]
===
match
---
fstring_string: Publishing docs for  [3112,3132]
fstring_string: Publishing docs for  [3112,3132]
===
match
---
trailer [1474,1480]
trailer [1474,1480]
===
match
---
name: formatter_class [2432,2447]
name: formatter_class [2432,2447]
===
match
---
trailer [1469,1474]
trailer [1469,1474]
===
match
---
suite [2863,3394]
suite [2863,3409]
===
match
---
atom [1961,2022]
atom [1961,2022]
===
match
---
name: AIRFLOW_SITE_DIR [1441,1457]
name: AIRFLOW_SITE_DIR [1441,1457]
===
match
---
suite [1531,1803]
suite [1531,1803]
===
match
---
name: os [1467,1469]
name: os [1467,1469]
===
match
---
name: package_filter [963,977]
name: package_filter [963,977]
===
match
---
operator: = [2993,2994]
operator: = [2993,2994]
===
match
---
argument [2698,2823]
argument [2698,2823]
===
match
---
atom_expr [1427,1458]
atom_expr [1427,1458]
===
match
---
operator: != [1179,1181]
operator: != [1179,1181]
===
match
---
trailer [3400,3402]
trailer [3415,3417]
===
match
---
arglist [2513,2605]
arglist [2513,2605]
===
match
---
name: docs [942,946]
name: docs [942,946]
===
match
---
name: os [1481,1483]
name: os [1481,1483]
===
match
---
strings [1562,1796]
strings [1562,1796]
===
match
---
operator: , [2413,2414]
operator: , [2413,2414]
===
match
---
trailer [1488,1493]
trailer [1488,1493]
===
match
---
operator: = [3332,3333]
operator: = [3332,3333]
===
match
---
simple_stmt [3396,3403]
simple_stmt [3411,3418]
===
match
---
name: process_package_filters [985,1008]
name: process_package_filters [985,1008]
===
match
---
name: current_packages [3265,3281]
name: current_packages [3265,3281]
===
match
---
name: package_filters [3083,3098]
name: package_filters [3083,3098]
===
match
---
arith_expr [2157,2203]
arith_expr [2157,2203]
===
match
---
import_name [825,834]
import_name [825,834]
===
match
---
operator: , [2663,2664]
operator: , [2663,2664]
===
match
---
name: add_argument [2623,2635]
name: add_argument [2623,2635]
===
match
---
trailer [2177,2203]
trailer [2177,2203]
===
match
---
argument [3347,3366]
argument [3347,3366]
===
match
---
trailer [2908,2919]
trailer [2908,2919]
===
match
---
name: current_packages [3137,3153]
name: current_packages [3137,3153]
===
match
---
arglist [2645,2824]
arglist [2645,2824]
===
match
---
string: "This file is intended to be executed as an executable program. You cannot use it as a module." [1224,1319]
string: "This file is intended to be executed as an executable program. You cannot use it as a module." [1224,1319]
===
match
---
name: get_available_packages [2178,2200]
name: get_available_packages [2178,2200]
===
match
---
atom_expr [2217,2420]
atom_expr [2217,2420]
===
match
---
simple_stmt [1536,1803]
simple_stmt [1536,1803]
===
match
---
name: parser [2425,2431]
name: parser [2425,2431]
===
match
---
name: AirflowDocsBuilder [918,936]
name: AirflowDocsBuilder [918,936]
===
match
---
trailer [2240,2420]
trailer [2240,2420]
===
match
---
funcdef [2108,2850]
funcdef [2108,2850]
===
match
---
simple_stmt [2484,2612]
simple_stmt [2484,2612]
===
match
---
string: "apache-airflow-providers" [2078,2104]
string: "apache-airflow-providers" [2078,2104]
===
match
---
simple_stmt [809,825]
simple_stmt [809,825]
===
match
---
operator: = [3299,3300]
operator: = [3299,3300]
===
match
---
import_from [872,936]
import_from [872,936]
===
match
---
operator: , [2688,2689]
operator: , [2688,2689]
===
match
---
arglist [2250,2414]
arglist [2250,2414]
===
match
---
operator: } [3225,3226]
operator: } [3225,3226]
===
match
---
fstring_end: " [3226,3227]
fstring_end: " [3226,3227]
===
match
---
atom_expr [2484,2611]
atom_expr [2484,2611]
===
match
---
operator: = [2537,2538]
operator: = [2537,2538]
===
match
---
string: 'Before using this script, set the environment variable AIRFLOW_SITE_DIRECTORY. This variable ' [1562,1657]
string: 'Before using this script, set the environment variable AIRFLOW_SITE_DIRECTORY. This variable ' [1562,1657]
===
match
---
atom_expr [3396,3402]
atom_expr [3411,3417]
===
match
---
name: ArgumentParser [2226,2240]
name: ArgumentParser [2226,2240]
===
match
---
name: docs_build [952,962]
name: docs_build [952,962]
===
match
---
name: package_name [3333,3345]
name: package_name [3333,3345]
===
match
---
atom_expr [2947,2971]
atom_expr [2947,2971]
===
match
---
name: docs_build [887,897]
name: docs_build [887,897]
===
match
---
trailer [2172,2177]
trailer [2172,2177]
===
match
---
parameters [2123,2125]
parameters [2123,2125]
===
match
---
name: help [2698,2702]
name: help [2698,2702]
===
match
---
name: description [2250,2261]
name: description [2250,2261]
===
match
---
string: '${AIRFLOW_SITE_DIRECTORY}/docs-archive must exists.' [1743,1796]
string: '${AIRFLOW_SITE_DIRECTORY}/docs-archive must exists.' [1743,1796]
===
match
---
import_from [937,1008]
import_from [937,1008]
===
match
---
name: os [832,834]
name: os [832,834]
===
match
---
operator: * [2053,2054]
operator: * [2053,2054]
===
match
---
expr_stmt [1106,1165]
expr_stmt [1106,1165]
===
match
---
operator: , [2531,2532]
operator: , [2531,2532]
===
match
---
string: """Main code""" [2868,2883]
string: """Main code""" [2868,2883]
===
match
---
trailer [1440,1458]
trailer [1440,1458]
===
match
---
atom_expr [3233,3240]
atom_expr [3233,3240]
===
match
---
string: 'disable_checks' [2538,2554]
string: 'disable_checks' [2538,2554]
===
match
---
operator: , [2823,2824]
operator: , [2823,2824]
===
match
---
string: "__main__" [1182,1192]
string: "__main__" [1182,1192]
===
match
---
name: docs [1014,1018]
name: docs [1014,1018]
===
match
---
atom_expr [3039,3099]
atom_expr [3039,3099]
===
match
---
name: dest [2533,2537]
name: dest [2533,2537]
===
match
---
operator: , [1510,1511]
operator: , [1510,1511]
===
match
---
for_stmt [3245,3394]
for_stmt [3245,3409]
===
match
---
trailer [2458,2479]
trailer [2458,2479]
===
match
---
name: exts [1019,1023]
name: exts [1019,1023]
===
match
---
operator: = [2945,2946]
operator: = [2945,2946]
===
match
---
name: load_package_data [1051,1068]
name: load_package_data [1051,1068]
===
match
---
simple_stmt [2888,2922]
simple_stmt [2888,2922]
===
match
---
operator: = [1123,1124]
operator: = [1123,1124]
===
match
---
expr_stmt [2425,2479]
expr_stmt [2425,2479]
===
match
---
name: _get_parser [2112,2123]
name: _get_parser [2112,2123]
===
match
---
name: ALL_PROVIDER_YAMLS [2003,2021]
name: ALL_PROVIDER_YAMLS [2003,2021]
===
match
---
operator: { [3132,3133]
operator: { [3132,3133]
===
match
---
name: provider [1962,1970]
name: provider [1962,1970]
===
match
---
simple_stmt [2131,2204]
simple_stmt [2131,2204]
===
match
---
name: argparse [2450,2458]
name: argparse [2450,2458]
===
match
---
name: SystemExit [1542,1552]
name: SystemExit [1542,1552]
===
match
---
simple_stmt [3291,3368]
simple_stmt [3291,3383]
===
match
---
argument [2332,2413]
argument [2332,2413]
===
match
---
trailer [2622,2635]
trailer [2622,2635]
===
match
---
name: main [2856,2860]
name: main [2856,2860]
===
match
---
atom_expr [1962,1986]
atom_expr [1962,1986]
===
match
---
simple_stmt [1106,1166]
simple_stmt [1106,1166]
===
match
---
not_test [1392,1530]
not_test [1392,1530]
===
match
---
raise_stmt [1198,1387]
raise_stmt [1198,1387]
===
match
---
for_stmt [3173,3229]
for_stmt [3173,3229]
===
match
---
trailer [1552,1802]
trailer [1552,1802]
===
match
---
operator: + [2163,2164]
operator: + [2163,2164]
===
match
---
name: isdir [1475,1480]
name: isdir [1475,1480]
===
match
---
operator: , [2051,2052]
operator: , [2051,2052]
===
match
---
atom_expr [1481,1527]
atom_expr [1481,1527]
===
match
---
name: ALL_PROVIDER_YAMLS [1804,1822]
name: ALL_PROVIDER_YAMLS [1804,1822]
===
match
---
operator: = [2702,2703]
operator: = [2702,2703]
===
match
---
name: path [1484,1488]
name: path [1484,1488]
===
match
---
operator: = [3361,3362]
operator: = [3361,3362]
===
match
---
simple_stmt [1881,1932]
simple_stmt [1881,1932]
===
match
---
arglist [3320,3366]
arglist [3320,3381]
===
match
---
expr_stmt [3020,3099]
expr_stmt [3020,3099]
===
match
---
trailer [3215,3228]
trailer [3215,3228]
===
match
---
trailer [1842,1844]
trailer [1842,1844]
===
match
---
name: action [2556,2562]
name: action [2556,2562]
===
match
---
name: argparse [816,824]
name: argparse [816,824]
===
match
---
simple_stmt [1198,1388]
simple_stmt [1198,1388]
===
match
---
fstring_start: f" [3216,3218]
fstring_start: f" [3216,3218]
===
match
---
name: os [1125,1127]
name: os [1125,1127]
===
match
---
simple_stmt [2977,3015]
simple_stmt [2977,3015]
===
match
---
simple_stmt [3233,3241]
simple_stmt [3233,3241]
===
match
---
strings [1224,1381]
strings [1224,1381]
===
match
---
strings [2339,2413]
strings [2339,2413]
===
match
---
atom_expr [1467,1528]
atom_expr [1467,1528]
===
match
---
trailer [1493,1527]
trailer [1493,1527]
===
match
---
expr_stmt [2888,2921]
expr_stmt [2888,2921]
===
match
---
simple_stmt [3104,3169]
simple_stmt [3104,3169]
===
match
---
name: provider [1991,1999]
name: provider [1991,1999]
===
match
---
name: available_packages [2926,2944]
name: available_packages [2926,2944]
===
match
---
name: available_packages_list [2385,2408]
name: available_packages_list [2385,2408]
===
match
---
if_stmt [1389,1803]
if_stmt [1389,1803]
===
match
---
simple_stmt [3210,3229]
simple_stmt [3210,3229]
===
match
---
string: 'store_true' [2563,2575]
string: 'store_true' [2563,2575]
===
match
---
name: pkg [3177,3180]
name: pkg [3177,3180]
===
match
---
name: AirflowDocsBuilder [3301,3319]
name: AirflowDocsBuilder [3301,3319]
===
match
---
expr_stmt [2977,3014]
expr_stmt [2977,3014]
===
match
---
name: help [2577,2581]
name: help [2577,2581]
===
match
---
atom_expr [1125,1165]
atom_expr [1125,1165]
===
match
---
name: action [2673,2679]
name: action [2673,2679]
===
match
---
operator: = [2338,2339]
operator: = [2338,2339]
===
match
---
name: args [2888,2892]
name: args [2888,2892]
===
match
---
string: 'Copies the built documentation to airflow-site repository.' [2262,2322]
string: 'Copies the built documentation to airflow-site repository.' [2262,2322]
===
match
---
string: 'package-name' [1971,1985]
string: 'package-name' [1971,1985]
===
match
---
simple_stmt [2027,2106]
simple_stmt [2027,2106]
===
match
---
sync_comp_for [1987,2021]
sync_comp_for [1987,2021]
===
match
---
atom_expr [3376,3393]
atom_expr [3391,3408]
===
match
---
trailer [1139,1165]
trailer [1139,1165]
===
match
---
trailer [3238,3240]
trailer [3238,3240]
===
match
---
fstring_end: " [2409,2410]
fstring_end: " [2409,2410]
===
match
---
trailer [3319,3367]
trailer [3319,3382]
===
match
---
simple_stmt [937,1009]
simple_stmt [937,1009]
===
match
---
name: parser [2616,2622]
name: parser [2616,2622]
===
match
---
atom_expr [2895,2921]
atom_expr [2895,2921]
===
match
---
trailer [2999,3014]
trailer [2999,3014]
===
match
---
name: process_package_filters [3039,3062]
name: process_package_filters [3039,3062]
===
match
---
operator: = [2562,2563]
operator: = [2562,2563]
===
match
---
name: print [3233,3238]
name: print [3233,3238]
===
match
---
trailer [1480,1528]
trailer [1480,1528]
===
match
---
name: available_packages_list [2131,2154]
name: available_packages_list [2131,2154]
===
match
---
simple_stmt [825,835]
simple_stmt [825,835]
===
match
---
name: package_name [3320,3332]
name: package_name [3320,3332]
===
match
---
dotted_name [942,977]
dotted_name [942,977]
===
match
---
fstring_start: f" [3110,3112]
fstring_start: f" [3110,3112]
===
match
---
name: package_filter [3000,3014]
name: package_filter [3000,3014]
===
match
---
suite [3201,3229]
suite [3201,3229]
===
match
---
fstring [3216,3227]
fstring [3216,3227]
===
match
---
import_name [809,824]
import_name [809,824]
===
match
---
name: get [1136,1139]
name: get [1136,1139]
===
match
---
fstring_string: List of supported documentation packages:\n [2341,2384]
fstring_string: List of supported documentation packages:\n [2341,2384]
===
match
---
and_test [1402,1528]
and_test [1402,1528]
===
match
---
string: " * " [2157,2162]
string: " * " [2157,2162]
===
match
---
fstring_expr [2384,2409]
fstring_expr [2384,2409]
===
match
---
atom_expr [3104,3168]
atom_expr [3104,3168]
===
match
---
trailer [1483,1488]
trailer [1483,1488]
===
match
---
name: join [2173,2177]
name: join [2173,2177]
===
match
---
operator: , [2575,2576]
operator: , [2575,2576]
===
match
---
string: "" [2411,2413]
string: "" [2411,2413]
===
match
---
trailer [2635,2830]
trailer [2635,2830]
===
match
---
atom_expr [3210,3228]
atom_expr [3210,3228]
===
match
---
name: get_available_packages [1851,1873]
name: get_available_packages [1851,1873]
===
match
---
expr_stmt [3291,3367]
expr_stmt [3291,3382]
===
match
---
simple_stmt [2425,2480]
simple_stmt [2425,2480]
===
match
---
argument [2533,2554]
argument [2533,2554]
===
match
---
name: exts [882,886]
name: exts [882,886]
===
match
---
trailer [2490,2503]
trailer [2490,2503]
===
match
---
name: main [3396,3400]
name: main [3411,3415]
===
match
---
operator: , [3081,3082]
operator: , [3081,3082]
===
match
---
atom_expr [2450,2479]
atom_expr [2450,2479]
===
match
---
import_from [1009,1068]
import_from [1009,1068]
===
match
---
name: builder [3291,3298]
name: builder [3291,3298]
===
match
---
atom_expr [2425,2447]
atom_expr [2425,2447]
===
match
---
operator: = [1959,1960]
operator: = [1959,1960]
===
match
---
atom_expr [1204,1387]
atom_expr [1204,1387]
===
match
---
name: path [1430,1434]
name: path [1430,1434]
===
match
---
name: builder [3376,3383]
name: builder [3391,3398]
===
match
---
trailer [1429,1434]
trailer [1429,1434]
===
match
---
simple_stmt [2868,2884]
simple_stmt [2868,2884]
===
match
---
name: epilog [2332,2338]
name: epilog [2332,2338]
===
match
---
name: parser [2484,2490]
name: parser [2484,2490]
===
match
---
suite [1193,1388]
suite [1193,1388]
===
match
---
atom_expr [2178,2202]
atom_expr [2178,2202]
===
match
---
suite [3282,3394]
suite [3282,3409]
===
match
---
trailer [3136,3154]
trailer [3136,3154]
===
insert-node
---
operator: , [3366,3367]
to
arglist [3320,3366]
at 3
===
insert-tree
---
argument [3368,3381]
    name: verbose [3368,3375]
    operator: = [3375,3376]
to
arglist [3320,3366]
at 4
