===
match
---
name: data [8286,8290]
name: data [8286,8290]
===
match
---
argument [3343,3364]
argument [3343,3364]
===
match
---
atom_expr [5654,5732]
atom_expr [5654,5732]
===
match
---
name: container_name [9737,9751]
name: container_name [9737,9751]
===
match
---
if_stmt [3417,3742]
if_stmt [3417,3742]
===
match
---
name: log [12665,12668]
name: log [12673,12676]
===
match
---
name: app_id [3496,3502]
name: app_id [3496,3502]
===
match
---
name: append [7594,7600]
name: append [7594,7600]
===
match
---
name: container_name [5676,5690]
name: container_name [5676,5690]
===
match
---
atom_expr [6593,6612]
atom_expr [6593,6612]
===
match
---
string: "Deleted blobs: %s" [14065,14084]
string: "Deleted blobs: %s" [14073,14092]
===
match
---
operator: * [13497,13498]
operator: * [13505,13506]
===
match
---
param [4326,4331]
param [4326,4331]
===
match
---
operator: = [6398,6399]
operator: = [6398,6399]
===
match
---
atom_expr [11205,11253]
atom_expr [11213,11261]
===
match
---
trailer [11292,11334]
trailer [11300,11342]
===
match
---
operator: , [8969,8970]
operator: , [8969,8970]
===
match
---
name: self [14123,14127]
name: self [14131,14135]
===
match
---
fstring_string: https:// [4025,4033]
fstring_string: https:// [4025,4033]
===
match
---
suite [13379,13448]
suite [13387,13456]
===
match
---
funcdef [9717,10233]
funcdef [9717,10241]
===
match
---
import_from [1158,1202]
import_from [1158,1202]
===
match
---
expr_stmt [2265,2297]
expr_stmt [2265,2297]
===
match
---
name: sas_token [4072,4081]
name: sas_token [4072,4081]
===
match
---
trailer [12536,12540]
trailer [12544,12548]
===
match
---
atom_expr [3377,3407]
atom_expr [3377,3407]
===
match
---
trailer [13255,13272]
trailer [13263,13280]
===
match
---
operator: , [1186,1187]
operator: , [1186,1187]
===
match
---
expr_stmt [9582,9666]
expr_stmt [9582,9666]
===
match
---
name: str [6649,6652]
name: str [6649,6652]
===
match
---
return_stmt [5804,5815]
return_stmt [5804,5815]
===
match
---
atom_expr [3193,3223]
atom_expr [3193,3223]
===
match
---
simple_stmt [2242,2261]
simple_stmt [2242,2261]
===
match
---
trailer [3425,3429]
trailer [3425,3429]
===
match
---
operator: ** [15363,15365]
operator: ** [15371,15373]
===
match
---
name: fileblob [9560,9568]
name: fileblob [9560,9568]
===
match
---
arglist [13406,13446]
arglist [13414,13454]
===
match
---
simple_stmt [4145,4295]
simple_stmt [4145,4295]
===
match
---
name: delete_blobs [13457,13469]
name: delete_blobs [13465,13477]
===
match
---
arglist [14025,14041]
arglist [14033,14049]
===
match
---
fstring_expr [4209,4221]
fstring_expr [4209,4221]
===
match
---
operator: , [8263,8264]
operator: , [8263,8264]
===
match
---
arglist [14974,15016]
arglist [14982,15024]
===
match
---
return_stmt [2989,3036]
return_stmt [2989,3036]
===
match
---
trailer [14011,14024]
trailer [14019,14032]
===
match
---
name: delimiter [7524,7533]
name: delimiter [7524,7533]
===
match
---
operator: , [9032,9033]
operator: , [9032,9033]
===
match
---
simple_stmt [9793,10157]
simple_stmt [9793,10157]
===
match
---
operator: , [7512,7513]
operator: , [7512,7513]
===
match
---
name: include [7505,7512]
name: include [7505,7512]
===
match
---
fstring_start: f' [15267,15269]
fstring_start: f' [15275,15277]
===
match
---
name: str [4678,4681]
name: str [4678,4681]
===
match
---
param [5869,5881]
param [5869,5881]
===
match
---
name: List [6688,6692]
name: List [6688,6692]
===
match
---
try_stmt [13116,13448]
try_stmt [13124,13456]
===
match
---
name: blobs [14086,14091]
name: blobs [14094,14099]
===
match
---
try_stmt [5637,5796]
try_stmt [5637,5796]
===
match
---
name: ResourceExistsError [1238,1257]
name: ResourceExistsError [1238,1257]
===
match
---
arglist [13147,13199]
arglist [13155,13207]
===
match
---
simple_stmt [2405,2424]
simple_stmt [2405,2424]
===
match
---
operator: , [12926,12927]
operator: , [12934,12935]
===
match
---
if_stmt [3046,3225]
if_stmt [3046,3225]
===
match
---
param [14223,14255]
param [14231,14263]
===
match
---
suite [12957,13448]
suite [12965,13456]
===
match
---
name: get [3426,3429]
name: get [3426,3429]
===
match
---
operator: , [6507,6508]
operator: , [6507,6508]
===
match
---
name: blob_name [8960,8969]
name: blob_name [8960,8969]
===
match
---
name: BlobServiceClient [2568,2585]
name: BlobServiceClient [2568,2585]
===
match
---
trailer [3054,3058]
trailer [3054,3058]
===
match
---
name: open [8179,8183]
name: open [8179,8183]
===
match
---
tfpdef [4662,4681]
tfpdef [4662,4681]
===
match
---
atom_expr [3505,3515]
atom_expr [3505,3515]
===
match
---
name: self [2785,2789]
name: self [2785,2789]
===
match
---
suite [8407,8994]
suite [8407,8994]
===
match
---
param [9758,9773]
param [9758,9773]
===
match
---
suite [15078,15121]
suite [15086,15129]
===
match
---
arglist [12142,12180]
arglist [12150,12188]
===
match
---
operator: = [4257,4258]
operator: = [4257,4258]
===
match
---
operator: , [7697,7698]
operator: , [7697,7698]
===
match
---
atom_expr [9694,9710]
atom_expr [9694,9710]
===
match
---
name: token_credential [3724,3740]
name: token_credential [3724,3740]
===
match
---
expr_stmt [4982,5038]
expr_stmt [4982,5038]
===
match
---
trailer [13239,13255]
trailer [13247,13263]
===
match
---
simple_stmt [9090,9522]
simple_stmt [9090,9522]
===
match
---
operator: , [8284,8285]
operator: , [8284,8285]
===
match
---
param [13505,13513]
param [13513,13521]
===
match
---
trailer [12056,12073]
trailer [12064,12081]
===
match
---
argument [15345,15361]
argument [15353,15369]
===
match
---
return_stmt [4145,4294]
return_stmt [4145,4294]
===
match
---
argument [6415,6428]
argument [6415,6428]
===
match
---
name: container_name [12491,12505]
name: container_name [12499,12513]
===
match
---
tfpdef [9034,9053]
tfpdef [9034,9053]
===
match
---
trailer [9693,9711]
trailer [9693,9711]
===
match
---
trailer [15328,15372]
trailer [15336,15380]
===
match
---
operator: -> [11470,11472]
operator: -> [11478,11480]
===
match
---
operator: = [14206,14207]
operator: = [14214,14215]
===
match
---
trailer [10383,10388]
trailer [10391,10396]
===
match
---
name: is_prefix [14913,14922]
name: is_prefix [14921,14930]
===
match
---
param [4332,4351]
param [4332,4351]
===
match
---
suite [6693,7637]
suite [6693,7637]
===
match
---
operator: = [2445,2446]
operator: = [2445,2446]
===
match
---
name: container_name [13432,13446]
name: container_name [13440,13454]
===
match
---
name: container_name [14137,14151]
name: container_name [14145,14159]
===
match
---
trailer [12645,12647]
trailer [12653,12655]
===
match
---
name: core [1215,1219]
name: core [1215,1219]
===
match
---
param [4656,4661]
param [4656,4661]
===
match
---
operator: = [9645,9646]
operator: = [9645,9646]
===
match
---
suite [12786,12896]
suite [12794,12904]
===
match
---
operator: , [14127,14128]
operator: , [14135,14136]
===
match
---
trailer [7593,7600]
trailer [7593,7600]
===
match
---
arglist [3609,3651]
arglist [3609,3651]
===
match
---
name: data [8291,8295]
name: data [8291,8295]
===
match
---
tfpdef [2322,2339]
tfpdef [2322,2339]
===
match
---
name: blobs [6459,6464]
name: blobs [6459,6464]
===
match
---
name: self [4326,4330]
name: self [4326,4330]
===
match
---
name: kwargs [8299,8305]
name: kwargs [8299,8305]
===
match
---
trailer [2410,2412]
trailer [2410,2412]
===
match
---
atom_expr [11269,11334]
atom_expr [11277,11342]
===
match
---
atom_expr [2699,2732]
atom_expr [2699,2732]
===
match
---
atom_expr [4034,4044]
atom_expr [4034,4044]
===
match
---
string: '/' [6656,6659]
string: '/' [6656,6659]
===
match
---
name: kwargs [9659,9665]
name: kwargs [9659,9665]
===
match
---
name: conn_id [2724,2731]
name: conn_id [2724,2731]
===
match
---
string: """         List blobs in a given container          :param container_name: The name of the container         :type container_name: str         :param prefix: Filters the results to return only blobs whose names             begin with the specified prefix.         :type prefix: str         :param include: Specifies one or more additional datasets to include in the             response. Options include: ``snapshots``, ``metadata``, ``uncommittedblobs``,             ``copy`, ``deleted``.         :type include: List[str]         :param delimiter: filters objects based on the delimiter (for e.g '.csv')         :type delimiter: str         """ [6702,7348]
string: """         List blobs in a given container          :param container_name: The name of the container         :type container_name: str         :param prefix: Filters the results to return only blobs whose names             begin with the specified prefix.         :type prefix: str         :param include: Specifies one or more additional datasets to include in the             response. Options include: ``snapshots``, ``metadata``, ``uncommittedblobs``,             ``copy`, ``deleted``.         :type include: List[str]         :param delimiter: filters objects based on the delimiter (for e.g '.csv')         :type delimiter: str         """ [6702,7348]
===
match
---
argument [3878,3912]
argument [3878,3912]
===
match
---
name: kwargs [6432,6438]
name: kwargs [6432,6438]
===
match
---
operator: = [8274,8275]
operator: = [8274,8275]
===
match
---
trailer [3030,3035]
trailer [3030,3035]
===
match
---
operator: , [10395,10396]
operator: , [10403,10404]
===
match
---
subscriptlist [10429,10437]
subscriptlist [10437,10445]
===
match
---
import_from [1331,1433]
import_from [1331,1433]
===
match
---
operator: ** [6669,6671]
operator: ** [6669,6671]
===
match
---
param [12922,12927]
param [12930,12935]
===
match
---
string: 'tenant_id' [3430,3441]
string: 'tenant_id' [3430,3441]
===
match
---
name: account_url [3343,3354]
name: account_url [3343,3354]
===
match
---
string: 'tenant_id' [3619,3630]
string: 'tenant_id' [3619,3630]
===
match
---
operator: = [6613,6614]
operator: = [6613,6614]
===
match
---
name: prefix [14990,14996]
name: prefix [14998,15004]
===
match
---
name: file_path [7662,7671]
name: file_path [7662,7671]
===
match
---
trailer [13217,13239]
trailer [13225,13247]
===
match
---
simple_stmt [2741,2773]
simple_stmt [2741,2773]
===
match
---
name: str [10340,10343]
name: str [10348,10351]
===
match
---
operator: = [3701,3702]
operator: = [3701,3702]
===
match
---
operator: -> [13515,13517]
operator: -> [13523,13525]
===
match
---
argument [6384,6413]
argument [6384,6413]
===
match
---
fstring_start: f" [4199,4201]
fstring_start: f" [4199,4201]
===
match
---
name: offset [12149,12155]
name: offset [12157,12163]
===
match
---
name: base [1502,1506]
name: base [1502,1506]
===
match
---
file_input [789,15373]
file_input [789,15381]
===
match
---
trailer [2718,2732]
trailer [2718,2732]
===
match
---
simple_stmt [3665,3742]
simple_stmt [3665,3742]
===
match
---
tfpdef [6584,6612]
tfpdef [6584,6612]
===
match
---
operator: , [14031,14032]
operator: , [14039,14040]
===
match
---
argument [11325,11333]
argument [11333,11341]
===
match
---
suite [5641,5733]
suite [5641,5733]
===
match
---
argument [5723,5731]
argument [5723,5731]
===
match
---
name: get_conn [2550,2558]
name: get_conn [2550,2558]
===
match
---
string: 'wasb_conn_id' [2184,2198]
string: 'wasb_conn_id' [2184,2198]
===
match
---
operator: , [6677,6678]
operator: , [6677,6678]
===
match
---
argument [10213,10221]
argument [10213,10221]
===
match
---
operator: , [4660,4661]
operator: , [4660,4661]
===
match
---
name: self [5654,5658]
name: self [5654,5658]
===
match
---
funcdef [13453,14093]
funcdef [13461,14101]
===
match
---
operator: = [11203,11204]
operator: = [11211,11212]
===
match
---
dotted_name [1209,1230]
dotted_name [1209,1230]
===
match
---
trailer [4581,4592]
trailer [4581,4592]
===
match
---
suite [2802,3037]
suite [2802,3037]
===
match
---
name: BaseHook [1514,1522]
name: BaseHook [1514,1522]
===
match
---
atom_expr [3860,3913]
atom_expr [3860,3913]
===
match
---
name: Any [10434,10437]
name: Any [10442,10445]
===
match
---
name: delimiter [6629,6638]
name: delimiter [6629,6638]
===
match
---
name: str [5864,5867]
name: str [5864,5867]
===
match
---
name: host [3360,3364]
name: host [3360,3364]
===
match
---
param [6546,6575]
param [6546,6575]
===
match
---
atom_expr [10172,10232]
atom_expr [10172,10240]
===
match
---
operator: -> [14280,14282]
operator: -> [14288,14290]
===
match
---
name: List [1188,1192]
name: List [1188,1192]
===
match
---
atom_expr [3702,3711]
atom_expr [3702,3711]
===
match
---
name: _get_blob_client [12057,12073]
name: _get_blob_client [12065,12081]
===
match
---
operator: , [15006,15007]
operator: , [15014,15015]
===
match
---
name: container_client [12879,12895]
name: container_client [12887,12903]
===
match
---
trailer [3013,3036]
trailer [3013,3036]
===
match
---
trailer [3767,3771]
trailer [3767,3771]
===
match
---
name: credential [4247,4257]
name: credential [4247,4257]
===
match
---
param [5848,5868]
param [5848,5868]
===
match
---
expr_stmt [7443,7544]
expr_stmt [7443,7544]
===
match
---
param [9737,9757]
param [9737,9757]
===
match
---
tfpdef [9055,9069]
tfpdef [9055,9069]
===
match
---
simple_stmt [5901,6348]
simple_stmt [5901,6348]
===
match
---
simple_stmt [12445,12507]
simple_stmt [12453,12515]
===
match
---
name: create_container [12191,12207]
name: create_container [12199,12215]
===
match
---
name: download [11344,11352]
name: download [11352,11360]
===
match
---
name: connection [2512,2522]
name: connection [2512,2522]
===
match
---
atom_expr [13287,13341]
atom_expr [13295,13349]
===
match
---
fstring_end: " [4068,4069]
fstring_end: " [4068,4069]
===
match
---
name: blob_name [15289,15298]
name: blob_name [15297,15306]
===
match
---
name: length [11310,11316]
name: length [11318,11324]
===
match
---
operator: = [2379,2380]
operator: = [2379,2380]
===
match
---
suite [4372,4630]
suite [4372,4630]
===
match
---
arglist [8944,8992]
arglist [8944,8992]
===
match
---
operator: -> [10421,10423]
operator: -> [10429,10431]
===
match
---
name: Any [1177,1180]
name: Any [1177,1180]
===
match
---
name: blob_name [14166,14175]
name: blob_name [14174,14183]
===
match
---
atom_expr [4210,4220]
atom_expr [4210,4220]
===
match
---
atom_expr [12464,12506]
atom_expr [12472,12514]
===
match
---
number: 0 [15229,15230]
number: 0 [15237,15238]
===
match
---
name: self [2699,2703]
name: self [2699,2703]
===
match
---
trailer [14059,14064]
trailer [14067,14072]
===
match
---
funcdef [7642,8307]
funcdef [7642,8307]
===
match
---
name: container_name [6517,6531]
name: container_name [6517,6531]
===
match
---
string: "wb" [9551,9555]
string: "wb" [9551,9555]
===
match
---
operator: ** [5165,5167]
operator: ** [5165,5167]
===
match
---
expr_stmt [2507,2540]
expr_stmt [2507,2540]
===
match
---
name: blob_name [5149,5158]
name: blob_name [5149,5158]
===
match
---
simple_stmt [12038,12101]
simple_stmt [12046,12109]
===
match
---
name: bool [5178,5182]
name: bool [5178,5182]
===
match
---
param [2316,2321]
param [2316,2321]
===
match
---
operator: * [15345,15346]
operator: * [15353,15354]
===
match
---
name: kwargs [5725,5731]
name: kwargs [5725,5731]
===
match
---
simple_stmt [13969,14043]
simple_stmt [13977,14051]
===
match
---
operator: , [2359,2360]
operator: , [2359,2360]
===
match
---
trailer [10176,10185]
trailer [10176,10185]
===
match
---
simple_stmt [12966,13108]
simple_stmt [12974,13116]
===
match
---
trailer [9539,9556]
trailer [9539,9556]
===
match
---
name: self [5842,5846]
name: self [5842,5846]
===
match
---
arglist [5676,5701]
arglist [5676,5701]
===
match
---
operator: = [12462,12463]
operator: = [12470,12471]
===
match
---
name: get_blob_client [5071,5086]
name: get_blob_client [5071,5086]
===
match
---
operator: , [10262,10263]
operator: , [10270,10271]
===
match
---
name: prefix [6422,6428]
name: prefix [6422,6428]
===
match
---
atom_expr [3609,3631]
atom_expr [3609,3631]
===
match
---
name: str [5144,5147]
name: str [5144,5147]
===
match
---
name: extra [3193,3198]
name: extra [3193,3198]
===
match
---
string: 'Container %s not found' [13406,13430]
string: 'Container %s not found' [13414,13438]
===
match
---
name: blob_name [9055,9064]
name: blob_name [9055,9064]
===
match
---
arglist [9540,9555]
arglist [9540,9555]
===
match
---
name: app_secret [3528,3538]
name: app_secret [3528,3538]
===
match
---
operator: , [5880,5881]
operator: , [5880,5881]
===
match
---
trailer [5722,5732]
trailer [5722,5732]
===
match
---
operator: , [11453,11454]
operator: , [11461,11462]
===
match
---
trailer [11209,11226]
trailer [11217,11234]
===
match
---
name: Dict [1182,1186]
name: Dict [1182,1186]
===
match
---
name: container_client [5054,5070]
name: container_client [5054,5070]
===
match
---
string: """         Upload a string to Azure Blob Storage.          :param string_data: String to load.         :type string_data: str         :param container_name: Name of the container.         :type container_name: str         :param blob_name: Name of the blob.         :type blob_name: str         :param kwargs: Optional keyword arguments that ``BlobClient.upload()`` takes.         :type kwargs: object         """ [8416,8830]
string: """         Upload a string to Azure Blob Storage.          :param string_data: String to load.         :type string_data: str         :param container_name: Name of the container.         :type container_name: str         :param blob_name: Name of the blob.         :type blob_name: str         :param kwargs: Optional keyword arguments that ``BlobClient.upload()`` takes.         :type kwargs: object         """ [8416,8830]
===
match
---
name: Dict [10424,10428]
name: Dict [10432,10436]
===
match
---
trailer [4214,4220]
trailer [4214,4220]
===
match
---
simple_stmt [1435,1483]
simple_stmt [1435,1483]
===
match
---
name: self [12464,12468]
name: self [12472,12476]
===
match
---
argument [7472,7495]
argument [7472,7495]
===
match
---
trailer [10428,10438]
trailer [10436,10446]
===
match
---
name: self [13133,13137]
name: self [13141,13145]
===
match
---
atom_expr [15250,15301]
atom_expr [15258,15309]
===
match
---
name: container_name [9034,9048]
name: container_name [9034,9048]
===
match
---
operator: = [6654,6655]
operator: = [6654,6655]
===
match
---
not_test [15179,15200]
not_test [15187,15208]
===
match
---
name: length [12157,12163]
name: length [12165,12171]
===
match
---
name: blob_name [10202,10211]
name: blob_name [10202,10211]
===
match
---
name: get [3199,3202]
name: get [3199,3202]
===
match
---
expr_stmt [3496,3515]
expr_stmt [3496,3515]
===
match
---
trailer [3895,3899]
trailer [3895,3899]
===
match
---
param [11455,11463]
param [11463,11471]
===
match
---
string: 'shared_access_key' [3246,3265]
string: 'shared_access_key' [3246,3265]
===
match
---
expr_stmt [15147,15167]
expr_stmt [15155,15175]
===
match
---
atom_expr [2405,2423]
atom_expr [2405,2423]
===
match
---
simple_stmt [2989,3037]
simple_stmt [2989,3037]
===
match
---
simple_stmt [12532,12600]
simple_stmt [12540,12608]
===
match
---
name: BlobServiceClient [3325,3342]
name: BlobServiceClient [3325,3342]
===
match
---
atom_expr [8179,8200]
atom_expr [8179,8200]
===
match
---
trailer [5675,5702]
trailer [5675,5702]
===
match
---
atom_expr [13969,14042]
atom_expr [13977,14050]
===
match
---
trailer [13995,14011]
trailer [14003,14019]
===
match
---
name: conn [3026,3030]
name: conn [3026,3030]
===
match
---
trailer [3192,3224]
trailer [3192,3224]
===
match
---
name: connection [4582,4592]
name: connection [4582,4592]
===
match
---
operator: , [13430,13431]
operator: , [13438,13439]
===
match
---
operator: ** [10213,10215]
operator: ** [10213,10215]
===
match
---
name: conn [3702,3706]
name: conn [3702,3706]
===
match
---
name: account_url [3878,3889]
name: account_url [3878,3889]
===
match
---
expr_stmt [12445,12506]
expr_stmt [12453,12514]
===
match
---
atom_expr [12532,12599]
atom_expr [12540,12607]
===
match
---
name: hook_name [2265,2274]
name: hook_name [2265,2274]
===
match
---
trailer [12545,12599]
trailer [12553,12607]
===
match
---
operator: , [6659,6660]
operator: , [6659,6660]
===
match
---
funcdef [8999,9712]
funcdef [8999,9712]
===
match
---
name: len [6455,6458]
name: len [6455,6458]
===
match
---
name: public_read [2473,2484]
name: public_read [2473,2484]
===
match
---
simple_stmt [13133,13201]
simple_stmt [13141,13209]
===
match
---
trailer [13141,13146]
trailer [13149,13154]
===
match
---
simple_stmt [15091,15121]
simple_stmt [15099,15129]
===
match
---
name: upload [8937,8943]
name: upload [8937,8943]
===
match
---
name: container_name [10272,10286]
name: container_name [10280,10294]
===
match
---
trailer [12073,12100]
trailer [12081,12108]
===
match
---
name: Optional [10375,10383]
name: Optional [10383,10391]
===
match
---
name: container_client [12612,12628]
name: container_client [12620,12636]
===
match
---
name: get_connection [2704,2718]
name: get_connection [2704,2718]
===
match
---
atom [2770,2772]
atom [2770,2772]
===
match
---
name: identity [1292,1300]
name: identity [1292,1300]
===
match
---
argument [8297,8305]
argument [8297,8305]
===
match
---
name: check_for_blob [15036,15050]
name: check_for_blob [15044,15058]
===
match
---
name: conn [3355,3359]
name: conn [3355,3359]
===
match
---
operator: , [3639,3640]
operator: , [3639,3640]
===
match
---
name: BlobServiceClient [3152,3169]
name: BlobServiceClient [3152,3169]
===
match
---
atom_expr [12052,12100]
atom_expr [12060,12108]
===
match
---
operator: , [15343,15344]
operator: , [15351,15352]
===
match
---
suite [5892,6470]
suite [5892,6470]
===
match
---
argument [8234,8263]
argument [8234,8263]
===
match
---
trailer [4169,4294]
trailer [4169,4294]
===
match
---
param [4662,4682]
param [4662,4682]
===
match
---
atom_expr [9535,9556]
atom_expr [9535,9556]
===
match
---
return_stmt [5047,5097]
return_stmt [5047,5097]
===
match
---
name: blob_client [11269,11280]
name: blob_client [11277,11288]
===
match
---
operator: , [14988,14989]
operator: , [14996,14997]
===
match
---
operator: , [3364,3365]
operator: , [3364,3365]
===
match
---
param [7678,7698]
param [7678,7698]
===
match
---
name: self [13969,13973]
name: self [13977,13981]
===
match
---
name: readall [9701,9708]
name: readall [9701,9708]
===
match
---
arglist [3690,3740]
arglist [3690,3740]
===
match
---
name: offset [12142,12148]
name: offset [12150,12156]
===
match
---
string: """         Download a file from Azure Blob Storage.          :param file_path: Path to the file to download.         :type file_path: str         :param container_name: Name of the container.         :type container_name: str         :param blob_name: Name of the blob.         :type blob_name: str         :param kwargs: Optional keyword arguments that `BlobClient.download_blob()` takes.         :type kwargs: object         """ [9090,9521]
string: """         Download a file from Azure Blob Storage.          :param file_path: Path to the file to download.         :type file_path: str         :param container_name: Name of the container.         :type container_name: str         :param blob_name: Name of the blob.         :type blob_name: str         :param kwargs: Optional keyword arguments that `BlobClient.download_blob()` takes.         :type kwargs: object         """ [9090,9521]
===
match
---
operator: , [11297,11298]
operator: , [11305,11306]
===
match
---
name: kwargs [7537,7543]
name: kwargs [7537,7543]
===
match
---
name: self [10172,10176]
name: self [10172,10176]
===
match
---
name: bool [14201,14205]
name: bool [14209,14213]
===
match
---
name: conn_id [2437,2444]
name: conn_id [2437,2444]
===
match
---
string: """         Upload a file to Azure Blob Storage.          :param file_path: Path to the file to load.         :type file_path: str         :param container_name: Name of the container.         :type container_name: str         :param blob_name: Name of the blob.         :type blob_name: str         :param kwargs: Optional keyword arguments that ``BlobClient.upload_blob()`` takes.         :type kwargs: object         """ [7742,8165]
string: """         Upload a file to Azure Blob Storage.          :param file_path: Path to the file to load.         :type file_path: str         :param container_name: Name of the container.         :type container_name: str         :param blob_name: Name of the blob.         :type blob_name: str         :param kwargs: Optional keyword arguments that ``BlobClient.upload_blob()`` takes.         :type kwargs: object         """ [7742,8165]
===
match
---
number: 0 [6468,6469]
number: 0 [6468,6469]
===
match
---
name: self [13392,13396]
name: self [13400,13404]
===
match
---
name: credential [3366,3376]
name: credential [3366,3376]
===
match
---
name: get [3383,3386]
name: get [3383,3386]
===
match
---
trailer [3202,3223]
trailer [3202,3223]
===
match
---
name: data [11293,11297]
name: data [11301,11305]
===
match
---
atom_expr [9679,9711]
atom_expr [9679,9711]
===
match
---
name: password [3546,3554]
name: password [3546,3554]
===
match
---
funcdef [5821,6470]
funcdef [5821,6470]
===
match
---
name: stream [9582,9588]
name: stream [9582,9588]
===
match
---
operator: { [15288,15289]
operator: { [15296,15297]
===
match
---
try_stmt [12515,12896]
try_stmt [12523,12904]
===
match
---
fstring_string: Blob(s) not found:  [15269,15288]
fstring_string: Blob(s) not found:  [15277,15296]
===
match
---
name: str [7673,7676]
name: str [7673,7676]
===
match
---
name: azure [1209,1214]
name: azure [1209,1214]
===
match
---
simple_stmt [7443,7545]
simple_stmt [7443,7545]
===
match
---
operator: = [2275,2276]
operator: = [2275,2276]
===
match
---
trailer [8936,8943]
trailer [8936,8943]
===
match
---
string: """         Marks the specified blobs or snapshots for deletion.          :param container_name: The name of the container containing the blobs         :type container_name: str         :param blobs: The blobs to delete. This can be a single blob, or multiple values             can be supplied, where each value is either the name of the blob (str) or BlobProperties.         :type blobs: Union[str, BlobProperties]         """ [13532,13960]
string: """         Marks the specified blobs or snapshots for deletion.          :param container_name: The name of the container containing the blobs         :type container_name: str         :param blobs: The blobs to delete. This can be a single blob, or multiple values             can be supplied, where each value is either the name of the blob (str) or BlobProperties.         :type blobs: Union[str, BlobProperties]         """ [13540,13968]
===
match
---
atom [15109,15120]
atom [15117,15128]
===
match
---
name: bool [2374,2378]
name: bool [2374,2378]
===
match
---
name: Optional [1194,1202]
name: Optional [1194,1202]
===
match
---
trailer [6601,6612]
trailer [6601,6612]
===
match
---
operator: = [2747,2748]
operator: = [2747,2748]
===
match
---
operator: , [8371,8372]
operator: , [8371,8372]
===
match
---
expr_stmt [3528,3554]
expr_stmt [3528,3554]
===
match
---
operator: , [1192,1193]
operator: , [1192,1193]
===
match
---
name: container_name [13240,13254]
name: container_name [13248,13262]
===
match
---
simple_stmt [5192,5629]
simple_stmt [5192,5629]
===
match
---
operator: = [4022,4023]
operator: = [4022,4023]
===
match
---
name: self [2316,2320]
name: self [2316,2320]
===
match
---
name: Optional [11433,11441]
name: Optional [11441,11449]
===
match
---
operator: ** [8297,8299]
operator: ** [8297,8299]
===
match
---
simple_stmt [5047,5098]
simple_stmt [5047,5098]
===
match
---
operator: , [9735,9736]
operator: , [9735,9736]
===
match
---
operator: , [11382,11383]
operator: , [11390,11391]
===
match
---
funcdef [14098,15373]
funcdef [14106,15381]
===
match
---
name: info [12541,12545]
name: info [12549,12553]
===
match
---
param [9055,9070]
param [9055,9070]
===
match
---
for_stmt [7553,7612]
for_stmt [7553,7612]
===
match
---
simple_stmt [12263,12437]
simple_stmt [12271,12445]
===
match
---
simple_stmt [3318,3409]
simple_stmt [3318,3409]
===
match
---
operator: , [6413,6414]
operator: , [6413,6414]
===
match
---
name: _get_blob_client [5659,5675]
name: _get_blob_client [5659,5675]
===
match
---
name: AirflowException [15250,15266]
name: AirflowException [15258,15274]
===
match
---
atom_expr [3152,3224]
atom_expr [3152,3224]
===
match
---
name: int [10384,10387]
name: int [10392,10395]
===
match
---
name: get [3055,3058]
name: get [3055,3058]
===
match
---
tfpdef [14166,14180]
tfpdef [14174,14188]
===
match
---
trailer [13396,13400]
trailer [13404,13408]
===
match
---
name: self [4656,4660]
name: self [4656,4660]
===
match
---
expr_stmt [2741,2772]
expr_stmt [2741,2772]
===
match
---
name: length [10367,10373]
name: length [10375,10381]
===
match
---
expr_stmt [15091,15120]
expr_stmt [15099,15128]
===
match
---
trailer [14055,14059]
trailer [14063,14067]
===
match
---
name: BlobServiceClient [2996,3013]
name: BlobServiceClient [2996,3013]
===
match
---
return_stmt [3986,4082]
return_stmt [3986,4082]
===
match
---
operator: } [4220,4221]
operator: } [4220,4221]
===
match
---
param [2322,2360]
param [2322,2360]
===
match
---
simple_stmt [15147,15168]
simple_stmt [15155,15176]
===
match
---
if_stmt [15176,15302]
if_stmt [15184,15310]
===
match
---
simple_stmt [11506,12030]
simple_stmt [11514,12038]
===
match
---
name: conn_type [2242,2251]
name: conn_type [2242,2251]
===
match
---
param [12928,12947]
param [12936,12955]
===
match
---
operator: = [14247,14248]
operator: = [14255,14256]
===
match
---
simple_stmt [12109,12182]
simple_stmt [12117,12190]
===
match
---
name: ClientSecretCredential [3586,3608]
name: ClientSecretCredential [3586,3608]
===
match
---
name: __init__ [2307,2315]
name: __init__ [2307,2315]
===
match
---
name: log [13397,13400]
name: log [13405,13408]
===
match
---
name: kwargs [8986,8992]
name: kwargs [8986,8992]
===
match
---
operator: , [7495,7496]
operator: , [7495,7496]
===
match
---
name: str [12944,12947]
name: str [12952,12955]
===
match
---
param [8334,8351]
param [8334,8351]
===
match
---
atom_expr [6554,6567]
atom_expr [6554,6567]
===
match
---
trailer [3359,3364]
trailer [3359,3364]
===
match
---
trailer [13295,13300]
trailer [13303,13308]
===
match
---
param [12208,12213]
param [12216,12221]
===
match
---
name: str [8368,8371]
name: str [8368,8371]
===
match
---
suite [3840,3914]
suite [3840,3914]
===
match
---
name: log [12804,12807]
name: log [12812,12815]
===
match
---
argument [7514,7533]
argument [7514,7533]
===
match
---
suite [3973,4083]
suite [3973,4083]
===
match
---
string: 'Attempting to create container: %s' [12546,12582]
string: 'Attempting to create container: %s' [12554,12590]
===
match
---
atom_expr [3355,3364]
atom_expr [3355,3364]
===
match
---
import_from [1435,1482]
import_from [1435,1482]
===
match
---
return_stmt [4570,4629]
return_stmt [4570,4629]
===
match
---
name: log [13138,13141]
name: log [13146,13149]
===
match
---
parameters [12207,12234]
parameters [12215,12242]
===
match
---
operator: = [2221,2222]
operator: = [2221,2222]
===
match
---
name: container_name [8352,8366]
name: container_name [8352,8366]
===
match
---
param [12214,12233]
param [12222,12241]
===
match
---
name: download_blob [12128,12141]
name: download_blob [12136,12149]
===
match
---
name: blobs_to_delete [14936,14951]
name: blobs_to_delete [14944,14959]
===
match
---
operator: , [5690,5691]
operator: , [5690,5691]
===
match
---
operator: -> [6685,6687]
operator: -> [6685,6687]
===
match
---
simple_stmt [7584,7612]
simple_stmt [7584,7612]
===
match
---
atom_expr [3049,3079]
atom_expr [3049,3079]
===
match
---
name: _get_container_client [7374,7395]
name: _get_container_client [7374,7395]
===
match
---
name: log [13292,13295]
name: log [13300,13303]
===
match
---
operator: , [14084,14085]
operator: , [14092,14093]
===
match
---
name: self [7656,7660]
name: self [7656,7660]
===
match
---
name: walk_blobs [7461,7471]
name: walk_blobs [7461,7471]
===
match
---
tfpdef [10329,10343]
tfpdef [10337,10351]
===
match
---
simple_stmt [12799,12860]
simple_stmt [12807,12868]
===
match
---
simple_stmt [9679,9712]
simple_stmt [9679,9712]
===
match
---
name: str [9753,9756]
name: str [9753,9756]
===
match
---
name: container_name [13476,13490]
name: container_name [13484,13498]
===
match
---
name: load_file [7646,7655]
name: load_file [7646,7655]
===
match
---
operator: -> [5175,5177]
operator: -> [5175,5177]
===
match
---
trailer [14973,15017]
trailer [14981,15025]
===
match
---
string: """         Check if a blob exists on Azure Blob Storage.          :param container_name: Name of the container.         :type container_name: str         :param blob_name: Name of the blob.         :type blob_name: str         :param kwargs: Optional keyword arguments for ``BlobClient.get_blob_properties`` takes.         :type kwargs: object         :return: True if the blob exists, False otherwise.         :rtype: bool         """ [5192,5628]
string: """         Check if a blob exists on Azure Blob Storage.          :param container_name: Name of the container.         :type container_name: str         :param blob_name: Name of the blob.         :type blob_name: str         :param kwargs: Optional keyword arguments for ``BlobClient.get_blob_properties`` takes.         :type kwargs: object         :return: True if the blob exists, False otherwise.         :rtype: bool         """ [5192,5628]
===
match
---
operator: + [4070,4071]
operator: + [4070,4071]
===
match
---
operator: , [7713,7714]
operator: , [7713,7714]
===
match
---
simple_stmt [13213,13275]
simple_stmt [13221,13283]
===
match
---
arglist [9605,9665]
arglist [9605,9665]
===
match
---
name: blobs_to_delete [15209,15224]
name: blobs_to_delete [15217,15232]
===
match
---
trailer [15266,15301]
trailer [15274,15309]
===
match
---
simple_stmt [2692,2733]
simple_stmt [2692,2733]
===
match
---
suite [3080,3225]
suite [3080,3225]
===
match
---
operator: , [7676,7677]
operator: , [7676,7677]
===
match
---
simple_stmt [12612,12648]
simple_stmt [12620,12656]
===
match
---
name: kwargs [15010,15016]
name: kwargs [15018,15024]
===
match
---
expr_stmt [11191,11253]
expr_stmt [11199,11261]
===
match
---
param [6517,6537]
param [6517,6537]
===
match
---
argument [15008,15016]
argument [15016,15024]
===
match
---
string: 'rb' [8195,8199]
string: 'rb' [8195,8199]
===
match
---
name: extra [3890,3895]
name: extra [3890,3895]
===
match
---
import_from [1483,1522]
import_from [1483,1522]
===
match
---
name: BlobServiceClient [3672,3689]
name: BlobServiceClient [3672,3689]
===
match
---
name: len [15205,15208]
name: len [15213,15216]
===
match
---
fstring_string: .blob.core.windows.net/ [4045,4068]
fstring_string: .blob.core.windows.net/ [4045,4068]
===
match
---
simple_stmt [14297,14902]
simple_stmt [14305,14910]
===
match
---
tfpdef [10367,10388]
tfpdef [10375,10396]
===
match
---
expr_stmt [2167,2198]
expr_stmt [2167,2198]
===
match
---
trailer [6458,6465]
trailer [6458,6465]
===
match
---
atom_expr [3586,3652]
atom_expr [3586,3652]
===
match
---
name: self [6364,6368]
name: self [6364,6368]
===
match
---
trailer [13405,13447]
trailer [13413,13455]
===
match
---
operator: -> [12235,12237]
operator: -> [12243,12245]
===
match
---
operator: , [10286,10287]
operator: , [10294,10295]
===
match
---
name: hooks [1496,1501]
name: hooks [1496,1501]
===
match
---
operator: -> [2565,2567]
operator: -> [2565,2567]
===
match
---
fstring_expr [4033,4045]
fstring_expr [4033,4045]
===
match
---
operator: , [11366,11367]
operator: , [11374,11375]
===
match
---
arglist [10186,10221]
arglist [10186,10221]
===
match
---
name: str [14153,14156]
name: str [14161,14164]
===
match
---
name: upload [8227,8233]
name: upload [8227,8233]
===
match
---
trailer [12141,12181]
trailer [12149,12189]
===
match
---
operator: , [12155,12156]
operator: , [12163,12164]
===
match
---
trailer [2412,2421]
trailer [2412,2421]
===
match
---
simple_stmt [14936,15018]
simple_stmt [14944,15026]
===
match
---
trailer [7460,7471]
trailer [7460,7471]
===
match
---
parameters [7655,7724]
parameters [7655,7724]
===
match
---
name: extra [3377,3382]
name: extra [3377,3382]
===
match
---
name: blob [7557,7561]
name: blob [7557,7561]
===
match
---
string: 'Azure Blob Storage' [2277,2297]
string: 'Azure Blob Storage' [2277,2297]
===
match
---
atom_expr [2785,2801]
atom_expr [2785,2801]
===
match
---
name: List [6602,6606]
name: List [6602,6606]
===
match
---
trailer [5022,5038]
trailer [5022,5038]
===
match
---
string: 'https' [3964,3971]
string: 'https' [3964,3971]
===
match
---
atom_expr [2507,2522]
atom_expr [2507,2522]
===
match
---
param [7699,7714]
param [7699,7714]
===
match
---
name: kwargs [10215,10221]
name: kwargs [10215,10221]
===
match
---
name: get [3896,3899]
name: get [3896,3899]
===
match
---
simple_stmt [9582,9667]
simple_stmt [9582,9667]
===
match
---
operator: ** [15008,15010]
operator: ** [15016,15018]
===
match
---
arglist [3343,3407]
arglist [3343,3407]
===
match
---
name: Optional [6640,6648]
name: Optional [6640,6648]
===
match
---
operator: , [1372,1373]
operator: , [1372,1373]
===
match
---
name: BlobClient [1362,1372]
name: BlobClient [1362,1372]
===
match
---
trailer [13291,13295]
trailer [13299,13303]
===
match
---
name: info [13142,13146]
name: info [13150,13154]
===
match
---
operator: } [2771,2772]
operator: } [2771,2772]
===
match
---
name: blobs_to_delete [15091,15106]
name: blobs_to_delete [15099,15114]
===
match
---
tfpdef [8352,8371]
tfpdef [8352,8371]
===
match
---
param [9071,9079]
param [9071,9079]
===
match
---
name: ResourceNotFoundError [1259,1280]
name: ResourceNotFoundError [1259,1280]
===
match
---
simple_stmt [3853,3914]
simple_stmt [3853,3914]
===
match
---
suite [15134,15168]
suite [15142,15176]
===
match
---
simple_stmt [2641,2684]
simple_stmt [2641,2684]
===
match
---
name: container_name [7396,7410]
name: container_name [7396,7410]
===
match
---
trailer [3899,3912]
trailer [3899,3912]
===
match
---
operator: , [11323,11324]
operator: , [11331,11332]
===
match
---
if_stmt [3793,3914]
if_stmt [3793,3914]
===
match
---
parameters [8327,8398]
parameters [8327,8398]
===
match
---
param [6584,6620]
param [6584,6620]
===
match
---
trailer [3545,3554]
trailer [3545,3554]
===
match
---
return_stmt [3145,3224]
return_stmt [3145,3224]
===
match
---
name: kwargs [9073,9079]
name: kwargs [9073,9079]
===
match
---
name: kwargs [5884,5890]
name: kwargs [5884,5890]
===
match
---
name: name [7606,7610]
name: name [7606,7610]
===
match
---
if_stmt [3922,4295]
if_stmt [3922,4295]
===
match
---
tfpdef [5128,5147]
tfpdef [5128,5147]
===
match
---
name: container_name [12214,12228]
name: container_name [12222,12236]
===
match
---
trailer [2472,2484]
trailer [2472,2484]
===
match
---
suite [14288,15373]
suite [14296,15381]
===
match
---
simple_stmt [3750,3785]
simple_stmt [3750,3785]
===
match
---
import_from [1204,1280]
import_from [1204,1280]
===
match
---
name: str [4694,4697]
name: str [4694,4697]
===
match
---
name: delete_blobs [15316,15328]
name: delete_blobs [15324,15336]
===
match
---
name: self [8222,8226]
name: self [8222,8226]
===
match
---
name: container_name [4332,4346]
name: container_name [4332,4346]
===
match
---
name: log [12537,12540]
name: log [12545,12548]
===
match
---
name: login [4039,4044]
name: login [4039,4044]
===
match
---
argument [8984,8992]
argument [8984,8992]
===
match
---
name: kwargs [7717,7723]
name: kwargs [7717,7723]
===
match
---
name: blob_list [7420,7429]
name: blob_list [7420,7429]
===
match
---
suite [4096,4295]
suite [4096,4295]
===
match
---
name: blobs [7565,7570]
name: blobs [7565,7570]
===
match
---
operator: , [10305,10306]
operator: , [10313,10314]
===
match
---
operator: , [15361,15362]
operator: , [15369,15370]
===
match
---
name: self [2559,2563]
name: self [2559,2563]
===
match
---
operator: , [12842,12843]
operator: , [12850,12851]
===
match
---
suite [14923,15018]
suite [14931,15026]
===
match
---
param [4683,4697]
param [4683,4697]
===
match
---
name: delete_container [13256,13272]
name: delete_container [13264,13280]
===
match
---
name: account_url [3014,3025]
name: account_url [3014,3025]
===
match
---
name: info [12808,12812]
name: info [12816,12820]
===
match
---
name: check_for_prefix [5825,5841]
name: check_for_prefix [5825,5841]
===
match
---
atom_expr [7451,7544]
atom_expr [7451,7544]
===
match
---
name: airflow [1488,1495]
name: airflow [1488,1495]
===
match
---
string: "Container %s already exists" [12813,12842]
string: "Container %s already exists" [12821,12850]
===
match
---
name: storage [1342,1349]
name: storage [1342,1349]
===
match
---
tfpdef [8334,8350]
tfpdef [8334,8350]
===
match
---
funcdef [5103,5816]
funcdef [5103,5816]
===
match
---
trailer [3614,3618]
trailer [3614,3618]
===
match
---
param [13476,13496]
param [13484,13504]
===
match
---
operator: , [8193,8194]
operator: , [8193,8194]
===
match
---
name: conn [2692,2696]
name: conn [2692,2696]
===
match
---
and_test [3925,3972]
and_test [3925,3972]
===
match
---
atom_expr [3943,3972]
atom_expr [3943,3972]
===
match
---
dotted_name [1336,1354]
dotted_name [1336,1354]
===
match
---
trailer [6606,6611]
trailer [6606,6611]
===
match
---
suite [15231,15302]
suite [15239,15310]
===
match
---
simple_stmt [3496,3516]
simple_stmt [3496,3516]
===
match
---
simple_stmt [3567,3653]
simple_stmt [3567,3653]
===
match
---
atom_expr [7369,7411]
atom_expr [7369,7411]
===
match
---
arglist [13301,13340]
arglist [13309,13348]
===
match
---
operator: , [13474,13475]
operator: , [13482,13483]
===
match
---
param [13497,13504]
param [13505,13512]
===
match
---
suite [8209,8307]
suite [8209,8307]
===
match
---
atom_expr [11433,11446]
atom_expr [11441,11454]
===
match
---
trailer [14024,14042]
trailer [14032,14050]
===
match
---
name: BlobClient [4702,4712]
name: BlobClient [4702,4712]
===
match
---
trailer [3382,3386]
trailer [3382,3386]
===
match
---
name: blob_name [9758,9767]
name: blob_name [9758,9767]
===
match
---
operator: , [9549,9550]
operator: , [9549,9550]
===
match
---
operator: , [8332,8333]
operator: , [8332,8333]
===
match
---
name: str [10429,10432]
name: str [10437,10440]
===
match
---
operator: , [1408,1409]
operator: , [1408,1409]
===
match
---
trailer [12668,12673]
trailer [12676,12681]
===
match
---
name: extra [3420,3425]
name: extra [3420,3425]
===
match
---
operator: , [1391,1392]
operator: , [1391,1392]
===
match
---
name: conn_name_attr [2167,2181]
name: conn_name_attr [2167,2181]
===
match
---
tfpdef [14223,14246]
tfpdef [14231,14254]
===
match
---
atom_expr [14051,14092]
atom_expr [14059,14100]
===
match
---
arglist [4187,4280]
arglist [4187,4280]
===
match
---
name: prefix [7489,7495]
name: prefix [7489,7495]
===
match
---
name: str [9029,9032]
name: str [9029,9032]
===
match
---
name: _get_blob_client [11210,11226]
name: _get_blob_client [11218,11234]
===
match
---
name: self [2719,2723]
name: self [2719,2723]
===
match
---
arith_expr [4023,4081]
arith_expr [4023,4081]
===
match
---
param [8389,8397]
param [8389,8397]
===
match
---
operator: = [9619,9620]
operator: = [9619,9620]
===
match
---
atom_expr [12612,12647]
atom_expr [12620,12655]
===
match
---
simple_stmt [8222,8307]
simple_stmt [8222,8307]
===
match
---
operator: , [10211,10212]
operator: , [10211,10212]
===
match
---
argument [12172,12180]
argument [12180,12188]
===
match
---
name: ContainerClient [4356,4371]
name: ContainerClient [4356,4371]
===
match
---
except_clause [5741,5769]
except_clause [5741,5769]
===
match
---
name: credential [3713,3723]
name: credential [3713,3723]
===
match
---
operator: == [15226,15228]
operator: == [15234,15236]
===
match
---
trailer [3963,3972]
trailer [3963,3972]
===
match
---
trailer [9604,9666]
trailer [9604,9666]
===
match
---
trailer [9687,9693]
trailer [9687,9693]
===
match
---
simple_stmt [2507,2541]
simple_stmt [2507,2541]
===
match
---
name: create_container [12629,12645]
name: create_container [12637,12653]
===
match
---
name: int [11412,11415]
name: int [11420,11423]
===
match
---
name: offset [11395,11401]
name: offset [11403,11409]
===
match
---
operator: = [7504,7505]
operator: = [7504,7505]
===
match
---
name: container_name [8234,8248]
name: container_name [8234,8248]
===
match
---
name: container_name [12074,12088]
name: container_name [12082,12096]
===
match
---
name: self [12052,12056]
name: self [12060,12064]
===
match
---
tfpdef [6546,6567]
tfpdef [6546,6567]
===
match
---
parameters [13469,13514]
parameters [13477,13522]
===
match
---
argument [8286,8295]
argument [8286,8295]
===
match
---
tfpdef [9737,9756]
tfpdef [9737,9756]
===
match
---
name: include [6584,6591]
name: include [6584,6591]
===
match
---
name: kwargs [15365,15371]
name: kwargs [15373,15379]
===
match
---
operator: , [14254,14255]
operator: , [14262,14263]
===
match
---
name: login [4215,4220]
name: login [4215,4220]
===
match
---
param [2361,2386]
param [2361,2386]
===
match
---
name: container [7451,7460]
name: container [7451,7460]
===
match
---
operator: , [4245,4246]
operator: , [4245,4246]
===
match
---
arglist [8184,8199]
arglist [8184,8199]
===
match
---
simple_stmt [4722,4974]
simple_stmt [4722,4974]
===
match
---
name: self [12922,12926]
name: self [12930,12934]
===
match
---
operator: } [4044,4045]
operator: } [4044,4045]
===
match
---
operator: = [7367,7368]
operator: = [7367,7368]
===
match
---
simple_stmt [8932,8994]
simple_stmt [8932,8994]
===
match
---
name: kwargs [11327,11333]
name: kwargs [11335,11341]
===
match
---
trailer [3386,3407]
trailer [3386,3407]
===
match
---
simple_stmt [15244,15302]
simple_stmt [15252,15310]
===
match
---
name: self [8932,8936]
name: self [8932,8936]
===
match
---
param [14264,14273]
param [14272,14281]
===
match
---
atom_expr [6602,6611]
atom_expr [6602,6611]
===
match
---
name: info [13296,13300]
name: info [13304,13308]
===
match
---
funcdef [2546,4295]
funcdef [2546,4295]
===
match
---
expr_stmt [3750,3784]
expr_stmt [3750,3784]
===
match
---
suite [3267,3409]
suite [3267,3409]
===
match
---
name: prefix [5869,5875]
name: prefix [5869,5875]
===
match
---
name: str [5877,5880]
name: str [5877,5880]
===
match
---
operator: , [6619,6620]
operator: , [6619,6620]
===
match
---
trailer [3819,3830]
trailer [3819,3830]
===
match
---
suite [13120,13342]
suite [13128,13350]
===
match
---
tfpdef [7662,7676]
tfpdef [7662,7676]
===
match
---
trailer [7471,7544]
trailer [7471,7544]
===
match
---
trailer [2529,2538]
trailer [2529,2538]
===
match
---
argument [14990,15006]
argument [14998,15014]
===
match
---
name: ignore_if_missing [14223,14240]
name: ignore_if_missing [14231,14248]
===
match
---
name: blob_name [15110,15119]
name: blob_name [15118,15127]
===
match
---
operator: , [9016,9017]
operator: , [9016,9017]
===
match
---
parameters [2315,2387]
parameters [2315,2387]
===
match
---
name: account_url [3690,3701]
name: account_url [3690,3701]
===
match
---
parameters [5841,5891]
parameters [5841,5891]
===
match
---
parameters [6493,6684]
parameters [6493,6684]
===
match
---
operator: ** [6430,6432]
operator: ** [6430,6432]
===
match
---
simple_stmt [8416,8831]
simple_stmt [8416,8831]
===
match
---
name: kwargs [12174,12180]
name: kwargs [12182,12188]
===
match
---
name: public_read [2361,2372]
name: public_read [2361,2372]
===
match
---
name: self [11362,11366]
name: self [11370,11374]
===
match
---
param [11425,11454]
param [11433,11462]
===
match
---
string: 'wasb' [2254,2260]
string: 'wasb' [2254,2260]
===
match
---
trailer [2703,2718]
trailer [2703,2718]
===
match
---
operator: , [5867,5868]
operator: , [5867,5868]
===
match
---
name: self [5122,5126]
name: self [5122,5126]
===
match
---
parameters [9730,9783]
parameters [9730,9783]
===
match
---
funcdef [12901,13448]
funcdef [12909,13456]
===
match
---
trailer [3608,3652]
trailer [3608,3652]
===
match
---
param [9012,9017]
param [9012,9017]
===
match
---
param [9034,9054]
param [9034,9054]
===
match
---
name: extra [3762,3767]
name: extra [3762,3767]
===
match
---
operator: = [7523,7524]
operator: = [7523,7524]
===
match
---
operator: , [13183,13184]
operator: , [13191,13192]
===
match
---
name: container_name [12928,12942]
name: container_name [12936,12950]
===
match
---
name: ignore_if_missing [15183,15200]
name: ignore_if_missing [15191,15208]
===
match
---
argument [9605,9634]
argument [9605,9634]
===
match
---
name: is_prefix [14190,14199]
name: is_prefix [14198,14207]
===
match
---
arglist [12074,12099]
arglist [12082,12107]
===
match
---
operator: = [7449,7450]
operator: = [7449,7450]
===
match
---
name: BlobServiceClient [1374,1391]
name: BlobServiceClient [1374,1391]
===
match
---
trailer [4613,4629]
trailer [4613,4629]
===
match
---
trailer [5070,5086]
trailer [5070,5086]
===
match
---
atom_expr [12799,12859]
atom_expr [12807,12867]
===
match
---
name: open [9535,9539]
name: open [9535,9539]
===
match
---
trailer [5658,5675]
trailer [5658,5675]
===
match
---
name: extra [3236,3241]
name: extra [3236,3241]
===
match
---
string: """         Read a file from Azure Blob Storage and return as a string.          :param container_name: Name of the container.         :type container_name: str         :param blob_name: Name of the blob.         :type blob_name: str         :param kwargs: Optional keyword arguments that `BlobClient.download_blob` takes.         :type kwargs: object         """ [9793,10156]
string: """         Read a file from Azure Blob Storage and return as a string.          :param container_name: Name of the container.         :type container_name: str         :param blob_name: Name of the blob.         :type blob_name: str         :param kwargs: Optional keyword arguments that `BlobClient.download_blob` takes.         :type kwargs: object         """ [9793,10156]
===
match
---
name: length [12164,12170]
name: length [12172,12178]
===
match
---
simple_stmt [7357,7412]
simple_stmt [7357,7412]
===
match
---
param [5165,5173]
param [5165,5173]
===
match
---
atom_expr [6364,6439]
atom_expr [6364,6439]
===
match
---
trailer [2421,2423]
trailer [2421,2423]
===
match
---
name: conn [3541,3545]
name: conn [3541,3545]
===
match
---
trailer [3342,3408]
trailer [3342,3408]
===
match
---
arglist [11227,11252]
arglist [11235,11260]
===
match
---
arglist [12546,12598]
arglist [12554,12606]
===
match
---
expr_stmt [2432,2459]
expr_stmt [2432,2459]
===
match
---
name: Optional [6554,6562]
name: Optional [6554,6562]
===
match
---
expr_stmt [14936,15017]
expr_stmt [14944,15025]
===
match
---
fstring [15267,15300]
fstring [15275,15308]
===
match
---
name: extra [2741,2746]
name: extra [2741,2746]
===
match
---
name: kwargs [14035,14041]
name: kwargs [14043,14049]
===
match
---
name: self [5001,5005]
name: self [5001,5005]
===
match
---
atom_expr [4258,4271]
atom_expr [4258,4271]
===
match
---
trailer [12468,12490]
trailer [12476,12498]
===
match
---
simple_stmt [4982,5039]
simple_stmt [4982,5039]
===
match
---
trailer [12803,12807]
trailer [12811,12815]
===
match
---
tfpdef [13476,13495]
tfpdef [13484,13503]
===
match
---
argument [4247,4271]
argument [4247,4271]
===
match
---
tfpdef [6629,6653]
tfpdef [6629,6653]
===
match
---
name: _get_blob_client [4639,4655]
name: _get_blob_client [4639,4655]
===
match
---
param [9018,9033]
param [9018,9033]
===
match
---
operator: ** [9071,9073]
operator: ** [9071,9073]
===
match
---
name: download [10177,10185]
name: download [10177,10185]
===
match
---
name: self [9012,9016]
name: self [9012,9016]
===
match
---
if_stmt [14910,15168]
if_stmt [14918,15176]
===
match
---
return_stmt [12109,12181]
return_stmt [12117,12189]
===
match
---
trailer [12490,12506]
trailer [12498,12514]
===
match
---
name: get_blobs_list [6479,6493]
name: get_blobs_list [6479,6493]
===
match
---
return_stmt [11262,11334]
return_stmt [11270,11342]
===
match
---
operator: , [3631,3632]
operator: , [3631,3632]
===
match
---
operator: -> [8399,8401]
operator: -> [8399,8401]
===
match
---
name: conn [2749,2753]
name: conn [2749,2753]
===
match
---
name: self [2468,2472]
name: self [2468,2472]
===
match
---
trailer [12807,12812]
trailer [12815,12820]
===
match
---
operator: , [6428,6429]
operator: , [6428,6429]
===
match
---
operator: = [14952,14953]
operator: = [14960,14961]
===
match
---
string: """         Delete a file from Azure Blob Storage.          :param container_name: Name of the container.         :type container_name: str         :param blob_name: Name of the blob.         :type blob_name: str         :param is_prefix: If blob_name is a prefix, delete all matching files         :type is_prefix: bool         :param ignore_if_missing: if True, then return success even if the             blob does not exist.         :type ignore_if_missing: bool         :param kwargs: Optional keyword arguments that ``ContainerClient.delete_blobs()`` takes.         :type kwargs: object         """ [14297,14901]
string: """         Delete a file from Azure Blob Storage.          :param container_name: Name of the container.         :type container_name: str         :param blob_name: Name of the blob.         :type blob_name: str         :param is_prefix: If blob_name is a prefix, delete all matching files         :type is_prefix: bool         :param ignore_if_missing: if True, then return success even if the             blob does not exist.         :type ignore_if_missing: bool         :param kwargs: Optional keyword arguments that ``ContainerClient.delete_blobs()`` takes.         :type kwargs: object         """ [14305,14909]
===
match
---
name: string_data [8971,8982]
name: string_data [8971,8982]
===
match
---
param [10315,10320]
param [10323,10328]
===
match
---
param [8373,8388]
param [8373,8388]
===
match
---
name: blob_name [9636,9645]
name: blob_name [9636,9645]
===
match
---
name: str [7710,7713]
name: str [7710,7713]
===
match
---
name: blob_type [11299,11308]
name: blob_type [11307,11316]
===
match
---
operator: = [9589,9590]
operator: = [9589,9590]
===
match
---
name: data [10315,10319]
name: data [10323,10327]
===
match
---
fstring [4199,4245]
fstring [4199,4245]
===
match
---
name: info [12669,12673]
name: info [12677,12681]
===
match
---
name: BlobServiceClient [3860,3877]
name: BlobServiceClient [3860,3877]
===
match
---
simple_stmt [11191,11254]
simple_stmt [11199,11262]
===
match
---
trailer [8226,8233]
trailer [8226,8233]
===
match
---
expr_stmt [3567,3652]
expr_stmt [3567,3652]
===
match
---
atom_expr [12660,12714]
atom_expr [12668,12722]
===
match
---
name: self [14051,14055]
name: self [14059,14063]
===
match
---
trailer [3830,3839]
trailer [3830,3839]
===
match
---
name: self [8328,8332]
name: self [8328,8332]
===
match
---
expr_stmt [6356,6439]
expr_stmt [6356,6439]
===
match
---
name: blob_name [11384,11393]
name: blob_name [11392,11401]
===
match
---
suite [7733,8307]
suite [7733,8307]
===
match
---
operator: , [8295,8296]
operator: , [8295,8296]
===
match
---
operator: = [3025,3026]
operator: = [3025,3026]
===
match
---
return_stmt [10165,10232]
return_stmt [10165,10240]
===
match
---
name: file_path [9540,9549]
name: file_path [9540,9549]
===
match
---
trailer [15315,15328]
trailer [15323,15336]
===
match
---
tfpdef [5848,5867]
tfpdef [5848,5867]
===
match
---
name: __init__ [2413,2421]
name: __init__ [2413,2421]
===
match
---
operator: , [2320,2321]
operator: , [2320,2321]
===
match
---
atom_expr [2432,2444]
atom_expr [2432,2444]
===
match
---
simple_stmt [1483,1523]
simple_stmt [1483,1523]
===
match
---
name: container_name [7678,7692]
name: container_name [7678,7692]
===
match
---
operator: , [8958,8959]
operator: , [8958,8959]
===
match
---
trailer [13272,13274]
trailer [13280,13282]
===
match
---
funcdef [11340,12182]
funcdef [11348,12190]
===
match
---
simple_stmt [6356,6440]
simple_stmt [6356,6440]
===
match
---
param [9774,9782]
param [9774,9782]
===
match
---
operator: = [3584,3585]
operator: = [3584,3585]
===
match
---
trailer [3618,3631]
trailer [3618,3631]
===
match
---
parameters [10248,10420]
parameters [10256,10428]
===
match
---
argument [7497,7512]
argument [7497,7512]
===
match
---
name: self [7369,7373]
name: self [7369,7373]
===
match
---
name: blobs [6356,6361]
name: blobs [6356,6361]
===
match
---
param [5122,5127]
param [5122,5127]
===
match
---
atom_expr [9591,9666]
atom_expr [9591,9666]
===
match
---
name: sas_token [3810,3819]
name: sas_token [3810,3819]
===
match
---
funcdef [4300,4630]
funcdef [4300,4630]
===
match
---
name: conn [3505,3509]
name: conn [3505,3509]
===
match
---
operator: , [13324,13325]
operator: , [13332,13333]
===
match
---
operator: -> [7725,7727]
operator: -> [7725,7727]
===
match
---
name: container_name [13326,13340]
name: container_name [13334,13348]
===
match
---
name: get [3768,3771]
name: get [3768,3771]
===
match
---
operator: = [6362,6363]
operator: = [6362,6363]
===
match
---
operator: = [4999,5000]
operator: = [4999,5000]
===
match
---
atom [7432,7434]
atom [7432,7434]
===
match
---
suite [7571,7612]
suite [7571,7612]
===
match
---
argument [12157,12170]
argument [12165,12178]
===
match
---
name: self [13470,13474]
name: self [13478,13482]
===
match
---
name: str [4348,4351]
name: str [4348,4351]
===
match
---
string: """         Downloads a blob to the StorageStreamDownloader          :param container_name: The name of the container containing the blob         :type container_name: str         :param blob_name: The name of the blob to download         :type blob_name: str         :param offset: Start of byte range to use for downloading a section of the blob.             Must be set if length is provided.         :type offset: int         :param length: Number of bytes to read from the stream.         :type length: int         """ [11506,12029]
string: """         Downloads a blob to the StorageStreamDownloader          :param container_name: The name of the container containing the blob         :type container_name: str         :param blob_name: The name of the blob to download         :type blob_name: str         :param offset: Start of byte range to use for downloading a section of the blob.             Must be set if length is provided.         :type offset: int         :param length: Number of bytes to read from the stream.         :type length: int         """ [11514,12037]
===
match
---
trailer [2789,2801]
trailer [2789,2801]
===
match
---
and_test [3796,3839]
and_test [3796,3839]
===
match
---
return_stmt [3853,3913]
return_stmt [3853,3913]
===
match
---
string: 'https' [3831,3838]
string: 'https' [3831,3838]
===
match
---
atom_expr [6455,6465]
atom_expr [6455,6465]
===
match
---
fstring_start: f" [4023,4025]
fstring_start: f" [4023,4025]
===
match
---
name: blob_name [8373,8382]
name: blob_name [8373,8382]
===
match
---
if_stmt [3233,3409]
if_stmt [3233,3409]
===
match
---
name: blob_client [12116,12127]
name: blob_client [12124,12135]
===
match
---
simple_stmt [3145,3225]
simple_stmt [3145,3225]
===
match
---
argument [3014,3035]
argument [3014,3035]
===
match
---
param [10329,10358]
param [10337,10366]
===
match
---
simple_stmt [10448,11183]
simple_stmt [10456,11191]
===
match
---
name: blob_name [11243,11252]
name: blob_name [11251,11260]
===
match
---
string: 'Deleted container: %s' [13301,13324]
string: 'Deleted container: %s' [13309,13332]
===
match
---
trailer [9708,9710]
trailer [9708,9710]
===
match
---
simple_stmt [1281,1331]
simple_stmt [1281,1331]
===
match
---
name: self [12208,12212]
name: self [12216,12220]
===
match
---
name: self [15311,15315]
name: self [15319,15323]
===
match
---
name: blob_list [7627,7636]
name: blob_list [7627,7636]
===
match
---
name: public_read [2790,2801]
name: public_read [2790,2801]
===
match
---
param [5149,5164]
param [5149,5164]
===
match
---
operator: , [11308,11309]
operator: , [11316,11317]
===
match
---
trailer [12673,12714]
trailer [12681,12722]
===
match
---
name: kwargs [8391,8397]
name: kwargs [8391,8397]
===
match
---
trailer [4010,4082]
trailer [4010,4082]
===
match
---
argument [7535,7543]
argument [7535,7543]
===
match
---
name: container_name [12584,12598]
name: container_name [12592,12606]
===
match
---
trailer [14064,14092]
trailer [14072,14100]
===
match
---
expr_stmt [2692,2732]
expr_stmt [2692,2732]
===
match
---
name: self [9591,9595]
name: self [9591,9595]
===
match
---
expr_stmt [7420,7434]
expr_stmt [7420,7434]
===
match
---
expr_stmt [2468,2498]
expr_stmt [2468,2498]
===
match
---
name: prefix [6415,6421]
name: prefix [6415,6421]
===
match
---
name: airflow [1440,1447]
name: airflow [1440,1447]
===
match
---
operator: { [4209,4210]
operator: { [4209,4210]
===
match
---
param [14123,14128]
param [14131,14136]
===
match
---
name: container_name [12844,12858]
name: container_name [12852,12866]
===
match
---
operator: , [9772,9773]
operator: , [9772,9773]
===
match
---
name: self [13287,13291]
name: self [13295,13299]
===
match
---
operator: , [6536,6537]
operator: , [6536,6537]
===
match
---
operator: } [15298,15299]
operator: } [15306,15307]
===
match
---
name: self [15031,15035]
name: self [15039,15043]
===
match
---
trailer [3241,3245]
trailer [3241,3245]
===
match
---
param [10367,10396]
param [10375,10404]
===
match
---
name: kwargs [13507,13513]
name: kwargs [13515,13521]
===
match
---
string: """         Create container object if not already existing          :param container_name: The name of the container to create         :type container_name: str         """ [12263,12436]
string: """         Create container object if not already existing          :param container_name: The name of the container to create         :type container_name: str         """ [12271,12444]
===
match
---
suite [9081,9712]
suite [9081,9712]
===
match
---
string: 'sas_token' [3900,3911]
string: 'sas_token' [3900,3911]
===
match
---
simple_stmt [7742,8166]
simple_stmt [7742,8166]
===
match
---
operator: = [2252,2253]
operator: = [2252,2253]
===
match
---
trailer [4262,4271]
trailer [4262,4271]
===
match
---
name: blob [1350,1354]
name: blob [1350,1354]
===
match
---
operator: = [12148,12149]
operator: = [12156,12157]
===
match
---
operator: * [14025,14026]
operator: * [14033,14034]
===
match
---
name: blobs_to_delete [15147,15162]
name: blobs_to_delete [15155,15170]
===
match
---
name: container_name [13996,14010]
name: container_name [14004,14018]
===
match
---
operator: , [11393,11394]
operator: , [11401,11402]
===
match
---
name: extra [3609,3614]
name: extra [3609,3614]
===
match
---
name: app_id [3633,3639]
name: app_id [3633,3639]
===
match
---
parameters [12921,12948]
parameters [12929,12956]
===
match
---
name: container_name [4662,4676]
name: container_name [4662,4676]
===
match
---
name: log [14056,14059]
name: log [14064,14067]
===
match
---
arglist [6384,6438]
arglist [6384,6438]
===
match
---
name: ResourceNotFoundError [13357,13378]
name: ResourceNotFoundError [13365,13386]
===
match
---
arglist [7472,7543]
arglist [7472,7543]
===
match
---
return_stmt [3665,3741]
return_stmt [3665,3741]
===
match
---
atom_expr [5054,5097]
atom_expr [5054,5097]
===
match
---
name: bool [14242,14246]
name: bool [14250,14254]
===
match
---
atom_expr [2749,2766]
atom_expr [2749,2766]
===
match
---
operator: = [12163,12164]
operator: = [12171,12172]
===
match
---
name: public_read [2487,2498]
name: public_read [2487,2498]
===
match
---
suite [4713,5098]
suite [4713,5098]
===
match
---
name: blob_type [10329,10338]
name: blob_type [10337,10346]
===
match
---
argument [3690,3711]
argument [3690,3711]
===
match
---
operator: = [6421,6422]
operator: = [6421,6422]
===
match
---
atom_expr [2719,2731]
atom_expr [2719,2731]
===
match
---
name: container_name [9605,9619]
name: container_name [9605,9619]
===
match
---
name: blob_name [7699,7708]
name: blob_name [7699,7708]
===
match
---
simple_stmt [2203,2238]
simple_stmt [2203,2238]
===
match
---
parameters [4325,4352]
parameters [4325,4352]
===
match
---
operator: ** [9774,9776]
operator: ** [9774,9776]
===
match
---
tfpdef [12214,12233]
tfpdef [12222,12241]
===
match
---
name: delete_container [12905,12921]
name: delete_container [12913,12929]
===
match
---
simple_stmt [4570,4630]
simple_stmt [4570,4630]
===
match
---
name: container_name [9620,9634]
name: container_name [9620,9634]
===
match
---
trailer [11226,11253]
trailer [11234,11261]
===
match
---
name: get_blobs_list [6369,6383]
name: get_blobs_list [6369,6383]
===
match
---
name: get [3615,3618]
name: get [3615,3618]
===
match
---
operator: ** [7535,7537]
operator: ** [7535,7537]
===
match
---
operator: = [14996,14997]
operator: = [15004,15005]
===
match
---
operator: , [9756,9757]
operator: , [9756,9757]
===
match
---
name: sas_token [3796,3805]
name: sas_token [3796,3805]
===
match
---
name: get [3242,3245]
name: get [3242,3245]
===
match
---
name: startswith [3953,3963]
name: startswith [3953,3963]
===
match
---
trailer [2723,2731]
trailer [2723,2731]
===
match
---
suite [3443,3742]
suite [3443,3742]
===
match
---
trailer [3706,3711]
trailer [3706,3711]
===
match
---
operator: = [11447,11448]
operator: = [11455,11456]
===
match
---
string: 'connection_string' [3059,3078]
string: 'connection_string' [3059,3078]
===
match
---
operator: , [14180,14181]
operator: , [14188,14189]
===
match
---
param [9731,9736]
param [9731,9736]
===
match
---
name: container_client [12445,12461]
name: container_client [12453,12469]
===
match
---
name: blobs_to_delete [15346,15361]
name: blobs_to_delete [15354,15369]
===
match
---
atom_expr [3325,3408]
atom_expr [3325,3408]
===
match
---
argument [11310,11323]
argument [11318,11331]
===
match
---
name: blob_name [8275,8284]
name: blob_name [8275,8284]
===
match
---
tfpdef [5869,5880]
tfpdef [5869,5880]
===
match
---
except_clause [12759,12785]
except_clause [12767,12793]
===
match
---
operator: ** [5882,5884]
operator: ** [5882,5884]
===
match
---
operator: , [10200,10201]
operator: , [10200,10201]
===
match
---
name: token_credential [3567,3583]
name: token_credential [3567,3583]
===
match
---
name: container_name [11227,11241]
name: container_name [11235,11249]
===
match
---
name: conn [4034,4038]
name: conn [4034,4038]
===
match
---
atom_expr [10375,10388]
atom_expr [10383,10396]
===
match
---
simple_stmt [6448,6470]
simple_stmt [6448,6470]
===
match
---
arglist [15051,15076]
arglist [15059,15084]
===
match
---
funcdef [6475,7637]
funcdef [6475,7637]
===
match
---
operator: , [8350,8351]
operator: , [8350,8351]
===
match
---
operator: , [14213,14214]
operator: , [14221,14222]
===
match
---
suite [2632,4295]
suite [2632,4295]
===
match
---
param [10272,10287]
param [10280,10295]
===
match
---
name: delimiter [7514,7523]
name: delimiter [7514,7523]
===
match
---
name: get_blob_properties [5703,5722]
name: get_blob_properties [5703,5722]
===
match
---
operator: = [2523,2524]
operator: = [2523,2524]
===
match
---
name: str [6563,6566]
name: str [6563,6566]
===
match
---
fstring_string: https:// [4201,4209]
fstring_string: https:// [4201,4209]
===
match
---
name: blob_name [8265,8274]
name: blob_name [8265,8274]
===
match
---
operator: = [2697,2698]
operator: = [2697,2698]
===
match
---
atom_expr [8222,8306]
atom_expr [8222,8306]
===
match
---
name: self [6503,6507]
name: self [6503,6507]
===
match
---
atom_expr [5001,5038]
atom_expr [5001,5038]
===
match
---
trailer [11411,11416]
trailer [11419,11424]
===
match
---
return_stmt [6448,6469]
return_stmt [6448,6469]
===
match
---
import_from [1281,1330]
import_from [1281,1330]
===
match
---
string: """         Delete a container object          :param container_name: The name of the container         :type container_name: str         """ [12966,13107]
string: """         Delete a container object          :param container_name: The name of the container         :type container_name: str         """ [12974,13115]
===
match
---
operator: , [14156,14157]
operator: , [14164,14165]
===
match
---
trailer [3771,3784]
trailer [3771,3784]
===
match
---
name: _get_container_client [13218,13239]
name: _get_container_client [13226,13247]
===
match
---
operator: -> [2388,2390]
operator: -> [2388,2390]
===
match
---
tfpdef [9758,9772]
tfpdef [9758,9772]
===
match
---
string: 'Attempting to delete container: %s' [13147,13183]
string: 'Attempting to delete container: %s' [13155,13191]
===
match
---
name: write [9688,9693]
name: write [9688,9693]
===
match
---
operator: ** [4273,4275]
operator: ** [4273,4275]
===
match
---
simple_stmt [14051,14093]
simple_stmt [14059,14101]
===
match
---
name: get_blobs_list [14959,14973]
name: get_blobs_list [14967,14981]
===
match
---
name: upload_blob [11281,11292]
name: upload_blob [11289,11300]
===
match
---
suite [13523,14093]
suite [13531,14101]
===
match
---
fstring_end: ' [15299,15300]
fstring_end: ' [15307,15308]
===
match
---
atom_expr [7601,7610]
atom_expr [7601,7610]
===
match
---
trailer [12127,12141]
trailer [12135,12149]
===
match
---
with_stmt [9530,9712]
with_stmt [9530,9712]
===
match
---
trailer [5086,5097]
trailer [5086,5097]
===
match
---
operator: = [15107,15108]
operator: = [15115,15116]
===
match
---
fstring_expr [15288,15299]
fstring_expr [15296,15307]
===
match
---
name: AirflowException [1466,1482]
name: AirflowException [1466,1482]
===
match
---
name: str [6607,6610]
name: str [6607,6610]
===
match
---
trailer [6648,6653]
trailer [6648,6653]
===
match
---
simple_stmt [12660,12715]
simple_stmt [12668,12723]
===
match
---
name: azure [1336,1341]
name: azure [1336,1341]
===
match
---
simple_stmt [1331,1434]
simple_stmt [1331,1434]
===
match
---
simple_stmt [11262,11335]
simple_stmt [11270,11343]
===
match
---
name: length [11425,11431]
name: length [11433,11439]
===
match
---
name: container_client [12734,12750]
name: container_client [12742,12758]
===
match
---
operator: = [6568,6569]
operator: = [6568,6569]
===
match
---
atom_expr [3420,3442]
atom_expr [3420,3442]
===
match
---
operator: = [7488,7489]
operator: = [7488,7489]
===
match
---
atom_expr [13213,13274]
atom_expr [13221,13282]
===
match
---
name: str [8384,8387]
name: str [8384,8387]
===
match
---
except_clause [13350,13378]
except_clause [13358,13386]
===
match
---
import_as_names [1238,1280]
import_as_names [1238,1280]
===
match
---
operator: = [8290,8291]
operator: = [8290,8291]
===
match
---
name: container_name [13185,13199]
name: container_name [13193,13207]
===
match
---
param [6669,6678]
param [6669,6678]
===
match
---
simple_stmt [13392,13448]
simple_stmt [13400,13456]
===
match
---
operator: , [1257,1258]
operator: , [1257,1258]
===
match
---
return_stmt [12727,12750]
return_stmt [12735,12758]
===
match
---
name: string_data [8334,8345]
name: string_data [8334,8345]
===
match
---
not_test [3939,3972]
not_test [3939,3972]
===
match
---
parameters [2558,2564]
parameters [2558,2564]
===
match
---
tfpdef [6517,6536]
tfpdef [6517,6536]
===
match
---
name: blob_name [15067,15076]
name: blob_name [15075,15084]
===
match
---
operator: , [12212,12213]
operator: , [12220,12221]
===
match
---
param [14166,14181]
param [14174,14189]
===
match
---
operator: = [12050,12051]
operator: = [12058,12059]
===
match
---
name: ContainerClient [1393,1408]
name: ContainerClient [1393,1408]
===
match
---
trailer [7600,7611]
trailer [7600,7611]
===
match
---
name: check_for_blob [5107,5121]
name: check_for_blob [5107,5121]
===
match
---
atom_expr [3672,3741]
atom_expr [3672,3741]
===
match
---
operator: , [7533,7534]
operator: , [7533,7534]
===
match
---
name: extra_dejson [2754,2766]
name: extra_dejson [2754,2766]
===
match
---
trailer [8943,8993]
trailer [8943,8993]
===
match
---
name: blobs [13498,13503]
name: blobs [13506,13511]
===
match
---
with_item [9535,9568]
with_item [9535,9568]
===
match
---
name: sas_token [3943,3952]
name: sas_token [3943,3952]
===
match
---
operator: , [10413,10414]
operator: , [10421,10422]
===
match
---
atom_expr [3810,3839]
atom_expr [3810,3839]
===
match
---
trailer [12664,12668]
trailer [12672,12676]
===
match
---
tfpdef [4683,4697]
tfpdef [4683,4697]
===
match
---
trailer [7395,7411]
trailer [7395,7411]
===
match
---
name: BlobServiceClient [3993,4010]
name: BlobServiceClient [3993,4010]
===
match
---
operator: , [9069,9070]
operator: , [9069,9070]
===
match
---
param [8328,8333]
param [8328,8333]
===
match
---
simple_stmt [13532,13961]
simple_stmt [13540,13969]
===
match
---
operator: = [2340,2341]
operator: = [2340,2341]
===
match
---
name: blob_name [4683,4692]
name: blob_name [4683,4692]
===
match
---
trailer [3877,3913]
trailer [3877,3913]
===
match
---
string: """Return the BlobServiceClient object.""" [2641,2683]
string: """Return the BlobServiceClient object.""" [2641,2683]
===
match
---
or_test [2749,2772]
or_test [2749,2772]
===
match
---
operator: > [6466,6467]
operator: > [6466,6467]
===
match
---
operator: ** [5723,5725]
operator: ** [5723,5725]
===
match
---
classdef [1525,15373]
classdef [1525,15381]
===
match
---
trailer [9700,9708]
trailer [9700,9708]
===
match
---
name: container_name [14974,14988]
name: container_name [14982,14996]
===
match
---
atom_expr [4152,4294]
atom_expr [4152,4294]
===
match
---
tfpdef [7699,7713]
tfpdef [7699,7713]
===
match
---
arglist [15329,15371]
arglist [15337,15379]
===
match
---
operator: = [3760,3761]
operator: = [3760,3761]
===
match
---
trailer [8233,8306]
trailer [8233,8306]
===
match
---
operator: , [5163,5164]
operator: , [5163,5164]
===
match
---
name: Optional [6593,6601]
name: Optional [6593,6601]
===
match
---
simple_stmt [3986,4083]
simple_stmt [3986,4083]
===
match
---
trailer [3429,3442]
trailer [3429,3442]
===
match
---
name: blob_name [12090,12099]
name: blob_name [12098,12107]
===
match
---
suite [10439,11335]
suite [10447,11343]
===
match
---
name: kwargs [5167,5173]
name: kwargs [5167,5173]
===
match
---
name: container_name [12699,12713]
name: container_name [12707,12721]
===
match
---
param [10405,10414]
param [10413,10422]
===
match
---
argument [3713,3740]
argument [3713,3740]
===
match
---
trailer [8183,8200]
trailer [8183,8200]
===
match
---
suite [12254,12896]
suite [12262,12904]
===
match
---
name: blob_client [12038,12049]
name: blob_client [12046,12057]
===
match
---
suite [5183,5816]
suite [5183,5816]
===
match
---
simple_stmt [5654,5733]
simple_stmt [5654,5733]
===
match
---
operator: = [3889,3890]
operator: = [3889,3890]
===
match
---
suite [1550,15373]
suite [1550,15381]
===
match
---
name: str [13492,13495]
name: str [13500,13503]
===
match
---
param [5842,5847]
param [5842,5847]
===
match
---
operator: , [5126,5127]
operator: , [5126,5127]
===
match
---
simple_stmt [4381,4562]
simple_stmt [4381,4562]
===
match
---
simple_stmt [5783,5796]
simple_stmt [5783,5796]
===
match
---
name: blobs [14026,14031]
name: blobs [14034,14039]
===
match
---
argument [4273,4280]
argument [4273,4280]
===
match
---
atom_expr [4577,4629]
atom_expr [4577,4629]
===
match
---
name: wasb_conn_id [2447,2459]
name: wasb_conn_id [2447,2459]
===
match
---
param [13470,13475]
param [13478,13483]
===
match
---
name: create_container [5006,5022]
name: create_container [5006,5022]
===
match
---
name: conn [4258,4262]
name: conn [4258,4262]
===
match
---
argument [4187,4245]
argument [4187,4245]
===
match
---
param [11362,11367]
param [11370,11375]
===
match
---
name: ResourceNotFoundError [5748,5769]
name: ResourceNotFoundError [5748,5769]
===
match
---
name: Optional [11403,11411]
name: Optional [11411,11419]
===
match
---
import_as_names [1362,1433]
import_as_names [1362,1433]
===
match
---
name: _get_container_client [4304,4325]
name: _get_container_client [4304,4325]
===
match
---
simple_stmt [2265,2298]
simple_stmt [2265,2298]
===
match
---
name: load_string [8316,8327]
name: load_string [8316,8327]
===
match
---
atom_expr [2525,2540]
atom_expr [2525,2540]
===
match
---
tfpdef [12928,12947]
tfpdef [12936,12955]
===
match
---
string: 'connection_string' [3203,3222]
string: 'connection_string' [3203,3222]
===
match
---
name: kwargs [14266,14272]
name: kwargs [14274,14280]
===
match
---
operator: , [15065,15066]
operator: , [15073,15074]
===
match
---
name: account_url [4187,4198]
name: account_url [4187,4198]
===
match
---
return_stmt [7620,7636]
return_stmt [7620,7636]
===
match
---
name: ContainerClient [12238,12253]
name: ContainerClient [12246,12261]
===
match
---
tfpdef [9018,9032]
tfpdef [9018,9032]
===
match
---
operator: , [9053,9054]
operator: , [9053,9054]
===
match
---
operator: ** [9657,9659]
operator: ** [9657,9659]
===
match
---
string: 'wasb_default' [2223,2237]
string: 'wasb_default' [2223,2237]
===
match
---
name: conn [4210,4214]
name: conn [4210,4214]
===
match
---
name: str [8347,8350]
name: str [8347,8350]
===
match
---
operator: ** [8389,8391]
operator: ** [8389,8391]
===
match
---
param [6629,6660]
param [6629,6660]
===
match
---
atom_expr [3762,3784]
atom_expr [3762,3784]
===
match
---
suite [12519,12751]
suite [12527,12759]
===
match
---
arglist [12674,12713]
arglist [12682,12721]
===
match
---
name: int [11442,11445]
name: int [11450,11453]
===
match
---
tfpdef [2361,2378]
tfpdef [2361,2378]
===
match
---
name: password [4263,4271]
name: password [4263,4271]
===
match
---
name: str [9050,9053]
name: str [9050,9053]
===
match
---
expr_stmt [7357,7411]
expr_stmt [7357,7411]
===
match
---
name: container_name [4614,4628]
name: container_name [4614,4628]
===
match
---
atom_expr [10424,10438]
atom_expr [10432,10446]
===
match
---
name: str [9769,9772]
name: str [9769,9772]
===
match
---
operator: , [4681,4682]
operator: , [4681,4682]
===
match
---
param [14190,14214]
param [14198,14222]
===
match
---
param [5882,5890]
param [5882,5890]
===
match
---
name: str [9066,9069]
name: str [9066,9069]
===
match
---
funcdef [8312,8994]
funcdef [8312,8994]
===
match
---
name: container [7357,7366]
name: container [7357,7366]
===
match
---
name: container_name [15329,15343]
name: container_name [15337,15351]
===
match
---
dotted_name [1440,1458]
dotted_name [1440,1458]
===
match
---
with_item [8179,8208]
with_item [8179,8208]
===
match
---
operator: , [12088,12089]
operator: , [12096,12097]
===
match
---
string: """         Instantiates a container client          :param container_name: The name of the container         :type container_name: str         :return: ContainerClient         """ [4381,4561]
string: """         Instantiates a container client          :param container_name: The name of the container         :type container_name: str         :return: ContainerClient         """ [4381,4561]
===
match
---
arglist [8234,8305]
arglist [8234,8305]
===
match
---
operator: ** [12172,12174]
operator: ** [12180,12182]
===
match
---
arglist [11293,11333]
arglist [11301,11341]
===
match
---
operator: , [13503,13504]
operator: , [13511,13512]
===
match
---
name: read_file [9721,9730]
name: read_file [9721,9730]
===
match
---
name: blob_client [11191,11202]
name: blob_client [11199,11210]
===
match
---
name: container_name [8944,8958]
name: container_name [8944,8958]
===
match
---
simple_stmt [6702,7349]
simple_stmt [6702,7349]
===
match
---
operator: , [9634,9635]
operator: , [9634,9635]
===
match
---
atom_expr [3026,3035]
atom_expr [3026,3035]
===
match
---
param [11384,11394]
param [11392,11402]
===
match
---
trailer [7373,7395]
trailer [7373,7395]
===
match
---
atom_expr [11403,11416]
atom_expr [11411,11424]
===
match
---
name: kwargs [6671,6677]
name: kwargs [6671,6677]
===
match
---
operator: ** [8984,8986]
operator: ** [8984,8986]
===
match
---
name: file_path [8184,8193]
name: file_path [8184,8193]
===
match
---
operator: -> [4699,4701]
operator: -> [4699,4701]
===
match
---
operator: = [11316,11317]
operator: = [11324,11325]
===
match
---
return_stmt [5783,5795]
return_stmt [5783,5795]
===
match
---
trailer [3952,3963]
trailer [3952,3963]
===
match
---
simple_stmt [2468,2499]
simple_stmt [2468,2499]
===
match
---
simple_stmt [12872,12896]
simple_stmt [12880,12904]
===
match
---
name: self [12660,12664]
name: self [12668,12672]
===
match
---
name: info [14060,14064]
name: info [14068,14072]
===
match
---
name: str [2336,2339]
name: str [2336,2339]
===
match
---
atom_expr [3993,4082]
atom_expr [3993,4082]
===
match
---
argument [8265,8284]
argument [8265,8284]
===
match
---
funcdef [2303,2541]
funcdef [2303,2541]
===
match
---
string: """         Instantiates a blob client          :param container_name: The name of the blob container         :type container_name: str         :param blob_name: The name of the blob. This needs not be existing         :type blob_name: str         """ [4722,4973]
string: """         Instantiates a blob client          :param container_name: The name of the blob container         :type container_name: str         :param blob_name: The name of the blob. This needs not be existing         :type blob_name: str         """ [4722,4973]
===
match
---
param [11395,11424]
param [11403,11432]
===
match
---
operator: ** [11455,11457]
operator: ** [11463,11465]
===
match
---
dotted_name [1488,1506]
dotted_name [1488,1506]
===
match
---
name: str [7694,7697]
name: str [7694,7697]
===
match
---
name: get_container_client [4593,4613]
name: get_container_client [4593,4613]
===
match
---
trailer [3198,3202]
trailer [3198,3202]
===
match
---
name: str [6533,6536]
name: str [6533,6536]
===
match
---
simple_stmt [5804,5816]
simple_stmt [5804,5816]
===
match
---
name: startswith [3820,3830]
name: startswith [3820,3830]
===
match
---
name: wasb_conn_id [2322,2334]
name: wasb_conn_id [2322,2334]
===
match
---
name: self [13213,13217]
name: self [13221,13225]
===
match
---
trailer [15035,15050]
trailer [15043,15058]
===
match
---
with_stmt [8174,8307]
with_stmt [8174,8307]
===
match
---
argument [9657,9665]
argument [9657,9665]
===
match
---
name: container_name [10186,10200]
name: container_name [10186,10200]
===
match
---
operator: , [5846,5847]
operator: , [5846,5847]
===
match
---
trailer [13973,13995]
trailer [13981,14003]
===
match
---
import_as_names [1177,1202]
import_as_names [1177,1202]
===
match
---
name: from_connection_string [3170,3192]
name: from_connection_string [3170,3192]
===
match
---
name: container_name [5128,5142]
name: container_name [5128,5142]
===
match
---
trailer [3245,3266]
trailer [3245,3266]
===
match
---
name: self [12799,12803]
name: self [12807,12811]
===
match
---
param [2559,2563]
param [2559,2563]
===
match
---
name: ClientSecretCredential [1308,1330]
name: ClientSecretCredential [1308,1330]
===
match
---
name: exceptions [1448,1458]
name: exceptions [1448,1458]
===
match
---
trailer [3058,3079]
trailer [3058,3079]
===
match
---
simple_stmt [7420,7435]
simple_stmt [7420,7435]
===
match
---
and_test [15179,15230]
and_test [15187,15238]
===
match
---
name: ResourceExistsError [12766,12785]
name: ResourceExistsError [12774,12793]
===
match
---
argument [9636,9655]
argument [9636,9655]
===
match
---
atom_expr [2468,2484]
atom_expr [2468,2484]
===
match
---
trailer [4592,4613]
trailer [4592,4613]
===
match
---
simple_stmt [3528,3555]
simple_stmt [3528,3555]
===
match
---
param [6503,6508]
param [6503,6508]
===
match
---
operator: , [9655,9656]
operator: , [9655,9656]
===
match
---
tfpdef [11395,11416]
tfpdef [11403,11424]
===
match
---
trailer [13400,13405]
trailer [13408,13413]
===
match
---
argument [12142,12155]
argument [12150,12163]
===
match
---
name: str [5160,5163]
name: str [5160,5163]
===
match
---
name: login [3510,3515]
name: login [3510,3515]
===
match
---
suite [9569,9712]
suite [9569,9712]
===
match
---
name: container_name [5848,5862]
name: container_name [5848,5862]
===
match
---
operator: -> [4353,4355]
operator: -> [4353,4355]
===
match
---
fstring_string: .blob.core.windows.net/ [4221,4244]
fstring_string: .blob.core.windows.net/ [4221,4244]
===
match
---
name: extra [3049,3054]
name: extra [3049,3054]
===
match
---
trailer [4038,4044]
trailer [4038,4044]
===
match
---
suite [2396,2541]
suite [2396,2541]
===
match
---
trailer [13146,13200]
trailer [13154,13208]
===
match
---
simple_stmt [1204,1281]
simple_stmt [1204,1281]
===
match
---
name: sas_token [3925,3934]
name: sas_token [3925,3934]
===
match
---
atom_expr [7584,7611]
atom_expr [7584,7611]
===
match
---
operator: ** [13505,13507]
operator: ** [13513,13515]
===
match
---
trailer [14958,14973]
trailer [14966,14981]
===
match
---
trailer [15208,15225]
trailer [15216,15233]
===
match
---
name: self [4577,4581]
name: self [4577,4581]
===
match
---
expr_stmt [2242,2260]
expr_stmt [2242,2260]
===
match
---
operator: , [3711,3712]
operator: , [3711,3712]
===
match
---
operator: , [6574,6575]
operator: , [6574,6575]
===
match
---
arglist [14065,14091]
arglist [14073,14099]
===
match
---
funcdef [10238,11335]
funcdef [10246,11343]
===
match
---
simple_stmt [1158,1203]
simple_stmt [1158,1203]
===
match
---
trailer [12628,12645]
trailer [12636,12653]
===
match
---
operator: = [3354,3355]
operator: = [3354,3355]
===
match
---
name: _get_container_client [12469,12490]
name: _get_container_client [12477,12498]
===
match
---
argument [4011,4081]
argument [4011,4081]
===
match
---
operator: , [11423,11424]
operator: , [11431,11432]
===
match
---
operator: = [10389,10390]
operator: = [10397,10398]
===
match
---
operator: = [3376,3377]
operator: = [3376,3377]
===
match
---
simple_stmt [10165,10233]
simple_stmt [10165,10241]
===
match
---
atom_expr [8932,8993]
atom_expr [8932,8993]
===
match
---
parameters [14113,14279]
parameters [14121,14287]
===
match
---
name: blob_list [7584,7593]
name: blob_list [7584,7593]
===
match
---
trailer [13300,13341]
trailer [13308,13349]
===
match
---
operator: = [8248,8249]
operator: = [8248,8249]
===
match
---
argument [15363,15371]
argument [15371,15379]
===
match
---
trailer [2753,2766]
trailer [2753,2766]
===
match
---
operator: , [12170,12171]
operator: , [12178,12179]
===
match
---
tfpdef [5149,5163]
tfpdef [5149,5163]
===
match
---
trailer [3509,3515]
trailer [3509,3515]
===
match
---
name: file_path [9018,9027]
name: file_path [9018,9027]
===
match
---
name: include [7497,7504]
name: include [7497,7504]
===
match
---
suite [5770,5796]
suite [5770,5796]
===
match
---
name: StorageStreamDownloader [11473,11496]
name: StorageStreamDownloader [11481,11504]
===
match
---
operator: ** [10405,10407]
operator: ** [10413,10415]
===
match
---
operator: , [12697,12698]
operator: , [12705,12706]
===
match
---
trailer [11280,11292]
trailer [11288,11300]
===
match
---
name: azure [1286,1291]
name: azure [1286,1291]
===
match
---
operator: { [4033,4034]
operator: { [4033,4034]
===
match
---
name: self [10258,10262]
name: self [10266,10270]
===
match
---
name: length [11317,11323]
name: length [11325,11331]
===
match
---
name: stream [9694,9700]
name: stream [9694,9700]
===
match
---
name: container_name [6384,6398]
name: container_name [6384,6398]
===
match
---
comparison [6455,6469]
comparison [6455,6469]
===
match
---
atom_expr [6640,6653]
atom_expr [6640,6653]
===
match
---
operator: ** [11325,11327]
operator: ** [11333,11335]
===
match
---
operator: , [1180,1181]
operator: , [1180,1181]
===
match
---
funcdef [4635,5098]
funcdef [4635,5098]
===
match
---
name: super [2405,2410]
name: super [2405,2410]
===
match
---
name: download [9596,9604]
name: download [9596,9604]
===
match
---
operator: , [12582,12583]
operator: , [12590,12591]
===
match
---
name: container_name [5023,5037]
name: container_name [5023,5037]
===
match
---
name: kwargs [10407,10413]
name: kwargs [10415,10421]
===
match
---
name: extra [4275,4280]
name: extra [4275,4280]
===
match
---
trailer [2436,2444]
trailer [2436,2444]
===
match
---
operator: , [10432,10433]
operator: , [10440,10441]
===
match
---
trailer [9595,9604]
trailer [9595,9604]
===
match
---
comparison [15205,15230]
comparison [15213,15238]
===
match
---
name: self [12532,12536]
name: self [12540,12544]
===
match
---
string: """         Creates a new blob from a data source with automatic chunking.          :param container_name: The name of the container to upload data         :type container_name: str         :param blob_name: The name of the blob to upload. This need not exist in the container         :type blob_name: str         :param data: The blob data to upload         :param blob_type: The type of the blob. This can be either ``BlockBlob``,             ``PageBlob`` or ``AppendBlob``. The default value is ``BlockBlob``.         :type blob_type: storage.BlobType         :param length: Number of bytes to read from the stream. This is optional,             but should be supplied for optimal performance.         :type length: int         """ [10448,11182]
string: """         Creates a new blob from a data source with automatic chunking.          :param container_name: The name of the container to upload data         :type container_name: str         :param blob_name: The name of the blob to upload. This need not exist in the container         :type blob_name: str         :param data: The blob data to upload         :param blob_type: The type of the blob. This can be either ``BlockBlob``,             ``PageBlob`` or ``AppendBlob``. The default value is ``BlockBlob``.         :type blob_type: storage.BlobType         :param length: Number of bytes to read from the stream. This is optional,             but should be supplied for optimal performance.         :type length: int         """ [10456,11190]
===
match
---
argument [3366,3407]
argument [3366,3407]
===
match
---
name: fileblob [9679,9687]
name: fileblob [9679,9687]
===
match
---
atom_expr [3541,3554]
atom_expr [3541,3554]
===
match
---
name: delete_blobs [14012,14024]
name: delete_blobs [14020,14032]
===
match
---
trailer [5702,5722]
trailer [5702,5722]
===
match
---
name: BlobServiceClient [4152,4169]
name: BlobServiceClient [4152,4169]
===
match
---
fstring_end: " [4244,4245]
fstring_end: " [4244,4245]
===
match
---
name: container_client [4982,4998]
name: container_client [4982,4998]
===
match
---
fstring [4023,4069]
fstring [4023,4069]
===
match
---
operator: ** [14264,14266]
operator: ** [14272,14274]
===
match
---
simple_stmt [7620,7637]
simple_stmt [7620,7637]
===
match
---
operator: = [2182,2183]
operator: = [2182,2183]
===
match
---
return_stmt [3318,3408]
return_stmt [3318,3408]
===
match
---
param [7715,7723]
param [7715,7723]
===
match
---
parameters [5121,5174]
parameters [5121,5174]
===
match
---
name: blob_name [5692,5701]
name: blob_name [5692,5701]
===
match
---
name: self [2525,2529]
name: self [2525,2529]
===
match
---
operator: , [8387,8388]
operator: , [8387,8388]
===
match
---
name: delete_file [14102,14113]
name: delete_file [14110,14121]
===
match
---
operator: { [2770,2771]
operator: { [2770,2771]
===
match
---
if_stmt [2782,3037]
if_stmt [2782,3037]
===
match
---
tfpdef [8373,8387]
tfpdef [8373,8387]
===
match
---
trailer [12540,12545]
trailer [12548,12553]
===
match
---
atom_expr [15311,15372]
atom_expr [15319,15380]
===
match
---
name: host [3031,3035]
name: host [3031,3035]
===
match
---
trailer [7605,7610]
trailer [7605,7610]
===
match
---
name: sas_token [3750,3759]
name: sas_token [3750,3759]
===
match
---
trailer [5005,5022]
trailer [5005,5022]
===
match
---
operator: = [3539,3540]
operator: = [3539,3540]
===
match
---
trailer [10230,10232]
trailer [10238,10240]
===
match
---
simple_stmt [12727,12751]
simple_stmt [12735,12759]
===
match
---
name: container_name [15051,15065]
name: container_name [15059,15073]
===
match
---
name: blobs [7443,7448]
name: blobs [7443,7448]
===
match
---
param [8352,8372]
param [8352,8372]
===
match
---
name: self [2432,2436]
name: self [2432,2436]
===
match
---
trailer [6562,6567]
trailer [6562,6567]
===
match
---
argument [14025,14031]
argument [14033,14039]
===
match
---
operator: , [4330,4331]
operator: , [4330,4331]
===
match
---
trailer [10185,10222]
trailer [10185,10222]
===
match
---
parameters [4655,4698]
parameters [4655,4698]
===
match
---
funcdef [12187,12896]
funcdef [12195,12904]
===
match
---
operator: , [11241,11242]
operator: , [11249,11250]
===
match
---
trailer [3689,3741]
trailer [3689,3741]
===
match
---
simple_stmt [2432,2460]
simple_stmt [2432,2460]
===
match
---
param [5128,5148]
param [5128,5148]
===
match
---
param [14137,14157]
param [14145,14165]
===
match
---
arglist [12813,12858]
arglist [12821,12866]
===
match
---
name: str [14177,14180]
name: str [14185,14188]
===
match
---
operator: , [14272,14273]
operator: , [14280,14281]
===
match
---
dotted_name [1286,1300]
dotted_name [1286,1300]
===
match
---
name: get_file [9003,9011]
name: get_file [9003,9011]
===
match
---
simple_stmt [2167,2199]
simple_stmt [2167,2199]
===
match
---
atom_expr [14954,15017]
atom_expr [14962,15025]
===
match
---
trailer [3169,3192]
trailer [3169,3192]
===
match
---
parameters [11352,11469]
parameters [11360,11477]
===
match
---
name: self [2507,2511]
name: self [2507,2511]
===
match
---
return_stmt [12872,12895]
return_stmt [12880,12903]
===
match
---
name: self [11205,11209]
name: self [11213,11217]
===
match
---
string: 'sas_token' [3772,3783]
string: 'sas_token' [3772,3783]
===
match
---
operator: , [10357,10358]
operator: , [10365,10366]
===
match
---
operator: = [7430,7431]
operator: = [7430,7431]
===
match
---
name: self [9731,9735]
name: self [9731,9735]
===
match
---
suite [9784,10233]
suite [9784,10241]
===
match
---
trailer [2511,2522]
trailer [2511,2522]
===
match
---
name: blob_name [9646,9655]
name: blob_name [9646,9655]
===
match
---
operator: ** [7715,7717]
operator: ** [7715,7717]
===
match
---
name: default_conn_name [2342,2359]
name: default_conn_name [2342,2359]
===
match
---
name: container_name [11368,11382]
name: container_name [11376,11390]
===
match
---
name: account_url [4011,4022]
name: account_url [4011,4022]
===
match
---
trailer [11441,11446]
trailer [11449,11454]
===
match
---
name: get_conn [2530,2538]
name: get_conn [2530,2538]
===
match
---
argument [14033,14041]
argument [14041,14049]
===
match
---
name: blob_name [14997,15006]
name: blob_name [15005,15014]
===
match
---
name: data [8204,8208]
name: data [8204,8208]
===
match
---
operator: = [11417,11418]
operator: = [11425,11426]
===
match
---
atom_expr [13133,13200]
atom_expr [13141,13208]
===
match
---
atom_expr [2996,3036]
atom_expr [2996,3036]
===
match
---
string: """         Check if a prefix exists on Azure Blob storage.          :param container_name: Name of the container.         :type container_name: str         :param prefix: Prefix of the blob.         :type prefix: str         :param kwargs: Optional keyword arguments that ``ContainerClient.walk_blobs`` takes         :type kwargs: object         :return: True if blobs matching the prefix exist, False otherwise.         :rtype: bool         """ [5901,6347]
string: """         Check if a prefix exists on Azure Blob storage.          :param container_name: Name of the container.         :type container_name: str         :param prefix: Prefix of the blob.         :type prefix: str         :param kwargs: Optional keyword arguments that ``ContainerClient.walk_blobs`` takes         :type kwargs: object         :return: True if blobs matching the prefix exist, False otherwise.         :rtype: bool         """ [5901,6347]
===
match
---
operator: = [3723,3724]
operator: = [3723,3724]
===
match
---
name: name_starts_with [7472,7488]
name: name_starts_with [7472,7488]
===
match
---
operator: , [4271,4272]
operator: , [4271,4272]
===
match
---
operator: ** [14033,14035]
operator: ** [14041,14043]
===
match
---
tfpdef [14190,14205]
tfpdef [14198,14213]
===
match
---
operator: = [15163,15164]
operator: = [15171,15172]
===
match
---
operator: , [13495,13496]
operator: , [13503,13504]
===
match
---
name: app_secret [3641,3651]
name: app_secret [3641,3651]
===
match
---
name: blob_name [10296,10305]
name: blob_name [10304,10313]
===
match
---
operator: , [8982,8983]
operator: , [8982,8983]
===
match
---
name: container_name [6399,6413]
name: container_name [6399,6413]
===
match
---
operator: , [7660,7661]
operator: , [7660,7661]
===
match
---
operator: = [4198,4199]
operator: = [4198,4199]
===
match
---
param [7656,7661]
param [7656,7661]
===
match
---
param [11368,11383]
param [11376,11391]
===
match
---
trailer [12812,12859]
trailer [12820,12867]
===
match
---
operator: = [3503,3504]
operator: = [3503,3504]
===
match
---
name: str [12230,12233]
name: str [12238,12241]
===
match
---
name: StorageStreamDownloader [1410,1433]
name: StorageStreamDownloader [1410,1433]
===
match
---
trailer [6368,6383]
trailer [6368,6383]
===
match
---
trailer [2538,2540]
trailer [2538,2540]
===
match
---
name: _get_container_client [13974,13995]
name: _get_container_client [13982,14003]
===
match
---
expr_stmt [12038,12100]
expr_stmt [12046,12108]
===
match
---
name: blob [7601,7605]
name: blob [7601,7605]
===
match
---
name: default_conn_name [2203,2220]
name: default_conn_name [2203,2220]
===
match
---
tfpdef [11425,11446]
tfpdef [11433,11454]
===
match
---
param [7662,7677]
param [7662,7677]
===
match
---
trailer [15050,15077]
trailer [15058,15085]
===
match
---
name: kwargs [9776,9782]
name: kwargs [9776,9782]
===
match
---
tfpdef [14137,14156]
tfpdef [14145,14164]
===
match
---
string: 'shared_access_key' [3387,3406]
string: 'shared_access_key' [3387,3406]
===
match
---
param [10296,10306]
param [10304,10314]
===
match
---
trailer [10222,10230]
trailer [10222,10238]
===
match
---
string: "Created container: %s" [12674,12697]
string: "Created container: %s" [12682,12705]
===
match
---
name: typing [1163,1169]
name: typing [1163,1169]
===
match
---
trailer [6383,6439]
trailer [6383,6439]
===
match
---
param [10258,10263]
param [10266,10271]
===
match
---
atom_expr [15031,15077]
atom_expr [15039,15085]
===
match
---
operator: = [2485,2486]
operator: = [2485,2486]
===
match
---
name: self [14954,14958]
name: self [14962,14966]
===
match
---
name: kwargs [11457,11463]
name: kwargs [11465,11471]
===
match
---
tfpdef [7678,7697]
tfpdef [7678,7697]
===
match
---
name: readall [10223,10230]
name: content_as_text [10223,10238]
===
match
---
tfpdef [4332,4351]
tfpdef [4332,4351]
===
match
---
suite [11497,12182]
suite [11505,12190]
===
match
---
name: exceptions [1220,1230]
name: exceptions [1220,1230]
===
match
---
atom_expr [3890,3912]
atom_expr [3890,3912]
===
match
---
name: prefix [6546,6552]
name: prefix [6546,6552]
===
match
---
string: 'BlockBlob' [10346,10357]
string: 'BlockBlob' [10354,10365]
===
match
---
name: info [13401,13405]
name: info [13409,13413]
===
match
---
operator: , [10319,10320]
operator: , [10327,10328]
===
match
---
atom [15165,15167]
atom [15173,15175]
===
match
---
simple_stmt [13287,13342]
simple_stmt [13295,13350]
===
match
---
argument [6430,6438]
argument [6430,6438]
===
match
---
parameters [9011,9080]
parameters [9011,9080]
===
match
---
operator: -> [12949,12951]
operator: -> [12957,12959]
===
match
---
trailer [13137,13141]
trailer [13145,13149]
===
match
---
atom_expr [13392,13447]
atom_expr [13400,13455]
===
match
---
atom_expr [15205,15225]
atom_expr [15213,15233]
===
match
---
name: blob_name [5087,5096]
name: blob_name [5087,5096]
===
match
---
operator: = [10344,10345]
operator: = [10352,10353]
===
match
---
atom_expr [3236,3266]
atom_expr [3236,3266]
===
match
---
name: upload [10242,10248]
name: upload [10250,10256]
===
match
---
expr_stmt [2203,2237]
expr_stmt [2203,2237]
===
match
---
simple_stmt [15311,15373]
simple_stmt [15319,15381]
===
match
---
name: host [3707,3711]
name: host [3707,3711]
===
match
---
atom_expr [12116,12181]
atom_expr [12124,12189]
===
match
---
raise_stmt [15244,15301]
raise_stmt [15252,15309]
===
match
---
operator: , [5147,5148]
operator: , [5147,5148]
===
match
---
name: container_name [8249,8263]
name: container_name [8249,8263]
===
insert-tree
---
simple_stmt [789,1157]
    string: """ This module contains integration with Azure Blob Storage.  It communicate via the Window Azure Storage Blob protocol. Make sure that a Airflow connection of type `wasb` exists. Authorization can be done by supplying a login (=Storage account name) and password (=KEY), or login and SAS token in the extra field (see connection `wasb_default` for an example).  """ [789,1156]
to
file_input [789,15373]
at 0
===
insert-node
---
name: WasbHook [1531,1539]
to
classdef [1525,15373]
at 0
===
insert-node
---
name: BaseHook [1540,1548]
to
classdef [1525,15373]
at 1
===
insert-tree
---
simple_stmt [1555,2162]
    string: """     Interacts with Azure Blob Storage through the ``wasb://`` protocol.      These parameters have to be passed in Airflow Data Base: account_name and account_key.      Additional options passed in the 'extra' field of the connection will be     passed to the `BlockBlockService()` constructor. For example, authenticate     using a SAS token by adding {"sas_token": "YOUR_TOKEN"}.      :param wasb_conn_id: Reference to the wasb connection.     :type wasb_conn_id: str     :param public_read: Whether an anonymous public read access should be used. default is False     :type public_read: bool     """ [1555,2161]
to
suite [1550,15373]
at 0
===
update-node
---
name: readall [10223,10230]
replace readall by content_as_text
===
delete-tree
---
simple_stmt [789,1157]
    string: """ This module contains integration with Azure Blob Storage.  It communicate via the Window Azure Storage Blob protocol. Make sure that a Airflow connection of type `wasb` exists. Authorization can be done by supplying a login (=Storage account name) and password (=KEY), or login and SAS token in the extra field (see connection `wasb_default` for an example).  """ [789,1156]
===
delete-node
---
name: WasbHook [1531,1539]
===
===
delete-node
---
name: BaseHook [1540,1548]
===
===
delete-tree
---
simple_stmt [1555,2162]
    string: """     Interacts with Azure Blob Storage through the ``wasb://`` protocol.      These parameters have to be passed in Airflow Data Base: account_name and account_key.      Additional options passed in the 'extra' field of the connection will be     passed to the `BlockBlockService()` constructor. For example, authenticate     using a SAS token by adding {"sas_token": "YOUR_TOKEN"}.      :param wasb_conn_id: Reference to the wasb connection.     :type wasb_conn_id: str     :param public_read: Whether an anonymous public read access should be used. default is False     :type public_read: bool     """ [1555,2161]
