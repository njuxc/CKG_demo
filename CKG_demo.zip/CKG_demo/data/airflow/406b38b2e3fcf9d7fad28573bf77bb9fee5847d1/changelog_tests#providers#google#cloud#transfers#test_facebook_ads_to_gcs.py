===
match
---
name: unittest [790,798]
name: unittest [790,798]
===
match
---
param [1756,1761]
param [1735,1740]
===
match
---
name: object_name [2056,2067]
name: object_name [2035,2046]
===
match
---
atom [1171,1260]
atom [1150,1239]
===
match
---
expr_stmt [1162,1260]
expr_stmt [1141,1239]
===
match
---
simple_stmt [2358,2486]
simple_stmt [2330,2458]
===
match
---
string: "ad_id" [1217,1224]
string: "ad_id" [1196,1203]
===
match
---
operator: = [2449,2450]
operator: = [2421,2422]
===
match
---
string: "google_cloud_default" [1014,1036]
string: "google_cloud_default" [1014,1036]
===
match
---
name: assert_called_once_with [2262,2285]
name: assert_called_once_with [2241,2264]
===
match
---
name: bucket_name [2712,2723]
name: bucket_name [2684,2695]
===
match
---
dotted_name [1547,1557]
dotted_name [1526,1536]
===
match
---
name: GCS_OBJ_PATH [2068,2080]
name: GCS_OBJ_PATH [2047,2059]
===
match
---
operator: = [2556,2557]
operator: = [2528,2529]
===
match
---
string: "abcd" [1375,1381]
string: "abcd" [1354,1360]
===
match
---
name: assert_called_once_with [2675,2698]
name: assert_called_once_with [2647,2670]
===
match
---
expr_stmt [950,999]
expr_stmt [950,999]
===
match
---
operator: = [1057,1058]
operator: = [1057,1058]
===
match
---
name: bulk_facebook_report [2385,2405]
name: bulk_facebook_report [2357,2377]
===
match
---
name: GCS_BUCKET [2724,2734]
name: GCS_BUCKET [2696,2706]
===
match
---
import_from [785,810]
import_from [785,810]
===
match
---
name: api_version [2325,2336]
name: api_version [2304,2315]
===
match
---
simple_stmt [1318,1498]
simple_stmt [1297,1477]
===
match
---
trailer [2698,2801]
trailer [2670,2773]
===
match
---
name: providers [825,834]
name: providers [825,834]
===
match
---
expr_stmt [1037,1098]
expr_stmt [1037,1098]
===
match
---
expr_stmt [1801,1885]
expr_stmt [1780,1864]
===
match
---
operator: , [1224,1225]
operator: , [1203,1204]
===
match
---
expr_stmt [1261,1317]
expr_stmt [1240,1296]
===
match
---
argument [2443,2460]
argument [2415,2432]
===
match
---
trailer [2405,2429]
trailer [2377,2401]
===
match
---
name: op [2225,2227]
name: op [2204,2206]
===
match
---
operator: , [2568,2569]
operator: , [2540,2541]
===
match
---
arglist [2712,2791]
arglist [2684,2763]
===
match
---
simple_stmt [785,811]
simple_stmt [785,811]
===
match
---
string: "campaign_name" [1177,1192]
string: "campaign_name" [1156,1171]
===
match
---
argument [2545,2568]
argument [2517,2540]
===
match
---
atom_expr [2641,2801]
atom_expr [2613,2773]
===
match
---
string: "airflow_bucket_fb" [930,949]
string: "airflow_bucket_fb" [930,949]
===
match
---
operator: , [2080,2081]
operator: , [2059,2060]
===
match
---
name: FacebookAdsReportToGcsOperator [1899,1929]
name: FacebookAdsReportToGcsOperator [1878,1908]
===
match
---
name: FIELDS [2469,2475]
name: FIELDS [2441,2447]
===
match
---
operator: , [1288,1289]
operator: , [1267,1268]
===
match
---
operator: = [2770,2771]
operator: = [2742,2743]
===
match
---
argument [2166,2205]
argument [2145,2184]
===
match
---
simple_stmt [917,950]
simple_stmt [917,950]
===
match
---
operator: , [1192,1193]
operator: , [1171,1172]
===
match
---
name: fields [1994,2000]
name: fields [1973,1979]
===
match
---
atom [1348,1495]
atom [1327,1474]
===
match
---
argument [2762,2779]
argument [2734,2751]
===
match
---
simple_stmt [812,916]
simple_stmt [812,916]
===
match
---
operator: , [2323,2324]
operator: , [2302,2303]
===
match
---
operator: } [1494,1495]
operator: } [1473,1474]
===
match
---
param [1777,1790]
param [1756,1769]
===
match
---
operator: , [2460,2461]
operator: , [2432,2433]
===
match
---
atom [2236,2238]
atom [2215,2217]
===
match
---
trailer [2227,2235]
trailer [2206,2214]
===
match
---
name: patch [1657,1662]
name: patch [1636,1641]
===
match
---
atom [1342,1497]
atom [1321,1476]
===
match
---
name: PARAMETERS [2032,2042]
name: PARAMETERS [2011,2021]
===
match
---
argument [2781,2791]
argument [2753,2763]
===
match
---
operator: = [1897,1898]
operator: = [1876,1877]
===
match
---
string: "level" [1275,1282]
string: "level" [1254,1261]
===
match
---
name: mock_gcs_hook [2641,2654]
name: mock_gcs_hook [2613,2626]
===
match
---
name: bulk_facebook_report [1828,1848]
name: bulk_facebook_report [1807,1827]
===
match
---
name: FIELDS [2001,2007]
name: FIELDS [1980,1986]
===
match
---
name: task_id [2130,2137]
name: task_id [2109,2116]
===
match
---
trailer [2285,2349]
trailer [2264,2321]
===
match
---
operator: , [1257,1258]
operator: , [1236,1237]
===
match
---
arglist [2443,2475]
arglist [2415,2447]
===
match
---
argument [2712,2734]
argument [2684,2706]
===
match
---
argument [2582,2621]
argument [2554,2593]
===
match
---
operator: @ [1546,1547]
operator: @ [1525,1526]
===
match
---
operator: @ [1651,1652]
operator: @ [1630,1631]
===
match
---
name: PARAMETERS [1261,1271]
name: PARAMETERS [1240,1250]
===
match
---
atom_expr [2494,2632]
atom_expr [2466,2604]
===
match
---
name: GCS_BUCKET [917,927]
name: GCS_BUCKET [917,927]
===
match
---
expr_stmt [917,949]
expr_stmt [917,949]
===
match
---
name: TestFacebookAdsReportToGcsOperator [1506,1540]
name: TestFacebookAdsReportToGcsOperator [1485,1519]
===
match
---
name: op [1894,1896]
name: op [1873,1875]
===
match
---
argument [2286,2323]
argument [2265,2302]
===
match
---
operator: , [2734,2735]
operator: , [2706,2707]
===
match
---
name: PARAMETERS [2450,2460]
name: PARAMETERS [2422,2432]
===
match
---
operator: , [1775,1776]
operator: , [1754,1755]
===
match
---
operator: , [1437,1438]
operator: , [1416,1417]
===
match
---
name: FIELDS [1162,1168]
name: FIELDS [1141,1147]
===
match
---
simple_stmt [1162,1261]
simple_stmt [1141,1240]
===
match
---
atom_expr [2248,2349]
atom_expr [2227,2321]
===
match
---
dotted_name [817,877]
dotted_name [817,877]
===
match
---
operator: { [1274,1275]
operator: { [1253,1254]
===
match
---
name: facebook_conn_id [1943,1959]
name: facebook_conn_id [1922,1938]
===
match
---
argument [2056,2080]
argument [2035,2059]
===
match
---
operator: , [2779,2780]
operator: , [2751,2752]
===
match
---
name: GCS_OBJ_PATH [950,962]
name: GCS_OBJ_PATH [950,962]
===
match
---
name: mock_ads_hook [1801,1814]
name: mock_ads_hook [1780,1793]
===
match
---
name: mock [1652,1656]
name: mock [1631,1635]
===
match
---
string: "campaign_name" [1358,1373]
string: "campaign_name" [1337,1352]
===
match
---
operator: , [1381,1382]
operator: , [1360,1361]
===
match
---
simple_stmt [950,1000]
simple_stmt [950,1000]
===
match
---
string: "impressions" [1244,1257]
string: "impressions" [1223,1236]
===
match
---
operator: , [1412,1413]
operator: , [1391,1392]
===
match
---
operator: , [1488,1489]
operator: , [1467,1468]
===
match
---
dictorsetmaker [1358,1489]
dictorsetmaker [1337,1468]
===
match
---
string: "date_preset" [1290,1303]
string: "date_preset" [1269,1282]
===
match
---
expr_stmt [1894,2216]
expr_stmt [1873,2195]
===
match
---
name: GCS_OBJ_PATH [2748,2760]
name: GCS_OBJ_PATH [2720,2732]
===
match
---
argument [1994,2007]
argument [1973,1986]
===
match
---
string: "Temp/this_is_my_report_json.json" [965,999]
string: "Temp/this_is_my_report_json.json" [965,999]
===
match
---
string: "airflow.providers.google.cloud.transfers.facebook_ads_to_gcs.GCSHook" [1663,1733]
string: "airflow.providers.google.cloud.transfers.facebook_ads_to_gcs.GCSHook" [1642,1712]
===
match
---
operator: = [2000,2001]
operator: = [1979,1980]
===
match
---
name: cloud [842,847]
name: cloud [842,847]
===
match
---
name: FACEBOOK_ADS_CONN_ID [2303,2323]
name: FACEBOOK_ADS_CONN_ID [2282,2302]
===
match
---
name: impersonation_chain [2166,2185]
name: impersonation_chain [2145,2164]
===
match
---
simple_stmt [2248,2350]
simple_stmt [2227,2322]
===
match
---
simple_stmt [1000,1037]
simple_stmt [1000,1037]
===
match
---
name: test_execute [1743,1755]
name: test_execute [1722,1734]
===
match
---
atom_expr [1801,1861]
atom_expr [1780,1840]
===
match
---
string: "abcd" [1406,1412]
string: "abcd" [1385,1391]
===
match
---
string: "ad" [1284,1288]
string: "ad" [1263,1267]
===
match
---
operator: = [2601,2602]
operator: = [2573,2574]
===
match
---
name: mock_ads_hook [1777,1790]
name: mock_ads_hook [1756,1769]
===
match
---
operator: = [2105,2106]
operator: = [2084,2085]
===
match
---
operator: = [963,964]
operator: = [963,964]
===
match
---
string: "ACCOUNT_1" [1060,1071]
string: "ACCOUNT_1" [1060,1071]
===
match
---
expr_stmt [1318,1497]
expr_stmt [1297,1476]
===
match
---
operator: , [1760,1761]
operator: , [1739,1740]
===
match
---
name: transfers [848,857]
name: transfers [848,857]
===
match
---
param [1762,1776]
param [1741,1755]
===
match
---
name: gcp_conn_id [2545,2556]
name: gcp_conn_id [2517,2528]
===
match
---
name: assert_called_once_with [2508,2531]
name: assert_called_once_with [2480,2503]
===
match
---
suite [1541,2802]
suite [1520,2774]
===
match
---
trailer [2667,2674]
trailer [2639,2646]
===
match
---
operator: = [2067,2068]
operator: = [2046,2047]
===
match
---
argument [2325,2348]
argument [2304,2320]
===
match
---
arglist [2545,2622]
arglist [2517,2594]
===
match
---
trailer [2429,2485]
trailer [2401,2457]
===
match
---
trailer [2674,2698]
trailer [2646,2670]
===
match
---
operator: = [2723,2724]
operator: = [2695,2696]
===
match
---
string: "ACCOUNT_3" [1086,1097]
string: "ACCOUNT_3" [1086,1097]
===
match
---
operator: { [2236,2237]
operator: { [2215,2216]
===
match
---
name: object_name [2736,2747]
name: object_name [2708,2719]
===
match
---
simple_stmt [2641,2802]
simple_stmt [2613,2774]
===
match
---
trailer [1848,1861]
trailer [1827,1840]
===
match
---
string: "campaign_id" [1198,1211]
string: "campaign_id" [1177,1190]
===
match
---
simple_stmt [1099,1141]
simple_stmt [1099,1141]
===
match
---
atom_expr [2225,2239]
atom_expr [2204,2218]
===
match
---
name: impersonation_chain [2582,2601]
name: impersonation_chain [2554,2573]
===
match
---
operator: = [2747,2748]
operator: = [2719,2720]
===
match
---
operator: , [2007,2008]
operator: , [1986,1987]
===
match
---
argument [2021,2042]
argument [2000,2021]
===
match
---
name: return_value [1849,1861]
name: return_value [1828,1840]
===
match
---
arglist [2286,2348]
arglist [2265,2320]
===
match
---
string: "facebook_default" [1122,1140]
string: "facebook_default" [1122,1140]
===
match
---
argument [2094,2116]
argument [2073,2095]
===
match
---
argument [2736,2760]
argument [2708,2732]
===
match
---
operator: , [2152,2153]
operator: , [2131,2132]
===
match
---
trailer [2235,2239]
trailer [2214,2218]
===
match
---
trailer [2261,2285]
trailer [2240,2264]
===
match
---
trailer [2654,2667]
trailer [2626,2639]
===
match
---
import_from [812,915]
import_from [812,915]
===
match
---
name: IMPERSONATION_CHAIN [2602,2621]
name: IMPERSONATION_CHAIN [2574,2593]
===
match
---
operator: , [2760,2761]
operator: , [2732,2733]
===
match
---
operator: , [2205,2206]
operator: , [2184,2185]
===
match
---
name: mock_gcs_hook [1762,1775]
name: mock_gcs_hook [1741,1754]
===
match
---
testlist_comp [1177,1258]
testlist_comp [1156,1237]
===
match
---
operator: = [928,929]
operator: = [928,929]
===
match
---
expr_stmt [1099,1140]
expr_stmt [1099,1140]
===
match
---
name: GCS_BUCKET [2106,2116]
name: GCS_BUCKET [2085,2095]
===
match
---
decorator [1546,1647]
decorator [1525,1626]
===
match
---
name: mock [806,810]
name: mock [806,810]
===
match
---
atom_expr [2358,2485]
atom_expr [2330,2457]
===
match
---
decorated [1546,2802]
decorated [1525,2774]
===
match
---
string: "clicks" [1230,1238]
string: "clicks" [1209,1217]
===
match
---
operator: = [1120,1121]
operator: = [1120,1121]
===
match
---
trailer [1827,1848]
trailer [1806,1827]
===
match
---
string: "run_operator" [2138,2152]
string: "run_operator" [2117,2131]
===
match
---
simple_stmt [1801,1886]
simple_stmt [1780,1865]
===
match
---
expr_stmt [1000,1036]
expr_stmt [1000,1036]
===
match
---
string: "ACCOUNT_2" [1073,1084]
string: "ACCOUNT_2" [1073,1084]
===
match
---
operator: } [2237,2238]
operator: } [2216,2217]
===
match
---
name: mock_ads_hook [2248,2261]
name: mock_ads_hook [2227,2240]
===
match
---
string: "impressions" [1470,1483]
string: "impressions" [1449,1462]
===
match
---
name: facebook_conn_id [2286,2302]
name: facebook_conn_id [2265,2281]
===
match
---
funcdef [1739,2802]
funcdef [1718,2774]
===
match
---
string: "abcd" [1431,1437]
string: "abcd" [1410,1416]
===
match
---
name: airflow [817,824]
name: airflow [817,824]
===
match
---
name: return_value [1815,1827]
name: return_value [1794,1806]
===
match
---
atom_expr [2771,2779]
atom_expr [2743,2751]
===
match
---
trailer [2507,2531]
trailer [2479,2503]
===
match
---
string: "ad_id" [1422,1429]
string: "ad_id" [1401,1408]
===
match
---
simple_stmt [1261,1318]
simple_stmt [1240,1297]
===
match
---
name: return_value [2372,2384]
name: return_value [2344,2356]
===
match
---
simple_stmt [1037,1099]
simple_stmt [1037,1099]
===
match
---
name: FacebookAdsReportToGcsOperator [885,915]
name: FacebookAdsReportToGcsOperator [885,915]
===
match
---
operator: = [1169,1170]
operator: = [1148,1149]
===
match
---
suite [1792,2802]
suite [1771,2774]
===
match
---
name: params [2443,2449]
name: params [2415,2421]
===
match
---
operator: , [2621,2622]
operator: , [2593,2594]
===
match
---
operator: { [1348,1349]
operator: { [1327,1328]
===
match
---
operator: , [1211,1212]
operator: , [1190,1191]
===
match
---
operator: = [1959,1960]
operator: = [1938,1939]
===
match
---
argument [2462,2475]
argument [2434,2447]
===
match
---
name: mock [1547,1551]
name: mock [1526,1530]
===
match
---
name: IMPERSONATION_CHAIN [2186,2205]
name: IMPERSONATION_CHAIN [2165,2184]
===
match
---
trailer [2371,2384]
trailer [2343,2356]
===
match
---
operator: , [1980,1981]
operator: , [1959,1960]
===
match
---
operator: = [1012,1013]
operator: = [1012,1013]
===
match
---
simple_stmt [2225,2240]
simple_stmt [2204,2219]
===
match
---
name: FACEBOOK_RETURN_VALUE [1318,1339]
name: FACEBOOK_RETURN_VALUE [1297,1318]
===
match
---
name: assert_called_once_with [2406,2429]
name: assert_called_once_with [2378,2401]
===
match
---
name: ANY [2776,2779]
name: ANY [2748,2751]
===
match
---
name: parameters [2021,2031]
name: parameters [2000,2010]
===
match
---
simple_stmt [2494,2633]
simple_stmt [2466,2605]
===
match
---
operator: , [1460,1461]
operator: , [1439,1440]
===
match
---
operator: = [2137,2138]
operator: = [2116,2117]
===
match
---
name: IMPERSONATION_CHAIN [1037,1056]
name: IMPERSONATION_CHAIN [1037,1056]
===
match
---
simple_stmt [1894,2217]
simple_stmt [1873,2196]
===
match
---
arglist [1943,2206]
arglist [1922,2185]
===
match
---
string: "airflow.providers.google.cloud.transfers.facebook_ads_to_gcs.FacebookAdsReportingHook" [1558,1645]
string: "airflow.providers.google.cloud.transfers.facebook_ads_to_gcs.FacebookAdsReportingHook" [1537,1624]
===
match
---
atom_expr [1899,2216]
atom_expr [1878,2195]
===
match
---
dictorsetmaker [1275,1316]
dictorsetmaker [1254,1295]
===
match
---
dotted_name [1652,1662]
dotted_name [1631,1641]
===
match
---
name: GCS_CONN_ID [1000,1011]
name: GCS_CONN_ID [1000,1011]
===
match
---
name: GCS_CONN_ID [2557,2568]
name: GCS_CONN_ID [2529,2540]
===
match
---
trailer [2775,2779]
trailer [2747,2751]
===
match
---
operator: = [2031,2032]
operator: = [2010,2011]
===
match
---
operator: = [2302,2303]
operator: = [2281,2282]
===
match
---
name: filename [2762,2770]
name: filename [2734,2742]
===
match
---
string: "clicks" [1447,1455]
string: "clicks" [1426,1434]
===
match
---
string: "2" [1485,1488]
string: "2" [1464,1467]
===
match
---
string: "2" [1457,1460]
string: "2" [1436,1439]
===
match
---
name: fields [2462,2468]
name: fields [2434,2440]
===
match
---
atom [1274,1317]
atom [1253,1296]
===
match
---
argument [2130,2152]
argument [2109,2131]
===
match
---
atom [1059,1098]
atom [1059,1098]
===
match
---
decorators [1546,1735]
decorators [1525,1714]
===
match
---
name: mock_gcs_hook [2494,2507]
name: mock_gcs_hook [2466,2479]
===
match
---
operator: , [2042,2043]
operator: , [2021,2022]
===
match
---
string: "yesterday" [1305,1316]
string: "yesterday" [1284,1295]
===
match
---
operator: , [1238,1239]
operator: , [1217,1218]
===
match
---
name: patch [1552,1557]
name: patch [1531,1536]
===
match
---
operator: , [2116,2117]
operator: , [2095,2096]
===
match
---
name: google [835,841]
name: google [835,841]
===
match
---
parameters [1755,1791]
parameters [1734,1770]
===
match
---
classdef [1500,2802]
classdef [1479,2774]
===
match
---
operator: } [1316,1317]
operator: } [1295,1296]
===
match
---
trailer [1929,2216]
trailer [1908,2195]
===
match
---
name: FACEBOOK_ADS_CONN_ID [1960,1980]
name: FACEBOOK_ADS_CONN_ID [1939,1959]
===
match
---
operator: = [2185,2186]
operator: = [2164,2165]
===
match
---
operator: = [1272,1273]
operator: = [1251,1252]
===
match
---
name: gzip [2781,2785]
name: gzip [2753,2757]
===
match
---
name: facebook_ads_to_gcs [858,877]
name: facebook_ads_to_gcs [858,877]
===
match
---
operator: = [2785,2786]
operator: = [2757,2758]
===
match
---
name: return_value [2655,2667]
name: return_value [2627,2639]
===
match
---
decorator [1651,1735]
decorator [1630,1714]
===
match
---
testlist_comp [1060,1097]
testlist_comp [1060,1097]
===
match
---
trailer [2531,2632]
trailer [2503,2604]
===
match
---
argument [1943,1980]
argument [1922,1959]
===
match
---
operator: = [1340,1341]
operator: = [1319,1320]
===
match
---
file_input [785,2802]
file_input [785,2774]
===
match
---
operator: , [1071,1072]
operator: , [1071,1072]
===
match
---
name: FACEBOOK_ADS_CONN_ID [1099,1119]
name: FACEBOOK_ADS_CONN_ID [1099,1119]
===
match
---
name: execute [2228,2235]
name: execute [2207,2214]
===
match
---
name: FACEBOOK_RETURN_VALUE [1864,1885]
name: FACEBOOK_RETURN_VALUE [1843,1864]
===
match
---
name: bucket_name [2094,2105]
name: bucket_name [2073,2084]
===
match
---
name: self [1756,1760]
name: self [1735,1739]
===
match
---
trailer [1814,1827]
trailer [1793,1806]
===
match
---
operator: , [1084,1085]
operator: , [1084,1085]
===
match
---
string: "campaign_id" [1391,1404]
string: "campaign_id" [1370,1383]
===
match
---
trailer [2384,2405]
trailer [2356,2377]
===
match
---
operator: = [2468,2469]
operator: = [2440,2441]
===
match
---
name: mock [2771,2775]
name: mock [2743,2747]
===
match
---
operator: = [1862,1863]
operator: = [1841,1842]
===
match
---
name: mock_ads_hook [2358,2371]
name: mock_ads_hook [2330,2343]
===
match
---
name: upload [2668,2674]
name: upload [2640,2646]
===
match
---
operator: = [2336,2337]
operator: = [2315,2316]
===
delete-tree
---
simple_stmt [1141,1162]
    expr_stmt [1141,1161]
        name: API_VERSION [1141,1152]
        operator: = [1153,1154]
        string: "v6.0" [1155,1161]
===
delete-node
---
name: API_VERSION [2337,2348]
===
