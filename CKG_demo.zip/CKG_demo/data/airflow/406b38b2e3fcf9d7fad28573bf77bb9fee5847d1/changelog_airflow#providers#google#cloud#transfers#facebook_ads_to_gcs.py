===
match
---
name: context [5354,5361]
name: context [5441,5448]
===
match
---
name: api_version [5483,5494]
name: api_version [5570,5581]
===
match
---
atom_expr [6428,6437]
atom_expr [6515,6524]
===
match
---
simple_stmt [5602,5647]
simple_stmt [5689,5734]
===
match
---
if_stmt [5735,6523]
if_stmt [5822,6610]
===
match
---
trailer [4645,4657]
trailer [4732,4744]
===
match
---
operator: = [4780,4781]
operator: = [4867,4868]
===
match
---
name: str [4134,4137]
name: str [4213,4216]
===
match
---
testlist_comp [5620,5645]
testlist_comp [5707,5732]
===
match
---
argument [6380,6401]
argument [6467,6488]
===
match
---
operator: , [931,932]
operator: , [931,932]
===
match
---
expr_stmt [5513,5592]
expr_stmt [5600,5679]
===
match
---
name: Union [4452,4457]
name: Union [4539,4544]
===
match
---
simple_stmt [6081,6231]
simple_stmt [6168,6318]
===
match
---
name: object_name [6347,6358]
name: object_name [6434,6445]
===
match
---
name: ads [1090,1093]
name: ads [1090,1093]
===
match
---
name: NamedTemporaryFile [5827,5845]
name: NamedTemporaryFile [5914,5932]
===
match
---
arglist [6117,6212]
arglist [6204,6299]
===
match
---
name: cloud [1156,1161]
name: cloud [1156,1161]
===
match
---
trailer [4544,4554]
trailer [4631,4641]
===
match
---
operator: , [5703,5704]
operator: , [5790,5791]
===
match
---
name: str [4108,4111]
name: str [4187,4190]
===
match
---
name: api_version [4748,4759]
name: api_version [4835,4846]
===
match
---
name: stacklevel [5266,5276]
name: stacklevel [5353,5363]
===
match
---
tfpdef [5354,5367]
tfpdef [5441,5454]
===
match
---
operator: , [4164,4165]
operator: , [4243,4244]
===
match
---
name: gcp_conn_id [4646,4657]
name: gcp_conn_id [4733,4744]
===
match
---
operator: , [6401,6402]
operator: , [6488,6489]
===
match
---
name: gzip [4839,4843]
name: gzip [4926,4930]
===
match
---
operator: = [5579,5580]
operator: = [5666,5667]
===
match
---
name: hook [6081,6085]
name: hook [6168,6172]
===
match
---
tfpdef [4213,4239]
tfpdef [4292,4318]
===
match
---
name: execute [5340,5347]
name: execute [5427,5434]
===
match
---
trailer [5826,5845]
trailer [5913,5932]
===
match
---
argument [5851,5864]
argument [5938,5951]
===
match
---
name: str [4297,4300]
name: str [4385,4388]
===
match
---
simple_stmt [4834,4851]
simple_stmt [4921,4938]
===
match
---
operator: = [5386,5387]
operator: = [5473,5474]
===
match
---
operator: = [6128,6129]
operator: = [6215,6216]
===
match
---
simple_stmt [1245,3885]
simple_stmt [1245,3964]
===
match
---
name: BaseOperator [1226,1238]
name: BaseOperator [1226,1238]
===
match
---
name: parameters [5311,5321]
name: parameters [5398,5408]
===
match
---
name: flush [6057,6062]
name: flush [6144,6149]
===
match
---
atom_expr [5556,5571]
atom_expr [5643,5658]
===
match
---
operator: , [4485,4486]
operator: , [4572,4573]
===
match
---
file_input [787,6523]
file_input [787,6610]
===
match
---
simple_stmt [865,881]
simple_stmt [865,881]
===
match
---
expr_stmt [4641,4671]
expr_stmt [4728,4758]
===
match
---
name: self [5443,5447]
name: self [5530,5534]
===
match
---
name: super [4528,4533]
name: super [4615,4620]
===
match
---
name: self [5306,5310]
name: self [5393,5397]
===
match
---
trailer [5624,5629]
trailer [5711,5716]
===
match
---
suite [4956,5031]
suite [5043,5118]
===
match
---
operator: , [6145,6146]
operator: , [6232,6233]
===
match
---
name: params [4918,4924]
name: params [5005,5011]
===
match
---
atom_expr [5776,5800]
atom_expr [5863,5887]
===
match
---
classdef [1189,6523]
classdef [1189,6610]
===
match
---
atom_expr [4528,4554]
atom_expr [4615,4641]
===
match
---
atom_expr [5963,5983]
atom_expr [6050,6070]
===
match
---
name: List [4155,4159]
name: List [4234,4238]
===
match
---
expr_stmt [5378,5504]
expr_stmt [5465,5591]
===
match
---
operator: -> [4511,4513]
operator: -> [4598,4600]
===
match
---
name: csvfile [6389,6396]
name: csvfile [6476,6483]
===
match
---
name: facebook_conn_id [5448,5464]
name: facebook_conn_id [5535,5551]
===
match
---
name: object_name [6330,6341]
name: object_name [6417,6428]
===
match
---
name: self [5655,5659]
name: self [5742,5746]
===
match
---
name: DeprecationWarning [5230,5248]
name: DeprecationWarning [5317,5335]
===
match
---
parameters [5347,5368]
parameters [5434,5455]
===
match
---
operator: * [4084,4085]
operator: * [4163,4164]
===
match
---
dotted_name [965,983]
dotted_name [965,983]
===
match
---
trailer [6095,6230]
trailer [6182,6317]
===
match
---
name: str [4458,4461]
name: str [4545,4548]
===
match
---
operator: = [4813,4814]
operator: = [4900,4901]
===
match
---
operator: = [4336,4337]
operator: = [4423,4424]
===
match
---
operator: , [3982,3983]
operator: , [4061,4062]
===
match
---
operator: , [4461,4462]
operator: , [4548,4549]
===
match
---
simple_stmt [5378,5505]
simple_stmt [5465,5592]
===
match
---
operator: = [5276,5277]
operator: = [5363,5364]
===
match
---
simple_stmt [6049,6065]
simple_stmt [6136,6152]
===
match
---
name: fields [4782,4788]
name: fields [4869,4875]
===
match
---
operator: , [4360,4361]
operator: , [4447,4448]
===
match
---
name: Optional [4443,4451]
name: Optional [4530,4538]
===
match
---
trailer [4606,4618]
trailer [4693,4705]
===
match
---
param [4147,4165]
param [4226,4244]
===
match
---
name: AirflowException [4975,4991]
name: AirflowException [5062,5078]
===
match
---
arglist [5426,5494]
arglist [5513,5581]
===
match
---
trailer [5482,5494]
trailer [5569,5581]
===
match
---
atom_expr [4155,4164]
atom_expr [4234,4243]
===
match
---
operator: , [4111,4112]
operator: , [4190,4191]
===
match
---
name: self [6292,6296]
name: self [6379,6383]
===
match
---
name: csv [5903,5906]
name: csv [5990,5993]
===
match
---
name: __init__ [4536,4544]
name: __init__ [4623,4631]
===
match
---
argument [4545,4553]
argument [4632,4640]
===
match
---
simple_stmt [881,897]
simple_stmt [881,897]
===
match
---
name: len [5705,5708]
name: len [5792,5795]
===
match
---
simple_stmt [4680,4721]
simple_stmt [4767,4808]
===
match
---
operator: , [6211,6212]
operator: , [6298,6299]
===
match
---
operator: , [4246,4247]
operator: , [4325,4326]
===
match
---
simple_stmt [4563,4594]
simple_stmt [4650,4681]
===
match
---
expr_stmt [4602,4632]
expr_stmt [4689,4719]
===
match
---
name: FacebookAdsReportToGcsOperator [1195,1225]
name: FacebookAdsReportToGcsOperator [1195,1225]
===
match
---
operator: = [4884,4885]
operator: = [4971,4972]
===
match
---
suite [5369,6523]
suite [5456,6610]
===
match
---
arglist [6487,6521]
arglist [6574,6608]
===
match
---
name: airflow [1131,1138]
name: airflow [1131,1138]
===
match
---
expr_stmt [5306,5330]
expr_stmt [5393,5417]
===
match
---
name: models [1021,1027]
name: models [1021,1027]
===
match
---
and_test [5042,5071]
and_test [5129,5158]
===
match
---
name: dict [5620,5624]
name: dict [5707,5711]
===
match
---
name: rows [5641,5645]
name: rows [5728,5732]
===
match
---
name: converted_rows [5602,5616]
name: converted_rows [5689,5703]
===
match
---
name: converted_rows [5776,5790]
name: converted_rows [5863,5877]
===
match
---
trailer [6016,6032]
trailer [6103,6119]
===
match
---
operator: = [6086,6087]
operator: = [6173,6174]
===
match
---
name: kwargs [4547,4553]
name: kwargs [4634,4640]
===
match
---
name: Dict [4225,4229]
name: Dict [4304,4308]
===
match
---
operator: , [3936,3937]
operator: , [4015,4016]
===
match
---
operator: , [4035,4036]
operator: , [4114,4115]
===
match
---
operator: = [4240,4241]
operator: = [4319,4320]
===
match
---
operator: , [4309,4310]
operator: , [4396,4397]
===
match
---
trailer [6006,6016]
trailer [6093,6103]
===
match
---
name: self [5580,5584]
name: self [5667,5671]
===
match
---
trailer [6432,6437]
trailer [6519,6524]
===
match
---
name: GCSHook [6088,6095]
name: GCSHook [6175,6182]
===
match
---
operator: , [4074,4075]
operator: , [4153,4154]
===
match
---
name: name [6517,6521]
name: name [6604,6608]
===
match
---
expr_stmt [4729,4759]
expr_stmt [4816,4846]
===
match
---
name: service [5520,5527]
name: service [5607,5614]
===
match
---
name: keys [5794,5798]
name: keys [5881,5885]
===
match
---
name: csvfile [5869,5876]
name: csvfile [5956,5963]
===
match
---
with_item [5818,5876]
with_item [5905,5963]
===
match
---
name: facebook_conn_id [4685,4701]
name: facebook_conn_id [4772,4788]
===
match
---
name: hooks [1084,1089]
name: hooks [1084,1089]
===
match
---
name: writer [5963,5969]
name: writer [6050,6056]
===
match
---
simple_stmt [5513,5593]
simple_stmt [5600,5680]
===
match
---
sync_comp_for [5630,5645]
sync_comp_for [5717,5732]
===
match
---
atom_expr [4768,4779]
atom_expr [4855,4866]
===
match
---
trailer [5149,5293]
trailer [5236,5380]
===
match
---
argument [5266,5278]
argument [5353,5365]
===
match
---
operator: , [5849,5850]
operator: , [5936,5937]
===
match
---
simple_stmt [4969,5031]
simple_stmt [5056,5118]
===
match
---
simple_stmt [6473,6523]
simple_stmt [6560,6610]
===
match
---
import_name [865,880]
import_name [865,880]
===
match
---
funcdef [5336,6523]
funcdef [5423,6610]
===
match
---
name: gzip [6433,6437]
name: gzip [6520,6524]
===
match
---
name: csvfile [6049,6056]
name: csvfile [6136,6143]
===
match
---
atom_expr [4641,4657]
atom_expr [4728,4744]
===
match
---
param [4121,4138]
param [4200,4217]
===
match
---
dotted_name [1131,1171]
dotted_name [1131,1171]
===
match
---
atom_expr [6000,6032]
atom_expr [6087,6119]
===
match
---
param [5348,5353]
param [5435,5440]
===
match
---
operator: , [5464,5465]
operator: , [5551,5552]
===
match
---
argument [5466,5494]
argument [5553,5581]
===
match
---
name: tempfile [872,880]
name: tempfile [872,880]
===
match
---
string: "facebook_conn_id" [3918,3936]
string: "facebook_conn_id" [3997,4015]
===
match
---
operator: = [5518,5519]
operator: = [5605,5606]
===
match
---
operator: = [5555,5556]
operator: = [5642,5643]
===
match
---
param [4284,4310]
param [4363,4397]
===
match
---
name: gcp_conn_id [6117,6128]
name: gcp_conn_id [6204,6215]
===
match
---
atom_expr [5306,5321]
atom_expr [5393,5408]
===
match
---
expr_stmt [5894,5946]
expr_stmt [5981,6033]
===
match
---
atom_expr [4452,4477]
atom_expr [4539,4564]
===
match
---
name: parameters [4815,4825]
name: parameters [4902,4912]
===
match
---
name: csvfile [6509,6516]
name: csvfile [6596,6603]
===
match
---
operator: , [5925,5926]
operator: , [6012,6013]
===
match
---
name: str [4230,4233]
name: str [4309,4312]
===
match
---
suite [5753,6523]
suite [5840,6610]
===
match
---
trailer [5527,5548]
trailer [5614,5635]
===
match
---
operator: ** [4495,4497]
operator: ** [4582,4584]
===
match
---
operator: , [925,926]
operator: , [925,926]
===
match
---
name: dict [5363,5367]
name: dict [5450,5454]
===
match
---
name: template_fields [3890,3905]
name: template_fields [3969,3984]
===
match
---
string: "impersonation_chain" [3992,4013]
string: "impersonation_chain" [4071,4092]
===
match
---
operator: = [3906,3907]
operator: = [3985,3986]
===
match
---
name: __init__ [4052,4060]
name: __init__ [4131,4139]
===
match
---
name: writer [5894,5900]
name: writer [5981,5987]
===
match
---
atom_expr [4225,4239]
atom_expr [4304,4318]
===
match
---
operator: = [4658,4659]
operator: = [4745,4746]
===
match
---
name: log [5660,5663]
name: log [5747,5750]
===
match
---
name: params [5549,5555]
name: params [5636,5642]
===
match
---
name: bucket_name [6280,6291]
name: bucket_name [6367,6378]
===
match
---
name: params [4174,4180]
name: params [4253,4259]
===
match
---
trailer [6251,6258]
trailer [6338,6345]
===
match
---
name: facebook_conn_id [4370,4386]
name: facebook_conn_id [4457,4473]
===
match
---
import_from [1126,1186]
import_from [1126,1186]
===
match
---
string: "object_name" [3969,3982]
string: "object_name" [4048,4061]
===
match
---
name: bucket_name [4582,4593]
name: bucket_name [4669,4680]
===
match
---
atom_expr [5620,5629]
atom_expr [5707,5716]
===
match
---
simple_stmt [6247,6457]
simple_stmt [6334,6544]
===
match
---
atom_expr [4563,4579]
atom_expr [4650,4666]
===
match
---
name: Any [4192,4195]
name: Any [4271,4274]
===
match
---
operator: = [5322,5323]
operator: = [5409,5410]
===
match
---
dotted_name [1053,1093]
dotted_name [1053,1093]
===
match
---
trailer [5917,5946]
trailer [6004,6033]
===
match
---
name: csvfile [5918,5925]
name: csvfile [6005,6012]
===
match
---
expr_stmt [4563,4593]
expr_stmt [4650,4680]
===
match
---
param [4070,4075]
param [4149,4154]
===
match
---
trailer [5668,5725]
trailer [5755,5812]
===
match
---
name: api_version [4734,4745]
name: api_version [4821,4832]
===
match
---
name: impersonation_chain [6192,6211]
name: impersonation_chain [6279,6298]
===
match
---
simple_stmt [3890,4043]
simple_stmt [3969,4122]
===
match
---
trailer [6346,6358]
trailer [6433,6445]
===
match
---
name: parameters [5053,5063]
name: parameters [5140,5150]
===
match
---
trailer [5790,5793]
trailer [5877,5880]
===
match
---
testlist_comp [3918,4036]
testlist_comp [3997,4115]
===
match
---
name: object_name [4607,4618]
name: object_name [4694,4705]
===
match
---
trailer [5793,5798]
trailer [5880,5885]
===
match
---
with_stmt [5813,6523]
with_stmt [5900,6610]
===
match
---
trailer [4533,4535]
trailer [4620,4622]
===
match
---
name: self [4641,4645]
name: self [4728,4732]
===
match
---
import_name [854,864]
import_name [854,864]
===
match
---
tfpdef [4284,4300]
tfpdef [4363,4389]
===
match
---
name: Optional [933,941]
name: Optional [933,941]
===
match
---
name: parameters [5561,5571]
name: parameters [5648,5658]
===
match
---
trailer [4733,4745]
trailer [4820,4832]
===
match
---
operator: = [5442,5443]
operator: = [5529,5530]
===
match
---
trailer [4471,4476]
trailer [4558,4563]
===
match
---
param [4370,4413]
param [4457,4500]
===
match
---
expr_stmt [4768,4788]
expr_stmt [4855,4875]
===
match
---
expr_stmt [5766,5800]
expr_stmt [5853,5887]
===
match
---
name: tempfile [5818,5826]
name: tempfile [5905,5913]
===
match
---
name: api_version [5466,5477]
name: api_version [5553,5564]
===
match
---
operator: = [4580,4581]
operator: = [4667,4668]
===
match
---
argument [5549,5571]
argument [5636,5658]
===
match
---
tfpdef [4256,4266]
tfpdef [4335,4345]
===
match
---
param [4422,4486]
param [4509,4573]
===
match
---
name: FacebookAdsReportingHook [5388,5412]
name: FacebookAdsReportingHook [5475,5499]
===
match
---
name: self [6342,6346]
name: self [6429,6433]
===
match
---
atom_expr [6509,6521]
atom_expr [6596,6608]
===
match
---
operator: = [5937,5938]
operator: = [6024,6025]
===
match
---
atom_expr [4463,4476]
atom_expr [4550,4563]
===
match
---
trailer [4457,4477]
trailer [4544,4564]
===
match
---
tfpdef [4147,4164]
tfpdef [4226,4243]
===
match
---
operator: = [5477,5478]
operator: = [5564,5565]
===
match
---
trailer [4567,4579]
trailer [4654,4666]
===
match
---
name: bucket_name [4568,4579]
name: bucket_name [4655,4666]
===
match
---
atom [3908,4042]
atom [3987,4121]
===
match
---
name: parameters [4213,4223]
name: parameters [4292,4302]
===
match
---
trailer [5548,5592]
trailer [5635,5679]
===
match
---
name: bool [4262,4266]
name: bool [4341,4345]
===
match
---
atom_expr [4443,4478]
atom_expr [4530,4565]
===
match
---
name: self [5478,5482]
name: self [5565,5569]
===
match
---
atom_expr [6389,6401]
atom_expr [6476,6488]
===
match
---
name: log [6478,6481]
name: log [6565,6568]
===
match
---
operator: = [4301,4302]
operator: = [4390,4391]
===
match
---
name: impersonation_chain [4886,4905]
name: impersonation_chain [4973,4992]
===
match
---
name: gcp_conn_id [4660,4671]
name: gcp_conn_id [4747,4758]
===
match
---
name: bulk_facebook_report [5528,5548]
name: bulk_facebook_report [5615,5635]
===
match
---
if_stmt [5039,5331]
if_stmt [5126,5418]
===
match
---
param [4256,4275]
param [4335,4354]
===
match
---
operator: , [4137,4138]
operator: , [4216,4217]
===
match
---
operator: , [6507,6508]
operator: , [6594,6595]
===
match
---
argument [5573,5591]
argument [5660,5678]
===
match
---
if_stmt [4915,5031]
if_stmt [5002,5118]
===
match
---
atom_expr [5388,5504]
atom_expr [5475,5591]
===
match
---
name: gzip [4846,4850]
name: gzip [4933,4937]
===
match
---
string: "Facebook Returned %s data points" [5669,5703]
string: "Facebook Returned %s data points" [5756,5790]
===
match
---
comparison [5053,5071]
comparison [5140,5158]
===
match
---
name: self [6473,6477]
name: self [6560,6564]
===
match
---
name: info [6482,6486]
name: info [6569,6573]
===
match
---
trailer [5798,5800]
trailer [5885,5887]
===
match
---
name: warnings [5136,5144]
name: warnings [5223,5231]
===
match
---
operator: , [951,952]
operator: , [951,952]
===
match
---
expr_stmt [3890,4042]
expr_stmt [3969,4121]
===
match
---
simple_stmt [6000,6033]
simple_stmt [6087,6120]
===
match
---
simple_stmt [4528,4555]
simple_stmt [4615,4642]
===
match
---
name: writeheader [5970,5981]
name: writeheader [6057,6068]
===
match
---
atom_expr [5903,5946]
atom_expr [5990,6033]
===
match
---
name: Any [916,919]
name: Any [916,919]
===
match
---
trailer [6296,6308]
trailer [6383,6395]
===
match
---
name: writerows [6007,6016]
name: writerows [6094,6103]
===
match
---
operator: = [6186,6187]
operator: = [6273,6274]
===
match
---
name: bucket_name [4095,4106]
name: bucket_name [4174,4185]
===
match
---
atom_expr [5520,5592]
atom_expr [5607,5679]
===
match
---
operator: , [4190,4191]
operator: , [4269,4270]
===
match
---
name: Any [4235,4238]
name: Any [4314,4317]
===
match
---
operator: , [4503,4504]
operator: , [4590,4591]
===
match
---
operator: ** [4545,4547]
operator: ** [4632,4634]
===
match
---
operator: = [4746,4747]
operator: = [4833,4834]
===
match
---
name: self [4797,4801]
name: self [4884,4888]
===
match
---
trailer [6486,6522]
trailer [6573,6609]
===
match
---
trailer [5708,5724]
trailer [5795,5811]
===
match
---
name: self [4729,4733]
name: self [4816,4820]
===
match
---
trailer [5981,5983]
trailer [6068,6070]
===
match
---
atom_expr [6088,6230]
atom_expr [6175,6317]
===
match
---
name: row [5625,5628]
name: row [5712,5715]
===
match
---
name: str [4388,4391]
name: str [4475,4478]
===
match
---
argument [6330,6358]
argument [6417,6445]
===
match
---
atom_expr [4680,4701]
atom_expr [4767,4788]
===
match
---
operator: = [4619,4620]
operator: = [4706,4707]
===
match
---
name: self [6428,6432]
name: self [6515,6519]
===
match
---
name: self [4602,4606]
name: self [4689,4693]
===
match
---
param [4174,4204]
param [4253,4283]
===
match
---
simple_stmt [5894,5947]
simple_stmt [5981,6034]
===
match
---
operator: = [4392,4393]
operator: = [4479,4480]
===
match
---
name: gcp_conn_id [4319,4330]
name: gcp_conn_id [4406,4417]
===
match
---
trailer [4838,4843]
trailer [4925,4930]
===
match
---
operator: , [5248,5249]
operator: , [5335,5336]
===
match
---
param [4495,4504]
param [4582,4591]
===
match
---
subscriptlist [4230,4238]
subscriptlist [4309,4317]
===
match
---
import_name [881,896]
import_name [881,896]
===
match
---
arglist [5167,5279]
arglist [5254,5366]
===
match
---
name: gzip [4256,4260]
name: gzip [4335,4339]
===
match
---
suite [4519,5331]
suite [4606,5418]
===
match
---
string: "Please use 'parameters' instead of 'params'" [5167,5212]
string: "Please use 'parameters' instead of 'params'" [5254,5299]
===
match
---
string: "Argument ['parameters'] is required" [4992,5029]
string: "Argument ['parameters'] is required" [5079,5116]
===
match
---
name: object_name [4121,4132]
name: object_name [4200,4211]
===
match
---
trailer [4186,4196]
trailer [4265,4275]
===
match
---
trailer [6396,6401]
trailer [6483,6488]
===
match
---
simple_stmt [5963,5984]
simple_stmt [6050,6071]
===
match
---
trailer [4772,4779]
trailer [4859,4866]
===
match
---
simple_stmt [4768,4789]
simple_stmt [4855,4876]
===
match
---
comparison [4918,4932]
comparison [5005,5019]
===
match
---
parameters [4060,4510]
parameters [4139,4597]
===
match
---
string: """This module contains Facebook Ad Reporting to GCS operators.""" [787,853]
string: """This module contains Facebook Ad Reporting to GCS operators.""" [787,853]
===
match
---
operator: , [5212,5213]
operator: , [5299,5300]
===
match
---
simple_stmt [854,865]
simple_stmt [854,865]
===
match
---
simple_stmt [4641,4672]
simple_stmt [4728,4759]
===
match
---
name: ads [1080,1083]
name: ads [1080,1083]
===
match
---
string: "google_cloud_default" [4338,4360]
string: "google_cloud_default" [4425,4447]
===
match
---
suite [5072,5331]
suite [5159,5418]
===
match
---
name: converted_rows [6017,6031]
name: converted_rows [6104,6118]
===
match
---
name: rows [5513,5517]
name: rows [5600,5604]
===
match
---
trailer [4801,4812]
trailer [4888,4899]
===
match
---
operator: = [6388,6389]
operator: = [6475,6476]
===
match
---
name: impersonation_chain [4864,4883]
name: impersonation_chain [4951,4970]
===
match
---
atom_expr [5818,5865]
atom_expr [5905,5952]
===
match
---
name: hook [6247,6251]
name: hook [6334,6338]
===
match
---
argument [6117,6145]
argument [6204,6232]
===
match
---
simple_stmt [1048,1126]
simple_stmt [1048,1126]
===
match
---
atom_expr [4602,4618]
atom_expr [4689,4705]
===
match
---
simple_stmt [4729,4760]
simple_stmt [4816,4847]
===
match
---
string: "facebook_default" [4394,4412]
string: "facebook_default" [4481,4499]
===
match
---
simple_stmt [4797,4826]
simple_stmt [4884,4913]
===
match
---
name: airflow [1013,1020]
name: airflow [1013,1020]
===
match
---
name: google [1149,1155]
name: google [1149,1155]
===
match
---
atom_expr [5478,5494]
atom_expr [5565,5581]
===
match
---
atom_expr [6473,6522]
atom_expr [6560,6609]
===
match
---
name: suffix [5851,5857]
name: suffix [5938,5944]
===
match
---
name: self [4859,4863]
name: self [4946,4950]
===
match
---
simple_stmt [5136,5294]
simple_stmt [5223,5381]
===
match
---
operator: , [4203,4204]
operator: , [4282,4283]
===
match
---
arglist [5549,5591]
arglist [5636,5678]
===
match
---
name: row [5634,5637]
name: row [5721,5724]
===
match
---
subscriptlist [4458,4476]
subscriptlist [4545,4563]
===
match
---
expr_stmt [4680,4720]
expr_stmt [4767,4807]
===
match
---
operator: = [6341,6342]
operator: = [6428,6429]
===
match
---
name: self [4768,4772]
name: self [4855,4859]
===
match
---
operator: = [6427,6428]
operator: = [6514,6515]
===
match
---
name: List [927,931]
name: List [927,931]
===
match
---
operator: , [4013,4014]
operator: , [4092,4093]
===
match
---
name: self [4070,4074]
name: self [4149,4153]
===
match
---
tfpdef [4319,4335]
tfpdef [4406,4422]
===
match
---
name: Union [953,958]
name: Union [953,958]
===
match
---
operator: = [4844,4845]
operator: = [4931,4932]
===
match
---
argument [5927,5945]
argument [6014,6032]
===
match
---
operator: , [6437,6438]
operator: , [6524,6525]
===
match
---
trailer [5663,5668]
trailer [5750,5755]
===
match
---
name: BaseOperator [1035,1047]
name: BaseOperator [1035,1047]
===
match
---
name: name [6397,6401]
name: name [6484,6488]
===
match
---
string: "bucket_name" [3946,3959]
string: "bucket_name" [4025,4038]
===
match
---
name: parameters [4802,4812]
name: parameters [4889,4899]
===
match
---
trailer [6481,6486]
trailer [6568,6573]
===
match
---
arglist [5669,5724]
arglist [5756,5811]
===
match
---
simple_stmt [5655,5726]
simple_stmt [5742,5813]
===
match
---
name: DictWriter [5907,5917]
name: DictWriter [5994,6004]
===
match
---
name: self [6129,6133]
name: self [6216,6220]
===
match
---
trailer [6062,6064]
trailer [6149,6151]
===
match
---
argument [6280,6308]
argument [6367,6395]
===
match
---
name: impersonation_chain [6167,6186]
name: impersonation_chain [6254,6273]
===
match
---
name: facebook_conn_id [4704,4720]
name: facebook_conn_id [4791,4807]
===
match
---
name: self [4563,4567]
name: self [4650,4654]
===
match
---
name: airflow [965,972]
name: airflow [965,972]
===
match
---
name: converted_rows [5738,5752]
name: converted_rows [5825,5839]
===
match
---
expr_stmt [4859,4905]
expr_stmt [4946,4992]
===
match
---
name: str [4187,4190]
name: str [4266,4269]
===
match
---
dotted_name [1013,1027]
dotted_name [1013,1027]
===
match
---
import_from [960,1007]
import_from [960,1007]
===
match
---
expr_stmt [6081,6230]
expr_stmt [6168,6317]
===
match
---
arglist [5846,5864]
arglist [5933,5951]
===
match
---
trailer [4535,4544]
trailer [4622,4631]
===
match
---
operator: = [6291,6292]
operator: = [6378,6379]
===
match
---
name: Sequence [4463,4471]
name: Sequence [4550,4558]
===
match
---
name: gcs [1168,1171]
name: gcs [1168,1171]
===
match
---
atom_expr [5443,5464]
atom_expr [5530,5551]
===
match
---
expr_stmt [5602,5646]
expr_stmt [5689,5733]
===
match
---
name: typing [902,908]
name: typing [902,908]
===
match
---
trailer [5447,5464]
trailer [5534,5551]
===
match
---
tfpdef [4121,4137]
tfpdef [4200,4216]
===
match
---
name: self [5556,5560]
name: self [5643,5647]
===
match
---
param [4095,4112]
param [4174,4191]
===
match
---
atom [5619,5646]
atom [5706,5733]
===
match
---
subscriptlist [4187,4195]
subscriptlist [4266,4274]
===
match
---
operator: = [5774,5775]
operator: = [5861,5862]
===
match
---
atom_expr [6049,6064]
atom_expr [6136,6151]
===
match
---
simple_stmt [5766,5801]
simple_stmt [5853,5888]
===
match
---
string: "w" [5846,5849]
string: "w" [5933,5936]
===
match
---
operator: = [4479,4480]
operator: = [4566,4567]
===
match
---
name: headers [5766,5773]
name: headers [5853,5860]
===
match
---
string: """     Fetches the results from the Facebook Ads API as desired in the params     Converts and saves the data as a temporary JSON file     Uploads the JSON to Google Cloud Storage      .. seealso::         For more information on the Facebook Ads API, take a look at the API docs:         https://developers.facebook.com/docs/marketing-apis/      .. seealso::         For more information on the Facebook Ads Python SDK, take a look at the docs:         https://github.com/facebook/facebook-python-business-sdk      .. seealso::         For more information on how to use this operator, take a look at the guide:         :ref:`howto/operator:FacebookAdsReportToGcsOperator`      :param bucket_name: The GCS bucket to upload to     :type bucket_name: str     :param object_name: GCS path to save the object. Must be the full file path (ex. `path/to/file.txt`)     :type object_name: str     :param gcp_conn_id: Airflow Google Cloud connection ID     :type gcp_conn_id: str     :param facebook_conn_id: Airflow Facebook Ads connection ID     :type facebook_conn_id: str     :param api_version: The version of Facebook API. Default to v6.0     :type api_version: str     :param fields: List of fields that is obtained from Facebook. Found in AdsInsights.Field class.         https://developers.facebook.com/docs/marketing-api/insights/parameters/v6.0     :type fields: List[str]     :param params: Parameters that determine the query for Facebook. This keyword is deprecated,         please use `parameters` keyword to pass the parameters.         https://developers.facebook.com/docs/marketing-api/insights/parameters/v6.0     :type params: Dict[str, Any]     :param parameters: Parameters that determine the query for Facebook         https://developers.facebook.com/docs/marketing-api/insights/parameters/v6.0     :type parameters: Dict[str, Any]     :param gzip: Option to compress local file or file data for upload     :type gzip: bool     :param impersonation_chain: Optional service account to impersonate using short-term         credentials, or chained list of accounts required to get the access_token         of the last account in the list, which will be impersonated in the request.         If set as a string, the account must grant the originating account         the Service Account Token Creator IAM role.         If set as a sequence, the identities from the list must grant         Service Account Token Creator IAM role to the directly preceding identity, with first         account from the list granting this role to the originating account (templated).     :type impersonation_chain: Union[str, Sequence[str]]     """ [1245,3884]
string: """     Fetches the results from the Facebook Ads API as desired in the params     Converts and saves the data as a temporary JSON file     Uploads the JSON to Google Cloud Storage      .. seealso::         For more information on the Facebook Ads API, take a look at the API docs:         https://developers.facebook.com/docs/marketing-apis/      .. seealso::         For more information on the Facebook Ads Python SDK, take a look at the docs:         https://github.com/facebook/facebook-python-business-sdk      .. seealso::         For more information on how to use this operator, take a look at the guide:         :ref:`howto/operator:FacebookAdsReportToGcsOperator`      :param bucket_name: The GCS bucket to upload to     :type bucket_name: str     :param object_name: GCS path to save the object. Must be the full file path (ex. `path/to/file.txt`)     :type object_name: str     :param gcp_conn_id: Airflow Google Cloud connection ID     :type gcp_conn_id: str     :param facebook_conn_id: Airflow Facebook Ads connection ID     :type facebook_conn_id: str     :param api_version: The version of Facebook API. Default to None. If it is None,         it will use the Facebook business SDK default version.     :type api_version: str     :param fields: List of fields that is obtained from Facebook. Found in AdsInsights.Field class.         https://developers.facebook.com/docs/marketing-api/insights/parameters/v6.0     :type fields: List[str]     :param params: Parameters that determine the query for Facebook. This keyword is deprecated,         please use `parameters` keyword to pass the parameters.         https://developers.facebook.com/docs/marketing-api/insights/parameters/v6.0     :type params: Dict[str, Any]     :param parameters: Parameters that determine the query for Facebook         https://developers.facebook.com/docs/marketing-api/insights/parameters/v6.0     :type parameters: Dict[str, Any]     :param gzip: Option to compress local file or file data for upload     :type gzip: bool     :param impersonation_chain: Optional service account to impersonate using short-term         credentials, or chained list of accounts required to get the access_token         of the last account in the list, which will be impersonated in the request.         If set as a string, the account must grant the originating account         the Service Account Token Creator IAM role.         If set as a sequence, the identities from the list must grant         Service Account Token Creator IAM role to the directly preceding identity, with first         account from the list granting this role to the originating account (templated).     :type impersonation_chain: Union[str, Sequence[str]]     """ [1245,3963]
===
match
---
trailer [4863,4883]
trailer [4950,4970]
===
match
---
name: self [5348,5352]
name: self [5435,5439]
===
match
---
atom_expr [5705,5724]
atom_expr [5792,5811]
===
match
---
import_from [897,958]
import_from [897,958]
===
match
---
name: fields [5573,5579]
name: fields [5660,5666]
===
match
---
operator: , [4274,4275]
operator: , [4353,4354]
===
match
---
name: headers [5938,5945]
name: headers [6025,6032]
===
match
---
trailer [5584,5591]
trailer [5671,5678]
===
match
---
param [4319,4361]
param [4406,4448]
===
match
---
trailer [4684,4701]
trailer [4771,4788]
===
match
---
name: params [5042,5048]
name: params [5129,5135]
===
match
---
name: exceptions [973,983]
name: exceptions [973,983]
===
match
---
trailer [4451,4478]
trailer [4538,4565]
===
match
---
name: airflow [1053,1060]
name: airflow [1053,1060]
===
match
---
name: providers [1139,1148]
name: providers [1139,1148]
===
match
---
name: upload [6252,6258]
name: upload [6339,6345]
===
match
---
trailer [5144,5149]
trailer [5231,5236]
===
match
---
name: facebook [1071,1079]
name: facebook [1071,1079]
===
match
---
name: str [4332,4335]
name: str [4419,4422]
===
match
---
name: Dict [4182,4186]
name: Dict [4261,4265]
===
match
---
name: GCSHook [1179,1186]
name: GCSHook [1179,1186]
===
match
---
operator: , [5278,5279]
operator: , [5365,5366]
===
match
---
name: filename [6380,6388]
name: filename [6467,6475]
===
match
---
and_test [4918,4955]
and_test [5005,5042]
===
match
---
atom_expr [6129,6145]
atom_expr [6216,6232]
===
match
---
name: gcp_conn_id [6134,6145]
name: gcp_conn_id [6221,6232]
===
match
---
simple_stmt [5306,5331]
simple_stmt [5393,5418]
===
match
---
trailer [5906,5917]
trailer [5993,6004]
===
match
---
name: Dict [921,925]
name: Dict [921,925]
===
match
---
suite [5877,6523]
suite [5964,6610]
===
match
---
tfpdef [4370,4391]
tfpdef [4457,4478]
===
match
---
number: 2 [5277,5278]
number: 2 [5364,5365]
===
match
---
atom_expr [5580,5591]
atom_expr [5667,5678]
===
match
---
name: parameters [4937,4947]
name: parameters [5024,5034]
===
match
---
name: impersonation_chain [4422,4441]
name: impersonation_chain [4509,4528]
===
match
---
atom_expr [5136,5293]
atom_expr [5223,5380]
===
match
---
name: self [6187,6191]
name: self [6274,6278]
===
match
---
atom_expr [4975,5030]
atom_expr [5062,5117]
===
match
---
operator: , [5352,5353]
operator: , [5439,5440]
===
match
---
operator: , [5571,5572]
operator: , [5658,5659]
===
match
---
operator: = [4702,4703]
operator: = [4789,4790]
===
match
---
name: str [4472,4475]
name: str [4559,4562]
===
match
---
name: object_name [4621,4632]
name: object_name [4708,4719]
===
match
---
operator: , [4412,4413]
operator: , [4499,4500]
===
match
---
import_as_names [916,958]
import_as_names [916,958]
===
match
---
string: "%s uploaded to GCS" [6487,6507]
string: "%s uploaded to GCS" [6574,6594]
===
match
---
suite [1240,6523]
suite [1240,6610]
===
match
---
atom_expr [4729,4745]
atom_expr [4816,4832]
===
match
---
trailer [5659,5663]
trailer [5746,5750]
===
match
---
operator: , [919,920]
operator: , [919,920]
===
match
---
trailer [5845,5865]
trailer [5932,5952]
===
match
---
trailer [6191,6211]
trailer [6278,6298]
===
match
---
operator: = [4197,4198]
operator: = [4276,4277]
===
match
---
operator: , [3959,3960]
operator: , [4038,4039]
===
match
---
name: info [5664,5668]
name: info [5751,5755]
===
match
---
operator: , [6358,6359]
operator: , [6445,6446]
===
match
---
simple_stmt [960,1008]
simple_stmt [960,1008]
===
match
---
expr_stmt [4834,4850]
expr_stmt [4921,4937]
===
match
---
raise_stmt [4969,5030]
raise_stmt [5056,5117]
===
match
---
trailer [4991,5030]
trailer [5078,5117]
===
match
---
operator: = [5857,5858]
operator: = [5944,5945]
===
match
---
trailer [4229,4239]
trailer [4308,4318]
===
match
---
simple_stmt [897,959]
simple_stmt [897,959]
===
match
---
string: ".csv" [5858,5864]
string: ".csv" [5945,5951]
===
match
---
name: hooks [1162,1167]
name: hooks [1162,1167]
===
match
---
operator: , [4233,4234]
operator: , [4312,4313]
===
match
---
name: kwargs [4497,4503]
name: kwargs [4584,4590]
===
match
---
name: fields [4773,4779]
name: fields [4860,4866]
===
match
---
param [5354,5367]
param [5441,5454]
===
match
---
argument [6423,6437]
argument [6510,6524]
===
match
---
name: csv [861,864]
name: csv [861,864]
===
match
---
trailer [6477,6481]
trailer [6564,6568]
===
match
---
argument [5426,5464]
argument [5513,5551]
===
match
---
arglist [6280,6438]
arglist [6367,6525]
===
match
---
expr_stmt [4797,4825]
expr_stmt [4884,4912]
===
match
---
trailer [6133,6145]
trailer [6220,6232]
===
match
---
name: self [4834,4838]
name: self [4921,4925]
===
match
---
simple_stmt [1008,1048]
simple_stmt [1008,1048]
===
match
---
name: fields [4147,4153]
name: fields [4226,4232]
===
match
---
simple_stmt [787,854]
simple_stmt [787,854]
===
match
---
param [4213,4247]
param [4292,4326]
===
match
---
name: Sequence [943,951]
name: Sequence [943,951]
===
match
---
name: service [5378,5385]
name: service [5465,5472]
===
match
---
atom_expr [4859,4883]
atom_expr [4946,4970]
===
match
---
import_from [1008,1047]
import_from [1008,1047]
===
match
---
string: "parameters" [4023,4035]
string: "parameters" [4102,4114]
===
match
---
atom_expr [4834,4843]
atom_expr [4921,4930]
===
match
---
name: FacebookAdsReportingHook [1101,1125]
name: FacebookAdsReportingHook [1101,1125]
===
match
---
arglist [5918,5945]
arglist [6005,6032]
===
match
---
trailer [5310,5321]
trailer [5397,5408]
===
match
---
tfpdef [4422,4478]
tfpdef [4509,4565]
===
match
---
simple_stmt [4602,4633]
simple_stmt [4689,4720]
===
match
---
name: AirflowException [991,1007]
name: AirflowException [991,1007]
===
match
---
atom_expr [4797,4812]
atom_expr [4884,4899]
===
match
---
simple_stmt [4859,4906]
simple_stmt [4946,4993]
===
match
---
trailer [5969,5981]
trailer [6056,6068]
===
match
---
simple_stmt [1126,1187]
simple_stmt [1126,1187]
===
match
---
import_from [1048,1125]
import_from [1048,1125]
===
match
---
argument [6167,6211]
argument [6254,6298]
===
match
---
atom_expr [6342,6358]
atom_expr [6429,6445]
===
match
---
trailer [6516,6521]
trailer [6603,6608]
===
match
---
operator: , [941,942]
operator: , [941,942]
===
match
---
number: 0 [5791,5792]
number: 0 [5878,5879]
===
match
---
operator: , [6308,6309]
operator: , [6395,6396]
===
match
---
name: api_version [4284,4295]
name: api_version [4363,4374]
===
match
---
operator: = [5617,5618]
operator: = [5704,5705]
===
match
---
operator: = [5901,5902]
operator: = [5988,5989]
===
match
---
name: facebook_conn_id [5426,5442]
name: facebook_conn_id [5513,5529]
===
match
---
trailer [5560,5571]
trailer [5647,5658]
===
match
---
trailer [4159,4164]
trailer [4238,4243]
===
match
---
name: str [4160,4163]
name: str [4239,4242]
===
match
---
name: fields [5585,5591]
name: fields [5672,5678]
===
match
---
operator: = [4267,4268]
operator: = [4346,4347]
===
match
---
name: providers [1061,1070]
name: providers [1061,1070]
===
match
---
trailer [5412,5504]
trailer [5499,5591]
===
match
---
name: writer [6000,6006]
name: writer [6087,6093]
===
match
---
name: bucket_name [6297,6308]
name: bucket_name [6384,6395]
===
match
---
name: gzip [6423,6427]
name: gzip [6510,6514]
===
match
---
tfpdef [4174,4196]
tfpdef [4253,4275]
===
match
---
trailer [6056,6062]
trailer [6143,6149]
===
match
---
comparison [4937,4955]
comparison [5024,5042]
===
match
---
name: self [4680,4684]
name: self [4767,4771]
===
match
---
name: warnings [888,896]
name: warnings [888,896]
===
match
---
atom_expr [6292,6308]
atom_expr [6379,6395]
===
match
---
operator: , [4085,4086]
operator: , [4164,4165]
===
match
---
atom_expr [5655,5725]
atom_expr [5742,5812]
===
match
---
name: fieldnames [5927,5937]
name: fieldnames [6014,6024]
===
match
---
funcdef [4048,5331]
funcdef [4127,5418]
===
match
---
atom_expr [4182,4196]
atom_expr [4261,4275]
===
match
---
name: converted_rows [5709,5723]
name: converted_rows [5796,5810]
===
match
---
atom_expr [6247,6456]
atom_expr [6334,6543]
===
match
---
trailer [6258,6456]
trailer [6345,6543]
===
match
---
atom_expr [6187,6211]
atom_expr [6274,6298]
===
match
---
name: params [5324,5330]
name: params [5411,5417]
===
match
---
tfpdef [4095,4111]
tfpdef [4174,4190]
===
match
---
name: warn [5145,5149]
name: warn [5232,5236]
===
update-node
---
string: """     Fetches the results from the Facebook Ads API as desired in the params     Converts and saves the data as a temporary JSON file     Uploads the JSON to Google Cloud Storage      .. seealso::         For more information on the Facebook Ads API, take a look at the API docs:         https://developers.facebook.com/docs/marketing-apis/      .. seealso::         For more information on the Facebook Ads Python SDK, take a look at the docs:         https://github.com/facebook/facebook-python-business-sdk      .. seealso::         For more information on how to use this operator, take a look at the guide:         :ref:`howto/operator:FacebookAdsReportToGcsOperator`      :param bucket_name: The GCS bucket to upload to     :type bucket_name: str     :param object_name: GCS path to save the object. Must be the full file path (ex. `path/to/file.txt`)     :type object_name: str     :param gcp_conn_id: Airflow Google Cloud connection ID     :type gcp_conn_id: str     :param facebook_conn_id: Airflow Facebook Ads connection ID     :type facebook_conn_id: str     :param api_version: The version of Facebook API. Default to v6.0     :type api_version: str     :param fields: List of fields that is obtained from Facebook. Found in AdsInsights.Field class.         https://developers.facebook.com/docs/marketing-api/insights/parameters/v6.0     :type fields: List[str]     :param params: Parameters that determine the query for Facebook. This keyword is deprecated,         please use `parameters` keyword to pass the parameters.         https://developers.facebook.com/docs/marketing-api/insights/parameters/v6.0     :type params: Dict[str, Any]     :param parameters: Parameters that determine the query for Facebook         https://developers.facebook.com/docs/marketing-api/insights/parameters/v6.0     :type parameters: Dict[str, Any]     :param gzip: Option to compress local file or file data for upload     :type gzip: bool     :param impersonation_chain: Optional service account to impersonate using short-term         credentials, or chained list of accounts required to get the access_token         of the last account in the list, which will be impersonated in the request.         If set as a string, the account must grant the originating account         the Service Account Token Creator IAM role.         If set as a sequence, the identities from the list must grant         Service Account Token Creator IAM role to the directly preceding identity, with first         account from the list granting this role to the originating account (templated).     :type impersonation_chain: Union[str, Sequence[str]]     """ [1245,3884]
replace """     Fetches the results from the Facebook Ads API as desired in the params     Converts and saves the data as a temporary JSON file     Uploads the JSON to Google Cloud Storage      .. seealso::         For more information on the Facebook Ads API, take a look at the API docs:         https://developers.facebook.com/docs/marketing-apis/      .. seealso::         For more information on the Facebook Ads Python SDK, take a look at the docs:         https://github.com/facebook/facebook-python-business-sdk      .. seealso::         For more information on how to use this operator, take a look at the guide:         :ref:`howto/operator:FacebookAdsReportToGcsOperator`      :param bucket_name: The GCS bucket to upload to     :type bucket_name: str     :param object_name: GCS path to save the object. Must be the full file path (ex. `path/to/file.txt`)     :type object_name: str     :param gcp_conn_id: Airflow Google Cloud connection ID     :type gcp_conn_id: str     :param facebook_conn_id: Airflow Facebook Ads connection ID     :type facebook_conn_id: str     :param api_version: The version of Facebook API. Default to v6.0     :type api_version: str     :param fields: List of fields that is obtained from Facebook. Found in AdsInsights.Field class.         https://developers.facebook.com/docs/marketing-api/insights/parameters/v6.0     :type fields: List[str]     :param params: Parameters that determine the query for Facebook. This keyword is deprecated,         please use `parameters` keyword to pass the parameters.         https://developers.facebook.com/docs/marketing-api/insights/parameters/v6.0     :type params: Dict[str, Any]     :param parameters: Parameters that determine the query for Facebook         https://developers.facebook.com/docs/marketing-api/insights/parameters/v6.0     :type parameters: Dict[str, Any]     :param gzip: Option to compress local file or file data for upload     :type gzip: bool     :param impersonation_chain: Optional service account to impersonate using short-term         credentials, or chained list of accounts required to get the access_token         of the last account in the list, which will be impersonated in the request.         If set as a string, the account must grant the originating account         the Service Account Token Creator IAM role.         If set as a sequence, the identities from the list must grant         Service Account Token Creator IAM role to the directly preceding identity, with first         account from the list granting this role to the originating account (templated).     :type impersonation_chain: Union[str, Sequence[str]]     """ by """     Fetches the results from the Facebook Ads API as desired in the params     Converts and saves the data as a temporary JSON file     Uploads the JSON to Google Cloud Storage      .. seealso::         For more information on the Facebook Ads API, take a look at the API docs:         https://developers.facebook.com/docs/marketing-apis/      .. seealso::         For more information on the Facebook Ads Python SDK, take a look at the docs:         https://github.com/facebook/facebook-python-business-sdk      .. seealso::         For more information on how to use this operator, take a look at the guide:         :ref:`howto/operator:FacebookAdsReportToGcsOperator`      :param bucket_name: The GCS bucket to upload to     :type bucket_name: str     :param object_name: GCS path to save the object. Must be the full file path (ex. `path/to/file.txt`)     :type object_name: str     :param gcp_conn_id: Airflow Google Cloud connection ID     :type gcp_conn_id: str     :param facebook_conn_id: Airflow Facebook Ads connection ID     :type facebook_conn_id: str     :param api_version: The version of Facebook API. Default to None. If it is None,         it will use the Facebook business SDK default version.     :type api_version: str     :param fields: List of fields that is obtained from Facebook. Found in AdsInsights.Field class.         https://developers.facebook.com/docs/marketing-api/insights/parameters/v6.0     :type fields: List[str]     :param params: Parameters that determine the query for Facebook. This keyword is deprecated,         please use `parameters` keyword to pass the parameters.         https://developers.facebook.com/docs/marketing-api/insights/parameters/v6.0     :type params: Dict[str, Any]     :param parameters: Parameters that determine the query for Facebook         https://developers.facebook.com/docs/marketing-api/insights/parameters/v6.0     :type parameters: Dict[str, Any]     :param gzip: Option to compress local file or file data for upload     :type gzip: bool     :param impersonation_chain: Optional service account to impersonate using short-term         credentials, or chained list of accounts required to get the access_token         of the last account in the list, which will be impersonated in the request.         If set as a string, the account must grant the originating account         the Service Account Token Creator IAM role.         If set as a sequence, the identities from the list must grant         Service Account Token Creator IAM role to the directly preceding identity, with first         account from the list granting this role to the originating account (templated).     :type impersonation_chain: Union[str, Sequence[str]]     """
===
insert-node
---
atom_expr [4376,4389]
to
tfpdef [4284,4300]
at 1
===
insert-node
---
trailer [4384,4389]
to
atom_expr [4376,4389]
at 1
===
move-tree
---
name: str [4297,4300]
to
trailer [4384,4389]
at 0
===
delete-node
---
string: "v6.0" [4303,4309]
===
