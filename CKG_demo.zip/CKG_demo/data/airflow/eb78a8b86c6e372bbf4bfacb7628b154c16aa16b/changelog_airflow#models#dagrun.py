===
match
---
expr_stmt [10235,10270]
expr_stmt [10249,10284]
===
match
---
operator: , [25505,25506]
operator: , [25796,25797]
===
match
---
name: DagRun [9357,9363]
name: DagRun [9371,9377]
===
match
---
name: merge [25568,25573]
name: merge [25859,25864]
===
match
---
param [4014,4056]
param [4028,4070]
===
match
---
param [19500,19505]
param [19791,19796]
===
match
---
name: values [25647,25653]
name: values [25938,25944]
===
match
---
name: ignore_in_reschedule_period [21061,21088]
name: ignore_in_reschedule_period [21352,21379]
===
match
---
operator: = [15578,15579]
operator: = [15592,15593]
===
match
---
trailer [16994,17001]
trailer [17008,17015]
===
match
---
operator: = [4530,4531]
operator: = [4544,4545]
===
match
---
name: provide_session [11870,11885]
name: provide_session [11884,11899]
===
match
---
simple_stmt [25003,25093]
simple_stmt [25294,25384]
===
match
---
trailer [13599,13601]
trailer [13613,13615]
===
match
---
simple_stmt [14764,14779]
simple_stmt [14778,14793]
===
match
---
comparison [23952,23978]
comparison [24243,24269]
===
match
---
name: end_date [2775,2783]
name: end_date [2789,2797]
===
match
---
trailer [11723,11730]
trailer [11737,11744]
===
match
---
name: dag [11762,11765]
name: dag [11776,11779]
===
match
---
atom_expr [9926,9993]
atom_expr [9940,10007]
===
match
---
name: schedulable_tis [18405,18420]
name: schedulable_tis [18419,18434]
===
match
---
arglist [13452,13566]
arglist [13466,13580]
===
match
---
param [6177,6210]
param [6191,6224]
===
match
---
funcdef [13638,18275]
funcdef [13652,18289]
===
match
---
operator: { [15529,15530]
operator: { [15543,15544]
===
match
---
name: execution_date [12951,12965]
name: execution_date [12965,12979]
===
match
---
tfpdef [5503,5519]
tfpdef [5517,5533]
===
match
---
name: utcnow [5272,5278]
name: utcnow [5286,5292]
===
match
---
name: ut [18943,18945]
name: ut [19234,19236]
===
match
---
atom_expr [26553,26571]
atom_expr [26844,26862]
===
match
---
name: str [10699,10702]
name: str [10713,10716]
===
match
---
atom_expr [5284,5295]
atom_expr [5298,5309]
===
match
---
name: self [3924,3928]
name: self [3938,3942]
===
match
---
atom_expr [20268,20285]
atom_expr [20559,20576]
===
match
---
operator: = [19655,19656]
operator: = [19946,19947]
===
match
---
atom_expr [14513,14530]
atom_expr [14527,14544]
===
match
---
name: query [20354,20359]
name: query [20645,20650]
===
match
---
name: session [7589,7596]
name: session [7603,7610]
===
match
---
simple_stmt [19644,19660]
simple_stmt [19935,19951]
===
match
---
name: subquery [27738,27746]
name: subquery [28029,28037]
===
match
---
name: self [18157,18161]
name: self [18171,18175]
===
match
---
atom_expr [24640,24664]
atom_expr [24931,24955]
===
match
---
arglist [11173,11183]
arglist [11187,11197]
===
match
---
sync_comp_for [16551,16574]
sync_comp_for [16565,16588]
===
match
---
operator: -> [13249,13251]
operator: -> [13263,13265]
===
match
---
operator: , [19576,19577]
operator: , [19867,19868]
===
match
---
operator: != [6940,6942]
operator: != [6954,6956]
===
match
---
operator: , [23927,23928]
operator: , [24218,24219]
===
match
---
suite [10029,10102]
suite [10043,10116]
===
match
---
atom_expr [14437,14483]
atom_expr [14451,14497]
===
match
---
import_from [2008,2050]
import_from [2022,2064]
===
match
---
atom_expr [5181,5192]
atom_expr [5195,5206]
===
match
---
simple_stmt [23456,23533]
simple_stmt [23747,23824]
===
match
---
simple_stmt [2074,2109]
simple_stmt [2088,2123]
===
match
---
trailer [2266,2270]
trailer [2280,2284]
===
match
---
name: Optional [4284,4292]
name: Optional [4298,4306]
===
match
---
suite [9631,9841]
suite [9645,9855]
===
match
---
suite [10311,10382]
suite [10325,10396]
===
match
---
name: old_state [20178,20187]
name: old_state [20469,20478]
===
match
---
fstring [25124,25161]
fstring [25415,25452]
===
match
---
name: self [17387,17391]
name: self [17401,17405]
===
match
---
argument [20054,20069]
argument [20345,20360]
===
match
---
arglist [19979,20035]
arglist [20270,20326]
===
match
---
atom_expr [5968,5979]
atom_expr [5982,5993]
===
match
---
trailer [13079,13085]
trailer [13093,13099]
===
match
---
operator: , [5396,5397]
operator: , [5410,5411]
===
match
---
operator: != [20428,20430]
operator: != [20719,20721]
===
match
---
operator: == [29837,29839]
operator: == [30128,30130]
===
match
---
argument [17893,17919]
argument [17907,17933]
===
match
---
operator: == [12358,12360]
operator: == [12372,12374]
===
match
---
name: id [2568,2570]
name: id [2582,2584]
===
match
---
trailer [13085,13093]
trailer [13099,13107]
===
match
---
name: ti_deps [1663,1670]
name: ti_deps [1677,1684]
===
match
---
name: ti [22860,22862]
name: ti [23151,23153]
===
match
---
trailer [20617,20621]
trailer [20908,20912]
===
match
---
tfpdef [7678,7717]
tfpdef [7692,7731]
===
match
---
name: self [4648,4652]
name: self [4662,4666]
===
match
---
operator: } [29520,29521]
operator: } [29811,29812]
===
match
---
operator: = [5690,5691]
operator: = [5704,5705]
===
match
---
argument [21181,21196]
argument [21472,21487]
===
match
---
arglist [5730,5759]
arglist [5744,5773]
===
match
---
name: self [29321,29325]
name: self [29612,29616]
===
match
---
name: get_state [5423,5432]
name: get_state [5437,5446]
===
match
---
name: timing [23880,23886]
name: timing [24171,24177]
===
match
---
name: schedulable_tis [14814,14829]
name: schedulable_tis [14828,14843]
===
match
---
name: TI [11804,11806]
name: TI [11818,11820]
===
match
---
name: self [20547,20551]
name: self [20838,20842]
===
match
---
fstring_expr [14633,14646]
fstring_expr [14647,14660]
===
match
---
atom_expr [11097,11116]
atom_expr [11111,11130]
===
match
---
atom_expr [28065,28077]
atom_expr [28356,28368]
===
match
---
atom_expr [9915,9994]
atom_expr [9929,10008]
===
match
---
name: filter [11018,11024]
name: filter [11032,11038]
===
match
---
not_test [22524,22554]
not_test [22815,22845]
===
match
---
atom_expr [9573,9604]
atom_expr [9587,9618]
===
match
---
name: TaskInstance [1491,1503]
name: TaskInstance [1505,1517]
===
match
---
atom_expr [18036,18065]
atom_expr [18050,18079]
===
match
---
operator: = [9701,9702]
operator: = [9715,9716]
===
match
---
expr_stmt [22487,22507]
expr_stmt [22778,22798]
===
match
---
simple_stmt [1274,1303]
simple_stmt [1274,1303]
===
match
---
trailer [19683,19687]
trailer [19974,19978]
===
match
---
trailer [11040,11047]
trailer [11054,11061]
===
match
---
name: filter [12272,12278]
name: filter [12286,12292]
===
match
---
number: 1 [25507,25508]
number: 1 [25798,25799]
===
match
---
name: sqlalchemy [1124,1134]
name: sqlalchemy [1124,1134]
===
match
---
name: leaf_ti [16555,16562]
name: leaf_ti [16569,16576]
===
match
---
name: Optional [14437,14445]
name: Optional [14451,14459]
===
match
---
operator: , [8015,8016]
operator: , [8029,8030]
===
match
---
trailer [3796,3803]
trailer [3810,3817]
===
match
---
string: 'max_dagruns_per_loop_to_schedule' [3834,3868]
string: 'max_dagruns_per_loop_to_schedule' [3848,3882]
===
match
---
suite [12557,12639]
suite [12571,12653]
===
match
---
fstring_string: task_instance_created- [25836,25858]
fstring_string: task_instance_created- [26127,26149]
===
match
---
atom_expr [5418,5432]
atom_expr [5432,5446]
===
match
---
name: update_state [13642,13654]
name: update_state [13656,13668]
===
match
---
name: DagRun [12922,12928]
name: DagRun [12936,12942]
===
match
---
comparison [9804,9839]
comparison [9818,9853]
===
match
---
simple_stmt [23779,23822]
simple_stmt [24070,24113]
===
match
---
trailer [12950,12965]
trailer [12964,12979]
===
match
---
if_stmt [9613,9841]
if_stmt [9627,9855]
===
match
---
simple_stmt [1510,1567]
simple_stmt [1524,1581]
===
match
---
name: dr [6070,6072]
name: dr [6084,6086]
===
match
---
trailer [17682,17938]
trailer [17696,17952]
===
match
---
number: 1 [25163,25164]
number: 1 [25454,25455]
===
match
---
expr_stmt [9567,9604]
expr_stmt [9581,9618]
===
match
---
name: DagCallbackRequest [16896,16914]
name: DagCallbackRequest [16910,16928]
===
match
---
operator: , [2981,2982]
operator: , [2995,2996]
===
match
---
name: State [23736,23741]
name: State [24027,24032]
===
match
---
name: state [18525,18530]
name: state [18539,18544]
===
match
---
name: cls [7048,7051]
name: cls [7062,7065]
===
match
---
name: self [12548,12552]
name: self [12562,12566]
===
match
---
name: task_states [18537,18548]
name: task_states [18551,18562]
===
match
---
trailer [14813,14829]
trailer [14827,14843]
===
match
---
trailer [10510,10550]
trailer [10524,10564]
===
match
---
comparison [29773,29797]
comparison [30064,30088]
===
match
---
trailer [4252,4257]
trailer [4266,4271]
===
match
---
name: conf [4569,4573]
name: conf [4583,4587]
===
match
---
name: are_dependencies_met [19918,19938]
name: are_dependencies_met [20209,20229]
===
match
---
expr_stmt [14695,14750]
expr_stmt [14709,14764]
===
match
---
operator: , [854,855]
operator: , [854,855]
===
match
---
simple_stmt [13065,13158]
simple_stmt [13079,13172]
===
match
---
comparison [13034,13055]
comparison [13048,13069]
===
match
---
name: self [17504,17508]
name: self [17518,17522]
===
match
---
tfpdef [4161,4180]
tfpdef [4175,4194]
===
match
---
name: airflow [1884,1891]
name: airflow [1898,1905]
===
match
---
name: get_run [26485,26492]
name: get_run [26776,26783]
===
match
---
operator: , [18566,18567]
operator: , [18580,18581]
===
match
---
fstring_expr [25858,25874]
fstring_expr [26149,26165]
===
match
---
name: t [15019,15020]
name: t [15033,15034]
===
match
---
trailer [29497,29503]
trailer [29788,29794]
===
match
---
name: state [25275,25280]
name: state [25566,25571]
===
match
---
atom_expr [9804,9821]
atom_expr [9818,9835]
===
match
---
name: dag_id [27898,27904]
name: dag_id [28189,28195]
===
match
---
name: Optional [4204,4212]
name: Optional [4218,4226]
===
match
---
expr_stmt [3001,3046]
expr_stmt [3015,3060]
===
match
---
trailer [3226,3230]
trailer [3240,3244]
===
match
---
name: run_id [5958,5964]
name: run_id [5972,5978]
===
match
---
operator: == [3581,3583]
operator: == [3595,3597]
===
match
---
name: DR [10341,10343]
name: DR [10355,10357]
===
match
---
simple_stmt [2910,2944]
simple_stmt [2924,2958]
===
match
---
operator: = [21129,21130]
operator: = [21420,21421]
===
match
---
expr_stmt [29164,29173]
expr_stmt [29455,29464]
===
match
---
fstring_expr [26224,26236]
fstring_expr [26515,26527]
===
match
---
name: s [11553,11554]
name: s [11567,11568]
===
match
---
atom_expr [3784,3896]
atom_expr [3798,3910]
===
match
---
param [7945,7983]
param [7959,7997]
===
match
---
name: dummy_ti_ids [29657,29669]
name: dummy_ti_ids [29948,29960]
===
match
---
name: super [4728,4733]
name: super [4742,4747]
===
match
---
simple_stmt [19879,19900]
simple_stmt [20170,20191]
===
match
---
name: utcnow [2763,2769]
name: utcnow [2777,2783]
===
match
---
if_stmt [29183,29564]
if_stmt [29474,29855]
===
match
---
if_stmt [10279,10382]
if_stmt [10293,10396]
===
match
---
name: tis [24579,24582]
name: tis [24870,24873]
===
match
---
trailer [16535,16550]
trailer [16549,16564]
===
match
---
name: Integer [2580,2587]
name: Integer [2594,2601]
===
match
---
operator: , [3352,3353]
operator: , [3366,3367]
===
match
---
name: dag_id [5847,5853]
name: dag_id [5861,5867]
===
match
---
trailer [5734,5749]
trailer [5748,5763]
===
match
---
name: cls [27873,27876]
name: cls [28164,28167]
===
match
---
argument [16356,16374]
argument [16370,16388]
===
match
---
name: all [16509,16512]
name: all [16523,16526]
===
match
---
name: reverse [22875,22882]
name: reverse [23166,23173]
===
match
---
trailer [24934,24940]
trailer [25225,25231]
===
match
---
name: task [24722,24726]
name: task [25013,25017]
===
match
---
name: Column [2819,2825]
name: Column [2833,2839]
===
match
---
trailer [27624,27690]
trailer [27915,27981]
===
match
---
trailer [9951,9993]
trailer [9965,10007]
===
match
---
simple_stmt [4368,4389]
simple_stmt [4382,4403]
===
match
---
name: dr [5770,5772]
name: dr [5784,5786]
===
match
---
operator: = [4702,4703]
operator: = [4716,4717]
===
match
---
operator: , [19085,19086]
operator: , [19376,19377]
===
match
---
name: execution_date [26524,26538]
name: execution_date [26815,26829]
===
match
---
suite [24982,25214]
suite [25273,25505]
===
match
---
simple_stmt [14539,14582]
simple_stmt [14553,14596]
===
match
---
operator: , [9672,9673]
operator: , [9686,9687]
===
match
---
fstring_string: __ [10798,10800]
fstring_string: __ [10812,10814]
===
match
---
name: Optional [7955,7963]
name: Optional [7969,7977]
===
match
---
trailer [5861,5868]
trailer [5875,5882]
===
match
---
trailer [11447,11453]
trailer [11461,11467]
===
match
---
name: Session [19595,19602]
name: Session [19886,19893]
===
match
---
operator: >= [10077,10079]
operator: >= [10091,10093]
===
match
---
atom [3270,3497]
atom [3284,3511]
===
match
---
trailer [3343,3371]
trailer [3357,3385]
===
match
---
trailer [25676,25687]
trailer [25967,25978]
===
match
---
argument [17791,17825]
argument [17805,17839]
===
match
---
not_test [15015,15041]
not_test [15029,15055]
===
match
---
trailer [13352,13360]
trailer [13366,13374]
===
match
---
argument [7550,7556]
argument [7564,7570]
===
match
---
name: tis [11586,11589]
name: tis [11600,11603]
===
match
---
name: reason [17525,17531]
name: reason [17539,17545]
===
match
---
name: execution_end_date [10115,10133]
name: execution_end_date [10129,10147]
===
match
---
name: execution_date [3613,3627]
name: execution_date [3627,3641]
===
match
---
operator: , [16630,16631]
operator: , [16644,16645]
===
match
---
annassign [18420,18435]
annassign [18434,18449]
===
match
---
atom_expr [15818,15863]
atom_expr [15832,15877]
===
match
---
testlist_comp [11533,11554]
testlist_comp [11547,11568]
===
match
---
comparison [27232,27271]
comparison [27523,27562]
===
match
---
name: self [19500,19504]
name: self [19791,19795]
===
match
---
atom_expr [27625,27635]
atom_expr [27916,27926]
===
match
---
name: filter [10157,10163]
name: filter [10171,10177]
===
match
---
name: Optional [4077,4085]
name: Optional [4091,4099]
===
match
---
operator: -> [27506,27508]
operator: -> [27797,27799]
===
match
---
expr_stmt [9405,9462]
expr_stmt [9419,9476]
===
match
---
operator: = [15527,15528]
operator: = [15541,15542]
===
match
---
trailer [14543,14568]
trailer [14557,14582]
===
match
---
atom_expr [18213,18232]
atom_expr [18227,18246]
===
match
---
simple_stmt [5708,5761]
simple_stmt [5722,5775]
===
match
---
name: partial [24974,24981]
name: partial [25265,25272]
===
match
---
operator: == [27884,27886]
operator: == [28175,28177]
===
match
---
trailer [27909,27924]
trailer [28200,28215]
===
match
---
argument [13101,13109]
argument [13115,13123]
===
match
---
argument [7589,7604]
argument [7603,7618]
===
match
---
operator: , [7140,7141]
operator: , [7154,7155]
===
match
---
operator: <= [7466,7468]
operator: <= [7480,7482]
===
match
---
param [13695,13725]
param [13709,13739]
===
match
---
decorated [24061,26458]
decorated [24352,26749]
===
match
---
name: TI [11076,11078]
name: TI [11090,11092]
===
match
---
operator: = [10890,10891]
operator: = [10904,10905]
===
match
---
atom_expr [5844,5853]
atom_expr [5858,5867]
===
match
---
operator: -> [13732,13734]
operator: -> [13746,13748]
===
match
---
name: leaf_ti [16513,16520]
name: leaf_ti [16527,16534]
===
match
---
trailer [7473,7477]
trailer [7487,7491]
===
match
---
name: schedulable_tis [15345,15360]
name: schedulable_tis [15359,15374]
===
match
---
trailer [6007,6011]
trailer [6021,6025]
===
match
---
name: self [15818,15822]
name: self [15832,15836]
===
match
---
name: str [12736,12739]
name: str [12750,12753]
===
match
---
param [6138,6142]
param [6152,6156]
===
match
---
trailer [14957,14974]
trailer [14971,14988]
===
match
---
name: self [13348,13352]
name: self [13362,13366]
===
match
---
name: filter [13094,13100]
name: filter [13108,13114]
===
match
---
name: Optional [8102,8110]
name: Optional [8116,8124]
===
match
---
name: airflow_conf [3784,3796]
name: airflow_conf [3798,3810]
===
match
---
operator: = [17098,17099]
operator: = [17112,17113]
===
match
---
operator: , [3317,3318]
operator: , [3331,3332]
===
match
---
atom_expr [4471,4486]
atom_expr [4485,4500]
===
match
---
operator: = [4258,4259]
operator: = [4272,4273]
===
match
---
atom_expr [19242,19466]
atom_expr [19533,19757]
===
match
---
trailer [11589,11596]
trailer [11603,11610]
===
match
---
argument [7558,7573]
argument [7572,7587]
===
match
---
name: run_type [4620,4628]
name: run_type [4634,4642]
===
match
---
operator: , [864,865]
operator: , [864,865]
===
match
---
expr_stmt [14842,14872]
expr_stmt [14856,14886]
===
match
---
name: DagRun [27096,27102]
name: DagRun [27387,27393]
===
match
---
atom_expr [10580,10597]
atom_expr [10594,10611]
===
match
---
operator: = [16002,16003]
operator: = [16016,16017]
===
match
---
name: tis [11434,11437]
name: tis [11448,11451]
===
match
---
trailer [5422,5432]
trailer [5436,5446]
===
match
---
arglist [25834,25881]
arglist [26125,26172]
===
match
---
trailer [18507,18569]
trailer [18521,18583]
===
match
---
simple_stmt [15302,15504]
simple_stmt [15316,15518]
===
match
---
name: external_trigger [27144,27160]
name: external_trigger [27435,27451]
===
match
---
for_stmt [28819,29155]
for_stmt [29110,29446]
===
match
---
name: execution_date [9807,9821]
name: execution_date [9821,9835]
===
match
---
trailer [4619,4628]
trailer [4633,4642]
===
match
---
name: schedulable_tis [19313,19328]
name: schedulable_tis [19604,19619]
===
match
---
name: is_ [7130,7133]
name: is_ [7144,7147]
===
match
---
operator: = [4968,4969]
operator: = [4982,4983]
===
match
---
operator: == [27110,27112]
operator: == [27401,27403]
===
match
---
trailer [11024,11127]
trailer [11038,11141]
===
match
---
name: dag [17484,17487]
name: dag [17498,17501]
===
match
---
suite [5109,5137]
suite [5123,5151]
===
match
---
operator: += [29224,29226]
operator: += [29515,29517]
===
match
---
name: self [5497,5501]
name: self [5511,5515]
===
match
---
trailer [18854,18860]
trailer [19145,19151]
===
match
---
tfpdef [7945,7975]
tfpdef [7959,7989]
===
match
---
trailer [14528,14530]
trailer [14542,14544]
===
match
---
atom_expr [7695,7716]
atom_expr [7709,7730]
===
match
---
simple_stmt [9909,9995]
simple_stmt [9923,10009]
===
match
---
name: Session [12758,12765]
name: Session [12772,12779]
===
match
---
param [27353,27357]
param [27644,27648]
===
match
---
operator: , [1022,1023]
operator: , [1022,1023]
===
match
---
return_stmt [10779,10829]
return_stmt [10793,10843]
===
match
---
argument [21061,21093]
argument [21352,21384]
===
match
---
name: task_id [12361,12368]
name: task_id [12375,12382]
===
match
---
comp_op [24941,24947]
comp_op [25232,25238]
===
match
---
trailer [13026,13033]
trailer [13040,13047]
===
match
---
name: models [6663,6669]
name: models [6677,6683]
===
match
---
name: t [18768,18769]
name: t [19059,19060]
===
match
---
arglist [22845,22888]
arglist [23136,23179]
===
match
---
name: task_id [29884,29891]
name: task_id [30175,30182]
===
match
---
name: exec_date [5928,5937]
name: exec_date [5942,5951]
===
match
---
name: dep_context [20921,20932]
name: dep_context [21212,21223]
===
match
---
name: self [23722,23726]
name: self [24013,24017]
===
match
---
operator: = [3241,3242]
operator: = [3255,3256]
===
match
---
name: Session [11941,11948]
name: Session [11955,11962]
===
match
---
operator: == [27397,27399]
operator: == [27688,27690]
===
match
---
name: session [5789,5796]
name: session [5803,5810]
===
match
---
string: 'dag_run' [3717,3726]
string: 'dag_run' [3731,3740]
===
match
---
fstring_end: ' [23518,23519]
fstring_end: ' [23809,23810]
===
match
---
simple_stmt [4615,4640]
simple_stmt [4629,4654]
===
match
---
trailer [24623,24627]
trailer [24914,24918]
===
match
---
name: dag [13523,13526]
name: dag [13537,13540]
===
match
---
atom_expr [16665,16678]
atom_expr [16679,16692]
===
match
---
name: task_id [18724,18731]
name: task_id [18759,18766]
===
match
---
arglist [29773,29910]
arglist [30064,30201]
===
match
---
operator: , [19199,19200]
operator: , [19490,19491]
===
match
---
suite [17467,17573]
suite [17481,17587]
===
match
---
name: self [4681,4685]
name: self [4695,4699]
===
match
---
expr_stmt [10494,10550]
expr_stmt [10508,10564]
===
match
---
name: schedulable_tis [28048,28063]
name: schedulable_tis [28339,28354]
===
match
---
name: qry [9495,9498]
name: qry [9509,9512]
===
match
---
trailer [9525,9534]
trailer [9539,9548]
===
match
---
operator: , [1444,1445]
operator: , [1458,1459]
===
match
---
trailer [27071,27078]
trailer [27362,27369]
===
match
---
operator: } [10797,10798]
operator: } [10811,10812]
===
match
---
trailer [10431,10456]
trailer [10445,10470]
===
match
---
name: state [11140,11145]
name: state [11154,11159]
===
match
---
name: unfinished_tasks [18891,18907]
name: unfinished_tasks [19182,19198]
===
match
---
name: limit [7531,7536]
name: limit [7545,7550]
===
match
---
parameters [13217,13248]
parameters [13231,13262]
===
match
---
trailer [17721,17729]
trailer [17735,17743]
===
match
---
dotted_name [2013,2032]
dotted_name [2027,2046]
===
match
---
trailer [10434,10443]
trailer [10448,10457]
===
match
---
name: int [6198,6201]
name: int [6212,6215]
===
match
---
name: ti [25526,25528]
name: ti [25817,25819]
===
match
---
param [12720,12748]
param [12734,12762]
===
match
---
suite [29100,29155]
suite [29391,29446]
===
match
---
name: String [1016,1022]
name: String [1016,1022]
===
match
---
name: func [27637,27641]
name: func [27928,27932]
===
match
---
operator: , [3691,3692]
operator: , [3705,3706]
===
match
---
param [10897,10909]
param [10911,10923]
===
match
---
name: session [12749,12756]
name: session [12763,12770]
===
match
---
name: List [13741,13745]
name: List [13755,13759]
===
match
---
arglist [29308,29451]
arglist [29599,29742]
===
match
---
name: Column [2620,2626]
name: Column [2634,2640]
===
match
---
operator: , [1010,1011]
operator: , [1010,1011]
===
match
---
name: task_ids [11828,11836]
name: task_ids [11842,11850]
===
match
---
trailer [5796,5802]
trailer [5810,5816]
===
match
---
atom_expr [25003,25092]
atom_expr [25294,25383]
===
match
---
name: all [15105,15108]
name: all [15119,15122]
===
match
---
name: self [17337,17341]
name: self [17351,17355]
===
match
---
operator: = [3735,3736]
operator: = [3749,3750]
===
match
---
name: filters [13102,13109]
name: filters [13116,13123]
===
match
---
name: unfinished_tasks [20561,20577]
name: unfinished_tasks [20852,20868]
===
match
---
name: self [13218,13222]
name: self [13232,13236]
===
match
---
name: not_none_state [11614,11628]
name: not_none_state [11628,11642]
===
match
---
expr_stmt [5770,6023]
expr_stmt [5784,6037]
===
match
---
trailer [29426,29430]
trailer [29717,29721]
===
match
---
funcdef [13184,13612]
funcdef [13198,13626]
===
match
---
name: s [11533,11534]
name: s [11547,11548]
===
match
---
trailer [15407,15450]
trailer [15421,15464]
===
match
---
name: self [24930,24934]
name: self [25221,25225]
===
match
---
name: filter [11590,11596]
name: filter [11604,11610]
===
match
---
atom_expr [2573,2606]
atom_expr [2587,2620]
===
match
---
operator: = [19688,19689]
operator: = [19979,19980]
===
match
---
name: TI [29308,29310]
name: TI [29599,29601]
===
match
---
simple_stmt [24143,24405]
simple_stmt [24434,24696]
===
match
---
simple_stmt [17337,17393]
simple_stmt [17351,17407]
===
match
---
return_stmt [27376,27423]
return_stmt [27667,27714]
===
match
---
name: execution_date [11102,11116]
name: execution_date [11116,11130]
===
match
---
name: set [24555,24558]
name: set [24846,24849]
===
match
---
name: str [26519,26522]
name: str [26810,26813]
===
match
---
trailer [3992,3997]
trailer [4006,4011]
===
match
---
string: 'task_failure' [16003,16017]
string: 'task_failure' [16017,16031]
===
match
---
name: provide_session [28005,28020]
name: provide_session [28296,28311]
===
match
---
name: DagModel [7029,7037]
name: DagModel [7043,7051]
===
match
---
trailer [30072,30079]
trailer [30363,30370]
===
match
---
comp_if [11550,11554]
comp_if [11564,11568]
===
match
---
trailer [7086,7093]
trailer [7100,7107]
===
match
---
name: log [26147,26150]
name: log [26438,26441]
===
match
---
name: Optional [4130,4138]
name: Optional [4144,4152]
===
match
---
trailer [10424,10431]
trailer [10438,10445]
===
match
---
trailer [23726,23732]
trailer [24017,24023]
===
match
---
name: dummy_ti_ids [28761,28773]
name: dummy_ti_ids [29052,29064]
===
match
---
operator: , [1940,1941]
operator: , [1954,1955]
===
match
---
name: TI [3592,3594]
name: TI [3606,3608]
===
match
---
atom_expr [23456,23532]
atom_expr [23747,23823]
===
match
---
param [11932,11955]
param [11946,11969]
===
match
---
name: Union [7695,7700]
name: Union [7709,7714]
===
match
---
suite [9482,9536]
suite [9496,9550]
===
match
---
operator: , [7850,7851]
operator: , [7864,7865]
===
match
---
operator: = [20985,20986]
operator: = [21276,21277]
===
match
---
arglist [2580,2605]
arglist [2594,2619]
===
match
---
atom_expr [4787,5083]
atom_expr [4801,5097]
===
match
---
operator: = [18456,18457]
operator: = [18470,18471]
===
match
---
name: find [7664,7668]
name: find [7678,7682]
===
match
---
name: finished_tasks [21130,21144]
name: finished_tasks [21421,21435]
===
match
---
name: classmethod [6085,6096]
name: classmethod [6099,6110]
===
match
---
name: BACKFILL_JOB [10537,10549]
name: BACKFILL_JOB [10551,10563]
===
match
---
argument [16254,16288]
argument [16268,16302]
===
match
---
name: state [10216,10221]
name: state [10230,10235]
===
match
---
trailer [24452,24471]
trailer [24743,24762]
===
match
---
atom_expr [26040,26055]
atom_expr [26331,26346]
===
match
---
name: key [20171,20174]
name: key [20462,20465]
===
match
---
argument [18525,18568]
argument [18539,18582]
===
match
---
simple_stmt [10779,10830]
simple_stmt [10793,10844]
===
match
---
name: self [6033,6037]
name: self [6047,6051]
===
match
---
if_stmt [17446,17939]
if_stmt [17460,17953]
===
match
---
trailer [15531,15539]
trailer [15545,15553]
===
match
---
trailer [27876,27883]
trailer [28167,28174]
===
match
---
comparison [18780,18807]
comparison [19071,19098]
===
match
---
expr_stmt [20157,20187]
expr_stmt [20448,20478]
===
match
---
name: leaf_tis [15795,15803]
name: leaf_tis [15809,15817]
===
match
---
number: 1 [25877,25878]
number: 1 [26168,26169]
===
match
---
name: scheduleable_tasks [19514,19532]
name: scheduleable_tasks [19805,19823]
===
match
---
trailer [9918,9925]
trailer [9932,9939]
===
match
---
trailer [13434,13580]
trailer [13448,13594]
===
match
---
name: query [9387,9392]
name: query [9401,9406]
===
match
---
name: TI [2237,2239]
name: TI [2251,2253]
===
match
---
suite [10222,10271]
suite [10236,10285]
===
match
---
simple_stmt [20334,20389]
simple_stmt [20625,20680]
===
match
---
trailer [11221,11227]
trailer [11235,11241]
===
match
---
atom_expr [14902,14921]
atom_expr [14916,14935]
===
match
---
operator: = [3960,3961]
operator: = [3974,3975]
===
match
---
trailer [16225,16232]
trailer [16239,16246]
===
match
---
param [12749,12772]
param [12763,12786]
===
match
---
argument [3728,3741]
argument [3742,3755]
===
match
---
atom [15529,15560]
atom [15543,15574]
===
match
---
expr_stmt [2537,2562]
expr_stmt [2551,2576]
===
match
---
operator: { [29494,29495]
operator: { [29785,29786]
===
match
---
atom_expr [27096,27109]
atom_expr [27387,27400]
===
match
---
atom_expr [25284,25297]
atom_expr [25575,25588]
===
match
---
name: error [15827,15832]
name: error [15841,15846]
===
match
---
string: 'state' [2826,2833]
string: 'state' [2840,2847]
===
match
---
comparison [3592,3627]
comparison [3606,3641]
===
match
---
operator: = [7290,7291]
operator: = [7304,7305]
===
match
---
atom_expr [16950,16961]
atom_expr [16964,16975]
===
match
---
atom [29494,29521]
atom [29785,29812]
===
match
---
atom_expr [7048,7058]
atom_expr [7062,7072]
===
match
---
name: execution_end_date [10185,10203]
name: execution_end_date [10199,10217]
===
match
---
operator: -> [12424,12426]
operator: -> [12438,12440]
===
match
---
name: subquery [27887,27895]
name: subquery [28178,28186]
===
match
---
simple_stmt [15569,15630]
simple_stmt [15583,15644]
===
match
---
operator: , [17825,17826]
operator: , [17839,17840]
===
match
---
operator: , [5937,5938]
operator: , [5951,5952]
===
match
---
name: task_dict [25637,25646]
name: task_dict [25928,25937]
===
match
---
argument [3554,3628]
argument [3568,3642]
===
match
---
name: Exception [23548,23557]
name: Exception [23839,23848]
===
match
---
name: SCHEDULEABLE_STATES [18988,19007]
name: SCHEDULEABLE_STATES [19279,19298]
===
match
---
name: session [27611,27618]
name: session [27902,27909]
===
match
---
name: external_trigger [4532,4548]
name: external_trigger [4546,4562]
===
match
---
funcdef [5348,5451]
funcdef [5362,5465]
===
match
---
comparison [11038,11062]
comparison [11052,11076]
===
match
---
name: datetime [8111,8119]
name: datetime [8125,8133]
===
match
---
name: session [1848,1855]
name: session [1862,1869]
===
match
---
name: order_by [10571,10579]
name: order_by [10585,10593]
===
match
---
operator: , [956,957]
operator: , [956,957]
===
match
---
operator: , [11116,11117]
operator: , [11130,11131]
===
match
---
atom_expr [3058,3076]
atom_expr [3072,3090]
===
match
---
import_from [1274,1302]
import_from [1274,1302]
===
match
---
trailer [30015,30023]
trailer [30306,30314]
===
match
---
name: State [18531,18536]
name: State [18545,18550]
===
match
---
name: self [14668,14672]
name: self [14682,14686]
===
match
---
arglist [19181,19224]
arglist [19472,19515]
===
match
---
name: property [27324,27332]
name: property [27615,27623]
===
match
---
name: airflow [1777,1784]
name: airflow [1791,1798]
===
match
---
param [7909,7936]
param [7923,7950]
===
match
---
simple_stmt [26142,26277]
simple_stmt [26433,26568]
===
match
---
name: Iterable [10914,10922]
name: Iterable [10928,10936]
===
match
---
trailer [29310,29317]
trailer [29601,29608]
===
match
---
param [27487,27491]
param [27778,27782]
===
match
---
tfpdef [4234,4257]
tfpdef [4248,4271]
===
match
---
name: true_delay [23521,23531]
name: true_delay [23812,23822]
===
match
---
suite [29034,29083]
suite [29325,29374]
===
match
---
name: info [14809,14813]
name: info [14823,14827]
===
match
---
string: 'Marking run %s failed' [15833,15856]
string: 'Marking run %s failed' [15847,15870]
===
match
---
name: filter [11212,11218]
name: filter [11226,11232]
===
match
---
if_stmt [29654,30281]
if_stmt [29945,30572]
===
match
---
name: List [866,870]
name: List [866,870]
===
match
---
name: duration [24046,24054]
name: duration [24337,24345]
===
match
---
name: ti [24573,24575]
name: ti [24864,24866]
===
match
---
name: self [14539,14543]
name: self [14553,14557]
===
match
---
name: self [18340,18344]
name: self [18354,18358]
===
match
---
atom_expr [3427,3490]
atom_expr [3441,3504]
===
match
---
suite [12433,12664]
suite [12447,12678]
===
match
---
atom_expr [29321,29332]
atom_expr [29612,29623]
===
match
---
trailer [15822,15826]
trailer [15836,15840]
===
match
---
name: filters [13019,13026]
name: filters [13033,13040]
===
match
---
atom [15323,15503]
atom [15337,15517]
===
match
---
operator: -> [11957,11959]
operator: -> [11971,11973]
===
match
---
trailer [13260,13270]
trailer [13274,13284]
===
match
---
string: 'Doing session rollback.' [26303,26328]
string: 'Doing session rollback.' [26594,26619]
===
match
---
parameters [26492,26549]
parameters [26783,26840]
===
match
---
operator: , [3544,3545]
operator: , [3558,3559]
===
match
---
param [4197,4225]
param [4211,4239]
===
match
---
expr_stmt [10042,10101]
expr_stmt [10056,10115]
===
match
---
name: self [18075,18079]
name: self [18089,18093]
===
match
---
name: session [17556,17563]
name: session [17570,17577]
===
match
---
name: self [5051,5055]
name: self [5065,5069]
===
match
---
name: unfinished_tasks [14934,14950]
name: unfinished_tasks [14948,14964]
===
match
---
name: _state [5289,5295]
name: _state [5303,5309]
===
match
---
name: dag [16822,16825]
name: dag [16836,16839]
===
match
---
name: is_ [7177,7180]
name: is_ [7191,7194]
===
match
---
operator: = [18695,18696]
operator: = [18730,18731]
===
match
---
operator: , [25878,25879]
operator: , [26169,26170]
===
match
---
arglist [27625,27689]
arglist [27916,27980]
===
match
---
name: dag [25490,25493]
name: dag [25781,25784]
===
match
---
if_stmt [15917,16394]
if_stmt [15931,16408]
===
match
---
funcdef [5089,5137]
funcdef [5103,5151]
===
match
---
expr_stmt [4397,4417]
expr_stmt [4411,4431]
===
match
---
operator: } [23489,23490]
operator: } [23780,23781]
===
match
---
name: qry [10415,10418]
name: qry [10429,10432]
===
match
---
simple_stmt [16867,17159]
simple_stmt [16881,17173]
===
match
---
name: info [16598,16602]
name: info [16612,16616]
===
match
---
operator: < [12944,12945]
operator: < [12958,12959]
===
match
---
name: unfinished_tasks [20847,20863]
name: unfinished_tasks [21138,21154]
===
match
---
name: execution_date [3595,3609]
name: execution_date [3609,3623]
===
match
---
name: self [5009,5013]
name: self [5023,5027]
===
match
---
name: self [24448,24452]
name: self [24739,24743]
===
match
---
atom_expr [14702,14750]
atom_expr [14716,14764]
===
match
---
name: query [13080,13085]
name: query [13094,13099]
===
match
---
name: self [17758,17762]
name: self [17772,17776]
===
match
---
simple_stmt [2948,2997]
simple_stmt [2962,3011]
===
match
---
string: """         Get a single DAG Run          :param session: Sqlalchemy ORM Session         :type session: Session         :param dag_id: DAG ID         :type dag_id: unicode         :param execution_date: execution date         :type execution_date: datetime         :return: DagRun corresponding to the given dag_id and execution date             if one exists. None otherwise.         :rtype: airflow.models.DagRun         """ [26581,27007]
string: """         Get a single DAG Run          :param session: Sqlalchemy ORM Session         :type session: Session         :param dag_id: DAG ID         :type dag_id: unicode         :param execution_date: execution date         :type execution_date: datetime         :return: DagRun corresponding to the given dag_id and execution date             if one exists. None otherwise.         :rtype: airflow.models.DagRun         """ [26872,27298]
===
match
---
name: execution_date [4448,4462]
name: execution_date [4462,4476]
===
match
---
name: dag_id [16226,16232]
name: dag_id [16240,16246]
===
match
---
name: self [11744,11748]
name: self [11758,11762]
===
match
---
tfpdef [3976,3997]
tfpdef [3990,4011]
===
match
---
number: 0 [22947,22948]
number: 0 [23238,23239]
===
match
---
name: finished_tasks [14885,14899]
name: finished_tasks [14899,14913]
===
match
---
name: State [2002,2007]
name: State [2016,2021]
===
match
---
name: state [30003,30008]
name: state [30294,30299]
===
match
---
name: self [5156,5160]
name: self [5170,5174]
===
match
---
name: handle_callback [15959,15974]
name: handle_callback [15973,15988]
===
match
---
name: self [4588,4592]
name: self [4602,4606]
===
match
---
name: task_id [15604,15611]
name: task_id [15618,15625]
===
match
---
suite [19756,19799]
suite [20047,20090]
===
match
---
name: execute_callbacks [17449,17466]
name: execute_callbacks [17463,17480]
===
match
---
operator: , [4102,4103]
operator: , [4116,4117]
===
match
---
trailer [3532,3749]
trailer [3546,3763]
===
match
---
operator: , [3928,3929]
operator: , [3942,3943]
===
match
---
simple_stmt [1119,1172]
simple_stmt [1119,1172]
===
match
---
trailer [12901,12908]
trailer [12915,12922]
===
match
---
name: staticmethod [7622,7634]
name: staticmethod [7636,7648]
===
match
---
operator: , [11178,11179]
operator: , [11192,11193]
===
match
---
name: TI [20360,20362]
name: TI [20651,20653]
===
match
---
operator: , [25502,25503]
operator: , [25793,25794]
===
match
---
operator: { [23478,23479]
operator: { [23769,23770]
===
match
---
name: log [1791,1794]
name: log [1805,1808]
===
match
---
atom_expr [10059,10076]
atom_expr [10073,10090]
===
match
---
comp_if [18777,18807]
comp_if [19068,19098]
===
match
---
name: callback_requests [17646,17663]
name: callback_requests [17660,17677]
===
match
---
simple_stmt [24640,24665]
simple_stmt [24931,24956]
===
match
---
name: _get_ready_tis [19166,19180]
name: _get_ready_tis [19457,19471]
===
match
---
name: are_dependencies_met [20883,20903]
name: are_dependencies_met [21174,21194]
===
match
---
name: utils [1983,1988]
name: utils [1997,2002]
===
match
---
name: declared_attr [1158,1171]
name: declared_attr [1158,1171]
===
match
---
name: self [5284,5288]
name: self [5298,5302]
===
match
---
trailer [29744,29751]
trailer [30035,30042]
===
match
---
name: dag [16730,16733]
name: dag [16744,16747]
===
match
---
operator: = [21188,21189]
operator: = [21479,21480]
===
match
---
name: tis [11580,11583]
name: tis [11594,11597]
===
match
---
trailer [23879,23886]
trailer [24170,24177]
===
match
---
expr_stmt [29218,29563]
expr_stmt [29509,29854]
===
match
---
operator: , [7724,7725]
operator: , [7738,7739]
===
match
---
operator: = [18477,18478]
operator: = [18491,18492]
===
match
---
trailer [11376,11402]
trailer [11390,11416]
===
match
---
operator: , [18344,18345]
operator: , [18358,18359]
===
match
---
operator: , [4304,4305]
operator: , [4318,4319]
===
match
---
operator: , [12908,12909]
operator: , [12922,12923]
===
match
---
operator: , [27169,27170]
operator: , [27460,27461]
===
match
---
name: with_row_locks [1955,1969]
name: with_row_locks [1969,1983]
===
match
---
name: List [2232,2236]
name: List [2246,2250]
===
match
---
name: run_id [4411,4417]
name: run_id [4425,4431]
===
match
---
name: session [7283,7290]
name: session [7297,7304]
===
match
---
simple_stmt [10936,10986]
simple_stmt [10950,11000]
===
match
---
trailer [27895,27897]
trailer [28186,28188]
===
match
---
name: run_type [10447,10455]
name: run_type [10461,10469]
===
match
---
operator: , [21328,21329]
operator: , [21619,21620]
===
match
---
operator: = [5050,5051]
operator: = [5064,5065]
===
match
---
name: TI [30107,30109]
name: TI [30398,30400]
===
match
---
name: execution_date [26245,26259]
name: execution_date [26536,26550]
===
match
---
atom_expr [23736,23749]
atom_expr [24027,24040]
===
match
---
operator: = [4928,4929]
operator: = [4942,4943]
===
match
---
trailer [29356,29371]
trailer [29647,29662]
===
match
---
atom_expr [25998,26013]
atom_expr [26289,26304]
===
match
---
operator: , [3029,3030]
operator: , [3043,3044]
===
match
---
trailer [5819,5826]
trailer [5833,5840]
===
match
---
operator: = [3176,3177]
operator: = [3190,3191]
===
match
---
name: external_trigger [22376,22392]
name: external_trigger [22667,22683]
===
match
---
simple_stmt [817,907]
simple_stmt [817,907]
===
match
---
name: ti [22758,22760]
name: ti [23049,23051]
===
match
---
trailer [11823,11827]
trailer [11837,11841]
===
match
---
name: State [25284,25289]
name: State [25575,25580]
===
match
---
atom_expr [18579,18651]
atom_expr [18593,18665]
===
match
---
tfpdef [28048,28077]
tfpdef [28339,28368]
===
match
---
trailer [18869,18878]
trailer [19160,19169]
===
match
---
trailer [12388,12390]
trailer [12402,12404]
===
match
---
simple_stmt [10147,10205]
simple_stmt [10161,10219]
===
match
---
trailer [25781,25789]
trailer [26072,26080]
===
match
---
name: RUNNING [6918,6925]
name: RUNNING [6932,6939]
===
match
---
name: self [16650,16654]
name: self [16664,16668]
===
match
---
simple_stmt [10712,10771]
simple_stmt [10726,10785]
===
match
---
trailer [9716,9731]
trailer [9730,9745]
===
match
---
atom_expr [17038,17057]
atom_expr [17052,17071]
===
match
---
simple_stmt [3503,3750]
simple_stmt [3517,3764]
===
match
---
expr_stmt [14500,14530]
expr_stmt [14514,14544]
===
match
---
name: state [11604,11609]
name: state [11618,11623]
===
match
---
operator: == [11094,11096]
operator: == [11108,11110]
===
match
---
string: """         This is a helper method to emit the true scheduling delay stats, which is defined as         the time when the first task in DAG starts minus the expected DAG run datetime.         This method will be used in the update_state method when the state of the DagRun         is updated to a completed status (either success or failure). The method will find the first         started task within the DAG and calculate the expected DagRun start time (based on         dag.execution_date & dag.schedule_interval), and minus these two values to get the delay.         The emitted data may contains outlier (e.g. when the first task was cleared, so         the second task's start_date will be used), but we can get rid of the the outliers         on the stats side through the dashboards tooling built.         Note, the stat will only be emitted if the DagRun is a scheduler triggered one         (i.e. external_trigger is False).         """ [21353,22300]
string: """         This is a helper method to emit the true scheduling delay stats, which is defined as         the time when the first task in DAG starts minus the expected DAG run datetime.         This method will be used in the update_state method when the state of the DagRun         is updated to a completed status (either success or failure). The method will find the first         started task within the DAG and calculate the expected DagRun start time (based on         dag.execution_date & dag.schedule_interval), and minus these two values to get the delay.         The emitted data may contains outlier (e.g. when the first task was cleared, so         the second task's start_date will be used), but we can get rid of the the outliers         on the stats side through the dashboards tooling built.         Note, the stat will only be emitted if the DagRun is a scheduler triggered one         (i.e. external_trigger is False).         """ [21644,22591]
===
match
---
atom_expr [16589,16637]
atom_expr [16603,16651]
===
match
---
trailer [18709,18711]
trailer [18744,18746]
===
match
---
operator: == [27925,27927]
operator: == [28216,28218]
===
match
---
name: execution_date [10670,10684]
name: execution_date [10684,10698]
===
match
---
name: run_id [5014,5020]
name: run_id [5028,5034]
===
match
---
name: session [27037,27044]
name: session [27328,27335]
===
match
---
trailer [4901,4908]
trailer [4915,4922]
===
match
---
name: self [14634,14638]
name: self [14648,14652]
===
match
---
decorated [18280,19467]
decorated [18294,19758]
===
match
---
operator: , [20647,20648]
operator: , [20938,20939]
===
match
---
name: ti [25978,25980]
name: ti [26269,26271]
===
match
---
trailer [10166,10181]
trailer [10180,10195]
===
match
---
name: self [15876,15880]
name: self [15890,15894]
===
match
---
expr_stmt [19879,19899]
expr_stmt [20170,20190]
===
match
---
trailer [5185,5192]
trailer [5199,5206]
===
match
---
expr_stmt [18473,18570]
expr_stmt [18487,18584]
===
match
---
name: session [1250,1257]
name: session [1250,1257]
===
match
---
simple_stmt [29117,29155]
simple_stmt [29408,29446]
===
match
---
return_stmt [10560,10604]
return_stmt [10574,10618]
===
match
---
name: backref [1199,1206]
name: backref [1199,1206]
===
match
---
name: execution_date [7321,7335]
name: execution_date [7335,7349]
===
match
---
trailer [11857,11861]
trailer [11871,11875]
===
match
---
suite [23435,23533]
suite [23726,23824]
===
match
---
name: true_delay [23404,23414]
name: true_delay [23695,23705]
===
match
---
name: run_id [9597,9603]
name: run_id [9611,9617]
===
match
---
param [3924,3929]
param [3938,3943]
===
match
---
trailer [3025,3029]
trailer [3039,3043]
===
match
---
name: info [14953,14957]
name: info [14967,14971]
===
match
---
name: self [15384,15388]
name: self [15398,15402]
===
match
---
atom_expr [18687,18694]
atom_expr [18722,18729]
===
match
---
string: """Returns the latest DagRun for each DAG""" [27533,27577]
string: """Returns the latest DagRun for each DAG""" [27824,27868]
===
match
---
name: Optional [13252,13260]
name: Optional [13266,13274]
===
match
---
atom_expr [30163,30174]
atom_expr [30454,30465]
===
match
---
string: 'dag_id_state' [3286,3300]
string: 'dag_id_state' [3300,3314]
===
match
---
comparison [22312,22339]
comparison [22603,22630]
===
match
---
operator: , [18634,18635]
operator: , [18648,18649]
===
match
---
name: isinstance [9427,9437]
name: isinstance [9441,9451]
===
match
---
trailer [26455,26457]
trailer [26746,26748]
===
match
---
dictorsetmaker [30000,30178]
dictorsetmaker [30291,30469]
===
match
---
trailer [7093,7201]
trailer [7107,7215]
===
match
---
atom_expr [14856,14872]
atom_expr [14870,14886]
===
match
---
name: task_ids [25797,25805]
name: task_ids [26088,26096]
===
match
---
argument [16770,16786]
argument [16784,16800]
===
match
---
name: st [20119,20121]
name: st [20410,20412]
===
match
---
name: self [13469,13473]
name: self [13483,13487]
===
match
---
name: airflow [1515,1522]
name: airflow [1529,1536]
===
match
---
argument [17510,17523]
argument [17524,17537]
===
match
---
decorator [27429,27442]
decorator [27720,27733]
===
match
---
name: Column [3012,3018]
name: Column [3026,3032]
===
match
---
name: in_ [29892,29895]
name: in_ [30183,30186]
===
match
---
name: or_ [11597,11600]
name: or_ [11611,11614]
===
match
---
atom_expr [25200,25213]
atom_expr [25491,25504]
===
match
---
name: dag [16181,16184]
name: dag [16195,16198]
===
match
---
name: State [23847,23852]
name: State [24138,24143]
===
match
---
name: BACKFILL_JOB [27411,27423]
name: BACKFILL_JOB [27702,27714]
===
match
---
atom_expr [20346,20388]
atom_expr [20637,20679]
===
match
---
name: none_depends_on_past [17250,17270]
name: none_depends_on_past [17264,17284]
===
match
---
simple_stmt [1879,1970]
simple_stmt [1893,1984]
===
match
---
simple_stmt [18817,18880]
simple_stmt [19108,19171]
===
match
---
operator: { [4577,4578]
operator: { [4591,4592]
===
match
---
name: is_active [7167,7176]
name: is_active [7181,7190]
===
match
---
param [13218,13223]
param [13232,13237]
===
match
---
atom_expr [15109,15132]
atom_expr [15123,15146]
===
match
---
name: success [17510,17517]
name: success [17524,17531]
===
match
---
if_stmt [10465,10551]
if_stmt [10479,10565]
===
match
---
name: TI [12255,12257]
name: TI [12269,12271]
===
match
---
name: utils [1785,1790]
name: utils [1799,1804]
===
match
---
simple_stmt [1303,1358]
simple_stmt [1303,1358]
===
match
---
arglist [2974,2995]
arglist [2988,3009]
===
match
---
trailer [11968,11972]
trailer [11982,11986]
===
match
---
name: filter [10245,10251]
name: filter [10259,10265]
===
match
---
name: run_type [7945,7953]
name: run_type [7959,7967]
===
match
---
fstring_expr [25489,25501]
fstring_expr [25780,25792]
===
match
---
simple_stmt [26106,26130]
simple_stmt [26397,26421]
===
match
---
atom_expr [25859,25873]
atom_expr [26150,26164]
===
match
---
name: ready_tis [19776,19785]
name: ready_tis [20067,20076]
===
match
---
name: self [4969,4973]
name: self [4983,4987]
===
match
---
name: Optional [4167,4175]
name: Optional [4181,4189]
===
match
---
name: state [5162,5167]
name: state [5176,5181]
===
match
---
trailer [20118,20122]
trailer [20409,20413]
===
match
---
string: '<DagRun {dag_id} @ {execution_date}: {run_id}, externally triggered: {external_trigger}>' [4801,4891]
string: '<DagRun {dag_id} @ {execution_date}: {run_id}, externally triggered: {external_trigger}>' [4815,4905]
===
match
---
operator: = [29170,29171]
operator: = [29461,29462]
===
match
---
operator: } [25500,25501]
operator: } [25791,25792]
===
match
---
arglist [7003,7059]
arglist [7017,7073]
===
match
---
name: task [15021,15025]
name: task [15035,15039]
===
match
---
name: error [17346,17351]
name: error [17360,17365]
===
match
---
name: RUNNING [2861,2868]
name: RUNNING [2875,2882]
===
match
---
simple_stmt [3755,3897]
simple_stmt [3769,3911]
===
match
---
trailer [27044,27050]
trailer [27335,27341]
===
match
---
atom_expr [25718,25734]
atom_expr [26009,26025]
===
match
---
name: logging_mixin [1795,1808]
name: logging_mixin [1809,1822]
===
match
---
trailer [26155,26276]
trailer [26446,26567]
===
match
---
operator: = [17896,17897]
operator: = [17910,17911]
===
match
---
name: airflow [2079,2086]
name: airflow [2093,2100]
===
match
---
suite [5364,5451]
suite [5378,5465]
===
match
---
comparison [12880,12908]
comparison [12894,12922]
===
match
---
atom_expr [24419,24433]
atom_expr [24710,24724]
===
match
---
atom_expr [20579,20587]
atom_expr [20870,20878]
===
match
---
name: qry [9501,9504]
name: qry [9515,9518]
===
match
---
simple_stmt [17405,17434]
simple_stmt [17419,17448]
===
match
---
sync_comp_for [18764,18807]
sync_comp_for [19055,19098]
===
match
---
simple_stmt [22487,22508]
simple_stmt [22778,22799]
===
match
---
atom_expr [5434,5448]
atom_expr [5448,5462]
===
match
---
trailer [5957,5964]
trailer [5971,5978]
===
match
---
name: session [7566,7573]
name: session [7580,7587]
===
match
---
expr_stmt [9495,9535]
expr_stmt [9509,9549]
===
match
---
trailer [20583,20587]
trailer [20874,20878]
===
match
---
atom_expr [2754,2769]
atom_expr [2768,2783]
===
match
---
expr_stmt [11580,11651]
expr_stmt [11594,11665]
===
match
---
trailer [12330,12345]
trailer [12344,12359]
===
match
---
import_from [1303,1357]
import_from [1303,1357]
===
match
---
sync_comp_for [15780,15803]
sync_comp_for [15794,15817]
===
match
---
name: dag_id [14639,14645]
name: dag_id [14653,14659]
===
match
---
trailer [10333,10340]
trailer [10347,10354]
===
match
---
atom_expr [18484,18569]
atom_expr [18498,18583]
===
match
---
name: conf [4562,4566]
name: conf [4576,4580]
===
match
---
sync_comp_for [15540,15559]
sync_comp_for [15554,15573]
===
match
---
trailer [23741,23749]
trailer [24032,24040]
===
match
---
trailer [3018,3046]
trailer [3032,3060]
===
match
---
name: self [5968,5972]
name: self [5982,5986]
===
match
---
trailer [24648,24652]
trailer [24939,24943]
===
match
---
name: DagRun [13034,13040]
name: DagRun [13048,13054]
===
match
---
dotted_name [1124,1150]
dotted_name [1124,1150]
===
match
---
atom [29974,30200]
atom [30265,30491]
===
match
---
name: merge [18221,18226]
name: merge [18235,18240]
===
match
---
atom_expr [4244,4257]
atom_expr [4258,4271]
===
match
---
trailer [2319,2323]
trailer [2333,2337]
===
match
---
or_test [4569,4579]
or_test [4583,4593]
===
match
---
trailer [6902,6908]
trailer [6916,6922]
===
match
---
name: log [15823,15826]
name: log [15837,15840]
===
match
---
operator: = [7756,7757]
operator: = [7770,7771]
===
match
---
name: between [9944,9951]
name: between [9958,9965]
===
match
---
sync_comp_for [15584,15628]
sync_comp_for [15598,15642]
===
match
---
trailer [27513,27523]
trailer [27804,27814]
===
match
---
trailer [18426,18430]
trailer [18440,18444]
===
match
---
atom_expr [22558,22584]
atom_expr [22849,22875]
===
match
---
name: Index [976,981]
name: Index [976,981]
===
match
---
name: get_dag [24424,24431]
name: get_dag [24715,24722]
===
match
---
name: info [14770,14774]
name: info [14784,14788]
===
match
---
trailer [7796,7806]
trailer [7810,7820]
===
match
---
atom_expr [29117,29154]
atom_expr [29408,29445]
===
match
---
name: external_trigger [4112,4128]
name: external_trigger [4126,4142]
===
match
---
trailer [4973,4988]
trailer [4987,5002]
===
match
---
name: timezone [14513,14521]
name: timezone [14527,14535]
===
match
---
name: ti [18664,18666]
name: ti [18678,18680]
===
match
---
trailer [10579,10598]
trailer [10593,10612]
===
match
---
name: Union [901,906]
name: Union [901,906]
===
match
---
expr_stmt [3202,3231]
expr_stmt [3216,3245]
===
match
---
name: self [18579,18583]
name: self [18593,18597]
===
match
---
name: Optional [26553,26561]
name: Optional [26844,26852]
===
match
---
name: airflow_conf [1345,1357]
name: airflow_conf [1345,1357]
===
match
---
operator: , [27271,27272]
operator: , [27562,27563]
===
match
---
name: qry [10421,10424]
name: qry [10435,10438]
===
match
---
name: DagRun [13452,13458]
name: DagRun [13466,13472]
===
match
---
suite [27524,27999]
suite [27815,28290]
===
match
---
simple_stmt [4557,4580]
simple_stmt [4571,4594]
===
match
---
name: session [6151,6158]
name: session [6165,6172]
===
match
---
atom_expr [23914,23925]
atom_expr [24205,24216]
===
match
---
operator: = [16220,16221]
operator: = [16234,16235]
===
match
---
trailer [7051,7058]
trailer [7065,7072]
===
match
---
operator: , [3889,3890]
operator: , [3903,3904]
===
match
---
trailer [11803,11838]
trailer [11817,11852]
===
match
---
trailer [6898,6967]
trailer [6912,6981]
===
match
---
name: DepContext [20933,20943]
name: DepContext [21224,21234]
===
match
---
name: DR [5687,5689]
name: DR [5701,5703]
===
match
---
suite [19866,20188]
suite [20157,20479]
===
match
---
name: schedule_tis [28029,28041]
name: schedule_tis [28320,28332]
===
match
---
trailer [6045,6048]
trailer [6059,6062]
===
match
---
operator: = [19395,19396]
operator: = [19686,19687]
===
match
---
suite [19635,20510]
suite [19926,20801]
===
match
---
name: sqlalchemy [1235,1245]
name: sqlalchemy [1235,1245]
===
match
---
param [24103,24108]
param [24394,24399]
===
match
---
name: in_ [9522,9525]
name: in_ [9536,9539]
===
match
---
operator: , [3824,3825]
operator: , [3838,3839]
===
match
---
operator: = [13346,13347]
operator: = [13360,13361]
===
match
---
trailer [13400,13406]
trailer [13414,13420]
===
match
---
return_stmt [27016,27317]
return_stmt [27307,27608]
===
match
---
argument [4922,4940]
argument [4936,4954]
===
match
---
expr_stmt [17635,17938]
expr_stmt [17649,17952]
===
match
---
atom_expr [25633,25655]
atom_expr [25924,25946]
===
match
---
name: scheduleable_tasks [19737,19755]
name: scheduleable_tasks [20028,20046]
===
match
---
name: dr [6043,6045]
name: dr [6057,6059]
===
match
---
name: query [6868,6873]
name: query [6882,6887]
===
match
---
atom_expr [27868,27954]
atom_expr [28159,28245]
===
match
---
simple_stmt [22902,22961]
simple_stmt [23193,23252]
===
match
---
arglist [3019,3045]
arglist [3033,3059]
===
match
---
atom_expr [7577,7605]
atom_expr [7591,7619]
===
match
---
trailer [26009,26013]
trailer [26300,26304]
===
match
---
name: default [2847,2854]
name: default [2861,2868]
===
match
---
trailer [16602,16637]
trailer [16616,16651]
===
match
---
suite [29670,30281]
suite [29961,30572]
===
match
---
parameters [5496,5527]
parameters [5510,5541]
===
match
---
string: 'execution_date' [27672,27688]
string: 'execution_date' [27963,27979]
===
match
---
trailer [16184,16192]
trailer [16198,16206]
===
match
---
atom_expr [12727,12740]
atom_expr [12741,12754]
===
match
---
operator: , [20036,20037]
operator: , [20327,20328]
===
match
---
trailer [16733,16749]
trailer [16747,16763]
===
match
---
name: self [4765,4769]
name: self [4779,4783]
===
match
---
atom_expr [17590,17617]
atom_expr [17604,17631]
===
match
---
name: Optional [7830,7838]
name: Optional [7844,7852]
===
match
---
name: ti [22787,22789]
name: ti [23078,23080]
===
match
---
fstring_start: f' [23593,23595]
fstring_start: f' [23884,23886]
===
match
---
name: _are_premature_tis [20519,20537]
name: _are_premature_tis [20810,20828]
===
match
---
tfpdef [26524,26548]
tfpdef [26815,26839]
===
match
---
arglist [18594,18650]
arglist [18608,18664]
===
match
---
name: ready_tis [20487,20496]
name: ready_tis [20778,20787]
===
match
---
atom_expr [12576,12638]
atom_expr [12590,12652]
===
match
---
name: ti [29143,29145]
name: ti [29434,29436]
===
match
---
name: get_task_instances [10860,10878]
name: get_task_instances [10874,10892]
===
match
---
simple_stmt [23763,23770]
simple_stmt [24054,24061]
===
match
---
import_as_name [1491,1509]
import_as_name [1505,1523]
===
match
---
operator: = [2724,2725]
operator: = [2738,2739]
===
match
---
name: execution_date [27939,27953]
name: execution_date [28230,28244]
===
match
---
operator: , [981,982]
operator: , [981,982]
===
match
---
name: self [5434,5438]
name: self [5448,5452]
===
match
---
name: with_row_locks [7497,7511]
name: with_row_locks [7511,7525]
===
match
---
name: declarative [1139,1150]
name: declarative [1139,1150]
===
match
---
atom [29227,29563]
atom [29518,29854]
===
match
---
operator: = [20061,20062]
operator: = [20352,20353]
===
match
---
name: finished_tasks [20597,20611]
name: finished_tasks [20888,20902]
===
match
---
atom_expr [18780,18787]
atom_expr [19071,19078]
===
match
---
operator: = [3998,3999]
operator: = [4012,4013]
===
match
---
operator: , [27635,27636]
operator: , [27926,27927]
===
match
---
number: 0 [23433,23434]
number: 0 [23724,23725]
===
match
---
operator: = [7718,7719]
operator: = [7732,7733]
===
match
---
comparison [10511,10549]
comparison [10525,10563]
===
match
---
name: flag_upstream_failed [19979,19999]
name: flag_upstream_failed [20270,20290]
===
match
---
arglist [4922,5073]
arglist [4936,5087]
===
match
---
operator: = [7928,7929]
operator: = [7942,7943]
===
match
---
expr_stmt [11515,11555]
expr_stmt [11529,11569]
===
match
---
trailer [19623,19627]
trailer [19914,19918]
===
match
---
suite [24705,24754]
suite [24996,25045]
===
match
---
name: dag [22563,22566]
name: dag [22854,22857]
===
match
---
name: String [2835,2841]
name: String [2849,2855]
===
match
---
trailer [10244,10251]
trailer [10258,10265]
===
match
---
arglist [19956,20070]
arglist [20247,20361]
===
match
---
dotted_name [1515,1531]
dotted_name [1529,1545]
===
match
---
name: self [19021,19025]
name: self [19312,19316]
===
match
---
name: Column [3178,3184]
name: Column [3192,3198]
===
match
---
expr_stmt [2227,2240]
expr_stmt [2241,2254]
===
match
---
trailer [9511,9535]
trailer [9525,9549]
===
match
---
atom_expr [3520,3749]
atom_expr [3534,3763]
===
match
---
operator: = [19713,19714]
operator: = [20004,20005]
===
match
---
fstring_start: f" [10786,10788]
fstring_start: f" [10800,10802]
===
match
---
testlist_comp [22758,22800]
testlist_comp [23049,23091]
===
match
---
operator: @ [10610,10611]
operator: @ [10624,10625]
===
match
---
name: execution_date [5899,5913]
name: execution_date [5913,5927]
===
match
---
atom_expr [22787,22800]
atom_expr [23078,23091]
===
match
---
name: run_type [6931,6939]
name: run_type [6945,6953]
===
match
---
name: Optional [7878,7886]
name: Optional [7892,7900]
===
match
---
name: str [9446,9449]
name: str [9460,9463]
===
match
---
operator: = [21034,21035]
operator: = [21325,21326]
===
match
---
atom_expr [29495,29503]
atom_expr [29786,29794]
===
match
---
param [5497,5502]
param [5511,5516]
===
match
---
name: session [21181,21188]
name: session [21472,21479]
===
match
---
name: int [4340,4343]
name: int [4354,4357]
===
match
---
argument [17023,17057]
argument [17037,17071]
===
match
---
atom_expr [24742,24752]
atom_expr [25033,25043]
===
match
---
name: dag_id [4922,4928]
name: dag_id [4936,4942]
===
match
---
name: query [29718,29723]
name: query [30009,30014]
===
match
---
name: Stats [25455,25460]
name: Stats [25746,25751]
===
match
---
param [19552,19577]
param [19843,19868]
===
match
---
simple_stmt [25113,25169]
simple_stmt [25404,25460]
===
match
---
name: execution_date [25918,25932]
name: execution_date [26209,26223]
===
match
---
name: TI [12347,12349]
name: TI [12361,12363]
===
match
---
operator: , [7899,7900]
operator: , [7913,7914]
===
match
---
name: self [11051,11055]
name: self [11065,11069]
===
match
---
atom_expr [11854,11863]
atom_expr [11868,11877]
===
match
---
name: taskinstance [1471,1483]
name: taskinstance [1485,1497]
===
match
---
atom_expr [6043,6048]
atom_expr [6057,6062]
===
match
---
testlist_comp [18552,18567]
testlist_comp [18566,18581]
===
match
---
operator: , [25432,25433]
operator: , [25723,25724]
===
match
---
name: state [24813,24818]
name: state [25104,25109]
===
match
---
trailer [29430,29450]
trailer [29721,29741]
===
match
---
name: declared_attr [5330,5343]
name: declared_attr [5344,5357]
===
match
---
name: get_previous_scheduled_dagrun [13188,13217]
name: get_previous_scheduled_dagrun [13202,13231]
===
match
---
trailer [2973,2996]
trailer [2987,3010]
===
match
---
operator: , [3490,3491]
operator: , [3504,3505]
===
match
---
name: state [12720,12725]
name: state [12734,12739]
===
match
---
atom_expr [20168,20174]
atom_expr [20459,20465]
===
match
---
trailer [29717,29723]
trailer [30008,30014]
===
match
---
atom_expr [2262,2270]
atom_expr [2276,2284]
===
match
---
name: models [1464,1470]
name: models [1478,1484]
===
match
---
comparison [25672,25709]
comparison [25963,26000]
===
match
---
operator: , [3371,3372]
operator: , [3385,3386]
===
match
---
simple_stmt [17635,17939]
simple_stmt [17649,17953]
===
match
---
operator: @ [27323,27324]
operator: @ [27614,27615]
===
match
---
trailer [8142,8152]
trailer [8156,8166]
===
match
---
name: execution_date [16254,16268]
name: execution_date [16268,16282]
===
match
---
operator: = [7429,7430]
operator: = [7443,7444]
===
match
---
arith_expr [23790,23821]
arith_expr [24081,24112]
===
match
---
trailer [6917,6925]
trailer [6931,6939]
===
match
---
comparison [12922,12965]
comparison [12936,12979]
===
match
---
name: session [21189,21196]
name: session [21480,21487]
===
match
---
argument [16513,16574]
argument [16527,16588]
===
match
---
simple_stmt [18075,18149]
simple_stmt [18089,18163]
===
match
---
operator: == [29318,29320]
operator: == [29609,29611]
===
match
---
fstring_expr [23478,23490]
fstring_expr [23769,23781]
===
match
---
operator: == [5965,5967]
operator: == [5979,5981]
===
match
---
operator: , [16192,16193]
operator: , [16206,16207]
===
match
---
name: state [4593,4598]
name: state [4607,4612]
===
match
---
name: dag_id [9416,9422]
name: dag_id [9430,9436]
===
match
---
name: TISchedulingDecision [2117,2137]
name: TISchedulingDecision [2131,2151]
===
match
---
name: provide_session [10836,10851]
name: provide_session [10850,10865]
===
match
---
name: and_ [27868,27872]
name: and_ [28159,28163]
===
match
---
name: execution_date [23369,23383]
name: execution_date [23660,23674]
===
match
---
trailer [27801,27806]
trailer [28092,28097]
===
match
---
name: session [18346,18353]
name: session [18360,18367]
===
match
---
name: DepContext [1639,1649]
name: DepContext [1653,1663]
===
match
---
name: ti [25084,25086]
name: ti [25375,25377]
===
match
---
atom_expr [2967,2996]
atom_expr [2981,3010]
===
match
---
name: State [18051,18056]
name: State [18065,18070]
===
match
---
trailer [12592,12638]
trailer [12606,12652]
===
match
---
operator: <= [10182,10184]
operator: <= [10196,10198]
===
match
---
atom_expr [17806,17825]
atom_expr [17820,17839]
===
match
---
name: self [16221,16225]
name: self [16235,16239]
===
match
---
name: Optional [7686,7694]
name: Optional [7700,7708]
===
match
---
name: session [16788,16795]
name: session [16802,16809]
===
match
---
name: cls [6747,6750]
name: cls [6761,6764]
===
match
---
trailer [23810,23821]
trailer [24101,24112]
===
match
---
funcdef [18301,19467]
funcdef [18315,19758]
===
match
---
operator: @ [26463,26464]
operator: @ [26754,26755]
===
match
---
name: info [14695,14699]
name: info [14709,14713]
===
match
---
name: filter [9505,9511]
name: filter [9519,9525]
===
match
---
operator: { [10788,10789]
operator: { [10802,10803]
===
match
---
parameters [12713,12773]
parameters [12727,12787]
===
match
---
name: datetime [7797,7805]
name: datetime [7811,7819]
===
match
---
param [4234,4265]
param [4248,4279]
===
match
---
simple_stmt [28761,28779]
simple_stmt [29052,29070]
===
match
---
name: end_date [5252,5260]
name: end_date [5266,5274]
===
match
---
atom [28808,28810]
atom [29099,29101]
===
match
---
string: 'run_id' [3408,3416]
string: 'run_id' [3422,3430]
===
match
---
name: DR [9804,9806]
name: DR [9818,9820]
===
match
---
operator: , [20551,20552]
operator: , [20842,20843]
===
match
---
param [13664,13669]
param [13678,13683]
===
match
---
trailer [25007,25011]
trailer [25298,25302]
===
match
---
operator: = [17037,17038]
operator: = [17051,17052]
===
match
---
import_as_names [1438,1450]
import_as_names [1452,1464]
===
match
---
atom_expr [29840,29859]
atom_expr [30131,30150]
===
match
---
trailer [24035,24042]
trailer [24326,24333]
===
match
---
name: List [8138,8142]
name: List [8152,8156]
===
match
---
expr_stmt [9909,9994]
expr_stmt [9923,10008]
===
match
---
suite [24790,25214]
suite [25081,25505]
===
match
---
name: self [25003,25007]
name: self [25294,25298]
===
match
---
arglist [9438,9449]
arglist [9452,9463]
===
match
---
trailer [6072,6078]
trailer [6086,6092]
===
match
---
operator: , [12965,12966]
operator: , [12979,12980]
===
match
---
operator: @ [7639,7640]
operator: @ [7653,7654]
===
match
---
not_test [16484,16504]
not_test [16498,16518]
===
match
---
trailer [5724,5729]
trailer [5738,5743]
===
match
---
name: unfinished_tasks [15150,15166]
name: unfinished_tasks [15164,15180]
===
match
---
name: _state [5220,5226]
name: _state [5234,5240]
===
match
---
name: should_restore_task [25313,25332]
name: should_restore_task [25604,25623]
===
match
---
param [11912,11917]
param [11926,11931]
===
match
---
atom [27023,27317]
atom [27314,27608]
===
match
---
atom_expr [11051,11062]
atom_expr [11065,11076]
===
match
---
parameters [5155,5168]
parameters [5169,5182]
===
match
---
param [13224,13247]
param [13238,13261]
===
match
---
number: 1 [25880,25881]
number: 1 [26171,26172]
===
match
---
operator: , [27119,27120]
operator: , [27410,27411]
===
match
---
trailer [20370,20382]
trailer [20661,20673]
===
match
---
name: execution_date [9825,9839]
name: execution_date [9839,9853]
===
match
---
name: self [24419,24423]
name: self [24710,24714]
===
match
---
name: dag_id [3584,3590]
name: dag_id [3598,3604]
===
match
---
trailer [11827,11836]
trailer [11841,11850]
===
match
---
trailer [15388,15407]
trailer [15402,15421]
===
match
---
operator: , [19145,19146]
operator: , [19436,19437]
===
match
---
atom_expr [23847,23860]
atom_expr [24138,24151]
===
match
---
tfpdef [19586,19602]
tfpdef [19877,19893]
===
match
---
classdef [2355,30303]
classdef [2369,30594]
===
match
---
name: filter [29745,29751]
name: filter [30036,30042]
===
match
---
simple_stmt [11428,11465]
simple_stmt [11442,11479]
===
match
---
suite [9896,9995]
suite [9910,10009]
===
match
---
trailer [25833,25882]
trailer [26124,26173]
===
match
---
decorated [7621,10605]
decorated [7635,10619]
===
match
---
simple_stmt [27016,27318]
simple_stmt [27307,27609]
===
match
---
arglist [29494,29548]
arglist [29785,29839]
===
match
---
name: append [29064,29070]
name: append [29355,29361]
===
match
---
trailer [2934,2943]
trailer [2948,2957]
===
match
---
suite [22596,22716]
suite [22887,23007]
===
match
---
import_from [1772,1828]
import_from [1786,1842]
===
match
---
operator: , [30137,30138]
operator: , [30428,30429]
===
match
---
name: TI [3571,3573]
name: TI [3585,3587]
===
match
---
atom_expr [16109,16393]
atom_expr [16123,16407]
===
match
---
trailer [18056,18064]
trailer [18070,18078]
===
match
---
suite [21344,23655]
suite [21635,23946]
===
match
---
atom_expr [8047,8065]
atom_expr [8061,8079]
===
match
---
operator: = [13241,13242]
operator: = [13255,13256]
===
match
---
parameters [3914,4358]
parameters [3928,4372]
===
match
---
name: _emit_true_scheduling_delay_stats_for_finished_state [18080,18132]
name: _emit_true_scheduling_delay_stats_for_finished_state [18094,18146]
===
match
---
atom_expr [23952,23962]
atom_expr [24243,24253]
===
match
---
operator: , [28077,28078]
operator: , [28368,28369]
===
match
---
argument [22845,22873]
argument [23136,23164]
===
match
---
name: self [5418,5422]
name: self [5432,5436]
===
match
---
name: session [24109,24116]
name: session [24400,24407]
===
match
---
simple_stmt [22814,22890]
simple_stmt [23105,23181]
===
match
---
name: set_state [16655,16664]
name: set_state [16669,16678]
===
match
---
trailer [9713,9752]
trailer [9727,9766]
===
match
---
comparison [12305,12345]
comparison [12319,12359]
===
match
---
operator: , [5020,5021]
operator: , [5034,5035]
===
match
---
trailer [27671,27689]
trailer [27962,27980]
===
match
---
simple_stmt [10994,11128]
simple_stmt [11008,11142]
===
match
---
atom_expr [7525,7548]
atom_expr [7539,7562]
===
match
---
name: self [4615,4619]
name: self [4629,4633]
===
match
---
operator: , [3628,3629]
operator: , [3642,3643]
===
match
---
trailer [6867,6873]
trailer [6881,6887]
===
match
---
name: none_depends_on_past [14988,15008]
name: none_depends_on_past [15002,15022]
===
match
---
trailer [27649,27664]
trailer [27940,27955]
===
match
---
operator: = [10998,10999]
operator: = [11012,11013]
===
match
---
atom_expr [10421,10456]
atom_expr [10435,10470]
===
match
---
name: dag_hash [4274,4282]
name: dag_hash [4288,4296]
===
match
---
name: session [24472,24479]
name: session [24763,24770]
===
match
---
atom_expr [13252,13270]
atom_expr [13266,13284]
===
match
---
comparison [5844,5868]
comparison [5858,5882]
===
match
---
name: dag_id [13459,13465]
name: dag_id [13473,13479]
===
match
---
trailer [2236,2240]
trailer [2250,2254]
===
match
---
trailer [11055,11062]
trailer [11069,11076]
===
match
---
tfpdef [7823,7843]
tfpdef [7837,7857]
===
match
---
name: all [11373,11376]
name: all [11387,11390]
===
match
---
parameters [10878,10910]
parameters [10892,10924]
===
match
---
name: state [11231,11236]
name: state [11245,11250]
===
match
---
name: t [15145,15146]
name: t [15159,15160]
===
match
---
atom_expr [20442,20448]
atom_expr [20733,20739]
===
match
---
name: state [11714,11719]
name: state [11728,11733]
===
match
---
arglist [27842,27955]
arglist [28133,28246]
===
match
---
name: execution_date [9929,9943]
name: execution_date [9943,9957]
===
match
---
fstring_string: dagrun.duration.success. [23889,23913]
fstring_string: dagrun.duration.success. [24180,24204]
===
match
---
atom_expr [12241,12390]
atom_expr [12255,12404]
===
match
---
trailer [4592,4598]
trailer [4606,4612]
===
match
---
atom_expr [29375,29394]
atom_expr [29666,29685]
===
match
---
operator: , [8127,8128]
operator: , [8141,8142]
===
match
---
atom_expr [10241,10270]
atom_expr [10255,10284]
===
match
---
trailer [28881,28886]
trailer [29172,29177]
===
match
---
trailer [11101,11116]
trailer [11115,11130]
===
match
---
name: dag_id [12887,12893]
name: dag_id [12901,12907]
===
match
---
trailer [6061,6067]
trailer [6075,6081]
===
match
---
name: old_states [20268,20278]
name: old_states [20559,20569]
===
match
---
trailer [17593,17617]
trailer [17607,17631]
===
match
---
trailer [18781,18787]
trailer [19072,19078]
===
match
---
atom_expr [4426,4445]
atom_expr [4440,4459]
===
match
---
import_from [1970,2007]
import_from [1984,2021]
===
match
---
operator: @ [24061,24062]
operator: @ [24352,24353]
===
match
---
atom_expr [22860,22873]
atom_expr [23151,23164]
===
match
---
name: finished_tasks [20021,20035]
name: finished_tasks [20312,20326]
===
match
---
name: utcnow [14522,14528]
name: utcnow [14536,14542]
===
match
---
trailer [17341,17345]
trailer [17355,17359]
===
match
---
tfpdef [7860,7892]
tfpdef [7874,7906]
===
match
---
trailer [18796,18807]
trailer [19087,19098]
===
match
---
name: run_type [4234,4242]
name: run_type [4248,4256]
===
match
---
operator: -> [10911,10913]
operator: -> [10925,10927]
===
match
---
trailer [15115,15132]
trailer [15129,15146]
===
match
---
trailer [16749,16804]
trailer [16763,16818]
===
match
---
trailer [30109,30118]
trailer [30400,30409]
===
match
---
simple_stmt [18687,18733]
simple_stmt [18722,18768]
===
match
---
operator: = [7893,7894]
operator: = [7907,7908]
===
match
---
expr_stmt [4426,4462]
expr_stmt [4440,4476]
===
match
---
name: Integer [2935,2942]
name: Integer [2949,2956]
===
match
---
parameters [18339,18370]
parameters [18353,18384]
===
match
---
name: TI [12305,12307]
name: TI [12319,12321]
===
match
---
atom_expr [23806,23821]
atom_expr [24097,24112]
===
match
---
fstring_start: f' [24005,24007]
fstring_start: f' [24296,24298]
===
match
---
atom_expr [11700,11731]
atom_expr [11714,11745]
===
match
---
trailer [13593,13599]
trailer [13607,13613]
===
match
---
name: utcnow [30129,30135]
name: utcnow [30420,30426]
===
match
---
fstring [25466,25502]
fstring [25757,25793]
===
match
---
operator: = [27499,27500]
operator: = [27790,27791]
===
match
---
trailer [13141,13146]
trailer [13155,13160]
===
match
---
fstring_string: dagrun.dependency-check. [14609,14633]
fstring_string: dagrun.dependency-check. [14623,14647]
===
match
---
name: is_ [11454,11457]
name: is_ [11468,11471]
===
match
---
name: task [25859,25863]
name: task [26150,26154]
===
match
---
comparison [10164,10203]
comparison [10178,10217]
===
match
---
operator: , [19365,19366]
operator: , [19656,19657]
===
match
---
sync_comp_for [15042,15067]
sync_comp_for [15056,15081]
===
match
---
expr_stmt [14427,14490]
expr_stmt [14441,14504]
===
match
---
name: st [19915,19917]
name: st [20206,20208]
===
match
---
name: orm [1188,1191]
name: orm [1188,1191]
===
match
---
name: self [11097,11101]
name: self [11111,11115]
===
match
---
operator: = [2551,2552]
operator: = [2565,2566]
===
match
---
name: bool [7923,7927]
name: bool [7937,7941]
===
match
---
suite [11255,11732]
suite [11269,11746]
===
match
---
trailer [9803,9840]
trailer [9817,9854]
===
match
---
simple_stmt [19021,19118]
simple_stmt [19312,19409]
===
match
---
name: cls [27906,27909]
name: cls [28197,28200]
===
match
---
atom_expr [11373,11402]
atom_expr [11387,11416]
===
match
---
trailer [4085,4095]
trailer [4099,4109]
===
match
---
name: State [29505,29510]
name: State [29796,29801]
===
match
---
operator: , [10883,10884]
operator: , [10897,10898]
===
match
---
arglist [2733,2769]
arglist [2747,2783]
===
match
---
trailer [26146,26150]
trailer [26437,26441]
===
match
---
comparison [11377,11386]
comparison [11391,11400]
===
match
---
simple_stmt [6033,6049]
simple_stmt [6047,6063]
===
match
---
atom_expr [26225,26235]
atom_expr [26516,26526]
===
match
---
trailer [14638,14645]
trailer [14652,14659]
===
match
---
name: Any [4176,4179]
name: Any [4190,4193]
===
match
---
name: dag_id [27717,27723]
name: dag_id [28008,28014]
===
match
---
suite [11673,11732]
suite [11687,11746]
===
match
---
comparison [23833,23860]
comparison [24124,24151]
===
match
---
name: TI [13746,13748]
name: TI [13760,13762]
===
match
---
name: dag [12660,12663]
name: dag [12674,12677]
===
match
---
arglist [27096,27272]
arglist [27387,27563]
===
match
---
simple_stmt [25455,25510]
simple_stmt [25746,25801]
===
match
---
for_stmt [25621,26014]
for_stmt [25912,26305]
===
match
---
atom_expr [10341,10360]
atom_expr [10355,10374]
===
match
---
name: self [5358,5362]
name: self [5372,5376]
===
match
---
name: property [5409,5417]
name: property [5423,5431]
===
match
---
trailer [26228,26235]
trailer [26519,26526]
===
match
---
fstring_end: ' [26261,26262]
fstring_end: ' [26552,26553]
===
match
---
name: self [4426,4430]
name: self [4440,4444]
===
match
---
name: self [12946,12950]
name: self [12960,12964]
===
match
---
trailer [9731,9735]
trailer [9745,9749]
===
match
---
simple_stmt [19130,19226]
simple_stmt [19421,19517]
===
match
---
atom_expr [13393,13601]
atom_expr [13407,13615]
===
match
---
name: cls [7553,7556]
name: cls [7567,7570]
===
match
---
name: ID_LEN [1438,1444]
name: ID_LEN [1452,1458]
===
match
---
operator: , [3674,3675]
operator: , [3688,3689]
===
match
---
name: dag_id [29776,29782]
name: dag_id [30067,30073]
===
match
---
simple_stmt [3202,3232]
simple_stmt [3216,3246]
===
match
---
name: Column [2928,2934]
name: Column [2942,2948]
===
match
---
comparison [22558,22595]
comparison [22849,22886]
===
match
---
trailer [20418,20470]
trailer [20709,20761]
===
match
---
simple_stmt [28120,28594]
simple_stmt [28411,28885]
===
match
---
atom_expr [17646,17938]
atom_expr [17660,17952]
===
match
---
simple_stmt [7490,7616]
simple_stmt [7504,7630]
===
match
---
name: callback [16098,16106]
name: callback [16112,16120]
===
match
---
name: State [17420,17425]
name: State [17434,17439]
===
match
---
if_stmt [15711,18066]
if_stmt [15725,18080]
===
match
---
name: TI [11038,11040]
name: TI [11052,11054]
===
match
---
name: FAILED [23972,23978]
name: FAILED [24263,24269]
===
match
---
name: self [25350,25354]
name: self [25641,25645]
===
match
---
trailer [15603,15611]
trailer [15617,15625]
===
match
---
name: TI [29773,29775]
name: TI [30064,30066]
===
match
---
name: dag_id [11041,11047]
name: dag_id [11055,11061]
===
match
---
name: changed_tis [19342,19353]
name: changed_tis [19633,19644]
===
match
---
name: last_scheduling_decision [7257,7281]
name: last_scheduling_decision [7271,7295]
===
match
---
comparison [7029,7058]
comparison [7043,7072]
===
match
---
name: query [7423,7428]
name: query [7437,7442]
===
match
---
name: first_start_date [23322,23338]
name: first_start_date [23613,23629]
===
match
---
name: provide_session [12670,12685]
name: provide_session [12684,12699]
===
match
---
argument [20921,21163]
argument [21212,21454]
===
match
---
operator: , [25875,25876]
operator: , [26166,26167]
===
match
---
operator: = [14511,14512]
operator: = [14525,14526]
===
match
---
trailer [19025,19029]
trailer [19316,19320]
===
match
---
arglist [2671,2707]
arglist [2685,2721]
===
match
---
comparison [12988,13005]
comparison [13002,13019]
===
match
---
name: state [19894,19899]
name: state [20185,20190]
===
match
---
name: task_instance_scheduling_decisions [18305,18339]
name: task_instance_scheduling_decisions [18319,18353]
===
match
---
testlist_comp [18943,19007]
testlist_comp [19234,19298]
===
match
---
suite [16576,17159]
suite [16590,17173]
===
match
---
name: session [27492,27499]
name: session [27783,27790]
===
match
---
name: qry [10330,10333]
name: qry [10344,10347]
===
match
---
name: fileloc [17722,17729]
name: fileloc [17736,17743]
===
match
---
name: qry [10153,10156]
name: qry [10167,10170]
===
match
---
name: task_id [29419,29426]
name: task_id [29710,29717]
===
match
---
name: filter [9797,9803]
name: filter [9811,9817]
===
match
---
name: dag_id [2611,2617]
name: dag_id [2625,2631]
===
match
---
name: UtcDateTime [2733,2744]
name: UtcDateTime [2747,2758]
===
match
---
operator: @ [11869,11870]
operator: @ [11883,11884]
===
match
---
simple_stmt [25752,25761]
simple_stmt [26043,26052]
===
match
---
atom_expr [27383,27396]
atom_expr [27674,27687]
===
match
---
fstring_expr [10788,10798]
fstring_expr [10802,10812]
===
match
---
trailer [13745,13749]
trailer [13759,13763]
===
match
---
if_stmt [5178,5324]
if_stmt [5192,5338]
===
match
---
name: _state [5130,5136]
name: _state [5144,5150]
===
match
---
atom_expr [11076,11093]
atom_expr [11090,11107]
===
match
---
trailer [4339,4344]
trailer [4353,4358]
===
match
---
atom_expr [11819,11836]
atom_expr [11833,11850]
===
match
---
expr_stmt [28761,28778]
expr_stmt [29052,29069]
===
match
---
atom_expr [18479,18570]
atom_expr [18493,18584]
===
match
---
tfpdef [7909,7927]
tfpdef [7923,7941]
===
match
---
atom_expr [18422,18430]
atom_expr [18436,18444]
===
match
---
expr_stmt [25189,25213]
expr_stmt [25480,25504]
===
match
---
atom [11532,11555]
atom [11546,11569]
===
match
---
trailer [26005,26009]
trailer [26296,26300]
===
match
---
if_stmt [25310,25548]
if_stmt [25601,25839]
===
match
---
name: dag [14662,14665]
name: dag [14676,14679]
===
match
---
name: filter_for_tis [20253,20267]
name: filter_for_tis [20544,20558]
===
match
---
argument [2589,2605]
argument [2603,2619]
===
match
---
name: TI [18427,18429]
name: TI [18441,18443]
===
match
---
atom_expr [13019,13056]
atom_expr [13033,13070]
===
match
---
trailer [5802,5806]
trailer [5816,5820]
===
match
---
param [24109,24132]
param [24400,24423]
===
match
---
name: state [12988,12993]
name: state [13002,13007]
===
match
---
trailer [12349,12357]
trailer [12363,12371]
===
match
---
trailer [13155,13157]
trailer [13169,13171]
===
match
---
name: self [5730,5734]
name: self [5744,5748]
===
match
---
atom_expr [25189,25197]
atom_expr [25480,25488]
===
match
---
trailer [15742,15804]
trailer [15756,15818]
===
match
---
atom_expr [20613,20621]
atom_expr [20904,20912]
===
match
---
name: unfinished_tasks [15408,15424]
name: unfinished_tasks [15422,15438]
===
match
---
trailer [17351,17392]
trailer [17365,17406]
===
match
---
suite [26572,27318]
suite [26863,27609]
===
match
---
trailer [23344,23363]
trailer [23635,23654]
===
match
---
atom_expr [7377,7409]
atom_expr [7391,7423]
===
match
---
atom_expr [25823,25882]
atom_expr [26114,26173]
===
match
---
atom_expr [17484,17572]
atom_expr [17498,17586]
===
match
---
name: desc [13142,13146]
name: desc [13156,13160]
===
match
---
atom_expr [19161,19225]
atom_expr [19452,19516]
===
match
---
operator: = [3211,3212]
operator: = [3225,3226]
===
match
---
argument [7283,7298]
argument [7297,7312]
===
match
---
name: log [23581,23584]
name: log [23872,23875]
===
match
---
simple_stmt [10324,10382]
simple_stmt [10338,10396]
===
match
---
name: ut [20841,20843]
name: ut [21132,21134]
===
match
---
atom [18433,18435]
atom [18447,18449]
===
match
---
simple_stmt [29051,29083]
simple_stmt [29342,29374]
===
match
---
comp_op [12994,13000]
comp_op [13008,13014]
===
match
---
name: str [7711,7714]
name: str [7725,7728]
===
match
---
trailer [3184,3197]
trailer [3198,3211]
===
match
---
atom_expr [29710,30266]
atom_expr [30001,30557]
===
match
---
funcdef [7660,10605]
funcdef [7674,10619]
===
match
---
operator: = [19999,20000]
operator: = [20290,20291]
===
match
---
comp_op [25255,25261]
comp_op [25546,25552]
===
match
---
except_clause [24766,24789]
except_clause [25057,25080]
===
match
---
name: Session [6160,6167]
name: Session [6174,6181]
===
match
---
simple_stmt [25998,26014]
simple_stmt [26289,26305]
===
match
---
expr_stmt [9373,9396]
expr_stmt [9387,9410]
===
match
---
name: dag [2094,2097]
name: dag [2108,2111]
===
match
---
simple_stmt [2874,2906]
simple_stmt [2888,2920]
===
match
---
decorator [26463,26477]
decorator [26754,26768]
===
match
---
name: TI [11601,11603]
name: TI [11615,11617]
===
match
---
name: bool [2288,2292]
name: bool [2302,2306]
===
match
---
name: execution_end_date [9974,9992]
name: execution_end_date [9988,10006]
===
match
---
expr_stmt [14662,14682]
expr_stmt [14676,14696]
===
match
---
trailer [18040,18050]
trailer [18054,18064]
===
match
---
name: DagRunType [2040,2050]
name: DagRunType [2054,2064]
===
match
---
name: filter [20364,20370]
name: filter [20655,20661]
===
match
---
trailer [7180,7186]
trailer [7194,7200]
===
match
---
simple_stmt [4397,4418]
simple_stmt [4411,4432]
===
match
---
suite [18674,18733]
suite [18705,18768]
===
match
---
operator: = [3268,3269]
operator: = [3282,3283]
===
match
---
name: session [9379,9386]
name: session [9393,9400]
===
match
---
name: Optional [4244,4252]
name: Optional [4258,4266]
===
match
---
tfpdef [19514,19542]
tfpdef [19805,19833]
===
match
---
name: self [16990,16994]
name: self [17004,17008]
===
match
---
trailer [29073,29081]
trailer [29364,29372]
===
match
---
trailer [28942,28947]
trailer [29233,29238]
===
match
---
operator: = [4096,4097]
operator: = [4110,4111]
===
match
---
trailer [16914,17158]
trailer [16928,17172]
===
match
---
operator: -> [28104,28106]
operator: -> [28395,28397]
===
match
---
return_stmt [30290,30302]
return_stmt [30581,30593]
===
match
---
operator: , [7762,7763]
operator: , [7776,7777]
===
match
---
operator: = [10904,10905]
operator: = [10918,10919]
===
match
---
name: Optional [7742,7750]
name: Optional [7756,7764]
===
match
---
name: State [2855,2860]
name: State [2869,2874]
===
match
---
trailer [13360,13362]
trailer [13374,13376]
===
match
---
simple_stmt [5215,5235]
simple_stmt [5229,5249]
===
match
---
operator: } [25159,25160]
operator: } [25450,25451]
===
match
---
and_test [15184,15251]
and_test [15198,15265]
===
match
---
operator: , [19215,19216]
operator: , [19506,19507]
===
match
---
fstring_end: " [14646,14647]
fstring_end: " [14660,14661]
===
match
---
suite [13006,13057]
suite [13020,13071]
===
match
---
name: List [19679,19683]
name: List [19970,19974]
===
match
---
atom_expr [11744,11752]
atom_expr [11758,11766]
===
match
---
name: st [20168,20170]
name: st [20459,20461]
===
match
---
name: inherits_from_dummy_operator [28887,28915]
name: inherits_from_dummy_operator [29178,29206]
===
match
---
name: airflow [1308,1315]
name: airflow [1308,1315]
===
match
---
name: REMOVED [24828,24835]
name: REMOVED [25119,25126]
===
match
---
name: dag_id [27629,27635]
name: dag_id [27920,27926]
===
match
---
atom_expr [27928,27953]
atom_expr [28219,28244]
===
match
---
parameters [19490,19609]
parameters [19781,19900]
===
match
---
trailer [20882,20903]
trailer [21173,21194]
===
match
---
testlist_comp [15581,15628]
testlist_comp [15595,15642]
===
match
---
import_from [6650,6689]
import_from [6664,6703]
===
match
---
string: 'Marking run %s successful' [16603,16630]
string: 'Marking run %s successful' [16617,16644]
===
match
---
atom_expr [12292,12303]
atom_expr [12306,12317]
===
match
---
if_stmt [15181,15504]
if_stmt [15195,15518]
===
match
---
operator: , [870,871]
operator: , [870,871]
===
match
---
operator: = [13719,13720]
operator: = [13733,13734]
===
match
---
if_stmt [25774,26014]
if_stmt [26065,26305]
===
match
---
name: qry [10042,10045]
name: qry [10056,10059]
===
match
---
operator: == [24819,24821]
operator: == [25110,25112]
===
match
---
trailer [9796,9803]
trailer [9810,9817]
===
match
---
name: dag [23479,23482]
name: dag [23770,23773]
===
match
---
atom_expr [2835,2845]
atom_expr [2849,2859]
===
match
---
string: 'all_tasks_deadlocked' [17897,17919]
string: 'all_tasks_deadlocked' [17911,17933]
===
match
---
name: refresh_from_db [5481,5496]
name: refresh_from_db [5495,5510]
===
match
---
trailer [7530,7536]
trailer [7544,7550]
===
match
---
dotted_name [1777,1808]
dotted_name [1791,1822]
===
match
---
trailer [19572,19576]
trailer [19863,19867]
===
match
---
trailer [18557,18566]
trailer [18571,18580]
===
match
---
name: stats [1580,1585]
name: stats [1594,1599]
===
match
---
operator: , [10668,10669]
operator: , [10682,10683]
===
match
---
trailer [13119,13149]
trailer [13133,13163]
===
match
---
trailer [23852,23860]
trailer [24143,24151]
===
match
---
name: conf [3051,3055]
name: conf [3065,3069]
===
match
---
atom_expr [12305,12322]
atom_expr [12319,12336]
===
match
---
name: task_instance_mutation_hook [24596,24623]
name: task_instance_mutation_hook [24887,24914]
===
match
---
name: dependencies_states [1671,1690]
name: dependencies_states [1685,1704]
===
match
---
expr_stmt [24544,24560]
expr_stmt [24835,24851]
===
match
---
simple_stmt [4471,4500]
simple_stmt [4485,4514]
===
match
---
name: tis [19280,19283]
name: tis [19571,19574]
===
match
---
trailer [25460,25465]
trailer [25751,25756]
===
match
---
name: state [11634,11639]
name: state [11648,11653]
===
match
---
annassign [19677,19692]
annassign [19968,19983]
===
match
---
name: TI [19624,19626]
name: TI [19915,19917]
===
match
---
string: """         Set the given task instances in to the scheduled state.          Each element of ``schedulable_tis`` should have it's ``task`` attribute already set.          Any DummyOperator without callbacks is instead set straight to the success state.          All the TIs should belong to this DagRun, but this code is in the hot-path, this is not checked -- it         is the caller's responsibility to call this function only with TIs from a single dag run.         """ [28120,28593]
string: """         Set the given task instances in to the scheduled state.          Each element of ``schedulable_tis`` should have it's ``task`` attribute already set.          Any DummyOperator without callbacks is instead set straight to the success state.          All the TIs should belong to this DagRun, but this code is in the hot-path, this is not checked -- it         is the caller's responsibility to call this function only with TIs from a single dag run.         """ [28411,28884]
===
match
---
name: task_id [15532,15539]
name: task_id [15546,15553]
===
match
---
atom_expr [23833,23843]
atom_expr [24124,24134]
===
match
---
operator: , [21039,21040]
operator: , [21330,21331]
===
match
---
name: airflow [6655,6662]
name: airflow [6669,6676]
===
match
---
operator: , [26522,26523]
operator: , [26813,26814]
===
match
---
trailer [11765,11773]
trailer [11779,11787]
===
match
---
trailer [19096,19116]
trailer [19387,19407]
===
match
---
name: REMOVED [25290,25297]
name: REMOVED [25581,25588]
===
match
---
name: str [7701,7704]
name: str [7715,7718]
===
match
---
simple_stmt [10494,10551]
simple_stmt [10508,10565]
===
match
---
atom [18942,19008]
atom [19233,19299]
===
match
---
simple_stmt [10560,10605]
simple_stmt [10574,10619]
===
match
---
operator: { [25858,25859]
operator: { [26149,26150]
===
match
---
name: session [29245,29252]
name: session [29536,29543]
===
match
---
name: str [11927,11930]
name: str [11941,11944]
===
match
---
name: SUCCESS [16671,16678]
name: SUCCESS [16685,16692]
===
match
---
name: dag [15549,15552]
name: dag [15563,15566]
===
match
---
fstring_expr [23649,23652]
fstring_expr [23940,23943]
===
match
---
name: tis [18773,18776]
name: tis [19064,19067]
===
match
---
atom_expr [27713,27723]
atom_expr [28004,28014]
===
match
---
argument [5398,5449]
argument [5412,5463]
===
match
---
param [7772,7814]
param [7786,7828]
===
match
---
trailer [13526,13544]
trailer [13540,13558]
===
match
---
atom_expr [29071,29081]
atom_expr [29362,29372]
===
match
---
if_stmt [22521,22716]
if_stmt [22812,23007]
===
match
---
trailer [4735,4744]
trailer [4749,4758]
===
match
---
operator: , [21144,21145]
operator: , [21435,21436]
===
match
---
name: self [4508,4512]
name: self [4522,4526]
===
match
---
simple_stmt [24722,24754]
simple_stmt [25013,25045]
===
match
---
comparison [5181,5201]
comparison [5195,5215]
===
match
---
simple_stmt [2775,2806]
simple_stmt [2789,2820]
===
match
---
not_test [22424,22440]
not_test [22715,22731]
===
match
---
atom_expr [29773,29782]
atom_expr [30064,30073]
===
match
---
name: session [7992,7999]
name: session [8006,8013]
===
match
---
trailer [6980,6985]
trailer [6994,6999]
===
match
---
trailer [29891,29895]
trailer [30182,30186]
===
match
---
name: list [18479,18483]
name: list [18493,18497]
===
match
---
name: self [24103,24107]
name: self [24394,24398]
===
match
---
name: TI [11445,11447]
name: TI [11459,11461]
===
match
---
number: 32 [3227,3229]
number: 32 [3241,3243]
===
match
---
name: bool [19629,19633]
name: bool [19920,19924]
===
match
---
operator: , [26509,26510]
operator: , [26800,26801]
===
match
---
name: state [25529,25534]
name: state [25820,25825]
===
match
---
trailer [11806,11814]
trailer [11820,11828]
===
match
---
trailer [19262,19466]
trailer [19553,19757]
===
match
---
trailer [2670,2708]
trailer [2684,2722]
===
match
---
decorator [27446,27463]
decorator [27737,27754]
===
match
---
trailer [20252,20267]
trailer [20543,20558]
===
match
---
import_from [1077,1118]
import_from [1077,1118]
===
match
---
atom_expr [2627,2641]
atom_expr [2641,2655]
===
match
---
trailer [25694,25709]
trailer [25985,26000]
===
match
---
trailer [17503,17572]
trailer [17517,17586]
===
match
---
name: DR [5955,5957]
name: DR [5969,5971]
===
match
---
name: add [24649,24652]
name: add [24940,24943]
===
match
---
trailer [17762,17769]
trailer [17776,17783]
===
match
---
trailer [17487,17503]
trailer [17501,17517]
===
match
---
atom_expr [7955,7975]
atom_expr [7969,7989]
===
match
---
name: task_ids [24640,24648]
name: task_ids [24931,24939]
===
match
---
name: dag_id [3574,3580]
name: dag_id [3588,3594]
===
match
---
operator: , [16232,16233]
operator: , [16246,16247]
===
match
---
name: self [12655,12659]
name: self [12669,12673]
===
match
---
string: "number of scheduleable tasks for %s: %s task(s)" [19036,19085]
string: "number of scheduleable tasks for %s: %s task(s)" [19327,19376]
===
match
---
atom_expr [24448,24488]
atom_expr [24739,24779]
===
match
---
name: TISchedulingDecision [19242,19262]
name: TISchedulingDecision [19533,19553]
===
match
---
name: warning [23585,23592]
name: warning [23876,23883]
===
match
---
name: staticmethod [26464,26476]
name: staticmethod [26755,26767]
===
match
---
name: finished_tasks [15426,15440]
name: finished_tasks [15440,15454]
===
match
---
trailer [9386,9392]
trailer [9400,9406]
===
match
---
name: err [26124,26127]
name: err [26415,26418]
===
match
---
name: all [10599,10602]
name: all [10613,10616]
===
match
---
trailer [27410,27423]
trailer [27701,27714]
===
match
---
name: _get_ready_tis [19476,19490]
name: _get_ready_tis [19767,19781]
===
match
---
name: x [11391,11392]
name: x [11405,11406]
===
match
---
subscriptlist [13741,13797]
subscriptlist [13755,13811]
===
match
---
atom [22757,22801]
atom [23048,23092]
===
match
---
name: has_on_failure_callback [16057,16080]
name: has_on_failure_callback [16071,16094]
===
match
---
trailer [29279,29286]
trailer [29570,29577]
===
match
---
operator: = [4181,4182]
operator: = [4195,4196]
===
match
---
trailer [18161,18201]
trailer [18175,18215]
===
match
---
trailer [24973,24981]
trailer [25264,25272]
===
match
---
operator: } [30199,30200]
operator: } [30490,30491]
===
match
---
if_stmt [11370,11652]
if_stmt [11384,11666]
===
match
---
trailer [25354,25358]
trailer [25645,25649]
===
match
---
atom_expr [23992,24055]
atom_expr [24283,24346]
===
match
---
argument [17126,17139]
argument [17140,17153]
===
match
---
trailer [4292,4297]
trailer [4306,4311]
===
match
---
expr_stmt [24442,24488]
expr_stmt [24733,24779]
===
match
---
atom_expr [14595,14648]
atom_expr [14609,14662]
===
match
---
param [12418,12422]
param [12432,12436]
===
match
---
name: dag [13342,13345]
name: dag [13356,13359]
===
match
---
trailer [26114,26119]
trailer [26405,26410]
===
match
---
atom_expr [16053,16080]
atom_expr [16067,16094]
===
match
---
trailer [20111,20118]
trailer [20402,20409]
===
match
---
name: changed_tis [14861,14872]
name: changed_tis [14875,14886]
===
match
---
expr_stmt [5687,5698]
expr_stmt [5701,5712]
===
match
---
tfpdef [4197,4217]
tfpdef [4211,4231]
===
match
---
trailer [5271,5278]
trailer [5285,5292]
===
match
---
trailer [18583,18587]
trailer [18597,18601]
===
match
---
name: is_backfill [25723,25734]
name: is_backfill [26014,26025]
===
match
---
name: dag_id [16214,16220]
name: dag_id [16228,16234]
===
match
---
param [28042,28047]
param [28333,28338]
===
match
---
name: st [19891,19893]
name: st [20182,20184]
===
match
---
decorator [5456,5473]
decorator [5470,5487]
===
match
---
trailer [12281,12288]
trailer [12295,12302]
===
match
---
trailer [11609,11613]
trailer [11623,11627]
===
match
---
operator: , [17104,17105]
operator: , [17118,17119]
===
match
---
name: task [18690,18694]
name: task [18725,18729]
===
match
---
name: self [23833,23837]
name: self [24124,24128]
===
match
---
operator: , [29450,29451]
operator: , [29741,29742]
===
match
---
atom_expr [16181,16192]
atom_expr [16195,16206]
===
match
---
name: self [4368,4372]
name: self [4382,4386]
===
match
---
expr_stmt [25526,25547]
expr_stmt [25817,25838]
===
match
---
atom_expr [2819,2869]
atom_expr [2833,2883]
===
match
---
name: BACKFILL_JOB [6954,6966]
name: BACKFILL_JOB [6968,6980]
===
match
---
atom_expr [27906,27924]
atom_expr [28197,28215]
===
match
---
trailer [13093,13100]
trailer [13107,13114]
===
match
---
name: start_date [2713,2723]
name: start_date [2727,2737]
===
match
---
name: task_instance_mutation_hook [1539,1566]
name: task_instance_mutation_hook [1553,1580]
===
match
---
atom_expr [2890,2904]
atom_expr [2904,2918]
===
match
---
name: TI [19539,19541]
name: TI [19830,19832]
===
match
---
simple_stmt [25350,25439]
simple_stmt [25641,25730]
===
match
---
operator: } [15559,15560]
operator: } [15573,15574]
===
match
---
atom_expr [2928,2943]
atom_expr [2942,2957]
===
match
---
arglist [7525,7605]
arglist [7539,7619]
===
match
---
trailer [27050,27058]
trailer [27341,27349]
===
match
---
name: execution_date [4014,4028]
name: execution_date [4028,4042]
===
match
---
name: TI [1507,1509]
name: TI [1521,1523]
===
match
---
name: Optional [11960,11968]
name: Optional [11974,11982]
===
match
---
operator: = [5261,5262]
operator: = [5275,5276]
===
match
---
name: ut [18976,18978]
name: ut [19267,19269]
===
match
---
name: t [18835,18836]
name: t [19126,19127]
===
match
---
name: verify_integrity [24086,24102]
name: verify_integrity [24377,24393]
===
match
---
comparison [12347,12368]
comparison [12361,12382]
===
match
---
name: _state [2810,2816]
name: _state [2824,2830]
===
match
---
name: Index [3427,3432]
name: Index [3441,3446]
===
match
---
name: state [15751,15756]
name: state [15765,15770]
===
match
---
name: old_states [20157,20167]
name: old_states [20448,20458]
===
match
---
trailer [13473,13480]
trailer [13487,13494]
===
match
---
name: state [18855,18860]
name: state [19146,19151]
===
match
---
name: start_dttm [14500,14510]
name: start_dttm [14514,14524]
===
match
---
testlist_comp [18762,18807]
testlist_comp [19053,19098]
===
match
---
param [5503,5526]
param [5517,5540]
===
match
---
operator: = [18363,18364]
operator: = [18377,18378]
===
match
---
name: TI [2267,2269]
name: TI [2281,2283]
===
match
---
operator: = [24126,24127]
operator: = [24417,24418]
===
match
---
suite [22340,22360]
suite [22631,22651]
===
match
---
name: tis [11208,11211]
name: tis [11222,11225]
===
match
---
try_stmt [26023,26458]
try_stmt [26314,26749]
===
match
---
trailer [24741,24753]
trailer [25032,25044]
===
match
---
funcdef [26481,27318]
funcdef [26772,27609]
===
match
---
name: sqlalchemy [1898,1908]
name: sqlalchemy [1912,1922]
===
match
---
operator: = [19889,19890]
operator: = [20180,20181]
===
match
---
trailer [2889,2905]
trailer [2903,2919]
===
match
---
trailer [25722,25734]
trailer [26013,26025]
===
match
---
expr_stmt [18921,19008]
expr_stmt [19212,19299]
===
match
---
trailer [13149,13155]
trailer [13163,13169]
===
match
---
trailer [24744,24752]
trailer [25035,25043]
===
match
---
simple_stmt [14842,14873]
simple_stmt [14856,14887]
===
match
---
arglist [25124,25167]
arglist [25415,25458]
===
match
---
trailer [27665,27671]
trailer [27956,27962]
===
match
---
trailer [28994,28999]
trailer [29285,29290]
===
match
---
name: following_schedule [23345,23363]
name: following_schedule [23636,23654]
===
match
---
simple_stmt [9405,9463]
simple_stmt [9419,9477]
===
match
---
decorator [13617,13634]
decorator [13631,13648]
===
match
---
trailer [18593,18651]
trailer [18607,18665]
===
match
---
for_stmt [20837,21241]
for_stmt [21128,21532]
===
match
---
trailer [5013,5020]
trailer [5027,5034]
===
match
---
comparison [27873,27904]
comparison [28164,28195]
===
match
---
name: TYPE_CHECKING [2055,2068]
name: TYPE_CHECKING [2069,2082]
===
match
---
and_test [25249,25297]
and_test [25540,25588]
===
match
---
operator: = [14854,14855]
operator: = [14868,14869]
===
match
---
name: TI [29881,29883]
name: TI [30172,30174]
===
match
---
trailer [12928,12943]
trailer [12942,12957]
===
match
---
not_test [28936,28967]
not_test [29227,29258]
===
match
---
atom_expr [11162,11184]
atom_expr [11176,11198]
===
match
---
suite [24134,26458]
suite [24425,26749]
===
match
---
atom_expr [16513,16526]
atom_expr [16527,16540]
===
match
---
trailer [18132,18148]
trailer [18146,18162]
===
match
---
funcdef [10856,11864]
funcdef [10870,11878]
===
match
---
name: unfinished_tasks [15184,15200]
name: unfinished_tasks [15198,15214]
===
match
---
name: List [20613,20617]
name: List [20904,20908]
===
match
---
simple_stmt [14885,14922]
simple_stmt [14899,14936]
===
match
---
tfpdef [8082,8120]
tfpdef [8096,8134]
===
match
---
return_stmt [7490,7615]
return_stmt [7504,7629]
===
match
---
arglist [2826,2868]
arglist [2840,2882]
===
match
---
atom_expr [7878,7892]
atom_expr [7892,7906]
===
match
---
trailer [23414,23428]
trailer [23705,23719]
===
match
---
arglist [25907,25932]
arglist [26198,26223]
===
match
---
name: execution_start_date [9952,9972]
name: execution_start_date [9966,9986]
===
match
---
name: append [20112,20118]
name: append [20403,20409]
===
match
---
simple_stmt [2328,2353]
simple_stmt [2342,2367]
===
match
---
name: is_paused [7120,7129]
name: is_paused [7134,7143]
===
match
---
string: "dag_run" [2553,2562]
string: "dag_run" [2567,2576]
===
match
---
arglist [25364,25437]
arglist [25655,25728]
===
match
---
arglist [5418,5448]
arglist [5432,5462]
===
match
---
arglist [3286,3316]
arglist [3300,3330]
===
match
---
simple_stmt [18405,18436]
simple_stmt [18419,18450]
===
match
---
expr_stmt [13342,13362]
expr_stmt [13356,13376]
===
match
---
trailer [10922,10926]
trailer [10936,10940]
===
match
---
trailer [6930,6939]
trailer [6944,6953]
===
match
---
arglist [24005,24054]
arglist [24296,24345]
===
match
---
name: utils [1892,1897]
name: utils [1906,1911]
===
match
---
comparison [27096,27119]
comparison [27387,27410]
===
match
---
atom_expr [22528,22554]
atom_expr [22819,22845]
===
match
---
argument [19979,20004]
argument [20270,20295]
===
match
---
name: dag_id [29791,29797]
name: dag_id [30082,30088]
===
match
---
atom [27597,27758]
atom [27888,28049]
===
match
---
name: synonym [5380,5387]
name: synonym [5394,5401]
===
match
---
trailer [8055,8065]
trailer [8069,8079]
===
match
---
operator: , [7813,7814]
operator: , [7827,7828]
===
match
---
tfpdef [7734,7755]
tfpdef [7748,7769]
===
match
---
name: dag [26225,26228]
name: dag [26516,26519]
===
match
---
name: dag [15955,15958]
name: dag [15969,15972]
===
match
---
name: subquery [27842,27850]
name: subquery [28133,28141]
===
match
---
operator: , [30081,30082]
operator: , [30372,30373]
===
match
---
expr_stmt [4588,4606]
expr_stmt [4602,4620]
===
match
---
trailer [7963,7975]
trailer [7977,7989]
===
match
---
atom_expr [20102,20122]
atom_expr [20393,20413]
===
match
---
trailer [27746,27748]
trailer [28037,28039]
===
match
---
name: ti [24742,24744]
name: ti [25033,25035]
===
match
---
trailer [11633,11639]
trailer [11647,11653]
===
match
---
name: callback [16867,16875]
name: callback [16881,16889]
===
match
---
name: full_filepath [16167,16180]
name: full_filepath [16181,16194]
===
match
---
name: nulls_first [7241,7252]
name: nulls_first [7255,7266]
===
match
---
name: RUNNING [22332,22339]
name: RUNNING [22623,22630]
===
match
---
operator: , [7982,7983]
operator: , [7996,7997]
===
match
---
name: execute_callbacks [15920,15937]
name: execute_callbacks [15934,15951]
===
match
---
operator: , [20587,20588]
operator: , [20878,20879]
===
match
---
name: changed_tis [14842,14853]
name: changed_tis [14856,14867]
===
match
---
operator: = [7976,7977]
operator: = [7990,7991]
===
match
---
operator: , [6141,6142]
operator: , [6155,6156]
===
match
---
simple_stmt [6226,6642]
simple_stmt [6240,6656]
===
match
---
name: execution_date [25695,25709]
name: execution_date [25986,26000]
===
match
---
atom_expr [15530,15539]
atom_expr [15544,15553]
===
match
---
number: 50 [3026,3028]
number: 50 [3040,3042]
===
match
---
name: self [18697,18701]
name: self [18732,18736]
===
match
---
comp_if [18973,19007]
comp_if [19264,19298]
===
match
---
simple_stmt [10042,10102]
simple_stmt [10056,10116]
===
match
---
name: List [19568,19572]
name: List [19859,19863]
===
match
---
parameters [4764,4770]
parameters [4778,4784]
===
match
---
trailer [22844,22889]
trailer [23135,23180]
===
match
---
operator: = [11584,11585]
operator: = [11598,11599]
===
match
---
operator: = [21088,21089]
operator: = [21379,21380]
===
match
---
testlist_star_expr [19130,19158]
testlist_star_expr [19421,19449]
===
match
---
name: leaf_ti [15784,15791]
name: leaf_ti [15798,15805]
===
match
---
param [6151,6168]
param [6165,6182]
===
match
---
atom_expr [6070,6078]
atom_expr [6084,6092]
===
match
---
string: 'dag_id' [3344,3352]
string: 'dag_id' [3358,3366]
===
match
---
trailer [16512,16575]
trailer [16526,16589]
===
match
---
arglist [15975,16034]
arglist [15989,16048]
===
match
---
name: DagRun [12880,12886]
name: DagRun [12894,12900]
===
match
---
name: query [7431,7436]
name: query [7445,7450]
===
match
---
atom_expr [30010,30023]
atom_expr [30301,30314]
===
match
---
atom [4577,4579]
atom [4591,4593]
===
match
---
atom_expr [10164,10181]
atom_expr [10178,10195]
===
match
---
suite [4359,4747]
suite [4373,4761]
===
match
---
name: DagRunType [6943,6953]
name: DagRunType [6957,6967]
===
match
---
atom_expr [13034,13046]
atom_expr [13048,13060]
===
match
---
import_from [1650,1717]
import_from [1664,1731]
===
match
---
number: 1 [25166,25167]
number: 1 [25457,25458]
===
match
---
name: _emit_duration_stats_for_finished_state [23664,23703]
name: _emit_duration_stats_for_finished_state [23955,23994]
===
match
---
name: dag_id [7678,7684]
name: dag_id [7692,7698]
===
match
---
simple_stmt [21249,21262]
simple_stmt [21540,21553]
===
match
---
name: set_state [5439,5448]
name: set_state [5453,5462]
===
match
---
trailer [7252,7299]
trailer [7266,7313]
===
match
---
param [12714,12719]
param [12728,12733]
===
match
---
name: task_concurrency [15116,15132]
name: task_concurrency [15130,15146]
===
match
---
string: """Returns the task instances for this dag run""" [10936,10985]
string: """Returns the task instances for this dag run""" [10950,10999]
===
match
---
atom_expr [13469,13480]
atom_expr [13483,13494]
===
match
---
dotted_name [1834,1855]
dotted_name [1848,1869]
===
match
---
import_as_name [1337,1357]
import_as_name [1337,1357]
===
match
---
operator: , [5749,5750]
operator: , [5763,5764]
===
match
---
string: """The previous, SCHEDULED DagRun, if there is one""" [13280,13333]
string: """The previous, SCHEDULED DagRun, if there is one""" [13294,13347]
===
match
---
name: start_date [4065,4075]
name: start_date [4079,4089]
===
match
---
name: qry [10147,10150]
name: qry [10161,10164]
===
match
---
name: dag_id [3668,3674]
name: dag_id [3682,3688]
===
match
---
name: max_number [6177,6187]
name: max_number [6191,6201]
===
match
---
name: finished_tasks [2328,2342]
name: finished_tasks [2342,2356]
===
match
---
name: id [6038,6040]
name: id [6052,6054]
===
match
---
suite [20663,21262]
suite [20954,21553]
===
match
---
tfpdef [28079,28095]
tfpdef [28370,28386]
===
match
---
operator: @ [12669,12670]
operator: @ [12683,12684]
===
match
---
name: run_type [10393,10401]
name: run_type [10407,10415]
===
match
---
trailer [12278,12369]
trailer [12292,12383]
===
match
---
fstring [26222,26262]
fstring [26513,26553]
===
match
---
name: airflow [1834,1841]
name: airflow [1848,1855]
===
match
---
atom_expr [27137,27160]
atom_expr [27428,27451]
===
match
---
name: session [25560,25567]
name: session [25851,25858]
===
match
---
simple_stmt [16650,16680]
simple_stmt [16664,16694]
===
match
---
simple_stmt [11787,11839]
simple_stmt [11801,11853]
===
match
---
trailer [9657,9679]
trailer [9671,9693]
===
match
---
trailer [2348,2352]
trailer [2362,2366]
===
match
---
decorated [10835,11864]
decorated [10849,11878]
===
match
---
param [13670,13694]
param [13684,13708]
===
match
---
atom_expr [3220,3230]
atom_expr [3234,3244]
===
match
---
name: State [16530,16535]
name: State [16544,16549]
===
match
---
operator: = [11791,11792]
operator: = [11805,11806]
===
match
---
trailer [25917,25932]
trailer [26208,26223]
===
match
---
name: dag_id [12297,12303]
name: dag_id [12311,12317]
===
match
---
trailer [7588,7605]
trailer [7602,7619]
===
match
---
arglist [9658,9678]
arglist [9672,9692]
===
match
---
name: session [13670,13677]
name: session [13684,13691]
===
match
---
tfpdef [19552,19576]
tfpdef [19843,19867]
===
match
---
suite [27367,27424]
suite [27658,27715]
===
match
---
name: creating_job_id [4686,4701]
name: creating_job_id [4700,4715]
===
match
---
decorated [27323,27424]
decorated [27614,27715]
===
match
---
name: self [17038,17042]
name: self [17052,17056]
===
match
---
annassign [2260,2270]
annassign [2274,2284]
===
match
---
name: airflow [1572,1579]
name: airflow [1586,1593]
===
match
---
atom_expr [23404,23430]
atom_expr [23695,23721]
===
match
---
operator: = [19353,19354]
operator: = [19644,19645]
===
match
---
name: Session [28088,28095]
name: Session [28379,28386]
===
match
---
comparison [24810,24835]
comparison [25101,25126]
===
match
---
operator: , [19785,19786]
operator: , [20076,20077]
===
match
---
name: State [18791,18796]
name: State [19082,19087]
===
match
---
decorated [13163,13612]
decorated [13177,13626]
===
match
---
operator: = [16776,16777]
operator: = [16790,16791]
===
match
---
operator: , [2833,2834]
operator: , [2847,2848]
===
match
---
name: airflow [1655,1662]
name: airflow [1669,1676]
===
match
---
name: execution_date [12331,12345]
name: execution_date [12345,12359]
===
match
---
name: Column [2664,2670]
name: Column [2678,2684]
===
match
---
expr_stmt [4557,4579]
expr_stmt [4571,4593]
===
match
---
operator: = [4049,4050]
operator: = [4063,4064]
===
match
---
name: isoformat [10816,10825]
name: isoformat [10830,10839]
===
match
---
name: st [19841,19843]
name: st [20132,20134]
===
match
---
trailer [20359,20363]
trailer [20650,20654]
===
match
---
param [4765,4769]
param [4779,4783]
===
match
---
trailer [9586,9593]
trailer [9600,9607]
===
match
---
name: bool [13714,13718]
name: bool [13728,13732]
===
match
---
name: synonym [1222,1229]
name: synonym [1222,1229]
===
match
---
trailer [14680,14682]
trailer [14694,14696]
===
match
---
trailer [16895,16914]
trailer [16909,16928]
===
match
---
trailer [23368,23383]
trailer [23659,23674]
===
match
---
atom [28776,28778]
atom [29067,29069]
===
match
---
atom_expr [25690,25709]
atom_expr [25981,26000]
===
match
---
name: dag [11749,11752]
name: dag [11763,11766]
===
match
---
atom_expr [18642,18650]
atom_expr [18656,18664]
===
match
---
name: full_filepath [17704,17717]
name: full_filepath [17718,17731]
===
match
---
name: changed_tis [19354,19365]
name: changed_tis [19645,19656]
===
match
---
param [20561,20588]
param [20852,20879]
===
match
---
for_stmt [18660,18733]
for_stmt [18674,19024]
===
match
---
comp_if [15598,15628]
comp_if [15612,15642]
===
match
---
name: tis [18646,18649]
name: tis [18660,18663]
===
match
---
suite [29205,29564]
suite [29496,29855]
===
match
---
return_stmt [5118,5136]
return_stmt [5132,5150]
===
match
---
file_input [787,30303]
file_input [787,30594]
===
match
---
name: run_id [4402,4408]
name: run_id [4416,4422]
===
match
---
atom_expr [19568,19576]
atom_expr [19859,19867]
===
match
---
dotted_name [1604,1631]
dotted_name [1618,1645]
===
match
---
import_from [1567,1598]
import_from [1581,1612]
===
match
---
name: State [25200,25205]
name: State [25491,25496]
===
match
---
and_test [28879,29019]
and_test [29170,29310]
===
match
---
trailer [29486,29493]
trailer [29777,29784]
===
match
---
name: configuration [1316,1329]
name: configuration [1316,1329]
===
match
---
name: self [13664,13668]
name: self [13678,13682]
===
match
---
tfpdef [13670,13686]
tfpdef [13684,13700]
===
match
---
simple_stmt [2008,2051]
simple_stmt [2022,2065]
===
match
---
import_as_names [1916,1969]
import_as_names [1930,1983]
===
match
---
trailer [7886,7892]
trailer [7900,7906]
===
match
---
param [7992,8016]
param [8006,8030]
===
match
---
operator: = [4662,4663]
operator: = [4676,4677]
===
match
---
atom_expr [4969,4988]
atom_expr [4983,5002]
===
match
---
name: classmethod [27430,27441]
name: classmethod [27721,27732]
===
match
---
name: DR [9393,9395]
name: DR [9407,9409]
===
match
---
arglist [18508,18568]
arglist [18522,18582]
===
match
---
arglist [3398,3416]
arglist [3412,3430]
===
match
---
funcdef [27467,27999]
funcdef [27758,28290]
===
match
---
name: List [19534,19538]
name: List [19825,19829]
===
match
---
expr_stmt [15302,15503]
expr_stmt [15316,15517]
===
match
---
not_test [25714,25734]
not_test [26005,26025]
===
match
---
simple_stmt [27376,27424]
simple_stmt [27667,27715]
===
match
---
operator: = [12864,12865]
operator: = [12878,12879]
===
match
---
argument [19956,20036]
argument [20247,20327]
===
match
---
trailer [20386,20388]
trailer [20677,20679]
===
match
---
simple_stmt [13342,13363]
simple_stmt [13356,13377]
===
match
---
operator: , [4264,4265]
operator: , [4278,4279]
===
match
---
trailer [22505,22507]
trailer [22796,22798]
===
match
---
operator: , [3868,3869]
operator: , [3882,3883]
===
match
---
name: self [12615,12619]
name: self [12629,12633]
===
match
---
name: state [11724,11729]
name: state [11738,11743]
===
match
---
fstring_start: f' [23887,23889]
fstring_start: f' [24178,24180]
===
match
---
name: filter [27072,27078]
name: filter [27363,27369]
===
match
---
expr_stmt [24677,24688]
expr_stmt [24968,24979]
===
match
---
funcdef [5142,5324]
funcdef [5156,5338]
===
match
---
operator: } [23651,23652]
operator: } [23942,23943]
===
match
---
comparison [5284,5313]
comparison [5298,5327]
===
match
---
name: self [11757,11761]
name: self [11771,11775]
===
match
---
name: t [15544,15545]
name: t [15558,15559]
===
match
---
funcdef [10628,10830]
funcdef [10642,10844]
===
match
---
name: utils [1842,1847]
name: utils [1856,1861]
===
match
---
atom_expr [9501,9535]
atom_expr [9515,9549]
===
match
---
simple_stmt [6838,7361]
simple_stmt [6852,7375]
===
match
---
operator: , [9444,9445]
operator: , [9458,9459]
===
match
---
trailer [2579,2606]
trailer [2593,2620]
===
match
---
if_stmt [24807,25214]
if_stmt [25098,25505]
===
match
---
string: 'dag_id' [3398,3406]
string: 'dag_id' [3412,3420]
===
match
---
name: ignore_in_retry_period [21012,21034]
name: ignore_in_retry_period [21303,21325]
===
match
---
if_stmt [25669,25761]
if_stmt [25960,26052]
===
match
---
simple_stmt [16589,16638]
simple_stmt [16603,16652]
===
match
---
decorator [13163,13180]
decorator [13177,13194]
===
match
---
tfpdef [26493,26509]
tfpdef [26784,26800]
===
match
---
operator: = [17866,17867]
operator: = [17880,17881]
===
match
---
operator: = [10328,10329]
operator: = [10342,10343]
===
match
---
operator: = [8066,8067]
operator: = [8080,8081]
===
match
---
operator: = [5773,5774]
operator: = [5787,5788]
===
match
---
atom_expr [25904,25933]
atom_expr [26195,26224]
===
match
---
trailer [9514,9521]
trailer [9528,9535]
===
match
---
comp_op [10299,10305]
comp_op [10313,10319]
===
match
---
fstring_expr [23913,23926]
fstring_expr [24204,24217]
===
match
---
atom_expr [15011,15068]
atom_expr [15025,15082]
===
match
---
trailer [3573,3580]
trailer [3587,3594]
===
match
---
operator: @ [18280,18281]
operator: @ [18294,18295]
===
match
---
name: s [11539,11540]
name: s [11553,11554]
===
match
---
argument [22875,22888]
argument [23166,23179]
===
match
---
parameters [27352,27358]
parameters [27643,27649]
===
match
---
name: bool [27362,27366]
name: bool [27653,27657]
===
match
---
comparison [25250,25266]
comparison [25541,25557]
===
match
---
dotted_name [1411,1430]
dotted_name [1425,1444]
===
match
---
not_test [15714,15734]
not_test [15728,15748]
===
match
---
trailer [19978,20036]
trailer [20269,20327]
===
match
---
name: self [26142,26146]
name: self [26433,26437]
===
match
---
trailer [10570,10579]
trailer [10584,10593]
===
match
---
name: dag_id [9515,9521]
name: dag_id [9529,9535]
===
match
---
expr_stmt [23309,23384]
expr_stmt [23600,23675]
===
match
---
arglist [23887,23937]
arglist [24178,24228]
===
match
---
operator: , [5913,5914]
operator: , [5927,5928]
===
match
---
trailer [11596,11651]
trailer [11610,11665]
===
match
---
and_test [16484,16575]
and_test [16498,16589]
===
match
---
tfpdef [11918,11930]
tfpdef [11932,11944]
===
match
---
name: cls [27646,27649]
name: cls [27937,27940]
===
match
---
argument [18508,18523]
argument [18522,18537]
===
match
---
operator: { [14633,14634]
operator: { [14647,14648]
===
match
---
atom_expr [27232,27253]
atom_expr [27523,27544]
===
match
---
atom_expr [26120,26128]
atom_expr [26411,26419]
===
match
---
simple_stmt [21229,21241]
simple_stmt [21520,21532]
===
match
---
name: self [12418,12422]
name: self [12432,12436]
===
match
---
name: state [5352,5357]
name: state [5366,5371]
===
match
---
atom_expr [14953,14974]
atom_expr [14967,14988]
===
match
---
if_stmt [9471,9536]
if_stmt [9485,9550]
===
match
---
atom_expr [19968,20036]
atom_expr [20259,20327]
===
match
---
suite [11403,11465]
suite [11417,11479]
===
match
---
name: are_runnable_tasks [15302,15320]
name: are_runnable_tasks [15316,15334]
===
match
---
if_stmt [28858,29155]
if_stmt [29149,29446]
===
match
---
operator: == [9822,9824]
operator: == [9836,9838]
===
match
---
name: ID_LEN [2634,2640]
name: ID_LEN [2648,2654]
===
match
---
trailer [2732,2770]
trailer [2746,2784]
===
match
---
trailer [23971,23978]
trailer [24262,24269]
===
match
---
name: execution_start_date [10008,10028]
name: execution_start_date [10022,10042]
===
match
---
comparison [11335,11348]
comparison [11349,11362]
===
match
---
string: """         Return the next DagRuns that the scheduler should attempt to schedule.          This will return zero or more DagRun rows that are row-level-locked with a "SELECT ... FOR UPDATE"         query, you should ensure that any scheduling decisions are made in a single transaction -- as soon as         the transaction is committed it will be unlocked.          :rtype: list[airflow.models.DagRun]         """ [6226,6641]
string: """         Return the next DagRuns that the scheduler should attempt to schedule.          This will return zero or more DagRun rows that are row-level-locked with a "SELECT ... FOR UPDATE"         query, you should ensure that any scheduling decisions are made in a single transaction -- as soon as         the transaction is committed it will be unlocked.          :rtype: list[airflow.models.DagRun]         """ [6240,6655]
===
match
---
atom_expr [24653,24663]
atom_expr [24944,24954]
===
match
---
name: any [15739,15742]
name: any [15753,15756]
===
match
---
operator: { [19657,19658]
operator: { [19948,19949]
===
match
---
arglist [5896,5923]
arglist [5910,5937]
===
match
---
name: none_depends_on_past [15205,15225]
name: none_depends_on_past [15219,15239]
===
match
---
trailer [3803,3896]
trailer [3817,3910]
===
match
---
argument [17525,17554]
argument [17539,17568]
===
match
---
trailer [19029,19035]
trailer [19320,19326]
===
match
---
trailer [10815,10825]
trailer [10829,10839]
===
match
---
simple_stmt [29164,29174]
simple_stmt [29455,29465]
===
match
---
name: callback_requests [14446,14463]
name: callback_requests [14460,14477]
===
match
---
name: query [12249,12254]
name: query [12263,12268]
===
match
---
name: dag_id [4373,4379]
name: dag_id [4387,4393]
===
match
---
name: execution_start_date [9852,9872]
name: execution_start_date [9866,9886]
===
match
---
trailer [7436,7443]
trailer [7450,7457]
===
match
---
comparison [27137,27169]
comparison [27428,27460]
===
match
---
name: changed_tis [19147,19158]
name: changed_tis [19438,19449]
===
match
---
name: in_ [11720,11723]
name: in_ [11734,11737]
===
match
---
parameters [6128,6216]
parameters [6142,6230]
===
match
---
name: execution_end_date [8082,8100]
name: execution_end_date [8096,8114]
===
match
---
name: cls [27713,27716]
name: cls [28004,28007]
===
match
---
atom_expr [5247,5260]
atom_expr [5261,5274]
===
match
---
name: self [13545,13549]
name: self [13559,13563]
===
match
---
operator: , [7186,7187]
operator: , [7200,7201]
===
match
---
operator: = [16989,16990]
operator: = [17003,17004]
===
match
---
atom_expr [6057,6067]
atom_expr [6071,6081]
===
match
---
name: get_task [18712,18720]
name: get_task [18747,18755]
===
match
---
expr_stmt [10147,10204]
expr_stmt [10161,10218]
===
match
---
param [18346,18369]
param [18360,18383]
===
match
---
fstring_expr [24030,24043]
fstring_expr [24321,24334]
===
match
---
operator: = [2691,2692]
operator: = [2705,2706]
===
match
---
name: airflow [1279,1286]
name: airflow [1279,1286]
===
match
---
trailer [13033,13056]
trailer [13047,13070]
===
match
---
operator: = [4409,4410]
operator: = [4423,4424]
===
match
---
comparison [9584,9603]
comparison [9598,9617]
===
match
---
name: timezone [30120,30128]
name: timezone [30411,30419]
===
match
---
atom_expr [13545,13564]
atom_expr [13559,13578]
===
match
---
name: self [21324,21328]
name: self [21615,21619]
===
match
---
operator: , [4004,4005]
operator: , [4018,4019]
===
match
---
simple_stmt [11580,11652]
simple_stmt [11594,11666]
===
match
---
atom_expr [29505,29520]
atom_expr [29796,29811]
===
match
---
trailer [4038,4048]
trailer [4052,4062]
===
match
---
name: task_instance_scheduling_decisions [14707,14741]
name: task_instance_scheduling_decisions [14721,14755]
===
match
---
atom [12227,12400]
atom [12241,12414]
===
match
---
name: isinstance [11162,11172]
name: isinstance [11176,11186]
===
match
---
operator: = [10046,10047]
operator: = [10060,10061]
===
match
---
trailer [29135,29142]
trailer [29426,29433]
===
match
---
if_stmt [12541,12639]
if_stmt [12555,12653]
===
match
---
name: timezone [5263,5271]
name: timezone [5277,5285]
===
match
---
expr_stmt [29683,30280]
expr_stmt [29974,30571]
===
match
---
name: not_none_state [11515,11529]
name: not_none_state [11529,11543]
===
match
---
trailer [14463,14482]
trailer [14477,14496]
===
match
---
decorator [27323,27333]
decorator [27614,27624]
===
match
---
expr_stmt [9787,9840]
expr_stmt [9801,9854]
===
match
---
name: task [25777,25781]
name: task [26068,26072]
===
match
---
trailer [3716,3742]
trailer [3730,3756]
===
match
---
trailer [14906,14921]
trailer [14920,14935]
===
match
---
operator: , [4055,4056]
operator: , [4069,4070]
===
match
---
operator: = [22848,22849]
operator: = [23139,23140]
===
match
---
parameters [5102,5108]
parameters [5116,5122]
===
match
---
trailer [25358,25363]
trailer [25649,25654]
===
match
---
suite [20321,20471]
suite [20612,20762]
===
match
---
name: leaf_tis [16566,16574]
name: leaf_tis [16580,16588]
===
match
---
trailer [13040,13046]
trailer [13054,13060]
===
match
---
tfpdef [11932,11948]
tfpdef [11946,11962]
===
match
---
suite [11349,11652]
suite [11363,11666]
===
match
---
trailer [14600,14606]
trailer [14614,14620]
===
match
---
name: session [18508,18515]
name: session [18522,18529]
===
match
---
operator: , [9972,9973]
operator: , [9986,9987]
===
match
---
name: DR [10432,10434]
name: DR [10446,10448]
===
match
---
name: skip_locked [7577,7588]
name: skip_locked [7591,7602]
===
match
---
name: TI [29416,29418]
name: TI [29707,29709]
===
match
---
simple_stmt [2537,2563]
simple_stmt [2551,2577]
===
match
---
name: dag_id [24036,24042]
name: dag_id [24327,24333]
===
match
---
name: UtcDateTime [2671,2682]
name: UtcDateTime [2685,2696]
===
match
---
fstring_start: f" [25124,25126]
fstring_start: f" [25415,25417]
===
match
---
trailer [4652,4661]
trailer [4666,4675]
===
match
---
atom_expr [30064,30081]
atom_expr [30355,30372]
===
match
---
operator: @ [7621,7622]
operator: @ [7635,7636]
===
match
---
name: log [25008,25011]
name: log [25299,25302]
===
match
---
testlist_comp [12880,12966]
testlist_comp [12894,12980]
===
match
---
name: run_type [10435,10443]
name: run_type [10449,10457]
===
match
---
name: self [22371,22375]
name: self [22662,22666]
===
match
---
name: log [18584,18587]
name: log [18598,18601]
===
match
---
trailer [29844,29859]
trailer [30135,30150]
===
match
---
trailer [22789,22800]
trailer [23080,23091]
===
match
---
simple_stmt [3237,3248]
simple_stmt [3251,3262]
===
match
---
name: self [4929,4933]
name: self [4943,4947]
===
match
---
atom_expr [27646,27664]
atom_expr [27937,27955]
===
match
---
operator: = [9913,9914]
operator: = [9927,9928]
===
match
---
atom [18834,18879]
atom [19125,19170]
===
match
---
name: execution_date [27650,27664]
name: execution_date [27941,27955]
===
match
---
simple_stmt [9495,9536]
simple_stmt [9509,9550]
===
match
---
trailer [20170,20174]
trailer [20461,20465]
===
match
---
name: ti [24653,24655]
name: ti [24944,24946]
===
match
---
name: true_delay [23309,23319]
name: true_delay [23600,23610]
===
match
---
trailer [29945,29952]
trailer [30236,30243]
===
match
---
operator: = [17129,17130]
operator: = [17143,17144]
===
match
---
atom [27774,27998]
atom [28065,28289]
===
match
---
expr_stmt [18405,18435]
expr_stmt [18419,18449]
===
match
---
trailer [29325,29332]
trailer [29616,29623]
===
match
---
operator: = [11698,11699]
operator: = [11712,11713]
===
match
---
name: DagModel [7111,7119]
name: DagModel [7125,7133]
===
match
---
name: cls [27802,27805]
name: cls [28093,28096]
===
match
---
name: any [20415,20418]
name: any [20706,20709]
===
match
---
name: str [7751,7754]
name: str [7765,7768]
===
match
---
expr_stmt [10324,10381]
expr_stmt [10338,10395]
===
match
---
trailer [7443,7480]
trailer [7457,7494]
===
match
---
name: unfinished_tasks [15051,15067]
name: unfinished_tasks [15065,15081]
===
match
---
trailer [16593,16597]
trailer [16607,16611]
===
match
---
name: bool [7887,7891]
name: bool [7901,7905]
===
match
---
trailer [18711,18720]
trailer [18746,18755]
===
match
---
fstring [14607,14647]
fstring [14621,14661]
===
match
---
argument [16756,16768]
argument [16770,16782]
===
match
---
operator: , [5501,5502]
operator: , [5515,5516]
===
match
---
except_clause [26064,26092]
except_clause [26355,26383]
===
match
---
simple_stmt [2275,2293]
simple_stmt [2289,2307]
===
match
---
import_from [1510,1566]
import_from [1524,1580]
===
match
---
name: state [23957,23962]
name: state [24248,24253]
===
match
---
name: self [6057,6061]
name: self [6071,6075]
===
match
---
name: timezone [2754,2762]
name: timezone [2768,2776]
===
match
---
trailer [20283,20285]
trailer [20574,20576]
===
match
---
funcdef [11890,12401]
funcdef [11904,12415]
===
match
---
name: session [14742,14749]
name: session [14756,14763]
===
match
---
trailer [25828,25833]
trailer [26119,26124]
===
match
---
name: dag_id [5862,5868]
name: dag_id [5876,5882]
===
match
---
name: execution_date [13550,13564]
name: execution_date [13564,13578]
===
match
---
name: schedulable_tis [14791,14806]
name: schedulable_tis [14805,14820]
===
match
---
atom_expr [19891,19899]
atom_expr [20182,20190]
===
match
---
string: """Type of return for DagRun.task_instance_scheduling_decisions""" [2155,2221]
string: """Type of return for DagRun.task_instance_scheduling_decisions""" [2169,2235]
===
match
---
atom_expr [19021,19117]
atom_expr [19312,19408]
===
match
---
name: __init__ [4736,4744]
name: __init__ [4750,4758]
===
match
---
name: run_type [27388,27396]
name: run_type [27679,27687]
===
match
---
name: and_ [3566,3570]
name: and_ [3580,3584]
===
match
---
operator: = [2618,2619]
operator: = [2632,2633]
===
match
---
not_test [19733,19755]
not_test [20024,20046]
===
match
---
trailer [26119,26129]
trailer [26410,26420]
===
match
---
comparison [15109,15140]
comparison [15123,15154]
===
match
---
atom_expr [3280,3317]
atom_expr [3294,3331]
===
match
---
operator: , [944,945]
operator: , [944,945]
===
match
---
atom_expr [4130,4144]
atom_expr [4144,4158]
===
match
---
arglist [19036,19116]
arglist [19327,19407]
===
match
---
name: Session [26502,26509]
name: Session [26793,26800]
===
match
---
name: is_failure_callback [17847,17866]
name: is_failure_callback [17861,17880]
===
match
---
param [21324,21329]
param [21615,21620]
===
match
---
name: TI [20584,20586]
name: TI [20875,20877]
===
match
---
suite [20085,20123]
suite [20376,20414]
===
match
---
name: dag_id [7052,7058]
name: dag_id [7066,7072]
===
match
---
trailer [7511,7615]
trailer [7525,7629]
===
match
---
simple_stmt [22406,22413]
simple_stmt [22697,22704]
===
match
---
name: tis_filter [20298,20308]
name: tis_filter [20589,20599]
===
match
---
atom_expr [2344,2352]
atom_expr [2358,2366]
===
match
---
name: msg [17893,17896]
name: msg [17907,17910]
===
match
---
name: conf [1337,1341]
name: conf [1337,1341]
===
match
---
trailer [23997,24004]
trailer [24288,24295]
===
match
---
name: log [26111,26114]
name: log [26402,26405]
===
match
---
trailer [15974,16035]
trailer [15988,16049]
===
match
---
name: PickleType [3065,3075]
name: PickleType [3079,3089]
===
match
---
atom_expr [24930,24940]
atom_expr [25221,25231]
===
match
---
atom_expr [11434,11464]
atom_expr [11448,11478]
===
match
---
operator: , [17871,17872]
operator: , [17885,17886]
===
match
---
trailer [29379,29394]
trailer [29670,29685]
===
match
---
argument [17079,17104]
argument [17093,17118]
===
match
---
name: task_type [25864,25873]
name: task_type [26155,26164]
===
match
---
name: changed_tis [19701,19712]
name: changed_tis [19992,20003]
===
match
---
trailer [29145,29153]
trailer [29436,29444]
===
match
---
name: state [24935,24940]
name: state [25226,25231]
===
match
---
suite [8153,10605]
suite [8167,10619]
===
match
---
name: fileloc [16954,16961]
name: fileloc [16968,16975]
===
match
---
operator: , [25086,25087]
operator: , [25377,25378]
===
match
---
suite [21212,21241]
suite [21503,21532]
===
match
---
name: tis [11694,11697]
name: tis [11708,11711]
===
match
---
name: order_by [7215,7223]
name: order_by [7229,7237]
===
match
---
operator: = [18832,18833]
operator: = [19123,19124]
===
match
---
name: schedulable_tis [28829,28844]
name: schedulable_tis [29120,29135]
===
match
---
simple_stmt [9352,9364]
simple_stmt [9366,9378]
===
match
---
name: provide_session [1863,1878]
name: provide_session [1877,1892]
===
match
---
name: DagModel [6681,6689]
name: DagModel [6695,6703]
===
match
---
simple_stmt [16730,16805]
simple_stmt [16744,16819]
===
match
---
name: scheduleable_tasks [19847,19865]
name: scheduleable_tasks [20138,20156]
===
match
---
simple_stmt [22709,22716]
simple_stmt [23000,23007]
===
match
---
name: datetime [808,816]
name: datetime [808,816]
===
match
---
operator: , [25082,25083]
operator: , [25373,25374]
===
match
---
name: List [19619,19623]
name: List [19910,19914]
===
match
---
trailer [11713,11719]
trailer [11727,11733]
===
match
---
string: 'DagRun' [27514,27522]
string: 'DagRun' [27805,27813]
===
match
---
trailer [28947,28967]
trailer [29238,29258]
===
match
---
expr_stmt [2948,2996]
expr_stmt [2962,3010]
===
match
---
trailer [25465,25509]
trailer [25756,25800]
===
match
---
name: filter [13428,13434]
name: filter [13442,13448]
===
match
---
name: last_scheduling_decision [14544,14568]
name: last_scheduling_decision [14558,14582]
===
match
---
name: self [27353,27357]
name: self [27644,27648]
===
match
---
param [11918,11931]
param [11932,11945]
===
match
---
name: DagRun [13407,13413]
name: DagRun [13421,13427]
===
match
---
name: filter [7437,7443]
name: filter [7451,7457]
===
match
---
name: ti [15588,15590]
name: ti [15602,15604]
===
match
---
expr_stmt [25899,25933]
expr_stmt [26190,26224]
===
match
---
name: key [22845,22848]
name: key [23136,23139]
===
match
---
name: execute_callbacks [16695,16712]
name: execute_callbacks [16709,16726]
===
match
---
name: SCHEDULEABLE_STATES [1698,1717]
name: SCHEDULEABLE_STATES [1712,1731]
===
match
---
arglist [3542,3743]
arglist [3556,3757]
===
match
---
string: 'DagRun' [26562,26570]
string: 'DagRun' [26853,26861]
===
match
---
name: order_by [13111,13119]
name: order_by [13125,13133]
===
match
---
name: filters [12856,12863]
name: filters [12870,12877]
===
match
---
name: append [13027,13033]
name: append [13041,13047]
===
match
---
expr_stmt [19701,19720]
expr_stmt [19992,20011]
===
match
---
operator: == [29783,29785]
operator: == [30074,30076]
===
match
---
atom_expr [11597,11650]
atom_expr [11611,11664]
===
match
---
operator: = [5408,5409]
operator: = [5422,5423]
===
match
---
name: get_dag [12410,12417]
name: get_dag [12424,12431]
===
match
---
decorator [10835,10852]
decorator [10849,10866]
===
match
---
funcdef [19472,20510]
funcdef [19763,20801]
===
match
---
expr_stmt [6734,6777]
expr_stmt [6748,6791]
===
match
---
name: TI [3542,3544]
name: TI [3556,3558]
===
match
---
param [4112,4152]
param [4126,4166]
===
match
---
trailer [22316,22322]
trailer [22607,22613]
===
match
---
name: run_type [10514,10522]
name: run_type [10528,10536]
===
match
---
operator: @ [13163,13164]
operator: @ [13177,13178]
===
match
---
if_stmt [22421,22461]
if_stmt [22712,22752]
===
match
---
comparison [23404,23434]
comparison [23695,23725]
===
match
---
operator: = [17717,17718]
operator: = [17731,17732]
===
match
---
name: Tuple [19613,19618]
name: Tuple [19904,19909]
===
match
---
atom_expr [16730,16804]
atom_expr [16744,16818]
===
match
---
tfpdef [13695,13718]
tfpdef [13709,13732]
===
match
---
name: _are_premature_tis [15389,15407]
name: _are_premature_tis [15403,15421]
===
match
---
simple_stmt [6734,6778]
simple_stmt [6748,6792]
===
match
---
expr_stmt [9697,9752]
expr_stmt [9711,9766]
===
match
---
trailer [22331,22339]
trailer [22622,22630]
===
match
---
expr_stmt [4368,4388]
expr_stmt [4382,4402]
===
match
---
operator: , [29797,29798]
operator: , [30088,30089]
===
match
---
name: tis [11854,11857]
name: tis [11868,11871]
===
match
---
atom_expr [11711,11730]
atom_expr [11725,11744]
===
match
---
expr_stmt [19668,19692]
expr_stmt [19959,19983]
===
match
---
operator: = [12766,12767]
operator: = [12780,12781]
===
match
---
name: info [26115,26119]
name: info [26406,26410]
===
match
---
name: first [13594,13599]
name: first [13608,13613]
===
match
---
trailer [15552,15559]
trailer [15566,15573]
===
match
---
atom_expr [5380,5450]
atom_expr [5394,5464]
===
match
---
atom_expr [5263,5280]
atom_expr [5277,5294]
===
match
---
name: Optional [13751,13759]
name: Optional [13765,13773]
===
match
---
name: func [5720,5724]
name: func [5734,5738]
===
match
---
name: ti [22765,22767]
name: ti [23056,23058]
===
match
---
name: ti [22856,22858]
name: ti [23147,23149]
===
match
---
name: first [27300,27305]
name: first [27591,27596]
===
match
---
operator: , [8072,8073]
operator: , [8086,8087]
===
match
---
operator: , [27850,27851]
operator: , [28141,28142]
===
match
---
simple_stmt [18157,18204]
simple_stmt [18171,18218]
===
match
---
trailer [4908,5083]
trailer [4922,5097]
===
match
---
atom_expr [27400,27423]
atom_expr [27691,27714]
===
match
---
param [26524,26548]
param [26815,26839]
===
match
---
name: base [1426,1430]
name: base [1440,1444]
===
match
---
atom_expr [7029,7044]
atom_expr [7043,7058]
===
match
---
expr_stmt [24413,24433]
expr_stmt [24704,24724]
===
match
---
name: self [22312,22316]
name: self [22603,22607]
===
match
---
trailer [6891,6898]
trailer [6905,6912]
===
match
---
trailer [10536,10549]
trailer [10550,10563]
===
match
---
operator: { [23913,23914]
operator: { [24204,24205]
===
match
---
trailer [27819,27824]
trailer [28110,28115]
===
match
---
name: incr [25119,25123]
name: incr [25410,25414]
===
match
---
param [10879,10884]
param [10893,10898]
===
match
---
trailer [4175,4180]
trailer [4189,4194]
===
match
---
name: ti [29071,29073]
name: ti [29362,29364]
===
match
---
name: log [25355,25358]
name: log [25646,25649]
===
match
---
name: finished_tasks [19441,19455]
name: finished_tasks [19732,19746]
===
match
---
name: State [23966,23971]
name: State [24257,24262]
===
match
---
trailer [16670,16678]
trailer [16684,16692]
===
match
---
dotted_name [1308,1329]
dotted_name [1308,1329]
===
match
---
trailer [23956,23962]
trailer [24247,24253]
===
match
---
atom [28861,29033]
atom [29152,29324]
===
match
---
expr_stmt [4681,4719]
expr_stmt [4695,4733]
===
match
---
suite [24836,24909]
suite [25127,25200]
===
match
---
name: DagCallbackRequest [14464,14482]
name: DagCallbackRequest [14478,14496]
===
match
---
operator: = [29542,29543]
operator: = [29833,29834]
===
match
---
strings [26173,26262]
strings [26464,26553]
===
match
---
name: e [23650,23651]
name: e [23941,23942]
===
match
---
param [20631,20648]
param [20922,20939]
===
match
---
trailer [18201,18203]
trailer [18215,18217]
===
match
---
name: t [15530,15531]
name: t [15544,15545]
===
match
---
name: log [19026,19029]
name: log [19317,19320]
===
match
---
name: provide_session [24062,24077]
name: provide_session [24353,24368]
===
match
---
if_stmt [6699,6778]
if_stmt [6713,6792]
===
match
---
trailer [19893,19899]
trailer [20184,20190]
===
match
---
simple_stmt [4426,4463]
simple_stmt [4440,4477]
===
match
---
name: dag_hash [4664,4672]
name: dag_hash [4678,4686]
===
match
---
atom_expr [5896,5913]
atom_expr [5910,5927]
===
match
---
name: session [27788,27795]
name: session [28079,28086]
===
match
---
name: session [15442,15449]
name: session [15456,15463]
===
match
---
trailer [18050,18065]
trailer [18064,18079]
===
match
---
atom_expr [9647,9679]
atom_expr [9661,9693]
===
match
---
name: query [27796,27801]
name: query [28087,28092]
===
match
---
name: execution_date [7772,7786]
name: execution_date [7786,7800]
===
match
---
atom_expr [10432,10443]
atom_expr [10446,10457]
===
match
---
atom_expr [4397,4408]
atom_expr [4411,4422]
===
match
---
decorated [5329,5451]
decorated [5343,5465]
===
match
---
trailer [5898,5913]
trailer [5912,5927]
===
match
---
suite [10402,10457]
suite [10416,10471]
===
match
---
operator: , [21196,21197]
operator: , [21487,21488]
===
match
---
trailer [2841,2845]
trailer [2855,2859]
===
match
---
operator: , [12747,12748]
operator: , [12761,12762]
===
match
---
decorator [11869,11886]
decorator [11883,11900]
===
match
---
param [8025,8073]
param [8039,8087]
===
match
---
atom_expr [18697,18732]
atom_expr [18732,18767]
===
match
---
name: dag [24729,24732]
name: dag [25020,25023]
===
match
---
trailer [24827,24835]
trailer [25118,25126]
===
match
---
and_test [25672,25734]
and_test [25963,26025]
===
match
---
name: default [2983,2990]
name: default [2997,3004]
===
match
---
trailer [22862,22873]
trailer [23153,23164]
===
match
---
import_from [787,816]
import_from [787,816]
===
match
---
name: creating_job_id [4314,4329]
name: creating_job_id [4328,4343]
===
match
---
string: """         Returns a set of dag runs for the given search criteria.          :param dag_id: the dag_id or list of dag_id to find dag runs for         :type dag_id: str or list[str]         :param run_id: defines the run id for this dag run         :type run_id: str         :param run_type: type of DagRun         :type run_type: airflow.utils.types.DagRunType         :param execution_date: the execution date         :type execution_date: datetime.datetime or list[datetime.datetime]         :param state: the state of the dag run         :type state: str         :param external_trigger: whether this dag run is externally triggered         :type external_trigger: bool         :param no_backfills: return no backfills (True), return all (False).             Defaults to False         :type no_backfills: bool         :param session: database session         :type session: sqlalchemy.orm.session.Session         :param execution_start_date: dag run that was executed from this date         :type execution_start_date: datetime.datetime         :param execution_end_date: dag run that was executed until this date         :type execution_end_date: datetime.datetime         """ [8162,9343]
string: """         Returns a set of dag runs for the given search criteria.          :param dag_id: the dag_id or list of dag_id to find dag runs for         :type dag_id: str or list[str]         :param run_id: defines the run id for this dag run         :type run_id: str         :param run_type: type of DagRun         :type run_type: airflow.utils.types.DagRunType         :param execution_date: the execution date         :type execution_date: datetime.datetime or list[datetime.datetime]         :param state: the state of the dag run         :type state: str         :param external_trigger: whether this dag run is externally triggered         :type external_trigger: bool         :param no_backfills: return no backfills (True), return all (False).             Defaults to False         :type no_backfills: bool         :param session: database session         :type session: sqlalchemy.orm.session.Session         :param execution_start_date: dag run that was executed from this date         :type execution_start_date: datetime.datetime         :param execution_end_date: dag run that was executed until this date         :type execution_end_date: datetime.datetime         """ [8176,9357]
===
match
---
name: in_ [11815,11818]
name: in_ [11829,11832]
===
match
---
name: state [16521,16526]
name: state [16535,16540]
===
match
---
funcdef [6101,7616]
funcdef [6115,7630]
===
match
---
trailer [7700,7716]
trailer [7714,7730]
===
match
---
simple_stmt [20237,20287]
simple_stmt [20528,20578]
===
match
---
trailer [26150,26155]
trailer [26441,26446]
===
match
---
operator: , [18523,18524]
operator: , [18537,18538]
===
match
---
dotted_name [1235,1257]
dotted_name [1235,1257]
===
match
---
name: session [10897,10904]
name: session [10911,10918]
===
match
---
atom_expr [7317,7335]
atom_expr [7331,7349]
===
match
---
name: execute_callbacks [13695,13712]
name: execute_callbacks [13709,13726]
===
match
---
operator: = [4567,4568]
operator: = [4581,4582]
===
match
---
name: State [18552,18557]
name: State [18566,18571]
===
match
---
name: run_type [10648,10656]
name: run_type [10662,10670]
===
match
---
fstring [24005,24044]
fstring [24296,24335]
===
match
---
operator: , [30247,30248]
operator: , [30538,30539]
===
match
---
name: Column [3058,3064]
name: Column [3072,3078]
===
match
---
operator: = [24553,24554]
operator: = [24844,24845]
===
match
---
operator: = [11206,11207]
operator: = [11220,11221]
===
match
---
name: isinstance [9647,9657]
name: isinstance [9661,9671]
===
match
---
fstring_string:  -  [26236,26239]
fstring_string:  -  [26527,26530]
===
match
---
name: utcnow [2701,2707]
name: utcnow [2715,2721]
===
match
---
name: dag_id [7038,7044]
name: dag_id [7052,7058]
===
match
---
operator: , [11916,11917]
operator: , [11930,11931]
===
match
---
name: finished_tis [21330,21342]
name: finished_tis [21621,21633]
===
match
---
atom_expr [14770,14778]
atom_expr [14784,14792]
===
match
---
atom_expr [10500,10550]
atom_expr [10514,10564]
===
match
---
name: unfinished_tasks [16488,16504]
name: unfinished_tasks [16502,16518]
===
match
---
atom_expr [2726,2770]
atom_expr [2740,2784]
===
match
---
operator: = [25247,25248]
operator: = [25538,25539]
===
match
---
simple_stmt [14662,14683]
simple_stmt [14676,14697]
===
match
---
param [27492,27504]
param [27783,27795]
===
match
---
operator: , [24044,24045]
operator: , [24335,24336]
===
match
---
name: self [23704,23708]
name: self [23995,23999]
===
match
---
arglist [17504,17571]
arglist [17518,17585]
===
match
---
name: SCHEDULED [29511,29520]
name: SCHEDULED [29802,29811]
===
match
---
name: DR [5844,5846]
name: DR [5858,5860]
===
match
---
argument [21012,21039]
argument [21303,21330]
===
match
---
name: LoggingMixin [1816,1828]
name: LoggingMixin [1830,1842]
===
match
---
expr_stmt [2611,2642]
expr_stmt [2625,2656]
===
match
---
atom_expr [16509,16575]
atom_expr [16523,16589]
===
match
---
trailer [14706,14741]
trailer [14720,14755]
===
match
---
name: DagCallbackRequest [13778,13796]
name: DagCallbackRequest [13792,13810]
===
match
---
trailer [11172,11184]
trailer [11186,11198]
===
match
---
operator: = [4298,4299]
operator: = [4312,4313]
===
match
---
name: self [5125,5129]
name: self [5139,5143]
===
match
---
trailer [23794,23803]
trailer [24085,24094]
===
match
---
name: generate_run_id [10632,10647]
name: generate_run_id [10646,10661]
===
match
---
operator: = [2784,2785]
operator: = [2798,2799]
===
match
---
simple_stmt [18742,18809]
simple_stmt [19033,19100]
===
match
---
trailer [25906,25933]
trailer [26197,26224]
===
match
---
comparison [27906,27953]
comparison [28197,28244]
===
match
---
name: Optional [12727,12735]
name: Optional [12741,12749]
===
match
---
operator: == [10261,10263]
operator: == [10275,10277]
===
match
---
atom_expr [12922,12943]
atom_expr [12936,12957]
===
match
---
arglist [11601,11649]
arglist [11615,11663]
===
match
---
name: run_type [10789,10797]
name: run_type [10803,10811]
===
match
---
trailer [5304,5313]
trailer [5318,5327]
===
match
---
name: dag_id [11056,11062]
name: dag_id [11070,11076]
===
match
---
import_as_names [1199,1229]
import_as_names [1199,1229]
===
match
---
trailer [27795,27801]
trailer [28086,28092]
===
match
---
name: str [3993,3996]
name: str [4007,4010]
===
match
---
name: cls [6927,6930]
name: cls [6941,6944]
===
match
---
name: Tuple [13735,13740]
name: Tuple [13749,13754]
===
match
---
simple_stmt [4588,4607]
simple_stmt [4602,4621]
===
match
---
name: self [17806,17810]
name: self [17820,17824]
===
match
---
name: external_trigger [4513,4529]
name: external_trigger [4527,4543]
===
match
---
name: ti [25272,25274]
name: ti [25563,25565]
===
match
---
simple_stmt [3051,3077]
simple_stmt [3065,3091]
===
match
---
fstring_end: " [25874,25875]
fstring_end: " [26165,26166]
===
match
---
name: session [7291,7298]
name: session [7305,7312]
===
match
---
trailer [19165,19180]
trailer [19456,19471]
===
match
---
atom_expr [2664,2708]
atom_expr [2678,2722]
===
match
---
name: tis [11202,11205]
name: tis [11216,11219]
===
match
---
name: timing [23998,24004]
name: timing [24289,24295]
===
match
---
string: "DAG" [12427,12432]
string: "DAG" [12441,12446]
===
match
---
name: dag_id [9438,9444]
name: dag_id [9452,9458]
===
match
---
operator: = [14569,14570]
operator: = [14583,14584]
===
match
---
name: __tablename__ [2537,2550]
name: __tablename__ [2551,2564]
===
match
---
expr_stmt [20401,20470]
expr_stmt [20692,20761]
===
match
---
trailer [26244,26259]
trailer [26535,26550]
===
match
---
name: t [18841,18842]
name: t [19132,19133]
===
match
---
name: ordered_tis_by_start_date [22729,22754]
name: ordered_tis_by_start_date [23020,23045]
===
match
---
atom_expr [15601,15611]
atom_expr [15615,15625]
===
match
---
atom_expr [12777,12795]
atom_expr [12791,12809]
===
match
---
name: fresh_tis [20460,20469]
name: fresh_tis [20751,20760]
===
match
---
trailer [27238,27253]
trailer [27529,27544]
===
match
---
name: self [4397,4401]
name: self [4411,4415]
===
match
---
simple_stmt [5247,5324]
simple_stmt [5261,5338]
===
match
---
operator: , [19542,19543]
operator: , [19833,19834]
===
match
---
trailer [5846,5853]
trailer [5860,5867]
===
match
---
suite [6721,6778]
suite [6735,6792]
===
match
---
name: session [20631,20638]
name: session [20922,20929]
===
match
---
name: query [13401,13406]
name: query [13415,13420]
===
match
---
name: leaf_task_ids [15615,15628]
name: leaf_task_ids [15629,15642]
===
match
---
operator: -> [19610,19612]
operator: -> [19901,19903]
===
match
---
operator: , [17769,17770]
operator: , [17783,17784]
===
match
---
atom_expr [4557,4566]
atom_expr [4571,4580]
===
match
---
name: dag_hash [3202,3210]
name: dag_hash [3216,3224]
===
match
---
atom_expr [7686,7717]
atom_expr [7700,7731]
===
match
---
argument [2746,2769]
argument [2760,2783]
===
match
---
operator: = [16876,16877]
operator: = [16890,16891]
===
match
---
name: Optional [4331,4339]
name: Optional [4345,4353]
===
match
---
atom [18551,18568]
atom [18565,18582]
===
match
---
trailer [11643,11649]
trailer [11657,11663]
===
match
---
sync_comp_for [15141,15166]
sync_comp_for [15155,15180]
===
match
---
name: tis_filter [20237,20247]
name: tis_filter [20528,20538]
===
match
---
trailer [18079,18132]
trailer [18093,18146]
===
match
---
operator: = [2854,2855]
operator: = [2868,2869]
===
match
---
tfpdef [7992,8008]
tfpdef [8006,8022]
===
match
---
name: task_id [11807,11814]
name: task_id [11821,11828]
===
match
---
expr_stmt [6057,6078]
expr_stmt [6071,6092]
===
match
---
name: start_date [22863,22873]
name: start_date [23154,23164]
===
match
---
name: TI [19684,19686]
name: TI [19975,19977]
===
match
---
name: ti [20454,20456]
name: ti [20745,20747]
===
match
---
atom_expr [2620,2642]
atom_expr [2634,2656]
===
match
---
expr_stmt [2297,2323]
expr_stmt [2311,2337]
===
match
---
return_stmt [13065,13157]
return_stmt [13079,13171]
===
match
---
operator: , [4224,4225]
operator: , [4238,4239]
===
match
---
simple_stmt [18921,19009]
simple_stmt [19212,19300]
===
match
---
fstring_end: " [10828,10829]
fstring_end: " [10842,10843]
===
match
---
and_test [9852,9895]
and_test [9866,9909]
===
match
---
test [5263,5323]
test [5277,5337]
===
match
---
trailer [27712,27724]
trailer [28003,28015]
===
match
---
atom_expr [15384,15450]
atom_expr [15398,15464]
===
match
---
name: update [29946,29952]
name: update [30237,30243]
===
match
---
operator: = [16268,16269]
operator: = [16282,16283]
===
match
---
name: self [18036,18040]
name: self [18050,18054]
===
match
---
trailer [24655,24663]
trailer [24946,24954]
===
match
---
comparison [27383,27423]
comparison [27674,27714]
===
match
---
atom [13379,13611]
atom [13393,13625]
===
match
---
name: Boolean [2974,2981]
name: Boolean [2988,2995]
===
match
---
atom_expr [24822,24835]
atom_expr [25113,25126]
===
match
---
simple_stmt [22454,22461]
simple_stmt [22745,22752]
===
match
---
atom_expr [11960,11972]
atom_expr [11974,11986]
===
match
---
fstring_start: f" [14607,14609]
fstring_start: f" [14621,14623]
===
match
---
name: types [2027,2032]
name: types [2041,2046]
===
match
---
operator: = [2926,2927]
operator: = [2940,2941]
===
match
---
operator: = [6041,6042]
operator: = [6055,6056]
===
match
---
trailer [27986,27988]
trailer [28277,28279]
===
match
---
simple_stmt [1599,1650]
simple_stmt [1613,1664]
===
match
---
argument [16167,16192]
argument [16181,16206]
===
match
---
name: UtcDateTime [3185,3196]
name: UtcDateTime [3199,3210]
===
match
---
name: self [18484,18488]
name: self [18498,18502]
===
match
---
atom_expr [2232,2240]
atom_expr [2246,2254]
===
match
---
trailer [18720,18732]
trailer [18755,18767]
===
match
---
operator: + [18549,18550]
operator: + [18563,18564]
===
match
---
name: task_id [11918,11925]
name: task_id [11932,11939]
===
match
---
trailer [25542,25547]
trailer [25833,25838]
===
match
---
trailer [12382,12388]
trailer [12396,12402]
===
match
---
name: UniqueConstraint [3381,3397]
name: UniqueConstraint [3395,3411]
===
match
---
atom_expr [25113,25168]
atom_expr [25404,25459]
===
match
---
name: state [11448,11453]
name: state [11462,11467]
===
match
---
name: state [23727,23732]
name: state [24018,24023]
===
match
---
atom_expr [6943,6966]
atom_expr [6957,6980]
===
match
---
operator: = [20248,20249]
operator: = [20539,20540]
===
match
---
name: scheduleable_tasks [18921,18939]
name: scheduleable_tasks [19212,19230]
===
match
---
simple_stmt [13019,13057]
simple_stmt [13033,13071]
===
match
---
operator: , [16786,16787]
operator: , [16800,16801]
===
match
---
try_stmt [22470,23655]
try_stmt [22761,23946]
===
match
---
parameters [24102,24133]
parameters [24393,24424]
===
match
---
atom_expr [13498,13519]
atom_expr [13512,13533]
===
match
---
trailer [4430,4445]
trailer [4444,4459]
===
match
---
name: DEFAULT_DAGRUNS_TO_EXAMINE [3755,3781]
name: DEFAULT_DAGRUNS_TO_EXAMINE [3769,3795]
===
match
---
trailer [23468,23532]
trailer [23759,23823]
===
match
---
name: execution_date [3676,3690]
name: execution_date [3690,3704]
===
match
---
name: old_states [19644,19654]
name: old_states [19935,19945]
===
match
---
name: execution_date [17023,17037]
name: execution_date [17037,17051]
===
match
---
operator: , [6167,6168]
operator: , [6181,6182]
===
match
---
trailer [12296,12303]
trailer [12310,12317]
===
match
---
name: datetime [10686,10694]
name: datetime [10700,10708]
===
match
---
name: self [12326,12330]
name: self [12340,12344]
===
match
---
trailer [10513,10522]
trailer [10527,10536]
===
match
---
suite [4771,5084]
suite [4785,5098]
===
match
---
atom_expr [15739,15804]
atom_expr [15753,15818]
===
match
---
suite [25333,25548]
suite [25624,25839]
===
match
---
operator: , [2682,2683]
operator: , [2696,2697]
===
match
---
comparison [11076,11116]
comparison [11090,11130]
===
match
---
operator: == [12289,12291]
operator: == [12303,12305]
===
match
---
trailer [11600,11650]
trailer [11614,11664]
===
match
---
name: query [5797,5802]
name: query [5811,5816]
===
match
---
name: finished_tasks [14907,14921]
name: finished_tasks [14921,14935]
===
match
---
atom_expr [23966,23978]
atom_expr [24257,24269]
===
match
---
trailer [10058,10101]
trailer [10072,10115]
===
match
---
name: next_dagruns_to_examine [6105,6128]
name: next_dagruns_to_examine [6119,6142]
===
match
---
name: callback [18266,18274]
name: callback [18280,18288]
===
match
---
name: filter [10504,10510]
name: filter [10518,10524]
===
match
---
simple_stmt [5770,6024]
simple_stmt [5784,6038]
===
match
---
name: TI [11969,11971]
name: TI [11983,11985]
===
match
---
name: Optional [3984,3992]
name: Optional [3998,4006]
===
match
---
name: session [26439,26446]
name: session [26730,26737]
===
match
---
name: _emit_true_scheduling_delay_stats_for_finished_state [21271,21323]
name: _emit_true_scheduling_delay_stats_for_finished_state [21562,21614]
===
match
---
suite [23563,23655]
suite [23854,23946]
===
match
---
trailer [14672,14680]
trailer [14686,14694]
===
match
---
atom_expr [16822,16849]
atom_expr [16836,16863]
===
match
---
operator: , [3300,3301]
operator: , [3314,3315]
===
match
---
operator: = [22491,22492]
operator: = [22782,22783]
===
match
---
testlist [20487,20509]
testlist [20778,20800]
===
match
---
param [18340,18345]
param [18354,18359]
===
match
---
trailer [7037,7044]
trailer [7051,7058]
===
match
---
atom_expr [22921,22960]
atom_expr [23212,23251]
===
match
---
simple_stmt [1772,1829]
simple_stmt [1786,1843]
===
match
---
operator: = [16026,16027]
operator: = [16040,16041]
===
match
---
trailer [27936,27938]
trailer [28227,28229]
===
match
---
import_from [1172,1229]
import_from [1172,1229]
===
match
---
fstring [10786,10829]
fstring [10800,10843]
===
match
---
operator: , [30177,30178]
operator: , [30468,30469]
===
match
---
operator: , [1927,1928]
operator: , [1941,1942]
===
match
---
expr_stmt [14885,14921]
expr_stmt [14899,14935]
===
match
---
operator: = [3518,3519]
operator: = [3532,3533]
===
match
---
simple_stmt [27533,27578]
simple_stmt [27824,27869]
===
match
---
name: TI [11631,11633]
name: TI [11645,11647]
===
match
---
name: ti [28823,28825]
name: ti [29114,29116]
===
match
---
atom_expr [5409,5449]
atom_expr [5423,5463]
===
match
---
name: default [2746,2753]
name: default [2760,2767]
===
match
---
name: cast [5891,5895]
name: cast [5905,5909]
===
match
---
name: dag [22533,22536]
name: dag [22824,22827]
===
match
---
operator: = [9413,9414]
operator: = [9427,9428]
===
match
---
name: are_runnable_tasks [17305,17323]
name: are_runnable_tasks [17319,17337]
===
match
---
suite [9680,9753]
suite [9694,9767]
===
match
---
trailer [29751,29928]
trailer [30042,30219]
===
match
---
dotted_name [1456,1483]
dotted_name [1470,1497]
===
match
---
trailer [4372,4379]
trailer [4386,4393]
===
match
---
trailer [10343,10360]
trailer [10357,10374]
===
match
---
operator: , [19627,19628]
operator: , [19918,19919]
===
match
---
tfpdef [7772,7806]
tfpdef [7786,7820]
===
match
---
name: unfinished [18797,18807]
name: unfinished [19088,19098]
===
match
---
operator: , [7011,7012]
operator: , [7025,7026]
===
match
---
name: str [3955,3958]
name: str [3969,3972]
===
match
---
operator: = [4380,4381]
operator: = [4394,4395]
===
match
---
parameters [27486,27505]
parameters [27777,27796]
===
match
---
name: t [15046,15047]
name: t [15060,15061]
===
match
---
funcdef [28025,30303]
funcdef [28316,30594]
===
match
---
name: DagRun [27051,27057]
name: DagRun [27342,27348]
===
match
---
argument [20006,20035]
argument [20297,20326]
===
match
---
atom_expr [18051,18064]
atom_expr [18065,18078]
===
match
---
atom_expr [15743,15756]
atom_expr [15757,15770]
===
match
---
operator: { [10800,10801]
operator: { [10814,10815]
===
match
---
operator: = [3056,3057]
operator: = [3070,3071]
===
match
---
name: self [4557,4561]
name: self [4571,4575]
===
match
---
arglist [16603,16636]
arglist [16617,16650]
===
match
---
trailer [29952,30266]
trailer [30243,30557]
===
match
---
param [10885,10896]
param [10899,10910]
===
match
---
name: dag [25633,25636]
name: dag [25924,25927]
===
match
---
operator: , [7704,7705]
operator: , [7718,7719]
===
match
---
operator: , [16288,16289]
operator: , [16302,16303]
===
match
---
name: dag [16950,16953]
name: dag [16964,16967]
===
match
---
trailer [30128,30135]
trailer [30419,30426]
===
match
---
name: callback_requests [13760,13777]
name: callback_requests [13774,13791]
===
match
---
name: DagModel [7158,7166]
name: DagModel [7172,7180]
===
match
---
operator: = [3039,3040]
operator: = [3053,3054]
===
match
---
name: debug [19030,19035]
name: debug [19321,19326]
===
match
---
operator: } [26259,26260]
operator: } [26550,26551]
===
match
---
name: msg [16356,16359]
name: msg [16370,16373]
===
match
---
name: task_id [24745,24752]
name: task_id [25036,25043]
===
match
---
atom_expr [2855,2868]
atom_expr [2869,2882]
===
match
---
param [20597,20622]
param [20888,20913]
===
match
---
expr_stmt [2328,2352]
expr_stmt [2342,2366]
===
match
---
comparison [7444,7479]
comparison [7458,7493]
===
match
---
simple_stmt [4681,4720]
simple_stmt [4695,4734]
===
match
---
name: warning [25012,25019]
name: warning [25303,25310]
===
match
---
expr_stmt [6033,6048]
expr_stmt [6047,6062]
===
match
---
name: depends_on_past [15026,15041]
name: depends_on_past [15040,15055]
===
match
---
simple_stmt [11694,11732]
simple_stmt [11708,11746]
===
match
---
operator: == [6909,6911]
operator: == [6923,6925]
===
match
---
operator: = [17805,17806]
operator: = [17819,17820]
===
match
---
not_test [12544,12556]
not_test [12558,12570]
===
match
---
atom_expr [24970,24981]
atom_expr [25261,25272]
===
match
---
funcdef [20515,21262]
funcdef [20806,21553]
===
match
---
name: self [22528,22532]
name: self [22819,22823]
===
match
---
return_stmt [18242,18274]
return_stmt [18256,18288]
===
match
---
expr_stmt [5708,5760]
expr_stmt [5722,5774]
===
match
---
dotted_name [1177,1191]
dotted_name [1177,1191]
===
match
---
expr_stmt [18444,18463]
expr_stmt [18458,18477]
===
match
---
trailer [25528,25534]
trailer [25819,25825]
===
match
---
name: ordered_tis_by_start_date [22921,22946]
name: ordered_tis_by_start_date [23212,23237]
===
match
---
name: Optional [8047,8055]
name: Optional [8061,8069]
===
match
---
argument [17556,17571]
argument [17570,17585]
===
match
---
operator: = [25902,25903]
operator: = [26193,26194]
===
match
---
atom_expr [13452,13465]
atom_expr [13466,13479]
===
match
---
trailer [11013,11017]
trailer [11027,11031]
===
match
---
param [7678,7725]
param [7692,7739]
===
match
---
name: execution_date [10167,10181]
name: execution_date [10181,10195]
===
match
---
raise_stmt [12570,12638]
raise_stmt [12584,12652]
===
match
---
name: DR [10580,10582]
name: DR [10594,10596]
===
match
---
string: "@once" [22588,22595]
string: "@once" [22879,22886]
===
match
---
name: flag_upstream_failed [20965,20985]
name: flag_upstream_failed [21256,21276]
===
match
---
name: execution_date [7451,7465]
name: execution_date [7465,7479]
===
match
---
operator: = [6068,6069]
operator: = [6082,6083]
===
match
---
operator: = [18515,18516]
operator: = [18529,18530]
===
match
---
operator: , [7058,7059]
operator: , [7072,7073]
===
match
---
subscriptlist [19619,19633]
subscriptlist [19910,19924]
===
match
---
trailer [20363,20370]
trailer [20654,20661]
===
match
---
import_from [1718,1771]
import_from [1732,1785]
===
match
---
trailer [5438,5448]
trailer [5452,5462]
===
match
---
simple_stmt [20401,20471]
simple_stmt [20692,20762]
===
match
---
atom_expr [18552,18566]
atom_expr [18566,18580]
===
match
---
name: String [2890,2896]
name: String [2904,2910]
===
match
---
name: fileloc [16185,16192]
name: fileloc [16199,16206]
===
match
---
name: callback [17635,17643]
name: callback [17649,17657]
===
match
---
atom_expr [26289,26329]
atom_expr [26580,26620]
===
match
---
trailer [14606,14648]
trailer [14620,14662]
===
match
---
name: self [24031,24035]
name: self [24322,24326]
===
match
---
comparison [20298,20320]
comparison [20589,20611]
===
match
---
name: self [5181,5185]
name: self [5195,5199]
===
match
---
trailer [17425,17432]
trailer [17439,17446]
===
match
---
decorated [13617,18275]
decorated [13631,18289]
===
match
---
expr_stmt [2275,2292]
expr_stmt [2289,2306]
===
match
---
import_as_names [1744,1771]
import_as_names [1758,1785]
===
match
---
comparison [24930,24961]
comparison [25221,25252]
===
match
---
operator: @ [10835,10836]
operator: @ [10849,10850]
===
match
---
name: in_ [9732,9735]
name: in_ [9746,9749]
===
match
---
trailer [6985,7073]
trailer [6999,7087]
===
match
---
operator: , [28046,28047]
operator: , [28337,28338]
===
match
---
arglist [25020,25091]
arglist [25311,25382]
===
match
---
operator: , [27490,27491]
operator: , [27781,27782]
===
match
---
expr_stmt [12856,12976]
expr_stmt [12870,12990]
===
match
---
simple_stmt [9697,9753]
simple_stmt [9711,9767]
===
match
---
name: ti [15601,15603]
name: ti [15615,15617]
===
match
---
decorator [12669,12686]
decorator [12683,12700]
===
match
---
number: 0 [29172,29173]
number: 0 [29463,29464]
===
match
---
operator: , [29909,29910]
operator: , [30200,30201]
===
match
---
name: execution_date [5735,5749]
name: execution_date [5749,5763]
===
match
---
trailer [15880,15890]
trailer [15894,15904]
===
match
---
atom_expr [10526,10549]
atom_expr [10540,10563]
===
match
---
trailer [23918,23925]
trailer [24209,24216]
===
match
---
simple_stmt [1970,2008]
simple_stmt [1984,2022]
===
match
---
trailer [27938,27953]
trailer [28229,28244]
===
match
---
name: DagRunType [10526,10536]
name: DagRunType [10540,10550]
===
match
---
operator: , [27904,27905]
operator: , [28195,28196]
===
match
---
atom_expr [23790,23803]
atom_expr [24081,24094]
===
match
---
operator: = [18940,18941]
operator: = [19231,19232]
===
match
---
name: dag_id [27113,27119]
name: dag_id [27404,27410]
===
match
---
simple_stmt [18579,18652]
simple_stmt [18593,18666]
===
match
---
trailer [7133,7140]
trailer [7147,7154]
===
match
---
trailer [25011,25019]
trailer [25302,25310]
===
match
---
lambdef [22849,22873]
lambdef [23140,23164]
===
match
---
name: DR [9926,9928]
name: DR [9940,9942]
===
match
---
name: dag_id [4934,4940]
name: dag_id [4948,4954]
===
match
---
operator: } [10827,10828]
operator: } [10841,10842]
===
match
---
trailer [29895,29909]
trailer [30186,30200]
===
match
---
expr_stmt [3051,3076]
expr_stmt [3065,3090]
===
match
---
funcdef [4752,5084]
funcdef [4766,5098]
===
match
---
name: schedulable_ti_ids [29186,29204]
name: schedulable_ti_ids [29477,29495]
===
match
---
name: get_previous_dagrun [12694,12713]
name: get_previous_dagrun [12708,12727]
===
match
---
operator: = [6844,6845]
operator: = [6858,6859]
===
match
---
trailer [18226,18232]
trailer [18240,18246]
===
match
---
trailer [7176,7180]
trailer [7190,7194]
===
match
---
operator: = [4487,4488]
operator: = [4501,4502]
===
match
---
atom_expr [23364,23383]
atom_expr [23655,23674]
===
match
---
name: tis [15594,15597]
name: tis [15608,15611]
===
match
---
suite [26027,26056]
suite [26318,26347]
===
match
---
atom_expr [25490,25500]
atom_expr [25781,25791]
===
match
---
import_from [2074,2108]
import_from [2088,2122]
===
match
---
name: finished_tasks [19552,19566]
name: finished_tasks [19843,19857]
===
match
---
argument [16983,17001]
argument [16997,17015]
===
match
---
atom_expr [29245,29549]
atom_expr [29536,29840]
===
match
---
name: unfinished_tasks [14958,14974]
name: unfinished_tasks [14972,14988]
===
match
---
name: self [19087,19091]
name: self [19378,19382]
===
match
---
name: nullable [3031,3039]
name: nullable [3045,3053]
===
match
---
name: session [29710,29717]
name: session [30001,30008]
===
match
---
name: count [29164,29169]
name: count [29455,29460]
===
match
---
atom_expr [17405,17433]
atom_expr [17419,17447]
===
match
---
trailer [12886,12893]
trailer [12900,12907]
===
match
---
name: filter [29280,29286]
name: filter [29571,29577]
===
match
---
trailer [13458,13465]
trailer [13472,13479]
===
match
---
suite [16081,16394]
suite [16095,16408]
===
match
---
operator: @ [28004,28005]
operator: @ [28295,28296]
===
match
---
name: ti [28879,28881]
name: ti [29170,29172]
===
match
---
simple_stmt [15513,15561]
simple_stmt [15527,15575]
===
match
---
name: all [20383,20386]
name: all [20674,20677]
===
match
---
decorators [7621,7656]
decorators [7635,7670]
===
match
---
number: 0 [30176,30177]
number: 0 [30467,30468]
===
match
---
name: dag_id [29311,29317]
name: dag_id [29602,29608]
===
match
---
operator: , [25161,25162]
operator: , [25452,25453]
===
match
---
name: cls [27487,27490]
name: cls [27778,27781]
===
match
---
simple_stmt [25227,25298]
simple_stmt [25518,25589]
===
match
---
atom_expr [27788,27988]
atom_expr [28079,28279]
===
match
---
operator: == [12894,12896]
operator: == [12908,12910]
===
match
---
testlist [18249,18274]
testlist [18263,18288]
===
match
---
trailer [7750,7755]
trailer [7764,7769]
===
match
---
operator: -> [8135,8137]
operator: -> [8149,8151]
===
match
---
name: format [4902,4908]
name: format [4916,4922]
===
match
---
atom_expr [11445,11463]
atom_expr [11459,11477]
===
match
---
atom_expr [4204,4217]
atom_expr [4218,4231]
===
match
---
atom_expr [13735,13798]
atom_expr [13749,13812]
===
match
---
suite [20140,20188]
suite [20431,20479]
===
match
---
name: max_number [6734,6744]
name: max_number [6748,6758]
===
match
---
name: dag_id [27103,27109]
name: dag_id [27394,27400]
===
match
---
name: state [11173,11178]
name: state [11187,11192]
===
match
---
atom_expr [9427,9450]
atom_expr [9441,9464]
===
match
---
argument [21115,21144]
argument [21406,21435]
===
match
---
atom_expr [23341,23384]
atom_expr [23632,23675]
===
match
---
atom_expr [22312,22322]
atom_expr [22603,22613]
===
match
---
operator: = [15103,15104]
operator: = [15117,15118]
===
match
---
trailer [18723,18731]
trailer [18758,18766]
===
match
---
operator: = [15321,15322]
operator: = [15335,15336]
===
match
---
name: qry [10494,10497]
name: qry [10508,10511]
===
match
---
name: incr [25461,25465]
name: incr [25752,25756]
===
match
---
operator: , [7335,7336]
operator: , [7349,7350]
===
match
---
trailer [17663,17682]
trailer [17677,17696]
===
match
---
name: session [26493,26500]
name: session [26784,26791]
===
match
---
name: str [4293,4296]
name: str [4307,4310]
===
match
---
name: DagRunType [10658,10668]
name: DagRunType [10672,10682]
===
match
---
atom_expr [11208,11237]
atom_expr [11222,11251]
===
match
---
argument [16310,16334]
argument [16324,16348]
===
match
---
suite [14649,15504]
suite [14663,15518]
===
match
---
name: timezone [1763,1771]
name: timezone [1777,1785]
===
match
---
trailer [22532,22536]
trailer [22823,22827]
===
match
---
operator: = [7844,7845]
operator: = [7858,7859]
===
match
---
operator: , [11930,11931]
operator: , [11944,11945]
===
match
---
name: bool [4139,4143]
name: bool [4153,4157]
===
match
---
suite [2150,2353]
suite [2164,2367]
===
match
---
name: session [7558,7565]
name: session [7572,7579]
===
match
---
name: List [2344,2348]
name: List [2358,2362]
===
match
---
name: state [25192,25197]
name: state [25483,25488]
===
match
---
simple_stmt [23576,23655]
simple_stmt [23867,23946]
===
match
---
operator: , [11629,11630]
operator: , [11643,11644]
===
match
---
argument [4954,4988]
argument [4968,5002]
===
match
---
name: task [25672,25676]
name: task [25963,25967]
===
match
---
fstring_start: f" [12593,12595]
fstring_start: f" [12607,12609]
===
match
---
param [28048,28078]
param [28339,28369]
===
match
---
name: session [6860,6867]
name: session [6874,6881]
===
match
---
or_test [22524,22595]
or_test [22815,22886]
===
match
---
comparison [11219,11236]
comparison [11233,11250]
===
match
---
trailer [11211,11218]
trailer [11225,11232]
===
match
---
name: tis_filter [20371,20381]
name: tis_filter [20662,20672]
===
match
---
atom_expr [7158,7186]
atom_expr [7172,7200]
===
match
---
import_as_names [836,906]
import_as_names [836,906]
===
match
---
trailer [8110,8120]
trailer [8124,8134]
===
match
---
name: is_failure_callback [16310,16329]
name: is_failure_callback [16324,16343]
===
match
---
name: t [18762,18763]
name: t [19053,19054]
===
match
---
name: qry [9703,9706]
name: qry [9717,9720]
===
match
---
trailer [10825,10827]
trailer [10839,10841]
===
match
---
trailer [10254,10260]
trailer [10268,10274]
===
match
---
trailer [11007,11013]
trailer [11021,11027]
===
match
---
string: "Restoring task '%s' which was previously removed from DAG '%s'" [25364,25428]
string: "Restoring task '%s' which was previously removed from DAG '%s'" [25655,25719]
===
match
---
name: execution_date [27239,27253]
name: execution_date [27530,27544]
===
match
---
trailer [2762,2769]
trailer [2776,2783]
===
match
---
trailer [30165,30174]
trailer [30456,30465]
===
match
---
trailer [11796,11803]
trailer [11810,11817]
===
match
---
name: session [18213,18220]
name: session [18227,18234]
===
match
---
name: func [5886,5890]
name: func [5900,5904]
===
match
---
atom_expr [15105,15167]
atom_expr [15119,15181]
===
match
---
trailer [25274,25280]
trailer [25565,25571]
===
match
---
name: get_task_instances [24453,24471]
name: get_task_instances [24744,24762]
===
match
---
atom_expr [3984,3997]
atom_expr [3998,4011]
===
match
---
atom_expr [7469,7479]
atom_expr [7483,7493]
===
match
---
name: session [24480,24487]
name: session [24771,24778]
===
match
---
comparison [12279,12303]
comparison [12293,12317]
===
match
---
name: provide_session [27447,27462]
name: provide_session [27738,27753]
===
match
---
operator: , [5072,5073]
operator: , [5086,5087]
===
match
---
string: """         Determines the overall state of the DagRun based on the state         of its TaskInstances.          :param session: Sqlalchemy ORM Session         :type session: Session         :param execute_callbacks: Should dag callbacks (success/failure, SLA etc) be invoked             directly (default: true) or recorded as a pending request in the ``callback`` property         :type execute_callbacks: bool         :return: Tuple containing tis that can be scheduled in the current loop & `callback` that             needs to be executed         """ [13808,14363]
string: """         Determines the overall state of the DagRun based on the state         of its TaskInstances.          :param session: Sqlalchemy ORM Session         :type session: Session         :param execute_callbacks: Should dag callbacks (success/failure, SLA etc) be invoked             directly (default: true) or recorded as a pending request in the ``callback`` property         :type execute_callbacks: bool         :return: Tuple containing tis that can be scheduled in the current loop & `callback` that             needs to be executed         """ [13822,14377]
===
match
---
trailer [7838,7843]
trailer [7852,7857]
===
match
---
name: unfinished_tasks [2297,2313]
name: unfinished_tasks [2311,2327]
===
match
---
operator: , [5979,5980]
operator: , [5993,5994]
===
match
---
atom_expr [11219,11227]
atom_expr [11233,11241]
===
match
---
if_stmt [20877,21241]
if_stmt [21168,21532]
===
match
---
name: task_instance_mutation_hook [25950,25977]
name: task_instance_mutation_hook [26241,26268]
===
match
---
arglist [15833,15862]
arglist [15847,15876]
===
match
---
name: descriptor [5398,5408]
name: descriptor [5412,5422]
===
match
---
name: tis [11700,11703]
name: tis [11714,11717]
===
match
---
name: state [10885,10890]
name: state [10899,10904]
===
match
---
name: count [29683,29688]
name: count [29974,29979]
===
match
---
atom_expr [16990,17001]
atom_expr [17004,17015]
===
match
---
atom_expr [11804,11837]
atom_expr [11818,11851]
===
match
---
trailer [12307,12322]
trailer [12321,12336]
===
match
---
name: Column [2573,2579]
name: Column [2587,2593]
===
match
---
name: task_id [29074,29081]
name: task_id [29365,29372]
===
match
---
name: schedulable_ti_ids [29117,29135]
name: schedulable_ti_ids [29408,29426]
===
match
---
trailer [9925,9994]
trailer [9939,10008]
===
match
---
name: state [7823,7828]
name: state [7837,7842]
===
match
---
expr_stmt [3503,3749]
expr_stmt [3517,3763]
===
match
---
name: is_ [11640,11643]
name: is_ [11654,11657]
===
match
---
trailer [18689,18694]
trailer [18724,18729]
===
match
---
trailer [2626,2642]
trailer [2640,2656]
===
match
---
name: func [7469,7473]
name: func [7483,7487]
===
match
---
name: TYPE_CHECKING [836,849]
name: TYPE_CHECKING [836,849]
===
match
---
operator: , [17508,17509]
operator: , [17522,17523]
===
match
---
operator: { [12614,12615]
operator: { [12628,12629]
===
match
---
atom_expr [24948,24961]
atom_expr [25239,25252]
===
match
---
expr_stmt [23779,23821]
expr_stmt [24070,24112]
===
match
---
operator: , [11062,11063]
operator: , [11076,11077]
===
match
---
for_stmt [24569,25578]
for_stmt [24860,25869]
===
match
---
annassign [14435,14490]
annassign [14449,14504]
===
match
---
name: ti [24624,24626]
name: ti [24915,24917]
===
match
---
name: state [4601,4606]
name: state [4615,4620]
===
match
---
name: filter [9577,9583]
name: filter [9591,9597]
===
match
---
name: DateTime [5751,5759]
name: DateTime [5765,5773]
===
match
---
name: incr [25829,25833]
name: incr [26120,26124]
===
match
---
fstring_start: f' [26222,26224]
fstring_start: f' [26513,26515]
===
match
---
operator: = [16359,16360]
operator: = [16373,16374]
===
match
---
simple_stmt [1172,1230]
simple_stmt [1172,1230]
===
match
---
suite [22393,22413]
suite [22684,22704]
===
match
---
arglist [15408,15449]
arglist [15422,15463]
===
match
---
operator: , [4940,4941]
operator: , [4954,4955]
===
match
---
atom_expr [13741,13749]
atom_expr [13755,13763]
===
match
---
name: NONE [25543,25547]
name: NONE [25834,25838]
===
match
---
operator: , [3726,3727]
operator: , [3740,3741]
===
match
---
trailer [4733,4735]
trailer [4747,4749]
===
match
---
name: execution_date [17811,17825]
name: execution_date [17825,17839]
===
match
---
name: Session [20640,20647]
name: Session [20931,20938]
===
match
---
name: TI [2349,2351]
name: TI [2363,2365]
===
match
---
operator: , [19328,19329]
operator: , [19619,19620]
===
match
---
argument [20419,20469]
argument [20710,20760]
===
match
---
expr_stmt [20334,20388]
expr_stmt [20625,20679]
===
match
---
name: state [5229,5234]
name: state [5243,5248]
===
match
---
parameters [21323,21343]
parameters [21614,21634]
===
match
---
name: leaf_ti [15743,15750]
name: leaf_ti [15757,15764]
===
match
---
name: dag_id [16995,17001]
name: dag_id [17009,17015]
===
match
---
name: DepContext [19968,19978]
name: DepContext [20259,20269]
===
match
---
number: 1 [25504,25505]
number: 1 [25795,25796]
===
match
---
trailer [4561,4566]
trailer [4575,4580]
===
match
---
suite [11774,11839]
suite [11788,11853]
===
match
---
name: execution_date [27257,27271]
name: execution_date [27548,27562]
===
match
---
suite [13271,13612]
suite [13285,13626]
===
match
---
name: TI [30000,30002]
name: TI [30291,30293]
===
match
---
name: qry [10324,10327]
name: qry [10338,10341]
===
match
---
operator: , [23519,23520]
operator: , [23810,23811]
===
match
---
suite [5202,5324]
suite [5216,5338]
===
match
---
string: 'task_failure' [16360,16374]
string: 'task_failure' [16374,16388]
===
match
---
trailer [20441,20449]
trailer [20732,20740]
===
match
---
operator: == [12323,12325]
operator: == [12337,12339]
===
match
---
name: should_restore_task [25227,25246]
name: should_restore_task [25518,25537]
===
match
---
trailer [20421,20427]
trailer [20712,20718]
===
match
---
name: PickleType [1000,1010]
name: PickleType [1000,1010]
===
match
---
name: self [22558,22562]
name: self [22849,22853]
===
match
---
comparison [5955,5979]
comparison [5969,5993]
===
match
---
trailer [25977,25981]
trailer [26268,26272]
===
match
---
arglist [6899,6966]
arglist [6913,6980]
===
match
---
atom_expr [17758,17769]
atom_expr [17772,17783]
===
match
---
fstring_string: task_removed_from_dag. [25126,25148]
fstring_string: task_removed_from_dag. [25417,25439]
===
match
---
name: state [6062,6067]
name: state [6076,6081]
===
match
---
comparison [23722,23749]
comparison [24013,24040]
===
match
---
name: Boolean [937,944]
name: Boolean [937,944]
===
match
---
name: Iterable [856,864]
name: Iterable [856,864]
===
match
---
name: conf [4161,4165]
name: conf [4175,4179]
===
match
---
name: qry [10567,10570]
name: qry [10581,10584]
===
match
---
name: c [27937,27938]
name: c [28228,28229]
===
match
---
name: self [27383,27387]
name: self [27674,27678]
===
match
---
name: self [11912,11916]
name: self [11926,11930]
===
match
---
trailer [27618,27624]
trailer [27909,27915]
===
match
---
trailer [6953,6966]
trailer [6967,6980]
===
match
---
trailer [26047,26053]
trailer [26338,26344]
===
match
---
argument [2983,2995]
argument [2997,3009]
===
match
---
argument [5034,5072]
argument [5048,5086]
===
match
---
expr_stmt [7423,7480]
expr_stmt [7437,7494]
===
match
---
atom_expr [28879,28915]
atom_expr [29170,29206]
===
match
---
trailer [13110,13119]
trailer [13124,13133]
===
match
---
operator: = [17563,17564]
operator: = [17577,17578]
===
match
---
trailer [15108,15167]
trailer [15122,15181]
===
match
---
name: self [15975,15979]
name: self [15989,15993]
===
match
---
trailer [29258,29262]
trailer [29549,29553]
===
match
---
simple_stmt [21353,22301]
simple_stmt [21644,22592]
===
match
---
name: tis [11428,11431]
name: tis [11442,11445]
===
match
---
operator: , [15856,15857]
operator: , [15870,15871]
===
match
---
atom_expr [3571,3580]
atom_expr [3585,3594]
===
match
---
trailer [10163,10204]
trailer [10177,10218]
===
match
---
atom_expr [24729,24753]
atom_expr [25020,25044]
===
match
---
trailer [25123,25168]
trailer [25414,25459]
===
match
---
name: str [4253,4256]
name: str [4267,4270]
===
match
---
trailer [5251,5260]
trailer [5265,5274]
===
match
---
operator: == [5854,5856]
operator: == [5868,5870]
===
match
---
name: ready_tis [19668,19677]
name: ready_tis [19959,19968]
===
match
---
name: dag_id [23919,23925]
name: dag_id [24210,24216]
===
match
---
operator: = [16949,16950]
operator: = [16963,16964]
===
match
---
operator: , [970,971]
operator: , [970,971]
===
match
---
atom_expr [25777,25789]
atom_expr [26068,26080]
===
match
---
trailer [11710,11731]
trailer [11724,11745]
===
match
---
name: dag [25149,25152]
name: dag [25440,25443]
===
match
---
atom_expr [16269,16288]
atom_expr [16283,16302]
===
match
---
name: finished_tasks [18133,18147]
name: finished_tasks [18147,18161]
===
match
---
name: ti [20419,20421]
name: ti [20710,20712]
===
match
---
name: settings [1523,1531]
name: settings [1537,1545]
===
match
---
argument [15743,15803]
argument [15757,15817]
===
match
---
name: flush [26048,26053]
name: flush [26339,26344]
===
match
---
name: DateTime [5915,5923]
name: DateTime [5929,5937]
===
match
---
trailer [10503,10510]
trailer [10517,10524]
===
match
---
atom_expr [3946,3959]
atom_expr [3960,3973]
===
match
---
name: group_by [27704,27712]
name: group_by [27995,28003]
===
match
---
operator: , [7935,7936]
operator: , [7949,7950]
===
match
---
operator: , [17139,17140]
operator: , [17153,17154]
===
match
---
atom_expr [16221,16232]
atom_expr [16235,16246]
===
match
---
comparison [29819,29859]
comparison [30110,30150]
===
match
---
simple_stmt [25560,25578]
simple_stmt [25851,25869]
===
match
---
tfpdef [20631,20647]
tfpdef [20922,20938]
===
match
---
trailer [7477,7479]
trailer [7491,7493]
===
match
---
simple_stmt [11982,12212]
simple_stmt [11996,12226]
===
match
---
name: schedulable_tis [19297,19312]
name: schedulable_tis [19588,19603]
===
match
---
name: DR [9352,9354]
name: DR [9366,9368]
===
match
---
parameters [13654,13731]
parameters [13668,13745]
===
match
---
operator: , [19504,19505]
operator: , [19795,19796]
===
match
---
name: Optional [4030,4038]
name: Optional [4044,4052]
===
match
---
name: query [27045,27050]
name: query [27336,27341]
===
match
---
trailer [10051,10058]
trailer [10065,10072]
===
match
---
name: TI [29354,29356]
name: TI [29645,29647]
===
match
---
operator: , [7281,7282]
operator: , [7295,7296]
===
match
---
name: foreign_keys [3654,3666]
name: foreign_keys [3668,3680]
===
match
---
operator: == [10444,10446]
operator: == [10458,10460]
===
match
---
operator: , [1064,1065]
operator: , [1064,1065]
===
match
---
name: execution_start_date [10080,10100]
name: execution_start_date [10094,10114]
===
match
---
trailer [11437,11444]
trailer [11451,11458]
===
match
---
name: utils [1731,1736]
name: utils [1745,1750]
===
match
---
string: "Failed to get task '%s' for dag '%s'. Marking it as removed." [25020,25082]
string: "Failed to get task '%s' for dag '%s'. Marking it as removed." [25311,25373]
===
match
---
name: qry [9909,9912]
name: qry [9923,9926]
===
match
---
operator: } [25873,25874]
operator: } [26164,26165]
===
match
---
name: all [15011,15014]
name: all [15025,15028]
===
match
---
name: id [6046,6048]
name: id [6060,6062]
===
match
---
operator: - [23804,23805]
operator: - [24095,24096]
===
match
---
trailer [28886,28915]
trailer [29177,29206]
===
match
---
name: start_date [22790,22800]
name: start_date [23081,23091]
===
match
---
atom_expr [13523,13565]
atom_expr [13537,13579]
===
match
---
name: String [3019,3025]
name: String [3033,3039]
===
match
---
comp_if [22784,22800]
comp_if [23075,23091]
===
match
---
simple_stmt [19668,19693]
simple_stmt [19959,19984]
===
match
---
name: previous_schedule [13527,13544]
name: previous_schedule [13541,13558]
===
match
---
name: get_task [24733,24741]
name: get_task [25024,25032]
===
match
---
name: timezone [2692,2700]
name: timezone [2706,2714]
===
match
---
name: DR [10164,10166]
name: DR [10178,10180]
===
match
---
atom_expr [3592,3609]
atom_expr [3606,3623]
===
match
---
name: TI [29819,29821]
name: TI [30110,30112]
===
match
---
name: relationship [1208,1220]
name: relationship [1208,1220]
===
match
---
name: fallback [3878,3886]
name: fallback [3892,3900]
===
match
---
suite [11185,11238]
suite [11199,11252]
===
match
---
argument [17704,17729]
argument [17718,17743]
===
match
---
simple_stmt [24596,24628]
simple_stmt [24887,24919]
===
match
---
operator: , [7556,7557]
operator: , [7570,7571]
===
match
---
name: NamedTuple [2138,2148]
name: NamedTuple [2152,2162]
===
match
---
trailer [27737,27746]
trailer [28028,28037]
===
match
---
funcdef [3902,4747]
funcdef [3916,4761]
===
match
---
if_stmt [23719,23770]
if_stmt [24010,24061]
===
match
---
name: ext [1135,1138]
name: ext [1135,1138]
===
match
---
atom_expr [18853,18860]
atom_expr [19144,19151]
===
match
---
name: join [27820,27824]
name: join [28111,28115]
===
match
---
expr_stmt [18742,18808]
expr_stmt [19033,19099]
===
match
---
name: default [2684,2691]
name: default [2698,2705]
===
match
---
name: List [27509,27513]
name: List [27800,27804]
===
match
---
name: self [28042,28046]
name: self [28333,28337]
===
match
---
atom_expr [9379,9396]
atom_expr [9393,9410]
===
match
---
name: dag_ids [9526,9533]
name: dag_ids [9540,9547]
===
match
---
argument [16019,16034]
argument [16033,16048]
===
match
---
parameters [10647,10695]
parameters [10661,10709]
===
match
---
comparison [13498,13565]
comparison [13512,13579]
===
match
---
simple_stmt [787,817]
simple_stmt [787,817]
===
match
---
simple_stmt [22729,22802]
simple_stmt [23020,23093]
===
match
---
name: ordered_tis_by_start_date [22814,22839]
name: ordered_tis_by_start_date [23105,23130]
===
match
---
operator: = [27595,27596]
operator: = [27886,27887]
===
match
---
trailer [12254,12258]
trailer [12268,12272]
===
match
---
fstring_end: " [25160,25161]
fstring_end: " [25451,25452]
===
match
---
name: duration [23929,23937]
name: duration [24220,24228]
===
match
---
if_stmt [10213,10271]
if_stmt [10227,10285]
===
match
---
name: DagRun [27232,27238]
name: DagRun [27523,27529]
===
match
---
name: DagRun [13086,13092]
name: DagRun [13100,13106]
===
match
---
expr_stmt [11202,11237]
expr_stmt [11216,11251]
===
match
---
funcdef [12406,12664]
funcdef [12420,12678]
===
match
---
suite [25735,25761]
suite [26026,26052]
===
match
---
name: ti [25899,25901]
name: ti [26190,26192]
===
match
---
trailer [23584,23592]
trailer [23875,23883]
===
match
---
atom [9415,9423]
atom [9429,9437]
===
match
---
trailer [27641,27645]
trailer [27932,27936]
===
match
---
trailer [3432,3490]
trailer [3446,3504]
===
match
---
operator: , [19283,19284]
operator: , [19574,19575]
===
match
---
name: filter [11797,11803]
name: filter [11811,11817]
===
match
---
operator: = [10498,10499]
operator: = [10512,10513]
===
match
---
expr_stmt [11428,11464]
expr_stmt [11442,11478]
===
match
---
trailer [29723,29727]
trailer [30014,30018]
===
match
---
name: dummy_ti_ids [29896,29908]
name: dummy_ti_ids [30187,30199]
===
match
---
return_stmt [21249,21261]
return_stmt [21540,21552]
===
match
---
atom_expr [7706,7715]
atom_expr [7720,7729]
===
match
---
arglist [5844,5980]
arglist [5858,5994]
===
match
---
name: dag_hash [4653,4661]
name: dag_hash [4667,4675]
===
match
---
trailer [3954,3959]
trailer [3968,3973]
===
match
---
and_test [24930,24981]
and_test [25221,25272]
===
match
---
operator: , [20621,20622]
operator: , [20912,20913]
===
match
---
operator: , [2587,2588]
operator: , [2601,2602]
===
match
---
expr_stmt [2568,2606]
expr_stmt [2582,2620]
===
match
---
trailer [29286,29469]
trailer [29577,29760]
===
match
---
param [10670,10694]
param [10684,10708]
===
match
---
expr_stmt [28787,28810]
expr_stmt [29078,29101]
===
match
---
annassign [2313,2323]
annassign [2327,2337]
===
match
---
atom_expr [15955,16035]
atom_expr [15969,16049]
===
match
---
operator: , [12718,12719]
operator: , [12732,12733]
===
match
---
name: Session [8001,8008]
name: Session [8015,8022]
===
match
---
trailer [4512,4529]
trailer [4526,4543]
===
match
---
name: execution_date [29822,29836]
name: execution_date [30113,30127]
===
match
---
atom_expr [18791,18807]
atom_expr [19082,19098]
===
match
---
trailer [16654,16664]
trailer [16668,16678]
===
match
---
simple_stmt [26439,26458]
simple_stmt [26730,26749]
===
match
---
argument [15109,15166]
argument [15123,15180]
===
match
---
trailer [2896,2904]
trailer [2910,2918]
===
match
---
trailer [4933,4940]
trailer [4947,4954]
===
match
---
trailer [3285,3317]
trailer [3299,3331]
===
match
---
operator: } [23925,23926]
operator: } [24216,24217]
===
match
---
arglist [23469,23531]
arglist [23760,23822]
===
match
---
expr_stmt [11694,11731]
expr_stmt [11708,11745]
===
match
---
name: list [9674,9678]
name: list [9688,9692]
===
match
---
name: UtcDateTime [1916,1927]
name: UtcDateTime [1930,1941]
===
match
---
return_stmt [27767,27998]
return_stmt [28058,28289]
===
match
---
comp_op [25790,25796]
comp_op [26081,26087]
===
match
---
string: 'DagRun' [13261,13269]
string: 'DagRun' [13275,13283]
===
match
---
param [7734,7763]
param [7748,7777]
===
match
---
name: DR [10511,10513]
name: DR [10525,10527]
===
match
---
name: max_number [6702,6712]
name: max_number [6716,6726]
===
match
---
decorator [7639,7656]
decorator [7653,7670]
===
match
---
simple_stmt [9567,9605]
simple_stmt [9581,9619]
===
match
---
name: Stats [23456,23461]
name: Stats [23747,23752]
===
match
---
trailer [4744,4746]
trailer [4758,4760]
===
match
---
atom_expr [3012,3046]
atom_expr [3026,3060]
===
match
---
atom_expr [30107,30118]
atom_expr [30398,30409]
===
match
---
if_stmt [9644,9841]
if_stmt [9658,9855]
===
match
---
name: UniqueConstraint [1028,1044]
name: UniqueConstraint [1028,1044]
===
match
---
simple_stmt [15876,15905]
simple_stmt [15890,15919]
===
match
---
name: start_date [23811,23821]
name: start_date [24102,24112]
===
match
---
operator: -> [18371,18373]
operator: -> [18385,18387]
===
match
---
name: creating_job_id [4704,4719]
name: creating_job_id [4718,4733]
===
match
---
atom_expr [19619,19627]
atom_expr [19910,19918]
===
match
---
fstring_expr [10800,10828]
fstring_expr [10814,10842]
===
match
---
name: DR [10059,10061]
name: DR [10073,10075]
===
match
---
simple_stmt [25950,25982]
simple_stmt [26241,26273]
===
match
---
trailer [15765,15779]
trailer [15779,15793]
===
match
---
param [5162,5167]
param [5176,5181]
===
match
---
trailer [7694,7717]
trailer [7708,7731]
===
match
---
name: Column [3213,3219]
name: Column [3227,3233]
===
match
---
operator: = [28774,28775]
operator: = [29065,29066]
===
match
---
operator: , [15979,15980]
operator: , [15993,15994]
===
match
---
name: qry [9573,9576]
name: qry [9587,9590]
===
match
---
atom_expr [14446,14482]
atom_expr [14460,14496]
===
match
---
name: tis [2227,2230]
name: tis [2241,2244]
===
match
---
atom_expr [9714,9751]
atom_expr [9728,9765]
===
match
---
decorated [6084,7616]
decorated [6098,7630]
===
match
---
return_stmt [12220,12400]
return_stmt [12234,12414]
===
match
---
arglist [7241,7336]
arglist [7255,7350]
===
match
---
atom_expr [30049,30062]
atom_expr [30340,30353]
===
match
---
atom [3667,3691]
atom [3681,3705]
===
match
---
simple_stmt [908,1077]
simple_stmt [908,1077]
===
match
---
simple_stmt [6057,6079]
simple_stmt [6071,6093]
===
match
---
trailer [19618,19634]
trailer [19909,19925]
===
match
---
param [4065,4103]
param [4079,4117]
===
match
---
trailer [7223,7350]
trailer [7237,7364]
===
match
---
atom [12866,12976]
atom [12880,12990]
===
match
---
name: leaves [15553,15559]
name: leaves [15567,15573]
===
match
---
atom_expr [17337,17392]
atom_expr [17351,17406]
===
match
---
comp_op [20309,20315]
comp_op [20600,20606]
===
match
---
funcdef [27337,27424]
funcdef [27628,27715]
===
match
---
name: none_task_concurrency [17275,17296]
name: none_task_concurrency [17289,17310]
===
match
---
atom_expr [7788,7806]
atom_expr [7802,7820]
===
match
---
suite [10134,10205]
suite [10148,10219]
===
match
---
name: uselist [3728,3735]
name: uselist [3742,3749]
===
match
---
name: get_latest_runs [27471,27486]
name: get_latest_runs [27762,27777]
===
match
---
name: synchronize_session [29523,29542]
name: synchronize_session [29814,29833]
===
match
---
name: TI [11711,11713]
name: TI [11725,11727]
===
match
---
name: task [25907,25911]
name: task [26198,26202]
===
match
---
expr_stmt [14934,14974]
expr_stmt [14948,14988]
===
match
---
atom_expr [25950,25981]
atom_expr [26241,26272]
===
match
---
suite [15938,16036]
suite [15952,16050]
===
match
---
atom_expr [16650,16679]
atom_expr [16664,16693]
===
match
---
name: and_ [1050,1054]
name: and_ [1050,1054]
===
match
---
arglist [25466,25508]
arglist [25757,25799]
===
match
---
operator: @ [5456,5457]
operator: @ [5470,5471]
===
match
---
name: end_date [30110,30118]
name: end_date [30401,30409]
===
match
---
expr_stmt [3151,3197]
expr_stmt [3165,3211]
===
match
---
decorated [12669,13158]
decorated [12683,13172]
===
match
---
trailer [7256,7281]
trailer [7270,7295]
===
match
---
simple_stmt [12570,12639]
simple_stmt [12584,12653]
===
match
---
name: execution_date [13127,13141]
name: execution_date [13141,13155]
===
match
---
operator: , [892,893]
operator: , [892,893]
===
match
---
operator: , [16754,16755]
operator: , [16768,16769]
===
match
---
name: get_dag [14673,14680]
name: get_dag [14687,14694]
===
match
---
name: end_date [23795,23803]
name: end_date [24086,24094]
===
match
---
name: backref [3709,3716]
name: backref [3723,3730]
===
match
---
operator: = [10419,10420]
operator: = [10433,10434]
===
match
---
name: cls [6138,6141]
name: cls [6152,6155]
===
match
---
trailer [27897,27904]
trailer [28188,28195]
===
match
---
comparison [3571,3590]
comparison [3585,3604]
===
match
---
atom_expr [27509,27523]
atom_expr [27800,27814]
===
match
---
operator: , [13668,13669]
operator: , [13682,13683]
===
match
---
dictorsetmaker [29495,29520]
dictorsetmaker [29786,29811]
===
match
---
comparison [10059,10100]
comparison [10073,10114]
===
match
---
name: execution_date [12929,12943]
name: execution_date [12943,12957]
===
match
---
name: debug [18588,18593]
name: debug [18602,18607]
===
match
---
fstring_string: task_restored_to_dag. [25468,25489]
fstring_string: task_restored_to_dag. [25759,25780]
===
match
---
name: dag_id [3938,3944]
name: dag_id [3952,3958]
===
match
---
name: self [11819,11823]
name: self [11833,11837]
===
match
---
name: session [26040,26047]
name: session [26331,26338]
===
match
---
name: Stats [23992,23997]
name: Stats [24283,24288]
===
match
---
trailer [7214,7223]
trailer [7228,7237]
===
match
---
suite [18395,19467]
suite [18409,19758]
===
match
---
atom_expr [9512,9534]
atom_expr [9526,9548]
===
match
---
tfpdef [12749,12765]
tfpdef [12763,12779]
===
match
---
name: models [2087,2093]
name: models [2101,2107]
===
match
---
name: primary_key [2589,2600]
name: primary_key [2603,2614]
===
match
---
sync_comp_for [22761,22800]
sync_comp_for [23052,23091]
===
match
---
name: session [17564,17571]
name: session [17578,17585]
===
match
---
suite [17618,17939]
suite [17632,17953]
===
match
---
atom_expr [5299,5313]
atom_expr [5313,5327]
===
match
---
trailer [12271,12278]
trailer [12285,12292]
===
match
---
operator: , [16334,16335]
operator: , [16348,16349]
===
match
---
name: airflow [1975,1982]
name: airflow [1989,1996]
===
match
---
expr_stmt [2810,2869]
expr_stmt [2824,2883]
===
match
---
name: failed_states [15766,15779]
name: failed_states [15780,15793]
===
match
---
name: session [19586,19593]
name: session [19877,19884]
===
match
---
name: finished_tasks [19201,19215]
name: finished_tasks [19492,19506]
===
match
---
atom_expr [13760,13796]
atom_expr [13774,13810]
===
match
---
trailer [16597,16602]
trailer [16611,16616]
===
match
---
simple_stmt [1451,1510]
simple_stmt [1465,1524]
===
match
---
expr_stmt [5247,5323]
expr_stmt [5261,5337]
===
match
---
name: Stats [25823,25828]
name: Stats [26114,26119]
===
match
---
name: self [23364,23368]
name: self [23655,23659]
===
match
---
atom_expr [29819,29836]
atom_expr [30110,30127]
===
match
---
fstring [25834,25875]
fstring [26125,26166]
===
match
---
name: dag_id [26511,26517]
name: dag_id [26802,26808]
===
match
---
arglist [3433,3489]
arglist [3447,3503]
===
match
---
trailer [23580,23584]
trailer [23871,23875]
===
match
---
param [5103,5107]
param [5117,5121]
===
match
---
testlist [19776,19798]
testlist [20067,20089]
===
match
---
trailer [15014,15068]
trailer [15028,15082]
===
match
---
name: old_state [19879,19888]
name: old_state [20170,20179]
===
match
---
simple_stmt [25189,25214]
simple_stmt [25480,25505]
===
match
---
fstring_string: Failed to record first_task_scheduling_delay metric:\n [23595,23649]
fstring_string: Failed to record first_task_scheduling_delay metric:\n [23886,23940]
===
match
---
name: execution_date [2647,2661]
name: execution_date [2661,2675]
===
match
---
operator: = [14484,14485]
operator: = [14498,14499]
===
match
---
operator: = [24727,24728]
operator: = [25018,25019]
===
match
---
simple_stmt [20480,20510]
simple_stmt [20771,20801]
===
match
---
operator: = [7565,7566]
operator: = [7579,7580]
===
match
---
name: airflow [2013,2020]
name: airflow [2027,2034]
===
match
---
if_stmt [2052,2109]
if_stmt [2066,2123]
===
match
---
trailer [28999,29019]
trailer [29290,29310]
===
match
---
string: """         Reloads the current dagrun from the database          :param session: database session         :type session: Session         """ [5537,5678]
string: """         Reloads the current dagrun from the database          :param session: database session         :type session: Session         """ [5551,5692]
===
match
---
if_stmt [20295,20471]
if_stmt [20586,20762]
===
match
---
name: Integer [987,994]
name: Integer [987,994]
===
match
---
string: """         Returns the Dag associated with this DagRun.          :return: DAG         """ [12442,12532]
string: """         Returns the Dag associated with this DagRun.          :return: DAG         """ [12456,12546]
===
match
---
atom_expr [4681,4701]
atom_expr [4695,4715]
===
match
---
string: 'scheduler' [3813,3824]
string: 'scheduler' [3827,3838]
===
match
---
operator: , [13749,13750]
operator: , [13763,13764]
===
match
---
argument [3701,3742]
argument [3715,3756]
===
match
---
name: DR [9714,9716]
name: DR [9728,9730]
===
match
---
name: task [28943,28947]
name: task [29234,29238]
===
match
---
name: List [2315,2319]
name: List [2329,2333]
===
match
---
fstring_string: . [26260,26261]
fstring_string: . [26551,26552]
===
match
---
name: List [2262,2266]
name: List [2276,2280]
===
match
---
name: session [16019,16026]
name: session [16033,16040]
===
match
---
operator: } [19658,19659]
operator: } [19949,19950]
===
match
---
name: state [11222,11227]
name: state [11236,11241]
===
match
---
return_stmt [20480,20509]
return_stmt [20771,20800]
===
match
---
operator: = [23788,23789]
operator: = [24079,24080]
===
match
---
name: cast [5725,5729]
name: cast [5739,5743]
===
match
---
atom_expr [14809,14829]
atom_expr [14823,14843]
===
match
---
name: task_id [12350,12357]
name: task_id [12364,12371]
===
match
---
name: state [10264,10269]
name: state [10278,10283]
===
match
---
expr_stmt [14764,14778]
expr_stmt [14778,14792]
===
match
---
name: exc [1093,1096]
name: exc [1093,1096]
===
match
---
trailer [19180,19225]
trailer [19471,19516]
===
match
---
funcdef [24082,26458]
funcdef [24373,26749]
===
match
---
name: get_task_instance [11894,11911]
name: get_task_instance [11908,11925]
===
match
---
operator: = [6745,6746]
operator: = [6759,6760]
===
match
---
name: DagRun [7444,7450]
name: DagRun [7458,7464]
===
match
---
simple_stmt [5118,5137]
simple_stmt [5132,5151]
===
match
---
operator: , [3308,3309]
operator: , [3322,3323]
===
match
---
operator: = [24446,24447]
operator: = [24737,24738]
===
match
---
operator: == [22585,22587]
operator: == [22876,22878]
===
match
---
name: handle_callback [16734,16749]
name: handle_callback [16748,16763]
===
match
---
trailer [10582,10597]
trailer [10596,10611]
===
match
---
tfpdef [6151,6167]
tfpdef [6165,6181]
===
match
---
name: qry [9697,9700]
name: qry [9711,9714]
===
match
---
name: tis [18473,18476]
name: tis [18487,18490]
===
match
---
if_stmt [18888,19226]
if_stmt [19179,19517]
===
match
---
name: sort [22840,22844]
name: sort [23131,23135]
===
match
---
trailer [25573,25577]
trailer [25864,25868]
===
match
---
name: is_failure_callback [17079,17098]
name: is_failure_callback [17093,17112]
===
match
---
argument [2847,2868]
argument [2861,2882]
===
match
---
param [3976,4005]
param [3990,4019]
===
match
---
operator: == [23963,23965]
operator: == [24254,24256]
===
match
---
operator: = [2600,2601]
operator: = [2614,2615]
===
match
---
fstring_string: .first_task_scheduling_delay [23490,23518]
fstring_string: .first_task_scheduling_delay [23781,23809]
===
match
---
trailer [20444,20448]
trailer [20735,20739]
===
match
---
name: airflow [1411,1418]
name: airflow [1425,1432]
===
match
---
suite [11490,11652]
suite [11504,11666]
===
match
---
name: duration [23779,23787]
name: duration [24070,24078]
===
match
---
name: execution_date [10801,10815]
name: execution_date [10815,10829]
===
match
---
suite [10703,10830]
suite [10717,10844]
===
match
---
operator: , [20069,20070]
operator: , [20360,20361]
===
match
---
trailer [20353,20359]
trailer [20644,20650]
===
match
---
name: schedule_interval [22537,22554]
name: schedule_interval [22828,22845]
===
match
---
name: Any [851,854]
name: Any [851,854]
===
match
---
trailer [16825,16849]
trailer [16839,16863]
===
match
---
string: 'Deadlock; marking run %s failed' [17352,17385]
string: 'Deadlock; marking run %s failed' [17366,17399]
===
match
---
name: TI [20618,20620]
name: TI [20909,20911]
===
match
---
operator: , [29394,29395]
operator: , [29685,29686]
===
match
---
name: AirflowException [12576,12592]
name: AirflowException [12590,12606]
===
match
---
name: String [2627,2633]
name: String [2641,2647]
===
match
---
name: dag_ids [9474,9481]
name: dag_ids [9488,9495]
===
match
---
trailer [13740,13798]
trailer [13754,13812]
===
match
---
name: dag [17718,17721]
name: dag [17732,17735]
===
match
---
trailer [19538,19542]
trailer [19829,19833]
===
match
---
fstring [23593,23653]
fstring [23884,23944]
===
match
---
name: State [30010,30015]
name: State [30301,30306]
===
match
---
name: str [4213,4216]
name: str [4227,4230]
===
match
---
if_stmt [9544,9605]
if_stmt [9558,9619]
===
match
---
operator: , [21093,21094]
operator: , [21384,21385]
===
match
---
trailer [12735,12740]
trailer [12749,12754]
===
match
---
name: query [6838,6843]
name: query [6852,6857]
===
match
---
name: dag_id [17751,17757]
name: dag_id [17765,17771]
===
match
---
atom_expr [7444,7465]
atom_expr [7458,7479]
===
match
---
argument [19297,19328]
argument [19588,19619]
===
match
---
name: Session [18355,18362]
name: Session [18369,18376]
===
match
---
name: leaf_tis [15569,15577]
name: leaf_tis [15583,15591]
===
match
---
name: run_id [5973,5979]
name: run_id [5987,5993]
===
match
---
name: _state [3310,3316]
name: _state [3324,3330]
===
match
---
dotted_name [6655,6673]
dotted_name [6669,6687]
===
match
---
simple_stmt [30290,30303]
simple_stmt [30581,30594]
===
match
---
atom_expr [25913,25932]
atom_expr [26204,26223]
===
match
---
atom_expr [4331,4344]
atom_expr [4345,4358]
===
match
---
comparison [29354,29394]
comparison [29645,29685]
===
match
---
operator: , [3966,3967]
operator: , [3980,3981]
===
match
---
comparison [10341,10380]
comparison [10355,10394]
===
match
---
name: now [7474,7477]
name: now [7488,7491]
===
match
---
argument [5002,5020]
argument [5016,5034]
===
match
---
name: TI [28074,28076]
name: TI [28365,28367]
===
match
---
trailer [29790,29797]
trailer [30081,30088]
===
match
---
name: session [25998,26005]
name: session [26289,26296]
===
match
---
or_test [15345,15485]
or_test [15359,15499]
===
match
---
fstring_expr [25148,25160]
fstring_expr [25439,25451]
===
match
---
name: none_task_concurrency [15081,15102]
name: none_task_concurrency [15095,15116]
===
match
---
suite [17324,17939]
suite [17338,17953]
===
match
---
expr_stmt [15569,15629]
expr_stmt [15583,15643]
===
match
---
atom_expr [23576,23654]
atom_expr [23867,23945]
===
match
---
atom [18761,18808]
atom [19052,19099]
===
match
---
trailer [25019,25092]
trailer [25310,25383]
===
match
---
operator: } [26235,26236]
operator: } [26526,26527]
===
match
---
atom_expr [10330,10381]
atom_expr [10344,10395]
===
match
---
name: qry [9915,9918]
name: qry [9929,9932]
===
match
---
try_stmt [24701,25214]
try_stmt [24992,25505]
===
match
---
name: Base [1446,1450]
name: Base [1460,1464]
===
match
---
name: execution_date [9736,9750]
name: execution_date [9750,9764]
===
match
---
simple_stmt [13280,13334]
simple_stmt [13294,13348]
===
match
---
if_stmt [22973,23533]
if_stmt [23264,23824]
===
match
---
name: datetime [8056,8064]
name: datetime [8070,8078]
===
match
---
name: cls [6874,6877]
name: cls [6888,6891]
===
match
---
name: synchronize_session [30222,30241]
name: synchronize_session [30513,30532]
===
match
---
atom_expr [22326,22339]
atom_expr [22617,22630]
===
match
---
trailer [27078,27286]
trailer [27369,27577]
===
match
---
name: dep_context [19956,19967]
name: dep_context [20247,20258]
===
match
---
name: fresh_tis [20334,20343]
name: fresh_tis [20625,20634]
===
match
---
classdef [2111,2353]
classdef [2125,2367]
===
match
---
name: Column [2967,2973]
name: Column [2981,2987]
===
match
---
operator: = [20932,20933]
operator: = [21223,21224]
===
match
---
operator: = [19159,19160]
operator: = [19450,19451]
===
match
---
trailer [9735,9751]
trailer [9749,9765]
===
match
---
operator: += [29689,29691]
operator: += [29980,29982]
===
match
---
name: ti [20442,20444]
name: ti [20733,20735]
===
match
---
name: ut [18950,18952]
name: ut [19241,19243]
===
match
---
operator: , [27954,27955]
operator: , [28245,28246]
===
match
---
atom_expr [14634,14645]
atom_expr [14648,14659]
===
match
---
tfpdef [4112,4144]
tfpdef [4126,4158]
===
match
---
atom_expr [30000,30008]
atom_expr [30291,30299]
===
match
---
name: state [13041,13046]
name: state [13055,13060]
===
match
---
atom_expr [17420,17432]
atom_expr [17434,17446]
===
match
---
name: external_trigger [7860,7876]
name: external_trigger [7874,7890]
===
match
---
import_from [1879,1969]
import_from [1893,1983]
===
match
---
trailer [24423,24431]
trailer [24714,24722]
===
match
---
name: self [26240,26244]
name: self [26531,26535]
===
match
---
except_clause [23541,23562]
except_clause [23832,23853]
===
match
---
expr_stmt [3253,3497]
expr_stmt [3267,3511]
===
match
---
name: tis [14764,14767]
name: tis [14778,14781]
===
match
---
name: self [26289,26293]
name: self [26580,26584]
===
match
---
atom_expr [13348,13362]
atom_expr [13362,13376]
===
match
---
operator: == [29372,29374]
operator: == [29663,29665]
===
match
---
trailer [9437,9450]
trailer [9451,9464]
===
match
---
atom_expr [23479,23489]
atom_expr [23770,23780]
===
match
---
comparison [20419,20449]
comparison [20710,20740]
===
match
---
trailer [9521,9525]
trailer [9535,9539]
===
match
---
simple_stmt [27767,27999]
simple_stmt [28058,28290]
===
match
---
atom_expr [4030,4048]
atom_expr [4044,4062]
===
match
---
expr_stmt [10994,11127]
expr_stmt [11008,11141]
===
match
---
number: 20 [3887,3889]
number: 20 [3901,3903]
===
match
---
name: TI [29724,29726]
name: TI [30015,30017]
===
match
---
name: count [30297,30302]
name: count [30588,30593]
===
match
---
name: session [13393,13400]
name: session [13407,13414]
===
match
---
operator: == [13047,13049]
operator: == [13061,13063]
===
match
---
string: """         Returns the task instance specified by task_id for this dag run          :param task_id: the task id         :type task_id: str         :param session: Sqlalchemy ORM Session         :type session: Session         """ [11982,12211]
string: """         Returns the task instance specified by task_id for this dag run          :param task_id: the task id         :type task_id: str         :param session: Sqlalchemy ORM Session         :type session: Session         """ [11996,12225]
===
match
---
simple_stmt [15955,16036]
simple_stmt [15969,16050]
===
match
---
name: run_id [2874,2880]
name: run_id [2888,2894]
===
match
---
suite [9554,9605]
suite [9568,9619]
===
match
---
testlist_comp [3280,3491]
testlist_comp [3294,3505]
===
match
---
simple_stmt [19235,19467]
simple_stmt [19526,19758]
===
match
---
operator: , [5160,5161]
operator: , [5174,5175]
===
match
---
name: filter [10425,10431]
name: filter [10439,10445]
===
match
---
name: dag [17590,17593]
name: dag [17604,17607]
===
match
---
simple_stmt [10235,10271]
simple_stmt [10249,10285]
===
match
---
operator: = [2571,2572]
operator: = [2585,2586]
===
match
---
operator: } [4578,4579]
operator: } [4592,4593]
===
match
---
decorator [5329,5344]
decorator [5343,5358]
===
match
---
name: run_id [5002,5008]
name: run_id [5016,5022]
===
match
---
operator: = [6203,6204]
operator: = [6217,6218]
===
match
---
comparison [5886,5937]
comparison [5900,5951]
===
match
---
trailer [17042,17057]
trailer [17056,17071]
===
match
---
expr_stmt [2874,2905]
expr_stmt [2888,2919]
===
match
---
trailer [18488,18507]
trailer [18502,18521]
===
match
---
name: last_scheduling_decision [3465,3489]
name: last_scheduling_decision [3479,3503]
===
match
---
trailer [25289,25297]
trailer [25580,25588]
===
match
---
operator: = [18431,18432]
operator: = [18445,18446]
===
match
---
operator: , [10895,10896]
operator: , [10909,10910]
===
match
---
atom_expr [10511,10522]
atom_expr [10525,10536]
===
match
---
name: session [18516,18523]
name: session [18530,18537]
===
match
---
fstring_end: ' [23652,23653]
fstring_end: ' [23943,23944]
===
match
---
name: dag [25088,25091]
name: dag [25379,25382]
===
match
---
suite [26093,26458]
suite [26384,26749]
===
match
---
suite [20864,21241]
suite [21155,21532]
===
match
---
suite [28845,29155]
suite [29136,29446]
===
match
---
operator: , [29332,29333]
operator: , [29623,29624]
===
match
---
name: session [19217,19224]
name: session [19508,19515]
===
match
---
operator: = [3010,3011]
operator: = [3024,3025]
===
match
---
trailer [28073,28077]
trailer [28364,28368]
===
match
---
trailer [15110,15115]
trailer [15124,15129]
===
match
---
trailer [15958,15974]
trailer [15972,15988]
===
match
---
import_from [1406,1450]
import_from [1420,1464]
===
match
---
name: session [13224,13231]
name: session [13238,13245]
===
match
---
arglist [27873,27953]
arglist [28164,28244]
===
match
---
parameters [20537,20654]
parameters [20828,20945]
===
match
---
suite [22474,23533]
suite [22765,23824]
===
match
---
name: execution_date [4431,4445]
name: execution_date [4445,4459]
===
match
---
operator: , [1206,1207]
operator: , [1206,1207]
===
match
---
string: """The previous DagRun, if there is one""" [12805,12847]
string: """The previous DagRun, if there is one""" [12819,12861]
===
match
---
name: finished_tasks [21115,21129]
name: finished_tasks [21406,21420]
===
match
---
argument [19276,19283]
argument [19567,19574]
===
match
---
simple_stmt [19769,19799]
simple_stmt [20060,20090]
===
match
---
simple_stmt [4648,4673]
simple_stmt [4662,4687]
===
match
---
name: changed_tis [2275,2286]
name: changed_tis [2289,2300]
===
match
---
name: unfinished_tasks [18742,18758]
name: unfinished_tasks [19033,19049]
===
match
---
not_test [17301,17323]
not_test [17315,17337]
===
match
---
name: task [28995,28999]
name: task [29286,29290]
===
match
---
simple_stmt [3253,3498]
simple_stmt [3267,3512]
===
match
---
trailer [20167,20175]
trailer [20458,20466]
===
match
---
atom_expr [27037,27307]
atom_expr [27328,27598]
===
match
---
name: self [16269,16273]
name: self [16283,16287]
===
match
---
operator: @ [13617,13618]
operator: @ [13631,13632]
===
match
---
argument [19426,19455]
argument [19717,19746]
===
match
---
simple_stmt [5373,5451]
simple_stmt [5387,5465]
===
match
---
arglist [3571,3627]
arglist [3585,3641]
===
match
---
simple_stmt [24544,24561]
simple_stmt [24835,24852]
===
match
---
if_stmt [16692,17159]
if_stmt [16706,17173]
===
match
---
name: finished_tis [22771,22783]
name: finished_tis [23062,23074]
===
match
---
suite [18908,19226]
suite [19199,19517]
===
match
---
operator: - [23339,23340]
operator: - [23630,23631]
===
match
---
string: 'all_tasks_deadlocked' [17532,17554]
string: 'all_tasks_deadlocked' [17546,17568]
===
match
---
name: session [11000,11007]
name: session [11014,11021]
===
match
---
atom_expr [25350,25438]
atom_expr [25641,25729]
===
match
---
trailer [12659,12663]
trailer [12673,12677]
===
match
---
name: success [15981,15988]
name: success [15995,16002]
===
match
---
decorated [26463,27318]
decorated [26754,27609]
===
match
---
trailer [26053,26055]
trailer [26344,26346]
===
match
---
operator: , [3742,3743]
operator: , [3756,3757]
===
match
---
name: dag_id [12902,12908]
name: dag_id [12916,12922]
===
match
---
return_stmt [4780,5083]
return_stmt [4794,5097]
===
match
---
operator: , [4151,4152]
operator: , [4165,4166]
===
match
---
name: no_backfills [7909,7921]
name: no_backfills [7923,7935]
===
match
---
trailer [7536,7548]
trailer [7550,7562]
===
match
---
parameters [12417,12423]
parameters [12431,12437]
===
match
---
simple_stmt [26581,27008]
simple_stmt [26872,27299]
===
match
---
atom [29692,30280]
atom [29983,30571]
===
match
---
name: session [12241,12248]
name: session [12255,12262]
===
match
---
trailer [25863,25873]
trailer [26154,26164]
===
match
---
trailer [11453,11457]
trailer [11467,11471]
===
match
---
atom_expr [4368,4379]
atom_expr [4382,4393]
===
match
---
operator: == [9594,9596]
operator: == [9608,9610]
===
match
---
operator: } [14645,14646]
operator: } [14659,14660]
===
match
---
name: creating_job_id [2910,2925]
name: creating_job_id [2924,2939]
===
match
---
if_stmt [11741,11839]
if_stmt [11755,11853]
===
match
---
fstring_string: dagrun.duration.failed. [24007,24030]
fstring_string: dagrun.duration.failed. [24298,24321]
===
match
---
trailer [12785,12795]
trailer [12799,12809]
===
match
---
simple_stmt [29218,29564]
simple_stmt [29509,29855]
===
match
---
operator: , [17523,17524]
operator: , [17537,17538]
===
match
---
name: State [25537,25542]
name: State [25828,25833]
===
match
---
atom_expr [9703,9752]
atom_expr [9717,9766]
===
match
---
suite [22441,22461]
suite [22732,22752]
===
match
---
trailer [25205,25213]
trailer [25496,25504]
===
match
---
trailer [20943,21163]
trailer [21234,21454]
===
match
---
trailer [16126,16145]
trailer [16140,16159]
===
match
---
operator: = [30241,30242]
operator: = [30532,30533]
===
match
---
trailer [18483,18570]
trailer [18497,18584]
===
match
---
trailer [11457,11463]
trailer [11471,11477]
===
match
---
name: session [16796,16803]
name: session [16810,16817]
===
match
---
arglist [19276,19456]
arglist [19567,19747]
===
match
---
operator: , [21163,21164]
operator: , [21454,21455]
===
match
---
trailer [7450,7465]
trailer [7464,7479]
===
match
---
trailer [30051,30062]
trailer [30342,30353]
===
match
---
simple_stmt [1567,1599]
simple_stmt [1581,1613]
===
match
---
simple_stmt [23874,23939]
simple_stmt [24165,24230]
===
match
---
argument [7575,7605]
argument [7589,7619]
===
match
---
name: in_ [11610,11613]
name: in_ [11624,11627]
===
match
---
name: filter [9919,9925]
name: filter [9933,9939]
===
match
---
name: tis [18670,18673]
name: tis [18684,18687]
===
match
---
testlist_comp [18835,18878]
testlist_comp [19126,19169]
===
match
---
operator: , [16768,16769]
operator: , [16782,16783]
===
match
---
operator: , [1220,1221]
operator: , [1220,1221]
===
match
---
expr_stmt [10415,10456]
expr_stmt [10429,10470]
===
match
---
sync_comp_for [11535,11554]
sync_comp_for [11549,11568]
===
match
---
name: last_scheduling_decision [3151,3175]
name: last_scheduling_decision [3165,3189]
===
match
---
operator: = [25535,25536]
operator: = [25826,25827]
===
match
---
trailer [26302,26329]
trailer [26593,26620]
===
match
---
atom_expr [19613,19634]
atom_expr [19904,19925]
===
match
---
atom_expr [26142,26276]
atom_expr [26433,26567]
===
match
---
name: dag_id [25494,25500]
name: dag_id [25785,25791]
===
match
---
trailer [11719,11723]
trailer [11733,11737]
===
match
---
suite [7410,7481]
suite [7424,7495]
===
match
---
name: func [1060,1064]
name: func [1060,1064]
===
match
---
expr_stmt [25227,25297]
expr_stmt [25518,25588]
===
match
---
atom_expr [12548,12556]
atom_expr [12562,12570]
===
match
---
name: filter [7087,7093]
name: filter [7101,7107]
===
match
---
atom_expr [12880,12893]
atom_expr [12894,12907]
===
match
---
operator: , [29859,29860]
operator: , [30150,30151]
===
match
---
name: start_date [25677,25687]
name: start_date [25968,25978]
===
match
---
name: dag_id [4382,4388]
name: dag_id [4396,4402]
===
match
---
fstring_start: f' [23469,23471]
fstring_start: f' [23760,23762]
===
match
---
name: execution_date [29380,29394]
name: execution_date [29671,29685]
===
match
---
simple_stmt [11202,11238]
simple_stmt [11216,11252]
===
match
---
name: dag_id [23483,23489]
name: dag_id [23774,23780]
===
match
---
operator: = [28806,28807]
operator: = [29097,29098]
===
match
---
atom_expr [2315,2323]
atom_expr [2329,2337]
===
match
---
simple_stmt [5687,5699]
simple_stmt [5701,5713]
===
match
---
trailer [7710,7715]
trailer [7724,7729]
===
match
---
simple_stmt [14934,14975]
simple_stmt [14948,14989]
===
match
---
name: ti [24810,24812]
name: ti [25101,25103]
===
match
---
name: UtcDateTime [2793,2804]
name: UtcDateTime [2807,2818]
===
match
---
name: Column [2883,2889]
name: Column [2897,2903]
===
match
---
arglist [7253,7298]
arglist [7267,7312]
===
match
---
atom_expr [24031,24042]
atom_expr [24322,24333]
===
match
---
if_stmt [19912,20188]
if_stmt [20203,20479]
===
match
---
expr_stmt [2647,2708]
expr_stmt [2661,2722]
===
match
---
operator: = [15988,15989]
operator: = [16002,16003]
===
match
---
decorator [24061,24078]
decorator [24352,24369]
===
match
---
name: x [11377,11378]
name: x [11391,11392]
===
match
---
name: DR [10252,10254]
name: DR [10266,10268]
===
match
---
trailer [5729,5760]
trailer [5743,5774]
===
match
---
operator: , [17919,17920]
operator: , [17933,17934]
===
match
---
atom_expr [6927,6939]
atom_expr [6941,6953]
===
match
---
arglist [9952,9992]
arglist [9966,10006]
===
match
---
suite [10927,11864]
suite [10941,11878]
===
match
---
operator: = [16795,16796]
operator: = [16809,16810]
===
match
---
operator: = [9571,9572]
operator: = [9585,9586]
===
match
---
name: unfinished_tasks [19379,19395]
name: unfinished_tasks [19670,19686]
===
match
---
name: datetime [4039,4047]
name: datetime [4053,4061]
===
match
---
trailer [26123,26128]
trailer [26414,26419]
===
match
---
atom_expr [28992,29019]
atom_expr [29283,29310]
===
match
---
trailer [5387,5450]
trailer [5401,5464]
===
match
---
operator: = [20176,20177]
operator: = [20467,20468]
===
match
---
simple_stmt [22353,22360]
simple_stmt [22644,22651]
===
match
---
atom_expr [15549,15559]
atom_expr [15563,15573]
===
match
---
name: unfinished_tasks [19396,19412]
name: unfinished_tasks [19687,19703]
===
match
---
operator: , [7299,7300]
operator: , [7313,7314]
===
match
---
decorator [18280,18297]
decorator [18294,18311]
===
match
---
name: finished_tasks [18817,18831]
name: finished_tasks [19108,19122]
===
match
---
expr_stmt [16867,17158]
expr_stmt [16881,17172]
===
match
---
trailer [23482,23489]
trailer [23773,23780]
===
match
---
name: __init__ [3906,3914]
name: __init__ [3920,3928]
===
match
---
simple_stmt [25823,25883]
simple_stmt [26114,26174]
===
match
---
trailer [30079,30081]
trailer [30370,30372]
===
match
---
simple_stmt [1650,1718]
simple_stmt [1664,1732]
===
match
---
name: max [27642,27645]
name: max [27933,27936]
===
match
---
atom_expr [12897,12908]
atom_expr [12911,12922]
===
match
---
atom_expr [14668,14682]
atom_expr [14682,14696]
===
match
---
trailer [25653,25655]
trailer [25944,25946]
===
match
---
operator: , [5432,5433]
operator: , [5446,5447]
===
match
---
operator: , [20496,20497]
operator: , [20787,20788]
===
match
---
operator: , [7573,7574]
operator: , [7587,7588]
===
match
---
trailer [29142,29154]
trailer [29433,29445]
===
match
---
expr_stmt [11787,11838]
expr_stmt [11801,11852]
===
match
---
string: '_state' [5388,5396]
string: '_state' [5402,5410]
===
match
---
trailer [13406,13414]
trailer [13420,13428]
===
match
---
name: SUCCESS [30016,30023]
name: SUCCESS [30307,30314]
===
match
---
operator: > [23431,23432]
operator: > [23722,23723]
===
match
---
name: TISchedulingDecision [18374,18394]
name: TISchedulingDecision [18388,18408]
===
match
---
argument [11377,11401]
argument [11391,11415]
===
match
---
parameters [11911,11956]
parameters [11925,11970]
===
match
---
name: DagRun [27137,27143]
name: DagRun [27428,27434]
===
match
---
expr_stmt [2713,2770]
expr_stmt [2727,2784]
===
match
---
trailer [22839,22844]
trailer [23130,23135]
===
match
---
atom_expr [20157,20175]
atom_expr [20448,20466]
===
match
---
operator: = [24417,24418]
operator: = [24708,24709]
===
match
---
simple_stmt [5537,5679]
simple_stmt [5551,5693]
===
match
---
trailer [15025,15041]
trailer [15039,15055]
===
match
---
name: Optional [884,892]
name: Optional [884,892]
===
match
---
name: finished [5305,5313]
name: finished [5319,5327]
===
match
---
trailer [14774,14778]
trailer [14788,14792]
===
match
---
trailer [23428,23430]
trailer [23719,23721]
===
match
---
atom_expr [27637,27689]
atom_expr [27928,27980]
===
match
---
name: self [4471,4475]
name: self [4485,4489]
===
match
---
name: TI [30049,30051]
name: TI [30340,30342]
===
match
---
simple_stmt [1406,1451]
simple_stmt [1420,1465]
===
match
---
arglist [11038,11117]
arglist [11052,11131]
===
match
---
atom_expr [17718,17729]
atom_expr [17732,17743]
===
match
---
name: first [13150,13155]
name: first [13164,13169]
===
match
---
atom_expr [8102,8120]
atom_expr [8116,8134]
===
match
---
name: callback_requests [1744,1761]
name: callback_requests [1758,1775]
===
match
---
dotted_name [1975,1994]
dotted_name [1989,2008]
===
match
---
name: State [18864,18869]
name: State [19155,19160]
===
match
---
name: changed_tis [15474,15485]
name: changed_tis [15488,15499]
===
match
---
name: self [23952,23956]
name: self [24243,24247]
===
match
---
operator: , [13693,13694]
operator: , [13707,13708]
===
match
---
suite [12796,13158]
suite [12810,13172]
===
match
---
expr_stmt [4508,4548]
expr_stmt [4522,4562]
===
match
---
operator: = [24479,24480]
operator: = [24770,24771]
===
match
---
name: dag_id [12282,12288]
name: dag_id [12296,12302]
===
match
---
trailer [9504,9511]
trailer [9518,9525]
===
match
---
operator: , [19455,19456]
operator: , [19746,19747]
===
match
---
simple_stmt [27586,27759]
simple_stmt [27877,28050]
===
match
---
atom_expr [24555,24560]
atom_expr [24846,24851]
===
match
---
name: label [27666,27671]
name: label [27957,27962]
===
match
---
suite [23710,24056]
suite [24001,24347]
===
match
---
name: cls [7253,7256]
name: cls [7267,7270]
===
match
---
atom_expr [7830,7843]
atom_expr [7844,7857]
===
match
---
name: dag [16053,16056]
name: dag [16067,16070]
===
match
---
simple_stmt [23309,23385]
simple_stmt [23600,23676]
===
match
---
trailer [14521,14528]
trailer [14535,14542]
===
match
---
trailer [10156,10163]
trailer [10170,10177]
===
match
---
operator: , [849,850]
operator: , [849,850]
===
match
---
name: self [22493,22497]
name: self [22784,22788]
===
match
---
param [20547,20552]
param [20838,20843]
===
match
---
atom [4787,4901]
atom [4801,4915]
===
match
---
not_test [24966,24981]
not_test [25257,25272]
===
match
---
atom_expr [29354,29371]
atom_expr [29645,29662]
===
match
---
name: DagRun [13498,13504]
name: DagRun [13512,13518]
===
match
---
name: self [15858,15862]
name: self [15872,15876]
===
match
---
atom_expr [15876,15904]
atom_expr [15890,15918]
===
match
---
annassign [2342,2352]
annassign [2356,2366]
===
match
---
name: self [16632,16636]
name: self [16646,16650]
===
match
---
expr_stmt [3755,3896]
expr_stmt [3769,3910]
===
match
---
name: unfinished_tasks [17229,17245]
name: unfinished_tasks [17243,17259]
===
match
---
name: self [5103,5107]
name: self [5117,5121]
===
match
---
trailer [11603,11609]
trailer [11617,11623]
===
match
---
name: query [29253,29258]
name: query [29544,29549]
===
match
---
name: SHUTDOWN [18558,18566]
name: SHUTDOWN [18572,18580]
===
match
---
simple_stmt [2647,2709]
simple_stmt [2661,2723]
===
match
---
trailer [6037,6040]
trailer [6051,6054]
===
match
---
trailer [24732,24741]
trailer [25023,25032]
===
match
---
arglist [16167,16375]
arglist [16181,16389]
===
match
---
string: 'execution_date' [3354,3370]
string: 'execution_date' [3368,3384]
===
match
---
operator: = [7596,7597]
operator: = [7610,7611]
===
match
---
name: schedulable_tis [19130,19145]
name: schedulable_tis [19421,19436]
===
match
---
operator: = [16107,16108]
operator: = [16121,16122]
===
match
---
operator: , [899,900]
operator: , [899,900]
===
match
---
name: provide_session [13164,13179]
name: provide_session [13178,13193]
===
match
---
name: DagCallbackRequest [17664,17682]
name: DagCallbackRequest [17678,17696]
===
match
---
name: utils [2021,2026]
name: utils [2035,2040]
===
match
---
atom_expr [25272,25280]
atom_expr [25563,25571]
===
match
---
name: DagRun [13120,13126]
name: DagRun [13134,13140]
===
match
---
operator: = [3708,3709]
operator: = [3722,3723]
===
match
---
dotted_name [1655,1690]
dotted_name [1669,1704]
===
match
---
expr_stmt [2775,2805]
expr_stmt [2789,2819]
===
match
---
name: success_states [16536,16550]
name: success_states [16550,16564]
===
match
---
name: success [16756,16763]
name: success [16770,16777]
===
match
---
trailer [4401,4408]
trailer [4415,4422]
===
match
---
name: DR [9512,9514]
name: DR [9526,9528]
===
match
---
name: task_instances [3503,3517]
name: task_instances [3517,3531]
===
match
---
name: State [24948,24953]
name: State [25239,25244]
===
match
---
name: airflow [1723,1730]
name: airflow [1737,1744]
===
match
---
arglist [12279,12368]
arglist [12293,12382]
===
match
---
return_stmt [19235,19466]
return_stmt [19526,19757]
===
match
---
name: task [25625,25629]
name: task [25916,25920]
===
match
---
operator: , [15424,15425]
operator: , [15438,15439]
===
match
---
name: self [17405,17409]
name: self [17419,17423]
===
match
---
annassign [2230,2240]
annassign [2244,2254]
===
match
---
operator: != [5193,5195]
operator: != [5207,5209]
===
match
---
name: ALLOW_FUTURE_EXEC_DATES [7386,7409]
name: ALLOW_FUTURE_EXEC_DATES [7400,7423]
===
match
---
operator: == [22323,22325]
operator: == [22614,22616]
===
match
---
atom_expr [27887,27904]
atom_expr [28178,28195]
===
match
---
name: e [23561,23562]
name: e [23852,23853]
===
match
---
operator: = [20344,20345]
operator: = [20635,20636]
===
match
---
suite [25656,26014]
suite [25947,26305]
===
match
---
name: run_type [4631,4639]
name: run_type [4645,4653]
===
match
---
param [19586,19603]
param [19877,19894]
===
match
---
atom [25249,25267]
atom [25540,25558]
===
match
---
simple_stmt [20157,20188]
simple_stmt [20448,20479]
===
match
---
number: 50 [2842,2844]
number: 50 [2856,2858]
===
match
---
name: leaf_task_ids [15513,15526]
name: leaf_task_ids [15527,15540]
===
match
---
operator: , [20990,20991]
operator: , [21281,21282]
===
match
---
operator: { [24030,24031]
operator: { [24321,24322]
===
match
---
dotted_name [1572,1585]
dotted_name [1586,1599]
===
match
---
trailer [24431,24433]
trailer [24722,24724]
===
match
---
name: DagCallbackRequest [16127,16145]
name: DagCallbackRequest [16141,16159]
===
match
---
name: qry [9373,9376]
name: qry [9387,9390]
===
match
---
atom_expr [4615,4628]
atom_expr [4629,4642]
===
match
---
name: DR [9584,9586]
name: DR [9598,9600]
===
match
---
import_from [1230,1272]
import_from [1230,1272]
===
match
---
string: "number of tis tasks for %s: %s task(s)" [18594,18634]
string: "number of tis tasks for %s: %s task(s)" [18608,18648]
===
match
---
atom_expr [27611,27748]
atom_expr [27902,28039]
===
match
---
atom_expr [7497,7615]
atom_expr [7511,7629]
===
match
---
name: FAILED [17426,17432]
name: FAILED [17440,17446]
===
match
---
operator: = [19279,19280]
operator: = [19570,19571]
===
match
---
operator: , [17001,17002]
operator: , [17015,17016]
===
match
---
name: execution_end_date [9877,9895]
name: execution_end_date [9891,9909]
===
match
---
argument [15981,15994]
argument [15995,16008]
===
match
---
expr_stmt [24722,24753]
expr_stmt [25013,25044]
===
match
---
name: dag_id [26229,26235]
name: dag_id [26520,26526]
===
match
---
name: dag_ids [9405,9412]
name: dag_ids [9419,9426]
===
match
---
name: count [29218,29223]
name: count [29509,29514]
===
match
---
name: IntegrityError [1104,1118]
name: IntegrityError [1104,1118]
===
match
---
operator: = [24682,24683]
operator: = [24973,24974]
===
match
---
trailer [11078,11093]
trailer [11092,11107]
===
match
---
simple_stmt [14427,14491]
simple_stmt [14441,14505]
===
match
---
simple_stmt [16098,16394]
simple_stmt [16112,16408]
===
match
---
trailer [27982,27986]
trailer [28273,28277]
===
match
---
name: run_id [9547,9553]
name: run_id [9561,9567]
===
match
---
return_stmt [12648,12663]
return_stmt [12662,12677]
===
match
---
atom_expr [5125,5136]
atom_expr [5139,5150]
===
match
---
atom_expr [13072,13157]
atom_expr [13086,13171]
===
match
---
for_stmt [19837,20188]
for_stmt [20128,20479]
===
match
---
name: TI [20250,20252]
name: TI [20541,20543]
===
match
---
trailer [12552,12556]
trailer [12566,12570]
===
match
---
trailer [23592,23654]
trailer [23883,23945]
===
match
---
name: get_dag [22498,22505]
name: get_dag [22789,22796]
===
match
---
tfpdef [4065,4095]
tfpdef [4079,4109]
===
match
---
trailer [29510,29520]
trailer [29801,29811]
===
match
---
name: RUNNING [18057,18064]
name: RUNNING [18071,18078]
===
match
---
tfpdef [3938,3959]
tfpdef [3952,3973]
===
match
---
name: dag_id [25153,25159]
name: dag_id [25444,25450]
===
match
---
name: info [26151,26155]
name: info [26442,26446]
===
match
---
trailer [9928,9943]
trailer [9942,9957]
===
match
---
name: run_id [9587,9593]
name: run_id [9601,9607]
===
match
---
operator: = [2817,2818]
operator: = [2831,2832]
===
match
---
argument [17751,17769]
argument [17765,17783]
===
match
---
name: relationship [3520,3532]
name: relationship [3534,3546]
===
match
---
trailer [6873,6878]
trailer [6887,6892]
===
match
---
param [19514,19543]
param [19805,19834]
===
match
---
argument [30222,30247]
argument [30513,30538]
===
match
---
tfpdef [8025,8065]
tfpdef [8039,8079]
===
match
---
param [8082,8128]
param [8096,8142]
===
match
---
operator: = [4218,4219]
operator: = [4232,4233]
===
match
---
atom_expr [20933,21163]
atom_expr [21224,21454]
===
match
---
trailer [10340,10381]
trailer [10354,10395]
===
match
---
atom_expr [5720,5760]
atom_expr [5734,5774]
===
match
---
name: task_id [25782,25789]
name: task_id [26073,26080]
===
match
---
name: t [18853,18854]
name: t [19144,19145]
===
match
---
name: session [16027,16034]
name: session [16041,16048]
===
match
---
fstring [23887,23927]
fstring [24178,24218]
===
match
---
operator: = [16763,16764]
operator: = [16777,16778]
===
match
---
argument [3031,3045]
argument [3045,3059]
===
match
---
dotted_name [2079,2097]
dotted_name [2093,2111]
===
match
---
trailer [7385,7409]
trailer [7399,7423]
===
match
---
simple_stmt [7423,7481]
simple_stmt [7437,7495]
===
match
---
operator: == [13520,13522]
operator: == [13534,13536]
===
match
---
trailer [24953,24961]
trailer [25244,25252]
===
match
---
name: Stats [25113,25118]
name: Stats [25404,25409]
===
match
---
atom_expr [9584,9593]
atom_expr [9598,9607]
===
match
---
name: set_state [18041,18050]
name: set_state [18055,18064]
===
match
---
trailer [17419,17433]
trailer [17433,17447]
===
match
---
name: session [13072,13079]
name: session [13086,13093]
===
match
---
operator: == [10361,10363]
operator: == [10375,10377]
===
match
---
simple_stmt [18213,18233]
simple_stmt [18227,18247]
===
match
---
operator: = [12741,12742]
operator: = [12755,12756]
===
match
---
trailer [13544,13565]
trailer [13558,13579]
===
match
---
operator: , [17554,17555]
operator: , [17568,17569]
===
match
---
name: external_trigger [5056,5072]
name: external_trigger [5070,5086]
===
match
---
name: DR [5803,5805]
name: DR [5817,5819]
===
match
---
operator: { [23649,23650]
operator: { [23940,23941]
===
match
---
trailer [3064,3076]
trailer [3078,3090]
===
match
---
atom_expr [7431,7480]
atom_expr [7445,7494]
===
match
---
suite [23979,24056]
suite [24270,24347]
===
match
---
trailer [17345,17351]
trailer [17359,17365]
===
match
---
if_stmt [10390,10457]
if_stmt [10404,10471]
===
match
---
name: datetime [792,800]
name: datetime [792,800]
===
match
---
name: Session [24118,24125]
name: Session [24409,24416]
===
match
---
atom_expr [26439,26457]
atom_expr [26730,26748]
===
match
---
expr_stmt [16098,16393]
expr_stmt [16112,16407]
===
match
---
name: keys [20279,20283]
name: keys [20570,20574]
===
match
---
atom_expr [27873,27883]
atom_expr [28164,28174]
===
match
---
name: state [4197,4202]
name: state [4211,4216]
===
match
---
operator: = [11949,11950]
operator: = [11963,11964]
===
match
---
name: tis [19276,19279]
name: tis [19567,19570]
===
match
---
name: msg [17126,17129]
name: msg [17140,17143]
===
match
---
name: query [11008,11013]
name: query [11022,11027]
===
match
---
expr_stmt [18687,18732]
expr_stmt [18722,18767]
===
match
---
argument [19342,19365]
argument [19633,19656]
===
match
---
trailer [24652,24664]
trailer [24943,24955]
===
match
---
trailer [11703,11710]
trailer [11717,11724]
===
match
---
name: List [7706,7710]
name: List [7720,7724]
===
match
---
operator: = [19440,19441]
operator: = [19731,19732]
===
match
---
simple_stmt [2227,2241]
simple_stmt [2241,2255]
===
match
---
name: timer [14601,14606]
name: timer [14615,14620]
===
match
---
name: reason [15996,16002]
name: reason [16010,16016]
===
match
---
operator: , [20004,20005]
operator: , [20295,20296]
===
match
---
operator: @ [27429,27430]
operator: @ [27720,27721]
===
match
---
trailer [18220,18226]
trailer [18234,18240]
===
match
---
expr_stmt [27586,27758]
expr_stmt [27877,28049]
===
match
---
simple_stmt [11515,11556]
simple_stmt [11529,11570]
===
match
---
name: subquery [27586,27594]
name: subquery [27877,27885]
===
match
---
name: no_backfills [10468,10480]
name: no_backfills [10482,10494]
===
match
---
name: State [5299,5304]
name: State [5313,5318]
===
match
---
comparison [15743,15779]
comparison [15757,15793]
===
match
---
name: sqlalchemy [1177,1187]
name: sqlalchemy [1177,1187]
===
match
---
param [28079,28102]
param [28370,28393]
===
match
---
name: UniqueConstraint [3327,3343]
name: UniqueConstraint [3341,3357]
===
match
---
simple_stmt [3001,3047]
simple_stmt [3015,3061]
===
match
---
name: session [5503,5510]
name: session [5517,5524]
===
match
---
name: start_date [30052,30062]
name: start_date [30343,30353]
===
match
---
trailer [2633,2641]
trailer [2647,2655]
===
match
---
atom_expr [25455,25509]
atom_expr [25746,25800]
===
match
---
tfpdef [13224,13240]
tfpdef [13238,13254]
===
match
---
name: self [5857,5861]
name: self [5871,5875]
===
match
---
fstring_end: " [12636,12637]
fstring_end: " [12650,12651]
===
match
---
operator: -> [12774,12776]
operator: -> [12788,12790]
===
match
---
atom_expr [11038,11047]
atom_expr [11052,11061]
===
match
---
simple_stmt [4780,5084]
simple_stmt [4794,5098]
===
match
---
trailer [26293,26297]
trailer [26584,26588]
===
match
---
operator: = [2881,2882]
operator: = [2895,2896]
===
match
---
if_stmt [11159,11732]
if_stmt [11173,11746]
===
match
---
trailer [27716,27723]
trailer [28007,28014]
===
match
---
atom [6846,7360]
atom [6860,7374]
===
match
---
trailer [23886,23938]
trailer [24177,24229]
===
match
---
name: on_success_callback [29000,29019]
name: on_success_callback [29291,29310]
===
match
---
trailer [25646,25653]
trailer [25937,25944]
===
match
---
param [22856,22858]
param [23147,23149]
===
match
---
fstring_string: The DAG (.dag) for  [12595,12614]
fstring_string: The DAG (.dag) for  [12609,12628]
===
match
---
trailer [24471,24488]
trailer [24762,24779]
===
match
---
trailer [13100,13110]
trailer [13114,13124]
===
match
---
comparison [25272,25297]
comparison [25563,25588]
===
match
---
fstring_end: " [25501,25502]
fstring_end: " [25792,25793]
===
match
---
operator: , [19412,19413]
operator: , [19703,19704]
===
match
---
name: state [22317,22322]
name: state [22608,22613]
===
match
---
expr_stmt [15081,15167]
expr_stmt [15095,15181]
===
match
---
tfpdef [4014,4048]
tfpdef [4028,4062]
===
match
---
name: settings [7377,7385]
name: settings [7391,7399]
===
match
---
name: dag [25434,25437]
name: dag [25725,25728]
===
match
---
string: 'success' [16777,16786]
string: 'success' [16791,16800]
===
match
---
name: Optional [7788,7796]
name: Optional [7802,7810]
===
match
---
name: Session [5512,5519]
name: Session [5526,5533]
===
match
---
atom_expr [29051,29082]
atom_expr [29342,29373]
===
match
---
name: add [26006,26009]
name: add [26297,26300]
===
match
---
name: self [23914,23918]
name: self [24205,24209]
===
match
---
atom_expr [6747,6777]
atom_expr [6761,6791]
===
match
---
name: Stats [14595,14600]
name: Stats [14609,14614]
===
match
---
trailer [16273,16288]
trailer [16287,16302]
===
match
---
name: List [18422,18426]
name: List [18436,18440]
===
match
---
dictorsetmaker [15530,15559]
dictorsetmaker [15544,15573]
===
match
---
operator: , [12303,12304]
operator: , [12317,12318]
===
match
---
name: execution_date [12308,12322]
name: execution_date [12322,12336]
===
match
---
atom_expr [4929,4940]
atom_expr [4943,4954]
===
match
---
simple_stmt [24442,24489]
simple_stmt [24733,24780]
===
match
---
simple_stmt [2155,2222]
simple_stmt [2169,2236]
===
match
---
name: State [6912,6917]
name: State [6926,6931]
===
match
---
name: timezone [30064,30072]
name: timezone [30355,30363]
===
match
---
trailer [22946,22949]
trailer [23237,23240]
===
match
---
expr_stmt [4471,4499]
expr_stmt [4485,4513]
===
match
---
trailer [3219,3231]
trailer [3233,3245]
===
match
---
name: dag [24413,24416]
name: dag [24704,24707]
===
match
---
operator: = [19967,19968]
operator: = [20258,20259]
===
match
---
atom_expr [25526,25534]
atom_expr [25817,25825]
===
match
---
suite [25806,26014]
suite [26097,26305]
===
match
---
operator: , [25428,25429]
operator: , [25719,25720]
===
match
---
name: first_start_date [22902,22918]
name: first_start_date [23193,23209]
===
match
---
atom_expr [11586,11651]
atom_expr [11600,11665]
===
match
---
if_stmt [23830,24056]
if_stmt [24121,24347]
===
match
---
trailer [11639,11643]
trailer [11653,11657]
===
match
---
name: dag_id [17763,17769]
name: dag_id [17777,17783]
===
match
---
trailer [19917,19938]
trailer [20208,20229]
===
match
---
trailer [27703,27712]
trailer [27994,28003]
===
match
---
fstring_expr [26239,26260]
fstring_expr [26530,26551]
===
match
---
trailer [27824,27969]
trailer [28115,28260]
===
match
---
sync_comp_for [20450,20469]
sync_comp_for [20741,20760]
===
match
---
fstring_end: ' [24043,24044]
fstring_end: ' [24334,24335]
===
match
---
string: 'success' [17130,17139]
string: 'success' [17144,17153]
===
match
---
trailer [6750,6777]
trailer [6764,6791]
===
match
---
name: filter [10052,10058]
name: filter [10066,10072]
===
match
---
name: session [7597,7604]
name: session [7611,7618]
===
match
---
trailer [2825,2869]
trailer [2839,2883]
===
match
---
operator: } [24042,24043]
operator: } [24333,24334]
===
match
---
simple_stmt [6650,6690]
simple_stmt [6664,6704]
===
match
---
atom_expr [18864,18878]
atom_expr [19155,19169]
===
match
---
operator: , [19091,19092]
operator: , [19382,19383]
===
match
---
name: log [16594,16597]
name: log [16608,16611]
===
match
---
simple_stmt [12648,12664]
simple_stmt [12662,12678]
===
match
---
name: orm [1246,1249]
name: orm [1246,1249]
===
match
---
name: dag_id [3302,3308]
name: dag_id [3316,3322]
===
match
---
arglist [3717,3741]
arglist [3731,3755]
===
match
---
operator: = [4345,4346]
operator: = [4359,4360]
===
match
---
tfpdef [10670,10694]
tfpdef [10684,10708]
===
match
---
name: external_trigger [5034,5050]
name: external_trigger [5048,5064]
===
match
---
parameters [28041,28103]
parameters [28332,28394]
===
match
---
trailer [18587,18593]
trailer [18601,18607]
===
match
---
trailer [9706,9713]
trailer [9720,9727]
===
match
---
atom_expr [25537,25547]
atom_expr [25828,25838]
===
match
---
atom_expr [25560,25577]
atom_expr [25851,25868]
===
match
---
comparison [10432,10455]
comparison [10446,10469]
===
match
---
fstring_string:  needs to be set [12620,12636]
fstring_string:  needs to be set [12634,12650]
===
match
---
suite [15252,15504]
suite [15266,15518]
===
match
---
name: get_task_instances [18489,18507]
name: get_task_instances [18503,18521]
===
match
---
name: ID_LEN [2897,2903]
name: ID_LEN [2911,2917]
===
match
---
name: self [12714,12718]
name: self [12728,12732]
===
match
---
name: Tuple [894,899]
name: Tuple [894,899]
===
match
---
decorated [28004,30303]
decorated [28295,30594]
===
match
---
tfpdef [20597,20621]
tfpdef [20888,20912]
===
match
---
trailer [3397,3417]
trailer [3411,3431]
===
match
---
tfpdef [18346,18362]
tfpdef [18360,18376]
===
match
---
suite [2388,30303]
suite [2402,30594]
===
match
---
name: start_date [4489,4499]
name: start_date [4503,4513]
===
match
---
atom_expr [4728,4746]
atom_expr [4742,4760]
===
match
---
atom_expr [6189,6202]
atom_expr [6203,6216]
===
match
---
param [4274,4305]
param [4288,4319]
===
match
---
operator: = [28096,28097]
operator: = [28387,28388]
===
match
---
atom_expr [4508,4529]
atom_expr [4522,4543]
===
match
---
atom_expr [4648,4661]
atom_expr [4662,4675]
===
match
---
name: sqlalchemy [913,923]
name: sqlalchemy [913,923]
===
match
---
atom_expr [5730,5749]
atom_expr [5744,5763]
===
match
---
atom_expr [6899,6908]
atom_expr [6913,6922]
===
match
---
name: unfinished_tasks [15718,15734]
name: unfinished_tasks [15732,15748]
===
match
---
name: state [6903,6908]
name: state [6917,6922]
===
match
---
import_from [908,1076]
import_from [908,1076]
===
match
---
trailer [14445,14483]
trailer [14459,14497]
===
match
---
test [9415,9462]
test [9429,9476]
===
match
---
name: external_trigger [2948,2964]
name: external_trigger [2962,2978]
===
match
---
name: callback_requests [16878,16895]
name: callback_requests [16892,16909]
===
match
---
funcdef [21267,23655]
funcdef [21558,23946]
===
match
---
if_stmt [7370,7481]
if_stmt [7384,7495]
===
match
---
name: __table_args__ [3253,3267]
name: __table_args__ [3267,3281]
===
match
---
name: task_id [29146,29153]
name: task_id [29437,29444]
===
match
---
name: external_trigger [10344,10360]
name: external_trigger [10358,10374]
===
match
---
trailer [25493,25500]
trailer [25784,25791]
===
match
---
simple_stmt [1718,1772]
simple_stmt [1732,1786]
===
match
---
name: external_trigger [10282,10298]
name: external_trigger [10296,10312]
===
match
---
name: self [18227,18231]
name: self [18241,18245]
===
match
---
operator: = [9791,9792]
operator: = [9805,9806]
===
match
---
name: ti [25189,25191]
name: ti [25480,25482]
===
match
---
trailer [5417,5449]
trailer [5431,5463]
===
match
---
name: State [15891,15896]
name: State [15905,15910]
===
match
---
name: filter [9707,9713]
name: filter [9721,9727]
===
match
---
name: join [6981,6985]
name: join [6995,6999]
===
match
---
trailer [26297,26302]
trailer [26588,26593]
===
match
---
atom_expr [15019,15041]
atom_expr [15033,15055]
===
match
---
operator: = [16329,16330]
operator: = [16343,16344]
===
match
---
operator: , [1761,1762]
operator: , [1775,1776]
===
match
---
operator: , [22873,22874]
operator: , [23164,23165]
===
match
---
trailer [12248,12254]
trailer [12262,12268]
===
match
---
trailer [9392,9396]
trailer [9406,9410]
===
match
---
atom_expr [2692,2707]
atom_expr [2706,2721]
===
match
---
name: first_start_date [22976,22992]
name: first_start_date [23267,23283]
===
match
---
return_stmt [19769,19798]
return_stmt [20060,20089]
===
match
---
atom_expr [2883,2905]
atom_expr [2897,2919]
===
match
---
expr_stmt [2245,2270]
expr_stmt [2259,2284]
===
match
---
operator: = [3666,3667]
operator: = [3680,3681]
===
match
---
name: qry [9787,9790]
name: qry [9801,9804]
===
match
---
name: DateTime [962,970]
name: DateTime [962,970]
===
match
---
expr_stmt [4615,4639]
expr_stmt [4629,4653]
===
match
---
arglist [7111,7187]
arglist [7125,7201]
===
match
---
trailer [16145,16393]
trailer [16159,16407]
===
match
---
name: dag_id [16983,16989]
name: dag_id [16997,17003]
===
match
---
argument [19379,19412]
argument [19670,19703]
===
match
---
trailer [26110,26114]
trailer [26401,26405]
===
match
---
name: execution_start_date [8025,8045]
name: execution_start_date [8039,8059]
===
match
---
operator: ** [7575,7577]
operator: ** [7589,7591]
===
match
---
trailer [22562,22566]
trailer [22853,22857]
===
match
---
operator: = [23320,23321]
operator: = [23611,23612]
===
match
---
trailer [11613,11629]
trailer [11627,11643]
===
match
---
argument [16214,16232]
argument [16228,16246]
===
match
---
operator: , [1953,1954]
operator: , [1967,1968]
===
match
---
suite [16713,16805]
suite [16727,16819]
===
match
---
name: DagRunType [27400,27410]
name: DagRunType [27691,27701]
===
match
---
atom_expr [23874,23938]
atom_expr [24165,24229]
===
match
---
atom_expr [3566,3628]
atom_expr [3580,3642]
===
match
---
name: old_states [20431,20441]
name: old_states [20722,20732]
===
match
---
name: tis [18846,18849]
name: tis [19137,19140]
===
match
---
atom_expr [15760,15779]
atom_expr [15774,15793]
===
match
---
trailer [3594,3609]
trailer [3608,3623]
===
match
---
name: all [11858,11861]
name: all [11872,11875]
===
match
---
name: execution_date [17043,17057]
name: execution_date [17057,17071]
===
match
---
atom_expr [30120,30137]
atom_expr [30411,30428]
===
match
---
operator: , [5868,5869]
operator: , [5882,5883]
===
match
---
atom_expr [7253,7281]
atom_expr [7267,7295]
===
match
---
operator: { [26224,26225]
operator: { [26515,26516]
===
match
---
param [21330,21342]
param [21621,21633]
===
match
---
name: self [23576,23580]
name: self [23867,23871]
===
match
---
operator: { [25148,25149]
operator: { [25439,25440]
===
match
---
name: info [25359,25363]
name: info [25650,25654]
===
match
---
comparison [16513,16550]
comparison [16527,16564]
===
match
---
arglist [16936,17140]
arglist [16950,17154]
===
match
---
atom_expr [10801,10827]
atom_expr [10815,10841]
===
match
---
atom_expr [3178,3197]
atom_expr [3192,3211]
===
match
---
name: filter [11704,11710]
name: filter [11718,11724]
===
match
---
name: DAG [2105,2108]
name: DAG [2119,2122]
===
match
---
suite [23750,23770]
suite [24041,24061]
===
match
---
tfpdef [12720,12740]
tfpdef [12734,12754]
===
match
---
name: TI [30163,30165]
name: TI [30454,30456]
===
match
---
atom_expr [18531,18548]
atom_expr [18545,18562]
===
match
---
atom_expr [29143,29153]
atom_expr [29434,29444]
===
match
---
operator: = [7807,7808]
operator: = [7821,7822]
===
match
---
expr_stmt [22729,22801]
expr_stmt [23020,23092]
===
match
---
operator: = [2753,2754]
operator: = [2767,2768]
===
match
---
arith_expr [23322,23384]
arith_expr [23613,23675]
===
match
---
trailer [13126,13141]
trailer [13140,13155]
===
match
---
operator: = [5718,5719]
operator: = [5732,5733]
===
match
---
simple_stmt [12442,12533]
simple_stmt [12456,12547]
===
match
---
comparison [15601,15628]
comparison [15615,15642]
===
match
---
sync_comp_for [18837,18878]
sync_comp_for [19128,19169]
===
match
---
operator: == [5925,5927]
operator: == [5939,5941]
===
match
---
atom_expr [8138,8152]
atom_expr [8152,8166]
===
match
---
name: state [1989,1994]
name: state [2003,2008]
===
match
---
return_stmt [21229,21240]
return_stmt [21520,21531]
===
match
---
name: self [26106,26110]
name: self [26397,26401]
===
match
---
name: full_filepath [16936,16949]
name: full_filepath [16950,16963]
===
match
---
trailer [9943,9951]
trailer [9957,9965]
===
match
---
name: t [18780,18781]
name: t [19071,19072]
===
match
---
name: self [5215,5219]
name: self [5229,5233]
===
match
---
name: dummy_ti_ids [29051,29063]
name: dummy_ti_ids [29342,29354]
===
match
---
simple_stmt [26040,26056]
simple_stmt [26331,26347]
===
match
---
name: self [16750,16754]
name: self [16764,16768]
===
match
---
atom_expr [3381,3417]
atom_expr [3395,3431]
===
match
---
simple_stmt [15081,15168]
simple_stmt [15095,15182]
===
match
---
name: query [7525,7530]
name: query [7539,7544]
===
match
---
name: max_number [7537,7547]
name: max_number [7551,7561]
===
match
---
trailer [30002,30008]
trailer [30293,30299]
===
match
---
trailer [20267,20286]
trailer [20558,20577]
===
match
---
name: ti [18687,18689]
name: ti [18722,18724]
===
match
---
name: str [7839,7842]
name: str [7853,7856]
===
match
---
name: tis [24442,24445]
name: tis [24733,24736]
===
match
---
comparison [10282,10310]
comparison [10296,10324]
===
match
---
name: Index [3280,3285]
name: Index [3294,3299]
===
match
---
atom_expr [2786,2805]
atom_expr [2800,2819]
===
match
---
operator: , [13565,13566]
operator: , [13579,13580]
===
match
---
operator: , [19602,19603]
operator: , [19893,19894]
===
match
---
operator: = [10151,10152]
operator: = [10165,10166]
===
match
---
if_stmt [19730,19799]
if_stmt [20021,20090]
===
match
---
atom_expr [12655,12663]
atom_expr [12669,12677]
===
match
---
operator: == [27254,27256]
operator: == [27545,27547]
===
match
---
trailer [3570,3628]
trailer [3584,3642]
===
match
---
operator: = [15009,15010]
operator: = [15023,15024]
===
match
---
trailer [7129,7133]
trailer [7143,7147]
===
match
---
name: self [25690,25694]
name: self [25981,25985]
===
match
---
operator: = [9377,9378]
operator: = [9391,9392]
===
match
---
suite [23861,23939]
suite [24152,24230]
===
match
---
trailer [17409,17419]
trailer [17423,17433]
===
match
---
name: callback [14427,14435]
name: callback [14441,14449]
===
match
---
atom_expr [7742,7755]
atom_expr [7756,7769]
===
match
---
operator: = [4629,4630]
operator: = [4643,4644]
===
match
---
decorator [7621,7635]
decorator [7635,7649]
===
match
---
name: has_on_failure_callback [17594,17617]
name: has_on_failure_callback [17608,17631]
===
match
---
trailer [24812,24818]
trailer [25103,25109]
===
match
---
name: append [29136,29142]
name: append [29427,29433]
===
match
---
tfpdef [6177,6202]
tfpdef [6191,6216]
===
match
---
name: execution_date [17791,17805]
name: execution_date [17805,17819]
===
match
---
name: task [24677,24681]
name: task [24968,24972]
===
match
---
trailer [22375,22392]
trailer [22666,22683]
===
match
---
argument [29523,29548]
argument [29814,29839]
===
match
---
string: 'Hit IntegrityError while creating the TIs for ' [26173,26221]
string: 'Hit IntegrityError while creating the TIs for ' [26464,26512]
===
match
---
suite [13799,18275]
suite [13813,18289]
===
match
---
operator: = [20413,20414]
operator: = [20704,20705]
===
match
---
name: self [12897,12901]
name: self [12911,12915]
===
match
---
argument [17847,17871]
argument [17861,17885]
===
match
---
trailer [5219,5226]
trailer [5233,5240]
===
match
---
if_stmt [11332,11732]
if_stmt [11346,11746]
===
match
---
import_from [817,906]
import_from [817,906]
===
match
---
operator: -> [10696,10698]
operator: -> [10710,10712]
===
match
---
name: nulls_first [1929,1940]
name: nulls_first [1943,1954]
===
match
---
atom_expr [29786,29797]
atom_expr [30077,30088]
===
match
---
name: first [12383,12388]
name: first [12397,12402]
===
match
---
trailer [5278,5280]
trailer [5292,5294]
===
match
---
operator: -> [26550,26552]
operator: -> [26841,26843]
===
match
---
atom_expr [4077,4095]
atom_expr [4091,4109]
===
match
---
name: update [29487,29493]
name: update [29778,29784]
===
match
---
trailer [2860,2868]
trailer [2874,2882]
===
match
---
name: state [6073,6078]
name: state [6087,6092]
===
match
---
simple_stmt [2810,2870]
simple_stmt [2824,2884]
===
match
---
operator: = [17644,17645]
operator: = [17658,17659]
===
match
---
name: qry [10235,10238]
name: qry [10249,10252]
===
match
---
name: ut [20880,20882]
name: ut [21171,21173]
===
match
---
operator: { [29974,29975]
operator: { [30265,30266]
===
match
---
decorated [27429,27999]
decorated [27720,28290]
===
match
---
operator: = [19312,19313]
operator: = [19603,19604]
===
match
---
comparison [6927,6966]
comparison [6941,6980]
===
match
---
comparison [18976,19007]
comparison [19267,19298]
===
match
---
name: IntegrityError [26071,26085]
name: IntegrityError [26362,26376]
===
match
---
trailer [15896,15903]
trailer [15910,15917]
===
match
---
arglist [29974,30248]
arglist [30265,30539]
===
match
---
import_from [1119,1171]
import_from [1119,1171]
===
match
---
name: state [13050,13055]
name: state [13064,13069]
===
match
---
trailer [10061,10076]
trailer [10075,10090]
===
match
---
suite [24583,25578]
suite [24874,25869]
===
match
---
name: task [15111,15115]
name: task [15125,15129]
===
match
---
simple_stmt [18242,18275]
simple_stmt [18256,18289]
===
match
---
name: state [23838,23843]
name: state [24129,24134]
===
match
---
name: dag_id [27877,27883]
name: dag_id [28168,28174]
===
match
---
if_stmt [22368,22413]
if_stmt [22659,22704]
===
match
---
operator: } [12619,12620]
operator: } [12633,12634]
===
match
---
atom_expr [16530,16550]
atom_expr [16544,16564]
===
match
---
subscriptlist [7701,7715]
subscriptlist [7715,7729]
===
match
---
name: ti [25574,25576]
name: ti [25865,25867]
===
match
---
trailer [5895,5924]
trailer [5909,5938]
===
match
---
argument [2684,2707]
argument [2698,2721]
===
match
---
operator: , [16017,16018]
operator: , [16031,16032]
===
match
---
operator: { [26239,26240]
operator: { [26530,26531]
===
match
---
and_test [17229,17323]
and_test [17243,17337]
===
match
---
name: TI [11014,11016]
name: TI [11028,11030]
===
match
---
trailer [27305,27307]
trailer [27596,27598]
===
match
---
trailer [5826,5994]
trailer [5840,6008]
===
match
---
name: ti [15581,15583]
name: ti [15595,15597]
===
match
---
simple_stmt [4508,4549]
simple_stmt [4522,4563]
===
match
---
operator: = [5520,5521]
operator: = [5534,5535]
===
match
---
string: 'idx_last_scheduling_decision' [3433,3463]
string: 'idx_last_scheduling_decision' [3447,3477]
===
match
---
atom_expr [22371,22392]
atom_expr [22662,22683]
===
match
---
name: tis [11793,11796]
name: tis [11807,11810]
===
match
---
trailer [15832,15863]
trailer [15846,15877]
===
match
---
if_stmt [23401,23533]
if_stmt [23692,23824]
===
match
---
name: DagModel [7003,7011]
name: DagModel [7017,7025]
===
match
---
trailer [13504,13519]
trailer [13518,13533]
===
match
---
name: key [20445,20448]
name: key [20736,20739]
===
match
---
name: session [20054,20061]
name: session [20345,20352]
===
match
---
atom_expr [26106,26129]
atom_expr [26397,26420]
===
match
---
name: sqlalchemy [1082,1092]
name: sqlalchemy [1082,1092]
===
match
---
operator: * [13101,13102]
operator: * [13115,13116]
===
match
---
atom_expr [5955,5964]
atom_expr [5969,5978]
===
match
---
suite [16850,17159]
suite [16864,17173]
===
match
---
name: finished_tis [22428,22440]
name: finished_tis [22719,22731]
===
match
---
simple_stmt [10415,10457]
simple_stmt [10429,10471]
===
match
---
trailer [22949,22960]
trailer [23240,23251]
===
match
---
name: dag [3237,3240]
name: dag [3251,3254]
===
match
---
operator: = [22919,22920]
operator: = [23210,23211]
===
match
---
simple_stmt [2297,2324]
simple_stmt [2311,2338]
===
match
---
sync_comp_for [18946,19007]
sync_comp_for [19237,19298]
===
match
---
atom_expr [22493,22507]
atom_expr [22784,22798]
===
match
---
trailer [24004,24055]
trailer [24295,24346]
===
match
---
name: info [14856,14860]
name: info [14870,14874]
===
match
---
atom_expr [20250,20286]
atom_expr [20541,20577]
===
match
---
name: log [26294,26297]
name: log [26585,26588]
===
match
---
fstring_string: dagrun. [23471,23478]
fstring_string: dagrun. [23762,23769]
===
match
---
name: State [22326,22331]
name: State [22617,22622]
===
match
---
name: Stats [1593,1598]
name: Stats [1607,1612]
===
match
---
operator: = [14807,14808]
operator: = [14821,14822]
===
match
---
param [7823,7851]
param [7837,7865]
===
match
---
comparison [6899,6925]
comparison [6913,6939]
===
match
---
arith_expr [18531,18568]
arith_expr [18545,18582]
===
match
---
trailer [23461,23468]
trailer [23752,23759]
===
match
---
trailer [13146,13148]
trailer [13160,13162]
===
match
---
fstring_end: ' [23926,23927]
fstring_end: ' [24217,24218]
===
match
---
trailer [20382,20386]
trailer [20673,20677]
===
match
---
trailer [2700,2707]
trailer [2714,2721]
===
match
---
trailer [27628,27635]
trailer [27919,27926]
===
match
---
operator: = [2965,2966]
operator: = [2979,2980]
===
match
---
return_stmt [5373,5450]
return_stmt [5387,5464]
===
match
---
not_test [28988,29019]
not_test [29279,29310]
===
match
---
name: TI [19573,19575]
name: TI [19864,19866]
===
match
---
operator: , [24107,24108]
operator: , [24398,24399]
===
match
---
name: airflow [1604,1611]
name: airflow [1618,1625]
===
match
---
fstring_start: f" [25834,25836]
fstring_start: f" [26125,26127]
===
match
---
funcdef [12690,13158]
funcdef [12704,13172]
===
match
---
operator: , [2845,2846]
operator: , [2859,2860]
===
match
---
name: provide_session [7640,7655]
name: provide_session [7654,7669]
===
match
---
atom_expr [19915,20084]
atom_expr [20206,20375]
===
match
---
atom_expr [18075,18148]
atom_expr [18089,18162]
===
match
---
import_from [1599,1649]
import_from [1613,1663]
===
match
---
atom_expr [10914,10926]
atom_expr [10928,10940]
===
match
---
name: backref [3701,3708]
name: backref [3715,3722]
===
match
---
name: provide_session [13618,13633]
name: provide_session [13632,13647]
===
match
---
name: TI [12279,12281]
name: TI [12293,12295]
===
match
---
name: task_ids [24544,24552]
name: task_ids [24835,24843]
===
match
---
trailer [10598,10602]
trailer [10612,10616]
===
match
---
operator: , [3590,3591]
operator: , [3604,3605]
===
match
---
trailer [13777,13796]
trailer [13791,13810]
===
match
---
simple_stmt [20102,20123]
simple_stmt [20393,20414]
===
match
---
name: in_ [29427,29430]
name: in_ [29718,29721]
===
match
---
trailer [16953,16961]
trailer [16967,16975]
===
match
---
name: qry [9793,9796]
name: qry [9807,9810]
===
match
---
atom_expr [3327,3371]
atom_expr [3341,3385]
===
match
---
name: dag [24970,24973]
name: dag [25261,25264]
===
match
---
fstring_start: f" [25466,25468]
fstring_start: f" [25757,25759]
===
match
---
trailer [6197,6202]
trailer [6211,6216]
===
match
---
operator: = [8009,8010]
operator: = [8023,8024]
===
match
---
name: state [11544,11549]
name: state [11558,11563]
===
match
---
not_test [7373,7409]
not_test [7387,7423]
===
match
---
name: run_type [3001,3009]
name: run_type [3015,3023]
===
match
---
expr_stmt [4648,4672]
expr_stmt [4662,4686]
===
match
---
operator: = [14666,14667]
operator: = [14680,14681]
===
match
---
simple_stmt [12856,12977]
simple_stmt [12870,12991]
===
match
---
operator: == [13466,13468]
operator: == [13480,13482]
===
match
---
operator: -> [20655,20657]
operator: -> [20946,20948]
===
match
---
expr_stmt [3237,3247]
expr_stmt [3251,3261]
===
match
---
operator: @ [5329,5330]
operator: @ [5343,5344]
===
match
---
name: bool [20658,20662]
name: bool [20949,20953]
===
match
---
name: skip_locked [1942,1953]
name: skip_locked [1956,1967]
===
match
---
atom_expr [14539,14568]
atom_expr [14553,14582]
===
match
---
trailer [11218,11237]
trailer [11232,11251]
===
match
---
trailer [25191,25197]
trailer [25482,25488]
===
match
---
atom_expr [19679,19687]
atom_expr [19970,19978]
===
match
---
name: execution_date [29845,29859]
name: execution_date [30136,30150]
===
match
---
trailer [26446,26455]
trailer [26737,26746]
===
match
---
name: execution_date [9616,9630]
name: execution_date [9630,9644]
===
match
---
operator: , [7548,7549]
operator: , [7562,7563]
===
match
---
name: schedulable_ti_ids [29431,29449]
name: schedulable_ti_ids [29722,29740]
===
match
---
atom_expr [18976,18984]
atom_expr [19267,19275]
===
match
---
simple_stmt [9787,9841]
simple_stmt [9801,9855]
===
match
---
name: state [18782,18787]
name: state [19073,19078]
===
match
---
operator: , [15994,15995]
operator: , [16008,16009]
===
match
---
expr_stmt [9352,9363]
expr_stmt [9366,9377]
===
match
---
simple_stmt [14500,14531]
simple_stmt [14514,14545]
===
match
---
name: State [16665,16670]
name: State [16679,16684]
===
match
---
name: ti_deps [1612,1619]
name: ti_deps [1626,1633]
===
match
---
name: qry [10500,10503]
name: qry [10514,10517]
===
match
---
parameters [5357,5363]
parameters [5371,5377]
===
match
---
fstring [12593,12637]
fstring [12607,12651]
===
match
---
suite [22993,23533]
suite [23284,23824]
===
match
---
name: getint [3797,3803]
name: getint [3811,3817]
===
match
---
name: schedulable_tis [2245,2260]
name: schedulable_tis [2259,2274]
===
match
---
operator: = [5008,5009]
operator: = [5022,5023]
===
match
---
decorator [6084,6097]
decorator [6098,6111]
===
match
---
return_stmt [11847,11863]
return_stmt [11861,11877]
===
match
---
argument [16936,16961]
argument [16950,16975]
===
match
---
atom_expr [11000,11127]
atom_expr [11014,11141]
===
match
---
name: Session [13233,13240]
name: Session [13247,13254]
===
match
---
name: partial [11766,11773]
name: partial [11780,11787]
===
match
---
trailer [11748,11752]
trailer [11762,11766]
===
match
---
expr_stmt [6838,7360]
expr_stmt [6852,7374]
===
match
---
name: callback_requests [16109,16126]
name: callback_requests [16123,16140]
===
match
---
import_from [1451,1509]
import_from [1465,1523]
===
match
---
operator: = [16180,16181]
operator: = [16194,16195]
===
match
---
tfpdef [4314,4344]
tfpdef [4328,4358]
===
match
---
name: execution_date [9658,9672]
name: execution_date [9672,9686]
===
match
---
atom_expr [9793,9840]
atom_expr [9807,9854]
===
match
---
name: State [15760,15765]
name: State [15774,15779]
===
match
---
simple_stmt [15818,15864]
simple_stmt [15832,15878]
===
match
---
name: dag_id [29326,29332]
name: dag_id [29617,29623]
===
match
---
name: scheduleable_tasks [19181,19199]
name: scheduleable_tasks [19472,19490]
===
match
---
name: Column [950,956]
name: Column [950,956]
===
match
---
if_stmt [22309,22360]
if_stmt [22600,22651]
===
match
---
name: _emit_duration_stats_for_finished_state [18162,18201]
name: _emit_duration_stats_for_finished_state [18176,18215]
===
match
---
suite [10481,10551]
suite [10495,10565]
===
match
---
arglist [3344,3370]
arglist [3358,3384]
===
match
---
simple_stmt [2568,2607]
simple_stmt [2582,2621]
===
match
---
atom [19657,19659]
atom [19948,19950]
===
match
---
name: schedulable_ti_ids [28787,28805]
name: schedulable_ti_ids [29078,29096]
===
match
---
name: state [11396,11401]
name: state [11410,11415]
===
match
---
name: TI [11219,11221]
name: TI [11233,11235]
===
match
---
name: one [6008,6011]
name: one [6022,6025]
===
match
---
trailer [6011,6013]
trailer [6025,6027]
===
match
---
atom [5775,6023]
atom [5789,6037]
===
match
---
name: Optional [12777,12785]
name: Optional [12791,12799]
===
match
---
simple_stmt [3151,3198]
simple_stmt [3165,3212]
===
match
---
name: self [25718,25722]
name: self [26009,26013]
===
match
---
name: execution_date [10062,10076]
name: execution_date [10076,10090]
===
match
---
atom_expr [10252,10260]
atom_expr [10266,10274]
===
match
---
expr_stmt [14791,14829]
expr_stmt [14805,14843]
===
match
---
name: primaryjoin [3554,3565]
name: primaryjoin [3568,3579]
===
match
---
name: tis [14775,14778]
name: tis [14789,14792]
===
match
---
simple_stmt [19701,19721]
simple_stmt [19992,20012]
===
match
---
name: self [25913,25917]
name: self [26204,26208]
===
match
---
name: get_dag [18702,18709]
name: get_dag [18737,18744]
===
match
---
operator: == [27161,27163]
operator: == [27452,27454]
===
match
---
name: state [10255,10260]
name: state [10269,10274]
===
match
---
trailer [15890,15904]
trailer [15904,15918]
===
match
---
simple_stmt [1077,1119]
simple_stmt [1077,1119]
===
match
---
atom_expr [20415,20470]
atom_expr [20706,20761]
===
match
---
name: self [29840,29844]
name: self [30131,30135]
===
match
---
fstring_expr [12614,12620]
fstring_expr [12628,12634]
===
match
---
trailer [13427,13434]
trailer [13441,13448]
===
match
---
trailer [23363,23384]
trailer [23654,23675]
===
match
---
name: unfinished_tasks [18956,18972]
name: unfinished_tasks [19247,19263]
===
match
---
name: self [14702,14706]
name: self [14716,14720]
===
match
---
argument [15015,15067]
argument [15029,15081]
===
match
---
trailer [11861,11863]
trailer [11875,11877]
===
match
---
suite [15805,16394]
suite [15819,16408]
===
match
---
simple_stmt [12805,12848]
simple_stmt [12819,12862]
===
match
---
name: changed_tis [20498,20509]
name: changed_tis [20789,20800]
===
match
---
atom_expr [20880,21211]
atom_expr [21171,21502]
===
match
---
funcdef [5477,6079]
funcdef [5491,6093]
===
match
---
parameters [23703,23709]
parameters [23994,24000]
===
match
---
name: __repr__ [4756,4764]
name: __repr__ [4770,4778]
===
match
---
decorator [28004,28021]
decorator [28295,28312]
===
match
---
name: typing [822,828]
name: typing [822,828]
===
match
---
operator: = [5227,5228]
operator: = [5241,5242]
===
match
---
trailer [25363,25438]
trailer [25654,25729]
===
match
---
name: state [20422,20427]
name: state [20713,20718]
===
match
---
operator: == [25281,25283]
operator: == [25572,25574]
===
match
---
trailer [18701,18709]
trailer [18736,18744]
===
match
---
name: start_date [4476,4486]
name: start_date [4490,4500]
===
match
---
name: qry [10241,10244]
name: qry [10255,10258]
===
match
---
name: SUCCESS [23853,23860]
name: SUCCESS [24144,24151]
===
match
---
expr_stmt [15513,15560]
expr_stmt [15527,15574]
===
match
---
name: models [1419,1425]
name: models [1433,1439]
===
match
---
simple_stmt [24677,24689]
simple_stmt [24968,24980]
===
match
---
name: has_on_success_callback [16826,16849]
name: has_on_success_callback [16840,16863]
===
match
---
name: task [25250,25254]
name: task [25541,25545]
===
match
---
name: dag [11824,11827]
name: dag [11838,11841]
===
match
---
name: staticmethod [10611,10623]
name: staticmethod [10625,10637]
===
match
---
name: filter [5820,5826]
name: filter [5834,5840]
===
match
---
name: State [24822,24827]
name: State [25113,25118]
===
match
---
name: execution_date [29357,29371]
name: execution_date [29648,29662]
===
match
---
operator: , [1073,1074]
operator: , [1073,1074]
===
match
---
name: qry [10048,10051]
name: qry [10062,10065]
===
match
---
operator: != [10523,10525]
operator: != [10537,10539]
===
match
---
atom_expr [29308,29317]
atom_expr [29599,29608]
===
match
---
expr_stmt [2910,2943]
expr_stmt [2924,2957]
===
match
---
operator: = [14951,14952]
operator: = [14965,14966]
===
match
---
atom_expr [25149,25159]
atom_expr [25440,25450]
===
match
---
operator: , [3406,3407]
operator: , [3420,3421]
===
match
---
name: run_id [3976,3982]
name: run_id [3990,3996]
===
match
---
operator: = [9355,9356]
operator: = [9369,9370]
===
match
---
simple_stmt [1829,1879]
simple_stmt [1843,1893]
===
match
---
trailer [22566,22584]
trailer [22857,22875]
===
match
---
name: self [10879,10883]
name: self [10893,10897]
===
match
---
name: filter [11438,11444]
name: filter [11452,11458]
===
match
---
simple_stmt [26289,26330]
simple_stmt [26580,26621]
===
match
---
tfpdef [20561,20587]
tfpdef [20852,20878]
===
match
---
tfpdef [10648,10668]
tfpdef [10662,10682]
===
match
---
simple_stmt [12220,12401]
simple_stmt [12234,12415]
===
match
---
expr_stmt [19644,19659]
expr_stmt [19935,19950]
===
match
---
annassign [2286,2292]
annassign [2300,2306]
===
match
---
suite [6217,7616]
suite [6231,7630]
===
match
---
simple_stmt [24413,24434]
simple_stmt [24704,24725]
===
match
---
name: datetime [26540,26548]
name: datetime [26831,26839]
===
match
---
atom_expr [5886,5924]
atom_expr [5900,5938]
===
match
---
trailer [2792,2805]
trailer [2806,2819]
===
match
---
name: execution_date [9717,9731]
name: execution_date [9731,9745]
===
match
---
trailer [19938,20084]
trailer [20229,20375]
===
match
---
comparison [10252,10269]
comparison [10266,10283]
===
match
---
name: execution_date [4974,4988]
name: execution_date [4988,5002]
===
match
---
name: set_state [15881,15890]
name: set_state [15895,15904]
===
match
---
name: Column [2786,2792]
name: Column [2800,2806]
===
match
---
arglist [3813,3890]
arglist [3827,3904]
===
match
---
name: dag [23341,23344]
name: dag [23632,23635]
===
match
---
operator: @ [27446,27447]
operator: @ [27737,27738]
===
match
---
param [4161,4188]
param [4175,4202]
===
match
---
argument [24472,24487]
argument [24763,24778]
===
match
---
operator: -> [27359,27361]
operator: -> [27650,27652]
===
match
---
name: scheduleable_tasks [19097,19115]
name: scheduleable_tasks [19388,19406]
===
match
---
operator: = [11530,11531]
operator: = [11544,11545]
===
match
---
trailer [4685,4701]
trailer [4699,4715]
===
match
---
comparison [25777,25805]
comparison [26068,26096]
===
match
---
atom_expr [13751,13797]
atom_expr [13765,13811]
===
match
---
operator: , [882,883]
operator: , [882,883]
===
match
---
name: str [11180,11183]
name: str [11194,11197]
===
match
---
string: 'DagRun' [12786,12794]
string: 'DagRun' [12800,12808]
===
match
---
trailer [27143,27160]
trailer [27434,27451]
===
match
---
parameters [7668,8134]
parameters [7682,8148]
===
match
---
trailer [29775,29782]
trailer [30066,30073]
===
match
---
name: get_dag [13353,13360]
name: get_dag [13367,13374]
===
match
---
name: filter [10334,10340]
name: filter [10348,10354]
===
match
---
operator: == [3610,3612]
operator: == [3624,3626]
===
match
---
operator: = [8121,8122]
operator: = [8135,8136]
===
match
---
atom_expr [5009,5020]
atom_expr [5023,5034]
===
match
---
name: task [28882,28886]
name: task [29173,29177]
===
match
---
string: "DagRun" [8143,8151]
string: "DagRun" [8157,8165]
===
match
---
operator: , [25164,25165]
operator: , [25455,25456]
===
match
---
name: reason [16770,16776]
name: reason [16784,16790]
===
match
---
name: finished_tasks [19426,19440]
name: finished_tasks [19717,19731]
===
match
---
operator: = [14768,14769]
operator: = [14782,14783]
===
match
---
atom_expr [5857,5868]
atom_expr [5871,5882]
===
match
---
operator: , [3463,3464]
operator: , [3477,3478]
===
match
---
name: cls [6899,6902]
name: cls [6913,6916]
===
match
---
tfpdef [24109,24125]
tfpdef [24400,24416]
===
match
---
operator: , [25911,25912]
operator: , [26202,26203]
===
match
---
expr_stmt [5215,5234]
expr_stmt [5229,5248]
===
match
---
trailer [9576,9583]
trailer [9590,9597]
===
match
---
atom_expr [4167,4180]
atom_expr [4181,4194]
===
match
---
trailer [5129,5136]
trailer [5143,5150]
===
match
---
trailer [25636,25646]
trailer [25927,25937]
===
match
---
simple_stmt [23992,24056]
simple_stmt [24283,24347]
===
match
---
operator: = [17757,17758]
operator: = [17771,17772]
===
match
---
comparison [6702,6720]
comparison [6716,6734]
===
match
---
operator: == [7045,7047]
operator: == [7059,7061]
===
match
---
name: dag [22487,22490]
name: dag [22778,22781]
===
match
---
atom_expr [6912,6925]
atom_expr [6926,6939]
===
match
---
atom_expr [13120,13148]
atom_expr [13134,13162]
===
match
---
name: execution_date [10583,10597]
name: execution_date [10597,10611]
===
match
---
name: duration [30166,30174]
name: duration [30457,30465]
===
match
---
operator: = [14900,14901]
operator: = [14914,14915]
===
match
---
param [5156,5161]
param [5170,5175]
===
match
---
decorated [5456,6079]
decorated [5470,6093]
===
match
---
simple_stmt [13808,14364]
simple_stmt [13822,14378]
===
match
---
name: changed_tis [19787,19798]
name: changed_tis [20078,20089]
===
match
---
trailer [25152,25159]
trailer [25443,25450]
===
match
---
name: self [18636,18640]
name: self [18650,18654]
===
match
---
name: cls [27625,27628]
name: cls [27916,27919]
===
match
---
operator: = [4145,4146]
operator: = [4159,4160]
===
match
---
trailer [4212,4217]
trailer [4226,4231]
===
match
---
trailer [29063,29070]
trailer [29354,29361]
===
match
---
name: self [12292,12296]
name: self [12306,12310]
===
match
---
name: TI [25904,25906]
name: TI [26195,26197]
===
match
---
atom_expr [15891,15903]
atom_expr [15905,15917]
===
match
---
name: TI [10923,10925]
name: TI [10937,10939]
===
match
---
operator: , [4187,4188]
operator: , [4201,4202]
===
match
---
name: log [17342,17345]
name: log [17356,17359]
===
match
---
name: int [28107,28110]
name: int [28398,28401]
===
match
---
suite [11973,12401]
suite [11987,12415]
===
match
---
trailer [19035,19117]
trailer [19326,19408]
===
match
---
with_stmt [14590,15504]
with_stmt [14604,15518]
===
match
---
tfpdef [26511,26522]
tfpdef [26802,26813]
===
match
---
operator: , [15440,15441]
operator: , [15454,15455]
===
match
---
operator: , [18640,18641]
operator: , [18654,18655]
===
match
---
operator: = [9499,9500]
operator: = [9513,9514]
===
match
---
expr_stmt [14988,15068]
expr_stmt [15002,15082]
===
match
---
atom_expr [29416,29450]
atom_expr [29707,29741]
===
match
---
argument [3654,3691]
argument [3668,3705]
===
match
---
atom_expr [12347,12357]
atom_expr [12361,12371]
===
match
---
operator: , [1054,1055]
operator: , [1054,1055]
===
match
---
trailer [15020,15025]
trailer [15034,15039]
===
match
---
trailer [22497,22505]
trailer [22788,22796]
===
match
---
operator: , [12345,12346]
operator: , [12359,12360]
===
match
---
atom_expr [18721,18731]
atom_expr [18756,18766]
===
match
---
trailer [25118,25123]
trailer [25409,25414]
===
match
---
trailer [13759,13797]
trailer [13773,13811]
===
match
---
operator: , [13480,13481]
operator: , [13494,13495]
===
match
---
name: state [5196,5201]
name: state [5210,5215]
===
match
---
trailer [27299,27305]
trailer [27590,27596]
===
match
---
trailer [9583,9604]
trailer [9597,9618]
===
match
---
expr_stmt [22902,22960]
expr_stmt [23193,23251]
===
match
---
trailer [18645,18650]
trailer [18659,18664]
===
match
---
return_stmt [13372,13611]
return_stmt [13386,13625]
===
match
---
name: AirflowException [24773,24789]
name: AirflowException [25064,25080]
===
match
---
name: DEFAULT_DAGRUNS_TO_EXAMINE [6751,6777]
name: DEFAULT_DAGRUNS_TO_EXAMINE [6765,6791]
===
match
---
atom_expr [3709,3742]
atom_expr [3723,3756]
===
match
---
name: execution_date [11079,11093]
name: execution_date [11093,11107]
===
match
---
name: execution_date [16274,16288]
name: execution_date [16288,16302]
===
match
---
name: REMOVED [25206,25213]
name: REMOVED [25497,25504]
===
match
---
name: err [26089,26092]
name: err [26380,26383]
===
match
---
name: session [20346,20353]
name: session [20637,20644]
===
match
---
name: self [29786,29790]
name: self [30077,30081]
===
match
---
operator: , [6925,6926]
operator: , [6939,6940]
===
match
---
operator: == [11228,11230]
operator: == [11242,11244]
===
match
---
simple_stmt [8162,9344]
simple_stmt [8176,9358]
===
match
---
trailer [10602,10604]
trailer [10616,10618]
===
match
---
operator: , [4351,4352]
operator: , [4365,4366]
===
match
---
atom_expr [5215,5226]
atom_expr [5229,5240]
===
match
---
name: RUNNING [23742,23749]
name: RUNNING [24033,24040]
===
match
---
operator: = [25198,25199]
operator: = [25489,25490]
===
match
---
operator: , [16961,16962]
operator: , [16975,16976]
===
match
---
suite [5169,5324]
suite [5183,5338]
===
match
---
operator: , [17057,17058]
operator: , [17071,17072]
===
match
---
simple_stmt [25899,25934]
simple_stmt [26190,26225]
===
match
---
name: tis [11787,11790]
name: tis [11801,11804]
===
match
---
expr_stmt [20237,20286]
expr_stmt [20528,20577]
===
match
---
name: t [15109,15110]
name: t [15123,15124]
===
match
---
name: total_seconds [23415,23428]
name: total_seconds [23706,23719]
===
match
---
simple_stmt [24857,24909]
simple_stmt [25148,25200]
===
match
---
simple_stmt [18036,18066]
simple_stmt [18050,18080]
===
match
---
name: get_state [5093,5102]
name: get_state [5107,5116]
===
match
---
trailer [9806,9821]
trailer [9820,9835]
===
match
---
atom_expr [7241,7299]
atom_expr [7255,7313]
===
match
---
name: set_state [5146,5155]
name: set_state [5160,5169]
===
match
---
name: RUNNING [24954,24961]
name: RUNNING [25245,25252]
===
match
---
dotted_name [1723,1736]
dotted_name [1737,1750]
===
match
---
decorator [10610,10624]
decorator [10624,10638]
===
match
---
trailer [18978,18984]
trailer [19269,19275]
===
match
---
trailer [20903,21211]
trailer [21194,21502]
===
match
---
if_stmt [11137,11732]
if_stmt [11151,11746]
===
match
---
arglist [17704,17920]
arglist [17718,17934]
===
match
---
atom_expr [24810,24818]
atom_expr [25101,25109]
===
match
---
arglist [20921,21197]
arglist [21212,21488]
===
match
---
trailer [7166,7176]
trailer [7180,7190]
===
match
---
if_stmt [9849,10205]
if_stmt [9863,10219]
===
match
---
atom_expr [29881,29909]
atom_expr [30172,30200]
===
match
---
name: rollback [26447,26455]
name: rollback [26738,26746]
===
match
---
trailer [27645,27665]
trailer [27936,27956]
===
match
---
atom_expr [26240,26259]
atom_expr [26531,26550]
===
match
---
operator: , [6209,6210]
operator: , [6223,6224]
===
match
---
trailer [27102,27109]
trailer [27393,27400]
===
match
---
name: dag_id [9456,9462]
name: dag_id [9470,9476]
===
match
---
operator: = [10239,10240]
operator: = [10253,10254]
===
match
---
name: self [23806,23810]
name: self [24097,24101]
===
match
---
name: state [29498,29503]
name: state [29789,29794]
===
match
---
simple_stmt [2713,2771]
simple_stmt [2727,2785]
===
match
---
import_as_names [937,1074]
import_as_names [937,1074]
===
match
---
atom_expr [12279,12288]
atom_expr [12293,12302]
===
match
---
arglist [17352,17391]
arglist [17366,17405]
===
match
---
atom_expr [5051,5072]
atom_expr [5065,5086]
===
match
---
trailer [14860,14872]
trailer [14874,14886]
===
match
---
name: dep_context [1620,1631]
name: dep_context [1634,1645]
===
match
---
operator: , [17729,17730]
operator: , [17743,17744]
===
match
---
trailer [11818,11837]
trailer [11832,11851]
===
match
---
simple_stmt [14695,14751]
simple_stmt [14709,14765]
===
match
---
operator: = [4599,4600]
operator: = [4613,4614]
===
match
---
argument [3878,3889]
argument [3892,3903]
===
match
---
trailer [5890,5895]
trailer [5904,5909]
===
match
---
name: or_ [1070,1073]
name: or_ [1070,1073]
===
match
---
name: String [3220,3226]
name: String [3234,3240]
===
match
---
name: session [28079,28086]
name: session [28370,28377]
===
match
---
expr_stmt [18817,18879]
expr_stmt [19108,19170]
===
match
---
trailer [15750,15756]
trailer [15764,15770]
===
match
---
suite [5528,6079]
suite [5542,6093]
===
match
---
name: filter [6892,6898]
name: filter [6906,6912]
===
match
---
operator: @ [6084,6085]
operator: @ [6098,6099]
===
match
---
trailer [16664,16679]
trailer [16678,16693]
===
match
---
name: schedulable_tis [18249,18264]
name: schedulable_tis [18263,18278]
===
match
---
operator: = [2662,2663]
operator: = [2676,2677]
===
match
---
name: set_state [17410,17419]
name: set_state [17424,17433]
===
match
---
operator: = [17531,17532]
operator: = [17545,17546]
===
match
---
atom_expr [11793,11838]
atom_expr [11807,11852]
===
match
---
string: """Generate Run ID based on Run Type and Execution Date""" [10712,10770]
string: """Generate Run ID based on Run Type and Execution Date""" [10726,10784]
===
match
---
name: start_date [22950,22960]
name: start_date [23241,23251]
===
match
---
simple_stmt [29683,30281]
simple_stmt [29974,30572]
===
match
---
atom_expr [6033,6040]
atom_expr [6047,6054]
===
match
---
name: of [7550,7552]
name: of [7564,7566]
===
match
---
atom_expr [20431,20449]
atom_expr [20722,20740]
===
match
---
name: DagRun [5692,5698]
name: DagRun [5706,5712]
===
match
---
name: timing [23462,23468]
name: timing [23753,23759]
===
match
---
simple_stmt [17484,17573]
simple_stmt [17498,17587]
===
match
---
operator: = [3565,3566]
operator: = [3579,3580]
===
match
---
name: execution_date [27910,27924]
name: execution_date [28201,28215]
===
match
---
tfpdef [4274,4297]
tfpdef [4288,4311]
===
match
---
simple_stmt [2245,2271]
simple_stmt [2259,2285]
===
match
---
atom_expr [12946,12965]
atom_expr [12960,12979]
===
match
---
name: self [16589,16593]
name: self [16603,16607]
===
match
---
arglist [5388,5449]
arglist [5402,5463]
===
match
---
trailer [29821,29836]
trailer [30112,30127]
===
match
---
simple_stmt [18473,18571]
simple_stmt [18487,18585]
===
match
---
operator: , [16374,16375]
operator: , [16388,16389]
===
match
---
name: finished [18870,18878]
name: finished [19161,19169]
===
match
---
operator: = [14700,14701]
operator: = [14714,14715]
===
match
---
operator: , [4988,4989]
operator: , [5002,5003]
===
match
---
name: Iterable [28065,28073]
name: Iterable [28356,28364]
===
match
---
trailer [17810,17825]
trailer [17824,17839]
===
match
---
name: DagRunType [7964,7974]
name: DagRunType [7978,7988]
===
match
---
atom_expr [3213,3231]
atom_expr [3227,3245]
===
match
---
trailer [16056,16080]
trailer [16070,16094]
===
match
---
atom_expr [23722,23732]
atom_expr [24013,24023]
===
match
---
atom_expr [19093,19116]
atom_expr [19384,19407]
===
match
---
simple_stmt [13372,13612]
simple_stmt [13386,13626]
===
match
---
expr_stmt [14539,14581]
expr_stmt [14553,14595]
===
match
---
param [3938,3967]
param [3952,3981]
===
match
---
name: dag [6670,6673]
name: dag [6684,6687]
===
match
---
operator: { [25489,25490]
operator: { [25780,25781]
===
match
---
atom_expr [18157,18203]
atom_expr [18171,18217]
===
match
---
name: schedule_interval [22567,22584]
name: schedule_interval [22858,22875]
===
match
---
name: ready_tis [20102,20111]
name: ready_tis [20393,20402]
===
match
---
atom_expr [20419,20427]
atom_expr [20710,20718]
===
match
---
param [23704,23708]
param [23995,23999]
===
match
---
trailer [29418,29426]
trailer [29709,29717]
===
match
---
name: subquery [27928,27936]
name: subquery [28219,28227]
===
match
---
operator: = [18759,18760]
operator: = [19050,19051]
===
match
---
atom_expr [25672,25687]
atom_expr [25963,25978]
===
match
---
trailer [7119,7129]
trailer [7133,7143]
===
match
---
suite [9770,9841]
suite [9784,9855]
===
match
---
simple_stmt [2611,2643]
simple_stmt [2625,2657]
===
match
---
name: provide_session [5457,5472]
name: provide_session [5471,5486]
===
match
---
name: info [26298,26302]
name: info [26589,26593]
===
match
---
operator: == [11048,11050]
operator: == [11062,11064]
===
match
---
suite [28111,30303]
suite [28402,30594]
===
match
---
atom_expr [12326,12345]
atom_expr [12340,12359]
===
match
---
trailer [26561,26571]
trailer [26852,26862]
===
match
---
operator: = [4446,4447]
operator: = [4460,4461]
===
match
---
and_test [11744,11773]
and_test [11758,11787]
===
match
---
trailer [24558,24560]
trailer [24849,24851]
===
match
---
name: datetime [4086,4094]
name: datetime [4100,4108]
===
match
---
name: dag [12553,12556]
name: dag [12567,12570]
===
match
---
decorators [27429,27463]
decorators [27720,27754]
===
match
---
name: self [5247,5251]
name: self [5261,5265]
===
match
---
simple_stmt [9373,9397]
simple_stmt [9387,9411]
===
match
---
trailer [5055,5072]
trailer [5069,5086]
===
match
---
argument [15996,16017]
argument [16010,16031]
===
match
---
atom_expr [5789,6013]
atom_expr [5803,6027]
===
match
---
name: finished_tasks [20006,20020]
name: finished_tasks [20297,20311]
===
match
---
name: TI [2320,2322]
name: TI [2334,2336]
===
match
---
import_from [1829,1878]
import_from [1843,1892]
===
match
---
name: execution_date [4954,4968]
name: execution_date [4968,4982]
===
match
---
if_stmt [12985,13057]
if_stmt [12999,13071]
===
match
---
trailer [10251,10270]
trailer [10265,10284]
===
match
---
funcdef [23660,24056]
funcdef [23951,24347]
===
match
---
simple_stmt [25526,25548]
simple_stmt [25817,25839]
===
match
---
name: str [26120,26123]
name: str [26411,26414]
===
match
---
atom_expr [22814,22889]
atom_expr [23105,23180]
===
match
---
operator: , [30200,30201]
operator: , [30491,30492]
===
match
---
name: settings [1294,1302]
name: settings [1294,1302]
===
match
---
operator: , [13222,13223]
operator: , [13236,13237]
===
match
---
name: Column [2726,2732]
name: Column [2740,2746]
===
match
---
trailer [11017,11024]
trailer [11031,11038]
===
match
---
comparison [13452,13480]
comparison [13466,13494]
===
match
---
atom_expr [11631,11649]
atom_expr [11645,11663]
===
match
---
suite [11146,11732]
suite [11160,11746]
===
match
---
simple_stmt [4728,4747]
simple_stmt [4742,4761]
===
match
---
testlist_comp [3668,3690]
testlist_comp [3682,3704]
===
match
---
trailer [11761,11765]
trailer [11775,11779]
===
match
---
operator: = [3886,3887]
operator: = [3900,3901]
===
match
---
name: self [29375,29379]
name: self [29666,29670]
===
match
---
atom_expr [6860,7350]
atom_expr [6874,7364]
===
match
---
trailer [29070,29082]
trailer [29361,29373]
===
match
---
param [4314,4352]
param [4328,4366]
===
match
---
name: is_backfill [27341,27352]
name: is_backfill [27632,27643]
===
match
---
trailer [4138,4144]
trailer [4152,4158]
===
match
---
trailer [27387,27396]
trailer [27678,27687]
===
match
---
simple_stmt [18444,18464]
simple_stmt [18458,18478]
===
match
---
name: changed_tis [18444,18455]
name: changed_tis [18458,18469]
===
match
---
argument [20965,20990]
argument [21256,21281]
===
match
---
operator: = [18530,18531]
operator: = [18544,18545]
===
match
---
decorated [11869,12401]
decorated [11883,12415]
===
match
---
param [5358,5362]
param [5372,5376]
===
match
---
name: cls [7317,7320]
name: cls [7331,7334]
===
match
---
trailer [23837,23843]
trailer [24128,24134]
===
match
---
operator: , [3417,3418]
operator: , [3431,3432]
===
match
---
atom_expr [3019,3029]
atom_expr [3033,3043]
===
match
---
comparison [29308,29332]
comparison [29599,29623]
===
match
---
trailer [29883,29891]
trailer [30174,30182]
===
match
---
trailer [29252,29258]
trailer [29543,29549]
===
match
---
atom_expr [10153,10204]
atom_expr [10167,10218]
===
match
---
dotted_name [1082,1096]
dotted_name [1082,1096]
===
match
---
operator: > [25688,25689]
operator: > [25979,25980]
===
match
---
simple_stmt [14988,15069]
simple_stmt [15002,15083]
===
match
---
expr_stmt [19130,19225]
expr_stmt [19421,19516]
===
match
---
name: changed_tis [20401,20412]
name: changed_tis [20692,20703]
===
match
---
trailer [11814,11818]
trailer [11828,11832]
===
match
---
trailer [18536,18548]
trailer [18550,18562]
===
match
---
name: Session [13679,13686]
name: Session [13693,13700]
===
match
---
param [7860,7900]
param [7874,7914]
===
match
---
name: none_task_concurrency [15230,15251]
name: none_task_concurrency [15244,15265]
===
match
---
name: on_execute_callback [28948,28967]
name: on_execute_callback [29239,29258]
===
match
---
suite [2069,2109]
suite [2083,2123]
===
match
---
operator: = [17517,17518]
operator: = [17531,17532]
===
match
---
trailer [14741,14750]
trailer [14755,14764]
===
match
---
operator: , [1044,1045]
operator: , [1044,1045]
===
match
---
name: TI [29259,29261]
name: TI [29550,29552]
===
match
---
name: task_id [24656,24663]
name: task_id [24947,24954]
===
match
---
trailer [16520,16526]
trailer [16534,16540]
===
match
---
param [26511,26523]
param [26802,26814]
===
match
---
atom [15580,15629]
atom [15594,15643]
===
match
---
name: run_id [7734,7740]
name: run_id [7748,7754]
===
match
---
atom [19690,19692]
atom [19981,19983]
===
match
---
operator: , [994,995]
operator: , [994,995]
===
match
---
name: execution_date [13505,13519]
name: execution_date [13519,13533]
===
match
---
decorated [10610,10830]
decorated [10624,10844]
===
match
---
atom_expr [11757,11773]
atom_expr [11771,11787]
===
match
---
trailer [13549,13564]
trailer [13563,13578]
===
match
---
simple_stmt [28787,28811]
simple_stmt [29078,29102]
===
match
---
name: Stats [23874,23879]
name: Stats [24165,24170]
===
match
---
trailer [11444,11464]
trailer [11458,11478]
===
match
---
name: List [20579,20583]
name: List [20870,20874]
===
match
---
operator: , [2744,2745]
operator: , [2758,2759]
===
match
---
name: dag_id [13474,13480]
name: dag_id [13488,13494]
===
match
---
name: info [14902,14906]
name: info [14916,14920]
===
match
---
and_test [15714,15804]
and_test [15728,15818]
===
match
---
dotted_name [1884,1908]
dotted_name [1898,1922]
===
match
---
name: c [27896,27897]
name: c [28187,28188]
===
match
---
name: ti [25430,25432]
name: ti [25721,25723]
===
match
---
param [26493,26510]
param [26784,26801]
===
match
---
atom_expr [28940,28967]
atom_expr [29231,29258]
===
match
---
name: TI [29495,29497]
name: TI [29786,29788]
===
match
---
name: session [11932,11939]
name: session [11946,11953]
===
match
---
operator: = [7552,7553]
operator: = [7566,7567]
===
match
---
name: ti [28940,28942]
name: ti [29231,29233]
===
match
---
name: airflow [1456,1463]
name: airflow [1470,1477]
===
match
---
name: self [23790,23794]
name: self [24081,24085]
===
match
---
argument [16788,16803]
argument [16802,16817]
===
match
---
operator: = [22755,22756]
operator: = [23046,23047]
===
match
---
trailer [5972,5979]
trailer [5986,5993]
===
match
---
name: self [19161,19165]
name: self [19452,19456]
===
match
---
simple_stmt [14791,14830]
simple_stmt [14805,14844]
===
match
---
name: exec_date [5708,5717]
name: exec_date [5722,5731]
===
match
---
name: query [27619,27624]
name: query [27910,27915]
===
match
---
trailer [27872,27954]
trailer [28163,28245]
===
match
---
atom_expr [16878,17158]
atom_expr [16892,17172]
===
match
---
name: state [11343,11348]
name: state [11357,11362]
===
match
---
name: handle_callback [17488,17503]
name: handle_callback [17502,17517]
===
match
---
operator: = [20020,20021]
operator: = [20311,20312]
===
match
---
operator: == [23733,23735]
operator: == [24024,24026]
===
match
---
atom_expr [10567,10604]
atom_expr [10581,10618]
===
match
---
name: state [18979,18984]
name: state [19270,19275]
===
match
---
suite [18023,18066]
suite [18037,18080]
===
match
---
atom_expr [19534,19542]
atom_expr [19825,19833]
===
match
---
atom_expr [10048,10101]
atom_expr [10062,10115]
===
match
---
operator: = [11432,11433]
operator: = [11446,11447]
===
match
---
comp_if [18850,18878]
comp_if [19141,19169]
===
match
---
trailer [29493,29549]
trailer [29784,29840]
===
match
---
name: tis [10994,10997]
name: tis [11008,11011]
===
match
---
trailer [4475,4486]
trailer [4489,4500]
===
match
---
simple_stmt [1230,1273]
simple_stmt [1230,1273]
===
match
---
trailer [7320,7335]
trailer [7334,7349]
===
match
---
trailer [15826,15832]
trailer [15840,15846]
===
match
---
name: ti [28992,28994]
name: ti [29283,29285]
===
match
---
name: len [19093,19096]
name: len [19384,19387]
===
match
---
operator: = [22882,22883]
operator: = [23173,23174]
===
match
---
name: qry [9567,9570]
name: qry [9581,9584]
===
match
---
trailer [5288,5295]
trailer [5302,5309]
===
match
---
operator: = [2990,2991]
operator: = [3004,3005]
===
match
---
name: len [18642,18645]
name: len [18656,18659]
===
match
---
comparison [18853,18878]
comparison [19144,19169]
===
match
---
name: all [27983,27986]
name: all [28274,28277]
===
match
---
atom_expr [7111,7140]
atom_expr [7125,7154]
===
match
---
sync_comp_for [11387,11401]
sync_comp_for [11401,11415]
===
match
---
arglist [20965,21145]
arglist [21256,21436]
===
match
---
trailer [25567,25573]
trailer [25858,25864]
===
match
---
name: utcnow [30073,30079]
name: utcnow [30364,30370]
===
match
---
simple_stmt [11847,11864]
simple_stmt [11861,11878]
===
match
---
string: """         Verifies the DagRun by checking for removed tasks or tasks that are not in the         database yet. It will set state to removed or add the task if required.          :param session: Sqlalchemy ORM Session         :type session: Session         """ [24143,24404]
string: """         Verifies the DagRun by checking for removed tasks or tasks that are not in the         database yet. It will set state to removed or add the task if required.          :param session: Sqlalchemy ORM Session         :type session: Session         """ [24434,24695]
===
match
---
name: start_dttm [14571,14581]
name: start_dttm [14585,14595]
===
match
---
name: session [20062,20069]
name: session [20353,20360]
===
match
---
trailer [20278,20283]
trailer [20569,20574]
===
match
---
name: _state [5186,5192]
name: _state [5200,5206]
===
match
---
atom_expr [11601,11629]
atom_expr [11615,11643]
===
match
---
name: provide_session [18281,18296]
name: provide_session [18295,18310]
===
match
---
arglist [16750,16803]
arglist [16764,16817]
===
match
---
fstring [23469,23519]
fstring [23760,23810]
===
match
---
atom_expr [4284,4297]
atom_expr [4298,4311]
===
match
---
operator: , [17385,17386]
operator: , [17399,17400]
===
match
---
name: DR [5896,5898]
name: DR [5910,5912]
===
match
---
operator: , [29521,29522]
operator: , [29812,29813]
===
match
---
param [10648,10669]
param [10662,10683]
===
match
---
trailer [22536,22554]
trailer [22827,22845]
===
match
---
name: ti [26010,26012]
name: ti [26301,26303]
===
match
---
name: NamedTuple [872,882]
name: NamedTuple [872,882]
===
match
---
name: Optional [6189,6197]
name: Optional [6203,6211]
===
match
---
trailer [30135,30137]
trailer [30426,30428]
===
match
---
name: FAILED [15897,15903]
name: FAILED [15911,15917]
===
match
---
operator: = [3782,3783]
operator: = [3796,3797]
===
match
---
name: external_trigger [10364,10380]
name: external_trigger [10378,10394]
===
match
---
name: Optional [3946,3954]
name: Optional [3960,3968]
===
match
---
atom_expr [4588,4598]
atom_expr [4602,4612]
===
match
---
name: ti [18721,18723]
name: ti [18756,18758]
===
match
---
operator: = [13687,13688]
operator: = [13701,13702]
===
match
---
operator: , [30023,30024]
operator: , [30314,30315]
===
match
---
name: Session [1265,1272]
name: Session [1265,1272]
===
match
---
atom_expr [24596,24627]
atom_expr [24887,24918]
===
match
---
operator: , [18264,18265]
operator: , [18278,18279]
===
insert-tree
---
simple_stmt [1358,1420]
    import_from [1358,1419]
        dotted_name [1363,1381]
            name: airflow [1363,1370]
            name: exceptions [1371,1381]
        import_as_names [1389,1419]
            name: AirflowException [1389,1405]
            operator: , [1405,1406]
            name: TaskNotFound [1407,1419]
to
file_input [787,30303]
at 9
===
insert-node
---
name: DagRun [2375,2381]
to
classdef [2355,30303]
at 0
===
insert-tree
---
arglist [2382,2400]
    name: Base [2382,2386]
    operator: , [2386,2387]
    name: LoggingMixin [2388,2400]
to
classdef [2355,30303]
at 1
===
insert-tree
---
simple_stmt [2407,2546]
    string: """     DagRun describes an instance of a Dag. It can be created     by the scheduler (for regular runs) or by an external trigger     """ [2407,2545]
to
suite [2388,30303]
at 0
===
insert-node
---
suite [18688,19024]
to
for_stmt [18660,18733]
at 2
===
insert-node
---
try_stmt [18701,19024]
to
suite [18688,19024]
at 0
===
move-tree
---
suite [18674,18733]
    simple_stmt [18687,18733]
        expr_stmt [18687,18732]
            atom_expr [18687,18694]
                name: ti [18687,18689]
                trailer [18689,18694]
                    name: task [18690,18694]
            operator: = [18695,18696]
            atom_expr [18697,18732]
                name: self [18697,18701]
                trailer [18701,18709]
                    name: get_dag [18702,18709]
                trailer [18709,18711]
                trailer [18711,18720]
                    name: get_task [18712,18720]
                trailer [18720,18732]
                    atom_expr [18721,18731]
                        name: ti [18721,18723]
                        trailer [18723,18731]
                            name: task_id [18724,18731]
to
try_stmt [18701,19024]
at 0
===
delete-tree
---
simple_stmt [1358,1406]
    import_from [1358,1405]
        dotted_name [1363,1381]
            name: airflow [1363,1370]
            name: exceptions [1371,1381]
        name: AirflowException [1389,1405]
===
delete-node
---
name: DagRun [2361,2367]
===
===
delete-tree
---
arglist [2368,2386]
    name: Base [2368,2372]
    operator: , [2372,2373]
    name: LoggingMixin [2374,2386]
===
delete-tree
---
simple_stmt [2393,2532]
    string: """     DagRun describes an instance of a Dag. It can be created     by the scheduler (for regular runs) or by an external trigger     """ [2393,2531]
