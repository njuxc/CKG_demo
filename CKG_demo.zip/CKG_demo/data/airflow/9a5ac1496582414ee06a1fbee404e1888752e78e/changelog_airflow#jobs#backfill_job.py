===
match
---
trailer [37294,37301]
trailer [37289,37296]
===
match
---
string: """         Initializes all components required to run a dag for a specified date range and         calls helper method to execute the tasks.         """ [32651,32804]
string: """         Initializes all components required to run a dag for a specified date range and         calls helper method to execute the tasks.         """ [32646,32799]
===
match
---
arglist [26772,26844]
arglist [26767,26839]
===
match
---
name: bf_start_date [32884,32897]
name: bf_start_date [32879,32892]
===
match
---
atom_expr [22928,22953]
atom_expr [22923,22948]
===
match
---
operator: , [8691,8692]
operator: , [8691,8692]
===
match
---
for_stmt [32388,32583]
for_stmt [32383,32578]
===
match
---
name: start_date [33042,33052]
name: start_date [33037,33047]
===
match
---
name: active_runs [4886,4897]
name: active_runs [4886,4897]
===
match
---
name: ti [19183,19185]
name: ti [19178,19180]
===
match
---
expr_stmt [20767,21036]
expr_stmt [20762,21031]
===
match
---
if_stmt [23673,23753]
if_stmt [23668,23748]
===
match
---
operator: == [8797,8799]
operator: == [8797,8799]
===
match
---
simple_stmt [29734,29783]
simple_stmt [29729,29778]
===
match
---
operator: = [4621,4622]
operator: = [4621,4622]
===
match
---
name: state [18185,18190]
name: state [18180,18185]
===
match
---
string: "Reset the following %s TaskInstances:\n\t%s" [38722,38767]
string: "Reset the following %s TaskInstances:\n\t%s" [38717,38762]
===
match
---
name: dag_id [25543,25549]
name: dag_id [25538,25544]
===
match
---
simple_stmt [16429,17279]
simple_stmt [16424,17274]
===
match
---
atom_expr [17335,17384]
atom_expr [17330,17379]
===
match
---
operator: @ [36335,36336]
operator: @ [36330,36331]
===
match
---
atom_expr [9523,9529]
atom_expr [9523,9529]
===
match
---
operator: , [4478,4479]
operator: , [4478,4479]
===
match
---
trailer [15491,15493]
trailer [15486,15488]
===
match
---
trailer [17465,17487]
trailer [17460,17482]
===
match
---
name: ti_status [18918,18927]
name: ti_status [18913,18922]
===
match
---
name: self [24970,24974]
name: self [24965,24969]
===
match
---
name: run [13369,13372]
name: run [13364,13367]
===
match
---
name: dag_run [15012,15019]
name: dag_run [15007,15014]
===
match
---
operator: = [27871,27872]
operator: = [27866,27867]
===
match
---
argument [22380,22418]
argument [22375,22413]
===
match
---
name: first [24328,24333]
name: first [24323,24328]
===
match
---
trailer [15035,15037]
trailer [15030,15032]
===
match
---
name: state [22801,22806]
name: state [22796,22801]
===
match
---
trailer [12900,12920]
trailer [12895,12915]
===
match
---
trailer [10849,10942]
trailer [10844,10937]
===
match
---
operator: = [17979,17980]
operator: = [17974,17975]
===
match
---
name: dag_id [13113,13119]
name: dag_id [13108,13114]
===
match
---
name: DagRunInfo [1592,1602]
name: DagRunInfo [1592,1602]
===
match
---
name: filter_for_tis [10827,10841]
name: filter_for_tis [10822,10836]
===
match
---
trailer [36273,36277]
trailer [36268,36272]
===
match
---
trailer [21980,21995]
trailer [21975,21990]
===
match
---
name: verbose [28991,28998]
name: verbose [28986,28993]
===
match
---
name: refresh_from_db [11554,11569]
name: refresh_from_db [11549,11564]
===
match
---
name: state [20216,20221]
name: state [20211,20216]
===
match
---
operator: = [4266,4267]
operator: = [4266,4267]
===
match
---
name: filter_for_tis [10734,10748]
name: filter_for_tis [10729,10743]
===
match
---
atom_expr [15876,15892]
atom_expr [15871,15887]
===
match
---
trailer [38721,38803]
trailer [38716,38798]
===
match
---
param [36421,36433]
param [36416,36428]
===
match
---
name: session [17914,17921]
name: session [17909,17916]
===
match
---
name: query [24271,24276]
name: query [24266,24271]
===
match
---
operator: } [14734,14735]
operator: } [14729,14730]
===
match
---
operator: = [35162,35163]
operator: = [35157,35158]
===
match
---
name: result [38069,38075]
name: result [38064,38070]
===
match
---
name: base_job [1261,1269]
name: base_job [1261,1269]
===
match
---
name: ti [23294,23296]
name: ti [23289,23291]
===
match
---
atom_expr [27283,27316]
atom_expr [27278,27311]
===
match
---
name: join [37433,37437]
name: join [37428,37432]
===
match
---
atom_expr [12846,12859]
atom_expr [12841,12854]
===
match
---
name: tabulate_ti_keys_set [29854,29874]
name: tabulate_ti_keys_set [29849,29869]
===
match
---
operator: = [21234,21235]
operator: = [21229,21230]
===
match
---
string: """         Returns a dag run for the given run date, which will be matched to an existing         dag run if available or create a new dag run otherwise. If the max_active_runs         limit is reached, this function will return None.          :param dagrun_info: Schedule information for the dag run         :param dag: DAG         :param session: the database session object         :return: a DagRun in state RUNNING or None         """ [12219,12659]
string: """         Returns a dag run for the given run date, which will be matched to an existing         dag run if available or create a new dag run otherwise. If the max_active_runs         limit is reached, this function will return None.          :param dagrun_info: Schedule information for the dag run         :param dag: DAG         :param session: the database session object         :return: a DagRun in state RUNNING or None         """ [12214,12654]
===
match
---
name: dag [12175,12178]
name: dag [12170,12173]
===
match
---
operator: = [13938,13939]
operator: = [13933,13934]
===
match
---
trailer [25223,25348]
trailer [25218,25343]
===
match
---
name: filter [38228,38234]
name: filter [38223,38229]
===
match
---
name: DagRun [13196,13202]
name: DagRun [13191,13197]
===
match
---
param [5408,5433]
param [5408,5433]
===
match
---
name: timezone [21781,21789]
name: timezone [21776,21784]
===
match
---
decorator [27649,27666]
decorator [27644,27661]
===
match
---
funcdef [14296,15541]
funcdef [14291,15536]
===
match
---
if_stmt [25374,26050]
if_stmt [25369,26045]
===
match
---
atom_expr [9046,9058]
atom_expr [9046,9058]
===
match
---
name: Set [28164,28167]
name: Set [28159,28162]
===
match
---
while_stmt [34735,35910]
while_stmt [34730,35905]
===
match
---
name: self [4741,4745]
name: self [4741,4745]
===
match
---
name: STATES_COUNT_AS_RUNNING [25652,25675]
name: STATES_COUNT_AS_RUNNING [25647,25670]
===
match
---
trailer [23890,23896]
trailer [23885,23891]
===
match
---
operator: = [5144,5145]
operator: = [5144,5145]
===
match
---
trailer [13577,13593]
trailer [13572,13588]
===
match
---
trailer [4934,4957]
trailer [4934,4957]
===
match
---
atom_expr [13641,14010]
atom_expr [13636,14005]
===
match
---
operator: = [31899,31900]
operator: = [31894,31895]
===
match
---
trailer [38273,38292]
trailer [38268,38287]
===
match
---
name: reset_tis [38664,38673]
name: reset_tis [38659,38668]
===
match
---
name: ti_status [18381,18390]
name: ti_status [18376,18385]
===
match
---
atom_expr [17401,17422]
atom_expr [17396,17417]
===
match
---
simple_stmt [4693,4729]
simple_stmt [4693,4729]
===
match
---
operator: , [18055,18056]
operator: , [18050,18051]
===
match
---
simple_stmt [11521,11539]
simple_stmt [11516,11534]
===
match
---
for_stmt [31325,31706]
for_stmt [31320,31701]
===
match
---
name: ti_status [27566,27575]
name: ti_status [27561,27570]
===
match
---
atom_expr [11403,11482]
atom_expr [11398,11477]
===
match
---
atom_expr [34472,34481]
atom_expr [34467,34476]
===
match
---
simple_stmt [27196,27233]
simple_stmt [27191,27228]
===
match
---
testlist_comp [28370,28440]
testlist_comp [28365,28435]
===
match
---
trailer [21830,21836]
trailer [21825,21831]
===
match
---
name: merge [32568,32573]
name: merge [32563,32568]
===
match
---
trailer [27339,27345]
trailer [27334,27340]
===
match
---
param [30336,30346]
param [30331,30341]
===
match
---
simple_stmt [34431,34448]
simple_stmt [34426,34443]
===
match
---
trailer [10877,10883]
trailer [10872,10878]
===
match
---
trailer [11419,11482]
trailer [11414,11477]
===
match
---
name: reduced_key [8981,8992]
name: reduced_key [8981,8992]
===
match
---
simple_stmt [32813,32857]
simple_stmt [32808,32852]
===
match
---
name: reduced_key [9477,9488]
name: reduced_key [9477,9488]
===
match
---
simple_stmt [20247,20273]
simple_stmt [20242,20268]
===
match
---
operator: = [17921,17922]
operator: = [17916,17917]
===
match
---
atom_expr [26631,26650]
atom_expr [26626,26645]
===
match
---
funcdef [37994,38511]
funcdef [37989,38506]
===
match
---
param [38012,38017]
param [38007,38012]
===
match
---
operator: , [2176,2177]
operator: , [2176,2177]
===
match
---
name: list [33251,33255]
name: list [33246,33250]
===
match
---
name: state [38264,38269]
name: state [38259,38264]
===
match
---
atom_expr [17466,17486]
atom_expr [17461,17481]
===
match
---
trailer [24926,24933]
trailer [24921,24928]
===
match
---
simple_stmt [27488,27534]
simple_stmt [27483,27529]
===
match
---
name: reduce_in_chunks [38540,38556]
name: reduce_in_chunks [38535,38551]
===
match
---
param [30295,30300]
param [30290,30295]
===
match
---
atom_expr [24970,24998]
atom_expr [24965,24993]
===
match
---
suite [27266,27534]
suite [27261,27529]
===
match
---
name: state [14136,14141]
name: state [14131,14136]
===
match
---
simple_stmt [21662,21686]
simple_stmt [21657,21681]
===
match
---
expr_stmt [29958,30003]
expr_stmt [29953,29998]
===
match
---
name: ti_status [27127,27136]
name: ti_status [27122,27131]
===
match
---
trailer [20628,20643]
trailer [20623,20638]
===
match
---
name: run_type [14170,14178]
name: run_type [14165,14173]
===
match
---
suite [7808,10943]
suite [7808,10938]
===
match
---
name: reset_tis [38520,38529]
name: reset_tis [38515,38524]
===
match
---
name: delay_on_limit_secs [7465,7484]
name: delay_on_limit_secs [7465,7484]
===
match
---
trailer [15958,15966]
trailer [15953,15961]
===
match
---
name: State [2163,2168]
name: State [2163,2168]
===
match
---
name: reduced_key [9782,9793]
name: key [9785,9788]
===
match
---
name: verbose [7498,7505]
name: verbose [7498,7505]
===
match
---
atom_expr [18381,18409]
atom_expr [18376,18404]
===
match
---
name: resettable_tis [37727,37741]
name: resettable_tis [37722,37736]
===
match
---
name: pool [5314,5318]
name: pool [5314,5318]
===
match
---
trailer [9769,9777]
trailer [9769,9777]
===
match
---
trailer [23234,23238]
trailer [23229,23233]
===
match
---
operator: , [9116,9117]
operator: , [9116,9117]
===
match
---
name: ti_status [23726,23735]
name: ti_status [23721,23730]
===
match
---
name: self [12144,12148]
name: self [12139,12143]
===
match
---
trailer [18141,18191]
trailer [18136,18186]
===
match
---
name: verify_integrity [14217,14233]
name: verify_integrity [14212,14228]
===
match
---
simple_stmt [25191,25349]
simple_stmt [25186,25344]
===
match
---
atom_expr [25136,25161]
atom_expr [25131,25156]
===
match
---
trailer [21350,21354]
trailer [21345,21349]
===
match
---
trailer [23082,23090]
trailer [23077,23085]
===
match
---
name: err [28546,28549]
name: err [28541,28544]
===
match
---
trailer [22209,22611]
trailer [22204,22606]
===
match
---
name: conf [7529,7533]
name: conf [7529,7533]
===
match
---
trailer [33255,33327]
trailer [33250,33322]
===
match
---
suite [18587,18639]
suite [18582,18634]
===
match
---
operator: , [5111,5112]
operator: , [5111,5112]
===
match
---
expr_stmt [30127,30169]
expr_stmt [30122,30164]
===
match
---
atom_expr [27488,27533]
atom_expr [27483,27528]
===
match
---
name: ti_deps [1502,1509]
name: ti_deps [1502,1509]
===
match
---
name: state [23181,23186]
name: state [23176,23181]
===
match
---
atom_expr [37879,37885]
atom_expr [37874,37880]
===
match
---
name: session [24263,24270]
name: session [24258,24265]
===
match
---
argument [13930,13962]
argument [13925,13957]
===
match
---
atom_expr [10565,10599]
atom_expr [10560,10594]
===
match
---
name: DagRun [37505,37511]
name: DagRun [37500,37506]
===
match
---
simple_stmt [947,977]
simple_stmt [947,977]
===
match
---
simple_stmt [4930,4992]
simple_stmt [4930,4992]
===
match
---
operator: { [31702,31703]
operator: { [31697,31698]
===
match
---
number: 1 [33799,33800]
number: 1 [33794,33795]
===
match
---
simple_stmt [12022,12042]
simple_stmt [12017,12037]
===
match
---
return_stmt [37976,37984]
return_stmt [37971,37979]
===
match
---
simple_stmt [26357,26378]
simple_stmt [26352,26373]
===
match
---
param [5182,5201]
param [5182,5201]
===
match
---
name: key [23967,23970]
name: key [23962,23965]
===
match
---
name: utils [1795,1800]
name: utils [1795,1800]
===
match
---
name: tabulate [28461,28469]
name: tabulate [28456,28464]
===
match
---
name: processed_dag_run_dates [31715,31738]
name: processed_dag_run_dates [31710,31733]
===
match
---
name: query [37396,37401]
name: query [37391,37396]
===
match
---
operator: = [28925,28926]
operator: = [28920,28921]
===
match
---
name: ti [20213,20215]
name: ti [20208,20210]
===
match
---
param [14334,14342]
param [14329,14337]
===
match
---
testlist_comp [28294,28341]
testlist_comp [28289,28336]
===
match
---
trailer [13788,13790]
trailer [13783,13785]
===
match
---
name: create_dagrun [13645,13658]
name: create_dagrun [13640,13653]
===
match
---
name: NoAvailablePoolSlot [1120,1139]
name: NoAvailablePoolSlot [1120,1139]
===
match
---
atom_expr [20112,20133]
atom_expr [20107,20128]
===
match
---
name: log [20165,20168]
name: log [20160,20163]
===
match
---
suite [34761,35910]
suite [34756,35905]
===
match
---
operator: += [29326,29328]
operator: += [29321,29323]
===
match
---
atom_expr [29106,29145]
atom_expr [29101,29140]
===
match
---
argument [35451,35470]
argument [35446,35465]
===
match
---
atom_expr [35970,36018]
atom_expr [35965,36013]
===
match
---
name: self [36391,36395]
name: self [36386,36390]
===
match
---
name: pop [23389,23392]
name: pop [23384,23387]
===
match
---
name: run_date [13687,13695]
name: run_date [13682,13690]
===
match
---
name: not_ready [23953,23962]
name: not_ready [23948,23957]
===
match
---
name: ti_key [27961,27967]
name: ti_key [27956,27962]
===
match
---
operator: = [22340,22341]
operator: = [22335,22336]
===
match
---
string: '\nThese tasks have succeeded:\n' [29688,29721]
string: '\nThese tasks have succeeded:\n' [29683,29716]
===
match
---
name: session [17994,18001]
name: session [17989,17996]
===
match
---
operator: = [27307,27308]
operator: = [27302,27303]
===
match
---
fstring_start: f' [24420,24422]
fstring_start: f' [24415,24417]
===
match
---
name: heartbeat [26366,26375]
name: heartbeat [26361,26370]
===
match
---
operator: = [13809,13810]
operator: = [13804,13805]
===
match
---
string: "Executor reports task instance {} finished ({}) " [11786,11836]
string: "Executor reports task instance {} finished ({}) " [11781,11831]
===
match
---
trailer [10753,10768]
trailer [10748,10763]
===
match
---
name: queued_tasks [37036,37048]
name: queued_tasks [37031,37043]
===
match
---
simple_stmt [28249,28344]
simple_stmt [28244,28339]
===
match
---
param [28289,28291]
param [28284,28286]
===
match
---
simple_stmt [33103,33148]
simple_stmt [33098,33143]
===
match
---
atom_expr [21732,21739]
atom_expr [21727,21734]
===
match
---
trailer [18578,18586]
trailer [18573,18581]
===
match
---
param [4364,4379]
param [4364,4379]
===
match
---
atom_expr [9811,9835]
atom_expr [9806,9830]
===
match
---
name: error [12031,12036]
name: error [12026,12031]
===
match
---
name: log [21385,21388]
name: log [21380,21383]
===
match
---
expr_stmt [37139,37174]
expr_stmt [37134,37169]
===
match
---
expr_stmt [10616,10645]
expr_stmt [10611,10640]
===
match
---
name: to_run [20307,20313]
name: to_run [20302,20308]
===
match
---
name: ti [9523,9525]
name: ti [9523,9525]
===
match
---
name: session [19436,19443]
name: session [19431,19438]
===
match
---
atom_expr [11972,11980]
atom_expr [11967,11975]
===
match
---
name: ti [22661,22663]
name: ti [22656,22658]
===
match
---
name: ti [8693,8695]
name: ti [8693,8695]
===
match
---
trailer [35974,35978]
trailer [35969,35973]
===
match
---
simple_stmt [37251,37303]
simple_stmt [37246,37298]
===
match
---
trailer [22990,22994]
trailer [22985,22989]
===
match
---
atom_expr [35873,35909]
atom_expr [35868,35904]
===
match
---
name: ti_status [26862,26871]
name: ti_status [26857,26866]
===
match
---
name: State [9046,9051]
name: State [9046,9051]
===
match
---
name: key [18911,18914]
name: key [18906,18909]
===
match
---
operator: = [18025,18026]
operator: = [18020,18021]
===
match
---
trailer [22043,22063]
trailer [22038,22058]
===
match
---
suite [13594,13619]
suite [13589,13614]
===
match
---
operator: += [29685,29687]
operator: += [29680,29682]
===
match
---
operator: , [1157,1158]
operator: , [1157,1158]
===
match
---
param [10975,10980]
param [10970,10975]
===
match
---
suite [25405,26050]
suite [25400,26045]
===
match
---
name: base [1580,1584]
name: base [1580,1584]
===
match
---
name: ti_status [16020,16029]
name: ti_status [16015,16024]
===
match
---
trailer [8237,8244]
trailer [8237,8244]
===
match
---
name: log [17511,17514]
name: log [17506,17509]
===
match
---
decorated [27649,30248]
decorated [27644,30243]
===
match
---
trailer [11472,11479]
trailer [11467,11474]
===
match
---
atom_expr [11282,11317]
atom_expr [11277,11312]
===
match
---
name: timezone [13773,13781]
name: timezone [13768,13776]
===
match
---
simple_stmt [17572,17600]
simple_stmt [17567,17595]
===
match
---
string: "Task instance %s with state %s" [20175,20207]
string: "Task instance %s with state %s" [20170,20202]
===
match
---
atom_expr [9629,9637]
atom_expr [9629,9637]
===
match
---
trailer [18795,18841]
trailer [18790,18836]
===
match
---
operator: , [13962,13963]
operator: , [13957,13958]
===
match
---
funcdef [7756,10943]
funcdef [7756,10938]
===
match
---
if_stmt [19461,20462]
if_stmt [19456,20457]
===
match
---
name: open_slots [24548,24558]
name: open_slots [24543,24553]
===
match
---
except_clause [15445,15461]
except_clause [15440,15456]
===
match
---
name: to_run [18523,18529]
name: to_run [18518,18524]
===
match
---
operator: , [4350,4351]
operator: , [4350,4351]
===
match
---
trailer [25381,25404]
trailer [25376,25399]
===
match
---
name: len [26696,26699]
name: len [26691,26694]
===
match
---
number: 0 [37983,37984]
number: 0 [37978,37979]
===
match
---
name: ignore_depends_on_past [20865,20887]
name: ignore_depends_on_past [20860,20882]
===
match
---
name: key [28278,28281]
name: key [28273,28276]
===
match
---
simple_stmt [23580,23653]
simple_stmt [23575,23648]
===
match
---
trailer [23238,23244]
trailer [23233,23239]
===
match
---
operator: } [2253,2254]
operator: } [2253,2254]
===
match
---
trailer [12036,12041]
trailer [12031,12036]
===
match
---
atom_expr [9828,9834]
atom_expr [9823,9829]
===
match
---
simple_stmt [23820,23827]
simple_stmt [23815,23822]
===
match
---
argument [14234,14249]
argument [14229,14244]
===
match
---
name: succeeded [18391,18400]
name: succeeded [18386,18395]
===
match
---
name: cfg_path [22567,22575]
name: cfg_path [22562,22570]
===
match
---
expr_stmt [37832,37934]
expr_stmt [37827,37929]
===
match
---
name: ti [19708,19710]
name: ti [19703,19705]
===
match
---
expr_stmt [11758,12005]
expr_stmt [11753,12000]
===
match
---
name: in_ [38270,38273]
name: in_ [38265,38268]
===
match
---
name: dagrun_infos [33236,33248]
name: dagrun_infos [33231,33243]
===
match
---
name: pool [7425,7429]
name: pool [7425,7429]
===
match
---
atom_expr [18781,18841]
atom_expr [18776,18836]
===
match
---
trailer [22653,22658]
trailer [22648,22653]
===
match
---
arglist [31411,31444]
arglist [31406,31439]
===
match
---
name: append [27507,27513]
name: append [27502,27508]
===
match
---
name: ti [23797,23799]
name: ti [23792,23794]
===
match
---
simple_stmt [8581,8618]
simple_stmt [8581,8618]
===
match
---
trailer [16019,16038]
trailer [16014,16033]
===
match
---
comparison [15335,15360]
comparison [15330,15355]
===
match
---
operator: , [22584,22585]
operator: , [22579,22580]
===
match
---
name: self [11403,11407]
name: self [11398,11402]
===
match
---
if_stmt [21330,22714]
if_stmt [21325,22709]
===
match
---
trailer [24026,24043]
trailer [24021,24038]
===
match
---
trailer [31778,31950]
trailer [31773,31945]
===
match
---
suite [13356,13380]
suite [13351,13375]
===
match
---
trailer [34143,34156]
trailer [34138,34151]
===
match
---
atom_expr [26357,26377]
atom_expr [26352,26372]
===
match
---
operator: = [17993,17994]
operator: = [17988,17989]
===
match
---
name: session [25717,25724]
name: session [25712,25719]
===
match
---
name: self [27547,27551]
name: self [27542,27546]
===
match
---
atom_expr [24599,24804]
atom_expr [24594,24799]
===
match
---
name: airflow [1825,1832]
name: airflow [1825,1832]
===
match
---
operator: = [7621,7622]
operator: = [7621,7622]
===
match
---
suite [24372,24450]
suite [24367,24445]
===
match
---
trailer [4885,4897]
trailer [4885,4897]
===
match
---
operator: @ [27649,27650]
operator: @ [27644,27645]
===
match
---
strings [29351,29650]
strings [29346,29645]
===
match
---
comparison [25099,25161]
comparison [25094,25156]
===
match
---
atom [8115,8117]
atom [8115,8117]
===
match
---
expr_stmt [38416,38437]
expr_stmt [38411,38432]
===
match
---
simple_stmt [34684,34723]
simple_stmt [34679,34718]
===
match
---
name: run_at_least_once [5471,5488]
name: run_at_least_once [5471,5488]
===
match
---
operator: = [13906,13907]
operator: = [13901,13902]
===
match
---
atom_expr [4831,4846]
atom_expr [4831,4846]
===
match
---
name: result [38492,38498]
name: result [38487,38493]
===
match
---
atom_expr [15106,15134]
atom_expr [15101,15129]
===
match
---
simple_stmt [8882,8943]
simple_stmt [8882,8943]
===
match
---
name: UP_FOR_RETRY [9352,9364]
name: UP_FOR_RETRY [9352,9364]
===
match
---
operator: = [13722,13723]
operator: = [13717,13718]
===
match
---
name: TaskInstance [1408,1420]
name: TaskInstance [1408,1420]
===
match
---
simple_stmt [35329,35408]
simple_stmt [35324,35403]
===
match
---
name: to_run [23783,23789]
name: to_run [23778,23784]
===
match
---
name: session [28962,28969]
name: session [28957,28964]
===
match
---
or_test [4572,4595]
or_test [4572,4595]
===
match
---
atom_expr [20357,20374]
atom_expr [20352,20369]
===
match
---
name: Set [27768,27771]
name: Set [27763,27766]
===
match
---
param [5314,5324]
param [5314,5324]
===
match
---
operator: , [28068,28069]
operator: , [28063,28064]
===
match
---
trailer [21282,21290]
trailer [21277,21285]
===
match
---
atom_expr [23943,23971]
atom_expr [23938,23966]
===
match
---
operator: , [37661,37662]
operator: , [37656,37657]
===
match
---
suite [31312,31706]
suite [31307,31701]
===
match
---
name: clear [26950,26955]
name: clear [26945,26950]
===
match
---
atom_expr [27105,27147]
atom_expr [27100,27142]
===
match
---
trailer [24111,24137]
trailer [24106,24132]
===
match
---
trailer [32432,32445]
trailer [32427,32440]
===
match
---
atom_expr [22528,22537]
atom_expr [22523,22532]
===
match
---
fstring [24420,24448]
fstring [24415,24443]
===
match
---
name: DagRunType [37575,37585]
name: DagRunType [37570,37580]
===
match
---
trailer [11533,11538]
trailer [11528,11533]
===
match
---
trailer [27771,27788]
trailer [27766,27783]
===
match
---
name: ti_deps [1451,1458]
name: ti_deps [1451,1458]
===
match
---
param [4216,4221]
param [4216,4221]
===
match
---
atom_expr [21673,21685]
atom_expr [21668,21680]
===
match
---
trailer [24276,24289]
trailer [24271,24284]
===
match
---
atom_expr [37620,37661]
atom_expr [37615,37656]
===
match
---
dotted_name [1608,1621]
dotted_name [1608,1621]
===
match
---
atom_expr [32825,32856]
atom_expr [32820,32851]
===
match
---
argument [24504,24519]
argument [24499,24514]
===
match
---
name: dag_run [31642,31649]
name: dag_run [31637,31644]
===
match
---
name: run_backwards [7607,7620]
name: run_backwards [7607,7620]
===
match
---
simple_stmt [36144,36207]
simple_stmt [36139,36202]
===
match
---
operator: = [10641,10642]
operator: = [10636,10637]
===
match
---
trailer [11290,11307]
trailer [11285,11302]
===
match
---
raise_stmt [24593,24804]
raise_stmt [24588,24799]
===
match
---
name: clear [17592,17597]
name: clear [17587,17592]
===
match
---
operator: , [31842,31843]
operator: , [31837,31838]
===
match
---
if_stmt [35591,35910]
if_stmt [35586,35905]
===
match
---
trailer [7606,7620]
trailer [7606,7620]
===
match
---
name: len [17430,17433]
name: len [17425,17428]
===
match
---
atom_expr [13723,13748]
atom_expr [13718,13743]
===
match
---
expr_stmt [29734,29782]
expr_stmt [29729,29777]
===
match
---
name: ti [18687,18689]
name: ti [18682,18684]
===
match
---
if_stmt [21175,22778]
if_stmt [21170,22773]
===
match
---
atom_expr [8788,8796]
atom_expr [8788,8796]
===
match
---
expr_stmt [25434,25755]
expr_stmt [25429,25750]
===
match
---
trailer [4697,4707]
trailer [4697,4707]
===
match
---
operator: , [4220,4221]
operator: , [4220,4221]
===
match
---
name: provide_session [16239,16254]
name: provide_session [16234,16249]
===
match
---
operator: = [13686,13687]
operator: = [13681,13682]
===
match
---
name: models [998,1004]
name: models [998,1004]
===
match
---
name: __init__ [4194,4202]
name: __init__ [4194,4202]
===
match
---
name: ti [11972,11974]
name: ti [11967,11969]
===
match
---
simple_stmt [18862,18888]
simple_stmt [18857,18883]
===
match
---
name: err [29322,29325]
name: err [29317,29320]
===
match
---
name: msg [12037,12040]
name: msg [12032,12035]
===
match
---
parameters [14327,14356]
parameters [14322,14351]
===
match
---
atom_expr [10885,10900]
atom_expr [10880,10895]
===
match
---
operator: = [31865,31866]
operator: = [31860,31861]
===
match
---
atom_expr [28704,28724]
atom_expr [28699,28719]
===
match
---
simple_stmt [9076,9122]
simple_stmt [9076,9122]
===
match
---
operator: = [21012,21013]
operator: = [21007,21008]
===
match
---
trailer [9336,9342]
trailer [9336,9342]
===
match
---
operator: = [11524,11525]
operator: = [11519,11520]
===
match
---
name: DepContext [28892,28902]
name: DepContext [28887,28897]
===
match
---
simple_stmt [9138,9172]
simple_stmt [9138,9172]
===
match
---
name: mark_success [22289,22301]
name: mark_success [22284,22296]
===
match
---
string: "Task instance %s upstream failed" [22868,22902]
string: "Task instance %s upstream failed" [22863,22897]
===
match
---
trailer [19710,19716]
trailer [19705,19711]
===
match
---
param [30359,30371]
param [30354,30366]
===
match
---
atom_expr [15945,15967]
atom_expr [15940,15962]
===
match
---
operator: = [7112,7113]
operator: = [7112,7113]
===
match
---
name: info [11982,11986]
name: info [11977,11981]
===
match
---
name: len [15981,15984]
name: len [15976,15979]
===
match
---
operator: = [33781,33782]
operator: = [33776,33777]
===
match
---
trailer [23039,23047]
trailer [23034,23042]
===
match
---
operator: != [37572,37574]
operator: != [37567,37569]
===
match
---
operator: + [38499,38500]
operator: + [38494,38495]
===
match
---
expr_stmt [31383,31445]
expr_stmt [31378,31440]
===
match
---
name: failed [28576,28582]
name: failed [28571,28577]
===
match
---
name: pop [10583,10586]
name: pop [10578,10581]
===
match
---
name: executor [35163,35171]
name: executor [35158,35166]
===
match
---
name: add [8849,8852]
name: add [8849,8852]
===
match
---
operator: , [25724,25725]
operator: , [25719,25720]
===
match
---
trailer [26942,26949]
trailer [26937,26944]
===
match
---
trailer [26226,26230]
trailer [26221,26225]
===
match
---
name: set [4863,4866]
name: set [4863,4866]
===
match
---
operator: , [14332,14333]
operator: , [14327,14328]
===
match
---
simple_stmt [15269,15316]
simple_stmt [15264,15311]
===
match
---
name: to_run [9516,9522]
name: to_run [9516,9522]
===
match
---
atom_expr [25647,25675]
atom_expr [25642,25670]
===
match
---
expr_stmt [4930,4991]
expr_stmt [4930,4991]
===
match
---
name: session [15420,15427]
name: session [15415,15422]
===
match
---
operator: = [37786,37787]
operator: = [37781,37782]
===
match
---
comparison [20085,20134]
comparison [20080,20129]
===
match
---
operator: , [37287,37288]
operator: , [37282,37283]
===
match
---
argument [28836,29248]
argument [28831,29243]
===
match
---
name: t [33450,33451]
name: t [33445,33446]
===
match
---
name: can_run [12830,12837]
name: can_run [12825,12832]
===
match
---
operator: = [7463,7464]
operator: = [7463,7464]
===
match
---
name: pool [24367,24371]
name: pool [24362,24366]
===
match
---
trailer [13996,13999]
trailer [13991,13994]
===
match
---
atom_expr [21278,21290]
atom_expr [21273,21285]
===
match
---
simple_stmt [18961,18988]
simple_stmt [18956,18983]
===
match
---
operator: , [1139,1140]
operator: , [1139,1140]
===
match
---
trailer [38418,38424]
trailer [38413,38419]
===
match
---
trailer [12815,12860]
trailer [12810,12855]
===
match
---
argument [19428,19443]
argument [19423,19438]
===
match
---
name: dagrun_start_date [33291,33308]
name: dagrun_start_date [33286,33303]
===
match
---
trailer [8722,8730]
trailer [8722,8730]
===
match
---
return_stmt [27618,27643]
return_stmt [27613,27638]
===
match
---
operator: = [4473,4474]
operator: = [4473,4474]
===
match
---
name: values [26836,26842]
name: values [26831,26837]
===
match
---
trailer [32573,32582]
trailer [32568,32577]
===
match
---
name: refreshed_tis [8126,8139]
name: refreshed_tis [8126,8139]
===
match
---
atom_expr [37289,37301]
atom_expr [37284,37296]
===
match
---
atom_expr [13101,13173]
atom_expr [13096,13168]
===
match
---
and_test [11657,11740]
and_test [11652,11735]
===
match
---
name: debug [18439,18444]
name: debug [18434,18439]
===
match
---
name: self [22853,22857]
name: self [22848,22852]
===
match
---
name: session [19967,19974]
name: session [19962,19969]
===
match
---
suite [24564,24805]
suite [24559,24800]
===
match
---
name: TaskInstanceKey [1422,1437]
name: TaskInstanceKey [1422,1437]
===
match
---
atom_expr [18918,18935]
atom_expr [18913,18930]
===
match
---
name: state [13266,13271]
name: state [13261,13266]
===
match
---
name: __init__ [5089,5097]
name: __init__ [5089,5097]
===
match
---
argument [22567,22584]
argument [22562,22579]
===
match
---
operator: += [30131,30133]
operator: += [30126,30128]
===
match
---
name: rerun_failed_tasks [19469,19487]
name: rerun_failed_tasks [19464,19482]
===
match
---
name: ti_status [35461,35470]
name: ti_status [35456,35465]
===
match
---
name: running [10575,10582]
name: running [10570,10577]
===
match
---
name: log [16141,16144]
name: log [16136,16139]
===
match
---
atom_expr [20662,20675]
atom_expr [20657,20670]
===
match
---
operator: = [7801,7802]
operator: = [7801,7802]
===
match
---
name: ti_status [15949,15958]
name: ti_status [15944,15953]
===
match
---
trailer [37277,37287]
trailer [37272,37282]
===
match
---
trailer [8514,8522]
trailer [8514,8522]
===
match
---
operator: , [1190,1191]
operator: , [1190,1191]
===
match
---
simple_stmt [19008,19015]
simple_stmt [19003,19010]
===
match
---
name: ti [21764,21766]
name: ti [21759,21761]
===
match
---
atom_expr [13907,13916]
atom_expr [13902,13911]
===
match
---
name: coerce_datetime [33026,33041]
name: coerce_datetime [33021,33036]
===
match
---
string: "reaching concurrency limits. Re-adding task to queue." [10403,10458]
string: "reaching concurrency limits. Re-adding task to queue." [10398,10453]
===
match
---
arith_expr [35347,35407]
arith_expr [35342,35402]
===
match
---
lambdef [27930,28010]
lambdef [27925,28005]
===
match
---
name: SystemExit [35945,35955]
name: SystemExit [35940,35950]
===
match
---
comparison [23676,23700]
comparison [23671,23695]
===
match
---
name: items [38134,38139]
name: items [38129,38134]
===
match
---
name: log [11408,11411]
name: log [11403,11406]
===
match
---
atom_expr [26700,26717]
atom_expr [26695,26712]
===
match
---
operator: } [4635,4636]
operator: } [4635,4636]
===
match
---
name: session [37814,37821]
name: session [37809,37816]
===
match
---
trailer [7553,7572]
trailer [7553,7572]
===
match
---
atom_expr [11526,11538]
atom_expr [11521,11533]
===
match
---
name: self [7250,7254]
name: self [7250,7254]
===
match
---
simple_stmt [35635,35853]
simple_stmt [35630,35848]
===
match
---
name: dag [7082,7085]
name: dag [7082,7085]
===
match
---
name: self [7493,7497]
name: self [7493,7497]
===
match
---
name: self [18127,18131]
name: self [18122,18126]
===
match
---
arglist [28054,28123]
arglist [28049,28118]
===
match
---
name: all [8357,8360]
name: all [8357,8360]
===
match
---
name: self [32090,32094]
name: self [32085,32089]
===
match
---
simple_stmt [7364,7405]
simple_stmt [7364,7405]
===
match
---
name: heartbeat [26258,26267]
name: heartbeat [26253,26262]
===
match
---
name: tasks_that_depend_on_past [33689,33714]
name: tasks_that_depend_on_past [33684,33709]
===
match
---
trailer [11315,11317]
trailer [11310,11312]
===
match
---
name: pickle_id [31866,31875]
name: pickle_id [31861,31870]
===
match
---
atom_expr [35818,35829]
atom_expr [35813,35824]
===
match
---
suite [23209,23472]
suite [23204,23467]
===
match
---
name: remaining_dates [35329,35344]
name: remaining_dates [35324,35339]
===
match
---
name: dag_run [31550,31557]
name: dag_run [31545,31552]
===
match
---
simple_stmt [18381,18410]
simple_stmt [18376,18405]
===
match
---
comparison [19580,19629]
comparison [19575,19624]
===
match
---
operator: , [11628,11629]
operator: , [11623,11624]
===
match
---
operator: , [5172,5173]
operator: , [5172,5173]
===
match
---
name: session [14234,14241]
name: session [14229,14236]
===
match
---
name: dag_runs [32096,32104]
name: dag_runs [32091,32099]
===
match
---
trailer [8340,8356]
trailer [8340,8356]
===
match
---
name: ignore_depends_on_past [28903,28925]
name: ignore_depends_on_past [28898,28920]
===
match
---
name: task [18020,18024]
name: task [18015,18019]
===
match
---
atom_expr [4649,4661]
atom_expr [4649,4661]
===
match
---
atom_expr [28316,28326]
atom_expr [28311,28321]
===
match
---
expr_stmt [2136,2191]
expr_stmt [2136,2191]
===
match
---
name: start_date [31889,31899]
name: start_date [31884,31894]
===
match
---
name: ti_status [9188,9197]
name: ti_status [9188,9197]
===
match
---
atom_expr [19464,19487]
atom_expr [19459,19482]
===
match
---
if_stmt [25096,25349]
if_stmt [25091,25344]
===
match
---
trailer [18789,18795]
trailer [18784,18790]
===
match
---
name: self [8882,8886]
name: self [8882,8886]
===
match
---
name: skipped [4285,4292]
name: skipped [4285,4292]
===
match
---
operator: = [34018,34019]
operator: = [34013,34014]
===
match
---
arglist [22239,22585]
arglist [22234,22580]
===
match
---
string: "FIXME: task instance %s state was set to none externally or " [10320,10382]
string: "FIXME: task instance %s state was set to none externally or " [10315,10377]
===
match
---
comparison [23178,23208]
comparison [23173,23203]
===
match
---
operator: = [36428,36429]
operator: = [36423,36424]
===
match
---
name: self [21909,21913]
name: self [21904,21908]
===
match
---
string: "Task Instance %s already in executor waiting for queue to clear" [21395,21460]
string: "Task Instance %s already in executor waiting for queue to clear" [21390,21455]
===
match
---
trailer [15397,15401]
trailer [15392,15396]
===
match
---
simple_stmt [18513,18539]
simple_stmt [18508,18534]
===
match
---
name: make_transient [15046,15060]
name: make_transient [15041,15055]
===
match
---
atom_expr [32484,32498]
atom_expr [32479,32493]
===
match
---
argument [20560,20575]
argument [20555,20570]
===
match
---
trailer [16055,16077]
trailer [16050,16072]
===
match
---
operator: , [27705,27706]
operator: , [27700,27701]
===
match
---
operator: , [33308,33309]
operator: , [33303,33304]
===
match
---
name: self [35970,35974]
name: self [35965,35969]
===
match
---
name: self [32622,32626]
name: self [32617,32621]
===
match
---
name: State [19607,19612]
name: State [19602,19607]
===
match
---
comparison [9334,9364]
comparison [9334,9364]
===
match
---
trailer [23434,23439]
trailer [23429,23434]
===
match
---
name: session [35285,35292]
name: session [35280,35287]
===
match
---
atom_expr [37556,37571]
atom_expr [37551,37566]
===
match
---
simple_stmt [20597,20677]
simple_stmt [20592,20672]
===
match
---
simple_stmt [20297,20323]
simple_stmt [20292,20318]
===
match
---
argument [24963,24998]
argument [24958,24993]
===
match
---
trailer [4787,4797]
trailer [4787,4797]
===
match
---
name: reduced_key [10587,10598]
name: reduced_key [10582,10593]
===
match
---
suite [15361,15408]
suite [15356,15403]
===
match
---
trailer [28818,29262]
trailer [28813,29257]
===
match
---
operator: , [18176,18177]
operator: , [18171,18172]
===
match
---
string: "Not scheduling since DAG max_active_tasks limit is reached." [25257,25318]
string: "Not scheduling since DAG max_active_tasks limit is reached." [25252,25313]
===
match
---
name: ti [21710,21712]
name: ti [21705,21707]
===
match
---
simple_stmt [1603,1647]
simple_stmt [1603,1647]
===
match
---
name: ignore_task_deps [22402,22418]
name: ignore_task_deps [22397,22413]
===
match
---
trailer [23540,23558]
trailer [23535,23553]
===
match
---
suite [19997,20462]
suite [19992,20457]
===
match
---
operator: = [17306,17307]
operator: = [17301,17302]
===
match
---
trailer [22861,22867]
trailer [22856,22862]
===
match
---
name: dagrun_info [34862,34873]
name: dagrun_info [34857,34868]
===
match
---
name: log [18435,18438]
name: log [18430,18433]
===
match
---
atom [2215,2254]
atom [2215,2254]
===
match
---
atom_expr [7077,7085]
atom_expr [7077,7085]
===
match
---
string: """         Returns a map of task instance key to task instance object for the tasks to         run in the given dag run.          :param dag_run: the dag run to get the tasks from         :type dag_run: airflow.models.DagRun         :param session: the database session object         :type session: sqlalchemy.orm.session.Session         """ [14366,14709]
string: """         Returns a map of task instance key to task instance object for the tasks to         run in the given dag run.          :param dag_run: the dag run to get the tasks from         :type dag_run: airflow.models.DagRun         :param session: the database session object         :type session: sqlalchemy.orm.session.Session         """ [14361,14704]
===
match
---
trailer [19659,19663]
trailer [19654,19658]
===
match
---
simple_stmt [23773,23800]
simple_stmt [23768,23795]
===
match
---
trailer [19231,19235]
trailer [19226,19230]
===
match
---
import_from [1285,1326]
import_from [1285,1326]
===
match
---
name: self [21278,21282]
name: self [21273,21277]
===
match
---
if_stmt [23020,23100]
if_stmt [23015,23095]
===
match
---
trailer [10298,10501]
trailer [10293,10496]
===
match
---
operator: == [22807,22809]
operator: == [22802,22804]
===
match
---
decorator [30253,30270]
decorator [30248,30265]
===
match
---
name: get_num_task_instances [24870,24892]
name: get_num_task_instances [24865,24887]
===
match
---
name: task_id [25598,25605]
name: task_id [25593,25600]
===
match
---
simple_stmt [11585,11641]
simple_stmt [11580,11636]
===
match
---
atom_expr [13120,13130]
atom_expr [13115,13125]
===
match
---
suite [32642,36330]
suite [32637,36325]
===
match
---
name: start_date [35245,35255]
name: start_date [35240,35250]
===
match
---
atom_expr [7364,7385]
atom_expr [7364,7385]
===
match
---
name: self [37022,37026]
name: self [37017,37021]
===
match
---
name: ti [38416,38418]
name: ti [38411,38413]
===
match
---
string: 'Sending %s to executor' [21531,21555]
string: 'Sending %s to executor' [21526,21550]
===
match
---
argument [28991,29011]
argument [28986,29006]
===
match
---
name: tabulate [28045,28053]
name: tabulate [28040,28048]
===
match
---
name: set [4813,4816]
name: set [4813,4816]
===
match
---
name: __mapper_args__ [2197,2212]
name: __mapper_args__ [2197,2212]
===
match
---
atom_expr [9506,9530]
atom_expr [9506,9530]
===
match
---
simple_stmt [15046,15070]
simple_stmt [15041,15065]
===
match
---
name: ignore_task_deps [5282,5298]
name: ignore_task_deps [5282,5298]
===
match
---
name: running [20414,20421]
name: running [20409,20416]
===
match
---
operator: = [4958,4959]
operator: = [4958,4959]
===
match
---
trailer [12026,12030]
trailer [12021,12025]
===
match
---
name: x [38659,38660]
name: x [38654,38655]
===
match
---
trailer [31745,31778]
trailer [31740,31773]
===
match
---
simple_stmt [25887,26050]
simple_stmt [25882,26045]
===
match
---
name: ignore_task_deps [7388,7404]
name: ignore_task_deps [7388,7404]
===
match
---
name: dag_run [32425,32432]
name: dag_run [32420,32427]
===
match
---
trailer [11686,11694]
trailer [11681,11689]
===
match
---
name: self [4649,4653]
name: self [4649,4653]
===
match
---
atom_expr [23328,23345]
atom_expr [23323,23340]
===
match
---
arglist [24922,25044]
arglist [24917,25039]
===
match
---
operator: = [22659,22660]
operator: = [22654,22655]
===
match
---
expr_stmt [28596,28634]
expr_stmt [28591,28629]
===
match
---
name: kwargs [7722,7728]
name: kwargs [7722,7728]
===
match
---
comparison [23523,23558]
comparison [23518,23553]
===
match
---
trailer [16140,16144]
trailer [16135,16139]
===
match
---
testlist_star_expr [11332,11343]
testlist_star_expr [11327,11338]
===
match
---
import_from [1489,1555]
import_from [1489,1555]
===
match
---
name: state [37633,37638]
name: state [37628,37633]
===
match
---
atom_expr [34202,34235]
atom_expr [34197,34230]
===
match
---
atom_expr [15395,15401]
atom_expr [15390,15396]
===
match
---
simple_stmt [7133,7165]
simple_stmt [7133,7165]
===
match
---
atom_expr [33891,33969]
atom_expr [33886,33964]
===
match
---
expr_stmt [38520,38605]
expr_stmt [38515,38600]
===
match
---
trailer [15287,15297]
trailer [15282,15292]
===
match
---
operator: , [31939,31940]
operator: , [31934,31935]
===
match
---
trailer [33423,33427]
trailer [33418,33422]
===
match
---
comp_op [37915,37921]
comp_op [37910,37916]
===
match
---
operator: , [13748,13749]
operator: , [13743,13744]
===
match
---
expr_stmt [7291,7355]
expr_stmt [7291,7355]
===
match
---
atom_expr [34377,34385]
atom_expr [34372,34380]
===
match
---
simple_stmt [8093,8118]
simple_stmt [8093,8118]
===
match
---
name: start [34570,34575]
name: start [34565,34570]
===
match
---
number: 0 [17425,17426]
number: 0 [17420,17421]
===
match
---
string: '\n\nThese tasks are deadlocked:\n' [30134,30169]
string: '\n\nThese tasks are deadlocked:\n' [30129,30164]
===
match
---
atom_expr [5004,5022]
atom_expr [5004,5022]
===
match
---
name: dagrun_infos [31299,31311]
name: dagrun_infos [31294,31306]
===
match
---
name: self [34161,34165]
name: self [34156,34160]
===
match
---
name: _collect_errors [27674,27689]
name: _collect_errors [27669,27684]
===
match
---
operator: = [37151,37152]
operator: = [37146,37147]
===
match
---
atom_expr [33192,33227]
atom_expr [33187,33222]
===
match
---
name: ti_status [15838,15847]
name: ti_status [15833,15842]
===
match
---
name: key [20318,20321]
name: key [20313,20316]
===
match
---
if_stmt [24360,24450]
if_stmt [24355,24445]
===
match
---
expr_stmt [27385,27413]
expr_stmt [27380,27408]
===
match
---
arglist [20818,21018]
arglist [20813,21013]
===
match
---
suite [9365,9536]
suite [9365,9536]
===
match
---
arglist [17964,18001]
arglist [17959,17996]
===
match
---
operator: = [12095,12096]
operator: = [12090,12091]
===
match
---
name: session [32560,32567]
name: session [32555,32562]
===
match
---
simple_stmt [11499,11508]
simple_stmt [11494,11503]
===
match
---
atom_expr [32516,32547]
atom_expr [32511,32542]
===
match
---
atom_expr [34249,34287]
atom_expr [34244,34282]
===
match
---
name: failed [20257,20263]
name: failed [20252,20258]
===
match
---
funcdef [27730,28125]
funcdef [27725,28120]
===
match
---
operator: , [10979,10980]
operator: , [10974,10975]
===
match
---
trailer [24321,24326]
trailer [24316,24321]
===
match
---
expr_stmt [15382,15407]
expr_stmt [15377,15402]
===
match
---
name: ignore_depends_on_past [22471,22493]
name: ignore_depends_on_past [22466,22488]
===
match
---
trailer [15271,15281]
trailer [15266,15276]
===
match
---
operator: = [18072,18073]
operator: = [18067,18068]
===
match
---
name: set [4765,4768]
name: set [4765,4768]
===
match
---
atom_expr [33419,33446]
atom_expr [33414,33441]
===
match
---
testlist_comp [37272,37301]
testlist_comp [37267,37296]
===
match
---
atom [19592,19629]
atom [19587,19624]
===
match
---
name: state [1801,1806]
name: state [1801,1806]
===
match
---
comparison [14748,14763]
comparison [14743,14758]
===
match
---
name: ignore_task_deps [7369,7385]
name: ignore_task_deps [7369,7385]
===
match
---
name: task_id [28385,28392]
name: task_id [28380,28387]
===
match
---
simple_stmt [31667,31706]
simple_stmt [31662,31701]
===
match
---
simple_stmt [9239,9248]
simple_stmt [9239,9248]
===
match
---
operator: , [37804,37805]
operator: , [37799,37800]
===
match
---
trailer [24134,24136]
trailer [24129,24131]
===
match
---
operator: , [16204,16205]
operator: , [16199,16200]
===
match
---
name: running [17444,17451]
name: running [17439,17446]
===
match
---
name: executor [35154,35162]
name: executor [35149,35157]
===
match
---
argument [35113,35132]
argument [35108,35127]
===
match
---
name: _dag_runs [27256,27265]
name: _dag_runs [27251,27260]
===
match
---
trailer [22800,22806]
trailer [22795,22801]
===
match
---
trailer [37910,37914]
trailer [37905,37909]
===
match
---
trailer [18522,18529]
trailer [18517,18524]
===
match
---
string: "Task instance %s skipped. Don't rerun." [18796,18836]
string: "Task instance %s skipped. Don't rerun." [18791,18831]
===
match
---
name: self [27690,27694]
name: self [27685,27689]
===
match
---
trailer [35888,35908]
trailer [35883,35903]
===
match
---
param [4285,4298]
param [4285,4298]
===
match
---
expr_stmt [7173,7200]
expr_stmt [7173,7200]
===
match
---
trailer [28268,28343]
trailer [28263,28338]
===
match
---
trailer [34267,34287]
trailer [34262,34282]
===
match
---
name: self [5051,5055]
name: self [5051,5055]
===
match
---
name: ti_status [26890,26899]
name: ti_status [26885,26894]
===
match
---
trailer [34040,34076]
trailer [34035,34071]
===
match
---
simple_stmt [5544,7069]
simple_stmt [5544,7069]
===
match
---
atom_expr [15985,16001]
atom_expr [15980,15996]
===
match
---
trailer [18404,18409]
trailer [18399,18404]
===
match
---
name: instance [33201,33209]
name: instance [33196,33204]
===
match
---
suite [20516,20677]
suite [20511,20672]
===
match
---
operator: = [12809,12810]
operator: = [12804,12805]
===
match
---
operator: = [4531,4532]
operator: = [4531,4532]
===
match
---
comp_if [37876,37933]
comp_if [37871,37928]
===
match
---
suite [21355,21466]
suite [21350,21461]
===
match
---
name: log [35640,35643]
name: log [35635,35638]
===
match
---
comp_op [37886,37892]
comp_op [37881,37887]
===
match
---
operator: , [5494,5495]
operator: , [5494,5495]
===
match
---
name: ti [12058,12060]
name: ti [12053,12055]
===
match
---
simple_stmt [30016,30056]
simple_stmt [30011,30051]
===
match
---
arglist [19942,19974]
arglist [19937,19969]
===
match
---
trailer [38646,38674]
trailer [38641,38669]
===
match
---
name: utils [1745,1750]
name: utils [1745,1750]
===
match
---
trailer [13112,13173]
trailer [13107,13168]
===
match
---
trailer [20953,20970]
trailer [20948,20965]
===
match
---
name: ti_status [30315,30324]
name: ti_status [30310,30319]
===
match
---
simple_stmt [9682,9744]
simple_stmt [9682,9744]
===
match
---
name: running [23736,23743]
name: running [23731,23738]
===
match
---
atom_expr [16052,16077]
atom_expr [16047,16072]
===
match
---
name: self [4216,4220]
name: self [4216,4220]
===
match
---
atom_expr [18699,18712]
atom_expr [18694,18707]
===
match
---
simple_stmt [21380,21466]
simple_stmt [21375,21461]
===
match
---
trailer [37638,37642]
trailer [37633,37637]
===
match
---
name: pop [8977,8980]
name: pop [8977,8980]
===
match
---
expr_stmt [7364,7404]
expr_stmt [7364,7404]
===
match
---
funcdef [30274,32025]
funcdef [30269,32020]
===
match
---
name: run [14166,14169]
name: run [14161,14164]
===
match
---
trailer [8890,8896]
trailer [8890,8896]
===
match
---
simple_stmt [37353,37701]
simple_stmt [37348,37696]
===
match
---
name: executor [26357,26365]
name: executor [26352,26360]
===
match
---
name: _execute [32613,32621]
name: _execute [32608,32616]
===
match
---
name: AirflowException [33533,33549]
name: AirflowException [33528,33544]
===
match
---
trailer [32533,32547]
trailer [32528,32542]
===
match
---
name: self [33256,33260]
name: self [33251,33255]
===
match
---
import_as_names [1312,1326]
import_as_names [1312,1326]
===
match
---
name: ti [15335,15337]
name: ti [15330,15332]
===
match
---
name: pop [23091,23094]
name: pop [23086,23089]
===
match
---
name: tasks_to_run [14718,14730]
name: tasks_to_run [14713,14725]
===
match
---
name: respect_dag_max_active_limit [12780,12808]
name: respect_dag_max_active_limit [12775,12803]
===
match
---
name: ti [15269,15271]
name: ti [15264,15266]
===
match
---
simple_stmt [31715,31951]
simple_stmt [31710,31946]
===
match
---
name: session [32628,32635]
name: session [32623,32630]
===
match
---
atom_expr [15911,15930]
atom_expr [15906,15925]
===
match
---
atom_expr [18612,18638]
atom_expr [18607,18633]
===
match
---
name: are_dependencies_met [21181,21201]
name: are_dependencies_met [21176,21196]
===
match
---
trailer [35557,35573]
trailer [35552,35568]
===
match
---
simple_stmt [1782,1820]
simple_stmt [1782,1820]
===
match
---
operator: , [22493,22494]
operator: , [22488,22489]
===
match
---
trailer [33133,33147]
trailer [33128,33142]
===
match
---
name: self [7364,7368]
name: self [7364,7368]
===
match
---
trailer [33795,33801]
trailer [33790,33796]
===
match
---
name: utcnow [21790,21796]
name: utcnow [21785,21791]
===
match
---
name: filter_for_tis [38089,38103]
name: filter_for_tis [38084,38098]
===
match
---
atom [38165,38365]
atom [38160,38360]
===
match
---
name: pool [24769,24773]
name: pool [24764,24768]
===
match
---
expr_stmt [28738,28773]
expr_stmt [28733,28768]
===
match
---
name: succeeded [4698,4707]
name: succeeded [4698,4707]
===
match
---
atom_expr [27006,27052]
atom_expr [27001,27047]
===
match
---
name: backfill_context [21235,21251]
name: backfill_context [21230,21246]
===
match
---
simple_stmt [38416,38438]
simple_stmt [38411,38433]
===
match
---
name: pickle [34411,34417]
name: pickle [34406,34412]
===
match
---
trailer [38310,38326]
trailer [38305,38321]
===
match
---
operator: , [13916,13917]
operator: , [13911,13912]
===
match
---
name: key [9831,9834]
name: key [9826,9829]
===
match
---
trailer [26949,26955]
trailer [26944,26950]
===
match
---
or_test [4710,4728]
or_test [4710,4728]
===
match
---
simple_stmt [28454,28537]
simple_stmt [28449,28532]
===
match
---
name: self [12022,12026]
name: self [12017,12021]
===
match
---
name: state [9037,9042]
name: state [9037,9042]
===
match
---
operator: , [930,931]
operator: , [930,931]
===
match
---
name: task [24166,24170]
name: task [24161,24165]
===
match
---
name: SCHEDULED [19417,19426]
name: SCHEDULED [19412,19421]
===
match
---
expr_stmt [18095,18109]
expr_stmt [18090,18104]
===
match
---
name: filter [37477,37483]
name: filter [37472,37478]
===
match
---
name: self [7413,7417]
name: self [7413,7417]
===
match
---
suite [23701,23753]
suite [23696,23748]
===
match
---
name: ti_status [18961,18970]
name: ti_status [18956,18965]
===
match
---
operator: = [38530,38531]
operator: = [38525,38526]
===
match
---
name: queued_tis [37893,37903]
name: queued_tis [37888,37898]
===
match
---
atom_expr [13939,13962]
atom_expr [13934,13957]
===
match
---
atom_expr [28999,29011]
atom_expr [28994,29006]
===
match
---
trailer [25140,25144]
trailer [25135,25139]
===
match
---
trailer [9476,9489]
trailer [9476,9489]
===
match
---
operator: , [5527,5528]
operator: , [5527,5528]
===
match
---
suite [22091,22156]
suite [22086,22151]
===
match
---
atom_expr [23230,23297]
atom_expr [23225,23292]
===
match
---
arglist [9399,9437]
arglist [9399,9437]
===
match
---
atom_expr [23726,23752]
atom_expr [23721,23747]
===
match
---
atom_expr [15801,15824]
atom_expr [15796,15819]
===
match
---
name: self [19464,19468]
name: self [19459,19463]
===
match
---
name: _per_task_process [26075,26092]
name: _per_task_process [26070,26087]
===
match
---
param [36391,36396]
param [36386,36391]
===
match
---
atom_expr [19195,19205]
atom_expr [19190,19200]
===
match
---
name: sleep [35878,35883]
name: sleep [35873,35878]
===
match
---
operator: = [9531,9532]
operator: = [9531,9532]
===
match
---
atom_expr [34502,34515]
atom_expr [34497,34510]
===
match
---
name: rerun_failed_tasks [7575,7593]
name: rerun_failed_tasks [7575,7593]
===
match
---
string: 'BackfillJob is deadlocked.' [28745,28773]
string: 'BackfillJob is deadlocked.' [28740,28768]
===
match
---
trailer [18336,18342]
trailer [18331,18337]
===
match
---
atom [26121,26199]
atom [26116,26194]
===
match
---
atom_expr [31667,31705]
atom_expr [31662,31700]
===
match
---
atom_expr [23030,23047]
atom_expr [23025,23042]
===
match
---
string: """         Updates the counters per state of the tasks that were running. Can re-add         to tasks to run in case required.          :param ti_status: the internal status of the backfill job tasks         :type ti_status: BackfillJob._DagRunTaskStatus         """ [7817,8084]
string: """         Updates the counters per state of the tasks that were running. Can re-add         to tasks to run in case required.          :param ti_status: the internal status of the backfill job tasks         :type ti_status: BackfillJob._DagRunTaskStatus         """ [7817,8084]
===
match
---
trailer [15337,15343]
trailer [15332,15338]
===
match
---
operator: , [17984,17985]
operator: , [17979,17980]
===
match
---
simple_stmt [37832,37935]
simple_stmt [37827,37930]
===
match
---
operator: = [8506,8507]
operator: = [8506,8507]
===
match
---
name: task_id [24185,24192]
name: task_id [24180,24187]
===
match
---
name: self [5004,5008]
name: self [5004,5008]
===
match
---
name: ignore_task_deps [22380,22396]
name: ignore_task_deps [22375,22391]
===
match
---
trailer [24184,24192]
trailer [24179,24187]
===
match
---
name: pop [22705,22708]
name: pop [22700,22703]
===
match
---
name: run_type [37563,37571]
name: run_type [37558,37566]
===
match
---
operator: = [4505,4506]
operator: = [4505,4506]
===
match
---
atom_expr [35884,35908]
atom_expr [35879,35903]
===
match
---
name: key [23676,23679]
name: key [23671,23674]
===
match
---
name: session [15475,15482]
name: session [15470,15477]
===
match
---
atom_expr [38708,38803]
atom_expr [38703,38798]
===
match
---
argument [19959,19974]
argument [19954,19969]
===
match
---
name: running [15959,15966]
name: running [15954,15961]
===
match
---
suite [38045,38076]
suite [38040,38071]
===
match
---
or_test [17401,17456]
or_test [17396,17451]
===
match
---
arglist [15617,16116]
arglist [15612,16111]
===
match
---
name: deadlocked [4836,4846]
name: deadlocked [4836,4846]
===
match
---
name: dag [13574,13577]
name: dag [13569,13572]
===
match
---
name: airflow [1787,1794]
name: airflow [1787,1794]
===
match
---
operator: = [30366,30367]
operator: = [30361,30362]
===
match
---
name: run [14059,14062]
name: run [14054,14057]
===
match
---
simple_stmt [8634,8697]
simple_stmt [8634,8697]
===
match
---
trailer [10826,10842]
trailer [10821,10837]
===
match
---
name: ti [28382,28384]
name: ti [28377,28379]
===
match
---
operator: += [28651,28653]
operator: += [28646,28648]
===
match
---
simple_stmt [27105,27148]
simple_stmt [27100,27143]
===
match
---
operator: , [38010,38011]
operator: , [38005,38006]
===
match
---
name: failed [4339,4345]
name: failed [4339,4345]
===
match
---
param [4421,4438]
param [4421,4438]
===
match
---
argument [22448,22493]
argument [22443,22488]
===
match
---
atom_expr [15282,15297]
atom_expr [15277,15292]
===
match
---
trailer [21524,21530]
trailer [21519,21525]
===
match
---
atom_expr [33017,33053]
atom_expr [33012,33048]
===
match
---
operator: = [10922,10923]
operator: = [10917,10918]
===
match
---
atom_expr [14059,14066]
atom_expr [14054,14061]
===
match
---
trailer [15594,15598]
trailer [15589,15593]
===
match
---
name: AirflowException [1042,1058]
name: AirflowException [1042,1058]
===
match
---
expr_stmt [34778,34995]
expr_stmt [34773,34990]
===
match
---
comparison [37908,37933]
comparison [37903,37928]
===
match
---
dotted_name [1561,1584]
dotted_name [1561,1584]
===
match
---
trailer [33437,33444]
trailer [33432,33439]
===
match
---
suite [35512,35574]
suite [35507,35569]
===
match
---
atom_expr [20297,20322]
atom_expr [20292,20317]
===
match
---
name: mark_success [5182,5194]
name: mark_success [5182,5194]
===
match
---
name: respect_dag_max_active_limit [13306,13334]
name: respect_dag_max_active_limit [13301,13329]
===
match
---
simple_stmt [36236,36253]
simple_stmt [36231,36248]
===
match
---
atom_expr [19942,19957]
atom_expr [19937,19952]
===
match
---
name: session [24512,24519]
name: session [24507,24514]
===
match
---
simple_stmt [12219,12660]
simple_stmt [12214,12655]
===
match
---
trailer [20421,20425]
trailer [20416,20420]
===
match
---
name: State [15237,15242]
name: State [15232,15237]
===
match
---
suite [21491,22714]
suite [21486,22709]
===
match
---
suite [26205,26240]
suite [26200,26235]
===
match
---
trailer [34596,34607]
trailer [34591,34602]
===
match
---
name: executed_dag_run_dates [35384,35406]
name: executed_dag_run_dates [35379,35401]
===
match
---
atom_expr [4675,4680]
atom_expr [4675,4680]
===
match
---
name: pickle_id [22331,22340]
name: pickle_id [22326,22335]
===
match
---
expr_stmt [5051,5079]
expr_stmt [5051,5079]
===
match
---
atom_expr [13262,13271]
atom_expr [13257,13266]
===
match
---
trailer [2183,2190]
trailer [2183,2190]
===
match
---
trailer [31690,31705]
trailer [31685,31700]
===
match
---
exprlist [11263,11273]
exprlist [11258,11268]
===
match
---
trailer [38539,38556]
trailer [38534,38551]
===
match
---
atom [28369,28441]
atom [28364,28436]
===
match
---
trailer [28396,28403]
trailer [28391,28398]
===
match
---
simple_stmt [11172,11197]
simple_stmt [11167,11192]
===
match
---
simple_stmt [7602,7637]
simple_stmt [7602,7637]
===
match
---
name: with_for_update [38311,38326]
name: with_for_update [38306,38321]
===
match
---
name: State [9641,9646]
name: State [9641,9646]
===
match
---
expr_stmt [9506,9535]
expr_stmt [9506,9535]
===
match
---
arglist [31792,31940]
arglist [31787,31935]
===
match
---
expr_stmt [12668,12703]
expr_stmt [12663,12698]
===
match
---
simple_stmt [4741,4771]
simple_stmt [4741,4771]
===
match
---
name: state [38419,38424]
name: state [38414,38419]
===
match
---
name: ti [22904,22906]
name: ti [22899,22901]
===
match
---
trailer [35986,36018]
trailer [35981,36013]
===
match
---
argument [35154,35171]
argument [35149,35166]
===
match
---
suite [25854,26050]
suite [25849,26045]
===
match
---
operator: = [37742,37743]
operator: = [37737,37738]
===
match
---
operator: , [12183,12184]
operator: , [12178,12179]
===
match
---
arglist [15282,15314]
arglist [15277,15309]
===
match
---
operator: = [26285,26286]
operator: = [26280,26281]
===
match
---
name: ti [11961,11963]
name: ti [11956,11958]
===
match
---
trailer [10815,10819]
trailer [10810,10814]
===
match
---
argument [29094,29145]
argument [29089,29140]
===
match
---
name: executor [34507,34515]
name: executor [34502,34510]
===
match
---
name: session [35472,35479]
name: session [35467,35474]
===
match
---
suite [37340,37701]
suite [37335,37696]
===
match
---
param [12150,12174]
param [12145,12169]
===
match
---
name: resettable_tis [37861,37875]
name: resettable_tis [37856,37870]
===
match
---
atom [27945,28010]
atom [27940,28005]
===
match
---
name: self [7291,7295]
name: self [7291,7295]
===
match
---
name: args [7714,7718]
name: args [7714,7718]
===
match
---
name: _manage_executor_state [27011,27033]
name: _manage_executor_state [27006,27028]
===
match
---
trailer [10290,10298]
trailer [10285,10293]
===
match
---
operator: , [10901,10902]
operator: , [10896,10897]
===
match
---
raise_stmt [24401,24449]
raise_stmt [24396,24444]
===
match
---
trailer [34569,34575]
trailer [34564,34570]
===
match
---
name: filter [24290,24296]
name: filter [24285,24291]
===
match
---
name: session [13881,13888]
name: session [13876,13883]
===
match
---
name: ti_status [34587,34596]
name: ti_status [34582,34591]
===
match
---
trailer [15875,15893]
trailer [15870,15888]
===
match
---
name: e [26237,26238]
name: e [26232,26233]
===
match
---
trailer [26913,26915]
trailer [26908,26910]
===
match
---
atom_expr [4881,4897]
atom_expr [4881,4897]
===
match
---
param [5107,5112]
param [5107,5112]
===
match
---
operator: = [13335,13336]
operator: = [13330,13331]
===
match
---
name: executed_dag_run_dates [4935,4957]
name: executed_dag_run_dates [4935,4957]
===
match
---
name: ti_status [23371,23380]
name: ti_status [23366,23375]
===
match
---
atom_expr [20786,21036]
atom_expr [20781,21031]
===
match
---
argument [29147,29162]
argument [29142,29157]
===
match
---
name: State [15282,15287]
name: State [15277,15282]
===
match
---
operator: = [5266,5267]
operator: = [5266,5267]
===
match
---
arglist [9699,9742]
arglist [9699,9742]
===
match
---
simple_stmt [8764,8773]
simple_stmt [8764,8773]
===
match
---
name: dag_runs [32403,32411]
name: dag_runs [32398,32406]
===
match
---
operator: += [29799,29801]
operator: += [29794,29796]
===
match
---
name: t [33400,33401]
name: t [33395,33396]
===
match
---
name: Optional [857,865]
name: Optional [857,865]
===
match
---
trailer [26257,26267]
trailer [26252,26262]
===
match
---
name: key [11453,11456]
name: key [11448,11451]
===
match
---
name: ti_status [17434,17443]
name: ti_status [17429,17438]
===
match
---
operator: = [28367,28368]
operator: = [28362,28363]
===
match
---
expr_stmt [14059,14072]
expr_stmt [14054,14067]
===
match
---
simple_stmt [7524,7541]
simple_stmt [7524,7541]
===
match
---
name: log [9687,9690]
name: log [9687,9690]
===
match
---
sync_comp_for [29219,29248]
sync_comp_for [29214,29243]
===
match
---
name: self [7777,7781]
name: self [7777,7781]
===
match
---
trailer [38133,38140]
trailer [38128,38135]
===
match
---
parameters [4202,4544]
parameters [4202,4544]
===
match
---
simple_stmt [32129,32380]
simple_stmt [32124,32375]
===
match
---
atom_expr [14166,14178]
atom_expr [14161,14173]
===
match
---
trailer [28330,28341]
trailer [28325,28336]
===
match
---
operator: = [24511,24512]
operator: = [24506,24507]
===
match
---
trailer [12819,12829]
trailer [12814,12824]
===
match
---
name: ignore_first_depends_on_past [5238,5266]
name: ignore_first_depends_on_past [5238,5266]
===
match
---
name: airflow [1248,1255]
name: airflow [1248,1255]
===
match
---
name: tis_values [28356,28366]
name: tis_values [28351,28361]
===
match
---
trailer [33069,33081]
trailer [33064,33076]
===
match
---
name: ti [28294,28296]
name: ti [28289,28291]
===
match
---
name: log [21521,21524]
name: log [21516,21519]
===
match
---
trailer [8356,8360]
trailer [8356,8360]
===
match
---
suite [26738,26958]
suite [26733,26953]
===
match
---
atom_expr [20085,20093]
atom_expr [20080,20088]
===
match
---
name: TI [8197,8199]
name: TI [8197,8199]
===
match
---
operator: , [38562,38563]
operator: , [38557,38558]
===
match
---
atom_expr [15838,15858]
atom_expr [15833,15853]
===
match
---
atom_expr [24922,24933]
atom_expr [24917,24928]
===
match
---
or_test [4960,4991]
or_test [4960,4991]
===
match
---
name: error [20169,20174]
name: error [20164,20169]
===
match
---
comparison [21909,22090]
comparison [21904,22085]
===
match
---
argument [31889,31910]
argument [31884,31905]
===
match
---
operator: = [35244,35245]
operator: = [35239,35240]
===
match
---
name: run_type [13930,13938]
name: run_type [13925,13933]
===
match
---
trailer [19947,19957]
trailer [19942,19952]
===
match
---
atom_expr [23773,23794]
atom_expr [23768,23789]
===
match
---
trailer [26889,26916]
trailer [26884,26911]
===
match
---
trailer [7703,7712]
trailer [7703,7712]
===
match
---
name: executor [11188,11196]
name: executor [11183,11191]
===
match
---
operator: , [1058,1059]
operator: , [1058,1059]
===
match
---
name: dagrun_infos [35055,35067]
name: dagrun_infos [35050,35062]
===
match
---
name: info [36298,36302]
name: info [36293,36297]
===
match
---
operator: = [4662,4663]
operator: = [4662,4663]
===
match
---
param [28155,28181]
param [28150,28176]
===
match
---
simple_stmt [29795,29835]
simple_stmt [29790,29830]
===
match
---
simple_stmt [14166,14205]
simple_stmt [14161,14200]
===
match
---
name: cfg_path [21866,21874]
name: cfg_path [21861,21869]
===
match
---
import_from [1194,1242]
import_from [1194,1242]
===
match
---
name: State [37272,37277]
name: State [37267,37272]
===
match
---
name: id [21737,21739]
name: id [21732,21734]
===
match
---
operator: = [19966,19967]
operator: = [19961,19962]
===
match
---
name: session [25709,25716]
name: session [25704,25711]
===
match
---
name: ti [20546,20548]
name: ti [20541,20543]
===
match
---
name: _log_progress [15550,15563]
name: _log_progress [15545,15558]
===
match
---
name: max_tis_per_query [38587,38604]
name: max_tis_per_query [38582,38599]
===
match
---
trailer [32523,32533]
trailer [32518,32528]
===
match
---
name: executor [22181,22189]
name: executor [22176,22184]
===
match
---
arglist [18142,18190]
arglist [18137,18185]
===
match
---
trailer [27010,27033]
trailer [27005,27028]
===
match
---
name: PoolNotFound [24407,24419]
name: PoolNotFound [24402,24414]
===
match
---
name: pool [24488,24492]
name: pool [24483,24487]
===
match
---
testlist_comp [26122,26198]
testlist_comp [26117,26193]
===
match
---
name: UP_FOR_RETRY [23196,23208]
name: UP_FOR_RETRY [23191,23203]
===
match
---
suite [31366,31706]
suite [31361,31701]
===
match
---
argument [14911,14926]
argument [14906,14921]
===
match
---
name: log [9081,9084]
name: log [9081,9084]
===
match
---
trailer [31410,31445]
trailer [31405,31440]
===
match
---
name: dag_id [28308,28314]
name: dag_id [28303,28309]
===
match
---
name: executed_run_dates [27488,27506]
name: executed_run_dates [27483,27501]
===
match
---
expr_stmt [4693,4728]
expr_stmt [4693,4728]
===
match
---
trailer [17475,17486]
trailer [17470,17481]
===
match
---
name: provide_session [7736,7751]
name: provide_session [7736,7751]
===
match
---
operator: += [29738,29740]
operator: += [29733,29735]
===
match
---
trailer [20796,21036]
trailer [20791,21031]
===
match
---
atom_expr [24107,24137]
atom_expr [24102,24132]
===
match
---
name: rerun_failed_tasks [5408,5426]
name: rerun_failed_tasks [5408,5426]
===
match
---
classdef [1865,38834]
classdef [1865,38829]
===
match
---
name: query [8324,8329]
name: query [8324,8329]
===
match
---
number: 0 [26722,26723]
number: 0 [26717,26718]
===
match
---
trailer [27551,27565]
trailer [27546,27560]
===
match
---
name: verbose [29164,29171]
name: verbose [29159,29166]
===
match
---
name: err [29734,29737]
name: err [29729,29732]
===
match
---
name: to_run [26900,26906]
name: to_run [26895,26901]
===
match
---
name: self [9076,9080]
name: self [9076,9080]
===
match
---
operator: = [14142,14143]
operator: = [14137,14138]
===
match
---
trailer [24974,24998]
trailer [24969,24993]
===
match
---
argument [25640,25675]
argument [25635,25670]
===
match
---
atom_expr [20160,20222]
atom_expr [20155,20217]
===
match
---
operator: = [13632,13633]
operator: = [13627,13628]
===
match
---
trailer [18743,18751]
trailer [18738,18746]
===
match
---
name: reset_state_for_orphaned_tasks [14853,14883]
name: reset_state_for_orphaned_tasks [14848,14878]
===
match
---
operator: += [30186,30188]
operator: += [30181,30183]
===
match
---
name: SKIPPED [8806,8813]
name: SKIPPED [8806,8813]
===
match
---
name: ignore_depends_on_past [22448,22470]
name: ignore_depends_on_past [22443,22465]
===
match
---
operator: , [11451,11452]
operator: , [11446,11447]
===
match
---
suite [14357,15541]
suite [14352,15536]
===
match
---
name: to_run [4234,4240]
name: to_run [4234,4240]
===
match
---
name: dagrun_end_date [33310,33325]
name: dagrun_end_date [33305,33320]
===
match
---
expr_stmt [22636,22663]
expr_stmt [22631,22658]
===
match
---
name: dag_id [13124,13130]
name: dag_id [13119,13125]
===
match
---
atom_expr [27514,27532]
atom_expr [27509,27527]
===
match
---
name: err [28738,28741]
name: err [28733,28736]
===
match
---
name: ti_status [10565,10574]
name: ti_status [10560,10569]
===
match
---
atom_expr [17430,17452]
atom_expr [17425,17447]
===
match
---
operator: , [18836,18837]
operator: , [18831,18832]
===
match
---
trailer [27998,28009]
trailer [27993,28004]
===
match
---
name: join [38642,38646]
name: join [38637,38641]
===
match
---
atom_expr [10751,10789]
atom_expr [10746,10784]
===
match
---
operator: = [5298,5299]
operator: = [5298,5299]
===
match
---
name: self [11712,11716]
name: self [11707,11711]
===
match
---
atom_expr [27547,27576]
atom_expr [27542,27571]
===
match
---
expr_stmt [33236,33327]
expr_stmt [33231,33322]
===
match
---
if_stmt [10698,10943]
if_stmt [10693,10938]
===
match
---
operator: , [22418,22419]
operator: , [22413,22414]
===
match
---
name: session [7794,7801]
name: session [7794,7801]
===
match
---
name: ti_status [31613,31622]
name: ti_status [31608,31617]
===
match
---
operator: , [28098,28099]
operator: , [28093,28094]
===
match
---
trailer [34532,34539]
trailer [34527,34534]
===
match
---
operator: = [7325,7326]
operator: = [7325,7326]
===
match
---
simple_stmt [7173,7201]
simple_stmt [7173,7201]
===
match
---
trailer [10544,10548]
trailer [10539,10543]
===
match
---
trailer [19816,19820]
trailer [19811,19815]
===
match
---
operator: = [21875,21876]
operator: = [21870,21871]
===
match
---
name: LOCAL_EXECUTOR [34221,34235]
name: LOCAL_EXECUTOR [34216,34230]
===
match
---
operator: == [26651,26653]
operator: == [26646,26648]
===
match
---
name: running [4259,4266]
name: running [4259,4266]
===
match
---
name: ti [22798,22800]
name: ti [22793,22795]
===
match
---
name: executor_class [21914,21928]
name: executor_class [21909,21923]
===
match
---
operator: , [38767,38768]
operator: , [38762,38763]
===
match
---
atom_expr [31337,31345]
atom_expr [31332,31340]
===
match
---
expr_stmt [34684,34722]
expr_stmt [34679,34717]
===
match
---
trailer [38269,38273]
trailer [38264,38268]
===
match
---
name: ti_status [28675,28684]
name: ti_status [28670,28679]
===
match
---
atom_expr [34610,34627]
atom_expr [34605,34622]
===
match
---
comparison [20350,20374]
comparison [20345,20369]
===
match
---
name: finished [27355,27363]
name: finished [27350,27358]
===
match
---
name: TaskInstance [8158,8170]
name: TaskInstance [8158,8170]
===
match
---
atom_expr [15382,15402]
atom_expr [15377,15397]
===
match
---
suite [36223,36280]
suite [36218,36275]
===
match
---
operator: , [11337,11338]
operator: , [11332,11333]
===
match
---
import_from [1438,1488]
import_from [1438,1488]
===
match
---
operator: = [23795,23796]
operator: = [23790,23791]
===
match
---
atom_expr [10616,10640]
atom_expr [10611,10635]
===
match
---
name: self [15590,15594]
name: self [15585,15589]
===
match
---
name: key [18534,18537]
name: key [18529,18532]
===
match
---
atom_expr [36184,36205]
atom_expr [36179,36200]
===
match
---
name: value [11346,11351]
name: value [11341,11346]
===
match
---
trailer [37562,37571]
trailer [37557,37566]
===
match
---
string: "Task instance %s retry period not expired yet" [23245,23292]
string: "Task instance %s retry period not expired yet" [23240,23287]
===
match
---
trailer [28837,28858]
trailer [28832,28853]
===
match
---
operator: , [4271,4272]
operator: , [4271,4272]
===
match
---
atom_expr [13773,13790]
atom_expr [13768,13785]
===
match
---
operator: , [4507,4508]
operator: , [4507,4508]
===
match
---
expr_stmt [8126,8144]
expr_stmt [8126,8144]
===
match
---
operator: , [11456,11457]
operator: , [11451,11452]
===
match
---
operator: , [26169,26170]
operator: , [26164,26165]
===
match
---
name: State [11681,11686]
name: State [11676,11681]
===
match
---
name: key [11263,11266]
name: key [11258,11261]
===
match
---
atom [11666,11695]
atom [11661,11690]
===
match
---
name: ti_status [18734,18743]
name: ti_status [18729,18738]
===
match
---
simple_stmt [13233,13247]
simple_stmt [13228,13242]
===
match
---
operator: = [16407,16408]
operator: = [16402,16403]
===
match
---
name: airflow [1010,1017]
name: airflow [1010,1017]
===
match
---
name: reset_state_for_orphaned_tasks [36360,36390]
name: reset_state_for_orphaned_tasks [36355,36385]
===
match
---
name: flush [38691,38696]
name: flush [38686,38691]
===
match
---
atom_expr [8959,8993]
atom_expr [8959,8993]
===
match
---
expr_stmt [23773,23799]
expr_stmt [23768,23794]
===
match
---
name: ti_status [31960,31969]
name: ti_status [31955,31964]
===
match
---
trailer [26709,26717]
trailer [26704,26712]
===
match
---
comparison [37314,37339]
comparison [37309,37334]
===
match
---
simple_stmt [31462,31531]
simple_stmt [31457,31526]
===
match
---
name: ti [11521,11523]
name: ti [11516,11518]
===
match
---
operator: = [24864,24865]
operator: = [24859,24860]
===
match
---
expr_stmt [14132,14157]
expr_stmt [14127,14152]
===
match
---
name: get_num_active_runs [12901,12920]
name: get_num_active_runs [12896,12915]
===
match
---
atom_expr [21516,21560]
atom_expr [21511,21555]
===
match
---
atom_expr [38427,38437]
atom_expr [38422,38432]
===
match
---
trailer [23525,23531]
trailer [23520,23526]
===
match
---
name: session [1751,1758]
name: session [1751,1758]
===
match
---
operator: += [28600,28602]
operator: += [28595,28597]
===
match
---
name: total_runs [34712,34722]
name: total_runs [34707,34717]
===
match
---
suite [12210,14270]
suite [12205,14265]
===
match
---
name: session [17986,17993]
name: session [17981,17988]
===
match
---
atom_expr [21178,21308]
atom_expr [21173,21303]
===
match
---
trailer [9158,9171]
trailer [9158,9171]
===
match
---
trailer [26230,26236]
trailer [26225,26231]
===
match
---
simple_stmt [38454,38472]
simple_stmt [38449,38467]
===
match
---
simple_stmt [23230,23298]
simple_stmt [23225,23293]
===
match
---
trailer [11309,11315]
trailer [11304,11310]
===
match
---
suite [18713,19015]
suite [18708,19010]
===
match
---
trailer [20425,20430]
trailer [20420,20425]
===
match
---
expr_stmt [7133,7164]
expr_stmt [7133,7164]
===
match
---
parameters [27689,27720]
parameters [27684,27715]
===
match
---
name: self [26253,26257]
name: self [26248,26252]
===
match
---
name: ti [23523,23525]
name: ti [23518,23520]
===
match
---
name: executor [30326,30334]
name: executor [30321,30329]
===
match
---
string: "Run ID" [28100,28108]
string: "Run ID" [28095,28103]
===
match
---
dotted_name [893,915]
dotted_name [893,915]
===
match
---
name: self [38582,38586]
name: self [38577,38581]
===
match
---
expr_stmt [8300,8362]
expr_stmt [8300,8362]
===
match
---
name: pickle_id [16356,16365]
name: pickle_id [16351,16360]
===
match
---
trailer [4612,4620]
trailer [4612,4620]
===
match
---
operator: = [7152,7153]
operator: = [7152,7153]
===
match
---
operator: @ [32588,32589]
operator: @ [32583,32584]
===
match
---
simple_stmt [35873,35910]
simple_stmt [35868,35905]
===
match
---
arglist [25531,25725]
arglist [25526,25720]
===
match
---
operator: = [32113,32114]
operator: = [32108,32109]
===
match
---
name: task_id [18048,18055]
name: task_id [18043,18050]
===
match
---
trailer [11953,11960]
trailer [11948,11955]
===
match
---
trailer [33260,33264]
trailer [33255,33259]
===
match
---
name: resettable_states [37251,37268]
name: resettable_states [37246,37263]
===
match
---
name: add [8601,8604]
name: add [8601,8604]
===
match
---
name: running [18622,18629]
name: running [18617,18624]
===
match
---
name: TaskInstance [17900,17912]
name: TaskInstance [17895,17907]
===
match
---
parameters [12143,12209]
parameters [12138,12204]
===
match
---
trailer [24128,24134]
trailer [24123,24129]
===
match
---
expr_stmt [11521,11538]
expr_stmt [11516,11533]
===
match
---
atom_expr [13275,13288]
atom_expr [13270,13283]
===
match
---
name: only_if_necessary [26268,26285]
name: only_if_necessary [26263,26280]
===
match
---
testlist_comp [11667,11694]
testlist_comp [11662,11689]
===
match
---
name: run [27463,27466]
name: run [27458,27461]
===
match
---
param [27937,27943]
param [27932,27938]
===
match
---
parameters [10974,10989]
parameters [10969,10984]
===
match
---
atom_expr [11681,11694]
atom_expr [11676,11689]
===
match
---
name: pop [22991,22994]
name: pop [22986,22989]
===
match
---
operator: , [5124,5125]
operator: , [5124,5125]
===
match
---
atom_expr [11277,11318]
atom_expr [11272,11313]
===
match
---
name: ti [28405,28407]
name: ti [28400,28402]
===
match
---
name: dagrun_infos [33768,33780]
name: dagrun_infos [33763,33775]
===
match
---
comparison [11700,11740]
comparison [11695,11735]
===
match
---
operator: = [13991,13992]
operator: = [13986,13987]
===
match
---
not_test [33814,33830]
not_test [33809,33825]
===
match
---
simple_stmt [18095,18110]
simple_stmt [18090,18105]
===
match
---
name: key [23095,23098]
name: key [23090,23093]
===
match
---
atom_expr [36265,36279]
atom_expr [36260,36274]
===
match
---
operator: , [16328,16329]
operator: , [16323,16324]
===
match
---
name: task_instance_str [38615,38632]
name: task_instance_str [38610,38627]
===
match
---
decorated [17840,23972]
decorated [17835,23967]
===
match
---
suite [2284,5080]
suite [2284,5080]
===
match
---
name: pool [22533,22537]
name: pool [22528,22532]
===
match
---
name: warning [9691,9698]
name: warning [9691,9698]
===
match
---
name: dagrun_start_date [32997,33014]
name: dagrun_start_date [32992,33009]
===
match
---
atom_expr [37505,37517]
atom_expr [37500,37512]
===
match
---
operator: = [38163,38164]
operator: = [38158,38159]
===
match
---
atom_expr [38251,38292]
atom_expr [38246,38287]
===
match
---
suite [33831,34078]
suite [33826,34073]
===
match
---
simple_stmt [7817,8085]
simple_stmt [7817,8085]
===
match
---
name: log [33896,33899]
name: log [33891,33894]
===
match
---
name: state [23526,23531]
name: state [23521,23526]
===
match
---
operator: = [24969,24970]
operator: = [24964,24965]
===
match
---
name: ti_status [27385,27394]
name: ti_status [27380,27389]
===
match
---
name: task_id [27983,27990]
name: task_id [27978,27985]
===
match
---
operator: = [4402,4403]
operator: = [4402,4403]
===
match
---
name: to_run [9821,9827]
name: to_run [9816,9822]
===
match
---
name: list [24107,24111]
name: list [24102,24106]
===
match
---
trailer [10635,10639]
trailer [10630,10634]
===
match
---
name: delay_on_limit_secs [5333,5352]
name: delay_on_limit_secs [5333,5352]
===
match
---
simple_stmt [1732,1782]
simple_stmt [1732,1782]
===
match
---
string: "Task ID" [28089,28098]
string: "Task ID" [28084,28093]
===
match
---
operator: = [34500,34501]
operator: = [34495,34496]
===
match
---
simple_stmt [13182,13204]
simple_stmt [13177,13199]
===
match
---
trailer [31357,31365]
trailer [31352,31360]
===
match
---
arglist [21531,21559]
arglist [21526,21554]
===
match
---
name: state [9632,9637]
name: state [9632,9637]
===
match
---
trailer [19808,19816]
trailer [19803,19811]
===
match
---
argument [21270,21290]
argument [21265,21285]
===
match
---
trailer [19235,19243]
trailer [19230,19238]
===
match
---
name: warning [11412,11419]
name: warning [11407,11414]
===
match
---
return_stmt [38812,38833]
return_stmt [38807,38828]
===
match
---
atom_expr [30206,30226]
atom_expr [30201,30221]
===
match
---
name: self [19227,19231]
name: self [19222,19226]
===
match
---
operator: , [5323,5324]
operator: , [5323,5324]
===
match
---
arglist [11420,11481]
arglist [11415,11476]
===
match
---
trailer [8590,8600]
trailer [8590,8600]
===
match
---
simple_stmt [16136,16233]
simple_stmt [16131,16228]
===
match
---
name: succeeded [15921,15930]
name: succeeded [15916,15925]
===
match
---
atom_expr [8197,8248]
atom_expr [8197,8248]
===
match
---
trailer [34954,34977]
trailer [34949,34972]
===
match
---
simple_stmt [32425,32448]
simple_stmt [32420,32443]
===
match
---
name: open_slots [24475,24485]
name: open_slots [24470,24480]
===
match
---
expr_stmt [4831,4868]
expr_stmt [4831,4868]
===
match
---
arglist [33291,33325]
arglist [33286,33320]
===
match
---
name: lock_for_update [17964,17979]
name: lock_for_update [17959,17974]
===
match
---
testlist_comp [27946,28009]
testlist_comp [27941,28004]
===
match
---
operator: = [28489,28490]
operator: = [28484,28485]
===
match
---
operator: , [24998,24999]
operator: , [24993,24994]
===
match
---
name: provide_session [12107,12122]
name: provide_session [12102,12117]
===
match
---
trailer [9090,9121]
trailer [9090,9121]
===
match
---
name: sorted_ti_keys [27856,27870]
name: sorted_ti_keys [27851,27865]
===
match
---
name: ti_status [20247,20256]
name: ti_status [20242,20251]
===
match
---
operator: , [35829,35830]
operator: , [35824,35825]
===
match
---
trailer [37476,37483]
trailer [37471,37478]
===
match
---
name: State [21673,21678]
name: State [21668,21673]
===
match
---
trailer [37166,37174]
trailer [37161,37169]
===
match
---
name: airflow [983,990]
name: airflow [983,990]
===
match
---
trailer [27462,27467]
trailer [27457,27462]
===
match
---
name: err [35558,35561]
name: err [35553,35556]
===
match
---
trailer [28407,28418]
trailer [28402,28413]
===
match
---
name: state [8791,8796]
name: state [8791,8796]
===
match
---
suite [33161,33228]
suite [33156,33223]
===
match
---
operator: == [9343,9345]
operator: == [9343,9345]
===
match
---
atom_expr [24407,24449]
atom_expr [24402,24444]
===
match
---
trailer [17597,17599]
trailer [17592,17594]
===
match
---
atom [14733,14735]
atom [14728,14730]
===
match
---
suite [24071,26102]
suite [24066,26097]
===
match
---
name: running [11465,11472]
name: running [11460,11467]
===
match
---
atom_expr [23371,23397]
atom_expr [23366,23392]
===
match
---
name: to_run [17415,17421]
name: to_run [17410,17416]
===
match
---
simple_stmt [31383,31446]
simple_stmt [31378,31441]
===
match
---
simple_stmt [7413,7430]
simple_stmt [7413,7430]
===
match
---
trailer [26267,26299]
trailer [26262,26294]
===
match
---
trailer [9525,9529]
trailer [9525,9529]
===
match
---
name: tabulate_ti_keys_set [29965,29985]
name: tabulate_ti_keys_set [29960,29980]
===
match
---
operator: , [11970,11971]
operator: , [11965,11966]
===
match
---
trailer [33427,33437]
trailer [33422,33432]
===
match
---
name: err [30182,30185]
name: err [30177,30180]
===
match
---
name: task [18105,18109]
name: task [18100,18104]
===
match
---
atom_expr [12897,12944]
atom_expr [12892,12939]
===
match
---
operator: , [14341,14342]
operator: , [14336,14337]
===
match
---
name: ti [9533,9535]
name: ti [9533,9535]
===
match
---
operator: , [25043,25044]
operator: , [25038,25039]
===
match
---
trailer [13734,13748]
trailer [13729,13743]
===
match
---
trailer [28674,28692]
trailer [28669,28687]
===
match
---
argument [25028,25043]
argument [25023,25038]
===
match
---
operator: , [865,866]
operator: , [865,866]
===
match
---
name: self [25538,25542]
name: self [25533,25537]
===
match
---
trailer [13644,13658]
trailer [13639,13653]
===
match
---
trailer [29985,30003]
trailer [29980,29998]
===
match
---
name: ti [19353,19355]
name: ti [19348,19350]
===
match
---
expr_stmt [4741,4770]
expr_stmt [4741,4770]
===
match
---
name: ti_status [18862,18871]
name: ti_status [18857,18866]
===
match
---
trailer [21201,21308]
trailer [21196,21303]
===
match
---
name: self [22397,22401]
name: self [22392,22396]
===
match
---
name: self [35012,35016]
name: self [35007,35011]
===
match
---
name: to_run [16216,16222]
name: to_run [16211,16217]
===
match
---
name: self [33210,33214]
name: self [33205,33209]
===
match
---
suite [21309,22778]
suite [21304,22773]
===
match
---
argument [25531,25549]
argument [25526,25544]
===
match
---
simple_stmt [28038,28125]
simple_stmt [28033,28120]
===
match
---
simple_stmt [24222,24231]
simple_stmt [24217,24226]
===
match
---
name: self [16136,16140]
name: self [16131,16135]
===
match
---
name: len [35370,35373]
name: len [35365,35368]
===
match
---
trailer [37437,37459]
trailer [37432,37454]
===
match
---
name: self [4783,4787]
name: self [4783,4787]
===
match
---
atom_expr [10282,10501]
atom_expr [10277,10496]
===
match
---
suite [31566,31596]
suite [31561,31591]
===
match
---
name: session [25028,25035]
name: session [25023,25030]
===
match
---
name: max_active_tis_per_dag [25831,25853]
name: max_active_tis_per_dag [25826,25848]
===
match
---
trailer [7295,7324]
trailer [7295,7324]
===
match
---
name: state [32471,32476]
name: state [32466,32471]
===
match
---
operator: , [5228,5229]
operator: , [5228,5229]
===
match
---
operator: = [25646,25647]
operator: = [25641,25642]
===
match
---
param [12185,12208]
param [12180,12203]
===
match
---
atom_expr [30096,30113]
atom_expr [30091,30108]
===
match
---
operator: , [29162,29163]
operator: , [29157,29158]
===
match
---
trailer [15482,15491]
trailer [15477,15486]
===
match
---
name: self [33419,33423]
name: self [33414,33418]
===
match
---
operator: , [26817,26818]
operator: , [26812,26813]
===
match
---
atom_expr [38106,38140]
atom_expr [38101,38135]
===
match
---
simple_stmt [1556,1603]
simple_stmt [1556,1603]
===
match
---
atom_expr [22181,22611]
atom_expr [22176,22606]
===
match
---
argument [12090,12099]
argument [12085,12094]
===
match
---
atom_expr [9382,9438]
atom_expr [9382,9438]
===
match
---
operator: = [36414,36415]
operator: = [36409,36410]
===
match
---
operator: = [18103,18104]
operator: = [18098,18099]
===
match
---
trailer [21836,21840]
trailer [21831,21835]
===
match
---
name: Pool [24284,24288]
name: Pool [24279,24283]
===
match
---
trailer [13123,13130]
trailer [13118,13125]
===
match
---
atom_expr [16056,16076]
atom_expr [16051,16071]
===
match
---
name: to_run [23428,23434]
name: to_run [23423,23429]
===
match
---
simple_stmt [1368,1438]
simple_stmt [1368,1438]
===
match
---
suite [28190,28537]
suite [28185,28532]
===
match
---
name: to_run [26829,26835]
name: to_run [26824,26830]
===
match
---
name: self [23230,23234]
name: self [23225,23229]
===
match
---
name: ti_status [8713,8722]
name: ti_status [8713,8722]
===
match
---
simple_stmt [20767,21037]
simple_stmt [20762,21032]
===
match
---
name: append [31635,31641]
name: append [31630,31636]
===
match
---
name: _task_instances_for_dag_run [31477,31504]
name: _task_instances_for_dag_run [31472,31499]
===
match
---
name: key [22995,22998]
name: key [22990,22993]
===
match
---
name: execution_date [20629,20643]
name: execution_date [20624,20638]
===
match
---
name: self [31349,31353]
name: self [31344,31348]
===
match
---
operator: = [7227,7228]
operator: = [7227,7228]
===
match
---
trailer [26092,26101]
trailer [26087,26096]
===
match
---
trailer [11307,11309]
trailer [11302,11304]
===
match
---
string: "Not scheduling since Task concurrency limit is reached." [25958,26015]
string: "Not scheduling since Task concurrency limit is reached." [25953,26010]
===
match
---
atom_expr [35539,35573]
atom_expr [35534,35568]
===
match
---
operator: = [4373,4374]
operator: = [4373,4374]
===
match
---
name: tasks_to_run [14784,14796]
name: tasks_to_run [14779,14791]
===
match
---
operator: += [29910,29912]
operator: += [29905,29907]
===
match
---
trailer [18751,18755]
trailer [18746,18750]
===
match
---
name: headers [28070,28077]
name: headers [28065,28072]
===
match
---
name: ti [18095,18097]
name: ti [18090,18092]
===
match
---
operator: = [25035,25036]
operator: = [25030,25031]
===
match
---
name: TI [10875,10877]
name: TI [10870,10872]
===
match
---
name: executed_run_dates [17287,17305]
name: executed_run_dates [17282,17300]
===
match
---
name: timetable [12820,12829]
name: timetable [12815,12824]
===
match
---
operator: , [32104,32105]
operator: , [32099,32100]
===
match
---
operator: = [31470,31471]
operator: = [31465,31466]
===
match
---
name: task_id [24171,24178]
name: task_id [24166,24173]
===
match
---
name: deadlocked [29238,29248]
name: deadlocked [29233,29243]
===
match
---
name: warning [35979,35986]
name: warning [35974,35981]
===
match
---
param [10981,10988]
param [10976,10983]
===
match
---
string: "Task instance %s succeeded. Don't rerun." [8649,8691]
string: "Task instance %s succeeded. Don't rerun." [8649,8691]
===
match
---
atom_expr [4813,4818]
atom_expr [4813,4818]
===
match
---
name: state [19186,19191]
name: state [19181,19186]
===
match
---
expr_stmt [8093,8117]
expr_stmt [8093,8117]
===
match
---
trailer [20306,20313]
trailer [20301,20308]
===
match
---
name: dagrun [1347,1353]
name: dagrun [1347,1353]
===
match
---
name: finished [32490,32498]
name: finished [32485,32493]
===
match
---
name: skipped [18744,18751]
name: skipped [18739,18746]
===
match
---
operator: = [14241,14242]
operator: = [14236,14237]
===
match
---
string: "*** Clearing out not_ready list ***" [17521,17558]
string: "*** Clearing out not_ready list ***" [17516,17553]
===
match
---
name: dag_run [32392,32399]
name: dag_run [32387,32394]
===
match
---
simple_stmt [33174,33228]
simple_stmt [33169,33223]
===
match
---
suite [36435,38834]
suite [36430,38829]
===
match
---
name: t [29223,29224]
name: t [29218,29219]
===
match
---
name: remove [27456,27462]
name: remove [27451,27457]
===
match
---
argument [35277,35292]
argument [35272,35287]
===
match
---
argument [35472,35487]
argument [35467,35482]
===
match
---
trailer [21796,21798]
trailer [21791,21793]
===
match
---
expr_stmt [13306,13342]
expr_stmt [13301,13337]
===
match
---
name: airflow [1443,1450]
name: airflow [1443,1450]
===
match
---
name: ignore_first_depends_on_past [7327,7355]
name: ignore_first_depends_on_past [7327,7355]
===
match
---
simple_stmt [10734,10790]
simple_stmt [10729,10785]
===
match
---
name: self [7524,7528]
name: self [7524,7528]
===
match
---
name: super [7696,7701]
name: super [7696,7701]
===
match
---
operator: == [24314,24316]
operator: == [24309,24311]
===
match
---
atom_expr [25471,25755]
atom_expr [25466,25750]
===
match
---
argument [38647,38673]
argument [38642,38668]
===
match
---
expr_stmt [7250,7282]
expr_stmt [7250,7282]
===
match
---
import_from [888,946]
import_from [888,946]
===
match
---
operator: = [28961,28962]
operator: = [28956,28957]
===
match
---
trailer [28167,28181]
trailer [28162,28176]
===
match
---
argument [28880,28932]
argument [28875,28927]
===
match
---
name: UP_FOR_RESCHEDULE [23541,23558]
name: UP_FOR_RESCHEDULE [23536,23553]
===
match
---
atom_expr [8550,8563]
atom_expr [8550,8563]
===
match
---
string: "Task instance %s is up for reschedule" [9699,9738]
string: "Task instance %s is up for reschedule" [9699,9738]
===
match
---
name: self [16305,16309]
name: self [16300,16304]
===
match
---
dictorsetmaker [10875,10900]
dictorsetmaker [10870,10895]
===
match
---
name: TI [10816,10818]
name: TI [10811,10813]
===
match
---
name: subdags [31358,31365]
name: subdags [31353,31360]
===
match
---
atom_expr [18961,18987]
atom_expr [18956,18982]
===
match
---
operator: = [38633,38634]
operator: = [38628,38629]
===
match
---
name: self [4881,4885]
name: self [4881,4885]
===
match
---
operator: = [8113,8114]
operator: = [8113,8114]
===
match
---
operator: , [22301,22302]
operator: , [22296,22297]
===
match
---
name: airflow_conf [17335,17347]
name: airflow_conf [17330,17342]
===
match
---
name: ti_key [27976,27982]
name: ti_key [27971,27977]
===
match
---
expr_stmt [30182,30227]
expr_stmt [30177,30222]
===
match
---
name: num_running_task_instances_in_task [25788,25822]
name: num_running_task_instances_in_task [25783,25817]
===
match
---
name: resettable_states [37643,37660]
name: resettable_states [37638,37655]
===
match
---
expr_stmt [27856,28025]
expr_stmt [27851,28020]
===
match
---
name: resettable_states [37787,37804]
name: resettable_states [37782,37799]
===
match
---
atom_expr [33256,33326]
atom_expr [33251,33321]
===
match
---
name: ti_status [31792,31801]
name: ti_status [31787,31796]
===
match
---
name: skipped [8841,8848]
name: skipped [8841,8848]
===
match
---
name: running [20367,20374]
name: running [20362,20369]
===
match
---
trailer [18978,18982]
trailer [18973,18977]
===
match
---
expr_stmt [35424,35488]
expr_stmt [35419,35483]
===
match
---
atom_expr [38416,38424]
atom_expr [38411,38419]
===
match
---
name: commit [36244,36250]
name: commit [36239,36245]
===
match
---
trailer [38234,38293]
trailer [38229,38288]
===
match
---
arglist [26093,26100]
arglist [26088,26095]
===
match
---
name: to_run [4572,4578]
name: to_run [4572,4578]
===
match
---
name: active_runs [31623,31634]
name: active_runs [31618,31629]
===
match
---
name: pickle_id [34460,34469]
name: pickle_id [34455,34464]
===
match
---
suite [23989,26102]
suite [23984,26097]
===
match
---
trailer [9205,9209]
trailer [9205,9209]
===
match
---
atom_expr [4930,4957]
atom_expr [4930,4957]
===
match
---
string: "Task instance %s reschedule period not expired yet" [23595,23647]
string: "Task instance %s reschedule period not expired yet" [23590,23642]
===
match
---
name: dep_context [29094,29105]
name: dep_context [29089,29100]
===
match
---
operator: { [14733,14734]
operator: { [14728,14729]
===
match
---
simple_stmt [872,888]
simple_stmt [872,888]
===
match
---
atom_expr [9138,9171]
atom_expr [9138,9171]
===
match
---
simple_stmt [34399,34419]
simple_stmt [34394,34414]
===
match
---
operator: = [5318,5319]
operator: = [5318,5319]
===
match
---
trailer [26600,26610]
trailer [26595,26605]
===
match
---
atom_expr [15907,15931]
atom_expr [15902,15926]
===
match
---
operator: = [5488,5489]
operator: = [5488,5489]
===
match
---
expr_stmt [7413,7429]
expr_stmt [7413,7429]
===
match
---
atom_expr [28654,28692]
atom_expr [28649,28687]
===
match
---
strings [11786,11953]
strings [11781,11948]
===
match
---
trailer [24270,24276]
trailer [24265,24271]
===
match
---
name: filter [10820,10826]
name: filter [10815,10821]
===
match
---
operator: = [22283,22284]
operator: = [22278,22279]
===
match
---
trailer [32836,32854]
trailer [32831,32849]
===
match
---
name: len [17401,17404]
name: len [17396,17399]
===
match
---
atom_expr [8538,8546]
atom_expr [8538,8546]
===
match
---
name: headers [28482,28489]
name: headers [28477,28484]
===
match
---
trailer [35648,35852]
trailer [35643,35847]
===
match
---
operator: = [12895,12896]
operator: = [12890,12891]
===
match
---
testlist_comp [28371,28418]
testlist_comp [28366,28413]
===
match
---
name: remaining_dates [35594,35609]
name: remaining_dates [35589,35604]
===
match
---
name: pendulum [33121,33129]
name: pendulum [33116,33124]
===
match
---
trailer [21341,21350]
trailer [21336,21345]
===
match
---
name: conf [13912,13916]
name: conf [13907,13911]
===
match
---
name: self [28999,29003]
name: self [28994,28998]
===
match
---
trailer [21712,21729]
trailer [21707,21724]
===
match
---
atom_expr [21333,21354]
atom_expr [21328,21349]
===
match
---
trailer [26365,26375]
trailer [26360,26370]
===
match
---
operator: = [28998,28999]
operator: = [28993,28994]
===
match
---
simple_stmt [10565,10600]
simple_stmt [10560,10595]
===
match
---
if_stmt [20082,20462]
if_stmt [20077,20457]
===
match
---
name: NONE [10260,10264]
name: NONE [10255,10259]
===
match
---
atom_expr [27961,27974]
atom_expr [27956,27969]
===
match
---
name: any [28815,28818]
name: any [28810,28813]
===
match
---
comparison [8538,8563]
comparison [8538,8563]
===
match
---
atom_expr [35374,35406]
atom_expr [35369,35401]
===
match
---
trailer [22189,22209]
trailer [22184,22204]
===
match
---
name: to_run [18872,18878]
name: to_run [18867,18873]
===
match
---
trailer [26835,26842]
trailer [26830,26837]
===
match
---
trailer [33688,33715]
trailer [33683,33710]
===
match
---
name: ti [37848,37850]
name: ti [37843,37845]
===
match
---
name: airflow [1737,1744]
name: airflow [1737,1744]
===
match
---
arglist [8649,8695]
arglist [8649,8695]
===
match
---
trailer [11702,11708]
trailer [11697,11703]
===
match
---
name: not_ready [17582,17591]
name: not_ready [17577,17586]
===
match
---
name: executor [34561,34569]
name: executor [34556,34564]
===
match
---
suite [19770,19826]
suite [19765,19821]
===
match
---
name: executor [31825,31833]
name: executor [31820,31828]
===
match
---
simple_stmt [23120,23127]
simple_stmt [23115,23122]
===
match
---
name: LOCAL_EXECUTOR [21981,21995]
name: LOCAL_EXECUTOR [21976,21990]
===
match
---
name: err [29681,29684]
name: err [29676,29679]
===
match
---
operator: @ [7735,7736]
operator: @ [7735,7736]
===
match
---
name: end_date [7192,7200]
name: end_date [7192,7200]
===
match
---
operator: , [11679,11680]
operator: , [11674,11675]
===
match
---
name: ti_status [30206,30215]
name: ti_status [30201,30210]
===
match
---
trailer [38822,38833]
trailer [38817,38828]
===
match
---
name: ignore_depends_on_past [20888,20910]
name: ignore_depends_on_past [20883,20905]
===
match
---
if_stmt [23318,23398]
if_stmt [23313,23393]
===
match
---
name: deadlocked_depends_on_past [28786,28812]
name: deadlocked_depends_on_past [28781,28807]
===
match
---
trailer [18035,18044]
trailer [18030,18039]
===
match
---
trailer [8510,8514]
trailer [8510,8514]
===
match
---
param [4339,4351]
param [4339,4351]
===
match
---
name: format [33648,33654]
name: format [33643,33649]
===
match
---
name: ti_status [19752,19761]
name: ti_status [19747,19756]
===
match
---
simple_stmt [12780,12861]
simple_stmt [12775,12856]
===
match
---
atom_expr [18430,18492]
atom_expr [18425,18487]
===
match
---
atom_expr [13574,13593]
atom_expr [13569,13588]
===
match
---
atom_expr [23178,23186]
atom_expr [23173,23181]
===
match
---
atom_expr [15012,15037]
atom_expr [15007,15032]
===
match
---
trailer [5008,5022]
trailer [5008,5022]
===
match
---
trailer [33142,33146]
trailer [33137,33141]
===
match
---
operator: , [19957,19958]
operator: , [19952,19953]
===
match
---
simple_stmt [30382,31272]
simple_stmt [30377,31267]
===
match
---
decorator [12106,12123]
decorator [12101,12118]
===
match
---
trailer [13280,13288]
trailer [13275,13283]
===
match
---
dotted_name [1332,1353]
dotted_name [1332,1353]
===
match
---
name: msg [12096,12099]
name: msg [12091,12094]
===
match
---
operator: = [20887,20888]
operator: = [20882,20883]
===
match
---
name: ti_status [27696,27705]
name: ti_status [27691,27700]
===
match
---
atom_expr [38635,38674]
atom_expr [38630,38669]
===
match
---
param [7783,7793]
param [7783,7793]
===
match
---
trailer [19941,19975]
trailer [19936,19970]
===
match
---
simple_stmt [23418,23445]
simple_stmt [23413,23440]
===
match
---
name: ti_status [32813,32822]
name: ti_status [32808,32817]
===
match
---
arglist [35451,35487]
arglist [35446,35482]
===
match
---
operator: , [15893,15894]
operator: , [15888,15889]
===
match
---
name: _manage_executor_state [10952,10974]
name: _manage_executor_state [10947,10969]
===
match
---
name: task [25377,25381]
name: task [25372,25376]
===
match
---
name: ti [28394,28396]
name: ti [28389,28391]
===
match
---
comparison [37879,37903]
comparison [37874,37898]
===
match
---
comparison [15225,15247]
comparison [15220,15242]
===
match
---
trailer [8734,8747]
trailer [8734,8747]
===
match
---
name: running [9198,9205]
name: running [9198,9205]
===
match
---
name: tabulate_tis_set [30189,30205]
name: tabulate_tis_set [30184,30200]
===
match
---
name: key [18983,18986]
name: key [18978,18981]
===
match
---
operator: , [28087,28088]
operator: , [28082,28083]
===
match
---
name: UP_FOR_RESCHEDULE [9647,9664]
name: UP_FOR_RESCHEDULE [9647,9664]
===
match
---
name: pool [22523,22527]
name: pool [22518,22522]
===
match
---
trailer [22937,22944]
trailer [22932,22939]
===
match
---
atom [28370,28419]
atom [28365,28414]
===
match
---
name: log [8887,8890]
name: log [8887,8890]
===
match
---
name: session [14911,14918]
name: session [14906,14913]
===
match
---
argument [27926,28010]
argument [27921,28005]
===
match
---
expr_stmt [34106,34122]
expr_stmt [34101,34117]
===
match
---
string: """         Go through the dag_runs and update the state based on the task_instance state.         Then set DAG runs that are not finished to failed.          :param dag_runs: DAG runs         :param session: session         :return: None         """ [32129,32379]
string: """         Go through the dag_runs and update the state based on the task_instance state.         Then set DAG runs that are not finished to failed.          :param dag_runs: DAG runs         :param session: session         :return: None         """ [32124,32374]
===
match
---
expr_stmt [28647,28692]
expr_stmt [28642,28687]
===
match
---
name: typing [843,849]
name: typing [843,849]
===
match
---
name: _collect_errors [35435,35450]
name: _collect_errors [35430,35445]
===
match
---
name: ti [28316,28318]
name: ti [28311,28313]
===
match
---
trailer [19410,19444]
trailer [19405,19439]
===
match
---
atom_expr [12816,12837]
atom_expr [12811,12832]
===
match
---
number: 0 [4532,4533]
number: 0 [4532,4533]
===
match
---
name: donot_pickle [34144,34156]
name: donot_pickle [34139,34151]
===
match
---
argument [17964,17984]
argument [17959,17979]
===
match
---
name: reset_tis [38389,38398]
name: reset_tis [38384,38393]
===
match
---
expr_stmt [13369,13379]
expr_stmt [13364,13374]
===
match
---
name: skipped [4664,4671]
name: skipped [4664,4671]
===
match
---
name: BaseJob [1277,1284]
name: BaseJob [1277,1284]
===
match
---
name: failed [28685,28691]
name: failed [28680,28686]
===
match
---
expr_stmt [34358,34386]
expr_stmt [34353,34381]
===
match
---
arglist [11600,11639]
arglist [11595,11634]
===
match
---
trailer [33444,33446]
trailer [33439,33441]
===
match
---
operator: , [29145,29146]
operator: , [29140,29141]
===
match
---
name: queue_task_instance [22190,22209]
name: queue_task_instance [22185,22204]
===
match
---
string: '' [28552,28554]
string: '' [28547,28549]
===
match
---
import_name [790,801]
import_name [790,801]
===
match
---
if_stmt [15222,15316]
if_stmt [15217,15311]
===
match
---
name: timezone [33134,33142]
name: timezone [33129,33137]
===
match
---
name: str [27793,27796]
name: str [27788,27791]
===
match
---
operator: = [25537,25538]
operator: = [25532,25533]
===
match
---
operator: = [29154,29155]
operator: = [29149,29150]
===
match
---
trailer [18390,18400]
trailer [18385,18395]
===
match
---
atom_expr [29854,29893]
atom_expr [29849,29888]
===
match
---
trailer [36193,36205]
trailer [36188,36200]
===
match
---
operator: = [31521,31522]
operator: = [31516,31517]
===
match
---
trailer [35016,35033]
trailer [35011,35028]
===
match
---
atom_expr [26862,26916]
atom_expr [26857,26911]
===
match
---
comparison [17462,17492]
comparison [17457,17487]
===
match
---
simple_stmt [5051,5080]
simple_stmt [5051,5080]
===
match
---
atom_expr [4783,4797]
atom_expr [4783,4797]
===
match
---
simple_stmt [15382,15408]
simple_stmt [15377,15403]
===
match
---
name: DagConcurrencyLimitReached [1088,1114]
name: DagConcurrencyLimitReached [1088,1114]
===
match
---
simple_stmt [38062,38076]
simple_stmt [38057,38071]
===
match
---
operator: += [30072,30074]
operator: += [30067,30069]
===
match
---
name: add [18401,18404]
name: add [18396,18399]
===
match
---
operator: , [5461,5462]
operator: , [5461,5462]
===
match
---
name: dag_id [24927,24933]
name: dag_id [24922,24928]
===
match
---
atom_expr [31472,31530]
atom_expr [31467,31525]
===
match
---
atom_expr [11551,11571]
atom_expr [11546,11566]
===
match
---
if_stmt [28701,30228]
if_stmt [28696,30223]
===
match
---
arglist [20175,20221]
arglist [20170,20216]
===
match
---
atom [21932,22090]
atom [21927,22085]
===
match
---
for_stmt [11259,12101]
for_stmt [11254,12096]
===
match
---
name: add [18752,18755]
name: add [18747,18750]
===
match
---
atom_expr [4741,4752]
atom_expr [4741,4752]
===
match
---
name: self [18430,18434]
name: self [18425,18429]
===
match
---
name: to_run [26668,26674]
name: to_run [26663,26669]
===
match
---
operator: == [9638,9640]
operator: == [9638,9640]
===
match
---
operator: = [35460,35461]
operator: = [35455,35456]
===
match
---
trailer [26236,26239]
trailer [26231,26234]
===
match
---
name: ti_status [35113,35122]
name: ti_status [35108,35117]
===
match
---
expr_stmt [33371,33468]
expr_stmt [33366,33463]
===
match
---
param [36397,36420]
param [36392,36415]
===
match
---
expr_stmt [12780,12860]
expr_stmt [12775,12855]
===
match
---
operator: , [9433,9434]
operator: , [9433,9434]
===
match
---
atom_expr [16016,16038]
atom_expr [16011,16033]
===
match
---
name: State [13275,13280]
name: State [13270,13275]
===
match
---
name: err [30244,30247]
name: err [30239,30242]
===
match
---
trailer [38263,38269]
trailer [38258,38264]
===
match
---
name: sorted [28262,28268]
name: sorted [28257,28263]
===
match
---
simple_stmt [802,838]
simple_stmt [802,838]
===
match
---
operator: , [4325,4326]
operator: , [4325,4326]
===
match
---
suite [11319,12101]
suite [11314,12096]
===
match
---
name: len [15872,15875]
name: len [15867,15870]
===
match
---
suite [8287,8363]
suite [8287,8363]
===
match
---
operator: = [28550,28551]
operator: = [28545,28546]
===
match
---
operator: , [22537,22538]
operator: , [22532,22533]
===
match
---
name: pickle [34472,34478]
name: pickle [34467,34473]
===
match
---
name: DAG [12180,12183]
name: DAG [12175,12178]
===
match
---
name: verbose [5366,5373]
name: verbose [5366,5373]
===
match
---
name: KeyboardInterrupt [35926,35943]
name: KeyboardInterrupt [35921,35938]
===
match
---
name: query [38191,38196]
name: query [38186,38191]
===
match
---
name: set [26654,26657]
name: set [26649,26652]
===
match
---
operator: , [26141,26142]
operator: , [26136,26137]
===
match
---
atom_expr [25893,26049]
atom_expr [25888,26044]
===
match
---
name: dagrun_infos [33818,33830]
name: dagrun_infos [33813,33825]
===
match
---
atom_expr [19655,19717]
atom_expr [19650,19712]
===
match
---
name: exceptions [1018,1028]
name: exceptions [1018,1028]
===
match
---
trailer [7117,7124]
trailer [7117,7124]
===
match
---
trailer [23747,23752]
trailer [23742,23747]
===
match
---
trailer [26375,26377]
trailer [26370,26372]
===
match
---
trailer [12690,12703]
trailer [12685,12698]
===
match
---
atom_expr [9076,9121]
atom_expr [9076,9121]
===
match
---
name: end [36274,36277]
name: end [36269,36272]
===
match
---
name: session [29147,29154]
name: session [29142,29149]
===
match
---
param [16305,16310]
param [16300,16305]
===
match
---
name: ignore_depends_on_past [20597,20619]
name: ignore_depends_on_past [20592,20614]
===
match
---
trailer [19931,19941]
trailer [19926,19936]
===
match
---
trailer [16094,16115]
trailer [16089,16110]
===
match
---
simple_stmt [34358,34387]
simple_stmt [34353,34382]
===
match
---
and_test [26591,26723]
and_test [26586,26718]
===
match
---
trailer [19612,19628]
trailer [19607,19623]
===
match
---
atom_expr [4723,4728]
atom_expr [4723,4728]
===
match
---
trailer [18400,18404]
trailer [18395,18399]
===
match
---
atom [26573,26737]
atom [26568,26732]
===
match
---
suite [15462,15512]
suite [15457,15507]
===
match
---
name: helpers [1629,1636]
name: helpers [1629,1636]
===
match
---
trailer [33129,33133]
trailer [33124,33128]
===
match
---
name: running [18928,18935]
name: running [18923,18930]
===
match
---
name: key [37911,37914]
name: key [37906,37909]
===
match
---
name: session [27707,27714]
name: session [27702,27709]
===
match
---
arglist [27897,28011]
arglist [27892,28006]
===
match
---
name: session [36421,36428]
name: session [36416,36423]
===
match
---
suite [10721,10943]
suite [10716,10938]
===
match
---
operator: == [15234,15236]
operator: == [15229,15231]
===
match
---
suite [34671,35910]
suite [34666,35905]
===
match
---
name: log [12027,12030]
name: log [12022,12025]
===
match
---
operator: = [4898,4899]
operator: = [4898,4899]
===
match
---
atom_expr [27992,28009]
atom_expr [27987,28004]
===
match
---
operator: , [19426,19427]
operator: , [19421,19422]
===
match
---
simple_stmt [15475,15494]
simple_stmt [15470,15489]
===
match
---
trailer [14135,14141]
trailer [14130,14136]
===
match
---
atom [28293,28342]
atom [28288,28337]
===
match
---
trailer [20168,20174]
trailer [20163,20169]
===
match
---
trailer [19663,19669]
trailer [19658,19664]
===
match
---
expr_stmt [24830,25070]
expr_stmt [24825,25065]
===
match
---
name: filter_for_tis [8200,8214]
name: filter_for_tis [8200,8214]
===
match
---
name: self [7077,7081]
name: self [7077,7081]
===
match
---
trailer [23735,23743]
trailer [23730,23738]
===
match
---
operator: = [37269,37270]
operator: = [37264,37265]
===
match
---
trailer [23388,23392]
trailer [23383,23387]
===
match
---
trailer [15885,15892]
trailer [15880,15887]
===
match
---
name: self [25136,25140]
name: self [25131,25135]
===
match
---
tfpdef [28155,28181]
tfpdef [28150,28176]
===
match
---
param [32096,32105]
param [32091,32100]
===
match
---
operator: += [29962,29964]
operator: += [29957,29959]
===
match
---
name: session [38454,38461]
name: session [38449,38456]
===
match
---
operator: , [25675,25676]
operator: , [25670,25671]
===
match
---
simple_stmt [5004,5039]
simple_stmt [5004,5039]
===
match
---
trailer [38345,38349]
trailer [38340,38344]
===
match
---
atom_expr [16095,16114]
atom_expr [16090,16109]
===
match
---
trailer [24492,24503]
trailer [24487,24498]
===
match
---
simple_stmt [18734,18761]
simple_stmt [18729,18756]
===
match
---
name: state [11332,11337]
name: state [11327,11332]
===
match
---
name: total_runs [4521,4531]
name: total_runs [4521,4531]
===
match
---
name: running [4623,4630]
name: running [4623,4630]
===
match
---
atom_expr [24182,24192]
atom_expr [24177,24187]
===
match
---
arglist [13672,14000]
arglist [13667,13995]
===
match
---
name: succeeded [4311,4320]
name: succeeded [4311,4320]
===
match
---
trailer [22983,22990]
trailer [22978,22985]
===
match
---
name: self [37153,37157]
name: self [37148,37152]
===
match
---
name: ti [10633,10635]
name: ti [10628,10630]
===
match
---
simple_stmt [15521,15541]
simple_stmt [15516,15536]
===
match
---
simple_stmt [9455,9490]
simple_stmt [9455,9490]
===
match
---
operator: , [13999,14000]
operator: , [13994,13995]
===
match
---
expr_stmt [4783,4818]
expr_stmt [4783,4818]
===
match
---
trailer [31341,31345]
trailer [31336,31340]
===
match
---
expr_stmt [24475,24520]
expr_stmt [24470,24515]
===
match
---
trailer [37526,37534]
trailer [37521,37529]
===
match
---
simple_stmt [9010,9019]
simple_stmt [9010,9019]
===
match
---
factor [33798,33800]
factor [33793,33795]
===
match
---
atom [4634,4636]
atom [4634,4636]
===
match
---
name: ti_status [22636,22645]
name: ti_status [22631,22640]
===
match
---
name: self [32879,32883]
name: self [32874,32878]
===
match
---
name: pop [20314,20317]
name: pop [20309,20312]
===
match
---
trailer [17358,17384]
trailer [17353,17379]
===
match
---
name: dag_run [32463,32470]
name: dag_run [32458,32465]
===
match
---
trailer [27299,27316]
trailer [27294,27311]
===
match
---
name: running [9465,9472]
name: running [9465,9472]
===
match
---
decorated [16238,27644]
decorated [16233,27639]
===
match
---
number: 0 [17491,17492]
number: 0 [17486,17487]
===
match
---
operator: = [24261,24262]
operator: = [24256,24257]
===
match
---
atom_expr [20213,20221]
atom_expr [20208,20216]
===
match
---
operator: , [17365,17366]
operator: , [17360,17361]
===
match
---
atom_expr [33400,33409]
atom_expr [33395,33404]
===
match
---
name: TI [8153,8155]
name: TI [8153,8155]
===
match
---
name: timetables [1569,1579]
name: timetables [1569,1579]
===
match
---
argument [27300,27315]
argument [27295,27310]
===
match
---
simple_stmt [17506,17560]
simple_stmt [17501,17555]
===
match
---
import_name [872,887]
import_name [872,887]
===
match
---
atom_expr [9334,9342]
atom_expr [9334,9342]
===
match
---
trailer [23952,23962]
trailer [23947,23957]
===
match
---
simple_stmt [1194,1243]
simple_stmt [1194,1243]
===
match
---
argument [20818,20843]
argument [20813,20838]
===
match
---
dotted_name [1248,1269]
dotted_name [1248,1269]
===
match
---
atom_expr [7696,7729]
atom_expr [7696,7729]
===
match
---
operator: , [35091,35092]
operator: , [35086,35087]
===
match
---
name: succeeded [8591,8600]
name: succeeded [8591,8600]
===
match
---
operator: + [31347,31348]
operator: + [31342,31343]
===
match
---
atom_expr [29172,29184]
atom_expr [29167,29179]
===
match
---
name: DAG [1312,1315]
name: DAG [1312,1315]
===
match
---
name: NONE [38433,38437]
name: NONE [38428,38432]
===
match
---
funcdef [15546,16233]
funcdef [15541,16228]
===
match
---
expr_stmt [20537,20576]
expr_stmt [20532,20571]
===
match
---
operator: , [35470,35471]
operator: , [35465,35466]
===
match
---
atom_expr [28164,28181]
atom_expr [28159,28176]
===
match
---
name: make_transient [932,946]
name: make_transient [932,946]
===
match
---
argument [28482,28535]
argument [28477,28530]
===
match
---
decorator [32030,32047]
decorator [32025,32042]
===
match
---
atom_expr [23683,23700]
atom_expr [23678,23695]
===
match
---
name: key [22949,22952]
name: key [22944,22947]
===
match
---
trailer [24441,24446]
trailer [24436,24441]
===
match
---
import_from [1782,1819]
import_from [1782,1819]
===
match
---
operator: = [13119,13120]
operator: = [13114,13115]
===
match
---
atom_expr [15237,15247]
atom_expr [15232,15242]
===
match
---
trailer [27229,27232]
trailer [27224,27227]
===
match
---
trailer [17520,17559]
trailer [17515,17554]
===
match
---
atom_expr [24166,24178]
atom_expr [24161,24173]
===
match
---
trailer [18135,18141]
trailer [18130,18136]
===
match
---
name: dagrun [20622,20628]
name: dagrun [20617,20623]
===
match
---
argument [35055,35091]
argument [35050,35086]
===
match
---
operator: = [31391,31392]
operator: = [31386,31387]
===
match
---
operator: = [33119,33120]
operator: = [33114,33115]
===
match
---
simple_stmt [17320,17385]
simple_stmt [17315,17380]
===
match
---
operator: = [5067,5068]
operator: = [5067,5068]
===
match
---
name: ti [21662,21664]
name: ti [21657,21659]
===
match
---
trailer [8600,8604]
trailer [8600,8604]
===
match
---
atom_expr [4693,4707]
atom_expr [4693,4707]
===
match
---
name: NONE [19201,19205]
name: NONE [19196,19200]
===
match
---
operator: @ [14275,14276]
operator: @ [14270,14271]
===
match
---
atom_expr [31741,31950]
atom_expr [31736,31945]
===
match
---
trailer [24043,24070]
trailer [24038,24065]
===
match
---
simple_stmt [23465,23472]
simple_stmt [23460,23467]
===
match
---
name: tis_to_be_scheduled [10701,10720]
name: tis_to_be_scheduled [10696,10715]
===
match
---
string: "Try number" [28110,28122]
string: "Try number" [28105,28117]
===
match
---
name: run_at_least_once [7670,7687]
name: run_at_least_once [7670,7687]
===
match
---
expr_stmt [30016,30055]
expr_stmt [30011,30050]
===
match
---
name: session [31429,31436]
name: session [31424,31431]
===
match
---
name: ti_status [7783,7792]
name: ti_status [7783,7792]
===
match
---
operator: != [24179,24181]
operator: != [24174,24176]
===
match
---
name: deadlocked [17476,17486]
name: deadlocked [17471,17481]
===
match
---
suite [17493,27577]
suite [17488,27572]
===
match
---
param [30326,30335]
param [30321,30330]
===
match
---
if_stmt [28563,28693]
if_stmt [28558,28688]
===
match
---
simple_stmt [26253,26300]
simple_stmt [26248,26295]
===
match
---
atom_expr [26591,26610]
atom_expr [26586,26605]
===
match
---
arglist [23897,23925]
arglist [23892,23920]
===
match
---
atom_expr [15335,15343]
atom_expr [15330,15338]
===
match
---
name: info [35644,35648]
name: info [35639,35643]
===
match
---
simple_stmt [26862,26917]
simple_stmt [26857,26912]
===
match
---
simple_stmt [7438,7485]
simple_stmt [7438,7485]
===
match
---
atom_expr [28305,28314]
atom_expr [28300,28309]
===
match
---
string: "max_active_runs limit for dag %s has been reached " [35674,35726]
string: "max_active_runs limit for dag %s has been reached " [35669,35721]
===
match
---
trailer [8730,8734]
trailer [8730,8734]
===
match
---
name: self [18781,18785]
name: self [18776,18780]
===
match
---
name: failed [9148,9154]
name: failed [9148,9154]
===
match
---
name: now [33130,33133]
name: now [33125,33128]
===
match
---
name: ti [9334,9336]
name: ti [9334,9336]
===
match
---
atom_expr [24764,24773]
atom_expr [24759,24768]
===
match
---
tfpdef [12150,12173]
tfpdef [12145,12168]
===
match
---
operator: = [13146,13147]
operator: = [13141,13142]
===
match
---
operator: = [4320,4321]
operator: = [4320,4321]
===
match
---
name: debug [23239,23244]
name: debug [23234,23239]
===
match
---
expr_stmt [34460,34481]
expr_stmt [34455,34476]
===
match
---
name: items [38012,38017]
name: items [38007,38012]
===
match
---
name: ti [10242,10244]
name: ti [10237,10239]
===
match
---
string: """         Process a set of task instances from a set of dag runs. Special handling is done         to account for different task instance states that could be present when running         them in a backfill process.          :param ti_status: the internal status of the job         :type ti_status: BackfillJob._DagRunTaskStatus         :param executor: the executor to run the task instances         :type executor: BaseExecutor         :param pickle_id: the pickle_id if dag is pickled, None otherwise         :type pickle_id: int         :param start_date: the start date of the backfill job         :type start_date: datetime.datetime         :param session: the current session object         :type session: sqlalchemy.orm.session.Session         :return: the list of execution_dates for the finished dag runs         :rtype: list         """ [16429,17278]
string: """         Process a set of task instances from a set of dag runs. Special handling is done         to account for different task instance states that could be present when running         them in a backfill process.          :param ti_status: the internal status of the job         :type ti_status: BackfillJob._DagRunTaskStatus         :param executor: the executor to run the task instances         :type executor: BaseExecutor         :param pickle_id: the pickle_id if dag is pickled, None otherwise         :type pickle_id: int         :param start_date: the start date of the backfill job         :type start_date: datetime.datetime         :param session: the current session object         :type session: sqlalchemy.orm.session.Session         :return: the list of execution_dates for the finished dag runs         :rtype: list         """ [16424,17273]
===
match
---
trailer [38690,38696]
trailer [38685,38691]
===
match
---
name: self [22528,22532]
name: self [22523,22527]
===
match
---
trailer [29051,29072]
trailer [29046,29067]
===
match
---
simple_stmt [9811,9841]
simple_stmt [9806,9836]
===
match
---
atom_expr [35430,35488]
atom_expr [35425,35483]
===
match
---
name: refresh_from_db [15020,15035]
name: refresh_from_db [15015,15030]
===
match
---
name: is_unit_test [17320,17332]
name: is_unit_test [17315,17327]
===
match
---
trailer [18970,18978]
trailer [18965,18973]
===
match
---
comparison [24297,24326]
comparison [24292,24321]
===
match
---
operator: { [4634,4635]
operator: { [4634,4635]
===
match
---
simple_stmt [27006,27053]
simple_stmt [27001,27048]
===
match
---
name: self [15564,15568]
name: self [15559,15563]
===
match
---
name: values [26907,26913]
name: values [26902,26908]
===
match
---
name: self [14328,14332]
name: self [14323,14327]
===
match
---
name: pop [9778,9781]
name: pop [9778,9781]
===
match
---
operator: = [29171,29172]
operator: = [29166,29167]
===
match
---
name: ti [28305,28307]
name: ti [28300,28302]
===
match
---
expr_stmt [4881,4917]
expr_stmt [4881,4917]
===
match
---
atom_expr [33065,33081]
atom_expr [33060,33076]
===
match
---
trailer [20256,20263]
trailer [20251,20258]
===
match
---
simple_stmt [2293,4110]
simple_stmt [2293,4110]
===
match
---
operator: , [22241,22242]
operator: , [22236,22237]
===
match
---
operator: = [21779,21780]
operator: = [21774,21775]
===
match
---
trailer [37450,37458]
trailer [37445,37453]
===
match
---
atom_expr [26658,26674]
atom_expr [26653,26669]
===
match
---
operator: , [13695,13696]
operator: , [13690,13691]
===
match
---
name: run_backwards [33344,33357]
name: run_backwards [33339,33352]
===
match
---
name: ti_status [27034,27043]
name: ti_status [27029,27038]
===
match
---
trailer [37432,37437]
trailer [37427,37432]
===
match
---
trailer [38696,38698]
trailer [38691,38693]
===
match
---
comparison [18562,18586]
comparison [18557,18581]
===
match
---
name: ti [10545,10547]
name: ti [10540,10542]
===
match
---
name: state [11975,11980]
name: state [11970,11975]
===
match
---
number: 0 [34759,34760]
number: 0 [34754,34755]
===
match
---
dotted_name [1825,1844]
dotted_name [1825,1844]
===
match
---
name: DagRunType [1852,1862]
name: DagRunType [1852,1862]
===
match
---
name: tabulate_ti_keys_set [30075,30095]
name: tabulate_ti_keys_set [30070,30090]
===
match
---
exprlist [24096,24103]
exprlist [24091,24098]
===
match
---
trailer [19243,19377]
trailer [19238,19372]
===
match
---
tfpdef [12175,12183]
tfpdef [12170,12178]
===
match
---
expr_stmt [33768,33801]
expr_stmt [33763,33796]
===
match
---
operator: = [37813,37814]
operator: = [37808,37809]
===
match
---
trailer [27043,27051]
trailer [27038,27046]
===
match
---
name: logical_date [34925,34937]
name: logical_date [34920,34932]
===
match
---
atom_expr [38683,38698]
atom_expr [38678,38693]
===
match
---
operator: , [13888,13889]
operator: , [13883,13884]
===
match
---
simple_stmt [12058,12101]
simple_stmt [12053,12096]
===
match
---
simple_stmt [20160,20223]
simple_stmt [20155,20218]
===
match
---
name: ti_status [8831,8840]
name: ti_status [8831,8840]
===
match
---
trailer [36183,36206]
trailer [36178,36201]
===
match
---
expr_stmt [7438,7484]
expr_stmt [7438,7484]
===
match
---
argument [18057,18077]
argument [18052,18072]
===
match
---
simple_stmt [22688,22714]
simple_stmt [22683,22709]
===
match
---
string: "," [33680,33683]
string: "," [33675,33678]
===
match
---
name: set [4986,4989]
name: set [4986,4989]
===
match
---
name: key [8511,8514]
name: key [8511,8514]
===
match
---
suite [9665,9841]
suite [9665,9836]
===
match
---
simple_stmt [38153,38366]
simple_stmt [38148,38361]
===
match
---
name: ti_status [18513,18522]
name: ti_status [18508,18517]
===
match
---
atom_expr [26933,26957]
atom_expr [26928,26952]
===
match
---
operator: , [12173,12174]
operator: , [12168,12169]
===
match
---
atom_expr [11712,11740]
atom_expr [11707,11735]
===
match
---
trailer [18785,18789]
trailer [18780,18784]
===
match
---
operator: , [31427,31428]
operator: , [31422,31423]
===
match
---
trailer [27513,27533]
trailer [27508,27528]
===
match
---
suite [35614,35910]
suite [35609,35905]
===
match
---
atom_expr [28405,28418]
atom_expr [28400,28413]
===
match
---
simple_stmt [38812,38834]
simple_stmt [38807,38829]
===
match
---
operator: , [36419,36420]
operator: , [36414,36415]
===
match
---
name: State [11667,11672]
name: State [11662,11667]
===
match
---
operator: , [1636,1637]
operator: , [1636,1637]
===
match
---
name: verbose [29004,29011]
name: verbose [28999,29006]
===
match
---
operator: , [19351,19352]
operator: , [19346,19347]
===
match
---
argument [10867,10901]
argument [10862,10896]
===
match
---
operator: , [13859,13860]
operator: , [13854,13855]
===
match
---
trailer [18755,18760]
trailer [18750,18755]
===
match
---
parameters [38003,38018]
parameters [37998,38013]
===
match
---
trailer [21384,21388]
trailer [21379,21383]
===
match
---
name: ti_key [27946,27952]
name: ti_key [27941,27947]
===
match
---
name: task [24437,24441]
name: task [24432,24436]
===
match
---
atom [31702,31704]
atom [31697,31699]
===
match
---
atom_expr [17945,18002]
atom_expr [17940,17997]
===
match
---
name: running [8969,8976]
name: running [8969,8976]
===
match
---
atom_expr [23418,23439]
atom_expr [23413,23434]
===
match
---
name: execution_date [27518,27532]
name: execution_date [27513,27527]
===
match
---
trailer [8214,8248]
trailer [8214,8248]
===
match
---
atom_expr [22636,22658]
atom_expr [22631,22653]
===
match
---
name: try_number [27999,28009]
name: try_number [27994,28004]
===
match
---
suite [16420,27644]
suite [16415,27639]
===
match
---
trailer [15434,15436]
trailer [15429,15431]
===
match
---
atom_expr [32425,32447]
atom_expr [32420,32442]
===
match
---
comparison [26696,26723]
comparison [26691,26718]
===
match
---
trailer [36250,36252]
trailer [36245,36247]
===
match
---
operator: = [14901,14902]
operator: = [14896,14897]
===
match
---
simple_stmt [4608,4637]
simple_stmt [4608,4637]
===
match
---
name: ti_status [16056,16065]
name: ti_status [16051,16060]
===
match
---
name: ignore_depends_on_past [20719,20741]
name: ignore_depends_on_past [20714,20736]
===
match
---
name: dag [14069,14072]
name: dag [14064,14067]
===
match
---
parameters [27754,27789]
parameters [27749,27784]
===
match
---
atom_expr [37153,37174]
atom_expr [37148,37169]
===
match
---
trailer [4653,4661]
trailer [4653,4661]
===
match
---
operator: = [8314,8315]
operator: = [8314,8315]
===
match
---
string: "Task ID" [28501,28510]
string: "Task ID" [28496,28505]
===
match
---
atom_expr [35635,35852]
atom_expr [35630,35847]
===
match
---
operator: >= [25133,25135]
operator: >= [25128,25130]
===
match
---
if_stmt [23520,23827]
if_stmt [23515,23822]
===
match
---
name: ti_status [27208,27217]
name: ti_status [27203,27212]
===
match
---
trailer [7137,7151]
trailer [7137,7151]
===
match
---
trailer [4593,4595]
trailer [4593,4595]
===
match
---
testlist_comp [34202,34334]
testlist_comp [34197,34329]
===
match
---
simple_stmt [22928,22954]
simple_stmt [22923,22949]
===
match
---
atom_expr [12022,12041]
atom_expr [12017,12036]
===
match
---
name: dag [5121,5124]
name: dag [5121,5124]
===
match
---
name: add [22945,22948]
name: add [22940,22943]
===
match
---
atom_expr [18182,18190]
atom_expr [18177,18185]
===
match
---
simple_stmt [8959,8994]
simple_stmt [8959,8994]
===
match
---
name: ti [11551,11553]
name: ti [11546,11548]
===
match
---
simple_stmt [36444,37001]
simple_stmt [36439,36996]
===
match
---
trailer [31676,31683]
trailer [31671,31678]
===
match
---
atom [2162,2191]
atom [2162,2191]
===
match
---
simple_stmt [15012,15038]
simple_stmt [15007,15033]
===
match
---
operator: , [5200,5201]
operator: , [5200,5201]
===
match
---
operator: , [11963,11964]
operator: , [11958,11959]
===
match
---
name: ti [17945,17947]
name: ti [17940,17942]
===
match
---
name: filter_for_tis [8341,8355]
name: filter_for_tis [8341,8355]
===
match
---
atom_expr [27434,27467]
atom_expr [27429,27462]
===
match
---
operator: = [33190,33191]
operator: = [33185,33186]
===
match
---
name: taskinstance [1388,1400]
name: taskinstance [1388,1400]
===
match
---
arglist [18445,18491]
arglist [18440,18486]
===
match
---
simple_stmt [22974,23000]
simple_stmt [22969,22995]
===
match
---
operator: = [34700,34701]
operator: = [34695,34696]
===
match
---
name: self [24018,24022]
name: self [24013,24017]
===
match
---
name: deadlocked [30216,30226]
name: deadlocked [30211,30221]
===
match
---
operator: = [13099,13100]
operator: = [13094,13095]
===
match
---
atom_expr [20247,20272]
atom_expr [20242,20267]
===
match
---
name: dag [25141,25144]
name: dag [25136,25139]
===
match
---
trailer [8852,8865]
trailer [8852,8865]
===
match
---
name: FAILED [11673,11679]
name: FAILED [11668,11674]
===
match
---
trailer [18044,18078]
trailer [18039,18073]
===
match
---
atom_expr [7438,7462]
atom_expr [7438,7462]
===
match
---
name: filter_by_dag_run [36397,36414]
name: filter_by_dag_run [36392,36409]
===
match
---
operator: , [37598,37599]
operator: , [37593,37594]
===
match
---
name: airflow [1561,1568]
name: airflow [1561,1568]
===
match
---
name: processed_dag_run_dates [32000,32023]
name: processed_dag_run_dates [31995,32018]
===
match
---
name: pickle_id [30336,30345]
name: pickle_id [30331,30340]
===
match
---
trailer [8329,8333]
trailer [8329,8333]
===
match
---
atom [28490,28535]
atom [28485,28530]
===
match
---
trailer [29874,29893]
trailer [29869,29888]
===
match
---
name: debug [23891,23896]
name: debug [23886,23891]
===
match
---
trailer [7104,7111]
trailer [7104,7111]
===
match
---
trailer [25597,25605]
trailer [25592,25600]
===
match
---
atom_expr [29741,29782]
atom_expr [29736,29777]
===
match
---
trailer [24768,24773]
trailer [24763,24768]
===
match
---
name: TaskInstance [37620,37632]
name: TaskInstance [37615,37627]
===
match
---
name: DagPickle [34367,34376]
name: DagPickle [34362,34371]
===
match
---
name: finished_runs [5009,5022]
name: finished_runs [5009,5022]
===
match
---
operator: , [5432,5433]
operator: , [5432,5433]
===
match
---
name: total_runs [34597,34607]
name: total_runs [34592,34602]
===
match
---
operator: , [30345,30346]
operator: , [30340,30341]
===
match
---
operator: , [15297,15298]
operator: , [15292,15293]
===
match
---
name: _set_unfinished_dag_runs_to_failed [36149,36183]
name: _set_unfinished_dag_runs_to_failed [36144,36178]
===
match
---
trailer [27565,27576]
trailer [27560,27571]
===
match
---
name: dagrun_end_date [34060,34075]
name: dagrun_end_date [34055,34070]
===
match
---
name: ti_status [36184,36193]
name: ti_status [36179,36188]
===
match
---
name: to_run [26943,26949]
name: to_run [26938,26944]
===
match
---
trailer [12829,12837]
trailer [12824,12832]
===
match
---
operator: , [29011,29012]
operator: , [29006,29007]
===
match
---
comp_op [34938,34944]
comp_op [34933,34939]
===
match
---
operator: , [5509,5510]
operator: , [5509,5510]
===
match
---
argument [20932,20970]
argument [20927,20965]
===
match
---
atom_expr [36289,36329]
atom_expr [36284,36324]
===
match
---
trailer [9522,9530]
trailer [9522,9530]
===
match
---
name: start_date [31900,31910]
name: start_date [31895,31905]
===
match
---
param [16356,16366]
param [16351,16361]
===
match
---
name: failed [15995,16001]
name: failed [15990,15996]
===
match
---
trailer [36302,36329]
trailer [36297,36324]
===
match
---
atom_expr [9188,9222]
atom_expr [9188,9222]
===
match
---
name: session [13165,13172]
name: session [13160,13167]
===
match
---
atom_expr [26075,26101]
atom_expr [26070,26096]
===
match
---
atom_expr [37438,37458]
atom_expr [37433,37453]
===
match
---
name: list [8215,8219]
name: list [8215,8219]
===
match
---
name: pop [18630,18633]
name: pop [18625,18628]
===
match
---
name: add [20264,20267]
name: add [20259,20262]
===
match
---
atom_expr [26253,26299]
atom_expr [26248,26294]
===
match
---
name: tabulate_ti_keys_set [27734,27754]
name: tabulate_ti_keys_set [27729,27749]
===
match
---
name: ti [18045,18047]
name: ti [18040,18042]
===
match
---
atom_expr [20482,20515]
atom_expr [20477,20510]
===
match
---
simple_stmt [13369,13380]
simple_stmt [13364,13375]
===
match
---
suite [33510,33756]
suite [33505,33751]
===
match
---
import_from [802,837]
import_from [802,837]
===
match
---
name: ti [37855,37857]
name: ti [37850,37852]
===
match
---
trailer [38772,38783]
trailer [38767,38778]
===
match
---
simple_stmt [14132,14158]
simple_stmt [14127,14153]
===
match
---
return_stmt [28454,28536]
return_stmt [28449,28531]
===
match
---
name: external_trigger [12921,12937]
name: external_trigger [12916,12932]
===
match
---
atom_expr [8800,8813]
atom_expr [8800,8813]
===
match
---
trailer [18184,18190]
trailer [18179,18185]
===
match
---
name: bf_end_date [33215,33226]
name: bf_end_date [33210,33221]
===
match
---
atom_expr [13810,13823]
atom_expr [13805,13818]
===
match
---
atom_expr [4608,4620]
atom_expr [4608,4620]
===
match
---
trailer [18351,18359]
trailer [18346,18354]
===
match
---
name: time [797,801]
name: time [797,801]
===
match
---
argument [7713,7718]
argument [7713,7718]
===
match
---
name: ti_key [27937,27943]
name: ti_key [27932,27938]
===
match
---
for_stmt [24006,26102]
for_stmt [24001,26097]
===
match
---
trailer [9351,9364]
trailer [9351,9364]
===
match
---
simple_stmt [10518,10549]
simple_stmt [10513,10544]
===
match
---
operator: , [35561,35562]
operator: , [35556,35557]
===
match
---
name: synchronize_session [10903,10922]
name: synchronize_session [10898,10917]
===
match
---
atom_expr [33680,33715]
atom_expr [33675,33710]
===
match
---
operator: == [18696,18698]
operator: == [18691,18693]
===
match
---
name: sorted_tis [28249,28259]
name: sorted_tis [28244,28254]
===
match
---
trailer [9084,9090]
trailer [9084,9090]
===
match
---
atom_expr [7549,7572]
atom_expr [7549,7572]
===
match
---
name: ti_status [23030,23039]
name: ti_status [23025,23034]
===
match
---
operator: , [27959,27960]
operator: , [27954,27955]
===
match
---
atom_expr [9760,9794]
atom_expr [9760,9789]
===
match
---
name: mark_success [22271,22283]
name: mark_success [22266,22278]
===
match
---
name: queued_dttm [21767,21778]
name: queued_dttm [21762,21773]
===
match
---
atom [34188,34344]
atom [34183,34339]
===
match
---
name: succeeded [4710,4719]
name: succeeded [4710,4719]
===
match
---
atom_expr [12679,12703]
atom_expr [12674,12698]
===
match
---
operator: , [15967,15968]
operator: , [15962,15963]
===
match
---
trailer [9646,9664]
trailer [9646,9664]
===
match
---
trailer [34381,34385]
trailer [34376,34380]
===
match
---
expr_stmt [13094,13173]
expr_stmt [13089,13168]
===
match
---
name: ti_status [9455,9464]
name: ti_status [9455,9464]
===
match
---
trailer [21789,21796]
trailer [21784,21791]
===
match
---
name: ti [24182,24184]
name: ti [24177,24179]
===
match
---
comparison [8260,8286]
comparison [8260,8286]
===
match
---
trailer [33647,33654]
trailer [33642,33649]
===
match
---
name: log [19660,19663]
name: log [19655,19658]
===
match
---
operator: = [7268,7269]
operator: = [7268,7269]
===
match
---
expr_stmt [29322,29668]
expr_stmt [29317,29663]
===
match
---
simple_stmt [11758,12006]
simple_stmt [11753,12001]
===
match
---
atom_expr [21781,21798]
atom_expr [21776,21793]
===
match
---
name: executed_dag_run_dates [31970,31992]
name: executed_dag_run_dates [31965,31987]
===
match
---
operator: , [20843,20844]
operator: , [20838,20839]
===
match
---
trailer [33264,33290]
trailer [33259,33285]
===
match
---
operator: } [10900,10901]
operator: } [10895,10896]
===
match
---
or_test [31691,31704]
or_test [31686,31699]
===
match
---
atom [29329,29668]
atom [29324,29663]
===
match
---
atom_expr [26755,26845]
atom_expr [26750,26840]
===
match
---
name: start_date [20665,20675]
name: start_date [20660,20670]
===
match
---
expr_stmt [29795,29834]
expr_stmt [29790,29829]
===
match
---
atom_expr [4986,4991]
atom_expr [4986,4991]
===
match
---
operator: , [16346,16347]
operator: , [16341,16342]
===
match
---
name: deadlocked [16066,16076]
name: deadlocked [16061,16071]
===
match
---
operator: , [34058,34059]
operator: , [34053,34054]
===
match
---
operator: , [31422,31423]
operator: , [31417,31418]
===
match
---
name: log [26760,26763]
name: log [26755,26758]
===
match
---
simple_stmt [4649,4681]
simple_stmt [4649,4681]
===
match
---
dotted_name [1652,1679]
dotted_name [1652,1679]
===
match
---
name: ti_status [20404,20413]
name: ti_status [20399,20408]
===
match
---
dotted_name [1787,1806]
dotted_name [1787,1806]
===
match
---
name: job_id [34533,34539]
name: job_id [34528,34534]
===
match
---
string: 'polymorphic_identity' [2216,2238]
string: 'polymorphic_identity' [2216,2238]
===
match
---
name: succeeded [29772,29781]
name: succeeded [29767,29776]
===
match
---
name: query [10810,10815]
name: query [10805,10810]
===
match
---
name: session [16400,16407]
name: session [16395,16402]
===
match
---
trailer [35883,35909]
trailer [35878,35904]
===
match
---
arglist [31505,31529]
arglist [31500,31524]
===
match
---
name: State [14144,14149]
name: State [14139,14144]
===
match
---
name: ti [9740,9742]
name: ti [9740,9742]
===
match
---
name: executed_dag_run_dates [4451,4473]
name: executed_dag_run_dates [4451,4473]
===
match
---
atom_expr [18027,18078]
atom_expr [18022,18073]
===
match
---
name: utils [1833,1838]
name: utils [1833,1838]
===
match
---
atom_expr [8831,8865]
atom_expr [8831,8865]
===
match
---
operator: , [4437,4438]
operator: , [4437,4438]
===
match
---
atom_expr [8215,8247]
atom_expr [8215,8247]
===
match
---
name: State [19195,19200]
name: State [19190,19195]
===
match
---
atom_expr [33339,33357]
atom_expr [33334,33352]
===
match
---
name: remaining_dates [34684,34699]
name: remaining_dates [34679,34694]
===
match
---
simple_stmt [20404,20431]
simple_stmt [20399,20426]
===
match
---
name: TaskInstance [28168,28180]
name: TaskInstance [28163,28175]
===
match
---
arglist [10320,10483]
arglist [10315,10478]
===
match
---
atom_expr [22397,22418]
atom_expr [22392,22413]
===
match
---
operator: = [25469,25470]
operator: = [25464,25465]
===
match
---
operator: , [24762,24763]
operator: , [24757,24758]
===
match
---
name: num_running_task_instances_in_dag [25099,25132]
name: num_running_task_instances_in_dag [25094,25127]
===
match
---
name: SCHEDULED [10891,10900]
name: SCHEDULED [10886,10895]
===
match
---
operator: = [5352,5353]
operator: = [5352,5353]
===
match
---
atom_expr [12058,12100]
atom_expr [12053,12095]
===
match
---
name: filter_for_tis [38235,38249]
name: filter_for_tis [38230,38244]
===
match
---
atom_expr [8508,8522]
atom_expr [8508,8522]
===
match
---
name: self [11183,11187]
name: self [11178,11182]
===
match
---
classdef [2260,5080]
classdef [2260,5080]
===
match
---
name: conf [1687,1691]
name: conf [1687,1691]
===
match
---
strings [10320,10458]
strings [10315,10453]
===
match
---
comparison [23023,23047]
comparison [23018,23042]
===
match
---
atom_expr [34301,34333]
atom_expr [34296,34328]
===
match
---
name: get_task_instances [37762,37780]
name: get_task_instances [37757,37775]
===
match
---
string: """         Internal status of the backfill job. This class is intended to be instantiated         only within a BackfillJob instance and will track the execution of tasks,         e.g. running, skipped, succeeded, failed, etc. Information about the dag runs         related to the backfill job are also being tracked in this structure,         .e.g finished runs, etc. Any other status related information related to the         execution of dag runs / tasks can be included in this structure since it makes         it easier to pass it around.          :param to_run: Tasks to run in the backfill         :type to_run: dict[tuple[TaskInstanceKey], airflow.models.TaskInstance]         :param running: Maps running task instance key to task instance object         :type running: dict[tuple[TaskInstanceKey], airflow.models.TaskInstance]         :param skipped: Tasks that have been skipped         :type skipped: set[tuple[TaskInstanceKey]]         :param succeeded: Tasks that have succeeded so far         :type succeeded: set[tuple[TaskInstanceKey]]         :param failed: Tasks that have failed         :type failed: set[tuple[TaskInstanceKey]]         :param not_ready: Tasks not ready for execution         :type not_ready: set[tuple[TaskInstanceKey]]         :param deadlocked: Deadlocked tasks         :type deadlocked: set[airflow.models.TaskInstance]         :param active_runs: Active dag runs at a certain point in time         :type active_runs: list[DagRun]         :param executed_dag_run_dates: Datetime objects for the executed dag runs         :type executed_dag_run_dates: set[datetime.datetime]         :param finished_runs: Number of finished runs so far         :type finished_runs: int         :param total_runs: Number of total dag runs able to run         :type total_runs: int         """ [2293,4109]
string: """         Internal status of the backfill job. This class is intended to be instantiated         only within a BackfillJob instance and will track the execution of tasks,         e.g. running, skipped, succeeded, failed, etc. Information about the dag runs         related to the backfill job are also being tracked in this structure,         .e.g finished runs, etc. Any other status related information related to the         execution of dag runs / tasks can be included in this structure since it makes         it easier to pass it around.          :param to_run: Tasks to run in the backfill         :type to_run: dict[tuple[TaskInstanceKey], airflow.models.TaskInstance]         :param running: Maps running task instance key to task instance object         :type running: dict[tuple[TaskInstanceKey], airflow.models.TaskInstance]         :param skipped: Tasks that have been skipped         :type skipped: set[tuple[TaskInstanceKey]]         :param succeeded: Tasks that have succeeded so far         :type succeeded: set[tuple[TaskInstanceKey]]         :param failed: Tasks that have failed         :type failed: set[tuple[TaskInstanceKey]]         :param not_ready: Tasks not ready for execution         :type not_ready: set[tuple[TaskInstanceKey]]         :param deadlocked: Deadlocked tasks         :type deadlocked: set[airflow.models.TaskInstance]         :param active_runs: Active dag runs at a certain point in time         :type active_runs: list[DagRun]         :param executed_dag_run_dates: Datetime objects for the executed dag runs         :type executed_dag_run_dates: set[datetime.datetime]         :param finished_runs: Number of finished runs so far         :type finished_runs: int         :param total_runs: Number of total dag runs able to run         :type total_runs: int         """ [2293,4109]
===
match
---
name: dag [34382,34385]
name: dag [34377,34380]
===
match
---
name: dagrun_infos_to_process [35068,35091]
name: dagrun_infos_to_process [35063,35086]
===
match
---
trailer [21664,21670]
trailer [21659,21665]
===
match
---
simple_stmt [10802,10943]
simple_stmt [10797,10938]
===
match
---
trailer [20413,20421]
trailer [20408,20416]
===
match
---
trailer [17514,17520]
trailer [17509,17515]
===
match
---
name: ti [18838,18840]
name: ti [18833,18835]
===
match
---
import_as_name [1687,1707]
import_as_name [1687,1707]
===
match
---
atom_expr [27336,27345]
atom_expr [27331,27340]
===
match
---
suite [34345,34482]
suite [34340,34477]
===
match
---
trailer [23392,23397]
trailer [23387,23392]
===
match
---
operator: = [5373,5374]
operator: = [5373,5374]
===
match
---
trailer [17443,17451]
trailer [17438,17446]
===
match
---
operator: , [16390,16391]
operator: , [16385,16386]
===
match
---
atom [10874,10901]
atom [10869,10896]
===
match
---
name: NoAvailablePoolSlot [24599,24618]
name: NoAvailablePoolSlot [24594,24613]
===
match
---
trailer [33654,33737]
trailer [33649,33732]
===
match
---
name: running [4613,4620]
name: running [4613,4620]
===
match
---
name: pop [18979,18982]
name: pop [18974,18977]
===
match
---
trailer [38190,38196]
trailer [38185,38191]
===
match
---
name: session [14919,14926]
name: session [14914,14921]
===
match
---
name: provide_session [17841,17856]
name: provide_session [17836,17851]
===
match
---
name: run [13628,13631]
name: run [13623,13626]
===
match
---
simple_stmt [34587,34658]
simple_stmt [34582,34653]
===
match
---
trailer [34711,34722]
trailer [34706,34717]
===
match
---
name: key [22709,22712]
name: key [22704,22707]
===
match
---
name: ti_status [26658,26667]
name: ti_status [26653,26662]
===
match
---
import_as_names [1042,1191]
import_as_names [1042,1191]
===
match
---
atom_expr [21962,21995]
atom_expr [21957,21990]
===
match
---
trailer [15281,15315]
trailer [15276,15310]
===
match
---
import_from [1732,1781]
import_from [1732,1781]
===
match
---
argument [22331,22350]
argument [22326,22345]
===
match
---
name: ti [24101,24103]
name: ti [24096,24098]
===
match
---
operator: , [15931,15932]
operator: , [15926,15927]
===
match
---
name: deadlocked [28714,28724]
name: deadlocked [28709,28719]
===
match
---
operator: , [34287,34288]
operator: , [34282,34283]
===
match
---
name: info [15599,15603]
name: info [15594,15598]
===
match
---
name: state [37781,37786]
name: state [37776,37781]
===
match
---
simple_stmt [38708,38804]
simple_stmt [38703,38799]
===
match
---
string: "Backfill done. Exiting." [36303,36328]
string: "Backfill done. Exiting." [36298,36323]
===
match
---
name: err [29847,29850]
name: err [29842,29845]
===
match
---
operator: , [11266,11267]
operator: , [11261,11262]
===
match
---
trailer [23094,23099]
trailer [23089,23094]
===
match
---
trailer [31634,31641]
trailer [31629,31636]
===
match
---
trailer [30215,30226]
trailer [30210,30221]
===
match
---
name: debug [8643,8648]
name: debug [8643,8648]
===
match
---
name: task_instance_str [38785,38802]
name: task_instance_str [38780,38797]
===
match
---
trailer [20366,20374]
trailer [20361,20369]
===
match
---
trailer [24170,24178]
trailer [24165,24173]
===
match
---
name: len [38769,38772]
name: len [38764,38767]
===
match
---
argument [31429,31444]
argument [31424,31439]
===
match
---
name: ti [23923,23925]
name: ti [23918,23920]
===
match
---
if_stmt [29275,29669]
if_stmt [29270,29664]
===
match
---
trailer [17947,17963]
trailer [17942,17958]
===
match
---
operator: = [5167,5168]
operator: = [5167,5168]
===
match
---
subscript [33796,33800]
subscript [33791,33795]
===
match
---
operator: = [35428,35429]
operator: = [35423,35424]
===
match
---
operator: = [4753,4754]
operator: = [4753,4754]
===
match
---
atom_expr [22025,22063]
atom_expr [22020,22058]
===
match
---
suite [18936,18988]
suite [18931,18983]
===
match
---
atom_expr [27946,27959]
atom_expr [27941,27954]
===
match
---
string: "Some task instances failed:\n" [28603,28634]
string: "Some task instances failed:\n" [28598,28629]
===
match
---
name: airflow [1652,1659]
name: airflow [1652,1659]
===
match
---
operator: @ [12106,12107]
operator: @ [12101,12102]
===
match
---
atom_expr [23523,23531]
atom_expr [23518,23526]
===
match
---
string: 'Adding %s to not_ready' [23897,23921]
string: 'Adding %s to not_ready' [23892,23916]
===
match
---
argument [13873,13888]
argument [13868,13883]
===
match
---
trailer [36293,36297]
trailer [36288,36292]
===
match
---
name: pop [18879,18882]
name: pop [18874,18877]
===
match
---
simple_stmt [21866,21882]
simple_stmt [21861,21877]
===
match
---
trailer [27286,27299]
trailer [27281,27294]
===
match
---
trailer [36297,36302]
trailer [36292,36297]
===
match
---
operator: , [26096,26097]
operator: , [26091,26092]
===
match
---
name: BACKFILL_JOB [37586,37598]
name: BACKFILL_JOB [37581,37593]
===
match
---
name: ti_status [9138,9147]
name: ti_status [9138,9147]
===
match
---
name: key [23435,23438]
name: key [23430,23433]
===
match
---
decorated [12106,14270]
decorated [12101,14265]
===
match
---
operator: = [13880,13881]
operator: = [13875,13876]
===
match
---
name: RUNNING [37527,37534]
name: RUNNING [37522,37529]
===
match
---
name: executed_dag_run_dates [4960,4982]
name: executed_dag_run_dates [4960,4982]
===
match
---
operator: = [35479,35480]
operator: = [35474,35475]
===
match
---
number: 0 [24562,24563]
number: 0 [24557,24558]
===
match
---
trailer [8790,8796]
trailer [8790,8796]
===
match
---
name: ti_status [26631,26640]
name: ti_status [26626,26635]
===
match
---
param [27707,27719]
param [27702,27714]
===
match
---
argument [29117,29144]
argument [29112,29139]
===
match
---
trailer [29237,29248]
trailer [29232,29243]
===
match
---
name: self [33065,33069]
name: self [33060,33064]
===
match
---
atom_expr [14181,14204]
atom_expr [14176,14199]
===
match
---
comparison [34741,34760]
comparison [34736,34755]
===
match
---
operator: { [2215,2216]
operator: { [2215,2216]
===
match
---
name: running [23338,23345]
name: running [23333,23340]
===
match
---
trailer [26759,26763]
trailer [26754,26758]
===
match
---
name: ti_status [17405,17414]
name: ti_status [17400,17409]
===
match
---
name: ti [20209,20211]
name: ti [20204,20206]
===
match
---
trailer [15427,15434]
trailer [15422,15429]
===
match
---
if_stmt [25785,26050]
if_stmt [25780,26045]
===
match
---
name: dag [12846,12849]
name: dag [12841,12844]
===
match
---
atom_expr [33783,33801]
atom_expr [33778,33796]
===
match
---
name: delay_on_limit_secs [7443,7462]
name: delay_on_limit_secs [7443,7462]
===
match
---
atom_expr [28382,28392]
atom_expr [28377,28387]
===
match
---
name: get_event_buffer [11291,11307]
name: get_event_buffer [11286,11302]
===
match
---
trailer [16150,16232]
trailer [16145,16227]
===
match
---
name: debug [17515,17520]
name: debug [17510,17515]
===
match
---
simple_stmt [23726,23753]
simple_stmt [23721,23748]
===
match
---
atom_expr [32463,32476]
atom_expr [32458,32471]
===
match
---
atom_expr [7524,7533]
atom_expr [7524,7533]
===
match
---
trailer [24308,24313]
trailer [24303,24308]
===
match
---
simple_stmt [8300,8363]
simple_stmt [8300,8363]
===
match
---
trailer [7213,7226]
trailer [7213,7226]
===
match
---
trailer [7254,7267]
trailer [7254,7267]
===
match
---
operator: = [28891,28892]
operator: = [28886,28887]
===
match
---
name: debug [11594,11599]
name: debug [11589,11594]
===
match
---
name: update_state [27287,27299]
name: update_state [27282,27294]
===
match
---
atom_expr [33851,33873]
atom_expr [33846,33868]
===
match
---
string: "Try number" [28522,28534]
string: "Try number" [28517,28529]
===
match
---
trailer [15948,15967]
trailer [15943,15962]
===
match
---
simple_stmt [8831,8866]
simple_stmt [8831,8866]
===
match
---
trailer [34220,34235]
trailer [34215,34230]
===
match
---
name: ti [18334,18336]
name: ti [18329,18331]
===
match
---
trailer [37698,37700]
trailer [37693,37695]
===
match
---
name: self [20160,20164]
name: self [20155,20159]
===
match
---
name: run_id [28397,28403]
name: run_id [28392,28398]
===
match
---
name: err [30068,30071]
name: err [30063,30066]
===
match
---
name: task [18098,18102]
name: task [18093,18097]
===
match
---
name: dag_id [35823,35829]
name: dag_id [35818,35824]
===
match
---
name: filter [8334,8340]
name: filter [8334,8340]
===
match
---
trailer [38467,38471]
trailer [38462,38466]
===
match
---
name: has_task [21342,21350]
name: has_task [21337,21345]
===
match
---
name: start_date [5134,5144]
name: start_date [5134,5144]
===
match
---
trailer [13781,13788]
trailer [13776,13783]
===
match
---
simple_stmt [4881,4918]
simple_stmt [4881,4918]
===
match
---
trailer [7368,7385]
trailer [7368,7385]
===
match
---
arglist [35558,35572]
arglist [35553,35567]
===
match
---
trailer [20164,20168]
trailer [20159,20163]
===
match
---
operator: , [18180,18181]
operator: , [18175,18176]
===
match
---
name: key [17891,17894]
name: key [17886,17889]
===
match
---
trailer [11553,11569]
trailer [11548,11564]
===
match
---
name: key [23321,23324]
name: key [23316,23319]
===
match
---
name: include_subdag_tasks [24044,24064]
name: include_subdag_tasks [24039,24059]
===
match
---
atom [38578,38580]
atom [38573,38575]
===
match
---
atom_expr [24297,24313]
atom_expr [24292,24308]
===
match
---
operator: , [25549,25550]
operator: , [25544,25545]
===
match
---
name: session [32106,32113]
name: session [32101,32108]
===
match
---
simple_stmt [8494,8523]
simple_stmt [8494,8523]
===
match
---
simple_stmt [33371,33469]
simple_stmt [33366,33464]
===
match
---
name: BACKFILL_QUEUED_DEPS [1535,1555]
name: BACKFILL_QUEUED_DEPS [1535,1555]
===
match
---
if_stmt [24545,24805]
if_stmt [24540,24800]
===
match
---
name: session [37388,37395]
name: session [37383,37390]
===
match
---
name: self [24922,24926]
name: self [24917,24921]
===
match
---
name: handle_failure_with_callback [12061,12089]
name: handle_failure_with_callback [12056,12084]
===
match
---
trailer [24419,24449]
trailer [24414,24444]
===
match
---
try_stmt [15079,15512]
try_stmt [15074,15507]
===
match
---
name: state [11458,11463]
name: state [11453,11458]
===
match
---
name: items [24129,24134]
name: items [24124,24129]
===
match
---
name: log [36294,36297]
name: log [36289,36292]
===
match
---
operator: , [22902,22903]
operator: , [22897,22898]
===
match
---
atom_expr [15872,15893]
atom_expr [15867,15888]
===
match
---
name: ti_status [17572,17581]
name: ti_status [17567,17576]
===
match
---
name: pop [23744,23747]
name: pop [23739,23742]
===
match
---
name: ti [8376,8378]
name: ti [8376,8378]
===
match
---
simple_stmt [21764,21799]
simple_stmt [21759,21794]
===
match
---
name: ti [23649,23651]
name: ti [23644,23646]
===
match
---
name: skipped [30106,30113]
name: skipped [30101,30108]
===
match
---
simple_stmt [978,1005]
simple_stmt [978,1005]
===
match
---
trailer [33290,33326]
trailer [33285,33321]
===
match
---
suite [9059,9248]
suite [9059,9248]
===
match
---
trailer [16144,16150]
trailer [16139,16145]
===
match
---
atom_expr [28045,28124]
atom_expr [28040,28119]
===
match
---
operator: , [28480,28481]
operator: , [28475,28476]
===
match
---
trailer [11593,11599]
trailer [11588,11594]
===
match
---
name: filter_for_tis [8260,8274]
name: filter_for_tis [8260,8274]
===
match
---
name: reduced [8515,8522]
name: reduced [8515,8522]
===
match
---
trailer [26906,26913]
trailer [26901,26908]
===
match
---
name: self [18027,18031]
name: self [18022,18026]
===
match
---
operator: == [13272,13274]
operator: == [13267,13269]
===
match
---
operator: , [13155,13156]
operator: , [13150,13151]
===
match
---
simple_stmt [33891,33970]
simple_stmt [33886,33965]
===
match
---
operator: = [34116,34117]
operator: = [34111,34112]
===
match
---
simple_stmt [34561,34578]
simple_stmt [34556,34573]
===
match
---
simple_stmt [19227,19378]
simple_stmt [19222,19373]
===
match
---
atom_expr [24652,24774]
atom_expr [24647,24769]
===
match
---
trailer [13243,13246]
trailer [13238,13241]
===
match
---
name: ti_status [22688,22697]
name: ti_status [22683,22692]
===
match
---
operator: = [23440,23441]
operator: = [23435,23436]
===
match
---
argument [14884,14909]
argument [14879,14904]
===
match
---
name: reduced_key [8735,8746]
name: reduced_key [8735,8746]
===
match
---
name: utcnow [13782,13788]
name: utcnow [13777,13783]
===
match
---
import_as_names [1687,1731]
import_as_names [1687,1731]
===
match
---
name: failed [4755,4761]
name: failed [4755,4761]
===
match
---
name: active_runs [4421,4432]
name: active_runs [4421,4432]
===
match
---
name: log [19232,19235]
name: log [19227,19230]
===
match
---
trailer [10768,10789]
trailer [10763,10784]
===
match
---
operator: = [21730,21731]
operator: = [21725,21726]
===
match
---
name: ti_status [23683,23692]
name: ti_status [23678,23687]
===
match
---
suite [24193,24231]
suite [24188,24226]
===
match
---
argument [25709,25724]
argument [25704,25719]
===
match
---
sync_comp_for [28420,28440]
sync_comp_for [28415,28435]
===
match
---
operator: = [20620,20621]
operator: = [20615,20616]
===
match
---
simple_stmt [23371,23398]
simple_stmt [23366,23393]
===
match
---
name: verbose [7508,7515]
name: verbose [7508,7515]
===
match
---
name: ti_status [16319,16328]
name: ti_status [16314,16323]
===
match
---
atom_expr [18734,18760]
atom_expr [18729,18755]
===
match
---
name: is_subdag [12850,12859]
name: is_subdag [12845,12854]
===
match
---
trailer [21913,21928]
trailer [21908,21923]
===
match
---
simple_stmt [35533,35574]
simple_stmt [35528,35569]
===
match
---
name: ti_status [26591,26600]
name: ti_status [26586,26595]
===
match
---
trailer [17404,17422]
trailer [17399,17417]
===
match
---
operator: = [14067,14068]
operator: = [14062,14063]
===
match
---
name: remaining_dates [34741,34756]
name: remaining_dates [34736,34751]
===
match
---
name: state [10878,10883]
name: state [10873,10878]
===
match
---
name: runs [13239,13243]
name: runs [13234,13238]
===
match
---
name: ti_status [35563,35572]
name: ti_status [35558,35567]
===
match
---
trailer [9386,9390]
trailer [9386,9390]
===
match
---
raise_stmt [25191,25348]
raise_stmt [25186,25343]
===
match
---
trailer [23195,23208]
trailer [23190,23203]
===
match
---
operator: -> [27790,27792]
operator: -> [27785,27787]
===
match
---
fstring_end: ' [24447,24448]
fstring_end: ' [24442,24443]
===
match
---
trailer [27517,27532]
trailer [27512,27527]
===
match
---
operator: = [14918,14919]
operator: = [14913,14914]
===
match
---
trailer [36243,36250]
trailer [36238,36245]
===
match
---
arglist [18796,18840]
arglist [18791,18835]
===
match
---
param [5519,5528]
param [5519,5528]
===
match
---
name: ti [20085,20087]
name: ti [20080,20082]
===
match
---
name: merge [21831,21836]
name: merge [21826,21831]
===
match
---
operator: != [29047,29049]
operator: != [29042,29044]
===
match
---
name: state [9337,9342]
name: state [9337,9342]
===
match
---
name: deadlocked [4392,4402]
name: deadlocked [4392,4402]
===
match
---
trailer [14169,14178]
trailer [14164,14173]
===
match
---
atom_expr [29228,29248]
atom_expr [29223,29243]
===
match
---
trailer [34406,34410]
trailer [34401,34405]
===
match
---
name: dag_run [32516,32523]
name: dag_run [32511,32518]
===
match
---
funcdef [32051,32583]
funcdef [32046,32578]
===
match
---
trailer [8886,8890]
trailer [8886,8890]
===
match
---
trailer [18047,18055]
trailer [18042,18050]
===
match
---
trailer [24283,24288]
trailer [24278,24283]
===
match
---
string: "DAG ID" [28079,28087]
string: "DAG ID" [28074,28082]
===
match
---
simple_stmt [14059,14073]
simple_stmt [14054,14068]
===
match
---
atom_expr [11183,11196]
atom_expr [11178,11191]
===
match
---
operator: , [30299,30300]
operator: , [30294,30295]
===
match
---
name: ti [19929,19931]
name: ti [19924,19926]
===
match
---
name: ignore_first_depends_on_past [7296,7324]
name: ignore_first_depends_on_past [7296,7324]
===
match
---
trailer [7417,7422]
trailer [7417,7422]
===
match
---
operator: ** [7720,7722]
operator: ** [7720,7722]
===
match
---
param [27755,27788]
param [27750,27783]
===
match
---
operator: = [7506,7507]
operator: = [7506,7507]
===
match
---
trailer [8840,8848]
trailer [8840,8848]
===
match
---
expr_stmt [32866,32897]
expr_stmt [32861,32892]
===
match
---
name: provide_session [27650,27665]
name: provide_session [27645,27660]
===
match
---
name: run_id [28297,28303]
name: run_id [28292,28298]
===
match
---
string: '\n\nThese tasks are running:\n' [29802,29834]
string: '\n\nThese tasks are running:\n' [29797,29829]
===
match
---
string: "although the task says its {}. Was the task " [11857,11903]
string: "although the task says its {}. Was the task " [11852,11898]
===
match
---
name: reset_tis [38501,38510]
name: reset_tis [38496,38505]
===
match
---
name: ti_status [15876,15885]
name: ti_status [15871,15880]
===
match
---
simple_stmt [12870,12945]
simple_stmt [12865,12940]
===
match
---
suite [27797,28125]
suite [27792,28120]
===
match
---
name: session [25036,25043]
name: session [25031,25038]
===
match
---
operator: = [20544,20545]
operator: = [20539,20540]
===
match
---
name: add [34407,34410]
name: add [34402,34405]
===
match
---
name: err [28647,28650]
name: err [28642,28645]
===
match
---
expr_stmt [4558,4595]
expr_stmt [4558,4595]
===
match
---
operator: == [23532,23534]
operator: == [23527,23529]
===
match
---
suite [37963,37985]
suite [37958,37980]
===
match
---
operator: = [35202,35203]
operator: = [35197,35198]
===
match
---
name: key [10636,10639]
name: key [10631,10634]
===
match
---
name: update [10843,10849]
name: update [10838,10844]
===
match
---
name: DepContext [20786,20796]
name: DepContext [20781,20791]
===
match
---
name: rollback [15483,15491]
name: rollback [15478,15486]
===
match
---
expr_stmt [8153,8170]
expr_stmt [8153,8170]
===
match
---
name: pool [24322,24326]
name: pool [24317,24321]
===
match
---
name: Session [923,930]
name: Session [923,930]
===
match
---
trailer [37761,37780]
trailer [37756,37775]
===
match
---
trailer [15242,15247]
trailer [15237,15242]
===
match
---
string: "FIXME: Task instance %s state was set to None externally. This should not happen" [19269,19351]
string: "FIXME: Task instance %s state was set to None externally. This should not happen" [19264,19346]
===
match
---
atom_expr [30189,30227]
atom_expr [30184,30222]
===
match
---
testlist_comp [28491,28534]
testlist_comp [28486,28529]
===
match
---
atom_expr [11465,11481]
atom_expr [11460,11476]
===
match
---
name: models [1340,1346]
name: models [1340,1346]
===
match
---
trailer [12060,12089]
trailer [12055,12084]
===
match
---
name: dagrun_info [13723,13734]
name: dagrun_info [13718,13729]
===
match
---
string: "Task instance %s succeeded. Don't rerun." [18445,18487]
string: "Task instance %s succeeded. Don't rerun." [18440,18482]
===
match
---
operator: , [38783,38784]
operator: , [38778,38779]
===
match
---
operator: = [37020,37021]
operator: = [37015,37016]
===
match
---
name: commit [15428,15434]
name: commit [15423,15429]
===
match
---
simple_stmt [22181,22612]
simple_stmt [22176,22607]
===
match
---
expr_stmt [37727,37822]
expr_stmt [37722,37817]
===
match
---
name: execution_date [13672,13686]
name: execution_date [13667,13681]
===
match
---
name: debug [8891,8896]
name: debug [8891,8896]
===
match
---
arglist [22868,22906]
arglist [22863,22901]
===
match
---
name: DagRunInfo [34021,34031]
name: DagRunInfo [34016,34026]
===
match
---
name: executor_class [34166,34180]
name: executor_class [34161,34175]
===
match
---
name: ti_status [35347,35356]
name: ti_status [35342,35351]
===
match
---
trailer [18131,18135]
trailer [18126,18130]
===
match
---
trailer [20559,20576]
trailer [20554,20571]
===
match
---
arglist [28269,28342]
arglist [28264,28337]
===
match
---
name: session [34431,34438]
name: session [34426,34433]
===
match
---
comparison [13262,13288]
comparison [13257,13283]
===
match
---
expr_stmt [4649,4680]
expr_stmt [4649,4680]
===
match
---
name: len [15945,15948]
name: len [15940,15943]
===
match
---
testlist_comp [34826,34977]
testlist_comp [34821,34972]
===
match
---
suite [32499,32548]
suite [32494,32543]
===
match
---
operator: , [30313,30314]
operator: , [30308,30309]
===
match
---
name: key [19745,19748]
name: key [19740,19743]
===
match
---
suite [10990,12101]
suite [10985,12096]
===
match
---
name: ti_status [24112,24121]
name: ti_status [24107,24116]
===
match
---
simple_stmt [24401,24450]
simple_stmt [24396,24445]
===
match
---
operator: = [7190,7191]
operator: = [7190,7191]
===
match
---
name: ti_status [28566,28575]
name: ti_status [28561,28570]
===
match
---
trailer [18434,18438]
trailer [18429,18433]
===
match
---
name: log [10287,10290]
name: log [10282,10285]
===
match
---
name: self [35884,35888]
name: self [35879,35883]
===
match
---
parameters [16295,16419]
parameters [16290,16414]
===
match
---
name: dagrun_info [31411,31422]
name: dagrun_info [31406,31417]
===
match
---
operator: , [38249,38250]
operator: , [38244,38245]
===
match
---
name: ti [28424,28426]
name: ti [28419,28421]
===
match
---
name: external_trigger [13837,13853]
name: external_trigger [13832,13848]
===
match
---
simple_stmt [34491,34516]
simple_stmt [34486,34511]
===
match
---
name: deadlocked [26872,26882]
name: deadlocked [26867,26877]
===
match
---
argument [20992,21017]
argument [20987,21012]
===
match
---
if_stmt [27333,27534]
if_stmt [27328,27529]
===
match
---
operator: , [5304,5305]
operator: , [5304,5305]
===
match
---
simple_stmt [28356,28442]
simple_stmt [28351,28437]
===
match
---
expr_stmt [23418,23444]
expr_stmt [23413,23439]
===
match
---
trailer [37511,37517]
trailer [37506,37512]
===
match
---
trailer [10819,10826]
trailer [10814,10821]
===
match
---
name: key [26093,26096]
name: key [26088,26091]
===
match
---
atom_expr [38454,38471]
atom_expr [38449,38466]
===
match
---
trailer [15920,15930]
trailer [15915,15925]
===
match
---
atom_expr [22853,22907]
atom_expr [22848,22902]
===
match
---
name: ti_status [23418,23427]
name: ti_status [23413,23422]
===
match
---
operator: , [35792,35793]
operator: , [35787,35788]
===
match
---
trailer [18629,18633]
trailer [18624,18628]
===
match
---
name: session [30359,30366]
name: session [30354,30361]
===
match
---
operator: = [22527,22528]
operator: = [22522,22523]
===
match
---
name: session [12185,12192]
name: session [12180,12187]
===
match
---
expr_stmt [21866,21881]
expr_stmt [21861,21876]
===
match
---
name: ti [19398,19400]
name: ti [19393,19395]
===
match
---
fstring_expr [24436,24447]
fstring_expr [24431,24442]
===
match
---
atom_expr [7250,7267]
atom_expr [7250,7267]
===
match
---
trailer [23692,23700]
trailer [23687,23695]
===
match
---
name: ti_status [20297,20306]
name: ti_status [20292,20301]
===
match
---
operator: ** [5519,5521]
operator: ** [5519,5521]
===
match
---
name: list [11277,11281]
name: list [11272,11276]
===
match
---
name: timezone [33017,33025]
name: timezone [33012,33020]
===
match
---
operator: >= [25823,25825]
operator: >= [25818,25820]
===
match
---
atom_expr [20098,20110]
atom_expr [20093,20105]
===
match
---
name: ti [20662,20664]
name: ti [20657,20659]
===
match
---
name: bf_start_date [7138,7151]
name: bf_start_date [7138,7151]
===
match
---
parameters [17890,17927]
parameters [17885,17922]
===
match
---
name: skipped [16030,16037]
name: skipped [16025,16032]
===
match
---
not_test [37946,37962]
not_test [37941,37957]
===
match
---
trailer [27952,27959]
trailer [27947,27954]
===
match
---
name: self [33891,33895]
name: self [33886,33890]
===
match
---
name: State [20112,20117]
name: State [20107,20112]
===
match
---
name: session [29155,29162]
name: session [29150,29157]
===
match
---
raise_stmt [35533,35573]
raise_stmt [35528,35568]
===
match
---
name: set [4723,4726]
name: set [4723,4726]
===
match
---
name: ti [9435,9437]
name: ti [9435,9437]
===
match
---
trailer [8219,8247]
trailer [8219,8247]
===
match
---
operator: , [23921,23922]
operator: , [23916,23917]
===
match
---
trailer [29761,29782]
trailer [29756,29777]
===
match
---
atom_expr [13992,13999]
atom_expr [13987,13994]
===
match
---
trailer [18621,18629]
trailer [18616,18624]
===
match
---
param [16338,16347]
param [16333,16342]
===
match
---
trailer [15810,15824]
trailer [15805,15819]
===
match
---
trailer [21736,21739]
trailer [21731,21734]
===
match
---
testlist_comp [2163,2190]
testlist_comp [2163,2190]
===
match
---
simple_stmt [29681,29722]
simple_stmt [29676,29717]
===
match
---
simple_stmt [8180,8249]
simple_stmt [8180,8249]
===
match
---
trailer [34478,34481]
trailer [34473,34476]
===
match
---
operator: = [22129,22130]
operator: = [22124,22125]
===
match
---
simple_stmt [13607,13619]
simple_stmt [13602,13614]
===
match
---
trailer [24121,24128]
trailer [24116,24123]
===
match
---
name: ti_status [9506,9515]
name: ti_status [9506,9515]
===
match
---
name: BackfillJob [32825,32836]
name: BackfillJob [32820,32831]
===
match
---
name: dagrun_info [34826,34837]
name: dagrun_info [34821,34832]
===
match
---
atom_expr [26654,26675]
atom_expr [26649,26670]
===
match
---
arglist [21395,21464]
arglist [21390,21459]
===
match
---
trailer [33343,33357]
trailer [33338,33352]
===
match
---
name: finished_runs [4492,4505]
name: finished_runs [4492,4505]
===
match
---
name: running [11378,11385]
name: running [11373,11380]
===
match
---
trailer [25651,25675]
trailer [25646,25670]
===
match
---
atom_expr [37272,37287]
atom_expr [37267,37282]
===
match
---
name: State [2178,2183]
name: State [2178,2183]
===
match
---
name: tis_to_reset [37832,37844]
name: tis_to_reset [37827,37839]
===
match
---
name: executor [34524,34532]
name: executor [34519,34527]
===
match
---
atom_expr [4863,4868]
atom_expr [4863,4868]
===
match
---
name: running [8230,8237]
name: running [8230,8237]
===
match
---
name: run [14132,14135]
name: run [14127,14130]
===
match
---
name: self [7438,7442]
name: self [7438,7442]
===
match
---
atom_expr [15981,16002]
atom_expr [15976,15997]
===
match
---
name: session [10802,10809]
name: session [10797,10804]
===
match
---
name: dag [13120,13123]
name: dag [13115,13118]
===
match
---
atom_expr [22734,22750]
atom_expr [22729,22745]
===
match
---
trailer [38326,38328]
trailer [38321,38323]
===
match
---
name: run_date [13147,13155]
name: run_date [13142,13150]
===
match
---
expr_stmt [7524,7540]
expr_stmt [7524,7540]
===
match
---
atom_expr [15225,15233]
atom_expr [15220,15228]
===
match
---
name: State [19942,19947]
name: State [19937,19942]
===
match
---
name: debug [21525,21530]
name: debug [21520,21525]
===
match
---
name: info [33900,33904]
name: info [33895,33899]
===
match
---
atom_expr [18045,18055]
atom_expr [18040,18050]
===
match
---
trailer [8323,8329]
trailer [8323,8329]
===
match
---
simple_stmt [13094,13174]
simple_stmt [13089,13169]
===
match
---
if_stmt [14745,14797]
if_stmt [14740,14792]
===
match
---
name: verbose [21270,21277]
name: verbose [21265,21272]
===
match
---
decorated [36335,38834]
decorated [36330,38829]
===
match
---
name: collections [807,818]
name: collections [807,818]
===
match
---
trailer [22748,22750]
trailer [22743,22745]
===
match
---
simple_stmt [29322,29669]
simple_stmt [29317,29664]
===
match
---
trailer [11187,11196]
trailer [11182,11191]
===
match
---
trailer [27394,27408]
trailer [27389,27403]
===
match
---
trailer [15910,15931]
trailer [15905,15926]
===
match
---
for_stmt [31280,31706]
for_stmt [31275,31701]
===
match
---
decorated [7735,10943]
decorated [7735,10938]
===
match
---
name: ti_status [29762,29771]
name: ti_status [29757,29766]
===
match
---
trailer [35822,35829]
trailer [35817,35824]
===
match
---
name: open_slots [24752,24762]
name: open_slots [24747,24757]
===
match
---
comparison [27336,27363]
comparison [27331,27358]
===
match
---
atom_expr [19227,19377]
atom_expr [19222,19372]
===
match
---
simple_stmt [24475,24521]
simple_stmt [24470,24516]
===
match
---
expr_stmt [31715,31950]
expr_stmt [31710,31945]
===
match
---
name: args [5505,5509]
name: args [5505,5509]
===
match
---
trailer [13658,14010]
trailer [13653,14005]
===
match
---
testlist_comp [19593,19628]
testlist_comp [19588,19623]
===
match
---
arglist [37781,37821]
arglist [37776,37816]
===
match
---
trailer [38712,38716]
trailer [38707,38711]
===
match
---
operator: , [30324,30325]
operator: , [30319,30320]
===
match
---
string: """         Checks if the executor agrees with the state of task instances         that are running          :param running: dict of key, task to verify         """ [10999,11163]
string: """         Checks if the executor agrees with the state of task instances         that are running          :param running: dict of key, task to verify         """ [10994,11158]
===
match
---
argument [37781,37804]
argument [37776,37799]
===
match
---
name: dependencies_deps [1510,1527]
name: dependencies_deps [1510,1527]
===
match
---
name: tis_to_reset [38564,38576]
name: tis_to_reset [38559,38571]
===
match
---
simple_stmt [27856,28026]
simple_stmt [27851,28021]
===
match
---
simple_stmt [22636,22664]
simple_stmt [22631,22659]
===
match
---
atom_expr [16020,16037]
atom_expr [16015,16032]
===
match
---
comparison [9629,9664]
comparison [9629,9664]
===
match
---
name: tabulate_ti_keys_set [29741,29761]
name: tabulate_ti_keys_set [29736,29756]
===
match
---
atom_expr [34702,34722]
atom_expr [34697,34717]
===
match
---
name: provide_session [36336,36351]
name: provide_session [36331,36346]
===
match
---
name: session [15299,15306]
name: session [15294,15301]
===
match
---
operator: } [24446,24447]
operator: } [24441,24442]
===
match
---
param [5504,5510]
param [5504,5510]
===
match
---
simple_stmt [7250,7283]
simple_stmt [7250,7283]
===
match
---
if_stmt [9031,9248]
if_stmt [9031,9248]
===
match
---
operator: = [31739,31740]
operator: = [31734,31735]
===
match
---
atom_expr [24488,24520]
atom_expr [24483,24515]
===
match
---
name: ti_status [15570,15579]
name: ti_status [15565,15574]
===
match
---
simple_stmt [22120,22156]
simple_stmt [22115,22151]
===
match
---
name: len [16052,16055]
name: len [16047,16050]
===
match
---
name: log [23585,23588]
name: log [23580,23583]
===
match
---
trailer [35033,35311]
trailer [35028,35306]
===
match
---
trailer [19200,19205]
trailer [19195,19200]
===
match
---
comp_if [33447,33467]
comp_if [33442,33462]
===
match
---
param [32622,32627]
param [32617,32622]
===
match
---
simple_stmt [38089,38141]
simple_stmt [38084,38136]
===
match
---
name: pendulum [879,887]
name: pendulum [879,887]
===
match
---
simple_stmt [20719,20750]
simple_stmt [20714,20745]
===
match
---
argument [31792,31811]
argument [31787,31806]
===
match
---
trailer [18529,18533]
trailer [18524,18528]
===
match
---
trailer [27967,27974]
trailer [27962,27969]
===
match
---
if_stmt [37943,37985]
if_stmt [37938,37980]
===
match
---
param [5238,5273]
param [5238,5273]
===
match
---
operator: } [31703,31704]
operator: } [31698,31699]
===
match
---
operator: , [21251,21252]
operator: , [21246,21247]
===
match
---
name: num_running_task_instances_in_dag [24830,24863]
name: num_running_task_instances_in_dag [24825,24858]
===
match
---
operator: = [31833,31834]
operator: = [31828,31829]
===
match
---
number: 0 [4506,4507]
number: 0 [4506,4507]
===
match
---
simple_stmt [19799,19826]
simple_stmt [19794,19821]
===
match
---
operator: , [30357,30358]
operator: , [30352,30353]
===
match
---
name: session [31437,31444]
name: session [31432,31439]
===
match
---
name: key [18883,18886]
name: key [18878,18881]
===
match
---
name: execution_date [13132,13146]
name: execution_date [13127,13141]
===
match
---
atom_expr [25593,25605]
atom_expr [25588,25600]
===
match
---
name: bf_end_date [7178,7189]
name: bf_end_date [7178,7189]
===
match
---
operator: , [31875,31876]
operator: , [31870,31871]
===
match
---
simple_stmt [29958,30004]
simple_stmt [29953,29999]
===
match
---
name: self [35818,35822]
name: self [35813,35817]
===
match
---
string: '\n\nThese tasks are skipped:\n' [30023,30055]
string: '\n\nThese tasks are skipped:\n' [30018,30050]
===
match
---
name: self [36289,36293]
name: self [36284,36288]
===
match
---
atom_expr [24866,25070]
atom_expr [24861,25065]
===
match
---
name: dag_run [32574,32581]
name: dag_run [32569,32576]
===
match
---
atom_expr [22131,22155]
atom_expr [22126,22150]
===
match
---
simple_stmt [26075,26102]
simple_stmt [26070,26097]
===
match
---
name: running [26710,26717]
name: running [26705,26712]
===
match
---
name: set_state [15272,15281]
name: set_state [15267,15276]
===
match
---
atom_expr [11786,11987]
atom_expr [11781,11982]
===
match
---
trailer [23180,23186]
trailer [23175,23181]
===
match
---
atom_expr [17572,17599]
atom_expr [17567,17594]
===
match
---
atom_expr [12811,12860]
atom_expr [12806,12855]
===
match
---
name: airflow_conf [1695,1707]
name: airflow_conf [1695,1707]
===
match
---
name: ti_status [9760,9769]
name: ti_status [9760,9769]
===
match
---
name: cfg_path [22576,22584]
name: cfg_path [22571,22579]
===
match
---
trailer [11569,11571]
trailer [11564,11566]
===
match
---
atom_expr [26890,26915]
atom_expr [26885,26910]
===
match
---
name: active_runs [4900,4911]
name: active_runs [4900,4911]
===
match
---
simple_stmt [35012,35312]
simple_stmt [35007,35307]
===
match
---
name: SEQUENTIAL_EXECUTOR [34268,34287]
name: SEQUENTIAL_EXECUTOR [34263,34282]
===
match
---
comparison [18687,18712]
comparison [18682,18707]
===
match
---
atom_expr [27768,27788]
atom_expr [27763,27783]
===
match
---
name: log [18786,18789]
name: log [18781,18784]
===
match
---
trailer [37694,37698]
trailer [37689,37693]
===
match
---
operator: , [9738,9739]
operator: , [9738,9739]
===
match
---
atom_expr [16206,16231]
atom_expr [16201,16226]
===
match
---
operator: , [21555,21556]
operator: , [21550,21551]
===
match
---
argument [22271,22301]
argument [22266,22296]
===
match
---
comparison [23321,23345]
comparison [23316,23340]
===
match
---
name: pool [24309,24313]
name: pool [24304,24308]
===
match
---
trailer [11599,11640]
trailer [11594,11635]
===
match
---
name: State [20098,20103]
name: State [20093,20098]
===
match
---
trailer [18097,18102]
trailer [18092,18097]
===
match
---
comparison [22798,22831]
comparison [22793,22826]
===
match
---
name: id [34479,34481]
name: id [34474,34476]
===
match
---
name: self [26222,26226]
name: self [26217,26221]
===
match
---
trailer [8848,8852]
trailer [8848,8852]
===
match
---
suite [23048,23100]
suite [23043,23095]
===
match
---
trailer [7712,7729]
trailer [7712,7729]
===
match
---
name: ti [9828,9830]
name: ti [9823,9825]
===
match
---
trailer [9464,9472]
trailer [9464,9472]
===
match
---
trailer [29995,30002]
trailer [29990,29997]
===
match
---
trailer [35356,35367]
trailer [35351,35362]
===
match
---
funcdef [16259,27644]
funcdef [16254,27639]
===
match
---
name: session [15307,15314]
name: session [15302,15309]
===
match
---
suite [33090,33148]
suite [33085,33143]
===
match
---
name: airflow [1199,1206]
name: airflow [1199,1206]
===
match
---
name: dagrun_info [31284,31295]
name: dagrun_info [31279,31290]
===
match
---
atom_expr [15590,16126]
atom_expr [15585,16121]
===
match
---
operator: = [34470,34471]
operator: = [34465,34466]
===
match
---
operator: , [11635,11636]
operator: , [11630,11631]
===
match
---
string: "Executor state: %s task %s" [11600,11628]
string: "Executor state: %s task %s" [11595,11623]
===
match
---
operator: , [13130,13131]
operator: , [13125,13126]
===
match
---
trailer [16029,16037]
trailer [16024,16032]
===
match
---
simple_stmt [14213,14251]
simple_stmt [14208,14246]
===
match
---
trailer [26699,26718]
trailer [26694,26713]
===
match
---
trailer [20103,20110]
trailer [20098,20105]
===
match
---
comparison [32463,32498]
comparison [32458,32493]
===
match
---
suite [38399,38472]
suite [38394,38467]
===
match
---
atom_expr [27349,27363]
atom_expr [27344,27358]
===
match
---
name: pool [24442,24446]
name: pool [24437,24441]
===
match
---
atom [37370,37694]
atom [37365,37689]
===
match
---
name: key [11367,11370]
name: key [11362,11365]
===
match
---
atom_expr [9682,9743]
atom_expr [9682,9743]
===
match
---
trailer [22697,22704]
trailer [22692,22699]
===
match
---
atom_expr [28461,28536]
atom_expr [28456,28531]
===
match
---
name: self [7173,7177]
name: self [7173,7177]
===
match
---
and_test [17400,17492]
and_test [17395,17487]
===
match
---
name: SEQUENTIAL_EXECUTOR [22044,22063]
name: SEQUENTIAL_EXECUTOR [22039,22058]
===
match
---
operator: , [13823,13824]
operator: , [13818,13819]
===
match
---
atom_expr [18687,18695]
atom_expr [18682,18690]
===
match
---
simple_stmt [30127,30170]
simple_stmt [30122,30165]
===
match
---
comparison [28836,29202]
comparison [28831,29197]
===
match
---
trailer [22867,22907]
trailer [22862,22902]
===
match
---
name: values [8238,8244]
name: values [8238,8244]
===
match
---
trailer [28858,29030]
trailer [28853,29025]
===
match
---
name: tabulate [952,960]
name: tabulate [952,960]
===
match
---
strings [35674,35792]
strings [35669,35787]
===
match
---
name: ti [15405,15407]
name: ti [15400,15402]
===
match
---
tfpdef [17896,17912]
tfpdef [17891,17907]
===
match
---
simple_stmt [26222,26240]
simple_stmt [26217,26235]
===
match
---
name: log [9387,9390]
name: log [9387,9390]
===
match
---
name: BACKFILL_JOB [13950,13962]
name: BACKFILL_JOB [13945,13957]
===
match
---
name: ti [11637,11639]
name: ti [11632,11634]
===
match
---
operator: = [4798,4799]
operator: = [4798,4799]
===
match
---
sync_comp_for [33410,33467]
sync_comp_for [33405,33462]
===
match
---
if_stmt [19577,19976]
if_stmt [19572,19971]
===
match
---
arglist [38235,38292]
arglist [38230,38287]
===
match
---
operator: , [16365,16366]
operator: , [16360,16361]
===
match
---
trailer [11281,11318]
trailer [11276,11313]
===
match
---
param [5210,5229]
param [5210,5229]
===
match
---
operator: = [20742,20743]
operator: = [20737,20738]
===
match
---
comparison [17401,17426]
comparison [17396,17421]
===
match
---
name: sqlalchemy [893,903]
name: sqlalchemy [893,903]
===
match
---
param [14328,14333]
param [14323,14328]
===
match
---
trailer [31641,31650]
trailer [31636,31645]
===
match
---
name: ti_status [31667,31676]
name: ti_status [31662,31671]
===
match
---
decorator [36335,36352]
decorator [36330,36347]
===
match
---
name: TaskConcurrencyLimitReached [26171,26198]
name: TaskConcurrencyLimitReached [26166,26193]
===
match
---
name: self [10282,10286]
name: self [10277,10281]
===
match
---
param [16319,16329]
param [16314,16324]
===
match
---
param [27696,27706]
param [27691,27701]
===
match
---
comparison [35594,35613]
comparison [35589,35608]
===
match
---
trailer [8244,8246]
trailer [8244,8246]
===
match
---
atom_expr [14213,14250]
atom_expr [14208,14245]
===
match
---
name: ti [21351,21353]
name: ti [21346,21348]
===
match
---
atom_expr [10242,10250]
atom_expr [10237,10245]
===
match
---
string: 'Some of the deadlocked tasks were unable to run because ' [29351,29409]
string: 'Some of the deadlocked tasks were unable to run because ' [29346,29404]
===
match
---
trailer [38556,38605]
trailer [38551,38600]
===
match
---
operator: , [11463,11464]
operator: , [11458,11459]
===
match
---
argument [28903,28931]
argument [28898,28926]
===
match
---
param [17914,17926]
param [17909,17921]
===
match
---
operator: , [28969,28970]
operator: , [28964,28965]
===
match
---
trailer [23782,23789]
trailer [23777,23784]
===
match
---
operator: = [27206,27207]
operator: = [27201,27202]
===
match
---
argument [13672,13695]
argument [13667,13690]
===
match
---
simple_stmt [33236,33328]
simple_stmt [33231,33323]
===
match
---
operator: - [33798,33799]
operator: - [33793,33794]
===
match
---
trailer [20117,20133]
trailer [20112,20128]
===
match
---
operator: @ [30253,30254]
operator: @ [30248,30249]
===
match
---
name: self [34377,34381]
name: self [34372,34376]
===
match
---
atom_expr [18862,18887]
atom_expr [18857,18882]
===
match
---
operator: = [15306,15307]
operator: = [15301,15302]
===
match
---
trailer [17591,17597]
trailer [17586,17592]
===
match
---
name: start_date [32866,32876]
name: start_date [32861,32871]
===
match
---
operator: , [1420,1421]
operator: , [1420,1421]
===
match
---
try_stmt [23985,26240]
try_stmt [23980,26235]
===
match
---
atom_expr [21764,21778]
atom_expr [21759,21773]
===
match
---
atom_expr [4765,4770]
atom_expr [4765,4770]
===
match
---
trailer [9472,9476]
trailer [9472,9476]
===
match
---
atom_expr [8581,8617]
atom_expr [8581,8617]
===
match
---
expr_stmt [13182,13203]
expr_stmt [13177,13198]
===
match
---
name: DagRun [13101,13107]
name: DagRun [13096,13102]
===
match
---
arglist [14884,14926]
arglist [14879,14921]
===
match
---
comp_op [34181,34187]
comp_op [34176,34182]
===
match
---
for_stmt [8372,10646]
for_stmt [8372,10641]
===
match
---
trailer [19400,19410]
trailer [19395,19405]
===
match
---
name: backfill_context [20767,20783]
name: backfill_context [20762,20778]
===
match
---
param [12175,12184]
param [12170,12179]
===
match
---
simple_stmt [32651,32805]
simple_stmt [32646,32800]
===
match
---
name: running [23693,23700]
name: running [23688,23695]
===
match
---
name: getboolean [17348,17358]
name: getboolean [17343,17353]
===
match
---
trailer [22704,22708]
trailer [22699,22703]
===
match
---
operator: , [4297,4298]
operator: , [4297,4298]
===
match
---
simple_stmt [7077,7092]
simple_stmt [7077,7092]
===
match
---
name: TaskInstance [37438,37450]
name: TaskInstance [37433,37445]
===
match
---
expr_stmt [35329,35407]
expr_stmt [35324,35402]
===
match
---
return_stmt [14777,14796]
return_stmt [14772,14791]
===
match
---
name: UPSTREAM_FAILED [20118,20133]
name: UPSTREAM_FAILED [20113,20128]
===
match
---
suite [13220,13343]
suite [13215,13338]
===
match
---
name: session [908,915]
name: session [908,915]
===
match
---
expr_stmt [30068,30114]
expr_stmt [30063,30109]
===
match
---
name: Optional [13187,13195]
name: Optional [13182,13190]
===
match
---
name: self [7602,7606]
name: self [7602,7606]
===
match
---
name: self [34502,34506]
name: self [34497,34501]
===
match
---
name: self [13907,13911]
name: self [13902,13906]
===
match
---
name: t [33414,33415]
name: t [33409,33410]
===
match
---
strings [15617,15787]
strings [15612,15782]
===
match
---
atom_expr [21710,21729]
atom_expr [21705,21724]
===
match
---
atom_expr [29875,29892]
atom_expr [29870,29887]
===
match
---
atom_expr [14132,14141]
atom_expr [14127,14136]
===
match
---
return_stmt [38485,38510]
return_stmt [38480,38505]
===
match
---
expr_stmt [7549,7593]
expr_stmt [7549,7593]
===
match
---
simple_stmt [9760,9795]
simple_stmt [9760,9790]
===
match
---
trailer [14233,14250]
trailer [14228,14245]
===
match
---
name: running [23083,23090]
name: running [23078,23085]
===
match
---
name: session [37806,37813]
name: session [37801,37808]
===
match
---
simple_stmt [10999,11164]
simple_stmt [10994,11159]
===
match
---
atom_expr [9346,9364]
atom_expr [9346,9364]
===
match
---
suite [8814,9019]
suite [8814,9019]
===
match
---
suite [35957,36207]
suite [35952,36202]
===
match
---
name: to_run [15886,15892]
name: to_run [15881,15887]
===
match
---
name: depends_on_past [33452,33467]
name: depends_on_past [33447,33462]
===
match
---
operator: = [14179,14180]
operator: = [14174,14175]
===
match
---
name: tasks_to_run [15382,15394]
name: tasks_to_run [15377,15389]
===
match
---
operator: = [8195,8196]
operator: = [8195,8196]
===
match
---
operator: = [31436,31437]
operator: = [31431,31432]
===
match
---
name: num_running_task_instances_in_task [25434,25468]
name: num_running_task_instances_in_task [25429,25463]
===
match
---
simple_stmt [32560,32583]
simple_stmt [32555,32578]
===
match
---
operator: , [21460,21461]
operator: , [21455,21456]
===
match
---
trailer [18689,18695]
trailer [18684,18690]
===
match
---
name: error [19664,19669]
name: error [19659,19664]
===
match
---
operator: , [31811,31812]
operator: , [31806,31807]
===
match
---
operator: , [34235,34236]
operator: , [34230,34231]
===
match
---
name: STATES_COUNT_AS_RUNNING [11717,11740]
name: STATES_COUNT_AS_RUNNING [11712,11735]
===
match
---
atom_expr [19580,19588]
atom_expr [19575,19583]
===
match
---
name: append [10538,10544]
name: append [10533,10539]
===
match
---
expr_stmt [37251,37302]
expr_stmt [37246,37297]
===
match
---
trailer [29116,29145]
trailer [29111,29140]
===
match
---
operator: += [29851,29853]
operator: += [29846,29848]
===
match
---
name: log [23235,23238]
name: log [23230,23233]
===
match
---
operator: , [14909,14910]
operator: , [14904,14905]
===
match
---
operator: , [13790,13791]
operator: , [13785,13786]
===
match
---
operator: { [10874,10875]
operator: { [10869,10870]
===
match
---
name: log [38713,38716]
name: log [38708,38711]
===
match
---
name: start_date [20648,20658]
name: start_date [20643,20653]
===
match
---
operator: = [7573,7574]
operator: = [7573,7574]
===
match
---
name: dagrun_end_date [33174,33189]
name: dagrun_end_date [33169,33184]
===
match
---
operator: = [16385,16386]
operator: = [16380,16381]
===
match
---
simple_stmt [29906,29946]
simple_stmt [29901,29941]
===
match
---
trailer [20087,20093]
trailer [20082,20088]
===
match
---
testlist_comp [21962,22064]
testlist_comp [21957,22059]
===
match
---
atom_expr [13187,13203]
atom_expr [13182,13198]
===
match
---
and_test [37879,37933]
and_test [37874,37928]
===
match
---
simple_stmt [19398,19445]
simple_stmt [19393,19440]
===
match
---
if_stmt [33481,33756]
if_stmt [33476,33751]
===
match
---
argument [13902,13916]
argument [13897,13911]
===
match
---
simple_stmt [37727,37823]
simple_stmt [37722,37818]
===
match
---
name: UPSTREAM_FAILED [22816,22831]
name: UPSTREAM_FAILED [22811,22826]
===
match
---
name: session [36236,36243]
name: session [36231,36238]
===
match
---
name: is_unit_test [26286,26298]
name: is_unit_test [26281,26293]
===
match
---
operator: = [20948,20949]
operator: = [20943,20944]
===
match
---
name: session [19959,19966]
name: session [19954,19961]
===
match
---
operator: , [5379,5380]
operator: , [5379,5380]
===
match
---
trailer [9781,9794]
trailer [9784,9788]
===
match
---
operator: = [32877,32878]
operator: = [32872,32873]
===
match
---
or_test [4755,4770]
or_test [4755,4770]
===
match
---
trailer [9631,9637]
trailer [9631,9637]
===
match
---
arglist [8897,8941]
arglist [8897,8941]
===
match
---
name: SUCCESS [8556,8563]
name: SUCCESS [8556,8563]
===
match
---
name: warning [26764,26771]
name: warning [26759,26766]
===
match
---
name: ti_status [17466,17475]
name: ti_status [17461,17470]
===
match
---
simple_stmt [8713,8748]
simple_stmt [8713,8748]
===
match
---
trailer [22944,22948]
trailer [22939,22943]
===
match
---
argument [22523,22537]
argument [22518,22532]
===
match
---
expr_stmt [37009,37048]
expr_stmt [37004,37043]
===
match
---
name: session [31932,31939]
name: session [31927,31934]
===
match
---
atom_expr [16136,16232]
atom_expr [16131,16227]
===
match
---
trailer [10625,10632]
trailer [10620,10627]
===
match
---
trailer [37632,37638]
trailer [37627,37633]
===
match
---
trailer [7649,7667]
trailer [7649,7667]
===
match
---
simple_stmt [37139,37175]
simple_stmt [37134,37170]
===
match
---
name: msg [11758,11761]
name: msg [11753,11756]
===
match
---
name: commit [22742,22748]
name: commit [22737,22743]
===
match
---
trailer [29771,29781]
trailer [29766,29776]
===
match
---
name: _log_progress [27552,27565]
name: _log_progress [27547,27560]
===
match
---
name: iter_dagrun_infos_between [33265,33290]
name: iter_dagrun_infos_between [33260,33285]
===
match
---
name: key [18562,18565]
name: key [18557,18560]
===
match
---
trailer [14062,14066]
trailer [14057,14061]
===
match
---
atom_expr [38582,38604]
atom_expr [38577,38599]
===
match
---
name: tis_map [31462,31469]
name: tis_map [31457,31464]
===
match
---
operator: = [34608,34609]
operator: = [34603,34604]
===
match
---
operator: = [4570,4571]
operator: = [4570,4571]
===
match
---
name: ti [37908,37910]
name: ti [37903,37905]
===
match
---
atom_expr [34587,34607]
atom_expr [34582,34602]
===
match
---
operator: = [10873,10874]
operator: = [10868,10869]
===
match
---
atom_expr [4582,4595]
atom_expr [4582,4595]
===
match
---
operator: = [29139,29140]
operator: = [29134,29135]
===
match
---
string: "Run ID" [28512,28520]
string: "Run ID" [28507,28515]
===
match
---
atom [37271,37302]
atom [37266,37297]
===
match
---
trailer [10582,10586]
trailer [10577,10581]
===
match
---
name: conf [5389,5393]
name: conf [5389,5393]
===
match
---
if_stmt [24163,24231]
if_stmt [24158,24226]
===
match
---
if_stmt [38032,38076]
if_stmt [38027,38071]
===
match
---
name: self [11585,11589]
name: self [11580,11584]
===
match
---
atom_expr [21662,21670]
atom_expr [21657,21665]
===
match
---
argument [28954,28969]
argument [28949,28964]
===
match
---
trailer [9827,9835]
trailer [9822,9830]
===
match
---
name: __init__ [7704,7712]
name: __init__ [7704,7712]
===
match
---
name: executor [36265,36273]
name: executor [36260,36268]
===
match
---
simple_stmt [1820,1863]
simple_stmt [1820,1863]
===
match
---
simple_stmt [38485,38511]
simple_stmt [38480,38506]
===
match
---
simple_stmt [9506,9536]
simple_stmt [9506,9536]
===
match
---
atom_expr [34139,34156]
atom_expr [34134,34151]
===
match
---
import_from [1005,1193]
import_from [1005,1193]
===
match
---
name: all [38346,38349]
name: all [38341,38344]
===
match
---
operator: , [28499,28500]
operator: , [28494,28495]
===
match
---
trailer [35877,35883]
trailer [35872,35878]
===
match
---
string: """         Computes the dag runs and their respective task instances for         the given run dates and executes the task instances.         Returns a list of execution dates of the dag runs that were executed.          :param dagrun_infos: Schedule information for dag runs         :type dagrun_infos: list[DagRunInfo]         :param ti_status: internal BackfillJob status structure to tis track progress         :type ti_status: BackfillJob._DagRunTaskStatus         :param executor: the executor to use, it must be previously started         :type executor: BaseExecutor         :param pickle_id: numeric id of the pickled dag, None if not pickled         :type pickle_id: int         :param start_date: backfill start date         :type start_date: datetime.datetime         :param session: the current session object         :type session: sqlalchemy.orm.session.Session         """ [30382,31271]
string: """         Computes the dag runs and their respective task instances for         the given run dates and executes the task instances.         Returns a list of execution dates of the dag runs that were executed.          :param dagrun_infos: Schedule information for dag runs         :type dagrun_infos: list[DagRunInfo]         :param ti_status: internal BackfillJob status structure to tis track progress         :type ti_status: BackfillJob._DagRunTaskStatus         :param executor: the executor to use, it must be previously started         :type executor: BaseExecutor         :param pickle_id: numeric id of the pickled dag, None if not pickled         :type pickle_id: int         :param start_date: backfill start date         :type start_date: datetime.datetime         :param session: the current session object         :type session: sqlalchemy.orm.session.Session         """ [30377,31266]
===
match
---
trailer [26828,26835]
trailer [26823,26830]
===
match
---
name: self [27105,27109]
name: self [27100,27104]
===
match
---
if_stmt [19742,19826]
if_stmt [19737,19821]
===
match
---
name: models [24297,24303]
name: models [24292,24298]
===
match
---
simple_stmt [4558,4596]
simple_stmt [4558,4596]
===
match
---
operator: , [30334,30335]
operator: , [30329,30330]
===
match
---
operator: = [34540,34541]
operator: = [34535,34536]
===
match
---
trailer [34613,34627]
trailer [34608,34622]
===
match
---
testlist_comp [35926,35955]
testlist_comp [35921,35950]
===
match
---
trailer [8976,8980]
trailer [8976,8980]
===
match
---
string: '\n\nThese tasks have failed:\n' [29913,29945]
string: '\n\nThese tasks have failed:\n' [29908,29940]
===
match
---
arglist [38722,38802]
arglist [38717,38797]
===
match
---
name: SCHEDULED [37278,37287]
name: SCHEDULED [37273,37282]
===
match
---
atom_expr [22688,22713]
atom_expr [22683,22708]
===
match
---
atom_expr [25377,25404]
atom_expr [25372,25399]
===
match
---
name: log [11590,11593]
name: log [11585,11588]
===
match
---
simple_stmt [1647,1732]
simple_stmt [1647,1732]
===
match
---
name: utc [33143,33146]
name: utc [33138,33141]
===
match
---
name: self [33339,33343]
name: self [33334,33338]
===
match
---
trailer [35373,35407]
trailer [35368,35402]
===
match
---
name: update [26883,26889]
name: update [26878,26884]
===
match
---
atom_expr [36144,36206]
atom_expr [36139,36201]
===
match
---
trailer [9051,9058]
trailer [9051,9058]
===
match
---
trailer [28318,28326]
trailer [28313,28321]
===
match
---
name: State [8550,8555]
name: State [8550,8555]
===
match
---
atom [17400,17457]
atom [17395,17452]
===
match
---
name: all [37695,37698]
name: all [37690,37693]
===
match
---
trailer [11716,11740]
trailer [11711,11735]
===
match
---
operator: , [5272,5273]
operator: , [5272,5273]
===
match
---
operator: * [5504,5505]
operator: * [5504,5505]
===
match
---
expr_stmt [5004,5038]
expr_stmt [5004,5038]
===
match
---
atom_expr [25826,25853]
atom_expr [25821,25848]
===
match
---
operator: = [13772,13773]
operator: = [13767,13768]
===
match
---
trailer [23896,23926]
trailer [23891,23921]
===
match
---
simple_stmt [22853,22908]
simple_stmt [22848,22903]
===
match
---
suite [29305,29669]
suite [29300,29664]
===
match
---
name: failed [4746,4752]
name: failed [4746,4752]
===
match
---
name: dag_run [14334,14341]
name: dag_run [14329,14336]
===
match
---
name: provide_session [14276,14291]
name: provide_session [14271,14286]
===
match
---
name: executor [31834,31842]
name: executor [31829,31837]
===
match
---
atom_expr [24317,24326]
atom_expr [24312,24321]
===
match
---
name: self [31393,31397]
name: self [31388,31392]
===
match
---
trailer [9390,9398]
trailer [9390,9398]
===
match
---
simple_stmt [19655,19718]
simple_stmt [19650,19713]
===
match
---
trailer [24503,24520]
trailer [24498,24515]
===
match
---
name: not_ready [26601,26610]
name: not_ready [26596,26605]
===
match
---
operator: , [23647,23648]
operator: , [23642,23643]
===
match
---
operator: , [5398,5399]
operator: , [5398,5399]
===
match
---
trailer [38432,38437]
trailer [38427,38432]
===
match
---
if_stmt [20347,20431]
if_stmt [20342,20426]
===
match
---
atom [34020,34077]
atom [34015,34072]
===
match
---
name: state [18690,18695]
name: state [18685,18690]
===
match
---
name: ti [15225,15227]
name: ti [15220,15222]
===
match
---
argument [15299,15314]
argument [15294,15309]
===
match
---
atom_expr [28262,28343]
atom_expr [28257,28338]
===
match
---
trailer [38716,38721]
trailer [38711,38716]
===
match
---
name: pickle_id [35203,35212]
name: pickle_id [35198,35207]
===
match
---
name: executor [16338,16346]
name: executor [16333,16341]
===
match
---
name: session [27308,27315]
name: session [27303,27310]
===
match
---
atom_expr [28566,28582]
atom_expr [28561,28577]
===
match
---
simple_stmt [36289,36330]
simple_stmt [36284,36325]
===
match
---
trailer [33200,33209]
trailer [33195,33204]
===
match
---
operator: = [4292,4293]
operator: = [4292,4293]
===
match
---
raise_stmt [25887,26049]
raise_stmt [25882,26044]
===
match
---
name: filter_by_dag_run [37744,37761]
name: filter_by_dag_run [37739,37756]
===
match
---
name: configuration [1666,1679]
name: configuration [1666,1679]
===
match
---
name: ti [9034,9036]
name: ti [9034,9036]
===
match
---
operator: , [25606,25607]
operator: , [25601,25602]
===
match
---
argument [27127,27146]
argument [27122,27141]
===
match
---
operator: , [35171,35172]
operator: , [35166,35167]
===
match
---
name: task [24010,24014]
name: task [24005,24009]
===
match
---
name: key [37882,37885]
name: key [37877,37880]
===
match
---
name: dag_id [7118,7124]
name: dag_id [7118,7124]
===
match
---
name: run [27283,27286]
name: run [27278,27281]
===
match
---
param [32090,32095]
param [32085,32090]
===
match
---
name: run_backwards [7623,7636]
name: run_backwards [7623,7636]
===
match
---
trailer [19582,19588]
trailer [19577,19583]
===
match
---
simple_stmt [38615,38675]
simple_stmt [38610,38670]
===
match
---
trailer [23962,23966]
trailer [23957,23961]
===
match
---
trailer [10809,10815]
trailer [10804,10810]
===
match
---
fstring_string: Unknown pool:  [24422,24436]
fstring_string: Unknown pool:  [24417,24431]
===
match
---
trailer [37026,37035]
trailer [37021,37030]
===
match
---
trailer [33401,33409]
trailer [33396,33404]
===
match
---
name: State [19411,19416]
name: State [19406,19411]
===
match
---
expr_stmt [14718,14735]
expr_stmt [14713,14730]
===
match
---
operator: = [25716,25717]
operator: = [25711,25712]
===
match
---
expr_stmt [24256,24335]
expr_stmt [24251,24330]
===
match
---
name: dag_run [31383,31390]
name: dag_run [31378,31385]
===
match
---
trailer [19669,19717]
trailer [19664,19712]
===
match
---
expr_stmt [27196,27232]
expr_stmt [27191,27227]
===
match
---
simple_stmt [17945,18003]
simple_stmt [17940,17998]
===
match
---
operator: , [7718,7719]
operator: , [7718,7719]
===
match
---
suite [27364,27534]
suite [27359,27529]
===
match
---
decorated [32030,32583]
decorated [32025,32578]
===
match
---
name: ti [8939,8941]
name: ti [8939,8941]
===
match
---
atom_expr [16091,16115]
atom_expr [16086,16110]
===
match
---
simple_stmt [7100,7125]
simple_stmt [7100,7125]
===
match
---
trailer [10632,10640]
trailer [10627,10635]
===
match
---
simple_stmt [8126,8145]
simple_stmt [8126,8145]
===
match
---
name: dag [14063,14066]
name: dag [14058,14061]
===
match
---
name: _set_unfinished_dag_runs_to_failed [32055,32089]
name: _set_unfinished_dag_runs_to_failed [32050,32084]
===
match
---
atom_expr [10802,10942]
atom_expr [10797,10937]
===
match
---
param [32106,32118]
param [32101,32113]
===
match
---
atom_expr [22974,22999]
atom_expr [22969,22994]
===
match
---
operator: , [16077,16078]
operator: , [16072,16073]
===
match
---
name: task [24764,24768]
name: task [24759,24763]
===
match
---
trailer [18982,18987]
trailer [18977,18982]
===
match
---
operator: , [21017,21018]
operator: , [21012,21013]
===
match
---
name: runs [13094,13098]
name: runs [13089,13093]
===
match
---
trailer [8360,8362]
trailer [8360,8362]
===
match
---
name: ignore_task_deps [20954,20970]
name: ignore_task_deps [20949,20965]
===
match
---
name: ti [26098,26100]
name: ti [26093,26095]
===
match
---
name: running_tis [37139,37150]
name: running_tis [37134,37145]
===
match
---
comparison [8788,8813]
comparison [8788,8813]
===
match
---
string: " - waiting for other dag runs to finish" [35751,35792]
string: " - waiting for other dag runs to finish" [35746,35787]
===
match
---
name: end_date [5159,5167]
name: end_date [5159,5167]
===
match
---
param [16400,16413]
param [16395,16408]
===
match
---
trailer [9080,9084]
trailer [9080,9084]
===
match
---
trailer [9197,9205]
trailer [9197,9205]
===
match
---
name: tasks_that_depend_on_past [33371,33396]
name: tasks_that_depend_on_past [33366,33391]
===
match
---
name: ti [18489,18491]
name: ti [18484,18486]
===
match
---
name: task_id [33402,33409]
name: task_id [33397,33404]
===
match
---
name: UPSTREAM_FAILED [19613,19628]
name: UPSTREAM_FAILED [19608,19623]
===
match
---
trailer [20317,20322]
trailer [20312,20317]
===
match
---
expr_stmt [7645,7687]
expr_stmt [7645,7687]
===
match
---
decorator [32588,32605]
decorator [32583,32600]
===
match
---
name: RUNNING [13281,13288]
name: RUNNING [13276,13283]
===
match
---
atom_expr [7133,7151]
atom_expr [7133,7151]
===
match
---
name: donot_pickle [7270,7282]
name: donot_pickle [7270,7282]
===
match
---
if_stmt [8535,8773]
if_stmt [8535,8773]
===
match
---
operator: , [16115,16116]
operator: , [16110,16111]
===
match
---
atom_expr [2178,2190]
atom_expr [2178,2190]
===
match
---
trailer [25497,25755]
trailer [25492,25750]
===
match
---
name: run [14266,14269]
name: run [14261,14264]
===
match
---
if_stmt [20479,20750]
if_stmt [20474,20745]
===
match
---
name: log [18132,18135]
name: log [18127,18130]
===
match
---
operator: , [38580,38581]
operator: , [38575,38576]
===
match
---
name: models [1381,1387]
name: models [1381,1387]
===
match
---
trailer [32470,32476]
trailer [32465,32471]
===
match
---
name: DagRun [37556,37562]
name: DagRun [37551,37557]
===
match
---
name: Exception [15452,15461]
name: Exception [15447,15456]
===
match
---
name: airflow [1494,1501]
name: airflow [1494,1501]
===
match
---
trailer [10537,10544]
trailer [10532,10539]
===
match
---
name: time [35873,35877]
name: time [35868,35872]
===
match
---
operator: == [17488,17490]
operator: == [17483,17485]
===
match
---
parameters [5097,5534]
parameters [5097,5534]
===
match
---
atom_expr [37022,37048]
atom_expr [37017,37043]
===
match
---
operator: , [24933,24934]
operator: , [24928,24929]
===
match
---
name: finished_runs [5025,5038]
name: finished_runs [5025,5038]
===
match
---
funcdef [32609,36330]
funcdef [32604,36325]
===
match
---
trailer [22815,22831]
trailer [22810,22826]
===
match
---
operator: > [17423,17424]
operator: > [17418,17419]
===
match
---
trailer [33451,33467]
trailer [33446,33462]
===
match
---
name: reset_tis [38823,38832]
name: reset_tis [38818,38827]
===
match
---
trailer [16065,16076]
trailer [16060,16071]
===
match
---
trailer [27033,27052]
trailer [27028,27047]
===
match
---
simple_stmt [24593,24805]
simple_stmt [24588,24800]
===
match
---
operator: = [38104,38105]
operator: = [38099,38100]
===
match
---
param [14343,14355]
param [14338,14350]
===
match
---
trailer [34575,34577]
trailer [34570,34572]
===
match
---
name: ti [21462,21464]
name: ti [21457,21459]
===
match
---
trailer [21520,21524]
trailer [21515,21519]
===
match
---
trailer [15060,15069]
trailer [15055,15064]
===
match
---
trailer [8980,8993]
trailer [8980,8993]
===
match
---
operator: , [20110,20111]
operator: , [20105,20106]
===
match
---
expr_stmt [2197,2254]
expr_stmt [2197,2254]
===
match
---
trailer [35434,35450]
trailer [35429,35445]
===
match
---
trailer [19416,19426]
trailer [19411,19421]
===
match
---
name: TI [10751,10753]
name: TI [10746,10748]
===
match
---
argument [28070,28123]
argument [28065,28118]
===
match
---
name: _per_task_process [17873,17890]
name: _per_task_process [17868,17885]
===
match
---
name: key [20268,20271]
name: key [20263,20266]
===
match
---
parameters [30294,30372]
parameters [30289,30367]
===
match
---
name: filter_by_dag_run [14884,14901]
name: filter_by_dag_run [14879,14896]
===
match
---
trailer [33214,33226]
trailer [33209,33221]
===
match
---
trailer [32567,32573]
trailer [32562,32568]
===
match
---
arglist [35055,35293]
arglist [35050,35288]
===
match
---
param [5389,5399]
param [5389,5399]
===
match
---
operator: = [33249,33250]
operator: = [33244,33245]
===
match
---
trailer [22288,22301]
trailer [22283,22296]
===
match
---
name: task_id [28319,28326]
name: task_id [28314,28321]
===
match
---
atom_expr [35370,35407]
atom_expr [35365,35402]
===
match
---
trailer [24022,24026]
trailer [24017,24021]
===
match
---
name: models [1298,1304]
name: models [1298,1304]
===
match
---
atom_expr [18569,18586]
atom_expr [18564,18581]
===
match
---
name: State [1814,1819]
name: State [1814,1819]
===
match
---
atom_expr [29965,30003]
atom_expr [29960,29998]
===
match
---
simple_stmt [35424,35489]
simple_stmt [35419,35484]
===
match
---
arglist [28470,28535]
arglist [28465,28530]
===
match
---
name: refresh_from_db [17948,17963]
name: refresh_from_db [17943,17958]
===
match
---
name: DepContext [29106,29116]
name: DepContext [29101,29111]
===
match
---
number: 0 [13244,13245]
number: 0 [13239,13240]
===
match
---
trailer [9830,9834]
trailer [9825,9829]
===
match
---
atom_expr [24277,24288]
atom_expr [24272,24283]
===
match
---
simple_stmt [790,802]
simple_stmt [790,802]
===
match
---
if_stmt [31547,31596]
if_stmt [31542,31591]
===
match
---
trailer [9036,9042]
trailer [9036,9042]
===
match
---
name: current_active_dag_count [13546,13570]
name: current_active_dag_count [13541,13565]
===
match
---
operator: = [12937,12938]
operator: = [12932,12933]
===
match
---
expr_stmt [7602,7636]
expr_stmt [7602,7636]
===
match
---
operator: = [2160,2161]
operator: = [2160,2161]
===
match
---
simple_stmt [23943,23972]
simple_stmt [23938,23967]
===
match
---
name: result [38004,38010]
name: result [37999,38005]
===
match
---
decorator [17840,17857]
decorator [17835,17852]
===
match
---
name: ti [10643,10645]
name: ti [10638,10640]
===
match
---
simple_stmt [27385,27414]
simple_stmt [27380,27409]
===
match
---
trailer [31504,31530]
trailer [31499,31525]
===
match
---
trailer [9398,9438]
trailer [9398,9438]
===
match
---
trailer [33895,33899]
trailer [33890,33894]
===
match
---
name: jobs [1256,1260]
name: jobs [1256,1260]
===
match
---
comparison [19745,19769]
comparison [19740,19764]
===
match
---
name: values [10867,10873]
name: values [10862,10868]
===
match
---
comparison [11657,11695]
comparison [11652,11690]
===
match
---
if_stmt [13259,13343]
if_stmt [13254,13338]
===
match
---
name: query [38557,38562]
name: query [38552,38557]
===
match
---
or_test [13634,14010]
or_test [13629,14005]
===
match
---
suite [18360,18666]
suite [18355,18661]
===
match
---
name: Set [867,870]
name: Set [867,870]
===
match
---
trailer [37395,37401]
trailer [37390,37396]
===
match
---
if_stmt [18331,19445]
if_stmt [18326,19440]
===
match
---
trailer [28373,28380]
trailer [28368,28375]
===
match
---
trailer [28053,28124]
trailer [28048,28119]
===
match
---
simple_stmt [28647,28693]
simple_stmt [28642,28688]
===
match
---
name: State [8800,8805]
name: State [8800,8805]
===
match
---
operator: , [1707,1708]
operator: , [1707,1708]
===
match
---
name: ti_status [8220,8229]
name: ti_status [8220,8229]
===
match
---
name: topological_sort [24027,24043]
name: topological_sort [24022,24038]
===
match
---
operator: , [28276,28277]
operator: , [28271,28272]
===
match
---
atom_expr [28815,29262]
atom_expr [28810,29257]
===
match
---
atom_expr [34524,34539]
atom_expr [34519,34534]
===
match
---
name: pop [20422,20425]
name: pop [20417,20420]
===
match
---
operator: = [37845,37846]
operator: = [37840,37841]
===
match
---
atom_expr [15475,15493]
atom_expr [15470,15488]
===
match
---
name: run [27336,27339]
name: run [27331,27334]
===
match
---
operator: = [7386,7387]
operator: = [7386,7387]
===
match
---
if_stmt [8785,9019]
if_stmt [8785,9019]
===
match
---
try_stmt [34667,36280]
try_stmt [34662,36275]
===
match
---
simple_stmt [32997,33054]
simple_stmt [32992,33049]
===
match
---
argument [20865,20910]
argument [20860,20905]
===
match
---
name: err [35508,35511]
name: err [35503,35506]
===
match
---
name: log [22858,22861]
name: log [22853,22856]
===
match
---
name: reset_tis [38773,38782]
name: reset_tis [38768,38777]
===
match
---
name: session [14343,14350]
name: session [14338,14345]
===
match
---
operator: , [35292,35293]
operator: , [35287,35288]
===
match
---
name: run [13233,13236]
name: run [13228,13231]
===
match
---
name: key [24096,24099]
name: key [24091,24094]
===
match
---
trailer [11960,11987]
trailer [11955,11982]
===
match
---
arglist [38557,38604]
arglist [38552,38599]
===
match
---
atom_expr [24437,24446]
atom_expr [24432,24441]
===
match
---
trailer [24333,24335]
trailer [24328,24330]
===
match
---
operator: = [12677,12678]
operator: = [12672,12673]
===
match
---
argument [13113,13130]
argument [13108,13125]
===
match
---
name: executor [34491,34499]
name: executor [34486,34494]
===
match
---
trailer [14216,14233]
trailer [14211,14228]
===
match
---
name: session [20560,20567]
name: session [20555,20562]
===
match
---
argument [21223,21251]
argument [21218,21246]
===
match
---
trailer [4745,4752]
trailer [4745,4752]
===
match
---
name: update [31993,31999]
name: update [31988,31994]
===
match
---
name: QUEUED [2184,2190]
name: QUEUED [2184,2190]
===
match
---
operator: > [35610,35611]
operator: > [35605,35606]
===
match
---
name: ti_status [26933,26942]
name: ti_status [26928,26937]
===
match
---
trailer [17581,17591]
trailer [17576,17586]
===
match
---
operator: = [21671,21672]
operator: = [21666,21667]
===
match
---
name: pop [8731,8734]
name: pop [8731,8734]
===
match
---
trailer [35383,35406]
trailer [35378,35401]
===
match
---
trailer [7081,7085]
trailer [7081,7085]
===
match
---
atom_expr [23190,23208]
atom_expr [23185,23203]
===
match
---
trailer [27109,27126]
trailer [27104,27121]
===
match
---
or_test [4900,4917]
or_test [4900,4917]
===
match
---
comparison [24548,24563]
comparison [24543,24558]
===
match
---
param [15570,15579]
param [15565,15574]
===
match
---
simple_stmt [21710,21740]
simple_stmt [21705,21735]
===
match
---
atom_expr [8220,8246]
atom_expr [8220,8246]
===
match
---
trailer [8555,8563]
trailer [8555,8563]
===
match
---
or_test [4664,4680]
or_test [4664,4680]
===
match
---
atom_expr [19183,19191]
atom_expr [19178,19186]
===
match
---
trailer [13949,13962]
trailer [13944,13957]
===
match
---
argument [28278,28342]
argument [28273,28337]
===
match
---
name: tis_to_be_scheduled [8093,8112]
name: tis_to_be_scheduled [8093,8112]
===
match
---
name: mark_success [7214,7226]
name: mark_success [7214,7226]
===
match
---
atom [33399,33468]
atom [33394,33463]
===
match
---
suite [23346,23398]
suite [23341,23393]
===
match
---
name: session [31924,31931]
name: session [31919,31926]
===
match
---
trailer [22857,22861]
trailer [22852,22856]
===
match
---
comparison [37505,37534]
comparison [37500,37529]
===
match
---
name: ti [9629,9631]
name: ti [9629,9631]
===
match
---
atom_expr [15347,15360]
atom_expr [15342,15355]
===
match
---
atom [31336,31346]
atom [31331,31341]
===
match
---
param [5366,5380]
param [5366,5380]
===
match
---
name: dag [33424,33427]
name: dag [33419,33422]
===
match
---
name: debug [18790,18795]
name: debug [18785,18790]
===
match
---
name: ti_status [29875,29884]
name: ti_status [29870,29879]
===
match
---
simple_stmt [18659,18666]
simple_stmt [18654,18661]
===
match
---
name: flag_upstream_failed [20992,21012]
name: flag_upstream_failed [20987,21007]
===
match
---
comparison [19183,19205]
comparison [19178,19200]
===
match
---
name: total_runs [35357,35367]
name: total_runs [35352,35362]
===
match
---
name: ti [38383,38385]
name: ti [38378,38380]
===
match
---
atom_expr [29762,29781]
atom_expr [29757,29776]
===
match
---
not_test [33847,33873]
not_test [33842,33868]
===
match
---
name: dag_run [37451,37458]
name: dag_run [37446,37453]
===
match
---
simple_stmt [27618,27644]
simple_stmt [27613,27639]
===
match
---
arglist [29094,29184]
arglist [29089,29179]
===
match
---
atom_expr [24112,24136]
atom_expr [24107,24131]
===
match
---
operator: += [27409,27411]
operator: += [27404,27406]
===
match
---
param [4311,4326]
param [4311,4326]
===
match
---
comparison [34913,34977]
comparison [34908,34972]
===
match
---
trailer [26657,26675]
trailer [26652,26670]
===
match
---
trailer [15598,15603]
trailer [15593,15598]
===
match
---
operator: , [32094,32095]
operator: , [32089,32090]
===
match
---
atom_expr [7209,7226]
atom_expr [7209,7226]
===
match
---
name: DASK_EXECUTOR [34320,34333]
name: DASK_EXECUTOR [34315,34328]
===
match
---
name: reduced_key [9159,9170]
name: reduced_key [9159,9170]
===
match
---
trailer [22532,22537]
trailer [22527,22532]
===
match
---
name: dagrun_info [12150,12161]
name: dagrun_info [12145,12156]
===
match
---
trailer [13107,13112]
trailer [13102,13107]
===
match
---
simple_stmt [1243,1285]
simple_stmt [1243,1285]
===
match
---
expr_stmt [14166,14204]
expr_stmt [14161,14199]
===
match
---
name: self [4831,4835]
name: self [4831,4835]
===
match
---
operator: , [28010,28011]
operator: , [28005,28006]
===
match
---
name: finished_runs [27395,27408]
name: finished_runs [27390,27403]
===
match
---
name: donot_pickle [5210,5222]
name: donot_pickle [5210,5222]
===
match
---
expr_stmt [13233,13246]
expr_stmt [13228,13241]
===
match
---
name: sorted [27873,27879]
name: sorted [27868,27874]
===
match
---
expr_stmt [11172,11196]
expr_stmt [11167,11191]
===
match
---
name: include_subdags [18057,18072]
name: include_subdags [18052,18067]
===
match
---
name: key [23023,23026]
name: key [23018,23021]
===
match
---
string: """         :param dag: DAG object.         :type dag: airflow.models.DAG         :param start_date: start date for the backfill date range.         :type start_date: datetime.datetime         :param end_date: end date for the backfill date range.         :type end_date: datetime.datetime         :param mark_success: flag whether to mark the task auto success.         :type mark_success: bool         :param donot_pickle: whether pickle         :type donot_pickle: bool         :param ignore_first_depends_on_past: whether to ignore depend on past         :type ignore_first_depends_on_past: bool         :param ignore_task_deps: whether to ignore the task dependency         :type ignore_task_deps: bool         :param pool: pool to backfill         :type pool: str         :param delay_on_limit_secs:         :param verbose:         :type verbose: flag to whether display verbose message to backfill console         :param conf: a dictionary which user could pass k-v pairs for backfill         :type conf: dictionary         :param rerun_failed_tasks: flag to whether to                                    auto rerun the failed task in backfill         :type rerun_failed_tasks: bool         :param run_backwards: Whether to process the dates from most to least recent         :type run_backwards bool         :param run_at_least_once: If true, always run the DAG at least once even             if no logical run exists within the time range.         :type: bool         :param args:         :param kwargs:         """ [5544,7068]
string: """         :param dag: DAG object.         :type dag: airflow.models.DAG         :param start_date: start date for the backfill date range.         :type start_date: datetime.datetime         :param end_date: end date for the backfill date range.         :type end_date: datetime.datetime         :param mark_success: flag whether to mark the task auto success.         :type mark_success: bool         :param donot_pickle: whether pickle         :type donot_pickle: bool         :param ignore_first_depends_on_past: whether to ignore depend on past         :type ignore_first_depends_on_past: bool         :param ignore_task_deps: whether to ignore the task dependency         :type ignore_task_deps: bool         :param pool: pool to backfill         :type pool: str         :param delay_on_limit_secs:         :param verbose:         :type verbose: flag to whether display verbose message to backfill console         :param conf: a dictionary which user could pass k-v pairs for backfill         :type conf: dictionary         :param rerun_failed_tasks: flag to whether to                                    auto rerun the failed task in backfill         :type rerun_failed_tasks: bool         :param run_backwards: Whether to process the dates from most to least recent         :type run_backwards bool         :param run_at_least_once: If true, always run the DAG at least once even             if no logical run exists within the time range.         :type: bool         :param args:         :param kwargs:         """ [5544,7068]
===
match
---
trailer [25144,25161]
trailer [25139,25156]
===
match
---
operator: , [21268,21269]
operator: , [21263,21264]
===
match
---
name: debug [26231,26236]
name: debug [26226,26231]
===
match
---
simple_stmt [28546,28555]
simple_stmt [28541,28550]
===
match
---
operator: += [28742,28744]
operator: += [28737,28739]
===
match
---
suite [33874,33993]
suite [33869,33988]
===
match
---
operator: = [35345,35346]
operator: = [35340,35341]
===
match
---
operator: -> [28183,28185]
operator: -> [28178,28180]
===
match
---
comparison [18334,18359]
comparison [18329,18354]
===
match
---
trailer [9209,9222]
trailer [9209,9222]
===
match
---
trailer [33904,33969]
trailer [33899,33964]
===
match
---
operator: = [4345,4346]
operator: = [4345,4346]
===
match
---
atom_expr [31960,32024]
atom_expr [31955,32019]
===
match
---
trailer [26899,26906]
trailer [26894,26901]
===
match
---
operator: @ [32030,32031]
operator: @ [32025,32026]
===
match
---
comp_op [32477,32483]
comp_op [32472,32478]
===
match
---
operator: , [35255,35256]
operator: , [35250,35251]
===
match
---
name: run [13182,13185]
name: run [13177,13180]
===
match
---
name: running [27044,27051]
name: running [27039,27046]
===
match
---
trailer [36277,36279]
trailer [36272,36274]
===
match
---
name: failed [22938,22944]
name: failed [22933,22939]
===
match
---
name: info [11339,11343]
name: info [11334,11338]
===
match
---
name: items [38039,38044]
name: items [38034,38039]
===
match
---
param [5282,5305]
param [5282,5305]
===
match
---
name: mark_success [7229,7241]
name: mark_success [7229,7241]
===
match
---
operator: , [4407,4408]
operator: , [4407,4408]
===
match
---
name: max_active_tasks [25145,25161]
name: max_active_tasks [25140,25156]
===
match
---
string: "Task instance %s skipped. Don't rerun." [8897,8937]
string: "Task instance %s skipped. Don't rerun." [8897,8937]
===
match
---
suite [19630,19976]
suite [19625,19971]
===
match
---
trailer [15113,15132]
trailer [15108,15127]
===
match
---
trailer [27126,27147]
trailer [27121,27142]
===
match
---
expr_stmt [28249,28343]
expr_stmt [28244,28338]
===
match
---
comparison [10242,10264]
comparison [10237,10259]
===
match
---
simple_stmt [14718,14736]
simple_stmt [14713,14731]
===
match
---
atom_expr [37575,37598]
atom_expr [37570,37593]
===
match
---
simple_stmt [21516,21561]
simple_stmt [21511,21556]
===
match
---
name: State [37289,37294]
name: State [37284,37289]
===
match
---
name: _task_instances_for_dag_run [14300,14327]
name: _task_instances_for_dag_run [14295,14322]
===
match
---
trailer [23743,23747]
trailer [23738,23742]
===
match
---
trailer [38118,38133]
trailer [38113,38128]
===
match
---
name: State [15347,15352]
name: State [15342,15347]
===
match
---
name: airflow [1608,1615]
name: airflow [1608,1615]
===
match
---
trailer [13815,13823]
trailer [13810,13818]
===
match
---
name: deps [20818,20822]
name: deps [20813,20817]
===
match
---
name: dag_run [15106,15113]
name: dag_run [15101,15108]
===
match
---
name: pool [7418,7422]
name: pool [7418,7422]
===
match
---
name: ti [28328,28330]
name: ti [28323,28325]
===
match
---
simple_stmt [30182,30228]
simple_stmt [30177,30223]
===
match
---
simple_stmt [10282,10502]
simple_stmt [10277,10497]
===
match
---
name: executor [11282,11290]
name: executor [11277,11285]
===
match
---
atom_expr [37744,37822]
atom_expr [37739,37817]
===
match
---
trailer [7442,7462]
trailer [7442,7462]
===
match
---
name: self [35430,35434]
name: self [35425,35429]
===
match
---
name: err [29795,29798]
name: err [29790,29793]
===
match
---
atom_expr [33533,33755]
atom_expr [33528,33750]
===
match
---
name: not_ready [4788,4797]
name: not_ready [4788,4797]
===
match
---
name: dag [31424,31427]
name: dag [31419,31422]
===
match
---
argument [31924,31939]
argument [31919,31934]
===
match
---
operator: = [28077,28078]
operator: = [28072,28073]
===
match
---
trailer [37881,37885]
trailer [37876,37880]
===
match
---
arith_expr [31336,31365]
arith_expr [31331,31360]
===
match
---
trailer [18704,18712]
trailer [18699,18707]
===
match
---
name: self [19655,19659]
name: self [19650,19654]
===
match
---
for_stmt [24092,26102]
for_stmt [24087,26097]
===
match
---
operator: , [4245,4246]
operator: , [4245,4246]
===
match
---
operator: , [1082,1083]
operator: , [1082,1083]
===
match
---
name: set [4675,4678]
name: set [4675,4678]
===
match
---
trailer [34410,34418]
trailer [34405,34413]
===
match
---
atom_expr [23535,23558]
atom_expr [23530,23553]
===
match
---
suite [24138,26102]
suite [24133,26097]
===
match
---
trailer [24751,24774]
trailer [24746,24769]
===
match
---
atom [4915,4917]
atom [4915,4917]
===
match
---
trailer [8540,8546]
trailer [8540,8546]
===
match
---
dotted_name [1290,1304]
dotted_name [1290,1304]
===
match
---
name: self [23882,23886]
name: self [23877,23881]
===
match
---
name: OrderedDict [826,837]
name: OrderedDict [826,837]
===
match
---
trailer [38349,38351]
trailer [38344,38346]
===
match
---
operator: , [20970,20971]
operator: , [20965,20966]
===
match
---
name: session [31522,31529]
name: session [31517,31524]
===
match
---
simple_stmt [1327,1368]
simple_stmt [1327,1368]
===
match
---
name: dag [12816,12819]
name: dag [12811,12814]
===
match
---
operator: = [22470,22471]
operator: = [22465,22466]
===
match
---
name: state [20088,20093]
name: state [20083,20088]
===
match
---
name: State [32484,32489]
name: State [32479,32484]
===
match
---
atom_expr [17462,17487]
atom_expr [17457,17482]
===
match
---
trailer [8638,8642]
trailer [8638,8642]
===
match
---
atom_expr [38183,38351]
atom_expr [38178,38346]
===
match
---
name: tis_to_be_scheduled [10518,10537]
name: tis_to_be_scheduled [10513,10532]
===
match
---
arglist [28880,29012]
arglist [28875,29007]
===
match
---
suite [20375,20431]
suite [20370,20426]
===
match
---
name: State [32534,32539]
name: State [32529,32534]
===
match
---
expr_stmt [34587,34627]
expr_stmt [34582,34622]
===
match
---
name: TaskInstanceKey [27772,27787]
name: TaskInstanceKey [27767,27782]
===
match
---
name: executed_dag_run_dates [34955,34977]
name: executed_dag_run_dates [34950,34972]
===
match
---
operator: == [9043,9045]
operator: == [9043,9045]
===
match
---
name: debug [21389,21394]
name: debug [21384,21389]
===
match
---
comparison [11367,11385]
comparison [11362,11380]
===
match
---
trailer [30205,30227]
trailer [30200,30222]
===
match
---
name: _DagRunTaskStatus [2266,2283]
name: _DagRunTaskStatus [2266,2283]
===
match
---
string: "Task instance %s with state %s" [19670,19702]
string: "Task instance %s with state %s" [19665,19697]
===
match
---
if_stmt [8257,8363]
if_stmt [8257,8363]
===
match
---
name: tasks_that_depend_on_past [33484,33509]
name: tasks_that_depend_on_past [33479,33504]
===
match
---
name: ti [8788,8790]
name: ti [8788,8790]
===
match
---
trailer [24892,25070]
trailer [24887,25065]
===
match
---
suite [15248,15316]
suite [15243,15311]
===
match
---
atom_expr [23073,23099]
atom_expr [23068,23094]
===
match
---
argument [26268,26298]
argument [26263,26293]
===
match
---
name: dep_context [1459,1470]
name: dep_context [1459,1470]
===
match
---
name: ti [8508,8510]
name: ti [8508,8510]
===
match
---
trailer [22401,22418]
trailer [22396,22413]
===
match
---
operator: = [5222,5223]
operator: = [5222,5223]
===
match
---
name: ti_status [8959,8968]
name: ti_status [8959,8968]
===
match
---
name: dag [33261,33264]
name: dag [33256,33259]
===
match
---
string: "killed externally? Info: {}" [11924,11953]
string: "killed externally? Info: {}" [11919,11948]
===
match
---
name: key [23393,23396]
name: key [23388,23391]
===
match
---
name: run [27249,27252]
name: run [27244,27247]
===
match
---
atom_expr [18095,18102]
atom_expr [18090,18097]
===
match
---
testlist_comp [28079,28122]
testlist_comp [28074,28117]
===
match
---
simple_stmt [17287,17311]
simple_stmt [17282,17306]
===
match
---
name: refreshed_tis [8300,8313]
name: refreshed_tis [8300,8313]
===
match
---
string: "Not scheduling since there are " [24652,24685]
string: "Not scheduling since there are " [24647,24680]
===
match
---
name: self [31741,31745]
name: self [31736,31740]
===
match
---
name: self [21380,21384]
name: self [21375,21379]
===
match
---
simple_stmt [32866,32898]
simple_stmt [32861,32893]
===
match
---
name: state [27340,27345]
name: state [27335,27340]
===
match
---
name: session [34399,34406]
name: session [34394,34401]
===
match
---
name: err [30016,30019]
name: err [30011,30014]
===
match
---
operator: = [4847,4848]
operator: = [4847,4848]
===
match
---
trailer [19820,19825]
trailer [19815,19820]
===
match
---
name: self [7209,7213]
name: self [7209,7213]
===
match
---
atom_expr [7413,7422]
atom_expr [7413,7422]
===
match
---
name: format [11954,11960]
name: format [11949,11955]
===
match
---
name: get_dagrun [20549,20559]
name: get_dagrun [20544,20554]
===
match
---
trailer [9154,9158]
trailer [9154,9158]
===
match
---
name: ti [8538,8540]
name: ti [8538,8540]
===
match
---
name: self [4930,4934]
name: self [4930,4934]
===
match
---
trailer [8229,8237]
trailer [8229,8237]
===
match
---
atom_expr [7100,7111]
atom_expr [7100,7111]
===
match
---
name: self [30295,30299]
name: self [30290,30294]
===
match
---
parameters [32089,32119]
parameters [32084,32114]
===
match
---
trailer [38651,38654]
trailer [38646,38649]
===
match
---
name: ti [9838,9840]
name: ti [9833,9835]
===
match
---
decorator [16238,16255]
decorator [16233,16250]
===
match
---
name: executed_run_dates [27625,27643]
name: executed_run_dates [27620,27638]
===
match
---
string: "Task instance %s failed" [9091,9116]
string: "Task instance %s failed" [9091,9116]
===
match
---
simple_stmt [34106,34123]
simple_stmt [34101,34118]
===
match
---
name: ignore_first_depends_on_past [20487,20515]
name: ignore_first_depends_on_past [20482,20510]
===
match
---
comparison [24166,24192]
comparison [24161,24187]
===
match
---
comparison [37556,37598]
comparison [37551,37593]
===
match
---
trailer [11974,11980]
trailer [11969,11975]
===
match
---
simple_stmt [7291,7356]
simple_stmt [7291,7356]
===
match
---
name: _DagRunTaskStatus [32837,32854]
name: _DagRunTaskStatus [32832,32849]
===
match
---
name: dagrun_infos [34005,34017]
name: dagrun_infos [34000,34012]
===
match
---
name: tis_to_be_scheduled [10769,10788]
name: tis_to_be_scheduled [10764,10783]
===
match
---
simple_stmt [33768,33802]
simple_stmt [33763,33797]
===
match
---
param [32628,32640]
param [32623,32635]
===
match
---
operator: , [16412,16413]
operator: , [16407,16408]
===
match
---
expr_stmt [8180,8248]
expr_stmt [8180,8248]
===
match
---
name: self [7645,7649]
name: self [7645,7649]
===
match
---
simple_stmt [30068,30115]
simple_stmt [30063,30110]
===
match
---
atom_expr [2163,2176]
atom_expr [2163,2176]
===
match
---
trailer [15984,16002]
trailer [15979,15997]
===
match
---
simple_stmt [24830,25071]
simple_stmt [24825,25066]
===
match
---
name: run_backwards [5442,5455]
name: run_backwards [5442,5455]
===
match
---
expr_stmt [33103,33147]
expr_stmt [33098,33142]
===
match
---
trailer [23427,23434]
trailer [23422,23429]
===
match
---
argument [35234,35255]
argument [35229,35250]
===
match
---
trailer [31992,31999]
trailer [31987,31994]
===
match
---
trailer [11589,11593]
trailer [11584,11588]
===
match
---
operator: = [35284,35285]
operator: = [35279,35280]
===
match
---
name: _get_dag_run [31398,31410]
name: _get_dag_run [31393,31405]
===
match
---
name: warning [9391,9398]
name: warning [9391,9398]
===
match
---
operator: >= [13571,13573]
operator: >= [13566,13568]
===
match
---
trailer [25830,25853]
trailer [25825,25848]
===
match
---
operator: , [18487,18488]
operator: , [18482,18483]
===
match
---
trailer [29176,29184]
trailer [29171,29179]
===
match
---
atom [25592,25606]
atom [25587,25601]
===
match
---
suite [15135,15408]
suite [15130,15403]
===
match
---
name: ti_status [16095,16104]
name: ti_status [16090,16099]
===
match
---
name: session [8316,8323]
name: session [8316,8323]
===
match
---
funcdef [12127,14270]
funcdef [12122,14265]
===
match
---
trailer [28469,28536]
trailer [28464,28531]
===
match
---
operator: , [19702,19703]
operator: , [19697,19698]
===
match
---
name: err [28596,28599]
name: err [28591,28594]
===
match
---
atom_expr [11700,11708]
atom_expr [11695,11703]
===
match
---
atom_expr [37370,37700]
atom_expr [37365,37695]
===
match
---
name: run [13634,13637]
name: run [13629,13632]
===
match
---
simple_stmt [21823,21841]
simple_stmt [21818,21836]
===
match
---
operator: , [15858,15859]
operator: , [15853,15854]
===
match
---
operator: , [36395,36396]
operator: , [36390,36391]
===
match
---
expr_stmt [11332,11351]
expr_stmt [11327,11346]
===
match
---
trailer [20548,20559]
trailer [20543,20554]
===
match
---
name: ti_status [27137,27146]
name: ti_status [27132,27141]
===
match
---
name: reduced_key [8605,8616]
name: reduced_key [8605,8616]
===
match
---
trailer [22948,22953]
trailer [22943,22948]
===
match
---
name: join [33684,33688]
name: join [33679,33683]
===
match
---
name: update_state [32433,32445]
name: update_state [32428,32440]
===
match
---
argument [31514,31529]
argument [31509,31524]
===
match
---
trailer [38196,38210]
trailer [38191,38205]
===
match
---
not_test [12842,12859]
not_test [12837,12854]
===
match
---
name: pickle [34358,34364]
name: pickle [34353,34359]
===
match
---
name: running [18971,18978]
name: running [18966,18973]
===
match
---
atom_expr [8634,8696]
atom_expr [8634,8696]
===
match
---
name: debug [16145,16150]
name: debug [16140,16145]
===
match
---
name: dagrun_start_date [34041,34058]
name: dagrun_start_date [34036,34053]
===
match
---
expr_stmt [20597,20676]
expr_stmt [20592,20671]
===
match
---
name: session [35277,35284]
name: session [35272,35279]
===
match
---
atom_expr [22798,22806]
atom_expr [22793,22801]
===
match
---
atom_expr [33210,33226]
atom_expr [33205,33221]
===
match
---
name: dag [7114,7117]
name: dag [7114,7117]
===
match
---
param [30301,30314]
param [30296,30309]
===
match
---
name: self [36144,36148]
name: self [36139,36143]
===
match
---
name: DAG [24866,24869]
name: DAG [24861,24864]
===
match
---
atom_expr [18127,18191]
atom_expr [18122,18186]
===
match
---
if_stmt [33062,33228]
if_stmt [33057,33223]
===
match
---
name: resettable_states [38274,38291]
name: resettable_states [38269,38286]
===
match
---
name: run [13262,13265]
name: run [13257,13260]
===
match
---
operator: = [9836,9837]
operator: = [9831,9832]
===
match
---
trailer [31683,31690]
trailer [31678,31685]
===
match
---
arglist [17359,17383]
arglist [17354,17378]
===
match
---
trailer [38227,38234]
trailer [38222,38229]
===
match
---
operator: = [4432,4433]
operator: = [4432,4433]
===
match
---
operator: = [7086,7087]
operator: = [7086,7087]
===
match
---
operator: , [35132,35133]
operator: , [35127,35128]
===
match
---
arglist [9091,9120]
arglist [9091,9120]
===
match
---
name: SUCCESS [11687,11694]
name: SUCCESS [11682,11689]
===
match
---
trailer [8805,8813]
trailer [8805,8813]
===
match
---
trailer [22645,22653]
trailer [22640,22648]
===
match
---
atom_expr [28394,28403]
atom_expr [28389,28398]
===
match
---
name: dagrun_infos [34614,34626]
name: dagrun_infos [34609,34621]
===
match
---
and_test [12816,12859]
and_test [12811,12854]
===
match
---
simple_stmt [28738,28774]
simple_stmt [28733,28769]
===
match
---
comparison [13546,13593]
comparison [13541,13588]
===
match
---
name: ti_status [18612,18621]
name: ti_status [18607,18616]
===
match
---
return_stmt [14259,14269]
return_stmt [14254,14264]
===
match
---
suite [15083,15437]
suite [15078,15432]
===
match
---
name: state [18337,18342]
name: state [18332,18337]
===
match
---
name: ti_status [35123,35132]
name: ti_status [35118,35127]
===
match
---
string: "Backfill terminated by user." [35987,36017]
string: "Backfill terminated by user." [35982,36012]
===
match
---
atom_expr [23580,23652]
atom_expr [23575,23647]
===
match
---
name: _execute_dagruns [30278,30294]
name: _execute_dagruns [30273,30289]
===
match
---
expr_stmt [7100,7124]
expr_stmt [7100,7124]
===
match
---
trailer [11407,11411]
trailer [11402,11406]
===
match
---
name: state [21665,21670]
name: state [21660,21665]
===
match
---
atom_expr [25538,25549]
atom_expr [25533,25544]
===
match
---
atom_expr [26696,26718]
atom_expr [26691,26713]
===
match
---
simple_stmt [22771,22778]
simple_stmt [22766,22773]
===
match
---
name: provide_session [1766,1781]
name: provide_session [1766,1781]
===
match
---
atom_expr [34161,34180]
atom_expr [34156,34175]
===
match
---
trailer [18882,18887]
trailer [18877,18882]
===
match
---
atom_expr [38769,38783]
atom_expr [38764,38778]
===
match
---
trailer [17510,17514]
trailer [17505,17509]
===
match
---
trailer [24744,24751]
trailer [24739,24746]
===
match
---
trailer [23594,23652]
trailer [23589,23647]
===
match
---
name: are_dependencies_met [28838,28858]
name: are_dependencies_met [28833,28853]
===
match
---
name: airflow [1332,1339]
name: airflow [1332,1339]
===
match
---
name: self [27006,27010]
name: self [27001,27005]
===
match
---
trailer [8648,8696]
trailer [8648,8696]
===
match
---
name: delay_on_limit_secs [35889,35908]
name: delay_on_limit_secs [35884,35903]
===
match
---
atom_expr [28892,28932]
atom_expr [28887,28927]
===
match
---
name: active_runs [36194,36205]
name: active_runs [36189,36200]
===
match
---
name: ti [38468,38470]
name: ti [38463,38465]
===
match
---
name: not_ready [16105,16114]
name: not_ready [16100,16109]
===
match
---
name: e [26203,26204]
name: e [26198,26199]
===
match
---
trailer [19761,19769]
trailer [19756,19764]
===
match
---
trailer [34924,34937]
trailer [34919,34932]
===
match
---
argument [17986,18001]
argument [17981,17996]
===
match
---
name: running [37167,37174]
name: running [37162,37169]
===
match
---
name: run [14213,14216]
name: run [14208,14211]
===
match
---
decorator [7735,7752]
decorator [7735,7752]
===
match
---
name: commit [34439,34445]
name: commit [34434,34440]
===
match
---
trailer [4678,4680]
trailer [4678,4680]
===
match
---
atom_expr [15269,15315]
atom_expr [15264,15310]
===
match
---
string: 'the command line.' [29631,29650]
string: 'the command line.' [29626,29645]
===
match
---
operator: = [31931,31932]
operator: = [31926,31927]
===
match
---
atom_expr [4558,4569]
atom_expr [4558,4569]
===
match
---
name: ti [19580,19582]
name: ti [19575,19577]
===
match
---
name: state [19583,19588]
name: state [19578,19583]
===
match
---
atom_expr [9455,9489]
atom_expr [9455,9489]
===
match
---
trailer [20313,20317]
trailer [20308,20312]
===
match
---
name: tis_to_reset [37950,37962]
name: tis_to_reset [37945,37957]
===
match
---
name: self [20949,20953]
name: self [20944,20948]
===
match
---
name: dag [24023,24026]
name: dag [24018,24021]
===
match
---
name: error [12090,12095]
name: error [12085,12090]
===
match
---
name: ti_status [31802,31811]
name: ti_status [31797,31806]
===
match
---
trailer [7528,7533]
trailer [7528,7533]
===
match
---
simple_stmt [838,871]
simple_stmt [838,871]
===
match
---
name: id [13997,13999]
name: id [13992,13994]
===
match
---
name: ignore_depends_on_past [29117,29139]
name: ignore_depends_on_past [29112,29134]
===
match
---
atom_expr [19929,19975]
atom_expr [19924,19970]
===
match
---
atom_expr [28294,28303]
atom_expr [28289,28298]
===
match
---
comparison [9034,9058]
comparison [9034,9058]
===
match
---
name: ti_key [27992,27998]
name: ti_key [27987,27993]
===
match
---
name: running [19809,19816]
name: running [19804,19811]
===
match
---
name: reduced_key [8494,8505]
name: reduced_key [8494,8505]
===
match
---
funcdef [4190,5080]
funcdef [4190,5080]
===
match
---
name: ti [21557,21559]
name: ti [21552,21554]
===
match
---
name: models [24277,24283]
name: models [24272,24278]
===
match
---
name: pop [9206,9209]
name: pop [9206,9209]
===
match
---
trailer [30105,30113]
trailer [30100,30108]
===
match
---
trailer [25474,25497]
trailer [25469,25492]
===
match
---
dotted_name [1373,1400]
dotted_name [1373,1400]
===
match
---
name: set_tis [28155,28162]
name: set_tis [28150,28157]
===
match
---
trailer [25542,25549]
trailer [25537,25544]
===
match
---
trailer [20215,20221]
trailer [20210,20216]
===
match
---
name: self [20482,20486]
name: self [20477,20481]
===
match
---
name: ti [23442,23444]
name: ti [23437,23439]
===
match
---
atom_expr [27034,27051]
atom_expr [27029,27046]
===
match
---
trailer [10286,10290]
trailer [10281,10285]
===
match
---
string: 'of "depends_on_past" relationships. Try running the ' [29430,29484]
string: 'of "depends_on_past" relationships. Try running the ' [29425,29479]
===
match
---
trailer [22741,22748]
trailer [22736,22743]
===
match
---
import_from [947,976]
import_from [947,976]
===
match
---
string: 'BackfillJob' [2240,2253]
string: 'BackfillJob' [2240,2253]
===
match
---
operator: = [33015,33016]
operator: = [33010,33011]
===
match
---
trailer [18871,18878]
trailer [18866,18873]
===
match
---
argument [21253,21268]
argument [21248,21263]
===
match
---
argument [7720,7728]
argument [7720,7728]
===
match
---
suite [14764,14797]
suite [14759,14792]
===
match
---
trailer [16229,16231]
trailer [16224,16226]
===
match
---
trailer [34319,34333]
trailer [34314,34328]
===
match
---
name: TaskConcurrencyLimitReached [1163,1190]
name: TaskConcurrencyLimitReached [1163,1190]
===
match
---
atom_expr [35347,35367]
atom_expr [35342,35362]
===
match
---
name: find [13108,13112]
name: find [13103,13107]
===
match
---
comparison [33065,33089]
comparison [33060,33084]
===
match
---
atom_expr [23882,23926]
atom_expr [23877,23921]
===
match
---
operator: = [10749,10750]
operator: = [10744,10745]
===
match
---
atom_expr [30075,30114]
atom_expr [30070,30109]
===
match
---
name: bool [12811,12815]
name: bool [12806,12810]
===
match
---
name: session [35480,35487]
name: session [35475,35482]
===
match
---
comparison [18911,18935]
comparison [18906,18930]
===
match
---
trailer [4866,4868]
trailer [4866,4868]
===
match
---
atom_expr [8316,8362]
atom_expr [8316,8362]
===
match
---
simple_stmt [7696,7730]
simple_stmt [7696,7730]
===
match
---
simple_stmt [28786,29263]
simple_stmt [28781,29258]
===
match
---
name: key [19821,19824]
name: key [19816,19819]
===
match
---
atom_expr [26819,26844]
atom_expr [26814,26839]
===
match
---
name: key [23790,23793]
name: key [23785,23788]
===
match
---
name: active_runs [27218,27229]
name: active_runs [27213,27224]
===
match
---
operator: , [28380,28381]
operator: , [28375,28376]
===
match
---
atom_expr [5051,5066]
atom_expr [5051,5066]
===
match
---
operator: , [35943,35944]
operator: , [35938,35939]
===
match
---
atom_expr [9641,9664]
atom_expr [9641,9664]
===
match
---
operator: = [21277,21278]
operator: = [21272,21273]
===
match
---
operator: == [8547,8549]
operator: == [8547,8549]
===
match
---
operator: = [20784,20785]
operator: = [20779,20780]
===
match
---
simple_stmt [27547,27577]
simple_stmt [27542,27572]
===
match
---
arglist [19670,19716]
arglist [19665,19711]
===
match
---
operator: = [29105,29106]
operator: = [29100,29101]
===
match
---
if_stmt [33844,33993]
if_stmt [33839,33988]
===
match
---
trailer [26871,26882]
trailer [26866,26877]
===
match
---
name: _process_backfill_task_instances [31746,31778]
name: _process_backfill_task_instances [31741,31773]
===
match
---
name: dag_id [28374,28380]
name: dag_id [28369,28375]
===
match
---
trailer [29072,29202]
trailer [29067,29197]
===
match
---
name: values [11473,11479]
name: values [11468,11474]
===
match
---
name: ti [17896,17898]
name: ti [17891,17893]
===
match
---
atom_expr [19799,19825]
atom_expr [19794,19820]
===
match
---
name: executor [11172,11180]
name: executor [11167,11175]
===
match
---
name: _update_counters [27110,27126]
name: _update_counters [27105,27121]
===
match
---
name: State [10254,10259]
name: State [10249,10254]
===
match
---
argument [24044,24069]
argument [24039,24064]
===
match
---
atom_expr [25197,25348]
atom_expr [25192,25343]
===
match
---
name: DagPickle [1317,1326]
name: DagPickle [1317,1326]
===
match
---
name: current_active_dag_count [12870,12894]
name: current_active_dag_count [12865,12889]
===
match
---
trailer [2168,2176]
trailer [2168,2176]
===
match
---
name: ti_status [35374,35383]
name: ti_status [35369,35378]
===
match
---
simple_stmt [34460,34482]
simple_stmt [34455,34477]
===
match
---
suite [8396,10646]
suite [8396,10641]
===
match
---
name: ti_status [22974,22983]
name: ti_status [22969,22978]
===
match
---
param [5134,5150]
param [5134,5150]
===
match
---
if_stmt [21906,22156]
if_stmt [21901,22151]
===
match
---
name: State [22810,22815]
name: State [22805,22810]
===
match
---
name: err [29906,29909]
name: err [29901,29904]
===
match
---
name: dagrun_infos [33783,33795]
name: dagrun_infos [33778,33790]
===
match
---
funcdef [36356,38834]
funcdef [36351,38829]
===
match
---
for_stmt [27245,27534]
for_stmt [27240,27529]
===
match
---
trailer [35450,35488]
trailer [35445,35483]
===
match
---
name: QUEUED [21679,21685]
name: QUEUED [21674,21680]
===
match
---
name: warning [10291,10298]
name: warning [10286,10293]
===
match
---
name: log [15595,15598]
name: log [15590,15593]
===
match
---
atom_expr [8713,8747]
atom_expr [8713,8747]
===
match
---
expr_stmt [7209,7241]
expr_stmt [7209,7241]
===
match
---
trailer [26640,26650]
trailer [26635,26645]
===
match
---
trailer [26667,26674]
trailer [26662,26669]
===
match
---
name: State [23190,23195]
name: State [23185,23190]
===
match
---
trailer [4835,4846]
trailer [4835,4846]
===
match
---
arglist [37505,37662]
arglist [37500,37657]
===
match
---
expr_stmt [13628,14010]
expr_stmt [13623,14005]
===
match
---
name: pendulum [33192,33200]
name: pendulum [33187,33195]
===
match
---
name: self [34139,34143]
name: self [34134,34138]
===
match
---
atom_expr [19752,19769]
atom_expr [19747,19764]
===
match
---
name: session [38683,38690]
name: session [38678,38685]
===
match
---
trailer [20486,20515]
trailer [20481,20510]
===
match
---
name: running_tis [37922,37933]
name: running_tis [37917,37928]
===
match
---
expr_stmt [38089,38140]
expr_stmt [38084,38135]
===
match
---
name: values [16223,16229]
name: values [16218,16224]
===
match
---
name: filter_for_tis [8180,8194]
name: filter_for_tis [8180,8194]
===
match
---
name: to_run [4563,4569]
name: to_run [4563,4569]
===
match
---
string: 'backfill with the option ' [29505,29532]
string: 'backfill with the option ' [29500,29527]
===
match
---
simple_stmt [29847,29894]
simple_stmt [29842,29889]
===
match
---
trailer [27217,27229]
trailer [27212,27224]
===
match
---
name: ti [21837,21839]
name: ti [21832,21834]
===
match
---
name: session [21261,21268]
name: session [21256,21263]
===
match
---
name: DagConcurrencyLimitReached [25197,25223]
name: DagConcurrencyLimitReached [25192,25218]
===
match
---
operator: == [37518,37520]
operator: == [37513,37515]
===
match
---
name: provide_session [32031,32046]
name: provide_session [32026,32041]
===
match
---
name: executor_constants [22025,22043]
name: executor_constants [22020,22038]
===
match
---
operator: <= [24559,24561]
operator: <= [24554,24556]
===
match
---
name: OrderedDict [4582,4593]
name: OrderedDict [4582,4593]
===
match
---
trailer [21394,21465]
trailer [21389,21460]
===
match
---
operator: = [15403,15404]
operator: = [15398,15399]
===
match
---
name: data_interval [13735,13748]
name: data_interval [13730,13743]
===
match
---
name: err [35424,35427]
name: err [35419,35422]
===
match
---
name: donot_pickle [7255,7267]
name: donot_pickle [7255,7267]
===
match
---
trailer [8199,8214]
trailer [8199,8214]
===
match
---
atom_expr [38819,38833]
atom_expr [38814,38828]
===
match
---
trailer [21180,21201]
trailer [21175,21196]
===
match
---
name: State [37521,37526]
name: State [37516,37521]
===
match
---
dictorsetmaker [2216,2253]
dictorsetmaker [2216,2253]
===
match
---
trailer [28684,28691]
trailer [28679,28686]
===
match
---
atom_expr [32560,32582]
atom_expr [32555,32577]
===
match
---
atom_expr [34021,34076]
atom_expr [34016,34071]
===
match
---
name: ti_status [19799,19808]
name: ti_status [19794,19803]
===
match
---
argument [12921,12943]
argument [12916,12938]
===
match
---
operator: , [1114,1115]
operator: , [1114,1115]
===
match
---
name: ti [23178,23180]
name: ti [23173,23175]
===
match
---
atom_expr [8882,8942]
atom_expr [8882,8942]
===
match
---
name: state [8541,8546]
name: state [8541,8546]
===
match
---
operator: , [20910,20911]
operator: , [20905,20906]
===
match
---
comp_op [11371,11377]
comp_op [11366,11372]
===
match
---
param [27690,27695]
param [27685,27690]
===
match
---
name: ti_status [8581,8590]
name: ti_status [8581,8590]
===
match
---
trailer [29003,29011]
trailer [28998,29006]
===
match
---
trailer [9777,9781]
trailer [9777,9781]
===
match
---
param [16375,16391]
param [16370,16386]
===
match
---
name: task [25826,25830]
name: task [25821,25825]
===
match
---
trailer [8642,8648]
trailer [8642,8648]
===
match
---
operator: * [7713,7714]
operator: * [7713,7714]
===
match
---
arglist [18045,18077]
arglist [18040,18072]
===
match
---
atom_expr [19708,19716]
atom_expr [19703,19711]
===
match
---
tfpdef [12185,12201]
tfpdef [12180,12196]
===
match
---
trailer [35643,35648]
trailer [35638,35643]
===
match
---
operator: , [22063,22064]
operator: , [22058,22059]
===
match
---
name: ti [9118,9120]
name: ti [9118,9120]
===
match
---
except_clause [35918,35956]
except_clause [35913,35951]
===
match
---
arglist [11961,11986]
arglist [11956,11981]
===
match
---
atom [35925,35956]
atom [35920,35951]
===
match
---
name: in_ [37639,37642]
name: in_ [37634,37637]
===
match
---
name: dag_run [15061,15068]
name: dag_run [15056,15063]
===
match
---
atom_expr [19398,19444]
atom_expr [19393,19439]
===
match
---
name: to_run [24122,24128]
name: to_run [24117,24123]
===
match
---
name: self [31337,31341]
name: self [31332,31336]
===
match
---
lambdef [28282,28342]
lambdef [28277,28337]
===
match
---
simple_stmt [1285,1327]
simple_stmt [1285,1327]
===
match
---
operator: = [13373,13374]
operator: = [13368,13369]
===
match
---
name: self [7100,7104]
name: self [7100,7104]
===
match
---
number: 0 [35612,35613]
number: 0 [35607,35608]
===
match
---
trailer [9698,9743]
trailer [9698,9743]
===
match
---
operator: = [4240,4241]
operator: = [4240,4241]
===
match
---
name: state [13804,13809]
name: state [13799,13804]
===
match
---
operator: == [10251,10253]
operator: == [10246,10248]
===
match
---
trailer [24618,24804]
trailer [24613,24799]
===
match
---
trailer [11411,11419]
trailer [11406,11414]
===
match
---
name: NONE [15243,15247]
name: NONE [15238,15242]
===
match
---
name: FAILED [9052,9058]
name: FAILED [9052,9058]
===
match
---
string: "No run dates were found for the given dates and dag interval." [33905,33968]
string: "No run dates were found for the given dates and dag interval." [33900,33963]
===
match
---
name: get_task_instances [15114,15132]
name: get_task_instances [15109,15127]
===
match
---
simple_stmt [11551,11572]
simple_stmt [11546,11567]
===
match
---
simple_stmt [36265,36280]
simple_stmt [36260,36275]
===
match
---
suite [15581,16233]
suite [15576,16228]
===
match
---
simple_stmt [38683,38699]
simple_stmt [38678,38694]
===
match
---
comparison [31550,31565]
comparison [31545,31560]
===
match
---
trailer [33041,33053]
trailer [33036,33048]
===
match
---
name: ti_status [34702,34711]
name: ti_status [34697,34706]
===
match
---
name: executors [1207,1216]
name: executors [1207,1216]
===
match
---
atom_expr [28836,29030]
atom_expr [28831,29025]
===
match
---
name: max_active_tis_per_dag [25382,25404]
name: max_active_tis_per_dag [25377,25399]
===
match
---
name: ti_status [30096,30105]
name: ti_status [30091,30100]
===
match
---
operator: = [32635,32636]
operator: = [32630,32631]
===
match
---
name: self [8634,8638]
name: self [8634,8638]
===
match
---
name: executor_constants [34301,34319]
name: executor_constants [34296,34314]
===
match
---
name: key [18634,18637]
name: key [18629,18632]
===
match
---
name: ti_status [22928,22937]
name: ti_status [22923,22932]
===
match
---
trailer [16222,16229]
trailer [16217,16224]
===
match
---
trailer [9690,9698]
trailer [9690,9698]
===
match
---
name: dagrun [20537,20543]
name: dagrun [20532,20538]
===
match
---
except_clause [26114,26204]
except_clause [26109,26199]
===
match
---
if_stmt [13510,13619]
if_stmt [13505,13614]
===
match
---
simple_stmt [31587,31596]
simple_stmt [31582,31591]
===
match
---
name: task_dict [33428,33437]
name: task_dict [33423,33432]
===
match
---
name: self [38708,38712]
name: self [38703,38707]
===
match
---
name: tmp_configuration_copy [1709,1731]
name: tmp_configuration_copy [1709,1731]
===
match
---
name: get_task [18036,18044]
name: get_task [18031,18039]
===
match
---
atom [20097,20134]
atom [20092,20129]
===
match
---
name: key [9526,9529]
name: key [9526,9529]
===
match
---
trailer [18927,18935]
trailer [18922,18930]
===
match
---
operator: = [8156,8157]
operator: = [8156,8157]
===
match
---
name: orm [904,907]
name: orm [904,907]
===
match
---
name: SCHEDULED [15288,15297]
name: SCHEDULED [15283,15292]
===
match
---
expr_stmt [28786,29262]
expr_stmt [28781,29257]
===
match
---
arglist [7713,7728]
arglist [7713,7728]
===
match
---
operator: , [15824,15825]
operator: , [15819,15820]
===
match
---
name: dag_id [7105,7111]
name: dag_id [7105,7111]
===
match
---
sync_comp_for [34858,34977]
sync_comp_for [34853,34972]
===
match
---
suite [23559,23827]
suite [23554,23822]
===
match
---
name: pool [24256,24260]
name: pool [24251,24255]
===
match
---
suite [28725,30228]
suite [28720,30223]
===
match
---
name: DagRunInfo [12163,12173]
name: DagRunInfo [12158,12168]
===
match
---
operator: = [32823,32824]
operator: = [32818,32819]
===
match
---
trailer [33209,33227]
trailer [33204,33222]
===
match
---
name: self [9682,9686]
name: self [9682,9686]
===
match
---
operator: = [34802,34803]
operator: = [34797,34798]
===
match
---
trailer [12030,12036]
trailer [12025,12031]
===
match
---
expr_stmt [38615,38674]
expr_stmt [38610,38669]
===
match
---
operator: , [16309,16310]
operator: , [16304,16305]
===
match
---
name: queued_by_job_id [21713,21729]
name: queued_by_job_id [21708,21724]
===
match
---
param [12144,12149]
param [12139,12144]
===
match
---
atom_expr [36236,36252]
atom_expr [36231,36247]
===
match
---
name: self [33851,33855]
name: self [33846,33850]
===
match
---
dotted_name [1010,1028]
dotted_name [1010,1028]
===
match
---
atom_expr [13239,13246]
atom_expr [13234,13241]
===
match
---
trailer [8333,8340]
trailer [8333,8340]
===
match
---
name: ignore_task_deps [20932,20948]
name: ignore_task_deps [20927,20943]
===
match
---
parameters [15563,15580]
parameters [15558,15575]
===
match
---
name: queued_tis [37009,37019]
name: queued_tis [37004,37014]
===
match
---
atom_expr [9034,9042]
atom_expr [9034,9042]
===
match
---
name: ti_status [35451,35460]
name: ti_status [35446,35455]
===
match
---
name: TI [8330,8332]
name: TI [8330,8332]
===
match
---
name: timezone [1638,1646]
name: timezone [1638,1646]
===
match
---
comparison [34161,34344]
comparison [34156,34339]
===
match
---
name: dag_id [27968,27974]
name: dag_id [27963,27969]
===
match
---
trailer [20267,20272]
trailer [20262,20267]
===
match
---
atom_expr [10254,10264]
atom_expr [10249,10259]
===
match
---
trailer [28384,28392]
trailer [28379,28387]
===
match
---
name: set_tis [28269,28276]
name: set_tis [28264,28271]
===
match
---
import_as_names [1408,1437]
import_as_names [1408,1437]
===
match
---
trailer [23380,23388]
trailer [23375,23383]
===
match
---
name: task [24317,24321]
name: task [24312,24316]
===
match
---
trailer [15394,15402]
trailer [15389,15397]
===
match
---
suite [30373,32025]
suite [30368,32020]
===
match
---
operator: = [5023,5024]
operator: = [5023,5024]
===
match
---
name: State [27349,27354]
name: State [27344,27349]
===
match
---
trailer [32854,32856]
trailer [32849,32851]
===
match
---
atom_expr [32879,32897]
atom_expr [32874,32892]
===
match
---
trailer [37585,37598]
trailer [37580,37593]
===
match
---
name: state [10245,10250]
name: state [10240,10245]
===
match
---
simple_stmt [18781,18842]
simple_stmt [18776,18837]
===
match
---
operator: = [7423,7424]
operator: = [7423,7424]
===
match
---
trailer [15227,15233]
trailer [15222,15228]
===
match
---
name: open_slots [24493,24503]
name: open_slots [24488,24498]
===
match
---
expr_stmt [8494,8522]
expr_stmt [8494,8522]
===
match
---
decorated [30253,32025]
decorated [30248,32020]
===
match
---
trailer [4726,4728]
trailer [4726,4728]
===
match
---
operator: , [28303,28304]
operator: , [28298,28299]
===
match
---
name: skipped [4654,4661]
name: skipped [4654,4661]
===
match
---
name: set_state [32524,32533]
name: set_state [32519,32528]
===
match
---
trailer [23588,23594]
trailer [23583,23589]
===
match
---
trailer [23966,23971]
trailer [23961,23966]
===
match
---
return_stmt [15521,15540]
return_stmt [15516,15535]
===
match
---
trailer [23244,23297]
trailer [23239,23292]
===
match
---
atom_expr [31349,31365]
atom_expr [31344,31360]
===
match
---
arglist [23595,23651]
arglist [23590,23646]
===
match
---
name: log [23887,23890]
name: log [23882,23885]
===
match
---
name: conf [7536,7540]
name: conf [7536,7540]
===
match
---
name: dag [13641,13644]
name: dag [13636,13639]
===
match
---
string: 'running: %s | failed: %s | skipped: %s | deadlocked: %s | not ready: %s' [15714,15787]
string: 'running: %s | failed: %s | skipped: %s | deadlocked: %s | not ready: %s' [15709,15782]
===
match
---
arglist [19269,19355]
arglist [19264,19350]
===
match
---
name: ti_status [15801,15810]
name: ti_status [15796,15805]
===
match
---
operator: = [7534,7535]
operator: = [7534,7535]
===
match
---
suite [17928,23972]
suite [17923,23967]
===
match
---
trailer [26882,26889]
trailer [26877,26884]
===
match
---
trailer [14149,14157]
trailer [14144,14152]
===
match
---
atom_expr [20622,20643]
atom_expr [20617,20638]
===
match
---
decorated [32588,36330]
decorated [32583,36325]
===
match
---
name: ti_status [16206,16215]
name: ti_status [16201,16210]
===
match
---
name: str [28186,28189]
name: str [28181,28184]
===
match
---
name: tis_map [31691,31698]
name: tis_map [31686,31693]
===
match
---
name: state [37512,37517]
name: state [37507,37512]
===
match
---
operator: , [32626,32627]
operator: , [32621,32622]
===
match
---
name: dagrun_infos [30301,30313]
name: dagrun_infos [30296,30308]
===
match
---
name: TaskInstance [37402,37414]
name: TaskInstance [37397,37409]
===
match
---
expr_stmt [22120,22155]
expr_stmt [22115,22150]
===
match
---
trailer [27443,27455]
trailer [27438,27450]
===
match
---
atom_expr [29986,30002]
atom_expr [29981,29997]
===
match
---
name: TaskInstance [38251,38263]
name: TaskInstance [38246,38258]
===
match
---
name: FAILED [19599,19605]
name: FAILED [19594,19600]
===
match
---
trailer [27354,27363]
trailer [27349,27358]
===
match
---
name: len [15907,15910]
name: len [15902,15905]
===
match
---
simple_stmt [34005,34078]
simple_stmt [34000,34073]
===
match
---
name: running [18579,18586]
name: running [18574,18581]
===
match
---
name: FAILED [20104,20110]
name: FAILED [20099,20105]
===
match
---
if_stmt [22795,23127]
if_stmt [22790,23122]
===
match
---
operator: > [34757,34758]
operator: > [34752,34753]
===
match
---
trailer [8968,8976]
trailer [8968,8976]
===
match
---
trailer [26842,26844]
trailer [26837,26839]
===
match
---
operator: , [28510,28511]
operator: , [28505,28506]
===
match
---
atom_expr [34913,34937]
atom_expr [34908,34932]
===
match
---
name: airflow [1290,1297]
name: airflow [1290,1297]
===
match
---
trailer [15132,15134]
trailer [15127,15129]
===
match
---
atom [8142,8144]
atom [8142,8144]
===
match
---
name: to_run [10626,10632]
name: to_run [10621,10627]
===
match
---
name: ti_status [27434,27443]
name: ti_status [27429,27438]
===
match
---
name: rerun_failed_tasks [7554,7572]
name: rerun_failed_tasks [7554,7572]
===
match
---
trailer [23789,23794]
trailer [23784,23789]
===
match
---
name: ti_status [15985,15994]
name: ti_status [15980,15989]
===
match
---
simple_stmt [19929,19976]
simple_stmt [19924,19971]
===
match
---
expr_stmt [20719,20749]
expr_stmt [20714,20744]
===
match
---
trailer [8604,8617]
trailer [8604,8617]
===
match
---
string: 'You cannot backfill backwards because one or more tasks depend_on_past: {}' [33571,33647]
string: 'You cannot backfill backwards because one or more tasks depend_on_past: {}' [33566,33642]
===
match
---
name: not_ready [26641,26650]
name: not_ready [26636,26645]
===
match
---
import_from [1556,1602]
import_from [1556,1602]
===
match
---
trailer [34506,34515]
trailer [34501,34510]
===
match
---
atom_expr [34945,34977]
atom_expr [34940,34972]
===
match
---
operator: @ [16238,16239]
operator: @ [16233,16234]
===
match
---
name: SCHEDULED [19948,19957]
name: SCHEDULED [19943,19952]
===
match
---
simple_stmt [28596,28635]
simple_stmt [28591,28630]
===
match
---
atom_expr [20404,20430]
atom_expr [20399,20425]
===
match
---
dotted_name [1737,1758]
dotted_name [1737,1758]
===
match
---
name: x [38652,38653]
name: x [38647,38648]
===
match
---
operator: , [10482,10483]
operator: , [10477,10478]
===
match
---
name: runs [13215,13219]
name: runs [13210,13214]
===
match
---
if_stmt [34132,34482]
if_stmt [34127,34477]
===
match
---
arglist [19411,19443]
arglist [19406,19438]
===
match
---
trailer [10586,10599]
trailer [10581,10594]
===
match
---
operator: > [17453,17454]
operator: > [17448,17449]
===
match
---
operator: = [20822,20823]
operator: = [20817,20818]
===
match
---
name: self [7133,7137]
name: self [7133,7137]
===
match
---
name: State [13810,13815]
name: State [13805,13810]
===
match
---
trailer [16104,16114]
trailer [16099,16109]
===
match
---
if_stmt [33811,34078]
if_stmt [33806,34073]
===
match
---
name: executor_constants [34202,34220]
name: executor_constants [34197,34215]
===
match
---
operator: - [35368,35369]
operator: - [35363,35364]
===
match
---
trailer [29884,29892]
trailer [29879,29887]
===
match
---
simple_stmt [30237,30248]
simple_stmt [30232,30243]
===
match
---
trailer [20174,20222]
trailer [20169,20217]
===
match
---
operator: == [20644,20646]
operator: == [20639,20641]
===
match
---
operator: { [24436,24437]
operator: { [24431,24432]
===
match
---
atom_expr [7291,7324]
atom_expr [7291,7324]
===
match
---
name: start_date [16375,16385]
name: start_date [16370,16380]
===
match
---
name: TaskInstance [38106,38118]
name: TaskInstance [38101,38113]
===
match
---
name: helpers [38532,38539]
name: helpers [38527,38534]
===
match
---
name: session [24504,24511]
name: session [24499,24506]
===
match
---
atom_expr [7173,7189]
atom_expr [7173,7189]
===
match
---
atom_expr [7493,7505]
atom_expr [7493,7505]
===
match
---
name: update [31684,31690]
name: update [31679,31685]
===
match
---
name: NoAvailablePoolSlot [26122,26141]
name: NoAvailablePoolSlot [26117,26136]
===
match
---
string: "backfill" [34542,34552]
string: "backfill" [34537,34547]
===
match
---
name: sorted_tis [28430,28440]
name: sorted_tis [28425,28435]
===
match
---
name: ti_status [34945,34954]
name: ti_status [34940,34949]
===
match
---
name: get_num_task_instances [25475,25497]
name: get_num_task_instances [25470,25492]
===
match
---
simple_stmt [13628,14011]
simple_stmt [13623,14006]
===
match
---
name: STATES_COUNT_AS_RUNNING [2136,2159]
name: STATES_COUNT_AS_RUNNING [2136,2159]
===
match
---
suite [19206,19445]
suite [19201,19440]
===
match
---
name: pickle_id [34106,34115]
name: pickle_id [34101,34110]
===
match
---
name: conf [13902,13906]
name: conf [13897,13901]
===
match
---
operator: == [26719,26721]
operator: == [26714,26716]
===
match
---
operator: = [2213,2214]
operator: = [2213,2214]
===
match
---
trailer [4989,4991]
trailer [4989,4991]
===
match
---
atom_expr [33571,33737]
atom_expr [33566,33732]
===
match
---
or_test [20648,20675]
or_test [20643,20670]
===
match
---
parameters [36390,36434]
parameters [36385,36429]
===
match
---
operator: = [38425,38426]
operator: = [38420,38421]
===
match
---
name: self [14848,14852]
name: self [14843,14847]
===
match
---
simple_stmt [31613,31651]
simple_stmt [31608,31646]
===
match
---
atom_expr [33450,33467]
atom_expr [33445,33462]
===
match
---
simple_stmt [20455,20462]
simple_stmt [20450,20457]
===
match
---
trailer [28296,28303]
trailer [28291,28298]
===
match
---
trailer [18633,18638]
trailer [18628,18633]
===
match
---
dotted_name [1443,1470]
dotted_name [1443,1470]
===
match
---
name: DepContext [1478,1488]
name: DepContext [1478,1488]
===
match
---
expr_stmt [7077,7091]
expr_stmt [7077,7091]
===
match
---
name: dag [12897,12900]
name: dag [12892,12895]
===
match
---
operator: , [27694,27695]
operator: , [27689,27690]
===
match
---
atom_expr [26222,26239]
atom_expr [26217,26234]
===
match
---
operator: = [28813,28814]
operator: = [28808,28809]
===
match
---
trailer [37401,37415]
trailer [37396,37410]
===
match
---
operator: = [28260,28261]
operator: = [28255,28256]
===
match
---
argument [25583,25606]
argument [25578,25601]
===
match
---
name: self [4608,4612]
name: self [4608,4612]
===
match
---
name: filter_for_tis [10754,10768]
name: filter_for_tis [10749,10763]
===
match
---
trailer [37157,37166]
trailer [37152,37161]
===
match
---
argument [10903,10928]
argument [10898,10923]
===
match
---
trailer [10259,10264]
trailer [10254,10259]
===
match
---
name: to_run [22698,22704]
name: to_run [22693,22699]
===
match
---
atom_expr [10518,10548]
atom_expr [10513,10543]
===
match
---
if_stmt [18559,18639]
if_stmt [18554,18634]
===
match
---
name: len [16016,16019]
name: len [16011,16014]
===
match
---
atom_expr [33121,33147]
atom_expr [33116,33142]
===
match
---
name: ti_status [26819,26828]
name: ti_status [26814,26823]
===
match
---
name: repr [38647,38651]
name: repr [38642,38646]
===
match
---
name: session [21253,21260]
name: session [21248,21255]
===
match
---
operator: , [17912,17913]
operator: , [17907,17908]
===
match
---
trailer [25920,26049]
trailer [25915,26044]
===
match
---
simple_stmt [23882,23927]
simple_stmt [23877,23922]
===
match
---
name: task [25593,25597]
name: task [25588,25592]
===
match
---
name: self [21516,21520]
name: self [21511,21515]
===
match
---
name: verbose [29177,29184]
name: verbose [29172,29179]
===
match
---
name: to_run [31677,31683]
name: to_run [31672,31678]
===
match
---
file_input [790,38834]
file_input [790,38829]
===
match
---
simple_stmt [15506,15512]
simple_stmt [15501,15507]
===
match
---
name: self [21732,21736]
name: self [21727,21731]
===
match
---
name: are_dependencies_met [29052,29072]
name: are_dependencies_met [29047,29067]
===
match
---
trailer [34376,34386]
trailer [34371,34381]
===
match
---
param [5159,5173]
param [5159,5173]
===
match
---
sliceop [33797,33800]
sliceop [33792,33795]
===
match
---
operator: , [17894,17895]
operator: , [17889,17890]
===
match
---
name: session [13157,13164]
name: session [13152,13159]
===
match
---
trailer [24869,24892]
trailer [24864,24887]
===
match
---
trailer [21766,21778]
trailer [21761,21773]
===
match
---
trailer [14852,14883]
trailer [14847,14878]
===
match
---
atom_expr [11667,11679]
atom_expr [11662,11674]
===
match
---
trailer [14191,14204]
trailer [14186,14199]
===
match
---
trailer [24327,24333]
trailer [24322,24328]
===
match
---
trailer [28575,28582]
trailer [28570,28577]
===
match
---
number: 1.0 [5353,5356]
number: 1.0 [5353,5356]
===
match
---
funcdef [27670,30248]
funcdef [27665,30243]
===
match
---
trailer [15019,15035]
trailer [15014,15030]
===
match
---
operator: , [22350,22351]
operator: , [22345,22346]
===
match
---
name: to_run [22984,22990]
name: to_run [22979,22985]
===
match
---
operator: , [7792,7793]
operator: , [7792,7793]
===
match
---
name: BackfillUnfinished [35539,35557]
name: BackfillUnfinished [35534,35552]
===
match
---
atom_expr [14144,14157]
atom_expr [14139,14152]
===
match
---
simple_stmt [1005,1194]
simple_stmt [1005,1194]
===
match
---
trailer [21530,21560]
trailer [21525,21555]
===
match
---
name: QUEUED [37295,37301]
name: QUEUED [37290,37296]
===
match
---
name: not_ready [4800,4809]
name: not_ready [4800,4809]
===
match
---
suite [5535,7730]
suite [5535,7730]
===
match
---
funcdef [10948,12101]
funcdef [10943,12096]
===
match
---
suite [8564,8773]
suite [8564,8773]
===
match
---
name: total_runs [15848,15858]
name: total_runs [15843,15853]
===
match
---
name: set_ti_keys [27897,27908]
name: set_ti_keys [27892,27903]
===
match
---
simple_stmt [33527,33756]
simple_stmt [33522,33751]
===
match
---
operator: , [19605,19606]
operator: , [19600,19601]
===
match
---
name: kwargs [5521,5527]
name: kwargs [5521,5527]
===
match
---
name: pop [9473,9476]
name: pop [9473,9476]
===
match
---
suite [25162,25349]
suite [25157,25344]
===
match
---
name: executor [37027,37035]
name: executor [37022,37030]
===
match
---
operator: , [28932,28933]
operator: , [28927,28928]
===
match
---
name: SKIPPED [18705,18712]
name: SKIPPED [18700,18707]
===
match
---
name: cfg_path [22120,22128]
name: cfg_path [22115,22123]
===
match
---
trailer [38641,38646]
trailer [38636,38641]
===
match
---
name: PoolNotFound [1145,1157]
name: PoolNotFound [1145,1157]
===
match
---
operator: = [34365,34366]
operator: = [34360,34361]
===
match
---
trailer [10244,10250]
trailer [10239,10245]
===
match
---
operator: , [20211,20212]
operator: , [20206,20207]
===
match
---
comparison [25788,25853]
comparison [25783,25848]
===
match
---
expr_stmt [32997,33053]
expr_stmt [32992,33048]
===
match
---
operator: = [13853,13854]
operator: = [13848,13849]
===
match
---
string: "DAG ID" [28491,28499]
string: "DAG ID" [28486,28494]
===
match
---
name: state [19711,19716]
name: state [19706,19711]
===
match
---
trailer [33855,33873]
trailer [33850,33868]
===
match
---
atom_expr [20949,20970]
atom_expr [20944,20965]
===
match
---
suite [11386,11508]
suite [11381,11503]
===
match
---
simple_stmt [22734,22751]
simple_stmt [22729,22746]
===
match
---
name: start_date [13762,13772]
name: start_date [13757,13767]
===
match
---
operator: == [19192,19194]
operator: == [19187,19189]
===
match
---
name: debug [23589,23594]
name: debug [23584,23589]
===
match
---
and_test [13513,13593]
and_test [13508,13588]
===
match
---
trailer [32539,32546]
trailer [32534,32541]
===
match
---
operator: , [28326,28327]
operator: , [28321,28322]
===
match
---
atom_expr [34367,34386]
atom_expr [34362,34381]
===
match
---
while_stmt [17394,27577]
while_stmt [17389,27572]
===
match
---
suite [19488,19976]
suite [19483,19971]
===
match
---
operator: = [35067,35068]
operator: = [35062,35063]
===
match
---
name: ti_status [15911,15920]
name: ti_status [15906,15915]
===
match
---
name: self [4558,4562]
name: self [4558,4562]
===
match
---
operator: = [13237,13238]
operator: = [13232,13233]
===
match
---
simple_stmt [12668,12704]
simple_stmt [12663,12699]
===
match
---
trailer [33549,33755]
trailer [33544,33750]
===
match
---
name: ti [28371,28373]
name: ti [28366,28368]
===
match
---
simple_stmt [25434,25756]
simple_stmt [25429,25751]
===
match
---
trailer [13911,13916]
trailer [13906,13911]
===
match
---
name: session [20568,20575]
name: session [20563,20570]
===
match
---
atom_expr [34399,34418]
atom_expr [34394,34413]
===
match
---
operator: , [37534,37535]
operator: , [37529,37530]
===
match
---
name: dagrun_infos [34877,34889]
name: dagrun_infos [34872,34884]
===
match
---
name: ti [15100,15102]
name: ti [15095,15097]
===
match
---
atom [34804,34995]
atom [34799,34990]
===
match
---
name: self [9382,9386]
name: self [9382,9386]
===
match
---
atom_expr [27873,28025]
atom_expr [27868,28020]
===
match
---
trailer [34438,34445]
trailer [34433,34440]
===
match
---
comp_op [8275,8281]
comp_op [8275,8281]
===
match
---
name: key [18405,18408]
name: key [18400,18403]
===
match
---
expr_stmt [12870,12944]
expr_stmt [12865,12939]
===
match
---
simple_stmt [33986,33993]
simple_stmt [33981,33988]
===
match
---
name: start_date [35234,35244]
name: start_date [35229,35239]
===
match
---
operator: , [34333,34334]
operator: , [34328,34329]
===
match
---
trailer [7701,7703]
trailer [7701,7703]
===
match
---
name: SUCCESS [18352,18359]
name: SUCCESS [18347,18354]
===
match
---
name: DagConcurrencyLimitReached [26143,26169]
name: DagConcurrencyLimitReached [26138,26164]
===
match
---
string: '[backfill progress] | finished run %s of %s | tasks waiting: %s | succeeded: %s | ' [15617,15701]
string: '[backfill progress] | finished run %s of %s | tasks waiting: %s | succeeded: %s | ' [15612,15696]
===
match
---
expr_stmt [7493,7515]
expr_stmt [7493,7515]
===
match
---
argument [35193,35212]
argument [35188,35207]
===
match
---
name: dag_id [25531,25537]
name: dag_id [25526,25532]
===
match
---
name: info [38717,38721]
name: info [38712,38716]
===
match
---
argument [13132,13155]
argument [13127,13150]
===
match
---
operator: , [28520,28521]
operator: , [28515,28516]
===
match
---
trailer [35978,35986]
trailer [35973,35981]
===
match
---
name: RUNNING [14150,14157]
name: RUNNING [14145,14152]
===
match
---
name: session [38183,38190]
name: session [38178,38185]
===
match
---
operator: , [31512,31513]
operator: , [31507,31508]
===
match
---
expr_stmt [10734,10789]
expr_stmt [10729,10784]
===
match
---
name: tabulate_ti_keys_set [28654,28674]
name: tabulate_ti_keys_set [28649,28669]
===
match
---
funcdef [28134,28537]
funcdef [28129,28532]
===
match
---
atom_expr [33251,33327]
atom_expr [33246,33322]
===
match
---
operator: = [24486,24487]
operator: = [24481,24482]
===
match
---
if_stmt [35505,35574]
if_stmt [35500,35569]
===
match
---
name: states [25640,25646]
name: states [25635,25641]
===
match
---
name: _get_dag_run [12131,12143]
name: _get_dag_run [12126,12138]
===
match
---
atom_expr [21909,21928]
atom_expr [21904,21923]
===
match
---
operator: , [28108,28109]
operator: , [28103,28104]
===
match
---
name: items [11310,11315]
name: items [11305,11310]
===
match
---
import_from [1368,1437]
import_from [1368,1437]
===
match
---
name: len [17462,17465]
name: len [17457,17460]
===
match
---
import_from [1327,1367]
import_from [1327,1367]
===
match
---
name: dep_context [28880,28891]
name: dep_context [28875,28886]
===
match
---
testlist_comp [37848,37933]
testlist_comp [37843,37928]
===
match
---
trailer [10574,10582]
trailer [10569,10577]
===
match
---
param [17891,17895]
param [17886,17890]
===
match
---
name: dagrun_info [12679,12690]
name: dagrun_info [12674,12685]
===
match
---
param [7777,7782]
param [7777,7782]
===
match
---
trailer [20664,20675]
trailer [20659,20670]
===
match
---
trailer [27455,27462]
trailer [27450,27457]
===
match
---
operator: = [28281,28282]
operator: = [28276,28277]
===
match
---
expr_stmt [29681,29721]
expr_stmt [29676,29716]
===
match
---
name: provide_session [32589,32604]
name: provide_session [32584,32599]
===
match
---
import_from [1603,1646]
import_from [1603,1646]
===
match
---
comparison [26631,26675]
comparison [26626,26670]
===
match
---
operator: , [11980,11981]
operator: , [11975,11976]
===
match
---
trailer [16215,16222]
trailer [16210,16217]
===
match
---
name: ti [37879,37881]
name: ti [37874,37876]
===
match
---
trailer [23886,23890]
trailer [23881,23885]
===
match
---
simple_stmt [18127,18192]
simple_stmt [18122,18187]
===
match
---
arglist [24752,24773]
arglist [24747,24768]
===
match
---
param [4521,4534]
param [4521,4534]
===
match
---
trailer [4768,4770]
trailer [4768,4770]
===
match
---
for_stmt [15096,15408]
for_stmt [15091,15403]
===
match
---
name: filter_for_tis [38119,38133]
name: filter_for_tis [38114,38128]
===
match
---
simple_stmt [4783,4819]
simple_stmt [4783,4819]
===
match
---
suite [28583,28693]
suite [28578,28688]
===
match
---
expr_stmt [18020,18078]
expr_stmt [18015,18073]
===
match
---
name: state [11630,11635]
name: state [11625,11630]
===
match
---
trailer [32445,32447]
trailer [32440,32442]
===
match
---
name: ti_status [29986,29995]
name: ti_status [29981,29990]
===
match
---
atom_expr [10875,10883]
atom_expr [10870,10878]
===
match
---
param [5442,5462]
param [5442,5462]
===
match
---
trailer [34031,34040]
trailer [34026,34035]
===
match
---
simple_stmt [27283,27317]
simple_stmt [27278,27312]
===
match
---
expr_stmt [9811,9840]
expr_stmt [9806,9835]
===
match
---
operator: , [7781,7782]
operator: , [7781,7782]
===
match
---
operator: , [27908,27909]
operator: , [27903,27904]
===
match
---
simple_stmt [27434,27468]
simple_stmt [27429,27463]
===
match
---
name: State [38427,38432]
name: State [38422,38427]
===
match
---
name: ti [19704,19706]
name: ti [19699,19701]
===
match
---
trailer [26763,26771]
trailer [26758,26766]
===
match
---
trailer [17963,18002]
trailer [17958,17997]
===
match
---
name: ti_status [20357,20366]
name: ti_status [20352,20361]
===
match
---
name: tabulate_tis_set [28138,28154]
name: tabulate_tis_set [28133,28149]
===
match
---
suite [37714,37823]
suite [37709,37818]
===
match
---
expr_stmt [38153,38365]
expr_stmt [38148,38360]
===
match
---
dotted_name [1199,1216]
dotted_name [1199,1216]
===
match
---
name: dagrun_info [34913,34924]
name: dagrun_info [34908,34919]
===
match
---
name: query [37998,38003]
name: query [37993,37998]
===
match
---
import_from [1243,1284]
import_from [1243,1284]
===
match
---
trailer [15352,15360]
trailer [15347,15355]
===
match
---
simple_stmt [15420,15437]
simple_stmt [15415,15432]
===
match
---
atom_expr [17434,17451]
atom_expr [17429,17446]
===
match
---
atom [20647,20676]
atom [20642,20671]
===
match
---
if_stmt [11364,11508]
if_stmt [11359,11503]
===
match
---
param [4259,4272]
param [4259,4272]
===
match
---
trailer [17347,17358]
trailer [17342,17353]
===
match
---
atom [17308,17310]
atom [17303,17305]
===
match
---
operator: , [15568,15569]
operator: , [15563,15564]
===
match
---
name: pop [19817,19820]
name: pop [19812,19815]
===
match
---
name: try_number [28331,28341]
name: try_number [28326,28336]
===
match
---
name: set_state [19932,19941]
name: set_state [19927,19936]
===
match
---
trailer [23337,23345]
trailer [23332,23340]
===
match
---
name: session [27300,27307]
name: session [27295,27302]
===
match
---
name: active_runs [27444,27455]
name: active_runs [27439,27450]
===
match
---
atom_expr [19411,19426]
atom_expr [19406,19421]
===
match
---
operator: = [19435,19436]
operator: = [19430,19431]
===
match
---
operator: , [31910,31911]
operator: , [31905,31906]
===
match
---
name: sorted_ti_keys [28054,28068]
name: sorted_ti_keys [28049,28063]
===
match
---
name: self [7549,7553]
name: self [7549,7553]
===
match
---
name: executor_constants [34249,34267]
name: executor_constants [34244,34262]
===
match
---
operator: , [21995,21996]
operator: , [21990,21991]
===
match
---
trailer [37642,37661]
trailer [37637,37656]
===
match
---
name: ti [28289,28291]
name: ti [28284,28286]
===
match
---
simple_stmt [1438,1489]
simple_stmt [1438,1489]
===
match
---
arglist [10867,10928]
arglist [10862,10923]
===
match
---
trailer [31397,31410]
trailer [31392,31405]
===
match
---
name: state [11703,11708]
name: state [11698,11703]
===
match
---
if_stmt [11654,12101]
if_stmt [11649,12096]
===
match
---
argument [13976,13999]
argument [13971,13994]
===
match
---
name: creating_job_id [13976,13991]
name: creating_job_id [13971,13986]
===
match
---
argument [13709,13748]
argument [13704,13743]
===
match
---
strings [24652,24744]
strings [24647,24739]
===
match
---
parameters [7776,7807]
parameters [7776,7807]
===
match
---
atom_expr [33134,33146]
atom_expr [33129,33141]
===
match
---
trailer [37035,37048]
trailer [37030,37043]
===
match
---
operator: = [37368,37369]
operator: = [37363,37364]
===
match
---
name: State [18346,18351]
name: State [18341,18346]
===
match
---
operator: , [10458,10459]
operator: , [10453,10454]
===
match
---
operator: == [18343,18345]
operator: == [18338,18340]
===
match
---
trailer [10890,10900]
trailer [10885,10895]
===
match
---
testlist_comp [33400,33467]
testlist_comp [33395,33462]
===
match
---
suite [27721,30248]
suite [27716,30243]
===
match
---
name: key [22654,22657]
name: key [22649,22652]
===
match
---
atom_expr [37388,37680]
atom_expr [37383,37675]
===
match
---
name: State [19593,19598]
name: State [19588,19593]
===
match
---
simple_stmt [8153,8171]
simple_stmt [8153,8171]
===
match
---
operator: = [13164,13165]
operator: = [13159,13160]
===
match
---
operator: = [5426,5427]
operator: = [5426,5427]
===
match
---
name: executor_constants [1224,1242]
name: executor_constants [1224,1242]
===
match
---
param [4451,4479]
param [4451,4479]
===
match
---
name: _execute_dagruns [35017,35033]
name: _execute_dagruns [35012,35028]
===
match
---
trailer [27879,28025]
trailer [27874,28020]
===
match
---
name: ti [18178,18180]
name: ti [18173,18175]
===
match
---
name: ti_status [18569,18578]
name: ti_status [18564,18573]
===
match
---
number: 0 [17455,17456]
number: 0 [17450,17451]
===
match
---
name: session [19428,19435]
name: session [19423,19430]
===
match
---
name: format [24745,24751]
name: format [24740,24746]
===
match
---
trailer [13265,13271]
trailer [13260,13266]
===
match
---
or_test [4800,4818]
or_test [4800,4818]
===
match
---
simple_stmt [13306,13343]
simple_stmt [13301,13338]
===
match
---
trailer [38461,38467]
trailer [38456,38462]
===
match
---
name: state [15228,15233]
name: state [15223,15228]
===
match
---
suite [32412,32583]
suite [32407,32578]
===
match
---
name: start_date [30347,30357]
name: start_date [30342,30352]
===
match
---
simple_stmt [32516,32548]
simple_stmt [32511,32543]
===
match
---
name: BACKFILL_JOB [14192,14204]
name: BACKFILL_JOB [14187,14199]
===
match
---
trailer [14883,14927]
trailer [14878,14922]
===
match
---
return_stmt [30237,30247]
return_stmt [30232,30242]
===
match
---
trailer [13195,13203]
trailer [13190,13198]
===
match
---
name: err [30127,30130]
name: err [30122,30125]
===
match
---
operator: = [27714,27715]
operator: = [27709,27710]
===
match
---
trailer [23584,23588]
trailer [23579,23583]
===
match
---
name: filter_by_dag_run [37314,37331]
name: filter_by_dag_run [37309,37326]
===
match
---
atom_expr [38647,38654]
atom_expr [38642,38649]
===
match
---
if_stmt [18908,18988]
if_stmt [18903,18983]
===
match
---
operator: , [24099,24100]
operator: , [24094,24095]
===
match
---
name: t [29050,29051]
name: t [29045,29046]
===
match
---
operator: = [20567,20568]
operator: = [20562,20563]
===
match
---
trailer [30095,30114]
trailer [30090,30109]
===
match
---
comparison [17430,17456]
comparison [17425,17451]
===
match
---
trailer [24296,24327]
trailer [24291,24322]
===
match
---
argument [13762,13790]
argument [13757,13785]
===
match
---
name: ti_status [29228,29237]
name: ti_status [29223,29232]
===
match
---
simple_stmt [31960,32025]
simple_stmt [31955,32020]
===
match
---
operator: = [7668,7669]
operator: = [7668,7669]
===
match
---
simple_stmt [37009,37049]
simple_stmt [37004,37044]
===
match
---
trailer [37780,37822]
trailer [37775,37817]
===
match
---
name: pickle_id [31856,31865]
name: pickle_id [31851,31860]
===
match
---
atom [28078,28123]
atom [28073,28118]
===
match
---
atom_expr [18513,18538]
atom_expr [18508,18533]
===
match
---
name: running [29885,29892]
name: running [29880,29887]
===
match
---
trailer [28307,28314]
trailer [28302,28309]
===
match
---
name: error [22862,22867]
name: error [22857,22862]
===
match
---
trailer [26771,26845]
trailer [26766,26840]
===
match
---
param [30315,30325]
param [30310,30320]
===
match
---
simple_stmt [34524,34553]
simple_stmt [34519,34548]
===
match
---
name: value [11268,11273]
name: value [11263,11268]
===
match
---
operator: = [11762,11763]
operator: = [11757,11758]
===
match
---
trailer [33899,33904]
trailer [33894,33899]
===
match
---
name: self [4693,4697]
name: self [4693,4697]
===
match
---
name: Pool [24304,24308]
name: Pool [24299,24303]
===
match
---
operator: , [8937,8938]
operator: , [8937,8938]
===
match
---
trailer [10842,10849]
trailer [10837,10844]
===
match
---
simple_stmt [9382,9439]
simple_stmt [9382,9439]
===
match
---
import_as_names [1629,1646]
import_as_names [1629,1646]
===
match
---
trailer [28713,28724]
trailer [28708,28719]
===
match
---
name: pickle_id [22341,22350]
name: pickle_id [22336,22345]
===
match
---
name: RUNNING [13816,13823]
name: RUNNING [13811,13818]
===
match
---
operator: = [25591,25592]
operator: = [25586,25587]
===
match
---
atom_expr [27385,27408]
atom_expr [27380,27403]
===
match
---
operator: , [12148,12149]
operator: , [12143,12144]
===
match
---
name: resettable_tis [37353,37367]
name: resettable_tis [37348,37362]
===
match
---
name: state [15338,15343]
name: state [15333,15338]
===
match
---
atom_expr [19593,19605]
atom_expr [19588,19600]
===
match
---
name: task_ids [25583,25591]
name: task_ids [25578,25586]
===
match
---
param [38004,38011]
param [37999,38006]
===
match
---
atom_expr [35012,35311]
atom_expr [35007,35306]
===
match
---
arglist [35674,35830]
arglist [35669,35825]
===
match
---
name: ti_status [23073,23082]
name: ti_status [23068,23077]
===
match
---
name: t [28836,28837]
name: t [28831,28832]
===
match
---
name: types [1839,1844]
name: types [1839,1844]
===
match
---
name: FAILED [32540,32546]
name: FAILED [32535,32541]
===
match
---
trailer [27982,27990]
trailer [27977,27985]
===
match
---
name: state [11965,11970]
name: state [11960,11965]
===
match
---
name: ti_status [23943,23952]
name: ti_status [23938,23947]
===
match
---
expr_stmt [33174,33227]
expr_stmt [33169,33222]
===
match
---
operator: @ [17840,17841]
operator: @ [17835,17836]
===
match
---
simple_stmt [14259,14270]
simple_stmt [14254,14265]
===
match
---
atom_expr [11585,11640]
atom_expr [11580,11635]
===
match
---
string: "{} open slots in pool {}" [24718,24744]
string: "{} open slots in pool {}" [24713,24739]
===
match
---
name: running [22646,22653]
name: running [22641,22648]
===
match
---
name: self [25647,25651]
name: self [25642,25646]
===
match
---
param [5333,5357]
param [5333,5357]
===
match
---
name: not_ready [4364,4373]
name: not_ready [4364,4373]
===
match
---
trailer [37483,37680]
trailer [37478,37675]
===
match
---
simple_stmt [10616,10646]
simple_stmt [10611,10641]
===
match
---
name: ti_status [26700,26709]
name: ti_status [26695,26704]
===
match
---
name: REMOVED [15353,15360]
name: REMOVED [15348,15355]
===
match
---
expr_stmt [31462,31530]
expr_stmt [31457,31525]
===
match
---
simple_stmt [26755,26846]
simple_stmt [26750,26841]
===
match
---
name: err [29958,29961]
name: err [29953,29956]
===
match
---
simple_stmt [20537,20577]
simple_stmt [20532,20572]
===
match
---
name: log [8639,8642]
name: log [8639,8642]
===
match
---
atom_expr [18334,18342]
atom_expr [18329,18337]
===
match
---
argument [13804,13823]
argument [13799,13818]
===
match
---
atom_expr [28328,28341]
atom_expr [28323,28336]
===
match
---
operator: , [15787,15788]
operator: , [15782,15783]
===
match
---
atom_expr [28675,28691]
atom_expr [28670,28686]
===
match
---
operator: = [33397,33398]
operator: = [33392,33393]
===
match
---
simple_stmt [14848,14928]
simple_stmt [14843,14923]
===
match
---
name: _dag_runs [27196,27205]
name: _dag_runs [27191,27200]
===
match
---
trailer [23090,23094]
trailer [23085,23089]
===
match
---
operator: = [24064,24065]
operator: = [24059,24060]
===
match
---
trailer [33025,33041]
trailer [33020,33036]
===
match
---
name: len [38819,38822]
name: len [38814,38817]
===
match
---
expr_stmt [21710,21739]
expr_stmt [21705,21734]
===
match
---
name: utils [1660,1665]
name: utils [1660,1665]
===
match
---
atom_expr [15949,15966]
atom_expr [15944,15961]
===
match
---
atom_expr [34431,34447]
atom_expr [34426,34442]
===
match
---
name: finished_runs [15811,15824]
name: finished_runs [15806,15819]
===
match
---
if_stmt [9331,10646]
if_stmt [9331,10641]
===
match
---
name: DAG [25471,25474]
name: DAG [25466,25469]
===
match
---
atom [37847,37934]
atom [37842,37929]
===
match
---
trailer [7177,7189]
trailer [7177,7189]
===
match
---
trailer [18438,18444]
trailer [18433,18439]
===
match
---
simple_stmt [14366,14710]
simple_stmt [14361,14705]
===
match
---
decorated [14275,15541]
decorated [14270,15536]
===
match
---
if_stmt [32460,32548]
if_stmt [32455,32543]
===
match
---
param [17896,17913]
param [17891,17908]
===
match
---
operator: , [1315,1316]
operator: , [1315,1316]
===
match
---
expr_stmt [29906,29945]
expr_stmt [29901,29940]
===
match
---
trailer [5055,5066]
trailer [5055,5066]
===
match
---
name: log [35975,35978]
name: log [35970,35973]
===
match
---
simple_stmt [23073,23100]
simple_stmt [23068,23095]
===
match
---
operator: == [23187,23189]
operator: == [23182,23184]
===
match
---
atom_expr [31613,31650]
atom_expr [31608,31645]
===
match
---
name: DagRun [1361,1367]
name: DagRun [1361,1367]
===
match
---
suite [33358,33802]
suite [33353,33797]
===
match
---
trailer [19598,19605]
trailer [19593,19600]
===
match
---
simple_stmt [11332,11352]
simple_stmt [11327,11347]
===
match
---
if_stmt [23175,23472]
if_stmt [23170,23467]
===
match
---
name: ti [21178,21180]
name: ti [21173,21175]
===
match
---
trailer [31353,31357]
trailer [31348,31352]
===
match
---
trailer [8896,8942]
trailer [8896,8942]
===
match
---
name: run_id [27953,27959]
name: run_id [27948,27954]
===
match
---
name: dag [18032,18035]
name: dag [18027,18030]
===
match
---
name: self [22284,22288]
name: self [22279,22283]
===
match
---
trailer [18878,18882]
trailer [18873,18877]
===
match
---
name: total_runs [5056,5066]
name: total_runs [5056,5066]
===
match
---
trailer [26955,26957]
trailer [26950,26952]
===
match
---
trailer [18533,18538]
trailer [18528,18533]
===
match
---
trailer [31999,32024]
trailer [31994,32019]
===
match
---
name: ti_status [10616,10625]
name: ti_status [10611,10620]
===
match
---
import_as_names [857,870]
import_as_names [857,870]
===
match
---
atom_expr [7645,7667]
atom_expr [7645,7667]
===
match
---
trailer [9147,9154]
trailer [9147,9154]
===
match
---
simple_stmt [18612,18639]
simple_stmt [18607,18634]
===
match
---
trailer [34445,34447]
trailer [34440,34442]
===
match
---
import_from [838,870]
import_from [838,870]
===
match
---
tfpdef [27755,27788]
tfpdef [27750,27783]
===
match
---
expr_stmt [29847,29893]
expr_stmt [29842,29888]
===
match
---
funcdef [17869,23972]
funcdef [17864,23967]
===
match
---
suite [4545,5080]
suite [4545,5080]
===
match
---
simple_stmt [14777,14797]
simple_stmt [14772,14792]
===
match
---
trailer [22708,22713]
trailer [22703,22708]
===
match
---
atom_expr [27208,27232]
atom_expr [27203,27227]
===
match
---
name: dagrun_infos_to_process [34778,34801]
name: dagrun_infos_to_process [34773,34796]
===
match
---
decorator [14275,14292]
decorator [14270,14287]
===
match
---
param [4392,4408]
param [4392,4408]
===
match
---
argument [29164,29184]
argument [29159,29179]
===
match
---
param [15564,15569]
param [15559,15564]
===
match
---
name: airflow [1373,1380]
name: airflow [1373,1380]
===
match
---
trailer [11479,11481]
trailer [11474,11476]
===
match
---
testlist_comp [20098,20133]
testlist_comp [20093,20128]
===
match
---
operator: += [30020,30022]
operator: += [30015,30017]
===
match
---
raise_stmt [33527,33755]
raise_stmt [33522,33750]
===
match
---
arglist [13113,13172]
arglist [13108,13167]
===
match
---
name: _update_counters [7760,7776]
name: _update_counters [7760,7776]
===
match
---
operator: , [5356,5357]
operator: , [5356,5357]
===
match
---
trailer [15847,15858]
trailer [15842,15853]
===
match
---
name: state [11657,11662]
name: state [11652,11657]
===
match
---
name: self [26755,26759]
name: self [26750,26754]
===
match
---
sync_comp_for [37851,37933]
sync_comp_for [37846,37928]
===
match
---
name: running [23381,23388]
name: running [23376,23383]
===
match
---
atom_expr [14848,14927]
atom_expr [14843,14922]
===
match
---
atom_expr [38532,38605]
atom_expr [38527,38600]
===
match
---
name: failed [29996,30002]
name: failed [29991,29997]
===
match
---
suite [20698,20750]
suite [20693,20745]
===
match
---
operator: = [14731,14732]
operator: = [14726,14727]
===
match
---
name: BACKFILL_QUEUED_DEPS [20823,20843]
name: BACKFILL_QUEUED_DEPS [20818,20838]
===
match
---
if_stmt [33336,33802]
if_stmt [33331,33797]
===
match
---
string: 'core' [17359,17365]
string: 'core' [17354,17360]
===
match
---
trailer [12849,12859]
trailer [12844,12854]
===
match
---
name: State [18699,18704]
name: State [18694,18699]
===
match
---
operator: = [35122,35123]
operator: = [35117,35118]
===
match
---
name: deadlocked_depends_on_past [29278,29304]
name: deadlocked_depends_on_past [29273,29299]
===
match
---
name: session [21823,21830]
name: session [21818,21825]
===
match
---
atom_expr [24018,24070]
atom_expr [24013,24065]
===
match
---
trailer [27506,27513]
trailer [27501,27508]
===
match
---
name: len [16091,16094]
name: len [16086,16089]
===
match
---
suite [32120,32583]
suite [32115,32578]
===
match
---
operator: = [14350,14351]
operator: = [14345,14346]
===
match
---
string: '"ignore_first_depends_on_past=True" or passing "-I" at ' [29553,29610]
string: '"ignore_first_depends_on_past=True" or passing "-I" at ' [29548,29605]
===
match
---
name: session [22734,22741]
name: session [22729,22736]
===
match
---
trailer [24289,24296]
trailer [24284,24291]
===
match
---
name: key [27926,27929]
name: key [27921,27924]
===
match
---
trailer [4816,4818]
trailer [4816,4818]
===
match
---
name: running [11526,11533]
name: running [11521,11528]
===
match
---
expr_stmt [21662,21685]
expr_stmt [21657,21680]
===
match
---
name: self [29172,29176]
name: self [29167,29171]
===
match
---
name: add [9155,9158]
name: add [9155,9158]
===
match
---
simple_stmt [4831,4869]
simple_stmt [4831,4869]
===
match
---
operator: , [16038,16039]
operator: , [16033,16034]
===
match
---
name: run [27514,27517]
name: run [27509,27512]
===
match
---
operator: = [5455,5456]
operator: = [5455,5456]
===
match
---
name: interval [34032,34040]
name: interval [34027,34035]
===
match
---
trailer [36148,36183]
trailer [36143,36178]
===
match
---
name: run_at_least_once [33856,33873]
name: run_at_least_once [33851,33868]
===
match
---
name: utils [1616,1621]
name: utils [1616,1621]
===
match
---
operator: = [22575,22576]
operator: = [22570,22571]
===
match
---
simple_stmt [26933,26958]
simple_stmt [26928,26953]
===
match
---
if_stmt [37311,37823]
if_stmt [37306,37818]
===
match
---
trailer [38586,38604]
trailer [38581,38599]
===
match
---
param [5121,5125]
param [5121,5125]
===
match
---
simple_stmt [888,947]
simple_stmt [888,947]
===
match
---
simple_stmt [7549,7594]
simple_stmt [7549,7594]
===
match
---
name: tabulate [968,976]
name: tabulate [968,976]
===
match
---
arglist [21223,21290]
arglist [21218,21285]
===
match
---
name: ti [15395,15397]
name: ti [15390,15392]
===
match
---
simple_stmt [18430,18493]
simple_stmt [18425,18488]
===
match
---
parameters [28154,28182]
parameters [28149,28177]
===
match
---
trailer [21678,21685]
trailer [21673,21680]
===
match
---
trailer [17414,17421]
trailer [17409,17416]
===
match
---
name: debug [18136,18141]
name: debug [18131,18136]
===
match
---
name: ti_status [23773,23782]
name: ti_status [23768,23777]
===
match
---
suite [38019,38511]
suite [38014,38506]
===
match
---
argument [13837,13859]
argument [13832,13854]
===
match
---
name: run_at_least_once [7650,7667]
name: run_at_least_once [7650,7667]
===
match
---
atom_expr [24263,24335]
atom_expr [24258,24330]
===
match
---
name: dag [31342,31345]
name: dag [31337,31340]
===
match
---
arglist [34041,34075]
arglist [34036,34070]
===
match
---
name: set_state [19401,19410]
name: set_state [19396,19405]
===
match
---
name: respect_dag_max_active_limit [13513,13541]
name: respect_dag_max_active_limit [13508,13536]
===
match
---
trailer [15603,16126]
trailer [15598,16121]
===
match
---
atom_expr [15420,15436]
atom_expr [15415,15431]
===
match
---
name: key [20350,20353]
name: key [20345,20348]
===
match
---
name: tmp_configuration_copy [22131,22153]
name: tmp_configuration_copy [22126,22148]
===
match
---
name: tis_values [28470,28480]
name: tis_values [28465,28475]
===
match
---
operator: = [21260,21261]
operator: = [21255,21256]
===
match
---
trailer [21388,21394]
trailer [21383,21389]
===
match
---
string: 'unit_test_mode' [17367,17383]
string: 'unit_test_mode' [17362,17378]
===
match
---
not_test [24363,24371]
not_test [24358,24366]
===
match
---
comp_if [34910,34977]
comp_if [34905,34972]
===
match
---
operator: = [5194,5195]
operator: = [5194,5195]
===
match
---
name: self [13992,13996]
name: self [13987,13991]
===
match
---
name: ti_status [9811,9820]
name: ti_status [9806,9815]
===
match
---
if_stmt [13212,13380]
if_stmt [13207,13375]
===
match
---
name: max_active_runs [13578,13593]
name: max_active_runs [13573,13588]
===
match
---
name: pickle_id [35193,35202]
name: pickle_id [35188,35197]
===
match
---
name: verbose [21283,21290]
name: verbose [21278,21285]
===
match
---
name: ti [10480,10482]
name: ti [10475,10477]
===
match
---
name: self [10975,10979]
name: self [10970,10974]
===
match
---
arglist [23245,23296]
arglist [23240,23291]
===
match
---
operator: = [8140,8141]
operator: = [8140,8141]
===
match
---
name: states [24963,24969]
name: states [24958,24964]
===
match
---
trailer [20263,20267]
trailer [20258,20262]
===
match
---
name: TaskInstance [38197,38209]
name: TaskInstance [38192,38204]
===
match
---
funcdef [5085,7730]
funcdef [5085,7730]
===
match
---
operator: = [5393,5394]
operator: = [5393,5394]
===
match
---
suite [20135,20462]
suite [20130,20457]
===
match
---
trailer [34165,34180]
trailer [34160,34175]
===
match
---
string: "Task instance to run %s state %s" [18142,18176]
string: "Task instance to run %s state %s" [18137,18171]
===
match
---
operator: != [15344,15346]
operator: != [15339,15341]
===
match
---
name: dag [31329,31332]
name: dag [31324,31327]
===
match
---
expr_stmt [21764,21798]
expr_stmt [21759,21793]
===
match
---
if_stmt [26570,26958]
if_stmt [26565,26953]
===
match
---
simple_stmt [24256,24336]
simple_stmt [24251,24331]
===
match
---
name: running [19762,19769]
name: running [19757,19764]
===
match
---
arith_expr [38492,38510]
arith_expr [38487,38505]
===
match
---
operator: , [27974,27975]
operator: , [27969,27970]
===
match
---
operator: , [4378,4379]
operator: , [4378,4379]
===
match
---
simple_stmt [18020,18079]
simple_stmt [18015,18074]
===
match
---
atom_expr [22810,22831]
atom_expr [22805,22826]
===
match
---
name: reduced_key [9210,9221]
name: reduced_key [9210,9221]
===
match
---
import_from [1647,1731]
import_from [1647,1731]
===
match
---
parameters [32621,32641]
parameters [32616,32636]
===
match
---
name: executor_constants [21962,21980]
name: executor_constants [21957,21975]
===
match
---
expr_stmt [34524,34552]
expr_stmt [34519,34547]
===
match
---
name: logical_date [12691,12703]
name: logical_date [12686,12698]
===
match
---
annassign [13185,13203]
annassign [13180,13198]
===
match
---
name: running [9770,9777]
name: running [9770,9777]
===
match
---
name: merge [38462,38467]
name: merge [38457,38462]
===
match
---
import_from [978,1004]
import_from [978,1004]
===
match
---
name: running [10981,10988]
name: running [10976,10983]
===
match
---
for_stmt [38379,38472]
for_stmt [38374,38467]
===
match
---
name: bf_end_date [33070,33081]
name: bf_end_date [33065,33076]
===
match
---
operator: , [16002,16003]
operator: , [15997,15998]
===
match
---
number: 1 [27412,27413]
number: 1 [27407,27408]
===
match
---
simple_stmt [1489,1556]
simple_stmt [1489,1556]
===
match
---
suite [13289,13343]
suite [13284,13338]
===
match
---
suite [1892,38834]
suite [1892,38829]
===
match
---
expr_stmt [34005,34077]
expr_stmt [34000,34072]
===
match
---
string: "%s state %s not in running=%s" [11420,11451]
string: "%s state %s not in running=%s" [11415,11446]
===
match
---
name: dag [31354,31357]
name: dag [31349,31352]
===
match
---
import_as_names [923,946]
import_as_names [923,946]
===
match
---
operator: = [22396,22397]
operator: = [22391,22392]
===
match
---
name: State [23535,23540]
name: State [23530,23535]
===
match
---
expr_stmt [17287,17310]
expr_stmt [17282,17305]
===
match
---
trailer [28902,28932]
trailer [28897,28927]
===
match
---
trailer [22994,22999]
trailer [22989,22994]
===
match
---
name: RUNNING [2169,2176]
name: RUNNING [2169,2176]
===
match
---
trailer [35639,35643]
trailer [35634,35638]
===
match
---
name: dag_run [14902,14909]
name: dag_run [14897,14904]
===
match
---
string: "Deadlock discovered for ti_status.to_run=%s" [26772,26817]
string: "Deadlock discovered for ti_status.to_run=%s" [26767,26812]
===
match
---
name: key [15398,15401]
name: key [15393,15396]
===
match
---
operator: , [19706,19707]
operator: , [19701,19702]
===
match
---
name: data_interval [13709,13722]
name: data_interval [13704,13717]
===
match
---
name: Session [12194,12201]
name: Session [12189,12196]
===
match
---
string: "Task instance %s is up for retry" [9399,9433]
string: "Task instance %s is up for retry" [9399,9433]
===
match
---
or_test [4623,4636]
or_test [4623,4636]
===
match
---
if_stmt [15332,15408]
if_stmt [15327,15403]
===
match
---
name: STATES_COUNT_AS_RUNNING [24975,24998]
name: STATES_COUNT_AS_RUNNING [24970,24993]
===
match
---
expr_stmt [37353,37700]
expr_stmt [37348,37695]
===
match
---
simple_stmt [2136,2192]
simple_stmt [2136,2192]
===
match
---
expr_stmt [32813,32856]
expr_stmt [32808,32851]
===
match
---
trailer [33683,33688]
trailer [33678,33683]
===
match
---
name: len [34610,34613]
name: len [34605,34608]
===
match
---
simple_stmt [7209,7242]
simple_stmt [7209,7242]
===
match
---
name: self [35635,35639]
name: self [35630,35634]
===
match
---
param [4234,4246]
param [4234,4246]
===
match
---
operator: , [28403,28404]
operator: , [28398,28399]
===
match
---
simple_stmt [11403,11483]
simple_stmt [11398,11478]
===
match
---
param [4492,4508]
param [4492,4508]
===
match
---
name: _process_backfill_task_instances [16263,16295]
name: _process_backfill_task_instances [16258,16290]
===
match
---
name: key [11534,11537]
name: key [11529,11532]
===
match
---
name: add [23963,23966]
name: add [23958,23961]
===
match
---
atom_expr [10633,10639]
atom_expr [10628,10634]
===
match
---
operator: = [17333,17334]
operator: = [17328,17329]
===
match
---
not_test [38035,38044]
not_test [38030,38039]
===
match
---
trailer [31969,31992]
trailer [31964,31987]
===
match
---
simple_stmt [15590,16127]
simple_stmt [15585,16122]
===
match
---
trailer [31622,31634]
trailer [31617,31629]
===
match
---
name: ti_status [23328,23337]
name: ti_status [23323,23332]
===
match
---
import_from [1820,1862]
import_from [1820,1862]
===
match
---
name: running [23040,23047]
name: running [23035,23042]
===
match
---
name: State [9346,9351]
name: State [9346,9351]
===
match
---
param [30347,30358]
param [30342,30353]
===
match
---
trailer [9515,9522]
trailer [9515,9522]
===
match
---
name: deadlocked [4849,4859]
name: deadlocked [4849,4859]
===
match
---
simple_stmt [7493,7516]
simple_stmt [7493,7516]
===
match
---
suite [10265,10646]
suite [10260,10641]
===
match
---
name: reset_tis [38153,38162]
name: reset_tis [38148,38157]
===
match
---
arglist [16151,16231]
arglist [16146,16226]
===
match
---
string: '\n\t' [38635,38641]
string: '\n\t' [38630,38636]
===
match
---
operator: , [28314,28315]
operator: , [28309,28310]
===
match
---
atom_expr [37908,37914]
atom_expr [37903,37909]
===
match
---
argument [31856,31875]
argument [31851,31870]
===
match
---
param [5471,5495]
param [5471,5495]
===
match
---
operator: = [31801,31802]
operator: = [31796,31797]
===
match
---
name: executor [37158,37166]
name: executor [37153,37161]
===
match
---
atom_expr [28371,28380]
atom_expr [28366,28375]
===
match
---
name: dagrun_end_date [33103,33118]
name: dagrun_end_date [33098,33113]
===
match
---
name: pop [18530,18533]
name: pop [18525,18528]
===
match
---
operator: , [27990,27991]
operator: , [27985,27986]
===
match
---
argument [13157,13172]
argument [13152,13167]
===
match
---
atom_expr [17405,17421]
atom_expr [17400,17416]
===
match
---
trailer [7497,7505]
trailer [7497,7505]
===
match
---
atom_expr [17506,17559]
atom_expr [17501,17554]
===
match
---
name: log [26227,26230]
name: log [26222,26225]
===
match
---
name: key [18756,18759]
name: key [18751,18754]
===
match
---
name: dag_run [31505,31512]
name: dag_run [31500,31507]
===
match
---
return_stmt [38062,38075]
return_stmt [38057,38070]
===
match
---
atom_expr [21380,21465]
atom_expr [21375,21460]
===
match
---
name: ti [18182,18184]
name: ti [18177,18179]
===
match
---
simple_stmt [7645,7688]
simple_stmt [7645,7688]
===
match
---
argument [31825,31842]
argument [31820,31837]
===
match
---
atom_expr [29050,29202]
atom_expr [29045,29197]
===
match
---
operator: , [20207,20208]
operator: , [20202,20203]
===
match
---
simple_stmt [9188,9223]
simple_stmt [9188,9223]
===
match
---
atom_expr [32534,32546]
atom_expr [32529,32541]
===
match
---
atom_expr [22284,22301]
atom_expr [22279,22296]
===
match
---
trailer [19185,19191]
trailer [19180,19186]
===
match
---
name: TaskConcurrencyLimitReached [25893,25920]
name: TaskConcurrencyLimitReached [25888,25915]
===
match
---
name: State [10885,10890]
name: State [10880,10885]
===
match
---
atom_expr [7602,7620]
atom_expr [7602,7620]
===
match
---
trailer [4562,4569]
trailer [4562,4569]
===
match
---
simple_stmt [2197,2255]
simple_stmt [2197,2255]
===
match
---
expr_stmt [17320,17384]
expr_stmt [17315,17379]
===
match
---
expr_stmt [4608,4636]
expr_stmt [4608,4636]
===
match
---
atom_expr [31393,31445]
atom_expr [31388,31440]
===
match
---
sync_comp_for [38655,38673]
sync_comp_for [38650,38668]
===
match
---
atom [11764,12005]
atom [11759,12000]
===
match
---
operator: = [4708,4709]
operator: = [4708,4709]
===
match
---
name: try_number [28408,28418]
name: try_number [28403,28413]
===
match
---
operator: , [4533,4534]
operator: , [4533,4534]
===
match
---
trailer [18444,18492]
trailer [18439,18487]
===
match
---
name: warning [19236,19243]
name: warning [19231,19238]
===
match
---
expr_stmt [28546,28554]
expr_stmt [28541,28549]
===
match
---
dotted_name [1494,1527]
dotted_name [1494,1527]
===
match
---
trailer [9686,9690]
trailer [9686,9690]
===
match
---
name: ti [22239,22241]
name: ti [22234,22236]
===
match
---
name: self [31472,31476]
name: self [31467,31471]
===
match
---
name: self [5107,5111]
name: self [5107,5111]
===
match
---
name: reduced_key [8853,8864]
name: reduced_key [8853,8864]
===
match
---
trailer [9820,9827]
trailer [9815,9822]
===
match
---
trailer [31476,31504]
trailer [31471,31499]
===
match
---
expr_stmt [28356,28441]
expr_stmt [28351,28436]
===
match
---
operator: , [38576,38577]
operator: , [38571,38572]
===
match
---
atom_expr [20546,20576]
atom_expr [20541,20571]
===
match
---
atom_expr [34561,34577]
atom_expr [34556,34572]
===
match
---
name: DagRunType [13939,13949]
name: DagRunType [13934,13944]
===
match
---
return_stmt [28038,28124]
return_stmt [28033,28119]
===
match
---
atom_expr [18346,18359]
atom_expr [18341,18354]
===
match
---
return_stmt [13607,13618]
return_stmt [13602,13613]
===
match
---
simple_stmt [35970,36019]
simple_stmt [35965,36014]
===
match
---
name: BackfillUnfinished [1064,1082]
name: BackfillUnfinished [1064,1082]
===
match
---
comparison [20622,20676]
comparison [20617,20671]
===
match
---
trailer [11672,11679]
trailer [11667,11674]
===
match
---
name: executor [21333,21341]
name: executor [21328,21336]
===
match
---
operator: = [12202,12203]
operator: = [12197,12198]
===
match
---
simple_stmt [38520,38606]
simple_stmt [38515,38601]
===
match
---
argument [37806,37821]
argument [37801,37816]
===
match
---
operator: = [27929,27930]
operator: = [27924,27925]
===
match
---
atom_expr [21823,21840]
atom_expr [21818,21835]
===
match
---
name: running [8723,8730]
name: running [8723,8730]
===
match
---
string: """         This function checks if there are any tasks in the dagrun (or all) that         have a schedule or queued states but are not known by the executor. If         it finds those it will reset the state to None so they will get picked         up again.  The batch option is for performance reasons as the queries         are made in sequence.          :param filter_by_dag_run: the dag_run we want to process, None if all         :type filter_by_dag_run: airflow.models.DagRun         :return: the number of TIs reset         :rtype: int         """ [36444,37000]
string: """         This function checks if there are any tasks in the dagrun (or all) that         have a schedule or queued states but are not known by the executor. If         it finds those it will reset the state to None so they will get picked         up again.  The batch option is for performance reasons as the queries         are made in sequence.          :param filter_by_dag_run: the dag_run we want to process, None if all         :type filter_by_dag_run: airflow.models.DagRun         :return: the number of TIs reset         :rtype: int         """ [36439,36995]
===
match
---
suite [11741,12101]
suite [11736,12096]
===
match
---
and_test [34135,34344]
and_test [34130,34339]
===
match
---
param [7794,7806]
param [7794,7806]
===
match
---
operator: = [11344,11345]
operator: = [11339,11340]
===
match
---
name: self [23580,23584]
name: self [23575,23579]
===
match
---
name: provide_session [30254,30269]
name: provide_session [30249,30264]
===
match
---
string: "Finished dag run loop iteration. Remaining tasks %s" [16151,16204]
string: "Finished dag run loop iteration. Remaining tasks %s" [16146,16199]
===
match
---
trailer [19468,19487]
trailer [19463,19482]
===
match
---
name: session [31514,31521]
name: session [31509,31516]
===
match
---
atom_expr [27976,27990]
atom_expr [27971,27985]
===
match
---
simple_stmt [34778,34996]
simple_stmt [34773,34991]
===
match
---
operator: = [27136,27137]
operator: = [27131,27132]
===
match
---
atom_expr [15046,15069]
atom_expr [15041,15064]
===
match
---
name: DagRunType [14181,14191]
name: DagRunType [14176,14186]
===
match
---
name: total_runs [5069,5079]
name: total_runs [5069,5079]
===
match
---
not_test [34135,34156]
not_test [34130,34151]
===
match
---
operator: = [11181,11182]
operator: = [11176,11177]
===
match
---
trailer [15994,16001]
trailer [15989,15996]
===
match
---
name: ti [11700,11702]
name: ti [11695,11697]
===
match
---
or_test [4849,4868]
or_test [4849,4868]
===
match
---
trailer [32883,32897]
trailer [32878,32892]
===
match
---
atom_expr [7114,7124]
atom_expr [7114,7124]
===
match
---
trailer [17433,17452]
trailer [17428,17447]
===
match
---
name: ti_status [28704,28713]
name: ti_status [28699,28708]
===
match
---
trailer [18031,18035]
trailer [18026,18030]
===
match
---
name: refreshed_tis [8382,8395]
name: refreshed_tis [8382,8395]
===
match
---
name: run_date [12668,12676]
name: run_date [12663,12671]
===
match
---
trailer [12920,12944]
trailer [12915,12939]
===
match
---
name: dag_run [14748,14755]
name: dag_run [14743,14750]
===
match
---
trailer [12089,12100]
trailer [12084,12095]
===
match
---
name: error [9085,9090]
name: error [9085,9090]
===
match
---
name: key [20426,20429]
name: key [20421,20424]
===
match
---
operator: , [35212,35213]
operator: , [35207,35208]
===
match
---
operator: , [23292,23293]
operator: , [23287,23288]
===
match
---
name: dep_context [21223,21234]
name: dep_context [21218,21229]
===
match
---
name: session [13873,13880]
name: session [13868,13875]
===
match
---
operator: , [5149,5150]
operator: , [5149,5150]
===
match
---
trailer [24303,24308]
trailer [24298,24303]
===
match
---
expr_stmt [34491,34515]
expr_stmt [34486,34510]
===
match
---
trailer [32489,32498]
trailer [32484,32493]
===
match
---
name: values [33438,33444]
name: values [33433,33439]
===
match
---
name: session [14242,14249]
name: session [14237,14244]
===
match
---
name: tasks_to_run [15528,15540]
name: tasks_to_run [15523,15535]
===
match
---
name: start_date [7154,7164]
name: start_date [7154,7164]
===
match
---
atom_expr [19607,19628]
atom_expr [19602,19623]
===
match
---
simple_stmt [37976,37985]
simple_stmt [37971,37980]
===
match
---
atom_expr [37521,37534]
atom_expr [37516,37529]
===
match
---
suite [22832,23127]
suite [22827,23122]
===
match
---
name: key [23748,23751]
name: key [23743,23746]
===
match
---
name: set_ti_keys [27755,27766]
name: set_ti_keys [27750,27761]
===
match
---
name: self [17506,17510]
name: self [17501,17505]
===
match
---
name: dag [7088,7091]
name: dag [7088,7091]
===
match
---
operator: , [28392,28393]
operator: , [28387,28388]
===
match
---
name: session [28954,28961]
name: session [28949,28956]
===
match
---
trailer [22153,22155]
trailer [22148,22150]
===
insert-node
---
name: BackfillJob [1871,1882]
to
classdef [1865,38834]
at 0
===
insert-node
---
name: BaseJob [1883,1890]
to
classdef [1865,38834]
at 1
===
insert-tree
---
simple_stmt [1897,2131]
    string: """     A backfill job consists of a dag or subdag for a specific time range. It     triggers a set of task instance runs, in the right order and lasts for     as long as it takes for the set of task instance to be completed.     """ [1897,2130]
to
suite [1892,38834]
at 0
===
insert-node
---
trailer [9781,9789]
to
atom_expr [9760,9794]
at 3
===
insert-node
---
atom_expr [9782,9788]
to
trailer [9781,9789]
at 0
===
move-tree
---
trailer [9781,9794]
    name: reduced_key [9782,9793]
to
atom_expr [9782,9788]
at 1
===
update-node
---
name: reduced_key [9782,9793]
replace reduced_key by key
===
delete-node
---
name: BackfillJob [1871,1882]
===
===
delete-node
---
name: BaseJob [1883,1890]
===
===
delete-tree
---
simple_stmt [1897,2131]
    string: """     A backfill job consists of a dag or subdag for a specific time range. It     triggers a set of task instance runs, in the right order and lasts for     as long as it takes for the set of task instance to be completed.     """ [1897,2130]
