===
match
---
trailer [4908,4913]
trailer [4908,4913]
===
match
---
param [5046,5093]
param [5046,5093]
===
match
---
operator: = [6088,6089]
operator: = [6088,6089]
===
match
---
trailer [5169,5196]
trailer [5169,5196]
===
match
---
name: str [5288,5291]
name: str [5288,5291]
===
match
---
name: self [6481,6485]
name: self [6481,6485]
===
match
---
trailer [6697,6704]
trailer [6697,6704]
===
match
---
expr_stmt [4425,4583]
expr_stmt [4425,4583]
===
match
---
name: Dict [886,890]
name: Dict [886,890]
===
match
---
name: str [5176,5179]
name: str [5176,5179]
===
match
---
name: self [6025,6029]
name: self [6025,6029]
===
match
---
name: extra_args [6913,6923]
name: extra_args [6913,6923]
===
match
---
atom_expr [4748,4761]
atom_expr [4748,4761]
===
match
---
name: dest_verify [5046,5057]
name: dest_verify [5046,5057]
===
match
---
dotted_name [986,1023]
dotted_name [986,1023]
===
match
---
trailer [5789,5799]
trailer [5789,5799]
===
match
---
expr_stmt [6025,6047]
expr_stmt [6025,6047]
===
match
---
simple_stmt [7518,7588]
simple_stmt [7518,7588]
===
match
---
name: file [7724,7728]
name: file [7724,7728]
===
match
---
name: str [4832,4835]
name: str [4832,4835]
===
match
---
if_stmt [5378,5718]
if_stmt [5378,5718]
===
match
---
name: self [5820,5824]
name: self [5820,5824]
===
match
---
operator: = [4456,4457]
operator: = [4456,4457]
===
match
---
operator: = [7533,7534]
operator: = [7533,7534]
===
match
---
atom_expr [6339,6523]
atom_expr [6339,6523]
===
match
---
tfpdef [5264,5292]
tfpdef [5264,5292]
===
match
---
name: file [7843,7847]
name: file [7843,7847]
===
match
---
operator: * [4670,4671]
operator: * [4670,4671]
===
match
---
atom_expr [6665,6679]
atom_expr [6665,6679]
===
match
---
trailer [8225,8274]
trailer [8249,8298]
===
match
---
name: Optional [4900,4908]
name: Optional [4900,4908]
===
match
---
name: dest_s3_key [7953,7964]
name: dest_s3_key [7977,7988]
===
match
---
trailer [6485,6512]
trailer [6485,6512]
===
match
---
atom_expr [6056,6087]
atom_expr [6056,6087]
===
match
---
name: bucket_name [6743,6754]
name: bucket_name [6743,6754]
===
match
---
name: replace [6979,6986]
name: replace [6979,6986]
===
match
---
param [5133,5204]
param [5133,5204]
===
match
---
string: '' [7713,7715]
string: '' [7713,7715]
===
match
---
atom_expr [7887,7919]
atom_expr [7887,7943]
===
match
---
operator: = [5800,5801]
operator: = [5800,5801]
===
match
---
operator: , [4476,4477]
operator: , [4476,4477]
===
match
---
string: 'google_cloud_default' [4838,4860]
string: 'google_cloud_default' [4838,4860]
===
match
---
name: prefix [7409,7415]
name: prefix [7409,7415]
===
match
---
name: kwargs [5361,5367]
name: kwargs [5361,5367]
===
match
---
name: warnings [5423,5431]
name: warnings [5423,5431]
===
match
---
suite [7857,8199]
suite [7857,8223]
===
match
---
trailer [6737,6742]
trailer [6737,6742]
===
match
---
name: existing_files [7518,7532]
name: existing_files [7518,7532]
===
match
---
name: delegate_to [4930,4941]
name: delegate_to [4930,4941]
===
match
---
operator: = [5837,5838]
operator: = [5837,5838]
===
match
---
string: """This module contains Google Cloud Storage to S3 operator.""" [787,850]
string: """This module contains Google Cloud Storage to S3 operator.""" [787,850]
===
match
---
trailer [7905,7912]
trailer [7935,7942]
===
match
---
atom_expr [5785,5799]
atom_expr [5785,5799]
===
match
---
operator: , [5092,5093]
operator: , [5092,5093]
===
match
---
name: airflow [1104,1111]
name: airflow [1104,1111]
===
match
---
trailer [7395,7423]
trailer [7395,7423]
===
match
---
operator: , [7194,7195]
operator: , [7194,7195]
===
match
---
simple_stmt [941,981]
simple_stmt [941,981]
===
match
---
name: impersonation_chain [6461,6480]
name: impersonation_chain [6461,6480]
===
match
---
name: dest_aws_conn_id [4973,4989]
name: dest_aws_conn_id [4973,4989]
===
match
---
name: files [8267,8272]
name: files [8291,8296]
===
match
---
atom_expr [7901,7912]
atom_expr [7931,7942]
===
match
---
name: Sequence [5181,5189]
name: Sequence [5181,5189]
===
match
---
operator: = [6797,6798]
operator: = [6797,6798]
===
match
---
name: self [5859,5863]
name: self [5859,5863]
===
match
---
operator: , [6786,6787]
operator: , [6786,6787]
===
match
---
operator: -> [5325,5327]
operator: -> [5325,5327]
===
match
---
simple_stmt [8373,8386]
simple_stmt [8397,8410]
===
match
---
atom_expr [5727,5738]
atom_expr [5727,5738]
===
match
---
atom_expr [7948,7964]
atom_expr [7972,7988]
===
match
---
param [4930,4964]
param [4930,4964]
===
match
---
suite [6987,7807]
suite [6987,7807]
===
match
---
name: replace [6040,6047]
name: replace [6040,6047]
===
match
---
atom_expr [6895,6911]
atom_expr [6895,6911]
===
match
---
trailer [7891,7900]
trailer [7891,7900]
===
match
---
operator: = [4995,4996]
operator: = [4995,4996]
===
match
---
trailer [5990,6002]
trailer [5990,6002]
===
match
---
operator: = [7415,7416]
operator: = [7415,7416]
===
match
---
name: dest_s3_extra_args [5213,5231]
name: dest_s3_extra_args [5213,5231]
===
match
---
name: log [8217,8220]
name: log [8241,8244]
===
match
---
operator: , [4860,4861]
operator: , [4860,4861]
===
match
---
name: dest_key [8023,8031]
name: dest_key [8047,8055]
===
match
---
argument [8115,8127]
argument [8139,8151]
===
match
---
name: verify [6888,6894]
name: verify [6888,6894]
===
match
---
atom_expr [5820,5836]
atom_expr [5820,5836]
===
match
---
name: amazon [1004,1010]
name: amazon [1004,1010]
===
match
---
atom_expr [6733,6813]
atom_expr [6733,6813]
===
match
---
operator: , [7715,7716]
operator: , [7715,7716]
===
match
---
operator: = [8136,8137]
operator: = [8160,8161]
===
match
---
trailer [8094,8113]
trailer [8118,8137]
===
match
---
name: aws [1011,1014]
name: aws [1011,1014]
===
match
---
operator: , [4920,4921]
operator: , [4920,4921]
===
match
---
arglist [8226,8273]
arglist [8250,8297]
===
match
---
operator: = [5768,5769]
operator: = [5768,5769]
===
match
---
name: prefix [6698,6704]
name: prefix [6698,6704]
===
match
---
name: self [8137,8141]
name: self [8161,8165]
===
match
---
param [6242,6249]
param [6242,6249]
===
match
---
operator: , [7407,7408]
operator: , [7407,7408]
===
match
---
name: self [6431,6435]
name: self [6431,6435]
===
match
---
operator: , [890,891]
operator: , [890,891]
===
match
---
simple_stmt [6533,6716]
simple_stmt [6533,6716]
===
match
---
name: Optional [908,916]
name: Optional [908,916]
===
match
---
name: delimiter [6803,6812]
name: delimiter [6803,6812]
===
match
---
name: str [4952,4955]
name: str [4952,4955]
===
match
---
name: self [7988,7992]
name: self [8012,8016]
===
match
---
operator: , [5036,5037]
operator: , [5036,5037]
===
match
---
arith_expr [7948,7971]
arith_expr [7972,7995]
===
match
---
operator: , [4671,4672]
operator: , [4671,4672]
===
match
---
name: execute [6228,6235]
name: execute [6228,6235]
===
match
---
atom_expr [7205,7242]
atom_expr [7205,7242]
===
match
---
name: dest_s3_key [5966,5977]
name: dest_s3_key [5966,5977]
===
match
---
argument [5635,5647]
argument [5635,5647]
===
match
---
operator: = [6337,6338]
operator: = [6337,6338]
===
match
---
name: GCSHook [6339,6346]
name: GCSHook [6339,6346]
===
match
---
simple_stmt [981,1038]
simple_stmt [981,1038]
===
match
---
atom_expr [5279,5292]
atom_expr [5279,5292]
===
match
---
atom_expr [6533,6715]
atom_expr [6533,6715]
===
match
---
name: self [5898,5902]
name: self [5898,5902]
===
match
---
name: ui_color [4588,4596]
name: ui_color [4588,4596]
===
match
---
argument [6360,6405]
argument [6360,6405]
===
match
---
name: delegate_to [6419,6430]
name: delegate_to [6419,6430]
===
match
---
trailer [8001,8032]
trailer [8025,8056]
===
match
---
name: existing_files [7732,7746]
name: existing_files [7732,7746]
===
match
---
name: aws_conn_id [6853,6864]
name: aws_conn_id [6853,6864]
===
match
---
operator: = [6774,6775]
operator: = [6774,6775]
===
match
---
operator: = [4914,4915]
operator: = [4914,4915]
===
match
---
operator: } [6174,6175]
operator: } [6174,6175]
===
match
---
name: Iterable [4442,4450]
name: Iterable [4442,4450]
===
match
---
name: len [8263,8266]
name: len [8287,8290]
===
match
---
atom_expr [4789,4802]
atom_expr [4789,4802]
===
match
---
name: models [954,960]
name: models [954,960]
===
match
---
atom_expr [5181,5194]
atom_expr [5181,5194]
===
match
---
operator: , [7711,7712]
operator: , [7711,7712]
===
match
---
operator: , [5203,5204]
operator: , [5203,5204]
===
match
---
name: Union [5170,5175]
name: Union [5170,5175]
===
match
---
suite [5333,6219]
suite [5333,6219]
===
match
---
trailer [5760,5767]
trailer [5760,5767]
===
match
---
name: delimiter [5802,5811]
name: delimiter [5802,5811]
===
match
---
expr_stmt [7760,7806]
expr_stmt [7760,7806]
===
match
---
name: GCSToS3Operator [1159,1174]
name: GCSToS3Operator [1159,1174]
===
match
---
arglist [6360,6513]
arglist [6360,6513]
===
match
---
name: files [7760,7765]
name: files [7760,7765]
===
match
---
string: 'delimiter' [4504,4515]
string: 'delimiter' [4504,4515]
===
match
---
trailer [8068,8198]
trailer [8092,8222]
===
match
---
name: file_bytes [8102,8112]
name: file_bytes [8126,8136]
===
match
---
expr_stmt [4588,4608]
expr_stmt [4588,4608]
===
match
---
atom_expr [5756,5767]
atom_expr [5756,5767]
===
match
---
name: BaseOperator [1175,1187]
name: BaseOperator [1175,1187]
===
match
---
name: google_impersonation_chain [5133,5159]
name: google_impersonation_chain [5133,5159]
===
match
---
simple_stmt [6125,6176]
simple_stmt [6125,6176]
===
match
---
expr_stmt [5820,5850]
expr_stmt [5820,5850]
===
match
---
operator: , [8021,8022]
operator: , [8045,8046]
===
match
---
suite [7825,8275]
suite [7825,8299]
===
match
---
name: s3_acl_policy [6189,6202]
name: s3_acl_policy [6189,6202]
===
match
---
operator: , [6626,6627]
operator: , [6626,6627]
===
match
---
atom_expr [5068,5084]
atom_expr [5068,5084]
===
match
---
atom [7585,7587]
atom [7585,7587]
===
match
---
trailer [5347,5349]
trailer [5347,5349]
===
match
---
arglist [5454,5648]
arglist [5454,5648]
===
match
---
trailer [5358,5368]
trailer [5358,5368]
===
match
---
operator: = [6831,6832]
operator: = [6831,6832]
===
match
---
name: info [6542,6546]
name: info [6542,6546]
===
match
---
trailer [7696,7704]
trailer [7696,7704]
===
match
---
operator: = [7766,7767]
operator: = [7766,7767]
===
match
---
name: gcp_conn_id [4819,4830]
name: gcp_conn_id [4819,4830]
===
match
---
name: s3_hook [7378,7385]
name: s3_hook [7378,7385]
===
match
---
name: self [5727,5731]
name: self [5727,5731]
===
match
---
tfpdef [5046,5085]
tfpdef [5046,5085]
===
match
---
name: str [5190,5193]
name: str [5190,5193]
===
match
---
name: cast [935,939]
name: cast [935,939]
===
match
---
simple_stmt [7674,7748]
simple_stmt [7674,7748]
===
match
---
name: delimiter [6670,6679]
name: delimiter [6670,6679]
===
match
---
name: GCSHook [1091,1098]
name: GCSHook [1091,1098]
===
match
---
name: info [8221,8225]
name: info [8245,8249]
===
match
---
name: dest_aws_conn_id [6870,6886]
name: dest_aws_conn_id [6870,6886]
===
match
---
atom_expr [5423,5662]
atom_expr [5423,5662]
===
match
---
name: S3Hook [7205,7211]
name: S3Hook [7205,7211]
===
match
---
atom_expr [6798,6812]
atom_expr [6798,6812]
===
match
---
name: self [6125,6129]
name: self [6125,6129]
===
match
---
decorated [4614,6219]
decorated [4614,6219]
===
match
---
parameters [4646,5324]
parameters [4646,5324]
===
match
---
expr_stmt [6125,6175]
expr_stmt [6125,6175]
===
match
---
simple_stmt [5785,5812]
simple_stmt [5785,5812]
===
match
---
name: self [7225,7229]
name: self [7225,7229]
===
match
---
arglist [7901,7918]
arglist [7901,7942]
===
match
---
name: download [7892,7900]
name: download [7892,7900]
===
match
---
operator: = [6480,6481]
operator: = [6480,6481]
===
match
---
atom_expr [4442,4455]
atom_expr [4442,4455]
===
match
---
simple_stmt [1099,1151]
simple_stmt [1099,1151]
===
match
---
simple_stmt [5756,5777]
simple_stmt [5756,5777]
===
match
---
param [4870,4921]
param [4870,4921]
===
match
---
string: 'aws_default' [4997,5010]
string: 'aws_default' [4997,5010]
===
match
---
name: set [7773,7776]
name: set [7773,7776]
===
match
---
operator: , [5010,5011]
operator: , [5010,5011]
===
match
---
param [4656,4661]
param [4656,4661]
===
match
---
name: load_bytes [8058,8068]
name: load_bytes [8082,8092]
===
match
---
name: Optional [5059,5067]
name: Optional [5059,5067]
===
match
---
operator: = [5086,5087]
operator: = [5086,5087]
===
match
---
atom_expr [7378,7423]
atom_expr [7378,7423]
===
match
---
atom_expr [6833,6957]
atom_expr [6833,6957]
===
match
---
name: gcp_conn_id [5825,5836]
name: gcp_conn_id [5825,5836]
===
match
---
if_stmt [7816,8364]
if_stmt [7816,8388]
===
match
---
trailer [8266,8273]
trailer [8290,8297]
===
match
---
operator: , [6911,6912]
operator: , [6911,6912]
===
match
---
string: "the gcp_conn_id parameter." [5553,5581]
string: "the gcp_conn_id parameter." [5553,5581]
===
match
---
import_from [981,1037]
import_from [981,1037]
===
match
---
name: hook [6733,6737]
name: hook [6733,6737]
===
match
---
name: self [6184,6188]
name: self [6184,6188]
===
match
---
expr_stmt [5675,5717]
expr_stmt [5675,5717]
===
match
---
operator: , [4538,4539]
operator: , [4538,4539]
===
match
---
classdef [1153,8386]
classdef [1153,8410]
===
match
---
arglist [6853,6947]
arglist [6853,6947]
===
match
---
operator: , [5299,5300]
operator: , [5299,5300]
===
match
---
name: Union [5068,5073]
name: Union [5068,5073]
===
match
---
tfpdef [4740,4761]
tfpdef [4740,4761]
===
match
---
name: str [4909,4912]
name: str [4909,4912]
===
match
---
name: s3_acl_policy [6205,6218]
name: s3_acl_policy [6205,6218]
===
match
---
arglist [8095,8112]
arglist [8119,8136]
===
match
---
atom_expr [8050,8198]
atom_expr [8074,8222]
===
match
---
expr_stmt [7674,7747]
expr_stmt [7674,7747]
===
match
---
string: "Saving file to %s" [8002,8021]
string: "Saving file to %s" [8026,8045]
===
match
---
operator: , [5581,5582]
operator: , [5581,5582]
===
match
---
operator: , [4494,4495]
operator: , [4494,4495]
===
match
---
name: google_impersonation_chain [6486,6512]
name: google_impersonation_chain [6486,6512]
===
match
---
not_test [6970,6986]
not_test [6970,6986]
===
match
---
name: Optional [5233,5241]
name: Optional [5233,5241]
===
match
---
name: bool [5079,5083]
name: bool [5079,5083]
===
match
---
trailer [5951,5963]
trailer [5951,5963]
===
match
---
name: log [8306,8309]
name: log [8330,8333]
===
match
---
name: dest_aws_conn_id [5922,5938]
name: dest_aws_conn_id [5922,5938]
===
match
---
name: replace [8142,8149]
name: replace [8166,8173]
===
match
---
annassign [4440,4583]
annassign [4440,4583]
===
match
---
testlist_star_expr [7183,7202]
testlist_star_expr [7183,7202]
===
match
---
name: cast [8090,8094]
name: cast [8114,8118]
===
match
---
operator: , [6405,6406]
operator: , [6405,6406]
===
match
---
operator: , [5179,5180]
operator: , [5179,5180]
===
match
---
trailer [7992,7996]
trailer [8016,8020]
===
match
---
trailer [5902,5919]
trailer [5902,5919]
===
match
---
operator: = [6388,6389]
operator: = [6388,6389]
===
match
---
name: file [7692,7696]
name: file [7692,7696]
===
match
---
name: apply_defaults [4615,4629]
name: apply_defaults [4615,4629]
===
match
---
import_as_names [886,939]
import_as_names [886,939]
===
match
---
name: bucket [7906,7912]
name: bucket [7936,7942]
===
match
---
name: str [4798,4801]
name: str [4798,4801]
===
match
---
number: 3 [5646,5647]
number: 3 [5646,5647]
===
match
---
expr_stmt [7361,7423]
expr_stmt [7361,7423]
===
match
---
simple_stmt [5675,5718]
simple_stmt [5675,5718]
===
match
---
name: google_cloud_storage_conn_id [6360,6388]
name: google_cloud_storage_conn_id [6360,6388]
===
match
---
name: utils [1112,1117]
name: utils [1112,1117]
===
match
---
name: dest_s3_extra_args [6929,6947]
name: dest_s3_extra_args [6929,6947]
===
match
---
operator: = [5248,5249]
operator: = [5248,5249]
===
match
---
name: bucket [6645,6651]
name: bucket [6645,6651]
===
match
---
atom_expr [5898,5919]
atom_expr [5898,5919]
===
match
---
simple_stmt [8050,8199]
simple_stmt [8074,8223]
===
match
---
simple_stmt [6025,6048]
simple_stmt [6025,6048]
===
match
---
dotted_name [1043,1083]
dotted_name [1043,1083]
===
match
---
simple_stmt [5342,5369]
simple_stmt [5342,5369]
===
match
---
trailer [8057,8068]
trailer [8081,8092]
===
match
---
trailer [6435,6447]
trailer [6435,6447]
===
match
---
name: super [5342,5347]
name: super [5342,5347]
===
match
---
simple_stmt [7183,7243]
simple_stmt [7183,7243]
===
match
---
name: __init__ [5350,5358]
name: __init__ [5350,5358]
===
match
---
name: existing_files [7674,7688]
name: existing_files [7674,7688]
===
match
---
expr_stmt [6332,6523]
expr_stmt [6332,6523]
===
match
---
atom_expr [6865,6886]
atom_expr [6865,6886]
===
match
---
atom_expr [6481,6512]
atom_expr [6481,6512]
===
match
---
arglist [7705,7718]
arglist [7705,7718]
===
match
---
name: file_bytes [7874,7884]
name: file_bytes [7874,7884]
===
match
---
operator: = [4597,4598]
operator: = [4597,4598]
===
match
---
name: decorators [1118,1128]
name: decorators [1118,1128]
===
match
---
name: s3_hook [6823,6830]
name: s3_hook [6823,6830]
===
match
---
name: Optional [4748,4756]
name: Optional [4748,4756]
===
match
---
name: replace [5102,5109]
name: replace [5102,5109]
===
match
---
trailer [6644,6651]
trailer [6644,6651]
===
match
---
param [4973,5011]
param [4973,5011]
===
match
---
atom_expr [7786,7805]
atom_expr [7786,7805]
===
match
---
name: S3Hook [1031,1037]
name: S3Hook [1031,1037]
===
match
---
name: existing_files [7361,7375]
name: existing_files [7361,7375]
===
match
---
parameters [6235,6250]
parameters [6235,6250]
===
match
---
trailer [6669,6679]
trailer [6669,6679]
===
match
---
operator: ** [5309,5311]
operator: ** [5309,5311]
===
match
---
operator: ** [5359,5361]
operator: ** [5359,5361]
===
match
---
param [5020,5037]
param [5020,5037]
===
match
---
name: gcp_conn_id [6394,6405]
name: gcp_conn_id [6394,6405]
===
match
---
operator: , [5077,5078]
operator: , [5077,5078]
===
match
---
trailer [7789,7805]
trailer [7789,7805]
===
match
---
operator: + [7965,7966]
operator: + [7989,7990]
===
match
---
if_stmt [6967,7807]
if_stmt [6967,7807]
===
match
---
name: Optional [4943,4951]
name: Optional [4943,4951]
===
match
---
name: dest_verify [6005,6016]
name: dest_verify [6005,6016]
===
match
---
atom_expr [6184,6202]
atom_expr [6184,6202]
===
match
---
name: google_cloud_storage_conn_id [5689,5717]
name: google_cloud_storage_conn_id [5689,5717]
===
match
---
comparison [7553,7579]
comparison [7553,7579]
===
match
---
name: hooks [1015,1020]
name: hooks [1015,1020]
===
match
---
name: airflow [986,993]
name: airflow [986,993]
===
match
---
name: dest_key [7937,7945]
name: dest_key [7961,7969]
===
match
---
tfpdef [5020,5036]
tfpdef [5020,5036]
===
match
---
name: self [6389,6393]
name: self [6389,6393]
===
match
---
trailer [6393,6405]
trailer [6393,6405]
===
match
---
name: s3_hook [8050,8057]
name: s3_hook [8074,8081]
===
match
---
string: 'prefix' [4486,4494]
string: 'prefix' [4486,4494]
===
match
---
subscriptlist [5074,5083]
subscriptlist [5074,5083]
===
match
---
simple_stmt [8301,8364]
simple_stmt [8325,8388]
===
match
---
operator: , [6240,6241]
operator: , [6240,6241]
===
match
---
name: str [5033,5036]
name: str [5033,5036]
===
match
---
operator: = [6038,6039]
operator: = [6038,6039]
===
match
---
comp_op [7568,7574]
comp_op [7568,7574]
===
match
---
testlist_comp [7692,7746]
testlist_comp [7692,7746]
===
match
---
or_test [6151,6175]
or_test [6151,6175]
===
match
---
atom_expr [6775,6786]
atom_expr [6775,6786]
===
match
---
operator: , [6512,6513]
operator: , [6512,6513]
===
match
---
trailer [5073,5084]
trailer [5073,5084]
===
match
---
name: airflow [946,953]
name: airflow [946,953]
===
match
---
simple_stmt [851,867]
simple_stmt [851,867]
===
match
---
name: template_fields [4425,4440]
name: template_fields [4425,4440]
===
match
---
expr_stmt [6184,6218]
expr_stmt [6184,6218]
===
match
---
name: list [7768,7772]
name: list [7768,7772]
===
match
---
operator: = [5116,5117]
operator: = [5116,5117]
===
match
---
suite [6264,8386]
suite [6264,8410]
===
match
---
name: self [6775,6779]
name: self [6775,6779]
===
match
---
atom_expr [4943,4956]
atom_expr [4943,4956]
===
match
---
atom_expr [6755,6766]
atom_expr [6755,6766]
===
match
---
param [5264,5300]
param [5264,5300]
===
match
---
import_from [1038,1098]
import_from [1038,1098]
===
match
---
name: dest_s3_extra_args [6130,6148]
name: dest_s3_extra_args [6130,6148]
===
match
---
atom [6173,6175]
atom [6173,6175]
===
match
---
trailer [5349,5358]
trailer [5349,5358]
===
match
---
name: files [7819,7824]
name: files [7819,7824]
===
match
---
name: cloud [1068,1073]
name: cloud [1068,1073]
===
match
---
operator: = [4762,4763]
operator: = [4762,4763]
===
match
---
operator: = [6203,6204]
operator: = [6203,6204]
===
match
---
simple_stmt [7361,7424]
simple_stmt [7361,7424]
===
match
---
name: bucket [5741,5747]
name: bucket [5741,5747]
===
match
---
atom_expr [6254,6263]
atom_expr [6254,6263]
===
match
---
name: bucket [5732,5738]
name: bucket [5732,5738]
===
match
---
operator: , [5617,5618]
operator: , [5617,5618]
===
match
---
name: str [4727,4730]
name: str [4727,4730]
===
match
---
simple_stmt [5986,6017]
simple_stmt [5986,6017]
===
match
---
name: self [5756,5760]
name: self [5756,5760]
===
match
---
operator: = [5876,5877]
operator: = [5876,5877]
===
match
---
operator: , [4660,4661]
operator: , [4660,4661]
===
match
---
trailer [5067,5085]
trailer [5067,5085]
===
match
---
operator: = [7689,7690]
operator: = [7689,7690]
===
match
---
name: str [6259,6262]
name: str [6259,6262]
===
match
---
operator: @ [4614,4615]
operator: @ [4614,4615]
===
match
---
operator: , [4576,4577]
operator: , [4576,4577]
===
match
---
argument [6888,6911]
argument [6888,6911]
===
match
---
trailer [6346,6523]
trailer [6346,6523]
===
match
---
operator: , [6651,6652]
operator: , [6651,6652]
===
match
---
expr_stmt [6725,6813]
expr_stmt [6725,6813]
===
match
---
operator: { [6173,6174]
operator: { [6173,6174]
===
match
---
name: list_keys [7386,7395]
name: list_keys [7386,7395]
===
match
---
name: Optional [5279,5287]
name: Optional [5279,5287]
===
match
---
name: self [6640,6644]
name: self [6640,6644]
===
match
---
operator: = [5739,5740]
operator: = [5739,5740]
===
match
---
simple_stmt [5820,5851]
simple_stmt [5820,5851]
===
match
---
trailer [5189,5194]
trailer [5189,5194]
===
match
---
operator: , [8149,8150]
operator: , [8173,8174]
===
match
---
name: Iterable [892,900]
name: Iterable [892,900]
===
match
---
name: self [5986,5990]
name: self [5986,5990]
===
match
---
trailer [6537,6541]
trailer [6537,6541]
===
match
---
name: delegate_to [6436,6447]
name: delegate_to [6436,6447]
===
match
---
name: google_impersonation_chain [6090,6116]
name: google_impersonation_chain [6090,6116]
===
match
---
atom_expr [6431,6447]
atom_expr [6431,6447]
===
match
---
simple_stmt [6725,6814]
simple_stmt [6725,6814]
===
match
---
string: "The google_cloud_storage_conn_id parameter has been deprecated. You should pass " [5454,5536]
string: "The google_cloud_storage_conn_id parameter has been deprecated. You should pass " [5454,5536]
===
match
---
name: existing_files [7790,7804]
name: existing_files [7790,7804]
===
match
---
argument [8151,8180]
argument [8175,8204]
===
match
---
argument [8129,8149]
argument [8153,8173]
===
match
---
argument [6853,6886]
argument [6853,6886]
===
match
---
argument [6743,6766]
argument [6743,6766]
===
match
---
simple_stmt [787,851]
simple_stmt [787,851]
===
match
---
trailer [8220,8225]
trailer [8244,8249]
===
match
---
name: self [6865,6869]
name: self [6865,6869]
===
match
---
trailer [6839,6957]
trailer [6839,6957]
===
match
---
string: 'dest_s3_key' [4525,4538]
string: 'dest_s3_key' [4525,4538]
===
match
---
operator: , [906,907]
operator: , [906,907]
===
match
---
atom_expr [8162,8180]
atom_expr [8186,8204]
===
match
---
name: log [7993,7996]
name: log [8017,8020]
===
match
---
atom_expr [8212,8274]
atom_expr [8236,8298]
===
match
---
name: file [7967,7971]
name: file [7991,7995]
===
match
---
simple_stmt [6332,6524]
simple_stmt [6332,6524]
===
match
---
name: self [8212,8216]
name: self [8236,8240]
===
match
---
dotted_name [946,960]
dotted_name [946,960]
===
match
---
name: s3_acl_policy [8167,8180]
name: s3_acl_policy [8191,8204]
===
match
---
trailer [8314,8363]
trailer [8338,8387]
===
match
---
simple_stmt [6056,6117]
simple_stmt [6056,6117]
===
match
---
name: bucket_name [7396,7407]
name: bucket_name [7396,7407]
===
match
---
name: List [6254,6258]
name: List [6254,6258]
===
match
---
name: typing [872,878]
name: typing [872,878]
===
match
---
expr_stmt [5727,5747]
expr_stmt [5727,5747]
===
match
---
atom_expr [6693,6704]
atom_expr [6693,6704]
===
match
---
name: self [6665,6669]
name: self [6665,6669]
===
match
---
name: prefix [6780,6786]
name: prefix [6780,6786]
===
match
---
trailer [7224,7242]
trailer [7224,7242]
===
match
---
trailer [7229,7241]
trailer [7229,7241]
===
match
---
name: info [7997,8001]
name: info [8021,8025]
===
match
---
trailer [8216,8220]
trailer [8240,8244]
===
match
---
simple_stmt [867,940]
simple_stmt [867,940]
===
match
---
argument [6461,6512]
argument [6461,6512]
===
match
---
tfpdef [4819,4835]
tfpdef [4819,4835]
===
match
---
atom_expr [8137,8149]
atom_expr [8161,8173]
===
match
---
name: airflow [1043,1050]
name: airflow [1043,1050]
===
match
---
name: prefix [5761,5767]
name: prefix [5761,5767]
===
match
---
atom_expr [5059,5085]
atom_expr [5059,5085]
===
match
---
name: files [6725,6730]
name: files [6725,6730]
===
match
---
name: replace [6030,6037]
name: replace [6030,6037]
===
match
---
trailer [6258,6263]
trailer [6258,6263]
===
match
---
name: prefix [6768,6774]
name: prefix [6768,6774]
===
match
---
argument [5359,5367]
argument [5359,5367]
===
match
---
operator: = [5920,5921]
operator: = [5920,5921]
===
match
---
number: 1 [7717,7718]
number: 1 [7717,7718]
===
match
---
expr_stmt [7518,7587]
expr_stmt [7518,7587]
===
match
---
atom_expr [7768,7806]
atom_expr [7768,7806]
===
match
---
trailer [5824,5836]
trailer [5824,5836]
===
match
---
suite [8288,8364]
suite [8312,8388]
===
match
---
operator: = [6430,6431]
operator: = [6430,6431]
===
match
---
string: 'Getting list of the files. Bucket: %s; Delimiter: %s; Prefix: %s' [6560,6626]
string: 'Getting list of the files. Bucket: %s; Delimiter: %s; Prefix: %s' [6560,6626]
===
match
---
name: acl_policy [8151,8161]
name: acl_policy [8175,8185]
===
match
---
operator: , [6704,6705]
operator: , [6704,6705]
===
match
---
name: delimiter [4778,4787]
name: delimiter [4778,4787]
===
match
---
name: str [4451,4454]
name: str [4451,4454]
===
match
---
name: dest_s3_key [5020,5031]
name: dest_s3_key [5020,5031]
===
match
---
trailer [6129,6148]
trailer [6129,6148]
===
match
---
name: List [902,906]
name: List [902,906]
===
match
---
trailer [5431,5436]
trailer [5431,5436]
===
match
---
operator: , [6766,6767]
operator: , [6766,6767]
===
match
---
name: providers [1051,1060]
name: providers [1051,1060]
===
match
---
operator: = [7203,7204]
operator: = [7203,7204]
===
match
---
name: __init__ [4638,4646]
name: __init__ [4638,4646]
===
match
---
operator: = [7376,7377]
operator: = [7376,7377]
===
match
---
name: str [5074,5077]
name: str [5074,5077]
===
match
---
operator: , [916,917]
operator: , [916,917]
===
match
---
arith_expr [7773,7805]
arith_expr [7773,7805]
===
match
---
trailer [7900,7919]
trailer [7900,7943]
===
match
---
operator: = [5197,5198]
operator: = [5197,5198]
===
match
---
name: providers [994,1003]
name: providers [994,1003]
===
match
---
name: self [6533,6537]
name: self [6533,6537]
===
match
---
name: dest_verify [5991,6002]
name: dest_verify [5991,6002]
===
match
---
operator: , [6679,6680]
operator: , [6679,6680]
===
match
---
name: Union [928,933]
name: Union [928,933]
===
match
---
trailer [7772,7806]
trailer [7772,7806]
===
match
---
name: google_impersonation_chain [6061,6087]
name: google_impersonation_chain [6061,6087]
===
match
---
name: prefix [4740,4746]
name: prefix [4740,4746]
===
match
---
name: bytes [8095,8100]
name: bytes [8119,8124]
===
match
---
operator: , [8127,8128]
operator: , [8151,8152]
===
match
---
operator: , [4768,4769]
operator: , [4768,4769]
===
match
---
operator: = [6754,6755]
operator: = [6754,6755]
===
match
---
name: gcp_conn_id [5675,5686]
name: gcp_conn_id [5675,5686]
===
match
---
atom_expr [6125,6148]
atom_expr [6125,6148]
===
match
---
trailer [5241,5247]
trailer [5241,5247]
===
match
---
name: Optional [4789,4797]
name: Optional [4789,4797]
===
match
---
argument [7409,7422]
argument [7409,7422]
===
match
---
expr_stmt [6056,6116]
expr_stmt [6056,6116]
===
match
---
name: prefix [7416,7422]
name: prefix [7416,7422]
===
match
---
arglist [8090,8180]
arglist [8114,8204]
===
match
---
operator: = [6731,6732]
operator: = [6731,6732]
===
match
---
return_stmt [8373,8385]
return_stmt [8397,8409]
===
match
---
name: replace [7697,7704]
name: replace [7697,7704]
===
match
---
name: dest_s3_extra_args [6151,6169]
name: dest_s3_extra_args [6151,6169]
===
match
---
operator: , [5254,5255]
operator: , [5254,5255]
===
match
---
param [5213,5255]
param [5213,5255]
===
match
---
trailer [7385,7395]
trailer [7385,7395]
===
match
---
operator: = [5645,5646]
operator: = [5645,5646]
===
match
---
simple_stmt [5859,5890]
simple_stmt [5859,5890]
===
match
---
suite [1189,8386]
suite [1189,8410]
===
match
---
name: self [5785,5789]
name: self [5785,5789]
===
match
---
name: self [5947,5951]
name: self [5947,5951]
===
match
---
name: delegate_to [5864,5875]
name: delegate_to [5864,5875]
===
match
---
arglist [6560,6705]
arglist [6560,6705]
===
match
---
atom_expr [6389,6405]
atom_expr [6389,6405]
===
match
---
name: key [8115,8118]
name: key [8139,8142]
===
match
---
operator: = [5293,5294]
operator: = [5293,5294]
===
match
---
atom_expr [7225,7241]
atom_expr [7225,7241]
===
match
---
trailer [6759,6766]
trailer [6759,6766]
===
match
---
name: self [6895,6899]
name: self [6895,6899]
===
match
---
trailer [6899,6911]
trailer [6899,6911]
===
match
---
arglist [7396,7422]
arglist [7396,7422]
===
match
---
decorator [4614,4630]
decorator [4614,4630]
===
match
---
name: bucket_name [7183,7194]
name: bucket_name [7183,7194]
===
match
---
tfpdef [4778,4802]
tfpdef [4778,4802]
===
match
---
operator: , [8113,8114]
operator: , [8137,8138]
===
match
---
name: delimiter [5790,5799]
name: delimiter [5790,5799]
===
match
---
suite [5410,5718]
suite [5410,5718]
===
match
---
name: hook [6332,6336]
name: hook [6332,6336]
===
match
---
trailer [7776,7783]
trailer [7776,7783]
===
match
---
name: dest_s3_key [5952,5963]
name: dest_s3_key [5952,5963]
===
match
---
name: s3 [1021,1023]
name: s3 [1021,1023]
===
match
---
testlist_comp [4468,4577]
testlist_comp [4468,4577]
===
match
---
operator: = [6894,6895]
operator: = [6894,6895]
===
match
---
tfpdef [4973,4994]
tfpdef [4973,4994]
===
match
---
atom_expr [5170,5195]
atom_expr [5170,5195]
===
match
---
tfpdef [4719,4730]
tfpdef [4719,4730]
===
match
---
name: str [4991,4994]
name: str [4991,4994]
===
match
---
trailer [8166,8180]
trailer [8190,8204]
===
match
---
param [5102,5124]
param [5102,5124]
===
match
---
trailer [7211,7224]
trailer [7211,7224]
===
match
---
simple_stmt [1038,1099]
simple_stmt [1038,1099]
===
match
---
subscriptlist [5176,5194]
subscriptlist [5176,5194]
===
match
---
string: "In sync, no files needed to be uploaded to S3" [8315,8362]
string: "In sync, no files needed to be uploaded to S3" [8339,8386]
===
match
---
operator: , [5317,5318]
operator: , [5317,5318]
===
match
---
trailer [6978,6986]
trailer [6978,6986]
===
match
---
name: prefix [5770,5776]
name: prefix [5770,5776]
===
match
---
trailer [7996,8001]
trailer [8020,8025]
===
match
---
param [5309,5318]
param [5309,5318]
===
match
---
simple_stmt [5423,5663]
simple_stmt [5423,5663]
===
match
---
dotted_name [1104,1128]
dotted_name [1104,1128]
===
match
---
name: kwargs [5311,5317]
name: kwargs [5311,5317]
===
match
---
operator: = [6923,6924]
operator: = [6923,6924]
===
match
---
arglist [8002,8031]
arglist [8026,8055]
===
match
---
argument [6768,6786]
argument [6768,6786]
===
match
---
tfpdef [4870,4913]
tfpdef [4870,4913]
===
match
---
name: s3_acl_policy [5264,5277]
name: s3_acl_policy [5264,5277]
===
match
---
trailer [6928,6947]
trailer [6928,6947]
===
match
---
expr_stmt [7874,7919]
expr_stmt [7874,7943]
===
match
---
param [4719,4731]
param [4719,4731]
===
match
---
operator: , [5123,5124]
operator: , [5123,5124]
===
match
---
name: self [8301,8305]
name: self [8325,8329]
===
match
---
simple_stmt [5727,5748]
simple_stmt [5727,5748]
===
match
---
atom_expr [5161,5196]
atom_expr [5161,5196]
===
match
---
simple_stmt [4588,4609]
simple_stmt [4588,4609]
===
match
---
trailer [6541,6546]
trailer [6541,6546]
===
match
---
name: BaseOperator [968,980]
name: BaseOperator [968,980]
===
match
---
name: files [7777,7782]
name: files [7777,7782]
===
match
---
operator: = [8118,8119]
operator: = [8142,8143]
===
match
---
name: context [6242,6249]
name: context [6242,6249]
===
match
---
operator: = [4803,4804]
operator: = [4803,4804]
===
match
---
trailer [4450,4455]
trailer [4450,4455]
===
match
---
simple_stmt [5947,5978]
simple_stmt [5947,5978]
===
match
---
name: hooks [1074,1079]
name: hooks [1074,1079]
===
match
---
param [4819,4861]
param [4819,4861]
===
match
---
name: dest_verify [6900,6911]
name: dest_verify [6900,6911]
===
match
---
name: replace [8129,8136]
name: replace [8153,8160]
===
match
---
operator: , [933,934]
operator: , [933,934]
===
match
---
name: self [6974,6978]
name: self [6974,6978]
===
match
---
name: info [8310,8314]
name: info [8334,8338]
===
match
---
string: 'bucket' [4468,4476]
string: 'bucket' [4468,4476]
===
match
---
atom_expr [7773,7783]
atom_expr [7773,7783]
===
match
---
operator: , [8261,8262]
operator: , [8285,8286]
===
match
---
trailer [6029,6037]
trailer [6029,6037]
===
match
---
trailer [6779,6786]
trailer [6779,6786]
===
match
---
name: gcp_conn_id [5839,5850]
name: gcp_conn_id [5839,5850]
===
match
---
atom_expr [5859,5875]
atom_expr [5859,5875]
===
match
---
atom_expr [8263,8273]
atom_expr [8287,8297]
===
match
---
trailer [6869,6886]
trailer [6869,6886]
===
match
---
name: stacklevel [5635,5645]
name: stacklevel [5635,5645]
===
match
---
operator: , [6886,6887]
operator: , [6886,6887]
===
match
---
param [4740,4769]
param [4740,4769]
===
match
---
strings [5454,5581]
strings [5454,5581]
===
match
---
name: self [6924,6928]
name: self [6924,6928]
===
match
---
trailer [8141,8149]
trailer [8165,8173]
===
match
---
string: "All done, uploaded %d files to S3" [8226,8261]
string: "All done, uploaded %d files to S3" [8250,8285]
===
match
---
tfpdef [5133,5196]
tfpdef [5133,5196]
===
match
---
name: delimiter [6788,6797]
name: delimiter [6788,6797]
===
match
---
name: apply_defaults [1136,1150]
name: apply_defaults [1136,1150]
===
match
---
name: self [6236,6240]
name: self [6236,6240]
===
match
---
name: google [1061,1067]
name: google [1061,1067]
===
match
---
file_input [787,8386]
file_input [787,8410]
===
match
---
simple_stmt [5898,5939]
simple_stmt [5898,5939]
===
match
---
trailer [6802,6812]
trailer [6802,6812]
===
match
---
name: google_cloud_storage_conn_id [4870,4898]
name: google_cloud_storage_conn_id [4870,4898]
===
match
---
name: bool [5111,5115]
name: bool [5111,5115]
===
match
---
trailer [6546,6715]
trailer [6546,6715]
===
match
---
import_from [1099,1150]
import_from [1099,1150]
===
match
---
operator: , [6447,6448]
operator: , [6447,6448]
===
match
---
operator: = [8161,8162]
operator: = [8185,8186]
===
match
---
name: bucket [4719,4725]
name: bucket [4719,4725]
===
match
---
simple_stmt [6184,6219]
simple_stmt [6184,6219]
===
match
---
expr_stmt [7183,7242]
expr_stmt [7183,7242]
===
match
---
name: set [7786,7789]
name: set [7786,7789]
===
match
---
atom_expr [6640,6651]
atom_expr [6640,6651]
===
match
---
atom_expr [5233,5247]
atom_expr [5233,5247]
===
match
---
operator: , [4730,4731]
operator: , [4730,4731]
===
match
---
name: google_cloud_storage_conn_id [5381,5409]
name: google_cloud_storage_conn_id [5381,5409]
===
match
---
expr_stmt [5898,5938]
expr_stmt [5898,5938]
===
match
---
name: Sequence [918,926]
name: Sequence [918,926]
===
match
---
funcdef [4634,6219]
funcdef [4634,6219]
===
match
---
atom_expr [8090,8113]
atom_expr [8114,8137]
===
match
---
name: Dict [5242,5246]
name: Dict [5242,5246]
===
match
---
atom_expr [6025,6037]
atom_expr [6025,6037]
===
match
---
simple_stmt [4425,4584]
simple_stmt [4425,4584]
===
match
---
name: list [6738,6742]
name: list [6738,6742]
===
match
---
name: self [6798,6802]
name: self [6798,6802]
===
match
---
name: files [8380,8385]
name: files [8404,8409]
===
match
---
operator: = [6864,6865]
operator: = [6864,6865]
===
match
---
import_from [941,980]
import_from [941,980]
===
match
---
name: warn [5432,5436]
name: warn [5432,5436]
===
match
---
operator: , [4515,4516]
operator: , [4515,4516]
===
match
---
atom [7691,7747]
atom [7691,7747]
===
match
---
simple_stmt [8212,8275]
simple_stmt [8236,8299]
===
match
---
name: existing_files [7553,7567]
name: existing_files [7553,7567]
===
match
---
string: """     Synchronizes a Google Cloud Storage bucket with an S3 bucket.      :param bucket: The Google Cloud Storage bucket to find the objects. (templated)     :type bucket: str     :param prefix: Prefix string which filters objects whose name begin with         this prefix. (templated)     :type prefix: str     :param delimiter: The delimiter by which you want to filter the objects. (templated)         For e.g to lists the CSV files from in a directory in GCS you would use         delimiter='.csv'.     :type delimiter: str     :param gcp_conn_id: (Optional) The connection ID used to connect to Google Cloud.     :type gcp_conn_id: str     :param google_cloud_storage_conn_id: (Deprecated) The connection ID used to connect to Google Cloud.         This parameter has been deprecated. You should pass the gcp_conn_id parameter instead.     :type google_cloud_storage_conn_id: str     :param delegate_to: Google account to impersonate using domain-wide delegation of authority,         if any. For this to work, the service account making the request must have         domain-wide delegation enabled.     :type delegate_to: str     :param dest_aws_conn_id: The destination S3 connection     :type dest_aws_conn_id: str     :param dest_s3_key: The base S3 key to be used to store the files. (templated)     :type dest_s3_key: str     :param dest_verify: Whether or not to verify SSL certificates for S3 connection.         By default SSL certificates are verified.         You can provide the following values:          - ``False``: do not validate SSL certificates. SSL will still be used                  (unless use_ssl is False), but SSL certificates will not be                  verified.         - ``path/to/cert/bundle.pem``: A filename of the CA cert bundle to uses.                  You can specify this argument if you want to use a different                  CA cert bundle than the one used by botocore.      :type dest_verify: bool or str     :param replace: Whether or not to verify the existence of the files in the         destination bucket.         By default is set to False         If set to True, will upload all the files replacing the existing ones in         the destination bucket.         If set to False, will upload only the files that are in the origin but not         in the destination bucket.     :type replace: bool     :param google_impersonation_chain: Optional Google service account to impersonate using         short-term credentials, or chained list of accounts required to get the access_token         of the last account in the list, which will be impersonated in the request.         If set as a string, the account must grant the originating account         the Service Account Token Creator IAM role.         If set as a sequence, the identities from the list must grant         Service Account Token Creator IAM role to the directly preceding identity, with first         account from the list granting this role to the originating account (templated).     :type google_impersonation_chain: Union[str, Sequence[str]]     :param s3_acl_policy: Optional The string to specify the canned ACL policy for the         object to be uploaded in S3     :type s3_acl_policy: str     """ [1194,4419]
string: """     Synchronizes a Google Cloud Storage bucket with an S3 bucket.      :param bucket: The Google Cloud Storage bucket to find the objects. (templated)     :type bucket: str     :param prefix: Prefix string which filters objects whose name begin with         this prefix. (templated)     :type prefix: str     :param delimiter: The delimiter by which you want to filter the objects. (templated)         For e.g to lists the CSV files from in a directory in GCS you would use         delimiter='.csv'.     :type delimiter: str     :param gcp_conn_id: (Optional) The connection ID used to connect to Google Cloud.     :type gcp_conn_id: str     :param google_cloud_storage_conn_id: (Deprecated) The connection ID used to connect to Google Cloud.         This parameter has been deprecated. You should pass the gcp_conn_id parameter instead.     :type google_cloud_storage_conn_id: str     :param delegate_to: Google account to impersonate using domain-wide delegation of authority,         if any. For this to work, the service account making the request must have         domain-wide delegation enabled.     :type delegate_to: str     :param dest_aws_conn_id: The destination S3 connection     :type dest_aws_conn_id: str     :param dest_s3_key: The base S3 key to be used to store the files. (templated)     :type dest_s3_key: str     :param dest_verify: Whether or not to verify SSL certificates for S3 connection.         By default SSL certificates are verified.         You can provide the following values:          - ``False``: do not validate SSL certificates. SSL will still be used                  (unless use_ssl is False), but SSL certificates will not be                  verified.         - ``path/to/cert/bundle.pem``: A filename of the CA cert bundle to uses.                  You can specify this argument if you want to use a different                  CA cert bundle than the one used by botocore.      :type dest_verify: bool or str     :param replace: Whether or not to verify the existence of the files in the         destination bucket.         By default is set to False         If set to True, will upload all the files replacing the existing ones in         the destination bucket.         If set to False, will upload only the files that are in the origin but not         in the destination bucket.     :type replace: bool     :param google_impersonation_chain: Optional Google service account to impersonate using         short-term credentials, or chained list of accounts required to get the access_token         of the last account in the list, which will be impersonated in the request.         If set as a string, the account must grant the originating account         the Service Account Token Creator IAM role.         If set as a sequence, the identities from the list must grant         Service Account Token Creator IAM role to the directly preceding identity, with first         account from the list granting this role to the originating account (templated).     :type google_impersonation_chain: Union[str, Sequence[str]]     :param s3_acl_policy: Optional The string to specify the canned ACL policy for the         object to be uploaded in S3     :type s3_acl_policy: str     """ [1194,4419]
===
match
---
name: hook [7887,7891]
name: hook [7887,7891]
===
match
---
trailer [5436,5662]
trailer [5436,5662]
===
match
---
simple_stmt [1194,4420]
simple_stmt [1194,4420]
===
match
---
atom [4458,4583]
atom [4458,4583]
===
match
---
string: 'google_impersonation_chain' [4548,4576]
string: 'google_impersonation_chain' [4548,4576]
===
match
---
name: S3Hook [6833,6839]
name: S3Hook [6833,6839]
===
match
---
name: self [6693,6697]
name: self [6693,6697]
===
match
---
atom_expr [4900,4913]
atom_expr [4900,4913]
===
match
---
test [7535,7587]
test [7535,7587]
===
match
---
name: self [6056,6060]
name: self [6056,6060]
===
match
---
string: '#f0eee4' [4599,4608]
string: '#f0eee4' [4599,4608]
===
match
---
funcdef [6224,8386]
funcdef [6224,8410]
===
match
---
operator: = [6149,6150]
operator: = [6149,6150]
===
match
---
operator: = [4957,4958]
operator: = [4957,4958]
===
match
---
simple_stmt [7760,7807]
simple_stmt [7760,7807]
===
match
---
atom_expr [5947,5963]
atom_expr [5947,5963]
===
match
---
import_name [851,866]
import_name [851,866]
===
match
---
expr_stmt [5859,5889]
expr_stmt [5859,5889]
===
match
---
operator: -> [6251,6253]
operator: -> [6251,6253]
===
match
---
arglist [6743,6812]
arglist [6743,6812]
===
match
---
simple_stmt [7937,7972]
simple_stmt [7961,7996]
===
match
---
operator: = [7946,7947]
operator: = [7970,7971]
===
match
---
simple_stmt [6823,6958]
simple_stmt [6823,6958]
===
match
---
name: str [4757,4760]
name: str [4757,4760]
===
match
---
tfpdef [4930,4956]
tfpdef [4930,4956]
===
match
---
name: bucket [6760,6766]
name: bucket [6760,6766]
===
match
---
param [4778,4810]
param [4778,4810]
===
match
---
operator: , [8100,8101]
operator: , [8124,8125]
===
match
---
trailer [6742,6813]
trailer [6742,6813]
===
match
---
operator: = [4836,4837]
operator: = [4836,4837]
===
match
---
operator: , [5647,5648]
operator: , [5647,5648]
===
match
---
name: self [7901,7905]
name: self [7931,7935]
===
match
---
param [6236,6241]
param [6236,6241]
===
match
---
argument [6419,6447]
argument [6419,6447]
===
match
---
name: dest_key [8119,8127]
name: dest_key [8143,8151]
===
match
---
name: warnings [858,866]
name: warnings [858,866]
===
match
---
name: self [6755,6759]
name: self [6755,6759]
===
match
---
sync_comp_for [7720,7746]
sync_comp_for [7720,7746]
===
match
---
operator: , [900,901]
operator: , [900,901]
===
match
---
name: prefix [7705,7711]
name: prefix [7705,7711]
===
match
---
operator: - [7784,7785]
operator: - [7784,7785]
===
match
---
trailer [5731,5738]
trailer [5731,5738]
===
match
---
simple_stmt [7988,8033]
simple_stmt [8012,8057]
===
match
---
trailer [4797,4802]
trailer [4797,4802]
===
match
---
trailer [5863,5875]
trailer [5863,5875]
===
match
---
operator: = [6003,6004]
operator: = [6003,6004]
===
match
---
atom_expr [6974,6986]
atom_expr [6974,6986]
===
match
---
trailer [6188,6202]
trailer [6188,6202]
===
match
---
trailer [4756,4761]
trailer [4756,4761]
===
match
---
atom_expr [5342,5368]
atom_expr [5342,5368]
===
match
---
atom_expr [5986,6002]
atom_expr [5986,6002]
===
match
---
expr_stmt [6823,6957]
expr_stmt [6823,6957]
===
match
---
trailer [5175,5195]
trailer [5175,5195]
===
match
---
name: DeprecationWarning [5599,5617]
name: DeprecationWarning [5599,5617]
===
match
---
operator: , [4963,4964]
operator: , [4963,4964]
===
match
---
tfpdef [5102,5115]
tfpdef [5102,5115]
===
match
---
name: self [7948,7952]
name: self [7972,7976]
===
match
---
name: files [7851,7856]
name: files [7851,7856]
===
match
---
trailer [7952,7964]
trailer [7976,7988]
===
match
---
name: Optional [5161,5169]
name: Optional [5161,5169]
===
match
---
name: prefix [7196,7202]
name: prefix [7196,7202]
===
match
---
name: dest_s3_key [7230,7241]
name: dest_s3_key [7230,7241]
===
match
---
argument [6913,6947]
argument [6913,6947]
===
match
---
atom_expr [8301,8363]
atom_expr [8325,8387]
===
match
---
operator: , [4809,4810]
operator: , [4809,4810]
===
match
---
trailer [4951,4956]
trailer [4951,4956]
===
match
---
expr_stmt [5756,5776]
expr_stmt [5756,5776]
===
match
---
expr_stmt [5986,6016]
expr_stmt [5986,6016]
===
match
---
simple_stmt [7874,7920]
simple_stmt [7874,7944]
===
match
---
trailer [6060,6087]
trailer [6060,6087]
===
match
---
trailer [8305,8309]
trailer [8329,8333]
===
match
---
expr_stmt [5785,5811]
expr_stmt [5785,5811]
===
match
---
argument [6788,6812]
argument [6788,6812]
===
match
---
trailer [7704,7719]
trailer [7704,7719]
===
match
---
name: log [6538,6541]
name: log [6538,6541]
===
match
---
name: self [8162,8166]
name: self [8186,8190]
===
match
---
atom_expr [7692,7719]
atom_expr [7692,7719]
===
match
---
import_from [867,939]
import_from [867,939]
===
match
---
operator: = [5964,5965]
operator: = [5964,5965]
===
match
---
tfpdef [5213,5247]
tfpdef [5213,5247]
===
match
---
operator: = [5687,5688]
operator: = [5687,5688]
===
match
---
operator: , [926,927]
operator: , [926,927]
===
match
---
trailer [8309,8314]
trailer [8333,8338]
===
match
---
for_stmt [7839,8199]
for_stmt [7839,8223]
===
match
---
name: existing_files [7535,7549]
name: existing_files [7535,7549]
===
match
---
trailer [5287,5292]
trailer [5287,5292]
===
match
---
name: dest_aws_conn_id [5903,5919]
name: dest_aws_conn_id [5903,5919]
===
match
---
atom_expr [7988,8032]
atom_expr [8012,8056]
===
match
---
operator: = [7885,7886]
operator: = [7885,7886]
===
match
---
expr_stmt [5947,5977]
expr_stmt [5947,5977]
===
match
---
atom_expr [6924,6947]
atom_expr [6924,6947]
===
match
---
name: parse_s3_url [7212,7224]
name: parse_s3_url [7212,7224]
===
match
---
name: delegate_to [5878,5889]
name: delegate_to [5878,5889]
===
match
---
expr_stmt [7937,7971]
expr_stmt [7961,7995]
===
match
---
name: self [4656,4660]
name: self [4656,4660]
===
match
---
name: gcs [1080,1083]
name: gcs [1080,1083]
===
insert-tree
---
argument [7901,7917]
    name: object_name [7901,7912]
    operator: = [7912,7913]
    name: file [7913,7917]
to
arglist [7901,7918]
at 0
===
insert-node
---
operator: , [7917,7918]
to
arglist [7901,7918]
at 1
===
insert-node
---
argument [7919,7942]
to
arglist [7901,7918]
at 2
===
move-tree
---
atom_expr [7901,7912]
    name: self [7901,7905]
    trailer [7905,7912]
        name: bucket [7906,7912]
to
argument [7919,7942]
at 2
===
delete-node
---
operator: , [7912,7913]
===
===
delete-node
---
name: file [7914,7918]
===
