===
match
---
operator: , [7069,7070]
operator: , [7069,7070]
===
match
---
name: dag_run_state [4408,4421]
name: dag_run_state [4408,4421]
===
match
---
name: dt [29628,29630]
name: dt [29628,29630]
===
match
---
name: tasks [3523,3528]
name: tasks [3523,3528]
===
match
---
atom [29740,29895]
atom [29740,29895]
===
match
---
operator: == [23451,23453]
operator: == [23451,23453]
===
match
---
param [39900,39904]
param [40622,40626]
===
match
---
operator: } [15260,15261]
operator: } [15260,15261]
===
match
---
name: timedelta [29808,29817]
name: timedelta [29808,29817]
===
match
---
atom_expr [11123,11143]
atom_expr [11123,11143]
===
match
---
atom_expr [16139,16174]
atom_expr [16139,16174]
===
match
---
arith_expr [20294,20335]
arith_expr [20294,20335]
===
match
---
name: single_dag_run [21836,21850]
name: single_dag_run [21836,21850]
===
match
---
operator: , [24175,24176]
operator: , [24175,24176]
===
match
---
name: assert_401 [35579,35589]
name: assert_401 [36301,36311]
===
match
---
trailer [28850,28858]
trailer [28850,28858]
===
match
---
operator: { [34487,34488]
operator: { [35209,35210]
===
match
---
atom_expr [10515,10535]
atom_expr [10515,10535]
===
match
---
dictorsetmaker [19469,19524]
dictorsetmaker [19469,19524]
===
match
---
suite [9308,9575]
suite [9308,9575]
===
match
---
operator: = [7645,7646]
operator: = [7645,7646]
===
match
---
simple_stmt [16254,16423]
simple_stmt [16254,16423]
===
match
---
trailer [39012,39036]
trailer [39734,39758]
===
match
---
operator: } [2833,2834]
operator: } [2833,2834]
===
match
---
string: "running" [18302,18311]
string: "running" [18302,18311]
===
match
---
operator: , [18411,18412]
operator: , [18411,18412]
===
match
---
comparison [4121,4144]
comparison [4121,4144]
===
match
---
string: "dry_run" [28270,28279]
string: "dry_run" [28270,28279]
===
match
---
dictorsetmaker [10345,10377]
dictorsetmaker [10345,10377]
===
match
---
operator: { [12488,12489]
operator: { [12488,12489]
===
match
---
operator: , [18669,18670]
operator: , [18669,18670]
===
match
---
operator: + [20230,20231]
operator: + [20230,20231]
===
match
---
arith_expr [2563,2603]
arith_expr [2563,2603]
===
match
---
atom_expr [15951,15981]
atom_expr [15951,15981]
===
match
---
operator: { [41860,41861]
operator: { [42582,42583]
===
match
---
operator: , [11742,11743]
operator: , [11742,11743]
===
match
---
string: "include_subdags" [32381,32398]
string: "include_subdags" [33103,33120]
===
match
---
name: create_task_instances [23006,23027]
name: create_task_instances [23006,23027]
===
match
---
assert_stmt [25107,25149]
assert_stmt [25107,25149]
===
match
---
string: "/api/v1/dags/example_python_operator/dagRuns/TEST_DAG_RUN_ID/taskInstances?" [11782,11859]
string: "/api/v1/dags/example_python_operator/dagRuns/TEST_DAG_RUN_ID/taskInstances?" [11782,11859]
===
match
---
atom_expr [23353,23389]
atom_expr [23353,23389]
===
match
---
string: "task_id" [7115,7124]
string: "task_id" [7115,7124]
===
match
---
expr_stmt [41211,41748]
expr_stmt [41933,42470]
===
match
---
name: DEFAULT_DATETIME_1 [40225,40243]
name: DEFAULT_DATETIME_1 [40947,40965]
===
match
---
operator: , [19002,19003]
operator: , [19002,19003]
===
match
---
operator: { [41347,41348]
operator: { [42069,42070]
===
match
---
operator: { [14484,14485]
operator: { [14484,14485]
===
match
---
string: "print_the_context" [40170,40189]
string: "print_the_context" [40892,40911]
===
match
---
operator: , [26169,26170]
operator: , [26169,26170]
===
match
---
operator: , [22778,22779]
operator: , [22778,22779]
===
match
---
name: response [33704,33712]
name: response [34426,34434]
===
match
---
dictorsetmaker [17463,17486]
dictorsetmaker [17463,17486]
===
match
---
name: response [21274,21282]
name: response [21274,21282]
===
match
---
operator: = [9966,9967]
operator: = [9966,9967]
===
match
---
name: environ_overrides [40033,40050]
name: environ_overrides [40755,40772]
===
match
---
number: 150 [13168,13171]
number: 150 [13168,13171]
===
match
---
atom_expr [38998,39278]
atom_expr [39720,40000]
===
match
---
name: dag_id [4195,4201]
name: dag_id [4195,4201]
===
match
---
operator: + [18960,18961]
operator: + [18960,18961]
===
match
---
atom [24995,25018]
atom [24995,25018]
===
match
---
trailer [11615,11623]
trailer [11615,11623]
===
match
---
name: utils [1008,1013]
name: utils [1008,1013]
===
match
---
operator: , [5874,5875]
operator: , [5874,5875]
===
match
---
operator: == [37858,37860]
operator: == [38580,38582]
===
match
---
operator: } [27989,27990]
operator: } [27989,27990]
===
match
---
name: response [16888,16896]
name: response [16888,16896]
===
match
---
arglist [23829,24024]
arglist [23829,24024]
===
match
---
trailer [3901,3920]
trailer [3901,3920]
===
match
---
arglist [4542,4735]
arglist [4542,4735]
===
match
---
name: status_code [41131,41142]
name: status_code [41853,41864]
===
match
---
operator: , [34778,34779]
operator: , [35500,35501]
===
match
---
argument [22134,22154]
argument [22134,22154]
===
match
---
string: "print_the_context" [40804,40823]
string: "print_the_context" [41526,41545]
===
match
---
name: session [16210,16217]
name: session [16210,16217]
===
match
---
operator: , [40723,40724]
operator: , [41445,41446]
===
match
---
trailer [42969,42991]
trailer [43691,43713]
===
match
---
name: dt [2649,2651]
name: dt [2649,2651]
===
match
---
operator: { [38042,38043]
operator: { [38764,38765]
===
match
---
operator: , [41605,41606]
operator: , [42327,42328]
===
match
---
name: response [9087,9095]
name: response [9087,9095]
===
match
---
number: 1 [27193,27194]
number: 1 [27193,27194]
===
match
---
trailer [22612,22617]
trailer [22612,22617]
===
match
---
name: dt [804,806]
name: dt [804,806]
===
match
---
operator: , [11475,11476]
operator: , [11475,11476]
===
match
---
name: timedelta [2652,2661]
name: timedelta [2652,2661]
===
match
---
operator: , [14548,14549]
operator: , [14548,14549]
===
match
---
number: 2 [32752,32753]
number: 2 [33474,33475]
===
match
---
operator: , [2035,2036]
operator: , [2035,2036]
===
match
---
atom [10863,11421]
atom [10863,11421]
===
match
---
operator: , [6984,6985]
operator: , [6984,6985]
===
match
---
name: self [2891,2895]
name: self [2891,2895]
===
match
---
dictorsetmaker [8480,8803]
dictorsetmaker [8480,8803]
===
match
---
operator: , [24461,24462]
operator: , [24461,24462]
===
match
---
trailer [37460,37470]
trailer [38182,38192]
===
match
---
string: "include_upstream" [42039,42057]
string: "include_upstream" [42761,42779]
===
match
---
operator: , [30519,30520]
operator: , [30519,30520]
===
match
---
operator: } [11143,11144]
operator: } [11143,11144]
===
match
---
name: client [6201,6207]
name: client [6201,6207]
===
match
---
operator: } [42258,42259]
operator: } [42980,42981]
===
match
---
trailer [37213,37220]
trailer [37935,37942]
===
match
---
dictorsetmaker [38102,38423]
dictorsetmaker [38824,39145]
===
match
---
name: dags [38879,38883]
name: dags [39601,39605]
===
match
---
number: 100 [8263,8266]
number: 100 [8263,8266]
===
match
---
operator: , [19525,19526]
operator: , [19525,19526]
===
match
---
number: 150 [18503,18506]
number: 150 [18503,18506]
===
match
---
fstring_string: ?start_date_gte= [10716,10732]
fstring_string: ?start_date_gte= [10716,10732]
===
match
---
testlist_comp [19333,19526]
testlist_comp [19333,19526]
===
match
---
string: "PythonOperator" [8226,8242]
string: "PythonOperator" [8226,8242]
===
match
---
trailer [6082,6104]
trailer [6082,6104]
===
match
---
string: "test_queue_1" [17378,17392]
string: "test_queue_1" [17378,17392]
===
match
---
operator: @ [36532,36533]
operator: @ [37254,37255]
===
match
---
trailer [4096,4100]
trailer [4096,4100]
===
match
---
suite [17241,25150]
suite [17241,25150]
===
match
---
string: "end_date" [5330,5340]
string: "end_date" [5330,5340]
===
match
---
atom [1749,1804]
atom [1749,1804]
===
match
---
name: update [3822,3828]
name: update [3822,3828]
===
match
---
arglist [6105,6175]
arglist [6105,6175]
===
match
---
name: days [33039,33043]
name: days [33761,33765]
===
match
---
operator: @ [22642,22643]
operator: @ [22642,22643]
===
match
---
name: task_instances [15600,15614]
name: task_instances [15600,15614]
===
match
---
argument [3951,3964]
argument [3951,3964]
===
match
---
operator: } [36380,36381]
operator: } [37102,37103]
===
match
---
argument [1697,1713]
argument [1697,1713]
===
match
---
string: "new_state" [40425,40436]
string: "new_state" [41147,41158]
===
match
---
trailer [7662,7836]
trailer [7662,7836]
===
match
---
name: parameterized [17247,17260]
name: parameterized [17247,17260]
===
match
---
name: FAILED [29076,29082]
name: FAILED [29076,29082]
===
match
---
trailer [29630,29640]
trailer [29630,29640]
===
match
---
operator: } [28167,28168]
operator: } [28167,28168]
===
match
---
trailer [21282,21287]
trailer [21282,21287]
===
match
---
name: models [902,908]
name: models [902,908]
===
match
---
atom_expr [18962,18982]
atom_expr [18962,18982]
===
match
---
operator: = [3310,3311]
operator: = [3310,3311]
===
match
---
atom [37788,37897]
atom [38510,38619]
===
match
---
name: self [16939,16943]
name: self [16939,16943]
===
match
---
name: TaskInstance [37816,37828]
name: TaskInstance [38538,38550]
===
match
---
name: DEFAULT_DATETIME_1 [9785,9803]
name: DEFAULT_DATETIME_1 [9785,9803]
===
match
---
atom [30094,30249]
atom [30094,30249]
===
match
---
operator: = [38083,38084]
operator: = [38805,38806]
===
match
---
number: 3 [18687,18688]
number: 3 [18687,18688]
===
match
---
trailer [2522,2532]
trailer [2522,2532]
===
match
---
name: items [4028,4033]
name: items [4028,4033]
===
match
---
trailer [9250,9260]
trailer [9250,9260]
===
match
---
atom [38556,38836]
atom [39278,39558]
===
match
---
name: query [7353,7358]
name: query [7353,7358]
===
match
---
string: '2020-11-10T12:4po' [36258,36277]
string: '2020-11-10T12:4po' [36980,36999]
===
match
---
string: "start_date" [2549,2561]
string: "start_date" [2549,2561]
===
match
---
trailer [3894,3901]
trailer [3894,3901]
===
match
---
operator: , [43168,43169]
operator: , [43890,43891]
===
match
---
trailer [22462,22474]
trailer [22462,22474]
===
match
---
for_stmt [34969,35077]
for_stmt [35691,35799]
===
match
---
trailer [3811,3821]
trailer [3811,3821]
===
match
---
decorator [21714,21731]
decorator [21714,21731]
===
match
---
trailer [43229,43241]
trailer [43951,43963]
===
match
---
name: expected_ti [15985,15996]
name: expected_ti [15985,15996]
===
match
---
simple_stmt [5210,5994]
simple_stmt [5210,5994]
===
match
---
operator: == [38521,38523]
operator: == [39243,39245]
===
match
---
string: "dry_run" [35861,35870]
string: "dry_run" [36583,36592]
===
match
---
testlist_comp [13410,13824]
testlist_comp [13410,13824]
===
match
---
operator: { [9766,9767]
operator: { [9766,9767]
===
match
---
string: "only_running" [35973,35987]
string: "only_running" [36695,36709]
===
match
---
operator: } [19524,19525]
operator: } [19524,19525]
===
match
---
import_from [954,994]
import_from [954,994]
===
match
---
operator: , [27088,27089]
operator: , [27088,27089]
===
match
---
string: "example_subdag_operator.section-1" [30484,30519]
string: "example_subdag_operator.section-1" [30484,30519]
===
match
---
name: create_task_instances [15672,15693]
name: create_task_instances [15672,15693]
===
match
---
simple_stmt [7845,7880]
simple_stmt [7845,7880]
===
match
---
operator: = [23797,23798]
operator: = [23797,23798]
===
match
---
string: "queue" [14761,14768]
string: "queue" [14761,14768]
===
match
---
operator: } [24268,24269]
operator: } [24268,24269]
===
match
---
argument [40682,40723]
argument [41404,41445]
===
match
---
trailer [19437,19445]
trailer [19437,19445]
===
match
---
name: json [43273,43277]
name: json [43995,43999]
===
match
---
trailer [2633,2646]
trailer [2633,2646]
===
match
---
operator: = [2600,2601]
operator: = [2600,2601]
===
match
---
trailer [22275,22282]
trailer [22275,22282]
===
match
---
string: "dag_ids" [23632,23641]
string: "dag_ids" [23632,23641]
===
match
---
simple_stmt [33366,33543]
simple_stmt [34088,34265]
===
match
---
operator: , [22949,22950]
operator: , [22949,22950]
===
match
---
comparison [36076,36103]
comparison [36798,36825]
===
match
---
operator: { [30094,30095]
operator: { [30094,30095]
===
match
---
arith_expr [19962,20003]
arith_expr [19962,20003]
===
match
---
assert_stmt [37440,37482]
assert_stmt [38162,38204]
===
match
---
string: "task_instances" [35115,35131]
string: "task_instances" [35837,35853]
===
match
---
name: response [5174,5182]
name: response [5174,5182]
===
match
---
trailer [4033,4035]
trailer [4033,4035]
===
match
---
operator: , [26377,26378]
operator: , [26377,26378]
===
match
---
name: response [23722,23730]
name: response [23722,23730]
===
match
---
param [37680,37695]
param [38402,38417]
===
match
---
name: environ_overrides [24977,24994]
name: environ_overrides [24977,24994]
===
match
---
atom_expr [42965,43000]
atom_expr [43687,43722]
===
match
---
operator: = [31078,31079]
operator: = [31078,31079]
===
match
---
operator: , [17056,17057]
operator: , [17056,17057]
===
match
---
operator: { [28596,28597]
operator: { [28596,28597]
===
match
---
name: execution_date [4615,4629]
name: execution_date [4615,4629]
===
match
---
string: "end_date" [36156,36166]
string: "end_date" [36878,36888]
===
match
---
argument [11136,11142]
argument [11136,11142]
===
match
---
argument [37015,37044]
argument [37737,37766]
===
match
---
operator: , [5757,5758]
operator: , [5757,5758]
===
match
---
name: timedelta [25538,25547]
name: timedelta [25538,25547]
===
match
---
operator: , [18003,18004]
operator: , [18003,18004]
===
match
---
name: return_value [37773,37785]
name: return_value [38495,38507]
===
match
---
name: str [3212,3215]
name: str [3212,3215]
===
match
---
operator: , [26943,26944]
operator: , [26943,26944]
===
match
---
testlist_comp [24609,24693]
testlist_comp [24609,24693]
===
match
---
name: response [40576,40584]
name: response [41298,41306]
===
match
---
string: "operator" [5535,5545]
string: "operator" [5535,5545]
===
match
---
operator: = [33224,33225]
operator: = [33946,33947]
===
match
---
operator: == [17174,17176]
operator: == [17174,17176]
===
match
---
operator: , [37044,37045]
operator: , [37766,37767]
===
match
---
operator: = [4516,4517]
operator: = [4516,4517]
===
match
---
name: count [33639,33644]
name: count [34361,34366]
===
match
---
operator: == [21271,21273]
operator: == [21271,21273]
===
match
---
string: "end_date" [11516,11526]
string: "end_date" [11516,11526]
===
match
---
name: days [32893,32897]
name: days [33615,33619]
===
match
---
string: "new_state" [42706,42717]
string: "new_state" [43428,43439]
===
match
---
operator: , [42307,42308]
operator: , [43029,43030]
===
match
---
atom_expr [26357,26377]
atom_expr [26357,26377]
===
match
---
operator: , [21168,21169]
operator: , [21168,21169]
===
match
---
number: 200 [21219,21222]
number: 200 [21219,21222]
===
match
---
name: status_code [17162,17173]
name: status_code [17162,17173]
===
match
---
trailer [2069,2137]
trailer [2069,2137]
===
match
---
operator: , [34302,34303]
operator: , [35024,35025]
===
match
---
operator: , [33871,33872]
operator: , [34593,34594]
===
match
---
name: dag_id [31600,31606]
name: dag_id [32322,32328]
===
match
---
operator: , [31982,31983]
operator: , [32704,32705]
===
match
---
operator: = [4165,4166]
operator: = [4165,4166]
===
match
---
operator: = [23962,23963]
operator: = [23962,23963]
===
match
---
dictorsetmaker [42376,42728]
dictorsetmaker [43098,43450]
===
match
---
name: timestamp [7534,7543]
name: timestamp [7534,7543]
===
match
---
operator: , [24561,24562]
operator: , [24561,24562]
===
match
---
operator: , [32517,32518]
operator: , [33239,33240]
===
match
---
string: "queue" [6927,6934]
string: "queue" [6927,6934]
===
match
---
atom_expr [23001,23036]
atom_expr [23001,23036]
===
match
---
atom [34487,34711]
atom [35209,35433]
===
match
---
dictorsetmaker [19086,19185]
dictorsetmaker [19086,19185]
===
match
---
name: ti [3933,3935]
name: ti [3933,3935]
===
match
---
arglist [15845,15891]
arglist [15845,15891]
===
match
---
name: airflow [1131,1138]
name: airflow [1131,1138]
===
match
---
param [3253,3280]
param [3253,3280]
===
match
---
assert_stmt [6394,6428]
assert_stmt [6394,6428]
===
match
---
operator: , [42746,42747]
operator: , [43468,43469]
===
match
---
operator: , [17848,17849]
operator: , [17848,17849]
===
match
---
dictorsetmaker [40052,40088]
dictorsetmaker [40774,40810]
===
match
---
operator: , [4259,4260]
operator: , [4259,4260]
===
match
---
name: RUNNING [32787,32794]
name: RUNNING [33509,33516]
===
match
---
trailer [16165,16174]
trailer [16165,16174]
===
match
---
name: timedelta [32883,32892]
name: timedelta [33605,33614]
===
match
---
atom_expr [29860,29872]
atom_expr [29860,29872]
===
match
---
trailer [22546,22563]
trailer [22546,22563]
===
match
---
operator: , [15848,15849]
operator: , [15848,15849]
===
match
---
dictorsetmaker [19944,20003]
dictorsetmaker [19944,20003]
===
match
---
name: DEFAULT_DATETIME_STR_1 [10172,10194]
name: DEFAULT_DATETIME_STR_1 [10172,10194]
===
match
---
testlist_comp [14394,14508]
testlist_comp [14394,14508]
===
match
---
name: get [16277,16280]
name: get [16277,16280]
===
match
---
testlist_comp [18094,18210]
testlist_comp [18094,18210]
===
match
---
name: json [35348,35352]
name: json [36070,36074]
===
match
---
operator: , [22346,22347]
operator: , [22346,22347]
===
match
---
name: execution_date [4281,4295]
name: execution_date [4281,4295]
===
match
---
name: timedelta [28664,28673]
name: timedelta [28664,28673]
===
match
---
name: response [21345,21353]
name: response [21345,21353]
===
match
---
operator: , [28285,28286]
operator: , [28285,28286]
===
match
---
number: 2 [20564,20565]
number: 2 [20564,20565]
===
match
---
operator: , [17952,17953]
operator: , [17952,17953]
===
match
---
trailer [6104,6176]
trailer [6104,6176]
===
match
---
operator: } [35558,35559]
operator: } [36280,36281]
===
match
---
operator: , [5724,5725]
operator: , [5724,5725]
===
match
---
dictorsetmaker [23235,23256]
dictorsetmaker [23235,23256]
===
match
---
name: self [39900,39904]
name: self [40622,40626]
===
match
---
string: "state" [6131,6138]
string: "state" [6131,6138]
===
match
---
assert_stmt [32002,32036]
assert_stmt [32724,32758]
===
match
---
argument [4348,4380]
argument [4348,4380]
===
match
---
name: self [23537,23541]
name: self [23537,23541]
===
match
---
fstring_string: /clearTaskInstances [31881,31900]
fstring_string: /clearTaskInstances [32603,32622]
===
match
---
trailer [3562,3569]
trailer [3562,3569]
===
match
---
string: "/api/v1/dags/~/dagRuns/~/taskInstances?pool=test_pool_1,test_pool_2" [14566,14635]
string: "/api/v1/dags/~/dagRuns/~/taskInstances?pool=test_pool_1,test_pool_2" [14566,14635]
===
match
---
arith_expr [20211,20252]
arith_expr [20211,20252]
===
match
---
operator: , [31151,31152]
operator: , [31151,31152]
===
match
---
string: "end_date_lte" [19146,19160]
string: "end_date_lte" [19146,19160]
===
match
---
operator: , [22820,22821]
operator: , [22820,22821]
===
match
---
string: "include_downstream" [42085,42105]
string: "include_downstream" [42807,42827]
===
match
---
operator: , [34473,34474]
operator: , [35195,35196]
===
match
---
name: timedelta [26360,26369]
name: timedelta [26360,26369]
===
match
---
name: FAILED [26418,26424]
name: FAILED [26418,26424]
===
match
---
number: 2 [2667,2668]
number: 2 [2667,2668]
===
match
---
atom [14484,14507]
atom [14484,14507]
===
match
---
trailer [16496,16510]
trailer [16496,16510]
===
match
---
atom [13515,13538]
atom [13515,13538]
===
match
---
string: "pool" [14019,14025]
string: "pool" [14019,14025]
===
match
---
string: "sla_miss" [8450,8460]
string: "sla_miss" [8450,8460]
===
match
---
operator: , [6720,6721]
operator: , [6720,6721]
===
match
---
dictorsetmaker [18798,18828]
dictorsetmaker [18798,18828]
===
match
---
classdef [17183,25150]
classdef [17183,25150]
===
match
---
atom [17368,17393]
atom [17368,17393]
===
match
---
trailer [26594,26601]
trailer [26594,26601]
===
match
---
operator: , [42642,42643]
operator: , [43364,43365]
===
match
---
atom [18851,18906]
atom [18851,18906]
===
match
---
name: json [21233,21237]
name: json [21233,21237]
===
match
---
operator: , [14041,14042]
operator: , [14041,14042]
===
match
---
operator: + [20147,20148]
operator: + [20147,20148]
===
match
---
expr_stmt [43009,43205]
expr_stmt [43731,43927]
===
match
---
operator: , [20567,20568]
operator: , [20567,20568]
===
match
---
simple_stmt [2351,2390]
simple_stmt [2351,2390]
===
match
---
fstring_start: f" [12447,12449]
fstring_start: f" [12447,12449]
===
match
---
testlist_comp [19883,20337]
testlist_comp [19883,20337]
===
match
---
operator: { [10171,10172]
operator: { [10171,10172]
===
match
---
suite [9078,9261]
suite [9078,9261]
===
match
---
name: days [2662,2666]
name: days [2662,2666]
===
match
---
suite [3390,4803]
suite [3390,4803]
===
match
---
operator: = [37786,37787]
operator: = [38508,38509]
===
match
---
name: self [21903,21907]
name: self [21903,21907]
===
match
---
atom_expr [32880,32900]
atom_expr [33602,33622]
===
match
---
name: parameterized [24084,24097]
name: parameterized [24084,24097]
===
match
---
name: self [23799,23803]
name: self [23799,23803]
===
match
---
operator: { [39465,39466]
operator: { [40187,40188]
===
match
---
atom [18094,18118]
atom [18094,18118]
===
match
---
string: "test_pool_1" [14403,14416]
string: "test_pool_1" [14403,14416]
===
match
---
atom [24413,24461]
atom [24413,24461]
===
match
---
string: 'detail' [43278,43286]
string: 'detail' [44000,44008]
===
match
---
operator: , [19566,19567]
operator: , [19566,19567]
===
match
---
trailer [23131,23138]
trailer [23131,23138]
===
match
---
decorator [37551,37631]
decorator [38273,38353]
===
match
---
name: self [20807,20811]
name: self [20807,20811]
===
match
---
atom [17825,17848]
atom [17825,17848]
===
match
---
operator: { [38084,38085]
operator: { [38806,38807]
===
match
---
operator: { [30559,30560]
operator: { [30559,30560]
===
match
---
name: assert_401 [9240,9250]
name: assert_401 [9240,9250]
===
match
---
operator: , [30049,30050]
operator: , [30049,30050]
===
match
---
operator: } [35823,35824]
operator: } [36545,36546]
===
match
---
atom [20109,20170]
atom [20109,20170]
===
match
---
operator: = [23233,23234]
operator: = [23233,23234]
===
match
---
string: "executor_config" [6669,6686]
string: "executor_config" [6669,6686]
===
match
---
dictorsetmaker [36681,36741]
dictorsetmaker [37403,37463]
===
match
---
operator: , [6510,6511]
operator: , [6510,6511]
===
match
---
atom_expr [4053,4076]
atom_expr [4053,4076]
===
match
---
testlist_comp [24413,24493]
testlist_comp [24413,24493]
===
match
---
string: "include_downstream" [39660,39680]
string: "include_downstream" [40382,40402]
===
match
---
operator: } [13492,13493]
operator: } [13492,13493]
===
match
---
operator: = [12211,12212]
operator: = [12211,12212]
===
match
---
name: post [23139,23143]
name: post [23139,23143]
===
match
---
decorated [17246,21378]
decorated [17246,21378]
===
match
---
expr_stmt [22260,22438]
expr_stmt [22260,22438]
===
match
---
operator: , [24694,24695]
operator: , [24694,24695]
===
match
---
name: single_dag_run [37091,37105]
name: single_dag_run [37813,37827]
===
match
---
name: client [7652,7658]
name: client [7652,7658]
===
match
---
atom [41842,42322]
atom [42564,43044]
===
match
---
dictorsetmaker [25904,26019]
dictorsetmaker [25904,26019]
===
match
---
operator: = [3216,3217]
operator: = [3216,3217]
===
match
---
param [4896,4903]
param [4896,4903]
===
match
---
operator: { [19064,19065]
operator: { [19064,19065]
===
match
---
trailer [2911,2913]
trailer [2911,2913]
===
match
---
name: value [4070,4075]
name: value [4070,4075]
===
match
---
operator: = [2369,2370]
operator: = [2369,2370]
===
match
---
name: upstream [39254,39262]
name: upstream [39976,39984]
===
match
---
string: "execution_date" [27753,27769]
string: "execution_date" [27753,27769]
===
match
---
name: json [25123,25127]
name: json [25123,25127]
===
match
---
operator: + [11121,11122]
operator: + [11121,11122]
===
match
---
import_from [848,887]
import_from [848,887]
===
match
---
string: 'TEST_DAG_RUN_ID_2' [34334,34353]
string: 'TEST_DAG_RUN_ID_2' [35056,35075]
===
match
---
trailer [16029,16047]
trailer [16029,16047]
===
match
---
trailer [2595,2603]
trailer [2595,2603]
===
match
---
dictorsetmaker [12660,12675]
dictorsetmaker [12660,12675]
===
match
---
string: "include_future" [38323,38339]
string: "include_future" [39045,39061]
===
match
---
name: permissions [1971,1982]
name: permissions [1971,1982]
===
match
---
operator: , [16119,16120]
operator: , [16119,16120]
===
match
---
operator: , [27266,27267]
operator: , [27266,27267]
===
match
---
name: expected [42937,42945]
name: expected [43659,43667]
===
match
---
name: timedelta [11047,11056]
name: timedelta [11047,11056]
===
match
---
comparison [38507,38846]
comparison [39229,39568]
===
match
---
operator: { [11933,11934]
operator: { [11933,11934]
===
match
---
operator: { [28950,28951]
operator: { [28950,28951]
===
match
---
operator: = [39351,39352]
operator: = [40073,40074]
===
match
---
string: "print_the_context" [42424,42443]
string: "print_the_context" [43146,43165]
===
match
---
string: "execution_date" [28799,28815]
string: "execution_date" [28799,28815]
===
match
---
name: main_dag [31455,31463]
name: main_dag [32177,32185]
===
match
---
operator: , [24365,24366]
operator: , [24365,24366]
===
match
---
number: 200 [33697,33700]
number: 200 [34419,34422]
===
match
---
string: "unixname" [5961,5971]
string: "unixname" [5961,5971]
===
match
---
operator: = [10453,10454]
operator: = [10453,10454]
===
match
---
operator: @ [21383,21384]
operator: @ [21383,21384]
===
match
---
dictorsetmaker [32247,32405]
dictorsetmaker [32969,33127]
===
match
---
operator: } [27087,27088]
operator: } [27087,27088]
===
match
---
trailer [32640,32648]
trailer [33362,33370]
===
match
---
name: single_dag_run [22226,22240]
name: single_dag_run [22226,22240]
===
match
---
string: "execution_date_gte" [24510,24530]
string: "execution_date_gte" [24510,24530]
===
match
---
trailer [6211,6385]
trailer [6211,6385]
===
match
---
name: dr [4774,4776]
name: dr [4774,4776]
===
match
---
decorator [36532,36549]
decorator [37254,37271]
===
match
---
operator: , [3654,3655]
operator: , [3654,3655]
===
match
---
simple_stmt [3754,3759]
simple_stmt [3754,3759]
===
match
---
name: expected [24805,24813]
name: expected [24805,24813]
===
match
---
operator: } [15307,15308]
operator: } [15307,15308]
===
match
---
simple_stmt [23116,23295]
simple_stmt [23116,23295]
===
match
---
dotted_name [1131,1153]
dotted_name [1131,1153]
===
match
---
operator: , [4697,4698]
operator: , [4697,4698]
===
match
---
string: "queue" [17416,17423]
string: "queue" [17416,17423]
===
match
---
string: "dry_run" [32247,32256]
string: "dry_run" [32969,32978]
===
match
---
testlist_comp [14334,14655]
testlist_comp [14334,14655]
===
match
---
name: DEFAULT_DATETIME_1 [9928,9946]
name: DEFAULT_DATETIME_1 [9928,9946]
===
match
---
trailer [22491,22496]
trailer [22491,22496]
===
match
---
number: 100 [6811,6814]
number: 100 [6811,6814]
===
match
---
operator: { [24995,24996]
operator: { [24995,24996]
===
match
---
name: dag_run_state [4721,4734]
name: dag_run_state [4721,4734]
===
match
---
operator: , [12550,12551]
operator: , [12550,12551]
===
match
---
name: days [29641,29645]
name: days [29641,29645]
===
match
---
name: self [2312,2316]
name: self [2312,2316]
===
match
---
name: self [36908,36912]
name: self [37630,37634]
===
match
---
atom_expr [7544,7561]
atom_expr [7544,7561]
===
match
---
operator: } [8816,8817]
operator: } [8816,8817]
===
match
---
dictorsetmaker [27753,27812]
dictorsetmaker [27753,27812]
===
match
---
operator: == [32030,32032]
operator: == [32752,32754]
===
match
---
trailer [28721,28728]
trailer [28721,28728]
===
match
---
operator: , [26601,26602]
operator: , [26601,26602]
===
match
---
name: default_time [2356,2368]
name: default_time [2356,2368]
===
match
---
operator: + [18883,18884]
operator: + [18883,18884]
===
match
---
name: sync_to_db [37148,37158]
name: sync_to_db [37870,37880]
===
match
---
name: app [31750,31753]
name: app [32472,32475]
===
match
---
name: response [16954,16962]
name: response [16954,16962]
===
match
---
import_as_names [916,953]
import_as_names [916,953]
===
match
---
operator: { [27752,27753]
operator: { [27752,27753]
===
match
---
operator: , [18587,18588]
operator: , [18587,18588]
===
match
---
operator: , [42443,42444]
operator: , [43165,43166]
===
match
---
dictorsetmaker [34505,34697]
dictorsetmaker [35227,35419]
===
match
---
operator: , [20004,20005]
operator: , [20004,20005]
===
match
---
simple_stmt [22073,22252]
simple_stmt [22073,22252]
===
match
---
dictorsetmaker [17089,17125]
dictorsetmaker [17089,17125]
===
match
---
dictorsetmaker [9483,9519]
dictorsetmaker [9483,9519]
===
match
---
atom_expr [28838,28858]
atom_expr [28838,28858]
===
match
---
operator: , [16857,16858]
operator: , [16857,16858]
===
match
---
string: "pid" [2683,2688]
string: "pid" [2683,2688]
===
match
---
trailer [35263,35570]
trailer [35985,36292]
===
match
---
operator: } [10755,10756]
operator: } [10755,10756]
===
match
---
atom_expr [9949,9969]
atom_expr [9949,9969]
===
match
---
atom_expr [18150,18162]
atom_expr [18150,18162]
===
match
---
operator: { [42354,42355]
operator: { [43076,43077]
===
match
---
name: json [37365,37369]
name: json [38087,38091]
===
match
---
string: "execution_date" [9910,9926]
string: "execution_date" [9910,9926]
===
match
---
string: "test_pool_2" [17954,17967]
string: "test_pool_2" [17954,17967]
===
match
---
trailer [20161,20169]
trailer [20161,20169]
===
match
---
string: "example_python_operator" [5258,5283]
string: "example_python_operator" [5258,5283]
===
match
---
string: 'example_python_operator' [34277,34302]
string: 'example_python_operator' [34999,35024]
===
match
---
operator: { [18094,18095]
operator: { [18094,18095]
===
match
---
testlist_comp [11515,11702]
testlist_comp [11515,11702]
===
match
---
trailer [5225,5230]
trailer [5225,5230]
===
match
---
operator: , [40446,40447]
operator: , [41168,41169]
===
match
---
expr_stmt [16254,16422]
expr_stmt [16254,16422]
===
match
---
name: create_task_instances [16188,16209]
name: create_task_instances [16188,16209]
===
match
---
expr_stmt [37198,37388]
expr_stmt [37920,38110]
===
match
---
operator: { [33482,33483]
operator: { [34204,34205]
===
match
---
operator: , [14669,14670]
operator: , [14669,14670]
===
match
---
operator: , [22039,22040]
operator: , [22039,22040]
===
match
---
param [39327,39331]
param [40049,40053]
===
match
---
name: status_code [15917,15928]
name: status_code [15917,15928]
===
match
---
atom [17415,17440]
atom [17415,17440]
===
match
---
atom_expr [9547,9567]
atom_expr [9547,9567]
===
match
---
name: state [33620,33625]
name: state [34342,34347]
===
match
---
operator: } [14784,14785]
operator: } [14784,14785]
===
match
---
param [22983,22990]
param [22983,22990]
===
match
---
assert_stmt [5210,5993]
assert_stmt [5210,5993]
===
match
---
trailer [23428,23433]
trailer [23428,23433]
===
match
---
trailer [20811,20833]
trailer [20811,20833]
===
match
---
atom [36429,36464]
atom [37151,37186]
===
match
---
dictorsetmaker [31022,31129]
dictorsetmaker [31022,31129]
===
match
---
operator: , [7428,7429]
operator: , [7428,7429]
===
match
---
operator: , [13344,13345]
operator: , [13344,13345]
===
match
---
atom_expr [16265,16422]
atom_expr [16265,16422]
===
match
---
operator: , [27505,27506]
operator: , [27505,27506]
===
match
---
operator: , [17988,17989]
operator: , [17988,17989]
===
match
---
testlist_comp [13469,13585]
testlist_comp [13469,13585]
===
match
---
dictorsetmaker [25496,25603]
dictorsetmaker [25496,25603]
===
match
---
argument [23626,23691]
argument [23626,23691]
===
match
---
expr_stmt [4958,5158]
expr_stmt [4958,5158]
===
match
---
trailer [4691,4697]
trailer [4691,4697]
===
match
---
atom_expr [38507,38520]
atom_expr [39229,39242]
===
match
---
simple_stmt [36649,36900]
simple_stmt [37371,37622]
===
match
---
name: FAILED [30613,30619]
name: FAILED [30613,30619]
===
match
---
name: client [33382,33388]
name: client [34104,34110]
===
match
---
operator: + [28659,28660]
operator: + [28659,28660]
===
match
---
name: platform [1014,1022]
name: platform [1014,1022]
===
match
---
operator: } [28927,28928]
operator: } [28927,28928]
===
match
---
simple_stmt [2937,2953]
simple_stmt [2937,2953]
===
match
---
name: len [3635,3638]
name: len [3635,3638]
===
match
---
operator: , [3107,3108]
operator: , [3107,3108]
===
match
---
atom [11087,11144]
atom [11087,11144]
===
match
---
atom_expr [7380,7572]
atom_expr [7380,7572]
===
match
---
dictorsetmaker [11516,11546]
dictorsetmaker [11516,11546]
===
match
---
operator: , [15629,15630]
operator: , [15629,15630]
===
match
---
name: DEFAULT_DATETIME_1 [12119,12137]
name: DEFAULT_DATETIME_1 [12119,12137]
===
match
---
name: dag_id [16219,16225]
name: dag_id [16219,16225]
===
match
---
operator: { [28248,28249]
operator: { [28248,28249]
===
match
---
name: client [2882,2888]
name: client [2882,2888]
===
match
---
name: days [11136,11140]
name: days [11136,11140]
===
match
---
dictorsetmaker [6131,6153]
dictorsetmaker [6131,6153]
===
match
---
atom [12351,12531]
atom [12351,12531]
===
match
---
import_as_names [1331,1363]
import_as_names [1331,1363]
===
match
---
operator: = [21118,21119]
operator: = [21118,21119]
===
match
---
argument [4402,4421]
argument [4402,4421]
===
match
---
name: session [33584,33591]
name: session [34306,34313]
===
match
---
import_from [807,832]
import_from [807,832]
===
match
---
name: response [41122,41130]
name: response [41844,41852]
===
match
---
dictorsetmaker [35861,36035]
dictorsetmaker [36583,36757]
===
match
---
trailer [25122,25127]
trailer [25122,25127]
===
match
---
name: client [43025,43031]
name: client [43747,43753]
===
match
---
name: test_should_raises_401_unauthenticated [16701,16739]
name: test_should_raises_401_unauthenticated [16701,16739]
===
match
---
name: single_dag_run [22211,22225]
name: single_dag_run [22211,22225]
===
match
---
name: timedelta [20235,20244]
name: timedelta [20235,20244]
===
match
---
name: dt [26357,26359]
name: dt [26357,26359]
===
match
---
operator: , [38383,38384]
operator: , [39105,39106]
===
match
---
operator: , [41080,41081]
operator: , [41802,41803]
===
match
---
argument [20559,20565]
argument [20559,20565]
===
match
---
name: timedelta [30162,30171]
name: timedelta [30162,30171]
===
match
---
name: response [39915,39923]
name: response [40637,40645]
===
match
---
trailer [4100,4104]
trailer [4100,4104]
===
match
---
operator: { [10344,10345]
operator: { [10344,10345]
===
match
---
name: counter [3549,3556]
name: counter [3549,3556]
===
match
---
operator: , [15614,15615]
operator: , [15614,15615]
===
match
---
operator: , [27920,27921]
operator: , [27920,27921]
===
match
---
name: state [4402,4407]
name: state [4402,4407]
===
match
---
arglist [41252,41738]
arglist [41974,42460]
===
match
---
operator: } [17610,17611]
operator: } [17610,17611]
===
match
---
operator: } [19748,19749]
operator: } [19748,19749]
===
match
---
operator: == [23390,23392]
operator: == [23390,23392]
===
match
---
operator: , [21087,21088]
operator: , [21087,21088]
===
match
---
name: self [2351,2355]
name: self [2351,2355]
===
match
---
string: "pool" [5601,5607]
string: "pool" [5601,5607]
===
match
---
name: DEFAULT_DATETIME_1 [28817,28835]
name: DEFAULT_DATETIME_1 [28817,28835]
===
match
---
name: DEFAULT_DATETIME_1 [20211,20229]
name: DEFAULT_DATETIME_1 [20211,20229]
===
match
---
operator: == [41785,41787]
operator: == [42507,42509]
===
match
---
name: status_code [37413,37424]
name: status_code [38135,38146]
===
match
---
name: self [23127,23131]
name: self [23127,23131]
===
match
---
assert_stmt [35142,35172]
assert_stmt [35864,35894]
===
match
---
operator: , [20605,20606]
operator: , [20605,20606]
===
match
---
operator: , [31615,31616]
operator: , [32337,32338]
===
match
---
name: self [4914,4918]
name: self [4914,4918]
===
match
---
arith_expr [28640,28681]
arith_expr [28640,28681]
===
match
---
string: "/api/v1/dags/example_python_operator/dagRuns/" [13666,13713]
string: "/api/v1/dags/example_python_operator/dagRuns/" [13666,13713]
===
match
---
param [21811,21816]
param [21811,21816]
===
match
---
trailer [37412,37424]
trailer [38134,38146]
===
match
---
atom [13392,13838]
atom [13392,13838]
===
match
---
name: value [4375,4380]
name: value [4375,4380]
===
match
---
testlist_comp [9680,15521]
testlist_comp [9680,15521]
===
match
---
argument [26370,26376]
argument [26370,26376]
===
match
---
operator: { [20275,20276]
operator: { [20275,20276]
===
match
---
atom_expr [22600,22636]
atom_expr [22600,22636]
===
match
---
dictorsetmaker [5125,5146]
dictorsetmaker [5125,5146]
===
match
---
name: status_code [9556,9567]
name: status_code [9556,9567]
===
match
---
operator: , [42945,42946]
operator: , [43667,43668]
===
match
---
name: response [15908,15916]
name: response [15908,15916]
===
match
---
name: dt [29805,29807]
name: dt [29805,29807]
===
match
---
dictorsetmaker [28514,28573]
dictorsetmaker [28514,28573]
===
match
---
operator: , [31479,31480]
operator: , [32201,32202]
===
match
---
operator: { [32455,32456]
operator: { [33177,33178]
===
match
---
name: json [31970,31974]
name: json [32692,32696]
===
match
---
string: "Naive datetime is disallowed" [24177,24207]
string: "Naive datetime is disallowed" [24177,24207]
===
match
---
name: self [37917,37921]
name: self [38639,38643]
===
match
---
decorator [17246,20638]
decorator [17246,20638]
===
match
---
comparison [16439,16466]
comparison [16439,16466]
===
match
---
string: """Method to create task instances using kwargs and default arguments""" [3399,3471]
string: """Method to create task instances using kwargs and default arguments""" [3399,3471]
===
match
---
argument [10528,10534]
argument [10528,10534]
===
match
---
suite [37546,43300]
suite [38268,44022]
===
match
---
testlist_comp [27650,28365]
testlist_comp [27650,28365]
===
match
---
operator: { [17415,17416]
operator: { [17415,17416]
===
match
---
number: 1 [1404,1405]
number: 1 [1404,1405]
===
match
---
simple_stmt [31812,31994]
simple_stmt [32534,32716]
===
match
---
operator: == [9568,9570]
operator: == [9568,9570]
===
match
---
atom_expr [27408,27420]
atom_expr [27408,27420]
===
match
---
string: "only_failed" [35935,35948]
string: "only_failed" [36657,36670]
===
match
---
operator: + [19423,19424]
operator: + [19423,19424]
===
match
---
atom [30537,31170]
atom [30537,31170]
===
match
---
atom_expr [32635,32648]
atom_expr [33357,33370]
===
match
---
atom [39234,39240]
atom [39956,39962]
===
match
---
atom [15157,15520]
atom [15157,15520]
===
match
---
name: client [35672,35678]
name: client [36394,36400]
===
match
---
param [3187,3195]
param [3187,3195]
===
match
---
operator: } [25447,25448]
operator: } [25447,25448]
===
match
---
string: "print_the_context" [7409,7428]
string: "print_the_context" [7409,7428]
===
match
---
operator: , [26686,26687]
operator: , [26686,26687]
===
match
---
name: response [37198,37206]
name: response [37920,37928]
===
match
---
fstring_start: f" [31853,31855]
fstring_start: f" [32575,32577]
===
match
---
suite [23779,24078]
suite [23779,24078]
===
match
---
param [31465,31480]
param [32187,32202]
===
match
---
operator: , [36833,36834]
operator: , [37555,37556]
===
match
---
number: 2 [19522,19523]
number: 2 [19522,19523]
===
match
---
operator: @ [20642,20643]
operator: @ [20642,20643]
===
match
---
assert_stmt [15901,15935]
assert_stmt [15901,15935]
===
match
---
atom [17578,17610]
atom [17578,17610]
===
match
---
string: "clear only running" [26923,26943]
string: "clear only running" [26923,26943]
===
match
---
operator: == [43288,43290]
operator: == [44010,44012]
===
match
---
name: response [6401,6409]
name: response [6401,6409]
===
match
---
operator: , [15196,15197]
operator: , [15196,15197]
===
match
---
trailer [16517,16567]
trailer [16517,16567]
===
match
---
argument [39228,39240]
argument [39950,39962]
===
match
---
name: FAILED [31122,31128]
name: FAILED [31122,31128]
===
match
---
name: provide_session [31389,31404]
name: provide_session [32111,32126]
===
match
---
trailer [33638,33644]
trailer [34360,34366]
===
match
---
name: self [16265,16269]
name: self [16265,16269]
===
match
---
operator: , [19124,19125]
operator: , [19124,19125]
===
match
---
number: 2 [10533,10534]
number: 2 [10533,10534]
===
match
---
operator: , [32955,32956]
operator: , [33677,33678]
===
match
---
testlist_comp [9698,10234]
testlist_comp [9698,10234]
===
match
---
name: sla_miss [7593,7601]
name: sla_miss [7593,7601]
===
match
---
name: self [37209,37213]
name: self [37931,37935]
===
match
---
dictorsetmaker [14855,14878]
dictorsetmaker [14855,14878]
===
match
---
operator: } [20585,20586]
operator: } [20585,20586]
===
match
---
name: timedelta [2586,2595]
name: timedelta [2586,2595]
===
match
---
arith_expr [20128,20169]
arith_expr [20128,20169]
===
match
---
string: "execution_date" [28976,28992]
string: "execution_date" [28976,28992]
===
match
---
operator: , [9970,9971]
operator: , [9970,9971]
===
match
---
name: timedelta [25715,25724]
name: timedelta [25715,25724]
===
match
---
param [22951,22959]
param [22951,22959]
===
match
---
operator: { [28513,28514]
operator: { [28513,28514]
===
match
---
simple_stmt [23711,23732]
simple_stmt [23711,23732]
===
match
---
name: dag_id [4202,4208]
name: dag_id [4202,4208]
===
match
---
atom [22740,22800]
atom [22740,22800]
===
match
---
operator: { [22378,22379]
operator: { [22378,22379]
===
match
---
operator: = [12288,12289]
operator: = [12288,12289]
===
match
---
string: "api/v1/dags/example_python_operator/dagRuns/TEST_DAG_RUN_ID/taskInstances/print_the_context" [9127,9220]
string: "api/v1/dags/example_python_operator/dagRuns/TEST_DAG_RUN_ID/taskInstances/print_the_context" [9127,9220]
===
match
---
testlist_comp [19815,20606]
testlist_comp [19815,20606]
===
match
---
fstring_string: end_date_gte= [11882,11895]
fstring_string: end_date_gte= [11882,11895]
===
match
---
name: get [9110,9113]
name: get [9110,9113]
===
match
---
operator: , [15396,15397]
operator: , [15396,15397]
===
match
---
operator: { [21629,21630]
operator: { [21629,21630]
===
match
---
trailer [13530,13537]
trailer [13530,13537]
===
match
---
suite [32171,35173]
suite [32893,35895]
===
match
---
trailer [30171,30179]
trailer [30171,30179]
===
match
---
simple_stmt [32002,32037]
simple_stmt [32724,32759]
===
match
---
operator: { [29563,29564]
operator: { [29563,29564]
===
match
---
operator: , [20723,20724]
operator: , [20723,20724]
===
match
---
argument [31074,31080]
argument [31074,31080]
===
match
---
testlist_comp [36154,36511]
testlist_comp [36876,37233]
===
match
---
operator: , [5842,5843]
operator: , [5842,5843]
===
match
---
string: "example_skip_dag" [24003,24021]
string: "example_skip_dag" [24003,24021]
===
match
---
operator: , [31453,31454]
operator: , [32175,32176]
===
match
---
atom_expr [4674,4697]
atom_expr [4674,4697]
===
match
---
string: "latest_only" [21642,21655]
string: "latest_only" [21642,21655]
===
match
---
atom_expr [21341,21377]
atom_expr [21341,21377]
===
match
---
atom [2535,2834]
atom [2535,2834]
===
match
---
atom [11008,11065]
atom [11008,11065]
===
match
---
name: dt [28661,28663]
name: dt [28661,28663]
===
match
---
operator: + [12269,12270]
operator: + [12269,12270]
===
match
---
string: "state" [7083,7090]
string: "state" [7083,7090]
===
match
---
atom_expr [33584,33646]
atom_expr [34306,34368]
===
match
---
operator: = [19442,19443]
operator: = [19442,19443]
===
match
---
trailer [2651,2661]
trailer [2651,2661]
===
match
---
atom_expr [22533,22563]
atom_expr [22533,22563]
===
match
---
dictorsetmaker [15869,15890]
dictorsetmaker [15869,15890]
===
match
---
name: self [9328,9332]
name: self [9328,9332]
===
match
---
dotted_name [36110,36130]
dotted_name [36832,36852]
===
match
---
trailer [23049,23071]
trailer [23049,23071]
===
match
---
decorator [24083,24712]
decorator [24083,24712]
===
match
---
argument [21101,21142]
argument [21101,21142]
===
match
---
number: 2 [18341,18342]
number: 2 [18341,18342]
===
match
---
assert_stmt [23413,23462]
assert_stmt [23413,23462]
===
match
---
argument [2107,2136]
argument [2107,2136]
===
match
---
name: DEFAULT_DATETIME_STR_2 [19708,19730]
name: DEFAULT_DATETIME_STR_2 [19708,19730]
===
match
---
string: "task_instances" [16673,16689]
string: "task_instances" [16673,16689]
===
match
---
operator: , [39446,39447]
operator: , [40168,40169]
===
match
---
number: 2 [27371,27372]
number: 2 [27371,27372]
===
match
---
arith_expr [11582,11623]
arith_expr [11582,11623]
===
match
---
param [20756,20764]
param [20756,20764]
===
match
---
atom_expr [16016,16047]
atom_expr [16016,16047]
===
match
---
operator: { [24317,24318]
operator: { [24317,24318]
===
match
---
operator: } [20335,20336]
operator: } [20335,20336]
===
match
---
name: status_code [40497,40508]
name: status_code [41219,41230]
===
match
---
operator: = [22225,22226]
operator: = [22225,22226]
===
match
---
operator: , [8977,8978]
operator: , [8977,8978]
===
match
---
name: post [23549,23553]
name: post [23549,23553]
===
match
---
atom [28491,29124]
atom [28491,29124]
===
match
---
name: REMOVED [6146,6153]
name: REMOVED [6146,6153]
===
match
---
name: len [23353,23356]
name: len [23353,23356]
===
match
---
atom [36244,36322]
atom [36966,37044]
===
match
---
operator: , [7825,7826]
operator: , [7825,7826]
===
match
---
operator: } [2508,2509]
operator: } [2508,2509]
===
match
---
simple_stmt [2877,2929]
simple_stmt [2877,2929]
===
match
---
string: "test_queue_3" [17472,17486]
string: "test_queue_3" [17472,17486]
===
match
---
string: 'REMOTE_USER' [41348,41361]
string: 'REMOTE_USER' [42070,42083]
===
match
---
operator: + [29626,29627]
operator: + [29626,29627]
===
match
---
param [31446,31451]
param [32168,32173]
===
match
---
name: post [35679,35683]
name: post [36401,36405]
===
match
---
operator: { [4255,4256]
operator: { [4255,4256]
===
match
---
operator: { [7802,7803]
operator: { [7802,7803]
===
match
---
string: "include_past" [38363,38377]
string: "include_past" [39085,39099]
===
match
---
comparison [22454,22481]
comparison [22454,22481]
===
match
---
atom_expr [33704,33724]
atom_expr [34426,34446]
===
match
---
dictorsetmaker [6475,7210]
dictorsetmaker [6475,7210]
===
match
---
name: session [7345,7352]
name: session [7345,7352]
===
match
---
operator: , [32608,32609]
operator: , [33330,33331]
===
match
---
operator: + [11042,11043]
operator: + [11042,11043]
===
match
---
arglist [39383,39819]
arglist [40105,40541]
===
match
---
operator: } [7824,7825]
operator: } [7824,7825]
===
match
---
string: "example_python_operator" [28205,28230]
string: "example_python_operator" [28205,28230]
===
match
---
fstring [11880,11958]
fstring [11880,11958]
===
match
---
operator: { [6130,6131]
operator: { [6130,6131]
===
match
---
name: State [27074,27079]
name: State [27074,27079]
===
match
---
string: "task_instance properties" [21446,21472]
string: "task_instance properties" [21446,21472]
===
match
---
operator: , [11163,11164]
operator: , [11163,11164]
===
match
---
string: "test state filter" [18035,18054]
string: "test state filter" [18035,18054]
===
match
---
trailer [38878,38883]
trailer [39600,39605]
===
match
---
operator: , [37077,37078]
operator: , [37799,37800]
===
match
---
name: DagBag [2989,2995]
name: DagBag [2989,2995]
===
match
---
atom [15868,15891]
atom [15868,15891]
===
match
---
argument [35768,35824]
argument [36490,36546]
===
match
---
string: "test_queue_2" [15293,15307]
string: "test_queue_2" [15293,15307]
===
match
---
operator: { [17735,17736]
operator: { [17735,17736]
===
match
---
operator: } [10535,10536]
operator: } [10535,10536]
===
match
---
name: environ_overrides [23888,23905]
name: environ_overrides [23888,23905]
===
match
---
expr_stmt [2518,2834]
expr_stmt [2518,2834]
===
match
---
operator: { [23234,23235]
operator: { [23234,23235]
===
match
---
operator: = [16963,16964]
operator: = [16963,16964]
===
match
---
trailer [33393,33542]
trailer [34115,34264]
===
match
---
string: "state" [5856,5863]
string: "state" [5856,5863]
===
match
---
operator: = [27917,27918]
operator: = [27917,27918]
===
match
---
atom_expr [24050,24070]
atom_expr [24050,24070]
===
match
---
strings [13666,13786]
strings [13666,13786]
===
match
---
trailer [5182,5194]
trailer [5182,5194]
===
match
---
string: "dry_run" [26726,26735]
string: "dry_run" [26726,26735]
===
match
---
name: days [26370,26374]
name: days [26370,26374]
===
match
---
atom_expr [4762,4777]
atom_expr [4762,4777]
===
match
---
number: 2 [26055,26056]
number: 2 [26055,26056]
===
match
---
argument [12284,12290]
argument [12284,12290]
===
match
---
name: response [16600,16608]
name: response [16600,16608]
===
match
---
operator: , [27539,27540]
operator: , [27539,27540]
===
match
---
string: "default_pool" [8288,8302]
string: "default_pool" [8288,8302]
===
match
---
number: 3 [31079,31080]
number: 3 [31079,31080]
===
match
---
operator: } [25624,25625]
operator: } [25624,25625]
===
match
---
name: json [38516,38520]
name: json [39238,39242]
===
match
---
operator: + [12192,12193]
operator: + [12192,12193]
===
match
---
operator: , [37296,37297]
operator: , [38018,38019]
===
match
---
string: "include_parentdag" [30357,30376]
string: "include_parentdag" [30357,30376]
===
match
---
trailer [37740,37749]
trailer [38462,38471]
===
match
---
string: "include_upstream" [42526,42544]
string: "include_upstream" [43248,43266]
===
match
---
simple_stmt [35656,36061]
simple_stmt [36378,36783]
===
match
---
atom_expr [1622,2053]
atom_expr [1622,2053]
===
match
---
trailer [16280,16422]
trailer [16280,16422]
===
match
---
operator: , [36197,36198]
operator: , [36919,36920]
===
match
---
atom [1891,1956]
atom [1891,1956]
===
match
---
trailer [16781,16868]
trailer [16781,16868]
===
match
---
operator: } [18545,18546]
operator: } [18545,18546]
===
match
---
comparison [35149,35169]
comparison [35871,35891]
===
match
---
fstring_expr [11304,11328]
fstring_expr [11304,11328]
===
match
---
operator: , [36510,36511]
operator: , [37232,37233]
===
match
---
atom_expr [31061,31081]
atom_expr [31061,31081]
===
match
---
name: DEFAULT_DATETIME_STR_2 [25955,25977]
name: DEFAULT_DATETIME_STR_2 [25955,25977]
===
match
---
name: test_should_respond_200_with_reset_dag_run [32113,32155]
name: test_should_respond_200_with_reset_dag_run [32835,32877]
===
match
---
simple_stmt [7581,7603]
simple_stmt [7581,7603]
===
match
---
operator: , [8744,8745]
operator: , [8744,8745]
===
match
---
atom_expr [4296,4326]
atom_expr [4296,4326]
===
match
---
trailer [29994,30002]
trailer [29994,30002]
===
match
---
number: 100 [13129,13132]
number: 100 [13129,13132]
===
match
---
string: "task_instances" [21359,21375]
string: "task_instances" [21359,21375]
===
match
---
suite [16945,17181]
suite [16945,17181]
===
match
---
string: "task_id" [8714,8723]
string: "task_id" [8714,8723]
===
match
---
dictorsetmaker [5248,5983]
dictorsetmaker [5248,5983]
===
match
---
atom [6130,6154]
atom [6130,6154]
===
match
---
atom_expr [25114,25137]
atom_expr [25114,25137]
===
match
---
argument [3966,3980]
argument [3966,3980]
===
match
---
name: expected_ti_count [21861,21878]
name: expected_ti_count [21861,21878]
===
match
---
string: "running" [8895,8904]
string: "running" [8895,8904]
===
match
---
atom [27632,28379]
atom [27632,28379]
===
match
---
number: 2 [18980,18981]
number: 2 [18980,18981]
===
match
---
atom [18140,18163]
atom [18140,18163]
===
match
---
operator: , [15598,15599]
operator: , [15598,15599]
===
match
---
string: "queue" [17369,17376]
string: "queue" [17369,17376]
===
match
---
decorator [15542,15559]
decorator [15542,15559]
===
match
---
operator: , [5787,5788]
operator: , [5787,5788]
===
match
---
name: pytest [1516,1522]
name: pytest [1516,1522]
===
match
---
simple_stmt [21313,21378]
simple_stmt [21313,21378]
===
match
---
string: "example_python_operator" [32189,32214]
string: "example_python_operator" [32911,32936]
===
match
---
operator: } [6153,6154]
operator: } [6153,6154]
===
match
---
operator: } [26446,26447]
operator: } [26446,26447]
===
match
---
operator: , [35334,35335]
operator: , [36056,36057]
===
match
---
name: response [35590,35598]
name: response [36312,36320]
===
match
---
operator: == [25092,25094]
operator: == [25092,25094]
===
match
---
name: dt [12271,12273]
name: dt [12271,12273]
===
match
---
name: TaskInstance [16497,16509]
name: TaskInstance [16497,16509]
===
match
---
operator: , [23079,23080]
operator: , [23079,23080]
===
match
---
atom [12160,12215]
atom [12160,12215]
===
match
---
dictorsetmaker [19334,19366]
dictorsetmaker [19334,19366]
===
match
---
operator: { [10952,10953]
operator: { [10952,10953]
===
match
---
string: "dry_run" [30340,30349]
string: "dry_run" [30340,30349]
===
match
---
trailer [16658,16691]
trailer [16658,16691]
===
match
---
trailer [4367,4374]
trailer [4367,4374]
===
match
---
param [20700,20705]
param [20700,20705]
===
match
---
operator: = [40585,40586]
operator: = [41307,41308]
===
match
---
name: days [11616,11620]
name: days [11616,11620]
===
match
---
string: "/api/v1/dags/example_python_operator/clearTaskInstances" [35697,35754]
string: "/api/v1/dags/example_python_operator/clearTaskInstances" [36419,36476]
===
match
---
string: "2020-01-01T00:00:00+00:00" [8625,8652]
string: "2020-01-01T00:00:00+00:00" [8625,8652]
===
match
---
operator: , [33101,33102]
operator: , [33823,33824]
===
match
---
trailer [36912,36934]
trailer [37634,37656]
===
match
---
atom [14938,15109]
atom [14938,15109]
===
match
---
name: session [16121,16128]
name: session [16121,16128]
===
match
---
operator: , [1344,1345]
operator: , [1344,1345]
===
match
---
name: status_code [16448,16459]
name: status_code [16448,16459]
===
match
---
name: TaskInstance [941,953]
name: TaskInstance [941,953]
===
match
---
name: self [24833,24837]
name: self [24833,24837]
===
match
---
argument [15850,15891]
argument [15850,15891]
===
match
---
atom [13852,14302]
atom [13852,14302]
===
match
---
operator: } [30796,30797]
operator: } [30796,30797]
===
match
---
string: "duration_gte" [18628,18642]
string: "duration_gte" [18628,18642]
===
match
---
name: airflow [1000,1007]
name: airflow [1000,1007]
===
match
---
operator: , [1272,1273]
operator: , [1272,1273]
===
match
---
operator: == [5195,5197]
operator: == [5195,5197]
===
match
---
name: ti_init [3887,3894]
name: ti_init [3887,3894]
===
match
---
comparison [23353,23404]
comparison [23353,23404]
===
match
---
trailer [37718,37740]
trailer [38440,38462]
===
match
---
atom [19861,20355]
atom [19861,20355]
===
match
---
name: dt [20149,20151]
name: dt [20149,20151]
===
match
---
string: "queue" [8379,8386]
string: "queue" [8379,8386]
===
match
---
name: self [32156,32160]
name: self [32878,32882]
===
match
---
argument [7488,7520]
argument [7488,7520]
===
match
---
operator: { [31933,31934]
operator: { [32655,32656]
===
match
---
operator: } [9969,9970]
operator: } [9969,9970]
===
match
---
dotted_name [1043,1064]
dotted_name [1043,1064]
===
match
---
atom_expr [5973,5982]
atom_expr [5973,5982]
===
match
---
dictorsetmaker [32841,32941]
dictorsetmaker [33563,33663]
===
match
---
argument [1531,1545]
argument [1531,1545]
===
match
---
fstring_end: " [11368,11369]
fstring_end: " [11368,11369]
===
match
---
simple_stmt [3621,3665]
simple_stmt [3621,3665]
===
match
---
operator: , [25732,25733]
operator: , [25732,25733]
===
match
---
trailer [27365,27373]
trailer [27365,27373]
===
match
---
operator: { [13469,13470]
operator: { [13469,13470]
===
match
---
operator: { [19606,19607]
operator: { [19606,19607]
===
match
---
operator: = [29999,30000]
operator: = [29999,30000]
===
match
---
atom [21552,21570]
atom [21552,21570]
===
match
---
operator: , [41041,41042]
operator: , [41763,41764]
===
match
---
string: "start_date" [10401,10413]
string: "start_date" [10401,10413]
===
match
---
param [37674,37679]
param [38396,38401]
===
match
---
trailer [22282,22287]
trailer [22282,22287]
===
match
---
atom_expr [31823,31993]
atom_expr [32545,32715]
===
match
---
name: session [37696,37703]
name: session [38418,38425]
===
match
---
operator: , [8266,8267]
operator: , [8266,8267]
===
match
---
operator: { [27288,27289]
operator: { [27288,27289]
===
match
---
atom_expr [18104,18117]
atom_expr [18104,18117]
===
match
---
trailer [35053,35058]
trailer [35775,35780]
===
match
---
atom_expr [21012,21179]
atom_expr [21012,21179]
===
match
---
operator: = [38860,38861]
operator: = [39582,39583]
===
match
---
name: client [39358,39364]
name: client [40080,40086]
===
match
---
name: environ_overrides [41329,41346]
name: environ_overrides [42051,42068]
===
match
---
string: "start_date" [21956,21968]
string: "start_date" [21956,21968]
===
match
---
atom [36337,36381]
atom [37059,37103]
===
match
---
simple_stmt [1126,1170]
simple_stmt [1126,1170]
===
match
---
string: "Naive datetime is disallowed" [24271,24301]
string: "Naive datetime is disallowed" [24271,24301]
===
match
---
atom_expr [13525,13537]
atom_expr [13525,13537]
===
match
---
operator: + [9947,9948]
operator: + [9947,9948]
===
match
---
string: "execution_date" [20027,20043]
string: "execution_date" [20027,20043]
===
match
---
name: post [22283,22287]
name: post [22283,22287]
===
match
---
name: session [4762,4769]
name: session [4762,4769]
===
match
---
name: State [29070,29075]
name: State [29070,29075]
===
match
---
string: "pool" [8280,8286]
string: "pool" [8280,8286]
===
match
---
trailer [35678,35683]
trailer [36400,36405]
===
match
---
operator: { [36245,36246]
operator: { [36967,36968]
===
match
---
atom_expr [43221,43241]
atom_expr [43943,43963]
===
match
---
operator: + [29013,29014]
operator: + [29013,29014]
===
match
---
name: add [4465,4468]
name: add [4465,4468]
===
match
---
string: "example_python_operator" [3218,3243]
string: "example_python_operator" [3218,3243]
===
match
---
operator: } [29540,29541]
operator: } [29540,29541]
===
match
---
testlist_comp [25387,25803]
testlist_comp [25387,25803]
===
match
---
name: test_should_respond_200 [15567,15590]
name: test_should_respond_200 [15567,15590]
===
match
---
trailer [16269,16276]
trailer [16269,16276]
===
match
---
string: "execution_date" [30120,30136]
string: "execution_date" [30120,30136]
===
match
---
name: test_should_raise_404_not_found_dag [40525,40560]
name: test_should_raise_404_not_found_dag [41247,41282]
===
match
---
operator: } [12214,12215]
operator: } [12214,12215]
===
match
---
argument [5106,5147]
argument [5106,5147]
===
match
---
assert_stmt [16584,16630]
assert_stmt [16584,16630]
===
match
---
string: "example_python_operator" [23644,23669]
string: "example_python_operator" [23644,23669]
===
match
---
atom_expr [11603,11623]
atom_expr [11603,11623]
===
match
---
string: "include_past" [41021,41035]
string: "include_past" [41743,41757]
===
match
---
name: task_instances [6114,6128]
name: task_instances [6114,6128]
===
match
---
operator: , [12138,12139]
operator: , [12138,12139]
===
match
---
argument [7534,7561]
argument [7534,7561]
===
match
---
operator: , [30904,30905]
operator: , [30904,30905]
===
match
---
operator: = [37029,37030]
operator: = [37751,37752]
===
match
---
arith_expr [29607,29648]
arith_expr [29607,29648]
===
match
---
operator: } [13210,13211]
operator: } [13210,13211]
===
match
---
trailer [30612,30619]
trailer [30612,30619]
===
match
---
operator: + [19981,19982]
operator: + [19981,19982]
===
match
---
name: create_task_instances [22078,22099]
name: create_task_instances [22078,22099]
===
match
---
name: expand [36124,36130]
name: expand [36846,36852]
===
match
---
operator: , [31725,31726]
operator: , [32447,32448]
===
match
---
argument [23081,23106]
argument [23081,23106]
===
match
---
operator: { [29917,29918]
operator: { [29917,29918]
===
match
---
trailer [35683,36060]
trailer [36405,36782]
===
match
---
name: DEFAULT_DATETIME_1 [25514,25532]
name: DEFAULT_DATETIME_1 [25514,25532]
===
match
---
trailer [22617,22635]
trailer [22617,22635]
===
match
---
name: all [37882,37885]
name: all [38604,38607]
===
match
---
trailer [37933,38448]
trailer [38655,39170]
===
match
---
name: default_time [2450,2462]
name: default_time [2450,2462]
===
match
---
argument [33519,33531]
argument [34241,34253]
===
match
---
fstring_string: &start_date_lte= [10756,10772]
fstring_string: &start_date_lte= [10756,10772]
===
match
---
name: self [9302,9306]
name: self [9302,9306]
===
match
---
name: i [3678,3679]
name: i [3678,3679]
===
match
---
name: dag_id [22134,22140]
name: dag_id [22134,22140]
===
match
---
operator: , [38305,38306]
operator: , [39027,39028]
===
match
---
operator: , [1687,1688]
operator: , [1687,1688]
===
match
---
operator: , [38117,38118]
operator: , [38839,38840]
===
match
---
simple_stmt [42965,43001]
simple_stmt [43687,43723]
===
match
---
string: "pool" [6828,6834]
string: "pool" [6828,6834]
===
match
---
atom [14439,14462]
atom [14439,14462]
===
match
---
name: task_instances [3639,3653]
name: task_instances [3639,3653]
===
match
---
operator: { [10772,10773]
operator: { [10772,10773]
===
match
---
operator: , [33196,33197]
operator: , [33918,33919]
===
match
---
testlist_comp [18035,18343]
testlist_comp [18035,18343]
===
match
---
simple_stmt [9540,9575]
simple_stmt [9540,9575]
===
match
---
operator: , [14507,14508]
operator: , [14507,14508]
===
match
---
operator: , [29330,29331]
operator: , [29330,29331]
===
match
---
simple_stmt [24877,25056]
simple_stmt [24877,25056]
===
match
---
name: timedelta [20549,20558]
name: timedelta [20549,20558]
===
match
---
name: DEFAULT_DATETIME_1 [19348,19366]
name: DEFAULT_DATETIME_1 [19348,19366]
===
match
---
name: run_id [4573,4579]
name: run_id [4573,4579]
===
match
---
operator: { [35786,35787]
operator: { [36508,36509]
===
match
---
dictorsetmaker [24224,24268]
dictorsetmaker [24224,24268]
===
match
---
string: "pool_slots" [8316,8328]
string: "pool_slots" [8316,8328]
===
match
---
argument [20245,20251]
argument [20245,20251]
===
match
---
atom [38524,38846]
atom [39246,39568]
===
match
---
suite [37705,39279]
suite [38427,40001]
===
match
---
name: create_task_instances [42970,42991]
name: create_task_instances [43692,43713]
===
match
---
name: status_code [33713,33724]
name: status_code [34435,34446]
===
match
---
operator: , [2603,2604]
operator: , [2603,2604]
===
match
---
operator: , [28145,28146]
operator: , [28145,28146]
===
match
---
trailer [27355,27365]
trailer [27355,27365]
===
match
---
operator: , [22855,22856]
operator: , [22855,22856]
===
match
---
expr_stmt [23788,24034]
expr_stmt [23788,24034]
===
match
---
trailer [28089,28097]
trailer [28089,28097]
===
match
---
string: '2020-11-10T12:42:39.442973' [24240,24268]
string: '2020-11-10T12:42:39.442973' [24240,24268]
===
match
---
operator: { [31231,31232]
operator: { [31231,31232]
===
match
---
atom [13094,13230]
atom [13094,13230]
===
match
---
operator: , [20586,20587]
operator: , [20586,20587]
===
match
---
name: read_dags_from_db [3019,3036]
name: read_dags_from_db [3019,3036]
===
match
---
comparison [16646,16691]
comparison [16646,16691]
===
match
---
name: dr [4162,4164]
name: dr [4162,4164]
===
match
---
name: dt [20315,20317]
name: dt [20315,20317]
===
match
---
string: "" [6718,6720]
string: "" [6718,6720]
===
match
---
argument [31915,31956]
argument [32637,32678]
===
match
---
operator: } [28344,28345]
operator: } [28344,28345]
===
match
---
name: permissions [1779,1790]
name: permissions [1779,1790]
===
match
---
string: "example_python_operator" [27687,27712]
string: "example_python_operator" [27687,27712]
===
match
---
name: payload [33524,33531]
name: payload [34246,34253]
===
match
---
atom_expr [19504,19524]
atom_expr [19504,19524]
===
match
---
atom_expr [3065,3076]
atom_expr [3065,3076]
===
match
---
operator: = [17087,17088]
operator: = [17087,17088]
===
match
---
name: create_task_instances [36913,36934]
name: create_task_instances [37635,37656]
===
match
---
string: "/api/v1/dags/~/dagRuns/~/taskInstances/list" [23567,23612]
string: "/api/v1/dags/~/dagRuns/~/taskInstances/list" [23567,23612]
===
match
---
operator: { [30642,30643]
operator: { [30642,30643]
===
match
---
atom_expr [15667,15809]
atom_expr [15667,15809]
===
match
---
operator: , [12215,12216]
operator: , [12215,12216]
===
match
---
operator: , [19024,19025]
operator: , [19024,19025]
===
match
---
decorated [37551,39279]
decorated [38273,40001]
===
match
---
operator: @ [9635,9636]
operator: @ [9635,9636]
===
match
---
number: 1 [6878,6879]
number: 1 [6878,6879]
===
match
---
name: client [24893,24899]
name: client [24893,24899]
===
match
---
operator: { [11304,11305]
operator: { [11304,11305]
===
match
---
trailer [23027,23036]
trailer [23027,23036]
===
match
---
trailer [24892,24899]
trailer [24892,24899]
===
match
---
operator: = [23275,23276]
operator: = [23275,23276]
===
match
---
name: MANUAL [4685,4691]
name: MANUAL [4685,4691]
===
match
---
operator: } [10377,10378]
operator: } [10377,10378]
===
match
---
operator: = [31932,31933]
operator: = [32654,32655]
===
match
---
operator: , [24208,24209]
operator: , [24208,24209]
===
match
---
operator: } [12473,12474]
operator: } [12473,12474]
===
match
---
name: dag [38955,38958]
name: dag [39677,39680]
===
match
---
number: 200 [5198,5201]
number: 200 [5198,5201]
===
match
---
trailer [21028,21179]
trailer [21028,21179]
===
match
---
string: "test state filter" [13410,13429]
string: "test state filter" [13410,13429]
===
match
---
name: TaskInstance [37837,37849]
name: TaskInstance [38559,38571]
===
match
---
dictorsetmaker [18491,18506]
dictorsetmaker [18491,18506]
===
match
---
operator: , [13020,13021]
operator: , [13020,13021]
===
match
---
name: days [11057,11061]
name: days [11057,11061]
===
match
---
operator: , [42017,42018]
operator: , [42739,42740]
===
match
---
expr_stmt [40576,41106]
expr_stmt [41298,41828]
===
match
---
dictorsetmaker [36430,36463]
dictorsetmaker [37152,37185]
===
match
---
operator: , [43113,43114]
operator: , [43835,43836]
===
match
---
operator: } [39817,39818]
operator: } [40539,40540]
===
match
---
string: "task_id" [40159,40168]
string: "task_id" [40881,40890]
===
match
---
operator: , [33086,33087]
operator: , [33808,33809]
===
match
---
name: dag_id [33423,33429]
name: dag_id [34145,34151]
===
match
---
suite [3737,3759]
suite [3737,3759]
===
match
---
simple_stmt [5167,5202]
simple_stmt [5167,5202]
===
match
---
trailer [37815,37829]
trailer [38537,38551]
===
match
---
fstring_string: taskInstances?execution_date_lte= [10138,10171]
fstring_string: taskInstances?execution_date_lte= [10138,10171]
===
match
---
testlist_comp [10280,10835]
testlist_comp [10280,10835]
===
match
---
trailer [23071,23107]
trailer [23071,23107]
===
match
---
arith_expr [12173,12214]
arith_expr [12173,12214]
===
match
---
name: payload [22420,22427]
name: payload [22420,22427]
===
match
---
name: self [35221,35225]
name: self [35943,35947]
===
match
---
name: session [6060,6067]
name: session [6060,6067]
===
match
---
name: DEFAULT_DATETIME_1 [29784,29802]
name: DEFAULT_DATETIME_1 [29784,29802]
===
match
---
name: self [6078,6082]
name: self [6078,6082]
===
match
---
trailer [40496,40508]
trailer [41218,41230]
===
match
---
string: "/api/v1/dags/example_python_operator/updateTaskInstancesState" [43050,43113]
string: "/api/v1/dags/example_python_operator/updateTaskInstancesState" [43772,43835]
===
match
---
string: "/api/v1/dags/example_python_operator/dagRuns/TEST_DAG_RUN_ID/" [12835,12898]
string: "/api/v1/dags/example_python_operator/dagRuns/TEST_DAG_RUN_ID/" [12835,12898]
===
match
---
operator: { [26292,26293]
operator: { [26292,26293]
===
match
---
operator: = [7408,7409]
operator: = [7408,7409]
===
match
---
assert_stmt [7889,9023]
assert_stmt [7889,9023]
===
match
---
name: app [2070,2073]
name: app [2070,2073]
===
match
---
simple_stmt [37714,37750]
simple_stmt [38436,38472]
===
match
---
string: "test_pool_2" [14448,14461]
string: "test_pool_2" [14448,14461]
===
match
---
trailer [16667,16672]
trailer [16667,16672]
===
match
---
operator: , [30402,30403]
operator: , [30402,30403]
===
match
---
operator: = [31685,31686]
operator: = [32407,32408]
===
match
---
name: len [21341,21344]
name: len [21341,21344]
===
match
---
string: "example_python_operator" [26961,26986]
string: "example_python_operator" [26961,26986]
===
match
---
atom [41828,42837]
atom [42550,43559]
===
match
---
name: json [32065,32069]
name: json [32787,32791]
===
match
---
name: self [21012,21016]
name: self [21012,21016]
===
match
---
operator: = [16764,16765]
operator: = [16764,16765]
===
match
---
operator: } [5146,5147]
operator: } [5146,5147]
===
match
---
operator: , [6112,6113]
operator: , [6112,6113]
===
match
---
name: configured_app [2318,2332]
name: configured_app [2318,2332]
===
match
---
string: "task_id" [40793,40802]
string: "task_id" [41515,41524]
===
match
---
operator: , [21472,21473]
operator: , [21472,21473]
===
match
---
atom [12106,12138]
atom [12106,12138]
===
match
---
string: "execution_date" [5383,5399]
string: "execution_date" [5383,5399]
===
match
---
string: "test" [22394,22400]
string: "test" [22394,22400]
===
match
---
argument [6333,6374]
argument [6333,6374]
===
match
---
name: get [7659,7662]
name: get [7659,7662]
===
match
---
arglist [3086,3131]
arglist [3086,3131]
===
match
---
comparison [16591,16630]
comparison [16591,16630]
===
match
---
operator: , [1919,1920]
operator: , [1919,1920]
===
match
---
suite [31530,32104]
suite [32252,32826]
===
match
---
string: "/api/v1/dags/example_python_operator/dagRuns/TEST_DAG_RUN_ID/taskInstances" [10617,10693]
string: "/api/v1/dags/example_python_operator/dagRuns/TEST_DAG_RUN_ID/taskInstances" [10617,10693]
===
match
---
operator: , [9220,9221]
operator: , [9220,9221]
===
match
---
name: get [9340,9343]
name: get [9340,9343]
===
match
---
simple_stmt [23001,23037]
simple_stmt [23001,23037]
===
match
---
name: DEFAULT_DATETIME_STR_2 [11345,11367]
name: DEFAULT_DATETIME_STR_2 [11345,11367]
===
match
---
name: response [41764,41772]
name: response [42486,42494]
===
match
---
name: response [9547,9555]
name: response [9547,9555]
===
match
---
trailer [30709,30719]
trailer [30709,30719]
===
match
---
atom [9826,9887]
atom [9826,9887]
===
match
---
string: "" [5491,5493]
string: "" [5491,5493]
===
match
---
name: dag_id [36969,36975]
name: dag_id [37691,37697]
===
match
---
name: days [26547,26551]
name: days [26547,26551]
===
match
---
string: 'task_instances' [38538,38554]
string: 'task_instances' [39260,39276]
===
match
---
argument [33039,33045]
argument [33761,33767]
===
match
---
trailer [33126,33148]
trailer [33848,33870]
===
match
---
arith_expr [26513,26554]
arith_expr [26513,26554]
===
match
---
operator: , [27712,27713]
operator: , [27712,27713]
===
match
---
string: "task_id" [38135,38144]
string: "task_id" [38857,38866]
===
match
---
string: "TEST_DAG_RUN_ID/taskInstances?pool=test_pool_1,test_pool_2" [14190,14250]
string: "TEST_DAG_RUN_ID/taskInstances?pool=test_pool_1,test_pool_2" [14190,14250]
===
match
---
operator: , [28187,28188]
operator: , [28187,28188]
===
match
---
operator: = [37105,37106]
operator: = [37827,37828]
===
match
---
string: "execution_date" [40841,40857]
string: "execution_date" [41563,41579]
===
match
---
number: 2 [10833,10834]
number: 2 [10833,10834]
===
match
---
string: "new_state" [38401,38412]
string: "new_state" [39123,39134]
===
match
---
trailer [23433,23450]
trailer [23433,23450]
===
match
---
operator: , [8589,8590]
operator: , [8589,8590]
===
match
---
trailer [32017,32029]
trailer [32739,32751]
===
match
---
dotted_name [1000,1022]
dotted_name [1000,1022]
===
match
---
atom_expr [2989,3056]
atom_expr [2989,3056]
===
match
---
dotted_name [959,975]
dotted_name [959,975]
===
match
---
name: json [40737,40741]
name: json [41459,41463]
===
match
---
string: "end_date" [12161,12171]
string: "end_date" [12161,12171]
===
match
---
string: "/api/v1/dags/example_python_operator/dagRuns/TEST_DAG_RUN_ID/taskInstances/print_the_context" [6225,6319]
string: "/api/v1/dags/example_python_operator/dagRuns/TEST_DAG_RUN_ID/taskInstances/print_the_context" [6225,6319]
===
match
---
tfpdef [3204,3215]
tfpdef [3204,3215]
===
match
---
string: "pool" [17930,17936]
string: "pool" [17930,17936]
===
match
---
operator: { [40108,40109]
operator: { [40830,40831]
===
match
---
operator: , [33820,33821]
operator: , [34542,34543]
===
match
---
operator: , [1804,1805]
operator: , [1804,1805]
===
match
---
operator: = [31643,31644]
operator: = [32365,32366]
===
match
---
trailer [4464,4468]
trailer [4464,4468]
===
match
---
operator: = [40699,40700]
operator: = [41421,41422]
===
match
---
parameters [37673,37704]
parameters [38395,38426]
===
match
---
name: DEFAULT_DATETIME_1 [32474,32492]
name: DEFAULT_DATETIME_1 [33196,33214]
===
match
---
name: response [35656,35664]
name: response [36378,36386]
===
match
---
name: timedelta [27903,27912]
name: timedelta [27903,27912]
===
match
---
trailer [3688,3697]
trailer [3688,3697]
===
match
---
string: "example_python_operator" [28448,28473]
string: "example_python_operator" [28448,28473]
===
match
---
comparison [40488,40515]
comparison [41210,41237]
===
match
---
string: 'detail' [25128,25136]
string: 'detail' [25128,25136]
===
match
---
operator: , [1877,1878]
operator: , [1877,1878]
===
match
---
argument [25032,25044]
argument [25032,25044]
===
match
---
param [42928,42936]
param [43650,43658]
===
match
---
name: ACTION_CAN_READ [1904,1919]
name: ACTION_CAN_READ [1904,1919]
===
match
---
string: "duration" [13156,13166]
string: "duration" [13156,13166]
===
match
---
name: create_task_instances [3142,3163]
name: create_task_instances [3142,3163]
===
match
---
name: min [3631,3634]
name: min [3631,3634]
===
match
---
arith_expr [11102,11143]
arith_expr [11102,11143]
===
match
---
number: 400 [37428,37431]
number: 400 [38150,38153]
===
match
---
testlist_comp [41842,42827]
testlist_comp [42564,43549]
===
match
---
operator: , [11144,11145]
operator: , [11144,11145]
===
match
---
operator: } [23943,23944]
operator: } [23943,23944]
===
match
---
name: payload [21852,21859]
name: payload [21852,21859]
===
match
---
operator: } [33996,33997]
operator: } [34718,34719]
===
match
---
name: DEFAULT_DATETIME_1 [12173,12191]
name: DEFAULT_DATETIME_1 [12173,12191]
===
match
---
operator: , [27063,27064]
operator: , [27063,27064]
===
match
---
string: "execution_date" [29481,29497]
string: "execution_date" [29481,29497]
===
match
---
trailer [39937,39942]
trailer [40659,40664]
===
match
---
number: 4 [31350,31351]
number: 4 [31350,31351]
===
match
---
atom [15283,15308]
atom [15283,15308]
===
match
---
operator: } [34710,34711]
operator: } [35432,35433]
===
match
---
string: "example_subdag_operator.section-1" [30286,30321]
string: "example_subdag_operator.section-1" [30286,30321]
===
match
---
import_name [785,806]
import_name [785,806]
===
match
---
operator: , [3177,3178]
operator: , [3177,3178]
===
match
---
trailer [16887,16897]
trailer [16887,16897]
===
match
---
atom [17291,17645]
atom [17291,17645]
===
match
---
name: State [30939,30944]
name: State [30939,30944]
===
match
---
operator: { [18627,18628]
operator: { [18627,18628]
===
match
---
trailer [33038,33046]
trailer [33760,33768]
===
match
---
trailer [16777,16781]
trailer [16777,16781]
===
match
---
arglist [43050,43195]
arglist [43772,43917]
===
match
---
operator: , [36034,36035]
operator: , [36756,36757]
===
match
---
testlist_comp [29480,30250]
testlist_comp [29480,30250]
===
match
---
string: '2020-01-02T00:00:00+00:00' [34151,34178]
string: '2020-01-02T00:00:00+00:00' [34873,34900]
===
match
---
name: payload [37370,37377]
name: payload [38092,38099]
===
match
---
atom_expr [37917,38448]
atom_expr [38639,39170]
===
match
---
arith_expr [9928,9969]
arith_expr [9928,9969]
===
match
---
string: "queue" [15237,15244]
string: "queue" [15237,15244]
===
match
---
comparison [43221,43248]
comparison [43943,43970]
===
match
---
operator: + [33024,33025]
operator: + [33746,33747]
===
match
---
param [2318,2332]
param [2318,2332]
===
match
---
assert_stmt [41115,41149]
assert_stmt [41837,41871]
===
match
---
name: environ_overrides [9464,9481]
name: environ_overrides [9464,9481]
===
match
---
suite [35227,35600]
suite [35949,36322]
===
match
---
name: DEFAULT_DATETIME_1 [27045,27063]
name: DEFAULT_DATETIME_1 [27045,27063]
===
match
---
name: FAILED [27961,27967]
name: FAILED [27961,27967]
===
match
---
name: timedelta [33029,33038]
name: timedelta [33751,33760]
===
match
---
number: 2 [29823,29824]
number: 2 [29823,29824]
===
match
---
number: 3 [32898,32899]
number: 3 [33620,33621]
===
match
---
operator: = [22419,22420]
operator: = [22419,22420]
===
match
---
simple_stmt [15901,15936]
simple_stmt [15901,15936]
===
match
---
operator: = [39233,39234]
operator: = [39955,39956]
===
match
---
name: self [3487,3491]
name: self [3487,3491]
===
match
---
atom [21119,21142]
atom [21119,21142]
===
match
---
operator: , [13951,13952]
operator: , [13951,13952]
===
match
---
string: 'dag_id' [38596,38604]
string: 'dag_id' [39318,39326]
===
match
---
string: "duration" [13117,13127]
string: "duration" [13117,13127]
===
match
---
name: self [16740,16744]
name: self [16740,16744]
===
match
---
atom_expr [2518,2532]
atom_expr [2518,2532]
===
match
---
operator: , [11185,11186]
operator: , [11185,11186]
===
match
---
atom_expr [21224,21237]
atom_expr [21224,21237]
===
match
---
atom_expr [16183,16245]
atom_expr [16183,16245]
===
match
---
trailer [4984,5158]
trailer [4984,5158]
===
match
---
string: "with dag filter" [22705,22722]
string: "with dag filter" [22705,22722]
===
match
---
testlist_comp [30559,31152]
testlist_comp [30559,31152]
===
match
---
atom_expr [37209,37388]
atom_expr [37931,38110]
===
match
---
parameters [31436,31529]
parameters [32158,32251]
===
match
---
name: self [42965,42969]
name: self [43687,43691]
===
match
---
name: client [21017,21023]
name: client [21017,21023]
===
match
---
string: "start_date_lte" [24318,24334]
string: "start_date_lte" [24318,24334]
===
match
---
comp_op [3596,3602]
comp_op [3596,3602]
===
match
---
string: "notification_sent" [8670,8689]
string: "notification_sent" [8670,8689]
===
match
---
arith_expr [27879,27920]
arith_expr [27879,27920]
===
match
---
trailer [26546,26554]
trailer [26546,26554]
===
match
---
dictorsetmaker [26318,26425]
dictorsetmaker [26318,26425]
===
match
---
name: test_utils [1224,1234]
name: test_utils [1224,1234]
===
match
---
string: "state" [26248,26255]
string: "state" [26248,26255]
===
match
---
operator: , [10577,10578]
operator: , [10577,10578]
===
match
---
trailer [32746,32754]
trailer [33468,33476]
===
match
---
string: 'task_id' [34672,34681]
string: 'task_id' [35394,35403]
===
match
---
simple_stmt [43214,43249]
simple_stmt [43936,43971]
===
match
---
testlist_comp [22687,22856]
testlist_comp [22687,22856]
===
match
---
dictorsetmaker [9827,9886]
dictorsetmaker [9827,9886]
===
match
---
trailer [4374,4380]
trailer [4374,4380]
===
match
---
assert_stmt [22572,22636]
assert_stmt [22572,22636]
===
match
---
string: "/api/v1/dags/~/dagRuns/~/taskInstances/list" [21042,21087]
string: "/api/v1/dags/~/dagRuns/~/taskInstances/list" [21042,21087]
===
match
---
trailer [2899,2911]
trailer [2899,2911]
===
match
---
operator: == [16652,16654]
operator: == [16652,16654]
===
match
---
operator: , [21570,21571]
operator: , [21570,21571]
===
match
---
simple_stmt [9087,9232]
simple_stmt [9087,9232]
===
match
---
atom [12737,12754]
atom [12737,12754]
===
match
---
operator: , [38751,38752]
operator: , [39473,39474]
===
match
---
operator: , [7174,7175]
operator: , [7174,7175]
===
match
---
name: provide_session [15543,15558]
name: provide_session [15543,15558]
===
match
---
operator: , [22946,22947]
operator: , [22946,22947]
===
match
---
argument [19438,19444]
argument [19438,19444]
===
match
---
name: range [3683,3688]
name: range [3683,3688]
===
match
---
string: "execution_date" [8062,8078]
string: "execution_date" [8062,8078]
===
match
---
name: expected [25141,25149]
name: expected [25141,25149]
===
match
---
funcdef [2296,3133]
funcdef [2296,3133]
===
match
---
name: self [3065,3069]
name: self [3065,3069]
===
match
---
name: self [23773,23777]
name: self [23773,23777]
===
match
---
name: session [36631,36638]
name: session [37353,37360]
===
match
---
name: days [11693,11697]
name: days [11693,11697]
===
match
---
operator: , [14720,14721]
operator: , [14720,14721]
===
match
---
atom_expr [30762,30774]
atom_expr [30762,30774]
===
match
---
operator: { [36680,36681]
operator: { [37402,37403]
===
match
---
operator: , [32940,32941]
operator: , [33662,33663]
===
match
---
suite [4036,4077]
suite [4036,4077]
===
match
---
fstring_expr [10732,10756]
fstring_expr [10732,10756]
===
match
---
operator: , [18703,18704]
operator: , [18703,18704]
===
match
---
string: 'example_python_operator' [34515,34540]
string: 'example_python_operator' [35237,35262]
===
match
---
param [21861,21879]
param [21861,21879]
===
match
---
operator: , [24803,24804]
operator: , [24803,24804]
===
match
---
operator: , [27195,27196]
operator: , [27195,27196]
===
match
---
assert_stmt [16005,16063]
assert_stmt [16005,16063]
===
match
---
argument [39200,39214]
argument [39922,39936]
===
match
---
atom_expr [3487,3514]
atom_expr [3487,3514]
===
match
---
simple_stmt [4089,4105]
simple_stmt [4089,4105]
===
match
---
string: 'example_python_operator' [34039,34064]
string: 'example_python_operator' [34761,34786]
===
match
---
string: 'dag_id' [34505,34513]
string: 'dag_id' [35227,35235]
===
match
---
string: "execution_date" [31022,31038]
string: "execution_date" [31022,31038]
===
match
---
name: counter [3621,3628]
name: counter [3621,3628]
===
match
---
testlist_comp [14701,15129]
testlist_comp [14701,15129]
===
match
---
argument [43182,43194]
argument [43904,43916]
===
match
---
atom_expr [2563,2580]
atom_expr [2563,2580]
===
match
---
atom_expr [2877,2888]
atom_expr [2877,2888]
===
match
---
trailer [21203,21215]
trailer [21203,21215]
===
match
---
string: "new_state" [42219,42230]
string: "new_state" [42941,42952]
===
match
---
name: response [16016,16024]
name: response [16016,16024]
===
match
---
trailer [20078,20086]
trailer [20078,20086]
===
match
---
name: DEFAULT_DATETIME_1 [11659,11677]
name: DEFAULT_DATETIME_1 [11659,11677]
===
match
---
operator: , [35169,35170]
operator: , [35891,35892]
===
match
---
number: 2 [28856,28857]
number: 2 [28856,28857]
===
match
---
arglist [23072,23106]
arglist [23072,23106]
===
match
---
string: "end_date" [8009,8019]
string: "end_date" [8009,8019]
===
match
---
testlist_comp [17291,20621]
testlist_comp [17291,20621]
===
match
---
dictorsetmaker [11570,11623]
dictorsetmaker [11570,11623]
===
match
---
trailer [9951,9961]
trailer [9951,9961]
===
match
---
argument [30172,30178]
argument [30172,30178]
===
match
---
arglist [23157,23284]
arglist [23157,23284]
===
match
---
operator: , [41370,41371]
operator: , [42092,42093]
===
match
---
trailer [4060,4076]
trailer [4060,4076]
===
match
---
name: json [33519,33523]
name: json [34241,34245]
===
match
---
string: "{}" [6688,6692]
string: "{}" [6688,6692]
===
match
---
dictorsetmaker [28622,28729]
dictorsetmaker [28622,28729]
===
match
---
operator: , [18565,18566]
operator: , [18565,18566]
===
match
---
number: 10000.0 [5309,5316]
number: 10000.0 [5309,5316]
===
match
---
trailer [20151,20161]
trailer [20151,20161]
===
match
---
name: timedelta [32591,32600]
name: timedelta [33313,33322]
===
match
---
name: dag [38856,38859]
name: dag [39578,39581]
===
match
---
atom [40051,40089]
atom [40773,40811]
===
match
---
name: test_should_respond_200 [4866,4889]
name: test_should_respond_200 [4866,4889]
===
match
---
trailer [27079,27087]
trailer [27079,27087]
===
match
---
dictorsetmaker [17781,17802]
dictorsetmaker [17781,17802]
===
match
---
operator: , [4068,4069]
operator: , [4068,4069]
===
match
---
funcdef [35605,36104]
funcdef [36327,36826]
===
match
---
name: FAILED [30043,30049]
name: FAILED [30043,30049]
===
match
---
name: create_task_instances [23050,23071]
name: create_task_instances [23050,23071]
===
match
---
name: response [37404,37412]
name: response [38126,38134]
===
match
---
name: RUNNING [36866,36873]
name: RUNNING [37588,37595]
===
match
---
arith_expr [32713,32754]
arith_expr [33435,33476]
===
match
---
name: expand [25231,25237]
name: expand [25231,25237]
===
match
---
trailer [1830,1846]
trailer [1830,1846]
===
match
---
name: self [35667,35671]
name: self [36389,36393]
===
match
---
import_from [1038,1087]
import_from [1038,1087]
===
match
---
operator: } [28573,28574]
operator: } [28573,28574]
===
match
---
operator: , [5283,5284]
operator: , [5283,5284]
===
match
---
operator: , [20938,20939]
operator: , [20938,20939]
===
match
---
atom [22687,22855]
atom [22687,22855]
===
match
---
operator: , [28379,28380]
operator: , [28379,28380]
===
match
---
name: session [16483,16490]
name: session [16483,16490]
===
match
---
operator: @ [1515,1516]
operator: @ [1515,1516]
===
match
---
operator: = [3340,3341]
operator: = [3340,3341]
===
match
---
name: days [9962,9966]
name: days [9962,9966]
===
match
---
assert_stmt [23346,23404]
assert_stmt [23346,23404]
===
match
---
dictorsetmaker [22741,22799]
dictorsetmaker [22741,22799]
===
match
---
name: assert_called_once_with [39013,39036]
name: assert_called_once_with [39735,39758]
===
match
---
operator: , [6155,6156]
operator: , [6155,6156]
===
match
---
parameters [36605,36639]
parameters [37327,37361]
===
match
---
trailer [1982,1998]
trailer [1982,1998]
===
match
---
atom [38084,38437]
atom [38806,39159]
===
match
---
string: "example_python_operator" [16541,16566]
string: "example_python_operator" [16541,16566]
===
match
---
atom [35353,35559]
atom [36075,36281]
===
match
---
argument [33464,33505]
argument [34186,34227]
===
match
---
trailer [1932,1955]
trailer [1932,1955]
===
match
---
decorators [21383,21731]
decorators [21383,21731]
===
match
---
trailer [3961,3964]
trailer [3961,3964]
===
match
---
testlist_comp [29257,29291]
testlist_comp [29257,29291]
===
match
---
trailer [12273,12283]
trailer [12273,12283]
===
match
---
trailer [32064,32069]
trailer [32786,32791]
===
match
---
string: "end_date" [26763,26773]
string: "end_date" [26763,26773]
===
match
---
operator: , [14287,14288]
operator: , [14287,14288]
===
match
---
atom [24412,24494]
atom [24412,24494]
===
match
---
param [15649,15656]
param [15649,15656]
===
match
---
string: "only_running" [35483,35497]
string: "only_running" [36205,36219]
===
match
---
trailer [28673,28681]
trailer [28673,28681]
===
match
---
strings [12835,12968]
strings [12835,12968]
===
match
---
string: "execution_date" [19884,19900]
string: "execution_date" [19884,19900]
===
match
---
name: len [32052,32055]
name: len [32774,32777]
===
match
---
string: "only_failed" [26819,26832]
string: "only_failed" [26819,26832]
===
match
---
trailer [4684,4691]
trailer [4684,4691]
===
match
---
name: post [23811,23815]
name: post [23811,23815]
===
match
---
name: DagRun [33598,33604]
name: DagRun [34320,34326]
===
match
---
number: 2 [9967,9968]
number: 2 [9967,9968]
===
match
---
string: "include_future" [42620,42636]
string: "include_future" [43342,43358]
===
match
---
atom [10400,10457]
atom [10400,10457]
===
match
---
number: 1 [27918,27919]
number: 1 [27918,27919]
===
match
---
testlist_comp [17309,17631]
testlist_comp [17309,17631]
===
match
---
atom_expr [3079,3132]
atom_expr [3079,3132]
===
match
---
string: "/api/v1/dags/example_python_operator/dagRuns/~/taskInstances" [16994,17056]
string: "/api/v1/dags/example_python_operator/dagRuns/~/taskInstances" [16994,17056]
===
match
---
atom [17735,17758]
atom [17735,17758]
===
match
---
string: "execution_date" [6610,6626]
string: "execution_date" [6610,6626]
===
match
---
operator: = [26551,26552]
operator: = [26551,26552]
===
match
---
operator: , [5982,5983]
operator: , [5982,5983]
===
match
---
operator: , [17630,17631]
operator: , [17630,17631]
===
match
---
name: timedelta [20069,20078]
name: timedelta [20069,20078]
===
match
---
operator: , [41683,41684]
operator: , [42405,42406]
===
match
---
string: "state" [18292,18299]
string: "state" [18292,18299]
===
match
---
operator: } [26269,26270]
operator: } [26269,26270]
===
match
---
simple_stmt [4162,4441]
simple_stmt [4162,4441]
===
match
---
name: task [38948,38952]
name: task [39670,39674]
===
match
---
suite [7292,9024]
suite [7292,9024]
===
match
---
operator: = [29032,29033]
operator: = [29032,29033]
===
match
---
dictorsetmaker [24318,24364]
dictorsetmaker [24318,24364]
===
match
---
name: get [4981,4984]
name: get [4981,4984]
===
match
---
operator: , [5947,5948]
operator: , [5947,5948]
===
match
---
operator: = [37327,37328]
operator: = [38049,38050]
===
match
---
expr_stmt [3481,3514]
expr_stmt [3481,3514]
===
match
---
atom_expr [4457,4472]
atom_expr [4457,4472]
===
match
---
name: create_task_instances [4919,4940]
name: create_task_instances [4919,4940]
===
match
---
string: "/api/v1/dags/example_python_operator/dagRuns/TEST_DAG_RUN_ID/taskInstances/print_the_context" [7676,7770]
string: "/api/v1/dags/example_python_operator/dagRuns/TEST_DAG_RUN_ID/taskInstances/print_the_context" [7676,7770]
===
match
---
operator: } [36741,36742]
operator: } [37463,37464]
===
match
---
operator: , [922,923]
operator: , [922,923]
===
match
---
operator: , [17393,17394]
operator: , [17393,17394]
===
match
---
name: State [2485,2490]
name: State [2485,2490]
===
match
---
dictorsetmaker [43146,43167]
dictorsetmaker [43868,43889]
===
match
---
name: response [41211,41219]
name: response [41933,41941]
===
match
---
operator: , [22401,22402]
operator: , [22401,22402]
===
match
---
operator: , [38422,38423]
operator: , [39144,39145]
===
match
---
name: status_code [24059,24070]
name: status_code [24059,24070]
===
match
---
trailer [39364,39369]
trailer [40086,40091]
===
match
---
fstring [33407,33450]
fstring [34129,34172]
===
match
---
atom_expr [4969,5158]
atom_expr [4969,5158]
===
match
---
name: RESOURCE_TASK_INSTANCE [2012,2034]
name: RESOURCE_TASK_INSTANCE [2012,2034]
===
match
---
operator: , [939,940]
operator: , [939,940]
===
match
---
operator: , [40775,40776]
operator: , [41497,41498]
===
match
---
atom [19064,19203]
atom [19064,19203]
===
match
---
atom_expr [22073,22251]
atom_expr [22073,22251]
===
match
---
funcdef [16069,16692]
funcdef [16069,16692]
===
match
---
operator: } [14831,14832]
operator: } [14831,14832]
===
match
---
name: read_dags_from_db [3109,3126]
name: read_dags_from_db [3109,3126]
===
match
---
assert_stmt [38457,38491]
assert_stmt [39179,39213]
===
match
---
simple_stmt [23788,24035]
simple_stmt [23788,24035]
===
match
---
operator: , [26643,26644]
operator: , [26643,26644]
===
match
---
operator: } [16410,16411]
operator: } [16410,16411]
===
match
---
operator: + [31059,31060]
operator: + [31059,31060]
===
match
---
atom_expr [20066,20086]
atom_expr [20066,20086]
===
match
---
testlist_comp [21512,21571]
testlist_comp [21512,21571]
===
match
---
string: "only_running" [27541,27555]
string: "only_running" [27541,27555]
===
match
---
parameters [32155,32170]
parameters [32877,32892]
===
match
---
name: self [3173,3177]
name: self [3173,3177]
===
match
---
trailer [24058,24070]
trailer [24058,24070]
===
match
---
string: "2020-01-01T00:00:00+00:00" [5401,5428]
string: "2020-01-01T00:00:00+00:00" [5401,5428]
===
match
---
string: "start_date" [36338,36350]
string: "start_date" [37060,37072]
===
match
---
name: DEFAULT_DATETIME_1 [32713,32731]
name: DEFAULT_DATETIME_1 [33435,33453]
===
match
---
operator: , [29276,29277]
operator: , [29276,29277]
===
match
---
string: 'execution_date' [38706,38722]
string: 'execution_date' [39428,39444]
===
match
---
operator: = [39158,39159]
operator: = [39880,39881]
===
match
---
comparison [7852,7879]
comparison [7852,7879]
===
match
---
operator: } [18208,18209]
operator: } [18208,18209]
===
match
---
name: DEFAULT_DATETIME_1 [10494,10512]
name: DEFAULT_DATETIME_1 [10494,10512]
===
match
---
operator: , [15647,15648]
operator: , [15647,15648]
===
match
---
number: 2 [27602,27603]
number: 2 [27602,27603]
===
match
---
name: State [29528,29533]
name: State [29528,29533]
===
match
---
operator: } [31880,31881]
operator: } [32602,32603]
===
match
---
operator: , [2760,2761]
operator: , [2760,2761]
===
match
---
operator: { [15236,15237]
operator: { [15236,15237]
===
match
---
atom [19311,19544]
atom [19311,19544]
===
match
---
operator: , [17911,17912]
operator: , [17911,17912]
===
match
---
arith_expr [30138,30179]
arith_expr [30138,30179]
===
match
---
operator: = [4356,4357]
operator: = [4356,4357]
===
match
---
string: "new_state" [39782,39793]
string: "new_state" [40504,40515]
===
match
---
trailer [19985,19995]
trailer [19985,19995]
===
match
---
operator: , [16411,16412]
operator: , [16411,16412]
===
match
---
atom_expr [16518,16537]
atom_expr [16518,16537]
===
match
---
string: "running" [5865,5874]
string: "running" [5865,5874]
===
match
---
string: "end_date" [18929,18939]
string: "end_date" [18929,18939]
===
match
---
string: "/api/v1/dags/INVALID_DAG/updateTaskInstancesState" [40617,40668]
string: "/api/v1/dags/INVALID_DAG/updateTaskInstancesState" [41339,41390]
===
match
---
simple_stmt [24833,24869]
simple_stmt [24833,24869]
===
match
---
operator: } [17392,17393]
operator: } [17392,17393]
===
match
---
decorated [41797,43300]
decorated [42519,44022]
===
match
---
param [3204,3244]
param [3204,3244]
===
match
---
operator: , [17645,17646]
operator: , [17645,17646]
===
match
---
trailer [9010,9012]
trailer [9010,9012]
===
match
---
trailer [4027,4033]
trailer [4027,4033]
===
match
---
dictorsetmaker [32456,32516]
dictorsetmaker [33178,33238]
===
match
---
trailer [26417,26424]
trailer [26417,26424]
===
match
---
testlist_comp [17735,17849]
testlist_comp [17735,17849]
===
match
---
trailer [23541,23548]
trailer [23541,23548]
===
match
---
name: response [37447,37455]
name: response [38169,38177]
===
match
---
string: "state" [26580,26587]
string: "state" [26580,26587]
===
match
---
name: session [33162,33169]
name: session [33884,33891]
===
match
---
operator: { [25470,25471]
operator: { [25470,25471]
===
match
---
string: "pool" [17736,17742]
string: "pool" [17736,17742]
===
match
---
number: 10000.0 [6536,6543]
number: 10000.0 [6536,6543]
===
match
---
atom_expr [43020,43205]
atom_expr [43742,43927]
===
match
---
argument [25548,25554]
argument [25548,25554]
===
match
---
string: "start_date" [19334,19346]
string: "start_date" [19334,19346]
===
match
---
string: "example_skip_dag" [23671,23689]
string: "example_skip_dag" [23671,23689]
===
match
---
operator: , [6543,6544]
operator: , [6543,6544]
===
match
---
operator: , [26126,26127]
operator: , [26126,26127]
===
match
---
string: "state" [18186,18193]
string: "state" [18186,18193]
===
match
---
operator: = [4967,4968]
operator: = [4967,4968]
===
match
---
operator: , [38803,38804]
operator: , [39525,39526]
===
match
---
name: dt [18885,18887]
name: dt [18885,18887]
===
match
---
string: "REMOTE_USER" [15869,15882]
string: "REMOTE_USER" [15869,15882]
===
match
---
operator: , [9887,9888]
operator: , [9887,9888]
===
match
---
atom_expr [16012,16048]
atom_expr [16012,16048]
===
match
---
testlist_comp [25261,31367]
testlist_comp [25261,32089]
===
match
---
operator: = [23125,23126]
operator: = [23125,23126]
===
match
---
operator: { [29480,29481]
operator: { [29480,29481]
===
match
---
string: "execution_date" [29766,29782]
string: "execution_date" [29766,29782]
===
match
---
argument [4615,4647]
argument [4615,4647]
===
match
---
operator: , [8948,8949]
operator: , [8948,8949]
===
match
---
name: post [37929,37933]
name: post [38651,38655]
===
match
---
operator: , [38065,38066]
operator: , [38787,38788]
===
match
---
operator: = [25552,25553]
operator: = [25552,25553]
===
match
---
operator: { [25647,25648]
operator: { [25647,25648]
===
match
---
operator: == [24071,24073]
operator: == [24071,24073]
===
match
---
dictorsetmaker [2549,2824]
dictorsetmaker [2549,2824]
===
match
---
atom_expr [3968,3980]
atom_expr [3968,3980]
===
match
---
operator: + [32586,32587]
operator: + [33308,33309]
===
match
---
operator: , [10248,10249]
operator: , [10248,10249]
===
match
---
dictorsetmaker [14395,14416]
dictorsetmaker [14395,14416]
===
match
---
param [24805,24814]
param [24805,24814]
===
match
---
atom_expr [28716,28728]
atom_expr [28716,28728]
===
match
---
arith_expr [31040,31081]
arith_expr [31040,31081]
===
match
---
string: "execution_date" [27136,27152]
string: "execution_date" [27136,27152]
===
match
---
name: parameterized [36110,36123]
name: parameterized [36832,36845]
===
match
---
string: "execution_date" [32695,32711]
string: "execution_date" [33417,33433]
===
match
---
atom_expr [1779,1803]
atom_expr [1779,1803]
===
match
---
operator: , [41465,41466]
operator: , [42187,42188]
===
match
---
operator: , [36629,36630]
operator: , [37351,37352]
===
match
---
assert_stmt [22447,22496]
assert_stmt [22447,22496]
===
match
---
atom [14100,14268]
atom [14100,14268]
===
match
---
trailer [7387,7572]
trailer [7387,7572]
===
match
---
operator: = [20923,20924]
operator: = [20923,20924]
===
match
---
name: task_instances [22183,22197]
name: task_instances [22183,22197]
===
match
---
operator: , [20355,20356]
operator: , [20355,20356]
===
match
---
dotted_name [17247,17267]
dotted_name [17247,17267]
===
match
---
name: downstream [39076,39086]
name: downstream [39798,39808]
===
match
---
trailer [16672,16690]
trailer [16672,16690]
===
match
---
name: airflow [1093,1100]
name: airflow [1093,1100]
===
match
---
number: 5 [20333,20334]
number: 5 [20333,20334]
===
match
---
operator: { [27110,27111]
operator: { [27110,27111]
===
match
---
name: expand [17261,17267]
name: expand [17261,17267]
===
match
---
operator: , [39726,39727]
operator: , [40448,40449]
===
match
---
string: "example_skip_dag" [16226,16244]
string: "example_skip_dag" [16226,16244]
===
match
---
trailer [7592,7602]
trailer [7592,7602]
===
match
---
operator: @ [31388,31389]
operator: @ [32110,32111]
===
match
---
operator: , [13603,13604]
operator: , [13603,13604]
===
match
---
operator: , [13252,13253]
operator: , [13252,13253]
===
match
---
operator: } [13950,13951]
operator: } [13950,13951]
===
match
---
arglist [2186,2206]
arglist [2186,2206]
===
match
---
dictorsetmaker [15284,15307]
dictorsetmaker [15284,15307]
===
match
---
argument [2278,2290]
argument [2278,2290]
===
match
---
trailer [11046,11056]
trailer [11046,11056]
===
match
---
trailer [30161,30171]
trailer [30161,30171]
===
match
---
operator: , [18983,18984]
operator: , [18983,18984]
===
match
---
operator: , [8652,8653]
operator: , [8652,8653]
===
match
---
atom_expr [7503,7520]
atom_expr [7503,7520]
===
match
---
name: response [9317,9325]
name: response [9317,9325]
===
match
---
operator: , [32492,32493]
operator: , [33214,33215]
===
match
---
string: "example_python_operator" [7937,7962]
string: "example_python_operator" [7937,7962]
===
match
---
simple_stmt [7369,7573]
simple_stmt [7369,7573]
===
match
---
operator: , [7995,7996]
operator: , [7995,7996]
===
match
---
argument [33287,33306]
argument [34009,34028]
===
match
---
trailer [2567,2580]
trailer [2567,2580]
===
match
---
name: post [40599,40603]
name: post [41321,41325]
===
match
---
atom [14760,14785]
atom [14760,14785]
===
match
---
operator: , [32367,32368]
operator: , [33089,33090]
===
match
---
trailer [21287,21304]
trailer [21287,21304]
===
match
---
assert_stmt [6437,7220]
assert_stmt [6437,7220]
===
match
---
name: request_dag [31869,31880]
name: request_dag [32591,32602]
===
match
---
argument [4573,4597]
argument [4573,4597]
===
match
---
argument [15769,15798]
argument [15769,15798]
===
match
---
name: json [22492,22496]
name: json [22492,22496]
===
match
---
string: "execution_date" [4309,4325]
string: "execution_date" [4309,4325]
===
match
---
argument [37365,37377]
argument [38087,38099]
===
match
---
name: ti_extras [4018,4027]
name: ti_extras [4018,4027]
===
match
---
atom_expr [31745,31774]
atom_expr [32467,32496]
===
match
---
operator: { [7913,7914]
operator: { [7913,7914]
===
match
---
operator: , [33169,33170]
operator: , [33891,33892]
===
match
---
name: timedelta [28841,28850]
name: timedelta [28841,28850]
===
match
---
operator: + [29980,29981]
operator: + [29980,29981]
===
match
---
suite [39333,39859]
suite [40055,40581]
===
match
---
operator: == [25138,25140]
operator: == [25138,25140]
===
match
---
atom_expr [18885,18905]
atom_expr [18885,18905]
===
match
---
trailer [11605,11615]
trailer [11605,11615]
===
match
---
parameters [24789,24823]
parameters [24789,24823]
===
match
---
testlist_comp [17368,17488]
testlist_comp [17368,17488]
===
match
---
string: "test_no_permissions" [23922,23943]
string: "test_no_permissions" [23922,23943]
===
match
---
string: "duration" [18530,18540]
string: "duration" [18530,18540]
===
match
---
suite [36640,37483]
suite [37362,38205]
===
match
---
name: environ_overrides [35768,35785]
name: environ_overrides [36490,36507]
===
match
---
name: session [3187,3194]
name: session [3187,3194]
===
match
---
string: "only_failed" [28307,28320]
string: "only_failed" [28307,28320]
===
match
---
simple_stmt [35021,35077]
simple_stmt [35743,35799]
===
match
---
string: "test_pool_1" [17939,17952]
string: "test_pool_1" [17939,17952]
===
match
---
operator: , [30383,30384]
operator: , [30383,30384]
===
match
---
name: failed_dag_runs [35154,35169]
name: failed_dag_runs [35876,35891]
===
match
---
string: "start_date" [19390,19402]
string: "start_date" [19390,19402]
===
match
---
suite [41202,41792]
suite [41924,42514]
===
match
---
operator: } [11546,11547]
operator: } [11546,11547]
===
match
---
operator: , [28345,28346]
operator: , [28345,28346]
===
match
---
trailer [2585,2595]
trailer [2585,2595]
===
match
---
string: '2020-11-10T12:4opfo' [42483,42504]
string: '2020-11-10T12:4opfo' [43205,43226]
===
match
---
fstring_end: " [33449,33450]
fstring_end: " [34171,34172]
===
match
---
operator: , [31366,31367]
operator: , [31366,31367]
===
match
---
operator: , [8515,8516]
operator: , [8515,8516]
===
match
---
name: default_time [2568,2580]
name: default_time [2568,2580]
===
match
---
dotted_as_name [792,806]
dotted_as_name [792,806]
===
match
---
number: 0 [2822,2823]
number: 0 [2822,2823]
===
match
---
string: "Naive datetime is disallowed" [42277,42307]
string: "Naive datetime is disallowed" [42999,43029]
===
match
---
assert_stmt [35021,35076]
assert_stmt [35743,35798]
===
match
---
string: "execution_date_gte" [20440,20460]
string: "execution_date_gte" [20440,20460]
===
match
---
operator: , [10834,10835]
operator: , [10834,10835]
===
match
---
atom_expr [9003,9012]
atom_expr [9003,9012]
===
match
---
name: days [20162,20166]
name: days [20162,20166]
===
match
---
trailer [22099,22251]
trailer [22099,22251]
===
match
---
atom_expr [23045,23107]
atom_expr [23045,23107]
===
match
---
name: username [2191,2199]
name: username [2191,2199]
===
match
---
atom [13906,14060]
atom [13906,14060]
===
match
---
string: "state" [30028,30035]
string: "state" [30028,30035]
===
match
---
simple_stmt [22260,22439]
simple_stmt [22260,22439]
===
match
---
string: "queue" [2774,2781]
string: "queue" [2774,2781]
===
match
---
name: days [32601,32605]
name: days [33323,33327]
===
match
---
name: post [24900,24904]
name: post [24900,24904]
===
match
---
atom [13644,13804]
atom [13644,13804]
===
match
---
param [31503,31515]
param [32225,32237]
===
match
---
argument [4542,4555]
argument [4542,4555]
===
match
---
operator: , [10986,10987]
operator: , [10986,10987]
===
match
---
trailer [4980,4984]
trailer [4980,4984]
===
match
---
operator: , [28364,28365]
operator: , [28364,28365]
===
match
---
string: "state" [36851,36858]
string: "state" [37573,37580]
===
match
---
operator: + [2581,2582]
operator: + [2581,2582]
===
match
---
simple_stmt [2989,3057]
simple_stmt [2989,3057]
===
match
---
operator: = [35665,35666]
operator: = [36387,36388]
===
match
---
operator: , [15355,15356]
operator: , [15355,15356]
===
match
---
dictorsetmaker [27027,27087]
dictorsetmaker [27027,27087]
===
match
---
trailer [2881,2888]
trailer [2881,2888]
===
match
---
operator: = [40741,40742]
operator: = [41463,41464]
===
match
---
atom_expr [35101,35132]
atom_expr [35823,35854]
===
match
---
name: test_should_raise_403_forbidden [9270,9301]
name: test_should_raise_403_forbidden [9270,9301]
===
match
---
dictorsetmaker [34029,34221]
dictorsetmaker [34751,34943]
===
match
---
fstring_string: &end_date_lte= [12474,12488]
fstring_string: &end_date_lte= [12474,12488]
===
match
---
operator: , [30355,30356]
operator: , [30355,30356]
===
match
---
atom_expr [3531,3540]
atom_expr [3531,3540]
===
match
---
simple_stmt [37906,38449]
simple_stmt [38628,39171]
===
match
---
operator: @ [36109,36110]
operator: @ [36831,36832]
===
match
---
operator: , [30596,30597]
operator: , [30596,30597]
===
match
---
name: self [22942,22946]
name: self [22942,22946]
===
match
---
operator: } [18117,18118]
operator: } [18117,18118]
===
match
---
arith_expr [28056,28097]
arith_expr [28056,28097]
===
match
---
arglist [4195,4422]
arglist [4195,4422]
===
match
---
number: 403 [9571,9574]
number: 403 [9571,9574]
===
match
---
number: 0 [6747,6748]
number: 0 [6747,6748]
===
match
---
dictorsetmaker [19390,19445]
dictorsetmaker [19390,19445]
===
match
---
name: parameterized [22643,22656]
name: parameterized [22643,22656]
===
match
---
operator: } [25017,25018]
operator: } [25017,25018]
===
match
---
operator: } [41369,41370]
operator: } [42091,42092]
===
match
---
name: QUEUED [13531,13537]
name: QUEUED [13531,13537]
===
match
---
operator: , [24001,24002]
operator: , [24001,24002]
===
match
---
simple_stmt [1460,1513]
simple_stmt [1460,1513]
===
match
---
trailer [32786,32794]
trailer [33508,33516]
===
match
---
simple_stmt [3549,3570]
simple_stmt [3549,3570]
===
match
---
atom_expr [15829,15892]
atom_expr [15829,15892]
===
match
---
name: response [23788,23796]
name: response [23788,23796]
===
match
---
expr_stmt [39915,40472]
expr_stmt [40637,41194]
===
match
---
atom_expr [16659,16690]
atom_expr [16659,16690]
===
match
---
param [21836,21851]
param [21836,21851]
===
match
---
simple_stmt [36908,37123]
simple_stmt [37630,37845]
===
match
---
name: DEFAULT_DATETIME_1 [36792,36810]
name: DEFAULT_DATETIME_1 [37514,37532]
===
match
---
trailer [23548,23553]
trailer [23548,23553]
===
match
---
operator: @ [21714,21715]
operator: @ [21714,21715]
===
match
---
operator: , [36619,36620]
operator: , [37341,37342]
===
match
---
arglist [1395,1405]
arglist [1395,1405]
===
match
---
operator: , [6951,6952]
operator: , [6951,6952]
===
match
---
operator: = [3036,3037]
operator: = [3036,3037]
===
match
---
operator: , [26624,26625]
operator: , [26624,26625]
===
match
---
operator: = [3012,3013]
operator: = [3012,3013]
===
match
---
operator: , [6913,6914]
operator: , [6913,6914]
===
match
---
name: single_dag_run [31705,31719]
name: single_dag_run [32427,32441]
===
match
---
string: "hostname" [6706,6716]
string: "hostname" [6706,6716]
===
match
---
fstring_end: " [10195,10196]
fstring_end: " [10195,10196]
===
match
---
atom [11646,11701]
atom [11646,11701]
===
match
---
operator: , [34934,34935]
operator: , [35656,35657]
===
match
---
name: days [20079,20083]
name: days [20079,20083]
===
match
---
operator: , [32648,32649]
operator: , [33370,33371]
===
match
---
operator: , [19367,19368]
operator: , [19367,19368]
===
match
---
atom_expr [2583,2603]
atom_expr [2583,2603]
===
match
---
operator: , [40407,40408]
operator: , [41129,41130]
===
match
---
operator: , [18323,18324]
operator: , [18323,18324]
===
match
---
atom_expr [30939,30951]
atom_expr [30939,30951]
===
match
---
comparison [41122,41149]
comparison [41844,41871]
===
match
---
atom [15214,15374]
atom [15214,15374]
===
match
---
operator: { [36756,36757]
operator: { [37478,37479]
===
match
---
name: response [24877,24885]
name: response [24877,24885]
===
match
---
operator: } [34234,34235]
operator: } [34956,34957]
===
match
---
name: response [32009,32017]
name: response [32731,32739]
===
match
---
operator: , [26447,26448]
operator: , [26447,26448]
===
match
---
parameters [39899,39905]
parameters [40621,40627]
===
match
---
name: DEFAULT_DATETIME_1 [11023,11041]
name: DEFAULT_DATETIME_1 [11023,11041]
===
match
---
operator: + [20313,20314]
operator: + [20313,20314]
===
match
---
name: client [4974,4980]
name: client [4974,4980]
===
match
---
testlist_comp [12659,12755]
testlist_comp [12659,12755]
===
match
---
trailer [7305,7327]
trailer [7305,7327]
===
match
---
operator: , [8331,8332]
operator: , [8331,8332]
===
match
---
atom_expr [21345,21376]
atom_expr [21345,21376]
===
match
---
dictorsetmaker [29207,29293]
dictorsetmaker [29207,29293]
===
match
---
number: 2 [15504,15505]
number: 2 [15504,15505]
===
match
---
argument [20079,20085]
argument [20079,20085]
===
match
---
name: expected [43291,43299]
name: expected [44013,44021]
===
match
---
operator: , [18829,18830]
operator: , [18829,18830]
===
match
---
operator: , [15261,15262]
operator: , [15261,15262]
===
match
---
atom_expr [29982,30002]
atom_expr [29982,30002]
===
match
---
operator: , [4208,4209]
operator: , [4208,4209]
===
match
---
operator: , [34178,34179]
operator: , [34900,34901]
===
match
---
trailer [4017,4027]
trailer [4017,4027]
===
match
---
atom_expr [6196,6385]
atom_expr [6196,6385]
===
match
---
string: "state" [8886,8893]
string: "state" [8886,8893]
===
match
---
operator: , [31450,31451]
operator: , [32172,32173]
===
match
---
name: task_instances [31629,31643]
name: task_instances [32351,32365]
===
match
---
string: "test" [7818,7824]
string: "test" [7818,7824]
===
match
---
string: "task_instances" [22618,22634]
string: "task_instances" [22618,22634]
===
match
---
name: expand [41812,41818]
name: expand [42534,42540]
===
match
---
atom [14316,14669]
atom [14316,14669]
===
match
---
comparison [17153,17180]
comparison [17153,17180]
===
match
---
trailer [35671,35678]
trailer [36393,36400]
===
match
---
operator: , [40019,40020]
operator: , [40741,40742]
===
match
---
simple_stmt [36069,36104]
simple_stmt [36791,36826]
===
match
---
operator: , [8200,8201]
operator: , [8200,8201]
===
match
---
dictorsetmaker [27861,27968]
dictorsetmaker [27861,27968]
===
match
---
name: response [25071,25079]
name: response [25071,25079]
===
match
---
string: "duration" [2707,2717]
string: "duration" [2707,2717]
===
match
---
atom_expr [38862,38910]
atom_expr [39584,39632]
===
match
---
number: 1 [1401,1402]
number: 1 [1401,1402]
===
match
---
string: "print_the_context" [29257,29276]
string: "print_the_context" [29257,29276]
===
match
---
comparison [33697,33724]
comparison [34419,34446]
===
match
---
operator: , [32754,32755]
operator: , [33476,33477]
===
match
---
operator: = [16387,16388]
operator: = [16387,16388]
===
match
---
comparison [5217,5993]
comparison [5217,5993]
===
match
---
comparison [33613,33637]
comparison [34335,34359]
===
match
---
operator: @ [24083,24084]
operator: @ [24083,24084]
===
match
---
string: "execution_date" [39564,39580]
string: "execution_date" [40286,40302]
===
match
---
operator: , [15755,15756]
operator: , [15755,15756]
===
match
---
name: DEFAULT_DATETIME_1 [29499,29517]
name: DEFAULT_DATETIME_1 [29499,29517]
===
match
---
operator: , [18163,18164]
operator: , [18163,18164]
===
match
---
operator: , [40369,40370]
operator: , [41091,41092]
===
match
---
dictorsetmaker [40126,40447]
dictorsetmaker [40848,41169]
===
match
---
param [36631,36638]
param [37353,37360]
===
match
---
trailer [20244,20252]
trailer [20244,20252]
===
match
---
operator: } [38821,38822]
operator: } [39543,39544]
===
match
---
name: DEFAULT_DATETIME_1 [11102,11120]
name: DEFAULT_DATETIME_1 [11102,11120]
===
match
---
operator: { [12659,12660]
operator: { [12659,12660]
===
match
---
name: session [22983,22990]
name: session [22983,22990]
===
match
---
atom [18429,18565]
atom [18429,18565]
===
match
---
arith_expr [32567,32608]
arith_expr [33289,33330]
===
match
---
operator: == [35151,35153]
operator: == [35873,35875]
===
match
---
trailer [2950,2952]
trailer [2950,2952]
===
match
---
trailer [4773,4777]
trailer [4773,4777]
===
match
---
operator: = [9481,9482]
operator: = [9481,9482]
===
match
---
string: "only_running" [32347,32361]
string: "only_running" [33069,33083]
===
match
---
name: clear_db_runs [1331,1344]
name: clear_db_runs [1331,1344]
===
match
---
atom [30642,30797]
atom [30642,30797]
===
match
---
dictorsetmaker [30120,30227]
dictorsetmaker [30120,30227]
===
match
---
string: "queued_when" [6965,6978]
string: "queued_when" [6965,6978]
===
match
---
simple_stmt [37131,37190]
simple_stmt [37853,37912]
===
match
---
name: FAILED [28899,28905]
name: FAILED [28899,28905]
===
match
---
name: expand [21398,21404]
name: expand [21398,21404]
===
match
---
number: 4 [20250,20251]
number: 4 [20250,20251]
===
match
---
operator: = [7448,7449]
operator: = [7448,7449]
===
match
---
atom_expr [31539,31736]
atom_expr [32261,32458]
===
match
---
operator: , [38345,38346]
operator: , [39067,39068]
===
match
---
operator: , [30417,30418]
operator: , [30417,30418]
===
match
---
name: expected_ti [32092,32103]
name: expected_ti [32814,32825]
===
match
---
dictorsetmaker [38043,38064]
dictorsetmaker [38765,38786]
===
match
---
trailer [3043,3054]
trailer [3043,3054]
===
match
---
number: 1 [10454,10455]
number: 1 [10454,10455]
===
match
---
operator: } [36887,36888]
operator: } [37609,37610]
===
match
---
atom [1735,2046]
atom [1735,2046]
===
match
---
operator: { [24609,24610]
operator: { [24609,24610]
===
match
---
operator: } [14878,14879]
operator: } [14878,14879]
===
match
---
name: assert_401 [16877,16887]
name: assert_401 [16877,16887]
===
match
---
operator: = [11140,11141]
operator: = [11140,11141]
===
match
---
parameters [9071,9077]
parameters [9071,9077]
===
match
---
string: "end_date_lte" [24130,24144]
string: "end_date_lte" [24130,24144]
===
match
---
string: 'dag_run_id' [33838,33850]
string: 'dag_run_id' [34560,34572]
===
match
---
name: timedelta [11606,11615]
name: timedelta [11606,11615]
===
match
---
dictorsetmaker [36156,36196]
dictorsetmaker [36878,36918]
===
match
---
operator: , [14785,14786]
operator: , [14785,14786]
===
match
---
name: app [1643,1646]
name: app [1643,1646]
===
match
---
atom [27110,27266]
atom [27110,27266]
===
match
---
tfpdef [3289,3309]
tfpdef [3289,3309]
===
match
---
trailer [4940,4949]
trailer [4940,4949]
===
match
---
dictorsetmaker [13195,13210]
dictorsetmaker [13195,13210]
===
match
---
atom [27288,27443]
atom [27288,27443]
===
match
---
operator: = [35785,35786]
operator: = [36507,36508]
===
match
---
operator: } [33429,33430]
operator: } [34151,34152]
===
match
---
operator: } [17847,17848]
operator: } [17847,17848]
===
match
---
operator: = [24994,24995]
operator: = [24994,24995]
===
match
---
operator: , [7962,7963]
operator: , [7962,7963]
===
match
---
operator: , [40141,40142]
operator: , [40863,40864]
===
match
---
operator: , [22971,22972]
operator: , [22971,22972]
===
match
---
number: 1 [29646,29647]
number: 1 [29646,29647]
===
match
---
assert_stmt [17146,17180]
assert_stmt [17146,17180]
===
match
---
operator: } [18506,18507]
operator: } [18506,18507]
===
match
---
string: "dry_run" [39483,39492]
string: "dry_run" [40205,40214]
===
match
---
operator: , [33273,33274]
operator: , [33995,33996]
===
match
---
name: client [31828,31834]
name: client [32550,32556]
===
match
---
string: "2020-01-02T00:00:00+00:00" [5815,5842]
string: "2020-01-02T00:00:00+00:00" [5815,5842]
===
match
---
name: self [41196,41200]
name: self [41918,41922]
===
match
---
number: 4 [33044,33045]
number: 4 [33766,33767]
===
match
---
name: dag_bag [31754,31761]
name: dag_bag [32476,32483]
===
match
---
operator: } [29894,29895]
operator: } [29894,29895]
===
match
---
atom_expr [22271,22438]
atom_expr [22271,22438]
===
match
---
suite [42956,43300]
suite [43678,44022]
===
match
---
simple_stmt [33733,34961]
simple_stmt [34455,35683]
===
match
---
name: response [22533,22541]
name: response [22533,22541]
===
match
---
name: response [22260,22268]
name: response [22260,22268]
===
match
---
operator: , [3243,3244]
operator: , [3243,3244]
===
match
---
trailer [33712,33724]
trailer [34434,34446]
===
match
---
atom [28596,28751]
atom [28596,28751]
===
match
---
name: environ_overrides [21101,21118]
name: environ_overrides [21101,21118]
===
match
---
number: 1 [9884,9885]
number: 1 [9884,9885]
===
match
---
operator: } [32516,32517]
operator: } [33238,33239]
===
match
---
atom [33570,33681]
atom [34292,34403]
===
match
---
dictorsetmaker [39483,39804]
dictorsetmaker [40205,40526]
===
match
---
funcdef [7226,9024]
funcdef [7226,9024]
===
match
---
operator: , [31514,31515]
operator: , [32236,32237]
===
match
---
param [22948,22950]
param [22948,22950]
===
match
---
number: 3 [20167,20168]
number: 3 [20167,20168]
===
match
---
comparison [15951,15996]
comparison [15951,15996]
===
match
---
funcdef [4862,5994]
funcdef [4862,5994]
===
match
---
expr_stmt [3549,3569]
expr_stmt [3549,3569]
===
match
---
name: FAILED [25441,25447]
name: FAILED [25441,25447]
===
match
---
string: 'airflow.api_connexion.endpoints.task_instance_endpoint.set_state' [37563,37629]
string: 'airflow.api_connexion.endpoints.task_instance_endpoint.set_state' [38285,38351]
===
match
---
operator: , [31351,31352]
operator: , [31351,31352]
===
match
---
trailer [39357,39364]
trailer [40079,40086]
===
match
---
name: test_should_raise_403_forbidden [39868,39899]
name: test_should_raise_403_forbidden [40590,40621]
===
match
---
operator: , [17758,17759]
operator: , [17758,17759]
===
match
---
arith_expr [18864,18905]
arith_expr [18864,18905]
===
match
---
name: RESOURCE_DAG_RUN [1860,1876]
name: RESOURCE_DAG_RUN [1860,1876]
===
match
---
name: update_extras [20882,20895]
name: update_extras [20882,20895]
===
match
---
trailer [37139,37147]
trailer [37861,37869]
===
match
---
operator: } [23690,23691]
operator: } [23690,23691]
===
match
---
trailer [7625,7627]
trailer [7625,7627]
===
match
---
string: "example_skip_dag" [22780,22798]
string: "example_skip_dag" [22780,22798]
===
match
---
operator: } [34472,34473]
operator: } [35194,35195]
===
match
---
number: 100 [5584,5587]
number: 100 [5584,5587]
===
match
---
suite [15658,16064]
suite [15658,16064]
===
match
---
name: pytest [841,847]
name: pytest [841,847]
===
match
---
atom [17713,17867]
atom [17713,17867]
===
match
---
name: utils [1101,1106]
name: utils [1101,1106]
===
match
---
argument [39105,39138]
argument [39827,39860]
===
match
---
string: "unixname" [8991,9001]
string: "unixname" [8991,9001]
===
match
---
name: ti_extras [21908,21917]
name: ti_extras [21908,21917]
===
match
---
string: "/api/v1/dags/~/dagRuns/~/taskInstances/list" [23829,23874]
string: "/api/v1/dags/~/dagRuns/~/taskInstances/list" [23829,23874]
===
match
---
expr_stmt [33552,33681]
expr_stmt [34274,34403]
===
match
---
string: "only_failed" [35445,35458]
string: "only_failed" [36167,36180]
===
match
---
number: 2 [19221,19222]
number: 2 [19221,19222]
===
match
---
name: expand [9650,9656]
name: expand [9650,9656]
===
match
---
fstring_start: f" [10136,10138]
fstring_start: f" [10136,10138]
===
match
---
name: DEFAULT_DATETIME_1 [25406,25424]
name: DEFAULT_DATETIME_1 [25406,25424]
===
match
---
argument [20868,20895]
argument [20868,20895]
===
match
---
string: "include_future" [40981,40997]
string: "include_future" [41703,41719]
===
match
---
name: DEFAULT_DATETIME_STR_1 [19646,19668]
name: DEFAULT_DATETIME_STR_1 [19646,19668]
===
match
---
string: '2020-11-10T12:42:39.442973' [41989,42017]
string: '2020-11-10T12:42:39.442973' [42711,42739]
===
match
---
atom_expr [23711,23731]
atom_expr [23711,23731]
===
match
---
operator: , [11720,11721]
operator: , [11720,11721]
===
match
---
name: DEFAULT_DATETIME_STR_1 [11305,11327]
name: DEFAULT_DATETIME_STR_1 [11305,11327]
===
match
---
operator: { [5234,5235]
operator: { [5234,5235]
===
match
---
string: "priority_weight" [8345,8362]
string: "priority_weight" [8345,8362]
===
match
---
arith_expr [29961,30002]
arith_expr [29961,30002]
===
match
---
name: post [21024,21028]
name: post [21024,21028]
===
match
---
string: '2020-11-10T12:4po' [36444,36463]
string: '2020-11-10T12:4po' [37166,37185]
===
match
---
name: client [40592,40598]
name: client [41314,41320]
===
match
---
decorator [41797,42844]
decorator [42519,43566]
===
match
---
operator: == [7910,7912]
operator: == [7910,7912]
===
match
---
operator: , [8696,8697]
operator: , [8696,8697]
===
match
---
operator: , [29167,29168]
operator: , [29167,29168]
===
match
---
operator: { [18140,18141]
operator: { [18140,18141]
===
match
---
operator: , [7209,7210]
operator: , [7209,7210]
===
match
---
trailer [21907,21917]
trailer [21907,21917]
===
match
---
name: session [32162,32169]
name: session [32884,32891]
===
match
---
operator: } [38845,38846]
operator: } [39567,39568]
===
match
---
simple_stmt [37397,37432]
simple_stmt [38119,38154]
===
match
---
operator: = [21010,21011]
operator: = [21010,21011]
===
match
---
dictorsetmaker [23964,24022]
dictorsetmaker [23964,24022]
===
match
---
trailer [29640,29648]
trailer [29640,29648]
===
match
---
argument [31600,31615]
argument [32322,32337]
===
match
---
operator: { [13194,13195]
operator: { [13194,13195]
===
match
---
name: State [26412,26417]
name: State [26412,26417]
===
match
---
argument [2662,2668]
argument [2662,2668]
===
match
---
name: self [33122,33126]
name: self [33844,33848]
===
match
---
operator: , [37678,37679]
operator: , [38400,38401]
===
match
---
operator: , [12010,12011]
operator: , [12010,12011]
===
match
---
trailer [39930,39937]
trailer [40652,40659]
===
match
---
string: "test_queue_3" [14864,14878]
string: "test_queue_3" [14864,14878]
===
match
---
import_from [1088,1125]
import_from [1088,1125]
===
match
---
atom [20275,20336]
atom [20275,20336]
===
match
---
param [16740,16744]
param [16740,16744]
===
match
---
dictorsetmaker [32695,32795]
dictorsetmaker [33417,33517]
===
match
---
name: dag_id [16531,16537]
name: dag_id [16531,16537]
===
match
---
number: 2 [14286,14287]
number: 2 [14286,14287]
===
match
---
operator: = [23087,23088]
operator: = [23087,23088]
===
match
---
funcdef [23468,23732]
funcdef [23468,23732]
===
match
---
operator: = [33043,33044]
operator: = [33765,33766]
===
match
---
name: DEFAULT_DATETIME_1 [28994,29012]
name: DEFAULT_DATETIME_1 [28994,29012]
===
match
---
operator: = [11697,11698]
operator: = [11697,11698]
===
match
---
atom [32441,33112]
atom [33163,33834]
===
match
---
operator: , [25779,25780]
operator: , [25779,25780]
===
match
---
string: "test_queue_1" [15246,15260]
string: "test_queue_1" [15246,15260]
===
match
---
fstring_expr [33422,33430]
fstring_expr [34144,34152]
===
match
---
name: filter [16511,16517]
name: filter [16511,16517]
===
match
---
operator: = [1483,1484]
operator: = [1483,1484]
===
match
---
name: session [31579,31586]
name: session [32301,32308]
===
match
---
atom [32969,33101]
atom [33691,33823]
===
match
---
name: DEFAULT_DATETIME_1 [20525,20543]
name: DEFAULT_DATETIME_1 [20525,20543]
===
match
---
operator: , [41095,41096]
operator: , [41817,41818]
===
match
---
arith_expr [10415,10456]
arith_expr [10415,10456]
===
match
---
string: "dry_run" [25904,25913]
string: "dry_run" [25904,25913]
===
match
---
operator: } [18982,18983]
operator: } [18982,18983]
===
match
---
operator: , [16217,16218]
operator: , [16217,16218]
===
match
---
operator: , [38261,38262]
operator: , [38983,38984]
===
match
---
atom [41860,42259]
atom [42582,42981]
===
match
---
strings [10617,10797]
strings [10617,10797]
===
match
---
trailer [16024,16029]
trailer [16024,16029]
===
match
---
operator: , [27990,27991]
operator: , [27990,27991]
===
match
---
operator: = [33481,33482]
operator: = [34203,34204]
===
match
---
simple_stmt [1592,1618]
simple_stmt [1592,1618]
===
match
---
dictorsetmaker [17569,17610]
dictorsetmaker [17569,17610]
===
match
---
name: DEFAULT_DATETIME_STR_1 [1407,1429]
name: DEFAULT_DATETIME_STR_1 [1407,1429]
===
match
---
operator: , [33982,33983]
operator: , [34704,34705]
===
match
---
name: _ [22948,22949]
name: _ [22948,22949]
===
match
---
name: response [33366,33374]
name: response [34088,34096]
===
match
---
name: self [40587,40591]
name: self [41309,41313]
===
match
---
operator: , [11995,11996]
operator: , [11995,11996]
===
match
---
operator: , [8802,8803]
operator: , [8802,8803]
===
match
---
name: State [30762,30767]
name: State [30762,30767]
===
match
---
string: "execution_date" [29943,29959]
string: "execution_date" [29943,29959]
===
match
---
operator: , [32299,32300]
operator: , [33021,33022]
===
match
---
operator: , [2798,2799]
operator: , [2798,2799]
===
match
---
assert_stmt [9540,9574]
assert_stmt [9540,9574]
===
match
---
atom [34011,34235]
atom [34733,34957]
===
match
---
operator: , [19544,19545]
operator: , [19544,19545]
===
match
---
string: 'example_python_operator' [34753,34778]
string: 'example_python_operator' [35475,35500]
===
match
---
atom_expr [32056,32087]
atom_expr [32778,32809]
===
match
---
argument [36826,36832]
argument [37548,37554]
===
match
---
operator: = [2199,2200]
operator: = [2199,2200]
===
match
---
string: "dag_id" [5248,5256]
string: "dag_id" [5248,5256]
===
match
---
name: len [3559,3562]
name: len [3559,3562]
===
match
---
string: "duration_lte" [18649,18663]
string: "duration_lte" [18649,18663]
===
match
---
operator: { [11344,11345]
operator: { [11344,11345]
===
match
---
operator: } [10985,10986]
operator: } [10985,10986]
===
match
---
atom_expr [12271,12291]
atom_expr [12271,12291]
===
match
---
name: DEFAULT_DATETIME_1 [26336,26354]
name: DEFAULT_DATETIME_1 [26336,26354]
===
match
---
trailer [37849,37857]
trailer [38571,38579]
===
match
---
operator: == [35094,35096]
operator: == [35816,35818]
===
match
---
atom [19606,19749]
atom [19606,19749]
===
match
---
operator: , [27243,27244]
operator: , [27243,27244]
===
match
---
name: ti_extras [2523,2532]
name: ti_extras [2523,2532]
===
match
---
dictorsetmaker [36774,36874]
dictorsetmaker [37496,37596]
===
match
---
string: "pid" [5577,5582]
string: "pid" [5577,5582]
===
match
---
operator: , [17440,17441]
operator: , [17440,17441]
===
match
---
atom [33482,33505]
atom [34204,34227]
===
match
---
trailer [16608,16613]
trailer [16608,16613]
===
match
---
trailer [21232,21237]
trailer [21232,21237]
===
match
---
name: response [15951,15959]
name: response [15951,15959]
===
match
---
string: "dag_ids" [22741,22750]
string: "dag_ids" [22741,22750]
===
match
---
string: "dry_run" [35371,35380]
string: "dry_run" [36093,36102]
===
match
---
argument [26547,26553]
argument [26547,26553]
===
match
---
operator: { [30819,30820]
operator: { [30819,30820]
===
match
---
operator: = [20083,20084]
operator: = [20083,20084]
===
match
---
name: session [7328,7335]
name: session [7328,7335]
===
match
---
operator: , [10849,10850]
operator: , [10849,10850]
===
match
---
operator: , [19668,19669]
operator: , [19668,19669]
===
match
---
trailer [3374,3382]
trailer [3374,3382]
===
match
---
string: "state" [30598,30605]
string: "state" [30598,30605]
===
match
---
strings [14122,14250]
strings [14122,14250]
===
match
---
name: main_dag [31607,31615]
name: main_dag [32329,32337]
===
match
---
funcdef [3138,4803]
funcdef [3138,4803]
===
match
---
name: create_user [1274,1285]
name: create_user [1274,1285]
===
match
---
trailer [30219,30226]
trailer [30219,30226]
===
match
---
name: DagRun [4167,4173]
name: DagRun [4167,4173]
===
match
---
operator: , [41003,41004]
operator: , [41725,41726]
===
match
---
name: days [28090,28094]
name: days [28090,28094]
===
match
---
trailer [13484,13492]
trailer [13484,13492]
===
match
---
decorators [41797,42865]
decorators [42519,43587]
===
match
---
operator: , [29397,29398]
operator: , [29397,29398]
===
match
---
name: json [38079,38083]
name: json [38801,38805]
===
match
---
operator: { [32823,32824]
operator: { [33545,33546]
===
match
---
operator: { [36155,36156]
operator: { [36877,36878]
===
match
---
fstring [10136,10196]
fstring [10136,10196]
===
match
---
atom [26704,26857]
atom [26704,26857]
===
match
---
dictorsetmaker [13156,13171]
dictorsetmaker [13156,13171]
===
match
---
argument [39152,39163]
argument [39874,39885]
===
match
---
operator: = [16263,16264]
operator: = [16263,16264]
===
match
---
expr_stmt [33366,33542]
expr_stmt [34088,34264]
===
match
---
atom_expr [23127,23294]
atom_expr [23127,23294]
===
match
---
testlist_comp [1750,1803]
testlist_comp [1750,1803]
===
match
---
argument [40737,41095]
argument [41459,41817]
===
match
---
name: dt [27175,27177]
name: dt [27175,27177]
===
match
---
operator: , [31956,31957]
operator: , [32678,32679]
===
match
---
string: "2020-01-01T00:00:00+00:00" [6628,6655]
string: "2020-01-01T00:00:00+00:00" [6628,6655]
===
match
---
operator: + [30882,30883]
operator: + [30882,30883]
===
match
---
argument [38024,38065]
argument [38746,38787]
===
match
---
trailer [7352,7358]
trailer [7352,7358]
===
match
---
assert_stmt [7845,7879]
assert_stmt [7845,7879]
===
match
---
param [3355,3383]
param [3355,3383]
===
match
---
param [35221,35225]
param [35943,35947]
===
match
---
name: dagbag [3070,3076]
name: dagbag [3070,3076]
===
match
---
arglist [2996,3042]
arglist [2996,3042]
===
match
---
name: days [25548,25552]
name: days [25548,25552]
===
match
---
name: single_dag_run [20740,20754]
name: single_dag_run [20740,20754]
===
match
---
operator: , [26270,26271]
operator: , [26270,26271]
===
match
---
classdef [25152,37483]
classdef [25152,38205]
===
match
---
dictorsetmaker [27524,27583]
dictorsetmaker [27524,27583]
===
match
---
testlist_comp [24317,24397]
testlist_comp [24317,24397]
===
match
---
tfpdef [3253,3272]
tfpdef [3253,3272]
===
match
---
string: "include_downstream" [40937,40957]
string: "include_downstream" [41659,41679]
===
match
---
atom [14683,15143]
atom [14683,15143]
===
match
---
atom [26187,26643]
atom [26187,26643]
===
match
---
operator: , [33997,33998]
operator: , [34719,34720]
===
match
---
operator: } [18162,18163]
operator: } [18162,18163]
===
match
---
operator: , [21657,21658]
operator: , [21657,21658]
===
match
---
expr_stmt [21001,21179]
expr_stmt [21001,21179]
===
match
---
atom_expr [13570,13583]
atom_expr [13570,13583]
===
match
---
suite [1587,2224]
suite [1587,2224]
===
match
---
operator: = [3273,3274]
operator: = [3273,3274]
===
match
---
string: "pool_slots" [6864,6876]
string: "pool_slots" [6864,6876]
===
match
---
param [20725,20739]
param [20725,20739]
===
match
---
operator: } [10795,10796]
operator: } [10795,10796]
===
match
---
operator: , [19588,19589]
operator: , [19588,19589]
===
match
---
name: bool [3268,3272]
name: bool [3268,3272]
===
match
---
fstring_expr [12450,12474]
fstring_expr [12450,12474]
===
match
---
string: "test duration filter" [12597,12619]
string: "test duration filter" [12597,12619]
===
match
---
trailer [9102,9109]
trailer [9102,9109]
===
match
---
operator: , [29895,29896]
operator: , [29895,29896]
===
match
---
name: dt [20232,20234]
name: dt [20232,20234]
===
match
---
name: create_task_instances [37719,37740]
name: create_task_instances [38441,38462]
===
match
---
operator: } [6373,6374]
operator: } [6373,6374]
===
match
---
expr_stmt [32180,32214]
expr_stmt [32902,32936]
===
match
---
expr_stmt [32424,33112]
expr_stmt [33146,33834]
===
match
---
operator: = [4201,4202]
operator: = [4201,4202]
===
match
---
string: "/api/v1/dags/example_python_operator/updateTaskInstancesState" [39956,40019]
string: "/api/v1/dags/example_python_operator/updateTaskInstancesState" [40678,40741]
===
match
---
atom [12084,12311]
atom [12084,12311]
===
match
---
atom_expr [1971,1998]
atom_expr [1971,1998]
===
match
---
operator: , [18054,18055]
operator: , [18054,18055]
===
match
---
name: dt [11123,11125]
name: dt [11123,11125]
===
match
---
name: dt [32588,32590]
name: dt [33310,33312]
===
match
---
trailer [20558,20566]
trailer [20558,20566]
===
match
---
operator: { [12450,12451]
operator: { [12450,12451]
===
match
---
comparison [9547,9574]
comparison [9547,9574]
===
match
---
operator: } [43167,43168]
operator: } [43889,43890]
===
match
---
argument [32893,32899]
argument [33615,33621]
===
match
---
operator: , [21222,21223]
operator: , [21222,21223]
===
match
---
operator: , [20763,20764]
operator: , [20763,20764]
===
match
---
string: "state" [2476,2483]
string: "state" [2476,2483]
===
match
---
string: "/api/v1/dags/example_python_operator/dagRuns/TEST_DAG_RUN_ID/taskInstances/print_the_context" [4998,5092]
string: "/api/v1/dags/example_python_operator/dagRuns/TEST_DAG_RUN_ID/taskInstances/print_the_context" [4998,5092]
===
match
---
operator: { [13973,13974]
operator: { [13973,13974]
===
match
---
comparison [7896,9023]
comparison [7896,9023]
===
match
---
operator: , [27373,27374]
operator: , [27373,27374]
===
match
---
operator: , [24269,24270]
operator: , [24269,24270]
===
match
---
atom_expr [4357,4380]
atom_expr [4357,4380]
===
match
---
name: json [23958,23962]
name: json [23958,23962]
===
match
---
operator: , [13172,13173]
operator: , [13172,13173]
===
match
---
number: 1 [2601,2602]
number: 1 [2601,2602]
===
match
---
argument [32747,32753]
argument [33469,33475]
===
match
---
string: "test queue filter ~" [15175,15196]
string: "test queue filter ~" [15175,15196]
===
match
---
name: expected_response [34990,35007]
name: expected_response [35712,35729]
===
match
---
atom_expr [38464,38484]
atom_expr [39186,39206]
===
match
---
trailer [2895,2899]
trailer [2895,2899]
===
match
---
fstring_start: f" [11301,11303]
fstring_start: f" [11301,11303]
===
match
---
operator: , [38165,38166]
operator: , [38887,38888]
===
match
---
name: State [13570,13575]
name: State [13570,13575]
===
match
---
name: setup_attrs [2300,2311]
name: setup_attrs [2300,2311]
===
match
---
name: dt [20066,20068]
name: dt [20066,20068]
===
match
---
operator: , [26741,26742]
operator: , [26741,26742]
===
match
---
dictorsetmaker [10401,10456]
dictorsetmaker [10401,10456]
===
match
---
trailer [10517,10527]
trailer [10517,10527]
===
match
---
string: "test_no_permissions" [17104,17125]
string: "test_no_permissions" [17104,17125]
===
match
---
atom_expr [24888,25055]
atom_expr [24888,25055]
===
match
---
operator: , [8172,8173]
operator: , [8172,8173]
===
match
---
trailer [16976,16980]
trailer [16976,16980]
===
match
---
atom [42336,42826]
atom [43058,43548]
===
match
---
strings [10052,10196]
strings [10052,10196]
===
match
---
operator: = [23535,23536]
operator: = [23535,23536]
===
match
---
trailer [4300,4308]
trailer [4300,4308]
===
match
---
dictorsetmaker [16389,16410]
dictorsetmaker [16389,16410]
===
match
---
string: "state" [28707,28714]
string: "state" [28707,28714]
===
match
---
atom [16388,16411]
atom [16388,16411]
===
match
---
operator: } [12511,12512]
operator: } [12511,12512]
===
match
---
atom_expr [16655,16691]
atom_expr [16655,16691]
===
match
---
name: create_task_instances [6083,6104]
name: create_task_instances [6083,6104]
===
match
---
parameters [4889,4904]
parameters [4889,4904]
===
match
---
number: 2 [28095,28096]
number: 2 [28095,28096]
===
match
---
name: post [43032,43036]
name: post [43754,43758]
===
match
---
name: DEFAULT_DATETIME_1 [10967,10985]
name: DEFAULT_DATETIME_1 [10967,10985]
===
match
---
name: self [36606,36610]
name: self [37328,37332]
===
match
---
name: fixture [2270,2277]
name: fixture [2270,2277]
===
match
---
operator: , [4647,4648]
operator: , [4647,4648]
===
match
---
operator: , [29082,29083]
operator: , [29082,29083]
===
match
---
name: dt [25535,25537]
name: dt [25535,25537]
===
match
---
name: timedelta [10518,10527]
name: timedelta [10518,10527]
===
match
---
operator: , [23202,23203]
operator: , [23202,23203]
===
match
---
operator: } [29717,29718]
operator: } [29717,29718]
===
match
---
name: response [7636,7644]
name: response [7636,7644]
===
match
---
name: json [21354,21358]
name: json [21354,21358]
===
match
---
operator: { [18451,18452]
operator: { [18451,18452]
===
match
---
string: "test_queue_3" [15340,15354]
string: "test_queue_3" [15340,15354]
===
match
---
name: getuser [7200,7207]
name: getuser [7200,7207]
===
match
---
name: i [3917,3918]
name: i [3917,3918]
===
match
---
name: State [28132,28137]
name: State [28132,28137]
===
match
---
string: "test end date filter" [18735,18757]
string: "test end date filter" [18735,18757]
===
match
---
classdef [9577,17181]
classdef [9577,17181]
===
match
---
operator: , [24963,24964]
operator: , [24963,24964]
===
match
---
name: expected_ti_count [21253,21270]
name: expected_ti_count [21253,21270]
===
match
---
expr_stmt [9087,9231]
expr_stmt [9087,9231]
===
match
---
number: 100 [18464,18467]
number: 100 [18464,18467]
===
match
---
atom_expr [7581,7602]
atom_expr [7581,7602]
===
match
---
operator: , [30268,30269]
operator: , [30268,30269]
===
match
---
string: "task_ids" [29244,29254]
string: "task_ids" [29244,29254]
===
match
---
operator: , [14462,14463]
operator: , [14462,14463]
===
match
---
simple_stmt [3933,3982]
simple_stmt [3933,3982]
===
match
---
atom [18775,19002]
atom [18775,19002]
===
match
---
name: post [39938,39942]
name: post [40660,40664]
===
match
---
name: test_should_raises_401_unauthenticated [39288,39326]
name: test_should_raises_401_unauthenticated [40010,40048]
===
match
---
operator: } [24560,24561]
operator: } [24560,24561]
===
match
---
string: "default_pool" [5609,5623]
string: "default_pool" [5609,5623]
===
match
---
simple_stmt [807,833]
simple_stmt [807,833]
===
match
---
operator: , [21878,21879]
operator: , [21878,21879]
===
match
---
trailer [27960,27967]
trailer [27960,27967]
===
match
---
operator: { [27835,27836]
operator: { [27835,27836]
===
match
---
name: assert_401 [1262,1272]
name: assert_401 [1262,1272]
===
match
---
string: "include_past" [39744,39758]
string: "include_past" [40466,40480]
===
match
---
param [36612,36620]
param [37334,37342]
===
match
---
name: DagRun [924,930]
name: DagRun [924,930]
===
match
---
string: 'dag_run_id' [34082,34094]
string: 'dag_run_id' [34804,34816]
===
match
---
parameters [40560,40566]
parameters [41282,41288]
===
match
---
name: update_extras [15728,15741]
name: update_extras [15728,15741]
===
match
---
simple_stmt [38457,38492]
simple_stmt [39179,39214]
===
match
---
funcdef [31409,32104]
funcdef [32131,32826]
===
match
---
operator: = [15741,15742]
operator: = [15741,15742]
===
match
---
dictorsetmaker [21553,21569]
dictorsetmaker [21553,21569]
===
match
---
argument [31629,31658]
argument [32351,32380]
===
match
---
operator: = [32751,32752]
operator: = [33473,33474]
===
match
---
operator: = [16225,16226]
operator: = [16225,16226]
===
match
---
expr_stmt [1460,1512]
expr_stmt [1460,1512]
===
match
---
name: task_instances [33259,33273]
name: task_instances [33981,33995]
===
match
---
strings [14960,15091]
strings [14960,15091]
===
match
---
atom [24222,24302]
atom [24222,24302]
===
match
---
operator: , [31128,31129]
operator: , [31128,31129]
===
match
---
suite [23517,23732]
suite [23517,23732]
===
match
---
decorated [2262,3133]
decorated [2262,3133]
===
match
---
suite [40567,41150]
suite [41289,41872]
===
match
---
dictorsetmaker [41348,41369]
dictorsetmaker [42070,42091]
===
match
---
testlist_comp [12106,12293]
testlist_comp [12106,12293]
===
match
---
atom_expr [3882,3920]
atom_expr [3882,3920]
===
match
---
parameters [16938,16944]
parameters [16938,16944]
===
match
---
operator: } [18828,18829]
operator: } [18828,18829]
===
match
---
name: session [24860,24867]
name: session [24860,24867]
===
match
---
atom_expr [5174,5194]
atom_expr [5174,5194]
===
match
---
string: "pool_slots" [5637,5649]
string: "pool_slots" [5637,5649]
===
match
---
trailer [19427,19437]
trailer [19427,19437]
===
match
---
operator: , [21702,21703]
operator: , [21702,21703]
===
match
---
name: tests [1218,1223]
name: tests [1218,1223]
===
match
---
name: task_instances [36649,36663]
name: task_instances [37371,37385]
===
match
---
name: FAILED [29866,29872]
name: FAILED [29866,29872]
===
match
---
operator: , [18357,18358]
operator: , [18357,18358]
===
match
---
operator: , [11406,11407]
operator: , [11406,11407]
===
match
---
number: 200 [22478,22481]
number: 200 [22478,22481]
===
match
---
operator: , [39764,39765]
operator: , [40486,40487]
===
match
---
operator: { [10732,10733]
operator: { [10732,10733]
===
match
---
trailer [20327,20335]
trailer [20327,20335]
===
match
---
testlist_comp [11453,11996]
testlist_comp [11453,11996]
===
match
---
name: update_extras [37058,37071]
name: update_extras [37780,37793]
===
match
---
operator: @ [24716,24717]
operator: @ [24716,24717]
===
match
---
string: "removed" [7092,7101]
string: "removed" [7092,7101]
===
match
---
number: 1 [30725,30726]
number: 1 [30725,30726]
===
match
---
trailer [7327,7336]
trailer [7327,7336]
===
match
---
assert_stmt [24043,24077]
assert_stmt [24043,24077]
===
match
---
trailer [31121,31128]
trailer [31121,31128]
===
match
---
arglist [39956,40462]
arglist [40678,41184]
===
match
---
atom_expr [32734,32754]
atom_expr [33456,33476]
===
match
---
string: "queue" [5700,5707]
string: "queue" [5700,5707]
===
match
---
operator: , [27813,27814]
operator: , [27813,27814]
===
match
---
name: json [35054,35058]
name: json [35776,35780]
===
match
---
name: State [36728,36733]
name: State [37450,37455]
===
match
---
assert_stmt [37397,37431]
assert_stmt [38119,38153]
===
match
---
operator: = [24886,24887]
operator: = [24886,24887]
===
match
---
atom [18717,19237]
atom [18717,19237]
===
match
---
operator: , [18757,18758]
operator: , [18757,18758]
===
match
---
dictorsetmaker [36338,36380]
dictorsetmaker [37060,37102]
===
match
---
trailer [7207,7209]
trailer [7207,7209]
===
match
---
operator: = [33375,33376]
operator: = [34097,34098]
===
match
---
parameters [3163,3389]
parameters [3163,3389]
===
match
---
operator: , [3279,3280]
operator: , [3279,3280]
===
match
---
atom [24508,24594]
atom [24508,24594]
===
match
---
number: 1 [12212,12213]
number: 1 [12212,12213]
===
match
---
trailer [31827,31834]
trailer [32549,32556]
===
match
---
atom_expr [3559,3569]
atom_expr [3559,3569]
===
match
---
operator: , [35824,35825]
operator: , [36546,36547]
===
match
---
name: State [32927,32932]
name: State [33649,33654]
===
match
---
trailer [31839,31993]
trailer [32561,32715]
===
match
---
atom_expr [39926,40472]
atom_expr [40648,41194]
===
match
---
trailer [9332,9339]
trailer [9332,9339]
===
match
---
operator: { [20109,20110]
operator: { [20109,20110]
===
match
---
dictorsetmaker [14808,14831]
dictorsetmaker [14808,14831]
===
match
---
name: self [16115,16119]
name: self [16115,16119]
===
match
---
atom [29917,30072]
atom [29917,30072]
===
match
---
parameters [39326,39332]
parameters [40048,40054]
===
match
---
arglist [16795,16858]
arglist [16795,16858]
===
match
---
atom_expr [2445,2462]
atom_expr [2445,2462]
===
match
---
atom [40700,40723]
atom [41422,41445]
===
match
---
atom [41389,41737]
atom [42111,42459]
===
match
---
string: "/api/v1/dags/example_python_operator/dagRuns/TEST_DAG_RUN_ID/" [10052,10115]
string: "/api/v1/dags/example_python_operator/dagRuns/TEST_DAG_RUN_ID/" [10052,10115]
===
match
---
trailer [35258,35263]
trailer [35980,35985]
===
match
---
trailer [23803,23810]
trailer [23803,23810]
===
match
---
operator: = [1734,1735]
operator: = [1734,1735]
===
match
---
trailer [37829,37836]
trailer [38551,38558]
===
match
---
name: dt [9866,9868]
name: dt [9866,9868]
===
match
---
parameters [6053,6068]
parameters [6053,6068]
===
match
---
operator: , [18311,18312]
operator: , [18311,18312]
===
match
---
expr_stmt [38948,38989]
expr_stmt [39670,39711]
===
match
---
expr_stmt [23116,23294]
expr_stmt [23116,23294]
===
match
---
operator: { [33767,33768]
operator: { [34489,34490]
===
match
---
simple_stmt [954,995]
simple_stmt [954,995]
===
match
---
name: create_task_instances [31544,31565]
name: create_task_instances [32266,32287]
===
match
---
strings [11782,11958]
strings [11782,11958]
===
match
---
testlist_comp [18389,18689]
testlist_comp [18389,18689]
===
match
---
name: days [20245,20249]
name: days [20245,20249]
===
match
---
operator: = [25036,25037]
operator: = [25036,25037]
===
match
---
trailer [10527,10535]
trailer [10527,10535]
===
match
---
for_stmt [3674,4473]
for_stmt [3674,4473]
===
match
---
string: "duration" [12738,12748]
string: "duration" [12738,12748]
===
match
---
atom_expr [3631,3664]
atom_expr [3631,3664]
===
match
---
operator: { [11515,11516]
operator: { [11515,11516]
===
match
---
operator: , [30797,30798]
operator: , [30797,30798]
===
match
---
operator: , [34064,34065]
operator: , [34786,34787]
===
match
---
trailer [32932,32940]
trailer [33654,33662]
===
match
---
string: "start_date" [11088,11100]
string: "start_date" [11088,11100]
===
match
---
name: expected_ti [15636,15647]
name: expected_ti [15636,15647]
===
match
---
name: days [29818,29822]
name: days [29818,29822]
===
match
---
operator: , [29345,29346]
operator: , [29345,29346]
===
match
---
string: "total_entries" [21288,21303]
string: "total_entries" [21288,21303]
===
match
---
atom [9909,9970]
atom [9909,9970]
===
match
---
operator: , [22958,22959]
operator: , [22958,22959]
===
match
---
atom_expr [22604,22635]
atom_expr [22604,22635]
===
match
---
string: "print_the_context" [8725,8744]
string: "print_the_context" [8725,8744]
===
match
---
name: dag_id [4549,4555]
name: dag_id [4549,4555]
===
match
---
operator: = [3368,3369]
operator: = [3368,3369]
===
match
---
string: "dry_run" [42376,42385]
string: "dry_run" [43098,43107]
===
match
---
string: "state" [30205,30212]
string: "state" [30205,30212]
===
match
---
if_stmt [3711,3921]
if_stmt [3711,3921]
===
match
---
trailer [4524,4749]
trailer [4524,4749]
===
match
---
operator: = [38953,38954]
operator: = [39675,39676]
===
match
---
operator: } [19920,19921]
operator: } [19920,19921]
===
match
---
operator: , [28574,28575]
operator: , [28574,28575]
===
match
---
name: self [6054,6058]
name: self [6054,6058]
===
match
---
operator: , [17969,17970]
operator: , [17969,17970]
===
match
---
name: create_user [2058,2069]
name: create_user [2058,2069]
===
match
---
name: self [16766,16770]
name: self [16766,16770]
===
match
---
argument [39254,39267]
argument [39976,39989]
===
match
---
funcdef [39284,39859]
funcdef [40006,40581]
===
match
---
name: len [35097,35100]
name: len [35819,35822]
===
match
---
name: self [24790,24794]
name: self [24790,24794]
===
match
---
operator: , [20400,20401]
operator: , [20400,20401]
===
match
---
operator: } [40722,40723]
operator: } [41444,41445]
===
match
---
atom [25470,25625]
atom [25470,25625]
===
match
---
name: TestTaskInstanceEndpoint [37520,37544]
name: TestTaskInstanceEndpoint [38242,38266]
===
match
---
comparison [3714,3736]
comparison [3714,3736]
===
match
---
simple_stmt [2174,2224]
simple_stmt [2174,2224]
===
match
---
string: 'example_python_operator' [38884,38909]
string: 'example_python_operator' [39606,39631]
===
match
---
name: payload [42928,42935]
name: payload [43650,43657]
===
match
---
dictorsetmaker [18095,18117]
dictorsetmaker [18095,18117]
===
match
---
string: "priority_weight" [6893,6910]
string: "priority_weight" [6893,6910]
===
match
---
name: response [21195,21203]
name: response [21195,21203]
===
match
---
operator: , [31313,31314]
operator: , [31313,31314]
===
match
---
number: 0 [8976,8977]
number: 0 [8976,8977]
===
match
---
name: State [28893,28898]
name: State [28893,28898]
===
match
---
operator: , [5686,5687]
operator: , [5686,5687]
===
match
---
atom_expr [32052,32088]
atom_expr [32774,32810]
===
match
---
argument [35838,36049]
argument [36560,36771]
===
match
---
string: "2020-01-03T00:00:00+00:00" [5342,5369]
string: "2020-01-03T00:00:00+00:00" [5342,5369]
===
match
---
atom [19333,19367]
atom [19333,19367]
===
match
---
string: "REMOTE_USER" [23235,23248]
string: "REMOTE_USER" [23235,23248]
===
match
---
atom_expr [25435,25447]
atom_expr [25435,25447]
===
match
---
string: "/api/v1/dags/~/dagRuns/~/taskInstances?start_date_gte" [11225,11280]
string: "/api/v1/dags/~/dagRuns/~/taskInstances?start_date_gte" [11225,11280]
===
match
---
atom [9666,15531]
atom [9666,15531]
===
match
---
trailer [37921,37928]
trailer [38643,38650]
===
match
---
operator: , [19843,19844]
operator: , [19843,19844]
===
match
---
arglist [3635,3663]
arglist [3635,3663]
===
match
---
string: 'REMOTE_USER' [40701,40714]
string: 'REMOTE_USER' [41423,41436]
===
match
---
operator: { [17780,17781]
operator: { [17780,17781]
===
match
---
dictorsetmaker [20110,20169]
dictorsetmaker [20110,20169]
===
match
---
string: "state" [36719,36726]
string: "state" [37441,37448]
===
match
---
name: setattr [4053,4060]
name: setattr [4053,4060]
===
match
---
trailer [31772,31774]
trailer [32494,32496]
===
match
---
arglist [33162,33347]
arglist [33884,34069]
===
match
---
argument [39076,39091]
argument [39798,39813]
===
match
---
trailer [16530,16537]
trailer [16530,16537]
===
match
---
argument [4195,4208]
argument [4195,4208]
===
match
---
testlist_comp [17677,17989]
testlist_comp [17677,17989]
===
match
---
operator: , [12619,12620]
operator: , [12619,12620]
===
match
---
name: expected_response [33733,33750]
name: expected_response [34455,34472]
===
match
---
dictorsetmaker [20440,20568]
dictorsetmaker [20440,20568]
===
match
---
trailer [15959,15964]
trailer [15959,15964]
===
match
---
string: "include_upstream" [40261,40279]
string: "include_upstream" [40983,41001]
===
match
---
parameters [42921,42955]
parameters [43643,43677]
===
match
---
number: 2 [20084,20085]
number: 2 [20084,20085]
===
match
---
name: session [37802,37809]
name: session [38524,38531]
===
match
---
string: "/api/v1/dags/~/dagRuns/~/taskInstances/list" [22301,22346]
string: "/api/v1/dags/~/dagRuns/~/taskInstances/list" [22301,22346]
===
match
---
atom_expr [32503,32516]
atom_expr [33225,33238]
===
match
---
suite [2257,4803]
suite [2257,4803]
===
match
---
atom_expr [7647,7836]
atom_expr [7647,7836]
===
match
---
operator: , [37001,37002]
operator: , [37723,37724]
===
match
---
name: timedelta [18965,18974]
name: timedelta [18965,18974]
===
match
---
string: "state" [29061,29068]
string: "state" [29061,29068]
===
match
---
atom [23975,24022]
atom [23975,24022]
===
match
---
operator: , [4063,4064]
operator: , [4063,4064]
===
match
---
dictorsetmaker [13974,13995]
dictorsetmaker [13974,13995]
===
match
---
param [4890,4895]
param [4890,4895]
===
match
---
string: "/api/v1/dags/~/dagRuns/~/taskInstances/list" [23157,23202]
string: "/api/v1/dags/~/dagRuns/~/taskInstances/list" [23157,23202]
===
match
---
trailer [32600,32608]
trailer [33322,33330]
===
match
---
testlist_comp [18302,18321]
testlist_comp [18302,18321]
===
match
---
fstring [12447,12513]
fstring [12447,12513]
===
match
---
string: "queue" [15284,15291]
string: "queue" [15284,15291]
===
match
---
name: RUNNING [3375,3382]
name: RUNNING [3375,3382]
===
match
---
testlist_comp [26103,26877]
testlist_comp [26103,26877]
===
match
---
name: timedelta [11683,11692]
name: timedelta [11683,11692]
===
match
---
operator: { [10479,10480]
operator: { [10479,10480]
===
match
---
decorated [25216,32104]
decorated [25216,32826]
===
match
---
operator: } [13537,13538]
operator: } [13537,13538]
===
match
---
name: task_instances [21820,21834]
name: task_instances [21820,21834]
===
match
---
atom [43145,43168]
atom [43867,43890]
===
match
---
expr_stmt [32223,32415]
expr_stmt [32945,33137]
===
match
---
name: self [4296,4300]
name: self [4296,4300]
===
match
---
operator: , [10536,10537]
operator: , [10536,10537]
===
match
---
trailer [16980,17137]
trailer [16980,17137]
===
match
---
argument [39177,39186]
argument [39899,39908]
===
match
---
name: dag_run_state [33320,33333]
name: dag_run_state [34042,34055]
===
match
---
expr_stmt [31812,31993]
expr_stmt [32534,32715]
===
match
---
name: days [2596,2600]
name: days [2596,2600]
===
match
---
comparison [24050,24077]
comparison [24050,24077]
===
match
---
name: i [3844,3845]
name: i [3844,3845]
===
match
---
trailer [16613,16630]
trailer [16613,16630]
===
match
---
operator: } [27583,27584]
operator: } [27583,27584]
===
match
---
atom [10479,10536]
atom [10479,10536]
===
match
---
operator: , [26037,26038]
operator: , [26037,26038]
===
match
---
dotted_name [25217,25237]
dotted_name [25217,25237]
===
match
---
operator: { [30996,30997]
operator: { [30996,30997]
===
match
---
string: "total_entries" [23434,23449]
string: "total_entries" [23434,23449]
===
match
---
atom [18017,18357]
atom [18017,18357]
===
match
---
atom_expr [37447,37470]
atom_expr [38169,38192]
===
match
---
param [23511,23515]
param [23511,23515]
===
match
---
operator: , [19446,19447]
operator: , [19446,19447]
===
match
---
name: days [29028,29032]
name: days [29028,29032]
===
match
---
atom [17462,17487]
atom [17462,17487]
===
match
---
argument [4230,4259]
argument [4230,4259]
===
match
---
arglist [36948,37112]
arglist [37670,37834]
===
match
---
atom [9744,9989]
atom [9744,9989]
===
match
---
operator: , [11701,11702]
operator: , [11701,11702]
===
match
---
atom [27004,27462]
atom [27004,27462]
===
match
---
atom [17938,17968]
atom [17938,17968]
===
match
---
trailer [18974,18982]
trailer [18974,18982]
===
match
---
name: tasks [39228,39233]
name: tasks [39950,39955]
===
match
---
name: key [3999,4002]
name: key [3999,4002]
===
match
---
name: timedelta [29985,29994]
name: timedelta [29985,29994]
===
match
---
operator: { [28773,28774]
operator: { [28773,28774]
===
match
---
number: 2 [19767,19768]
number: 2 [19767,19768]
===
match
---
simple_stmt [23526,23703]
simple_stmt [23526,23703]
===
match
---
operator: , [1998,1999]
operator: , [1998,1999]
===
match
---
name: test_should_raises_401_unauthenticated [9033,9071]
name: test_should_raises_401_unauthenticated [9033,9071]
===
match
---
operator: } [24660,24661]
operator: } [24660,24661]
===
match
---
name: State [1120,1125]
name: State [1120,1125]
===
match
---
trailer [41238,41748]
trailer [41960,42470]
===
match
---
name: json [21283,21287]
name: json [21283,21287]
===
match
---
string: "end_date" [2617,2627]
string: "end_date" [2617,2627]
===
match
---
operator: , [28928,28929]
operator: , [28928,28929]
===
match
---
operator: , [17695,17696]
operator: , [17695,17696]
===
match
---
operator: , [19237,19238]
operator: , [19237,19238]
===
match
---
name: json [35838,35842]
name: json [36560,36564]
===
match
---
trailer [4173,4440]
trailer [4173,4440]
===
match
---
operator: = [4720,4721]
operator: = [4720,4721]
===
match
---
operator: } [14461,14462]
operator: } [14461,14462]
===
match
---
operator: } [37350,37351]
operator: } [38072,38073]
===
match
---
name: response [16659,16667]
name: response [16659,16667]
===
match
---
operator: , [36381,36382]
operator: , [37103,37104]
===
match
---
name: state [39200,39205]
name: state [39922,39927]
===
match
---
name: update_extras [33287,33300]
name: update_extras [34009,34022]
===
match
---
string: 'dag_run_id' [34796,34808]
string: 'dag_run_id' [35518,35530]
===
match
---
string: "Naive datetime is disallowed" [24463,24493]
string: "Naive datetime is disallowed" [24463,24493]
===
match
---
atom [31231,31332]
atom [31231,31332]
===
match
---
operator: == [16049,16051]
operator: == [16049,16051]
===
match
---
operator: , [27462,27463]
operator: , [27462,27463]
===
match
---
name: configured_app [2854,2868]
name: configured_app [2854,2868]
===
match
---
operator: , [34540,34541]
operator: , [35262,35263]
===
match
---
trailer [2449,2462]
trailer [2449,2462]
===
match
---
operator: , [4734,4735]
operator: , [4734,4735]
===
match
---
name: minimal_app_for_api [1598,1617]
name: minimal_app_for_api [1598,1617]
===
match
---
operator: } [11327,11328]
operator: } [11327,11328]
===
match
---
name: response [5217,5225]
name: response [5217,5225]
===
match
---
atom_expr [27230,27243]
atom_expr [27230,27243]
===
match
---
atom_expr [1921,1955]
atom_expr [1921,1955]
===
match
---
string: "Naive datetime is disallowed" [36383,36413]
string: "Naive datetime is disallowed" [37105,37135]
===
match
---
name: dt [12194,12196]
name: dt [12194,12196]
===
match
---
comparison [32052,32103]
comparison [32774,32825]
===
match
---
name: session [4089,4096]
name: session [4089,4096]
===
match
---
trailer [25772,25779]
trailer [25772,25779]
===
match
---
trailer [32055,32088]
trailer [32777,32810]
===
match
---
trailer [3638,3654]
trailer [3638,3654]
===
match
---
atom_expr [41122,41142]
atom_expr [41844,41864]
===
match
---
operator: = [33751,33752]
operator: = [34473,34474]
===
match
---
atom_expr [2174,2207]
atom_expr [2174,2207]
===
match
---
name: DEFAULT_DATETIME_1 [27332,27350]
name: DEFAULT_DATETIME_1 [27332,27350]
===
match
---
name: update [21918,21924]
name: update [21918,21924]
===
match
---
operator: { [26209,26210]
operator: { [26209,26210]
===
match
---
name: response [7852,7860]
name: response [7852,7860]
===
match
---
dictorsetmaker [28270,28327]
dictorsetmaker [28270,28327]
===
match
---
name: client [37214,37220]
name: client [37936,37942]
===
match
---
name: SUCCESS [18201,18208]
name: SUCCESS [18201,18208]
===
match
---
atom_expr [13479,13492]
atom_expr [13479,13492]
===
match
---
atom_expr [26257,26269]
atom_expr [26257,26269]
===
match
---
operator: { [14854,14855]
operator: { [14854,14855]
===
match
---
string: "INVALID_TASK" [41451,41465]
string: "INVALID_TASK" [42173,42187]
===
match
---
argument [3019,3042]
argument [3019,3042]
===
match
---
name: dag_id [4542,4548]
name: dag_id [4542,4548]
===
match
---
string: "test_pool_2" [13982,13995]
string: "test_pool_2" [13982,13995]
===
match
---
trailer [19995,20003]
trailer [19995,20003]
===
match
---
comparison [21320,21377]
comparison [21320,21377]
===
match
---
param [3173,3178]
param [3173,3178]
===
match
---
simple_stmt [32223,32416]
simple_stmt [32945,33138]
===
match
---
string: "test start date filter" [19269,19293]
string: "test start date filter" [19269,19293]
===
match
---
string: "task" [21513,21519]
string: "task" [21513,21519]
===
match
---
testlist_comp [41860,42308]
testlist_comp [42582,43030]
===
match
---
operator: , [25304,25305]
operator: , [25304,25305]
===
match
---
atom [28012,28168]
atom [28012,28168]
===
match
---
name: test_should_assert_call_mocked_api [37639,37673]
name: test_should_assert_call_mocked_api [38361,38395]
===
match
---
argument [39050,39062]
argument [39772,39784]
===
match
---
operator: , [6790,6791]
operator: , [6790,6791]
===
match
---
operator: { [43145,43146]
operator: { [43867,43868]
===
match
---
name: TaskInstance [16518,16530]
name: TaskInstance [16518,16530]
===
match
---
argument [33210,33230]
argument [33932,33952]
===
match
---
operator: , [31081,31082]
operator: , [31081,31082]
===
match
---
name: session [7283,7290]
name: session [7283,7290]
===
match
---
name: self [41222,41226]
name: self [41944,41948]
===
match
---
argument [28851,28857]
argument [28851,28857]
===
match
---
operator: { [19468,19469]
operator: { [19468,19469]
===
match
---
name: State [30037,30042]
name: State [30037,30042]
===
match
---
name: get [16977,16980]
name: get [16977,16980]
===
match
---
string: "{'execution_date': ['Not a valid datetime.']}" [42764,42811]
string: "{'execution_date': ['Not a valid datetime.']}" [43486,43533]
===
match
---
atom [30819,30974]
atom [30819,30974]
===
match
---
string: "start_date" [10480,10492]
string: "start_date" [10480,10492]
===
match
---
argument [19517,19523]
argument [19517,19523]
===
match
---
trailer [40591,40598]
trailer [41313,41320]
===
match
---
name: dt [27900,27902]
name: dt [27900,27902]
===
match
---
string: "execution_date" [32456,32472]
string: "execution_date" [33178,33194]
===
match
---
dictorsetmaker [24610,24660]
dictorsetmaker [24610,24660]
===
match
---
name: response [39342,39350]
name: response [40064,40072]
===
match
---
string: "state" [28552,28559]
string: "state" [28552,28559]
===
match
---
name: self [31745,31749]
name: self [32467,32471]
===
match
---
name: response [40488,40496]
name: response [41210,41218]
===
match
---
string: "state" [25426,25433]
string: "state" [25426,25433]
===
match
---
dictorsetmaker [20027,20086]
dictorsetmaker [20027,20086]
===
match
---
name: status_code [6410,6421]
name: status_code [6410,6421]
===
match
---
operator: } [32808,32809]
operator: } [33530,33531]
===
match
---
atom [14738,14898]
atom [14738,14898]
===
match
---
operator: } [31150,31151]
operator: } [31150,31151]
===
match
---
operator: == [36097,36099]
operator: == [36819,36821]
===
match
---
operator: , [23612,23613]
operator: , [23612,23613]
===
match
---
name: RUNNING [32509,32516]
name: RUNNING [33231,33238]
===
match
---
name: expected_ti [22960,22971]
name: expected_ti [22960,22971]
===
match
---
name: test_should_raise_403_forbidden [16907,16938]
name: test_should_raise_403_forbidden [16907,16938]
===
match
---
trailer [22603,22636]
trailer [22603,22636]
===
match
---
operator: } [26036,26037]
operator: } [26036,26037]
===
match
---
name: DEFAULT_DATETIME_STR_2 [10773,10795]
name: DEFAULT_DATETIME_STR_2 [10773,10795]
===
match
---
name: default_time [7508,7520]
name: default_time [7508,7520]
===
match
---
argument [7442,7474]
argument [7442,7474]
===
match
---
name: response [17153,17161]
name: response [17153,17161]
===
match
---
string: "include_upstream" [40895,40913]
string: "include_upstream" [41617,41635]
===
match
---
operator: , [13429,13430]
operator: , [13429,13430]
===
match
---
operator: , [14268,14269]
operator: , [14268,14269]
===
match
---
arglist [9357,9521]
arglist [9357,9521]
===
match
---
trailer [1633,2053]
trailer [1633,2053]
===
match
---
trailer [41233,41238]
trailer [41955,41960]
===
match
---
string: "state" [28123,28130]
string: "state" [28123,28130]
===
match
---
name: json [22613,22617]
name: json [22613,22617]
===
match
---
name: self [24888,24892]
name: self [24888,24892]
===
match
---
operator: = [39119,39120]
operator: = [39841,39842]
===
match
---
string: "execution_date" [25388,25404]
string: "execution_date" [25388,25404]
===
match
---
name: payload [20756,20763]
name: payload [20756,20763]
===
match
---
param [35641,35645]
param [36363,36367]
===
match
---
string: 'dag_id' [34267,34275]
string: 'dag_id' [34989,34997]
===
match
---
operator: , [17803,17804]
operator: , [17803,17804]
===
match
---
name: response [22604,22612]
name: response [22604,22612]
===
match
---
operator: { [37328,37329]
operator: { [38050,38051]
===
match
---
simple_stmt [21903,22065]
simple_stmt [21903,22065]
===
match
---
operator: + [30157,30158]
operator: + [30157,30158]
===
match
---
assert_stmt [40481,40515]
assert_stmt [41203,41237]
===
match
---
operator: = [36975,36976]
operator: = [37697,37698]
===
match
---
string: 'dag_run_id' [34320,34332]
string: 'dag_run_id' [35042,35054]
===
match
---
name: dagbag [3492,3498]
name: dagbag [3492,3498]
===
match
---
name: json [5226,5230]
name: json [5226,5230]
===
match
---
param [21817,21819]
param [21817,21819]
===
match
---
string: 'sleep_for_2' [34683,34696]
string: 'sleep_for_2' [35405,35418]
===
match
---
strings [11225,11369]
strings [11225,11369]
===
match
---
trailer [18200,18208]
trailer [18200,18208]
===
match
---
atom [13560,13584]
atom [13560,13584]
===
match
---
name: State [25767,25772]
name: State [25767,25772]
===
match
---
name: DEFAULT_DATETIME_1 [36699,36717]
name: DEFAULT_DATETIME_1 [37421,37439]
===
match
---
trailer [3506,3514]
trailer [3506,3514]
===
match
---
name: days [10528,10532]
name: days [10528,10532]
===
match
---
number: 100 [12672,12675]
number: 100 [12672,12675]
===
match
---
atom [21428,21691]
atom [21428,21691]
===
match
---
simple_stmt [40576,41107]
simple_stmt [41298,41829]
===
match
---
name: ACTION_CAN_READ [1831,1846]
name: ACTION_CAN_READ [1831,1846]
===
match
---
operator: = [39464,39465]
operator: = [40186,40187]
===
match
---
operator: , [34654,34655]
operator: , [35376,35377]
===
match
---
atom [40108,40461]
atom [40830,41183]
===
match
---
dictorsetmaker [18292,18322]
dictorsetmaker [18292,18322]
===
match
---
decorator [31388,31405]
decorator [32110,32127]
===
match
---
name: environ_overrides [31915,31932]
name: environ_overrides [32637,32654]
===
match
---
atom_expr [36813,36833]
atom_expr [37535,37555]
===
match
---
operator: = [43186,43187]
operator: = [43908,43909]
===
match
---
string: "state" [29519,29526]
string: "state" [29519,29526]
===
match
---
atom [10344,10378]
atom [10344,10378]
===
match
---
name: DEFAULT_DATETIME_STR_2 [19162,19184]
name: DEFAULT_DATETIME_STR_2 [19162,19184]
===
match
---
operator: = [39262,39263]
operator: = [39984,39985]
===
match
---
atom_expr [28893,28905]
atom_expr [28893,28905]
===
match
---
atom [10322,10555]
atom [10322,10555]
===
match
---
string: "pool" [13974,13980]
string: "pool" [13974,13980]
===
match
---
trailer [20317,20327]
trailer [20317,20327]
===
match
---
operator: = [30176,30177]
operator: = [30176,30177]
===
match
---
name: ACTION_CAN_EDIT [1983,1998]
name: ACTION_CAN_EDIT [1983,1998]
===
match
---
atom [21414,21702]
atom [21414,21702]
===
match
---
string: "state" [32772,32779]
string: "state" [33494,33501]
===
match
---
testlist_comp [28513,29106]
testlist_comp [28513,29106]
===
match
---
funcdef [9029,9261]
funcdef [9029,9261]
===
match
---
simple_stmt [23045,23108]
simple_stmt [23045,23108]
===
match
---
operator: , [2693,2694]
operator: , [2693,2694]
===
match
---
string: "execution_date" [2427,2443]
string: "execution_date" [2427,2443]
===
match
---
string: "operator" [8214,8224]
string: "operator" [8214,8224]
===
match
---
argument [2596,2602]
argument [2596,2602]
===
match
---
simple_stmt [40481,40516]
simple_stmt [41203,41238]
===
match
---
arith_expr [27154,27195]
arith_expr [27154,27195]
===
match
---
string: "state" [18095,18102]
string: "state" [18095,18102]
===
match
---
string: "test" [38058,38064]
string: "test" [38780,38786]
===
match
---
dotted_name [9636,9656]
dotted_name [9636,9656]
===
match
---
trailer [7358,7360]
trailer [7358,7360]
===
match
---
trailer [26536,26546]
trailer [26536,26546]
===
match
---
operator: = [6170,6171]
operator: = [6170,6171]
===
match
---
atom [25261,26071]
atom [25261,26071]
===
match
---
string: "duration" [12699,12709]
string: "duration" [12699,12709]
===
match
---
atom [28513,28574]
atom [28513,28574]
===
match
---
trailer [23553,23702]
trailer [23553,23702]
===
match
---
string: "module" [1537,1545]
string: "module" [1537,1545]
===
match
---
operator: , [5092,5093]
operator: , [5092,5093]
===
match
---
string: 'REMOTE_USER' [17089,17102]
string: 'REMOTE_USER' [17089,17102]
===
match
---
param [9302,9306]
param [9302,9306]
===
match
---
arith_expr [30686,30727]
arith_expr [30686,30727]
===
match
---
import_from [1299,1363]
import_from [1299,1363]
===
match
---
trailer [16447,16459]
trailer [16447,16459]
===
match
---
operator: { [9909,9910]
operator: { [9909,9910]
===
match
---
arglist [1643,2047]
arglist [1643,2047]
===
match
---
import_as_names [1262,1298]
import_as_names [1262,1298]
===
match
---
operator: , [22481,22482]
operator: , [22481,22482]
===
match
---
operator: , [40089,40090]
operator: , [40811,40812]
===
match
---
testlist_comp [21446,21677]
testlist_comp [21446,21677]
===
match
---
string: "end_date" [18798,18808]
string: "end_date" [18798,18808]
===
match
---
name: json [15960,15964]
name: json [15960,15964]
===
match
---
name: timedelta [20152,20161]
name: timedelta [20152,20161]
===
match
---
dictorsetmaker [12699,12714]
dictorsetmaker [12699,12714]
===
match
---
operator: , [15634,15635]
operator: , [15634,15635]
===
match
---
string: "try_number" [8962,8974]
string: "try_number" [8962,8974]
===
match
---
trailer [3950,3981]
trailer [3950,3981]
===
match
---
name: minimal_app_for_api [1566,1585]
name: minimal_app_for_api [1566,1585]
===
match
---
atom [23963,24023]
atom [23963,24023]
===
match
---
trailer [27177,27187]
trailer [27177,27187]
===
match
---
dictorsetmaker [18628,18668]
dictorsetmaker [18628,18668]
===
match
---
atom [18291,18323]
atom [18291,18323]
===
match
---
operator: , [40329,40330]
operator: , [41051,41052]
===
match
---
name: DEFAULT_DATETIME_1 [2371,2389]
name: DEFAULT_DATETIME_1 [2371,2389]
===
match
---
atom [8462,8817]
atom [8462,8817]
===
match
---
operator: , [25424,25425]
operator: , [25424,25425]
===
match
---
operator: + [10513,10514]
operator: + [10513,10514]
===
match
---
operator: } [20252,20253]
operator: } [20252,20253]
===
match
---
operator: , [38010,38011]
operator: , [38732,38733]
===
match
---
operator: } [11700,11701]
operator: } [11700,11701]
===
match
---
trailer [18897,18905]
trailer [18897,18905]
===
match
---
operator: , [42197,42198]
operator: , [42919,42920]
===
match
---
atom_expr [1892,1919]
atom_expr [1892,1919]
===
match
---
trailer [2011,2034]
trailer [2011,2034]
===
match
---
operator: , [23283,23284]
operator: , [23283,23284]
===
match
---
atom_expr [3369,3382]
atom_expr [3369,3382]
===
match
---
atom [26292,26447]
atom [26292,26447]
===
match
---
testlist_comp [22753,22798]
testlist_comp [22753,22798]
===
match
---
dictorsetmaker [12161,12214]
dictorsetmaker [12161,12214]
===
match
---
atom_expr [39353,39829]
atom_expr [40075,40551]
===
match
---
suite [22992,23463]
suite [22992,23463]
===
match
---
name: payload [24796,24803]
name: payload [24796,24803]
===
match
---
string: "/api/v1/dags/~/dagRuns/~/taskInstances?duration_gte=100&duration_lte=200" [13270,13344]
string: "/api/v1/dags/~/dagRuns/~/taskInstances?duration_gte=100&duration_lte=200" [13270,13344]
===
match
---
string: "test" [33498,33504]
string: "test" [34220,34226]
===
match
---
operator: = [1536,1537]
operator: = [1536,1537]
===
match
---
number: 3 [13004,13005]
number: 3 [13004,13005]
===
match
---
name: db [1321,1323]
name: db [1321,1323]
===
match
---
atom_expr [38955,38989]
atom_expr [39677,39711]
===
match
---
operator: , [8817,8818]
operator: , [8817,8818]
===
match
---
name: State [26257,26262]
name: State [26257,26262]
===
match
---
string: "test" [5140,5146]
string: "test" [5140,5146]
===
match
---
dictorsetmaker [34743,34935]
dictorsetmaker [35465,35657]
===
match
---
number: 2 [26552,26553]
number: 2 [26552,26553]
===
match
---
operator: , [23669,23670]
operator: , [23669,23670]
===
match
---
operator: , [36888,36889]
operator: , [37610,37611]
===
match
---
name: state [1107,1112]
name: state [1107,1112]
===
match
---
name: response [39849,39857]
name: response [40571,40579]
===
match
---
operator: , [39062,39063]
operator: , [39784,39785]
===
match
---
name: parameterized [21384,21397]
name: parameterized [21384,21397]
===
match
---
expr_stmt [24877,25055]
expr_stmt [24877,25055]
===
match
---
arglist [39050,39268]
arglist [39772,39990]
===
match
---
atom_expr [36728,36741]
atom_expr [37450,37463]
===
match
---
operator: { [24509,24510]
operator: { [24509,24510]
===
match
---
operator: , [34235,34236]
operator: , [34957,34958]
===
match
---
argument [18975,18981]
argument [18975,18981]
===
match
---
testlist_comp [26923,27604]
testlist_comp [26923,27604]
===
match
---
operator: + [25533,25534]
operator: + [25533,25534]
===
match
---
trailer [31543,31565]
trailer [32265,32287]
===
match
---
operator: , [10912,10913]
operator: , [10912,10913]
===
match
---
operator: , [22800,22801]
operator: , [22800,22801]
===
match
---
trailer [20234,20244]
trailer [20234,20244]
===
match
---
string: "state" [32494,32501]
string: "state" [33216,33223]
===
match
---
fstring_start: f" [33407,33409]
fstring_start: f" [34129,34131]
===
match
---
operator: } [12675,12676]
operator: } [12675,12676]
===
match
---
atom [30996,31151]
atom [30996,31151]
===
match
---
trailer [40598,40603]
trailer [41320,41325]
===
match
---
operator: = [7502,7503]
operator: = [7502,7503]
===
match
---
name: response [24050,24058]
name: response [24050,24058]
===
match
---
testlist_comp [24509,24593]
testlist_comp [24509,24593]
===
match
---
param [42922,42927]
param [43644,43649]
===
match
---
string: "execution_date" [26210,26226]
string: "execution_date" [26210,26226]
===
match
---
operator: , [20170,20171]
operator: , [20170,20171]
===
match
---
arglist [22673,22867]
arglist [22673,22867]
===
match
---
name: task_instances [3902,3916]
name: task_instances [3902,3916]
===
match
---
operator: , [26246,26247]
operator: , [26246,26247]
===
match
---
trailer [3054,3056]
trailer [3054,3056]
===
match
---
name: state [4715,4720]
name: state [4715,4720]
===
match
---
atom [14807,14832]
atom [14807,14832]
===
match
---
string: "2020-01-01T00:00:00+00:00" [8775,8802]
string: "2020-01-01T00:00:00+00:00" [8775,8802]
===
match
---
operator: @ [25216,25217]
operator: @ [25216,25217]
===
match
---
operator: } [24022,24023]
operator: } [24022,24023]
===
match
---
funcdef [32109,35173]
funcdef [32831,35895]
===
match
---
operator: , [42926,42927]
operator: , [43648,43649]
===
match
---
atom_expr [16877,16897]
atom_expr [16877,16897]
===
match
---
argument [4665,4697]
argument [4665,4697]
===
match
---
atom [11203,11387]
atom [11203,11387]
===
match
---
name: task_instances [31644,31658]
name: task_instances [32366,32380]
===
match
---
atom_expr [2351,2368]
atom_expr [2351,2368]
===
match
---
trailer [28840,28850]
trailer [28840,28850]
===
match
---
operator: , [3316,3317]
operator: , [3316,3317]
===
match
---
simple_stmt [32180,32215]
simple_stmt [32902,32937]
===
match
---
operator: , [33934,33935]
operator: , [34656,34657]
===
match
---
suite [16130,16692]
suite [16130,16692]
===
match
---
operator: , [34220,34221]
operator: , [34942,34943]
===
match
---
operator: = [29822,29823]
operator: = [29822,29823]
===
match
---
operator: == [43242,43244]
operator: == [43964,43966]
===
match
---
operator: , [2046,2047]
operator: , [2046,2047]
===
match
---
argument [39460,39818]
argument [40182,40540]
===
match
---
operator: { [23906,23907]
operator: { [23906,23907]
===
match
---
name: get_dag [3499,3506]
name: get_dag [3499,3506]
===
match
---
operator: { [18529,18530]
operator: { [18529,18530]
===
match
---
assert_stmt [21246,21304]
assert_stmt [21246,21304]
===
match
---
strings [12373,12513]
strings [12373,12513]
===
match
---
atom_expr [2937,2952]
atom_expr [2937,2952]
===
match
---
atom_expr [5217,5230]
atom_expr [5217,5230]
===
match
---
operator: == [41143,41145]
operator: == [41865,41867]
===
match
---
string: "execution_date" [25496,25512]
string: "execution_date" [25496,25512]
===
match
---
operator: { [35843,35844]
operator: { [36565,36566]
===
match
---
name: self [16183,16187]
name: self [16183,16187]
===
match
---
name: environ_overrides [7784,7801]
name: environ_overrides [7784,7801]
===
match
---
name: RUNNING [33079,33086]
name: RUNNING [33801,33808]
===
match
---
operator: } [26623,26624]
operator: } [26623,26624]
===
match
---
number: 2 [13822,13823]
number: 2 [13822,13823]
===
match
---
name: DEFAULT_DATETIME_1 [18810,18828]
name: DEFAULT_DATETIME_1 [18810,18828]
===
match
---
string: "end_date_gte" [24224,24238]
string: "end_date_gte" [24224,24238]
===
match
---
string: "queue" [15331,15338]
string: "queue" [15331,15338]
===
match
---
operator: , [36049,36050]
operator: , [36771,36772]
===
match
---
comparison [25071,25098]
comparison [25071,25098]
===
match
---
name: future [39152,39158]
name: future [39874,39880]
===
match
---
name: datetime [1386,1394]
name: datetime [1386,1394]
===
match
---
name: test_should_raise_403_forbidden [35609,35640]
name: test_should_raise_403_forbidden [36331,36362]
===
match
---
name: DagRun [33613,33619]
name: DagRun [34335,34341]
===
match
---
string: "" [8170,8172]
string: "" [8170,8172]
===
match
---
atom [17568,17611]
atom [17568,17611]
===
match
---
trailer [3916,3919]
trailer [3916,3919]
===
match
---
string: "REMOTE_USER" [5125,5138]
string: "REMOTE_USER" [5125,5138]
===
match
---
string: "state" [25581,25588]
string: "state" [25581,25588]
===
match
---
name: self [16965,16969]
name: self [16965,16969]
===
match
---
operator: , [7014,7015]
operator: , [7014,7015]
===
match
---
trailer [33339,33346]
trailer [34061,34068]
===
match
---
operator: , [13363,13364]
operator: , [13363,13364]
===
match
---
string: "state" [28884,28891]
string: "state" [28884,28891]
===
match
---
decorator [1515,1547]
decorator [1515,1547]
===
match
---
operator: + [19502,19503]
operator: + [19502,19503]
===
match
---
name: session [4786,4793]
name: session [4786,4793]
===
match
---
name: status_code [21204,21215]
name: status_code [21204,21215]
===
match
---
name: create_task_instances [33127,33148]
name: create_task_instances [33849,33870]
===
match
---
number: 5 [35092,35093]
number: 5 [35814,35815]
===
match
---
operator: { [19389,19390]
operator: { [19389,19390]
===
match
---
operator: { [31868,31869]
operator: { [32590,32591]
===
match
---
operator: , [39214,39215]
operator: , [39936,39937]
===
match
---
operator: , [35387,35388]
operator: , [36109,36110]
===
match
---
name: status_code [38473,38484]
name: status_code [39195,39206]
===
match
---
name: self [22271,22275]
name: self [22271,22275]
===
match
---
name: json [37456,37460]
name: json [38178,38182]
===
match
---
trailer [16573,16575]
trailer [16573,16575]
===
match
---
string: "include_past" [42664,42678]
string: "include_past" [43386,43400]
===
match
---
name: days [30897,30901]
name: days [30897,30901]
===
match
---
string: "example_python_operator" [7449,7474]
string: "example_python_operator" [7449,7474]
===
match
---
funcdef [9266,9575]
funcdef [9266,9575]
===
match
---
dictorsetmaker [11088,11143]
dictorsetmaker [11088,11143]
===
match
---
arglist [35697,36050]
arglist [36419,36772]
===
match
---
simple_stmt [31745,31804]
simple_stmt [32467,32526]
===
match
---
operator: == [21216,21218]
operator: == [21216,21218]
===
match
---
operator: } [19445,19446]
operator: } [19445,19446]
===
match
---
operator: } [18905,18906]
operator: } [18905,18906]
===
match
---
operator: { [17462,17463]
operator: { [17462,17463]
===
match
---
argument [23888,23944]
argument [23888,23944]
===
match
---
funcdef [24737,25150]
funcdef [24737,25150]
===
match
---
string: 'dag_run_id' [38653,38665]
string: 'dag_run_id' [39375,39387]
===
match
---
name: payload [25037,25044]
name: payload [25037,25044]
===
match
---
simple_stmt [2843,2869]
simple_stmt [2843,2869]
===
match
---
atom [15236,15261]
atom [15236,15261]
===
match
---
simple_stmt [1088,1126]
simple_stmt [1088,1126]
===
match
---
operator: = [6350,6351]
operator: = [6350,6351]
===
match
---
name: State [30214,30219]
name: State [30214,30219]
===
match
---
atom_expr [26412,26424]
atom_expr [26412,26424]
===
match
---
operator: + [30705,30706]
operator: + [30705,30706]
===
match
---
operator: -> [2334,2336]
operator: -> [2334,2336]
===
match
---
expr_stmt [4513,4749]
expr_stmt [4513,4749]
===
match
---
name: self [2518,2522]
name: self [2518,2522]
===
match
---
trailer [18109,18117]
trailer [18109,18117]
===
match
---
import_from [1126,1169]
import_from [1126,1169]
===
match
---
name: DEFAULT_DATETIME_STR_1 [11896,11918]
name: DEFAULT_DATETIME_STR_1 [11896,11918]
===
match
---
string: "test queue filter" [17309,17328]
string: "test queue filter" [17309,17328]
===
match
---
atom_expr [24833,24868]
atom_expr [24833,24868]
===
match
---
name: DEFAULT_DATETIME_1 [26228,26246]
name: DEFAULT_DATETIME_1 [26228,26246]
===
match
---
name: json [23429,23433]
name: json [23429,23433]
===
match
---
operator: { [13155,13156]
operator: { [13155,13156]
===
match
---
name: response [16755,16763]
name: response [16755,16763]
===
match
---
dictorsetmaker [18852,18905]
dictorsetmaker [18852,18905]
===
match
---
atom [24316,24398]
atom [24316,24398]
===
match
---
name: self [15667,15671]
name: self [15667,15671]
===
match
---
comparison [22579,22636]
comparison [22579,22636]
===
match
---
operator: } [24174,24175]
operator: } [24174,24175]
===
match
---
operator: , [15714,15715]
operator: , [15714,15715]
===
match
---
operator: , [30727,30728]
operator: , [30727,30728]
===
match
---
operator: , [5563,5564]
operator: , [5563,5564]
===
match
---
name: json [35110,35114]
name: json [35832,35836]
===
match
---
string: '2020-11-10T12:42:39.442973' [36168,36196]
string: '2020-11-10T12:42:39.442973' [36890,36918]
===
match
---
name: dt [30159,30161]
name: dt [30159,30161]
===
match
---
trailer [16015,16048]
trailer [16015,16048]
===
match
---
param [6054,6059]
param [6054,6059]
===
match
---
operator: , [14654,14655]
operator: , [14654,14655]
===
match
---
string: "TEST_DAG_RUN_ID/taskInstances?state=running,queued" [13734,13786]
string: "TEST_DAG_RUN_ID/taskInstances?state=running,queued" [13734,13786]
===
match
---
number: 1 [32606,32607]
number: 1 [33328,33329]
===
match
---
operator: = [33258,33259]
operator: = [33980,33981]
===
match
---
operator: , [17550,17551]
operator: , [17550,17551]
===
match
---
name: DEFAULT_DATETIME_1 [39120,39138]
name: DEFAULT_DATETIME_1 [39842,39860]
===
match
---
atom [9680,10248]
atom [9680,10248]
===
match
---
operator: = [3629,3630]
operator: = [3629,3630]
===
match
---
atom [6351,6374]
atom [6351,6374]
===
match
---
operator: , [19184,19185]
operator: , [19184,19185]
===
match
---
number: 404 [41788,41791]
number: 404 [42510,42513]
===
match
---
dictorsetmaker [41407,41723]
dictorsetmaker [42129,42445]
===
match
---
operator: , [25602,25603]
operator: , [25602,25603]
===
match
---
operator: , [25802,25803]
operator: , [25802,25803]
===
match
---
name: permissions [1848,1859]
name: permissions [1848,1859]
===
match
---
name: days [20328,20332]
name: days [20328,20332]
===
match
---
expr_stmt [2398,2509]
expr_stmt [2398,2509]
===
match
---
comparison [5174,5201]
comparison [5174,5201]
===
match
---
operator: , [35427,35428]
operator: , [36149,36150]
===
match
---
simple_stmt [41757,41792]
simple_stmt [42479,42514]
===
match
---
operator: } [23256,23257]
operator: } [23256,23257]
===
match
---
operator: , [24023,24024]
operator: , [24023,24024]
===
match
---
operator: { [17088,17089]
operator: { [17088,17089]
===
match
---
name: dt [11680,11682]
name: dt [11680,11682]
===
match
---
name: client [39931,39937]
name: client [40653,40659]
===
match
---
operator: , [42684,42685]
operator: , [43406,43407]
===
match
---
operator: { [12698,12699]
operator: { [12698,12699]
===
match
---
testlist_comp [10952,11145]
testlist_comp [10952,11145]
===
match
---
string: "/api/v1/dags/example_python_operator/dagRuns/~/taskInstances" [16294,16356]
string: "/api/v1/dags/example_python_operator/dagRuns/~/taskInstances" [16294,16356]
===
match
---
string: "test start date filter" [10280,10304]
string: "test start date filter" [10280,10304]
===
match
---
operator: , [20336,20337]
operator: , [20336,20337]
===
match
---
string: "test_no_permissions" [40067,40088]
string: "test_no_permissions" [40789,40810]
===
match
---
name: response [15818,15826]
name: response [15818,15826]
===
match
---
name: json [22542,22546]
name: json [22542,22546]
===
match
---
testlist_comp [24223,24301]
testlist_comp [24223,24301]
===
match
---
trailer [24899,24904]
trailer [24899,24904]
===
match
---
name: app [2896,2899]
name: app [2896,2899]
===
match
---
operator: = [35352,35353]
operator: = [36074,36075]
===
match
---
name: dag_id [33183,33189]
name: dag_id [33905,33911]
===
match
---
number: 2 [21675,21676]
number: 2 [21675,21676]
===
match
---
string: 'REMOTE_USER' [23907,23920]
string: 'REMOTE_USER' [23907,23920]
===
match
---
string: "include_subdags" [36011,36028]
string: "include_subdags" [36733,36750]
===
match
---
dictorsetmaker [18186,18208]
dictorsetmaker [18186,18208]
===
match
---
trailer [20068,20078]
trailer [20068,20078]
===
match
---
funcdef [41155,41792]
funcdef [41877,42514]
===
match
---
suite [4857,9575]
suite [4857,9575]
===
match
---
operator: { [22740,22741]
operator: { [22740,22741]
===
match
---
operator: , [31691,31692]
operator: , [32413,32414]
===
match
---
param [3289,3317]
param [3289,3317]
===
match
---
operator: , [18507,18508]
operator: , [18507,18508]
===
match
---
operator: , [6879,6880]
operator: , [6879,6880]
===
match
---
operator: = [43144,43145]
operator: = [43866,43867]
===
match
---
simple_stmt [2058,2154]
simple_stmt [2058,2154]
===
match
---
string: "failed" [40438,40446]
string: "failed" [41160,41168]
===
match
---
operator: , [41737,41738]
operator: , [42459,42460]
===
match
---
trailer [31749,31753]
trailer [32471,32475]
===
match
---
operator: + [28075,28076]
operator: + [28075,28076]
===
match
---
name: default_time [2634,2646]
name: default_time [2634,2646]
===
match
---
operator: , [31213,31214]
operator: , [31213,31214]
===
match
---
param [23773,23777]
param [23773,23777]
===
match
---
string: "reset_dag_runs" [32277,32293]
string: "reset_dag_runs" [32999,33015]
===
match
---
dotted_name [2263,2277]
dotted_name [2263,2277]
===
match
---
number: 200 [7876,7879]
number: 200 [7876,7879]
===
match
---
name: ti [4061,4063]
name: ti [4061,4063]
===
match
---
number: 2 [11698,11699]
number: 2 [11698,11699]
===
match
---
operator: == [32089,32091]
operator: == [32811,32813]
===
match
---
atom_expr [20149,20169]
atom_expr [20149,20169]
===
match
---
operator: + [27351,27352]
operator: + [27351,27352]
===
match
---
operator: { [21119,21120]
operator: { [21119,21120]
===
match
---
dotted_name [22643,22663]
dotted_name [22643,22663]
===
match
---
atom [33753,34960]
atom [34475,35682]
===
match
---
name: self [39327,39331]
name: self [40049,40053]
===
match
---
operator: , [10233,10234]
operator: , [10233,10234]
===
match
---
name: response [43221,43229]
name: response [43943,43951]
===
match
---
string: 'task_id' [34196,34205]
string: 'task_id' [34918,34927]
===
match
---
name: username [1672,1680]
name: username [1672,1680]
===
match
---
operator: @ [15542,15543]
operator: @ [15542,15543]
===
match
---
operator: , [15109,15110]
operator: , [15109,15110]
===
match
---
arith_expr [28994,29035]
arith_expr [28994,29035]
===
match
---
operator: , [19293,19294]
operator: , [19293,19294]
===
match
---
string: "test" [25011,25017]
string: "test" [25011,25017]
===
match
---
simple_stmt [16584,16631]
simple_stmt [16584,16631]
===
match
---
operator: { [32677,32678]
operator: { [33399,33400]
===
match
---
trailer [43036,43205]
trailer [43758,43927]
===
match
---
param [15636,15648]
param [15636,15648]
===
match
---
name: dt [26534,26536]
name: dt [26534,26536]
===
match
---
operator: , [36278,36279]
operator: , [37000,37001]
===
match
---
simple_stmt [21001,21180]
simple_stmt [21001,21180]
===
match
---
atom_expr [35667,36060]
atom_expr [36389,36782]
===
match
---
dictorsetmaker [35787,35823]
dictorsetmaker [36509,36545]
===
match
---
name: days [27913,27917]
name: days [27913,27917]
===
match
---
name: payload [32223,32230]
name: payload [32945,32952]
===
match
---
name: airflow [894,901]
name: airflow [894,901]
===
match
---
operator: , [35993,35994]
operator: , [36715,36716]
===
match
---
trailer [28898,28905]
trailer [28898,28905]
===
match
---
name: State [29683,29688]
name: State [29683,29688]
===
match
---
name: parameterized [853,866]
name: parameterized [853,866]
===
match
---
string: "state" [32918,32925]
string: "state" [33640,33647]
===
match
---
operator: , [34711,34712]
operator: , [35433,35434]
===
match
---
operator: , [17867,17868]
operator: , [17867,17868]
===
match
---
trailer [16187,16209]
trailer [16187,16209]
===
match
---
name: response [38507,38515]
name: response [39229,39237]
===
match
---
operator: } [13171,13172]
operator: } [13171,13172]
===
match
---
arglist [6225,6375]
arglist [6225,6375]
===
match
---
name: test_should_raise_404_not_found_task [41159,41195]
name: test_should_raise_404_not_found_task [41881,41917]
===
match
---
string: "only_failed" [32313,32326]
string: "only_failed" [33035,33048]
===
match
---
name: dt [2583,2585]
name: dt [2583,2585]
===
match
---
string: "test_2" [21561,21569]
string: "test_2" [21561,21569]
===
match
---
name: response [16254,16262]
name: response [16254,16262]
===
match
---
operator: = [1680,1681]
operator: = [1680,1681]
===
match
---
operator: { [33422,33423]
operator: { [34144,34145]
===
match
---
name: dt [10436,10438]
name: dt [10436,10438]
===
match
---
number: 403 [24074,24077]
number: 403 [24074,24077]
===
match
---
name: mock_set_state [37758,37772]
name: mock_set_state [38480,38494]
===
match
---
name: airflow [1175,1182]
name: airflow [1175,1182]
===
match
---
name: State [28716,28721]
name: State [28716,28721]
===
match
---
string: "execution_date" [40207,40223]
string: "execution_date" [40929,40945]
===
match
---
operator: , [21859,21860]
operator: , [21859,21860]
===
match
---
fstring_expr [12488,12512]
fstring_expr [12488,12512]
===
match
---
name: execution_date [7488,7502]
name: execution_date [7488,7502]
===
match
---
dictorsetmaker [6352,6373]
dictorsetmaker [6352,6373]
===
match
---
operator: , [29222,29223]
operator: , [29222,29223]
===
match
---
trailer [30767,30774]
trailer [30767,30774]
===
match
---
operator: , [5587,5588]
operator: , [5587,5588]
===
match
---
number: 400 [25095,25098]
number: 400 [25095,25098]
===
match
---
string: "hostname" [5479,5489]
string: "hostname" [5479,5489]
===
match
---
number: 2 [29329,29330]
number: 2 [29329,29330]
===
match
---
name: permissions [983,994]
name: permissions [983,994]
===
match
---
operator: { [12106,12107]
operator: { [12106,12107]
===
match
---
operator: { [20418,20419]
operator: { [20418,20419]
===
match
---
number: 0 [35171,35172]
number: 0 [35893,35894]
===
match
---
operator: = [33300,33301]
operator: = [34022,34023]
===
match
---
atom [17346,17506]
atom [17346,17506]
===
match
---
operator: { [29185,29186]
operator: { [29185,29186]
===
match
---
suite [4905,5994]
suite [4905,5994]
===
match
---
name: State [18104,18109]
name: State [18104,18109]
===
match
---
string: "execution_date" [42465,42481]
string: "execution_date" [43187,43203]
===
match
---
operator: , [19768,19769]
operator: , [19768,19769]
===
match
---
atom_expr [6444,6457]
atom_expr [6444,6457]
===
match
---
operator: = [39056,39057]
operator: = [39778,39779]
===
match
---
atom_expr [35579,35599]
atom_expr [36301,36321]
===
match
---
fstring_string: TEST_DAG_RUN_ID_ [4239,4255]
fstring_string: TEST_DAG_RUN_ID_ [4239,4255]
===
match
---
string: "start_date" [5801,5813]
string: "start_date" [5801,5813]
===
match
---
string: "execution_date" [30560,30576]
string: "execution_date" [30560,30576]
===
match
---
string: "/api/v1/dags/~/dagRuns/~/taskInstances?end_date_gte" [12373,12426]
string: "/api/v1/dags/~/dagRuns/~/taskInstances?end_date_gte" [12373,12426]
===
match
---
param [22942,22947]
param [22942,22947]
===
match
---
trailer [4800,4802]
trailer [4800,4802]
===
match
---
atom [42354,42746]
atom [43076,43468]
===
match
---
operator: , [6319,6320]
operator: , [6319,6320]
===
match
---
atom_expr [29015,29035]
atom_expr [29015,29035]
===
match
---
name: response [23420,23428]
name: response [23420,23428]
===
match
---
name: days [25725,25729]
name: days [25725,25729]
===
match
---
string: "only_failed" [25999,26012]
string: "only_failed" [25999,26012]
===
match
---
name: request_dag [31481,31492]
name: request_dag [32203,32214]
===
match
---
atom_expr [19425,19445]
atom_expr [19425,19445]
===
match
---
name: self [4890,4894]
name: self [4890,4894]
===
match
---
string: "{}" [8140,8144]
string: "{}" [8140,8144]
===
match
---
atom [21629,21657]
atom [21629,21657]
===
match
---
string: "execution_date" [32841,32857]
string: "execution_date" [33563,33579]
===
match
---
operator: = [1706,1707]
operator: = [1706,1707]
===
match
---
atom_expr [41764,41784]
atom_expr [42486,42506]
===
match
---
operator: = [10532,10533]
operator: = [10532,10533]
===
match
---
number: 3 [13362,13363]
number: 3 [13362,13363]
===
match
---
operator: = [2083,2084]
operator: = [2083,2084]
===
match
---
operator: , [15505,15506]
operator: , [15505,15506]
===
match
---
atom [36336,36414]
atom [37058,37136]
===
match
---
name: session [20847,20854]
name: session [20847,20854]
===
match
---
operator: { [26469,26470]
operator: { [26469,26470]
===
match
---
param [24815,24822]
param [24815,24822]
===
match
---
trailer [25127,25137]
trailer [25127,25137]
===
match
---
import_name [834,847]
import_name [834,847]
===
match
---
name: self [33377,33381]
name: self [34099,34103]
===
match
---
string: "start_date_lte" [19690,19706]
string: "start_date_lte" [19690,19706]
===
match
---
operator: , [28430,28431]
operator: , [28430,28431]
===
match
---
atom [31933,31956]
atom [32655,32678]
===
match
---
name: QUEUED [18156,18162]
name: QUEUED [18156,18162]
===
match
---
string: "execution_date" [36681,36697]
string: "execution_date" [37403,37419]
===
match
---
operator: } [38064,38065]
operator: } [38786,38787]
===
match
---
operator: = [33189,33190]
operator: = [33911,33912]
===
match
---
operator: = [30724,30725]
operator: = [30724,30725]
===
match
---
funcdef [42869,43300]
funcdef [43591,44022]
===
match
---
trailer [1761,1777]
trailer [1761,1777]
===
match
---
if_stmt [3578,3665]
if_stmt [3578,3665]
===
match
---
operator: , [22008,22009]
operator: , [22008,22009]
===
match
---
atom_expr [3938,3981]
atom_expr [3938,3981]
===
match
---
argument [35348,35559]
argument [36070,36281]
===
match
---
name: RUNNING [27080,27087]
name: RUNNING [27080,27087]
===
match
---
name: dt [33026,33028]
name: dt [33748,33750]
===
match
---
string: "dag_ids" [23964,23973]
string: "dag_ids" [23964,23973]
===
match
---
operator: = [4629,4630]
operator: = [4629,4630]
===
match
---
string: "dry_run" [40126,40135]
string: "dry_run" [40848,40857]
===
match
---
name: sync_to_db [3044,3054]
name: sync_to_db [3044,3054]
===
match
---
comparison [38464,38491]
comparison [39186,39213]
===
match
---
operator: , [13230,13231]
operator: , [13230,13231]
===
match
---
string: "task_instances" [23371,23387]
string: "task_instances" [23371,23387]
===
match
---
testlist_comp [23976,24021]
testlist_comp [23976,24021]
===
match
---
fstring [31853,31901]
fstring [32575,32623]
===
match
---
name: timedelta [19986,19995]
name: timedelta [19986,19995]
===
match
---
operator: { [36429,36430]
operator: { [37151,37152]
===
match
---
string: "example_skip_dag" [23088,23106]
string: "example_skip_dag" [23088,23106]
===
match
---
operator: { [40742,40743]
operator: { [41464,41465]
===
match
---
atom [22673,22866]
atom [22673,22866]
===
match
---
string: "execution_date_lte" [20502,20522]
string: "execution_date_lte" [20502,20522]
===
match
---
name: timezone [1145,1153]
name: timezone [1145,1153]
===
match
---
operator: , [1402,1403]
operator: , [1402,1403]
===
match
---
atom [24223,24269]
atom [24223,24269]
===
match
---
trailer [21344,21377]
trailer [21344,21377]
===
match
---
atom_expr [27353,27373]
atom_expr [27353,27373]
===
match
---
atom_expr [26589,26601]
atom_expr [26589,26601]
===
match
---
operator: + [29803,29804]
operator: + [29803,29804]
===
match
---
simple_stmt [2961,2981]
simple_stmt [2961,2981]
===
match
---
operator: , [21142,21143]
operator: , [21142,21143]
===
match
---
name: self [21811,21815]
name: self [21811,21815]
===
match
---
arglist [35277,35560]
arglist [35999,36282]
===
match
---
operator: , [27584,27585]
operator: , [27584,27585]
===
match
---
operator: = [18902,18903]
operator: = [18902,18903]
===
match
---
dictorsetmaker [13516,13537]
dictorsetmaker [13516,13537]
===
match
---
expr_stmt [37758,37897]
expr_stmt [38480,38619]
===
match
---
name: State [32503,32508]
name: State [33225,33230]
===
match
---
operator: , [5465,5466]
operator: , [5465,5466]
===
match
---
operator: , [25625,25626]
operator: , [25625,25626]
===
match
---
simple_stmt [21188,21238]
simple_stmt [21188,21238]
===
match
---
operator: { [34011,34012]
operator: { [34733,34734]
===
match
---
argument [31705,31725]
argument [32427,32447]
===
match
---
fstring_end: " [10796,10797]
fstring_end: " [10796,10797]
===
match
---
operator: = [28094,28095]
operator: = [28094,28095]
===
match
---
operator: } [13995,13996]
operator: } [13995,13996]
===
match
---
atom [24509,24561]
atom [24509,24561]
===
match
---
string: 'TEST_DAG_RUN_ID_3' [34572,34591]
string: 'TEST_DAG_RUN_ID_3' [35294,35313]
===
match
---
name: self [43020,43024]
name: self [43742,43746]
===
match
---
name: client [9103,9109]
name: client [9103,9109]
===
match
---
name: dt [19983,19985]
name: dt [19983,19985]
===
match
---
atom_expr [18195,18208]
atom_expr [18195,18208]
===
match
---
atom [13116,13133]
atom [13116,13133]
===
match
---
simple_stmt [22572,22637]
simple_stmt [22572,22637]
===
match
---
testlist_comp [9766,9971]
testlist_comp [9766,9971]
===
match
---
string: 'sleep_for_1' [34445,34458]
string: 'sleep_for_1' [35167,35180]
===
match
---
atom [26085,26891]
atom [26085,26891]
===
match
---
name: environ_overrides [17070,17087]
name: environ_overrides [17070,17087]
===
match
---
atom_expr [1750,1777]
atom_expr [1750,1777]
===
match
---
name: provide_session [22879,22894]
name: provide_session [22879,22894]
===
match
---
operator: , [42111,42112]
operator: , [42833,42834]
===
match
---
name: session [24815,24822]
name: session [24815,24822]
===
match
---
operator: , [28230,28231]
operator: , [28230,28231]
===
match
---
operator: = [29645,29646]
operator: = [29645,29646]
===
match
---
number: 1 [8330,8331]
number: 1 [8330,8331]
===
match
---
trailer [16510,16517]
trailer [16510,16517]
===
match
---
string: "test_no_permissions" [2084,2105]
string: "test_no_permissions" [2084,2105]
===
match
---
operator: , [3345,3346]
operator: , [3345,3346]
===
match
---
assert_stmt [16432,16466]
assert_stmt [16432,16466]
===
match
---
atom [22378,22401]
atom [22378,22401]
===
match
---
operator: , [30179,30180]
operator: , [30179,30180]
===
match
---
name: post [35259,35263]
name: post [35981,35985]
===
match
---
name: DEFAULT_DATETIME_1 [10359,10377]
name: DEFAULT_DATETIME_1 [10359,10377]
===
match
---
operator: , [26876,26877]
operator: , [26876,26877]
===
match
---
atom_expr [2891,2913]
atom_expr [2891,2913]
===
match
---
operator: = [9096,9097]
operator: = [9096,9097]
===
match
---
name: MANUAL [4368,4374]
name: MANUAL [4368,4374]
===
match
---
operator: , [9804,9805]
operator: , [9804,9805]
===
match
---
operator: @ [37551,37552]
operator: @ [38273,38274]
===
match
---
name: permissions [1819,1830]
name: permissions [1819,1830]
===
match
---
operator: , [11065,11066]
operator: , [11065,11066]
===
match
---
dictorsetmaker [14019,14040]
dictorsetmaker [14019,14040]
===
match
---
string: "test" [43161,43167]
string: "test" [43883,43889]
===
match
---
operator: = [35842,35843]
operator: = [36564,36565]
===
match
---
atom [13447,13603]
atom [13447,13603]
===
match
---
name: json [40103,40107]
name: json [40825,40829]
===
match
---
string: "test" [41363,41369]
string: "test" [42085,42091]
===
match
---
assert_stmt [23303,23337]
assert_stmt [23303,23337]
===
match
---
name: response [4958,4966]
name: response [4958,4966]
===
match
---
string: "print_the_context" [38146,38165]
string: "print_the_context" [38868,38887]
===
match
---
operator: { [41389,41390]
operator: { [42111,42112]
===
match
---
operator: } [36048,36049]
operator: } [36770,36771]
===
match
---
atom [12024,12565]
atom [12024,12565]
===
match
---
trailer [21016,21023]
trailer [21016,21023]
===
match
---
operator: , [22427,22428]
operator: , [22427,22428]
===
match
---
string: "execution_date" [25673,25689]
string: "execution_date" [25673,25689]
===
match
---
testlist_comp [19269,19769]
testlist_comp [19269,19769]
===
match
---
simple_stmt [4958,5159]
simple_stmt [4958,5159]
===
match
---
operator: , [39186,39187]
operator: , [39908,39909]
===
match
---
name: client [41227,41233]
name: client [41949,41955]
===
match
---
argument [11616,11622]
argument [11616,11622]
===
match
---
operator: , [22197,22198]
operator: , [22197,22198]
===
match
---
classdef [4805,9575]
classdef [4805,9575]
===
match
---
operator: { [28012,28013]
operator: { [28012,28013]
===
match
---
trailer [23318,23330]
trailer [23318,23330]
===
match
---
dictorsetmaker [34267,34459]
dictorsetmaker [34989,35181]
===
match
---
name: timedelta [26537,26546]
name: timedelta [26537,26546]
===
match
---
name: self [3968,3972]
name: self [3968,3972]
===
match
---
number: 200 [13207,13210]
number: 200 [13207,13210]
===
match
---
operator: , [36464,36465]
operator: , [37186,37187]
===
match
---
simple_stmt [16005,16064]
simple_stmt [16005,16064]
===
match
---
string: 'execution_date' [34609,34625]
string: 'execution_date' [35331,35347]
===
match
---
fstring_expr [31868,31881]
fstring_expr [32590,32603]
===
match
---
dictorsetmaker [2427,2499]
dictorsetmaker [2427,2499]
===
match
---
name: TaskInstance [3938,3950]
name: TaskInstance [3938,3950]
===
match
---
operator: = [20332,20333]
operator: = [20332,20333]
===
match
---
name: pytest [2263,2269]
name: pytest [2263,2269]
===
match
---
name: task_instances [37030,37044]
name: task_instances [37752,37766]
===
match
---
arith_expr [27332,27373]
arith_expr [27332,27373]
===
match
---
operator: , [42322,42323]
operator: , [43044,43045]
===
match
---
name: self [20700,20704]
name: self [20700,20704]
===
match
---
name: tests [1304,1309]
name: tests [1304,1309]
===
match
---
name: task_dict [38959,38968]
name: task_dict [39681,39690]
===
match
---
operator: { [36337,36338]
operator: { [37059,37060]
===
match
---
string: "execution_date" [26495,26511]
string: "execution_date" [26495,26511]
===
match
---
name: test_utils [1310,1320]
name: test_utils [1310,1320]
===
match
---
string: "state" [26403,26410]
string: "state" [26403,26410]
===
match
---
string: 'example_python_operator' [38606,38631]
string: 'example_python_operator' [39328,39353]
===
match
---
operator: , [32333,32334]
operator: , [33055,33056]
===
match
---
atom [36154,36230]
atom [36876,36952]
===
match
---
trailer [23143,23294]
trailer [23143,23294]
===
match
---
operator: , [13493,13494]
operator: , [13493,13494]
===
match
---
string: 'dag_run_id' [34558,34570]
string: 'dag_run_id' [35280,35292]
===
match
---
atom_expr [2000,2034]
atom_expr [2000,2034]
===
match
---
name: single_dag_run [4121,4135]
name: single_dag_run [4121,4135]
===
match
---
name: timedelta [12197,12206]
name: timedelta [12197,12206]
===
match
---
operator: @ [2262,2263]
operator: @ [2262,2263]
===
match
---
operator: == [7873,7875]
operator: == [7873,7875]
===
match
---
dictorsetmaker [27314,27421]
dictorsetmaker [27314,27421]
===
match
---
operator: , [1399,1400]
operator: , [1399,1400]
===
match
---
simple_stmt [889,954]
simple_stmt [889,954]
===
match
---
argument [37058,37077]
argument [37780,37799]
===
match
---
operator: = [2285,2286]
operator: = [2285,2286]
===
match
---
operator: , [12754,12755]
operator: , [12754,12755]
===
match
---
operator: , [22866,22867]
operator: , [22866,22867]
===
match
---
trailer [6145,6153]
trailer [6145,6153]
===
match
---
name: State [13525,13530]
name: State [13525,13530]
===
match
---
atom [24128,24208]
atom [24128,24208]
===
match
---
import_from [1213,1298]
import_from [1213,1298]
===
match
---
name: timedelta [20318,20327]
name: timedelta [20318,20327]
===
match
---
argument [30720,30726]
argument [30720,30726]
===
match
---
operator: = [1430,1431]
operator: = [1430,1431]
===
match
---
atom [29563,29718]
atom [29563,29718]
===
match
---
string: "print_the_context" [37861,37880]
string: "print_the_context" [38583,38602]
===
match
---
trailer [39942,40472]
trailer [40664,41194]
===
match
---
operator: , [21818,21819]
operator: , [21818,21819]
===
match
---
operator: , [37111,37112]
operator: , [37833,37834]
===
match
---
simple_stmt [7611,7628]
simple_stmt [7611,7628]
===
match
---
atom [19883,19921]
atom [19883,19921]
===
match
---
atom [32531,32663]
atom [33253,33385]
===
match
---
simple_stmt [37758,37898]
simple_stmt [38480,38620]
===
match
---
string: "execution_date" [27027,27043]
string: "execution_date" [27027,27043]
===
match
---
name: task_instances [37015,37029]
name: task_instances [37737,37751]
===
match
---
operator: = [22140,22141]
operator: = [22140,22141]
===
match
---
trailer [7658,7662]
trailer [7658,7662]
===
match
---
atom_expr [2485,2498]
atom_expr [2485,2498]
===
match
---
name: dag_bag [37140,37147]
name: dag_bag [37862,37869]
===
match
---
operator: , [10378,10379]
operator: , [10378,10379]
===
match
---
operator: , [20895,20896]
operator: , [20895,20896]
===
match
---
testlist_comp [36429,36509]
testlist_comp [37151,37231]
===
match
---
name: RUNNING [36734,36741]
name: RUNNING [37456,37463]
===
match
---
name: json [16609,16613]
name: json [16609,16613]
===
match
---
operator: { [20192,20193]
operator: { [20192,20193]
===
match
---
operator: = [41388,41389]
operator: = [42110,42111]
===
match
---
name: app [2848,2851]
name: app [2848,2851]
===
match
---
name: provide_session [1072,1087]
name: provide_session [1072,1087]
===
match
---
trailer [35251,35258]
trailer [35973,35980]
===
match
---
operator: = [37207,37208]
operator: = [37929,37930]
===
match
---
operator: , [34949,34950]
operator: , [35671,35672]
===
match
---
fstring_string: /api/v1/dags/ [31855,31868]
fstring_string: /api/v1/dags/ [32577,32590]
===
match
---
string: "description" [8533,8546]
string: "description" [8533,8546]
===
match
---
simple_stmt [35085,35134]
simple_stmt [35807,35856]
===
match
---
dictorsetmaker [26210,26269]
dictorsetmaker [26210,26269]
===
match
---
operator: = [30901,30902]
operator: = [30901,30902]
===
match
---
trailer [2490,2498]
trailer [2490,2498]
===
match
---
param [15616,15630]
param [15616,15630]
===
match
---
funcdef [22899,23463]
funcdef [22899,23463]
===
match
---
operator: , [3017,3018]
operator: , [3017,3018]
===
match
---
name: dag [3481,3484]
name: dag [3481,3484]
===
match
---
operator: { [12160,12161]
operator: { [12160,12161]
===
match
---
string: "test_pool_3" [17834,17847]
string: "test_pool_3" [17834,17847]
===
match
---
trailer [23721,23731]
trailer [23721,23731]
===
match
---
operator: { [18851,18852]
operator: { [18851,18852]
===
match
---
string: "new_state" [41059,41070]
string: "new_state" [41781,41792]
===
match
---
number: 150 [12711,12714]
number: 150 [12711,12714]
===
match
---
trailer [15671,15693]
trailer [15671,15693]
===
match
---
trailer [23138,23143]
trailer [23138,23143]
===
match
---
string: "queue" [17463,17470]
string: "queue" [17463,17470]
===
match
---
suite [3608,3665]
suite [3608,3665]
===
match
---
name: timedelta [11126,11135]
name: timedelta [11126,11135]
===
match
---
operator: , [2189,2190]
operator: , [2189,2190]
===
match
---
trailer [4918,4940]
trailer [4918,4940]
===
match
---
name: scope [1531,1536]
name: scope [1531,1536]
===
match
---
number: 1 [20001,20002]
number: 1 [20001,20002]
===
match
---
name: environ_overrides [6333,6350]
name: environ_overrides [6333,6350]
===
match
---
operator: { [32233,32234]
operator: { [32955,32956]
===
match
---
string: "execution_date" [20110,20126]
string: "execution_date" [20110,20126]
===
match
---
simple_stmt [4786,4803]
simple_stmt [4786,4803]
===
match
---
operator: , [29517,29518]
operator: , [29517,29518]
===
match
---
testlist_comp [13870,14288]
testlist_comp [13870,14288]
===
match
---
atom_expr [22454,22474]
atom_expr [22454,22474]
===
match
---
param [22960,22972]
param [22960,22972]
===
match
---
operator: , [23874,23875]
operator: , [23874,23875]
===
match
---
atom_expr [25071,25091]
atom_expr [25071,25091]
===
match
---
operator: , [5147,5148]
operator: , [5147,5148]
===
match
---
operator: { [17568,17569]
operator: { [17568,17569]
===
match
---
argument [21156,21168]
argument [21156,21168]
===
match
---
atom [19389,19446]
atom [19389,19446]
===
match
---
number: 200 [23334,23337]
number: 200 [23334,23337]
===
match
---
name: permissions [1750,1761]
name: permissions [1750,1761]
===
match
---
operator: = [3102,3103]
operator: = [3102,3103]
===
match
---
operator: , [28905,28906]
operator: , [28905,28906]
===
match
---
operator: = [23630,23631]
operator: = [23630,23631]
===
match
---
name: getuser [5973,5980]
name: getuser [5973,5980]
===
match
---
operator: + [27898,27899]
operator: + [27898,27899]
===
match
---
string: "start_date" [8831,8843]
string: "start_date" [8831,8843]
===
match
---
operator: , [9520,9521]
operator: , [9520,9521]
===
match
---
operator: } [14416,14417]
operator: } [14416,14417]
===
match
---
name: self [7277,7281]
name: self [7277,7281]
===
match
---
atom_expr [28132,28145]
atom_expr [28132,28145]
===
match
---
atom_expr [35045,35076]
atom_expr [35767,35798]
===
match
---
operator: , [31492,31493]
operator: , [32214,32215]
===
match
---
name: State [18150,18155]
name: State [18150,18155]
===
match
---
argument [12207,12213]
argument [12207,12213]
===
match
---
operator: = [7801,7802]
operator: = [7801,7802]
===
match
---
string: "state" [29851,29858]
string: "state" [29851,29858]
===
match
---
arith_expr [9845,9886]
arith_expr [9845,9886]
===
match
---
string: "{'start_date': ['Not a valid datetime.']}" [36466,36509]
string: "{'start_date': ['Not a valid datetime.']}" [37188,37231]
===
match
---
atom [12813,12986]
atom [12813,12986]
===
match
---
testlist_comp [1749,2036]
testlist_comp [1749,2036]
===
match
---
string: "test_queue_1" [17579,17593]
string: "test_queue_1" [17579,17593]
===
match
---
string: "queue" [17569,17576]
string: "queue" [17569,17576]
===
match
---
argument [41384,41737]
argument [42106,42459]
===
match
---
operator: { [13515,13516]
operator: { [13515,13516]
===
match
---
name: url [15631,15634]
name: url [15631,15634]
===
match
---
comparison [43264,43299]
comparison [43986,44021]
===
match
---
string: "REMOTE_USER" [16389,16402]
string: "REMOTE_USER" [16389,16402]
===
match
---
simple_stmt [3399,3472]
simple_stmt [3399,3472]
===
match
---
name: json [21156,21160]
name: json [21156,21160]
===
match
---
name: dt [30707,30709]
name: dt [30707,30709]
===
match
---
funcdef [16697,16898]
funcdef [16697,16898]
===
match
---
dictorsetmaker [15331,15354]
dictorsetmaker [15331,15354]
===
match
---
string: "include_downstream" [38279,38299]
string: "include_downstream" [39001,39021]
===
match
---
operator: = [3955,3956]
operator: = [3955,3956]
===
match
---
decorator [2262,2292]
decorator [2262,2292]
===
match
---
name: TestGetTaskInstance [4811,4830]
name: TestGetTaskInstance [4811,4830]
===
match
---
suite [4500,4778]
suite [4500,4778]
===
match
---
operator: , [26857,26858]
operator: , [26857,26858]
===
match
---
string: "example_subdag_operator" [29415,29440]
string: "example_subdag_operator" [29415,29440]
===
match
---
operator: , [23257,23258]
operator: , [23257,23258]
===
match
---
name: single_dag_run [33210,33224]
name: single_dag_run [33932,33946]
===
match
---
name: utils [1051,1056]
name: utils [1051,1056]
===
match
---
atom [18490,18507]
atom [18490,18507]
===
match
---
number: 15 [22838,22840]
number: 15 [22838,22840]
===
match
---
operator: @ [42848,42849]
operator: @ [43570,43571]
===
match
---
argument [16219,16244]
argument [16219,16244]
===
match
---
operator: } [20003,20004]
operator: } [20003,20004]
===
match
---
trailer [35114,35132]
trailer [35836,35854]
===
match
---
trailer [33591,33597]
trailer [34313,34319]
===
match
---
atom_expr [23420,23450]
atom_expr [23420,23450]
===
match
---
string: "test_pool_3" [14027,14040]
string: "test_pool_3" [14027,14040]
===
match
---
name: filter [33606,33612]
name: filter [34328,34334]
===
match
---
operator: , [29105,29106]
operator: , [29105,29106]
===
match
---
operator: } [30973,30974]
operator: } [30973,30974]
===
match
---
name: post [31835,31839]
name: post [32557,32561]
===
match
---
operator: , [12292,12293]
operator: , [12292,12293]
===
match
---
operator: { [18928,18929]
operator: { [18928,18929]
===
match
---
argument [3086,3107]
argument [3086,3107]
===
match
---
atom_expr [28077,28097]
atom_expr [28077,28097]
===
match
---
operator: , [8242,8243]
operator: , [8242,8243]
===
match
---
string: "print_the_context" [5899,5918]
string: "print_the_context" [5899,5918]
===
match
---
simple_stmt [43009,43206]
simple_stmt [43731,43928]
===
match
---
operator: , [17593,17594]
operator: , [17593,17594]
===
match
---
dictorsetmaker [11009,11064]
dictorsetmaker [11009,11064]
===
match
---
operator: { [30339,30340]
operator: { [30339,30340]
===
match
---
decorator [20642,20659]
decorator [20642,20659]
===
match
---
string: "api/v1/dags/example_python_operator/dagRuns/TEST_DAG_RUN_ID/taskInstances/print_the_context" [9357,9450]
string: "api/v1/dags/example_python_operator/dagRuns/TEST_DAG_RUN_ID/taskInstances/print_the_context" [9357,9450]
===
match
---
string: 'REMOTE_USER' [38043,38056]
string: 'REMOTE_USER' [38765,38778]
===
match
---
name: self [6196,6200]
name: self [6196,6200]
===
match
---
operator: , [18209,18210]
operator: , [18209,18210]
===
match
---
name: State [26589,26594]
name: State [26589,26594]
===
match
---
testlist_comp [27026,27444]
testlist_comp [27026,27444]
===
match
---
operator: , [21834,21835]
operator: , [21834,21835]
===
match
---
atom [5234,5993]
atom [5234,5993]
===
match
---
string: "duration" [18491,18501]
string: "duration" [18491,18501]
===
match
---
string: "sleep_for_1" [29278,29291]
string: "sleep_for_1" [29278,29291]
===
match
---
string: "state" [30930,30937]
string: "state" [30930,30937]
===
match
---
atom [11515,11547]
atom [11515,11547]
===
match
---
atom_expr [36908,37122]
atom_expr [37630,37844]
===
match
---
trailer [36934,37122]
trailer [37656,37844]
===
match
---
if_stmt [4118,4473]
if_stmt [4118,4473]
===
match
---
trailer [30944,30951]
trailer [30944,30951]
===
match
---
name: DagBag [3079,3085]
name: DagBag [3079,3085]
===
match
---
operator: , [6850,6851]
operator: , [6850,6851]
===
match
---
testlist_comp [28411,29331]
testlist_comp [28411,29331]
===
match
---
operator: { [18185,18186]
operator: { [18185,18186]
===
match
---
name: test_should_respond_200_task_instance_with_sla [7230,7276]
name: test_should_respond_200_task_instance_with_sla [7230,7276]
===
match
---
param [32162,32169]
param [32884,32891]
===
match
---
trailer [31753,31761]
trailer [32475,32483]
===
match
---
atom_expr [16600,16630]
atom_expr [16600,16630]
===
match
---
operator: } [14040,14041]
operator: } [14040,14041]
===
match
---
atom [30559,30620]
atom [30559,30620]
===
match
---
operator: , [16356,16357]
operator: , [16356,16357]
===
match
---
atom_expr [43264,43287]
atom_expr [43986,44009]
===
match
---
name: client [22276,22282]
name: client [22276,22282]
===
match
---
atom_expr [9866,9886]
atom_expr [9866,9886]
===
match
---
trailer [9113,9231]
trailer [9113,9231]
===
match
---
operator: , [34353,34354]
operator: , [35075,35076]
===
match
---
atom [38574,38822]
atom [39296,39544]
===
match
---
operator: , [17328,17329]
operator: , [17328,17329]
===
match
---
string: "failed" [33629,33637]
string: "failed" [34351,34359]
===
match
---
name: DEFAULT_DATETIME_1 [18941,18959]
name: DEFAULT_DATETIME_1 [18941,18959]
===
match
---
operator: , [30951,30952]
operator: , [30951,30952]
===
match
---
operator: == [33701,33703]
operator: == [34423,34425]
===
match
---
operator: } [24364,24365]
operator: } [24364,24365]
===
match
---
name: task_instances [3829,3843]
name: task_instances [3829,3843]
===
match
---
operator: = [7378,7379]
operator: = [7378,7379]
===
match
---
testlist_comp [42354,42812]
testlist_comp [43076,43534]
===
match
---
comparison [6401,6428]
comparison [6401,6428]
===
match
---
trailer [30042,30049]
trailer [30042,30049]
===
match
---
trailer [25537,25547]
trailer [25537,25547]
===
match
---
assert_stmt [21188,21237]
assert_stmt [21188,21237]
===
match
---
number: 200 [6425,6428]
number: 200 [6425,6428]
===
match
---
testlist_comp [36245,36321]
testlist_comp [36967,37043]
===
match
---
name: timedelta [30710,30719]
name: timedelta [30710,30719]
===
match
---
name: create_user [1622,1633]
name: create_user [1622,1633]
===
match
---
argument [20162,20168]
argument [20162,20168]
===
match
---
trailer [12206,12214]
trailer [12206,12214]
===
match
---
name: task_instances [15784,15798]
name: task_instances [15784,15798]
===
match
---
name: DEFAULT_DATETIME_1 [18864,18882]
name: DEFAULT_DATETIME_1 [18864,18882]
===
match
---
simple_stmt [6078,6177]
simple_stmt [6078,6177]
===
match
---
trailer [29688,29695]
trailer [29688,29695]
===
match
---
arith_expr [28817,28858]
arith_expr [28817,28858]
===
match
---
atom [24609,24661]
atom [24609,24661]
===
match
---
operator: == [22597,22599]
operator: == [22597,22599]
===
match
---
operator: , [8436,8437]
operator: , [8436,8437]
===
match
---
string: "execution_date" [8607,8623]
string: "execution_date" [8607,8623]
===
match
---
atom [10952,10986]
atom [10952,10986]
===
match
---
trailer [28137,28145]
trailer [28137,28145]
===
match
---
operator: , [39686,39687]
operator: , [40408,40409]
===
match
---
string: "execution_date" [41483,41499]
string: "execution_date" [42205,42221]
===
match
---
string: "/api/v1/dags/example_python_operator/updateTaskInstancesState" [41252,41315]
string: "/api/v1/dags/example_python_operator/updateTaskInstancesState" [41974,42037]
===
match
---
funcdef [16903,17181]
funcdef [16903,17181]
===
match
---
atom_expr [11680,11700]
atom_expr [11680,11700]
===
match
---
operator: , [26018,26019]
operator: , [26018,26019]
===
match
---
string: "PythonOperator" [5547,5563]
string: "PythonOperator" [5547,5563]
===
match
---
atom [20524,20567]
atom [20524,20567]
===
match
---
operator: , [21850,21851]
operator: , [21850,21851]
===
match
---
string: "test" [40716,40722]
string: "test" [41438,41444]
===
match
---
atom_expr [29628,29648]
atom_expr [29628,29648]
===
match
---
operator: { [24223,24224]
operator: { [24223,24224]
===
match
---
atom [18451,18468]
atom [18451,18468]
===
match
---
name: json [23271,23275]
name: json [23271,23275]
===
match
---
operator: , [10012,10013]
operator: , [10012,10013]
===
match
---
name: days [27366,27370]
name: days [27366,27370]
===
match
---
operator: = [4548,4549]
operator: = [4548,4549]
===
match
---
operator: , [31463,31464]
operator: , [32185,32186]
===
match
---
operator: , [11624,11625]
operator: , [11624,11625]
===
match
---
comparison [21195,21222]
comparison [21195,21222]
===
match
---
string: "include_past" [41663,41677]
string: "include_past" [42385,42399]
===
match
---
operator: } [29310,29311]
operator: } [29310,29311]
===
match
---
comparison [35092,35133]
comparison [35814,35855]
===
match
---
operator: , [41561,41562]
operator: , [42283,42284]
===
match
---
atom [27752,27813]
atom [27752,27813]
===
match
---
trailer [1790,1803]
trailer [1790,1803]
===
match
---
string: "task_instances" [16030,16046]
string: "task_instances" [16030,16046]
===
match
---
param [42947,42954]
param [43669,43676]
===
match
---
dictorsetmaker [30340,30382]
dictorsetmaker [30340,30382]
===
match
---
atom [13034,13378]
atom [13034,13378]
===
match
---
arith_expr [30863,30904]
arith_expr [30863,30904]
===
match
---
operator: == [22530,22532]
operator: == [22530,22532]
===
match
---
string: 'TEST_DAG_RUN_ID_4' [34810,34829]
string: 'TEST_DAG_RUN_ID_4' [35532,35551]
===
match
---
string: 'REMOTE_USER' [43146,43159]
string: 'REMOTE_USER' [43868,43881]
===
match
---
simple_stmt [38500,38847]
simple_stmt [39222,39569]
===
match
---
name: status_code [36085,36096]
name: status_code [36807,36818]
===
match
---
operator: , [6374,6375]
operator: , [6374,6375]
===
match
---
simple_stmt [6394,6429]
simple_stmt [6394,6429]
===
match
---
name: session [15707,15714]
name: session [15707,15714]
===
match
---
trailer [43277,43287]
trailer [43999,44009]
===
match
---
atom [23643,23690]
atom [23643,23690]
===
match
---
name: TestPostSetTaskInstanceState [37491,37519]
name: TestPostSetTaskInstanceState [38213,38241]
===
match
---
name: DagBag [916,922]
name: DagBag [916,922]
===
match
---
dictorsetmaker [26495,26602]
dictorsetmaker [26495,26602]
===
match
---
simple_stmt [39342,39830]
simple_stmt [40064,40552]
===
match
---
operator: , [28858,28859]
operator: , [28858,28859]
===
match
---
operator: = [31974,31975]
operator: = [32696,32697]
===
match
---
atom [13194,13211]
atom [13194,13211]
===
match
---
name: mock [828,832]
name: mock [828,832]
===
match
---
name: status_code [43230,43241]
name: status_code [43952,43963]
===
match
---
name: timedelta [12274,12283]
name: timedelta [12274,12283]
===
match
---
string: "test_pool_1" [13937,13950]
string: "test_pool_1" [13937,13950]
===
match
---
string: "default_pool" [6836,6850]
string: "default_pool" [6836,6850]
===
match
---
trailer [36733,36741]
trailer [37455,37463]
===
match
---
number: 100 [2690,2693]
number: 100 [2690,2693]
===
match
---
param [15597,15599]
param [15597,15599]
===
match
---
dictorsetmaker [22379,22400]
dictorsetmaker [22379,22400]
===
match
---
string: "pid" [8256,8261]
string: "pid" [8256,8261]
===
match
---
atom [20026,20087]
atom [20026,20087]
===
match
---
param [20765,20783]
param [20765,20783]
===
match
---
trailer [37135,37139]
trailer [37857,37861]
===
match
---
dotted_name [1516,1530]
dotted_name [1516,1530]
===
match
---
string: "test_pool_2" [17789,17802]
string: "test_pool_2" [17789,17802]
===
match
---
parameters [16114,16129]
parameters [16114,16129]
===
match
---
name: provide_session [20643,20658]
name: provide_session [20643,20658]
===
match
---
name: self [7544,7548]
name: self [7544,7548]
===
match
---
name: FAILED [28567,28573]
name: FAILED [28567,28573]
===
match
---
name: run_type [4348,4356]
name: run_type [4348,4356]
===
match
---
trailer [7507,7520]
trailer [7507,7520]
===
match
---
name: create_task_instances [16144,16165]
name: create_task_instances [16144,16165]
===
match
---
string: '2020-01-01T00:00:00+00:00' [33907,33934]
string: '2020-01-01T00:00:00+00:00' [34629,34656]
===
match
---
string: 'dag_id' [34743,34751]
string: 'dag_id' [35465,35473]
===
match
---
atom_expr [23799,24034]
atom_expr [23799,24034]
===
match
---
trailer [15833,15840]
trailer [15833,15840]
===
match
---
argument [11693,11699]
argument [11693,11699]
===
match
---
string: "failed" [42719,42727]
string: "failed" [43441,43449]
===
match
---
string: "include_future" [40347,40363]
string: "include_future" [41069,41085]
===
match
---
trailer [38968,38989]
trailer [39690,39711]
===
match
---
parameters [21801,21893]
parameters [21801,21893]
===
match
---
suite [25211,37483]
suite [25211,38205]
===
match
---
operator: , [27669,27670]
operator: , [27669,27670]
===
match
---
trailer [29984,29994]
trailer [29984,29994]
===
match
---
operator: , [18273,18274]
operator: , [18273,18274]
===
match
---
operator: , [7561,7562]
operator: , [7561,7562]
===
match
---
operator: , [34892,34893]
operator: , [35614,35615]
===
match
---
dictorsetmaker [21120,21141]
dictorsetmaker [21120,21141]
===
match
---
atom [22752,22799]
atom [22752,22799]
===
match
---
string: "include_upstream" [41537,41555]
string: "include_upstream" [42259,42277]
===
match
---
name: self [37674,37678]
name: self [38396,38400]
===
match
---
name: DEFAULT_DATETIME_1 [20462,20480]
name: DEFAULT_DATETIME_1 [20462,20480]
===
match
---
testlist_comp [25279,26057]
testlist_comp [25279,26057]
===
match
---
operator: , [42935,42936]
operator: , [43657,43658]
===
match
---
name: commit [4794,4800]
name: commit [4794,4800]
===
match
---
trailer [23365,23370]
trailer [23365,23370]
===
match
---
name: timedelta [31064,31073]
name: timedelta [31064,31073]
===
match
---
string: "task_instances" [32070,32086]
string: "task_instances" [32792,32808]
===
match
---
name: dag_id [3204,3210]
name: dag_id [3204,3210]
===
match
---
atom [21938,22054]
atom [21938,22054]
===
match
---
arglist [21042,21169]
arglist [21042,21169]
===
match
---
name: timedelta [27178,27187]
name: timedelta [27178,27187]
===
match
---
string: "state" [31107,31114]
string: "state" [31107,31114]
===
match
---
arglist [15707,15799]
arglist [15707,15799]
===
match
---
name: FAILED [29689,29695]
name: FAILED [29689,29695]
===
match
---
atom [10930,11163]
atom [10930,11163]
===
match
---
operator: , [14082,14083]
operator: , [14082,14083]
===
match
---
trailer [29017,29027]
trailer [29017,29027]
===
match
---
string: "include_upstream" [39618,39636]
string: "include_upstream" [40340,40358]
===
match
---
simple_stmt [3523,3541]
simple_stmt [3523,3541]
===
match
---
atom_expr [6140,6153]
atom_expr [6140,6153]
===
match
---
operator: { [6351,6352]
operator: { [6351,6352]
===
match
---
operator: , [18688,18689]
operator: , [18688,18689]
===
match
---
suite [39906,40516]
suite [40628,41238]
===
match
---
parameters [23510,23516]
parameters [23510,23516]
===
match
---
name: dag_id [23081,23087]
name: dag_id [23081,23087]
===
match
---
fstring [4237,4259]
fstring [4237,4259]
===
match
---
name: client [16270,16276]
name: client [16270,16276]
===
match
---
string: "/api/v1/dags/example_python_operator/clearTaskInstances" [37239,37296]
string: "/api/v1/dags/example_python_operator/clearTaskInstances" [37961,38018]
===
match
---
operator: , [13626,13627]
operator: , [13626,13627]
===
match
---
name: days [28674,28678]
name: days [28674,28678]
===
match
---
simple_stmt [4762,4778]
simple_stmt [4762,4778]
===
match
---
simple_stmt [16639,16692]
simple_stmt [16639,16692]
===
match
---
operator: , [5428,5429]
operator: , [5428,5429]
===
match
---
string: "max_tries" [6734,6745]
string: "max_tries" [6734,6745]
===
match
---
trailer [27805,27812]
trailer [27805,27812]
===
match
---
argument [4281,4326]
argument [4281,4326]
===
match
---
operator: { [17825,17826]
operator: { [17825,17826]
===
match
---
name: response [23310,23318]
name: response [23310,23318]
===
match
---
string: '2020-01-04T00:00:00+00:00' [34627,34654]
string: '2020-01-04T00:00:00+00:00' [35349,35376]
===
match
---
atom_expr [4089,4104]
atom_expr [4089,4104]
===
match
---
atom_expr [30159,30179]
atom_expr [30159,30179]
===
match
---
operator: , [19921,19922]
operator: , [19921,19922]
===
match
---
argument [43127,43168]
argument [43849,43890]
===
match
---
operator: , [38684,38685]
operator: , [39406,39407]
===
match
---
atom [6129,6155]
atom [6129,6155]
===
match
---
atom [36756,36888]
atom [37478,37610]
===
match
---
name: permissions [1921,1932]
name: permissions [1921,1932]
===
match
---
name: days [10449,10453]
name: days [10449,10453]
===
match
---
name: self [37714,37718]
name: self [38436,38440]
===
match
---
trailer [1903,1919]
trailer [1903,1919]
===
match
---
param [16939,16943]
param [16939,16943]
===
match
---
string: "include_downstream" [40303,40323]
string: "include_downstream" [41025,41045]
===
match
---
operator: == [16597,16599]
operator: == [16597,16599]
===
match
---
operator: } [10456,10457]
operator: } [10456,10457]
===
match
---
string: 'print_the_context' [33963,33982]
string: 'print_the_context' [34685,34704]
===
match
---
atom_expr [33334,33346]
atom_expr [34056,34068]
===
match
---
operator: , [31268,31269]
operator: , [31268,31269]
===
match
---
name: DagRunType [4357,4367]
name: DagRunType [4357,4367]
===
match
---
name: DEFAULT_DATETIME_1 [28640,28658]
name: DEFAULT_DATETIME_1 [28640,28658]
===
match
---
argument [27188,27194]
argument [27188,27194]
===
match
---
name: create_task_instances [24838,24859]
name: create_task_instances [24838,24859]
===
match
---
trailer [37836,37881]
trailer [38558,38603]
===
match
---
name: count [16568,16573]
name: count [16568,16573]
===
match
---
operator: , [17487,17488]
operator: , [17487,17488]
===
match
---
operator: == [22475,22477]
operator: == [22475,22477]
===
match
---
simple_stmt [33690,33725]
simple_stmt [34412,34447]
===
match
---
string: "pool" [14395,14401]
string: "pool" [14395,14401]
===
match
---
name: DEFAULT_DATETIME_1 [27879,27897]
name: DEFAULT_DATETIME_1 [27879,27897]
===
match
---
operator: , [8552,8553]
operator: , [8552,8553]
===
match
---
string: "example_python_operator" [26144,26169]
string: "example_python_operator" [26144,26169]
===
match
---
string: "include sub dag" [30449,30466]
string: "include sub dag" [30449,30466]
===
match
---
atom [36140,36521]
atom [36862,37243]
===
match
---
number: 200 [38488,38491]
number: 200 [39210,39213]
===
match
---
trailer [6409,6421]
trailer [6409,6421]
===
match
---
operator: , [28168,28169]
operator: , [28168,28169]
===
match
---
atom [25882,26037]
atom [25882,26037]
===
match
---
trailer [26262,26269]
trailer [26262,26269]
===
match
---
operator: , [6058,6059]
operator: , [6058,6059]
===
match
---
string: "execution_date" [38183,38199]
string: "execution_date" [38905,38921]
===
match
---
string: "total_entries" [16614,16629]
string: "total_entries" [16614,16629]
===
match
---
argument [33320,33346]
argument [34042,34068]
===
match
---
operator: , [31901,31902]
operator: , [32623,32624]
===
match
---
simple_stmt [16475,16576]
simple_stmt [16475,16576]
===
match
---
assert_stmt [15944,15996]
assert_stmt [15944,15996]
===
match
---
operator: } [36463,36464]
operator: } [37185,37186]
===
match
---
name: tasks [3535,3540]
name: tasks [3535,3540]
===
match
---
name: update_extras [3776,3789]
name: update_extras [3776,3789]
===
match
---
trailer [20833,20992]
trailer [20833,20992]
===
match
---
operator: , [25044,25045]
operator: , [25044,25045]
===
match
---
operator: , [30466,30467]
operator: , [30466,30467]
===
match
---
atom_expr [10436,10456]
atom_expr [10436,10456]
===
match
---
string: '2020-11-10T12:42:39.442973' [36352,36380]
string: '2020-11-10T12:42:39.442973' [37074,37102]
===
match
---
operator: , [1846,1847]
operator: , [1846,1847]
===
match
---
operator: , [1956,1957]
operator: , [1956,1957]
===
match
---
operator: } [31955,31956]
operator: } [32677,32678]
===
match
---
atom_expr [29070,29082]
atom_expr [29070,29082]
===
match
---
operator: } [34948,34949]
operator: } [35670,35671]
===
match
---
expr_stmt [7636,7836]
expr_stmt [7636,7836]
===
match
---
name: mock_set_state [38998,39012]
name: mock_set_state [39720,39734]
===
match
---
operator: , [4380,4381]
operator: , [4380,4381]
===
match
---
string: "test" [23250,23256]
string: "test" [23250,23256]
===
match
---
trailer [2661,2669]
trailer [2661,2669]
===
match
---
operator: , [17528,17529]
operator: , [17528,17529]
===
match
---
simple_stmt [995,1038]
simple_stmt [995,1038]
===
match
---
name: DEFAULT_DATETIME_1 [29961,29979]
name: DEFAULT_DATETIME_1 [29961,29979]
===
match
---
trailer [16567,16573]
trailer [16567,16573]
===
match
---
number: 4 [30177,30178]
number: 4 [30177,30178]
===
match
---
name: expected_ti [31503,31514]
name: expected_ti [32225,32236]
===
match
---
name: task_instances [3581,3595]
name: task_instances [3581,3595]
===
match
---
number: 200 [32033,32036]
number: 200 [32755,32758]
===
match
---
operator: , [14635,14636]
operator: , [14635,14636]
===
match
---
operator: { [32969,32970]
operator: { [33691,33692]
===
match
---
name: DEFAULT_DATETIME_1 [39582,39600]
name: DEFAULT_DATETIME_1 [40304,40322]
===
match
---
trailer [16969,16976]
trailer [16969,16976]
===
match
---
operator: == [6422,6424]
operator: == [6422,6424]
===
match
---
operator: { [18490,18491]
operator: { [18490,18491]
===
match
---
atom_expr [4786,4802]
atom_expr [4786,4802]
===
match
---
string: "pool" [17781,17787]
string: "pool" [17781,17787]
===
match
---
string: "state" [27065,27072]
string: "state" [27065,27072]
===
match
---
string: "execution_date" [27314,27330]
string: "execution_date" [27314,27330]
===
match
---
name: response [9251,9259]
name: response [9251,9259]
===
match
---
fstring_string: = [11303,11304]
fstring_string: = [11303,11304]
===
match
---
atom_expr [2961,2980]
atom_expr [2961,2980]
===
match
---
operator: , [42598,42599]
operator: , [43320,43321]
===
match
---
operator: , [24494,24495]
operator: , [24494,24495]
===
match
---
trailer [23370,23388]
trailer [23370,23388]
===
match
---
param [15631,15635]
param [15631,15635]
===
match
---
operator: { [34249,34250]
operator: { [34971,34972]
===
match
---
string: "test start date filter with ~" [10881,10912]
string: "test start date filter with ~" [10881,10912]
===
match
---
name: DEFAULT_DATETIME_1 [11528,11546]
name: DEFAULT_DATETIME_1 [11528,11546]
===
match
---
string: "test end date filter" [11453,11475]
string: "test end date filter" [11453,11475]
===
match
---
trailer [37147,37158]
trailer [37869,37880]
===
match
---
trailer [25079,25091]
trailer [25079,25091]
===
match
---
atom [36666,36899]
atom [37388,37621]
===
match
---
name: dt [28077,28079]
name: dt [28077,28079]
===
match
---
param [20740,20755]
param [20740,20755]
===
match
---
trailer [16490,16496]
trailer [16490,16496]
===
match
---
param [2312,2317]
param [2312,2317]
===
match
---
name: single_dag_run [3289,3303]
name: single_dag_run [3289,3303]
===
match
---
dictorsetmaker [30668,30775]
dictorsetmaker [30668,30775]
===
match
---
atom_expr [16483,16575]
atom_expr [16483,16575]
===
match
---
string: '2020-11-10T12:42:39.442973' [24146,24174]
string: '2020-11-10T12:42:39.442973' [24146,24174]
===
match
---
operator: = [27192,27193]
operator: = [27192,27193]
===
match
---
operator: , [38437,38438]
operator: , [39159,39160]
===
match
---
name: self [7647,7651]
name: self [7647,7651]
===
match
---
decorated [21383,22637]
decorated [21383,22637]
===
match
---
trailer [25724,25732]
trailer [25724,25732]
===
match
---
operator: { [20026,20027]
operator: { [20026,20027]
===
match
---
testlist_comp [12042,12551]
testlist_comp [12042,12551]
===
match
---
trailer [12196,12206]
trailer [12196,12206]
===
match
---
atom [32823,32955]
atom [33545,33677]
===
match
---
string: 'print_the_context' [38969,38988]
string: 'print_the_context' [39691,39710]
===
match
---
name: utils [1183,1188]
name: utils [1183,1188]
===
match
---
name: State [18195,18200]
name: State [18195,18200]
===
match
---
operator: = [3936,3937]
operator: = [3936,3937]
===
match
---
atom_expr [33377,33542]
atom_expr [34099,34264]
===
match
---
atom [26209,26270]
atom [26209,26270]
===
match
---
name: days [29995,29999]
name: days [29995,29999]
===
match
---
operator: , [9989,9990]
operator: , [9989,9990]
===
match
---
name: State [6140,6145]
name: State [6140,6145]
===
match
---
trailer [2995,3043]
trailer [2995,3043]
===
match
---
name: security [967,975]
name: security [967,975]
===
match
---
atom [12698,12715]
atom [12698,12715]
===
match
---
string: "test_pool_3" [14493,14506]
string: "test_pool_3" [14493,14506]
===
match
---
expr_stmt [2877,2913]
expr_stmt [2877,2913]
===
match
---
name: self [3807,3811]
name: self [3807,3811]
===
match
---
name: getuser [1030,1037]
name: getuser [1030,1037]
===
match
---
string: "execution_date_lte" [24610,24630]
string: "execution_date_lte" [24610,24630]
===
match
---
param [37696,37703]
param [38418,38425]
===
match
---
string: "dry_run" [27524,27533]
string: "dry_run" [27524,27533]
===
match
---
atom_expr [3902,3919]
atom_expr [3902,3919]
===
match
---
operator: , [15143,15144]
operator: , [15143,15144]
===
match
---
string: "default_queue" [6936,6951]
string: "default_queue" [6936,6951]
===
match
---
name: DEFAULT_DATETIME_1 [27771,27789]
name: DEFAULT_DATETIME_1 [27771,27789]
===
match
---
name: test_should_respond_200 [20667,20690]
name: test_should_respond_200 [20667,20690]
===
match
---
string: 'task_id' [38773,38782]
string: 'task_id' [39495,39504]
===
match
---
string: "Naive datetime is disallowed" [24563,24593]
string: "Naive datetime is disallowed" [24563,24593]
===
match
---
operator: = [40107,40108]
operator: = [40829,40830]
===
match
---
name: utils [1139,1144]
name: utils [1139,1144]
===
match
---
atom_expr [16766,16868]
atom_expr [16766,16868]
===
match
---
name: i [4256,4257]
name: i [4256,4257]
===
match
---
operator: , [30321,30322]
operator: , [30321,30322]
===
match
---
name: dt [20546,20548]
name: dt [20546,20548]
===
match
---
operator: + [11601,11602]
operator: + [11601,11602]
===
match
---
name: test_client [2900,2911]
name: test_client [2900,2911]
===
match
---
arglist [24918,25045]
arglist [24918,25045]
===
match
---
expr_stmt [36649,36899]
expr_stmt [37371,37621]
===
match
---
name: expected_ti_count [20765,20782]
name: expected_ti_count [20765,20782]
===
match
---
trailer [3828,3847]
trailer [3828,3847]
===
match
---
trailer [18964,18974]
trailer [18964,18974]
===
match
---
trailer [16276,16280]
trailer [16276,16280]
===
match
---
trailer [27912,27920]
trailer [27912,27920]
===
match
---
name: i [3962,3963]
name: i [3962,3963]
===
match
---
funcdef [35178,35600]
funcdef [35900,36322]
===
match
---
argument [29028,29034]
argument [29028,29034]
===
match
---
dictorsetmaker [13561,13583]
dictorsetmaker [13561,13583]
===
match
---
name: FAILED [27414,27420]
name: FAILED [27414,27420]
===
match
---
number: 1 [28679,28680]
number: 1 [28679,28680]
===
match
---
string: "Naive datetime is disallowed" [36199,36229]
string: "Naive datetime is disallowed" [36921,36951]
===
match
---
name: environ_overrides [43127,43144]
name: environ_overrides [43849,43866]
===
match
---
number: 2 [15127,15128]
number: 2 [15127,15128]
===
match
---
argument [40103,40461]
argument [40825,41183]
===
match
---
testlist_comp [15236,15356]
testlist_comp [15236,15356]
===
match
---
expr_stmt [23526,23702]
expr_stmt [23526,23702]
===
match
---
operator: { [13560,13561]
operator: { [13560,13561]
===
match
---
operator: , [26071,26072]
operator: , [26071,26072]
===
match
---
atom [7913,9023]
atom [7913,9023]
===
match
---
name: self [2445,2449]
name: self [2445,2449]
===
match
---
operator: , [20253,20254]
operator: , [20253,20254]
===
match
---
string: "max_tries" [5507,5518]
string: "max_tries" [5507,5518]
===
match
---
operator: } [22053,22054]
operator: } [22053,22054]
===
match
---
name: post [41234,41238]
name: post [41956,41960]
===
match
---
name: task [39235,39239]
name: task [39957,39961]
===
match
---
operator: , [21974,21975]
operator: , [21974,21975]
===
match
---
simple_stmt [3065,3133]
simple_stmt [3065,3133]
===
match
---
operator: = [4295,4296]
operator: = [4295,4296]
===
match
---
operator: + [28836,28837]
operator: + [28836,28837]
===
match
---
arglist [31853,31983]
arglist [32575,32705]
===
match
---
name: get [16778,16781]
name: get [16778,16781]
===
match
---
name: expected [37474,37482]
name: expected [38196,38204]
===
match
---
operator: { [18291,18292]
operator: { [18291,18292]
===
match
---
name: response [6444,6452]
name: response [6444,6452]
===
match
---
string: "test queue filter" [14701,14720]
string: "test queue filter" [14701,14720]
===
match
---
string: "queue" [14855,14862]
string: "queue" [14855,14862]
===
match
---
import_from [889,953]
import_from [889,953]
===
match
---
name: FAILED [30220,30226]
name: FAILED [30220,30226]
===
match
---
atom [19797,20620]
atom [19797,20620]
===
match
---
atom [30339,30383]
atom [30339,30383]
===
match
---
name: update_extras [20725,20738]
name: update_extras [20725,20738]
===
match
---
operator: , [31170,31171]
operator: , [31170,31171]
===
match
---
trailer [21358,21376]
trailer [21358,21376]
===
match
---
string: "state" [27791,27798]
string: "state" [27791,27798]
===
match
---
atom_expr [29528,29540]
atom_expr [29528,29540]
===
match
---
operator: @ [41797,41798]
operator: @ [42519,42520]
===
match
---
operator: , [6814,6815]
operator: , [6814,6815]
===
match
---
operator: , [27561,27562]
operator: , [27561,27562]
===
match
---
name: self [35641,35645]
name: self [36363,36367]
===
match
---
simple_stmt [1365,1407]
simple_stmt [1365,1407]
===
match
---
operator: , [13584,13585]
operator: , [13584,13585]
===
match
---
operator: } [9803,9804]
operator: } [9803,9804]
===
match
---
trailer [15964,15981]
trailer [15964,15981]
===
match
---
string: "default_pool" [2746,2760]
string: "default_pool" [2746,2760]
===
match
---
decorated [9635,16064]
decorated [9635,16064]
===
match
---
dictorsetmaker [21513,21529]
dictorsetmaker [21513,21529]
===
match
---
name: environ_overrides [16370,16387]
name: environ_overrides [16370,16387]
===
match
---
name: timedelta [30887,30896]
name: timedelta [30887,30896]
===
match
---
name: dt [19425,19427]
name: dt [19425,19427]
===
match
---
string: 'TEST_DAG_RUN_ID' [38667,38684]
string: 'TEST_DAG_RUN_ID' [39389,39406]
===
match
---
atom [28773,28928]
atom [28773,28928]
===
match
---
operator: } [15354,15355]
operator: } [15354,15355]
===
match
---
name: count [16591,16596]
name: count [16591,16596]
===
match
---
name: DagRunType [4674,4684]
name: DagRunType [4674,4684]
===
match
---
fstring_string: = [12449,12450]
fstring_string: = [12449,12450]
===
match
---
number: 1 [26375,26376]
number: 1 [26375,26376]
===
match
---
operator: = [16481,16482]
operator: = [16481,16482]
===
match
---
trailer [28566,28573]
trailer [28566,28573]
===
match
---
fstring_end: " [31900,31901]
fstring_end: " [32622,32623]
===
match
---
testlist_comp [18735,19223]
testlist_comp [18735,19223]
===
match
---
operator: , [8403,8404]
operator: , [8403,8404]
===
match
---
operator: == [37425,37427]
operator: == [38147,38149]
===
match
---
fstring_expr [4255,4258]
fstring_expr [4255,4258]
===
match
---
operator: = [2533,2534]
operator: = [2533,2534]
===
match
---
fstring_expr [11344,11368]
fstring_expr [11344,11368]
===
match
---
assert_stmt [5167,5201]
assert_stmt [5167,5201]
===
match
---
name: FAILED [30768,30774]
name: FAILED [30768,30774]
===
match
---
name: FAILED [29534,29540]
name: FAILED [29534,29540]
===
match
---
name: response [23357,23365]
name: response [23357,23365]
===
match
---
number: 200 [18542,18545]
number: 200 [18542,18545]
===
match
---
name: unittest [812,820]
name: unittest [812,820]
===
match
---
name: execution_date [39105,39119]
name: execution_date [39827,39841]
===
match
---
operator: , [13538,13539]
operator: , [13538,13539]
===
match
---
name: counter [3689,3696]
name: counter [3689,3696]
===
match
---
operator: { [15868,15869]
operator: { [15868,15869]
===
match
---
trailer [2355,2368]
trailer [2355,2368]
===
match
---
trailer [37885,37887]
trailer [38607,38609]
===
match
---
operator: , [11547,11548]
operator: , [11547,11548]
===
match
---
testlist_comp [1892,1955]
testlist_comp [1892,1955]
===
match
---
string: "REMOTE_USER" [22379,22392]
string: "REMOTE_USER" [22379,22392]
===
match
---
name: json [22415,22419]
name: json [22415,22419]
===
match
---
fstring_expr [11895,11919]
fstring_expr [11895,11919]
===
match
---
trailer [29075,29082]
trailer [29075,29082]
===
match
---
name: payload [21161,21168]
name: payload [21161,21168]
===
match
---
trailer [39369,39829]
trailer [40091,40551]
===
match
---
string: "total_entries" [15965,15980]
string: "total_entries" [15965,15980]
===
match
---
arglist [31579,31726]
arglist [32301,32448]
===
match
---
trailer [20548,20558]
trailer [20548,20558]
===
match
---
operator: { [40051,40052]
operator: { [40773,40774]
===
match
---
name: response [6185,6193]
name: response [6185,6193]
===
match
---
name: RUNNING [32641,32648]
name: RUNNING [33363,33370]
===
match
---
name: days [18898,18902]
name: days [18898,18902]
===
match
---
argument [7784,7825]
argument [7784,7825]
===
match
---
operator: == [21338,21340]
operator: == [21338,21340]
===
match
---
string: "end_date" [36246,36256]
string: "end_date" [36968,36978]
===
match
---
operator: { [6461,6462]
operator: { [6461,6462]
===
match
---
trailer [11682,11692]
trailer [11682,11692]
===
match
---
atom_expr [30037,30049]
atom_expr [30037,30049]
===
match
---
param [15600,15615]
param [15600,15615]
===
match
---
dotted_name [1218,1254]
dotted_name [1218,1254]
===
match
---
trailer [27187,27195]
trailer [27187,27195]
===
match
---
operator: } [30071,30072]
operator: } [30071,30072]
===
match
---
operator: , [22981,22982]
operator: , [22981,22982]
===
match
---
dictorsetmaker [32987,33087]
dictorsetmaker [33709,33809]
===
match
---
operator: , [31501,31502]
operator: , [32223,32224]
===
match
---
trailer [5980,5982]
trailer [5980,5982]
===
match
---
operator: , [24661,24662]
operator: , [24661,24662]
===
match
---
funcdef [40521,41150]
funcdef [41243,41872]
===
match
---
operator: , [30774,30775]
operator: , [30774,30775]
===
match
---
atom [19943,20004]
atom [19943,20004]
===
match
---
atom_expr [40587,41106]
atom_expr [41309,41828]
===
match
---
name: commit [7619,7625]
name: commit [7619,7625]
===
match
---
suite [35008,35077]
suite [35730,35799]
===
match
---
simple_stmt [31539,31737]
simple_stmt [32261,32459]
===
match
---
argument [33244,33273]
argument [33966,33995]
===
match
---
name: days [18975,18979]
name: days [18975,18979]
===
match
---
comparison [16518,16566]
comparison [16518,16566]
===
match
---
string: 'execution_date' [33889,33905]
string: 'execution_date' [34611,34627]
===
match
---
assert_stmt [41757,41791]
assert_stmt [42479,42513]
===
match
---
operator: , [14417,14418]
operator: , [14417,14418]
===
match
---
atom [36155,36197]
atom [36877,36919]
===
match
---
dictorsetmaker [24996,25017]
dictorsetmaker [24996,25017]
===
match
---
operator: = [36830,36831]
operator: = [37552,37553]
===
match
---
operator: } [14506,14507]
operator: } [14506,14507]
===
match
---
atom [7802,7825]
atom [7802,7825]
===
match
---
operator: , [41949,41950]
operator: , [42671,42672]
===
match
---
trailer [41226,41233]
trailer [41948,41955]
===
match
---
name: days [31074,31078]
name: days [31074,31078]
===
match
---
atom [27730,28187]
atom [27730,28187]
===
match
---
arglist [16294,16412]
arglist [16294,16412]
===
match
---
operator: , [9726,9727]
operator: , [9726,9727]
===
match
---
dictorsetmaker [24510,24560]
dictorsetmaker [24510,24560]
===
match
---
name: query [37810,37815]
name: query [38532,38537]
===
match
---
trailer [18887,18897]
trailer [18887,18897]
===
match
---
name: FAILED [28722,28728]
name: FAILED [28722,28728]
===
match
---
operator: , [3964,3965]
operator: , [3964,3965]
===
match
---
operator: + [36811,36812]
operator: + [37533,37534]
===
match
---
name: timedelta [28080,28089]
name: timedelta [28080,28089]
===
match
---
atom [25647,25802]
atom [25647,25802]
===
match
---
operator: , [27967,27968]
operator: , [27967,27968]
===
match
---
arglist [20847,20982]
arglist [20847,20982]
===
match
---
operator: , [40285,40286]
operator: , [41007,41008]
===
match
---
operator: , [17611,17612]
operator: , [17611,17612]
===
match
---
comparison [41764,41791]
comparison [42486,42513]
===
match
---
dictorsetmaker [38596,38804]
dictorsetmaker [39318,39526]
===
match
---
string: "failed" [42232,42240]
string: "failed" [42954,42962]
===
match
---
operator: = [19521,19522]
operator: = [19521,19522]
===
match
---
name: datetime [792,800]
name: datetime [792,800]
===
match
---
name: dr [4513,4515]
name: dr [4513,4515]
===
match
---
string: "start_date" [19469,19481]
string: "start_date" [19469,19481]
===
match
---
atom_expr [33073,33086]
atom_expr [33795,33808]
===
match
---
string: "state" [32626,32633]
string: "state" [33348,33355]
===
match
---
fstring_string: /api/v1/dags/ [33409,33422]
fstring_string: /api/v1/dags/ [34131,34144]
===
match
---
string: "default_queue" [8388,8403]
string: "default_queue" [8388,8403]
===
match
---
string: "PythonOperator" [6774,6790]
string: "PythonOperator" [6774,6790]
===
match
---
operator: , [7474,7475]
operator: , [7474,7475]
===
match
---
name: response [35236,35244]
name: response [35958,35966]
===
match
---
name: days [28851,28855]
name: days [28851,28855]
===
match
---
operator: } [12714,12715]
operator: } [12714,12715]
===
match
---
atom [14018,14041]
atom [14018,14041]
===
match
---
decorator [24716,24733]
decorator [24716,24733]
===
match
---
name: DEFAULT_DATETIME_1 [32859,32877]
name: DEFAULT_DATETIME_1 [33581,33599]
===
match
---
string: "2020-01-03T00:00:00+00:00" [6569,6596]
string: "2020-01-03T00:00:00+00:00" [6569,6596]
===
match
---
operator: = [33568,33569]
operator: = [34290,34291]
===
match
---
atom_expr [1819,1846]
atom_expr [1819,1846]
===
match
---
atom [21490,21589]
atom [21490,21589]
===
match
---
dotted_name [37552,37562]
dotted_name [38274,38284]
===
match
---
name: DEFAULT_DATETIME_STR_1 [12451,12473]
name: DEFAULT_DATETIME_STR_1 [12451,12473]
===
match
---
arglist [3951,3980]
arglist [3951,3980]
===
match
---
operator: , [35754,35755]
operator: , [36476,36477]
===
match
---
simple_stmt [785,807]
simple_stmt [785,807]
===
match
---
testlist_comp [1971,2034]
testlist_comp [1971,2034]
===
match
---
operator: { [29740,29741]
operator: { [29740,29741]
===
match
---
atom_expr [21903,22064]
atom_expr [21903,22064]
===
match
---
name: update_extras [31672,31685]
name: update_extras [32394,32407]
===
match
---
simple_stmt [23413,23463]
simple_stmt [23413,23463]
===
match
---
name: commit [39050,39056]
name: commit [39772,39778]
===
match
---
atom [11569,11624]
atom [11569,11624]
===
match
---
param [31455,31464]
param [32177,32186]
===
match
---
string: "failed" [41714,41722]
string: "failed" [42436,42444]
===
match
---
operator: , [24794,24795]
operator: , [24794,24795]
===
match
---
operator: { [17929,17930]
operator: { [17929,17930]
===
match
---
operator: { [38574,38575]
operator: { [39296,39297]
===
match
---
name: TestTaskInstanceEndpoint [2232,2256]
name: TestTaskInstanceEndpoint [2232,2256]
===
match
---
comparison [25114,25149]
comparison [25114,25149]
===
match
---
operator: , [40877,40878]
operator: , [41599,41600]
===
match
---
trailer [15916,15928]
trailer [15916,15928]
===
match
---
atom [41347,41370]
atom [42069,42092]
===
match
---
operator: , [1777,1778]
operator: , [1777,1778]
===
match
---
trailer [43272,43277]
trailer [43994,43999]
===
match
---
dictorsetmaker [21630,21656]
dictorsetmaker [21630,21656]
===
match
---
name: session [22113,22120]
name: session [22113,22120]
===
match
---
testlist_comp [10881,11407]
testlist_comp [10881,11407]
===
match
---
string: "REMOTE_USER" [37329,37342]
string: "REMOTE_USER" [38051,38064]
===
match
---
operator: { [9826,9827]
operator: { [9826,9827]
===
match
---
trailer [31761,31772]
trailer [32483,32494]
===
match
---
atom_expr [3635,3654]
atom_expr [3635,3654]
===
match
---
string: "end_date" [18852,18862]
string: "end_date" [18852,18862]
===
match
---
argument [9464,9520]
argument [9464,9520]
===
match
---
name: response [22483,22491]
name: response [22483,22491]
===
match
---
name: self [39926,39930]
name: self [40648,40652]
===
match
---
name: session [31516,31523]
name: session [32238,32245]
===
match
---
string: "state" [27399,27406]
string: "state" [27399,27406]
===
match
---
name: test_should_raise_403_forbidden [23741,23772]
name: test_should_raise_403_forbidden [23741,23772]
===
match
---
suite [3790,3848]
suite [3790,3848]
===
match
---
trailer [11125,11135]
trailer [11125,11135]
===
match
---
simple_stmt [16755,16869]
simple_stmt [16755,16869]
===
match
---
suite [2342,3133]
suite [2342,3133]
===
match
---
operator: } [12753,12754]
operator: } [12753,12754]
===
match
---
comparison [22512,22563]
comparison [22512,22563]
===
match
---
operator: , [13996,13997]
operator: , [13996,13997]
===
match
---
number: 403 [17177,17180]
number: 403 [17177,17180]
===
match
---
operator: , [39600,39601]
operator: , [40322,40323]
===
match
---
atom [10595,10815]
atom [10595,10815]
===
match
---
string: "execution_date" [20276,20292]
string: "execution_date" [20276,20292]
===
match
---
name: session [42992,42999]
name: session [43714,43721]
===
match
---
operator: + [32878,32879]
operator: + [33600,33601]
===
match
---
atom [12659,12676]
atom [12659,12676]
===
match
---
trailer [1394,1406]
trailer [1394,1406]
===
match
---
operator: } [30248,30249]
operator: } [30248,30249]
===
match
---
dictorsetmaker [23907,23943]
dictorsetmaker [23907,23943]
===
match
---
operator: == [16460,16462]
operator: == [16460,16462]
===
match
---
trailer [37225,37388]
trailer [37947,38110]
===
match
---
name: expected_ti [23393,23404]
name: expected_ti [23393,23404]
===
match
---
operator: , [4597,4598]
operator: , [4597,4598]
===
match
---
operator: , [14060,14061]
operator: , [14060,14061]
===
match
---
dictorsetmaker [12238,12291]
dictorsetmaker [12238,12291]
===
match
---
name: test_should_raise_400_for_naive_and_bad_datetime [36557,36605]
name: test_should_raise_400_for_naive_and_bad_datetime [37279,37327]
===
match
---
atom_expr [7200,7209]
atom_expr [7200,7209]
===
match
---
atom_expr [27175,27195]
atom_expr [27175,27195]
===
match
---
operator: } [30382,30383]
operator: } [30382,30383]
===
match
---
name: DEFAULT_DATETIME_1 [20128,20146]
name: DEFAULT_DATETIME_1 [20128,20146]
===
match
---
name: task_instances [15769,15783]
name: task_instances [15769,15783]
===
match
---
operator: , [34829,34830]
operator: , [35551,35552]
===
match
---
operator: = [20000,20001]
operator: = [20000,20001]
===
match
---
string: "state" [22026,22033]
string: "state" [22026,22033]
===
match
---
dictorsetmaker [20276,20335]
dictorsetmaker [20276,20335]
===
match
---
param [31494,31502]
param [32216,32224]
===
match
---
string: "include_upstream" [38237,38255]
string: "include_upstream" [38959,38977]
===
match
---
operator: , [34591,34592]
operator: , [35313,35314]
===
match
---
operator: , [25555,25556]
operator: , [25555,25556]
===
match
---
operator: , [4555,4556]
operator: , [4555,4556]
===
match
---
name: add [4097,4100]
name: add [4097,4100]
===
match
---
string: 'example_python_operator' [33795,33820]
string: 'example_python_operator' [34517,34542]
===
match
---
operator: , [24813,24814]
operator: , [24813,24814]
===
match
---
name: ti_init [3973,3980]
name: ti_init [3973,3980]
===
match
---
atom [10030,10214]
atom [10030,10214]
===
match
---
string: "sla_miss" [6998,7008]
string: "sla_miss" [6998,7008]
===
match
---
string: "TestNoPermissions" [2117,2136]
string: "TestNoPermissions" [2117,2136]
===
match
---
name: dag_run_state [3355,3368]
name: dag_run_state [3355,3368]
===
match
---
operator: , [12986,12987]
operator: , [12986,12987]
===
match
---
testlist_comp [15175,15506]
testlist_comp [15175,15506]
===
match
---
operator: = [1384,1385]
operator: = [1384,1385]
===
match
---
parameters [1565,1586]
parameters [1565,1586]
===
match
---
operator: , [14832,14833]
operator: , [14832,14833]
===
match
---
name: State [31116,31121]
name: State [31116,31121]
===
match
---
name: response [23116,23124]
name: response [23116,23124]
===
match
---
operator: { [40700,40701]
operator: { [41422,41423]
===
match
---
operator: , [41315,41316]
operator: , [42037,42038]
===
match
---
simple_stmt [7889,9024]
simple_stmt [7889,9024]
===
match
---
simple_stmt [834,848]
simple_stmt [834,848]
===
match
---
assert_stmt [43214,43248]
assert_stmt [43936,43970]
===
match
---
trailer [11056,11064]
trailer [11056,11064]
===
match
---
argument [32601,32607]
argument [33323,33329]
===
match
---
trailer [3972,3980]
trailer [3972,3980]
===
match
---
atom [9482,9520]
atom [9482,9520]
===
match
---
atom [27026,27088]
atom [27026,27088]
===
match
---
string: "new_state" [41701,41712]
string: "new_state" [42423,42434]
===
match
---
operator: } [32414,32415]
operator: } [33136,33137]
===
match
---
name: DEFAULT_DATETIME_1 [26513,26531]
name: DEFAULT_DATETIME_1 [26513,26531]
===
match
---
operator: { [19333,19334]
operator: { [19333,19334]
===
match
---
arglist [23567,23692]
arglist [23567,23692]
===
match
---
name: test_should_respond_200_for_dag_id_filter [16073,16114]
name: test_should_respond_200_for_dag_id_filter [16073,16114]
===
match
---
argument [27366,27372]
argument [27366,27372]
===
match
---
arith_expr [2629,2669]
arith_expr [2629,2669]
===
match
---
simple_stmt [9317,9532]
simple_stmt [9317,9532]
===
match
---
operator: = [22182,22183]
operator: = [22182,22183]
===
match
---
operator: = [3126,3127]
operator: = [3126,3127]
===
match
---
name: FAILED [33340,33346]
name: FAILED [34062,34068]
===
match
---
operator: = [33523,33524]
operator: = [34245,34246]
===
match
---
name: FAILED [25596,25602]
name: FAILED [25596,25602]
===
match
---
name: task_instances [31465,31479]
name: task_instances [32187,32201]
===
match
---
name: test_should_respond_200_with_task_state_in_removed [6003,6053]
name: test_should_respond_200_with_task_state_in_removed [6003,6053]
===
match
---
atom_expr [32781,32794]
atom_expr [33503,33516]
===
match
---
arith_expr [19483,19524]
arith_expr [19483,19524]
===
match
---
operator: , [14898,14899]
operator: , [14898,14899]
===
match
---
simple_stmt [17146,17181]
simple_stmt [17146,17181]
===
match
---
arith_expr [25691,25732]
arith_expr [25691,25732]
===
match
---
fstring_expr [10171,10195]
fstring_expr [10171,10195]
===
match
---
name: environ_overrides [37310,37327]
name: environ_overrides [38032,38049]
===
match
---
expr_stmt [3621,3664]
expr_stmt [3621,3664]
===
match
---
string: "/api/v1/dags/example_python_operator/dagRuns/TEST_DAG_RUN_ID" [14960,15022]
string: "/api/v1/dags/example_python_operator/dagRuns/TEST_DAG_RUN_ID" [14960,15022]
===
match
---
operator: , [15374,15375]
operator: , [15374,15375]
===
match
---
name: self [31446,31450]
name: self [32168,32172]
===
match
---
name: DEFAULT_DATETIME_1 [41501,41519]
name: DEFAULT_DATETIME_1 [42223,42241]
===
match
---
operator: } [5992,5993]
operator: } [5992,5993]
===
match
---
name: task_instances [3714,3728]
name: task_instances [3714,3728]
===
match
---
string: "duration" [6524,6534]
string: "duration" [6524,6534]
===
match
---
testlist_comp [26209,26625]
testlist_comp [26209,26625]
===
match
---
name: test_should_raises_401_unauthenticated [23472,23510]
name: test_should_raises_401_unauthenticated [23472,23510]
===
match
---
name: DEFAULT_DATETIME_STR_2 [26775,26797]
name: DEFAULT_DATETIME_STR_2 [26775,26797]
===
match
---
atom_expr [37837,37857]
atom_expr [38559,38579]
===
match
---
atom_expr [27074,27087]
atom_expr [27074,27087]
===
match
---
number: 2020 [1395,1399]
number: 2020 [1395,1399]
===
match
---
atom [10262,10849]
atom [10262,10849]
===
match
---
simple_stmt [4914,4950]
simple_stmt [4914,4950]
===
match
---
atom_expr [2629,2646]
atom_expr [2629,2646]
===
match
---
name: timedelta [29018,29027]
name: timedelta [29018,29027]
===
match
---
operator: , [20738,20739]
operator: , [20738,20739]
===
match
---
operator: } [11956,11957]
operator: } [11956,11957]
===
match
---
name: session [6105,6112]
name: session [6105,6112]
===
match
---
atom_expr [3807,3847]
atom_expr [3807,3847]
===
match
---
testlist_comp [36155,36229]
testlist_comp [36877,36951]
===
match
---
operator: , [32794,32795]
operator: , [33516,33517]
===
match
---
name: DEFAULT_DATETIME_1 [11582,11600]
name: DEFAULT_DATETIME_1 [11582,11600]
===
match
---
name: value [4692,4697]
name: value [4692,4697]
===
match
---
operator: } [22400,22401]
operator: } [22400,22401]
===
match
---
operator: = [4407,4408]
operator: = [4407,4408]
===
match
---
atom [11493,11720]
atom [11493,11720]
===
match
---
operator: , [24302,24303]
operator: , [24302,24303]
===
match
---
name: response [37906,37914]
name: response [38628,38636]
===
match
---
name: self [16139,16143]
name: self [16139,16143]
===
match
---
name: create_task_instances [7306,7327]
name: create_task_instances [7306,7327]
===
match
---
string: "end_date" [12238,12248]
string: "end_date" [12238,12248]
===
match
---
operator: , [12565,12566]
operator: , [12565,12566]
===
match
---
name: count [16475,16480]
name: count [16475,16480]
===
match
---
operator: , [42826,42827]
operator: , [43548,43549]
===
match
---
param [21880,21887]
param [21880,21887]
===
match
---
name: DEFAULT_DATETIME_STR_2 [11934,11956]
name: DEFAULT_DATETIME_STR_2 [11934,11956]
===
match
---
string: 'REMOTE_USER' [35787,35800]
string: 'REMOTE_USER' [36509,36522]
===
match
---
name: DEFAULT_DATETIME_1 [33005,33023]
name: DEFAULT_DATETIME_1 [33727,33745]
===
match
---
string: "print_the_context" [8929,8948]
string: "print_the_context" [8929,8948]
===
match
---
number: 0 [35149,35150]
number: 0 [35871,35872]
===
match
---
number: 2 [28363,28364]
number: 2 [28363,28364]
===
match
---
name: FAILED [26595,26601]
name: FAILED [26595,26601]
===
match
---
name: airflow [959,966]
name: airflow [959,966]
===
match
---
name: self [9098,9102]
name: self [9098,9102]
===
match
---
operator: = [15827,15828]
operator: = [15827,15828]
===
match
---
atom [35843,36049]
atom [36565,36771]
===
match
---
trailer [31565,31736]
trailer [32287,32458]
===
match
---
operator: , [34696,34697]
operator: , [35418,35419]
===
match
---
atom [25365,25821]
atom [25365,25821]
===
match
---
operator: { [11008,11009]
operator: { [11008,11009]
===
match
---
operator: , [36717,36718]
operator: , [37439,37440]
===
match
---
name: post [37221,37225]
name: post [37943,37947]
===
match
---
operator: } [32662,32663]
operator: } [33384,33385]
===
match
---
operator: , [37694,37695]
operator: , [38416,38417]
===
match
---
funcdef [36553,37483]
funcdef [37275,38205]
===
match
---
name: DEFAULT_DATETIME_1 [20045,20063]
name: DEFAULT_DATETIME_1 [20045,20063]
===
match
---
operator: , [20754,20755]
operator: , [20754,20755]
===
match
---
param [24790,24795]
param [24790,24795]
===
match
---
trailer [9961,9969]
trailer [9961,9969]
===
match
---
arith_expr [26336,26377]
arith_expr [26336,26377]
===
match
---
fstring [10714,10797]
fstring [10714,10797]
===
match
---
string: "test" [1681,1687]
string: "test" [1681,1687]
===
match
---
decorated [24083,25150]
decorated [24083,25150]
===
match
---
trailer [24837,24859]
trailer [24837,24859]
===
match
---
atom [2413,2509]
atom [2413,2509]
===
match
---
name: DEFAULT_DATETIME_1 [30578,30596]
name: DEFAULT_DATETIME_1 [30578,30596]
===
match
---
trailer [11135,11143]
trailer [11135,11143]
===
match
---
string: "task_id" [39516,39525]
string: "task_id" [40238,40247]
===
match
---
operator: == [40509,40511]
operator: == [41231,41233]
===
match
---
string: "start_date_gte" [24414,24430]
string: "start_date_gte" [24414,24430]
===
match
---
string: "queued_when" [5738,5751]
string: "queued_when" [5738,5751]
===
match
---
dictorsetmaker [28038,28146]
dictorsetmaker [28038,28146]
===
match
---
name: DEFAULT_DATETIME_1 [38201,38219]
name: DEFAULT_DATETIME_1 [38923,38941]
===
match
---
string: "end_date" [21992,22002]
string: "end_date" [21992,22002]
===
match
---
name: days [36826,36830]
name: days [37548,37552]
===
match
---
simple_stmt [1407,1460]
simple_stmt [1407,1460]
===
match
---
simple_stmt [41115,41150]
simple_stmt [41837,41872]
===
match
---
name: session [23072,23079]
name: session [23072,23079]
===
match
---
string: "REMOTE_USER" [21120,21133]
string: "REMOTE_USER" [21120,21133]
===
match
---
string: "/api/v1/dags/~/dagRuns/~/taskInstances?queue=test_queue_1,test_queue_2" [15414,15486]
string: "/api/v1/dags/~/dagRuns/~/taskInstances?queue=test_queue_1,test_queue_2" [15414,15486]
===
match
---
number: 200 [18665,18668]
number: 200 [18665,18668]
===
match
---
atom_expr [39838,39858]
atom_expr [40560,40580]
===
match
---
arglist [37947,38438]
arglist [38669,39160]
===
match
---
name: State [28561,28566]
name: State [28561,28566]
===
match
---
param [16115,16120]
param [16115,16120]
===
match
---
assert_stmt [16639,16691]
assert_stmt [16639,16691]
===
match
---
trailer [33612,33638]
trailer [34334,34360]
===
match
---
arglist [21414,21703]
arglist [21414,21703]
===
match
---
param [15591,15596]
param [15591,15596]
===
match
---
name: json [6453,6457]
name: json [6453,6457]
===
match
---
name: permissions [1892,1903]
name: permissions [1892,1903]
===
match
---
operator: , [32263,32264]
operator: , [32985,32986]
===
match
---
name: app [2186,2189]
name: app [2186,2189]
===
match
---
operator: , [14526,14527]
operator: , [14526,14527]
===
match
---
name: environ_overrides [22360,22377]
name: environ_overrides [22360,22377]
===
match
---
operator: } [26856,26857]
operator: } [26856,26857]
===
match
---
param [6060,6067]
param [6060,6067]
===
match
---
dotted_name [1093,1112]
dotted_name [1093,1112]
===
match
---
operator: } [9886,9887]
operator: } [9886,9887]
===
match
---
name: SlaMiss [932,939]
name: SlaMiss [932,939]
===
match
---
param [20784,20791]
param [20784,20791]
===
match
---
atom [30431,31366]
atom [30431,31366]
===
match
---
name: DEFAULT_DATETIME_1 [30863,30881]
name: DEFAULT_DATETIME_1 [30863,30881]
===
match
---
string: "clear start date filter" [25279,25304]
string: "clear start date filter" [25279,25304]
===
match
---
name: dt [28838,28840]
name: dt [28838,28840]
===
match
---
trailer [9555,9567]
trailer [9555,9567]
===
match
---
simple_stmt [2518,2835]
simple_stmt [2518,2835]
===
match
---
string: "end_date" [12107,12117]
string: "end_date" [12107,12117]
===
match
---
operator: { [23631,23632]
operator: { [23631,23632]
===
match
---
operator: , [3194,3195]
operator: , [3194,3195]
===
match
---
string: "test pool filter ~" [14334,14354]
string: "test pool filter ~" [14334,14354]
===
match
---
name: parameterized [9636,9649]
name: parameterized [9636,9649]
===
match
---
name: self [23045,23049]
name: self [23045,23049]
===
match
---
operator: { [27026,27027]
operator: { [27026,27027]
===
match
---
number: 3 [29033,29034]
number: 3 [29033,29034]
===
match
---
name: DEFAULT_DATETIME_1 [30138,30156]
name: DEFAULT_DATETIME_1 [30138,30156]
===
match
---
operator: , [17889,17890]
operator: , [17889,17890]
===
match
---
operator: { [23963,23964]
operator: { [23963,23964]
===
match
---
trailer [3886,3894]
trailer [3886,3894]
===
match
---
operator: } [19366,19367]
operator: } [19366,19367]
===
match
---
atom [32677,32809]
atom [33399,33531]
===
match
---
string: "queued" [18313,18321]
string: "queued" [18313,18321]
===
match
---
name: session [7581,7588]
name: session [7581,7588]
===
match
---
string: "test" [15884,15890]
string: "test" [15884,15890]
===
match
---
operator: , [39163,39164]
operator: , [39885,39886]
===
match
---
name: self [2398,2402]
name: self [2398,2402]
===
match
---
operator: = [37071,37072]
operator: = [37793,37794]
===
match
---
arglist [22301,22428]
arglist [22301,22428]
===
match
---
atom_expr [29683,29695]
atom_expr [29683,29695]
===
match
---
name: task [3951,3955]
name: task [3951,3955]
===
match
---
argument [1672,1687]
argument [1672,1687]
===
match
---
trailer [35058,35076]
trailer [35780,35798]
===
match
---
operator: = [11061,11062]
operator: = [11061,11062]
===
match
---
name: len [16012,16015]
name: len [16012,16015]
===
match
---
name: single_dag_run [20952,20966]
name: single_dag_run [20952,20966]
===
match
---
atom_expr [1386,1406]
atom_expr [1386,1406]
===
match
---
atom [35786,35824]
atom [36508,36546]
===
match
---
atom [17929,17969]
atom [17929,17969]
===
match
---
operator: , [21611,21612]
operator: , [21611,21612]
===
match
---
string: "queue" [14808,14815]
string: "queue" [14808,14815]
===
match
---
operator: , [39498,39499]
operator: , [40220,40221]
===
match
---
operator: , [7281,7282]
operator: , [7281,7282]
===
match
---
number: 2 [11141,11142]
number: 2 [11141,11142]
===
match
---
operator: { [14018,14019]
operator: { [14018,14019]
===
match
---
operator: } [27442,27443]
operator: } [27442,27443]
===
match
---
operator: , [30974,30975]
operator: , [30974,30975]
===
match
---
operator: } [36277,36278]
operator: } [36999,37000]
===
match
---
operator: , [15128,15129]
operator: , [15128,15129]
===
match
---
name: app [38867,38870]
name: app [39589,39592]
===
match
---
dictorsetmaker [14440,14461]
dictorsetmaker [14440,14461]
===
match
---
dictorsetmaker [18141,18162]
dictorsetmaker [18141,18162]
===
match
---
name: test_should_raises_401_unauthenticated [35182,35220]
name: test_should_raises_401_unauthenticated [35904,35942]
===
match
---
name: ti [4101,4103]
name: ti [4101,4103]
===
match
---
dictorsetmaker [14761,14784]
dictorsetmaker [14761,14784]
===
match
---
name: FAILED [25773,25779]
name: FAILED [25773,25779]
===
match
---
operator: , [21530,21531]
operator: , [21530,21531]
===
match
---
trailer [24859,24868]
trailer [24859,24868]
===
match
---
operator: = [4673,4674]
operator: = [4673,4674]
===
match
---
operator: { [8462,8463]
operator: { [8462,8463]
===
match
---
operator: } [17968,17969]
operator: } [17968,17969]
===
match
---
suite [35647,36104]
suite [36369,36826]
===
match
---
operator: , [29648,29649]
operator: , [29648,29649]
===
match
---
trailer [25714,25724]
trailer [25714,25724]
===
match
---
operator: } [40088,40089]
operator: } [40810,40811]
===
match
---
operator: , [25448,25449]
operator: , [25448,25449]
===
match
---
operator: , [27618,27619]
operator: , [27618,27619]
===
match
---
atom_expr [6401,6421]
atom_expr [6401,6421]
===
match
---
string: "execution_date" [29589,29605]
string: "execution_date" [29589,29605]
===
match
---
atom [18301,18322]
atom [18301,18322]
===
match
---
comparison [15908,15935]
comparison [15908,15935]
===
match
---
dictorsetmaker [13929,13950]
dictorsetmaker [13929,13950]
===
match
---
name: State [27800,27805]
name: State [27800,27805]
===
match
---
assert_stmt [35085,35133]
assert_stmt [35807,35855]
===
match
---
simple_stmt [16139,16175]
simple_stmt [16139,16175]
===
match
---
number: 6 [5685,5686]
number: 6 [5685,5686]
===
match
---
atom [9766,9804]
atom [9766,9804]
===
match
---
number: 200 [15932,15935]
number: 200 [15932,15935]
===
match
---
name: client [16771,16777]
name: client [16771,16777]
===
match
---
atom [13469,13493]
atom [13469,13493]
===
match
---
trailer [30896,30904]
trailer [30896,30904]
===
match
---
operator: , [2462,2463]
operator: , [2462,2463]
===
match
---
trailer [27235,27243]
trailer [27235,27243]
===
match
---
name: State [29860,29865]
name: State [29860,29865]
===
match
---
string: "example_python_operator" [23976,24001]
string: "example_python_operator" [23976,24001]
===
match
---
name: DagRunType [1202,1212]
name: DagRunType [1202,1212]
===
match
---
dictorsetmaker [37329,37350]
dictorsetmaker [38051,38072]
===
match
---
operator: , [17506,17507]
operator: , [17506,17507]
===
match
---
string: "executor_config" [5442,5459]
string: "executor_config" [5442,5459]
===
match
---
name: _ [31452,31453]
name: _ [32174,32175]
===
match
---
atom [36680,36742]
atom [37402,37464]
===
match
---
trailer [28079,28089]
trailer [28079,28089]
===
match
---
name: update_extras [15616,15629]
name: update_extras [15616,15629]
===
match
---
string: "try_number" [7159,7171]
string: "try_number" [7159,7171]
===
match
---
string: "execution_date" [41971,41987]
string: "execution_date" [42693,42709]
===
match
---
trailer [2978,2980]
trailer [2978,2980]
===
match
---
operator: , [19783,19784]
operator: , [19783,19784]
===
match
---
operator: , [34115,34116]
operator: , [34837,34838]
===
match
---
trailer [2847,2851]
trailer [2847,2851]
===
match
---
number: 2 [11994,11995]
number: 2 [11994,11995]
===
match
---
trailer [13575,13583]
trailer [13575,13583]
===
match
---
operator: , [6655,6656]
operator: , [6655,6656]
===
match
---
operator: = [39181,39182]
operator: = [39903,39904]
===
match
---
trailer [40603,41106]
trailer [41325,41828]
===
match
---
operator: , [33230,33231]
operator: , [33952,33953]
===
match
---
name: session [20784,20791]
name: session [20784,20791]
===
match
---
arglist [33407,33532]
arglist [34129,34254]
===
match
---
string: "test_pool_1" [17744,17757]
string: "test_pool_1" [17744,17757]
===
match
---
name: single_dag_run [4485,4499]
name: single_dag_run [4485,4499]
===
match
---
operator: , [42240,42241]
operator: , [42962,42963]
===
match
---
decorated [22642,23463]
decorated [22642,23463]
===
match
---
arglist [16994,17127]
arglist [16994,17127]
===
match
---
atom [13155,13172]
atom [13155,13172]
===
match
---
name: dt [30884,30886]
name: dt [30884,30886]
===
match
---
atom_expr [4167,4440]
atom_expr [4167,4440]
===
match
---
string: "include_subdags" [31290,31307]
string: "include_subdags" [31290,31307]
===
match
---
dictorsetmaker [26726,26839]
dictorsetmaker [26726,26839]
===
match
---
operator: , [21589,21590]
operator: , [21589,21590]
===
match
---
trailer [3821,3828]
trailer [3821,3828]
===
match
---
operator: , [39803,39804]
operator: , [40525,40526]
===
match
---
trailer [6452,6457]
trailer [6452,6457]
===
match
---
name: self [23511,23515]
name: self [23511,23515]
===
match
---
expr_stmt [16954,17137]
expr_stmt [16954,17137]
===
match
---
trailer [25440,25447]
trailer [25440,25447]
===
match
---
argument [16370,16411]
argument [16370,16411]
===
match
---
operator: , [15308,15309]
operator: , [15308,15309]
===
match
---
name: timedelta [36816,36825]
name: timedelta [37538,37547]
===
match
---
name: environ_overrides [38024,38041]
name: environ_overrides [38746,38763]
===
match
---
trailer [41130,41142]
trailer [41852,41864]
===
match
---
expr_stmt [1592,1617]
expr_stmt [1592,1617]
===
match
---
operator: = [20249,20250]
operator: = [20249,20250]
===
match
---
string: "dag_id" [6475,6483]
string: "dag_id" [6475,6483]
===
match
---
operator: , [39818,39819]
operator: , [40540,40541]
===
match
---
operator: , [13804,13805]
operator: , [13804,13805]
===
match
---
string: "dag_id" [7927,7935]
string: "dag_id" [7927,7935]
===
match
---
string: "dag_id" [8480,8488]
string: "dag_id" [8480,8488]
===
match
---
simple_stmt [6437,7221]
simple_stmt [6437,7221]
===
match
---
atom_expr [25767,25779]
atom_expr [25767,25779]
===
match
---
operator: } [21656,21657]
operator: } [21656,21657]
===
match
---
param [31452,31454]
param [32174,32176]
===
match
---
simple_stmt [23346,23405]
simple_stmt [23346,23405]
===
match
---
operator: , [30002,30003]
operator: , [30002,30003]
===
match
---
operator: { [27523,27524]
operator: { [27523,27524]
===
match
---
name: SlaMiss [7380,7387]
name: SlaMiss [7380,7387]
===
match
---
param [7277,7282]
param [7277,7282]
===
match
---
string: "{'end_date': ['Not a valid datetime.']}" [36280,36321]
string: "{'end_date': ['Not a valid datetime.']}" [37002,37043]
===
match
---
simple_stmt [32045,32104]
simple_stmt [32767,32826]
===
match
---
name: RUNNING [2491,2498]
name: RUNNING [2491,2498]
===
match
---
name: DEFAULT_DATETIME_1 [19404,19422]
name: DEFAULT_DATETIME_1 [19404,19422]
===
match
---
trailer [29817,29825]
trailer [29817,29825]
===
match
---
string: "dry_run" [38102,38111]
string: "dry_run" [38824,38833]
===
match
---
trailer [41772,41784]
trailer [42494,42506]
===
match
---
operator: { [14439,14440]
operator: { [14439,14440]
===
match
---
operator: , [36955,36956]
operator: , [37677,37678]
===
match
---
dictorsetmaker [18452,18467]
dictorsetmaker [18452,18467]
===
match
---
atom [38042,38065]
atom [38764,38787]
===
match
---
operator: , [10304,10305]
operator: , [10304,10305]
===
match
---
atom [25247,31377]
atom [25247,32099]
===
match
---
name: State [27408,27413]
name: State [27408,27413]
===
match
---
trailer [15840,15844]
trailer [15840,15844]
===
match
---
parameters [35220,35226]
parameters [35942,35948]
===
match
---
import_from [995,1037]
import_from [995,1037]
===
match
---
operator: { [14760,14761]
operator: { [14760,14761]
===
match
---
dictorsetmaker [17736,17757]
dictorsetmaker [17736,17757]
===
match
---
operator: = [28855,28856]
operator: = [28855,28856]
===
match
---
argument [23216,23257]
argument [23216,23257]
===
match
---
atom_expr [33122,33357]
atom_expr [33844,34079]
===
match
---
atom [1970,2035]
atom [1970,2035]
===
match
---
operator: } [41094,41095]
operator: } [41816,41817]
===
match
---
operator: , [33505,33506]
operator: , [34227,34228]
===
match
---
string: "print_the_context" [41930,41949]
string: "print_the_context" [42652,42671]
===
match
---
atom_expr [19983,20003]
atom_expr [19983,20003]
===
match
---
comparison [16012,16063]
comparison [16012,16063]
===
match
---
trailer [7548,7561]
trailer [7548,7561]
===
match
---
suite [9630,17181]
suite [9630,17181]
===
match
---
operator: } [11918,11919]
operator: } [11918,11919]
===
match
---
name: DEFAULT_DATETIME_1 [31040,31058]
name: DEFAULT_DATETIME_1 [31040,31058]
===
match
---
name: dt [19504,19506]
name: dt [19504,19506]
===
match
---
decorator [25216,31384]
decorator [25216,32106]
===
match
---
name: delete_user [1287,1298]
name: delete_user [1287,1298]
===
match
---
operator: { [35353,35354]
operator: { [36075,36076]
===
match
---
name: status_code [32018,32029]
name: status_code [32740,32751]
===
match
---
name: expand [24098,24104]
name: expand [24098,24104]
===
match
---
dictorsetmaker [36246,36277]
dictorsetmaker [36968,36999]
===
match
---
operator: , [27420,27421]
operator: , [27420,27421]
===
match
---
decorators [17246,20659]
decorators [17246,20659]
===
match
---
atom_expr [22483,22496]
atom_expr [22483,22496]
===
match
---
string: "job_id" [2812,2820]
string: "job_id" [2812,2820]
===
match
---
operator: , [3382,3383]
operator: , [3382,3383]
===
match
---
name: status_code [23319,23330]
name: status_code [23319,23330]
===
match
---
operator: , [35465,35466]
operator: , [36187,36188]
===
match
---
name: post [39365,39369]
name: post [40087,40091]
===
match
---
string: "start_date" [25941,25953]
string: "start_date" [25941,25953]
===
match
---
atom [20192,20253]
atom [20192,20253]
===
match
---
trailer [39036,39278]
trailer [39758,40000]
===
match
---
string: "execution_date" [30668,30684]
string: "execution_date" [30668,30684]
===
match
---
number: 6 [8364,8365]
number: 6 [8364,8365]
===
match
---
name: get [6208,6211]
name: get [6208,6211]
===
match
---
operator: { [18797,18798]
operator: { [18797,18798]
===
match
---
name: ti_init [2403,2410]
name: ti_init [2403,2410]
===
match
---
operator: , [6596,6597]
operator: , [6596,6597]
===
match
---
operator: { [24129,24130]
operator: { [24129,24130]
===
match
---
trailer [33605,33612]
trailer [34327,34334]
===
match
---
arglist [7401,7562]
arglist [7401,7562]
===
match
---
atom [29185,29311]
atom [29185,29311]
===
match
---
atom_expr [3683,3697]
atom_expr [3683,3697]
===
match
---
funcdef [39864,40516]
funcdef [40586,41238]
===
match
---
name: self [4969,4973]
name: self [4969,4973]
===
match
---
dictorsetmaker [31934,31955]
dictorsetmaker [32656,32677]
===
match
---
trailer [33619,33625]
trailer [34341,34347]
===
match
---
name: response [32056,32064]
name: response [32778,32786]
===
match
---
operator: == [38485,38487]
operator: == [39207,39209]
===
match
---
operator: } [13583,13584]
operator: } [13583,13584]
===
match
---
trailer [3085,3132]
trailer [3085,3132]
===
match
---
name: update_extras [20868,20881]
name: update_extras [20868,20881]
===
match
---
name: app [2165,2168]
name: app [2165,2168]
===
match
---
string: "test_no_permissions" [9498,9519]
string: "test_no_permissions" [9498,9519]
===
match
---
operator: , [19046,19047]
operator: , [19046,19047]
===
match
---
operator: , [4326,4327]
operator: , [4326,4327]
===
match
---
name: response [43264,43272]
name: response [43986,43994]
===
match
---
suite [16746,16898]
suite [16746,16898]
===
match
---
simple_stmt [15667,15810]
simple_stmt [15667,15810]
===
match
---
operator: , [1713,1714]
operator: , [1713,1714]
===
match
---
fstring_start: f" [10714,10716]
fstring_start: f" [10714,10716]
===
match
---
operator: } [12137,12138]
operator: } [12137,12138]
===
match
---
string: "/api/v1/dags/example_python_operator/dagRuns/~/taskInstances" [16795,16857]
string: "/api/v1/dags/example_python_operator/dagRuns/~/taskInstances" [16795,16857]
===
match
---
name: session [4896,4903]
name: session [4896,4903]
===
match
---
string: 'task_id' [34434,34443]
string: 'task_id' [35156,35165]
===
match
---
arglist [37239,37378]
arglist [37961,38100]
===
match
---
trailer [10438,10448]
trailer [10438,10448]
===
match
---
trailer [16143,16165]
trailer [16143,16165]
===
match
---
funcdef [20663,21378]
funcdef [20663,21378]
===
match
---
operator: , [8144,8145]
operator: , [8144,8145]
===
match
---
parameters [20690,20797]
parameters [20690,20797]
===
match
---
operator: , [28097,28098]
operator: , [28097,28098]
===
match
---
trailer [21353,21358]
trailer [21353,21358]
===
match
---
atom_expr [37758,37785]
atom_expr [38480,38507]
===
match
---
dictorsetmaker [21956,22040]
dictorsetmaker [21956,22040]
===
match
---
string: "Naive datetime is disallowed" [24663,24693]
string: "Naive datetime is disallowed" [24663,24693]
===
match
---
operator: , [17126,17127]
operator: , [17126,17127]
===
match
---
operator: , [18118,18119]
operator: , [18118,18119]
===
match
---
name: self [37131,37135]
name: self [37853,37857]
===
match
---
assert_stmt [36069,36103]
assert_stmt [36791,36825]
===
match
---
trailer [9339,9343]
trailer [9339,9343]
===
match
---
simple_stmt [1170,1213]
simple_stmt [1170,1213]
===
match
---
trailer [43031,43036]
trailer [43753,43758]
===
match
---
string: 'task_id' [33952,33961]
string: 'task_id' [34674,34683]
===
match
---
operator: , [20981,20982]
operator: , [20981,20982]
===
match
---
operator: = [32897,32898]
operator: = [33619,33620]
===
match
---
dictorsetmaker [14485,14506]
dictorsetmaker [14485,14506]
===
match
---
trailer [32590,32600]
trailer [33312,33322]
===
match
---
name: task_instances [20924,20938]
name: task_instances [20924,20938]
===
match
---
decorator [9635,15538]
decorator [9635,15538]
===
match
---
dictorsetmaker [9910,9969]
dictorsetmaker [9910,9969]
===
match
---
name: response [22454,22462]
name: response [22454,22462]
===
match
---
string: 'REMOTE_USER' [24996,25009]
string: 'REMOTE_USER' [24996,25009]
===
match
---
operator: , [14879,14880]
operator: , [14879,14880]
===
match
---
trailer [35109,35114]
trailer [35831,35836]
===
match
---
operator: , [2724,2725]
operator: , [2724,2725]
===
match
---
operator: } [28750,28751]
operator: } [28750,28751]
===
match
---
name: days [32747,32751]
name: days [33469,33473]
===
match
---
operator: , [2823,2824]
operator: , [2823,2824]
===
match
---
atom_expr [21274,21304]
atom_expr [21274,21304]
===
match
---
string: "test_1" [21521,21529]
string: "test_1" [21521,21529]
===
match
---
simple_stmt [24043,24078]
simple_stmt [24043,24078]
===
match
---
suite [3698,4473]
suite [3698,4473]
===
match
---
expr_stmt [16755,16868]
expr_stmt [16755,16868]
===
match
---
string: "clear by task ids" [28411,28430]
string: "clear by task ids" [28411,28430]
===
match
---
atom_expr [7301,7336]
atom_expr [7301,7336]
===
match
---
operator: { [16388,16389]
operator: { [16388,16389]
===
match
---
trailer [7651,7658]
trailer [7651,7658]
===
match
---
string: "/api/v1/dags/example_python_operator/clearTaskInstances" [35277,35334]
string: "/api/v1/dags/example_python_operator/clearTaskInstances" [35999,36056]
===
match
---
atom_expr [6078,6176]
atom_expr [6078,6176]
===
match
---
string: 'execution_date' [34371,34387]
string: 'execution_date' [35093,35109]
===
match
---
atom_expr [23310,23330]
atom_expr [23310,23330]
===
match
---
operator: } [29104,29105]
operator: } [29104,29105]
===
match
---
atom [39465,39818]
atom [40187,40540]
===
match
---
name: client [9333,9339]
name: client [9333,9339]
===
match
---
arith_expr [29784,29825]
arith_expr [29784,29825]
===
match
---
operator: = [20166,20167]
operator: = [20166,20167]
===
match
---
operator: = [35245,35246]
operator: = [35967,35968]
===
match
---
string: "latest_only" [22141,22154]
string: "latest_only" [22141,22154]
===
match
---
atom_expr [9098,9231]
atom_expr [9098,9231]
===
match
---
argument [27913,27919]
argument [27913,27919]
===
match
---
number: 1 [11621,11622]
number: 1 [11621,11622]
===
match
---
operator: { [13928,13929]
operator: { [13928,13929]
===
match
---
name: client [15834,15840]
name: client [15834,15840]
===
match
---
name: configured_app [1551,1565]
name: configured_app [1551,1565]
===
match
---
trailer [26369,26377]
trailer [26369,26377]
===
match
---
name: TestTaskInstanceEndpoint [4831,4855]
name: TestTaskInstanceEndpoint [4831,4855]
===
match
---
param [31481,31493]
param [32203,32215]
===
match
---
argument [41329,41370]
argument [42051,42092]
===
match
---
argument [29818,29824]
argument [29818,29824]
===
match
---
dictorsetmaker [24414,24460]
dictorsetmaker [24414,24460]
===
match
---
operator: = [40050,40051]
operator: = [40772,40773]
===
match
---
simple_stmt [15818,15893]
simple_stmt [15818,15893]
===
match
---
atom_expr [35097,35133]
atom_expr [35819,35855]
===
match
---
string: "failed" [41072,41080]
string: "failed" [41794,41802]
===
match
---
operator: , [31658,31659]
operator: , [32380,32381]
===
match
---
string: "execution_date" [20193,20209]
string: "execution_date" [20193,20209]
===
match
---
operator: { [11087,11088]
operator: { [11087,11088]
===
match
---
name: past [39177,39181]
name: past [39899,39903]
===
match
---
atom [27835,27990]
atom [27835,27990]
===
match
---
operator: , [33531,33532]
operator: , [34253,34254]
===
match
---
operator: = [20966,20967]
operator: = [20966,20967]
===
match
---
name: dag [3531,3534]
name: dag [3531,3534]
===
match
---
operator: , [24398,24399]
operator: , [24398,24399]
===
match
---
argument [6114,6155]
argument [6114,6155]
===
match
---
simple_stmt [3882,3921]
simple_stmt [3882,3921]
===
match
---
trailer [33078,33086]
trailer [33800,33808]
===
match
---
trailer [31063,31073]
trailer [31063,31073]
===
match
---
operator: } [11367,11368]
operator: } [11367,11368]
===
match
---
name: self [35247,35251]
name: self [35969,35973]
===
match
---
argument [31970,31982]
argument [32692,32704]
===
match
---
string: "/api/v1/dags/example_python_operator/dagRuns/" [14122,14169]
string: "/api/v1/dags/example_python_operator/dagRuns/" [14122,14169]
===
match
---
argument [22211,22240]
argument [22211,22240]
===
match
---
operator: , [39546,39547]
operator: , [40268,40269]
===
match
---
param [21852,21860]
param [21852,21860]
===
match
---
name: key [4065,4068]
name: key [4065,4068]
===
match
---
operator: , [20782,20783]
operator: , [20782,20783]
===
match
---
atom [5124,5147]
atom [5124,5147]
===
match
---
string: 'TEST_DAG_RUN_ID_0' [33852,33871]
string: 'TEST_DAG_RUN_ID_0' [34574,34593]
===
match
---
number: 1 [25553,25554]
number: 1 [25553,25554]
===
match
---
name: tasks [3563,3568]
name: tasks [3563,3568]
===
match
---
operator: , [7770,7771]
operator: , [7770,7771]
===
match
---
argument [37091,37111]
argument [37813,37833]
===
match
---
name: State [33073,33078]
name: State [33795,33800]
===
match
---
string: 'dag_id' [33785,33793]
string: 'dag_id' [34507,34515]
===
match
---
operator: { [17368,17369]
operator: { [17368,17369]
===
match
---
dictorsetmaker [18929,18982]
dictorsetmaker [18929,18982]
===
match
---
argument [20909,20938]
argument [20909,20938]
===
match
---
operator: + [26532,26533]
operator: + [26532,26533]
===
match
---
simple_stmt [3807,3848]
simple_stmt [3807,3848]
===
match
---
operator: , [9012,9013]
operator: , [9012,9013]
===
match
---
name: days [9879,9883]
name: days [9879,9883]
===
match
---
arglist [4998,5148]
arglist [4998,5148]
===
match
---
name: provide_session [24717,24732]
name: provide_session [24717,24732]
===
match
---
string: "end_date" [6557,6567]
string: "end_date" [6557,6567]
===
match
---
operator: + [2647,2648]
operator: + [2647,2648]
===
match
---
name: self [40561,40565]
name: self [41283,41287]
===
match
---
param [41196,41200]
param [41918,41922]
===
match
---
dictorsetmaker [9767,9803]
dictorsetmaker [9767,9803]
===
match
---
param [31516,31523]
param [32238,32245]
===
match
---
name: permissions [1723,1734]
name: permissions [1723,1734]
===
match
---
operator: == [15982,15984]
operator: == [15982,15984]
===
match
---
string: "2020-01-01T00:00:00+00:00" [8080,8107]
string: "2020-01-01T00:00:00+00:00" [8080,8107]
===
match
---
name: response [23526,23534]
name: response [23526,23534]
===
match
---
simple_stmt [35236,35571]
simple_stmt [35958,36293]
===
match
---
trailer [37455,37460]
trailer [38177,38182]
===
match
---
testlist_comp [22705,22841]
testlist_comp [22705,22841]
===
match
---
atom_expr [23357,23388]
atom_expr [23357,23388]
===
match
---
string: 'sleep_for_3' [34921,34934]
string: 'sleep_for_3' [35643,35656]
===
match
---
arith_expr [25514,25555]
arith_expr [25514,25555]
===
match
---
suite [4145,4473]
suite [4145,4473]
===
match
---
name: self [3882,3886]
name: self [3882,3886]
===
match
---
operator: , [31586,31587]
operator: , [32308,32309]
===
match
---
assert_stmt [22505,22563]
assert_stmt [22505,22563]
===
match
---
operator: , [28473,28474]
operator: , [28473,28474]
===
match
---
string: "taskInstances?duration_gte=100&duration_lte=200" [12919,12968]
string: "taskInstances?duration_gte=100&duration_lte=200" [12919,12968]
===
match
---
simple_stmt [39915,40473]
simple_stmt [40637,41195]
===
match
---
name: DEFAULT_DATETIME_1 [1365,1383]
name: DEFAULT_DATETIME_1 [1365,1383]
===
match
---
param [3326,3346]
param [3326,3346]
===
match
---
name: State [3369,3374]
name: State [3369,3374]
===
match
---
parameters [23772,23778]
parameters [23772,23778]
===
match
---
argument [11057,11063]
argument [11057,11063]
===
match
---
string: "TEST_DAG_RUN_ID" [4580,4597]
string: "TEST_DAG_RUN_ID" [4580,4597]
===
match
---
string: "include_past" [42177,42191]
string: "include_past" [42899,42913]
===
match
---
operator: , [5316,5317]
operator: , [5316,5317]
===
match
---
argument [29995,30001]
argument [29995,30001]
===
match
---
operator: { [25882,25883]
operator: { [25882,25883]
===
match
---
operator: , [20854,20855]
operator: , [20854,20855]
===
match
---
name: parameterized [25217,25230]
name: parameterized [25217,25230]
===
match
---
simple_stmt [38948,38990]
simple_stmt [39670,39712]
===
match
---
operator: } [21529,21530]
operator: } [21529,21530]
===
match
---
name: session [37741,37748]
name: session [38463,38470]
===
match
---
trailer [37881,37885]
trailer [38603,38607]
===
match
---
atom [13928,13951]
atom [13928,13951]
===
match
---
string: "pool" [13929,13935]
string: "pool" [13929,13935]
===
match
---
argument [10449,10455]
argument [10449,10455]
===
match
---
trailer [9343,9531]
trailer [9343,9531]
===
match
---
string: '2020-01-03T00:00:00+00:00' [34389,34416]
string: '2020-01-03T00:00:00+00:00' [35111,35138]
===
match
---
atom [34725,34949]
atom [35447,35671]
===
match
---
suite [3865,3921]
suite [3865,3921]
===
match
---
name: expand [22657,22663]
name: expand [22657,22663]
===
match
---
dictorsetmaker [30845,30952]
dictorsetmaker [30845,30952]
===
match
---
name: task_instances [22168,22182]
name: task_instances [22168,22182]
===
match
---
atom_expr [2649,2669]
atom_expr [2649,2669]
===
match
---
string: "pid" [6804,6809]
string: "pid" [6804,6809]
===
match
---
name: self [4630,4634]
name: self [4630,4634]
===
match
---
string: "/taskInstances?queue=test_queue_1,test_queue_2" [15043,15091]
string: "/taskInstances?queue=test_queue_1,test_queue_2" [15043,15091]
===
match
---
number: 15 [22818,22820]
number: 15 [22818,22820]
===
match
---
string: "test" [16404,16410]
string: "test" [16404,16410]
===
match
---
expr_stmt [2351,2389]
expr_stmt [2351,2389]
===
match
---
operator: , [10457,10458]
operator: , [10457,10458]
===
match
---
operator: = [22377,22378]
operator: = [22377,22378]
===
match
---
operator: } [12291,12292]
operator: } [12291,12292]
===
match
---
suite [6069,7221]
suite [6069,7221]
===
match
---
operator: , [42504,42505]
operator: , [43226,43227]
===
match
---
name: self [31539,31543]
name: self [32261,32265]
===
match
---
name: session [15649,15656]
name: session [15649,15656]
===
match
---
parameters [35640,35646]
parameters [36362,36368]
===
match
---
atom [13973,13996]
atom [13973,13996]
===
match
---
operator: , [8302,8303]
operator: , [8302,8303]
===
match
---
operator: = [39086,39087]
operator: = [39808,39809]
===
match
---
trailer [22077,22099]
trailer [22077,22099]
===
match
---
name: default_time [4635,4647]
name: default_time [4635,4647]
===
match
---
name: json [39460,39464]
name: json [40182,40186]
===
match
---
name: environ_overrides [33464,33481]
name: environ_overrides [34186,34203]
===
match
---
name: _ [15597,15598]
name: _ [15597,15598]
===
match
---
number: 6 [6912,6913]
number: 6 [6912,6913]
===
match
---
argument [25725,25731]
argument [25725,25731]
===
match
---
name: task_instances [20909,20923]
name: task_instances [20909,20923]
===
match
---
atom_expr [41222,41748]
atom_expr [41944,42470]
===
match
---
operator: + [26355,26356]
operator: + [26355,26356]
===
match
---
name: assert_401 [23711,23721]
name: assert_401 [23711,23721]
===
match
---
dictorsetmaker [28976,29083]
dictorsetmaker [28976,29083]
===
match
---
string: "print_the_context" [39527,39546]
string: "print_the_context" [40249,40268]
===
match
---
trailer [21917,21924]
trailer [21917,21924]
===
match
---
number: 2 [26875,26876]
number: 2 [26875,26876]
===
match
---
param [32156,32161]
param [32878,32883]
===
match
---
string: "include_future" [39704,39720]
string: "include_future" [40426,40442]
===
match
---
expr_stmt [33733,34960]
expr_stmt [34455,35682]
===
match
---
trailer [15693,15809]
trailer [15693,15809]
===
match
---
dictorsetmaker [31253,31314]
dictorsetmaker [31253,31314]
===
match
---
operator: , [18228,18229]
operator: , [18228,18229]
===
match
---
name: clear_db_sla_miss [2961,2978]
name: clear_db_sla_miss [2961,2978]
===
match
---
trailer [39848,39858]
trailer [40570,40580]
===
match
---
trailer [27902,27912]
trailer [27902,27912]
===
match
---
atom [19251,19783]
atom [19251,19783]
===
match
---
atom_expr [20807,20992]
atom_expr [20807,20992]
===
match
---
atom [40742,41095]
atom [41464,41817]
===
match
---
name: query [16491,16496]
name: query [16491,16496]
===
match
---
atom_expr [31116,31128]
atom_expr [31116,31128]
===
match
---
operator: , [8872,8873]
operator: , [8872,8873]
===
match
---
name: self [31823,31827]
name: self [32545,32549]
===
match
---
operator: , [22840,22841]
operator: , [22840,22841]
===
match
---
string: "test_queue_1" [14770,14784]
string: "test_queue_1" [14770,14784]
===
match
---
string: "REMOTE_USER" [31934,31947]
string: "REMOTE_USER" [32656,32669]
===
match
---
trailer [35589,35599]
trailer [36311,36321]
===
match
---
dictorsetmaker [17930,17968]
dictorsetmaker [17930,17968]
===
match
---
operator: , [9450,9451]
operator: , [9450,9451]
===
match
---
string: "test" [31949,31955]
string: "test" [32671,32677]
===
match
---
trailer [4769,4773]
trailer [4769,4773]
===
match
---
operator: { [11895,11896]
operator: { [11895,11896]
===
match
---
operator: , [20480,20481]
operator: , [20480,20481]
===
match
---
suite [24824,25150]
suite [24824,25150]
===
match
---
param [36606,36611]
param [37328,37333]
===
match
---
trailer [32882,32892]
trailer [33604,33614]
===
match
---
simple_stmt [848,888]
simple_stmt [848,888]
===
match
---
dictorsetmaker [41882,42241]
dictorsetmaker [42604,42963]
===
match
---
name: client [16970,16976]
name: client [16970,16976]
===
match
---
operator: , [27443,27444]
operator: , [27443,27444]
===
match
---
name: sync_to_db [31762,31772]
name: sync_to_db [32484,32494]
===
match
---
funcdef [5999,7221]
funcdef [5999,7221]
===
match
---
operator: , [8904,8905]
operator: , [8904,8905]
===
match
---
dictorsetmaker [29481,29540]
dictorsetmaker [29481,29540]
===
match
---
name: timedelta [9952,9961]
name: timedelta [9952,9961]
===
match
---
string: "execution_date" [30845,30861]
string: "execution_date" [30845,30861]
===
match
---
operator: } [42745,42746]
operator: } [43467,43468]
===
match
---
trailer [9878,9886]
trailer [9878,9886]
===
match
---
simple_stmt [2398,2510]
simple_stmt [2398,2510]
===
match
---
operator: @ [17246,17247]
operator: @ [17246,17247]
===
match
---
name: sla_miss [7369,7377]
name: sla_miss [7369,7377]
===
match
---
dictorsetmaker [12107,12137]
dictorsetmaker [12107,12137]
===
match
---
number: 2 [14653,14654]
number: 2 [14653,14654]
===
match
---
name: DEFAULT_DATETIME_1 [25691,25709]
name: DEFAULT_DATETIME_1 [25691,25709]
===
match
---
fstring_end: " [11957,11958]
fstring_end: " [11957,11958]
===
match
---
name: update_extras [6157,6170]
name: update_extras [6157,6170]
===
match
---
operator: } [17439,17440]
operator: } [17439,17440]
===
match
---
string: "clear end date filter" [26103,26126]
string: "clear end date filter" [26103,26126]
===
match
---
operator: , [12773,12774]
operator: , [12773,12774]
===
match
---
trailer [38883,38910]
trailer [39605,39632]
===
match
---
number: 1 [36831,36832]
number: 1 [37553,37554]
===
match
---
operator: , [5623,5624]
operator: , [5623,5624]
===
match
---
trailer [29807,29817]
trailer [29807,29817]
===
match
---
name: permissions [2000,2011]
name: permissions [2000,2011]
===
match
---
name: DEFAULT_DATETIME_1 [9845,9863]
name: DEFAULT_DATETIME_1 [9845,9863]
===
match
---
name: query [33592,33597]
name: query [34314,34319]
===
match
---
operator: = [2666,2667]
operator: = [2666,2667]
===
match
---
name: response [35101,35109]
name: response [35823,35831]
===
match
---
name: DEFAULT_DATETIME_1 [29607,29625]
name: DEFAULT_DATETIME_1 [29607,29625]
===
match
---
simple_stmt [39838,39859]
simple_stmt [40560,40581]
===
match
---
funcdef [1547,2224]
funcdef [1547,2224]
===
match
---
name: days [19996,20000]
name: days [19996,20000]
===
match
---
string: "REMOTE_USER" [6352,6365]
string: "REMOTE_USER" [6352,6365]
===
match
---
name: total_ti [23454,23462]
name: total_ti [23454,23462]
===
match
---
testlist_comp [13928,14042]
testlist_comp [13928,14042]
===
match
---
string: "timestamp" [8762,8773]
string: "timestamp" [8762,8773]
===
match
---
atom [29480,29541]
atom [29480,29541]
===
match
---
string: "task" [21553,21559]
string: "task" [21553,21559]
===
match
---
expr_stmt [3065,3132]
expr_stmt [3065,3132]
===
match
---
string: "dry_run" [41882,41891]
string: "dry_run" [42604,42613]
===
match
---
atom_expr [36860,36873]
atom_expr [37582,37595]
===
match
---
number: 4 [30401,30402]
number: 4 [30401,30402]
===
match
---
trailer [38958,38968]
trailer [39680,39690]
===
match
---
operator: , [12715,12716]
operator: , [12715,12716]
===
match
---
operator: , [19222,19223]
operator: , [19222,19223]
===
match
---
string: "test" [21135,21141]
string: "test" [21135,21141]
===
match
---
operator: , [28326,28327]
operator: , [28326,28327]
===
match
---
atom_expr [20232,20252]
atom_expr [20232,20252]
===
match
---
atom [29256,29292]
atom [29256,29292]
===
match
---
operator: , [29292,29293]
operator: , [29292,29293]
===
match
---
atom_expr [12194,12214]
atom_expr [12194,12214]
===
match
---
simple_stmt [33552,33682]
simple_stmt [34274,34404]
===
match
---
atom_expr [27900,27920]
atom_expr [27900,27920]
===
match
---
dictorsetmaker [13117,13132]
dictorsetmaker [13117,13132]
===
match
---
string: "example_python_operator" [27480,27505]
string: "example_python_operator" [27480,27505]
===
match
---
string: "2020-01-03T00:00:00+00:00" [8021,8048]
string: "2020-01-03T00:00:00+00:00" [8021,8048]
===
match
---
operator: , [2105,2106]
operator: , [2105,2106]
===
match
---
dotted_name [24084,24104]
dotted_name [24084,24104]
===
match
---
name: json [16025,16029]
name: json [16025,16029]
===
match
---
string: "/api/v1/dags/~/dagRuns/~/taskInstances/list" [24918,24963]
string: "/api/v1/dags/~/dagRuns/~/taskInstances/list" [24918,24963]
===
match
---
operator: } [33504,33505]
operator: } [34226,34227]
===
match
---
dictorsetmaker [40701,40722]
dictorsetmaker [41423,41444]
===
match
---
argument [29641,29647]
argument [29641,29647]
===
match
---
number: 3 [30000,30001]
number: 3 [30000,30001]
===
match
---
operator: , [29440,29441]
operator: , [29440,29441]
===
match
---
argument [2075,2105]
argument [2075,2105]
===
match
---
atom [18072,18228]
atom [18072,18228]
===
match
---
string: 'print_the_context' [38784,38803]
string: 'print_the_context' [39506,39525]
===
match
---
atom_expr [4914,4949]
atom_expr [4914,4949]
===
match
---
atom [18185,18209]
atom [18185,18209]
===
match
---
trailer [22541,22546]
trailer [22541,22546]
===
match
---
operator: , [40668,40669]
operator: , [41390,41391]
===
match
---
trailer [32069,32087]
trailer [32791,32809]
===
match
---
atom_expr [25590,25602]
atom_expr [25590,25602]
===
match
---
name: FAILED [26263,26269]
name: FAILED [26263,26269]
===
match
---
operator: } [41736,41737]
operator: } [42458,42459]
===
match
---
string: 'failed' [39206,39214]
string: 'failed' [39928,39936]
===
match
---
trailer [21924,22064]
trailer [21924,22064]
===
match
---
operator: { [12737,12738]
operator: { [12737,12738]
===
match
---
operator: , [5918,5919]
operator: , [5918,5919]
===
match
---
fstring_start: f" [4237,4239]
fstring_start: f" [4237,4239]
===
match
---
string: "pool" [14485,14491]
string: "pool" [14485,14491]
===
match
---
operator: = [31606,31607]
operator: = [32328,32329]
===
match
---
operator: = [39205,39206]
operator: = [39927,39928]
===
match
---
operator: = [7543,7544]
operator: = [7543,7544]
===
match
---
simple_stmt [7301,7337]
simple_stmt [7301,7337]
===
match
---
atom [12637,12773]
atom [12637,12773]
===
match
---
operator: , [25919,25920]
operator: , [25919,25920]
===
match
---
operator: { [32531,32532]
operator: { [33253,33254]
===
match
---
name: expected_ti_count [21320,21337]
name: expected_ti_count [21320,21337]
===
match
---
argument [9879,9885]
argument [9879,9885]
===
match
---
operator: } [33100,33101]
operator: } [33822,33823]
===
match
---
arith_expr [32859,32900]
arith_expr [33581,33622]
===
match
---
dictorsetmaker [28799,28906]
dictorsetmaker [28799,28906]
===
match
---
operator: , [23944,23945]
operator: , [23944,23945]
===
match
---
parameters [9301,9307]
parameters [9301,9307]
===
match
---
atom [17088,17126]
atom [17088,17126]
===
match
---
name: status_code [25080,25091]
name: status_code [25080,25091]
===
match
---
trailer [12283,12291]
trailer [12283,12291]
===
match
---
string: "start_date" [36430,36442]
string: "start_date" [37152,37164]
===
match
---
fstring_string: &start_date_lte= [11328,11344]
fstring_string: &start_date_lte= [11328,11344]
===
match
---
atom_expr [3956,3964]
atom_expr [3956,3964]
===
match
---
expr_stmt [35236,35570]
expr_stmt [35958,36292]
===
match
---
string: "state" [29674,29681]
string: "state" [29674,29681]
===
match
---
operator: , [29695,29696]
operator: , [29695,29696]
===
match
---
argument [4715,4734]
argument [4715,4734]
===
match
---
name: timedelta [9869,9878]
name: timedelta [9869,9878]
===
match
---
operator: , [20087,20088]
operator: , [20087,20088]
===
match
---
string: "test_no_permissions" [35802,35823]
string: "test_no_permissions" [36524,36545]
===
match
---
string: "test end date filter ~" [12042,12066]
string: "test end date filter ~" [12042,12066]
===
match
---
parameters [2311,2333]
parameters [2311,2333]
===
match
---
decorators [9635,15559]
decorators [9635,15559]
===
match
---
decorated [36109,37483]
decorated [36831,38205]
===
match
---
operator: , [10815,10816]
operator: , [10815,10816]
===
match
---
atom_expr [32927,32940]
atom_expr [33649,33662]
===
match
---
operator: , [10555,10556]
operator: , [10555,10556]
===
match
---
atom_expr [7852,7872]
atom_expr [7852,7872]
===
match
---
funcdef [15563,16064]
funcdef [15563,16064]
===
match
---
testlist_comp [24129,24207]
testlist_comp [24129,24207]
===
match
---
atom [24608,24694]
atom [24608,24694]
===
match
---
fstring_end: " [12512,12513]
fstring_end: " [12512,12513]
===
match
---
name: client [23804,23810]
name: client [23804,23810]
===
match
---
name: payload [36612,36619]
name: payload [37334,37341]
===
match
---
dictorsetmaker [24130,24174]
dictorsetmaker [24130,24174]
===
match
---
operator: } [24460,24461]
operator: } [24460,24461]
===
match
---
name: response [36076,36084]
name: response [36798,36806]
===
match
---
operator: , [42259,42260]
operator: , [42981,42982]
===
match
---
string: "test duration filter ~" [13052,13076]
string: "test duration filter ~" [13052,13076]
===
match
---
operator: , [7520,7521]
operator: , [7520,7521]
===
match
---
atom [20418,20586]
atom [20418,20586]
===
match
---
testlist_comp [13116,13212]
testlist_comp [13116,13212]
===
match
---
atom_expr [36076,36096]
atom_expr [36798,36818]
===
match
---
name: dt [18962,18964]
name: dt [18962,18964]
===
match
---
operator: , [4894,4895]
operator: , [4894,4895]
===
match
---
comparison [3581,3607]
comparison [3581,3607]
===
match
---
name: payload [43187,43194]
name: payload [43909,43916]
===
match
---
operator: , [30620,30621]
operator: , [30620,30621]
===
match
---
operator: } [7219,7220]
operator: } [7219,7220]
===
match
---
operator: , [21691,21692]
operator: , [21691,21692]
===
match
---
classdef [2226,4803]
classdef [2226,4803]
===
match
---
string: "test pool filter" [13870,13888]
string: "test pool filter" [13870,13888]
===
match
---
atom_expr [17153,17173]
atom_expr [17153,17173]
===
match
---
name: State [32781,32786]
name: State [33503,33508]
===
match
---
string: "example_python_operator" [36976,37001]
string: "example_python_operator" [37698,37723]
===
match
---
atom_expr [4630,4647]
atom_expr [4630,4647]
===
match
---
dictorsetmaker [29589,29696]
dictorsetmaker [29589,29696]
===
match
---
operator: , [36322,36323]
operator: , [37044,37045]
===
match
---
name: DagRun [4518,4524]
name: DagRun [4518,4524]
===
match
---
decorator [22878,22895]
decorator [22878,22895]
===
match
---
name: value [4004,4009]
name: value [4004,4009]
===
match
---
comparison [35028,35076]
comparison [35750,35798]
===
match
---
name: session [16166,16173]
name: session [16166,16173]
===
match
---
operator: , [930,931]
operator: , [930,931]
===
match
---
argument [38079,38437]
argument [38801,39159]
===
match
---
name: status_code [5183,5194]
name: status_code [5183,5194]
===
match
---
operator: , [20707,20708]
operator: , [20707,20708]
===
match
---
name: tasks [3956,3961]
name: tasks [3956,3961]
===
match
---
string: "duration" [13195,13205]
string: "duration" [13195,13205]
===
match
---
atom_expr [25712,25732]
atom_expr [25712,25732]
===
match
---
string: "execution_date" [19944,19960]
string: "execution_date" [19944,19960]
===
match
---
operator: = [21160,21161]
operator: = [21160,21161]
===
match
---
trailer [9109,9113]
trailer [9109,9113]
===
match
---
argument [30897,30903]
argument [30897,30903]
===
match
---
operator: == [23331,23333]
operator: == [23331,23333]
===
match
---
atom_expr [2058,2137]
atom_expr [2058,2137]
===
match
---
operator: , [29035,29036]
operator: , [29035,29036]
===
match
---
operator: = [3557,3558]
operator: = [3557,3558]
===
match
---
number: 0 [5946,5947]
number: 0 [5946,5947]
===
match
---
operator: = [33333,33334]
operator: = [34055,34056]
===
match
---
simple_stmt [2159,2169]
simple_stmt [2159,2169]
===
match
---
number: 403 [40512,40515]
number: 403 [41234,41237]
===
match
---
operator: , [11976,11977]
operator: , [11976,11977]
===
match
---
number: 2 [30902,30903]
number: 2 [30902,30903]
===
match
---
atom_expr [27955,27967]
atom_expr [27955,27967]
===
match
---
operator: = [28678,28679]
operator: = [28678,28679]
===
match
---
operator: , [4002,4003]
operator: , [4002,4003]
===
match
---
atom_expr [30707,30727]
atom_expr [30707,30727]
===
match
---
string: "clear only failed" [27650,27669]
string: "clear only failed" [27650,27669]
===
match
---
string: "Naive datetime is disallowed" [24367,24397]
string: "Naive datetime is disallowed" [24367,24397]
===
match
---
number: 0 [8199,8200]
number: 0 [8199,8200]
===
match
---
dictorsetmaker [13470,13492]
dictorsetmaker [13470,13492]
===
match
---
operator: , [5369,5370]
operator: , [5369,5370]
===
match
---
name: single_dag_run [20967,20981]
name: single_dag_run [20967,20981]
===
match
---
param [21820,21835]
param [21820,21835]
===
match
---
string: "failed" [39795,39803]
string: "failed" [40517,40525]
===
match
---
dictorsetmaker [25388,25447]
dictorsetmaker [25388,25447]
===
match
---
name: task_instances [3326,3340]
name: task_instances [3326,3340]
===
match
---
string: "pool" [14440,14446]
string: "pool" [14440,14446]
===
match
---
arglist [7676,7826]
arglist [7676,7826]
===
match
---
name: RESOURCE_DAG [1791,1803]
name: RESOURCE_DAG [1791,1803]
===
match
---
arglist [16210,16244]
arglist [16210,16244]
===
match
---
name: delete_user [2174,2185]
name: delete_user [2174,2185]
===
match
---
string: "state" [18141,18148]
string: "state" [18141,18148]
===
match
---
trailer [21023,21028]
trailer [21023,21028]
===
match
---
name: post [33389,33393]
name: post [34111,34115]
===
match
---
testlist_comp [21428,21692]
testlist_comp [21428,21692]
===
match
---
name: self [39353,39357]
name: self [40075,40079]
===
match
---
trailer [38870,38878]
trailer [39592,39600]
===
match
---
name: State [30607,30612]
name: State [30607,30612]
===
match
---
operator: , [28550,28551]
operator: , [28550,28551]
===
match
---
operator: , [41645,41646]
operator: , [42367,42368]
===
match
---
operator: , [25821,25822]
operator: , [25821,25822]
===
match
---
operator: + [20544,20545]
operator: + [20544,20545]
===
match
---
atom_expr [28661,28681]
atom_expr [28661,28681]
===
match
---
number: 100 [18644,18647]
number: 100 [18644,18647]
===
match
---
name: session [21880,21887]
name: session [21880,21887]
===
match
---
string: "only_failed" [27563,27576]
string: "only_failed" [27563,27576]
===
match
---
operator: , [42811,42812]
operator: , [43533,43534]
===
match
---
name: SUCCESS [13576,13583]
name: SUCCESS [13576,13583]
===
match
---
trailer [25547,25555]
trailer [25547,25555]
===
match
---
operator: , [26056,26057]
operator: , [26056,26057]
===
match
---
atom_expr [30884,30904]
atom_expr [30884,30904]
===
match
---
name: payload [31494,31501]
name: payload [32216,32223]
===
match
---
string: 'execution_date' [34847,34863]
string: 'execution_date' [35569,35585]
===
match
---
testlist_comp [29377,30403]
testlist_comp [29377,30403]
===
match
---
name: response [21224,21232]
name: response [21224,21232]
===
match
---
name: provide_session [21715,21730]
name: provide_session [21715,21730]
===
match
---
name: self [7503,7507]
name: self [7503,7507]
===
match
---
operator: , [6692,6693]
operator: , [6692,6693]
===
match
---
name: datetime [1161,1169]
name: datetime [1161,1169]
===
match
---
expr_stmt [35656,36060]
expr_stmt [36378,36782]
===
match
---
operator: , [18251,18252]
operator: , [18251,18252]
===
match
---
expr_stmt [37906,38448]
expr_stmt [38628,39170]
===
match
---
dictorsetmaker [38538,38836]
dictorsetmaker [39260,39558]
===
match
---
simple_stmt [16183,16246]
simple_stmt [16183,16246]
===
match
---
string: "{}" [5461,5465]
string: "{}" [5461,5465]
===
match
---
operator: , [2316,2317]
operator: , [2316,2317]
===
match
---
name: airflow [1043,1050]
name: airflow [1043,1050]
===
match
---
operator: , [35917,35918]
operator: , [36639,36640]
===
match
---
name: environ_overrides [15850,15867]
name: environ_overrides [15850,15867]
===
match
---
argument [36969,37001]
argument [37691,37723]
===
match
---
trailer [3069,3076]
trailer [3069,3076]
===
match
---
atom_expr [1848,1876]
atom_expr [1848,1876]
===
match
---
name: dag_id [33190,33196]
name: dag_id [33912,33918]
===
match
---
trailer [2185,2207]
trailer [2185,2207]
===
match
---
string: "pool" [2738,2744]
string: "pool" [2738,2744]
===
match
---
operator: , [42155,42156]
operator: , [42877,42878]
===
match
---
string: "test execution date filter" [9698,9726]
string: "test execution date filter" [9698,9726]
===
match
---
parameters [16739,16745]
parameters [16739,16745]
===
match
---
argument [20328,20334]
argument [20328,20334]
===
match
---
operator: } [25801,25802]
operator: } [25801,25802]
===
match
---
atom_expr [9240,9260]
atom_expr [9240,9260]
===
match
---
param [42937,42946]
param [43659,43668]
===
match
---
operator: = [3485,3486]
operator: = [3485,3486]
===
match
---
string: "/api/v1/dags/example_python_operator/updateTaskInstancesState" [39383,39446]
string: "/api/v1/dags/example_python_operator/updateTaskInstancesState" [40105,40168]
===
match
---
fstring [11301,11369]
fstring [11301,11369]
===
match
---
operator: { [25387,25388]
operator: { [25387,25388]
===
match
---
name: test_should_respond_200_when_task_instance_properties_are_none [21739,21801]
name: test_should_respond_200_when_task_instance_properties_are_none [21739,21801]
===
match
---
expr_stmt [4162,4440]
expr_stmt [4162,4440]
===
match
---
string: "failed" [38414,38422]
string: "failed" [39136,39144]
===
match
---
string: "end_date" [11647,11657]
string: "end_date" [11647,11657]
===
match
---
name: State [36860,36865]
name: State [37582,37587]
===
match
---
trailer [7618,7625]
trailer [7618,7625]
===
match
---
string: "2020-01-01T00:00:00+00:00" [1432,1459]
string: "2020-01-01T00:00:00+00:00" [1432,1459]
===
match
---
operator: { [21512,21513]
operator: { [21512,21513]
===
match
---
operator: , [32900,32901]
operator: , [33622,33623]
===
match
---
argument [19996,20002]
argument [19996,20002]
===
match
---
operator: , [14302,14303]
operator: , [14302,14303]
===
match
---
string: "email_sent" [8570,8582]
string: "email_sent" [8570,8582]
===
match
---
operator: , [14354,14355]
operator: , [14354,14355]
===
match
---
operator: = [27370,27371]
operator: = [27370,27371]
===
match
---
operator: , [5652,5653]
operator: , [5652,5653]
===
match
---
simple_stmt [41211,41749]
simple_stmt [41933,42471]
===
match
---
operator: , [32160,32161]
operator: , [32882,32883]
===
match
---
name: include_examples [3086,3102]
name: include_examples [3086,3102]
===
match
---
name: failed_dag_runs [33552,33567]
name: failed_dag_runs [34274,34289]
===
match
---
atom_expr [4518,4749]
atom_expr [4518,4749]
===
match
---
operator: , [32809,32810]
operator: , [33531,33532]
===
match
---
expr_stmt [2843,2868]
expr_stmt [2843,2868]
===
match
---
arith_expr [10494,10535]
arith_expr [10494,10535]
===
match
---
operator: , [8365,8366]
operator: , [8365,8366]
===
match
---
string: 'REMOTE_USER' [40052,40065]
string: 'REMOTE_USER' [40774,40787]
===
match
---
decorators [25216,31405]
decorators [25216,32127]
===
match
---
name: ti_init [4301,4308]
name: ti_init [4301,4308]
===
match
---
atom_expr [40488,40508]
atom_expr [41210,41230]
===
match
---
operator: = [9883,9884]
operator: = [9883,9884]
===
match
---
argument [23271,23283]
argument [23271,23283]
===
match
---
atom_expr [28561,28573]
atom_expr [28561,28573]
===
match
---
atom_expr [16439,16459]
atom_expr [16439,16459]
===
match
---
name: DEFAULT_DATETIME_1 [19902,19920]
name: DEFAULT_DATETIME_1 [19902,19920]
===
match
---
name: RUNNING [13485,13492]
name: RUNNING [13485,13492]
===
match
---
operator: , [29872,29873]
operator: , [29872,29873]
===
match
---
trailer [3534,3540]
trailer [3534,3540]
===
match
---
trailer [38866,38870]
trailer [39588,39592]
===
match
---
trailer [17161,17173]
trailer [17161,17173]
===
match
---
operator: , [22154,22155]
operator: , [22154,22155]
===
match
---
simple_stmt [9240,9261]
simple_stmt [9240,9261]
===
match
---
arith_expr [18941,18982]
arith_expr [18941,18982]
===
match
---
name: include_examples [2996,3012]
name: include_examples [2996,3012]
===
match
---
operator: { [24413,24414]
operator: { [24413,24414]
===
match
---
operator: = [2852,2853]
operator: = [2852,2853]
===
match
---
argument [22415,22427]
argument [22415,22427]
===
match
---
string: 'execution_date' [34133,34149]
string: 'execution_date' [34855,34871]
===
match
---
name: session [36948,36955]
name: session [37670,37677]
===
match
---
name: DEFAULT_DATETIME_STR_2 [12489,12511]
name: DEFAULT_DATETIME_STR_2 [12489,12511]
===
match
---
string: "total_entries" [22547,22562]
string: "total_entries" [22547,22562]
===
match
---
dictorsetmaker [33785,33983]
dictorsetmaker [34507,34705]
===
match
---
simple_stmt [1622,2054]
simple_stmt [1622,2054]
===
match
---
operator: == [37471,37473]
operator: == [38193,38195]
===
match
---
atom_expr [25535,25555]
atom_expr [25535,25555]
===
match
---
operator: , [18906,18907]
operator: , [18906,18907]
===
match
---
operator: , [41422,41423]
operator: , [42144,42145]
===
match
---
operator: , [2498,2499]
operator: , [2498,2499]
===
match
---
name: len [22600,22603]
name: len [22600,22603]
===
match
---
arith_expr [11659,11700]
arith_expr [11659,11700]
===
match
---
atom [17659,18003]
atom [17659,18003]
===
match
---
simple_stmt [43257,43300]
simple_stmt [43979,44022]
===
match
---
simple_stmt [25107,25150]
simple_stmt [25107,25150]
===
match
---
trailer [33381,33388]
trailer [34103,34110]
===
match
---
name: DEFAULT_DATETIME_1 [27154,27172]
name: DEFAULT_DATETIME_1 [27154,27172]
===
match
---
name: parameterized [874,887]
name: parameterized [874,887]
===
match
---
atom [11760,11976]
atom [11760,11976]
===
match
---
trailer [23005,23027]
trailer [23005,23027]
===
match
---
atom_expr [23537,23702]
atom_expr [23537,23702]
===
match
---
comparison [37404,37431]
comparison [38126,38153]
===
match
---
operator: = [31719,31720]
operator: = [32441,32442]
===
match
---
name: json [43182,43186]
name: json [43904,43908]
===
match
---
simple_stmt [22447,22497]
simple_stmt [22447,22497]
===
match
---
operator: , [4421,4422]
operator: , [4421,4422]
===
match
---
simple_stmt [1299,1364]
simple_stmt [1299,1364]
===
match
---
arith_expr [11023,11064]
arith_expr [11023,11064]
===
match
---
name: timedelta [27356,27365]
name: timedelta [27356,27365]
===
match
---
classdef [37485,43300]
classdef [38207,44022]
===
match
---
operator: , [39642,39643]
operator: , [40364,40365]
===
match
---
operator: , [13133,13134]
operator: , [13133,13134]
===
match
---
operator: } [30619,30620]
operator: } [30619,30620]
===
match
---
name: task_instances [32424,32438]
name: task_instances [33146,33160]
===
match
---
operator: == [5231,5233]
operator: == [5231,5233]
===
match
---
simple_stmt [7345,7361]
simple_stmt [7345,7361]
===
match
---
string: "executor_config" [8121,8138]
string: "executor_config" [8121,8138]
===
match
---
string: "example_python_operator" [25322,25347]
string: "example_python_operator" [25322,25347]
===
match
---
param [20709,20724]
param [20709,20724]
===
match
---
name: dt [27353,27355]
name: dt [27353,27355]
===
match
---
string: "duration" [5297,5307]
string: "duration" [5297,5307]
===
match
---
name: RUNNING [28138,28145]
name: RUNNING [28138,28145]
===
match
---
name: self [2629,2633]
name: self [2629,2633]
===
match
---
operator: } [4257,4258]
operator: } [4257,4258]
===
match
---
trailer [33644,33646]
trailer [34366,34368]
===
match
---
operator: + [20064,20065]
operator: + [20064,20065]
===
match
---
operator: @ [22878,22879]
operator: @ [22878,22879]
===
match
---
expr_stmt [38856,38910]
expr_stmt [39578,39632]
===
match
---
atom_expr [16965,17137]
atom_expr [16965,17137]
===
match
---
simple_stmt [6185,6386]
simple_stmt [6185,6386]
===
match
---
trailer [26359,26369]
trailer [26359,26369]
===
match
---
name: app [1592,1595]
name: app [1592,1595]
===
match
---
trailer [9868,9878]
trailer [9868,9878]
===
match
---
comparison [21253,21304]
comparison [21253,21304]
===
match
---
name: clear_db_runs [2937,2950]
name: clear_db_runs [2937,2950]
===
match
---
simple_stmt [16954,17138]
simple_stmt [16954,17138]
===
match
---
operator: } [15890,15891]
operator: } [15890,15891]
===
match
---
name: url [15845,15848]
name: url [15845,15848]
===
match
---
number: 0 [5520,5521]
number: 0 [5520,5521]
===
match
---
dictorsetmaker [29766,29873]
dictorsetmaker [29766,29873]
===
match
---
name: test_should_raise_400_for_naive_and_bad_datetime [42873,42921]
name: test_should_raise_400_for_naive_and_bad_datetime [43595,43643]
===
match
---
operator: , [33306,33307]
operator: , [34028,34029]
===
match
---
name: create_task_instances [20812,20833]
name: create_task_instances [20812,20833]
===
match
---
argument [6157,6175]
argument [6157,6175]
===
match
---
name: State [25590,25595]
name: State [25590,25595]
===
match
---
operator: { [21938,21939]
operator: { [21938,21939]
===
match
---
name: TestGetTaskInstancesBatch [17189,17214]
name: TestGetTaskInstancesBatch [17189,17214]
===
match
---
simple_stmt [23303,23338]
simple_stmt [23303,23338]
===
match
---
string: "include_downstream" [42572,42592]
string: "include_downstream" [43294,43314]
===
match
---
atom_expr [20315,20335]
atom_expr [20315,20335]
===
match
---
atom [24129,24175]
atom [24129,24175]
===
match
---
operator: , [41897,41898]
operator: , [42619,42620]
===
match
---
name: self [15591,15595]
name: self [15591,15595]
===
match
---
string: "execution_date" [32987,33003]
string: "execution_date" [33709,33725]
===
match
---
operator: = [9326,9327]
operator: = [9326,9327]
===
match
---
operator: = [1596,1597]
operator: = [1596,1597]
===
match
---
operator: , [18468,18469]
operator: , [18468,18469]
===
match
---
operator: , [20620,20621]
operator: , [20620,20621]
===
match
---
name: api_connexion_utils [1235,1254]
name: api_connexion_utils [1235,1254]
===
match
---
operator: , [13211,13212]
operator: , [13211,13212]
===
match
---
name: timedelta [10439,10448]
name: timedelta [10439,10448]
===
match
---
operator: , [41722,41723]
operator: , [42444,42445]
===
match
---
operator: , [40823,40824]
operator: , [41545,41546]
===
match
---
atom [25387,25448]
atom [25387,25448]
===
match
---
string: "hostname" [8158,8168]
string: "hostname" [8158,8168]
===
match
---
string: "state" [33064,33071]
string: "state" [33786,33793]
===
match
---
operator: , [2669,2670]
operator: , [2669,2670]
===
match
---
name: session [42947,42954]
name: session [43669,43676]
===
match
---
atom [21641,21656]
atom [21641,21656]
===
match
---
parameters [7276,7291]
parameters [7276,7291]
===
match
---
operator: , [1646,1647]
operator: , [1646,1647]
===
match
---
name: run_type [4665,4673]
name: run_type [4665,4673]
===
match
---
name: role_name [2107,2116]
name: role_name [2107,2116]
===
match
---
fstring_expr [11933,11957]
fstring_expr [11933,11957]
===
match
---
name: username [2075,2083]
name: username [2075,2083]
===
match
---
name: DEFAULT_DATETIME_1 [28056,28074]
name: DEFAULT_DATETIME_1 [28056,28074]
===
match
---
operator: , [32404,32405]
operator: , [33126,33127]
===
match
---
string: "Test" [1707,1713]
string: "Test" [1707,1713]
===
match
---
operator: , [39138,39139]
operator: , [39860,39861]
===
match
---
dictorsetmaker [19628,19731]
dictorsetmaker [19628,19731]
===
match
---
parameters [41195,41201]
parameters [41917,41923]
===
match
---
name: self [9072,9076]
name: self [9072,9076]
===
match
---
operator: + [25710,25711]
operator: + [25710,25711]
===
match
---
string: "print_the_context" [7126,7145]
string: "print_the_context" [7126,7145]
===
match
---
name: test_should_respond_200 [31413,31436]
name: test_should_respond_200 [32135,32158]
===
match
---
param [1566,1585]
param [1566,1585]
===
match
---
expr_stmt [9317,9531]
expr_stmt [9317,9531]
===
match
---
string: "execution_date" [27861,27877]
string: "execution_date" [27861,27877]
===
match
---
name: days [19517,19521]
name: days [19517,19521]
===
match
---
string: "duration" [7976,7986]
string: "duration" [7976,7986]
===
match
---
operator: = [3077,3078]
operator: = [3077,3078]
===
match
---
testlist_comp [13052,13364]
testlist_comp [13052,13364]
===
match
---
string: "reset_dag_runs" [35895,35911]
string: "reset_dag_runs" [36617,36633]
===
match
---
import_from [1170,1212]
import_from [1170,1212]
===
match
---
string: "default_queue" [2783,2798]
string: "default_queue" [2783,2798]
===
match
---
simple_stmt [38998,39279]
simple_stmt [39720,40001]
===
match
---
name: json [41384,41388]
name: json [42106,42110]
===
match
---
name: State [33334,33339]
name: State [34056,34061]
===
match
---
atom_expr [32009,32029]
atom_expr [32731,32751]
===
match
---
operator: , [43194,43195]
operator: , [43916,43917]
===
match
---
string: "/api/v1/dags/example_python_operator/updateTaskInstancesState" [37947,38010]
string: "/api/v1/dags/example_python_operator/updateTaskInstancesState" [38669,38732]
===
match
---
trailer [36815,36825]
trailer [37537,37547]
===
match
---
argument [40033,40089]
argument [40755,40811]
===
match
---
fstring_string: /clearTaskInstances [33430,33449]
fstring_string: /clearTaskInstances [34152,34171]
===
match
---
testlist_comp [30449,31352]
testlist_comp [30449,31352]
===
match
---
operator: , [35544,35545]
operator: , [36266,36267]
===
match
---
name: dt [32734,32736]
name: dt [33456,33458]
===
match
---
operator: , [30072,30073]
operator: , [30072,30073]
===
match
---
string: "start_date" [7028,7040]
string: "start_date" [7028,7040]
===
match
---
name: autouse [2278,2285]
name: autouse [2278,2285]
===
match
---
argument [31672,31691]
argument [32394,32413]
===
match
---
operator: , [15798,15799]
operator: , [15798,15799]
===
match
---
name: self [2877,2881]
name: self [2877,2881]
===
match
---
arglist [40617,41096]
arglist [41339,41818]
===
match
---
string: "default_queue" [5709,5724]
string: "default_queue" [5709,5724]
===
match
---
name: FAILED [30945,30951]
name: FAILED [30945,30951]
===
match
---
operator: , [22722,22723]
operator: , [22722,22723]
===
match
---
operator: , [5521,5522]
operator: , [5521,5522]
===
match
---
operator: + [32732,32733]
operator: + [33454,33455]
===
match
---
string: "example_python_operator" [26661,26686]
string: "example_python_operator" [26661,26686]
===
match
---
operator: , [28728,28729]
operator: , [28728,28729]
===
match
---
operator: } [18668,18669]
operator: } [18668,18669]
===
match
---
string: "example_python_operator" [29142,29167]
string: "example_python_operator" [29142,29167]
===
match
---
atom_expr [33613,33625]
atom_expr [34335,34347]
===
match
---
name: patch [37557,37562]
name: patch [38279,38284]
===
match
---
comparison [6444,7220]
comparison [6444,7220]
===
match
---
string: "execution_date" [28622,28638]
string: "execution_date" [28622,28638]
===
match
---
number: 1 [18903,18904]
number: 1 [18903,18904]
===
match
---
operator: , [40919,40920]
operator: , [41641,41642]
===
match
---
operator: = [37369,37370]
operator: = [38091,38092]
===
match
---
operator: , [21815,21816]
operator: , [21815,21816]
===
match
---
name: self [4013,4017]
name: self [4013,4017]
===
match
---
name: dt [32880,32882]
name: dt [33602,33604]
===
match
---
operator: , [34458,34459]
operator: , [35180,35181]
===
match
---
trailer [29533,29540]
trailer [29533,29540]
===
match
---
number: 2 [12549,12550]
number: 2 [12549,12550]
===
match
---
name: bool [3305,3309]
name: bool [3305,3309]
===
match
---
number: 2 [17987,17988]
number: 2 [17987,17988]
===
match
---
operator: , [13888,13889]
operator: , [13888,13889]
===
match
---
atom_expr [7611,7627]
atom_expr [7611,7627]
===
match
---
name: mock_set_state [37680,37694]
name: mock_set_state [38402,38416]
===
match
---
string: '2020-11-10T12:42:39.442973' [24432,24460]
string: '2020-11-10T12:42:39.442973' [24432,24460]
===
match
---
arith_expr [19404,19445]
arith_expr [19404,19445]
===
match
---
operator: { [2413,2414]
operator: { [2413,2414]
===
match
---
operator: { [10400,10401]
operator: { [10400,10401]
===
match
---
dictorsetmaker [10953,10985]
dictorsetmaker [10953,10985]
===
match
---
fstring_string: &end_date_lte= [11919,11933]
fstring_string: &end_date_lte= [11919,11933]
===
match
---
operator: = [37915,37916]
operator: = [38637,38638]
===
match
---
string: "start_date" [10953,10965]
string: "start_date" [10953,10965]
===
match
---
trailer [33388,33393]
trailer [34110,34115]
===
match
---
operator: { [9482,9483]
operator: { [9482,9483]
===
match
---
name: DEFAULT_DATETIME_STR_1 [19102,19124]
name: DEFAULT_DATETIME_STR_1 [19102,19124]
===
match
---
testlist_comp [17579,17609]
testlist_comp [17579,17609]
===
match
---
atom [15330,15355]
atom [15330,15355]
===
match
---
name: task_instance [35028,35041]
name: task_instance [35750,35763]
===
match
---
string: "include_past" [40387,40401]
string: "include_past" [41109,41123]
===
match
---
trailer [7588,7592]
trailer [7588,7592]
===
match
---
name: State [27230,27235]
name: State [27230,27235]
===
match
---
name: json [7905,7909]
name: json [7905,7909]
===
match
---
operator: = [25729,25730]
operator: = [25729,25730]
===
match
---
name: update [3895,3901]
name: update [3895,3901]
===
match
---
atom [14372,14526]
atom [14372,14526]
===
match
---
operator: , [37377,37378]
operator: , [38099,38100]
===
match
---
operator: = [32439,32440]
operator: = [33161,33162]
===
match
---
exprlist [3999,4009]
exprlist [3999,4009]
===
match
---
operator: } [38436,38437]
operator: } [39158,39159]
===
match
---
suite [20798,21378]
suite [20798,21378]
===
match
---
name: dag_id [3507,3513]
name: dag_id [3507,3513]
===
match
---
operator: = [18979,18980]
operator: = [18979,18980]
===
match
---
trailer [16209,16245]
trailer [16209,16245]
===
match
---
dotted_name [21384,21404]
dotted_name [21384,21404]
===
match
---
trailer [32736,32746]
trailer [33458,33468]
===
match
---
trailer [4793,4800]
trailer [4793,4800]
===
match
---
name: client [37922,37928]
name: client [38644,38650]
===
match
---
string: "execution_date" [9827,9843]
string: "execution_date" [9827,9843]
===
match
---
yield_expr [2159,2168]
yield_expr [2159,2168]
===
match
---
atom_expr [37802,37887]
atom_expr [38524,38609]
===
match
---
name: State [27955,27960]
name: State [27955,27960]
===
match
---
arith_expr [12250,12291]
arith_expr [12250,12291]
===
match
---
operator: = [15783,15784]
operator: = [15783,15784]
===
match
---
operator: , [12311,12312]
operator: , [12311,12312]
===
match
---
string: "test" [6367,6373]
string: "test" [6367,6373]
===
match
---
atom [18627,18669]
atom [18627,18669]
===
match
---
funcdef [21735,22637]
funcdef [21735,22637]
===
match
---
operator: , [26838,26839]
operator: , [26838,26839]
===
match
---
argument [9962,9968]
argument [9962,9968]
===
match
---
operator: , [31332,31333]
operator: , [31332,31333]
===
match
---
testlist_comp [18451,18547]
testlist_comp [18451,18547]
===
match
---
operator: , [18342,18343]
operator: , [18342,18343]
===
match
---
number: 200 [12750,12753]
number: 200 [12750,12753]
===
match
---
file_input [785,43300]
file_input [785,44022]
===
match
---
operator: } [31331,31332]
operator: } [31331,31332]
===
match
---
argument [20952,20981]
argument [20952,20981]
===
match
---
atom_expr [33026,33046]
atom_expr [33748,33768]
===
match
---
string: "example_python_operator" [8490,8515]
string: "example_python_operator" [8490,8515]
===
match
---
name: response [21001,21009]
name: response [21001,21009]
===
match
---
trailer [15844,15892]
trailer [15844,15892]
===
match
---
atom [23906,23944]
atom [23906,23944]
===
match
---
expr_stmt [3933,3981]
expr_stmt [3933,3981]
===
match
---
name: session [7611,7618]
name: session [7611,7618]
===
match
---
atom_expr [4013,4035]
atom_expr [4013,4035]
===
match
---
string: "max_tries" [8186,8197]
string: "max_tries" [8186,8197]
===
match
---
atom_expr [20546,20566]
atom_expr [20546,20566]
===
match
---
operator: = [20563,20564]
operator: = [20563,20564]
===
match
---
trailer [37220,37225]
trailer [37942,37947]
===
match
---
name: State [32635,32640]
name: State [33357,33362]
===
match
---
number: 403 [36100,36103]
number: 403 [36822,36825]
===
match
---
name: fixture [1523,1530]
name: fixture [1523,1530]
===
match
---
operator: } [22799,22800]
operator: } [22799,22800]
===
match
---
name: add [4770,4773]
name: add [4770,4773]
===
match
---
trailer [32892,32900]
trailer [33614,33622]
===
match
---
decorators [36109,36549]
decorators [36831,37271]
===
match
---
operator: , [40243,40244]
operator: , [40965,40966]
===
match
---
testlist_comp [36680,36889]
testlist_comp [37402,37611]
===
match
---
atom [17780,17803]
atom [17780,17803]
===
match
---
string: "test_queue_2" [17595,17609]
string: "test_queue_2" [17595,17609]
===
match
---
name: response [43009,43017]
name: response [43731,43739]
===
match
---
operator: = [43018,43019]
operator: = [43740,43741]
===
match
---
operator: , [42391,42392]
operator: , [43113,43114]
===
match
---
atom_expr [2398,2410]
atom_expr [2398,2410]
===
match
---
name: self [7301,7305]
name: self [7301,7305]
===
match
---
operator: } [36196,36197]
operator: } [36918,36919]
===
match
---
dictorsetmaker [29943,30050]
dictorsetmaker [29943,30050]
===
match
---
fstring_end: " [4258,4259]
fstring_end: " [4258,4259]
===
match
---
if_stmt [4482,4778]
if_stmt [4482,4778]
===
match
---
trailer [19516,19524]
trailer [19516,19524]
===
match
---
name: json [16668,16672]
name: json [16668,16672]
===
match
---
string: "execution_date" [28514,28530]
string: "execution_date" [28514,28530]
===
match
---
trailer [19506,19516]
trailer [19506,19516]
===
match
---
operator: , [40461,40462]
operator: , [41183,41184]
===
match
---
string: "include_subdags" [35521,35538]
string: "include_subdags" [36243,36260]
===
match
---
operator: , [30249,30250]
operator: , [30249,30250]
===
match
---
operator: = [32187,32188]
operator: = [32909,32910]
===
match
---
atom [23234,23257]
atom [23234,23257]
===
match
---
atom_expr [7345,7360]
atom_expr [7345,7360]
===
match
---
simple_stmt [4513,4750]
simple_stmt [4513,4750]
===
match
---
number: 0 [7173,7174]
number: 0 [7173,7174]
===
match
---
param [20706,20708]
param [20706,20708]
===
match
---
operator: == [15929,15931]
operator: == [15929,15931]
===
match
---
operator: , [36230,36231]
operator: , [36952,36953]
===
match
---
string: "task_id" [41440,41449]
string: "task_id" [42162,42171]
===
match
---
operator: } [9519,9520]
operator: } [9519,9520]
===
match
---
string: "state" [27221,27228]
string: "state" [27221,27228]
===
match
---
operator: + [9864,9865]
operator: + [9864,9865]
===
match
---
testlist_comp [10344,10537]
testlist_comp [10344,10537]
===
match
---
string: "test" [2200,2206]
string: "test" [2200,2206]
===
match
---
simple_stmt [32424,33113]
simple_stmt [33146,33835]
===
match
---
number: 1 [19443,19444]
number: 1 [19443,19444]
===
match
---
operator: { [19943,19944]
operator: { [19943,19944]
===
match
---
operator: , [18647,18648]
operator: , [18647,18648]
===
match
---
expr_stmt [6185,6385]
expr_stmt [6185,6385]
===
match
---
name: days [20559,20563]
name: days [20559,20563]
===
match
---
operator: = [2411,2412]
operator: = [2411,2412]
===
match
---
name: status_code [41773,41784]
name: status_code [42495,42506]
===
match
---
string: "start_date" [11009,11021]
string: "start_date" [11009,11021]
===
match
---
name: parameterized [41798,41811]
name: parameterized [42520,42533]
===
match
---
operator: , [6748,6749]
operator: , [6748,6749]
===
match
---
name: response [38464,38472]
name: response [39186,39194]
===
match
---
name: get [15841,15844]
name: get [15841,15844]
===
match
---
operator: , [12066,12067]
operator: , [12066,12067]
===
match
---
operator: { [15283,15284]
operator: { [15283,15284]
===
match
---
atom [36428,36510]
atom [37150,37232]
===
match
---
operator: , [15520,15521]
operator: , [15520,15521]
===
match
---
assert_stmt [43257,43299]
assert_stmt [43979,44021]
===
match
---
operator: + [11678,11679]
operator: + [11678,11679]
===
match
---
string: "include parent dag" [29377,29397]
string: "include parent dag" [29377,29397]
===
match
---
string: "include_downstream" [41579,41599]
string: "include_downstream" [42301,42321]
===
match
---
simple_stmt [35142,35173]
simple_stmt [35864,35895]
===
match
---
trailer [16770,16777]
trailer [16770,16777]
===
match
---
name: dag_id [32180,32186]
name: dag_id [32902,32908]
===
match
---
testlist_comp [24128,24695]
testlist_comp [24128,24695]
===
match
---
name: session [4457,4464]
name: session [4457,4464]
===
match
---
name: self [38862,38866]
name: self [39584,39588]
===
match
---
dictorsetmaker [20193,20252]
dictorsetmaker [20193,20252]
===
match
---
param [24796,24804]
param [24796,24804]
===
match
---
atom [33767,33997]
atom [34489,34719]
===
match
---
string: "dag_ids" [21630,21639]
string: "dag_ids" [21630,21639]
===
match
---
trailer [35100,35133]
trailer [35822,35855]
===
match
---
operator: , [18546,18547]
operator: , [18546,18547]
===
match
---
name: json [25032,25036]
name: json [25032,25036]
===
match
---
operator: , [42550,42551]
operator: , [43272,43273]
===
match
---
string: 'sleep_for_0' [34207,34220]
string: 'sleep_for_0' [34929,34942]
===
match
---
argument [37310,37351]
argument [38032,38073]
===
match
---
operator: } [27812,27813]
operator: } [27812,27813]
===
match
---
operator: = [4236,4237]
operator: = [4236,4237]
===
match
---
dotted_name [1304,1323]
dotted_name [1304,1323]
===
match
---
simple_stmt [37198,37389]
simple_stmt [37920,38111]
===
match
---
operator: , [32663,32664]
operator: , [33385,33386]
===
match
---
atom_expr [7896,7909]
atom_expr [7896,7909]
===
match
---
string: "with execution date filter" [19815,19843]
string: "with execution date filter" [19815,19843]
===
match
---
string: '2020-01-05T00:00:00+00:00' [34865,34892]
string: '2020-01-05T00:00:00+00:00' [35587,35614]
===
match
---
name: RUNNING [32933,32940]
name: RUNNING [33655,33662]
===
match
---
comparison [23420,23462]
comparison [23420,23462]
===
match
---
expr_stmt [3523,3540]
expr_stmt [3523,3540]
===
match
---
testlist_comp [36337,36413]
testlist_comp [37059,37135]
===
match
---
operator: , [8107,8108]
operator: , [8107,8108]
===
match
---
atom [1818,1877]
atom [1818,1877]
===
match
---
operator: , [26554,26555]
operator: , [26554,26555]
===
match
---
dictorsetmaker [17826,17847]
dictorsetmaker [17826,17847]
===
match
---
dictorsetmaker [25673,25780]
dictorsetmaker [25673,25780]
===
match
---
name: DEFAULT_DATETIME_STR_1 [10733,10755]
name: DEFAULT_DATETIME_STR_1 [10733,10755]
===
match
---
assert_stmt [25064,25098]
assert_stmt [25064,25098]
===
match
---
trailer [29027,29035]
trailer [29027,29035]
===
match
---
operator: , [40189,40190]
operator: , [40911,40912]
===
match
---
string: "execution_date" [28038,28054]
string: "execution_date" [28038,28054]
===
match
---
testlist_comp [12597,13006]
testlist_comp [12597,13006]
===
match
---
name: dt [31061,31063]
name: dt [31061,31063]
===
match
---
string: "REMOTE_USER" [33483,33496]
string: "REMOTE_USER" [34205,34218]
===
match
---
name: self [23001,23005]
name: self [23001,23005]
===
match
---
decorator [42848,42865]
decorator [43570,43587]
===
match
---
atom [6461,7220]
atom [6461,7220]
===
match
---
name: self [2843,2847]
name: self [2843,2847]
===
match
---
operator: ** [3966,3968]
operator: ** [3966,3968]
===
match
---
name: environ_overrides [40682,40699]
name: environ_overrides [41404,41421]
===
match
---
name: dr [4469,4471]
name: dr [4469,4471]
===
match
---
atom [12237,12292]
atom [12237,12292]
===
match
---
string: "unixname" [7188,7198]
string: "unixname" [7188,7198]
===
match
---
operator: , [20704,20705]
operator: , [20704,20705]
===
match
---
atom_expr [2843,2851]
atom_expr [2843,2851]
===
match
---
trailer [37809,37815]
trailer [38531,38537]
===
match
---
argument [2191,2206]
argument [2191,2206]
===
match
---
trailer [31834,31839]
trailer [32556,32561]
===
match
---
dictorsetmaker [23632,23690]
dictorsetmaker [23632,23690]
===
match
---
trailer [33597,33605]
trailer [34319,34327]
===
match
---
operator: , [39267,39268]
operator: , [39989,39990]
===
match
---
operator: , [15595,15596]
operator: , [15595,15596]
===
match
---
name: DEFAULT_DATETIME_1 [32567,32585]
name: DEFAULT_DATETIME_1 [33289,33307]
===
match
---
testlist_comp [17939,17967]
testlist_comp [17939,17967]
===
match
---
string: '2020-11-10T12:42:39.442973' [24532,24560]
string: '2020-11-10T12:42:39.442973' [24532,24560]
===
match
---
name: dt [29982,29984]
name: dt [29982,29984]
===
match
---
name: timedelta [18888,18897]
name: timedelta [18888,18897]
===
match
---
name: TestTaskInstanceEndpoint [9604,9628]
name: TestTaskInstanceEndpoint [9604,9628]
===
match
---
operator: } [17486,17487]
operator: } [17486,17487]
===
match
---
trailer [2402,2410]
trailer [2402,2410]
===
match
---
name: environ_overrides [23216,23233]
name: environ_overrides [23216,23233]
===
match
---
operator: , [35559,35560]
operator: , [36281,36282]
===
match
---
operator: = [2889,2890]
operator: = [2889,2890]
===
match
---
dictorsetmaker [27136,27244]
dictorsetmaker [27136,27244]
===
match
---
operator: } [10194,10195]
operator: } [10194,10195]
===
match
---
operator: = [4579,4580]
operator: = [4579,4580]
===
match
---
trailer [28663,28673]
trailer [28663,28673]
===
match
---
simple_stmt [3481,3515]
simple_stmt [3481,3515]
===
match
---
trailer [30719,30727]
trailer [30719,30727]
===
match
---
operator: , [7145,7146]
operator: , [7145,7146]
===
match
---
name: DEFAULT_DATETIME_1 [12250,12268]
name: DEFAULT_DATETIME_1 [12250,12268]
===
match
---
operator: , [36742,36743]
operator: , [37464,37465]
===
match
---
trailer [3491,3498]
trailer [3491,3498]
===
match
---
expr_stmt [15818,15892]
expr_stmt [15818,15892]
===
match
---
atom_expr [30607,30619]
atom_expr [30607,30619]
===
match
---
name: task_instance [34973,34986]
name: task_instance [35695,35708]
===
match
---
operator: { [21552,21553]
operator: { [21552,21553]
===
match
---
name: assert_401 [39838,39848]
name: assert_401 [40560,40570]
===
match
---
name: DEFAULT_DATETIME_1 [19483,19501]
name: DEFAULT_DATETIME_1 [19483,19501]
===
match
---
operator: , [42727,42728]
operator: , [43449,43450]
===
match
---
arith_expr [33005,33046]
arith_expr [33727,33768]
===
match
---
operator: , [13076,13077]
operator: , [13076,13077]
===
match
---
operator: , [33450,33451]
operator: , [34172,34173]
===
match
---
operator: , [30226,30227]
operator: , [30226,30227]
===
match
---
operator: { [11646,11647]
operator: { [11646,11647]
===
match
---
atom_expr [3829,3846]
atom_expr [3829,3846]
===
match
---
string: "queued_when" [8417,8430]
string: "queued_when" [8417,8430]
===
match
---
testlist_comp [23644,23689]
testlist_comp [23644,23689]
===
match
---
name: test_should_raise_400_for_naive_and_bad_datetime [24741,24789]
name: test_should_raise_400_for_naive_and_bad_datetime [24741,24789]
===
match
---
operator: = [5123,5124]
operator: = [5123,5124]
===
match
---
atom_expr [29805,29825]
atom_expr [29805,29825]
===
match
---
operator: , [39091,39092]
operator: , [39813,39814]
===
match
---
name: expected_ti_count [22512,22529]
name: expected_ti_count [22512,22529]
===
match
---
operator: , [12676,12677]
operator: , [12676,12677]
===
match
---
operator: , [13378,13379]
operator: , [13378,13379]
===
match
---
name: role_name [1697,1706]
name: role_name [1697,1706]
===
match
---
string: "sla_miss" [5771,5781]
string: "sla_miss" [5771,5781]
===
match
---
operator: { [13116,13117]
operator: { [13116,13117]
===
match
---
number: 10000 [2719,2724]
number: 10000 [2719,2724]
===
match
---
name: mock [37552,37556]
name: mock [38274,38278]
===
match
---
name: session [1057,1064]
name: session [1057,1064]
===
match
---
operator: , [19730,19731]
operator: , [19730,19731]
===
match
---
string: "end_date" [11570,11580]
string: "end_date" [11570,11580]
===
match
---
trailer [7904,7909]
trailer [7904,7909]
===
match
---
decorated [1515,2224]
decorated [1515,2224]
===
match
---
operator: { [15330,15331]
operator: { [15330,15331]
===
match
---
atom [18928,18983]
atom [18928,18983]
===
match
---
param [40561,40565]
param [41283,41287]
===
match
---
trailer [31073,31081]
trailer [31073,31081]
===
match
---
string: 'task_id' [34910,34919]
string: 'task_id' [35632,35641]
===
match
---
operator: , [11387,11388]
operator: , [11387,11388]
===
match
---
name: session [4941,4948]
name: session [4941,4948]
===
match
---
comparison [32009,32036]
comparison [32731,32758]
===
match
---
name: getuser [9003,9010]
name: getuser [9003,9010]
===
match
---
atom [23631,23691]
atom [23631,23691]
===
match
---
funcdef [23737,24078]
funcdef [23737,24078]
===
match
---
trailer [36865,36873]
trailer [37587,37595]
===
match
---
string: "dry_run" [29207,29216]
string: "dry_run" [29207,29216]
===
match
---
atom_expr [30214,30226]
atom_expr [30214,30226]
===
match
---
name: _ [20706,20707]
name: _ [20706,20707]
===
match
---
operator: { [26704,26705]
operator: { [26704,26705]
===
match
---
operator: , [23691,23692]
operator: , [23691,23692]
===
match
---
name: self [22073,22077]
name: self [22073,22077]
===
match
---
param [36621,36630]
param [37343,37352]
===
match
---
name: dt [29015,29017]
name: dt [29015,29017]
===
match
---
trailer [32508,32516]
trailer [33230,33238]
===
match
---
operator: , [19203,19204]
operator: , [19203,19204]
===
match
---
name: total_ti [22973,22981]
name: total_ti [22973,22981]
===
match
---
dictorsetmaker [7927,9013]
dictorsetmaker [7927,9013]
===
match
---
string: 'REMOTE_USER' [9483,9496]
string: 'REMOTE_USER' [9483,9496]
===
match
---
operator: } [20169,20170]
operator: } [20169,20170]
===
match
---
string: "dry_run" [31253,31262]
string: "dry_run" [31253,31262]
===
match
---
number: 2 [11405,11406]
number: 2 [11405,11406]
===
match
---
name: counter [3656,3663]
name: counter [3656,3663]
===
match
---
dictorsetmaker [19884,19920]
dictorsetmaker [19884,19920]
===
match
---
string: "test" [37344,37350]
string: "test" [38066,38072]
===
match
---
string: "2020-01-02T00:00:00+00:00" [8845,8872]
string: "2020-01-02T00:00:00+00:00" [8845,8872]
===
match
---
argument [28674,28680]
argument [28674,28680]
===
match
---
operator: , [7101,7102]
operator: , [7101,7102]
===
match
---
string: "2020-01-02T00:00:00+00:00" [1485,1512]
string: "2020-01-02T00:00:00+00:00" [1485,1512]
===
match
---
atom_expr [27800,27812]
atom_expr [27800,27812]
===
match
---
operator: { [14807,14808]
operator: { [14807,14808]
===
match
---
name: DEFAULT_DATETIME_1 [19962,19980]
name: DEFAULT_DATETIME_1 [19962,19980]
===
match
---
argument [1723,2046]
argument [1723,2046]
===
match
---
name: DEFAULT_DATETIME_STR_2 [1460,1482]
name: DEFAULT_DATETIME_STR_2 [1460,1482]
===
match
---
operator: = [32231,32232]
operator: = [32953,32954]
===
match
---
operator: { [34725,34726]
operator: { [35447,35448]
===
match
---
argument [18898,18904]
argument [18898,18904]
===
match
---
name: update_extras [15742,15755]
name: update_extras [15742,15755]
===
match
---
operator: + [10434,10435]
operator: + [10434,10435]
===
match
---
operator: } [11623,11624]
operator: } [11623,11624]
===
match
---
name: payload [23276,23283]
name: payload [23276,23283]
===
match
---
trailer [3843,3846]
trailer [3843,3846]
===
match
---
operator: , [2073,2074]
operator: , [2073,2074]
===
match
---
atom [11435,12010]
atom [11435,12010]
===
match
---
number: 1 [10232,10233]
number: 1 [10232,10233]
===
match
---
string: 'dag_id' [34029,34037]
string: 'dag_id' [34751,34759]
===
match
---
dictorsetmaker [12738,12753]
dictorsetmaker [12738,12753]
===
match
---
operator: = [6128,6129]
operator: = [6128,6129]
===
match
---
operator: , [28751,28752]
operator: , [28751,28752]
===
match
---
name: status_code [7861,7872]
name: status_code [7861,7872]
===
match
---
dictorsetmaker [17369,17392]
dictorsetmaker [17369,17392]
===
match
---
operator: } [21141,21142]
operator: } [21141,21142]
===
match
---
string: "example_python_operator" [6485,6510]
string: "example_python_operator" [6485,6510]
===
match
---
string: "task_instances" [35059,35075]
string: "task_instances" [35781,35797]
===
match
---
operator: , [25347,25348]
operator: , [25347,25348]
===
match
---
operator: = [41346,41347]
operator: = [42068,42069]
===
match
---
name: response [7896,7904]
name: response [7896,7904]
===
match
---
operator: + [27173,27174]
operator: + [27173,27174]
===
match
---
operator: } [13132,13133]
operator: } [13132,13133]
===
match
---
number: 2 [17629,17630]
number: 2 [17629,17630]
===
match
---
trailer [3498,3506]
trailer [3498,3506]
===
match
---
name: count [16646,16651]
name: count [16646,16651]
===
match
---
funcdef [37635,39279]
funcdef [38357,40001]
===
match
---
argument [23958,24023]
argument [23958,24023]
===
match
---
dictorsetmaker [11647,11700]
dictorsetmaker [11647,11700]
===
match
---
operator: { [38524,38525]
operator: { [39246,39247]
===
match
---
name: len [16655,16658]
name: len [16655,16658]
===
match
---
name: response [35045,35053]
name: response [35767,35775]
===
match
---
name: _ [21817,21818]
name: _ [21817,21818]
===
match
---
name: dt [11603,11605]
name: dt [11603,11605]
===
match
---
suite [21894,22637]
suite [21894,22637]
===
match
---
simple_stmt [7636,7837]
simple_stmt [7636,7837]
===
match
---
name: days [30172,30176]
name: days [30172,30176]
===
match
---
string: "duration" [18452,18462]
string: "duration" [18452,18462]
===
match
---
number: 404 [41146,41149]
number: 404 [41868,41871]
===
match
---
arith_expr [20045,20086]
arith_expr [20045,20086]
===
match
---
operator: , [1285,1286]
operator: , [1285,1286]
===
match
---
atom [34249,34473]
atom [34971,35195]
===
match
---
operator: { [5124,5125]
operator: { [5124,5125]
===
match
---
operator: = [15867,15868]
operator: = [15867,15868]
===
match
---
name: default_time [7549,7561]
name: default_time [7549,7561]
===
match
---
decorator [22642,22874]
decorator [22642,22874]
===
match
---
string: '2020-11-10T12:42:39.442973' [24632,24660]
string: '2020-11-10T12:42:39.442973' [24632,24660]
===
match
---
simple_stmt [4053,4077]
simple_stmt [4053,4077]
===
match
---
string: "state" [13561,13568]
string: "state" [13561,13568]
===
match
---
dictorsetmaker [15237,15260]
dictorsetmaker [15237,15260]
===
match
---
operator: { [11569,11570]
operator: { [11569,11570]
===
match
---
name: response [16439,16447]
name: response [16439,16447]
===
match
---
operator: , [34416,34417]
operator: , [35138,35139]
===
match
---
comparison [23310,23337]
comparison [23310,23337]
===
match
---
operator: , [25018,25019]
operator: , [25018,25019]
===
match
---
testlist_comp [32455,33102]
testlist_comp [33177,33824]
===
match
---
atom_expr [11044,11064]
atom_expr [11044,11064]
===
match
---
dictorsetmaker [17416,17439]
dictorsetmaker [17416,17439]
===
match
---
name: status_code [22463,22474]
name: status_code [22463,22474]
===
match
---
string: 'TEST_DAG_RUN_ID_1' [34096,34115]
string: 'TEST_DAG_RUN_ID_1' [34818,34837]
===
match
---
string: "test_queue_2" [14817,14831]
string: "test_queue_2" [14817,14831]
===
match
---
name: dt [11044,11046]
name: dt [11044,11046]
===
match
---
string: "state" [13516,13523]
string: "state" [13516,13523]
===
match
---
arglist [4061,4075]
arglist [4061,4075]
===
match
---
name: RUNNING [27236,27243]
name: RUNNING [27236,27243]
===
match
---
number: 2 [25730,25731]
number: 2 [25730,25731]
===
match
---
assert_stmt [32045,32103]
assert_stmt [32767,32825]
===
match
---
trailer [25595,25602]
trailer [25595,25602]
===
match
---
atom [12579,13020]
atom [12579,13020]
===
match
---
name: client [23132,23138]
name: client [23132,23138]
===
match
---
trailer [3634,3664]
trailer [3634,3664]
===
match
---
simple_stmt [4457,4473]
simple_stmt [4457,4473]
===
match
---
name: expected_ti [16052,16063]
name: expected_ti [16052,16063]
===
match
---
string: '2020-01-01T00:00:00+00:00' [38724,38751]
string: '2020-01-01T00:00:00+00:00' [39446,39473]
===
match
---
simple_stmt [15944,15997]
simple_stmt [15944,15997]
===
match
---
comparison [37447,37482]
comparison [38169,38204]
===
match
---
simple_stmt [1213,1299]
simple_stmt [1213,1299]
===
match
---
trailer [36084,36096]
trailer [36806,36818]
===
match
---
operator: , [29124,29125]
operator: , [29124,29125]
===
match
---
dictorsetmaker [35371,35545]
dictorsetmaker [36093,36267]
===
match
---
operator: == [6458,6460]
operator: == [6458,6460]
===
match
---
arglist [22113,22241]
arglist [22113,22241]
===
match
---
name: days [12284,12288]
name: days [12284,12288]
===
match
---
arglist [9127,9221]
arglist [9127,9221]
===
match
---
string: "start_date_gte" [19628,19644]
string: "start_date_gte" [19628,19644]
===
match
---
name: timedelta [32737,32746]
name: timedelta [33459,33468]
===
match
---
simple_stmt [22505,22564]
simple_stmt [22505,22564]
===
match
---
dictorsetmaker [18530,18545]
dictorsetmaker [18530,18545]
===
match
---
name: timedelta [19428,19437]
name: timedelta [19428,19437]
===
match
---
string: '2020-11-10T12:42:39.442973' [24336,24364]
string: '2020-11-10T12:42:39.442973' [24336,24364]
===
match
---
string: "example_subdag_operator" [31188,31213]
string: "example_subdag_operator" [31188,31213]
===
match
---
name: filter [37830,37836]
name: filter [38552,38558]
===
match
---
name: provide_session [42849,42864]
name: provide_session [43571,43586]
===
match
---
name: FAILED [27806,27812]
name: FAILED [27806,27812]
===
match
---
argument [24977,25018]
argument [24977,25018]
===
match
---
operator: , [36610,36611]
operator: , [37332,37333]
===
match
---
string: "state" [25758,25765]
string: "state" [25758,25765]
===
match
---
name: dag_id [7442,7448]
name: dag_id [7442,7448]
===
match
---
arith_expr [20525,20566]
arith_expr [20525,20566]
===
match
---
string: "task_id" [41919,41928]
string: "task_id" [42641,42650]
===
match
---
operator: , [13005,13006]
operator: , [13005,13006]
===
match
---
argument [15728,15755]
argument [15728,15755]
===
match
---
expr_stmt [7369,7572]
expr_stmt [7369,7572]
===
match
---
operator: , [12333,12334]
operator: , [12333,12334]
===
match
---
trailer [6207,6211]
trailer [6207,6211]
===
match
---
decorator [21383,21710]
decorator [21383,21710]
===
match
---
name: test_should_respond_200_dag_ids_filter [22903,22941]
name: test_should_respond_200_dag_ids_filter [22903,22941]
===
match
---
name: task_instances [33244,33258]
name: task_instances [33966,33980]
===
match
---
argument [22168,22197]
argument [22168,22197]
===
match
---
argument [22360,22401]
argument [22360,22401]
===
match
---
string: "task_id" [8918,8927]
string: "task_id" [8918,8927]
===
match
---
operator: } [18467,18468]
operator: } [18467,18468]
===
match
---
name: response [25114,25122]
name: response [25114,25122]
===
match
---
operator: = [2116,2117]
operator: = [2116,2117]
===
match
---
operator: , [26986,26987]
operator: , [26986,26987]
===
match
---
trailer [43024,43031]
trailer [43746,43753]
===
match
---
atom [14394,14417]
atom [14394,14417]
===
match
---
string: "include_future" [41623,41639]
string: "include_future" [42345,42361]
===
match
---
number: 200 [16463,16466]
number: 200 [16463,16466]
===
match
---
operator: , [42063,42064]
operator: , [42785,42786]
===
match
---
dotted_name [1175,1194]
dotted_name [1175,1194]
===
match
---
operator: , [22240,22241]
operator: , [22240,22241]
===
match
---
name: add [7589,7592]
name: add [7589,7592]
===
match
---
name: DEFAULT_DATETIME_1 [28532,28550]
name: DEFAULT_DATETIME_1 [28532,28550]
===
match
---
operator: , [26424,26425]
operator: , [26424,26425]
===
match
---
trailer [23810,23815]
trailer [23810,23815]
===
match
---
string: "state" [27946,27953]
string: "state" [27946,27953]
===
match
---
operator: { [2535,2536]
operator: { [2535,2536]
===
match
---
assert_stmt [21313,21377]
assert_stmt [21313,21377]
===
match
---
operator: = [38041,38042]
operator: = [38763,38764]
===
match
---
operator: , [26891,26892]
operator: , [26891,26892]
===
match
---
atom [26905,27618]
atom [26905,27618]
===
match
---
name: days [27188,27192]
name: days [27188,27192]
===
match
---
atom_expr [21195,21215]
atom_expr [21195,21215]
===
match
---
operator: , [25977,25978]
operator: , [25977,25978]
===
match
---
name: days [19438,19442]
name: days [19438,19442]
===
match
---
atom_expr [9328,9531]
atom_expr [9328,9531]
===
match
---
operator: { [12237,12238]
operator: { [12237,12238]
===
match
---
name: provide_session [36533,36548]
name: provide_session [37255,37270]
===
match
---
name: expected_ti_count [22579,22596]
name: expected_ti_count [22579,22596]
===
match
---
expr_stmt [16475,16575]
expr_stmt [16475,16575]
===
match
---
name: update_extras [3253,3266]
name: update_extras [3253,3266]
===
match
---
string: "REMOTE_USER" [7803,7816]
string: "REMOTE_USER" [7803,7816]
===
match
---
trailer [24904,25055]
trailer [24904,25055]
===
match
---
operator: = [20881,20882]
operator: = [20881,20882]
===
match
---
assert_stmt [38500,38846]
assert_stmt [39222,39568]
===
match
---
dictorsetmaker [32549,32649]
dictorsetmaker [33271,33371]
===
match
---
operator: , [10214,10215]
operator: , [10214,10215]
===
match
---
string: "end_date_gte" [19086,19100]
string: "end_date_gte" [19086,19100]
===
match
---
trailer [23356,23389]
trailer [23356,23389]
===
match
---
operator: , [14920,14921]
operator: , [14920,14921]
===
match
---
string: "duration" [12660,12670]
string: "duration" [12660,12670]
===
match
---
operator: , [29541,29542]
operator: , [29541,29542]
===
match
---
name: task_id [7401,7408]
name: task_id [7401,7408]
===
match
---
string: "example_python_operator" [22753,22778]
string: "example_python_operator" [22753,22778]
===
match
---
testlist_comp [1819,1876]
testlist_comp [1819,1876]
===
match
---
operator: , [40963,40964]
operator: , [41685,41686]
===
match
---
operator: , [41519,41520]
operator: , [42241,42242]
===
match
---
trailer [38472,38484]
trailer [39194,39206]
===
match
---
operator: , [37351,37352]
operator: , [38073,38074]
===
match
---
atom [26469,26624]
atom [26469,26624]
===
match
---
operator: , [38219,38220]
operator: , [38941,38942]
===
match
---
operator: , [29825,29826]
operator: , [29825,29826]
===
match
---
operator: == [16538,16540]
operator: == [16538,16540]
===
match
---
name: State [13479,13484]
name: State [13479,13484]
===
match
---
operator: , [5493,5494]
operator: , [5493,5494]
===
match
---
for_stmt [3995,4077]
for_stmt [3995,4077]
===
match
---
decorator [36109,36528]
decorator [36831,37250]
===
match
---
dotted_name [41798,41818]
dotted_name [42520,42540]
===
match
---
name: dt [25712,25714]
name: dt [25712,25714]
===
match
---
atom [17277,20631]
atom [17277,20631]
===
match
---
name: expected [36621,36629]
name: expected [37343,37351]
===
match
---
operator: , [29311,29312]
operator: , [29311,29312]
===
match
---
name: session [23028,23035]
name: session [23028,23035]
===
match
---
decorators [24083,24733]
decorators [24083,24733]
===
match
---
operator: } [18322,18323]
operator: } [18322,18323]
===
match
---
operator: == [33626,33628]
operator: == [34348,34350]
===
match
---
string: "priority_weight" [5666,5683]
string: "priority_weight" [5666,5683]
===
match
---
name: client [23542,23548]
name: client [23542,23548]
===
match
---
string: "execution_date" [9767,9783]
string: "execution_date" [9767,9783]
===
match
---
operator: = [31821,31822]
operator: = [32543,32544]
===
match
---
trailer [11692,11700]
trailer [11692,11700]
===
match
---
param [9072,9076]
param [9072,9076]
===
match
---
operator: = [3529,3530]
operator: = [3529,3530]
===
match
---
number: 2 [12289,12290]
number: 2 [12289,12290]
===
match
---
simple_stmt [20807,20993]
simple_stmt [20807,20993]
===
match
---
operator: , [8048,8049]
operator: , [8048,8049]
===
match
---
string: "task_id" [42413,42422]
string: "task_id" [43135,43144]
===
match
---
dictorsetmaker [40760,41081]
dictorsetmaker [41482,41803]
===
match
---
argument [28090,28096]
argument [28090,28096]
===
match
---
name: dt [10515,10517]
name: dt [10515,10517]
===
match
---
name: days [12207,12211]
name: days [12207,12211]
===
match
---
atom_expr [35247,35570]
atom_expr [35969,36292]
===
match
---
name: self [2563,2567]
name: self [2563,2567]
===
match
---
trailer [4468,4472]
trailer [4468,4472]
===
match
---
atom_expr [15908,15928]
atom_expr [15908,15928]
===
match
---
atom [29359,30417]
atom [29359,30417]
===
match
---
name: DEFAULT_DATETIME_1 [30686,30704]
name: DEFAULT_DATETIME_1 [30686,30704]
===
match
---
name: timedelta [29631,29640]
name: timedelta [29631,29640]
===
match
---
name: State [25435,25440]
name: State [25435,25440]
===
match
---
name: RESOURCE_TASK_INSTANCE [1933,1955]
name: RESOURCE_TASK_INSTANCE [1933,1955]
===
match
---
expr_stmt [1365,1406]
expr_stmt [1365,1406]
===
match
---
string: "try_number" [5932,5944]
string: "try_number" [5932,5944]
===
match
---
name: response [31812,31820]
name: response [32534,32542]
===
match
---
name: dt [9949,9951]
name: dt [9949,9951]
===
match
---
trailer [33148,33357]
trailer [33870,34079]
===
match
---
name: TestTaskInstanceEndpoint [17215,17239]
name: TestTaskInstanceEndpoint [17215,17239]
===
match
---
string: "start_date" [10345,10357]
string: "start_date" [10345,10357]
===
match
---
trailer [18155,18162]
trailer [18155,18162]
===
match
---
string: "test_queue_2" [17425,17439]
string: "test_queue_2" [17425,17439]
===
match
---
operator: , [24594,24595]
operator: , [24594,24595]
===
match
---
number: 10000.0 [7988,7995]
number: 10000.0 [7988,7995]
===
match
---
operator: , [28681,28682]
operator: , [28681,28682]
===
match
---
string: "test duration filter" [18389,18411]
string: "test duration filter" [18389,18411]
===
match
---
comparison [37837,37880]
comparison [38559,38602]
===
match
---
atom [37328,37351]
atom [38050,38073]
===
match
---
dictorsetmaker [30560,30619]
dictorsetmaker [30560,30619]
===
match
---
operator: , [12795,12796]
operator: , [12795,12796]
===
match
---
operator: , [36873,36874]
operator: , [37595,37596]
===
match
---
operator: = [23905,23906]
operator: = [23905,23906]
===
match
---
operator: , [39240,39241]
operator: , [39962,39963]
===
match
---
param [16121,16128]
param [16121,16128]
===
match
---
name: json [23626,23630]
name: json [23626,23630]
===
match
---
expr_stmt [39342,39829]
expr_stmt [40064,40551]
===
match
---
name: environ_overrides [5106,5123]
name: environ_overrides [5106,5123]
===
match
---
operator: , [36414,36415]
operator: , [37136,37137]
===
match
---
atom [28248,28345]
atom [28248,28345]
===
match
---
operator: } [11064,11065]
operator: } [11064,11065]
===
match
---
operator: , [35877,35878]
operator: , [36599,36600]
===
match
---
atom [28393,29345]
atom [28393,29345]
===
match
---
trailer [37928,37933]
trailer [38650,38655]
===
match
---
operator: , [13823,13824]
operator: , [13823,13824]
===
match
---
simple_stmt [38856,38940]
simple_stmt [39578,39662]
===
match
---
operator: } [32954,32955]
operator: } [33676,33677]
===
match
---
atom_expr [37714,37749]
atom_expr [38436,38471]
===
match
---
trailer [37158,37160]
trailer [37880,37882]
===
match
---
operator: } [27265,27266]
operator: } [27265,27266]
===
match
---
atom_expr [37131,37160]
atom_expr [37853,37882]
===
match
---
trailer [4308,4326]
trailer [4308,4326]
===
match
---
operator: , [33046,33047]
operator: , [33768,33769]
===
match
---
trailer [29865,29872]
trailer [29865,29872]
===
match
---
operator: { [19883,19884]
operator: { [19883,19884]
===
match
---
atom_expr [32588,32608]
atom_expr [33310,33330]
===
match
---
string: "dry_run" [41407,41416]
string: "dry_run" [42129,42138]
===
match
---
atom [18529,18546]
atom [18529,18546]
===
match
---
operator: , [35955,35956]
operator: , [36677,36678]
===
match
---
testlist_comp [18797,18984]
testlist_comp [18797,18984]
===
match
---
argument [3109,3131]
argument [3109,3131]
===
match
---
operator: } [20086,20087]
operator: } [20086,20087]
===
match
---
number: 1 [5651,5652]
number: 1 [5651,5652]
===
match
---
name: dt [36813,36815]
name: dt [37535,37537]
===
match
---
name: task_id [37850,37857]
name: task_id [38572,38579]
===
match
---
trailer [22287,22438]
trailer [22287,22438]
===
match
---
string: "reset_dag_runs" [35405,35421]
string: "reset_dag_runs" [36127,36143]
===
match
---
atom [19468,19525]
atom [19468,19525]
===
match
---
simple_stmt [35579,35600]
simple_stmt [36301,36322]
===
match
---
operator: , [27789,27790]
operator: , [27789,27790]
===
match
---
string: "2020-01-02T00:00:00+00:00" [7042,7069]
string: "2020-01-02T00:00:00+00:00" [7042,7069]
===
match
---
name: app [37136,37139]
name: app [37858,37861]
===
match
---
testlist_comp [33767,34950]
testlist_comp [34489,35672]
===
match
---
simple_stmt [21246,21305]
simple_stmt [21246,21305]
===
match
---
atom [14854,14879]
atom [14854,14879]
===
match
---
trailer [6200,6207]
trailer [6200,6207]
===
match
---
parameters [15590,15657]
parameters [15590,15657]
===
match
---
param [22973,22982]
param [22973,22982]
===
match
---
name: DEFAULT_DATETIME_1 [20294,20312]
name: DEFAULT_DATETIME_1 [20294,20312]
===
match
---
argument [2996,3017]
argument [2996,3017]
===
match
---
operator: } [40460,40461]
operator: } [41182,41183]
===
match
---
testlist_comp [27752,28169]
testlist_comp [27752,28169]
===
match
---
trailer [4973,4980]
trailer [4973,4980]
===
match
---
name: days [30720,30724]
name: days [30720,30724]
===
match
---
trailer [10448,10456]
trailer [10448,10456]
===
match
---
simple_stmt [1038,1088]
simple_stmt [1038,1088]
===
match
---
operator: , [35503,35504]
operator: , [36225,36226]
===
match
---
atom [18371,18703]
atom [18371,18703]
===
match
---
dictorsetmaker [10480,10535]
dictorsetmaker [10480,10535]
===
match
---
name: self [15829,15833]
name: self [15829,15833]
===
match
---
dotted_name [894,908]
dotted_name [894,908]
===
match
---
operator: = [36664,36665]
operator: = [37386,37387]
===
match
---
name: dag_bag [38871,38878]
name: dag_bag [39593,39600]
===
match
---
string: "pool" [17826,17832]
string: "pool" [17826,17832]
===
match
---
fstring_expr [10772,10796]
fstring_expr [10772,10796]
===
match
---
argument [33183,33196]
argument [33905,33918]
===
match
---
name: DEFAULT_DATETIME_1 [10415,10433]
name: DEFAULT_DATETIME_1 [10415,10433]
===
match
---
operator: , [19749,19750]
operator: , [19749,19750]
===
match
---
operator: , [20378,20379]
operator: , [20378,20379]
===
match
---
operator: , [33346,33347]
operator: , [34068,34069]
===
match
---
operator: = [26374,26375]
operator: = [26374,26375]
===
match
---
atom [29458,30268]
atom [29458,30268]
===
match
---
name: payload [22951,22958]
name: payload [22951,22958]
===
match
---
string: "execution_date" [36774,36790]
string: "execution_date" [37496,37512]
===
match
---
simple_stmt [37440,37483]
simple_stmt [38162,38205]
===
match
---
atom [28950,29105]
atom [28950,29105]
===
match
---
name: client [35252,35258]
name: client [35974,35980]
===
match
---
operator: { [14394,14395]
operator: { [14394,14395]
===
match
---
arith_expr [36792,36833]
arith_expr [37514,37555]
===
match
---
trailer [33028,33038]
trailer [33750,33760]
===
match
---
operator: , [38631,38632]
operator: , [39353,39354]
===
match
---
operator: } [21569,21570]
operator: } [21569,21570]
===
match
---
trailer [1859,1876]
trailer [1859,1876]
===
match
---
trailer [42991,43000]
trailer [43713,43722]
===
match
---
operator: = [32605,32606]
operator: = [33327,33328]
===
match
---
name: timedelta [19507,19516]
name: timedelta [19507,19516]
===
match
---
string: "include_future" [42133,42149]
string: "include_future" [42855,42871]
===
match
---
operator: } [9022,9023]
operator: } [9022,9023]
===
match
---
name: payload [31975,31982]
name: payload [32697,32704]
===
match
---
string: "execution_date" [26318,26334]
string: "execution_date" [26318,26334]
===
match
---
operator: , [21676,21677]
operator: , [21676,21677]
===
match
---
dictorsetmaker [7803,7824]
dictorsetmaker [7803,7824]
===
match
---
string: "test pool filter" [17677,17695]
string: "test pool filter" [17677,17695]
===
match
---
operator: = [22269,22270]
operator: = [22269,22270]
===
match
---
string: "dry_run" [40760,40769]
string: "dry_run" [41482,41491]
===
match
---
trailer [38515,38520]
trailer [39237,39242]
===
match
---
argument [17070,17126]
argument [17070,17126]
===
match
---
name: clear_db_sla_miss [1346,1363]
name: clear_db_sla_miss [1346,1363]
===
match
---
atom [32455,32517]
atom [33177,33239]
===
match
---
decorators [22642,22895]
decorators [22642,22895]
===
match
---
operator: = [39924,39925]
operator: = [40646,40647]
===
match
---
name: run_id [4230,4236]
name: run_id [4230,4236]
===
match
---
operator: } [17802,17803]
operator: } [17802,17803]
===
match
---
string: "example_python_operator" [25839,25864]
string: "example_python_operator" [25839,25864]
===
match
---
atom_expr [37404,37424]
atom_expr [38126,38146]
===
match
---
operator: , [26797,26798]
operator: , [26797,26798]
===
match
---
atom [24114,24705]
atom [24114,24705]
===
match
---
atom [36245,36278]
atom [36967,37000]
===
match
---
operator: , [13838,13839]
operator: , [13838,13839]
===
match
---
operator: = [6194,6195]
operator: = [6194,6195]
===
match
---
number: 3 [20604,20605]
number: 3 [20604,20605]
===
match
---
trailer [36825,36833]
trailer [37547,37555]
===
match
---
string: "execution_date" [32549,32565]
string: "execution_date" [33271,33287]
===
match
---
arglist [2070,2136]
arglist [2070,2136]
===
match
---
string: "state" [30753,30760]
string: "state" [30753,30760]
===
match
---
name: ti_extras [3812,3821]
name: ti_extras [3812,3821]
===
match
---
fstring_start: f" [11880,11882]
fstring_start: f" [11880,11882]
===
match
---
number: 400 [43245,43248]
number: 400 [43967,43970]
===
match
---
param [7283,7290]
param [7283,7290]
===
match
---
operator: , [11421,11422]
operator: , [11421,11422]
===
match
---
operator: , [25864,25865]
operator: , [25864,25865]
===
match
---
atom_expr [26534,26554]
atom_expr [26534,26554]
===
match
---
string: "state" [13470,13477]
string: "state" [13470,13477]
===
match
---
operator: } [17757,17758]
operator: } [17757,17758]
===
match
---
number: 1 [11062,11063]
number: 1 [11062,11063]
===
match
---
operator: , [29718,29719]
operator: , [29718,29719]
===
match
---
atom [27523,27584]
atom [27523,27584]
===
match
---
operator: , [18609,18610]
operator: , [18609,18610]
===
match
---
operator: } [17125,17126]
operator: } [17125,17126]
===
match
---
string: "operator" [6762,6772]
string: "operator" [6762,6772]
===
match
---
dictorsetmaker [33483,33504]
dictorsetmaker [34205,34226]
===
match
---
operator: } [19202,19203]
operator: } [19202,19203]
===
match
---
simple_stmt [16432,16467]
simple_stmt [16432,16467]
===
match
---
name: DEFAULT_DATETIME_1 [40859,40877]
name: DEFAULT_DATETIME_1 [41581,41599]
===
match
---
operator: = [41220,41221]
operator: = [41942,41943]
===
match
---
trailer [7860,7872]
trailer [7860,7872]
===
match
---
simple_stmt [16877,16898]
simple_stmt [16877,16898]
===
match
---
operator: = [11620,11621]
operator: = [11620,11621]
===
match
---
name: RUNNING [18110,18117]
name: RUNNING [18110,18117]
===
match
---
testlist_comp [14760,14880]
testlist_comp [14760,14880]
===
match
---
atom [21512,21530]
atom [21512,21530]
===
match
---
name: types [1189,1194]
name: types [1189,1194]
===
match
---
trailer [23815,24034]
trailer [23815,24034]
===
match
---
operator: , [22120,22121]
operator: , [22120,22121]
===
match
---
name: self [42922,42926]
name: self [43644,43648]
===
match
---
string: 'detail' [37461,37469]
string: 'detail' [38183,38191]
===
match
---
simple_stmt [25064,25099]
simple_stmt [25064,25099]
===
match
---
name: ACTION_CAN_READ [1762,1777]
name: ACTION_CAN_READ [1762,1777]
===
match
---
operator: , [15486,15487]
operator: , [15486,15487]
===
match
---
expr_stmt [1407,1459]
expr_stmt [1407,1459]
===
match
---
name: TestGetTaskInstances [9583,9603]
name: TestGetTaskInstances [9583,9603]
===
match
---
operator: , [12531,12532]
operator: , [12531,12532]
===
match
---
operator: , [27603,27604]
operator: , [27603,27604]
===
match
---
argument [7401,7428]
argument [7401,7428]
===
match
---
name: task_instances [20709,20723]
name: task_instances [20709,20723]
===
match
---
trailer [37772,37785]
trailer [38494,38507]
===
match
---
trailer [4634,4647]
trailer [4634,4647]
===
match
---
string: "task_id" [5888,5897]
string: "task_id" [5888,5897]
===
match
---
name: json [23366,23370]
name: json [23366,23370]
===
match
---
atom [24317,24365]
atom [24317,24365]
===
match
---
atom [32233,32415]
atom [32955,33137]
===
match
---
atom [18797,18829]
atom [18797,18829]
===
match
---
trailer [27413,27420]
trailer [27413,27420]
===
match
---
simple_stmt [33122,33358]
simple_stmt [33844,34080]
===
match
---
assert_stmt [33690,33724]
assert_stmt [34412,34446]
===
match
---
parameters [22941,22991]
parameters [22941,22991]
===
match
---
trailer [30886,30896]
trailer [30886,30896]
===
insert-node
---
name: TestPostClearTaskInstances [25158,25184]
to
classdef [25152,37483]
at 0
===
insert-node
---
name: TestTaskInstanceEndpoint [25185,25209]
to
classdef [25152,37483]
at 1
===
insert-tree
---
atom [31380,32088]
    testlist_comp [31398,32074]
        string: "dry_run default" [31398,31415]
        operator: , [31415,31416]
        string: "example_python_operator" [31433,31458]
        operator: , [31458,31459]
        atom [31476,31933]
            testlist_comp [31498,31915]
                atom [31498,31559]
                    operator: { [31498,31499]
                    dictorsetmaker [31499,31558]
                        string: "execution_date" [31499,31515]
                        name: DEFAULT_DATETIME_1 [31517,31535]
                        operator: , [31535,31536]
                        string: "state" [31537,31544]
                        atom_expr [31546,31558]
                            name: State [31546,31551]
                            trailer [31551,31558]
                                name: FAILED [31552,31558]
                    operator: } [31558,31559]
                operator: , [31559,31560]
                atom [31581,31736]
                    operator: { [31581,31582]
                    dictorsetmaker [31607,31714]
                        string: "execution_date" [31607,31623]
                        arith_expr [31625,31666]
                            name: DEFAULT_DATETIME_1 [31625,31643]
                            operator: + [31644,31645]
                            atom_expr [31646,31666]
                                name: dt [31646,31648]
                                trailer [31648,31658]
                                    name: timedelta [31649,31658]
                                trailer [31658,31666]
                                    argument [31659,31665]
                                        name: days [31659,31663]
                                        operator: = [31663,31664]
                                        number: 1 [31664,31665]
                        operator: , [31666,31667]
                        string: "state" [31692,31699]
                        atom_expr [31701,31713]
                            name: State [31701,31706]
                            trailer [31706,31713]
                                name: FAILED [31707,31713]
                        operator: , [31713,31714]
                    operator: } [31735,31736]
                operator: , [31736,31737]
                atom [31758,31914]
                    operator: { [31758,31759]
                    dictorsetmaker [31784,31892]
                        string: "execution_date" [31784,31800]
                        arith_expr [31802,31843]
                            name: DEFAULT_DATETIME_1 [31802,31820]
                            operator: + [31821,31822]
                            atom_expr [31823,31843]
                                name: dt [31823,31825]
                                trailer [31825,31835]
                                    name: timedelta [31826,31835]
                                trailer [31835,31843]
                                    argument [31836,31842]
                                        name: days [31836,31840]
                                        operator: = [31840,31841]
                                        number: 2 [31841,31842]
                        operator: , [31843,31844]
                        string: "state" [31869,31876]
                        atom_expr [31878,31891]
                            name: State [31878,31883]
                            trailer [31883,31891]
                                name: RUNNING [31884,31891]
                        operator: , [31891,31892]
                    operator: } [31913,31914]
                operator: , [31914,31915]
        operator: , [31933,31934]
        string: "example_python_operator" [31951,31976]
        operator: , [31976,31977]
        atom [31994,32054]
            operator: { [31994,31995]
            dictorsetmaker [32016,32036]
                string: "only_failed" [32016,32029]
                operator: , [32035,32036]
            operator: } [32053,32054]
        operator: , [32054,32055]
        number: 2 [32072,32073]
        operator: , [32073,32074]
to
testlist_comp [25261,31367]
at 14
===
insert-node
---
operator: , [32088,32089]
to
testlist_comp [25261,31367]
at 15
===
delete-node
---
name: TestPostClearTaskInstances [25158,25184]
===
===
delete-node
---
name: TestTaskInstanceEndpoint [25185,25209]
===
