===
match
---
expr_stmt [22157,22165]
expr_stmt [22157,22165]
===
match
---
operator: = [31268,31269]
operator: = [31654,31655]
===
match
---
operator: = [3397,3398]
operator: = [3397,3398]
===
match
---
name: op [16499,16501]
name: op [16499,16501]
===
match
---
atom_expr [3557,3570]
atom_expr [3557,3570]
===
match
---
arith_expr [12915,12937]
arith_expr [12915,12937]
===
match
---
fstring [28450,28465]
fstring [28836,28851]
===
match
---
name: dag [33965,33968]
name: dag [34351,34354]
===
match
---
name: State [3604,3609]
name: State [3604,3609]
===
match
---
dotted_name [18047,18061]
dotted_name [18047,18061]
===
match
---
comparison [34867,34951]
comparison [35253,35337]
===
match
---
name: i [9852,9853]
name: i [9852,9853]
===
match
---
trailer [11187,11257]
trailer [11187,11257]
===
match
---
name: task_id [13632,13639]
name: task_id [13632,13639]
===
match
---
argument [26104,26117]
argument [26490,26503]
===
match
---
operator: = [2730,2731]
operator: = [2730,2731]
===
match
---
name: logging [794,801]
name: logging [794,801]
===
match
---
name: timedelta [9129,9138]
name: timedelta [9129,9138]
===
match
---
import_from [1499,1542]
import_from [1499,1542]
===
match
---
atom_expr [32348,32439]
atom_expr [32734,32825]
===
match
---
operator: = [34936,34937]
operator: = [35322,35323]
===
match
---
operator: , [28021,28022]
operator: , [28407,28408]
===
match
---
name: dag [15638,15641]
name: dag [15638,15641]
===
match
---
atom_expr [8152,8170]
atom_expr [8152,8170]
===
match
---
suite [8209,8376]
suite [8209,8376]
===
match
---
simple_stmt [31070,31133]
simple_stmt [31456,31519]
===
match
---
trailer [25760,25768]
trailer [26146,26154]
===
match
---
argument [22286,22315]
argument [22286,22315]
===
match
---
operator: = [19526,19527]
operator: = [19526,19527]
===
match
---
name: failed_tis [8570,8580]
name: failed_tis [8570,8580]
===
match
---
lambdef [9810,9866]
lambdef [9810,9866]
===
match
---
operator: , [15299,15300]
operator: , [15299,15300]
===
match
---
argument [34444,34453]
argument [34830,34839]
===
match
---
operator: = [29440,29441]
operator: = [29826,29827]
===
match
---
name: external_task_id [19140,19156]
name: external_task_id [19140,19156]
===
match
---
name: dag_0 [26789,26794]
name: dag_0 [27175,27180]
===
match
---
name: allowed_states [12419,12433]
name: allowed_states [12419,12433]
===
match
---
name: ValueError [14669,14679]
name: ValueError [14669,14679]
===
match
---
operator: , [19167,19168]
operator: , [19167,19168]
===
match
---
name: tomorrow_ds_nodash [12798,12816]
name: tomorrow_ds_nodash [12798,12816]
===
match
---
operator: { [22163,22164]
operator: { [22163,22164]
===
match
---
operator: } [29063,29064]
operator: } [29449,29450]
===
match
---
operator: { [28615,28616]
operator: { [29001,29002]
===
match
---
and_test [8888,8966]
and_test [8888,8966]
===
match
---
operator: , [29119,29120]
operator: , [29505,29506]
===
match
---
for_stmt [20330,20418]
for_stmt [20330,20418]
===
match
---
fstring_start: f" [28609,28611]
fstring_start: f" [28995,28997]
===
match
---
arglist [6743,6828]
arglist [6743,6828]
===
match
---
simple_stmt [12159,12184]
simple_stmt [12159,12184]
===
match
---
name: test_external_task_sensor [2379,2404]
name: test_external_task_sensor [2379,2404]
===
match
---
string: '_external' [7538,7549]
string: '_external' [7538,7549]
===
match
---
operator: = [10674,10675]
operator: = [10674,10675]
===
match
---
operator: , [21879,21880]
operator: , [21879,21880]
===
match
---
trailer [28528,28733]
trailer [28914,29119]
===
match
---
name: external_task_id [19793,19809]
name: external_task_id [19793,19809]
===
match
---
operator: = [28013,28014]
operator: = [28399,28400]
===
match
---
operator: , [31116,31117]
operator: , [31502,31503]
===
match
---
atom_expr [8796,8816]
atom_expr [8796,8816]
===
match
---
name: self [14486,14490]
name: self [14486,14490]
===
match
---
operator: = [19028,19029]
operator: = [19028,19029]
===
match
---
string: 'test_external_task_sensor_check_task_ids' [5712,5754]
string: 'test_external_task_sensor_check_task_ids' [5712,5754]
===
match
---
name: DEV_NULL [33166,33174]
name: DEV_NULL [33552,33560]
===
match
---
trailer [23318,23458]
trailer [23704,23844]
===
match
---
name: TimeSensor [1292,1302]
name: TimeSensor [1292,1302]
===
match
---
name: dag_0 [29933,29938]
name: dag_0 [30319,30324]
===
match
---
name: dag [13264,13267]
name: dag [13264,13267]
===
match
---
operator: = [30834,30835]
operator: = [31220,31221]
===
match
---
operator: = [31325,31326]
operator: = [31711,31712]
===
match
---
operator: = [29048,29049]
operator: = [29434,29435]
===
match
---
name: test_time_sensor [2862,2878]
name: test_time_sensor [2862,2878]
===
match
---
argument [11529,11580]
argument [11529,11580]
===
match
---
trailer [28927,28932]
trailer [29313,29318]
===
match
---
name: dag_bag [34902,34909]
name: dag_bag [35288,35295]
===
match
---
argument [28872,28894]
argument [29258,29280]
===
match
---
name: task_id [21267,21274]
name: task_id [21267,21274]
===
match
---
operator: = [15441,15442]
operator: = [15441,15442]
===
match
---
name: session [23436,23443]
name: session [23822,23829]
===
match
---
operator: = [29250,29251]
operator: = [29636,29637]
===
match
---
arglist [17899,17933]
arglist [17899,17933]
===
match
---
operator: = [25193,25194]
operator: = [25579,25580]
===
match
---
string: """Check this task sensor passes multiple args with full context. If no failure, means clean run.""" [11928,12028]
string: """Check this task sensor passes multiple args with full context. If no failure, means clean run.""" [11928,12028]
===
match
---
simple_stmt [26468,26664]
simple_stmt [26854,27050]
===
match
---
arglist [18934,18990]
arglist [18934,18990]
===
match
---
operator: , [15477,15478]
operator: , [15477,15478]
===
match
---
operator: , [20354,20355]
operator: , [20354,20355]
===
match
---
name: refresh_from_db [22875,22890]
name: refresh_from_db [23261,23276]
===
match
---
atom_expr [5314,5323]
atom_expr [5314,5323]
===
match
---
simple_stmt [22580,22604]
simple_stmt [22966,22990]
===
match
---
operator: = [33839,33840]
operator: = [34225,34226]
===
match
---
name: task_id [15775,15782]
name: task_id [15775,15782]
===
match
---
string: "external_task_marker_child" [17548,17576]
string: "external_task_marker_child" [17548,17576]
===
match
---
atom [13899,13910]
atom [13899,13910]
===
match
---
simple_stmt [25025,25120]
simple_stmt [25411,25506]
===
match
---
simple_stmt [29489,29505]
simple_stmt [29875,29891]
===
match
---
operator: , [1664,1665]
operator: , [1664,1665]
===
match
---
simple_stmt [18834,18850]
simple_stmt [18834,18850]
===
match
---
trailer [33465,33473]
trailer [33851,33859]
===
match
---
suite [20503,21935]
suite [20503,21935]
===
match
---
name: task_0 [24716,24722]
name: task_0 [25102,25108]
===
match
---
parameters [27012,27014]
parameters [27398,27400]
===
match
---
expr_stmt [27931,28083]
expr_stmt [28317,28469]
===
match
---
name: start_date [17425,17435]
name: start_date [17425,17435]
===
match
---
name: task_id [9214,9221]
name: task_id [9214,9221]
===
match
---
name: end_date [8295,8303]
name: end_date [8295,8303]
===
match
---
atom_expr [22522,22532]
atom_expr [22908,22918]
===
match
---
name: e [9029,9030]
name: e [9029,9030]
===
match
---
string: 'test_serialized_external_task_marker' [17385,17423]
string: 'test_serialized_external_task_marker' [17385,17423]
===
match
---
expr_stmt [33296,33515]
expr_stmt [33682,33901]
===
match
---
simple_stmt [7336,7498]
simple_stmt [7336,7498]
===
match
---
simple_stmt [24186,24227]
simple_stmt [24572,24613]
===
match
---
operator: , [31045,31046]
operator: , [31431,31432]
===
match
---
arglist [7188,7256]
arglist [7188,7256]
===
match
---
comparison [17073,17136]
comparison [17073,17136]
===
match
---
name: ctx [4962,4965]
name: ctx [4962,4965]
===
match
---
name: include_examples [30767,30783]
name: include_examples [31153,31169]
===
match
---
atom_expr [33303,33515]
atom_expr [33689,33901]
===
match
---
expr_stmt [1960,2024]
expr_stmt [1960,2024]
===
match
---
funcdef [12070,12184]
funcdef [12070,12184]
===
match
---
name: dagrun [34139,34145]
name: dagrun [34525,34531]
===
match
---
trailer [30894,30958]
trailer [31280,31344]
===
match
---
operator: = [24121,24122]
operator: = [24507,24508]
===
match
---
name: cm [4906,4908]
name: cm [4906,4908]
===
match
---
operator: = [28659,28660]
operator: = [29045,29046]
===
match
---
name: start_date [32362,32372]
name: start_date [32748,32758]
===
match
---
argument [7213,7234]
argument [7213,7234]
===
match
---
name: State [26290,26295]
name: State [26676,26681]
===
match
---
string: 'test_external_task_sensor_check' [3398,3431]
string: 'test_external_task_sensor_check' [3398,3431]
===
match
---
expr_stmt [25727,25768]
expr_stmt [26113,26154]
===
match
---
name: DEFAULT_DATE [10675,10687]
name: DEFAULT_DATE [10675,10687]
===
match
---
name: ti [30549,30551]
name: ti [30935,30937]
===
match
---
name: timedelta [8796,8805]
name: timedelta [8796,8805]
===
match
---
argument [16299,16333]
argument [16299,16333]
===
match
---
atom [23253,23267]
atom [23639,23653]
===
match
---
name: airflow [1176,1183]
name: airflow [1176,1183]
===
match
---
argument [23269,23292]
argument [23655,23678]
===
match
---
lambdef [21710,21773]
lambdef [21710,21773]
===
match
---
operator: , [3900,3901]
operator: , [3900,3901]
===
match
---
name: fixture [26986,26993]
name: fixture [27372,27379]
===
match
---
operator: = [8581,8582]
operator: = [8581,8582]
===
match
---
name: TEST_TASK_ID [15237,15249]
name: TEST_TASK_ID [15237,15249]
===
match
---
operator: , [30992,30993]
operator: , [31378,31379]
===
match
---
string: 'external_task_id' [18007,18025]
string: 'external_task_id' [18007,18025]
===
match
---
argument [27776,27799]
argument [28162,28185]
===
match
---
string: """     Test clearing a dag that has multiple ExternalTaskMarker.      sqlite3 parser stack size is 100 lexical items by default so this puts a hard limit on     the level of nesting in the sql. This test is intentionally skipped in sqlite.     """ [31673,31921]
string: """     Test clearing a dag that has multiple ExternalTaskMarker.      sqlite3 parser stack size is 100 lexical items by default so this puts a hard limit on     the level of nesting in the sql. This test is intentionally skipped in sqlite.     """ [32059,32307]
===
match
---
name: session [23967,23974]
name: session [24353,24360]
===
match
---
string: 'invalid_state' [15283,15298]
string: 'invalid_state' [15283,15298]
===
match
---
argument [30824,30847]
argument [31210,31233]
===
match
---
operator: , [21442,21443]
operator: , [21442,21443]
===
match
---
trailer [11747,11768]
trailer [11747,11768]
===
match
---
trailer [2942,3154]
trailer [2942,3154]
===
match
---
name: DEV_NULL [30757,30765]
name: DEV_NULL [31143,31151]
===
match
---
atom [11123,11134]
atom [11123,11134]
===
match
---
operator: = [21493,21494]
operator: = [21493,21494]
===
match
---
trailer [34473,34488]
trailer [34859,34874]
===
match
---
trailer [17013,17029]
trailer [17013,17029]
===
match
---
name: DAG [27763,27766]
name: DAG [28149,28152]
===
match
---
string: "dag_0" [23634,23641]
string: "dag_0" [24020,24027]
===
match
---
arglist [19887,19989]
arglist [19887,19989]
===
match
---
argument [21692,21773]
argument [21692,21773]
===
match
---
name: dag_0 [23658,23663]
name: dag_0 [24044,24049]
===
match
---
argument [9214,9244]
argument [9214,9244]
===
match
---
decorator [22935,22952]
decorator [23321,23338]
===
match
---
simple_stmt [25124,25218]
simple_stmt [25510,25604]
===
match
---
number: 1 [1663,1664]
number: 1 [1663,1664]
===
match
---
name: DagRunState [34205,34216]
name: DagRunState [34591,34602]
===
match
---
number: 51 [32443,32445]
number: 51 [32829,32831]
===
match
---
operator: , [13210,13211]
operator: , [13210,13211]
===
match
---
name: dag [20399,20402]
name: dag [20399,20402]
===
match
---
name: external_task_id [13742,13758]
name: external_task_id [13742,13758]
===
match
---
name: depth [28838,28843]
name: depth [29224,29229]
===
match
---
atom_expr [9100,9109]
atom_expr [9100,9109]
===
match
---
name: ExternalTaskSensor [21543,21561]
name: ExternalTaskSensor [21543,21561]
===
match
---
trailer [15416,15656]
trailer [15416,15656]
===
match
---
name: raises [15366,15372]
name: raises [15366,15372]
===
match
---
string: 'success' [11610,11619]
string: 'success' [11610,11619]
===
match
---
name: ExternalTaskSensor [13010,13028]
name: ExternalTaskSensor [13010,13028]
===
match
---
argument [2130,2152]
argument [2130,2152]
===
match
---
operator: , [12282,12283]
operator: , [12282,12283]
===
match
---
trailer [23700,23730]
trailer [24086,24116]
===
match
---
argument [3918,3947]
argument [3918,3947]
===
match
---
name: range [9430,9435]
name: range [9430,9435]
===
match
---
name: day_1 [24997,25002]
name: day_1 [25383,25388]
===
match
---
name: dag [3140,3143]
name: dag [3140,3143]
===
match
---
comparison [17000,17061]
comparison [17000,17061]
===
match
---
argument [30994,31012]
argument [31380,31398]
===
match
---
argument [6890,6913]
argument [6890,6913]
===
match
---
operator: , [13128,13129]
operator: , [13128,13129]
===
match
---
operator: = [23081,23082]
operator: = [23467,23468]
===
match
---
operator: = [14485,14486]
operator: = [14485,14486]
===
match
---
arglist [21267,21443]
arglist [21267,21443]
===
match
---
string: "task_a_1" [30426,30436]
string: "task_a_1" [30812,30822]
===
match
---
suite [16629,17137]
suite [16629,17137]
===
match
---
argument [25873,25894]
argument [26259,26280]
===
match
---
name: task_id [31384,31391]
name: task_id [31770,31777]
===
match
---
atom_expr [22182,22203]
atom_expr [22182,22203]
===
match
---
parameters [18077,18079]
parameters [18077,18079]
===
match
---
simple_stmt [24606,24646]
simple_stmt [24992,25032]
===
match
---
operator: = [33146,33147]
operator: = [33532,33533]
===
match
---
arglist [4391,4459]
arglist [4391,4459]
===
match
---
name: task_id [7896,7903]
name: task_id [7896,7903]
===
match
---
name: task_ids_or_regex [23235,23252]
name: task_ids_or_regex [23621,23638]
===
match
---
suite [16198,16576]
suite [16198,16576]
===
match
---
trailer [25045,25053]
trailer [25431,25439]
===
match
---
name: self [14018,14022]
name: self [14018,14022]
===
match
---
name: task_b [28760,28766]
name: task_b [29146,29152]
===
match
---
trailer [17127,17132]
trailer [17127,17132]
===
match
---
string: 'owner' [2046,2053]
string: 'owner' [2046,2053]
===
match
---
operator: = [16745,16746]
operator: = [16745,16746]
===
match
---
atom_expr [24614,24645]
atom_expr [25000,25031]
===
match
---
fstring_end: " [31295,31296]
fstring_end: " [31681,31682]
===
match
---
name: end_date [2325,2333]
name: end_date [2325,2333]
===
match
---
argument [10664,10687]
argument [10664,10687]
===
match
---
name: DEFAULT_DATE [18954,18966]
name: DEFAULT_DATE [18954,18966]
===
match
---
import_from [1073,1120]
import_from [1073,1120]
===
match
---
operator: = [21121,21122]
operator: = [21121,21122]
===
match
---
simple_stmt [21027,21043]
simple_stmt [21027,21043]
===
match
---
trailer [6847,6861]
trailer [6847,6861]
===
match
---
operator: = [10599,10600]
operator: = [10599,10600]
===
match
---
trailer [10633,10637]
trailer [10633,10637]
===
match
---
name: external_dag_id [16730,16745]
name: external_dag_id [16730,16745]
===
match
---
strings [5328,5445]
strings [5328,5445]
===
match
---
arglist [2667,2735]
arglist [2667,2735]
===
match
---
trailer [2475,2651]
trailer [2475,2651]
===
match
---
name: op [6010,6012]
name: op [6010,6012]
===
match
---
assert_stmt [6472,6677]
assert_stmt [6472,6677]
===
match
---
trailer [31096,31132]
trailer [31482,31518]
===
match
---
name: start_date [13304,13314]
name: start_date [13304,13314]
===
match
---
name: dag_bag [21048,21055]
name: dag_bag [21048,21055]
===
match
---
name: DEFAULT_DATE [32042,32054]
name: DEFAULT_DATE [32428,32440]
===
match
---
funcdef [13961,14510]
funcdef [13961,14510]
===
match
---
operator: , [26888,26889]
operator: , [27274,27275]
===
match
---
name: dag [33826,33829]
name: dag [34212,34215]
===
match
---
name: my_func [12398,12405]
name: my_func [12398,12405]
===
match
---
name: ignore_ti_state [2715,2730]
name: ignore_ti_state [2715,2730]
===
match
---
name: failed_tis [8892,8902]
name: failed_tis [8892,8902]
===
match
---
simple_stmt [30881,30959]
simple_stmt [31267,31345]
===
match
---
operator: } [34341,34342]
operator: } [34727,34728]
===
match
---
argument [14795,14822]
argument [14795,14822]
===
match
---
operator: = [16210,16211]
operator: = [16210,16211]
===
match
---
argument [33545,33559]
argument [33931,33945]
===
match
---
atom_expr [21146,21207]
atom_expr [21146,21207]
===
match
---
name: retries [7791,7798]
name: retries [7791,7798]
===
match
---
operator: = [28557,28558]
operator: = [28943,28944]
===
match
---
operator: = [31167,31168]
operator: = [31553,31554]
===
match
---
name: task_instance [22904,22917]
name: task_instance [23290,23303]
===
match
---
name: clear [34871,34876]
name: clear [35257,35262]
===
match
---
name: utils [1392,1397]
name: utils [1392,1397]
===
match
---
name: self [3640,3644]
name: self [3640,3644]
===
match
---
name: DEFAULT_DATE [11825,11837]
name: DEFAULT_DATE [11825,11837]
===
match
---
operator: , [34343,34344]
operator: , [34729,34730]
===
match
---
name: i [9425,9426]
name: i [9425,9426]
===
match
---
operator: = [22220,22221]
operator: = [22220,22221]
===
match
---
trailer [20268,20299]
trailer [20268,20299]
===
match
---
name: dag [34973,34976]
name: dag [35359,35362]
===
match
---
operator: = [7944,7945]
operator: = [7944,7945]
===
match
---
argument [11657,11672]
argument [11657,11672]
===
match
---
operator: , [31175,31176]
operator: , [31561,31562]
===
match
---
name: dag_bag_ext [25909,25920]
name: dag_bag_ext [26295,26306]
===
match
---
param [10772,10776]
param [10772,10776]
===
match
---
argument [25761,25767]
argument [26147,26153]
===
match
---
name: run [10044,10047]
name: run [10044,10047]
===
match
---
operator: = [7867,7868]
operator: = [7867,7868]
===
match
---
operator: = [33301,33302]
operator: = [33687,33688]
===
match
---
expr_stmt [33138,33199]
expr_stmt [33524,33585]
===
match
---
parameters [12613,12619]
parameters [12613,12619]
===
match
---
fstring_start: f" [28450,28452]
fstring_start: f" [28836,28838]
===
match
---
name: external_dag_id [33363,33378]
name: external_dag_id [33749,33764]
===
match
---
comparison [6497,6663]
comparison [6497,6663]
===
match
---
trailer [31208,31212]
trailer [31594,31598]
===
match
---
string: "%Y%m%d" [12948,12956]
string: "%Y%m%d" [12948,12956]
===
match
---
comparison [6232,6445]
comparison [6232,6445]
===
match
---
operator: = [16539,16540]
operator: = [16539,16540]
===
match
---
name: dag_2 [20356,20361]
name: dag_2 [20356,20361]
===
match
---
name: execution_date_fn [9792,9809]
name: execution_date_fn [9792,9809]
===
match
---
string: "dag_2" [30479,30486]
string: "dag_2" [30865,30872]
===
match
---
atom_expr [8913,8934]
atom_expr [8913,8934]
===
match
---
atom_expr [12171,12183]
atom_expr [12171,12183]
===
match
---
name: _factory [29496,29504]
name: _factory [29882,29890]
===
match
---
argument [2715,2735]
argument [2715,2735]
===
match
---
arglist [6875,6963]
arglist [6875,6963]
===
match
---
argument [6915,6942]
argument [6915,6942]
===
match
---
operator: , [15522,15523]
operator: , [15522,15523]
===
match
---
name: task_b_3 [20316,20324]
name: task_b_3 [20316,20324]
===
match
---
name: AirflowException [943,959]
name: AirflowException [943,959]
===
match
---
operator: , [19959,19960]
operator: , [19959,19960]
===
match
---
operator: , [20187,20188]
operator: , [20187,20188]
===
match
---
argument [17532,17576]
argument [17532,17576]
===
match
---
string: "{{ tomorrow_ds_nodash }}" [33734,33760]
string: "{{ tomorrow_ds_nodash }}" [34120,34146]
===
match
---
arglist [8664,8817]
arglist [8664,8817]
===
match
---
classdef [1882,16576]
classdef [1882,16576]
===
match
---
parameters [7320,7326]
parameters [7320,7326]
===
match
---
operator: , [7059,7060]
operator: , [7059,7060]
===
match
---
simple_stmt [21115,21136]
simple_stmt [21115,21136]
===
match
---
name: dag_id [8667,8673]
name: dag_id [8667,8673]
===
match
---
name: op [10657,10659]
name: op [10657,10659]
===
match
---
operator: = [20205,20206]
operator: = [20205,20206]
===
match
---
argument [9647,9674]
argument [9647,9674]
===
match
---
name: external_dag_id [21297,21312]
name: external_dag_id [21297,21312]
===
match
---
trailer [10047,10117]
trailer [10047,10117]
===
match
---
trailer [14956,14960]
trailer [14956,14960]
===
match
---
arglist [19491,19593]
arglist [19491,19593]
===
match
---
name: dt [9395,9397]
name: dt [9395,9397]
===
match
---
name: dagrun [22213,22219]
name: dagrun [22213,22219]
===
match
---
atom_expr [17891,17934]
atom_expr [17891,17934]
===
match
---
operator: = [15510,15511]
operator: = [15510,15511]
===
match
---
name: dag [16416,16419]
name: dag [16416,16419]
===
match
---
operator: = [23252,23253]
operator: = [23638,23639]
===
match
---
name: ignore_ti_state [11236,11251]
name: ignore_ti_state [11236,11251]
===
match
---
import_from [1379,1428]
import_from [1379,1428]
===
match
---
name: pytest [13557,13563]
name: pytest [13557,13563]
===
match
---
name: allowed_states [13224,13238]
name: allowed_states [13224,13238]
===
match
---
arglist [28340,28466]
arglist [28726,28852]
===
match
---
number: 0 [7945,7946]
number: 0 [7945,7946]
===
match
---
string: "task_b_3" [20277,20287]
string: "task_b_3" [20277,20287]
===
match
---
name: dt [13860,13862]
name: dt [13860,13862]
===
match
---
arglist [21575,21805]
arglist [21575,21805]
===
match
---
string: 'task_without_failure' [9222,9244]
string: 'task_without_failure' [9222,9244]
===
match
---
operator: = [12509,12510]
operator: = [12509,12510]
===
match
---
param [23018,23042]
param [23404,23428]
===
match
---
name: DEFAULT_DATE [10237,10249]
name: DEFAULT_DATE [10237,10249]
===
match
---
argument [7759,7789]
argument [7759,7789]
===
match
---
name: dag_bag_cyclic [26998,27012]
name: dag_bag_cyclic [27384,27398]
===
match
---
param [29997,30011]
param [30383,30397]
===
match
---
operator: , [18005,18006]
operator: , [18005,18006]
===
match
---
name: external_dag_id [3873,3888]
name: external_dag_id [3873,3888]
===
match
---
expr_stmt [23606,23642]
expr_stmt [23992,24028]
===
match
---
name: task_with_failure [9595,9612]
name: task_with_failure [9595,9612]
===
match
---
operator: = [12562,12563]
operator: = [12562,12563]
===
match
---
name: task_id [33698,33705]
name: task_id [34084,34091]
===
match
---
name: dag_bag [24384,24391]
name: dag_bag [24770,24777]
===
match
---
name: dag [33652,33655]
name: dag [34038,34041]
===
match
---
name: daily_dag [31003,31012]
name: daily_dag [31389,31398]
===
match
---
param [13860,13862]
param [13860,13862]
===
match
---
operator: , [28361,28362]
operator: , [28747,28748]
===
match
---
operator: = [19948,19949]
operator: = [19948,19949]
===
match
---
operator: , [19365,19366]
operator: , [19365,19366]
===
match
---
argument [12524,12545]
argument [12524,12545]
===
match
---
argument [7188,7211]
argument [7188,7211]
===
match
---
operator: , [11580,11581]
operator: , [11580,11581]
===
match
---
atom_expr [14147,14172]
atom_expr [14147,14172]
===
match
---
simple_stmt [24650,24684]
simple_stmt [25036,25070]
===
match
---
trailer [32361,32439]
trailer [32747,32825]
===
match
---
arglist [29437,29458]
arglist [29823,29844]
===
match
---
name: external_task_id [4701,4717]
name: external_task_id [4701,4717]
===
match
---
simple_stmt [16207,16440]
simple_stmt [16207,16440]
===
match
---
operator: = [16830,16831]
operator: = [16830,16831]
===
match
---
trailer [8891,8903]
trailer [8891,8903]
===
match
---
name: external_dag_id [15830,15845]
name: external_dag_id [15830,15845]
===
match
---
argument [31034,31045]
argument [31420,31431]
===
match
---
param [15019,15023]
param [15019,15023]
===
match
---
operator: } [28181,28182]
operator: } [28567,28568]
===
match
---
name: ti_b_3 [23764,23770]
name: ti_b_3 [24150,24156]
===
match
---
trailer [14712,14975]
trailer [14712,14975]
===
match
---
operator: @ [18046,18047]
operator: @ [18046,18047]
===
match
---
string: """     Clearing across multiple DAGs should raise AirflowException if more levels are being cleared     than allowed by the recursion_depth of the first ExternalTaskMarker being cleared.     """ [26468,26663]
string: """     Clearing across multiple DAGs should raise AirflowException if more levels are being cleared     than allowed by the recursion_depth of the first ExternalTaskMarker being cleared.     """ [26854,27049]
===
match
---
name: start_date [2667,2677]
name: start_date [2667,2677]
===
match
---
name: state [34515,34520]
name: state [34901,34906]
===
match
---
atom_expr [15359,15384]
atom_expr [15359,15384]
===
match
---
name: dag_1 [19588,19593]
name: dag_1 [19588,19593]
===
match
---
suite [27659,29484]
suite [28045,29870]
===
match
---
name: output [5252,5258]
name: output [5252,5258]
===
match
---
trailer [34560,34566]
trailer [34946,34952]
===
match
---
name: dagrun_1_2 [25222,25232]
name: dagrun_1_2 [25608,25618]
===
match
---
expr_stmt [21226,21453]
expr_stmt [21226,21453]
===
match
---
simple_stmt [22674,22715]
simple_stmt [23060,23101]
===
match
---
operator: = [27744,27745]
operator: = [28130,28131]
===
match
---
simple_stmt [19208,19229]
simple_stmt [19208,19229]
===
match
---
atom_expr [26183,26205]
atom_expr [26569,26591]
===
match
---
suite [28241,28767]
suite [28627,29153]
===
match
---
trailer [21064,21109]
trailer [21064,21109]
===
match
---
trailer [26073,26118]
trailer [26459,26504]
===
match
---
operator: = [5893,5894]
operator: = [5893,5894]
===
match
---
argument [13835,13866]
argument [13835,13866]
===
match
---
name: ignore_ti_state [2348,2363]
name: ignore_ti_state [2348,2363]
===
match
---
atom_expr [33210,33279]
atom_expr [33596,33665]
===
match
---
name: session [22408,22415]
name: session [22408,22415]
===
match
---
trailer [10808,10810]
trailer [10808,10810]
===
match
---
trailer [26752,26761]
trailer [27138,27147]
===
match
---
name: session [25111,25118]
name: session [25497,25504]
===
match
---
import_as_names [1461,1498]
import_as_names [1461,1498]
===
match
---
name: days [11573,11577]
name: days [11573,11577]
===
match
---
trailer [13936,13940]
trailer [13936,13940]
===
match
---
operator: = [33470,33471]
operator: = [33856,33857]
===
match
---
name: DummyOperator [1157,1170]
name: DummyOperator [1157,1170]
===
match
---
number: 1 [24178,24179]
number: 1 [24564,24565]
===
match
---
name: pytest [30590,30596]
name: pytest [30976,30982]
===
match
---
name: DagBag [30739,30745]
name: DagBag [31125,31131]
===
match
---
operator: = [14229,14230]
operator: = [14229,14230]
===
match
---
name: get_dag [33994,34001]
name: get_dag [34380,34387]
===
match
---
trailer [12494,12498]
trailer [12494,12498]
===
match
---
operator: , [14777,14778]
operator: , [14777,14778]
===
match
---
shift_expr [31503,31516]
shift_expr [31889,31902]
===
match
---
expr_stmt [7506,7549]
expr_stmt [7506,7549]
===
match
---
name: get_task [26753,26761]
name: get_task [27139,27147]
===
match
---
name: task_b_3 [20244,20252]
name: task_b_3 [20244,20252]
===
match
---
name: dag_bag [21856,21863]
name: dag_bag [21856,21863]
===
match
---
name: run [11787,11790]
name: run [11787,11790]
===
match
---
name: tail [33796,33800]
name: tail [34182,34186]
===
match
---
trailer [14490,14494]
trailer [14490,14494]
===
match
---
simple_stmt [31522,31536]
simple_stmt [31908,31922]
===
match
---
string: "task_a_2" [19553,19563]
string: "task_a_2" [19553,19563]
===
match
---
operator: = [3464,3465]
operator: = [3464,3465]
===
match
---
operator: , [14930,14931]
operator: , [14930,14931]
===
match
---
name: set_state [24556,24565]
name: set_state [24942,24951]
===
match
---
atom_expr [32057,32078]
atom_expr [32443,32464]
===
match
---
name: serialize_operator [17701,17719]
name: serialize_operator [17701,17719]
===
match
---
expr_stmt [23764,23788]
expr_stmt [24150,24174]
===
match
---
trailer [6504,6510]
trailer [6504,6510]
===
match
---
name: dag_0 [25953,25958]
name: dag_0 [26339,26344]
===
match
---
name: external_dag_id [7073,7088]
name: external_dag_id [7073,7088]
===
match
---
parameters [15018,15024]
parameters [15018,15024]
===
match
---
name: TI [8714,8716]
name: TI [8714,8716]
===
match
---
atom_expr [24688,24774]
atom_expr [25074,25160]
===
match
---
name: ctx [6097,6100]
name: ctx [6097,6100]
===
match
---
name: ExternalTaskMarker [1213,1231]
name: ExternalTaskMarker [1213,1231]
===
match
---
trailer [30551,30558]
trailer [30937,30944]
===
match
---
simple_stmt [23764,23789]
simple_stmt [24150,24175]
===
match
---
number: 1 [8337,8338]
number: 1 [8337,8338]
===
match
---
arglist [21065,21108]
arglist [21065,21108]
===
match
---
funcdef [2742,3240]
funcdef [2742,3240]
===
match
---
number: 0 [9501,9502]
number: 0 [9501,9502]
===
match
---
name: external_dag_id [11445,11460]
name: external_dag_id [11445,11460]
===
match
---
simple_stmt [16660,16818]
simple_stmt [16660,16818]
===
match
---
name: clear_db_runs [1864,1877]
name: clear_db_runs [1864,1877]
===
match
---
name: dag_0 [26087,26092]
name: dag_0 [26473,26478]
===
match
---
name: clear_tasks [29912,29923]
name: clear_tasks [30298,30309]
===
match
---
name: external_task_id [15540,15556]
name: external_task_id [15540,15556]
===
match
---
simple_stmt [22547,22568]
simple_stmt [22933,22954]
===
match
---
name: bag_dag [21864,21871]
name: bag_dag [21864,21871]
===
match
---
name: start_date [8031,8041]
name: start_date [8031,8041]
===
match
---
expr_stmt [21048,21109]
expr_stmt [21048,21109]
===
match
---
operator: = [24937,24938]
operator: = [25323,25324]
===
match
---
simple_stmt [21856,21895]
simple_stmt [21856,21895]
===
match
---
atom_expr [7869,7974]
atom_expr [7869,7974]
===
match
---
argument [9688,9719]
argument [9688,9719]
===
match
---
trailer [17057,17059]
trailer [17057,17059]
===
match
---
trailer [2666,2736]
trailer [2666,2736]
===
match
---
operator: , [7946,7947]
operator: , [7946,7947]
===
match
---
operator: , [18941,18942]
operator: , [18941,18942]
===
match
---
fstring_string: dag_ [17035,17039]
fstring_string: dag_ [17035,17039]
===
match
---
fstring_start: f" [28660,28662]
fstring_start: f" [29046,29048]
===
match
---
name: session [34937,34944]
name: session [35323,35330]
===
match
---
name: DEFAULT_DATE [34888,34900]
name: DEFAULT_DATE [35274,35286]
===
match
---
arglist [24700,24773]
arglist [25086,25159]
===
match
---
argument [2233,2248]
argument [2233,2248]
===
match
---
simple_stmt [20379,20418]
simple_stmt [20379,20418]
===
match
---
operator: , [11431,11432]
operator: , [11431,11432]
===
match
---
name: DEFAULT_DATE [28196,28208]
name: DEFAULT_DATE [28582,28594]
===
match
---
expr_stmt [34426,34454]
expr_stmt [34812,34840]
===
match
---
operator: = [7354,7355]
operator: = [7354,7355]
===
match
---
simple_stmt [22025,22153]
simple_stmt [22025,22153]
===
match
---
expr_stmt [1633,1668]
expr_stmt [1633,1668]
===
match
---
operator: = [2310,2311]
operator: = [2310,2311]
===
match
---
argument [20404,20416]
argument [20404,20416]
===
match
---
operator: , [12366,12367]
operator: , [12366,12367]
===
match
---
name: external_dag_id [17014,17029]
name: external_dag_id [17014,17029]
===
match
---
name: tomorrow_ds_nodash [12892,12910]
name: tomorrow_ds_nodash [12892,12910]
===
match
---
operator: , [10249,10250]
operator: , [10249,10250]
===
match
---
arith_expr [24148,24180]
arith_expr [24534,24566]
===
match
---
string: "task_a_0" [30364,30374]
string: "task_a_0" [30750,30760]
===
match
---
name: range [31990,31995]
name: range [32376,32381]
===
match
---
name: task_b_2 [19848,19856]
name: task_b_2 [19848,19856]
===
match
---
simple_stmt [34956,35156]
simple_stmt [35342,35542]
===
match
---
operator: == [25345,25347]
operator: == [25731,25733]
===
match
---
argument [7896,7935]
argument [7896,7935]
===
match
---
string: "task_b_2" [19895,19905]
string: "task_b_2" [19895,19905]
===
match
---
name: dag [4361,4364]
name: dag [4361,4364]
===
match
---
number: 0 [12992,12993]
number: 0 [12992,12993]
===
match
---
name: DagRunType [16865,16875]
name: DagRunType [16865,16875]
===
match
---
operator: , [31483,31484]
operator: , [31869,31870]
===
match
---
atom [27746,27748]
atom [28132,28134]
===
match
---
operator: , [24248,24249]
operator: , [24634,24635]
===
match
---
atom_expr [30149,30166]
atom_expr [30535,30552]
===
match
---
funcdef [2159,2370]
funcdef [2159,2370]
===
match
---
expr_stmt [25901,25937]
expr_stmt [26287,26323]
===
match
---
operator: , [5754,5755]
operator: , [5754,5755]
===
match
---
expr_stmt [26167,26205]
expr_stmt [26553,26591]
===
match
---
operator: = [15845,15846]
operator: = [15845,15846]
===
match
---
decorator [30589,30605]
decorator [30975,30991]
===
match
---
operator: = [16067,16068]
operator: = [16067,16068]
===
match
---
name: State [22700,22705]
name: State [23086,23091]
===
match
---
name: dag_bag_multiple [31936,31952]
name: dag_bag_multiple [32322,32338]
===
match
---
operator: = [18953,18954]
operator: = [18953,18954]
===
match
---
trailer [34154,34354]
trailer [34540,34740]
===
match
---
name: DEFAULT_DATE [19266,19278]
name: DEFAULT_DATE [19266,19278]
===
match
---
operator: , [34927,34928]
operator: , [35313,35314]
===
match
---
atom_expr [25751,25768]
atom_expr [26137,26154]
===
match
---
trailer [15761,15990]
trailer [15761,15990]
===
match
---
suite [18080,20458]
suite [18080,20458]
===
match
---
argument [33363,33389]
argument [33749,33775]
===
match
---
operator: = [19461,19462]
operator: = [19461,19462]
===
match
---
name: dag [22986,22989]
name: dag [23372,23375]
===
match
---
name: TEST_TASK_ID [10517,10529]
name: TEST_TASK_ID [10517,10529]
===
match
---
arglist [31261,31484]
arglist [31647,31870]
===
match
---
name: self [2275,2279]
name: self [2275,2279]
===
match
---
operator: = [4182,4183]
operator: = [4182,4183]
===
match
---
argument [29033,29065]
argument [29419,29451]
===
match
---
trailer [23633,23642]
trailer [24019,24028]
===
match
---
name: ExternalTaskSensor [14694,14712]
name: ExternalTaskSensor [14694,14712]
===
match
---
operator: = [21356,21357]
operator: = [21356,21357]
===
match
---
trailer [29814,29826]
trailer [30200,30212]
===
match
---
trailer [11572,11580]
trailer [11572,11580]
===
match
---
testlist_comp [9822,9865]
testlist_comp [9822,9865]
===
match
---
name: create_dagrun [6848,6861]
name: create_dagrun [6848,6861]
===
match
---
name: dag_bag [27668,27675]
name: dag_bag [28054,28061]
===
match
---
fstring_string: task_a_ [29000,29007]
fstring_string: task_a_ [29386,29393]
===
match
---
atom_expr [10023,10117]
atom_expr [10023,10117]
===
match
---
string: "invalid_state" [3980,3995]
string: "invalid_state" [3980,3995]
===
match
---
arith_expr [28460,28463]
arith_expr [28846,28849]
===
match
---
name: root_dag [31047,31055]
name: root_dag [31433,31441]
===
match
---
operator: , [22272,22273]
operator: , [22272,22273]
===
match
---
name: DEFAULT_DATE [16517,16529]
name: DEFAULT_DATE [16517,16529]
===
match
---
operator: = [34146,34147]
operator: = [34532,34533]
===
match
---
trailer [23874,23879]
trailer [24260,24265]
===
match
---
argument [31261,31296]
argument [31647,31682]
===
match
---
operator: { [29109,29110]
operator: { [29495,29496]
===
match
---
name: args [7612,7616]
name: args [7612,7616]
===
match
---
operator: , [9351,9352]
operator: , [9351,9352]
===
match
---
trailer [12853,12862]
trailer [12853,12862]
===
match
---
argument [10500,10529]
argument [10500,10529]
===
match
---
funcdef [14981,15657]
funcdef [14981,15657]
===
match
---
operator: @ [32448,32449]
operator: @ [32834,32835]
===
match
---
name: dag_bag_ext [26074,26085]
name: dag_bag_ext [26460,26471]
===
match
---
operator: = [9809,9810]
operator: = [9809,9810]
===
match
---
name: task_b [29376,29382]
name: task_b [29762,29768]
===
match
---
arglist [24982,25019]
arglist [25368,25405]
===
match
---
name: start_date [12499,12509]
name: start_date [12499,12509]
===
match
---
simple_stmt [3163,3240]
simple_stmt [3163,3240]
===
match
---
operator: = [10058,10059]
operator: = [10058,10059]
===
match
---
operator: , [6016,6017]
operator: , [6016,6017]
===
match
---
trailer [16855,16915]
trailer [16855,16915]
===
match
---
name: date_1 [25888,25894]
name: date_1 [26274,26280]
===
match
---
operator: , [20045,20046]
operator: , [20045,20046]
===
match
---
atom_expr [11152,11160]
atom_expr [11152,11160]
===
match
---
trailer [24981,25020]
trailer [25367,25406]
===
match
---
trailer [19877,19995]
trailer [19877,19995]
===
match
---
name: ExternalTaskMarker [31229,31247]
name: ExternalTaskMarker [31615,31633]
===
match
---
argument [21647,21678]
argument [21647,21678]
===
match
---
name: run_id [6875,6881]
name: run_id [6875,6881]
===
match
---
operator: = [9844,9845]
operator: = [9844,9845]
===
match
---
parameters [11912,11918]
parameters [11912,11918]
===
match
---
name: task_instances [16941,16955]
name: task_instances [16941,16955]
===
match
---
atom_expr [1648,1668]
atom_expr [1648,1668]
===
match
---
name: task_0 [21226,21232]
name: task_0 [21226,21232]
===
match
---
suite [34413,34549]
suite [34799,34935]
===
match
---
atom [3603,3618]
atom [3603,3618]
===
match
---
operator: = [25824,25825]
operator: = [26210,26211]
===
match
---
argument [5918,5943]
argument [5918,5943]
===
match
---
name: recursion_depth [26829,26844]
name: recursion_depth [27215,27230]
===
match
---
trailer [6438,6445]
trailer [6438,6445]
===
match
---
operator: = [13639,13640]
operator: = [13639,13640]
===
match
---
name: end_date [23368,23376]
name: end_date [23754,23762]
===
match
---
operator: = [7198,7199]
operator: = [7198,7199]
===
match
---
operator: = [35077,35078]
operator: = [35463,35464]
===
match
---
atom_expr [16420,16428]
atom_expr [16420,16428]
===
match
---
operator: , [901,902]
operator: , [901,902]
===
match
---
name: session [23005,23012]
name: session [23391,23398]
===
match
---
simple_stmt [23735,23760]
simple_stmt [24121,24146]
===
match
---
string: """ {% set s=execution_date.time().second %} echo "second is {{ s }}" if [[ $(( {{ s }} % 60 )) == 1 ]]     then         exit 1 fi exit 0 """ [7356,7497]
string: """ {% set s=execution_date.time().second %} echo "second is {{ s }}" if [[ $(( {{ s }} % 60 )) == 1 ]]     then         exit 1 fi exit 0 """ [7356,7497]
===
match
---
atom_expr [25460,25476]
atom_expr [25846,25862]
===
match
---
name: run [6121,6124]
name: run [6121,6124]
===
match
---
name: datetime [1648,1656]
name: datetime [1648,1656]
===
match
---
operator: = [25306,25307]
operator: = [25692,25693]
===
match
---
operator: = [23656,23657]
operator: = [24042,24043]
===
match
---
name: dag_id [9079,9085]
name: dag_id [9079,9085]
===
match
---
number: 1 [1666,1667]
number: 1 [1666,1667]
===
match
---
name: utils [1442,1447]
name: utils [1442,1447]
===
match
---
fstring_string: dag_ [28175,28179]
fstring_string: dag_ [28561,28565]
===
match
---
funcdef [33884,35156]
funcdef [34270,35542]
===
match
---
parameters [23501,23514]
parameters [23887,23900]
===
match
---
operator: = [16120,16121]
operator: = [16120,16121]
===
match
---
operator: = [4355,4356]
operator: = [4355,4356]
===
match
---
atom_expr [31990,32015]
atom_expr [32376,32401]
===
match
---
name: external_task_id [7114,7130]
name: external_task_id [7114,7130]
===
match
---
name: dag_bag [24700,24707]
name: dag_bag [25086,25093]
===
match
---
argument [6173,6193]
argument [6173,6193]
===
match
---
argument [13185,13210]
argument [13185,13210]
===
match
---
string: "failed" [5895,5903]
string: "failed" [5895,5903]
===
match
---
operator: = [24503,24504]
operator: = [24889,24890]
===
match
---
arglist [9214,9576]
arglist [9214,9576]
===
match
---
argument [10073,10094]
argument [10073,10094]
===
match
---
name: dag [34403,34406]
name: dag [34789,34792]
===
match
---
name: default_args [7594,7606]
name: default_args [7594,7606]
===
match
---
name: dag_bag [25038,25045]
name: dag_bag [25424,25431]
===
match
---
argument [21575,21591]
argument [21575,21591]
===
match
---
string: "body" [33553,33559]
string: "body" [33939,33945]
===
match
---
param [33932,33950]
param [34318,34336]
===
match
---
parameters [29548,29564]
parameters [29934,29950]
===
match
---
arglist [28173,28232]
arglist [28559,28618]
===
match
---
operator: , [30468,30469]
operator: , [30854,30855]
===
match
---
argument [2325,2346]
argument [2325,2346]
===
match
---
assert_stmt [34956,35155]
assert_stmt [35342,35541]
===
match
---
comparison [8913,8966]
comparison [8913,8966]
===
match
---
atom_expr [22488,22534]
atom_expr [22874,22920]
===
match
---
name: DAG [1069,1072]
name: DAG [1069,1072]
===
match
---
operator: = [21663,21664]
operator: = [21663,21664]
===
match
---
arglist [32097,32144]
arglist [32483,32530]
===
match
---
operator: , [24714,24715]
operator: , [25100,25101]
===
match
---
import_from [1303,1378]
import_from [1303,1378]
===
match
---
arglist [10048,10116]
arglist [10048,10116]
===
match
---
with_stmt [15354,15657]
with_stmt [15354,15657]
===
match
---
trailer [9633,10013]
trailer [9633,10013]
===
match
---
trailer [26193,26205]
trailer [26579,26591]
===
match
---
operator: = [21889,21890]
operator: = [21889,21890]
===
match
---
trailer [4557,4559]
trailer [4557,4559]
===
match
---
argument [12296,12323]
argument [12296,12323]
===
match
---
name: execution_date [25810,25824]
name: execution_date [26196,26210]
===
match
---
argument [13101,13128]
argument [13101,13128]
===
match
---
name: dag [31118,31121]
name: dag [31504,31507]
===
match
---
comparison [12115,12146]
comparison [12115,12146]
===
match
---
argument [11686,11698]
argument [11686,11698]
===
match
---
name: dag [19432,19435]
name: dag [19432,19435]
===
match
---
name: getattr [17982,17989]
name: getattr [17982,17989]
===
match
---
name: dt [9390,9392]
name: dt [9390,9392]
===
match
---
operator: = [19184,19185]
operator: = [19184,19185]
===
match
---
assert_stmt [17975,18043]
assert_stmt [17975,18043]
===
match
---
operator: , [34062,34063]
operator: , [34448,34449]
===
match
---
arith_expr [11077,11094]
arith_expr [11077,11094]
===
match
---
argument [19980,19989]
argument [19980,19989]
===
match
---
atom_expr [26703,26731]
atom_expr [27089,27117]
===
match
---
operator: , [3996,3997]
operator: , [3996,3997]
===
match
---
atom [6479,6677]
atom [6479,6677]
===
match
---
simple_stmt [3354,3664]
simple_stmt [3354,3664]
===
match
---
trailer [10145,10167]
trailer [10145,10167]
===
match
---
string: "dag_1" [30417,30424]
string: "dag_1" [30803,30810]
===
match
---
simple_stmt [1669,1699]
simple_stmt [1669,1699]
===
match
---
argument [33155,33174]
argument [33541,33560]
===
match
---
argument [13352,13372]
argument [13352,13372]
===
match
---
argument [5879,5904]
argument [5879,5904]
===
match
---
argument [31472,31483]
argument [31858,31869]
===
match
---
name: timedelta [11082,11091]
name: timedelta [11082,11091]
===
match
---
operator: = [10727,10728]
operator: = [10727,10728]
===
match
---
name: allowed_states [15267,15281]
name: allowed_states [15267,15281]
===
match
---
trailer [22623,22629]
trailer [23009,23015]
===
match
---
operator: = [25907,25908]
operator: = [26293,26294]
===
match
---
name: external_task_id [19397,19413]
name: external_task_id [19397,19413]
===
match
---
name: tis [22157,22160]
name: tis [22157,22160]
===
match
---
atom_expr [2275,2283]
atom_expr [2275,2283]
===
match
---
name: args [9105,9109]
name: args [9105,9109]
===
match
---
string: 'test_external_task_sensor_check_2' [15442,15477]
string: 'test_external_task_sensor_check_2' [15442,15477]
===
match
---
operator: , [11814,11815]
operator: , [11814,11815]
===
match
---
trailer [34374,34382]
trailer [34760,34768]
===
match
---
decorator [1814,1844]
decorator [1814,1844]
===
match
---
simple_stmt [22157,22166]
simple_stmt [22157,22166]
===
match
---
name: dag [12459,12462]
name: dag [12459,12462]
===
match
---
trailer [13464,13466]
trailer [13464,13466]
===
match
---
name: external_task_id [10500,10516]
name: external_task_id [10500,10516]
===
match
---
simple_stmt [8179,8197]
simple_stmt [8179,8197]
===
match
---
string: "%Y%m%d" [12863,12871]
string: "%Y%m%d" [12863,12871]
===
match
---
suite [5544,6678]
suite [5544,6678]
===
match
---
operator: = [9319,9320]
operator: = [9319,9320]
===
match
---
trailer [29805,29814]
trailer [30191,30200]
===
match
---
name: task_a [28291,28297]
name: task_a [28677,28683]
===
match
---
operator: , [25297,25298]
operator: , [25683,25684]
===
match
---
operator: = [19005,19006]
operator: = [19005,19006]
===
match
---
name: run [10199,10202]
name: run [10199,10202]
===
match
---
expr_stmt [34512,34548]
expr_stmt [34898,34934]
===
match
---
atom_expr [13805,13817]
atom_expr [13805,13817]
===
match
---
argument [9920,9929]
argument [9920,9929]
===
match
---
fstring_end: " [28674,28675]
fstring_end: " [29060,29061]
===
match
---
argument [11573,11579]
argument [11573,11579]
===
match
---
simple_stmt [17819,17876]
simple_stmt [17819,17876]
===
match
---
name: dt [12977,12979]
name: dt [12977,12979]
===
match
---
name: dag_bag_ext [25797,25808]
name: dag_bag_ext [26183,26194]
===
match
---
trailer [33382,33389]
trailer [33768,33775]
===
match
---
suite [12818,12995]
suite [12818,12995]
===
match
---
name: test_external_task_marker_clear_activate [23904,23944]
name: test_external_task_marker_clear_activate [24290,24330]
===
match
---
operator: == [32440,32442]
operator: == [32826,32828]
===
match
---
name: TEST_DAG_ID [15191,15202]
name: TEST_DAG_ID [15191,15202]
===
match
---
expr_stmt [15738,15990]
expr_stmt [15738,15990]
===
match
---
expr_stmt [7558,7657]
expr_stmt [7558,7657]
===
match
---
expr_stmt [29147,29353]
expr_stmt [29533,29739]
===
match
---
argument [3390,3431]
argument [3390,3431]
===
match
---
testlist_comp [5828,5864]
testlist_comp [5828,5864]
===
match
---
name: dag_bag_ext [23502,23513]
name: dag_bag_ext [23888,23899]
===
match
---
trailer [31159,31189]
trailer [31545,31575]
===
match
---
operator: , [32412,32413]
operator: , [32798,32799]
===
match
---
expr_stmt [27668,27729]
expr_stmt [28054,28115]
===
match
---
trailer [11736,11769]
trailer [11736,11769]
===
match
---
funcdef [2375,2737]
funcdef [2375,2737]
===
match
---
name: external_dag_id [33636,33651]
name: external_dag_id [34022,34037]
===
match
---
suite [31668,32446]
suite [32054,32832]
===
match
---
dotted_name [1434,1453]
dotted_name [1434,1453]
===
match
---
trailer [22651,22657]
trailer [23037,23043]
===
match
---
simple_stmt [28291,28485]
simple_stmt [28677,28871]
===
match
---
name: dag_bag_multiple [32422,32438]
name: dag_bag_multiple [32808,32824]
===
match
---
arith_expr [25736,25768]
arith_expr [26122,26154]
===
match
---
argument [19169,19186]
argument [19169,19186]
===
match
---
operator: , [33349,33350]
operator: , [33735,33736]
===
match
---
argument [25103,25118]
argument [25489,25504]
===
match
---
argument [10901,10950]
argument [10901,10950]
===
match
---
name: clear_db_runs [18834,18847]
name: clear_db_runs [18834,18847]
===
match
---
operator: , [7935,7936]
operator: , [7935,7936]
===
match
---
simple_stmt [27931,28084]
simple_stmt [28317,28470]
===
match
---
trailer [24629,24645]
trailer [25015,25031]
===
match
---
operator: = [15948,15949]
operator: = [15948,15949]
===
match
---
trailer [34370,34374]
trailer [34756,34760]
===
match
---
expr_stmt [23573,23601]
expr_stmt [23959,23987]
===
match
---
trailer [33993,34001]
trailer [34379,34387]
===
match
---
simple_stmt [7666,7829]
simple_stmt [7666,7829]
===
match
---
name: ti [22488,22490]
name: ti [22874,22876]
===
match
---
trailer [13272,13276]
trailer [13272,13276]
===
match
---
argument [15220,15249]
argument [15220,15249]
===
match
---
name: test_external_task_sensor_fn_kwargs [12578,12613]
name: test_external_task_sensor_fn_kwargs [12578,12613]
===
match
---
operator: , [1231,1232]
operator: , [1231,1232]
===
match
---
param [2180,2185]
param [2180,2185]
===
match
---
name: dag_folder [33155,33165]
name: dag_folder [33541,33551]
===
match
---
atom_expr [23869,23879]
atom_expr [24255,24265]
===
match
---
param [13428,13432]
param [13428,13432]
===
match
---
string: "dag_3" [20038,20045]
string: "dag_3" [20038,20045]
===
match
---
atom_expr [17000,17029]
atom_expr [17000,17029]
===
match
---
name: dag [7149,7152]
name: dag [7149,7152]
===
match
---
operator: = [6881,6882]
operator: = [6881,6882]
===
match
---
import_from [1121,1170]
import_from [1121,1170]
===
match
---
argument [4783,4808]
argument [4783,4808]
===
match
---
operator: , [19430,19431]
operator: , [19430,19431]
===
match
---
trailer [29738,29747]
trailer [30124,30133]
===
match
---
simple_stmt [25365,25405]
simple_stmt [25751,25791]
===
match
---
simple_stmt [17458,17653]
simple_stmt [17458,17653]
===
match
---
operator: , [30437,30438]
operator: , [30823,30824]
===
match
---
operator: = [4454,4455]
operator: = [4454,4455]
===
match
---
atom_expr [27763,27824]
atom_expr [28149,28210]
===
match
---
atom_expr [19319,19447]
atom_expr [19319,19447]
===
match
---
argument [24742,24756]
argument [25128,25142]
===
match
---
expr_stmt [4138,4375]
expr_stmt [4138,4375]
===
match
---
atom_expr [23216,23293]
atom_expr [23602,23679]
===
match
---
name: DEV_NULL [21076,21084]
name: DEV_NULL [21076,21084]
===
match
---
name: State [25480,25485]
name: State [25866,25871]
===
match
---
name: op [4875,4877]
name: op [4875,4877]
===
match
---
trailer [34976,34982]
trailer [35362,35368]
===
match
---
operator: @ [23883,23884]
operator: @ [24269,24270]
===
match
---
atom [5079,5272]
atom [5079,5272]
===
match
---
suite [29903,29950]
suite [30289,30336]
===
match
---
argument [8329,8338]
argument [8329,8338]
===
match
---
atom_expr [3163,3239]
atom_expr [3163,3239]
===
match
---
trailer [18871,18916]
trailer [18871,18916]
===
match
---
operator: = [24177,24178]
operator: = [24563,24564]
===
match
---
operator: , [30393,30394]
operator: , [30779,30780]
===
match
---
argument [4744,4769]
argument [4744,4769]
===
match
---
name: run_tasks [26668,26677]
name: run_tasks [27054,27063]
===
match
---
operator: = [32071,32072]
operator: = [32457,32458]
===
match
---
operator: = [17676,17677]
operator: = [17676,17677]
===
match
---
name: dag [31177,31180]
name: dag [31563,31566]
===
match
---
simple_stmt [3778,4042]
simple_stmt [3778,4042]
===
match
---
operator: = [19778,19779]
operator: = [19778,19779]
===
match
---
atom_expr [10787,10810]
atom_expr [10787,10810]
===
match
---
name: sensors [1184,1191]
name: sensors [1184,1191]
===
match
---
expr_stmt [17662,17725]
expr_stmt [17662,17725]
===
match
---
trailer [17052,17057]
trailer [17052,17057]
===
match
---
string: 'head' [33343,33349]
string: 'head' [33729,33735]
===
match
---
simple_stmt [14694,14976]
simple_stmt [14694,14976]
===
match
---
operator: , [30929,30930]
operator: , [31315,31316]
===
match
---
operator: , [11211,11212]
operator: , [11211,11212]
===
match
---
operator: = [17750,17751]
operator: = [17750,17751]
===
match
---
funcdef [25496,26408]
funcdef [25882,26794]
===
match
---
name: all [8853,8856]
name: all [8853,8856]
===
match
---
name: run [8014,8017]
name: run [8014,8017]
===
match
---
simple_stmt [34139,34355]
simple_stmt [34525,34741]
===
match
---
suite [7327,10273]
suite [7327,10273]
===
match
---
operator: = [34092,34093]
operator: = [34478,34479]
===
match
---
name: DagBag [33148,33154]
name: DagBag [33534,33540]
===
match
---
operator: , [4808,4809]
operator: , [4808,4809]
===
match
---
operator: = [10697,10698]
operator: = [10697,10698]
===
match
---
string: "dag_0" [26723,26730]
string: "dag_0" [27109,27116]
===
match
---
name: dag_id [33383,33389]
name: dag_id [33769,33775]
===
match
---
operator: = [6929,6930]
operator: = [6929,6930]
===
match
---
trailer [14661,14668]
trailer [14661,14668]
===
match
---
atom_expr [19414,19430]
atom_expr [19414,19430]
===
match
---
operator: , [959,960]
operator: , [959,960]
===
match
---
name: dag [12468,12471]
name: dag [12468,12471]
===
match
---
name: schedule_interval [19280,19297]
name: schedule_interval [19280,19297]
===
match
---
name: dag_id [9040,9046]
name: dag_id [9040,9046]
===
match
---
name: session [22587,22594]
name: session [22973,22980]
===
match
---
trailer [4127,4129]
trailer [4127,4129]
===
match
---
simple_stmt [29789,29827]
simple_stmt [30175,30213]
===
match
---
name: task [31222,31226]
name: task [31608,31612]
===
match
---
argument [10096,10116]
argument [10096,10116]
===
match
---
with_stmt [28822,29383]
with_stmt [29208,29769]
===
match
---
operator: , [19039,19040]
operator: , [19039,19040]
===
match
---
string: """     Test clearing tasks across DAGs.     """ [23520,23568]
string: """     Test clearing tasks across DAGs.     """ [23906,23954]
===
match
---
operator: = [17637,17638]
operator: = [17637,17638]
===
match
---
name: dag_folder [1981,1991]
name: dag_folder [1981,1991]
===
match
---
trailer [24565,24580]
trailer [24951,24966]
===
match
---
name: unittest [809,817]
name: unittest [809,817]
===
match
---
trailer [34566,34568]
trailer [34952,34954]
===
match
---
param [22995,23000]
param [23381,23386]
===
match
---
name: session [35109,35116]
name: session [35495,35502]
===
match
---
sync_comp_for [30572,30585]
sync_comp_for [30958,30971]
===
match
---
operator: , [14323,14324]
operator: , [14323,14324]
===
match
---
simple_stmt [34363,34383]
simple_stmt [34749,34769]
===
match
---
argument [20072,20094]
argument [20072,20094]
===
match
---
name: get_task [30248,30256]
name: get_task [30634,30642]
===
match
---
except_clause [8535,8556]
except_clause [8535,8556]
===
match
---
operator: = [5711,5712]
operator: = [5711,5712]
===
match
---
atom_expr [5672,5980]
atom_expr [5672,5980]
===
match
---
trailer [17008,17013]
trailer [17008,17013]
===
match
---
operator: , [30822,30823]
operator: , [31208,31209]
===
match
---
param [12798,12816]
param [12798,12816]
===
match
---
name: DAG [23210,23213]
name: DAG [23596,23599]
===
match
---
arith_expr [9395,9420]
arith_expr [9395,9420]
===
match
---
operator: = [9654,9655]
operator: = [9654,9655]
===
match
---
argument [17497,17518]
argument [17497,17518]
===
match
---
simple_stmt [26695,26732]
simple_stmt [27081,27118]
===
match
---
name: agg_dag [32000,32007]
name: agg_dag [32386,32393]
===
match
---
atom_expr [6408,6432]
atom_expr [6408,6432]
===
match
---
name: root_dag [21881,21889]
name: root_dag [21881,21889]
===
match
---
name: State [25392,25397]
name: State [25778,25783]
===
match
---
name: DAG [33210,33213]
name: DAG [33596,33599]
===
match
---
trailer [22189,22194]
trailer [22189,22194]
===
match
---
name: dag [4822,4825]
name: dag [4822,4825]
===
match
---
operator: = [18909,18910]
operator: = [18909,18910]
===
match
---
dotted_name [987,1001]
dotted_name [987,1001]
===
match
---
name: ExternalTaskSensor [4573,4591]
name: ExternalTaskSensor [4573,4591]
===
match
---
argument [25277,25297]
argument [25663,25683]
===
match
---
argument [19907,19930]
argument [19907,19930]
===
match
---
name: external_dag_id [9258,9273]
name: external_dag_id [9258,9273]
===
match
---
trailer [3796,4041]
trailer [3796,4041]
===
match
---
name: external_task_id [11005,11021]
name: external_task_id [11005,11021]
===
match
---
operator: = [28997,28998]
operator: = [29383,29384]
===
match
---
name: execution_date [22340,22354]
name: execution_date [22340,22354]
===
match
---
operator: , [23068,23069]
operator: , [23454,23455]
===
match
---
argument [11634,11643]
argument [11634,11643]
===
match
---
name: start_date [6125,6135]
name: start_date [6125,6135]
===
match
---
string: """     Clear the task and its downstream tasks recursively for the dag in the given dagbag.     """ [23096,23196]
string: """     Clear the task and its downstream tasks recursively for the dag in the given dagbag.     """ [23482,23582]
===
match
---
operator: = [17435,17436]
operator: = [17435,17436]
===
match
---
atom_expr [25235,25315]
atom_expr [25621,25701]
===
match
---
operator: = [7951,7952]
operator: = [7951,7952]
===
match
---
name: TEST_DAG_ID [3036,3047]
name: TEST_DAG_ID [3036,3047]
===
match
---
name: task_id [10398,10405]
name: task_id [10398,10405]
===
match
---
atom_expr [27885,27918]
atom_expr [28271,28304]
===
match
---
trailer [28262,28269]
trailer [28648,28655]
===
match
---
number: 1 [29116,29117]
number: 1 [29502,29503]
===
match
---
arglist [11382,11699]
arglist [11382,11699]
===
match
---
operator: = [24088,24089]
operator: = [24474,24475]
===
match
---
simple_stmt [982,1038]
simple_stmt [982,1038]
===
match
---
name: TEST_TASK_ID [13759,13771]
name: TEST_TASK_ID [13759,13771]
===
match
---
number: 1 [19977,19978]
number: 1 [19977,19978]
===
match
---
trailer [21863,21871]
trailer [21863,21871]
===
match
---
operator: = [9523,9524]
operator: = [9523,9524]
===
match
---
name: timeout [11634,11641]
name: timeout [11634,11641]
===
match
---
dotted_name [1126,1149]
dotted_name [1126,1149]
===
match
---
operator: , [26288,26289]
operator: , [26674,26675]
===
match
---
name: DEFAULT_DATE [17436,17448]
name: DEFAULT_DATE [17436,17448]
===
match
---
param [23502,23513]
param [23888,23899]
===
match
---
name: dag_bag_parent_child [23945,23965]
name: dag_bag_parent_child [24331,24351]
===
match
---
argument [21483,21499]
argument [21483,21499]
===
match
---
expr_stmt [26210,26248]
expr_stmt [26596,26634]
===
match
---
name: daily_task [31272,31282]
name: daily_task [31658,31668]
===
match
---
expr_stmt [16207,16439]
expr_stmt [16207,16439]
===
match
---
trailer [3322,3340]
trailer [3322,3340]
===
match
---
name: external_task_id [4271,4287]
name: external_task_id [4271,4287]
===
match
---
atom_expr [34109,34130]
atom_expr [34495,34516]
===
match
---
atom [34963,35155]
atom [35349,35541]
===
match
---
operator: = [3934,3935]
operator: = [3934,3935]
===
match
---
operator: = [28712,28713]
operator: = [29098,29099]
===
match
---
name: external_dag_id [19367,19382]
name: external_dag_id [19367,19382]
===
match
---
operator: , [16929,16930]
operator: , [16929,16930]
===
match
---
trailer [29720,29724]
trailer [30106,30110]
===
match
---
argument [13042,13087]
argument [13042,13087]
===
match
---
trailer [19020,19051]
trailer [19020,19051]
===
match
---
name: task_id [28990,28997]
name: task_id [29376,29383]
===
match
---
argument [33335,33349]
argument [33721,33735]
===
match
---
argument [19280,19302]
argument [19280,19302]
===
match
---
arith_expr [32042,32078]
arith_expr [32428,32464]
===
match
---
name: dry_run [30318,30325]
name: dry_run [30704,30711]
===
match
---
name: dag_0 [24606,24611]
name: dag_0 [24992,24997]
===
match
---
trailer [3372,3663]
trailer [3372,3663]
===
match
---
name: dag [19828,19831]
name: dag [19828,19831]
===
match
---
operator: = [30147,30148]
operator: = [30533,30534]
===
match
---
number: 2 [9436,9437]
number: 2 [9436,9437]
===
match
---
argument [11486,11515]
argument [11486,11515]
===
match
---
name: pytest [6062,6068]
name: pytest [6062,6068]
===
match
---
simple_stmt [802,818]
simple_stmt [802,818]
===
match
---
operator: , [12471,12472]
operator: , [12471,12472]
===
match
---
name: self [3719,3723]
name: self [3719,3723]
===
match
---
suite [23515,23881]
suite [23901,24267]
===
match
---
atom_expr [4384,4460]
atom_expr [4384,4460]
===
match
---
atom_expr [12037,12060]
atom_expr [12037,12060]
===
match
---
name: start_date [23328,23338]
name: start_date [23714,23724]
===
match
---
name: dag_bag [23394,23401]
name: dag_bag [23780,23787]
===
match
---
argument [15114,15157]
argument [15114,15157]
===
match
---
name: target_time [2250,2261]
name: target_time [2250,2261]
===
match
---
expr_stmt [22547,22567]
expr_stmt [22933,22953]
===
match
---
string: 'time_sensor_check' [1714,1733]
string: 'time_sensor_check' [1714,1733]
===
match
---
suite [22020,22731]
suite [22020,23117]
===
match
---
name: dag_bag_multiple [30609,30625]
name: dag_bag_multiple [30995,31011]
===
match
---
name: execution_date_fn [11529,11546]
name: execution_date_fn [11529,11546]
===
match
---
name: DagBag [27652,27658]
name: DagBag [28038,28044]
===
match
---
name: INFO [4897,4901]
name: INFO [4897,4901]
===
match
---
simple_stmt [27020,27619]
simple_stmt [27406,28005]
===
match
---
trailer [21253,21453]
trailer [21253,21453]
===
match
---
atom_expr [33806,33844]
atom_expr [34192,34230]
===
match
---
name: dag [20289,20292]
name: dag [20289,20292]
===
match
---
dotted_name [30590,30604]
dotted_name [30976,30990]
===
match
---
name: tis [22547,22550]
name: tis [22933,22936]
===
match
---
atom [2045,2093]
atom [2045,2093]
===
match
---
string: "task_external_without_failure" [7904,7935]
string: "task_external_without_failure" [7904,7935]
===
match
---
name: test_utils [1597,1607]
name: test_utils [1597,1607]
===
match
---
operator: , [20347,20348]
operator: , [20347,20348]
===
match
---
name: State [26396,26401]
name: State [26782,26787]
===
match
---
operator: , [14370,14371]
operator: , [14370,14371]
===
match
---
operator: , [10002,10003]
operator: , [10002,10003]
===
match
---
name: TEST_DAG_ID [9049,9060]
name: TEST_DAG_ID [9049,9060]
===
match
---
name: external_task_id [31356,31372]
name: external_task_id [31742,31758]
===
match
---
name: run_tasks [23579,23588]
name: run_tasks [23965,23974]
===
match
---
name: TEST_DAG_ID [13713,13724]
name: TEST_DAG_ID [13713,13724]
===
match
---
name: task [17458,17462]
name: task [17458,17462]
===
match
---
name: dt [9822,9824]
name: dt [9822,9824]
===
match
---
trailer [27766,27824]
trailer [28152,28210]
===
match
---
simple_stmt [23201,23294]
simple_stmt [23587,23680]
===
match
---
operator: = [21274,21275]
operator: = [21274,21275]
===
match
---
param [2405,2409]
param [2405,2409]
===
match
---
name: ValueError [15373,15383]
name: ValueError [15373,15383]
===
match
---
simple_stmt [25727,25769]
simple_stmt [26113,26155]
===
match
---
trailer [25276,25315]
trailer [25662,25701]
===
match
---
number: 0 [12181,12182]
number: 0 [12181,12182]
===
match
---
operator: = [13202,13203]
operator: = [13202,13203]
===
match
---
parameters [25532,25545]
parameters [25918,25931]
===
match
---
argument [13742,13771]
argument [13742,13771]
===
match
---
testlist_comp [30510,30529]
testlist_comp [30896,30915]
===
match
---
name: task_id [19743,19750]
name: task_id [19743,19750]
===
match
---
argument [10048,10071]
argument [10048,10071]
===
match
---
name: dag [15976,15979]
name: dag [15976,15979]
===
match
---
name: dag_bag [29760,29767]
name: dag_bag [30146,30153]
===
match
---
name: DummyOperator [31083,31096]
name: DummyOperator [31469,31482]
===
match
---
number: 2 [9863,9864]
number: 2 [9863,9864]
===
match
---
operator: = [33733,33734]
operator: = [34119,34120]
===
match
---
string: 'INFO:airflow.task.operators:Poking for tasks ' [6232,6279]
string: 'INFO:airflow.task.operators:Poking for tasks ' [6232,6279]
===
match
---
number: 1 [25766,25767]
number: 1 [26152,26153]
===
match
---
arglist [4990,5058]
arglist [4990,5058]
===
match
---
operator: = [23742,23743]
operator: = [24128,24129]
===
match
---
name: time [2262,2266]
name: time [2262,2266]
===
match
---
number: 1 [9147,9148]
number: 1 [9147,9148]
===
match
---
trailer [16018,16036]
trailer [16018,16036]
===
match
---
name: dag_maker [16639,16648]
name: dag_maker [16639,16648]
===
match
---
atom_expr [24566,24579]
atom_expr [24952,24965]
===
match
---
name: timedelta [12982,12991]
name: timedelta [12982,12991]
===
match
---
simple_stmt [30171,30190]
simple_stmt [30557,30576]
===
match
---
name: state [34199,34204]
name: state [34585,34590]
===
match
---
operator: = [19382,19383]
operator: = [19382,19383]
===
match
---
comparison [8888,8908]
comparison [8888,8908]
===
match
---
operator: , [23012,23013]
operator: , [23398,23399]
===
match
---
atom_expr [21621,21633]
atom_expr [21621,21633]
===
match
---
trailer [33821,33844]
trailer [34207,34230]
===
match
---
argument [14438,14464]
argument [14438,14464]
===
match
---
arglist [18872,18915]
arglist [18872,18915]
===
match
---
operator: = [12433,12434]
operator: = [12433,12434]
===
match
---
operator: , [14420,14421]
operator: , [14420,14421]
===
match
---
file_input [787,35156]
file_input [787,35542]
===
match
---
atom_expr [12738,12761]
atom_expr [12738,12761]
===
match
---
name: agg_dag [31476,31483]
name: agg_dag [31862,31869]
===
match
---
name: execution_date [22301,22315]
name: execution_date [22301,22315]
===
match
---
string: 'in dag unit_test_dag on %s ... ' [6372,6405]
string: 'in dag unit_test_dag on %s ... ' [6372,6405]
===
match
---
string: 'test_external_task_sensor_check_delta' [13640,13679]
string: 'test_external_task_sensor_check_delta' [13640,13679]
===
match
---
operator: , [19509,19510]
operator: , [19509,19510]
===
match
---
name: task_id [27978,27985]
name: task_id [28364,28371]
===
match
---
name: task [17009,17013]
name: task [17009,17013]
===
match
---
operator: = [10474,10475]
operator: = [10474,10475]
===
match
---
argument [19887,19905]
argument [19887,19905]
===
match
---
name: partial [23305,23312]
name: partial [23691,23698]
===
match
---
operator: , [8293,8294]
operator: , [8293,8294]
===
match
---
atom_expr [19715,19843]
atom_expr [19715,19843]
===
match
---
trailer [22695,22714]
trailer [23081,23100]
===
match
---
name: dag_bag [29476,29483]
name: dag_bag [29862,29869]
===
match
---
operator: >> [28757,28759]
operator: >> [29143,29145]
===
match
---
operator: + [24161,24162]
operator: + [24547,24548]
===
match
---
atom_expr [21394,21411]
atom_expr [21394,21411]
===
match
---
arith_expr [28406,28409]
arith_expr [28792,28795]
===
match
---
fstring [28609,28621]
fstring [28995,29007]
===
match
---
arglist [1981,2023]
arglist [1981,2023]
===
match
---
suite [2208,2370]
suite [2208,2370]
===
match
---
atom_expr [30739,30790]
atom_expr [31125,31176]
===
match
---
name: render_templates [16969,16985]
name: render_templates [16969,16985]
===
match
---
operator: , [23267,23268]
operator: , [23653,23654]
===
match
---
trailer [21932,21934]
trailer [21932,21934]
===
match
---
name: state [22253,22258]
name: state [22253,22258]
===
match
---
atom_expr [12463,12471]
atom_expr [12463,12471]
===
match
---
name: task_a_1 [19308,19316]
name: task_a_1 [19308,19316]
===
match
---
atom_expr [11723,11769]
atom_expr [11723,11769]
===
match
---
operator: = [33269,33270]
operator: = [33655,33656]
===
match
---
argument [3589,3618]
argument [3589,3618]
===
match
---
simple_stmt [33296,33516]
simple_stmt [33682,33902]
===
match
---
operator: } [28673,28674]
operator: } [29059,29060]
===
match
---
operator: = [21393,21394]
operator: = [21393,21394]
===
match
---
operator: = [19693,19694]
operator: = [19693,19694]
===
match
---
name: schedule_interval [6803,6820]
name: schedule_interval [6803,6820]
===
match
---
name: delta [31981,31986]
name: delta [32367,32372]
===
match
---
param [17219,17223]
param [17219,17223]
===
match
---
string: "['time_sensor_check'] in DAG " [5374,5405]
string: "['time_sensor_check'] in DAG " [5374,5405]
===
match
---
expr_stmt [23201,23293]
expr_stmt [23587,23679]
===
match
---
shift_expr [20304,20324]
shift_expr [20304,20324]
===
match
---
operator: = [29798,29799]
operator: = [30184,30185]
===
match
---
name: ExternalTaskSensor [4143,4161]
name: ExternalTaskSensor [4143,4161]
===
match
---
name: cm [6041,6043]
name: cm [6041,6043]
===
match
---
funcdef [10739,11861]
funcdef [10739,11861]
===
match
---
name: get_dag [25046,25053]
name: get_dag [25432,25439]
===
match
---
name: bag_dag [29429,29436]
name: bag_dag [29815,29822]
===
match
---
name: self [6712,6716]
name: self [6712,6716]
===
match
---
operator: = [10405,10406]
operator: = [10405,10406]
===
match
---
arglist [29850,29901]
arglist [30236,30287]
===
match
---
name: instance [16960,16968]
name: instance [16960,16968]
===
match
---
trailer [33321,33515]
trailer [33707,33901]
===
match
---
operator: = [14951,14952]
operator: = [14951,14952]
===
match
---
name: append [28921,28927]
name: append [29307,29313]
===
match
---
name: task_id [10901,10908]
name: task_id [10901,10908]
===
match
---
operator: , [19253,19254]
operator: , [19253,19254]
===
match
---
trailer [17081,17086]
trailer [17081,17086]
===
match
---
atom_expr [11690,11698]
atom_expr [11690,11698]
===
match
---
name: mode [33487,33491]
name: mode [33873,33877]
===
match
---
argument [32362,32387]
argument [32748,32773]
===
match
---
trailer [16056,16126]
trailer [16056,16126]
===
match
---
number: 10 [29721,29723]
number: 10 [30107,30109]
===
match
---
operator: % [5219,5220]
operator: % [5219,5220]
===
match
---
name: dag [5966,5969]
name: dag [5966,5969]
===
match
---
trailer [22512,22521]
trailer [22898,22907]
===
match
---
trailer [17989,18026]
trailer [17989,18026]
===
match
---
name: fixture [1822,1829]
name: fixture [1822,1829]
===
match
---
operator: = [12397,12398]
operator: = [12397,12398]
===
match
---
argument [18893,18915]
argument [18893,18915]
===
match
---
shift_expr [29366,29382]
shift_expr [29752,29768]
===
match
---
name: DEFAULT_DATE [1633,1645]
name: DEFAULT_DATE [1633,1645]
===
match
---
operator: = [30200,30201]
operator: = [30586,30587]
===
match
---
test [21733,21773]
test [21733,21773]
===
match
---
fstring_string: task_ [17109,17114]
fstring_string: task_ [17109,17114]
===
match
---
name: session [24585,24592]
name: session [24971,24978]
===
match
---
name: ExternalTaskSensor [6987,7005]
name: ExternalTaskSensor [6987,7005]
===
match
---
operator: , [27774,27775]
operator: , [28160,28161]
===
match
---
simple_stmt [1960,2025]
simple_stmt [1960,2025]
===
match
---
argument [2002,2023]
argument [2002,2023]
===
match
---
atom_expr [6950,6963]
atom_expr [6950,6963]
===
match
---
atom_expr [23744,23759]
atom_expr [24130,24145]
===
match
---
string: """     Create a DagBag with DAGs having cyclic dependencies set up by ExternalTaskMarker and     ExternalTaskSensor.      dag_0:   task_a_0 >> task_b_0                   ^          |                   |          |     dag_1:        |          ---> task_a_1 >> task_b_1                   |                              ^                   |                              |     dag_n:        |                              ---> task_a_n >> task_b_n                   |                                                   |                   -----------------------------------------------------     """ [27020,27618]
string: """     Create a DagBag with DAGs having cyclic dependencies set up by ExternalTaskMarker and     ExternalTaskSensor.      dag_0:   task_a_0 >> task_b_0                   ^          |                   |          |     dag_1:        |          ---> task_a_1 >> task_b_1                   |                              ^                   |                              |     dag_n:        |                              ---> task_a_n >> task_b_n                   |                                                   |                   -----------------------------------------------------     """ [27406,28004]
===
match
---
argument [20224,20233]
argument [20224,20233]
===
match
---
operator: = [25734,25735]
operator: = [26120,26121]
===
match
---
expr_stmt [24650,24683]
expr_stmt [25036,25069]
===
match
---
simple_stmt [28945,29135]
simple_stmt [29331,29521]
===
match
---
name: task_id [22554,22561]
name: task_id [22940,22947]
===
match
---
operator: = [27676,27677]
operator: = [28062,28063]
===
match
---
atom_expr [12914,12957]
atom_expr [12914,12957]
===
match
---
argument [17634,17641]
argument [17634,17641]
===
match
---
atom_expr [6501,6510]
atom_expr [6501,6510]
===
match
---
name: task_id [5704,5711]
name: task_id [5704,5711]
===
match
---
name: check_existence [15933,15948]
name: check_existence [15933,15948]
===
match
---
operator: @ [22935,22936]
operator: @ [23321,23322]
===
match
---
operator: = [28889,28890]
operator: = [29275,29276]
===
match
---
expr_stmt [19308,19447]
expr_stmt [19308,19447]
===
match
---
operator: , [33473,33474]
operator: , [33859,33860]
===
match
---
param [16192,16196]
param [16192,16196]
===
match
---
name: dag_external [7806,7818]
name: dag_external [7806,7818]
===
match
---
operator: , [28571,28572]
operator: , [28957,28958]
===
match
---
operator: = [2455,2456]
operator: = [2455,2456]
===
match
---
operator: = [5000,5001]
operator: = [5000,5001]
===
match
---
operator: = [6023,6024]
operator: = [6023,6024]
===
match
---
atom_expr [31272,31290]
atom_expr [31658,31676]
===
match
---
fstring_end: " [28844,28845]
fstring_end: " [29230,29231]
===
match
---
name: DEFAULT_DATE [23056,23068]
name: DEFAULT_DATE [23442,23454]
===
match
---
with_stmt [26853,26976]
with_stmt [27239,27362]
===
match
---
name: SUCCESS [25486,25493]
name: SUCCESS [25872,25879]
===
match
---
trailer [23860,23880]
trailer [24246,24266]
===
match
---
simple_stmt [30633,30725]
simple_stmt [31019,31111]
===
match
---
trailer [25796,25832]
trailer [26182,26218]
===
match
---
name: n [28670,28671]
name: n [29056,29057]
===
match
---
argument [14730,14777]
argument [14730,14777]
===
match
---
assert_stmt [5072,5272]
assert_stmt [5072,5272]
===
match
---
param [14549,14553]
param [14549,14553]
===
match
---
operator: = [21201,21202]
operator: = [21201,21202]
===
match
---
string: ' in dag unit_test_dag on %s ... ' [5184,5218]
string: ' in dag unit_test_dag on %s ... ' [5184,5218]
===
match
---
argument [19793,19826]
argument [19793,19826]
===
match
---
operator: = [16090,16091]
operator: = [16090,16091]
===
match
---
operator: , [1015,1016]
operator: , [1015,1016]
===
match
---
name: tis [22727,22730]
name: tis [23113,23116]
===
match
---
name: execution_date [24982,24996]
name: execution_date [25368,25382]
===
match
---
trailer [29436,29459]
trailer [29822,29845]
===
match
---
atom_expr [18834,18849]
atom_expr [18834,18849]
===
match
---
name: run [13300,13303]
name: run [13300,13303]
===
match
---
name: start_date [11188,11198]
name: start_date [11188,11198]
===
match
---
argument [2544,2571]
argument [2544,2571]
===
match
---
operator: = [19317,19318]
operator: = [19317,19318]
===
match
---
operator: = [25095,25096]
operator: = [25481,25482]
===
match
---
param [3289,3293]
param [3289,3293]
===
match
---
operator: , [28465,28466]
operator: , [28851,28852]
===
match
---
trailer [30547,30586]
trailer [30933,30972]
===
match
---
name: DAG [33970,33973]
name: DAG [34356,34359]
===
match
---
name: task_id [2827,2834]
name: task_id [2827,2834]
===
match
---
simple_stmt [4106,4130]
simple_stmt [4106,4130]
===
match
---
param [26450,26461]
param [26836,26847]
===
match
---
name: ignore_ti_state [16105,16120]
name: ignore_ti_state [16105,16120]
===
match
---
operator: , [29931,29932]
operator: , [30317,30318]
===
match
---
operator: , [7234,7235]
operator: , [7234,7235]
===
match
---
assert_stmt [30337,30586]
assert_stmt [30723,30972]
===
match
---
name: ignore_ti_state [8341,8356]
name: ignore_ti_state [8341,8356]
===
match
---
suite [1951,2154]
suite [1951,2154]
===
match
---
operator: = [29873,29874]
operator: = [30259,30260]
===
match
---
name: execution_date [21379,21393]
name: execution_date [21379,21393]
===
match
---
trailer [23672,23684]
trailer [24058,24070]
===
match
---
operator: = [3233,3234]
operator: = [3233,3234]
===
match
---
operator: = [2631,2632]
operator: = [2631,2632]
===
match
---
name: dag_bag [24939,24946]
name: dag_bag [25325,25332]
===
match
---
operator: = [23367,23368]
operator: = [23753,23754]
===
match
---
atom_expr [21856,21894]
atom_expr [21856,21894]
===
match
---
simple_stmt [33965,34015]
simple_stmt [34351,34401]
===
match
---
operator: , [21481,21482]
operator: , [21481,21482]
===
match
---
funcdef [1935,2154]
funcdef [1935,2154]
===
match
---
name: dag [14948,14951]
name: dag [14948,14951]
===
match
---
operator: } [29013,29014]
operator: } [29399,29400]
===
match
---
parameters [1856,1858]
parameters [1856,1858]
===
match
---
name: execution_date [25081,25095]
name: execution_date [25467,25481]
===
match
---
name: sensors [1265,1272]
name: sensors [1265,1272]
===
match
---
name: self [1945,1949]
name: self [1945,1949]
===
match
---
name: dag [3636,3639]
name: dag [3636,3639]
===
match
---
name: airflow [1078,1085]
name: airflow [1078,1085]
===
match
---
with_stmt [11718,11861]
with_stmt [11718,11861]
===
match
---
atom_expr [34403,34412]
atom_expr [34789,34798]
===
match
---
fstring_start: f" [28173,28175]
fstring_start: f" [28559,28561]
===
match
---
atom_expr [16454,16485]
atom_expr [16454,16485]
===
match
---
operator: , [10529,10530]
operator: , [10529,10530]
===
match
---
name: task_id [20139,20146]
name: task_id [20139,20146]
===
match
---
operator: , [27799,27800]
operator: , [28185,28186]
===
match
---
name: external_dag_id [19763,19778]
name: external_dag_id [19763,19778]
===
match
---
atom_expr [29836,29902]
atom_expr [30222,30288]
===
match
---
name: external_task_id [15220,15236]
name: external_task_id [15220,15236]
===
match
---
trailer [18847,18849]
trailer [18847,18849]
===
match
---
operator: , [10637,10638]
operator: , [10637,10638]
===
match
---
argument [34877,34900]
argument [35263,35286]
===
match
---
expr_stmt [16920,16955]
expr_stmt [16920,16955]
===
match
---
simple_stmt [12108,12147]
simple_stmt [12108,12147]
===
match
---
name: test_external_task_marker_cyclic_shallow [29956,29996]
name: test_external_task_marker_cyclic_shallow [30342,30382]
===
match
---
for_stmt [22171,22715]
for_stmt [22171,23101]
===
match
---
name: dag_0 [24709,24714]
name: dag_0 [25095,25100]
===
match
---
atom [5827,5865]
atom [5827,5865]
===
match
---
argument [21267,21283]
argument [21267,21283]
===
match
---
operator: , [10445,10446]
operator: , [10445,10446]
===
match
---
trailer [13814,13817]
trailer [13814,13817]
===
match
---
operator: = [16569,16570]
operator: = [16569,16570]
===
match
---
operator: , [17641,17642]
operator: , [17641,17642]
===
match
---
name: State [23823,23828]
name: State [24209,24214]
===
match
---
operator: = [6985,6986]
operator: = [6985,6986]
===
match
---
operator: = [6820,6821]
operator: = [6820,6821]
===
match
---
simple_stmt [5667,5981]
simple_stmt [5667,5981]
===
match
---
name: args [6774,6778]
name: args [6774,6778]
===
match
---
trailer [22508,22534]
trailer [22894,22920]
===
match
---
simple_stmt [22861,22893]
simple_stmt [23247,23279]
===
match
---
name: test_time_sensor [2810,2826]
name: test_time_sensor [2810,2826]
===
match
---
arglist [21468,21523]
arglist [21468,21523]
===
match
---
param [12086,12093]
param [12086,12093]
===
match
---
comparison [21742,21765]
comparison [21742,21765]
===
match
---
atom_expr [31229,31494]
atom_expr [31615,31880]
===
match
---
name: ignore_ti_state [11839,11854]
name: ignore_ti_state [11839,11854]
===
match
---
operator: , [10486,10487]
operator: , [10486,10487]
===
match
---
operator: , [15816,15817]
operator: , [15816,15817]
===
match
---
name: get_dag [29768,29775]
name: get_dag [30154,30161]
===
match
---
operator: = [11065,11066]
operator: = [11065,11066]
===
match
---
name: getattr [17891,17898]
name: getattr [17891,17898]
===
match
---
trailer [19641,19699]
trailer [19641,19699]
===
match
---
name: dags [27845,27849]
name: dags [28231,28235]
===
match
---
name: time [839,843]
name: time [839,843]
===
match
---
name: DEFAULT_DATE [34094,34106]
name: DEFAULT_DATE [34480,34492]
===
match
---
name: task_id [12231,12238]
name: task_id [12231,12238]
===
match
---
name: self [9100,9104]
name: self [9100,9104]
===
match
---
suite [30628,31536]
suite [31014,31922]
===
match
---
name: test_serialized_external_task_marker [17323,17359]
name: test_serialized_external_task_marker [17323,17359]
===
match
---
operator: = [14737,14738]
operator: = [14737,14738]
===
match
---
name: allowed_states [14904,14918]
name: allowed_states [14904,14918]
===
match
---
name: AirflowException [16019,16035]
name: AirflowException [16019,16035]
===
match
---
operator: , [13171,13172]
operator: , [13171,13172]
===
match
---
arglist [24241,24270]
arglist [24627,24656]
===
match
---
argument [19115,19138]
argument [19115,19138]
===
match
---
name: bag_dag [20387,20394]
name: bag_dag [20387,20394]
===
match
---
name: task_a_0 [30231,30239]
name: task_a_0 [30617,30625]
===
match
---
atom_expr [24384,24405]
atom_expr [24770,24791]
===
match
---
name: models [1051,1057]
name: models [1051,1057]
===
match
---
name: root_dag [30994,31002]
name: root_dag [31380,31388]
===
match
---
name: ti [22522,22524]
name: ti [22908,22910]
===
match
---
atom_expr [8601,8858]
atom_expr [8601,8858]
===
match
---
parameters [2789,2795]
parameters [2789,2795]
===
match
---
name: DEFAULT_DATE [11199,11211]
name: DEFAULT_DATE [11199,11211]
===
match
---
argument [14222,14278]
argument [14222,14278]
===
match
---
name: day_1 [25194,25199]
name: day_1 [25580,25585]
===
match
---
trailer [34488,34495]
trailer [34874,34881]
===
match
---
with_stmt [28164,28767]
with_stmt [28550,29153]
===
match
---
with_stmt [16449,16576]
with_stmt [16449,16576]
===
match
---
name: dag [31034,31037]
name: dag [31420,31423]
===
match
---
name: external_task_id [2585,2601]
name: external_task_id [2585,2601]
===
match
---
name: test_external_task_sensor_multiple_task_ids [2746,2789]
name: test_external_task_sensor_multiple_task_ids [2746,2789]
===
match
---
operator: , [30375,30376]
operator: , [30761,30762]
===
match
---
name: models [995,1001]
name: models [995,1001]
===
match
---
name: dag_bag [20379,20386]
name: dag_bag [20379,20386]
===
match
---
with_stmt [21459,21816]
with_stmt [21459,21816]
===
match
---
argument [15317,15329]
argument [15317,15329]
===
match
---
operator: = [15741,15742]
operator: = [15741,15742]
===
match
---
operator: = [10628,10629]
operator: = [10628,10629]
===
match
---
funcdef [20476,21935]
funcdef [20476,21935]
===
match
---
atom_expr [34512,34520]
atom_expr [34898,34906]
===
match
---
argument [9568,9575]
argument [9568,9575]
===
match
---
name: ExternalTaskMarker [19067,19085]
name: ExternalTaskMarker [19067,19085]
===
match
---
trailer [3169,3239]
trailer [3169,3239]
===
match
---
expr_stmt [26124,26162]
expr_stmt [26510,26548]
===
match
---
name: self [12463,12467]
name: self [12463,12467]
===
match
---
name: get_serialized_fields [17289,17310]
name: get_serialized_fields [17289,17310]
===
match
---
name: DEFAULT_DATE [7222,7234]
name: DEFAULT_DATE [7222,7234]
===
match
---
expr_stmt [18996,19051]
expr_stmt [18996,19051]
===
match
---
arglist [21872,21893]
arglist [21872,21893]
===
match
---
argument [4014,4026]
argument [4014,4026]
===
match
---
operator: = [12532,12533]
operator: = [12532,12533]
===
match
---
atom_expr [29156,29353]
atom_expr [29542,29739]
===
match
---
atom_expr [31018,31064]
atom_expr [31404,31450]
===
match
---
operator: = [2261,2262]
operator: = [2261,2262]
===
match
---
operator: , [33705,33706]
operator: , [34091,34092]
===
match
---
name: execution_date [25873,25887]
name: execution_date [26259,26273]
===
match
---
operator: = [8336,8337]
operator: = [8336,8337]
===
match
---
simple_stmt [17066,17137]
simple_stmt [17066,17137]
===
match
---
string: 'task_with_failure' [9655,9674]
string: 'task_with_failure' [9655,9674]
===
match
---
name: dag_bag_ext [26946,26957]
name: dag_bag_ext [27332,27343]
===
match
---
operator: = [27883,27884]
operator: = [28269,28270]
===
match
---
argument [28550,28571]
argument [28936,28957]
===
match
---
string: 'task_{{ ds }}' [16791,16806]
string: 'task_{{ ds }}' [16791,16806]
===
match
---
name: session [25103,25110]
name: session [25489,25496]
===
match
---
argument [7721,7757]
argument [7721,7757]
===
match
---
arglist [31034,31063]
arglist [31420,31449]
===
match
---
argument [3873,3900]
argument [3873,3900]
===
match
---
decorated [18046,20458]
decorated [18046,20458]
===
match
---
operator: = [12462,12463]
operator: = [12462,12463]
===
match
---
name: get_dagrun [24971,24981]
name: get_dagrun [25357,25367]
===
match
---
operator: = [24527,24528]
operator: = [24913,24914]
===
match
---
name: task_instance [22759,22772]
name: task_instance [23145,23158]
===
match
---
operator: = [5023,5024]
operator: = [5023,5024]
===
match
---
name: task_instances [22460,22474]
name: task_instances [22793,22807]
===
match
---
atom_expr [25392,25404]
atom_expr [25778,25790]
===
match
---
arglist [25860,25894]
arglist [26246,26280]
===
match
---
operator: } [17059,17060]
operator: } [17059,17060]
===
match
---
trailer [10350,10352]
trailer [10350,10352]
===
match
---
name: context [12086,12093]
name: context [12086,12093]
===
match
---
name: airflow [917,924]
name: airflow [917,924]
===
match
---
atom [4797,4808]
atom [4797,4808]
===
match
---
operator: , [16333,16334]
operator: , [16333,16334]
===
match
---
name: dag [21876,21879]
name: dag [21876,21879]
===
match
---
operator: , [12796,12797]
operator: , [12796,12797]
===
match
---
name: context [12115,12122]
name: context [12115,12122]
===
match
---
argument [28023,28050]
argument [28409,28436]
===
match
---
operator: , [33389,33390]
operator: , [33775,33776]
===
match
---
arglist [24196,24225]
arglist [24582,24611]
===
match
---
simple_stmt [5285,5460]
simple_stmt [5285,5460]
===
match
---
funcdef [26994,29505]
funcdef [27380,29891]
===
match
---
expr_stmt [29696,29724]
expr_stmt [30082,30110]
===
match
---
atom_expr [2222,2284]
atom_expr [2222,2284]
===
match
---
trailer [5233,5243]
trailer [5233,5243]
===
match
---
trailer [10791,10808]
trailer [10791,10808]
===
match
---
name: start_date [30906,30916]
name: start_date [31292,31302]
===
match
---
simple_stmt [26359,26408]
simple_stmt [26745,26794]
===
match
---
name: task_b_0 [19414,19422]
name: task_b_0 [19414,19422]
===
match
---
param [6712,6716]
param [6712,6716]
===
match
---
atom_expr [7153,7161]
atom_expr [7153,7161]
===
match
---
name: dag_3 [20228,20233]
name: dag_3 [20228,20233]
===
match
---
lambdef [13853,13866]
lambdef [13853,13866]
===
match
---
trailer [34178,34185]
trailer [34564,34571]
===
match
---
trailer [25920,25928]
trailer [26306,26314]
===
match
---
name: schedule_interval [19676,19693]
name: schedule_interval [19676,19693]
===
match
---
trailer [9409,9420]
trailer [9409,9420]
===
match
---
string: "unit_test_dag failed." [6640,6663]
string: "unit_test_dag failed." [6640,6663]
===
match
---
name: dag [7158,7161]
name: dag [7158,7161]
===
match
---
operator: = [31475,31476]
operator: = [31861,31862]
===
match
---
operator: , [13250,13251]
operator: , [13250,13251]
===
match
---
atom_expr [2293,2369]
atom_expr [2293,2369]
===
match
---
argument [21881,21893]
argument [21881,21893]
===
match
---
operator: = [21102,21103]
operator: = [21102,21103]
===
match
---
argument [22329,22354]
argument [22329,22354]
===
match
---
name: State [23869,23874]
name: State [24255,24260]
===
match
---
argument [7236,7256]
argument [7236,7256]
===
match
---
name: op [16050,16052]
name: op [16050,16052]
===
match
---
name: dag_maker [16618,16627]
name: dag_maker [16618,16627]
===
match
---
number: 1 [7654,7655]
number: 1 [7654,7655]
===
match
---
atom_expr [33693,33705]
atom_expr [34079,34091]
===
match
---
trailer [7005,7172]
trailer [7005,7172]
===
match
---
string: "head_tail" [33214,33225]
string: "head_tail" [33600,33611]
===
match
---
name: schedule_interval [7618,7635]
name: schedule_interval [7618,7635]
===
match
---
operator: , [9554,9555]
operator: , [9554,9555]
===
match
---
name: external_task_id [29276,29292]
name: external_task_id [29662,29678]
===
match
---
expr_stmt [8142,8170]
expr_stmt [8142,8170]
===
match
---
name: DEFAULT_DATE [6789,6801]
name: DEFAULT_DATE [6789,6801]
===
match
---
operator: = [31081,31082]
operator: = [31467,31468]
===
match
---
trailer [27960,28083]
trailer [28346,28469]
===
match
---
name: backend [31576,31583]
name: backend [31962,31969]
===
match
---
atom_expr [26253,26301]
atom_expr [26639,26687]
===
match
---
name: timedelta [13805,13814]
name: timedelta [13805,13814]
===
match
---
simple_stmt [16920,16956]
simple_stmt [16920,16956]
===
match
---
with_item [33210,33286]
with_item [33596,33672]
===
match
---
name: day_2 [24751,24756]
name: day_2 [25137,25142]
===
match
---
trailer [16424,16428]
trailer [16424,16428]
===
match
---
fstring_expr [31271,31291]
fstring_expr [31657,31677]
===
match
---
argument [16856,16885]
argument [16856,16885]
===
match
---
name: execution_date [32373,32387]
name: execution_date [32759,32773]
===
match
---
atom [24437,24451]
atom [24823,24837]
===
match
---
operator: , [30558,30559]
operator: , [30944,30945]
===
match
---
name: bash_command_code [7336,7353]
name: bash_command_code [7336,7353]
===
match
---
operator: , [15157,15158]
operator: , [15157,15158]
===
match
---
argument [21425,21442]
argument [21425,21442]
===
match
---
fstring_end: " [29064,29065]
fstring_end: " [29450,29451]
===
match
---
trailer [11694,11698]
trailer [11694,11698]
===
match
---
name: DagBag [27678,27684]
name: DagBag [28064,28070]
===
match
---
simple_stmt [13443,13467]
simple_stmt [13443,13467]
===
match
---
name: append [28263,28269]
name: append [28649,28655]
===
match
---
operator: , [2184,2185]
operator: , [2184,2185]
===
match
---
operator: , [16885,16886]
operator: , [16885,16886]
===
match
---
trailer [5313,5324]
trailer [5313,5324]
===
match
---
name: task_id [30563,30570]
name: task_id [30949,30956]
===
match
---
trailer [28920,28927]
trailer [29306,29313]
===
match
---
name: len [8888,8891]
name: len [8888,8891]
===
match
---
operator: = [11460,11461]
operator: = [11460,11461]
===
match
---
trailer [34540,34548]
trailer [34926,34934]
===
match
---
simple_stmt [20442,20458]
simple_stmt [20442,20458]
===
match
---
operator: , [16080,16081]
operator: , [16080,16081]
===
match
---
name: dag_folder [27685,27695]
name: dag_folder [28071,28081]
===
match
---
name: execution_date_fn [13185,13202]
name: execution_date_fn [13185,13202]
===
match
---
operator: , [7100,7101]
operator: , [7100,7101]
===
match
---
name: execution_date [35042,35056]
name: execution_date [35428,35442]
===
match
---
string: "dag_0" [30386,30393]
string: "dag_0" [30772,30779]
===
match
---
name: poke_interval [9539,9552]
name: poke_interval [9539,9552]
===
match
---
string: 'test_external_task_sensor_check_delta_1' [10909,10950]
string: 'test_external_task_sensor_check_delta_1' [10909,10950]
===
match
---
assert_stmt [25365,25404]
assert_stmt [25751,25790]
===
match
---
trailer [26677,26690]
trailer [27063,27076]
===
match
---
argument [16105,16125]
argument [16105,16125]
===
match
---
suite [13434,13956]
suite [13434,13956]
===
match
---
name: task [17082,17086]
name: task [17082,17086]
===
match
---
expr_stmt [24115,24135]
expr_stmt [24501,24521]
===
match
---
operator: , [22772,22773]
operator: , [23158,23159]
===
match
---
name: assert_ti_state_equal [26359,26380]
name: assert_ti_state_equal [26745,26766]
===
match
---
simple_stmt [27845,27862]
simple_stmt [28231,28248]
===
match
---
trailer [28140,28150]
trailer [28526,28536]
===
match
---
atom_expr [17168,17185]
atom_expr [17168,17185]
===
match
---
name: seconds [8090,8097]
name: seconds [8090,8097]
===
match
---
string: 'unit_test_dag' [1683,1698]
string: 'unit_test_dag' [1683,1698]
===
match
---
name: dag [34175,34178]
name: dag [34561,34564]
===
match
---
name: state [25383,25388]
name: state [25769,25774]
===
match
---
name: pytest [3309,3315]
name: pytest [3309,3315]
===
match
---
atom [6214,6459]
atom [6214,6459]
===
match
---
operator: , [15611,15612]
operator: , [15611,15612]
===
match
---
name: session [33951,33958]
name: session [34337,34344]
===
match
---
raise_stmt [9023,9030]
raise_stmt [9023,9030]
===
match
---
operator: , [7800,7801]
operator: , [7800,7801]
===
match
---
name: TEST_TASK_ID [3935,3947]
name: TEST_TASK_ID [3935,3947]
===
match
---
suite [31213,31517]
suite [31599,31903]
===
match
---
fstring_string: dag_ [28401,28405]
fstring_string: dag_ [28787,28791]
===
match
---
name: allowed_states [9453,9467]
name: allowed_states [9453,9467]
===
match
---
operator: , [35056,35057]
operator: , [35442,35443]
===
match
---
name: dag_bag_cyclic [29549,29563]
name: dag_bag_cyclic [29935,29949]
===
match
---
operator: = [33165,33166]
operator: = [33551,33552]
===
match
---
arith_expr [8781,8816]
arith_expr [8781,8816]
===
match
---
fstring_expr [28837,28844]
fstring_expr [29223,29230]
===
match
---
operator: = [14311,14312]
operator: = [14311,14312]
===
match
---
expr_stmt [7336,7497]
expr_stmt [7336,7497]
===
match
---
name: dag [29396,29399]
name: dag [29782,29785]
===
match
---
parameters [16191,16197]
parameters [16191,16197]
===
match
---
operator: = [7635,7636]
operator: = [7635,7636]
===
match
---
name: deserialized_op [17826,17841]
name: deserialized_op [17826,17841]
===
match
---
name: daily_dag [30983,30992]
name: daily_dag [31369,31378]
===
match
---
operator: = [26845,26846]
operator: = [27231,27232]
===
match
---
operator: , [6913,6914]
operator: , [6913,6914]
===
match
---
operator: = [7653,7654]
operator: = [7653,7654]
===
match
---
simple_stmt [12970,12995]
simple_stmt [12970,12995]
===
match
---
name: session [25004,25011]
name: session [25390,25397]
===
match
---
name: task_id [7019,7026]
name: task_id [7019,7026]
===
match
---
expr_stmt [2033,2093]
expr_stmt [2033,2093]
===
match
---
trailer [4360,4364]
trailer [4360,4364]
===
match
---
name: task_external_with_failure [7666,7692]
name: task_external_with_failure [7666,7692]
===
match
---
name: dag_id [33656,33662]
name: dag_id [34042,34048]
===
match
---
operator: , [21326,21327]
operator: , [21326,21327]
===
match
---
name: start_date [4391,4401]
name: start_date [4391,4401]
===
match
---
operator: = [9047,9048]
operator: = [9047,9048]
===
match
---
operator: = [13049,13050]
operator: = [13049,13050]
===
match
---
operator: , [33662,33663]
operator: , [34048,34049]
===
match
---
name: DAG [6739,6742]
name: DAG [6739,6742]
===
match
---
operator: + [8078,8079]
operator: + [8078,8079]
===
match
---
name: SCHEDULED [16876,16885]
name: SCHEDULED [16876,16885]
===
match
---
trailer [27856,27861]
trailer [28242,28247]
===
match
---
name: state [8717,8722]
name: state [8717,8722]
===
match
---
name: dagrun [34375,34381]
name: dagrun [34761,34767]
===
match
---
name: dag_0 [21833,21838]
name: dag_0 [21833,21838]
===
match
---
trailer [34495,34499]
trailer [34881,34885]
===
match
---
arglist [12499,12567]
arglist [12499,12567]
===
match
---
name: test_catch_overlap_allowed_failed_state [3249,3288]
name: test_catch_overlap_allowed_failed_state [3249,3288]
===
match
---
name: SUCCESS [3563,3570]
name: SUCCESS [3563,3570]
===
match
---
trailer [31383,31391]
trailer [31769,31777]
===
match
---
name: deserialize_operator [17775,17795]
name: deserialize_operator [17775,17795]
===
match
---
operator: = [23393,23394]
operator: = [23779,23780]
===
match
---
operator: @ [26978,26979]
operator: @ [27364,27365]
===
match
---
name: DEFAULT_DATE [4402,4414]
name: DEFAULT_DATE [4402,4414]
===
match
---
parameters [4520,4526]
parameters [4520,4526]
===
match
---
atom_expr [13443,13466]
atom_expr [13443,13466]
===
match
---
atom [15282,15299]
atom [15282,15299]
===
match
---
name: schedule_interval [30931,30948]
name: schedule_interval [31317,31334]
===
match
---
atom_expr [26934,26975]
atom_expr [27320,27361]
===
match
---
arglist [22253,22424]
arglist [22253,22424]
===
match
---
name: task_id [20269,20276]
name: task_id [20269,20276]
===
match
---
name: task_id [14222,14229]
name: task_id [14222,14229]
===
match
---
operator: = [25951,25952]
operator: = [26337,26338]
===
match
---
atom [30385,30406]
atom [30771,30792]
===
match
---
atom_expr [25137,25217]
atom_expr [25523,25603]
===
match
---
simple_stmt [787,802]
simple_stmt [787,802]
===
match
---
param [22759,22773]
param [23145,23159]
===
match
---
trailer [4989,5059]
trailer [4989,5059]
===
match
---
operator: { [29209,29210]
operator: { [29595,29596]
===
match
---
name: run_tasks [24231,24240]
name: run_tasks [24617,24626]
===
match
---
name: raises [11730,11736]
name: raises [11730,11736]
===
match
---
trailer [20214,20222]
trailer [20214,20222]
===
match
---
name: get_dag [31953,31960]
name: get_dag [32339,32346]
===
match
---
trailer [10333,10350]
trailer [10333,10350]
===
match
---
operator: + [11561,11562]
operator: + [11561,11562]
===
match
---
operator: = [9927,9928]
operator: = [9927,9928]
===
match
---
operator: , [7211,7212]
operator: , [7211,7212]
===
match
---
number: 3 [28068,28069]
number: 3 [28454,28455]
===
match
---
name: dag_0 [29800,29805]
name: dag_0 [30186,30191]
===
match
---
operator: = [3180,3181]
operator: = [3180,3181]
===
match
---
operator: , [9906,9907]
operator: , [9906,9907]
===
match
---
name: dagrun_1_1 [25124,25134]
name: dagrun_1_1 [25510,25520]
===
match
---
name: end_date [7213,7221]
name: end_date [7213,7221]
===
match
---
operator: = [28398,28399]
operator: = [28784,28785]
===
match
---
name: session [34929,34936]
name: session [35315,35322]
===
match
---
trailer [32096,32145]
trailer [32482,32531]
===
match
---
name: DAG [20034,20037]
name: DAG [20034,20037]
===
match
---
simple_stmt [19848,19996]
simple_stmt [19848,19996]
===
match
---
argument [20139,20157]
argument [20139,20157]
===
match
---
simple_stmt [5605,5659]
simple_stmt [5605,5659]
===
match
---
atom_expr [33976,34014]
atom_expr [34362,34400]
===
match
---
name: TEST_TASK_ID [14873,14885]
name: TEST_TASK_ID [14873,14885]
===
match
---
name: ti [22658,22660]
name: ti [23044,23046]
===
match
---
atom [3979,3996]
atom [3979,3996]
===
match
---
if_stmt [8885,9031]
if_stmt [8885,9031]
===
match
---
name: dag [17638,17641]
name: dag [17638,17641]
===
match
---
suite [32016,32146]
suite [32402,32532]
===
match
---
name: utils [1512,1517]
name: utils [1512,1517]
===
match
---
atom_expr [26858,26924]
atom_expr [27244,27310]
===
match
---
name: issubset [17261,17269]
name: issubset [17261,17269]
===
match
---
expr_stmt [31926,31971]
expr_stmt [32312,32357]
===
match
---
trailer [17288,17310]
trailer [17288,17310]
===
match
---
expr_stmt [2102,2153]
expr_stmt [2102,2153]
===
match
---
operator: = [15320,15321]
operator: = [15320,15321]
===
match
---
fstring [28831,28845]
fstring [29217,29231]
===
match
---
argument [20395,20402]
argument [20395,20402]
===
match
---
atom_expr [26789,26815]
atom_expr [27175,27201]
===
match
---
argument [10689,10710]
argument [10689,10710]
===
match
---
name: ExternalTaskMarker [33576,33594]
name: ExternalTaskMarker [33962,33980]
===
match
---
assert_stmt [6207,6459]
assert_stmt [6207,6459]
===
match
---
argument [31356,31391]
argument [31742,31777]
===
match
---
name: run_type [34281,34289]
name: run_type [34667,34675]
===
match
---
trailer [11790,11860]
trailer [11790,11860]
===
match
---
atom_expr [31203,31212]
atom_expr [31589,31598]
===
match
---
name: dagrun_0_1 [24926,24936]
name: dagrun_0_1 [25312,25322]
===
match
---
operator: = [30982,30983]
operator: = [31368,31369]
===
match
---
name: raises [6069,6075]
name: raises [6069,6075]
===
match
---
string: "recursion_depth" [17242,17259]
string: "recursion_depth" [17242,17259]
===
match
---
atom_expr [2033,2042]
atom_expr [2033,2042]
===
match
---
operator: , [26102,26103]
operator: , [26488,26489]
===
match
---
trailer [3745,3752]
trailer [3745,3752]
===
match
---
argument [28210,28232]
argument [28596,28618]
===
match
---
name: task_id [14730,14737]
name: task_id [14730,14737]
===
match
---
trailer [8716,8722]
trailer [8716,8722]
===
match
---
argument [19021,19039]
argument [19021,19039]
===
match
---
suite [14173,14510]
suite [14173,14510]
===
match
---
name: test_external_task_sensor_fn_multiple_execution_dates [7267,7320]
name: test_external_task_sensor_fn_multiple_execution_dates [7267,7320]
===
match
---
trailer [13299,13303]
trailer [13299,13303]
===
match
---
name: timedelta [8319,8328]
name: timedelta [8319,8328]
===
match
---
name: dag_bag [24241,24248]
name: dag_bag [24627,24634]
===
match
---
name: tis [23573,23576]
name: tis [23959,23962]
===
match
---
funcdef [16132,16576]
funcdef [16132,16576]
===
match
---
name: days [25761,25765]
name: days [26147,26151]
===
match
---
operator: = [2963,2964]
operator: = [2963,2964]
===
match
---
name: task_external_without_failure [7837,7866]
name: task_external_without_failure [7837,7866]
===
match
---
operator: = [4141,4142]
operator: = [4141,4142]
===
match
---
name: run [3166,3169]
name: run [3166,3169]
===
match
---
name: DAG [9075,9078]
name: DAG [9075,9078]
===
match
---
operator: - [29061,29062]
operator: - [29447,29448]
===
match
---
argument [18968,18990]
argument [18968,18990]
===
match
---
simple_stmt [25774,25833]
simple_stmt [26160,26219]
===
match
---
operator: , [15329,15330]
operator: , [15329,15330]
===
match
---
name: dag_folder [21065,21075]
name: dag_folder [21065,21075]
===
match
---
name: op [2217,2219]
name: op [2217,2219]
===
match
---
name: external_task_id [17590,17606]
name: external_task_id [17590,17606]
===
match
---
atom_expr [15321,15329]
atom_expr [15321,15329]
===
match
---
name: dag_bag_ext [26450,26461]
name: dag_bag_ext [26836,26847]
===
match
---
name: self [15633,15637]
name: self [15633,15637]
===
match
---
string: """     Create a DagBag with two DAGs looking like this. task_1 of child_dag_1 on day 1 depends on     task_0 of parent_dag_0 on day 1. Therefore, when task_0 of parent_dag_0 on day 1 and day 2     are cleared, parent_dag_0 DagRuns need to be set to running on both days, but child_dag_1     only needs to be set to running on day 1.                     day 1   day 2       parent_dag_0  task_0  task_0                      |                      |                      v      child_dag_1   task_1  task_1      """ [20508,21022]
string: """     Create a DagBag with two DAGs looking like this. task_1 of child_dag_1 on day 1 depends on     task_0 of parent_dag_0 on day 1. Therefore, when task_0 of parent_dag_0 on day 1 and day 2     are cleared, parent_dag_0 DagRuns need to be set to running on both days, but child_dag_1     only needs to be set to running on day 1.                     day 1   day 2       parent_dag_0  task_0  task_0                      |                      |                      v      child_dag_1   task_1  task_1      """ [20508,21022]
===
match
---
string: 'test_external_task_sensor_check_task_ids' [2964,3006]
string: 'test_external_task_sensor_check_task_ids' [2964,3006]
===
match
---
number: 1 [9951,9952]
number: 1 [9951,9952]
===
match
---
operator: = [22563,22564]
operator: = [22949,22950]
===
match
---
comparison [17826,17875]
comparison [17826,17875]
===
match
---
operator: = [9703,9704]
operator: = [9703,9704]
===
match
---
name: external_task_id [11486,11502]
name: external_task_id [11486,11502]
===
match
---
operator: , [12445,12446]
operator: , [12445,12446]
===
match
---
name: test_time_sensor [5610,5626]
name: test_time_sensor [5610,5626]
===
match
---
expr_stmt [20100,20239]
expr_stmt [20100,20239]
===
match
---
name: task_id [3814,3821]
name: task_id [3814,3821]
===
match
---
number: 1 [11578,11579]
number: 1 [11578,11579]
===
match
---
argument [15629,15641]
argument [15629,15641]
===
match
---
operator: , [26964,26965]
operator: , [27350,27351]
===
match
---
operator: = [14452,14453]
operator: = [14452,14453]
===
match
---
arglist [20038,20094]
arglist [20038,20094]
===
match
---
name: dag [5957,5960]
name: dag [5957,5960]
===
match
---
atom_expr [31326,31342]
atom_expr [31712,31728]
===
match
---
name: session [22616,22623]
name: session [23002,23009]
===
match
---
name: DEFAULT_DATE [16902,16914]
name: DEFAULT_DATE [16902,16914]
===
match
---
name: tis_date_0 [25774,25784]
name: tis_date_0 [26160,26170]
===
match
---
name: execution_date [24504,24518]
name: execution_date [24890,24904]
===
match
---
name: self [15321,15325]
name: self [15321,15325]
===
match
---
argument [15933,15953]
argument [15933,15953]
===
match
---
name: dagrun [22453,22459]
name: dagrun [22786,22792]
===
match
---
arglist [34061,34066]
arglist [34447,34452]
===
match
---
arglist [25081,25118]
arglist [25467,25504]
===
match
---
name: ExternalTaskSensor [15743,15761]
name: ExternalTaskSensor [15743,15761]
===
match
---
name: dag [28899,28902]
name: dag [29285,29288]
===
match
---
name: dag [3131,3134]
name: dag [3131,3134]
===
match
---
expr_stmt [1699,1733]
expr_stmt [1699,1733]
===
match
---
operator: , [2571,2572]
operator: , [2571,2572]
===
match
---
argument [19511,19534]
argument [19511,19534]
===
match
---
simple_stmt [4138,4376]
simple_stmt [4138,4376]
===
match
---
name: run [16502,16505]
name: run [16502,16505]
===
match
---
name: start_date [23339,23349]
name: start_date [23725,23735]
===
match
---
simple_stmt [1586,1632]
simple_stmt [1586,1632]
===
match
---
string: """     Tests clearing across multiple DAGs that have cyclic dependencies shallower     than recursion_depth     """ [30018,30134]
string: """     Tests clearing across multiple DAGs that have cyclic dependencies shallower     than recursion_depth     """ [30404,30520]
===
match
---
argument [12231,12282]
argument [12231,12282]
===
match
---
name: run_tasks [21958,21967]
name: run_tasks [21958,21967]
===
match
---
name: task_external_without_failure [7984,8013]
name: task_external_without_failure [7984,8013]
===
match
---
operator: = [21991,21992]
operator: = [21991,21992]
===
match
---
operator: = [31104,31105]
operator: = [31490,31491]
===
match
---
trailer [1656,1668]
trailer [1656,1668]
===
match
---
simple_stmt [33780,33801]
simple_stmt [34166,34187]
===
match
---
atom_expr [9075,9150]
atom_expr [9075,9150]
===
match
---
parameters [12081,12094]
parameters [12081,12094]
===
match
---
name: test_catch_duplicate_task_ids [14519,14548]
name: test_catch_duplicate_task_ids [14519,14548]
===
match
---
operator: = [29154,29155]
operator: = [29540,29541]
===
match
---
name: dag [19980,19983]
name: dag [19980,19983]
===
match
---
operator: , [13350,13351]
operator: , [13350,13351]
===
match
---
simple_stmt [1429,1499]
simple_stmt [1429,1499]
===
match
---
atom_expr [22904,22923]
atom_expr [23290,23309]
===
match
---
name: start_date [16506,16516]
name: start_date [16506,16516]
===
match
---
operator: = [34327,34328]
operator: = [34713,34714]
===
match
---
name: my_func [13203,13210]
name: my_func [13203,13210]
===
match
---
operator: { [28459,28460]
operator: { [28845,28846]
===
match
---
expr_stmt [29789,29826]
expr_stmt [30175,30212]
===
match
---
name: run [11184,11187]
name: run [11184,11187]
===
match
---
name: dagrun [24549,24555]
name: dagrun [24935,24941]
===
match
---
expr_stmt [24465,24536]
expr_stmt [24851,24922]
===
match
---
arith_expr [12977,12994]
arith_expr [12977,12994]
===
match
---
string: 'success' [11124,11133]
string: 'success' [11124,11133]
===
match
---
name: day_1 [24220,24225]
name: day_1 [24606,24611]
===
match
---
trailer [25441,25448]
trailer [25827,25834]
===
match
---
argument [33831,33843]
argument [34217,34229]
===
match
---
operator: , [15979,15980]
operator: , [15979,15980]
===
match
---
string: 'other_dag' [7089,7100]
string: 'other_dag' [7089,7100]
===
match
---
atom_expr [15971,15979]
atom_expr [15971,15979]
===
match
---
operator: = [33825,33826]
operator: = [34211,34212]
===
match
---
with_item [6062,6100]
with_item [6062,6100]
===
match
---
name: execution_date [33719,33733]
name: execution_date [34105,34119]
===
match
---
name: dag [22222,22225]
name: dag [22222,22225]
===
match
---
simple_stmt [19056,19204]
simple_stmt [19056,19204]
===
match
---
operator: = [2922,2923]
operator: = [2922,2923]
===
match
---
operator: = [9571,9572]
operator: = [9571,9572]
===
match
---
operator: , [1472,1473]
operator: , [1472,1473]
===
match
---
expr_stmt [9069,9150]
expr_stmt [9069,9150]
===
match
---
trailer [15325,15329]
trailer [15325,15329]
===
match
---
name: external_task_id [28643,28659]
name: external_task_id [29029,29045]
===
match
---
trailer [8168,8170]
trailer [8168,8170]
===
match
---
simple_stmt [30337,30587]
simple_stmt [30723,30973]
===
match
---
fstring_end: " [29014,29015]
fstring_end: " [29400,29401]
===
match
---
name: dag_bag_head_tail [33932,33949]
name: dag_bag_head_tail [34318,34335]
===
match
---
operator: , [24443,24444]
operator: , [24829,24830]
===
match
---
name: external_task_ids [14388,14405]
name: external_task_ids [14388,14405]
===
match
---
operator: , [2640,2641]
operator: , [2640,2641]
===
match
---
trailer [6500,6511]
trailer [6500,6511]
===
match
---
name: DEFAULT_DATE [6930,6942]
name: DEFAULT_DATE [6930,6942]
===
match
---
operator: = [28449,28450]
operator: = [28835,28836]
===
match
---
name: session [22644,22651]
name: session [23030,23037]
===
match
---
name: range [9857,9862]
name: range [9857,9862]
===
match
---
operator: = [16901,16902]
operator: = [16901,16902]
===
match
---
argument [19584,19593]
argument [19584,19593]
===
match
---
string: "mysql" [31596,31603]
string: "mysql" [31982,31989]
===
match
---
atom_expr [17465,17652]
atom_expr [17465,17652]
===
match
---
parameters [10771,10777]
parameters [10771,10777]
===
match
---
operator: , [26341,26342]
operator: , [26727,26728]
===
match
---
simple_stmt [34077,34131]
simple_stmt [34463,34517]
===
match
---
name: dag [9568,9571]
name: dag [9568,9571]
===
match
---
name: task_id [21575,21582]
name: task_id [21575,21582]
===
match
---
trailer [8666,8673]
trailer [8666,8673]
===
match
---
annassign [33968,34014]
annassign [34354,34400]
===
match
---
name: raises [3746,3752]
name: raises [3746,3752]
===
match
---
operator: = [31121,31122]
operator: = [31507,31508]
===
match
---
atom_expr [2632,2640]
atom_expr [2632,2640]
===
match
---
name: dag [30979,30982]
name: dag [31365,31368]
===
match
---
operator: = [33455,33456]
operator: = [33841,33842]
===
match
---
name: deserialized_op [17734,17749]
name: deserialized_op [17734,17749]
===
match
---
operator: , [5840,5841]
operator: , [5840,5841]
===
match
---
name: level [6018,6023]
name: level [6018,6023]
===
match
---
operator: = [32421,32422]
operator: = [32807,32808]
===
match
---
name: self [12037,12041]
name: self [12037,12041]
===
match
---
trailer [29428,29436]
trailer [29814,29822]
===
match
---
expr_stmt [20244,20299]
expr_stmt [20244,20299]
===
match
---
operator: = [16699,16700]
operator: = [16699,16700]
===
match
---
name: test_external_task_marker_transitive [23465,23501]
name: test_external_task_marker_transitive [23851,23887]
===
match
---
atom_expr [28510,28733]
atom_expr [28896,29119]
===
match
---
atom_expr [23689,23730]
atom_expr [24075,24116]
===
match
---
trailer [17384,17449]
trailer [17384,17449]
===
match
---
operator: , [23821,23822]
operator: , [24207,24208]
===
match
---
with_stmt [14650,14976]
with_stmt [14650,14976]
===
match
---
argument [15579,15611]
argument [15579,15611]
===
match
---
name: DummyOperator [27885,27898]
name: DummyOperator [28271,28284]
===
match
---
assert_stmt [25453,25493]
assert_stmt [25839,25879]
===
match
---
atom_expr [26359,26407]
atom_expr [26745,26793]
===
match
---
argument [2348,2368]
argument [2348,2368]
===
match
---
trailer [22890,22892]
trailer [23276,23278]
===
match
---
operator: = [35006,35007]
operator: = [35392,35393]
===
match
---
operator: == [17030,17032]
operator: == [17030,17032]
===
match
---
trailer [2299,2369]
trailer [2299,2369]
===
match
---
with_stmt [13552,13956]
with_stmt [13552,13956]
===
match
---
fstring_expr [28357,28360]
fstring_expr [28743,28746]
===
match
---
argument [34281,34307]
argument [34667,34693]
===
match
---
name: self [3289,3293]
name: self [3289,3293]
===
match
---
name: end_date [8056,8064]
name: end_date [8056,8064]
===
match
---
operator: , [28621,28622]
operator: , [29007,29008]
===
match
---
argument [28593,28621]
argument [28979,29007]
===
match
---
trailer [24240,24271]
trailer [24626,24657]
===
match
---
arith_expr [9822,9847]
arith_expr [9822,9847]
===
match
---
name: dag [27857,27860]
name: dag [28243,28246]
===
match
---
decorator [18046,18062]
decorator [18046,18062]
===
match
---
operator: = [19587,19588]
operator: = [19587,19588]
===
match
---
argument [12380,12405]
argument [12380,12405]
===
match
---
simple_stmt [8222,8376]
simple_stmt [8222,8376]
===
match
---
suite [26925,26976]
suite [27311,27362]
===
match
---
trailer [3165,3169]
trailer [3165,3169]
===
match
---
argument [15883,15919]
argument [15883,15919]
===
match
---
name: dummy [1144,1149]
name: dummy [1144,1149]
===
match
---
suite [1859,1880]
suite [1859,1880]
===
match
---
operator: = [26787,26788]
operator: = [27173,27174]
===
match
---
operator: , [22989,22990]
operator: , [23375,23376]
===
match
---
number: 2 [30164,30165]
number: 2 [30550,30551]
===
match
---
name: external_task_id [3918,3934]
name: external_task_id [3918,3934]
===
match
---
name: root_dag [33831,33839]
name: root_dag [34217,34225]
===
match
---
operator: = [24657,24658]
operator: = [25043,25044]
===
match
---
string: "task_a_0" [26151,26161]
string: "task_a_0" [26537,26547]
===
match
---
name: op1 [10863,10866]
name: op1 [10863,10866]
===
match
---
name: timedelta [9827,9836]
name: timedelta [9827,9836]
===
match
---
name: len [31996,31999]
name: len [32382,32385]
===
match
---
with_stmt [5989,6678]
with_stmt [5989,6678]
===
match
---
simple_stmt [27668,27730]
simple_stmt [28054,28116]
===
match
---
name: other_dag [6727,6736]
name: other_dag [6727,6736]
===
match
---
operator: = [23443,23444]
operator: = [23829,23830]
===
match
---
with_stmt [16000,16127]
with_stmt [16000,16127]
===
match
---
operator: = [22415,22416]
operator: = [22415,22416]
===
match
---
simple_stmt [24549,24581]
simple_stmt [24935,24967]
===
match
---
trailer [4940,4958]
trailer [4940,4958]
===
match
---
simple_stmt [14033,14057]
simple_stmt [14033,14057]
===
match
---
name: serialization [1316,1329]
name: serialization [1316,1329]
===
match
---
name: dag_bag [29924,29931]
name: dag_bag [30310,30317]
===
match
---
simple_stmt [18085,18830]
simple_stmt [18085,18830]
===
match
---
simple_stmt [17884,17967]
simple_stmt [17884,17967]
===
match
---
trailer [13614,13955]
trailer [13614,13955]
===
match
---
atom_expr [2457,2651]
atom_expr [2457,2651]
===
match
---
name: task_id [19021,19028]
name: task_id [19021,19028]
===
match
---
simple_stmt [22720,22731]
simple_stmt [23106,23117]
===
match
---
name: root_dag [20404,20412]
name: root_dag [20404,20412]
===
match
---
argument [4883,4901]
argument [4883,4901]
===
match
---
expr_stmt [25124,25217]
expr_stmt [25510,25603]
===
match
---
operator: = [16251,16252]
operator: = [16251,16252]
===
match
---
name: run_type [16856,16864]
name: run_type [16856,16864]
===
match
---
name: task_id [19819,19826]
name: task_id [19819,19826]
===
match
---
operator: = [25233,25234]
operator: = [25619,25620]
===
match
---
operator: = [23577,23578]
operator: = [23963,23964]
===
match
---
simple_stmt [2217,2285]
simple_stmt [2217,2285]
===
match
---
argument [7791,7800]
argument [7791,7800]
===
match
---
atom_expr [14486,14494]
atom_expr [14486,14494]
===
match
---
trailer [17269,17313]
trailer [17269,17313]
===
match
---
operator: = [28608,28609]
operator: = [28994,28995]
===
match
---
argument [12337,12366]
argument [12337,12366]
===
match
---
operator: , [3476,3477]
operator: , [3476,3477]
===
match
---
name: task_id [16692,16699]
name: task_id [16692,16699]
===
match
---
operator: = [8303,8304]
operator: = [8303,8304]
===
match
---
name: task_id [28340,28347]
name: task_id [28726,28733]
===
match
---
simple_stmt [2102,2154]
simple_stmt [2102,2154]
===
match
---
operator: , [6148,6149]
operator: , [6148,6149]
===
match
---
arglist [33155,33198]
arglist [33541,33584]
===
match
---
name: depth [29056,29061]
name: depth [29442,29447]
===
match
---
name: self [1960,1964]
name: self [1960,1964]
===
match
---
simple_stmt [6118,6195]
simple_stmt [6118,6195]
===
match
---
name: test_external_task_sensor_wrong_failed_states [3673,3718]
name: test_external_task_sensor_wrong_failed_states [3673,3718]
===
match
---
operator: = [11608,11609]
operator: = [11608,11609]
===
match
---
name: ExternalTaskMarker [21235,21253]
name: ExternalTaskMarker [21235,21253]
===
match
---
name: self [2405,2409]
name: self [2405,2409]
===
match
---
argument [11816,11837]
argument [11816,11837]
===
match
---
argument [11594,11620]
argument [11594,11620]
===
match
---
name: op [16207,16209]
name: op [16207,16209]
===
match
---
parameters [2404,2410]
parameters [2404,2410]
===
match
---
operator: , [25871,25872]
operator: , [26257,26258]
===
match
---
operator: = [10516,10517]
operator: = [10516,10517]
===
match
---
atom [21832,21846]
atom [21832,21846]
===
match
---
name: AirflowException [26872,26888]
name: AirflowException [27258,27274]
===
match
---
operator: = [2274,2275]
operator: = [2274,2275]
===
match
---
argument [28340,28361]
argument [28726,28747]
===
match
---
name: pytest [31539,31545]
name: pytest [31925,31931]
===
match
---
atom_expr [5961,5969]
atom_expr [5961,5969]
===
match
---
operator: = [12238,12239]
operator: = [12238,12239]
===
match
---
operator: , [9719,9720]
operator: , [9719,9720]
===
match
---
trailer [34443,34454]
trailer [34829,34840]
===
match
---
operator: = [16790,16791]
operator: = [16790,16791]
===
match
---
operator: = [16516,16517]
operator: = [16516,16517]
===
match
---
name: dag [4352,4355]
name: dag [4352,4355]
===
match
---
param [23047,23069]
param [23433,23455]
===
match
---
argument [30548,30585]
argument [30934,30971]
===
match
---
name: dags [28258,28262]
name: dags [28644,28648]
===
match
---
name: external_task_id [28433,28449]
name: external_task_id [28819,28835]
===
match
---
name: BashOperator [7695,7707]
name: BashOperator [7695,7707]
===
match
---
comparison [8714,8738]
comparison [8714,8738]
===
match
---
simple_stmt [5072,5273]
simple_stmt [5072,5273]
===
match
---
suite [10320,10734]
suite [10320,10734]
===
match
---
trailer [24673,24683]
trailer [25059,25069]
===
match
---
string: 'test_external_task_sensor_fn_kwargs' [13050,13087]
string: 'test_external_task_sensor_fn_kwargs' [13050,13087]
===
match
---
name: execution_date [32130,32144]
name: execution_date [32516,32530]
===
match
---
return_stmt [12159,12183]
return_stmt [12159,12183]
===
match
---
operator: , [2713,2714]
operator: , [2713,2714]
===
match
---
fstring_end: " [17135,17136]
fstring_end: " [17135,17136]
===
match
---
operator: , [34185,34186]
operator: , [34571,34572]
===
match
---
atom_expr [25416,25432]
atom_expr [25802,25818]
===
match
---
name: seconds [7646,7653]
name: seconds [7646,7653]
===
match
---
name: DEFAULT_DATE [3181,3193]
name: DEFAULT_DATE [3181,3193]
===
match
---
name: task_a_0 [28096,28104]
name: task_a_0 [28482,28490]
===
match
---
assert_stmt [17819,17875]
assert_stmt [17819,17875]
===
match
---
simple_stmt [11344,11710]
simple_stmt [11344,11710]
===
match
---
operator: = [13267,13268]
operator: = [13267,13268]
===
match
---
operator: , [2269,2270]
operator: , [2269,2270]
===
match
---
name: task_id [8927,8934]
name: task_id [8927,8934]
===
match
---
name: dag_id [21627,21633]
name: dag_id [21627,21633]
===
match
---
name: clear_db_runs [21919,21932]
name: clear_db_runs [21919,21932]
===
match
---
name: failed_states [4314,4327]
name: failed_states [4314,4327]
===
match
---
parameters [10313,10319]
parameters [10313,10319]
===
match
---
arglist [28990,29120]
arglist [29376,29506]
===
match
---
operator: , [9289,9290]
operator: , [9289,9290]
===
match
---
return_stmt [29469,29483]
return_stmt [29855,29869]
===
match
---
name: external_dag_id [13101,13116]
name: external_dag_id [13101,13116]
===
match
---
argument [19140,19167]
argument [19140,19167]
===
match
---
argument [18872,18891]
argument [18872,18891]
===
match
---
name: DEFAULT_DATE [17040,17052]
name: DEFAULT_DATE [17040,17052]
===
match
---
name: ExternalTaskMarker [17465,17483]
name: ExternalTaskMarker [17465,17483]
===
match
---
atom_expr [3739,3764]
atom_expr [3739,3764]
===
match
---
name: external_dag_id [10459,10474]
name: external_dag_id [10459,10474]
===
match
---
name: timedelta [24163,24172]
name: timedelta [24549,24558]
===
match
---
trailer [28830,28895]
trailer [29216,29281]
===
match
---
suite [29408,29460]
suite [29794,29846]
===
match
---
atom [17241,17260]
atom [17241,17260]
===
match
---
simple_stmt [17662,17726]
simple_stmt [17662,17726]
===
match
---
trailer [26327,26354]
trailer [26713,26740]
===
match
---
trailer [8017,8132]
trailer [8017,8132]
===
match
---
operator: @ [31538,31539]
operator: @ [31924,31925]
===
match
---
operator: = [11251,11252]
operator: = [11251,11252]
===
match
---
operator: = [26701,26702]
operator: = [27087,27088]
===
match
---
simple_stmt [27874,27919]
simple_stmt [28260,28305]
===
match
---
name: get_dag [24947,24954]
name: get_dag [25333,25340]
===
match
---
argument [10398,10445]
argument [10398,10445]
===
match
---
operator: , [13327,13328]
operator: , [13327,13328]
===
match
---
argument [3449,3476]
argument [3449,3476]
===
match
---
atom_expr [6010,6016]
atom_expr [6010,6016]
===
match
---
trailer [19818,19826]
trailer [19818,19826]
===
match
---
name: DEFAULT_DATE [6901,6913]
name: DEFAULT_DATE [6901,6913]
===
match
---
name: external_dag_id [15495,15510]
name: external_dag_id [15495,15510]
===
match
---
operator: , [2000,2001]
operator: , [2000,2001]
===
match
---
name: dry_run [23074,23081]
name: dry_run [23460,23467]
===
match
---
name: dag_1 [19234,19239]
name: dag_1 [19234,19239]
===
match
---
operator: } [28463,28464]
operator: } [28849,28850]
===
match
---
name: airflow [1308,1315]
name: airflow [1308,1315]
===
match
---
argument [3170,3193]
argument [3170,3193]
===
match
---
name: seconds [9837,9844]
name: seconds [9837,9844]
===
match
---
with_stmt [29831,29950]
with_stmt [30217,30336]
===
match
---
parameters [22758,22780]
parameters [23144,23166]
===
match
---
string: """     Tests clearing across multiple DAGs that have cyclic dependencies. AirflowException should be     raised.     """ [29570,29691]
string: """     Tests clearing across multiple DAGs that have cyclic dependencies. AirflowException should be     raised.     """ [29956,30077]
===
match
---
operator: = [20227,20228]
operator: = [20227,20228]
===
match
---
atom_expr [12491,12568]
atom_expr [12491,12568]
===
match
---
operator: + [12918,12919]
operator: + [12918,12919]
===
match
---
atom_expr [1960,1971]
atom_expr [1960,1971]
===
match
---
simple_stmt [26210,26249]
simple_stmt [26596,26635]
===
match
---
name: external_dag_id [19115,19130]
name: external_dag_id [19115,19130]
===
match
---
atom_expr [26820,26844]
atom_expr [27206,27230]
===
match
---
string: 'test_external_task_sensor_check' [4613,4646]
string: 'test_external_task_sensor_check' [4613,4646]
===
match
---
expr_stmt [33965,34014]
expr_stmt [34351,34400]
===
match
---
operator: = [2193,2194]
operator: = [2193,2194]
===
match
---
name: test_external_task_marker_cyclic_deep [29511,29548]
name: test_external_task_marker_cyclic_deep [29897,29934]
===
match
---
name: test_external_task_marker_exception [26414,26449]
name: test_external_task_marker_exception [26800,26835]
===
match
---
trailer [6009,6037]
trailer [6009,6037]
===
match
---
name: TestExternalTaskSensor [1888,1910]
name: TestExternalTaskSensor [1888,1910]
===
match
---
operator: , [9981,9982]
operator: , [9981,9982]
===
match
---
operator: { [29007,29008]
operator: { [29393,29394]
===
match
---
operator: , [22354,22355]
operator: , [22354,22355]
===
match
---
operator: = [4717,4718]
operator: = [4717,4718]
===
match
---
trailer [8856,8858]
trailer [8856,8858]
===
match
---
operator: = [34909,34910]
operator: = [35295,35296]
===
match
---
name: int [27644,27647]
name: int [28030,28033]
===
match
---
name: dag [29437,29440]
name: dag [29823,29826]
===
match
---
name: dag [22509,22512]
name: dag [22895,22898]
===
match
---
name: ti [34512,34514]
name: ti [34898,34900]
===
match
---
param [21968,21976]
param [21968,21976]
===
match
---
trailer [2232,2284]
trailer [2232,2284]
===
match
---
name: self [4859,4863]
name: self [4859,4863]
===
match
---
operator: , [7592,7593]
operator: , [7592,7593]
===
match
---
arglist [4175,4365]
arglist [4175,4365]
===
match
---
operator: , [2530,2531]
operator: , [2530,2531]
===
match
---
string: 'test_external_task_sensor_multiple_arg_fn' [12239,12282]
string: 'test_external_task_sensor_multiple_arg_fn' [12239,12282]
===
match
---
operator: = [2142,2143]
operator: = [2142,2143]
===
match
---
atom_expr [28827,28895]
atom_expr [29213,29281]
===
match
---
expr_stmt [19234,19303]
expr_stmt [19234,19303]
===
match
---
trailer [17700,17719]
trailer [17700,17719]
===
match
---
operator: = [30240,30241]
operator: = [30626,30627]
===
match
---
with_stmt [3734,4042]
with_stmt [3734,4042]
===
match
---
simple_stmt [26778,26816]
simple_stmt [27164,27202]
===
match
---
operator: = [15632,15633]
operator: = [15632,15633]
===
match
---
name: db [1608,1610]
name: db [1608,1610]
===
match
---
operator: = [2559,2560]
operator: = [2559,2560]
===
match
---
operator: = [9221,9222]
operator: = [9221,9222]
===
match
---
trailer [2861,2878]
trailer [2861,2878]
===
match
---
name: test_external_dag_sensor [6687,6711]
name: test_external_dag_sensor [6687,6711]
===
match
---
trailer [24488,24536]
trailer [24874,24922]
===
match
---
trailer [5626,5658]
trailer [5626,5658]
===
match
---
name: date [17053,17057]
name: date [17053,17057]
===
match
---
name: end_date [16531,16539]
name: end_date [16531,16539]
===
match
---
suite [8557,9031]
suite [8557,9031]
===
match
---
operator: , [18891,18892]
operator: , [18891,18892]
===
match
---
atom_expr [22616,22631]
atom_expr [23002,23017]
===
match
---
operator: = [19413,19414]
operator: = [19413,19414]
===
match
---
atom_expr [6838,6973]
atom_expr [6838,6973]
===
match
---
trailer [23312,23318]
trailer [23698,23704]
===
match
---
operator: , [3092,3093]
operator: , [3092,3093]
===
match
---
argument [9258,9289]
argument [9258,9289]
===
match
---
simple_stmt [25222,25316]
simple_stmt [25608,25702]
===
match
---
operator: , [15249,15250]
operator: , [15249,15250]
===
match
---
name: day_2 [24445,24450]
name: day_2 [24831,24836]
===
match
---
operator: } [17134,17135]
operator: } [17134,17135]
===
match
---
arith_expr [7524,7549]
arith_expr [7524,7549]
===
match
---
arglist [2233,2283]
arglist [2233,2283]
===
match
---
name: dag_bag [29739,29746]
name: dag_bag [30125,30132]
===
match
---
atom_expr [10657,10733]
atom_expr [10657,10733]
===
match
---
name: task [34444,34448]
name: task [34830,34834]
===
match
---
trailer [12122,12140]
trailer [12122,12140]
===
match
---
atom_expr [6987,7172]
atom_expr [6987,7172]
===
match
---
simple_stmt [30274,30332]
simple_stmt [30660,30718]
===
match
---
name: dag [9572,9575]
name: dag [9572,9575]
===
match
---
parameters [31649,31667]
parameters [32035,32053]
===
match
---
name: ti [22565,22567]
name: ti [22951,22953]
===
match
---
argument [9303,9351]
argument [9303,9351]
===
match
---
operator: = [16397,16398]
operator: = [16397,16398]
===
match
---
simple_stmt [30139,30167]
simple_stmt [30525,30553]
===
match
---
name: task_id [20215,20222]
name: task_id [20215,20222]
===
match
---
name: log [6013,6016]
name: log [6013,6016]
===
match
---
name: end_date [16082,16090]
name: end_date [16082,16090]
===
match
---
name: ExternalTaskSensor [5672,5690]
name: ExternalTaskSensor [5672,5690]
===
match
---
funcdef [4047,4461]
funcdef [4047,4461]
===
match
---
argument [31097,31116]
argument [31483,31502]
===
match
---
argument [28990,29015]
argument [29376,29401]
===
match
---
name: dag_bag_ext [25533,25544]
name: dag_bag_ext [25919,25930]
===
match
---
argument [19932,19959]
argument [19932,19959]
===
match
---
name: dags [29403,29407]
name: dags [29789,29793]
===
match
---
name: DEFAULT_DATE [3204,3216]
name: DEFAULT_DATE [3204,3216]
===
match
---
name: pytest [26979,26985]
name: pytest [27365,27371]
===
match
---
name: dag_bag [22182,22189]
name: dag_bag [22182,22189]
===
match
---
parameters [21967,22019]
parameters [21967,22019]
===
match
---
atom_expr [21919,21934]
atom_expr [21919,21934]
===
match
---
operator: = [7130,7131]
operator: = [7130,7131]
===
match
---
operator: , [19791,19792]
operator: , [19791,19792]
===
match
---
atom_expr [28135,28150]
atom_expr [28521,28536]
===
match
---
number: 30 [34949,34951]
number: 30 [35335,35337]
===
match
---
name: default_args [2130,2142]
name: default_args [2130,2142]
===
match
---
argument [12499,12522]
argument [12499,12522]
===
match
---
suite [4966,5060]
suite [4966,5060]
===
match
---
name: schedule_interval [28872,28889]
name: schedule_interval [29258,29275]
===
match
---
string: 'child_dag_1' [25153,25166]
string: 'child_dag_1' [25539,25552]
===
match
---
atom_expr [6436,6445]
atom_expr [6436,6445]
===
match
---
name: head [33693,33697]
name: head [34079,34083]
===
match
---
name: clear_tasks [30280,30291]
name: clear_tasks [30666,30677]
===
match
---
operator: = [23418,23419]
operator: = [23804,23805]
===
match
---
simple_stmt [31673,31922]
simple_stmt [32059,32308]
===
match
---
name: TestExternalTaskMarker [17145,17167]
name: TestExternalTaskMarker [17145,17167]
===
match
---
name: external_task_id [16347,16363]
name: external_task_id [16347,16363]
===
match
---
simple_stmt [16050,16127]
simple_stmt [16050,16127]
===
match
---
argument [15967,15979]
argument [15967,15979]
===
match
---
operator: = [4401,4402]
operator: = [4401,4402]
===
match
---
name: task_with_failure [10181,10198]
name: task_with_failure [10181,10198]
===
match
---
operator: , [6801,6802]
operator: , [6801,6802]
===
match
---
trailer [25353,25360]
trailer [25739,25746]
===
match
---
name: execution_delta [13789,13804]
name: execution_delta [13789,13804]
===
match
---
atom_expr [16212,16439]
atom_expr [16212,16439]
===
match
---
name: ExternalTaskSensor [28954,28972]
name: ExternalTaskSensor [29340,29358]
===
match
---
atom_expr [20379,20417]
atom_expr [20379,20417]
===
match
---
string: 'other_dag' [6743,6754]
string: 'other_dag' [6743,6754]
===
match
---
name: external_dag_id [2544,2559]
name: external_dag_id [2544,2559]
===
match
---
argument [8056,8100]
argument [8056,8100]
===
match
---
number: 0 [11092,11093]
number: 0 [11092,11093]
===
match
---
trailer [10384,10648]
trailer [10384,10648]
===
match
---
name: task_b_2 [20012,20020]
name: task_b_2 [20012,20020]
===
match
---
atom_expr [4859,4902]
atom_expr [4859,4902]
===
match
---
arglist [16244,16429]
arglist [16244,16429]
===
match
---
name: bag_dag [33814,33821]
name: bag_dag [34200,34207]
===
match
---
name: AirflowSensorTimeout [10146,10166]
name: AirflowSensorTimeout [10146,10166]
===
match
---
atom_expr [22551,22561]
atom_expr [22937,22947]
===
match
---
operator: , [9244,9245]
operator: , [9244,9245]
===
match
---
trailer [16230,16439]
trailer [16230,16439]
===
match
---
name: task_id [19491,19498]
name: task_id [19491,19498]
===
match
---
operator: = [19580,19581]
operator: = [19580,19581]
===
match
---
operator: == [17935,17937]
operator: == [17935,17937]
===
match
---
parameters [3718,3724]
parameters [3718,3724]
===
match
---
name: dt [9817,9819]
name: dt [9817,9819]
===
match
---
operator: = [23214,23215]
operator: = [23600,23601]
===
match
---
atom_expr [33531,33560]
atom_expr [33917,33946]
===
match
---
trailer [26714,26722]
trailer [27100,27108]
===
match
---
string: "task_b_0" [26804,26814]
string: "task_b_0" [27190,27200]
===
match
---
argument [31118,31131]
argument [31504,31517]
===
match
---
operator: = [28508,28509]
operator: = [28894,28895]
===
match
---
arglist [19246,19302]
arglist [19246,19302]
===
match
---
trailer [5251,5258]
trailer [5251,5258]
===
match
---
argument [7937,7946]
argument [7937,7946]
===
match
---
name: pytest [18047,18053]
name: pytest [18047,18053]
===
match
---
trailer [26945,26975]
trailer [27331,27361]
===
match
---
simple_stmt [10023,10118]
simple_stmt [10023,10118]
===
match
---
operator: = [19498,19499]
operator: = [19498,19499]
===
match
---
name: clear_db_runs [1618,1631]
name: clear_db_runs [1618,1631]
===
match
---
number: 3 [21441,21442]
number: 3 [21441,21442]
===
match
---
name: provide_session [1413,1428]
name: provide_session [1413,1428]
===
match
---
name: dag [10634,10637]
name: dag [10634,10637]
===
match
---
arglist [10203,10271]
arglist [10203,10271]
===
match
---
operator: = [15121,15122]
operator: = [15121,15122]
===
match
---
testlist_comp [16921,16930]
testlist_comp [16921,16930]
===
match
---
string: "task_a_3" [20147,20157]
string: "task_a_3" [20147,20157]
===
match
---
name: self [17219,17223]
name: self [17219,17223]
===
match
---
argument [25299,25314]
argument [25685,25700]
===
match
---
operator: = [13758,13759]
operator: = [13758,13759]
===
match
---
simple_stmt [31222,31495]
simple_stmt [31608,31881]
===
match
---
argument [13304,13327]
argument [13304,13327]
===
match
---
atom_expr [19810,19826]
atom_expr [19810,19826]
===
match
---
trailer [15372,15384]
trailer [15372,15384]
===
match
---
atom_expr [22861,22892]
atom_expr [23247,23278]
===
match
---
parameters [33931,33959]
parameters [34317,34345]
===
match
---
argument [2956,3006]
argument [2956,3006]
===
match
---
name: DEV_NULL [27696,27704]
name: DEV_NULL [28082,28090]
===
match
---
operator: = [15782,15783]
operator: = [15782,15783]
===
match
---
atom_expr [18865,18916]
atom_expr [18865,18916]
===
match
---
name: _factory [27628,27636]
name: _factory [28014,28022]
===
match
---
simple_stmt [20026,20096]
simple_stmt [20026,20096]
===
match
---
operator: = [14918,14919]
operator: = [14918,14919]
===
match
---
operator: = [9552,9553]
operator: = [9552,9553]
===
match
---
operator: = [7152,7153]
operator: = [7152,7153]
===
match
---
operator: = [22339,22340]
operator: = [22339,22340]
===
match
---
name: airflow [876,883]
name: airflow [876,883]
===
match
---
name: ExternalTaskSensor [16660,16678]
name: ExternalTaskSensor [16660,16678]
===
match
---
atom [14406,14420]
atom [14406,14420]
===
match
---
operator: = [17379,17380]
operator: = [17379,17380]
===
match
---
string: 'time_sensor_check_alternate' [1759,1788]
string: 'time_sensor_check_alternate' [1759,1788]
===
match
---
name: clear_db_runs [21027,21040]
name: clear_db_runs [21027,21040]
===
match
---
name: dag_bag [21906,21913]
name: dag_bag [21906,21913]
===
match
---
name: strftime [12939,12947]
name: strftime [12939,12947]
===
match
---
name: agg_dag [31181,31188]
name: agg_dag [31567,31574]
===
match
---
argument [35033,35056]
argument [35419,35442]
===
match
---
name: task_a_0 [25942,25950]
name: task_a_0 [26328,26336]
===
match
---
name: DEFAULT_DATE [35007,35019]
name: DEFAULT_DATE [35393,35405]
===
match
---
operator: , [19534,19535]
operator: , [19534,19535]
===
match
---
trailer [29775,29784]
trailer [30161,30170]
===
match
---
name: head [33296,33300]
name: head [33682,33686]
===
match
---
operator: , [16806,16807]
operator: , [16806,16807]
===
match
---
simple_stmt [25551,25697]
simple_stmt [25937,26083]
===
match
---
operator: , [21365,21366]
operator: , [21365,21366]
===
match
---
simple_stmt [22616,22632]
simple_stmt [23002,23018]
===
match
---
operator: , [24203,24204]
operator: , [24589,24590]
===
match
---
operator: , [14871,14872]
operator: , [14871,14872]
===
match
---
string: "{{ macros.ds_add(ds, -1 * %s) }}" [31420,31454]
string: "{{ macros.ds_add(ds, -1 * %s) }}" [31806,31840]
===
match
---
trailer [26295,26300]
trailer [26681,26686]
===
match
---
name: run [4387,4390]
name: run [4387,4390]
===
match
---
import_as_names [891,911]
import_as_names [891,911]
===
match
---
operator: , [12545,12546]
operator: , [12545,12546]
===
match
---
operator: = [3555,3556]
operator: = [3555,3556]
===
match
---
comparison [32348,32445]
comparison [32734,32831]
===
match
---
suite [10778,11861]
suite [10778,11861]
===
match
---
trailer [8248,8252]
trailer [8248,8252]
===
match
---
name: range [34055,34060]
name: range [34441,34446]
===
match
---
decorators [31538,31605]
decorators [31924,31991]
===
match
---
name: schedule_interval [30849,30866]
name: schedule_interval [31235,31252]
===
match
---
name: date_0 [25701,25707]
name: date_0 [26087,26093]
===
match
---
name: query [8609,8614]
name: query [8609,8614]
===
match
---
decorated [26978,29505]
decorated [27364,29891]
===
match
---
argument [14482,14494]
argument [14482,14494]
===
match
---
arglist [10664,10732]
arglist [10664,10732]
===
match
---
trailer [17898,17934]
trailer [17898,17934]
===
match
---
arglist [8270,8361]
arglist [8270,8361]
===
match
---
name: delta [32072,32077]
name: delta [32458,32463]
===
match
---
suite [4097,4461]
suite [4097,4461]
===
match
---
trailer [26348,26353]
trailer [26734,26739]
===
match
---
operator: >> [20313,20315]
operator: >> [20313,20315]
===
match
---
operator: = [30866,30867]
operator: = [31252,31253]
===
match
---
name: TI [8615,8617]
name: TI [8615,8617]
===
match
---
simple_stmt [28501,28734]
simple_stmt [28887,29120]
===
match
---
name: start_date [28185,28195]
name: start_date [28571,28581]
===
match
---
operator: , [13940,13941]
operator: , [13940,13941]
===
match
---
dotted_name [32449,32463]
dotted_name [32835,32849]
===
match
---
simple_stmt [1171,1252]
simple_stmt [1171,1252]
===
match
---
argument [11213,11234]
argument [11213,11234]
===
match
---
name: airflow [1257,1264]
name: airflow [1257,1264]
===
match
---
name: ti_a_0 [23815,23821]
name: ti_a_0 [24201,24207]
===
match
---
operator: = [5670,5671]
operator: = [5670,5671]
===
match
---
fstring [28399,28411]
fstring [28785,28797]
===
match
---
name: execution_date [24205,24219]
name: execution_date [24591,24605]
===
match
---
atom_expr [30560,30570]
atom_expr [30946,30956]
===
match
---
name: TEST_TASK_ID [2602,2614]
name: TEST_TASK_ID [2602,2614]
===
match
---
number: 3 [28713,28714]
number: 3 [29099,29100]
===
match
---
operator: = [34252,34253]
operator: = [34638,34639]
===
match
---
argument [27685,27704]
argument [28071,28090]
===
match
---
decorated [31538,32446]
decorated [31924,32832]
===
match
---
name: execution_date [34253,34267]
name: execution_date [34639,34653]
===
match
---
name: TEST_TASK_ID [11022,11034]
name: TEST_TASK_ID [11022,11034]
===
match
---
argument [6018,6036]
argument [6018,6036]
===
match
---
trailer [22874,22890]
trailer [23260,23276]
===
match
---
argument [34929,34944]
argument [35315,35330]
===
match
---
trailer [26401,26406]
trailer [26787,26792]
===
match
---
operator: } [2092,2093]
operator: } [2092,2093]
===
match
---
expr_stmt [1789,1811]
expr_stmt [1789,1811]
===
match
---
operator: , [13679,13680]
operator: , [13679,13680]
===
match
---
atom [30478,30499]
atom [30864,30885]
===
match
---
name: days [12930,12934]
name: days [12930,12934]
===
match
---
name: external_task_ids [14840,14857]
name: external_task_ids [14840,14857]
===
match
---
shift_expr [28750,28766]
shift_expr [29136,29152]
===
match
---
simple_stmt [29147,29354]
simple_stmt [29533,29740]
===
match
---
string: "dag_1" [19246,19253]
string: "dag_1" [19246,19253]
===
match
---
trailer [30810,30876]
trailer [31196,31262]
===
match
---
import_from [1171,1251]
import_from [1171,1251]
===
match
---
name: TI [8664,8666]
name: TI [8664,8666]
===
match
---
name: TEST_TASK_ID [14358,14370]
name: TEST_TASK_ID [14358,14370]
===
match
---
assert_stmt [16993,17061]
assert_stmt [16993,17061]
===
match
---
name: fixture [32456,32463]
name: fixture [32842,32849]
===
match
---
name: default_args [9087,9099]
name: default_args [9087,9099]
===
match
---
operator: = [11122,11123]
operator: = [11122,11123]
===
match
---
name: TEST_TASK_ID_ALTERNATE [5635,5657]
name: TEST_TASK_ID_ALTERNATE [5635,5657]
===
match
---
name: execution_date [24250,24264]
name: execution_date [24636,24650]
===
match
---
operator: , [3648,3649]
operator: , [3648,3649]
===
match
---
name: TI [8179,8181]
name: TI [8179,8181]
===
match
---
name: dag_0 [18922,18927]
name: dag_0 [18922,18927]
===
match
---
simple_stmt [11783,11861]
simple_stmt [11783,11861]
===
match
---
fstring_start: f" [28399,28401]
fstring_start: f" [28785,28787]
===
match
---
trailer [22524,22532]
trailer [22910,22918]
===
match
---
name: allowed_states [9880,9894]
name: allowed_states [9880,9894]
===
match
---
name: DAG [18930,18933]
name: DAG [18930,18933]
===
match
---
trailer [24621,24629]
trailer [25007,25015]
===
match
---
trailer [14153,14160]
trailer [14153,14160]
===
match
---
operator: = [22161,22162]
operator: = [22161,22162]
===
match
---
string: "dag_0" [30218,30225]
string: "dag_0" [30604,30611]
===
match
---
name: test_clear_multiple_external_task_marker [31609,31649]
name: test_clear_multiple_external_task_marker [31995,32035]
===
match
---
name: test_external_task_sensor_error_delta_and_fn [13383,13427]
name: test_external_task_sensor_error_delta_and_fn [13383,13427]
===
match
---
string: "task_b_1" [30457,30467]
string: "task_b_1" [30843,30853]
===
match
---
name: task_b [28501,28507]
name: task_b [28887,28893]
===
match
---
name: state [22774,22779]
name: state [23160,23165]
===
match
---
string: """     Create a DagBag containing one DAG, with task "head" depending on task "tail" of the     previous execution_date.      20200501     20200502                 20200510     +------+     +------+                 +------+     | head |    -->head |    -->         -->head |     |  |   |   / |  |   |   /           / |  |   |     |  v   |  /  |  v   |  /           /  |  v   |     | body | /   | body | /     ...   /   | body |     |  |   |/    |  |   |/           /    |  |   |     |  v   /     |  v   /           /     |  v   |     | tail/|     | tail/|          /      | tail |     +------+     +------+                 +------+     """ [32493,33133]
string: """     Create a DagBag containing one DAG, with task "head" depending on task "tail" of the     previous execution_date.      20200501     20200502                 20200510     +------+     +------+                 +------+     | head |    -->head |    -->         -->head |     |  |   |   / |  |   |   /           / |  |   |     |  v   |  /  |  v   |  /           /  |  v   |     | body | /   | body | /     ...   /   | body |     |  |   |/    |  |   |/           /    |  |   |     |  v   /     |  v   /           /     |  v   |     | tail/|     | tail/|          /      | tail |     +------+     +------+                 +------+     """ [32879,33519]
===
match
---
trailer [23814,23834]
trailer [24200,24220]
===
match
---
operator: , [3047,3048]
operator: , [3047,3048]
===
match
---
suite [24406,24581]
suite [24792,24967]
===
match
---
trailer [24954,24970]
trailer [25340,25356]
===
match
---
operator: = [14405,14406]
operator: = [14405,14406]
===
match
---
name: session [8601,8608]
name: session [8601,8608]
===
match
---
trailer [8614,8618]
trailer [8614,8618]
===
match
---
simple_stmt [24115,24136]
simple_stmt [24501,24522]
===
match
---
decorator [31538,31563]
decorator [31924,31949]
===
match
---
atom_expr [2143,2152]
atom_expr [2143,2152]
===
match
---
name: DEFAULT_DATE [16091,16103]
name: DEFAULT_DATE [16091,16103]
===
match
---
argument [16244,16285]
argument [16244,16285]
===
match
---
argument [13928,13940]
argument [13928,13940]
===
match
---
argument [19367,19395]
argument [19367,19395]
===
match
---
name: DEFAULT_DATE [6136,6148]
name: DEFAULT_DATE [6136,6148]
===
match
---
argument [16531,16552]
argument [16531,16552]
===
match
---
name: dag_0 [23606,23611]
name: dag_0 [23992,23997]
===
match
---
import_from [1038,1072]
import_from [1038,1072]
===
match
---
operator: = [6158,6159]
operator: = [6158,6159]
===
match
---
operator: - [28461,28462]
operator: - [28847,28848]
===
match
---
operator: @ [1814,1815]
operator: @ [1814,1815]
===
match
---
operator: = [9613,9614]
operator: = [9613,9614]
===
match
---
simple_stmt [20423,20437]
simple_stmt [20423,20437]
===
match
---
name: session [34553,34560]
name: session [34939,34946]
===
match
---
param [3719,3723]
param [3719,3723]
===
match
---
operator: = [28195,28196]
operator: = [28581,28582]
===
match
---
simple_stmt [29912,29950]
simple_stmt [30298,30336]
===
match
---
name: ExternalTaskSensor [15078,15096]
name: ExternalTaskSensor [15078,15096]
===
match
---
operator: , [28845,28846]
operator: , [29231,29232]
===
match
---
argument [29192,29217]
argument [29578,29603]
===
match
---
simple_stmt [21919,21935]
simple_stmt [21919,21935]
===
match
---
name: dag [22175,22178]
name: dag [22175,22178]
===
match
---
operator: = [13238,13239]
operator: = [13238,13239]
===
match
---
name: raises [4934,4940]
name: raises [4934,4940]
===
match
---
name: include_downstream [23269,23287]
name: include_downstream [23655,23673]
===
match
---
argument [21787,21804]
argument [21787,21804]
===
match
---
operator: = [33237,33238]
operator: = [33623,33624]
===
match
---
name: settings [8152,8160]
name: settings [8152,8160]
===
match
---
name: ExternalTaskMarker [27942,27960]
name: ExternalTaskMarker [28328,28346]
===
match
---
name: run [12495,12498]
name: run [12495,12498]
===
match
---
trailer [2441,2443]
trailer [2441,2443]
===
match
---
decorated [1814,1880]
decorated [1814,1880]
===
match
---
name: self [5994,5998]
name: self [5994,5998]
===
match
---
string: "task_a_1" [19157,19167]
string: "task_a_1" [19157,19167]
===
match
---
name: TaskInstance [8184,8196]
name: TaskInstance [8184,8196]
===
match
---
operator: + [9825,9826]
operator: + [9825,9826]
===
match
---
suite [14555,14976]
suite [14555,14976]
===
match
---
name: exceptions [891,901]
name: exceptions [891,901]
===
match
---
funcdef [30605,31536]
funcdef [30991,31922]
===
match
---
operator: , [19649,19650]
operator: , [19649,19650]
===
match
---
name: DagBag [1009,1015]
name: DagBag [1009,1015]
===
match
---
name: start_date [18943,18953]
name: start_date [18943,18953]
===
match
---
trailer [30256,30268]
trailer [30642,30654]
===
match
---
operator: = [2601,2602]
operator: = [2601,2602]
===
match
---
dotted_name [1043,1061]
dotted_name [1043,1061]
===
match
---
return_stmt [22720,22730]
return_stmt [23106,23116]
===
match
---
atom_expr [34175,34185]
atom_expr [34561,34571]
===
match
---
operator: , [3618,3619]
operator: , [3618,3619]
===
match
---
name: end_date [10689,10697]
name: end_date [10689,10697]
===
match
---
operator: , [21838,21839]
operator: , [21838,21839]
===
match
---
operator: = [12311,12312]
operator: = [12311,12312]
===
match
---
suite [11919,12569]
suite [11919,12569]
===
match
---
name: serialized_op [17662,17675]
name: serialized_op [17662,17675]
===
match
---
name: dag_id [31336,31342]
name: dag_id [31722,31728]
===
match
---
operator: , [16368,16369]
operator: , [16368,16369]
===
match
---
operator: = [21056,21057]
operator: = [21056,21057]
===
match
---
trailer [4022,4026]
trailer [4022,4026]
===
match
---
expr_stmt [30729,30790]
expr_stmt [31115,31176]
===
match
---
name: external_dag_id [31310,31325]
name: external_dag_id [31696,31711]
===
match
---
arglist [27978,28069]
arglist [28364,28455]
===
match
---
name: seconds [9410,9417]
name: seconds [9410,9417]
===
match
---
name: dag_bag_ext [25860,25871]
name: dag_bag_ext [26246,26257]
===
match
---
operator: , [33250,33251]
operator: , [33636,33637]
===
match
---
trailer [7882,7974]
trailer [7882,7974]
===
match
---
operator: == [5325,5327]
operator: == [5325,5327]
===
match
---
operator: , [29866,29867]
operator: , [30252,30253]
===
match
---
name: n [28180,28181]
name: n [28566,28567]
===
match
---
argument [28185,28208]
argument [28571,28594]
===
match
---
operator: , [3117,3118]
operator: , [3117,3118]
===
match
---
atom_expr [14186,14509]
atom_expr [14186,14509]
===
match
---
operator: , [9929,9930]
operator: , [9929,9930]
===
match
---
operator: , [28870,28871]
operator: , [29256,29257]
===
match
---
name: self [4356,4360]
name: self [4356,4360]
===
match
---
param [23005,23013]
param [23391,23399]
===
match
---
name: dag_bag [30729,30736]
name: dag_bag [31115,31122]
===
match
---
argument [5575,5595]
argument [5575,5595]
===
match
---
operator: = [27940,27941]
operator: = [28326,28327]
===
match
---
name: dag_0 [21211,21216]
name: dag_0 [21211,21216]
===
match
---
argument [7948,7964]
argument [7948,7964]
===
match
---
argument [33822,33829]
argument [34208,34215]
===
match
---
name: dag [10625,10628]
name: dag [10625,10628]
===
match
---
operator: == [30538,30540]
operator: == [30924,30926]
===
match
---
name: serialized_op [17796,17809]
name: serialized_op [17796,17809]
===
match
---
name: tis_date_0 [26140,26150]
name: tis_date_0 [26526,26536]
===
match
---
simple_stmt [32493,33134]
simple_stmt [32879,33520]
===
match
---
string: "['time_sensor_check', 'time_sensor_check_alternate'] in DAG " [6561,6623]
string: "['time_sensor_check', 'time_sensor_check_alternate'] in DAG " [6561,6623]
===
match
---
operator: = [23612,23613]
operator: = [23998,23999]
===
match
---
atom_expr [17073,17103]
atom_expr [17073,17103]
===
match
---
simple_stmt [9040,9061]
simple_stmt [9040,9061]
===
match
---
param [12614,12618]
param [12614,12618]
===
match
---
string: "failed" [4329,4337]
string: "failed" [4329,4337]
===
match
---
name: dag_bag [18855,18862]
name: dag_bag [18855,18862]
===
match
---
operator: , [21633,21634]
operator: , [21633,21634]
===
match
---
operator: , [23376,23377]
operator: , [23762,23763]
===
match
---
testlist_comp [9395,9438]
testlist_comp [9395,9438]
===
match
---
operator: , [1023,1024]
operator: , [1023,1024]
===
match
---
operator: = [28857,28858]
operator: = [29243,29244]
===
match
---
arglist [7721,7818]
arglist [7721,7818]
===
match
---
atom_expr [9615,10013]
atom_expr [9615,10013]
===
match
---
name: values [24397,24403]
name: values [24783,24789]
===
match
---
simple_stmt [31018,31065]
simple_stmt [31404,31451]
===
match
---
trailer [6120,6124]
trailer [6120,6124]
===
match
---
simple_stmt [2033,2094]
simple_stmt [2033,2094]
===
match
---
operator: = [28067,28068]
operator: = [28453,28454]
===
match
---
simple_stmt [29570,29692]
simple_stmt [29956,30078]
===
match
---
string: "daily_tas" [31105,31116]
string: "daily_tas" [31491,31502]
===
match
---
name: timedelta [7636,7645]
name: timedelta [7636,7645]
===
match
---
number: 2 [19581,19582]
number: 2 [19581,19582]
===
match
---
simple_stmt [2420,2444]
simple_stmt [2420,2444]
===
match
---
operator: = [9950,9951]
operator: = [9950,9951]
===
match
---
operator: = [34448,34449]
operator: = [34834,34835]
===
match
---
name: n [28616,28617]
name: n [29002,29003]
===
match
---
name: day_1 [21177,21182]
name: day_1 [21177,21182]
===
match
---
operator: , [9575,9576]
operator: , [9575,9576]
===
match
---
name: task [23254,23258]
name: task [23640,23644]
===
match
---
operator: , [11643,11644]
operator: , [11643,11644]
===
match
---
trailer [26864,26871]
trailer [27250,27257]
===
match
---
argument [14840,14886]
argument [14840,14886]
===
match
---
name: agg_dag [32348,32355]
name: agg_dag [32734,32741]
===
match
---
trailer [24598,24600]
trailer [24984,24986]
===
match
---
name: seconds [8806,8813]
name: seconds [8806,8813]
===
match
---
arglist [26275,26300]
arglist [26661,26686]
===
match
---
name: end_date [13329,13337]
name: end_date [13329,13337]
===
match
---
name: bag_dag [31026,31033]
name: bag_dag [31412,31419]
===
match
---
operator: , [20157,20158]
operator: , [20157,20158]
===
match
---
simple_stmt [16823,16916]
simple_stmt [16823,16916]
===
match
---
name: DEFAULT_DATE [12533,12545]
name: DEFAULT_DATE [12533,12545]
===
match
---
operator: , [26957,26958]
operator: , [27343,27344]
===
match
---
operator: = [8150,8151]
operator: = [8150,8151]
===
match
---
trailer [19481,19599]
trailer [19481,19599]
===
match
---
name: dag_bag_head_tail [33976,33993]
name: dag_bag_head_tail [34362,34379]
===
match
---
operator: , [16402,16403]
operator: , [16402,16403]
===
match
---
operator: = [6737,6738]
operator: = [6737,6738]
===
match
---
operator: = [19102,19103]
operator: = [19102,19103]
===
match
---
name: pytest [863,869]
name: pytest [863,869]
===
match
---
operator: = [19983,19984]
operator: = [19983,19984]
===
match
---
name: op1 [11180,11183]
name: op1 [11180,11183]
===
match
---
trailer [21409,21411]
trailer [21409,21411]
===
match
---
expr_stmt [26736,26773]
expr_stmt [27122,27159]
===
match
---
operator: = [31180,31181]
operator: = [31566,31567]
===
match
---
trailer [22490,22508]
trailer [22876,22894]
===
match
---
parameters [16617,16628]
parameters [16617,16628]
===
match
---
number: 1 [28141,28142]
number: 1 [28527,28528]
===
match
---
operator: = [2111,2112]
operator: = [2111,2112]
===
match
---
trailer [6124,6194]
trailer [6124,6194]
===
match
---
trailer [15365,15372]
trailer [15365,15372]
===
match
---
parameters [13427,13433]
parameters [13427,13433]
===
match
---
operator: = [30805,30806]
operator: = [31191,31192]
===
match
---
expr_stmt [29752,29784]
expr_stmt [30138,30170]
===
match
---
name: dagrun_0_2 [25372,25382]
name: dagrun_0_2 [25758,25768]
===
match
---
import_name [856,869]
import_name [856,869]
===
match
---
operator: , [4769,4770]
operator: , [4769,4770]
===
match
---
operator: , [30362,30363]
operator: , [30748,30749]
===
match
---
atom [12914,12938]
atom [12914,12938]
===
match
---
operator: = [7903,7904]
operator: = [7903,7904]
===
match
---
argument [25004,25019]
argument [25390,25405]
===
match
---
trailer [12929,12937]
trailer [12929,12937]
===
match
---
name: schedule_interval [9111,9128]
name: schedule_interval [9111,9128]
===
match
---
simple_stmt [26253,26302]
simple_stmt [26639,26688]
===
match
---
name: TEST_DAG_ID [7524,7535]
name: TEST_DAG_ID [7524,7535]
===
match
---
name: daily_dag [31122,31131]
name: daily_dag [31508,31517]
===
match
---
trailer [24571,24579]
trailer [24957,24965]
===
match
---
trailer [21670,21678]
trailer [21670,21678]
===
match
---
operator: , [19138,19139]
operator: , [19138,19139]
===
match
---
string: 'parent_dag_0' [25054,25068]
string: 'parent_dag_0' [25440,25454]
===
match
---
simple_stmt [7837,7975]
simple_stmt [7837,7975]
===
match
---
operator: = [8813,8814]
operator: = [8813,8814]
===
match
---
fstring [28173,28183]
fstring [28559,28569]
===
match
---
trailer [30970,30978]
trailer [31356,31364]
===
match
---
suite [3765,4042]
suite [3765,4042]
===
match
---
atom_expr [26062,26118]
atom_expr [26448,26504]
===
match
---
name: execution_date_fn [9365,9382]
name: execution_date_fn [9365,9382]
===
match
---
operator: = [12934,12935]
operator: = [12934,12935]
===
match
---
atom [5292,5459]
atom [5292,5459]
===
match
---
string: 'ExternalTaskMarker' [17855,17875]
string: 'ExternalTaskMarker' [17855,17875]
===
match
---
name: test_time_sensor [14038,14054]
name: test_time_sensor [14038,14054]
===
match
---
argument [3195,3216]
argument [3195,3216]
===
match
---
fstring_expr [29109,29118]
fstring_expr [29495,29504]
===
match
---
operator: , [10687,10688]
operator: , [10687,10688]
===
match
---
suite [15385,15657]
suite [15385,15657]
===
match
---
name: ti_b_3_date_0 [26167,26180]
name: ti_b_3_date_0 [26553,26566]
===
match
---
argument [7646,7655]
argument [7646,7655]
===
match
---
string: 'task_external_with_failure' [8938,8966]
string: 'task_external_with_failure' [8938,8966]
===
match
---
atom_expr [23614,23642]
atom_expr [24000,24028]
===
match
---
name: task_id [31097,31104]
name: task_id [31483,31490]
===
match
---
name: task [31512,31516]
name: task [31898,31902]
===
match
---
name: task_a_3 [20304,20312]
name: task_a_3 [20304,20312]
===
match
---
simple_stmt [24926,25021]
simple_stmt [25312,25407]
===
match
---
name: task_a_0 [29789,29797]
name: task_a_0 [30175,30183]
===
match
---
name: DEFAULT_DATE [24123,24135]
name: DEFAULT_DATE [24509,24521]
===
match
---
with_item [28169,28240]
with_item [28555,28626]
===
match
---
atom_expr [2102,2110]
atom_expr [2102,2110]
===
match
---
trailer [2878,2910]
trailer [2878,2910]
===
match
---
string: 'success' [13900,13909]
string: 'success' [13900,13909]
===
match
---
atom [30509,30530]
atom [30895,30916]
===
match
---
atom_expr [34523,34548]
atom_expr [34909,34934]
===
match
---
trailer [25338,25344]
trailer [25724,25730]
===
match
---
simple_stmt [15738,15991]
simple_stmt [15738,15991]
===
match
---
param [2790,2794]
param [2790,2794]
===
match
---
arglist [15114,15330]
arglist [15114,15330]
===
match
---
yield_expr [31522,31535]
yield_expr [31908,31921]
===
match
---
arglist [4875,4901]
arglist [4875,4901]
===
match
---
name: dag_folder [18872,18882]
name: dag_folder [18872,18882]
===
match
---
fstring_start: f" [17033,17035]
fstring_start: f" [17033,17035]
===
match
---
argument [25201,25216]
argument [25587,25602]
===
match
---
atom_expr [5221,5245]
atom_expr [5221,5245]
===
match
---
simple_stmt [24140,24181]
simple_stmt [24526,24567]
===
match
---
trailer [19337,19447]
trailer [19337,19447]
===
match
---
string: "Some of the external tasks " [6515,6544]
string: "Some of the external tasks " [6515,6544]
===
match
---
name: agg_dag [31038,31045]
name: agg_dag [31424,31431]
===
match
---
name: task_id [4605,4612]
name: task_id [4605,4612]
===
match
---
funcdef [6683,7258]
funcdef [6683,7258]
===
match
---
operator: @ [30589,30590]
operator: @ [30975,30976]
===
match
---
operator: , [29015,29016]
operator: , [29401,29402]
===
match
---
atom_expr [2420,2443]
atom_expr [2420,2443]
===
match
---
name: task_id [5575,5582]
name: task_id [5575,5582]
===
match
---
trailer [25250,25265]
trailer [25636,25651]
===
match
---
name: op2 [11344,11347]
name: op2 [11344,11347]
===
match
---
name: default_args [6756,6768]
name: default_args [6756,6768]
===
match
---
trailer [17176,17185]
trailer [17176,17185]
===
match
---
name: timedelta [25751,25760]
name: timedelta [26137,26146]
===
match
---
operator: , [24722,24723]
operator: , [25108,25109]
===
match
---
argument [8090,8099]
argument [8090,8099]
===
match
---
string: "dag_3" [19923,19930]
string: "dag_3" [19923,19930]
===
match
---
operator: , [6778,6779]
operator: , [6778,6779]
===
match
---
trailer [20455,20457]
trailer [20455,20457]
===
match
---
fstring_expr [29209,29216]
fstring_expr [29595,29602]
===
match
---
trailer [15975,15979]
trailer [15975,15979]
===
match
---
name: daily_dag [31326,31335]
name: daily_dag [31712,31721]
===
match
---
name: external_dag_id [20159,20174]
name: external_dag_id [20159,20174]
===
match
---
atom [9468,9479]
atom [9468,9479]
===
match
---
operator: , [10710,10711]
operator: , [10710,10711]
===
match
---
operator: , [16103,16104]
operator: , [16103,16104]
===
match
---
simple_stmt [26736,26774]
simple_stmt [27122,27160]
===
match
---
suite [9006,9031]
suite [9006,9031]
===
match
---
operator: = [10979,10980]
operator: = [10979,10980]
===
match
---
argument [29437,29444]
argument [29823,29830]
===
match
---
operator: = [4245,4246]
operator: = [4245,4246]
===
match
---
name: dag_bag [21968,21975]
name: dag_bag [21968,21975]
===
match
---
operator: = [23055,23056]
operator: = [23441,23442]
===
match
---
string: "task_a_1" [28040,28050]
string: "task_a_1" [28426,28436]
===
match
---
name: body [33788,33792]
name: body [34174,34178]
===
match
---
operator: , [21411,21412]
operator: , [21411,21412]
===
match
---
suite [29565,29950]
suite [29951,30336]
===
match
---
operator: { [2045,2046]
operator: { [2045,2046]
===
match
---
atom [30447,30468]
atom [30833,30854]
===
match
---
name: mark [31571,31575]
name: mark [31957,31961]
===
match
---
name: external_task_id [29083,29099]
name: external_task_id [29469,29485]
===
match
---
name: end_date [26104,26112]
name: end_date [26490,26498]
===
match
---
atom_expr [9129,9149]
atom_expr [9129,9149]
===
match
---
string: 'test_external_task_sensor_check' [3822,3855]
string: 'test_external_task_sensor_check' [3822,3855]
===
match
---
name: test_external_task_sensor_templated [16582,16617]
name: test_external_task_sensor_templated [16582,16617]
===
match
---
name: DAG [21146,21149]
name: DAG [21146,21149]
===
match
---
string: "task_a_0" [30257,30267]
string: "task_a_0" [30643,30653]
===
match
---
name: TEST_DAG_ID [1669,1680]
name: TEST_DAG_ID [1669,1680]
===
match
---
atom_expr [9182,9586]
atom_expr [9182,9586]
===
match
---
name: DAG [28827,28830]
name: DAG [29213,29216]
===
match
---
atom_expr [23839,23880]
atom_expr [24225,24266]
===
match
---
number: 2 [26847,26848]
number: 2 [27233,27234]
===
match
---
atom_expr [14033,14056]
atom_expr [14033,14056]
===
match
---
name: dag [28237,28240]
name: dag [28623,28626]
===
match
---
name: tis_date_1 [25837,25847]
name: tis_date_1 [26223,26233]
===
match
---
trailer [6075,6093]
trailer [6075,6093]
===
match
---
number: 1 [28672,28673]
number: 1 [29058,29059]
===
match
---
atom [4328,4338]
atom [4328,4338]
===
match
---
name: timeout [9516,9523]
name: timeout [9516,9523]
===
match
---
expr_stmt [33569,33771]
expr_stmt [33955,34157]
===
match
---
name: state [22918,22923]
name: state [23304,23309]
===
match
---
trailer [20394,20417]
trailer [20394,20417]
===
match
---
testlist_comp [30479,30498]
testlist_comp [30865,30884]
===
match
---
operator: , [23719,23720]
operator: , [24105,24106]
===
match
---
trailer [12991,12994]
trailer [12991,12994]
===
match
---
arglist [26872,26923]
arglist [27258,27309]
===
match
---
operator: , [12323,12324]
operator: , [12323,12324]
===
match
---
name: task_a_0 [29940,29948]
name: task_a_0 [30326,30334]
===
match
---
name: self [11913,11917]
name: self [11913,11917]
===
match
---
string: "failed" [4760,4768]
string: "failed" [4760,4768]
===
match
---
trailer [22550,22562]
trailer [22936,22948]
===
match
---
name: execution_date [32025,32039]
name: execution_date [32411,32425]
===
match
---
trailer [31995,32015]
trailer [32381,32401]
===
match
---
operator: , [16716,16717]
operator: , [16716,16717]
===
match
---
operator: = [28952,28953]
operator: = [29338,29339]
===
match
---
name: task_id [19887,19894]
name: task_id [19887,19894]
===
match
---
name: dag [20224,20227]
name: dag [20224,20227]
===
match
---
name: autouse [1830,1837]
name: autouse [1830,1837]
===
match
---
name: log [4878,4881]
name: log [4878,4881]
===
match
---
fstring_start: f" [29100,29102]
fstring_start: f" [29486,29488]
===
match
---
simple_stmt [25701,25723]
simple_stmt [26087,26109]
===
match
---
simple_stmt [12037,12061]
simple_stmt [12037,12061]
===
match
---
name: TEST_TASK_ID [14407,14419]
name: TEST_TASK_ID [14407,14419]
===
match
---
name: task_b_0 [28108,28116]
name: task_b_0 [28494,28502]
===
match
---
argument [4314,4338]
argument [4314,4338]
===
match
---
trailer [10202,10272]
trailer [10202,10272]
===
match
---
name: state [25471,25476]
name: state [25857,25862]
===
match
---
name: run [2663,2666]
name: run [2663,2666]
===
match
---
operator: , [7757,7758]
operator: , [7757,7758]
===
match
---
simple_stmt [11928,12029]
simple_stmt [11928,12029]
===
match
---
argument [24758,24773]
argument [25144,25159]
===
match
---
operator: , [11234,11235]
operator: , [11234,11235]
===
match
---
argument [3965,3996]
argument [3965,3996]
===
match
---
arith_expr [28670,28673]
arith_expr [29056,29059]
===
match
---
trailer [24592,24598]
trailer [24978,24984]
===
match
---
argument [2667,2690]
argument [2667,2690]
===
match
---
trailer [16460,16467]
trailer [16460,16467]
===
match
---
fstring_expr [17039,17060]
fstring_expr [17039,17060]
===
match
---
name: dag [11157,11160]
name: dag [11157,11160]
===
match
---
trailer [2826,2848]
trailer [2826,2848]
===
match
---
expr_stmt [18855,18916]
expr_stmt [18855,18916]
===
match
---
trailer [8089,8100]
trailer [8089,8100]
===
match
---
simple_stmt [20000,20021]
simple_stmt [20000,20021]
===
match
---
argument [4605,4646]
argument [4605,4646]
===
match
---
name: dags [24392,24396]
name: dags [24778,24782]
===
match
---
name: AirflowException [16468,16484]
name: AirflowException [16468,16484]
===
match
---
name: settings [903,911]
name: settings [903,911]
===
match
---
shift_expr [19604,19624]
shift_expr [19604,19624]
===
match
---
trailer [10887,11171]
trailer [10887,11171]
===
match
---
name: task_a [28750,28756]
name: task_a [29136,29142]
===
match
---
name: DEFAULT_DATE [5024,5036]
name: DEFAULT_DATE [5024,5036]
===
match
---
name: ExternalTaskSensor [28300,28318]
name: ExternalTaskSensor [28686,28704]
===
match
---
trailer [2809,2826]
trailer [2809,2826]
===
match
---
fstring_end: " [28570,28571]
fstring_end: " [28956,28957]
===
match
---
simple_stmt [8142,8171]
simple_stmt [8142,8171]
===
match
---
string: '[\'time_sensor_check\', \'time_sensor_check_alternate\'] ' [6296,6355]
string: '[\'time_sensor_check\', \'time_sensor_check_alternate\'] ' [6296,6355]
===
match
---
operator: = [24472,24473]
operator: = [24858,24859]
===
match
---
atom_expr [21464,21524]
atom_expr [21464,21524]
===
match
---
with_stmt [3304,3664]
with_stmt [3304,3664]
===
match
---
name: RUNNING [22265,22272]
name: RUNNING [22265,22272]
===
match
---
name: failed_tis [8913,8923]
name: failed_tis [8913,8923]
===
match
---
fstring_end: " [28182,28183]
fstring_end: " [28568,28569]
===
match
---
atom_expr [26140,26162]
atom_expr [26526,26548]
===
match
---
name: State [22259,22264]
name: State [22259,22264]
===
match
---
argument [20159,20187]
argument [20159,20187]
===
match
---
operator: , [9866,9867]
operator: , [9866,9867]
===
match
---
operator: = [4017,4018]
operator: = [4017,4018]
===
match
---
assert_stmt [5285,5459]
assert_stmt [5285,5459]
===
match
---
atom_expr [10869,11171]
atom_expr [10869,11171]
===
match
---
simple_stmt [22897,22933]
simple_stmt [23283,23319]
===
match
---
operator: , [25808,25809]
operator: , [26194,26195]
===
match
---
operator: == [17852,17854]
operator: == [17852,17854]
===
match
---
string: 'success' [12435,12444]
string: 'success' [12435,12444]
===
match
---
operator: , [15561,15562]
operator: , [15561,15562]
===
match
---
atom_expr [15078,15344]
atom_expr [15078,15344]
===
match
---
arglist [17385,17448]
arglist [17385,17448]
===
match
---
name: pytest [15359,15365]
name: pytest [15359,15365]
===
match
---
operator: { [28669,28670]
operator: { [29055,29056]
===
match
---
name: dag_bag [25137,25144]
name: dag_bag [25523,25530]
===
match
---
name: dag [7948,7951]
name: dag [7948,7951]
===
match
---
operator: , [23451,23452]
operator: , [23837,23838]
===
match
---
name: dag_0 [21621,21626]
name: dag_0 [21621,21626]
===
match
---
simple_stmt [31926,31972]
simple_stmt [32312,32358]
===
match
---
expr_stmt [6982,7172]
expr_stmt [6982,7172]
===
match
---
operator: = [33419,33420]
operator: = [33805,33806]
===
match
---
name: dag_2 [19630,19635]
name: dag_2 [19630,19635]
===
match
---
funcdef [16578,17137]
funcdef [16578,17137]
===
match
---
argument [25810,25831]
argument [26196,26217]
===
match
---
operator: + [12980,12981]
operator: + [12980,12981]
===
match
---
name: self [4826,4830]
name: self [4826,4830]
===
match
---
name: instance [16921,16929]
name: instance [16921,16929]
===
match
---
atom_expr [16660,16817]
atom_expr [16660,16817]
===
match
---
operator: = [1712,1713]
operator: = [1712,1713]
===
match
---
trailer [30180,30189]
trailer [30566,30575]
===
match
---
parameters [22967,23090]
parameters [23353,23476]
===
match
---
argument [35109,35124]
argument [35495,35510]
===
match
---
name: dag_1 [21840,21845]
name: dag_1 [21840,21845]
===
match
---
operator: , [4881,4882]
operator: , [4881,4882]
===
match
---
name: op [5667,5669]
name: op [5667,5669]
===
match
---
atom_expr [11783,11860]
atom_expr [11783,11860]
===
match
---
fstring_expr [28567,28570]
fstring_expr [28953,28956]
===
match
---
arglist [10901,11161]
arglist [10901,11161]
===
match
---
comparison [8664,8692]
comparison [8664,8692]
===
match
---
name: task [34449,34453]
name: task [34835,34839]
===
match
---
operator: , [9674,9675]
operator: , [9674,9675]
===
match
---
expr_stmt [19630,19699]
expr_stmt [19630,19699]
===
match
---
name: dag_id [34168,34174]
name: dag_id [34554,34560]
===
match
---
trailer [17795,17810]
trailer [17795,17810]
===
match
---
atom_expr [30891,30958]
atom_expr [31277,31344]
===
match
---
with_item [4859,4908]
with_item [4859,4908]
===
match
---
operator: = [13314,13315]
operator: = [13314,13315]
===
match
---
trailer [25167,25178]
trailer [25553,25564]
===
match
---
operator: = [8356,8357]
operator: = [8356,8357]
===
match
---
suite [22204,22715]
suite [22204,23101]
===
match
---
name: ignore_ti_state [8102,8117]
name: ignore_ti_state [8102,8117]
===
match
---
operator: } [28619,28620]
operator: } [29005,29006]
===
match
---
name: self [15019,15023]
name: self [15019,15023]
===
match
---
name: external_dag_id [17532,17547]
name: external_dag_id [17532,17547]
===
match
---
operator: = [4327,4328]
operator: = [4327,4328]
===
match
---
import_name [787,801]
import_name [787,801]
===
match
---
trailer [9836,9847]
trailer [9836,9847]
===
match
---
name: dry_run [23411,23418]
name: dry_run [23797,23804]
===
match
---
string: "dag_1" [19131,19138]
string: "dag_1" [19131,19138]
===
match
---
name: State [8726,8731]
name: State [8726,8731]
===
match
---
name: fixture [20468,20475]
name: fixture [20468,20475]
===
match
---
term [5097,5245]
term [5097,5245]
===
match
---
name: str [5310,5313]
name: str [5310,5313]
===
match
---
trailer [12742,12759]
trailer [12742,12759]
===
match
---
argument [16382,16402]
argument [16382,16402]
===
match
---
argument [6803,6828]
argument [6803,6828]
===
match
---
operator: == [12141,12143]
operator: == [12141,12143]
===
match
---
simple_stmt [19308,19448]
simple_stmt [19308,19448]
===
match
---
simple_stmt [28258,28275]
simple_stmt [28644,28661]
===
match
---
name: execution_date_fn [12380,12397]
name: execution_date_fn [12380,12397]
===
match
---
arglist [14222,14495]
arglist [14222,14495]
===
match
---
expr_stmt [19848,19995]
expr_stmt [19848,19995]
===
match
---
name: task_id [2241,2248]
name: task_id [2241,2248]
===
match
---
atom_expr [4826,4834]
atom_expr [4826,4834]
===
match
---
name: task_a_2 [19704,19712]
name: task_a_2 [19704,19712]
===
match
---
param [22986,22990]
param [23372,23376]
===
match
---
argument [27978,27996]
argument [28364,28382]
===
match
---
trailer [17719,17725]
trailer [17719,17725]
===
match
---
argument [6780,6801]
argument [6780,6801]
===
match
---
atom_expr [16960,16987]
atom_expr [16960,16987]
===
match
---
atom_expr [2857,2910]
atom_expr [2857,2910]
===
match
---
arglist [7019,7162]
arglist [7019,7162]
===
match
---
name: task_id [13042,13049]
name: task_id [13042,13049]
===
match
---
atom_expr [24549,24580]
atom_expr [24935,24966]
===
match
---
operator: , [3193,3194]
operator: , [3193,3194]
===
match
---
operator: , [28411,28412]
operator: , [28797,28798]
===
match
---
name: recursion_depth [28052,28067]
name: recursion_depth [28438,28453]
===
match
---
expr_stmt [10863,11171]
expr_stmt [10863,11171]
===
match
---
argument [14388,14420]
argument [14388,14420]
===
match
---
operator: = [28039,28040]
operator: = [28425,28426]
===
match
---
trailer [24403,24405]
trailer [24789,24791]
===
match
---
atom_expr [13932,13940]
atom_expr [13932,13940]
===
match
---
simple_stmt [2660,2737]
simple_stmt [2660,2737]
===
match
---
number: 1 [8814,8815]
number: 1 [8814,8815]
===
match
---
atom_expr [25038,25119]
atom_expr [25424,25505]
===
match
---
name: op [4384,4386]
name: op [4384,4386]
===
match
---
atom_expr [5994,6037]
atom_expr [5994,6037]
===
match
---
trailer [22582,22586]
trailer [22968,22972]
===
match
---
name: dt [12166,12168]
name: dt [12166,12168]
===
match
---
atom [9821,9866]
atom [9821,9866]
===
match
---
name: pytest [26858,26864]
name: pytest [27244,27250]
===
match
---
param [2186,2206]
param [2186,2206]
===
match
---
name: task_a_1 [19604,19612]
name: task_a_1 [19604,19612]
===
match
---
string: "dag_0" [30355,30362]
string: "dag_0" [30741,30748]
===
match
---
arglist [28831,28894]
arglist [29217,29280]
===
match
---
name: tasks [32008,32013]
name: tasks [32394,32399]
===
match
---
name: self [13428,13432]
name: self [13428,13432]
===
match
---
name: dag [13928,13931]
name: dag [13928,13931]
===
match
---
operator: , [21182,21183]
operator: , [21182,21183]
===
match
---
atom_expr [6769,6778]
atom_expr [6769,6778]
===
match
---
name: external_task_id [9733,9749]
name: external_task_id [9733,9749]
===
match
---
name: dt [12082,12084]
name: dt [12082,12084]
===
match
---
name: provide_session [21938,21953]
name: provide_session [21938,21953]
===
match
---
operator: , [30847,30848]
operator: , [31233,31234]
===
match
---
trailer [6773,6778]
trailer [6773,6778]
===
match
---
name: pytest [16005,16011]
name: pytest [16005,16011]
===
match
---
operator: >> [31509,31511]
operator: >> [31895,31897]
===
match
---
operator: = [20412,20413]
operator: = [20412,20413]
===
match
---
name: SerializedBaseOperator [17678,17700]
name: SerializedBaseOperator [17678,17700]
===
match
---
name: ignore_ti_state [13352,13367]
name: ignore_ti_state [13352,13367]
===
match
---
decorated [33867,35156]
decorated [34253,35542]
===
match
---
name: schedule_interval [21184,21201]
name: schedule_interval [21184,21201]
===
match
---
arglist [29924,29948]
arglist [30310,30334]
===
match
---
operator: % [31455,31456]
operator: % [31841,31842]
===
match
---
simple_stmt [18855,18917]
simple_stmt [18855,18917]
===
match
---
atom_expr [6024,6036]
atom_expr [6024,6036]
===
match
---
operator: , [14960,14961]
operator: , [14960,14961]
===
match
---
name: task_a_0 [26094,26102]
name: task_a_0 [26480,26488]
===
match
---
name: external_dag_id [16299,16314]
name: external_dag_id [16299,16314]
===
match
---
name: dag_bag_ext [26703,26714]
name: dag_bag_ext [27089,27100]
===
match
---
name: task_id [2489,2496]
name: task_id [2489,2496]
===
match
---
simple_stmt [34860,34952]
simple_stmt [35246,35338]
===
match
---
name: dag [2637,2640]
name: dag [2637,2640]
===
match
---
argument [3636,3648]
argument [3636,3648]
===
match
---
operator: , [21499,21500]
operator: , [21499,21500]
===
match
---
name: ctx [5314,5317]
name: ctx [5314,5317]
===
match
---
operator: = [28298,28299]
operator: = [28684,28685]
===
match
---
simple_stmt [13296,13374]
simple_stmt [13296,13374]
===
match
---
trailer [16467,16485]
trailer [16467,16485]
===
match
---
operator: + [8317,8318]
operator: + [8317,8318]
===
match
---
name: run [10660,10663]
name: run [10660,10663]
===
match
---
atom_expr [19463,19599]
atom_expr [19463,19599]
===
match
---
string: "example_bash_operator" [15846,15869]
string: "example_bash_operator" [15846,15869]
===
match
---
fstring [17033,17061]
fstring [17033,17061]
===
match
---
fstring [29049,29065]
fstring [29435,29451]
===
match
---
operator: , [4364,4365]
operator: , [4364,4365]
===
match
---
name: get_dag [23626,23633]
name: get_dag [24012,24019]
===
match
---
name: start_date [34877,34887]
name: start_date [35263,35273]
===
match
---
name: end_date [32389,32397]
name: end_date [32775,32783]
===
match
---
trailer [1980,2024]
trailer [1980,2024]
===
match
---
operator: = [7088,7089]
operator: = [7088,7089]
===
match
---
operator: = [20057,20058]
operator: = [20057,20058]
===
match
---
atom_expr [8664,8673]
atom_expr [8664,8673]
===
match
---
operator: , [13724,13725]
operator: , [13724,13725]
===
match
---
atom_expr [34055,34067]
atom_expr [34441,34453]
===
match
---
simple_stmt [23689,23731]
simple_stmt [24075,24117]
===
match
---
name: test_time_sensor [14569,14585]
name: test_time_sensor [14569,14585]
===
match
---
name: range [28135,28140]
name: range [28521,28526]
===
match
---
atom_expr [25436,25448]
atom_expr [25822,25834]
===
match
---
name: dagrun_1_2 [25460,25470]
name: dagrun_1_2 [25846,25856]
===
match
---
argument [2300,2323]
argument [2300,2323]
===
match
---
name: dag [17375,17378]
name: dag [17375,17378]
===
match
---
arglist [7577,7656]
arglist [7577,7656]
===
match
---
argument [30849,30875]
argument [31235,31261]
===
match
---
simple_stmt [16960,16988]
simple_stmt [16960,16988]
===
match
---
name: end_date [4416,4424]
name: end_date [4416,4424]
===
match
---
expr_stmt [1734,1788]
expr_stmt [1734,1788]
===
match
---
simple_stmt [33850,33865]
simple_stmt [34236,34251]
===
match
---
arglist [2117,2152]
arglist [2117,2152]
===
match
---
atom_expr [19859,19995]
atom_expr [19859,19995]
===
match
---
operator: = [26138,26139]
operator: = [26524,26525]
===
match
---
operator: = [4796,4797]
operator: = [4796,4797]
===
match
---
operator: = [9146,9147]
operator: = [9146,9147]
===
match
---
name: airflow [1548,1555]
name: airflow [1548,1555]
===
match
---
atom_expr [10629,10637]
atom_expr [10629,10637]
===
match
---
name: include_examples [2002,2018]
name: include_examples [2002,2018]
===
match
---
name: TEST_TASK_ID [3080,3092]
name: TEST_TASK_ID [3080,3092]
===
match
---
operator: = [9073,9074]
operator: = [9073,9074]
===
match
---
simple_stmt [6207,6460]
simple_stmt [6207,6460]
===
match
---
trailer [28172,28233]
trailer [28558,28619]
===
match
---
name: include_examples [27706,27722]
name: include_examples [28092,28108]
===
match
---
atom [11609,11620]
atom [11609,11620]
===
match
---
name: session [25012,25019]
name: session [25398,25405]
===
match
---
atom_expr [29706,29724]
atom_expr [30092,30110]
===
match
---
expr_stmt [21115,21135]
expr_stmt [21115,21135]
===
match
---
name: task_a_0 [30308,30316]
name: task_a_0 [30694,30702]
===
match
---
trailer [31999,32014]
trailer [32385,32400]
===
match
---
string: 'child_task1' [18030,18043]
string: 'child_task1' [18030,18043]
===
match
---
name: SUCCESS [22706,22713]
name: SUCCESS [23092,23099]
===
match
---
simple_stmt [23520,23569]
simple_stmt [23906,23955]
===
match
---
trailer [6068,6075]
trailer [6068,6075]
===
match
---
name: self [10629,10633]
name: self [10629,10633]
===
match
---
argument [9111,9149]
argument [9111,9149]
===
match
---
atom_expr [8760,8777]
atom_expr [8760,8777]
===
match
---
operator: + [7536,7537]
operator: + [7536,7537]
===
match
---
name: self [13268,13272]
name: self [13268,13272]
===
match
---
trailer [14160,14172]
trailer [14160,14172]
===
match
---
operator: = [27818,27819]
operator: = [28204,28205]
===
match
---
simple_stmt [14564,14588]
simple_stmt [14564,14588]
===
match
---
operator: , [15641,15642]
operator: , [15641,15642]
===
match
---
param [33951,33958]
param [34337,34344]
===
match
---
simple_stmt [912,982]
simple_stmt [912,982]
===
match
---
string: "reschedule" [33492,33504]
string: "reschedule" [33878,33890]
===
match
---
operator: , [4026,4027]
operator: , [4026,4027]
===
match
---
operator: = [6900,6901]
operator: = [6900,6901]
===
match
---
simple_stmt [30194,30227]
simple_stmt [30580,30613]
===
match
---
atom_expr [14952,14960]
atom_expr [14952,14960]
===
match
---
name: i [31293,31294]
name: i [31679,31680]
===
match
---
operator: = [15236,15237]
operator: = [15236,15237]
===
match
---
simple_stmt [7984,8133]
simple_stmt [7984,8133]
===
match
---
string: 'test_external_task_duplicate_task_ids' [14738,14777]
string: 'test_external_task_duplicate_task_ids' [14738,14777]
===
match
---
argument [19188,19197]
argument [19188,19197]
===
match
---
name: ignore_ti_state [7236,7251]
name: ignore_ti_state [7236,7251]
===
match
---
name: TEST_DAG_ID [14312,14323]
name: TEST_DAG_ID [14312,14323]
===
match
---
name: self [6769,6773]
name: self [6769,6773]
===
match
---
operator: == [12911,12913]
operator: == [12911,12913]
===
match
---
name: dag_id [19785,19791]
name: dag_id [19785,19791]
===
match
---
trailer [29849,29902]
trailer [30235,30288]
===
match
---
name: dag_external_id [8677,8692]
name: dag_external_id [8677,8692]
===
match
---
argument [13789,13817]
argument [13789,13817]
===
match
---
operator: = [34204,34205]
operator: = [34590,34591]
===
match
---
operator: = [11854,11855]
operator: = [11854,11855]
===
match
---
argument [13632,13679]
argument [13632,13679]
===
match
---
argument [34238,34267]
argument [34624,34653]
===
match
---
simple_stmt [30231,30269]
simple_stmt [30617,30655]
===
match
---
trailer [17132,17134]
trailer [17132,17134]
===
match
---
name: self [3135,3139]
name: self [3135,3139]
===
match
---
atom_expr [22453,22474]
atom_expr [22786,22807]
===
match
---
operator: = [3978,3979]
operator: = [3978,3979]
===
match
---
simple_stmt [34512,34549]
simple_stmt [34898,34935]
===
match
---
name: DEFAULT_DATE [33238,33250]
name: DEFAULT_DATE [33624,33636]
===
match
---
suite [20370,20418]
suite [20370,20418]
===
match
---
argument [20047,20070]
argument [20047,20070]
===
match
---
import_from [1429,1498]
import_from [1429,1498]
===
match
---
name: DEFAULT_DATE [2080,2092]
name: DEFAULT_DATE [2080,2092]
===
match
---
trailer [7576,7657]
trailer [7576,7657]
===
match
---
for_stmt [28126,28767]
for_stmt [28512,29153]
===
match
---
name: external_task_id [21647,21663]
name: external_task_id [21647,21663]
===
match
---
import_as_names [1009,1037]
import_as_names [1009,1037]
===
match
---
operator: , [33504,33505]
operator: , [33890,33891]
===
match
---
trailer [8923,8926]
trailer [8923,8926]
===
match
---
for_stmt [29392,29460]
for_stmt [29778,29846]
===
match
---
operator: = [29199,29200]
operator: = [29585,29586]
===
match
---
name: ignore_ti_state [4439,4454]
name: ignore_ti_state [4439,4454]
===
match
---
argument [4660,4687]
argument [4660,4687]
===
match
---
name: ignore_ti_state [5038,5053]
name: ignore_ti_state [5038,5053]
===
match
---
atom [9895,9906]
atom [9895,9906]
===
match
---
with_stmt [15034,15345]
with_stmt [15034,15345]
===
match
---
simple_stmt [16993,17062]
simple_stmt [16993,17062]
===
match
---
operator: = [29336,29337]
operator: = [29722,29723]
===
match
---
suite [12620,13374]
suite [12620,13374]
===
match
---
operator: = [13367,13368]
operator: = [13367,13368]
===
match
---
suite [16651,16818]
suite [16651,16818]
===
match
---
argument [19095,19113]
argument [19095,19113]
===
match
---
fstring_end: " [28464,28465]
fstring_end: " [28850,28851]
===
match
---
name: day_1 [21115,21120]
name: day_1 [21115,21120]
===
match
---
simple_stmt [19630,19700]
simple_stmt [19630,19700]
===
match
---
trailer [22586,22603]
trailer [22972,22989]
===
match
---
trailer [34982,35135]
trailer [35368,35521]
===
match
---
operator: = [22258,22259]
operator: = [22258,22259]
===
match
---
name: retries [9920,9927]
name: retries [9920,9927]
===
match
---
fstring_start: f" [28558,28560]
fstring_start: f" [28944,28946]
===
match
---
argument [34321,34343]
argument [34707,34729]
===
match
---
operator: = [11824,11825]
operator: = [11824,11825]
===
match
---
argument [13697,13724]
argument [13697,13724]
===
match
---
name: allowed_states [14438,14452]
name: allowed_states [14438,14452]
===
match
---
string: 'test_external_task_sensor_check' [15783,15816]
string: 'test_external_task_sensor_check' [15783,15816]
===
match
---
trailer [2037,2042]
trailer [2037,2042]
===
match
---
operator: , [11094,11095]
operator: , [11094,11095]
===
match
---
name: op1 [13296,13299]
name: op1 [13296,13299]
===
match
---
name: get_task [23664,23672]
name: get_task [24050,24058]
===
match
---
name: DEFAULT_DATE [8065,8077]
name: DEFAULT_DATE [8065,8077]
===
match
---
number: 1 [9553,9554]
number: 1 [9553,9554]
===
match
---
fstring_string: dag_ [29051,29055]
fstring_string: dag_ [29437,29441]
===
match
---
name: external_task_id [16774,16790]
name: external_task_id [16774,16790]
===
match
---
atom_expr [12115,12140]
atom_expr [12115,12140]
===
match
---
suite [6044,6678]
suite [6044,6678]
===
match
---
name: task_id [16244,16251]
name: task_id [16244,16251]
===
match
---
arith_expr [8304,8339]
arith_expr [8304,8339]
===
match
---
arglist [33822,33843]
arglist [34208,34229]
===
match
---
name: isoformat [21400,21409]
name: isoformat [21400,21409]
===
match
---
trailer [5317,5323]
trailer [5317,5323]
===
match
---
fstring [28660,28675]
fstring [29046,29061]
===
match
---
name: recursion_depth [29321,29336]
name: recursion_depth [29707,29722]
===
match
---
name: AirflowException [6076,6092]
name: AirflowException [6076,6092]
===
match
---
operator: , [22004,22005]
operator: , [22004,22005]
===
match
---
arglist [15434,15642]
arglist [15434,15642]
===
match
---
operator: , [30499,30500]
operator: , [30885,30886]
===
match
---
name: TEST_TASK_ID [13159,13171]
name: TEST_TASK_ID [13159,13171]
===
match
---
string: "task_a_0" [26762,26772]
string: "task_a_0" [27148,27158]
===
match
---
testlist_comp [14859,14885]
testlist_comp [14859,14885]
===
match
---
name: test_serialized_fields [17196,17218]
name: test_serialized_fields [17196,17218]
===
match
---
trailer [31025,31033]
trailer [31411,31419]
===
match
---
operator: = [19130,19131]
operator: = [19130,19131]
===
match
---
expr_stmt [6727,6829]
expr_stmt [6727,6829]
===
match
---
name: task_id [9647,9654]
name: task_id [9647,9654]
===
match
---
string: 'child_dag_1' [25251,25264]
string: 'child_dag_1' [25637,25650]
===
match
---
argument [10543,10571]
argument [10543,10571]
===
match
---
name: my_func [12074,12081]
name: my_func [12074,12081]
===
match
---
name: self [2420,2424]
name: self [2420,2424]
===
match
---
operator: , [28208,28209]
operator: , [28594,28595]
===
match
---
trailer [22239,22434]
trailer [22239,22434]
===
match
---
name: start_date [21483,21493]
name: start_date [21483,21493]
===
match
---
name: self [2632,2636]
name: self [2632,2636]
===
match
---
atom_expr [4889,4901]
atom_expr [4889,4901]
===
match
---
arith_expr [34094,34130]
arith_expr [34480,34516]
===
match
---
string: '/dev/null' [1800,1811]
string: '/dev/null' [1800,1811]
===
match
---
string: "task_b_3" [26194,26204]
string: "task_b_3" [26580,26590]
===
match
---
simple_stmt [9023,9031]
simple_stmt [9023,9031]
===
match
---
funcdef [14515,14976]
funcdef [14515,14976]
===
match
---
name: dag_bag_cyclic [29706,29720]
name: dag_bag_cyclic [30092,30106]
===
match
---
name: assert_ti_state_equal [22737,22758]
name: assert_ti_state_equal [23123,23144]
===
match
---
argument [21379,21411]
argument [21379,21411]
===
match
---
operator: = [34174,34175]
operator: = [34560,34561]
===
match
---
simple_stmt [6982,7173]
simple_stmt [6982,7173]
===
match
---
simple_stmt [23981,24076]
simple_stmt [24367,24462]
===
match
---
name: ExternalTaskSensor [10366,10384]
name: ExternalTaskSensor [10366,10384]
===
match
---
trailer [22459,22474]
trailer [22792,22807]
===
match
---
trailer [23588,23601]
trailer [23974,23987]
===
match
---
operator: , [23867,23868]
operator: , [24253,24254]
===
match
---
name: task_a_0 [26736,26744]
name: task_a_0 [27122,27130]
===
match
---
atom_expr [30549,30558]
atom_expr [30935,30944]
===
match
---
trailer [23663,23672]
trailer [24049,24058]
===
match
---
trailer [26150,26162]
trailer [26536,26548]
===
match
---
name: TEST_TASK_ID [3511,3523]
name: TEST_TASK_ID [3511,3523]
===
match
---
simple_stmt [26668,26691]
simple_stmt [27054,27077]
===
match
---
name: bash [1096,1100]
name: bash [1096,1100]
===
match
---
operator: = [2834,2835]
operator: = [2834,2835]
===
match
---
operator: = [7798,7799]
operator: = [7798,7799]
===
match
---
operator: = [34887,34888]
operator: = [35273,35274]
===
match
---
with_stmt [27758,28117]
with_stmt [28144,28503]
===
match
---
operator: = [19809,19810]
operator: = [19809,19810]
===
match
---
number: 1 [33471,33472]
number: 1 [33857,33858]
===
match
---
fstring_expr [29055,29064]
fstring_expr [29441,29450]
===
match
---
expr_stmt [26778,26815]
expr_stmt [27164,27201]
===
match
---
name: dag [15326,15329]
name: dag [15326,15329]
===
match
---
argument [11048,11094]
argument [11048,11094]
===
match
---
operator: == [34946,34948]
operator: == [35332,35334]
===
match
---
name: logging [4889,4896]
name: logging [4889,4896]
===
match
---
name: TEST_TASK_ID [2194,2206]
name: TEST_TASK_ID [2194,2206]
===
match
---
atom_expr [22377,22394]
atom_expr [22377,22394]
===
match
---
name: self [13443,13447]
name: self [13443,13447]
===
match
---
arglist [23235,23292]
arglist [23621,23678]
===
match
---
name: TEST_DAG_ID [5784,5795]
name: TEST_DAG_ID [5784,5795]
===
match
---
atom_expr [25953,25979]
atom_expr [26339,26365]
===
match
---
fstring_expr [28615,28620]
fstring_expr [29001,29006]
===
match
---
operator: = [11198,11199]
operator: = [11198,11199]
===
match
---
name: external_dag_id [19511,19526]
name: external_dag_id [19511,19526]
===
match
---
trailer [32007,32013]
trailer [32393,32399]
===
match
---
expr_stmt [33524,33560]
expr_stmt [33910,33946]
===
match
---
name: State [26343,26348]
name: State [26729,26734]
===
match
---
atom_expr [30242,30268]
atom_expr [30628,30654]
===
match
---
decorator [32448,32464]
decorator [32834,32850]
===
match
---
name: raises [14662,14668]
name: raises [14662,14668]
===
match
---
fstring_start: f" [17107,17109]
fstring_start: f" [17107,17109]
===
match
---
atom_expr [26396,26406]
atom_expr [26782,26792]
===
match
---
name: clear_tasks [22956,22967]
name: clear_tasks [23342,23353]
===
match
---
argument [19255,19278]
argument [19255,19278]
===
match
---
name: timeout [9943,9950]
name: timeout [9943,9950]
===
match
---
arglist [3170,3238]
arglist [3170,3238]
===
match
---
name: self [2102,2106]
name: self [2102,2106]
===
match
---
funcdef [7263,10273]
funcdef [7263,10273]
===
match
---
name: ti_b_3_date_0 [26328,26341]
name: ti_b_3_date_0 [26714,26727]
===
match
---
name: dag_maker [16832,16841]
name: dag_maker [16832,16841]
===
match
---
name: dag_external [7952,7964]
name: dag_external [7952,7964]
===
match
---
argument [21065,21084]
argument [21065,21084]
===
match
---
operator: = [9382,9383]
operator: = [9382,9383]
===
match
---
arglist [33608,33761]
arglist [33994,34147]
===
match
---
argument [28052,28069]
argument [28438,28455]
===
match
---
atom_expr [31146,31189]
atom_expr [31532,31575]
===
match
---
trailer [33154,33199]
trailer [33540,33585]
===
match
---
suite [30013,30587]
suite [30399,30973]
===
match
---
name: ExternalTaskMarker [19463,19481]
name: ExternalTaskMarker [19463,19481]
===
match
---
arglist [12231,12472]
arglist [12231,12472]
===
match
---
name: DagRunType [1575,1585]
name: DagRunType [1575,1585]
===
match
---
simple_stmt [21048,21110]
simple_stmt [21048,21110]
===
match
---
argument [33487,33504]
argument [33873,33890]
===
match
---
name: ti_b_3_date_1 [26210,26223]
name: ti_b_3_date_1 [26596,26609]
===
match
---
comparison [12892,12957]
comparison [12892,12957]
===
match
---
name: op [4568,4570]
name: op [4568,4570]
===
match
---
operator: = [4758,4759]
operator: = [4758,4759]
===
match
---
operator: = [5931,5932]
operator: = [5931,5932]
===
match
---
operator: , [9085,9086]
operator: , [9085,9086]
===
match
---
expr_stmt [16823,16915]
expr_stmt [16823,16915]
===
match
---
suite [17366,18044]
suite [17366,18044]
===
match
---
name: dt [11073,11075]
name: dt [11073,11075]
===
match
---
name: dags [22190,22194]
name: dags [22190,22194]
===
match
---
with_stmt [4922,5060]
with_stmt [4922,5060]
===
match
---
simple_stmt [29366,29383]
simple_stmt [29752,29769]
===
match
---
simple_stmt [22488,22535]
simple_stmt [22874,22921]
===
match
---
operator: = [19857,19858]
operator: = [19857,19858]
===
match
---
parameters [5537,5543]
parameters [5537,5543]
===
match
---
expr_stmt [34077,34130]
expr_stmt [34463,34516]
===
match
---
expr_stmt [24080,24110]
expr_stmt [24466,24496]
===
match
---
funcdef [10278,10734]
funcdef [10278,10734]
===
match
---
argument [6944,6963]
argument [6944,6963]
===
match
---
operator: , [14278,14279]
operator: , [14278,14279]
===
match
---
arglist [14730,14961]
arglist [14730,14961]
===
match
---
comparison [25416,25448]
comparison [25802,25834]
===
match
---
trailer [2147,2152]
trailer [2147,2152]
===
match
---
name: external_task_id [9303,9319]
name: external_task_id [9303,9319]
===
match
---
name: run_tasks [25787,25796]
name: run_tasks [26173,26182]
===
match
---
operator: % [6406,6407]
operator: % [6406,6407]
===
match
---
operator: , [8054,8055]
operator: , [8054,8055]
===
match
---
trailer [24391,24396]
trailer [24777,24782]
===
match
---
decorator [26978,26994]
decorator [27364,27380]
===
match
---
name: args [2038,2042]
name: args [2038,2042]
===
match
---
trailer [30217,30226]
trailer [30603,30612]
===
match
---
name: start_date [21166,21176]
name: start_date [21166,21176]
===
match
---
name: op [4983,4985]
name: op [4983,4985]
===
match
---
operator: , [16552,16553]
operator: , [16552,16553]
===
match
---
operator: = [11389,11390]
operator: = [11389,11390]
===
match
---
name: agg_dag [30881,30888]
name: agg_dag [31267,31274]
===
match
---
operator: = [25110,25111]
operator: = [25496,25497]
===
match
---
parameters [1944,1950]
parameters [1944,1950]
===
match
---
argument [13329,13350]
argument [13329,13350]
===
match
---
operator: , [31391,31392]
operator: , [31777,31778]
===
match
---
name: external_dag_id [28593,28608]
name: external_dag_id [28979,28994]
===
match
---
atom_expr [16005,16036]
atom_expr [16005,16036]
===
match
---
operator: = [27695,27696]
operator: = [28081,28082]
===
match
---
name: dag_2 [19832,19837]
name: dag_2 [19832,19837]
===
match
---
name: dt [12851,12853]
name: dt [12851,12853]
===
match
---
operator: = [13337,13338]
operator: = [13337,13338]
===
match
---
operator: , [6171,6172]
operator: , [6171,6172]
===
match
---
operator: = [9467,9468]
operator: = [9467,9468]
===
match
---
name: DEFAULT_DATE [24148,24160]
name: DEFAULT_DATE [24534,24546]
===
match
---
name: op1 [12491,12494]
name: op1 [12491,12494]
===
match
---
simple_stmt [28916,28933]
simple_stmt [29302,29319]
===
match
---
operator: , [12084,12085]
operator: , [12084,12085]
===
match
---
name: poke_interval [9966,9979]
name: poke_interval [9966,9979]
===
match
---
operator: = [14810,14811]
operator: = [14810,14811]
===
match
---
comparison [25460,25493]
comparison [25846,25879]
===
match
---
name: external_dag_id [13697,13712]
name: external_dag_id [13697,13712]
===
match
---
name: test_external_task_sensor_fn [10743,10771]
name: test_external_task_sensor_fn [10743,10771]
===
match
---
trailer [25265,25276]
trailer [25651,25662]
===
match
---
operator: = [7026,7027]
operator: = [7026,7027]
===
match
---
name: failed_states [3589,3602]
name: failed_states [3589,3602]
===
match
---
name: external_task_id [15883,15899]
name: external_task_id [15883,15899]
===
match
---
trailer [10568,10571]
trailer [10568,10571]
===
match
---
name: self [11152,11156]
name: self [11152,11156]
===
match
---
trailer [25382,25388]
trailer [25768,25774]
===
match
---
operator: , [8738,8739]
operator: , [8738,8739]
===
match
---
name: recursion_depth [19961,19976]
name: recursion_depth [19961,19976]
===
match
---
decorated [21937,22731]
decorated [21937,23117]
===
match
---
name: partial_subset [23220,23234]
name: partial_subset [23606,23620]
===
match
---
name: raises [26865,26871]
name: raises [27251,27257]
===
match
---
fstring [17107,17136]
fstring [17107,17136]
===
match
---
funcdef [4466,5460]
funcdef [4466,5460]
===
match
---
atom [10600,10611]
atom [10600,10611]
===
match
---
name: TEST_DAG_ID [2560,2571]
name: TEST_DAG_ID [2560,2571]
===
match
---
with_stmt [6057,6195]
with_stmt [6057,6195]
===
match
---
name: ti [22551,22553]
name: ti [22937,22939]
===
match
---
suite [25546,26408]
suite [25932,26794]
===
match
---
operator: = [20174,20175]
operator: = [20174,20175]
===
match
---
operator: = [13931,13932]
operator: = [13931,13932]
===
match
---
suite [2796,3240]
suite [2796,3240]
===
match
---
argument [21340,21365]
argument [21340,21365]
===
match
---
string: 'external_task_marker_child' [17938,17966]
string: 'external_task_marker_child' [17938,17966]
===
match
---
argument [9453,9479]
argument [9453,9479]
===
match
---
atom_expr [8080,8100]
atom_expr [8080,8100]
===
match
---
string: "task_a_2" [19751,19761]
string: "task_a_2" [19751,19761]
===
match
---
argument [11839,11859]
argument [11839,11859]
===
match
---
name: task_id [21671,21678]
name: task_id [21671,21678]
===
match
---
operator: = [2700,2701]
operator: = [2700,2701]
===
match
---
classdef [17139,18044]
classdef [17139,18044]
===
match
---
atom_expr [16639,16650]
atom_expr [16639,16650]
===
match
---
simple_stmt [4983,5060]
simple_stmt [4983,5060]
===
match
---
operator: = [12197,12198]
operator: = [12197,12198]
===
match
---
decorator [20460,20476]
decorator [20460,20476]
===
match
---
argument [14296,14323]
argument [14296,14323]
===
match
---
name: DEFAULT_DATE [25736,25748]
name: DEFAULT_DATE [26122,26134]
===
match
---
name: TEST_DAG_ID [3465,3476]
name: TEST_DAG_ID [3465,3476]
===
match
---
operator: = [17463,17464]
operator: = [17463,17464]
===
match
---
name: AirflowSensorTimeout [961,981]
name: AirflowSensorTimeout [961,981]
===
match
---
param [5538,5542]
param [5538,5542]
===
match
---
argument [16347,16368]
argument [16347,16368]
===
match
---
name: dag_bag [35070,35077]
name: dag_bag [35456,35463]
===
match
---
operator: , [11672,11673]
operator: , [11672,11673]
===
match
---
name: self [4018,4022]
name: self [4018,4022]
===
match
---
for_stmt [22443,22715]
for_stmt [22845,23101]
===
match
---
operator: = [22300,22301]
operator: = [22300,22301]
===
match
---
trailer [7183,7187]
trailer [7183,7187]
===
match
---
argument [15775,15816]
argument [15775,15816]
===
match
---
name: deserialized_op [17899,17914]
name: deserialized_op [17899,17914]
===
match
---
operator: = [31227,31228]
operator: = [31613,31614]
===
match
---
name: execution_date [21717,21731]
name: execution_date [21717,21731]
===
match
---
name: start_date [23018,23028]
name: start_date [23404,23414]
===
match
---
name: end_date [5015,5023]
name: end_date [5015,5023]
===
match
---
atom_expr [22700,22713]
atom_expr [23086,23099]
===
match
---
name: dag_id [20181,20187]
name: dag_id [20181,20187]
===
match
---
operator: = [21440,21441]
operator: = [21440,21441]
===
match
---
name: dag_bag_ext [23614,23625]
name: dag_bag_ext [24000,24011]
===
match
---
operator: = [19894,19895]
operator: = [19894,19895]
===
match
---
name: n [28568,28569]
name: n [28954,28955]
===
match
---
name: task_b [29147,29153]
name: task_b [29533,29539]
===
match
---
trailer [12759,12761]
trailer [12759,12761]
===
match
---
trailer [16875,16885]
trailer [16875,16885]
===
match
---
funcdef [27624,29484]
funcdef [28010,29870]
===
match
---
name: task_id [29192,29199]
name: task_id [29578,29585]
===
match
---
string: "task_a_0" [23673,23683]
string: "task_a_0" [24059,24069]
===
match
---
operator: = [19240,19241]
operator: = [19240,19241]
===
match
---
string: 'test_external_task_sensor_check_delta' [10406,10445]
string: 'test_external_task_sensor_check_delta' [10406,10445]
===
match
---
name: pytest [11723,11729]
name: pytest [11723,11729]
===
match
---
name: self [4521,4525]
name: self [4521,4525]
===
match
---
simple_stmt [8984,8989]
simple_stmt [8984,8989]
===
match
---
atom_expr [16865,16885]
atom_expr [16865,16885]
===
match
---
suite [28151,28767]
suite [28537,29153]
===
match
---
fstring [29100,29119]
fstring [29486,29505]
===
match
---
string: "task_a_0" [19029,19039]
string: "task_a_0" [19029,19039]
===
match
---
atom_expr [11563,11580]
atom_expr [11563,11580]
===
match
---
decorated [20460,21935]
decorated [20460,21935]
===
match
---
operator: , [21975,21976]
operator: , [21975,21976]
===
match
---
param [12783,12786]
param [12783,12786]
===
match
---
trailer [2662,2666]
trailer [2662,2666]
===
match
---
name: op [6982,6984]
name: op [6982,6984]
===
match
---
operator: = [30948,30949]
operator: = [31334,31335]
===
match
---
argument [19828,19837]
argument [19828,19837]
===
match
---
argument [24173,24179]
argument [24559,24565]
===
match
---
name: task_instances [34474,34488]
name: task_instances [34860,34874]
===
match
---
atom_expr [2805,2848]
atom_expr [2805,2848]
===
match
---
operator: = [6188,6189]
operator: = [6188,6189]
===
match
---
simple_stmt [15078,15345]
simple_stmt [15078,15345]
===
match
---
operator: = [30889,30890]
operator: = [31275,31276]
===
match
---
string: 'success' [9896,9905]
string: 'success' [9896,9905]
===
match
---
name: TEST_TASK_ID [14859,14871]
name: TEST_TASK_ID [14859,14871]
===
match
---
operator: = [24612,24613]
operator: = [24998,24999]
===
match
---
name: get_dag [25243,25250]
name: get_dag [25629,25636]
===
match
---
atom_expr [21027,21042]
atom_expr [21027,21042]
===
match
---
name: ignore_ti_state [10096,10111]
name: ignore_ti_state [10096,10111]
===
match
---
name: dag_bag [22973,22980]
name: dag_bag [23359,23366]
===
match
---
string: "task_b_0" [27986,27996]
string: "task_b_0" [28372,28382]
===
match
---
name: dag_bag_parent_child [24090,24110]
name: dag_bag_parent_child [24476,24496]
===
match
---
operator: = [6949,6950]
operator: = [6949,6950]
===
match
---
operator: , [22980,22981]
operator: , [23366,23367]
===
match
---
name: start_date [6890,6900]
name: start_date [6890,6900]
===
match
---
argument [27801,27823]
argument [28187,28209]
===
match
---
name: task_b_0 [26778,26786]
name: task_b_0 [27164,27172]
===
match
---
name: end_date [12524,12532]
name: end_date [12524,12532]
===
match
---
string: "task_a_3" [19949,19959]
string: "task_a_3" [19949,19959]
===
match
---
simple_stmt [1699,1734]
simple_stmt [1699,1734]
===
match
---
name: self [2790,2794]
name: self [2790,2794]
===
match
---
comparison [5310,5445]
comparison [5310,5445]
===
match
---
expr_stmt [31070,31132]
expr_stmt [31456,31518]
===
match
---
argument [19347,19365]
argument [19347,19365]
===
match
---
atom [14858,14886]
atom [14858,14886]
===
match
---
funcdef [17192,17314]
funcdef [17192,17314]
===
match
---
name: dag_bag [25235,25242]
name: dag_bag [25621,25628]
===
match
---
simple_stmt [25453,25494]
simple_stmt [25839,25880]
===
match
---
simple_stmt [1633,1669]
simple_stmt [1633,1669]
===
match
---
name: dag_bag [24614,24621]
name: dag_bag [25000,25007]
===
match
---
argument [14904,14930]
argument [14904,14930]
===
match
---
operator: = [19661,19662]
operator: = [19661,19662]
===
match
---
simple_stmt [12193,12483]
simple_stmt [12193,12483]
===
match
---
name: dag [33379,33382]
name: dag [33765,33768]
===
match
---
operator: , [19978,19979]
operator: , [19978,19979]
===
match
---
name: ValueError [13571,13581]
name: ValueError [13571,13581]
===
match
---
name: task_id [5627,5634]
name: task_id [5627,5634]
===
match
---
argument [9880,9906]
argument [9880,9906]
===
match
---
trailer [30209,30217]
trailer [30595,30603]
===
match
---
argument [4175,4216]
argument [4175,4216]
===
match
---
suite [3341,3664]
suite [3341,3664]
===
match
---
arglist [23328,23452]
arglist [23714,23838]
===
match
---
expr_stmt [28501,28733]
expr_stmt [28887,29119]
===
match
---
simple_stmt [11180,11258]
simple_stmt [11180,11258]
===
match
---
name: task_0 [24650,24656]
name: task_0 [25036,25042]
===
match
---
name: dag_bag_multiple [32097,32113]
name: dag_bag_multiple [32483,32499]
===
match
---
operator: + [9398,9399]
operator: + [9398,9399]
===
match
---
argument [26890,26923]
argument [27276,27309]
===
match
---
trailer [23219,23234]
trailer [23605,23620]
===
match
---
argument [25081,25101]
argument [25467,25487]
===
match
---
expr_stmt [24606,24645]
expr_stmt [24992,25031]
===
match
---
operator: = [11546,11547]
operator: = [11546,11547]
===
match
---
arglist [32362,32438]
arglist [32748,32824]
===
match
---
string: 'test_external_task_sensor_check_1' [15122,15157]
string: 'test_external_task_sensor_check_1' [15122,15157]
===
match
---
string: "task_0" [24674,24682]
string: "task_0" [25060,25068]
===
match
---
operator: , [22315,22316]
operator: , [22315,22316]
===
match
---
simple_stmt [10329,10353]
simple_stmt [10329,10353]
===
match
---
operator: = [24146,24147]
operator: = [24532,24533]
===
match
---
name: execution_date [24419,24433]
name: execution_date [24805,24819]
===
match
---
simple_stmt [29752,29785]
simple_stmt [30138,30171]
===
match
---
string: 'task_external_with_failure' [9750,9778]
string: 'task_external_with_failure' [9750,9778]
===
match
---
arglist [29192,29339]
arglist [29578,29725]
===
match
---
name: self [15723,15727]
name: self [15723,15727]
===
match
---
assert_stmt [25409,25448]
assert_stmt [25795,25834]
===
match
---
decorator [21937,21954]
decorator [21937,21954]
===
match
---
operator: , [24707,24708]
operator: , [25093,25094]
===
match
---
name: ExternalTaskSensor [2924,2942]
name: ExternalTaskSensor [2924,2942]
===
match
---
name: ignore_ti_state [6173,6188]
name: ignore_ti_state [6173,6188]
===
match
---
operator: = [17606,17607]
operator: = [17606,17607]
===
match
---
operator: = [3078,3079]
operator: = [3078,3079]
===
match
---
operator: = [6768,6769]
operator: = [6768,6769]
===
match
---
operator: , [30316,30317]
operator: , [30702,30703]
===
match
---
argument [15175,15202]
argument [15175,15202]
===
match
---
atom_expr [34148,34354]
atom_expr [34534,34740]
===
match
---
atom_expr [12199,12482]
atom_expr [12199,12482]
===
match
---
name: self [15971,15975]
name: self [15971,15975]
===
match
---
name: dag [16425,16428]
name: dag [16425,16428]
===
match
---
operator: = [19297,19298]
operator: = [19297,19298]
===
match
---
operator: , [7789,7790]
operator: , [7789,7790]
===
match
---
name: TEST_DAG_ID [13117,13128]
name: TEST_DAG_ID [13117,13128]
===
match
---
operator: == [8674,8676]
operator: == [8674,8676]
===
match
---
fstring [28998,29015]
fstring [29384,29401]
===
match
---
operator: = [19636,19637]
operator: = [19636,19637]
===
match
---
atom_expr [34205,34224]
atom_expr [34591,34610]
===
match
---
operator: , [12522,12523]
operator: , [12522,12523]
===
match
---
simple_stmt [7558,7658]
simple_stmt [7558,7658]
===
match
---
import_from [982,1037]
import_from [982,1037]
===
match
---
funcdef [18062,20458]
funcdef [18062,20458]
===
match
---
name: self [5605,5609]
name: self [5605,5609]
===
match
---
arglist [16856,16914]
arglist [16856,16914]
===
match
---
operator: = [4825,4826]
operator: = [4825,4826]
===
match
---
name: retries [9493,9500]
name: retries [9493,9500]
===
match
---
operator: = [33491,33492]
operator: = [33877,33878]
===
match
---
name: dag_0 [26747,26752]
name: dag_0 [27133,27138]
===
match
---
name: ExternalTaskSensor [9615,9633]
name: ExternalTaskSensor [9615,9633]
===
match
---
import_from [1543,1585]
import_from [1543,1585]
===
match
---
suite [3295,3664]
suite [3295,3664]
===
match
---
name: schedule_interval [20072,20089]
name: schedule_interval [20072,20089]
===
match
---
atom_expr [11737,11768]
atom_expr [11737,11768]
===
match
---
name: TEST_DAG_ID [12312,12323]
name: TEST_DAG_ID [12312,12323]
===
match
---
atom_expr [13268,13276]
atom_expr [13268,13276]
===
match
---
trailer [14585,14587]
trailer [14585,14587]
===
match
---
trailer [16968,16985]
trailer [16968,16985]
===
match
---
name: dag_external_id [7577,7592]
name: dag_external_id [7577,7592]
===
match
---
number: 0 [10569,10570]
number: 0 [10569,10570]
===
match
---
name: dag [9069,9072]
name: dag [9069,9072]
===
match
---
param [12787,12797]
param [12787,12797]
===
match
---
atom_expr [4983,5059]
atom_expr [4983,5059]
===
match
---
name: start_date [16057,16067]
name: start_date [16057,16067]
===
match
---
simple_stmt [26167,26206]
simple_stmt [26553,26592]
===
match
---
expr_stmt [13004,13287]
expr_stmt [13004,13287]
===
match
---
trailer [33213,33279]
trailer [33599,33665]
===
match
---
name: NONE [23829,23833]
name: NONE [24215,24219]
===
match
---
name: task [17720,17724]
name: task [17720,17724]
===
match
---
name: tests [1591,1596]
name: tests [1591,1596]
===
match
---
operator: , [20287,20288]
operator: , [20287,20288]
===
match
---
operator: @ [31563,31564]
operator: @ [31949,31950]
===
match
---
expr_stmt [25701,25722]
expr_stmt [26087,26108]
===
match
---
name: external_dag_id [3020,3035]
name: external_dag_id [3020,3035]
===
match
---
atom [5932,5943]
atom [5932,5943]
===
match
---
operator: = [8041,8042]
operator: = [8041,8042]
===
match
---
operator: = [19354,19355]
operator: = [19354,19355]
===
match
---
operator: = [32397,32398]
operator: = [32783,32784]
===
match
---
atom_expr [3640,3648]
atom_expr [3640,3648]
===
match
---
operator: == [21757,21759]
operator: == [21757,21759]
===
match
---
name: days [24173,24177]
name: days [24559,24563]
===
match
---
argument [19676,19698]
argument [19676,19698]
===
match
---
name: AirflowException [4941,4957]
name: AirflowException [4941,4957]
===
match
---
atom_expr [7607,7616]
atom_expr [7607,7616]
===
match
---
argument [7594,7616]
argument [7594,7616]
===
match
---
name: ExternalTaskMarker [29156,29174]
name: ExternalTaskMarker [29542,29560]
===
match
---
argument [19961,19978]
argument [19961,19978]
===
match
---
argument [34168,34185]
argument [34554,34571]
===
match
---
name: dag_1 [21528,21533]
name: dag_1 [21528,21533]
===
match
---
name: end_date [35033,35041]
name: end_date [35419,35427]
===
match
---
operator: = [16419,16420]
operator: = [16419,16420]
===
match
---
operator: , [10571,10572]
operator: , [10571,10572]
===
match
---
name: dag_0 [30194,30199]
name: dag_0 [30580,30585]
===
match
---
name: get_task [29806,29814]
name: get_task [30192,30200]
===
match
---
name: delta [34046,34051]
name: delta [34432,34437]
===
match
---
operator: -> [27649,27651]
operator: -> [28035,28037]
===
match
---
string: "agg_dag" [30895,30904]
string: "agg_dag" [31281,31290]
===
match
---
operator: = [14857,14858]
operator: = [14857,14858]
===
match
---
operator: , [16760,16761]
operator: , [16760,16761]
===
match
---
fstring_expr [31292,31295]
fstring_expr [31678,31681]
===
match
---
atom_expr [7181,7257]
atom_expr [7181,7257]
===
match
---
operator: , [3216,3217]
operator: , [3216,3217]
===
match
---
simple_stmt [12629,12730]
simple_stmt [12629,12730]
===
match
---
dictorsetmaker [2046,2092]
dictorsetmaker [2046,2092]
===
match
---
name: QUEUED [25398,25404]
name: QUEUED [25784,25790]
===
match
---
operator: = [8280,8281]
operator: = [8280,8281]
===
match
---
name: timedelta [12171,12180]
name: timedelta [12171,12180]
===
match
---
operator: , [21164,21165]
operator: , [21164,21165]
===
match
---
name: dag_bag_head_tail [34910,34927]
name: dag_bag_head_tail [35296,35313]
===
match
---
operator: = [9500,9501]
operator: = [9500,9501]
===
match
---
trailer [3139,3143]
trailer [3139,3143]
===
match
---
trailer [2279,2283]
trailer [2279,2283]
===
match
---
assert_stmt [12885,12957]
assert_stmt [12885,12957]
===
match
---
argument [20189,20222]
argument [20189,20222]
===
match
---
trailer [2295,2299]
trailer [2295,2299]
===
match
---
simple_stmt [26306,26355]
simple_stmt [26692,26741]
===
match
---
atom [30354,30375]
atom [30740,30761]
===
match
---
name: end_date [6150,6158]
name: end_date [6150,6158]
===
match
---
simple_stmt [19452,19600]
simple_stmt [19452,19600]
===
match
---
name: execution_date [8763,8777]
name: execution_date [8763,8777]
===
match
---
arglist [16057,16125]
arglist [16057,16125]
===
match
---
param [22006,22018]
param [22006,22018]
===
match
---
operator: , [17423,17424]
operator: , [17423,17424]
===
match
---
argument [33176,33198]
argument [33562,33584]
===
match
---
argument [21297,21326]
argument [21297,21326]
===
match
---
name: self [7607,7611]
name: self [7607,7611]
===
match
---
trailer [22629,22631]
trailer [23015,23017]
===
match
---
trailer [4110,4127]
trailer [4110,4127]
===
match
---
operator: , [10071,10072]
operator: , [10071,10072]
===
match
---
operator: = [1837,1838]
operator: = [1837,1838]
===
match
---
name: session [23444,23451]
name: session [23830,23837]
===
match
---
atom_expr [33456,33473]
atom_expr [33842,33859]
===
match
---
operator: = [8097,8098]
operator: = [8097,8098]
===
match
---
string: 'test_external_dag_sensor_check' [7027,7059]
string: 'test_external_dag_sensor_check' [7027,7059]
===
match
---
trailer [25069,25080]
trailer [25455,25466]
===
match
---
trailer [11183,11187]
trailer [11183,11187]
===
match
---
atom_expr [17040,17059]
atom_expr [17040,17059]
===
match
---
argument [8295,8339]
argument [8295,8339]
===
match
---
trailer [26380,26407]
trailer [26766,26793]
===
match
---
operator: = [30325,30326]
operator: = [30711,30712]
===
match
---
argument [18943,18966]
argument [18943,18966]
===
match
---
trailer [24555,24565]
trailer [24941,24951]
===
match
---
name: State [24566,24571]
name: State [24952,24957]
===
match
---
name: agg_dag [31056,31063]
name: agg_dag [31442,31449]
===
match
---
comparison [30344,30586]
comparison [30730,30972]
===
match
---
trailer [16052,16056]
trailer [16052,16056]
===
match
---
trailer [33813,33821]
trailer [34199,34207]
===
match
---
operator: = [25785,25786]
operator: = [26171,26172]
===
match
---
arith_expr [8065,8100]
arith_expr [8065,8100]
===
match
---
name: mark [31546,31550]
name: mark [31932,31936]
===
match
---
name: dag_0 [26695,26700]
name: dag_0 [27081,27086]
===
match
---
suite [6101,6195]
suite [6101,6195]
===
match
---
name: run_tasks [29729,29738]
name: run_tasks [30115,30124]
===
match
---
name: external_task_id [20189,20205]
name: external_task_id [20189,20205]
===
match
---
parameters [29996,30012]
parameters [30382,30398]
===
match
---
arglist [34996,35125]
arglist [35382,35511]
===
match
---
suite [21534,21816]
suite [21534,21816]
===
match
---
operator: , [11620,11621]
operator: , [11620,11621]
===
match
---
operator: , [21773,21774]
operator: , [21773,21774]
===
match
---
comparison [17982,18043]
comparison [17982,18043]
===
match
---
operator: = [2677,2678]
operator: = [2677,2678]
===
match
---
name: start_date [27776,27786]
name: start_date [28162,28172]
===
match
---
operator: = [7251,7252]
operator: = [7251,7252]
===
match
---
operator: , [2323,2324]
operator: , [2323,2324]
===
match
---
operator: + [8794,8795]
operator: + [8794,8795]
===
match
---
testlist_comp [30354,30531]
testlist_comp [30740,30917]
===
match
---
operator: = [2363,2364]
operator: = [2363,2364]
===
match
---
operator: , [13817,13818]
operator: , [13817,13818]
===
match
---
expr_stmt [30795,30876]
expr_stmt [31181,31262]
===
match
---
atom_expr [31936,31971]
atom_expr [32322,32357]
===
match
---
trailer [21040,21042]
trailer [21040,21042]
===
match
---
name: task_id [33545,33552]
name: task_id [33931,33938]
===
match
---
operator: , [3855,3856]
operator: , [3855,3856]
===
match
---
trailer [4390,4460]
trailer [4390,4460]
===
match
---
string: 'success' [10601,10610]
string: 'success' [10601,10610]
===
match
---
operator: = [33574,33575]
operator: = [33960,33961]
===
match
---
parameters [23944,23975]
parameters [24330,24361]
===
match
---
atom_expr [30202,30226]
atom_expr [30588,30612]
===
match
---
trailer [4877,4881]
trailer [4877,4881]
===
match
---
name: external_dag_id [9688,9703]
name: external_dag_id [9688,9703]
===
match
---
name: task_id [19347,19354]
name: task_id [19347,19354]
===
match
---
name: DagRunType [34290,34300]
name: DagRunType [34676,34686]
===
match
---
funcdef [21954,22731]
funcdef [21954,23117]
===
match
---
atom_expr [8714,8722]
atom_expr [8714,8722]
===
match
---
name: dag [33283,33286]
name: dag [33669,33672]
===
match
---
operator: , [3523,3524]
operator: , [3523,3524]
===
match
---
arglist [26074,26117]
arglist [26460,26503]
===
match
---
suite [14024,14510]
suite [14024,14510]
===
match
---
name: test_external_task_sensor_fn_multiple_args [11870,11912]
name: test_external_task_sensor_fn_multiple_args [11870,11912]
===
match
---
operator: , [17518,17519]
operator: , [17518,17519]
===
match
---
name: dag [17634,17637]
name: dag [17634,17637]
===
match
---
argument [22587,22602]
argument [22973,22988]
===
match
---
operator: = [25708,25709]
operator: = [26094,26095]
===
match
---
argument [28383,28411]
argument [28769,28797]
===
match
---
name: depth [29210,29215]
name: depth [29596,29601]
===
match
---
arith_expr [29110,29117]
arith_expr [29496,29503]
===
match
---
operator: , [29938,29939]
operator: , [30324,30325]
===
match
---
arglist [19095,19197]
arglist [19095,19197]
===
match
---
atom [4759,4769]
atom [4759,4769]
===
match
---
name: date [17128,17132]
name: date [17128,17132]
===
match
---
operator: = [9979,9980]
operator: = [9979,9980]
===
match
---
arglist [11188,11256]
arglist [11188,11256]
===
match
---
name: DEFAULT_DATE [28858,28870]
name: DEFAULT_DATE [29244,29256]
===
match
---
name: task_id [3390,3397]
name: task_id [3390,3397]
===
match
---
operator: = [13712,13713]
operator: = [13712,13713]
===
match
---
name: task_external_with_failure [8222,8248]
name: task_external_with_failure [8222,8248]
===
match
---
simple_stmt [12738,12762]
simple_stmt [12738,12762]
===
match
---
simple_stmt [21900,21914]
simple_stmt [21900,21914]
===
match
---
operator: = [25291,25292]
operator: = [25677,25678]
===
match
---
trailer [31335,31342]
trailer [31721,31728]
===
match
---
atom [5894,5904]
atom [5894,5904]
===
match
---
name: dag_0 [19045,19050]
name: dag_0 [19045,19050]
===
match
---
operator: , [10611,10612]
operator: , [10611,10612]
===
match
---
argument [29276,29303]
argument [29662,29689]
===
match
---
name: ti_b_3_date_1 [26381,26394]
name: ti_b_3_date_1 [26767,26780]
===
match
---
testlist_comp [3080,3116]
testlist_comp [3080,3116]
===
match
---
argument [29235,29258]
argument [29621,29644]
===
match
---
string: "task_a_0" [23748,23758]
string: "task_a_0" [24134,24144]
===
match
---
argument [4990,5013]
argument [4990,5013]
===
match
---
operator: = [34521,34522]
operator: = [34907,34908]
===
match
---
operator: = [21233,21234]
operator: = [21233,21234]
===
match
---
name: test_time_sensor [4111,4127]
name: test_time_sensor [4111,4127]
===
match
---
name: ExternalTaskSensor [19715,19733]
name: ExternalTaskSensor [19715,19733]
===
match
---
operator: = [30278,30279]
operator: = [30664,30665]
===
match
---
name: DEFAULT_DATE [11802,11814]
name: DEFAULT_DATE [11802,11814]
===
match
---
argument [2879,2909]
argument [2879,2909]
===
match
---
name: recursion_depth [21425,21440]
name: recursion_depth [21425,21440]
===
match
---
expr_stmt [27739,27748]
expr_stmt [28125,28134]
===
match
---
name: dag_0 [23714,23719]
name: dag_0 [24100,24105]
===
match
---
name: DummyOperator [33531,33544]
name: DummyOperator [33917,33930]
===
match
---
trailer [33544,33560]
trailer [33930,33946]
===
match
---
operator: , [34224,34225]
operator: , [34610,34611]
===
match
---
trailer [21561,21815]
trailer [21561,21815]
===
match
---
trailer [13028,13287]
trailer [13028,13287]
===
match
---
operator: , [22999,23000]
operator: , [23385,23386]
===
match
---
name: dag_id [30552,30558]
name: dag_id [30938,30944]
===
match
---
name: state [6944,6949]
name: state [6944,6949]
===
match
---
name: schedule_interval [28210,28227]
name: schedule_interval [28596,28613]
===
match
---
name: ti_a_0_date_0 [26124,26137]
name: ti_a_0_date_0 [26510,26523]
===
match
---
name: output [6439,6445]
name: output [6439,6445]
===
match
---
name: task_b_1 [19810,19818]
name: task_b_1 [19810,19818]
===
match
---
operator: , [4216,4217]
operator: , [4216,4217]
===
match
---
name: day_1 [21494,21499]
name: day_1 [21494,21499]
===
match
---
trailer [19422,19430]
trailer [19422,19430]
===
match
---
arglist [20139,20233]
arglist [20139,20233]
===
match
---
name: dag_bag [33806,33813]
name: dag_bag [34192,34199]
===
match
---
for_stmt [24415,24581]
for_stmt [24801,24967]
===
match
---
operator: = [15556,15557]
operator: = [15556,15557]
===
match
---
operator: = [34123,34124]
operator: = [34509,34510]
===
match
---
name: dag [11686,11689]
name: dag [11686,11689]
===
match
---
argument [17425,17448]
argument [17425,17448]
===
match
---
operator: , [9502,9503]
operator: , [9502,9503]
===
match
---
argument [10203,10226]
argument [10203,10226]
===
match
---
trailer [24664,24673]
trailer [25050,25059]
===
match
---
string: "success" [4798,4807]
string: "success" [4798,4807]
===
match
---
operator: = [7728,7729]
operator: = [7728,7729]
===
match
---
simple_stmt [34553,34569]
simple_stmt [34939,34955]
===
match
---
name: end_date [10073,10081]
name: end_date [10073,10081]
===
match
---
name: timedelta [32057,32066]
name: timedelta [32443,32452]
===
match
---
trailer [25859,25895]
trailer [26245,26281]
===
match
---
number: 25 [31209,31211]
number: 25 [31595,31597]
===
match
---
expr_stmt [32025,32078]
expr_stmt [32411,32464]
===
match
---
trailer [34870,34876]
trailer [35256,35262]
===
match
---
argument [2489,2530]
argument [2489,2530]
===
match
---
name: self [2857,2861]
name: self [2857,2861]
===
match
---
argument [13224,13250]
argument [13224,13250]
===
match
---
fstring_start: f" [34328,34330]
fstring_start: f" [34714,34716]
===
match
---
operator: , [19113,19114]
operator: , [19113,19114]
===
match
---
name: DEFAULT_DATE [21123,21135]
name: DEFAULT_DATE [21123,21135]
===
match
---
fstring_end: " [28620,28621]
fstring_end: " [29006,29007]
===
match
---
operator: , [27996,27997]
operator: , [28382,28383]
===
match
---
operator: = [11151,11152]
operator: = [11151,11152]
===
match
---
name: ti_a_0 [23735,23741]
name: ti_a_0 [24121,24127]
===
match
---
name: ValueError [3753,3763]
name: ValueError [3753,3763]
===
match
---
argument [8102,8122]
argument [8102,8122]
===
match
---
name: days [32067,32071]
name: days [32453,32457]
===
match
---
simple_stmt [2919,3155]
simple_stmt [2919,3155]
===
match
---
name: execution_delta [10543,10558]
name: execution_delta [10543,10558]
===
match
---
string: 'execution_date' [12123,12139]
string: 'execution_date' [12123,12139]
===
match
---
operator: , [29217,29218]
operator: , [29603,29604]
===
match
---
param [23074,23088]
param [23460,23474]
===
match
---
operator: , [9952,9953]
operator: , [9952,9953]
===
match
---
argument [4230,4257]
argument [4230,4257]
===
match
---
suite [21217,21454]
suite [21217,21454]
===
match
---
name: types [1562,1567]
name: types [1562,1567]
===
match
---
name: ds_nodash [12838,12847]
name: ds_nodash [12838,12847]
===
match
---
atom [30416,30437]
atom [30802,30823]
===
match
---
simple_stmt [6727,6830]
simple_stmt [6727,6830]
===
match
---
name: self [16192,16196]
name: self [16192,16196]
===
match
---
atom_expr [11350,11709]
atom_expr [11350,11709]
===
match
---
name: TEST_DAG_ID [10475,10486]
name: TEST_DAG_ID [10475,10486]
===
match
---
name: get_dagrun [25168,25178]
name: get_dagrun [25554,25564]
===
match
---
testlist_comp [30448,30467]
testlist_comp [30834,30853]
===
match
---
name: SUCCESS [34217,34224]
name: SUCCESS [34603,34610]
===
match
---
argument [3541,3571]
argument [3541,3571]
===
match
---
name: run [22583,22586]
name: run [22969,22972]
===
match
---
name: task_b_2 [20206,20214]
name: task_b_2 [20206,20214]
===
match
---
atom_expr [26226,26248]
atom_expr [26612,26634]
===
match
---
operator: } [28359,28360]
operator: } [28745,28746]
===
match
---
simple_stmt [16499,16576]
simple_stmt [16499,16576]
===
match
---
operator: = [33378,33379]
operator: = [33764,33765]
===
match
---
simple_stmt [33524,33561]
simple_stmt [33910,33947]
===
match
---
atom [8583,8872]
atom [8583,8872]
===
match
---
fstring_string: task_b_ [28452,28459]
fstring_string: task_b_ [28838,28845]
===
match
---
name: timedelta [12920,12929]
name: timedelta [12920,12929]
===
match
---
simple_stmt [12491,12569]
simple_stmt [12491,12569]
===
match
---
name: start [31138,31143]
name: start [31524,31529]
===
match
---
comparison [34973,35149]
comparison [35359,35535]
===
match
---
operator: , [24740,24741]
operator: , [25126,25127]
===
match
---
trailer [20037,20095]
trailer [20037,20095]
===
match
---
trailer [25928,25937]
trailer [26314,26323]
===
match
---
name: dag_bag [31528,31535]
name: dag_bag [31914,31921]
===
match
---
operator: = [29758,29759]
operator: = [30144,30145]
===
match
---
trailer [17086,17103]
trailer [17086,17103]
===
match
---
operator: , [33760,33761]
operator: , [34146,34147]
===
match
---
simple_stmt [23793,23835]
simple_stmt [24179,24221]
===
match
---
string: "start" [31168,31175]
string: "start" [31554,31561]
===
match
---
name: bash_command [7759,7771]
name: bash_command [7759,7771]
===
match
---
parameters [12782,12817]
parameters [12782,12817]
===
match
---
name: self [2805,2809]
name: self [2805,2809]
===
match
---
operator: = [31037,31038]
operator: = [31423,31424]
===
match
---
name: failed_states [3965,3978]
name: failed_states [3965,3978]
===
match
---
operator: = [9417,9418]
operator: = [9417,9418]
===
match
---
name: day_1 [21394,21399]
name: day_1 [21394,21399]
===
match
---
suite [27832,28117]
suite [28218,28503]
===
match
---
operator: = [33342,33343]
operator: = [33728,33729]
===
match
---
name: day_1 [24438,24443]
name: day_1 [24824,24829]
===
match
---
name: DEFAULT_DATE [5221,5233]
name: DEFAULT_DATE [5221,5233]
===
match
---
argument [22408,22423]
argument [22408,22423]
===
match
---
annassign [23208,23293]
annassign [23594,23679]
===
match
---
string: 'INFO:airflow.task.operators:Poking for tasks [\'time_sensor_check\']' [5097,5167]
string: 'INFO:airflow.task.operators:Poking for tasks [\'time_sensor_check\']' [5097,5167]
===
match
---
dotted_name [1176,1205]
dotted_name [1176,1205]
===
match
---
number: 1 [28618,28619]
number: 1 [29004,29005]
===
match
---
atom_expr [29729,29747]
atom_expr [30115,30133]
===
match
---
name: session [22416,22423]
name: session [22416,22423]
===
match
---
string: 'test_external_task_sensor_check' [2497,2530]
string: 'test_external_task_sensor_check' [2497,2530]
===
match
---
name: DAG [2113,2116]
name: DAG [2113,2116]
===
match
---
string: "task_b_2" [30519,30529]
string: "task_b_2" [30905,30915]
===
match
---
expr_stmt [31222,31494]
expr_stmt [31608,31880]
===
match
---
simple_stmt [25901,25938]
simple_stmt [26287,26324]
===
match
---
arglist [25179,25216]
arglist [25565,25602]
===
match
---
name: external_task_id [14341,14357]
name: external_task_id [14341,14357]
===
match
---
simple_stmt [23298,23459]
simple_stmt [23684,23845]
===
match
---
operator: = [29704,29705]
operator: = [30090,30091]
===
match
---
operator: = [7571,7572]
operator: = [7571,7572]
===
match
---
suite [11770,11861]
suite [11770,11861]
===
match
---
name: DEFAULT_DATE [2334,2346]
name: DEFAULT_DATE [2334,2346]
===
match
---
operator: = [20276,20277]
operator: = [20276,20277]
===
match
---
trailer [23828,23833]
trailer [24214,24219]
===
match
---
string: "child_task1" [17607,17620]
string: "child_task1" [17607,17620]
===
match
---
trailer [6742,6829]
trailer [6742,6829]
===
match
---
number: 2015 [1657,1661]
number: 2015 [1657,1661]
===
match
---
simple_stmt [856,870]
simple_stmt [856,870]
===
match
---
simple_stmt [27739,27749]
simple_stmt [28125,28135]
===
match
---
simple_stmt [33569,33772]
simple_stmt [33955,34158]
===
match
---
name: date_1 [25727,25733]
name: date_1 [26113,26119]
===
match
---
operator: , [4687,4688]
operator: , [4687,4688]
===
match
---
name: end_date [6780,6788]
name: end_date [6780,6788]
===
match
---
argument [33252,33278]
argument [33638,33664]
===
match
---
parameters [27636,27648]
parameters [28022,28034]
===
match
---
name: dag_0 [29752,29757]
name: dag_0 [30138,30143]
===
match
---
name: dag [2107,2110]
name: dag [2107,2110]
===
match
---
strings [6232,6405]
strings [6232,6405]
===
match
---
operator: , [35124,35125]
operator: , [35510,35511]
===
match
---
name: TaskInstance [34431,34443]
name: TaskInstance [34817,34829]
===
match
---
trailer [24172,24180]
trailer [24558,24566]
===
match
---
argument [16506,16529]
argument [16506,16529]
===
match
---
trailer [30745,30790]
trailer [31131,31176]
===
match
---
name: ignore_ti_state [10251,10266]
name: ignore_ti_state [10251,10266]
===
match
---
atom_expr [14564,14587]
atom_expr [14564,14587]
===
match
---
operator: , [1661,1662]
operator: , [1661,1662]
===
match
---
operator: = [22376,22377]
operator: = [22376,22377]
===
match
---
name: day_1 [24115,24120]
name: day_1 [24501,24506]
===
match
---
operator: , [5036,5037]
operator: , [5036,5037]
===
match
---
trailer [5243,5245]
trailer [5243,5245]
===
match
---
trailer [6430,6432]
trailer [6430,6432]
===
match
---
name: ti_a_0_date_0 [26275,26288]
name: ti_a_0_date_0 [26661,26674]
===
match
---
atom_expr [2924,3154]
atom_expr [2924,3154]
===
match
---
assert_stmt [32341,32445]
assert_stmt [32727,32831]
===
match
---
string: "dag_1" [28014,28021]
string: "dag_1" [28400,28407]
===
match
---
trailer [31247,31494]
trailer [31633,31880]
===
match
---
name: self [12614,12618]
name: self [12614,12618]
===
match
---
argument [15495,15522]
argument [15495,15522]
===
match
---
name: DAG [7573,7576]
name: DAG [7573,7576]
===
match
---
simple_stmt [818,855]
simple_stmt [818,855]
===
match
---
name: pytest [3739,3745]
name: pytest [3739,3745]
===
match
---
name: dag_bag [29696,29703]
name: dag_bag [30082,30089]
===
match
---
atom_expr [4018,4026]
atom_expr [4018,4026]
===
match
---
operator: = [5960,5961]
operator: = [5960,5961]
===
match
---
name: ignore_ti_state [16554,16569]
name: ignore_ti_state [16554,16569]
===
match
---
name: value [6505,6510]
name: value [6505,6510]
===
match
---
operator: , [20361,20362]
operator: , [20361,20362]
===
match
---
atom_expr [1911,1928]
atom_expr [1911,1928]
===
match
---
operator: { [28357,28358]
operator: { [28743,28744]
===
match
---
name: TEST_TASK_ID_ALTERNATE [1734,1756]
name: TEST_TASK_ID_ALTERNATE [1734,1756]
===
match
---
name: tail [33569,33573]
name: tail [33955,33959]
===
match
---
name: DEFAULT_DATE [8281,8293]
name: DEFAULT_DATE [8281,8293]
===
match
---
dotted_name [1548,1567]
dotted_name [1548,1567]
===
match
---
name: task_id [7721,7728]
name: task_id [7721,7728]
===
match
---
name: day_2 [25096,25101]
name: day_2 [25482,25487]
===
match
---
trailer [25242,25250]
trailer [25628,25636]
===
match
---
operator: == [18027,18029]
operator: == [18027,18029]
===
match
---
name: DagBag [18865,18871]
name: DagBag [18865,18871]
===
match
---
operator: = [15899,15900]
operator: = [15899,15900]
===
match
---
name: include_examples [21086,21102]
name: include_examples [21086,21102]
===
match
---
operator: , [13910,13911]
operator: , [13910,13911]
===
match
---
atom_expr [12851,12872]
atom_expr [12851,12872]
===
match
---
arglist [34168,34344]
arglist [34554,34730]
===
match
---
name: op [2660,2662]
name: op [2660,2662]
===
match
---
name: ti [22580,22582]
name: ti [22966,22968]
===
match
---
operator: , [18966,18967]
operator: , [18966,18967]
===
match
---
trailer [18933,18991]
trailer [18933,18991]
===
match
---
simple_stmt [24688,24775]
simple_stmt [25074,25161]
===
match
---
atom_expr [14655,14680]
atom_expr [14655,14680]
===
match
---
name: day_2 [24265,24270]
name: day_2 [24651,24656]
===
match
---
name: session [22006,22013]
name: session [22006,22013]
===
match
---
atom_expr [10181,10272]
atom_expr [10181,10272]
===
match
---
name: exceptions [925,935]
name: exceptions [925,935]
===
match
---
string: 'success' [14920,14929]
string: 'success' [14920,14929]
===
match
---
string: 'test_external_task_sensor_check' [16252,16285]
string: 'test_external_task_sensor_check' [16252,16285]
===
match
---
atom_expr [30171,30189]
atom_expr [30557,30575]
===
match
---
dotted_name [917,935]
dotted_name [917,935]
===
match
---
arglist [13632,13941]
arglist [13632,13941]
===
match
---
name: execution_date [25179,25193]
name: execution_date [25565,25579]
===
match
---
arglist [27685,27728]
arglist [28071,28114]
===
match
---
trailer [32355,32361]
trailer [32741,32747]
===
match
---
name: self [10787,10791]
name: self [10787,10791]
===
match
---
simple_stmt [4568,4846]
simple_stmt [4568,4846]
===
match
---
argument [9516,9525]
argument [9516,9525]
===
match
---
atom_expr [19242,19303]
atom_expr [19242,19303]
===
match
---
arglist [19347,19441]
arglist [19347,19441]
===
match
---
name: state [22927,22932]
name: state [23313,23318]
===
match
---
argument [27998,28021]
argument [28384,28407]
===
match
---
operator: , [5795,5796]
operator: , [5795,5796]
===
match
---
name: timedelta [8080,8089]
name: timedelta [8080,8089]
===
match
---
expr_stmt [30881,30958]
expr_stmt [31267,31344]
===
match
---
name: self [2143,2147]
name: self [2143,2147]
===
match
---
argument [6756,6778]
argument [6756,6778]
===
match
---
name: ExternalTaskSensor [3778,3796]
name: ExternalTaskSensor [3778,3796]
===
match
---
name: dag [21890,21893]
name: dag [21890,21893]
===
match
---
atom_expr [33379,33389]
atom_expr [33765,33775]
===
match
---
operator: , [15953,15954]
operator: , [15953,15954]
===
match
---
funcdef [22952,23459]
funcdef [23338,23845]
===
match
---
name: task_b_1 [19616,19624]
name: task_b_1 [19616,19624]
===
match
---
testlist_comp [20342,20368]
testlist_comp [20342,20368]
===
match
---
name: op [15738,15740]
name: op [15738,15740]
===
match
---
operator: = [30756,30757]
operator: = [31142,31143]
===
match
---
argument [5768,5795]
argument [5768,5795]
===
match
---
name: self [14033,14037]
name: self [14033,14037]
===
match
---
simple_stmt [23096,23197]
simple_stmt [23482,23583]
===
match
---
name: QUEUED [25354,25360]
name: QUEUED [25740,25746]
===
match
---
name: DEFAULT_DATE [30835,30847]
name: DEFAULT_DATE [31221,31233]
===
match
---
name: provide_session [33868,33883]
name: provide_session [34254,34269]
===
match
---
operator: , [33829,33830]
operator: , [34215,34216]
===
match
---
operator: = [23771,23772]
operator: = [24157,24158]
===
match
---
name: DEFAULT_DATE [10082,10094]
name: DEFAULT_DATE [10082,10094]
===
match
---
trailer [27849,27856]
trailer [28235,28242]
===
match
---
name: test_external_task_sensor_error_task_id_and_task_ids [13965,14017]
name: test_external_task_sensor_error_task_id_and_task_ids [13965,14017]
===
match
---
operator: } [28569,28570]
operator: } [28955,28956]
===
match
---
name: external_dag_id [14795,14810]
name: external_dag_id [14795,14810]
===
match
---
name: AirflowException [29850,29866]
name: AirflowException [30236,30252]
===
match
---
arglist [31160,31188]
arglist [31546,31574]
===
match
---
atom_expr [4106,4129]
atom_expr [4106,4129]
===
match
---
operator: = [9998,9999]
operator: = [9998,9999]
===
match
---
name: DummyOperator [19007,19020]
name: DummyOperator [19007,19020]
===
match
---
argument [15830,15869]
argument [15830,15869]
===
match
---
string: 'success' [14454,14463]
string: 'success' [14454,14463]
===
match
---
argument [24250,24270]
argument [24636,24656]
===
match
---
name: start_date [10203,10213]
name: start_date [10203,10213]
===
match
---
operator: = [30783,30784]
operator: = [31169,31170]
===
match
---
argument [8806,8815]
argument [8806,8815]
===
match
---
atom_expr [34973,35135]
atom_expr [35359,35521]
===
match
---
arglist [23861,23879]
arglist [24247,24265]
===
match
---
operator: = [30916,30917]
operator: = [31302,31303]
===
match
---
funcdef [29952,30587]
funcdef [30338,30973]
===
match
---
string: "task_b_3" [26237,26247]
string: "task_b_3" [26623,26633]
===
match
---
name: task_a_2 [20000,20008]
name: task_a_2 [20000,20008]
===
match
---
assert_stmt [25321,25360]
assert_stmt [25707,25746]
===
match
---
simple_stmt [25942,25980]
simple_stmt [26328,26366]
===
match
---
name: provide_session [23884,23899]
name: provide_session [24270,24285]
===
match
---
trailer [21399,21409]
trailer [21399,21409]
===
match
---
decorator [33867,33884]
decorator [34253,34270]
===
match
---
operator: { [28567,28568]
operator: { [28953,28954]
===
match
---
operator: , [33949,33950]
operator: , [34335,34336]
===
match
---
number: 1 [12935,12936]
number: 1 [12935,12936]
===
match
---
shift_expr [20000,20020]
shift_expr [20000,20020]
===
match
---
operator: { [17241,17242]
operator: { [17241,17242]
===
match
---
trailer [15096,15344]
trailer [15096,15344]
===
match
---
argument [9837,9846]
argument [9837,9846]
===
match
---
operator: { [17114,17115]
operator: { [17114,17115]
===
match
---
argument [11445,11472]
argument [11445,11472]
===
match
---
fstring_string: task_b_ [29102,29109]
fstring_string: task_b_ [29488,29495]
===
match
---
fstring_expr [28179,28182]
fstring_expr [28565,28568]
===
match
---
argument [11382,11431]
argument [11382,11431]
===
match
---
trailer [16011,16018]
trailer [16011,16018]
===
match
---
argument [31177,31188]
argument [31563,31574]
===
match
---
operator: , [26085,26086]
operator: , [26471,26472]
===
match
---
name: DEFAULT_DATE [6159,6171]
name: DEFAULT_DATE [6159,6171]
===
match
---
string: "Maximum recursion depth 3" [29874,29901]
string: "Maximum recursion depth 3" [30260,30287]
===
match
---
operator: = [25036,25037]
operator: = [25422,25423]
===
match
---
operator: = [8117,8118]
operator: = [8117,8118]
===
match
---
argument [33608,33622]
argument [33994,34008]
===
match
---
trailer [20386,20394]
trailer [20386,20394]
===
match
---
dotted_name [1308,1348]
dotted_name [1308,1348]
===
match
---
atom [30548,30571]
atom [30934,30957]
===
match
---
name: test_external_task_sensor_failed_states [4051,4090]
name: test_external_task_sensor_failed_states [4051,4090]
===
match
---
param [9390,9392]
param [9390,9392]
===
match
---
name: self [4106,4110]
name: self [4106,4110]
===
match
---
suite [10168,10273]
suite [10168,10273]
===
match
---
operator: , [30486,30487]
operator: , [30872,30873]
===
match
---
simple_stmt [10787,10811]
simple_stmt [10787,10811]
===
match
---
name: tis [23773,23776]
name: tis [24159,24162]
===
match
---
atom_expr [3309,3340]
atom_expr [3309,3340]
===
match
---
simple_stmt [29421,29460]
simple_stmt [29807,29846]
===
match
---
simple_stmt [33806,33845]
simple_stmt [34192,34231]
===
match
---
comparison [25372,25404]
comparison [25758,25790]
===
match
---
operator: == [25477,25479]
operator: == [25863,25865]
===
match
---
suite [22475,22715]
suite [22861,23101]
===
match
---
atom_expr [20034,20095]
atom_expr [20034,20095]
===
match
---
param [21717,21731]
param [21717,21731]
===
match
---
simple_stmt [34467,34500]
simple_stmt [34853,34886]
===
match
---
string: 'invalid_state' [15595,15610]
string: 'invalid_state' [15595,15610]
===
match
---
argument [21605,21633]
argument [21605,21633]
===
match
---
name: external_dag_id [10964,10979]
name: external_dag_id [10964,10979]
===
match
---
name: start_date [34996,35006]
name: start_date [35382,35392]
===
match
---
operator: , [30299,30300]
operator: , [30685,30686]
===
match
---
argument [9087,9109]
argument [9087,9109]
===
match
---
name: dag [27828,27831]
name: dag [28214,28217]
===
match
---
simple_stmt [26062,26119]
simple_stmt [26448,26505]
===
match
---
trailer [34060,34067]
trailer [34446,34453]
===
match
---
simple_stmt [29729,29748]
simple_stmt [30115,30134]
===
match
---
name: dag [31472,31475]
name: dag [31858,31861]
===
match
---
argument [19491,19509]
argument [19491,19509]
===
match
---
operator: , [6888,6889]
operator: , [6888,6889]
===
match
---
import_from [912,981]
import_from [912,981]
===
match
---
name: run_tasks [25850,25859]
name: run_tasks [26236,26245]
===
match
---
term [6232,6432]
term [6232,6432]
===
match
---
trailer [8608,8614]
trailer [8608,8614]
===
match
---
operator: = [17504,17505]
operator: = [17504,17505]
===
match
---
argument [24982,25002]
argument [25368,25388]
===
match
---
name: DummyOperator [31146,31159]
name: DummyOperator [31532,31545]
===
match
---
argument [15267,15299]
argument [15267,15299]
===
match
---
name: DEV_NULL [18883,18891]
name: DEV_NULL [18883,18891]
===
match
---
trailer [16985,16987]
trailer [16985,16987]
===
match
---
name: dag_0 [30242,30247]
name: dag_0 [30628,30633]
===
match
---
name: raises [3316,3322]
name: raises [3316,3322]
===
match
---
comparison [12838,12872]
comparison [12838,12872]
===
match
---
trailer [8328,8339]
trailer [8328,8339]
===
match
---
string: 'test_external_task_sensor_check' [4183,4216]
string: 'test_external_task_sensor_check' [4183,4216]
===
match
---
operator: >> [28105,28107]
operator: >> [28491,28493]
===
match
---
name: dag_2 [19984,19989]
name: dag_2 [19984,19989]
===
match
---
string: """     Create a DagBag containing two DAGs, linked by multiple ExternalTaskMarker.     """ [30633,30724]
string: """     Create a DagBag containing two DAGs, linked by multiple ExternalTaskMarker.     """ [31019,31110]
===
match
---
name: add [34371,34374]
name: add [34757,34760]
===
match
---
name: test_catch_invalid_allowed_states [14985,15018]
name: test_catch_invalid_allowed_states [14985,15018]
===
match
---
operator: = [23338,23339]
operator: = [23724,23725]
===
match
---
name: schedule_interval [18968,18985]
name: schedule_interval [18968,18985]
===
match
---
comparison [5097,5258]
comparison [5097,5258]
===
match
---
operator: = [11689,11690]
operator: = [11689,11690]
===
match
---
operator: , [11698,11699]
operator: , [11698,11699]
===
match
---
number: 3 [19185,19186]
number: 3 [19185,19186]
===
match
---
atom_expr [26290,26300]
atom_expr [26676,26686]
===
match
---
name: allowed_states [10585,10599]
name: allowed_states [10585,10599]
===
match
---
name: dag [28270,28273]
name: dag [28656,28659]
===
match
---
atom_expr [34467,34499]
atom_expr [34853,34885]
===
match
---
name: assertLogs [5999,6009]
name: assertLogs [5999,6009]
===
match
---
name: dag [9999,10002]
name: dag [9999,10002]
===
match
---
name: task_id [28550,28557]
name: task_id [28936,28943]
===
match
---
argument [33440,33473]
argument [33826,33859]
===
match
---
name: DagRunState [1461,1472]
name: DagRunState [1461,1472]
===
match
---
name: FAILED [8732,8738]
name: FAILED [8732,8738]
===
match
---
argument [32389,32412]
argument [32775,32798]
===
match
---
name: ignore_ti_state [10712,10727]
name: ignore_ti_state [10712,10727]
===
match
---
param [23967,23974]
param [24353,24360]
===
match
---
argument [33636,33662]
argument [34022,34048]
===
match
---
name: task_id [19095,19102]
name: task_id [19095,19102]
===
match
---
operator: = [3821,3822]
operator: = [3821,3822]
===
match
---
expr_stmt [34139,34354]
expr_stmt [34525,34740]
===
match
---
operator: = [5634,5635]
operator: = [5634,5635]
===
match
---
trailer [25178,25217]
trailer [25564,25603]
===
match
---
operator: = [3888,3889]
operator: = [3888,3889]
===
match
---
name: TEST_TASK_ID [12354,12366]
name: TEST_TASK_ID [12354,12366]
===
match
---
name: unittest [1911,1919]
name: unittest [1911,1919]
===
match
---
argument [5957,5969]
argument [5957,5969]
===
match
---
arglist [33214,33278]
arglist [33600,33664]
===
match
---
trailer [14054,14056]
trailer [14054,14056]
===
match
---
name: recursion_depth [28697,28712]
name: recursion_depth [29083,29098]
===
match
---
trailer [30247,30256]
trailer [30633,30642]
===
match
---
name: i [9418,9419]
name: i [9418,9419]
===
match
---
with_item [28827,28902]
with_item [29213,29288]
===
match
---
operator: = [32129,32130]
operator: = [32515,32516]
===
match
---
name: task_id [2956,2963]
name: task_id [2956,2963]
===
match
---
operator: , [5969,5970]
operator: , [5969,5970]
===
match
---
operator: , [2064,2065]
operator: , [2064,2065]
===
match
---
operator: , [8816,8817]
operator: , [8816,8817]
===
match
---
param [29549,29563]
param [29935,29949]
===
match
---
arglist [2489,2641]
arglist [2489,2641]
===
match
---
number: 2 [29337,29338]
number: 2 [29723,29724]
===
match
---
argument [20289,20298]
argument [20289,20298]
===
match
---
name: dag [14491,14494]
name: dag [14491,14494]
===
match
---
simple_stmt [1789,1812]
simple_stmt [1789,1812]
===
match
---
argument [24489,24518]
argument [24875,24904]
===
match
---
name: dag_0 [20342,20347]
name: dag_0 [20342,20347]
===
match
---
name: execution_date [32398,32412]
name: execution_date [32784,32798]
===
match
---
name: dag [29455,29458]
name: dag [29841,29844]
===
match
---
operator: = [29099,29100]
operator: = [29485,29486]
===
match
---
operator: , [30424,30425]
operator: , [30810,30811]
===
match
---
name: tis [23744,23747]
name: tis [24130,24133]
===
match
---
name: clear [34977,34982]
name: clear [35363,35368]
===
match
---
name: task_0 [21664,21670]
name: task_0 [21664,21670]
===
match
---
name: self [13932,13936]
name: self [13932,13936]
===
match
---
name: task_id [23259,23266]
name: task_id [23645,23652]
===
match
---
operator: == [8723,8725]
operator: == [8723,8725]
===
match
---
trailer [25958,25967]
trailer [26344,26353]
===
match
---
name: DEFAULT_DATE [30917,30929]
name: DEFAULT_DATE [31303,31315]
===
match
---
name: dagrun [24465,24471]
name: dagrun [24851,24857]
===
match
---
name: test_external_task_marker_future [25500,25532]
name: test_external_task_marker_future [25886,25918]
===
match
---
name: test_external_task_sensor_failed_states_as_success [4470,4520]
name: test_external_task_sensor_failed_states_as_success [4470,4520]
===
match
---
name: time_sensor [1273,1284]
name: time_sensor [1273,1284]
===
match
---
operator: = [10266,10267]
operator: = [10266,10267]
===
match
---
operator: + [28617,28618]
operator: + [29003,29004]
===
match
---
operator: , [7616,7617]
operator: , [7616,7617]
===
match
---
operator: , [29338,29339]
operator: , [29724,29725]
===
match
---
name: DEFAULT_DATE [27787,27799]
name: DEFAULT_DATE [28173,28185]
===
match
---
name: dag_bag_parent_child [20480,20500]
name: dag_bag_parent_child [20480,20500]
===
match
---
trailer [9200,9586]
trailer [9200,9586]
===
match
---
suite [26463,26976]
suite [26849,27362]
===
match
---
operator: } [31294,31295]
operator: } [31680,31681]
===
match
---
trailer [9138,9149]
trailer [9138,9149]
===
match
---
operator: = [1972,1973]
operator: = [1972,1973]
===
match
---
name: airflow [1434,1441]
name: airflow [1434,1441]
===
match
---
name: task_id [2186,2193]
name: task_id [2186,2193]
===
match
---
name: task_id [17497,17504]
name: task_id [17497,17504]
===
match
---
operator: >> [33785,33787]
operator: >> [34171,34173]
===
match
---
atom_expr [32000,32013]
atom_expr [32386,32399]
===
match
---
operator: = [26112,26113]
operator: = [26498,26499]
===
match
---
atom_expr [19638,19699]
atom_expr [19638,19699]
===
match
---
name: dag_2 [20175,20180]
name: dag_2 [20175,20180]
===
match
---
name: pytest [14147,14153]
name: pytest [14147,14153]
===
match
---
name: values [22195,22201]
name: values [22195,22201]
===
match
---
name: external_task_id [33676,33692]
name: external_task_id [34062,34078]
===
match
---
name: dag [2271,2274]
name: dag [2271,2274]
===
match
---
argument [5015,5036]
argument [5015,5036]
===
match
---
operator: = [10908,10909]
operator: = [10908,10909]
===
match
---
operator: = [23028,23029]
operator: = [23414,23415]
===
match
---
string: "task_b_1" [19499,19509]
string: "task_b_1" [19499,19509]
===
match
---
name: DAG [30891,30894]
name: DAG [31277,31280]
===
match
---
simple_stmt [23573,23602]
simple_stmt [23959,23988]
===
match
---
funcdef [22733,22933]
funcdef [23119,23319]
===
match
---
name: cm [5249,5251]
name: cm [5249,5251]
===
match
---
name: State [3557,3562]
name: State [3557,3562]
===
match
---
argument [11236,11256]
argument [11236,11256]
===
match
---
name: INFO [6032,6036]
name: INFO [6032,6036]
===
match
---
trailer [12862,12872]
trailer [12862,12872]
===
match
---
operator: , [28050,28051]
operator: , [28436,28437]
===
match
---
operator: = [18985,18986]
operator: = [18985,18986]
===
match
---
name: allowed_states [5879,5893]
name: allowed_states [5879,5893]
===
match
---
string: "task_a_0" [29293,29303]
string: "task_a_0" [29679,29689]
===
match
---
name: ExternalTaskSensor [14186,14204]
name: ExternalTaskSensor [14186,14204]
===
match
---
name: dag [7802,7805]
name: dag [7802,7805]
===
match
---
operator: = [27786,27787]
operator: = [28172,28173]
===
match
---
operator: , [14822,14823]
operator: , [14822,14823]
===
match
---
suite [14681,14976]
suite [14681,14976]
===
match
---
name: task_a [28945,28951]
name: task_a [29331,29337]
===
match
---
simple_stmt [34426,34455]
simple_stmt [34812,34841]
===
match
---
fstring_end: " [29118,29119]
fstring_end: " [29504,29505]
===
match
---
name: run [4986,4989]
name: run [4986,4989]
===
match
---
atom_expr [21543,21815]
atom_expr [21543,21815]
===
match
---
name: dt [11077,11079]
name: dt [11077,11079]
===
match
---
name: TEST_TASK_ID [11503,11515]
name: TEST_TASK_ID [11503,11515]
===
match
---
atom_expr [22580,22603]
atom_expr [22966,22989]
===
match
---
operator: = [24765,24766]
operator: = [25151,25152]
===
match
---
name: day_1 [21733,21738]
name: day_1 [21733,21738]
===
match
---
atom_expr [6118,6194]
atom_expr [6118,6194]
===
match
---
name: TaskInstance [1025,1037]
name: TaskInstance [1025,1037]
===
match
---
operator: , [8692,8693]
operator: , [8692,8693]
===
match
---
name: clean_db [1848,1856]
name: clean_db [1848,1856]
===
match
---
trailer [11786,11790]
trailer [11786,11790]
===
match
---
number: 1 [28462,28463]
number: 1 [28848,28849]
===
match
---
trailer [5965,5969]
trailer [5965,5969]
===
match
---
name: session [25299,25306]
name: session [25685,25692]
===
match
---
name: external_task_id [13142,13158]
name: external_task_id [13142,13158]
===
match
---
arglist [30746,30789]
arglist [31132,31175]
===
match
---
name: fixture [18054,18061]
name: fixture [18054,18061]
===
match
---
trailer [29842,29849]
trailer [30228,30235]
===
match
---
name: self [14952,14956]
name: self [14952,14956]
===
match
---
name: start_date [19651,19661]
name: start_date [19651,19661]
===
match
---
name: start_date [11791,11801]
name: start_date [11791,11801]
===
match
---
atom_expr [20175,20187]
atom_expr [20175,20187]
===
match
---
string: 'dag_{{ ds }}' [16746,16760]
string: 'dag_{{ ds }}' [16746,16760]
===
match
---
name: n [28358,28359]
name: n [28744,28745]
===
match
---
atom_expr [22509,22533]
atom_expr [22895,22919]
===
match
---
sync_comp_for [9848,9865]
sync_comp_for [9848,9865]
===
match
---
operator: , [21283,21284]
operator: , [21283,21284]
===
match
---
trailer [22201,22203]
trailer [22201,22203]
===
match
---
name: dag [19584,19587]
name: dag [19584,19587]
===
match
---
name: State [25436,25441]
name: State [25822,25827]
===
match
---
param [4091,4095]
param [4091,4095]
===
match
---
atom_expr [13296,13373]
atom_expr [13296,13373]
===
match
---
operator: = [35116,35117]
operator: = [35502,35503]
===
match
---
operator: = [24734,24735]
operator: = [25120,25121]
===
match
---
name: strftime [12854,12862]
name: strftime [12854,12862]
===
match
---
name: daily_task [31373,31383]
name: daily_task [31759,31769]
===
match
---
atom_expr [20206,20222]
atom_expr [20206,20222]
===
match
---
trailer [19388,19395]
trailer [19388,19395]
===
match
---
trailer [24195,24226]
trailer [24581,24612]
===
match
---
name: timedelta [845,854]
name: timedelta [845,854]
===
match
---
trailer [25152,25167]
trailer [25538,25553]
===
match
---
name: op [4138,4140]
name: op [4138,4140]
===
match
---
arglist [9647,10003]
arglist [9647,10003]
===
match
---
operator: = [34289,34290]
operator: = [34675,34676]
===
match
---
name: task_id [2879,2886]
name: task_id [2879,2886]
===
match
---
argument [9493,9502]
argument [9493,9502]
===
match
---
string: 'test_external_task_sensor_check_delta_2' [11390,11431]
string: 'test_external_task_sensor_check_delta_2' [11390,11431]
===
match
---
name: i [9845,9846]
name: i [9845,9846]
===
match
---
string: "success" [5933,5942]
string: "success" [5933,5942]
===
match
---
name: depth [27637,27642]
name: depth [28023,28028]
===
match
---
simple_stmt [2805,2849]
simple_stmt [2805,2849]
===
match
---
argument [4416,4437]
argument [4416,4437]
===
match
---
operator: , [31342,31343]
operator: , [31728,31729]
===
match
---
argument [31047,31063]
argument [31433,31449]
===
match
---
name: op [2452,2454]
name: op [2452,2454]
===
match
---
string: 'test_external_task_sensor_task_id_and_task_ids' [14230,14278]
string: 'test_external_task_sensor_task_id_and_task_ids' [14230,14278]
===
match
---
simple_stmt [30963,31014]
simple_stmt [31349,31400]
===
match
---
yield_expr [21900,21913]
yield_expr [21900,21913]
===
match
---
name: dag [33840,33843]
name: dag [34226,34229]
===
match
---
name: self [5553,5557]
name: self [5553,5557]
===
match
---
operator: = [16363,16364]
operator: = [16363,16364]
===
match
---
expr_stmt [19704,19843]
expr_stmt [19704,19843]
===
match
---
name: test_clear_overlapping_external_task_marker [33888,33931]
name: test_clear_overlapping_external_task_marker [34274,34317]
===
match
---
name: state [25427,25432]
name: state [25813,25818]
===
match
---
operator: , [4834,4835]
operator: , [4834,4835]
===
match
---
atom_expr [20442,20457]
atom_expr [20442,20457]
===
match
---
operator: , [30455,30456]
operator: , [30841,30842]
===
match
---
trailer [12498,12568]
trailer [12498,12568]
===
match
---
argument [28847,28870]
argument [29233,29256]
===
match
---
name: depth [29110,29115]
name: depth [29496,29501]
===
match
---
parameters [17218,17224]
parameters [17218,17224]
===
match
---
simple_stmt [1252,1303]
simple_stmt [1252,1303]
===
match
---
string: "child_dag_1" [21468,21481]
string: "child_dag_1" [21468,21481]
===
match
---
atom_expr [22674,22714]
atom_expr [23060,23100]
===
match
---
name: dag_0 [26959,26964]
name: dag_0 [27345,27350]
===
match
---
string: "@daily" [30949,30957]
string: "@daily" [31335,31343]
===
match
---
simple_stmt [1864,1880]
simple_stmt [1864,1880]
===
match
---
name: get_dagrun [25070,25080]
name: get_dagrun [25456,25466]
===
match
---
operator: = [29292,29293]
operator: = [29678,29679]
===
match
---
name: get_task [26795,26803]
name: get_task [27181,27189]
===
match
---
name: State [6950,6955]
name: State [6950,6955]
===
match
---
expr_stmt [9040,9060]
expr_stmt [9040,9060]
===
match
---
atom_expr [12982,12994]
atom_expr [12982,12994]
===
match
---
name: SUCCESS [34541,34548]
name: SUCCESS [34927,34934]
===
match
---
name: execution_date [25277,25291]
name: execution_date [25663,25677]
===
match
---
simple_stmt [15398,15657]
simple_stmt [15398,15657]
===
match
---
dotted_name [1504,1526]
dotted_name [1504,1526]
===
match
---
name: dt [11558,11560]
name: dt [11558,11560]
===
match
---
argument [16082,16103]
argument [16082,16103]
===
match
---
name: TEST_DAG_ID [2117,2128]
name: TEST_DAG_ID [2117,2128]
===
match
---
atom_expr [2262,2269]
atom_expr [2262,2269]
===
match
---
argument [4439,4459]
argument [4439,4459]
===
match
---
operator: , [5904,5905]
operator: , [5904,5905]
===
match
---
name: start_date [33227,33237]
name: start_date [33613,33623]
===
match
---
assert_stmt [22897,22932]
assert_stmt [23283,23318]
===
match
---
argument [9139,9148]
argument [9139,9148]
===
match
---
name: SerializedBaseOperator [1356,1378]
name: SerializedBaseOperator [1356,1378]
===
match
---
argument [16692,16716]
argument [16692,16716]
===
match
---
suite [4527,5460]
suite [4527,5460]
===
match
---
expr_stmt [22213,22434]
expr_stmt [22213,22434]
===
match
---
operator: = [24750,24751]
operator: = [25136,25137]
===
match
---
name: airflow [987,994]
name: airflow [987,994]
===
match
---
name: DEV_NULL [1789,1797]
name: DEV_NULL [1789,1797]
===
match
---
number: 0 [34061,34062]
number: 0 [34447,34448]
===
match
---
name: TEST_TASK_ID [5828,5840]
name: TEST_TASK_ID [5828,5840]
===
match
---
operator: } [29215,29216]
operator: } [29601,29602]
===
match
---
operator: , [33225,33226]
operator: , [33611,33612]
===
match
---
operator: = [30737,30738]
operator: = [31123,31124]
===
match
---
trailer [33655,33662]
trailer [34041,34048]
===
match
---
operator: , [6754,6755]
operator: , [6754,6755]
===
match
---
atom_expr [12920,12937]
atom_expr [12920,12937]
===
match
---
name: self [7153,7157]
name: self [7153,7157]
===
match
---
atom_expr [23305,23458]
atom_expr [23691,23844]
===
match
---
operator: , [25101,25102]
operator: , [25487,25488]
===
match
---
name: QUEUED [25442,25448]
name: QUEUED [25828,25834]
===
match
---
argument [22253,22272]
argument [22253,22272]
===
match
---
trailer [16841,16855]
trailer [16841,16855]
===
match
---
atom_expr [15398,15656]
atom_expr [15398,15656]
===
match
---
name: tis_date_1 [26226,26236]
name: tis_date_1 [26612,26622]
===
match
---
simple_stmt [10181,10273]
simple_stmt [10181,10273]
===
match
---
name: task_a_0 [19208,19216]
name: task_a_0 [19208,19216]
===
match
---
name: ExternalTaskSensor [33303,33321]
name: ExternalTaskSensor [33689,33707]
===
match
---
name: dag_folder [30746,30756]
name: dag_folder [31132,31142]
===
match
---
trailer [22917,22923]
trailer [23303,23309]
===
match
---
simple_stmt [1734,1789]
simple_stmt [1734,1789]
===
match
---
atom_expr [19007,19051]
atom_expr [19007,19051]
===
match
---
simple_stmt [31503,31517]
simple_stmt [31889,31903]
===
match
---
name: self [11690,11694]
name: self [11690,11694]
===
match
---
name: task_id [31261,31268]
name: task_id [31647,31654]
===
match
---
string: "dag_0" [18934,18941]
string: "dag_0" [18934,18941]
===
match
---
operator: , [13771,13772]
operator: , [13771,13772]
===
match
---
argument [23359,23376]
argument [23745,23762]
===
match
---
atom_expr [34867,34945]
atom_expr [35253,35331]
===
match
---
funcdef [31605,32446]
funcdef [31991,32832]
===
match
---
name: dag_id [19389,19395]
name: dag_id [19389,19395]
===
match
---
operator: , [19563,19564]
operator: , [19563,19564]
===
match
---
number: 30 [35147,35149]
number: 30 [35533,35535]
===
match
---
arglist [21150,21206]
arglist [21150,21206]
===
match
---
name: end_date [11213,11221]
name: end_date [11213,11221]
===
match
---
shift_expr [19208,19228]
shift_expr [19208,19228]
===
match
---
name: dag_bag_ext [23589,23600]
name: dag_bag_ext [23975,23986]
===
match
---
suite [1930,16576]
suite [1930,16576]
===
match
---
trailer [17774,17795]
trailer [17774,17795]
===
match
---
name: op [3163,3165]
name: op [3163,3165]
===
match
---
expr_stmt [25774,25832]
expr_stmt [26160,26218]
===
match
---
argument [7073,7100]
argument [7073,7100]
===
match
---
name: provide_session [22936,22951]
name: provide_session [23322,23337]
===
match
---
string: 'external_dag_id' [17916,17933]
string: 'external_dag_id' [17916,17933]
===
match
---
name: run_id [34321,34327]
name: run_id [34707,34713]
===
match
---
trailer [23625,23633]
trailer [24011,24019]
===
match
---
trailer [5998,6009]
trailer [5998,6009]
===
match
---
argument [2827,2847]
argument [2827,2847]
===
match
---
argument [4271,4300]
argument [4271,4300]
===
match
---
name: flush [22624,22629]
name: flush [23010,23015]
===
match
---
trailer [24396,24403]
trailer [24782,24789]
===
match
---
name: start_date [24724,24734]
name: start_date [25110,25120]
===
match
---
name: State [1474,1479]
name: State [1474,1479]
===
match
---
suite [23091,23459]
suite [23477,23845]
===
match
---
name: run_tasks [24186,24195]
name: run_tasks [24572,24581]
===
match
---
operator: , [9525,9526]
operator: , [9525,9526]
===
match
---
trailer [10198,10202]
trailer [10198,10202]
===
match
---
simple_stmt [14186,14510]
simple_stmt [14186,14510]
===
match
---
name: dag [21872,21875]
name: dag [21872,21875]
===
match
---
simple_stmt [6838,6974]
simple_stmt [6838,6974]
===
match
---
name: get_task [22513,22521]
name: get_task [22899,22907]
===
match
---
trailer [4896,4901]
trailer [4896,4901]
===
match
---
trailer [13447,13464]
trailer [13447,13464]
===
match
---
argument [14341,14370]
argument [14341,14370]
===
match
---
name: ValueError [15053,15063]
name: ValueError [15053,15063]
===
match
---
simple_stmt [30018,30135]
simple_stmt [30404,30521]
===
match
---
name: dag_bag_ext [18066,18077]
name: dag_bag_ext [18066,18077]
===
match
---
fstring [28348,28361]
fstring [28734,28747]
===
match
---
operator: , [28675,28676]
operator: , [29061,29062]
===
match
---
argument [13884,13910]
argument [13884,13910]
===
match
---
name: dag_bag [33138,33145]
name: dag_bag [33524,33531]
===
match
---
param [21977,22005]
param [21977,22005]
===
match
---
param [27637,27647]
param [28023,28033]
===
match
---
name: task_id [11382,11389]
name: task_id [11382,11389]
===
match
---
arglist [24489,24535]
arglist [24875,24921]
===
match
---
simple_stmt [1379,1429]
simple_stmt [1379,1429]
===
match
---
name: depth [29008,29013]
name: depth [29394,29399]
===
match
---
trailer [12467,12471]
trailer [12467,12471]
===
match
---
operator: = [10558,10559]
operator: = [10558,10559]
===
match
---
number: 10 [34064,34066]
number: 10 [34450,34452]
===
match
---
simple_stmt [8570,8873]
simple_stmt [8570,8873]
===
match
---
number: 1 [28408,28409]
number: 1 [28794,28795]
===
match
---
operator: , [23401,23402]
operator: , [23787,23788]
===
match
---
atom_expr [25850,25895]
atom_expr [26236,26281]
===
match
---
atom_expr [34553,34568]
atom_expr [34939,34954]
===
match
---
atom_expr [29760,29784]
atom_expr [30146,30170]
===
match
---
name: run [2296,2299]
name: run [2296,2299]
===
match
---
operator: = [10867,10868]
operator: = [10867,10868]
===
match
---
trailer [34118,34130]
trailer [34504,34516]
===
match
---
operator: = [33615,33616]
operator: = [34001,34002]
===
match
---
strings [5097,5218]
strings [5097,5218]
===
match
---
trailer [26761,26773]
trailer [27147,27159]
===
match
---
atom_expr [5605,5658]
atom_expr [5605,5658]
===
match
---
name: dag_1 [20349,20354]
name: dag_1 [20349,20354]
===
match
---
operator: = [11670,11671]
operator: = [11670,11671]
===
match
---
simple_stmt [7181,7258]
simple_stmt [7181,7258]
===
match
---
name: schedule_interval [33252,33269]
name: schedule_interval [33638,33655]
===
match
---
name: start_date [3170,3180]
name: start_date [3170,3180]
===
match
---
testlist_comp [21833,21845]
testlist_comp [21833,21845]
===
match
---
trailer [30562,30570]
trailer [30948,30956]
===
match
---
name: DEFAULT_DATE [10214,10226]
name: DEFAULT_DATE [10214,10226]
===
match
---
simple_stmt [22213,22435]
simple_stmt [22213,22435]
===
match
---
atom_expr [30280,30331]
atom_expr [30666,30717]
===
match
---
name: external_dag_id [4230,4245]
name: external_dag_id [4230,4245]
===
match
---
operator: , [26092,26093]
operator: , [26478,26479]
===
match
---
operator: = [1646,1647]
operator: = [1646,1647]
===
match
---
operator: , [15202,15203]
operator: , [15202,15203]
===
match
---
operator: = [19265,19266]
operator: = [19265,19266]
===
match
---
operator: = [13008,13009]
operator: = [13008,13009]
===
match
---
name: test_external_task_sensor_waits_for_dag_check_existence [16136,16191]
name: test_external_task_sensor_waits_for_dag_check_existence [16136,16191]
===
match
---
operator: = [20253,20254]
operator: = [20253,20254]
===
match
---
trailer [21626,21633]
trailer [21626,21633]
===
match
---
argument [12459,12471]
argument [12459,12471]
===
match
---
trailer [25080,25119]
trailer [25466,25505]
===
match
---
name: assert_ti_state_equal [26253,26274]
name: assert_ti_state_equal [26639,26660]
===
match
---
operator: , [3947,3948]
operator: , [3947,3948]
===
match
---
number: 0 [7799,7800]
number: 0 [7799,7800]
===
match
---
name: DEFAULT_DATE [13315,13327]
name: DEFAULT_DATE [13315,13327]
===
match
---
string: "daily_dag" [30811,30822]
string: "daily_dag" [31197,31208]
===
match
---
simple_stmt [9069,9151]
simple_stmt [9069,9151]
===
match
---
name: TaskInstanceState [1481,1498]
name: TaskInstanceState [1481,1498]
===
match
---
trailer [8160,8168]
trailer [8160,8168]
===
match
---
simple_stmt [32087,32146]
simple_stmt [32473,32532]
===
match
---
for_stmt [34391,34549]
for_stmt [34777,34935]
===
match
---
arglist [28141,28149]
arglist [28527,28535]
===
match
---
name: pytest [15039,15045]
name: pytest [15039,15045]
===
match
---
name: get_dag [24622,24629]
name: get_dag [25008,25015]
===
match
---
number: 1 [11642,11643]
number: 1 [11642,11643]
===
match
---
operator: = [3510,3511]
operator: = [3510,3511]
===
match
---
arglist [30895,30957]
arglist [31281,31343]
===
match
---
operator: = [4888,4889]
operator: = [4888,4889]
===
match
---
argument [3061,3117]
argument [3061,3117]
===
match
---
arglist [22696,22713]
arglist [23082,23099]
===
match
---
name: ti [34496,34498]
name: ti [34882,34884]
===
match
---
expr_stmt [10361,10648]
expr_stmt [10361,10648]
===
match
---
operator: == [25433,25435]
operator: == [25819,25821]
===
match
---
atom_expr [23579,23601]
atom_expr [23965,23987]
===
match
---
argument [7802,7818]
argument [7802,7818]
===
match
---
param [11073,11075]
param [11073,11075]
===
match
---
yield_expr [20423,20436]
yield_expr [20423,20436]
===
match
---
operator: = [28347,28348]
operator: = [28733,28734]
===
match
---
dotted_name [31564,31583]
dotted_name [31950,31969]
===
match
---
string: """     Create a DagBag with DAGs looking like this. The dotted lines represent external dependencies     set up using ExternalTaskMarker and ExternalTaskSensor.      dag_0:   task_a_0 >> task_b_0                              |                              |     dag_1:                   ---> task_a_1 >> task_b_1                                                   |                                                   |     dag_2:                                        ---> task_a_2 >> task_b_2                                                                        |                                                                        |     dag_3:                                                             ---> task_a_3 >> task_b_3     """ [18085,18829]
string: """     Create a DagBag with DAGs looking like this. The dotted lines represent external dependencies     set up using ExternalTaskMarker and ExternalTaskSensor.      dag_0:   task_a_0 >> task_b_0                              |                              |     dag_1:                   ---> task_a_1 >> task_b_1                                                   |                                                   |     dag_2:                                        ---> task_a_2 >> task_b_2                                                                        |                                                                        |     dag_3:                                                             ---> task_a_3 >> task_b_3     """ [18085,18829]
===
match
---
trailer [20180,20187]
trailer [20180,20187]
===
match
---
atom_expr [25328,25344]
atom_expr [25714,25730]
===
match
---
testlist_comp [30355,30374]
testlist_comp [30741,30760]
===
match
---
suite [23976,25494]
suite [24362,25880]
===
match
---
operator: @ [33867,33868]
operator: @ [34253,34254]
===
match
---
name: task_id [27899,27906]
name: task_id [28285,28292]
===
match
---
name: dag_3 [20293,20298]
name: dag_3 [20293,20298]
===
match
---
arglist [8031,8122]
arglist [8031,8122]
===
match
---
name: ti [30576,30578]
name: ti [30962,30964]
===
match
---
operator: = [31055,31056]
operator: = [31441,31442]
===
match
---
operator: = [20398,20399]
operator: = [20398,20399]
===
match
---
operator: = [4612,4613]
operator: = [4612,4613]
===
match
---
argument [11005,11034]
argument [11005,11034]
===
match
---
operator: = [14357,14358]
operator: = [14357,14358]
===
match
---
operator: , [31458,31459]
operator: , [31844,31845]
===
match
---
operator: = [17547,17548]
operator: = [17547,17548]
===
match
---
name: DummyOperator [7869,7882]
name: DummyOperator [7869,7882]
===
match
---
atom_expr [25480,25493]
atom_expr [25866,25879]
===
match
---
argument [3494,3523]
argument [3494,3523]
===
match
---
name: test_time_sensor [4541,4557]
name: test_time_sensor [4541,4557]
===
match
---
fstring_string: task_b_ [28560,28567]
fstring_string: task_b_ [28946,28953]
===
match
---
atom_expr [4356,4364]
atom_expr [4356,4364]
===
match
---
operator: = [33552,33553]
operator: = [33938,33939]
===
match
---
name: ExternalTaskSensor [3354,3372]
name: ExternalTaskSensor [3354,3372]
===
match
---
name: session [8142,8149]
name: session [8142,8149]
===
match
---
trailer [34406,34412]
trailer [34792,34798]
===
match
---
name: ExternalTaskSensor [20111,20129]
name: ExternalTaskSensor [20111,20129]
===
match
---
string: "task_b_3" [23777,23787]
string: "task_b_3" [24163,24173]
===
match
---
atom [3079,3117]
atom [3079,3117]
===
match
---
assert_stmt [34860,34951]
assert_stmt [35246,35337]
===
match
---
suite [32488,33865]
suite [32874,34251]
===
match
---
operator: , [21678,21679]
operator: , [21678,21679]
===
match
---
operator: = [34429,34430]
operator: = [34815,34816]
===
match
---
name: match [29868,29873]
name: match [30254,30259]
===
match
---
operator: , [19905,19906]
operator: , [19905,19906]
===
match
---
name: dag_0 [30301,30306]
name: dag_0 [30687,30692]
===
match
---
name: task_id [15114,15121]
name: task_id [15114,15121]
===
match
---
operator: = [25208,25209]
operator: = [25594,25595]
===
match
---
trailer [3644,3648]
trailer [3644,3648]
===
match
---
name: DEFAULT_DATE [13338,13350]
name: DEFAULT_DATE [13338,13350]
===
match
---
name: external_task_ids [5809,5826]
name: external_task_ids [5809,5826]
===
match
---
name: session [24758,24765]
name: session [25144,25151]
===
match
---
atom_expr [7573,7657]
atom_expr [7573,7657]
===
match
---
name: external_task_id [17087,17103]
name: external_task_id [17087,17103]
===
match
---
operator: , [5865,5866]
operator: , [5865,5866]
===
match
---
name: dag [24377,24380]
name: dag [24763,24766]
===
match
---
operator: = [22013,22014]
operator: = [22013,22014]
===
match
---
name: DagRun [34148,34154]
name: DagRun [34534,34540]
===
match
---
name: datetime [823,831]
name: datetime [823,831]
===
match
---
simple_stmt [29469,29484]
simple_stmt [29855,29870]
===
match
---
operator: , [15919,15920]
operator: , [15919,15920]
===
match
---
lambdef [9383,9439]
lambdef [9383,9439]
===
match
---
argument [2628,2640]
argument [2628,2640]
===
match
---
param [15723,15727]
param [15723,15727]
===
match
---
simple_stmt [19234,19304]
simple_stmt [19234,19304]
===
match
---
expr_stmt [20026,20095]
expr_stmt [20026,20095]
===
match
---
trailer [33697,33705]
trailer [34083,34091]
===
match
---
name: depth [28144,28149]
name: depth [28530,28535]
===
match
---
fstring_start: f" [28831,28833]
fstring_start: f" [29217,29219]
===
match
---
string: 'airflow' [2055,2064]
string: 'airflow' [2055,2064]
===
match
---
operator: , [10226,10227]
operator: , [10226,10227]
===
match
---
name: self [2180,2184]
name: self [2180,2184]
===
match
---
operator: = [7693,7694]
operator: = [7693,7694]
===
match
---
fstring_string: _ [31291,31292]
fstring_string: _ [31677,31678]
===
match
---
parameters [20500,20502]
parameters [20500,20502]
===
match
---
trailer [12041,12058]
trailer [12041,12058]
===
match
---
param [16618,16627]
param [16618,16627]
===
match
---
trailer [19784,19791]
trailer [19784,19791]
===
match
---
arglist [30292,30330]
arglist [30678,30716]
===
match
---
arglist [31097,31131]
arglist [31483,31517]
===
match
---
operator: , [30530,30531]
operator: , [30916,30917]
===
match
---
argument [7149,7161]
argument [7149,7161]
===
match
---
lambdef [11066,11094]
lambdef [11066,11094]
===
match
---
argument [30767,30789]
argument [31153,31175]
===
match
---
operator: { [28405,28406]
operator: { [28791,28792]
===
match
---
name: task_id [33608,33615]
name: task_id [33994,34001]
===
match
---
argument [12930,12936]
argument [12930,12936]
===
match
---
import_as_names [1213,1251]
import_as_names [1213,1251]
===
match
---
argument [4352,4364]
argument [4352,4364]
===
match
---
argument [34996,35019]
argument [35382,35405]
===
match
---
trailer [34001,34014]
trailer [34387,34400]
===
match
---
trailer [24477,24488]
trailer [24863,24874]
===
match
---
name: dry_run [23419,23426]
name: dry_run [23805,23812]
===
match
---
name: external_dag_id [29033,29048]
name: external_dag_id [29419,29434]
===
match
---
trailer [4863,4874]
trailer [4863,4874]
===
match
---
atom_expr [9827,9847]
atom_expr [9827,9847]
===
match
---
operator: = [33651,33652]
operator: = [34037,34038]
===
match
---
name: n [28406,28407]
name: n [28792,28793]
===
match
---
name: start_date [20047,20057]
name: start_date [20047,20057]
===
match
---
trailer [17260,17269]
trailer [17260,17269]
===
match
---
operator: , [17576,17577]
operator: , [17576,17577]
===
match
---
atom_expr [33576,33771]
atom_expr [33962,34157]
===
match
---
arglist [4605,4835]
arglist [4605,4835]
===
match
---
trailer [11091,11094]
trailer [11091,11094]
===
match
---
name: TEST_TASK_ID_ALTERNATE [5842,5864]
name: TEST_TASK_ID_ALTERNATE [5842,5864]
===
match
---
name: ds_nodash [12787,12796]
name: ds_nodash [12787,12796]
===
match
---
argument [3814,3855]
argument [3814,3855]
===
match
---
name: State [25348,25353]
name: State [25734,25739]
===
match
---
trailer [31952,31960]
trailer [32338,32346]
===
match
---
decorator [31563,31605]
decorator [31949,31991]
===
match
---
string: """     Test clearing tasks across DAGs and make sure the right DagRuns are activated.     """ [23981,24075]
string: """     Test clearing tasks across DAGs and make sure the right DagRuns are activated.     """ [24367,24461]
===
match
---
operator: == [6512,6514]
operator: == [6512,6514]
===
match
---
name: external_dag_id [15175,15190]
name: external_dag_id [15175,15190]
===
match
---
arglist [9079,9149]
arglist [9079,9149]
===
match
---
trailer [3609,3617]
trailer [3609,3617]
===
match
---
suite [27015,29505]
suite [27401,29891]
===
match
---
name: task_a [29366,29372]
name: task_a [29752,29758]
===
match
---
operator: = [20292,20293]
operator: = [20292,20293]
===
match
---
simple_stmt [24585,24601]
simple_stmt [24971,24987]
===
match
---
name: run [8249,8252]
name: run [8249,8252]
===
match
---
argument [23436,23451]
argument [23822,23837]
===
match
---
atom_expr [22259,22272]
atom_expr [22259,22272]
===
match
---
name: session [25307,25314]
name: session [25693,25700]
===
match
---
fstring_expr [34335,34342]
fstring_expr [34721,34728]
===
match
---
name: tis [30582,30585]
name: tis [30968,30971]
===
match
---
argument [5704,5754]
argument [5704,5754]
===
match
---
name: dag [20395,20398]
name: dag [20395,20398]
===
match
---
expr_stmt [7666,7828]
expr_stmt [7666,7828]
===
match
---
simple_stmt [26124,26163]
simple_stmt [26510,26549]
===
match
---
argument [12547,12567]
argument [12547,12567]
===
match
---
name: DEV_NULL [1992,2000]
name: DEV_NULL [1992,2000]
===
match
---
atom_expr [5249,5258]
atom_expr [5249,5258]
===
match
---
fstring_expr [29007,29014]
fstring_expr [29393,29400]
===
match
---
argument [2250,2269]
argument [2250,2269]
===
match
---
operator: = [29454,29455]
operator: = [29840,29841]
===
match
---
operator: , [9439,9440]
operator: , [9439,9440]
===
match
---
name: append [34489,34495]
name: append [34875,34881]
===
match
---
trailer [32066,32078]
trailer [32452,32464]
===
match
---
operator: , [21591,21592]
operator: , [21591,21592]
===
match
---
name: dag [19188,19191]
name: dag [19188,19191]
===
match
---
testlist_comp [30386,30405]
testlist_comp [30772,30791]
===
match
---
simple_stmt [9159,9587]
simple_stmt [9159,9587]
===
match
---
arglist [5704,5970]
arglist [5704,5970]
===
match
---
name: ctx [6501,6504]
name: ctx [6501,6504]
===
match
---
trailer [13563,13570]
trailer [13563,13570]
===
match
---
operator: , [23965,23966]
operator: , [24351,24352]
===
match
---
comparison [25328,25360]
comparison [25714,25746]
===
match
---
name: start_date [7188,7198]
name: start_date [7188,7198]
===
match
---
name: op2 [11783,11786]
name: op2 [11783,11786]
===
match
---
atom_expr [15633,15641]
atom_expr [15633,15641]
===
match
---
argument [16416,16428]
argument [16416,16428]
===
match
---
name: dt [12783,12785]
name: dt [12783,12785]
===
match
---
trailer [28269,28274]
trailer [28655,28660]
===
match
---
operator: , [4730,4731]
operator: , [4730,4731]
===
match
---
operator: = [9749,9750]
operator: = [9749,9750]
===
match
---
name: external_task_id [28023,28039]
name: external_task_id [28409,28425]
===
match
---
name: run_tasks [30171,30180]
name: run_tasks [30557,30566]
===
match
---
trailer [17483,17652]
trailer [17483,17652]
===
match
---
name: days [33466,33470]
name: days [33852,33856]
===
match
---
trailer [8642,8835]
trailer [8642,8835]
===
match
---
name: raises [15046,15052]
name: raises [15046,15052]
===
match
---
operator: = [33692,33693]
operator: = [34078,34079]
===
match
---
atom_expr [13596,13955]
atom_expr [13596,13955]
===
match
---
name: op [2293,2295]
name: op [2293,2295]
===
match
---
trailer [31960,31971]
trailer [32346,32357]
===
match
---
arglist [26328,26353]
arglist [26714,26739]
===
match
---
parameters [30625,30627]
parameters [31011,31013]
===
match
---
argument [28433,28465]
argument [28819,28851]
===
match
---
argument [16887,16914]
argument [16887,16914]
===
match
---
name: DEFAULT_DATE [6408,6420]
name: DEFAULT_DATE [6408,6420]
===
match
---
name: start_date [2300,2310]
name: start_date [2300,2310]
===
match
---
parameters [6711,6717]
parameters [6711,6717]
===
match
---
operator: = [27722,27723]
operator: = [28108,28109]
===
match
---
operator: = [20032,20033]
operator: = [20032,20033]
===
match
---
name: run [16053,16056]
name: run [16053,16056]
===
match
---
param [10314,10318]
param [10314,10318]
===
match
---
trailer [5574,5596]
trailer [5574,5596]
===
match
---
import_from [1586,1631]
import_from [1586,1631]
===
match
---
atom_expr [8888,8903]
atom_expr [8888,8903]
===
match
---
name: range [31203,31208]
name: range [31589,31594]
===
match
---
simple_stmt [21543,21816]
simple_stmt [21543,21816]
===
match
---
name: pytest [29836,29842]
name: pytest [30222,30228]
===
match
---
argument [34199,34224]
argument [34585,34610]
===
match
---
atom_expr [4927,4958]
atom_expr [4927,4958]
===
match
---
trailer [22521,22533]
trailer [22907,22919]
===
match
---
operator: , [19278,19279]
operator: , [19278,19279]
===
match
---
atom_expr [29912,29949]
atom_expr [30298,30335]
===
match
---
atom_expr [16832,16915]
atom_expr [16832,16915]
===
match
---
name: end_date [2692,2700]
name: end_date [2692,2700]
===
match
---
name: day_1 [24735,24740]
name: day_1 [25121,25126]
===
match
---
name: DagRunType [22377,22387]
name: DagRunType [22377,22387]
===
match
---
name: dag [34867,34870]
name: dag [35253,35256]
===
match
---
operator: = [10081,10082]
operator: = [10081,10082]
===
match
---
simple_stmt [17375,17450]
simple_stmt [17375,17450]
===
match
---
operator: , [10094,10095]
operator: , [10094,10095]
===
match
---
string: """     Test clearing tasks with no end_date. This is the case when users clear tasks with     Future, Downstream and Recursive selected.     """ [25551,25696]
string: """     Test clearing tasks with no end_date. This is the case when users clear tasks with     Future, Downstream and Recursive selected.     """ [25937,26082]
===
match
---
name: self [10772,10776]
name: self [10772,10776]
===
match
---
trailer [23234,23293]
trailer [23620,23679]
===
match
---
trailer [11368,11709]
trailer [11368,11709]
===
match
---
with_stmt [14142,14510]
with_stmt [14142,14510]
===
match
---
arglist [16692,16807]
arglist [16692,16807]
===
match
---
trailer [8013,8017]
trailer [8013,8017]
===
match
---
name: dag_0 [24659,24664]
name: dag_0 [25045,25050]
===
match
---
name: clear_tasks [23689,23700]
name: clear_tasks [24075,24086]
===
match
---
name: pytest [1815,1821]
name: pytest [1815,1821]
===
match
---
simple_stmt [1038,1073]
simple_stmt [1038,1073]
===
match
---
string: "task_1" [21357,21365]
string: "task_1" [21357,21365]
===
match
---
operator: = [2496,2497]
operator: = [2496,2497]
===
match
---
atom_expr [10366,10648]
atom_expr [10366,10648]
===
match
---
dotted_name [1078,1100]
dotted_name [1078,1100]
===
match
---
name: dag [20334,20337]
name: dag [20334,20337]
===
match
---
arglist [26946,26974]
arglist [27332,27360]
===
match
---
name: test_time_sensor [10334,10350]
name: test_time_sensor [10334,10350]
===
match
---
operator: = [21620,21621]
operator: = [21620,21621]
===
match
---
suite [21847,21895]
suite [21847,21895]
===
match
---
name: exceptions [11737,11747]
name: exceptions [11737,11747]
===
match
---
operator: , [14494,14495]
operator: , [14494,14495]
===
match
---
name: serialized_objects [1330,1348]
name: serialized_objects [1330,1348]
===
match
---
atom_expr [3135,3143]
atom_expr [3135,3143]
===
match
---
operator: = [15593,15594]
operator: = [15593,15594]
===
match
---
trailer [25967,25979]
trailer [26353,26365]
===
match
---
name: task_instance [22861,22874]
name: task_instance [23247,23260]
===
match
---
trailer [15637,15641]
trailer [15637,15641]
===
match
---
name: start_date [10664,10674]
name: start_date [10664,10674]
===
match
---
name: TEST_DAG_ID [10980,10991]
name: TEST_DAG_ID [10980,10991]
===
match
---
funcdef [13379,13956]
funcdef [13379,13956]
===
match
---
simple_stmt [30729,30791]
simple_stmt [31115,31177]
===
match
---
name: raises [29843,29849]
name: raises [30229,30235]
===
match
---
atom_expr [25787,25832]
atom_expr [26173,26218]
===
match
---
string: "postgres" [31584,31594]
string: "postgres" [31970,31980]
===
match
---
operator: , [35019,35020]
operator: , [35405,35406]
===
match
---
name: clear [32356,32361]
name: clear [32742,32747]
===
match
---
suite [33287,33801]
suite [33673,34187]
===
match
---
name: DEFAULT_DATE [2678,2690]
name: DEFAULT_DATE [2678,2690]
===
match
---
name: my_func [12775,12782]
name: my_func [12775,12782]
===
match
---
name: NONE [26296,26300]
name: NONE [26682,26686]
===
match
---
trailer [28318,28484]
trailer [28704,28870]
===
match
---
dotted_name [1815,1829]
dotted_name [1815,1829]
===
match
---
operator: , [3571,3572]
operator: , [3571,3572]
===
match
---
name: dag_external_id [9704,9719]
name: dag_external_id [9704,9719]
===
match
---
lambdef [11547,11580]
lambdef [11547,11580]
===
match
---
operator: , [17914,17915]
operator: , [17914,17915]
===
match
---
name: ti_b_3 [23861,23867]
name: ti_b_3 [24247,24253]
===
match
---
name: dag [19041,19044]
name: dag [19041,19044]
===
match
---
atom_expr [20111,20239]
atom_expr [20111,20239]
===
match
---
fstring_string: test_ [34330,34335]
fstring_string: test_ [34716,34721]
===
match
---
name: dag [4831,4834]
name: dag [4831,4834]
===
match
---
argument [6875,6888]
argument [6875,6888]
===
match
---
argument [16774,16806]
argument [16774,16806]
===
match
---
name: failed_states [5918,5931]
name: failed_states [5918,5931]
===
match
---
operator: - [29115,29116]
operator: - [29501,29502]
===
match
---
name: SUCCESS [3610,3617]
name: SUCCESS [3610,3617]
===
match
---
operator: , [13866,13867]
operator: , [13866,13867]
===
match
---
arglist [28550,28715]
arglist [28936,29101]
===
match
---
name: MANUAL [34301,34307]
name: MANUAL [34687,34693]
===
match
---
name: TEST_TASK_ID_ALTERNATE [3094,3116]
name: TEST_TASK_ID_ALTERNATE [3094,3116]
===
match
---
fstring_start: f" [28998,29000]
fstring_start: f" [29384,29386]
===
match
---
name: logging [6024,6031]
name: logging [6024,6031]
===
match
---
argument [9792,9866]
argument [9792,9866]
===
match
---
trailer [22705,22713]
trailer [23091,23099]
===
match
---
operator: , [28142,28143]
operator: , [28528,28529]
===
match
---
arglist [23815,23833]
arglist [24201,24219]
===
match
---
trailer [2266,2269]
trailer [2266,2269]
===
match
---
name: op [10361,10363]
name: op [10361,10363]
===
match
---
trailer [16505,16575]
trailer [16505,16575]
===
match
---
operator: = [13852,13853]
operator: = [13852,13853]
===
match
---
arglist [33335,33505]
arglist [33721,33891]
===
match
---
name: DAG [30807,30810]
name: DAG [31193,31196]
===
match
---
name: DagBag [1974,1980]
name: DagBag [1974,1980]
===
match
---
operator: , [30406,30407]
operator: , [30792,30793]
===
match
---
name: include_examples [18893,18909]
name: include_examples [18893,18909]
===
match
---
operator: @ [21937,21938]
operator: @ [21937,21938]
===
match
---
name: cm [6436,6438]
name: cm [6436,6438]
===
match
---
operator: , [20222,20223]
operator: , [20222,20223]
===
match
---
name: timedelta [11563,11572]
name: timedelta [11563,11572]
===
match
---
fstring_string: task_a_ [28350,28357]
fstring_string: task_a_ [28736,28743]
===
match
---
argument [11188,11211]
argument [11188,11211]
===
match
---
trailer [31033,31064]
trailer [31419,31450]
===
match
---
operator: = [10213,10214]
operator: = [10213,10214]
===
match
---
name: dagrun [16934,16940]
name: dagrun [16934,16940]
===
match
---
name: ExternalTaskSensor [2457,2475]
name: ExternalTaskSensor [2457,2475]
===
match
---
operator: , [4414,4415]
operator: , [4414,4415]
===
match
---
name: DEFAULT_DATE [16540,16552]
name: DEFAULT_DATE [16540,16552]
===
match
---
operator: , [32387,32388]
operator: , [32773,32774]
===
match
---
string: "parent_dag_0" [24630,24644]
string: "parent_dag_0" [25016,25030]
===
match
---
atom_expr [1974,2024]
atom_expr [1974,2024]
===
match
---
expr_stmt [2452,2651]
expr_stmt [2452,2651]
===
match
---
param [7321,7325]
param [7321,7325]
===
match
---
operator: == [8778,8780]
operator: == [8778,8780]
===
match
---
atom_expr [10329,10352]
atom_expr [10329,10352]
===
match
---
trailer [6955,6963]
trailer [6955,6963]
===
match
---
argument [30746,30765]
argument [31132,31151]
===
match
---
trailer [17841,17851]
trailer [17841,17851]
===
match
---
for_stmt [21821,21895]
for_stmt [21821,21895]
===
match
---
atom [16920,16931]
atom [16920,16931]
===
match
---
name: raises [14154,14160]
name: raises [14154,14160]
===
match
---
argument [33676,33705]
argument [34062,34091]
===
match
---
argument [15434,15477]
argument [15434,15477]
===
match
---
simple_stmt [28750,28767]
simple_stmt [29136,29153]
===
match
---
arith_expr [29056,29063]
arith_expr [29442,29449]
===
match
---
name: execution_date_fn [21692,21709]
name: execution_date_fn [21692,21709]
===
match
---
name: self [5961,5965]
name: self [5961,5965]
===
match
---
trailer [4933,4940]
trailer [4933,4940]
===
match
---
name: dagrun [34467,34473]
name: dagrun [34853,34859]
===
match
---
parameters [17359,17365]
parameters [17359,17365]
===
match
---
trailer [12938,12947]
trailer [12938,12947]
===
match
---
operator: = [25011,25012]
operator: = [25397,25398]
===
match
---
suite [12095,12184]
suite [12095,12184]
===
match
---
assert_stmt [12831,12872]
assert_stmt [12831,12872]
===
match
---
name: op [2919,2921]
name: op [2919,2921]
===
match
---
simple_stmt [4384,4461]
simple_stmt [4384,4461]
===
match
---
name: daily_task [31070,31080]
name: daily_task [31456,31466]
===
match
---
arglist [30811,30875]
arglist [31197,31261]
===
match
---
arglist [6010,6036]
arglist [6010,6036]
===
match
---
argument [11791,11814]
argument [11791,11814]
===
match
---
arglist [25797,25831]
arglist [26183,26217]
===
match
---
simple_stmt [19704,19844]
simple_stmt [19704,19844]
===
match
---
fstring_expr [28459,28464]
fstring_expr [28845,28850]
===
match
---
trailer [25426,25432]
trailer [25812,25818]
===
match
---
operator: = [16314,16315]
operator: = [16314,16315]
===
match
---
name: check_existence [16382,16397]
name: check_existence [16382,16397]
===
match
---
operator: = [13158,13159]
operator: = [13158,13159]
===
match
---
name: assert_ti_state_equal [22674,22695]
name: assert_ti_state_equal [23060,23081]
===
match
---
atom_expr [31373,31391]
atom_expr [31759,31777]
===
match
---
name: pytest [20461,20467]
name: pytest [20461,20467]
===
match
---
assert_stmt [17066,17136]
assert_stmt [17066,17136]
===
match
---
atom_expr [3778,4041]
atom_expr [3778,4041]
===
match
---
argument [4701,4730]
argument [4701,4730]
===
match
---
name: test_external_task_sensor_delta [10282,10313]
name: test_external_task_sensor_delta [10282,10313]
===
match
---
atom_expr [27942,28083]
atom_expr [28328,28469]
===
match
---
operator: , [10991,10992]
operator: , [10991,10992]
===
match
---
name: dag [23216,23219]
name: dag [23602,23605]
===
match
---
argument [23328,23349]
argument [23714,23735]
===
match
---
operator: = [20109,20110]
operator: = [20109,20110]
===
match
---
trailer [20129,20239]
trailer [20129,20239]
===
match
---
operator: , [22394,22395]
operator: , [22394,22395]
===
match
---
argument [1830,1842]
argument [1830,1842]
===
match
---
operator: , [2690,2691]
operator: , [2690,2691]
===
match
---
name: TEST_TASK_ID [2835,2847]
name: TEST_TASK_ID [2835,2847]
===
match
---
atom_expr [30807,30876]
atom_expr [31193,31262]
===
match
---
param [12082,12085]
param [12082,12085]
===
match
---
expr_stmt [30274,30331]
expr_stmt [30660,30717]
===
match
---
arith_expr [11558,11580]
arith_expr [11558,11580]
===
match
---
name: task_id [15434,15441]
name: task_id [15434,15441]
===
match
---
operator: >> [33793,33795]
operator: >> [34179,34181]
===
match
---
name: execution_date [31405,31419]
name: execution_date [31791,31805]
===
match
---
operator: = [1798,1799]
operator: = [1798,1799]
===
match
---
operator: + [12169,12170]
operator: + [12169,12170]
===
match
---
operator: = [35041,35042]
operator: = [35427,35428]
===
match
---
name: dag [14957,14960]
name: dag [14957,14960]
===
match
---
operator: , [22423,22424]
operator: , [22423,22424]
===
match
---
number: 1 [11671,11672]
number: 1 [11671,11672]
===
match
---
name: dag_1 [19436,19441]
name: dag_1 [19436,19441]
===
match
---
string: "@daily" [33270,33278]
string: "@daily" [33656,33664]
===
match
---
operator: = [21075,21076]
operator: = [21075,21076]
===
match
---
with_item [5994,6043]
with_item [5994,6043]
===
match
---
name: dag_id [34179,34185]
name: dag_id [34565,34571]
===
match
---
trailer [25470,25476]
trailer [25856,25862]
===
match
---
operator: = [20146,20147]
operator: = [20146,20147]
===
match
---
expr_stmt [17458,17652]
expr_stmt [17458,17652]
===
match
---
simple_stmt [28096,28117]
simple_stmt [28482,28503]
===
match
---
operator: , [11472,11473]
operator: , [11472,11473]
===
match
---
term [31420,31458]
term [31806,31844]
===
match
---
atom_expr [28300,28484]
atom_expr [28686,28870]
===
match
---
name: TimeSensor [2222,2232]
name: TimeSensor [2222,2232]
===
match
---
name: delta [34124,34129]
name: delta [34510,34515]
===
match
---
name: dag [33822,33825]
name: dag [34208,34211]
===
match
---
expr_stmt [4568,4845]
expr_stmt [4568,4845]
===
match
---
name: self [10329,10333]
name: self [10329,10333]
===
match
---
argument [29083,29119]
argument [29469,29505]
===
match
---
name: other_dag [6838,6847]
name: other_dag [6838,6847]
===
match
---
operator: = [13116,13117]
operator: = [13116,13117]
===
match
---
name: tis_date_0 [26183,26193]
name: tis_date_0 [26569,26579]
===
match
---
fstring_start: f" [28348,28350]
fstring_start: f" [28734,28736]
===
match
---
expr_stmt [11344,11709]
expr_stmt [11344,11709]
===
match
---
name: op [7181,7183]
name: op [7181,7183]
===
match
---
name: dag_bag_ext [26678,26689]
name: dag_bag_ext [27064,27075]
===
match
---
name: external_dag_id [28383,28398]
name: external_dag_id [28769,28784]
===
match
---
suite [2411,2737]
suite [2411,2737]
===
match
---
trailer [34216,34224]
trailer [34602,34610]
===
match
---
string: "dag_2" [30510,30517]
string: "dag_2" [30896,30903]
===
match
---
number: 1 [8098,8099]
number: 1 [8098,8099]
===
match
---
string: "non-existing-task" [15900,15919]
string: "non-existing-task" [15900,15919]
===
match
---
fstring_end: " [28410,28411]
fstring_end: " [28796,28797]
===
match
---
name: assert_ti_state_equal [23839,23860]
name: assert_ti_state_equal [24225,24246]
===
match
---
suite [8967,8989]
suite [8967,8989]
===
match
---
operator: = [10236,10237]
operator: = [10236,10237]
===
match
---
suite [28903,29383]
suite [29289,29769]
===
match
---
import_as_names [943,981]
import_as_names [943,981]
===
match
---
string: "dag_1" [30448,30455]
string: "dag_1" [30834,30841]
===
match
---
expr_stmt [17734,17810]
expr_stmt [17734,17810]
===
match
---
operator: = [6135,6136]
operator: = [6135,6136]
===
match
---
trailer [12180,12183]
trailer [12180,12183]
===
match
---
operator: , [20402,20403]
operator: , [20402,20403]
===
match
---
trailer [6420,6430]
trailer [6420,6430]
===
match
---
operator: = [7805,7806]
operator: = [7805,7806]
===
match
---
funcdef [1844,1880]
funcdef [1844,1880]
===
match
---
name: isoformat [6421,6430]
name: isoformat [6421,6430]
===
match
---
name: airflow [1126,1133]
name: airflow [1126,1133]
===
match
---
operator: , [19186,19187]
operator: , [19186,19187]
===
match
---
argument [9966,9981]
argument [9966,9981]
===
match
---
name: external_dag_id [14296,14311]
name: external_dag_id [14296,14311]
===
match
---
name: dag_bag [24196,24203]
name: dag_bag [24582,24589]
===
match
---
name: airflow [1384,1391]
name: airflow [1384,1391]
===
match
---
name: dag [29441,29444]
name: dag [29827,29830]
===
match
---
simple_stmt [1303,1379]
simple_stmt [1303,1379]
===
match
---
operator: = [1757,1758]
operator: = [1757,1758]
===
match
---
name: dagrun_0_1 [25328,25338]
name: dagrun_0_1 [25714,25724]
===
match
---
name: op [6118,6120]
name: op [6118,6120]
===
match
---
argument [33227,33250]
argument [33613,33636]
===
match
---
atom_expr [17752,17810]
atom_expr [17752,17810]
===
match
---
parameters [3288,3294]
parameters [3288,3294]
===
match
---
argument [21872,21879]
argument [21872,21879]
===
match
---
name: tis [30274,30277]
name: tis [30660,30663]
===
match
---
with_item [21146,21216]
with_item [21146,21216]
===
match
---
string: 'reschedule' [21792,21804]
string: 'reschedule' [21792,21804]
===
match
---
suite [15025,15657]
suite [15025,15657]
===
match
---
name: DEFAULT_DATE [7199,7211]
name: DEFAULT_DATE [7199,7211]
===
match
---
operator: = [31934,31935]
operator: = [32320,32321]
===
match
---
name: start_date [19255,19265]
name: start_date [19255,19265]
===
match
---
name: dag_3 [20363,20368]
name: dag_3 [20363,20368]
===
match
---
simple_stmt [4536,4560]
simple_stmt [4536,4560]
===
match
---
operator: >> [19217,19219]
operator: >> [19217,19219]
===
match
---
name: external_task_id [33403,33419]
name: external_task_id [33789,33805]
===
match
---
operator: = [7522,7523]
operator: = [7522,7523]
===
match
---
atom_expr [6739,6829]
atom_expr [6739,6829]
===
match
---
name: DEFAULT_DATE [19662,19674]
name: DEFAULT_DATE [19662,19674]
===
match
---
name: task_b_0 [27931,27939]
name: task_b_0 [28317,28325]
===
match
---
name: execution_date [24489,24503]
name: execution_date [24875,24889]
===
match
---
name: pytest [32449,32455]
name: pytest [32835,32841]
===
match
---
atom_expr [3604,3617]
atom_expr [3604,3617]
===
match
---
atom_expr [5310,5324]
atom_expr [5310,5324]
===
match
---
name: day_1 [21760,21765]
name: day_1 [21760,21765]
===
match
---
name: dag [2280,2283]
name: dag [2280,2283]
===
match
---
name: TEST_DAG_ID [15511,15522]
name: TEST_DAG_ID [15511,15522]
===
match
---
operator: = [3134,3135]
operator: = [3134,3135]
===
match
---
arglist [3390,3649]
arglist [3390,3649]
===
match
---
operator: - [28407,28408]
operator: - [28793,28794]
===
match
---
trailer [4830,4834]
trailer [4830,4834]
===
match
---
operator: , [9479,9480]
operator: , [9479,9480]
===
match
---
name: body [33524,33528]
name: body [33910,33914]
===
match
---
name: dt [12915,12917]
name: dt [12915,12917]
===
match
---
name: task_a_3 [20100,20108]
name: task_a_3 [20100,20108]
===
match
---
atom_expr [17678,17725]
atom_expr [17678,17725]
===
match
---
funcdef [3245,3664]
funcdef [3245,3664]
===
match
---
operator: , [11034,11035]
operator: , [11034,11035]
===
match
---
name: raises [16012,16018]
name: raises [16012,16018]
===
match
---
operator: , [29444,29445]
operator: , [29830,29831]
===
match
---
operator: , [24518,24519]
operator: , [24904,24905]
===
match
---
atom_expr [4143,4375]
atom_expr [4143,4375]
===
match
---
operator: = [27985,27986]
operator: = [28371,28372]
===
match
---
name: DAG [19638,19641]
name: DAG [19638,19641]
===
match
---
operator: == [8935,8937]
operator: == [8935,8937]
===
match
---
atom_expr [10559,10571]
atom_expr [10559,10571]
===
match
---
operator: = [25765,25766]
operator: = [26151,26152]
===
match
---
param [9817,9819]
param [9817,9819]
===
match
---
name: NONE [26349,26353]
name: NONE [26735,26739]
===
match
---
arglist [26381,26406]
arglist [26767,26792]
===
match
---
name: ExternalTaskSensor [19319,19337]
name: ExternalTaskSensor [19319,19337]
===
match
---
number: 0 [2267,2268]
number: 0 [2267,2268]
===
match
---
simple_stmt [23839,23881]
simple_stmt [24225,24267]
===
match
---
argument [19763,19791]
argument [19763,19791]
===
match
---
name: state [25339,25344]
name: state [25725,25730]
===
match
---
trailer [17310,17312]
trailer [17310,17312]
===
match
---
name: self [5538,5542]
name: self [5538,5542]
===
match
---
atom_expr [13557,13582]
atom_expr [13557,13582]
===
match
---
trailer [34514,34520]
trailer [34900,34906]
===
match
---
operator: , [14464,14465]
operator: , [14464,14465]
===
match
---
operator: , [2248,2249]
operator: , [2248,2249]
===
match
---
name: start_date [28847,28857]
name: start_date [29233,29243]
===
match
---
name: external_dag_id [3449,3464]
name: external_dag_id [3449,3464]
===
match
---
arglist [3814,4027]
arglist [3814,4027]
===
match
---
argument [3218,3238]
argument [3218,3238]
===
match
---
funcdef [5465,6678]
funcdef [5465,6678]
===
match
---
name: retries [7937,7944]
name: retries [7937,7944]
===
match
---
name: append [27850,27856]
name: append [28236,28242]
===
match
---
name: create_dagrun [16842,16855]
name: create_dagrun [16842,16855]
===
match
---
operator: = [8064,8065]
operator: = [8064,8065]
===
match
---
name: end_date [11816,11824]
name: end_date [11816,11824]
===
match
---
operator: { [28837,28838]
operator: { [29223,29224]
===
match
---
suite [6718,7258]
suite [6718,7258]
===
match
---
operator: = [4424,4425]
operator: = [4424,4425]
===
match
---
operator: = [6788,6789]
operator: = [6788,6789]
===
match
---
argument [29321,29338]
argument [29707,29724]
===
match
---
name: DAG [28169,28172]
name: DAG [28555,28558]
===
match
---
operator: = [11348,11349]
operator: = [11348,11349]
===
match
---
arglist [19642,19698]
arglist [19642,19698]
===
match
---
name: include_examples [33176,33192]
name: include_examples [33562,33578]
===
match
---
operator: = [31144,31145]
operator: = [31530,31531]
===
match
---
atom [20341,20369]
atom [20341,20369]
===
match
---
trailer [6012,6016]
trailer [6012,6016]
===
match
---
atom_expr [28169,28233]
atom_expr [28555,28619]
===
match
---
operator: + [32055,32056]
operator: + [32441,32442]
===
match
---
arglist [31584,31603]
arglist [31970,31989]
===
match
---
operator: , [19582,19583]
operator: , [19582,19583]
===
match
---
name: TEST_TASK_ID [4718,4730]
name: TEST_TASK_ID [4718,4730]
===
match
---
name: match [26890,26895]
name: match [27276,27281]
===
match
---
argument [10712,10732]
argument [10712,10732]
===
match
---
operator: , [21804,21805]
operator: , [21804,21805]
===
match
---
argument [1981,2000]
argument [1981,2000]
===
match
---
trailer [22194,22201]
trailer [22194,22201]
===
match
---
name: clear_tasks [26062,26073]
name: clear_tasks [26448,26459]
===
match
---
trailer [13303,13373]
trailer [13303,13373]
===
match
---
name: TEST_TASK_ID [1699,1711]
name: TEST_TASK_ID [1699,1711]
===
match
---
trailer [16648,16650]
trailer [16648,16650]
===
match
---
name: pytest [14655,14661]
name: pytest [14655,14661]
===
match
---
name: task_id [19423,19430]
name: task_id [19423,19430]
===
match
---
atom_expr [24163,24180]
atom_expr [24549,24566]
===
match
---
operator: = [18882,18883]
operator: = [18882,18883]
===
match
---
operator: , [30904,30905]
operator: , [31290,31291]
===
match
---
name: external_task_id [3494,3510]
name: external_task_id [3494,3510]
===
match
---
name: allowed_states [3541,3555]
name: allowed_states [3541,3555]
===
match
---
name: start [31503,31508]
name: start [31889,31894]
===
match
---
operator: = [21791,21792]
operator: = [21791,21792]
===
match
---
expr_stmt [9595,10013]
expr_stmt [9595,10013]
===
match
---
simple_stmt [23606,23643]
simple_stmt [23992,24029]
===
match
---
name: DAG [19242,19245]
name: DAG [19242,19245]
===
match
---
atom [14919,14930]
atom [14919,14930]
===
match
---
name: external_dag_id [21605,21620]
name: external_dag_id [21605,21620]
===
match
---
decorated [23883,25494]
decorated [24269,25880]
===
match
---
trailer [22553,22561]
trailer [22939,22947]
===
match
---
name: BashOperator [1108,1120]
name: BashOperator [1108,1120]
===
match
---
name: refresh_from_task [22491,22508]
name: refresh_from_task [22877,22894]
===
match
---
name: unittest [17168,17176]
name: unittest [17168,17176]
===
match
---
operator: + [34107,34108]
operator: + [34493,34494]
===
match
---
suite [13583,13956]
suite [13583,13956]
===
match
---
param [14018,14022]
param [14018,14022]
===
match
---
argument [19536,19563]
argument [19536,19563]
===
match
---
atom [13239,13250]
atom [13239,13250]
===
match
---
operator: = [24219,24220]
operator: = [24605,24606]
===
match
---
name: ExternalTaskSensor [13596,13614]
name: ExternalTaskSensor [13596,13614]
===
match
---
operator: = [13898,13899]
operator: = [13898,13899]
===
match
---
name: dag_bag_ext [23701,23712]
name: dag_bag_ext [24087,24098]
===
match
---
simple_stmt [20508,21023]
simple_stmt [20508,21023]
===
match
---
arglist [19743,19837]
arglist [19743,19837]
===
match
---
operator: = [32040,32041]
operator: = [32426,32427]
===
match
---
argument [9943,9952]
argument [9943,9952]
===
match
---
operator: = [19750,19751]
operator: = [19750,19751]
===
match
---
arglist [23701,23729]
arglist [24087,24115]
===
match
---
trailer [8805,8816]
trailer [8805,8816]
===
match
---
name: dagrun [16823,16829]
name: dagrun [16823,16829]
===
match
---
argument [16554,16574]
argument [16554,16574]
===
match
---
name: DAG [21464,21467]
name: DAG [21464,21467]
===
match
---
trailer [30163,30166]
trailer [30549,30552]
===
match
---
dotted_name [31539,31562]
dotted_name [31925,31948]
===
match
---
name: allowed_states [11108,11122]
name: allowed_states [11108,11122]
===
match
---
decorated [30589,31536]
decorated [30975,31922]
===
match
---
operator: = [20089,20090]
operator: = [20089,20090]
===
match
---
string: 'templated_task' [16700,16716]
string: 'templated_task' [16700,16716]
===
match
---
comparison [22904,22932]
comparison [23290,23318]
===
match
---
name: flush [24593,24598]
name: flush [24979,24984]
===
match
---
argument [31405,31458]
argument [31791,31844]
===
match
---
atom_expr [3354,3663]
atom_expr [3354,3663]
===
match
---
simple_stmt [24080,24111]
simple_stmt [24466,24497]
===
match
---
argument [31310,31342]
argument [31696,31728]
===
match
---
expr_stmt [12193,12482]
expr_stmt [12193,12482]
===
match
---
trailer [30978,31013]
trailer [31364,31399]
===
match
---
operator: , [3006,3007]
operator: , [3006,3007]
===
match
---
trailer [34876,34945]
trailer [35262,35331]
===
match
---
name: ti [30560,30562]
name: ti [30946,30948]
===
match
---
dotted_name [26979,26993]
dotted_name [27365,27379]
===
match
---
name: instance [17000,17008]
name: instance [17000,17008]
===
match
---
name: pytest [10132,10138]
name: pytest [10132,10138]
===
match
---
argument [30906,30929]
argument [31292,31315]
===
match
---
operator: , [19826,19827]
operator: , [19826,19827]
===
match
---
name: self [4536,4540]
name: self [4536,4540]
===
match
---
atom_expr [9430,9438]
atom_expr [9430,9438]
===
match
---
argument [10585,10611]
argument [10585,10611]
===
match
---
simple_stmt [17975,18044]
simple_stmt [17975,18044]
===
match
---
operator: , [30306,30307]
operator: , [30692,30693]
===
match
---
operator: , [12785,12786]
operator: , [12785,12786]
===
match
---
name: value [5318,5323]
name: value [5318,5323]
===
match
---
trailer [26274,26301]
trailer [26660,26687]
===
match
---
operator: , [16529,16530]
operator: , [16529,16530]
===
match
---
with_stmt [33205,33801]
with_stmt [33591,34187]
===
match
---
atom_expr [2113,2153]
atom_expr [2113,2153]
===
match
---
trailer [5557,5574]
trailer [5557,5574]
===
match
---
argument [28697,28714]
argument [29083,29100]
===
match
---
name: task_b_0 [19220,19228]
name: task_b_0 [19220,19228]
===
match
---
argument [30318,30330]
argument [30704,30716]
===
match
---
import_from [1252,1302]
import_from [1252,1302]
===
match
---
string: "dag_0" [25929,25936]
string: "dag_0" [26315,26322]
===
match
---
name: bag_dag [30971,30978]
name: bag_dag [31357,31364]
===
match
---
expr_stmt [30194,30226]
expr_stmt [30580,30612]
===
match
---
expr_stmt [23735,23759]
expr_stmt [24121,24145]
===
match
---
name: execution_date_fn [13835,13852]
name: execution_date_fn [13835,13852]
===
match
---
name: DAG [17381,17384]
name: DAG [17381,17384]
===
match
---
name: external_dag_id [19907,19922]
name: external_dag_id [19907,19922]
===
match
---
name: instance [17073,17081]
name: instance [17073,17081]
===
match
---
operator: = [10364,10365]
operator: = [10364,10365]
===
match
---
atom_expr [11180,11257]
atom_expr [11180,11257]
===
match
---
fstring_expr [28405,28410]
fstring_expr [28791,28796]
===
match
---
operator: , [4300,4301]
operator: , [4300,4301]
===
match
---
string: "non-existing-dag" [16315,16333]
string: "non-existing-dag" [16315,16333]
===
match
---
simple_stmt [20304,20325]
simple_stmt [20304,20325]
===
match
---
operator: = [32372,32373]
operator: = [32758,32759]
===
match
---
name: start_date [4990,5000]
name: start_date [4990,5000]
===
match
---
argument [34902,34927]
argument [35288,35313]
===
match
---
operator: = [5582,5583]
operator: = [5582,5583]
===
match
---
argument [8031,8054]
argument [8031,8054]
===
match
---
argument [10459,10486]
argument [10459,10486]
===
match
---
parameters [2179,2207]
parameters [2179,2207]
===
match
---
name: ExternalTaskSensor [10869,10887]
name: ExternalTaskSensor [10869,10887]
===
match
---
atom_expr [28258,28274]
atom_expr [28644,28660]
===
match
---
operator: = [27906,27907]
operator: = [28292,28293]
===
match
---
name: dag_bag [30139,30146]
name: dag_bag [30525,30532]
===
match
---
expr_stmt [25837,25895]
expr_stmt [26223,26281]
===
match
---
operator: , [29258,29259]
operator: , [29644,29645]
===
match
---
name: external_dag_id [4660,4675]
name: external_dag_id [4660,4675]
===
match
---
argument [9995,10002]
argument [9995,10002]
===
match
---
name: dag_0 [25901,25906]
name: dag_0 [26287,26292]
===
match
---
name: Exception [8542,8551]
name: Exception [8542,8551]
===
match
---
operator: = [11221,11222]
operator: = [11221,11222]
===
match
---
atom_expr [25372,25388]
atom_expr [25758,25774]
===
match
---
trailer [21149,21207]
trailer [21149,21207]
===
match
---
name: dag_3 [20026,20031]
name: dag_3 [20026,20031]
===
match
---
argument [4391,4414]
argument [4391,4414]
===
match
---
name: failed_states [4783,4796]
name: failed_states [4783,4796]
===
match
---
trailer [30291,30331]
trailer [30677,30717]
===
match
---
operator: , [5943,5944]
operator: , [5943,5944]
===
match
---
operator: = [2886,2887]
operator: = [2886,2887]
===
match
---
name: end_date [3195,3203]
name: end_date [3195,3203]
===
match
---
simple_stmt [10657,10734]
simple_stmt [10657,10734]
===
match
---
operator: , [11134,11135]
operator: , [11134,11135]
===
match
---
simple_stmt [32025,32079]
simple_stmt [32411,32465]
===
match
---
argument [33719,33760]
argument [34105,34146]
===
match
---
name: TEST_DAG_ID [14811,14822]
name: TEST_DAG_ID [14811,14822]
===
match
---
trailer [25485,25493]
trailer [25871,25879]
===
match
---
operator: , [8100,8101]
operator: , [8100,8101]
===
match
---
operator: , [23349,23350]
operator: , [23735,23736]
===
match
---
string: "dag_0" [27767,27774]
string: "dag_0" [28153,28160]
===
match
---
arglist [34877,34944]
arglist [35263,35330]
===
match
---
operator: == [17104,17106]
operator: == [17104,17106]
===
match
---
argument [14948,14960]
argument [14948,14960]
===
match
---
trailer [25397,25404]
trailer [25783,25790]
===
match
---
name: task_a_0 [23647,23655]
name: task_a_0 [24033,24041]
===
match
---
atom_expr [34363,34382]
atom_expr [34749,34768]
===
match
---
atom_expr [24585,24600]
atom_expr [24971,24986]
===
match
---
suite [16037,16127]
suite [16037,16127]
===
match
---
argument [5038,5058]
argument [5038,5058]
===
match
---
operator: = [2043,2044]
operator: = [2043,2044]
===
match
---
name: TEST_TASK_ID [5583,5595]
name: TEST_TASK_ID [5583,5595]
===
match
---
atom [15594,15611]
atom [15594,15611]
===
match
---
dotted_name [20461,20475]
dotted_name [20461,20475]
===
match
---
atom_expr [21664,21678]
atom_expr [21664,21678]
===
match
---
string: "task_a_0" [29815,29825]
string: "task_a_0" [30201,30211]
===
match
---
operator: = [9894,9895]
operator: = [9894,9895]
===
match
---
operator: , [4646,4647]
operator: , [4646,4647]
===
match
---
name: deserialized_op [17990,18005]
name: deserialized_op [17990,18005]
===
match
---
simple_stmt [21226,21454]
simple_stmt [21226,21454]
===
match
---
operator: , [16428,16429]
operator: , [16428,16429]
===
match
---
expr_stmt [28291,28484]
expr_stmt [28677,28870]
===
match
---
operator: = [18863,18864]
operator: = [18863,18864]
===
match
---
name: TEST_TASK_ID [4288,4300]
name: TEST_TASK_ID [4288,4300]
===
match
---
name: dag [11148,11151]
name: dag [11148,11151]
===
match
---
atom_expr [31083,31132]
atom_expr [31469,31518]
===
match
---
atom_expr [27678,27729]
atom_expr [28064,28115]
===
match
---
operator: = [19065,19066]
operator: = [19065,19066]
===
match
---
argument [24520,24535]
argument [24906,24921]
===
match
---
name: execution_date [32115,32129]
name: execution_date [32501,32515]
===
match
---
name: task_id [4175,4182]
name: task_id [4175,4182]
===
match
---
argument [10964,10991]
argument [10964,10991]
===
match
---
name: operators [1086,1095]
name: operators [1086,1095]
===
match
---
string: 'success' [9469,9478]
string: 'success' [9469,9478]
===
match
---
simple_stmt [20244,20300]
simple_stmt [20244,20300]
===
match
---
operator: , [17620,17621]
operator: , [17620,17621]
===
match
---
atom_expr [20255,20299]
atom_expr [20255,20299]
===
match
---
name: day_2 [25292,25297]
name: day_2 [25678,25683]
===
match
---
name: dag_bag_head_tail [32468,32485]
name: dag_bag_head_tail [32854,32871]
===
match
---
number: 1 [29062,29063]
number: 1 [29448,29449]
===
match
---
expr_stmt [26695,26731]
expr_stmt [27081,27117]
===
match
---
argument [16057,16080]
argument [16057,16080]
===
match
---
argument [2271,2283]
argument [2271,2283]
===
match
---
operator: , [31296,31297]
operator: , [31682,31683]
===
match
---
operator: == [22924,22926]
operator: == [23310,23312]
===
match
---
funcdef [15662,16127]
funcdef [15662,16127]
===
match
---
operator: = [1681,1682]
operator: = [1681,1682]
===
match
---
arglist [17497,17642]
arglist [17497,17642]
===
match
---
fstring [28558,28571]
fstring [28944,28957]
===
match
---
for_stmt [31194,31517]
for_stmt [31580,31903]
===
match
---
operator: + [28671,28672]
operator: + [29057,29058]
===
match
---
name: dag [21825,21828]
name: dag [21825,21828]
===
match
---
string: """Check this task sensor passes multiple args with full context. If no failure, means clean run.""" [12629,12729]
string: """Check this task sensor passes multiple args with full context. If no failure, means clean run.""" [12629,12729]
===
match
---
operator: = [25848,25849]
operator: = [26234,26235]
===
match
---
name: dag_bag_head_tail [35078,35095]
name: dag_bag_head_tail [35464,35481]
===
match
---
argument [9410,9419]
argument [9410,9419]
===
match
---
name: external_task_id [19932,19948]
name: external_task_id [19932,19948]
===
match
---
funcdef [3669,4042]
funcdef [3669,4042]
===
match
---
arglist [16506,16574]
arglist [16506,16574]
===
match
---
argument [27899,27917]
argument [28285,28303]
===
match
---
argument [16730,16760]
argument [16730,16760]
===
match
---
param [11554,11556]
param [11554,11556]
===
match
---
arglist [17990,18025]
arglist [17990,18025]
===
match
---
name: DEFAULT_DATE [8781,8793]
name: DEFAULT_DATE [8781,8793]
===
match
---
operator: = [15970,15971]
operator: = [15970,15971]
===
match
---
name: dt [13864,13866]
name: dt [13864,13866]
===
match
---
suite [15729,16127]
suite [15729,16127]
===
match
---
name: dag [11695,11698]
name: dag [11695,11698]
===
match
---
name: dag [2628,2631]
name: dag [2628,2631]
===
match
---
name: SUCCESS [24572,24579]
name: SUCCESS [24958,24965]
===
match
---
string: "dag_2" [19527,19534]
string: "dag_2" [19527,19534]
===
match
---
operator: , [11837,11838]
operator: , [11837,11838]
===
match
---
simple_stmt [2452,2652]
simple_stmt [2452,2652]
===
match
---
atom_expr [4875,4881]
atom_expr [4875,4881]
===
match
---
name: dagrun_0_2 [25025,25035]
name: dagrun_0_2 [25411,25421]
===
match
---
trailer [4386,4390]
trailer [4386,4390]
===
match
---
name: TI [8760,8762]
name: TI [8760,8762]
===
match
---
fstring_start: f" [29200,29202]
fstring_start: f" [29586,29588]
===
match
---
name: ti [22447,22449]
name: ti [22849,22851]
===
match
---
operator: = [15190,15191]
operator: = [15190,15191]
===
match
---
param [11913,11917]
param [11913,11917]
===
match
---
atom_expr [19067,19203]
atom_expr [19067,19203]
===
match
---
atom_expr [7636,7656]
atom_expr [7636,7656]
===
match
---
name: schedule_interval [21501,21518]
name: schedule_interval [21501,21518]
===
match
---
trailer [14668,14680]
trailer [14668,14680]
===
match
---
name: args [2148,2152]
name: args [2148,2152]
===
match
---
trailer [25144,25152]
trailer [25530,25538]
===
match
---
atom_expr [26668,26690]
atom_expr [27054,27076]
===
match
---
operator: = [19156,19157]
operator: = [19156,19157]
===
match
---
argument [12419,12445]
argument [12419,12445]
===
match
---
trailer [12947,12957]
trailer [12947,12957]
===
match
---
string: 'parent_dag_0' [24955,24969]
string: 'parent_dag_0' [25341,25355]
===
match
---
atom_expr [6062,6093]
atom_expr [6062,6093]
===
match
---
with_item [21464,21533]
with_item [21464,21533]
===
match
---
trailer [11729,11736]
trailer [11729,11736]
===
match
---
fstring [31269,31296]
fstring [31655,31682]
===
match
---
simple_stmt [1121,1171]
simple_stmt [1121,1171]
===
match
---
atom_expr [22644,22661]
atom_expr [23030,23047]
===
match
---
arglist [25277,25314]
arglist [25663,25700]
===
match
---
decorated [22935,23459]
decorated [23321,23845]
===
match
---
fstring_end: " [28360,28361]
fstring_end: " [28746,28747]
===
match
---
name: dag_1 [19779,19784]
name: dag_1 [19779,19784]
===
match
---
name: dag_bag_cyclic [30149,30163]
name: dag_bag_cyclic [30535,30549]
===
match
---
simple_stmt [26820,26849]
simple_stmt [27206,27235]
===
match
---
operator: { [17039,17040]
operator: { [17039,17040]
===
match
---
param [31650,31666]
param [32036,32052]
===
match
---
name: self [17360,17364]
name: self [17360,17364]
===
match
---
name: TEST_DAG_ID [4246,4257]
name: TEST_DAG_ID [4246,4257]
===
match
---
trailer [10138,10145]
trailer [10138,10145]
===
match
---
name: get_dagrun [25266,25276]
name: get_dagrun [25652,25662]
===
match
---
fstring_end: " [17060,17061]
fstring_end: " [17060,17061]
===
match
---
name: DEFAULT_DATE [25710,25722]
name: DEFAULT_DATE [26096,26108]
===
match
---
name: ExternalTaskSensor [15398,15416]
name: ExternalTaskSensor [15398,15416]
===
match
---
argument [31160,31175]
argument [31546,31561]
===
match
---
operator: = [2333,2334]
operator: = [2333,2334]
===
match
---
argument [9539,9554]
argument [9539,9554]
===
match
---
name: op1 [12193,12196]
name: op1 [12193,12196]
===
match
---
name: task_a_0 [27874,27882]
name: task_a_0 [28260,28268]
===
match
---
name: ExternalTaskSensor [1233,1251]
name: ExternalTaskSensor [1233,1251]
===
match
---
string: "tail" [33420,33426]
string: "tail" [33806,33812]
===
match
---
trailer [6861,6973]
trailer [6861,6973]
===
match
---
name: assertLogs [4864,4874]
name: assertLogs [4864,4874]
===
match
---
name: mode [21787,21791]
name: mode [21787,21791]
===
match
---
trailer [10663,10733]
trailer [10663,10733]
===
match
---
operator: , [15869,15870]
operator: , [15869,15870]
===
match
---
name: external_task [1192,1205]
name: external_task [1192,1205]
===
match
---
name: task [34395,34399]
name: task [34781,34785]
===
match
---
fstring_end: " [34342,34343]
fstring_end: " [34728,34729]
===
match
---
atom_expr [17115,17134]
atom_expr [17115,17134]
===
match
---
trailer [3562,3570]
trailer [3562,3570]
===
match
---
operator: = [21176,21177]
operator: = [21176,21177]
===
match
---
trailer [2106,2110]
trailer [2106,2110]
===
match
---
argument [10251,10271]
argument [10251,10271]
===
match
---
argument [33403,33426]
argument [33789,33812]
===
match
---
name: DEFAULT_DATE [4425,4437]
name: DEFAULT_DATE [4425,4437]
===
match
---
name: ExternalTaskSensor [11350,11368]
name: ExternalTaskSensor [11350,11368]
===
match
---
name: run [7184,7187]
name: run [7184,7187]
===
match
---
name: test_time_sensor [12743,12759]
name: test_time_sensor [12743,12759]
===
match
---
argument [21086,21108]
argument [21086,21108]
===
match
---
trailer [9862,9865]
trailer [9862,9865]
===
match
---
simple_stmt [13596,13956]
simple_stmt [13596,13956]
===
match
---
argument [29446,29458]
argument [29832,29844]
===
match
---
argument [34119,34129]
argument [34505,34515]
===
match
---
trailer [1919,1928]
trailer [1919,1928]
===
match
---
name: timezone [1518,1526]
name: timezone [1518,1526]
===
match
---
trailer [4874,4902]
trailer [4874,4902]
===
match
---
name: start_date [8270,8280]
name: start_date [8270,8280]
===
match
---
name: DEFAULT_DATE [10059,10071]
name: DEFAULT_DATE [10059,10071]
===
match
---
expr_stmt [5667,5980]
expr_stmt [5667,5980]
===
match
---
operator: = [19831,19832]
operator: = [19831,19832]
===
match
---
trailer [22387,22394]
trailer [22387,22394]
===
match
---
operator: , [29303,29304]
operator: , [29689,29690]
===
match
---
name: dag [28928,28931]
name: dag [29314,29317]
===
match
---
operator: = [4287,4288]
operator: = [4287,4288]
===
match
---
expr_stmt [17375,17449]
expr_stmt [17375,17449]
===
match
---
name: dagbag [1965,1971]
name: dagbag [1965,1971]
===
match
---
argument [15540,15561]
argument [15540,15561]
===
match
---
atom_expr [21235,21453]
atom_expr [21235,21453]
===
match
---
atom_expr [11082,11094]
atom_expr [11082,11094]
===
match
---
name: quarantined [31551,31562]
name: quarantined [31937,31948]
===
match
---
name: level [4883,4888]
name: level [4883,4888]
===
match
---
name: i [31457,31458]
name: i [31843,31844]
===
match
---
simple_stmt [5553,5597]
simple_stmt [5553,5597]
===
match
---
name: dag_0 [19192,19197]
name: dag_0 [19192,19197]
===
match
---
name: test_external_task_sensor_failed_states_as_success_mulitple_task_ids [5469,5537]
name: test_external_task_sensor_failed_states_as_success_mulitple_task_ids [5469,5537]
===
match
---
name: DEFAULT_DATE [21992,22004]
name: DEFAULT_DATE [21992,22004]
===
match
---
trailer [26794,26803]
trailer [27180,27189]
===
match
---
with_item [4927,4965]
with_item [4927,4965]
===
match
---
name: n [28130,28131]
name: n [28516,28517]
===
match
---
operator: = [9273,9274]
operator: = [9273,9274]
===
match
---
operator: { [29055,29056]
operator: { [29441,29442]
===
match
---
comparison [17891,17966]
comparison [17891,17966]
===
match
---
atom_expr [4536,4559]
atom_expr [4536,4559]
===
match
---
operator: } [22164,22165]
operator: } [22164,22165]
===
match
---
operator: = [5826,5827]
operator: = [5826,5827]
===
match
---
with_stmt [4854,5460]
with_stmt [4854,5460]
===
match
---
name: airflow [1504,1511]
name: airflow [1504,1511]
===
match
---
atom_expr [23823,23833]
atom_expr [24209,24219]
===
match
---
name: ExternalTaskSensor [9182,9200]
name: ExternalTaskSensor [9182,9200]
===
match
---
atom_expr [17270,17312]
atom_expr [17270,17312]
===
match
---
atom_expr [16050,16126]
atom_expr [16050,16126]
===
match
---
trailer [19733,19843]
trailer [19733,19843]
===
match
---
expr_stmt [23647,23684]
expr_stmt [24033,24070]
===
match
---
name: external_dag_id [5768,5783]
name: external_dag_id [5768,5783]
===
match
---
name: dag [15629,15632]
name: dag [15629,15632]
===
match
---
name: external_dag_id [27998,28013]
name: external_dag_id [28384,28399]
===
match
---
trailer [29174,29353]
trailer [29560,29739]
===
match
---
trailer [2116,2153]
trailer [2116,2153]
===
match
---
name: str [6497,6500]
name: str [6497,6500]
===
match
---
trailer [21467,21524]
trailer [21467,21524]
===
match
---
argument [23411,23426]
argument [23797,23812]
===
match
---
name: dag [24474,24477]
name: dag [24860,24863]
===
match
---
name: ExternalTaskMarker [28510,28528]
name: ExternalTaskMarker [28896,28914]
===
match
---
expr_stmt [2217,2284]
expr_stmt [2217,2284]
===
match
---
arglist [1657,1667]
arglist [1657,1667]
===
match
---
suite [22781,22933]
suite [23167,23319]
===
match
---
name: TEST_DAG_ID [3889,3900]
name: TEST_DAG_ID [3889,3900]
===
match
---
return_stmt [33850,33864]
return_stmt [34236,34250]
===
match
---
operator: , [14886,14887]
operator: , [14886,14887]
===
match
---
trailer [6031,6036]
trailer [6031,6036]
===
match
---
trailer [34300,34307]
trailer [34686,34693]
===
match
---
atom_expr [15743,15990]
atom_expr [15743,15990]
===
match
---
fstring_string: dag_ [28833,28837]
fstring_string: dag_ [29219,29223]
===
match
---
simple_stmt [33138,33200]
simple_stmt [33524,33586]
===
match
---
atom [30344,30537]
atom [30730,30923]
===
match
---
assert_stmt [12108,12146]
assert_stmt [12108,12146]
===
match
---
name: DEFAULT_DATE [17115,17127]
name: DEFAULT_DATE [17115,17127]
===
match
---
param [22774,22779]
param [23160,23165]
===
match
---
argument [7114,7135]
argument [7114,7135]
===
match
---
name: get_task [25959,25967]
name: get_task [26345,26353]
===
match
---
expr_stmt [8570,8872]
expr_stmt [8570,8872]
===
match
---
name: assert_ti_state_equal [26306,26327]
name: assert_ti_state_equal [26692,26713]
===
match
---
arglist [2300,2368]
arglist [2300,2368]
===
match
---
operator: , [23041,23042]
operator: , [23427,23428]
===
match
---
trailer [33594,33771]
trailer [33980,34157]
===
match
---
operator: = [25887,25888]
operator: = [26273,26274]
===
match
---
comparison [8760,8816]
comparison [8760,8816]
===
match
---
atom_expr [28954,29134]
atom_expr [29340,29520]
===
match
---
atom_expr [24939,25020]
atom_expr [25325,25406]
===
match
---
trailer [11156,11160]
trailer [11156,11160]
===
match
---
argument [30979,30992]
argument [31365,31378]
===
match
---
dotted_name [1384,1405]
dotted_name [1384,1405]
===
match
---
name: DEFAULT_DATE [2701,2713]
name: DEFAULT_DATE [2701,2713]
===
match
---
trailer [3315,3322]
trailer [3315,3322]
===
match
---
operator: = [19552,19553]
operator: = [19552,19553]
===
match
---
operator: , [16285,16286]
operator: , [16285,16286]
===
match
---
arglist [7896,7964]
arglist [7896,7964]
===
match
---
simple_stmt [20100,20240]
simple_stmt [20100,20240]
===
match
---
operator: , [32113,32114]
operator: , [32499,32500]
===
match
---
operator: , [23087,23088]
operator: , [23473,23474]
===
match
---
name: allowed_states [13884,13898]
name: allowed_states [13884,13898]
===
match
---
trailer [9078,9150]
trailer [9078,9150]
===
match
---
suite [15065,15345]
suite [15065,15345]
===
match
---
name: start_date [22329,22339]
name: start_date [22329,22339]
===
match
---
operator: = [22594,22595]
operator: = [22980,22981]
===
match
---
operator: = [19191,19192]
operator: = [19191,19192]
===
match
---
name: end_date [23359,23367]
name: end_date [23745,23753]
===
match
---
name: session [22595,22602]
name: session [22981,22988]
===
match
---
name: test_time_sensor [2163,2179]
name: test_time_sensor [2163,2179]
===
match
---
atom_expr [1864,1879]
atom_expr [1864,1879]
===
match
---
number: 1 [8907,8908]
number: 1 [8907,8908]
===
match
---
operator: = [7606,7607]
operator: = [7606,7607]
===
match
---
string: 'head_tail' [34002,34013]
string: 'head_tail' [34388,34399]
===
match
---
argument [3020,3047]
argument [3020,3047]
===
match
---
argument [28643,28675]
argument [29029,29061]
===
match
---
atom_expr [32087,32145]
atom_expr [32473,32531]
===
match
---
name: session [25201,25208]
name: session [25587,25594]
===
match
---
atom_expr [17241,17313]
atom_expr [17241,17313]
===
match
---
operator: = [4571,4572]
operator: = [4571,4572]
===
match
---
name: start_date [30824,30834]
name: start_date [31210,31220]
===
match
---
name: DummyOperator [20255,20268]
name: DummyOperator [20255,20268]
===
match
---
trailer [24946,24954]
trailer [25332,25340]
===
match
---
expr_stmt [26820,26848]
expr_stmt [27206,27234]
===
match
---
name: dag_bag [30963,30970]
name: dag_bag [31349,31356]
===
match
---
trailer [27684,27729]
trailer [28070,28115]
===
match
---
argument [10228,10249]
argument [10228,10249]
===
match
---
suite [16486,16576]
suite [16486,16576]
===
match
---
trailer [8852,8856]
trailer [8852,8856]
===
match
---
operator: , [34900,34901]
operator: , [35286,35287]
===
match
---
simple_stmt [10863,11172]
simple_stmt [10863,11172]
===
match
---
simple_stmt [22786,22857]
simple_stmt [23172,23243]
===
match
---
name: utils [1556,1561]
name: utils [1556,1561]
===
match
---
argument [23386,23401]
argument [23772,23787]
===
match
---
name: execution_date [21742,21756]
name: execution_date [21742,21756]
===
match
---
name: test_time_sensor [5558,5574]
name: test_time_sensor [5558,5574]
===
match
---
atom_expr [23254,23266]
atom_expr [23640,23652]
===
match
---
dotted_name [1257,1284]
dotted_name [1257,1284]
===
match
---
operator: , [19395,19396]
operator: , [19395,19396]
===
match
---
atom_expr [34290,34307]
atom_expr [34676,34693]
===
match
---
expr_stmt [19452,19599]
expr_stmt [19452,19599]
===
match
---
operator: = [33529,33530]
operator: = [33915,33916]
===
match
---
argument [8341,8361]
argument [8341,8361]
===
match
---
argument [11148,11160]
argument [11148,11160]
===
match
---
operator: , [7161,7162]
operator: , [7161,7162]
===
match
---
operator: = [21875,21876]
operator: = [21875,21876]
===
match
---
name: sorted [30541,30547]
name: sorted [30927,30933]
===
match
---
atom_expr [8222,8375]
atom_expr [8222,8375]
===
match
---
expr_stmt [8179,8196]
expr_stmt [8179,8196]
===
match
---
argument [19651,19674]
argument [19651,19674]
===
match
---
atom_expr [30541,30586]
atom_expr [30927,30972]
===
match
---
simple_stmt [10361,10649]
simple_stmt [10361,10649]
===
match
---
name: setUp [1939,1944]
name: setUp [1939,1944]
===
match
---
argument [17590,17620]
argument [17590,17620]
===
match
---
arglist [10398,10638]
arglist [10398,10638]
===
match
---
name: delta [34336,34341]
name: delta [34722,34727]
===
match
---
operator: , [13276,13277]
operator: , [13276,13277]
===
match
---
string: "@daily" [30867,30875]
string: "@daily" [31253,31261]
===
match
---
argument [32115,32144]
argument [32501,32530]
===
match
---
arglist [30979,31012]
arglist [31365,31398]
===
match
---
atom_expr [17381,17449]
atom_expr [17381,17449]
===
match
---
name: dag [9995,9998]
name: dag [9995,9998]
===
match
---
trailer [10043,10047]
trailer [10043,10047]
===
match
---
argument [24724,24740]
argument [25110,25126]
===
match
---
name: state [1448,1453]
name: state [1448,1453]
===
match
---
name: task_a_0 [23721,23729]
name: task_a_0 [24107,24115]
===
match
---
argument [4822,4834]
argument [4822,4834]
===
match
---
arith_expr [12166,12183]
arith_expr [12166,12183]
===
match
---
name: operators [1134,1143]
name: operators [1134,1143]
===
match
---
name: session [1398,1405]
name: session [1398,1405]
===
match
---
simple_stmt [1499,1543]
simple_stmt [1499,1543]
===
match
---
arith_expr [28616,28619]
arith_expr [29002,29005]
===
match
---
for_stmt [24373,24581]
for_stmt [24759,24967]
===
match
---
trailer [7707,7828]
trailer [7707,7828]
===
match
---
trailer [7611,7616]
trailer [7611,7616]
===
match
---
operator: = [21312,21313]
operator: = [21312,21313]
===
match
---
string: "child_dag_1" [21313,21326]
string: "child_dag_1" [21313,21326]
===
match
---
atom_expr [21058,21109]
atom_expr [21058,21109]
===
match
---
atom_expr [15039,15064]
atom_expr [15039,15064]
===
match
---
operator: , [31594,31595]
operator: , [31980,31981]
===
match
---
decorator [23883,23900]
decorator [24269,24286]
===
match
---
suite [3725,4042]
suite [3725,4042]
===
match
---
name: task_id [31160,31167]
name: task_id [31546,31553]
===
match
---
operator: } [31290,31291]
operator: } [31676,31677]
===
match
---
operator: = [9180,9181]
operator: = [9180,9181]
===
match
---
atom_expr [29800,29826]
atom_expr [30186,30212]
===
match
---
name: date_0 [25825,25831]
name: date_0 [26211,26217]
===
match
---
expr_stmt [9159,9586]
expr_stmt [9159,9586]
===
match
---
fstring_expr [28669,28674]
fstring_expr [29055,29060]
===
match
---
name: self [4091,4095]
name: self [4091,4095]
===
match
---
trailer [26722,26731]
trailer [27108,27117]
===
match
---
funcdef [12574,13374]
funcdef [12574,13374]
===
match
---
name: dag_bag_multiple [31650,31666]
name: dag_bag_multiple [32036,32052]
===
match
---
operator: { [31292,31293]
operator: { [31678,31679]
===
match
---
import_as_names [839,854]
import_as_names [839,854]
===
match
---
with_stmt [10127,10273]
with_stmt [10127,10273]
===
match
---
name: ti [34426,34428]
name: ti [34812,34814]
===
match
---
funcdef [23900,25494]
funcdef [24286,25880]
===
match
---
fstring_string: task_b_ [29202,29209]
fstring_string: task_b_ [29588,29595]
===
match
---
dotted_name [1591,1610]
dotted_name [1591,1610]
===
match
---
operator: , [25199,25200]
operator: , [25585,25586]
===
match
---
atom [21771,21773]
atom [21771,21773]
===
match
---
trailer [22264,22272]
trailer [22264,22272]
===
match
---
argument [5627,5657]
argument [5627,5657]
===
match
---
trailer [26803,26815]
trailer [27189,27201]
===
match
---
operator: , [9109,9110]
operator: , [9109,9110]
===
match
---
sync_comp_for [9421,9438]
sync_comp_for [9421,9438]
===
match
---
name: e [8555,8556]
name: e [8555,8556]
===
match
---
operator: , [33426,33427]
operator: , [33812,33813]
===
match
---
name: task_without_failure [10023,10043]
name: task_without_failure [10023,10043]
===
match
---
trailer [15052,15064]
trailer [15052,15064]
===
match
---
operator: >> [29373,29375]
operator: >> [29759,29761]
===
match
---
simple_stmt [22644,22662]
simple_stmt [23030,23048]
===
match
---
name: dag_bag [29421,29428]
name: dag_bag [29807,29814]
===
match
---
shift_expr [33780,33800]
shift_expr [34166,34186]
===
match
---
operator: , [27704,27705]
operator: , [28090,28091]
===
match
---
operator: { [34335,34336]
operator: { [34721,34722]
===
match
---
trailer [19245,19303]
trailer [19245,19303]
===
match
---
operator: = [33974,33975]
operator: = [34360,34361]
===
match
---
name: day_2 [24140,24145]
name: day_2 [24526,24531]
===
match
---
name: execution_date [34077,34091]
name: execution_date [34463,34477]
===
match
---
operator: = [21518,21519]
operator: = [21518,21519]
===
match
---
trailer [19085,19203]
trailer [19085,19203]
===
match
---
operator: = [3203,3204]
operator: = [3203,3204]
===
match
---
name: external_dag_id [29235,29250]
name: external_dag_id [29621,29636]
===
match
---
operator: , [3143,3144]
operator: , [3143,3144]
===
match
---
argument [29868,29901]
argument [30254,30287]
===
match
---
name: get_dag [26715,26722]
name: get_dag [27101,27108]
===
match
---
trailer [13570,13582]
trailer [13570,13582]
===
match
---
operator: { [31271,31272]
operator: { [31657,31658]
===
match
---
trailer [27898,27918]
trailer [28284,28304]
===
match
---
operator: , [9778,9779]
operator: , [9778,9779]
===
match
---
trailer [14204,14509]
trailer [14204,14509]
===
match
---
name: test_time_sensor [2425,2441]
name: test_time_sensor [2425,2441]
===
match
---
operator: + [11080,11081]
operator: + [11080,11081]
===
match
---
argument [3131,3143]
argument [3131,3143]
===
match
---
name: seconds [8329,8336]
name: seconds [8329,8336]
===
match
---
name: self [14549,14553]
name: self [14549,14553]
===
match
---
operator: , [21084,21085]
operator: , [21084,21085]
===
match
---
trailer [2636,2640]
trailer [2636,2640]
===
match
---
name: end_date [24742,24750]
name: end_date [25128,25136]
===
match
---
name: assert_ti_state_equal [23793,23814]
name: assert_ti_state_equal [24179,24200]
===
match
---
expr_stmt [31138,31189]
expr_stmt [31524,31575]
===
match
---
param [22973,22981]
param [23359,23367]
===
match
---
trailer [24699,24774]
trailer [25085,25160]
===
match
---
operator: , [1479,1480]
operator: , [1479,1480]
===
match
---
suite [17225,17314]
suite [17225,17314]
===
match
---
atom [9394,9439]
atom [9394,9439]
===
match
---
name: TEST_TASK_ID_ALTERNATE [2887,2909]
name: TEST_TASK_ID_ALTERNATE [2887,2909]
===
match
---
name: airflow [1043,1050]
name: airflow [1043,1050]
===
match
---
simple_stmt [12885,12958]
simple_stmt [12885,12958]
===
match
---
atom_expr [16499,16575]
atom_expr [16499,16575]
===
match
---
name: dag_bag [24080,24087]
name: dag_bag [24466,24473]
===
match
---
param [17360,17364]
param [17360,17364]
===
match
---
name: DEFAULT_DATE [5001,5013]
name: DEFAULT_DATE [5001,5013]
===
match
---
argument [7019,7059]
argument [7019,7059]
===
match
---
operator: = [7771,7772]
operator: = [7771,7772]
===
match
---
param [4521,4525]
param [4521,4525]
===
match
---
name: task_id [22525,22532]
name: task_id [22911,22918]
===
match
---
trailer [14568,14585]
trailer [14568,14585]
===
match
---
trailer [26236,26248]
trailer [26622,26634]
===
match
---
fstring_string: dag_ [28611,28615]
fstring_string: dag_ [28997,29001]
===
match
---
name: execution_date [21977,21991]
name: execution_date [21977,21991]
===
match
---
name: recursion_depth [19565,19580]
name: recursion_depth [19565,19580]
===
match
---
string: "task_b_0" [30395,30405]
string: "task_b_0" [30781,30791]
===
match
---
operator: = [2240,2241]
operator: = [2240,2241]
===
match
---
operator: , [12405,12406]
operator: , [12405,12406]
===
match
---
string: "parent_dag_0" [21150,21164]
string: "parent_dag_0" [21150,21164]
===
match
---
operator: , [33622,33623]
operator: , [34008,34009]
===
match
---
parameters [15722,15728]
parameters [15722,15728]
===
match
---
argument [30931,30957]
argument [31317,31343]
===
match
---
operator: } [28843,28844]
operator: } [29229,29230]
===
match
---
name: task_id [31283,31290]
name: task_id [31669,31676]
===
match
---
atom_expr [19383,19395]
atom_expr [19383,19395]
===
match
---
operator: , [843,844]
operator: , [843,844]
===
match
---
operator: = [10111,10112]
operator: = [10111,10112]
===
match
---
name: test_external_task_sensor_waits_for_task_check_existence [15666,15722]
name: test_external_task_sensor_waits_for_task_check_existence [15666,15722]
===
match
---
trailer [23258,23266]
trailer [23644,23652]
===
match
---
trailer [5609,5626]
trailer [5609,5626]
===
match
---
argument [6150,6171]
argument [6150,6171]
===
match
---
atom_expr [13010,13287]
atom_expr [13010,13287]
===
match
---
simple_stmt [2293,2370]
simple_stmt [2293,2370]
===
match
---
operator: , [28183,28184]
operator: , [28569,28570]
===
match
---
name: days [34119,34123]
name: days [34505,34509]
===
match
---
simple_stmt [26934,26976]
simple_stmt [27320,27362]
===
match
---
expr_stmt [7837,7974]
expr_stmt [7837,7974]
===
match
---
name: dag [13937,13940]
name: dag [13937,13940]
===
match
---
trailer [3752,3764]
trailer [3752,3764]
===
match
---
atom_expr [8726,8738]
atom_expr [8726,8738]
===
match
---
string: "task_1" [21583,21591]
string: "task_1" [21583,21591]
===
match
---
name: dag_external [7558,7570]
name: dag_external [7558,7570]
===
match
---
trailer [15045,15052]
trailer [15045,15052]
===
match
---
name: ignore_ti_state [12547,12562]
name: ignore_ti_state [12547,12562]
===
match
---
arglist [15775,15980]
arglist [15775,15980]
===
match
---
operator: = [25135,25136]
operator: = [25521,25522]
===
match
---
atom_expr [22222,22434]
atom_expr [22222,22434]
===
match
---
operator: = [31372,31373]
operator: = [31758,31759]
===
match
---
atom_expr [25909,25937]
atom_expr [26295,26323]
===
match
---
name: self [16420,16424]
name: self [16420,16424]
===
match
---
name: dag_bag [30202,30209]
name: dag_bag [30588,30595]
===
match
---
import_from [818,854]
import_from [818,854]
===
match
---
argument [19397,19430]
argument [19397,19430]
===
match
---
testlist_comp [24438,24450]
testlist_comp [24824,24836]
===
match
---
name: pytest [16454,16460]
name: pytest [16454,16460]
===
match
---
operator: , [34307,34308]
operator: , [34693,34694]
===
match
---
expr_stmt [30139,30166]
expr_stmt [30525,30552]
===
match
---
arglist [2956,3144]
arglist [2956,3144]
===
match
---
operator: = [11021,11022]
operator: = [11021,11022]
===
match
---
operator: } [28409,28410]
operator: } [28795,28796]
===
match
---
name: minutes [9139,9146]
name: minutes [9139,9146]
===
match
---
with_stmt [21141,21454]
with_stmt [21141,21454]
===
match
---
name: TestCase [1920,1928]
name: TestCase [1920,1928]
===
match
---
argument [19743,19761]
argument [19743,19761]
===
match
---
operator: = [2220,2221]
operator: = [2220,2221]
===
match
---
parameters [4090,4096]
parameters [4090,4096]
===
match
---
expr_stmt [19056,19203]
expr_stmt [19056,19203]
===
match
---
simple_stmt [30795,30877]
simple_stmt [31181,31263]
===
match
---
string: "parent_task" [17505,17518]
string: "parent_task" [17505,17518]
===
match
---
arglist [13042,13277]
arglist [13042,13277]
===
match
---
name: ValueError [14161,14171]
name: ValueError [14161,14171]
===
match
---
atom_expr [16934,16955]
atom_expr [16934,16955]
===
match
---
operator: = [3602,3603]
operator: = [3602,3603]
===
match
---
shift_expr [28096,28116]
shift_expr [28482,28502]
===
match
---
operator: = [11801,11802]
operator: = [11801,11802]
===
match
---
operator: >> [19613,19615]
operator: >> [19613,19615]
===
match
---
name: ExternalTaskMarker [19859,19877]
name: ExternalTaskMarker [19859,19877]
===
match
---
suite [4909,5460]
suite [4909,5460]
===
match
---
atom_expr [33148,33199]
atom_expr [33534,33585]
===
match
---
operator: , [19761,19762]
operator: , [19761,19762]
===
match
---
name: allowed_states [15579,15593]
name: allowed_states [15579,15593]
===
match
---
name: DEFAULT_DATE [23029,23041]
name: DEFAULT_DATE [23415,23427]
===
match
---
simple_stmt [25409,25449]
simple_stmt [25795,25835]
===
match
---
string: 'task_external_without_failure' [9320,9351]
string: 'task_external_without_failure' [9320,9351]
===
match
---
name: task_a_0 [18996,19004]
name: task_a_0 [18996,19004]
===
match
---
assert_stmt [17234,17313]
assert_stmt [17234,17313]
===
match
---
decorated [32448,33865]
decorated [32834,34251]
===
match
---
for_stmt [34042,34549]
for_stmt [34428,34935]
===
match
---
trailer [8762,8777]
trailer [8762,8777]
===
match
---
operator: , [28714,28715]
operator: , [29100,29101]
===
match
---
testlist_comp [30417,30436]
testlist_comp [30803,30822]
===
match
---
expr_stmt [2919,3154]
expr_stmt [2919,3154]
===
match
---
simple_stmt [18922,18992]
simple_stmt [18922,18992]
===
match
---
operator: = [16864,16865]
operator: = [16864,16865]
===
match
---
atom_expr [6497,6511]
atom_expr [6497,6511]
===
match
---
atom_expr [17826,17851]
atom_expr [17826,17851]
===
match
---
name: op1 [13004,13007]
name: op1 [13004,13007]
===
match
---
argument [13142,13171]
argument [13142,13171]
===
match
---
name: session [24520,24527]
name: session [24906,24913]
===
match
---
atom_expr [26343,26353]
atom_expr [26729,26739]
===
match
---
name: dag [4023,4026]
name: dag [4023,4026]
===
match
---
atom_expr [10132,10167]
atom_expr [10132,10167]
===
match
---
operator: , [7135,7136]
operator: , [7135,7136]
===
match
---
operator: , [13087,13088]
operator: , [13087,13088]
===
match
---
name: TEST_DAG_ID [11461,11472]
name: TEST_DAG_ID [11461,11472]
===
match
---
simple_stmt [24231,24272]
simple_stmt [24617,24658]
===
match
---
operator: = [26224,26225]
operator: = [26610,26611]
===
match
---
trailer [26871,26924]
trailer [27257,27310]
===
match
---
trailer [8926,8934]
trailer [8926,8934]
===
match
---
operator: = [12353,12354]
operator: = [12353,12354]
===
match
---
operator: } [17259,17260]
operator: } [17259,17260]
===
match
---
trailer [1877,1879]
trailer [1877,1879]
===
match
---
argument [9733,9778]
argument [9733,9778]
===
match
---
operator: , [30517,30518]
operator: , [30903,30904]
===
match
---
expr_stmt [18922,18991]
expr_stmt [18922,18991]
===
match
---
name: fixture [30597,30604]
name: fixture [30983,30990]
===
match
---
name: timedelta [9400,9409]
name: timedelta [9400,9409]
===
match
---
name: session [24766,24773]
name: session [25152,25159]
===
match
---
simple_stmt [17734,17811]
simple_stmt [17734,17811]
===
match
---
name: get_dag [25921,25928]
name: get_dag [26307,26314]
===
match
---
atom [22163,22165]
atom [22163,22165]
===
match
---
parameters [26449,26462]
parameters [26835,26848]
===
match
---
trailer [23776,23788]
trailer [24162,24174]
===
match
---
name: dag [20413,20416]
name: dag [20413,20416]
===
match
---
trailer [9435,9438]
trailer [9435,9438]
===
match
---
name: pytest [4927,4933]
name: pytest [4927,4933]
===
match
---
name: NONE [26402,26406]
name: NONE [26788,26792]
===
match
---
operator: = [26745,26746]
operator: = [27131,27132]
===
match
---
simple_stmt [2857,2911]
simple_stmt [2857,2911]
===
match
---
trailer [8731,8738]
trailer [8731,8738]
===
match
---
operator: , [34267,34268]
operator: , [34653,34654]
===
match
---
name: run_type [22368,22376]
name: run_type [22368,22376]
===
match
---
operator: = [19044,19045]
operator: = [19044,19045]
===
match
---
name: self [12738,12742]
name: self [12738,12742]
===
match
---
name: daily_dag [30795,30804]
name: daily_dag [31181,31190]
===
match
---
string: "unit_test_dag failed." [5422,5445]
string: "unit_test_dag failed." [5422,5445]
===
match
---
atom_expr [18930,18991]
atom_expr [18930,18991]
===
match
---
name: create_dagrun [22226,22239]
name: create_dagrun [22226,22239]
===
match
---
argument [2585,2614]
argument [2585,2614]
===
match
---
string: "dag_2" [19642,19649]
string: "dag_2" [19642,19649]
===
match
---
name: task_id [33335,33342]
name: task_id [33721,33728]
===
match
---
string: "task_a_0" [25968,25978]
string: "task_a_0" [26354,26364]
===
match
---
suite [17187,18044]
suite [17187,18044]
===
match
---
name: self [7321,7325]
name: self [7321,7325]
===
match
---
name: timedelta [10559,10568]
name: timedelta [10559,10568]
===
match
---
atom_expr [33652,33662]
atom_expr [34038,34048]
===
match
---
name: external_task_ids [3061,3078]
name: external_task_ids [3061,3078]
===
match
---
operator: , [4257,4258]
operator: , [4257,4258]
===
match
---
operator: } [29117,29118]
operator: } [29503,29504]
===
match
---
simple_stmt [17234,17314]
simple_stmt [17234,17314]
===
match
---
name: get_dag [25145,25152]
name: get_dag [25531,25538]
===
match
---
atom_expr [19779,19791]
atom_expr [19779,19791]
===
match
---
argument [7618,7656]
argument [7618,7656]
===
match
---
name: raises [16461,16467]
name: raises [16461,16467]
===
match
---
trailer [29767,29775]
trailer [30153,30161]
===
match
---
name: end_date [23047,23055]
name: end_date [23433,23441]
===
match
---
arglist [13304,13372]
arglist [13304,13372]
===
match
---
name: task_b_0 [19056,19064]
name: task_b_0 [19056,19064]
===
match
---
arglist [27767,27823]
arglist [28153,28209]
===
match
---
string: "dag_0" [29776,29783]
string: "dag_0" [30162,30169]
===
match
---
operator: = [3035,3036]
operator: = [3035,3036]
===
match
---
operator: , [11160,11161]
operator: , [11160,11161]
===
match
---
arglist [19021,19050]
arglist [19021,19050]
===
match
---
name: DEFAULT_DATE [11222,11234]
name: DEFAULT_DATE [11222,11234]
===
match
---
simple_stmt [32341,32446]
simple_stmt [32727,32832]
===
match
---
name: dag [4014,4017]
name: dag [4014,4017]
===
match
---
trailer [8252,8375]
trailer [8252,8375]
===
match
---
fstring_start: f" [29049,29051]
fstring_start: f" [29435,29437]
===
match
---
number: 1 [9524,9525]
number: 1 [9524,9525]
===
match
---
trailer [5690,5980]
trailer [5690,5980]
===
match
---
atom_expr [2660,2736]
atom_expr [2660,2736]
===
match
---
trailer [16940,16955]
trailer [16940,16955]
===
match
---
name: session [34363,34370]
name: session [34749,34756]
===
match
---
argument [32067,32077]
argument [32453,32463]
===
match
---
trailer [12058,12060]
trailer [12058,12060]
===
match
---
trailer [14037,14054]
trailer [14037,14054]
===
match
---
operator: = [31002,31003]
operator: = [31388,31389]
===
match
---
operator: >> [20009,20011]
operator: >> [20009,20011]
===
match
---
suite [33960,35156]
suite [34346,35542]
===
match
---
simple_stmt [18996,19052]
simple_stmt [18996,19052]
===
match
---
operator: , [35095,35096]
operator: , [35481,35482]
===
match
---
argument [2692,2713]
argument [2692,2713]
===
match
---
funcdef [12771,12995]
funcdef [12771,12995]
===
match
---
parameters [14548,14554]
parameters [14548,14554]
===
match
---
name: task_b_0 [26820,26828]
name: task_b_0 [27206,27214]
===
match
---
name: merge [22652,22657]
name: merge [23038,23043]
===
match
---
simple_stmt [7506,7550]
simple_stmt [7506,7550]
===
match
---
name: AirflowSensorTimeout [11748,11768]
name: AirflowSensorTimeout [11748,11768]
===
match
---
operator: , [2614,2615]
operator: , [2614,2615]
===
match
---
name: dag_bag [20429,20436]
name: dag_bag [20429,20436]
===
match
---
trailer [22657,22661]
trailer [23043,23047]
===
match
---
operator: = [19976,19977]
operator: = [19976,19977]
===
match
---
name: dag_bag [31018,31025]
name: dag_bag [31404,31411]
===
match
---
name: session [25209,25216]
name: session [25595,25602]
===
match
---
atom_expr [4573,4845]
atom_expr [4573,4845]
===
match
---
strings [6515,6663]
strings [6515,6663]
===
match
---
operator: , [4437,4438]
operator: , [4437,4438]
===
match
---
argument [19565,19582]
argument [19565,19582]
===
match
---
name: DEFAULT_DATE [12510,12522]
name: DEFAULT_DATE [12510,12522]
===
match
---
name: DagRun [1017,1023]
name: DagRun [1017,1023]
===
match
---
fstring_start: f" [31269,31271]
fstring_start: f" [31655,31657]
===
match
---
name: TaskInstanceState [34523,34540]
name: TaskInstanceState [34909,34926]
===
match
---
atom_expr [27845,27861]
atom_expr [28231,28247]
===
match
---
atom_expr [34431,34454]
atom_expr [34817,34840]
===
match
---
operator: , [25002,25003]
operator: , [25388,25389]
===
match
---
simple_stmt [1073,1121]
simple_stmt [1073,1121]
===
match
---
operator: , [23712,23713]
operator: , [24098,24099]
===
match
---
atom_expr [26306,26354]
atom_expr [26692,26740]
===
match
---
string: "tail" [33616,33622]
string: "tail" [34002,34008]
===
match
---
operator: = [11502,11503]
operator: = [11502,11503]
===
match
---
argument [19432,19441]
argument [19432,19441]
===
match
---
atom_expr [17982,18026]
atom_expr [17982,18026]
===
match
---
name: dag_external_id [9274,9289]
name: dag_external_id [9274,9289]
===
match
---
string: """     Assert state of task_instances equals the given state.     """ [22786,22856]
string: """     Assert state of task_instances equals the given state.     """ [23172,23242]
===
match
---
arglist [11791,11859]
arglist [11791,11859]
===
match
---
atom_expr [8319,8339]
atom_expr [8319,8339]
===
match
---
operator: = [9099,9100]
operator: = [9099,9100]
===
match
---
number: 0 [13815,13816]
number: 0 [13815,13816]
===
match
---
string: "task_a_2" [30488,30498]
string: "task_a_2" [30874,30884]
===
match
---
operator: = [23287,23288]
operator: = [23673,23674]
===
match
---
argument [21166,21182]
argument [21166,21182]
===
match
---
atom_expr [23793,23834]
atom_expr [24179,24220]
===
match
---
name: dag [14482,14485]
name: dag [14482,14485]
===
match
---
argument [24205,24225]
argument [24591,24611]
===
match
---
trailer [4591,4845]
trailer [4591,4845]
===
match
---
atom_expr [31996,32014]
atom_expr [32382,32400]
===
match
---
number: 1 [9980,9981]
number: 1 [9980,9981]
===
match
---
name: root_dag [29446,29454]
name: root_dag [29832,29840]
===
match
---
operator: = [19713,19714]
operator: = [19713,19714]
===
match
---
name: execution_date [34238,34252]
name: execution_date [34624,34638]
===
match
---
name: agg_dag [31926,31933]
name: agg_dag [32312,32319]
===
match
---
name: task_b_1 [19452,19460]
name: task_b_1 [19452,19460]
===
match
---
argument [33466,33472]
argument [33852,33858]
===
match
---
name: test_time_sensor [10792,10808]
name: test_time_sensor [10792,10808]
===
match
---
name: ExternalTaskSensor [12199,12217]
name: ExternalTaskSensor [12199,12217]
===
match
---
string: 'start_date' [2066,2078]
string: 'start_date' [2066,2078]
===
match
---
name: dt [11554,11556]
name: dt [11554,11556]
===
match
---
name: poke_interval [11657,11670]
name: poke_interval [11657,11670]
===
match
---
name: SerializedBaseOperator [17752,17774]
name: SerializedBaseOperator [17752,17774]
===
match
---
argument [8270,8293]
argument [8270,8293]
===
match
---
atom_expr [14694,14975]
atom_expr [14694,14975]
===
match
---
atom_expr [5553,5596]
atom_expr [5553,5596]
===
match
---
trailer [25053,25069]
trailer [25439,25455]
===
match
---
name: external_task_id [21340,21356]
name: external_task_id [21340,21356]
===
match
---
arglist [20269,20298]
arglist [20269,20298]
===
match
---
string: "dag_0" [29251,29258]
string: "dag_0" [29637,29644]
===
match
---
name: session [35117,35124]
name: session [35503,35510]
===
match
---
return_stmt [29489,29504]
return_stmt [29875,29890]
===
match
---
operator: = [5783,5784]
operator: = [5783,5784]
===
match
---
operator: = [11577,11578]
operator: = [11577,11578]
===
match
---
name: run_tasks [32087,32096]
name: run_tasks [32473,32482]
===
match
---
simple_stmt [25837,25896]
simple_stmt [26223,26282]
===
match
---
name: execution_date [6915,6929]
name: execution_date [6915,6929]
===
match
---
string: 'success' [13240,13249]
string: 'success' [13240,13249]
===
match
---
name: NONE [23875,23879]
name: NONE [24261,24265]
===
match
---
operator: = [15281,15282]
operator: = [15281,15282]
===
match
---
name: DEFAULT_DATE [10698,10710]
name: DEFAULT_DATE [10698,10710]
===
match
---
operator: , [23426,23427]
operator: , [23812,23813]
===
match
---
argument [25179,25199]
argument [25565,25585]
===
match
---
funcdef [23461,23881]
funcdef [23847,24267]
===
match
---
argument [10625,10637]
argument [10625,10637]
===
match
---
name: allowed_states [4744,4758]
name: allowed_states [4744,4758]
===
match
---
trailer [9104,9109]
trailer [9104,9109]
===
match
---
name: datetime [1534,1542]
name: datetime [1534,1542]
===
match
---
name: dag_0 [19383,19388]
name: dag_0 [19383,19388]
===
match
---
atom_expr [24186,24226]
atom_expr [24572,24612]
===
match
---
funcdef [11866,12569]
funcdef [11866,12569]
===
match
---
operator: == [35144,35146]
operator: == [35530,35532]
===
match
---
name: ExternalTaskSensor [16212,16230]
name: ExternalTaskSensor [16212,16230]
===
match
---
name: dag_bag [32414,32421]
name: dag_bag [32800,32807]
===
match
---
atom [14453,14464]
atom [14453,14464]
===
match
---
name: self [10314,10318]
name: self [10314,10318]
===
match
---
name: dags [27739,27743]
name: dags [28125,28129]
===
match
---
operator: = [26895,26896]
operator: = [27281,27282]
===
match
---
trailer [22225,22239]
trailer [22225,22239]
===
match
---
operator: == [8904,8906]
operator: == [8904,8906]
===
match
---
simple_stmt [12831,12873]
simple_stmt [12831,12873]
===
match
---
import_name [802,817]
import_name [802,817]
===
match
---
simple_stmt [19604,19625]
simple_stmt [19604,19625]
===
match
---
name: AirflowException [3323,3339]
name: AirflowException [3323,3339]
===
match
---
for_stmt [31977,32146]
for_stmt [32363,32532]
===
match
---
name: dt [12144,12146]
name: dt [12144,12146]
===
match
---
operator: , [5013,5014]
operator: , [5013,5014]
===
match
---
trailer [28972,29134]
trailer [29358,29520]
===
match
---
fstring_end: " [29216,29217]
fstring_end: " [29602,29603]
===
match
---
argument [27706,27728]
argument [28092,28114]
===
match
---
expr_stmt [24926,25020]
expr_stmt [25312,25406]
===
match
---
operator: , [6942,6943]
operator: , [6942,6943]
===
match
---
tfpdef [27637,27647]
tfpdef [28023,28033]
===
match
---
operator: = [3639,3640]
operator: = [3639,3640]
===
match
---
simple_stmt [29696,29725]
simple_stmt [30082,30111]
===
match
---
operator: , [19930,19931]
operator: , [19930,19931]
===
match
---
fstring_expr [17114,17135]
fstring_expr [17114,17135]
===
match
---
atom_expr [30963,31013]
atom_expr [31349,31399]
===
match
---
simple_stmt [1543,1586]
simple_stmt [1543,1586]
===
match
---
atom_expr [29421,29459]
atom_expr [29807,29845]
===
match
---
trailer [4540,4557]
trailer [4540,4557]
===
match
---
operator: = [7221,7222]
operator: = [7221,7222]
===
match
---
atom_expr [24231,24271]
atom_expr [24617,24657]
===
match
---
operator: , [26394,26395]
operator: , [26780,26781]
===
match
---
atom [12434,12445]
atom [12434,12445]
===
match
---
name: test_time_sensor [13448,13464]
name: test_time_sensor [13448,13464]
===
match
---
name: Session [8161,8168]
name: Session [8161,8168]
===
match
---
name: DEFAULT_DATE [2311,2323]
name: DEFAULT_DATE [2311,2323]
===
match
---
parameters [32485,32487]
parameters [32871,32873]
===
match
---
return_stmt [12970,12994]
return_stmt [12970,12994]
===
match
---
operator: = [21709,21710]
operator: = [21709,21710]
===
match
---
argument [6125,6148]
argument [6125,6148]
===
match
---
string: "task_b_0" [19103,19113]
string: "task_b_0" [19103,19113]
===
match
---
assert_stmt [17884,17966]
assert_stmt [17884,17966]
===
match
---
trailer [16501,16505]
trailer [16501,16505]
===
match
---
operator: = [19435,19436]
operator: = [19435,19436]
===
match
---
name: end_date [10228,10236]
name: end_date [10228,10236]
===
match
---
funcdef [17319,18044]
funcdef [17319,18044]
===
match
---
name: DagBag [21058,21064]
name: DagBag [21058,21064]
===
match
---
atom_expr [28916,28932]
atom_expr [29302,29318]
===
match
---
param [25533,25544]
param [25919,25930]
===
match
---
import_from [871,911]
import_from [871,911]
===
match
---
string: "task_a_1" [19355,19365]
string: "task_a_1" [19355,19365]
===
match
---
name: dag [15317,15320]
name: dag [15317,15320]
===
match
---
trailer [31282,31290]
trailer [31668,31676]
===
match
---
name: tasks [34407,34412]
name: tasks [34793,34798]
===
match
---
funcdef [29507,29950]
funcdef [29893,30336]
===
match
---
name: dag_bag [30181,30188]
name: dag_bag [30567,30574]
===
match
---
operator: , [3431,3432]
operator: , [3431,3432]
===
match
---
operator: , [4338,4339]
operator: , [4338,4339]
===
match
---
name: isoformat [5234,5243]
name: isoformat [5234,5243]
===
match
---
name: dagrun_1_1 [25416,25426]
name: dagrun_1_1 [25802,25812]
===
match
---
operator: = [33192,33193]
operator: = [33578,33579]
===
match
---
arglist [6125,6193]
arglist [6125,6193]
===
match
---
trailer [21871,21894]
trailer [21871,21894]
===
match
---
operator: = [2018,2019]
operator: = [2018,2019]
===
match
---
trailer [7187,7257]
trailer [7187,7257]
===
match
---
name: execution_date [22286,22300]
name: execution_date [22286,22300]
===
match
---
name: DEFAULT_DATE [8042,8054]
name: DEFAULT_DATE [8042,8054]
===
match
---
name: dag_external_id [7506,7521]
name: dag_external_id [7506,7521]
===
match
---
parameters [14017,14023]
parameters [14017,14023]
===
match
---
name: ExternalTaskMarker [17270,17288]
name: ExternalTaskMarker [17270,17288]
===
match
---
expr_stmt [25942,25979]
expr_stmt [26328,26365]
===
match
---
try_stmt [8205,9031]
try_stmt [8205,9031]
===
match
---
return_stmt [23298,23458]
return_stmt [23684,23844]
===
match
---
operator: , [24756,24757]
operator: , [25142,25143]
===
match
---
name: dag_bag_cyclic [29997,30011]
name: dag_bag_cyclic [30383,30397]
===
match
---
operator: , [19674,19675]
operator: , [19674,19675]
===
match
---
name: session [24528,24535]
name: session [24914,24921]
===
match
---
name: dag [13273,13276]
name: dag [13273,13276]
===
match
---
operator: { [28179,28180]
operator: { [28565,28566]
===
match
---
name: flush [34561,34566]
name: flush [34947,34952]
===
match
---
simple_stmt [13004,13288]
simple_stmt [13004,13288]
===
match
---
operator: = [28227,28228]
operator: = [28613,28614]
===
match
---
operator: = [16932,16933]
operator: = [16932,16933]
===
match
---
expr_stmt [24140,24180]
expr_stmt [24526,24566]
===
match
---
operator: + [25749,25750]
operator: + [26135,26136]
===
match
---
operator: , [22698,22699]
operator: , [23084,23085]
===
match
---
simple_stmt [23647,23685]
simple_stmt [24033,24071]
===
match
---
funcdef [26410,26976]
funcdef [26796,27362]
===
match
---
name: dag_bag [23386,23393]
name: dag_bag [23772,23779]
===
match
---
name: DEFAULT_DATE [20058,20070]
name: DEFAULT_DATE [20058,20070]
===
match
---
expr_stmt [27874,27918]
expr_stmt [28260,28304]
===
match
---
name: dag [1058,1061]
name: dag [1058,1061]
===
match
---
name: partial [23201,23208]
name: partial [23587,23594]
===
match
---
name: clear_tasks [24688,24699]
name: clear_tasks [25074,25085]
===
match
---
expr_stmt [25222,25315]
expr_stmt [25608,25701]
===
match
---
atom_expr [24659,24683]
atom_expr [25045,25069]
===
match
---
name: i [31198,31199]
name: i [31584,31585]
===
match
---
trailer [1964,1971]
trailer [1964,1971]
===
match
---
name: dag [3645,3648]
name: dag [3645,3648]
===
match
---
atom_expr [9400,9420]
atom_expr [9400,9420]
===
match
---
name: clear_tasks [26934,26945]
name: clear_tasks [27320,27331]
===
match
---
fstring [29200,29217]
fstring [29586,29603]
===
match
---
name: DEFAULT_DATE [8304,8316]
name: DEFAULT_DATE [8304,8316]
===
match
---
atom_expr [23658,23684]
atom_expr [24044,24070]
===
match
---
trailer [8635,8642]
trailer [8635,8642]
===
match
---
name: DEFAULT_DATE [16068,16080]
name: DEFAULT_DATE [16068,16080]
===
match
---
simple_stmt [9595,10014]
simple_stmt [9595,10014]
===
match
---
funcdef [32464,33865]
funcdef [32850,34251]
===
match
---
atom_expr [24474,24536]
atom_expr [24860,24922]
===
match
---
name: clear [23313,23318]
name: clear [23699,23704]
===
match
---
operator: = [11641,11642]
operator: = [11641,11642]
===
match
---
operator: = [9128,9129]
operator: = [9128,9129]
===
match
---
atom_expr [23773,23788]
atom_expr [24159,24174]
===
match
---
name: dag_bag [33857,33864]
name: dag_bag [34243,34250]
===
match
---
name: get_task [24665,24673]
name: get_task [25051,25059]
===
match
---
trailer [2424,2441]
trailer [2424,2441]
===
match
---
trailer [10659,10663]
trailer [10659,10663]
===
match
---
name: clear_db_runs [20442,20455]
name: clear_db_runs [20442,20455]
===
match
---
name: timedelta [33456,33465]
name: timedelta [33842,33851]
===
match
---
name: timedelta [34109,34118]
name: timedelta [34495,34504]
===
match
---
name: external_task_id [12337,12353]
name: external_task_id [12337,12353]
===
match
---
atom_expr [9857,9865]
atom_expr [9857,9865]
===
match
---
name: dag [15967,15970]
name: dag [15967,15970]
===
match
---
fstring_string: task_a_ [28662,28669]
fstring_string: task_a_ [29048,29055]
===
match
---
trailer [23747,23759]
trailer [24133,24145]
===
match
---
name: execution_date [16887,16901]
name: execution_date [16887,16901]
===
match
---
name: get_dag [30210,30217]
name: get_dag [30596,30603]
===
match
---
name: MANUAL [22388,22394]
name: MANUAL [22388,22394]
===
match
---
simple_stmt [871,912]
simple_stmt [871,912]
===
match
---
operator: = [8182,8183]
operator: = [8182,8183]
===
match
---
expr_stmt [1669,1698]
expr_stmt [1669,1698]
===
match
---
fstring [34328,34343]
fstring [34714,34729]
===
match
---
testlist_comp [30549,30570]
testlist_comp [30935,30956]
===
match
---
operator: = [24264,24265]
operator: = [24650,24651]
===
match
---
string: "task_a_0" [27907,27917]
string: "task_a_0" [28293,28303]
===
match
---
name: bash_command_code [7772,7789]
name: bash_command_code [7772,7789]
===
match
---
atom_expr [22547,22562]
atom_expr [22933,22948]
===
match
---
name: self [2033,2037]
name: self [2033,2037]
===
match
---
argument [22368,22394]
argument [22368,22394]
===
match
---
argument [9365,9439]
argument [9365,9439]
===
match
---
number: 0 [9928,9929]
number: 0 [9928,9929]
===
match
---
operator: , [2128,2129]
operator: , [2128,2129]
===
match
---
string: 'test' [6882,6888]
string: 'test' [6882,6888]
===
match
---
name: ignore_ti_state [3218,3233]
name: ignore_ti_state [3218,3233]
===
match
---
name: external_dag_id [12296,12311]
name: external_dag_id [12296,12311]
===
match
---
suite [24452,24581]
suite [24838,24967]
===
match
---
operator: = [24996,24997]
operator: = [25382,25383]
===
match
---
operator: = [26181,26182]
operator: = [26567,26568]
===
match
---
string: """     Run all tasks in the DAGs in the given dag_bag. Return the TaskInstance objects as a dict     keyed by task_id.     """ [22025,22152]
string: """     Run all tasks in the DAGs in the given dag_bag. Return the TaskInstance objects as a dict     keyed by task_id.     """ [22025,22152]
===
match
---
argument [20269,20287]
argument [20269,20287]
===
match
---
simple_stmt [24465,24537]
simple_stmt [24851,24923]
===
match
---
param [1945,1949]
param [1945,1949]
===
match
---
name: schedule_interval [27801,27818]
name: schedule_interval [28187,28204]
===
match
---
name: execution_date_fn [11048,11065]
name: execution_date_fn [11048,11065]
===
match
---
operator: = [5053,5054]
operator: = [5053,5054]
===
match
---
string: "task_0" [21275,21283]
string: "task_0" [21275,21283]
===
match
---
name: task_a_0 [26966,26974]
name: task_a_0 [27352,27360]
===
match
---
name: task_without_failure [9159,9179]
name: task_without_failure [9159,9179]
===
match
---
operator: @ [20460,20461]
operator: @ [20460,20461]
===
match
---
name: task_type [17842,17851]
name: task_type [17842,17851]
===
match
---
simple_stmt [6472,6678]
simple_stmt [6472,6678]
===
match
---
string: '@once' [6821,6828]
string: '@once' [6821,6828]
===
match
---
argument [11108,11134]
argument [11108,11134]
===
match
---
argument [32414,32438]
argument [32800,32824]
===
match
---
trailer [7645,7656]
trailer [7645,7656]
===
match
---
name: allowed_states [11594,11608]
name: allowed_states [11594,11608]
===
match
---
name: dags [28916,28920]
name: dags [29302,29306]
===
match
---
with_item [27763,27831]
with_item [28149,28217]
===
match
---
with_stmt [16634,16818]
with_stmt [16634,16818]
===
match
---
name: task [22995,22999]
name: task [23381,23385]
===
match
---
trailer [26828,26844]
trailer [27214,27230]
===
match
---
name: test_time_sensor [12042,12058]
name: test_time_sensor [12042,12058]
===
match
---
name: n [28460,28461]
name: n [28846,28847]
===
match
---
simple_stmt [31138,31190]
simple_stmt [31524,31576]
===
match
---
string: "task_external_with_failure" [7729,7757]
string: "task_external_with_failure" [7729,7757]
===
match
---
operator: = [4675,4676]
operator: = [4675,4676]
===
match
---
trailer [24970,24981]
trailer [25356,25367]
===
match
---
trailer [7157,7161]
trailer [7157,7161]
===
match
---
name: raises [13564,13570]
name: raises [13564,13570]
===
match
---
param [23945,23966]
param [24331,24352]
===
match
---
operator: , [20070,20071]
operator: , [20070,20071]
===
match
---
name: execution_delta [33440,33455]
name: execution_delta [33826,33841]
===
match
---
name: start_date [10048,10058]
name: start_date [10048,10058]
===
match
---
name: get_dagrun [24478,24488]
name: get_dagrun [24864,24874]
===
match
---
string: "Maximum recursion depth 2" [26896,26923]
string: "Maximum recursion depth 2" [27282,27309]
===
match
---
string: "Some of the external tasks " [5328,5357]
string: "Some of the external tasks " [5328,5357]
===
match
---
expr_stmt [30231,30268]
expr_stmt [30617,30654]
===
match
---
operator: , [30765,30766]
operator: , [31151,31152]
===
match
---
name: recursion_depth [19169,19184]
name: recursion_depth [19169,19184]
===
match
---
argument [21501,21523]
argument [21501,21523]
===
match
---
name: pytest [31564,31570]
name: pytest [31950,31956]
===
match
---
operator: = [18928,18929]
operator: = [18928,18929]
===
match
---
name: TEST_DAG_ID [4676,4687]
name: TEST_DAG_ID [4676,4687]
===
match
---
name: SUCCESS [6956,6963]
name: SUCCESS [6956,6963]
===
match
---
operator: = [19922,19923]
operator: = [19922,19923]
===
match
---
atom_expr [7695,7828]
atom_expr [7695,7828]
===
match
---
name: ti [22696,22698]
name: ti [23082,23084]
===
match
---
atom [3556,3571]
atom [3556,3571]
===
match
---
atom_expr [25348,25360]
atom_expr [25734,25746]
===
match
---
operator: , [8339,8340]
operator: , [8339,8340]
===
match
---
trailer [16678,16817]
trailer [16678,16817]
===
match
---
name: head [33780,33784]
name: head [34166,34170]
===
match
---
name: task_id [2233,2240]
name: task_id [2233,2240]
===
match
---
number: 0 [8924,8925]
number: 0 [8924,8925]
===
match
---
argument [35070,35095]
argument [35456,35481]
===
match
---
expr_stmt [28945,29134]
expr_stmt [29331,29520]
===
match
---
operator: , [29065,29066]
operator: , [29451,29452]
===
match
---
name: TestCase [17177,17185]
name: TestCase [17177,17185]
===
match
---
trailer [29923,29949]
trailer [30309,30335]
===
match
---
argument [19041,19050]
argument [19041,19050]
===
match
---
atom_expr [7984,8132]
atom_expr [7984,8132]
===
match
---
arglist [20395,20416]
arglist [20395,20416]
===
match
---
operator: , [10950,10951]
operator: , [10950,10951]
===
match
---
argument [5809,5865]
argument [5809,5865]
===
match
---
argument [13264,13276]
argument [13264,13276]
===
match
---
operator: , [11515,11516]
operator: , [11515,11516]
===
match
---
argument [21184,21206]
argument [21184,21206]
===
match
---
expr_stmt [25025,25119]
expr_stmt [25411,25505]
===
match
---
name: self [14564,14568]
name: self [14564,14568]
===
match
---
trailer [4985,4989]
trailer [4985,4989]
===
match
---
suite [34068,34549]
suite [34454,34935]
===
match
---
trailer [4161,4375]
trailer [4161,4375]
===
match
---
operator: = [21582,21583]
operator: = [21582,21583]
===
match
---
name: external_task_id [19536,19552]
name: external_task_id [19536,19552]
===
match
---
operator: == [25389,25391]
operator: == [25775,25777]
===
match
---
string: "agg_dag" [31961,31970]
string: "agg_dag" [32347,32356]
===
match
---
name: raises [10139,10145]
name: raises [10139,10145]
===
match
---
argument [23235,23267]
argument [23621,23653]
===
match
---
operator: = [31419,31420]
operator: = [31805,31806]
===
match
---
operator: , [33174,33175]
operator: , [33560,33561]
===
match
---
operator: == [12848,12850]
operator: == [12848,12850]
===
match
---
operator: = [13804,13805]
operator: = [13804,13805]
===
match
---
atom_expr [26747,26773]
atom_expr [27133,27159]
===
match
---
name: filter [8636,8642]
name: filter [8636,8642]
===
match
---
simple_stmt [25321,25361]
simple_stmt [25707,25747]
===
match
---
operator: = [1991,1992]
operator: = [1991,1992]
===
match
---
operator: , [2346,2347]
operator: , [2346,2347]
===
match
---
trailer [12217,12482]
trailer [12217,12482]
===
match
---
name: dag_bag [30292,30299]
name: dag_bag [30678,30685]
===
insert-node
---
simple_stmt [22757,22837]
to
suite [22204,22715]
at 1
===
insert-node
---
expr_stmt [22757,22836]
to
simple_stmt [22757,22837]
at 0
===
insert-node
---
name: tasks [22855,22860]
to
for_stmt [22443,22715]
at 1
===
insert-node
---
atom_expr [22765,22836]
to
expr_stmt [22757,22836]
at 2
===
insert-node
---
trailer [22771,22836]
to
atom_expr [22765,22836]
at 1
===
insert-node
---
arglist [22772,22835]
to
trailer [22771,22836]
at 0
===
insert-node
---
atom [22772,22808]
to
arglist [22772,22835]
at 0
===
insert-node
---
testlist_comp [22773,22807]
to
atom [22772,22808]
at 0
===
insert-node
---
sync_comp_for [22776,22807]
to
testlist_comp [22773,22807]
at 1
===
move-tree
---
atom_expr [22453,22474]
    name: dagrun [22453,22459]
    trailer [22459,22474]
        name: task_instances [22460,22474]
to
sync_comp_for [22776,22807]
at 1
