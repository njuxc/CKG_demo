===
match
---
fstring_string: = [2771,2772]
fstring_string: = [2773,2774]
===
match
---
suite [3234,3266]
suite [3236,3268]
===
match
---
fstring_string:   [2834,2835]
fstring_string:   [2836,2837]
===
match
---
simple_stmt [2876,3196]
simple_stmt [2878,3198]
===
match
---
string: "Triggers must implement serialize()" [1605,1642]
string: "Triggers must implement serialize()" [1607,1644]
===
match
---
decorated [1649,2486]
decorated [1651,2488]
===
match
---
name: self [3214,3218]
name: self [3216,3220]
===
match
---
fstring_start: f" [3313,3315]
fstring_start: f" [3315,3317]
===
match
---
funcdef [3352,3491]
funcdef [3354,3493]
===
match
---
name: self [2503,2507]
name: self [2505,2509]
===
match
---
expr_stmt [2698,2734]
expr_stmt [2700,2736]
===
match
---
operator: { [2835,2836]
operator: { [2837,2838]
===
match
---
name: join [2761,2765]
name: join [2763,2767]
===
match
---
atom_expr [1377,1391]
atom_expr [1379,1393]
===
match
---
simple_stmt [1309,1314]
simple_stmt [1311,1316]
===
match
---
trailer [2452,2485]
trailer [2454,2487]
===
match
---
name: abstractmethod [1654,1668]
name: abstractmethod [1656,1670]
===
match
---
name: self [3284,3288]
name: self [3286,3290]
===
match
---
suite [2517,2658]
suite [2519,2660]
===
match
---
operator: } [2770,2771]
operator: } [2772,2773]
===
match
---
decorated [1319,1644]
decorated [1321,1646]
===
match
---
name: cleanup [2495,2502]
name: cleanup [2497,2504]
===
match
---
name: payload [3446,3453]
name: payload [3448,3455]
===
match
---
dotted_name [1650,1668]
dotted_name [1652,1670]
===
match
---
atom_expr [1696,1725]
atom_expr [1698,1727]
===
match
---
operator: , [3218,3219]
operator: , [3220,3221]
===
match
---
name: __eq__ [3356,3362]
name: __eq__ [3358,3364]
===
match
---
return_stmt [3306,3346]
return_stmt [3308,3348]
===
match
---
operator: -> [3290,3292]
operator: -> [3292,3294]
===
match
---
name: other [3399,3404]
name: other [3401,3406]
===
match
---
argument [2766,2803]
argument [2768,2805]
===
match
---
name: abc [1320,1323]
name: abc [1322,1325]
===
match
---
parameters [2502,2508]
parameters [2504,2510]
===
match
---
funcdef [3201,3266]
funcdef [3203,3268]
===
match
---
string: ", " [2756,2760]
string: ", " [2758,2762]
===
match
---
simple_stmt [3478,3491]
simple_stmt [3480,3493]
===
match
---
name: r [3342,3343]
name: r [3344,3345]
===
match
---
name: kwargs_str [2836,2846]
name: kwargs_str [2838,2848]
===
match
---
sync_comp_for [2777,2803]
sync_comp_for [2779,2805]
===
match
---
trailer [3333,3341]
trailer [3335,3343]
===
match
---
if_stmt [3385,3470]
if_stmt [3387,3472]
===
match
---
name: Any [816,819]
name: Any [816,819]
===
match
---
suite [877,2850]
suite [877,2852]
===
match
---
name: abstractmethod [1324,1338]
name: abstractmethod [1326,1340]
===
match
---
name: __init__ [3205,3213]
name: __init__ [3207,3215]
===
match
---
trailer [2801,2803]
trailer [2803,2805]
===
match
---
trailer [1371,1392]
trailer [1373,1394]
===
match
---
name: typing [802,808]
name: typing [802,808]
===
match
---
operator: @ [1319,1320]
operator: @ [1321,1322]
===
match
---
trailer [1604,1643]
trailer [1606,1645]
===
match
---
name: payload [3248,3255]
name: payload [3250,3257]
===
match
---
fstring_expr [3328,3344]
fstring_expr [3330,3346]
===
match
---
simple_stmt [3433,3470]
simple_stmt [3435,3472]
===
match
---
operator: , [3404,3405]
operator: , [3406,3407]
===
match
---
trailer [2722,2732]
trailer [2724,2734]
===
match
---
name: Tuple [1366,1371]
name: Tuple [1368,1373]
===
match
---
operator: { [2823,2824]
operator: { [2825,2826]
===
match
---
name: Tuple [842,847]
name: Tuple [842,847]
===
match
---
operator: } [2774,2775]
operator: } [2776,2777]
===
match
---
name: other [3369,3374]
name: other [3371,3376]
===
match
---
return_stmt [3478,3490]
return_stmt [3480,3492]
===
match
---
string: """         Runs the trigger in an asynchronous context.          The trigger should yield an Event whenever it wants to fire off         an event, and return None if it is finished. Single-event triggers         should thus yield and then immediately return.          If it yields, it is likely that it will be resumed very quickly,         but it may not be (e.g. if the workload is being moved to another         trigger process, or a multi-event trigger was being used for a         single-event task defer).          In either case, Trigger classes should assume they will be persisted,         and then rely on cleanup() being called when they are no longer needed.         """ [1735,2418]
string: """         Runs the trigger in an asynchronous context.          The trigger should yield an Event whenever it wants to fire off         an event, and return None if it is finished. Single-event triggers         should thus yield and then immediately return.          If it yields, it is likely that it will be resumed very quickly,         but it may not be (e.g. if the workload is being moved to another         trigger process, or a multi-event trigger was being used for a         single-event task defer).          In either case, Trigger classes should assume they will be persisted,         and then rely on cleanup() being called when they are no longer needed.         """ [1737,2420]
===
match
---
return_stmt [2813,2849]
return_stmt [2815,2851]
===
match
---
name: Any [3229,3232]
name: Any [3231,3234]
===
match
---
simple_stmt [3306,3347]
simple_stmt [3308,3349]
===
match
---
param [2503,2507]
param [2505,2509]
===
match
---
fstring [2766,2776]
fstring [2768,2778]
===
match
---
simple_stmt [2698,2735]
simple_stmt [2700,2737]
===
match
---
operator: = [2716,2717]
operator: = [2718,2719]
===
match
---
parameters [3362,3375]
parameters [3364,3377]
===
match
---
trailer [2732,2734]
trailer [2734,2736]
===
match
---
fstring_conversion [3341,3343]
fstring_conversion [3343,3345]
===
match
---
name: payload [3334,3341]
name: payload [3336,3343]
===
match
---
name: v [2773,2774]
name: v [2775,2776]
===
match
---
simple_stmt [2526,2658]
simple_stmt [2528,2660]
===
match
---
fstring_string: TriggerEvent< [3315,3328]
fstring_string: TriggerEvent< [3317,3330]
===
match
---
trailer [3247,3255]
trailer [3249,3257]
===
match
---
suite [1393,1644]
suite [1395,1646]
===
match
---
string: """     Base class for all triggers.      A trigger has two contexts it can exist in:       - Inside an Operator, when it's passed to TaskDeferred      - Actively running in a trigger worker      We use the same class for both situations, and rely on all Trigger classes     to be able to return the (Airflow-JSON-encodable) arguments that will     let them be reinsantiated elsewhere.     """ [882,1275]
string: """     Base class for all triggers.      A trigger has two contexts it can exist in:       - Inside an Operator, when it's passed to TaskDeferred      - Actively running in a trigger worker      We use the same class for both situations, and rely on all Trigger classes     to be able to return the (Airflow-JSON-encodable) arguments that will     let them be re-instantiated elsewhere.     """ [882,1277]
===
match
---
name: TriggerEvent [2858,2870]
name: TriggerEvent [2860,2872]
===
match
---
funcdef [2491,2658]
funcdef [2493,2660]
===
match
---
name: other [3440,3445]
name: other [3442,3447]
===
match
---
operator: , [3367,3368]
operator: , [3369,3370]
===
match
---
name: v [2784,2785]
name: v [2786,2787]
===
match
---
operator: } [2833,2834]
operator: } [2835,2836]
===
match
---
operator: , [840,841]
operator: , [840,841]
===
match
---
string: "Triggers must implement run()" [2453,2484]
string: "Triggers must implement run()" [2455,2486]
===
match
---
trailer [1709,1725]
trailer [1711,1727]
===
match
---
name: self [2718,2722]
name: self [2720,2724]
===
match
---
funcdef [1343,1644]
funcdef [1345,1646]
===
match
---
operator: , [1375,1376]
operator: , [1377,1378]
===
match
---
name: Dict [1377,1381]
name: Dict [1379,1383]
===
match
---
name: payload [3220,3227]
name: payload [3222,3229]
===
match
---
name: str [1382,1385]
name: str [1384,1387]
===
match
---
name: NotImplementedError [1585,1604]
name: NotImplementedError [1587,1606]
===
match
---
name: str [1372,1375]
name: str [1374,1377]
===
match
---
atom_expr [3388,3419]
atom_expr [3390,3421]
===
match
---
operator: { [2772,2773]
operator: { [2774,2775]
===
match
---
name: ABC [872,875]
name: ABC [872,875]
===
match
---
name: items [2796,2801]
name: items [2798,2803]
===
match
---
parameters [2675,2681]
parameters [2677,2683]
===
match
---
name: serialize [2723,2732]
name: serialize [2725,2734]
===
match
---
simple_stmt [2813,2850]
simple_stmt [2815,2852]
===
match
---
atom_expr [3457,3469]
atom_expr [3459,3471]
===
match
---
name: serialize [1347,1356]
name: serialize [1349,1358]
===
match
---
name: AsyncIterator [1696,1709]
name: AsyncIterator [1698,1711]
===
match
---
subscriptlist [1382,1390]
subscriptlist [1384,1392]
===
match
---
classdef [850,2850]
classdef [850,2852]
===
match
---
suite [3376,3491]
suite [3378,3493]
===
match
---
fstring_expr [2768,2771]
fstring_expr [2770,2773]
===
match
---
operator: = [3256,3257]
operator: = [3258,3259]
===
match
---
fstring_end: " [2848,2849]
fstring_end: " [2850,2851]
===
match
---
name: __repr__ [2667,2675]
name: __repr__ [2669,2677]
===
match
---
name: run [1683,1686]
name: run [1685,1688]
===
match
---
name: self [1357,1361]
name: self [1359,1363]
===
match
---
expr_stmt [3243,3265]
expr_stmt [3245,3267]
===
match
---
name: self [3457,3461]
name: self [3459,3463]
===
match
---
atom_expr [3243,3255]
atom_expr [3245,3257]
===
match
---
trailer [2760,2765]
trailer [2762,2767]
===
match
---
name: kwargs_str [2743,2753]
name: kwargs_str [2745,2755]
===
match
---
param [1294,1298]
param [1296,1300]
===
match
---
fstring_expr [2835,2847]
fstring_expr [2837,2849]
===
match
---
atom_expr [2756,2804]
atom_expr [2758,2806]
===
match
---
suite [3297,3347]
suite [3299,3349]
===
match
---
suite [1300,1314]
suite [1302,1316]
===
match
---
operator: -> [2509,2511]
operator: -> [2511,2513]
===
match
---
operator: -> [1693,1695]
operator: -> [1695,1697]
===
match
---
return_stmt [3433,3469]
return_stmt [3435,3471]
===
match
---
name: abc [868,871]
name: abc [868,871]
===
match
---
classdef [2852,3491]
classdef [2854,3493]
===
match
---
simple_stmt [2427,2486]
simple_stmt [2429,2488]
===
match
---
parameters [1356,1362]
parameters [1358,1364]
===
match
---
parameters [3213,3233]
parameters [3215,3235]
===
match
---
arglist [3399,3418]
arglist [3401,3420]
===
match
---
fstring_start: f" [2766,2768]
fstring_start: f" [2768,2770]
===
match
---
trailer [871,875]
trailer [871,875]
===
match
---
fstring [2820,2849]
fstring [2822,2851]
===
match
---
fstring_start: f" [2820,2822]
fstring_start: f" [2822,2824]
===
match
---
raise_stmt [2427,2485]
raise_stmt [2429,2487]
===
match
---
name: str [2685,2688]
name: str [2687,2690]
===
match
---
operator: } [2846,2847]
operator: } [2848,2849]
===
match
---
string: """         Called when the trigger is no longer needed and it's being removed         from the active trigger process.         """ [2526,2657]
string: """         Called when the trigger is no longer needed and it's being removed         from the active trigger process.         """ [2528,2659]
===
match
---
suite [3420,3470]
suite [3422,3472]
===
match
---
name: __init__ [1285,1293]
name: __init__ [1287,1295]
===
match
---
atom_expr [3440,3453]
atom_expr [3442,3455]
===
match
---
operator: { [2768,2769]
operator: { [2770,2771]
===
match
---
import_from [797,847]
import_from [797,847]
===
match
---
simple_stmt [882,1276]
simple_stmt [882,1278]
===
match
---
name: self [3243,3247]
name: self [3245,3249]
===
match
---
string: """     Something that a trigger can fire when its conditions are met.      Events must have a uniquely identifying value that would be the same     wherever the trigger is run; this is to ensure that if the same trigger     is being run in two locations (for HA reasons) that we can deduplicate its     events.     """ [2876,3195]
string: """     Something that a trigger can fire when its conditions are met.      Events must have a uniquely identifying value that would be the same     wherever the trigger is run; this is to ensure that if the same trigger     is being run in two locations (for HA reasons) that we can deduplicate its     events.     """ [2878,3197]
===
match
---
operator: ! [3341,3342]
operator: ! [3343,3344]
===
match
---
param [2676,2680]
param [2678,2682]
===
match
---
import_name [786,796]
import_name [786,796]
===
match
---
suite [2689,2850]
suite [2691,2852]
===
match
---
fstring_expr [2772,2775]
fstring_expr [2774,2777]
===
match
---
name: payload [3258,3265]
name: payload [3260,3267]
===
match
---
param [3220,3232]
param [3222,3234]
===
match
---
operator: -> [2682,2684]
operator: -> [2684,2686]
===
match
---
simple_stmt [1735,2419]
simple_stmt [1737,2421]
===
match
---
atom_expr [868,875]
atom_expr [868,875]
===
match
---
operator: } [3343,3344]
operator: } [3345,3346]
===
match
---
param [1687,1691]
param [1689,1693]
===
match
---
comparison [3440,3469]
comparison [3442,3471]
===
match
---
raise_stmt [1579,1643]
raise_stmt [1581,1645]
===
match
---
name: Any [1387,1390]
name: Any [1389,1392]
===
match
---
trailer [3445,3453]
trailer [3447,3455]
===
match
---
suite [1726,2486]
suite [1728,2488]
===
match
---
operator: , [819,820]
operator: , [819,820]
===
match
---
expr_stmt [2743,2804]
expr_stmt [2745,2806]
===
match
---
operator: , [1385,1386]
operator: , [1387,1388]
===
match
---
simple_stmt [786,797]
simple_stmt [786,797]
===
match
---
parameters [3283,3289]
parameters [3285,3291]
===
match
---
funcdef [1281,1314]
funcdef [1283,1316]
===
match
---
name: payload [3462,3469]
name: payload [3464,3471]
===
match
---
suite [2871,3491]
suite [2873,3493]
===
match
---
fstring [3313,3346]
fstring [3315,3348]
===
match
---
name: k [2769,2770]
name: k [2771,2772]
===
match
---
subscriptlist [1372,1391]
subscriptlist [1374,1393]
===
match
---
param [3214,3219]
param [3216,3221]
===
match
---
atom_expr [2789,2803]
atom_expr [2791,2805]
===
match
---
operator: { [3328,3329]
operator: { [3330,3331]
===
match
---
testlist_star_expr [2698,2715]
testlist_star_expr [2700,2717]
===
match
---
name: BaseTrigger [856,867]
name: BaseTrigger [856,867]
===
match
---
name: __repr__ [3275,3283]
name: __repr__ [3277,3285]
===
match
---
trailer [2795,2801]
trailer [2797,2803]
===
match
---
decorator [1319,1339]
decorator [1321,1341]
===
match
---
fstring_end: " [3345,3346]
fstring_end: " [3347,3348]
===
match
---
operator: -> [1363,1365]
operator: -> [1365,1367]
===
match
---
name: str [3293,3296]
name: str [3295,3298]
===
match
---
name: Dict [836,840]
name: Dict [836,840]
===
match
---
file_input [786,3491]
file_input [786,3493]
===
match
---
fstring_string: < [2822,2823]
fstring_string: < [2824,2825]
===
match
---
simple_stmt [797,848]
simple_stmt [797,848]
===
match
---
simple_stmt [1579,1644]
simple_stmt [1581,1646]
===
match
---
name: abc [1650,1653]
name: abc [1652,1655]
===
match
---
funcdef [2663,2850]
funcdef [2665,2852]
===
match
---
name: k [2781,2782]
name: k [2783,2784]
===
match
---
operator: , [2707,2708]
operator: , [2709,2710]
===
match
---
fstring_end: " [2775,2776]
fstring_end: " [2777,2778]
===
match
---
param [3369,3374]
param [3371,3376]
===
match
---
atom_expr [2718,2734]
atom_expr [2720,2736]
===
match
---
fstring_string: > [3344,3345]
fstring_string: > [3346,3347]
===
match
---
trailer [2765,2804]
trailer [2767,2806]
===
match
---
operator: , [834,835]
operator: , [834,835]
===
match
---
fstring_expr [2823,2834]
fstring_expr [2825,2836]
===
match
---
import_as_names [816,847]
import_as_names [816,847]
===
match
---
simple_stmt [1402,1571]
simple_stmt [1404,1573]
===
match
---
atom_expr [1585,1643]
atom_expr [1587,1645]
===
match
---
string: """         Returns the information needed to reconstruct this Trigger.          :return: Tuple of (class path, keyword arguments needed to re-instantiate).         """ [1402,1570]
string: """         Returns the information needed to reconstruct this Trigger.          :return: Tuple of (class path, keyword arguments needed to re-instantiate).         """ [1404,1572]
===
match
---
atom_expr [3329,3341]
atom_expr [3331,3343]
===
match
---
name: self [3363,3367]
name: self [3365,3369]
===
match
---
async_funcdef [1673,2486]
async_funcdef [1675,2488]
===
match
---
dotted_name [1320,1338]
dotted_name [1322,1340]
===
match
---
simple_stmt [2743,2805]
simple_stmt [2745,2807]
===
match
---
name: classpath [2824,2833]
name: classpath [2826,2835]
===
match
---
name: isinstance [3388,3398]
name: isinstance [3390,3400]
===
match
---
tfpdef [3220,3232]
tfpdef [3222,3234]
===
match
---
name: classpath [2698,2707]
name: classpath [2700,2709]
===
match
---
name: abc [793,796]
name: abc [793,796]
===
match
---
operator: == [3454,3456]
operator: == [3456,3458]
===
match
---
param [1357,1361]
param [1359,1363]
===
match
---
trailer [3398,3419]
trailer [3400,3421]
===
match
---
exprlist [2781,2785]
exprlist [2783,2787]
===
match
---
name: kwargs [2789,2795]
name: kwargs [2791,2797]
===
match
---
param [3363,3368]
param [3365,3370]
===
match
---
decorator [1649,1669]
decorator [1651,1671]
===
match
---
trailer [3461,3469]
trailer [3463,3471]
===
match
---
operator: @ [1649,1650]
operator: @ [1651,1652]
===
match
---
parameters [1293,1299]
parameters [1295,1301]
===
match
---
name: kwargs [2709,2715]
name: kwargs [2711,2717]
===
match
---
funcdef [1679,2486]
funcdef [1681,2488]
===
match
---
operator: = [2754,2755]
operator: = [2756,2757]
===
match
---
operator: , [2782,2783]
operator: , [2784,2785]
===
match
---
atom_expr [1366,1392]
atom_expr [1368,1394]
===
match
---
parameters [1686,1692]
parameters [1688,1694]
===
match
---
name: self [2676,2680]
name: self [2678,2682]
===
match
---
name: TriggerEvent [3406,3418]
name: TriggerEvent [3408,3420]
===
match
---
name: NotImplementedError [2433,2452]
name: NotImplementedError [2435,2454]
===
match
---
fstring_string: > [2847,2848]
fstring_string: > [2849,2850]
===
match
---
simple_stmt [3243,3266]
simple_stmt [3245,3268]
===
match
---
string: "TriggerEvent" [1710,1724]
string: "TriggerEvent" [1712,1726]
===
match
---
name: self [1687,1691]
name: self [1689,1693]
===
match
---
trailer [1381,1391]
trailer [1383,1393]
===
match
---
param [3284,3288]
param [3286,3290]
===
match
---
name: self [3329,3333]
name: self [3331,3335]
===
match
---
name: AsyncIterator [821,834]
name: AsyncIterator [821,834]
===
match
---
atom_expr [2433,2485]
atom_expr [2435,2487]
===
match
---
funcdef [3271,3347]
funcdef [3273,3349]
===
match
---
name: self [1294,1298]
name: self [1296,1300]
===
update-node
---
string: """     Base class for all triggers.      A trigger has two contexts it can exist in:       - Inside an Operator, when it's passed to TaskDeferred      - Actively running in a trigger worker      We use the same class for both situations, and rely on all Trigger classes     to be able to return the (Airflow-JSON-encodable) arguments that will     let them be reinsantiated elsewhere.     """ [882,1275]
replace """     Base class for all triggers.      A trigger has two contexts it can exist in:       - Inside an Operator, when it's passed to TaskDeferred      - Actively running in a trigger worker      We use the same class for both situations, and rely on all Trigger classes     to be able to return the (Airflow-JSON-encodable) arguments that will     let them be reinsantiated elsewhere.     """ by """     Base class for all triggers.      A trigger has two contexts it can exist in:       - Inside an Operator, when it's passed to TaskDeferred      - Actively running in a trigger worker      We use the same class for both situations, and rely on all Trigger classes     to be able to return the (Airflow-JSON-encodable) arguments that will     let them be re-instantiated elsewhere.     """
