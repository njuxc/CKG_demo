===
match
---
operator: = [1239,1240]
operator: = [1255,1256]
===
match
---
name: method_name [1941,1952]
name: method_name [2218,2229]
===
match
---
trailer [1194,1203]
trailer [1210,1219]
===
match
---
atom_expr [1187,1213]
atom_expr [1203,1229]
===
match
---
simple_stmt [788,840]
simple_stmt [804,856]
===
match
---
simple_stmt [1222,1253]
simple_stmt [1238,1269]
===
match
---
string: 'Checking if the time (%s) has come' [1305,1341]
string: 'Checking if the time (%s) has come' [1321,1357]
===
match
---
simple_stmt [1880,1973]
simple_stmt [2128,2260]
===
match
---
arglist [1396,1432]
arglist [1412,1448]
===
match
---
return_stmt [2143,2154]
return_stmt [2430,2441]
===
match
---
arglist [1891,1971]
arglist [2152,2249]
===
match
---
name: self [1880,1884]
name: self [2128,2132]
===
match
---
name: __init__ [1137,1145]
name: __init__ [1153,1161]
===
match
---
suite [2061,2155]
suite [2348,2442]
===
match
---
name: base [809,813]
name: base [825,829]
===
match
---
name: BaseSensorOperator [1484,1502]
name: BaseSensorOperator [1500,1518]
===
match
---
name: self [1291,1295]
name: self [1307,1311]
===
match
---
name: self [1732,1736]
name: self [1748,1752]
===
match
---
simple_stmt [1808,1839]
simple_stmt [1824,1855]
===
match
---
simple_stmt [2070,2135]
simple_stmt [2357,2422]
===
match
---
name: utils [907,912]
name: utils [923,928]
===
match
---
name: airflow [793,800]
name: airflow [809,816]
===
match
---
argument [1790,1798]
argument [1806,1814]
===
match
---
expr_stmt [1222,1252]
expr_stmt [1238,1268]
===
match
---
atom_expr [1396,1413]
atom_expr [1412,1429]
===
match
---
trailer [1304,1360]
trailer [1320,1376]
===
match
---
trailer [1295,1299]
trailer [1311,1315]
===
match
---
name: time [1434,1438]
name: time [1450,1454]
===
match
---
name: self [1808,1812]
name: self [1824,1828]
===
match
---
string: """Callback for when the trigger fires - returns immediately.""" [2070,2134]
string: """Callback for when the trigger fires - returns immediately.""" [2357,2421]
===
match
---
trailer [1203,1213]
trailer [1219,1229]
===
match
---
operator: , [2003,2004]
operator: , [2290,2291]
===
match
---
name: timezone [1376,1384]
name: timezone [1392,1400]
===
match
---
atom_expr [1880,1972]
atom_expr [2128,2259]
===
match
---
simple_stmt [1369,1460]
simple_stmt [1385,1476]
===
match
---
trailer [1419,1423]
trailer [1435,1439]
===
match
---
name: kwargs [1756,1762]
name: kwargs [1772,1778]
===
match
---
trailer [1812,1824]
trailer [1828,1840]
===
match
---
argument [1204,1212]
argument [1220,1228]
===
match
---
suite [968,1460]
suite [984,1476]
===
match
---
param [1754,1762]
param [1770,1778]
===
match
---
expr_stmt [1808,1838]
expr_stmt [1824,1854]
===
match
---
simple_stmt [1187,1214]
simple_stmt [1203,1230]
===
match
---
name: self [1267,1271]
name: self [1283,1287]
===
match
---
atom_expr [1343,1359]
atom_expr [1359,1375]
===
match
---
name: self [1443,1447]
name: self [1459,1463]
===
match
---
trailer [1438,1440]
trailer [1454,1456]
===
match
---
name: BaseSensorOperator [948,966]
name: BaseSensorOperator [964,982]
===
match
---
operator: = [1921,1922]
operator: = [2182,2183]
===
match
---
name: DateTimeTrigger [878,893]
name: DateTimeTrigger [894,909]
===
match
---
atom_expr [1415,1432]
atom_expr [1431,1448]
===
match
---
param [2005,2013]
param [2292,2300]
===
match
---
param [1862,1869]
param [2110,2117]
===
match
---
funcdef [1844,1973]
funcdef [2092,2260]
===
match
---
name: target_time [1227,1238]
name: target_time [1243,1254]
===
match
---
name: info [1300,1304]
name: info [1316,1320]
===
match
---
simple_stmt [2143,2155]
simple_stmt [2430,2442]
===
match
---
name: timezone [1396,1404]
name: timezone [1412,1420]
===
match
---
comparison [1376,1459]
comparison [1392,1475]
===
match
---
return_stmt [1369,1459]
return_stmt [1385,1475]
===
match
---
name: moment [1915,1921]
name: moment [2176,2182]
===
match
---
operator: , [1736,1737]
operator: , [1752,1753]
===
match
---
operator: , [1341,1342]
operator: , [1357,1358]
===
match
---
param [1267,1272]
param [1283,1288]
===
match
---
param [1155,1167]
param [1171,1183]
===
match
---
name: super [1187,1192]
name: super [1203,1208]
===
match
---
funcdef [1978,2155]
funcdef [2265,2442]
===
match
---
dotted_name [899,912]
dotted_name [915,928]
===
match
---
trailer [1411,1413]
trailer [1427,1429]
===
match
---
operator: , [1939,1940]
operator: , [2204,2205]
===
match
---
argument [1891,1939]
argument [2152,2204]
===
match
---
name: temporal [862,870]
name: temporal [878,886]
===
match
---
trailer [1884,1890]
trailer [2132,2138]
===
match
---
name: kwargs [1792,1798]
name: kwargs [1808,1814]
===
match
---
name: target_time [1813,1824]
name: target_time [1829,1840]
===
match
---
funcdef [1133,1253]
funcdef [1149,1269]
===
match
---
parameters [1145,1177]
parameters [1161,1193]
===
match
---
operator: = [1952,1953]
operator: = [2229,2230]
===
match
---
trailer [1226,1238]
trailer [1242,1254]
===
match
---
operator: , [1150,1151]
operator: , [1166,1167]
===
match
---
suite [1178,1253]
suite [1194,1269]
===
match
---
string: """     Waits until the specified time of the day.      :param target_time: time after which the job succeeds     :type target_time: datetime.time     """ [973,1127]
string: """     Waits until the specified time of the day.      :param target_time: time after which the job succeeds     :type target_time: datetime.time     """ [989,1143]
===
match
---
name: dag [1420,1423]
name: dag [1436,1439]
===
match
---
name: target_time [1741,1752]
name: target_time [1757,1768]
===
match
---
name: execute_complete [1982,1998]
name: execute_complete [2269,2285]
===
match
---
operator: = [1825,1826]
operator: = [1841,1842]
===
match
---
operator: ** [1790,1792]
operator: ** [1806,1808]
===
match
---
name: self [1146,1150]
name: self [1162,1166]
===
match
---
name: self [1415,1419]
name: self [1431,1435]
===
match
---
operator: , [1271,1272]
operator: , [1287,1288]
===
match
---
name: super [1773,1778]
name: super [1789,1794]
===
match
---
trailer [1926,1938]
trailer [2052,2064]
===
match
---
funcdef [1258,1460]
funcdef [1274,1476]
===
match
---
parameters [1998,2025]
parameters [2285,2312]
===
match
---
name: poke [1262,1266]
name: poke [1278,1282]
===
match
---
param [2014,2024]
param [2301,2311]
===
match
---
string: "execute_complete" [1953,1971]
string: "execute_complete" [2230,2248]
===
match
---
trailer [1299,1304]
trailer [1315,1320]
===
match
---
operator: = [2019,2020]
operator: = [2306,2307]
===
match
---
param [1732,1737]
param [1748,1753]
===
match
---
trailer [1789,1799]
trailer [1805,1815]
===
match
---
trailer [1447,1459]
trailer [1463,1475]
===
match
---
operator: , [1739,1740]
operator: , [1755,1756]
===
match
---
classdef [931,1460]
classdef [947,1476]
===
match
---
name: context [1862,1869]
name: context [2110,2117]
===
match
---
name: target_time [1827,1838]
name: target_time [1843,1854]
===
match
---
operator: ** [1204,1206]
operator: ** [1220,1222]
===
match
---
trailer [1433,1438]
trailer [1449,1454]
===
match
---
param [1741,1753]
param [1757,1769]
===
match
---
atom_expr [1899,1939]
atom_expr [2160,2204]
===
match
---
simple_stmt [1509,1714]
simple_stmt [1525,1730]
===
match
---
name: execute [1848,1855]
name: execute [2096,2103]
===
match
---
name: defer [1885,1890]
name: defer [2133,2138]
===
match
---
name: __init__ [1723,1731]
name: __init__ [1739,1747]
===
match
---
suite [1871,1973]
suite [2119,2260]
===
match
---
trailer [1890,1972]
trailer [2138,2259]
===
match
---
operator: * [1738,1739]
operator: * [1754,1755]
===
match
---
atom_expr [1443,1459]
atom_expr [1459,1475]
===
match
---
name: context [2005,2012]
name: context [2292,2299]
===
match
---
import_from [894,928]
import_from [910,944]
===
match
---
operator: , [1752,1753]
operator: , [1768,1769]
===
match
---
suite [1764,1839]
suite [1780,2087]
===
match
---
funcdef [1719,1839]
funcdef [1735,2087]
===
match
---
parameters [1266,1281]
parameters [1282,1297]
===
match
---
name: __init__ [1195,1203]
name: __init__ [1211,1219]
===
match
---
atom_expr [1376,1440]
atom_expr [1392,1456]
===
match
---
classdef [1462,2155]
classdef [1478,2442]
===
match
---
file_input [788,2155]
file_input [787,2442]
===
match
---
operator: = [1898,1899]
operator: = [2159,2160]
===
match
---
param [1273,1280]
param [1289,1296]
===
match
---
atom_expr [1222,1238]
atom_expr [1238,1254]
===
match
---
string: """     Waits until the specified time of the day, freeing up a worker slot while     it is waiting.      :param target_time: time after which the job succeeds     :type target_time: datetime.time     """ [1509,1713]
string: """     Waits until the specified time of the day, freeing up a worker slot while     it is waiting.      :param target_time: time after which the job succeeds     :type target_time: datetime.time     """ [1525,1729]
===
match
---
operator: , [1860,1861]
operator: , [2108,2109]
===
match
---
parameters [1731,1763]
parameters [1747,1779]
===
match
---
trailer [1384,1395]
trailer [1400,1411]
===
match
---
trailer [1780,1789]
trailer [1796,1805]
===
match
---
name: target_time [1448,1459]
name: target_time [1464,1475]
===
match
---
operator: ** [1168,1170]
operator: ** [1184,1186]
===
match
---
operator: , [1153,1154]
operator: , [1169,1170]
===
match
---
name: airflow [899,906]
name: airflow [915,922]
===
match
---
name: self [1856,1860]
name: self [2104,2108]
===
match
---
import_from [840,893]
import_from [856,909]
===
match
---
operator: * [1152,1153]
operator: * [1168,1169]
===
match
---
parameters [1855,1870]
parameters [2103,2118]
===
match
---
simple_stmt [1291,1361]
simple_stmt [1307,1377]
===
match
---
simple_stmt [894,929]
simple_stmt [910,945]
===
match
---
name: self [1999,2003]
name: self [2286,2290]
===
match
---
trailer [1192,1194]
trailer [1208,1210]
===
match
---
arglist [1305,1359]
arglist [1321,1375]
===
match
---
simple_stmt [973,1128]
simple_stmt [989,1144]
===
match
---
name: kwargs [1206,1212]
name: kwargs [1222,1228]
===
match
---
name: self [1343,1347]
name: self [1359,1363]
===
match
---
argument [1941,1971]
argument [2218,2248]
===
match
---
suite [1282,1460]
suite [1298,1476]
===
match
---
atom_expr [1922,1938]
atom_expr [2048,2064]
===
match
---
trailer [1395,1433]
trailer [1411,1449]
===
match
---
name: target_time [1927,1938]
name: target_time [2053,2064]
===
match
---
name: log [1296,1299]
name: log [1312,1315]
===
match
---
name: triggers [853,861]
name: triggers [869,877]
===
match
---
name: trigger [1891,1898]
name: trigger [2152,2159]
===
match
---
simple_stmt [840,894]
simple_stmt [856,910]
===
match
---
param [1168,1176]
param [1184,1192]
===
match
---
name: sensors [801,808]
name: sensors [817,824]
===
match
---
simple_stmt [1773,1800]
simple_stmt [1789,1816]
===
match
---
operator: , [1413,1414]
operator: , [1429,1430]
===
match
---
name: make_naive [1385,1395]
name: make_naive [1401,1411]
===
match
---
name: airflow [845,852]
name: airflow [861,868]
===
match
---
name: DateTimeTrigger [1899,1914]
name: DateTimeTrigger [2160,2175]
===
match
---
operator: ** [1754,1756]
operator: ** [1770,1772]
===
match
---
name: target_time [1155,1166]
name: target_time [1171,1182]
===
match
---
name: kwargs [1170,1176]
name: kwargs [1186,1192]
===
match
---
operator: , [1166,1167]
operator: , [1182,1183]
===
match
---
trailer [1347,1359]
trailer [1363,1375]
===
match
---
name: utcnow [1405,1411]
name: utcnow [1421,1427]
===
match
---
name: BaseSensorOperator [821,839]
name: BaseSensorOperator [837,855]
===
match
---
atom_expr [1808,1824]
atom_expr [1824,1840]
===
match
---
trailer [1914,1939]
trailer [2175,2204]
===
match
---
trailer [1423,1432]
trailer [1439,1448]
===
match
---
name: self [1222,1226]
name: self [1238,1242]
===
match
---
name: timezone [920,928]
name: timezone [936,944]
===
match
---
name: self [1922,1926]
name: self [2048,2052]
===
match
---
name: timezone [1424,1432]
name: timezone [1440,1448]
===
match
---
trailer [1404,1411]
trailer [1420,1427]
===
match
---
import_from [788,839]
import_from [804,855]
===
match
---
param [1999,2004]
param [2286,2291]
===
match
---
dotted_name [793,813]
dotted_name [809,829]
===
match
---
operator: , [2012,2013]
operator: , [2299,2300]
===
match
---
atom_expr [1773,1799]
atom_expr [1789,1815]
===
match
---
argument [1915,1938]
argument [2176,2203]
===
match
---
name: TimeSensor [937,947]
name: TimeSensor [953,963]
===
match
---
trailer [1778,1780]
trailer [1794,1796]
===
match
---
name: TimeSensorAsync [1468,1483]
name: TimeSensorAsync [1484,1499]
===
match
---
operator: > [1441,1442]
operator: > [1457,1458]
===
match
---
suite [1504,2155]
suite [1520,2442]
===
match
---
name: target_time [1241,1252]
name: target_time [1257,1268]
===
match
---
param [1856,1861]
param [2104,2109]
===
match
---
name: __init__ [1781,1789]
name: __init__ [1797,1805]
===
match
---
param [1146,1151]
param [1162,1167]
===
match
---
atom_expr [1291,1360]
atom_expr [1307,1376]
===
match
---
name: target_time [1348,1359]
name: target_time [1364,1375]
===
match
---
dotted_name [845,870]
dotted_name [861,886]
===
match
---
name: context [1273,1280]
name: context [1289,1296]
===
match
---
name: event [2014,2019]
name: event [2301,2306]
===
insert-tree
---
simple_stmt [787,803]
    import_name [787,802]
        name: datetime [794,802]
to
file_input [788,2155]
at 0
===
insert-tree
---
simple_stmt [1863,1936]
    expr_stmt [1863,1935]
        name: current_time [1863,1875]
        operator: = [1876,1877]
        atom_expr [1878,1935]
            name: timezone [1878,1886]
            trailer [1886,1897]
                name: make_naive [1887,1897]
            trailer [1897,1935]
                arglist [1898,1934]
                    atom_expr [1898,1915]
                        name: timezone [1898,1906]
                        trailer [1906,1913]
                            name: utcnow [1907,1913]
                        trailer [1913,1915]
                    operator: , [1915,1916]
                    atom_expr [1917,1934]
                        name: self [1917,1921]
                        trailer [1921,1925]
                            name: dag [1922,1925]
                        trailer [1925,1934]
                            name: timezone [1926,1934]
to
suite [1764,1839]
at 2
===
insert-tree
---
simple_stmt [1944,1978]
    expr_stmt [1944,1977]
        name: todays_date [1944,1955]
        operator: = [1956,1957]
        atom_expr [1958,1977]
            name: current_time [1958,1970]
            trailer [1970,1975]
                name: date [1971,1975]
            trailer [1975,1977]
to
suite [1764,1839]
at 3
===
insert-node
---
simple_stmt [1986,2087]
to
suite [1764,1839]
at 4
===
insert-node
---
expr_stmt [1986,2086]
to
simple_stmt [1986,2087]
at 0
===
insert-node
---
atom_expr [2009,2086]
to
expr_stmt [1986,2086]
at 2
===
insert-node
---
trailer [2034,2086]
to
atom_expr [2009,2086]
at 3
===
insert-node
---
arglist [2035,2085]
to
trailer [2034,2086]
at 0
===
insert-node
---
operator: , [2248,2249]
to
arglist [1891,1971]
at 3
===
move-tree
---
atom_expr [1922,1938]
    name: self [1922,1926]
    trailer [1926,1938]
        name: target_time [1927,1938]
to
arglist [2035,2085]
at 2
===
insert-tree
---
atom_expr [2183,2203]
    name: self [2183,2187]
    trailer [2187,2203]
        name: target_datetime [2188,2203]
to
argument [1915,1938]
at 2
