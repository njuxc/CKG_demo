===
match
---
name: run [70137,70140]
name: run [70640,70643]
===
match
---
atom_expr [12218,12231]
atom_expr [12218,12231]
===
match
---
comparison [35305,35350]
comparison [35808,35853]
===
match
---
atom_expr [12366,12376]
atom_expr [12366,12376]
===
match
---
name: typing [1177,1183]
name: typing [1177,1183]
===
match
---
trailer [12418,12434]
trailer [12418,12434]
===
match
---
name: state [32545,32550]
name: state [33048,33053]
===
match
---
operator: = [45583,45584]
operator: = [46086,46087]
===
match
---
name: self [11197,11201]
name: self [11197,11201]
===
match
---
operator: = [37522,37523]
operator: = [38025,38026]
===
match
---
name: Stats [78014,78019]
name: Stats [78517,78522]
===
match
---
name: ValueError [77623,77633]
name: ValueError [78126,78136]
===
match
---
trailer [60490,60503]
trailer [60993,61006]
===
match
---
name: callback_to_run [75531,75546]
name: callback_to_run [76034,76049]
===
match
---
trailer [79131,79143]
trailer [79634,79646]
===
match
---
trailer [62856,62865]
trailer [63359,63368]
===
match
---
name: warning [35610,35617]
name: warning [36113,36120]
===
match
---
arglist [81887,81965]
arglist [82390,82468]
===
match
---
atom_expr [72421,72502]
atom_expr [72924,73005]
===
match
---
name: dag_ids [7752,7759]
name: dag_ids [7752,7759]
===
match
---
operator: , [23692,23693]
operator: , [23692,23693]
===
match
---
name: import_errors [27073,27086]
name: import_errors [27073,27086]
===
match
---
suite [20616,21057]
suite [20616,21057]
===
match
---
arglist [52499,52543]
arglist [53002,53046]
===
match
---
atom_expr [53465,53482]
atom_expr [53968,53985]
===
match
---
operator: = [68623,68624]
operator: = [69126,69127]
===
match
---
trailer [30635,30658]
trailer [30889,30912]
===
match
---
name: task_instance_str [50556,50573]
name: task_instance_str [51059,51076]
===
match
---
dotted_name [2010,2037]
dotted_name [2010,2037]
===
match
---
operator: = [19873,19874]
operator: = [19873,19874]
===
match
---
operator: += [44592,44594]
operator: += [45095,45097]
===
match
---
simple_stmt [64445,64495]
simple_stmt [64948,64998]
===
match
---
string: "Lock held by another Scheduler" [60991,61023]
string: "Lock held by another Scheduler" [61494,61526]
===
match
---
trailer [76734,76751]
trailer [77237,77254]
===
match
---
name: task_concurrency_limit [43548,43570]
name: task_concurrency_limit [44051,44073]
===
match
---
name: orm [1450,1453]
name: orm [1450,1453]
===
match
---
name: DagRun [71266,71272]
name: DagRun [71769,71775]
===
match
---
atom_expr [43309,43355]
atom_expr [43812,43858]
===
match
---
name: synchronize_session [35491,35510]
name: synchronize_session [35994,36013]
===
match
---
trailer [27747,27779]
trailer [27747,27779]
===
match
---
name: info [53533,53537]
name: info [54036,54040]
===
match
---
name: self [50630,50634]
name: self [51133,51137]
===
match
---
name: Iterable [70597,70605]
name: Iterable [71100,71108]
===
match
---
name: self [19067,19071]
name: self [19067,19071]
===
match
---
number: 80 [31750,31752]
number: 80 [32253,32255]
===
match
---
name: dag [73088,73091]
name: dag [73591,73594]
===
match
---
param [50636,50659]
param [51139,51162]
===
match
---
operator: , [44499,44500]
operator: , [45002,45003]
===
match
---
simple_stmt [40389,40418]
simple_stmt [40892,40921]
===
match
---
expr_stmt [40899,40930]
expr_stmt [41402,41433]
===
match
---
name: state [45836,45841]
name: state [46339,46344]
===
match
---
name: outerjoin [38412,38421]
name: outerjoin [38915,38924]
===
match
---
name: current_thread [7562,7576]
name: current_thread [7562,7576]
===
match
---
operator: , [60504,60505]
operator: , [61007,61008]
===
match
---
comparison [16288,16313]
comparison [16288,16313]
===
match
---
name: error [52953,52958]
name: error [53456,53461]
===
match
---
name: len [26785,26788]
name: len [26785,26788]
===
match
---
name: signal [30885,30891]
name: signal [31139,31145]
===
match
---
atom_expr [72361,72382]
atom_expr [72864,72885]
===
match
---
suite [76135,76769]
suite [76638,77272]
===
match
---
string: "Exiting scheduler loop as requested DAG parse count (%d) has been reached after %d" [60013,60097]
string: "Exiting scheduler loop as requested DAG parse count (%d) has been reached after %d" [60516,60600]
===
match
---
name: DR [38479,38481]
name: DR [38982,38984]
===
match
---
name: filter [33652,33658]
name: filter [34155,34161]
===
match
---
name: all [18169,18172]
name: all [18169,18172]
===
match
---
name: blocking_task_list [18626,18644]
name: blocking_task_list [18626,18644]
===
match
---
simple_stmt [67270,67285]
simple_stmt [67773,67788]
===
match
---
operator: + [79926,79927]
operator: + [80429,80430]
===
match
---
name: dag_ids [56172,56179]
name: dag_ids [56675,56682]
===
match
---
name: in_ [64161,64164]
name: in_ [64664,64667]
===
match
---
atom_expr [65560,65589]
atom_expr [66063,66092]
===
match
---
expr_stmt [8835,9281]
expr_stmt [8835,9281]
===
match
---
expr_stmt [41359,41381]
expr_stmt [41862,41884]
===
match
---
name: outerjoin [33521,33530]
name: outerjoin [34024,34033]
===
match
---
trailer [38073,38077]
trailer [38576,38580]
===
match
---
name: timezone [69735,69743]
name: timezone [70238,70246]
===
match
---
atom_expr [63947,63963]
atom_expr [64450,64466]
===
match
---
simple_stmt [79230,79306]
simple_stmt [79733,79809]
===
match
---
trailer [16083,16102]
trailer [16083,16102]
===
match
---
name: _log [15363,15367]
name: _log [15363,15367]
===
match
---
name: TaskNotFound [1680,1692]
name: TaskNotFound [1680,1692]
===
match
---
atom_expr [17907,17930]
atom_expr [17907,17930]
===
match
---
simple_stmt [55469,55549]
simple_stmt [55972,56052]
===
match
---
trailer [17328,17334]
trailer [17328,17334]
===
match
---
name: log [78939,78942]
name: log [79442,79445]
===
match
---
suite [68538,70333]
suite [69041,70836]
===
match
---
atom_expr [31310,31330]
atom_expr [31687,31707]
===
match
---
atom_expr [46149,46157]
atom_expr [46652,46660]
===
match
---
name: dag [70257,70260]
name: dag [70760,70763]
===
match
---
expr_stmt [50407,50480]
expr_stmt [50910,50983]
===
match
---
suite [20883,21057]
suite [20883,21057]
===
match
---
operator: = [57325,57326]
operator: = [57828,57829]
===
match
---
name: executor [49754,49762]
name: executor [50257,50265]
===
match
---
name: slot_stats [78058,78068]
name: slot_stats [78561,78571]
===
match
---
name: execute_callbacks [75587,75604]
name: execute_callbacks [76090,76107]
===
match
---
string: "Error executing %s callback for file: %s" [23602,23644]
string: "Error executing %s callback for file: %s" [23602,23644]
===
match
---
simple_stmt [77901,77950]
simple_stmt [78404,78453]
===
match
---
string: 'clean_tis_without_dagrun_interval' [57879,57914]
string: 'clean_tis_without_dagrun_interval' [58382,58417]
===
match
---
trailer [58918,58928]
trailer [59421,59431]
===
match
---
name: event_scheduler [2537,2552]
name: event_scheduler [2537,2552]
===
match
---
trailer [53800,53821]
trailer [54303,54324]
===
match
---
arglist [20669,20733]
arglist [20669,20733]
===
match
---
name: num_times_parse_dags [60163,60183]
name: num_times_parse_dags [60666,60686]
===
match
---
trailer [35945,35950]
trailer [36448,36453]
===
match
---
atom_expr [81582,81592]
atom_expr [82085,82095]
===
match
---
name: self [23834,23838]
name: self [23834,23838]
===
match
---
name: paused_dag_ids [27442,27456]
name: paused_dag_ids [27442,27456]
===
match
---
name: session [27537,27544]
name: session [27537,27544]
===
match
---
name: str [50870,50873]
name: str [51373,51376]
===
match
---
trailer [59040,59056]
trailer [59543,59559]
===
match
---
name: dag_id [80979,80985]
name: dag_id [81482,81488]
===
match
---
tfpdef [67379,67395]
tfpdef [67882,67898]
===
match
---
name: max_active_runs [71988,72003]
name: max_active_runs [72491,72506]
===
match
---
name: dag [74325,74328]
name: dag [74828,74831]
===
match
---
name: self [8656,8660]
name: self [8656,8660]
===
match
---
name: self [12218,12222]
name: self [12218,12222]
===
match
---
operator: = [17077,17078]
operator: = [17077,17078]
===
match
---
simple_stmt [66608,66617]
simple_stmt [67111,67120]
===
match
---
name: prohibit_commit [60342,60357]
name: prohibit_commit [60845,60860]
===
match
---
name: executors [1706,1715]
name: executors [1706,1715]
===
match
---
name: query [38905,38910]
name: query [39408,39413]
===
match
---
atom [45832,45921]
atom [46335,46424]
===
match
---
trailer [26827,26832]
trailer [26827,26832]
===
match
---
name: TI [38422,38424]
name: TI [38925,38927]
===
match
---
decorator [23786,23803]
decorator [23786,23803]
===
match
---
string: "Executor reports execution of %s.%s execution_date=%s " [51360,51416]
string: "Executor reports execution of %s.%s execution_date=%s " [51863,51919]
===
match
---
operator: , [44374,44375]
operator: , [44877,44878]
===
match
---
import_from [1762,1803]
import_from [1762,1803]
===
match
---
name: timezone [79573,79581]
name: timezone [80076,80084]
===
match
---
atom_expr [35305,35332]
atom_expr [35808,35835]
===
match
---
trailer [71907,71922]
trailer [72410,72425]
===
match
---
simple_stmt [2178,2213]
simple_stmt [2178,2213]
===
match
---
trailer [51333,51337]
trailer [51836,51840]
===
match
---
name: task_list [19555,19564]
name: task_list [19555,19564]
===
match
---
trailer [38083,38106]
trailer [38586,38609]
===
match
---
name: heartbeat_callback [78310,78328]
name: heartbeat_callback [78813,78831]
===
match
---
simple_stmt [53008,53237]
simple_stmt [53511,53740]
===
match
---
operator: = [29223,29224]
operator: = [29477,29478]
===
match
---
name: str [40102,40105]
name: str [40605,40608]
===
match
---
simple_stmt [65469,65491]
simple_stmt [65972,65994]
===
match
---
name: utcnow [79582,79588]
name: utcnow [80085,80091]
===
match
---
atom_expr [16591,16604]
atom_expr [16591,16604]
===
match
---
simple_stmt [32857,33419]
simple_stmt [33360,33922]
===
match
---
fstring [6888,6939]
fstring [6888,6939]
===
match
---
trailer [4902,4929]
trailer [4902,4929]
===
match
---
name: ti [52535,52537]
name: ti [53038,53040]
===
match
---
atom_expr [49904,49912]
atom_expr [50407,50415]
===
match
---
strings [40974,41097]
strings [41477,41600]
===
match
---
name: create_dagrun [69580,69593]
name: create_dagrun [70083,70096]
===
match
---
atom_expr [42137,42164]
atom_expr [42640,42667]
===
match
---
if_stmt [57145,57238]
if_stmt [57648,57741]
===
match
---
trailer [30944,30983]
trailer [31198,31237]
===
match
---
funcdef [15221,15374]
funcdef [15221,15374]
===
match
---
name: task [24472,24476]
name: task [24472,24476]
===
match
---
decorated [25146,27840]
decorated [25146,27840]
===
match
---
trailer [10464,10466]
trailer [10464,10466]
===
match
---
name: self [30900,30904]
name: self [31154,31158]
===
match
---
name: num_unhandled [41722,41735]
name: num_unhandled [42225,42238]
===
match
---
atom_expr [15895,15904]
atom_expr [15895,15904]
===
match
---
fstring_string: pool.running_slots. [78204,78223]
fstring_string: pool.running_slots. [78707,78726]
===
match
---
annassign [4635,4671]
annassign [4635,4671]
===
match
---
name: log [73965,73968]
name: log [74468,74471]
===
match
---
atom_expr [39538,39545]
atom_expr [40041,40048]
===
match
---
number: 0 [40416,40417]
number: 0 [40919,40920]
===
match
---
argument [7906,7929]
argument [7906,7929]
===
match
---
name: DagRun [71349,71355]
name: DagRun [71852,71858]
===
match
---
operator: = [47041,47042]
operator: = [47544,47545]
===
match
---
trailer [59146,59150]
trailer [59649,59653]
===
match
---
atom_expr [4164,4177]
atom_expr [4164,4177]
===
match
---
operator: = [13509,13510]
operator: = [13509,13510]
===
match
---
atom_expr [74989,75011]
atom_expr [75492,75514]
===
match
---
atom_expr [45493,45512]
atom_expr [45996,46015]
===
match
---
expr_stmt [16029,16437]
expr_stmt [16029,16437]
===
match
---
name: self [4796,4800]
name: self [4796,4800]
===
match
---
return_stmt [26761,26772]
return_stmt [26761,26772]
===
match
---
name: priority [47271,47279]
name: priority [47774,47782]
===
match
---
param [24212,24217]
param [24212,24217]
===
match
---
param [66964,66971]
param [67467,67474]
===
match
---
comparison [10323,10351]
comparison [10323,10351]
===
match
---
trailer [55097,55117]
trailer [55600,55620]
===
match
---
trailer [56011,56034]
trailer [56514,56537]
===
match
---
trailer [55832,55834]
trailer [56335,56337]
===
match
---
trailer [50180,50280]
trailer [50683,50783]
===
match
---
name: end [31365,31368]
name: end [31742,31745]
===
match
---
name: get_latest_version_hash [76274,76297]
name: get_latest_version_hash [76777,76800]
===
match
---
simple_stmt [60842,60857]
simple_stmt [61345,61360]
===
match
---
simple_stmt [53358,53378]
simple_stmt [53861,53881]
===
match
---
name: pool_to_task_instances [40621,40643]
name: pool_to_task_instances [41124,41146]
===
match
---
simple_stmt [19450,19763]
simple_stmt [19450,19763]
===
match
---
trailer [11145,11161]
trailer [11145,11161]
===
match
---
atom_expr [42205,42240]
atom_expr [42708,42743]
===
match
---
trailer [11026,11035]
trailer [11026,11035]
===
match
---
number: 0 [73282,73283]
number: 0 [73785,73786]
===
match
---
name: self [54584,54588]
name: self [55087,55091]
===
match
---
name: num_starving_tasks_total [45146,45170]
name: num_starving_tasks_total [45649,45673]
===
match
---
fstring_end: " [9148,9149]
fstring_end: " [9148,9149]
===
match
---
operator: = [29638,29639]
operator: = [29892,29893]
===
match
---
name: slas [18608,18612]
name: slas [18608,18612]
===
match
---
operator: , [46131,46132]
operator: , [46634,46635]
===
match
---
operator: , [15420,15421]
operator: , [15420,15421]
===
match
---
name: _schedule_dag_run [65096,65113]
name: _schedule_dag_run [65599,65616]
===
match
---
name: make_transient [1478,1492]
name: make_transient [1478,1492]
===
match
---
name: task_concurrency_map [40057,40077]
name: task_concurrency_map [40560,40580]
===
match
---
name: self [67341,67345]
name: self [67844,67848]
===
match
---
trailer [22363,22365]
trailer [22363,22365]
===
match
---
name: session [76314,76321]
name: session [76817,76824]
===
match
---
name: execution_date [35417,35431]
name: execution_date [35920,35934]
===
match
---
suite [24949,25141]
suite [24949,25141]
===
match
---
operator: , [71666,71667]
operator: , [72169,72170]
===
match
---
simple_stmt [60410,60564]
simple_stmt [60913,61067]
===
match
---
name: Stats [45106,45111]
name: Stats [45609,45614]
===
match
---
atom_expr [71191,71204]
atom_expr [71694,71707]
===
match
---
expr_stmt [37497,37526]
expr_stmt [38000,38029]
===
match
---
operator: , [67177,67178]
operator: , [67680,67681]
===
match
---
with_item [62841,62874]
with_item [63344,63377]
===
match
---
atom [50902,50904]
atom [51405,51407]
===
match
---
atom_expr [9735,9755]
atom_expr [9735,9755]
===
match
---
name: dagbag [27308,27314]
name: dagbag [27308,27314]
===
match
---
name: airflow [2667,2674]
name: airflow [2667,2674]
===
match
---
name: Stats [81794,81799]
name: Stats [82297,82302]
===
match
---
name: task_id [43473,43480]
name: task_id [43976,43983]
===
match
---
atom [68389,68500]
atom [68892,69003]
===
match
---
name: query [16489,16494]
name: query [16489,16494]
===
match
---
operator: , [68309,68310]
operator: , [68812,68813]
===
match
---
simple_stmt [53524,53564]
simple_stmt [54027,54067]
===
match
---
trailer [49829,49836]
trailer [50332,50339]
===
match
---
trailer [39537,39581]
trailer [40040,40084]
===
match
---
operator: , [7759,7760]
operator: , [7759,7760]
===
match
---
simple_stmt [68790,68799]
simple_stmt [69293,69302]
===
match
---
name: _execute [53492,53500]
name: _execute [53995,54003]
===
match
---
suite [57173,57238]
suite [57676,57741]
===
match
---
operator: * [67941,67942]
operator: * [68444,68445]
===
match
---
trailer [55244,55254]
trailer [55747,55757]
===
match
---
string: "Processor agent is not started." [57203,57236]
string: "Processor agent is not started." [57706,57739]
===
match
---
name: filter [73641,73647]
name: filter [74144,74150]
===
match
---
atom_expr [64250,64270]
atom_expr [64753,64773]
===
match
---
name: ti [47217,47219]
name: ti [47720,47722]
===
match
---
string: "Failed at reloading the DAG file %s" [26644,26681]
string: "Failed at reloading the DAG file %s" [26644,26681]
===
match
---
operator: = [32448,32449]
operator: = [32951,32952]
===
match
---
trailer [65573,65589]
trailer [66076,66092]
===
match
---
funcdef [77830,78280]
funcdef [78333,78783]
===
match
---
name: dagbag [26789,26795]
name: dagbag [26789,26795]
===
match
---
name: ti [53331,53333]
name: ti [53834,53836]
===
match
---
parameters [11196,11202]
parameters [11196,11202]
===
match
---
string: "DAG '%s' not found in serialized_dag table" [65267,65311]
string: "DAG '%s' not found in serialized_dag table" [65770,65814]
===
match
---
expr_stmt [34473,34489]
expr_stmt [34976,34992]
===
match
---
trailer [55917,55921]
trailer [56420,56424]
===
match
---
operator: , [54523,54524]
operator: , [55026,55027]
===
match
---
if_stmt [77334,77381]
if_stmt [77837,77884]
===
match
---
name: filter [16250,16256]
name: filter [16250,16256]
===
match
---
trailer [24671,24682]
trailer [24671,24682]
===
match
---
import_as_names [2263,2352]
import_as_names [2263,2352]
===
match
---
name: dag [69496,69499]
name: dag [69999,70002]
===
match
---
trailer [60763,60768]
trailer [61266,61271]
===
match
---
expr_stmt [52131,52192]
expr_stmt [52634,52695]
===
match
---
name: DagModel [74163,74171]
name: DagModel [74666,74674]
===
match
---
string: 'SCHEDULER_HEARTBEAT_SEC' [29312,29337]
string: 'SCHEDULER_HEARTBEAT_SEC' [29566,29591]
===
match
---
name: info [31239,31243]
name: info [31616,31620]
===
match
---
name: session [60358,60365]
name: session [60861,60868]
===
match
---
operator: , [23464,23465]
operator: , [23464,23465]
===
match
---
name: SlaCallbackRequest [2308,2326]
name: SlaCallbackRequest [2308,2326]
===
match
---
name: info [39599,39603]
name: info [40102,40106]
===
match
---
name: file_path [56381,56390]
name: file_path [56884,56893]
===
match
---
name: timedelta [77420,77429]
name: timedelta [77923,77932]
===
match
---
number: 0 [38792,38793]
number: 0 [39295,39296]
===
match
---
atom_expr [16835,16866]
atom_expr [16835,16866]
===
match
---
param [47380,47396]
param [47883,47899]
===
match
---
trailer [39752,39757]
trailer [40255,40260]
===
match
---
name: label [16103,16108]
name: label [16103,16108]
===
match
---
simple_stmt [34416,34457]
simple_stmt [34919,34960]
===
match
---
name: state [38615,38620]
name: state [39118,39123]
===
match
---
atom_expr [70137,70151]
atom_expr [70640,70654]
===
match
---
trailer [3133,3142]
trailer [3133,3142]
===
match
---
operator: , [31020,31021]
operator: , [31274,31275]
===
match
---
name: _child_channel [9573,9587]
name: _child_channel [9573,9587]
===
match
---
decorator [66896,66918]
decorator [67399,67421]
===
match
---
trailer [50995,51012]
trailer [51498,51515]
===
match
---
name: self [68691,68695]
name: self [69194,69198]
===
match
---
simple_stmt [75072,75320]
simple_stmt [75575,75823]
===
match
---
argument [69896,69913]
argument [70399,70416]
===
match
---
name: pickle_dags [54465,54476]
name: pickle_dags [54968,54979]
===
match
---
string: "open" [78069,78075]
string: "open" [78572,78578]
===
match
---
name: self [48593,48597]
name: self [49096,49100]
===
match
---
name: dagbag [33621,33627]
name: dagbag [34124,34130]
===
match
---
name: State [80892,80897]
name: State [81395,81400]
===
match
---
operator: = [19793,19794]
operator: = [19793,19794]
===
match
---
if_stmt [32244,32402]
if_stmt [32747,32905]
===
match
---
name: to_reset [81331,81339]
name: to_reset [81834,81842]
===
match
---
name: test_mode [25021,25030]
name: test_mode [25021,25030]
===
match
---
suite [17300,17463]
suite [17300,17463]
===
match
---
atom [79572,79620]
atom [80075,80123]
===
match
---
arglist [55170,55256]
arglist [55673,55759]
===
match
---
simple_stmt [76390,76487]
simple_stmt [76893,76990]
===
match
---
operator: , [50243,50244]
operator: , [50746,50747]
===
match
---
name: subdir [29745,29751]
name: subdir [29999,30005]
===
match
---
arglist [81221,81282]
arglist [81724,81785]
===
match
---
trailer [82104,82108]
trailer [82607,82611]
===
match
---
name: _exit_gracefully [30966,30982]
name: _exit_gracefully [31220,31236]
===
match
---
argument [53115,53158]
argument [53618,53661]
===
match
---
trailer [55139,55143]
trailer [55642,55646]
===
match
---
number: 1 [44925,44926]
number: 1 [45428,45429]
===
match
---
operator: , [26501,26502]
operator: , [26501,26502]
===
match
---
operator: , [1476,1477]
operator: , [1476,1477]
===
match
---
atom_expr [68578,68632]
atom_expr [69081,69135]
===
match
---
trailer [31653,31661]
trailer [32156,32164]
===
match
---
atom_expr [7069,7150]
atom_expr [7069,7150]
===
match
---
trailer [52613,52624]
trailer [53116,53127]
===
match
---
name: dags [26796,26800]
name: dags [26796,26800]
===
match
---
name: process [8835,8842]
name: process [8835,8842]
===
match
---
simple_stmt [78812,78883]
simple_stmt [79315,79386]
===
match
---
name: dag_id [71660,71666]
name: dag_id [72163,72169]
===
match
---
dotted_name [1613,1631]
dotted_name [1613,1631]
===
match
---
name: task_instance [44808,44821]
name: task_instance [45311,45324]
===
match
---
testlist [27796,27839]
testlist [27796,27839]
===
match
---
atom_expr [5059,5074]
atom_expr [5059,5074]
===
match
---
name: RUNNING [79503,79510]
name: RUNNING [80006,80013]
===
match
---
name: blocking_task_list [19189,19207]
name: blocking_task_list [19189,19207]
===
match
---
argument [49841,49868]
argument [50344,50371]
===
match
---
simple_stmt [8517,8540]
simple_stmt [8517,8540]
===
match
---
name: update_import_errors [21385,21405]
name: update_import_errors [21385,21405]
===
match
---
name: update [35468,35474]
name: update [35971,35977]
===
match
---
name: state [3015,3020]
name: state [3015,3020]
===
match
---
import_as_names [1191,1246]
import_as_names [1191,1246]
===
match
---
name: sql [1509,1512]
name: sql [1509,1512]
===
match
---
expr_stmt [44839,44877]
expr_stmt [45342,45380]
===
match
---
name: info [31807,31811]
name: info [32310,32314]
===
match
---
atom_expr [24285,24313]
atom_expr [24285,24313]
===
match
---
name: Optional [4894,4902]
name: Optional [4894,4902]
===
match
---
trailer [39745,39758]
trailer [40248,40261]
===
match
---
operator: = [24099,24100]
operator: = [24099,24100]
===
match
---
atom_expr [58056,58069]
atom_expr [58559,58572]
===
match
---
name: _clean_tis_without_dagrun [57949,57974]
name: _clean_tis_without_dagrun [58452,58477]
===
match
---
atom_expr [64038,64047]
atom_expr [64541,64550]
===
match
---
not_test [15847,15905]
not_test [15847,15905]
===
match
---
number: 0 [65593,65594]
number: 0 [66096,66097]
===
match
---
name: ti [52218,52220]
name: ti [52721,52723]
===
match
---
trailer [82113,82314]
trailer [82616,82817]
===
match
---
simple_stmt [55808,55835]
simple_stmt [56311,56338]
===
match
---
trailer [35467,35474]
trailer [35970,35977]
===
match
---
operator: , [74465,74466]
operator: , [74968,74969]
===
match
---
simple_stmt [20213,20243]
simple_stmt [20213,20243]
===
match
---
name: _child_channel [8948,8962]
name: _child_channel [8948,8962]
===
match
---
atom_expr [27352,27361]
atom_expr [27352,27361]
===
match
---
parameters [53500,53506]
parameters [54003,54009]
===
match
---
operator: = [42135,42136]
operator: = [42638,42639]
===
match
---
atom_expr [12243,12263]
atom_expr [12243,12263]
===
match
---
name: rollback [66577,66585]
name: rollback [67080,67088]
===
match
---
operator: , [41174,41175]
operator: , [41677,41678]
===
match
---
simple_stmt [27052,27088]
simple_stmt [27052,27088]
===
match
---
number: 1 [26746,26747]
number: 1 [26746,26747]
===
match
---
name: dag_models [70585,70595]
name: dag_models [71088,71098]
===
match
---
name: SCHEDULED [79996,80005]
name: SCHEDULED [80499,80508]
===
match
---
name: log [8062,8065]
name: log [8062,8065]
===
match
---
name: get [74173,74176]
name: get [74676,74679]
===
match
---
return_stmt [82634,82654]
return_stmt [83137,83157]
===
match
---
simple_stmt [51329,51650]
simple_stmt [51832,52153]
===
match
---
atom_expr [27526,27545]
atom_expr [27526,27545]
===
match
---
atom_expr [26864,26882]
atom_expr [26864,26882]
===
match
---
atom_expr [4327,4372]
atom_expr [4327,4372]
===
match
---
annassign [20262,20280]
annassign [20262,20280]
===
match
---
atom_expr [38069,38106]
atom_expr [38572,38609]
===
match
---
trailer [73409,73416]
trailer [73912,73919]
===
match
---
param [78329,78334]
param [78832,78837]
===
match
---
name: SchedulerJob [80592,80604]
name: SchedulerJob [81095,81107]
===
match
---
name: INFO [7061,7065]
name: INFO [7061,7065]
===
match
---
name: callback_to_run [75668,75683]
name: callback_to_run [76171,76186]
===
match
---
name: task_instances [40603,40617]
name: task_instances [41106,41120]
===
match
---
subscriptlist [40097,40105]
subscriptlist [40600,40608]
===
match
---
name: duration [8123,8131]
name: duration [8123,8131]
===
match
---
return_stmt [53458,53482]
return_stmt [53961,53985]
===
match
---
name: seconds [79603,79610]
name: seconds [80106,80113]
===
match
---
name: self [30961,30965]
name: self [31215,31219]
===
match
---
string: """         Reset any TaskInstance still in QUEUED or SCHEDULED states that were         enqueued by a SchedulerJob that is no longer running.          :return: the number of TIs reset         :rtype: int         """ [78517,78733]
string: """         Reset any TaskInstance still in QUEUED or SCHEDULED states that were         enqueued by a SchedulerJob that is no longer running.          :return: the number of TIs reset         :rtype: int         """ [79020,79236]
===
match
---
operator: , [30898,30899]
operator: , [31152,31153]
===
match
---
name: dag_id [75202,75208]
name: dag_id [75705,75711]
===
match
---
suite [22588,23781]
suite [22588,23781]
===
match
---
trailer [60521,60528]
trailer [61024,61031]
===
match
---
name: c [35415,35416]
name: c [35918,35919]
===
match
---
trailer [52075,52088]
trailer [52578,52591]
===
match
---
operator: = [4494,4495]
operator: = [4494,4495]
===
match
---
simple_stmt [52485,52545]
simple_stmt [52988,53048]
===
match
---
atom_expr [74949,74968]
atom_expr [75452,75471]
===
match
---
name: TI [80976,80978]
name: TI [81479,81481]
===
match
---
name: pool [46862,46866]
name: pool [47365,47369]
===
match
---
atom_expr [60670,60685]
atom_expr [61173,61188]
===
match
---
exprlist [51058,51071]
exprlist [51561,51574]
===
match
---
operator: , [23255,23256]
operator: , [23255,23256]
===
match
---
operator: = [25299,25300]
operator: = [25299,25300]
===
match
---
trailer [17275,17279]
trailer [17275,17279]
===
match
---
atom_expr [82227,82240]
atom_expr [82730,82743]
===
match
---
expr_stmt [18942,18967]
expr_stmt [18942,18967]
===
match
---
name: len [81952,81955]
name: len [82455,82458]
===
match
---
suite [82000,82315]
suite [82503,82818]
===
match
---
trailer [71272,71289]
trailer [71775,71792]
===
match
---
name: session [18491,18498]
name: session [18491,18498]
===
match
---
suite [55698,55775]
suite [56201,56278]
===
match
---
operator: , [78333,78334]
operator: , [78836,78837]
===
match
---
suite [60898,61112]
suite [61401,61615]
===
match
---
name: Session [50645,50652]
name: Session [51148,51155]
===
match
---
trailer [15331,15339]
trailer [15331,15339]
===
match
---
name: Session [25325,25332]
name: Session [25325,25332]
===
match
---
name: int [40108,40111]
name: int [40611,40614]
===
match
---
expr_stmt [21213,21240]
expr_stmt [21213,21240]
===
match
---
suite [19826,20243]
suite [19826,20243]
===
match
---
name: sys [927,930]
name: sys [927,930]
===
match
---
trailer [79445,79647]
trailer [79948,80150]
===
match
---
operator: , [51474,51475]
operator: , [51977,51978]
===
match
---
if_stmt [10898,11096]
if_stmt [10898,11096]
===
match
---
expr_stmt [41810,41845]
expr_stmt [42313,42348]
===
match
---
name: request [23666,23673]
name: request [23666,23673]
===
match
---
name: subdir [54255,54261]
name: subdir [54758,54764]
===
match
---
name: pickle_dags [5257,5268]
name: pickle_dags [5257,5268]
===
match
---
comparison [74989,75040]
comparison [75492,75543]
===
match
---
trailer [55733,55774]
trailer [56236,56277]
===
match
---
trailer [13482,13484]
trailer [13482,13484]
===
match
---
trailer [57770,57789]
trailer [58273,58292]
===
match
---
simple_stmt [40121,40263]
simple_stmt [40624,40766]
===
match
---
arith_expr [70137,70173]
arith_expr [70640,70676]
===
match
---
suite [20322,20594]
suite [20322,20594]
===
match
---
simple_stmt [10569,10650]
simple_stmt [10569,10650]
===
match
---
name: run_type [69615,69623]
name: run_type [70118,70126]
===
match
---
argument [7951,7986]
argument [7951,7986]
===
match
---
name: len [51866,51869]
name: len [52369,52372]
===
match
---
operator: = [73092,73093]
operator: = [73595,73596]
===
match
---
operator: , [53093,53094]
operator: , [53596,53597]
===
match
---
comparison [65560,65594]
comparison [66063,66097]
===
match
---
trailer [38604,38611]
trailer [39107,39114]
===
match
---
trailer [30225,30242]
trailer [30479,30496]
===
match
---
trailer [68699,68709]
trailer [69202,69212]
===
match
---
trailer [26788,26801]
trailer [26788,26801]
===
match
---
name: dag_ids [7744,7751]
name: dag_ids [7744,7751]
===
match
---
argument [47297,47308]
argument [47800,47811]
===
match
---
trailer [16822,16826]
trailer [16822,16826]
===
match
---
name: setproctitle [1253,1265]
name: setproctitle [1253,1265]
===
match
---
term [31812,31820]
term [32315,32323]
===
match
---
trailer [45255,45261]
trailer [45758,45764]
===
match
---
simple_stmt [21310,21329]
simple_stmt [21310,21329]
===
match
---
name: RUNNING [69786,69793]
name: RUNNING [70289,70296]
===
match
---
trailer [30502,30511]
trailer [30756,30765]
===
match
---
name: _exit_gracefully [30905,30921]
name: _exit_gracefully [31159,31175]
===
match
---
atom_expr [38538,38550]
atom_expr [39041,39053]
===
match
---
simple_stmt [24867,24902]
simple_stmt [24867,24902]
===
match
---
operator: , [52983,52984]
operator: , [53486,53487]
===
match
---
operator: = [13297,13298]
operator: = [13297,13298]
===
match
---
atom_expr [40943,41189]
atom_expr [41446,41692]
===
match
---
param [66957,66963]
param [67460,67466]
===
match
---
name: num_runs [59838,59846]
name: num_runs [60341,60349]
===
match
---
trailer [68695,68699]
trailer [69198,69202]
===
match
---
name: Pool [39753,39757]
name: Pool [40256,40260]
===
match
---
arglist [32462,32509]
arglist [32965,33012]
===
match
---
operator: , [76639,76640]
operator: , [77142,77143]
===
match
---
argument [56417,56432]
argument [56920,56935]
===
match
---
name: _run_scheduler_loop [56489,56508]
name: _run_scheduler_loop [56992,57011]
===
match
---
name: TI [16261,16263]
name: TI [16261,16263]
===
match
---
name: join [12647,12651]
name: join [12647,12651]
===
match
---
atom [17933,17969]
atom [17933,17969]
===
match
---
trailer [26870,26875]
trailer [26870,26875]
===
match
---
atom_expr [30871,30922]
atom_expr [31125,31176]
===
match
---
name: configure_orm [7291,7304]
name: configure_orm [7291,7304]
===
match
---
name: self [20019,20023]
name: self [20019,20023]
===
match
---
expr_stmt [45568,45618]
expr_stmt [46071,46121]
===
match
---
name: timezone [74691,74699]
name: timezone [75194,75202]
===
match
---
name: TI [36629,36631]
name: TI [37132,37134]
===
match
---
name: int [50895,50898]
name: int [51398,51401]
===
match
---
name: timer [8117,8122]
name: timer [8117,8122]
===
match
---
atom_expr [32450,32510]
atom_expr [32953,33013]
===
match
---
atom_expr [4619,4635]
atom_expr [4619,4635]
===
match
---
name: task_instances_to_examine [39644,39669]
name: task_instances_to_examine [40147,40172]
===
match
---
name: _create_dag_runs [67149,67165]
name: _create_dag_runs [67652,67668]
===
match
---
expr_stmt [52205,52252]
expr_stmt [52708,52755]
===
match
---
trailer [58813,58829]
trailer [59316,59332]
===
match
---
trailer [50361,50374]
trailer [50864,50877]
===
match
---
name: session [78483,78490]
name: session [78986,78993]
===
match
---
trailer [18505,18507]
trailer [18505,18507]
===
match
---
trailer [24382,24387]
trailer [24382,24387]
===
match
---
name: executable_tis [45999,46013]
name: executable_tis [46502,46516]
===
match
---
expr_stmt [4619,4671]
expr_stmt [4619,4671]
===
match
---
name: pool_to_task_instances [39700,39722]
name: pool_to_task_instances [40203,40225]
===
match
---
name: dag_run [64512,64519]
name: dag_run [65015,65022]
===
match
---
param [56509,56513]
param [57012,57016]
===
match
---
trailer [64071,64086]
trailer [64574,64589]
===
match
---
simple_stmt [73960,74036]
simple_stmt [74463,74539]
===
match
---
name: dag [24479,24482]
name: dag [24479,24482]
===
match
---
atom_expr [40732,40814]
atom_expr [41235,41317]
===
match
---
operator: = [7810,7811]
operator: = [7810,7811]
===
match
---
operator: , [9093,9094]
operator: , [9093,9094]
===
match
---
atom [60655,60726]
atom [61158,61229]
===
match
---
trailer [58061,58067]
trailer [58564,58570]
===
match
---
not_test [49152,49182]
not_test [49655,49685]
===
match
---
name: dag_id [74318,74324]
name: dag_id [74821,74827]
===
match
---
suite [39835,39913]
suite [40338,40416]
===
match
---
trailer [73424,73439]
trailer [73927,73942]
===
match
---
name: MultiprocessingConnection [5198,5223]
name: MultiprocessingConnection [5198,5223]
===
match
---
name: session [77941,77948]
name: session [78444,78451]
===
match
---
suite [49183,49203]
suite [49686,49706]
===
match
---
name: pool [44525,44529]
name: pool [45028,45032]
===
match
---
subscriptlist [50859,50898]
subscriptlist [51362,51401]
===
match
---
name: _instance_id [9248,9260]
name: _instance_id [9248,9260]
===
match
---
name: num_unhandled [41832,41845]
name: num_unhandled [42335,42348]
===
match
---
simple_stmt [41810,41846]
simple_stmt [42313,42349]
===
match
---
operator: } [20716,20717]
operator: } [20716,20717]
===
match
---
comparison [39315,39350]
comparison [39818,39853]
===
match
---
trailer [13464,13473]
trailer [13464,13473]
===
match
---
name: file_path [56098,56107]
name: file_path [56601,56610]
===
match
---
simple_stmt [18452,18471]
simple_stmt [18452,18471]
===
match
---
name: processor_agent [58814,58829]
name: processor_agent [59317,59332]
===
match
---
name: dag_id [74185,74191]
name: dag_id [74688,74694]
===
match
---
name: multiprocessing [4336,4351]
name: multiprocessing [4336,4351]
===
match
---
simple_stmt [73507,73763]
simple_stmt [74010,74266]
===
match
---
name: session [37774,37781]
name: session [38277,38284]
===
match
---
operator: , [78056,78057]
operator: , [78559,78560]
===
match
---
name: session [35160,35167]
name: session [35663,35670]
===
match
---
argument [69935,69958]
argument [70438,70461]
===
match
---
name: dag_run [74666,74673]
name: dag_run [75169,75176]
===
match
---
name: update [45672,45678]
name: update [46175,46181]
===
match
---
atom_expr [49314,49324]
atom_expr [49817,49827]
===
match
---
atom_expr [4796,4813]
atom_expr [4796,4813]
===
match
---
string: """Get Next DagRuns to Examine with retries""" [66789,66835]
string: """Get Next DagRuns to Examine with retries""" [67292,67338]
===
match
---
name: info [42569,42573]
name: info [43072,43076]
===
match
---
name: states [40206,40212]
name: states [40709,40715]
===
match
---
name: limit [38911,38916]
name: limit [39414,39419]
===
match
---
name: dagbag [23918,23924]
name: dagbag [23918,23924]
===
match
---
name: self [10901,10905]
name: self [10901,10905]
===
match
---
name: provide_session [77810,77825]
name: provide_session [78313,78328]
===
match
---
trailer [27799,27812]
trailer [27799,27812]
===
match
---
atom_expr [60712,60725]
atom_expr [61215,61228]
===
match
---
atom_expr [30551,30596]
atom_expr [30805,30850]
===
match
---
operator: = [35969,35970]
operator: = [36472,36473]
===
match
---
trailer [4359,4371]
trailer [4359,4371]
===
match
---
name: task [24535,24539]
name: task [24535,24539]
===
match
---
operator: , [19213,19214]
operator: , [19213,19214]
===
match
---
name: int [61181,61184]
name: int [61684,61687]
===
match
---
operator: , [26882,26883]
operator: , [26882,26883]
===
match
---
name: TI [45645,45647]
name: TI [46148,46150]
===
match
---
suite [20353,20594]
suite [20353,20594]
===
match
---
name: request [23930,23937]
name: request [23930,23937]
===
match
---
name: exc [1355,1358]
name: exc [1355,1358]
===
match
---
suite [32276,32402]
suite [32779,32905]
===
match
---
name: sql_conn [30337,30345]
name: sql_conn [30591,30599]
===
match
---
name: result_channel [8517,8531]
name: result_channel [8517,8531]
===
match
---
name: Session [21415,21422]
name: Session [21415,21422]
===
match
---
name: count [36964,36969]
name: count [37467,37472]
===
match
---
atom_expr [38962,38970]
atom_expr [39465,39473]
===
match
---
atom_expr [13621,13649]
atom_expr [13621,13649]
===
match
---
simple_stmt [37497,37527]
simple_stmt [38000,38030]
===
match
---
name: TI [37181,37183]
name: TI [37684,37686]
===
match
---
if_stmt [77576,77669]
if_stmt [78079,78172]
===
match
---
name: fetched_tis [17982,17993]
name: fetched_tis [17982,17993]
===
match
---
atom_expr [3127,3142]
atom_expr [3127,3142]
===
match
---
atom_expr [27062,27087]
atom_expr [27062,27087]
===
match
---
name: session [21310,21317]
name: session [21310,21317]
===
match
---
simple_stmt [17982,18189]
simple_stmt [17982,18189]
===
match
---
name: max [37970,37973]
name: max [38473,38476]
===
match
---
simple_stmt [66001,66081]
simple_stmt [66504,66584]
===
match
---
atom_expr [78136,78160]
atom_expr [78639,78663]
===
match
---
operator: = [46858,46859]
operator: = [47361,47362]
===
match
---
operator: , [49388,49389]
operator: , [49891,49892]
===
match
---
atom_expr [24442,24454]
atom_expr [24442,24454]
===
match
---
name: task_instances [46133,46147]
name: task_instances [46636,46650]
===
match
---
trailer [12651,12653]
trailer [12651,12653]
===
match
---
tfpdef [15240,15268]
tfpdef [15240,15268]
===
match
---
name: options [80958,80965]
name: options [81461,81468]
===
match
---
string: "Set %s task instances to state=%s as their associated DagRun was not in RUNNING state" [35635,35722]
string: "Set %s task instances to state=%s as their associated DagRun was not in RUNNING state" [36138,36225]
===
match
---
simple_stmt [1172,1247]
simple_stmt [1172,1247]
===
match
---
name: self [59935,59939]
name: self [60438,60442]
===
match
---
name: dag_run [73128,73135]
name: dag_run [73631,73638]
===
match
---
operator: = [20273,20274]
operator: = [20273,20274]
===
match
---
try_stmt [68551,68799]
try_stmt [69054,69302]
===
match
---
name: task_id [18286,18293]
name: task_id [18286,18293]
===
match
---
string: """         This function is where the main scheduling decisions take places. It:          - Creates any necessary DAG runs by examining the next_dagrun_create_after column of DagModel            Since creating Dag Runs is a relatively time consuming process, we select only 10 dags by default           (configurable via ``scheduler.max_dagruns_to_create_per_loop`` setting) - putting this higher will           mean one scheduler could spend a chunk of time creating dag runs, and not ever get around to           scheduling tasks.          - Finds the "next n oldest" running DAG Runs to examine for scheduling (n=20 by default, configurable           via ``scheduler.max_dagruns_per_loop_to_schedule`` config setting) and tries to progress state (TIs           to SCHEDULED, or DagRuns to SUCCESS/FAILURE etc)            By "next oldest", we mean hasn't been examined/scheduled in the most time.            The reason we don't select all dagruns at once because the rows are selected with row locks, meaning           that only one scheduler can "process them", even it is waiting behind other dags. Increasing this           limit will allow more throughput for smaller DAGs but will likely slow down throughput for larger           (>500 tasks.) DAGs          - Then, via a Critical Section (locking the rows of the Pool model) we queue tasks, and then send them           to the executor.            See docs of _critical_section_execute_task_instances for more.          :return: Number of TIs enqueued in this iteration         :rtype: int         """ [61194,62754]
string: """         This function is where the main scheduling decisions take places. It:          - Creates any necessary DAG runs by examining the next_dagrun_create_after column of DagModel            Since creating Dag Runs is a relatively time consuming process, we select only 10 dags by default           (configurable via ``scheduler.max_dagruns_to_create_per_loop`` setting) - putting this higher will           mean one scheduler could spend a chunk of time creating dag runs, and not ever get around to           scheduling tasks.          - Finds the "next n oldest" running DAG Runs to examine for scheduling (n=20 by default, configurable           via ``scheduler.max_dagruns_per_loop_to_schedule`` config setting) and tries to progress state (TIs           to SCHEDULED, or DagRuns to SUCCESS/FAILURE etc)            By "next oldest", we mean hasn't been examined/scheduled in the most time.            The reason we don't select all dagruns at once because the rows are selected with row locks, meaning           that only one scheduler can "process them", even it is waiting behind other dags. Increasing this           limit will allow more throughput for smaller DAGs but will likely slow down throughput for larger           (>500 tasks.) DAGs          - Then, via a Critical Section (locking the rows of the Pool model) we queue tasks, and then send them           to the executor.            See docs of _critical_section_execute_task_instances for more.          :return: Number of TIs enqueued in this iteration         :rtype: int         """ [61697,63257]
===
match
---
if_stmt [10786,10889]
if_stmt [10786,10889]
===
match
---
name: self [32765,32769]
name: self [33268,33272]
===
match
---
name: execution_date [24002,24016]
name: execution_date [24002,24016]
===
match
---
operator: , [53193,53194]
operator: , [53696,53697]
===
match
---
param [23840,23855]
param [23840,23855]
===
match
---
name: execute_start_time [54718,54736]
name: execute_start_time [55221,55239]
===
match
---
trailer [46954,46964]
trailer [47457,47467]
===
match
---
name: executable_tis [45497,45511]
name: executable_tis [46000,46014]
===
match
---
name: blocking_tis [18386,18398]
name: blocking_tis [18386,18398]
===
match
---
name: only_if_necessary [58929,58946]
name: only_if_necessary [59432,59449]
===
match
---
atom_expr [33933,33962]
atom_expr [34436,34465]
===
match
---
name: self [42257,42261]
name: self [42760,42764]
===
match
---
name: repr [50439,50443]
name: repr [50942,50946]
===
match
---
name: len [48820,48823]
name: len [49323,49326]
===
match
---
atom_expr [24921,24948]
atom_expr [24921,24948]
===
match
---
trailer [40643,40649]
trailer [41146,41152]
===
match
---
name: session [75417,75424]
name: session [75920,75927]
===
match
---
name: provide_session [35871,35886]
name: provide_session [36374,36389]
===
match
---
fstring_start: f' [78102,78104]
fstring_start: f' [78605,78607]
===
match
---
name: next_event [59017,59027]
name: next_event [59520,59530]
===
match
---
if_stmt [41489,41934]
if_stmt [41992,42437]
===
match
---
name: dag_id [35260,35266]
name: dag_id [35763,35769]
===
match
---
param [5182,5224]
param [5182,5224]
===
match
---
name: success [24092,24099]
name: success [24092,24099]
===
match
---
name: SIGTERM [30952,30959]
name: SIGTERM [31206,31213]
===
match
---
name: EXECUTION_STATES [40218,40234]
name: EXECUTION_STATES [40721,40737]
===
match
---
trailer [32593,32600]
trailer [33096,33103]
===
match
---
simple_stmt [82025,82076]
simple_stmt [82528,82579]
===
match
---
param [53501,53505]
param [54004,54008]
===
match
---
trailer [30877,30884]
trailer [31131,31138]
===
match
---
simple_stmt [1862,1903]
simple_stmt [1862,1903]
===
match
---
name: active_runs_of_dag [72190,72208]
name: active_runs_of_dag [72693,72711]
===
match
---
name: ti [18696,18698]
name: ti [18696,18698]
===
match
---
name: dag_run [74602,74609]
name: dag_run [75105,75112]
===
match
---
atom_expr [78907,78943]
atom_expr [79410,79446]
===
match
---
operator: , [25125,25126]
operator: , [25125,25126]
===
match
---
or_test [12218,12271]
or_test [12218,12271]
===
match
---
name: primary [52184,52191]
name: primary [52687,52694]
===
match
---
operator: = [25333,25334]
operator: = [25333,25334]
===
match
---
name: info [79796,79800]
name: info [80299,80303]
===
match
---
string: """Only run DagRun.verify integrity if Serialized DAG has changed since it is slow""" [76144,76229]
string: """Only run DagRun.verify integrity if Serialized DAG has changed since it is slow""" [76647,76732]
===
match
---
trailer [27536,27545]
trailer [27536,27545]
===
match
---
trailer [10934,10943]
trailer [10934,10943]
===
match
---
number: 0 [39349,39350]
number: 0 [39852,39853]
===
match
---
number: 1 [34488,34489]
number: 1 [34991,34992]
===
match
---
atom_expr [54284,54309]
atom_expr [54787,54812]
===
match
---
trailer [80659,80671]
trailer [81162,81174]
===
match
---
argument [77776,77793]
argument [78279,78296]
===
match
---
name: ti [52586,52588]
name: ti [53089,53091]
===
match
---
name: import_errors [27825,27838]
name: import_errors [27825,27838]
===
match
---
name: self [72021,72025]
name: self [72524,72528]
===
match
---
operator: , [78412,78413]
operator: , [78915,78916]
===
match
---
trailer [7743,7769]
trailer [7743,7769]
===
match
---
name: _parent_channel [4877,4892]
name: _parent_channel [4877,4892]
===
match
---
name: execution_date [74997,75011]
name: execution_date [75500,75514]
===
match
---
name: sla [18543,18546]
name: sla [18543,18546]
===
match
---
operator: = [19464,19465]
operator: = [19464,19465]
===
match
---
trailer [31802,31806]
trailer [32305,32309]
===
match
---
name: models [34632,34638]
name: models [35135,35141]
===
match
---
atom_expr [4196,4219]
atom_expr [4196,4219]
===
match
---
string: "Closing parent pipe" [6748,6769]
string: "Closing parent pipe" [6748,6769]
===
match
---
trailer [55323,55343]
trailer [55826,55846]
===
match
---
name: dag_id [44914,44920]
name: dag_id [45417,45423]
===
match
---
name: session [71025,71032]
name: session [71528,71535]
===
match
---
trailer [76349,76358]
trailer [76852,76861]
===
match
---
name: next_event [59612,59622]
name: next_event [60115,60125]
===
match
---
operator: , [67377,67378]
operator: , [67880,67881]
===
match
---
suite [68674,68799]
suite [69177,69302]
===
match
---
simple_stmt [66316,66339]
simple_stmt [66819,66842]
===
match
---
operator: , [1234,1235]
operator: , [1234,1235]
===
match
---
trailer [10573,10582]
trailer [10573,10582]
===
match
---
atom_expr [16992,17006]
atom_expr [16992,17006]
===
match
---
trailer [82051,82056]
trailer [82554,82559]
===
match
---
operator: = [25007,25008]
operator: = [25007,25008]
===
match
---
suite [20543,20594]
suite [20543,20594]
===
match
---
name: int [13755,13758]
name: int [13755,13758]
===
match
---
name: List [38962,38966]
name: List [39465,39469]
===
match
---
name: Session [67388,67395]
name: Session [67891,67898]
===
match
---
trailer [50443,50446]
trailer [50946,50949]
===
match
---
name: info [53262,53266]
name: info [53765,53769]
===
match
---
name: register_signals [54644,54660]
name: register_signals [55147,55163]
===
match
---
name: _result [4459,4466]
name: _result [4459,4466]
===
match
---
operator: , [51702,51703]
operator: , [52205,52206]
===
match
---
operator: , [20398,20399]
operator: , [20398,20399]
===
match
---
name: Logger [6504,6510]
name: Logger [6504,6510]
===
match
---
simple_stmt [35128,35532]
simple_stmt [35631,36035]
===
match
---
trailer [30410,30423]
trailer [30664,30677]
===
match
---
suite [71430,72503]
suite [71933,73006]
===
match
---
expr_stmt [71624,71684]
expr_stmt [72127,72187]
===
match
---
testlist_comp [17934,17968]
testlist_comp [17934,17968]
===
match
---
trailer [11795,11838]
trailer [11795,11838]
===
match
---
name: run_id [38461,38467]
name: run_id [38964,38970]
===
match
---
argument [22367,22388]
argument [22367,22388]
===
match
---
trailer [36025,36047]
trailer [36528,36550]
===
match
---
name: task_instance [42774,42787]
name: task_instance [43277,43290]
===
match
---
trailer [45295,45311]
trailer [45798,45814]
===
match
---
name: tasks [15899,15904]
name: tasks [15899,15904]
===
match
---
string: "Sending %s to executor with priority %s and queue %s" [47078,47132]
string: "Sending %s to executor with priority %s and queue %s" [47581,47635]
===
match
---
trailer [82516,82518]
trailer [83019,83021]
===
match
---
name: State [18078,18083]
name: State [18078,18083]
===
match
---
trailer [51093,51095]
trailer [51596,51598]
===
match
---
name: set [81704,81707]
name: set [82207,82210]
===
match
---
trailer [34926,35114]
trailer [35429,35617]
===
match
---
atom_expr [59978,60234]
atom_expr [60481,60737]
===
match
---
arglist [38164,38188]
arglist [38667,38691]
===
match
---
name: task_instance [44439,44452]
name: task_instance [44942,44955]
===
match
---
trailer [12539,12545]
trailer [12539,12545]
===
match
---
name: sla [15869,15872]
name: sla [15869,15872]
===
match
---
atom_expr [17079,17120]
atom_expr [17079,17120]
===
match
---
name: timezone [45873,45881]
name: timezone [46376,46384]
===
match
---
operator: = [42974,42975]
operator: = [43477,43478]
===
match
---
simple_stmt [36978,37003]
simple_stmt [37481,37506]
===
match
---
decorated [77809,78280]
decorated [78312,78783]
===
match
---
operator: , [81839,81840]
operator: , [82342,82343]
===
match
---
name: file_path [25207,25216]
name: file_path [25207,25216]
===
match
---
name: dag_hash [76523,76531]
name: dag_hash [77026,77034]
===
match
---
operator: , [75176,75177]
operator: , [75679,75680]
===
match
---
trailer [15898,15904]
trailer [15898,15904]
===
match
---
not_test [13904,13917]
not_test [13904,13917]
===
match
---
name: dependencies_states [2134,2153]
name: dependencies_states [2134,2153]
===
match
---
import_as_names [1019,1061]
import_as_names [1019,1061]
===
match
---
trailer [69634,69644]
trailer [70137,70147]
===
match
---
trailer [8891,8911]
trailer [8891,8911]
===
match
---
trailer [59955,59960]
trailer [60458,60463]
===
match
---
operator: = [76882,76883]
operator: = [77385,77386]
===
match
---
trailer [65700,65706]
trailer [66203,66209]
===
match
---
name: len [27796,27799]
name: len [27796,27799]
===
match
---
name: Session [48923,48930]
name: Session [49426,49433]
===
match
---
operator: ** [81252,81254]
operator: ** [81755,81757]
===
match
---
trailer [81529,81536]
trailer [82032,82039]
===
match
---
name: dag_id [17017,17023]
name: dag_id [17017,17023]
===
match
---
atom_expr [42560,42889]
atom_expr [43063,43392]
===
match
---
name: ImportError [22307,22318]
name: ImportError [22307,22318]
===
match
---
tfpdef [25281,25298]
tfpdef [25281,25298]
===
match
---
name: run_single_parsing_loop [58160,58183]
name: run_single_parsing_loop [58663,58686]
===
match
---
name: SlaCallbackRequest [23257,23275]
name: SlaCallbackRequest [23257,23275]
===
match
---
operator: = [77907,77908]
operator: = [78410,78411]
===
match
---
name: state [53335,53340]
name: state [53838,53843]
===
match
---
name: DagRunType [3066,3076]
name: DagRunType [3066,3076]
===
match
---
name: int [36702,36705]
name: int [37205,37208]
===
match
---
name: TI [16461,16463]
name: TI [16461,16463]
===
match
---
trailer [18129,18136]
trailer [18129,18136]
===
match
---
if_stmt [18980,19438]
if_stmt [18980,19438]
===
match
---
trailer [24869,24879]
trailer [24869,24879]
===
match
---
name: dag [24370,24373]
name: dag [24370,24373]
===
match
---
name: self [48472,48476]
name: self [48975,48979]
===
match
---
import_from [1493,1530]
import_from [1493,1530]
===
match
---
trailer [82230,82240]
trailer [82733,82743]
===
match
---
name: dag [27488,27491]
name: dag [27488,27491]
===
match
---
trailer [55921,55931]
trailer [56424,56434]
===
match
---
trailer [54565,54574]
trailer [55068,55077]
===
match
---
name: DAG [15427,15430]
name: DAG [15427,15430]
===
match
---
name: processor_agent [58459,58474]
name: processor_agent [58962,58977]
===
match
---
name: DagRun [3115,3121]
name: DagRun [3115,3121]
===
match
---
atom_expr [52014,52095]
atom_expr [52517,52598]
===
match
---
name: info [6743,6747]
name: info [6743,6747]
===
match
---
operator: , [10048,10049]
operator: , [10048,10049]
===
match
---
trailer [49780,49782]
trailer [50283,50285]
===
match
---
name: log [50494,50497]
name: log [50997,51000]
===
match
---
name: filter_for_tis [45656,45670]
name: filter_for_tis [46159,46173]
===
match
---
tfpdef [77218,77226]
tfpdef [77721,77729]
===
match
---
operator: = [76596,76597]
operator: = [77099,77100]
===
match
---
name: timestamp [17427,17436]
name: timestamp [17427,17436]
===
match
---
atom_expr [38572,38590]
atom_expr [39075,39093]
===
match
---
trailer [68423,68430]
trailer [68926,68933]
===
match
---
trailer [26832,26894]
trailer [26832,26894]
===
match
---
name: ti [81542,81544]
name: ti [82045,82047]
===
match
---
name: execution_date [51562,51576]
name: execution_date [52065,52079]
===
match
---
expr_stmt [73088,73160]
expr_stmt [73591,73663]
===
match
---
name: is_failure_callback [24929,24948]
name: is_failure_callback [24929,24948]
===
match
---
annassign [50852,50904]
annassign [51355,51407]
===
match
---
trailer [18143,18150]
trailer [18143,18150]
===
match
---
name: emails [20430,20436]
name: emails [20430,20436]
===
match
---
atom [63985,64378]
atom [64488,64881]
===
match
---
name: dag_model [71808,71817]
name: dag_model [72311,72320]
===
match
---
name: tis_with_right_state [51968,51988]
name: tis_with_right_state [52471,52491]
===
match
---
trailer [66657,66664]
trailer [67160,67167]
===
match
---
name: request [23466,23473]
name: request [23466,23473]
===
match
---
name: utils [2832,2837]
name: utils [2832,2837]
===
match
---
trailer [73594,73623]
trailer [74097,74126]
===
match
---
sync_comp_for [18597,18612]
sync_comp_for [18597,18612]
===
match
---
string: "Task %s doesn't exist in DAG anymore, skipping SLA miss notification." [20061,20132]
string: "Task %s doesn't exist in DAG anymore, skipping SLA miss notification." [20061,20132]
===
match
---
tfpdef [78483,78499]
tfpdef [78986,79002]
===
match
---
string: "Processor agent is not started." [50777,50810]
string: "Processor agent is not started." [51280,51313]
===
match
---
param [5322,5339]
param [5322,5339]
===
match
---
atom_expr [40621,40651]
atom_expr [41124,41154]
===
match
---
param [32794,32809]
param [33297,33312]
===
match
---
trailer [81799,81804]
trailer [82302,82307]
===
match
---
trailer [9552,9558]
trailer [9552,9558]
===
match
---
atom_expr [68756,68772]
atom_expr [69259,69275]
===
match
---
if_stmt [20374,20594]
if_stmt [20374,20594]
===
match
---
trailer [29667,29674]
trailer [29921,29928]
===
match
---
arglist [60644,60806]
arglist [61147,61309]
===
match
---
name: Tuple [36026,36031]
name: Tuple [36529,36534]
===
match
---
trailer [26716,26748]
trailer [26716,26748]
===
match
---
name: DefaultDict [36744,36755]
name: DefaultDict [37247,37258]
===
match
---
name: self [23013,23017]
name: self [23013,23017]
===
match
---
name: Stats [78090,78095]
name: Stats [78593,78598]
===
match
---
simple_stmt [12569,12617]
simple_stmt [12569,12617]
===
match
---
name: Exception [19297,19306]
name: Exception [19297,19306]
===
match
---
atom_expr [46536,46545]
atom_expr [47039,47048]
===
match
---
name: outerjoin [80497,80506]
name: outerjoin [81000,81009]
===
match
---
trailer [5063,5074]
trailer [5063,5074]
===
match
---
atom_expr [67846,67871]
atom_expr [68349,68374]
===
match
---
name: info [26393,26397]
name: info [26393,26397]
===
match
---
operator: = [60537,60538]
operator: = [61040,61041]
===
match
---
name: signum [31654,31660]
name: signum [32157,32163]
===
match
---
name: queue [47035,47040]
name: queue [47538,47543]
===
match
---
string: 'core' [57283,57289]
string: 'core' [57786,57792]
===
match
---
atom_expr [38859,38885]
atom_expr [39362,39388]
===
match
---
name: start [65878,65883]
name: start [66381,66386]
===
match
---
name: ti_key [51555,51561]
name: ti_key [52058,52064]
===
match
---
operator: , [36860,36861]
operator: , [37363,37364]
===
match
---
name: self [31840,31844]
name: self [32343,32347]
===
match
---
name: simple_ti [24787,24796]
name: simple_ti [24787,24796]
===
match
---
trailer [33855,33863]
trailer [34358,34366]
===
match
---
operator: == [49575,49577]
operator: == [50078,50080]
===
match
---
operator: += [41891,41893]
operator: += [42394,42396]
===
match
---
trailer [58589,58604]
trailer [59092,59107]
===
match
---
operator: , [38477,38478]
operator: , [38980,38981]
===
match
---
simple_stmt [2005,2081]
simple_stmt [2005,2081]
===
match
---
trailer [36597,36605]
trailer [37100,37108]
===
match
---
atom_expr [81254,81282]
atom_expr [81757,81785]
===
match
---
simple_stmt [20755,20773]
simple_stmt [20755,20773]
===
match
---
name: DagCallbackRequest [76862,76880]
name: DagCallbackRequest [77365,77383]
===
match
---
trailer [13342,13344]
trailer [13342,13344]
===
match
---
name: dag_id [68853,68859]
name: dag_id [69356,69362]
===
match
---
trailer [65877,65883]
trailer [66380,66386]
===
match
---
trailer [4168,4177]
trailer [4168,4177]
===
match
---
string: """         Check if the process launched to process this file is done.          :return: whether the process is finished running         :rtype: bool         """ [12044,12206]
string: """         Check if the process launched to process this file is done.          :return: whether the process is finished running         :rtype: bool         """ [12044,12206]
===
match
---
name: get [68845,68848]
name: get [69348,69351]
===
match
---
name: executor [47177,47185]
name: executor [47680,47688]
===
match
---
name: num_queued_tis [66686,66700]
name: num_queued_tis [67189,67203]
===
match
---
dotted_name [1344,1358]
dotted_name [1344,1358]
===
match
---
name: start_date [73388,73398]
name: start_date [73891,73901]
===
match
---
decorator [56040,56054]
decorator [56543,56557]
===
match
---
name: self [12491,12495]
name: self [12491,12495]
===
match
---
atom_expr [50766,50811]
atom_expr [51269,51314]
===
match
---
name: or_ [1327,1330]
name: or_ [1327,1330]
===
match
---
trailer [10731,10737]
trailer [10731,10737]
===
match
---
trailer [38866,38870]
trailer [39369,39373]
===
match
---
name: next_dagrun_create_after [72295,72319]
name: next_dagrun_create_after [72798,72822]
===
match
---
name: sqlalchemy [1344,1354]
name: sqlalchemy [1344,1354]
===
match
---
atom_expr [76625,76639]
atom_expr [77128,77142]
===
match
---
trailer [33550,33558]
trailer [34053,34061]
===
match
---
name: func [36548,36552]
name: func [37051,37055]
===
match
---
trailer [57465,57487]
trailer [57968,57990]
===
match
---
atom_expr [16536,16545]
atom_expr [16536,16545]
===
match
---
atom_expr [14070,14087]
atom_expr [14070,14087]
===
match
---
name: all [71377,71380]
name: all [71880,71883]
===
match
---
name: ti [52438,52440]
name: ti [52941,52943]
===
match
---
atom_expr [47134,47140]
atom_expr [47637,47643]
===
match
---
name: info [43874,43878]
name: info [44377,44381]
===
match
---
name: self [10298,10302]
name: self [10298,10302]
===
match
---
trailer [74996,75011]
trailer [75499,75514]
===
match
---
expr_stmt [81617,81643]
expr_stmt [82120,82146]
===
match
---
atom_expr [69951,69958]
atom_expr [70454,70461]
===
match
---
expr_stmt [57318,57343]
expr_stmt [57821,57846]
===
match
---
trailer [44800,44807]
trailer [45303,45310]
===
match
---
name: request [23207,23214]
name: request [23207,23214]
===
match
---
name: TaskInstance [3090,3102]
name: TaskInstance [3090,3102]
===
match
---
string: "Processing Callback Request: %s" [23028,23061]
string: "Processing Callback Request: %s" [23028,23061]
===
match
---
atom_expr [68232,68362]
atom_expr [68735,68865]
===
match
---
name: of [81228,81230]
name: of [81731,81733]
===
match
---
name: pid [10944,10947]
name: pid [10944,10947]
===
match
---
name: DAG [55298,55301]
name: DAG [55801,55804]
===
match
---
name: dag_file_processor [7706,7724]
name: dag_file_processor [7706,7724]
===
match
---
parameters [5121,5395]
parameters [5121,5395]
===
match
---
argument [39039,39054]
argument [39542,39557]
===
match
---
operator: , [32808,32809]
operator: , [33311,33312]
===
match
---
string: "Started process (PID=%s) to work on %s" [7624,7664]
string: "Started process (PID=%s) to work on %s" [7624,7664]
===
match
---
atom_expr [34172,34189]
atom_expr [34675,34692]
===
match
---
name: filter_for_tis [50158,50172]
name: filter_for_tis [50661,50675]
===
match
---
expr_stmt [39700,39779]
expr_stmt [40203,40282]
===
match
---
simple_stmt [22412,22429]
simple_stmt [22412,22429]
===
match
---
name: TI [24532,24534]
name: TI [24532,24534]
===
match
---
trailer [57865,57930]
trailer [58368,58433]
===
match
---
trailer [76522,76531]
trailer [77025,77034]
===
match
---
name: num_ready [40899,40908]
name: num_ready [41402,41411]
===
match
---
fstring [78026,78056]
fstring [78529,78559]
===
match
---
operator: , [36546,36547]
operator: , [37049,37050]
===
match
---
name: dagbag [23199,23205]
name: dagbag [23199,23205]
===
match
---
simple_stmt [4124,4156]
simple_stmt [4124,4156]
===
match
---
name: num_runs [59660,59668]
name: num_runs [60163,60171]
===
match
---
name: num_queued_tis [58568,58582]
name: num_queued_tis [59071,59085]
===
match
---
name: queued_tasks [49170,49182]
name: queued_tasks [49673,49685]
===
match
---
operator: = [54737,54738]
operator: = [55240,55241]
===
match
---
trailer [60162,60183]
trailer [60665,60686]
===
match
---
operator: = [26547,26548]
operator: = [26547,26548]
===
match
---
name: self [53741,53745]
name: self [54244,54248]
===
match
---
name: dag_id [16215,16221]
name: dag_id [16215,16221]
===
match
---
trailer [39109,39113]
trailer [39612,39616]
===
match
---
name: incr [20910,20914]
name: incr [20910,20914]
===
match
---
name: async_mode [54513,54523]
name: async_mode [55016,55026]
===
match
---
name: task_list [18521,18530]
name: task_list [18521,18530]
===
match
---
atom_expr [23430,23483]
atom_expr [23430,23483]
===
match
---
trailer [73587,73594]
trailer [74090,74097]
===
match
---
operator: , [42451,42452]
operator: , [42954,42955]
===
match
---
atom_expr [22229,22257]
atom_expr [22229,22257]
===
match
---
name: queued_tis [48793,48803]
name: queued_tis [49296,49306]
===
match
---
name: collections [965,976]
name: collections [965,976]
===
match
---
operator: , [31423,31424]
operator: , [31800,31801]
===
match
---
atom_expr [80614,80627]
atom_expr [81117,81130]
===
match
---
name: all [36662,36665]
name: all [37165,37168]
===
match
---
operator: , [75585,75586]
operator: , [76088,76089]
===
match
---
name: stats [38775,38780]
name: stats [39278,39283]
===
match
---
operator: , [50893,50894]
operator: , [51396,51397]
===
match
---
name: self [78329,78333]
name: self [78832,78836]
===
match
---
simple_stmt [931,948]
simple_stmt [931,948]
===
match
---
trailer [58143,58159]
trailer [58646,58662]
===
match
---
name: get_task [16782,16790]
name: get_task [16782,16790]
===
match
---
trailer [68000,68007]
trailer [68503,68510]
===
match
---
simple_stmt [52438,52469]
simple_stmt [52941,52972]
===
match
---
argument [66327,66337]
argument [66830,66840]
===
match
---
name: open_slots [44187,44197]
name: open_slots [44690,44700]
===
match
---
name: filter [71084,71090]
name: filter [71587,71593]
===
match
---
atom_expr [54047,54096]
atom_expr [54550,54599]
===
match
---
trailer [79143,79158]
trailer [79646,79661]
===
match
---
name: TaskInstanceKey [2065,2080]
name: TaskInstanceKey [2065,2080]
===
match
---
atom_expr [57687,57752]
atom_expr [58190,58255]
===
match
---
suite [62918,62981]
suite [63421,63484]
===
match
---
name: len [82227,82230]
name: len [82730,82733]
===
match
---
name: exception [20978,20987]
name: exception [20978,20987]
===
match
---
operator: @ [76040,76041]
operator: @ [76543,76544]
===
match
---
name: session [73891,73898]
name: session [74394,74401]
===
match
---
import_as_names [2619,2661]
import_as_names [2619,2661]
===
match
---
trailer [13284,13289]
trailer [13284,13289]
===
match
---
name: dagrun_timeout [73349,73363]
name: dagrun_timeout [73852,73866]
===
match
---
import_as_names [1831,1861]
import_as_names [1831,1861]
===
match
---
name: task_instance [43333,43346]
name: task_instance [43836,43849]
===
match
---
name: in_ [80149,80152]
name: in_ [80652,80655]
===
match
---
comparison [17250,17299]
comparison [17250,17299]
===
match
---
operator: = [33439,33440]
operator: = [33942,33943]
===
match
---
trailer [64466,64474]
trailer [64969,64977]
===
match
---
name: keys [26876,26880]
name: keys [26876,26880]
===
match
---
trailer [73719,73725]
trailer [74222,74228]
===
match
---
operator: , [77774,77775]
operator: , [78277,78278]
===
match
---
trailer [43699,43706]
trailer [44202,44209]
===
match
---
name: signum [31527,31533]
name: signum [32030,32036]
===
match
---
name: dag_run [76104,76111]
name: dag_run [76607,76614]
===
match
---
name: simple_ti [24325,24334]
name: simple_ti [24325,24334]
===
match
---
trailer [46041,46045]
trailer [46544,46548]
===
match
---
operator: , [36006,36007]
operator: , [36509,36510]
===
match
---
simple_stmt [67896,68182]
simple_stmt [68399,68685]
===
match
---
trailer [17682,17700]
trailer [17682,17700]
===
match
---
operator: , [53210,53211]
operator: , [53713,53714]
===
match
---
name: _process [14409,14417]
name: _process [14409,14417]
===
match
---
operator: = [30757,30758]
operator: = [31011,31012]
===
match
---
trailer [65148,65171]
trailer [65651,65674]
===
match
---
trailer [46501,46518]
trailer [47004,47021]
===
match
---
atom_expr [23714,23735]
atom_expr [23714,23735]
===
match
---
argument [53180,53217]
argument [53683,53720]
===
match
---
parameters [76810,76894]
parameters [77313,77397]
===
match
---
name: self [34172,34176]
name: self [34675,34679]
===
match
---
operator: , [64086,64087]
operator: , [64589,64590]
===
match
---
argument [39082,39097]
argument [39585,39600]
===
match
---
trailer [26629,26633]
trailer [26629,26633]
===
match
---
name: num_starving_tasks [44573,44591]
name: num_starving_tasks [45076,45094]
===
match
---
import_from [1944,2004]
import_from [1944,2004]
===
match
---
sync_comp_for [68327,68347]
sync_comp_for [68830,68850]
===
match
---
name: DagBag [21432,21438]
name: DagBag [21432,21438]
===
match
---
param [76820,76825]
param [77323,77328]
===
match
---
trailer [38421,38433]
trailer [38924,38936]
===
match
---
name: self [31230,31234]
name: self [31607,31611]
===
match
---
name: DagFileProcessor [7727,7743]
name: DagFileProcessor [7727,7743]
===
match
---
name: _callback_requests [4201,4219]
name: _callback_requests [4201,4219]
===
match
---
argument [66247,66256]
argument [66750,66759]
===
match
---
trailer [20443,20479]
trailer [20443,20479]
===
match
---
name: log [15924,15927]
name: log [15924,15927]
===
match
---
name: dag_run [24083,24090]
name: dag_run [24083,24090]
===
match
---
name: x [50444,50445]
name: x [50947,50948]
===
match
---
name: __mapper_args__ [29207,29222]
name: __mapper_args__ [29461,29476]
===
match
---
name: provide_session [15380,15395]
name: provide_session [15380,15395]
===
match
---
funcdef [32715,35865]
funcdef [33218,36368]
===
match
---
name: sla [19814,19817]
name: sla [19814,19817]
===
match
---
name: task_instance [43000,43013]
name: task_instance [43503,43516]
===
match
---
not_test [50722,50746]
not_test [51225,51249]
===
match
---
name: timedelta [1083,1092]
name: timedelta [1083,1092]
===
match
---
trailer [80509,80523]
trailer [81012,81026]
===
match
---
operator: , [11020,11021]
operator: , [11020,11021]
===
match
---
atom_expr [14326,14342]
atom_expr [14326,14342]
===
match
---
operator: , [25221,25222]
operator: , [25221,25222]
===
match
---
simple_stmt [38935,39116]
simple_stmt [39438,39619]
===
match
---
name: ti [24722,24724]
name: ti [24722,24724]
===
match
---
name: _do_scheduling [61148,61162]
name: _do_scheduling [61651,61665]
===
match
---
trailer [64160,64164]
trailer [64663,64667]
===
match
---
fstring_string: DagFileProcessor [9113,9129]
fstring_string: DagFileProcessor [9113,9129]
===
match
---
name: log [25070,25073]
name: log [25070,25073]
===
match
---
name: timer [7169,7174]
name: timer [7169,7174]
===
match
---
name: Tuple [7794,7799]
name: Tuple [7794,7799]
===
match
---
name: sla [21213,21216]
name: sla [21213,21216]
===
match
---
name: settings [62892,62900]
name: settings [63395,63403]
===
match
---
trailer [36631,36639]
trailer [37134,37142]
===
match
---
name: self [14382,14386]
name: self [14382,14386]
===
match
---
trailer [14408,14417]
trailer [14408,14417]
===
match
---
name: self [58358,58362]
name: self [58861,58865]
===
match
---
name: self [24212,24216]
name: self [24212,24216]
===
match
---
trailer [4623,4635]
trailer [4623,4635]
===
match
---
name: group_by [71340,71348]
name: group_by [71843,71851]
===
match
---
expr_stmt [37718,37782]
expr_stmt [38221,38285]
===
match
---
name: dag_model [72384,72393]
name: dag_model [72887,72896]
===
match
---
trailer [45859,45871]
trailer [46362,46374]
===
match
---
trailer [11055,11060]
trailer [11055,11060]
===
match
---
param [66765,66770]
param [67268,67273]
===
match
---
name: open_slots [40853,40863]
name: open_slots [41356,41366]
===
match
---
atom_expr [4872,4892]
atom_expr [4872,4892]
===
match
---
name: fileloc [46907,46914]
name: fileloc [47410,47417]
===
match
---
trailer [35276,35283]
trailer [35779,35786]
===
match
---
string: "DAG %s is at (or above) max_active_runs (%d of %d), not creating any more runs" [72056,72136]
string: "DAG %s is at (or above) max_active_runs (%d of %d), not creating any more runs" [72559,72639]
===
match
---
operator: , [56415,56416]
operator: , [56918,56919]
===
match
---
trailer [49960,49962]
trailer [50463,50465]
===
match
---
atom_expr [11366,11383]
atom_expr [11366,11383]
===
match
---
expr_stmt [13135,13152]
expr_stmt [13135,13152]
===
match
---
name: exception [23571,23580]
name: exception [23571,23580]
===
match
---
trailer [16328,16335]
trailer [16328,16335]
===
match
---
trailer [64242,64249]
trailer [64745,64752]
===
match
---
trailer [79800,79858]
trailer [80303,80361]
===
match
---
string: "Critical section lock held by another Scheduler" [66432,66481]
string: "Critical section lock held by another Scheduler" [66935,66984]
===
match
---
simple_stmt [44219,44553]
simple_stmt [44722,45056]
===
match
---
atom_expr [75988,76034]
atom_expr [76491,76537]
===
match
---
name: dag_map [36676,36683]
name: dag_map [37179,37186]
===
match
---
atom_expr [16890,17058]
atom_expr [16890,17058]
===
match
---
arglist [20061,20145]
arglist [20061,20145]
===
match
---
atom_expr [66569,66587]
atom_expr [67072,67090]
===
match
---
name: signal [11080,11086]
name: signal [11080,11086]
===
match
---
trailer [82056,82075]
trailer [82559,82578]
===
match
---
expr_stmt [4556,4574]
expr_stmt [4556,4574]
===
match
---
name: dagbag [30680,30686]
name: dagbag [30934,30940]
===
match
---
atom_expr [42960,42973]
atom_expr [43463,43476]
===
match
---
operator: , [45144,45145]
operator: , [45647,45648]
===
match
---
arglist [47078,47157]
arglist [47581,47660]
===
match
---
number: 0 [35558,35559]
number: 0 [36061,36062]
===
match
---
suite [31488,31569]
suite [31991,32072]
===
match
---
name: threading [7552,7561]
name: threading [7552,7561]
===
match
---
sync_comp_for [18726,18748]
sync_comp_for [18726,18748]
===
match
---
name: State [52408,52413]
name: State [52911,52916]
===
match
---
suite [12442,13444]
suite [12442,13444]
===
match
---
name: in_ [68277,68280]
name: in_ [68780,68783]
===
match
---
subscriptlist [40091,40111]
subscriptlist [40594,40614]
===
match
---
import_from [1532,1568]
import_from [1532,1568]
===
match
---
name: task_instance [44965,44978]
name: task_instance [45468,45481]
===
match
---
operator: -> [56515,56517]
operator: -> [57018,57020]
===
match
---
name: dialect_name [16170,16182]
name: dialect_name [16170,16182]
===
match
---
atom_expr [20342,20352]
atom_expr [20342,20352]
===
match
---
name: self [57413,57417]
name: self [57916,57920]
===
match
---
name: models [35240,35246]
name: models [35743,35749]
===
match
---
atom_expr [35573,35588]
atom_expr [36076,36091]
===
match
---
atom_expr [26819,26894]
atom_expr [26819,26894]
===
match
---
atom_expr [64171,64185]
atom_expr [64674,64688]
===
match
---
arglist [47217,47309]
arglist [47720,47812]
===
match
---
operator: = [34302,34303]
operator: = [34805,34806]
===
match
---
expr_stmt [68208,68362]
expr_stmt [68711,68865]
===
match
---
atom_expr [27616,27658]
atom_expr [27616,27658]
===
match
---
parameters [70578,70634]
parameters [71081,71137]
===
match
---
param [46133,46157]
param [46636,46660]
===
match
---
name: dag_models [71145,71155]
name: dag_models [71648,71658]
===
match
---
name: call_regular_interval [57466,57487]
name: call_regular_interval [57969,57990]
===
match
---
name: process [4352,4359]
name: process [4352,4359]
===
match
---
simple_stmt [69570,69978]
simple_stmt [70073,70481]
===
match
---
simple_stmt [27097,27147]
simple_stmt [27097,27147]
===
match
---
trailer [31012,31020]
trailer [31266,31274]
===
match
---
simple_stmt [51109,51120]
simple_stmt [51612,51623]
===
match
---
operator: + [18685,18686]
operator: + [18685,18686]
===
match
---
trailer [48750,48792]
trailer [49253,49295]
===
match
---
operator: , [30959,30960]
operator: , [31213,31214]
===
match
---
with_item [7152,7174]
with_item [7152,7174]
===
match
---
name: _update_dag_next_dagruns [74123,74147]
name: _update_dag_next_dagruns [74626,74650]
===
match
---
name: self [39590,39594]
name: self [40093,40097]
===
match
---
suite [23903,24179]
suite [23903,24179]
===
match
---
atom_expr [43333,43354]
atom_expr [43836,43857]
===
match
---
string: "No tasks to consider for execution." [39379,39416]
string: "No tasks to consider for execution." [39882,39919]
===
match
---
trailer [11345,11354]
trailer [11345,11354]
===
match
---
operator: = [71005,71006]
operator: = [71508,71509]
===
match
---
operator: -= [44850,44852]
operator: -= [45353,45355]
===
match
---
operator: , [57559,57560]
operator: , [58062,58063]
===
match
---
return_stmt [48813,48835]
return_stmt [49316,49338]
===
match
---
trailer [67858,67866]
trailer [68361,68369]
===
match
---
trailer [59703,59897]
trailer [60206,60400]
===
match
---
name: num_failed [79751,79761]
name: num_failed [80254,80264]
===
match
---
atom_expr [30483,30511]
atom_expr [30737,30765]
===
match
---
operator: -> [37173,37175]
operator: -> [37676,37678]
===
match
---
expr_stmt [24867,24901]
expr_stmt [24867,24901]
===
match
---
atom_expr [77987,78000]
atom_expr [78490,78503]
===
match
---
trailer [54680,54696]
trailer [55183,55199]
===
match
---
expr_stmt [16447,16699]
expr_stmt [16447,16699]
===
match
---
atom_expr [39590,39690]
atom_expr [40093,40193]
===
match
---
trailer [52291,52295]
trailer [52794,52798]
===
match
---
operator: , [1202,1203]
operator: , [1202,1203]
===
match
---
string: "Not executing %s since the number of tasks running or queued " [42599,42662]
string: "Not executing %s since the number of tasks running or queued " [43102,43165]
===
match
---
trailer [51279,51295]
trailer [51782,51798]
===
match
---
simple_stmt [30406,30456]
simple_stmt [30660,30710]
===
match
---
name: selectinload [38662,38674]
name: selectinload [39165,39177]
===
match
---
operator: , [3929,3930]
operator: , [3929,3930]
===
match
---
argument [25002,25019]
argument [25002,25019]
===
match
---
simple_stmt [44786,44823]
simple_stmt [45289,45326]
===
match
---
comparison [16577,16604]
comparison [16577,16604]
===
match
---
trailer [30468,30480]
trailer [30722,30734]
===
match
---
suite [11210,11498]
suite [11210,11498]
===
match
---
trailer [41315,41330]
trailer [41818,41833]
===
match
---
atom_expr [43459,43480]
atom_expr [43962,43983]
===
match
---
name: task_instance_str [82270,82287]
name: task_instance_str [82773,82790]
===
match
---
parameters [77211,77227]
parameters [77714,77730]
===
match
---
name: int [11206,11209]
name: int [11206,11209]
===
match
---
name: lock_rows [37750,37759]
name: lock_rows [38253,38262]
===
match
---
expr_stmt [24527,24566]
expr_stmt [24527,24566]
===
match
---
atom_expr [52944,52990]
atom_expr [53447,53493]
===
match
---
name: simple_ti [24835,24844]
name: simple_ti [24835,24844]
===
match
---
arglist [65114,65180]
arglist [65617,65683]
===
match
---
name: airflow [2456,2463]
name: airflow [2456,2463]
===
match
---
name: session [40245,40252]
name: session [40748,40755]
===
match
---
name: run [70040,70043]
name: run [70543,70546]
===
match
---
atom_expr [27405,27424]
atom_expr [27405,27424]
===
match
---
atom_expr [17395,17404]
atom_expr [17395,17404]
===
match
---
trailer [51623,51634]
trailer [52126,52137]
===
match
---
trailer [55621,55630]
trailer [56124,56133]
===
match
---
operator: , [74335,74336]
operator: , [74838,74839]
===
match
---
suite [77361,77381]
suite [77864,77884]
===
match
---
simple_stmt [52265,52308]
simple_stmt [52768,52811]
===
match
---
operator: , [41097,41098]
operator: , [41600,41601]
===
match
---
simple_stmt [12670,12699]
simple_stmt [12670,12699]
===
match
---
trailer [54747,54754]
trailer [55250,55257]
===
match
---
name: in_ [33607,33610]
name: in_ [34110,34113]
===
match
---
testlist_star_expr [52265,52276]
testlist_star_expr [52768,52779]
===
match
---
name: pickle_dags [7906,7917]
name: pickle_dags [7906,7917]
===
match
---
trailer [32355,32357]
trailer [32858,32860]
===
match
---
name: try_number [52241,52251]
name: try_number [52744,52754]
===
match
---
fstring [9224,9270]
fstring [9224,9270]
===
match
---
operator: = [16465,16466]
operator: = [16465,16466]
===
match
---
operator: , [65163,65164]
operator: , [65666,65667]
===
match
---
annassign [4892,4936]
annassign [4892,4936]
===
match
---
name: dag_ids [15342,15349]
name: dag_ids [15342,15349]
===
match
---
operator: = [25030,25031]
operator: = [25030,25031]
===
match
---
simple_stmt [4619,4672]
simple_stmt [4619,4672]
===
match
---
atom_expr [71349,71362]
atom_expr [71852,71865]
===
match
---
comparison [16212,16235]
comparison [16212,16235]
===
match
---
name: file_path [56371,56380]
name: file_path [56874,56883]
===
match
---
operator: = [9304,9305]
operator: = [9304,9305]
===
match
---
trailer [81926,81949]
trailer [82429,82452]
===
match
---
name: filter [22084,22090]
name: filter [22084,22090]
===
match
---
decorator [14348,14358]
decorator [14348,14358]
===
match
---
name: getLogger [6521,6530]
name: getLogger [6521,6530]
===
match
---
trailer [33952,33956]
trailer [34455,34459]
===
match
---
atom_expr [45342,45386]
atom_expr [45845,45889]
===
match
---
trailer [48673,48710]
trailer [49176,49213]
===
match
---
trailer [23321,23326]
trailer [23321,23326]
===
match
---
simple_stmt [27616,27659]
simple_stmt [27616,27659]
===
match
---
import_from [2727,2818]
import_from [2727,2818]
===
match
---
trailer [16102,16108]
trailer [16102,16108]
===
match
---
atom_expr [77678,77803]
atom_expr [78181,78306]
===
match
---
trailer [20520,20526]
trailer [20520,20526]
===
match
---
arglist [53755,53821]
arglist [54258,54324]
===
match
---
suite [21192,21329]
suite [21192,21329]
===
match
---
name: airflow [1613,1620]
name: airflow [1613,1620]
===
match
---
name: dag_id [64338,64344]
name: dag_id [64841,64847]
===
match
---
trailer [51337,51342]
trailer [51840,51845]
===
match
---
atom_expr [10682,10702]
atom_expr [10682,10702]
===
match
---
trailer [37732,37737]
trailer [38235,38240]
===
match
---
simple_stmt [8766,8827]
simple_stmt [8766,8827]
===
match
---
name: TI [73717,73719]
name: TI [74220,74222]
===
match
---
name: int [36489,36492]
name: int [36992,36995]
===
match
---
name: selectinload [52063,52075]
name: selectinload [52566,52578]
===
match
---
trailer [73709,73716]
trailer [74212,74219]
===
match
---
name: filter_for_ti_state_change [49212,49238]
name: filter_for_ti_state_change [49715,49741]
===
match
---
name: timedelta [54125,54134]
name: timedelta [54628,54637]
===
match
---
trailer [7290,7304]
trailer [7290,7304]
===
match
---
name: execution_date [74353,74367]
name: execution_date [74856,74870]
===
match
---
atom_expr [57459,57635]
atom_expr [57962,58138]
===
match
---
string: "Marked %d SchedulerJob instances as failed" [79801,79845]
string: "Marked %d SchedulerJob instances as failed" [80304,80348]
===
match
---
atom_expr [74758,74831]
atom_expr [75261,75334]
===
match
---
operator: , [29414,29415]
operator: , [29668,29669]
===
match
---
trailer [38471,38477]
trailer [38974,38980]
===
match
---
operator: == [68008,68010]
operator: == [68511,68513]
===
match
---
name: email_content [20720,20733]
name: email_content [20720,20733]
===
match
---
name: timer [58073,58078]
name: timer [58576,58581]
===
match
---
atom [74148,74193]
atom [74651,74696]
===
match
---
name: query [38389,38394]
name: query [38892,38897]
===
match
---
name: using_sqlite [30411,30423]
name: using_sqlite [30665,30677]
===
match
---
name: remove [55374,55380]
name: remove [55877,55883]
===
match
---
trailer [31872,31879]
trailer [32375,32382]
===
match
---
name: dag [19173,19176]
name: dag [19173,19176]
===
match
---
atom_expr [59581,59610]
atom_expr [60084,60113]
===
match
---
argument [75392,75407]
argument [75895,75910]
===
match
---
name: SKIPPED [73867,73874]
name: SKIPPED [74370,74377]
===
match
---
trailer [16056,16062]
trailer [16056,16062]
===
match
---
operator: , [19207,19208]
operator: , [19207,19208]
===
match
---
trailer [52224,52240]
trailer [52727,52743]
===
match
---
simple_stmt [8578,8633]
simple_stmt [8578,8633]
===
match
---
trailer [58028,58037]
trailer [58531,58540]
===
match
---
param [29366,29371]
param [29620,29625]
===
match
---
atom_expr [60842,60856]
atom_expr [61345,61359]
===
match
---
trailer [57505,57514]
trailer [58008,58017]
===
match
---
name: num_runs [29424,29432]
name: num_runs [29678,29686]
===
match
---
name: Optional [3975,3983]
name: Optional [3975,3983]
===
match
---
trailer [51952,51967]
trailer [52455,52470]
===
match
---
name: dag_id [17733,17739]
name: dag_id [17733,17739]
===
match
---
name: session [34295,34302]
name: session [34798,34805]
===
match
---
trailer [23967,23978]
trailer [23967,23978]
===
match
---
operator: = [68821,68822]
operator: = [69324,69325]
===
match
---
trailer [18110,18114]
trailer [18110,18114]
===
match
---
operator: , [60528,60529]
operator: , [61031,61032]
===
match
---
name: task_instance [44853,44866]
name: task_instance [45356,45369]
===
match
---
name: info [47073,47077]
name: info [47576,47580]
===
match
---
atom_expr [23918,23945]
atom_expr [23918,23945]
===
match
---
trailer [10582,10589]
trailer [10582,10589]
===
match
---
trailer [52027,52031]
trailer [52530,52534]
===
match
---
simple_stmt [79883,79948]
simple_stmt [80386,80451]
===
match
---
name: dag_run [64171,64178]
name: dag_run [64674,64681]
===
match
---
simple_stmt [30272,30288]
simple_stmt [30526,30542]
===
match
---
trailer [17911,17930]
trailer [17911,17930]
===
match
---
simple_stmt [26706,26749]
simple_stmt [26706,26749]
===
match
---
operator: = [81230,81231]
operator: = [81733,81734]
===
match
---
atom_expr [39315,39345]
atom_expr [39818,39848]
===
match
---
parameters [23833,23902]
parameters [23833,23902]
===
match
---
atom_expr [49277,49286]
atom_expr [49780,49789]
===
match
---
trailer [35342,35350]
trailer [35845,35853]
===
match
---
name: dag_run [74177,74184]
name: dag_run [74680,74687]
===
match
---
name: state [24827,24832]
name: state [24827,24832]
===
match
---
atom_expr [55808,55834]
atom_expr [56311,56337]
===
match
---
atom_expr [55913,55985]
atom_expr [56416,56488]
===
match
---
dictorsetmaker [64171,64209]
dictorsetmaker [64674,64712]
===
match
---
name: TI [39023,39025]
name: TI [39526,39528]
===
match
---
operator: = [58034,58035]
operator: = [58537,58538]
===
match
---
testlist_star_expr [8766,8797]
testlist_star_expr [8766,8797]
===
match
---
except_clause [55407,55423]
except_clause [55910,55926]
===
match
---
number: 0 [33441,33442]
number: 0 [33944,33945]
===
match
---
simple_stmt [30464,30512]
simple_stmt [30718,30766]
===
match
---
name: dag_id [49280,49286]
name: dag_id [49783,49789]
===
match
---
name: filename [22110,22118]
name: filename [22110,22118]
===
match
---
atom_expr [73553,73748]
atom_expr [74056,74251]
===
match
---
suite [77892,78280]
suite [78395,78783]
===
match
---
name: next_dagrun [69518,69529]
name: next_dagrun [70021,70032]
===
match
---
name: self [59690,59694]
name: self [60193,60197]
===
match
---
if_stmt [74898,75345]
if_stmt [75401,75848]
===
match
---
operator: , [64344,64345]
operator: , [64847,64848]
===
match
---
simple_stmt [37718,37783]
simple_stmt [38221,38286]
===
match
---
fstring_end: ' [78234,78235]
fstring_end: ' [78737,78738]
===
match
---
trailer [45261,45312]
trailer [45764,45815]
===
match
---
name: Stats [70194,70199]
name: Stats [70697,70702]
===
match
---
term [31744,31752]
term [32247,32255]
===
match
---
tfpdef [29526,29556]
tfpdef [29780,29810]
===
match
---
string: 'sql_alchemy_conn' [30370,30388]
string: 'sql_alchemy_conn' [30624,30642]
===
match
---
atom_expr [16063,16073]
atom_expr [16063,16073]
===
match
---
atom_expr [18696,18725]
atom_expr [18696,18725]
===
match
---
name: provide_session [2869,2884]
name: provide_session [2869,2884]
===
match
---
not_test [74713,74744]
not_test [75216,75247]
===
match
---
trailer [23118,23148]
trailer [23118,23148]
===
match
---
arglist [73974,74034]
arglist [74477,74537]
===
match
---
funcdef [78306,78417]
funcdef [78809,78920]
===
match
---
name: o [71127,71128]
name: o [71630,71631]
===
match
---
trailer [68589,68597]
trailer [69092,69100]
===
match
---
trailer [4645,4664]
trailer [4645,4664]
===
match
---
name: super [15300,15305]
name: super [15300,15305]
===
match
---
atom_expr [30109,30138]
atom_expr [30363,30392]
===
match
---
atom_expr [13528,13575]
atom_expr [13528,13575]
===
match
---
name: State [71191,71196]
name: State [71694,71699]
===
match
---
argument [30720,30742]
argument [30974,30996]
===
match
---
name: execute_start_time [55324,55342]
name: execute_start_time [55827,55845]
===
match
---
dotted_name [1698,1731]
dotted_name [1698,1731]
===
match
---
trailer [45648,45655]
trailer [46151,46158]
===
match
---
atom [34948,35096]
atom [35451,35599]
===
match
---
argument [34440,34455]
argument [34943,34958]
===
match
---
arglist [19709,19744]
arglist [19709,19744]
===
match
---
expr_stmt [24824,24850]
expr_stmt [24824,24850]
===
match
---
name: _done [12371,12376]
name: _done [12371,12376]
===
match
---
name: end [55829,55832]
name: end [56332,56335]
===
match
---
name: dag [76592,76595]
name: dag [77095,77098]
===
match
---
trailer [71817,71824]
trailer [72320,72327]
===
match
---
name: join [50434,50438]
name: join [50937,50941]
===
match
---
trailer [33480,33486]
trailer [33983,33989]
===
match
---
trailer [77444,77450]
trailer [77947,77953]
===
match
---
operator: , [76102,76103]
operator: , [76605,76606]
===
match
---
trailer [71751,71761]
trailer [72254,72264]
===
match
---
operator: , [59610,59611]
operator: , [60113,60114]
===
match
---
name: filename [22205,22213]
name: filename [22205,22213]
===
match
---
operator: = [26519,26520]
operator: = [26519,26520]
===
match
---
operator: , [36950,36951]
operator: , [37453,37454]
===
match
---
name: self [37128,37132]
name: self [37631,37635]
===
match
---
expr_stmt [4945,4996]
expr_stmt [4945,4996]
===
match
---
name: session [2838,2845]
name: session [2838,2845]
===
match
---
name: TI [64151,64153]
name: TI [64654,64656]
===
match
---
simple_stmt [20430,20480]
simple_stmt [20430,20480]
===
match
---
name: contextlib [1001,1011]
name: contextlib [1001,1011]
===
match
---
trailer [46518,46979]
trailer [47021,47482]
===
match
---
name: subdir [30712,30718]
name: subdir [30966,30972]
===
match
---
trailer [33946,33952]
trailer [34449,34455]
===
match
---
atom_expr [48669,48736]
atom_expr [49172,49239]
===
match
---
name: task [16818,16822]
name: task [16818,16822]
===
match
---
trailer [64016,64105]
trailer [64519,64608]
===
match
---
trailer [32600,32602]
trailer [33103,33105]
===
match
---
atom_expr [51617,51634]
atom_expr [52120,52137]
===
match
---
operator: , [22548,22549]
operator: , [22548,22549]
===
match
---
name: TI [34291,34293]
name: TI [34794,34796]
===
match
---
atom_expr [74325,74335]
atom_expr [74828,74838]
===
match
---
operator: , [55224,55225]
operator: , [55727,55728]
===
match
---
name: TI [49560,49562]
name: TI [50063,50065]
===
match
---
name: with_row_locks [38973,38987]
name: with_row_locks [39476,39490]
===
match
---
if_stmt [51662,51771]
if_stmt [52165,52274]
===
match
---
name: new_state [34429,34438]
name: new_state [34932,34941]
===
match
---
trailer [71641,71649]
trailer [72144,72152]
===
match
---
suite [11865,11955]
suite [11865,11955]
===
match
---
operator: = [4930,4931]
operator: = [4930,4931]
===
match
---
trailer [74328,74335]
trailer [74831,74838]
===
match
---
name: not_ [38854,38858]
name: not_ [39357,39361]
===
match
---
name: active_runs_by_dag_id [63923,63944]
name: active_runs_by_dag_id [64426,64447]
===
match
---
simple_stmt [56532,57137]
simple_stmt [57035,57640]
===
match
---
name: result [36809,36815]
name: result [37312,37318]
===
match
---
annassign [17600,17777]
annassign [17600,17777]
===
match
---
trailer [35811,35817]
trailer [36314,36320]
===
match
---
operator: = [68387,68388]
operator: = [68890,68891]
===
match
---
name: currently_active_runs [72578,72599]
name: currently_active_runs [73081,73102]
===
match
---
trailer [12646,12651]
trailer [12646,12651]
===
match
---
name: sqlalchemy [1439,1449]
name: sqlalchemy [1439,1449]
===
match
---
string: 'num_runs' [29465,29475]
string: 'num_runs' [29719,29729]
===
match
---
trailer [68438,68453]
trailer [68941,68956]
===
match
---
name: log [59695,59698]
name: log [60198,60201]
===
match
---
operator: , [35431,35432]
operator: , [35934,35935]
===
match
---
name: incr [26712,26716]
name: incr [26712,26716]
===
match
---
fstring_expr [9129,9148]
fstring_expr [9129,9148]
===
match
---
trailer [38763,38769]
trailer [39266,39272]
===
match
---
arglist [45832,45965]
arglist [46335,46468]
===
match
---
name: utils [2675,2680]
name: utils [2675,2680]
===
match
---
name: guard [60370,60375]
name: guard [60873,60878]
===
match
---
name: bool [57260,57264]
name: bool [57763,57767]
===
match
---
operator: = [70135,70136]
operator: = [70638,70639]
===
match
---
name: conf [57267,57271]
name: conf [57770,57774]
===
match
---
raise_stmt [10365,10431]
raise_stmt [10365,10431]
===
match
---
name: DagFileProcessor [14435,14451]
name: DagFileProcessor [14435,14451]
===
match
---
operator: , [29516,29517]
operator: , [29770,29771]
===
match
---
name: Dict [1204,1208]
name: Dict [1204,1208]
===
match
---
name: TI [38538,38540]
name: TI [39041,39043]
===
match
---
name: processor_timeout_seconds [54014,54039]
name: processor_timeout_seconds [54517,54542]
===
match
---
trailer [49663,49670]
trailer [50166,50173]
===
match
---
arglist [71650,71683]
arglist [72153,72186]
===
match
---
name: str [40039,40042]
name: str [40542,40545]
===
match
---
name: call_regular_interval [57817,57838]
name: call_regular_interval [58320,58341]
===
match
---
simple_stmt [50015,50022]
simple_stmt [50518,50525]
===
match
---
name: file_path [9018,9027]
name: file_path [9018,9027]
===
match
---
atom_expr [16714,16731]
atom_expr [16714,16731]
===
match
---
trailer [16142,16191]
trailer [16142,16191]
===
match
---
param [35927,35932]
param [36430,36435]
===
match
---
name: airflow [2118,2125]
name: airflow [2118,2125]
===
match
---
atom_expr [33659,33700]
atom_expr [34162,34203]
===
match
---
simple_stmt [49212,49793]
simple_stmt [49715,50296]
===
match
---
string: 'max_tis_per_query' [30576,30595]
string: 'max_tis_per_query' [30830,30849]
===
match
---
name: int [4488,4491]
name: int [4488,4491]
===
match
---
arith_expr [73401,73439]
arith_expr [73904,73942]
===
match
---
if_stmt [15844,16020]
if_stmt [15844,16020]
===
match
---
simple_stmt [78377,78417]
simple_stmt [78880,78920]
===
match
---
name: task_instances_to_examine [39809,39834]
name: task_instances_to_examine [40312,40337]
===
match
---
simple_stmt [60976,61025]
simple_stmt [61479,61528]
===
match
---
operator: , [48912,48913]
operator: , [49415,49416]
===
match
---
trailer [50210,50220]
trailer [50713,50723]
===
match
---
trailer [53261,53266]
trailer [53764,53769]
===
match
---
operator: , [30718,30719]
operator: , [30972,30973]
===
match
---
trailer [74375,74390]
trailer [74878,74893]
===
match
---
trailer [65256,65266]
trailer [65759,65769]
===
match
---
string: 'Calling SLA miss callback' [19081,19108]
string: 'Calling SLA miss callback' [19081,19108]
===
match
---
parameters [3891,4051]
parameters [3891,4051]
===
match
---
name: log [42262,42265]
name: log [42765,42768]
===
match
---
argument [7761,7768]
argument [7761,7768]
===
match
---
name: dag [72421,72424]
name: dag [72924,72927]
===
match
---
operator: @ [11503,11504]
operator: @ [11503,11504]
===
match
---
name: currently_active_runs [74923,74944]
name: currently_active_runs [75426,75447]
===
match
---
trailer [13275,13284]
trailer [13275,13284]
===
match
---
name: session [50636,50643]
name: session [51139,51146]
===
match
---
not_test [11850,11864]
not_test [11850,11864]
===
match
---
argument [77933,77948]
argument [78436,78451]
===
match
---
atom_expr [66851,66890]
atom_expr [67354,67393]
===
match
---
trailer [55828,55832]
trailer [56331,56335]
===
match
---
exprlist [64396,64418]
exprlist [64899,64921]
===
match
---
simple_stmt [20256,20281]
simple_stmt [20256,20281]
===
match
---
trailer [50941,50958]
trailer [51444,51461]
===
match
---
operator: , [45075,45076]
operator: , [45578,45579]
===
match
---
name: pickle_id [46932,46941]
name: pickle_id [47435,47444]
===
match
---
name: loop_count [59641,59651]
name: loop_count [60144,60154]
===
match
---
name: pool_slots [44174,44184]
name: pool_slots [44677,44687]
===
match
---
fstring_string: \n<code></pre>             Blocking tasks:             <pre><code> [19565,19631]
fstring_string: \n<code></pre>             Blocking tasks:             <pre><code> [19565,19631]
===
match
---
argument [32367,32400]
argument [32870,32903]
===
match
---
trailer [80026,80034]
trailer [80529,80537]
===
match
---
name: filter [16512,16518]
name: filter [16512,16518]
===
match
---
operator: , [44071,44072]
operator: , [44574,44575]
===
match
---
tfpdef [21424,21438]
tfpdef [21424,21438]
===
match
---
simple_stmt [22271,22404]
simple_stmt [22271,22404]
===
match
---
operator: , [30574,30575]
operator: , [30828,30829]
===
match
---
trailer [76398,76404]
trailer [76901,76907]
===
match
---
suite [72004,72327]
suite [72507,72830]
===
match
---
name: import_errors [22236,22249]
name: import_errors [22236,22249]
===
match
---
name: task_instance [50294,50307]
name: task_instance [50797,50810]
===
match
---
trailer [12573,12577]
trailer [12573,12577]
===
match
---
fstring_expr [9242,9261]
fstring_expr [9242,9261]
===
match
---
name: TI [64234,64236]
name: TI [64737,64739]
===
match
---
name: pool_slots_free [38173,38188]
name: pool_slots_free [38676,38691]
===
match
---
expr_stmt [17896,17969]
expr_stmt [17896,17969]
===
match
---
trailer [15305,15307]
trailer [15305,15307]
===
match
---
trailer [16204,16211]
trailer [16204,16211]
===
match
---
name: with_row_locks [2981,2995]
name: with_row_locks [2981,2995]
===
match
---
string: "-" [31812,31815]
string: "-" [32315,32318]
===
match
---
atom_expr [31230,31298]
atom_expr [31607,31675]
===
match
---
simple_stmt [18491,18508]
simple_stmt [18491,18508]
===
match
---
name: session [43269,43276]
name: session [43772,43779]
===
match
---
name: dag [19151,19154]
name: dag [19151,19154]
===
match
---
name: task_id [24502,24509]
name: task_id [24502,24509]
===
match
---
operator: = [54448,54449]
operator: = [54951,54952]
===
match
---
name: current_dag_concurrency [42385,42408]
name: current_dag_concurrency [42888,42911]
===
match
---
operator: , [16854,16855]
operator: , [16854,16855]
===
match
---
simple_stmt [13271,13301]
simple_stmt [13271,13301]
===
match
---
name: blocking_tis [19215,19227]
name: blocking_tis [19215,19227]
===
match
---
name: ti [53202,53204]
name: ti [53705,53707]
===
match
---
simple_stmt [29207,29266]
simple_stmt [29461,29520]
===
match
---
name: debug [23022,23027]
name: debug [23022,23027]
===
match
---
operator: = [24734,24735]
operator: = [24734,24735]
===
match
---
name: BACKFILL_JOB [80763,80775]
name: BACKFILL_JOB [81266,81278]
===
match
---
testlist_comp [20529,20540]
testlist_comp [20529,20540]
===
match
---
operator: == [49325,49327]
operator: == [49828,49830]
===
match
---
atom_expr [39526,39581]
atom_expr [40029,40084]
===
match
---
trailer [57856,57865]
trailer [58359,58368]
===
match
---
suite [59961,60257]
suite [60464,60760]
===
match
---
simple_stmt [3078,3103]
simple_stmt [3078,3103]
===
match
---
name: query [38359,38364]
name: query [38862,38867]
===
match
---
trailer [16086,16101]
trailer [16086,16101]
===
match
---
name: Tuple [35985,35990]
name: Tuple [36488,36493]
===
match
---
trailer [72029,72034]
trailer [72532,72537]
===
match
---
trailer [4092,4103]
trailer [4092,4103]
===
match
---
atom_expr [23013,23071]
atom_expr [23013,23071]
===
match
---
param [4004,4045]
param [4004,4045]
===
match
---
trailer [38846,38853]
trailer [39349,39356]
===
match
---
operator: , [22336,22337]
operator: , [22336,22337]
===
match
---
exprlist [41398,41426]
exprlist [41901,41929]
===
match
---
operator: -> [5396,5398]
operator: -> [5396,5398]
===
match
---
operator: = [39046,39047]
operator: = [39549,39550]
===
match
---
operator: = [69623,69624]
operator: = [70126,70127]
===
match
---
arglist [23602,23736]
arglist [23602,23736]
===
match
---
name: dag_id [64041,64047]
name: dag_id [64544,64550]
===
match
---
name: in_ [33685,33688]
name: in_ [34188,34191]
===
match
---
name: List [46149,46153]
name: List [46652,46656]
===
match
---
operator: = [75416,75417]
operator: = [75919,75920]
===
match
---
operator: = [34247,34248]
operator: = [34750,34751]
===
match
---
name: List [3984,3988]
name: List [3984,3988]
===
match
---
name: self [11107,11111]
name: self [11107,11111]
===
match
---
atom_expr [73648,73665]
atom_expr [74151,74168]
===
match
---
arglist [16143,16190]
arglist [16143,16190]
===
match
---
atom_expr [32554,32567]
atom_expr [33057,33070]
===
match
---
name: queued_dttm [45860,45871]
name: queued_dttm [46363,46374]
===
match
---
operator: , [25197,25198]
operator: , [25197,25198]
===
match
---
name: log [55140,55143]
name: log [55643,55646]
===
match
---
arglist [71108,71312]
arglist [71611,71815]
===
match
---
trailer [80654,80659]
trailer [81157,81162]
===
match
---
atom_expr [44853,44877]
atom_expr [45356,45380]
===
match
---
name: multiprocessing [8715,8730]
name: multiprocessing [8715,8730]
===
match
---
string: "DAG '%s' not found in serialized_dag table" [71762,71806]
string: "DAG '%s' not found in serialized_dag table" [72265,72309]
===
match
---
trailer [52220,52224]
trailer [52723,52727]
===
match
---
name: str [30347,30350]
name: str [30601,30604]
===
match
---
trailer [23673,23683]
trailer [23673,23683]
===
match
---
parameters [15415,15456]
parameters [15415,15456]
===
match
---
operator: , [65171,65172]
operator: , [65674,65675]
===
match
---
operator: , [2302,2303]
operator: , [2302,2303]
===
match
---
atom_expr [77412,77418]
atom_expr [77915,77921]
===
match
---
trailer [11086,11094]
trailer [11086,11094]
===
match
---
name: append [44801,44807]
name: append [45304,45310]
===
match
---
trailer [73127,73160]
trailer [73630,73663]
===
match
---
name: dag_run [73310,73317]
name: dag_run [73813,73820]
===
match
---
argument [46626,46636]
argument [47129,47139]
===
match
---
suite [46476,47324]
suite [46979,47827]
===
match
---
name: read_dags_from_db [30720,30737]
name: read_dags_from_db [30974,30991]
===
match
---
trailer [80975,81017]
trailer [81478,81520]
===
match
---
simple_stmt [54770,54797]
simple_stmt [55273,55300]
===
match
---
trailer [6530,6551]
trailer [6530,6551]
===
match
---
trailer [35167,35173]
trailer [35670,35676]
===
match
---
name: WARN [7131,7135]
name: WARN [7131,7135]
===
match
---
tfpdef [24234,24262]
tfpdef [24234,24262]
===
match
---
trailer [10923,10925]
trailer [10923,10925]
===
match
---
name: utcnow [9350,9356]
name: utcnow [9350,9356]
===
match
---
name: num_starving_tasks_total [40389,40413]
name: num_starving_tasks_total [40892,40916]
===
match
---
name: priority_weight [41296,41311]
name: priority_weight [41799,41814]
===
match
---
simple_stmt [30605,30666]
simple_stmt [30859,30920]
===
match
---
trailer [24397,24404]
trailer [24397,24404]
===
match
---
name: serialized_dag [1964,1978]
name: serialized_dag [1964,1978]
===
match
---
atom_expr [20275,20280]
atom_expr [20275,20280]
===
match
---
atom_expr [10830,10888]
atom_expr [10830,10888]
===
match
---
operator: @ [56040,56041]
operator: @ [56543,56544]
===
match
---
for_stmt [78892,82625]
for_stmt [79395,83128]
===
match
---
trailer [34878,34887]
trailer [35381,35390]
===
match
---
name: mark_success [46654,46666]
name: mark_success [47157,47169]
===
match
---
atom_expr [18491,18507]
atom_expr [18491,18507]
===
match
---
funcdef [22455,23781]
funcdef [22455,23781]
===
match
---
name: SCHEDULED [69635,69644]
name: SCHEDULED [70138,70147]
===
match
---
name: self [20969,20973]
name: self [20969,20973]
===
match
---
simple_stmt [39590,39691]
simple_stmt [40093,40194]
===
match
---
atom_expr [19426,19436]
atom_expr [19426,19436]
===
match
---
name: int [29434,29437]
name: int [29688,29691]
===
match
---
comp_op [40702,40708]
comp_op [41205,41211]
===
match
---
operator: = [75547,75548]
operator: = [76050,76051]
===
match
---
name: _callback_requests [9172,9190]
name: _callback_requests [9172,9190]
===
match
---
if_stmt [11847,11955]
if_stmt [11847,11955]
===
match
---
trailer [64474,64478]
trailer [64977,64981]
===
match
---
name: filter_for_tis [50085,50099]
name: filter_for_tis [50588,50602]
===
match
---
trailer [51529,51537]
trailer [52032,52040]
===
match
---
name: callback_requests [4222,4239]
name: callback_requests [4222,4239]
===
match
---
operator: } [17023,17024]
operator: } [17023,17024]
===
match
---
atom_expr [8481,8503]
atom_expr [8481,8503]
===
match
---
string: ' on ' [18687,18693]
string: ' on ' [18687,18693]
===
match
---
trailer [51967,51989]
trailer [52470,52492]
===
match
---
trailer [80978,80985]
trailer [81481,81488]
===
match
---
trailer [29298,29338]
trailer [29552,29592]
===
match
---
name: self [47064,47068]
name: self [47567,47571]
===
match
---
name: request [53008,53015]
name: request [53511,53518]
===
match
---
atom_expr [51329,51649]
atom_expr [51832,52152]
===
match
---
name: dags [23322,23326]
name: dags [23322,23326]
===
match
---
name: self [23562,23566]
name: self [23562,23566]
===
match
---
name: int [36773,36776]
name: int [37276,37279]
===
match
---
name: provide_session [50581,50596]
name: provide_session [51084,51099]
===
match
---
operator: , [39054,39055]
operator: , [39557,39558]
===
match
---
atom [80064,81040]
atom [80567,81543]
===
match
---
name: full_filepath [23722,23735]
name: full_filepath [23722,23735]
===
match
---
operator: = [24139,24140]
operator: = [24139,24140]
===
match
---
name: priority_sorted_task_instances [41440,41470]
name: priority_sorted_task_instances [41943,41973]
===
match
---
name: log [43870,43873]
name: log [44373,44376]
===
match
---
atom_expr [4088,4103]
atom_expr [4088,4103]
===
match
---
atom_expr [14204,14220]
atom_expr [14204,14220]
===
match
---
simple_stmt [38069,38107]
simple_stmt [38572,38610]
===
match
---
trailer [24745,24754]
trailer [24745,24754]
===
match
---
simple_stmt [77374,77381]
simple_stmt [77877,77884]
===
match
---
atom_expr [11022,11039]
atom_expr [11022,11039]
===
match
---
name: session [18452,18459]
name: session [18452,18459]
===
match
---
trailer [54794,54796]
trailer [55297,55299]
===
match
---
name: try_number [51305,51315]
name: try_number [51808,51818]
===
match
---
simple_stmt [1493,1531]
simple_stmt [1493,1531]
===
match
---
trailer [35061,35070]
trailer [35564,35573]
===
match
---
name: Stats [26706,26711]
name: Stats [26706,26711]
===
match
---
name: MultiprocessingConnection [4903,4928]
name: MultiprocessingConnection [4903,4928]
===
match
---
param [76843,76888]
param [77346,77391]
===
match
---
trailer [17367,17440]
trailer [17367,17440]
===
match
---
name: self [30605,30609]
name: self [30859,30863]
===
match
---
atom_expr [79593,79619]
atom_expr [80096,80122]
===
match
---
operator: , [39098,39099]
operator: , [39601,39602]
===
match
---
name: self [54676,54680]
name: self [55179,55183]
===
match
---
if_stmt [10658,10703]
if_stmt [10658,10703]
===
match
---
name: external_trigger [71273,71289]
name: external_trigger [71776,71792]
===
match
---
name: dag [74865,74868]
name: dag [75368,75371]
===
match
---
name: in_ [16347,16350]
name: in_ [16347,16350]
===
match
---
arith_expr [79894,79934]
arith_expr [80397,80437]
===
match
---
trailer [68073,68085]
trailer [68576,68588]
===
match
---
suite [56262,56480]
suite [56765,56983]
===
match
---
name: get_dag [68590,68597]
name: get_dag [69093,69100]
===
match
---
trailer [12247,12263]
trailer [12247,12263]
===
match
---
simple_stmt [81794,81856]
simple_stmt [82297,82359]
===
match
---
for_stmt [51054,51771]
for_stmt [51557,52274]
===
match
---
operator: = [75604,75605]
operator: = [76107,76108]
===
match
---
name: dag_id [24335,24341]
name: dag_id [24335,24341]
===
match
---
trailer [17537,17539]
trailer [17537,17539]
===
match
---
suite [55118,55344]
suite [55621,55847]
===
match
---
operator: , [32769,32770]
operator: , [33272,33273]
===
match
---
and_test [16818,16866]
and_test [16818,16866]
===
match
---
if_stmt [67843,68363]
if_stmt [68346,68866]
===
match
---
trailer [22134,22141]
trailer [22134,22141]
===
match
---
name: __init__ [15225,15233]
name: __init__ [15225,15233]
===
match
---
operator: = [15449,15450]
operator: = [15449,15450]
===
match
---
name: TaskInstance [33538,33550]
name: TaskInstance [34041,34053]
===
match
---
operator: , [29310,29311]
operator: , [29564,29565]
===
match
---
name: self [10004,10008]
name: self [10004,10008]
===
match
---
trailer [23721,23735]
trailer [23721,23735]
===
match
---
atom_expr [44943,45010]
atom_expr [45446,45513]
===
match
---
trailer [24826,24832]
trailer [24826,24832]
===
match
---
suite [10948,11096]
suite [10948,11096]
===
match
---
name: gauge [35812,35817]
name: gauge [36315,36320]
===
match
---
operator: = [68576,68577]
operator: = [69079,69080]
===
match
---
simple_stmt [50820,50905]
simple_stmt [51323,51408]
===
match
---
name: debug [59082,59087]
name: debug [59585,59590]
===
match
---
operator: = [21228,21229]
operator: = [21228,21229]
===
match
---
trailer [10943,10947]
trailer [10943,10947]
===
match
---
atom_expr [15851,15905]
atom_expr [15851,15905]
===
match
---
atom_expr [65371,65385]
atom_expr [65874,65888]
===
match
---
suite [60393,60857]
suite [60896,61360]
===
match
---
parameters [67340,67396]
parameters [67843,67899]
===
match
---
trailer [17397,17404]
trailer [17397,17404]
===
match
---
operator: } [9147,9148]
operator: } [9147,9148]
===
match
---
name: errors [22300,22306]
name: errors [22300,22306]
===
match
---
name: self [30521,30525]
name: self [30775,30779]
===
match
---
simple_stmt [20969,21057]
simple_stmt [20969,21057]
===
match
---
trailer [73198,73202]
trailer [73701,73705]
===
match
---
atom_expr [24722,24733]
atom_expr [24722,24733]
===
match
---
atom_expr [15855,15884]
atom_expr [15855,15884]
===
match
---
operator: = [32383,32384]
operator: = [32886,32887]
===
match
---
atom_expr [52177,52191]
atom_expr [52680,52694]
===
match
---
operator: , [49592,49593]
operator: , [50095,50096]
===
match
---
comparison [18283,18309]
comparison [18283,18309]
===
match
---
name: self [13460,13464]
name: self [13460,13464]
===
match
---
simple_stmt [45631,45980]
simple_stmt [46134,46483]
===
match
---
number: 300.0 [57570,57575]
number: 300.0 [58073,58078]
===
match
---
atom_expr [38841,38887]
atom_expr [39344,39390]
===
match
---
atom_expr [31671,31753]
atom_expr [32174,32256]
===
match
---
name: self [71630,71634]
name: self [72133,72137]
===
match
---
trailer [34651,34657]
trailer [35154,35160]
===
match
---
param [14382,14386]
param [14382,14386]
===
match
---
name: dag_id [64396,64402]
name: dag_id [64899,64905]
===
match
---
name: ti [15866,15868]
name: ti [15866,15868]
===
match
---
name: or_ [16257,16260]
name: or_ [16257,16260]
===
match
---
name: ignore_task_deps [46775,46791]
name: ignore_task_deps [47278,47294]
===
match
---
trailer [46153,46157]
trailer [46656,46660]
===
match
---
operator: = [46791,46792]
operator: = [47294,47295]
===
match
---
name: task_instance_str [45322,45339]
name: task_instance_str [45825,45842]
===
match
---
trailer [16228,16235]
trailer [16228,16235]
===
match
---
suite [74745,74853]
suite [75248,75356]
===
match
---
atom_expr [69735,69752]
atom_expr [70238,70255]
===
match
---
name: state [52632,52637]
name: state [53135,53140]
===
match
---
param [76098,76103]
param [76601,76606]
===
match
---
number: 0 [66615,66616]
number: 0 [67118,67119]
===
match
---
trailer [76305,76312]
trailer [76808,76815]
===
match
---
argument [17406,17425]
argument [17406,17425]
===
match
---
trailer [18459,18466]
trailer [18459,18466]
===
match
---
operator: , [77857,77858]
operator: , [78360,78361]
===
match
---
expr_stmt [41203,41345]
expr_stmt [41706,41848]
===
match
---
trailer [52054,52062]
trailer [52557,52565]
===
match
---
simple_stmt [16029,16438]
simple_stmt [16029,16438]
===
match
---
sync_comp_for [49698,49782]
sync_comp_for [50201,50285]
===
match
---
name: flush [82511,82516]
name: flush [83014,83019]
===
match
---
trailer [78101,78161]
trailer [78604,78664]
===
match
---
name: info [53212,53216]
name: info [53715,53719]
===
match
---
name: conf [30353,30357]
name: conf [30607,30611]
===
match
---
trailer [35605,35609]
trailer [36108,36112]
===
match
---
operator: , [51576,51577]
operator: , [52079,52080]
===
match
---
trailer [49819,49825]
trailer [50322,50328]
===
match
---
name: max_active_runs [71942,71957]
name: max_active_runs [72445,72460]
===
match
---
name: TI [16143,16145]
name: TI [16143,16145]
===
match
---
arglist [45041,45095]
arglist [45544,45598]
===
match
---
sync_comp_for [50447,50479]
sync_comp_for [50950,50982]
===
match
---
operator: } [34744,34745]
operator: } [35247,35248]
===
match
---
name: utcnow [45882,45888]
name: utcnow [46385,46391]
===
match
---
name: self [4556,4560]
name: self [4556,4560]
===
match
---
operator: , [50873,50874]
operator: , [51376,51377]
===
match
---
trailer [71011,71392]
trailer [71514,71895]
===
match
---
trailer [79695,79702]
trailer [80198,80205]
===
match
---
expr_stmt [40006,40048]
expr_stmt [40509,40551]
===
match
---
argument [40206,40235]
argument [40709,40738]
===
match
---
name: commit [65377,65383]
name: commit [65880,65886]
===
match
---
return_stmt [73275,73283]
return_stmt [73778,73786]
===
match
---
name: processor_agent [54183,54198]
name: processor_agent [54686,54701]
===
match
---
name: time [59566,59570]
name: time [60069,60073]
===
match
---
name: sigkill [10050,10057]
name: sigkill [10050,10057]
===
match
---
trailer [82510,82516]
trailer [83013,83019]
===
match
---
simple_stmt [42257,42471]
simple_stmt [42760,42974]
===
match
---
operator: , [52270,52271]
operator: , [52773,52774]
===
match
---
operator: = [30549,30550]
operator: = [30803,30804]
===
match
---
name: session [37766,37773]
name: session [38269,38276]
===
match
---
name: self [31798,31802]
name: self [32301,32305]
===
match
---
suite [64532,65358]
suite [65035,65861]
===
match
---
atom_expr [71039,71052]
atom_expr [71542,71555]
===
match
---
string: 'core' [54059,54065]
string: 'core' [54562,54568]
===
match
---
trailer [11858,11864]
trailer [11858,11864]
===
match
---
comparison [32540,32567]
comparison [33043,33070]
===
match
---
for_stmt [46451,47324]
for_stmt [46954,47827]
===
match
---
trailer [9294,9303]
trailer [9294,9303]
===
match
---
operator: , [60685,60686]
operator: , [61188,61189]
===
match
---
simple_stmt [38359,38699]
simple_stmt [38862,39202]
===
match
---
with_item [58056,58078]
with_item [58559,58581]
===
match
---
trailer [23302,23314]
trailer [23302,23314]
===
match
---
name: join [80655,80659]
name: join [81158,81162]
===
match
---
operator: { [16991,16992]
operator: { [16991,16992]
===
match
---
name: self [52944,52948]
name: self [53447,53451]
===
match
---
decorator [13701,13711]
decorator [13701,13711]
===
match
---
name: wait [10590,10594]
name: wait [10590,10594]
===
match
---
name: ImportError [22071,22082]
name: ImportError [22071,22082]
===
match
---
trailer [8812,8826]
trailer [8812,8826]
===
match
---
if_stmt [9901,9996]
if_stmt [9901,9996]
===
match
---
name: session [66072,66079]
name: session [66575,66582]
===
match
---
trailer [30445,30455]
trailer [30699,30709]
===
match
---
atom_expr [77465,77547]
atom_expr [77968,78050]
===
match
---
dotted_name [1439,1461]
dotted_name [1439,1461]
===
match
---
tfpdef [29380,29391]
tfpdef [29634,29645]
===
match
---
trailer [7576,7578]
trailer [7576,7578]
===
match
---
comparison [74666,74708]
comparison [75169,75211]
===
match
---
name: os [11053,11055]
name: os [11053,11055]
===
match
---
arglist [77749,77793]
arglist [78252,78296]
===
match
---
atom_expr [10533,10555]
atom_expr [10533,10555]
===
match
---
name: self [30174,30178]
name: self [30428,30432]
===
match
---
simple_stmt [47172,47324]
simple_stmt [47675,47827]
===
match
---
trailer [25133,25139]
trailer [25133,25139]
===
match
---
trailer [78068,78076]
trailer [78571,78579]
===
match
---
trailer [73716,73748]
trailer [74219,74251]
===
match
---
operator: , [4044,4045]
operator: , [4044,4045]
===
match
---
name: execution_date [41316,41330]
name: execution_date [41819,41833]
===
match
---
operator: = [46631,46632]
operator: = [47134,47135]
===
match
---
string: 'pool_metrics_interval' [57714,57737]
string: 'pool_metrics_interval' [58217,58240]
===
match
---
trailer [33599,33606]
trailer [34102,34109]
===
match
---
if_stmt [66356,66617]
if_stmt [66859,67120]
===
match
---
arglist [76009,76033]
arglist [76512,76536]
===
match
---
name: conf [57687,57691]
name: conf [58190,58194]
===
match
---
name: task_instance [73905,73918]
name: task_instance [74408,74421]
===
match
---
atom_expr [49353,49370]
atom_expr [49856,49873]
===
match
---
simple_stmt [5052,5075]
simple_stmt [5052,5075]
===
match
---
trailer [16511,16518]
trailer [16511,16518]
===
match
---
trailer [76478,76485]
trailer [76981,76988]
===
match
---
trailer [3988,3993]
trailer [3988,3993]
===
match
---
name: get_dagrun [23968,23978]
name: get_dagrun [23968,23978]
===
match
---
atom [33459,34005]
atom [33962,34508]
===
match
---
trailer [78938,78942]
trailer [79441,79445]
===
match
---
trailer [58829,58839]
trailer [59332,59342]
===
match
---
simple_stmt [50133,50281]
simple_stmt [50636,50784]
===
match
---
name: _kill_process [10687,10700]
name: _kill_process [10687,10700]
===
match
---
string: "from DAG %s is >= to the DAG's task concurrency limit of %s" [42687,42748]
string: "from DAG %s is >= to the DAG's task concurrency limit of %s" [43190,43251]
===
match
---
name: dag_model [72285,72294]
name: dag_model [72788,72797]
===
match
---
param [48908,48913]
param [49411,49416]
===
match
---
operator: - [79591,79592]
operator: - [80094,80095]
===
match
---
trailer [27204,27215]
trailer [27204,27215]
===
match
---
name: session [76121,76128]
name: session [76624,76631]
===
match
---
operator: == [80889,80891]
operator: == [81392,81394]
===
match
---
name: repr [45354,45358]
name: repr [45857,45861]
===
match
---
trailer [76915,76931]
trailer [77418,77434]
===
match
---
trailer [68260,68275]
trailer [68763,68778]
===
match
---
atom_expr [20440,20479]
atom_expr [20440,20479]
===
match
---
trailer [77479,77547]
trailer [77982,78050]
===
match
---
expr_stmt [81571,81592]
expr_stmt [82074,82095]
===
match
---
name: bool [31891,31895]
name: bool [32394,32398]
===
match
---
atom_expr [70194,70332]
atom_expr [70697,70835]
===
match
---
funcdef [66732,66891]
funcdef [67235,67394]
===
match
---
name: task_concurrency_map [44943,44963]
name: task_concurrency_map [45446,45466]
===
match
---
operator: -> [56235,56237]
operator: -> [56738,56740]
===
match
---
operator: { [19631,19632]
operator: { [19631,19632]
===
match
---
name: int [72660,72663]
name: int [73163,73166]
===
match
---
name: pools [38758,38763]
name: pools [39261,39266]
===
match
---
name: state [64237,64242]
name: state [64740,64745]
===
match
---
simple_stmt [23764,23781]
simple_stmt [23764,23781]
===
match
---
atom_expr [7666,7677]
atom_expr [7666,7677]
===
match
---
string: "Tried to call retcode before process was finished!" [11901,11953]
string: "Tried to call retcode before process was finished!" [11901,11953]
===
match
---
expr_stmt [42064,42093]
expr_stmt [42567,42596]
===
match
---
name: TaskInstance [35312,35324]
name: TaskInstance [35815,35827]
===
match
---
name: _start_time [14209,14220]
name: _start_time [14209,14220]
===
match
---
string: "%s tasks up for execution:\n\t%s" [39604,39638]
string: "%s tasks up for execution:\n\t%s" [40107,40141]
===
match
---
simple_stmt [46176,46411]
simple_stmt [46679,46914]
===
match
---
trailer [64249,64289]
trailer [64752,64792]
===
match
---
atom_expr [72230,72249]
atom_expr [72733,72752]
===
match
---
name: dag_concurrency_limit [42845,42866]
name: dag_concurrency_limit [43348,43369]
===
match
---
trailer [68461,68484]
trailer [68964,68987]
===
match
---
operator: = [82043,82044]
operator: = [82546,82547]
===
match
---
simple_stmt [81331,81404]
simple_stmt [81834,81907]
===
match
---
name: self [13528,13532]
name: self [13528,13532]
===
match
---
name: executor [48528,48536]
name: executor [49031,49039]
===
match
---
atom_expr [23930,23944]
atom_expr [23930,23944]
===
match
---
atom_expr [46942,46964]
atom_expr [47445,47467]
===
match
---
trailer [49836,49870]
trailer [50339,50373]
===
match
---
operator: , [35489,35490]
operator: , [35992,35993]
===
match
---
suite [40715,40840]
suite [41218,41343]
===
match
---
atom_expr [20969,21056]
atom_expr [20969,21056]
===
match
---
operator: { [17011,17012]
operator: { [17011,17012]
===
match
---
name: task_instance [73779,73792]
name: task_instance [74282,74295]
===
match
---
trailer [38467,38471]
trailer [38970,38974]
===
match
---
name: dag_id [71129,71135]
name: dag_id [71632,71638]
===
match
---
name: kill [11056,11060]
name: kill [11056,11060]
===
match
---
name: state [33679,33684]
name: state [34182,34187]
===
match
---
trailer [40956,41189]
trailer [41459,41692]
===
match
---
name: num_queued_tis [66001,66015]
name: num_queued_tis [66504,66518]
===
match
---
name: callback [77160,77168]
name: callback [77663,77671]
===
match
---
atom_expr [34249,34362]
atom_expr [34752,34865]
===
match
---
name: dagbag [27198,27204]
name: dagbag [27198,27204]
===
match
---
operator: , [60805,60806]
operator: , [61308,61309]
===
match
---
comparison [43548,43582]
comparison [44051,44085]
===
match
---
trailer [69750,69752]
trailer [70253,70255]
===
match
---
name: getboolean [15179,15189]
name: getboolean [15179,15189]
===
match
---
arglist [43912,44072]
arglist [44415,44575]
===
match
---
operator: = [78500,78501]
operator: = [79003,79004]
===
match
---
operator: = [48521,48522]
operator: = [49024,49025]
===
match
---
atom_expr [68071,68085]
atom_expr [68574,68588]
===
match
---
name: incr [78383,78387]
name: incr [78886,78890]
===
match
---
trailer [31026,31038]
trailer [31280,31292]
===
match
---
operator: -> [70635,70637]
operator: -> [71138,71140]
===
match
---
operator: { [34948,34949]
operator: { [35451,35452]
===
match
---
name: dagbag [22229,22235]
name: dagbag [22229,22235]
===
match
---
simple_stmt [65371,65386]
simple_stmt [65874,65889]
===
match
---
name: airflow [3001,3008]
name: airflow [3001,3008]
===
match
---
name: task_id [19892,19899]
name: task_id [19892,19899]
===
match
---
name: type [8881,8885]
name: type [8881,8885]
===
match
---
name: _pickle_dags [9050,9062]
name: _pickle_dags [9050,9062]
===
match
---
import_from [1608,1692]
import_from [1608,1692]
===
match
---
comp_op [75012,75018]
comp_op [75515,75521]
===
match
---
name: _critical_section_execute_task_instances [47333,47373]
name: _critical_section_execute_task_instances [47836,47876]
===
match
---
param [30791,30795]
param [31045,31049]
===
match
---
operator: , [20675,20676]
operator: , [20675,20676]
===
match
---
operator: , [26437,26438]
operator: , [26437,26438]
===
match
---
name: queued_by_job_id [81620,81636]
name: queued_by_job_id [82123,82139]
===
match
---
not_test [77393,77451]
not_test [77896,77954]
===
match
---
name: log [19365,19368]
name: log [19365,19368]
===
match
---
trailer [9739,9755]
trailer [9739,9755]
===
match
---
name: dag [19426,19429]
name: dag [19426,19429]
===
match
---
arglist [72056,72250]
arglist [72559,72753]
===
match
---
name: get_email_address_list [2483,2505]
name: get_email_address_list [2483,2505]
===
match
---
expr_stmt [19450,19762]
expr_stmt [19450,19762]
===
match
---
name: concurrency [42229,42240]
name: concurrency [42732,42743]
===
match
---
name: _create_dagruns_for_dags [66926,66950]
name: _create_dagruns_for_dags [67429,67453]
===
match
---
trailer [71064,71069]
trailer [71567,71572]
===
match
---
dotted_name [3001,3020]
dotted_name [3001,3020]
===
match
---
name: task_id [49317,49324]
name: task_id [49820,49827]
===
match
---
simple_stmt [49879,49963]
simple_stmt [50382,50466]
===
match
---
name: info [52494,52498]
name: info [52997,53001]
===
match
---
trailer [19878,19887]
trailer [19878,19887]
===
match
---
trailer [53537,53563]
trailer [54040,54066]
===
match
---
simple_stmt [40943,41190]
simple_stmt [41446,41693]
===
match
---
atom_expr [57413,57449]
atom_expr [57916,57952]
===
match
---
operator: = [9339,9340]
operator: = [9339,9340]
===
match
---
name: active_runs_by_dag_id [64445,64466]
name: active_runs_by_dag_id [64948,64969]
===
match
---
trailer [55365,55373]
trailer [55868,55876]
===
match
---
decorated [11503,11993]
decorated [11503,11993]
===
match
---
name: DagModel [67097,67105]
name: DagModel [67600,67608]
===
match
---
name: dag_runs [64523,64531]
name: dag_runs [65026,65034]
===
match
---
name: len [27062,27065]
name: len [27062,27065]
===
match
---
name: processor_agent [76916,76931]
name: processor_agent [77419,77434]
===
match
---
name: log [39595,39598]
name: log [40098,40101]
===
match
---
suite [22037,22144]
suite [22037,22144]
===
match
---
try_stmt [71603,71851]
try_stmt [72106,72354]
===
match
---
name: log [15370,15373]
name: log [15370,15373]
===
match
---
argument [37766,37781]
argument [38269,38284]
===
match
---
trailer [49956,49960]
trailer [50459,50463]
===
match
---
trailer [23247,23276]
trailer [23247,23276]
===
match
---
operator: , [53158,53159]
operator: , [53661,53662]
===
match
---
name: str [25218,25221]
name: str [25218,25221]
===
match
---
suite [15465,21358]
suite [15465,21358]
===
match
---
trailer [7668,7675]
trailer [7668,7675]
===
match
---
name: DM [3122,3124]
name: DM [3122,3124]
===
match
---
operator: , [56432,56433]
operator: , [56935,56936]
===
match
---
operator: , [46836,46837]
operator: , [47339,47340]
===
match
---
sync_comp_for [27386,27456]
sync_comp_for [27386,27456]
===
match
---
name: warning [26930,26937]
name: warning [26930,26937]
===
match
---
trailer [13502,13508]
trailer [13502,13508]
===
match
---
simple_stmt [61194,62755]
simple_stmt [61697,63258]
===
match
---
if_stmt [44157,44769]
if_stmt [44660,45272]
===
match
---
atom_expr [30464,30480]
atom_expr [30718,30734]
===
match
---
operator: = [78933,78934]
operator: = [79436,79437]
===
match
---
trailer [80897,80905]
trailer [81400,81408]
===
match
---
name: SlaMiss [1846,1853]
name: SlaMiss [1846,1853]
===
match
---
name: async_mode [54502,54512]
name: async_mode [55005,55015]
===
match
---
argument [58029,58036]
argument [58532,58539]
===
match
---
name: file_path [7679,7688]
name: file_path [7679,7688]
===
match
---
comparison [68046,68085]
comparison [68549,68588]
===
match
---
name: session [48914,48921]
name: session [49417,49424]
===
match
---
name: BaseJob [1796,1803]
name: BaseJob [1796,1803]
===
match
---
classdef [14429,27840]
classdef [14429,27840]
===
match
---
operator: , [1319,1320]
operator: , [1319,1320]
===
match
---
name: _exit_gracefully [31049,31065]
name: _exit_gracefully [31303,31319]
===
match
---
name: retries [2746,2753]
name: retries [2746,2753]
===
match
---
name: timer [65872,65877]
name: timer [66375,66380]
===
match
---
trailer [15362,15367]
trailer [15362,15367]
===
match
---
atom_expr [30900,30921]
atom_expr [31154,31175]
===
match
---
name: debug [76399,76404]
name: debug [76902,76907]
===
match
---
trailer [56357,56479]
trailer [56860,56982]
===
match
---
trailer [55254,55256]
trailer [55757,55759]
===
match
---
operator: , [25359,25360]
operator: , [25359,25360]
===
match
---
atom_expr [54341,54378]
atom_expr [54844,54881]
===
match
---
operator: , [2063,2064]
operator: , [2063,2064]
===
match
---
atom_expr [25131,25139]
atom_expr [25131,25139]
===
match
---
name: all [68485,68488]
name: all [68988,68991]
===
match
---
name: latest_version [76362,76376]
name: latest_version [76865,76879]
===
match
---
name: values [38012,38018]
name: values [38515,38521]
===
match
---
simple_stmt [44760,44769]
simple_stmt [45263,45272]
===
match
---
try_stmt [31484,31662]
try_stmt [31987,32165]
===
match
---
name: task_map [36934,36942]
name: task_map [37437,37445]
===
match
---
operator: , [72649,72650]
operator: , [73152,73153]
===
match
---
name: DagRun [71108,71114]
name: DagRun [71611,71617]
===
match
---
operator: = [77782,77783]
operator: = [78285,78286]
===
match
---
atom_expr [46591,46608]
atom_expr [47094,47111]
===
match
---
name: queued_tasks [50362,50374]
name: queued_tasks [50865,50877]
===
match
---
atom_expr [73310,73328]
atom_expr [73813,73831]
===
match
---
expr_stmt [38897,38925]
expr_stmt [39400,39428]
===
match
---
name: timezone [9341,9349]
name: timezone [9341,9349]
===
match
---
name: to_reset [82645,82653]
name: to_reset [83148,83156]
===
match
---
name: models [3127,3133]
name: models [3127,3133]
===
match
---
name: priority [47262,47270]
name: priority [47765,47773]
===
match
---
simple_stmt [76945,76997]
simple_stmt [77448,77500]
===
match
---
name: query [33451,33456]
name: query [33954,33959]
===
match
---
trailer [17530,17537]
trailer [17530,17537]
===
match
---
simple_stmt [26761,26773]
simple_stmt [26761,26773]
===
match
---
trailer [57700,57752]
trailer [58203,58255]
===
match
---
atom_expr [19151,19228]
atom_expr [19151,19228]
===
match
---
name: _update_dag_next_dagruns [70347,70371]
name: _update_dag_next_dagruns [70850,70874]
===
match
---
import_as_names [2045,2080]
import_as_names [2045,2080]
===
match
---
name: DagCallbackRequest [2284,2302]
name: DagCallbackRequest [2284,2302]
===
match
---
trailer [36755,36777]
trailer [37258,37280]
===
match
---
string: 'scheduler' [30563,30574]
string: 'scheduler' [30817,30828]
===
match
---
trailer [33586,33599]
trailer [34089,34102]
===
match
---
simple_stmt [35601,35794]
simple_stmt [36104,36297]
===
match
---
name: log [59983,59986]
name: log [60486,60489]
===
match
---
name: self [58454,58458]
name: self [58957,58961]
===
match
---
trailer [45000,45008]
trailer [45503,45511]
===
match
---
name: getint [78827,78833]
name: getint [79330,79336]
===
match
---
trailer [68052,68067]
trailer [68555,68570]
===
match
---
name: request [24234,24241]
name: request [24234,24241]
===
match
---
name: processor_timeout [54410,54427]
name: processor_timeout [54913,54930]
===
match
---
trailer [71121,71125]
trailer [71624,71628]
===
match
---
operator: , [3905,3906]
operator: , [3905,3906]
===
match
---
name: self [12476,12480]
name: self [12476,12480]
===
match
---
expr_stmt [75514,75611]
expr_stmt [76017,76114]
===
match
---
operator: , [64212,64213]
operator: , [64715,64716]
===
match
---
param [60313,60318]
param [60816,60821]
===
match
---
name: query [39001,39006]
name: query [39504,39509]
===
match
---
operator: = [18960,18961]
operator: = [18960,18961]
===
match
---
testlist_comp [51675,51716]
testlist_comp [52178,52219]
===
match
---
name: msg [53180,53183]
name: msg [53683,53686]
===
match
---
trailer [72441,72502]
trailer [72944,73005]
===
match
---
trailer [64178,64185]
trailer [64681,64688]
===
match
---
name: _clean_tis_without_dagrun [60287,60312]
name: _clean_tis_without_dagrun [60790,60815]
===
match
---
simple_stmt [45250,45313]
simple_stmt [45753,45816]
===
match
---
simple_stmt [70342,70393]
simple_stmt [70845,70896]
===
match
---
trailer [53439,53448]
trailer [53942,53951]
===
match
---
operator: = [60483,60484]
operator: = [60986,60987]
===
match
---
name: dag [77076,77079]
name: dag [77579,77582]
===
match
---
operator: = [54283,54284]
operator: = [54786,54787]
===
match
---
name: ti_key [51298,51304]
name: ti_key [51801,51807]
===
match
---
atom_expr [32584,32643]
atom_expr [33087,33146]
===
match
---
simple_stmt [4196,4240]
simple_stmt [4196,4240]
===
match
---
arglist [25079,25139]
arglist [25079,25139]
===
match
---
trailer [30965,30982]
trailer [31219,31236]
===
match
---
atom [38367,38698]
atom [38870,39201]
===
match
---
string: " this task has been reached." [43994,44024]
string: " this task has been reached." [44497,44527]
===
match
---
name: open_slots [44489,44499]
name: open_slots [44992,45002]
===
match
---
atom_expr [68011,68020]
atom_expr [68514,68523]
===
match
---
string: "Not scheduling since there are %s open slots in pool %s" [41543,41600]
string: "Not scheduling since there are %s open slots in pool %s" [42046,42103]
===
match
---
simple_stmt [58358,58434]
simple_stmt [58861,58937]
===
match
---
name: self [78934,78938]
name: self [79437,79441]
===
match
---
string: "No viable dags retrieved from %s" [26938,26972]
string: "No viable dags retrieved from %s" [26938,26972]
===
match
---
name: Session [55366,55373]
name: Session [55869,55876]
===
match
---
atom_expr [53987,54004]
atom_expr [54490,54507]
===
match
---
name: __class__ [79899,79908]
name: __class__ [80402,80411]
===
match
---
string: "exited with status %s for try_number %s" [51433,51474]
string: "exited with status %s for try_number %s" [51936,51977]
===
match
---
atom_expr [7123,7135]
atom_expr [7123,7135]
===
match
---
operator: = [22347,22348]
operator: = [22347,22348]
===
match
---
trailer [4560,4566]
trailer [4560,4566]
===
match
---
name: self [57152,57156]
name: self [57655,57659]
===
match
---
trailer [22070,22082]
trailer [22070,22082]
===
match
---
name: jobs [1775,1779]
name: jobs [1775,1779]
===
match
---
atom_expr [18533,18613]
atom_expr [18533,18613]
===
match
---
operator: = [21283,21284]
operator: = [21283,21284]
===
match
---
name: self [67144,67148]
name: self [67647,67651]
===
match
---
name: new_state [34860,34869]
name: new_state [35363,35372]
===
match
---
tfpdef [15422,15430]
tfpdef [15422,15430]
===
match
---
param [67341,67346]
param [67844,67849]
===
match
---
operator: , [1218,1219]
operator: , [1218,1219]
===
match
---
name: suppress [10533,10541]
name: suppress [10533,10541]
===
match
---
name: pop [50375,50378]
name: pop [50878,50881]
===
match
---
not_test [49974,50001]
not_test [50477,50504]
===
match
---
name: gauge [45186,45191]
name: gauge [45689,45694]
===
match
---
suite [65227,65358]
suite [65730,65861]
===
match
---
name: _send_dag_callbacks_to_processor [76778,76810]
name: _send_dag_callbacks_to_processor [77281,77313]
===
match
---
trailer [73470,73480]
trailer [73973,73983]
===
match
---
name: parent_channel [6815,6829]
name: parent_channel [6815,6829]
===
match
---
name: State [73481,73486]
name: State [73984,73989]
===
match
---
name: info [40952,40956]
name: info [41455,41459]
===
match
---
operator: % [53188,53189]
operator: % [53691,53692]
===
match
---
comparison [32247,32275]
comparison [32750,32778]
===
match
---
operator: , [16559,16560]
operator: , [16559,16560]
===
match
---
atom_expr [60918,60954]
atom_expr [61421,61457]
===
match
---
trailer [45678,45979]
trailer [46181,46482]
===
match
---
name: dag_run [76584,76591]
name: dag_run [77087,77094]
===
match
---
atom_expr [12491,12518]
atom_expr [12491,12518]
===
match
---
operator: { [29225,29226]
operator: { [29479,29480]
===
match
---
param [24234,24262]
param [24234,24262]
===
match
---
arglist [52959,52989]
arglist [53462,53492]
===
match
---
atom_expr [72158,72168]
atom_expr [72661,72671]
===
match
---
comparison [14204,14228]
comparison [14204,14228]
===
match
---
operator: , [75407,75408]
operator: , [75910,75911]
===
match
---
name: warning [10970,10977]
name: warning [10970,10977]
===
match
---
trailer [38481,38490]
trailer [38984,38993]
===
match
---
name: state [53195,53200]
name: state [53698,53703]
===
match
---
atom_expr [73247,73261]
atom_expr [73750,73764]
===
match
---
string: 'scheduler_health_check_threshold' [32475,32509]
string: 'scheduler_health_check_threshold' [32978,33012]
===
match
---
atom_expr [37981,37993]
atom_expr [38484,38496]
===
match
---
operator: + [64271,64272]
operator: + [64774,64775]
===
match
---
operator: = [39089,39090]
operator: = [39592,39593]
===
match
---
operator: , [17709,17710]
operator: , [17709,17710]
===
match
---
name: request [24104,24111]
name: request [24104,24111]
===
match
---
operator: = [52012,52013]
operator: = [52515,52516]
===
match
---
name: simple_ti [24685,24694]
name: simple_ti [24685,24694]
===
match
---
trailer [64337,64344]
trailer [64840,64847]
===
match
---
atom_expr [33580,33637]
atom_expr [34083,34140]
===
match
---
name: task [20582,20586]
name: task [20582,20586]
===
match
---
name: self [9788,9792]
name: self [9788,9792]
===
match
---
trailer [52093,52095]
trailer [52596,52598]
===
match
---
simple_stmt [48948,49141]
simple_stmt [49451,49644]
===
match
---
name: poll [12435,12439]
name: poll [12435,12439]
===
match
---
operator: , [35751,35752]
operator: , [36254,36255]
===
match
---
name: min [38160,38163]
name: min [38663,38666]
===
match
---
name: following_schedule [17083,17101]
name: following_schedule [17083,17101]
===
match
---
simple_stmt [45395,45482]
simple_stmt [45898,45985]
===
match
---
name: List [27352,27356]
name: List [27352,27356]
===
match
---
name: update [34920,34926]
name: update [35423,35429]
===
match
---
name: dag [18140,18143]
name: dag [18140,18143]
===
match
---
trailer [57673,57800]
trailer [58176,58303]
===
match
---
trailer [62964,62980]
trailer [63467,63483]
===
match
---
funcdef [31403,31822]
funcdef [31780,32325]
===
match
---
arglist [26644,26692]
arglist [26644,26692]
===
match
---
trailer [78195,78201]
trailer [78698,78704]
===
match
---
name: file_path [7875,7884]
name: file_path [7875,7884]
===
match
---
sync_comp_for [15885,15904]
sync_comp_for [15885,15904]
===
match
---
name: filter [18059,18065]
name: filter [18059,18065]
===
match
---
atom_expr [57766,57789]
atom_expr [58269,58292]
===
match
---
trailer [74952,74968]
trailer [75455,75471]
===
match
---
operator: , [27812,27813]
operator: , [27812,27813]
===
match
---
comparison [11738,11759]
comparison [11738,11759]
===
match
---
name: dag_id [77776,77782]
name: dag_id [78279,78285]
===
match
---
string: """         Get the concurrency maps.          :param states: List of states to query for         :type states: list[airflow.utils.state.State]         :return: A map from (dag_id, task_id) to # of task instances and          a map from (dag_id, task_id) to # of task instances in the given state list         :rtype: tuple[dict[str, int], dict[tuple[str, str], int]]         """ [36058,36437]
string: """         Get the concurrency maps.          :param states: List of states to query for         :type states: list[airflow.utils.state.State]         :return: A map from (dag_id, task_id) to # of task instances and          a map from (dag_id, task_id) to # of task instances in the given state list         :rtype: tuple[dict[str, int], dict[tuple[str, str], int]]         """ [36561,36940]
===
match
---
atom_expr [32605,32626]
atom_expr [33108,33129]
===
match
---
trailer [20987,21056]
trailer [20987,21056]
===
match
---
trailer [13473,13482]
trailer [13473,13482]
===
match
---
trailer [43013,43023]
trailer [43516,43526]
===
match
---
name: self [53663,53667]
name: self [54166,54170]
===
match
---
simple_stmt [54561,54592]
simple_stmt [55064,55095]
===
match
---
name: DefaultDict [36014,36025]
name: DefaultDict [36517,36528]
===
match
---
name: DagRun [72562,72568]
name: DagRun [73065,73071]
===
match
---
name: state [80883,80888]
name: state [81386,81391]
===
match
---
simple_stmt [30675,30765]
simple_stmt [30929,31019]
===
match
---
expr_stmt [19249,19273]
expr_stmt [19249,19273]
===
match
---
name: sla [20134,20137]
name: sla [20134,20137]
===
match
---
tfpdef [29655,29674]
tfpdef [29909,29928]
===
match
---
name: session [58775,58782]
name: session [59278,59285]
===
match
---
name: self [75072,75076]
name: self [75575,75579]
===
match
---
operator: , [44985,44986]
operator: , [45488,45489]
===
match
---
trailer [59698,59703]
trailer [60201,60206]
===
match
---
name: self [48908,48912]
name: self [49411,49415]
===
match
---
operator: , [34730,34731]
operator: , [35233,35234]
===
match
---
dotted_name [2456,2475]
dotted_name [2456,2475]
===
match
---
trailer [67367,67377]
trailer [67870,67880]
===
match
---
name: dag_id [64467,64473]
name: dag_id [64970,64976]
===
match
---
arglist [67994,68086]
arglist [68497,68589]
===
match
---
name: session [39090,39097]
name: session [39593,39600]
===
match
---
atom_expr [38454,38518]
atom_expr [38957,39021]
===
match
---
name: emails [20669,20675]
name: emails [20669,20675]
===
match
---
simple_stmt [6839,6867]
simple_stmt [6839,6867]
===
match
---
trailer [30389,30395]
trailer [30643,30649]
===
match
---
trailer [45040,45096]
trailer [45543,45599]
===
match
---
if_stmt [13453,13674]
if_stmt [13453,13674]
===
match
---
name: to_reset [81956,81964]
name: to_reset [82459,82467]
===
match
---
trailer [52176,52192]
trailer [52679,52695]
===
match
---
name: ti [46859,46861]
name: ti [47362,47364]
===
match
---
trailer [78146,78160]
trailer [78649,78663]
===
match
---
atom_expr [24376,24405]
atom_expr [24376,24405]
===
match
---
name: max_tis [38150,38157]
name: max_tis [38653,38660]
===
match
---
operator: , [3956,3957]
operator: , [3956,3957]
===
match
---
operator: -> [30797,30799]
operator: -> [31051,31053]
===
match
---
suite [16867,17059]
suite [16867,17059]
===
match
---
operator: = [24082,24083]
operator: = [24082,24083]
===
match
---
dotted_name [2732,2753]
dotted_name [2732,2753]
===
match
---
suite [10081,10740]
suite [10081,10740]
===
match
---
operator: -> [35982,35984]
operator: -> [36485,36487]
===
match
---
name: dag [74717,74720]
name: dag [75220,75223]
===
match
---
atom_expr [68417,68430]
atom_expr [68920,68933]
===
match
---
atom_expr [10961,11040]
atom_expr [10961,11040]
===
match
---
name: dag_concurrency_map [40006,40025]
name: dag_concurrency_map [40509,40528]
===
match
---
with_item [60342,60375]
with_item [60845,60878]
===
match
---
operator: = [38839,38840]
operator: = [39342,39343]
===
match
---
operator: == [49371,49373]
operator: == [49874,49876]
===
match
---
atom_expr [24835,24850]
atom_expr [24835,24850]
===
match
---
operator: , [64402,64403]
operator: , [64905,64906]
===
match
---
if_stmt [50719,50812]
if_stmt [51222,51315]
===
match
---
name: subquery [16413,16421]
name: subquery [16413,16421]
===
match
---
name: dagbag [43246,43252]
name: dagbag [43749,43755]
===
match
---
name: ti_primary_key_to_try_number_map [50820,50852]
name: ti_primary_key_to_try_number_map [51323,51355]
===
match
---
name: processor_factory [54323,54340]
name: processor_factory [54826,54843]
===
match
---
fstring_start: f" [9224,9226]
fstring_start: f" [9224,9226]
===
match
---
trailer [78833,78882]
trailer [79336,79385]
===
match
---
atom_expr [73730,73746]
atom_expr [74233,74249]
===
match
---
expr_stmt [70120,70173]
expr_stmt [70623,70676]
===
match
---
trailer [40649,40651]
trailer [41152,41154]
===
match
---
name: exception [55478,55487]
name: exception [55981,55990]
===
match
---
operator: , [8911,8912]
operator: , [8911,8912]
===
match
---
trailer [50502,50574]
trailer [51005,51077]
===
match
---
simple_stmt [10441,10467]
simple_stmt [10441,10467]
===
match
---
trailer [45671,45678]
trailer [46174,46181]
===
match
---
trailer [76404,76486]
trailer [76907,76989]
===
match
---
name: serialized_dag [43406,43420]
name: serialized_dag [43909,43923]
===
match
---
name: expression [71293,71303]
name: expression [71796,71806]
===
match
---
name: TaskInstance [33587,33599]
name: TaskInstance [34090,34102]
===
match
---
atom_expr [16456,16464]
atom_expr [16456,16464]
===
match
---
operator: , [13753,13754]
operator: , [13753,13754]
===
match
---
comparison [69495,69552]
comparison [69998,70055]
===
match
---
name: Optional [4637,4645]
name: Optional [4637,4645]
===
match
---
atom_expr [16846,16854]
atom_expr [16846,16854]
===
match
---
suite [55791,55835]
suite [56294,56338]
===
match
---
trailer [18333,18338]
trailer [18333,18338]
===
match
---
trailer [64254,64270]
trailer [64757,64773]
===
match
---
suite [8569,9774]
suite [8569,9774]
===
match
---
name: executable_tis [45603,45617]
name: executable_tis [46106,46120]
===
match
---
operator: = [4814,4815]
operator: = [4814,4815]
===
match
---
name: dagbag [1882,1888]
name: dagbag [1882,1888]
===
match
---
name: self [12535,12539]
name: self [12535,12539]
===
match
---
atom_expr [15249,15268]
atom_expr [15249,15268]
===
match
---
name: _create_dag_file_processor [56062,56088]
name: _create_dag_file_processor [56565,56591]
===
match
---
operator: , [8104,8105]
operator: , [8104,8105]
===
match
---
arglist [68417,68453]
arglist [68920,68956]
===
match
---
annassign [18213,18228]
annassign [18213,18228]
===
match
---
import_as_names [1639,1692]
import_as_names [1639,1692]
===
match
---
operator: = [54409,54410]
operator: = [54912,54913]
===
match
---
trailer [16996,17006]
trailer [16996,17006]
===
match
---
operator: , [27649,27650]
operator: , [27649,27650]
===
match
---
atom_expr [64274,64287]
atom_expr [64777,64790]
===
match
---
name: self [76598,76602]
name: self [77101,77105]
===
match
---
name: allow_future_exec_dates [74721,74744]
name: allow_future_exec_dates [75224,75247]
===
match
---
tfpdef [77859,77875]
tfpdef [78362,78378]
===
match
---
atom_expr [31763,31789]
atom_expr [32266,32292]
===
match
---
atom_expr [6839,6866]
atom_expr [6839,6866]
===
match
---
name: int [4483,4486]
name: int [4483,4486]
===
match
---
tfpdef [22550,22566]
tfpdef [22550,22566]
===
match
---
operator: , [80005,80006]
operator: , [80508,80509]
===
match
---
name: active_dagruns_filter [68208,68229]
name: active_dagruns_filter [68711,68732]
===
match
---
name: all [34357,34360]
name: all [34860,34863]
===
match
---
trailer [77414,77418]
trailer [77917,77921]
===
match
---
try_stmt [26459,26773]
try_stmt [26459,26773]
===
match
---
raise_stmt [11405,11464]
raise_stmt [11405,11464]
===
match
---
expr_stmt [30605,30665]
expr_stmt [30859,30919]
===
match
---
simple_stmt [38897,38926]
simple_stmt [39400,39429]
===
match
---
name: self [56509,56513]
name: self [57012,57016]
===
match
---
trailer [24928,24948]
trailer [24928,24948]
===
match
---
simple_stmt [11219,11330]
simple_stmt [11219,11330]
===
match
---
name: state [51594,51599]
name: state [52097,52102]
===
match
---
suite [21448,22429]
suite [21448,22429]
===
match
---
atom_expr [58635,58660]
atom_expr [59138,59163]
===
match
---
name: to_reset [82231,82239]
name: to_reset [82734,82742]
===
match
---
name: self [5030,5034]
name: self [5030,5034]
===
match
---
atom_expr [77012,77029]
atom_expr [77515,77532]
===
match
---
atom_expr [76515,76531]
atom_expr [77018,77034]
===
match
---
trailer [33665,33678]
trailer [34168,34181]
===
match
---
fstring_end: ' [70268,70269]
fstring_end: ' [70771,70772]
===
match
---
name: str [36037,36040]
name: str [36540,36543]
===
match
---
expr_stmt [36734,36796]
expr_stmt [37237,37299]
===
match
---
arglist [30696,30763]
arglist [30950,31017]
===
match
---
name: self [79787,79791]
name: self [80290,80294]
===
match
---
name: filter [73710,73716]
name: filter [74213,74219]
===
match
---
operator: , [72568,72569]
operator: , [73071,73072]
===
match
---
name: self [79894,79898]
name: self [80397,80401]
===
match
---
name: DagRunType [38494,38504]
name: DagRunType [38997,39007]
===
match
---
atom [79989,80035]
atom [80492,80538]
===
match
---
name: commit [22420,22426]
name: commit [22420,22426]
===
match
---
name: DagBag [24226,24232]
name: DagBag [24226,24232]
===
match
---
name: self [79230,79234]
name: self [79733,79737]
===
match
---
simple_stmt [73839,73875]
simple_stmt [74342,74378]
===
match
---
name: DagFileProcessorProcess [56334,56357]
name: DagFileProcessorProcess [56837,56860]
===
match
---
simple_stmt [44894,44927]
simple_stmt [45397,45430]
===
match
---
return_stmt [75336,75344]
return_stmt [75839,75847]
===
match
---
name: dag_runs [64201,64209]
name: dag_runs [64704,64712]
===
match
---
simple_stmt [39506,39582]
simple_stmt [40009,40085]
===
match
---
trailer [54588,54591]
trailer [55091,55094]
===
match
---
atom_expr [78237,78262]
atom_expr [78740,78765]
===
match
---
operator: = [77876,77877]
operator: = [78379,78380]
===
match
---
name: self [30707,30711]
name: self [30961,30965]
===
match
---
name: gauge [45035,45040]
name: gauge [45538,45543]
===
match
---
atom_expr [68239,68252]
atom_expr [68742,68755]
===
match
---
comparison [17711,17739]
comparison [17711,17739]
===
match
---
name: log [65697,65700]
name: log [66200,66203]
===
match
---
trailer [13324,13333]
trailer [13324,13333]
===
match
---
trailer [22306,22318]
trailer [22306,22318]
===
match
---
atom_expr [64069,64086]
atom_expr [64572,64589]
===
match
---
name: end_date [34994,35002]
name: end_date [35497,35505]
===
match
---
atom_expr [76598,76657]
atom_expr [77101,77160]
===
match
---
name: timing [70200,70206]
name: timing [70703,70709]
===
match
---
name: create_session [2853,2867]
name: create_session [2853,2867]
===
match
---
name: dag_hash [76350,76358]
name: dag_hash [76853,76861]
===
match
---
name: num_starving_tasks_total [41866,41890]
name: num_starving_tasks_total [42369,42393]
===
match
---
operator: = [79987,79988]
operator: = [80490,80491]
===
match
---
operator: , [31078,31079]
operator: , [31332,31333]
===
match
---
trailer [10302,10311]
trailer [10302,10311]
===
match
---
simple_stmt [50760,50812]
simple_stmt [51263,51315]
===
match
---
atom_expr [8263,8312]
atom_expr [8263,8312]
===
match
---
atom_expr [78014,78077]
atom_expr [78517,78580]
===
match
---
string: """Helper method to clean up processor_agent to avoid leaving orphan processes.""" [31139,31221]
string: """Helper method to clean up processor_agent to avoid leaving orphan processes.""" [31393,31475]
===
match
---
suite [20637,20818]
suite [20637,20818]
===
match
---
name: email_sent [21217,21227]
name: email_sent [21217,21227]
===
match
---
name: timer [7158,7163]
name: timer [7158,7163]
===
match
---
name: self [50348,50352]
name: self [50851,50855]
===
match
---
trailer [13441,13443]
trailer [13441,13443]
===
match
---
atom_expr [24140,24151]
atom_expr [24140,24151]
===
match
---
trailer [7031,7067]
trailer [7031,7067]
===
match
---
operator: } [19650,19651]
operator: } [19650,19651]
===
match
---
name: DR [3103,3105]
name: DR [3103,3105]
===
match
---
name: qry [16591,16594]
name: qry [16591,16594]
===
match
---
atom_expr [76911,76931]
atom_expr [77414,77434]
===
match
---
atom_expr [24970,25044]
atom_expr [24970,25044]
===
match
---
operator: == [52405,52407]
operator: == [52908,52910]
===
match
---
atom_expr [52438,52461]
atom_expr [52941,52964]
===
match
---
name: num_unhandled [41894,41907]
name: num_unhandled [42397,42410]
===
match
---
name: int [25361,25364]
name: int [25361,25364]
===
match
---
atom [51015,51017]
atom [51518,51520]
===
match
---
operator: == [16270,16272]
operator: == [16270,16272]
===
match
---
name: task_concurrency_limit [43381,43403]
name: task_concurrency_limit [43884,43906]
===
match
---
for_stmt [81665,81773]
for_stmt [82168,82276]
===
match
---
operator: @ [14032,14033]
operator: @ [14032,14033]
===
match
---
suite [21159,21329]
suite [21159,21329]
===
match
---
trailer [36791,36796]
trailer [37294,37299]
===
match
---
trailer [7675,7677]
trailer [7675,7677]
===
match
---
trailer [38870,38885]
trailer [39373,39388]
===
match
---
name: ti [25131,25133]
name: ti [25131,25133]
===
match
---
trailer [65706,65750]
trailer [66209,66253]
===
match
---
name: self [13423,13427]
name: self [13423,13427]
===
match
---
suite [48566,48648]
suite [49069,49151]
===
match
---
name: execution_date [74816,74830]
name: execution_date [75319,75333]
===
match
---
name: filter [80550,80556]
name: filter [81053,81059]
===
match
---
simple_stmt [27255,27324]
simple_stmt [27255,27324]
===
match
---
trailer [77633,77668]
trailer [78136,78171]
===
match
---
atom_expr [60758,60768]
atom_expr [61261,61271]
===
match
---
name: len [53465,53468]
name: len [53968,53971]
===
match
---
string: "DAG '%s' not found in serialized_dag table" [68710,68754]
string: "DAG '%s' not found in serialized_dag table" [69213,69257]
===
match
---
arglist [30945,30982]
arglist [31199,31236]
===
match
---
name: pickle_dags [4144,4155]
name: pickle_dags [4144,4155]
===
match
---
atom_expr [25350,25365]
atom_expr [25350,25365]
===
match
---
name: current_dag_concurrency [42490,42513]
name: current_dag_concurrency [42993,43016]
===
match
---
testlist_comp [27382,27456]
testlist_comp [27382,27456]
===
match
---
name: _parent_channel [11146,11161]
name: _parent_channel [11146,11161]
===
match
---
expr_stmt [40853,40885]
expr_stmt [41356,41388]
===
match
---
suite [82559,82625]
suite [83062,83128]
===
match
---
simple_stmt [75336,75345]
simple_stmt [75839,75848]
===
match
---
name: self [58139,58143]
name: self [58642,58646]
===
match
---
name: request [23856,23863]
name: request [23856,23863]
===
match
---
name: TI [80987,80989]
name: TI [81490,81492]
===
match
---
atom_expr [64151,64212]
atom_expr [64654,64715]
===
match
---
operator: , [40807,40808]
operator: , [41310,41311]
===
match
---
atom_expr [35985,36048]
atom_expr [36488,36551]
===
match
---
operator: @ [14348,14349]
operator: @ [14348,14349]
===
match
---
name: TI [73567,73569]
name: TI [74070,74072]
===
match
---
operator: = [56424,56425]
operator: = [56927,56928]
===
match
---
trailer [3114,3121]
trailer [3114,3121]
===
match
---
trailer [18651,18656]
trailer [18651,18656]
===
match
---
name: queued_tasks [49763,49775]
name: queued_tasks [50266,50278]
===
match
---
name: _emit_pool_metrics [77834,77852]
name: _emit_pool_metrics [78337,78355]
===
match
---
name: self [68823,68827]
name: self [69326,69330]
===
match
---
trailer [45835,45841]
trailer [46338,46344]
===
match
---
atom_expr [19888,19899]
atom_expr [19888,19899]
===
match
---
simple_stmt [81743,81773]
simple_stmt [82246,82276]
===
match
---
trailer [22356,22363]
trailer [22356,22363]
===
match
---
trailer [24351,24356]
trailer [24351,24356]
===
match
---
comparison [33827,33863]
comparison [34330,34366]
===
match
---
except_clause [65198,65226]
except_clause [65701,65729]
===
match
---
name: RUNNING [32560,32567]
name: RUNNING [33063,33070]
===
match
---
trailer [46565,46573]
trailer [47068,47076]
===
match
---
name: State [45843,45848]
name: State [46346,46351]
===
match
---
name: self [12670,12674]
name: self [12670,12674]
===
match
---
name: exceptions [1621,1631]
name: exceptions [1621,1631]
===
match
---
name: List [52003,52007]
name: List [52506,52510]
===
match
---
atom_expr [38479,38490]
atom_expr [38982,38993]
===
match
---
name: processor_agent [54681,54696]
name: processor_agent [55184,55199]
===
match
---
argument [79603,79618]
argument [80106,80121]
===
match
---
name: session [81235,81242]
name: session [81738,81745]
===
match
---
name: current_task_concurrency [43608,43632]
name: current_task_concurrency [44111,44135]
===
match
---
argument [53059,53093]
argument [53562,53596]
===
match
---
atom_expr [4945,4991]
atom_expr [4945,4991]
===
match
---
name: self [74118,74122]
name: self [74621,74625]
===
match
---
name: processor_agent [30610,30625]
name: processor_agent [30864,30879]
===
match
---
atom_expr [67359,67377]
atom_expr [67862,67880]
===
match
---
decorated [35870,37003]
decorated [36373,37506]
===
match
---
suite [13918,13999]
suite [13918,13999]
===
match
---
name: starved_pools [38707,38720]
name: starved_pools [39210,39223]
===
match
---
name: sla [17276,17279]
name: sla [17276,17279]
===
match
---
atom_expr [76853,76881]
atom_expr [77356,77384]
===
match
---
trailer [23434,23457]
trailer [23434,23457]
===
match
---
name: priority_weight [47007,47022]
name: priority_weight [47510,47525]
===
match
---
string: "Exiting scheduler loop as requested number of runs (%d - got to %d) has been reached" [59725,59811]
string: "Exiting scheduler loop as requested number of runs (%d - got to %d) has been reached" [60228,60314]
===
match
---
trailer [80619,80627]
trailer [81122,81130]
===
match
---
name: Logger [15283,15289]
name: Logger [15283,15289]
===
match
---
operator: = [24683,24684]
operator: = [24683,24684]
===
match
---
trailer [57816,57838]
trailer [58319,58341]
===
match
---
name: property [14033,14041]
name: property [14033,14041]
===
match
---
name: Session [72642,72649]
name: Session [73145,73152]
===
match
---
operator: , [76119,76120]
operator: , [76622,76623]
===
match
---
name: CallbackRequest [2263,2278]
name: CallbackRequest [2263,2278]
===
match
---
string: 'scheduler.critical_section_duration' [65817,65854]
string: 'scheduler.critical_section_duration' [66320,66357]
===
match
---
operator: , [49717,49718]
operator: , [50220,50221]
===
match
---
name: log [82105,82108]
name: log [82608,82611]
===
match
---
name: TaskInstance [35049,35061]
name: TaskInstance [35552,35564]
===
match
---
trailer [32357,32366]
trailer [32860,32869]
===
match
---
name: c [16595,16596]
name: c [16595,16596]
===
match
---
argument [81252,81282]
argument [81755,81785]
===
match
---
operator: , [36700,36701]
operator: , [37203,37204]
===
match
---
atom_expr [22348,22365]
atom_expr [22348,22365]
===
match
---
dotted_name [2824,2845]
dotted_name [2824,2845]
===
match
---
suite [34503,35532]
suite [35006,36035]
===
match
---
name: dag_run [75988,75995]
name: dag_run [76491,76498]
===
match
---
name: session [66771,66778]
name: session [67274,67281]
===
match
---
operator: = [18004,18005]
operator: = [18004,18005]
===
match
---
trailer [29402,29414]
trailer [29656,29668]
===
match
---
name: _verify_integrity_if_dag_changed [75359,75391]
name: _verify_integrity_if_dag_changed [75862,75894]
===
match
---
argument [17368,17386]
argument [17368,17386]
===
match
---
trailer [17154,17161]
trailer [17154,17161]
===
match
---
simple_stmt [66789,66836]
simple_stmt [67292,67339]
===
match
---
name: _kill_process [13428,13441]
name: _kill_process [13428,13441]
===
match
---
operator: |= [20437,20439]
operator: |= [20437,20439]
===
match
---
arglist [31685,31752]
arglist [32188,32255]
===
match
---
name: SerializedDagNotFound [1657,1678]
name: SerializedDagNotFound [1657,1678]
===
match
---
name: task_concurrency_limit [42936,42958]
name: task_concurrency_limit [43439,43461]
===
match
---
name: dag_concurrency_limit [42430,42451]
name: dag_concurrency_limit [42933,42954]
===
match
---
arglist [77480,77546]
arglist [77983,78049]
===
match
---
atom_expr [73891,73919]
atom_expr [74394,74422]
===
match
---
arglist [23199,23214]
arglist [23199,23214]
===
match
---
suite [20405,20480]
suite [20405,20480]
===
match
---
name: CallbackRequest [25255,25270]
name: CallbackRequest [25255,25270]
===
match
---
fstring_string: SLA is expected to be timedelta object, got  [16923,16967]
fstring_string: SLA is expected to be timedelta object, got  [16923,16967]
===
match
---
atom_expr [46563,46573]
atom_expr [47066,47076]
===
match
---
atom_expr [58519,58535]
atom_expr [59022,59038]
===
match
---
name: QUEUED [49664,49670]
name: QUEUED [50167,50173]
===
match
---
name: max_tis [38917,38924]
name: max_tis [39420,39427]
===
match
---
comparison [49560,49592]
comparison [50063,50095]
===
match
---
operator: , [20132,20133]
operator: , [20132,20133]
===
match
---
name: id [54589,54591]
name: id [55092,55094]
===
match
---
atom_expr [74149,74192]
atom_expr [74652,74695]
===
match
---
name: tis_to_set_to_scheduled [49879,49902]
name: tis_to_set_to_scheduled [50382,50405]
===
match
---
trailer [33530,33559]
trailer [34033,34062]
===
match
---
raise_stmt [11878,11954]
raise_stmt [11878,11954]
===
match
---
expr_stmt [15358,15373]
expr_stmt [15358,15373]
===
match
---
trailer [52183,52191]
trailer [52686,52694]
===
match
---
atom_expr [56190,56199]
atom_expr [56693,56702]
===
match
---
name: dag_models [70372,70382]
name: dag_models [70875,70885]
===
match
---
simple_stmt [49196,49203]
simple_stmt [49699,49706]
===
match
---
name: request [23119,23126]
name: request [23119,23126]
===
match
---
operator: = [17375,17376]
operator: = [17375,17376]
===
match
---
param [3966,3995]
param [3966,3995]
===
match
---
trailer [20229,20236]
trailer [20229,20236]
===
match
---
trailer [80560,80628]
trailer [81063,81131]
===
match
---
operator: = [53016,53017]
operator: = [53519,53520]
===
match
---
name: DagBag [1896,1902]
name: DagBag [1896,1902]
===
match
---
name: ti_query [49930,49938]
name: ti_query [50433,50441]
===
match
---
expr_stmt [4796,4862]
expr_stmt [4796,4862]
===
match
---
parameters [48907,48938]
parameters [49410,49441]
===
match
---
name: isinstance [20377,20387]
name: isinstance [20377,20387]
===
match
---
operator: , [73245,73246]
operator: , [73748,73749]
===
match
---
name: getint [54052,54058]
name: getint [54555,54561]
===
match
---
operator: , [53217,53218]
operator: , [53720,53721]
===
match
---
name: QUEUED [51710,51716]
name: QUEUED [52213,52219]
===
match
---
name: task [20297,20301]
name: task [20297,20301]
===
match
---
name: filter [38847,38853]
name: filter [39350,39356]
===
match
---
name: gauge [45256,45261]
name: gauge [45759,45764]
===
match
---
name: request [23380,23387]
name: request [23380,23387]
===
match
---
argument [69859,69874]
argument [70362,70377]
===
match
---
atom_expr [73839,73858]
atom_expr [74342,74361]
===
match
---
name: dag_id [76479,76485]
name: dag_id [76982,76988]
===
match
---
simple_stmt [32410,32511]
simple_stmt [32913,33014]
===
match
---
name: session [43277,43284]
name: session [43780,43787]
===
match
---
trailer [23021,23027]
trailer [23021,23027]
===
match
---
comparison [71962,72003]
comparison [72465,72506]
===
match
---
suite [70643,72503]
suite [71146,73006]
===
match
---
name: MAX_DB_RETRIES [79180,79194]
name: MAX_DB_RETRIES [79683,79697]
===
match
---
operator: -> [46159,46161]
operator: -> [46662,46664]
===
match
---
name: join [18538,18542]
name: join [18538,18542]
===
match
---
if_stmt [17247,17463]
if_stmt [17247,17463]
===
match
---
argument [56392,56415]
argument [56895,56918]
===
match
---
simple_stmt [23013,23072]
simple_stmt [23013,23072]
===
match
---
name: self [31763,31767]
name: self [32266,32270]
===
match
---
name: dag_models [68337,68347]
name: dag_models [68840,68850]
===
match
---
trailer [44963,45010]
trailer [45466,45513]
===
match
---
fstring_end: " [20717,20718]
fstring_end: " [20717,20718]
===
match
---
name: task_id [36632,36639]
name: task_id [37135,37142]
===
match
---
trailer [19080,19109]
trailer [19080,19109]
===
match
---
name: sla [18566,18569]
name: sla [18566,18569]
===
match
---
atom_expr [76471,76485]
atom_expr [76974,76988]
===
match
---
name: get_paused_dag_ids [27281,27299]
name: get_paused_dag_ids [27281,27299]
===
match
---
atom_expr [23108,23148]
atom_expr [23108,23148]
===
match
---
atom_expr [8881,8911]
atom_expr [8881,8911]
===
match
---
name: pid [11036,11039]
name: pid [11036,11039]
===
match
---
atom_expr [11107,11127]
atom_expr [11107,11127]
===
match
---
import_from [2575,2661]
import_from [2575,2661]
===
match
---
operator: , [46797,46798]
operator: , [47300,47301]
===
match
---
except_clause [71697,71725]
except_clause [72200,72228]
===
match
---
name: tis_to_set_to_scheduled [50311,50334]
name: tis_to_set_to_scheduled [50814,50837]
===
match
---
operator: , [23883,23884]
operator: , [23883,23884]
===
match
---
trailer [71634,71641]
trailer [72137,72144]
===
match
---
operator: , [56200,56201]
operator: , [56703,56704]
===
match
---
operator: = [81763,81764]
operator: = [82266,82267]
===
match
---
atom_expr [81743,81762]
atom_expr [82246,82265]
===
match
---
trailer [35391,35406]
trailer [35894,35909]
===
match
---
not_test [77579,77603]
not_test [78082,78106]
===
match
---
trailer [54702,54704]
trailer [55205,55207]
===
match
---
atom_expr [35160,35517]
atom_expr [35663,36020]
===
match
---
name: session [60319,60326]
name: session [60822,60829]
===
match
---
arglist [65149,65170]
arglist [65652,65673]
===
match
---
suite [13485,13674]
suite [13485,13674]
===
match
---
name: simple_ti [24541,24550]
name: simple_ti [24541,24550]
===
match
---
parameters [10043,10072]
parameters [10043,10072]
===
match
---
operator: , [2278,2279]
operator: , [2278,2279]
===
match
---
suite [78944,82625]
suite [79447,83128]
===
match
---
name: file_path [6928,6937]
name: file_path [6928,6937]
===
match
---
operator: > [35556,35557]
operator: > [36059,36060]
===
match
---
trailer [52413,52420]
trailer [52916,52923]
===
match
---
name: task_id [49328,49335]
name: task_id [49831,49838]
===
match
---
atom_expr [16351,16363]
atom_expr [16351,16363]
===
match
---
trailer [17765,17767]
trailer [17765,17767]
===
match
---
trailer [10846,10888]
trailer [10846,10888]
===
match
---
atom_expr [79894,79925]
atom_expr [80397,80428]
===
match
---
if_stmt [74663,74853]
if_stmt [75166,75356]
===
match
---
simple_stmt [18626,18763]
simple_stmt [18626,18763]
===
match
---
name: items [40644,40649]
name: items [41147,41152]
===
match
---
name: debug [13537,13542]
name: debug [13537,13542]
===
match
---
suite [78508,82655]
suite [79011,83158]
===
match
---
name: Optional [15249,15257]
name: Optional [15249,15257]
===
match
---
name: _change_state_for_tis_without_dagrun [60415,60451]
name: _change_state_for_tis_without_dagrun [60918,60954]
===
match
---
name: _process [10446,10454]
name: _process [10446,10454]
===
match
---
trailer [78746,78750]
trailer [79249,79253]
===
match
---
string: "Got an exception! Propagating..." [8277,8311]
string: "Got an exception! Propagating..." [8277,8311]
===
match
---
trailer [38388,38394]
trailer [38891,38897]
===
match
---
trailer [41439,41471]
trailer [41942,41974]
===
match
---
expr_stmt [44573,44596]
expr_stmt [45076,45099]
===
match
---
name: utils [2464,2469]
name: utils [2464,2469]
===
match
---
expr_stmt [53008,53236]
expr_stmt [53511,53739]
===
match
---
name: self [39364,39368]
name: self [39867,39871]
===
match
---
operator: , [57914,57915]
operator: , [58417,58418]
===
match
---
name: sqlalchemy [1388,1398]
name: sqlalchemy [1388,1398]
===
match
---
name: processor_poll_interval [29526,29549]
name: processor_poll_interval [29780,29803]
===
match
---
name: dag [15422,15425]
name: dag [15422,15425]
===
match
---
name: func [71054,71058]
name: func [71557,71561]
===
match
---
name: models [34686,34692]
name: models [35189,35195]
===
match
---
operator: , [16168,16169]
operator: , [16168,16169]
===
match
---
parameters [24211,24263]
parameters [24211,24263]
===
match
---
name: buffer_key [52296,52306]
name: buffer_key [52799,52809]
===
match
---
trailer [54254,54261]
trailer [54757,54764]
===
match
---
name: dttm [17139,17143]
name: dttm [17139,17143]
===
match
---
name: datetime [4646,4654]
name: datetime [4646,4654]
===
match
---
operator: , [57712,57713]
operator: , [58215,58216]
===
match
---
simple_stmt [46027,46046]
simple_stmt [46530,46549]
===
match
---
operator: , [47150,47151]
operator: , [47653,47654]
===
match
---
name: session [81266,81273]
name: session [81769,81776]
===
match
---
name: task_ids [18301,18309]
name: task_ids [18301,18309]
===
match
---
trailer [6742,6747]
trailer [6742,6747]
===
match
---
name: task_instance [44987,45000]
name: task_instance [45490,45503]
===
match
---
name: email [2470,2475]
name: email [2470,2475]
===
match
---
name: execute_callbacks [22459,22476]
name: execute_callbacks [22459,22476]
===
match
---
trailer [43655,43756]
trailer [44158,44259]
===
match
---
string: 'scheduler.tasks.executable' [45262,45290]
string: 'scheduler.tasks.executable' [45765,45793]
===
match
---
operator: , [24232,24233]
operator: , [24232,24233]
===
match
---
suite [53515,56035]
suite [54018,56538]
===
match
---
simple_stmt [55291,55344]
simple_stmt [55794,55847]
===
match
---
name: and_ [1309,1313]
name: and_ [1309,1313]
===
match
---
trailer [12696,12698]
trailer [12696,12698]
===
match
---
name: info [73969,73973]
name: info [74472,74476]
===
match
---
trailer [38446,38453]
trailer [38949,38956]
===
match
---
atom_expr [76342,76358]
atom_expr [76845,76861]
===
match
---
name: info [75081,75085]
name: info [75584,75588]
===
match
---
name: dag [17202,17205]
name: dag [17202,17205]
===
match
---
expr_stmt [30464,30511]
expr_stmt [30718,30765]
===
match
---
trailer [77042,77075]
trailer [77545,77578]
===
match
---
operator: = [74367,74368]
operator: = [74870,74871]
===
match
---
name: task_instance [73839,73852]
name: task_instance [74342,74355]
===
match
---
trailer [78750,78755]
trailer [79253,79258]
===
match
---
simple_stmt [68812,68861]
simple_stmt [69315,69364]
===
match
---
name: self [50726,50730]
name: self [51229,51233]
===
match
---
argument [81235,81250]
argument [81738,81753]
===
match
---
operator: , [35073,35074]
operator: , [35576,35577]
===
match
---
trailer [22097,22109]
trailer [22097,22109]
===
match
---
simple_stmt [41928,41934]
simple_stmt [42431,42437]
===
match
---
atom_expr [51247,51295]
atom_expr [51750,51798]
===
match
---
trailer [34176,34189]
trailer [34679,34692]
===
match
---
atom_expr [15327,15339]
atom_expr [15327,15339]
===
match
---
name: DagBag [26485,26491]
name: DagBag [26485,26491]
===
match
---
atom [49241,49792]
atom [49744,50295]
===
match
---
name: id [45918,45920]
name: id [46421,46423]
===
match
---
operator: = [40414,40415]
operator: = [40917,40918]
===
match
---
simple_stmt [1569,1608]
simple_stmt [1569,1608]
===
match
---
trailer [68410,68416]
trailer [68913,68919]
===
match
---
operator: = [34447,34448]
operator: = [34950,34951]
===
match
---
trailer [71761,71825]
trailer [72264,72328]
===
match
---
name: starved_pools [38806,38819]
name: starved_pools [39309,39322]
===
match
---
atom_expr [49156,49182]
atom_expr [49659,49685]
===
match
---
atom_expr [9243,9260]
atom_expr [9243,9260]
===
match
---
name: _parent_channel [10328,10343]
name: _parent_channel [10328,10343]
===
match
---
argument [24018,24033]
argument [24018,24033]
===
match
---
number: 0 [74652,74653]
number: 0 [75155,75156]
===
match
---
parameters [77852,77883]
parameters [78355,78386]
===
match
---
trailer [22318,22389]
trailer [22318,22389]
===
match
---
name: property [13702,13710]
name: property [13702,13710]
===
match
---
name: dag [19875,19878]
name: dag [19875,19878]
===
match
---
dictorsetmaker [79681,79702]
dictorsetmaker [80184,80205]
===
match
---
trailer [76861,76881]
trailer [77364,77384]
===
match
---
name: simple_ti [24492,24501]
name: simple_ti [24492,24501]
===
match
---
atom_expr [30885,30898]
atom_expr [31139,31152]
===
match
---
name: self [69951,69955]
name: self [70454,70458]
===
match
---
name: timer [66236,66241]
name: timer [66739,66744]
===
match
---
name: dag_run [33551,33558]
name: dag_run [34054,34061]
===
match
---
arglist [62965,62979]
arglist [63468,63482]
===
match
---
simple_stmt [40057,40113]
simple_stmt [40560,40616]
===
match
---
if_stmt [16815,17059]
if_stmt [16815,17059]
===
match
---
trailer [30951,30959]
trailer [31205,31213]
===
match
---
operator: , [51599,51600]
operator: , [52102,52103]
===
match
---
name: utcnow [32594,32600]
name: utcnow [33097,33103]
===
match
---
simple_stmt [68208,68363]
simple_stmt [68711,68866]
===
match
---
trailer [53037,53236]
trailer [53540,53739]
===
match
---
operator: , [70269,70270]
operator: , [70772,70773]
===
match
---
if_stmt [55074,55344]
if_stmt [55577,55847]
===
match
---
name: dag_run [75278,75285]
name: dag_run [75781,75788]
===
match
---
name: task [20342,20346]
name: task [20342,20346]
===
match
---
strings [60013,60136]
strings [60516,60639]
===
match
---
simple_stmt [75621,75685]
simple_stmt [76124,76188]
===
match
---
trailer [24724,24733]
trailer [24724,24733]
===
match
---
name: REMOVED [64280,64287]
name: REMOVED [64783,64790]
===
match
---
trailer [80762,80775]
trailer [81265,81278]
===
match
---
atom_expr [16481,16689]
atom_expr [16481,16689]
===
match
---
trailer [26397,26449]
trailer [26397,26449]
===
match
---
name: List [49904,49908]
name: List [50407,50411]
===
match
---
name: verify_integrity [76735,76751]
name: verify_integrity [77238,77254]
===
match
---
atom_expr [18386,18409]
atom_expr [18386,18409]
===
match
---
name: dag_id [33600,33606]
name: dag_id [34103,34109]
===
match
---
name: request [22971,22978]
name: request [22971,22978]
===
match
---
atom_expr [64234,64289]
atom_expr [64737,64792]
===
match
---
name: email_content [19450,19463]
name: email_content [19450,19463]
===
match
---
trailer [18068,18074]
trailer [18068,18074]
===
match
---
name: session [66064,66071]
name: session [66567,66574]
===
match
---
trailer [68416,68454]
trailer [68919,68957]
===
match
---
trailer [49929,49956]
trailer [50432,50459]
===
match
---
atom_expr [80752,80775]
atom_expr [81255,81278]
===
match
---
name: staticmethod [5081,5093]
name: staticmethod [5081,5093]
===
match
---
name: airflow [1537,1544]
name: airflow [1537,1544]
===
match
---
trailer [72034,72268]
trailer [72537,72771]
===
match
---
trailer [79995,80005]
trailer [80498,80508]
===
match
---
name: self [30109,30113]
name: self [30363,30367]
===
match
---
name: dag_run [76727,76734]
name: dag_run [77230,77237]
===
match
---
trailer [8531,8537]
trailer [8531,8537]
===
match
---
operator: = [66331,66332]
operator: = [66834,66835]
===
match
---
trailer [36587,36593]
trailer [37090,37096]
===
match
---
import_from [1383,1433]
import_from [1383,1433]
===
match
---
trailer [82587,82596]
trailer [83090,83099]
===
match
---
name: self [58914,58918]
name: self [59417,59421]
===
match
---
trailer [79588,79590]
trailer [80091,80093]
===
match
---
atom_expr [74118,74203]
atom_expr [74621,74706]
===
match
---
operator: = [29775,29776]
operator: = [30029,30030]
===
match
---
name: blocking_tis [18201,18213]
name: blocking_tis [18201,18213]
===
match
---
simple_stmt [2355,2451]
simple_stmt [2355,2451]
===
match
---
simple_stmt [63977,64379]
simple_stmt [64480,64882]
===
match
---
atom_expr [36537,36546]
atom_expr [37040,37049]
===
match
---
name: close [6795,6800]
name: close [6795,6800]
===
match
---
atom_expr [50222,50236]
atom_expr [50725,50739]
===
match
---
fstring_start: f" [6888,6890]
fstring_start: f" [6888,6890]
===
match
---
simple_stmt [8481,8504]
simple_stmt [8481,8504]
===
match
---
parameters [37127,37172]
parameters [37630,37675]
===
match
---
trailer [16421,16427]
trailer [16421,16427]
===
match
---
string: "Figuring out tasks to run in Pool(name=%s) with %s open slots " [40974,41038]
string: "Figuring out tasks to run in Pool(name=%s) with %s open slots " [41477,41541]
===
match
---
raise_stmt [12285,12353]
raise_stmt [12285,12353]
===
match
---
operator: = [8843,8844]
operator: = [8843,8844]
===
match
---
name: kill [9783,9787]
name: kill [9783,9787]
===
match
---
name: task_id [16794,16801]
name: task_id [16794,16801]
===
match
---
name: new_state [35769,35778]
name: new_state [36272,36281]
===
match
---
trailer [16781,16790]
trailer [16781,16790]
===
match
---
name: log [26389,26392]
name: log [26389,26392]
===
match
---
name: request [23994,24001]
name: request [23994,24001]
===
match
---
name: all [17762,17765]
name: all [17762,17765]
===
match
---
name: self [53524,53528]
name: self [54027,54031]
===
match
---
expr_stmt [34597,34745]
expr_stmt [35100,35248]
===
match
---
if_stmt [42487,42919]
if_stmt [42990,43422]
===
match
---
operator: = [29285,29286]
operator: = [29539,29540]
===
match
---
name: state [24845,24850]
name: state [24845,24850]
===
match
---
arglist [78388,78415]
arglist [78891,78918]
===
match
---
trailer [35324,35332]
trailer [35827,35835]
===
match
---
trailer [80965,81018]
trailer [81468,81521]
===
match
---
trailer [10594,10597]
trailer [10594,10597]
===
match
---
name: tuple_ [1332,1338]
name: tuple_ [1332,1338]
===
match
---
name: State [16300,16305]
name: State [16300,16305]
===
match
---
atom_expr [50133,50280]
atom_expr [50636,50783]
===
match
---
atom_expr [81617,81636]
atom_expr [82120,82139]
===
match
---
arglist [16063,16118]
arglist [16063,16118]
===
match
---
atom_expr [27729,27779]
atom_expr [27729,27779]
===
match
---
trailer [25015,25019]
trailer [25015,25019]
===
match
---
name: dag [73102,73105]
name: dag [73605,73608]
===
match
---
name: self [78987,78991]
name: self [79490,79494]
===
match
---
name: sla_dates [17896,17905]
name: sla_dates [17896,17905]
===
match
---
name: is_ [33953,33956]
name: is_ [34456,34459]
===
match
---
simple_stmt [27729,27780]
simple_stmt [27729,27780]
===
match
---
arglist [64151,64290]
arglist [64654,64793]
===
match
---
suite [25366,27840]
suite [25366,27840]
===
match
---
atom_expr [81765,81772]
atom_expr [82268,82275]
===
match
---
name: AirflowException [10371,10387]
name: AirflowException [10371,10387]
===
match
---
atom_expr [81876,81966]
atom_expr [82379,82469]
===
match
---
atom_expr [8715,8756]
atom_expr [8715,8756]
===
match
---
trailer [75080,75085]
trailer [75583,75588]
===
match
---
name: info [42266,42270]
name: info [42769,42773]
===
match
---
name: RUNNING [33856,33863]
name: RUNNING [34359,34366]
===
match
---
name: qry [16643,16646]
name: qry [16643,16646]
===
match
---
name: dag_model [71406,71415]
name: dag_model [71909,71918]
===
match
---
operator: , [40140,40141]
operator: , [40643,40644]
===
match
---
atom_expr [82503,82518]
atom_expr [83006,83021]
===
match
---
param [78477,78482]
param [78980,78985]
===
match
---
name: FAILED [79696,79702]
name: FAILED [80199,80205]
===
match
---
trailer [60585,60622]
trailer [61088,61125]
===
match
---
name: ti_query [49801,49809]
name: ti_query [50304,50312]
===
match
---
trailer [13749,13759]
trailer [13749,13759]
===
match
---
simple_stmt [63923,63964]
simple_stmt [64426,64467]
===
match
---
for_stmt [77958,78280]
for_stmt [78461,78783]
===
match
---
name: info [72030,72034]
name: info [72533,72537]
===
match
---
trailer [23379,23408]
trailer [23379,23408]
===
match
---
name: timezone [16714,16722]
name: timezone [16714,16722]
===
match
---
operator: , [15268,15269]
operator: , [15268,15269]
===
match
---
suite [72344,72503]
suite [72847,73006]
===
match
---
atom_expr [55469,55548]
atom_expr [55972,56051]
===
match
---
simple_stmt [2575,2662]
simple_stmt [2575,2662]
===
match
---
operator: = [37165,37166]
operator: = [37668,37669]
===
match
---
trailer [53360,53370]
trailer [53863,53873]
===
match
---
atom_expr [63005,63047]
atom_expr [63508,63550]
===
match
---
name: log [41534,41537]
name: log [42037,42040]
===
match
---
param [5348,5389]
param [5348,5389]
===
match
---
argument [46775,46797]
argument [47278,47300]
===
match
---
name: filter [73588,73594]
name: filter [74091,74097]
===
match
---
name: len [75230,75233]
name: len [75733,75736]
===
match
---
if_stmt [34857,35115]
if_stmt [35360,35618]
===
match
---
atom_expr [30627,30658]
atom_expr [30881,30912]
===
match
---
tfpdef [3939,3956]
tfpdef [3939,3956]
===
match
---
comparison [10298,10319]
comparison [10298,10319]
===
match
---
name: TI [49909,49911]
name: TI [50412,50414]
===
match
---
name: State [69780,69785]
name: State [70283,70288]
===
match
---
atom_expr [4894,4929]
atom_expr [4894,4929]
===
match
---
raise_stmt [9939,9995]
raise_stmt [9939,9995]
===
match
---
trailer [26643,26693]
trailer [26643,26693]
===
match
---
operator: , [27126,27127]
operator: , [27126,27127]
===
match
---
name: ti [46042,46044]
name: ti [46545,46547]
===
match
---
operator: = [24374,24375]
operator: = [24374,24375]
===
match
---
atom_expr [54676,54704]
atom_expr [55179,55207]
===
match
---
name: query [38833,38838]
name: query [39336,39341]
===
match
---
suite [71607,71685]
suite [72110,72188]
===
match
---
trailer [16335,16365]
trailer [16335,16365]
===
match
---
param [67379,67395]
param [67882,67898]
===
match
---
name: self [66018,66022]
name: self [66521,66525]
===
match
---
name: tasks [77445,77450]
name: tasks [77948,77953]
===
match
---
operator: < [32644,32645]
operator: < [33147,33148]
===
match
---
simple_stmt [6491,6552]
simple_stmt [6491,6552]
===
match
---
atom_expr [71293,71311]
atom_expr [71796,71814]
===
match
---
trailer [36539,36546]
trailer [37042,37049]
===
match
---
trailer [16850,16854]
trailer [16850,16854]
===
match
---
return_stmt [12390,12401]
return_stmt [12390,12401]
===
match
---
name: State [64274,64279]
name: State [64777,64782]
===
match
---
name: expression [1520,1530]
name: expression [1520,1530]
===
match
---
name: signal [30945,30951]
name: signal [31199,31205]
===
match
---
atom_expr [35601,35793]
atom_expr [36104,36296]
===
match
---
suite [23409,23484]
suite [23409,23484]
===
match
---
name: TI [80999,81001]
name: TI [81502,81504]
===
match
---
trailer [13565,13574]
trailer [13565,13574]
===
match
---
arglist [11061,11094]
arglist [11061,11094]
===
match
---
name: ti [46536,46538]
name: ti [47039,47041]
===
match
---
string: 'USE INDEX (PRIMARY)' [16147,16168]
string: 'USE INDEX (PRIMARY)' [16147,16168]
===
match
---
atom_expr [24787,24807]
atom_expr [24787,24807]
===
match
---
name: session [67379,67386]
name: session [67882,67889]
===
match
---
trailer [64334,64364]
trailer [64837,64867]
===
match
---
import_as_names [1410,1433]
import_as_names [1410,1433]
===
match
---
name: DefaultDict [1191,1202]
name: DefaultDict [1191,1202]
===
match
---
param [25316,25340]
param [25316,25340]
===
match
---
testlist_star_expr [40121,40162]
testlist_star_expr [40624,40665]
===
match
---
name: execution_date [75286,75300]
name: execution_date [75789,75803]
===
match
---
atom [18006,18188]
atom [18006,18188]
===
match
---
string: "Ran scheduling loop in %.2f seconds" [59157,59194]
string: "Ran scheduling loop in %.2f seconds" [59660,59697]
===
match
---
name: property [11176,11184]
name: property [11176,11184]
===
match
---
name: sla [21324,21327]
name: sla [21324,21327]
===
match
---
decorated [48841,50575]
decorated [49344,51078]
===
match
---
atom_expr [70257,70267]
atom_expr [70760,70770]
===
match
---
simple_stmt [34473,34490]
simple_stmt [34976,34993]
===
match
---
name: debug [65701,65706]
name: debug [66204,66209]
===
match
---
name: handle_failure_with_callback [24973,25001]
name: handle_failure_with_callback [24973,25001]
===
match
---
arglist [7744,7768]
arglist [7744,7768]
===
match
---
suite [44198,44769]
suite [44701,45272]
===
match
---
name: self [12243,12247]
name: self [12243,12247]
===
match
---
name: provide_session [32695,32710]
name: provide_session [33198,33213]
===
match
---
trailer [79679,79704]
trailer [80182,80207]
===
match
---
name: str [40097,40100]
name: str [40600,40603]
===
match
---
arglist [31244,31297]
arglist [31621,31674]
===
match
---
name: _verify_integrity_if_dag_changed [76065,76097]
name: _verify_integrity_if_dag_changed [76568,76600]
===
match
---
operator: , [68085,68086]
operator: , [68588,68589]
===
match
---
except_clause [55649,55665]
except_clause [56152,56168]
===
match
---
name: errors [22064,22070]
name: errors [22064,22070]
===
match
---
name: List [1220,1224]
name: List [1220,1224]
===
match
---
atom_expr [51675,51687]
atom_expr [52178,52190]
===
match
---
name: filter [38605,38611]
name: filter [39108,39114]
===
match
---
atom_expr [74289,74300]
atom_expr [74792,74803]
===
match
---
name: ti [24527,24529]
name: ti [24527,24529]
===
match
---
string: 'polymorphic_identity' [29226,29248]
string: 'polymorphic_identity' [29480,29502]
===
match
---
atom_expr [27097,27146]
atom_expr [27097,27146]
===
match
---
atom_expr [18331,18338]
atom_expr [18331,18338]
===
match
---
name: TI [18000,18002]
name: TI [18000,18002]
===
match
---
name: key [47137,47140]
name: key [47640,47643]
===
match
---
expr_stmt [52265,52307]
expr_stmt [52768,52810]
===
match
---
name: dags [24352,24356]
name: dags [24352,24356]
===
match
---
string: 'scheduler' [57701,57712]
string: 'scheduler' [58204,58215]
===
match
---
operator: { [6927,6928]
operator: { [6927,6928]
===
match
---
trailer [81955,81965]
trailer [82458,82468]
===
match
---
name: self [48746,48750]
name: self [49249,49253]
===
match
---
trailer [40947,40951]
trailer [41450,41454]
===
match
---
name: State [49658,49663]
name: State [50161,50166]
===
match
---
name: Session [77868,77875]
name: Session [78371,78378]
===
match
---
name: self [54178,54182]
name: self [54681,54685]
===
match
---
name: utcnow [17155,17161]
name: utcnow [17155,17161]
===
match
---
name: run_with_db_retries [78907,78926]
name: run_with_db_retries [79410,79429]
===
match
---
name: self [77678,77682]
name: self [78181,78185]
===
match
---
atom_expr [20904,20948]
atom_expr [20904,20948]
===
match
---
atom_expr [77038,77080]
atom_expr [77541,77583]
===
match
---
funcdef [61144,66701]
funcdef [61647,67204]
===
match
---
operator: , [1313,1314]
operator: , [1313,1314]
===
match
---
simple_stmt [11141,11170]
simple_stmt [11141,11170]
===
match
---
trailer [74122,74147]
trailer [74625,74650]
===
match
---
simple_stmt [23170,23216]
simple_stmt [23170,23216]
===
match
---
arglist [26398,26448]
arglist [26398,26448]
===
match
---
name: start_date [34706,34716]
name: start_date [35209,35219]
===
match
---
trailer [54134,54169]
trailer [54637,54672]
===
match
---
simple_stmt [1248,1286]
simple_stmt [1248,1286]
===
match
---
trailer [30609,30625]
trailer [30863,30879]
===
match
---
name: unfinished_task_instances [73507,73532]
name: unfinished_task_instances [74010,74035]
===
match
---
operator: = [50425,50426]
operator: = [50928,50929]
===
match
---
trailer [45408,45481]
trailer [45911,45984]
===
match
---
trailer [21355,21357]
trailer [21355,21357]
===
match
---
atom_expr [23237,23276]
atom_expr [23237,23276]
===
match
---
name: options [38654,38661]
name: options [39157,39164]
===
match
---
atom_expr [32585,32602]
atom_expr [33088,33105]
===
match
---
name: _dag_ids [4169,4177]
name: _dag_ids [4169,4177]
===
match
---
argument [24092,24131]
argument [24092,24131]
===
match
---
trailer [48476,48494]
trailer [48979,48997]
===
match
---
argument [23979,24016]
argument [23979,24016]
===
match
---
simple_stmt [2819,2885]
simple_stmt [2819,2885]
===
match
---
name: manage_slas [15404,15415]
name: manage_slas [15404,15415]
===
match
---
trailer [50433,50438]
trailer [50936,50941]
===
match
---
trailer [73968,73973]
trailer [74471,74476]
===
match
---
name: List [22527,22531]
name: List [22527,22531]
===
match
---
except_clause [31577,31593]
except_clause [32080,32096]
===
match
---
trailer [57487,57635]
trailer [57990,58138]
===
match
---
name: self [9013,9017]
name: self [9013,9017]
===
match
---
trailer [79487,79493]
trailer [79990,79996]
===
match
---
name: executor [49161,49169]
name: executor [49664,49672]
===
match
---
comparison [79475,79510]
comparison [79978,80013]
===
match
---
trailer [81308,81310]
trailer [81811,81813]
===
match
---
name: __get_concurrency_maps [35895,35917]
name: __get_concurrency_maps [36398,36420]
===
match
---
name: dag_id [36905,36911]
name: dag_id [37408,37414]
===
match
---
name: rollback [82588,82596]
name: rollback [83091,83099]
===
match
---
simple_stmt [15474,15773]
simple_stmt [15474,15773]
===
match
---
name: AirflowException [1639,1655]
name: AirflowException [1639,1655]
===
match
---
operator: - [29514,29515]
operator: - [29768,29769]
===
match
---
string: 'scheduler.tasks.starving' [45118,45144]
string: 'scheduler.tasks.starving' [45621,45647]
===
match
---
name: processor_agent [59940,59955]
name: processor_agent [60443,60458]
===
match
---
operator: = [76648,76649]
operator: = [77151,77152]
===
match
---
simple_stmt [5413,6427]
simple_stmt [5413,6427]
===
match
---
param [66771,66778]
param [67274,67281]
===
match
---
name: DagBag [22500,22506]
name: DagBag [22500,22506]
===
match
---
name: dag_ids [4180,4187]
name: dag_ids [4180,4187]
===
match
---
trailer [18037,18041]
trailer [18037,18041]
===
match
---
operator: != [80749,80751]
operator: != [81252,81254]
===
match
---
simple_stmt [81876,81967]
simple_stmt [82379,82470]
===
match
---
name: datetime [72614,72622]
name: datetime [73117,73125]
===
match
---
comparison [32584,32678]
comparison [33087,33181]
===
match
---
operator: , [54378,54379]
operator: , [54881,54882]
===
match
---
simple_stmt [81425,81448]
simple_stmt [81928,81951]
===
match
---
name: dag_id [46539,46545]
name: dag_id [47042,47048]
===
match
---
suite [27242,27546]
suite [27242,27546]
===
match
---
raise_stmt [77617,77668]
raise_stmt [78120,78171]
===
match
---
name: pool_name [38738,38747]
name: pool_name [39241,39250]
===
match
---
trailer [24972,25001]
trailer [24972,25001]
===
match
---
name: delete [22135,22141]
name: delete [22135,22141]
===
match
---
simple_stmt [59914,59920]
simple_stmt [60417,60423]
===
match
---
operator: = [4220,4221]
operator: = [4220,4221]
===
match
---
trailer [39368,39372]
trailer [39871,39875]
===
match
---
name: task_instance [39898,39911]
name: task_instance [40401,40414]
===
match
---
trailer [78152,78159]
trailer [78655,78662]
===
match
---
operator: , [9149,9150]
operator: , [9149,9150]
===
match
---
arglist [54059,54095]
arglist [54562,54598]
===
match
---
operator: , [45964,45965]
operator: , [46467,46468]
===
match
---
atom_expr [15781,15835]
atom_expr [15781,15835]
===
match
---
expr_stmt [48656,48736]
expr_stmt [49159,49239]
===
match
---
simple_stmt [896,906]
simple_stmt [896,906]
===
match
---
atom_expr [3975,3994]
atom_expr [3975,3994]
===
match
---
name: isinstance [23237,23247]
name: isinstance [23237,23247]
===
match
---
trailer [79602,79619]
trailer [80105,80122]
===
match
---
simple_stmt [30992,31040]
simple_stmt [31246,31294]
===
match
---
name: list [20529,20533]
name: list [20529,20533]
===
match
---
trailer [16338,16346]
trailer [16338,16346]
===
match
---
operator: , [5338,5339]
operator: , [5338,5339]
===
match
---
atom [37524,37526]
atom [38027,38029]
===
match
---
trailer [71987,72003]
trailer [72490,72506]
===
match
---
name: _process [11485,11493]
name: _process [11485,11493]
===
match
---
expr_stmt [73507,73762]
expr_stmt [74010,74265]
===
match
---
atom_expr [81342,81403]
atom_expr [81845,81906]
===
match
---
atom_expr [29731,29742]
atom_expr [29985,29996]
===
match
---
atom_expr [54584,54591]
atom_expr [55087,55094]
===
match
---
name: tis_to_set_to_scheduled [50100,50123]
name: tis_to_set_to_scheduled [50603,50626]
===
match
---
trailer [11548,11553]
trailer [11548,11553]
===
match
---
atom_expr [68311,68325]
atom_expr [68814,68828]
===
match
---
name: redirect_stdout [1036,1051]
name: redirect_stdout [1036,1051]
===
match
---
trailer [81881,81886]
trailer [82384,82389]
===
match
---
name: TypeError [16890,16899]
name: TypeError [16890,16899]
===
match
---
name: pool [37998,38002]
name: pool [38501,38505]
===
match
---
lambdef [41280,41331]
lambdef [41783,41834]
===
match
---
name: commit [60848,60854]
name: commit [61351,61357]
===
match
---
atom_expr [74865,74884]
atom_expr [75368,75387]
===
match
---
atom_expr [23369,23408]
atom_expr [23369,23408]
===
match
---
atom_expr [24479,24510]
atom_expr [24479,24510]
===
match
---
operator: , [2326,2327]
operator: , [2326,2327]
===
match
---
name: SCHEDULED [50211,50220]
name: SCHEDULED [50714,50723]
===
match
---
trailer [54574,54581]
trailer [55077,55084]
===
match
---
simple_stmt [58681,58703]
simple_stmt [59184,59206]
===
match
---
annassign [16454,16699]
annassign [16454,16699]
===
match
---
arglist [74602,74630]
arglist [75105,75133]
===
match
---
operator: += [44922,44924]
operator: += [45425,45427]
===
match
---
name: session [17632,17639]
name: session [17632,17639]
===
match
---
name: dag_model [42219,42228]
name: dag_model [42722,42731]
===
match
---
atom_expr [24824,24832]
atom_expr [24824,24832]
===
match
---
name: SUCCESS [51695,51702]
name: SUCCESS [52198,52205]
===
match
---
string: 'mysql' [16183,16190]
string: 'mysql' [16183,16190]
===
match
---
trailer [23778,23780]
trailer [23778,23780]
===
match
---
name: self [60158,60162]
name: self [60661,60665]
===
match
---
trailer [18986,19004]
trailer [18986,19004]
===
match
---
expr_stmt [24472,24510]
expr_stmt [24472,24510]
===
match
---
simple_stmt [30174,30201]
simple_stmt [30428,30455]
===
match
---
name: executor [54609,54617]
name: executor [55112,55120]
===
match
---
number: 0 [26768,26769]
number: 0 [26768,26769]
===
match
---
trailer [13912,13917]
trailer [13912,13917]
===
match
---
name: State [78248,78253]
name: State [78751,78756]
===
match
---
atom_expr [40866,40885]
atom_expr [41369,41388]
===
match
---
name: info [45404,45408]
name: info [45907,45911]
===
match
---
operator: = [29675,29676]
operator: = [29929,29930]
===
match
---
decorator [11998,12008]
decorator [11998,12008]
===
match
---
atom_expr [20377,20404]
atom_expr [20377,20404]
===
match
---
name: self [58809,58813]
name: self [59312,59316]
===
match
---
operator: , [36535,36536]
operator: , [37038,37039]
===
match
---
operator: , [79102,79103]
operator: , [79605,79606]
===
match
---
simple_stmt [65797,65856]
simple_stmt [66300,66359]
===
match
---
trailer [51286,51294]
trailer [51789,51797]
===
match
---
name: ti [81571,81573]
name: ti [82074,82076]
===
match
---
and_test [74666,74744]
and_test [75169,75247]
===
match
---
simple_stmt [67089,67136]
simple_stmt [67592,67639]
===
match
---
trailer [77920,77932]
trailer [78423,78435]
===
match
---
simple_stmt [14242,14311]
simple_stmt [14242,14311]
===
match
---
atom_expr [51280,51294]
atom_expr [51783,51797]
===
match
---
name: settings [8481,8489]
name: settings [8481,8489]
===
match
---
suite [58547,58792]
suite [59050,59295]
===
match
---
name: _change_state_for_tis_without_dagrun [60586,60622]
name: _change_state_for_tis_without_dagrun [61089,61125]
===
match
---
name: Stats [7152,7157]
name: Stats [7152,7157]
===
match
---
atom_expr [41236,41345]
atom_expr [41739,41848]
===
match
---
return_stmt [27052,27087]
return_stmt [27052,27087]
===
match
---
trailer [51869,51883]
trailer [52372,52386]
===
match
---
atom_expr [32783,32792]
atom_expr [33286,33295]
===
match
---
param [46127,46132]
param [46630,46635]
===
match
---
not_test [73173,73180]
not_test [73676,73683]
===
match
---
operator: , [75208,75209]
operator: , [75711,75712]
===
match
---
atom_expr [50082,50124]
atom_expr [50585,50627]
===
match
---
name: executable_tis [38126,38140]
name: executable_tis [38629,38643]
===
match
---
name: execution_date [74674,74688]
name: execution_date [75177,75191]
===
match
---
atom_expr [16257,16314]
atom_expr [16257,16314]
===
match
---
name: __class__ [23674,23683]
name: __class__ [23674,23683]
===
match
---
expr_stmt [27337,27470]
expr_stmt [27337,27470]
===
match
---
atom_expr [80140,80171]
atom_expr [80643,80674]
===
match
---
operator: , [16145,16146]
operator: , [16145,16146]
===
match
---
simple_stmt [27198,27218]
simple_stmt [27198,27218]
===
match
---
atom_expr [74666,74688]
atom_expr [75169,75191]
===
match
---
name: get_dag [71642,71649]
name: get_dag [72145,72152]
===
match
---
name: dag_model [46945,46954]
name: dag_model [47448,47457]
===
match
---
name: dag_hash [68812,68820]
name: dag_hash [69315,69323]
===
match
---
expr_stmt [45322,45386]
expr_stmt [45825,45889]
===
match
---
name: slas [19209,19213]
name: slas [19209,19213]
===
match
---
for_stmt [36805,36970]
for_stmt [37308,37473]
===
match
---
name: timestamp [22338,22347]
name: timestamp [22338,22347]
===
match
---
trailer [29735,29742]
trailer [29989,29996]
===
match
---
argument [41276,41331]
argument [41779,41834]
===
match
---
atom_expr [20578,20593]
atom_expr [20578,20593]
===
match
---
trailer [65376,65383]
trailer [65879,65886]
===
match
---
simple_stmt [20019,20168]
simple_stmt [20019,20168]
===
match
---
operator: = [30659,30660]
operator: = [30913,30914]
===
match
---
number: 80 [31818,31820]
number: 80 [32321,32323]
===
match
---
trailer [20137,20145]
trailer [20137,20145]
===
match
---
name: thread_name [5322,5333]
name: thread_name [5322,5333]
===
match
---
atom_expr [17360,17440]
atom_expr [17360,17440]
===
match
---
testlist_comp [49255,49782]
testlist_comp [49758,50285]
===
match
---
trailer [78253,78261]
trailer [78756,78764]
===
match
---
simple_stmt [11773,11839]
simple_stmt [11773,11839]
===
match
---
operator: = [76532,76533]
operator: = [77035,77036]
===
match
---
name: end_date [24746,24754]
name: end_date [24746,24754]
===
match
---
import_from [996,1061]
import_from [996,1061]
===
match
---
operator: @ [23786,23787]
operator: @ [23786,23787]
===
match
---
name: dagrun [1923,1929]
name: dagrun [1923,1929]
===
match
---
trailer [53398,53414]
trailer [53901,53917]
===
match
---
trailer [50197,50203]
trailer [50700,50706]
===
match
---
atom_expr [10789,10802]
atom_expr [10789,10802]
===
match
---
atom_expr [52408,52420]
atom_expr [52911,52923]
===
match
---
name: to_reset [81845,81853]
name: to_reset [82348,82356]
===
match
---
trailer [35340,35342]
trailer [35843,35845]
===
match
---
operator: , [35778,35779]
operator: , [36281,36282]
===
match
---
trailer [72472,72484]
trailer [72975,72987]
===
match
---
name: sig_name [31734,31742]
name: sig_name [32237,32245]
===
match
---
operator: , [57526,57527]
operator: , [58029,58030]
===
match
---
trailer [7618,7623]
trailer [7618,7623]
===
match
---
name: log [26926,26929]
name: log [26926,26929]
===
match
---
string: 'base_url' [19734,19744]
string: 'base_url' [19734,19744]
===
match
---
string: """         Unconditionally create a DAG run for the given DAG, and update the dag_model's fields to control         if/when the next DAGRun should be created         """ [67414,67584]
string: """         Unconditionally create a DAG run for the given DAG, and update the dag_model's fields to control         if/when the next DAGRun should be created         """ [67917,68087]
===
match
---
simple_stmt [75354,75426]
simple_stmt [75857,75929]
===
match
---
argument [60530,60545]
argument [61033,61048]
===
match
---
simple_stmt [18911,18930]
simple_stmt [18911,18930]
===
match
---
name: executable_tis [39437,39451]
name: executable_tis [39940,39954]
===
match
---
trailer [65488,65490]
trailer [65991,65993]
===
match
---
name: self [52485,52489]
name: self [52988,52992]
===
match
---
trailer [33572,33579]
trailer [34075,34082]
===
match
---
subscriptlist [40039,40047]
subscriptlist [40542,40550]
===
match
---
trailer [52588,52599]
trailer [53091,53102]
===
match
---
atom_expr [75278,75300]
atom_expr [75781,75803]
===
match
---
name: append [20230,20236]
name: append [20230,20236]
===
match
---
trailer [81678,81701]
trailer [82181,82204]
===
match
---
name: loop_count [57999,58009]
name: loop_count [58502,58512]
===
match
---
trailer [27001,27022]
trailer [27001,27022]
===
match
---
operator: = [57265,57266]
operator: = [57768,57769]
===
match
---
name: close [11162,11167]
name: close [11162,11167]
===
match
---
suite [15291,15374]
suite [15291,15374]
===
match
---
name: log [47069,47072]
name: log [47572,47575]
===
match
---
name: SIGUSR2 [31013,31020]
name: SIGUSR2 [31267,31274]
===
match
---
atom_expr [74368,74390]
atom_expr [74871,74893]
===
match
---
atom_expr [10901,10925]
atom_expr [10901,10925]
===
match
---
if_stmt [24918,25141]
if_stmt [24918,25141]
===
match
---
name: self [10930,10934]
name: self [10930,10934]
===
match
---
parameters [78328,78359]
parameters [78831,78862]
===
match
---
arglist [67166,67186]
arglist [67669,67689]
===
match
---
name: pool_slots_free [38035,38050]
name: pool_slots_free [38538,38553]
===
match
---
suite [41472,45016]
suite [41975,45519]
===
match
---
trailer [20346,20352]
trailer [20346,20352]
===
match
---
name: tasks_missed_sla [20213,20229]
name: tasks_missed_sla [20213,20229]
===
match
---
trailer [34692,34705]
trailer [35195,35208]
===
match
---
name: info [51338,51342]
name: info [51841,51845]
===
match
---
name: List [18215,18219]
name: List [18215,18219]
===
match
---
name: processor_agent [57157,57172]
name: processor_agent [57660,57675]
===
match
---
name: debug [12578,12583]
name: debug [12578,12583]
===
match
---
operator: , [2427,2428]
operator: , [2427,2428]
===
match
---
name: include_smart_sensor [26527,26547]
name: include_smart_sensor [26527,26547]
===
match
---
atom_expr [50928,50960]
atom_expr [51431,51463]
===
match
---
simple_stmt [1903,1944]
simple_stmt [1903,1944]
===
match
---
name: timezone [2204,2212]
name: timezone [2204,2212]
===
match
---
atom_expr [39746,39757]
atom_expr [40249,40260]
===
match
---
trailer [39884,39889]
trailer [40387,40392]
===
match
---
trailer [45587,45602]
trailer [46090,46105]
===
match
---
suite [19847,19901]
suite [19847,19901]
===
match
---
expr_stmt [58723,58791]
expr_stmt [59226,59294]
===
match
---
name: dag_run [76342,76349]
name: dag_run [76845,76852]
===
match
---
operator: , [23735,23736]
operator: , [23735,23736]
===
match
---
arglist [23979,24033]
arglist [23979,24033]
===
match
---
name: slas [19821,19825]
name: slas [19821,19825]
===
match
---
trailer [32366,32401]
trailer [32869,32904]
===
match
---
name: ti [47043,47045]
name: ti [47546,47548]
===
match
---
name: append [39891,39897]
name: append [40394,40400]
===
match
---
argument [60946,60953]
argument [61449,61456]
===
match
---
name: fallback [57561,57569]
name: fallback [58064,58072]
===
match
---
if_stmt [71935,72503]
if_stmt [72438,73006]
===
match
---
operator: , [50220,50221]
operator: , [50723,50724]
===
match
---
suite [37185,46076]
suite [37688,46579]
===
match
---
not_test [16831,16866]
not_test [16831,16866]
===
match
---
name: scheduler_health_check_threshold [32646,32678]
name: scheduler_health_check_threshold [33149,33181]
===
match
---
operator: = [53135,53136]
operator: = [53638,53639]
===
match
---
name: self [30791,30795]
name: self [31045,31049]
===
match
---
name: str [56109,56112]
name: str [56612,56615]
===
match
---
name: DagFileProcessorAgent [2429,2450]
name: DagFileProcessorAgent [2429,2450]
===
match
---
atom_expr [69681,69702]
atom_expr [70184,70205]
===
match
---
name: _child_channel [8783,8797]
name: _child_channel [8783,8797]
===
match
---
trailer [58648,58658]
trailer [59151,59161]
===
match
---
name: _done [13140,13145]
name: _done [13140,13145]
===
match
---
operator: - [70152,70153]
operator: - [70655,70656]
===
match
---
name: str [32805,32808]
name: str [33308,33311]
===
match
---
if_stmt [51818,51884]
if_stmt [52321,52387]
===
match
---
name: redirect_stdout [7016,7031]
name: redirect_stdout [7016,7031]
===
match
---
operator: , [66769,66770]
operator: , [67272,67273]
===
match
---
operator: = [32827,32828]
operator: = [33330,33331]
===
match
---
arith_expr [64250,64288]
arith_expr [64753,64791]
===
match
---
for_stmt [22967,23755]
for_stmt [22967,23755]
===
match
---
operator: = [52739,52740]
operator: = [53242,53243]
===
match
---
operator: , [74018,74019]
operator: , [74521,74522]
===
match
---
trailer [8276,8312]
trailer [8276,8312]
===
match
---
not_test [57148,57172]
not_test [57651,57675]
===
match
---
trailer [57417,57447]
trailer [57920,57950]
===
match
---
arglist [59088,59127]
arglist [59591,59630]
===
match
---
name: OperationalError [1366,1382]
name: OperationalError [1366,1382]
===
match
---
operator: , [36992,36993]
operator: , [37495,37496]
===
match
---
atom_expr [27800,27811]
atom_expr [27800,27811]
===
match
---
import_as_names [2761,2818]
import_as_names [2761,2818]
===
match
---
trailer [49775,49780]
trailer [50278,50283]
===
match
---
simple_stmt [35806,35865]
simple_stmt [36309,36368]
===
match
---
name: dag_model [68514,68523]
name: dag_model [69017,69026]
===
match
---
name: tis_to_reset_or_adopt [81679,81700]
name: tis_to_reset_or_adopt [82182,82203]
===
match
---
name: dag_id [70261,70267]
name: dag_id [70764,70770]
===
match
---
operator: = [54340,54341]
operator: = [54843,54844]
===
match
---
name: is_alive [31831,31839]
name: is_alive [32334,32342]
===
match
---
atom_expr [38662,38687]
atom_expr [39165,39190]
===
match
---
trailer [77469,77473]
trailer [77972,77976]
===
match
---
name: not_ [1321,1325]
name: not_ [1321,1325]
===
match
---
name: dag_ids [54441,54448]
name: dag_ids [54944,54951]
===
match
---
name: get [71904,71907]
name: get [72407,72410]
===
match
---
name: dag [70017,70020]
name: dag [70520,70523]
===
match
---
trailer [17674,17740]
trailer [17674,17740]
===
match
---
operator: = [60797,60798]
operator: = [61300,61301]
===
match
---
name: msg [52959,52962]
name: msg [53462,53465]
===
match
---
arglist [80733,80906]
arglist [81236,81409]
===
match
---
simple_stmt [18386,18410]
simple_stmt [18386,18410]
===
match
---
name: pid [11380,11383]
name: pid [11380,11383]
===
match
---
arglist [18066,18150]
arglist [18066,18150]
===
match
---
operator: , [66955,66956]
operator: , [67458,67459]
===
match
---
name: DR [38458,38460]
name: DR [38961,38963]
===
match
---
trailer [16488,16494]
trailer [16488,16494]
===
match
---
arglist [7048,7065]
arglist [7048,7065]
===
match
---
name: QUEUED [52414,52420]
name: QUEUED [52917,52923]
===
match
---
name: ti [18354,18356]
name: ti [18354,18356]
===
match
---
try_stmt [19843,20197]
try_stmt [19843,20197]
===
match
---
trailer [75358,75391]
trailer [75861,75894]
===
match
---
operator: , [24151,24152]
operator: , [24151,24152]
===
match
---
trailer [46944,46954]
trailer [47447,47457]
===
match
---
import_as_names [1552,1568]
import_as_names [1552,1568]
===
match
---
atom_expr [13320,13344]
atom_expr [13320,13344]
===
match
---
operator: @ [21363,21364]
operator: @ [21363,21364]
===
match
---
name: Dict [50854,50858]
name: Dict [51357,51361]
===
match
---
for_stmt [18241,18508]
for_stmt [18241,18508]
===
match
---
trailer [35817,35864]
trailer [36320,36367]
===
match
---
trailer [17224,17230]
trailer [17224,17230]
===
match
---
simple_stmt [48813,48836]
simple_stmt [49316,49339]
===
match
---
name: task_id [17031,17038]
name: task_id [17031,17038]
===
match
---
atom_expr [18297,18309]
atom_expr [18297,18309]
===
match
---
string: 'sla_email_notification_failure' [20915,20947]
string: 'sla_email_notification_failure' [20915,20947]
===
match
---
name: dag_models [71419,71429]
name: dag_models [71922,71932]
===
match
---
operator: = [59049,59050]
operator: = [59552,59553]
===
match
---
name: pool [41614,41618]
name: pool [42117,42121]
===
match
---
trailer [80549,80556]
trailer [81052,81059]
===
match
---
name: TI [37518,37520]
name: TI [38021,38023]
===
match
---
operator: { [45832,45833]
operator: { [46335,46336]
===
match
---
name: query [18032,18037]
name: query [18032,18037]
===
match
---
name: task_instance_str [39672,39689]
name: task_instance_str [40175,40192]
===
match
---
name: self [61163,61167]
name: self [61666,61670]
===
match
---
expr_stmt [26476,26554]
expr_stmt [26476,26554]
===
match
---
trailer [33610,33637]
trailer [34113,34140]
===
match
---
trailer [59201,59210]
trailer [59704,59713]
===
match
---
name: task_instance [44160,44173]
name: task_instance [44663,44676]
===
match
---
trailer [15927,15932]
trailer [15927,15932]
===
match
---
name: lower [79918,79923]
name: lower [80421,80426]
===
match
---
name: sqlalchemy [1291,1301]
name: sqlalchemy [1291,1301]
===
match
---
operator: = [54199,54200]
operator: = [54702,54703]
===
match
---
operator: , [59194,59195]
operator: , [59697,59698]
===
match
---
arglist [7118,7135]
arglist [7118,7135]
===
match
---
trailer [41242,41345]
trailer [41745,41848]
===
match
---
trailer [19075,19080]
trailer [19075,19080]
===
match
---
simple_stmt [57186,57238]
simple_stmt [57689,57741]
===
match
---
name: log [31235,31238]
name: log [31612,31615]
===
match
---
atom_expr [33531,33558]
atom_expr [34034,34061]
===
match
---
trailer [18353,18365]
trailer [18353,18365]
===
match
---
return_stmt [74844,74852]
return_stmt [75347,75355]
===
match
---
operator: , [79934,79935]
operator: , [80437,80438]
===
match
---
atom_expr [11341,11354]
atom_expr [11341,11354]
===
match
---
trailer [81587,81592]
trailer [82090,82095]
===
match
---
expr_stmt [77006,77029]
expr_stmt [77509,77532]
===
match
---
name: dag [68849,68852]
name: dag [69352,69355]
===
match
---
suite [58118,58497]
suite [58621,59000]
===
match
---
name: gauge [78196,78201]
name: gauge [78699,78704]
===
match
---
atom_expr [59935,59960]
atom_expr [60438,60463]
===
match
---
atom_expr [45250,45312]
atom_expr [45753,45815]
===
match
---
atom_expr [3984,3993]
atom_expr [3984,3993]
===
match
---
name: sentinel [14418,14426]
name: sentinel [14418,14426]
===
match
---
name: DagRun [68432,68438]
name: DagRun [68935,68941]
===
match
---
testlist_comp [79990,80034]
testlist_comp [80493,80537]
===
match
---
trailer [58533,58535]
trailer [59036,59038]
===
match
---
name: info [19076,19080]
name: info [19076,19080]
===
match
---
trailer [24387,24405]
trailer [24387,24405]
===
match
---
operator: , [2797,2798]
operator: , [2797,2798]
===
match
---
dotted_name [2183,2196]
dotted_name [2183,2196]
===
match
---
name: State [50205,50210]
name: State [50708,50713]
===
match
---
if_stmt [35541,35865]
if_stmt [36044,36368]
===
match
---
operator: , [22506,22507]
operator: , [22506,22507]
===
match
---
name: callback_requests [27128,27145]
name: callback_requests [27128,27145]
===
match
---
simple_stmt [53394,53449]
simple_stmt [53897,53952]
===
match
---
name: self [10441,10445]
name: self [10441,10445]
===
match
---
name: str [51116,51119]
name: str [51619,51622]
===
match
---
atom_expr [35336,35350]
atom_expr [35839,35853]
===
match
---
atom_expr [79386,79704]
atom_expr [79889,80207]
===
match
---
name: state [51109,51114]
name: state [51612,51617]
===
match
---
name: e [66297,66298]
name: e [66800,66801]
===
match
---
trailer [55630,55634]
trailer [56133,56137]
===
match
---
trailer [10914,10923]
trailer [10914,10923]
===
match
---
atom_expr [7152,7165]
atom_expr [7152,7165]
===
match
---
name: pickle_dags [54477,54488]
name: pickle_dags [54980,54991]
===
match
---
arglist [57283,57307]
arglist [57786,57810]
===
match
---
name: dag_id [68014,68020]
name: dag_id [68517,68523]
===
match
---
testlist_comp [71127,71155]
testlist_comp [71630,71658]
===
match
---
name: log [15270,15273]
name: log [15270,15273]
===
match
---
atom_expr [20467,20477]
atom_expr [20467,20477]
===
match
---
arglist [76298,76329]
arglist [76801,76832]
===
match
---
if_stmt [45490,45980]
if_stmt [45993,46483]
===
match
---
trailer [42261,42265]
trailer [42764,42768]
===
match
---
simple_stmt [66569,66588]
simple_stmt [67072,67091]
===
match
---
atom [68299,68326]
atom [68802,68829]
===
match
---
name: task_concurrency_map [40142,40162]
name: task_concurrency_map [40645,40665]
===
match
---
param [13726,13730]
param [13726,13730]
===
match
---
name: State [73861,73866]
name: State [74364,74369]
===
match
---
simple_stmt [23954,24035]
simple_stmt [23954,24035]
===
match
---
name: false [71304,71309]
name: false [71807,71812]
===
match
---
name: session [76322,76329]
name: session [76825,76832]
===
match
---
arglist [35240,35432]
arglist [35743,35935]
===
match
---
operator: = [34612,34613]
operator: = [35115,35116]
===
match
---
string: "Tried to call terminate before starting!" [10388,10430]
string: "Tried to call terminate before starting!" [10388,10430]
===
match
---
trailer [24292,24313]
trailer [24292,24313]
===
match
---
name: ti_concurrency_query [36446,36466]
name: ti_concurrency_query [36949,36969]
===
match
---
name: setproctitle [1273,1285]
name: setproctitle [1273,1285]
===
match
---
name: start [54618,54623]
name: start [55121,55126]
===
match
---
operator: , [50634,50635]
operator: , [51137,51138]
===
match
---
operator: , [48615,48616]
operator: , [49118,49119]
===
match
---
operator: , [68430,68431]
operator: , [68933,68934]
===
match
---
name: info [41538,41542]
name: info [42041,42045]
===
match
---
trailer [73597,73604]
trailer [74100,74107]
===
match
---
name: start_method [8641,8653]
name: start_method [8641,8653]
===
match
---
expr_stmt [29761,29785]
expr_stmt [30015,30039]
===
match
---
comparison [49646,49670]
comparison [50149,50173]
===
match
---
trailer [16390,16398]
trailer [16390,16398]
===
match
---
name: execution_date [23979,23993]
name: execution_date [23979,23993]
===
match
---
name: TI [49314,49316]
name: TI [49817,49819]
===
match
---
tfpdef [25231,25271]
tfpdef [25231,25271]
===
match
---
decorated [56040,56480]
decorated [56543,56983]
===
match
---
trailer [53528,53532]
trailer [54031,54035]
===
match
---
operator: = [57569,57570]
operator: = [58072,58073]
===
match
---
trailer [12674,12690]
trailer [12674,12690]
===
match
---
name: self [73194,73198]
name: self [73697,73701]
===
match
---
operator: = [47002,47003]
operator: = [47505,47506]
===
match
---
param [31072,31079]
param [31326,31333]
===
match
---
expr_stmt [67089,67135]
expr_stmt [67592,67638]
===
match
---
name: task_instances [46461,46475]
name: task_instances [46964,46978]
===
match
---
operator: { [79680,79681]
operator: { [80183,80184]
===
match
---
operator: , [46757,46758]
operator: , [47260,47261]
===
match
---
name: self [4872,4876]
name: self [4872,4876]
===
match
---
name: session [25316,25323]
name: session [25316,25323]
===
match
---
name: airflow [2523,2530]
name: airflow [2523,2530]
===
match
---
decorated [5080,8540]
decorated [5080,8540]
===
match
---
suite [50335,50398]
suite [50838,50901]
===
match
---
name: conf [57852,57856]
name: conf [58355,58359]
===
match
---
string: "\n\t" [45342,45348]
string: "\n\t" [45845,45851]
===
match
---
trailer [53075,53085]
trailer [53578,53588]
===
match
---
atom_expr [78822,78882]
atom_expr [79325,79385]
===
match
---
name: ti [24970,24972]
name: ti [24970,24972]
===
match
---
funcdef [25167,27840]
funcdef [25167,27840]
===
match
---
atom_expr [71650,71666]
atom_expr [72153,72169]
===
match
---
name: TI [49353,49355]
name: TI [49856,49858]
===
match
---
trailer [16278,16286]
trailer [16278,16286]
===
match
---
annassign [4325,4379]
annassign [4325,4379]
===
match
---
name: log [55474,55477]
name: log [55977,55980]
===
match
---
tfpdef [3915,3929]
tfpdef [3915,3929]
===
match
---
name: info [7619,7623]
name: info [7619,7623]
===
match
---
name: exception [68700,68709]
name: exception [69203,69212]
===
match
---
atom_expr [67166,67177]
atom_expr [67669,67680]
===
match
---
suite [36840,36970]
suite [37343,37473]
===
match
---
subscriptlist [50865,50892]
subscriptlist [51368,51395]
===
match
---
name: isinstance [23108,23118]
name: isinstance [23108,23118]
===
match
---
name: Stats [81876,81881]
name: Stats [82379,82384]
===
match
---
fstring_string: \             Here's a list of tasks that missed their SLAs:             <pre><code> [19470,19554]
fstring_string: \             Here's a list of tasks that missed their SLAs:             <pre><code> [19470,19554]
===
match
---
argument [46854,46866]
argument [47357,47369]
===
match
---
simple_stmt [19249,19274]
simple_stmt [19249,19274]
===
match
---
name: self [30272,30276]
name: self [30526,30530]
===
match
---
string: "Deactivating DAGs that haven't been touched since %s" [55170,55224]
string: "Deactivating DAGs that haven't been touched since %s" [55673,55727]
===
match
---
for_stmt [34375,34490]
for_stmt [34878,34993]
===
match
---
testlist_comp [43686,43729]
testlist_comp [44189,44232]
===
match
---
name: self [13621,13625]
name: self [13621,13625]
===
match
---
simple_stmt [72285,72327]
simple_stmt [72788,72830]
===
match
---
atom_expr [33473,33995]
atom_expr [33976,34498]
===
match
---
name: session [35952,35959]
name: session [36455,36462]
===
match
---
trailer [19378,19437]
trailer [19378,19437]
===
match
---
parameters [31839,31887]
parameters [32342,32390]
===
match
---
trailer [57838,57985]
trailer [58341,58488]
===
match
---
operator: = [30282,30283]
operator: = [30536,30537]
===
match
---
atom_expr [9538,9560]
atom_expr [9538,9560]
===
match
---
simple_stmt [77560,77567]
simple_stmt [78063,78070]
===
match
---
operator: = [73106,73107]
operator: = [73609,73610]
===
match
---
operator: , [75300,75301]
operator: , [75803,75804]
===
match
---
atom_expr [18543,18554]
atom_expr [18543,18554]
===
match
---
operator: = [12546,12547]
operator: = [12546,12547]
===
match
---
name: execution_date [70044,70058]
name: execution_date [70547,70561]
===
match
---
name: UP_FOR_RETRY [60491,60503]
name: UP_FOR_RETRY [60994,61006]
===
match
---
name: TI [52028,52030]
name: TI [52531,52533]
===
match
---
simple_stmt [15151,15216]
simple_stmt [15151,15216]
===
match
---
operator: = [30078,30079]
operator: = [30332,30333]
===
match
---
trailer [36665,36667]
trailer [37168,37170]
===
match
---
atom_expr [73094,73105]
atom_expr [73597,73608]
===
match
---
atom_expr [77341,77360]
atom_expr [77844,77863]
===
match
---
trailer [16214,16221]
trailer [16214,16221]
===
match
---
trailer [67853,67858]
trailer [68356,68361]
===
match
---
simple_stmt [41359,41382]
simple_stmt [41862,41885]
===
match
---
trailer [33520,33530]
trailer [34023,34033]
===
match
---
name: start [54697,54702]
name: start [55200,55205]
===
match
---
atom_expr [55715,55774]
atom_expr [56218,56277]
===
match
---
name: commit [17531,17537]
name: commit [17531,17537]
===
match
---
name: self [57766,57770]
name: self [58269,58273]
===
match
---
trailer [36002,36012]
trailer [36505,36515]
===
match
---
atom_expr [13135,13145]
atom_expr [13135,13145]
===
match
---
name: models [3083,3089]
name: models [3083,3089]
===
match
---
atom_expr [15258,15267]
atom_expr [15258,15267]
===
match
---
atom_expr [22271,22403]
atom_expr [22271,22403]
===
match
---
name: key [52221,52224]
name: key [52724,52727]
===
match
---
name: session [45631,45638]
name: session [46134,46141]
===
match
---
name: get_dag [76610,76617]
name: get_dag [77113,77120]
===
match
---
trailer [34428,34456]
trailer [34931,34959]
===
match
---
name: errors [22091,22097]
name: errors [22091,22097]
===
match
---
name: self [15327,15331]
name: self [15327,15331]
===
match
---
name: self [3901,3905]
name: self [3901,3905]
===
match
---
name: max_tis [48579,48586]
name: max_tis [49082,49089]
===
match
---
trailer [18168,18172]
trailer [18168,18172]
===
match
---
name: start_date [69724,69734]
name: start_date [70227,70237]
===
match
---
suite [7175,8050]
suite [7175,8050]
===
match
---
name: info [52985,52989]
name: info [53488,53492]
===
match
---
trailer [44913,44921]
trailer [45416,45424]
===
match
---
name: log [23018,23021]
name: log [23018,23021]
===
match
---
operator: = [39022,39023]
operator: = [39525,39526]
===
match
---
operator: -> [8561,8563]
operator: -> [8561,8563]
===
match
---
atom_expr [30209,30242]
atom_expr [30463,30496]
===
match
---
name: session [80090,80097]
name: session [80593,80600]
===
match
---
tfpdef [37148,37164]
tfpdef [37651,37667]
===
match
---
name: send [8037,8041]
name: send [8037,8041]
===
match
---
name: callback_requests [56122,56139]
name: callback_requests [56625,56642]
===
match
---
atom_expr [57944,57974]
atom_expr [58447,58477]
===
match
---
simple_stmt [1762,1804]
simple_stmt [1762,1804]
===
match
---
trailer [53749,53754]
trailer [54252,54257]
===
match
---
name: generate_command [46502,46518]
name: generate_command [47005,47021]
===
match
---
operator: , [82197,82198]
operator: , [82700,82701]
===
match
---
name: session [61045,61052]
name: session [61548,61555]
===
match
---
name: State [51675,51680]
name: State [52178,52183]
===
match
---
atom_expr [26997,27039]
atom_expr [26997,27039]
===
match
---
trailer [43878,44102]
trailer [44381,44605]
===
match
---
name: getfloat [57692,57700]
name: getfloat [58195,58203]
===
match
---
and_test [32540,32678]
and_test [33043,33181]
===
match
---
trailer [77159,77169]
trailer [77662,77672]
===
match
---
name: Iterable [67359,67367]
name: Iterable [67862,67870]
===
match
---
name: airflow [1949,1956]
name: airflow [1949,1956]
===
match
---
trailer [73486,73493]
trailer [73989,73996]
===
match
---
name: self [53501,53505]
name: self [54004,54008]
===
match
---
name: task_id [17379,17386]
name: task_id [17379,17386]
===
match
---
operator: > [26802,26803]
operator: > [26802,26803]
===
match
---
simple_stmt [37952,38023]
simple_stmt [38455,38526]
===
match
---
name: executor_class [53687,53701]
name: executor_class [54190,54204]
===
match
---
name: Exception [23503,23512]
name: Exception [23503,23512]
===
match
---
suite [52421,52570]
suite [52924,53073]
===
match
---
atom_expr [48523,48552]
atom_expr [49026,49055]
===
match
---
operator: , [15430,15431]
operator: , [15430,15431]
===
match
---
name: current_index [41776,41789]
name: current_index [42279,42292]
===
match
---
operator: = [54123,54124]
operator: = [54626,54627]
===
match
---
atom [60484,60504]
atom [60987,61007]
===
match
---
operator: , [1853,1854]
operator: , [1853,1854]
===
match
---
name: property [11999,12007]
name: property [11999,12007]
===
match
---
name: ti [46455,46457]
name: ti [46958,46960]
===
match
---
trailer [18172,18174]
trailer [18172,18174]
===
match
---
name: logging [6496,6503]
name: logging [6496,6503]
===
match
---
name: ti [25127,25129]
name: ti [25127,25129]
===
match
---
name: self [27729,27733]
name: self [27729,27733]
===
match
---
trailer [51694,51702]
trailer [52197,52205]
===
match
---
atom_expr [60687,60710]
atom_expr [61190,61213]
===
match
---
name: notification_sent [19249,19266]
name: notification_sent [19249,19266]
===
match
---
funcdef [48862,50575]
funcdef [49365,51078]
===
match
---
trailer [34575,34582]
trailer [35078,35085]
===
match
---
name: state [52399,52404]
name: state [52902,52907]
===
match
---
exprlist [77962,77983]
exprlist [78465,78486]
===
match
---
string: "Processing %s took %.3f seconds" [8071,8104]
string: "Processing %s took %.3f seconds" [8071,8104]
===
match
---
name: dag [24043,24046]
name: dag [24043,24046]
===
match
---
simple_stmt [62935,62981]
simple_stmt [63438,63484]
===
match
---
operator: <= [65590,65592]
operator: <= [66093,66095]
===
match
---
name: query [16057,16062]
name: query [16057,16062]
===
match
---
trailer [79888,79893]
trailer [80391,80396]
===
match
---
trailer [73964,73968]
trailer [74467,74471]
===
match
---
trailer [24482,24491]
trailer [24482,24491]
===
match
---
argument [7865,7884]
argument [7865,7884]
===
match
---
param [25207,25222]
param [25207,25222]
===
match
---
name: timers [57318,57324]
name: timers [57821,57827]
===
match
---
name: timers [59030,59036]
name: timers [59533,59539]
===
match
---
name: List [50991,50995]
name: List [51494,51498]
===
match
---
name: query [17640,17645]
name: query [17640,17645]
===
match
---
name: is_lock_not_available_error [2922,2949]
name: is_lock_not_available_error [2922,2949]
===
match
---
name: self [4619,4623]
name: self [4619,4623]
===
match
---
name: task_instance [43708,43721]
name: task_instance [44211,44224]
===
match
---
param [15422,15431]
param [15422,15431]
===
match
---
operator: = [16776,16777]
operator: = [16776,16777]
===
match
---
string: """Register signals that stop child processes""" [30814,30862]
string: """Register signals that stop child processes""" [31068,31116]
===
match
---
parameters [12020,12026]
parameters [12020,12026]
===
match
---
trailer [75658,75684]
trailer [76161,76187]
===
match
---
name: session [50133,50140]
name: session [50636,50643]
===
match
---
name: tis [51998,52001]
name: tis [52501,52504]
===
match
---
number: 5 [13298,13299]
number: 5 [13298,13299]
===
match
---
string: """         For the DAGs in the given DagBag, record any associated import errors and clears         errors for files that no longer have them. These are usually displayed through the         Airflow UI so that users know that there are issues parsing DAGs.          :param session: session for ORM operations         :type session: sqlalchemy.orm.session.Session         :param dagbag: DagBag containing DAGs with import errors         :type dagbag: airflow.DagBag         """ [21457,21934]
string: """         For the DAGs in the given DagBag, record any associated import errors and clears         errors for files that no longer have them. These are usually displayed through the         Airflow UI so that users know that there are issues parsing DAGs.          :param session: session for ORM operations         :type session: sqlalchemy.orm.session.Session         :param dagbag: DagBag containing DAGs with import errors         :type dagbag: airflow.DagBag         """ [21457,21934]
===
match
---
trailer [34638,34651]
trailer [35141,35154]
===
match
---
name: pickle_dags [25281,25292]
name: pickle_dags [25281,25292]
===
match
---
name: self [65692,65696]
name: self [66195,66199]
===
match
---
atom_expr [69780,69793]
atom_expr [70283,70296]
===
match
---
name: self [55715,55719]
name: self [56218,56222]
===
match
---
name: tis_to_change [34223,34236]
name: tis_to_change [34726,34739]
===
match
---
trailer [38163,38189]
trailer [38666,38692]
===
match
---
atom_expr [8656,8696]
atom_expr [8656,8696]
===
match
---
trailer [73254,73261]
trailer [73757,73764]
===
match
---
trailer [3089,3102]
trailer [3089,3102]
===
match
---
trailer [30937,30944]
trailer [31191,31198]
===
match
---
string: "Exception when executing SchedulerJob._run_scheduler_loop" [55488,55547]
string: "Exception when executing SchedulerJob._run_scheduler_loop" [55991,56050]
===
match
---
trailer [22057,22063]
trailer [22057,22063]
===
match
---
name: DefaultDict [35991,36002]
name: DefaultDict [36494,36505]
===
match
---
operator: , [49670,49671]
operator: , [50173,50174]
===
match
---
name: Stats [65805,65810]
name: Stats [66308,66313]
===
match
---
name: airflow [1809,1816]
name: airflow [1809,1816]
===
match
---
operator: = [23962,23963]
operator: = [23962,23963]
===
match
---
atom_expr [17026,17038]
atom_expr [17026,17038]
===
match
---
name: List [17995,17999]
name: List [17995,17999]
===
match
---
name: log [12574,12577]
name: log [12574,12577]
===
match
---
name: num_tasks_in_executor [40272,40293]
name: num_tasks_in_executor [40775,40796]
===
match
---
atom_expr [77397,77451]
atom_expr [77900,77954]
===
match
---
operator: , [72623,72624]
operator: , [73126,73127]
===
match
---
name: dag [15895,15898]
name: dag [15895,15898]
===
match
---
name: queue_command [47186,47199]
name: queue_command [47689,47702]
===
match
---
trailer [49160,49169]
trailer [49663,49672]
===
match
---
name: query [33481,33486]
name: query [33984,33989]
===
match
---
suite [38056,38141]
suite [38559,38644]
===
match
---
simple_stmt [53741,53823]
simple_stmt [54244,54326]
===
match
---
name: state [71182,71187]
name: state [71685,71690]
===
match
---
decorator [5002,5012]
decorator [5002,5012]
===
match
---
string: "Waiting for %s" [12584,12600]
string: "Waiting for %s" [12584,12600]
===
match
---
name: get [19705,19708]
name: get [19705,19708]
===
match
---
trailer [79791,79795]
trailer [80294,80298]
===
match
---
trailer [67148,67165]
trailer [67651,67668]
===
match
---
atom_expr [9904,9917]
atom_expr [9904,9917]
===
match
---
simple_stmt [73194,73263]
simple_stmt [73697,73766]
===
match
---
string: 'core' [30362,30368]
string: 'core' [30616,30622]
===
match
---
atom_expr [46027,46045]
atom_expr [46530,46548]
===
match
---
trailer [17104,17119]
trailer [17104,17119]
===
match
---
atom_expr [37977,38021]
atom_expr [38480,38524]
===
match
---
name: State [3028,3033]
name: State [3028,3033]
===
match
---
trailer [78201,78263]
trailer [78704,78766]
===
match
---
trailer [70346,70371]
trailer [70849,70874]
===
match
---
name: ti [17102,17104]
name: ti [17102,17104]
===
match
---
trailer [52646,52653]
trailer [53149,53156]
===
match
---
decorator [11503,11513]
decorator [11503,11513]
===
match
---
trailer [73208,73262]
trailer [73711,73765]
===
match
---
trailer [35246,35259]
trailer [35749,35762]
===
match
---
name: _process [11027,11035]
name: _process [11027,11035]
===
match
---
suite [19005,19438]
suite [19005,19438]
===
match
---
atom_expr [29394,29414]
atom_expr [29648,29668]
===
match
---
name: ti [34416,34418]
name: ti [34919,34921]
===
match
---
simple_stmt [4061,4080]
simple_stmt [4061,4080]
===
match
---
trailer [22109,22118]
trailer [22109,22118]
===
match
---
trailer [52440,52461]
trailer [52943,52964]
===
match
---
if_stmt [20606,21057]
if_stmt [20606,21057]
===
match
---
trailer [25355,25365]
trailer [25355,25365]
===
match
---
name: session [70617,70624]
name: session [71120,71127]
===
match
---
name: info [31680,31684]
name: info [32183,32187]
===
match
---
parameters [50629,50660]
parameters [51132,51163]
===
match
---
name: max_tis [37134,37141]
name: max_tis [37637,37644]
===
match
---
atom_expr [77114,77169]
atom_expr [77617,77672]
===
match
---
name: ti [52177,52179]
name: ti [52680,52682]
===
match
---
tfpdef [4004,4044]
tfpdef [4004,4044]
===
match
---
testlist_comp [67964,68149]
testlist_comp [68467,68652]
===
match
---
atom_expr [54770,54796]
atom_expr [55273,55299]
===
match
---
atom_expr [48617,48646]
atom_expr [49120,49149]
===
match
---
argument [54465,54488]
argument [54968,54991]
===
match
---
trailer [74699,74706]
trailer [75202,75209]
===
match
---
name: TI [16288,16290]
name: TI [16288,16290]
===
match
---
simple_stmt [8835,9282]
simple_stmt [8835,9282]
===
match
---
atom_expr [69576,69977]
atom_expr [70079,70480]
===
match
---
trailer [78019,78025]
trailer [78522,78528]
===
match
---
trailer [10022,10024]
trailer [10022,10024]
===
match
---
trailer [9247,9260]
trailer [9247,9260]
===
match
---
name: run [69570,69573]
name: run [70073,70076]
===
match
---
param [22550,22573]
param [22550,22573]
===
match
---
name: new_state [32794,32803]
name: new_state [33297,33306]
===
match
---
simple_stmt [9569,9588]
simple_stmt [9569,9588]
===
match
---
operator: -> [10769,10771]
operator: -> [10769,10771]
===
match
---
parameters [15233,15290]
parameters [15233,15290]
===
match
---
name: execution_date [64404,64418]
name: execution_date [64907,64921]
===
match
---
trailer [40748,40814]
trailer [41251,41317]
===
match
---
name: dag_id [17388,17394]
name: dag_id [17388,17394]
===
match
---
name: error [66387,66392]
name: error [66890,66895]
===
match
---
name: sig_name [31639,31647]
name: sig_name [32142,32150]
===
match
---
trailer [6747,6770]
trailer [6747,6770]
===
match
---
name: self [12366,12370]
name: self [12366,12370]
===
match
---
trailer [27529,27536]
trailer [27529,27536]
===
match
---
name: Stats [66503,66508]
name: Stats [67006,67011]
===
match
---
operator: = [36962,36963]
operator: = [37465,37466]
===
match
---
and_test [74919,75040]
and_test [75422,75543]
===
match
---
name: simple_task_instance [53115,53135]
name: simple_task_instance [53618,53638]
===
match
---
name: AirflowException [14248,14264]
name: AirflowException [14248,14264]
===
match
---
trailer [55081,55097]
trailer [55584,55600]
===
match
---
name: all [49957,49960]
name: all [50460,50463]
===
match
---
simple_stmt [57645,57801]
simple_stmt [58148,58304]
===
match
---
name: DagRun [68046,68052]
name: DagRun [68549,68555]
===
match
---
simple_stmt [17072,17121]
simple_stmt [17072,17121]
===
match
---
name: incr [81882,81886]
name: incr [82385,82389]
===
match
---
name: self [76911,76915]
name: self [77414,77418]
===
match
---
operator: , [2351,2352]
operator: , [2351,2352]
===
match
---
trailer [73202,73208]
trailer [73705,73711]
===
match
---
atom [79680,79703]
atom [80183,80206]
===
match
---
name: parent_channel [5182,5196]
name: parent_channel [5182,5196]
===
match
---
trailer [33486,33507]
trailer [33989,34010]
===
match
---
name: State [33850,33855]
name: State [34353,34358]
===
match
---
trailer [32544,32550]
trailer [33047,33053]
===
match
---
operator: - [41774,41775]
operator: - [42277,42278]
===
match
---
simple_stmt [54178,54535]
simple_stmt [54681,55038]
===
match
---
name: EOFError [12746,12754]
name: EOFError [12746,12754]
===
match
---
name: TI [16495,16497]
name: TI [16495,16497]
===
match
---
atom_expr [4454,4466]
atom_expr [4454,4466]
===
match
---
trailer [29572,29612]
trailer [29826,29866]
===
match
---
name: session [24153,24160]
name: session [24153,24160]
===
match
---
name: LoggingMixin [3208,3220]
name: LoggingMixin [3208,3220]
===
match
---
name: class_creation_counter [4969,4991]
name: class_creation_counter [4969,4991]
===
match
---
simple_stmt [32343,32402]
simple_stmt [32846,32905]
===
match
---
name: dag [73177,73180]
name: dag [73680,73683]
===
match
---
annassign [15165,15215]
annassign [15165,15215]
===
match
---
string: 'UNIT_TEST_MODE' [15198,15214]
string: 'UNIT_TEST_MODE' [15198,15214]
===
match
---
name: open_slots [44839,44849]
name: open_slots [45342,45352]
===
match
---
name: tis_to_change [34385,34398]
name: tis_to_change [34888,34901]
===
match
---
or_test [11341,11391]
or_test [11341,11391]
===
match
---
name: dag [20706,20709]
name: dag [20706,20709]
===
match
---
operator: = [17200,17201]
operator: = [17200,17201]
===
match
---
name: session [22050,22057]
name: session [22050,22057]
===
match
---
name: any [15851,15854]
name: any [15851,15854]
===
match
---
operator: , [72249,72250]
operator: , [72752,72753]
===
match
---
expr_stmt [24771,24807]
expr_stmt [24771,24807]
===
match
---
name: priority [46993,47001]
name: priority [47496,47504]
===
match
---
expr_stmt [15151,15215]
expr_stmt [15151,15215]
===
match
---
name: task_id [16066,16073]
name: task_id [16066,16073]
===
match
---
operator: , [36041,36042]
operator: , [36544,36545]
===
match
---
trailer [45348,45353]
trailer [45851,45856]
===
match
---
operator: , [72543,72544]
operator: , [73046,73047]
===
match
---
operator: = [58782,58783]
operator: = [59285,59286]
===
match
---
name: List [5367,5371]
name: List [5367,5371]
===
match
---
trailer [81195,81304]
trailer [81698,81807]
===
match
---
name: TI [16388,16390]
name: TI [16388,16390]
===
match
---
atom_expr [76390,76486]
atom_expr [76893,76989]
===
match
---
funcdef [23807,24179]
funcdef [23807,24179]
===
match
---
trailer [30562,30596]
trailer [30816,30850]
===
match
---
fstring_string: DagFileProcessor [9226,9242]
fstring_string: DagFileProcessor [9226,9242]
===
match
---
name: DagFileProcessorProcess [4816,4839]
name: DagFileProcessorProcess [4816,4839]
===
match
---
atom [38723,38794]
atom [39226,39297]
===
match
---
name: self [9045,9049]
name: self [9045,9049]
===
match
---
expr_stmt [19868,19900]
expr_stmt [19868,19900]
===
match
---
atom_expr [24541,24565]
atom_expr [24541,24565]
===
match
---
name: sql_conn [30426,30434]
name: sql_conn [30680,30688]
===
match
---
name: pools [77901,77906]
name: pools [78404,78409]
===
match
---
if_stmt [27227,27546]
if_stmt [27227,27546]
===
match
---
atom_expr [81704,81717]
atom_expr [82207,82220]
===
match
---
simple_stmt [52671,52719]
simple_stmt [53174,53222]
===
match
---
trailer [27737,27747]
trailer [27737,27747]
===
match
---
trailer [68238,68276]
trailer [68741,68779]
===
match
---
operator: = [66392,66393]
operator: = [66895,66896]
===
match
---
name: self [57590,57594]
name: self [58093,58097]
===
match
---
suite [78368,78417]
suite [78871,78920]
===
match
---
name: _create_dagruns_for_dags [62940,62964]
name: _create_dagruns_for_dags [63443,63467]
===
match
---
name: session [17523,17530]
name: session [17523,17530]
===
match
---
name: ti [18331,18333]
name: ti [18331,18333]
===
match
---
name: guard [67270,67275]
name: guard [67773,67778]
===
match
---
suite [24264,25141]
suite [24264,25141]
===
match
---
operator: = [54512,54513]
operator: = [55015,55016]
===
match
---
operator: -> [21440,21442]
operator: -> [21440,21442]
===
match
---
operator: , [13559,13560]
operator: , [13559,13560]
===
match
---
name: session [73144,73151]
name: session [73647,73654]
===
match
---
operator: = [77010,77011]
operator: = [77513,77514]
===
match
---
trailer [21048,21055]
trailer [21048,21055]
===
match
---
trailer [21264,21282]
trailer [21264,21282]
===
match
---
simple_stmt [9367,9383]
simple_stmt [9367,9383]
===
match
---
argument [22319,22336]
argument [22319,22336]
===
match
---
simple_stmt [65771,65780]
simple_stmt [66274,66283]
===
match
---
suite [50668,53483]
suite [51171,53986]
===
match
---
trailer [68852,68859]
trailer [69355,69362]
===
match
---
trailer [18058,18065]
trailer [18058,18065]
===
match
---
trailer [13592,13601]
trailer [13592,13601]
===
match
---
trailer [39318,39345]
trailer [39821,39848]
===
match
---
expr_stmt [17072,17120]
expr_stmt [17072,17120]
===
match
---
trailer [70260,70267]
trailer [70763,70770]
===
match
---
trailer [35218,35450]
trailer [35721,35953]
===
match
---
if_stmt [43782,44140]
if_stmt [44285,44643]
===
match
---
operator: * [30226,30227]
operator: * [30480,30481]
===
match
---
operator: , [65121,65122]
operator: , [65624,65625]
===
match
---
trailer [58104,58117]
trailer [58607,58620]
===
match
---
decorator [35870,35887]
decorator [36373,36390]
===
match
---
operator: , [52966,52967]
operator: , [53469,53470]
===
match
---
suite [5404,8540]
suite [5404,8540]
===
match
---
simple_stmt [53253,53342]
simple_stmt [53756,53845]
===
match
---
name: pickle_dags [56210,56221]
name: pickle_dags [56713,56724]
===
match
---
and_test [53663,53731]
and_test [54166,54234]
===
match
---
trailer [59982,59986]
trailer [60485,60489]
===
match
---
simple_stmt [1339,1383]
simple_stmt [1339,1383]
===
match
---
atom_expr [80876,80888]
atom_expr [81379,81391]
===
match
---
annassign [42958,42980]
annassign [43461,43483]
===
match
---
name: get [23327,23330]
name: get [23327,23330]
===
match
---
name: self [23430,23434]
name: self [23430,23434]
===
match
---
name: ti [81743,81745]
name: ti [82246,82248]
===
match
---
trailer [16460,16464]
trailer [16460,16464]
===
match
---
expr_stmt [50913,50960]
expr_stmt [51416,51463]
===
match
---
operator: = [63983,63984]
operator: = [64486,64487]
===
match
---
atom_expr [55617,55636]
atom_expr [56120,56139]
===
match
---
name: _process [9909,9917]
name: _process [9909,9917]
===
match
---
simple_stmt [7786,8006]
simple_stmt [7786,8006]
===
match
---
name: dag_run [73247,73254]
name: dag_run [73750,73757]
===
match
---
name: is_alive [13334,13342]
name: is_alive [13334,13342]
===
match
---
trailer [64325,64334]
trailer [64828,64837]
===
match
---
name: bool [3952,3956]
name: bool [3952,3956]
===
match
---
trailer [72424,72441]
trailer [72927,72944]
===
match
---
expr_stmt [4454,4500]
expr_stmt [4454,4500]
===
match
---
trailer [48536,48552]
trailer [49039,49055]
===
match
---
trailer [73904,73919]
trailer [74407,74422]
===
match
---
trailer [50224,50236]
trailer [50727,50739]
===
match
---
name: self [15781,15785]
name: self [15781,15785]
===
match
---
operator: -> [14067,14069]
operator: -> [14067,14069]
===
match
---
name: dag_concurrency_map [44894,44913]
name: dag_concurrency_map [45397,45416]
===
match
---
atom_expr [70342,70392]
atom_expr [70845,70895]
===
match
---
operator: = [17484,17485]
operator: = [17484,17485]
===
match
---
trailer [66664,66666]
trailer [67167,67169]
===
match
---
atom_expr [15919,16000]
atom_expr [15919,16000]
===
match
---
expr_stmt [20430,20479]
expr_stmt [20430,20479]
===
match
---
name: utils [2898,2903]
name: utils [2898,2903]
===
match
---
operator: , [71204,71205]
operator: , [71707,71708]
===
match
---
trailer [19891,19899]
trailer [19891,19899]
===
match
---
name: ti [25031,25033]
name: ti [25031,25033]
===
match
---
trailer [65883,65885]
trailer [66386,66388]
===
match
---
name: debug [58367,58372]
name: debug [58870,58875]
===
match
---
simple_stmt [31379,31398]
simple_stmt [31756,31775]
===
match
---
atom_expr [23298,23347]
atom_expr [23298,23347]
===
match
---
tfpdef [24218,24232]
tfpdef [24218,24232]
===
match
---
name: models [1552,1558]
name: models [1552,1558]
===
match
---
name: selectinload [1421,1433]
name: selectinload [1421,1433]
===
match
---
expr_stmt [27255,27323]
expr_stmt [27255,27323]
===
match
---
name: SchedulerJob [79540,79552]
name: SchedulerJob [80043,80055]
===
match
---
name: dag [77441,77444]
name: dag [77944,77947]
===
match
---
trailer [50438,50480]
trailer [50941,50983]
===
match
---
trailer [26392,26397]
trailer [26392,26397]
===
match
---
name: log [26630,26633]
name: log [26630,26633]
===
match
---
raise_stmt [10824,10888]
raise_stmt [10824,10888]
===
match
---
expr_stmt [54718,54756]
expr_stmt [55221,55259]
===
match
---
trailer [77075,77080]
trailer [77578,77583]
===
match
---
operator: <= [41503,41505]
operator: <= [42006,42008]
===
match
---
name: ti [47004,47006]
name: ti [47507,47509]
===
match
---
atom_expr [14404,14426]
atom_expr [14404,14426]
===
match
---
operator: , [8962,8963]
operator: , [8962,8963]
===
match
---
atom_expr [72601,72623]
atom_expr [73104,73126]
===
match
---
argument [74275,74300]
argument [74778,74803]
===
match
---
trailer [38564,38571]
trailer [39067,39074]
===
match
---
import_as_name [1132,1171]
import_as_name [1132,1171]
===
match
---
argument [76618,76639]
argument [77121,77142]
===
match
---
name: state [34652,34657]
name: state [35155,35160]
===
match
---
name: Tuple [40091,40096]
name: Tuple [40594,40599]
===
match
---
trailer [53754,53822]
trailer [54257,54325]
===
match
---
funcdef [53488,56035]
funcdef [53991,56538]
===
match
---
trailer [16108,16118]
trailer [16108,16118]
===
match
---
atom_expr [52975,52983]
atom_expr [53478,53486]
===
match
---
atom_expr [17602,17615]
atom_expr [17602,17615]
===
match
---
name: filter_for_tis [51953,51967]
name: filter_for_tis [52456,52470]
===
match
---
string: """Launch the process and start processing the DAG.""" [8578,8632]
string: """Launch the process and start processing the DAG.""" [8578,8632]
===
match
---
param [77212,77217]
param [77715,77720]
===
match
---
operator: , [42819,42820]
operator: , [43322,43323]
===
match
---
trailer [37749,37782]
trailer [38252,38285]
===
match
---
suite [74885,75345]
suite [75388,75848]
===
match
---
name: file_path [26492,26501]
name: file_path [26492,26501]
===
match
---
name: num_times_parse_dags [30080,30100]
name: num_times_parse_dags [30334,30354]
===
match
---
atom_expr [9290,9303]
atom_expr [9290,9303]
===
match
---
argument [75409,75424]
argument [75912,75927]
===
match
---
trailer [15932,16000]
trailer [15932,16000]
===
match
---
atom_expr [56181,56200]
atom_expr [56684,56703]
===
match
---
expr_stmt [4196,4239]
expr_stmt [4196,4239]
===
match
---
operator: , [39739,39740]
operator: , [40242,40243]
===
match
---
name: dag_id [36644,36650]
name: dag_id [37147,37153]
===
match
---
operator: == [67872,67874]
operator: == [68375,68377]
===
match
---
operator: , [21043,21044]
operator: , [21043,21044]
===
match
---
trailer [59570,59576]
trailer [60073,60079]
===
match
---
simple_stmt [17181,17231]
simple_stmt [17181,17231]
===
match
---
name: section [19709,19716]
name: section [19709,19716]
===
match
---
operator: , [37146,37147]
operator: , [37649,37650]
===
match
---
atom_expr [11540,11553]
atom_expr [11540,11553]
===
match
---
trailer [48710,48736]
trailer [49213,49239]
===
match
---
trailer [71659,71666]
trailer [72162,72169]
===
match
---
trailer [5371,5388]
trailer [5371,5388]
===
match
---
name: get_task [19879,19887]
name: get_task [19879,19887]
===
match
---
name: parent_channel [6780,6794]
name: parent_channel [6780,6794]
===
match
---
decorator [66706,66728]
decorator [67209,67231]
===
match
---
string: 'dag_model' [52076,52087]
string: 'dag_model' [52579,52590]
===
match
---
name: __init__ [29348,29356]
name: __init__ [29602,29610]
===
match
---
atom_expr [17995,18003]
atom_expr [17995,18003]
===
match
---
atom [27364,27470]
atom [27364,27470]
===
match
---
atom [74901,75054]
atom [75404,75557]
===
match
---
name: str [5244,5247]
name: str [5244,5247]
===
match
---
suite [17164,17515]
suite [17164,17515]
===
match
---
atom_expr [26384,26449]
atom_expr [26384,26449]
===
match
---
simple_stmt [2213,2355]
simple_stmt [2213,2355]
===
match
---
name: DagRun [68254,68260]
name: DagRun [68757,68763]
===
match
---
name: utcnow [16723,16729]
name: utcnow [16723,16729]
===
match
---
atom [29225,29265]
atom [29479,29519]
===
match
---
trailer [68709,68773]
trailer [69212,69276]
===
match
---
simple_stmt [29761,29786]
simple_stmt [30015,30040]
===
match
---
trailer [38579,38589]
trailer [39082,39092]
===
match
---
number: 1 [44595,44596]
number: 1 [45098,45099]
===
match
---
operator: , [29463,29464]
operator: , [29717,29718]
===
match
---
atom_expr [35806,35864]
atom_expr [36309,36367]
===
match
---
trailer [26823,26827]
trailer [26823,26827]
===
match
---
name: State [60758,60763]
name: State [61261,61266]
===
match
---
name: task_instance [42073,42086]
name: task_instance [42576,42589]
===
match
---
string: 'sqlite' [30446,30454]
string: 'sqlite' [30700,30708]
===
match
---
name: TI [80660,80662]
name: TI [81163,81165]
===
match
---
suite [31331,31371]
suite [31708,31748]
===
match
---
atom_expr [47064,47158]
atom_expr [47567,47661]
===
match
---
name: dag [74949,74952]
name: dag [75452,75455]
===
match
---
name: _parent_channel [12248,12263]
name: _parent_channel [12248,12263]
===
match
---
operator: , [23644,23645]
operator: , [23644,23645]
===
match
---
name: _process [13465,13473]
name: _process [13465,13473]
===
match
---
simple_stmt [12044,12207]
simple_stmt [12044,12207]
===
match
---
name: str [39736,39739]
name: str [40239,40242]
===
match
---
trailer [7117,7136]
trailer [7117,7136]
===
match
---
name: int [11549,11552]
name: int [11549,11552]
===
match
---
atom_expr [54604,54625]
atom_expr [55107,55128]
===
match
---
trailer [19071,19075]
trailer [19071,19075]
===
match
---
name: str [5039,5042]
name: str [5039,5042]
===
match
---
simple_stmt [74645,74654]
simple_stmt [75148,75157]
===
match
---
with_stmt [60337,61139]
with_stmt [60840,61642]
===
match
---
operator: , [26862,26863]
operator: , [26862,26863]
===
match
---
simple_stmt [59142,59212]
simple_stmt [59645,59715]
===
match
---
simple_stmt [16884,17059]
simple_stmt [16884,17059]
===
match
---
fstring_end: ' [78133,78134]
fstring_end: ' [78636,78637]
===
match
---
trailer [61052,61061]
trailer [61555,61564]
===
match
---
trailer [57948,57974]
trailer [58451,58477]
===
match
---
atom_expr [10323,10343]
atom_expr [10323,10343]
===
match
---
simple_stmt [20793,20818]
simple_stmt [20793,20818]
===
match
---
operator: == [35407,35409]
operator: == [35910,35912]
===
match
---
name: update_import_errors [27621,27641]
name: update_import_errors [27621,27641]
===
match
---
atom_expr [30605,30625]
atom_expr [30859,30879]
===
match
---
param [67347,67378]
param [67850,67881]
===
match
---
name: dag [71938,71941]
name: dag [72441,72444]
===
match
---
operator: , [40106,40107]
operator: , [40609,40610]
===
match
---
name: self [50489,50493]
name: self [50992,50996]
===
match
---
simple_stmt [67144,67188]
simple_stmt [67647,67691]
===
match
---
atom_expr [20264,20272]
atom_expr [20264,20272]
===
match
---
simple_stmt [30052,30101]
simple_stmt [30306,30355]
===
match
---
atom_expr [13460,13484]
atom_expr [13460,13484]
===
match
---
trailer [20909,20914]
trailer [20909,20914]
===
match
---
name: processor_agent [50731,50746]
name: processor_agent [51234,51249]
===
match
---
trailer [4027,4044]
trailer [4027,4044]
===
match
---
simple_stmt [32519,32689]
simple_stmt [33022,33192]
===
match
---
operator: = [30351,30352]
operator: = [30605,30606]
===
match
---
name: self [19360,19364]
name: self [19360,19364]
===
match
---
atom_expr [30406,30423]
atom_expr [30660,30677]
===
match
---
expr_stmt [44894,44926]
expr_stmt [45397,45429]
===
match
---
name: info [82109,82113]
name: info [82612,82616]
===
match
---
exprlist [49702,49745]
exprlist [50205,50248]
===
match
---
name: log [78992,78995]
name: log [79495,79498]
===
match
---
name: DagRun [66851,66857]
name: DagRun [67354,67360]
===
match
---
operator: , [24131,24132]
operator: , [24131,24132]
===
match
---
name: self [12569,12573]
name: self [12569,12573]
===
match
---
operator: , [5274,5275]
operator: , [5274,5275]
===
match
---
operator: = [36778,36779]
operator: = [37281,37282]
===
match
---
name: start_date [70141,70151]
name: start_date [70644,70654]
===
match
---
operator: , [76312,76313]
operator: , [76815,76816]
===
match
---
name: task_id [35343,35350]
name: task_id [35846,35853]
===
match
---
atom_expr [73669,73691]
atom_expr [74172,74194]
===
match
---
simple_stmt [2451,2518]
simple_stmt [2451,2518]
===
match
---
atom_expr [62892,62917]
atom_expr [63395,63420]
===
match
---
name: subdir [29380,29386]
name: subdir [29634,29640]
===
match
---
operator: = [77940,77941]
operator: = [78443,78444]
===
match
---
name: int [37143,37146]
name: int [37646,37649]
===
match
---
name: slots_stats [37738,37749]
name: slots_stats [38241,38252]
===
match
---
name: _parent_channel [12419,12434]
name: _parent_channel [12419,12434]
===
match
---
name: update_state [75557,75569]
name: update_state [76060,76072]
===
match
---
name: pools [38006,38011]
name: pools [38509,38514]
===
match
---
operator: , [5223,5224]
operator: , [5223,5224]
===
match
---
argument [77749,77774]
argument [78252,78277]
===
match
---
number: 1 [45014,45015]
number: 1 [45517,45518]
===
match
---
operator: = [37968,37969]
operator: = [38471,38472]
===
match
---
string: """         Make scheduling decisions about an individual dag run          ``currently_active_runs`` is passed in so that a batch query can be         used to ask this for all dag runs in the batch, to avoid an n+1 query.          :param dag_run: The DagRun to schedule         :param currently_active_runs: Number of currently active runs of this DAG         :return: Number of tasks scheduled         """ [72673,73079]
string: """         Make scheduling decisions about an individual dag run          ``currently_active_runs`` is passed in so that a batch query can be         used to ask this for all dag runs in the batch, to avoid an n+1 query.          :param dag_run: The DagRun to schedule         :param currently_active_runs: Number of currently active runs of this DAG         :return: Number of tasks scheduled         """ [73176,73582]
===
match
---
trailer [74762,74766]
trailer [75265,75269]
===
match
---
trailer [8266,8276]
trailer [8266,8276]
===
match
---
name: ti [81472,81474]
name: ti [81975,81977]
===
match
---
operator: = [19733,19734]
operator: = [19733,19734]
===
match
---
name: _parent_channel [10716,10731]
name: _parent_channel [10716,10731]
===
match
---
simple_stmt [20188,20197]
simple_stmt [20188,20197]
===
match
---
name: dag [18983,18986]
name: dag [18983,18986]
===
match
---
trailer [38532,38537]
trailer [39035,39040]
===
match
---
atom_expr [65091,65181]
atom_expr [65594,65684]
===
match
---
simple_stmt [36058,36438]
simple_stmt [36561,36941]
===
match
---
simple_stmt [72673,73080]
simple_stmt [73176,73583]
===
match
---
atom_expr [66236,66257]
atom_expr [66739,66760]
===
match
---
trailer [80097,80103]
trailer [80600,80606]
===
match
---
trailer [40740,40748]
trailer [41243,41251]
===
match
---
trailer [54058,54096]
trailer [54561,54599]
===
match
---
trailer [36643,36650]
trailer [37146,37153]
===
match
---
argument [74318,74335]
argument [74821,74838]
===
match
---
name: exception [71752,71761]
name: exception [72255,72264]
===
match
---
return_stmt [27789,27839]
return_stmt [27789,27839]
===
match
---
name: TI [49277,49279]
name: TI [49780,49782]
===
match
---
simple_stmt [44839,44878]
simple_stmt [45342,45381]
===
match
---
name: current_time [34718,34730]
name: current_time [35221,35233]
===
match
---
name: attempt_number [79144,79158]
name: attempt_number [79647,79661]
===
match
---
operator: -> [22580,22582]
operator: -> [22580,22582]
===
match
---
trailer [13743,13760]
trailer [13743,13760]
===
match
---
operator: , [50554,50555]
operator: , [51057,51058]
===
match
---
arglist [22319,22388]
arglist [22319,22388]
===
match
---
trailer [52007,52011]
trailer [52510,52514]
===
match
---
operator: , [42866,42867]
operator: , [43369,43370]
===
match
---
name: num_tasks_in_executor [45219,45240]
name: num_tasks_in_executor [45722,45743]
===
match
---
name: debug_dump [31777,31787]
name: debug_dump [32280,32290]
===
match
---
name: callback_requests [2232,2249]
name: callback_requests [2232,2249]
===
match
---
name: task [18334,18338]
name: task [18334,18338]
===
match
---
not_test [76907,76931]
not_test [77410,77434]
===
match
---
atom_expr [65805,65855]
atom_expr [66308,66358]
===
match
---
name: new_state [34659,34668]
name: new_state [35162,35171]
===
match
---
suite [10811,10889]
suite [10811,10889]
===
match
---
name: signum [31291,31297]
name: signum [31668,31674]
===
match
---
param [15270,15289]
param [15270,15289]
===
match
---
name: query [67166,67171]
name: query [67669,67674]
===
match
---
operator: = [8713,8714]
operator: = [8713,8714]
===
match
---
trailer [35211,35218]
trailer [35714,35721]
===
match
---
comparison [73595,73622]
comparison [74098,74125]
===
match
---
simple_stmt [54718,54757]
simple_stmt [55221,55260]
===
match
---
atom_expr [73717,73747]
atom_expr [74220,74250]
===
match
---
arglist [19173,19227]
arglist [19173,19227]
===
match
---
simple_stmt [42936,42981]
simple_stmt [43439,43484]
===
match
---
name: self [58100,58104]
name: self [58603,58607]
===
match
---
name: dag_run [72553,72560]
name: dag_run [73056,73063]
===
match
---
import_as_names [1469,1492]
import_as_names [1469,1492]
===
match
---
except_clause [68645,68673]
except_clause [69148,69176]
===
match
---
name: slas [17596,17600]
name: slas [17596,17600]
===
match
---
name: ti [52629,52631]
name: ti [53132,53134]
===
match
---
operator: @ [11175,11176]
operator: @ [11175,11176]
===
match
---
name: end [55631,55634]
name: end [56134,56137]
===
match
---
name: State [64255,64260]
name: State [64758,64763]
===
match
---
operator: = [43633,43634]
operator: = [44136,44137]
===
match
---
if_stmt [48469,48648]
if_stmt [48972,49151]
===
match
---
name: _send_sla_callbacks_to_processor [77043,77075]
name: _send_sla_callbacks_to_processor [77546,77578]
===
match
---
annassign [52001,52095]
annassign [52504,52598]
===
match
---
strings [43912,44024]
strings [44415,44527]
===
match
---
trailer [64153,64160]
trailer [64656,64663]
===
match
---
atom_expr [35941,35950]
atom_expr [36444,36453]
===
match
---
string: 'scheduler' [29573,29584]
string: 'scheduler' [29827,29838]
===
match
---
atom_expr [43635,43756]
atom_expr [44138,44259]
===
match
---
name: signum [31425,31431]
name: signum [31802,31808]
===
match
---
expr_stmt [4312,4379]
expr_stmt [4312,4379]
===
match
---
suite [66396,66617]
suite [66899,67120]
===
match
---
with_stmt [62836,66701]
with_stmt [63339,67204]
===
match
---
name: TI [18220,18222]
name: TI [18220,18222]
===
match
---
fstring_end: " [6938,6939]
fstring_end: " [6938,6939]
===
match
---
if_stmt [60915,61112]
if_stmt [61418,61615]
===
match
---
trailer [43472,43480]
trailer [43975,43983]
===
match
---
name: Stats [78377,78382]
name: Stats [78880,78885]
===
match
---
decorated [66706,66891]
decorated [67209,67394]
===
match
---
operator: , [35016,35017]
operator: , [35519,35520]
===
match
---
trailer [80604,80610]
trailer [81107,81113]
===
match
---
name: dagbag [26476,26482]
name: dagbag [26476,26482]
===
match
---
operator: = [9756,9757]
operator: = [9756,9757]
===
match
---
operator: = [46666,46667]
operator: = [47169,47170]
===
match
---
name: kwargs [30235,30241]
name: kwargs [30489,30495]
===
match
---
name: self [48669,48673]
name: self [49172,49176]
===
match
---
operator: , [79510,79511]
operator: , [80013,80014]
===
match
---
name: EventScheduler [57327,57341]
name: EventScheduler [57830,57844]
===
match
---
operator: @ [66706,66707]
operator: @ [67209,67210]
===
match
---
name: _process [11743,11751]
name: _process [11743,11751]
===
match
---
funcdef [35891,37003]
funcdef [36394,37506]
===
match
---
trailer [8070,8132]
trailer [8070,8132]
===
match
---
atom_expr [9341,9358]
atom_expr [9341,9358]
===
match
---
name: log [42565,42568]
name: log [43068,43071]
===
match
---
name: Stats [52671,52676]
name: Stats [53174,53179]
===
match
---
trailer [39081,39098]
trailer [39584,39601]
===
match
---
name: airflow [2732,2739]
name: airflow [2732,2739]
===
match
---
name: _get_multiprocessing_start_method [8661,8694]
name: _get_multiprocessing_start_method [8661,8694]
===
match
---
name: _process_executor_events [50605,50629]
name: _process_executor_events [51108,51132]
===
match
---
name: adopt_or_reset_orphaned_tasks [57595,57624]
name: adopt_or_reset_orphaned_tasks [58098,58127]
===
match
---
trailer [31314,31330]
trailer [31691,31707]
===
match
---
name: dag_run [76298,76305]
name: dag_run [76801,76808]
===
match
---
trailer [22090,22134]
trailer [22090,22134]
===
match
---
suite [12377,12402]
suite [12377,12402]
===
match
---
atom_expr [43000,43051]
atom_expr [43503,43554]
===
match
---
name: grace_multiplier [32367,32383]
name: grace_multiplier [32870,32886]
===
match
---
name: num_ready [41165,41174]
name: num_ready [41668,41677]
===
match
---
name: processor_agent [77588,77603]
name: processor_agent [78091,78106]
===
match
---
simple_stmt [52561,52570]
simple_stmt [53064,53073]
===
match
---
trailer [73945,73947]
trailer [74448,74450]
===
match
---
trailer [42086,42093]
trailer [42589,42596]
===
match
---
operator: = [26483,26484]
operator: = [26483,26484]
===
match
---
trailer [71903,71907]
trailer [72406,72410]
===
match
---
atom_expr [82045,82075]
atom_expr [82548,82578]
===
match
---
string: "Running SLA Checks for %s" [15795,15822]
string: "Running SLA Checks for %s" [15795,15822]
===
match
---
name: session [73152,73159]
name: session [73655,73662]
===
match
---
if_stmt [11735,11839]
if_stmt [11735,11839]
===
match
---
trailer [37517,37521]
trailer [38020,38024]
===
match
---
atom_expr [66316,66338]
atom_expr [66819,66841]
===
match
---
name: logging [7123,7130]
name: logging [7123,7130]
===
match
---
name: _kill_process [10749,10762]
name: _kill_process [10749,10762]
===
match
---
name: self [78742,78746]
name: self [79245,79249]
===
match
---
atom_expr [22064,22082]
atom_expr [22064,22082]
===
match
---
operator: = [30481,30482]
operator: = [30735,30736]
===
match
---
name: terminate [10034,10043]
name: terminate [10034,10043]
===
match
---
name: getint [30556,30562]
name: getint [30810,30816]
===
match
---
operator: == [73605,73607]
operator: == [74108,74110]
===
match
---
simple_stmt [17321,17463]
simple_stmt [17321,17463]
===
match
---
trailer [19368,19378]
trailer [19368,19378]
===
match
---
suite [19937,20197]
suite [19937,20197]
===
match
---
name: session [68624,68631]
name: session [69127,69134]
===
match
---
name: simple_ti [24736,24745]
name: simple_ti [24736,24745]
===
match
---
atom_expr [58454,58496]
atom_expr [58957,58999]
===
match
---
funcdef [10030,10740]
funcdef [10030,10740]
===
match
---
operator: = [41279,41280]
operator: = [41782,41783]
===
match
---
operator: = [57924,57925]
operator: = [58427,58428]
===
match
---
trailer [22282,22403]
trailer [22282,22403]
===
match
---
decorated [22434,23781]
decorated [22434,23781]
===
match
---
trailer [40217,40235]
trailer [40720,40738]
===
match
---
name: queued_tis [48656,48666]
name: queued_tis [49159,49169]
===
match
---
name: self [77212,77216]
name: self [77715,77719]
===
match
---
simple_stmt [72361,72503]
simple_stmt [72864,73006]
===
match
---
name: ti [24669,24671]
name: ti [24669,24671]
===
match
---
trailer [68245,68252]
trailer [68748,68755]
===
match
---
number: 1 [78414,78415]
number: 1 [78917,78918]
===
match
---
operator: , [29714,29715]
operator: , [29968,29969]
===
match
---
trailer [31348,31364]
trailer [31725,31741]
===
match
---
name: try_number [51624,51634]
name: try_number [52127,52137]
===
match
---
if_stmt [14201,14311]
if_stmt [14201,14311]
===
match
---
operator: -> [53507,53509]
operator: -> [54010,54012]
===
match
---
trailer [66513,66548]
trailer [67016,67051]
===
match
---
operator: , [79620,79621]
operator: , [80123,80124]
===
match
---
atom_expr [4646,4663]
atom_expr [4646,4663]
===
match
---
name: Exception [55414,55423]
name: Exception [55917,55926]
===
match
---
name: session [22271,22278]
name: session [22271,22278]
===
match
---
simple_stmt [73275,73284]
simple_stmt [73778,73787]
===
match
---
trailer [64169,64211]
trailer [64672,64714]
===
match
---
name: dag_id [23938,23944]
name: dag_id [23938,23944]
===
match
---
trailer [30695,30764]
trailer [30949,31018]
===
match
---
atom_expr [43241,43285]
atom_expr [43744,43788]
===
match
---
atom_expr [39724,39759]
atom_expr [40227,40262]
===
match
---
arglist [16261,16313]
arglist [16261,16313]
===
match
---
name: _done [12540,12545]
name: _done [12540,12545]
===
match
---
name: processor_timeout [54392,54409]
name: processor_timeout [54895,54912]
===
match
---
testlist_comp [41292,41330]
testlist_comp [41795,41833]
===
match
---
expr_stmt [41722,41789]
expr_stmt [42225,42292]
===
match
---
expr_stmt [50969,51017]
expr_stmt [51472,51520]
===
match
---
operator: , [39638,39639]
operator: , [40141,40142]
===
match
---
suite [69553,70333]
suite [70056,70836]
===
match
---
operator: , [43706,43707]
operator: , [44209,44210]
===
match
---
operator: , [35850,35851]
operator: , [36353,36354]
===
match
---
arglist [27120,27145]
arglist [27120,27145]
===
match
---
name: all [52090,52093]
name: all [52593,52596]
===
match
---
operator: , [47244,47245]
operator: , [47747,47748]
===
match
---
trailer [65144,65148]
trailer [65647,65651]
===
match
---
comp_op [27435,27441]
comp_op [27435,27441]
===
match
---
atom_expr [18093,18125]
atom_expr [18093,18125]
===
match
---
name: utils [2531,2536]
name: utils [2531,2536]
===
match
---
name: tis_changed [33427,33438]
name: tis_changed [33930,33941]
===
match
---
simple_stmt [23912,23946]
simple_stmt [23912,23946]
===
match
---
name: synchronize_session [50245,50264]
name: synchronize_session [50748,50767]
===
match
---
string: "Couldn't find dag %s in DagBag/DB!" [73209,73245]
string: "Couldn't find dag %s in DagBag/DB!" [73712,73748]
===
match
---
name: log [55720,55723]
name: log [56223,56226]
===
match
---
operator: , [20526,20527]
operator: , [20526,20527]
===
match
---
atom_expr [20706,20716]
atom_expr [20706,20716]
===
match
---
operator: = [39524,39525]
operator: = [40027,40028]
===
match
---
atom_expr [68300,68309]
atom_expr [68803,68812]
===
match
---
name: SCHEDULED [60676,60685]
name: SCHEDULED [61179,61188]
===
match
---
name: tis_with_right_state [51825,51845]
name: tis_with_right_state [52328,52348]
===
match
---
string: 'scheduler' [57866,57877]
string: 'scheduler' [58369,58380]
===
match
---
atom_expr [54250,54261]
atom_expr [54753,54764]
===
match
---
name: blocking_tis [18736,18748]
name: blocking_tis [18736,18748]
===
match
---
name: self [10682,10686]
name: self [10682,10686]
===
match
---
name: ti [47134,47136]
name: ti [47637,47639]
===
match
---
operator: = [40864,40865]
operator: = [41367,41368]
===
match
---
trailer [13625,13641]
trailer [13625,13641]
===
match
---
simple_stmt [73932,73948]
simple_stmt [74435,74451]
===
match
---
atom_expr [79230,79305]
atom_expr [79733,79808]
===
match
---
name: ti [53191,53193]
name: ti [53694,53696]
===
match
---
trailer [30276,30281]
trailer [30530,30535]
===
match
---
name: event_buffer [51075,51087]
name: event_buffer [51578,51590]
===
match
---
trailer [56145,56162]
trailer [56648,56665]
===
match
---
trailer [30884,30922]
trailer [31138,31176]
===
match
---
fstring_string: <code></pre>             Airflow Webserver URL:  [19651,19699]
fstring_string: <code></pre>             Airflow Webserver URL:  [19651,19699]
===
match
---
argument [19730,19744]
argument [19730,19744]
===
match
---
atom_expr [24771,24784]
atom_expr [24771,24784]
===
match
---
number: 1 [58035,58036]
number: 1 [58538,58539]
===
match
---
simple_stmt [58914,58953]
simple_stmt [59417,59456]
===
match
---
atom_expr [48593,48615]
atom_expr [49096,49118]
===
match
---
trailer [66063,66080]
trailer [66566,66583]
===
match
---
testlist_comp [36944,36959]
testlist_comp [37447,37462]
===
match
---
name: session [82580,82587]
name: session [83083,83090]
===
match
---
atom_expr [24104,24131]
atom_expr [24104,24131]
===
match
---
argument [56434,56469]
argument [56937,56972]
===
match
---
name: max_ti [16649,16655]
name: max_ti [16649,16655]
===
match
---
operator: = [16712,16713]
operator: = [16712,16713]
===
match
---
simple_stmt [45029,45097]
simple_stmt [45532,45600]
===
match
---
atom_expr [36709,36725]
atom_expr [37212,37228]
===
match
---
name: dag_run [73463,73470]
name: dag_run [73966,73973]
===
match
---
operator: , [61167,61168]
operator: , [61670,61671]
===
match
---
name: str [36697,36700]
name: str [37200,37203]
===
match
---
name: TI [38859,38861]
name: TI [39362,39364]
===
match
---
trailer [40877,40885]
trailer [41380,41388]
===
match
---
name: dag_id [51499,51505]
name: dag_id [52002,52008]
===
match
---
atom_expr [73595,73604]
atom_expr [74098,74107]
===
match
---
trailer [20236,20242]
trailer [20236,20242]
===
match
---
import_from [3034,3076]
import_from [3034,3076]
===
match
---
trailer [36584,36606]
trailer [37087,37109]
===
match
---
operator: , [37764,37765]
operator: , [38267,38268]
===
match
---
name: execution_date [18096,18110]
name: execution_date [18096,18110]
===
match
---
trailer [22249,22255]
trailer [22249,22255]
===
match
---
trailer [40169,40192]
trailer [40672,40695]
===
match
---
operator: = [49913,49914]
operator: = [50416,50417]
===
match
---
comparison [74919,74968]
comparison [75422,75471]
===
match
---
atom_expr [72285,72319]
atom_expr [72788,72822]
===
match
---
trailer [50157,50173]
trailer [50660,50676]
===
match
---
name: TI [73595,73597]
name: TI [74098,74100]
===
match
---
name: MultiprocessingStartMethodMixin [3222,3253]
name: MultiprocessingStartMethodMixin [3222,3253]
===
match
---
param [76121,76133]
param [76624,76636]
===
match
---
if_stmt [31307,31371]
if_stmt [31684,31748]
===
match
---
name: request [23714,23721]
name: request [23714,23721]
===
match
---
simple_stmt [24273,24314]
simple_stmt [24273,24314]
===
match
---
operator: , [5247,5248]
operator: , [5247,5248]
===
match
---
atom_expr [73421,73439]
atom_expr [73924,73942]
===
match
---
atom_expr [23994,24016]
atom_expr [23994,24016]
===
match
---
atom_expr [19875,19900]
atom_expr [19875,19900]
===
match
---
trailer [43332,43355]
trailer [43835,43858]
===
match
---
param [61169,61176]
param [61672,61679]
===
match
---
atom_expr [24532,24566]
atom_expr [24532,24566]
===
match
---
if_stmt [59638,59920]
if_stmt [60141,60423]
===
match
---
atom_expr [82641,82654]
atom_expr [83144,83157]
===
match
---
suite [55600,55637]
suite [56103,56140]
===
match
---
trailer [11983,11992]
trailer [11983,11992]
===
match
---
name: DagRun [71175,71181]
name: DagRun [71678,71684]
===
match
---
string: '*' [36559,36562]
string: '*' [37062,37065]
===
match
---
suite [77452,77567]
suite [77955,78070]
===
match
---
name: SerializedDagNotFound [68652,68673]
name: SerializedDagNotFound [69155,69176]
===
match
---
name: self [55913,55917]
name: self [56416,56420]
===
match
---
name: heartbeat [58919,58928]
name: heartbeat [59422,59431]
===
match
---
trailer [57651,57673]
trailer [58154,58176]
===
match
---
name: dagbag [68828,68834]
name: dagbag [69331,69337]
===
match
---
arglist [20388,20403]
arglist [20388,20403]
===
match
---
name: join [18652,18656]
name: join [18652,18656]
===
match
---
name: fileloc [53086,53093]
name: fileloc [53589,53596]
===
match
---
name: current_task_concurrency [43785,43809]
name: current_task_concurrency [44288,44312]
===
match
---
suite [16758,17515]
suite [16758,17515]
===
match
---
name: try_number [52614,52624]
name: try_number [53117,53127]
===
match
---
operator: , [80590,80591]
operator: , [81093,81094]
===
match
---
arglist [33827,33963]
arglist [34330,34466]
===
match
---
atom_expr [74564,74631]
atom_expr [75067,75134]
===
match
---
arith_expr [81923,81965]
arith_expr [82426,82468]
===
match
---
fstring_end: """ [19759,19762]
fstring_end: """ [19759,19762]
===
match
---
name: register_signals [30774,30790]
name: register_signals [31028,31044]
===
match
---
name: DefaultDict [39724,39735]
name: DefaultDict [40227,40238]
===
match
---
name: ti_key [51617,51623]
name: ti_key [52120,52126]
===
match
---
name: log [44224,44227]
name: log [44727,44730]
===
match
---
name: self [10789,10793]
name: self [10789,10793]
===
match
---
import_from [2518,2574]
import_from [2518,2574]
===
match
---
atom_expr [68849,68859]
atom_expr [69352,69362]
===
match
---
trailer [11742,11751]
trailer [11742,11751]
===
match
---
trailer [42218,42228]
trailer [42721,42731]
===
match
---
if_stmt [12215,12354]
if_stmt [12215,12354]
===
match
---
name: self [59142,59146]
name: self [59645,59649]
===
match
---
trailer [78247,78262]
trailer [78750,78765]
===
match
---
name: following_schedule [17206,17224]
name: following_schedule [17206,17224]
===
match
---
trailer [11974,11983]
trailer [11974,11983]
===
match
---
trailer [68848,68860]
trailer [69351,69363]
===
match
---
name: update [79673,79679]
name: update [80176,80182]
===
match
---
param [77859,77882]
param [78362,78385]
===
match
---
name: tuple_ [68232,68238]
name: tuple_ [68735,68741]
===
match
---
name: next_dagrun [68314,68325]
name: next_dagrun [68817,68828]
===
match
---
trailer [33721,33995]
trailer [34224,34498]
===
match
---
except_clause [19917,19936]
except_clause [19917,19936]
===
match
---
name: log [7761,7764]
name: log [7761,7764]
===
match
---
name: len [45493,45496]
name: len [45996,45999]
===
match
---
operator: , [41119,41120]
operator: , [41622,41623]
===
match
---
atom_expr [30961,30982]
atom_expr [31215,31236]
===
match
---
parameters [10762,10768]
parameters [10762,10768]
===
match
---
with_stmt [78957,82625]
with_stmt [79460,83128]
===
match
---
atom_expr [53358,53377]
atom_expr [53861,53880]
===
match
---
atom_expr [38775,38788]
atom_expr [39278,39291]
===
match
---
argument [45354,45385]
argument [45857,45888]
===
match
---
name: __init__ [15308,15316]
name: __init__ [15308,15316]
===
match
---
operator: , [44529,44530]
operator: , [45032,45033]
===
match
---
simple_stmt [33451,34006]
simple_stmt [33954,34509]
===
match
---
trailer [16646,16648]
trailer [16646,16648]
===
match
---
trailer [10715,10731]
trailer [10715,10731]
===
match
---
name: append [81530,81536]
name: append [82033,82039]
===
match
---
return_stmt [11963,11992]
return_stmt [11963,11992]
===
match
---
name: currently_active_runs [75019,75040]
name: currently_active_runs [75522,75543]
===
match
---
name: key [19730,19733]
name: key [19730,19733]
===
match
---
operator: == [76359,76361]
operator: == [76862,76864]
===
match
---
simple_stmt [52205,52253]
simple_stmt [52708,52756]
===
match
---
atom_expr [54844,54876]
atom_expr [55347,55379]
===
match
---
name: provide_session [23787,23802]
name: provide_session [23787,23802]
===
match
---
name: state [73720,73725]
name: state [74223,74228]
===
match
---
trailer [13542,13575]
trailer [13542,13575]
===
match
---
name: ti_key [51763,51769]
name: ti_key [52266,52272]
===
match
---
arith_expr [49578,49592]
arith_expr [50081,50095]
===
match
---
trailer [50173,50180]
trailer [50676,50683]
===
match
---
name: num_times_parse_dags [29486,29506]
name: num_times_parse_dags [29740,29760]
===
match
---
name: Optional [13735,13743]
name: Optional [13735,13743]
===
match
---
dotted_name [1809,1823]
dotted_name [1809,1823]
===
match
---
for_stmt [16740,17515]
for_stmt [16740,17515]
===
match
---
atom [41291,41331]
atom [41794,41834]
===
match
---
atom_expr [64255,64269]
atom_expr [64758,64772]
===
match
---
suite [32848,35865]
suite [33351,36368]
===
match
---
name: self [10044,10048]
name: self [10044,10048]
===
match
---
number: 15.0 [57925,57929]
number: 15.0 [58428,58432]
===
match
---
trailer [27072,27086]
trailer [27072,27086]
===
match
---
trailer [21317,21323]
trailer [21317,21323]
===
match
---
suite [77604,77669]
suite [78107,78172]
===
match
---
simple_stmt [948,960]
simple_stmt [948,960]
===
match
---
name: email [20472,20477]
name: email [20472,20477]
===
match
---
name: dag_id [68424,68430]
name: dag_id [68927,68933]
===
match
---
trailer [25069,25073]
trailer [25069,25073]
===
match
---
name: ti_key [51492,51498]
name: ti_key [51995,52001]
===
match
---
atom_expr [18215,18223]
atom_expr [18215,18223]
===
match
---
classdef [3145,14427]
classdef [3145,14427]
===
match
---
parameters [9787,9793]
parameters [9787,9793]
===
match
---
arglist [57501,57625]
arglist [58004,58128]
===
match
---
trailer [38780,38788]
trailer [39283,39291]
===
match
---
name: self [81342,81346]
name: self [81845,81849]
===
match
---
operator: { [19699,19700]
operator: { [19699,19700]
===
match
---
name: models [1916,1922]
name: models [1916,1922]
===
match
---
name: DagRunType [80752,80762]
name: DagRunType [81255,81265]
===
match
---
comparison [16261,16286]
comparison [16261,16286]
===
match
---
expr_stmt [17181,17230]
expr_stmt [17181,17230]
===
match
---
name: subq [35270,35274]
name: subq [35773,35777]
===
match
---
simple_stmt [3847,3874]
simple_stmt [3847,3874]
===
match
---
name: TI [45833,45835]
name: TI [46336,46338]
===
match
---
trailer [79795,79800]
trailer [80298,80303]
===
match
---
atom [64170,64210]
atom [64673,64713]
===
match
---
argument [66064,66079]
argument [66567,66582]
===
match
---
suite [6954,8133]
suite [6954,8133]
===
match
---
operator: , [23061,23062]
operator: , [23061,23062]
===
match
---
trailer [38858,38886]
trailer [39361,39389]
===
match
---
trailer [43873,43878]
trailer [44376,44381]
===
match
---
name: execution_date [46594,46608]
name: execution_date [47097,47111]
===
match
---
tfpdef [76843,76881]
tfpdef [77346,77384]
===
match
---
comparison [26785,26805]
comparison [26785,26805]
===
match
---
trailer [54696,54702]
trailer [55199,55205]
===
match
---
atom_expr [20516,20526]
atom_expr [20516,20526]
===
match
---
subscriptlist [36003,36011]
subscriptlist [36506,36514]
===
match
---
operator: = [34565,34566]
operator: = [35068,35069]
===
match
---
simple_stmt [4164,4188]
simple_stmt [4164,4188]
===
match
---
operator: , [81921,81922]
operator: , [82424,82425]
===
match
---
operator: , [59115,59116]
operator: , [59618,59619]
===
match
---
atom_expr [23562,23754]
atom_expr [23562,23754]
===
match
---
name: buffer_key [52603,52613]
name: buffer_key [53106,53116]
===
match
---
simple_stmt [21261,21290]
simple_stmt [21261,21290]
===
match
---
arglist [65267,65327]
arglist [65770,65830]
===
match
---
simple_stmt [2518,2575]
simple_stmt [2518,2575]
===
match
---
trailer [81619,81636]
trailer [82122,82139]
===
match
---
string: '\n\t' [82045,82051]
string: '\n\t' [82548,82554]
===
match
---
name: executor [55622,55630]
name: executor [56125,56133]
===
match
---
name: session [67127,67134]
name: session [67630,67637]
===
match
---
trailer [23174,23198]
trailer [23174,23198]
===
match
---
name: callback_requests [25231,25248]
name: callback_requests [25231,25248]
===
match
---
operator: , [31289,31290]
operator: , [31666,31667]
===
match
---
funcdef [11517,11993]
funcdef [11517,11993]
===
match
---
operator: = [79610,79611]
operator: = [80113,80114]
===
match
---
string: 'core' [15190,15196]
string: 'core' [15190,15196]
===
match
---
suite [48500,48553]
suite [49003,49056]
===
match
---
name: session [23475,23482]
name: session [23475,23482]
===
match
---
fstring_start: f' [78202,78204]
fstring_start: f' [78705,78707]
===
match
---
atom_expr [76584,76595]
atom_expr [77087,77098]
===
match
---
name: utils [2368,2373]
name: utils [2368,2373]
===
match
---
name: session [81243,81250]
name: session [81746,81753]
===
match
---
simple_stmt [77006,77030]
simple_stmt [77509,77533]
===
match
---
atom_expr [56334,56479]
atom_expr [56837,56982]
===
match
---
trailer [71090,71326]
trailer [71593,71829]
===
match
---
simple_stmt [8641,8697]
simple_stmt [8641,8697]
===
match
---
atom_expr [10441,10466]
atom_expr [10441,10466]
===
match
---
trailer [47185,47199]
trailer [47688,47702]
===
match
---
simple_stmt [7552,7598]
simple_stmt [7552,7598]
===
match
---
trailer [8036,8041]
trailer [8036,8041]
===
match
---
name: tis_to_reset_or_adopt [81927,81948]
name: tis_to_reset_or_adopt [82430,82451]
===
match
---
name: int [42969,42972]
name: int [43472,43475]
===
match
---
name: log [65253,65256]
name: log [65756,65759]
===
match
---
import_name [920,930]
import_name [920,930]
===
match
---
name: ti [34379,34381]
name: ti [34882,34884]
===
match
---
trailer [67165,67187]
trailer [67668,67690]
===
match
---
name: self [29761,29765]
name: self [30015,30019]
===
match
---
funcdef [56058,56480]
funcdef [56561,56983]
===
match
---
operator: = [80062,80063]
operator: = [80565,80566]
===
match
---
atom_expr [30052,30077]
atom_expr [30306,30331]
===
match
---
return_stmt [14319,14342]
return_stmt [14319,14342]
===
match
---
name: num_failed [79936,79946]
name: num_failed [80439,80449]
===
match
---
trailer [55931,55985]
trailer [56434,56488]
===
match
---
name: dag [77006,77009]
name: dag [77509,77512]
===
match
---
param [72578,72624]
param [73081,73127]
===
match
---
trailer [75201,75208]
trailer [75704,75711]
===
match
---
name: pools [37718,37723]
name: pools [38221,38226]
===
match
---
operator: { [19554,19555]
operator: { [19554,19555]
===
match
---
atom_expr [61124,61138]
atom_expr [61627,61641]
===
match
---
trailer [7830,7843]
trailer [7830,7843]
===
match
---
if_stmt [79748,79948]
if_stmt [80251,80451]
===
match
---
trailer [30113,30138]
trailer [30367,30392]
===
match
---
name: tis_to_reset_or_adopt [81381,81402]
name: tis_to_reset_or_adopt [81884,81905]
===
match
---
operator: = [54476,54477]
operator: = [54979,54980]
===
match
---
operator: , [41612,41613]
operator: , [42115,42116]
===
match
---
name: callback_requests [7951,7968]
name: callback_requests [7951,7968]
===
match
---
name: schedule_tis [75996,76008]
name: schedule_tis [76499,76511]
===
match
---
comparison [38775,38793]
comparison [39278,39296]
===
match
---
name: signal [31512,31518]
name: signal [32015,32021]
===
match
---
name: command [47237,47244]
name: command [47740,47747]
===
match
---
name: time [955,959]
name: time [955,959]
===
match
---
operator: = [50653,50654]
operator: = [51156,51157]
===
match
---
name: session [76752,76759]
name: session [77255,77262]
===
match
---
simple_stmt [13528,13576]
simple_stmt [13528,13576]
===
match
---
suite [13761,14027]
suite [13761,14027]
===
match
---
trailer [68276,68280]
trailer [68779,68783]
===
match
---
trailer [11427,11464]
trailer [11427,11464]
===
match
---
name: AirflowException [11884,11900]
name: AirflowException [11884,11900]
===
match
---
name: send_email [2507,2517]
name: send_email [2507,2517]
===
match
---
trailer [39378,39417]
trailer [39881,39920]
===
match
---
trailer [58774,58791]
trailer [59277,59294]
===
match
---
suite [78970,82625]
suite [79473,83128]
===
match
---
atom_expr [50348,50397]
atom_expr [50851,50900]
===
match
---
name: filter [80133,80139]
name: filter [80636,80642]
===
match
---
trailer [40096,40106]
trailer [40599,40609]
===
match
---
name: self [75354,75358]
name: self [75857,75861]
===
match
---
trailer [25001,25044]
trailer [25001,25044]
===
match
---
trailer [41741,41773]
trailer [42244,42276]
===
match
---
name: get [30358,30361]
name: get [30612,30615]
===
match
---
tfpdef [5322,5338]
tfpdef [5322,5338]
===
match
---
atom_expr [6875,6940]
atom_expr [6875,6940]
===
match
---
operator: = [46830,46831]
operator: = [47333,47334]
===
match
---
operator: , [15822,15823]
operator: , [15822,15823]
===
match
---
name: utils [2740,2745]
name: utils [2740,2745]
===
match
---
atom_expr [16300,16313]
atom_expr [16300,16313]
===
match
---
except_clause [55847,55863]
except_clause [56350,56366]
===
match
---
trailer [26880,26882]
trailer [26880,26882]
===
match
---
atom_expr [51689,51702]
atom_expr [52192,52205]
===
match
---
atom_expr [55226,55256]
atom_expr [55729,55759]
===
match
---
operator: , [1208,1209]
operator: , [1208,1209]
===
match
---
return_stmt [65771,65779]
return_stmt [66274,66282]
===
match
---
tfpdef [72578,72623]
tfpdef [73081,73126]
===
match
---
string: """         Execute on failure callbacks. These objects can come from SchedulerJob or from         DagFileProcessorManager.          :param dagbag: Dag Bag of dags         :param callback_requests: failure callbacks to execute         :type callback_requests: List[airflow.utils.callback_requests.CallbackRequest]         :param session: DB session.         """ [22597,22958]
string: """         Execute on failure callbacks. These objects can come from SchedulerJob or from         DagFileProcessorManager.          :param dagbag: Dag Bag of dags         :param callback_requests: failure callbacks to execute         :type callback_requests: List[airflow.utils.callback_requests.CallbackRequest]         :param session: DB session.         """ [22597,22958]
===
match
---
name: str [56195,56198]
name: str [56698,56701]
===
match
---
operator: = [43276,43277]
operator: = [43779,43780]
===
match
---
name: self [63005,63009]
name: self [63508,63512]
===
match
---
operator: , [50868,50869]
operator: , [51371,51372]
===
match
---
name: error [25002,25007]
name: error [25002,25007]
===
match
---
atom_expr [30992,31039]
atom_expr [31246,31293]
===
match
---
operator: * [49841,49842]
operator: * [50344,50345]
===
match
---
operator: @ [13701,13702]
operator: @ [13701,13702]
===
match
---
operator: = [81242,81243]
operator: = [81745,81746]
===
match
---
name: open_slots [41137,41147]
name: open_slots [41640,41650]
===
match
---
atom_expr [65872,65885]
atom_expr [66375,66388]
===
match
---
trailer [38571,38591]
trailer [39074,39094]
===
match
---
name: filter_for_ti_state_change [49842,49868]
name: filter_for_ti_state_change [50345,50371]
===
match
---
trailer [36577,36584]
trailer [37080,37087]
===
match
---
name: __init__ [4069,4077]
name: __init__ [4069,4077]
===
match
---
name: incr [81800,81804]
name: incr [82303,82307]
===
match
---
atom_expr [58139,58185]
atom_expr [58642,58688]
===
match
---
funcdef [9779,10025]
funcdef [9779,10025]
===
match
---
simple_stmt [34597,34746]
simple_stmt [35100,35249]
===
match
---
operator: , [5172,5173]
operator: , [5172,5173]
===
match
---
operator: = [52142,52143]
operator: = [52645,52646]
===
match
---
arglist [8874,9271]
arglist [8874,9271]
===
match
---
arglist [27023,27038]
arglist [27023,27038]
===
match
---
simple_stmt [9538,9561]
simple_stmt [9538,9561]
===
match
---
operator: = [37773,37774]
operator: = [38276,38277]
===
match
---
operator: = [54142,54143]
operator: = [54645,54646]
===
match
---
name: TI [80507,80509]
name: TI [81010,81012]
===
match
---
operator: , [77541,77542]
operator: , [78044,78045]
===
match
---
trailer [60847,60854]
trailer [61350,61357]
===
match
---
trailer [7843,8005]
trailer [7843,8005]
===
match
---
operator: = [46497,46498]
operator: = [47000,47001]
===
match
---
name: Stats [78190,78195]
name: Stats [78693,78698]
===
match
---
operator: , [54451,54452]
operator: , [54954,54955]
===
match
---
name: DagRunType [69624,69634]
name: DagRunType [70127,70137]
===
match
---
trailer [67275,67282]
trailer [67778,67785]
===
match
---
operator: , [68614,68615]
operator: , [69117,69118]
===
match
---
simple_stmt [16013,16020]
simple_stmt [16013,16020]
===
match
---
suite [55583,56035]
suite [56086,56538]
===
match
---
atom_expr [36629,36639]
atom_expr [37132,37142]
===
match
---
operator: @ [48841,48842]
operator: @ [49344,49345]
===
match
---
name: DagRun [80733,80739]
name: DagRun [81236,81242]
===
match
---
string: "-" [31744,31747]
string: "-" [32247,32250]
===
match
---
try_stmt [23084,23755]
try_stmt [23084,23755]
===
match
---
expr_stmt [51998,52095]
expr_stmt [52501,52598]
===
match
---
name: _change_state_for_tis_without_dagrun [32719,32755]
name: _change_state_for_tis_without_dagrun [33222,33258]
===
match
---
atom_expr [11080,11094]
atom_expr [11080,11094]
===
match
---
arglist [16846,16865]
arglist [16846,16865]
===
match
---
name: State [79690,79695]
name: State [80193,80198]
===
match
---
atom_expr [30931,30983]
atom_expr [31185,31237]
===
match
---
simple_stmt [30109,30165]
simple_stmt [30363,30419]
===
match
---
name: self [50928,50932]
name: self [51431,51435]
===
match
---
name: _result [14019,14026]
name: _result [14019,14026]
===
match
---
operator: = [43404,43405]
operator: = [43907,43908]
===
match
---
exprlist [27390,27401]
exprlist [27390,27401]
===
match
---
number: 80 [31730,31732]
number: 80 [32233,32235]
===
match
---
operator: = [15172,15173]
operator: = [15172,15173]
===
match
---
atom_expr [36744,36777]
atom_expr [37247,37280]
===
match
---
atom_expr [74717,74744]
atom_expr [75220,75247]
===
match
---
trailer [60854,60856]
trailer [61357,61359]
===
match
---
suite [10556,10650]
suite [10556,10650]
===
match
---
atom_expr [17729,17739]
atom_expr [17729,17739]
===
match
---
name: _done [4561,4566]
name: _done [4561,4566]
===
match
---
suite [26612,26773]
suite [26612,26773]
===
match
---
suite [34399,34490]
suite [34902,34993]
===
match
---
trailer [73387,73398]
trailer [73890,73901]
===
match
---
simple_stmt [29270,29339]
simple_stmt [29524,29593]
===
match
---
name: session [40237,40244]
name: session [40740,40747]
===
match
---
atom_expr [49255,49685]
atom_expr [49758,50188]
===
match
---
operator: = [42071,42072]
operator: = [42574,42575]
===
match
---
operator: , [9062,9063]
operator: , [9062,9063]
===
match
---
parameters [25183,25346]
parameters [25183,25346]
===
match
---
name: self [40165,40169]
name: self [40668,40672]
===
match
---
name: connection [1114,1124]
name: connection [1114,1124]
===
match
---
trailer [59156,59211]
trailer [59659,59714]
===
match
---
not_test [77337,77360]
not_test [77840,77863]
===
match
---
simple_stmt [30209,30243]
simple_stmt [30463,30497]
===
match
---
name: processor_timeout_seconds [54143,54168]
name: processor_timeout_seconds [54646,54671]
===
match
---
expr_stmt [78812,78882]
expr_stmt [79315,79385]
===
match
---
name: Exception [55656,55665]
name: Exception [56159,56168]
===
match
---
name: ti [17395,17397]
name: ti [17395,17397]
===
match
---
name: options [52055,52062]
name: options [52558,52565]
===
match
---
name: _run_file_processor [5102,5121]
name: _run_file_processor [5102,5121]
===
match
---
expr_stmt [7706,7769]
expr_stmt [7706,7769]
===
match
---
fstring_string: [airflow] SLA miss on DAG= [20679,20705]
fstring_string: [airflow] SLA miss on DAG= [20679,20705]
===
match
---
operator: , [49708,49709]
operator: , [50211,50212]
===
match
---
tfpdef [31846,31879]
tfpdef [32349,32382]
===
match
---
argument [54323,54378]
argument [54826,54881]
===
match
---
trailer [77400,77451]
trailer [77903,77954]
===
match
---
atom_expr [35270,35283]
atom_expr [35773,35786]
===
match
---
trailer [36527,36535]
trailer [37030,37038]
===
match
---
name: executor [50353,50361]
name: executor [50856,50864]
===
match
---
trailer [73939,73945]
trailer [74442,74448]
===
match
---
name: dag_directory [54236,54249]
name: dag_directory [54739,54752]
===
match
---
atom_expr [14014,14026]
atom_expr [14014,14026]
===
match
---
trailer [59077,59081]
trailer [59580,59584]
===
match
---
trailer [69517,69529]
trailer [70020,70032]
===
match
---
name: min [59577,59580]
name: min [60080,60083]
===
match
---
trailer [20387,20404]
trailer [20387,20404]
===
match
---
trailer [30056,30077]
trailer [30310,30331]
===
match
---
suite [52118,53449]
suite [52621,53952]
===
match
---
trailer [65564,65573]
trailer [66067,66076]
===
match
---
trailer [12370,12376]
trailer [12370,12376]
===
match
---
atom_expr [71984,72003]
atom_expr [72487,72506]
===
match
---
arglist [13543,13574]
arglist [13543,13574]
===
match
---
name: dag [74289,74292]
name: dag [74792,74795]
===
match
---
name: seconds [54135,54142]
name: seconds [54638,54645]
===
match
---
trailer [33579,33638]
trailer [34082,34141]
===
match
---
name: dagbag [23458,23464]
name: dagbag [23458,23464]
===
match
---
name: self [9904,9908]
name: self [9904,9908]
===
match
---
name: serialized_dag [43309,43323]
name: serialized_dag [43812,43826]
===
match
---
try_stmt [65066,65358]
try_stmt [65569,65861]
===
match
---
trailer [66431,66482]
trailer [66934,66985]
===
match
---
suite [29722,30765]
suite [29976,31019]
===
match
---
name: self [14014,14018]
name: self [14014,14018]
===
match
---
name: session [72633,72640]
name: session [73136,73143]
===
match
---
trailer [20581,20593]
trailer [20581,20593]
===
match
---
trailer [59087,59128]
trailer [59590,59631]
===
match
---
name: priority [47142,47150]
name: priority [47645,47653]
===
match
---
trailer [18542,18613]
trailer [18542,18613]
===
match
---
string: "Resetting orphaned tasks for active dag runs" [78756,78802]
string: "Resetting orphaned tasks for active dag runs" [79259,79305]
===
match
---
name: dag_hash [69896,69904]
name: dag_hash [70399,70407]
===
match
---
simple_stmt [15300,15319]
simple_stmt [15300,15319]
===
match
---
name: event_buffer [52279,52291]
name: event_buffer [52782,52794]
===
match
---
name: _kill_process [10009,10022]
name: _kill_process [10009,10022]
===
match
---
atom_expr [15358,15367]
atom_expr [15358,15367]
===
match
---
operator: { [50902,50903]
operator: { [51405,51406]
===
match
---
name: file_path [46884,46893]
name: file_path [47387,47396]
===
match
---
name: StreamLogWriter [2633,2648]
name: StreamLogWriter [2633,2648]
===
match
---
name: update [50174,50180]
name: update [50677,50683]
===
match
---
atom_expr [9045,9062]
atom_expr [9045,9062]
===
match
---
suite [14088,14343]
suite [14088,14343]
===
match
---
trailer [52038,52054]
trailer [52541,52557]
===
match
---
trailer [33956,33962]
trailer [34459,34465]
===
match
---
for_stmt [40593,45097]
for_stmt [41096,45600]
===
match
---
trailer [13601,13606]
trailer [13601,13606]
===
match
---
name: ti [17376,17378]
name: ti [17376,17378]
===
match
---
name: dag [27398,27401]
name: dag [27398,27401]
===
match
---
trailer [73112,73119]
trailer [73615,73622]
===
match
---
name: AirflowException [13937,13953]
name: AirflowException [13937,13953]
===
match
---
atom_expr [80999,81016]
atom_expr [81502,81519]
===
match
---
atom_expr [19360,19437]
atom_expr [19360,19437]
===
match
---
operator: , [7150,7151]
operator: , [7150,7151]
===
match
---
dotted_name [2667,2687]
dotted_name [2667,2687]
===
match
---
trailer [10445,10454]
trailer [10445,10454]
===
match
---
return_stmt [38119,38140]
return_stmt [38622,38643]
===
match
---
operator: , [59811,59812]
operator: , [60314,60315]
===
match
---
trailer [35414,35416]
trailer [35917,35919]
===
match
---
name: dag_id [42087,42093]
name: dag_id [42590,42596]
===
match
---
trailer [23978,24034]
trailer [23978,24034]
===
match
---
string: 'scheduler.orphaned_tasks.cleared' [81805,81839]
string: 'scheduler.orphaned_tasks.cleared' [82308,82342]
===
match
---
name: ti [15889,15891]
name: ti [15889,15891]
===
match
---
decorator [60262,60279]
decorator [60765,60782]
===
match
---
arglist [46536,46965]
arglist [47039,47468]
===
match
---
trailer [33651,33658]
trailer [34154,34161]
===
match
---
name: TI [64346,64348]
name: TI [64849,64851]
===
match
---
name: List [4023,4027]
name: List [4023,4027]
===
match
---
trailer [27022,27039]
trailer [27022,27039]
===
match
---
trailer [71355,71362]
trailer [71858,71865]
===
match
---
name: stacktrace [22378,22388]
name: stacktrace [22378,22388]
===
match
---
name: TI [36525,36527]
name: TI [37028,37030]
===
match
---
atom_expr [9322,9338]
atom_expr [9322,9338]
===
match
---
arglist [27642,27657]
arglist [27642,27657]
===
match
---
name: ti_key [51058,51064]
name: ti_key [51561,51567]
===
match
---
atom_expr [79690,79702]
atom_expr [80193,80205]
===
match
---
simple_stmt [42560,42890]
simple_stmt [43063,43393]
===
match
---
simple_stmt [66844,66891]
simple_stmt [67347,67394]
===
match
---
comparison [80592,80627]
comparison [81095,81130]
===
match
---
comparison [18066,18091]
comparison [18066,18091]
===
match
---
name: task_id [35325,35332]
name: task_id [35828,35835]
===
match
---
name: AirflowException [10830,10846]
name: AirflowException [10830,10846]
===
match
---
atom_expr [17321,17462]
atom_expr [17321,17462]
===
match
---
string: "-" [31724,31727]
string: "-" [32227,32230]
===
match
---
operator: = [66016,66017]
operator: = [66519,66520]
===
match
---
atom_expr [66018,66080]
atom_expr [66521,66583]
===
match
---
simple_stmt [4556,4575]
simple_stmt [4556,4575]
===
match
---
simple_stmt [43865,44103]
simple_stmt [44368,44606]
===
match
---
name: CHECK_SLAS [77350,77360]
name: CHECK_SLAS [77853,77863]
===
match
---
name: max_active_runs [74953,74968]
name: max_active_runs [75456,75471]
===
match
---
trailer [76602,76609]
trailer [77105,77112]
===
match
---
trailer [68597,68632]
trailer [69100,69135]
===
match
---
name: session [77933,77940]
name: session [78436,78443]
===
match
---
decorated [15379,21358]
decorated [15379,21358]
===
match
---
operator: @ [37066,37067]
operator: @ [37569,37570]
===
match
---
name: dag_id [68001,68007]
name: dag_id [68504,68510]
===
match
---
atom_expr [38758,38771]
atom_expr [39261,39274]
===
match
---
expr_stmt [18911,18929]
expr_stmt [18911,18929]
===
match
---
operator: @ [77809,77810]
operator: @ [78312,78313]
===
match
---
name: Tuple [25350,25355]
name: Tuple [25350,25355]
===
match
---
name: key [50393,50396]
name: key [50896,50899]
===
match
---
trailer [13641,13647]
trailer [13641,13647]
===
match
---
name: dag_folder [30696,30706]
name: dag_folder [30950,30960]
===
match
---
atom_expr [4556,4566]
atom_expr [4556,4566]
===
match
---
name: query [22058,22063]
name: query [22058,22063]
===
match
---
suite [31626,31662]
suite [32129,32165]
===
match
---
name: sla [18601,18604]
name: sla [18601,18604]
===
match
---
suite [43583,44140]
suite [44086,44643]
===
match
---
name: logging [865,872]
name: logging [865,872]
===
match
---
sync_comp_for [37994,38020]
sync_comp_for [38497,38523]
===
match
---
trailer [68488,68490]
trailer [68991,68993]
===
match
---
operator: == [17701,17703]
operator: == [17701,17703]
===
match
---
atom_expr [16273,16286]
atom_expr [16273,16286]
===
match
---
tfpdef [72553,72568]
tfpdef [73056,73071]
===
match
---
expr_stmt [34516,34539]
expr_stmt [35019,35042]
===
match
---
trailer [43869,43873]
trailer [44372,44376]
===
match
---
operator: <= [38789,38791]
operator: <= [39292,39294]
===
match
---
expr_stmt [29207,29265]
expr_stmt [29461,29519]
===
match
---
parameters [78476,78507]
parameters [78979,79010]
===
match
---
suite [51846,51884]
suite [52349,52387]
===
match
---
arglist [74275,74466]
arglist [74778,74969]
===
match
---
testlist [26768,26772]
testlist [26768,26772]
===
match
---
import_from [2885,2995]
import_from [2885,2995]
===
match
---
simple_stmt [75514,75612]
simple_stmt [76017,76115]
===
match
---
operator: @ [78285,78286]
operator: @ [78788,78789]
===
match
---
operator: = [56451,56452]
operator: = [56954,56955]
===
match
---
name: sla [77415,77418]
name: sla [77918,77921]
===
match
---
trailer [20267,20272]
trailer [20267,20272]
===
match
---
simple_stmt [65692,65751]
simple_stmt [66195,66254]
===
match
---
operator: , [81250,81251]
operator: , [81753,81754]
===
match
---
simple_stmt [81512,81547]
simple_stmt [82015,82050]
===
match
---
atom_expr [68823,68860]
atom_expr [69326,69363]
===
match
---
name: dag_models [68527,68537]
name: dag_models [69030,69040]
===
match
---
except_clause [82535,82558]
except_clause [83038,83061]
===
match
---
name: LoggingMixin [14452,14464]
name: LoggingMixin [14452,14464]
===
match
---
trailer [71083,71090]
trailer [71586,71593]
===
match
---
name: int [50664,50667]
name: int [51167,51170]
===
match
---
atom_expr [59142,59211]
atom_expr [59645,59714]
===
match
---
trailer [64478,64494]
trailer [64981,64997]
===
match
---
operator: , [27060,27061]
operator: , [27060,27061]
===
match
---
atom_expr [3083,3102]
atom_expr [3083,3102]
===
match
---
name: self [47374,47378]
name: self [47877,47881]
===
match
---
simple_stmt [4454,4501]
simple_stmt [4454,4501]
===
match
---
simple_stmt [27526,27546]
simple_stmt [27526,27546]
===
match
---
name: str [36003,36006]
name: str [36506,36509]
===
match
---
fstring [16989,17040]
fstring [16989,17040]
===
match
---
trailer [56194,56199]
trailer [56697,56702]
===
match
---
name: self [9735,9739]
name: self [9735,9739]
===
match
---
name: file_path [3915,3924]
name: file_path [3915,3924]
===
match
---
atom_expr [74691,74708]
atom_expr [75194,75211]
===
match
---
argument [34295,34310]
argument [34798,34813]
===
match
---
operator: , [36765,36766]
operator: , [37268,37269]
===
match
---
operator: = [40675,40676]
operator: = [41178,41179]
===
match
---
name: log [60981,60984]
name: log [61484,61487]
===
match
---
if_stmt [49149,49203]
if_stmt [49652,49706]
===
match
---
operator: , [44463,44464]
operator: , [44966,44967]
===
match
---
name: session [58783,58790]
name: session [59286,59293]
===
match
---
trailer [45111,45117]
trailer [45614,45620]
===
match
---
strings [16921,17040]
strings [16921,17040]
===
match
---
trailer [12495,12511]
trailer [12495,12511]
===
match
---
simple_stmt [1608,1693]
simple_stmt [1608,1693]
===
match
---
atom_expr [30689,30764]
atom_expr [30943,31018]
===
match
---
operator: { [78044,78045]
operator: { [78547,78548]
===
match
---
number: 0 [41506,41507]
number: 0 [42009,42010]
===
match
---
name: dag_id [17398,17404]
name: dag_id [17398,17404]
===
match
---
trailer [66425,66431]
trailer [66928,66934]
===
match
---
fstring_string: pool.open_slots. [78028,78044]
fstring_string: pool.open_slots. [78531,78547]
===
match
---
atom_expr [26785,26801]
atom_expr [26785,26801]
===
match
---
suite [12755,13444]
suite [12755,13444]
===
match
---
import_from [2178,2212]
import_from [2178,2212]
===
match
---
param [29486,29517]
param [29740,29771]
===
match
---
operator: = [56403,56404]
operator: = [56906,56907]
===
match
---
operator: @ [15379,15380]
operator: @ [15379,15380]
===
match
---
trailer [39113,39115]
trailer [39616,39618]
===
match
---
arglist [60473,60545]
arglist [60976,61048]
===
match
---
trailer [68765,68772]
trailer [69268,69275]
===
match
---
simple_stmt [1804,1862]
simple_stmt [1804,1862]
===
match
---
trailer [34263,34356]
trailer [34766,34859]
===
match
---
param [5030,5034]
param [5030,5034]
===
match
---
atom_expr [27308,27322]
atom_expr [27308,27322]
===
match
---
name: self [71743,71747]
name: self [72246,72250]
===
match
---
funcdef [76061,76769]
funcdef [76564,77272]
===
match
---
string: """         Process a Python file containing Airflow DAGs.          This includes:          1. Execute the file and look for DAG objects in the namespace.         2. Execute any Callbacks if passed to this method.         3. Serialize the DAGs and save it to DB (or update existing record in the DB).         4. Pickle the DAG and save it to the DB (if necessary).         5. Record any errors importing the file into ORM          :param file_path: the path to the Python file that should be executed         :type file_path: str         :param callback_requests: failure callback to execute         :type callback_requests: List[airflow.utils.dag_processing.CallbackRequest]         :param pickle_dags: whether serialize the DAGs found in the file and             save them to the db         :type pickle_dags: bool         :param session: Sqlalchemy ORM Session         :type session: Session         :return: number of dags found, count of import errors         :rtype: Tuple[int, int]         """ [25375,26375]
string: """         Process a Python file containing Airflow DAGs.          This includes:          1. Execute the file and look for DAG objects in the namespace.         2. Execute any Callbacks if passed to this method.         3. Serialize the DAGs and save it to DB (or update existing record in the DB).         4. Pickle the DAG and save it to the DB (if necessary).         5. Record any errors importing the file into ORM          :param file_path: the path to the Python file that should be executed         :type file_path: str         :param callback_requests: failure callback to execute         :type callback_requests: List[airflow.utils.dag_processing.CallbackRequest]         :param pickle_dags: whether serialize the DAGs found in the file and             save them to the db         :type pickle_dags: bool         :param session: Sqlalchemy ORM Session         :type session: Session         :return: number of dags found, count of import errors         :rtype: Tuple[int, int]         """ [25375,26375]
===
match
---
trailer [72613,72622]
trailer [73116,73125]
===
match
---
operator: == [38051,38053]
operator: == [38554,38556]
===
match
---
trailer [76008,76034]
trailer [76511,76537]
===
match
---
suite [26463,26555]
suite [26463,26555]
===
match
---
trailer [18676,18684]
trailer [18676,18684]
===
match
---
name: do_pickle [30179,30188]
name: do_pickle [30433,30442]
===
match
---
name: dag_id [69500,69506]
name: dag_id [70003,70009]
===
match
---
trailer [68607,68614]
trailer [69110,69117]
===
match
---
simple_stmt [873,896]
simple_stmt [873,896]
===
match
---
trailer [30178,30188]
trailer [30432,30442]
===
match
---
trailer [16596,16604]
trailer [16596,16604]
===
match
---
simple_stmt [65872,65886]
simple_stmt [66375,66389]
===
match
---
trailer [11900,11954]
trailer [11900,11954]
===
match
---
expr_stmt [21261,21289]
expr_stmt [21261,21289]
===
match
---
name: sla [17002,17005]
name: sla [17002,17005]
===
match
---
expr_stmt [3103,3121]
expr_stmt [3103,3121]
===
match
---
operator: , [34668,34669]
operator: , [35171,35172]
===
match
---
operator: @ [22434,22435]
operator: @ [22434,22435]
===
match
---
annassign [32442,32510]
annassign [32945,33013]
===
match
---
atom_expr [11738,11751]
atom_expr [11738,11751]
===
match
---
name: dag_run [75659,75666]
name: dag_run [76162,76169]
===
match
---
operator: == [52600,52602]
operator: == [53103,53105]
===
match
---
trailer [22235,22249]
trailer [22235,22249]
===
match
---
tfpdef [46133,46157]
tfpdef [46636,46660]
===
match
---
name: TI [51950,51952]
name: TI [52453,52455]
===
match
---
trailer [70043,70058]
trailer [70546,70561]
===
match
---
name: set [20578,20581]
name: set [20578,20581]
===
match
---
name: exception [19369,19378]
name: exception [19369,19378]
===
match
---
expr_stmt [9290,9313]
expr_stmt [9290,9313]
===
match
---
name: processor_agent [31315,31330]
name: processor_agent [31692,31707]
===
match
---
operator: , [62970,62971]
operator: , [63473,63474]
===
match
---
name: slot_stats [78136,78146]
name: slot_stats [78639,78649]
===
match
---
operator: -> [9794,9796]
operator: -> [9794,9796]
===
match
---
tfpdef [21406,21422]
tfpdef [21406,21422]
===
match
---
name: self [14326,14330]
name: self [14326,14330]
===
match
---
number: 0 [74851,74852]
number: 0 [75354,75355]
===
match
---
name: getboolean [57272,57282]
name: getboolean [57775,57785]
===
match
---
name: pool [37981,37985]
name: pool [38484,38488]
===
match
---
argument [25021,25043]
argument [25021,25043]
===
match
---
name: thread_name [7586,7597]
name: thread_name [7586,7597]
===
match
---
name: SlaMiss [17607,17614]
name: SlaMiss [17607,17614]
===
match
---
name: max_tis_per_query [48477,48494]
name: max_tis_per_query [48980,48997]
===
match
---
trailer [72604,72623]
trailer [73107,73126]
===
match
---
trailer [73480,73494]
trailer [73983,73997]
===
match
---
name: int [40044,40047]
name: int [40547,40550]
===
match
---
atom_expr [69496,69506]
atom_expr [69999,70009]
===
match
---
trailer [74922,74945]
trailer [75425,75448]
===
match
---
name: dag_model [71650,71659]
name: dag_model [72153,72162]
===
match
---
operator: , [57877,57878]
operator: , [58380,58381]
===
match
---
try_stmt [54544,56035]
try_stmt [55047,56538]
===
match
---
atom_expr [16388,16398]
atom_expr [16388,16398]
===
match
---
operator: , [72208,72209]
operator: , [72711,72712]
===
match
---
trailer [31684,31753]
trailer [32187,32256]
===
match
---
atom_expr [64346,64363]
atom_expr [64849,64866]
===
match
---
trailer [71032,71038]
trailer [71535,71541]
===
match
---
operator: , [74609,74610]
operator: , [75112,75113]
===
match
---
operator: = [76128,76129]
operator: = [76631,76632]
===
match
---
trailer [35617,35793]
trailer [36120,36296]
===
match
---
name: pools [40709,40714]
name: pools [41212,41217]
===
match
---
simple_stmt [41529,41620]
simple_stmt [42032,42123]
===
match
---
atom_expr [19067,19109]
atom_expr [19067,19109]
===
match
---
simple_stmt [65248,65329]
simple_stmt [65751,65832]
===
match
---
operator: , [60183,60184]
operator: , [60686,60687]
===
match
---
trailer [44227,44232]
trailer [44730,44735]
===
match
---
atom_expr [24867,24879]
atom_expr [24867,24879]
===
match
---
argument [27300,27322]
argument [27300,27322]
===
match
---
name: session [32810,32817]
name: session [33313,33320]
===
match
---
name: filter [38565,38571]
name: filter [39068,39074]
===
match
---
trailer [20515,20542]
trailer [20515,20542]
===
match
---
name: list [40213,40217]
name: list [40716,40720]
===
match
---
trailer [78025,78077]
trailer [78528,78580]
===
match
---
trailer [38661,38688]
trailer [39164,39191]
===
match
---
atom [79360,79726]
atom [79863,80229]
===
match
---
trailer [81745,81762]
trailer [82248,82265]
===
match
---
trailer [9908,9917]
trailer [9908,9917]
===
match
---
expr_stmt [40057,40112]
expr_stmt [40560,40615]
===
match
---
name: notification_sent [21141,21158]
name: notification_sent [21141,21158]
===
match
---
argument [71668,71683]
argument [72171,72186]
===
match
---
simple_stmt [46054,46076]
simple_stmt [46557,46579]
===
match
---
operator: = [76253,76254]
operator: = [76756,76757]
===
match
---
name: sla [16851,16854]
name: sla [16851,16854]
===
match
---
simple_stmt [10682,10703]
simple_stmt [10682,10703]
===
match
---
name: self [54346,54350]
name: self [54849,54853]
===
match
---
name: num_queued_tis [59253,59267]
name: num_queued_tis [59756,59770]
===
match
---
expr_stmt [54561,54591]
expr_stmt [55064,55094]
===
match
---
if_stmt [12411,13444]
if_stmt [12411,13444]
===
match
---
string: "Exception when executing DagFileProcessorAgent.end" [55932,55984]
string: "Exception when executing DagFileProcessorAgent.end" [56435,56487]
===
match
---
param [29706,29715]
param [29960,29969]
===
match
---
atom_expr [54125,54169]
atom_expr [54628,54672]
===
match
---
name: file_last_changed [22019,22036]
name: file_last_changed [22019,22036]
===
match
---
trailer [31368,31370]
trailer [31745,31747]
===
match
---
operator: = [3106,3107]
operator: = [3106,3107]
===
match
---
name: sla [16823,16826]
name: sla [16823,16826]
===
match
---
trailer [17205,17224]
trailer [17205,17224]
===
match
---
atom_expr [22527,22548]
atom_expr [22527,22548]
===
match
---
name: dag_id [43261,43267]
name: dag_id [43764,43770]
===
match
---
simple_stmt [50489,50575]
simple_stmt [50992,51078]
===
match
---
name: session [21341,21348]
name: session [21341,21348]
===
match
---
trailer [81707,81717]
trailer [82210,82220]
===
match
---
fstring_string: pool.queued_slots. [78104,78122]
fstring_string: pool.queued_slots. [78607,78625]
===
match
---
suite [41508,41934]
suite [42011,42437]
===
match
---
name: info [55144,55148]
name: info [55647,55651]
===
match
---
operator: , [31732,31733]
operator: , [32235,32236]
===
match
---
name: retry_db_transaction [66707,66727]
name: retry_db_transaction [67210,67230]
===
match
---
name: _processor_poll_interval [30114,30138]
name: _processor_poll_interval [30368,30392]
===
match
---
name: slas [21187,21191]
name: slas [21187,21191]
===
match
---
trailer [18405,18409]
trailer [18405,18409]
===
match
---
trailer [73647,73692]
trailer [74150,74195]
===
match
---
atom_expr [60976,61024]
atom_expr [61479,61527]
===
match
---
name: fetched_tis [18251,18262]
name: fetched_tis [18251,18262]
===
match
---
atom_expr [53073,53093]
atom_expr [53576,53596]
===
match
---
trailer [8730,8742]
trailer [8730,8742]
===
match
---
trailer [55373,55380]
trailer [55876,55883]
===
match
---
name: session [74195,74202]
name: session [74698,74705]
===
match
---
name: class_creation_counter [3847,3869]
name: class_creation_counter [3847,3869]
===
match
---
arglist [42599,42867]
arglist [43102,43370]
===
match
---
name: session [23764,23771]
name: session [23764,23771]
===
match
---
name: execution_date [69666,69680]
name: execution_date [70169,70183]
===
match
---
name: signal [30992,30998]
name: signal [31246,31252]
===
match
---
arglist [81805,81854]
arglist [82308,82357]
===
match
---
param [29380,29415]
param [29634,29669]
===
match
---
if_stmt [21138,21329]
if_stmt [21138,21329]
===
match
---
name: dagbag [24345,24351]
name: dagbag [24345,24351]
===
match
---
name: startswith [30435,30445]
name: startswith [30689,30699]
===
match
---
parameters [35917,35981]
parameters [36420,36484]
===
match
---
operator: , [70382,70383]
operator: , [70885,70886]
===
match
---
trailer [45399,45403]
trailer [45902,45906]
===
match
---
trailer [20709,20716]
trailer [20709,20716]
===
match
---
name: StreamLogWriter [7102,7117]
name: StreamLogWriter [7102,7117]
===
match
---
trailer [22063,22083]
trailer [22063,22083]
===
match
---
atom_expr [65123,65171]
atom_expr [65626,65674]
===
match
---
atom_expr [26789,26800]
atom_expr [26789,26800]
===
match
---
fstring_expr [78223,78234]
fstring_expr [78726,78737]
===
match
---
trailer [77473,77479]
trailer [77976,77982]
===
match
---
simple_stmt [46993,47023]
simple_stmt [47496,47526]
===
match
---
name: args [8925,8929]
name: args [8925,8929]
===
match
---
operator: , [54427,54428]
operator: , [54930,54931]
===
match
---
atom_expr [16622,16639]
atom_expr [16622,16639]
===
match
---
suite [76895,77170]
suite [77398,77673]
===
match
---
atom_expr [44786,44822]
atom_expr [45289,45325]
===
match
---
simple_stmt [36897,36922]
simple_stmt [37400,37425]
===
match
---
operator: } [45073,45074]
operator: } [45576,45577]
===
match
---
atom_expr [31798,31821]
atom_expr [32301,32324]
===
match
---
trailer [65095,65113]
trailer [65598,65616]
===
match
---
trailer [38411,38421]
trailer [38914,38924]
===
match
---
operator: , [47132,47133]
operator: , [47635,47636]
===
match
---
name: DefaultDict [36685,36696]
name: DefaultDict [37188,37199]
===
match
---
name: dagbag [27818,27824]
name: dagbag [27818,27824]
===
match
---
not_test [59249,59267]
not_test [59752,59770]
===
match
---
name: self [11061,11065]
name: self [11061,11065]
===
match
---
atom_expr [20019,20167]
atom_expr [20019,20167]
===
match
---
arglist [8071,8131]
arglist [8071,8131]
===
match
---
simple_stmt [58809,58842]
simple_stmt [59312,59345]
===
match
---
name: Optional [11540,11548]
name: Optional [11540,11548]
===
match
---
trailer [4968,4991]
trailer [4968,4991]
===
match
---
name: utcnow [74700,74706]
name: utcnow [75203,75209]
===
match
---
arglist [60013,60216]
arglist [60516,60719]
===
match
---
if_stmt [34169,35532]
if_stmt [34672,36035]
===
match
---
trailer [33688,33700]
trailer [34191,34203]
===
match
---
atom_expr [43406,43523]
atom_expr [43909,44026]
===
match
---
name: old_states [32771,32781]
name: old_states [33274,33284]
===
match
---
name: exception [26634,26643]
name: exception [26634,26643]
===
match
---
if_stmt [42997,44140]
if_stmt [43500,44643]
===
match
---
param [11531,11535]
param [11531,11535]
===
match
---
string: "Exiting gracefully upon receiving signal %s" [31244,31289]
string: "Exiting gracefully upon receiving signal %s" [31621,31666]
===
match
---
name: dag_ids [15332,15339]
name: dag_ids [15332,15339]
===
match
---
expr_stmt [30675,30764]
expr_stmt [30929,31018]
===
match
---
trailer [16387,16399]
trailer [16387,16399]
===
match
---
trailer [16729,16731]
trailer [16729,16731]
===
match
---
operator: != [80611,80613]
operator: != [81114,81116]
===
match
---
operator: != [33847,33849]
operator: != [34350,34352]
===
match
---
operator: , [34286,34287]
operator: , [34789,34790]
===
match
---
string: "Processor agent is not started." [77634,77667]
string: "Processor agent is not started." [78137,78170]
===
match
---
atom [43685,43730]
atom [44188,44233]
===
match
---
trailer [75569,75611]
trailer [76072,76114]
===
match
---
name: ti [18406,18408]
name: ti [18406,18408]
===
match
---
name: List [56190,56194]
name: List [56693,56697]
===
match
---
operator: , [31844,31845]
operator: , [32347,32348]
===
match
---
name: queued_by_job [80510,80523]
name: queued_by_job [81013,81026]
===
match
---
operator: = [24785,24786]
operator: = [24785,24786]
===
match
---
name: _parent_channel [11112,11127]
name: _parent_channel [11112,11127]
===
match
---
trailer [65252,65256]
trailer [65755,65759]
===
match
---
trailer [72294,72319]
trailer [72797,72822]
===
match
---
string: """         The actual scheduler loop. The main steps in the loop are:             #. Harvest DAG parsing results through DagFileProcessorAgent             #. Find and queue executable tasks                 #. Change task instance state in DB                 #. Queue tasks in executor             #. Heartbeat executor                 #. Execute queued tasks in executor asynchronously                 #. Sync on the states of running tasks          Following is a graphic representation of these steps.          .. image:: ../docs/apache-airflow/img/scheduler_loop.jpg          :rtype: None         """ [56532,57136]
string: """         The actual scheduler loop. The main steps in the loop are:             #. Harvest DAG parsing results through DagFileProcessorAgent             #. Find and queue executable tasks                 #. Change task instance state in DB                 #. Queue tasks in executor             #. Heartbeat executor                 #. Execute queued tasks in executor asynchronously                 #. Sync on the states of running tasks          Following is a graphic representation of these steps.          .. image:: ../docs/apache-airflow/img/scheduler_loop.jpg          :rtype: None         """ [57035,57639]
===
match
---
suite [40652,45097]
suite [41155,45600]
===
match
---
operator: , [80985,80986]
operator: , [81488,81489]
===
match
---
trailer [22141,22143]
trailer [22141,22143]
===
match
---
trailer [29563,29572]
trailer [29817,29826]
===
match
---
name: session [79386,79393]
name: session [79889,79896]
===
match
---
atom_expr [80561,80590]
atom_expr [81064,81093]
===
match
---
trailer [77735,77803]
trailer [78238,78306]
===
match
---
decorator [11175,11185]
decorator [11175,11185]
===
match
---
name: _get_next_dagruns_to_examine [63010,63038]
name: _get_next_dagruns_to_examine [63513,63541]
===
match
---
name: task [20388,20392]
name: task [20388,20392]
===
match
---
trailer [9084,9093]
trailer [9084,9093]
===
match
---
string: 'timed_out' [74454,74465]
string: 'timed_out' [74957,74968]
===
match
---
name: full_filepath [53059,53072]
name: full_filepath [53562,53575]
===
match
---
string: "Setting the following tasks to queued state:\n\t%s" [45409,45461]
string: "Setting the following tasks to queued state:\n\t%s" [45912,45964]
===
match
---
name: EventScheduler [2560,2574]
name: EventScheduler [2560,2574]
===
match
---
operator: = [52277,52278]
operator: = [52780,52781]
===
match
---
name: sig_name [31501,31509]
name: sig_name [32004,32012]
===
match
---
argument [40237,40252]
argument [40740,40755]
===
match
---
operator: , [24216,24217]
operator: , [24216,24217]
===
match
---
suite [5043,5075]
suite [5043,5075]
===
match
---
annassign [17905,17969]
annassign [17905,17969]
===
match
---
atom_expr [59030,59056]
atom_expr [59533,59559]
===
match
---
name: dag_id [64179,64185]
name: dag_id [64682,64688]
===
match
---
name: resettable_states [80153,80170]
name: resettable_states [80656,80673]
===
match
---
name: execution_date [68261,68275]
name: execution_date [68764,68778]
===
match
---
name: get_event_buffer [50942,50958]
name: get_event_buffer [51445,51461]
===
match
---
atom_expr [4637,4664]
atom_expr [4637,4664]
===
match
---
name: self [77583,77587]
name: self [78086,78090]
===
match
---
atom_expr [30272,30281]
atom_expr [30526,30535]
===
match
---
name: subquery [34529,34537]
name: subquery [35032,35040]
===
match
---
atom_expr [7016,7067]
atom_expr [7016,7067]
===
match
---
name: key [41276,41279]
name: key [41779,41782]
===
match
---
name: gauge [78096,78101]
name: gauge [78599,78604]
===
match
---
atom_expr [51555,51576]
atom_expr [52058,52079]
===
match
---
trailer [9326,9338]
trailer [9326,9338]
===
match
---
trailer [39598,39603]
trailer [40101,40106]
===
match
---
operator: } [45920,45921]
operator: } [46423,46424]
===
match
---
name: self [15358,15362]
name: self [15358,15362]
===
match
---
trailer [75625,75658]
trailer [76128,76161]
===
match
---
expr_stmt [50820,50904]
expr_stmt [51323,51407]
===
match
---
operator: + [17269,17270]
operator: + [17269,17270]
===
match
---
name: terminate [54865,54874]
name: terminate [55368,55377]
===
match
---
name: redirect_stderr [1019,1034]
name: redirect_stderr [1019,1034]
===
match
---
atom [52741,52927]
atom [53244,53430]
===
match
---
tfpdef [25316,25332]
tfpdef [25316,25332]
===
match
---
trailer [61129,61136]
trailer [61632,61639]
===
match
---
atom_expr [34873,34887]
atom_expr [35376,35390]
===
match
---
name: log [79235,79238]
name: log [79738,79741]
===
match
---
operator: , [81226,81227]
operator: , [81729,81730]
===
match
---
name: TI [45892,45894]
name: TI [46395,46397]
===
match
---
atom_expr [50991,51012]
atom_expr [51494,51515]
===
match
---
name: defaultdict [984,995]
name: defaultdict [984,995]
===
match
---
name: query [80056,80061]
name: query [80559,80564]
===
match
---
trailer [27215,27217]
trailer [27215,27217]
===
match
---
name: isoformat [18585,18594]
name: isoformat [18585,18594]
===
match
---
atom_expr [39762,39779]
atom_expr [40265,40282]
===
match
---
name: active_dagruns_filter [67896,67917]
name: active_dagruns_filter [68399,68420]
===
match
---
simple_stmt [44131,44140]
simple_stmt [44634,44643]
===
match
---
string: "state" [79681,79688]
string: "state" [80184,80191]
===
match
---
comparison [52399,52420]
comparison [52902,52923]
===
match
---
name: self [60313,60317]
name: self [60816,60820]
===
match
---
trailer [10327,10343]
trailer [10327,10343]
===
match
---
name: airflow [2824,2831]
name: airflow [2824,2831]
===
match
---
expr_stmt [24722,24754]
expr_stmt [24722,24754]
===
match
---
name: CallbackRequest [22532,22547]
name: CallbackRequest [22532,22547]
===
match
---
name: Exception [31584,31593]
name: Exception [32087,32096]
===
match
---
string: 'scheduler.tasks.running' [45192,45217]
string: 'scheduler.tasks.running' [45695,45720]
===
match
---
name: RUNNING [80898,80905]
name: RUNNING [81401,81408]
===
match
---
name: super [30209,30214]
name: super [30463,30468]
===
match
---
operator: = [66071,66072]
operator: = [66574,66575]
===
match
---
name: self [38069,38073]
name: self [38572,38576]
===
match
---
name: with_try_number [52225,52240]
name: with_try_number [52728,52743]
===
match
---
name: stacktrace [22215,22225]
name: stacktrace [22215,22225]
===
match
---
testlist_comp [53191,53216]
testlist_comp [53694,53719]
===
match
---
operator: , [74002,74003]
operator: , [74505,74506]
===
match
---
name: int [54041,54044]
name: int [54544,54547]
===
match
---
trailer [7304,7306]
trailer [7304,7306]
===
match
---
name: models [39746,39752]
name: models [40249,40255]
===
match
---
suite [30805,31040]
suite [31059,31294]
===
match
---
name: EXECUTION_STATES [2161,2177]
name: EXECUTION_STATES [2161,2177]
===
match
---
operator: = [81340,81341]
operator: = [81843,81844]
===
match
---
name: dagbag [23315,23321]
name: dagbag [23315,23321]
===
match
---
name: dag [71984,71987]
name: dag [72487,72490]
===
match
---
name: property [5003,5011]
name: property [5003,5011]
===
match
---
funcdef [72508,76035]
funcdef [73011,76538]
===
match
---
import_from [2451,2517]
import_from [2451,2517]
===
match
---
name: Tuple [13744,13749]
name: Tuple [13744,13749]
===
match
---
trailer [17334,17462]
trailer [17334,17462]
===
match
---
name: self [60410,60414]
name: self [60913,60917]
===
match
---
name: slots_available [48631,48646]
name: slots_available [49134,49149]
===
match
---
name: filter [16205,16211]
name: filter [16205,16211]
===
match
---
name: str [36484,36487]
name: str [36987,36990]
===
match
---
atom_expr [43686,43706]
atom_expr [44189,44209]
===
match
---
operator: , [53333,53334]
operator: , [53836,53837]
===
match
---
name: guard [66652,66657]
name: guard [67155,67160]
===
match
---
decorator [77809,77826]
decorator [78312,78329]
===
match
---
name: task_id [18547,18554]
name: task_id [18547,18554]
===
match
---
trailer [64260,64269]
trailer [64763,64772]
===
match
---
name: self [12021,12025]
name: self [12021,12025]
===
match
---
operator: = [22327,22328]
operator: = [22327,22328]
===
match
---
string: "Executor full, skipping critical section" [65707,65749]
string: "Executor full, skipping critical section" [66210,66252]
===
match
---
trailer [14330,14342]
trailer [14330,14342]
===
match
---
operator: , [2775,2776]
operator: , [2775,2776]
===
match
---
name: task_id [16580,16587]
name: task_id [16580,16587]
===
match
---
name: DagRun [1937,1943]
name: DagRun [1937,1943]
===
match
---
try_stmt [12455,13444]
try_stmt [12455,13444]
===
match
---
param [22508,22549]
param [22508,22549]
===
match
---
trailer [23937,23944]
trailer [23937,23944]
===
match
---
trailer [43346,43354]
trailer [43849,43857]
===
match
---
atom_expr [59655,59668]
atom_expr [60158,60171]
===
match
---
name: get_task [18345,18353]
name: get_task [18345,18353]
===
match
---
operator: + [18564,18565]
operator: + [18564,18565]
===
match
---
operator: == [68068,68070]
operator: == [68571,68573]
===
match
---
name: isinstance [16835,16845]
name: isinstance [16835,16845]
===
match
---
suite [23277,23348]
suite [23277,23348]
===
match
---
trailer [80662,80670]
trailer [81165,81173]
===
match
---
atom_expr [44965,44985]
atom_expr [45468,45488]
===
match
---
name: old_states [60473,60483]
name: old_states [60976,60986]
===
match
---
name: Stats [45180,45185]
name: Stats [45683,45688]
===
match
---
name: log [55918,55921]
name: log [56421,56424]
===
match
---
trailer [64348,64363]
trailer [64851,64866]
===
match
---
simple_stmt [70194,70333]
simple_stmt [70697,70836]
===
match
---
name: log [23567,23570]
name: log [23567,23570]
===
match
---
arglist [48593,48646]
arglist [49096,49149]
===
match
---
name: logging [15275,15282]
name: logging [15275,15282]
===
match
---
operator: , [7664,7665]
operator: , [7664,7665]
===
match
---
tfpdef [76826,76841]
tfpdef [77329,77344]
===
match
---
name: self [57944,57948]
name: self [58447,58451]
===
match
---
string: """     Process a Python file containing Airflow DAGs.      This includes:      1. Execute the file and look for DAG objects in the namespace.     2. Execute any Callbacks if passed to DagFileProcessor.process_file     3. Serialize the DAGs and save it to DB (or update existing record in the DB).     4. Pickle the DAG and save it to the DB (if necessary).     5. Record any errors importing the file into ORM      Returns a tuple of 'number of dags found' and 'the count of import errors'      :param dag_ids: If specified, only look at these DAG ID's     :type dag_ids: List[str]     :param log: Logger to save the processing process     :type log: logging.Logger     """ [14471,15145]
string: """     Process a Python file containing Airflow DAGs.      This includes:      1. Execute the file and look for DAG objects in the namespace.     2. Execute any Callbacks if passed to DagFileProcessor.process_file     3. Serialize the DAGs and save it to DB (or update existing record in the DB).     4. Pickle the DAG and save it to the DB (if necessary).     5. Record any errors importing the file into ORM      Returns a tuple of 'number of dags found' and 'the count of import errors'      :param dag_ids: If specified, only look at these DAG ID's     :type dag_ids: List[str]     :param log: Logger to save the processing process     :type log: logging.Logger     """ [14471,15145]
===
match
---
name: and_ [49255,49259]
name: and_ [49758,49762]
===
match
---
trailer [15868,15872]
trailer [15868,15872]
===
match
---
simple_stmt [72021,72269]
simple_stmt [72524,72772]
===
match
---
name: sla_miss_callback [18987,19004]
name: sla_miss_callback [18987,19004]
===
match
---
suite [60955,61064]
suite [61458,61567]
===
match
---
trailer [59991,60234]
trailer [60494,60737]
===
match
---
funcdef [46081,47324]
funcdef [46584,47827]
===
match
---
operator: , [51137,51138]
operator: , [51640,51641]
===
match
---
name: run [59037,59040]
name: run [59540,59543]
===
match
---
name: dag_id [71115,71121]
name: dag_id [71618,71624]
===
match
---
not_test [13456,13484]
not_test [13456,13484]
===
match
---
argument [46932,46964]
argument [47435,47467]
===
match
---
or_test [34172,34209]
or_test [34675,34712]
===
match
---
operator: -> [10073,10075]
operator: -> [10073,10075]
===
match
---
operator: , [79158,79159]
operator: , [79661,79662]
===
match
---
atom_expr [75230,75256]
atom_expr [75733,75759]
===
match
---
name: dag_map [36897,36904]
name: dag_map [37400,37407]
===
match
---
if_stmt [17833,21358]
if_stmt [17833,21358]
===
match
---
expr_stmt [53970,54004]
expr_stmt [54473,54507]
===
match
---
simple_stmt [82580,82599]
simple_stmt [83083,83102]
===
match
---
trailer [8041,8049]
trailer [8041,8049]
===
match
---
operator: , [75529,75530]
operator: , [76032,76033]
===
match
---
atom_expr [30945,30959]
atom_expr [31199,31213]
===
match
---
for_stmt [20293,20594]
for_stmt [20293,20594]
===
match
---
simple_stmt [51247,51316]
simple_stmt [51750,51819]
===
match
---
number: 0 [37974,37975]
number: 0 [38477,38478]
===
match
---
atom_expr [41293,41311]
atom_expr [41796,41814]
===
match
---
operator: == [71290,71292]
operator: == [71793,71795]
===
match
---
expr_stmt [4088,4115]
expr_stmt [4088,4115]
===
match
---
name: num_times_parse_dags [54289,54309]
name: num_times_parse_dags [54792,54812]
===
match
---
exprlist [40597,40617]
exprlist [41100,41120]
===
match
---
operator: = [18224,18225]
operator: = [18224,18225]
===
match
---
name: task_concurrency [43507,43523]
name: task_concurrency [44010,44026]
===
match
---
trailer [18095,18110]
trailer [18095,18110]
===
match
---
if_stmt [77390,77567]
if_stmt [77893,78070]
===
match
---
argument [69815,69837]
argument [70318,70340]
===
match
---
argument [7744,7759]
argument [7744,7759]
===
match
---
name: guard [60842,60847]
name: guard [61345,61350]
===
match
---
funcdef [31827,32689]
funcdef [32330,33192]
===
match
---
name: dagbag [24218,24224]
name: dagbag [24218,24224]
===
match
---
operator: = [30139,30140]
operator: = [30393,30394]
===
match
---
atom_expr [16643,16655]
atom_expr [16643,16655]
===
match
---
atom_expr [33487,33506]
atom_expr [33990,34009]
===
match
---
simple_stmt [4312,4380]
simple_stmt [4312,4380]
===
match
---
name: dag_run [38425,38432]
name: dag_run [38928,38935]
===
match
---
operator: , [80019,80020]
operator: , [80522,80523]
===
match
---
simple_stmt [24527,24567]
simple_stmt [24527,24567]
===
match
---
trailer [54623,54625]
trailer [55126,55128]
===
match
---
param [78335,78358]
param [78838,78861]
===
match
---
atom_expr [75621,75684]
atom_expr [76124,76187]
===
match
---
name: airflow [2218,2225]
name: airflow [2218,2225]
===
match
---
simple_stmt [31905,32236]
simple_stmt [32408,32739]
===
match
---
name: dm [68133,68135]
name: dm [68636,68638]
===
match
---
atom_expr [35991,36012]
atom_expr [36494,36515]
===
match
---
atom_expr [4023,4044]
atom_expr [4023,4044]
===
match
---
name: TI [45857,45859]
name: TI [46360,46362]
===
match
---
simple_stmt [78014,78078]
simple_stmt [78517,78581]
===
match
---
name: TI [45585,45587]
name: TI [46088,46090]
===
match
---
trailer [72393,72418]
trailer [72896,72921]
===
match
---
name: self [4312,4316]
name: self [4312,4316]
===
match
---
expr_stmt [51132,51148]
expr_stmt [51635,51651]
===
match
---
name: get_dag [43253,43260]
name: get_dag [43756,43763]
===
match
---
name: wait_until_finished [58475,58494]
name: wait_until_finished [58978,58997]
===
match
---
name: logging [7053,7060]
name: logging [7053,7060]
===
match
---
name: session [23885,23892]
name: session [23885,23892]
===
match
---
atom_expr [50205,50220]
atom_expr [50708,50723]
===
match
---
trailer [59837,59846]
trailer [60340,60349]
===
match
---
operator: == [22119,22121]
operator: == [22119,22121]
===
match
---
decorated [66896,67285]
decorated [67399,67788]
===
match
---
testlist_star_expr [75514,75546]
testlist_star_expr [76017,76049]
===
match
---
name: task_ids [24446,24454]
name: task_ids [24446,24454]
===
match
---
argument [58929,58951]
argument [59432,59454]
===
match
---
atom_expr [22050,22143]
atom_expr [22050,22143]
===
match
---
operator: { [78122,78123]
operator: { [78625,78626]
===
match
---
operator: , [29681,29682]
operator: , [29935,29936]
===
match
---
trailer [34360,34362]
trailer [34863,34865]
===
match
---
arglist [35635,35779]
arglist [36138,36282]
===
match
---
name: _start_time [4624,4635]
name: _start_time [4624,4635]
===
match
---
trailer [31806,31811]
trailer [32309,32314]
===
match
---
param [21406,21423]
param [21406,21423]
===
match
---
trailer [33493,33506]
trailer [33996,34009]
===
match
---
trailer [8501,8503]
trailer [8501,8503]
===
match
---
atom_expr [80987,80997]
atom_expr [81490,81500]
===
match
---
atom_expr [9945,9995]
atom_expr [9945,9995]
===
match
---
param [21424,21438]
param [21424,21438]
===
match
---
simple_stmt [58454,58497]
simple_stmt [58957,59000]
===
match
---
name: List [36468,36472]
name: List [36971,36975]
===
match
---
simple_stmt [71624,71685]
simple_stmt [72127,72188]
===
match
---
operator: { [9242,9243]
operator: { [9242,9243]
===
match
---
name: SlaMiss [17646,17653]
name: SlaMiss [17646,17653]
===
match
---
name: ti_concurrency_query [36819,36839]
name: ti_concurrency_query [37322,37342]
===
match
---
operator: = [38721,38722]
operator: = [39224,39225]
===
match
---
name: x [45359,45360]
name: x [45862,45863]
===
match
---
atom_expr [21045,21055]
atom_expr [21045,21055]
===
match
---
operator: = [48931,48932]
operator: = [49434,49435]
===
match
---
operator: , [36012,36013]
operator: , [36515,36516]
===
match
---
name: task_map [36994,37002]
name: task_map [37497,37505]
===
match
---
trailer [74720,74744]
trailer [75223,75247]
===
match
---
name: dttm [17421,17425]
name: dttm [17421,17425]
===
match
---
trailer [80142,80148]
trailer [80645,80651]
===
match
---
atom_expr [71175,71187]
atom_expr [71678,71690]
===
match
---
name: ti [46894,46896]
name: ti [47397,47399]
===
match
---
name: self [58585,58589]
name: self [59088,59092]
===
match
---
trailer [53532,53537]
trailer [54035,54040]
===
match
---
arglist [71039,71069]
arglist [71542,71572]
===
match
---
name: _dag_ids [9085,9093]
name: _dag_ids [9085,9093]
===
match
---
operator: = [66251,66252]
operator: = [66754,66755]
===
match
---
expr_stmt [34223,34362]
expr_stmt [34726,34865]
===
match
---
trailer [77682,77698]
trailer [78185,78201]
===
match
---
expr_stmt [81743,81772]
expr_stmt [82246,82275]
===
match
---
name: tis_with_right_state [50969,50989]
name: tis_with_right_state [51472,51492]
===
match
---
comparison [35544,35559]
comparison [36047,36062]
===
match
---
if_stmt [26782,27088]
if_stmt [26782,27088]
===
match
---
atom_expr [31650,31661]
atom_expr [32153,32164]
===
match
---
name: signal [30931,30937]
name: signal [31185,31191]
===
match
---
name: SerializedDagModel [1986,2004]
name: SerializedDagModel [1986,2004]
===
match
---
fstring_expr [19699,19746]
fstring_expr [19699,19746]
===
match
---
name: filter_for_tis [52039,52053]
name: filter_for_tis [52542,52556]
===
match
---
simple_stmt [1944,2005]
simple_stmt [1944,2005]
===
match
---
name: self [82100,82104]
name: self [82603,82607]
===
match
---
trailer [52031,52038]
trailer [52534,52541]
===
match
---
trailer [58639,58648]
trailer [59142,59151]
===
match
---
name: Session [47389,47396]
name: Session [47892,47899]
===
match
---
string: "Running SchedulerJob.adopt_or_reset_orphaned_tasks with retries. Try %d of %d" [79023,79102]
string: "Running SchedulerJob.adopt_or_reset_orphaned_tasks with retries. Try %d of %d" [79526,79605]
===
match
---
simple_stmt [58723,58792]
simple_stmt [59226,59295]
===
match
---
argument [57739,57751]
argument [58242,58254]
===
match
---
annassign [27350,27470]
annassign [27350,27470]
===
match
---
name: self [54604,54608]
name: self [55107,55111]
===
match
---
expr_stmt [72361,72502]
expr_stmt [72864,73005]
===
match
---
name: self [31022,31026]
name: self [31276,31280]
===
match
---
name: log [30255,30258]
name: log [30509,30512]
===
match
---
parameters [13725,13731]
parameters [13725,13731]
===
match
---
decorated [23786,24179]
decorated [23786,24179]
===
match
---
name: error [74767,74772]
name: error [75270,75275]
===
match
---
name: ti [53358,53360]
name: ti [53861,53863]
===
match
---
name: _send_sla_callbacks_to_processor [77179,77211]
name: _send_sla_callbacks_to_processor [77682,77714]
===
match
---
trailer [23017,23021]
trailer [23017,23021]
===
match
---
operator: -> [61178,61180]
operator: -> [61681,61683]
===
match
---
atom_expr [30353,30397]
atom_expr [30607,30651]
===
match
---
name: bool [5270,5274]
name: bool [5270,5274]
===
match
---
simple_stmt [75981,76035]
simple_stmt [76484,76538]
===
match
---
atom_expr [80966,81017]
atom_expr [81469,81520]
===
match
---
name: TI [38612,38614]
name: TI [39115,39117]
===
match
---
name: sqlalchemy [2904,2914]
name: sqlalchemy [2904,2914]
===
match
---
simple_stmt [10711,10740]
simple_stmt [10711,10740]
===
match
---
param [77853,77858]
param [78356,78361]
===
match
---
subscriptlist [36697,36705]
subscriptlist [37200,37208]
===
match
---
atom_expr [52279,52307]
atom_expr [52782,52810]
===
match
---
name: self [76820,76824]
name: self [77323,77327]
===
match
---
trailer [42968,42973]
trailer [43471,43476]
===
match
---
name: List [32783,32787]
name: List [33286,33290]
===
match
---
atom [34614,34745]
atom [35117,35248]
===
match
---
simple_stmt [59073,59129]
simple_stmt [59576,59632]
===
match
---
operator: = [29392,29393]
operator: = [29646,29647]
===
match
---
arglist [37974,38021]
arglist [38477,38524]
===
match
---
trailer [75085,75319]
trailer [75588,75822]
===
match
---
trailer [38629,38639]
trailer [39132,39142]
===
match
---
trailer [23330,23346]
trailer [23330,23346]
===
match
---
name: info [26828,26832]
name: info [26828,26832]
===
match
---
atom_expr [67270,67284]
atom_expr [67773,67787]
===
match
---
name: join [13285,13289]
name: join [13285,13289]
===
match
---
expr_stmt [31639,31661]
expr_stmt [32142,32164]
===
match
---
operator: , [2949,2950]
operator: , [2949,2950]
===
match
---
name: QUEUED [80013,80019]
name: QUEUED [80516,80522]
===
match
---
atom_expr [60342,60366]
atom_expr [60845,60869]
===
match
---
funcdef [21381,22429]
funcdef [21381,22429]
===
match
---
name: str [5307,5310]
name: str [5307,5310]
===
match
---
operator: , [17386,17387]
operator: , [17386,17387]
===
match
---
name: self [31310,31314]
name: self [31687,31691]
===
match
---
name: stats [38749,38754]
name: stats [39252,39257]
===
match
---
expr_stmt [48513,48552]
expr_stmt [49016,49055]
===
match
---
fstring_string:               [19746,19759]
fstring_string:               [19746,19759]
===
match
---
operator: -> [67397,67399]
operator: -> [67900,67902]
===
match
---
name: dags_needing_dagruns [67106,67126]
name: dags_needing_dagruns [67609,67629]
===
match
---
simple_stmt [47064,47159]
simple_stmt [47567,47662]
===
match
---
operator: = [8929,8930]
operator: = [8929,8930]
===
match
---
name: RUNNING [80620,80627]
name: RUNNING [81123,81130]
===
match
---
name: ti [18245,18247]
name: ti [18245,18247]
===
match
---
atom_expr [22300,22389]
atom_expr [22300,22389]
===
match
---
param [5233,5248]
param [5233,5248]
===
match
---
operator: < [17280,17281]
operator: < [17280,17281]
===
match
---
simple_stmt [56271,56319]
simple_stmt [56774,56822]
===
match
---
simple_stmt [36676,36726]
simple_stmt [37179,37229]
===
match
---
atom_expr [18066,18074]
atom_expr [18066,18074]
===
match
---
trailer [57691,57700]
trailer [58194,58203]
===
match
---
name: tis_to_set_to_scheduled [49978,50001]
name: tis_to_set_to_scheduled [50481,50504]
===
match
---
name: guard [62965,62970]
name: guard [63468,63473]
===
match
---
name: callback_requests [22982,22999]
name: callback_requests [22982,22999]
===
match
---
trailer [54051,54058]
trailer [54554,54561]
===
match
---
atom_expr [36685,36706]
atom_expr [37188,37209]
===
match
---
simple_stmt [8263,8313]
simple_stmt [8263,8313]
===
match
---
name: request [53440,53447]
name: request [53943,53950]
===
match
---
name: _emit_pool_metrics [57771,57789]
name: _emit_pool_metrics [58274,58292]
===
match
---
name: info [50498,50502]
name: info [51001,51005]
===
match
---
trailer [56189,56200]
trailer [56692,56703]
===
match
---
name: dag_run [75400,75407]
name: dag_run [75903,75910]
===
match
---
trailer [59986,59991]
trailer [60489,60494]
===
match
---
trailer [23457,23483]
trailer [23457,23483]
===
match
---
name: _log [30277,30281]
name: _log [30531,30535]
===
match
---
name: dag_model [72463,72472]
name: dag_model [72966,72975]
===
match
---
trailer [45353,45386]
trailer [45856,45889]
===
match
---
atom_expr [66417,66482]
atom_expr [66920,66985]
===
match
---
name: session [76026,76033]
name: session [76529,76536]
===
match
---
name: conf [32450,32454]
name: conf [32953,32957]
===
match
---
operator: , [9027,9028]
operator: , [9027,9028]
===
match
---
name: TaskInstance [34639,34651]
name: TaskInstance [35142,35154]
===
match
---
name: task_instances_to_examine [38935,38960]
name: task_instances_to_examine [39438,39463]
===
match
---
atom_expr [36548,36563]
atom_expr [37051,37066]
===
match
---
trailer [52179,52183]
trailer [52682,52686]
===
match
---
and_test [52586,52653]
and_test [53089,53156]
===
match
---
trailer [57156,57172]
trailer [57659,57675]
===
match
---
name: tis_to_set_to_scheduled [50456,50479]
name: tis_to_set_to_scheduled [50959,50982]
===
match
---
trailer [54660,54662]
trailer [55163,55165]
===
match
---
operator: , [56390,56391]
operator: , [56893,56894]
===
match
---
name: send_callback_to_execute [77135,77159]
name: send_callback_to_execute [77638,77662]
===
match
---
for_stmt [73775,73920]
for_stmt [74278,74423]
===
match
---
trailer [17937,17952]
trailer [17937,17952]
===
match
---
name: _process [10935,10943]
name: _process [10935,10943]
===
match
---
trailer [74601,74631]
trailer [75104,75134]
===
match
---
name: or_ [49837,49840]
name: or_ [50340,50343]
===
match
---
name: EX_OK [31391,31396]
name: EX_OK [31768,31773]
===
match
---
name: ti [24771,24773]
name: ti [24771,24773]
===
match
---
atom_expr [79883,79947]
atom_expr [80386,80450]
===
match
---
operator: , [39006,39007]
operator: , [39509,39510]
===
match
---
name: dag_concurrency_map [42137,42156]
name: dag_concurrency_map [42640,42659]
===
match
---
string: "Not executing %s since the task concurrency for" [43912,43961]
string: "Not executing %s since the task concurrency for" [44415,44464]
===
match
---
trailer [27422,27424]
trailer [27422,27424]
===
match
---
expr_stmt [81331,81403]
expr_stmt [81834,81906]
===
match
---
atom_expr [39741,39758]
atom_expr [40244,40261]
===
match
---
argument [46690,46711]
argument [47193,47214]
===
match
---
comparison [17675,17709]
comparison [17675,17709]
===
match
---
simple_stmt [11405,11465]
simple_stmt [11405,11465]
===
match
---
name: session [78335,78342]
name: session [78838,78845]
===
match
---
arglist [30563,30595]
arglist [30817,30849]
===
match
---
operator: , [45855,45856]
operator: , [46358,46359]
===
match
---
except_clause [60869,60897]
except_clause [61372,61400]
===
match
---
trailer [36472,36494]
trailer [36975,36997]
===
match
---
import_from [2081,2112]
import_from [2081,2112]
===
match
---
trailer [17645,17654]
trailer [17645,17654]
===
match
---
atom_expr [40911,40930]
atom_expr [41414,41433]
===
match
---
name: filter [36578,36584]
name: filter [37081,37087]
===
match
---
name: send [66327,66331]
name: send [66830,66834]
===
match
---
name: file_path [5020,5029]
name: file_path [5020,5029]
===
match
---
operator: , [68020,68021]
operator: , [68523,68524]
===
match
---
name: dag_id [20710,20716]
name: dag_id [20710,20716]
===
match
---
simple_stmt [57246,57309]
simple_stmt [57749,57812]
===
match
---
simple_stmt [31139,31222]
simple_stmt [31393,31476]
===
match
---
comparison [16622,16655]
comparison [16622,16655]
===
match
---
name: resettable_states [79969,79986]
name: resettable_states [80472,80489]
===
match
---
name: task_id [20138,20145]
name: task_id [20138,20145]
===
match
---
trailer [9349,9356]
trailer [9349,9356]
===
match
---
trailer [38453,38519]
trailer [38956,39022]
===
match
---
name: synchronize_session [45939,45958]
name: synchronize_session [46442,46461]
===
match
---
trailer [4654,4663]
trailer [4654,4663]
===
match
---
operator: , [35722,35723]
operator: , [36225,36226]
===
match
---
name: pools [40866,40871]
name: pools [41369,41374]
===
match
---
name: BaseProcess [4360,4371]
name: BaseProcess [4360,4371]
===
match
---
atom_expr [79497,79510]
atom_expr [80000,80013]
===
match
---
arith_expr [18543,18596]
arith_expr [18543,18596]
===
match
---
name: send_callback_to_execute [53415,53439]
name: send_callback_to_execute [53918,53942]
===
match
---
raise_stmt [16884,17058]
raise_stmt [16884,17058]
===
match
---
simple_stmt [53458,53483]
simple_stmt [53961,53986]
===
match
---
operator: = [20811,20812]
operator: = [20811,20812]
===
match
---
name: _run_scheduler_loop [54775,54794]
name: _run_scheduler_loop [55278,55297]
===
match
---
name: pop [52292,52295]
name: pop [52795,52798]
===
match
---
operator: , [37132,37133]
operator: , [37635,37636]
===
match
---
name: task_instance [43459,43472]
name: task_instance [43962,43975]
===
match
---
name: ti [52964,52966]
name: ti [53467,53469]
===
match
---
atom_expr [40165,40262]
atom_expr [40668,40765]
===
match
---
operator: = [74427,74428]
operator: = [74930,74931]
===
match
---
arglist [3175,3253]
arglist [3175,3253]
===
match
---
name: dag_run [76471,76478]
name: dag_run [76974,76981]
===
match
---
name: fileloc [74293,74300]
name: fileloc [74796,74803]
===
match
---
trailer [14208,14220]
trailer [14208,14220]
===
match
---
suite [65540,66258]
suite [66043,66761]
===
match
---
operator: , [17425,17426]
operator: , [17425,17426]
===
match
---
simple_stmt [10004,10025]
simple_stmt [10004,10025]
===
match
---
trailer [79399,79413]
trailer [79902,79916]
===
match
---
trailer [70039,70059]
trailer [70542,70562]
===
match
---
name: datetime [14070,14078]
name: datetime [14070,14078]
===
match
---
trailer [78926,78943]
trailer [79429,79446]
===
match
---
simple_stmt [31763,31790]
simple_stmt [32266,32293]
===
match
---
name: dag_concurrency_limit [42517,42538]
name: dag_concurrency_limit [43020,43041]
===
match
---
simple_stmt [33427,33443]
simple_stmt [33930,33946]
===
match
---
param [70579,70584]
param [71082,71087]
===
match
---
atom_expr [26485,26554]
atom_expr [26485,26554]
===
match
---
atom [36497,36661]
atom [37000,37164]
===
match
---
trailer [64122,64129]
trailer [64625,64632]
===
match
---
operator: @ [60262,60263]
operator: @ [60765,60766]
===
match
---
operator: = [7725,7726]
operator: = [7725,7726]
===
match
---
import_from [2113,2177]
import_from [2113,2177]
===
match
---
simple_stmt [70985,71393]
simple_stmt [71488,71896]
===
match
---
import_from [1862,1902]
import_from [1862,1902]
===
match
---
trailer [58474,58494]
trailer [58977,58997]
===
match
---
trailer [47072,47077]
trailer [47575,47580]
===
match
---
atom_expr [12602,12615]
atom_expr [12602,12615]
===
match
---
atom_expr [20388,20398]
atom_expr [20388,20398]
===
match
---
argument [58775,58790]
argument [59278,59293]
===
match
---
name: sql_conn [30483,30491]
name: sql_conn [30737,30745]
===
match
---
trailer [11493,11497]
trailer [11493,11497]
===
match
---
argument [46815,46836]
argument [47318,47339]
===
match
---
string: "Exception when executing Executor.end" [55734,55773]
string: "Exception when executing Executor.end" [56237,56276]
===
match
---
atom_expr [50489,50574]
atom_expr [50992,51077]
===
match
---
trailer [77786,77793]
trailer [78289,78296]
===
match
---
trailer [79552,79569]
trailer [80055,80072]
===
match
---
name: slas [17836,17840]
name: slas [17836,17840]
===
match
---
operator: , [6854,6855]
operator: , [6854,6855]
===
match
---
atom_expr [30675,30686]
atom_expr [30929,30940]
===
match
---
trailer [60717,60725]
trailer [61220,61228]
===
match
---
atom_expr [78058,78076]
atom_expr [78561,78579]
===
match
---
name: starved_pools [38871,38884]
name: starved_pools [39374,39387]
===
match
---
atom_expr [79787,79858]
atom_expr [80290,80361]
===
match
---
atom_expr [81794,81855]
atom_expr [82297,82358]
===
match
---
name: TI [52008,52010]
name: TI [52511,52513]
===
match
---
string: 'sq' [16422,16426]
string: 'sq' [16422,16426]
===
match
---
operator: , [1034,1035]
operator: , [1034,1035]
===
match
---
name: log [40948,40951]
name: log [41451,41454]
===
match
---
expr_stmt [72285,72326]
expr_stmt [72788,72829]
===
match
---
atom_expr [55357,55382]
atom_expr [55860,55885]
===
match
---
name: slot_stats [77973,77983]
name: slot_stats [78476,78486]
===
match
---
operator: , [45461,45462]
operator: , [45964,45965]
===
match
---
name: group_by [64326,64334]
name: group_by [64829,64837]
===
match
---
comparison [79540,79620]
comparison [80043,80123]
===
match
---
name: executable_tis [45371,45385]
name: executable_tis [45874,45888]
===
match
---
atom [44964,45009]
atom [45467,45512]
===
match
---
try_stmt [6950,8540]
try_stmt [6950,8540]
===
match
---
name: self [12602,12606]
name: self [12602,12606]
===
match
---
name: run_type [80740,80748]
name: run_type [81243,81251]
===
match
---
param [23856,23884]
param [23856,23884]
===
match
---
name: datetime [17912,17920]
name: datetime [17912,17920]
===
match
---
raise_stmt [11773,11838]
raise_stmt [11773,11838]
===
match
---
return_stmt [66608,66616]
return_stmt [67111,67119]
===
match
---
atom_expr [67097,67135]
atom_expr [67600,67638]
===
match
---
arglist [23380,23407]
arglist [23380,23407]
===
match
---
simple_stmt [1532,1569]
simple_stmt [1532,1569]
===
match
---
name: USE_JOB_SCHEDULE [62901,62917]
name: USE_JOB_SCHEDULE [63404,63420]
===
match
---
funcdef [50601,53483]
funcdef [51104,53986]
===
match
---
suite [68555,68633]
suite [69058,69136]
===
match
---
name: dag_id [35277,35283]
name: dag_id [35780,35786]
===
match
---
name: task_instance [44400,44413]
name: task_instance [44903,44916]
===
match
---
atom_expr [17376,17386]
atom_expr [17376,17386]
===
match
---
trailer [30904,30921]
trailer [31158,31175]
===
match
---
atom_expr [59566,59624]
atom_expr [60069,60127]
===
match
---
name: email_sent [21230,21240]
name: email_sent [21230,21240]
===
match
---
comparison [27428,27456]
comparison [27428,27456]
===
match
---
trailer [20668,20734]
trailer [20668,20734]
===
match
---
trailer [34993,35002]
trailer [35496,35505]
===
match
---
trailer [52489,52493]
trailer [52992,52996]
===
match
---
operator: = [4178,4179]
operator: = [4178,4179]
===
match
---
trailer [10905,10914]
trailer [10905,10914]
===
match
---
name: os [31388,31390]
name: os [31765,31767]
===
match
---
trailer [38611,38640]
trailer [39114,39143]
===
match
---
arith_expr [41738,41789]
arith_expr [42241,42292]
===
match
---
simple_stmt [19868,19901]
simple_stmt [19868,19901]
===
match
---
name: fileloc [77767,77774]
name: fileloc [78270,78277]
===
match
---
name: _parent_channel [9740,9755]
name: _parent_channel [9740,9755]
===
match
---
for_stmt [22201,22404]
for_stmt [22201,22404]
===
match
---
name: timers [57645,57651]
name: timers [58148,58154]
===
match
---
arglist [59581,59622]
arglist [60084,60125]
===
match
---
atom_expr [73932,73947]
atom_expr [74435,74450]
===
match
---
import_as_names [2396,2450]
import_as_names [2396,2450]
===
match
---
import_as_names [2483,2517]
import_as_names [2483,2517]
===
match
---
trailer [58700,58702]
trailer [59203,59205]
===
match
---
name: log [2594,2597]
name: log [2594,2597]
===
match
---
name: dag_id [73616,73622]
name: dag_id [74119,74125]
===
match
---
number: 0 [27059,27060]
number: 0 [27059,27060]
===
match
---
trailer [38674,38687]
trailer [39177,39190]
===
match
---
operator: , [49938,49939]
operator: , [50441,50442]
===
match
---
name: session [15432,15439]
name: session [15432,15439]
===
match
---
name: TI [34243,34245]
name: TI [34746,34748]
===
match
---
atom [64273,64288]
atom [64776,64791]
===
match
---
atom_expr [17486,17514]
atom_expr [17486,17514]
===
match
---
param [11197,11201]
param [11197,11201]
===
match
---
atom_expr [53394,53448]
atom_expr [53897,53951]
===
match
---
operator: = [45340,45341]
operator: = [45843,45844]
===
match
---
try_stmt [19126,19438]
try_stmt [19126,19438]
===
match
---
trailer [38916,38925]
trailer [39419,39428]
===
match
---
name: self [35601,35605]
name: self [36104,36108]
===
match
---
trailer [74868,74884]
trailer [75371,75387]
===
match
---
operator: = [72419,72420]
operator: = [72922,72923]
===
match
---
trailer [9374,9380]
trailer [9374,9380]
===
match
---
trailer [26711,26716]
trailer [26711,26716]
===
match
---
name: filter [33573,33579]
name: filter [34076,34082]
===
match
---
name: int [36043,36046]
name: int [36546,36549]
===
match
---
simple_stmt [12476,12519]
simple_stmt [12476,12519]
===
match
---
simple_stmt [18331,18366]
simple_stmt [18331,18366]
===
match
---
fstring [78202,78235]
fstring [78705,78738]
===
match
---
atom_expr [71025,71382]
atom_expr [71528,71885]
===
match
---
trailer [38077,38083]
trailer [38580,38586]
===
match
---
trailer [40038,40048]
trailer [40541,40551]
===
match
---
decorated [21363,22429]
decorated [21363,22429]
===
match
---
name: is_unit_test [57246,57258]
name: is_unit_test [57749,57761]
===
match
---
suite [75055,75345]
suite [75558,75848]
===
match
---
atom_expr [65469,65490]
atom_expr [65972,65993]
===
match
---
string: """Find Dag Models needing DagRuns and Create Dag Runs with retries in case of OperationalError""" [66982,67080]
string: """Find Dag Models needing DagRuns and Create Dag Runs with retries in case of OperationalError""" [67485,67583]
===
match
---
operator: , [7986,7987]
operator: , [7986,7987]
===
match
---
operator: = [52462,52463]
operator: = [52965,52966]
===
match
---
sync_comp_for [38734,38793]
sync_comp_for [39237,39296]
===
match
---
name: DagModel [1836,1844]
name: DagModel [1836,1844]
===
match
---
operator: , [47378,47379]
operator: , [47881,47882]
===
match
---
operator: >= [74946,74948]
operator: >= [75449,75451]
===
match
---
name: dm [68011,68013]
name: dm [68514,68516]
===
match
---
trailer [77019,77027]
trailer [77522,77530]
===
match
---
trailer [55634,55636]
trailer [56137,56139]
===
match
---
name: next_dagrun_info [72425,72441]
name: next_dagrun_info [72928,72944]
===
match
---
name: dm [68300,68302]
name: dm [68803,68805]
===
match
---
arith_expr [81675,81717]
arith_expr [82178,82220]
===
match
---
number: 5.0 [57748,57751]
number: 5.0 [58251,58254]
===
match
---
sync_comp_for [71136,71155]
sync_comp_for [71639,71658]
===
match
---
operator: = [39760,39761]
operator: = [40263,40264]
===
match
---
name: func [1315,1319]
name: func [1315,1319]
===
match
---
string: "Error logging import errors!" [27748,27778]
string: "Error logging import errors!" [27748,27778]
===
match
---
trailer [53991,54004]
trailer [54494,54507]
===
match
---
operator: , [80997,80998]
operator: , [81500,81501]
===
match
---
name: getfloat [57857,57865]
name: getfloat [58360,58368]
===
match
---
name: session [73553,73560]
name: session [74056,74063]
===
match
---
name: queue [47297,47302]
name: queue [47800,47805]
===
match
---
name: flush [73940,73945]
name: flush [74443,74448]
===
match
---
string: "Run %s of %s has timed-out" [73974,74002]
string: "Run %s of %s has timed-out" [74477,74505]
===
match
---
suite [19339,19438]
suite [19339,19438]
===
match
---
name: set_state [53361,53370]
name: set_state [53864,53873]
===
match
---
raise_stmt [76945,76996]
raise_stmt [77448,77499]
===
match
---
operator: , [77418,77419]
operator: , [77921,77922]
===
match
---
name: len [81841,81844]
name: len [82344,82347]
===
match
---
decorated [78422,82655]
decorated [78925,83158]
===
match
---
name: execution_date [74376,74390]
name: execution_date [74879,74893]
===
match
---
trailer [37973,38022]
trailer [38476,38525]
===
match
---
trailer [80703,80932]
trailer [81206,81435]
===
match
---
name: add [64475,64478]
name: add [64978,64981]
===
match
---
number: 0 [45515,45516]
number: 0 [46018,46019]
===
match
---
operator: != [18075,18077]
operator: != [18075,18077]
===
match
---
trailer [31243,31298]
trailer [31620,31675]
===
match
---
string: "Executor reports task instance %s finished (%s) although the " [52763,52826]
string: "Executor reports task instance %s finished (%s) although the " [53266,53329]
===
match
---
name: sys [31379,31382]
name: sys [31756,31759]
===
match
---
atom_expr [36780,36796]
atom_expr [37283,37299]
===
match
---
return_stmt [32343,32401]
return_stmt [32846,32904]
===
match
---
name: query [71033,71038]
name: query [71536,71541]
===
match
---
name: log [71748,71751]
name: log [72251,72254]
===
match
---
name: ti [45993,45995]
name: ti [46496,46498]
===
match
---
name: State [78147,78152]
name: State [78650,78655]
===
match
---
trailer [65476,65488]
trailer [65979,65991]
===
match
---
trailer [19154,19172]
trailer [19154,19172]
===
match
---
string: """Sends SLA Callbacks to DagFileProcessor if tasks have SLAs set and check_slas=True""" [77237,77325]
string: """Sends SLA Callbacks to DagFileProcessor if tasks have SLAs set and check_slas=True""" [77740,77828]
===
match
---
name: DagRun [76835,76841]
name: DagRun [77338,77344]
===
match
---
atom_expr [66503,66548]
atom_expr [67006,67051]
===
match
---
argument [49940,49955]
argument [50443,50458]
===
match
---
trailer [21216,21227]
trailer [21216,21227]
===
match
---
name: load_only [1410,1419]
name: load_only [1410,1419]
===
match
---
name: Signals [31519,31526]
name: Signals [32022,32029]
===
match
---
operator: == [17726,17728]
operator: == [17726,17728]
===
match
---
trailer [30525,30543]
trailer [30779,30797]
===
match
---
trailer [38769,38771]
trailer [39272,39274]
===
match
---
name: Tuple [36756,36761]
name: Tuple [37259,37264]
===
match
---
name: timezone [34567,34575]
name: timezone [35070,35078]
===
match
---
arglist [25002,25043]
arglist [25002,25043]
===
match
---
string: "Could not call sla_miss_callback for DAG %s" [19379,19424]
string: "Could not call sla_miss_callback for DAG %s" [19379,19424]
===
match
---
tfpdef [22492,22506]
tfpdef [22492,22506]
===
match
---
name: self [54844,54848]
name: self [55347,55351]
===
match
---
name: merge [21318,21323]
name: merge [21318,21323]
===
match
---
simple_stmt [74844,74853]
simple_stmt [75347,75356]
===
match
---
name: priority_sorted_task_instances [41203,41233]
name: priority_sorted_task_instances [41706,41736]
===
match
---
atom_expr [64335,64344]
atom_expr [64838,64847]
===
match
---
atom_expr [47043,47051]
atom_expr [47546,47554]
===
match
---
operator: += [45011,45013]
operator: += [45514,45516]
===
match
---
arglist [12584,12615]
arglist [12584,12615]
===
match
---
del_stmt [6811,6829]
del_stmt [6811,6829]
===
match
---
annassign [49902,49962]
annassign [50405,50465]
===
match
---
param [3939,3957]
param [3939,3957]
===
match
---
name: get_task [43421,43429]
name: get_task [43924,43932]
===
match
---
trailer [81346,81355]
trailer [81849,81858]
===
match
---
name: skip_locked [39070,39081]
name: skip_locked [39573,39584]
===
match
---
name: State [80614,80619]
name: State [81117,81122]
===
match
---
operator: , [74300,74301]
operator: , [74803,74804]
===
match
---
string: "Calling SchedulerJob.adopt_or_reset_orphaned_tasks method" [79245,79304]
string: "Calling SchedulerJob.adopt_or_reset_orphaned_tasks method" [79748,79807]
===
match
---
trailer [4200,4219]
trailer [4200,4219]
===
match
---
expr_stmt [23954,24034]
expr_stmt [23954,24034]
===
match
---
trailer [24534,24566]
trailer [24534,24566]
===
match
---
operator: -> [13732,13734]
operator: -> [13732,13734]
===
match
---
name: paused_dag_ids [27255,27269]
name: paused_dag_ids [27255,27269]
===
match
---
atom_expr [45857,45871]
atom_expr [46360,46374]
===
match
---
trailer [80696,80703]
trailer [81199,81206]
===
match
---
atom_expr [81923,81949]
atom_expr [82426,82452]
===
match
---
trailer [26388,26392]
trailer [26388,26392]
===
match
---
name: old_states [33689,33699]
name: old_states [34192,34202]
===
match
---
simple_stmt [57413,57450]
simple_stmt [57916,57953]
===
match
---
atom_expr [51298,51315]
atom_expr [51801,51818]
===
match
---
trailer [36761,36771]
trailer [37264,37274]
===
match
---
expr_stmt [51247,51315]
expr_stmt [51750,51818]
===
match
---
operator: , [47140,47141]
operator: , [47643,47644]
===
match
---
trailer [11161,11167]
trailer [11161,11167]
===
match
---
name: task [16771,16775]
name: task [16771,16775]
===
match
---
simple_stmt [79969,80036]
simple_stmt [80472,80539]
===
match
---
name: ti [41313,41315]
name: ti [41816,41818]
===
match
---
name: log [51334,51337]
name: log [51837,51840]
===
match
---
trailer [53154,53158]
trailer [53657,53661]
===
match
---
trailer [59659,59668]
trailer [60162,60171]
===
match
---
name: int [30545,30548]
name: int [30799,30802]
===
match
---
name: int [29508,29511]
name: int [29762,29765]
===
match
---
name: dag_id [49702,49708]
name: dag_id [50205,50211]
===
match
---
name: dag [15996,15999]
name: dag [15996,15999]
===
match
---
try_stmt [27599,27780]
try_stmt [27599,27780]
===
match
---
operator: , [8115,8116]
operator: , [8115,8116]
===
match
---
name: self [58745,58749]
name: self [59248,59252]
===
match
---
name: dag_id [73136,73142]
name: dag_id [73639,73645]
===
match
---
operator: = [43239,43240]
operator: = [43742,43743]
===
match
---
atom_expr [10930,10947]
atom_expr [10930,10947]
===
match
---
trailer [15827,15834]
trailer [15827,15834]
===
match
---
trailer [60945,60954]
trailer [61448,61457]
===
match
---
trailer [79438,79445]
trailer [79941,79948]
===
match
---
trailer [50352,50361]
trailer [50855,50864]
===
match
---
name: email [20521,20526]
name: email [20521,20526]
===
match
---
string: 'mysql' [30503,30510]
string: 'mysql' [30757,30764]
===
match
---
name: name [31535,31539]
name: name [32038,32042]
===
match
---
argument [39020,39025]
argument [39523,39528]
===
match
---
name: with_row_locks [49915,49929]
name: with_row_locks [50418,50432]
===
match
---
testlist_comp [8948,9191]
testlist_comp [8948,9191]
===
match
---
fstring_string: -Process [9261,9269]
fstring_string: -Process [9261,9269]
===
match
---
number: 0 [26771,26772]
number: 0 [26771,26772]
===
match
---
name: list [39774,39778]
name: list [40277,40281]
===
match
---
import_from [1903,1943]
import_from [1903,1943]
===
match
---
name: DagFileProcessorProcess [3151,3174]
name: DagFileProcessorProcess [3151,3174]
===
match
---
argument [37981,38020]
argument [38484,38523]
===
match
---
annassign [36683,36725]
annassign [37186,37228]
===
match
---
operator: , [37975,37976]
operator: , [38478,38479]
===
match
---
operator: , [42408,42409]
operator: , [42911,42912]
===
match
---
trailer [76591,76595]
trailer [77094,77098]
===
match
---
operator: , [36482,36483]
operator: , [36985,36986]
===
match
---
expr_stmt [53649,53731]
expr_stmt [54152,54234]
===
match
---
dotted_name [1388,1402]
dotted_name [1388,1402]
===
match
---
name: State [52641,52646]
name: State [53144,53149]
===
match
---
operator: = [15368,15369]
operator: = [15368,15369]
===
match
---
trailer [29444,29451]
trailer [29698,29705]
===
match
---
suite [51718,51771]
suite [52221,52274]
===
match
---
operator: == [35267,35269]
operator: == [35770,35772]
===
match
---
name: queued_by_job_id [80564,80580]
name: queued_by_job_id [81067,81083]
===
match
---
name: state [52978,52983]
name: state [53481,53486]
===
match
---
operator: , [42363,42364]
operator: , [42866,42867]
===
match
---
operator: = [76759,76760]
operator: = [77262,77263]
===
match
---
trailer [42564,42568]
trailer [43067,43071]
===
match
---
name: Stats [45250,45255]
name: Stats [45753,45758]
===
match
---
operator: = [4104,4105]
operator: = [4104,4105]
===
match
---
number: 0 [35072,35073]
number: 0 [35575,35576]
===
match
---
name: event_buffer [51870,51882]
name: event_buffer [52373,52385]
===
match
---
operator: = [18339,18340]
operator: = [18339,18340]
===
match
---
operator: , [7067,7068]
operator: , [7067,7068]
===
match
---
name: execution_date [73651,73665]
name: execution_date [74154,74168]
===
match
---
operator: = [16033,16034]
operator: = [16033,16034]
===
match
---
name: external_executor_id [52441,52461]
name: external_executor_id [52944,52964]
===
match
---
expr_stmt [82025,82075]
expr_stmt [82528,82578]
===
match
---
string: "Next timed event is in %f" [59088,59115]
string: "Next timed event is in %f" [59591,59618]
===
match
---
trailer [31675,31679]
trailer [32178,32182]
===
match
---
name: dag_id [44979,44985]
name: dag_id [45482,45488]
===
match
---
trailer [45848,45855]
trailer [46351,46358]
===
match
---
trailer [58658,58660]
trailer [59161,59163]
===
match
---
operator: -> [11203,11205]
operator: -> [11203,11205]
===
match
---
arglist [30226,30241]
arglist [30480,30495]
===
match
---
name: RUNNING [78254,78261]
name: RUNNING [78757,78764]
===
match
---
operator: = [42203,42204]
operator: = [42706,42707]
===
match
---
atom_expr [60410,60563]
atom_expr [60913,61066]
===
match
---
name: type [16992,16996]
name: type [16992,16996]
===
match
---
name: dag [72230,72233]
name: dag [72733,72736]
===
match
---
expr_stmt [62994,63047]
expr_stmt [63497,63550]
===
match
---
trailer [33606,33610]
trailer [34109,34113]
===
match
---
atom_expr [78987,79213]
atom_expr [79490,79716]
===
match
---
operator: , [57289,57290]
operator: , [57792,57793]
===
match
---
fstring_start: f' [45041,45043]
fstring_start: f' [45544,45546]
===
match
---
subscriptlist [25356,25364]
subscriptlist [25356,25364]
===
match
---
trailer [71045,71052]
trailer [71548,71555]
===
match
---
simple_stmt [30931,30984]
simple_stmt [31185,31238]
===
match
---
operator: = [69831,69832]
operator: = [70334,70335]
===
match
---
name: is_alive [32358,32366]
name: is_alive [32861,32869]
===
match
---
comp_op [43571,43577]
comp_op [44074,44080]
===
match
---
atom_expr [57327,57343]
atom_expr [57830,57846]
===
match
---
name: self [11141,11145]
name: self [11141,11145]
===
match
---
atom_expr [75072,75319]
atom_expr [75575,75822]
===
match
---
param [61163,61168]
param [61666,61671]
===
match
---
name: dag_hash [69905,69913]
name: dag_hash [70408,70416]
===
match
---
import_from [2819,2884]
import_from [2819,2884]
===
match
---
name: TI [49646,49648]
name: TI [50149,50151]
===
match
---
name: dagbag [22012,22018]
name: dagbag [22012,22018]
===
match
---
atom_expr [78742,78803]
atom_expr [79245,79306]
===
match
---
expr_stmt [71863,71922]
expr_stmt [72366,72425]
===
match
---
atom_expr [4336,4371]
atom_expr [4336,4371]
===
match
---
trailer [10700,10702]
trailer [10700,10702]
===
match
---
name: frame [31433,31438]
name: frame [31810,31815]
===
match
---
name: msg [74450,74453]
name: msg [74953,74956]
===
match
---
trailer [23027,23071]
trailer [23027,23071]
===
match
---
trailer [79581,79588]
trailer [80084,80091]
===
match
---
name: settings [77341,77349]
name: settings [77844,77852]
===
match
---
testlist_star_expr [72361,72418]
testlist_star_expr [72864,72921]
===
match
---
trailer [61061,61063]
trailer [61564,61566]
===
match
---
trailer [48597,48615]
trailer [49100,49118]
===
match
---
simple_stmt [906,920]
simple_stmt [906,920]
===
match
---
trailer [16354,16363]
trailer [16354,16363]
===
match
---
string: """Creates DagFileProcessorProcess instance.""" [56271,56318]
string: """Creates DagFileProcessorProcess instance.""" [56774,56821]
===
match
---
subscriptlist [39736,39758]
subscriptlist [40239,40261]
===
match
---
trailer [63038,63047]
trailer [63541,63550]
===
match
---
name: session [49812,49819]
name: session [50315,50322]
===
match
---
param [3901,3906]
param [3901,3906]
===
match
---
name: ti [53073,53075]
name: ti [53576,53578]
===
match
---
atom_expr [51735,51770]
atom_expr [52238,52273]
===
match
---
trailer [71911,71918]
trailer [72414,72421]
===
match
---
name: _execute_task_callbacks [23175,23198]
name: _execute_task_callbacks [23175,23198]
===
match
---
trailer [8489,8501]
trailer [8489,8501]
===
match
---
name: task_instance [41413,41426]
name: task_instance [41916,41929]
===
match
---
name: repr [39538,39542]
name: repr [40041,40045]
===
match
---
trailer [53745,53749]
trailer [54248,54252]
===
match
---
operator: = [38971,38972]
operator: = [39474,39475]
===
match
---
trailer [23580,23754]
trailer [23580,23754]
===
match
---
name: List [34238,34242]
name: List [34741,34745]
===
match
---
operator: } [35095,35096]
operator: } [35598,35599]
===
match
---
expr_stmt [36934,36969]
expr_stmt [37437,37472]
===
match
---
operator: = [17616,17617]
operator: = [17616,17617]
===
match
---
trailer [26937,26984]
trailer [26937,26984]
===
match
---
name: dag_id [21049,21055]
name: dag_id [21049,21055]
===
match
---
simple_stmt [45180,45242]
simple_stmt [45683,45745]
===
match
---
name: session [69859,69866]
name: session [70362,70369]
===
match
---
for_stmt [52104,53449]
for_stmt [52607,53952]
===
match
---
expr_stmt [18626,18762]
expr_stmt [18626,18762]
===
match
---
expr_stmt [23912,23945]
expr_stmt [23912,23945]
===
match
---
number: 1 [49591,49592]
number: 1 [50094,50095]
===
match
---
expr_stmt [17596,17777]
expr_stmt [17596,17777]
===
match
---
name: List [56141,56145]
name: List [56644,56648]
===
match
---
annassign [30543,30596]
annassign [30797,30850]
===
match
---
name: dag_id [36944,36950]
name: dag_id [37447,37453]
===
match
---
name: session [62857,62864]
name: session [63360,63367]
===
match
---
name: exception [55922,55931]
name: exception [56425,56434]
===
match
---
name: queued_tis [48824,48834]
name: queued_tis [49327,49337]
===
match
---
comparison [10789,10810]
comparison [10789,10810]
===
match
---
simple_stmt [47035,47052]
simple_stmt [47538,47555]
===
match
---
name: TI [16536,16538]
name: TI [16536,16538]
===
match
---
name: log [6851,6854]
name: log [6851,6854]
===
match
---
atom [68298,68348]
atom [68801,68851]
===
match
---
trailer [81380,81403]
trailer [81883,81906]
===
match
---
name: State [79497,79502]
name: State [80000,80005]
===
match
---
atom_expr [51950,51989]
atom_expr [52453,52492]
===
match
---
name: query [68411,68416]
name: query [68914,68919]
===
match
---
name: session [73932,73939]
name: session [74435,74442]
===
match
---
name: execution_date [16087,16101]
name: execution_date [16087,16101]
===
match
---
not_test [53983,54004]
not_test [54486,54507]
===
match
---
parameters [47373,47397]
parameters [47876,47900]
===
match
---
simple_stmt [24970,25045]
simple_stmt [24970,25045]
===
match
---
name: self [42560,42564]
name: self [43063,43067]
===
match
---
operator: { [34614,34615]
operator: { [35117,35118]
===
match
---
name: dag [16225,16228]
name: dag [16225,16228]
===
match
---
name: fallback [57739,57747]
name: fallback [58242,58250]
===
match
---
name: include_examples [26503,26519]
name: include_examples [26503,26519]
===
match
---
name: self [55135,55139]
name: self [55638,55642]
===
match
---
name: count [58023,58028]
name: count [58526,58531]
===
match
---
trailer [24550,24565]
trailer [24550,24565]
===
match
---
trailer [68484,68488]
trailer [68987,68991]
===
match
---
atom_expr [39640,39670]
atom_expr [40143,40173]
===
match
---
atom_expr [49749,49782]
atom_expr [50252,50285]
===
match
---
fstring_expr [78122,78133]
fstring_expr [78625,78636]
===
match
---
atom_expr [48820,48835]
atom_expr [49323,49338]
===
match
---
name: TI [50195,50197]
name: TI [50698,50700]
===
match
---
name: in_ [38867,38870]
name: in_ [39370,39373]
===
match
---
trailer [38966,38970]
trailer [39469,39473]
===
match
---
name: query [36519,36524]
name: query [37022,37027]
===
match
---
name: FAILED [51681,51687]
name: FAILED [52184,52190]
===
match
---
trailer [16065,16073]
trailer [16065,16073]
===
match
---
name: TI [36537,36539]
name: TI [37040,37042]
===
match
---
name: conf [57501,57505]
name: conf [58004,58008]
===
match
---
trailer [49825,49829]
trailer [50328,50332]
===
match
---
name: AirflowException [11779,11795]
name: AirflowException [11779,11795]
===
match
---
operator: -> [47398,47400]
operator: -> [47901,47903]
===
match
---
trailer [71196,71204]
trailer [71699,71707]
===
match
---
and_test [73310,73439]
and_test [73813,73942]
===
match
---
string: "Processing file %s for tasks to queue" [26398,26437]
string: "Processing file %s for tasks to queue" [26398,26437]
===
match
---
suite [46167,47324]
suite [46670,47827]
===
match
---
string: "Setting external_id for %s to %s" [52499,52533]
string: "Setting external_id for %s to %s" [53002,53036]
===
match
---
operator: , [36035,36036]
operator: , [36538,36539]
===
match
---
trailer [17161,17163]
trailer [17161,17163]
===
match
---
name: suppress [1053,1061]
name: suppress [1053,1061]
===
match
---
name: pickle_dags [7918,7929]
name: pickle_dags [7918,7929]
===
match
---
name: pickle_dags [27230,27241]
name: pickle_dags [27230,27241]
===
match
---
name: log [66422,66425]
name: log [66925,66928]
===
match
---
simple_stmt [82100,82315]
simple_stmt [82603,82818]
===
match
---
name: dags [24383,24387]
name: dags [24383,24387]
===
match
---
trailer [27416,27422]
trailer [27416,27422]
===
match
---
operator: = [27362,27363]
operator: = [27362,27363]
===
match
---
atom_expr [32540,32550]
atom_expr [33043,33053]
===
match
---
atom_expr [54739,54756]
atom_expr [55242,55259]
===
match
---
name: email_sent [20755,20765]
name: email_sent [20755,20765]
===
match
---
atom_expr [12414,12441]
atom_expr [12414,12441]
===
match
---
operator: , [60668,60669]
operator: , [61171,61172]
===
match
---
operator: = [73151,73152]
operator: = [73654,73655]
===
match
---
atom_expr [73608,73622]
atom_expr [74111,74125]
===
match
---
operator: , [45890,45891]
operator: , [46393,46394]
===
match
---
operator: = [65803,65804]
operator: = [66306,66307]
===
match
---
simple_stmt [76727,76769]
simple_stmt [77230,77272]
===
match
---
simple_stmt [18521,18614]
simple_stmt [18521,18614]
===
match
---
operator: = [31510,31511]
operator: = [32013,32014]
===
match
---
name: StreamLogWriter [7032,7047]
name: StreamLogWriter [7032,7047]
===
match
---
operator: = [74453,74454]
operator: = [74956,74957]
===
match
---
expr_stmt [6491,6551]
expr_stmt [6491,6551]
===
match
---
operator: , [72168,72169]
operator: , [72671,72672]
===
match
---
expr_stmt [58568,58613]
expr_stmt [59071,59116]
===
match
---
name: setproctitle [6875,6887]
name: setproctitle [6875,6887]
===
match
---
trailer [33714,33721]
trailer [34217,34224]
===
match
---
name: ValueError [50766,50776]
name: ValueError [51269,51279]
===
match
---
name: dag [69576,69579]
name: dag [70079,70082]
===
match
---
string: "airflow.processor" [6531,6550]
string: "airflow.processor" [6531,6550]
===
match
---
fstring_expr [17025,17039]
fstring_expr [17025,17039]
===
match
---
name: bool [25294,25298]
name: bool [25294,25298]
===
match
---
operator: > [59669,59670]
operator: > [60172,60173]
===
match
---
name: pool_slots [44867,44877]
name: pool_slots [45370,45380]
===
match
---
name: dag_id [18144,18150]
name: dag_id [18144,18150]
===
match
---
except_clause [23496,23512]
except_clause [23496,23512]
===
match
---
argument [73144,73159]
argument [73647,73662]
===
match
---
name: self [41529,41533]
name: self [42032,42036]
===
match
---
arglist [36525,36563]
arglist [37028,37066]
===
match
---
name: super [4061,4066]
name: super [4061,4066]
===
match
---
simple_stmt [47414,48461]
simple_stmt [47917,48964]
===
match
---
name: State [60485,60490]
name: State [60988,60993]
===
match
---
simple_stmt [37194,37489]
simple_stmt [37697,37992]
===
match
---
name: List [15258,15262]
name: List [15258,15262]
===
match
---
trailer [67105,67126]
trailer [67608,67629]
===
match
---
name: models [3108,3114]
name: models [3108,3114]
===
match
---
string: """Kill the process launched to process the file, and ensure consistent state.""" [9811,9892]
string: """Kill the process launched to process the file, and ensure consistent state.""" [9811,9892]
===
match
---
trailer [20023,20027]
trailer [20023,20027]
===
match
---
trailer [20466,20478]
trailer [20466,20478]
===
match
---
name: ti [24824,24826]
name: ti [24824,24826]
===
match
---
name: session [71668,71675]
name: session [72171,72178]
===
match
---
not_test [51821,51845]
not_test [52324,52348]
===
match
---
name: str [36032,36035]
name: str [36535,36538]
===
match
---
name: session [62972,62979]
name: session [63475,63482]
===
match
---
tfpdef [47380,47396]
tfpdef [47883,47899]
===
match
---
atom_expr [24345,24356]
atom_expr [24345,24356]
===
match
---
name: logger [78927,78933]
name: logger [79430,79436]
===
match
---
trailer [16793,16801]
trailer [16793,16801]
===
match
---
operator: , [69752,69753]
operator: , [70255,70256]
===
match
---
fstring_string: dagrun.schedule_delay. [70234,70256]
fstring_string: dagrun.schedule_delay. [70737,70759]
===
match
---
for_stmt [81468,81644]
for_stmt [81971,82147]
===
match
---
atom_expr [52063,52088]
atom_expr [52566,52591]
===
match
---
name: List [17907,17911]
name: List [17907,17911]
===
match
---
param [37134,37147]
param [37637,37650]
===
match
---
name: int [7805,7808]
name: int [7805,7808]
===
match
---
parameters [32755,32839]
parameters [33258,33342]
===
match
---
parameters [66950,66972]
parameters [67453,67475]
===
match
---
name: TaskCallbackRequest [24243,24262]
name: TaskCallbackRequest [24243,24262]
===
match
---
operator: = [8880,8881]
operator: = [8880,8881]
===
match
---
name: query [79394,79399]
name: query [79897,79902]
===
match
---
trailer [70020,70039]
trailer [70523,70542]
===
match
---
trailer [73640,73647]
trailer [74143,74150]
===
match
---
name: bool [12030,12034]
name: bool [12030,12034]
===
match
---
name: max_tis [48513,48520]
name: max_tis [49016,49023]
===
match
---
atom_expr [71127,71135]
atom_expr [71630,71638]
===
match
---
name: self [40732,40736]
name: self [41235,41239]
===
match
---
name: task_id [16597,16604]
name: task_id [16597,16604]
===
match
---
name: sla_miss_callback [19155,19172]
name: sla_miss_callback [19155,19172]
===
match
---
atom_expr [81675,81701]
atom_expr [82178,82204]
===
match
---
operator: , [49733,49734]
operator: , [50236,50237]
===
match
---
name: models [1817,1823]
name: models [1817,1823]
===
match
---
trailer [47199,47323]
trailer [47702,47826]
===
match
---
operator: = [7968,7969]
operator: = [7968,7969]
===
match
---
trailer [52631,52637]
trailer [53134,53140]
===
match
---
name: state [53205,53210]
name: state [53708,53713]
===
match
---
atom_expr [76727,76768]
atom_expr [77230,77271]
===
match
---
trailer [77992,77998]
trailer [78495,78501]
===
match
---
trailer [43429,43506]
trailer [43932,44009]
===
match
---
trailer [31234,31238]
trailer [31611,31615]
===
match
---
name: local [46626,46631]
name: local [47129,47134]
===
match
---
simple_stmt [31798,31822]
simple_stmt [32301,32325]
===
match
---
name: State [60670,60675]
name: State [61173,61178]
===
match
---
simple_stmt [43381,43524]
simple_stmt [43884,44027]
===
match
---
name: heartrate [29270,29279]
name: heartrate [29524,29533]
===
match
---
trailer [27314,27322]
trailer [27314,27322]
===
match
---
tfpdef [48914,48930]
tfpdef [49417,49433]
===
match
---
decorator [37066,37083]
decorator [37569,37586]
===
match
---
name: settings [29394,29402]
name: settings [29648,29656]
===
match
---
name: subq [35336,35340]
name: subq [35839,35843]
===
match
---
name: self [54284,54288]
name: self [54787,54791]
===
match
---
name: provide_session [37067,37082]
name: provide_session [37570,37585]
===
match
---
parameters [72529,72656]
parameters [73032,73159]
===
match
---
number: 0 [40296,40297]
number: 0 [40799,40800]
===
match
---
fstring_start: f' [70232,70234]
fstring_start: f' [70735,70737]
===
match
---
name: TaskInstance [33494,33506]
name: TaskInstance [33997,34009]
===
match
---
name: dialect [67859,67866]
name: dialect [68362,68369]
===
match
---
if_stmt [59225,59625]
if_stmt [59728,60128]
===
match
---
name: slots_available [48537,48552]
name: slots_available [49040,49055]
===
match
---
trailer [18398,18405]
trailer [18398,18405]
===
match
---
operator: , [44024,44025]
operator: , [44527,44528]
===
match
---
trailer [17639,17645]
trailer [17639,17645]
===
match
---
subscriptlist [7800,7808]
subscriptlist [7800,7808]
===
match
---
trailer [70371,70392]
trailer [70874,70895]
===
match
---
name: dags [26871,26875]
name: dags [26871,26875]
===
match
---
funcdef [31045,31398]
funcdef [31299,31775]
===
match
---
trailer [73119,73127]
trailer [73622,73630]
===
match
---
atom_expr [6739,6770]
atom_expr [6739,6770]
===
match
---
atom_expr [18024,18174]
atom_expr [18024,18174]
===
match
---
name: TI [64069,64071]
name: TI [64572,64574]
===
match
---
atom_expr [49658,49670]
atom_expr [50161,50173]
===
match
---
trailer [80739,80748]
trailer [81242,81251]
===
match
---
name: using_mysql [30469,30480]
name: using_mysql [30723,30734]
===
match
---
name: ti_primary_key_to_try_number_map [51247,51279]
name: ti_primary_key_to_try_number_map [51750,51782]
===
match
---
name: self [9243,9247]
name: self [9243,9247]
===
match
---
name: str [20268,20271]
name: str [20268,20271]
===
match
---
import_from [960,995]
import_from [960,995]
===
match
---
name: executable_tis [46061,46075]
name: executable_tis [46564,46578]
===
match
---
testlist_comp [38724,38793]
testlist_comp [39227,39296]
===
match
---
arglist [43261,43284]
arglist [43764,43787]
===
match
---
atom_expr [27272,27323]
atom_expr [27272,27323]
===
match
---
trailer [79672,79679]
trailer [80175,80182]
===
match
---
trailer [24501,24509]
trailer [24501,24509]
===
match
---
simple_stmt [77038,77081]
simple_stmt [77541,77584]
===
match
---
operator: = [34290,34291]
operator: = [34793,34794]
===
match
---
operator: , [53794,53795]
operator: , [54297,54298]
===
match
---
name: models [55291,55297]
name: models [55794,55800]
===
match
---
name: latest_version [76534,76548]
name: latest_version [77037,77051]
===
match
---
string: " scheduler loops" [60118,60136]
string: " scheduler loops" [60621,60639]
===
match
---
trailer [50099,50124]
trailer [50602,50627]
===
match
---
simple_stmt [53649,53732]
simple_stmt [54152,54235]
===
match
---
trailer [41533,41537]
trailer [42036,42040]
===
match
---
name: self [74758,74762]
name: self [75261,75265]
===
match
---
name: bool [15167,15171]
name: bool [15167,15171]
===
match
---
expr_stmt [43381,43523]
expr_stmt [43884,44026]
===
match
---
name: __name__ [23684,23692]
name: __name__ [23684,23692]
===
match
---
name: ti [18467,18469]
name: ti [18467,18469]
===
match
---
name: settings [7282,7290]
name: settings [7282,7290]
===
match
---
name: ti [18730,18732]
name: ti [18730,18732]
===
match
---
expr_stmt [74217,74480]
expr_stmt [74720,74983]
===
match
---
atom_expr [73960,74035]
atom_expr [74463,74538]
===
match
---
operator: = [57747,57748]
operator: = [58250,58251]
===
match
---
argument [19709,19728]
argument [19709,19728]
===
match
---
name: dag_ids [5284,5291]
name: dag_ids [5284,5291]
===
match
---
trailer [81573,81579]
trailer [82076,82082]
===
match
---
name: task_id [45001,45008]
name: task_id [45504,45511]
===
match
---
name: State [60687,60692]
name: State [61190,61195]
===
match
---
name: self [13561,13565]
name: self [13561,13565]
===
match
---
atom_expr [13271,13300]
atom_expr [13271,13300]
===
match
---
trailer [34980,34993]
trailer [35483,35496]
===
match
---
name: Stats [58056,58061]
name: Stats [58559,58564]
===
match
---
decorated [14032,14343]
decorated [14032,14343]
===
match
---
name: is_failure_callback [24112,24131]
name: is_failure_callback [24112,24131]
===
match
---
name: dag [68572,68575]
name: dag [69075,69078]
===
match
---
trailer [67923,68181]
trailer [68426,68684]
===
match
---
trailer [15923,15927]
trailer [15923,15927]
===
match
---
name: request [24921,24928]
name: request [24921,24928]
===
match
---
name: timedelta [79593,79602]
name: timedelta [80096,80105]
===
match
---
simple_stmt [1693,1762]
simple_stmt [1693,1762]
===
match
---
suite [14388,14427]
suite [14388,14427]
===
match
---
arglist [40974,41175]
arglist [41477,41678]
===
match
---
arglist [75659,75683]
arglist [76162,76186]
===
match
---
name: self [43865,43869]
name: self [44368,44372]
===
match
---
operator: , [67345,67346]
operator: , [67848,67849]
===
match
---
atom_expr [33611,33636]
atom_expr [34114,34139]
===
match
---
name: ti [81617,81619]
name: ti [82120,82122]
===
match
---
simple_stmt [67414,67585]
simple_stmt [67917,68088]
===
match
---
atom_expr [13744,13759]
atom_expr [13744,13759]
===
match
---
trailer [35259,35266]
trailer [35762,35769]
===
match
---
trailer [18656,18762]
trailer [18656,18762]
===
match
---
trailer [59939,59955]
trailer [60442,60458]
===
match
---
name: context [8845,8852]
name: context [8845,8852]
===
match
---
trailer [21348,21355]
trailer [21348,21355]
===
match
---
string: 'orphaned_tasks_check_interval' [57528,57559]
string: 'orphaned_tasks_check_interval' [58031,58062]
===
match
---
trailer [35580,35586]
trailer [36083,36089]
===
match
---
name: errors [1855,1861]
name: errors [1855,1861]
===
match
---
trailer [17297,17299]
trailer [17297,17299]
===
match
---
suite [18310,18410]
suite [18310,18410]
===
match
---
name: value [51143,51148]
name: value [51646,51651]
===
match
---
name: filter_for_tis [50065,50079]
name: filter_for_tis [50568,50582]
===
match
---
param [56210,56228]
param [56713,56731]
===
match
---
name: self [54250,54254]
name: self [54753,54757]
===
match
---
import_from [1434,1492]
import_from [1434,1492]
===
match
---
name: is_failure_callback [74408,74427]
name: is_failure_callback [74911,74930]
===
match
---
operator: { [50194,50195]
operator: { [50697,50698]
===
match
---
comparison [45493,45516]
comparison [45996,46019]
===
match
---
param [32771,32793]
param [33274,33296]
===
match
---
suite [22258,22404]
suite [22258,22404]
===
match
---
atom_expr [74004,74018]
atom_expr [74507,74521]
===
match
---
trailer [46538,46545]
trailer [47041,47048]
===
match
---
file_input [825,82655]
file_input [825,83158]
===
match
---
trailer [45638,45644]
trailer [46141,46147]
===
match
---
fstring_string: : [17024,17025]
fstring_string: : [17024,17025]
===
match
---
atom_expr [27198,27217]
atom_expr [27198,27217]
===
match
---
name: info [53750,53754]
name: info [54253,54257]
===
match
---
name: dag_id [15828,15834]
name: dag_id [15828,15834]
===
match
---
trailer [29765,29774]
trailer [30019,30028]
===
match
---
name: filter [38447,38453]
name: filter [38950,38956]
===
match
---
atom [18226,18228]
atom [18226,18228]
===
match
---
name: self [26625,26629]
name: self [26625,26629]
===
match
---
name: DagModel [3134,3142]
name: DagModel [3134,3142]
===
match
---
trailer [24062,24178]
trailer [24062,24178]
===
match
---
comparison [52586,52624]
comparison [53089,53127]
===
match
---
atom_expr [52671,52718]
atom_expr [53174,53221]
===
match
---
name: state [18069,18074]
name: state [18069,18074]
===
match
---
operator: = [13146,13147]
operator: = [13146,13147]
===
match
---
name: retry_db_transaction [66897,66917]
name: retry_db_transaction [67400,67420]
===
match
---
name: dag_id [68246,68252]
name: dag_id [68749,68755]
===
match
---
simple_stmt [70120,70174]
simple_stmt [70623,70677]
===
match
---
simple_stmt [53970,54005]
simple_stmt [54473,54508]
===
match
---
trailer [79908,79917]
trailer [80411,80420]
===
match
---
operator: = [37724,37725]
operator: = [38227,38228]
===
match
---
operator: = [30424,30425]
operator: = [30678,30679]
===
match
---
name: file_path [4106,4115]
name: file_path [4106,4115]
===
match
---
name: self [51329,51333]
name: self [51832,51836]
===
match
---
atom_expr [26706,26748]
atom_expr [26706,26748]
===
match
---
trailer [44223,44227]
trailer [44726,44730]
===
match
---
atom_expr [36756,36771]
atom_expr [37259,37274]
===
match
---
operator: , [44413,44414]
operator: , [44916,44917]
===
match
---
trailer [75995,76008]
trailer [76498,76511]
===
match
---
name: dag_id [71912,71918]
name: dag_id [72415,72421]
===
match
---
trailer [16683,16687]
trailer [16683,16687]
===
match
---
operator: -> [72657,72659]
operator: -> [73160,73162]
===
match
---
name: dag_run [23954,23961]
name: dag_run [23954,23961]
===
match
---
operator: = [46705,46706]
operator: = [47208,47209]
===
match
---
name: callback_requests [56434,56451]
name: callback_requests [56937,56954]
===
match
---
simple_stmt [79787,79859]
simple_stmt [80290,80362]
===
match
---
trailer [38614,38620]
trailer [39117,39123]
===
match
---
atom_expr [78147,78159]
atom_expr [78650,78662]
===
match
---
name: super [32350,32355]
name: super [32853,32858]
===
match
---
param [37148,37171]
param [37651,37674]
===
match
---
atom_expr [45631,45979]
atom_expr [46134,46482]
===
match
---
expr_stmt [68812,68860]
expr_stmt [69315,69363]
===
match
---
name: session [60798,60805]
name: session [61301,61308]
===
match
---
atom_expr [21341,21357]
atom_expr [21341,21357]
===
match
---
atom_expr [38624,38639]
atom_expr [39127,39142]
===
match
---
trailer [67282,67284]
trailer [67785,67787]
===
match
---
suite [56523,60257]
suite [57026,60760]
===
match
---
arglist [59157,59210]
arglist [59660,59713]
===
match
---
trailer [8860,9281]
trailer [8860,9281]
===
match
---
name: session [63039,63046]
name: session [63542,63549]
===
match
---
suite [15906,16020]
suite [15906,16020]
===
match
---
simple_stmt [81571,81593]
simple_stmt [82074,82096]
===
match
---
name: task_instance [39871,39884]
name: task_instance [40374,40387]
===
match
---
operator: > [44185,44186]
operator: > [44688,44689]
===
match
---
name: x [45366,45367]
name: x [45869,45870]
===
match
---
atom_expr [20444,20478]
atom_expr [20444,20478]
===
match
---
name: self [13908,13912]
name: self [13908,13912]
===
match
---
trailer [31518,31526]
trailer [32021,32029]
===
match
---
operator: , [65311,65312]
operator: , [65814,65815]
===
match
---
trailer [13647,13649]
trailer [13647,13649]
===
match
---
name: items [27417,27422]
name: items [27417,27422]
===
match
---
name: timer [58062,58067]
name: timer [58565,58570]
===
match
---
tfpdef [5131,5172]
tfpdef [5131,5172]
===
match
---
name: Tuple [50859,50864]
name: Tuple [51362,51367]
===
match
---
dictorsetmaker [45833,45920]
dictorsetmaker [46336,46423]
===
match
---
name: os [903,905]
name: os [903,905]
===
match
---
name: next_dagrun [72473,72484]
name: next_dagrun [72976,72987]
===
match
---
simple_stmt [82503,82519]
simple_stmt [83006,83022]
===
match
---
name: debug [38078,38083]
name: debug [38581,38586]
===
match
---
name: session [24161,24168]
name: session [24161,24168]
===
match
---
operator: = [81179,81180]
operator: = [81682,81683]
===
match
---
name: SENSING [60718,60725]
name: SENSING [61221,61228]
===
match
---
trailer [19708,19745]
trailer [19708,19745]
===
match
---
name: guard [66957,66962]
name: guard [67460,67465]
===
match
---
atom_expr [73463,73494]
atom_expr [73966,73997]
===
match
---
return_stmt [66844,66890]
return_stmt [67347,67393]
===
match
---
simple_stmt [45568,45619]
simple_stmt [46071,46122]
===
match
---
name: log [75077,75080]
name: log [75580,75583]
===
match
---
name: self [11531,11535]
name: self [11531,11535]
===
match
---
simple_stmt [48746,48805]
simple_stmt [49249,49308]
===
match
---
name: models [1957,1963]
name: models [1957,1963]
===
match
---
name: tis_changed [35852,35863]
name: tis_changed [36355,36366]
===
match
---
name: commit [23772,23778]
name: commit [23772,23778]
===
match
---
expr_stmt [43224,43285]
expr_stmt [43727,43788]
===
match
---
simple_stmt [2727,2819]
simple_stmt [2727,2819]
===
match
---
funcdef [76774,77170]
funcdef [77277,77673]
===
match
---
simple_stmt [68372,68501]
simple_stmt [68875,69004]
===
match
---
trailer [41542,41619]
trailer [42045,42122]
===
match
---
operator: = [8654,8655]
operator: = [8654,8655]
===
match
---
name: num_finished_events [59276,59295]
name: num_finished_events [59779,59798]
===
match
---
name: dag_model [68598,68607]
name: dag_model [69101,69110]
===
match
---
name: dag_id [71818,71824]
name: dag_id [72321,72327]
===
match
---
name: duration [59202,59210]
name: duration [59705,59713]
===
match
---
simple_stmt [6739,6771]
simple_stmt [6739,6771]
===
match
---
operator: >= [59652,59654]
operator: >= [60155,60157]
===
match
---
atom_expr [20213,20242]
atom_expr [20213,20242]
===
match
---
atom_expr [55291,55343]
atom_expr [55794,55846]
===
match
---
trailer [8537,8539]
trailer [8537,8539]
===
match
---
name: UNPICKLEABLE_EXECUTORS [53709,53731]
name: UNPICKLEABLE_EXECUTORS [54212,54234]
===
match
---
atom_expr [50854,50899]
atom_expr [51357,51402]
===
match
---
param [12021,12025]
param [12021,12025]
===
match
---
name: _process [12607,12615]
name: _process [12607,12615]
===
match
---
tfpdef [56172,56200]
tfpdef [56675,56703]
===
match
---
name: file_path [26884,26893]
name: file_path [26884,26893]
===
match
---
expr_stmt [42181,42240]
expr_stmt [42684,42743]
===
match
---
string: 'Setting task instance %s state to %s as reported by executor' [53267,53329]
string: 'Setting task instance %s state to %s as reported by executor' [53770,53832]
===
match
---
operator: ** [34312,34314]
operator: ** [34815,34817]
===
match
---
trailer [53085,53093]
trailer [53588,53596]
===
match
---
name: staticmethod [21364,21376]
name: staticmethod [21364,21376]
===
match
---
arglist [53059,53218]
arglist [53562,53721]
===
match
---
name: dag_id [27390,27396]
name: dag_id [27390,27396]
===
match
---
operator: , [35283,35284]
operator: , [35786,35787]
===
match
---
operator: { [78223,78224]
operator: { [78726,78727]
===
match
---
operator: == [16640,16642]
operator: == [16640,16642]
===
match
---
atom [53190,53217]
atom [53693,53720]
===
match
---
simple_stmt [996,1062]
simple_stmt [996,1062]
===
match
---
argument [54236,54261]
argument [54739,54764]
===
match
---
name: log [6739,6742]
name: log [6739,6742]
===
match
---
expr_stmt [13498,13515]
expr_stmt [13498,13515]
===
match
---
name: emails [20256,20262]
name: emails [20256,20262]
===
match
---
name: signal [30871,30877]
name: signal [31125,31131]
===
match
---
param [56098,56113]
param [56601,56616]
===
match
---
name: State [79990,79995]
name: State [80493,80498]
===
match
---
name: sla [17934,17937]
name: sla [17934,17937]
===
match
---
name: in_ [36594,36597]
name: in_ [37097,37100]
===
match
---
name: UNPICKLEABLE_EXECUTORS [1739,1761]
name: UNPICKLEABLE_EXECUTORS [1739,1761]
===
match
---
operator: , [19424,19425]
operator: , [19424,19425]
===
match
---
atom_expr [57152,57172]
atom_expr [57655,57675]
===
match
---
atom_expr [23170,23215]
atom_expr [23170,23215]
===
match
---
name: TaskInstance [35181,35193]
name: TaskInstance [35684,35696]
===
match
---
name: executor [50933,50941]
name: executor [51436,51444]
===
match
---
name: dag_model [68756,68765]
name: dag_model [69259,69268]
===
match
---
annassign [38960,39115]
annassign [39463,39618]
===
match
---
name: _change_state_for_tasks_failed_to_execute [48866,48907]
name: _change_state_for_tasks_failed_to_execute [49369,49410]
===
match
---
operator: , [70583,70584]
operator: , [71086,71087]
===
match
---
atom_expr [80592,80610]
atom_expr [81095,81113]
===
match
---
name: timezone [22348,22356]
name: timezone [22348,22356]
===
match
---
atom_expr [23764,23780]
atom_expr [23764,23780]
===
match
---
simple_stmt [26625,26694]
simple_stmt [26625,26694]
===
match
---
dotted_name [2523,2552]
dotted_name [2523,2552]
===
match
---
name: ignore_depends_on_past [46729,46751]
name: ignore_depends_on_past [47232,47254]
===
match
---
atom_expr [45180,45241]
atom_expr [45683,45744]
===
match
---
trailer [58366,58372]
trailer [58869,58875]
===
match
---
trailer [24886,24901]
trailer [24886,24901]
===
match
---
operator: = [36876,36877]
operator: = [37379,37380]
===
match
---
name: dagbag_file [21997,22008]
name: dagbag_file [21997,22008]
===
match
---
arglist [15795,15834]
arglist [15795,15834]
===
match
---
trailer [52089,52093]
trailer [52592,52596]
===
match
---
operator: , [26744,26745]
operator: , [26744,26745]
===
match
---
for_stmt [64392,64495]
for_stmt [64895,64998]
===
match
---
name: context [8800,8807]
name: context [8800,8807]
===
match
---
trailer [79917,79923]
trailer [80420,80426]
===
match
---
operator: = [60757,60758]
operator: = [61260,61261]
===
match
---
name: models [77909,77915]
name: models [78412,78418]
===
match
---
trailer [6794,6800]
trailer [6794,6800]
===
match
---
name: all_files_processed [55098,55117]
name: all_files_processed [55601,55620]
===
match
---
operator: , [32473,32474]
operator: , [32976,32977]
===
match
---
atom_expr [18674,18684]
atom_expr [18674,18684]
===
match
---
expr_stmt [30337,30397]
expr_stmt [30591,30651]
===
match
---
name: msg [52735,52738]
name: msg [53238,53241]
===
match
---
atom_expr [22412,22428]
atom_expr [22412,22428]
===
match
---
argument [54392,54427]
argument [54895,54930]
===
match
---
trailer [49753,49762]
trailer [50256,50265]
===
match
---
trailer [72025,72029]
trailer [72528,72532]
===
match
---
name: dag_id [42357,42363]
name: dag_id [42860,42866]
===
match
---
operator: , [36639,36640]
operator: , [37142,37143]
===
match
---
name: session [47380,47387]
name: session [47883,47890]
===
match
---
arglist [79894,79946]
arglist [80397,80449]
===
match
---
name: dag_model [38541,38550]
name: dag_model [39044,39053]
===
match
---
argument [54441,54451]
argument [54944,54954]
===
match
---
trailer [32559,32567]
trailer [33062,33070]
===
match
---
atom_expr [52629,52637]
atom_expr [53132,53140]
===
match
---
string: "\n" [18647,18651]
string: "\n" [18647,18651]
===
match
---
trailer [73566,73570]
trailer [74069,74073]
===
match
---
operator: += [36913,36915]
operator: += [37416,37418]
===
match
---
comparison [49314,49335]
comparison [49817,49838]
===
match
---
argument [76314,76329]
argument [76817,76832]
===
match
---
simple_stmt [76499,76506]
simple_stmt [77002,77009]
===
match
---
operator: = [7764,7765]
operator: = [7764,7765]
===
match
---
string: "Tried to get start time before it started!" [14265,14309]
string: "Tried to get start time before it started!" [14265,14309]
===
match
---
name: log [7048,7051]
name: log [7048,7051]
===
match
---
trailer [38460,38467]
trailer [38963,38970]
===
match
---
name: max_tis_per_query [30526,30543]
name: max_tis_per_query [30780,30797]
===
match
---
funcdef [10745,11170]
funcdef [10745,11170]
===
match
---
name: session [67179,67186]
name: session [67682,67689]
===
match
---
expr_stmt [51109,51119]
expr_stmt [51612,51622]
===
match
---
dotted_name [1098,1124]
dotted_name [1098,1124]
===
match
---
trailer [20392,20398]
trailer [20392,20398]
===
match
---
param [15416,15421]
param [15416,15421]
===
match
---
string: 'scheduler' [57515,57526]
string: 'scheduler' [58018,58029]
===
match
---
trailer [49316,49324]
trailer [49819,49827]
===
match
---
tfpdef [29486,29511]
tfpdef [29740,29765]
===
match
---
name: self [54639,54643]
name: self [55142,55146]
===
match
---
name: session [1454,1461]
name: session [1454,1461]
===
match
---
comparison [35372,35431]
comparison [35875,35934]
===
match
---
trailer [79893,79947]
trailer [80396,80450]
===
match
---
operator: , [15238,15239]
operator: , [15238,15239]
===
match
---
name: len [27814,27817]
name: len [27814,27817]
===
match
---
fstring_expr [20705,20717]
fstring_expr [20705,20717]
===
match
---
operator: } [64209,64210]
operator: } [64712,64713]
===
match
---
name: dag [23964,23967]
name: dag [23964,23967]
===
match
---
name: processor_agent [53399,53414]
name: processor_agent [53902,53917]
===
match
---
atom_expr [52003,52011]
atom_expr [52506,52514]
===
match
---
name: dag [17729,17732]
name: dag [17729,17732]
===
match
---
simple_stmt [34905,35115]
simple_stmt [35408,35618]
===
match
---
param [10044,10049]
param [10044,10049]
===
match
---
number: 5 [10595,10596]
number: 5 [10595,10596]
===
match
---
name: utcnow [17291,17297]
name: utcnow [17291,17297]
===
match
---
expr_stmt [49801,49870]
expr_stmt [50304,50373]
===
match
---
suite [66780,66891]
suite [67283,67394]
===
match
---
name: Pool [37733,37737]
name: Pool [38236,38240]
===
match
---
expr_stmt [44943,45015]
expr_stmt [45446,45518]
===
match
---
name: task_id [46566,46573]
name: task_id [47069,47076]
===
match
---
name: str [20400,20403]
name: str [20400,20403]
===
match
---
trailer [30491,30502]
trailer [30745,30756]
===
match
---
atom_expr [24669,24682]
atom_expr [24669,24682]
===
match
---
atom_expr [36897,36912]
atom_expr [37400,37415]
===
match
---
name: dag_concurrency_limit [42181,42202]
name: dag_concurrency_limit [42684,42705]
===
match
---
argument [69666,69702]
argument [70169,70205]
===
match
---
name: all [16684,16687]
name: all [16684,16687]
===
match
---
dotted_name [1908,1929]
dotted_name [1908,1929]
===
match
---
trailer [35474,35517]
trailer [35977,36020]
===
match
---
simple_stmt [12390,12402]
simple_stmt [12390,12402]
===
match
---
suite [70099,70333]
suite [70602,70836]
===
match
---
expr_stmt [35128,35531]
expr_stmt [35631,36034]
===
match
---
string: 'open' [37986,37992]
string: 'open' [38489,38495]
===
match
---
atom_expr [69624,69644]
atom_expr [70127,70147]
===
match
---
arglist [57852,57975]
arglist [58355,58478]
===
match
---
name: _processor_poll_interval [59586,59610]
name: _processor_poll_interval [60089,60113]
===
match
---
name: tis_changed [35128,35139]
name: tis_changed [35631,35642]
===
match
---
argument [30226,30231]
argument [30480,30485]
===
match
---
atom_expr [58681,58702]
atom_expr [59184,59205]
===
match
---
name: dag_run [77012,77019]
name: dag_run [77515,77522]
===
match
---
funcdef [37087,46076]
funcdef [37590,46579]
===
match
---
param [31433,31438]
param [31810,31815]
===
match
---
name: ti [46942,46944]
name: ti [47445,47447]
===
match
---
atom_expr [37726,37782]
atom_expr [38229,38285]
===
match
---
name: SchedulerJob [79400,79412]
name: SchedulerJob [79903,79915]
===
match
---
trailer [4800,4813]
trailer [4800,4813]
===
match
---
atom_expr [48746,48804]
atom_expr [49249,49307]
===
match
---
atom_expr [3108,3121]
atom_expr [3108,3121]
===
match
---
simple_stmt [45106,45172]
simple_stmt [45609,45675]
===
match
---
atom_expr [17202,17230]
atom_expr [17202,17230]
===
match
---
name: warning [20028,20035]
name: warning [20028,20035]
===
match
---
atom [67942,68167]
atom [68445,68670]
===
match
---
name: schedule_delay [70295,70309]
name: schedule_delay [70798,70812]
===
match
---
suite [66299,66639]
suite [66802,67142]
===
match
---
name: error [73203,73208]
name: error [73706,73711]
===
match
---
operator: = [45958,45959]
operator: = [46461,46462]
===
match
---
name: guard [65371,65376]
name: guard [65874,65879]
===
match
---
operator: = [4142,4143]
operator: = [4142,4143]
===
match
---
arglist [74148,74202]
arglist [74651,74705]
===
match
---
operator: += [41829,41831]
operator: += [42332,42334]
===
match
---
name: simple_ti [24388,24397]
name: simple_ti [24388,24397]
===
match
---
name: session [76760,76767]
name: session [77263,77270]
===
match
---
string: "Tried to kill before starting!" [9962,9994]
string: "Tried to kill before starting!" [9962,9994]
===
match
---
name: bool [10059,10063]
name: bool [10059,10063]
===
match
---
name: dag [17079,17082]
name: dag [17079,17082]
===
match
---
name: dag_run [74020,74027]
name: dag_run [74523,74530]
===
match
---
operator: , [7051,7052]
operator: , [7051,7052]
===
match
---
parameters [22476,22579]
parameters [22476,22579]
===
match
---
simple_stmt [52131,52193]
simple_stmt [52634,52696]
===
match
---
operator: , [19176,19177]
operator: , [19176,19177]
===
match
---
trailer [68280,68362]
trailer [68783,68865]
===
match
---
trailer [20035,20167]
trailer [20035,20167]
===
match
---
trailer [52676,52681]
trailer [53179,53184]
===
match
---
name: TI [73648,73650]
name: TI [74151,74153]
===
match
---
name: dag_models [67347,67357]
name: dag_models [67850,67860]
===
match
---
name: Exception [27674,27683]
name: Exception [27674,27683]
===
match
---
operator: = [63003,63004]
operator: = [63506,63507]
===
match
---
simple_stmt [73088,73161]
simple_stmt [73591,73664]
===
match
---
trailer [70605,70615]
trailer [71108,71118]
===
match
---
suite [27603,27659]
suite [27603,27659]
===
match
---
atom_expr [74919,74945]
atom_expr [75422,75448]
===
match
---
name: info [25074,25078]
name: info [25074,25078]
===
match
---
atom_expr [34567,34584]
atom_expr [35070,35087]
===
match
---
name: qry [16029,16032]
name: qry [16029,16032]
===
match
---
name: filter [50151,50157]
name: filter [50654,50660]
===
match
---
atom_expr [20582,20592]
atom_expr [20582,20592]
===
match
---
name: airflow [1908,1915]
name: airflow [1908,1915]
===
match
---
trailer [73317,73328]
trailer [73820,73831]
===
match
---
atom_expr [29440,29476]
atom_expr [29694,29730]
===
match
---
operator: , [53329,53330]
operator: , [53832,53833]
===
match
---
name: in_ [18111,18114]
name: in_ [18111,18114]
===
match
---
trailer [77587,77603]
trailer [78090,78106]
===
match
---
trailer [16211,16236]
trailer [16211,16236]
===
match
---
subscriptlist [36756,36776]
subscriptlist [37259,37279]
===
match
---
name: self [53253,53257]
name: self [53756,53760]
===
match
---
atom_expr [6513,6551]
atom_expr [6513,6551]
===
match
---
argument [24153,24168]
argument [24153,24168]
===
match
---
atom_expr [54178,54198]
atom_expr [54681,54701]
===
match
---
trailer [81536,81546]
trailer [82039,82049]
===
match
---
operator: } [17006,17007]
operator: } [17006,17007]
===
match
---
trailer [53468,53482]
trailer [53971,53985]
===
match
---
trailer [67866,67871]
trailer [68369,68374]
===
match
---
name: pool [46854,46858]
name: pool [47357,47361]
===
match
---
name: session [70384,70391]
name: session [70887,70894]
===
match
---
name: models [33531,33537]
name: models [34034,34040]
===
match
---
name: exitcode [11984,11992]
name: exitcode [11984,11992]
===
match
---
name: duplex [8813,8819]
name: duplex [8813,8819]
===
match
---
name: e [60896,60897]
name: e [61399,61400]
===
match
---
argument [74353,74390]
argument [74856,74893]
===
match
---
trailer [9961,9995]
trailer [9961,9995]
===
match
---
trailer [42568,42573]
trailer [43071,43076]
===
match
---
trailer [19429,19436]
trailer [19429,19436]
===
match
---
trailer [24111,24131]
trailer [24111,24131]
===
match
---
fstring_expr [6927,6938]
fstring_expr [6927,6938]
===
match
---
operator: == [35333,35335]
operator: == [35836,35838]
===
match
---
name: self [11970,11974]
name: self [11970,11974]
===
match
---
simple_stmt [66236,66258]
simple_stmt [66739,66761]
===
match
---
simple_stmt [41866,41908]
simple_stmt [42369,42411]
===
match
---
name: get_dag [77020,77027]
name: get_dag [77523,77530]
===
match
---
fstring [70232,70269]
fstring [70735,70772]
===
match
---
suite [9926,9996]
suite [9926,9996]
===
match
---
expr_stmt [4872,4936]
expr_stmt [4872,4936]
===
match
---
name: AirflowException [9945,9961]
name: AirflowException [9945,9961]
===
match
---
trailer [36942,36961]
trailer [37445,37464]
===
match
---
name: session [39047,39054]
name: session [39550,39557]
===
match
---
name: open_slots [41492,41502]
name: open_slots [41995,42005]
===
match
---
name: session [66964,66971]
name: session [67467,67474]
===
match
---
raise_stmt [57186,57237]
raise_stmt [57689,57740]
===
match
---
name: _parent_channel [9758,9773]
name: _parent_channel [9758,9773]
===
match
---
name: itertools [848,857]
name: itertools [848,857]
===
match
---
fstring_start: f""" [19466,19470]
fstring_start: f""" [19466,19470]
===
match
---
trailer [66881,66890]
trailer [67384,67393]
===
match
---
simple_stmt [61124,61139]
simple_stmt [61627,61642]
===
match
---
atom_expr [65248,65328]
atom_expr [65751,65831]
===
match
---
operator: , [60215,60216]
operator: , [60718,60719]
===
match
---
name: of [34288,34290]
name: of [34791,34793]
===
match
---
operator: = [51141,51142]
operator: = [51644,51645]
===
match
---
trailer [43023,43051]
trailer [43526,43554]
===
match
---
name: ti [52975,52977]
name: ti [53478,53480]
===
match
---
operator: , [2505,2506]
operator: , [2505,2506]
===
match
---
simple_stmt [54105,54170]
simple_stmt [54608,54673]
===
match
---
atom_expr [58914,58952]
atom_expr [59417,59455]
===
match
---
testlist_comp [68300,68325]
testlist_comp [68803,68828]
===
match
---
atom_expr [71938,71957]
atom_expr [72441,72460]
===
match
---
comparison [34860,34887]
comparison [35363,35390]
===
match
---
operator: , [23387,23388]
operator: , [23387,23388]
===
match
---
simple_stmt [59978,60235]
simple_stmt [60481,60738]
===
match
---
name: task [20467,20471]
name: task [20467,20471]
===
match
---
name: dagbag [73113,73119]
name: dagbag [73616,73622]
===
match
---
name: provide_session [25147,25162]
name: provide_session [25147,25162]
===
match
---
name: task_id [36528,36535]
name: task_id [37031,37038]
===
match
---
name: sla_dates [18115,18124]
name: sla_dates [18115,18124]
===
match
---
trailer [73898,73904]
trailer [74401,74407]
===
match
---
tfpdef [72633,72649]
tfpdef [73136,73152]
===
match
---
name: state [73853,73858]
name: state [74356,74361]
===
match
---
name: buffer_key [52205,52215]
name: buffer_key [52708,52718]
===
match
---
name: _start_time [9327,9338]
name: _start_time [9327,9338]
===
match
---
trailer [18065,18151]
trailer [18065,18151]
===
match
---
operator: = [53981,53982]
operator: = [54484,54485]
===
match
---
trailer [65266,65328]
trailer [65769,65831]
===
match
---
string: """         Takes task_instances, which should have been set to queued, and enqueues them         with the executor.          :param task_instances: TaskInstances to enqueue         :type task_instances: list[TaskInstance]         """ [46176,46410]
string: """         Takes task_instances, which should have been set to queued, and enqueues them         with the executor.          :param task_instances: TaskInstances to enqueue         :type task_instances: list[TaskInstance]         """ [46679,46913]
===
match
---
atom_expr [15300,15318]
atom_expr [15300,15318]
===
match
---
tfpdef [78335,78351]
tfpdef [78838,78854]
===
match
---
if_stmt [38032,38141]
if_stmt [38535,38644]
===
match
---
atom_expr [45106,45171]
atom_expr [45609,45674]
===
match
---
param [35952,35975]
param [36455,36478]
===
match
---
operator: , [36487,36488]
operator: , [36990,36991]
===
match
---
name: _update_dag_next_dagruns [70554,70578]
name: _update_dag_next_dagruns [71057,71081]
===
match
---
name: adopt_or_reset_orphaned_tasks [57418,57447]
name: adopt_or_reset_orphaned_tasks [57921,57950]
===
match
---
name: self [54561,54565]
name: self [55064,55068]
===
match
---
operator: = [60654,60655]
operator: = [61157,61158]
===
match
---
name: __init__ [3883,3891]
name: __init__ [3883,3891]
===
match
---
name: adopt_or_reset_orphaned_tasks [78447,78476]
name: adopt_or_reset_orphaned_tasks [78950,78979]
===
match
---
name: self [78477,78481]
name: self [78980,78984]
===
match
---
name: OperationalError [66277,66293]
name: OperationalError [66780,66796]
===
match
---
suite [9802,10025]
suite [9802,10025]
===
match
---
name: airflow [1767,1774]
name: airflow [1767,1774]
===
match
---
parameters [5029,5035]
parameters [5029,5035]
===
match
---
name: notification_sent [17683,17700]
name: notification_sent [17683,17700]
===
match
---
trailer [11065,11074]
trailer [11065,11074]
===
match
---
string: """Respond to executor events.""" [50677,50710]
string: """Respond to executor events.""" [51180,51213]
===
match
---
trailer [50493,50497]
trailer [50996,51000]
===
match
---
name: execution_date [81002,81016]
name: execution_date [81505,81519]
===
match
---
atom_expr [80090,81018]
atom_expr [80593,81521]
===
match
---
suite [26806,26895]
suite [26806,26895]
===
match
---
name: float [31873,31878]
name: float [32376,32381]
===
match
---
argument [39538,39580]
argument [40041,40083]
===
match
---
atom_expr [11854,11864]
atom_expr [11854,11864]
===
match
---
name: exception [8267,8276]
name: exception [8267,8276]
===
match
---
name: query [80098,80103]
name: query [80601,80606]
===
match
---
trailer [34537,34539]
trailer [35040,35042]
===
match
---
operator: = [3125,3126]
operator: = [3125,3126]
===
match
---
name: close [10732,10737]
name: close [10732,10737]
===
match
---
operator: , [75666,75667]
operator: , [76169,76170]
===
match
---
operator: = [40212,40213]
operator: = [40715,40716]
===
match
---
import_from [1062,1092]
import_from [1062,1092]
===
match
---
operator: , [31431,31432]
operator: , [31808,31809]
===
match
---
operator: , [74806,74807]
operator: , [75309,75310]
===
match
---
trailer [12583,12616]
trailer [12583,12616]
===
match
---
funcdef [70550,72503]
funcdef [71053,73006]
===
match
---
try_stmt [55787,55986]
try_stmt [56290,56489]
===
match
---
atom_expr [50379,50396]
atom_expr [50882,50899]
===
match
---
name: session [35573,35580]
name: session [36076,36083]
===
match
---
operator: , [69874,69875]
operator: , [70377,70378]
===
match
---
atom_expr [38381,38688]
atom_expr [38884,39191]
===
match
---
name: slots_available [65574,65589]
name: slots_available [66077,66092]
===
match
---
simple_stmt [4088,4116]
simple_stmt [4088,4116]
===
match
---
number: 0 [26804,26805]
number: 0 [26804,26805]
===
match
---
name: conf [78822,78826]
name: conf [79325,79329]
===
match
---
simple_stmt [30871,30923]
simple_stmt [31125,31177]
===
match
---
trailer [37985,37993]
trailer [38488,38496]
===
match
---
comparison [67994,68020]
comparison [68497,68523]
===
match
---
operator: , [5312,5313]
operator: , [5312,5313]
===
match
---
operator: = [7874,7875]
operator: = [7874,7875]
===
match
---
simple_stmt [54676,54705]
simple_stmt [55179,55208]
===
match
---
trailer [67175,67177]
trailer [67678,67680]
===
match
---
name: Iterable [1210,1218]
name: Iterable [1210,1218]
===
match
---
atom_expr [39364,39417]
atom_expr [39867,39920]
===
match
---
string: """         :return: result of running DagFileProcessor.process_file()         :rtype: tuple[int, int] or None         """ [13770,13892]
string: """         :return: result of running DagFileProcessor.process_file()         :rtype: tuple[int, int] or None         """ [13770,13892]
===
match
---
operator: , [3220,3221]
operator: , [3220,3221]
===
match
---
operator: = [69680,69681]
operator: = [70183,70184]
===
match
---
operator: , [35931,35932]
operator: , [36434,36435]
===
match
---
name: TaskInstance [35247,35259]
name: TaskInstance [35750,35762]
===
match
---
arglist [31006,31038]
arglist [31260,31292]
===
match
---
trailer [70206,70332]
trailer [70709,70835]
===
match
---
arglist [64038,64087]
arglist [64541,64590]
===
match
---
name: dag_id [76633,76639]
name: dag_id [77136,77142]
===
match
---
trailer [34418,34428]
trailer [34921,34931]
===
match
---
trailer [18723,18725]
trailer [18723,18725]
===
match
---
name: _execute_dag_callbacks [23435,23457]
name: _execute_dag_callbacks [23435,23457]
===
match
---
import_from [1569,1607]
import_from [1569,1607]
===
match
---
trailer [26875,26880]
trailer [26875,26880]
===
match
---
operator: = [74237,74238]
operator: = [74740,74741]
===
match
---
trailer [39643,39670]
trailer [40146,40173]
===
match
---
name: creating_job_id [69935,69950]
name: creating_job_id [70438,70453]
===
match
---
name: SlaMiss [17360,17367]
name: SlaMiss [17360,17367]
===
match
---
try_stmt [65536,66639]
try_stmt [66039,67142]
===
match
---
simple_stmt [8022,8050]
simple_stmt [8022,8050]
===
match
---
atom_expr [78190,78263]
atom_expr [78693,78766]
===
match
---
name: pool_slots_free [37952,37967]
name: pool_slots_free [38455,38470]
===
match
---
trailer [74257,74480]
trailer [74760,74983]
===
match
---
expr_stmt [79347,79726]
expr_stmt [79850,80229]
===
match
---
operator: >= [43810,43812]
operator: >= [44313,44315]
===
match
---
name: _process [10794,10802]
name: _process [10794,10802]
===
match
---
name: task [17026,17030]
name: task [17026,17030]
===
match
---
suite [64428,64495]
suite [64931,64998]
===
match
---
simple_stmt [60581,60825]
simple_stmt [61084,61328]
===
match
---
import_name [825,840]
import_name [825,840]
===
match
---
name: TI [36585,36587]
name: TI [37088,37090]
===
match
---
trailer [18300,18309]
trailer [18300,18309]
===
match
---
name: query [49820,49825]
name: query [50323,50328]
===
match
---
operator: = [63945,63946]
operator: = [64448,64449]
===
match
---
trailer [50776,50811]
trailer [51279,51314]
===
match
---
name: next_dagruns_to_examine [66858,66881]
name: next_dagruns_to_examine [67361,67384]
===
match
---
simple_stmt [15327,15350]
simple_stmt [15327,15350]
===
match
---
suite [27509,27546]
suite [27509,27546]
===
match
---
atom_expr [36473,36493]
atom_expr [36976,36996]
===
match
---
name: next_dagrun [68074,68085]
name: next_dagrun [68577,68588]
===
match
---
trailer [16132,16142]
trailer [16132,16142]
===
match
---
trailer [74706,74708]
trailer [75209,75211]
===
match
---
operator: - [81950,81951]
operator: - [82453,82454]
===
match
---
atom_expr [30174,30188]
atom_expr [30428,30442]
===
match
---
atom_expr [68046,68067]
atom_expr [68549,68570]
===
match
---
operator: @ [35870,35871]
operator: @ [36373,36374]
===
match
---
parameters [66764,66779]
parameters [67267,67282]
===
match
---
name: session [64003,64010]
name: session [64506,64513]
===
match
---
suite [19130,19274]
suite [19130,19274]
===
match
---
name: session [71676,71683]
name: session [72179,72186]
===
match
---
name: state [36588,36593]
name: state [37091,37096]
===
match
---
tfpdef [15270,15289]
tfpdef [15270,15289]
===
match
---
name: Optional [4468,4476]
name: Optional [4468,4476]
===
match
---
suite [59673,59920]
suite [60176,60423]
===
match
---
name: tis_changed [35740,35751]
name: tis_changed [36243,36254]
===
match
---
trailer [15262,15267]
trailer [15262,15267]
===
match
---
operator: , [57974,57975]
operator: , [58477,58478]
===
match
---
name: TaskCallbackRequest [23128,23147]
name: TaskCallbackRequest [23128,23147]
===
match
---
argument [74450,74465]
argument [74953,74968]
===
match
---
trailer [43323,43332]
trailer [43826,43835]
===
match
---
trailer [76632,76639]
trailer [77135,77142]
===
match
---
operator: , [27396,27397]
operator: , [27396,27397]
===
match
---
operator: = [36495,36496]
operator: = [36998,36999]
===
match
---
operator: = [76321,76322]
operator: = [76824,76825]
===
match
---
name: info [52539,52543]
name: info [53042,53046]
===
match
---
name: TI [50082,50084]
name: TI [50585,50587]
===
match
---
operator: , [1678,1679]
operator: , [1678,1679]
===
match
---
name: execution_date [35392,35406]
name: execution_date [35895,35909]
===
match
---
tfpdef [70585,70615]
tfpdef [71088,71118]
===
match
---
param [15234,15239]
param [15234,15239]
===
match
---
name: Session [1469,1476]
name: Session [1469,1476]
===
match
---
atom_expr [71108,71157]
atom_expr [71611,71660]
===
match
---
name: executor [54566,54574]
name: executor [55069,55077]
===
match
---
name: any [77397,77400]
name: any [77900,77903]
===
match
---
atom_expr [55077,55117]
atom_expr [55580,55620]
===
match
---
operator: , [46964,46965]
operator: , [47467,47468]
===
match
---
name: grace_multiplier [31846,31862]
name: grace_multiplier [32349,32365]
===
match
---
name: task_id [18677,18684]
name: task_id [18677,18684]
===
match
---
simple_stmt [38119,38141]
simple_stmt [38622,38644]
===
match
---
simple_stmt [18942,18968]
simple_stmt [18942,18968]
===
match
---
atom_expr [5293,5312]
atom_expr [5293,5312]
===
match
---
trailer [8852,8860]
trailer [8852,8860]
===
match
---
simple_stmt [78742,78804]
simple_stmt [79245,79307]
===
match
---
name: process [9306,9313]
name: process [9306,9313]
===
match
---
simple_stmt [2996,3034]
simple_stmt [2996,3034]
===
match
---
comparison [35240,35283]
comparison [35743,35786]
===
match
---
number: 0 [75343,75344]
number: 0 [75846,75847]
===
match
---
name: task_instance [43686,43699]
name: task_instance [44189,44202]
===
match
---
operator: , [42787,42788]
operator: , [43290,43291]
===
match
---
name: debug [77474,77479]
name: debug [77977,77982]
===
match
---
suite [68195,68363]
suite [68698,68866]
===
match
---
name: sla [17957,17960]
name: sla [17957,17960]
===
match
---
trailer [5306,5311]
trailer [5306,5311]
===
match
---
funcdef [12012,13696]
funcdef [12012,13696]
===
match
---
atom_expr [30521,30543]
atom_expr [30775,30797]
===
match
---
simple_stmt [42910,42919]
simple_stmt [43413,43422]
===
match
---
name: expected_start_date [70154,70173]
name: expected_start_date [70657,70676]
===
match
---
suite [46014,46046]
suite [46517,46549]
===
match
---
name: self [30464,30468]
name: self [30718,30722]
===
match
---
trailer [35048,35061]
trailer [35551,35564]
===
match
---
simple_stmt [12633,12654]
simple_stmt [12633,12654]
===
match
---
atom_expr [18283,18293]
atom_expr [18283,18293]
===
match
---
trailer [16378,16387]
trailer [16378,16387]
===
match
---
atom_expr [66359,66395]
atom_expr [66862,66898]
===
match
---
name: repr [81537,81541]
name: repr [82040,82044]
===
match
---
name: executable_tis [44786,44800]
name: executable_tis [45289,45303]
===
match
---
operator: , [74432,74433]
operator: , [74935,74936]
===
match
---
name: TaskInstanceKey [50996,51011]
name: TaskInstanceKey [51499,51514]
===
match
---
name: state [52968,52973]
name: state [53471,53476]
===
match
---
name: num_starving_tasks_total [44617,44641]
name: num_starving_tasks_total [45120,45144]
===
match
---
name: self [24882,24886]
name: self [24882,24886]
===
match
---
tfpdef [29622,29637]
tfpdef [29876,29891]
===
match
---
simple_stmt [31639,31662]
simple_stmt [32142,32165]
===
match
---
name: dag [18297,18300]
name: dag [18297,18300]
===
match
---
name: task_instances [41260,41274]
name: task_instances [41763,41777]
===
match
---
fstring [9111,9149]
fstring [9111,9149]
===
match
---
trailer [16687,16689]
trailer [16687,16689]
===
match
---
simple_stmt [74758,74832]
simple_stmt [75261,75335]
===
match
---
trailer [74156,74162]
trailer [74659,74665]
===
match
---
trailer [24694,24705]
trailer [24694,24705]
===
match
---
simple_stmt [10090,10287]
simple_stmt [10090,10287]
===
match
---
name: is_alive [13474,13482]
name: is_alive [13474,13482]
===
match
---
name: log [74763,74766]
name: log [75266,75269]
===
match
---
comparison [67846,67882]
comparison [68349,68385]
===
match
---
operator: == [18137,18139]
operator: == [18137,18139]
===
match
---
atom_expr [77909,77949]
atom_expr [78412,78452]
===
match
---
trailer [71125,71157]
trailer [71628,71660]
===
match
---
trailer [73735,73746]
trailer [74238,74249]
===
match
---
trailer [75285,75300]
trailer [75788,75803]
===
match
---
atom_expr [29660,29674]
atom_expr [29914,29928]
===
match
---
suite [81487,81644]
suite [81990,82147]
===
match
---
name: dag_ids [56417,56424]
name: dag_ids [56920,56927]
===
match
---
trailer [31679,31684]
trailer [32182,32187]
===
match
---
trailer [23326,23330]
trailer [23326,23330]
===
match
---
arglist [39604,39689]
arglist [40107,40192]
===
match
---
name: _process [11975,11983]
name: _process [11975,11983]
===
match
---
operator: = [15340,15341]
operator: = [15340,15341]
===
match
---
name: dag [71624,71627]
name: dag [72127,72130]
===
match
---
trailer [13532,13536]
trailer [13532,13536]
===
match
---
name: pool [40809,40813]
name: pool [41312,41316]
===
match
---
atom_expr [68403,68490]
atom_expr [68906,68993]
===
match
---
name: TI [16577,16579]
name: TI [16577,16579]
===
match
---
simple_stmt [13588,13609]
simple_stmt [13588,13609]
===
match
---
decorator [22434,22451]
decorator [22434,22451]
===
match
---
operator: , [9205,9206]
operator: , [9205,9206]
===
match
---
name: task [19868,19872]
name: task [19868,19872]
===
match
---
annassign [37511,37526]
annassign [38014,38029]
===
match
---
simple_stmt [8062,8133]
simple_stmt [8062,8133]
===
match
---
simple_stmt [31230,31299]
simple_stmt [31607,31676]
===
match
---
string: "Processor agent is not started." [76962,76995]
string: "Processor agent is not started." [77465,77498]
===
match
---
name: _process [9295,9303]
name: _process [9295,9303]
===
match
---
trailer [14264,14310]
trailer [14264,14310]
===
match
---
number: 0 [3872,3873]
number: 0 [3872,3873]
===
match
---
name: dag_id [71046,71052]
name: dag_id [71549,71555]
===
match
---
trailer [16845,16866]
trailer [16845,16866]
===
match
---
name: dag_id [68766,68772]
name: dag_id [69269,69275]
===
match
---
operator: , [71806,71807]
operator: , [72309,72310]
===
match
---
param [60319,60326]
param [60822,60829]
===
match
---
name: dag_model [46897,46906]
name: dag_model [47400,47409]
===
match
---
name: prohibit_commit [62841,62856]
name: prohibit_commit [63344,63359]
===
match
---
operator: = [40244,40245]
operator: = [40747,40748]
===
match
---
trailer [23198,23215]
trailer [23198,23215]
===
match
---
expr_stmt [52735,52927]
expr_stmt [53238,53430]
===
match
---
operator: , [29696,29697]
operator: , [29950,29951]
===
match
---
name: timezone [32585,32593]
name: timezone [33088,33096]
===
match
---
atom_expr [30426,30455]
atom_expr [30680,30709]
===
match
---
simple_stmt [17596,17778]
simple_stmt [17596,17778]
===
match
---
atom_expr [61045,61063]
atom_expr [61548,61566]
===
match
---
trailer [81541,81545]
trailer [82044,82048]
===
match
---
atom_expr [44894,44921]
atom_expr [45397,45424]
===
match
---
trailer [55148,55274]
trailer [55651,55777]
===
match
---
trailer [55719,55723]
trailer [56222,56226]
===
match
---
trailer [22018,22036]
trailer [22018,22036]
===
match
---
name: List [25250,25254]
name: List [25250,25254]
===
match
---
trailer [27119,27146]
trailer [27119,27146]
===
match
---
argument [81228,81233]
argument [81731,81736]
===
match
---
name: defaultdict [63947,63958]
name: defaultdict [64450,64461]
===
match
---
trailer [50497,50502]
trailer [51000,51005]
===
match
---
comparison [49277,49296]
comparison [49780,49799]
===
match
---
name: active_dagruns [69538,69552]
name: active_dagruns [70041,70055]
===
match
---
name: session [34326,34333]
name: session [34829,34836]
===
match
---
name: is_ [38468,38471]
name: is_ [38971,38974]
===
match
---
tfpdef [67347,67377]
tfpdef [67850,67880]
===
match
---
name: TI [81231,81233]
name: TI [81734,81736]
===
match
---
arglist [50503,50573]
arglist [51006,51076]
===
match
---
atom [73535,73762]
atom [74038,74265]
===
match
---
arglist [71908,71921]
arglist [72411,72424]
===
match
---
name: log [76395,76398]
name: log [76898,76901]
===
match
---
operator: , [66962,66963]
operator: , [67465,67466]
===
match
---
name: request [23063,23070]
name: request [23063,23070]
===
match
---
trailer [36720,36725]
trailer [37223,37228]
===
match
---
string: """         Terminate (and then kill) the process launched to process the file.          :param sigkill: whether to issue a SIGKILL if SIGTERM doesn't work.         :type sigkill: bool         """ [10090,10286]
string: """         Terminate (and then kill) the process launched to process the file.          :param sigkill: whether to issue a SIGKILL if SIGTERM doesn't work.         :type sigkill: bool         """ [10090,10286]
===
match
---
operator: , [69506,69507]
operator: , [70009,70010]
===
match
---
suite [8190,8331]
suite [8190,8331]
===
match
---
trailer [12516,12518]
trailer [12516,12518]
===
match
---
trailer [65320,65327]
trailer [65823,65830]
===
match
---
name: log [31676,31679]
name: log [32179,32182]
===
match
---
simple_stmt [66982,67081]
simple_stmt [67485,67584]
===
match
---
factor [41292,41311]
factor [41795,41814]
===
match
---
name: _send_dag_callbacks_to_processor [75626,75658]
name: _send_dag_callbacks_to_processor [76129,76161]
===
match
---
simple_stmt [6780,6803]
simple_stmt [6780,6803]
===
match
---
operator: = [18645,18646]
operator: = [18645,18646]
===
match
---
funcdef [66922,67285]
funcdef [67425,67788]
===
match
---
import_as_names [2853,2884]
import_as_names [2853,2884]
===
match
---
sync_comp_for [39546,39580]
sync_comp_for [40049,40083]
===
match
---
name: dagbag [76603,76609]
name: dagbag [77106,77112]
===
match
---
name: threading [938,947]
name: threading [938,947]
===
match
---
name: log [7765,7768]
name: log [7765,7768]
===
match
---
trailer [22531,22548]
trailer [22531,22548]
===
match
---
name: self [59581,59585]
name: self [60084,60088]
===
match
---
suite [10669,10703]
suite [10669,10703]
===
match
---
trailer [27065,27087]
trailer [27065,27087]
===
match
---
argument [76752,76767]
argument [77255,77270]
===
match
---
operator: = [8819,8820]
operator: = [8819,8820]
===
match
---
trailer [20471,20477]
trailer [20471,20477]
===
match
---
string: 'scheduler_heartbeat' [78388,78409]
string: 'scheduler_heartbeat' [78891,78912]
===
match
---
name: property [11504,11512]
name: property [11504,11512]
===
match
---
trailer [32627,32641]
trailer [33130,33144]
===
match
---
param [78483,78506]
param [78986,79009]
===
match
---
operator: , [47279,47280]
operator: , [47782,47783]
===
match
---
trailer [44232,44552]
trailer [44735,45055]
===
match
---
name: num_starving_tasks [45077,45095]
name: num_starving_tasks [45580,45598]
===
match
---
atom_expr [72605,72622]
atom_expr [73108,73125]
===
match
---
name: dag [18341,18344]
name: dag [18341,18344]
===
match
---
simple_stmt [44573,44597]
simple_stmt [45076,45100]
===
match
---
name: signal [913,919]
name: signal [913,919]
===
match
---
trailer [39542,39545]
trailer [40045,40048]
===
match
---
name: log [59147,59150]
name: log [59650,59653]
===
match
---
name: _ [51139,51140]
name: _ [51642,51643]
===
match
---
name: skip_locked [2968,2979]
name: skip_locked [2968,2979]
===
match
---
atom_expr [73194,73262]
atom_expr [73697,73765]
===
match
---
name: ti_prop_update [35475,35489]
name: ti_prop_update [35978,35992]
===
match
---
trailer [44173,44184]
trailer [44676,44687]
===
match
---
expr_stmt [7786,8005]
expr_stmt [7786,8005]
===
match
---
name: and_ [67964,67968]
name: and_ [68467,68471]
===
match
---
expr_stmt [17982,18188]
expr_stmt [17982,18188]
===
match
---
trailer [4066,4068]
trailer [4066,4068]
===
match
---
name: DagRun [68417,68423]
name: DagRun [68920,68926]
===
match
---
name: logging [6513,6520]
name: logging [6513,6520]
===
match
---
operator: , [16655,16656]
operator: , [16655,16656]
===
match
---
name: log [35606,35609]
name: log [36109,36112]
===
match
---
name: id [81770,81772]
name: id [82273,82275]
===
match
---
atom_expr [21310,21328]
atom_expr [21310,21328]
===
match
---
name: dag_id [68608,68614]
name: dag_id [69111,69117]
===
match
---
trailer [71941,71957]
trailer [72444,72460]
===
match
---
name: class_creation_counter [4840,4862]
name: class_creation_counter [4840,4862]
===
match
---
name: self [11738,11742]
name: self [11738,11742]
===
match
---
atom_expr [11061,11078]
atom_expr [11061,11078]
===
match
---
trailer [51498,51505]
trailer [52001,52008]
===
match
---
name: dag [16351,16354]
name: dag [16351,16354]
===
match
---
trailer [31526,31534]
trailer [32029,32037]
===
match
---
arglist [75107,75301]
arglist [75610,75804]
===
match
---
simple_stmt [7615,7690]
simple_stmt [7615,7690]
===
match
---
name: do_pickle [53668,53677]
name: do_pickle [54171,54180]
===
match
---
trailer [72233,72249]
trailer [72736,72752]
===
match
---
atom_expr [17934,17952]
atom_expr [17934,17952]
===
match
---
operator: , [80905,80906]
operator: , [81408,81409]
===
match
---
trailer [77932,77949]
trailer [78435,78452]
===
match
---
name: TI [18093,18095]
name: TI [18093,18095]
===
match
---
atom_expr [80021,80034]
atom_expr [80524,80537]
===
match
---
name: send [66247,66251]
name: send [66750,66754]
===
match
---
name: e [60952,60953]
name: e [61455,61456]
===
match
---
name: process [9367,9374]
name: process [9367,9374]
===
match
---
atom_expr [16084,16101]
atom_expr [16084,16101]
===
match
---
name: List [35941,35945]
name: List [36444,36448]
===
match
---
operator: , [69958,69959]
operator: , [70461,70462]
===
match
---
expr_stmt [63977,64378]
expr_stmt [64480,64881]
===
match
---
name: self [26921,26925]
name: self [26921,26925]
===
match
---
name: timezone [54739,54747]
name: timezone [55242,55250]
===
match
---
name: states [35933,35939]
name: states [36436,36442]
===
match
---
testlist_star_expr [36853,36875]
testlist_star_expr [37356,37378]
===
match
---
operator: , [52537,52538]
operator: , [53040,53041]
===
match
---
simple_stmt [82619,82625]
simple_stmt [83122,83128]
===
match
---
arglist [30362,30388]
arglist [30616,30642]
===
match
---
atom_expr [58809,58841]
atom_expr [59312,59344]
===
match
---
expr_stmt [3847,3873]
expr_stmt [3847,3873]
===
match
---
argument [30233,30241]
argument [30487,30495]
===
match
---
trailer [69785,69793]
trailer [70288,70296]
===
match
---
atom_expr [38422,38432]
atom_expr [38925,38935]
===
match
---
trailer [22419,22426]
trailer [22419,22426]
===
match
---
atom_expr [51866,51883]
atom_expr [52369,52386]
===
match
---
atom_expr [74177,74191]
atom_expr [74680,74694]
===
match
---
name: dag_run [73380,73387]
name: dag_run [73883,73890]
===
match
---
trailer [76617,76657]
trailer [77120,77160]
===
match
---
name: finished [34879,34887]
name: finished [35382,35390]
===
match
---
name: self [11480,11484]
name: self [11480,11484]
===
match
---
operator: -> [31888,31890]
operator: -> [32391,32393]
===
match
---
name: Optional [1226,1234]
name: Optional [1226,1234]
===
match
---
operator: , [9270,9271]
operator: , [9270,9271]
===
match
---
name: Pool [77916,77920]
name: Pool [78419,78423]
===
match
---
atom_expr [53741,53822]
atom_expr [54244,54325]
===
match
---
suite [23000,23755]
suite [23000,23755]
===
match
---
name: DagRun [71039,71045]
name: DagRun [71542,71548]
===
match
---
name: dag_run [74004,74011]
name: dag_run [74507,74514]
===
match
---
atom_expr [77441,77450]
atom_expr [77944,77953]
===
match
---
name: debug [59151,59156]
name: debug [59654,59659]
===
match
---
name: reset_tis_message [81425,81442]
name: reset_tis_message [81928,81945]
===
match
---
name: rollback [61053,61061]
name: rollback [61556,61564]
===
match
---
operator: , [1834,1835]
operator: , [1834,1835]
===
match
---
trailer [59694,59698]
trailer [60197,60201]
===
match
---
name: DagBag [30689,30695]
name: DagBag [30943,30949]
===
match
---
name: debug [78996,79001]
name: debug [79499,79504]
===
match
---
name: tasks_missed_sla [19776,19792]
name: tasks_missed_sla [19776,19792]
===
match
---
trailer [54864,54874]
trailer [55367,55377]
===
match
---
name: processor_poll_interval [30141,30164]
name: processor_poll_interval [30395,30418]
===
match
---
operator: = [31880,31881]
operator: = [32383,32384]
===
match
---
trailer [63009,63038]
trailer [63512,63541]
===
match
---
trailer [37980,38021]
trailer [38483,38524]
===
match
---
simple_stmt [12535,12553]
simple_stmt [12535,12553]
===
match
---
name: FAILED [60522,60528]
name: FAILED [61025,61031]
===
match
---
operator: { [70256,70257]
operator: { [70759,70760]
===
match
---
if_stmt [24322,25141]
if_stmt [24322,25141]
===
match
---
atom_expr [38612,38620]
atom_expr [39115,39123]
===
match
---
atom_expr [62841,62865]
atom_expr [63344,63368]
===
match
---
trailer [68013,68020]
trailer [68516,68523]
===
match
---
name: session [66882,66889]
name: session [67385,67392]
===
match
---
trailer [50140,50146]
trailer [50643,50649]
===
match
---
trailer [33620,33627]
trailer [34123,34130]
===
match
---
operator: = [22377,22378]
operator: = [22377,22378]
===
match
---
name: processor_timeout [54105,54122]
name: processor_timeout [54608,54625]
===
match
---
name: state [53371,53376]
name: state [53874,53879]
===
match
---
name: executor [81347,81355]
name: executor [81850,81858]
===
match
---
suite [42539,42919]
suite [43042,43422]
===
match
---
operator: } [6937,6938]
operator: } [6937,6938]
===
match
---
operator: >= [71981,71983]
operator: >= [72484,72486]
===
match
---
atom_expr [18566,18596]
atom_expr [18566,18596]
===
match
---
string: """         Process the given file.          :param result_channel: the connection to use for passing back the result         :type result_channel: multiprocessing.Connection         :param parent_channel: the parent end of the channel to close in the child         :type parent_channel: multiprocessing.Connection         :param file_path: the file to process         :type file_path: str         :param pickle_dags: whether to pickle the DAGs found in the file and             save them to the DB         :type pickle_dags: bool         :param dag_ids: if specified, only examine DAG ID's that are             in this list         :type dag_ids: list[str]         :param thread_name: the name to use for the process that is launched         :type thread_name: str         :param callback_requests: failure callback to execute         :type callback_requests: List[airflow.utils.callback_requests.CallbackRequest]         :return: the process that was launched         :rtype: multiprocessing.Process         """ [5413,6426]
string: """         Process the given file.          :param result_channel: the connection to use for passing back the result         :type result_channel: multiprocessing.Connection         :param parent_channel: the parent end of the channel to close in the child         :type parent_channel: multiprocessing.Connection         :param file_path: the file to process         :type file_path: str         :param pickle_dags: whether to pickle the DAGs found in the file and             save them to the DB         :type pickle_dags: bool         :param dag_ids: if specified, only examine DAG ID's that are             in this list         :type dag_ids: list[str]         :param thread_name: the name to use for the process that is launched         :type thread_name: str         :param callback_requests: failure callback to execute         :type callback_requests: List[airflow.utils.callback_requests.CallbackRequest]         :return: the process that was launched         :rtype: multiprocessing.Process         """ [5413,6426]
===
match
---
expr_stmt [8766,8826]
expr_stmt [8766,8826]
===
match
---
trailer [40951,40956]
trailer [41454,41459]
===
match
---
simple_stmt [23430,23484]
simple_stmt [23430,23484]
===
match
---
operator: , [1419,1420]
operator: , [1419,1420]
===
match
---
atom_expr [34686,34716]
atom_expr [35189,35219]
===
match
---
operator: , [47219,47220]
operator: , [47722,47723]
===
match
---
simple_stmt [81617,81644]
simple_stmt [82120,82147]
===
match
---
decorated [11998,13696]
decorated [11998,13696]
===
match
---
name: currently_active_runs [75234,75255]
name: currently_active_runs [75737,75758]
===
match
---
trailer [24796,24807]
trailer [24796,24807]
===
match
---
expr_stmt [76238,76330]
expr_stmt [76741,76833]
===
match
---
funcdef [3879,4997]
funcdef [3879,4997]
===
match
---
string: "Reset the following %s orphaned TaskInstances:\n\t%s" [82143,82197]
string: "Reset the following %s orphaned TaskInstances:\n\t%s" [82646,82700]
===
match
---
name: log [29655,29658]
name: log [29909,29912]
===
match
---
trailer [27299,27323]
trailer [27299,27323]
===
match
---
string: 'scheduler' [32462,32473]
string: 'scheduler' [32965,32976]
===
match
---
trailer [79923,79925]
trailer [80426,80428]
===
match
---
fstring_start: f" [16921,16923]
fstring_start: f" [16921,16923]
===
match
---
name: self [46127,46131]
name: self [46630,46634]
===
match
---
name: Session [32819,32826]
name: Session [33322,33329]
===
match
---
operator: , [46711,46712]
operator: , [47214,47215]
===
match
---
trailer [42228,42240]
trailer [42731,42743]
===
match
---
name: file_path [26439,26448]
name: file_path [26439,26448]
===
match
---
operator: , [40235,40236]
operator: , [40738,40739]
===
match
---
param [23834,23839]
param [23834,23839]
===
match
---
trailer [9017,9027]
trailer [9017,9027]
===
match
---
trailer [12606,12615]
trailer [12606,12615]
===
match
---
operator: = [37759,37760]
operator: = [38262,38263]
===
match
---
arglist [35475,35516]
arglist [35978,36019]
===
match
---
trailer [69690,69702]
trailer [70193,70205]
===
match
---
simple_stmt [54604,54626]
simple_stmt [55107,55129]
===
match
---
suite [59296,59625]
suite [59799,60128]
===
match
---
return_stmt [32519,32688]
return_stmt [33022,33191]
===
match
---
name: TI [50222,50224]
name: TI [50725,50727]
===
match
---
arglist [73209,73261]
arglist [73712,73764]
===
match
---
and_test [59228,59295]
and_test [59731,59798]
===
match
---
trailer [27101,27119]
trailer [27101,27119]
===
match
---
name: self [45913,45917]
name: self [46416,46420]
===
match
---
arglist [15933,15999]
arglist [15933,15999]
===
match
---
name: dag [24442,24445]
name: dag [24442,24445]
===
match
---
name: isinstance [77401,77411]
name: isinstance [77904,77914]
===
match
---
operator: = [40909,40910]
operator: = [41412,41413]
===
match
---
trailer [73729,73747]
trailer [74232,74250]
===
match
---
trailer [79244,79305]
trailer [79747,79808]
===
match
---
number: 1 [44645,44646]
number: 1 [45148,45149]
===
match
---
atom_expr [68598,68614]
atom_expr [69101,69117]
===
match
---
simple_stmt [39848,39913]
simple_stmt [40351,40416]
===
match
---
name: Session [37157,37164]
name: Session [37660,37667]
===
match
---
atom_expr [18127,18136]
atom_expr [18127,18136]
===
match
---
name: dag_ids [15240,15247]
name: dag_ids [15240,15247]
===
match
---
name: int [36792,36795]
name: int [37295,37298]
===
match
---
funcdef [14046,14343]
funcdef [14046,14343]
===
match
---
suite [36049,37003]
suite [36552,37506]
===
match
---
name: execution_date [49374,49388]
name: execution_date [49877,49891]
===
match
---
import_from [1286,1338]
import_from [1286,1338]
===
match
---
operator: , [46545,46546]
operator: , [47048,47049]
===
match
---
name: x [39550,39551]
name: x [40053,40054]
===
match
---
trailer [24046,24062]
trailer [24046,24062]
===
match
---
name: self [5059,5063]
name: self [5059,5063]
===
match
---
atom_expr [6780,6802]
atom_expr [6780,6802]
===
match
---
atom_expr [53136,53158]
atom_expr [53639,53661]
===
match
---
trailer [60984,60990]
trailer [61487,61493]
===
match
---
simple_stmt [34516,34540]
simple_stmt [35019,35043]
===
match
---
name: itertools [58013,58022]
name: itertools [58516,58525]
===
match
---
subscriptlist [36762,36770]
subscriptlist [37265,37273]
===
match
---
import_from [1693,1761]
import_from [1693,1761]
===
match
---
operator: , [42748,42749]
operator: , [43251,43252]
===
match
---
name: dttm [17509,17513]
name: dttm [17509,17513]
===
match
---
simple_stmt [10365,10432]
simple_stmt [10365,10432]
===
match
---
trailer [54617,54623]
trailer [55120,55126]
===
match
---
name: set_state [73471,73480]
name: set_state [73974,73983]
===
match
---
atom_expr [34905,35114]
atom_expr [35408,35617]
===
match
---
decorator [21363,21377]
decorator [21363,21377]
===
match
---
trailer [38910,38916]
trailer [39413,39419]
===
match
---
trailer [73416,73418]
trailer [73919,73921]
===
match
---
name: _result [12481,12488]
name: _result [12481,12488]
===
match
---
operator: + [18555,18556]
operator: + [18555,18556]
===
match
---
trailer [58372,58433]
trailer [58875,58936]
===
match
---
name: sqlalchemy [1498,1508]
name: sqlalchemy [1498,1508]
===
match
---
operator: ** [30233,30235]
operator: ** [30487,30489]
===
match
---
expr_stmt [46993,47022]
expr_stmt [47496,47525]
===
match
---
name: ti [46563,46565]
name: ti [47066,47068]
===
match
---
name: email [20347,20352]
name: email [20347,20352]
===
match
---
comparison [71175,71204]
comparison [71678,71707]
===
match
---
arglist [53267,53340]
arglist [53770,53843]
===
match
---
operator: , [7884,7885]
operator: , [7884,7885]
===
match
---
argument [57561,57575]
argument [58064,58078]
===
match
---
operator: , [1051,1052]
operator: , [1051,1052]
===
match
---
simple_stmt [44943,45016]
simple_stmt [45446,45519]
===
match
---
trailer [48823,48835]
trailer [49326,49338]
===
match
---
trailer [24445,24454]
trailer [24445,24454]
===
match
---
trailer [36031,36041]
trailer [36534,36544]
===
match
---
suite [10777,11170]
suite [10777,11170]
===
match
---
simple_stmt [40899,40931]
simple_stmt [41402,41434]
===
match
---
name: task [17271,17275]
name: task [17271,17275]
===
match
---
name: warning [40741,40748]
name: warning [41244,41251]
===
match
---
name: start_date [24672,24682]
name: start_date [24672,24682]
===
match
---
name: UP_FOR_RESCHEDULE [60693,60710]
name: UP_FOR_RESCHEDULE [61196,61213]
===
match
---
trailer [43245,43252]
trailer [43748,43755]
===
match
---
trailer [18219,18223]
trailer [18219,18223]
===
match
---
atom_expr [77763,77774]
atom_expr [78266,78277]
===
match
---
trailer [74772,74831]
trailer [75275,75334]
===
match
---
atom_expr [59196,59210]
atom_expr [59699,59713]
===
match
---
name: self [26997,27001]
name: self [26997,27001]
===
match
---
simple_stmt [48656,48737]
simple_stmt [49159,49240]
===
match
---
trailer [4316,4325]
trailer [4316,4325]
===
match
---
comparison [38479,38517]
comparison [38982,39020]
===
match
---
argument [67941,68167]
argument [68444,68670]
===
match
---
operator: , [26769,26770]
operator: , [26769,26770]
===
match
---
trailer [34582,34584]
trailer [35085,35087]
===
match
---
name: pid [11193,11196]
name: pid [11193,11196]
===
match
---
trailer [50858,50899]
trailer [51361,51402]
===
match
---
operator: , [78845,78846]
operator: , [79348,79349]
===
match
---
argument [56371,56390]
argument [56874,56893]
===
match
---
operator: , [49296,49297]
operator: , [49799,49800]
===
match
---
comparison [17139,17163]
comparison [17139,17163]
===
match
---
tfpdef [5348,5388]
tfpdef [5348,5388]
===
match
---
name: num_runs [29777,29785]
name: num_runs [30031,30039]
===
match
---
simple_stmt [11878,11955]
simple_stmt [11878,11955]
===
match
---
name: len [45292,45295]
name: len [45795,45798]
===
match
---
operator: { [64170,64171]
operator: { [64673,64674]
===
match
---
arglist [51360,51635]
arglist [51863,52138]
===
match
---
param [10763,10767]
param [10763,10767]
===
match
---
name: pool [40872,40876]
name: pool [41375,41379]
===
match
---
suite [24455,25141]
suite [24455,25141]
===
match
---
trailer [38540,38550]
trailer [39043,39053]
===
match
---
trailer [13427,13441]
trailer [13427,13441]
===
match
---
name: DM [38577,38579]
name: DM [39080,39082]
===
match
---
name: executor [48622,48630]
name: executor [49125,49133]
===
match
---
trailer [42265,42270]
trailer [42768,42773]
===
match
---
suite [27716,27780]
suite [27716,27780]
===
match
---
name: pool [38862,38866]
name: pool [39365,39369]
===
match
---
name: staticmethod [56041,56053]
name: staticmethod [56544,56556]
===
match
---
trailer [12511,12516]
trailer [12511,12516]
===
match
---
trailer [48792,48804]
trailer [49295,49307]
===
match
---
name: TI [16084,16086]
name: TI [16084,16086]
===
match
---
simple_stmt [960,996]
simple_stmt [960,996]
===
match
---
name: context [8705,8712]
name: context [8705,8712]
===
match
---
trailer [36524,36564]
trailer [37027,37067]
===
match
---
atom_expr [75198,75208]
atom_expr [75701,75711]
===
match
---
argument [81266,81281]
argument [81769,81784]
===
match
---
string: "\n" [18533,18537]
string: "\n" [18533,18537]
===
match
---
name: list [64165,64169]
name: list [64668,64672]
===
match
---
name: count [36870,36875]
name: count [37373,37378]
===
match
---
name: target [8874,8880]
name: target [8874,8880]
===
match
---
name: unpaused_dags [27337,27350]
name: unpaused_dags [27337,27350]
===
match
---
trailer [71038,71070]
trailer [71541,71573]
===
match
---
param [25281,25307]
param [25281,25307]
===
match
---
name: session [48728,48735]
name: session [49231,49238]
===
match
---
operator: = [17394,17395]
operator: = [17394,17395]
===
match
---
name: _process [12223,12231]
name: _process [12223,12231]
===
match
---
trailer [71309,71311]
trailer [71812,71814]
===
match
---
operator: , [39025,39026]
operator: , [39528,39529]
===
match
---
string: 'dag_file_refresh_error' [26717,26741]
string: 'dag_file_refresh_error' [26717,26741]
===
match
---
import_name [841,857]
import_name [841,857]
===
match
---
comparison [41492,41507]
comparison [41995,42010]
===
match
---
simple_stmt [26476,26555]
simple_stmt [26476,26555]
===
match
---
trailer [73973,74035]
trailer [74476,74538]
===
match
---
name: TI [50147,50149]
name: TI [50650,50652]
===
match
---
trailer [77411,77430]
trailer [77914,77933]
===
match
---
decorator [25146,25163]
decorator [25146,25163]
===
match
---
arglist [57866,57929]
arglist [58369,58432]
===
match
---
name: new_state [60748,60757]
name: new_state [61251,61260]
===
match
---
tfpdef [50636,50652]
tfpdef [51139,51155]
===
match
---
name: bool [56223,56227]
name: bool [56726,56730]
===
match
---
string: 'webserver' [19717,19728]
string: 'webserver' [19717,19728]
===
match
---
name: session [67846,67853]
name: session [68349,68356]
===
match
---
name: try_number [24797,24807]
name: try_number [24797,24807]
===
match
---
trailer [77027,77029]
trailer [77530,77532]
===
match
---
atom_expr [27814,27839]
atom_expr [27814,27839]
===
match
---
expr_stmt [38150,38189]
expr_stmt [38653,38692]
===
match
---
argument [60748,60768]
argument [61251,61271]
===
match
---
name: self [44219,44223]
name: self [44722,44726]
===
match
---
if_stmt [43545,44140]
if_stmt [44048,44643]
===
match
---
name: filter_for_tis [45568,45582]
name: filter_for_tis [46071,46085]
===
match
---
arglist [49277,49671]
arglist [49780,50174]
===
match
---
atom_expr [10004,10024]
atom_expr [10004,10024]
===
match
---
name: close [8532,8537]
name: close [8532,8537]
===
match
---
atom_expr [49812,49870]
atom_expr [50315,50373]
===
match
---
name: self [9080,9084]
name: self [9080,9084]
===
match
---
arglist [26717,26747]
arglist [26717,26747]
===
match
---
name: add [22279,22282]
name: add [22279,22282]
===
match
---
suite [34210,34490]
suite [34713,34993]
===
match
---
name: dag_id [73255,73261]
name: dag_id [73758,73764]
===
match
---
name: TI [3078,3080]
name: TI [3078,3080]
===
match
---
atom_expr [41430,41471]
atom_expr [41933,41974]
===
match
---
name: task_instances [40915,40929]
name: task_instances [41418,41432]
===
match
---
testlist_star_expr [51132,51140]
testlist_star_expr [51635,51643]
===
match
---
name: num_starving_tasks [41359,41377]
name: num_starving_tasks [41862,41880]
===
match
---
atom_expr [13735,13760]
atom_expr [13735,13760]
===
match
---
atom_expr [17146,17163]
atom_expr [17146,17163]
===
match
---
trailer [43506,43523]
trailer [44009,44026]
===
match
---
operator: = [81273,81274]
operator: = [81776,81777]
===
match
---
except_clause [66270,66298]
except_clause [66773,66801]
===
match
---
name: join [38533,38537]
name: join [39036,39040]
===
match
---
string: """         Bulk update the next_dagrun and next_dagrun_create_after for all the dags.          We batch the select queries to get info about all the dags at once         """ [70652,70826]
string: """         Bulk update the next_dagrun and next_dagrun_create_after for all the dags.          We batch the select queries to get info about all the dags at once         """ [71155,71329]
===
match
---
tfpdef [32794,32808]
tfpdef [33297,33311]
===
match
---
trailer [10686,10700]
trailer [10686,10700]
===
match
---
simple_stmt [14007,14027]
simple_stmt [14007,14027]
===
match
---
trailer [13289,13300]
trailer [13289,13300]
===
match
---
arglist [59725,59879]
arglist [60228,60382]
===
match
---
string: '*' [71065,71068]
string: '*' [71568,71571]
===
match
---
atom_expr [53663,53677]
atom_expr [54166,54180]
===
match
---
string: "Skipping SLA check for %s because no tasks in DAG have SLAs" [15933,15994]
string: "Skipping SLA check for %s because no tasks in DAG have SLAs" [15933,15994]
===
match
---
name: _parent_channel [12496,12511]
name: _parent_channel [12496,12511]
===
match
---
name: pool_name [38724,38733]
name: pool_name [39227,39236]
===
match
---
atom_expr [57810,57985]
atom_expr [58313,58488]
===
match
---
operator: , [8995,8996]
operator: , [8995,8996]
===
match
---
trailer [11060,11095]
trailer [11060,11095]
===
match
---
suite [11392,11465]
suite [11392,11465]
===
match
---
atom_expr [45029,45096]
atom_expr [45532,45599]
===
match
---
name: datetime [72605,72613]
name: datetime [73108,73116]
===
match
---
operator: , [15196,15197]
operator: , [15196,15197]
===
match
---
trailer [16722,16729]
trailer [16722,16729]
===
match
---
tfpdef [56210,56227]
tfpdef [56713,56730]
===
match
---
operator: = [17436,17437]
operator: = [17436,17437]
===
match
---
name: self [55077,55081]
name: self [55580,55584]
===
match
---
name: next_dagrun_create_after [72394,72418]
name: next_dagrun_create_after [72897,72921]
===
match
---
trailer [52958,52990]
trailer [53461,53493]
===
match
---
string: """         After the process is finished, this can be called to get the return code          :return: the exit code of the process         :rtype: int         """ [11563,11726]
string: """         After the process is finished, this can be called to get the return code          :return: the exit code of the process         :rtype: int         """ [11563,11726]
===
match
---
atom_expr [78090,78161]
atom_expr [78593,78664]
===
match
---
name: filter [17668,17674]
name: filter [17668,17674]
===
match
---
atom_expr [50859,50893]
atom_expr [51362,51396]
===
match
---
trailer [60675,60685]
trailer [61178,61188]
===
match
---
atom_expr [15866,15872]
atom_expr [15866,15872]
===
match
---
name: self [74564,74568]
name: self [75067,75071]
===
match
---
name: dm [68311,68313]
name: dm [68814,68816]
===
match
---
name: execution_date [16625,16639]
name: execution_date [16625,16639]
===
match
---
name: send_sla_callback_request_to_execute [77699,77735]
name: send_sla_callback_request_to_execute [78202,78238]
===
match
---
atom_expr [49837,49869]
atom_expr [50340,50372]
===
match
---
operator: = [38158,38159]
operator: = [38661,38662]
===
match
---
param [25231,25272]
param [25231,25272]
===
match
---
atom_expr [31379,31397]
atom_expr [31756,31774]
===
match
---
subscriptlist [36479,36492]
subscriptlist [36982,36995]
===
match
---
trailer [33939,33946]
trailer [34442,34449]
===
match
---
name: str [29388,29391]
name: str [29642,29645]
===
match
---
atom_expr [57192,57237]
atom_expr [57695,57740]
===
match
---
trailer [74147,74203]
trailer [74650,74706]
===
match
---
param [32810,32833]
param [33313,33336]
===
match
---
trailer [38653,38661]
trailer [39156,39164]
===
match
---
arglist [78102,78160]
arglist [78605,78663]
===
match
---
expr_stmt [52438,52468]
expr_stmt [52941,52971]
===
match
---
name: dag_id [76618,76624]
name: dag_id [77121,77127]
===
match
---
atom [73296,73449]
atom [73799,73952]
===
match
---
atom [36943,36960]
atom [37446,37463]
===
match
---
simple_stmt [12715,12727]
simple_stmt [12715,12727]
===
match
---
simple_stmt [55715,55775]
simple_stmt [56218,56278]
===
match
---
param [29655,29682]
param [29909,29936]
===
match
---
name: session [65469,65476]
name: session [65972,65979]
===
match
---
operator: = [58946,58947]
operator: = [59449,59450]
===
match
---
name: _child_channel [9538,9552]
name: _child_channel [9538,9552]
===
match
---
simple_stmt [1434,1493]
simple_stmt [1434,1493]
===
match
---
trailer [58839,58841]
trailer [59342,59344]
===
match
---
operator: , [74193,74194]
operator: , [74696,74697]
===
match
---
name: dag_id [42157,42163]
name: dag_id [42660,42666]
===
match
---
name: self [34193,34197]
name: self [34696,34700]
===
match
---
with_stmt [10528,10650]
with_stmt [10528,10650]
===
match
---
simple_stmt [27789,27840]
simple_stmt [27789,27840]
===
match
---
operator: - [49589,49590]
operator: - [50092,50093]
===
match
---
atom_expr [52485,52544]
atom_expr [52988,53047]
===
match
---
operator: += [4992,4994]
operator: += [4992,4994]
===
match
---
name: dag_id [73598,73604]
name: dag_id [74101,74107]
===
match
---
name: session [49940,49947]
name: session [50443,50450]
===
match
---
atom_expr [45354,45361]
atom_expr [45857,45864]
===
match
---
arglist [26833,26893]
arglist [26833,26893]
===
match
---
name: start [58029,58034]
name: start [58532,58537]
===
match
---
param [31425,31432]
param [31802,31809]
===
match
---
atom_expr [17711,17725]
atom_expr [17711,17725]
===
match
---
operator: = [46941,46942]
operator: = [47444,47445]
===
match
---
simple_stmt [73891,73920]
simple_stmt [74394,74423]
===
match
---
operator: , [26741,26742]
operator: , [26741,26742]
===
match
---
param [5284,5313]
param [5284,5313]
===
match
---
name: orm [1399,1402]
name: orm [1399,1402]
===
match
---
name: session [38381,38388]
name: session [38884,38891]
===
match
---
simple_stmt [39364,39418]
simple_stmt [39867,39921]
===
match
---
name: priority_sorted_task_instances [41742,41772]
name: priority_sorted_task_instances [42245,42275]
===
match
---
atom_expr [54561,54581]
atom_expr [55064,55084]
===
match
---
trailer [75233,75256]
trailer [75736,75759]
===
match
---
atom_expr [45873,45890]
atom_expr [46376,46393]
===
match
---
operator: , [76469,76470]
operator: , [76972,76973]
===
match
---
name: task [17012,17016]
name: task [17012,17016]
===
match
---
simple_stmt [20658,20735]
simple_stmt [20658,20735]
===
match
---
atom_expr [45395,45481]
atom_expr [45898,45984]
===
match
---
suite [35560,35865]
suite [36063,36368]
===
match
---
name: session [48720,48727]
name: session [49223,49230]
===
match
---
string: "Tried to get the result before it's done!" [13954,13997]
string: "Tried to get the result before it's done!" [13954,13997]
===
match
---
suite [58038,60257]
suite [58541,60760]
===
match
---
name: log [26824,26827]
name: log [26824,26827]
===
match
---
trailer [38861,38866]
trailer [39364,39369]
===
match
---
name: state [16264,16269]
name: state [16264,16269]
===
match
---
expr_stmt [69995,70059]
expr_stmt [70498,70562]
===
match
---
trailer [78991,78995]
trailer [79494,79498]
===
match
---
simple_stmt [78090,78178]
simple_stmt [78593,78681]
===
match
---
name: SerializedDagNotFound [65205,65226]
name: SerializedDagNotFound [65708,65729]
===
match
---
operator: = [12489,12490]
operator: = [12489,12490]
===
match
---
name: execution_date [68053,68067]
name: execution_date [68556,68570]
===
match
---
name: getint [32455,32461]
name: getint [32958,32964]
===
match
---
name: task [16846,16850]
name: task [16846,16850]
===
match
---
simple_stmt [50677,50711]
simple_stmt [51180,51214]
===
match
---
name: max [16080,16083]
name: max [16080,16083]
===
match
---
trailer [71303,71309]
trailer [71806,71812]
===
match
---
simple_stmt [54844,54877]
simple_stmt [55347,55380]
===
match
---
name: name [9219,9223]
name: name [9219,9223]
===
match
---
name: dag_concurrency_map [40121,40140]
name: dag_concurrency_map [40624,40643]
===
match
---
trailer [81001,81016]
trailer [81504,81519]
===
match
---
name: not_ [38572,38576]
name: not_ [39075,39079]
===
match
---
atom_expr [35042,35070]
atom_expr [35545,35573]
===
match
---
trailer [38576,38590]
trailer [39079,39093]
===
match
---
name: session [68403,68410]
name: session [68906,68913]
===
match
---
operator: , [54065,54066]
operator: , [54568,54569]
===
match
---
name: using_mysql [34198,34209]
name: using_mysql [34701,34712]
===
match
---
simple_stmt [48579,48648]
simple_stmt [49082,49151]
===
match
---
name: TI [46154,46156]
name: TI [46657,46659]
===
match
---
tfpdef [5182,5223]
tfpdef [5182,5223]
===
match
---
string: "but there are %s open slots in the pool %s." [44329,44374]
string: "but there are %s open slots in the pool %s." [44832,44877]
===
match
---
atom_expr [58745,58791]
atom_expr [59248,59294]
===
match
---
atom_expr [57645,57800]
atom_expr [58148,58303]
===
match
---
operator: , [57624,57625]
operator: , [58127,58128]
===
match
---
number: 1 [29515,29516]
number: 1 [29769,29770]
===
match
---
name: State [16273,16278]
name: State [16273,16278]
===
match
---
name: set [63959,63962]
name: set [64462,64465]
===
match
---
operator: = [81580,81581]
operator: = [82083,82084]
===
match
---
arglist [68598,68631]
arglist [69101,69134]
===
match
---
atom_expr [22091,22118]
atom_expr [22091,22118]
===
match
---
expr_stmt [76584,76657]
expr_stmt [77087,77160]
===
match
---
atom_expr [53253,53341]
atom_expr [53756,53844]
===
match
---
operator: + [18694,18695]
operator: + [18694,18695]
===
match
---
atom_expr [31864,31879]
atom_expr [32367,32382]
===
match
---
name: callback_to_execute [74217,74236]
name: callback_to_execute [74720,74739]
===
match
---
dotted_name [1498,1512]
dotted_name [1498,1512]
===
match
---
trailer [63958,63963]
trailer [64461,64466]
===
match
---
name: gauge [45112,45117]
name: gauge [45615,45620]
===
match
---
simple_stmt [36853,36885]
simple_stmt [37356,37388]
===
match
---
dotted_name [1949,1978]
dotted_name [1949,1978]
===
match
---
trailer [50378,50397]
trailer [50881,50900]
===
match
---
name: _enqueue_task_instances_with_queued_state [46085,46126]
name: _enqueue_task_instances_with_queued_state [46588,46629]
===
match
---
trailer [51561,51576]
trailer [52064,52079]
===
match
---
name: state [49649,49654]
name: state [50152,50157]
===
match
---
name: result [8042,8048]
name: result [8042,8048]
===
match
---
atom_expr [43708,43729]
atom_expr [44211,44232]
===
match
---
name: commit [66658,66664]
name: commit [67161,67167]
===
match
---
name: provide_session [22435,22450]
name: provide_session [22435,22450]
===
match
---
suite [3255,14427]
suite [3255,14427]
===
match
---
name: log [20974,20977]
name: log [20974,20977]
===
match
---
trailer [8660,8694]
trailer [8660,8694]
===
match
---
param [31080,31085]
param [31334,31339]
===
match
---
operator: == [16546,16548]
operator: == [16546,16548]
===
match
---
trailer [50150,50157]
trailer [50653,50660]
===
match
---
argument [50439,50479]
argument [50942,50982]
===
match
---
string: "Tried to see if it's done before starting!" [12308,12352]
string: "Tried to see if it's done before starting!" [12308,12352]
===
match
---
operator: , [23126,23127]
operator: , [23126,23127]
===
match
---
suite [55456,55567]
suite [55959,56070]
===
match
---
trailer [35173,35194]
trailer [35676,35697]
===
match
---
simple_stmt [40665,40682]
simple_stmt [41168,41185]
===
match
---
trailer [75556,75569]
trailer [76059,76072]
===
match
---
decorator [78422,78439]
decorator [78925,78942]
===
match
---
argument [34326,34341]
argument [34829,34844]
===
match
---
name: SimpleTaskInstance [2045,2063]
name: SimpleTaskInstance [2045,2063]
===
match
---
operator: , [25306,25307]
operator: , [25306,25307]
===
match
---
atom_expr [31388,31396]
atom_expr [31765,31773]
===
match
---
arglist [75570,75610]
arglist [76073,76113]
===
match
---
name: e [66393,66394]
name: e [66896,66897]
===
match
---
simple_stmt [13135,13153]
simple_stmt [13135,13153]
===
match
---
operator: , [57576,57577]
operator: , [58079,58080]
===
match
---
name: max_tis [38164,38171]
name: max_tis [38667,38674]
===
match
---
trailer [8742,8756]
trailer [8742,8756]
===
match
---
if_stmt [38803,38888]
if_stmt [39306,39391]
===
match
---
name: log [31803,31806]
name: log [32306,32309]
===
match
---
dotted_name [2218,2249]
dotted_name [2218,2249]
===
match
---
expr_stmt [81425,81447]
expr_stmt [81928,81950]
===
match
---
if_stmt [81988,82315]
if_stmt [82491,82818]
===
match
---
argument [30696,30718]
argument [30950,30972]
===
match
---
trailer [38537,38551]
trailer [39040,39054]
===
match
---
trailer [30361,30389]
trailer [30615,30643]
===
match
---
name: ti_key [51523,51529]
name: ti_key [52026,52032]
===
match
---
name: session [18024,18031]
name: session [18024,18031]
===
match
---
name: states [36598,36604]
name: states [37101,37107]
===
match
---
atom_expr [72463,72484]
atom_expr [72966,72987]
===
match
---
trailer [66857,66881]
trailer [67360,67384]
===
match
---
atom_expr [7552,7583]
atom_expr [7552,7583]
===
match
---
atom_expr [17012,17023]
atom_expr [17012,17023]
===
match
---
trailer [7130,7135]
trailer [7130,7135]
===
match
---
atom_expr [68432,68453]
atom_expr [68935,68956]
===
match
---
name: int [36008,36011]
name: int [36511,36514]
===
match
---
string: """Runs DAG processing in a separate process using DagFileProcessor      :param file_path: a Python file containing Airflow DAG definitions     :type file_path: str     :param pickle_dags: whether to serialize the DAG objects to the DB     :type pickle_dags: bool     :param dag_ids: If specified, only look at these DAG ID's     :type dag_ids: List[str]     :param callback_requests: failure callback to execute     :type callback_requests: List[airflow.utils.callback_requests.CallbackRequest]     """ [3260,3763]
string: """Runs DAG processing in a separate process using DagFileProcessor      :param file_path: a Python file containing Airflow DAG definitions     :type file_path: str     :param pickle_dags: whether to serialize the DAG objects to the DB     :type pickle_dags: bool     :param dag_ids: If specified, only look at these DAG ID's     :type dag_ids: List[str]     :param callback_requests: failure callback to execute     :type callback_requests: List[airflow.utils.callback_requests.CallbackRequest]     """ [3260,3763]
===
match
---
if_stmt [40694,40840]
if_stmt [41197,41343]
===
match
---
trailer [11074,11078]
trailer [11074,11078]
===
match
---
trailer [57202,57237]
trailer [57705,57740]
===
match
---
name: dag_id [43700,43706]
name: dag_id [44203,44209]
===
match
---
arglist [54236,54524]
arglist [54739,55027]
===
match
---
name: query [63977,63982]
name: query [64480,64485]
===
match
---
funcdef [56485,60257]
funcdef [56988,60760]
===
match
---
name: isinstance [23369,23379]
name: isinstance [23369,23379]
===
match
---
atom_expr [44219,44552]
atom_expr [44722,45055]
===
match
---
trailer [16790,16802]
trailer [16790,16802]
===
match
---
trailer [55477,55487]
trailer [55980,55990]
===
match
---
trailer [21323,21328]
trailer [21323,21328]
===
match
---
trailer [8807,8812]
trailer [8807,8812]
===
match
---
suite [10352,10432]
suite [10352,10432]
===
match
---
name: query [34523,34528]
name: query [35026,35031]
===
match
---
name: schedule_delay [70120,70134]
name: schedule_delay [70623,70637]
===
match
---
operator: = [53072,53073]
operator: = [53575,53576]
===
match
---
trailer [26925,26929]
trailer [26925,26929]
===
match
---
expr_stmt [68572,68632]
expr_stmt [69075,69135]
===
match
---
arith_expr [18674,18725]
arith_expr [18674,18725]
===
match
---
trailer [38394,38398]
trailer [38897,38901]
===
match
---
operator: , [40601,40602]
operator: , [41104,41105]
===
match
---
simple_stmt [50348,50398]
simple_stmt [50851,50901]
===
match
---
name: pool_name [77962,77971]
name: pool_name [78465,78474]
===
match
---
param [72633,72650]
param [73136,73153]
===
match
---
operator: , [34293,34294]
operator: , [34796,34797]
===
match
---
name: task_instance_str [82025,82042]
name: task_instance_str [82528,82545]
===
match
---
name: count [36916,36921]
name: count [37419,37424]
===
match
---
trailer [43420,43429]
trailer [43923,43932]
===
match
---
operator: == [16222,16224]
operator: == [16222,16224]
===
match
---
trailer [58749,58774]
trailer [59252,59277]
===
match
---
operator: , [56162,56163]
operator: , [56665,56666]
===
match
---
name: models [33659,33665]
name: models [34162,34168]
===
match
---
trailer [49840,49869]
trailer [50343,50372]
===
match
---
name: len [82641,82644]
name: len [83144,83147]
===
match
---
name: keys [49776,49780]
name: keys [50279,50283]
===
match
---
name: append [51756,51762]
name: append [52259,52265]
===
match
---
atom_expr [41529,41619]
atom_expr [42032,42122]
===
match
---
suite [81718,81773]
suite [82221,82276]
===
match
---
name: session [16481,16488]
name: session [16481,16488]
===
match
---
name: execution_date [64479,64493]
name: execution_date [64982,64996]
===
match
---
expr_stmt [9322,9358]
expr_stmt [9322,9358]
===
match
---
arglist [80561,80627]
arglist [81064,81130]
===
match
---
operator: -> [11537,11539]
operator: -> [11537,11539]
===
match
---
trailer [18537,18542]
trailer [18537,18542]
===
match
---
tfpdef [3966,3994]
tfpdef [3966,3994]
===
match
---
operator: } [70267,70268]
operator: } [70770,70771]
===
match
---
operator: , [25271,25272]
operator: , [25271,25272]
===
match
---
arglist [44258,44530]
arglist [44761,45033]
===
match
---
import_from [2213,2354]
import_from [2213,2354]
===
match
---
simple_stmt [2885,2996]
simple_stmt [2885,2996]
===
match
---
name: all [81305,81308]
name: all [81808,81811]
===
match
---
if_stmt [52583,53449]
if_stmt [53086,53952]
===
match
---
atom_expr [17102,17119]
atom_expr [17102,17119]
===
match
---
name: signal [31006,31012]
name: signal [31260,31266]
===
match
---
name: slas [17964,17968]
name: slas [17964,17968]
===
match
---
name: processor_agent [31349,31364]
name: processor_agent [31726,31741]
===
match
---
name: create_session [58519,58533]
name: create_session [59022,59036]
===
match
---
trailer [54848,54864]
trailer [55351,55367]
===
match
---
name: file_path [26974,26983]
name: file_path [26974,26983]
===
match
---
trailer [59081,59087]
trailer [59584,59590]
===
match
---
param [9788,9792]
param [9788,9792]
===
match
---
operator: = [79358,79359]
operator: = [79861,79862]
===
match
---
simple_stmt [36446,36668]
simple_stmt [36949,37171]
===
match
---
trailer [35378,35391]
trailer [35881,35894]
===
match
---
trailer [35416,35431]
trailer [35919,35934]
===
match
---
simple_stmt [55913,55986]
simple_stmt [56416,56489]
===
match
---
trailer [30357,30361]
trailer [30611,30615]
===
match
---
name: manage_slas [23303,23314]
name: manage_slas [23303,23314]
===
match
---
trailer [22083,22090]
trailer [22083,22090]
===
match
---
operator: , [31070,31071]
operator: , [31324,31325]
===
match
---
atom_expr [52586,52599]
atom_expr [53089,53102]
===
match
---
trailer [45888,45890]
trailer [46391,46393]
===
match
---
name: provide_session [60263,60278]
name: provide_session [60766,60781]
===
match
---
expr_stmt [18201,18228]
expr_stmt [18201,18228]
===
match
---
funcdef [29344,30765]
funcdef [29598,31019]
===
match
---
atom_expr [23331,23345]
atom_expr [23331,23345]
===
match
---
name: schedulable_tis [75514,75529]
name: schedulable_tis [76017,76032]
===
match
---
name: self [15234,15238]
name: self [15234,15238]
===
match
---
trailer [44452,44463]
trailer [44955,44966]
===
match
---
operator: == [16588,16590]
operator: == [16588,16590]
===
match
---
param [32765,32770]
param [33268,33273]
===
match
---
name: _process [11066,11074]
name: _process [11066,11074]
===
match
---
string: "Starting the scheduler" [53538,53562]
string: "Starting the scheduler" [54041,54065]
===
match
---
argument [50245,50270]
argument [50748,50773]
===
match
---
name: ti_deps [2126,2133]
name: ti_deps [2126,2133]
===
match
---
operator: , [23854,23855]
operator: , [23854,23855]
===
match
---
trailer [45917,45920]
trailer [46420,46423]
===
match
---
atom_expr [25065,25140]
atom_expr [25065,25140]
===
match
---
operator: , [70615,70616]
operator: , [71118,71119]
===
match
---
trailer [82596,82598]
trailer [83099,83101]
===
match
---
operator: = [58583,58584]
operator: = [59086,59087]
===
match
---
trailer [12690,12696]
trailer [12690,12696]
===
match
---
name: info [78751,78755]
name: info [79254,79258]
===
match
---
name: pool [40677,40681]
name: pool [41180,41184]
===
match
---
operator: = [51296,51297]
operator: = [51799,51800]
===
match
---
atom_expr [16212,16221]
atom_expr [16212,16221]
===
match
---
name: taskinstance [2025,2037]
name: taskinstance [2025,2037]
===
match
---
name: utils [2588,2593]
name: utils [2588,2593]
===
match
---
name: Session [78492,78499]
name: Session [78995,79002]
===
match
---
trailer [38018,38020]
trailer [38521,38523]
===
match
---
operator: == [49287,49289]
operator: == [49790,49792]
===
match
---
name: Session [35961,35968]
name: Session [36464,36471]
===
match
---
atom_expr [22012,22036]
atom_expr [22012,22036]
===
match
---
atom_expr [60581,60824]
atom_expr [61084,61327]
===
match
---
name: dagbag [27651,27657]
name: dagbag [27651,27657]
===
match
---
fstring_end: " [17039,17040]
fstring_end: " [17039,17040]
===
match
---
name: active_runs_of_dag [71863,71881]
name: active_runs_of_dag [72366,72384]
===
match
---
operator: , [45290,45291]
operator: , [45793,45794]
===
match
---
trailer [71348,71363]
trailer [71851,71866]
===
match
---
atom_expr [18452,18470]
atom_expr [18452,18470]
===
match
---
suite [8347,8540]
suite [8347,8540]
===
match
---
name: execution_date [73677,73691]
name: execution_date [74180,74194]
===
match
---
suite [43052,44140]
suite [43555,44643]
===
match
---
name: Exception [55854,55863]
name: Exception [56357,56366]
===
match
---
name: _try_number [49563,49574]
name: _try_number [50066,50077]
===
match
---
atom_expr [40091,40106]
atom_expr [40594,40609]
===
match
---
expr_stmt [77901,77949]
expr_stmt [78404,78452]
===
match
---
simple_stmt [55357,55399]
simple_stmt [55860,55902]
===
match
---
name: TI [80104,80106]
name: TI [80607,80609]
===
match
---
name: airflow [1698,1705]
name: airflow [1698,1705]
===
match
---
trailer [17001,17005]
trailer [17001,17005]
===
match
---
name: notification_sent [20793,20810]
name: notification_sent [20793,20810]
===
match
---
atom_expr [27066,27086]
atom_expr [27066,27086]
===
match
---
name: guard [61124,61129]
name: guard [61627,61632]
===
match
---
atom_expr [51704,51716]
atom_expr [52207,52219]
===
match
---
trailer [16594,16596]
trailer [16594,16596]
===
match
---
string: 'dag_file_processor_timeout' [54067,54095]
string: 'dag_file_processor_timeout' [54570,54598]
===
match
---
name: QUEUED [45849,45855]
name: QUEUED [46352,46358]
===
match
---
string: "Execution date is in future: %s" [74773,74806]
string: "Execution date is in future: %s" [75276,75309]
===
match
---
name: grace_multiplier [32247,32263]
name: grace_multiplier [32750,32766]
===
match
---
simple_stmt [66679,66701]
simple_stmt [67182,67204]
===
match
---
name: dag [73421,73424]
name: dag [73924,73927]
===
match
---
name: dag_id [19430,19436]
name: dag_id [19430,19436]
===
match
---
name: commit [18499,18505]
name: commit [18499,18505]
===
match
---
trailer [55723,55733]
trailer [56226,56236]
===
match
---
atom_expr [65313,65327]
atom_expr [65816,65830]
===
match
---
simple_stmt [82634,82655]
simple_stmt [83137,83158]
===
match
---
name: airflow [2010,2017]
name: airflow [2010,2017]
===
match
---
name: latest_heartbeat [32610,32626]
name: latest_heartbeat [33113,33129]
===
match
---
name: State [80007,80012]
name: State [80510,80515]
===
match
---
name: query [52022,52027]
name: query [52525,52530]
===
match
---
trailer [31811,31821]
trailer [32314,32324]
===
match
---
name: Stats [2107,2112]
name: Stats [2107,2112]
===
match
---
name: self [60976,60980]
name: self [61479,61483]
===
match
---
suite [31896,32689]
suite [32399,33192]
===
match
---
argument [54502,54523]
argument [55005,55026]
===
match
---
atom_expr [9130,9147]
atom_expr [9130,9147]
===
match
---
expr_stmt [4164,4187]
expr_stmt [4164,4187]
===
match
---
name: models [1875,1881]
name: models [1875,1881]
===
match
---
expr_stmt [8641,8696]
expr_stmt [8641,8696]
===
match
---
operator: = [38903,38904]
operator: = [39406,39407]
===
match
---
trailer [18594,18596]
trailer [18594,18596]
===
match
---
atom_expr [24492,24509]
atom_expr [24492,24509]
===
match
---
operator: = [75399,75400]
operator: = [75902,75903]
===
match
---
trailer [31534,31539]
trailer [32037,32042]
===
match
---
name: TI [80140,80142]
name: TI [80643,80645]
===
match
---
argument [66387,66394]
argument [66890,66897]
===
match
---
operator: , [76824,76825]
operator: , [77327,77328]
===
match
---
simple_stmt [24370,24406]
simple_stmt [24370,24406]
===
match
---
operator: = [19716,19717]
operator: = [19716,19717]
===
match
---
simple_stmt [44617,44647]
simple_stmt [45120,45150]
===
match
---
trailer [23929,23945]
trailer [23929,23945]
===
match
---
name: self [68578,68582]
name: self [69081,69085]
===
match
---
simple_stmt [81157,81311]
simple_stmt [81660,81814]
===
match
---
name: tis_to_reset_or_adopt [81157,81178]
name: tis_to_reset_or_adopt [81660,81681]
===
match
---
operator: = [24477,24478]
operator: = [24477,24478]
===
match
---
argument [59041,59055]
argument [59544,59558]
===
match
---
arglist [26938,26983]
arglist [26938,26983]
===
match
---
name: dag_id [72162,72168]
name: dag_id [72665,72671]
===
match
---
name: dagrun_timeout [73425,73439]
name: dagrun_timeout [73928,73942]
===
match
---
operator: , [1224,1225]
operator: , [1224,1225]
===
match
---
name: open_slots [41602,41612]
name: open_slots [42105,42115]
===
match
---
operator: = [68230,68231]
operator: = [68733,68734]
===
match
---
trailer [51304,51315]
trailer [51807,51818]
===
match
---
atom_expr [5302,5311]
atom_expr [5302,5311]
===
match
---
atom_expr [71630,71684]
atom_expr [72133,72187]
===
match
---
operator: } [79702,79703]
operator: } [80205,80206]
===
match
---
name: str [35946,35949]
name: str [36449,36452]
===
match
---
name: str [36767,36770]
name: str [37270,37273]
===
match
---
trailer [53414,53439]
trailer [53917,53942]
===
match
---
atom_expr [23315,23346]
atom_expr [23315,23346]
===
match
---
trailer [23771,23778]
trailer [23771,23778]
===
match
---
arglist [34429,34455]
arglist [34932,34958]
===
match
---
name: dag_run [74989,74996]
name: dag_run [75492,75499]
===
match
---
suite [78001,78280]
suite [78504,78783]
===
match
---
name: flush [35581,35586]
name: flush [36084,36089]
===
match
---
trailer [38853,38887]
trailer [39356,39390]
===
match
---
decorator [76040,76057]
decorator [76543,76560]
===
match
---
trailer [74568,74601]
trailer [75071,75104]
===
match
---
name: session [16049,16056]
name: session [16049,16056]
===
match
---
atom_expr [4124,4141]
atom_expr [4124,4141]
===
match
---
name: _get_next_dagruns_to_examine [66736,66764]
name: _get_next_dagruns_to_examine [67239,67267]
===
match
---
name: len [74919,74922]
name: len [75422,75425]
===
match
---
name: exception [55724,55733]
name: exception [56227,56236]
===
match
---
operator: = [18922,18923]
operator: = [18922,18923]
===
match
---
operator: = [69950,69951]
operator: = [70453,70454]
===
match
---
param [25193,25198]
param [25193,25198]
===
match
---
decorator [50580,50597]
decorator [51083,51100]
===
match
---
name: pool_name [78123,78132]
name: pool_name [78626,78635]
===
match
---
name: getint [29292,29298]
name: getint [29546,29552]
===
match
---
atom_expr [11884,11954]
atom_expr [11884,11954]
===
match
---
arglist [70232,70310]
arglist [70735,70813]
===
match
---
atom_expr [27796,27812]
atom_expr [27796,27812]
===
match
---
argument [24076,24090]
argument [24076,24090]
===
match
---
dotted_name [2118,2153]
dotted_name [2118,2153]
===
match
---
name: dispose_orm [8490,8501]
name: dispose_orm [8490,8501]
===
match
---
simple_stmt [45322,45387]
simple_stmt [45825,45890]
===
match
---
trailer [30434,30445]
trailer [30688,30699]
===
match
---
string: ' on ' [18557,18563]
string: ' on ' [18557,18563]
===
match
---
trailer [68313,68325]
trailer [68816,68828]
===
match
---
if_stmt [77089,77170]
if_stmt [77592,77673]
===
match
---
testlist_comp [68299,68347]
testlist_comp [68802,68850]
===
match
---
expr_stmt [29270,29338]
expr_stmt [29524,29592]
===
match
---
import_as_names [1309,1338]
import_as_names [1309,1338]
===
match
---
atom_expr [29761,29774]
atom_expr [30015,30028]
===
match
---
trailer [80563,80580]
trailer [81066,81083]
===
match
---
name: queue [47046,47051]
name: queue [47549,47554]
===
match
---
simple_stmt [825,841]
simple_stmt [825,841]
===
match
---
name: DagRun [68239,68245]
name: DagRun [68742,68748]
===
match
---
atom_expr [10371,10431]
atom_expr [10371,10431]
===
match
---
expr_stmt [37952,38022]
expr_stmt [38455,38525]
===
match
---
string: 'open' [38781,38787]
string: 'open' [39284,39290]
===
match
---
atom [54449,54451]
atom [54952,54954]
===
match
---
expr_stmt [47035,47051]
expr_stmt [47538,47554]
===
match
---
param [5257,5275]
param [5257,5275]
===
match
---
trailer [14018,14026]
trailer [14018,14026]
===
match
---
name: func [16075,16079]
name: func [16075,16079]
===
match
---
name: active_runs_by_dag_id [65123,65144]
name: active_runs_by_dag_id [65626,65647]
===
match
---
operator: } [19745,19746]
operator: } [19745,19746]
===
match
---
trailer [33684,33688]
trailer [34187,34191]
===
match
---
name: info [15928,15932]
name: info [15928,15932]
===
match
---
trailer [14417,14426]
trailer [14417,14426]
===
match
---
string: "DAG %s not changed structure, skipping dagrun.verify_integrity" [76405,76469]
string: "DAG %s not changed structure, skipping dagrun.verify_integrity" [76908,76972]
===
match
---
simple_stmt [841,858]
simple_stmt [841,858]
===
match
---
trailer [73676,73691]
trailer [74179,74194]
===
match
---
param [70617,70633]
param [71120,71136]
===
match
---
trailer [35990,36048]
trailer [36493,36551]
===
match
---
return_stmt [13683,13695]
return_stmt [13683,13695]
===
match
---
atom_expr [71884,71922]
atom_expr [72387,72425]
===
match
---
arglist [57701,57751]
arglist [58204,58254]
===
match
---
trailer [77134,77159]
trailer [77637,77662]
===
match
---
atom_expr [15275,15289]
atom_expr [15275,15289]
===
match
---
operator: == [16297,16299]
operator: == [16297,16299]
===
match
---
name: self [10961,10965]
name: self [10961,10965]
===
match
---
name: full_filepath [77749,77762]
name: full_filepath [78252,78265]
===
match
---
name: with_row_locks [34249,34263]
name: with_row_locks [34752,34766]
===
match
---
name: State [51689,51694]
name: State [52192,52197]
===
match
---
atom_expr [38006,38020]
atom_expr [38509,38523]
===
match
---
operator: @ [5080,5081]
operator: @ [5080,5081]
===
match
---
parameters [60312,60327]
parameters [60815,60830]
===
match
---
operator: = [7751,7752]
operator: = [7751,7752]
===
match
---
operator: = [4373,4374]
operator: = [4373,4374]
===
match
---
trailer [36518,36524]
trailer [37021,37027]
===
match
---
operator: = [73859,73860]
operator: = [74362,74363]
===
match
---
comparison [38612,38639]
comparison [39115,39142]
===
match
---
name: dag [27382,27385]
name: dag [27382,27385]
===
match
---
import_from [1804,1861]
import_from [1804,1861]
===
match
---
name: dag_id [18130,18136]
name: dag_id [18130,18136]
===
match
---
name: _run_file_processor [8892,8911]
name: _run_file_processor [8892,8911]
===
match
---
atom_expr [36934,36961]
atom_expr [37437,37464]
===
match
---
simple_stmt [50969,51018]
simple_stmt [51472,51521]
===
match
---
trailer [57514,57576]
trailer [58017,58079]
===
match
---
string: 'mssql' [67875,67882]
string: 'mssql' [68378,68385]
===
match
---
tfpdef [32810,32826]
tfpdef [33313,33329]
===
match
---
trailer [7578,7583]
trailer [7578,7583]
===
match
---
name: has_task_concurrency_limits [43024,43051]
name: has_task_concurrency_limits [43527,43554]
===
match
---
return_stmt [66679,66700]
return_stmt [67182,67203]
===
match
---
name: self [23170,23174]
name: self [23170,23174]
===
match
---
simple_stmt [54639,54663]
simple_stmt [55142,55166]
===
match
---
operator: ** [29706,29708]
operator: ** [29960,29962]
===
match
---
trailer [60414,60451]
trailer [60917,60954]
===
match
---
trailer [12577,12583]
trailer [12577,12583]
===
match
---
name: pool_name [45064,45073]
name: pool_name [45567,45576]
===
match
---
atom_expr [18983,19004]
atom_expr [18983,19004]
===
match
---
operator: , [16604,16605]
operator: , [16604,16605]
===
match
---
simple_stmt [76515,76549]
simple_stmt [77018,77052]
===
match
---
name: pool_name [78045,78054]
name: pool_name [78548,78557]
===
match
---
expr_stmt [34552,34584]
expr_stmt [35055,35087]
===
match
---
fstring_start: f" [9111,9113]
fstring_start: f" [9111,9113]
===
match
---
name: process_file [7831,7843]
name: process_file [7831,7843]
===
match
---
atom_expr [73401,73418]
atom_expr [73904,73921]
===
match
---
param [31840,31845]
param [32343,32348]
===
match
---
trailer [45117,45171]
trailer [45620,45674]
===
match
---
trailer [9380,9382]
trailer [9380,9382]
===
match
---
expr_stmt [24370,24405]
expr_stmt [24370,24405]
===
match
---
name: _instance_id [9135,9147]
name: _instance_id [9135,9147]
===
match
---
name: dag_id [23339,23345]
name: dag_id [23339,23345]
===
match
---
atom_expr [52603,52624]
atom_expr [53106,53127]
===
match
---
trailer [53204,53210]
trailer [53707,53713]
===
match
---
argument [17388,17404]
argument [17388,17404]
===
match
---
import_from [2662,2726]
import_from [2662,2726]
===
match
---
name: session [58539,58546]
name: session [59042,59049]
===
match
---
name: int [13750,13753]
name: int [13750,13753]
===
match
---
operator: , [54309,54310]
operator: , [54812,54813]
===
match
---
trailer [81769,81772]
trailer [82272,82275]
===
match
---
string: """         Finding all tasks that have SLAs defined, and sending alert emails         where needed. New SLA misses are also recorded in the database.          We are assuming that the scheduler runs often, so we only check for         tasks that should have succeeded in the past hour.         """ [15474,15772]
string: """         Finding all tasks that have SLAs defined, and sending alert emails         where needed. New SLA misses are also recorded in the database.          We are assuming that the scheduler runs often, so we only check for         tasks that should have succeeded in the past hour.         """ [15474,15772]
===
match
---
name: DagFileProcessorAgent [30636,30657]
name: DagFileProcessorAgent [30890,30911]
===
match
---
atom_expr [15824,15834]
atom_expr [15824,15834]
===
match
---
trailer [69499,69506]
trailer [70002,70009]
===
match
---
argument [17427,17439]
argument [17427,17439]
===
match
---
name: dag_run [65114,65121]
name: dag_run [65617,65624]
===
match
---
simple_stmt [59690,59898]
simple_stmt [60193,60401]
===
match
---
atom_expr [6496,6510]
atom_expr [6496,6510]
===
match
---
atom_expr [11141,11169]
atom_expr [11141,11169]
===
match
---
if_stmt [18280,18508]
if_stmt [18280,18508]
===
match
---
atom_expr [4477,4492]
atom_expr [4477,4492]
===
match
---
name: self [12633,12637]
name: self [12633,12637]
===
match
---
name: query [45639,45644]
name: query [46142,46147]
===
match
---
trailer [31767,31776]
trailer [32270,32279]
===
match
---
operator: = [53661,53662]
operator: = [54164,54165]
===
match
---
name: self [30052,30056]
name: self [30306,30310]
===
match
---
trailer [68454,68461]
trailer [68957,68964]
===
match
---
trailer [43260,43285]
trailer [43763,43788]
===
match
---
name: startswith [30492,30502]
name: startswith [30746,30756]
===
match
---
decorator [48841,48858]
decorator [49344,49361]
===
match
---
testlist_comp [44965,45008]
testlist_comp [45468,45511]
===
match
---
trailer [52498,52544]
trailer [53001,53047]
===
match
---
name: _process [11346,11354]
name: _process [11346,11354]
===
match
---
subscriptlist [36032,36040]
subscriptlist [36535,36543]
===
match
---
simple_stmt [13683,13696]
simple_stmt [13683,13696]
===
match
---
operator: , [21422,21423]
operator: , [21422,21423]
===
match
---
suite [66973,67285]
suite [67476,67788]
===
match
---
name: session [27642,27649]
name: session [27642,27649]
===
match
---
name: pickle_dags [3939,3950]
name: pickle_dags [3939,3950]
===
match
---
name: pickle_id [46955,46964]
name: pickle_id [47458,47467]
===
match
---
trailer [43252,43260]
trailer [43755,43763]
===
match
---
operator: , [15994,15995]
operator: , [15994,15995]
===
match
---
name: execute_start_time [55226,55244]
name: execute_start_time [55729,55747]
===
match
---
name: self [11341,11345]
name: self [11341,11345]
===
match
---
simple_stmt [66652,66667]
simple_stmt [67155,67170]
===
match
---
name: tis_changed [34473,34484]
name: tis_changed [34976,34987]
===
match
---
arglist [75392,75424]
arglist [75895,75927]
===
match
---
name: simple_ti [24273,24282]
name: simple_ti [24273,24282]
===
match
---
trailer [67968,68108]
trailer [68471,68611]
===
match
---
name: callback_requests [4004,4021]
name: callback_requests [4004,4021]
===
match
---
operator: @ [11998,11999]
operator: @ [11998,11999]
===
match
---
operator: , [53200,53201]
operator: , [53703,53704]
===
match
---
fstring [19466,19762]
fstring [19466,19762]
===
match
---
name: num_failed [79847,79857]
name: num_failed [80350,80360]
===
match
---
simple_stmt [27337,27471]
simple_stmt [27337,27471]
===
match
---
simple_stmt [8325,8331]
simple_stmt [8325,8331]
===
match
---
atom_expr [18140,18150]
atom_expr [18140,18150]
===
match
---
name: Optional [76853,76861]
name: Optional [77356,77364]
===
match
---
operator: , [57737,57738]
operator: , [58240,58241]
===
match
---
name: queue [47303,47308]
name: queue [47806,47811]
===
match
---
operator: } [50903,50904]
operator: } [51406,51407]
===
match
---
name: timeout [78812,78819]
name: timeout [79315,79322]
===
match
---
arglist [64335,64363]
arglist [64838,64866]
===
match
---
name: log [15786,15789]
name: log [15786,15789]
===
match
---
trailer [55380,55382]
trailer [55883,55885]
===
match
---
atom_expr [34632,34657]
atom_expr [35135,35160]
===
match
---
name: msg [25016,25019]
name: msg [25016,25019]
===
match
---
suite [24357,25141]
suite [24357,25141]
===
match
---
name: ts [16709,16711]
name: ts [16709,16711]
===
match
---
atom_expr [46894,46914]
atom_expr [47397,47417]
===
match
---
name: utcnow [54748,54754]
name: utcnow [55251,55257]
===
match
---
trailer [9356,9358]
trailer [9356,9358]
===
match
---
name: int [7800,7803]
name: int [7800,7803]
===
match
---
atom_expr [50427,50480]
atom_expr [50930,50983]
===
match
---
name: session [17321,17328]
name: session [17321,17328]
===
match
---
trailer [53266,53341]
trailer [53769,53844]
===
match
---
name: DagRun [33834,33840]
name: DagRun [34337,34343]
===
match
---
argument [60644,60726]
argument [61147,61229]
===
match
---
name: Session [15441,15448]
name: Session [15441,15448]
===
match
---
trailer [31787,31789]
trailer [32290,32292]
===
match
---
trailer [65696,65700]
trailer [66199,66203]
===
match
---
trailer [75076,75080]
trailer [75579,75583]
===
match
---
name: signum [31072,31078]
name: signum [31326,31332]
===
match
---
comparison [51665,51717]
comparison [52168,52220]
===
match
---
operator: , [7803,7804]
operator: , [7803,7804]
===
match
---
name: timers [57459,57465]
name: timers [57962,57968]
===
match
---
name: Set [20264,20267]
name: Set [20264,20267]
===
match
---
trailer [36593,36597]
trailer [37096,37100]
===
match
---
name: processor_agent [77683,77698]
name: processor_agent [78186,78201]
===
match
---
suite [43356,43524]
suite [43859,44027]
===
match
---
atom_expr [19700,19745]
atom_expr [19700,19745]
===
match
---
expr_stmt [36446,36667]
expr_stmt [36949,37170]
===
match
---
atom [35142,35531]
atom [35645,36034]
===
match
---
string: 'scheduler_health_check_threshold' [78847,78881]
string: 'scheduler_health_check_threshold' [79350,79384]
===
match
---
comparison [18127,18150]
comparison [18127,18150]
===
match
---
name: filter [79439,79445]
name: filter [79942,79948]
===
match
---
trailer [31005,31039]
trailer [31259,31293]
===
match
---
atom_expr [36511,36651]
atom_expr [37014,37154]
===
match
---
trailer [13953,13998]
trailer [13953,13998]
===
match
---
number: 1 [4995,4996]
number: 1 [4995,4996]
===
match
---
operator: = [71882,71883]
operator: = [72385,72386]
===
match
---
name: processor_agent [55082,55097]
name: processor_agent [55585,55600]
===
match
---
expr_stmt [39506,39581]
expr_stmt [40009,40084]
===
match
---
name: State [34873,34878]
name: State [35376,35381]
===
match
---
simple_stmt [41722,41790]
simple_stmt [42225,42293]
===
match
---
atom [32526,32688]
atom [33029,33191]
===
match
---
funcdef [60283,61139]
funcdef [60786,61642]
===
match
---
trailer [54351,54378]
trailer [54854,54881]
===
match
---
trailer [30214,30216]
trailer [30468,30470]
===
match
---
return_stmt [14397,14426]
return_stmt [14397,14426]
===
match
---
for_stmt [57995,60257]
for_stmt [58498,60760]
===
match
---
name: dag_model [72361,72370]
name: dag_model [72864,72873]
===
match
---
name: filename [22319,22327]
name: filename [22319,22327]
===
match
---
name: self [10711,10715]
name: self [10711,10715]
===
match
---
name: done [13913,13917]
name: done [13913,13917]
===
match
---
trailer [19887,19900]
trailer [19887,19900]
===
match
---
operator: = [50900,50901]
operator: = [51403,51404]
===
match
---
name: executor [31768,31776]
name: executor [32271,32279]
===
match
---
name: error [60946,60951]
name: error [61449,61454]
===
match
---
import_name [931,947]
import_name [931,947]
===
match
---
name: Optional [56181,56189]
name: Optional [56684,56692]
===
match
---
trailer [25073,25078]
trailer [25073,25078]
===
match
---
atom_expr [73861,73874]
atom_expr [74364,74377]
===
match
---
name: self [65091,65095]
name: self [65594,65598]
===
match
---
trailer [79898,79908]
trailer [80401,80411]
===
match
---
trailer [11379,11383]
trailer [11379,11383]
===
match
---
arglist [49930,49955]
arglist [50433,50458]
===
match
---
name: self [4088,4092]
name: self [4088,4092]
===
match
---
name: session [39082,39089]
name: session [39585,39592]
===
match
---
atom_expr [17675,17700]
atom_expr [17675,17700]
===
match
---
name: self [54770,54774]
name: self [55273,55277]
===
match
---
name: TI [16336,16338]
name: TI [16336,16338]
===
match
---
name: task_id [49710,49717]
name: task_id [50213,50220]
===
match
---
name: simple_ti [24421,24430]
name: simple_ti [24421,24430]
===
match
---
trailer [11111,11127]
trailer [11111,11127]
===
match
---
fstring_string:  in  [17007,17011]
fstring_string:  in  [17007,17011]
===
match
---
trailer [17606,17615]
trailer [17606,17615]
===
match
---
atom_expr [13498,13508]
atom_expr [13498,13508]
===
match
---
simple_stmt [19776,19798]
simple_stmt [19776,19798]
===
match
---
name: conf [54047,54051]
name: conf [54550,54554]
===
match
---
trailer [32461,32510]
trailer [32964,33013]
===
match
---
operator: { [9129,9130]
operator: { [9129,9130]
===
match
---
name: _popen [10583,10589]
name: _popen [10583,10589]
===
match
---
number: 1 [26743,26744]
number: 1 [26743,26744]
===
match
---
atom_expr [45585,45618]
atom_expr [46088,46121]
===
match
---
trailer [45655,45671]
trailer [46158,46174]
===
match
---
trailer [42573,42889]
trailer [43076,43392]
===
match
---
string: 'scheduler.tasks.without_dagrun' [35818,35850]
string: 'scheduler.tasks.without_dagrun' [36321,36353]
===
match
---
simple_stmt [34552,34585]
simple_stmt [35055,35088]
===
match
---
name: dag_model [43014,43023]
name: dag_model [43517,43526]
===
match
---
name: conf [30551,30555]
name: conf [30805,30809]
===
match
---
name: defaultdict [36709,36720]
name: defaultdict [37212,37223]
===
match
---
trailer [73852,73858]
trailer [74355,74361]
===
match
---
operator: , [81233,81234]
operator: , [81736,81737]
===
match
---
suite [34888,35115]
suite [35391,35618]
===
match
---
decorated [60262,61139]
decorated [60765,61642]
===
match
---
trailer [42270,42470]
trailer [42773,42973]
===
match
---
name: execution_date [49356,49370]
name: execution_date [49859,49873]
===
match
---
name: start_date [73318,73328]
name: start_date [73821,73831]
===
match
---
trailer [15316,15318]
trailer [15316,15318]
===
match
---
name: Exception [8148,8157]
name: Exception [8148,8157]
===
match
---
trailer [20278,20280]
trailer [20278,20280]
===
match
---
atom_expr [31512,31539]
atom_expr [32015,32042]
===
match
---
trailer [12439,12441]
trailer [12439,12441]
===
match
---
name: len [40911,40914]
name: len [41414,41417]
===
match
---
atom_expr [18078,18091]
atom_expr [18078,18091]
===
match
---
arglist [45118,45170]
arglist [45621,45673]
===
match
---
arglist [41260,41331]
arglist [41763,41834]
===
match
---
trailer [71339,71348]
trailer [71842,71851]
===
match
---
name: self [75621,75625]
name: self [76124,76128]
===
match
---
name: exit [31383,31387]
name: exit [31760,31764]
===
match
---
atom_expr [79573,79590]
atom_expr [80076,80093]
===
match
---
arglist [57687,57790]
arglist [58190,58293]
===
match
---
trailer [47068,47072]
trailer [47571,47575]
===
match
---
name: email [20587,20592]
name: email [20587,20592]
===
match
---
name: __name__ [79909,79917]
name: __name__ [80412,80420]
===
match
---
fstring [20677,20718]
fstring [20677,20718]
===
match
---
atom [51674,51717]
atom [52177,52220]
===
match
---
import_from [1172,1246]
import_from [1172,1246]
===
match
---
name: self [53682,53686]
name: self [54185,54189]
===
match
---
suite [50747,50812]
suite [51250,51315]
===
match
---
name: task_instance [44058,44071]
name: task_instance [44561,44574]
===
match
---
atom_expr [59577,59623]
atom_expr [60080,60126]
===
match
---
arglist [6851,6865]
arglist [6851,6865]
===
match
---
trailer [74176,74192]
trailer [74679,74695]
===
match
---
name: airflow [2890,2897]
name: airflow [2890,2897]
===
match
---
trailer [16412,16421]
trailer [16412,16421]
===
match
---
atom_expr [35174,35193]
atom_expr [35677,35696]
===
match
---
operator: , [60726,60727]
operator: , [61229,61230]
===
match
---
operator: = [24833,24834]
operator: = [24833,24834]
===
match
---
name: to_reset [81708,81716]
name: to_reset [82211,82219]
===
match
---
string: "Processing each file at most %s times" [53755,53794]
string: "Processing each file at most %s times" [54258,54297]
===
match
---
atom_expr [71808,71824]
atom_expr [72311,72327]
===
match
---
string: "task says its %s. (Info: %s) Was the task killed externally?" [52847,52909]
string: "task says its %s. (Info: %s) Was the task killed externally?" [53350,53412]
===
match
---
operator: , [40042,40043]
operator: , [40545,40546]
===
match
---
arglist [34281,34342]
arglist [34784,34845]
===
match
---
param [22486,22491]
param [22486,22491]
===
match
---
name: CallbackRequest [5372,5387]
name: CallbackRequest [5372,5387]
===
match
---
annassign [39722,39779]
annassign [40225,40282]
===
match
---
name: do_pickle [29622,29631]
name: do_pickle [29876,29885]
===
match
---
name: log [6491,6494]
name: log [6491,6494]
===
match
---
fstring_end: ' [45074,45075]
fstring_end: ' [45577,45578]
===
match
---
name: query [64011,64016]
name: query [64514,64519]
===
match
---
argument [47262,47279]
argument [47765,47782]
===
match
---
name: dag_ids [27300,27307]
name: dag_ids [27300,27307]
===
match
---
simple_stmt [13770,13893]
simple_stmt [13770,13893]
===
match
---
arglist [78026,78076]
arglist [78529,78579]
===
match
---
name: models [35042,35048]
name: models [35545,35551]
===
match
---
operator: = [10064,10065]
operator: = [10064,10065]
===
match
---
simple_stmt [11563,11727]
simple_stmt [11563,11727]
===
match
---
operator: = [23993,23994]
operator: = [23993,23994]
===
match
---
name: stop [66322,66326]
name: stop [66825,66829]
===
match
---
name: ti [77412,77414]
name: ti [77915,77917]
===
match
---
operator: , [41311,41312]
operator: , [41814,41815]
===
match
---
name: dagbag [27405,27411]
name: dagbag [27405,27411]
===
match
---
trailer [41295,41311]
trailer [41798,41814]
===
match
---
name: callback_requests [22508,22525]
name: callback_requests [22508,22525]
===
match
---
operator: , [59878,59879]
operator: , [60381,60382]
===
match
---
name: slots_stats [77921,77932]
name: slots_stats [78424,78435]
===
match
---
name: TI [64335,64337]
name: TI [64838,64840]
===
match
---
trailer [52021,52027]
trailer [52524,52530]
===
match
---
operator: = [73533,73534]
operator: = [74036,74037]
===
match
---
simple_stmt [38707,38795]
simple_stmt [39210,39298]
===
match
---
name: self [59978,59982]
name: self [60481,60485]
===
match
---
name: self [27616,27620]
name: self [27616,27620]
===
match
---
atom_expr [82580,82598]
atom_expr [83083,83101]
===
match
---
classdef [27842,82655]
classdef [28096,83158]
===
match
---
trailer [23683,23692]
trailer [23683,23692]
===
match
---
string: "Skipping SLA check for %s because no tasks in DAG have SLAs" [77480,77541]
string: "Skipping SLA check for %s because no tasks in DAG have SLAs" [77983,78044]
===
match
---
suite [60328,61139]
suite [60831,61642]
===
match
---
operator: , [51687,51688]
operator: , [52190,52191]
===
match
---
operator: < [73399,73400]
operator: < [73902,73903]
===
match
---
operator: , [1330,1331]
operator: , [1330,1331]
===
match
---
trailer [77998,78000]
trailer [78501,78503]
===
match
---
operator: * [31728,31729]
operator: * [32231,32232]
===
match
---
name: _send_dag_callbacks_to_processor [74569,74601]
name: _send_dag_callbacks_to_processor [75072,75104]
===
match
---
suite [67883,68182]
suite [68386,68685]
===
match
---
name: commit [21349,21355]
name: commit [21349,21355]
===
match
---
name: frame [31080,31085]
name: frame [31334,31339]
===
match
---
name: dag_models [68139,68149]
name: dag_models [68642,68652]
===
match
---
simple_stmt [66417,66483]
simple_stmt [66920,66986]
===
match
---
funcdef [30770,31040]
funcdef [31024,31294]
===
match
---
atom_expr [54201,54534]
atom_expr [54704,55037]
===
match
---
atom_expr [34974,35002]
atom_expr [35477,35505]
===
match
---
param [24218,24233]
param [24218,24233]
===
match
---
atom_expr [24388,24404]
atom_expr [24388,24404]
===
match
---
tfpdef [23856,23883]
tfpdef [23856,23883]
===
match
---
name: TaskInstance [34693,34705]
name: TaskInstance [35196,35208]
===
match
---
string: "Set the following tasks to scheduled state:\n\t%s" [50503,50554]
string: "Set the following tasks to scheduled state:\n\t%s" [51006,51057]
===
match
---
name: has_task [43324,43332]
name: has_task [43827,43835]
===
match
---
atom_expr [58358,58433]
atom_expr [58861,58936]
===
match
---
name: dag_map [36985,36992]
name: dag_map [37488,37495]
===
match
---
name: TaskCallbackRequest [2332,2351]
name: TaskCallbackRequest [2332,2351]
===
match
---
name: notin_ [64243,64249]
name: notin_ [64746,64752]
===
match
---
atom_expr [25031,25043]
atom_expr [25031,25043]
===
match
---
name: file_path [26683,26692]
name: file_path [26683,26692]
===
match
---
atom_expr [24325,24341]
atom_expr [24325,24341]
===
match
---
arglist [29573,29611]
arglist [29827,29865]
===
match
---
trailer [34197,34209]
trailer [34700,34712]
===
match
---
expr_stmt [38935,39115]
expr_stmt [39438,39618]
===
match
---
suite [11760,11839]
suite [11760,11839]
===
match
---
trailer [71181,71187]
trailer [71684,71690]
===
match
---
name: _process [12638,12646]
name: _process [12638,12646]
===
match
---
name: dagbag [26864,26870]
name: dagbag [26864,26870]
===
match
---
name: RUNNING [80027,80034]
name: RUNNING [80530,80537]
===
match
---
atom_expr [70597,70615]
atom_expr [71100,71118]
===
match
---
simple_stmt [52735,52928]
simple_stmt [53238,53431]
===
match
---
operator: , [2867,2868]
operator: , [2867,2868]
===
match
---
operator: += [34485,34487]
operator: += [34988,34990]
===
match
---
simple_stmt [71863,71923]
simple_stmt [72366,72426]
===
match
---
name: dag_id [36540,36546]
name: dag_id [37043,37049]
===
match
---
name: conf [15174,15178]
name: conf [15174,15178]
===
match
---
name: id [69956,69958]
name: id [70459,70461]
===
match
---
name: utils [3009,3014]
name: utils [3009,3014]
===
match
---
atom_expr [16778,16802]
atom_expr [16778,16802]
===
match
---
atom_expr [13561,13574]
atom_expr [13561,13574]
===
match
---
name: waitable_handle [14366,14381]
name: waitable_handle [14366,14381]
===
match
---
name: execution_date [68439,68453]
name: execution_date [68942,68956]
===
match
---
name: log [19072,19075]
name: log [19072,19075]
===
match
---
arith_expr [32585,32626]
arith_expr [33088,33129]
===
match
---
name: count [36553,36558]
name: count [37056,37061]
===
match
---
atom [69495,69530]
atom [69998,70033]
===
match
---
argument [54275,54309]
argument [54778,54812]
===
match
---
trailer [49259,49685]
trailer [49762,50188]
===
match
---
name: attempt [78896,78903]
name: attempt [79399,79406]
===
match
---
operator: += [44642,44644]
operator: += [45145,45147]
===
match
---
operator: , [60710,60711]
operator: , [61213,61214]
===
match
---
atom_expr [44439,44463]
atom_expr [44942,44966]
===
match
---
simple_stmt [29731,29752]
simple_stmt [29985,30006]
===
match
---
argument [57916,57929]
argument [58419,58432]
===
match
---
trailer [39603,39690]
trailer [40106,40193]
===
match
---
string: "open" [40878,40884]
string: "open" [41381,41387]
===
match
---
exprlist [22205,22225]
exprlist [22205,22225]
===
match
---
name: session [60538,60545]
name: session [61041,61048]
===
match
---
simple_stmt [26997,27040]
simple_stmt [26997,27040]
===
match
---
name: load_only [80966,80975]
name: load_only [81469,81478]
===
match
---
or_test [10298,10351]
or_test [10298,10351]
===
match
---
trailer [47176,47185]
trailer [47679,47688]
===
match
---
name: msg [53184,53187]
name: msg [53687,53690]
===
match
---
simple_stmt [26819,26895]
simple_stmt [26819,26895]
===
match
---
name: subq [34516,34520]
name: subq [35019,35023]
===
match
---
name: duration [35062,35070]
name: duration [35565,35573]
===
match
---
fstring_string: airflow scheduler - DagFileProcessor  [6890,6927]
fstring_string: airflow scheduler - DagFileProcessor  [6890,6927]
===
match
---
name: retry_db_transaction [2777,2797]
name: retry_db_transaction [2777,2797]
===
match
---
arglist [37750,37781]
arglist [38253,38284]
===
match
---
name: self [25065,25069]
name: self [25065,25069]
===
match
---
name: log [40737,40740]
name: log [41240,41243]
===
match
---
trailer [27817,27839]
trailer [27817,27839]
===
match
---
name: Optional [31864,31872]
name: Optional [32367,32375]
===
match
---
operator: , [71311,71312]
operator: , [71814,71815]
===
match
---
name: tis_changed [35544,35555]
name: tis_changed [36047,36058]
===
match
---
expr_stmt [49212,49792]
expr_stmt [49715,50295]
===
match
---
name: x [39543,39544]
name: x [40046,40047]
===
match
---
comparison [73380,73439]
comparison [73883,73942]
===
match
---
trailer [25078,25140]
trailer [25078,25140]
===
match
---
comparison [52629,52653]
comparison [53132,53156]
===
match
---
annassign [29279,29338]
annassign [29533,29592]
===
match
---
name: set [20275,20278]
name: set [20275,20278]
===
match
---
trailer [30998,31005]
trailer [31252,31259]
===
match
---
name: subq [35410,35414]
name: subq [35913,35917]
===
match
---
trailer [53257,53261]
trailer [53760,53764]
===
match
---
atom_expr [82100,82314]
atom_expr [82603,82817]
===
match
---
name: active_runs_of_dags [71884,71903]
name: active_runs_of_dags [72387,72406]
===
match
---
name: to_reset [81991,81999]
name: to_reset [82494,82502]
===
match
---
trailer [18546,18554]
trailer [18546,18554]
===
match
---
atom_expr [31006,31020]
atom_expr [31260,31274]
===
match
---
dotted_name [2580,2611]
dotted_name [2580,2611]
===
match
---
name: make_transient [46027,46041]
name: make_transient [46530,46544]
===
match
---
operator: , [41147,41148]
operator: , [41650,41651]
===
match
---
operator: = [31648,31649]
operator: = [32151,32152]
===
match
---
expr_stmt [30272,30287]
expr_stmt [30526,30541]
===
match
---
name: timezone [73401,73409]
name: timezone [73904,73912]
===
match
---
name: log [7615,7618]
name: log [7615,7618]
===
match
---
operator: , [69644,69645]
operator: , [70147,70148]
===
match
---
name: pool [41115,41119]
name: pool [41618,41622]
===
match
---
trailer [24334,24341]
trailer [24334,24341]
===
match
---
name: _parent_channel [8980,8995]
name: _parent_channel [8980,8995]
===
match
---
tfpdef [15432,15448]
tfpdef [15432,15448]
===
match
---
name: pool [40697,40701]
name: pool [41200,41204]
===
match
---
name: or_ [80557,80560]
name: or_ [81060,81063]
===
match
---
name: in_ [73726,73729]
name: in_ [74229,74232]
===
match
---
operator: = [71628,71629]
operator: = [72131,72132]
===
match
---
name: self [59833,59837]
name: self [60336,60340]
===
match
---
operator: , [70309,70310]
operator: , [70812,70813]
===
match
---
atom_expr [32350,32401]
atom_expr [32853,32904]
===
match
---
operator: ** [39068,39070]
operator: ** [39571,39573]
===
match
---
operator: , [39670,39671]
operator: , [40173,40174]
===
match
---
trailer [10965,10969]
trailer [10965,10969]
===
match
---
name: self [77038,77042]
name: self [77541,77545]
===
match
---
name: self [65248,65252]
name: self [65751,65755]
===
match
---
operator: , [26525,26526]
operator: , [26525,26526]
===
match
---
name: SIGKILL [11087,11094]
name: SIGKILL [11087,11094]
===
match
---
param [14061,14065]
param [14061,14065]
===
match
---
name: session [60530,60537]
name: session [61033,61040]
===
match
---
name: state [50198,50203]
name: state [50701,50706]
===
match
---
name: dags [27807,27811]
name: dags [27807,27811]
===
match
---
trailer [60451,60563]
trailer [60954,61066]
===
match
---
for_stmt [21993,22144]
for_stmt [21993,22144]
===
match
---
atom_expr [71266,71289]
atom_expr [71769,71792]
===
match
---
suite [71726,71851]
suite [72229,72354]
===
match
---
name: utils [3047,3052]
name: utils [3047,3052]
===
match
---
operator: -> [77884,77886]
operator: -> [78387,78389]
===
match
---
trailer [52952,52958]
trailer [53455,53461]
===
match
---
name: _create_dag_runs [67324,67340]
name: _create_dag_runs [67827,67843]
===
match
---
name: self [9290,9294]
name: self [9290,9294]
===
match
---
name: self [55808,55812]
name: self [56311,56315]
===
match
---
argument [48720,48735]
argument [49223,49238]
===
match
---
trailer [6520,6530]
trailer [6520,6530]
===
match
---
atom_expr [7282,7306]
atom_expr [7282,7306]
===
match
---
trailer [79238,79244]
trailer [79741,79747]
===
match
---
argument [8925,9205]
argument [8925,9205]
===
match
---
suite [67405,70393]
suite [67908,70896]
===
match
---
name: self [11366,11370]
name: self [11366,11370]
===
match
---
name: max_active_runs [74869,74884]
name: max_active_runs [75372,75387]
===
match
---
simple_stmt [43608,43757]
simple_stmt [44111,44260]
===
match
---
atom_expr [17912,17929]
atom_expr [17912,17929]
===
match
---
operator: , [46636,46637]
operator: , [47139,47140]
===
match
---
name: do_pickle [30191,30200]
name: do_pickle [30445,30454]
===
match
---
atom_expr [9013,9027]
atom_expr [9013,9027]
===
match
---
atom_expr [36525,36535]
atom_expr [37028,37038]
===
match
---
name: active_runs_of_dag [71962,71980]
name: active_runs_of_dag [72465,72483]
===
match
---
name: self [14061,14065]
name: self [14061,14065]
===
match
---
name: execution_date [17406,17420]
name: execution_date [17406,17420]
===
match
---
tfpdef [32771,32792]
tfpdef [33274,33295]
===
match
---
name: test_mode [25034,25043]
name: test_mode [25034,25043]
===
match
---
suite [77101,77170]
suite [77604,77673]
===
match
---
name: dm [68071,68073]
name: dm [68574,68576]
===
match
---
name: log [52490,52493]
name: log [52993,52996]
===
match
---
trailer [30216,30225]
trailer [30470,30479]
===
match
---
trailer [80103,80107]
trailer [80606,80610]
===
match
---
name: log [30284,30287]
name: log [30538,30541]
===
match
---
atom_expr [76255,76330]
atom_expr [76758,76833]
===
match
---
atom_expr [8062,8132]
atom_expr [8062,8132]
===
match
---
name: self [81765,81769]
name: self [82268,82272]
===
match
---
trailer [55143,55148]
trailer [55646,55651]
===
match
---
name: get_context [8731,8742]
name: get_context [8731,8742]
===
match
---
for_stmt [50290,50398]
for_stmt [50793,50901]
===
match
---
atom_expr [8800,8826]
atom_expr [8800,8826]
===
match
---
name: expected_start_date [69995,70014]
name: expected_start_date [70498,70517]
===
match
---
name: dag [16549,16552]
name: dag [16549,16552]
===
match
---
funcdef [24184,25141]
funcdef [24184,25141]
===
match
---
trailer [32609,32626]
trailer [33112,33129]
===
match
---
name: self [31066,31070]
name: self [31320,31324]
===
match
---
name: self [11854,11858]
name: self [11854,11858]
===
match
---
with_stmt [58051,59129]
with_stmt [58554,59632]
===
match
---
name: dag_run [74368,74375]
name: dag_run [74871,74878]
===
match
---
trailer [66246,66257]
trailer [66749,66760]
===
match
---
name: datetime [832,840]
name: datetime [832,840]
===
match
---
with_stmt [58514,58792]
with_stmt [59017,59295]
===
match
---
name: getfloat [57506,57514]
name: getfloat [58009,58017]
===
match
---
operator: } [78132,78133]
operator: } [78635,78636]
===
match
---
operator: , [25129,25130]
operator: , [25129,25130]
===
match
---
name: count [71059,71064]
name: count [71562,71567]
===
match
---
name: State [38624,38629]
name: State [39127,39132]
===
match
---
name: session [36511,36518]
name: session [37014,37021]
===
match
---
simple_stmt [43224,43286]
simple_stmt [43727,43789]
===
match
---
expr_stmt [38359,38698]
expr_stmt [38862,39201]
===
match
---
atom_expr [78934,78942]
atom_expr [79437,79445]
===
match
---
trailer [52493,52498]
trailer [52996,53001]
===
match
---
name: session [81274,81281]
name: session [81777,81784]
===
match
---
atom_expr [31022,31038]
atom_expr [31276,31292]
===
match
---
funcdef [8545,9774]
funcdef [8545,9774]
===
match
---
operator: == [52638,52640]
operator: == [53141,53143]
===
match
---
name: _parent_channel [13626,13641]
name: _parent_channel [13626,13641]
===
match
---
if_stmt [73170,73284]
if_stmt [73673,73787]
===
match
---
try_stmt [20633,21057]
try_stmt [20633,21057]
===
match
---
name: queue [47152,47157]
name: queue [47655,47660]
===
match
---
name: logging [29660,29667]
name: logging [29914,29921]
===
match
---
name: close [9553,9558]
name: close [9553,9558]
===
match
---
and_test [71938,72003]
and_test [72441,72506]
===
match
---
name: datetime [14079,14087]
name: datetime [14079,14087]
===
match
---
operator: , [2648,2649]
operator: , [2648,2649]
===
match
---
name: self [48617,48621]
name: self [49120,49124]
===
match
---
string: """         For all DAG IDs in the DagBag, look for task instances in the         old_states and set them to new_state if the corresponding DagRun         does not exist or exists but is not in the running state. This         normally should not happen, but it can if the state of DagRuns are         changed manually.          :param old_states: examine TaskInstances in this state         :type old_states: list[airflow.utils.state.State]         :param new_state: set TaskInstances to this state         :type new_state: airflow.utils.state.State         """ [32857,33418]
string: """         For all DAG IDs in the DagBag, look for task instances in the         old_states and set them to new_state if the corresponding DagRun         does not exist or exists but is not in the running state. This         normally should not happen, but it can if the state of DagRuns are         changed manually.          :param old_states: examine TaskInstances in this state         :type old_states: list[airflow.utils.state.State]         :param new_state: set TaskInstances to this state         :type new_state: airflow.utils.state.State         """ [33360,33921]
===
match
---
name: run_id [74012,74018]
name: run_id [74515,74521]
===
match
---
operator: , [76841,76842]
operator: , [77344,77345]
===
match
---
trailer [52948,52952]
trailer [53451,53455]
===
match
---
name: dagrun [24076,24082]
name: dagrun [24076,24082]
===
match
---
name: TimeoutError [10542,10554]
name: TimeoutError [10542,10554]
===
match
---
name: dag_run [64190,64197]
name: dag_run [64693,64700]
===
match
---
fstring [78102,78134]
fstring [78605,78637]
===
match
---
atom_expr [7794,7809]
atom_expr [7794,7809]
===
match
---
name: self [55617,55621]
name: self [56120,56124]
===
match
---
atom_expr [77583,77603]
atom_expr [78086,78106]
===
match
---
trailer [34528,34537]
trailer [35031,35040]
===
match
---
atom_expr [44160,44184]
atom_expr [44663,44687]
===
match
---
annassign [57258,57308]
annassign [57761,57811]
===
match
---
name: ti [16744,16746]
name: ti [16744,16746]
===
match
---
simple_stmt [17479,17515]
simple_stmt [17479,17515]
===
match
---
operator: = [54045,54046]
operator: = [54548,54549]
===
match
---
raise_stmt [14242,14310]
raise_stmt [14242,14310]
===
match
---
string: 'scheduler.tasks.killed_externally' [52682,52717]
string: 'scheduler.tasks.killed_externally' [53185,53220]
===
match
---
name: DAG [27357,27360]
name: DAG [27357,27360]
===
match
---
trailer [39372,39378]
trailer [39875,39881]
===
match
---
name: FAILED [73487,73493]
name: FAILED [73990,73996]
===
match
---
operator: , [78235,78236]
operator: , [78738,78739]
===
match
---
simple_stmt [50407,50481]
simple_stmt [50910,50984]
===
match
---
simple_stmt [920,931]
simple_stmt [920,931]
===
match
---
trailer [80957,80965]
trailer [81460,81468]
===
match
---
trailer [70140,70151]
trailer [70643,70654]
===
match
---
trailer [79001,79213]
trailer [79504,79716]
===
match
---
trailer [57271,57282]
trailer [57774,57785]
===
match
---
param [76826,76842]
param [77329,77345]
===
match
---
name: task_id [18357,18364]
name: task_id [18357,18364]
===
match
---
trailer [66585,66587]
trailer [67088,67090]
===
match
---
simple_stmt [58635,58661]
simple_stmt [59138,59164]
===
match
---
name: DAG [1831,1834]
name: DAG [1831,1834]
===
match
---
name: filter [45649,45655]
name: filter [46152,46158]
===
match
---
funcdef [5098,8540]
funcdef [5098,8540]
===
match
---
operator: , [27030,27031]
operator: , [27030,27031]
===
match
---
name: query [74157,74162]
name: query [74660,74665]
===
match
---
name: following_schedule [70021,70039]
name: following_schedule [70524,70542]
===
match
---
operator: , [23205,23206]
operator: , [23205,23206]
===
match
---
name: task_map [36734,36742]
name: task_map [37237,37245]
===
match
---
name: timedelta [16856,16865]
name: timedelta [16856,16865]
===
match
---
atom_expr [64445,64494]
atom_expr [64948,64997]
===
match
---
name: following_schedule [17250,17268]
name: following_schedule [17250,17268]
===
match
---
trailer [22278,22282]
trailer [22278,22282]
===
match
---
simple_stmt [31501,31569]
simple_stmt [32004,32072]
===
match
---
for_stmt [41394,45016]
for_stmt [41897,45519]
===
match
---
import_from [2355,2450]
import_from [2355,2450]
===
match
---
name: stacktrace [22367,22377]
name: stacktrace [22367,22377]
===
match
---
name: List [5302,5306]
name: List [5302,5306]
===
match
---
operator: , [78481,78482]
operator: , [78984,78985]
===
match
---
term [31724,31732]
term [32227,32235]
===
match
---
trailer [78755,78803]
trailer [79258,79306]
===
match
---
operator: , [82240,82241]
operator: , [82743,82744]
===
match
---
name: self [9130,9134]
name: self [9130,9134]
===
match
---
tfpdef [35952,35968]
tfpdef [36455,36471]
===
match
---
name: AbstractDagFileProcessorProcess [2396,2427]
name: AbstractDagFileProcessorProcess [2396,2427]
===
match
---
expr_stmt [17479,17514]
expr_stmt [17479,17514]
===
match
---
trailer [65816,65855]
trailer [66319,66358]
===
match
---
atom_expr [73380,73398]
atom_expr [73883,73901]
===
match
---
string: 'scheduler' [78834,78845]
string: 'scheduler' [79337,79348]
===
match
---
trailer [18466,18470]
trailer [18466,18470]
===
match
---
name: Session [78344,78351]
name: Session [78847,78854]
===
match
---
trailer [77766,77774]
trailer [78269,78277]
===
match
---
name: os [7666,7668]
name: os [7666,7668]
===
match
---
name: ignore_ti_state [46815,46830]
name: ignore_ti_state [47318,47333]
===
match
---
suite [38820,38888]
suite [39323,39391]
===
match
---
number: 0 [59671,59672]
number: 0 [60174,60175]
===
match
---
if_stmt [11338,11465]
if_stmt [11338,11465]
===
match
---
operator: } [78233,78234]
operator: } [78736,78737]
===
match
---
operator: , [52973,52974]
operator: , [53476,53477]
===
match
---
operator: , [79845,79846]
operator: , [80348,80349]
===
match
---
atom_expr [27818,27838]
atom_expr [27818,27838]
===
match
---
suite [14229,14311]
suite [14229,14311]
===
match
---
operator: = [60515,60516]
operator: = [61018,61019]
===
match
---
name: filter [35212,35218]
name: filter [35715,35721]
===
match
---
name: execution_date [49719,49733]
name: execution_date [50222,50236]
===
match
---
argument [35491,35516]
argument [35994,36019]
===
match
---
name: tis [52114,52117]
name: tis [52617,52620]
===
match
---
expr_stmt [40121,40262]
expr_stmt [40624,40765]
===
match
---
trailer [33742,33981]
trailer [34245,34484]
===
match
---
expr_stmt [38707,38794]
expr_stmt [39210,39297]
===
match
---
trailer [18356,18364]
trailer [18356,18364]
===
match
---
name: Tuple [36473,36478]
name: Tuple [36976,36981]
===
match
---
atom_expr [55998,56034]
atom_expr [56501,56537]
===
match
---
name: set_context [2650,2661]
name: set_context [2650,2661]
===
match
---
trailer [78382,78387]
trailer [78885,78890]
===
match
---
atom_expr [37513,37521]
atom_expr [38016,38024]
===
match
---
name: event_buffer [50913,50925]
name: event_buffer [51416,51428]
===
match
---
name: _parent_channel [12675,12690]
name: _parent_channel [12675,12690]
===
match
---
operator: = [50080,50081]
operator: = [50583,50584]
===
match
---
operator: = [54582,54583]
operator: = [55085,55086]
===
match
---
sync_comp_for [77431,77450]
sync_comp_for [77934,77953]
===
match
---
trailer [59580,59623]
trailer [60083,60126]
===
match
---
operator: == [49655,49657]
operator: == [50158,50160]
===
match
---
decorated [14348,14427]
decorated [14348,14427]
===
match
---
trailer [44807,44822]
trailer [45310,45325]
===
match
---
name: set_context [6839,6850]
name: set_context [6839,6850]
===
match
---
name: dag [71908,71911]
name: dag [72411,72414]
===
match
---
name: Exception [26570,26579]
name: Exception [26570,26579]
===
match
---
parameters [30790,30796]
parameters [31044,31050]
===
match
---
trailer [71058,71064]
trailer [71561,71567]
===
match
---
name: TI [38395,38397]
name: TI [38898,38900]
===
match
---
name: is_paused [38580,38589]
name: is_paused [39083,39092]
===
match
---
name: self [13588,13592]
name: self [13588,13592]
===
match
---
name: task_instances_to_examine [39319,39344]
name: task_instances_to_examine [39822,39847]
===
match
---
name: session [76641,76648]
name: session [77144,77151]
===
match
---
trailer [17030,17038]
trailer [17030,17038]
===
match
---
atom_expr [20505,20542]
atom_expr [20505,20542]
===
match
---
operator: == [38621,38623]
operator: == [39124,39126]
===
match
---
name: info [44228,44232]
name: info [44731,44735]
===
match
---
name: name [7579,7583]
name: name [7579,7583]
===
match
---
atom_expr [76951,76996]
atom_expr [77454,77499]
===
match
---
trailer [78387,78416]
trailer [78890,78919]
===
match
---
operator: -> [25347,25349]
operator: -> [25347,25349]
===
match
---
trailer [19364,19368]
trailer [19364,19368]
===
match
---
name: dags [27412,27416]
name: dags [27412,27416]
===
match
---
atom_expr [36585,36605]
atom_expr [37088,37108]
===
match
---
expr_stmt [3122,3142]
expr_stmt [3122,3142]
===
match
---
name: heartbeat [58830,58839]
name: heartbeat [59333,59342]
===
match
---
name: ti [41293,41295]
name: ti [41796,41798]
===
match
---
comparison [11341,11362]
comparison [11341,11362]
===
match
---
name: self [55998,56002]
name: self [56501,56505]
===
match
---
name: task_instances_to_examine [39555,39580]
name: task_instances_to_examine [40058,40083]
===
match
---
simple_stmt [57318,57344]
simple_stmt [57821,57847]
===
match
---
simple_stmt [24472,24511]
simple_stmt [24472,24511]
===
match
---
trailer [37180,37184]
trailer [37683,37687]
===
match
---
suite [39351,39452]
suite [39854,39955]
===
match
---
decorator [5080,5094]
decorator [5080,5094]
===
match
---
name: log [79792,79795]
name: log [80295,80298]
===
match
---
simple_stmt [62994,63048]
simple_stmt [63497,63551]
===
match
---
trailer [33678,33684]
trailer [34181,34187]
===
match
---
operator: , [42335,42336]
operator: , [42838,42839]
===
match
---
atom_expr [35410,35431]
atom_expr [35913,35934]
===
match
---
arglist [82143,82288]
arglist [82646,82791]
===
match
---
atom_expr [74020,74034]
atom_expr [74523,74537]
===
match
---
operator: = [50264,50265]
operator: = [50767,50768]
===
match
---
trailer [20977,20987]
trailer [20977,20987]
===
match
---
atom_expr [37176,37184]
atom_expr [37679,37687]
===
match
---
simple_stmt [30814,30863]
simple_stmt [31068,31117]
===
match
---
simple_stmt [1286,1339]
simple_stmt [1286,1339]
===
match
---
string: """         :return: the PID of the process launched to process the given file         :rtype: int         """ [11219,11329]
string: """         :return: the PID of the process launched to process the given file         :rtype: int         """ [11219,11329]
===
match
---
trailer [17667,17674]
trailer [17667,17674]
===
match
---
trailer [79502,79510]
trailer [80005,80013]
===
match
---
atom_expr [23964,24034]
atom_expr [23964,24034]
===
match
---
name: sorted [41236,41242]
name: sorted [41739,41745]
===
match
---
atom_expr [53796,53821]
atom_expr [54299,54324]
===
match
---
trailer [51087,51093]
trailer [51590,51596]
===
match
---
name: _file_path [5064,5074]
name: _file_path [5064,5074]
===
match
---
operator: , [45217,45218]
operator: , [45720,45721]
===
match
---
decorated [76040,76769]
decorated [76543,77272]
===
match
---
name: tis_with_right_state [51735,51755]
name: tis_with_right_state [52238,52258]
===
match
---
param [15432,15455]
param [15432,15455]
===
match
---
name: dag [77763,77766]
name: dag [78266,78269]
===
match
---
argument [13290,13299]
argument [13290,13299]
===
match
---
operator: @ [66896,66897]
operator: @ [67399,67400]
===
match
---
operator: -> [12027,12029]
operator: -> [12027,12029]
===
match
---
operator: , [2979,2980]
operator: , [2979,2980]
===
match
---
operator: != [38491,38493]
operator: != [38994,38996]
===
match
---
operator: |= [20575,20577]
operator: |= [20575,20577]
===
match
---
name: timer [65811,65816]
name: timer [66314,66319]
===
match
---
name: session [39039,39046]
name: session [39542,39549]
===
match
---
name: latest_heartbeat [79553,79569]
name: latest_heartbeat [80056,80072]
===
match
---
tfpdef [22508,22548]
tfpdef [22508,22548]
===
match
---
name: dag_run [65149,65156]
name: dag_run [65652,65659]
===
match
---
simple_stmt [4872,4937]
simple_stmt [4872,4937]
===
match
---
simple_stmt [22050,22144]
simple_stmt [22050,22144]
===
match
---
name: external_trigger [69815,69831]
name: external_trigger [70318,70334]
===
match
---
simple_stmt [16771,16803]
simple_stmt [16771,16803]
===
match
---
operator: , [24539,24540]
operator: , [24539,24540]
===
match
---
name: ti_prop_update [34597,34611]
name: ti_prop_update [35100,35114]
===
match
---
name: self [4164,4168]
name: self [4164,4168]
===
match
---
operator: = [69904,69905]
operator: = [70407,70408]
===
match
---
name: _process [4317,4325]
name: _process [4317,4325]
===
match
---
not_test [59228,59244]
not_test [59731,59747]
===
match
---
trailer [15789,15794]
trailer [15789,15794]
===
match
---
name: session [24018,24025]
name: session [24018,24025]
===
match
---
simple_stmt [15358,15374]
simple_stmt [15358,15374]
===
match
---
operator: , [60136,60137]
operator: , [60639,60640]
===
match
---
operator: = [49947,49948]
operator: = [50450,50451]
===
match
---
trailer [36696,36706]
trailer [37199,37209]
===
match
---
name: scheduler_health_check_threshold [32410,32442]
name: scheduler_health_check_threshold [32913,32945]
===
match
---
name: utils [2191,2196]
name: utils [2191,2196]
===
match
---
trailer [4351,4359]
trailer [4351,4359]
===
match
---
name: TaskCallbackRequest [53018,53037]
name: TaskCallbackRequest [53521,53540]
===
match
---
fstring [45041,45075]
fstring [45544,45578]
===
match
---
suite [26908,27088]
suite [26908,27088]
===
match
---
trailer [70199,70206]
trailer [70702,70709]
===
match
---
expr_stmt [73839,73874]
expr_stmt [74342,74377]
===
match
---
name: state [81574,81579]
name: state [82077,82082]
===
match
---
trailer [23570,23580]
trailer [23570,23580]
===
match
---
trailer [60990,61024]
trailer [61493,61527]
===
match
---
name: dagbag [27800,27806]
name: dagbag [27800,27806]
===
match
---
trailer [27641,27658]
trailer [27641,27658]
===
match
---
expr_stmt [16771,16802]
expr_stmt [16771,16802]
===
match
---
not_test [24100,24131]
not_test [24100,24131]
===
match
---
trailer [41537,41542]
trailer [42040,42045]
===
match
---
name: stats [2094,2099]
name: stats [2094,2099]
===
match
---
name: type [54341,54345]
name: type [54844,54848]
===
match
---
trailer [15257,15268]
trailer [15257,15268]
===
match
---
name: execution_date [17938,17952]
name: execution_date [17938,17952]
===
match
---
tfpdef [76104,76119]
tfpdef [76607,76622]
===
match
---
name: name [67867,67871]
name: name [68370,68374]
===
match
---
operator: , [79194,79195]
operator: , [79697,79698]
===
match
---
trailer [50374,50378]
trailer [50877,50881]
===
match
---
name: or_ [33739,33742]
name: or_ [34242,34245]
===
match
---
trailer [20914,20948]
trailer [20914,20948]
===
match
---
name: Set [72601,72604]
name: Set [73104,73107]
===
match
---
simple_stmt [55561,55567]
simple_stmt [56064,56070]
===
match
---
atom_expr [45913,45920]
atom_expr [46416,46423]
===
match
---
testlist [36985,37002]
testlist [37488,37505]
===
match
---
name: loop_count [60205,60215]
name: loop_count [60708,60718]
===
match
---
trailer [72370,72382]
trailer [72873,72885]
===
match
---
simple_stmt [36734,36797]
simple_stmt [37237,37300]
===
match
---
name: num_failed [79347,79357]
name: num_failed [79850,79860]
===
match
---
name: BACKFILL_JOB [38505,38517]
name: BACKFILL_JOB [39008,39020]
===
match
---
atom [8930,9205]
atom [8930,9205]
===
match
---
name: enumerate [41430,41439]
name: enumerate [41933,41942]
===
match
---
comp_op [32264,32270]
comp_op [32767,32773]
===
match
---
trailer [18698,18713]
trailer [18698,18713]
===
match
---
dotted_name [2360,2388]
dotted_name [2360,2388]
===
match
---
name: dagbag [24376,24382]
name: dagbag [24376,24382]
===
match
---
name: dag [15824,15827]
name: dag [15824,15827]
===
match
---
for_stmt [45989,46046]
for_stmt [46492,46549]
===
match
---
trailer [16350,16364]
trailer [16350,16364]
===
match
---
name: UNIT_TEST_MODE [15151,15165]
name: UNIT_TEST_MODE [15151,15165]
===
match
---
operator: , [72136,72137]
operator: , [72639,72640]
===
match
---
operator: , [71157,71158]
operator: , [71660,71661]
===
match
---
name: all [67172,67175]
name: all [67675,67678]
===
match
---
trailer [38457,38518]
trailer [38960,39021]
===
match
---
trailer [36558,36563]
trailer [37061,37066]
===
match
---
atom_expr [70040,70058]
atom_expr [70543,70561]
===
match
---
atom_expr [65692,65750]
atom_expr [66195,66253]
===
match
---
name: getint [29445,29451]
name: getint [29699,29705]
===
match
---
operator: , [7677,7678]
operator: , [7677,7678]
===
match
---
parameters [11530,11536]
parameters [11530,11536]
===
match
---
operator: , [80775,80776]
operator: , [81278,81279]
===
match
---
trailer [45034,45040]
trailer [45537,45543]
===
match
---
suite [12459,12727]
suite [12459,12727]
===
match
---
simple_stmt [51998,52096]
simple_stmt [52501,52599]
===
match
---
name: List [17602,17606]
name: List [17602,17606]
===
match
---
parameters [31418,31439]
parameters [31795,31816]
===
match
---
name: self [14204,14208]
name: self [14204,14208]
===
match
---
trailer [58022,58028]
trailer [58525,58531]
===
match
---
atom_expr [71054,71069]
atom_expr [71557,71572]
===
match
---
expr_stmt [43608,43756]
expr_stmt [44111,44259]
===
match
---
trailer [34705,34716]
trailer [35208,35219]
===
match
---
name: airflow [2360,2367]
name: airflow [2360,2367]
===
match
---
name: State [60656,60661]
name: State [61159,61164]
===
match
---
name: self [29731,29735]
name: self [29985,29989]
===
match
---
trailer [40736,40740]
trailer [41239,41243]
===
match
---
trailer [31238,31243]
trailer [31615,31620]
===
match
---
name: full_filepath [74275,74288]
name: full_filepath [74778,74791]
===
match
---
simple_stmt [11963,11993]
simple_stmt [11963,11993]
===
match
---
atom_expr [40213,40235]
atom_expr [40716,40738]
===
match
---
name: _process [10303,10311]
name: _process [10303,10311]
===
match
---
atom_expr [47172,47323]
atom_expr [47675,47826]
===
match
---
name: provide_session [48842,48857]
name: provide_session [49345,49360]
===
match
---
operator: = [75577,75578]
operator: = [76080,76081]
===
match
---
expr_stmt [42936,42980]
expr_stmt [43439,43483]
===
match
---
suite [58079,59129]
suite [58582,59632]
===
match
---
name: len [81923,81926]
name: len [82426,82429]
===
match
---
name: event_buffer [53469,53481]
name: event_buffer [53972,53984]
===
match
---
atom_expr [58100,58117]
atom_expr [58603,58620]
===
match
---
simple_stmt [10824,10889]
simple_stmt [10824,10889]
===
match
---
expr_stmt [70985,71392]
expr_stmt [71488,71895]
===
match
---
trailer [8694,8696]
trailer [8694,8696]
===
match
---
name: TI [38967,38969]
name: TI [39470,39472]
===
match
---
atom_expr [73481,73493]
atom_expr [73984,73996]
===
match
---
arglist [69615,69959]
arglist [70118,70462]
===
match
---
name: dagbag [27066,27072]
name: dagbag [27066,27072]
===
match
---
parameters [29356,29721]
parameters [29610,29975]
===
match
---
atom_expr [17523,17539]
atom_expr [17523,17539]
===
match
---
name: max_runs [54275,54283]
name: max_runs [54778,54786]
===
match
---
trailer [18713,18723]
trailer [18713,18723]
===
match
---
name: c [35275,35276]
name: c [35778,35779]
===
match
---
atom_expr [60656,60668]
atom_expr [61159,61171]
===
match
---
name: TI [18038,18040]
name: TI [18038,18040]
===
match
---
argument [43269,43284]
argument [43772,43787]
===
match
---
operator: > [74689,74690]
operator: > [75192,75193]
===
match
---
trailer [68582,68589]
trailer [69085,69092]
===
match
---
operator: = [17420,17421]
operator: = [17420,17421]
===
match
---
operator: , [41411,41412]
operator: , [41914,41915]
===
match
---
trailer [13139,13145]
trailer [13139,13145]
===
match
---
suite [47405,48836]
suite [47908,49339]
===
match
---
argument [60790,60805]
argument [61293,61308]
===
match
---
import_from [2996,3033]
import_from [2996,3033]
===
match
---
name: self [33616,33620]
name: self [34119,34123]
===
match
---
trailer [66386,66395]
trailer [66889,66898]
===
match
---
name: pool_slots [44453,44463]
name: pool_slots [44956,44966]
===
match
---
trailer [39890,39897]
trailer [40393,40400]
===
match
---
name: log [68696,68699]
name: log [69199,69202]
===
match
---
name: self [15416,15420]
name: self [15416,15420]
===
match
---
expr_stmt [69570,69977]
expr_stmt [70073,70480]
===
match
---
except_clause [27667,27683]
except_clause [27667,27683]
===
match
---
trailer [74162,74172]
trailer [74665,74675]
===
match
---
arglist [24076,24168]
arglist [24076,24168]
===
match
---
name: heartbeat [58649,58658]
name: heartbeat [59152,59161]
===
match
---
atom_expr [4816,4862]
atom_expr [4816,4862]
===
match
---
name: task_instance [39792,39805]
name: task_instance [40295,40308]
===
match
---
argument [75587,75610]
argument [76090,76113]
===
match
---
simple_stmt [52944,52991]
simple_stmt [53447,53494]
===
match
---
name: _parent_channel [8766,8781]
name: _parent_channel [8766,8781]
===
match
---
atom_expr [34523,34539]
atom_expr [35026,35042]
===
match
---
name: _file_path [4093,4103]
name: _file_path [4093,4103]
===
match
---
atom_expr [16818,16826]
atom_expr [16818,16826]
===
match
---
tfpdef [23885,23901]
tfpdef [23885,23901]
===
match
---
trailer [52681,52718]
trailer [53184,53221]
===
match
---
expr_stmt [4124,4155]
expr_stmt [4124,4155]
===
match
---
name: DefaultDict [40079,40090]
name: DefaultDict [40582,40593]
===
match
---
argument [69774,69793]
argument [70277,70296]
===
match
---
name: session [52014,52021]
name: session [52517,52524]
===
match
---
atom_expr [33827,33846]
atom_expr [34330,34349]
===
match
---
tfpdef [56122,56162]
tfpdef [56625,56665]
===
match
---
name: following_schedule [17490,17508]
name: following_schedule [17490,17508]
===
match
---
trailer [30891,30898]
trailer [31145,31152]
===
match
---
atom_expr [81537,81545]
atom_expr [82040,82048]
===
match
---
name: result [7786,7792]
name: result [7786,7792]
===
match
---
comparison [40697,40714]
comparison [41200,41217]
===
match
---
argument [8874,8911]
argument [8874,8911]
===
match
---
name: utcnow [73410,73416]
name: utcnow [73913,73919]
===
match
---
annassign [30345,30397]
annassign [30599,30651]
===
match
---
name: state [51665,51670]
name: state [52168,52173]
===
match
---
arglist [50194,50270]
arglist [50697,50773]
===
match
---
simple_stmt [16447,16700]
simple_stmt [16447,16700]
===
match
---
name: isoformat [55245,55254]
name: isoformat [55748,55757]
===
match
---
operator: = [33457,33458]
operator: = [33960,33961]
===
match
---
name: dag_id [16229,16235]
name: dag_id [16229,16235]
===
match
---
name: num_starving_tasks [41810,41828]
name: num_starving_tasks [42313,42331]
===
match
---
name: task [20237,20241]
name: task [20237,20241]
===
match
---
simple_stmt [78987,79214]
simple_stmt [79490,79717]
===
match
---
name: DagRun [33940,33946]
name: DagRun [34443,34449]
===
match
---
operator: * [31748,31749]
operator: * [32251,32252]
===
match
---
param [66951,66956]
param [67454,67459]
===
match
---
name: o [71140,71141]
name: o [71643,71644]
===
match
---
trailer [58604,58613]
trailer [59107,59116]
===
match
---
term [53184,53217]
term [53687,53720]
===
match
---
if_stmt [30252,30288]
if_stmt [30506,30542]
===
match
---
name: old_states [60644,60654]
name: old_states [61147,61157]
===
match
---
name: incr [52677,52681]
name: incr [53180,53184]
===
match
---
name: _done [13503,13508]
name: _done [13503,13508]
===
match
---
name: task_id [43347,43354]
name: task_id [43850,43857]
===
match
---
simple_stmt [58568,58614]
simple_stmt [59071,59117]
===
match
---
name: self [49749,49753]
name: self [50252,50256]
===
match
---
expr_stmt [30521,30596]
expr_stmt [30775,30850]
===
match
---
param [56172,56201]
param [56675,56704]
===
match
---
name: DagFileProcessorAgent [54201,54222]
name: DagFileProcessorAgent [54704,54725]
===
match
---
string: 'scheduler' [29299,29310]
string: 'scheduler' [29553,29564]
===
match
---
name: timers [57810,57816]
name: timers [58313,58319]
===
match
---
arglist [29452,29475]
arglist [29706,29729]
===
match
---
decorator [14032,14042]
decorator [14032,14042]
===
match
---
name: DagCallbackRequest [23389,23407]
name: DagCallbackRequest [23389,23407]
===
match
---
name: self [31671,31675]
name: self [32174,32178]
===
match
---
name: task_instance [50379,50392]
name: task_instance [50882,50895]
===
match
---
atom_expr [12291,12353]
atom_expr [12291,12353]
===
match
---
atom_expr [8117,8131]
atom_expr [8117,8131]
===
match
---
if_stmt [43306,43524]
if_stmt [43809,44027]
===
match
---
simple_stmt [7706,7770]
simple_stmt [7706,7770]
===
match
---
name: dag_run [76826,76833]
name: dag_run [77329,77336]
===
match
---
simple_stmt [59017,59057]
simple_stmt [59520,59560]
===
match
---
trailer [35586,35588]
trailer [36089,36091]
===
match
---
trailer [25254,25271]
trailer [25254,25271]
===
match
---
subscriptlist [13750,13758]
subscriptlist [13750,13758]
===
match
---
name: List [37513,37517]
name: List [38016,38020]
===
match
---
name: task_instance [42205,42218]
name: task_instance [42708,42721]
===
match
---
name: all [39110,39113]
name: all [39613,39616]
===
match
---
trailer [59036,59040]
trailer [59539,59543]
===
match
---
trailer [46906,46914]
trailer [47409,47417]
===
match
---
arglist [79475,79621]
arglist [79978,80124]
===
match
---
comparison [12218,12239]
comparison [12218,12239]
===
match
---
if_stmt [24418,25141]
if_stmt [24418,25141]
===
match
---
trailer [50146,50150]
trailer [50649,50653]
===
match
---
name: log [27734,27737]
name: log [27734,27737]
===
match
---
name: dag_run [75549,75556]
name: dag_run [76052,76059]
===
match
---
name: execution_date [18699,18713]
name: execution_date [18699,18713]
===
match
---
trailer [36661,36665]
trailer [37164,37168]
===
match
---
trailer [50730,50746]
trailer [51233,51249]
===
match
---
name: MultiprocessingConnection [5147,5172]
name: MultiprocessingConnection [5147,5172]
===
match
---
operator: , [73142,73143]
operator: , [73645,73646]
===
match
---
trailer [59585,59610]
trailer [60088,60113]
===
match
---
suite [11554,11993]
suite [11554,11993]
===
match
---
trailer [15785,15789]
trailer [15785,15789]
===
match
---
trailer [7060,7065]
trailer [7060,7065]
===
match
---
simple_stmt [14319,14343]
simple_stmt [14319,14343]
===
match
---
simple_stmt [76144,76230]
simple_stmt [76647,76733]
===
match
---
operator: , [60768,60769]
operator: , [61271,61272]
===
match
---
name: task_id [51530,51537]
name: task_id [52033,52040]
===
match
---
operator: = [71675,71676]
operator: = [72178,72179]
===
match
---
operator: , [35950,35951]
operator: , [36453,36454]
===
match
---
atom_expr [59690,59897]
atom_expr [60193,60400]
===
match
---
atom_expr [11411,11464]
atom_expr [11411,11464]
===
match
---
param [48914,48937]
param [49417,49440]
===
match
---
atom_expr [46859,46866]
atom_expr [47362,47369]
===
match
---
arglist [40749,40813]
arglist [41252,41316]
===
match
---
trailer [27824,27838]
trailer [27824,27838]
===
match
---
simple_stmt [51132,51149]
simple_stmt [51635,51652]
===
match
---
comparison [80733,80775]
comparison [81236,81278]
===
match
---
operator: = [67918,67919]
operator: = [68421,68422]
===
match
---
simple_stmt [65091,65182]
simple_stmt [65594,65685]
===
match
---
operator: , [46672,46673]
operator: , [47175,47176]
===
match
---
name: session [34303,34310]
name: session [34806,34813]
===
match
---
trailer [47045,47051]
trailer [47548,47554]
===
match
---
name: dag_run [73608,73615]
name: dag_run [74111,74118]
===
match
---
trailer [71376,71380]
trailer [71879,71883]
===
match
---
if_stmt [13317,13444]
if_stmt [13317,13444]
===
match
---
name: dag_ids [3966,3973]
name: dag_ids [3966,3973]
===
match
---
simple_stmt [59566,59625]
simple_stmt [60069,60128]
===
match
---
trailer [76394,76398]
trailer [76897,76901]
===
match
---
atom_expr [57501,57576]
atom_expr [58004,58079]
===
match
---
expr_stmt [48579,48647]
expr_stmt [49082,49150]
===
match
---
atom_expr [4312,4325]
atom_expr [4312,4325]
===
match
---
atom_expr [17632,17767]
atom_expr [17632,17767]
===
match
---
if_stmt [13901,13999]
if_stmt [13901,13999]
===
match
---
name: dag_run [74808,74815]
name: dag_run [75311,75318]
===
match
---
name: num_finished_events [58723,58742]
name: num_finished_events [59226,59245]
===
match
---
string: """         Attempts to execute TaskInstances that should be executed by the scheduler.          There are three steps:         1. Pick TIs by priority with the constraint that they are in the expected states         and that we do exceed max_active_runs or pool limits.         2. Change the state for the TIs above atomically.         3. Enqueue the TIs in the executor.          HA note: This function is a "critical section" meaning that only a single executor process can execute         this function at the same time. This is achieved by doing ``SELECT ... from pool FOR UPDATE``. For DBs         that support NOWAIT, a "blocked" scheduler will skip this and continue on with other tasks (creating         new DAG runs, progressing TIs from None to SCHEDULED etc.); DBs that don't support this (such as         MariaDB or MySQL 5.x) the other schedulers will wait for the lock before continuing.          :param session:         :type session: sqlalchemy.orm.Session         :return: Number of task instance with state changed.         """ [47414,48460]
string: """         Attempts to execute TaskInstances that should be executed by the scheduler.          There are three steps:         1. Pick TIs by priority with the constraint that they are in the expected states         and that we do exceed max_active_runs or pool limits.         2. Change the state for the TIs above atomically.         3. Enqueue the TIs in the executor.          HA note: This function is a "critical section" meaning that only a single executor process can execute         this function at the same time. This is achieved by doing ``SELECT ... from pool FOR UPDATE``. For DBs         that support NOWAIT, a "blocked" scheduler will skip this and continue on with other tasks (creating         new DAG runs, progressing TIs from None to SCHEDULED etc.); DBs that don't support this (such as         MariaDB or MySQL 5.x) the other schedulers will wait for the lock before continuing.          :param session:         :type session: sqlalchemy.orm.Session         :return: Number of task instance with state changed.         """ [47917,48963]
===
match
---
name: file_path [7865,7874]
name: file_path [7865,7874]
===
match
---
name: bind [67854,67858]
name: bind [68357,68361]
===
match
---
comparison [43785,43835]
comparison [44288,44338]
===
match
---
trailer [31776,31787]
trailer [32279,32290]
===
match
---
trailer [11035,11039]
trailer [11035,11039]
===
match
---
atom_expr [71908,71918]
atom_expr [72411,72421]
===
match
---
suite [65595,65780]
suite [66098,66283]
===
match
---
argument [77401,77450]
argument [77904,77953]
===
match
---
trailer [33615,33636]
trailer [34118,34139]
===
match
---
atom_expr [12535,12545]
atom_expr [12535,12545]
===
match
---
simple_stmt [11473,11498]
simple_stmt [11473,11498]
===
match
---
atom_expr [34416,34456]
atom_expr [34919,34959]
===
match
---
name: total_seconds [32628,32641]
name: total_seconds [33131,33144]
===
match
---
operator: > [45513,45514]
operator: > [46016,46017]
===
match
---
simple_stmt [61106,61112]
simple_stmt [61609,61615]
===
match
---
trailer [73725,73729]
trailer [74228,74232]
===
match
---
trailer [34242,34246]
trailer [34745,34749]
===
match
---
trailer [81804,81855]
trailer [82307,82358]
===
match
---
return_stmt [56327,56479]
return_stmt [56830,56982]
===
match
---
trailer [49908,49912]
trailer [50411,50415]
===
match
---
name: try_number [24774,24784]
name: try_number [24774,24784]
===
match
---
operator: -> [50661,50663]
operator: -> [51164,51166]
===
match
---
decorated [5002,5075]
decorated [5002,5075]
===
match
---
name: info [52464,52468]
name: info [52967,52971]
===
match
---
name: AirflowException [12291,12307]
name: AirflowException [12291,12307]
===
match
---
trailer [46861,46866]
trailer [47364,47369]
===
match
---
name: QUEUED [60662,60668]
name: QUEUED [61165,61171]
===
match
---
not_test [59272,59295]
not_test [59775,59798]
===
match
---
parameters [8554,8560]
parameters [8554,8560]
===
match
---
name: defaultdict [39762,39773]
name: defaultdict [40265,40276]
===
match
---
trailer [45403,45408]
trailer [45906,45911]
===
match
---
name: ti [77435,77437]
name: ti [77938,77940]
===
match
---
dotted_name [1767,1788]
dotted_name [1767,1788]
===
match
---
name: filter [80697,80703]
name: filter [81200,81206]
===
match
---
operator: >= [42514,42516]
operator: >= [43017,43019]
===
match
---
operator: -> [31087,31089]
operator: -> [31341,31343]
===
match
---
name: session [82503,82510]
name: session [83006,83013]
===
match
---
name: dag [21045,21048]
name: dag [21045,21048]
===
match
---
trailer [4458,4466]
trailer [4458,4466]
===
match
---
operator: = [41234,41235]
operator: = [41737,41738]
===
match
---
atom_expr [45833,45841]
atom_expr [46336,46344]
===
match
---
name: _execute_dag_callbacks [23811,23833]
name: _execute_dag_callbacks [23811,23833]
===
match
---
name: result_channel [8022,8036]
name: result_channel [8022,8036]
===
match
---
expr_stmt [66001,66080]
expr_stmt [66504,66583]
===
match
---
name: executor_loader [1716,1731]
name: executor_loader [1716,1731]
===
match
---
trailer [65156,65163]
trailer [65659,65666]
===
match
---
name: guard [62869,62874]
name: guard [63372,63377]
===
match
---
name: filter [52032,52038]
name: filter [52535,52541]
===
match
---
name: query [50141,50146]
name: query [50644,50649]
===
match
---
name: dag_id [65321,65327]
name: dag_id [65824,65830]
===
match
---
atom_expr [18341,18365]
atom_expr [18341,18365]
===
match
---
name: self [31344,31348]
name: self [31721,31725]
===
match
---
except_clause [19290,19306]
except_clause [19290,19306]
===
match
---
trailer [12637,12646]
trailer [12637,12646]
===
match
---
trailer [50958,50960]
trailer [51461,51463]
===
match
---
name: TI [18127,18129]
name: TI [18127,18129]
===
match
---
name: self [14404,14408]
name: self [14404,14408]
===
match
---
name: TI [46499,46501]
name: TI [47002,47004]
===
match
---
param [41287,41289]
param [41790,41792]
===
match
---
parameters [21405,21439]
parameters [21405,21439]
===
match
---
argument [46654,46672]
argument [47157,47175]
===
match
---
simple_stmt [38150,38190]
simple_stmt [38653,38693]
===
match
---
name: dagbag [21424,21430]
name: dagbag [21424,21430]
===
match
---
trailer [39735,39759]
trailer [40238,40262]
===
match
---
name: ValueError [57192,57202]
name: ValueError [57695,57705]
===
match
---
trailer [18569,18584]
trailer [18569,18584]
===
match
---
name: task [20516,20520]
name: task [20516,20520]
===
match
---
name: state [80143,80148]
name: state [80646,80651]
===
match
---
atom_expr [11053,11095]
atom_expr [11053,11095]
===
match
---
trailer [81304,81308]
trailer [81807,81811]
===
match
---
operator: , [7929,7930]
operator: , [7929,7930]
===
match
---
operator: @ [5002,5003]
operator: @ [5002,5003]
===
match
---
trailer [80556,80629]
trailer [81059,81132]
===
match
---
name: is_unit_test [59232,59244]
name: is_unit_test [59735,59747]
===
match
---
name: lower [30390,30395]
name: lower [30644,30649]
===
match
---
atom_expr [18647,18762]
atom_expr [18647,18762]
===
match
---
operator: , [54488,54489]
operator: , [54991,54992]
===
match
---
annassign [36466,36667]
annassign [36969,37170]
===
match
---
simple_stmt [68572,68633]
simple_stmt [69075,69136]
===
match
---
name: callback_to_execute [74611,74630]
name: callback_to_execute [75114,75133]
===
match
---
trailer [80580,80584]
trailer [81083,81087]
===
match
---
atom_expr [34193,34209]
atom_expr [34696,34712]
===
match
---
trailer [54874,54876]
trailer [55377,55379]
===
match
---
trailer [45881,45888]
trailer [46384,46391]
===
match
---
name: unfinished [73736,73746]
name: unfinished [74239,74249]
===
match
---
simple_stmt [1093,1172]
simple_stmt [1093,1172]
===
match
---
name: dag_run [80663,80670]
name: dag_run [81166,81173]
===
match
---
name: reset_tis_message [81512,81529]
name: reset_tis_message [82015,82032]
===
match
---
param [23885,23901]
param [23885,23901]
===
match
---
atom_expr [7727,7769]
atom_expr [7727,7769]
===
match
---
name: exception [65257,65266]
name: exception [65760,65769]
===
match
---
fstring [16921,16968]
fstring [16921,16968]
===
match
---
argument [22338,22365]
argument [22338,22365]
===
match
---
name: num_runs [29766,29774]
name: num_runs [30020,30028]
===
match
---
simple_stmt [51859,51884]
simple_stmt [52362,52387]
===
match
---
dotted_name [2890,2914]
dotted_name [2890,2914]
===
match
---
name: query [73561,73566]
name: query [74064,74069]
===
match
---
name: task_id [17368,17375]
name: task_id [17368,17375]
===
match
---
name: self [27097,27101]
name: self [27097,27101]
===
match
---
trailer [40090,40112]
trailer [40593,40615]
===
match
---
expr_stmt [65797,65855]
expr_stmt [66300,66358]
===
match
---
simple_stmt [1062,1093]
simple_stmt [1062,1093]
===
match
---
name: deactivate_stale_dags [55302,55323]
name: deactivate_stale_dags [55805,55826]
===
match
---
simple_stmt [3034,3077]
simple_stmt [3034,3077]
===
match
---
name: DagFileProcessorProcess [56238,56261]
name: DagFileProcessorProcess [56741,56764]
===
match
---
operator: = [34333,34334]
operator: = [34836,34837]
===
match
---
name: property [14349,14357]
name: property [14349,14357]
===
match
---
name: airflow [1574,1581]
name: airflow [1574,1581]
===
match
---
string: 'scheduler.critical_section_busy' [66514,66547]
string: 'scheduler.critical_section_busy' [67017,67050]
===
match
---
trailer [11484,11493]
trailer [11484,11493]
===
match
---
arglist [20988,21055]
arglist [20988,21055]
===
match
---
argument [68616,68631]
argument [69119,69134]
===
match
---
operator: = [49239,49240]
operator: = [49742,49743]
===
match
---
name: TI [36641,36643]
name: TI [37144,37146]
===
match
---
return_stmt [74645,74653]
return_stmt [75148,75156]
===
match
---
operator: = [24160,24161]
operator: = [24160,24161]
===
match
---
atom_expr [30707,30718]
atom_expr [30961,30972]
===
match
---
name: recv [12512,12516]
name: recv [12512,12516]
===
match
---
comparison [71266,71311]
comparison [71769,71814]
===
match
---
arglist [78834,78881]
arglist [79337,79384]
===
match
---
trailer [66326,66338]
trailer [66829,66841]
===
match
---
operator: == [73666,73668]
operator: == [74169,74171]
===
match
---
name: OperationalError [82542,82558]
name: OperationalError [83045,83061]
===
match
---
name: Connection [1132,1142]
name: Connection [1132,1142]
===
match
---
comparison [9904,9925]
comparison [9904,9925]
===
match
---
name: session [22412,22419]
name: session [22412,22419]
===
match
---
trailer [50864,50893]
trailer [51367,51396]
===
match
---
name: session [75578,75585]
name: session [76081,76088]
===
match
---
atom_expr [74808,74830]
atom_expr [75311,75333]
===
match
---
with_item [58519,58546]
with_item [59022,59049]
===
match
---
operator: = [46751,46752]
operator: = [47254,47255]
===
match
---
parameters [56088,56234]
parameters [56591,56737]
===
match
---
name: query [64422,64427]
name: query [64925,64930]
===
match
---
name: DefaultDict [40027,40038]
name: DefaultDict [40530,40541]
===
match
---
operator: , [56227,56228]
operator: , [56730,56731]
===
match
---
suite [11128,11170]
suite [11128,11170]
===
match
---
suite [30259,30288]
suite [30513,30542]
===
match
---
simple_stmt [39430,39452]
simple_stmt [39933,39955]
===
match
---
name: using_sqlite [53992,54004]
name: using_sqlite [54495,54507]
===
match
---
atom_expr [81571,81579]
atom_expr [82074,82082]
===
match
---
trailer [26795,26800]
trailer [26795,26800]
===
match
---
trailer [48527,48536]
trailer [49030,49039]
===
match
---
atom_expr [59073,59128]
atom_expr [59576,59631]
===
match
---
trailer [66022,66063]
trailer [66525,66566]
===
match
---
comparison [53682,53731]
comparison [54185,54234]
===
match
---
atom_expr [71743,71825]
atom_expr [72246,72328]
===
match
---
funcdef [5016,5075]
funcdef [5016,5075]
===
match
---
name: self [23298,23302]
name: self [23298,23302]
===
match
---
atom_expr [16288,16296]
atom_expr [16288,16296]
===
match
---
name: dag_ids [27315,27322]
name: dag_ids [27315,27322]
===
match
---
import_name [896,905]
import_name [896,905]
===
match
---
simple_stmt [50065,50125]
simple_stmt [50568,50628]
===
match
---
atom_expr [80976,80985]
atom_expr [81479,81488]
===
match
---
trailer [33833,33840]
trailer [34336,34343]
===
match
---
atom_expr [36468,36494]
atom_expr [36971,36997]
===
match
---
string: """         Finds TIs that are ready for execution with respect to pool limits,         dag concurrency, executor state, and priority.          :param max_tis: Maximum number of TIs to queue in this loop.         :type max_tis: int         :return: list[airflow.models.TaskInstance]         """ [37194,37488]
string: """         Finds TIs that are ready for execution with respect to pool limits,         dag concurrency, executor state, and priority.          :param max_tis: Maximum number of TIs to queue in this loop.         :type max_tis: int         :return: list[airflow.models.TaskInstance]         """ [37697,37991]
===
match
---
arglist [77412,77429]
arglist [77915,77932]
===
match
---
comp_op [69531,69537]
comp_op [70034,70040]
===
match
---
operator: , [47308,47309]
operator: , [47811,47812]
===
match
---
trailer [10541,10555]
trailer [10541,10555]
===
match
---
suite [73822,73920]
suite [74325,74423]
===
match
---
trailer [60980,60984]
trailer [61483,61487]
===
match
---
name: query [38841,38846]
name: query [39344,39349]
===
match
---
name: Exception [20841,20850]
name: Exception [20841,20850]
===
match
---
trailer [71380,71382]
trailer [71883,71885]
===
match
---
parameters [31065,31086]
parameters [31319,31340]
===
match
---
trailer [57282,57308]
trailer [57785,57811]
===
match
---
trailer [17290,17297]
trailer [17290,17297]
===
match
---
operator: , [30368,30369]
operator: , [30622,30623]
===
match
---
atom_expr [24043,24178]
atom_expr [24043,24178]
===
match
---
expr_stmt [41866,41907]
expr_stmt [42369,42410]
===
match
---
operator: { [17025,17026]
operator: { [17025,17026]
===
match
---
tfpdef [5284,5312]
tfpdef [5284,5312]
===
match
---
name: redirect_stderr [7069,7084]
name: redirect_stderr [7069,7084]
===
match
---
comparison [48472,48499]
comparison [48975,49002]
===
match
---
trailer [66321,66326]
trailer [66824,66829]
===
match
---
trailer [30679,30686]
trailer [30933,30940]
===
match
---
trailer [35274,35276]
trailer [35777,35779]
===
match
---
atom_expr [81952,81965]
atom_expr [82455,82468]
===
match
---
for_stmt [27484,27546]
for_stmt [27484,27546]
===
match
---
atom_expr [35372,35406]
atom_expr [35875,35909]
===
match
---
annassign [36742,36796]
annassign [37245,37299]
===
match
---
atom_expr [79475,79493]
atom_expr [79978,79996]
===
match
---
number: 0 [71920,71921]
number: 0 [72423,72424]
===
match
---
name: log [59078,59081]
name: log [59581,59584]
===
match
---
suite [18263,18508]
suite [18263,18508]
===
match
---
trailer [53667,53677]
trailer [54170,54180]
===
match
---
simple_stmt [15781,15836]
simple_stmt [15781,15836]
===
match
---
operator: = [24025,24026]
operator: = [24025,24026]
===
match
---
name: OperationalError [60876,60892]
name: OperationalError [61379,61395]
===
match
---
operator: = [36707,36708]
operator: = [37210,37211]
===
match
---
name: List [37176,37180]
name: List [37679,37683]
===
match
---
simple_stmt [30521,30597]
simple_stmt [30775,30851]
===
match
---
name: query [38897,38902]
name: query [39400,39405]
===
match
---
comparison [16536,16559]
comparison [16536,16559]
===
match
---
expr_stmt [20568,20593]
expr_stmt [20568,20593]
===
match
---
name: sync_to_db [27205,27215]
name: sync_to_db [27205,27215]
===
match
---
for_stmt [68510,70333]
for_stmt [69013,70836]
===
match
---
name: airflow [1867,1874]
name: airflow [1867,1874]
===
match
---
name: dag_run [76625,76632]
name: dag_run [77128,77135]
===
match
---
dictorsetmaker [34974,35074]
dictorsetmaker [35477,35577]
===
match
---
decorated [32694,35865]
decorated [33197,36368]
===
match
---
name: pool_to_task_instances [39848,39870]
name: pool_to_task_instances [40351,40373]
===
match
---
name: session [69867,69874]
name: session [70370,70377]
===
match
---
name: utcnow [22357,22363]
name: utcnow [22357,22363]
===
match
---
tfpdef [5233,5247]
tfpdef [5233,5247]
===
match
---
operator: , [18125,18126]
operator: , [18125,18126]
===
match
---
name: self [66951,66955]
name: self [67454,67458]
===
match
---
string: """         If there are tasks left over in the executor,         we set them back to SCHEDULED to avoid creating hanging tasks.          :param session: session for ORM operations         """ [48948,49140]
string: """         If there are tasks left over in the executor,         we set them back to SCHEDULED to avoid creating hanging tasks.          :param session: session for ORM operations         """ [49451,49643]
===
match
---
name: ImportError [22098,22109]
name: ImportError [22098,22109]
===
match
---
name: filter_for_tis [45588,45602]
name: filter_for_tis [46091,46105]
===
match
---
expr_stmt [50065,50124]
expr_stmt [50568,50627]
===
match
---
trailer [42156,42164]
trailer [42659,42667]
===
match
---
atom_expr [29559,29612]
atom_expr [29813,29866]
===
match
---
operator: , [64289,64290]
operator: , [64792,64793]
===
match
---
name: dag_id [36862,36868]
name: dag_id [37365,37371]
===
match
---
suite [55896,55986]
suite [56399,56489]
===
match
---
name: Tuple [1241,1246]
name: Tuple [1241,1246]
===
match
---
trailer [8122,8131]
trailer [8122,8131]
===
match
---
simple_stmt [79347,79727]
simple_stmt [79850,80230]
===
match
---
simple_stmt [4796,4863]
simple_stmt [4796,4863]
===
match
---
trailer [75391,75425]
trailer [75894,75928]
===
match
---
atom_expr [16261,16269]
atom_expr [16261,16269]
===
match
---
trailer [50084,50099]
trailer [50587,50602]
===
match
---
atom_expr [21213,21227]
atom_expr [21213,21227]
===
match
---
expr_stmt [68372,68500]
expr_stmt [68875,69003]
===
match
---
return_stmt [12715,12726]
return_stmt [12715,12726]
===
match
---
operator: , [78134,78135]
operator: , [78637,78638]
===
match
---
name: self [13135,13139]
name: self [13135,13139]
===
match
---
name: dag_id [64154,64160]
name: dag_id [64657,64663]
===
match
---
atom_expr [7102,7136]
atom_expr [7102,7136]
===
match
---
atom_expr [67994,68007]
atom_expr [68497,68510]
===
match
---
simple_stmt [51735,51771]
simple_stmt [52238,52274]
===
match
---
name: str [32788,32791]
name: str [33291,33294]
===
match
---
name: Optional [5293,5301]
name: Optional [5293,5301]
===
match
---
expr_stmt [42111,42164]
expr_stmt [42614,42667]
===
match
---
funcdef [77175,77804]
funcdef [77678,78307]
===
match
---
trailer [68827,68834]
trailer [69330,69337]
===
match
---
name: processor_agent [58144,58159]
name: processor_agent [58647,58662]
===
match
---
trailer [44978,44985]
trailer [45481,45488]
===
match
---
simple_stmt [77465,77548]
simple_stmt [77968,78051]
===
match
---
argument [18674,18748]
argument [18674,18748]
===
match
---
name: self [40943,40947]
name: self [41446,41450]
===
match
---
name: timedelta [15874,15883]
name: timedelta [15874,15883]
===
match
---
name: DagModel [67368,67376]
name: DagModel [67871,67879]
===
match
---
trailer [51755,51762]
trailer [52258,52265]
===
match
---
expr_stmt [24273,24313]
expr_stmt [24273,24313]
===
match
---
trailer [52240,52252]
trailer [52743,52755]
===
match
---
operator: , [29476,29477]
operator: , [29730,29731]
===
match
---
expr_stmt [63923,63963]
expr_stmt [64426,64466]
===
match
---
trailer [24844,24850]
trailer [24844,24850]
===
match
---
trailer [73560,73566]
trailer [74063,74069]
===
match
---
name: base_job [1780,1788]
name: base_job [1780,1788]
===
match
---
operator: , [68754,68755]
operator: , [69257,69258]
===
match
---
name: DagRun [76113,76119]
name: DagRun [76616,76622]
===
match
---
arglist [56371,56469]
arglist [56874,56972]
===
match
---
name: isinstance [20505,20515]
name: isinstance [20505,20515]
===
match
---
trailer [82108,82113]
trailer [82611,82616]
===
match
---
expr_stmt [44617,44646]
expr_stmt [45120,45149]
===
match
---
name: ignore_all_deps [46690,46705]
name: ignore_all_deps [47193,47208]
===
match
---
name: set [65165,65168]
name: set [65668,65671]
===
match
---
operator: == [71188,71190]
operator: == [71691,71693]
===
match
---
operator: , [51634,51635]
operator: , [52137,52138]
===
match
---
name: Stats [35806,35811]
name: Stats [36309,36314]
===
match
---
operator: } [50242,50243]
operator: } [50745,50746]
===
match
---
operator: , [82287,82288]
operator: , [82790,82791]
===
match
---
trailer [40192,40262]
trailer [40695,40765]
===
match
---
simple_stmt [35573,35589]
simple_stmt [36076,36092]
===
match
---
trailer [16290,16296]
trailer [16290,16296]
===
match
---
atom_expr [72021,72268]
atom_expr [72524,72771]
===
match
---
operator: , [69913,69914]
operator: , [70416,70417]
===
match
---
suite [43836,44140]
suite [44339,44643]
===
match
---
atom_expr [80892,80905]
atom_expr [81395,81408]
===
match
---
return_stmt [36978,37002]
return_stmt [37481,37505]
===
match
---
simple_stmt [14397,14427]
simple_stmt [14397,14427]
===
match
---
name: queued_dttm [50225,50236]
name: queued_dttm [50728,50739]
===
match
---
name: Session [22559,22566]
name: Session [22559,22566]
===
match
---
try_stmt [79322,82625]
try_stmt [79825,83128]
===
match
---
name: dag_processing [2374,2388]
name: dag_processing [2374,2388]
===
match
---
trailer [18344,18353]
trailer [18344,18353]
===
match
---
trailer [16346,16350]
trailer [16346,16350]
===
match
---
fstring_end: " [9269,9270]
fstring_end: " [9269,9270]
===
match
---
operator: , [31722,31723]
operator: , [32225,32226]
===
match
---
operator: = [40294,40295]
operator: = [40797,40798]
===
match
---
trailer [80882,80888]
trailer [81385,81391]
===
match
---
name: session [21406,21413]
name: session [21406,21413]
===
match
---
operator: , [24016,24017]
operator: , [24016,24017]
===
match
---
simple_stmt [2113,2178]
simple_stmt [2113,2178]
===
match
---
trailer [27356,27361]
trailer [27356,27361]
===
match
---
trailer [17508,17514]
trailer [17508,17514]
===
match
---
name: of [39020,39022]
name: of [39523,39525]
===
match
---
trailer [67171,67175]
trailer [67674,67678]
===
match
---
trailer [39773,39779]
trailer [40276,40282]
===
match
---
name: dag [77783,77786]
name: dag [78286,78289]
===
match
---
operator: , [78409,78410]
operator: , [78912,78913]
===
match
---
argument [69615,69644]
argument [70118,70147]
===
match
---
number: 0 [38054,38055]
number: 0 [38557,38558]
===
match
---
name: str [50865,50868]
name: str [51368,51371]
===
match
---
operator: , [33962,33963]
operator: , [34465,34466]
===
match
---
trailer [34356,34360]
trailer [34859,34863]
===
match
---
expr_stmt [15327,15349]
expr_stmt [15327,15349]
===
match
---
trailer [23338,23345]
trailer [23338,23345]
===
match
---
trailer [22426,22428]
trailer [22426,22428]
===
match
---
name: self [43241,43245]
name: self [43744,43748]
===
match
---
operator: , [20533,20534]
operator: , [20533,20534]
===
match
---
name: SimpleTaskInstance [53136,53154]
name: SimpleTaskInstance [53639,53657]
===
match
---
trailer [58494,58496]
trailer [58997,58999]
===
match
---
name: self [10323,10327]
name: self [10323,10327]
===
match
---
trailer [36904,36912]
trailer [37407,37415]
===
match
---
import_name [858,872]
import_name [858,872]
===
match
---
name: dag_id [42813,42819]
name: dag_id [43316,43322]
===
match
---
name: State [60516,60521]
name: State [61019,61024]
===
match
---
name: processor_agent [54849,54864]
name: processor_agent [55352,55367]
===
match
---
name: Session [70626,70633]
name: Session [71129,71136]
===
match
---
name: serialized_dag [43224,43238]
name: serialized_dag [43727,43741]
===
match
---
name: Set [1236,1239]
name: Set [1236,1239]
===
match
---
simple_stmt [1383,1434]
simple_stmt [1383,1434]
===
match
---
name: str [36762,36765]
name: str [37265,37268]
===
match
---
name: datetime [50875,50883]
name: datetime [51378,51386]
===
match
---
trailer [24773,24784]
trailer [24773,24784]
===
match
---
simple_stmt [16709,16732]
simple_stmt [16709,16732]
===
match
---
name: DagRun [67994,68000]
name: DagRun [68497,68503]
===
match
---
atom_expr [7053,7065]
atom_expr [7053,7065]
===
match
---
trailer [35180,35193]
trailer [35683,35696]
===
match
---
operator: , [16286,16287]
operator: , [16286,16287]
===
match
---
trailer [8065,8070]
trailer [8065,8070]
===
match
---
arglist [7624,7688]
arglist [7624,7688]
===
match
---
name: _process [13566,13574]
name: _process [13566,13574]
===
match
---
operator: @ [25146,25147]
operator: @ [25146,25147]
===
match
---
name: dag_model [53076,53085]
name: dag_model [53579,53588]
===
match
---
operator: = [77762,77763]
operator: = [78265,78266]
===
match
---
suite [61085,61112]
suite [61588,61615]
===
match
---
name: models [33580,33586]
name: models [34083,34089]
===
match
---
trailer [7561,7576]
trailer [7561,7576]
===
match
---
simple_stmt [25065,25141]
simple_stmt [25065,25141]
===
match
---
operator: = [81637,81638]
operator: = [82140,82141]
===
match
---
argument [34288,34293]
argument [34791,34796]
===
match
---
operator: , [49335,49336]
operator: , [49838,49839]
===
match
---
name: models [37726,37732]
name: models [38229,38235]
===
match
---
string: "Tasks using non-existent pool '%s' will not be scheduled" [40749,40807]
string: "Tasks using non-existent pool '%s' will not be scheduled" [41252,41310]
===
match
---
fstring_end: ' [78055,78056]
fstring_end: ' [78558,78559]
===
match
---
simple_stmt [55617,55637]
simple_stmt [56120,56140]
===
match
---
name: task_id [43722,43729]
name: task_id [44225,44232]
===
match
---
name: task_id [36853,36860]
name: task_id [37356,37363]
===
match
---
trailer [10589,10594]
trailer [10589,10594]
===
match
---
name: next_dagrun [72371,72382]
name: next_dagrun [72874,72885]
===
match
---
operator: , [23838,23839]
operator: , [23838,23839]
===
match
---
name: log [8263,8266]
name: log [8263,8266]
===
match
---
simple_stmt [66503,66549]
simple_stmt [67006,67052]
===
match
---
arglist [35818,35863]
arglist [36321,36366]
===
match
---
trailer [20586,20592]
trailer [20586,20592]
===
match
---
name: reason [24133,24139]
name: reason [24133,24139]
===
match
---
name: signal [30938,30944]
name: signal [31192,31198]
===
match
---
trailer [24147,24151]
trailer [24147,24151]
===
match
---
atom_expr [65165,65170]
atom_expr [65668,65673]
===
match
---
name: session [66569,66576]
name: session [67072,67079]
===
match
---
name: is_lock_not_available_error [66359,66386]
name: is_lock_not_available_error [66862,66889]
===
match
---
operator: = [29557,29558]
operator: = [29811,29812]
===
match
---
name: _start_time [14331,14342]
name: _start_time [14331,14342]
===
match
---
suite [31475,31822]
suite [31852,32325]
===
match
---
operator: = [47270,47271]
operator: = [47773,47774]
===
match
---
name: conf [1603,1607]
name: conf [1603,1607]
===
match
---
funcdef [47329,48836]
funcdef [47832,49339]
===
match
---
name: try_number [49578,49588]
name: try_number [50081,50091]
===
match
---
trailer [73348,73363]
trailer [73851,73866]
===
match
---
trailer [73135,73142]
trailer [73638,73645]
===
match
---
atom_expr [38905,38925]
atom_expr [39408,39428]
===
match
---
name: TaskNotFound [19924,19936]
name: TaskNotFound [19924,19936]
===
match
---
except_clause [26563,26579]
except_clause [26563,26579]
===
match
---
return_stmt [51859,51883]
return_stmt [52362,52386]
===
match
---
trailer [39897,39912]
trailer [40400,40415]
===
match
---
name: DagModel [27272,27280]
name: DagModel [27272,27280]
===
match
---
operator: , [26972,26973]
operator: , [26972,26973]
===
match
---
trailer [4482,4492]
trailer [4482,4492]
===
match
---
operator: = [40163,40164]
operator: = [40666,40667]
===
match
---
name: self [65560,65564]
name: self [66063,66067]
===
match
---
name: SlaMiss [17711,17718]
name: SlaMiss [17711,17718]
===
match
---
operator: - [73419,73420]
operator: - [73922,73923]
===
match
---
operator: = [34521,34522]
operator: = [35024,35025]
===
match
---
name: timer [66316,66321]
name: timer [66819,66824]
===
match
---
name: self [31419,31423]
name: self [31796,31800]
===
match
---
trailer [45191,45241]
trailer [45694,45744]
===
match
---
operator: , [29370,29371]
operator: , [29624,29625]
===
match
---
operator: @ [32694,32695]
operator: @ [33197,33198]
===
match
---
name: next_dagrun [69691,69702]
name: next_dagrun [70194,70205]
===
match
---
fstring_expr [70256,70268]
fstring_expr [70759,70771]
===
match
---
name: or_ [67920,67923]
name: or_ [68423,68426]
===
match
---
string: "\n\t" [39526,39532]
string: "\n\t" [40029,40035]
===
match
---
if_stmt [76339,76506]
if_stmt [76842,77009]
===
match
---
name: commit [61130,61136]
name: commit [61633,61639]
===
match
---
trailer [53370,53377]
trailer [53873,53880]
===
match
---
del_stmt [9569,9587]
del_stmt [9569,9587]
===
match
---
name: set [20440,20443]
name: set [20440,20443]
===
match
---
name: primary [51287,51294]
name: primary [51790,51797]
===
match
---
operator: , [5388,5389]
operator: , [5388,5389]
===
match
---
name: Optional [30627,30635]
name: Optional [30881,30889]
===
match
---
operator: == [39346,39348]
operator: == [39849,39851]
===
match
---
operator: , [46866,46867]
operator: , [47369,47370]
===
match
---
operator: -> [15457,15459]
operator: -> [15457,15459]
===
match
---
name: self [13271,13275]
name: self [13271,13275]
===
match
---
operator: = [50926,50927]
operator: = [51429,51430]
===
match
---
name: AirflowException [11411,11427]
name: AirflowException [11411,11427]
===
match
---
atom_expr [78248,78261]
atom_expr [78751,78764]
===
match
---
trailer [77118,77134]
trailer [77621,77637]
===
match
---
name: self [32540,32544]
name: self [33043,33047]
===
match
---
name: try_number [49735,49745]
name: try_number [50238,50248]
===
match
---
trailer [80132,80139]
trailer [80635,80642]
===
match
---
name: update_import_errors [27002,27022]
name: update_import_errors [27002,27022]
===
match
---
trailer [46593,46608]
trailer [47096,47111]
===
match
---
arglist [17675,17739]
arglist [17675,17739]
===
match
---
simple_stmt [55998,56035]
simple_stmt [56501,56538]
===
match
---
trailer [52062,52089]
trailer [52565,52592]
===
match
---
trailer [16260,16314]
trailer [16260,16314]
===
match
---
trailer [13536,13542]
trailer [13536,13542]
===
match
---
name: State [51704,51709]
name: State [52207,52212]
===
match
---
string: "Killing DAGFileProcessorProcess (PID=%d)" [10978,11020]
string: "Killing DAGFileProcessorProcess (PID=%d)" [10978,11020]
===
match
---
trailer [16518,16670]
trailer [16518,16670]
===
match
---
trailer [58183,58185]
trailer [58686,58688]
===
match
---
trailer [71128,71135]
trailer [71631,71638]
===
match
---
name: _create_dag_file_processor [54352,54378]
name: _create_dag_file_processor [54855,54881]
===
match
---
name: query [67089,67094]
name: query [67592,67597]
===
match
---
atom_expr [13937,13998]
atom_expr [13937,13998]
===
match
---
name: request [24285,24292]
name: request [24285,24292]
===
match
---
simple_stmt [31671,31754]
simple_stmt [32174,32257]
===
match
---
trailer [15307,15316]
trailer [15307,15316]
===
match
---
tfpdef [37134,37146]
tfpdef [37637,37649]
===
match
---
trailer [74027,74034]
trailer [74530,74537]
===
match
---
atom_expr [68691,68773]
atom_expr [69194,69276]
===
match
---
simple_stmt [30337,30398]
simple_stmt [30591,30652]
===
match
---
name: result_channel [5131,5145]
name: result_channel [5131,5145]
===
match
---
expr_stmt [54014,54096]
expr_stmt [54517,54599]
===
match
---
name: self [59655,59659]
name: self [60158,60162]
===
match
---
argument [37750,37764]
argument [38253,38267]
===
match
---
name: DAG [77223,77226]
name: DAG [77726,77729]
===
match
---
trailer [10454,10464]
trailer [10454,10464]
===
match
---
trailer [10737,10739]
trailer [10737,10739]
===
match
---
atom_expr [53202,53210]
atom_expr [53705,53713]
===
match
---
trailer [16624,16639]
trailer [16624,16639]
===
match
---
arglist [30885,30921]
arglist [31139,31175]
===
match
---
if_stmt [23105,23484]
if_stmt [23105,23484]
===
match
---
operator: = [58743,58744]
operator: = [59246,59247]
===
match
---
name: gauge [78020,78025]
name: gauge [78523,78528]
===
match
---
trailer [25033,25043]
trailer [25033,25043]
===
match
---
suite [17883,21358]
suite [17883,21358]
===
match
---
atom_expr [26625,26693]
atom_expr [26625,26693]
===
match
---
name: request [24140,24147]
name: request [24140,24147]
===
match
---
atom_expr [4468,4493]
atom_expr [4468,4493]
===
match
---
name: merge [17329,17334]
name: merge [17329,17334]
===
match
---
name: is_ [80581,80584]
name: is_ [81084,81087]
===
match
---
name: load_op_links [30744,30757]
name: load_op_links [30998,31011]
===
match
---
operator: , [2966,2967]
operator: , [2966,2967]
===
match
---
argument [69724,69752]
argument [70227,70255]
===
match
---
fstring_start: f" [20677,20679]
fstring_start: f" [20677,20679]
===
match
---
trailer [77349,77360]
trailer [77852,77863]
===
match
---
trailer [38424,38432]
trailer [38927,38935]
===
match
---
trailer [18031,18037]
trailer [18031,18037]
===
match
---
name: get_dag [73120,73127]
name: get_dag [73623,73630]
===
match
---
operator: , [60317,60318]
operator: , [60820,60821]
===
match
---
name: unfinished_task_instances [73796,73821]
name: unfinished_task_instances [74299,74324]
===
match
---
atom_expr [67964,68108]
atom_expr [68467,68611]
===
match
---
atom_expr [74239,74480]
atom_expr [74742,74983]
===
match
---
name: current_dag_concurrency [42111,42134]
name: current_dag_concurrency [42614,42637]
===
match
---
name: query [34281,34286]
name: query [34784,34789]
===
match
---
trailer [4876,4892]
trailer [4876,4892]
===
match
---
param [8555,8559]
param [8555,8559]
===
match
---
name: self [48523,48527]
name: self [49026,49030]
===
match
---
operator: = [22567,22568]
operator: = [22567,22568]
===
match
---
simple_stmt [49801,49871]
simple_stmt [50304,50374]
===
match
---
name: session [24026,24033]
name: session [24026,24033]
===
match
---
atom_expr [52144,52192]
atom_expr [52647,52695]
===
match
---
name: start [9375,9380]
name: start [9375,9380]
===
match
---
comparison [38035,38055]
comparison [38538,38558]
===
match
---
atom_expr [23666,23692]
atom_expr [23666,23692]
===
match
---
name: simple_task_instance [24293,24313]
name: simple_task_instance [24293,24313]
===
match
---
name: active_dagruns_filter [68462,68483]
name: active_dagruns_filter [68965,68986]
===
match
---
trailer [80139,80172]
trailer [80642,80675]
===
match
---
trailer [6800,6802]
trailer [6800,6802]
===
match
---
atom_expr [36026,36041]
atom_expr [36529,36544]
===
match
---
atom_expr [50875,50892]
atom_expr [51378,51395]
===
match
---
name: request [23331,23338]
name: request [23331,23338]
===
match
---
trailer [51709,51716]
trailer [52212,52219]
===
match
---
string: "Tried to get exit code before starting!" [11796,11837]
string: "Tried to get exit code before starting!" [11796,11837]
===
match
---
atom_expr [60485,60503]
atom_expr [60988,61006]
===
match
---
trailer [74172,74176]
trailer [74675,74679]
===
match
---
trailer [6850,6866]
trailer [6850,6866]
===
match
---
comparison [11366,11391]
comparison [11366,11391]
===
match
---
name: Logger [29668,29674]
name: Logger [29922,29928]
===
match
---
simple_stmt [9290,9314]
simple_stmt [9290,9314]
===
match
---
operator: , [3206,3207]
operator: , [3206,3207]
===
match
---
param [31846,31886]
param [32349,32389]
===
match
---
atom_expr [43865,44102]
atom_expr [44368,44605]
===
match
---
trailer [47077,47158]
trailer [47580,47661]
===
match
---
name: ti [24867,24869]
name: ti [24867,24869]
===
match
---
trailer [80496,80506]
trailer [80999,81009]
===
match
---
trailer [17016,17023]
trailer [17016,17023]
===
match
---
atom_expr [15174,15215]
atom_expr [15174,15215]
===
match
---
operator: = [7584,7585]
operator: = [7584,7585]
===
match
---
trailer [69955,69958]
trailer [70458,70461]
===
match
---
operator: { [45063,45064]
operator: { [45566,45567]
===
match
---
trailer [17718,17725]
trailer [17718,17725]
===
match
---
atom_expr [57590,57624]
atom_expr [58093,58127]
===
match
---
name: commit [67276,67282]
name: commit [67779,67785]
===
match
---
simple_stmt [56327,56480]
simple_stmt [56830,56983]
===
match
---
suite [4052,4997]
suite [4052,4997]
===
match
---
name: execution_date [64349,64363]
name: execution_date [64852,64866]
===
match
---
arglist [40206,40252]
arglist [40709,40755]
===
match
---
trailer [39870,39890]
trailer [40373,40393]
===
match
---
name: schedulable_tis [76009,76024]
name: schedulable_tis [76512,76527]
===
match
---
trailer [56002,56006]
trailer [56505,56509]
===
match
---
arglist [7865,7987]
arglist [7865,7987]
===
match
---
operator: , [51505,51506]
operator: , [52008,52009]
===
match
---
name: dag_model [69681,69690]
name: dag_model [70184,70193]
===
match
---
simple_stmt [23298,23348]
simple_stmt [23298,23348]
===
match
---
trailer [51680,51687]
trailer [52183,52190]
===
match
---
expr_stmt [24669,24705]
expr_stmt [24669,24705]
===
match
---
atom_expr [52218,52252]
atom_expr [52721,52755]
===
match
---
argument [24133,24151]
argument [24133,24151]
===
match
---
name: info [52272,52276]
name: info [52775,52779]
===
match
---
decorator [78285,78302]
decorator [78788,78805]
===
match
---
name: _process_executor_events [58750,58774]
name: _process_executor_events [59253,59277]
===
match
---
name: _done [11859,11864]
name: _done [11859,11864]
===
match
---
atom_expr [48589,48647]
atom_expr [49092,49150]
===
match
---
name: self [13320,13324]
name: self [13320,13324]
===
match
---
except_clause [8141,8157]
except_clause [8141,8157]
===
match
---
expr_stmt [40665,40681]
expr_stmt [41168,41184]
===
match
---
trailer [59576,59624]
trailer [60079,60127]
===
match
---
trailer [4839,4862]
trailer [4839,4862]
===
match
---
atom_expr [12633,12653]
atom_expr [12633,12653]
===
match
---
trailer [15794,15835]
trailer [15794,15835]
===
match
---
name: self [77465,77469]
name: self [77968,77972]
===
match
---
name: self [47172,47176]
name: self [47675,47679]
===
match
---
trailer [60661,60668]
trailer [61164,61171]
===
match
---
name: async_mode [53970,53980]
name: async_mode [54473,54483]
===
match
---
argument [34312,34342]
argument [34815,34845]
===
match
---
fstring_expr [45063,45074]
fstring_expr [45566,45577]
===
match
---
if_stmt [69492,70333]
if_stmt [69995,70836]
===
match
---
trailer [77915,77920]
trailer [78418,78423]
===
match
---
atom_expr [68254,68275]
atom_expr [68757,68778]
===
match
---
suite [54548,55399]
suite [55051,55902]
===
match
---
trailer [43721,43729]
trailer [44224,44232]
===
match
---
arith_expr [79573,79619]
arith_expr [80076,80122]
===
match
---
trailer [49762,49775]
trailer [50265,50278]
===
match
---
atom_expr [18354,18364]
atom_expr [18354,18364]
===
match
---
name: dag_id [65157,65163]
name: dag_id [65660,65666]
===
match
---
simple_stmt [12285,12354]
simple_stmt [12285,12354]
===
match
---
operator: = [78820,78821]
operator: = [79323,79324]
===
match
---
name: self [30675,30679]
name: self [30929,30933]
===
match
---
arglist [45192,45240]
arglist [45695,45743]
===
match
---
parameters [14060,14066]
parameters [14060,14066]
===
match
---
string: 'unit_test_mode' [57291,57307]
string: 'unit_test_mode' [57794,57810]
===
match
---
trailer [24001,24016]
trailer [24001,24016]
===
match
---
operator: , [52533,52534]
operator: , [53036,53037]
===
match
---
name: getfloat [29564,29572]
name: getfloat [29818,29826]
===
match
---
name: multiprocessing [1098,1113]
name: multiprocessing [1098,1113]
===
match
---
name: NONE [81588,81592]
name: NONE [82091,82095]
===
match
---
atom_expr [80507,80523]
atom_expr [81010,81026]
===
match
---
operator: , [30231,30232]
operator: , [30485,30486]
===
match
---
atom_expr [64003,64364]
atom_expr [64506,64867]
===
match
---
atom_expr [53018,53236]
atom_expr [53521,53739]
===
match
---
comp_op [53702,53708]
comp_op [54205,54211]
===
match
---
name: defaultdict [36780,36791]
name: defaultdict [37283,37294]
===
match
---
atom_expr [33739,33981]
atom_expr [34242,34484]
===
match
---
name: dag_id [17719,17725]
name: dag_id [17719,17725]
===
match
---
name: dag [75198,75201]
name: dag [75701,75704]
===
match
---
trailer [81355,81380]
trailer [81858,81883]
===
match
---
trailer [54643,54660]
trailer [55146,55163]
===
match
---
trailer [64164,64212]
trailer [64667,64715]
===
match
---
name: models [35305,35311]
name: models [35808,35814]
===
match
---
operator: , [77216,77217]
operator: , [77719,77720]
===
match
---
name: settings [55357,55365]
name: settings [55860,55868]
===
match
---
decorated [13701,14027]
decorated [13701,14027]
===
match
---
trailer [6503,6510]
trailer [6503,6510]
===
match
---
if_stmt [65557,65780]
if_stmt [66060,66283]
===
match
---
simple_stmt [13621,13650]
simple_stmt [13621,13650]
===
match
---
simple_stmt [19360,19438]
simple_stmt [19360,19438]
===
match
---
name: dag_run [75392,75399]
name: dag_run [75895,75902]
===
match
---
trailer [71747,71751]
trailer [72250,72254]
===
match
---
name: TI [16622,16624]
name: TI [16622,16624]
===
match
---
operator: = [51948,51949]
operator: = [52451,52452]
===
match
---
arglist [29299,29337]
arglist [29553,29591]
===
match
---
name: ti_key [51280,51286]
name: ti_key [51783,51789]
===
match
---
operator: = [69574,69575]
operator: = [70077,70078]
===
match
---
name: self [66417,66421]
name: self [66920,66924]
===
match
---
suite [48939,50575]
suite [49442,51078]
===
match
---
expr_stmt [12476,12518]
expr_stmt [12476,12518]
===
match
---
name: types [3053,3058]
name: types [3053,3058]
===
match
---
atom_expr [51523,51537]
atom_expr [52026,52040]
===
match
---
name: self [73108,73112]
name: self [73611,73615]
===
match
---
name: Tuple [4477,4482]
name: Tuple [4477,4482]
===
match
---
atom_expr [73128,73142]
atom_expr [73631,73645]
===
match
---
string: 'SchedulerJob' [29250,29264]
string: 'SchedulerJob' [29504,29518]
===
match
---
name: str [3926,3929]
name: str [3926,3929]
===
match
---
trailer [7623,7689]
trailer [7623,7689]
===
match
---
name: notification_sent [21265,21282]
name: notification_sent [21265,21282]
===
match
---
atom_expr [81841,81854]
atom_expr [82344,82357]
===
match
---
trailer [81886,81966]
trailer [82389,82469]
===
match
---
argument [15855,15904]
argument [15855,15904]
===
match
---
name: incr [79889,79893]
name: incr [80392,80396]
===
match
---
name: session [58605,58612]
name: session [59108,59115]
===
match
---
simple_stmt [14471,15146]
simple_stmt [14471,15146]
===
match
---
name: isinstance [15855,15865]
name: isinstance [15855,15865]
===
match
---
operator: = [49810,49811]
operator: = [50313,50314]
===
match
---
operator: , [11078,11079]
operator: , [11078,11079]
===
match
---
string: '_end' [79928,79934]
string: '_end' [80431,80437]
===
match
---
name: ti [81669,81671]
name: ti [82172,82174]
===
match
---
name: min [48589,48592]
name: min [49092,49095]
===
match
---
operator: , [46608,46609]
operator: , [47111,47112]
===
match
---
expr_stmt [76515,76548]
expr_stmt [77018,77051]
===
match
---
name: items [51088,51093]
name: items [51591,51596]
===
match
---
name: _process [10574,10582]
name: _process [10574,10582]
===
match
---
trailer [74766,74772]
trailer [75269,75275]
===
match
---
simple_stmt [38833,38888]
simple_stmt [39336,39391]
===
match
---
expr_stmt [51933,51989]
expr_stmt [52436,52492]
===
match
---
name: command [46489,46496]
name: command [46992,46999]
===
match
---
name: subdir [29736,29742]
name: subdir [29990,29996]
===
match
---
simple_stmt [74217,74481]
simple_stmt [74720,74984]
===
match
---
trailer [36628,36651]
trailer [37131,37154]
===
match
---
trailer [47006,47022]
trailer [47509,47525]
===
match
---
trailer [81844,81854]
trailer [82347,82357]
===
match
---
name: log [39369,39372]
name: log [39872,39875]
===
match
---
return_stmt [14007,14026]
return_stmt [14007,14026]
===
match
---
name: DagCallbackRequest [23865,23883]
name: DagCallbackRequest [23865,23883]
===
match
---
name: dag_id [27428,27434]
name: dag_id [27428,27434]
===
match
---
suite [62875,66701]
suite [63378,67204]
===
match
---
name: MAX_DB_RETRIES [2761,2775]
name: MAX_DB_RETRIES [2761,2775]
===
match
---
if_stmt [52396,52570]
if_stmt [52899,53073]
===
match
---
trailer [40914,40930]
trailer [41417,41433]
===
match
---
operator: = [53183,53184]
operator: = [53686,53687]
===
match
---
name: TI [16212,16214]
name: TI [16212,16214]
===
match
---
simple_stmt [50913,50961]
simple_stmt [51416,51464]
===
match
---
return_stmt [13662,13673]
return_stmt [13662,13673]
===
match
---
name: max_tis [16750,16757]
name: max_tis [16750,16757]
===
match
---
name: QUEUED [52647,52653]
name: QUEUED [53150,53156]
===
match
---
trailer [45358,45361]
trailer [45861,45864]
===
match
---
name: execution_date [64072,64086]
name: execution_date [64575,64589]
===
match
---
arglist [73128,73159]
arglist [73631,73662]
===
match
---
arglist [26492,26553]
arglist [26492,26553]
===
match
---
trailer [19704,19708]
trailer [19704,19708]
===
match
---
name: exception [27738,27747]
name: exception [27738,27747]
===
match
---
simple_stmt [40006,40049]
simple_stmt [40509,40552]
===
match
---
name: using_sqlite [58105,58117]
name: using_sqlite [58608,58620]
===
match
---
name: queued_by_job_id [81746,81762]
name: queued_by_job_id [82249,82265]
===
match
---
name: reset_tis_message [82057,82074]
name: reset_tis_message [82560,82577]
===
match
---
atom_expr [25250,25271]
atom_expr [25250,25271]
===
match
---
name: bool [29633,29637]
name: bool [29887,29891]
===
match
---
operator: , [15872,15873]
operator: , [15872,15873]
===
match
---
trailer [4128,4141]
trailer [4128,4141]
===
match
---
param [77218,77226]
param [77721,77729]
===
match
---
expr_stmt [30174,30200]
expr_stmt [30428,30454]
===
match
---
trailer [49355,49370]
trailer [49858,49873]
===
match
---
expr_stmt [54105,54169]
expr_stmt [54608,54672]
===
match
---
trailer [20027,20035]
trailer [20027,20035]
===
match
---
name: log [52949,52952]
name: log [53452,53455]
===
match
---
dictorsetmaker [34632,34731]
dictorsetmaker [35135,35234]
===
match
---
name: state [25134,25139]
name: state [25134,25139]
===
match
---
tfpdef [10050,10063]
tfpdef [10050,10063]
===
match
---
trailer [38987,39109]
trailer [39490,39612]
===
match
---
name: configuration [1582,1595]
name: configuration [1582,1595]
===
match
---
atom_expr [60516,60528]
atom_expr [61019,61031]
===
match
---
name: pool_name [78224,78233]
name: pool_name [78727,78736]
===
match
---
trailer [26633,26643]
trailer [26633,26643]
===
match
---
name: MultiprocessingStartMethodMixin [2695,2726]
name: MultiprocessingStartMethodMixin [2695,2726]
===
match
---
fstring_start: f' [78026,78028]
fstring_start: f' [78529,78531]
===
match
---
name: models [2018,2024]
name: models [2018,2024]
===
match
---
name: dag [23912,23915]
name: dag [23912,23915]
===
match
---
atom_expr [52641,52653]
atom_expr [53144,53156]
===
match
---
arglist [42292,42452]
arglist [42795,42955]
===
match
---
trailer [73650,73665]
trailer [74153,74168]
===
match
---
name: NONE [60764,60768]
name: NONE [61267,61271]
===
match
---
name: tasks_missed_sla [20305,20321]
name: tasks_missed_sla [20305,20321]
===
match
---
name: file_path [5233,5242]
name: file_path [5233,5242]
===
match
---
simple_stmt [2081,2113]
simple_stmt [2081,2113]
===
match
---
expr_stmt [38833,38887]
expr_stmt [39336,39390]
===
match
---
name: self [26819,26823]
name: self [26819,26823]
===
match
---
operator: , [16073,16074]
operator: , [16073,16074]
===
match
---
name: self [30406,30410]
name: self [30660,30664]
===
match
---
simple_stmt [61045,61064]
simple_stmt [61548,61567]
===
match
---
atom [50194,50243]
atom [50697,50746]
===
match
---
operator: , [52962,52963]
operator: , [53465,53466]
===
match
---
expr_stmt [32410,32510]
expr_stmt [32913,33013]
===
match
---
name: debug [66426,66431]
name: debug [66929,66934]
===
match
---
string: "and %s task instances ready to be queued" [41055,41097]
string: "and %s task instances ready to be queued" [41558,41600]
===
match
---
fstring_end: " [16967,16968]
fstring_end: " [16967,16968]
===
match
---
annassign [51114,51119]
annassign [51617,51622]
===
match
---
name: ti [16791,16793]
name: ti [16791,16793]
===
match
---
name: filter [64123,64129]
name: filter [64626,64632]
===
match
---
name: filter [16329,16335]
name: filter [16329,16335]
===
match
---
atom [20528,20541]
atom [20528,20541]
===
match
---
trailer [46896,46906]
trailer [47399,47409]
===
match
---
name: models [33487,33493]
name: models [33990,33996]
===
match
---
name: multiprocessing [880,895]
name: multiprocessing [880,895]
===
match
---
fstring_string: pool.starving_tasks. [45043,45063]
fstring_string: pool.starving_tasks. [45546,45566]
===
match
---
comparison [24325,24356]
comparison [24325,24356]
===
match
---
simple_stmt [57810,57986]
simple_stmt [58313,58489]
===
match
---
string: "Tried to kill process before starting!" [10847,10887]
string: "Tried to kill process before starting!" [10847,10887]
===
match
---
name: SlaMiss [17675,17682]
name: SlaMiss [17675,17682]
===
match
---
trailer [55473,55477]
trailer [55976,55980]
===
match
---
name: msg [24148,24151]
name: msg [24148,24151]
===
match
---
suite [23545,23755]
suite [23545,23755]
===
match
---
name: MultiprocessingConnection [1146,1171]
name: MultiprocessingConnection [1146,1171]
===
match
---
trailer [48630,48646]
trailer [49133,49149]
===
match
---
name: items [38764,38769]
name: items [39267,39272]
===
match
---
operator: - [81702,81703]
operator: - [82205,82206]
===
match
---
simple_stmt [14097,14193]
simple_stmt [14097,14193]
===
match
---
atom_expr [57852,57930]
atom_expr [58355,58433]
===
match
---
trailer [45644,45648]
trailer [46147,46151]
===
match
---
name: dttm [17072,17076]
name: dttm [17072,17076]
===
match
---
operator: , [26681,26682]
operator: , [26681,26682]
===
match
---
name: self [4454,4458]
name: self [4454,4458]
===
match
---
atom_expr [65149,65163]
atom_expr [65652,65666]
===
match
---
operator: = [18531,18532]
operator: = [18531,18532]
===
match
---
trailer [57341,57343]
trailer [57844,57846]
===
match
---
atom_expr [48472,48494]
atom_expr [48975,48997]
===
match
---
name: getpid [7669,7675]
name: getpid [7669,7675]
===
match
---
operator: = [59028,59029]
operator: = [59531,59532]
===
match
---
argument [76641,76656]
argument [77144,77159]
===
match
---
name: session [34448,34455]
name: session [34951,34958]
===
match
---
operator: , [1844,1845]
operator: , [1844,1845]
===
match
---
simple_stmt [15919,16001]
simple_stmt [15919,16001]
===
match
---
operator: , [46573,46574]
operator: , [47076,47077]
===
match
---
name: append [18399,18405]
name: append [18399,18405]
===
match
---
param [56122,56163]
param [56625,56666]
===
match
---
string: "DAG %s already has %d active runs, not queuing any tasks for run %s" [75107,75176]
string: "DAG %s already has %d active runs, not queuing any tasks for run %s" [75610,75679]
===
match
---
expr_stmt [46489,46979]
expr_stmt [46992,47482]
===
match
---
trailer [50932,50941]
trailer [51435,51444]
===
match
---
name: try_number [52589,52599]
name: try_number [53092,53102]
===
match
---
for_stmt [39788,39913]
for_stmt [40291,40416]
===
match
---
suite [65070,65182]
suite [65573,65685]
===
match
---
operator: = [30189,30190]
operator: = [30443,30444]
===
match
---
simple_stmt [11053,11096]
simple_stmt [11053,11096]
===
match
---
operator: , [48718,48719]
operator: , [49221,49222]
===
match
---
trailer [35609,35617]
trailer [36112,36120]
===
match
---
operator: = [9223,9224]
operator: = [9223,9224]
===
match
---
operator: , [54261,54262]
operator: , [54764,54765]
===
match
---
operator: = [27307,27308]
operator: = [27307,27308]
===
match
---
simple_stmt [76238,76331]
simple_stmt [76741,76834]
===
match
---
name: filter [33715,33721]
name: filter [34218,34224]
===
match
---
operator: , [22213,22214]
operator: , [22213,22214]
===
match
---
trailer [18114,18125]
trailer [18114,18125]
===
match
---
operator: = [51013,51014]
operator: = [51516,51517]
===
match
---
trailer [32787,32792]
trailer [33290,33295]
===
match
---
trailer [31390,31396]
trailer [31767,31773]
===
match
---
annassign [7792,8005]
annassign [7792,8005]
===
match
---
trailer [57447,57449]
trailer [57950,57952]
===
match
---
arglist [71762,71824]
arglist [72265,72327]
===
match
---
name: airflow [2086,2093]
name: airflow [2086,2093]
===
match
---
suite [31130,31398]
suite [31384,31775]
===
match
---
trailer [11167,11169]
trailer [11167,11169]
===
match
---
trailer [65810,65816]
trailer [66313,66319]
===
match
---
trailer [60622,60824]
trailer [61125,61327]
===
match
---
operator: , [35350,35351]
operator: , [35853,35854]
===
match
---
atom_expr [38494,38517]
atom_expr [38997,39020]
===
match
---
name: len [39640,39643]
name: len [40143,40146]
===
match
---
trailer [76961,76996]
trailer [77464,77499]
===
match
---
simple_stmt [7282,7307]
simple_stmt [7282,7307]
===
match
---
raise_stmt [13931,13998]
raise_stmt [13931,13998]
===
match
---
name: blocking_task_list [19632,19650]
name: blocking_task_list [19632,19650]
===
match
---
trailer [12434,12439]
trailer [12434,12439]
===
match
---
argument [39068,39098]
argument [39571,39601]
===
match
---
name: state [51132,51137]
name: state [51635,51640]
===
match
---
atom_expr [73345,73363]
atom_expr [73848,73866]
===
match
---
name: provide_session [78423,78438]
name: provide_session [78926,78941]
===
match
---
name: int [32444,32447]
name: int [32947,32950]
===
match
---
name: self [53987,53991]
name: self [54490,54494]
===
match
---
name: latest_version [76238,76252]
name: latest_version [76741,76755]
===
match
---
name: _execute_task_callbacks [24188,24211]
name: _execute_task_callbacks [24188,24211]
===
match
---
arglist [48711,48735]
arglist [49214,49238]
===
match
---
arglist [23119,23147]
arglist [23119,23147]
===
match
---
operator: = [76624,76625]
operator: = [77127,77128]
===
match
---
trailer [31364,31368]
trailer [31741,31745]
===
match
---
trailer [65168,65170]
trailer [65671,65673]
===
match
---
operator: = [48587,48588]
operator: = [49090,49091]
===
match
---
name: active_dagruns [68372,68386]
name: active_dagruns [68875,68889]
===
match
---
atom_expr [36641,36650]
atom_expr [37144,37153]
===
match
---
name: str [36479,36482]
name: str [36982,36985]
===
match
---
name: self [11022,11026]
name: self [11022,11026]
===
match
---
name: log [13533,13536]
name: log [13533,13536]
===
match
---
name: session [33473,33480]
name: session [33976,33983]
===
match
---
suite [76932,76997]
suite [77435,77500]
===
match
---
name: self [4196,4200]
name: self [4196,4200]
===
match
---
arglist [10978,11039]
arglist [10978,11039]
===
match
---
tfpdef [23840,23854]
tfpdef [23840,23854]
===
match
---
operator: , [57789,57790]
operator: , [58292,58293]
===
match
---
operator: , [74390,74391]
operator: , [74893,74894]
===
match
---
operator: , [31742,31743]
operator: , [32245,32246]
===
match
---
simple_stmt [31344,31371]
simple_stmt [31721,31748]
===
match
---
argument [18543,18612]
argument [18543,18612]
===
match
---
name: ts [17437,17439]
name: ts [17437,17439]
===
match
---
name: dag_id [74028,74034]
name: dag_id [74531,74537]
===
match
---
arglist [15866,15883]
arglist [15866,15883]
===
match
---
trailer [35311,35324]
trailer [35814,35827]
===
match
---
name: dag_id [71356,71362]
name: dag_id [71859,71865]
===
match
---
trailer [24491,24510]
trailer [24491,24510]
===
match
---
name: expunge_all [65477,65488]
name: expunge_all [65980,65991]
===
match
---
simple_stmt [71743,71826]
simple_stmt [72246,72329]
===
match
---
name: TaskInstance [35379,35391]
name: TaskInstance [35882,35894]
===
match
---
operator: = [24283,24284]
operator: = [24283,24284]
===
match
---
name: dag_run [76515,76522]
name: dag_run [77018,77025]
===
match
---
operator: = [41378,41379]
operator: = [41881,41882]
===
match
---
name: dag_id [16553,16559]
name: dag_id [16553,16559]
===
match
---
name: TI [16063,16065]
name: TI [16063,16065]
===
match
---
name: log [73199,73202]
name: log [73702,73705]
===
match
---
name: self [26384,26388]
name: self [26384,26388]
===
match
---
atom_expr [11480,11497]
atom_expr [11480,11497]
===
match
---
factor [29514,29516]
factor [29768,29770]
===
match
---
simple_stmt [13498,13516]
simple_stmt [13498,13516]
===
match
---
name: utcnow [69744,69750]
name: utcnow [70247,70253]
===
match
---
name: group_by [16379,16387]
name: group_by [16379,16387]
===
match
---
trailer [7799,7809]
trailer [7799,7809]
===
match
---
simple_stmt [40831,40840]
simple_stmt [41334,41343]
===
match
---
atom_expr [5367,5388]
atom_expr [5367,5388]
===
match
---
string: 'processor_poll_interval' [29586,29611]
string: 'processor_poll_interval' [29840,29865]
===
match
---
name: ti_primary_key_to_try_number_map [52144,52176]
name: ti_primary_key_to_try_number_map [52647,52679]
===
match
---
trailer [16552,16559]
trailer [16552,16559]
===
match
---
name: self [13726,13730]
name: self [13726,13730]
===
match
---
operator: = [29743,29744]
operator: = [29997,29998]
===
match
---
operator: , [33863,33864]
operator: , [34366,34367]
===
match
---
trailer [48621,48630]
trailer [49124,49133]
===
match
---
trailer [23314,23347]
trailer [23314,23347]
===
match
---
operator: , [38747,38748]
operator: , [39250,39251]
===
match
---
atom_expr [38160,38189]
atom_expr [38663,38692]
===
match
---
operator: - [41292,41293]
operator: - [41795,41796]
===
match
---
suite [18431,18508]
suite [18431,18508]
===
match
---
name: dag [27526,27529]
name: dag [27526,27529]
===
match
---
trailer [18083,18091]
trailer [18083,18091]
===
match
---
name: TI [49826,49828]
name: TI [50329,50331]
===
match
---
operator: , [71052,71053]
operator: , [71555,71556]
===
match
---
atom_expr [79124,79158]
atom_expr [79627,79661]
===
match
---
trailer [24430,24438]
trailer [24430,24438]
===
match
---
decorated [11175,11498]
decorated [11175,11498]
===
match
---
trailer [11370,11379]
trailer [11370,11379]
===
match
---
name: state [79488,79493]
name: state [79991,79996]
===
match
---
name: dag [17486,17489]
name: dag [17486,17489]
===
match
---
atom_expr [38577,38589]
atom_expr [39080,39092]
===
match
---
name: dag_id [49290,49296]
name: dag_id [49793,49799]
===
match
---
name: execution_date [17105,17119]
name: execution_date [17105,17119]
===
match
---
trailer [16305,16313]
trailer [16305,16313]
===
match
---
param [22492,22507]
param [22492,22507]
===
match
---
simple_stmt [57459,57636]
simple_stmt [57962,58139]
===
match
---
trailer [27411,27416]
trailer [27411,27416]
===
match
---
annassign [6494,6551]
annassign [6494,6551]
===
match
---
name: task_concurrency_map [43635,43655]
name: task_concurrency_map [44138,44158]
===
match
---
atom_expr [77623,77668]
atom_expr [78126,78171]
===
match
---
name: executable_tis [45296,45310]
name: executable_tis [45799,45813]
===
match
---
name: self [15919,15923]
name: self [15919,15923]
===
match
---
trailer [72161,72168]
trailer [72664,72671]
===
match
---
trailer [65113,65181]
trailer [65616,65684]
===
match
---
name: SchedulerJob [79475,79487]
name: SchedulerJob [79978,79990]
===
match
---
name: to_reset [81478,81486]
name: to_reset [81981,81989]
===
match
---
operator: = [48667,48668]
operator: = [49170,49171]
===
match
---
atom_expr [8517,8539]
atom_expr [8517,8539]
===
match
---
atom_expr [79540,79569]
atom_expr [80043,80072]
===
match
---
name: dags [23925,23929]
name: dags [23925,23929]
===
match
---
operator: = [74288,74289]
operator: = [74791,74792]
===
match
---
name: Process [8853,8860]
name: Process [8853,8860]
===
match
---
suite [51096,51771]
suite [51599,52274]
===
match
---
simple_stmt [10961,11041]
simple_stmt [10961,11041]
===
match
---
name: ti [18283,18285]
name: ti [18283,18285]
===
match
---
name: active_runs_of_dags [70985,71004]
name: active_runs_of_dags [71488,71507]
===
match
---
atom_expr [75354,75425]
atom_expr [75857,75928]
===
match
---
if_stmt [70076,70333]
if_stmt [70579,70836]
===
match
---
name: dag_id [16539,16545]
name: dag_id [16539,16545]
===
match
---
trailer [7163,7165]
trailer [7163,7165]
===
match
---
name: session [77859,77866]
name: session [78362,78369]
===
match
---
operator: -> [78360,78362]
operator: -> [78863,78865]
===
match
---
string: "DAG %s has %s/%s running and queued tasks" [42292,42335]
string: "DAG %s has %s/%s running and queued tasks" [42795,42838]
===
match
---
trailer [27733,27737]
trailer [27733,27737]
===
match
---
atom_expr [33850,33863]
atom_expr [34353,34366]
===
match
---
parameters [61162,61177]
parameters [61665,61680]
===
match
---
trailer [64010,64016]
trailer [64513,64519]
===
match
---
operator: = [60951,60952]
operator: = [61454,61455]
===
match
---
name: dag_id [77787,77793]
name: dag_id [78290,78296]
===
match
---
trailer [30555,30562]
trailer [30809,30816]
===
match
---
name: task_id [16391,16398]
name: task_id [16391,16398]
===
match
---
name: join [39533,39537]
name: join [40036,40040]
===
match
---
name: debug [79239,79244]
name: debug [79742,79747]
===
match
---
operator: , [20718,20719]
operator: , [20718,20719]
===
match
---
trailer [32641,32643]
trailer [33144,33146]
===
match
---
trailer [80148,80152]
trailer [80651,80655]
===
match
---
name: set [81675,81678]
name: set [82178,82181]
===
match
---
operator: , [29584,29585]
operator: , [29838,29839]
===
match
---
trailer [76751,76768]
trailer [77254,77271]
===
match
---
name: log [45400,45403]
name: log [45903,45906]
===
match
---
simple_stmt [26921,26985]
simple_stmt [26921,26985]
===
match
---
atom_expr [62935,62980]
atom_expr [63438,63483]
===
match
---
simple_stmt [17896,17970]
simple_stmt [17896,17970]
===
match
---
simple_stmt [71842,71851]
simple_stmt [72345,72354]
===
match
---
expr_stmt [9735,9773]
expr_stmt [9735,9773]
===
match
---
funcdef [78443,82655]
funcdef [78946,83158]
===
match
---
name: kwargs [29708,29714]
name: kwargs [29962,29968]
===
match
---
atom_expr [39871,39889]
atom_expr [40374,40392]
===
match
---
trailer [45185,45191]
trailer [45688,45694]
===
match
---
sync_comp_for [45362,45385]
sync_comp_for [45865,45888]
===
match
---
tfpdef [25207,25221]
tfpdef [25207,25221]
===
match
---
name: next_event [59117,59127]
name: next_event [59620,59630]
===
match
---
trailer [69593,69977]
trailer [70096,70480]
===
match
---
name: query [35168,35173]
name: query [35671,35676]
===
match
---
trailer [30711,30718]
trailer [30965,30972]
===
match
---
simple_stmt [40272,40298]
simple_stmt [40775,40801]
===
match
---
name: log [38074,38077]
name: log [38577,38580]
===
match
---
atom [19795,19797]
atom [19795,19797]
===
match
---
operator: = [74324,74325]
operator: = [74827,74828]
===
match
---
atom_expr [41738,41773]
atom_expr [42241,42276]
===
match
---
name: current_time [34552,34564]
name: current_time [35055,35067]
===
match
---
name: _process [13593,13601]
name: _process [13593,13601]
===
match
---
trailer [55812,55828]
trailer [56315,56331]
===
match
---
name: State [73730,73735]
name: State [74233,74238]
===
match
---
funcdef [15400,21358]
funcdef [15400,21358]
===
match
---
atom_expr [4061,4079]
atom_expr [4061,4079]
===
match
---
name: self [12414,12418]
name: self [12414,12418]
===
match
---
operator: , [1655,1656]
operator: , [1655,1656]
===
match
---
expr_stmt [67896,68181]
expr_stmt [68399,68684]
===
match
---
name: State [81582,81587]
name: State [82085,82090]
===
match
---
atom_expr [33616,33635]
atom_expr [34119,34138]
===
match
---
expr_stmt [31501,31539]
expr_stmt [32004,32042]
===
match
---
name: execution_date [24551,24565]
name: execution_date [24551,24565]
===
match
---
string: 'Executed failure callback for %s in state %s' [25079,25125]
string: 'Executed failure callback for %s in state %s' [25079,25125]
===
match
---
operator: = [46893,46894]
operator: = [47396,47397]
===
match
---
simple_stmt [13931,13999]
simple_stmt [13931,13999]
===
match
---
name: debug [60985,60990]
name: debug [61488,61493]
===
match
---
name: queued_by_job_id [45895,45911]
name: queued_by_job_id [46398,46414]
===
match
---
trailer [54222,54534]
trailer [54725,55037]
===
match
---
name: loop_count [59868,59878]
name: loop_count [60371,60381]
===
match
---
name: in_ [71122,71125]
name: in_ [71625,71628]
===
match
---
operator: = [69779,69780]
operator: = [70282,70283]
===
match
---
name: dagbag [68583,68589]
name: dagbag [69086,69092]
===
match
---
suite [52654,53449]
suite [53157,53952]
===
match
---
trailer [4068,4077]
trailer [4068,4077]
===
match
---
name: _process [13276,13284]
name: _process [13276,13284]
===
match
---
operator: , [1558,1559]
operator: , [1558,1559]
===
match
---
annassign [40025,40048]
annassign [40528,40551]
===
match
---
operator: < [17144,17145]
operator: < [17144,17145]
===
match
---
trailer [32454,32461]
trailer [32957,32964]
===
match
---
atom_expr [45892,45911]
atom_expr [46395,46414]
===
match
---
name: executor [58640,58648]
name: executor [59143,59151]
===
match
---
if_stmt [76904,76997]
if_stmt [77407,77500]
===
match
---
atom_expr [66652,66666]
atom_expr [67155,67169]
===
match
---
arglist [68710,68772]
arglist [69213,69275]
===
match
---
name: airflow [3039,3046]
name: airflow [3039,3046]
===
match
---
name: start_method [8743,8755]
name: start_method [8743,8755]
===
match
---
operator: , [8781,8782]
operator: , [8781,8782]
===
match
---
import_from [2005,2080]
import_from [2005,2080]
===
match
---
name: log [53529,53532]
name: log [54032,54035]
===
match
---
trailer [7157,7163]
trailer [7157,7163]
===
match
---
simple_stmt [39700,39780]
simple_stmt [40203,40283]
===
match
---
name: unpaused_dags [27495,27508]
name: unpaused_dags [27495,27508]
===
match
---
atom [81445,81447]
atom [81948,81950]
===
match
---
suite [61185,66701]
suite [61688,67204]
===
match
---
tfpdef [5257,5274]
tfpdef [5257,5274]
===
match
---
name: _schedule_dag_run [72512,72529]
name: _schedule_dag_run [73015,73032]
===
match
---
atom_expr [53524,53563]
atom_expr [54027,54066]
===
match
---
trailer [81265,81282]
trailer [81768,81785]
===
match
---
name: conf [29440,29444]
name: conf [29694,29698]
===
match
---
comparison [12243,12271]
comparison [12243,12271]
===
match
---
simple_stmt [20568,20594]
simple_stmt [20568,20594]
===
match
---
atom_expr [12569,12616]
atom_expr [12569,12616]
===
match
---
operator: , [2631,2632]
operator: , [2631,2632]
===
match
---
operator: , [75256,75257]
operator: , [75759,75760]
===
match
---
sync_comp_for [17953,17968]
sync_comp_for [17953,17968]
===
match
---
trailer [73866,73874]
trailer [74369,74377]
===
match
---
trailer [49648,49654]
trailer [50151,50157]
===
match
---
param [70585,70616]
param [71088,71119]
===
match
---
if_stmt [73293,74654]
if_stmt [73796,75157]
===
match
---
name: run_type [38482,38490]
name: run_type [38985,38993]
===
match
---
name: self [25193,25197]
name: self [25193,25197]
===
match
---
fstring_start: f" [16989,16991]
fstring_start: f" [16989,16991]
===
match
---
atom_expr [9167,9190]
atom_expr [9167,9190]
===
match
---
trailer [33658,33701]
trailer [34161,34204]
===
match
---
trailer [78826,78833]
trailer [79329,79336]
===
match
---
name: dags_hash [68835,68844]
name: dags_hash [69338,69347]
===
match
---
trailer [33840,33846]
trailer [34343,34349]
===
match
---
trailer [9558,9560]
trailer [9558,9560]
===
match
---
trailer [82644,82654]
trailer [83147,83157]
===
match
---
trailer [27620,27641]
trailer [27620,27641]
===
match
---
name: file_path [8106,8115]
name: file_path [8106,8115]
===
match
---
name: self [66765,66769]
name: self [67268,67272]
===
match
---
operator: = [23916,23917]
operator: = [23916,23917]
===
match
---
operator: } [29264,29265]
operator: } [29518,29519]
===
match
---
trailer [54182,54198]
trailer [54685,54701]
===
match
---
suite [12272,12354]
suite [12272,12354]
===
match
---
trailer [12307,12353]
trailer [12307,12353]
===
match
---
trailer [79234,79238]
trailer [79737,79741]
===
match
---
simple_stmt [24771,24808]
simple_stmt [24771,24808]
===
match
---
string: """         Is this SchedulerJob alive?          We define alive as in a state of running and a heartbeat within the         threshold defined in the ``scheduler_health_check_threshold`` config         setting.          ``grace_multiplier`` is accepted for compatibility with the parent class.          :rtype: boolean         """ [31905,32235]
string: """         Is this SchedulerJob alive?          We define alive as in a state of running and a heartbeat within the         threshold defined in the ``scheduler_health_check_threshold`` config         setting.          ``grace_multiplier`` is accepted for compatibility with the parent class.          :rtype: boolean         """ [32408,32738]
===
match
---
suite [60376,61139]
suite [60879,61642]
===
match
---
simple_stmt [6811,6830]
simple_stmt [6811,6830]
===
match
---
trailer [17999,18003]
trailer [17999,18003]
===
match
---
number: 0 [41380,41381]
number: 0 [41883,41884]
===
match
---
name: signal [30999,31005]
name: signal [31253,31259]
===
match
---
name: key [52180,52183]
name: key [52683,52686]
===
match
---
name: Stats [45029,45034]
name: Stats [45532,45537]
===
match
---
trailer [52977,52983]
trailer [53480,53486]
===
match
---
with_stmt [7011,8050]
with_stmt [7011,8050]
===
match
---
operator: = [56380,56381]
operator: = [56883,56884]
===
match
---
name: execute_callbacks [27102,27119]
name: execute_callbacks [27102,27119]
===
match
---
name: self [32605,32609]
name: self [33108,33112]
===
match
---
name: dag [77218,77221]
name: dag [77721,77724]
===
match
---
dotted_name [1867,1888]
dotted_name [1867,1888]
===
match
---
trailer [36478,36493]
trailer [36981,36996]
===
match
---
expr_stmt [80056,81040]
expr_stmt [80559,81543]
===
match
---
annassign [40077,40112]
annassign [40580,40615]
===
match
---
fstring_expr [17011,17024]
fstring_expr [17011,17024]
===
match
---
simple_stmt [24669,24706]
simple_stmt [24669,24706]
===
match
---
trailer [80989,80997]
trailer [81492,81500]
===
match
---
name: current_time [35004,35016]
name: current_time [35507,35519]
===
match
---
name: conf [19700,19704]
name: conf [19700,19704]
===
match
---
import_name [906,919]
import_name [906,919]
===
match
---
name: Stats [79883,79888]
name: Stats [80386,80391]
===
match
---
decorated [37066,46076]
decorated [37569,46579]
===
match
---
atom_expr [9367,9382]
atom_expr [9367,9382]
===
match
---
simple_stmt [41203,41346]
simple_stmt [41706,41849]
===
match
---
name: self [49156,49160]
name: self [49659,49663]
===
match
---
name: info [56007,56011]
name: info [56510,56514]
===
match
---
param [29622,29646]
param [29876,29900]
===
match
---
atom_expr [40027,40048]
atom_expr [40530,40551]
===
match
---
expr_stmt [79969,80035]
expr_stmt [80472,80538]
===
match
---
name: dagbag [27120,27126]
name: dagbag [27120,27126]
===
match
---
suite [12035,13696]
suite [12035,13696]
===
match
---
name: ti [18674,18676]
name: ti [18674,18676]
===
match
---
operator: @ [50580,50581]
operator: @ [51083,51084]
===
match
---
simple_stmt [78517,78734]
simple_stmt [79020,79237]
===
match
---
name: conf [29287,29291]
name: conf [29541,29545]
===
match
---
name: str [31650,31653]
name: str [32153,32156]
===
match
---
arglist [57515,57575]
arglist [58018,58078]
===
match
---
operator: , [19187,19188]
operator: , [19187,19188]
===
match
---
name: items [22250,22255]
name: items [22250,22255]
===
match
---
arglist [19379,19436]
arglist [19379,19436]
===
match
---
suite [79326,82519]
suite [79829,83022]
===
match
---
trailer [17082,17101]
trailer [17082,17101]
===
match
---
name: join [13602,13606]
name: join [13602,13606]
===
match
---
comparison [59641,59672]
comparison [60144,60175]
===
match
---
operator: < [79570,79571]
operator: < [80073,80074]
===
match
---
name: airflow [2580,2587]
name: airflow [2580,2587]
===
match
---
param [72553,72569]
param [73056,73072]
===
match
---
strings [44258,44374]
strings [44761,44877]
===
match
---
name: _executable_task_instances_to_queued [37091,37127]
name: _executable_task_instances_to_queued [37594,37630]
===
match
---
trailer [7047,7066]
trailer [7047,7066]
===
match
---
atom_expr [24736,24754]
atom_expr [24736,24754]
===
match
---
trailer [76273,76297]
trailer [76776,76800]
===
match
---
name: max_tis [48711,48718]
name: max_tis [49214,49221]
===
match
---
expr_stmt [40389,40417]
expr_stmt [40892,40920]
===
match
---
arglist [36629,36650]
arglist [37132,37153]
===
match
---
trailer [49562,49574]
trailer [50065,50077]
===
match
---
atom_expr [13423,13443]
atom_expr [13423,13443]
===
match
---
name: callback [76843,76851]
name: callback [77346,77354]
===
match
---
trailer [34919,34926]
trailer [35422,35429]
===
match
---
name: handle_callback [24047,24062]
name: handle_callback [24047,24062]
===
match
---
name: _enqueue_task_instances_with_queued_state [48751,48792]
name: _enqueue_task_instances_with_queued_state [49254,49295]
===
match
---
trailer [17920,17929]
trailer [17920,17929]
===
match
---
name: self [10569,10573]
name: self [10569,10573]
===
match
---
strings [52763,52909]
strings [53266,53412]
===
match
---
name: dag_id [68303,68309]
name: dag_id [68806,68812]
===
match
---
trailer [15178,15189]
trailer [15178,15189]
===
match
---
name: SKIPPED [16306,16313]
name: SKIPPED [16306,16313]
===
match
---
atom_expr [80557,80628]
atom_expr [81060,81131]
===
match
---
suite [45517,45980]
suite [46020,46483]
===
match
---
operator: = [41736,41737]
operator: = [42239,42240]
===
match
---
name: sleep [59571,59576]
name: sleep [60074,60079]
===
match
---
funcdef [13715,14027]
funcdef [13715,14027]
===
match
---
name: log [77470,77473]
name: log [77973,77976]
===
match
---
operator: = [3081,3082]
operator: = [3081,3082]
===
match
---
argument [46729,46757]
argument [47232,47260]
===
match
---
expr_stmt [30406,30455]
expr_stmt [30660,30709]
===
match
---
trailer [54345,54351]
trailer [54848,54854]
===
match
---
string: "\n\t" [50427,50433]
string: "\n\t" [50930,50936]
===
match
---
trailer [5301,5312]
trailer [5301,5312]
===
match
---
name: self [22486,22490]
name: self [22486,22490]
===
match
---
argument [30744,30763]
argument [30998,31017]
===
match
---
for_stmt [19810,20243]
for_stmt [19810,20243]
===
match
---
exprlist [38738,38754]
exprlist [39241,39257]
===
match
---
name: conf [29559,29563]
name: conf [29813,29817]
===
match
---
atom_expr [34238,34246]
atom_expr [34741,34749]
===
match
---
suite [73181,73284]
suite [73684,73787]
===
match
---
atom_expr [16791,16801]
atom_expr [16791,16801]
===
match
---
operator: = [6511,6512]
operator: = [6511,6512]
===
match
---
operator: = [78352,78353]
operator: = [78855,78856]
===
match
---
operator: , [72382,72383]
operator: , [72885,72886]
===
match
---
name: with_row_locks [81181,81195]
name: with_row_locks [81684,81698]
===
match
---
name: timezone [17282,17290]
name: timezone [17282,17290]
===
match
---
argument [60473,60504]
argument [60976,61007]
===
match
---
name: pool [39885,39889]
name: pool [40388,40392]
===
match
---
atom_expr [39070,39098]
atom_expr [39573,39601]
===
match
---
name: SerializedDagModel [76255,76273]
name: SerializedDagModel [76758,76776]
===
match
---
name: _pickle_dags [4129,4141]
name: _pickle_dags [4129,4141]
===
match
---
funcdef [14362,14427]
funcdef [14362,14427]
===
match
---
atom_expr [10298,10311]
atom_expr [10298,10311]
===
match
---
expr_stmt [30109,30164]
expr_stmt [30363,30418]
===
match
---
name: len [39315,39318]
name: len [39818,39821]
===
match
---
atom [32584,32627]
atom [33087,33130]
===
match
---
atom_expr [16549,16559]
atom_expr [16549,16559]
===
match
---
trailer [26491,26554]
trailer [26491,26554]
===
match
---
name: SerializedDagNotFound [71704,71725]
name: SerializedDagNotFound [72207,72228]
===
match
---
for_stmt [71402,72503]
for_stmt [71905,73006]
===
match
---
name: mixins [2681,2687]
name: mixins [2681,2687]
===
match
---
simple_stmt [13423,13444]
simple_stmt [13423,13444]
===
match
---
name: retry_state [79132,79143]
name: retry_state [79635,79646]
===
match
---
trailer [51762,51770]
trailer [52265,52273]
===
match
---
arglist [68239,68275]
arglist [68742,68778]
===
match
---
subscriptlist [35991,36047]
subscriptlist [36494,36550]
===
match
---
name: timeout [13290,13297]
name: timeout [13290,13297]
===
match
---
simple_stmt [70652,70827]
simple_stmt [71155,71330]
===
match
---
name: slot_stats [78237,78247]
name: slot_stats [78740,78750]
===
match
---
operator: , [64047,64048]
operator: , [64550,64551]
===
match
---
name: callback [77092,77100]
name: callback [77595,77603]
===
match
---
name: ti [52108,52110]
name: ti [52611,52613]
===
match
---
trailer [69743,69750]
trailer [70246,70253]
===
match
---
trailer [36619,36628]
trailer [37122,37131]
===
match
---
name: self [10763,10767]
name: self [10763,10767]
===
match
---
sync_comp_for [68129,68149]
sync_comp_for [68632,68652]
===
match
---
trailer [23924,23929]
trailer [23924,23929]
===
match
---
name: self [70342,70346]
name: self [70845,70849]
===
match
---
trailer [16249,16256]
trailer [16249,16256]
===
match
---
name: self [55469,55473]
name: self [55972,55976]
===
match
---
trailer [12480,12488]
trailer [12480,12488]
===
match
---
name: TaskInstance [34981,34993]
name: TaskInstance [35484,35496]
===
match
---
param [76104,76120]
param [76607,76623]
===
match
---
trailer [40871,40877]
trailer [41374,41380]
===
match
---
parameters [76097,76134]
parameters [76600,76637]
===
match
---
annassign [34236,34362]
annassign [34739,34865]
===
match
---
trailer [80152,80171]
trailer [80655,80674]
===
match
---
string: 'scheduler' [29452,29463]
string: 'scheduler' [29706,29717]
===
match
---
name: timer [65797,65802]
name: timer [66300,66305]
===
match
---
name: self [4124,4128]
name: self [4124,4128]
===
match
---
trailer [50883,50892]
trailer [51386,51395]
===
match
---
name: log [53258,53261]
name: log [53761,53764]
===
match
---
trailer [79393,79399]
trailer [79896,79902]
===
match
---
simple_stmt [25375,26376]
simple_stmt [25375,26376]
===
match
---
trailer [10977,11040]
trailer [10977,11040]
===
match
---
operator: = [4665,4666]
operator: = [4665,4666]
===
match
---
atom [16467,16699]
atom [16467,16699]
===
match
---
name: self [13498,13502]
name: self [13498,13502]
===
match
---
name: models [34974,34980]
name: models [35477,35483]
===
match
---
name: state [69774,69779]
name: state [70277,70282]
===
match
---
arglist [23028,23070]
arglist [23028,23070]
===
match
---
except_clause [20834,20850]
except_clause [20834,20850]
===
match
---
trailer [58159,58183]
trailer [58662,58686]
===
match
---
suite [14466,27840]
suite [14466,27840]
===
match
---
name: dag_model [69508,69517]
name: dag_model [70011,70020]
===
match
---
trailer [45894,45911]
trailer [46397,46414]
===
match
---
simple_stmt [42064,42094]
simple_stmt [42567,42597]
===
match
---
name: DagFileProcessorProcess [4945,4968]
name: DagFileProcessorProcess [4945,4968]
===
match
---
atom_expr [8845,9281]
atom_expr [8845,9281]
===
match
---
name: dagbag [22492,22498]
name: dagbag [22492,22498]
===
match
---
simple_stmt [51933,51990]
simple_stmt [52436,52493]
===
match
---
expr_stmt [19776,19797]
expr_stmt [19776,19797]
===
match
---
atom_expr [81181,81310]
atom_expr [81684,81813]
===
match
---
operator: = [81443,81444]
operator: = [81946,81947]
===
match
---
name: done [59956,59960]
name: done [60459,60463]
===
match
---
name: dag_id [76306,76312]
name: dag_id [76809,76815]
===
match
---
param [5131,5173]
param [5131,5173]
===
match
---
funcdef [67320,70393]
funcdef [67823,70896]
===
match
---
name: test_mode [24870,24879]
name: test_mode [24870,24879]
===
match
---
atom_expr [37970,38022]
atom_expr [38473,38525]
===
match
---
name: task_id [16339,16346]
name: task_id [16339,16346]
===
match
---
arglist [41543,41618]
arglist [42046,42121]
===
match
---
name: _process [13325,13333]
name: _process [13325,13333]
===
match
---
simple_stmt [48513,48553]
simple_stmt [49016,49056]
===
match
---
return_stmt [46054,46075]
return_stmt [46557,46578]
===
match
---
trailer [17378,17386]
trailer [17378,17386]
===
match
---
name: _process [10906,10914]
name: _process [10906,10914]
===
match
---
operator: = [24530,24531]
operator: = [24530,24531]
===
match
---
name: dag_id [24398,24404]
name: dag_id [24398,24404]
===
match
---
name: c [35341,35342]
name: c [35844,35845]
===
match
---
expr_stmt [54178,54534]
expr_stmt [54681,55037]
===
match
---
atom_expr [57267,57308]
atom_expr [57770,57811]
===
match
---
atom_expr [71007,71392]
atom_expr [71510,71895]
===
match
---
trailer [31387,31397]
trailer [31764,31774]
===
match
---
name: self [53394,53398]
name: self [53897,53901]
===
match
---
name: State [60712,60717]
name: State [61215,61220]
===
match
---
trailer [50392,50396]
trailer [50895,50899]
===
match
---
trailer [10387,10431]
trailer [10387,10431]
===
match
---
name: max_tis_per_query [48598,48615]
name: max_tis_per_query [49101,49118]
===
match
---
name: self [70579,70583]
name: self [71082,71086]
===
match
---
trailer [58362,58366]
trailer [58865,58869]
===
match
---
arglist [45409,45480]
arglist [45912,45983]
===
match
---
arglist [79023,79195]
arglist [79526,79698]
===
match
---
name: State [32554,32559]
name: State [33057,33062]
===
match
---
name: executor [65565,65573]
name: executor [66068,66076]
===
match
---
name: session [75570,75577]
name: session [76073,76080]
===
match
---
name: int [47401,47404]
name: int [47904,47907]
===
match
---
name: task_id [36952,36959]
name: task_id [37455,37462]
===
match
---
simple_stmt [76584,76658]
simple_stmt [77087,77161]
===
match
---
name: dag [77543,77546]
name: dag [78046,78049]
===
match
---
trailer [27806,27811]
trailer [27806,27811]
===
match
---
operator: } [17038,17039]
operator: } [17038,17039]
===
match
---
arglist [45262,45311]
arglist [45765,45814]
===
match
---
trailer [16494,16498]
trailer [16494,16498]
===
match
---
trailer [64236,64242]
trailer [64739,64745]
===
match
---
operator: , [25339,25340]
operator: , [25339,25340]
===
match
---
trailer [64129,64308]
trailer [64632,64811]
===
match
---
suite [13345,13444]
suite [13345,13444]
===
match
---
name: pool_name [40665,40674]
name: pool_name [41168,41177]
===
match
---
name: DagModel [70606,70614]
name: DagModel [71109,71117]
===
match
---
name: session [58681,58688]
name: session [59184,59191]
===
match
---
expr_stmt [40272,40297]
expr_stmt [40775,40800]
===
match
---
simple_stmt [17523,17540]
simple_stmt [17523,17540]
===
match
---
name: start_time [14050,14060]
name: start_time [14050,14060]
===
match
---
atom_expr [59833,59846]
atom_expr [60336,60349]
===
match
---
operator: = [30687,30688]
operator: = [30941,30942]
===
match
---
param [72539,72544]
param [73042,73047]
===
match
---
simple_stmt [20904,20949]
simple_stmt [20904,20949]
===
match
---
suite [23088,23484]
suite [23088,23484]
===
match
---
name: dag_runs [62994,63002]
name: dag_runs [63497,63505]
===
match
---
atom_expr [7615,7689]
atom_expr [7615,7689]
===
match
---
trailer [78095,78101]
trailer [78598,78604]
===
match
---
name: TaskInstance [33666,33678]
name: TaskInstance [34169,34181]
===
match
---
name: session [37148,37155]
name: session [37651,37658]
===
match
---
name: stop [66242,66246]
name: stop [66745,66749]
===
match
---
argument [78927,78942]
argument [79430,79445]
===
match
---
simple_stmt [21341,21358]
simple_stmt [21341,21358]
===
match
---
atom_expr [24421,24438]
atom_expr [24421,24438]
===
match
---
trailer [77698,77735]
trailer [78201,78238]
===
match
---
name: emails [20609,20615]
name: emails [20609,20615]
===
match
---
name: filename [22328,22336]
name: filename [22328,22336]
===
match
---
name: task_list [19178,19187]
name: task_list [19178,19187]
===
match
---
operator: } [78054,78055]
operator: } [78557,78558]
===
match
---
name: state [52265,52270]
name: state [52768,52773]
===
match
---
name: task_id [80990,80997]
name: task_id [81493,81500]
===
match
---
atom_expr [45292,45311]
atom_expr [45795,45814]
===
match
---
simple_stmt [6875,6941]
simple_stmt [6875,6941]
===
match
---
name: dag_run [73094,73101]
name: dag_run [73597,73604]
===
match
---
name: processor_agent [77119,77134]
name: processor_agent [77622,77637]
===
match
---
trailer [38011,38018]
trailer [38514,38521]
===
match
---
atom_expr [49646,49654]
atom_expr [50149,50157]
===
match
---
trailer [33537,33550]
trailer [34040,34053]
===
match
---
operator: , [71918,71919]
operator: , [72421,72422]
===
match
---
comparison [73648,73691]
comparison [74151,74194]
===
match
---
simple_stmt [58139,58186]
simple_stmt [58642,58689]
===
match
---
simple_stmt [24722,24755]
simple_stmt [24722,24755]
===
match
---
simple_stmt [23562,23755]
simple_stmt [23562,23755]
===
match
---
argument [26527,26553]
argument [26527,26553]
===
match
---
atom_expr [47004,47022]
atom_expr [47507,47525]
===
match
---
trailer [15854,15905]
trailer [15854,15905]
===
match
---
name: TI [64038,64040]
name: TI [64541,64543]
===
match
---
atom_expr [17282,17299]
atom_expr [17282,17299]
===
match
---
name: email [20393,20398]
name: email [20393,20398]
===
match
---
name: sigkill [10661,10668]
name: sigkill [10661,10668]
===
match
---
simple_stmt [21213,21241]
simple_stmt [21213,21241]
===
match
---
atom_expr [49560,49574]
atom_expr [50063,50077]
===
match
---
trailer [39532,39537]
trailer [40035,40040]
===
match
---
operator: , [12600,12601]
operator: , [12600,12601]
===
match
---
argument [45939,45964]
argument [46442,46467]
===
match
---
name: processor_agent [55813,55828]
name: processor_agent [56316,56331]
===
match
---
operator: = [69734,69735]
operator: = [70237,70238]
===
match
---
operator: = [17931,17932]
operator: = [17931,17932]
===
match
---
name: dag [73345,73348]
name: dag [73848,73851]
===
match
---
atom_expr [53682,53701]
atom_expr [54185,54204]
===
match
---
try_stmt [55596,55775]
try_stmt [56099,56278]
===
match
---
name: RUNNING [71197,71204]
name: RUNNING [71700,71707]
===
match
---
operator: , [69837,69838]
operator: , [70340,70341]
===
match
---
atom_expr [16049,16427]
atom_expr [16049,16427]
===
match
---
name: self [53796,53800]
name: self [54299,54303]
===
match
---
trailer [71649,71684]
trailer [72152,72187]
===
match
---
decorator [32694,32711]
decorator [33197,33214]
===
match
---
simple_stmt [9322,9359]
simple_stmt [9322,9359]
===
match
---
trailer [74184,74191]
trailer [74687,74694]
===
match
---
arglist [39001,39099]
arglist [39504,39602]
===
match
---
comp_if [38772,38793]
comp_if [39275,39296]
===
match
---
name: info [8066,8070]
name: info [8066,8070]
===
match
---
operator: , [76024,76025]
operator: , [76527,76528]
===
match
---
expr_stmt [8705,8756]
expr_stmt [8705,8756]
===
match
---
name: filter_for_tis [51933,51947]
name: filter_for_tis [52436,52450]
===
match
---
trailer [54288,54309]
trailer [54791,54812]
===
match
---
operator: = [7917,7918]
operator: = [7917,7918]
===
match
---
string: 'max_ti' [16109,16117]
string: 'max_ti' [16109,16117]
===
match
---
simple_stmt [55135,55275]
simple_stmt [55638,55778]
===
match
---
operator: = [29438,29439]
operator: = [29692,29693]
===
match
---
atom_expr [64165,64211]
atom_expr [64668,64714]
===
match
---
trailer [58067,58069]
trailer [58570,58572]
===
match
---
fstring_expr [19631,19651]
fstring_expr [19631,19651]
===
match
---
trailer [57594,57624]
trailer [58097,58127]
===
match
---
name: list [33611,33615]
name: list [34114,34118]
===
match
---
simple_stmt [9735,9774]
simple_stmt [9735,9774]
===
match
---
funcdef [11189,11498]
funcdef [11189,11498]
===
match
---
name: done [12016,12020]
name: done [12016,12020]
===
match
---
atom_expr [69508,69529]
atom_expr [70011,70032]
===
match
---
atom [16035,16437]
atom [16035,16437]
===
match
---
expr_stmt [36897,36921]
expr_stmt [37400,37424]
===
match
---
arglist [76618,76656]
arglist [77121,77159]
===
match
---
name: query [81221,81226]
name: query [81724,81729]
===
match
---
atom_expr [31344,31370]
atom_expr [31721,31747]
===
match
---
name: blocking [59041,59049]
name: blocking [59544,59552]
===
match
---
param [29424,29477]
param [29678,29731]
===
match
---
atom [17618,17777]
atom [17618,17777]
===
match
---
trailer [54608,54617]
trailer [55111,55120]
===
match
---
name: info [59987,59991]
name: info [60490,60494]
===
match
---
expr_stmt [33427,33442]
expr_stmt [33930,33945]
===
match
---
atom_expr [10569,10597]
atom_expr [10569,10597]
===
match
---
trailer [74673,74688]
trailer [75176,75191]
===
match
---
name: exit_code [11521,11530]
name: exit_code [11521,11530]
===
match
---
operator: -> [5036,5038]
operator: -> [5036,5038]
===
match
---
atom_expr [16336,16364]
atom_expr [16336,16364]
===
match
---
name: self [45395,45399]
name: self [45898,45902]
===
match
---
atom_expr [9080,9093]
atom_expr [9080,9093]
===
match
---
suite [23149,23216]
suite [23149,23216]
===
match
---
operator: , [23473,23474]
operator: , [23473,23474]
===
match
---
trailer [48592,48647]
trailer [49095,49150]
===
match
---
name: pool [40597,40601]
name: pool [41100,41104]
===
match
---
name: TI [80561,80563]
name: TI [81064,81066]
===
match
---
comp_if [27425,27456]
comp_if [27425,27456]
===
match
---
atom_expr [77401,77430]
atom_expr [77904,77933]
===
match
---
name: log [20024,20027]
name: log [20024,20027]
===
match
---
operator: = [24880,24881]
operator: = [24880,24881]
===
match
---
name: self [9322,9326]
name: self [9322,9326]
===
match
---
expr_stmt [7552,7597]
expr_stmt [7552,7597]
===
match
---
dotted_name [3039,3058]
dotted_name [3039,3058]
===
match
---
trailer [36552,36558]
trailer [37055,37061]
===
match
---
name: datetime [17921,17929]
name: datetime [17921,17929]
===
match
---
name: tuple [20535,20540]
name: tuple [20535,20540]
===
match
---
name: incr [66509,66513]
name: incr [67012,67016]
===
match
---
operator: , [30742,30743]
operator: , [30996,30997]
===
match
---
arglist [70372,70391]
arglist [70875,70894]
===
match
---
return_stmt [75981,76034]
return_stmt [76484,76537]
===
match
---
trailer [18285,18293]
trailer [18285,18293]
===
match
---
name: provide_session [78286,78301]
name: provide_session [78789,78804]
===
match
---
name: pickle [27530,27536]
name: pickle [27530,27536]
===
match
---
atom_expr [75549,75611]
atom_expr [76052,76114]
===
match
---
operator: , [69793,69794]
operator: , [70296,70297]
===
match
---
simple_stmt [26384,26450]
simple_stmt [26384,26450]
===
match
---
name: _executable_task_instances_to_queued [48674,48710]
name: _executable_task_instances_to_queued [49177,49213]
===
match
---
operator: = [30706,30707]
operator: = [30960,30961]
===
match
---
simple_stmt [9939,9996]
simple_stmt [9939,9996]
===
match
---
operator: = [48727,48728]
operator: = [49230,49231]
===
match
---
import_name [873,895]
import_name [873,895]
===
match
---
name: session [60790,60797]
name: session [61293,61300]
===
match
---
operator: = [35140,35141]
operator: = [35643,35644]
===
match
---
trailer [51342,51649]
trailer [51845,52152]
===
match
---
name: notification_sent [18942,18959]
name: notification_sent [18942,18959]
===
match
---
operator: = [52216,52217]
operator: = [52719,52720]
===
match
---
import_name [948,959]
import_name [948,959]
===
match
---
name: join [45349,45353]
name: join [45852,45856]
===
match
---
simple_stmt [60251,60257]
simple_stmt [60754,60760]
===
match
---
name: args [30227,30231]
name: args [30481,30485]
===
match
---
operator: } [9260,9261]
operator: } [9260,9261]
===
match
---
simple_stmt [77114,77170]
simple_stmt [77617,77673]
===
match
---
name: finished [64261,64269]
name: finished [64764,64772]
===
match
---
atom_expr [58585,58613]
atom_expr [59088,59116]
===
match
---
atom_expr [60158,60183]
atom_expr [60661,60686]
===
match
---
atom_expr [7032,7066]
atom_expr [7032,7066]
===
match
---
fstring_expr [16991,17007]
fstring_expr [16991,17007]
===
match
---
arglist [15190,15214]
arglist [15190,15214]
===
match
---
name: timezone [17146,17154]
name: timezone [17146,17154]
===
match
---
atom_expr [13908,13917]
atom_expr [13908,13917]
===
match
---
simple_stmt [3103,3122]
simple_stmt [3103,3122]
===
match
---
name: task_ids [16355,16363]
name: task_ids [16355,16363]
===
match
---
param [31419,31424]
param [31796,31801]
===
match
---
arglist [74773,74830]
arglist [75276,75333]
===
match
---
arglist [24535,24565]
arglist [24535,24565]
===
match
---
operator: , [51537,51538]
operator: , [52040,52041]
===
match
---
operator: = [70015,70016]
operator: = [70518,70519]
===
match
---
parameters [56508,56514]
parameters [57011,57017]
===
match
---
name: current_index [41398,41411]
name: current_index [41901,41914]
===
match
---
name: DAGS_FOLDER [29403,29414]
name: DAGS_FOLDER [29657,29668]
===
match
---
atom_expr [80660,80670]
atom_expr [81163,81173]
===
match
---
name: List [16456,16460]
name: List [16456,16460]
===
match
---
import_from [1248,1285]
import_from [1248,1285]
===
match
---
atom_expr [7812,8005]
atom_expr [7812,8005]
===
match
---
name: utcnow [34576,34582]
name: utcnow [35079,35085]
===
match
---
name: info [59699,59703]
name: info [60202,60206]
===
match
---
trailer [66508,66513]
trailer [67011,67016]
===
match
---
operator: = [72320,72321]
operator: = [72823,72824]
===
match
---
name: datetime [1067,1075]
name: datetime [1067,1075]
===
match
---
trailer [34325,34342]
trailer [34828,34845]
===
match
---
name: self [8886,8890]
name: self [8886,8890]
===
match
---
operator: == [48495,48497]
operator: == [48998,49000]
===
match
---
name: state [16291,16296]
name: state [16291,16296]
===
match
---
atom_expr [70017,70059]
atom_expr [70520,70562]
===
match
---
trailer [17761,17765]
trailer [17761,17765]
===
match
---
name: skip_locked [34314,34325]
name: skip_locked [34817,34828]
===
match
---
for_stmt [21176,21329]
for_stmt [21176,21329]
===
match
---
name: info [15790,15794]
name: info [15790,15794]
===
match
---
atom_expr [67144,67187]
atom_expr [67647,67690]
===
match
---
operator: , [36868,36869]
operator: , [37371,37372]
===
match
---
string: "All pools are full!" [38084,38105]
string: "All pools are full!" [38587,38608]
===
match
---
if_stmt [49971,50022]
if_stmt [50474,50525]
===
match
---
arith_expr [17250,17279]
arith_expr [17250,17279]
===
match
---
name: request [23248,23255]
name: request [23248,23255]
===
match
---
trailer [9049,9062]
trailer [9049,9062]
===
match
---
name: or_ [38454,38457]
name: or_ [38957,38960]
===
match
---
arglist [23248,23275]
arglist [23248,23275]
===
match
---
name: items [77993,77998]
name: items [78496,78501]
===
match
---
comparison [80876,80905]
comparison [81379,81408]
===
match
---
arglist [78202,78262]
arglist [78705,78765]
===
match
---
arglist [16536,16656]
arglist [16536,16656]
===
match
---
param [47374,47379]
param [47877,47882]
===
match
---
param [15240,15269]
param [15240,15269]
===
match
---
operator: = [27270,27271]
operator: = [27270,27271]
===
match
---
param [29526,29613]
param [29780,29867]
===
match
---
trailer [69579,69593]
trailer [70082,70096]
===
match
---
trailer [15282,15289]
trailer [15282,15289]
===
match
---
name: ValueError [76951,76961]
name: ValueError [77454,77464]
===
match
---
string: "Could not send SLA Miss email notification for DAG %s" [20988,21043]
string: "Could not send SLA Miss email notification for DAG %s" [20988,21043]
===
match
---
name: task_instance_str [45463,45480]
name: task_instance_str [45966,45983]
===
match
---
suite [79762,79948]
suite [80265,80451]
===
match
---
atom_expr [24882,24901]
atom_expr [24882,24901]
===
match
---
atom_expr [45843,45855]
atom_expr [46346,46358]
===
match
---
name: TI [18066,18068]
name: TI [18066,18068]
===
match
---
import_from [1093,1171]
import_from [1093,1171]
===
match
---
atom_expr [11779,11838]
atom_expr [11779,11838]
===
match
---
trailer [8885,8891]
trailer [8885,8891]
===
match
---
dictorsetmaker [29226,29264]
dictorsetmaker [29480,29518]
===
match
---
argument [26503,26525]
argument [26503,26525]
===
match
---
trailer [10969,10977]
trailer [10969,10977]
===
match
---
name: args [29692,29696]
name: args [29946,29950]
===
match
---
if_stmt [11104,11170]
if_stmt [11104,11170]
===
match
---
tfpdef [29424,29437]
tfpdef [29678,29691]
===
match
---
annassign [4466,4500]
annassign [4466,4500]
===
match
---
atom_expr [42257,42470]
atom_expr [42760,42973]
===
match
---
operator: , [7121,7122]
operator: , [7121,7122]
===
match
---
atom_expr [78377,78416]
atom_expr [78880,78919]
===
match
---
trailer [4335,4372]
trailer [4335,4372]
===
match
---
expr_stmt [16709,16731]
expr_stmt [16709,16731]
===
match
---
operator: , [68252,68253]
operator: , [68755,68756]
===
match
---
operator: , [51064,51065]
operator: , [51567,51568]
===
match
---
string: "Tried to get PID before starting!" [11428,11463]
string: "Tried to get PID before starting!" [11428,11463]
===
match
---
name: task [16997,17001]
name: task [16997,17001]
===
match
---
operator: , [56112,56113]
operator: , [56615,56616]
===
match
---
suite [50002,50022]
suite [50505,50525]
===
match
---
simple_stmt [2662,2727]
simple_stmt [2662,2727]
===
match
---
trailer [53686,53701]
trailer [54189,54204]
===
match
---
trailer [55487,55548]
trailer [55990,56051]
===
match
---
name: session [74149,74156]
name: session [74652,74659]
===
match
---
atom_expr [13588,13608]
atom_expr [13588,13608]
===
match
---
name: self [8555,8559]
name: self [8555,8559]
===
match
---
trailer [18584,18594]
trailer [18584,18594]
===
match
---
parameters [46126,46158]
parameters [46629,46661]
===
match
---
name: self [58635,58639]
name: self [59138,59142]
===
match
---
atom_expr [10711,10739]
atom_expr [10711,10739]
===
match
---
atom_expr [20658,20734]
atom_expr [20658,20734]
===
match
---
for_stmt [64508,65358]
for_stmt [65011,65861]
===
match
---
decorator [15379,15396]
decorator [15379,15396]
===
match
---
trailer [10793,10802]
trailer [10793,10802]
===
match
---
operator: , [9190,9191]
operator: , [9190,9191]
===
match
---
name: str [15263,15266]
name: str [15263,15266]
===
match
---
atom_expr [25008,25019]
atom_expr [25008,25019]
===
match
---
comparison [49353,49388]
comparison [49856,49891]
===
match
---
operator: = [16182,16183]
operator: = [16182,16183]
===
match
---
expr_stmt [12535,12552]
expr_stmt [12535,12552]
===
match
---
name: models [33933,33939]
name: models [34436,34442]
===
match
---
expr_stmt [81157,81310]
expr_stmt [81660,81813]
===
match
---
name: try_number [52131,52141]
name: try_number [52634,52644]
===
match
---
trailer [58458,58474]
trailer [58961,58977]
===
match
---
simple_stmt [4945,4997]
simple_stmt [4945,4997]
===
match
---
trailer [17489,17508]
trailer [17489,17508]
===
match
---
name: value [51066,51071]
name: value [51569,51574]
===
match
---
trailer [16648,16655]
trailer [16648,16655]
===
match
---
number: 1 [78411,78412]
number: 1 [78914,78915]
===
match
---
name: num_times_parse_dags [53801,53821]
name: num_times_parse_dags [54304,54324]
===
match
---
name: callback_requests [7969,7986]
name: callback_requests [7969,7986]
===
match
---
param [37128,37133]
param [37631,37636]
===
match
---
expr_stmt [20755,20772]
expr_stmt [20755,20772]
===
match
---
name: ti [53155,53157]
name: ti [53658,53660]
===
match
---
atom_expr [80007,80019]
atom_expr [80510,80522]
===
match
---
trailer [64279,64287]
trailer [64782,64790]
===
match
---
trailer [3983,3994]
trailer [3983,3994]
===
match
---
name: session [65173,65180]
name: session [65676,65683]
===
match
---
atom_expr [56141,56162]
atom_expr [56644,56665]
===
match
---
name: ti [46591,46593]
name: ti [47094,47096]
===
match
---
name: pid [11494,11497]
name: pid [11494,11497]
===
match
---
atom_expr [17271,17279]
atom_expr [17271,17279]
===
match
---
name: dag_id [42064,42070]
name: dag_id [42567,42573]
===
match
---
name: log [56003,56006]
name: log [56506,56509]
===
match
---
atom_expr [29287,29338]
atom_expr [29541,29592]
===
match
---
name: delete [18460,18466]
name: delete [18460,18466]
===
match
---
annassign [50989,51017]
annassign [51492,51520]
===
match
---
suite [27918,82655]
suite [28172,83158]
===
match
---
tfpdef [56098,56112]
tfpdef [56601,56615]
===
match
---
trailer [44866,44877]
trailer [45369,45380]
===
match
---
except_clause [12739,12754]
except_clause [12739,12754]
===
match
---
name: start_date [24695,24705]
name: start_date [24695,24705]
===
match
---
name: log [78747,78750]
name: log [79250,79253]
===
match
---
operator: , [43267,43268]
operator: , [43770,43771]
===
match
---
name: provide_session [76041,76056]
name: provide_session [76544,76559]
===
match
---
comparison [44160,44197]
comparison [44663,44700]
===
match
---
operator: = [67095,67096]
operator: = [67598,67599]
===
match
---
operator: , [40100,40101]
operator: , [40603,40604]
===
match
---
atom_expr [80733,80748]
atom_expr [81236,81251]
===
match
---
trailer [56006,56011]
trailer [56509,56514]
===
match
---
trailer [14078,14087]
trailer [14078,14087]
===
match
---
name: isoformat [18714,18723]
name: isoformat [18714,18723]
===
match
---
number: 0 [65778,65779]
number: 0 [66281,66282]
===
match
---
atom_expr [16225,16235]
atom_expr [16225,16235]
===
match
---
name: session [34440,34447]
name: session [34943,34950]
===
match
---
name: timeout [79611,79618]
name: timeout [80114,80121]
===
match
---
name: self [77114,77118]
name: self [77617,77621]
===
match
---
trailer [23566,23570]
trailer [23566,23570]
===
match
---
operator: = [30737,30738]
operator: = [30991,30992]
===
match
---
name: state [33947,33952]
name: state [34450,34455]
===
match
---
name: str [5335,5338]
name: str [5335,5338]
===
match
---
name: expected_start_date [70079,70098]
name: expected_start_date [70582,70601]
===
match
---
atom_expr [41313,41330]
atom_expr [41816,41833]
===
match
---
trailer [19172,19228]
trailer [19172,19228]
===
match
---
decorated [50580,53483]
decorated [51083,53986]
===
match
---
name: with_hint [16133,16142]
name: with_hint [16133,16142]
===
match
---
comparison [76342,76376]
comparison [76845,76879]
===
match
---
name: models [33827,33833]
name: models [34330,34336]
===
match
---
name: log [72026,72029]
name: log [72529,72532]
===
match
---
name: int [36721,36724]
name: int [37224,37227]
===
match
---
simple_stmt [34223,34363]
simple_stmt [34726,34866]
===
match
---
name: task_concurrency_limit [43813,43835]
name: task_concurrency_limit [44316,44338]
===
match
---
return_stmt [11473,11497]
return_stmt [11473,11497]
===
match
---
name: SUCCESS [16279,16286]
name: SUCCESS [16279,16286]
===
match
---
operator: , [25019,25020]
operator: , [25019,25020]
===
match
---
name: filter [68455,68461]
name: filter [68958,68964]
===
match
---
expr_stmt [18521,18613]
expr_stmt [18521,18613]
===
match
---
trailer [55301,55323]
trailer [55804,55826]
===
match
---
simple_stmt [77678,77804]
simple_stmt [78181,78307]
===
match
---
expr_stmt [57246,57308]
expr_stmt [57749,57811]
===
match
---
trailer [16062,16119]
trailer [16062,16119]
===
match
---
trailer [4077,4079]
trailer [4077,4079]
===
match
---
name: close [12691,12696]
name: close [12691,12696]
===
match
---
number: 0 [48498,48499]
number: 0 [49001,49002]
===
match
---
operator: = [54249,54250]
operator: = [54752,54753]
===
match
---
argument [54135,54168]
argument [54638,54671]
===
match
---
name: filter [49830,49836]
name: filter [50333,50339]
===
match
---
atom_expr [50439,50446]
atom_expr [50942,50949]
===
match
---
operator: , [34310,34311]
operator: , [34813,34814]
===
match
---
name: start [8549,8554]
name: start [8549,8554]
===
match
---
trailer [55297,55301]
trailer [55800,55804]
===
match
---
trailer [9134,9147]
trailer [9134,9147]
===
match
---
name: self [77853,77857]
name: self [78356,78360]
===
match
---
name: dag [16778,16781]
name: dag [16778,16781]
===
match
---
simple_stmt [68691,68774]
simple_stmt [69194,69277]
===
match
---
trailer [16256,16315]
trailer [16256,16315]
===
match
---
operator: , [17404,17405]
operator: , [17404,17405]
===
match
---
try_stmt [60389,61112]
try_stmt [60892,61615]
===
match
---
name: self [29366,29370]
name: self [29620,29624]
===
match
---
name: models [35174,35180]
name: models [35677,35683]
===
match
---
name: job_id [54575,54581]
name: job_id [55078,55084]
===
match
---
name: dict [71007,71011]
name: dict [71510,71514]
===
match
---
name: _debug_dump [31407,31418]
name: _debug_dump [31784,31795]
===
match
---
if_stmt [20339,20594]
if_stmt [20339,20594]
===
match
---
name: state [33841,33846]
name: state [34344,34349]
===
match
---
name: grace_multiplier [32384,32400]
name: grace_multiplier [32887,32903]
===
match
---
simple_stmt [78190,78280]
simple_stmt [78693,78783]
===
match
---
subscriptlist [4483,4491]
subscriptlist [4483,4491]
===
match
---
name: request [25008,25015]
name: request [25008,25015]
===
match
---
atom_expr [8022,8049]
atom_expr [8022,8049]
===
match
---
argument [8813,8825]
argument [8813,8825]
===
match
---
simple_stmt [42181,42241]
simple_stmt [42684,42744]
===
match
---
return_stmt [39430,39451]
return_stmt [39933,39954]
===
match
---
name: dttm [17225,17229]
name: dttm [17225,17229]
===
match
---
string: """         :return: when this started to process the file         :rtype: datetime         """ [14097,14192]
string: """         :return: when this started to process the file         :rtype: datetime         """ [14097,14192]
===
match
---
tfpdef [70617,70633]
tfpdef [71120,71136]
===
match
---
operator: , [36771,36772]
operator: , [37274,37275]
===
match
---
name: self [76390,76394]
name: self [76893,76897]
===
match
---
name: Pipe [8808,8812]
name: Pipe [8808,8812]
===
match
---
trailer [15865,15884]
trailer [15865,15884]
===
match
---
trailer [58688,58700]
trailer [59191,59203]
===
match
---
string: 'dag_model' [38675,38686]
string: 'dag_model' [39178,39189]
===
match
---
name: _process [11371,11379]
name: _process [11371,11379]
===
match
---
operator: = [69866,69867]
operator: = [70369,70370]
===
match
---
string: "%s\n%s received, printing debug\n%s" [31685,31722]
string: "%s\n%s received, printing debug\n%s" [32188,32225]
===
match
---
arglist [20516,20541]
arglist [20516,20541]
===
match
---
expr_stmt [36853,36884]
expr_stmt [37356,37387]
===
match
---
simple_stmt [21457,21935]
simple_stmt [21457,21935]
===
match
---
name: LoggingMixin [2619,2631]
name: LoggingMixin [2619,2631]
===
match
---
name: state [80605,80610]
name: state [81108,81113]
===
match
---
import_as_names [2922,2995]
import_as_names [2922,2995]
===
match
---
simple_stmt [46489,46980]
simple_stmt [46992,47483]
===
match
---
raise_stmt [50760,50811]
raise_stmt [51263,51314]
===
match
---
operator: , [46914,46915]
operator: , [47417,47418]
===
match
---
testlist [27059,27087]
testlist [27059,27087]
===
match
---
expr_stmt [36676,36725]
expr_stmt [37179,37228]
===
match
---
argument [74408,74432]
argument [74911,74935]
===
match
---
name: settings [1560,1568]
name: settings [1560,1568]
===
match
---
name: session [68616,68623]
name: session [69119,69126]
===
match
---
name: list [64250,64254]
name: list [64753,64757]
===
match
---
name: len [41738,41741]
name: len [42241,42244]
===
match
---
dictorsetmaker [50195,50242]
dictorsetmaker [50698,50745]
===
match
---
trailer [13333,13342]
trailer [13333,13342]
===
match
---
trailer [20973,20977]
trailer [20973,20977]
===
match
---
atom_expr [16577,16587]
atom_expr [16577,16587]
===
match
---
trailer [45602,45618]
trailer [46105,46121]
===
match
---
suite [77228,77804]
suite [77731,78307]
===
match
---
expr_stmt [30052,30100]
expr_stmt [30306,30354]
===
match
---
annassign [54039,54096]
annassign [54542,54599]
===
match
---
atom_expr [49915,49962]
atom_expr [50418,50465]
===
match
---
string: "Exited execute loop" [56012,56033]
string: "Exited execute loop" [56515,56536]
===
match
---
name: pickle_dags [56392,56403]
name: pickle_dags [56895,56906]
===
match
---
name: dag_ids [56425,56432]
name: dag_ids [56928,56935]
===
match
---
name: max_active_runs [72234,72249]
name: max_active_runs [72737,72752]
===
match
---
atom_expr [34314,34342]
atom_expr [34817,34845]
===
match
---
name: end_date [24725,24733]
name: end_date [24725,24733]
===
match
---
trailer [54774,54794]
trailer [55277,55297]
===
match
---
if_stmt [58097,58497]
if_stmt [58600,59000]
===
match
---
name: timer [59196,59201]
name: timer [59699,59704]
===
match
---
atom_expr [12670,12698]
atom_expr [12670,12698]
===
match
---
name: Stats [20904,20909]
name: Stats [20904,20909]
===
match
---
name: self [62935,62939]
name: self [63438,63442]
===
match
---
suite [72664,76035]
suite [73167,76538]
===
match
---
comparison [22091,22133]
comparison [22091,22133]
===
match
---
atom_expr [58013,58037]
atom_expr [58516,58540]
===
match
---
simple_stmt [19151,19229]
simple_stmt [19151,19229]
===
match
---
atom_expr [50726,50746]
atom_expr [51229,51249]
===
match
---
name: attempt [78962,78969]
name: attempt [79465,79472]
===
match
---
operator: , [38171,38172]
operator: , [38674,38675]
===
match
---
simple_stmt [54014,54097]
simple_stmt [54517,54600]
===
match
---
name: call_regular_interval [57652,57673]
name: call_regular_interval [58155,58176]
===
match
---
trailer [49279,49286]
trailer [49782,49789]
===
match
---
arglist [17368,17439]
arglist [17368,17439]
===
match
---
name: num_times_parse_dags [30057,30077]
name: num_times_parse_dags [30311,30331]
===
match
---
atom_expr [39848,39912]
atom_expr [40351,40415]
===
match
---
name: airflow [2183,2190]
name: airflow [2183,2190]
===
match
---
comparison [42490,42538]
comparison [42993,43041]
===
match
---
operator: , [19728,19729]
operator: , [19728,19729]
===
match
---
name: UNIT_TEST_MODE [24887,24901]
name: UNIT_TEST_MODE [24887,24901]
===
match
---
trailer [61136,61138]
trailer [61639,61641]
===
match
---
name: models [35372,35378]
name: models [35875,35881]
===
match
---
operator: , [18091,18092]
operator: , [18091,18092]
===
match
---
name: dagbag [27032,27038]
name: dagbag [27032,27038]
===
match
---
name: pid [11075,11078]
name: pid [11075,11078]
===
match
---
name: DagBag [23848,23854]
name: DagBag [23848,23854]
===
match
---
trailer [80506,80524]
trailer [81009,81027]
===
match
---
atom_expr [51075,51095]
atom_expr [51578,51598]
===
match
---
trailer [49169,49182]
trailer [49672,49685]
===
match
---
arglist [23458,23482]
arglist [23458,23482]
===
match
---
name: close [13642,13647]
name: close [13642,13647]
===
match
---
name: dag_run [73669,73676]
name: dag_run [74172,74179]
===
match
---
string: "Waiting for %s" [13543,13559]
string: "Waiting for %s" [13543,13559]
===
match
---
operator: , [29612,29613]
operator: , [29866,29867]
===
match
---
trailer [15189,15215]
trailer [15189,15215]
===
match
---
simple_stmt [18201,18229]
simple_stmt [18201,18229]
===
match
---
string: "Waiting for processors to finish since we're using sqlite" [58373,58432]
string: "Waiting for processors to finish since we're using sqlite" [58876,58935]
===
match
---
name: Session [23894,23901]
name: Session [23894,23901]
===
match
---
trailer [38504,38517]
trailer [39007,39020]
===
match
---
decorated [78285,78417]
decorated [78788,78920]
===
match
---
simple_stmt [8705,8757]
simple_stmt [8705,8757]
===
match
---
name: run_with_db_retries [2799,2818]
name: run_with_db_retries [2799,2818]
===
match
---
expr_stmt [20793,20817]
expr_stmt [20793,20817]
===
match
---
name: pickle_dags [56404,56415]
name: pickle_dags [56907,56918]
===
match
---
name: process_file [25171,25183]
name: process_file [25171,25183]
===
match
---
name: set_state [34419,34428]
name: set_state [34922,34931]
===
match
---
trailer [17101,17120]
trailer [17101,17120]
===
match
---
name: send_email [20658,20668]
name: send_email [20658,20668]
===
match
---
name: dagbag [71635,71641]
name: dagbag [72138,72144]
===
match
---
trailer [65383,65385]
trailer [65886,65888]
===
match
---
trailer [80584,80590]
trailer [81087,81093]
===
match
---
trailer [16079,16083]
trailer [16079,16083]
===
match
---
trailer [29451,29476]
trailer [29705,29730]
===
match
---
operator: @ [78422,78423]
operator: @ [78925,78926]
===
match
---
trailer [17732,17739]
trailer [17732,17739]
===
match
---
operator: , [77971,77972]
operator: , [78474,78475]
===
match
---
operator: , [22365,22366]
operator: , [22365,22366]
===
match
---
atom_expr [79990,80005]
atom_expr [80493,80508]
===
match
---
trailer [66576,66585]
trailer [67079,67088]
===
match
---
atom_expr [26921,26984]
atom_expr [26921,26984]
===
match
---
name: session [49948,49955]
name: session [50451,50458]
===
match
---
name: log [7118,7121]
name: log [7118,7121]
===
match
---
trailer [71114,71121]
trailer [71617,71624]
===
match
---
simple_stmt [3260,3764]
simple_stmt [3260,3764]
===
match
---
simple_stmt [13662,13674]
simple_stmt [13662,13674]
===
match
---
expr_stmt [3078,3102]
expr_stmt [3078,3102]
===
match
---
name: try_adopt_task_instances [81356,81380]
name: try_adopt_task_instances [81859,81883]
===
match
---
trailer [29291,29298]
trailer [29545,29552]
===
match
---
name: dag_ids [33628,33635]
name: dag_ids [34131,34138]
===
match
---
subscriptlist [36026,36046]
subscriptlist [36529,36549]
===
match
---
if_stmt [62889,62981]
if_stmt [63392,63484]
===
match
---
atom_expr [24685,24705]
atom_expr [24685,24705]
===
match
---
name: result [36878,36884]
name: result [37381,37387]
===
match
---
operator: = [19267,19268]
operator: = [19267,19268]
===
match
---
name: self [59073,59077]
name: self [59576,59580]
===
match
---
strings [42599,42748]
strings [43102,43251]
===
match
---
argument [16170,16190]
argument [16170,16190]
===
match
---
argument [75570,75585]
argument [76073,76088]
===
match
---
name: self [72539,72543]
name: self [73042,73046]
===
match
---
expr_stmt [20256,20280]
expr_stmt [20256,20280]
===
match
---
name: _instance_id [4801,4813]
name: _instance_id [4801,4813]
===
match
---
atom_expr [38854,38886]
atom_expr [39357,39389]
===
match
---
string: "Not executing %s since it requires %s slots " [44258,44304]
string: "Not executing %s since it requires %s slots " [44761,44807]
===
match
---
name: executable_tis [37497,37511]
name: executable_tis [38000,38014]
===
match
---
trailer [30395,30397]
trailer [30649,30651]
===
match
---
trailer [73101,73105]
trailer [73604,73608]
===
match
---
operator: , [59846,59847]
operator: , [60349,60350]
===
match
---
atom_expr [54639,54662]
atom_expr [55142,55165]
===
match
---
name: dag_file_processor [7812,7830]
name: dag_file_processor [7812,7830]
===
match
---
name: join [82052,82056]
name: join [82555,82559]
===
match
---
atom_expr [42073,42093]
atom_expr [42576,42596]
===
match
---
simple_stmt [19067,19110]
simple_stmt [19067,19110]
===
match
---
operator: , [22490,22491]
operator: , [22490,22491]
===
match
---
atom_expr [38458,38477]
atom_expr [38961,38980]
===
match
---
name: dag_run [65313,65320]
name: dag_run [65816,65823]
===
match
---
name: sla [21261,21264]
name: sla [21261,21264]
===
match
---
if_stmt [59932,60257]
if_stmt [60435,60760]
===
match
---
trailer [16538,16545]
trailer [16538,16545]
===
match
---
operator: { [20705,20706]
operator: { [20705,20706]
===
match
---
operator: , [24090,24091]
operator: , [24090,24091]
===
match
---
name: self [60581,60585]
name: self [61084,61088]
===
match
---
name: SIGINT [30892,30898]
name: SIGINT [31146,31152]
===
match
---
atom_expr [36497,36667]
atom_expr [37000,37170]
===
match
---
simple_stmt [42111,42165]
simple_stmt [42614,42668]
===
match
---
name: pools [77987,77992]
name: pools [78490,78495]
===
match
---
simple_stmt [66633,66639]
simple_stmt [67136,67142]
===
match
---
atom_expr [20134,20145]
atom_expr [20134,20145]
===
match
---
name: new_state [60506,60515]
name: new_state [61009,61018]
===
match
---
trailer [16899,17058]
trailer [16899,17058]
===
match
---
name: AbstractDagFileProcessorProcess [3175,3206]
name: AbstractDagFileProcessorProcess [3175,3206]
===
match
---
sync_comp_for [64186,64209]
sync_comp_for [64689,64712]
===
match
---
trailer [60357,60366]
trailer [60860,60869]
===
match
---
argument [46884,46914]
argument [47387,47417]
===
match
---
operator: , [29645,29646]
operator: , [29899,29900]
===
match
---
simple_stmt [77617,77669]
simple_stmt [78120,78172]
===
match
---
simple_stmt [24043,24179]
simple_stmt [24043,24179]
===
match
---
name: self [9167,9171]
name: self [9167,9171]
===
match
---
trailer [68844,68848]
trailer [69347,69351]
===
match
---
operator: , [1325,1326]
operator: , [1325,1326]
===
match
---
atom_expr [36014,36047]
atom_expr [36517,36550]
===
match
---
name: session [61169,61176]
name: session [61672,61679]
===
match
---
atom_expr [46499,46979]
atom_expr [47002,47482]
===
match
---
import_from [1339,1382]
import_from [1339,1382]
===
match
---
trailer [39594,39598]
trailer [40097,40101]
===
match
---
name: _debug_dump [31027,31038]
name: _debug_dump [31281,31292]
===
match
---
atom_expr [44987,45008]
atom_expr [45490,45511]
===
match
---
operator: , [4486,4487]
operator: , [4486,4487]
===
match
---
simple_stmt [40732,40815]
simple_stmt [41235,41318]
===
match
---
name: execution_date [18570,18584]
name: execution_date [18570,18584]
===
match
---
trailer [74011,74018]
trailer [74514,74521]
===
match
---
operator: == [79494,79496]
operator: == [79997,79999]
===
match
---
name: session [34334,34341]
name: session [34837,34844]
===
match
---
operator: , [1239,1240]
operator: , [1239,1240]
===
match
---
trailer [33627,33635]
trailer [34130,34138]
===
match
---
name: get [65145,65148]
name: get [65648,65651]
===
match
---
name: dm [68331,68333]
name: dm [68834,68836]
===
match
---
name: skip_locked [81254,81265]
name: skip_locked [81757,81768]
===
match
---
simple_stmt [3122,3143]
simple_stmt [3122,3143]
===
match
---
trailer [13606,13608]
trailer [13606,13608]
===
match
---
name: dag_id [74329,74335]
name: dag_id [74832,74838]
===
match
---
string: 'scheduler.orphaned_tasks.adopted' [81887,81921]
string: 'scheduler.orphaned_tasks.adopted' [82390,82424]
===
match
---
operator: = [3870,3871]
operator: = [3870,3871]
===
match
---
operator: = [8798,8799]
operator: = [8798,8799]
===
match
---
simple_stmt [24824,24851]
simple_stmt [24824,24851]
===
match
---
name: sla [21180,21183]
name: sla [21180,21183]
===
match
---
name: session [75409,75416]
name: session [75912,75919]
===
match
---
param [35933,35951]
param [36436,36454]
===
match
---
and_test [10901,10947]
and_test [10901,10947]
===
match
---
arglist [38458,38517]
arglist [38961,39020]
===
match
---
name: task_instance_str [39506,39523]
name: task_instance_str [40009,40026]
===
match
---
strings [51360,51474]
strings [51863,51977]
===
match
---
trailer [18498,18505]
trailer [18498,18505]
===
match
---
expr_stmt [33451,34005]
expr_stmt [33954,34508]
===
match
---
simple_stmt [73463,73495]
simple_stmt [73966,73998]
===
match
---
arglist [79801,79857]
arglist [80304,80360]
===
match
---
name: dttm [17479,17483]
name: dttm [17479,17483]
===
match
---
name: dagbag [23840,23846]
name: dagbag [23840,23846]
===
match
---
operator: , [34438,34439]
operator: , [34941,34942]
===
match
---
trailer [37737,37749]
trailer [38240,38252]
===
match
---
operator: } [19564,19565]
operator: } [19564,19565]
===
match
---
trailer [12222,12231]
trailer [12222,12231]
===
match
---
dotted_name [1574,1595]
dotted_name [1574,1595]
===
match
---
operator: , [41274,41275]
operator: , [41777,41778]
===
match
---
name: callback_requests [5348,5365]
name: callback_requests [5348,5365]
===
match
---
suite [73450,74654]
suite [73953,75157]
===
match
---
trailer [74292,74300]
trailer [74795,74803]
===
match
---
name: callback_requests [56452,56469]
name: callback_requests [56955,56972]
===
match
---
simple_stmt [74564,74632]
simple_stmt [75067,75135]
===
match
---
name: self [76098,76102]
name: self [76601,76605]
===
match
---
trailer [68834,68844]
trailer [69337,69347]
===
match
---
operator: = [47302,47303]
operator: = [47805,47806]
===
match
---
trailer [4476,4493]
trailer [4476,4493]
===
match
---
tfpdef [35933,35950]
tfpdef [36436,36453]
===
match
---
name: _do_scheduling [58590,58604]
name: _do_scheduling [59093,59107]
===
match
---
operator: = [29512,29513]
operator: = [29766,29767]
===
match
---
name: debug [39373,39378]
name: debug [39876,39881]
===
match
---
atom_expr [81512,81546]
atom_expr [82015,82049]
===
match
---
simple_stmt [69995,70060]
simple_stmt [70498,70563]
===
match
---
name: log [58363,58366]
name: log [58866,58869]
===
match
---
operator: , [41600,41601]
operator: , [42103,42104]
===
match
---
atom_expr [16075,16118]
atom_expr [16075,16118]
===
match
---
expr_stmt [29731,29751]
expr_stmt [29985,30005]
===
match
---
atom_expr [50195,50203]
atom_expr [50698,50706]
===
match
---
name: DagRun [80876,80882]
name: DagRun [81379,81385]
===
match
---
name: CallbackRequest [56146,56161]
name: CallbackRequest [56649,56664]
===
match
---
simple_stmt [65349,65358]
simple_stmt [65852,65861]
===
match
---
if_stmt [39312,39452]
if_stmt [39815,39955]
===
match
---
simple_stmt [858,873]
simple_stmt [858,873]
===
match
---
expr_stmt [18331,18365]
expr_stmt [18331,18365]
===
match
---
name: self [35927,35931]
name: self [36430,36434]
===
match
---
name: file_path [6856,6865]
name: file_path [6856,6865]
===
match
---
name: fallback [57916,57924]
name: fallback [58419,58427]
===
match
---
simple_stmt [9811,9893]
simple_stmt [9811,9893]
===
match
---
name: Optional [4327,4335]
name: Optional [4327,4335]
===
match
---
return_stmt [5052,5074]
return_stmt [5052,5074]
===
match
---
name: expunge_all [58689,58700]
name: expunge_all [59192,59203]
===
match
---
arglist [80976,81016]
arglist [81479,81519]
===
match
---
name: int [29281,29284]
name: int [29535,29538]
===
match
---
trailer [27280,27299]
trailer [27280,27299]
===
match
---
fstring_expr [19554,19565]
fstring_expr [19554,19565]
===
match
---
trailer [10008,10022]
trailer [10008,10022]
===
match
---
atom_expr [12476,12488]
atom_expr [12476,12488]
===
match
---
name: QUEUED [78153,78159]
name: QUEUED [78656,78662]
===
match
---
argument [9219,9270]
argument [9219,9270]
===
match
---
atom_expr [35240,35266]
atom_expr [35743,35769]
===
match
---
trailer [26929,26937]
trailer [26929,26937]
===
match
---
trailer [6887,6940]
trailer [6887,6940]
===
match
---
atom_expr [67920,68181]
atom_expr [68423,68684]
===
match
---
trailer [47136,47140]
trailer [47639,47643]
===
match
---
param [29691,29697]
param [29945,29951]
===
match
---
operator: -> [32840,32842]
operator: -> [33343,33345]
===
match
---
trailer [66241,66246]
trailer [66744,66749]
===
match
---
trailer [7084,7150]
trailer [7084,7150]
===
match
---
operator: , [69702,69703]
operator: , [70205,70206]
===
match
---
name: log [10966,10969]
name: log [10966,10969]
===
match
---
trailer [31382,31387]
trailer [31759,31764]
===
match
---
atom [71126,71156]
atom [71629,71659]
===
match
---
name: State [80021,80026]
name: State [80524,80529]
===
match
---
annassign [30625,30665]
annassign [30879,30919]
===
match
---
operator: * [31816,31817]
operator: * [32319,32320]
===
match
---
operator: == [32551,32553]
operator: == [33054,33056]
===
match
---
name: _critical_section_execute_task_instances [66023,66063]
name: _critical_section_execute_task_instances [66526,66566]
===
match
---
trailer [76297,76330]
trailer [76800,76833]
===
match
---
atom_expr [21261,21282]
atom_expr [21261,21282]
===
match
---
name: ti_prop_update [34905,34919]
name: ti_prop_update [35408,35422]
===
match
---
name: pickle_dags [53649,53660]
name: pickle_dags [54152,54163]
===
match
---
param [3915,3930]
param [3915,3930]
===
match
---
trailer [58928,58952]
trailer [59431,59455]
===
match
---
if_stmt [74862,75345]
if_stmt [75365,75848]
===
match
---
if_stmt [10295,10432]
if_stmt [10295,10432]
===
match
---
name: prohibit_commit [2951,2966]
name: prohibit_commit [2951,2966]
===
match
---
operator: - [32603,32604]
operator: - [33106,33107]
===
match
---
name: terminate [10455,10464]
name: terminate [10455,10464]
===
match
---
name: dag [72158,72161]
name: dag [72661,72664]
===
match
---
name: self [73960,73964]
name: self [74463,74467]
===
match
---
name: log [53746,53749]
name: log [54249,54252]
===
match
---
atom_expr [11970,11992]
atom_expr [11970,11992]
===
match
---
name: str [3989,3992]
name: str [3989,3992]
===
match
---
name: sla [19888,19891]
name: sla [19888,19891]
===
match
---
trailer [60692,60710]
trailer [61195,61213]
===
match
---
simple_stmt [36934,36970]
simple_stmt [37437,37473]
===
match
---
atom_expr [16997,17005]
atom_expr [16997,17005]
===
match
---
trailer [64040,64047]
trailer [64543,64550]
===
match
---
param [50630,50635]
param [51133,51138]
===
match
---
trailer [76609,76617]
trailer [77112,77120]
===
match
---
name: sum [37977,37980]
name: sum [38480,38483]
===
match
---
simple_stmt [22597,22959]
simple_stmt [22597,22959]
===
match
---
trailer [62900,62917]
trailer [63403,63420]
===
match
---
trailer [54754,54756]
trailer [55257,55259]
===
match
---
operator: , [3994,3995]
operator: , [3994,3995]
===
match
---
name: get_task [24483,24491]
name: get_task [24483,24491]
===
match
---
arglist [76405,76485]
arglist [76908,76988]
===
match
---
operator: , [57752,57753]
operator: , [58255,58256]
===
match
---
parameters [14381,14387]
parameters [14381,14387]
===
match
---
name: max_tis [16447,16454]
name: max_tis [16447,16454]
===
match
---
trailer [59150,59156]
trailer [59653,59659]
===
match
---
param [31066,31071]
param [31320,31325]
===
match
---
name: is_lock_not_available_error [60918,60945]
name: is_lock_not_available_error [61421,61448]
===
match
---
fstring_expr [78044,78055]
fstring_expr [78547,78558]
===
match
---
name: session [76649,76656]
name: session [77152,77159]
===
match
---
atom_expr [72384,72418]
atom_expr [72887,72921]
===
match
---
trailer [73615,73622]
trailer [74118,74125]
===
match
---
name: merge [73899,73904]
name: merge [74402,74407]
===
match
---
trailer [78995,79001]
trailer [79498,79504]
===
match
---
name: get_email_address_list [20444,20466]
name: get_email_address_list [20444,20466]
===
match
---
atom_expr [77783,77793]
atom_expr [78286,78296]
===
match
---
trailer [67126,67135]
trailer [67629,67638]
===
match
---
trailer [80012,80019]
trailer [80515,80522]
===
match
---
atom_expr [76298,76312]
atom_expr [76801,76815]
===
match
---
testlist_comp [60656,60725]
testlist_comp [61159,61228]
===
match
---
while_stmt [17133,17515]
while_stmt [17133,17515]
===
match
---
testlist_comp [69496,69529]
testlist_comp [69999,70032]
===
match
---
name: List [39741,39745]
name: List [40244,40248]
===
match
---
name: task_id [24431,24438]
name: task_id [24431,24438]
===
match
---
name: group_by [36620,36628]
name: group_by [37123,37131]
===
match
---
name: following_schedule [17181,17199]
name: following_schedule [17181,17199]
===
match
---
name: x [50451,50452]
name: x [50954,50955]
===
match
---
simple_stmt [40853,40886]
simple_stmt [41356,41389]
===
match
---
atom_expr [38973,39115]
atom_expr [39476,39618]
===
match
---
trailer [74815,74830]
trailer [75318,75333]
===
match
---
name: result [13719,13725]
name: result [13719,13725]
===
match
---
operator: = [20766,20767]
operator: = [20766,20767]
===
match
---
operator: = [4567,4568]
operator: = [4567,4568]
===
match
---
name: task_instance_str [50407,50424]
name: task_instance_str [50910,50927]
===
match
---
name: DagCallbackRequest [74239,74257]
name: DagCallbackRequest [74742,74760]
===
match
---
atom_expr [51492,51505]
atom_expr [51995,52008]
===
match
---
operator: * [29691,29692]
operator: * [29945,29946]
===
match
---
name: dagbag_file [22122,22133]
name: dagbag_file [22122,22133]
===
match
---
operator: , [45921,45922]
operator: , [46424,46425]
===
match
---
name: email_sent [18911,18921]
name: email_sent [18911,18921]
===
match
---
simple_stmt [77237,77326]
simple_stmt [77740,77829]
===
match
---
name: CallbackRequest [4028,4043]
name: CallbackRequest [4028,4043]
===
match
---
trailer [9171,9190]
trailer [9171,9190]
===
match
---
name: logging_mixin [2598,2611]
name: logging_mixin [2598,2611]
===
match
---
atom_expr [55135,55274]
atom_expr [55638,55777]
===
match
---
expr_stmt [59017,59056]
expr_stmt [59520,59559]
===
match
---
name: __get_concurrency_maps [40170,40192]
name: __get_concurrency_maps [40673,40695]
===
match
---
name: SUCCESS [18084,18091]
name: SUCCESS [18084,18091]
===
match
---
simple_stmt [74118,74204]
simple_stmt [74621,74707]
===
match
---
operator: , [32792,32793]
operator: , [33295,33296]
===
match
---
name: using_sqlite [34177,34189]
name: using_sqlite [34680,34692]
===
match
---
if_stmt [12363,12402]
if_stmt [12363,12402]
===
match
---
trailer [16263,16269]
trailer [16263,16269]
===
match
---
operator: , [57930,57931]
operator: , [58433,58434]
===
match
---
trailer [16579,16587]
trailer [16579,16587]
===
match
---
name: session [22550,22557]
name: session [22550,22557]
===
match
---
comparison [24421,24454]
comparison [24421,24454]
===
match
---
name: SCHEDULED [38630,38639]
name: SCHEDULED [39133,39142]
===
match
---
argument [60506,60528]
argument [61009,61031]
===
match
---
name: ti [41287,41289]
name: ti [41790,41792]
===
match
---
name: c [16647,16648]
name: c [16647,16648]
===
match
---
name: attempt [79124,79131]
name: attempt [79627,79634]
===
match
---
string: "DAG(s) %s retrieved from %s" [26833,26862]
string: "DAG(s) %s retrieved from %s" [26833,26862]
===
match
---
name: session [27023,27030]
name: session [27023,27030]
===
match
---
annassign [17993,18188]
annassign [17993,18188]
===
match
---
atom_expr [73108,73160]
atom_expr [73611,73663]
===
match
---
name: Optional [42960,42968]
name: Optional [43463,43471]
===
match
---
name: datetime [4655,4663]
name: datetime [4655,4663]
===
match
---
atom_expr [40079,40112]
atom_expr [40582,40615]
===
match
---
atom_expr [14248,14310]
atom_expr [14248,14310]
===
match
---
trailer [68302,68309]
trailer [68805,68812]
===
match
---
dotted_name [2086,2099]
dotted_name [2086,2099]
===
match
---
name: __init__ [30217,30225]
name: __init__ [30471,30479]
===
match
---
suite [76377,76506]
suite [76880,77009]
===
match
---
trailer [22255,22257]
trailer [22255,22257]
===
match
---
trailer [62939,62964]
trailer [63442,63467]
===
match
---
simple_stmt [80056,81041]
simple_stmt [80559,81544]
===
match
---
name: datetime [50884,50892]
name: datetime [51387,51395]
===
match
---
expr_stmt [49879,49962]
expr_stmt [50382,50465]
===
match
---
name: signal [30878,30884]
name: signal [31132,31138]
===
match
---
operator: = [38365,38366]
operator: = [38868,38869]
===
match
---
trailer [52295,52307]
trailer [52798,52810]
===
match
---
trailer [45496,45512]
trailer [45999,46015]
===
match
---
name: float [29551,29556]
name: float [29805,29810]
===
match
---
name: emails [20568,20574]
name: emails [20568,20574]
===
match
---
name: utils [2226,2231]
name: utils [2226,2231]
===
match
---
param [10050,10071]
param [10050,10071]
===
match
---
name: int [25356,25359]
name: int [25356,25359]
===
match
---
trailer [66421,66425]
trailer [66924,66928]
===
match
---
operator: = [35510,35511]
operator: = [36013,36014]
===
match
---
name: is_alive [10915,10923]
name: is_alive [10915,10923]
===
insert-tree
---
funcdef [27842,28094]
    name: _is_parent_process [27846,27864]
    parameters [27864,27866]
    suite [27867,28094]
        simple_stmt [27872,28027]
            string: """     Returns True if the current process is the parent process. False if the current process is a child     process started by multiprocessing.     """ [27872,28026]
        simple_stmt [28031,28094]
            return_stmt [28031,28093]
                comparison [28038,28093]
                    atom_expr [28038,28076]
                        name: multiprocessing [28038,28053]
                        trailer [28053,28069]
                            name: current_process [28054,28069]
                        trailer [28069,28071]
                        trailer [28071,28076]
                            name: name [28072,28076]
                    operator: == [28077,28079]
                    string: 'MainProcess' [28080,28093]
to
file_input [825,82655]
at 49
===
insert-node
---
name: SchedulerJob [28102,28114]
to
classdef [27842,82655]
at 0
===
insert-node
---
name: BaseJob [28115,28122]
to
classdef [27842,82655]
at 1
===
insert-tree
---
simple_stmt [28177,29456]
    string: """     This SchedulerJob runs for a specific time interval and schedules the jobs     that are ready to run. It figures out the latest runs for each     task and sees if the dependencies for the next schedules are met.     If so, it creates appropriate TaskInstances and sends run commands to the     executor. It does this for each task in each DAG and repeats.      :param subdir: directory containing Python files with Airflow DAG         definitions, or a specific path to a file     :type subdir: str     :param num_runs: The number of times to run the scheduling loop. If you         have a large number of DAG files this could complete before each file         has been parsed. -1 for unlimited times.     :type num_runs: int     :param num_times_parse_dags: The number of times to try to parse each DAG file.         -1 for unlimited times.     :type num_times_parse_dags: int     :param processor_poll_interval: The number of seconds to wait between         polls of running processors     :type processor_poll_interval: int     :param do_pickle: once a DAG object is obtained by executing the Python         file, whether to serialize the DAG object to the DB     :type do_pickle: bool     :param log: override the default Logger     :type log: logging.Logger     """ [28177,29455]
to
suite [27918,82655]
at 0
===
insert-tree
---
if_stmt [31484,31598]
    not_test [31487,31511]
        atom_expr [31491,31511]
            name: _is_parent_process [31491,31509]
            trailer [31509,31511]
    suite [31512,31598]
        simple_stmt [31591,31598]
to
suite [31130,31398]
at 1
===
insert-tree
---
if_stmt [31861,31978]
    not_test [31864,31888]
        atom_expr [31868,31888]
            name: _is_parent_process [31868,31886]
            trailer [31886,31888]
    suite [31889,31978]
        simple_stmt [31971,31978]
to
suite [31475,31822]
at 0
===
delete-node
---
name: SchedulerJob [27848,27860]
===
===
delete-node
---
name: BaseJob [27861,27868]
===
===
delete-tree
---
simple_stmt [27923,29202]
    string: """     This SchedulerJob runs for a specific time interval and schedules the jobs     that are ready to run. It figures out the latest runs for each     task and sees if the dependencies for the next schedules are met.     If so, it creates appropriate TaskInstances and sends run commands to the     executor. It does this for each task in each DAG and repeats.      :param subdir: directory containing Python files with Airflow DAG         definitions, or a specific path to a file     :type subdir: str     :param num_runs: The number of times to run the scheduling loop. If you         have a large number of DAG files this could complete before each file         has been parsed. -1 for unlimited times.     :type num_runs: int     :param num_times_parse_dags: The number of times to try to parse each DAG file.         -1 for unlimited times.     :type num_times_parse_dags: int     :param processor_poll_interval: The number of seconds to wait between         polls of running processors     :type processor_poll_interval: int     :param do_pickle: once a DAG object is obtained by executing the Python         file, whether to serialize the DAG object to the DB     :type do_pickle: bool     :param log: override the default Logger     :type log: logging.Logger     """ [27923,29201]
