===
match
---
atom_expr [15855,15885]
atom_expr [15869,15899]
===
match
---
name: backend [3905,3912]
name: backend [3919,3926]
===
match
---
arglist [15061,15080]
arglist [15075,15094]
===
match
---
operator: = [4009,4010]
operator: = [4023,4024]
===
match
---
decorated [12905,13419]
decorated [12919,13433]
===
match
---
operator: , [4045,4046]
operator: , [4059,4060]
===
match
---
operator: { [9996,9997]
operator: { [10010,10011]
===
match
---
name: line [11202,11206]
name: line [11216,11220]
===
match
---
decorator [13424,13466]
decorator [13438,13480]
===
match
---
trailer [19037,19044]
trailer [19051,19058]
===
match
---
name: bash [1814,1818]
name: bash [1828,1832]
===
match
---
trailer [9211,9221]
trailer [9225,9235]
===
match
---
simple_stmt [3520,3541]
simple_stmt [3534,3555]
===
match
---
name: TaskInstanceKey [14513,14528]
name: TaskInstanceKey [14527,14542]
===
match
---
name: celery_executor [8290,8305]
name: celery_executor [8304,8319]
===
match
---
suite [8394,10733]
suite [8408,10747]
===
match
---
name: task_1 [15604,15610]
name: task_1 [15618,15624]
===
match
---
arglist [18642,18683]
arglist [18656,18697]
===
match
---
atom_expr [8619,8747]
atom_expr [8633,8761]
===
match
---
trailer [9821,9834]
trailer [9835,9848]
===
match
---
simple_stmt [14309,14342]
simple_stmt [14323,14356]
===
match
---
trailer [19677,19684]
trailer [19691,19698]
===
match
---
operator: , [12345,12346]
operator: , [12359,12360]
===
match
---
name: TaskInstance [13947,13959]
name: TaskInstance [13961,13973]
===
match
---
atom [12846,12859]
atom [12860,12873]
===
match
---
atom_expr [8894,8971]
atom_expr [8908,8985]
===
match
---
suite [6895,7688]
suite [6909,7702]
===
match
---
testlist_comp [11997,12017]
testlist_comp [12011,12031]
===
match
---
trailer [16689,16698]
trailer [16703,16712]
===
match
---
name: executor [7616,7624]
name: executor [7630,7638]
===
match
---
name: mark [10775,10779]
name: mark [10789,10793]
===
match
---
name: test_app [3417,3425]
name: test_app [3431,3439]
===
match
---
name: TaskInstanceKey [15659,15674]
name: TaskInstanceKey [15673,15688]
===
match
---
trailer [8779,8781]
trailer [8793,8795]
===
match
---
simple_stmt [13869,13932]
simple_stmt [13883,13946]
===
match
---
assert_stmt [6219,6315]
assert_stmt [6233,6329]
===
match
---
atom_expr [2447,2490]
atom_expr [2461,2504]
===
match
---
name: integration [18440,18451]
name: integration [18454,18465]
===
match
---
argument [13180,13196]
argument [13194,13210]
===
match
---
operator: = [15339,15340]
operator: = [15353,15354]
===
match
---
trailer [15978,15984]
trailer [15992,15998]
===
match
---
funcdef [2236,2280]
funcdef [2250,2294]
===
match
---
dotted_name [11453,11463]
dotted_name [11467,11477]
===
match
---
comparison [14409,14429]
comparison [14423,14443]
===
match
---
atom [2576,2602]
atom [2590,2616]
===
match
---
name: BaseKeyValueStoreBackend [17351,17375]
name: BaseKeyValueStoreBackend [17365,17389]
===
match
---
simple_stmt [11893,11934]
simple_stmt [11907,11948]
===
match
---
name: task_id [19406,19413]
name: task_id [19420,19427]
===
match
---
name: executor [14409,14417]
name: executor [14423,14431]
===
match
---
name: celery_executor [19988,20003]
name: celery_executor [20002,20017]
===
match
---
string: 'fake_simple_ti' [5980,5996]
string: 'fake_simple_ti' [5994,6010]
===
match
---
expr_stmt [14588,14662]
expr_stmt [14602,14676]
===
match
---
number: 2 [13569,13570]
number: 2 [13583,13584]
===
match
---
name: mark [17125,17129]
name: mark [17139,17143]
===
match
---
name: TestBulkStateFetcher [16911,16931]
name: TestBulkStateFetcher [16925,16945]
===
match
---
name: Celery [2619,2625]
name: Celery [2633,2639]
===
match
---
atom_expr [3334,3349]
atom_expr [3348,3363]
===
match
---
operator: { [9282,9283]
operator: { [9296,9297]
===
match
---
name: executor [8470,8478]
name: executor [8484,8492]
===
match
---
trailer [8967,8969]
trailer [8981,8983]
===
match
---
expr_stmt [7563,7603]
expr_stmt [7577,7617]
===
match
---
name: AirflowTaskTimeout [1485,1503]
name: AirflowTaskTimeout [1499,1517]
===
match
---
name: dag [15592,15595]
name: dag [15606,15609]
===
match
---
atom_expr [7465,7479]
atom_expr [7479,7493]
===
match
---
comparison [5717,5900]
comparison [5731,5914]
===
match
---
trailer [15285,15292]
trailer [15299,15306]
===
match
---
operator: = [20325,20326]
operator: = [20339,20340]
===
match
---
decorated [11939,12900]
decorated [11953,12914]
===
match
---
operator: = [15428,15429]
operator: = [15442,15443]
===
match
---
import_as_names [1118,1155]
import_as_names [1132,1169]
===
match
---
number: 1 [5629,5630]
number: 1 [5643,5644]
===
match
---
simple_stmt [7509,7551]
simple_stmt [7523,7565]
===
match
---
atom_expr [19228,19246]
atom_expr [19242,19260]
===
match
---
arglist [3913,3932]
arglist [3927,3946]
===
match
---
suite [18598,19462]
suite [18612,19476]
===
match
---
name: backend [10780,10787]
name: backend [10794,10801]
===
match
---
simple_stmt [8794,8987]
simple_stmt [8808,9001]
===
match
---
trailer [14933,14939]
trailer [14947,14953]
===
match
---
atom_expr [2389,2421]
atom_expr [2403,2435]
===
match
---
string: 'celery' [2398,2406]
string: 'celery' [2412,2420]
===
match
---
name: fake_execute_command [4292,4312]
name: fake_execute_command [4306,4326]
===
match
---
name: test_app [2608,2616]
name: test_app [2622,2630]
===
match
---
name: BashOperator [8619,8631]
name: BashOperator [8633,8645]
===
match
---
name: executor [14257,14265]
name: executor [14271,14279]
===
match
---
operator: = [15525,15526]
operator: = [15539,15540]
===
match
---
operator: , [2867,2868]
operator: , [2881,2882]
===
match
---
name: mock [916,920]
name: mock [930,934]
===
match
---
trailer [14298,14300]
trailer [14312,14314]
===
match
---
expr_stmt [15328,15342]
expr_stmt [15342,15356]
===
match
---
name: mock [11747,11751]
name: mock [11761,11765]
===
match
---
trailer [3576,3585]
trailer [3590,3599]
===
match
---
arith_expr [15277,15318]
arith_expr [15291,15332]
===
match
---
trailer [11118,11124]
trailer [11132,11138]
===
match
---
trailer [2809,2815]
trailer [2823,2829]
===
match
---
string: b'celery-task-meta-456' [17985,18008]
string: b'celery-task-meta-456' [17999,18022]
===
match
---
name: mock_mget [18043,18052]
name: mock_mget [18057,18066]
===
match
---
atom [9282,9290]
atom [9296,9304]
===
match
---
atom_expr [16144,16156]
atom_expr [16158,16170]
===
match
---
param [17277,17282]
param [17291,17296]
===
match
---
simple_stmt [13158,13221]
simple_stmt [13172,13235]
===
match
---
funcdef [13470,15035]
funcdef [13484,15049]
===
match
---
trailer [9061,9074]
trailer [9075,9088]
===
match
---
operator: { [14391,14392]
operator: { [14405,14406]
===
match
---
comparison [14357,14393]
comparison [14371,14407]
===
match
---
name: executor [11611,11619]
name: executor [11625,11633]
===
match
---
name: start_date [13038,13048]
name: start_date [13052,13062]
===
match
---
operator: == [20684,20686]
operator: == [20698,20700]
===
match
---
name: self [12108,12112]
name: self [12122,12126]
===
match
---
simple_stmt [18096,18166]
simple_stmt [18110,18180]
===
match
---
name: app [4317,4320]
name: app [4331,4334]
===
match
---
string: "INFO:airflow.executors.celery_executor.CeleryExecutor:" [9457,9513]
string: "INFO:airflow.executors.celery_executor.CeleryExecutor:" [9471,9527]
===
match
---
operator: } [17102,17103]
operator: } [17116,17117]
===
match
---
operator: -> [3695,3697]
operator: -> [3709,3711]
===
match
---
string: "task_2" [15526,15534]
string: "task_2" [15540,15548]
===
match
---
name: DAG [7200,7203]
name: DAG [7214,7217]
===
match
---
argument [13081,13087]
argument [13095,13101]
===
match
---
dotted_name [2283,2308]
dotted_name [2297,2322]
===
match
---
operator: = [13844,13845]
operator: = [13858,13859]
===
match
---
name: mock_backend [18753,18765]
name: mock_backend [18767,18779]
===
match
---
name: key_2 [16015,16020]
name: key_2 [16029,16034]
===
match
---
dotted_name [1315,1333]
dotted_name [1329,1347]
===
match
---
atom_expr [2109,2141]
atom_expr [2123,2155]
===
match
---
name: execute_date [4688,4700]
name: execute_date [4702,4714]
===
match
---
name: integration [7919,7930]
name: integration [7933,7944]
===
match
---
or_test [2375,2421]
or_test [2389,2435]
===
match
---
arith_expr [14854,14898]
arith_expr [14868,14912]
===
match
---
name: pytest [17156,17162]
name: pytest [17170,17176]
===
match
---
argument [13623,13629]
argument [13637,13643]
===
match
---
operator: { [20500,20501]
operator: { [20514,20515]
===
match
---
trailer [2117,2141]
trailer [2131,2155]
===
match
---
simple_stmt [15970,16042]
simple_stmt [15984,16056]
===
match
---
fstring_string: ( [16679,16680]
fstring_string: ( [16693,16694]
===
match
---
dotted_name [10768,10787]
dotted_name [10782,10801]
===
match
---
simple_stmt [20173,20203]
simple_stmt [20187,20217]
===
match
---
argument [7175,7194]
argument [7189,7208]
===
match
---
operator: , [10708,10709]
operator: , [10722,10723]
===
match
---
decorated [10738,11292]
decorated [10752,11306]
===
match
---
trailer [6015,6018]
trailer [6029,6032]
===
match
---
simple_stmt [16873,16903]
simple_stmt [16887,16917]
===
match
---
trailer [16755,16757]
trailer [16769,16771]
===
match
---
trailer [6409,6416]
trailer [6423,6430]
===
match
---
operator: @ [6704,6705]
operator: @ [6718,6719]
===
match
---
name: try_number [15631,15641]
name: try_number [15645,15655]
===
match
---
trailer [13249,13283]
trailer [13263,13297]
===
match
---
operator: - [13611,13612]
operator: - [13625,13626]
===
match
---
name: pytest [19770,19776]
name: pytest [19784,19790]
===
match
---
trailer [12247,12329]
trailer [12261,12343]
===
match
---
name: operators [1804,1813]
name: operators [1818,1827]
===
match
---
operator: = [8915,8916]
operator: = [8929,8930]
===
match
---
string: "test_check_for_stalled_adopted_tasks" [15361,15399]
string: "test_check_for_stalled_adopted_tasks" [15375,15413]
===
match
---
simple_stmt [14007,14040]
simple_stmt [14021,14054]
===
match
---
name: executor [14868,14876]
name: executor [14882,14890]
===
match
---
name: State [7850,7855]
name: State [7864,7869]
===
match
---
name: try_number [15714,15724]
name: try_number [15728,15738]
===
match
---
name: mock_backend [20020,20032]
name: mock_backend [20034,20046]
===
match
---
string: "DEBUG" [20128,20135]
string: "DEBUG" [20142,20149]
===
match
---
string: 'airflow' [4089,4098]
string: 'airflow' [4103,4112]
===
match
---
name: mock [11828,11832]
name: mock [11842,11846]
===
match
---
comparison [9457,9596]
comparison [9471,9610]
===
match
---
name: mark [7955,7959]
name: mark [7969,7973]
===
match
---
simple_stmt [11663,11684]
simple_stmt [11677,11698]
===
match
---
expr_stmt [15735,15778]
expr_stmt [15749,15792]
===
match
---
string: "airflow.executors.celery_executor.BulkStateFetcher" [18801,18853]
string: "airflow.executors.celery_executor.BulkStateFetcher" [18815,18867]
===
match
---
name: _prepare_app [10865,10877]
name: _prepare_app [10879,10891]
===
match
---
argument [18642,18665]
argument [18656,18679]
===
match
---
operator: == [10154,10156]
operator: == [10168,10170]
===
match
---
string: "redis" [7893,7900]
string: "redis" [7907,7914]
===
match
---
atom_expr [12643,12672]
atom_expr [12657,12686]
===
match
---
name: pytest [6705,6711]
name: pytest [6719,6725]
===
match
---
expr_stmt [15787,15961]
expr_stmt [15801,15975]
===
match
---
parameters [12989,12995]
parameters [13003,13009]
===
match
---
decorated [6625,7863]
decorated [6639,7877]
===
match
---
name: exec_date [15142,15151]
name: exec_date [15156,15165]
===
match
---
atom_expr [9813,9834]
atom_expr [9827,9848]
===
match
---
arglist [8929,8969]
arglist [8943,8983]
===
match
---
name: ValueError [12020,12030]
name: ValueError [12034,12044]
===
match
---
name: airflow [1796,1803]
name: airflow [1810,1817]
===
match
---
string: "true" [7188,7194]
string: "true" [7202,7208]
===
match
---
string: 'id' [7211,7215]
string: 'id' [7225,7229]
===
match
---
operator: { [14427,14428]
operator: { [14441,14442]
===
match
---
string: "true" [8678,8684]
string: "true" [8692,8698]
===
match
---
classdef [16905,20697]
classdef [16919,20711]
===
match
---
name: when [7542,7546]
name: when [7556,7560]
===
match
---
testlist_comp [7336,7482]
testlist_comp [7350,7496]
===
match
---
atom_expr [8690,8706]
atom_expr [8704,8720]
===
match
---
name: pytest [10739,10745]
name: pytest [10753,10759]
===
match
---
assert_stmt [9724,9793]
assert_stmt [9738,9807]
===
match
---
atom_expr [10157,10183]
atom_expr [10171,10197]
===
match
---
name: task [14105,14109]
name: task [14119,14123]
===
match
---
name: executor [9392,9400]
name: executor [9406,9414]
===
match
---
operator: == [14424,14426]
operator: == [14438,14440]
===
match
---
name: AsyncResult [14978,14989]
name: AsyncResult [14992,15003]
===
match
---
name: broker_url [2375,2385]
name: broker_url [2389,2399]
===
match
---
comparison [11249,11268]
comparison [11263,11282]
===
match
---
argument [20122,20135]
argument [20136,20149]
===
match
---
simple_stmt [13366,13419]
simple_stmt [13380,13433]
===
match
---
name: task_1 [13158,13164]
name: task_1 [13172,13178]
===
match
---
name: backend [7960,7967]
name: backend [7974,7981]
===
match
---
atom_expr [13551,13571]
atom_expr [13565,13585]
===
match
---
name: key [9283,9286]
name: key [9297,9300]
===
match
---
atom_expr [12537,12577]
atom_expr [12551,12591]
===
match
---
assert_stmt [16209,16252]
assert_stmt [16223,16266]
===
match
---
name: output [10432,10438]
name: output [10446,10452]
===
match
---
operator: , [7838,7839]
operator: , [7852,7853]
===
match
---
atom_expr [2619,2664]
atom_expr [2633,2678]
===
match
---
argument [4284,4312]
argument [4298,4326]
===
match
---
atom_expr [17967,17979]
atom_expr [17981,17993]
===
match
---
operator: { [9703,9704]
operator: { [9717,9718]
===
match
---
name: assert_not_called [12607,12624]
name: assert_not_called [12621,12638]
===
match
---
name: airflow [1509,1516]
name: airflow [1523,1530]
===
match
---
name: start_date [15536,15546]
name: start_date [15550,15560]
===
match
---
operator: - [13549,13550]
operator: - [13563,13564]
===
match
---
name: execute_command [12553,12568]
name: execute_command [12567,12582]
===
match
---
name: datetime [7465,7473]
name: datetime [7479,7487]
===
match
---
param [11591,11600]
param [11605,11614]
===
match
---
atom_expr [13653,13670]
atom_expr [13667,13684]
===
match
---
name: os [824,826]
name: os [824,826]
===
match
---
name: execute_command [5224,5239]
name: execute_command [5238,5253]
===
match
---
name: queued_dttm [14854,14865]
name: queued_dttm [14868,14879]
===
match
---
name: ti [8913,8915]
name: ti [8927,8929]
===
match
---
trailer [14611,14662]
trailer [14625,14676]
===
match
---
name: TaskInstanceKey [15576,15591]
name: TaskInstanceKey [15590,15605]
===
match
---
operator: = [14132,14133]
operator: = [14146,14147]
===
match
---
string: "PENDING" [18148,18157]
string: "PENDING" [18162,18171]
===
match
---
operator: = [13964,13965]
operator: = [13978,13979]
===
match
---
operator: = [19413,19414]
operator: = [19427,19428]
===
match
---
not_test [16880,16902]
not_test [16894,16916]
===
match
---
trailer [14339,14341]
trailer [14353,14355]
===
match
---
atom_expr [2684,2706]
atom_expr [2698,2720]
===
match
---
name: executor [5946,5954]
name: executor [5960,5968]
===
match
---
with_stmt [17413,17865]
with_stmt [17427,17879]
===
match
---
expr_stmt [2789,2882]
expr_stmt [2803,2896]
===
match
---
argument [19114,19181]
argument [19128,19195]
===
match
---
simple_stmt [19006,19201]
simple_stmt [19020,19215]
===
match
---
operator: == [6299,6301]
operator: == [6313,6315]
===
match
---
name: timezone [13531,13539]
name: timezone [13545,13553]
===
match
---
trailer [16684,16699]
trailer [16698,16713]
===
match
---
trailer [10896,10917]
trailer [10910,10931]
===
match
---
operator: } [19539,19540]
operator: } [19553,19554]
===
match
---
parameters [17276,17293]
parameters [17290,17307]
===
match
---
operator: = [19913,19914]
operator: = [19927,19928]
===
match
---
param [11571,11590]
param [11585,11604]
===
match
---
trailer [13601,13608]
trailer [13615,13622]
===
match
---
trailer [16120,16127]
trailer [16134,16141]
===
match
---
operator: , [1483,1484]
operator: , [1497,1498]
===
match
---
operator: = [15215,15216]
operator: = [15229,15230]
===
match
---
operator: = [15251,15252]
operator: = [15265,15266]
===
match
---
expr_stmt [13703,13717]
expr_stmt [13717,13731]
===
match
---
trailer [12488,12495]
trailer [12502,12509]
===
match
---
name: exec_date [13988,13997]
name: exec_date [14002,14011]
===
match
---
name: executor [16081,16089]
name: executor [16095,16103]
===
match
---
name: key [7585,7588]
name: key [7599,7602]
===
match
---
simple_stmt [19549,19685]
simple_stmt [19563,19699]
===
match
---
name: call [11775,11779]
name: call [11789,11793]
===
match
---
expr_stmt [13869,13931]
expr_stmt [13883,13945]
===
match
---
atom [16106,16164]
atom [16120,16178]
===
match
---
funcdef [3938,6620]
funcdef [3952,6634]
===
match
---
operator: = [14090,14091]
operator: = [14104,14105]
===
match
---
trailer [2053,2061]
trailer [2067,2075]
===
match
---
testlist_comp [18148,18163]
testlist_comp [18162,18177]
===
match
---
string: "postgres" [6734,6744]
string: "postgres" [6748,6758]
===
match
---
name: mock_session [18906,18918]
name: mock_session [18920,18932]
===
match
---
operator: , [7345,7346]
operator: , [7359,7360]
===
match
---
name: execution_date [14118,14132]
name: execution_date [14132,14146]
===
match
---
string: 'id' [8701,8705]
string: 'id' [8715,8719]
===
match
---
name: backends [1176,1184]
name: backends [1190,1198]
===
match
---
assert_stmt [6518,6552]
assert_stmt [6532,6566]
===
match
---
atom [18147,18164]
atom [18161,18178]
===
match
---
name: executor [8525,8533]
name: executor [8539,8547]
===
match
---
name: BashOperator [1826,1838]
name: BashOperator [1840,1852]
===
match
---
name: output [9590,9596]
name: output [9604,9610]
===
match
---
string: 'airflow.executors.celery_executor.CeleryExecutor.sync' [11309,11364]
string: 'airflow.executors.celery_executor.CeleryExecutor.sync' [11323,11378]
===
match
---
trailer [19018,19024]
trailer [19032,19038]
===
match
---
simple_stmt [14439,14496]
simple_stmt [14453,14510]
===
match
---
atom_expr [8142,8156]
atom_expr [8156,8170]
===
match
---
atom [17052,17105]
atom [17066,17119]
===
match
---
decorator [7906,7943]
decorator [7920,7957]
===
match
---
name: len [9736,9739]
name: len [9750,9753]
===
match
---
suite [16864,16903]
suite [16878,16917]
===
match
---
arglist [7968,7987]
arglist [7982,8001]
===
match
---
import_from [1272,1309]
import_from [1286,1323]
===
match
---
atom_expr [16548,16562]
atom_expr [16562,16576]
===
match
---
name: mock [11298,11302]
name: mock [11312,11316]
===
match
---
trailer [7571,7584]
trailer [7585,7598]
===
match
---
name: ClassWithCustomAttributes [16644,16669]
name: ClassWithCustomAttributes [16658,16683]
===
match
---
atom_expr [12237,12329]
atom_expr [12251,12343]
===
match
---
testlist_comp [12888,12896]
testlist_comp [12902,12910]
===
match
---
simple_stmt [10466,10487]
simple_stmt [10480,10501]
===
match
---
name: airflow [1402,1409]
name: airflow [1416,1423]
===
match
---
name: level [17570,17575]
name: level [17584,17589]
===
match
---
name: mark [7914,7918]
name: mark [7928,7932]
===
match
---
atom [4632,4939]
atom [4646,4953]
===
match
---
name: datetime [13012,13020]
name: datetime [13026,13034]
===
match
---
comparison [16081,16164]
comparison [16095,16178]
===
match
---
name: patch_execute [2789,2802]
name: patch_execute [2803,2816]
===
match
---
name: timedelta [885,894]
name: timedelta [899,908]
===
match
---
name: ClassWithCustomAttributes [16350,16375]
name: ClassWithCustomAttributes [16364,16389]
===
match
---
trailer [18772,18783]
trailer [18786,18797]
===
match
---
comparison [6226,6315]
comparison [6240,6329]
===
match
---
trailer [19103,19113]
trailer [19117,19127]
===
match
---
arglist [14612,14661]
arglist [14626,14675]
===
match
---
simple_stmt [15204,15255]
simple_stmt [15218,15269]
===
match
---
trailer [14741,14763]
trailer [14755,14777]
===
match
---
name: DatabaseBackend [18626,18641]
name: DatabaseBackend [18640,18655]
===
match
---
operator: , [14566,14567]
operator: , [14580,14581]
===
match
---
name: executor [16180,16188]
name: executor [16194,16202]
===
match
---
atom_expr [10655,10716]
atom_expr [10669,10730]
===
match
---
arith_expr [15841,15885]
arith_expr [15855,15899]
===
match
---
name: __str__ [16611,16618]
name: __str__ [16625,16632]
===
match
---
atom_expr [4495,4505]
atom_expr [4509,4519]
===
match
---
dictorsetmaker [17985,18033]
dictorsetmaker [17999,18047]
===
match
---
name: task [13960,13964]
name: task [13974,13978]
===
match
---
name: mock_stats_gauge [11553,11569]
name: mock_stats_gauge [11567,11583]
===
match
---
operator: { [9838,9839]
operator: { [9852,9853]
===
match
---
name: bash_command [7175,7187]
name: bash_command [7189,7201]
===
match
---
name: task [2693,2697]
name: task [2707,2711]
===
match
---
assert_stmt [10145,10214]
assert_stmt [10159,10228]
===
match
---
name: CeleryExecutor [4361,4375]
name: CeleryExecutor [4375,4389]
===
match
---
name: dag_id [15596,15602]
name: dag_id [15610,15616]
===
match
---
name: self [15127,15131]
name: self [15141,15145]
===
match
---
name: integration [18402,18413]
name: integration [18416,18427]
===
match
---
name: queued_dttm [15841,15852]
name: queued_dttm [15855,15866]
===
match
---
operator: == [7705,7707]
operator: == [7719,7721]
===
match
---
atom_expr [9319,9340]
atom_expr [9333,9354]
===
match
---
name: mock_fork [12863,12872]
name: mock_fork [12877,12886]
===
match
---
simple_stmt [10648,10733]
simple_stmt [10662,10747]
===
match
---
operator: , [14116,14117]
operator: , [14130,14131]
===
match
---
atom_expr [19006,19074]
atom_expr [19020,19088]
===
match
---
name: executor [9813,9821]
name: executor [9827,9835]
===
match
---
string: "SUCCESS" [17075,17084]
string: "SUCCESS" [17089,17098]
===
match
---
simple_stmt [12537,12578]
simple_stmt [12551,12592]
===
match
---
simple_stmt [3712,3731]
simple_stmt [3726,3745]
===
match
---
name: executor [10161,10169]
name: executor [10175,10183]
===
match
---
assert_stmt [6426,6464]
assert_stmt [6440,6478]
===
match
---
atom_expr [18768,18882]
atom_expr [18782,18896]
===
match
---
assert_stmt [11144,11229]
assert_stmt [11158,11243]
===
match
---
string: "status" [17065,17073]
string: "status" [17079,17087]
===
match
---
dictorsetmaker [15834,15951]
dictorsetmaker [15848,15965]
===
match
---
argument [7196,7216]
argument [7210,7230]
===
match
---
fstring_start: f" [9951,9953]
fstring_start: f" [9965,9967]
===
match
---
atom_expr [11864,11872]
atom_expr [11878,11886]
===
match
---
operator: , [4037,4038]
operator: , [4051,4052]
===
match
---
name: patch [18708,18713]
name: patch [18722,18727]
===
match
---
name: SUCCESS [6308,6315]
name: SUCCESS [6322,6329]
===
match
---
string: "redis" [19715,19722]
string: "redis" [19729,19736]
===
match
---
name: integration [6676,6687]
name: integration [6690,6701]
===
match
---
operator: @ [13424,13425]
operator: @ [13438,13439]
===
match
---
atom_expr [2510,2552]
atom_expr [2524,2566]
===
match
---
name: now [7474,7477]
name: now [7488,7491]
===
match
---
string: "232" [14990,14995]
string: "232" [15004,15009]
===
match
---
operator: } [16199,16200]
operator: } [16213,16214]
===
match
---
dictorsetmaker [18114,18164]
dictorsetmaker [18128,18178]
===
match
---
name: queued_tasks [7572,7584]
name: queued_tasks [7586,7598]
===
match
---
operator: , [17768,17769]
operator: , [17782,17783]
===
match
---
operator: == [6547,6549]
operator: == [6561,6563]
===
match
---
atom_expr [17483,17597]
atom_expr [17497,17611]
===
match
---
simple_stmt [18043,18087]
simple_stmt [18057,18101]
===
match
---
number: 0 [9038,9039]
number: 0 [9052,9053]
===
match
---
expr_stmt [19900,19951]
expr_stmt [19914,19965]
===
match
---
testlist_star_expr [17913,17925]
testlist_star_expr [17927,17939]
===
match
---
atom_expr [14803,14833]
atom_expr [14817,14847]
===
match
---
name: task_tuples_to_send [4588,4607]
name: task_tuples_to_send [4602,4621]
===
match
---
name: SimpleTaskInstance [7404,7422]
name: SimpleTaskInstance [7418,7436]
===
match
---
dotted_name [1277,1290]
dotted_name [1291,1304]
===
match
---
number: 600 [6581,6584]
number: 600 [6595,6598]
===
match
---
name: DAG [13103,13106]
name: DAG [13117,13120]
===
match
---
name: State [6302,6307]
name: State [6316,6321]
===
match
---
return_stmt [2025,2095]
return_stmt [2039,2109]
===
match
---
operator: == [9279,9281]
operator: == [9293,9295]
===
match
---
operator: , [10183,10184]
operator: , [10197,10198]
===
match
---
trailer [7685,7687]
trailer [7699,7701]
===
match
---
dotted_name [17156,17179]
dotted_name [17170,17193]
===
match
---
operator: } [16678,16679]
operator: } [16692,16693]
===
match
---
trailer [8928,8970]
trailer [8942,8984]
===
match
---
operator: = [20226,20227]
operator: = [20240,20241]
===
match
---
name: AsyncResult [1298,1309]
name: AsyncResult [1312,1323]
===
match
---
name: len [10157,10160]
name: len [10171,10174]
===
match
---
name: set [14336,14339]
name: set [14350,14353]
===
match
---
operator: } [9710,9711]
operator: } [9724,9725]
===
match
---
atom [19116,19181]
atom [19130,19195]
===
match
---
operator: , [4994,4995]
operator: , [5008,5009]
===
match
---
operator: , [12112,12113]
operator: , [12126,12127]
===
match
---
trailer [18707,18713]
trailer [18721,18727]
===
match
---
operator: - [13069,13070]
operator: - [13083,13084]
===
match
---
arglist [15675,15724]
arglist [15689,15738]
===
match
---
string: 'true' [11973,11979]
string: 'true' [11987,11993]
===
match
---
trailer [11681,11683]
trailer [11695,11697]
===
match
---
simple_stmt [9385,9420]
simple_stmt [9399,9434]
===
match
---
operator: } [11036,11037]
operator: } [11050,11051]
===
match
---
dictorsetmaker [19489,19539]
dictorsetmaker [19503,19553]
===
match
---
trailer [4375,4377]
trailer [4389,4391]
===
match
---
dotted_name [6705,6724]
dotted_name [6719,6738]
===
match
---
name: integration [3864,3875]
name: integration [3878,3889]
===
match
---
simple_stmt [10274,10453]
simple_stmt [10288,10467]
===
match
---
name: celery_executor [16303,16318]
name: celery_executor [16317,16332]
===
match
---
operator: = [13277,13278]
operator: = [13291,13292]
===
match
---
trailer [6295,6298]
trailer [6309,6312]
===
match
---
name: sync [16059,16063]
name: sync [16073,16077]
===
match
---
trailer [11058,11077]
trailer [11072,11091]
===
match
---
name: self [10844,10848]
name: self [10858,10862]
===
match
---
name: celery_executor [14268,14283]
name: celery_executor [14282,14297]
===
match
---
trailer [18783,18882]
trailer [18797,18896]
===
match
---
funcdef [16607,16703]
funcdef [16621,16717]
===
match
---
name: key [9075,9078]
name: key [9089,9092]
===
match
---
atom_expr [14409,14423]
atom_expr [14423,14437]
===
match
---
trailer [11809,11813]
trailer [11823,11827]
===
match
---
simple_stmt [16296,16342]
simple_stmt [16310,16356]
===
match
---
trailer [12357,12411]
trailer [12371,12425]
===
match
---
trailer [13339,13354]
trailer [13353,13368]
===
match
---
assert_stmt [10648,10732]
assert_stmt [10662,10746]
===
match
---
operator: , [8338,8339]
operator: , [8352,8353]
===
match
---
operator: == [12883,12885]
operator: == [12897,12899]
===
match
---
comparison [6076,6161]
comparison [6090,6175]
===
match
---
name: len [9315,9318]
name: len [9329,9332]
===
match
---
name: mock_backend [17468,17480]
name: mock_backend [17482,17494]
===
match
---
fstring_start: f" [10372,10374]
fstring_start: f" [10386,10388]
===
match
---
expr_stmt [13519,13571]
expr_stmt [13533,13585]
===
match
---
trailer [10053,10063]
trailer [10067,10077]
===
match
---
operator: , [11569,11570]
operator: , [11583,11584]
===
match
---
simple_stmt [13005,13030]
simple_stmt [13019,13044]
===
match
---
with_stmt [18698,19462]
with_stmt [18712,19476]
===
match
---
testlist_comp [12847,12858]
testlist_comp [12861,12872]
===
match
---
name: airflow [1879,1886]
name: airflow [1893,1900]
===
match
---
name: ti1 [14239,14242]
name: ti1 [14253,14256]
===
match
---
name: task_1 [14541,14547]
name: task_1 [14555,14561]
===
match
---
name: task_publish_retries [7625,7645]
name: task_publish_retries [7639,7659]
===
match
---
name: pytest [3893,3899]
name: pytest [3907,3913]
===
match
---
string: 'fake_simple_ti' [6260,6276]
string: 'fake_simple_ti' [6274,6290]
===
match
---
operator: , [17922,17923]
operator: , [17936,17937]
===
match
---
name: task_id [15694,15701]
name: task_id [15708,15715]
===
match
---
trailer [2692,2697]
trailer [2706,2711]
===
match
---
string: 'executor.open_slots' [11724,11745]
string: 'executor.open_slots' [11738,11759]
===
match
---
name: self [16685,16689]
name: self [16699,16703]
===
match
---
suite [19887,20474]
suite [19901,20488]
===
match
---
name: mock_backend [18611,18623]
name: mock_backend [18625,18637]
===
match
---
string: "postgres" [17226,17236]
string: "postgres" [17240,17250]
===
match
---
name: executor [10937,10945]
name: executor [10951,10959]
===
match
---
operator: @ [7947,7948]
operator: @ [7961,7962]
===
match
---
simple_stmt [3334,3350]
simple_stmt [3348,3364]
===
match
---
string: 'BROKER_URL' [2128,2140]
string: 'BROKER_URL' [2142,2154]
===
match
---
operator: , [14638,14639]
operator: , [14652,14653]
===
match
---
trailer [17937,17947]
trailer [17951,17961]
===
match
---
comparison [7785,7862]
comparison [7799,7876]
===
match
---
operator: , [13196,13197]
operator: , [13210,13211]
===
match
---
name: ti2 [14244,14247]
name: ti2 [14258,14261]
===
match
---
simple_stmt [12643,12673]
simple_stmt [12657,12687]
===
match
---
string: """Class for testing purpose: allows to create objects with custom attributes in one single statement.""" [16381,16486]
string: """Class for testing purpose: allows to create objects with custom attributes in one single statement.""" [16395,16500]
===
match
---
name: pytest [18390,18396]
name: pytest [18404,18410]
===
match
---
atom [13298,13304]
atom [13312,13318]
===
match
---
operator: = [7425,7426]
operator: = [7439,7440]
===
match
---
name: dag [7196,7199]
name: dag [7210,7213]
===
match
---
name: key_1 [16107,16112]
name: key_1 [16121,16126]
===
match
---
name: command [5421,5428]
name: command [5435,5442]
===
match
---
simple_stmt [17621,17650]
simple_stmt [17635,17664]
===
match
---
operator: , [4859,4860]
operator: , [4873,4874]
===
match
---
name: mock [2805,2809]
name: mock [2819,2823]
===
match
---
decorators [16956,17238]
decorators [16970,17252]
===
match
---
arglist [4478,4522]
arglist [4492,4536]
===
match
---
name: execute [2343,2350]
name: execute [2357,2364]
===
match
---
argument [17809,17822]
argument [17823,17836]
===
match
---
operator: , [5559,5560]
operator: , [5573,5574]
===
match
---
name: set_event_loop [1341,1355]
name: set_event_loop [1355,1369]
===
match
---
atom [5838,5881]
atom [5852,5895]
===
match
---
assert_stmt [8518,8598]
assert_stmt [8532,8612]
===
match
---
atom_expr [3712,3730]
atom_expr [3726,3744]
===
match
---
name: AirflowException [1467,1483]
name: AirflowException [1481,1497]
===
match
---
atom [5404,5442]
atom [5418,5456]
===
match
---
simple_stmt [19471,19541]
simple_stmt [19485,19555]
===
match
---
operator: = [15744,15745]
operator: = [15758,15759]
===
match
---
name: AirflowException [4220,4236]
name: AirflowException [4234,4250]
===
match
---
atom_expr [10881,10917]
atom_expr [10895,10931]
===
match
---
arglist [13960,13997]
arglist [13974,14011]
===
match
---
string: "task_1" [15451,15459]
string: "task_1" [15465,15473]
===
match
---
name: output [11222,11228]
name: output [11236,11242]
===
match
---
simple_stmt [1397,1436]
simple_stmt [1411,1450]
===
match
---
number: 1 [8853,8854]
number: 1 [8867,8868]
===
match
---
suite [8036,10733]
suite [8050,10747]
===
match
---
simple_stmt [7563,7604]
simple_stmt [7577,7618]
===
match
---
name: task_tuples_to_send [5446,5465]
name: task_tuples_to_send [5460,5479]
===
match
---
string: "postgres" [10797,10807]
string: "postgres" [10811,10821]
===
match
---
operator: , [19506,19507]
operator: , [19520,19521]
===
match
---
argument [7218,7243]
argument [7232,7257]
===
match
---
name: ti1 [13941,13944]
name: ti1 [13955,13958]
===
match
---
name: expected_exception [12441,12459]
name: expected_exception [12455,12473]
===
match
---
expr_stmt [8999,9040]
expr_stmt [9013,9054]
===
match
---
name: start_worker [4465,4477]
name: start_worker [4479,4491]
===
match
---
operator: = [15818,15819]
operator: = [15832,15833]
===
match
---
atom_expr [10234,10255]
atom_expr [10248,10269]
===
match
---
atom_expr [17928,17947]
atom_expr [17942,17961]
===
match
---
arglist [20401,20431]
arglist [20415,20445]
===
match
---
name: environ [2054,2061]
name: environ [2068,2075]
===
match
---
name: tasks [16189,16194]
name: tasks [16203,16208]
===
match
---
name: DAG [13732,13735]
name: DAG [13746,13749]
===
match
---
operator: , [8563,8564]
operator: , [8577,8578]
===
match
---
simple_stmt [6219,6316]
simple_stmt [6233,6330]
===
match
---
trailer [6187,6191]
trailer [6201,6205]
===
match
---
simple_stmt [15328,15343]
simple_stmt [15342,15357]
===
match
---
operator: == [12843,12845]
operator: == [12857,12859]
===
match
---
operator: , [2341,2342]
operator: , [2355,2356]
===
match
---
atom_expr [9392,9413]
atom_expr [9406,9427]
===
match
---
number: 1 [9731,9732]
number: 1 [9745,9746]
===
match
---
name: result [19478,19484]
name: result [19492,19498]
===
match
---
name: integration [6638,6649]
name: integration [6652,6663]
===
match
---
name: result [17666,17672]
name: result [17680,17686]
===
match
---
name: assertLogs [20040,20050]
name: assertLogs [20054,20064]
===
match
---
simple_stmt [5512,5572]
simple_stmt [5526,5586]
===
match
---
trailer [15169,15171]
trailer [15183,15185]
===
match
---
operator: , [5030,5031]
operator: , [5044,5045]
===
match
---
name: app [17452,17455]
name: app [17466,17469]
===
match
---
simple_stmt [9303,9373]
simple_stmt [9317,9387]
===
match
---
with_stmt [4254,6210]
with_stmt [4268,6224]
===
match
---
trailer [11001,11007]
trailer [11015,11021]
===
match
---
operator: } [16251,16252]
operator: } [16265,16266]
===
match
---
atom_expr [11622,11654]
atom_expr [11636,11668]
===
match
---
simple_stmt [6561,6620]
simple_stmt [6575,6634]
===
match
---
name: _prepare_app [2313,2325]
name: _prepare_app [2327,2339]
===
match
---
name: mock [17418,17422]
name: mock [17432,17436]
===
match
---
string: "postgres" [7977,7987]
string: "postgres" [7991,8001]
===
match
---
simple_stmt [3625,3644]
simple_stmt [3639,3658]
===
match
---
atom_expr [10572,10598]
atom_expr [10586,10612]
===
match
---
name: session [3292,3299]
name: session [3306,3313]
===
match
---
decorated [11297,11934]
decorated [11311,11948]
===
match
---
import_from [1085,1155]
import_from [1099,1169]
===
match
---
simple_stmt [787,805]
simple_stmt [787,805]
===
match
---
parameters [13503,13509]
parameters [13517,13523]
===
match
---
trailer [9632,9642]
trailer [9646,9656]
===
match
---
name: celery_executor [11622,11637]
name: celery_executor [11636,11651]
===
match
---
atom [16114,16134]
atom [16128,16148]
===
match
---
name: fetcher [19218,19225]
name: fetcher [19232,19239]
===
match
---
name: mget_args [17913,17922]
name: mget_args [17927,17936]
===
match
---
name: State [1906,1911]
name: State [1920,1925]
===
match
---
string: "to_dict.return_value" [19117,19139]
string: "to_dict.return_value" [19131,19153]
===
match
---
arith_expr [15906,15950]
arith_expr [15920,15964]
===
match
---
operator: + [14866,14867]
operator: + [14880,14881]
===
match
---
dotted_name [3852,3875]
dotted_name [3866,3889]
===
match
---
suite [4524,6210]
suite [4538,6224]
===
match
---
simple_stmt [4334,4378]
simple_stmt [4348,4392]
===
match
---
atom_expr [13051,13068]
atom_expr [13065,13082]
===
match
---
trailer [2113,2117]
trailer [2127,2131]
===
match
---
operator: @ [3892,3893]
operator: @ [3906,3907]
===
match
---
fstring_start: f" [9530,9532]
fstring_start: f" [9544,9546]
===
match
---
name: mock [11371,11375]
name: mock [11385,11389]
===
match
---
comparison [16303,16341]
comparison [16317,16355]
===
match
---
atom_expr [6494,6508]
atom_expr [6508,6522]
===
match
---
suite [12460,12673]
suite [12474,12687]
===
match
---
suite [4154,4245]
suite [4168,4259]
===
match
---
name: _ [17924,17925]
name: _ [17938,17939]
===
match
---
testlist_comp [4659,4703]
testlist_comp [4673,4717]
===
match
---
name: mock_stats_gauge [11893,11909]
name: mock_stats_gauge [11907,11923]
===
match
---
name: execute_command [2463,2478]
name: execute_command [2477,2492]
===
match
---
trailer [2530,2551]
trailer [2544,2565]
===
match
---
operator: = [14209,14210]
operator: = [14223,14224]
===
match
---
simple_stmt [16576,16602]
simple_stmt [16590,16616]
===
match
---
name: timezone [15217,15225]
name: timezone [15231,15239]
===
match
---
name: mock [11453,11457]
name: mock [11467,11471]
===
match
---
operator: = [2682,2683]
operator: = [2696,2697]
===
match
---
operator: = [5627,5628]
operator: = [5641,5642]
===
match
---
arglist [2626,2663]
arglist [2640,2677]
===
match
---
name: start_date [15204,15214]
name: start_date [15218,15228]
===
match
---
name: result [20490,20496]
name: result [20504,20510]
===
match
---
decorator [7947,7989]
decorator [7961,8003]
===
match
---
string: "123" [19359,19364]
string: "123" [19373,19378]
===
match
---
simple_stmt [13794,13857]
simple_stmt [13808,13871]
===
match
---
operator: } [10131,10132]
operator: } [10145,10146]
===
match
---
operator: = [9003,9004]
operator: = [9017,9018]
===
match
---
atom_expr [15995,16013]
atom_expr [16009,16027]
===
match
---
comparison [17963,18034]
comparison [17977,18048]
===
match
---
string: "mysql" [13445,13452]
string: "mysql" [13459,13466]
===
match
---
simple_stmt [9853,10032]
simple_stmt [9867,10046]
===
match
---
name: patch [2810,2815]
name: patch [2824,2829]
===
match
---
parameters [2325,2356]
parameters [2339,2370]
===
match
---
operator: } [16699,16700]
operator: } [16713,16714]
===
match
---
name: executor [14357,14365]
name: executor [14371,14379]
===
match
---
trailer [18595,18597]
trailer [18609,18611]
===
match
---
name: celery_executor [17436,17451]
name: celery_executor [17450,17465]
===
match
---
testlist_comp [12034,12067]
testlist_comp [12048,12081]
===
match
---
string: "test_try_adopt_task_instances_none" [13107,13143]
string: "test_try_adopt_task_instances_none" [13121,13157]
===
match
---
name: test_should_support_db_backend [18518,18548]
name: test_should_support_db_backend [18532,18562]
===
match
---
string: "postgres" [13454,13464]
string: "postgres" [13468,13478]
===
match
---
trailer [10160,10183]
trailer [10174,10197]
===
match
---
name: executor [14678,14686]
name: executor [14692,14700]
===
match
---
operator: , [15629,15630]
operator: , [15643,15644]
===
match
---
fstring_end: " [10003,10004]
fstring_end: " [10017,10018]
===
match
---
operator: @ [6625,6626]
operator: @ [6639,6640]
===
match
---
atom_expr [18646,18665]
atom_expr [18660,18679]
===
match
---
trailer [5736,5741]
trailer [5750,5755]
===
match
---
testlist_comp [18122,18137]
testlist_comp [18136,18151]
===
match
---
trailer [16583,16601]
trailer [16597,16615]
===
match
---
comparison [9243,9290]
comparison [9257,9304]
===
match
---
name: key_1 [14699,14704]
name: key_1 [14713,14718]
===
match
---
trailer [2061,2083]
trailer [2075,2097]
===
match
---
operator: = [13010,13011]
operator: = [13024,13025]
===
match
---
name: SimpleTaskInstance [8894,8912]
name: SimpleTaskInstance [8908,8926]
===
match
---
simple_stmt [16209,16253]
simple_stmt [16223,16267]
===
match
---
arglist [13816,13855]
arglist [13830,13869]
===
match
---
with_item [12347,12424]
with_item [12361,12438]
===
match
---
trailer [13815,13856]
trailer [13829,13870]
===
match
---
atom_expr [12707,12747]
atom_expr [12721,12761]
===
match
---
assert_stmt [16074,16164]
assert_stmt [16088,16178]
===
match
---
name: pytest [6626,6632]
name: pytest [6640,6646]
===
match
---
dotted_name [13425,13444]
dotted_name [13439,13458]
===
match
---
name: patch_execute [3371,3384]
name: patch_execute [3385,3398]
===
match
---
name: queued_tasks [10585,10597]
name: queued_tasks [10599,10611]
===
match
---
operator: = [2434,2435]
operator: = [2448,2449]
===
match
---
comparison [8470,8505]
comparison [8484,8519]
===
match
---
name: conf [1431,1435]
name: conf [1445,1449]
===
match
---
name: ClassWithCustomAttributes [20375,20400]
name: ClassWithCustomAttributes [20389,20414]
===
match
---
param [16511,16519]
param [16525,16533]
===
match
---
name: days [15247,15251]
name: days [15261,15265]
===
match
---
arglist [2398,2420]
arglist [2412,2434]
===
match
---
name: mock_fork [12415,12424]
name: mock_fork [12429,12438]
===
match
---
trailer [11718,11723]
trailer [11732,11737]
===
match
---
string: 'tasks' [4023,4030]
string: 'tasks' [4037,4044]
===
match
---
arglist [7159,7243]
arglist [7173,7257]
===
match
---
operator: == [6019,6021]
operator: == [6033,6035]
===
match
---
param [2326,2342]
param [2340,2356]
===
match
---
name: app [4482,4485]
name: app [4496,4499]
===
match
---
simple_stmt [6473,6509]
simple_stmt [6487,6523]
===
match
---
suite [10850,11292]
suite [10864,11306]
===
match
---
name: mark [17163,17167]
name: mark [17177,17181]
===
match
---
simple_stmt [6833,6838]
simple_stmt [6847,6852]
===
match
---
name: len [10572,10575]
name: len [10586,10589]
===
match
---
trailer [14104,14143]
trailer [14118,14157]
===
match
---
operator: = [10946,10947]
operator: = [10960,10961]
===
match
---
name: calls [11692,11697]
name: calls [11706,11711]
===
match
---
name: dict [14728,14732]
name: dict [14742,14746]
===
match
---
name: execute_date [5865,5877]
name: execute_date [5879,5891]
===
match
---
operator: , [6360,6361]
operator: , [6374,6375]
===
match
---
name: patch [12242,12247]
name: patch [12256,12261]
===
match
---
simple_stmt [2100,2144]
simple_stmt [2114,2158]
===
match
---
name: now [7286,7289]
name: now [7300,7303]
===
match
---
string: 'airflow.executors.celery_executor.execute_command' [2816,2867]
string: 'airflow.executors.celery_executor.execute_command' [2830,2881]
===
match
---
name: task_id [20318,20325]
name: task_id [20332,20339]
===
match
---
string: "456" [20409,20414]
string: "456" [20423,20428]
===
match
---
name: now [7238,7241]
name: now [7252,7255]
===
match
---
string: 'SUCCESS' [18122,18131]
string: 'SUCCESS' [18136,18145]
===
match
---
name: broker_url [2626,2636]
name: broker_url [2640,2650]
===
match
---
expr_stmt [18611,18684]
expr_stmt [18625,18698]
===
match
---
import_from [1839,1873]
import_from [1853,1887]
===
match
---
trailer [2697,2706]
trailer [2711,2720]
===
match
---
operator: , [12895,12896]
operator: , [12909,12910]
===
match
---
string: "mysql" [6725,6732]
string: "mysql" [6739,6746]
===
match
---
operator: = [6203,6204]
operator: = [6217,6218]
===
match
---
name: task_id [14631,14638]
name: task_id [14645,14652]
===
match
---
name: State [16144,16149]
name: State [16158,16163]
===
match
---
operator: , [14833,14834]
operator: , [14847,14848]
===
match
---
dotted_name [7869,7892]
dotted_name [7883,7906]
===
match
---
name: self [16743,16747]
name: self [16757,16761]
===
match
---
operator: == [5745,5747]
operator: == [5759,5761]
===
match
---
comp_op [6443,6449]
comp_op [6457,6463]
===
match
---
name: key_2 [15899,15904]
name: key_2 [15913,15918]
===
match
---
operator: { [16250,16251]
operator: { [16264,16265]
===
match
---
dotted_name [19729,19752]
dotted_name [19743,19766]
===
match
---
operator: = [17816,17817]
operator: = [17830,17831]
===
match
---
string: "celery.backends.database.DatabaseBackend.ResultSession" [18327,18383]
string: "celery.backends.database.DatabaseBackend.ResultSession" [18341,18397]
===
match
---
trailer [15232,15234]
trailer [15246,15248]
===
match
---
operator: = [18670,18671]
operator: = [18684,18685]
===
match
---
operator: , [13971,13972]
operator: , [13985,13986]
===
match
---
operator: , [5816,5817]
operator: , [5830,5831]
===
match
---
arglist [13891,13930]
arglist [13905,13944]
===
match
---
operator: , [5863,5864]
operator: , [5877,5878]
===
match
---
dictorsetmaker [14782,14899]
dictorsetmaker [14796,14913]
===
match
---
argument [15184,15194]
argument [15198,15208]
===
match
---
string: "task_id" [17086,17095]
string: "task_id" [17100,17109]
===
match
---
name: key1 [13230,13234]
name: key1 [13244,13248]
===
match
---
atom_expr [11219,11228]
atom_expr [11233,11242]
===
match
---
param [16780,16785]
param [16794,16799]
===
match
---
arglist [17217,17236]
arglist [17231,17250]
===
match
---
operator: @ [3813,3814]
operator: @ [3827,3828]
===
match
---
name: self [2198,2202]
name: self [2212,2216]
===
match
---
trailer [4438,4444]
trailer [4452,4458]
===
match
---
name: MagicMock [19396,19405]
name: MagicMock [19410,19419]
===
match
---
operator: + [14801,14802]
operator: + [14815,14816]
===
match
---
atom [7515,7550]
atom [7529,7564]
===
match
---
operator: == [8559,8561]
operator: == [8573,8575]
===
match
---
argument [20318,20331]
argument [20332,20345]
===
match
---
trailer [18076,18086]
trailer [18090,18100]
===
match
---
atom_expr [3785,3807]
atom_expr [3799,3821]
===
match
---
name: other [16820,16825]
name: other [16834,16839]
===
match
---
name: json [17053,17057]
name: json [17067,17071]
===
match
---
operator: = [2508,2509]
operator: = [2522,2523]
===
match
---
testlist_comp [20292,20433]
testlist_comp [20306,20447]
===
match
---
name: TaskInstance [14092,14104]
name: TaskInstance [14106,14118]
===
match
---
name: backend [17209,17216]
name: backend [17223,17230]
===
match
---
name: pytest [18428,18434]
name: pytest [18442,18448]
===
match
---
arglist [20318,20348]
arglist [20332,20362]
===
match
---
operator: = [4086,4087]
operator: = [4100,4101]
===
match
---
name: fetcher [20173,20180]
name: fetcher [20187,20194]
===
match
---
name: mock [11714,11718]
name: mock [11728,11732]
===
match
---
operator: == [15029,15031]
operator: == [15043,15045]
===
match
---
name: executor [10655,10663]
name: executor [10669,10677]
===
match
---
name: backend [2888,2895]
name: backend [2902,2909]
===
match
---
simple_stmt [14257,14301]
simple_stmt [14271,14315]
===
match
---
decorator [10738,10763]
decorator [10752,10777]
===
match
---
testlist_comp [11972,11992]
testlist_comp [11986,12006]
===
match
---
name: result [1284,1290]
name: result [1298,1304]
===
match
---
operator: , [6258,6259]
operator: , [6272,6273]
===
match
---
atom_expr [10576,10597]
atom_expr [10590,10611]
===
match
---
operator: = [13529,13530]
operator: = [13543,13544]
===
match
---
trailer [15162,15169]
trailer [15176,15183]
===
match
---
decorators [18315,18510]
decorators [18329,18524]
===
match
---
name: datetime [7277,7285]
name: datetime [7291,7299]
===
match
---
argument [7159,7173]
argument [7173,7187]
===
match
---
name: QUEUED [6155,6161]
name: QUEUED [6169,6175]
===
match
---
trailer [7107,7109]
trailer [7121,7123]
===
match
---
name: object [19981,19987]
name: object [19995,20001]
===
match
---
name: state [2192,2197]
name: state [2206,2211]
===
match
---
atom [11970,12069]
atom [11984,12083]
===
match
---
operator: { [15820,15821]
operator: { [15834,15835]
===
match
---
trailer [11837,11873]
trailer [11851,11887]
===
match
---
string: "Task should no longer be in queue" [10600,10635]
string: "Task should no longer be in queue" [10614,10649]
===
match
---
atom_expr [14596,14662]
atom_expr [14610,14676]
===
match
---
string: 'key' [11011,11016]
string: 'key' [11025,11030]
===
match
---
name: hasattr [2923,2930]
name: hasattr [2937,2944]
===
match
---
name: test_command_validation [12084,12107]
name: test_command_validation [12098,12121]
===
match
---
name: queued_tasks [9062,9074]
name: queued_tasks [9076,9088]
===
match
---
name: utcnow [15226,15232]
name: utcnow [15240,15246]
===
match
---
name: execution_date [13973,13987]
name: execution_date [13987,14001]
===
match
---
name: queued_dttm [14066,14077]
name: queued_dttm [14080,14091]
===
match
---
operator: , [14704,14705]
operator: , [14718,14719]
===
match
---
atom_expr [13103,13144]
atom_expr [13117,13158]
===
match
---
name: datetime [875,883]
name: datetime [889,897]
===
match
---
dotted_name [1509,1526]
dotted_name [1523,1540]
===
match
---
expr_stmt [20219,20473]
expr_stmt [20233,20487]
===
match
---
operator: , [15534,15535]
operator: , [15548,15549]
===
match
---
arglist [8649,8733]
arglist [8663,8747]
===
match
---
name: sys [834,837]
name: sys [848,851]
===
match
---
trailer [11221,11228]
trailer [11235,11242]
===
match
---
number: 1 [13691,13692]
number: 1 [13705,13706]
===
match
---
trailer [17375,17400]
trailer [17389,17414]
===
match
---
name: testing [987,994]
name: testing [1001,1008]
===
match
---
name: not_adopted_tis [15013,15028]
name: not_adopted_tis [15027,15042]
===
match
---
trailer [15591,15642]
trailer [15605,15656]
===
match
---
atom_expr [16803,16816]
atom_expr [16817,16830]
===
match
---
import_name [827,837]
import_name [841,851]
===
match
---
atom_expr [15174,15195]
atom_expr [15188,15209]
===
match
---
assert_stmt [14309,14341]
assert_stmt [14323,14355]
===
match
---
name: task_id [14548,14555]
name: task_id [14562,14569]
===
match
---
name: State [10720,10725]
name: State [10734,10739]
===
match
---
trailer [9668,9699]
trailer [9682,9713]
===
match
---
trailer [3728,3730]
trailer [3742,3744]
===
match
---
trailer [19057,19061]
trailer [19071,19075]
===
match
---
suite [12425,12900]
suite [12439,12914]
===
match
---
operator: = [7513,7514]
operator: = [7527,7528]
===
match
---
simple_stmt [4390,4418]
simple_stmt [4404,4432]
===
match
---
name: command [12569,12576]
name: command [12583,12590]
===
match
---
name: start_date [15547,15557]
name: start_date [15561,15571]
===
match
---
atom_expr [16576,16601]
atom_expr [16590,16615]
===
match
---
operator: , [18766,18767]
operator: , [18780,18781]
===
match
---
atom_expr [8525,8558]
atom_expr [8539,8572]
===
match
---
operator: == [9733,9735]
operator: == [9747,9749]
===
match
---
name: self [19852,19856]
name: self [19866,19870]
===
match
---
expr_stmt [3292,3325]
expr_stmt [3306,3339]
===
match
---
funcdef [17242,18310]
funcdef [17256,18324]
===
match
---
string: 'fail' [7808,7814]
string: 'fail' [7822,7828]
===
match
---
atom_expr [15576,15642]
atom_expr [15590,15656]
===
match
---
simple_stmt [1085,1164]
simple_stmt [1099,1178]
===
match
---
operator: , [4282,4283]
operator: , [4296,4297]
===
match
---
string: 'airflow.executors.celery_executor._execute_in_fork' [12358,12410]
string: 'airflow.executors.celery_executor._execute_in_fork' [12372,12424]
===
match
---
dictorsetmaker [17065,17102]
dictorsetmaker [17079,17116]
===
match
---
name: url [2034,2037]
name: url [2048,2051]
===
match
---
name: BaseBackend [19939,19950]
name: BaseBackend [19953,19964]
===
match
---
string: 'success' [5771,5780]
string: 'success' [5785,5794]
===
match
---
simple_stmt [17913,17948]
simple_stmt [17927,17962]
===
match
---
expr_stmt [17666,17864]
expr_stmt [17680,17878]
===
match
---
operator: , [18740,18741]
operator: , [18754,18755]
===
match
---
name: task_publish_retries [10520,10540]
name: task_publish_retries [10534,10554]
===
match
---
testlist_comp [11971,12068]
testlist_comp [11985,12082]
===
match
---
operator: , [5435,5436]
operator: , [5449,5450]
===
match
---
operator: { [14943,14944]
operator: { [14957,14958]
===
match
---
name: call_args [12833,12842]
name: call_args [12847,12856]
===
match
---
name: ValueError [11982,11992]
name: ValueError [11996,12006]
===
match
---
atom_expr [3520,3540]
atom_expr [3534,3554]
===
match
---
import_from [1666,1700]
import_from [1680,1714]
===
match
---
trailer [5954,5967]
trailer [5968,5981]
===
match
---
operator: = [2617,2618]
operator: = [2631,2632]
===
match
---
exprlist [16534,16544]
exprlist [16548,16558]
===
match
---
operator: , [5881,5882]
operator: , [5895,5896]
===
match
---
trailer [10885,10896]
trailer [10899,10910]
===
match
---
argument [15443,15459]
argument [15457,15473]
===
match
---
atom_expr [19336,19365]
atom_expr [19350,19379]
===
match
---
suite [6820,6838]
suite [6834,6852]
===
match
---
name: TaskInstance [7426,7438]
name: TaskInstance [7440,7452]
===
match
---
trailer [13546,13548]
trailer [13560,13562]
===
match
---
operator: , [18853,18854]
operator: , [18867,18868]
===
match
---
atom [9417,9419]
atom [9431,9433]
===
match
---
suite [6784,7863]
suite [6798,7877]
===
match
---
argument [7439,7448]
argument [7453,7462]
===
match
---
simple_stmt [16074,16165]
simple_stmt [16088,16179]
===
match
---
trailer [13179,13220]
trailer [13193,13234]
===
match
---
suite [16625,16703]
suite [16639,16717]
===
match
---
name: mark [18397,18401]
name: mark [18411,18415]
===
match
---
testlist_comp [7516,7549]
testlist_comp [7530,7563]
===
match
---
assert_stmt [14721,14909]
assert_stmt [14735,14923]
===
match
---
assert_stmt [7778,7862]
assert_stmt [7792,7876]
===
match
---
trailer [7289,7291]
trailer [7303,7305]
===
match
---
trailer [7711,7734]
trailer [7725,7748]
===
match
---
name: dict [9664,9668]
name: dict [9678,9682]
===
match
---
trailer [8219,8393]
trailer [8233,8407]
===
match
---
atom_expr [7129,7257]
atom_expr [7143,7271]
===
match
---
operator: , [15618,15619]
operator: , [15632,15633]
===
match
---
with_stmt [3355,3541]
with_stmt [3369,3555]
===
match
---
string: "123" [19174,19179]
string: "123" [19188,19193]
===
match
---
name: exec_date [13519,13528]
name: exec_date [13533,13542]
===
match
---
dotted_name [16957,16967]
dotted_name [16971,16981]
===
match
---
simple_stmt [15006,15035]
simple_stmt [15020,15049]
===
match
---
name: task_adoption_timeout [15864,15885]
name: task_adoption_timeout [15878,15899]
===
match
---
dotted_name [1222,1251]
dotted_name [1236,1265]
===
match
---
name: executor [7563,7571]
name: executor [7577,7585]
===
match
---
name: tis [14232,14235]
name: tis [14246,14249]
===
match
---
atom [11700,11884]
atom [11714,11898]
===
match
---
simple_stmt [2711,2785]
simple_stmt [2725,2799]
===
match
---
expr_stmt [13313,13356]
expr_stmt [13327,13370]
===
match
---
name: __init__ [16496,16504]
name: __init__ [16510,16518]
===
match
---
operator: , [5978,5979]
operator: , [5992,5993]
===
match
---
argument [8913,8970]
argument [8927,8984]
===
match
---
decorator [11370,11448]
decorator [11384,11462]
===
match
---
operator: == [14765,14767]
operator: == [14779,14781]
===
match
---
atom_expr [2723,2784]
atom_expr [2737,2798]
===
match
---
trailer [13106,13144]
trailer [13120,13158]
===
match
---
operator: , [7386,7387]
operator: , [7400,7401]
===
match
---
assert_stmt [9657,9711]
assert_stmt [9671,9725]
===
match
---
name: celery_executor [10948,10963]
name: celery_executor [10962,10977]
===
match
---
expr_stmt [17621,17649]
expr_stmt [17635,17663]
===
match
---
assert_stmt [19471,19540]
assert_stmt [19485,19554]
===
match
---
name: queued_dttm [14789,14800]
name: queued_dttm [14803,14814]
===
match
---
simple_stmt [13313,13357]
simple_stmt [13327,13371]
===
match
---
name: backends [1097,1105]
name: backends [1111,1119]
===
match
---
with_stmt [19965,20474]
with_stmt [19979,20488]
===
match
---
trailer [19340,19350]
trailer [19354,19364]
===
match
---
if_stmt [2920,3350]
if_stmt [2934,3364]
===
match
---
operator: , [1773,1774]
operator: , [1787,1788]
===
match
---
name: cm [8198,8200]
name: cm [8212,8214]
===
match
---
trailer [17647,17649]
trailer [17661,17663]
===
match
---
string: "redis" [3838,3845]
string: "redis" [3852,3859]
===
match
---
name: task_adoption_timeout [6598,6619]
name: task_adoption_timeout [6612,6633]
===
match
---
trailer [14490,14495]
trailer [14504,14509]
===
match
---
name: now [8964,8967]
name: now [8978,8981]
===
match
---
decorated [7868,10733]
decorated [7882,10747]
===
match
---
expr_stmt [4334,4377]
expr_stmt [4348,4391]
===
match
---
name: executor [15787,15795]
name: executor [15801,15809]
===
match
---
operator: { [9575,9576]
operator: { [9589,9590]
===
match
---
name: datetime [8767,8775]
name: datetime [8781,8789]
===
match
---
with_item [13732,13780]
with_item [13746,13794]
===
match
---
atom_expr [7563,7589]
atom_expr [7577,7603]
===
match
---
name: task_adoption_timeout [14812,14833]
name: task_adoption_timeout [14826,14847]
===
match
---
atom_expr [7712,7733]
atom_expr [7726,7747]
===
match
---
name: task_id [15518,15525]
name: task_id [15532,15539]
===
match
---
decorator [19728,19765]
decorator [19742,19779]
===
match
---
operator: = [7210,7211]
operator: = [7224,7225]
===
match
---
simple_stmt [7778,7863]
simple_stmt [7792,7877]
===
match
---
param [12990,12994]
param [13004,13008]
===
match
---
operator: @ [17117,17118]
operator: @ [17131,17132]
===
match
---
name: value_tuple [7304,7315]
name: value_tuple [7318,7329]
===
match
---
operator: = [20421,20422]
operator: = [20435,20436]
===
match
---
testlist_comp [4632,5263]
testlist_comp [4646,5277]
===
match
---
name: executor [7785,7793]
name: executor [7799,7807]
===
match
---
number: 0 [4702,4703]
number: 0 [4716,4717]
===
match
---
name: key [8999,9002]
name: key [9013,9016]
===
match
---
trailer [13059,13066]
trailer [13073,13080]
===
match
---
operator: = [6872,6873]
operator: = [6886,6887]
===
match
---
trailer [8173,8194]
trailer [8187,8208]
===
match
---
name: backend [2931,2938]
name: backend [2945,2952]
===
match
---
argument [8708,8733]
argument [8722,8747]
===
match
---
name: expected_exception [12496,12514]
name: expected_exception [12510,12528]
===
match
---
trailer [3805,3807]
trailer [3819,3821]
===
match
---
string: 'airflow' [4012,4021]
string: 'airflow' [4026,4035]
===
match
---
operator: , [16013,16014]
operator: , [16027,16028]
===
match
---
name: celery_executor [2515,2530]
name: celery_executor [2529,2544]
===
match
---
operator: } [2601,2602]
operator: } [2615,2616]
===
match
---
operator: , [4734,4735]
operator: , [4748,4749]
===
match
---
trailer [4900,4916]
trailer [4914,4930]
===
match
---
name: executor [13313,13321]
name: executor [13327,13335]
===
match
---
name: CeleryExecutor [14284,14298]
name: CeleryExecutor [14298,14312]
===
match
---
argument [15461,15482]
argument [15475,15496]
===
match
---
funcdef [19815,20697]
funcdef [19829,20711]
===
match
---
simple_stmt [13703,13718]
simple_stmt [13717,13732]
===
match
---
simple_stmt [18906,18990]
simple_stmt [18920,19004]
===
match
---
name: mock_mget [17283,17292]
name: mock_mget [17297,17306]
===
match
---
assert_stmt [16296,16341]
assert_stmt [16310,16355]
===
match
---
operator: = [19938,19939]
operator: = [19952,19953]
===
match
---
name: tasks [5731,5736]
name: tasks [5745,5750]
===
match
---
name: datetime [859,867]
name: datetime [873,881]
===
match
---
arglist [11724,11755]
arglist [11738,11769]
===
match
---
name: executor [10511,10519]
name: executor [10525,10533]
===
match
---
name: self [11547,11551]
name: self [11561,11565]
===
match
---
trailer [10063,10065]
trailer [10077,10079]
===
match
---
operator: , [7481,7482]
operator: , [7495,7496]
===
match
---
name: BulkStateFetcher [1596,1612]
name: BulkStateFetcher [1610,1626]
===
match
---
trailer [3741,3755]
trailer [3755,3769]
===
match
---
name: executor [10045,10053]
name: executor [10059,10067]
===
match
---
operator: , [17281,17282]
operator: , [17295,17296]
===
match
---
expr_stmt [7509,7550]
expr_stmt [7523,7564]
===
match
---
operator: , [6123,6124]
operator: , [6137,6138]
===
match
---
trailer [14051,14063]
trailer [14065,14077]
===
match
---
trailer [4360,4375]
trailer [4374,4389]
===
match
---
operator: , [8876,8877]
operator: , [8890,8891]
===
match
---
name: pytest [19729,19735]
name: pytest [19743,19749]
===
match
---
operator: , [20525,20526]
operator: , [20539,20540]
===
match
---
atom_expr [14316,14332]
atom_expr [14330,14346]
===
match
---
name: cm [19675,19677]
name: cm [19689,19691]
===
match
---
string: "mysql" [10788,10795]
string: "mysql" [10802,10809]
===
match
---
trailer [6597,6619]
trailer [6611,6633]
===
match
---
name: key_1 [15988,15993]
name: key_1 [16002,16007]
===
match
---
trailer [11779,11814]
trailer [11793,11828]
===
match
---
trailer [15776,15778]
trailer [15790,15792]
===
match
---
operator: = [17051,17052]
operator: = [17065,17066]
===
match
---
argument [15518,15534]
argument [15532,15548]
===
match
---
trailer [6502,6508]
trailer [6516,6522]
===
match
---
string: "PENDING" [20422,20431]
string: "PENDING" [20436,20445]
===
match
---
name: return_value [19025,19037]
name: return_value [19039,19051]
===
match
---
name: success_command [4181,4196]
name: success_command [4195,4210]
===
match
---
argument [13973,13997]
argument [13987,14011]
===
match
---
operator: , [8706,8707]
operator: , [8720,8721]
===
match
---
atom_expr [13673,13693]
atom_expr [13687,13707]
===
match
---
operator: , [7540,7541]
operator: , [7554,7555]
===
match
---
expr_stmt [13230,13283]
expr_stmt [13244,13297]
===
match
---
operator: } [8504,8505]
operator: } [8518,8519]
===
match
---
operator: , [883,884]
operator: , [897,898]
===
match
---
name: call_args [17938,17947]
name: call_args [17952,17961]
===
match
---
name: executor [14803,14811]
name: executor [14817,14825]
===
match
---
name: app [18642,18645]
name: app [18656,18659]
===
match
---
name: setUp [3596,3601]
name: setUp [3610,3615]
===
match
---
name: integration [7881,7892]
name: integration [7895,7906]
===
match
---
name: app [4478,4481]
name: app [4492,4495]
===
match
---
name: clear_db_runs [3715,3728]
name: clear_db_runs [3729,3742]
===
match
---
operator: , [9030,9031]
operator: , [9044,9045]
===
match
---
name: celery_executor [18646,18661]
name: celery_executor [18660,18675]
===
match
---
atom_expr [14336,14341]
atom_expr [14350,14355]
===
match
---
suite [16521,16602]
suite [16535,16616]
===
match
---
name: executor [14316,14324]
name: executor [14330,14338]
===
match
---
trailer [19405,19420]
trailer [19419,19434]
===
match
---
operator: = [14511,14512]
operator: = [14525,14526]
===
match
---
parameters [3601,3607]
parameters [3615,3621]
===
match
---
trailer [10089,10120]
trailer [10103,10134]
===
match
---
atom_expr [9740,9761]
atom_expr [9754,9775]
===
match
---
name: patch [11376,11381]
name: patch [11390,11395]
===
match
---
trailer [12351,12357]
trailer [12365,12371]
===
match
---
trailer [6142,6145]
trailer [6156,6159]
===
match
---
name: _prepare_app [4259,4271]
name: _prepare_app [4273,4285]
===
match
---
operator: , [11589,11590]
operator: , [11603,11604]
===
match
---
name: tis [14491,14494]
name: tis [14505,14508]
===
match
---
atom_expr [19872,19886]
atom_expr [19886,19900]
===
match
---
name: task_id [13816,13823]
name: task_id [13830,13837]
===
match
---
name: event_buffer [6340,6352]
name: event_buffer [6354,6366]
===
match
---
name: tasks [15979,15984]
name: tasks [15993,15998]
===
match
---
name: app [18662,18665]
name: app [18676,18679]
===
match
---
atom [2032,2095]
atom [2046,2109]
===
match
---
trailer [14324,14332]
trailer [14338,14346]
===
match
---
trailer [14630,14638]
trailer [14644,14652]
===
match
---
string: "456" [17817,17822]
string: "456" [17831,17836]
===
match
---
name: pytest [17197,17203]
name: pytest [17211,17217]
===
match
---
name: exec_date [14557,14566]
name: exec_date [14571,14580]
===
match
---
funcdef [3676,3758]
funcdef [3690,3772]
===
match
---
return_stmt [16796,16834]
return_stmt [16810,16848]
===
match
---
trailer [4477,4523]
trailer [4491,4537]
===
match
---
operator: , [15068,15069]
operator: , [15082,15083]
===
match
---
name: __wrapped__ [2479,2490]
name: __wrapped__ [2493,2504]
===
match
---
suite [16291,16342]
suite [16305,16356]
===
match
---
funcdef [12080,12900]
funcdef [12094,12914]
===
match
---
param [8030,8034]
param [8044,8048]
===
match
---
name: mark [18476,18480]
name: mark [18490,18494]
===
match
---
operator: = [15657,15658]
operator: = [15671,15672]
===
match
---
string: 'fake_simple_ti' [9014,9030]
string: 'fake_simple_ti' [9028,9044]
===
match
---
operator: @ [11939,11940]
operator: @ [11953,11954]
===
match
---
name: BaseOperator [13878,13890]
name: BaseOperator [13892,13904]
===
match
---
name: execution_date [13263,13277]
name: execution_date [13277,13291]
===
match
---
simple_stmt [1356,1396]
simple_stmt [1370,1410]
===
match
---
operator: , [20018,20019]
operator: , [20032,20033]
===
match
---
parameters [15126,15132]
parameters [15140,15146]
===
match
---
suite [13145,13221]
suite [13159,13235]
===
match
---
name: CELERY_FETCH_ERR_MSG_HEADER [11171,11198]
name: CELERY_FETCH_ERR_MSG_HEADER [11185,11212]
===
match
---
atom_expr [2051,2094]
atom_expr [2065,2108]
===
match
---
parameters [1970,1972]
parameters [1984,1986]
===
match
---
suite [12996,13419]
suite [13010,13433]
===
match
---
name: tasks [11119,11124]
name: tasks [11133,11138]
===
match
---
import_name [1045,1058]
import_name [1059,1072]
===
match
---
trailer [17753,17768]
trailer [17767,17782]
===
match
---
trailer [14686,14694]
trailer [14700,14708]
===
match
---
operator: , [7364,7365]
operator: , [7378,7379]
===
match
---
assert_stmt [14671,14712]
assert_stmt [14685,14726]
===
match
---
string: 'fail' [6480,6486]
string: 'fail' [6494,6500]
===
match
---
name: TestCeleryExecutor [3549,3567]
name: TestCeleryExecutor [3563,3581]
===
match
---
name: executor [9669,9677]
name: executor [9683,9691]
===
match
---
name: mock [19915,19919]
name: mock [19929,19933]
===
match
---
testlist_comp [9006,9039]
testlist_comp [9020,9053]
===
match
---
name: running [14325,14332]
name: running [14339,14346]
===
match
---
string: "__enter__" [8327,8338]
string: "__enter__" [8341,8352]
===
match
---
name: testing [1237,1244]
name: testing [1251,1258]
===
match
---
name: task_1 [13794,13800]
name: task_1 [13808,13814]
===
match
---
parameters [16850,16863]
parameters [16864,16877]
===
match
---
arglist [6725,6744]
arglist [6739,6758]
===
match
---
name: start_date [7218,7228]
name: start_date [7232,7242]
===
match
---
operator: } [10000,10001]
operator: } [10014,10015]
===
match
---
atom_expr [10865,10879]
atom_expr [10879,10893]
===
match
---
trailer [19279,19288]
trailer [19293,19302]
===
match
---
atom_expr [9669,9698]
atom_expr [9683,9712]
===
match
---
operator: = [8689,8690]
operator: = [8703,8704]
===
match
---
suite [4197,4245]
suite [4211,4259]
===
match
---
atom_expr [15675,15685]
atom_expr [15689,15699]
===
match
---
trailer [16825,16834]
trailer [16839,16848]
===
match
---
arglist [15518,15557]
arglist [15532,15571]
===
match
---
name: execute_date [6278,6290]
name: execute_date [6292,6304]
===
match
---
string: 'success' [6433,6442]
string: 'success' [6447,6456]
===
match
---
trailer [11909,11926]
trailer [11923,11940]
===
match
---
expr_stmt [17913,17947]
expr_stmt [17927,17961]
===
match
---
trailer [18081,18085]
trailer [18095,18099]
===
match
---
name: output [18303,18309]
name: output [18317,18323]
===
match
---
name: start_date [13920,13930]
name: start_date [13934,13944]
===
match
---
operator: = [14455,14456]
operator: = [14469,14470]
===
match
---
operator: = [3300,3301]
operator: = [3314,3315]
===
match
---
operator: = [17761,17762]
operator: = [17775,17776]
===
match
---
name: mock [19336,19340]
name: mock [19350,19354]
===
match
---
name: str [16681,16684]
name: str [16695,16698]
===
match
---
trailer [20003,20007]
trailer [20017,20021]
===
match
---
fstring_start: f" [16641,16643]
fstring_start: f" [16655,16657]
===
match
---
name: CeleryExecutor [13340,13354]
name: CeleryExecutor [13354,13368]
===
match
---
dotted_name [3814,3837]
dotted_name [3828,3851]
===
match
---
atom_expr [8158,8194]
atom_expr [8172,8208]
===
match
---
import_as_names [875,894]
import_as_names [889,908]
===
match
---
operator: } [9839,9840]
operator: } [9853,9854]
===
match
---
operator: , [2938,2939]
operator: , [2952,2953]
===
match
---
name: mock [12237,12241]
name: mock [12251,12255]
===
match
---
simple_stmt [8407,8451]
simple_stmt [8421,8465]
===
match
---
operator: , [19797,19798]
operator: , [19811,19812]
===
match
---
trailer [3714,3728]
trailer [3728,3742]
===
match
---
trailer [14615,14622]
trailer [14629,14636]
===
match
---
name: State [16115,16120]
name: State [16129,16134]
===
match
---
atom_expr [19675,19684]
atom_expr [19689,19698]
===
match
---
trailer [16188,16194]
trailer [16202,16208]
===
match
---
suite [4321,6210]
suite [4335,6224]
===
match
---
name: airflow [1844,1851]
name: airflow [1858,1865]
===
match
---
atom_expr [19099,19182]
atom_expr [19113,19196]
===
match
---
trailer [10912,10916]
trailer [10926,10930]
===
match
---
comparison [9878,10017]
comparison [9892,10031]
===
match
---
operator: , [6378,6379]
operator: , [6392,6393]
===
match
---
name: test_app [2684,2692]
name: test_app [2698,2706]
===
match
---
trailer [6864,6894]
trailer [6878,6908]
===
match
---
operator: { [2576,2577]
operator: { [2590,2591]
===
match
---
name: running [14687,14694]
name: running [14701,14708]
===
match
---
sync_comp_for [2040,2094]
sync_comp_for [2054,2108]
===
match
---
simple_stmt [5710,5901]
simple_stmt [5724,5915]
===
match
---
operator: = [13627,13628]
operator: = [13641,13642]
===
match
---
operator: == [13412,13414]
operator: == [13426,13428]
===
match
---
trailer [16747,16755]
trailer [16761,16769]
===
match
---
import_from [1310,1355]
import_from [1324,1369]
===
match
---
atom_expr [5592,5626]
atom_expr [5606,5640]
===
match
---
name: self [17277,17281]
name: self [17291,17295]
===
match
---
comparison [14925,14997]
comparison [14939,15011]
===
match
---
atom_expr [17418,17481]
atom_expr [17432,17495]
===
match
---
simple_stmt [17956,18035]
simple_stmt [17970,18049]
===
match
---
operator: ** [16511,16513]
operator: ** [16525,16527]
===
match
---
atom_expr [7850,7862]
atom_expr [7864,7876]
===
match
---
name: start_date [13845,13855]
name: start_date [13859,13869]
===
match
---
name: expected_exception [12123,12141]
name: expected_exception [12137,12155]
===
match
---
parameters [3965,3983]
parameters [3979,3997]
===
match
---
trailer [8478,8499]
trailer [8492,8513]
===
match
---
operator: , [20518,20519]
operator: , [20532,20533]
===
match
---
atom_expr [6568,6585]
atom_expr [6582,6599]
===
match
---
operator: , [20331,20332]
operator: , [20345,20346]
===
match
---
atom_expr [6525,6546]
atom_expr [6539,6560]
===
match
---
parameters [4144,4153]
parameters [4158,4167]
===
match
---
simple_stmt [11611,11655]
simple_stmt [11625,11669]
===
match
---
fstring_string: ) [16700,16701]
fstring_string: ) [16714,16715]
===
match
---
name: ANY [11810,11813]
name: ANY [11824,11827]
===
match
---
name: mock_sync [11591,11600]
name: mock_sync [11605,11614]
===
match
---
atom_expr [14868,14898]
atom_expr [14882,14912]
===
match
---
name: __dict__ [16690,16698]
name: __dict__ [16704,16712]
===
match
---
operator: , [18751,18752]
operator: , [18765,18766]
===
match
---
comparison [10655,10732]
comparison [10669,10746]
===
match
---
dotted_name [19770,19789]
dotted_name [19784,19803]
===
match
---
name: value [16595,16600]
name: value [16609,16614]
===
match
---
atom [6353,6396]
atom [6367,6410]
===
match
---
parameters [12107,12142]
parameters [12121,12156]
===
match
---
trailer [9748,9761]
trailer [9762,9775]
===
match
---
param [15127,15131]
param [15141,15145]
===
match
---
expr_stmt [4588,5281]
expr_stmt [4602,5295]
===
match
---
name: adopted_task_timeouts [16225,16246]
name: adopted_task_timeouts [16239,16260]
===
match
---
trailer [7806,7843]
trailer [7820,7857]
===
match
---
name: dag_id [8694,8700]
name: dag_id [8708,8714]
===
match
---
number: 0 [5814,5815]
number: 0 [5828,5829]
===
match
---
atom_expr [10506,10541]
atom_expr [10520,10555]
===
match
---
import_from [1164,1216]
import_from [1178,1230]
===
match
---
name: utcnow [13060,13066]
name: utcnow [13074,13080]
===
match
---
string: 'airflow' [11997,12006]
string: 'airflow' [12011,12020]
===
match
---
dotted_name [1796,1818]
dotted_name [1810,1832]
===
match
---
trailer [17691,17864]
trailer [17705,17878]
===
match
---
string: "Task should no longer be queued" [7736,7769]
string: "Task should no longer be queued" [7750,7783]
===
match
---
name: clear_db_jobs [3742,3755]
name: clear_db_jobs [3756,3769]
===
match
---
name: airflow [1706,1713]
name: airflow [1720,1727]
===
match
---
name: line [11264,11268]
name: line [11278,11282]
===
match
---
name: task_id [13180,13187]
name: task_id [13194,13201]
===
match
---
operator: , [16588,16589]
operator: , [16602,16603]
===
match
---
operator: , [8938,8939]
operator: , [8952,8953]
===
match
---
atom_expr [4556,4570]
atom_expr [4570,4584]
===
match
---
simple_stmt [10499,10548]
simple_stmt [10513,10562]
===
match
---
number: 1 [9310,9311]
number: 1 [9324,9325]
===
match
---
atom_expr [13071,13088]
atom_expr [13085,13102]
===
match
---
name: command [4170,4177]
name: command [4184,4191]
===
match
---
trailer [10584,10597]
trailer [10598,10611]
===
match
---
dotted_name [1441,1459]
dotted_name [1455,1473]
===
match
---
operator: = [19270,19271]
operator: = [19284,19285]
===
match
---
simple_stmt [8045,8128]
simple_stmt [8059,8142]
===
match
---
string: "Exception" [11249,11260]
string: "Exception" [11263,11274]
===
match
---
operator: { [19488,19489]
operator: { [19502,19503]
===
match
---
string: 'ResultSession' [2940,2955]
string: 'ResultSession' [2954,2969]
===
match
---
name: dumps [17058,17063]
name: dumps [17072,17077]
===
match
---
operator: == [10569,10571]
operator: == [10583,10585]
===
match
---
name: task [13250,13254]
name: task [13264,13268]
===
match
---
operator: , [3920,3921]
operator: , [3934,3935]
===
match
---
name: State [6404,6409]
name: State [6418,6423]
===
match
---
name: dag_id [7204,7210]
name: dag_id [7218,7224]
===
match
---
name: tasks [14418,14423]
name: tasks [14432,14437]
===
match
---
operator: = [20408,20409]
operator: = [20422,20423]
===
match
---
operator: @ [2282,2283]
operator: @ [2296,2297]
===
match
---
atom_expr [3739,3757]
atom_expr [3753,3771]
===
match
---
fstring [9951,10004]
fstring [9965,10018]
===
match
---
name: autospec [19930,19938]
name: autospec [19944,19952]
===
match
---
atom_expr [12482,12515]
atom_expr [12496,12529]
===
match
---
operator: @ [12905,12906]
operator: @ [12919,12920]
===
match
---
string: "123" [20326,20331]
string: "123" [20340,20345]
===
match
---
dictorsetmaker [19117,19180]
dictorsetmaker [19131,19194]
===
match
---
name: pytest [19691,19697]
name: pytest [19705,19711]
===
match
---
trailer [5139,5160]
trailer [5153,5174]
===
match
---
name: self [16505,16509]
name: self [16519,16523]
===
match
---
name: mock [19391,19395]
name: mock [19405,19409]
===
match
---
operator: == [6401,6403]
operator: == [6415,6417]
===
match
---
atom_expr [20228,20473]
atom_expr [20242,20487]
===
match
---
atom [10124,10132]
atom [10138,10146]
===
match
---
operator: , [5239,5240]
operator: , [5253,5254]
===
match
---
operator: , [8854,8855]
operator: , [8868,8869]
===
match
---
expr_stmt [2669,2706]
expr_stmt [2683,2720]
===
match
---
string: "rabbitmq" [18452,18462]
string: "rabbitmq" [18466,18476]
===
match
---
operator: , [16537,16538]
operator: , [16551,16552]
===
match
---
testlist_comp [5542,5570]
testlist_comp [5556,5584]
===
match
---
trailer [7675,7685]
trailer [7689,7699]
===
match
---
argument [4487,4505]
argument [4501,4519]
===
match
---
operator: , [16778,16779]
operator: , [16792,16793]
===
match
---
param [12108,12113]
param [12122,12127]
===
match
---
name: cm [20687,20689]
name: cm [20701,20703]
===
match
---
comparison [4170,4196]
comparison [4184,4210]
===
match
---
atom [19556,19671]
atom [19570,19685]
===
match
---
expr_stmt [14505,14579]
expr_stmt [14519,14593]
===
match
---
suite [16787,16835]
suite [16801,16849]
===
match
---
dictorsetmaker [9283,9289]
dictorsetmaker [9297,9303]
===
match
---
trailer [2228,2230]
trailer [2242,2244]
===
match
---
name: fake_execute_command [6797,6817]
name: fake_execute_command [6811,6831]
===
match
---
trailer [2007,2015]
trailer [2021,2029]
===
match
---
number: 0 [6143,6144]
number: 0 [6157,6158]
===
match
---
expr_stmt [15142,15195]
expr_stmt [15156,15209]
===
match
---
expr_stmt [8612,8747]
expr_stmt [8626,8761]
===
match
---
string: "test" [7167,7173]
string: "test" [7181,7187]
===
match
---
or_test [2436,2490]
or_test [2450,2504]
===
match
---
name: db [3652,3654]
name: db [3666,3668]
===
match
---
operator: } [9289,9290]
operator: } [9303,9304]
===
match
---
trailer [17395,17399]
trailer [17409,17413]
===
match
---
operator: = [14266,14267]
operator: = [14280,14281]
===
match
---
name: worker [1245,1251]
name: worker [1259,1265]
===
match
---
simple_stmt [7616,7655]
simple_stmt [7630,7669]
===
match
---
name: value [16539,16544]
name: value [16553,16558]
===
match
---
dotted_name [10739,10762]
dotted_name [10753,10776]
===
match
---
operator: , [11993,11994]
operator: , [12007,12008]
===
match
---
trailer [7285,7289]
trailer [7299,7303]
===
match
---
trailer [9677,9698]
trailer [9691,9712]
===
match
---
operator: == [9312,9314]
operator: == [9326,9328]
===
match
---
operator: , [14969,14970]
operator: , [14983,14984]
===
match
---
simple_stmt [6426,6465]
simple_stmt [6440,6479]
===
match
---
operator: { [14768,14769]
operator: { [14782,14783]
===
match
---
name: end [6188,6191]
name: end [6202,6205]
===
match
---
atom [4415,4417]
atom [4429,4431]
===
match
---
expr_stmt [15651,15725]
expr_stmt [15665,15739]
===
match
---
param [18549,18554]
param [18563,18568]
===
match
---
operator: @ [3763,3764]
operator: @ [3777,3778]
===
match
---
expr_stmt [2608,2664]
expr_stmt [2622,2678]
===
match
---
trailer [20039,20050]
trailer [20053,20064]
===
match
---
number: 1 [16340,16341]
number: 1 [16354,16355]
===
match
---
trailer [7422,7481]
trailer [7436,7495]
===
match
---
operator: , [1759,1760]
operator: , [1773,1774]
===
match
---
atom_expr [20687,20696]
atom_expr [20701,20710]
===
match
---
suite [12516,12578]
suite [12530,12592]
===
match
---
atom_expr [5717,5744]
atom_expr [5731,5758]
===
match
---
trailer [17320,17322]
trailer [17334,17336]
===
match
---
name: pytest [6664,6670]
name: pytest [6678,6684]
===
match
---
name: test_config [2557,2568]
name: test_config [2571,2582]
===
match
---
name: key_1 [14944,14949]
name: key_1 [14958,14963]
===
match
---
operator: } [14711,14712]
operator: } [14725,14726]
===
match
---
operator: , [14649,14650]
operator: , [14663,14664]
===
match
---
operator: , [4704,4705]
operator: , [4718,4719]
===
match
---
string: "INFO:airflow.executors.celery_executor.CeleryExecutor:" [10299,10355]
string: "INFO:airflow.executors.celery_executor.CeleryExecutor:" [10313,10369]
===
match
---
name: BashOperator [7129,7141]
name: BashOperator [7143,7155]
===
match
---
name: cm [17601,17603]
name: cm [17615,17617]
===
match
---
suite [13510,15035]
suite [13524,15049]
===
match
---
trailer [14876,14898]
trailer [14890,14912]
===
match
---
simple_stmt [7066,7110]
simple_stmt [7080,7124]
===
match
---
name: other [16780,16785]
name: other [16794,16799]
===
match
---
with_item [8158,8200]
with_item [8172,8214]
===
match
---
trailer [11077,11109]
trailer [11091,11123]
===
match
---
comparison [10567,10598]
comparison [10581,10612]
===
match
---
atom [5541,5571]
atom [5555,5585]
===
match
---
operator: } [14908,14909]
operator: } [14922,14923]
===
match
---
assert_stmt [10274,10452]
assert_stmt [10288,10466]
===
match
---
number: 2 [9288,9289]
number: 2 [9302,9303]
===
match
---
operator: , [14898,14899]
operator: , [14912,14913]
===
match
---
param [4145,4152]
param [4159,4166]
===
match
---
operator: == [9835,9837]
operator: == [9849,9851]
===
match
---
param [2343,2355]
param [2357,2369]
===
match
---
atom [19496,19513]
atom [19510,19527]
===
match
---
decorator [19690,19724]
decorator [19704,19738]
===
match
---
trailer [15674,15725]
trailer [15688,15739]
===
match
---
atom_expr [5946,6018]
atom_expr [5960,6032]
===
match
---
dotted_name [7948,7967]
dotted_name [7962,7981]
===
match
---
parameters [19851,19857]
parameters [19865,19871]
===
match
---
simple_stmt [10145,10215]
simple_stmt [10159,10229]
===
match
---
suite [20156,20474]
suite [20170,20488]
===
match
---
decorators [10738,10809]
decorators [10752,10823]
===
match
---
fstring_expr [10417,10422]
fstring_expr [10431,10436]
===
match
---
simple_stmt [14232,14249]
simple_stmt [14246,14263]
===
match
---
operator: , [17481,17482]
operator: , [17495,17496]
===
match
---
name: test_try_adopt_task_instances [13474,13503]
name: test_try_adopt_task_instances [13488,13517]
===
match
---
trailer [15795,15817]
trailer [15809,15831]
===
match
---
name: TaskInstance [13237,13249]
name: TaskInstance [13251,13263]
===
match
---
atom_expr [14357,14387]
atom_expr [14371,14401]
===
match
---
trailer [19987,20033]
trailer [20001,20047]
===
match
---
suite [3587,16253]
suite [3601,16267]
===
match
---
trailer [2727,2733]
trailer [2741,2747]
===
match
---
name: key_2 [14588,14593]
name: key_2 [14602,14607]
===
match
---
argument [2638,2663]
argument [2652,2677]
===
match
---
simple_stmt [14086,14144]
simple_stmt [14100,14158]
===
match
---
comparison [9664,9711]
comparison [9678,9725]
===
match
---
atom_expr [7426,7480]
atom_expr [7440,7494]
===
match
---
atom_expr [13803,13856]
atom_expr [13817,13870]
===
match
---
funcdef [12951,13419]
funcdef [12965,13433]
===
match
---
name: celery_executor [15746,15761]
name: celery_executor [15760,15775]
===
match
---
suite [18889,19462]
suite [18903,19476]
===
match
---
operator: , [18553,18554]
operator: , [18567,18568]
===
match
---
name: airflow [1671,1678]
name: airflow [1685,1692]
===
match
---
name: ti1 [14048,14051]
name: ti1 [14062,14065]
===
match
---
simple_stmt [16050,16066]
simple_stmt [16064,16080]
===
match
---
name: BulkStateFetcher [19228,19244]
name: BulkStateFetcher [19242,19258]
===
match
---
string: 'fake_simple_ti' [4670,4686]
string: 'fake_simple_ti' [4684,4700]
===
match
---
atom_expr [12594,12626]
atom_expr [12608,12640]
===
match
---
expr_stmt [3993,4064]
expr_stmt [4007,4078]
===
match
---
operator: , [10879,10880]
operator: , [10893,10894]
===
match
---
operator: = [8416,8417]
operator: = [8430,8431]
===
match
---
atom_expr [15357,15400]
atom_expr [15371,15414]
===
match
---
with_stmt [18578,19462]
with_stmt [18592,19476]
===
match
---
classdef [3543,16253]
classdef [3557,16267]
===
match
---
operator: = [8656,8657]
operator: = [8670,8671]
===
match
---
argument [13834,13855]
argument [13848,13869]
===
match
---
operator: @ [10767,10768]
operator: @ [10781,10782]
===
match
---
trailer [8433,8448]
trailer [8447,8462]
===
match
---
name: executor [4430,4438]
name: executor [4444,4452]
===
match
---
atom [19310,19443]
atom [19324,19457]
===
match
---
name: DAG [15357,15360]
name: DAG [15371,15374]
===
match
---
operator: , [8663,8664]
operator: , [8677,8678]
===
match
---
trailer [13608,13610]
trailer [13622,13624]
===
match
---
simple_stmt [838,854]
simple_stmt [852,868]
===
match
---
simple_stmt [11238,11292]
simple_stmt [11252,11306]
===
match
---
dotted_name [18428,18451]
dotted_name [18442,18465]
===
match
---
trailer [18302,18309]
trailer [18316,18323]
===
match
---
name: executor [6179,6187]
name: executor [6193,6201]
===
match
---
name: dag [1686,1689]
name: dag [1700,1703]
===
match
---
trailer [16807,16816]
trailer [16821,16830]
===
match
---
operator: = [2721,2722]
operator: = [2735,2736]
===
match
---
simple_stmt [1164,1217]
simple_stmt [1178,1231]
===
match
---
operator: = [11008,11009]
operator: = [11022,11023]
===
match
---
comparison [6433,6464]
comparison [6447,6478]
===
match
---
atom_expr [19988,20007]
atom_expr [20002,20021]
===
match
---
operator: , [19365,19366]
operator: , [19379,19380]
===
match
---
string: 'SUCCESS' [20509,20518]
string: 'SUCCESS' [20523,20532]
===
match
---
name: pytest [13425,13431]
name: pytest [13439,13445]
===
match
---
arglist [12926,12945]
arglist [12940,12959]
===
match
---
operator: = [14032,14033]
operator: = [14046,14047]
===
match
---
name: minutes [15307,15314]
name: minutes [15321,15328]
===
match
---
name: dag [8686,8689]
name: dag [8700,8703]
===
match
---
suite [13781,13932]
suite [13795,13946]
===
match
---
atom_expr [9053,9079]
atom_expr [9067,9093]
===
match
---
name: executor [11110,11118]
name: executor [11124,11132]
===
match
---
trailer [6154,6161]
trailer [6168,6175]
===
match
---
dotted_name [1917,1933]
dotted_name [1931,1947]
===
match
---
funcdef [4120,4245]
funcdef [4134,4259]
===
match
---
name: side_effect [8352,8363]
name: side_effect [8366,8377]
===
match
---
operator: , [11756,11757]
operator: , [11770,11771]
===
match
---
trailer [10010,10017]
trailer [10024,10031]
===
match
---
string: 'celery' [2118,2126]
string: 'celery' [2132,2140]
===
match
---
trailer [13661,13668]
trailer [13675,13682]
===
match
---
name: tis [13292,13295]
name: tis [13306,13309]
===
match
---
name: mock [19970,19974]
name: mock [19984,19988]
===
match
---
atom_expr [18300,18309]
atom_expr [18314,18323]
===
match
---
atom_expr [3625,3643]
atom_expr [3639,3657]
===
match
---
import_name [838,853]
import_name [852,867]
===
match
---
trailer [17063,17104]
trailer [17077,17118]
===
match
---
operator: = [13801,13802]
operator: = [13815,13816]
===
match
---
argument [8649,8663]
argument [8663,8677]
===
match
---
string: "test" [8657,8663]
string: "test" [8671,8677]
===
match
---
name: celery [1090,1096]
name: celery [1104,1110]
===
match
---
trailer [20689,20696]
trailer [20703,20710]
===
match
---
name: key_1 [14782,14787]
name: key_1 [14796,14801]
===
match
---
simple_stmt [14918,14998]
simple_stmt [14932,15012]
===
match
---
name: start_date [13580,13590]
name: start_date [13594,13604]
===
match
---
comparison [6568,6619]
comparison [6582,6633]
===
match
---
simple_stmt [15142,15196]
simple_stmt [15156,15210]
===
match
---
name: mget_args [17967,17976]
name: mget_args [17981,17990]
===
match
---
trailer [20199,20202]
trailer [20213,20216]
===
match
---
arglist [6578,6584]
arglist [6592,6598]
===
match
---
dictorsetmaker [9704,9710]
dictorsetmaker [9718,9724]
===
match
---
name: command [4145,4152]
name: command [4159,4166]
===
match
---
name: ti2 [14193,14196]
name: ti2 [14207,14210]
===
match
---
operator: = [13165,13166]
operator: = [13179,13180]
===
match
---
name: task_tuples_to_send [5672,5691]
name: task_tuples_to_send [5686,5705]
===
match
---
operator: , [2406,2407]
operator: , [2420,2421]
===
match
---
trailer [8305,8313]
trailer [8319,8327]
===
match
---
trailer [3347,3349]
trailer [3361,3363]
===
match
---
name: raises [12489,12495]
name: raises [12503,12509]
===
match
---
suite [16727,16758]
suite [16741,16772]
===
match
---
simple_stmt [1791,1839]
simple_stmt [1805,1853]
===
match
---
number: 0 [6394,6395]
number: 0 [6408,6409]
===
match
---
name: AirflowTaskTimeout [8364,8382]
name: AirflowTaskTimeout [8378,8396]
===
match
---
assert_stmt [9853,10031]
assert_stmt [9867,10045]
===
match
---
name: task_id [13891,13898]
name: task_id [13905,13912]
===
match
---
atom_expr [15217,15234]
atom_expr [15231,15248]
===
match
---
trailer [15183,15195]
trailer [15197,15209]
===
match
---
name: self [16803,16807]
name: self [16817,16821]
===
match
---
number: 1 [20200,20201]
number: 1 [20214,20215]
===
match
---
expr_stmt [4073,4110]
expr_stmt [4087,4124]
===
match
---
operator: , [10795,10796]
operator: , [10809,10810]
===
match
---
name: command [12114,12121]
name: command [12128,12135]
===
match
---
name: ANY [11869,11872]
name: ANY [11883,11886]
===
match
---
operator: { [15987,15988]
operator: { [16001,16002]
===
match
---
name: AsyncResult [14951,14962]
name: AsyncResult [14965,14976]
===
match
---
trailer [4405,4411]
trailer [4419,4425]
===
match
---
name: timedelta [15237,15246]
name: timedelta [15251,15260]
===
match
---
name: executor [15970,15978]
name: executor [15984,15992]
===
match
---
name: patch_app [3360,3369]
name: patch_app [3374,3383]
===
match
---
operator: } [9418,9419]
operator: } [9432,9433]
===
match
---
string: 'backend' [18742,18751]
string: 'backend' [18756,18765]
===
match
---
dotted_name [7907,7930]
dotted_name [7921,7944]
===
match
---
number: 0 [6012,6013]
number: 0 [6026,6027]
===
match
---
name: clear_db_jobs [3655,3668]
name: clear_db_jobs [3669,3682]
===
match
---
trailer [13682,13693]
trailer [13696,13707]
===
match
---
assert_stmt [10078,10132]
assert_stmt [10092,10146]
===
match
---
atom [4610,5281]
atom [4624,5295]
===
match
---
operator: { [16198,16199]
operator: { [16212,16213]
===
match
---
trailer [15246,15254]
trailer [15260,15268]
===
match
---
testlist_comp [6099,6140]
testlist_comp [6113,6154]
===
match
---
trailer [3341,3347]
trailer [3355,3361]
===
match
---
string: "mysql" [7968,7975]
string: "mysql" [7982,7989]
===
match
---
atom_expr [10720,10732]
atom_expr [10734,10746]
===
match
---
operator: = [19075,19076]
operator: = [19089,19090]
===
match
---
name: self [6778,6782]
name: self [6792,6796]
===
match
---
trailer [17976,17979]
trailer [17990,17993]
===
match
---
operator: , [8971,8972]
operator: , [8985,8986]
===
match
---
name: mock_fork [12643,12652]
name: mock_fork [12657,12666]
===
match
---
name: now [4565,4568]
name: now [4579,4582]
===
match
---
name: dict [2510,2514]
name: dict [2524,2528]
===
match
---
comparison [9392,9419]
comparison [9406,9433]
===
match
---
operator: = [15191,15192]
operator: = [15205,15206]
===
match
---
testlist_comp [7808,7841]
testlist_comp [7822,7855]
===
match
---
name: key [9704,9707]
name: key [9718,9721]
===
match
---
name: celery [1064,1070]
name: celery [1078,1084]
===
match
---
operator: = [15546,15547]
operator: = [15560,15561]
===
match
---
name: queued_tasks [6534,6546]
name: queued_tasks [6548,6560]
===
match
---
name: state [20416,20421]
name: state [20430,20435]
===
match
---
name: celery_executor [1573,1588]
name: celery_executor [1587,1602]
===
match
---
atom_expr [15659,15725]
atom_expr [15673,15739]
===
match
---
trailer [7720,7733]
trailer [7734,7747]
===
match
---
funcdef [16708,16758]
funcdef [16722,16772]
===
match
---
name: dict [10085,10089]
name: dict [10099,10103]
===
match
---
name: task_publish_retries [9678,9698]
name: task_publish_retries [9692,9712]
===
match
---
trailer [2393,2397]
trailer [2407,2411]
===
match
---
trailer [11652,11654]
trailer [11666,11668]
===
match
---
name: integration [19741,19752]
name: integration [19755,19766]
===
match
---
name: external_executor_id [14011,14031]
name: external_executor_id [14025,14045]
===
match
---
atom [2108,2142]
atom [2122,2156]
===
match
---
operator: = [8806,8807]
operator: = [8820,8821]
===
match
---
simple_stmt [19218,19247]
simple_stmt [19232,19261]
===
match
---
name: task_1 [13255,13261]
name: task_1 [13269,13275]
===
match
---
name: key_1 [15568,15573]
name: key_1 [15582,15587]
===
match
---
simple_stmt [12594,12627]
simple_stmt [12608,12641]
===
match
---
suite [19858,20697]
suite [19872,20711]
===
match
---
atom_expr [8290,8313]
atom_expr [8304,8327]
===
match
---
name: key_2 [14971,14976]
name: key_2 [14985,14990]
===
match
---
argument [6865,6893]
argument [6879,6907]
===
match
---
name: celery_executor [11155,11170]
name: celery_executor [11169,11184]
===
match
---
string: '456' [19515,19520]
string: '456' [19529,19534]
===
match
---
atom_expr [15746,15778]
atom_expr [15760,15792]
===
match
---
import_name [965,1000]
import_name [979,1014]
===
match
---
operator: , [20544,20545]
operator: , [20558,20559]
===
match
---
atom [6550,6552]
atom [6564,6566]
===
match
---
assert_stmt [14350,14393]
assert_stmt [14364,14407]
===
match
---
operator: = [13296,13297]
operator: = [13310,13311]
===
match
---
name: timedelta [15297,15306]
name: timedelta [15311,15320]
===
match
---
atom_expr [17631,17649]
atom_expr [17645,17663]
===
match
---
operator: , [5419,5420]
operator: , [5433,5434]
===
match
---
operator: , [12897,12898]
operator: , [12911,12912]
===
match
---
string: "rabbitmq" [7931,7941]
string: "rabbitmq" [7945,7955]
===
match
---
decorator [17117,17151]
decorator [17131,17165]
===
match
---
name: mark [12913,12917]
name: mark [12927,12931]
===
match
---
simple_stmt [9203,9224]
simple_stmt [9217,9238]
===
match
---
string: "task_id" [19163,19172]
string: "task_id" [19177,19186]
===
match
---
expr_stmt [7616,7654]
expr_stmt [7630,7668]
===
match
---
name: dag [15675,15678]
name: dag [15689,15692]
===
match
---
trailer [2083,2089]
trailer [2097,2103]
===
match
---
string: "rabbitmq" [17180,17190]
string: "rabbitmq" [17194,17204]
===
match
---
name: pytest [7869,7875]
name: pytest [7883,7889]
===
match
---
atom [8808,8986]
atom [8822,9000]
===
match
---
name: task_2 [15496,15502]
name: task_2 [15510,15516]
===
match
---
atom_expr [4220,4244]
atom_expr [4234,4258]
===
match
---
trailer [18947,18960]
trailer [18961,18974]
===
match
---
trailer [9327,9340]
trailer [9341,9354]
===
match
---
string: "mysql" [12926,12933]
string: "mysql" [12940,12947]
===
match
---
trailer [5967,6015]
trailer [5981,6029]
===
match
---
name: queued_dttm [13639,13650]
name: queued_dttm [13653,13664]
===
match
---
decorated [3763,6620]
decorated [3777,6634]
===
match
---
arglist [10788,10807]
arglist [10802,10821]
===
match
---
trailer [14365,14387]
trailer [14379,14401]
===
match
---
name: MagicMock [19104,19113]
name: MagicMock [19118,19127]
===
match
---
operator: , [7734,7735]
operator: , [7748,7749]
===
match
---
name: execution_date [8940,8954]
name: execution_date [8954,8968]
===
match
---
number: 0 [17977,17978]
number: 0 [17991,17992]
===
match
---
name: key_2 [15651,15656]
name: key_2 [15665,15670]
===
match
---
operator: == [16103,16105]
operator: == [16117,16119]
===
match
---
argument [17039,17105]
argument [17053,17119]
===
match
---
name: BaseBackend [1118,1129]
name: BaseBackend [1132,1143]
===
match
---
name: tasks [995,1000]
name: tasks [1009,1014]
===
match
---
string: '456' [20527,20532]
string: '456' [20541,20546]
===
match
---
name: task_id [2240,2247]
name: task_id [2254,2261]
===
match
---
simple_stmt [13580,13631]
simple_stmt [13594,13645]
===
match
---
operator: , [17568,17569]
operator: , [17582,17583]
===
match
---
atom_expr [14541,14555]
atom_expr [14555,14569]
===
match
---
name: FakeCeleryResult [2152,2168]
name: FakeCeleryResult [2166,2182]
===
match
---
name: queued_dttm [14197,14208]
name: queued_dttm [14211,14222]
===
match
---
operator: { [16106,16107]
operator: { [16120,16121]
===
match
---
operator: , [5552,5553]
operator: , [5566,5567]
===
match
---
name: app [17376,17379]
name: app [17390,17393]
===
match
---
operator: , [5877,5878]
operator: , [5891,5892]
===
match
---
operator: , [1129,1130]
operator: , [1143,1144]
===
match
---
param [6778,6782]
param [6792,6796]
===
match
---
atom_expr [15592,15602]
atom_expr [15606,15616]
===
match
---
atom_expr [5124,5182]
atom_expr [5138,5196]
===
match
---
funcdef [6793,6838]
funcdef [6807,6852]
===
match
---
expr_stmt [15204,15254]
expr_stmt [15218,15268]
===
match
---
name: __repr__ [16712,16720]
name: __repr__ [16726,16734]
===
match
---
string: 'fail' [6099,6105]
string: 'fail' [6113,6119]
===
match
---
name: object [17429,17435]
name: object [17443,17449]
===
match
---
name: line [11273,11277]
name: line [11287,11291]
===
match
---
operator: = [7075,7076]
operator: = [7089,7090]
===
match
---
trailer [18641,18684]
trailer [18655,18698]
===
match
---
atom_expr [16932,16949]
atom_expr [16946,16963]
===
match
---
name: log [8190,8193]
name: log [8204,8207]
===
match
---
simple_stmt [7122,7258]
simple_stmt [7136,7272]
===
match
---
atom_expr [14678,14694]
atom_expr [14692,14708]
===
match
---
operator: = [15985,15986]
operator: = [15999,16000]
===
match
---
operator: } [9579,9580]
operator: } [9593,9594]
===
match
---
name: test_exception_propagation [10817,10843]
name: test_exception_propagation [10831,10857]
===
match
---
arith_expr [14789,14833]
arith_expr [14803,14847]
===
match
---
operator: , [19513,19514]
operator: , [19527,19528]
===
match
---
name: datetime [8955,8963]
name: datetime [8969,8977]
===
match
---
simple_stmt [10993,11038]
simple_stmt [11007,11052]
===
match
---
argument [4507,4522]
argument [4521,4536]
===
match
---
decorator [18468,18510]
decorator [18482,18524]
===
match
---
atom [16250,16252]
atom [16264,16266]
===
match
---
import_from [1550,1612]
import_from [1564,1626]
===
match
---
operator: == [20497,20499]
operator: == [20511,20513]
===
match
---
name: filter [19038,19044]
name: filter [19052,19058]
===
match
---
name: executor [9203,9211]
name: executor [9217,9225]
===
match
---
arglist [4272,4312]
arglist [4286,4326]
===
match
---
name: executor [9248,9256]
name: executor [9262,9270]
===
match
---
name: mock [18316,18320]
name: mock [18330,18334]
===
match
---
operator: @ [19728,19729]
operator: @ [19742,19743]
===
match
---
number: 2 [13628,13629]
number: 2 [13642,13643]
===
match
---
arglist [18721,18765]
arglist [18735,18779]
===
match
---
name: tasks [6503,6508]
name: tasks [6517,6522]
===
match
---
trailer [4564,4568]
trailer [4578,4582]
===
match
---
name: executor [9624,9632]
name: executor [9638,9646]
===
match
---
with_item [20035,20155]
with_item [20049,20169]
===
match
---
atom [18113,18165]
atom [18127,18179]
===
match
---
atom_expr [13012,13029]
atom_expr [13026,13043]
===
match
---
operator: @ [19769,19770]
operator: @ [19783,19784]
===
match
---
param [12123,12141]
param [12137,12155]
===
match
---
trailer [11868,11872]
trailer [11882,11886]
===
match
---
name: simple_ti [5410,5419]
name: simple_ti [5424,5433]
===
match
---
simple_stmt [5592,5631]
simple_stmt [5606,5645]
===
match
---
name: mock_session [18555,18567]
name: mock_session [18569,18581]
===
match
---
atom_expr [11893,11933]
atom_expr [11907,11947]
===
match
---
name: BaseOperator [13803,13815]
name: BaseOperator [13817,13829]
===
match
---
name: taskinstance [1721,1733]
name: taskinstance [1735,1747]
===
match
---
operator: = [4554,4555]
operator: = [4568,4569]
===
match
---
fstring_string: [Try 3 of 3] Task Timeout Error for Task: ( [10374,10417]
fstring_string: [Try 3 of 3] Task Timeout Error for Task: ( [10388,10431]
===
match
---
trailer [17798,17808]
trailer [17812,17822]
===
match
---
name: other [16857,16862]
name: other [16871,16876]
===
match
---
name: when [7834,7838]
name: when [7848,7852]
===
match
---
operator: , [11873,11874]
operator: , [11887,11888]
===
match
---
name: patch [16962,16967]
name: patch [16976,16981]
===
match
---
trailer [11248,11291]
trailer [11262,11305]
===
match
---
operator: = [4343,4344]
operator: = [4357,4358]
===
match
---
return_stmt [2100,2143]
return_stmt [2114,2157]
===
match
---
return_stmt [16873,16902]
return_stmt [16887,16916]
===
match
---
decorated [15040,16253]
decorated [15054,16267]
===
match
---
trailer [11154,11229]
trailer [11168,11243]
===
match
---
parameters [2197,2203]
parameters [2211,2217]
===
match
---
trailer [8189,8193]
trailer [8203,8207]
===
match
---
operator: , [5098,5099]
operator: , [5112,5113]
===
match
---
name: celery_executor [1534,1549]
name: celery_executor [1548,1563]
===
match
---
dotted_name [15041,15060]
dotted_name [15055,15074]
===
match
---
simple_stmt [10937,10981]
simple_stmt [10951,10995]
===
match
---
operator: , [5780,5781]
operator: , [5794,5795]
===
match
---
funcdef [2188,2231]
funcdef [2202,2245]
===
match
---
name: object [8213,8219]
name: object [8227,8233]
===
match
---
dotted_name [6626,6649]
dotted_name [6640,6663]
===
match
---
if_stmt [1978,2096]
if_stmt [1992,2110]
===
match
---
name: mark [3821,3825]
name: mark [3835,3839]
===
match
---
argument [8929,8938]
argument [8943,8952]
===
match
---
name: return_value [19062,19074]
name: return_value [19076,19088]
===
match
---
atom_expr [10008,10017]
atom_expr [10022,10031]
===
match
---
comparison [4397,4417]
comparison [4411,4431]
===
match
---
name: event_buffer [5955,5967]
name: event_buffer [5969,5981]
===
match
---
name: cm [10921,10923]
name: cm [10935,10937]
===
match
---
name: app [20004,20007]
name: app [20018,20021]
===
match
---
atom_expr [18703,18766]
atom_expr [18717,18780]
===
match
---
name: mock [12347,12351]
name: mock [12361,12365]
===
match
---
name: not_adopted_tis [14439,14454]
name: not_adopted_tis [14453,14468]
===
match
---
atom_expr [14193,14208]
atom_expr [14207,14222]
===
match
---
simple_stmt [14350,14394]
simple_stmt [14364,14408]
===
match
---
suite [17294,18310]
suite [17308,18324]
===
match
---
operator: , [7975,7976]
operator: , [7989,7990]
===
match
---
string: 'broker_url' [2577,2589]
string: 'broker_url' [2591,2603]
===
match
---
operator: = [7275,7276]
operator: = [7289,7290]
===
match
---
simple_stmt [1217,1272]
simple_stmt [1231,1286]
===
match
---
name: mock [18703,18707]
name: mock [18717,18721]
===
match
---
expr_stmt [13005,13029]
expr_stmt [13019,13043]
===
match
---
name: executor [5512,5520]
name: executor [5526,5534]
===
match
---
operator: } [16163,16164]
operator: } [16177,16178]
===
match
---
expr_stmt [5592,5630]
expr_stmt [5606,5644]
===
match
---
atom_expr [6179,6209]
atom_expr [6193,6223]
===
match
---
atom_expr [11770,11814]
atom_expr [11784,11828]
===
match
---
expr_stmt [10937,10980]
expr_stmt [10951,10994]
===
match
---
operator: , [8684,8685]
operator: , [8698,8699]
===
match
---
atom_expr [9736,9762]
atom_expr [9750,9776]
===
match
---
expr_stmt [15421,15483]
expr_stmt [15435,15497]
===
match
---
operator: = [5539,5540]
operator: = [5553,5554]
===
match
---
arglist [13250,13282]
arglist [13264,13296]
===
match
---
suite [17323,17865]
suite [17337,17879]
===
match
---
number: 3 [8562,8563]
number: 3 [8576,8577]
===
match
---
name: patch [8207,8212]
name: patch [8221,8226]
===
match
---
name: exec_date [14133,14142]
name: exec_date [14147,14156]
===
match
---
name: datetime [4556,4564]
name: datetime [4570,4578]
===
match
---
strings [9878,10004]
strings [9892,10018]
===
match
---
atom_expr [2557,2603]
atom_expr [2571,2617]
===
match
---
atom_expr [8719,8733]
atom_expr [8733,8747]
===
match
---
string: 'fail' [5839,5845]
string: 'fail' [5853,5859]
===
match
---
string: 'success' [5969,5978]
string: 'success' [5983,5992]
===
match
---
trailer [12722,12738]
trailer [12736,12752]
===
match
---
trailer [14962,14969]
trailer [14976,14983]
===
match
---
trailer [7141,7257]
trailer [7155,7271]
===
match
---
testlist_comp [11996,12030]
testlist_comp [12010,12044]
===
match
---
trailer [12241,12247]
trailer [12255,12261]
===
match
---
operator: = [13690,13691]
operator: = [13704,13705]
===
match
---
name: items [16555,16560]
name: items [16569,16574]
===
match
---
atom_expr [5512,5538]
atom_expr [5526,5552]
===
match
---
atom_expr [16180,16194]
atom_expr [16194,16208]
===
match
---
operator: , [3369,3370]
operator: , [3383,3384]
===
match
---
expr_stmt [7122,7257]
expr_stmt [7136,7271]
===
match
---
atom_expr [2219,2230]
atom_expr [2233,2244]
===
match
---
simple_stmt [7304,7497]
simple_stmt [7318,7511]
===
match
---
name: datetime [13051,13059]
name: datetime [13065,13073]
===
match
---
name: url [2044,2047]
name: url [2058,2061]
===
match
---
trailer [3755,3757]
trailer [3769,3771]
===
match
---
name: executors [1563,1572]
name: executors [1577,1586]
===
match
---
name: celery_executor [10897,10912]
name: celery_executor [10911,10926]
===
match
---
expr_stmt [13794,13856]
expr_stmt [13808,13870]
===
match
---
trailer [3534,3540]
trailer [3548,3554]
===
match
---
name: Celery [1078,1084]
name: Celery [1092,1098]
===
match
---
atom_expr [13593,13610]
atom_expr [13607,13624]
===
match
---
param [16851,16856]
param [16865,16870]
===
match
---
testlist_comp [8826,8972]
testlist_comp [8840,8986]
===
match
---
operator: @ [17155,17156]
operator: @ [17169,17170]
===
match
---
string: 'success' [4659,4668]
string: 'success' [4673,4682]
===
match
---
operator: , [6392,6393]
operator: , [6406,6407]
===
match
---
string: 'version' [12008,12017]
string: 'version' [12022,12031]
===
match
---
atom [9838,9840]
atom [9852,9854]
===
match
---
name: mark [19736,19740]
name: mark [19750,19754]
===
match
---
parameters [16504,16520]
parameters [16518,16534]
===
match
---
name: key1 [13299,13303]
name: key1 [13313,13317]
===
match
---
operator: = [13591,13592]
operator: = [13605,13606]
===
match
---
name: celery_executor [7077,7092]
name: celery_executor [7091,7106]
===
match
---
operator: , [9762,9763]
operator: , [9776,9777]
===
match
---
name: parameterized [11940,11953]
name: parameterized [11954,11967]
===
match
---
with_stmt [15352,15559]
with_stmt [15366,15573]
===
match
---
name: CeleryExecutor [7093,7107]
name: CeleryExecutor [7107,7121]
===
match
---
atom [14698,14712]
atom [14712,14726]
===
match
---
name: event_buffer [16090,16102]
name: event_buffer [16104,16116]
===
match
---
name: date [13278,13282]
name: date [13292,13296]
===
match
---
simple_stmt [854,895]
simple_stmt [868,909]
===
match
---
atom_expr [16050,16065]
atom_expr [16064,16079]
===
match
---
atom_expr [6450,6464]
atom_expr [6464,6478]
===
match
---
name: task_2 [14110,14116]
name: task_2 [14124,14130]
===
match
---
trailer [19024,19037]
trailer [19038,19051]
===
match
---
name: tasks [14934,14939]
name: tasks [14948,14953]
===
match
---
string: '123' [19489,19494]
string: '123' [19503,19508]
===
match
---
parameters [16773,16786]
parameters [16787,16800]
===
match
---
name: __ne__ [16844,16850]
name: __ne__ [16858,16864]
===
match
---
name: fail_command [4073,4085]
name: fail_command [4087,4099]
===
match
---
operator: , [5996,5997]
operator: , [6010,6011]
===
match
---
operator: = [13208,13209]
operator: = [13222,13223]
===
match
---
operator: @ [15040,15041]
operator: @ [15054,15055]
===
match
---
atom [8503,8505]
atom [8517,8519]
===
match
---
name: quarantined [10751,10762]
name: quarantined [10765,10776]
===
match
---
atom_expr [14612,14622]
atom_expr [14626,14636]
===
match
---
testlist_comp [4658,4917]
testlist_comp [4672,4931]
===
match
---
operator: { [17984,17985]
operator: { [17998,17999]
===
match
---
atom_expr [20375,20432]
atom_expr [20389,20446]
===
match
---
number: 1 [7363,7364]
number: 1 [7377,7378]
===
match
---
argument [8686,8706]
argument [8700,8720]
===
match
---
operator: , [13452,13453]
operator: , [13466,13467]
===
match
---
name: mock [18077,18081]
name: mock [18091,18095]
===
match
---
name: start_date [13909,13919]
name: start_date [13923,13933]
===
match
---
name: TaskInstance [1761,1773]
name: TaskInstance [1775,1787]
===
match
---
trailer [17743,17753]
trailer [17757,17767]
===
match
---
atom_expr [17794,17823]
atom_expr [17808,17837]
===
match
---
operator: { [16643,16644]
operator: { [16657,16658]
===
match
---
atom_expr [7667,7687]
atom_expr [7681,7701]
===
match
---
with_item [15357,15407]
with_item [15371,15421]
===
match
---
atom_expr [4801,4859]
atom_expr [4815,4873]
===
match
---
comparison [20568,20696]
comparison [20582,20710]
===
match
---
trailer [19061,19074]
trailer [19075,19088]
===
match
---
name: queue [5430,5435]
name: queue [5444,5449]
===
match
---
assert_stmt [9236,9290]
assert_stmt [9250,9304]
===
match
---
operator: , [16134,16135]
operator: , [16148,16149]
===
match
---
trailer [10725,10732]
trailer [10739,10746]
===
match
---
operator: , [20414,20415]
operator: , [20428,20429]
===
match
---
atom_expr [3652,3670]
atom_expr [3666,3684]
===
match
---
operator: , [9012,9013]
operator: , [9026,9027]
===
match
---
name: executor [6589,6597]
name: executor [6603,6611]
===
match
---
arglist [2734,2783]
arglist [2748,2797]
===
match
---
expr_stmt [11611,11654]
expr_stmt [11625,11668]
===
match
---
name: pytest [17118,17124]
name: pytest [17132,17138]
===
match
---
operator: = [17926,17927]
operator: = [17940,17941]
===
match
---
name: executor [6494,6502]
name: executor [6508,6516]
===
match
---
name: FAILED [10726,10732]
name: FAILED [10740,10746]
===
match
---
name: value_tuple [9082,9093]
name: value_tuple [9096,9107]
===
match
---
simple_stmt [8760,8782]
simple_stmt [8774,8796]
===
match
---
atom_expr [7616,7650]
atom_expr [7630,7664]
===
match
---
string: "task_1" [13188,13196]
string: "task_1" [13202,13210]
===
match
---
trailer [13668,13670]
trailer [13682,13684]
===
match
---
name: test_app [2898,2906]
name: test_app [2912,2920]
===
match
---
operator: = [13898,13899]
operator: = [13912,13913]
===
match
---
trailer [14528,14579]
trailer [14542,14593]
===
match
---
simple_stmt [1912,1944]
simple_stmt [1926,1958]
===
match
---
operator: == [4412,4414]
operator: == [4426,4428]
===
match
---
argument [7204,7215]
argument [7218,7229]
===
match
---
arglist [14105,14142]
arglist [14119,14156]
===
match
---
operator: , [15950,15951]
operator: , [15964,15965]
===
match
---
expr_stmt [14257,14300]
expr_stmt [14271,14314]
===
match
---
name: test_retry_on_error_sending_task [7997,8029]
name: test_retry_on_error_sending_task [8011,8043]
===
match
---
operator: = [13987,13988]
operator: = [14001,14002]
===
match
---
string: 'fail' [7516,7522]
string: 'fail' [7530,7536]
===
match
---
atom_expr [13732,13773]
atom_expr [13746,13787]
===
match
---
trailer [7092,7107]
trailer [7106,7121]
===
match
---
name: command [12888,12895]
name: command [12902,12909]
===
match
---
trailer [8693,8706]
trailer [8707,8720]
===
match
---
name: self [13504,13508]
name: self [13518,13522]
===
match
---
arglist [11838,11872]
arglist [11852,11886]
===
match
---
decorated [13424,15035]
decorated [13438,15049]
===
match
---
param [3689,3693]
param [3703,3707]
===
match
---
name: kombu [1315,1320]
name: kombu [1329,1334]
===
match
---
name: celery_executor [4345,4360]
name: celery_executor [4359,4374]
===
match
---
trailer [19884,19886]
trailer [19898,19900]
===
match
---
testlist_comp [20509,20524]
testlist_comp [20523,20538]
===
match
---
simple_stmt [7667,7688]
simple_stmt [7681,7702]
===
match
---
import_as_names [1741,1790]
import_as_names [1755,1804]
===
match
---
name: timedelta [15174,15183]
name: timedelta [15188,15197]
===
match
---
name: task [8929,8933]
name: task [8943,8947]
===
match
---
string: 'task_default_queue' [4838,4858]
string: 'task_default_queue' [4852,4872]
===
match
---
trailer [5160,5182]
trailer [5174,5196]
===
match
---
name: execute_date [5800,5812]
name: execute_date [5814,5826]
===
match
---
simple_stmt [10045,10066]
simple_stmt [10059,10080]
===
match
---
expr_stmt [14152,14184]
expr_stmt [14166,14198]
===
match
---
name: assert_not_called [12653,12670]
name: assert_not_called [12667,12684]
===
match
---
simple_stmt [13292,13305]
simple_stmt [13306,13319]
===
match
---
name: heartbeat [10054,10063]
name: heartbeat [10068,10077]
===
match
---
atom_expr [11828,11873]
atom_expr [11842,11887]
===
match
---
name: mark [13432,13436]
name: mark [13446,13450]
===
match
---
argument [13816,13832]
argument [13830,13846]
===
match
---
operator: = [14594,14595]
operator: = [14608,14609]
===
match
---
simple_stmt [20483,20553]
simple_stmt [20497,20567]
===
match
---
name: _get_many_using_multiprocessing [11078,11109]
name: _get_many_using_multiprocessing [11092,11123]
===
match
---
simple_stmt [13230,13284]
simple_stmt [13244,13298]
===
match
---
name: assert_called_once_with [18053,18076]
name: assert_called_once_with [18067,18090]
===
match
---
name: assertLogs [8163,8173]
name: assertLogs [8177,8187]
===
match
---
atom_expr [9664,9699]
atom_expr [9678,9713]
===
match
---
operator: , [11980,11981]
operator: , [11994,11995]
===
match
---
assert_stmt [6473,6508]
assert_stmt [6487,6522]
===
match
---
assert_stmt [14918,14997]
assert_stmt [14932,15011]
===
match
---
name: task_publish_retries [8479,8499]
name: task_publish_retries [8493,8513]
===
match
---
name: execute_date [5998,6010]
name: execute_date [6012,6024]
===
match
---
simple_stmt [6518,6553]
simple_stmt [6532,6567]
===
match
---
arglist [18489,18508]
arglist [18503,18522]
===
match
---
operator: } [14392,14393]
operator: } [14406,14407]
===
match
---
with_stmt [13098,13221]
with_stmt [13112,13235]
===
match
---
comparison [19556,19684]
comparison [19570,19698]
===
match
---
expr_stmt [14048,14077]
expr_stmt [14062,14091]
===
match
---
expr_stmt [15568,15642]
expr_stmt [15582,15656]
===
match
---
name: _prepare_app [6852,6864]
name: _prepare_app [6866,6878]
===
match
---
comparison [9731,9762]
comparison [9745,9776]
===
match
---
trailer [17435,17481]
trailer [17449,17495]
===
match
---
trailer [10663,10676]
trailer [10677,10690]
===
match
---
decorator [11939,12076]
decorator [11953,12090]
===
match
---
parameters [16720,16726]
parameters [16734,16740]
===
match
---
name: __dict__ [16826,16834]
name: __dict__ [16840,16848]
===
match
---
name: task_publish_retries [5601,5621]
name: task_publish_retries [5615,5635]
===
match
---
operator: { [19116,19117]
operator: { [19130,19131]
===
match
---
trailer [8963,8967]
trailer [8977,8981]
===
match
---
atom_expr [13878,13931]
atom_expr [13892,13945]
===
match
---
argument [19930,19950]
argument [19944,19964]
===
match
---
name: when [7270,7274]
name: when [7284,7288]
===
match
---
dotted_name [1618,1645]
dotted_name [1632,1659]
===
match
---
assert_stmt [10560,10635]
assert_stmt [10574,10649]
===
match
---
operator: , [17823,17824]
operator: , [17837,17838]
===
match
---
atom_expr [17963,17980]
atom_expr [17977,17994]
===
match
---
dotted_name [18390,18413]
dotted_name [18404,18427]
===
match
---
atom [19522,19539]
atom [19536,19553]
===
match
---
trailer [18052,18076]
trailer [18066,18090]
===
match
---
atom [19077,19200]
atom [19091,19214]
===
match
---
param [3972,3982]
param [3986,3996]
===
match
---
string: "456" [19414,19419]
string: "456" [19428,19433]
===
match
---
atom_expr [20183,20202]
atom_expr [20197,20216]
===
match
---
suite [2204,2231]
suite [2218,2245]
===
match
---
trailer [7855,7862]
trailer [7869,7876]
===
match
---
operator: = [2803,2804]
operator: = [2817,2818]
===
match
---
string: 'DEBUG:airflow.executors.celery_executor.BulkStateFetcher:Fetched 2 state(s) for 2 task(s)' [19570,19661]
string: 'DEBUG:airflow.executors.celery_executor.BulkStateFetcher:Fetched 2 state(s) for 2 task(s)' [19584,19675]
===
match
---
operator: == [14333,14335]
operator: == [14347,14349]
===
match
---
operator: { [11010,11011]
operator: { [11024,11025]
===
match
---
trailer [5621,5626]
trailer [5635,5640]
===
match
---
operator: , [16509,16510]
operator: , [16523,16524]
===
match
---
operator: = [13322,13323]
operator: = [13336,13337]
===
match
---
name: broker_url [2362,2372]
name: broker_url [2376,2386]
===
match
---
name: event_buffer [6235,6247]
name: event_buffer [6249,6261]
===
match
---
expr_stmt [18906,18960]
expr_stmt [18920,18974]
===
match
---
name: cm [11219,11221]
name: cm [11233,11235]
===
match
---
trailer [19288,19461]
trailer [19302,19475]
===
match
---
operator: = [13945,13946]
operator: = [13959,13960]
===
match
---
operator: = [19358,19359]
operator: = [19372,19373]
===
match
---
operator: , [16156,16157]
operator: , [16170,16171]
===
match
---
atom_expr [10085,10120]
atom_expr [10099,10134]
===
match
---
simple_stmt [3739,3758]
simple_stmt [3753,3772]
===
match
---
atom [20534,20551]
atom [20548,20565]
===
match
---
string: 'fake_simple_ti' [7524,7540]
string: 'fake_simple_ti' [7538,7554]
===
match
---
name: fetcher [19272,19279]
name: fetcher [19286,19293]
===
match
---
funcdef [7993,10733]
funcdef [8007,10747]
===
match
---
name: queued_tasks [9328,9340]
name: queued_tasks [9342,9354]
===
match
---
name: airflow [1555,1562]
name: airflow [1569,1576]
===
match
---
name: task_2 [15687,15693]
name: task_2 [15701,15707]
===
match
---
operator: , [12061,12062]
operator: , [12075,12076]
===
match
---
testlist_comp [16144,16162]
testlist_comp [16158,16176]
===
match
---
atom [19141,19180]
atom [19155,19194]
===
match
---
atom [12887,12897]
atom [12901,12911]
===
match
---
name: execute_date [5014,5026]
name: execute_date [5028,5040]
===
match
---
name: key [5405,5408]
name: key [5419,5422]
===
match
---
assert_stmt [6324,6416]
assert_stmt [6338,6430]
===
match
---
simple_stmt [9053,9094]
simple_stmt [9067,9108]
===
match
---
trailer [11034,11036]
trailer [11048,11050]
===
match
---
trailer [20050,20149]
trailer [20064,20163]
===
match
---
atom_expr [5648,5692]
atom_expr [5662,5706]
===
match
---
name: QUEUED [6028,6034]
name: QUEUED [6042,6048]
===
match
---
name: baseoperator [1633,1645]
name: baseoperator [1647,1659]
===
match
---
name: heartbeat [10475,10484]
name: heartbeat [10489,10498]
===
match
---
atom_expr [7229,7243]
atom_expr [7243,7257]
===
match
---
operator: = [13714,13715]
operator: = [13728,13729]
===
match
---
name: task_1 [13965,13971]
name: task_1 [13979,13985]
===
match
---
name: get_many [17683,17691]
name: get_many [17697,17705]
===
match
---
import_name [787,804]
import_name [787,804]
===
match
---
atom_expr [9315,9341]
atom_expr [9329,9355]
===
match
---
name: url [18667,18670]
name: url [18681,18684]
===
match
---
name: mark [6633,6637]
name: mark [6647,6651]
===
match
---
operator: , [8156,8157]
operator: , [8170,8171]
===
match
---
name: executors [1517,1526]
name: executors [1531,1540]
===
match
---
name: broker_url [2591,2601]
name: broker_url [2605,2615]
===
match
---
assert_stmt [20483,20552]
assert_stmt [20497,20566]
===
match
---
atom_expr [5722,5743]
atom_expr [5736,5757]
===
match
---
arith_expr [15154,15195]
arith_expr [15168,15209]
===
match
---
operator: @ [11297,11298]
operator: @ [11311,11312]
===
match
---
suite [15408,15559]
suite [15422,15573]
===
match
---
name: test_should_support_kv_backend [17246,17276]
name: test_should_support_kv_backend [17260,17290]
===
match
---
name: ClassWithCustomAttributes [20292,20317]
name: ClassWithCustomAttributes [20306,20331]
===
match
---
operator: = [13254,13255]
operator: = [13268,13269]
===
match
---
atom_expr [16022,16040]
atom_expr [16036,16054]
===
match
---
operator: == [14695,14697]
operator: == [14709,14711]
===
match
---
name: mock [2723,2727]
name: mock [2737,2741]
===
match
---
atom_expr [12863,12882]
atom_expr [12877,12896]
===
match
---
operator: , [13261,13262]
operator: , [13275,13276]
===
match
---
operator: , [6579,6580]
operator: , [6593,6594]
===
match
---
name: key [9576,9579]
name: key [9590,9593]
===
match
---
name: configuration [1410,1423]
name: configuration [1424,1437]
===
match
---
name: pytest [12482,12488]
name: pytest [12496,12502]
===
match
---
name: expand [11954,11960]
name: expand [11968,11974]
===
match
---
trailer [10098,10119]
trailer [10112,10133]
===
match
---
atom_expr [14007,14031]
atom_expr [14021,14045]
===
match
---
string: "123" [17762,17767]
string: "123" [17776,17781]
===
match
---
name: backend [13437,13444]
name: backend [13451,13458]
===
match
---
with_stmt [10860,11135]
with_stmt [10874,11149]
===
match
---
arglist [17436,17480]
arglist [17450,17494]
===
match
---
operator: = [7316,7317]
operator: = [7330,7331]
===
match
---
operator: , [4030,4031]
operator: , [4044,4045]
===
match
---
name: dag_id [14616,14622]
name: dag_id [14630,14636]
===
match
---
string: 'fail' [10678,10684]
string: 'fail' [10692,10698]
===
match
---
atom_expr [11151,11229]
atom_expr [11165,11243]
===
match
---
name: BulkStateFetcher [17631,17647]
name: BulkStateFetcher [17645,17661]
===
match
---
name: now [8728,8731]
name: now [8742,8745]
===
match
---
simple_stmt [2362,2422]
simple_stmt [2376,2436]
===
match
---
string: "rabbitmq" [19753,19763]
string: "rabbitmq" [19767,19777]
===
match
---
atom_expr [4885,4916]
atom_expr [4899,4930]
===
match
---
number: 0 [10710,10711]
number: 0 [10724,10725]
===
match
---
simple_stmt [16796,16835]
simple_stmt [16810,16849]
===
match
---
comparison [6480,6508]
comparison [6494,6522]
===
match
---
name: self [18549,18553]
name: self [18563,18567]
===
match
---
arith_expr [13593,13630]
arith_expr [13607,13644]
===
match
---
decorated [2174,2231]
decorated [2188,2245]
===
match
---
fstring_expr [9575,9580]
fstring_expr [9589,9594]
===
match
---
atom_expr [8174,8193]
atom_expr [8188,8207]
===
match
---
name: call [11833,11837]
name: call [11847,11851]
===
match
---
name: other [16896,16901]
name: other [16910,16915]
===
match
---
simple_stmt [1272,1310]
simple_stmt [1286,1324]
===
match
---
name: list [5717,5721]
name: list [5731,5735]
===
match
---
operator: , [12044,12045]
operator: , [12058,12059]
===
match
---
number: 1 [13716,13717]
number: 1 [13730,13731]
===
match
---
operator: = [18624,18625]
operator: = [18638,18639]
===
match
---
name: test_celery_integration [3942,3965]
name: test_celery_integration [3956,3979]
===
match
---
simple_stmt [6069,6162]
simple_stmt [6083,6176]
===
match
---
dictorsetmaker [14944,14996]
dictorsetmaker [14958,15010]
===
match
---
name: heartbeat [11672,11681]
name: heartbeat [11686,11695]
===
match
---
name: executor [4397,4405]
name: executor [4411,4419]
===
match
---
argument [7450,7479]
argument [7464,7493]
===
match
---
simple_stmt [14588,14663]
simple_stmt [14602,14677]
===
match
---
atom [15820,15961]
atom [15834,15975]
===
match
---
comparison [16216,16252]
comparison [16230,16266]
===
match
---
testlist_comp [5771,5815]
testlist_comp [5785,5829]
===
match
---
operator: == [17981,17983]
operator: == [17995,17997]
===
match
---
trailer [12738,12747]
trailer [12752,12761]
===
match
---
operator: , [2636,2637]
operator: , [2650,2651]
===
match
---
atom_expr [18077,18085]
atom_expr [18091,18099]
===
match
---
trailer [10575,10598]
trailer [10589,10612]
===
match
---
name: call [11719,11723]
name: call [11733,11737]
===
match
---
operator: , [4916,4917]
operator: , [4930,4931]
===
match
---
atom_expr [8955,8969]
atom_expr [8969,8983]
===
match
---
name: contrib [979,986]
name: contrib [993,1000]
===
match
---
operator: , [11551,11552]
operator: , [11565,11566]
===
match
---
decorated [2282,3541]
decorated [2296,3555]
===
match
---
operator: @ [18468,18469]
operator: @ [18482,18483]
===
match
---
or_test [12820,12899]
or_test [12834,12913]
===
match
---
param [16857,16862]
param [16871,16876]
===
match
---
atom_expr [7277,7291]
atom_expr [7291,7305]
===
match
---
name: start_date [15461,15471]
name: start_date [15475,15485]
===
match
---
name: exceptions [1449,1459]
name: exceptions [1463,1473]
===
match
---
operator: @ [2174,2175]
operator: @ [2188,2189]
===
match
---
atom_expr [6589,6619]
atom_expr [6603,6633]
===
match
---
expr_stmt [14193,14222]
expr_stmt [14207,14236]
===
match
---
simple_stmt [15421,15484]
simple_stmt [15435,15498]
===
match
---
atom_expr [10045,10065]
atom_expr [10059,10079]
===
match
---
atom_expr [14048,14063]
atom_expr [14062,14077]
===
match
---
name: get [2114,2117]
name: get [2128,2131]
===
match
---
trailer [17428,17435]
trailer [17442,17449]
===
match
---
name: executor [10234,10242]
name: executor [10248,10256]
===
match
---
assert_stmt [16173,16200]
assert_stmt [16187,16214]
===
match
---
try_stmt [3394,3541]
try_stmt [3408,3555]
===
match
---
dotted_name [1090,1110]
dotted_name [1104,1124]
===
match
---
trailer [7237,7241]
trailer [7251,7255]
===
match
---
comparison [16180,16200]
comparison [16194,16214]
===
match
---
trailer [7203,7216]
trailer [7217,7230]
===
match
---
operator: = [2896,2897]
operator: = [2910,2911]
===
match
---
operator: == [19672,19674]
operator: == [19686,19688]
===
match
---
trailer [16318,16336]
trailer [16332,16350]
===
match
---
trailer [12568,12577]
trailer [12582,12591]
===
match
---
suite [2169,2280]
suite [2183,2294]
===
match
---
atom [5968,6014]
atom [5982,6028]
===
match
---
trailer [15610,15618]
trailer [15624,15632]
===
match
---
simple_stmt [14048,14078]
simple_stmt [14062,14092]
===
match
---
trailer [17422,17428]
trailer [17436,17442]
===
match
---
name: task_id [17754,17761]
name: task_id [17768,17775]
===
match
---
simple_stmt [1701,1791]
simple_stmt [1715,1805]
===
match
---
arglist [2118,2140]
arglist [2132,2154]
===
match
---
operator: = [14064,14065]
operator: = [14078,14079]
===
match
---
atom [12034,12061]
atom [12048,12075]
===
match
---
name: executor [13373,13381]
name: executor [13387,13395]
===
match
---
atom_expr [6149,6161]
atom_expr [6163,6175]
===
match
---
name: cm [10008,10010]
name: cm [10022,10024]
===
match
---
name: logfile [4487,4494]
name: logfile [4501,4508]
===
match
---
name: mark [3859,3863]
name: mark [3873,3877]
===
match
---
name: celery_executor [2447,2462]
name: celery_executor [2461,2476]
===
match
---
comparison [11155,11206]
comparison [11169,11220]
===
match
---
dotted_name [1844,1857]
dotted_name [1858,1871]
===
match
---
trailer [9400,9413]
trailer [9414,9427]
===
match
---
name: mark [19777,19781]
name: mark [19791,19795]
===
match
---
suite [2357,3541]
suite [2371,3555]
===
match
---
name: mark [17204,17208]
name: mark [17218,17222]
===
match
---
name: conf [2109,2113]
name: conf [2123,2127]
===
match
---
name: patch [11458,11463]
name: patch [11472,11477]
===
match
---
expr_stmt [14232,14248]
expr_stmt [14246,14262]
===
match
---
dotted_name [1169,1193]
dotted_name [1183,1207]
===
match
---
name: dict [10506,10510]
name: dict [10520,10524]
===
match
---
dotted_name [1402,1423]
dotted_name [1416,1437]
===
match
---
import_from [1217,1271]
import_from [1231,1285]
===
match
---
simple_stmt [9806,9841]
simple_stmt [9820,9855]
===
match
---
name: dag_id [14533,14539]
name: dag_id [14547,14553]
===
match
---
trailer [17682,17691]
trailer [17696,17705]
===
match
---
name: celery [1277,1283]
name: celery [1291,1297]
===
match
---
name: unittest [3568,3576]
name: unittest [3582,3590]
===
match
---
operator: == [6586,6588]
operator: == [6600,6602]
===
match
---
name: clear_db_runs [3628,3641]
name: clear_db_runs [3642,3655]
===
match
---
atom_expr [7077,7109]
atom_expr [7091,7123]
===
match
---
operator: = [14236,14237]
operator: = [14250,14251]
===
match
---
string: 'tasks' [12046,12053]
string: 'tasks' [12060,12067]
===
match
---
comparison [14678,14712]
comparison [14692,14726]
===
match
---
assert_stmt [15006,15034]
assert_stmt [15020,15048]
===
match
---
operator: == [7847,7849]
operator: == [7861,7863]
===
match
---
trailer [13080,13088]
trailer [13094,13102]
===
match
---
name: DAG [8690,8693]
name: DAG [8704,8707]
===
match
---
trailer [12552,12568]
trailer [12566,12582]
===
match
---
trailer [7624,7645]
trailer [7638,7659]
===
match
---
name: utcnow [15163,15169]
name: utcnow [15177,15183]
===
match
---
operator: , [6137,6138]
operator: , [6151,6152]
===
match
---
expr_stmt [5512,5571]
expr_stmt [5526,5585]
===
match
---
name: cm [9587,9589]
name: cm [9601,9603]
===
match
---
operator: , [19532,19533]
operator: , [19546,19547]
===
match
---
number: 3 [9709,9710]
number: 3 [9723,9724]
===
match
---
name: FAILED [16121,16127]
name: FAILED [16135,16141]
===
match
---
name: pytest [3814,3820]
name: pytest [3828,3834]
===
match
---
operator: , [11745,11746]
operator: , [11759,11760]
===
match
---
operator: , [12121,12122]
operator: , [12135,12136]
===
match
---
operator: = [13187,13188]
operator: = [13201,13202]
===
match
---
operator: = [13919,13920]
operator: = [13933,13934]
===
match
---
name: executor [7667,7675]
name: executor [7681,7689]
===
match
---
operator: , [10684,10685]
operator: , [10698,10699]
===
match
---
string: 'fail' [9006,9012]
string: 'fail' [9020,9026]
===
match
---
name: mock_subproc [12820,12832]
name: mock_subproc [12834,12846]
===
match
---
trailer [5721,5744]
trailer [5735,5758]
===
match
---
name: executor [14733,14741]
name: executor [14747,14755]
===
match
---
name: mock [19099,19103]
name: mock [19113,19117]
===
match
---
name: utcnow [13021,13027]
name: utcnow [13035,13041]
===
match
---
operator: @ [18315,18316]
operator: @ [18329,18330]
===
match
---
suite [18569,19685]
suite [18583,19699]
===
match
---
operator: -> [3608,3610]
operator: -> [3622,3624]
===
match
---
comparison [6331,6416]
comparison [6345,6430]
===
match
---
name: _prepare_app [8142,8154]
name: _prepare_app [8156,8168]
===
match
---
testlist_comp [4089,4109]
testlist_comp [4103,4123]
===
match
---
import_as_names [1467,1503]
import_as_names [1481,1517]
===
match
---
assert_stmt [5710,5900]
assert_stmt [5724,5914]
===
match
---
assert_stmt [7696,7769]
assert_stmt [7710,7783]
===
match
---
name: heartbeat [7676,7685]
name: heartbeat [7690,7699]
===
match
---
trailer [14989,14996]
trailer [15003,15010]
===
match
---
string: 'fake_simple_ti' [10686,10702]
string: 'fake_simple_ti' [10700,10716]
===
match
---
name: test_execute [2669,2681]
name: test_execute [2683,2695]
===
match
---
name: BaseOperator [15430,15442]
name: BaseOperator [15444,15456]
===
match
---
string: '231' [14034,14039]
string: '231' [14048,14053]
===
match
---
trailer [15928,15950]
trailer [15942,15964]
===
match
---
name: task [7444,7448]
name: task [7458,7462]
===
match
---
dotted_name [3764,3784]
dotted_name [3778,3798]
===
match
---
trailer [12670,12672]
trailer [12684,12686]
===
match
---
atom [20500,20552]
atom [20514,20566]
===
match
---
atom_expr [17675,17864]
atom_expr [17689,17878]
===
match
---
simple_stmt [8463,8506]
simple_stmt [8477,8520]
===
match
---
operator: , [12031,12032]
operator: , [12045,12046]
===
match
---
trailer [9589,9596]
trailer [9603,9610]
===
match
---
name: self [3689,3693]
name: self [3703,3707]
===
match
---
parameters [16618,16624]
parameters [16632,16638]
===
match
---
testlist_comp [12887,12898]
testlist_comp [12901,12912]
===
match
---
return_stmt [16634,16702]
return_stmt [16648,16716]
===
match
---
simple_stmt [19263,19462]
simple_stmt [19277,19476]
===
match
---
trailer [6577,6585]
trailer [6591,6599]
===
match
---
operator: = [8765,8766]
operator: = [8779,8780]
===
match
---
trailer [14732,14764]
trailer [14746,14778]
===
match
---
string: "mysql" [18489,18496]
string: "mysql" [18503,18510]
===
match
---
comparison [7703,7734]
comparison [7717,7748]
===
match
---
with_stmt [4460,6210]
with_stmt [4474,6224]
===
match
---
name: queued_tasks [10170,10182]
name: queued_tasks [10184,10196]
===
match
---
dictorsetmaker [2577,2601]
dictorsetmaker [2591,2615]
===
match
---
operator: , [8200,8201]
operator: , [8214,8215]
===
match
---
atom [7318,7496]
atom [7332,7510]
===
match
---
decorator [17196,17238]
decorator [17210,17252]
===
match
---
trailer [11170,11198]
trailer [11184,11212]
===
match
---
atom_expr [8470,8499]
atom_expr [8484,8513]
===
match
---
name: MagicMock [19341,19350]
name: MagicMock [19355,19364]
===
match
---
name: os [2051,2053]
name: os [2065,2067]
===
match
---
string: 'CELERY_BROKER_URLS' [2062,2082]
string: 'CELERY_BROKER_URLS' [2076,2096]
===
match
---
atom_expr [15604,15618]
atom_expr [15618,15632]
===
match
---
comparison [14728,14909]
comparison [14742,14923]
===
match
---
operator: , [18665,18666]
operator: , [18679,18680]
===
match
---
trailer [8162,8173]
trailer [8176,8187]
===
match
---
atom [19488,19540]
atom [19502,19554]
===
match
---
comparison [6525,6552]
comparison [6539,6566]
===
match
---
operator: = [11620,11621]
operator: = [11634,11635]
===
match
---
atom_expr [16884,16902]
atom_expr [16898,16916]
===
match
---
name: test_execute [2869,2881]
name: test_execute [2883,2895]
===
match
---
operator: , [7522,7523]
operator: , [7536,7537]
===
match
---
name: __name__ [16670,16678]
name: __name__ [16684,16692]
===
match
---
name: now [8776,8779]
name: now [8790,8793]
===
match
---
atom_expr [16685,16698]
atom_expr [16699,16712]
===
match
---
atom_expr [13531,13548]
atom_expr [13545,13562]
===
match
---
operator: - [15295,15296]
operator: - [15309,15310]
===
match
---
name: broker_url [4272,4282]
name: broker_url [4286,4296]
===
match
---
operator: , [4686,4687]
operator: , [4700,4701]
===
match
---
trailer [10713,10716]
trailer [10727,10730]
===
match
---
name: utils [1887,1892]
name: utils [1901,1906]
===
match
---
name: simple_ti [5561,5570]
name: simple_ti [5575,5584]
===
match
---
trailer [9739,9762]
trailer [9753,9776]
===
match
---
operator: = [8700,8701]
operator: = [8714,8715]
===
match
---
name: broker_url [3972,3982]
name: broker_url [3986,3996]
===
match
---
expr_stmt [19006,19200]
expr_stmt [19020,19214]
===
match
---
name: days [13623,13627]
name: days [13637,13641]
===
match
---
operator: , [11862,11863]
operator: , [11876,11877]
===
match
---
atom_expr [18583,18597]
atom_expr [18597,18611]
===
match
---
operator: , [5408,5409]
operator: , [5422,5423]
===
match
---
name: task_publish_retries [10099,10119]
name: task_publish_retries [10113,10133]
===
match
---
sync_comp_for [11207,11228]
sync_comp_for [11221,11242]
===
match
---
name: mark [3900,3904]
name: mark [3914,3918]
===
match
---
arglist [13445,13464]
arglist [13459,13478]
===
match
---
name: executor [8407,8415]
name: executor [8421,8429]
===
match
---
simple_stmt [12707,12748]
simple_stmt [12721,12762]
===
match
---
string: 'backend' [17457,17466]
string: 'backend' [17471,17480]
===
match
---
atom [15987,16041]
atom [16001,16055]
===
match
---
atom_expr [6302,6315]
atom_expr [6316,6329]
===
match
---
number: 0 [10714,10715]
number: 0 [10728,10729]
===
match
---
argument [19351,19364]
argument [19365,19378]
===
match
---
simple_stmt [3652,3671]
simple_stmt [3666,3685]
===
match
---
string: '456' [18140,18145]
string: '456' [18154,18159]
===
match
---
name: keys [5737,5741]
name: keys [5751,5755]
===
match
---
atom_expr [4465,4523]
atom_expr [4479,4537]
===
match
---
name: mock [11805,11809]
name: mock [11819,11823]
===
match
---
parameters [2247,2253]
parameters [2261,2267]
===
match
---
name: test_app [2775,2783]
name: test_app [2789,2797]
===
match
---
operator: == [18110,18112]
operator: == [18124,18126]
===
match
---
operator: = [13049,13050]
operator: = [13063,13064]
===
match
---
atom [16198,16200]
atom [16212,16214]
===
match
---
name: datetime [7229,7237]
name: datetime [7243,7251]
===
match
---
name: all [19058,19061]
name: all [19072,19075]
===
match
---
string: "rabbitmq" [6688,6698]
string: "rabbitmq" [6702,6712]
===
match
---
trailer [4498,4505]
trailer [4512,4519]
===
match
---
name: unittest [845,853]
name: unittest [859,867]
===
match
---
expr_stmt [14439,14495]
expr_stmt [14453,14509]
===
match
---
simple_stmt [11692,11885]
simple_stmt [11706,11899]
===
match
---
simple_stmt [9624,9645]
simple_stmt [9638,9659]
===
match
---
operator: { [10417,10418]
operator: { [10431,10432]
===
match
---
import_name [805,816]
import_name [805,816]
===
match
---
name: task [5437,5441]
name: task [5451,5455]
===
match
---
string: 'fake_simple_ti' [7816,7832]
string: 'fake_simple_ti' [7830,7846]
===
match
---
string: "Task should remain in queue" [10185,10214]
string: "Task should remain in queue" [10199,10228]
===
match
---
name: app [18737,18740]
name: app [18751,18754]
===
match
---
atom_expr [15787,15817]
atom_expr [15801,15831]
===
match
---
name: __eq__ [16767,16773]
name: __eq__ [16781,16787]
===
match
---
name: Exception [2219,2228]
name: Exception [2233,2242]
===
match
---
expr_stmt [13158,13220]
expr_stmt [13172,13234]
===
match
---
suite [3398,3426]
suite [3412,3440]
===
match
---
simple_stmt [11144,11230]
simple_stmt [11158,11244]
===
match
---
atom [18121,18138]
atom [18135,18152]
===
match
---
raise_stmt [4214,4244]
raise_stmt [4228,4258]
===
match
---
trailer [8206,8212]
trailer [8220,8226]
===
match
---
simple_stmt [2263,2280]
simple_stmt [2277,2294]
===
match
---
name: event_buffer [10664,10676]
name: event_buffer [10678,10690]
===
match
---
atom [11995,12031]
atom [12009,12045]
===
match
---
decorator [2282,2309]
decorator [2296,2323]
===
match
---
atom_expr [10090,10119]
atom_expr [10104,10133]
===
match
---
name: stdout [4499,4505]
name: stdout [4513,4519]
===
match
---
atom [16143,16163]
atom [16157,16177]
===
match
---
operator: , [12855,12856]
operator: , [12869,12870]
===
match
---
atom_expr [6852,6894]
atom_expr [6866,6908]
===
match
---
name: key_2 [14847,14852]
name: key_2 [14861,14866]
===
match
---
name: cm [11281,11283]
name: cm [11295,11297]
===
match
---
operator: , [10598,10599]
operator: , [10612,10613]
===
match
---
simple_stmt [17336,17401]
simple_stmt [17350,17415]
===
match
---
suite [3984,6620]
suite [3998,6634]
===
match
---
dictorsetmaker [19142,19179]
dictorsetmaker [19156,19193]
===
match
---
name: mark [15048,15052]
name: mark [15062,15066]
===
match
---
trailer [8631,8747]
trailer [8645,8761]
===
match
---
name: pytest [12906,12912]
name: pytest [12920,12926]
===
match
---
with_stmt [12477,12578]
with_stmt [12491,12592]
===
match
---
operator: , [15685,15686]
operator: , [15699,15700]
===
match
---
decorated [16956,18310]
decorated [16970,18324]
===
match
---
name: level [18855,18860]
name: level [18869,18874]
===
match
---
dictorsetmaker [16107,16163]
dictorsetmaker [16121,16177]
===
match
---
atom [18181,18296]
atom [18195,18310]
===
match
---
simple_stmt [15735,15779]
simple_stmt [15749,15793]
===
match
---
number: 0 [7840,7841]
number: 0 [7854,7855]
===
match
---
assert_stmt [12813,12899]
assert_stmt [12827,12913]
===
match
---
name: property [2175,2183]
name: property [2189,2197]
===
match
---
arglist [15592,15641]
arglist [15606,15655]
===
match
---
atom_expr [4345,4377]
atom_expr [4359,4391]
===
match
---
simple_stmt [9432,9611]
simple_stmt [9446,9625]
===
match
---
name: backend [2907,2914]
name: backend [2921,2928]
===
match
---
name: contrib [1229,1236]
name: contrib [1243,1250]
===
match
---
number: 0 [5879,5880]
number: 0 [5893,5894]
===
match
---
operator: = [2336,2337]
operator: = [2350,2351]
===
match
---
string: 'fake_simple_ti' [5847,5863]
string: 'fake_simple_ti' [5861,5877]
===
match
---
name: self [16774,16778]
name: self [16788,16792]
===
match
---
simple_stmt [20561,20697]
simple_stmt [20575,20711]
===
match
---
name: adopted_task_timeouts [15796,15817]
name: adopted_task_timeouts [15810,15831]
===
match
---
name: self [18768,18772]
name: self [18782,18786]
===
match
---
name: mock_backend [17336,17348]
name: mock_backend [17350,17362]
===
match
---
string: "test_try_adopt_task_instances_none" [13736,13772]
string: "test_try_adopt_task_instances_none" [13750,13786]
===
match
---
simple_stmt [2426,2491]
simple_stmt [2440,2505]
===
match
---
name: key [7646,7649]
name: key [7660,7663]
===
match
---
name: ANY [11752,11755]
name: ANY [11766,11769]
===
match
---
operator: { [16680,16681]
operator: { [16694,16695]
===
match
---
decorator [18315,18385]
decorator [18329,18399]
===
match
---
name: fake_execute_command [6873,6893]
name: fake_execute_command [6887,6907]
===
match
---
atom_expr [16303,16336]
atom_expr [16317,16350]
===
match
---
operator: , [2773,2774]
operator: , [2787,2788]
===
match
---
simple_stmt [18611,18685]
simple_stmt [18625,18699]
===
match
---
name: celery_executor [5208,5223]
name: celery_executor [5222,5237]
===
match
---
name: task [7122,7126]
name: task [7136,7140]
===
match
---
name: config_source [2638,2651]
name: config_source [2652,2665]
===
match
---
string: "PENDING" [20535,20544]
string: "PENDING" [20549,20558]
===
match
---
decorator [6625,6659]
decorator [6639,6673]
===
match
---
name: airflow [1441,1448]
name: airflow [1455,1462]
===
match
---
name: test_check_for_stalled_adopted_tasks [15090,15126]
name: test_check_for_stalled_adopted_tasks [15104,15140]
===
match
---
number: 2 [15252,15253]
number: 2 [15266,15267]
===
match
---
name: executor [10466,10474]
name: executor [10480,10488]
===
match
---
string: "task_2" [13899,13907]
string: "task_2" [13913,13921]
===
match
---
name: base [1106,1110]
name: base [1120,1124]
===
match
---
string: 'fake_simple_ti' [5782,5798]
string: 'fake_simple_ti' [5796,5812]
===
match
---
assert_stmt [5917,6052]
assert_stmt [5931,6066]
===
match
---
dotted_name [6664,6687]
dotted_name [6678,6701]
===
match
---
expr_stmt [19218,19246]
expr_stmt [19232,19260]
===
match
---
atom_expr [3568,3585]
atom_expr [3582,3599]
===
match
---
suite [3442,3541]
suite [3456,3555]
===
match
---
name: key_1 [15834,15839]
name: key_1 [15848,15853]
===
match
---
trailer [12652,12670]
trailer [12666,12684]
===
match
---
trailer [14417,14423]
trailer [14431,14437]
===
match
---
number: 1 [7653,7654]
number: 1 [7667,7668]
===
match
---
simple_stmt [1839,1874]
simple_stmt [1853,1888]
===
match
---
operator: != [4178,4180]
operator: != [4192,4194]
===
match
---
atom_expr [4397,4411]
atom_expr [4411,4425]
===
match
---
trailer [6352,6397]
trailer [6366,6411]
===
match
---
name: timezone [15154,15162]
name: timezone [15168,15176]
===
match
---
funcdef [6750,7863]
funcdef [6764,7877]
===
match
---
name: fetcher [20228,20235]
name: fetcher [20242,20249]
===
match
---
assert_stmt [8463,8505]
assert_stmt [8477,8519]
===
match
---
operator: , [16127,16128]
operator: , [16141,16142]
===
match
---
operator: , [7814,7815]
operator: , [7828,7829]
===
match
---
string: "mysql" [17217,17224]
string: "mysql" [17231,17238]
===
match
---
name: patch [17423,17428]
name: patch [17437,17442]
===
match
---
operator: , [14622,14623]
operator: , [14636,14637]
===
match
---
expr_stmt [13580,13630]
expr_stmt [13594,13644]
===
match
---
comparison [12863,12899]
comparison [12877,12913]
===
match
---
operator: , [16855,16856]
operator: , [16869,16870]
===
match
---
name: celery [1169,1175]
name: celery [1183,1189]
===
match
---
simple_stmt [13941,13999]
simple_stmt [13955,14013]
===
match
---
name: test_utils [1923,1933]
name: test_utils [1937,1947]
===
match
---
operator: , [18496,18497]
operator: , [18510,18511]
===
match
---
strings [10299,10425]
strings [10313,10439]
===
match
---
name: ti2 [14086,14089]
name: ti2 [14100,14103]
===
match
---
atom_expr [14925,14939]
atom_expr [14939,14953]
===
match
---
name: tis [13415,13418]
name: tis [13429,13432]
===
match
---
atom_expr [17351,17400]
atom_expr [17365,17414]
===
match
---
name: patch_app [2711,2720]
name: patch_app [2725,2734]
===
match
---
name: self [10881,10885]
name: self [10895,10899]
===
match
---
string: 'fake_simple_ti' [4996,5012]
string: 'fake_simple_ti' [5010,5026]
===
match
---
atom_expr [9624,9644]
atom_expr [9638,9658]
===
match
---
name: self [20035,20039]
name: self [20049,20053]
===
match
---
simple_stmt [3411,3426]
simple_stmt [3425,3440]
===
match
---
trailer [6247,6295]
trailer [6261,6309]
===
match
---
name: celery_executor [8174,8189]
name: celery_executor [8188,8203]
===
match
---
name: dag [15404,15407]
name: dag [15418,15421]
===
match
---
name: output [20690,20696]
name: output [20704,20710]
===
match
---
name: executor [7066,7074]
name: executor [7080,7088]
===
match
---
string: "fail" [4237,4243]
string: "fail" [4251,4257]
===
match
---
name: exec_date [14640,14649]
name: exec_date [14654,14663]
===
match
---
name: FAILED [16150,16156]
name: FAILED [16164,16170]
===
match
---
trailer [14547,14555]
trailer [14561,14569]
===
match
---
operator: = [15275,15276]
operator: = [15289,15290]
===
match
---
atom_expr [6226,6298]
atom_expr [6240,6312]
===
match
---
simple_stmt [13639,13694]
simple_stmt [13653,13708]
===
match
---
funcdef [2309,3541]
funcdef [2323,3555]
===
match
---
suite [17604,17865]
suite [17618,17879]
===
match
---
number: 1 [15341,15342]
number: 1 [15355,15356]
===
match
---
operator: , [18157,18158]
operator: , [18171,18172]
===
match
---
assert_stmt [10227,10261]
assert_stmt [10241,10275]
===
match
---
trailer [2930,2956]
trailer [2944,2970]
===
match
---
atom_expr [13613,13630]
atom_expr [13627,13644]
===
match
---
expr_stmt [14007,14039]
expr_stmt [14021,14053]
===
match
---
operator: , [15701,15702]
operator: , [15715,15716]
===
match
---
name: start [4439,4444]
name: start [4453,4458]
===
match
---
name: key [10125,10128]
name: key [10139,10142]
===
match
---
name: TaskInstanceKey [14596,14611]
name: TaskInstanceKey [14610,14625]
===
match
---
string: "task_1" [13824,13832]
string: "task_1" [13838,13846]
===
match
---
import_from [1912,1943]
import_from [1926,1957]
===
match
---
name: key [10418,10421]
name: key [10432,10435]
===
match
---
name: utcnow [15286,15292]
name: utcnow [15300,15306]
===
match
---
name: value_tuple [8794,8805]
name: value_tuple [8808,8819]
===
match
---
decorator [18389,18423]
decorator [18403,18437]
===
match
---
name: task_id [15443,15450]
name: task_id [15457,15464]
===
match
---
simple_stmt [965,1045]
simple_stmt [979,1059]
===
match
---
operator: , [19161,19162]
operator: , [19175,19176]
===
match
---
name: assertLogs [17488,17498]
name: assertLogs [17502,17512]
===
match
---
string: "DEBUG" [18861,18868]
string: "DEBUG" [18875,18882]
===
match
---
import_from [1874,1911]
import_from [1888,1925]
===
match
---
operator: , [12933,12934]
operator: , [12947,12948]
===
match
---
trailer [14196,14208]
trailer [14210,14222]
===
match
---
string: "INFO:airflow.executors.celery_executor.CeleryExecutor:" [9878,9934]
string: "INFO:airflow.executors.celery_executor.CeleryExecutor:" [9892,9948]
===
match
---
name: patch [11303,11308]
name: patch [11317,11322]
===
match
---
decorators [11297,11511]
decorators [11311,11525]
===
match
---
operator: { [14698,14699]
operator: { [14712,14713]
===
match
---
name: executor [15735,15743]
name: executor [15749,15757]
===
match
---
name: mock_session [19006,19018]
name: mock_session [19020,19032]
===
match
---
number: 0 [6578,6579]
number: 0 [6592,6593]
===
match
---
decorator [17155,17192]
decorator [17169,17206]
===
match
---
trailer [8212,8219]
trailer [8226,8233]
===
match
---
operator: { [4415,4416]
operator: { [4429,4430]
===
match
---
string: "Task should remain in queue" [9343,9372]
string: "Task should remain in queue" [9357,9386]
===
match
---
trailer [4444,4446]
trailer [4458,4460]
===
match
---
atom [10281,10452]
atom [10295,10466]
===
match
---
with_item [10881,10923]
with_item [10895,10937]
===
match
---
simple_stmt [18174,18310]
simple_stmt [18188,18324]
===
match
---
name: integration [3826,3837]
name: integration [3840,3851]
===
match
---
name: fetcher [17621,17628]
name: fetcher [17635,17642]
===
match
---
name: MagicMock [17799,17808]
name: MagicMock [17813,17822]
===
match
---
simple_stmt [1613,1666]
simple_stmt [1627,1680]
===
match
---
name: try_adopt_task_instances [14466,14490]
name: try_adopt_task_instances [14480,14504]
===
match
---
trailer [10978,10980]
trailer [10992,10994]
===
match
---
expr_stmt [9053,9093]
expr_stmt [9067,9107]
===
match
---
trailer [2906,2914]
trailer [2920,2928]
===
match
---
name: ResultSession [18934,18947]
name: ResultSession [18948,18961]
===
match
---
trailer [16063,16065]
trailer [16077,16079]
===
match
---
atom_expr [7200,7216]
atom_expr [7214,7230]
===
match
---
trailer [18736,18740]
trailer [18750,18754]
===
match
---
decorators [6625,6746]
decorators [6639,6760]
===
match
---
name: task_id [8649,8656]
name: task_id [8663,8670]
===
match
---
operator: , [17084,17085]
operator: , [17098,17099]
===
match
---
trailer [15693,15701]
trailer [15707,15715]
===
match
---
atom_expr [14268,14300]
atom_expr [14282,14314]
===
match
---
operator: @ [3851,3852]
operator: @ [3865,3866]
===
match
---
name: command [12848,12855]
name: command [12862,12869]
===
match
---
simple_stmt [8518,8599]
simple_stmt [8532,8613]
===
match
---
name: sys [4495,4498]
name: sys [4509,4512]
===
match
---
name: models [1714,1720]
name: models [1728,1734]
===
match
---
operator: - [15235,15236]
operator: - [15249,15250]
===
match
---
argument [14118,14142]
argument [14132,14156]
===
match
---
trailer [2478,2490]
trailer [2492,2504]
===
match
---
testlist_comp [5839,5880]
testlist_comp [5853,5894]
===
match
---
expr_stmt [11692,11884]
expr_stmt [11706,11898]
===
match
---
atom_expr [11714,11756]
atom_expr [11728,11770]
===
match
---
operator: = [19226,19227]
operator: = [19240,19241]
===
match
---
name: when [10704,10708]
name: when [10718,10722]
===
match
---
number: 0 [6398,6399]
number: 0 [6412,6413]
===
match
---
number: 4 [10130,10131]
number: 4 [10144,10145]
===
match
---
atom_expr [19915,19951]
atom_expr [19929,19965]
===
match
---
trailer [8727,8731]
trailer [8741,8745]
===
match
---
param [10844,10848]
param [10858,10862]
===
match
---
name: unittest [900,908]
name: unittest [914,922]
===
match
---
trailer [4271,4313]
trailer [4285,4327]
===
match
---
name: State [6149,6154]
name: State [6163,6168]
===
match
---
expr_stmt [17336,17400]
expr_stmt [17350,17414]
===
match
---
name: execute [4284,4291]
name: execute [4298,4305]
===
match
---
with_item [12237,12345]
with_item [12251,12359]
===
match
---
trailer [20235,20244]
trailer [20249,20258]
===
match
---
trailer [6339,6352]
trailer [6353,6366]
===
match
---
operator: = [13651,13652]
operator: = [13665,13666]
===
match
---
assert_stmt [9432,9610]
assert_stmt [9446,9624]
===
match
---
funcdef [3592,3671]
funcdef [3606,3685]
===
match
---
string: 'fake_simple_ti' [6362,6378]
string: 'fake_simple_ti' [6376,6392]
===
match
---
string: '123' [20501,20506]
string: '123' [20515,20520]
===
match
---
string: 'command' [8826,8835]
string: 'command' [8840,8849]
===
match
---
funcdef [16763,16835]
funcdef [16777,16849]
===
match
---
operator: == [16337,16339]
operator: == [16351,16353]
===
match
---
name: task_2 [13869,13875]
name: task_2 [13883,13889]
===
match
---
suite [2016,2096]
suite [2030,2110]
===
match
---
operator: , [18131,18132]
operator: , [18145,18146]
===
match
---
name: timezone [13593,13601]
name: timezone [13607,13615]
===
match
---
trailer [2397,2421]
trailer [2411,2435]
===
match
---
name: start_date [8708,8718]
name: start_date [8722,8732]
===
match
---
operator: = [18919,18920]
operator: = [18933,18934]
===
match
---
operator: = [15450,15451]
operator: = [15464,15465]
===
match
---
suite [1973,2144]
suite [1987,2158]
===
match
---
funcdef [18514,19685]
funcdef [18528,19699]
===
match
---
name: celery_executor [4885,4900]
name: celery_executor [4899,4914]
===
match
---
name: mark [18435,18439]
name: mark [18449,18453]
===
match
---
trailer [10474,10484]
trailer [10488,10498]
===
match
---
atom_expr [7708,7734]
atom_expr [7722,7748]
===
match
---
expr_stmt [2888,2914]
expr_stmt [2902,2928]
===
match
---
name: task_publish_retries [9257,9277]
name: task_publish_retries [9271,9291]
===
match
---
argument [19406,19419]
argument [19420,19433]
===
match
---
operator: } [15960,15961]
operator: } [15974,15975]
===
match
---
name: heartbeat [9212,9221]
name: heartbeat [9226,9235]
===
match
---
operator: = [20338,20339]
operator: = [20352,20353]
===
match
---
simple_stmt [19900,19952]
simple_stmt [19914,19966]
===
match
---
param [16505,16510]
param [16519,16524]
===
match
---
trailer [19044,19057]
trailer [19058,19071]
===
match
---
name: timezone [13653,13661]
name: timezone [13667,13675]
===
match
---
string: "airflow.executors.celery_executor.BulkStateFetcher" [20068,20120]
string: "airflow.executors.celery_executor.BulkStateFetcher" [20082,20134]
===
match
---
operator: , [16593,16594]
operator: , [16607,16608]
===
match
---
atom [5770,5816]
atom [5784,5830]
===
match
---
atom_expr [10948,10980]
atom_expr [10962,10994]
===
match
---
atom_expr [16216,16246]
atom_expr [16230,16260]
===
match
---
name: task_1 [15421,15427]
name: task_1 [15435,15441]
===
match
---
simple_stmt [1666,1701]
simple_stmt [1680,1715]
===
match
---
name: mock_mget [17928,17937]
name: mock_mget [17942,17951]
===
match
---
comparison [5946,6034]
comparison [5960,6048]
===
match
---
atom [4011,4064]
atom [4025,4078]
===
match
---
argument [11249,11290]
argument [11263,11304]
===
match
---
name: tasks [6459,6464]
name: tasks [6473,6478]
===
match
---
name: call_args [12873,12882]
name: call_args [12887,12896]
===
match
---
dotted_name [1555,1588]
dotted_name [1569,1602]
===
match
---
number: 0 [6296,6297]
number: 0 [6310,6311]
===
match
---
argument [13683,13692]
argument [13697,13706]
===
match
---
decorator [7868,7902]
decorator [7882,7916]
===
match
---
simple_stmt [2888,2915]
simple_stmt [2902,2929]
===
match
---
trailer [14010,14031]
trailer [14024,14045]
===
match
---
trailer [13959,13998]
trailer [13973,14012]
===
match
---
trailer [5730,5736]
trailer [5744,5750]
===
match
---
simple_stmt [11050,11135]
simple_stmt [11064,11149]
===
match
---
decorator [11452,11511]
decorator [11466,11525]
===
match
---
string: "celery.backends.base.BaseKeyValueStoreBackend.mget" [16977,17029]
string: "celery.backends.base.BaseKeyValueStoreBackend.mget" [16991,17043]
===
match
---
name: executor [6525,6533]
name: executor [6539,6547]
===
match
---
number: 40 [15192,15194]
number: 40 [15206,15208]
===
match
---
argument [8694,8705]
argument [8708,8719]
===
match
---
trailer [11774,11779]
trailer [11788,11793]
===
match
---
string: 'fail' [6354,6360]
string: 'fail' [6368,6374]
===
match
---
with_item [17483,17603]
with_item [17497,17617]
===
match
---
operator: = [13085,13086]
operator: = [13099,13100]
===
match
---
simple_stmt [15263,15319]
simple_stmt [15277,15333]
===
match
---
argument [14105,14116]
argument [14119,14130]
===
match
---
operator: , [11803,11804]
operator: , [11817,11818]
===
match
---
fstring_expr [9996,10001]
fstring_expr [10010,10015]
===
match
---
operator: , [20120,20121]
operator: , [20134,20135]
===
match
---
name: MagicMock [17744,17753]
name: MagicMock [17758,17767]
===
match
---
simple_stmt [4430,4447]
simple_stmt [4444,4461]
===
match
---
name: start_date [13209,13219]
name: start_date [13223,13233]
===
match
---
name: TestCase [16941,16949]
name: TestCase [16955,16963]
===
match
---
trailer [12872,12882]
trailer [12886,12896]
===
match
---
string: "231" [16007,16012]
string: "231" [16021,16026]
===
match
---
name: parameterized [1382,1395]
name: parameterized [1396,1409]
===
match
---
name: _prepare_app [17308,17320]
name: _prepare_app [17322,17334]
===
match
---
argument [4478,4485]
argument [4492,4499]
===
match
---
simple_stmt [9724,9794]
simple_stmt [9738,9808]
===
match
---
param [2248,2252]
param [2262,2266]
===
match
---
atom_expr [9587,9596]
atom_expr [9601,9610]
===
match
---
dotted_name [11298,11308]
dotted_name [11312,11322]
===
match
---
fstring_string: [Try 2 of 3] Task Timeout Error for Task: ( [9953,9996]
fstring_string: [Try 2 of 3] Task Timeout Error for Task: ( [9967,10010]
===
match
---
atom_expr [6331,6400]
atom_expr [6345,6414]
===
match
---
simple_stmt [2669,2707]
simple_stmt [2683,2721]
===
match
---
decorator [2174,2184]
decorator [2188,2198]
===
match
---
operator: , [4775,4776]
operator: , [4789,4790]
===
match
---
dictorsetmaker [15988,16040]
dictorsetmaker [16002,16054]
===
match
---
trailer [15595,15602]
trailer [15609,15616]
===
match
---
atom_expr [16743,16757]
atom_expr [16757,16771]
===
match
---
name: try_number [13703,13713]
name: try_number [13717,13727]
===
match
---
name: start_date [15472,15482]
name: start_date [15486,15496]
===
match
---
trailer [6084,6097]
trailer [6098,6111]
===
match
---
atom_expr [14951,14969]
atom_expr [14965,14983]
===
match
---
atom_expr [17739,17768]
atom_expr [17753,17782]
===
match
---
trailer [5533,5538]
trailer [5547,5552]
===
match
---
trailer [12495,12515]
trailer [12509,12529]
===
match
---
simple_stmt [895,921]
simple_stmt [909,935]
===
match
---
with_stmt [19867,20474]
with_stmt [19881,20488]
===
match
---
operator: = [15471,15472]
operator: = [15485,15486]
===
match
---
operator: @ [17196,17197]
operator: @ [17210,17211]
===
match
---
decorated [19690,20697]
decorated [19704,20711]
===
match
---
trailer [7241,7243]
trailer [7255,7257]
===
match
---
simple_stmt [8999,9041]
simple_stmt [9013,9055]
===
match
---
name: date [13005,13009]
name: date [13019,13023]
===
match
---
operator: , [17455,17456]
operator: , [17469,17470]
===
match
---
name: adopted_task_timeouts [14366,14387]
name: adopted_task_timeouts [14380,14401]
===
match
---
param [11547,11552]
param [11561,11566]
===
match
---
atom [14768,14909]
atom [14782,14923]
===
match
---
atom [20568,20683]
atom [20582,20697]
===
match
---
name: setattr [16576,16583]
name: setattr [16590,16597]
===
match
---
trailer [4837,4859]
trailer [4851,4873]
===
match
---
trailer [6307,6315]
trailer [6321,6329]
===
match
---
operator: , [20007,20008]
operator: , [20021,20022]
===
match
---
trailer [9221,9223]
trailer [9235,9237]
===
match
---
operator: , [4939,4940]
operator: , [4953,4954]
===
match
---
operator: @ [16956,16957]
operator: @ [16970,16971]
===
match
---
operator: - [15172,15173]
operator: - [15186,15187]
===
match
---
operator: , [6276,6277]
operator: , [6290,6291]
===
match
---
argument [15247,15253]
argument [15261,15267]
===
match
---
expr_stmt [7066,7109]
expr_stmt [7080,7123]
===
match
---
dotted_name [12906,12925]
dotted_name [12920,12939]
===
match
---
trailer [7438,7480]
trailer [7452,7494]
===
match
---
name: execute [2426,2433]
name: execute [2440,2447]
===
match
---
operator: , [17224,17225]
operator: , [17238,17239]
===
match
---
argument [17754,17767]
argument [17768,17781]
===
match
---
operator: == [14388,14390]
operator: == [14402,14404]
===
match
---
string: "status" [19142,19150]
string: "status" [19156,19164]
===
match
---
comparison [10299,10438]
comparison [10313,10452]
===
match
---
name: queued_dttm [15263,15274]
name: queued_dttm [15277,15288]
===
match
---
name: OPERATION_TIMEOUT [16319,16336]
name: OPERATION_TIMEOUT [16333,16350]
===
match
---
operator: , [20033,20034]
operator: , [20047,20048]
===
match
---
atom_expr [16081,16102]
atom_expr [16095,16116]
===
match
---
operator: = [11698,11699]
operator: = [11712,11713]
===
match
---
operator: + [15853,15854]
operator: + [15867,15868]
===
match
---
param [13504,13508]
param [13518,13522]
===
match
---
expr_stmt [2496,2552]
expr_stmt [2510,2566]
===
match
---
assert_stmt [11238,11291]
assert_stmt [11252,11305]
===
match
---
name: set [17963,17966]
name: set [17977,17980]
===
match
---
atom [20266,20455]
atom [20280,20469]
===
match
---
name: db [3712,3714]
name: db [3726,3728]
===
match
---
trailer [18661,18665]
trailer [18675,18679]
===
match
---
string: 'command' [7336,7345]
string: 'command' [7350,7359]
===
match
---
trailer [16149,16156]
trailer [16163,16170]
===
match
---
atom [17984,18034]
atom [17998,18048]
===
match
---
trailer [6397,6400]
trailer [6411,6414]
===
match
---
param [2198,2202]
param [2212,2216]
===
match
---
string: 'info' [4516,4522]
string: 'info' [4530,4536]
===
match
---
import_from [1059,1084]
import_from [1073,1098]
===
match
---
trailer [16940,16949]
trailer [16954,16963]
===
match
---
trailer [19919,19929]
trailer [19933,19943]
===
match
---
name: contextmanager [2294,2308]
name: contextmanager [2308,2322]
===
match
---
name: parameterized [1361,1374]
name: parameterized [1375,1388]
===
match
---
trailer [9642,9644]
trailer [9656,9658]
===
match
---
fstring [10372,10425]
fstring [10386,10439]
===
match
---
name: timedelta [13673,13682]
name: timedelta [13687,13696]
===
match
---
operator: = [7166,7167]
operator: = [7180,7181]
===
match
---
name: key [5622,5625]
name: key [5636,5639]
===
match
---
atom_expr [13324,13356]
atom_expr [13338,13370]
===
match
---
trailer [13735,13773]
trailer [13749,13787]
===
match
---
string: '232' [14179,14184]
string: '232' [14193,14198]
===
match
---
argument [13561,13570]
argument [13575,13584]
===
match
---
dotted_name [18469,18488]
dotted_name [18483,18502]
===
match
---
operator: = [2651,2652]
operator: = [2665,2666]
===
match
---
decorator [11297,11366]
decorator [11311,11380]
===
match
---
name: environ [2008,2015]
name: environ [2022,2029]
===
match
---
simple_stmt [1059,1085]
simple_stmt [1073,1099]
===
match
---
if_stmt [12438,12900]
if_stmt [12452,12914]
===
match
---
trailer [10676,10713]
trailer [10690,10727]
===
match
---
name: task [8612,8616]
name: task [8626,8630]
===
match
---
name: celery_configuration [2531,2551]
name: celery_configuration [2545,2565]
===
match
---
name: celery_executor [18721,18736]
name: celery_executor [18735,18750]
===
match
---
fstring [16641,16702]
fstring [16655,16716]
===
match
---
name: log [10913,10916]
name: log [10927,10930]
===
match
---
operator: , [5845,5846]
operator: , [5859,5860]
===
match
---
assert_stmt [19549,19684]
assert_stmt [19563,19698]
===
match
---
name: execute_date [6125,6137]
name: execute_date [6139,6151]
===
match
---
name: executor [11663,11671]
name: executor [11677,11685]
===
match
---
operator: = [7443,7444]
operator: = [7457,7458]
===
match
---
name: db [3739,3741]
name: db [3753,3755]
===
match
---
fstring_string: ). [10422,10424]
fstring_string: ). [10436,10438]
===
match
---
simple_stmt [1550,1613]
simple_stmt [1564,1627]
===
match
---
operator: , [4505,4506]
operator: , [4519,4520]
===
match
---
name: query [19019,19024]
name: query [19033,19038]
===
match
---
operator: , [14242,14243]
operator: , [14256,14257]
===
match
---
simple_stmt [13038,13089]
simple_stmt [13052,13103]
===
match
---
trailer [14811,14833]
trailer [14825,14847]
===
match
---
name: patch [12352,12357]
name: patch [12366,12371]
===
match
---
dotted_name [17197,17216]
dotted_name [17211,17230]
===
match
---
operator: } [19179,19180]
operator: } [19193,19194]
===
match
---
name: executor [4334,4342]
name: executor [4348,4356]
===
match
---
name: FAILED [7856,7862]
name: FAILED [7870,7876]
===
match
---
argument [13250,13261]
argument [13264,13275]
===
match
---
number: 30 [15315,15317]
number: 30 [15329,15331]
===
match
---
atom [9005,9040]
atom [9019,9054]
===
match
---
trailer [19929,19951]
trailer [19943,19965]
===
match
---
name: timeout [8306,8313]
name: timeout [8320,8327]
===
match
---
name: TaskInstanceKey [1775,1790]
name: TaskInstanceKey [1789,1804]
===
match
---
name: ti2 [14152,14155]
name: ti2 [14166,14169]
===
match
---
operator: , [2126,2127]
operator: , [2140,2141]
===
match
---
name: CeleryExecutor [11638,11652]
name: CeleryExecutor [11652,11666]
===
match
---
operator: , [3970,3971]
operator: , [3984,3985]
===
match
---
atom_expr [15430,15483]
atom_expr [15444,15497]
===
match
---
trailer [5600,5621]
trailer [5614,5635]
===
match
---
name: db [3625,3627]
name: db [3639,3641]
===
match
---
atom [10545,10547]
atom [10559,10561]
===
match
---
name: mock [17739,17743]
name: mock [17753,17757]
===
match
---
assert_stmt [17956,18034]
assert_stmt [17970,18048]
===
match
---
decorators [7868,7989]
decorators [7882,8003]
===
match
---
name: FakeCeleryResult [11018,11034]
name: FakeCeleryResult [11032,11048]
===
match
---
arglist [17516,17583]
arglist [17530,17597]
===
match
---
import_from [1613,1665]
import_from [1627,1679]
===
match
---
trailer [3309,3323]
trailer [3323,3337]
===
match
---
string: """Test that Airflow retries publishing tasks to Celery Broker at least 3 times""" [8045,8127]
string: """Test that Airflow retries publishing tasks to Celery Broker at least 3 times""" [8059,8141]
===
match
---
operator: , [15602,15603]
operator: , [15616,15617]
===
match
---
name: celery_executor [5124,5139]
name: celery_executor [5138,5153]
===
match
---
name: executor [10993,11001]
name: executor [11007,11015]
===
match
---
name: dag [13777,13780]
name: dag [13791,13794]
===
match
---
trailer [16058,16063]
trailer [16072,16077]
===
match
---
operator: @ [7906,7907]
operator: @ [7920,7921]
===
match
---
trailer [17808,17823]
trailer [17822,17837]
===
match
---
param [3966,3971]
param [3980,3985]
===
match
---
string: 'fail' [4988,4994]
string: 'fail' [5002,5008]
===
match
---
operator: = [4608,4609]
operator: = [4622,4623]
===
match
---
decorator [3892,3934]
decorator [3906,3948]
===
match
---
arglist [8290,8383]
arglist [8304,8397]
===
match
---
comparison [18181,18309]
comparison [18195,18323]
===
match
---
trailer [3641,3643]
trailer [3655,3657]
===
match
---
name: queued_dttm [14211,14222]
name: queued_dttm [14225,14236]
===
match
---
atom_expr [17380,17399]
atom_expr [17394,17413]
===
match
---
operator: , [4098,4099]
operator: , [4112,4113]
===
match
---
argument [13263,13282]
argument [13277,13296]
===
match
---
testlist_comp [6249,6293]
testlist_comp [6263,6307]
===
match
---
arglist [16977,17106]
arglist [16991,17120]
===
match
---
operator: = [7651,7652]
operator: = [7665,7666]
===
match
---
number: 0 [6292,6293]
number: 0 [6306,6307]
===
match
---
import_from [1504,1549]
import_from [1518,1563]
===
match
---
string: "postgres" [18498,18508]
string: "postgres" [18512,18522]
===
match
---
name: task_2 [14624,14630]
name: task_2 [14638,14644]
===
match
---
operator: , [9341,9342]
operator: , [9355,9356]
===
match
---
operator: == [16817,16819]
operator: == [16831,16833]
===
match
---
trailer [14532,14539]
trailer [14546,14553]
===
match
---
name: celery [972,978]
name: celery [986,992]
===
match
---
dictorsetmaker [20501,20551]
dictorsetmaker [20515,20565]
===
match
---
fstring_end: " [10424,10425]
fstring_end: " [10438,10439]
===
match
---
funcdef [16492,16602]
funcdef [16506,16616]
===
match
---
trailer [7793,7806]
trailer [7807,7820]
===
match
---
name: executor [15920,15928]
name: executor [15934,15942]
===
match
---
name: assert_has_calls [11910,11926]
name: assert_has_calls [11924,11940]
===
match
---
simple_stmt [15651,15726]
simple_stmt [15665,15740]
===
match
---
name: ti [7423,7425]
name: ti [7437,7439]
===
match
---
atom_expr [11018,11036]
atom_expr [11032,11050]
===
match
---
name: timezone [15277,15285]
name: timezone [15291,15299]
===
match
---
name: backend [12918,12925]
name: backend [12932,12939]
===
match
---
simple_stmt [4588,5282]
simple_stmt [4602,5296]
===
match
---
atom_expr [2005,2015]
atom_expr [2019,2029]
===
match
---
trailer [2568,2575]
trailer [2582,2589]
===
match
---
name: command [5542,5549]
name: command [5556,5563]
===
match
---
atom [9860,10031]
atom [9874,10045]
===
match
---
name: fail_command [5086,5098]
name: fail_command [5100,5112]
===
match
---
name: bulk_state_fetcher [11059,11077]
name: bulk_state_fetcher [11073,11091]
===
match
---
operator: , [6290,6291]
operator: , [6304,6305]
===
match
---
trailer [12832,12842]
trailer [12846,12856]
===
match
---
atom_expr [4259,4313]
atom_expr [4273,4327]
===
match
---
string: "DEBUG" [17576,17583]
string: "DEBUG" [17590,17597]
===
match
---
name: airflow [1618,1625]
name: airflow [1632,1639]
===
match
---
name: test_error_sending_task [6754,6777]
name: test_error_sending_task [6768,6791]
===
match
---
atom [14238,14248]
atom [14252,14262]
===
match
---
operator: , [9036,9037]
operator: , [9050,9051]
===
match
---
string: 'some_parameter' [4047,4063]
string: 'some_parameter' [4061,4077]
===
match
---
trailer [2625,2664]
trailer [2639,2678]
===
match
---
trailer [2089,2094]
trailer [2103,2108]
===
match
---
atom_expr [8418,8450]
atom_expr [8432,8464]
===
match
---
trailer [2575,2603]
trailer [2589,2617]
===
match
---
name: self [17483,17487]
name: self [17497,17501]
===
match
---
name: synchronous [6192,6203]
name: synchronous [6206,6217]
===
match
---
atom_expr [7785,7846]
atom_expr [7799,7860]
===
match
---
name: return_value [19045,19057]
name: return_value [19059,19071]
===
match
---
name: mock_subproc [12594,12606]
name: mock_subproc [12608,12620]
===
match
---
name: task_id [20401,20408]
name: task_id [20415,20422]
===
match
---
atom [5924,6052]
atom [5938,6066]
===
match
---
suite [16563,16602]
suite [16577,16616]
===
match
---
fstring_string: [Try 1 of 3] Task Timeout Error for Task: ( [9532,9575]
fstring_string: [Try 1 of 3] Task Timeout Error for Task: ( [9546,9589]
===
match
---
atom_expr [9243,9278]
atom_expr [9257,9292]
===
match
---
argument [6192,6208]
argument [6206,6222]
===
match
---
operator: , [6732,6733]
operator: , [6746,6747]
===
match
---
assert_stmt [13366,13418]
assert_stmt [13380,13432]
===
match
---
import_from [895,920]
import_from [909,934]
===
match
---
trailer [17498,17597]
trailer [17512,17611]
===
match
---
trailer [7473,7477]
trailer [7487,7491]
===
match
---
name: mock [11770,11774]
name: mock [11784,11788]
===
match
---
name: key_1 [14505,14510]
name: key_1 [14519,14524]
===
match
---
atom_expr [14978,14996]
atom_expr [14992,15010]
===
match
---
comparison [12820,12859]
comparison [12834,12873]
===
match
---
for_stmt [5400,5631]
for_stmt [5414,5645]
===
match
---
string: "Task should remain in queue" [9764,9793]
string: "Task should remain in queue" [9778,9807]
===
match
---
name: set_event_loop [3520,3534]
name: set_event_loop [3534,3548]
===
match
---
operator: = [8677,8678]
operator: = [8691,8692]
===
match
---
name: external_executor_id [14156,14176]
name: external_executor_id [14170,14190]
===
match
---
trailer [13406,13411]
trailer [13420,13425]
===
match
---
simple_stmt [16634,16703]
simple_stmt [16648,16717]
===
match
---
atom_expr [19272,19461]
atom_expr [19286,19475]
===
match
---
trailer [15225,15232]
trailer [15239,15246]
===
match
---
string: "redis" [6650,6657]
string: "redis" [6664,6671]
===
match
---
atom_expr [16644,16678]
atom_expr [16658,16692]
===
match
---
parameters [6817,6819]
parameters [6831,6833]
===
match
---
string: 'airflow.executors.celery_executor.app' [2734,2773]
string: 'airflow.executors.celery_executor.app' [2748,2787]
===
match
---
atom_expr [14728,14764]
atom_expr [14742,14778]
===
match
---
assert_stmt [10499,10547]
assert_stmt [10513,10561]
===
match
---
atom [6098,6141]
atom [6112,6155]
===
match
---
trailer [8912,8971]
trailer [8926,8985]
===
match
---
simple_stmt [15787,15962]
simple_stmt [15801,15976]
===
match
---
trailer [5656,5671]
trailer [5670,5685]
===
match
---
trailer [16895,16902]
trailer [16909,16916]
===
match
---
suite [16951,20697]
suite [16965,20711]
===
match
---
simple_stmt [10227,10262]
simple_stmt [10241,10276]
===
match
---
comparison [10234,10261]
comparison [10248,10275]
===
match
---
param [18555,18567]
param [18569,18581]
===
match
---
trailer [10877,10879]
trailer [10891,10893]
===
match
---
expr_stmt [2362,2421]
expr_stmt [2376,2435]
===
match
---
name: output [11284,11290]
name: output [11298,11304]
===
match
---
arith_expr [13653,13693]
arith_expr [13667,13707]
===
match
---
name: self [8030,8034]
name: self [8044,8048]
===
match
---
name: timezone [1865,1873]
name: timezone [1879,1887]
===
match
---
name: ANY [18082,18085]
name: ANY [18096,18099]
===
match
---
simple_stmt [805,817]
simple_stmt [805,817]
===
match
---
param [16774,16779]
param [16788,16793]
===
match
---
simple_stmt [10560,10636]
simple_stmt [10574,10650]
===
match
---
expr_stmt [20173,20202]
expr_stmt [20187,20216]
===
match
---
param [19852,19856]
param [19866,19870]
===
match
---
trailer [10519,10540]
trailer [10533,10554]
===
match
---
atom_expr [11747,11755]
atom_expr [11761,11769]
===
match
---
operator: = [13876,13877]
operator: = [13890,13891]
===
match
---
parameters [3688,3694]
parameters [3702,3708]
===
match
---
name: executor [14457,14465]
name: executor [14471,14479]
===
match
---
name: mock_backend [18921,18933]
name: mock_backend [18935,18947]
===
match
---
arglist [19988,20032]
arglist [20002,20046]
===
match
---
atom_expr [14513,14579]
atom_expr [14527,14593]
===
match
---
name: pytest [10768,10774]
name: pytest [10782,10788]
===
match
---
expr_stmt [10993,11037]
expr_stmt [11007,11051]
===
match
---
expr_stmt [13292,13304]
expr_stmt [13306,13318]
===
match
---
atom_expr [15237,15254]
atom_expr [15251,15268]
===
match
---
argument [18667,18683]
argument [18681,18697]
===
match
---
name: self [16884,16888]
name: self [16898,16902]
===
match
---
simple_stmt [12813,12900]
simple_stmt [12827,12914]
===
match
---
trailer [19244,19246]
trailer [19258,19260]
===
match
---
operator: , [4021,4022]
operator: , [4035,4036]
===
match
---
name: executor [9740,9748]
name: executor [9754,9762]
===
match
---
string: 'airflow.executors.base_executor.Stats.gauge' [11464,11509]
string: 'airflow.executors.base_executor.Stats.gauge' [11478,11523]
===
match
---
operator: @ [18389,18390]
operator: @ [18403,18404]
===
match
---
name: queued_tasks [5521,5533]
name: queued_tasks [5535,5547]
===
match
---
operator: , [7194,7195]
operator: , [7208,7209]
===
match
---
simple_stmt [6324,6417]
simple_stmt [6338,6431]
===
match
---
simple_stmt [4073,4111]
simple_stmt [4087,4125]
===
match
---
trailer [13560,13571]
trailer [13574,13585]
===
match
---
trailer [3654,3668]
trailer [3668,3682]
===
match
---
name: executor [6450,6458]
name: executor [6464,6472]
===
match
---
comparison [9813,9840]
comparison [9827,9854]
===
match
---
dotted_name [972,1000]
dotted_name [986,1014]
===
match
---
name: cm [18300,18302]
name: cm [18314,18316]
===
match
---
arglist [16584,16600]
arglist [16598,16614]
===
match
---
operator: { [10545,10546]
operator: { [10559,10560]
===
match
---
string: "postgres" [15070,15080]
string: "postgres" [15084,15094]
===
match
---
name: utcnow [13540,13546]
name: utcnow [13554,13560]
===
match
---
argument [15307,15317]
argument [15321,15331]
===
match
---
operator: , [20349,20350]
operator: , [20363,20364]
===
match
---
name: mark [6671,6675]
name: mark [6685,6689]
===
match
---
param [11553,11570]
param [11567,11584]
===
match
---
name: line [11211,11215]
name: line [11225,11229]
===
match
---
operator: = [15574,15575]
operator: = [15588,15589]
===
match
---
operator: } [10421,10422]
operator: } [10435,10436]
===
match
---
name: __str__ [16748,16755]
name: __str__ [16762,16769]
===
match
---
name: success_command [4760,4775]
name: success_command [4774,4789]
===
match
---
operator: = [15152,15153]
operator: = [15166,15167]
===
match
---
import_name [817,826]
import_name [817,826]
===
match
---
string: 'SUCCESS' [20339,20348]
string: 'SUCCESS' [20353,20362]
===
match
---
return_stmt [16736,16757]
return_stmt [16750,16771]
===
match
---
operator: , [7546,7547]
operator: , [7560,7561]
===
match
---
atom_expr [8767,8781]
atom_expr [8781,8795]
===
match
---
trailer [10510,10541]
trailer [10524,10555]
===
match
---
simple_stmt [7270,7292]
simple_stmt [7284,7306]
===
match
---
expr_stmt [15263,15318]
expr_stmt [15277,15332]
===
match
---
name: utcnow [13662,13668]
name: utcnow [13676,13682]
===
match
---
simple_stmt [14402,14430]
simple_stmt [14416,14444]
===
match
---
testlist_comp [6354,6395]
testlist_comp [6368,6409]
===
match
---
trailer [5671,5692]
trailer [5685,5706]
===
match
---
string: "postgres" [12935,12945]
string: "postgres" [12949,12959]
===
match
---
dotted_name [17118,17141]
dotted_name [17132,17155]
===
match
---
atom [11971,11993]
atom [11985,12007]
===
match
---
testlist_comp [12848,12856]
testlist_comp [12862,12870]
===
match
---
string: "task_id" [2270,2279]
string: "task_id" [2284,2293]
===
match
---
atom [4658,4704]
atom [4672,4718]
===
match
---
name: task_id [15611,15618]
name: task_id [15625,15632]
===
match
---
operator: = [15314,15315]
operator: = [15328,15329]
===
match
---
atom_expr [6404,6416]
atom_expr [6418,6430]
===
match
---
string: 'executor.queued_tasks' [11780,11803]
string: 'executor.queued_tasks' [11794,11817]
===
match
---
string: "sqlite3://" [18671,18683]
string: "sqlite3://" [18685,18697]
===
match
---
testlist_comp [17739,17824]
testlist_comp [17753,17838]
===
match
---
operator: == [14940,14942]
operator: == [14954,14956]
===
match
---
string: "231" [14963,14968]
string: "231" [14977,14982]
===
match
---
number: 2 [13086,13087]
number: 2 [13100,13101]
===
match
---
trailer [16006,16013]
trailer [16020,16027]
===
match
---
trailer [4236,4244]
trailer [4250,4258]
===
match
---
trailer [5223,5239]
trailer [5237,5253]
===
match
---
trailer [10484,10486]
trailer [10498,10500]
===
match
---
name: close [3342,3347]
name: close [3356,3361]
===
match
---
atom_expr [10993,11007]
atom_expr [11007,11021]
===
match
---
operator: = [2350,2351]
operator: = [2364,2365]
===
match
---
trailer [2462,2478]
trailer [2476,2492]
===
match
---
trailer [16888,16895]
trailer [16902,16909]
===
match
---
simple_stmt [2213,2231]
simple_stmt [2227,2245]
===
match
---
trailer [15306,15318]
trailer [15320,15332]
===
match
---
dotted_name [11940,11960]
dotted_name [11954,11974]
===
match
---
parameters [11546,11601]
parameters [11560,11615]
===
match
---
assert_stmt [14402,14429]
assert_stmt [14416,14443]
===
match
---
trailer [16033,16040]
trailer [16047,16054]
===
match
---
operator: , [12018,12019]
operator: , [12032,12033]
===
match
---
operator: = [14109,14110]
operator: = [14123,14124]
===
match
---
trailer [11671,11681]
trailer [11685,11695]
===
match
---
name: execute_date [6380,6392]
name: execute_date [6394,6406]
===
match
---
name: mock [17794,17798]
name: mock [17808,17812]
===
match
---
import_from [1701,1790]
import_from [1715,1804]
===
match
---
dotted_name [11371,11381]
dotted_name [11385,11395]
===
match
---
operator: } [16040,16041]
operator: } [16054,16055]
===
match
---
name: key [16534,16537]
name: key [16548,16551]
===
match
---
operator: , [5012,5013]
operator: , [5026,5027]
===
match
---
atom_expr [10511,10540]
atom_expr [10525,10554]
===
match
---
operator: , [7173,7174]
operator: , [7187,7188]
===
match
---
name: timedelta [13071,13080]
name: timedelta [13085,13094]
===
match
---
operator: ** [19114,19116]
operator: ** [19128,19130]
===
match
---
sync_comp_for [11269,11290]
sync_comp_for [11283,11304]
===
match
---
operator: , [7448,7449]
operator: , [7462,7463]
===
match
---
comparison [19478,19540]
comparison [19492,19554]
===
match
---
fstring_end: " [16701,16702]
fstring_end: " [16715,16716]
===
match
---
atom_expr [8202,8393]
atom_expr [8216,8407]
===
match
---
atom_expr [14624,14638]
atom_expr [14638,14652]
===
match
---
name: patch [18321,18326]
name: patch [18335,18340]
===
match
---
operator: = [8954,8955]
operator: = [8968,8969]
===
match
---
trailer [10431,10438]
trailer [10445,10452]
===
match
---
assert_stmt [6561,6619]
assert_stmt [6575,6633]
===
match
---
atom [12033,12068]
atom [12047,12082]
===
match
---
decorator [6663,6700]
decorator [6677,6714]
===
match
---
operator: @ [7868,7869]
operator: @ [7882,7883]
===
match
---
operator: @ [6663,6664]
operator: @ [6677,6678]
===
match
---
testlist_comp [16115,16133]
testlist_comp [16129,16147]
===
match
---
name: executor [10090,10098]
name: executor [10104,10112]
===
match
---
with_stmt [13727,13932]
with_stmt [13741,13946]
===
match
---
dotted_name [1671,1689]
dotted_name [1685,1703]
===
match
---
operator: = [20127,20128]
operator: = [20141,20142]
===
match
---
simple_stmt [1045,1059]
simple_stmt [1059,1073]
===
match
---
string: "airflow.executors.celery_executor.BulkStateFetcher" [17516,17568]
string: "airflow.executors.celery_executor.BulkStateFetcher" [17530,17582]
===
match
---
trailer [6533,6546]
trailer [6547,6560]
===
match
---
decorator [3813,3847]
decorator [3827,3861]
===
match
---
simple_stmt [14152,14185]
simple_stmt [14166,14199]
===
match
---
trailer [7477,7479]
trailer [7491,7493]
===
match
---
atom [4961,5262]
atom [4975,5276]
===
match
---
name: value_tuple [7592,7603]
name: value_tuple [7606,7617]
===
match
---
name: execute [6865,6872]
name: execute [6879,6886]
===
match
---
name: session [3334,3341]
name: session [3348,3355]
===
match
---
simple_stmt [2025,2096]
simple_stmt [2039,2110]
===
match
---
string: 'true' [4039,4045]
string: 'true' [4053,4059]
===
match
---
testlist_comp [5969,6013]
testlist_comp [5983,6027]
===
match
---
param [16619,16623]
param [16633,16637]
===
match
---
atom [14427,14429]
atom [14441,14443]
===
match
---
name: tearDown [3680,3688]
name: tearDown [3694,3702]
===
match
---
dotted_name [3893,3912]
dotted_name [3907,3926]
===
match
---
trailer [5520,5533]
trailer [5534,5547]
===
match
---
fstring_end: " [9582,9583]
fstring_end: " [9596,9597]
===
match
---
decorator [12905,12947]
decorator [12919,12961]
===
match
---
name: _prepare_test_bodies [3785,3805]
name: _prepare_test_bodies [3799,3819]
===
match
---
atom [11010,11037]
atom [11024,11051]
===
match
---
dictorsetmaker [14699,14711]
dictorsetmaker [14713,14725]
===
match
---
testlist_comp [2033,2094]
testlist_comp [2047,2108]
===
match
---
operator: = [4481,4482]
operator: = [4495,4496]
===
match
---
suite [3385,3541]
suite [3399,3555]
===
match
---
argument [8940,8969]
argument [8954,8983]
===
match
---
atom [10677,10712]
atom [10691,10726]
===
match
---
operator: = [18645,18646]
operator: = [18659,18660]
===
match
---
name: event_buffer [9822,9834]
name: event_buffer [9836,9848]
===
match
---
testlist_comp [19336,19421]
testlist_comp [19350,19435]
===
match
---
trailer [19350,19365]
trailer [19364,19379]
===
match
---
name: self [16584,16588]
name: self [16598,16602]
===
match
---
dotted_name [18316,18326]
dotted_name [18330,18340]
===
match
---
argument [17570,17583]
argument [17584,17597]
===
match
---
assert_stmt [6069,6161]
assert_stmt [6083,6175]
===
match
---
trailer [13354,13356]
trailer [13368,13370]
===
match
---
operator: , [13832,13833]
operator: , [13846,13847]
===
match
---
trailer [16560,16562]
trailer [16574,16576]
===
match
---
string: "postgres" [3922,3932]
string: "postgres" [3936,3946]
===
match
---
with_item [4259,4320]
with_item [4273,4334]
===
match
---
name: parameterized [3764,3777]
name: parameterized [3778,3791]
===
match
---
name: State [6022,6027]
name: State [6036,6041]
===
match
---
name: pytest [7948,7954]
name: pytest [7962,7968]
===
match
---
arglist [2931,2955]
arglist [2945,2969]
===
match
---
name: self [8158,8162]
name: self [8172,8176]
===
match
---
operator: , [11814,11815]
operator: , [11828,11829]
===
match
---
with_stmt [6847,7688]
with_stmt [6861,7702]
===
match
---
name: celery_executor [4801,4816]
name: celery_executor [4815,4830]
===
match
---
operator: = [7127,7128]
operator: = [7141,7142]
===
match
---
atom_expr [11281,11290]
atom_expr [11295,11304]
===
match
---
atom_expr [15687,15701]
atom_expr [15701,15715]
===
match
---
name: FAILED [6410,6416]
name: FAILED [6424,6430]
===
match
---
operator: , [5262,5263]
operator: , [5276,5277]
===
match
---
name: backend [19782,19789]
name: backend [19796,19803]
===
match
---
parameters [10843,10849]
parameters [10857,10863]
===
match
---
trailer [20400,20432]
trailer [20414,20446]
===
match
---
arglist [20068,20135]
arglist [20082,20149]
===
match
---
name: return_value [18948,18960]
name: return_value [18962,18974]
===
match
---
operator: = [13235,13236]
operator: = [13249,13250]
===
match
---
expr_stmt [13941,13998]
expr_stmt [13955,14012]
===
match
---
import_from [1436,1503]
import_from [1450,1517]
===
match
---
trailer [15442,15483]
trailer [15456,15497]
===
match
---
name: self [3966,3970]
name: self [3980,3984]
===
match
---
simple_stmt [3993,4065]
simple_stmt [4007,4079]
===
match
---
trailer [16089,16102]
trailer [16103,16116]
===
match
---
atom [9703,9711]
atom [9717,9725]
===
match
---
trailer [17966,17980]
trailer [17980,17994]
===
match
---
expr_stmt [14086,14143]
expr_stmt [14100,14157]
===
match
---
funcdef [16255,16342]
funcdef [16269,16356]
===
match
---
name: BulkStateFetcher [20183,20199]
name: BulkStateFetcher [20197,20213]
===
match
---
trailer [13381,13406]
trailer [13395,13420]
===
match
---
trailer [13622,13630]
trailer [13636,13644]
===
match
---
atom_expr [13167,13220]
atom_expr [13181,13234]
===
match
---
name: DAG [1697,1700]
name: DAG [1711,1714]
===
match
---
name: tis [13407,13410]
name: tis [13421,13424]
===
match
---
operator: = [13568,13569]
operator: = [13582,13583]
===
match
---
comparison [18103,18165]
comparison [18117,18179]
===
match
---
comparison [10085,10132]
comparison [10099,10146]
===
match
---
assert_stmt [18096,18165]
assert_stmt [18110,18179]
===
match
---
expr_stmt [8794,8986]
expr_stmt [8808,9000]
===
match
---
atom_expr [15154,15171]
atom_expr [15168,15185]
===
match
---
atom_expr [11110,11133]
atom_expr [11124,11147]
===
match
---
classdef [16344,16903]
classdef [16358,16917]
===
match
---
string: 'backend' [20009,20018]
string: 'backend' [20023,20032]
===
match
---
atom [2107,2143]
atom [2121,2157]
===
match
---
name: AsyncResult [16022,16033]
name: AsyncResult [16036,16047]
===
match
---
string: "rabbitmq" [3876,3886]
string: "rabbitmq" [3890,3900]
===
match
---
name: models [1626,1632]
name: models [1640,1646]
===
match
---
atom_expr [15970,15984]
atom_expr [15984,15998]
===
match
---
testlist_comp [12035,12060]
testlist_comp [12049,12074]
===
match
---
atom_expr [15505,15558]
atom_expr [15519,15572]
===
match
---
param [3602,3606]
param [3616,3620]
===
match
---
simple_stmt [2608,2665]
simple_stmt [2622,2679]
===
match
---
atom [10259,10261]
atom [10273,10275]
===
match
---
arglist [15443,15482]
arglist [15457,15496]
===
match
---
atom [4987,5030]
atom [5001,5044]
===
match
---
strings [9457,9583]
strings [9471,9597]
===
match
---
operator: , [10702,10703]
operator: , [10716,10717]
===
match
---
atom_expr [12820,12842]
atom_expr [12834,12856]
===
match
---
operator: , [6010,6011]
operator: , [6024,6025]
===
match
---
operator: } [19180,19181]
operator: } [19194,19195]
===
match
---
suite [15133,16253]
suite [15147,16267]
===
match
---
operator: } [20551,20552]
operator: } [20565,20566]
===
match
---
name: event_buffer [6085,6097]
name: event_buffer [6099,6111]
===
match
---
decorator [18427,18464]
decorator [18441,18478]
===
match
---
operator: = [18860,18861]
operator: = [18874,18875]
===
match
---
operator: = [15503,15504]
operator: = [15517,15518]
===
match
---
string: '123' [18114,18119]
string: '123' [18128,18133]
===
match
---
trailer [13539,13546]
trailer [13553,13560]
===
match
---
operator: } [10546,10547]
operator: } [10560,10561]
===
match
---
atom_expr [11155,11198]
atom_expr [11169,11212]
===
match
---
name: execute_date [4541,4553]
name: execute_date [4555,4567]
===
match
---
atom [14943,14997]
atom [14957,15011]
===
match
---
trailer [5741,5743]
trailer [5755,5757]
===
match
---
operator: , [6105,6106]
operator: , [6119,6120]
===
match
---
with_stmt [8137,10733]
with_stmt [8151,10747]
===
match
---
name: executor [10576,10584]
name: executor [10590,10598]
===
match
---
simple_stmt [16381,16487]
simple_stmt [16395,16501]
===
match
---
suite [10924,11135]
suite [10938,11149]
===
match
---
name: ResultSession [3310,3323]
name: ResultSession [3324,3337]
===
match
---
trailer [18720,18766]
trailer [18734,18780]
===
match
---
string: 'task_default_queue' [5161,5181]
string: 'task_default_queue' [5175,5195]
===
match
---
operator: { [10124,10125]
operator: { [10138,10139]
===
match
---
name: assertLogs [18773,18783]
name: assertLogs [18787,18797]
===
match
---
string: "Assert Default Max Retries is 3" [8565,8598]
string: "Assert Default Max Retries is 3" [8579,8612]
===
match
---
atom_expr [11245,11291]
atom_expr [11259,11305]
===
match
---
operator: = [17629,17630]
operator: = [17643,17644]
===
match
---
operator: , [4700,4701]
operator: , [4714,4715]
===
match
---
operator: , [5428,5429]
operator: , [5442,5443]
===
match
---
name: executor [6331,6339]
name: executor [6345,6353]
===
match
---
name: self [2248,2252]
name: self [2262,2266]
===
match
---
decorators [3763,3934]
decorators [3777,3948]
===
match
---
operator: @ [10738,10739]
operator: @ [10752,10753]
===
match
---
trailer [11124,11131]
trailer [11138,11145]
===
match
---
name: ti1 [14007,14010]
name: ti1 [14021,14024]
===
match
---
name: task_id [17809,17816]
name: task_id [17823,17830]
===
match
---
name: mock [8202,8206]
name: mock [8216,8220]
===
match
---
simple_stmt [2496,2553]
simple_stmt [2510,2567]
===
match
---
arglist [2816,2881]
arglist [2830,2895]
===
match
---
atom_expr [14092,14143]
atom_expr [14106,14157]
===
match
---
operator: = [17673,17674]
operator: = [17687,17688]
===
match
---
operator: } [18033,18034]
operator: } [18047,18048]
===
match
---
string: ',' [2090,2093]
string: ',' [2104,2107]
===
match
---
name: key_2 [14706,14711]
name: key_2 [14720,14725]
===
match
---
operator: , [5798,5799]
operator: , [5812,5813]
===
match
---
comparison [20490,20552]
comparison [20504,20566]
===
match
---
string: 'fake_simple_ti' [6107,6123]
string: 'fake_simple_ti' [6121,6137]
===
match
---
trailer [14465,14490]
trailer [14479,14504]
===
match
---
name: output [10011,10017]
name: output [10025,10031]
===
match
---
name: celery_configuration [5140,5160]
name: celery_configuration [5154,5174]
===
match
---
comparison [15013,15034]
comparison [15027,15048]
===
match
---
expr_stmt [4541,4570]
expr_stmt [4555,4584]
===
match
---
trailer [11131,11133]
trailer [11145,11147]
===
match
---
name: exec_date [15620,15629]
name: exec_date [15634,15643]
===
match
---
name: execute [2698,2705]
name: execute [2712,2719]
===
match
---
atom [2033,2039]
atom [2047,2053]
===
match
---
operator: = [4494,4495]
operator: = [4508,4509]
===
match
---
name: CeleryExecutor [10964,10978]
name: CeleryExecutor [10978,10992]
===
match
---
operator: = [20181,20182]
operator: = [20195,20196]
===
match
---
fstring_string: ). [9580,9582]
fstring_string: ). [9594,9596]
===
match
---
operator: , [17466,17467]
operator: , [17480,17481]
===
match
---
operator: == [19485,19487]
operator: == [19499,19501]
===
match
---
atom_expr [14733,14763]
atom_expr [14747,14777]
===
match
---
name: key [16590,16593]
name: key [16604,16607]
===
match
---
expr_stmt [15970,16041]
expr_stmt [15984,16055]
===
match
---
atom_expr [20035,20149]
atom_expr [20049,20163]
===
match
---
arglist [14529,14578]
arglist [14543,14592]
===
match
---
trailer [15761,15776]
trailer [15775,15790]
===
match
---
suite [12690,12900]
suite [12704,12914]
===
match
---
atom_expr [18721,18740]
atom_expr [18735,18754]
===
match
---
operator: { [9417,9418]
operator: { [9431,9432]
===
match
---
name: fake_execute_command [4124,4144]
name: fake_execute_command [4138,4158]
===
match
---
funcdef [15086,16253]
funcdef [15100,16267]
===
match
---
name: backend [3302,3309]
name: backend [3316,3323]
===
match
---
funcdef [11515,11934]
funcdef [11529,11948]
===
match
---
trailer [8775,8779]
trailer [8789,8793]
===
match
---
simple_stmt [14671,14713]
simple_stmt [14685,14727]
===
match
---
name: timedelta [13551,13560]
name: timedelta [13565,13574]
===
match
---
operator: , [14539,14540]
operator: , [14553,14554]
===
match
---
testlist_comp [11714,11874]
testlist_comp [11728,11888]
===
match
---
atom_expr [16820,16834]
atom_expr [16834,16848]
===
match
---
name: split [2084,2089]
name: split [2098,2103]
===
match
---
trailer [11832,11837]
trailer [11846,11851]
===
match
---
simple_stmt [16736,16758]
simple_stmt [16750,16772]
===
match
---
name: queue [5554,5559]
name: queue [5568,5573]
===
match
---
string: "redis" [17142,17149]
string: "redis" [17156,17163]
===
match
---
operator: , [4668,4669]
operator: , [4682,4683]
===
match
---
expr_stmt [8760,8781]
expr_stmt [8774,8795]
===
match
---
testlist_comp [14239,14247]
testlist_comp [14253,14261]
===
match
---
name: mock [11864,11868]
name: mock [11878,11882]
===
match
---
name: executor [7712,7720]
name: executor [7726,7734]
===
match
---
atom_expr [13947,13998]
atom_expr [13961,14012]
===
match
---
name: contextlib [794,804]
name: contextlib [794,804]
===
match
---
with_stmt [17303,17865]
with_stmt [17317,17879]
===
match
---
operator: , [19420,19421]
operator: , [19434,19435]
===
match
---
name: mock_subproc [12333,12345]
name: mock_subproc [12347,12359]
===
match
---
name: test_try_adopt_task_instances_none [12955,12989]
name: test_try_adopt_task_instances_none [12969,13003]
===
match
---
atom [17064,17103]
atom [17078,17117]
===
match
---
comp_op [6487,6493]
comp_op [6501,6507]
===
match
---
simple_stmt [827,838]
simple_stmt [841,852]
===
match
---
trailer [11723,11756]
trailer [11737,11770]
===
match
---
name: executor [15855,15863]
name: executor [15869,15877]
===
match
---
trailer [17451,17455]
trailer [17465,17469]
===
match
---
classdef [2146,2280]
classdef [2160,2294]
===
match
---
operator: @ [19690,19691]
operator: @ [19704,19705]
===
match
---
name: loglevel [4507,4515]
name: loglevel [4521,4529]
===
match
---
operator: { [10259,10260]
operator: { [10273,10274]
===
match
---
atom_expr [17436,17455]
atom_expr [17450,17469]
===
match
---
name: _prepare_app [18583,18595]
name: _prepare_app [18597,18609]
===
match
---
atom [14391,14393]
atom [14405,14407]
===
match
---
name: exec_date [15703,15712]
name: exec_date [15717,15726]
===
match
---
fstring_expr [16680,16700]
fstring_expr [16694,16714]
===
match
---
simple_stmt [9657,9712]
simple_stmt [9671,9726]
===
match
---
string: 'airflow' [12035,12044]
string: 'airflow' [12049,12058]
===
match
---
simple_stmt [3292,3326]
simple_stmt [3306,3340]
===
match
---
operator: = [7187,7188]
operator: = [7201,7202]
===
match
---
operator: , [5549,5550]
operator: , [5563,5564]
===
match
---
decorator [10767,10809]
decorator [10781,10823]
===
match
---
name: dag [14612,14615]
name: dag [14626,14629]
===
match
---
testlist_comp [4012,4063]
testlist_comp [4026,4077]
===
match
---
testlist_comp [20535,20550]
testlist_comp [20549,20564]
===
match
---
atom_expr [10466,10486]
atom_expr [10480,10500]
===
match
---
trailer [4816,4837]
trailer [4830,4851]
===
match
---
trailer [11283,11290]
trailer [11297,11304]
===
match
---
name: execution_date [7450,7464]
name: execution_date [7464,7478]
===
match
---
name: execute_command [12723,12738]
name: execute_command [12737,12752]
===
match
---
fstring_string: ). [10001,10003]
fstring_string: ). [10015,10017]
===
match
---
name: try_adopt_task_instances [13382,13406]
name: try_adopt_task_instances [13396,13420]
===
match
---
name: get_many [20236,20244]
name: get_many [20250,20258]
===
match
---
number: 1 [5551,5552]
number: 1 [5565,5566]
===
match
---
trailer [8448,8450]
trailer [8462,8464]
===
match
---
trailer [10169,10182]
trailer [10183,10196]
===
match
---
simple_stmt [6179,6210]
simple_stmt [6193,6224]
===
match
---
simple_stmt [4541,4571]
simple_stmt [4555,4585]
===
match
---
name: state [20333,20338]
name: state [20347,20352]
===
match
---
operator: } [14428,14429]
operator: } [14442,14443]
===
match
---
name: executor [11050,11058]
name: executor [11064,11072]
===
match
---
name: executor [5592,5600]
name: executor [5606,5614]
===
match
---
name: executor [16050,16058]
name: executor [16064,16072]
===
match
---
atom_expr [6076,6145]
atom_expr [6090,6159]
===
match
---
trailer [6027,6034]
trailer [6041,6048]
===
match
---
name: backend [18481,18488]
name: backend [18495,18502]
===
match
---
name: output [19678,19684]
name: output [19692,19698]
===
match
---
name: executor [5648,5656]
name: executor [5662,5670]
===
match
---
name: SimpleTaskInstance [1741,1759]
name: SimpleTaskInstance [1755,1773]
===
match
---
assert_stmt [9303,9372]
assert_stmt [9317,9386]
===
match
---
testlist_comp [4987,5240]
testlist_comp [5001,5254]
===
match
---
string: 'success' [6249,6258]
string: 'success' [6263,6272]
===
match
---
name: key [5534,5537]
name: key [5548,5551]
===
match
---
decorated [18315,19685]
decorated [18329,19699]
===
match
---
trailer [9256,9277]
trailer [9270,9291]
===
match
---
simple_stmt [14721,14910]
simple_stmt [14735,14924]
===
match
---
string: b'celery-task-meta-123' [18010,18033]
string: b'celery-task-meta-123' [18024,18047]
===
match
---
name: executor [6226,6234]
name: executor [6240,6248]
===
match
---
simple_stmt [14505,14580]
simple_stmt [14519,14594]
===
match
---
yield_expr [3411,3425]
yield_expr [3425,3439]
===
match
---
assert_stmt [20561,20696]
assert_stmt [20575,20710]
===
match
---
name: backend [6717,6724]
name: backend [6731,6738]
===
match
---
simple_stmt [2557,2604]
simple_stmt [2571,2618]
===
match
---
string: 'CELERY_BROKER_URLS' [1981,2001]
string: 'CELERY_BROKER_URLS' [1995,2015]
===
match
---
name: kwargs [16513,16519]
name: kwargs [16527,16533]
===
match
---
trailer [19974,19980]
trailer [19988,19994]
===
match
---
operator: = [4291,4292]
operator: = [4305,4306]
===
match
---
name: queued_dttm [14052,14063]
name: queued_dttm [14066,14077]
===
match
---
trailer [6458,6464]
trailer [6472,6478]
===
match
---
operator: , [14555,14556]
operator: , [14569,14570]
===
match
---
atom [11972,11980]
atom [11986,11994]
===
match
---
atom_expr [19970,20033]
atom_expr [19984,20047]
===
match
---
atom_expr [7404,7481]
atom_expr [7418,7495]
===
match
---
atom_expr [18921,18960]
atom_expr [18935,18974]
===
match
---
operator: = [8617,8618]
operator: = [8631,8632]
===
match
---
name: result [19263,19269]
name: result [19277,19283]
===
match
---
fstring_expr [16643,16679]
fstring_expr [16657,16693]
===
match
---
trailer [16224,16246]
trailer [16238,16260]
===
match
---
with_item [18768,18888]
with_item [18782,18902]
===
match
---
trailer [8731,8733]
trailer [8745,8747]
===
match
---
atom_expr [17053,17104]
atom_expr [17067,17118]
===
match
---
name: any [11151,11154]
name: any [11165,11168]
===
match
---
trailer [15517,15558]
trailer [15531,15572]
===
match
---
name: level [20122,20127]
name: level [20136,20141]
===
match
---
import_from [1791,1838]
import_from [1805,1852]
===
match
---
decorator [3851,3888]
decorator [3865,3902]
===
match
---
name: executor [14925,14933]
name: executor [14939,14947]
===
match
---
name: pytest [7907,7913]
name: pytest [7921,7927]
===
match
---
name: contextlib [2283,2293]
name: contextlib [2297,2307]
===
match
---
name: minutes [13561,13568]
name: minutes [13575,13582]
===
match
---
name: when [9032,9036]
name: when [9046,9050]
===
match
---
simple_stmt [14193,14223]
simple_stmt [14207,14237]
===
match
---
name: test_config [2496,2507]
name: test_config [2510,2521]
===
match
---
suite [16376,16903]
suite [16390,16917]
===
match
---
name: TaskInstance [8916,8928]
name: TaskInstance [8930,8942]
===
match
---
simple_stmt [7696,7770]
simple_stmt [7710,7784]
===
match
---
name: self [3602,3606]
name: self [3616,3620]
===
match
---
operator: = [17379,17380]
operator: = [17393,17394]
===
match
---
operator: , [5026,5027]
operator: , [5040,5041]
===
match
---
name: try_number [15328,15338]
name: try_number [15342,15352]
===
match
---
trailer [17057,17063]
trailer [17071,17077]
===
match
---
dotted_name [19691,19714]
dotted_name [19705,19728]
===
match
---
expr_stmt [15496,15558]
expr_stmt [15510,15572]
===
match
---
expr_stmt [2711,2784]
expr_stmt [2725,2798]
===
match
---
atom_expr [10429,10438]
atom_expr [10443,10452]
===
match
---
name: pytest [15041,15047]
name: pytest [15055,15061]
===
match
---
operator: , [8835,8836]
operator: , [8849,8850]
===
match
---
atom_expr [10897,10916]
atom_expr [10911,10930]
===
match
---
name: patch [19975,19980]
name: patch [19989,19994]
===
match
---
name: key_2 [16136,16141]
name: key_2 [16150,16155]
===
match
---
trailer [2514,2552]
trailer [2528,2566]
===
match
---
trailer [6097,6142]
trailer [6111,6156]
===
match
---
name: conf [2389,2393]
name: conf [2403,2407]
===
match
---
operator: @ [18427,18428]
operator: @ [18441,18442]
===
match
---
name: task_publish_max_retries [8534,8558]
name: task_publish_max_retries [8548,8572]
===
match
---
name: values [11125,11131]
name: values [11139,11145]
===
match
---
name: task [7439,7443]
name: task [7453,7457]
===
match
---
expr_stmt [8407,8450]
expr_stmt [8421,8464]
===
match
---
argument [8352,8382]
argument [8366,8396]
===
match
---
operator: == [10542,10544]
operator: == [10556,10558]
===
match
---
atom_expr [20292,20349]
atom_expr [20306,20363]
===
match
---
number: 0 [10567,10568]
number: 0 [10581,10582]
===
match
---
name: start_date [13198,13208]
name: start_date [13212,13222]
===
match
---
trailer [15360,15400]
trailer [15374,15414]
===
match
---
name: BaseOperator [15505,15517]
name: BaseOperator [15519,15531]
===
match
---
dictorsetmaker [10125,10131]
dictorsetmaker [10139,10145]
===
match
---
number: 1 [10152,10153]
number: 1 [10166,10167]
===
match
---
name: unittest [16932,16940]
name: unittest [16946,16954]
===
match
---
name: mock_backend [19900,19912]
name: mock_backend [19914,19926]
===
match
---
operator: { [18113,18114]
operator: { [18127,18128]
===
match
---
suite [5491,5631]
suite [5505,5645]
===
match
---
operator: , [12006,12007]
operator: , [12020,12021]
===
match
---
atom_expr [16115,16127]
atom_expr [16129,16141]
===
match
---
name: cm [20153,20155]
name: cm [20167,20169]
===
match
---
name: test_operation_timeout_config [16259,16288]
name: test_operation_timeout_config [16273,16302]
===
match
---
name: db [1941,1943]
name: db [1955,1957]
===
match
---
atom [7807,7842]
atom [7821,7856]
===
match
---
number: 0 [7703,7704]
number: 0 [7717,7718]
===
match
---
atom_expr [14152,14176]
atom_expr [14166,14190]
===
match
---
name: asynchronous [1321,1333]
name: asynchronous [1335,1347]
===
match
---
if_stmt [4167,4245]
if_stmt [4181,4259]
===
match
---
operator: , [15712,15713]
operator: , [15726,15727]
===
match
---
atom_expr [15920,15950]
atom_expr [15934,15964]
===
match
---
atom_expr [9248,9277]
atom_expr [9262,9291]
===
match
---
trailer [18713,18720]
trailer [18727,18734]
===
match
---
name: dict [9243,9247]
name: dict [9257,9261]
===
match
---
atom_expr [4430,4446]
atom_expr [4444,4460]
===
match
---
string: 'SUCCESS' [19497,19506]
string: 'SUCCESS' [19511,19520]
===
match
---
trailer [12624,12626]
trailer [12638,12640]
===
match
---
name: task_adoption_timeout [15929,15950]
name: task_adoption_timeout [15943,15964]
===
match
---
name: event_buffer [10243,10255]
name: event_buffer [10257,10269]
===
match
---
dotted_name [1879,1898]
dotted_name [1893,1912]
===
match
---
argument [17376,17399]
argument [17390,17413]
===
match
---
operator: == [6146,6148]
operator: == [6160,6162]
===
match
---
decorators [19690,19811]
decorators [19704,19825]
===
match
---
operator: = [9080,9081]
operator: = [9094,9095]
===
match
---
atom [9439,9610]
atom [9453,9624]
===
match
---
simple_stmt [8612,8748]
simple_stmt [8626,8762]
===
match
---
comparison [10152,10183]
comparison [10166,10197]
===
match
---
operator: = [14177,14178]
operator: = [14191,14192]
===
match
---
name: patch [2728,2733]
name: patch [2742,2747]
===
match
---
import_from [1397,1435]
import_from [1411,1449]
===
match
---
decorator [3763,3809]
decorator [3777,3823]
===
match
---
suite [3703,3758]
suite [3717,3772]
===
match
---
testlist_comp [19497,19512]
testlist_comp [19511,19526]
===
match
---
atom_expr [13373,13411]
atom_expr [13387,13425]
===
match
---
operator: , [15885,15886]
operator: , [15899,15900]
===
match
---
atom_expr [3302,3325]
atom_expr [3316,3339]
===
match
---
assert_stmt [9806,9840]
assert_stmt [9820,9854]
===
match
---
name: minutes [13683,13690]
name: minutes [13697,13704]
===
match
---
name: self [16721,16725]
name: self [16735,16739]
===
match
---
atom_expr [11050,11134]
atom_expr [11064,11148]
===
match
---
trailer [3668,3670]
trailer [3682,3684]
===
match
---
comparison [8525,8563]
comparison [8539,8577]
===
match
---
argument [13891,13907]
argument [13905,13921]
===
match
---
funcdef [16840,16903]
funcdef [16854,16917]
===
match
---
decorator [16956,17113]
decorator [16970,17127]
===
match
---
operator: == [18297,18299]
operator: == [18311,18313]
===
match
---
name: dag_id [15679,15685]
name: dag_id [15693,15699]
===
match
---
simple_stmt [16173,16201]
simple_stmt [16187,16215]
===
match
---
name: DatabaseBackend [1201,1216]
name: DatabaseBackend [1215,1230]
===
match
---
name: MagicMock [19920,19929]
name: MagicMock [19934,19943]
===
match
---
assert_stmt [9385,9419]
assert_stmt [9399,9433]
===
match
---
suite [2254,2280]
suite [2268,2294]
===
match
---
simple_stmt [20219,20474]
simple_stmt [20233,20488]
===
match
---
atom [12886,12899]
atom [12900,12913]
===
match
---
name: backend [15053,15060]
name: backend [15067,15074]
===
match
---
name: BaseOperator [1653,1665]
name: BaseOperator [1667,1679]
===
match
---
atom [5748,5900]
atom [5762,5914]
===
match
---
expr_stmt [7304,7496]
expr_stmt [7318,7510]
===
match
---
trailer [7843,7846]
trailer [7857,7860]
===
match
---
name: execute_command [4901,4916]
name: execute_command [4915,4930]
===
match
---
argument [13909,13930]
argument [13923,13944]
===
match
---
string: "SUCCESS" [19152,19161]
string: "SUCCESS" [19166,19175]
===
match
---
name: pytest [18469,18475]
name: pytest [18483,18489]
===
match
---
trailer [16554,16560]
trailer [16568,16574]
===
match
---
string: 'airflow.executors.celery_executor._execute_in_subprocess' [12261,12319]
string: 'airflow.executors.celery_executor._execute_in_subprocess' [12275,12333]
===
match
---
name: dag [14529,14532]
name: dag [14543,14546]
===
match
---
operator: , [15459,15460]
operator: , [15473,15474]
===
match
---
operator: + [15918,15919]
operator: + [15932,15933]
===
match
---
trailer [10242,10255]
trailer [10256,10269]
===
match
---
atom_expr [14529,14539]
atom_expr [14543,14553]
===
match
---
name: get [2394,2397]
name: get [2408,2411]
===
match
---
number: 0 [6139,6140]
number: 0 [6153,6154]
===
match
---
name: timedelta [6568,6577]
name: timedelta [6582,6591]
===
match
---
expr_stmt [13038,13088]
expr_stmt [13052,13102]
===
match
---
name: self [16619,16623]
name: self [16633,16637]
===
match
---
string: "postgres" [19799,19809]
string: "postgres" [19813,19823]
===
match
---
name: mark [7876,7880]
name: mark [7890,7894]
===
match
---
name: utcnow [13602,13608]
name: utcnow [13616,13622]
===
match
---
simple_stmt [4214,4245]
simple_stmt [4228,4259]
===
match
---
operator: = [8718,8719]
operator: = [8732,8733]
===
match
---
trailer [7645,7650]
trailer [7659,7664]
===
match
---
trailer [14155,14176]
trailer [14169,14190]
===
match
---
trailer [12606,12624]
trailer [12620,12638]
===
match
---
name: try_number [14568,14578]
name: try_number [14582,14592]
===
match
---
param [17283,17292]
param [17297,17306]
===
match
---
name: AsyncResult [15995,16006]
name: AsyncResult [16009,16020]
===
match
---
arglist [18801,18868]
arglist [18815,18882]
===
match
---
operator: } [14996,14997]
operator: } [15010,15011]
===
match
---
name: celery [1222,1228]
name: celery [1236,1242]
===
match
---
atom [15032,15034]
atom [15046,15048]
===
match
---
name: TestCase [3577,3585]
name: TestCase [3591,3599]
===
match
---
name: tasks [11002,11007]
name: tasks [11016,11021]
===
match
---
simple_stmt [9236,9291]
simple_stmt [9250,9305]
===
match
---
trailer [20244,20473]
trailer [20258,20487]
===
match
---
for_stmt [16530,16602]
for_stmt [16544,16616]
===
match
---
operator: } [4416,4417]
operator: } [4430,4431]
===
match
---
trailer [15292,15294]
trailer [15306,15308]
===
match
---
arith_expr [13051,13088]
arith_expr [13065,13102]
===
match
---
operator: - [13671,13672]
operator: - [13685,13686]
===
match
---
string: 'run' [4032,4037]
string: 'run' [4046,4051]
===
match
---
dotted_name [1706,1733]
dotted_name [1720,1747]
===
match
---
atom_expr [11805,11813]
atom_expr [11819,11827]
===
match
---
simple_stmt [5648,5693]
simple_stmt [5662,5707]
===
match
---
atom_expr [14457,14495]
atom_expr [14471,14509]
===
match
---
name: executor [16216,16224]
name: executor [16230,16238]
===
match
---
name: fetcher [17675,17682]
name: fetcher [17689,17696]
===
match
---
trailer [9318,9341]
trailer [9332,9355]
===
match
---
funcdef [1946,2144]
funcdef [1960,2158]
===
match
---
name: when [8760,8764]
name: when [8774,8778]
===
match
---
return_stmt [2263,2279]
return_stmt [2277,2293]
===
match
---
name: mark [6712,6716]
name: mark [6726,6730]
===
match
---
trailer [13027,13029]
trailer [13041,13043]
===
match
---
name: days [13081,13085]
name: days [13095,13099]
===
match
---
testlist_comp [2034,2038]
testlist_comp [2048,2052]
===
match
---
name: get_many [19280,19288]
name: get_many [19294,19302]
===
match
---
name: tasks [4406,4411]
name: tasks [4420,4425]
===
match
---
operator: == [10256,10258]
operator: == [10270,10272]
===
match
---
argument [7423,7480]
argument [7437,7494]
===
match
---
trailer [13066,13068]
trailer [13080,13082]
===
match
---
operator: @ [11370,11371]
operator: @ [11384,11385]
===
match
---
name: pytest [1052,1058]
name: pytest [1066,1072]
===
match
---
operator: { [19141,19142]
operator: { [19155,19156]
===
match
---
decorator [19769,19811]
decorator [19783,19825]
===
match
---
name: task [8934,8938]
name: task [8948,8952]
===
match
---
with_stmt [12232,12900]
with_stmt [12246,12914]
===
match
---
name: queued_tasks [9749,9761]
name: queued_tasks [9763,9775]
===
match
---
arith_expr [15217,15254]
arith_expr [15231,15268]
===
match
---
operator: == [9414,9416]
operator: == [9428,9430]
===
match
---
operator: , [17029,17030]
operator: , [17043,17044]
===
match
---
argument [18855,18868]
argument [18869,18882]
===
match
---
trailer [19395,19405]
trailer [19409,19419]
===
match
---
assert_stmt [18174,18309]
assert_stmt [18188,18323]
===
match
---
fstring [9530,9583]
fstring [9544,9597]
===
match
---
name: _process_tasks [5657,5671]
name: _process_tasks [5671,5685]
===
match
---
atom_expr [19391,19420]
atom_expr [19405,19434]
===
match
---
testlist_comp [19523,19538]
testlist_comp [19537,19552]
===
match
---
raise_stmt [2213,2230]
raise_stmt [2227,2244]
===
match
---
name: datetime [8719,8727]
name: datetime [8733,8741]
===
match
---
name: celery_executor [12707,12722]
name: celery_executor [12721,12736]
===
match
---
atom_expr [15297,15318]
atom_expr [15311,15332]
===
match
---
atom_expr [6022,6034]
atom_expr [6036,6048]
===
match
---
comparison [16803,16834]
comparison [16817,16848]
===
match
---
trailer [18933,18947]
trailer [18947,18961]
===
match
---
number: 0 [7548,7549]
number: 0 [7562,7563]
===
match
---
testlist_comp [10678,10711]
testlist_comp [10692,10725]
===
match
---
trailer [3627,3641]
trailer [3641,3655]
===
match
---
operator: = [4515,4516]
operator: = [4529,4530]
===
match
---
atom_expr [17308,17322]
atom_expr [17322,17336]
===
match
---
name: len [7708,7711]
name: len [7722,7725]
===
match
---
decorator [15040,15082]
decorator [15054,15096]
===
match
---
operator: == [16247,16249]
operator: == [16261,16263]
===
match
---
atom_expr [13237,13283]
atom_expr [13251,13297]
===
match
---
trailer [2815,2882]
trailer [2829,2896]
===
match
---
suite [3616,3671]
suite [3630,3685]
===
match
---
argument [11155,11228]
argument [11169,11242]
===
match
---
name: any [11245,11248]
name: any [11259,11262]
===
match
---
assert_stmt [4390,4417]
assert_stmt [4404,4431]
===
match
---
name: celery_executor [8418,8433]
name: celery_executor [8432,8447]
===
match
---
name: heartbeat [9633,9642]
name: heartbeat [9647,9656]
===
match
---
trailer [6191,6209]
trailer [6205,6223]
===
match
---
name: self [16851,16855]
name: self [16865,16869]
===
match
---
name: calls [11927,11932]
name: calls [11941,11946]
===
match
---
expr_stmt [13639,13693]
expr_stmt [13653,13707]
===
match
---
argument [15536,15557]
argument [15550,15571]
===
match
---
name: __eq__ [16889,16895]
name: __eq__ [16903,16909]
===
match
---
name: command [12739,12746]
name: command [12753,12760]
===
match
---
trailer [13890,13931]
trailer [13904,13945]
===
match
---
name: mark [19698,19702]
name: mark [19712,19716]
===
match
---
trailer [7584,7589]
trailer [7598,7603]
===
match
---
trailer [11751,11755]
trailer [11765,11769]
===
match
---
name: __dict__ [16808,16816]
name: __dict__ [16822,16830]
===
match
---
simple_stmt [15568,15643]
simple_stmt [15582,15657]
===
match
---
name: celery_executor [17380,17395]
name: celery_executor [17394,17409]
===
match
---
number: 0 [5028,5029]
number: 0 [5042,5043]
===
match
---
parameters [6777,6783]
parameters [6791,6797]
===
match
---
name: celery_configuration [4817,4837]
name: celery_configuration [4831,4851]
===
match
---
name: celery_executor [12537,12552]
name: celery_executor [12551,12566]
===
match
---
name: minutes [15184,15191]
name: minutes [15198,15205]
===
match
---
trailer [15863,15885]
trailer [15877,15899]
===
match
---
atom_expr [2923,2956]
atom_expr [2937,2970]
===
match
---
operator: , [17105,17106]
operator: , [17119,17120]
===
match
---
simple_stmt [817,827]
simple_stmt [817,827]
===
match
---
name: result [18103,18109]
name: result [18117,18123]
===
match
---
expr_stmt [19263,19461]
expr_stmt [19277,19475]
===
match
---
string: 'airflow.executors.celery_executor.CeleryExecutor.trigger_tasks' [11382,11446]
string: 'airflow.executors.celery_executor.CeleryExecutor.trigger_tasks' [11396,11460]
===
match
---
comparison [9310,9341]
comparison [9324,9355]
===
match
---
trailer [19980,19987]
trailer [19994,20001]
===
match
---
arglist [11780,11813]
arglist [11794,11827]
===
match
---
operator: { [8503,8504]
operator: { [8517,8518]
===
match
---
name: executor [9053,9061]
name: executor [9067,9075]
===
match
---
arith_expr [13531,13571]
arith_expr [13545,13585]
===
match
---
string: 'BROKER_URL' [2408,2420]
string: 'BROKER_URL' [2422,2434]
===
match
---
string: 'DEBUG:airflow.executors.celery_executor.BulkStateFetcher:Fetched 2 state(s) for 2 task(s)' [18195,18286]
string: 'DEBUG:airflow.executors.celery_executor.BulkStateFetcher:Fetched 2 state(s) for 2 task(s)' [18209,18300]
===
match
---
name: start_date [13834,13844]
name: start_date [13848,13858]
===
match
---
name: models [1679,1685]
name: models [1693,1699]
===
match
---
operator: , [5060,5061]
operator: , [5074,5075]
===
match
---
operator: == [10121,10123]
operator: == [10135,10137]
===
match
---
name: assertLogs [10886,10896]
name: assertLogs [10900,10910]
===
match
---
operator: , [12053,12054]
operator: , [12067,12068]
===
match
---
atom [20508,20525]
atom [20522,20539]
===
match
---
name: test_gauge_executor_metrics [11519,11546]
name: test_gauge_executor_metrics [11533,11560]
===
match
---
atom_expr [11663,11683]
atom_expr [11677,11697]
===
match
---
name: CeleryExecutor [8434,8448]
name: CeleryExecutor [8448,8462]
===
match
---
argument [13960,13971]
argument [13974,13985]
===
match
---
name: executor [6076,6084]
name: executor [6090,6098]
===
match
---
name: integration [17168,17179]
name: integration [17182,17193]
===
match
---
trailer [6234,6247]
trailer [6248,6261]
===
match
---
name: mock_trigger_tasks [11571,11589]
name: mock_trigger_tasks [11585,11603]
===
match
---
name: object [18714,18720]
name: object [18728,18734]
===
match
---
operator: , [7216,7217]
operator: , [7230,7231]
===
match
---
name: BaseOperator [13167,13179]
name: BaseOperator [13181,13193]
===
match
---
string: "redis" [18414,18421]
string: "redis" [18428,18435]
===
match
---
trailer [14283,14298]
trailer [14297,14312]
===
match
---
funcdef [10813,11292]
funcdef [10827,11306]
===
match
---
name: update [2569,2575]
name: update [2583,2589]
===
match
---
simple_stmt [1310,1356]
simple_stmt [1324,1370]
===
match
---
operator: = [17349,17350]
operator: = [17363,17364]
===
match
---
operator: == [10717,10719]
operator: == [10731,10733]
===
match
---
testlist_comp [5405,5441]
testlist_comp [5419,5455]
===
match
---
trailer [9074,9079]
trailer [9088,9093]
===
match
---
import_from [1356,1395]
import_from [1370,1409]
===
match
---
string: 'executor.running_tasks' [11838,11862]
string: 'executor.running_tasks' [11852,11876]
===
match
---
name: task_adoption_timeout [14877,14898]
name: task_adoption_timeout [14891,14912]
===
match
---
operator: = [13823,13824]
operator: = [13837,13838]
===
match
---
comparison [10506,10547]
comparison [10520,10561]
===
match
---
simple_stmt [2789,2883]
simple_stmt [2803,2897]
===
match
---
arglist [19790,19809]
arglist [19804,19823]
===
match
---
atom_expr [8916,8970]
atom_expr [8930,8984]
===
match
---
atom [12847,12857]
atom [12861,12871]
===
match
---
name: pytest [3852,3858]
name: pytest [3866,3872]
===
match
---
atom [11996,12018]
atom [12010,12032]
===
match
---
testlist_comp [5770,5882]
testlist_comp [5784,5896]
===
match
---
trailer [2733,2784]
trailer [2747,2798]
===
match
---
name: return_value [17039,17051]
name: return_value [17053,17065]
===
match
---
operator: = [7228,7229]
operator: = [7242,7243]
===
match
---
name: test_config [2652,2663]
name: test_config [2666,2677]
===
match
---
atom [4088,4110]
atom [4102,4124]
===
match
---
simple_stmt [15496,15559]
simple_stmt [15510,15573]
===
match
---
parameters [16288,16290]
parameters [16302,16304]
===
match
---
testlist_comp [4988,5029]
testlist_comp [5002,5043]
===
match
---
name: key [7509,7512]
name: key [7523,7526]
===
match
---
import_from [854,894]
import_from [868,908]
===
match
---
name: task_id [19351,19358]
name: task_id [19365,19372]
===
match
---
atom_expr [12347,12411]
atom_expr [12361,12425]
===
match
---
name: celery_executor [13324,13339]
name: celery_executor [13338,13353]
===
match
---
operator: , [8313,8314]
operator: , [8327,8328]
===
match
---
trailer [16669,16678]
trailer [16683,16692]
===
match
---
name: self [12990,12994]
name: self [13004,13008]
===
match
---
operator: } [6551,6552]
operator: } [6565,6566]
===
match
---
string: "mysql" [15061,15068]
string: "mysql" [15075,15082]
===
match
---
name: cm [10429,10431]
name: cm [10443,10445]
===
match
---
parameters [18548,18568]
parameters [18562,18582]
===
match
---
comparison [14316,14341]
comparison [14330,14355]
===
match
---
name: queued_dttm [15906,15917]
name: queued_dttm [15920,15931]
===
match
---
simple_stmt [1504,1550]
simple_stmt [1518,1564]
===
match
---
string: "mysql" [3913,3920]
string: "mysql" [3927,3934]
===
match
---
trailer [4568,4570]
trailer [4582,4584]
===
match
---
simple_stmt [5917,6053]
simple_stmt [5931,6067]
===
match
---
atom [17713,17846]
atom [17727,17860]
===
match
---
operator: { [6550,6551]
operator: { [6564,6565]
===
match
---
argument [20416,20431]
argument [20430,20445]
===
match
---
operator: = [7464,7465]
operator: = [7478,7479]
===
match
---
trailer [8154,8156]
trailer [8168,8170]
===
match
---
operator: = [7590,7591]
operator: = [7604,7605]
===
match
---
name: timedelta [13613,13622]
name: timedelta [13627,13636]
===
match
---
name: cm [18886,18888]
name: cm [18900,18902]
===
match
---
operator: , [8382,8383]
operator: , [8396,8397]
===
match
---
expr_stmt [2426,2490]
expr_stmt [2440,2504]
===
match
---
name: mock [16957,16961]
name: mock [16971,16975]
===
match
---
operator: , [2037,2038]
operator: , [2051,2052]
===
match
---
argument [13198,13219]
argument [13212,13233]
===
match
---
file_input [787,20697]
file_input [787,22291]
===
match
---
trailer [13020,13027]
trailer [13034,13041]
===
match
---
name: BaseKeyValueStoreBackend [1131,1155]
name: BaseKeyValueStoreBackend [1145,1169]
===
match
---
atom_expr [18626,18684]
atom_expr [18640,18698]
===
match
---
operator: , [18008,18009]
operator: , [18022,18023]
===
match
---
simple_stmt [1436,1504]
simple_stmt [1450,1518]
===
match
---
atom_expr [2515,2551]
atom_expr [2529,2565]
===
match
---
suite [2957,3350]
suite [2971,3364]
===
match
---
name: result [20219,20225]
name: result [20233,20239]
===
match
---
name: broker_url [2326,2336]
name: broker_url [2340,2350]
===
match
---
name: database [1185,1193]
name: database [1199,1207]
===
match
---
name: app [17396,17399]
name: app [17410,17413]
===
match
---
name: utils [1852,1857]
name: utils [1866,1871]
===
match
---
name: CeleryExecutor [15762,15776]
name: CeleryExecutor [15776,15790]
===
match
---
argument [20333,20348]
argument [20347,20362]
===
match
---
string: 'version' [4100,4109]
string: 'version' [4114,4123]
===
match
---
name: event_buffer [9401,9413]
name: event_buffer [9415,9427]
===
match
---
name: test_should_support_base_backend [19819,19851]
name: test_should_support_base_backend [19833,19865]
===
match
---
operator: == [8500,8502]
operator: == [8514,8516]
===
match
---
atom_expr [18043,18086]
atom_expr [18057,18100]
===
match
---
argument [8665,8684]
argument [8679,8698]
===
match
---
name: adopted_task_timeouts [14742,14763]
name: adopted_task_timeouts [14756,14777]
===
match
---
operator: == [9700,9702]
operator: == [9714,9716]
===
match
---
comparison [1981,2015]
comparison [1995,2029]
===
match
---
name: execute [2436,2443]
name: execute [2450,2457]
===
match
---
trailer [11637,11652]
trailer [11651,11666]
===
match
---
atom_expr [9203,9223]
atom_expr [9217,9237]
===
match
---
operator: } [18164,18165]
operator: } [18178,18179]
===
match
---
name: json [812,816]
name: json [812,816]
===
match
---
param [16721,16725]
param [16735,16739]
===
match
---
name: mark [10746,10750]
name: mark [10760,10764]
===
match
---
suite [12143,12900]
suite [12157,12914]
===
match
---
name: key [9997,10000]
name: key [10011,10014]
===
match
---
name: try_number [14651,14661]
name: try_number [14665,14675]
===
match
---
operator: , [18138,18139]
operator: , [18152,18153]
===
match
---
simple_stmt [1874,1912]
simple_stmt [1888,1926]
===
match
---
operator: = [8363,8364]
operator: = [8377,8378]
===
match
---
name: tests [1917,1922]
name: tests [1931,1936]
===
match
---
trailer [3323,3325]
trailer [3337,3339]
===
match
---
number: 0 [7844,7845]
number: 0 [7858,7859]
===
match
---
operator: , [20432,20433]
operator: , [20446,20447]
===
match
---
name: executor [9319,9327]
name: executor [9333,9341]
===
match
---
simple_stmt [10078,10133]
simple_stmt [10092,10147]
===
match
---
string: 'DEBUG:airflow.executors.celery_executor.BulkStateFetcher:Fetched 2 state(s) for 2 task(s)' [20582,20673]
string: 'DEBUG:airflow.executors.celery_executor.BulkStateFetcher:Fetched 2 state(s) for 2 task(s)' [20596,20687]
===
match
---
operator: = [7199,7200]
operator: = [7213,7214]
===
match
---
name: expand [3778,3784]
name: expand [3792,3798]
===
match
---
param [12114,12122]
param [12128,12136]
===
match
---
name: start_worker [1259,1271]
name: start_worker [1273,1285]
===
match
---
string: "123" [17097,17102]
string: "123" [17111,17116]
===
match
---
trailer [19113,19182]
trailer [19127,19196]
===
match
---
name: _prepare_test_bodies [1950,1970]
name: _prepare_test_bodies [1964,1984]
===
match
---
trailer [20317,20349]
trailer [20331,20363]
===
match
---
atom_expr [2898,2914]
atom_expr [2912,2928]
===
match
---
dictorsetmaker [11011,11036]
dictorsetmaker [11025,11050]
===
match
---
operator: , [5812,5813]
operator: , [5826,5827]
===
match
---
name: _prepare_app [19872,19884]
name: _prepare_app [19886,19898]
===
match
---
trailer [9247,9278]
trailer [9261,9292]
===
match
---
decorator [6704,6746]
decorator [6718,6760]
===
match
---
name: task_id [7159,7166]
name: task_id [7173,7180]
===
match
---
trailer [11109,11134]
trailer [11123,11148]
===
match
---
name: queued_tasks [7721,7733]
name: queued_tasks [7735,7747]
===
match
---
suite [11602,11934]
suite [11616,11948]
===
match
---
atom_expr [2805,2882]
atom_expr [2819,2896]
===
match
---
operator: == [16195,16197]
operator: == [16209,16211]
===
match
---
name: integration [19703,19714]
name: integration [19717,19728]
===
match
---
trailer [11926,11933]
trailer [11940,11947]
===
match
---
trailer [15678,15685]
trailer [15692,15699]
===
match
---
operator: , [7832,7833]
operator: , [7846,7847]
===
match
---
operator: , [5182,5183]
operator: , [5196,5197]
===
match
---
operator: { [17064,17065]
operator: { [17078,17079]
===
match
---
arglist [7439,7479]
arglist [7453,7493]
===
match
---
comparison [13373,13418]
comparison [13387,13432]
===
match
---
name: state [1893,1898]
name: state [1907,1912]
===
match
---
atom_expr [10161,10182]
atom_expr [10175,10196]
===
match
---
name: os [2005,2007]
name: os [2019,2021]
===
match
---
string: "mysql" [19790,19797]
string: "mysql" [19804,19811]
===
match
---
number: 0 [6016,6017]
number: 0 [6030,6031]
===
match
---
atom_expr [15277,15294]
atom_expr [15291,15308]
===
match
---
atom_expr [5208,5239]
atom_expr [5222,5253]
===
match
---
expr_stmt [7270,7291]
expr_stmt [7284,7305]
===
match
---
name: event_buffer [7794,7806]
name: event_buffer [7808,7820]
===
match
---
name: success_command [3993,4008]
name: success_command [4007,4022]
===
match
---
operator: = [17575,17576]
operator: = [17589,17590]
===
match
---
trailer [8533,8558]
trailer [8547,8572]
===
match
---
name: kwargs [16548,16554]
name: kwargs [16562,16568]
===
match
---
operator: = [8933,8934]
operator: = [8947,8948]
===
match
---
parameters [8029,8035]
parameters [8043,8049]
===
match
---
trailer [10963,10978]
trailer [10977,10992]
===
match
---
atom [6248,6294]
atom [6262,6308]
===
match
---
arglist [13180,13219]
arglist [13194,13233]
===
match
---
operator: @ [11452,11453]
operator: @ [11466,11467]
===
match
---
name: integration [17130,17141]
name: integration [17144,17155]
===
match
---
operator: , [13907,13908]
operator: , [13921,13922]
===
match
---
name: executor [5722,5730]
name: executor [5736,5744]
===
match
---
operator: , [4485,4486]
operator: , [4499,4500]
===
match
---
simple_stmt [17666,17865]
simple_stmt [17680,17879]
===
match
---
operator: } [10260,10261]
operator: } [10274,10275]
===
match
---
operator: = [2373,2374]
operator: = [2387,2388]
===
match
---
string: "232" [16034,16039]
string: "232" [16048,16053]
===
match
---
operator: , [12857,12858]
operator: , [12871,12872]
===
match
---
simple_stmt [13519,13572]
simple_stmt [13533,13586]
===
match
---
string: "PENDING" [19523,19532]
string: "PENDING" [19537,19546]
===
match
---
name: bash_command [8665,8677]
name: bash_command [8679,8691]
===
match
---
trailer [17487,17498]
trailer [17501,17512]
===
match
---
argument [20401,20414]
argument [20415,20428]
===
match
---
atom_expr [16681,16699]
atom_expr [16695,16713]
===
match
---
string: 'run' [12055,12060]
string: 'run' [12069,12074]
===
insert-tree
---
simple_stmt [827,841]
    import_name [827,840]
        name: signal [834,840]
to
file_input [787,20697]
at 3
===
insert-tree
---
classdef [20713,20929]
    name: MockTask [20719,20727]
    suite [20728,20929]
        simple_stmt [20733,20867]
            string: """     A picklable object used to mock tasks sent to Celery. Can't use the mock library     here because it's not picklable.     """ [20733,20866]
        funcdef [20872,20929]
            name: apply_async [20876,20887]
            parameters [20887,20910]
                param [20888,20893]
                    name: self [20888,20892]
                    operator: , [20892,20893]
                param [20894,20900]
                    operator: * [20894,20895]
                    name: args [20895,20899]
                    operator: , [20899,20900]
                param [20901,20909]
                    operator: ** [20901,20903]
                    name: kwargs [20903,20909]
            suite [20911,20929]
                simple_stmt [20920,20929]
                    return_stmt [20920,20928]
                        number: 1 [20927,20928]
to
file_input [787,20697]
at 35
===
insert-tree
---
funcdef [20931,21063]
    name: _exit_gracefully [20935,20951]
    parameters [20951,20962]
        param [20952,20959]
            name: signum [20952,20958]
            operator: , [20958,20959]
        param [20960,20961]
            name: _ [20960,20961]
    suite [20963,21063]
        simple_stmt [20968,21042]
            atom_expr [20968,21041]
                name: print [20968,20973]
                trailer [20973,21041]
                    fstring [20974,21040]
                        fstring_start: f" [20974,20976]
                        fstring_expr [20976,20989]
                            operator: { [20976,20977]
                            atom_expr [20977,20988]
                                name: os [20977,20979]
                                trailer [20979,20986]
                                    name: getpid [20980,20986]
                                trailer [20986,20988]
                            operator: } [20988,20989]
                        fstring_string:  Exiting gracefully upon receiving signal  [20989,21031]
                        fstring_expr [21031,21039]
                            operator: { [21031,21032]
                            name: signum [21032,21038]
                            operator: } [21038,21039]
                        fstring_end: " [21039,21040]
        simple_stmt [21046,21063]
            atom_expr [21046,21062]
                name: sys [21046,21049]
                trailer [21049,21054]
                    name: exit [21050,21054]
                trailer [21054,21062]
                    name: signum [21055,21061]
to
file_input [787,20697]
at 36
===
insert-tree
---
decorated [21065,21695]
    decorator [21065,21081]
        operator: @ [21065,21066]
        dotted_name [21066,21080]
            name: pytest [21066,21072]
            name: fixture [21073,21080]
    funcdef [21081,21695]
        name: register_signals [21085,21101]
        parameters [21101,21103]
        suite [21104,21695]
            simple_stmt [21109,21228]
                string: """     Register the same signals as scheduler does to test celery_executor to make sure it does not     hang.     """ [21109,21227]
            simple_stmt [21232,21291]
                expr_stmt [21232,21290]
                    name: orig_sigint [21232,21243]
                    operator: = [21244,21245]
                    name: orig_sigterm [21246,21258]
                    operator: = [21259,21260]
                    name: orig_sigusr2 [21261,21273]
                    operator: = [21274,21275]
                    atom_expr [21276,21290]
                        name: signal [21276,21282]
                        trailer [21282,21290]
                            name: SIG_DFL [21283,21290]
            simple_stmt [21296,21357]
                expr_stmt [21296,21356]
                    name: orig_sigint [21296,21307]
                    operator: = [21308,21309]
                    atom_expr [21310,21356]
                        name: signal [21310,21316]
                        trailer [21316,21323]
                            name: signal [21317,21323]
                        trailer [21323,21356]
                            arglist [21324,21355]
                                atom_expr [21324,21337]
                                    name: signal [21324,21330]
                                    trailer [21330,21337]
                                        name: SIGINT [21331,21337]
                                operator: , [21337,21338]
                                name: _exit_gracefully [21339,21355]
            simple_stmt [21361,21424]
                expr_stmt [21361,21423]
                    name: orig_sigterm [21361,21373]
                    operator: = [21374,21375]
                    atom_expr [21376,21423]
                        name: signal [21376,21382]
                        trailer [21382,21389]
                            name: signal [21383,21389]
                        trailer [21389,21423]
                            arglist [21390,21422]
                                atom_expr [21390,21404]
                                    name: signal [21390,21396]
                                    trailer [21396,21404]
                                        name: SIGTERM [21397,21404]
                                operator: , [21404,21405]
                                name: _exit_gracefully [21406,21422]
            simple_stmt [21428,21491]
                expr_stmt [21428,21490]
                    name: orig_sigusr2 [21428,21440]
                    operator: = [21441,21442]
                    atom_expr [21443,21490]
                        name: signal [21443,21449]
                        trailer [21449,21456]
                            name: signal [21450,21456]
                        trailer [21456,21490]
                            arglist [21457,21489]
                                atom_expr [21457,21471]
                                    name: signal [21457,21463]
                                    trailer [21463,21471]
                                        name: SIGUSR2 [21464,21471]
                                operator: , [21471,21472]
                                name: _exit_gracefully [21473,21489]
            simple_stmt [21496,21502]
            simple_stmt [21557,21599]
                atom_expr [21557,21598]
                    name: signal [21557,21563]
                    trailer [21563,21570]
                        name: signal [21564,21570]
                    trailer [21570,21598]
                        arglist [21571,21597]
                            atom_expr [21571,21584]
                                name: signal [21571,21577]
                                trailer [21577,21584]
                                    name: SIGINT [21578,21584]
                            operator: , [21584,21585]
                            name: orig_sigint [21586,21597]
            simple_stmt [21603,21647]
                atom_expr [21603,21646]
                    name: signal [21603,21609]
                    trailer [21609,21616]
                        name: signal [21610,21616]
                    trailer [21616,21646]
                        arglist [21617,21645]
                            atom_expr [21617,21631]
                                name: signal [21617,21623]
                                trailer [21623,21631]
                                    name: SIGTERM [21624,21631]
                            operator: , [21631,21632]
                            name: orig_sigterm [21633,21645]
            simple_stmt [21651,21695]
                atom_expr [21651,21694]
                    name: signal [21651,21657]
                    trailer [21657,21664]
                        name: signal [21658,21664]
                    trailer [21664,21694]
                        arglist [21665,21693]
                            atom_expr [21665,21679]
                                name: signal [21665,21671]
                                trailer [21671,21679]
                                    name: SIGUSR2 [21672,21679]
                            operator: , [21679,21680]
                            name: orig_sigusr2 [21681,21693]
to
file_input [787,20697]
at 37
===
insert-tree
---
funcdef [21697,22291]
    name: test_send_tasks_to_celery_hang [21701,21731]
    parameters [21731,21749]
        param [21732,21748]
            name: register_signals [21732,21748]
    suite [21785,22291]
        simple_stmt [21790,21863]
            string: """     Test that celery_executor does not hang after many runs.     """ [21790,21862]
        simple_stmt [21867,21911]
            expr_stmt [21867,21910]
                name: executor [21867,21875]
                operator: = [21876,21877]
                atom_expr [21878,21910]
                    name: celery_executor [21878,21893]
                    trailer [21893,21908]
                        name: CeleryExecutor [21894,21908]
                    trailer [21908,21910]
        simple_stmt [21916,21934]
            expr_stmt [21916,21933]
                name: task [21916,21920]
                operator: = [21921,21922]
                atom_expr [21923,21933]
                    name: MockTask [21923,21931]
                    trailer [21931,21933]
        simple_stmt [21938,22012]
            expr_stmt [21938,22011]
                name: task_tuples_to_send [21938,21957]
                operator: = [21958,21959]
                atom [21960,22011]
                    testlist_comp [21961,22010]
                        atom [21961,21991]
                            testlist_comp [21962,21990]
                                operator: , [21966,21967]
                                operator: , [21972,21973]
                                operator: , [21978,21979]
                                operator: , [21984,21985]
                                name: task [21986,21990]
                        sync_comp_for [21992,22010]
                            name: _ [21996,21997]
                            atom_expr [22001,22010]
                                name: range [22001,22006]
                                trailer [22006,22010]
                                    number: 26 [22007,22009]
        for_stmt [22017,22291]
            name: _ [22021,22022]
            atom_expr [22026,22036]
                name: range [22026,22031]
                trailer [22031,22036]
                    number: 500 [22032,22035]
            suite [22037,22291]
                simple_stmt [22156,22218]
                    expr_stmt [22156,22217]
                        name: results [22156,22163]
                        operator: = [22164,22165]
                        atom_expr [22166,22217]
                            name: executor [22166,22174]
                            trailer [22174,22196]
                                name: _send_tasks_to_celery [22175,22196]
                            trailer [22196,22217]
                                name: task_tuples_to_send [22197,22216]
                simple_stmt [22226,22291]
                    assert_stmt [22226,22290]
                        comparison [22233,22290]
                            name: results [22233,22240]
                            operator: == [22241,22243]
                            atom [22244,22290]
                                testlist_comp [22245,22289]
                                    atom [22245,22260]
                                        testlist_comp [22246,22259]
                                            operator: , [22250,22251]
                                            operator: , [22256,22257]
                                            number: 1 [22258,22259]
                                    sync_comp_for [22261,22289]
                                        name: _ [22265,22266]
                                        name: task_tuples_to_send [22270,22289]
to
file_input [787,20697]
at 38
