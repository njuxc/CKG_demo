===
match
---
operator: -> [8937,8939]
operator: -> [8982,8984]
===
match
---
trailer [11157,11167]
trailer [11202,11212]
===
match
---
name: log [2264,2267]
name: log [2309,2312]
===
match
---
testlist_comp [11246,11264]
testlist_comp [11291,11309]
===
match
---
fstring_expr [20263,20270]
fstring_expr [19933,19940]
===
match
---
simple_stmt [11319,11358]
simple_stmt [11364,11403]
===
match
---
trailer [16638,16646]
trailer [16308,16316]
===
match
---
arith_expr [4764,4814]
arith_expr [4809,4859]
===
match
---
suite [6835,6883]
suite [6880,6928]
===
match
---
name: self [22145,22149]
name: self [21815,21819]
===
match
---
name: task_publish_retries [10322,10342]
name: task_publish_retries [10367,10387]
===
match
---
operator: , [22387,22388]
operator: , [22057,22058]
===
match
---
operator: , [7804,7805]
operator: , [7849,7850]
===
match
---
expr_stmt [12478,12547]
expr_stmt [12523,12592]
===
match
---
operator: , [12522,12523]
operator: , [12567,12568]
===
match
---
param [2921,2949]
param [2966,2994]
===
match
---
trailer [15954,15960]
trailer [15624,15630]
===
match
---
name: Tuple [20589,20594]
name: Tuple [20259,20264]
===
match
---
param [16522,16531]
param [16192,16201]
===
match
---
parameters [7363,7369]
parameters [7408,7414]
===
match
---
name: conf [2616,2620]
name: conf [2661,2665]
===
match
---
operator: = [19854,19855]
operator: = [19524,19525]
===
match
---
number: 1 [3888,3889]
number: 1 [3933,3934]
===
match
---
name: ti [20199,20201]
name: ti [19869,19871]
===
match
---
name: async_result [21451,21463]
name: async_result [21121,21133]
===
match
---
fstring_expr [6013,6037]
fstring_expr [6058,6082]
===
match
---
name: values [19671,19677]
name: values [19341,19347]
===
match
---
name: cached_celery_backend [9929,9950]
name: cached_celery_backend [9974,9995]
===
match
---
name: net [2117,2120]
name: net [2162,2165]
===
match
---
operator: , [25270,25271]
operator: , [24962,24963]
===
match
---
name: validate_command [3005,3021]
name: validate_command [3050,3066]
===
match
---
name: async_result [21378,21390]
name: async_result [21048,21060]
===
match
---
name: dispose [3734,3741]
name: dispose [3779,3786]
===
match
---
operator: = [24550,24551]
operator: = [24220,24221]
===
match
---
simple_stmt [15762,15797]
simple_stmt [15432,15467]
===
match
---
name: celery_import_modules [6171,6192]
name: celery_import_modules [6216,6237]
===
match
---
funcdef [5156,5304]
funcdef [5201,5349]
===
match
---
trailer [9190,9212]
trailer [9235,9257]
===
match
---
name: incr [10482,10486]
name: incr [10527,10531]
===
match
---
atom [19093,19095]
atom [18763,18765]
===
match
---
string: 'celery' [7692,7700]
string: 'celery' [7737,7745]
===
match
---
name: taskinstance [1939,1951]
name: taskinstance [1984,1996]
===
match
---
number: 0 [19556,19557]
number: 0 [19226,19227]
===
match
---
operator: , [2499,2500]
operator: , [2544,2545]
===
match
---
string: 'SYNC_PARALLELISM' [7702,7720]
string: 'SYNC_PARALLELISM' [7747,7765]
===
match
---
suite [8633,8891]
suite [8678,8936]
===
match
---
param [24268,24291]
param [23938,23961]
===
match
---
atom_expr [7874,7896]
atom_expr [7919,7941]
===
match
---
name: pid [3401,3404]
name: pid [3446,3449]
===
match
---
atom_expr [17510,17521]
atom_expr [17180,17191]
===
match
---
operator: = [17329,17330]
operator: = [16999,17000]
===
match
---
name: key_and_async_results [13016,13037]
name: key_and_async_results [12680,12701]
===
match
---
atom_expr [22535,22584]
atom_expr [22205,22254]
===
match
---
name: celery_states [1271,1284]
name: celery_states [1316,1329]
===
match
---
operator: { [21599,21600]
operator: { [21269,21270]
===
match
---
name: utils [2154,2159]
name: utils [2199,2204]
===
match
---
name: super [15345,15350]
name: super [15015,15020]
===
match
---
name: app [2892,2895]
name: app [2937,2940]
===
match
---
name: celery [1348,1354]
name: celery [1393,1399]
===
match
---
name: timedout_keys [15023,15036]
name: timedout_keys [14693,14706]
===
match
---
atom_expr [16413,16454]
atom_expr [16083,16124]
===
match
---
atom_expr [23090,23131]
atom_expr [22760,22801]
===
match
---
simple_stmt [19603,19616]
simple_stmt [19273,19286]
===
match
---
name: exception_traceback [5197,5216]
name: exception_traceback [5242,5261]
===
match
---
simple_stmt [1534,1609]
simple_stmt [1579,1654]
===
match
---
trailer [15000,15005]
trailer [14670,14675]
===
match
---
import_as_name [1397,1411]
import_as_name [1442,1456]
===
match
---
operator: , [2831,2832]
operator: , [2876,2877]
===
match
---
name: exception [11158,11167]
name: exception [11203,11212]
===
match
---
name: self [15917,15921]
name: self [15587,15591]
===
match
---
argument [25272,25291]
argument [24964,24983]
===
match
---
operator: , [21390,21391]
operator: , [21060,21061]
===
match
---
trailer [8286,8308]
trailer [8331,8353]
===
match
---
trailer [11762,11769]
trailer [11807,11814]
===
match
---
trailer [20594,20640]
trailer [20264,20310]
===
match
---
trailer [4256,4261]
trailer [4301,4306]
===
match
---
name: states_and_info_by_task_id [25319,25345]
name: states_and_info_by_task_id [25012,25038]
===
match
---
simple_stmt [2221,2263]
simple_stmt [2266,2308]
===
match
---
name: __init__ [7355,7363]
name: __init__ [7400,7408]
===
match
---
simple_stmt [4887,5151]
simple_stmt [4932,5196]
===
match
---
if_stmt [19370,19445]
if_stmt [19040,19115]
===
match
---
string: "[Try %s of %s] Task Timeout Error for Task: (%s)." [10575,10626]
string: "[Try %s of %s] Task Timeout Error for Task: (%s)." [10620,10671]
===
match
---
name: key [16394,16397]
name: key [16064,16067]
===
match
---
trailer [4669,4721]
trailer [4714,4766]
===
match
---
name: task_cls [23861,23869]
name: task_cls [23531,23539]
===
match
---
name: task_ids [23882,23890]
name: task_ids [23552,23560]
===
match
---
if_stmt [22532,22862]
if_stmt [22202,22532]
===
match
---
operator: = [9377,9378]
operator: = [9422,9423]
===
match
---
name: min [24950,24953]
name: min [24620,24623]
===
match
---
import_from [1720,1758]
import_from [1765,1803]
===
match
---
name: _execute_in_fork [3265,3281]
name: _execute_in_fork [3310,3326]
===
match
---
atom_expr [12933,12989]
atom_expr [12607,12653]
===
match
---
operator: = [12947,12948]
operator: = [12638,12639]
===
match
---
arglist [21685,21707]
arglist [21355,21377]
===
match
---
trailer [7684,7691]
trailer [7729,7736]
===
match
---
atom_expr [7655,7677]
atom_expr [7700,7722]
===
match
---
expr_stmt [19217,19299]
expr_stmt [18887,18969]
===
match
---
operator: , [20449,20450]
operator: , [20119,20120]
===
match
---
trailer [23288,23291]
trailer [22958,22961]
===
match
---
simple_stmt [19785,19827]
simple_stmt [19455,19497]
===
match
---
atom [23923,23988]
atom [23593,23658]
===
match
---
name: QUEUED [11763,11769]
name: QUEUED [11808,11814]
===
match
---
operator: = [22727,22728]
operator: = [22397,22398]
===
match
---
name: time [17488,17492]
name: time [17158,17162]
===
match
---
simple_stmt [10887,10914]
simple_stmt [10932,10959]
===
match
---
annassign [25345,25393]
annassign [25038,25086]
===
match
---
operator: , [25437,25438]
operator: , [25130,25131]
===
match
---
operator: = [12409,12410]
operator: = [12454,12455]
===
match
---
atom_expr [9549,9579]
atom_expr [9594,9624]
===
match
---
name: engine [3727,3733]
name: engine [3772,3778]
===
match
---
suite [16077,16242]
suite [15747,15912]
===
match
---
arglist [9246,9280]
arglist [9291,9325]
===
match
---
simple_stmt [1429,1467]
simple_stmt [1474,1512]
===
match
---
name: adopted_task_timeouts [15664,15685]
name: adopted_task_timeouts [15334,15355]
===
match
---
atom_expr [17682,17695]
atom_expr [17352,17365]
===
match
---
name: send_task_to_executor [12222,12243]
name: send_task_to_executor [12267,12288]
===
match
---
operator: , [8221,8222]
operator: , [8266,8267]
===
match
---
dotted_name [1764,1782]
dotted_name [1809,1827]
===
match
---
name: ret [3442,3445]
name: ret [3487,3490]
===
match
---
name: app [23216,23219]
name: app [22886,22889]
===
match
---
operator: , [15695,15696]
operator: , [15365,15366]
===
match
---
name: task_tuples_to_send [9165,9184]
name: task_tuples_to_send [9210,9229]
===
match
---
name: t [9784,9785]
name: t [9829,9830]
===
match
---
operator: , [25255,25256]
operator: , [24947,24948]
===
match
---
operator: / [8863,8864]
operator: / [8908,8909]
===
match
---
name: key [6115,6118]
name: key [6160,6163]
===
match
---
name: adopted_task_timeouts [13385,13406]
name: adopted_task_timeouts [13055,13076]
===
match
---
name: subprocess [1018,1028]
name: subprocess [1018,1028]
===
match
---
trailer [24308,24335]
trailer [23978,24005]
===
match
---
name: result [10239,10245]
name: result [10284,10290]
===
match
---
atom_expr [10061,10094]
atom_expr [10106,10139]
===
match
---
name: info [24796,24800]
name: info [24466,24470]
===
match
---
trailer [5869,5898]
trailer [5914,5943]
===
match
---
simple_stmt [2964,2988]
simple_stmt [3009,3033]
===
match
---
simple_stmt [6577,6609]
simple_stmt [6622,6654]
===
match
---
operator: , [3426,3427]
operator: , [3471,3472]
===
match
---
string: 'celery_config_options' [2720,2743]
string: 'celery_config_options' [2765,2788]
===
match
---
name: result [19839,19845]
name: result [19509,19515]
===
match
---
trailer [10321,10342]
trailer [10366,10387]
===
match
---
except_clause [21480,21501]
except_clause [21150,21171]
===
match
---
tfpdef [5175,5195]
tfpdef [5220,5240]
===
match
---
fstring [3954,3999]
fstring [3999,4044]
===
match
---
number: 600 [8232,8235]
number: 600 [8277,8280]
===
match
---
comparison [12090,12117]
comparison [12135,12162]
===
match
---
name: settings [3112,3120]
name: settings [3157,3165]
===
match
---
name: max [8822,8825]
name: max [8867,8870]
===
match
---
number: 1.0 [8843,8846]
number: 1.0 [8888,8891]
===
match
---
simple_stmt [11374,11396]
simple_stmt [11419,11441]
===
match
---
atom_expr [19527,19583]
atom_expr [19197,19253]
===
match
---
expr_stmt [22720,22774]
expr_stmt [22390,22444]
===
match
---
name: backends [1297,1305]
name: backends [1342,1350]
===
match
---
name: external_executor_id [19233,19253]
name: external_executor_id [18903,18923]
===
match
---
name: EXECUTE_TASKS_NEW_PYTHON_INTERPRETER [3121,3157]
name: EXECUTE_TASKS_NEW_PYTHON_INTERPRETER [3166,3202]
===
match
---
name: state_and_info_by_celery_task_id [16104,16136]
name: state_and_info_by_celery_task_id [15774,15806]
===
match
---
expr_stmt [4370,4393]
expr_stmt [4415,4438]
===
match
---
name: tasks [15955,15960]
name: tasks [15625,15630]
===
match
---
name: info [16793,16797]
name: info [16463,16467]
===
match
---
name: list [12213,12217]
name: list [12258,12262]
===
match
---
operator: = [20118,20119]
operator: = [19788,19789]
===
match
---
argument [5870,5884]
argument [5915,5929]
===
match
---
atom_expr [3225,3258]
atom_expr [3270,3303]
===
match
---
string: '\n\t' [20326,20332]
string: '\n\t' [19996,20002]
===
match
---
with_stmt [5784,5899]
with_stmt [5829,5944]
===
match
---
operator: , [16268,16269]
operator: , [15938,15939]
===
match
---
name: str [16517,16520]
name: str [16187,16190]
===
match
---
simple_stmt [21543,21625]
simple_stmt [21213,21295]
===
match
---
name: backend [19685,19692]
name: backend [19355,19362]
===
match
---
name: self [10317,10321]
name: self [10362,10366]
===
match
---
operator: , [6127,6128]
operator: , [6172,6173]
===
match
---
atom_expr [25494,25548]
atom_expr [25187,25241]
===
match
---
trailer [7737,7755]
trailer [7782,7800]
===
match
---
operator: , [20634,20635]
operator: , [20304,20305]
===
match
---
funcdef [8568,8891]
funcdef [8613,8936]
===
match
---
name: settings [1637,1645]
name: settings [1682,1690]
===
match
---
trailer [25731,25741]
trailer [25424,25434]
===
match
---
try_stmt [21138,21715]
try_stmt [20808,21385]
===
match
---
trailer [25210,25214]
trailer [24919,24923]
===
match
---
simple_stmt [22964,22978]
simple_stmt [22634,22648]
===
match
---
comparison [16816,16846]
comparison [16486,16516]
===
match
---
atom_expr [4109,4160]
atom_expr [4154,4205]
===
match
---
trailer [22676,22706]
trailer [22346,22376]
===
match
---
atom_expr [7733,7755]
atom_expr [7778,7800]
===
match
---
name: task_publish_max_retries [8338,8362]
name: task_publish_max_retries [8383,8407]
===
match
---
name: CELERY_FETCH_ERR_MSG_HEADER [2333,2360]
name: CELERY_FETCH_ERR_MSG_HEADER [2378,2405]
===
match
---
name: ceil [8838,8842]
name: ceil [8883,8887]
===
match
---
import_name [6744,6775]
import_name [6789,6820]
===
match
---
name: airflow [1725,1732]
name: airflow [1770,1777]
===
match
---
name: base [1306,1310]
name: base [1351,1355]
===
match
---
if_stmt [3345,3555]
if_stmt [3390,3600]
===
match
---
trailer [22545,22584]
trailer [22215,22254]
===
match
---
trailer [20064,20086]
trailer [19734,19756]
===
match
---
name: task_tuple [9468,9478]
name: task_tuple [9513,9523]
===
match
---
string: "Unexpected state for %s: %s" [17104,17133]
string: "Unexpected state for %s: %s" [16774,16803]
===
match
---
atom_expr [12057,12081]
atom_expr [12102,12126]
===
match
---
name: send_pool [12993,13002]
name: send_pool [12657,12666]
===
match
---
testlist_comp [11757,11785]
testlist_comp [11802,11830]
===
match
---
trailer [23837,23843]
trailer [23507,23513]
===
match
---
name: result [22927,22933]
name: result [22597,22603]
===
match
---
name: ti [20110,20112]
name: ti [19780,19782]
===
match
---
string: "\n\t" [15447,15453]
string: "\n\t" [15117,15123]
===
match
---
trailer [25361,25388]
trailer [25054,25081]
===
match
---
trailer [3338,3340]
trailer [3383,3385]
===
match
---
expr_stmt [20099,20126]
expr_stmt [19769,19796]
===
match
---
name: backends [1355,1363]
name: backends [1400,1408]
===
match
---
trailer [19166,19187]
trailer [18836,18857]
===
match
---
trailer [3502,3554]
trailer [3547,3599]
===
match
---
name: import_modules [1494,1508]
name: import_modules [1539,1553]
===
match
---
name: self [13942,13946]
name: self [13612,13616]
===
match
---
argument [8223,8235]
argument [8268,8280]
===
match
---
name: info [21471,21475]
name: info [21141,21145]
===
match
---
expr_stmt [7906,7921]
expr_stmt [7951,7966]
===
match
---
operator: } [25392,25393]
operator: } [25085,25086]
===
match
---
string: "Failed to execute task %s." [4123,4151]
string: "Failed to execute task %s." [4168,4196]
===
match
---
simple_stmt [23997,24093]
simple_stmt [23667,23763]
===
match
---
trailer [3905,3923]
trailer [3950,3968]
===
match
---
string: 'operation_timeout' [2501,2520]
string: 'operation_timeout' [2546,2565]
===
match
---
name: exception [10246,10255]
name: exception [10291,10300]
===
match
---
trailer [7395,7397]
trailer [7440,7442]
===
match
---
operator: @ [24190,24191]
operator: @ [23860,23861]
===
match
---
operator: , [24872,24873]
operator: , [24542,24543]
===
match
---
atom_expr [22210,22232]
atom_expr [21880,21902]
===
match
---
name: key [16224,16227]
name: key [15894,15897]
===
match
---
atom_expr [24643,24662]
atom_expr [24313,24332]
===
match
---
atom_expr [3331,3340]
atom_expr [3376,3385]
===
match
---
name: task_tuples_to_send [9798,9817]
name: task_tuples_to_send [9843,9862]
===
match
---
name: copy [4387,4391]
name: copy [4432,4436]
===
match
---
name: EventBufferValueType [1898,1918]
name: EventBufferValueType [1943,1963]
===
match
---
atom_expr [24950,24997]
atom_expr [24620,24667]
===
match
---
arglist [8480,8561]
arglist [8525,8606]
===
match
---
comparison [19164,19199]
comparison [18834,18869]
===
match
---
trailer [3422,3430]
trailer [3467,3475]
===
match
---
trailer [9346,9350]
trailer [9391,9395]
===
match
---
atom_expr [15345,15365]
atom_expr [15015,15035]
===
match
---
trailer [16337,16339]
trailer [16007,16009]
===
match
---
trailer [16383,16389]
trailer [16053,16059]
===
match
---
expr_stmt [3599,3606]
expr_stmt [3644,3651]
===
match
---
name: ti [20043,20045]
name: ti [19713,19715]
===
match
---
trailer [3953,4000]
trailer [3998,4045]
===
match
---
atom [9301,9331]
atom [9346,9376]
===
match
---
name: stats [2022,2027]
name: stats [2067,2072]
===
match
---
import_from [2041,2097]
import_from [2086,2142]
===
match
---
simple_stmt [19454,19594]
simple_stmt [19124,19264]
===
match
---
trailer [3741,3743]
trailer [3786,3788]
===
match
---
name: _ [9311,9312]
name: _ [9356,9357]
===
match
---
trailer [11175,11185]
trailer [11220,11230]
===
match
---
number: 0 [4040,4041]
number: 0 [4085,4086]
===
match
---
trailer [15643,15648]
trailer [15313,15318]
===
match
---
name: tasks [23982,23987]
name: tasks [23652,23657]
===
match
---
argument [5886,5897]
argument [5931,5942]
===
match
---
suite [16184,16242]
suite [15854,15912]
===
match
---
operator: , [25741,25742]
operator: , [25434,25435]
===
match
---
arglist [4123,4159]
arglist [4168,4204]
===
match
---
argument [21164,21189]
argument [20834,20859]
===
match
---
parameters [17304,17337]
parameters [16974,17007]
===
match
---
name: Union [5635,5640]
name: Union [5680,5685]
===
match
---
name: task [23974,23978]
name: task [23644,23648]
===
match
---
name: chunksize [13115,13124]
name: chunksize [12784,12793]
===
match
---
atom [10347,10454]
atom [10392,10499]
===
match
---
name: self [22810,22814]
name: self [22480,22484]
===
match
---
atom_expr [17956,17974]
atom_expr [17626,17644]
===
match
---
name: info [16236,16240]
name: info [15906,15910]
===
match
---
operator: == [7756,7758]
operator: == [7801,7803]
===
match
---
name: floor [25090,25095]
name: floor [24777,24782]
===
match
---
trailer [17424,17437]
trailer [17094,17107]
===
match
---
trailer [12217,12266]
trailer [12262,12311]
===
match
---
param [16482,16487]
param [16152,16157]
===
match
---
atom_expr [10239,10255]
atom_expr [10284,10300]
===
match
---
name: BaseKeyValueStoreBackend [1318,1342]
name: BaseKeyValueStoreBackend [1363,1387]
===
match
---
operator: , [17309,17310]
operator: , [16979,16980]
===
match
---
name: self [23434,23438]
name: self [23104,23108]
===
match
---
name: TaskInstance [17938,17950]
name: TaskInstance [17608,17620]
===
match
---
import_from [2009,2040]
import_from [2054,2085]
===
match
---
name: next [9779,9783]
name: next [9824,9828]
===
match
---
name: celery_task_id [19811,19825]
name: celery_task_id [19481,19495]
===
match
---
operator: { [20249,20250]
operator: { [19919,19920]
===
match
---
operator: , [17133,17134]
operator: , [16803,16804]
===
match
---
name: debug_dump [15250,15260]
name: debug_dump [14920,14930]
===
match
---
param [23552,23563]
param [23222,23233]
===
match
---
arglist [12222,12264]
arglist [12267,12309]
===
match
---
name: Optional [17635,17643]
name: Optional [17305,17313]
===
match
---
name: log [20364,20367]
name: log [20034,20037]
===
match
---
name: key [9296,9299]
name: key [9341,9344]
===
match
---
name: len [15430,15433]
name: len [15100,15103]
===
match
---
simple_stmt [23322,23418]
simple_stmt [22992,23088]
===
match
---
operator: , [16095,16096]
operator: , [15765,15766]
===
match
---
atom_expr [24552,24573]
atom_expr [24222,24243]
===
match
---
trailer [22199,22201]
trailer [21869,21871]
===
match
---
atom_expr [7906,7916]
atom_expr [7951,7961]
===
match
---
simple_stmt [16332,16371]
simple_stmt [16002,16041]
===
match
---
name: datetime [8136,8144]
name: datetime [8181,8189]
===
match
---
atom_expr [15950,15969]
atom_expr [15620,15639]
===
match
---
atom_expr [7857,7897]
atom_expr [7902,7942]
===
match
---
operator: , [9410,9411]
operator: , [9455,9456]
===
match
---
string: "No task to query celery, skipping sync" [13269,13309]
string: "No task to query celery, skipping sync" [12939,12979]
===
match
---
tfpdef [8920,8935]
tfpdef [8965,8980]
===
match
---
name: task_tuples_to_send [9700,9719]
name: task_tuples_to_send [9745,9764]
===
match
---
atom_expr [5506,5519]
atom_expr [5551,5564]
===
match
---
atom_expr [23861,23891]
atom_expr [23531,23561]
===
match
---
name: args [3901,3905]
name: args [3946,3950]
===
match
---
suite [19148,19361]
suite [18818,19031]
===
match
---
operator: -> [16533,16535]
operator: -> [16203,16205]
===
match
---
operator: , [6118,6119]
operator: , [6163,6164]
===
match
---
arglist [16788,16797]
arglist [16458,16467]
===
match
---
trailer [11890,11908]
trailer [11935,11953]
===
match
---
funcdef [2901,3259]
funcdef [2946,3304]
===
match
---
name: change_state [16251,16263]
name: change_state [15921,15933]
===
match
---
name: task_results_by_task_id [24160,24183]
name: task_results_by_task_id [23830,23853]
===
match
---
name: open_slots [8920,8930]
name: open_slots [8965,8975]
===
match
---
name: self [22285,22289]
name: self [21955,21959]
===
match
---
name: result [22598,22604]
name: result [22268,22274]
===
match
---
name: adopted [20232,20239]
name: adopted [19902,19909]
===
match
---
trailer [13262,13268]
trailer [12932,12938]
===
match
---
name: exception [4113,4122]
name: exception [4158,4167]
===
match
---
name: state [16229,16234]
name: state [15899,15904]
===
match
---
operator: , [16520,16521]
operator: , [16190,16191]
===
match
---
trailer [17467,17469]
trailer [17137,17139]
===
match
---
name: self [20060,20064]
name: self [19730,19734]
===
match
---
name: self [10887,10891]
name: self [10932,10936]
===
match
---
name: celery_states [16825,16838]
name: celery_states [16495,16508]
===
match
---
name: state_info [24816,24826]
name: state_info [24486,24496]
===
match
---
testlist_star_expr [16090,16101]
testlist_star_expr [15760,15771]
===
match
---
name: error [4734,4739]
name: error [4779,4784]
===
match
---
name: values [17461,17467]
name: values [17131,17137]
===
match
---
operator: , [8918,8919]
operator: , [8963,8964]
===
match
---
exprlist [25410,25443]
exprlist [25103,25136]
===
match
---
operator: == [16622,16624]
operator: == [16292,16294]
===
match
---
atom_expr [19536,19558]
atom_expr [19206,19228]
===
match
---
comp_op [11290,11296]
comp_op [11335,11341]
===
match
---
operator: , [16034,16035]
operator: , [15704,15705]
===
match
---
suite [24680,24755]
suite [24350,24425]
===
match
---
expr_stmt [2672,2744]
expr_stmt [2717,2789]
===
match
---
name: task_to_run [5846,5857]
name: task_to_run [5891,5902]
===
match
---
simple_stmt [6844,6883]
simple_stmt [6889,6928]
===
match
---
import_as_names [1380,1428]
import_as_names [1425,1473]
===
match
---
atom_expr [8365,8426]
atom_expr [8410,8471]
===
match
---
name: append [9461,9467]
name: append [9506,9512]
===
match
---
name: meta_from_decoded [23936,23953]
name: meta_from_decoded [23606,23623]
===
match
---
dotted_name [2014,2027]
dotted_name [2059,2072]
===
match
---
simple_stmt [23719,23771]
simple_stmt [23389,23441]
===
match
---
suite [5679,6136]
suite [5724,6181]
===
match
---
operator: , [1212,1213]
operator: , [1257,1258]
===
match
---
name: in_ [23878,23881]
name: in_ [23548,23551]
===
match
---
name: task_id [21653,21660]
name: task_id [21323,21330]
===
match
---
name: debug [8474,8479]
name: debug [8519,8524]
===
match
---
string: "task_cls" [23751,23761]
string: "task_cls" [23421,23431]
===
match
---
name: getint [8181,8187]
name: getint [8226,8232]
===
match
---
param [17628,17656]
param [17298,17326]
===
match
---
operator: , [25795,25796]
operator: , [25488,25489]
===
match
---
param [17311,17336]
param [16981,17006]
===
match
---
operator: , [5740,5741]
operator: , [5785,5786]
===
match
---
atom_expr [12444,12468]
atom_expr [12489,12513]
===
match
---
trailer [24654,24662]
trailer [24324,24332]
===
match
---
atom_expr [25012,25039]
atom_expr [24682,24726]
===
match
---
operator: , [15578,15579]
operator: , [15248,15249]
===
match
---
string: """Gets status for many Celery tasks using the best method available.""" [22451,22523]
string: """Gets status for many Celery tasks using the best method available.""" [22121,22193]
===
match
---
suite [16847,16986]
suite [16517,16656]
===
match
---
import_name [1029,1040]
import_name [1029,1040]
===
match
---
import_from [1759,1826]
import_from [1804,1871]
===
match
---
atom_expr [9784,9788]
atom_expr [9829,9833]
===
match
---
suite [21534,21715]
suite [21204,21385]
===
match
---
name: async_tasks [23019,23030]
name: async_tasks [22689,22700]
===
match
---
name: bool [17324,17328]
name: bool [16994,16998]
===
match
---
name: state [16816,16821]
name: state [16486,16491]
===
match
---
name: __init__ [7387,7395]
name: __init__ [7432,7440]
===
match
---
trailer [22939,22954]
trailer [22609,22624]
===
match
---
trailer [22214,22232]
trailer [21884,21902]
===
match
---
simple_stmt [13517,13857]
simple_stmt [13187,13527]
===
match
---
expr_stmt [19785,19826]
expr_stmt [19455,19496]
===
match
---
name: key [16031,16034]
name: key [15701,15704]
===
match
---
return_stmt [20506,20528]
return_stmt [20176,20198]
===
match
---
name: command_to_exec [3022,3037]
name: command_to_exec [3067,3082]
===
match
---
trailer [19652,19681]
trailer [19322,19351]
===
match
---
name: AsyncResult [19258,19269]
name: AsyncResult [18928,18939]
===
match
---
trailer [22637,22652]
trailer [22307,22322]
===
match
---
atom_expr [4612,4641]
atom_expr [4657,4686]
===
match
---
name: timeout [2198,2205]
name: timeout [2243,2250]
===
match
---
name: update_task_state [11891,11908]
name: update_task_state [11936,11953]
===
match
---
arglist [5870,5897]
arglist [5915,5942]
===
match
---
arith_expr [11108,11149]
arith_expr [11153,11194]
===
match
---
name: state [17003,17008]
name: state [16673,16678]
===
match
---
simple_stmt [1610,1646]
simple_stmt [1655,1691]
===
match
---
import_name [6645,6679]
import_name [6690,6724]
===
match
---
operator: , [24628,24629]
operator: , [24298,24299]
===
match
---
suite [9283,9584]
suite [9328,9629]
===
match
---
name: e [4645,4646]
name: e [4690,4691]
===
match
---
name: CommandType [4344,4355]
name: CommandType [4389,4400]
===
match
---
name: operator [992,1000]
name: operator [992,1000]
===
match
---
operator: = [16102,16103]
operator: = [15772,15773]
===
match
---
tfpdef [9700,9747]
tfpdef [9745,9792]
===
match
---
name: exception_traceback [21688,21707]
name: exception_traceback [21358,21377]
===
match
---
operator: , [7700,7701]
operator: , [7745,7746]
===
match
---
name: bulk_state_fetcher [19486,19504]
name: bulk_state_fetcher [19156,19174]
===
match
---
simple_stmt [12399,12470]
simple_stmt [12444,12515]
===
match
---
trailer [20010,20032]
trailer [19680,19702]
===
match
---
name: operators [6725,6734]
name: operators [6770,6779]
===
match
---
name: debug [13263,13268]
name: debug [12933,12938]
===
match
---
trailer [12497,12547]
trailer [12542,12592]
===
match
---
trailer [20246,20272]
trailer [19916,19942]
===
match
---
annassign [24355,24403]
annassign [24025,24073]
===
match
---
simple_stmt [22598,22653]
simple_stmt [22268,22323]
===
match
---
suite [6990,20529]
suite [7035,20199]
===
match
---
name: Optional [1199,1207]
name: Optional [1244,1252]
===
match
---
simple_stmt [17051,17056]
simple_stmt [16721,16726]
===
match
---
suite [3320,4298]
suite [3365,4343]
===
match
---
name: info [16682,16686]
name: info [16352,16356]
===
match
---
if_stmt [19161,19361]
if_stmt [18831,19031]
===
match
---
name: adopted [20338,20345]
name: adopted [20008,20015]
===
match
---
string: "Inquiries completed." [15995,16017]
string: "Inquiries completed." [15665,15687]
===
match
---
trailer [20201,20205]
trailer [19871,19875]
===
match
---
simple_stmt [1919,2009]
simple_stmt [1964,2054]
===
match
---
simple_stmt [4248,4298]
simple_stmt [4293,4343]
===
match
---
atom_expr [7831,7854]
atom_expr [7876,7899]
===
match
---
param [11990,11995]
param [12035,12040]
===
match
---
atom_expr [11151,11167]
atom_expr [11196,11212]
===
match
---
atom_expr [24609,24637]
atom_expr [24279,24307]
===
match
---
name: TaskDb [23763,23769]
name: TaskDb [23433,23439]
===
match
---
operator: , [3085,3086]
operator: , [3130,3131]
===
match
---
name: append [19350,19356]
name: append [19020,19026]
===
match
---
expr_stmt [9929,9971]
expr_stmt [9974,10016]
===
match
---
name: log [8470,8473]
name: log [8515,8518]
===
match
---
trailer [15940,15949]
trailer [15610,15619]
===
match
---
expr_stmt [24936,24997]
expr_stmt [24606,24667]
===
match
---
trailer [4483,4551]
trailer [4528,4596]
===
match
---
import_from [1285,1342]
import_from [1330,1387]
===
match
---
name: signals [1479,1486]
name: signals [1524,1531]
===
match
---
atom_expr [8014,8040]
atom_expr [8059,8085]
===
match
---
name: session [23800,23807]
name: session [23470,23477]
===
match
---
with_item [25012,25052]
with_item [24682,24739]
===
match
---
atom [22332,22364]
atom [22002,22034]
===
match
---
parameters [6229,6246]
parameters [6274,6291]
===
match
---
name: os [4248,4250]
name: os [4293,4295]
===
match
---
name: key [20113,20116]
name: key [19783,19786]
===
match
---
operator: = [23346,23347]
operator: = [23016,23017]
===
match
---
name: task_ids [24150,24158]
name: task_ids [23820,23828]
===
match
---
import_name [6684,6705]
import_name [6729,6750]
===
match
---
atom_expr [25861,25896]
atom_expr [25554,25589]
===
match
---
name: task_id [25410,25417]
name: task_id [25103,25110]
===
match
---
operator: , [9319,9320]
operator: , [9364,9365]
===
match
---
operator: > [14007,14008]
operator: > [13677,13678]
===
match
---
trailer [23575,23602]
trailer [23245,23272]
===
match
---
trailer [17805,17848]
trailer [17475,17518]
===
match
---
atom_expr [17389,17470]
atom_expr [17059,17140]
===
match
---
name: Tuple [5450,5455]
name: Tuple [5495,5500]
===
match
---
simple_stmt [9629,9670]
simple_stmt [9674,9715]
===
match
---
trailer [23737,23770]
trailer [23407,23440]
===
match
---
strings [14811,14932]
strings [14481,14602]
===
match
---
simple_stmt [1720,1759]
simple_stmt [1765,1804]
===
match
---
atom_expr [15173,15188]
atom_expr [14843,14858]
===
match
---
name: task_tuples_to_send [13094,13113]
name: task_tuples_to_send [12763,12782]
===
match
---
trailer [10891,10904]
trailer [10936,10949]
===
match
---
simple_stmt [15345,15366]
simple_stmt [15015,15036]
===
match
---
name: items [13969,13974]
name: items [13639,13644]
===
match
---
name: fallback [2522,2530]
name: fallback [2567,2575]
===
match
---
simple_stmt [3167,3207]
simple_stmt [3212,3252]
===
match
---
name: result [11430,11436]
name: result [11475,11481]
===
match
---
name: os [4376,4378]
name: os [4421,4423]
===
match
---
expr_stmt [3901,3931]
expr_stmt [3946,3976]
===
match
---
name: exception [5237,5246]
name: exception [5282,5291]
===
match
---
simple_stmt [4823,4851]
simple_stmt [4868,4896]
===
match
---
funcdef [23516,24185]
funcdef [23186,23855]
===
match
---
name: task_id [21442,21449]
name: task_id [21112,21119]
===
match
---
operator: , [25083,25084]
operator: , [24770,24771]
===
match
---
name: airflow [2146,2153]
name: airflow [2191,2198]
===
match
---
atom_expr [14714,14739]
atom_expr [14384,14409]
===
match
---
name: _execute_in_subprocess [4304,4326]
name: _execute_in_subprocess [4349,4371]
===
match
---
name: executors [1840,1849]
name: executors [1885,1894]
===
match
---
trailer [25504,25548]
trailer [25197,25241]
===
match
---
name: command_to_exec [3872,3887]
name: command_to_exec [3917,3932]
===
match
---
trailer [20035,20039]
trailer [19705,19709]
===
match
---
trailer [21609,21620]
trailer [21279,21290]
===
match
---
operator: = [5448,5449]
operator: = [5493,5494]
===
match
---
parameters [8913,8936]
parameters [8958,8981]
===
match
---
name: adopted_task_timeouts [16949,16970]
name: adopted_task_timeouts [16619,16640]
===
match
---
name: session_cleanup [23784,23799]
name: session_cleanup [23454,23469]
===
match
---
testlist_comp [23148,23197]
testlist_comp [22818,22867]
===
match
---
name: join [15644,15648]
name: join [15314,15318]
===
match
---
simple_stmt [9441,9480]
simple_stmt [9486,9525]
===
match
---
import_from [3624,3669]
import_from [3669,3714]
===
match
---
param [20559,20584]
param [20229,20254]
===
match
---
name: state [24544,24549]
name: state [24214,24219]
===
match
---
name: task_id [24491,24498]
name: task_id [24161,24168]
===
match
---
suite [4882,5304]
suite [4927,5349]
===
match
---
atom_expr [20199,20205]
atom_expr [19869,19875]
===
match
---
name: task_tuples_to_send [9596,9615]
name: task_tuples_to_send [9641,9660]
===
match
---
name: isinstance [22666,22676]
name: isinstance [22336,22346]
===
match
---
name: result [22971,22977]
name: result [22641,22647]
===
match
---
import_from [2179,2220]
import_from [2224,2265]
===
match
---
name: OPERATION_TIMEOUT [5805,5822]
name: OPERATION_TIMEOUT [5850,5867]
===
match
---
operator: = [23621,23622]
operator: = [23291,23292]
===
match
---
name: int [8829,8832]
name: int [8874,8877]
===
match
---
trailer [14727,14734]
trailer [14397,14404]
===
match
---
tfpdef [16292,16302]
tfpdef [15962,15972]
===
match
---
atom_expr [13871,13879]
atom_expr [13541,13549]
===
match
---
name: Mapping [1174,1181]
name: Mapping [1219,1226]
===
match
---
name: app [22546,22549]
name: app [22216,22219]
===
match
---
atom_expr [11731,11753]
atom_expr [11776,11798]
===
match
---
operator: , [4525,4526]
operator: , [4570,4571]
===
match
---
suite [9532,9584]
suite [9577,9629]
===
match
---
name: celery_tasks [19217,19229]
name: celery_tasks [18887,18899]
===
match
---
expr_stmt [5718,5766]
expr_stmt [5763,5811]
===
match
---
trailer [9574,9579]
trailer [9619,9624]
===
match
---
name: async_results [24874,24887]
name: async_results [24544,24557]
===
match
---
operator: = [25076,25077]
operator: = [24763,24764]
===
match
---
name: self [10708,10712]
name: self [10753,10757]
===
match
---
name: self [13230,13234]
name: self [12900,12904]
===
match
---
tfpdef [17928,17951]
tfpdef [17598,17621]
===
match
---
simple_stmt [1001,1011]
simple_stmt [1001,1011]
===
match
---
funcdef [22983,23511]
funcdef [22653,23181]
===
match
---
param [3282,3310]
param [3327,3355]
===
match
---
name: async_results [22847,22860]
name: async_results [22517,22530]
===
match
---
trailer [19229,19254]
trailer [18899,18924]
===
match
---
name: simple_ti [9321,9330]
name: simple_ti [9366,9375]
===
match
---
arglist [2823,2850]
arglist [2868,2895]
===
match
---
operator: , [23761,23762]
operator: , [23431,23432]
===
match
---
simple_stmt [2098,2141]
simple_stmt [2143,2186]
===
match
---
name: sync_parallelism [22235,22251]
name: sync_parallelism [21905,21921]
===
match
---
name: sorted_queue [9103,9115]
name: sorted_queue [9148,9160]
===
match
---
name: fallback [8223,8231]
name: fallback [8268,8276]
===
match
---
name: error [11045,11050]
name: error [11090,11095]
===
match
---
name: self [17554,17558]
name: self [17224,17228]
===
match
---
atom_expr [11771,11785]
atom_expr [11816,11830]
===
match
---
trailer [20454,20463]
trailer [20124,20133]
===
match
---
name: items [15686,15691]
name: items [15356,15361]
===
match
---
string: ": %s\n%s\n" [11137,11149]
string: ": %s\n%s\n" [11182,11194]
===
match
---
name: self [22729,22733]
name: self [22399,22403]
===
match
---
suite [17975,20529]
suite [17645,20199]
===
match
---
name: TaskInstanceKey [5605,5620]
name: TaskInstanceKey [5650,5665]
===
match
---
simple_stmt [1228,1285]
simple_stmt [1273,1330]
===
match
---
name: key [20036,20039]
name: key [19706,19709]
===
match
---
name: key [11391,11394]
name: key [11436,11439]
===
match
---
with_stmt [23779,23899]
with_stmt [23449,23569]
===
match
---
operator: = [17649,17650]
operator: = [17319,17320]
===
match
---
atom_expr [19560,19581]
atom_expr [19230,19251]
===
match
---
name: flush [4205,4210]
name: flush [4250,4255]
===
match
---
operator: , [23484,23485]
operator: , [23154,23155]
===
match
---
trailer [16352,16370]
trailer [16022,16040]
===
match
---
operator: { [19093,19094]
operator: { [18763,18764]
===
match
---
string: "\n\t" [14994,15000]
string: "\n\t" [14664,14670]
===
match
---
name: super [16332,16337]
name: super [16002,16007]
===
match
---
name: values [23207,23213]
name: values [22877,22883]
===
match
---
name: task_tuples_to_send [12245,12264]
name: task_tuples_to_send [12290,12309]
===
match
---
operator: = [2475,2476]
operator: = [2520,2521]
===
match
---
name: get_parser [3659,3669]
name: get_parser [3704,3714]
===
match
---
name: fail [16783,16787]
name: fail [16453,16457]
===
match
---
trailer [21620,21622]
trailer [21290,21292]
===
match
---
name: range [9236,9241]
name: range [9281,9286]
===
match
---
name: tasks [23822,23827]
name: tasks [23492,23497]
===
match
---
name: ImportError [6894,6905]
name: ImportError [6939,6950]
===
match
---
simple_stmt [16550,16588]
simple_stmt [16220,16258]
===
match
---
name: key [9575,9578]
name: key [9620,9623]
===
match
---
atom_expr [9953,9971]
atom_expr [9998,10016]
===
match
---
trailer [7659,7677]
trailer [7704,7722]
===
match
---
atom_expr [15917,15970]
atom_expr [15587,15640]
===
match
---
name: List [1168,1172]
name: List [1213,1217]
===
match
---
name: celery_task_id [19706,19720]
name: celery_task_id [19376,19390]
===
match
---
trailer [12447,12468]
trailer [12492,12513]
===
match
---
atom_expr [15857,15872]
atom_expr [15527,15542]
===
match
---
simple_stmt [6915,6920]
simple_stmt [6960,6965]
===
match
---
operator: == [16822,16824]
operator: == [16492,16494]
===
match
---
subscriptlist [8047,8081]
subscriptlist [8092,8126]
===
match
---
suite [2959,3259]
suite [3004,3304]
===
match
---
atom_expr [16664,16687]
atom_expr [16334,16357]
===
match
---
trailer [5796,5823]
trailer [5841,5868]
===
match
---
trailer [15967,15969]
trailer [15637,15639]
===
match
---
atom_expr [15107,15129]
atom_expr [14777,14799]
===
match
---
name: task [23954,23958]
name: task [23624,23628]
===
match
---
name: key_and_async_results [13164,13185]
name: key_and_async_results [12834,12855]
===
match
---
name: Mapping [22407,22414]
name: Mapping [22077,22084]
===
match
---
operator: = [8083,8084]
operator: = [8128,8129]
===
match
---
trailer [15648,15695]
trailer [15318,15365]
===
match
---
name: self [20359,20363]
name: self [20029,20033]
===
match
---
trailer [21463,21469]
trailer [21133,21139]
===
match
---
trailer [9467,9479]
trailer [9512,9524]
===
match
---
name: pool [3695,3699]
name: pool [3740,3744]
===
match
---
name: cached_celery_backend [19856,19877]
name: cached_celery_backend [19526,19547]
===
match
---
trailer [3694,3699]
trailer [3739,3744]
===
match
---
trailer [20151,20155]
trailer [19821,19825]
===
match
---
testlist_star_expr [9296,9331]
testlist_star_expr [9341,9376]
===
match
---
name: seconds [5797,5804]
name: seconds [5842,5849]
===
match
---
import_name [6844,6868]
import_name [6889,6913]
===
match
---
name: self [13254,13258]
name: self [12924,12928]
===
match
---
import_as_name [1261,1284]
import_as_name [1306,1329]
===
match
---
param [15261,15265]
param [14931,14935]
===
match
---
operator: = [23145,23146]
operator: = [22815,22816]
===
match
---
string: "task_id" [23361,23370]
string: "task_id" [23031,23040]
===
match
---
name: self [16379,16383]
name: self [16049,16053]
===
match
---
trailer [20032,20040]
trailer [19702,19710]
===
match
---
simple_stmt [19334,19361]
simple_stmt [19004,19031]
===
match
---
operator: , [11258,11259]
operator: , [11303,11304]
===
match
---
name: e [6079,6080]
name: e [6124,6125]
===
match
---
name: str [24309,24312]
name: str [23979,23982]
===
match
---
operator: = [9580,9581]
operator: = [9625,9626]
===
match
---
operator: , [5471,5472]
operator: , [5516,5517]
===
match
---
operator: -> [5596,5598]
operator: -> [5641,5643]
===
match
---
operator: -> [4357,4359]
operator: -> [4402,4404]
===
match
---
name: airflow [1764,1771]
name: airflow [1809,1816]
===
match
---
operator: = [5986,5987]
operator: = [6031,6032]
===
match
---
trailer [13234,13240]
trailer [12904,12910]
===
match
---
name: e [4066,4067]
name: e [4111,4112]
===
match
---
arglist [4484,4550]
arglist [4529,4595]
===
match
---
name: ti [19270,19272]
name: ti [18940,18942]
===
match
---
trailer [8111,8133]
trailer [8156,8178]
===
match
---
simple_stmt [15205,15241]
simple_stmt [14875,14911]
===
match
---
operator: = [24748,24749]
operator: = [24418,24419]
===
match
---
atom_expr [19839,19853]
atom_expr [19509,19523]
===
match
---
operator: , [15657,15658]
operator: , [15327,15328]
===
match
---
arith_expr [25646,25687]
arith_expr [25339,25380]
===
match
---
operator: = [23088,23089]
operator: = [22758,22759]
===
match
---
name: backend [23152,23159]
name: backend [22822,22829]
===
match
---
simple_stmt [25570,25819]
simple_stmt [25263,25512]
===
match
---
trailer [23958,23966]
trailer [23628,23636]
===
match
---
name: bulk_state_fetcher [15922,15940]
name: bulk_state_fetcher [15592,15610]
===
match
---
name: celery_import_modules [1512,1533]
name: celery_import_modules [1557,1578]
===
match
---
operator: } [20252,20253]
operator: } [19922,19923]
===
match
---
name: command [5876,5883]
name: command [5921,5928]
===
match
---
expr_stmt [24544,24573]
expr_stmt [24214,24243]
===
match
---
expr_stmt [8014,8098]
expr_stmt [8059,8143]
===
match
---
atom [9379,9428]
atom [9424,9473]
===
match
---
operator: , [8196,8197]
operator: , [8241,8242]
===
match
---
suite [12118,12267]
suite [12163,12312]
===
match
---
trailer [10031,10052]
trailer [10076,10097]
===
match
---
name: event_buffer [15112,15124]
name: event_buffer [14782,14794]
===
match
---
param [5560,5593]
param [5605,5638]
===
match
---
expr_stmt [9103,9155]
expr_stmt [9148,9200]
===
match
---
name: task_publish_retries [9511,9531]
name: task_publish_retries [9556,9576]
===
match
---
atom_expr [2695,2744]
atom_expr [2740,2789]
===
match
---
atom_expr [23738,23749]
atom_expr [23408,23419]
===
match
---
trailer [24112,24149]
trailer [23782,23819]
===
match
---
operator: , [16356,16357]
operator: , [16026,16027]
===
match
---
name: debug [15989,15994]
name: debug [15659,15664]
===
match
---
operator: = [3924,3925]
operator: = [3969,3970]
===
match
---
del_stmt [15169,15188]
del_stmt [14839,14858]
===
match
---
name: get_parser [3762,3772]
name: get_parser [3807,3817]
===
match
---
name: key [15184,15187]
name: key [14854,14857]
===
match
---
name: seconds [8168,8175]
name: seconds [8213,8220]
===
match
---
name: info [16304,16308]
name: info [15974,15978]
===
match
---
simple_stmt [17488,17502]
simple_stmt [17158,17172]
===
match
---
name: kwargs [6239,6245]
name: kwargs [6284,6290]
===
match
---
atom_expr [4800,4814]
atom_expr [4845,4859]
===
match
---
string: 'Sent all tasks.' [10076,10093]
string: 'Sent all tasks.' [10121,10138]
===
match
---
name: str [24900,24903]
name: str [24570,24573]
===
match
---
name: ExceptionWithTraceback [10995,11017]
name: ExceptionWithTraceback [11040,11062]
===
match
---
trailer [10411,10436]
trailer [10456,10481]
===
match
---
operator: , [11942,11943]
operator: , [11987,11988]
===
match
---
trailer [2490,2535]
trailer [2535,2580]
===
match
---
trailer [8180,8187]
trailer [8225,8232]
===
match
---
name: session_cleanup [1413,1428]
name: session_cleanup [1458,1473]
===
match
---
name: fetch_celery_task_state [20535,20558]
name: fetch_celery_task_state [20205,20228]
===
match
---
name: task_ids [23079,23087]
name: task_ids [22749,22757]
===
match
---
trailer [23896,23898]
trailer [23566,23568]
===
match
---
trailer [10986,11018]
trailer [11031,11063]
===
match
---
atom_expr [10164,10206]
atom_expr [10209,10251]
===
match
---
sync_comp_for [17438,17469]
sync_comp_for [17108,17139]
===
match
---
operator: , [23046,23047]
operator: , [22716,22717]
===
match
---
name: Exception [4053,4062]
name: Exception [4098,4107]
===
match
---
subscriptlist [24900,24925]
subscriptlist [24570,24595]
===
match
---
operator: -> [15745,15747]
operator: -> [15415,15417]
===
match
---
expr_stmt [23079,23131]
expr_stmt [22749,22801]
===
match
---
name: BulkStateFetcher [21723,21739]
name: BulkStateFetcher [21393,21409]
===
match
---
name: backend [11326,11333]
name: backend [11371,11378]
===
match
---
name: self [8865,8869]
name: self [8910,8914]
===
match
---
suite [19317,19361]
suite [18987,19031]
===
match
---
string: 'celery' [8377,8385]
string: 'celery' [8422,8430]
===
match
---
simple_stmt [13323,13330]
simple_stmt [12993,13000]
===
match
---
trailer [4250,4256]
trailer [4295,4301]
===
match
---
name: collections [1063,1074]
name: collections [1063,1074]
===
match
---
atom_expr [19648,19692]
atom_expr [19318,19362]
===
match
---
name: synchronous [17311,17322]
name: synchronous [16981,16992]
===
match
---
not_test [24605,24637]
not_test [24275,24307]
===
match
---
suite [13241,13330]
suite [12911,13000]
===
match
---
expr_stmt [3325,3340]
expr_stmt [3370,3385]
===
match
---
operator: , [16290,16291]
operator: , [15960,15961]
===
match
---
name: task_results [24079,24091]
name: task_results [23749,23761]
===
match
---
trailer [25584,25818]
trailer [25277,25511]
===
match
---
operator: , [6080,6081]
operator: , [6125,6126]
===
match
---
name: task_results_by_task_id [24463,24486]
name: task_results_by_task_id [24133,24156]
===
match
---
simple_stmt [6047,6103]
simple_stmt [6092,6148]
===
match
---
name: to_send_count [8606,8619]
name: to_send_count [8651,8664]
===
match
---
operator: <= [10404,10406]
operator: <= [10449,10451]
===
match
---
expr_stmt [19624,19692]
expr_stmt [19294,19362]
===
match
---
name: self [8914,8918]
name: self [8959,8963]
===
match
---
atom_expr [19532,19582]
atom_expr [19202,19252]
===
match
---
name: log [13259,13262]
name: log [12929,12932]
===
match
---
name: _sync_parallelism [7879,7896]
name: _sync_parallelism [7924,7941]
===
match
---
name: env [4543,4546]
name: env [4588,4591]
===
match
---
name: LoggingMixin [21740,21752]
name: LoggingMixin [21410,21422]
===
match
---
name: items [19764,19769]
name: items [19434,19439]
===
match
---
name: e [21685,21686]
name: e [21355,21356]
===
match
---
name: key [16353,16356]
name: key [16023,16026]
===
match
---
atom_expr [3941,4000]
atom_expr [3986,4045]
===
match
---
simple_stmt [4034,4042]
simple_stmt [4079,4087]
===
match
---
atom_expr [8085,8098]
atom_expr [8130,8143]
===
match
---
trailer [12443,12469]
trailer [12488,12514]
===
match
---
operator: , [15428,15429]
operator: , [15098,15099]
===
match
---
atom_expr [15447,15489]
atom_expr [15117,15159]
===
match
---
operator: , [23017,23018]
operator: , [22687,22688]
===
match
---
atom_expr [25347,25388]
atom_expr [25040,25081]
===
match
---
name: str [20595,20598]
name: str [20265,20268]
===
match
---
atom_expr [10369,10403]
atom_expr [10414,10448]
===
match
---
trailer [4812,4814]
trailer [4857,4859]
===
match
---
name: Sentry [3587,3593]
name: Sentry [3632,3638]
===
match
---
import_as_names [1959,2008]
import_as_names [2004,2053]
===
match
---
arglist [8377,8425]
arglist [8422,8470]
===
match
---
decorator [2891,2901]
decorator [2936,2946]
===
match
---
operator: , [10114,10115]
operator: , [10159,10160]
===
match
---
comparison [10369,10436]
comparison [10414,10481]
===
match
---
name: str [16299,16302]
name: str [15969,15972]
===
match
---
param [7364,7368]
param [7409,7413]
===
match
---
trailer [7835,7854]
trailer [7880,7899]
===
match
---
name: _check_for_stalled_adopted_tasks [13425,13457]
name: _check_for_stalled_adopted_tasks [13095,13127]
===
match
---
trailer [22884,22955]
trailer [22554,22625]
===
match
---
trailer [10908,10913]
trailer [10953,10958]
===
match
---
operator: = [22167,22168]
operator: = [21837,21838]
===
match
---
atom_expr [20033,20039]
atom_expr [19703,19709]
===
match
---
operator: , [1411,1412]
operator: , [1456,1457]
===
match
---
trailer [11908,11958]
trailer [11953,12003]
===
match
---
name: self [20099,20103]
name: self [19769,19773]
===
match
---
name: str [25362,25365]
name: str [25055,25058]
===
match
---
name: task_results_by_task_id [23486,23509]
name: task_results_by_task_id [23156,23179]
===
match
---
simple_stmt [16090,16163]
simple_stmt [15760,15833]
===
match
---
argument [13115,13134]
argument [12784,12803]
===
match
---
name: update_task_state [16464,16481]
name: update_task_state [16134,16151]
===
match
---
operator: -> [8448,8450]
operator: -> [8493,8495]
===
match
---
expr_stmt [25172,25305]
expr_stmt [24859,24998]
===
match
---
name: num_process [24936,24947]
name: num_process [24606,24617]
===
match
---
name: a [22347,22348]
name: a [22017,22018]
===
match
---
operator: { [25391,25392]
operator: { [25084,25085]
===
match
---
atom [11756,11786]
atom [11801,11831]
===
match
---
simple_stmt [25066,25159]
simple_stmt [24753,24846]
===
match
---
name: adopted_task_timeouts [20011,20032]
name: adopted_task_timeouts [19681,19702]
===
match
---
trailer [17460,17467]
trailer [17130,17137]
===
match
---
name: self [15596,15600]
name: self [15266,15270]
===
match
---
name: _num_tasks_per_send_process [8572,8599]
name: _num_tasks_per_send_process [8617,8644]
===
match
---
testlist_comp [15133,15151]
testlist_comp [14803,14821]
===
match
---
name: backend [23742,23749]
name: backend [23412,23419]
===
match
---
name: task_ids [23612,23620]
name: task_ids [23282,23290]
===
match
---
trailer [16067,16073]
trailer [15737,15743]
===
match
---
string: "Error syncing the Celery executor, ignoring it." [17241,17290]
string: "Error syncing the Celery executor, ignoring it." [16911,16960]
===
match
---
name: cached_celery_backend [19624,19645]
name: cached_celery_backend [19294,19315]
===
match
---
simple_stmt [14157,14163]
simple_stmt [13827,13833]
===
match
---
name: int [8304,8307]
name: int [8349,8352]
===
match
---
arglist [20199,20218]
arglist [19869,19888]
===
match
---
name: iter [19653,19657]
name: iter [19323,19327]
===
match
---
trailer [15363,15365]
trailer [15033,15035]
===
match
---
name: staticmethod [24191,24203]
name: staticmethod [23861,23873]
===
match
---
trailer [12937,12989]
trailer [12626,12653]
===
match
---
operator: } [23416,23417]
operator: } [23086,23087]
===
match
---
name: self [15209,15213]
name: self [14879,14883]
===
match
---
name: environ [4379,4386]
name: environ [4424,4431]
===
match
---
atom_expr [5232,5246]
atom_expr [5277,5291]
===
match
---
param [17868,17872]
param [17538,17542]
===
match
---
name: exception_traceback [5966,5985]
name: exception_traceback [6011,6030]
===
match
---
trailer [25887,25896]
trailer [25580,25589]
===
match
---
name: fork [3334,3338]
name: fork [3379,3383]
===
match
---
trailer [16136,16140]
trailer [15806,15810]
===
match
---
trailer [22680,22688]
trailer [22350,22358]
===
match
---
name: e [5923,5924]
name: e [5968,5969]
===
match
---
testlist_star_expr [25899,25923]
testlist_star_expr [25592,25616]
===
match
---
expr_stmt [9296,9353]
expr_stmt [9341,9398]
===
match
---
operator: @ [6170,6171]
operator: @ [6215,6216]
===
match
---
name: TaskInstanceInCelery [9726,9746]
name: TaskInstanceInCelery [9771,9791]
===
match
---
operator: , [24158,24159]
operator: , [23828,23829]
===
match
---
import_name [1610,1645]
import_name [1655,1690]
===
match
---
expr_stmt [8107,8246]
expr_stmt [8152,8291]
===
match
---
return_stmt [22325,22364]
return_stmt [21995,22034]
===
match
---
name: CELERY_FETCH_ERR_MSG_HEADER [25646,25673]
name: CELERY_FETCH_ERR_MSG_HEADER [25339,25366]
===
match
---
name: async_tasks [22291,22302]
name: async_tasks [21961,21972]
===
match
---
name: debug [22879,22884]
name: debug [22549,22554]
===
match
---
name: utils [2234,2239]
name: utils [2279,2284]
===
match
---
name: ExceptionWithTraceback [6056,6078]
name: ExceptionWithTraceback [6101,6123]
===
match
---
name: CommandType [2938,2949]
name: CommandType [2983,2994]
===
match
---
atom_expr [2814,2851]
atom_expr [2859,2896]
===
match
---
simple_stmt [3325,3341]
simple_stmt [3370,3386]
===
match
---
argument [17393,17469]
argument [17063,17139]
===
match
---
trailer [8369,8376]
trailer [8414,8421]
===
match
---
string: """         Overwrite trigger_tasks function from BaseExecutor          :param open_slots: Number of open slots         :return:         """ [8954,9094]
string: """         Overwrite trigger_tasks function from BaseExecutor          :param open_slots: Number of open slots         :return:         """ [8999,9139]
===
match
---
operator: , [15467,15468]
operator: , [15137,15138]
===
match
---
name: State [2173,2178]
name: State [2218,2223]
===
match
---
name: logging [4221,4228]
name: logging [4266,4273]
===
match
---
name: external_executor_id [19273,19293]
name: external_executor_id [18943,18963]
===
match
---
name: macros [6699,6705]
name: macros [6744,6750]
===
match
---
operator: { [23348,23349]
operator: { [23018,23019]
===
match
---
operator: , [24266,24267]
operator: , [23936,23937]
===
match
---
operator: , [21469,21470]
operator: , [21139,21140]
===
match
---
name: List [17956,17960]
name: List [17626,17630]
===
match
---
name: timedelta [8145,8154]
name: timedelta [8190,8199]
===
match
---
name: len [12444,12447]
name: len [12489,12492]
===
match
---
trailer [25785,25795]
trailer [25478,25488]
===
match
---
trailer [22874,22878]
trailer [22544,22548]
===
match
---
operator: , [4499,4500]
operator: , [4544,4545]
===
match
---
subscriptlist [23576,23601]
subscriptlist [23246,23271]
===
match
---
operator: = [2530,2531]
operator: = [2575,2576]
===
match
---
name: conf [8176,8180]
name: conf [8221,8225]
===
match
---
name: airflow [6691,6698]
name: airflow [6736,6743]
===
match
---
parameters [8599,8625]
parameters [8644,8670]
===
match
---
simple_stmt [1041,1058]
simple_stmt [1041,1058]
===
match
---
suite [17874,17888]
suite [17544,17558]
===
match
---
classdef [6955,20529]
classdef [7000,20199]
===
match
---
operator: / [25131,25132]
operator: / [24818,24819]
===
match
---
simple_stmt [23612,23665]
simple_stmt [23282,23335]
===
match
---
trailer [11040,11044]
trailer [11085,11089]
===
match
---
suite [5775,5899]
suite [5820,5944]
===
match
---
name: _sync_parallelism [7779,7796]
name: _sync_parallelism [7824,7841]
===
match
---
fstring_expr [21599,21623]
fstring_expr [21269,21293]
===
match
---
trailer [12094,12112]
trailer [12139,12157]
===
match
---
name: result [11771,11777]
name: result [11816,11822]
===
match
---
trailer [3241,3258]
trailer [3286,3303]
===
match
---
trailer [22759,22774]
trailer [22429,22444]
===
match
---
name: hasattr [21370,21377]
name: hasattr [21040,21047]
===
match
---
suite [3615,4042]
suite [3660,4087]
===
match
---
name: state [2160,2165]
name: state [2205,2210]
===
match
---
string: 'celery' [8188,8196]
string: 'celery' [8233,8241]
===
match
---
operator: -> [22304,22306]
operator: -> [21974,21976]
===
match
---
expr_stmt [25319,25393]
expr_stmt [25012,25086]
===
match
---
name: celery_configuration [2672,2692]
name: celery_configuration [2717,2737]
===
match
---
if_stmt [25491,25924]
if_stmt [25184,25617]
===
match
---
simple_stmt [22325,22365]
simple_stmt [21995,22035]
===
match
---
trailer [20332,20337]
trailer [20002,20007]
===
match
---
trailer [17498,17501]
trailer [17168,17171]
===
match
---
operator: , [25687,25688]
operator: , [25380,25381]
===
match
---
name: k [23177,23178]
name: k [22847,22848]
===
match
---
atom_expr [17635,17648]
atom_expr [17305,17318]
===
match
---
dictorsetmaker [22333,22363]
dictorsetmaker [22003,22033]
===
match
---
trailer [17690,17695]
trailer [17360,17365]
===
match
---
name: format_exc [21610,21620]
name: format_exc [21280,21290]
===
match
---
operator: , [20463,20464]
operator: , [20133,20134]
===
match
---
operator: } [6010,6011]
operator: } [6055,6056]
===
match
---
operator: * [25110,25111]
operator: * [24797,24798]
===
match
---
name: processes [25017,25026]
name: max_workers [24702,24713]
===
match
---
operator: = [21171,21172]
operator: = [20841,20842]
===
match
---
operator: + [20058,20059]
operator: + [19728,19729]
===
match
---
name: result [10987,10993]
name: result [11032,11038]
===
match
---
trailer [11251,11258]
trailer [11296,11303]
===
match
---
trailer [9245,9281]
trailer [9290,9326]
===
match
---
name: num_processes [12948,12961]
name: num_processes [12639,12652]
===
match
---
operator: = [17696,17697]
operator: = [17366,17367]
===
match
---
name: setproctitle [1539,1551]
name: setproctitle [1584,1596]
===
match
---
simple_stmt [6710,6740]
simple_stmt [6755,6785]
===
match
---
name: traceback [1048,1057]
name: traceback [1048,1057]
===
match
---
name: exception [5249,5258]
name: exception [5294,5303]
===
match
---
name: start [8436,8441]
name: start [8481,8486]
===
match
---
simple_stmt [3599,3607]
simple_stmt [3644,3652]
===
match
---
if_stmt [16175,16242]
if_stmt [15845,15912]
===
match
---
name: len [24954,24957]
name: len [24624,24627]
===
match
---
parameters [11989,12044]
parameters [12034,12089]
===
match
---
name: os [1008,1010]
name: os [1008,1010]
===
match
---
expr_stmt [15107,15152]
expr_stmt [14777,14822]
===
match
---
arglist [15401,15489]
arglist [15071,15159]
===
match
---
trailer [19349,19356]
trailer [19019,19026]
===
match
---
name: exception [17231,17240]
name: exception [16901,16910]
===
match
---
for_stmt [19134,19361]
for_stmt [18804,19031]
===
match
---
name: state [16705,16710]
name: state [16375,16380]
===
match
---
operator: , [1395,1396]
operator: , [1440,1441]
===
match
---
name: self [10926,10930]
name: self [10971,10975]
===
match
---
operator: , [16680,16681]
operator: , [16350,16351]
===
match
---
arglist [24954,24996]
arglist [24624,24666]
===
match
---
name: Task [1397,1401]
name: Task [1442,1446]
===
match
---
operator: } [24402,24403]
operator: } [24072,24073]
===
match
---
name: func [4015,4019]
name: func [4060,4064]
===
match
---
name: self [11886,11890]
name: self [11931,11935]
===
match
---
atom_expr [21451,21469]
atom_expr [21121,21139]
===
match
---
name: conf [2695,2699]
name: conf [2740,2744]
===
match
---
simple_stmt [23247,23314]
simple_stmt [22917,22984]
===
match
---
suite [7370,8427]
suite [7415,8472]
===
match
---
atom_expr [2616,2666]
atom_expr [2661,2711]
===
match
---
operator: = [25281,25282]
operator: = [24973,24974]
===
match
---
try_stmt [5771,6103]
try_stmt [5816,6148]
===
match
---
atom_expr [9236,9282]
atom_expr [9281,9327]
===
match
---
expr_stmt [19454,19593]
expr_stmt [19124,19263]
===
match
---
suite [3216,3259]
suite [3261,3304]
===
match
---
name: celery_states [17411,17424]
name: celery_states [17081,17094]
===
match
---
string: 'Error sending Celery task' [2428,2455]
string: 'Error sending Celery task' [2473,2500]
===
match
---
name: CommandType [5622,5633]
name: CommandType [5667,5678]
===
match
---
sync_comp_for [23180,23197]
sync_comp_for [22850,22867]
===
match
---
param [22145,22150]
param [21815,21820]
===
match
---
trailer [11416,11422]
trailer [11461,11467]
===
match
---
simple_stmt [3941,4001]
simple_stmt [3986,4046]
===
match
---
name: seconds [21164,21171]
name: seconds [20834,20841]
===
match
---
trailer [3551,3553]
trailer [3596,3598]
===
match
---
name: settings [1625,1633]
name: settings [1670,1678]
===
match
---
operator: ** [6237,6239]
operator: ** [6282,6284]
===
match
---
name: send_task_to_executor [13071,13092]
name: send_task_to_executor [12740,12761]
===
match
---
atom_expr [15430,15445]
atom_expr [15100,15115]
===
match
---
suite [23809,23899]
suite [23479,23569]
===
match
---
trailer [8187,8236]
trailer [8232,8281]
===
match
---
trailer [15960,15967]
trailer [15630,15637]
===
match
---
trailer [10656,10677]
trailer [10701,10722]
===
match
---
atom_expr [12213,12266]
atom_expr [12258,12311]
===
match
---
subscriptlist [5456,5525]
subscriptlist [5501,5570]
===
match
---
name: pop [10905,10908]
name: pop [10950,10953]
===
match
---
atom_expr [21640,21660]
atom_expr [21310,21330]
===
match
---
simple_stmt [15980,16019]
simple_stmt [15650,15689]
===
match
---
trailer [7386,7395]
trailer [7431,7440]
===
match
---
name: task_result [23389,23400]
name: task_result [23059,23070]
===
match
---
simple_stmt [7379,7398]
simple_stmt [7424,7443]
===
match
---
arglist [2491,2534]
arglist [2536,2579]
===
match
---
arglist [7803,7821]
arglist [7848,7866]
===
match
---
name: task_publish_retries [10657,10677]
name: task_publish_retries [10702,10722]
===
match
---
name: FAILURE [16729,16736]
name: FAILURE [16399,16406]
===
match
---
operator: , [16486,16487]
operator: , [16156,16157]
===
match
---
simple_stmt [19078,19096]
simple_stmt [18748,18766]
===
match
---
atom_expr [20006,20040]
atom_expr [19676,19710]
===
match
---
suite [24436,24801]
suite [24106,24471]
===
match
---
name: event_buffer [11736,11748]
name: event_buffer [11781,11793]
===
match
---
name: ti [19164,19166]
name: ti [18834,18836]
===
match
---
operator: = [7797,7798]
operator: = [7842,7843]
===
match
---
atom_expr [8465,8562]
atom_expr [8510,8607]
===
match
---
name: dispose [3700,3707]
name: dispose [3745,3752]
===
match
---
trailer [24718,24726]
trailer [24388,24396]
===
match
---
name: TaskInstanceInCelery [9191,9211]
name: TaskInstanceInCelery [9236,9256]
===
match
---
name: self [15980,15984]
name: self [15650,15654]
===
match
---
atom_expr [15592,15623]
atom_expr [15262,15293]
===
match
---
atom_expr [7379,7397]
atom_expr [7424,7442]
===
match
---
simple_stmt [8014,8099]
simple_stmt [8059,8144]
===
match
---
name: app [23738,23741]
name: app [23408,23411]
===
match
---
name: Mapping [24892,24899]
name: Mapping [24562,24569]
===
match
---
operator: = [7855,7856]
operator: = [7900,7901]
===
match
---
trailer [10835,10840]
trailer [10880,10885]
===
match
---
operator: , [10111,10112]
operator: , [10156,10157]
===
match
---
atom_expr [5450,5526]
atom_expr [5495,5571]
===
match
---
atom_expr [2270,2297]
atom_expr [2315,2342]
===
match
---
simple_stmt [25319,25394]
simple_stmt [25012,25087]
===
match
---
trailer [19763,19769]
trailer [19433,19439]
===
match
---
arglist [25082,25157]
arglist [24769,24844]
===
match
---
name: log [15810,15813]
name: log [15480,15483]
===
match
---
name: BaseExecutor [2992,3004]
name: BaseExecutor [3037,3049]
===
match
---
testlist [21640,21714]
testlist [21310,21384]
===
match
---
name: adopted [19603,19610]
name: adopted [19273,19280]
===
match
---
operator: = [3760,3761]
operator: = [3805,3806]
===
match
---
simple_stmt [6645,6680]
simple_stmt [6690,6725]
===
match
---
funcdef [22132,22252]
funcdef [21802,21922]
===
match
---
atom_expr [8822,8890]
atom_expr [8867,8935]
===
match
---
trailer [2287,2297]
trailer [2332,2342]
===
match
---
name: task_tuples_to_send [12448,12467]
name: task_tuples_to_send [12493,12512]
===
match
---
operator: = [4762,4763]
operator: = [4807,4808]
===
match
---
atom_expr [15637,15695]
atom_expr [15307,15365]
===
match
---
trailer [15485,15487]
trailer [15155,15157]
===
match
---
trailer [20337,20346]
trailer [20007,20016]
===
match
---
string: 'execute_command encountered a CalledProcessError' [4670,4720]
string: 'execute_command encountered a CalledProcessError' [4715,4765]
===
match
---
trailer [15382,15387]
trailer [15052,15057]
===
match
---
trailer [23686,23694]
trailer [23356,23364]
===
match
---
name: TaskInstanceKey [8047,8062]
name: TaskInstanceKey [8092,8107]
===
match
---
name: state_or_exception [25767,25785]
name: state_or_exception [25460,25478]
===
match
---
atom_expr [8042,8082]
atom_expr [8087,8127]
===
match
---
trailer [5604,5678]
trailer [5649,5723]
===
match
---
name: info [10545,10549]
name: info [10590,10594]
===
match
---
string: "Fetched %d state(s) for %d task(s)" [22885,22921]
string: "Fetched %d state(s) for %d task(s)" [22555,22591]
===
match
---
operator: , [8537,8538]
operator: , [8582,8583]
===
match
---
fstring_end: " [21623,21624]
fstring_end: " [21293,21294]
===
match
---
name: super [7379,7384]
name: super [7424,7429]
===
match
---
name: min [12494,12497]
name: min [12539,12542]
===
match
---
trailer [15473,15479]
trailer [15143,15149]
===
match
---
atom_expr [3679,3709]
atom_expr [3724,3754]
===
match
---
operator: , [10181,10182]
operator: , [10226,10227]
===
match
---
atom [5875,5884]
atom [5920,5929]
===
match
---
arglist [25505,25547]
arglist [25198,25240]
===
match
---
suite [16647,16688]
suite [16317,16358]
===
match
---
simple_stmt [4370,4394]
simple_stmt [4415,4439]
===
match
---
name: celery [1434,1440]
name: celery [1479,1485]
===
match
---
arglist [22885,22954]
arglist [22555,22624]
===
match
---
string: """     Fetch and return the state of the given celery task. The scope of this function is     global so that it can be called by subprocesses in the pool.      :param async_result: a tuple of the Celery task key and the async Celery object used         to fetch the task's state     :type async_result: tuple(str, celery.result.AsyncResult)     :return: a tuple of the Celery task key and the Celery state and the celery info         of the task     :rtype: tuple[str, str, str]     """ [20646,21133]
string: """     Fetch and return the state of the given celery task. The scope of this function is     global so that it can be called by subprocesses in the pool.      :param async_result: a tuple of the Celery task key and the async Celery object used         to fetch the task's state     :type async_result: tuple(str, celery.result.AsyncResult)     :return: a tuple of the Celery task key and the Celery state and the celery info         of the task     :rtype: tuple[str, str, str]     """ [20316,20803]
===
match
---
name: tasks [11417,11422]
name: tasks [11462,11467]
===
match
---
simple_stmt [3043,3104]
simple_stmt [3088,3149]
===
match
---
name: isinstance [10164,10174]
name: isinstance [10209,10219]
===
match
---
operator: = [2426,2427]
operator: = [2471,2472]
===
match
---
trailer [24616,24637]
trailer [24286,24307]
===
match
---
parameters [5554,5595]
parameters [5599,5640]
===
match
---
name: celery_tasks [19560,19572]
name: celery_tasks [19230,19242]
===
match
---
operator: , [23749,23750]
operator: , [23419,23420]
===
match
---
name: task_results [23908,23920]
name: task_results [23578,23590]
===
match
---
sync_comp_for [24060,24091]
sync_comp_for [23730,23761]
===
match
---
name: parse_args [3861,3871]
name: parse_args [3906,3916]
===
match
---
simple_stmt [7774,7823]
simple_stmt [7819,7868]
===
match
---
name: ResultSession [23695,23708]
name: ResultSession [23365,23378]
===
match
---
name: self [17868,17872]
name: self [17538,17542]
===
match
---
name: t [9793,9794]
name: t [9838,9839]
===
match
---
simple_stmt [8642,8807]
simple_stmt [8687,8852]
===
match
---
argument [12938,12961]
argument [12627,12652]
===
match
---
expr_stmt [9766,9818]
expr_stmt [9811,9863]
===
match
---
name: bash [6735,6739]
name: bash [6780,6784]
===
match
---
suite [11019,11266]
suite [11064,11311]
===
match
---
name: ceil [25101,25105]
name: ceil [24788,24792]
===
match
---
string: "executor.tasks (%d)\n\t%s" [15401,15428]
string: "executor.tasks (%d)\n\t%s" [15071,15098]
===
match
---
suite [16541,17292]
suite [16211,16962]
===
match
---
name: num_process [25027,25038]
name: num_process [24714,24725]
===
match
---
simple_stmt [19839,19878]
simple_stmt [19509,19548]
===
match
---
atom_expr [12524,12546]
atom_expr [12569,12591]
===
match
---
operator: = [2776,2777]
operator: = [2821,2822]
===
match
---
trailer [10904,10908]
trailer [10949,10953]
===
match
---
name: tasks [7911,7916]
name: tasks [7956,7961]
===
match
---
name: sorted_queue [9334,9346]
name: sorted_queue [9379,9391]
===
match
---
name: LoggingMixin [2085,2097]
name: LoggingMixin [2130,2142]
===
match
---
name: execute_command [9412,9427]
name: execute_command [9457,9472]
===
match
---
operator: , [11769,11770]
operator: , [11814,11815]
===
match
---
dotted_name [1651,1690]
dotted_name [1696,1735]
===
match
---
trailer [22190,22199]
trailer [21860,21869]
===
match
---
suite [4402,4552]
suite [4447,4597]
===
match
---
suite [16600,17147]
suite [16270,16817]
===
match
---
expr_stmt [24767,24800]
expr_stmt [24437,24470]
===
match
---
fstring_expr [6006,6011]
fstring_expr [6051,6056]
===
match
---
operator: , [8062,8063]
operator: , [8107,8108]
===
match
---
name: adopted_task_timeouts [15601,15622]
name: adopted_task_timeouts [15271,15292]
===
match
---
sync_comp_for [15014,15036]
sync_comp_for [14684,14706]
===
match
---
number: 0 [3449,3450]
number: 0 [3494,3495]
===
match
---
name: operators [6795,6804]
name: operators [6840,6849]
===
match
---
name: task_tuples_to_send [10032,10051]
name: task_tuples_to_send [10077,10096]
===
match
---
simple_stmt [1285,1343]
simple_stmt [1330,1388]
===
match
---
atom_expr [14950,14976]
atom_expr [14620,14646]
===
match
---
trailer [24953,24997]
trailer [24623,24667]
===
match
---
annassign [8280,8324]
annassign [8325,8369]
===
match
---
param [24874,24887]
param [24544,24557]
===
match
---
simple_stmt [23822,23899]
simple_stmt [23492,23569]
===
match
---
name: task_result [23373,23384]
name: task_result [23043,23054]
===
match
---
number: 1 [12085,12086]
number: 1 [12130,12131]
===
match
---
trailer [3733,3741]
trailer [3778,3786]
===
match
---
operator: = [19796,19797]
operator: = [19466,19467]
===
match
---
simple_stmt [11220,11266]
simple_stmt [11265,11311]
===
match
---
name: send_pool [13040,13049]
name: send_pool [12726,12735]
===
match
---
name: keys [23233,23237]
name: keys [22903,22907]
===
match
---
operator: , [5721,5722]
operator: , [5766,5767]
===
match
---
trailer [23094,23118]
trailer [22764,22788]
===
match
---
subscriptlist [5641,5676]
subscriptlist [5686,5721]
===
match
---
trailer [11386,11390]
trailer [11431,11435]
===
match
---
suite [19200,19300]
suite [18870,18970]
===
match
---
name: first_task [9953,9963]
name: first_task [9998,10008]
===
match
---
trailer [19504,19513]
trailer [19174,19183]
===
match
---
name: external_executor_id [19167,19187]
name: external_executor_id [18837,18857]
===
match
---
operator: = [8231,8232]
operator: = [8276,8277]
===
match
---
operator: = [9951,9952]
operator: = [9996,9997]
===
match
---
trailer [16073,16075]
trailer [15743,15745]
===
match
---
trailer [13268,13310]
trailer [12938,12980]
===
match
---
operator: , [2718,2719]
operator: , [2763,2764]
===
match
---
param [9700,9747]
param [9745,9792]
===
match
---
simple_stmt [24743,24755]
simple_stmt [24413,24425]
===
match
---
trailer [19769,19771]
trailer [19439,19441]
===
match
---
tfpdef [16488,16508]
tfpdef [16158,16178]
===
match
---
name: _send_tasks_to_celery [11968,11989]
name: _send_tasks_to_celery [12013,12034]
===
match
---
name: __name__ [2288,2296]
name: __name__ [2333,2341]
===
match
---
operator: , [17618,17619]
operator: , [17288,17289]
===
match
---
atom_expr [9506,9531]
atom_expr [9551,9576]
===
match
---
trailer [22334,22342]
trailer [22004,22012]
===
match
---
name: timeout [21156,21163]
name: timeout [20826,20833]
===
match
---
simple_stmt [15169,15189]
simple_stmt [14839,14859]
===
match
---
name: self [17222,17226]
name: self [16892,16896]
===
match
---
import_name [973,984]
import_name [973,984]
===
match
---
name: task_instance_str [20465,20482]
name: task_instance_str [20135,20152]
===
match
---
trailer [19677,19679]
trailer [19347,19349]
===
match
---
atom_expr [10317,10342]
atom_expr [10362,10387]
===
match
---
name: async_tasks [23652,23663]
name: async_tasks [23322,23333]
===
match
---
suite [22316,22365]
suite [21986,22035]
===
match
---
trailer [10930,10951]
trailer [10975,10996]
===
match
---
string: 'Error fetching Celery task state' [2363,2397]
string: 'Error fetching Celery task state' [2408,2442]
===
match
---
name: connect [6193,6200]
name: connect [6238,6245]
===
match
---
param [9694,9699]
param [9739,9744]
===
match
---
fstring_start: f" [21565,21567]
fstring_start: f" [21235,21237]
===
match
---
name: TaskInstanceKey [17573,17588]
name: TaskInstanceKey [17243,17258]
===
match
---
suite [17209,17292]
suite [16879,16962]
===
match
---
operator: , [22557,22558]
operator: , [22227,22228]
===
match
---
name: not_adopted_tis [20513,20528]
name: not_adopted_tis [20183,20198]
===
match
---
atom_expr [11412,11427]
atom_expr [11457,11472]
===
match
---
atom_expr [13254,13310]
atom_expr [12924,12980]
===
match
---
operator: -> [15267,15269]
operator: -> [14937,14939]
===
match
---
name: celery_configuration [2867,2887]
name: celery_configuration [2912,2932]
===
match
---
atom_expr [25085,25157]
atom_expr [24772,24844]
===
match
---
operator: = [2361,2362]
operator: = [2406,2407]
===
match
---
name: utils [2192,2197]
name: utils [2237,2242]
===
match
---
trailer [25016,25039]
trailer [24701,24726]
===
match
---
atom_expr [17450,17469]
atom_expr [17120,17139]
===
match
---
atom_expr [13230,13240]
atom_expr [12900,12910]
===
match
---
name: jinja2 [6584,6590]
name: jinja2 [6629,6635]
===
match
---
atom_expr [11169,11185]
atom_expr [11214,11230]
===
match
---
operator: , [24794,24795]
operator: , [24464,24465]
===
match
---
suite [25474,25924]
suite [25167,25617]
===
match
---
comparison [7733,7760]
comparison [7778,7805]
===
match
---
trailer [23151,23159]
trailer [22821,22829]
===
match
---
expr_stmt [9549,9583]
expr_stmt [9594,9628]
===
match
---
simple_stmt [10926,10961]
simple_stmt [10971,11006]
===
match
---
name: state [16616,16621]
name: state [16286,16291]
===
match
---
import_name [1001,1010]
import_name [1001,1010]
===
match
---
arith_expr [20043,20086]
arith_expr [19713,19756]
===
match
---
name: state [20264,20269]
name: state [19934,19939]
===
match
---
name: self [23090,23094]
name: self [22760,22764]
===
match
---
operator: = [22233,22234]
operator: = [21903,21904]
===
match
---
string: 'celery_config_options' [2642,2665]
string: 'celery_config_options' [2687,2710]
===
match
---
operator: = [13903,13904]
operator: = [13573,13574]
===
match
---
name: task_result [23349,23360]
name: task_result [23019,23030]
===
match
---
trailer [2481,2490]
trailer [2526,2535]
===
match
---
testlist_star_expr [24789,24800]
testlist_star_expr [24459,24470]
===
match
---
operator: -> [23032,23034]
operator: -> [22702,22704]
===
match
---
suite [16761,16799]
suite [16431,16469]
===
match
---
trailer [13946,13968]
trailer [13616,13638]
===
match
---
operator: , [21449,21450]
operator: , [21119,21120]
===
match
---
string: """Updates states of the tasks.""" [15762,15796]
string: """Updates states of the tasks.""" [15432,15466]
===
match
---
return_stmt [23427,23510]
return_stmt [23097,23180]
===
match
---
trailer [14783,14787]
trailer [14453,14457]
===
match
---
trailer [12021,12043]
trailer [12066,12088]
===
match
---
operator: , [5491,5492]
operator: , [5536,5537]
===
match
---
trailer [10075,10094]
trailer [10120,10139]
===
match
---
suite [19772,20273]
suite [19442,19943]
===
match
---
sync_comp_for [23292,23312]
sync_comp_for [22962,22982]
===
match
---
expr_stmt [11412,11436]
expr_stmt [11457,11481]
===
match
---
name: utils [2054,2059]
name: utils [2099,2104]
===
match
---
name: max [7799,7802]
name: max [7844,7847]
===
match
---
exprlist [10108,10122]
exprlist [10153,10167]
===
match
---
name: isinstance [22535,22545]
name: isinstance [22205,22215]
===
match
---
trailer [10481,10486]
trailer [10526,10531]
===
match
---
simple_stmt [5966,6039]
simple_stmt [6011,6084]
===
match
---
name: info [15517,15521]
name: info [15187,15191]
===
match
---
simple_stmt [24449,24500]
simple_stmt [24119,24170]
===
match
---
name: self [16264,16268]
name: self [15934,15938]
===
match
---
name: AsyncResult [20573,20584]
name: AsyncResult [20243,20254]
===
match
---
return_stmt [6108,6135]
return_stmt [6153,6180]
===
match
---
atom_expr [10810,10840]
atom_expr [10855,10885]
===
match
---
atom_expr [22546,22557]
atom_expr [22216,22227]
===
match
---
param [24868,24873]
param [24538,24543]
===
match
---
name: ret [4257,4260]
name: ret [4302,4305]
===
match
---
name: tasks [15474,15479]
name: tasks [15144,15149]
===
match
---
dotted_name [2103,2120]
dotted_name [2148,2165]
===
match
---
atom_expr [23434,23510]
atom_expr [23104,23180]
===
match
---
name: sync_pool [25201,25210]
name: sync_pool [24910,24919]
===
match
---
trailer [19657,19680]
trailer [19327,19350]
===
match
---
arglist [25646,25796]
arglist [25339,25489]
===
match
---
operator: , [22921,22922]
operator: , [22591,22592]
===
match
---
name: BaseKeyValueStoreBackend [22559,22583]
name: BaseKeyValueStoreBackend [22229,22253]
===
match
---
atom_expr [8333,8362]
atom_expr [8378,8407]
===
match
---
return_stmt [24809,24826]
return_stmt [24479,24496]
===
match
---
argument [8168,8236]
argument [8213,8281]
===
match
---
if_stmt [24512,24755]
if_stmt [24182,24425]
===
match
---
operator: , [11926,11927]
operator: , [11971,11972]
===
match
---
simple_stmt [2992,3039]
simple_stmt [3037,3084]
===
match
---
trailer [15860,15872]
trailer [15530,15542]
===
match
---
name: key [10956,10959]
name: key [11001,11004]
===
match
---
atom_expr [8829,8889]
atom_expr [8874,8934]
===
match
---
simple_stmt [1138,1227]
simple_stmt [1183,1272]
===
match
---
suite [25840,25924]
suite [25533,25617]
===
match
---
name: v [23289,23290]
name: v [22959,22960]
===
match
---
atom_expr [20060,20086]
atom_expr [19730,19756]
===
match
---
operator: , [15037,15038]
operator: , [14707,14708]
===
match
---
name: self [24974,24978]
name: self [24644,24648]
===
match
---
operator: = [5844,5845]
operator: = [5889,5890]
===
match
---
atom_expr [8311,8324]
atom_expr [8356,8369]
===
match
---
trailer [8096,8098]
trailer [8141,8143]
===
match
---
trailer [8018,8040]
trailer [8063,8085]
===
match
---
name: Any [17691,17694]
name: Any [17361,17364]
===
match
---
name: PENDING [17026,17033]
name: PENDING [16696,16703]
===
match
---
trailer [6078,6102]
trailer [6123,6147]
===
match
---
atom_expr [23568,23602]
atom_expr [23238,23272]
===
match
---
name: CommandType [3299,3310]
name: CommandType [3344,3355]
===
match
---
simple_stmt [8255,8325]
simple_stmt [8300,8370]
===
match
---
operator: { [6013,6014]
operator: { [6058,6059]
===
match
---
for_stmt [10104,11959]
for_stmt [10149,12004]
===
match
---
trailer [25100,25105]
trailer [24787,24792]
===
match
---
simple_stmt [4656,4722]
simple_stmt [4701,4767]
===
match
---
if_stmt [13223,13330]
if_stmt [12893,13000]
===
match
---
name: self [14779,14783]
name: self [14449,14453]
===
match
---
name: self [8255,8259]
name: self [8300,8304]
===
match
---
operator: == [17009,17011]
operator: == [16679,16681]
===
match
---
arglist [22546,22583]
arglist [22216,22253]
===
match
---
atom_expr [8255,8280]
atom_expr [8300,8325]
===
match
---
name: add [11387,11390]
name: add [11432,11435]
===
match
---
name: info [16522,16526]
name: info [16192,16196]
===
match
---
suite [9616,9670]
suite [9661,9715]
===
match
---
import_from [1827,1918]
import_from [1872,1963]
===
match
---
arglist [2632,2665]
arglist [2677,2710]
===
match
---
trailer [3021,3038]
trailer [3066,3083]
===
match
---
decorator [24190,24204]
decorator [23860,23874]
===
match
---
dotted_name [1290,1310]
dotted_name [1335,1355]
===
match
---
param [8442,8446]
param [8487,8491]
===
match
---
trailer [16787,16798]
trailer [16457,16468]
===
match
---
name: to_send_count [8849,8862]
name: to_send_count [8894,8907]
===
match
---
import_from [1058,1093]
import_from [1058,1093]
===
match
---
simple_stmt [17090,17147]
simple_stmt [16760,16817]
===
match
---
simple_stmt [4221,4240]
simple_stmt [4266,4285]
===
match
---
operator: , [1207,1208]
operator: , [1252,1253]
===
match
---
parameters [3281,3311]
parameters [3326,3356]
===
match
---
name: command_to_exec [3242,3257]
name: command_to_exec [3287,3302]
===
match
---
string: """     Preload some "expensive" airflow modules so that every task process doesn't have to import it again and     again.      Loading these for each task adds 0.3-0.5s *per task* before the task can run. For long running tasks this     doesn't matter, but for short tasks this starts to be a noticeable impact.     """ [6252,6572]
string: """     Preload some "expensive" airflow modules so that every task process doesn't have to import it again and     again.      Loading these for each task adds 0.3-0.5s *per task* before the task can run. For long running tasks this     doesn't matter, but for short tasks this starts to be a noticeable impact.     """ [6297,6617]
===
match
---
name: self [7655,7659]
name: self [7700,7704]
===
match
---
name: int [8621,8624]
name: int [8666,8669]
===
match
---
atom_expr [10652,10682]
atom_expr [10697,10727]
===
match
---
name: self [7874,7878]
name: self [7919,7923]
===
match
---
expr_stmt [4034,4041]
expr_stmt [4079,4086]
===
match
---
name: log [22875,22878]
name: log [22545,22548]
===
match
---
name: states_and_info_by_task_id [25861,25887]
name: states_and_info_by_task_id [25554,25580]
===
match
---
trailer [3687,3694]
trailer [3732,3739]
===
match
---
operator: = [20324,20325]
operator: = [19994,19995]
===
match
---
name: _execute_in_subprocess [3167,3189]
name: _execute_in_subprocess [3212,3234]
===
match
---
name: task_id [16154,16161]
name: task_id [15824,15831]
===
match
---
name: self [15861,15865]
name: self [15531,15535]
===
match
---
atom_expr [15374,15499]
atom_expr [15044,15169]
===
match
---
trailer [4014,4019]
trailer [4059,4064]
===
match
---
atom_expr [9262,9279]
atom_expr [9307,9324]
===
match
---
string: 'CELERY_APP_NAME' [2833,2850]
string: 'CELERY_APP_NAME' [2878,2895]
===
match
---
tfpdef [17665,17695]
tfpdef [17335,17365]
===
match
---
name: tasks [20104,20109]
name: tasks [19774,19779]
===
match
---
operator: = [11243,11244]
operator: = [11288,11289]
===
match
---
operator: = [4374,4375]
operator: = [4419,4420]
===
match
---
name: _sync_parallelism [12529,12546]
name: _sync_parallelism [12574,12591]
===
match
---
name: self [5169,5173]
name: self [5214,5218]
===
match
---
expr_stmt [15882,15970]
expr_stmt [15552,15640]
===
match
---
decorated [24190,24827]
decorated [23860,24497]
===
match
---
name: Union [20600,20605]
name: Union [20270,20275]
===
match
---
name: settings [3718,3726]
name: settings [3763,3771]
===
match
---
name: fetch_celery_task_state [25232,25255]
name: fetch_celery_task_state [24924,24947]
===
match
---
import_as_names [1247,1284]
import_as_names [1292,1329]
===
match
---
name: result [11936,11942]
name: result [11981,11987]
===
match
---
name: terminate [17858,17867]
name: terminate [17528,17537]
===
match
---
operator: , [5173,5174]
operator: , [5218,5219]
===
match
---
subscriptlist [20606,20633]
subscriptlist [20276,20303]
===
match
---
name: pid [3423,3426]
name: pid [3468,3471]
===
match
---
funcdef [13191,13460]
funcdef [12861,13130]
===
match
---
raise_stmt [4823,4850]
raise_stmt [4868,4895]
===
match
---
name: self [15739,15743]
name: self [15409,15413]
===
match
---
name: task_result [24048,24059]
name: task_result [23718,23729]
===
match
---
trailer [24490,24499]
trailer [24160,24169]
===
match
---
trailer [15378,15382]
trailer [15048,15052]
===
match
---
name: key_and_async_results [10126,10147]
name: key_and_async_results [10171,10192]
===
match
---
funcdef [3261,4298]
funcdef [3306,4343]
===
match
---
name: close_fds [4527,4536]
name: close_fds [4572,4581]
===
match
---
name: send_task_to_executor [5533,5554]
name: send_task_to_executor [5578,5599]
===
match
---
name: int [8629,8632]
name: int [8674,8677]
===
match
---
atom_expr [2477,2535]
atom_expr [2522,2580]
===
match
---
trailer [23232,23238]
trailer [22902,22908]
===
match
---
dotted_name [6851,6868]
dotted_name [6896,6913]
===
match
---
suite [20293,20497]
suite [19963,20167]
===
match
---
operator: } [3997,3998]
operator: } [4042,4043]
===
match
---
name: key [16444,16447]
name: key [16114,16117]
===
match
---
simple_stmt [20646,21134]
simple_stmt [20316,20804]
===
match
---
name: cli_parser [3641,3651]
name: cli_parser [3686,3696]
===
match
---
name: ExceptionWithTraceback [21662,21684]
name: ExceptionWithTraceback [21332,21354]
===
match
---
name: exception [4660,4669]
name: exception [4705,4714]
===
match
---
atom_expr [24463,24499]
atom_expr [24133,24169]
===
match
---
atom_expr [15434,15444]
atom_expr [15104,15114]
===
match
---
trailer [11378,11386]
trailer [11423,11431]
===
match
---
atom_expr [12498,12522]
atom_expr [12543,12567]
===
match
---
suite [19390,19445]
suite [19060,19115]
===
match
---
name: success [16669,16676]
name: success [16339,16346]
===
match
---
dotted_name [1472,1486]
dotted_name [1517,1531]
===
match
---
string: 'Celery command failed on host: ' [3503,3536]
string: 'Celery command failed on host: ' [3548,3581]
===
match
---
argument [25017,25038]
argument [24702,24725]
===
match
---
name: local_task_job [6665,6679]
name: local_task_job [6710,6724]
===
match
---
name: self [8600,8604]
name: self [8645,8649]
===
match
---
trailer [24035,24046]
trailer [23705,23716]
===
match
---
trailer [10712,10737]
trailer [10757,10782]
===
match
---
trailer [15462,15488]
trailer [15132,15158]
===
match
---
name: self [17450,17454]
name: self [17120,17124]
===
match
---
name: settings [3679,3687]
name: settings [3724,3732]
===
match
---
operator: , [20598,20599]
operator: , [20268,20269]
===
match
---
trailer [20605,20634]
trailer [20275,20304]
===
match
---
simple_stmt [1029,1041]
simple_stmt [1029,1041]
===
match
---
name: v [23296,23297]
name: v [22966,22967]
===
match
---
operator: = [8175,8176]
operator: = [8220,8221]
===
match
---
trailer [8259,8280]
trailer [8304,8325]
===
match
---
operator: = [3410,3411]
operator: = [3455,3456]
===
match
---
name: key [5718,5721]
name: key [5763,5766]
===
match
---
param [16264,16269]
param [15934,15939]
===
match
---
name: query [23838,23843]
name: query [23508,23513]
===
match
---
parameters [23012,23031]
parameters [22682,22701]
===
match
---
name: command [5726,5733]
name: command [5771,5778]
===
match
---
operator: , [22934,22935]
operator: , [22604,22605]
===
match
---
trailer [11390,11395]
trailer [11435,11440]
===
match
---
atom_expr [4198,4212]
atom_expr [4243,4257]
===
match
---
name: configuration [1733,1746]
name: configuration [1778,1791]
===
match
---
name: x [15011,15012]
name: x [14681,14682]
===
match
---
name: num_processes [12478,12491]
name: num_processes [12523,12536]
===
match
---
trailer [20045,20057]
trailer [19715,19727]
===
match
---
atom_expr [10005,10052]
atom_expr [10050,10097]
===
match
---
classdef [4853,5304]
classdef [4898,5349]
===
match
---
trailer [24777,24786]
trailer [24447,24456]
===
match
---
trailer [12501,12522]
trailer [12546,12567]
===
match
---
string: """Updates state of a single task.""" [16550,16587]
string: """Updates state of a single task.""" [16220,16257]
===
match
---
simple_stmt [3847,3893]
simple_stmt [3892,3938]
===
match
---
name: change_state [16340,16352]
name: change_state [16010,16022]
===
match
---
param [16304,16313]
param [15974,15983]
===
match
---
name: result [10116,10122]
name: result [10161,10167]
===
match
---
param [23013,23018]
param [22683,22688]
===
match
---
name: result [11319,11325]
name: result [11364,11370]
===
match
---
name: chunksize [25282,25291]
name: chunksize [24974,24983]
===
match
---
name: result [19785,19791]
name: result [19455,19461]
===
match
---
name: itemgetter [19545,19555]
name: itemgetter [19215,19225]
===
match
---
for_stmt [9227,9584]
for_stmt [9272,9629]
===
match
---
trailer [8322,8324]
trailer [8367,8369]
===
match
---
name: result [11914,11920]
name: result [11959,11965]
===
match
---
name: info [16365,16369]
name: info [16035,16039]
===
match
---
name: List [9186,9190]
name: List [9231,9235]
===
match
---
suite [24927,25966]
suite [24597,25659]
===
match
---
operator: , [22688,22689]
operator: , [22358,22359]
===
match
---
name: items [16068,16073]
name: items [15738,15743]
===
match
---
name: map [12218,12221]
name: map [12263,12266]
===
match
---
name: Mapping [24301,24308]
name: Mapping [23971,23978]
===
match
---
trailer [10814,10835]
trailer [10859,10880]
===
match
---
import_from [3560,3593]
import_from [3605,3638]
===
match
---
testlist_comp [16715,16759]
testlist_comp [16385,16429]
===
match
---
name: queue [17628,17633]
name: queue [17298,17303]
===
match
---
trailer [9460,9467]
trailer [9505,9512]
===
match
---
simple_stmt [16379,16405]
simple_stmt [16049,16075]
===
match
---
name: EventBufferValueType [24377,24397]
name: EventBufferValueType [24047,24067]
===
match
---
expr_stmt [25066,25158]
expr_stmt [24753,24845]
===
match
---
trailer [13424,13457]
trailer [13094,13127]
===
match
---
name: super [22183,22188]
name: super [21853,21858]
===
match
---
name: Exception [5910,5919]
name: Exception [5955,5964]
===
match
---
trailer [23843,23853]
trailer [23513,23523]
===
match
---
atom_expr [21600,21622]
atom_expr [21270,21292]
===
match
---
name: result [20120,20126]
name: result [19790,19796]
===
match
---
tfpdef [17598,17618]
tfpdef [17268,17288]
===
match
---
atom_expr [22666,22706]
atom_expr [22336,22376]
===
match
---
operator: -> [16315,16317]
operator: -> [15985,15987]
===
match
---
sync_comp_for [22343,22363]
sync_comp_for [22013,22033]
===
match
---
atom_expr [22936,22954]
atom_expr [22606,22624]
===
match
---
atom_expr [15459,15488]
atom_expr [15129,15158]
===
match
---
subscriptlist [25362,25387]
subscriptlist [25055,25080]
===
match
---
name: ExceptionWithTraceback [5654,5676]
name: ExceptionWithTraceback [5699,5721]
===
match
---
trailer [23176,23179]
trailer [22846,22849]
===
match
---
trailer [3004,3021]
trailer [3049,3066]
===
match
---
name: Set [22307,22310]
name: Set [21977,21980]
===
match
---
name: backend [9964,9971]
name: backend [10009,10016]
===
match
---
trailer [16728,16736]
trailer [16398,16406]
===
match
---
atom_expr [22923,22934]
atom_expr [22593,22604]
===
match
---
trailer [19232,19253]
trailer [18902,18923]
===
match
---
name: getimport [2700,2709]
name: getimport [2745,2754]
===
match
---
name: command_to_exec [3982,3997]
name: command_to_exec [4027,4042]
===
match
---
trailer [15663,15685]
trailer [15333,15355]
===
match
---
return_stmt [21422,21475]
return_stmt [21092,21145]
===
match
---
name: get [2819,2822]
name: get [2864,2867]
===
match
---
simple_stmt [6613,6640]
simple_stmt [6658,6685]
===
match
---
operator: = [25389,25390]
operator: = [25082,25083]
===
match
---
trailer [20103,20109]
trailer [19773,19779]
===
match
---
suite [8456,8563]
suite [8501,8608]
===
match
---
name: utcnow [2256,2262]
name: utcnow [2301,2307]
===
match
---
name: self [8333,8337]
name: self [8378,8382]
===
match
---
operator: { [6006,6007]
operator: { [6051,6052]
===
match
---
expr_stmt [4758,4814]
expr_stmt [4803,4859]
===
match
---
import_as_names [1871,1918]
import_as_names [1916,1963]
===
match
---
atom_expr [3167,3206]
atom_expr [3212,3251]
===
match
---
testlist_comp [23263,23312]
testlist_comp [22933,22982]
===
match
---
simple_stmt [5684,5714]
simple_stmt [5729,5759]
===
match
---
expr_stmt [7655,7721]
expr_stmt [7700,7766]
===
match
---
simple_stmt [6684,6706]
simple_stmt [6729,6751]
===
match
---
name: pop [16440,16443]
name: pop [16110,16113]
===
match
---
name: EventBufferValueType [23581,23601]
name: EventBufferValueType [23251,23271]
===
match
---
name: stalled_after [13993,14006]
name: stalled_after [13663,13676]
===
match
---
fstring_string:  in state  [20253,20263]
fstring_string:  in state  [19923,19933]
===
match
---
operator: , [12243,12244]
operator: , [12288,12289]
===
match
---
name: sleep [17493,17498]
name: sleep [17163,17168]
===
match
---
if_stmt [20282,20497]
if_stmt [19952,20167]
===
match
---
parameters [22382,22403]
parameters [22052,22073]
===
match
---
arglist [2814,2887]
arglist [2859,2932]
===
match
---
name: airflow [2103,2110]
name: airflow [2148,2155]
===
match
---
atom_expr [3043,3103]
atom_expr [3088,3148]
===
match
---
name: map [15649,15652]
name: map [15319,15322]
===
match
---
import_as_names [1790,1826]
import_as_names [1835,1871]
===
match
---
simple_stmt [12206,12267]
simple_stmt [12251,12312]
===
match
---
testlist [21429,21475]
testlist [21099,21145]
===
match
---
name: traceback [5272,5281]
name: traceback [5317,5326]
===
match
---
operator: = [11428,11429]
operator: = [11473,11474]
===
match
---
trailer [16223,16241]
trailer [15893,15911]
===
match
---
atom_expr [22607,22652]
atom_expr [22277,22322]
===
match
---
simple_stmt [20306,20347]
simple_stmt [19976,20017]
===
match
---
name: _prepare_state_and_info_by_task_dict [24212,24248]
name: _prepare_state_and_info_by_task_dict [23882,23918]
===
match
---
raise_stmt [3480,3554]
raise_stmt [3525,3599]
===
match
---
trailer [10951,10955]
trailer [10996,11000]
===
match
---
name: chunksize [25272,25281]
name: chunksize [24964,24973]
===
match
---
name: _sync_parallelism [7660,7677]
name: _sync_parallelism [7705,7722]
===
match
---
simple_stmt [22210,22252]
simple_stmt [21880,21922]
===
match
---
name: str [22311,22314]
name: str [21981,21984]
===
match
---
fstring_expr [21583,21597]
fstring_expr [21253,21267]
===
match
---
name: task_cls [23844,23852]
name: task_cls [23514,23522]
===
match
---
atom_expr [2992,3038]
atom_expr [3037,3083]
===
match
---
operator: , [9309,9310]
operator: , [9354,9355]
===
match
---
comp_op [17404,17410]
comp_op [17074,17080]
===
match
---
simple_stmt [2333,2398]
simple_stmt [2378,2443]
===
match
---
expr_stmt [23247,23313]
expr_stmt [22917,22983]
===
match
---
trailer [10486,10515]
trailer [10531,10560]
===
match
---
operator: , [3404,3405]
operator: , [3449,3450]
===
match
---
name: self [23546,23550]
name: self [23216,23220]
===
match
---
expr_stmt [7831,7897]
expr_stmt [7876,7942]
===
match
---
name: self [10369,10373]
name: self [10414,10418]
===
match
---
trailer [4204,4210]
trailer [4249,4255]
===
match
---
operator: , [9312,9313]
operator: , [9357,9358]
===
match
---
trailer [14793,15052]
trailer [14463,14722]
===
match
---
operator: , [1977,1978]
operator: , [2022,2023]
===
match
---
del_stmt [15205,15240]
del_stmt [14875,14910]
===
match
---
simple_stmt [2399,2456]
simple_stmt [2444,2501]
===
match
---
except_clause [5903,5924]
except_clause [5948,5969]
===
match
---
dotted_name [2892,2900]
dotted_name [2937,2945]
===
match
---
expr_stmt [13889,13907]
expr_stmt [13559,13577]
===
match
---
suite [5957,6103]
suite [6002,6148]
===
match
---
atom_expr [16332,16370]
atom_expr [16002,16040]
===
match
---
simple_stmt [9981,10053]
simple_stmt [10026,10098]
===
match
---
operator: = [24399,24400]
operator: = [24069,24070]
===
match
---
name: Any [1157,1160]
name: Any [1202,1205]
===
match
---
parameters [17921,17952]
parameters [17591,17622]
===
match
---
trailer [6023,6034]
trailer [6068,6079]
===
match
---
name: self [15950,15954]
name: self [15620,15624]
===
match
---
operator: -> [17338,17340]
operator: -> [17008,17010]
===
match
---
name: async_results [25116,25129]
name: async_results [24803,24816]
===
match
---
expr_stmt [6047,6102]
expr_stmt [6092,6147]
===
match
---
trailer [8046,8082]
trailer [8091,8127]
===
match
---
operator: = [9213,9214]
operator: = [9258,9259]
===
match
---
suite [22788,22862]
suite [22458,22532]
===
match
---
param [4327,4355]
param [4372,4400]
===
match
---
atom_expr [8176,8236]
atom_expr [8221,8281]
===
match
---
name: base_executor [1850,1863]
name: base_executor [1895,1908]
===
match
---
operator: } [21596,21597]
operator: } [21266,21267]
===
match
---
atom_expr [4508,4525]
atom_expr [4553,4570]
===
match
---
name: Task [5521,5525]
name: Task [5566,5570]
===
match
---
simple_stmt [15805,15874]
simple_stmt [15475,15544]
===
match
---
trailer [9510,9531]
trailer [9555,9576]
===
match
---
operator: = [23214,23215]
operator: = [22884,22885]
===
match
---
operator: , [22149,22150]
operator: , [21819,21820]
===
match
---
name: self [22383,22387]
name: self [22053,22057]
===
match
---
name: key [11749,11752]
name: key [11794,11797]
===
match
---
name: EventBufferValueType [22420,22440]
name: EventBufferValueType [22090,22110]
===
match
---
atom_expr [24108,24184]
atom_expr [23778,23854]
===
match
---
operator: = [2693,2694]
operator: = [2738,2739]
===
match
---
suite [3451,3471]
suite [3496,3516]
===
match
---
trailer [16056,16076]
trailer [15726,15746]
===
match
---
operator: , [5633,5634]
operator: , [5678,5679]
===
match
---
param [17598,17619]
param [17268,17289]
===
match
---
trailer [22846,22861]
trailer [22516,22531]
===
match
---
arglist [8826,8889]
arglist [8871,8934]
===
match
---
name: backend [23928,23935]
name: backend [23598,23605]
===
match
---
trailer [20363,20367]
trailer [20033,20037]
===
match
---
string: 'celery' [2710,2718]
string: 'celery' [2755,2763]
===
match
---
name: ti [19793,19795]
name: ti [19463,19465]
===
match
---
trailer [19544,19555]
trailer [19214,19225]
===
match
---
comparison [13993,14012]
comparison [13663,13682]
===
match
---
string: "clearing:\n\t%s" [14915,14932]
string: "clearing:\n\t%s" [14585,14602]
===
match
---
name: tasks [15866,15871]
name: tasks [15536,15541]
===
match
---
operator: , [19558,19559]
operator: , [19228,19229]
===
match
---
name: engine [3688,3694]
name: engine [3733,3739]
===
match
---
name: key [17568,17571]
name: key [17238,17241]
===
match
---
suite [17073,17147]
suite [16743,16817]
===
match
---
operator: = [23728,23729]
operator: = [23398,23399]
===
match
---
arglist [10239,10275]
arglist [10284,10320]
===
match
---
comparison [12057,12086]
comparison [12102,12131]
===
match
---
trailer [19555,19558]
trailer [19225,19228]
===
match
---
atom_expr [17393,17403]
atom_expr [17063,17073]
===
match
---
name: msg [4846,4849]
name: msg [4891,4894]
===
match
---
name: task_id [11778,11785]
name: task_id [11823,11830]
===
match
---
atom_expr [15659,15693]
atom_expr [15329,15363]
===
match
---
trailer [10245,10255]
trailer [10290,10300]
===
match
---
string: 'task_publish_max_retries' [8387,8413]
string: 'task_publish_max_retries' [8432,8458]
===
match
---
name: e [4740,4741]
name: e [4785,4786]
===
match
---
atom_expr [10407,10436]
atom_expr [10452,10481]
===
match
---
trailer [25115,25130]
trailer [24802,24817]
===
match
---
simple_stmt [13889,13908]
simple_stmt [13559,13578]
===
match
---
name: join [15454,15458]
name: join [15124,15128]
===
match
---
name: fallback [8415,8423]
name: fallback [8460,8468]
===
match
---
trailer [4470,4483]
trailer [4515,4528]
===
match
---
atom_expr [15133,15145]
atom_expr [14803,14815]
===
match
---
name: key [10399,10402]
name: key [10444,10447]
===
match
---
name: airflow [2226,2233]
name: airflow [2271,2278]
===
match
---
argument [5797,5822]
argument [5842,5867]
===
match
---
atom_expr [15508,15706]
atom_expr [15178,15376]
===
match
---
atom_expr [11036,11203]
atom_expr [11081,11248]
===
match
---
expr_stmt [21543,21624]
expr_stmt [21213,21294]
===
match
---
atom_expr [22183,22201]
atom_expr [21853,21871]
===
match
---
name: self [16664,16668]
name: self [16334,16338]
===
match
---
name: key [11909,11912]
name: key [11954,11957]
===
match
---
funcdef [24208,24827]
funcdef [23878,24497]
===
match
---
atom_expr [4460,4551]
atom_expr [4505,4596]
===
match
---
string: """         How many Celery tasks should each worker process send.          :return: Number of tasks that should be sent per process         :rtype: int         """ [8642,8806]
string: """         How many Celery tasks should each worker process send.          :return: Number of tasks that should be sent per process         :rtype: int         """ [8687,8851]
===
match
---
for_stmt [16027,16242]
for_stmt [15697,15912]
===
match
---
expr_stmt [20006,20086]
expr_stmt [19676,19756]
===
match
---
suite [7761,7823]
suite [7806,7868]
===
match
---
simple_stmt [4198,4213]
simple_stmt [4243,4258]
===
match
---
simple_stmt [7655,7722]
simple_stmt [7700,7767]
===
match
---
trailer [24957,24972]
trailer [24627,24642]
===
match
---
name: chunksize [25066,25075]
name: chunksize [24753,24762]
===
match
---
trailer [25578,25584]
trailer [25271,25277]
===
match
---
funcdef [4300,4851]
funcdef [4345,4896]
===
match
---
exprlist [16031,16048]
exprlist [15701,15718]
===
match
---
simple_stmt [20359,20497]
simple_stmt [20029,20167]
===
match
---
name: key [14735,14738]
name: key [14405,14408]
===
match
---
name: simple_ti [9385,9394]
name: simple_ti [9430,9439]
===
match
---
operator: , [14932,14933]
operator: , [14602,14603]
===
match
---
name: get [24487,24490]
name: get [24157,24160]
===
match
---
simple_stmt [19434,19445]
simple_stmt [19104,19115]
===
match
---
name: check_output [4471,4483]
name: check_output [4516,4528]
===
match
---
name: Any [20636,20639]
name: Any [20306,20309]
===
match
---
parameters [16481,16532]
parameters [16151,16202]
===
match
---
param [5197,5221]
param [5242,5266]
===
match
---
atom_expr [14779,15052]
atom_expr [14449,14722]
===
match
---
import_name [6577,6594]
import_name [6622,6639]
===
match
---
trailer [24978,24996]
trailer [24648,24666]
===
match
---
parameters [20558,20585]
parameters [20228,20255]
===
match
---
import_from [2221,2262]
import_from [2266,2307]
===
match
---
operator: , [4151,4152]
operator: , [4196,4197]
===
match
---
operator: , [17588,17589]
operator: , [17258,17259]
===
match
---
if_stmt [16613,17147]
if_stmt [16283,16817]
===
match
---
simple_stmt [21342,21410]
simple_stmt [21012,21080]
===
match
---
trailer [15177,15183]
trailer [14847,14853]
===
match
---
name: task_ids [24258,24266]
name: task_ids [23928,23936]
===
match
---
trailer [20155,20163]
trailer [19825,19833]
===
match
---
simple_stmt [8333,8427]
simple_stmt [8378,8472]
===
match
---
arglist [6079,6101]
arglist [6124,6146]
===
match
---
name: celery_tasks [19658,19670]
name: celery_tasks [19328,19340]
===
match
---
expr_stmt [19839,19877]
expr_stmt [19509,19547]
===
match
---
name: sentry [3573,3579]
name: sentry [3618,3624]
===
match
---
trailer [23475,23510]
trailer [23145,23180]
===
match
---
trailer [14734,14739]
trailer [14404,14409]
===
match
---
name: queue [9405,9410]
name: queue [9450,9455]
===
match
---
suite [21754,25966]
suite [21424,25659]
===
match
---
name: result [6047,6053]
name: result [6092,6098]
===
match
---
atom_expr [10476,10515]
atom_expr [10521,10560]
===
match
---
operator: + [25674,25675]
operator: + [25367,25368]
===
match
---
name: adopted [20455,20462]
name: adopted [20125,20132]
===
match
---
operator: , [15623,15624]
operator: , [15293,15294]
===
match
---
name: task_publish_retries [10931,10951]
name: task_publish_retries [10976,10996]
===
match
---
try_stmt [4398,4851]
try_stmt [4443,4896]
===
match
---
simple_stmt [3679,3710]
simple_stmt [3724,3755]
===
match
---
name: map [15459,15462]
name: map [15129,15132]
===
match
---
trailer [3414,3422]
trailer [3459,3467]
===
match
---
name: ExceptionWithTraceback [10183,10205]
name: ExceptionWithTraceback [10228,10250]
===
match
---
atom_expr [21429,21449]
atom_expr [21099,21119]
===
match
---
trailer [17519,17521]
trailer [17189,17191]
===
match
---
operator: , [17655,17656]
operator: , [17325,17326]
===
match
---
name: state_info [24767,24777]
name: state_info [24437,24447]
===
match
---
number: 0 [19682,19683]
number: 0 [19352,19353]
===
match
---
name: Any [16528,16531]
name: Any [16198,16201]
===
match
---
trailer [2699,2709]
trailer [2744,2754]
===
match
---
dictorsetmaker [23349,23416]
dictorsetmaker [23019,23086]
===
match
---
dotted_name [6691,6705]
dotted_name [6736,6750]
===
match
---
atom_expr [3412,3430]
atom_expr [3457,3475]
===
match
---
trailer [6034,6036]
trailer [6079,6081]
===
match
---
name: TaskInstanceKey [16493,16508]
name: TaskInstanceKey [16163,16178]
===
match
---
atom [19613,19615]
atom [19283,19285]
===
match
---
parameters [5168,5222]
parameters [5213,5267]
===
match
---
fstring_end: " [6037,6038]
fstring_end: " [6082,6083]
===
match
---
name: datetime [8064,8072]
name: datetime [8109,8117]
===
match
---
name: command [9302,9309]
name: command [9347,9354]
===
match
---
dotted_name [6652,6679]
dotted_name [6697,6724]
===
match
---
funcdef [20531,21715]
funcdef [20201,21385]
===
match
---
name: self [9262,9266]
name: self [9307,9311]
===
match
---
tfpdef [5560,5592]
tfpdef [5605,5637]
===
match
---
trailer [4112,4122]
trailer [4157,4167]
===
match
---
parameters [22144,22173]
parameters [21814,21843]
===
match
---
subscriptlist [8287,8307]
subscriptlist [8332,8352]
===
match
---
name: timeout [2213,2220]
name: timeout [2258,2265]
===
match
---
name: log [10066,10069]
name: log [10111,10114]
===
match
---
name: result [10175,10181]
name: result [10220,10226]
===
match
---
trailer [11325,11333]
trailer [11370,11378]
===
match
---
name: task_results_by_task_id [24268,24291]
name: task_results_by_task_id [23938,23961]
===
match
---
name: args [6231,6235]
name: args [6276,6280]
===
match
---
argument [8415,8425]
argument [8460,8470]
===
match
---
trailer [13053,13148]
trailer [12739,12804]
===
match
---
trailer [25214,25305]
trailer [24923,24984]
===
match
---
name: self [7906,7910]
name: self [7951,7955]
===
match
---
trailer [17643,17648]
trailer [17313,17318]
===
match
---
trailer [23860,23892]
trailer [23530,23562]
===
match
---
name: keys [23140,23144]
name: keys [22810,22814]
===
match
---
atom_expr [25767,25795]
atom_expr [25460,25488]
===
match
---
suite [20641,21715]
suite [20311,21385]
===
match
---
suite [6906,6920]
suite [6951,6965]
===
match
---
expr_stmt [23908,23988]
expr_stmt [23578,23658]
===
match
---
name: parser [3854,3860]
name: parser [3899,3905]
===
match
---
atom_expr [23683,23710]
atom_expr [23353,23380]
===
match
---
expr_stmt [23719,23770]
expr_stmt [23389,23440]
===
match
---
operator: = [9777,9778]
operator: = [9822,9823]
===
match
---
atom_expr [12017,12043]
atom_expr [12062,12088]
===
match
---
param [5169,5174]
param [5214,5219]
===
match
---
simple_stmt [17719,17775]
simple_stmt [17389,17445]
===
match
---
name: backend [23267,23274]
name: backend [22937,22944]
===
match
---
simple_stmt [22183,22202]
simple_stmt [21853,21872]
===
match
---
suite [14013,14163]
suite [13683,13833]
===
match
---
atom_expr [22407,22441]
atom_expr [22077,22111]
===
match
---
number: 0 [9351,9352]
number: 0 [9396,9397]
===
match
---
trailer [13457,13459]
trailer [13127,13129]
===
match
---
trailer [23159,23176]
trailer [22829,22846]
===
match
---
expr_stmt [10810,10845]
expr_stmt [10855,10890]
===
match
---
return_stmt [21633,21714]
return_stmt [21303,21384]
===
match
---
name: task_tuple [5756,5766]
name: task_tuple [5801,5811]
===
match
---
simple_stmt [19217,19300]
simple_stmt [18887,18970]
===
match
---
simple_stmt [17510,17522]
simple_stmt [17180,17192]
===
match
---
atom_expr [23784,23808]
atom_expr [23454,23478]
===
match
---
operator: , [5620,5621]
operator: , [5665,5666]
===
match
---
import_name [1011,1028]
import_name [1011,1028]
===
match
---
name: get_many [22374,22382]
name: get_many [22044,22052]
===
match
---
atom_expr [21349,21366]
atom_expr [21019,21036]
===
match
---
name: utils [2111,2116]
name: utils [2156,2161]
===
match
---
name: on_celery_import_modules [6205,6229]
name: on_celery_import_modules [6250,6274]
===
match
---
atom_expr [3539,3553]
atom_expr [3584,3598]
===
match
---
expr_stmt [3847,3892]
expr_stmt [3892,3937]
===
match
---
arith_expr [7806,7821]
arith_expr [7851,7866]
===
match
---
funcdef [22370,22978]
funcdef [22040,22648]
===
match
---
name: state [11921,11926]
name: state [11966,11971]
===
match
---
name: task_id_to_states_and_info [25447,25473]
name: task_id_to_states_and_info [25140,25166]
===
match
---
suite [4100,4177]
suite [4145,4222]
===
match
---
simple_stmt [9165,9218]
simple_stmt [9210,9263]
===
match
---
name: _exit [4251,4256]
name: _exit [4296,4301]
===
match
---
name: max [25078,25081]
name: max [24765,24768]
===
match
---
name: setproctitle [3941,3953]
name: setproctitle [3986,3998]
===
match
---
dotted_as_name [1617,1645]
dotted_as_name [1662,1690]
===
match
---
simple_stmt [3624,3670]
simple_stmt [3669,3715]
===
match
---
operator: } [6036,6037]
operator: } [6081,6082]
===
match
---
name: ti [20250,20252]
name: ti [19920,19922]
===
match
---
with_stmt [21151,21476]
with_stmt [20821,21146]
===
match
---
name: command_to_exec [3282,3297]
name: command_to_exec [3327,3342]
===
match
---
name: map [19532,19535]
name: map [19202,19205]
===
match
---
try_stmt [6831,6920]
try_stmt [6876,6965]
===
match
---
number: 1 [10844,10845]
number: 1 [10889,10890]
===
match
---
simple_stmt [1467,1534]
simple_stmt [1512,1579]
===
match
---
atom_expr [11886,11958]
atom_expr [11931,12003]
===
match
---
trailer [8469,8473]
trailer [8514,8518]
===
match
---
name: mget [23228,23232]
name: mget [22898,22902]
===
match
---
name: task_tuples_to_send [11996,12015]
name: task_tuples_to_send [12041,12060]
===
match
---
operator: , [16302,16303]
operator: , [15972,15973]
===
match
---
name: exception_traceback [21543,21562]
name: exception_traceback [21213,21232]
===
match
---
name: AirflowException [17789,17805]
name: AirflowException [17459,17475]
===
match
---
for_stmt [13916,14740]
for_stmt [13586,14410]
===
match
---
name: FAILED [15139,15145]
name: FAILED [14809,14815]
===
match
---
arglist [16677,16686]
arglist [16347,16356]
===
match
---
name: str [4153,4156]
name: str [4198,4201]
===
match
---
atom_expr [20139,20163]
atom_expr [19809,19833]
===
match
---
name: airflow [6652,6659]
name: airflow [6697,6704]
===
match
---
comparison [16705,16760]
comparison [16375,16430]
===
match
---
trailer [19513,19593]
trailer [19183,19263]
===
match
---
name: kubernetes [6851,6861]
name: kubernetes [6896,6906]
===
match
---
trailer [3699,3707]
trailer [3744,3752]
===
match
---
trailer [7878,7896]
trailer [7923,7941]
===
match
---
name: task_ids [23189,23197]
name: task_ids [22859,22867]
===
match
---
atom_expr [4656,4721]
atom_expr [4701,4766]
===
match
---
param [6237,6245]
param [6282,6290]
===
match
---
name: all [23893,23896]
name: all [23563,23566]
===
match
---
number: 1.0 [25106,25109]
number: 1.0 [24793,24796]
===
match
---
trailer [22878,22884]
trailer [22548,22554]
===
match
---
atom_expr [19653,19680]
atom_expr [19323,19350]
===
match
---
atom_expr [5599,5678]
atom_expr [5644,5723]
===
match
---
name: task_publish_retries [8260,8280]
name: task_publish_retries [8305,8325]
===
match
---
trailer [13049,13053]
trailer [12735,12739]
===
match
---
operator: -> [24298,24300]
operator: -> [23968,23970]
===
match
---
atom_expr [5635,5677]
atom_expr [5680,5722]
===
match
---
name: debug [15814,15819]
name: debug [15484,15489]
===
match
---
name: getint [7685,7691]
name: getint [7730,7736]
===
match
---
name: _num_tasks_per_send_process [12416,12443]
name: _num_tasks_per_send_process [12461,12488]
===
match
---
name: airflow [2046,2053]
name: airflow [2091,2098]
===
match
---
atom_expr [4010,4025]
atom_expr [4055,4070]
===
match
---
name: EventBufferValueType [25367,25387]
name: EventBufferValueType [25060,25080]
===
match
---
fstring_string: Celery Task ID:  [5990,6006]
fstring_string: Celery Task ID:  [6035,6051]
===
match
---
return_stmt [22964,22977]
return_stmt [22634,22647]
===
match
---
operator: , [1160,1161]
operator: , [1205,1206]
===
match
---
simple_stmt [13338,13368]
simple_stmt [13008,13038]
===
match
---
expr_stmt [19603,19615]
expr_stmt [19273,19285]
===
match
---
expr_stmt [9981,10052]
expr_stmt [10026,10097]
===
match
---
trailer [10174,10206]
trailer [10219,10251]
===
match
---
name: task_adoption_timeout [14955,14976]
name: task_adoption_timeout [14625,14646]
===
match
---
name: _sync_parallelism [22215,22232]
name: _sync_parallelism [21885,21902]
===
match
---
fstring_string: \n [21597,21599]
fstring_string: \n [21267,21269]
===
match
---
name: parser [3753,3759]
name: parser [3798,3804]
===
match
---
name: _sync_parallelism [8544,8561]
name: _sync_parallelism [8589,8606]
===
match
---
name: log [25575,25578]
name: log [25268,25271]
===
match
---
funcdef [17854,17888]
funcdef [17524,17558]
===
match
---
suite [13214,13460]
suite [12884,13130]
===
match
---
trailer [23741,23749]
trailer [23411,23419]
===
match
---
operator: = [23828,23829]
operator: = [23498,23499]
===
match
---
arglist [24150,24183]
arglist [23820,23853]
===
match
---
name: BaseExecutor [1871,1883]
name: BaseExecutor [1916,1928]
===
match
---
trailer [23892,23896]
trailer [23562,23566]
===
match
---
trailer [22188,22190]
trailer [21858,21860]
===
match
---
with_item [12933,13002]
with_item [12607,12666]
===
match
---
trailer [11224,11237]
trailer [11269,11282]
===
match
---
operator: , [2520,2521]
operator: , [2565,2566]
===
match
---
name: _sync_parallelism [8870,8887]
name: _sync_parallelism [8915,8932]
===
match
---
name: task_publish_max_retries [10412,10436]
name: task_publish_max_retries [10457,10481]
===
match
---
atom_expr [12090,12112]
atom_expr [12135,12157]
===
match
---
name: log [2060,2063]
name: log [2105,2108]
===
match
---
trailer [7384,7386]
trailer [7429,7431]
===
match
---
operator: , [4541,4542]
operator: , [4586,4587]
===
match
---
operator: , [14976,14977]
operator: , [14646,14647]
===
match
---
trailer [23360,23371]
trailer [23030,23041]
===
match
---
import_name [6710,6739]
import_name [6755,6784]
===
match
---
trailer [9648,9669]
trailer [9693,9714]
===
match
---
simple_stmt [24590,24663]
simple_stmt [24260,24333]
===
match
---
name: state [16178,16183]
name: state [15848,15853]
===
match
---
name: get_hostname [4800,4812]
name: get_hostname [4845,4857]
===
match
---
name: AsyncResult [1455,1466]
name: AsyncResult [1500,1511]
===
match
---
trailer [3887,3891]
trailer [3932,3936]
===
match
---
name: OPERATION_TIMEOUT [2457,2474]
name: OPERATION_TIMEOUT [2502,2519]
===
match
---
operator: , [9383,9384]
operator: , [9428,9429]
===
match
---
name: celery_states [16715,16728]
name: celery_states [16385,16398]
===
match
---
name: key [10909,10912]
name: key [10954,10957]
===
match
---
name: task_results [23247,23259]
name: task_results [22917,22929]
===
match
---
name: airflow [1617,1624]
name: airflow [1662,1669]
===
match
---
dotted_name [1434,1447]
dotted_name [1479,1492]
===
match
---
atom_expr [25078,25158]
atom_expr [24765,24845]
===
match
---
name: self [22607,22611]
name: self [22277,22281]
===
match
---
arglist [3052,3102]
arglist [3097,3147]
===
match
---
name: states_by_celery_task_id [19739,19763]
name: states_by_celery_task_id [19409,19433]
===
match
---
name: task_tuple [9366,9376]
name: task_tuple [9411,9421]
===
match
---
expr_stmt [2801,2888]
expr_stmt [2846,2933]
===
match
---
fstring_expr [20249,20253]
fstring_expr [19919,19923]
===
match
---
expr_stmt [13865,13879]
expr_stmt [13535,13549]
===
match
---
suite [13977,14740]
suite [13647,14410]
===
match
---
expr_stmt [24697,24726]
expr_stmt [24367,24396]
===
match
---
operator: , [21660,21661]
operator: , [21330,21331]
===
match
---
except_clause [4605,4646]
except_clause [4650,4691]
===
match
---
trailer [8832,8889]
trailer [8877,8934]
===
match
---
trailer [15005,15037]
trailer [14675,14707]
===
match
---
simple_stmt [24345,24404]
simple_stmt [24015,24074]
===
match
---
simple_stmt [973,985]
simple_stmt [973,985]
===
match
---
except_clause [17155,17171]
except_clause [16825,16841]
===
match
---
operator: , [25523,25524]
operator: , [25216,25217]
===
match
---
operator: = [3603,3604]
operator: = [3648,3649]
===
match
---
name: shut_down_logging [3906,3923]
name: shut_down_logging [3951,3968]
===
match
---
operator: = [25199,25200]
operator: = [24886,24887]
===
match
---
trailer [23651,23664]
trailer [23321,23334]
===
match
---
comp_if [23308,23312]
comp_if [22978,22982]
===
match
---
suite [22585,22653]
suite [22255,22323]
===
match
---
trailer [15988,15994]
trailer [15658,15664]
===
match
---
operator: = [5804,5805]
operator: = [5849,5850]
===
match
---
name: math [25096,25100]
name: math [24783,24787]
===
match
---
trailer [15453,15458]
trailer [15123,15128]
===
match
---
name: processes [12938,12947]
name: max_workers [12627,12638]
===
match
---
simple_stmt [23207,23239]
simple_stmt [22877,22909]
===
match
---
name: timedout_keys [15076,15089]
name: timedout_keys [14746,14759]
===
match
---
tfpdef [16270,16290]
tfpdef [15940,15960]
===
match
---
name: List [17933,17937]
name: List [17603,17607]
===
match
---
name: Exception [5186,5195]
name: Exception [5231,5240]
===
match
---
operator: = [24948,24949]
operator: = [24618,24619]
===
match
---
suite [23070,23511]
suite [22740,23181]
===
match
---
name: ext [6591,6594]
name: ext [6636,6639]
===
match
---
name: open_slots [9246,9256]
name: open_slots [9291,9301]
===
match
---
atom_expr [8064,8081]
atom_expr [8109,8126]
===
match
---
atom_expr [20232,20272]
atom_expr [19902,19942]
===
match
---
import_name [6613,6625]
import_name [6658,6670]
===
match
---
name: queue [5735,5740]
name: queue [5780,5785]
===
match
---
name: async_results [22760,22773]
name: async_results [22430,22443]
===
match
---
parameters [15260,15266]
parameters [14930,14936]
===
match
---
atom_expr [20043,20057]
atom_expr [19713,19727]
===
match
---
simple_stmt [19624,19693]
simple_stmt [19294,19363]
===
match
---
name: celery_states [16738,16751]
name: celery_states [16408,16421]
===
match
---
fstring_string: airflow task supervisor:  [3956,3981]
fstring_string: airflow task supervisor:  [4001,4026]
===
match
---
trailer [23708,23710]
trailer [23378,23380]
===
match
---
name: client [6862,6868]
name: client [6907,6913]
===
match
---
suite [4365,4851]
suite [4410,4896]
===
match
---
name: Dict [1162,1166]
name: Dict [1207,1211]
===
match
---
atom_expr [25713,25741]
atom_expr [25406,25434]
===
match
---
comparison [11283,11301]
comparison [11328,11346]
===
match
---
operator: = [7917,7918]
operator: = [7962,7963]
===
match
---
trailer [13365,13367]
trailer [13035,13037]
===
match
---
trailer [4739,4749]
trailer [4784,4794]
===
match
---
suite [23603,24185]
suite [23273,23855]
===
match
---
operator: = [21347,21348]
operator: = [21017,21018]
===
match
---
trailer [9633,9648]
trailer [9678,9693]
===
match
---
trailer [2709,2744]
trailer [2754,2789]
===
match
---
string: "No Async execution for Celery executor." [17806,17847]
string: "No Async execution for Celery executor." [17476,17517]
===
match
---
suite [13407,13460]
suite [13077,13130]
===
match
---
name: key [10108,10111]
name: key [10153,10156]
===
match
---
name: Tuple [5599,5604]
name: Tuple [5644,5649]
===
match
---
atom_expr [15861,15871]
atom_expr [15531,15541]
===
match
---
name: os [3412,3414]
name: os [3457,3459]
===
match
---
name: task_publish_retries [10374,10394]
name: task_publish_retries [10419,10439]
===
match
---
name: _get_many_from_db_backend [22734,22759]
name: _get_many_from_db_backend [22404,22429]
===
match
---
atom_expr [25112,25130]
atom_expr [24799,24817]
===
match
---
trailer [19531,19583]
trailer [19201,19253]
===
match
---
comparison [10310,10342]
comparison [10355,10387]
===
match
---
funcdef [7351,8427]
funcdef [7396,8472]
===
match
---
for_stmt [15065,15241]
for_stmt [14735,14911]
===
match
---
name: state [19723,19728]
name: state [19393,19398]
===
match
---
number: 1 [3605,3606]
number: 1 [3650,3651]
===
match
---
name: get_many [15941,15949]
name: get_many [15611,15619]
===
match
---
name: traceback [11176,11185]
name: traceback [11221,11230]
===
match
---
expr_stmt [24345,24403]
expr_stmt [24015,24073]
===
match
---
operator: = [8309,8310]
operator: = [8354,8355]
===
match
---
atom_expr [19258,19294]
atom_expr [18928,18964]
===
match
---
atom_expr [11914,11926]
atom_expr [11959,11971]
===
match
---
name: logging [965,972]
name: logging [965,972]
===
match
---
trailer [7873,7897]
trailer [7918,7942]
===
match
---
param [8914,8919]
param [8959,8964]
===
match
---
if_stmt [9492,9584]
if_stmt [9537,9629]
===
match
---
atom [15132,15152]
atom [14802,14822]
===
match
---
trailer [23853,23860]
trailer [23523,23530]
===
match
---
name: ti [20156,20158]
name: ti [19826,19828]
===
match
---
simple_stmt [23908,23989]
simple_stmt [23578,23659]
===
match
---
name: tasks [13235,13240]
name: tasks [12905,12910]
===
match
---
atom_expr [19334,19360]
atom_expr [19004,19030]
===
match
---
name: Pool [12933,12937]
name: ProcessPoolExecutor [12607,12626]
===
match
---
return_stmt [25932,25965]
return_stmt [25625,25658]
===
match
---
name: async_result [21584,21596]
name: async_result [21254,21266]
===
match
---
name: ti [19138,19140]
name: ti [18808,18810]
===
match
---
funcdef [5529,6136]
funcdef [5574,6181]
===
match
---
atom_expr [15805,15873]
atom_expr [15475,15543]
===
match
---
atom_expr [20176,20219]
atom_expr [19846,19889]
===
match
---
trailer [10221,10289]
trailer [10266,10334]
===
match
---
name: error [25579,25584]
name: error [25272,25277]
===
match
---
simple_stmt [5267,5304]
simple_stmt [5312,5349]
===
match
---
simple_stmt [15284,15337]
simple_stmt [14954,15007]
===
match
---
name: get [10395,10398]
name: get [10440,10443]
===
match
---
operator: = [5754,5755]
operator: = [5799,5800]
===
match
---
suite [4189,4298]
suite [4234,4343]
===
match
---
operator: , [5195,5196]
operator: , [5240,5241]
===
match
---
name: key [16677,16680]
name: key [16347,16350]
===
match
---
name: args [4010,4014]
name: args [4055,4059]
===
match
---
trailer [15691,15693]
trailer [15361,15363]
===
match
---
import_as_names [1157,1226]
import_as_names [1202,1271]
===
match
---
trailer [16970,16974]
trailer [16640,16644]
===
match
---
name: command [9396,9403]
name: command [9441,9448]
===
match
---
simple_stmt [1011,1029]
simple_stmt [1011,1029]
===
match
---
suite [25549,25819]
suite [25242,25512]
===
match
---
operator: , [9403,9404]
operator: , [9448,9449]
===
match
---
name: info [25439,25443]
name: info [25132,25136]
===
match
---
name: logging_mixin [2064,2077]
name: logging_mixin [2109,2122]
===
match
---
atom_expr [20099,20117]
atom_expr [19769,19787]
===
match
---
simple_stmt [2264,2298]
simple_stmt [2309,2343]
===
match
---
trailer [10373,10394]
trailer [10418,10439]
===
match
---
parameters [24248,24297]
parameters [23918,23967]
===
match
---
tfpdef [2921,2949]
tfpdef [2966,2994]
===
match
---
simple_stmt [4010,4026]
simple_stmt [4055,4071]
===
match
---
import_from [1138,1226]
import_from [1183,1271]
===
match
---
trailer [23694,23708]
trailer [23364,23378]
===
match
---
decorated [2891,3259]
decorated [2936,3304]
===
match
---
import_from [1467,1533]
import_from [1512,1578]
===
match
---
name: args [4020,4024]
name: args [4065,4069]
===
match
---
operator: , [19720,19721]
operator: , [19390,19391]
===
match
---
name: python [6769,6775]
name: python [6814,6820]
===
match
---
name: task_result [24449,24460]
name: task_result [24119,24130]
===
match
---
trailer [16668,16676]
trailer [16338,16346]
===
match
---
name: CommandType [5493,5504]
name: CommandType [5538,5549]
===
match
---
arglist [11108,11185]
arglist [11153,11230]
===
match
---
name: output [4742,4748]
name: output [4787,4793]
===
match
---
import_from [1646,1719]
import_from [1691,1764]
===
match
---
arglist [22677,22705]
arglist [22347,22375]
===
match
---
suite [2750,2800]
suite [2795,2845]
===
match
---
name: self [9629,9633]
name: self [9674,9678]
===
match
---
trailer [24899,24926]
trailer [24569,24596]
===
match
---
trailer [15685,15691]
trailer [15355,15361]
===
match
---
operator: } [19094,19095]
operator: } [18764,18765]
===
match
---
atom_expr [4221,4239]
atom_expr [4266,4284]
===
match
---
name: math [980,984]
name: math [980,984]
===
match
---
trailer [17226,17230]
trailer [16896,16900]
===
match
---
simple_stmt [13157,13186]
simple_stmt [12827,12856]
===
match
---
name: repr [15463,15467]
name: repr [15133,15137]
===
match
---
param [16510,16521]
param [16180,16191]
===
match
---
number: 1 [7820,7821]
number: 1 [7865,7866]
===
match
---
name: _tasks_list_to_task_ids [23628,23651]
name: _tasks_list_to_task_ids [23298,23321]
===
match
---
tfpdef [17311,17328]
tfpdef [16981,16998]
===
match
---
arglist [10575,10767]
arglist [10620,10812]
===
match
---
name: task_to_run [5742,5753]
name: task_to_run [5787,5798]
===
match
---
name: key [10763,10766]
name: key [10808,10811]
===
match
---
name: format_exc [6024,6034]
name: format_exc [6069,6079]
===
match
---
trailer [4228,4237]
trailer [4273,4282]
===
match
---
operator: , [19728,19729]
operator: , [19398,19399]
===
match
---
name: Dict [8042,8046]
name: Dict [8087,8091]
===
match
---
name: getint [8370,8376]
name: getint [8415,8421]
===
match
---
operator: == [12082,12084]
operator: == [12127,12129]
===
match
---
name: chunksize [12399,12408]
name: chunksize [12444,12453]
===
match
---
suite [21142,21476]
suite [20812,21146]
===
match
---
simple_stmt [20099,20127]
simple_stmt [19769,19797]
===
match
---
name: get_hostname [2128,2140]
name: get_hostname [2173,2185]
===
match
---
param [16292,16303]
param [15962,15973]
===
match
---
name: task_id [24416,24423]
name: task_id [24086,24093]
===
match
---
name: append [14728,14734]
name: append [14398,14404]
===
match
---
operator: = [22808,22809]
operator: = [22478,22479]
===
match
---
operator: , [1896,1897]
operator: , [1941,1942]
===
match
---
name: len [22936,22939]
name: len [22606,22609]
===
match
---
name: pop [9347,9350]
name: pop [9392,9395]
===
match
---
simple_stmt [11036,11204]
simple_stmt [11081,11249]
===
match
---
trailer [19356,19360]
trailer [19026,19030]
===
match
---
operator: , [19791,19792]
operator: , [19461,19462]
===
match
---
funcdef [6201,6920]
funcdef [6246,6965]
===
match
---
trailer [3860,3871]
trailer [3905,3916]
===
match
---
name: List [12017,12021]
name: List [12062,12066]
===
match
---
if_stmt [13377,13460]
if_stmt [13047,13130]
===
match
---
simple_stmt [21633,21715]
simple_stmt [21303,21385]
===
match
---
name: update_task_state [20181,20198]
name: update_task_state [19851,19868]
===
match
---
name: key [15069,15072]
name: key [14739,14742]
===
match
---
atom_expr [8136,8246]
atom_expr [8181,8291]
===
match
---
name: __init__ [22191,22199]
name: __init__ [21861,21869]
===
match
---
name: info [20368,20372]
name: info [20038,20042]
===
match
---
simple_stmt [24101,24185]
simple_stmt [23771,23855]
===
match
---
simple_stmt [15882,15971]
simple_stmt [15552,15641]
===
match
---
operator: , [10682,10683]
operator: , [10727,10728]
===
match
---
name: state [24697,24702]
name: state [24367,24372]
===
match
---
trailer [25095,25157]
trailer [24782,24844]
===
match
---
name: cached_celery_backend [11336,11357]
name: cached_celery_backend [11381,11402]
===
match
---
string: """Called in response to SIGUSR2 by the scheduler""" [15284,15336]
string: """Called in response to SIGUSR2 by the scheduler""" [14954,15006]
===
match
---
name: x [15018,15019]
name: x [14688,14689]
===
match
---
name: _tasks_list_to_task_ids [22261,22284]
name: _tasks_list_to_task_ids [21931,21954]
===
match
---
name: TaskInstanceInCelery [12022,12042]
name: TaskInstanceInCelery [12067,12087]
===
match
---
operator: = [8363,8364]
operator: = [8408,8409]
===
match
---
atom_expr [13380,13406]
atom_expr [13050,13076]
===
match
---
suite [5223,5304]
suite [5268,5349]
===
match
---
fstring_end: " [3998,3999]
fstring_end: " [4043,4044]
===
match
---
name: order_queued_tasks_by_priority [9123,9153]
name: order_queued_tasks_by_priority [9168,9198]
===
match
---
name: info [25919,25923]
name: info [25612,25616]
===
match
---
if_stmt [10973,11959]
if_stmt [11018,12004]
===
match
---
name: self [20139,20143]
name: self [19809,19813]
===
match
---
atom_expr [23216,23238]
atom_expr [22886,22908]
===
match
---
name: self [23623,23627]
name: self [23293,23297]
===
match
---
name: Task [1255,1259]
name: Task [1300,1304]
===
match
---
for_stmt [19702,20273]
for_stmt [19372,19943]
===
match
---
atom_expr [22810,22861]
atom_expr [22480,22531]
===
match
---
simple_stmt [10866,10875]
simple_stmt [10911,10920]
===
match
---
atom_expr [9721,9747]
atom_expr [9766,9792]
===
match
---
fstring_start: f" [20247,20249]
fstring_start: f" [19917,19919]
===
match
---
suite [9757,11959]
suite [9802,12004]
===
match
---
argument [2853,2887]
argument [2898,2932]
===
match
---
operator: , [5724,5725]
operator: , [5769,5770]
===
match
---
name: info [21362,21366]
name: info [21032,21036]
===
match
---
name: task_adoption_timeout [8112,8133]
name: task_adoption_timeout [8157,8178]
===
match
---
trailer [15819,15873]
trailer [15489,15543]
===
match
---
parameters [22284,22303]
parameters [21954,21973]
===
match
---
expr_stmt [5427,5526]
expr_stmt [5472,5571]
===
match
---
name: STARTED [16839,16846]
name: STARTED [16509,16516]
===
match
---
atom_expr [25133,25155]
atom_expr [24820,24842]
===
match
---
name: state_or_exception [25713,25731]
name: state_or_exception [25406,25424]
===
match
---
name: AirflowException [1790,1806]
name: AirflowException [1835,1851]
===
match
---
name: msg [4758,4761]
name: msg [4803,4806]
===
match
---
name: states [1261,1267]
name: states [1306,1312]
===
match
---
simple_stmt [17883,17888]
simple_stmt [17553,17558]
===
match
---
string: "\n\t" [15637,15643]
string: "\n\t" [15307,15313]
===
match
---
atom_expr [15649,15694]
atom_expr [15319,15364]
===
match
---
parameters [2920,2950]
parameters [2965,2995]
===
match
---
atom_expr [8107,8133]
atom_expr [8152,8178]
===
match
---
trailer [15984,15988]
trailer [15654,15658]
===
match
---
term [25106,25155]
term [24793,24842]
===
match
---
name: airflow [2184,2191]
name: airflow [2229,2236]
===
match
---
trailer [5640,5677]
trailer [5685,5722]
===
match
---
atom_expr [19217,19254]
atom_expr [18887,18924]
===
match
---
operator: , [10255,10256]
operator: , [10300,10301]
===
match
---
simple_stmt [13016,13149]
simple_stmt [12680,12819]
===
match
---
dotted_name [1617,1633]
dotted_name [1662,1678]
===
match
---
argument [9784,9817]
argument [9829,9862]
===
match
---
arglist [21378,21398]
arglist [21048,21068]
===
match
---
simple_stmt [9929,9972]
simple_stmt [9974,10017]
===
match
---
operator: = [3329,3330]
operator: = [3374,3375]
===
match
---
name: adopted_task_timeouts [16418,16439]
name: adopted_task_timeouts [16088,16109]
===
match
---
suite [12045,13186]
suite [12090,12856]
===
match
---
operator: = [11754,11755]
operator: = [11799,11800]
===
match
---
name: executor_config [17665,17680]
name: executor_config [17335,17350]
===
match
---
simple_stmt [13420,13460]
simple_stmt [13090,13130]
===
match
---
simple_stmt [2009,2041]
simple_stmt [2054,2086]
===
match
---
string: "Adopted tasks were still pending after %s, assuming they never made it to celery and " [14811,14898]
string: "Adopted tasks were still pending after %s, assuming they never made it to celery and " [14481,14568]
===
match
---
name: self [16482,16486]
name: self [16152,16156]
===
match
---
trailer [21163,21190]
trailer [20833,20860]
===
match
---
name: event_buffer [11225,11237]
name: event_buffer [11270,11282]
===
match
---
operator: , [16227,16228]
operator: , [15897,15898]
===
match
---
operator: == [3446,3448]
operator: == [3491,3493]
===
match
---
arglist [19536,19581]
arglist [19206,19251]
===
match
---
name: state_and_info_by_celery_task_id [15882,15914]
name: state_and_info_by_celery_task_id [15552,15584]
===
match
---
if_stmt [13990,14163]
if_stmt [13660,13833]
===
match
---
trailer [16751,16759]
trailer [16421,16429]
===
match
---
string: 'Celery command failed on host: ' [4764,4797]
string: 'Celery command failed on host: ' [4809,4842]
===
match
---
name: result [11151,11157]
name: result [11196,11202]
===
match
---
except_clause [6887,6905]
except_clause [6932,6950]
===
match
---
trailer [12528,12546]
trailer [12573,12591]
===
match
---
name: running [20144,20151]
name: running [19814,19821]
===
match
---
name: MutableMapping [1183,1197]
name: MutableMapping [1228,1242]
===
match
---
atom [9215,9217]
atom [9260,9262]
===
match
---
name: task_result [24643,24654]
name: task_result [24313,24324]
===
match
---
atom_expr [13420,13459]
atom_expr [13090,13129]
===
match
---
name: datetime [949,957]
name: datetime [949,957]
===
match
---
simple_stmt [10810,10846]
simple_stmt [10855,10891]
===
match
---
sync_comp_for [23970,23987]
sync_comp_for [23640,23657]
===
match
---
name: self [15107,15111]
name: self [14777,14781]
===
match
---
name: TaskInstanceInCelery [5427,5447]
name: TaskInstanceInCelery [5472,5492]
===
match
---
trailer [19485,19504]
trailer [19155,19174]
===
match
---
string: "celery.task_timeout_error" [10487,10514]
string: "celery.task_timeout_error" [10532,10559]
===
match
---
trailer [23927,23935]
trailer [23597,23605]
===
match
---
atom_expr [20451,20463]
atom_expr [20121,20133]
===
match
---
name: task_tuples_to_send [9441,9460]
name: task_tuples_to_send [9486,9505]
===
match
---
name: ExceptionWithTraceback [25525,25547]
name: ExceptionWithTraceback [25218,25240]
===
match
---
suite [22174,22252]
suite [21844,21922]
===
match
---
trailer [5857,5869]
trailer [5902,5914]
===
match
---
trailer [5514,5519]
trailer [5559,5564]
===
match
---
arglist [15463,15487]
arglist [15133,15157]
===
match
---
number: 0 [7759,7760]
number: 0 [7804,7805]
===
match
---
trailer [19269,19294]
trailer [18939,18964]
===
match
---
trailer [22814,22846]
trailer [22484,22516]
===
match
---
atom_expr [17090,17146]
atom_expr [16760,16816]
===
match
---
name: default_celery [1676,1690]
name: default_celery [1721,1735]
===
match
---
simple_stmt [14714,14740]
simple_stmt [14384,14410]
===
match
---
operator: } [22363,22364]
operator: } [22033,22034]
===
match
---
simple_stmt [16944,16986]
simple_stmt [16614,16656]
===
match
---
name: tasks [16062,16067]
name: tasks [15732,15737]
===
match
---
name: _execute_in_fork [3225,3241]
name: _execute_in_fork [3270,3286]
===
match
---
trailer [10065,10069]
trailer [10110,10114]
===
match
---
name: Stats [10476,10481]
name: Stats [10521,10526]
===
match
---
dotted_name [1725,1746]
dotted_name [1770,1791]
===
match
---
trailer [4733,4739]
trailer [4778,4784]
===
match
---
atom_expr [23954,23968]
atom_expr [23624,23638]
===
match
---
name: key [11423,11426]
name: key [11468,11471]
===
match
---
name: _sync_parallelism [25138,25155]
name: _sync_parallelism [24825,24842]
===
match
---
trailer [10540,10544]
trailer [10585,10589]
===
match
---
atom_expr [13338,13367]
atom_expr [13008,13037]
===
match
---
atom_expr [19658,19679]
atom_expr [19328,19349]
===
match
---
simple_stmt [9549,9584]
simple_stmt [9594,9629]
===
match
---
operator: , [16736,16737]
operator: , [16406,16407]
===
match
---
name: str [5515,5518]
name: str [5560,5563]
===
match
---
expr_stmt [9366,9428]
expr_stmt [9411,9473]
===
match
---
operator: , [20212,20213]
operator: , [19882,19883]
===
match
---
fstring_start: f" [5988,5990]
fstring_start: f" [6033,6035]
===
match
---
string: 'task_adoption_timeout' [8198,8221]
string: 'task_adoption_timeout' [8243,8266]
===
match
---
name: self [17922,17926]
name: self [17592,17596]
===
match
---
trailer [13258,13262]
trailer [12928,12932]
===
match
---
name: _sync_parallelism [24979,24996]
name: _sync_parallelism [24649,24666]
===
match
---
trailer [11237,11242]
trailer [11282,11287]
===
match
---
operator: = [2805,2806]
operator: = [2850,2851]
===
match
---
number: 3 [8424,8425]
number: 3 [8469,8470]
===
match
---
subscriptlist [20595,20639]
subscriptlist [20265,20309]
===
match
---
fstring_end: " [20270,20271]
fstring_end: " [19940,19941]
===
match
---
operator: = [20041,20042]
operator: = [19711,19712]
===
match
---
name: info [3047,3051]
name: info [3092,3096]
===
match
---
while_stmt [17383,17502]
while_stmt [17053,17172]
===
match
---
trailer [16140,16162]
trailer [15810,15832]
===
match
---
name: queue [9314,9319]
name: queue [9359,9364]
===
match
---
dictorsetmaker [24024,24091]
dictorsetmaker [23694,23761]
===
match
---
trailer [3120,3157]
trailer [3165,3202]
===
match
---
name: len [12057,12060]
name: len [12102,12105]
===
match
---
simple_stmt [20176,20220]
simple_stmt [19846,19890]
===
match
---
trailer [10398,10403]
trailer [10443,10448]
===
match
---
operator: @ [2891,2892]
operator: @ [2936,2937]
===
match
---
simple_stmt [11886,11959]
simple_stmt [11931,12004]
===
match
---
name: DatabaseBackend [22690,22705]
name: DatabaseBackend [22360,22375]
===
match
---
funcdef [11964,13186]
funcdef [12009,12856]
===
match
---
name: self [15469,15473]
name: self [15139,15143]
===
match
---
atom_expr [15209,15240]
atom_expr [14879,14910]
===
match
---
if_stmt [9593,9670]
if_stmt [9638,9715]
===
match
---
trailer [15183,15188]
trailer [14853,14858]
===
match
---
name: debug [10070,10075]
name: debug [10115,10120]
===
match
---
name: app [23263,23266]
name: app [22933,22936]
===
match
---
name: trigger_tasks [8900,8913]
name: trigger_tasks [8945,8958]
===
match
---
name: state [16090,16095]
name: state [15760,15765]
===
match
---
dotted_name [1924,1951]
dotted_name [1969,1996]
===
match
---
name: airflow [3629,3636]
name: airflow [3674,3681]
===
match
---
operator: , [11994,11995]
operator: , [12039,12040]
===
match
---
name: celery_tasks [19377,19389]
name: celery_tasks [19047,19059]
===
match
---
number: 4 [9786,9787]
number: 4 [9831,9832]
===
match
---
operator: } [24091,24092]
operator: } [23761,23762]
===
match
---
fstring_string: \n [6011,6013]
fstring_string: \n [6056,6058]
===
match
---
simple_stmt [1343,1429]
simple_stmt [1388,1474]
===
match
---
trailer [15921,15940]
trailer [15591,15610]
===
match
---
name: stalled_after [13925,13938]
name: stalled_after [13595,13608]
===
match
---
operator: = [6054,6055]
operator: = [6099,6100]
===
match
---
atom [23262,23313]
atom [22932,22983]
===
match
---
name: timeout [5789,5796]
name: timeout [5834,5841]
===
match
---
suite [15275,15707]
suite [14945,15377]
===
match
---
name: getLogger [2278,2287]
name: getLogger [2323,2332]
===
match
---
name: tasks [16384,16389]
name: tasks [16054,16059]
===
match
---
operator: , [17138,17139]
operator: , [16808,16809]
===
match
---
name: args [3847,3851]
name: args [3892,3896]
===
match
---
simple_stmt [1058,1094]
simple_stmt [1058,1094]
===
match
---
name: State [15133,15138]
name: State [14803,14808]
===
match
---
name: adopted_task_timeouts [15214,15235]
name: adopted_task_timeouts [14884,14905]
===
match
---
name: result [5837,5843]
name: result [5882,5888]
===
match
---
trailer [2822,2851]
trailer [2867,2896]
===
match
---
trailer [10549,10789]
trailer [10594,10834]
===
match
---
param [8920,8935]
param [8965,8980]
===
match
---
simple_stmt [20139,20164]
simple_stmt [19809,19834]
===
match
---
if_stmt [7730,7823]
if_stmt [7775,7868]
===
match
---
tfpdef [11996,12043]
tfpdef [12041,12088]
===
match
---
decorated [6170,6920]
decorated [6215,6965]
===
match
---
name: self [11412,11416]
name: self [11457,11461]
===
match
---
operator: , [11912,11913]
operator: , [11957,11958]
===
match
---
name: PENDING [24719,24726]
name: PENDING [24389,24396]
===
match
---
name: TaskInstanceKey [16275,16290]
name: TaskInstanceKey [15945,15960]
===
match
---
name: queue [5886,5891]
name: queue [5931,5936]
===
match
---
atom_expr [23035,23069]
atom_expr [22705,22739]
===
match
---
operator: , [1259,1260]
operator: , [1304,1305]
===
match
---
trailer [9350,9353]
trailer [9395,9398]
===
match
---
name: async_tasks [22352,22363]
name: async_tasks [22022,22033]
===
match
---
operator: , [24903,24904]
operator: , [24573,24574]
===
match
---
name: typing [1143,1149]
name: typing [1188,1194]
===
match
---
atom [7919,7921]
atom [7964,7966]
===
match
---
name: ret [3406,3409]
name: ret [3451,3454]
===
match
---
simple_stmt [20232,20273]
simple_stmt [19902,19943]
===
match
---
name: isinstance [10211,10221]
name: isinstance [10256,10266]
===
match
---
name: end [17301,17304]
name: end [16971,16974]
===
match
---
trailer [3871,3892]
trailer [3916,3937]
===
match
---
trailer [15438,15444]
trailer [15108,15114]
===
match
---
arglist [15820,15872]
arglist [15490,15542]
===
match
---
trailer [17025,17033]
trailer [16695,16703]
===
match
---
operator: = [4038,4039]
operator: = [4083,4084]
===
match
---
atom_expr [8282,8308]
atom_expr [8327,8353]
===
match
---
name: subdag [6805,6811]
name: subdag [6850,6856]
===
match
---
name: models [1932,1938]
name: models [1977,1983]
===
match
---
trailer [4378,4386]
trailer [4423,4431]
===
match
---
string: """         See if any of the tasks we adopted from another Executor run have not         progressed after the configured timeout.          If they haven't, they likely never made it to Celery, and we should         just resend them. We do that by clearing the state and letting the         normal scheduler loop deal with that         """ [13517,13856]
string: """         See if any of the tasks we adopted from another Executor run have not         progressed after the configured timeout.          If they haven't, they likely never made it to Celery, and we should         just resend them. We do that by clearing the state and letting the         normal scheduler loop deal with that         """ [13187,13526]
===
match
---
name: _get_many_using_multiprocessing [22815,22846]
name: _get_many_using_multiprocessing [22485,22516]
===
match
---
operator: , [8827,8828]
operator: , [8872,8873]
===
match
---
expr_stmt [24590,24662]
expr_stmt [24260,24332]
===
match
---
name: len [25112,25115]
name: len [24799,24802]
===
match
---
name: exception [5175,5184]
name: exception [5220,5229]
===
match
---
name: values [23301,23307]
name: values [22971,22977]
===
match
---
name: traceback [6014,6023]
name: traceback [6059,6068]
===
match
---
expr_stmt [11731,11786]
expr_stmt [11776,11831]
===
match
---
name: self [8014,8018]
name: self [8059,8063]
===
match
---
name: key [9380,9383]
name: key [9425,9428]
===
match
---
name: self [7831,7835]
name: self [7876,7880]
===
match
---
arglist [16394,16403]
arglist [16064,16073]
===
match
---
name: task_result [24552,24563]
name: task_result [24222,24233]
===
match
---
simple_stmt [3464,3471]
simple_stmt [3509,3516]
===
match
---
name: task_publish_retries [9554,9574]
name: task_publish_retries [9599,9619]
===
match
---
name: Mapping [23568,23575]
name: Mapping [23238,23245]
===
match
---
name: __init__ [5160,5168]
name: __init__ [5205,5213]
===
match
---
expr_stmt [23997,24092]
expr_stmt [23667,23762]
===
match
---
name: self [16944,16948]
name: self [16614,16618]
===
match
---
simple_stmt [21759,22127]
simple_stmt [21429,21797]
===
match
---
number: 0 [3428,3429]
number: 0 [3473,3474]
===
match
---
fstring_start: f" [3954,3956]
fstring_start: f" [3999,4001]
===
match
---
name: command_to_exec [3087,3102]
name: command_to_exec [3132,3147]
===
match
---
string: 'info' [11944,11950]
string: 'info' [11989,11995]
===
match
---
name: self [16778,16782]
name: self [16448,16452]
===
match
---
simple_stmt [7906,7922]
simple_stmt [7951,7967]
===
match
---
simple_stmt [3718,3744]
simple_stmt [3763,3789]
===
match
---
trailer [15433,15445]
trailer [15103,15115]
===
match
---
name: self [17090,17094]
name: self [16760,16764]
===
match
---
name: self [16413,16417]
name: self [16083,16087]
===
match
---
simple_stmt [21422,21476]
simple_stmt [21092,21146]
===
match
---
name: _prepare_state_and_info_by_task_dict [24113,24149]
name: _prepare_state_and_info_by_task_dict [23783,23819]
===
match
---
name: self [5232,5236]
name: self [5277,5281]
===
match
---
funcdef [8896,9670]
funcdef [8941,9715]
===
match
---
trailer [2813,2888]
trailer [2858,2933]
===
match
---
name: Union [1221,1226]
name: Union [1266,1271]
===
match
---
name: async_result [16141,16153]
name: async_result [15811,15823]
===
match
---
simple_stmt [1759,1827]
simple_stmt [1804,1872]
===
match
---
expr_stmt [20306,20346]
expr_stmt [19976,20016]
===
match
---
name: Sentry [4198,4204]
name: Sentry [4243,4249]
===
match
---
comparison [16616,16646]
comparison [16286,16316]
===
match
---
operator: -> [17953,17955]
operator: -> [17623,17625]
===
match
---
name: tis [17928,17931]
name: tis [17598,17601]
===
match
---
trailer [8072,8081]
trailer [8117,8126]
===
match
---
suite [3158,3207]
suite [3203,3252]
===
match
---
operator: , [16234,16235]
operator: , [15904,15905]
===
match
---
operator: , [5733,5734]
operator: , [5778,5779]
===
match
---
name: sync [17515,17519]
name: sync [17185,17189]
===
match
---
dotted_name [2226,2248]
dotted_name [2271,2293]
===
match
---
atom_expr [11928,11957]
atom_expr [11973,12002]
===
match
---
name: _get_many_from_kv_backend [22612,22637]
name: _get_many_from_kv_backend [22282,22307]
===
match
---
operator: , [11950,11951]
operator: , [11995,11996]
===
match
---
atom_expr [17012,17033]
atom_expr [16682,16703]
===
match
---
atom_expr [4376,4393]
atom_expr [4421,4438]
===
match
---
operator: = [24021,24022]
operator: = [23691,23692]
===
match
---
name: self [11036,11040]
name: self [11081,11085]
===
match
---
name: str [23576,23579]
name: str [23246,23249]
===
match
---
atom_expr [23730,23770]
atom_expr [23400,23440]
===
match
---
if_stmt [12054,12267]
if_stmt [12099,12312]
===
match
---
trailer [7778,7796]
trailer [7823,7841]
===
match
---
operator: = [4507,4508]
operator: = [4552,4553]
===
match
---
atom_expr [21662,21708]
atom_expr [21332,21378]
===
match
---
with_stmt [12928,13149]
with_stmt [12602,12819]
===
match
---
name: update_task_state [16206,16223]
name: update_task_state [15876,15893]
===
match
---
simple_stmt [9296,9354]
simple_stmt [9341,9399]
===
match
---
name: state_or_exception [25419,25437]
name: state_or_exception [25112,25130]
===
match
---
trailer [16061,16067]
trailer [15731,15737]
===
match
---
atom_expr [5789,5823]
atom_expr [5834,5868]
===
match
---
atom_expr [20600,20634]
atom_expr [20270,20304]
===
match
---
suite [17471,17502]
suite [17141,17172]
===
match
---
string: "Executing command in Celery: %s" [3052,3085]
string: "Executing command in Celery: %s" [3097,3130]
===
match
---
import_name [985,1000]
import_name [985,1000]
===
match
---
trailer [11044,11050]
trailer [11089,11095]
===
match
---
name: state [20207,20212]
name: state [19877,19882]
===
match
---
operator: , [13092,13093]
operator: , [12761,12762]
===
match
---
name: Optional [5506,5514]
name: Optional [5551,5559]
===
match
---
name: state [16358,16363]
name: state [16028,16033]
===
match
---
trailer [4122,4160]
trailer [4167,4205]
===
match
---
name: self [15173,15177]
name: self [14843,14847]
===
match
---
atom_expr [19270,19293]
atom_expr [18940,18963]
===
match
---
name: ti [19296,19298]
name: ti [18966,18968]
===
match
---
string: 'celery' [2823,2831]
string: 'celery' [2868,2876]
===
match
---
trailer [13384,13406]
trailer [13054,13076]
===
match
---
operator: = [24787,24788]
operator: = [24457,24458]
===
match
---
trailer [16782,16787]
trailer [16452,16457]
===
match
---
string: 'Starting Celery Executor using %s processes for syncing' [8480,8537]
string: 'Starting Celery Executor using %s processes for syncing' [8525,8582]
===
match
---
name: info [21342,21346]
name: info [21012,21016]
===
match
---
name: command_to_exec [4327,4342]
name: command_to_exec [4372,4387]
===
match
---
simple_stmt [2179,2221]
simple_stmt [2224,2266]
===
match
---
trailer [11748,11753]
trailer [11793,11798]
===
match
---
operator: = [24461,24462]
operator: = [24131,24132]
===
match
---
import_from [1919,2008]
import_from [1964,2053]
===
match
---
atom_expr [11757,11769]
atom_expr [11802,11814]
===
match
---
trailer [19810,19826]
trailer [19480,19496]
===
match
---
name: Mapping [23035,23042]
name: Mapping [22705,22712]
===
match
---
name: celery_states [24705,24718]
name: celery_states [24375,24388]
===
match
---
atom_expr [3486,3554]
atom_expr [3531,3599]
===
match
---
suite [22707,22775]
suite [22377,22445]
===
match
---
name: self [10652,10656]
name: self [10697,10701]
===
match
---
simple_stmt [24767,24801]
simple_stmt [24437,24471]
===
match
---
name: backend [23220,23227]
name: backend [22890,22897]
===
match
---
name: async_result [21429,21441]
name: async_result [21099,21111]
===
match
---
name: self [10061,10065]
name: self [10106,10110]
===
match
---
atom_expr [13040,13148]
atom_expr [12726,12804]
===
match
---
simple_stmt [3753,3775]
simple_stmt [3798,3820]
===
match
---
arglist [15535,15696]
arglist [15205,15366]
===
match
---
name: to_dict [23959,23966]
name: to_dict [23629,23636]
===
match
---
name: waitpid [3415,3422]
name: waitpid [3460,3467]
===
match
---
name: OPERATION_TIMEOUT [21172,21189]
name: OPERATION_TIMEOUT [20842,20859]
===
match
---
simple_stmt [16201,16242]
simple_stmt [15871,15912]
===
match
---
trailer [5236,5246]
trailer [5281,5291]
===
match
---
simple_stmt [15508,15707]
simple_stmt [15178,15377]
===
match
---
operator: , [15855,15856]
operator: , [15525,15526]
===
match
---
import_from [1534,1571]
import_from [1579,1616]
===
match
---
suite [15753,16242]
suite [15423,15912]
===
match
---
name: state [17140,17145]
name: state [16810,16815]
===
match
---
operator: , [22289,22290]
operator: , [21959,21960]
===
match
---
simple_stmt [22451,22524]
simple_stmt [22121,22194]
===
match
---
string: 'celery' [2491,2499]
string: 'celery' [2536,2544]
===
match
---
expr_stmt [9165,9217]
expr_stmt [9210,9262]
===
match
---
param [22389,22402]
param [22059,22072]
===
match
---
name: async_tasks [23119,23130]
name: async_tasks [22789,22800]
===
match
---
trailer [8473,8479]
trailer [8518,8524]
===
match
---
atom_expr [23349,23371]
atom_expr [23019,23041]
===
match
---
param [22151,22172]
param [21821,21842]
===
match
---
arith_expr [3503,3553]
arith_expr [3548,3598]
===
match
---
name: math [8833,8837]
name: math [8878,8882]
===
match
---
operator: , [9698,9699]
operator: , [9743,9744]
===
match
---
operator: = [15130,15131]
operator: = [14800,14801]
===
match
---
name: command_to_exec [4484,4499]
name: command_to_exec [4529,4544]
===
match
---
comparison [9495,9531]
comparison [9540,9576]
===
match
---
tfpdef [5197,5221]
tfpdef [5242,5266]
===
match
---
trailer [23799,23808]
trailer [23469,23478]
===
match
---
simple_stmt [2801,2889]
simple_stmt [2846,2934]
===
match
---
name: key [15236,15239]
name: key [14906,14909]
===
match
---
atom_expr [11246,11258]
atom_expr [11291,11303]
===
match
---
expr_stmt [2333,2397]
expr_stmt [2378,2442]
===
match
---
operator: , [5592,5593]
operator: , [5637,5638]
===
match
---
name: append [20240,20246]
name: append [19910,19916]
===
match
---
string: "info" [24630,24636]
string: "info" [24300,24306]
===
match
---
dotted_name [3565,3579]
dotted_name [3610,3624]
===
match
---
operator: == [12113,12115]
operator: == [12158,12160]
===
match
---
operator: { [3981,3982]
operator: { [4026,4027]
===
match
---
simple_stmt [3901,3932]
simple_stmt [3946,3977]
===
match
---
simple_stmt [15107,15153]
simple_stmt [14777,14823]
===
match
---
name: subprocess [4612,4622]
name: subprocess [4657,4667]
===
match
---
name: celery_tasks [19078,19090]
name: celery_tasks [18748,18760]
===
match
---
trailer [17397,17403]
trailer [17067,17073]
===
match
---
name: AsyncResult [5641,5652]
name: AsyncResult [5686,5697]
===
match
---
suite [16323,16455]
suite [15993,16125]
===
match
---
atom_expr [21156,21190]
atom_expr [20826,20860]
===
match
---
name: tis [19441,19444]
name: tis [19111,19114]
===
match
---
name: info [24743,24747]
name: info [24413,24417]
===
match
---
name: Set [1209,1212]
name: Set [1254,1257]
===
match
---
name: self [12411,12415]
name: self [12456,12460]
===
match
---
trailer [16389,16393]
trailer [16059,16063]
===
match
---
simple_stmt [4109,4161]
simple_stmt [4154,4206]
===
match
---
atom_expr [19481,19593]
atom_expr [19151,19263]
===
match
---
name: celery_states [16625,16638]
name: celery_states [16295,16308]
===
match
---
trailer [8837,8842]
trailer [8882,8887]
===
match
---
name: app [23683,23686]
name: app [23353,23356]
===
match
---
trailer [11935,11957]
trailer [11980,12002]
===
match
---
operator: , [6235,6236]
operator: , [6280,6281]
===
match
---
name: synchronous [17358,17369]
name: synchronous [17028,17039]
===
match
---
trailer [20239,20246]
trailer [19909,19916]
===
match
---
name: min [9242,9245]
name: min [9287,9290]
===
match
---
name: debug_dump [15353,15363]
name: debug_dump [15023,15033]
===
match
---
atom_expr [24974,24996]
atom_expr [24644,24666]
===
match
---
trailer [5455,5526]
trailer [5500,5571]
===
match
---
name: async_results [22940,22953]
name: async_results [22610,22623]
===
match
---
simple_stmt [10536,10790]
simple_stmt [10581,10835]
===
match
---
name: result [22801,22807]
name: result [22471,22477]
===
match
---
trailer [17937,17951]
trailer [17607,17621]
===
match
---
atom_expr [16625,16646]
atom_expr [16295,16316]
===
match
---
operator: = [24703,24704]
operator: = [24373,24374]
===
match
---
trailer [10394,10398]
trailer [10439,10443]
===
match
---
suite [17710,17849]
suite [17380,17519]
===
match
---
name: _ [9231,9232]
name: _ [9276,9277]
===
match
---
name: task [2896,2900]
name: task [2941,2945]
===
match
---
name: _send_tasks_to_celery [10010,10031]
name: _send_tasks_to_celery [10055,10076]
===
match
---
name: ret [3599,3602]
name: ret [3644,3647]
===
match
---
atom_expr [5267,5281]
atom_expr [5312,5326]
===
match
---
trailer [24371,24398]
trailer [24041,24068]
===
match
---
name: OrderedDict [8311,8322]
name: OrderedDict [8356,8367]
===
match
---
name: session [23673,23680]
name: session [23343,23350]
===
match
---
suite [14766,15241]
suite [14436,14911]
===
match
---
name: queued_dttm [20046,20057]
name: queued_dttm [19716,19727]
===
match
---
simple_stmt [24936,24998]
simple_stmt [24606,24668]
===
match
---
simple_stmt [8465,8563]
simple_stmt [8510,8608]
===
match
---
expr_stmt [5267,5303]
expr_stmt [5312,5348]
===
match
---
operator: , [1806,1807]
operator: , [1851,1852]
===
match
---
name: has_option [2621,2631]
name: has_option [2666,2676]
===
match
---
atom_expr [25570,25818]
atom_expr [25263,25511]
===
match
---
name: traceback [21600,21609]
name: traceback [21270,21279]
===
match
---
atom_expr [20359,20496]
atom_expr [20029,20166]
===
match
---
operator: , [1181,1182]
operator: , [1226,1227]
===
match
---
operator: = [7678,7679]
operator: = [7723,7724]
===
match
---
atom [19122,19124]
atom [18792,18794]
===
match
---
trailer [8154,8246]
trailer [8199,8291]
===
match
---
trailer [23274,23288]
trailer [22944,22958]
===
match
---
return_stmt [13157,13185]
return_stmt [12827,12855]
===
match
---
atom_expr [17789,17848]
atom_expr [17459,17518]
===
match
---
string: "info" [24655,24661]
string: "info" [24325,24331]
===
match
---
simple_stmt [8815,8891]
simple_stmt [8860,8936]
===
match
---
name: async_results [22389,22402]
name: async_results [22059,22072]
===
match
---
name: states_and_info_by_task_id [25939,25965]
name: states_and_info_by_task_id [25632,25658]
===
match
---
trailer [17392,17470]
trailer [17062,17140]
===
match
---
name: state [16292,16297]
name: state [15962,15967]
===
match
---
name: hasattr [24609,24616]
name: hasattr [24279,24286]
===
match
---
atom_expr [16379,16404]
atom_expr [16049,16074]
===
match
---
atom_expr [6014,6036]
atom_expr [6059,6081]
===
match
---
operator: } [20269,20270]
operator: } [19939,19940]
===
match
---
name: task_id [25888,25895]
name: task_id [25581,25588]
===
match
---
name: EventBufferValueType [24905,24925]
name: EventBufferValueType [24575,24595]
===
match
---
name: backend [23687,23694]
name: backend [23357,23364]
===
match
---
atom_expr [7680,7721]
atom_expr [7725,7766]
===
match
---
atom_expr [2807,2888]
atom_expr [2852,2933]
===
match
---
name: celery_states [17012,17025]
name: celery_states [16682,16695]
===
match
---
trailer [16393,16404]
trailer [16063,16074]
===
match
---
trailer [8825,8890]
trailer [8870,8935]
===
match
---
atom_expr [25201,25305]
atom_expr [24910,24984]
===
match
---
operator: , [9299,9300]
operator: , [9344,9345]
===
match
---
trailer [19272,19293]
trailer [18942,18963]
===
match
---
name: int [8932,8935]
name: int [8977,8980]
===
match
---
tfpdef [3282,3310]
tfpdef [3327,3355]
===
match
---
atom_expr [4829,4850]
atom_expr [4874,4895]
===
match
---
atom_expr [23830,23898]
atom_expr [23500,23568]
===
match
---
name: str [23043,23046]
name: str [22713,22716]
===
match
---
name: queued_tasks [10892,10904]
name: queued_tasks [10937,10949]
===
match
---
atom_expr [15980,16018]
atom_expr [15650,15688]
===
match
---
name: exception [25732,25741]
name: exception [25425,25434]
===
match
---
testlist_comp [9380,9427]
testlist_comp [9425,9472]
===
match
---
name: filter [23854,23860]
name: filter [23524,23530]
===
match
---
name: task_id [24778,24785]
name: task_id [24448,24455]
===
match
---
name: self [10407,10411]
name: self [10452,10456]
===
match
---
param [17554,17559]
param [17224,17229]
===
match
---
trailer [15458,15489]
trailer [15128,15159]
===
match
---
if_stmt [17355,17502]
if_stmt [17025,17172]
===
match
---
atom_expr [8539,8561]
atom_expr [8584,8606]
===
match
---
trailer [9553,9574]
trailer [9598,9619]
===
match
---
trailer [15352,15363]
trailer [15022,15033]
===
match
---
atom_expr [22870,22955]
atom_expr [22540,22625]
===
match
---
suite [17034,17056]
suite [16704,16726]
===
match
---
simple_stmt [3560,3594]
simple_stmt [3605,3639]
===
match
---
simple_stmt [6108,6136]
simple_stmt [6153,6181]
===
match
---
atom_expr [14994,15037]
atom_expr [14664,14707]
===
match
---
dotted_name [6717,6739]
dotted_name [6762,6784]
===
match
---
dotted_name [3629,3651]
dotted_name [3674,3696]
===
match
---
operator: = [4173,4174]
operator: = [4218,4219]
===
match
---
simple_stmt [3401,3431]
simple_stmt [3446,3476]
===
match
---
name: self [15805,15809]
name: self [15475,15479]
===
match
---
atom_expr [17933,17951]
atom_expr [17603,17621]
===
match
---
trailer [15521,15706]
trailer [15191,15376]
===
match
---
simple_stmt [2457,2536]
simple_stmt [2502,2581]
===
match
---
name: ti [20033,20035]
name: ti [19703,19705]
===
match
---
name: self [13338,13342]
name: self [13008,13012]
===
match
---
operator: -> [20586,20588]
operator: -> [20256,20258]
===
match
---
name: self [16057,16061]
name: self [15727,15731]
===
match
---
simple_stmt [9766,9819]
simple_stmt [9811,9864]
===
match
---
simple_stmt [4460,4552]
simple_stmt [4505,4597]
===
match
---
string: """     Gets status for many Celery tasks using the best method available      If BaseKeyValueStoreBackend is used as result backend, the mget method is used.     If DatabaseBackend is used as result backend, the SELECT ...WHERE task_id IN (...) query is used     Otherwise, multiprocessing.Pool will be used. Each task status will be downloaded individually.     """ [21759,22126]
string: """     Gets status for many Celery tasks using the best method available      If BaseKeyValueStoreBackend is used as result backend, the mget method is used.     If DatabaseBackend is used as result backend, the SELECT ...WHERE task_id IN (...) query is used     Otherwise, multiprocessing.Pool will be used. Each task status will be downloaded individually.     """ [21429,21796]
===
match
---
name: tasks [15178,15183]
name: tasks [14848,14853]
===
match
---
dotted_name [2046,2077]
dotted_name [2091,2122]
===
match
---
for_stmt [24412,24801]
for_stmt [24082,24471]
===
match
---
atom [19257,19299]
atom [18927,18969]
===
match
---
operator: , [25917,25918]
operator: , [25610,25611]
===
match
---
atom_expr [10926,10960]
atom_expr [10971,11005]
===
match
---
name: log [17095,17098]
name: log [16765,16768]
===
match
---
for_stmt [25406,25924]
for_stmt [25099,25617]
===
match
---
operator: , [5519,5520]
operator: , [5564,5565]
===
match
---
name: __init__ [22136,22144]
name: __init__ [21806,21814]
===
match
---
atom_expr [4248,4261]
atom_expr [4293,4306]
===
match
---
arglist [20390,20482]
arglist [20060,20152]
===
match
---
arglist [8188,8235]
arglist [8233,8280]
===
match
---
name: self [20006,20010]
name: self [19676,19680]
===
match
---
name: AirflowTaskTimeout [1808,1826]
name: AirflowTaskTimeout [1853,1871]
===
match
---
name: conf [2814,2818]
name: conf [2859,2863]
===
match
---
trailer [11777,11785]
trailer [11822,11830]
===
match
---
name: self [12090,12094]
name: self [12135,12139]
===
match
---
dotted_name [6584,6594]
dotted_name [6629,6639]
===
match
---
name: ExceptionWithTraceback [4859,4881]
name: ExceptionWithTraceback [4904,4926]
===
match
---
operator: } [21622,21623]
operator: } [21292,21293]
===
match
---
trailer [8543,8561]
trailer [8588,8606]
===
match
---
operator: = [12492,12493]
operator: = [12537,12538]
===
match
---
name: e [4157,4158]
name: e [4202,4203]
===
match
---
name: celery [1472,1478]
name: celery [1517,1523]
===
match
---
name: ti [19230,19232]
name: ti [18900,18902]
===
match
---
name: self [11220,11224]
name: self [11265,11269]
===
match
---
name: str [5218,5221]
name: str [5263,5266]
===
match
---
trailer [14954,14976]
trailer [14624,14646]
===
match
---
name: task_publish_max_retries [10713,10737]
name: task_publish_max_retries [10758,10782]
===
match
---
parameters [13199,13205]
parameters [12869,12875]
===
match
---
operator: = [23681,23682]
operator: = [23351,23352]
===
match
---
expr_stmt [23822,23898]
expr_stmt [23492,23568]
===
match
---
name: _sync_parallelism [12095,12112]
name: _sync_parallelism [12140,12157]
===
match
---
name: env [4547,4550]
name: env [4592,4595]
===
match
---
parameters [23545,23564]
parameters [23215,23234]
===
match
---
atom_expr [24892,24926]
atom_expr [24562,24596]
===
match
---
name: math [25085,25089]
name: math [24772,24776]
===
match
---
name: execute_command [2905,2920]
name: execute_command [2950,2965]
===
match
---
name: timedout_keys [13889,13902]
name: timedout_keys [13559,13572]
===
match
---
name: STDOUT [4519,4525]
name: STDOUT [4564,4570]
===
match
---
name: cli [3637,3640]
name: cli [3682,3685]
===
match
---
name: queued_tasks [9267,9279]
name: queued_tasks [9312,9324]
===
match
---
atom_expr [12218,12265]
atom_expr [12263,12310]
===
match
---
name: getattr [23730,23737]
name: getattr [23400,23407]
===
match
---
expr_stmt [11220,11265]
expr_stmt [11265,11310]
===
match
---
suite [13508,15241]
suite [13178,14911]
===
match
---
tfpdef [17628,17648]
tfpdef [17298,17318]
===
match
---
operator: + [11135,11136]
operator: + [11180,11181]
===
match
---
name: timezone [2240,2248]
name: timezone [2285,2293]
===
match
---
operator: { [24023,24024]
operator: { [23693,23694]
===
match
---
operator: , [10766,10767]
operator: , [10811,10812]
===
match
---
trailer [4210,4212]
trailer [4255,4257]
===
match
---
operator: , [1991,1992]
operator: , [2036,2037]
===
match
---
atom_expr [11374,11395]
atom_expr [11419,11440]
===
match
---
name: numpy [6620,6625]
name: numpy [6665,6670]
===
match
---
operator: = [24595,24596]
operator: = [24265,24266]
===
match
---
name: task [17393,17397]
name: task [17063,17067]
===
match
---
param [11996,12043]
param [12041,12088]
===
match
---
name: task_result [24617,24628]
name: task_result [24287,24298]
===
match
---
operator: , [15445,15446]
operator: , [15115,15116]
===
match
---
string: "Inquiring about %s celery task(s)" [15820,15855]
string: "Inquiring about %s celery task(s)" [15490,15525]
===
match
---
operator: } [7920,7921]
operator: } [7965,7966]
===
match
---
trailer [22611,22637]
trailer [22281,22307]
===
match
---
if_stmt [10161,10875]
if_stmt [10206,10920]
===
match
---
operator: - [7818,7819]
operator: - [7863,7864]
===
match
---
trailer [23219,23227]
trailer [22889,22897]
===
match
---
trailer [17098,17103]
trailer [16768,16773]
===
match
---
atom [23348,23417]
atom [23018,23087]
===
match
---
atom_expr [22333,22342]
atom_expr [22003,22012]
===
match
---
trailer [9122,9153]
trailer [9167,9198]
===
match
---
trailer [19572,19579]
trailer [19242,19249]
===
match
---
string: """Executes command.""" [2964,2987]
string: """Executes command.""" [3009,3032]
===
match
---
expr_stmt [25861,25923]
expr_stmt [25554,25616]
===
match
---
operator: = [4546,4547]
operator: = [4591,4592]
===
match
---
simple_stmt [16413,16455]
simple_stmt [16083,16125]
===
match
---
name: adopted [20285,20292]
name: adopted [19955,19962]
===
match
---
name: CommandType [17607,17618]
name: CommandType [17277,17288]
===
match
---
name: log [15513,15516]
name: log [15183,15186]
===
match
---
name: log [14784,14787]
name: log [14454,14457]
===
match
---
try_stmt [16596,17292]
try_stmt [16266,16962]
===
match
---
trailer [13877,13879]
trailer [13547,13549]
===
match
---
suite [4647,4851]
suite [4692,4896]
===
match
---
arglist [24617,24636]
arglist [24287,24306]
===
match
---
trailer [20198,20219]
trailer [19868,19889]
===
match
---
trailer [11735,11748]
trailer [11780,11793]
===
match
---
operator: -> [23565,23567]
operator: -> [23235,23237]
===
match
---
simple_stmt [942,958]
simple_stmt [942,958]
===
match
---
operator: = [5891,5892]
operator: = [5936,5937]
===
match
---
name: shutdown [4229,4237]
name: shutdown [4274,4282]
===
match
---
trailer [21652,21660]
trailer [21322,21330]
===
match
---
expr_stmt [11319,11357]
expr_stmt [11364,11402]
===
match
---
expr_stmt [13016,13148]
expr_stmt [12680,12818]
===
match
---
arglist [15653,15693]
arglist [15323,15363]
===
match
---
import_from [1228,1284]
import_from [1273,1329]
===
match
---
name: Tuple [1214,1219]
name: Tuple [1259,1264]
===
match
---
simple_stmt [24544,24574]
simple_stmt [24214,24244]
===
match
---
operator: { [22332,22333]
operator: { [22002,22003]
===
match
---
name: sync_parallelism [22151,22167]
name: sync_parallelism [21821,21837]
===
match
---
trailer [20109,20117]
trailer [19779,19787]
===
match
---
name: app [23148,23151]
name: app [22818,22821]
===
match
---
trailer [15235,15240]
trailer [14905,14910]
===
match
---
name: task_ids [23476,23484]
name: task_ids [23146,23154]
===
match
---
trailer [22733,22759]
trailer [22403,22429]
===
match
---
trailer [22414,22441]
trailer [22084,22111]
===
match
---
suite [24527,24663]
suite [24197,24333]
===
match
---
operator: , [5884,5885]
operator: , [5929,5930]
===
match
---
dotted_name [6751,6775]
dotted_name [6796,6820]
===
match
---
name: _get_many_from_db_backend [23520,23545]
name: _get_many_from_db_backend [23190,23215]
===
match
---
simple_stmt [2141,2179]
simple_stmt [2186,2224]
===
match
---
name: database [1364,1372]
name: database [1409,1417]
===
match
---
return_stmt [19434,19444]
return_stmt [19104,19114]
===
match
---
trailer [7802,7822]
trailer [7847,7867]
===
match
---
trailer [8337,8362]
trailer [8382,8407]
===
match
---
name: self [20176,20180]
name: self [19846,19850]
===
match
---
trailer [13968,13974]
trailer [13638,13644]
===
match
---
operator: , [16508,16509]
operator: , [16178,16179]
===
match
---
operator: = [13038,13039]
operator: = [12702,12703]
===
match
---
name: ExceptionWithTraceback [20611,20633]
name: ExceptionWithTraceback [20281,20303]
===
match
---
expr_stmt [4169,4176]
expr_stmt [4214,4221]
===
match
---
dotted_name [6787,6811]
dotted_name [6832,6856]
===
match
---
operator: -> [9749,9751]
operator: -> [9794,9796]
===
match
---
import_from [1429,1466]
import_from [1474,1511]
===
match
---
arglist [16353,16369]
arglist [16023,16039]
===
match
---
suite [5824,5899]
suite [5869,5944]
===
match
---
atom_expr [9779,9818]
atom_expr [9824,9863]
===
match
---
expr_stmt [5966,6038]
expr_stmt [6011,6083]
===
match
---
name: self [8107,8111]
name: self [8152,8156]
===
match
---
simple_stmt [17222,17292]
simple_stmt [16892,16962]
===
match
---
operator: , [24375,24376]
operator: , [24045,24046]
===
match
---
name: state [21464,21469]
name: state [21134,21139]
===
match
---
simple_stmt [3225,3259]
simple_stmt [3270,3304]
===
match
---
atom_expr [15006,15013]
atom_expr [14676,14683]
===
match
---
and_test [10310,10454]
and_test [10355,10499]
===
match
---
suite [17370,17502]
suite [17040,17172]
===
match
---
atom_expr [16944,16985]
atom_expr [16614,16655]
===
match
---
trailer [16948,16970]
trailer [16618,16640]
===
match
---
trailer [15865,15871]
trailer [15535,15541]
===
match
---
name: env [4370,4373]
name: env [4415,4418]
===
match
---
name: _process_tasks [9634,9648]
name: _process_tasks [9679,9693]
===
match
---
param [17928,17951]
param [17598,17621]
===
match
---
name: AirflowException [3486,3502]
name: AirflowException [3531,3547]
===
match
---
number: 1 [25082,25083]
number: 1 [24769,24770]
===
match
---
name: config_templates [1659,1675]
name: config_templates [1704,1720]
===
match
---
operator: = [23921,23922]
operator: = [23591,23592]
===
match
---
funcdef [8432,8563]
funcdef [8477,8608]
===
match
---
trailer [10069,10075]
trailer [10114,10120]
===
match
---
operator: -> [13206,13208]
operator: -> [12876,12878]
===
match
---
atom_expr [8865,8887]
atom_expr [8910,8932]
===
match
---
name: self [8442,8446]
name: self [8487,8491]
===
match
---
trailer [17240,17291]
trailer [16910,16961]
===
match
---
name: ti [19357,19359]
name: ti [19027,19029]
===
match
---
expr_stmt [3753,3774]
expr_stmt [3798,3819]
===
match
---
operator: += [10841,10843]
operator: += [10886,10888]
===
match
---
atom_expr [7774,7796]
atom_expr [7819,7841]
===
match
---
name: self [16201,16205]
name: self [15871,15875]
===
match
---
operator: -> [8626,8628]
operator: -> [8671,8673]
===
match
---
number: 1 [7803,7804]
number: 1 [7848,7849]
===
match
---
name: async_results [25257,25270]
name: async_results [24949,24962]
===
match
---
name: subprocess [4508,4518]
name: subprocess [4553,4563]
===
match
---
name: jobs [6660,6664]
name: jobs [6705,6709]
===
match
---
operator: , [16363,16364]
operator: , [16033,16034]
===
match
---
name: log [15985,15988]
name: log [15655,15658]
===
match
---
name: AirflowTaskTimeout [10257,10275]
name: AirflowTaskTimeout [10302,10320]
===
match
---
name: key [20159,20162]
name: key [19829,19832]
===
match
---
operator: , [2851,2852]
operator: , [2896,2897]
===
match
---
name: FAILED [11252,11258]
name: FAILED [11297,11303]
===
match
---
param [16488,16509]
param [16158,16179]
===
match
---
simple_stmt [19104,19125]
simple_stmt [18774,18795]
===
match
---
trailer [24149,24184]
trailer [23819,23854]
===
match
---
name: timedout_keys [14752,14765]
name: timedout_keys [14422,14435]
===
match
---
name: result [6129,6135]
name: result [6174,6180]
===
match
---
simple_stmt [24697,24727]
simple_stmt [24367,24397]
===
match
---
atom_expr [11319,11333]
atom_expr [11364,11378]
===
match
---
suite [3352,3555]
suite [3397,3600]
===
match
---
name: self [10810,10814]
name: self [10855,10859]
===
match
---
name: task_tuple [5560,5570]
name: task_tuple [5605,5615]
===
match
---
name: state [16510,16515]
name: state [16180,16185]
===
match
---
string: "task_id" [24036,24045]
string: "task_id" [23706,23715]
===
match
---
name: _process_tasks [9679,9693]
name: _process_tasks [9724,9738]
===
match
---
param [13200,13204]
param [12870,12874]
===
match
---
name: logging [2270,2277]
name: logging [2315,2322]
===
match
---
trailer [3333,3338]
trailer [3378,3383]
===
match
---
arglist [16444,16453]
arglist [16114,16123]
===
match
---
expr_stmt [23140,23198]
expr_stmt [22810,22868]
===
match
---
atom_expr [5846,5898]
atom_expr [5891,5943]
===
match
---
name: tis [19144,19147]
name: tis [18814,18817]
===
match
---
operator: + [4798,4799]
operator: + [4843,4844]
===
match
---
atom [25391,25393]
atom [25084,25086]
===
match
---
trailer [17094,17098]
trailer [16764,16768]
===
match
---
simple_stmt [10061,10095]
simple_stmt [10106,10140]
===
match
---
operator: , [17702,17703]
operator: , [17372,17373]
===
match
---
param [16270,16291]
param [15940,15961]
===
match
---
import_as_name [1494,1533]
import_as_name [1539,1578]
===
match
---
simple_stmt [23140,23199]
simple_stmt [22810,22869]
===
match
---
trailer [10009,10031]
trailer [10054,10076]
===
match
---
import_from [2141,2178]
import_from [2186,2223]
===
match
---
atom_expr [21370,21399]
atom_expr [21040,21069]
===
match
---
name: log [17227,17230]
name: log [16897,16900]
===
match
---
name: self [25570,25574]
name: self [25263,25267]
===
match
---
name: pop [16390,16393]
name: pop [16060,16063]
===
match
---
operator: + [3537,3538]
operator: + [3582,3583]
===
match
---
trailer [7691,7721]
trailer [7736,7766]
===
match
---
expr_stmt [24743,24754]
expr_stmt [24413,24424]
===
match
---
trailer [15010,15013]
trailer [14680,14683]
===
match
---
name: task_instance_str [20306,20323]
name: task_instance_str [19976,19993]
===
match
---
number: 5 [17499,17500]
number: 5 [17169,17170]
===
match
---
operator: = [19646,19647]
operator: = [19316,19317]
===
match
---
operator: , [20205,20206]
operator: , [19875,19876]
===
match
---
trailer [10544,10549]
trailer [10589,10594]
===
match
---
name: str [17644,17647]
name: str [17314,17317]
===
match
---
name: command_to_exec [2921,2936]
name: command_to_exec [2966,2981]
===
match
---
operator: , [16447,16448]
operator: , [16117,16118]
===
match
---
name: state [24789,24794]
name: state [24459,24464]
===
match
---
operator: = [19479,19480]
operator: = [19149,19150]
===
match
---
trailer [15994,16018]
trailer [15664,15688]
===
match
---
expr_stmt [23673,23710]
expr_stmt [23343,23380]
===
match
---
name: TaskInstanceKey [8287,8302]
name: TaskInstanceKey [8332,8347]
===
match
---
expr_stmt [8333,8426]
expr_stmt [8378,8471]
===
match
---
trailer [12415,12443]
trailer [12460,12488]
===
match
---
atom_expr [9242,9281]
atom_expr [9287,9326]
===
match
---
simple_stmt [11731,11787]
simple_stmt [11776,11832]
===
match
---
atom_expr [13942,13976]
atom_expr [13612,13646]
===
match
---
name: Exception [17162,17171]
name: Exception [16832,16841]
===
match
---
trailer [4518,4525]
trailer [4563,4570]
===
match
---
atom_expr [9629,9669]
atom_expr [9674,9714]
===
match
---
suite [10290,10875]
suite [10335,10920]
===
match
---
suite [10455,10875]
suite [10500,10920]
===
match
---
trailer [16443,16454]
trailer [16113,16124]
===
match
---
operator: = [19611,19612]
operator: = [19281,19282]
===
match
---
operator: = [19120,19121]
operator: = [18790,18791]
===
match
---
arglist [7692,7720]
arglist [7737,7765]
===
match
---
atom_expr [9258,9280]
atom_expr [9303,9325]
===
match
---
trailer [19684,19692]
trailer [19354,19362]
===
match
---
name: log [4109,4112]
name: log [4154,4157]
===
match
---
testlist_comp [19258,19298]
testlist_comp [18928,18968]
===
match
---
atom_expr [24767,24786]
atom_expr [24437,24456]
===
match
---
name: task_cls [23719,23727]
name: task_cls [23389,23397]
===
match
---
name: TaskInstance [17961,17973]
name: TaskInstance [17631,17643]
===
match
---
trailer [9261,9280]
trailer [9306,9325]
===
match
---
simple_stmt [23427,23511]
simple_stmt [23097,23181]
===
match
---
simple_stmt [13865,13880]
simple_stmt [13535,13550]
===
match
---
trailer [17230,17240]
trailer [16900,16910]
===
match
---
testlist [6115,6135]
testlist [6160,6180]
===
match
---
expr_stmt [12399,12469]
expr_stmt [12444,12514]
===
match
---
name: self [22210,22214]
name: self [21880,21884]
===
match
---
name: try_adopt_task_instances [17897,17921]
name: try_adopt_task_instances [17567,17591]
===
match
---
import_name [958,972]
import_name [958,972]
===
match
---
number: 1.0 [2531,2534]
number: 1.0 [2576,2579]
===
match
---
trailer [9963,9971]
trailer [10008,10016]
===
match
---
name: self [25133,25137]
name: self [24820,24824]
===
match
---
operator: { [7919,7920]
operator: { [7964,7965]
===
match
---
name: self [24108,24112]
name: self [23778,23782]
===
match
---
operator: { [21583,21584]
operator: { [21253,21254]
===
match
---
arglist [17104,17145]
arglist [16774,16815]
===
match
---
testlist_star_expr [5718,5753]
testlist_star_expr [5763,5798]
===
match
---
exprlist [19706,19735]
exprlist [19376,19405]
===
match
---
simple_stmt [5837,5899]
simple_stmt [5882,5944]
===
match
---
number: 1 [12116,12117]
number: 1 [12161,12162]
===
match
---
expr_stmt [5837,5898]
expr_stmt [5882,5943]
===
match
---
operator: = [9332,9333]
operator: = [9377,9378]
===
match
---
atom_expr [16738,16759]
atom_expr [16408,16429]
===
match
---
try_stmt [3611,4298]
try_stmt [3656,4343]
===
match
---
simple_stmt [15374,15500]
simple_stmt [15044,15170]
===
match
---
term [8843,8887]
term [8888,8932]
===
match
---
simple_stmt [12478,12548]
simple_stmt [12523,12593]
===
match
---
param [23546,23551]
param [23216,23221]
===
match
---
operator: , [5652,5653]
operator: , [5697,5698]
===
match
---
operator: , [10993,10994]
operator: , [11038,11039]
===
match
---
atom_expr [4153,4159]
atom_expr [4198,4204]
===
match
---
name: DatabaseBackend [1380,1395]
name: DatabaseBackend [1425,1440]
===
match
---
with_stmt [25007,25924]
with_stmt [24677,25617]
===
match
---
name: _check_for_stalled_adopted_tasks [13469,13501]
name: _check_for_stalled_adopted_tasks [13139,13171]
===
match
---
import_from [2098,2140]
import_from [2143,2185]
===
match
---
name: key [6007,6010]
name: key [6052,6055]
===
match
---
string: "executor.adopted_task_timeouts (%d)\n\t%s" [15535,15578]
string: "executor.adopted_task_timeouts (%d)\n\t%s" [15205,15248]
===
match
---
suite [11302,11959]
suite [11347,12004]
===
match
---
param [24258,24267]
param [23928,23937]
===
match
---
name: List [9721,9725]
name: List [9766,9770]
===
match
---
name: self [7733,7737]
name: self [7778,7782]
===
match
---
name: key [10836,10839]
name: key [10881,10884]
===
match
---
operator: , [11149,11150]
operator: , [11194,11195]
===
match
---
if_stmt [14749,15241]
if_stmt [14419,14911]
===
match
---
expr_stmt [22801,22861]
expr_stmt [22471,22531]
===
match
---
operator: { [20263,20264]
operator: { [19933,19934]
===
match
---
arglist [10987,11017]
arglist [11032,11062]
===
match
---
operator: = [4536,4537]
operator: = [4581,4582]
===
match
---
name: datetime [8073,8081]
name: datetime [8118,8126]
===
match
---
name: len [15592,15595]
name: len [15262,15265]
===
match
---
name: TaskInstanceKey [5456,5471]
name: TaskInstanceKey [5501,5516]
===
match
---
file_input [787,25966]
file_input [787,25659]
===
match
---
fstring_string: Celery Task ID:  [21567,21583]
fstring_string: Celery Task ID:  [21237,21253]
===
match
---
trailer [13342,13365]
trailer [13012,13035]
===
match
---
name: values [15961,15967]
name: values [15631,15637]
===
match
---
tfpdef [16522,16531]
tfpdef [16192,16201]
===
match
---
parameters [17867,17873]
parameters [17537,17543]
===
match
---
import_name [942,957]
import_name [942,957]
===
match
---
parameters [9693,9748]
parameters [9738,9793]
===
match
---
return_stmt [24101,24184]
return_stmt [23771,23854]
===
match
---
operator: , [23550,23551]
operator: , [23220,23221]
===
match
---
name: state_info [24345,24355]
name: state_info [24015,24025]
===
match
---
simple_stmt [6744,6776]
simple_stmt [6789,6821]
===
match
---
atom_expr [3718,3743]
atom_expr [3763,3788]
===
match
---
arglist [23476,23509]
arglist [23146,23179]
===
match
---
name: result [11169,11175]
name: result [11214,11220]
===
match
---
name: self [11731,11735]
name: self [11776,11780]
===
match
---
atom_expr [10976,11018]
atom_expr [11021,11063]
===
match
---
name: EventBufferValueType [24314,24334]
name: EventBufferValueType [23984,24004]
===
match
---
name: celery [1290,1296]
name: celery [1335,1341]
===
match
---
operator: -> [24889,24891]
operator: -> [24559,24561]
===
match
---
trailer [25105,25156]
trailer [24792,24843]
===
match
---
name: get_many [19505,19513]
name: get_many [19175,19183]
===
match
---
fstring [5988,6038]
fstring [6033,6083]
===
match
---
string: """Do not allow async execution for Celery executor.""" [17719,17774]
string: """Do not allow async execution for Celery executor.""" [17389,17444]
===
match
---
atom_expr [6056,6102]
atom_expr [6101,6147]
===
match
---
param [17922,17927]
param [17592,17597]
===
match
---
trailer [3051,3103]
trailer [3096,3148]
===
match
---
simple_stmt [24809,24827]
simple_stmt [24479,24497]
===
match
---
name: adopted_task_timeouts [13947,13968]
name: adopted_task_timeouts [13617,13638]
===
match
---
simple_stmt [2755,2800]
simple_stmt [2800,2845]
===
match
---
tfpdef [4327,4355]
tfpdef [4372,4400]
===
match
---
atom [23147,23198]
atom [22817,22868]
===
match
---
atom_expr [8833,8888]
atom_expr [8878,8933]
===
match
---
arglist [16224,16240]
arglist [15894,15910]
===
match
---
suite [6247,6920]
suite [6292,6965]
===
match
---
atom_expr [3872,3891]
atom_expr [3917,3936]
===
match
---
name: self [15261,15265]
name: self [14931,14935]
===
match
---
simple_stmt [5232,5259]
simple_stmt [5277,5304]
===
match
---
atom_expr [11220,11242]
atom_expr [11265,11287]
===
match
---
name: key [11238,11241]
name: key [11283,11286]
===
match
---
testlist_comp [9302,9330]
testlist_comp [9347,9375]
===
match
---
trailer [22926,22934]
trailer [22596,22604]
===
match
---
name: session [23830,23837]
name: session [23500,23507]
===
match
---
name: ret [4034,4037]
name: ret [4079,4082]
===
match
---
funcdef [15246,15707]
funcdef [14916,15377]
===
match
---
name: _get_many_from_kv_backend [22987,23012]
name: _get_many_from_kv_backend [22657,22682]
===
match
---
simple_stmt [6780,6826]
simple_stmt [6825,6871]
===
match
---
comparison [3442,3450]
comparison [3487,3495]
===
match
---
name: conf [1754,1758]
name: conf [1799,1803]
===
match
---
name: log [15379,15382]
name: log [15049,15052]
===
match
---
name: airflow [6787,6794]
name: airflow [6832,6839]
===
match
---
testlist_star_expr [3401,3409]
testlist_star_expr [3446,3454]
===
match
---
atom_expr [23924,23969]
atom_expr [23594,23639]
===
match
---
atom_expr [16715,16736]
atom_expr [16385,16406]
===
match
---
testlist_comp [23924,23987]
testlist_comp [23594,23657]
===
match
---
string: 'info' [21392,21398]
string: 'info' [21062,21068]
===
match
---
name: key [16270,16273]
name: key [15940,15943]
===
match
---
trailer [4659,4669]
trailer [4704,4714]
===
match
---
funcdef [9675,11959]
funcdef [9720,12004]
===
match
---
return_stmt [8815,8890]
return_stmt [8860,8935]
===
match
---
name: self [15659,15663]
name: self [15329,15333]
===
match
---
operator: , [9256,9257]
operator: , [9301,9302]
===
match
---
name: CELERY_SEND_ERR_MSG_HEADER [11108,11134]
name: CELERY_SEND_ERR_MSG_HEADER [11153,11179]
===
match
---
simple_stmt [958,973]
simple_stmt [958,973]
===
match
---
atom_expr [9186,9212]
atom_expr [9231,9257]
===
match
---
atom [19722,19735]
atom [19392,19405]
===
match
---
name: exception_traceback [5284,5303]
name: exception_traceback [5329,5348]
===
match
---
trailer [10677,10682]
trailer [10722,10727]
===
match
---
name: key [16975,16978]
name: key [16645,16648]
===
match
---
expr_stmt [5232,5258]
expr_stmt [5277,5303]
===
match
---
param [13502,13506]
param [13172,13176]
===
match
---
name: result [22720,22726]
name: result [22390,22396]
===
match
---
name: self [13380,13384]
name: self [13050,13054]
===
match
---
trailer [20180,20198]
trailer [19850,19868]
===
match
---
atom_expr [24301,24335]
atom_expr [23971,24005]
===
match
---
trailer [2818,2822]
trailer [2863,2867]
===
match
---
parameters [16263,16314]
parameters [15933,15984]
===
match
---
atom_expr [23263,23291]
atom_expr [22933,22961]
===
match
---
subscriptlist [24372,24397]
subscriptlist [24042,24067]
===
match
---
parameters [15738,15744]
parameters [15408,15414]
===
match
---
atom_expr [16141,16161]
atom_expr [15811,15831]
===
match
---
operator: = [5282,5283]
operator: = [5327,5328]
===
match
---
trailer [23953,23969]
trailer [23623,23639]
===
match
---
name: os [3331,3333]
name: os [3376,3378]
===
match
---
name: self [13200,13204]
name: self [12870,12874]
===
match
---
simple_stmt [4758,4815]
simple_stmt [4803,4860]
===
match
---
tfpdef [17568,17588]
tfpdef [17238,17258]
===
match
---
operator: , [8302,8303]
operator: , [8347,8348]
===
match
---
trailer [15111,15124]
trailer [14781,14794]
===
match
---
atom [24401,24403]
atom [24071,24073]
===
match
---
trailer [25089,25095]
trailer [24776,24782]
===
match
---
simple_stmt [13254,13311]
simple_stmt [12924,12981]
===
match
---
name: task_results_by_task_id [23322,23345]
name: task_results_by_task_id [22992,23015]
===
match
---
name: subprocess [4460,4470]
name: subprocess [4505,4515]
===
match
---
name: list [16052,16056]
name: list [15722,15726]
===
match
---
exprlist [13920,13938]
exprlist [13590,13608]
===
match
---
simple_stmt [16778,16799]
simple_stmt [16448,16469]
===
match
---
suite [25053,25924]
suite [24740,25617]
===
match
---
name: info [16097,16101]
name: info [15767,15771]
===
match
---
tfpdef [20559,20584]
tfpdef [20229,20254]
===
match
---
name: AirflowException [4829,4845]
name: AirflowException [4874,4890]
===
match
---
operator: , [23579,23580]
operator: , [23249,23250]
===
match
---
name: Optional [17682,17690]
name: Optional [17352,17360]
===
match
---
name: now [14009,14012]
name: now [13679,13682]
===
match
---
atom_expr [24705,24726]
atom_expr [24375,24396]
===
match
---
atom_expr [10536,10789]
atom_expr [10581,10834]
===
match
---
name: pop [10952,10955]
name: pop [10997,11000]
===
match
---
name: OrderedDict [1082,1093]
name: OrderedDict [1082,1093]
===
match
---
simple_stmt [4730,4750]
simple_stmt [4775,4795]
===
match
---
fstring_expr [3981,3998]
fstring_expr [4026,4043]
===
match
---
arglist [23738,23769]
arglist [23408,23439]
===
match
---
trailer [25137,25155]
trailer [24824,24842]
===
match
---
classdef [21717,25966]
classdef [21387,25659]
===
match
---
except_clause [4046,4067]
except_clause [4091,4112]
===
match
---
atom_expr [23623,23664]
atom_expr [23293,23334]
===
match
---
trailer [23877,23881]
trailer [23547,23551]
===
match
---
name: repr [15653,15657]
name: repr [15323,15327]
===
match
---
name: OrderedDict [8085,8096]
name: OrderedDict [8130,8141]
===
match
---
trailer [15138,15145]
trailer [14808,14815]
===
match
---
expr_stmt [23207,23238]
expr_stmt [22877,22908]
===
match
---
operator: { [24401,24402]
operator: { [24071,24072]
===
match
---
name: self [7774,7778]
name: self [7819,7823]
===
match
---
trailer [16676,16687]
trailer [16346,16357]
===
match
---
atom [13905,13907]
atom [13575,13577]
===
match
---
trailer [8376,8426]
trailer [8421,8471]
===
match
---
param [17568,17589]
param [17238,17259]
===
match
---
name: log [4730,4733]
name: log [4775,4778]
===
match
---
operator: -> [2951,2953]
operator: -> [2996,2998]
===
match
---
trailer [15595,15623]
trailer [15265,15293]
===
match
---
operator: , [5504,5505]
operator: , [5549,5550]
===
match
---
name: stderr [4501,4507]
name: stderr [4546,4552]
===
match
---
trailer [8869,8887]
trailer [8914,8932]
===
match
---
simple_stmt [22801,22862]
simple_stmt [22471,22532]
===
match
---
operator: , [1197,1198]
operator: , [1242,1243]
===
match
---
dotted_name [2184,2205]
dotted_name [2229,2250]
===
match
---
operator: = [8134,8135]
operator: = [8179,8180]
===
match
---
name: self [9694,9698]
name: self [9739,9743]
===
match
---
annassign [9184,9217]
annassign [9229,9262]
===
match
---
number: 1 [8826,8827]
number: 1 [8871,8872]
===
match
---
atom_expr [7806,7817]
atom_expr [7851,7862]
===
match
---
trailer [3189,3206]
trailer [3234,3251]
===
match
---
trailer [20143,20151]
trailer [19813,19821]
===
match
---
atom_expr [16057,16075]
atom_expr [15727,15745]
===
match
---
name: backend [22681,22688]
name: backend [22351,22358]
===
match
---
name: running [11379,11386]
name: running [11424,11431]
===
match
---
trailer [2277,2287]
trailer [2322,2332]
===
match
---
expr_stmt [19104,19124]
expr_stmt [18774,18794]
===
match
---
trailer [21377,21399]
trailer [21047,21069]
===
match
---
annassign [8040,8098]
annassign [8085,8143]
===
match
---
name: pid [3348,3351]
name: pid [3393,3396]
===
match
---
simple_stmt [7831,7898]
simple_stmt [7876,7943]
===
match
---
operator: , [19294,19295]
operator: , [18964,18965]
===
match
---
and_test [10164,10289]
and_test [10209,10334]
===
match
---
trailer [15652,15694]
trailer [15322,15364]
===
match
---
name: list [19527,19531]
name: list [19197,19201]
===
match
---
name: self [10005,10009]
name: self [10050,10054]
===
match
---
arglist [14811,15038]
arglist [14481,14708]
===
match
---
trailer [17514,17519]
trailer [17184,17189]
===
match
---
param [17665,17703]
param [17335,17373]
===
match
---
name: async_result [21349,21361]
name: async_result [21019,21031]
===
match
---
trailer [4237,4239]
trailer [4282,4284]
===
match
---
name: operator [19536,19544]
name: operator [19206,19214]
===
match
---
atom_expr [22307,22315]
atom_expr [21977,21985]
===
match
---
subscript [3888,3890]
subscript [3933,3935]
===
match
---
name: v [23311,23312]
name: v [22981,22982]
===
match
---
name: async_results [24958,24971]
name: async_results [24628,24641]
===
match
---
argument [2522,2534]
argument [2567,2579]
===
match
---
name: backend [19846,19853]
name: backend [19516,19523]
===
match
---
atom_expr [20326,20346]
atom_expr [19996,20016]
===
match
---
trailer [17454,17460]
trailer [17124,17130]
===
match
---
subscriptlist [5605,5677]
subscriptlist [5650,5722]
===
match
---
simple_stmt [5427,5527]
simple_stmt [5472,5572]
===
match
---
name: not_adopted_tis [19334,19349]
name: not_adopted_tis [19004,19019]
===
match
---
suite [8945,9670]
suite [8990,9715]
===
match
---
operator: , [1172,1173]
operator: , [1217,1218]
===
match
---
funcdef [13465,15241]
funcdef [13135,14911]
===
match
---
string: 'celery' [2632,2640]
string: 'celery' [2677,2685]
===
match
---
name: execute_async [17531,17544]
name: execute_async [17201,17214]
===
match
---
operator: , [16978,16979]
operator: , [16648,16649]
===
match
---
operator: , [1166,1167]
operator: , [1211,1212]
===
match
---
operator: = [15915,15916]
operator: = [15585,15586]
===
match
---
name: conf [7680,7684]
name: conf [7725,7729]
===
match
---
if_stmt [3109,3259]
if_stmt [3154,3304]
===
match
---
trailer [9785,9788]
trailer [9830,9833]
===
match
---
name: self [22870,22874]
name: self [22540,22544]
===
match
---
testlist_comp [19723,19734]
testlist_comp [19393,19404]
===
match
---
name: task_id_to_states_and_info [25172,25198]
name: task_id_to_states_and_info [24859,24885]
===
match
---
name: command [6120,6127]
name: command [6165,6172]
===
match
---
trailer [14787,14793]
trailer [14457,14463]
===
match
---
arglist [25232,25291]
arglist [24924,24983]
===
match
---
trailer [7910,7916]
trailer [7955,7961]
===
match
---
name: State [11246,11251]
name: State [11291,11296]
===
match
---
operator: = [23260,23261]
operator: = [22930,22931]
===
match
---
name: key [17135,17138]
name: key [16805,16808]
===
match
---
simple_stmt [17783,17849]
simple_stmt [17453,17519]
===
match
---
operator: , [17926,17927]
operator: , [17596,17597]
===
match
---
import_from [1343,1428]
import_from [1388,1473]
===
match
---
atom_expr [20156,20162]
atom_expr [19826,19832]
===
match
---
simple_stmt [16664,16688]
simple_stmt [16334,16358]
===
match
---
import_name [6780,6811]
import_name [6825,6856]
===
match
---
trailer [23042,23069]
trailer [22712,22739]
===
match
---
name: error [14788,14793]
name: error [14458,14463]
===
match
---
operator: , [1253,1254]
operator: , [1298,1299]
===
match
---
trailer [16838,16846]
trailer [16508,16516]
===
match
---
trailer [24486,24490]
trailer [24156,24160]
===
match
---
operator: , [17558,17559]
operator: , [17228,17229]
===
match
---
trailer [23118,23131]
trailer [22788,22801]
===
match
---
name: _sync_parallelism [7738,7755]
name: _sync_parallelism [7783,7800]
===
match
---
name: CalledProcessError [4623,4641]
name: CalledProcessError [4668,4686]
===
match
---
name: self [14950,14954]
name: self [14620,14624]
===
match
---
trailer [9266,9279]
trailer [9311,9324]
===
match
---
atom_expr [24357,24398]
atom_expr [24027,24068]
===
match
---
suite [24336,24827]
suite [24006,24497]
===
match
---
trailer [15813,15819]
trailer [15483,15489]
===
match
---
trailer [2620,2631]
trailer [2665,2676]
===
match
---
argument [15006,15036]
argument [14676,14706]
===
match
---
trailer [22549,22557]
trailer [22219,22227]
===
match
---
parameters [13501,13507]
parameters [13171,13177]
===
match
---
test [24597,24662]
test [24267,24332]
===
match
---
simple_stmt [14779,15053]
simple_stmt [14449,14723]
===
match
---
name: task_result [24064,24075]
name: task_result [23734,23745]
===
match
---
suite [22442,22978]
suite [22112,22648]
===
match
---
simple_stmt [8107,8247]
simple_stmt [8152,8292]
===
match
---
name: task_id [23870,23877]
name: task_id [23540,23547]
===
match
---
trailer [24563,24573]
trailer [24233,24243]
===
match
---
atom_expr [7799,7822]
atom_expr [7844,7867]
===
match
---
trailer [23266,23274]
trailer [22936,22944]
===
match
---
operator: = [5874,5875]
operator: = [5919,5920]
===
match
---
trailer [15512,15516]
trailer [15182,15186]
===
match
---
sync_comp_for [23385,23416]
sync_comp_for [23055,23086]
===
match
---
operator: , [8604,8605]
operator: , [8649,8650]
===
match
---
name: State [11757,11762]
name: State [11802,11807]
===
match
---
trailer [4019,4025]
trailer [4064,4070]
===
match
---
name: TaskInstanceInCelery [5572,5592]
name: TaskInstanceInCelery [5617,5637]
===
match
---
name: bulk_state_fetcher [7836,7854]
name: bulk_state_fetcher [7881,7899]
===
match
---
name: next [19648,19652]
name: next [19318,19322]
===
match
---
param [8600,8605]
param [8645,8650]
===
match
---
name: traceback [25786,25795]
name: traceback [25479,25488]
===
match
---
atom_expr [16201,16241]
atom_expr [15871,15911]
===
match
---
atom_expr [20589,20640]
atom_expr [20259,20310]
===
match
---
operator: = [2866,2867]
operator: = [2911,2912]
===
match
---
name: first_task [9766,9776]
name: first_task [9811,9821]
===
match
---
comp_op [9499,9505]
comp_op [9544,9550]
===
match
---
expr_stmt [16090,16162]
expr_stmt [15760,15832]
===
match
---
test [21349,21409]
test [21019,21079]
===
match
---
name: READY_STATES [17425,17437]
name: READY_STATES [17095,17107]
===
match
---
atom_expr [4740,4748]
atom_expr [4785,4793]
===
match
---
name: CELERY_SEND_ERR_MSG_HEADER [2399,2425]
name: CELERY_SEND_ERR_MSG_HEADER [2444,2470]
===
match
---
trailer [8842,8888]
trailer [8887,8933]
===
match
---
name: key [10310,10313]
name: key [10355,10358]
===
match
---
name: log [11041,11044]
name: log [11086,11089]
===
match
---
name: Dict [8282,8286]
name: Dict [8327,8331]
===
match
---
trailer [12221,12265]
trailer [12266,12310]
===
match
---
name: self [9549,9553]
name: self [9594,9598]
===
match
---
expr_stmt [3401,3430]
expr_stmt [3446,3475]
===
match
---
name: async_result [21640,21652]
name: async_result [21310,21322]
===
match
---
number: 1 [4175,4176]
number: 1 [4220,4221]
===
match
---
expr_stmt [23322,23417]
expr_stmt [22992,23087]
===
match
---
name: e [21500,21501]
name: e [21170,21171]
===
match
---
name: time [1036,1040]
name: time [1036,1040]
===
match
---
name: key [10678,10681]
name: key [10723,10726]
===
match
---
name: TaskInstance [1979,1991]
name: TaskInstance [2024,2036]
===
match
---
name: now [13865,13868]
name: now [13535,13538]
===
match
---
string: """     Wrapper class used to propagate exceptions to parent processes from subprocesses.      :param exception: The exception to wrap     :type exception: Exception     :param exception_traceback: The stacktrace to wrap     :type exception_traceback: str     """ [4887,5150]
string: """     Wrapper class used to propagate exceptions to parent processes from subprocesses.      :param exception: The exception to wrap     :type exception: Exception     :param exception_traceback: The stacktrace to wrap     :type exception_traceback: str     """ [4932,5195]
===
match
---
name: task [17442,17446]
name: task [17112,17116]
===
match
---
operator: , [2640,2641]
operator: , [2685,2686]
===
match
---
trailer [5271,5281]
trailer [5316,5326]
===
match
---
name: info [17099,17103]
name: info [16769,16773]
===
match
---
operator: = [8423,8424]
operator: = [8468,8469]
===
match
---
trailer [21441,21449]
trailer [21111,21119]
===
match
---
trailer [4391,4393]
trailer [4436,4438]
===
match
---
param [8606,8624]
param [8651,8669]
===
match
---
simple_stmt [9366,9429]
simple_stmt [9411,9474]
===
match
---
name: str [24372,24375]
name: str [24042,24045]
===
match
---
param [15739,15743]
param [15409,15413]
===
match
---
name: chunksize [13125,13134]
name: chunksize [12794,12803]
===
match
---
atom_expr [4730,4749]
atom_expr [4775,4794]
===
match
---
name: state_or_exception [25899,25917]
name: state_or_exception [25592,25610]
===
match
---
name: self [12524,12528]
name: self [12569,12573]
===
match
---
arglist [12498,12546]
arglist [12543,12591]
===
match
---
name: sync [13195,13199]
name: sync [12865,12869]
===
match
---
name: EventBufferValueType [23048,23068]
name: EventBufferValueType [22718,22738]
===
match
---
not_test [13226,13240]
not_test [12896,12910]
===
match
---
operator: * [6230,6231]
operator: * [6275,6276]
===
match
---
param [5175,5196]
param [5220,5241]
===
match
---
expr_stmt [2399,2455]
expr_stmt [2444,2500]
===
match
---
atom_expr [16778,16798]
atom_expr [16448,16468]
===
match
---
operator: , [16791,16792]
operator: , [16461,16462]
===
match
---
suite [17346,17522]
suite [17016,17192]
===
match
---
trailer [8479,8562]
trailer [8524,8607]
===
match
---
trailer [23935,23953]
trailer [23605,23623]
===
match
---
name: timedout_keys [14714,14727]
name: timedout_keys [14384,14397]
===
match
---
trailer [19681,19684]
trailer [19351,19354]
===
match
---
atom_expr [9334,9353]
atom_expr [9379,9398]
===
match
---
operator: * [8847,8848]
operator: * [8892,8893]
===
match
---
funcdef [16247,16455]
funcdef [15917,16125]
===
match
---
name: tasks [15439,15444]
name: tasks [15109,15114]
===
match
---
name: task_id [22335,22342]
name: task_id [22005,22012]
===
match
---
param [22285,22290]
param [21955,21960]
===
match
---
trailer [4156,4159]
trailer [4201,4204]
===
match
---
suite [13003,13149]
suite [12667,12819]
===
match
---
simple_stmt [1646,1720]
simple_stmt [1691,1765]
===
match
---
simple_stmt [11412,11437]
simple_stmt [11457,11482]
===
match
---
atom_expr [3112,3157]
atom_expr [3157,3202]
===
match
---
name: self [9118,9122]
name: self [9163,9167]
===
match
---
operator: , [22418,22419]
operator: , [22088,22089]
===
match
---
name: _get_many_using_multiprocessing [24836,24867]
name: _get_many_using_multiprocessing [24506,24537]
===
match
---
name: async_result [16036,16048]
name: async_result [15706,15718]
===
match
---
subscriptlist [22415,22440]
subscriptlist [22085,22110]
===
match
---
arglist [11936,11956]
arglist [11981,12001]
===
match
---
name: airflow [1832,1839]
name: airflow [1877,1884]
===
match
---
trailer [20112,20116]
trailer [19782,19786]
===
match
---
trailer [9153,9155]
trailer [9198,9200]
===
match
---
trailer [16974,16985]
trailer [16644,16655]
===
match
---
simple_stmt [1827,1919]
simple_stmt [1872,1964]
===
match
---
name: SimpleTaskInstance [1959,1977]
name: SimpleTaskInstance [2004,2022]
===
match
---
expr_stmt [24449,24499]
expr_stmt [24119,24169]
===
match
---
trailer [2631,2666]
trailer [2676,2711]
===
match
---
operator: , [21708,21709]
operator: , [21378,21379]
===
match
---
simple_stmt [22720,22775]
simple_stmt [22390,22445]
===
match
---
name: async_result [20559,20571]
name: async_result [20229,20241]
===
match
---
name: key [16788,16791]
name: key [16458,16461]
===
match
---
name: ret [4169,4172]
name: ret [4214,4217]
===
match
---
simple_stmt [25932,25966]
simple_stmt [25625,25659]
===
match
---
trailer [10955,10960]
trailer [11000,11005]
===
match
---
atom_expr [10887,10913]
atom_expr [10932,10958]
===
match
---
dotted_name [1832,1863]
dotted_name [1877,1908]
===
match
---
name: operators [6759,6768]
name: operators [6804,6813]
===
match
---
simple_stmt [9103,9156]
simple_stmt [9148,9201]
===
match
---
tfpdef [16510,16520]
tfpdef [16180,16190]
===
match
---
name: airflow [3565,3572]
name: airflow [3610,3617]
===
match
---
operator: = [10003,10004]
operator: = [10048,10049]
===
match
---
trailer [4622,4641]
trailer [4667,4686]
===
match
---
name: task_publish_retries [10815,10835]
name: task_publish_retries [10860,10880]
===
match
---
operator: , [13113,13114]
operator: , [12782,12783]
===
match
---
trailer [3772,3774]
trailer [3817,3819]
===
match
---
arglist [10175,10205]
arglist [10220,10250]
===
match
---
name: any [17389,17392]
name: any [17059,17062]
===
match
---
name: task_result [24024,24035]
name: task_result [23694,23705]
===
match
---
trailer [3046,3051]
trailer [3091,3096]
===
match
---
operator: , [9394,9395]
operator: , [9439,9440]
===
match
---
name: self [17305,17309]
name: self [16975,16979]
===
match
---
name: self [8539,8543]
name: self [8584,8588]
===
match
---
name: async_results [22638,22651]
name: async_results [22308,22321]
===
match
---
name: self [10536,10540]
name: self [10581,10585]
===
match
---
name: self [23013,23017]
name: self [22683,22687]
===
match
---
fstring [20247,20271]
fstring [19917,19941]
===
match
---
expr_stmt [2264,2297]
expr_stmt [2309,2342]
===
match
---
simple_stmt [985,1001]
simple_stmt [985,1001]
===
match
---
trailer [15124,15129]
trailer [14794,14799]
===
match
---
string: ":%s\n%s\n" [25676,25687]
string: ":%s\n%s\n" [25369,25380]
===
match
---
trailer [12060,12081]
trailer [12105,12126]
===
match
---
name: setproctitle [1559,1571]
name: setproctitle [1604,1616]
===
match
---
atom_expr [3854,3892]
atom_expr [3899,3937]
===
match
---
name: Celery [2807,2813]
name: Celery [2852,2858]
===
match
---
trailer [15809,15813]
trailer [15479,15483]
===
match
---
name: _prepare_state_and_info_by_task_dict [23439,23475]
name: _prepare_state_and_info_by_task_dict [23109,23145]
===
match
---
trailer [19845,19853]
trailer [19515,19523]
===
match
---
trailer [7815,7817]
trailer [7860,7862]
===
match
---
operator: = [5247,5248]
operator: = [5292,5293]
===
match
---
atom_expr [9118,9155]
atom_expr [9163,9200]
===
match
---
name: pop [16971,16974]
name: pop [16641,16644]
===
match
---
name: cpu_count [7806,7815]
name: cpu_count [7851,7860]
===
match
---
name: task_ids [24427,24435]
name: task_ids [24097,24105]
===
match
---
name: _ [5723,5724]
name: _ [5768,5769]
===
match
---
string: "Adopted the following %d tasks from a dead executor\n\t%s" [20390,20449]
string: "Adopted the following %d tasks from a dead executor\n\t%s" [20060,20119]
===
match
---
trailer [9725,9747]
trailer [9770,9792]
===
match
---
name: DEFAULT_CELERY_CONFIG [2778,2799]
name: DEFAULT_CELERY_CONFIG [2823,2844]
===
match
---
return_stmt [12206,12266]
return_stmt [12251,12311]
===
match
---
arglist [3423,3429]
arglist [3468,3474]
===
match
---
trailer [11422,11427]
trailer [11467,11472]
===
match
---
suite [21191,21476]
suite [20861,21146]
===
match
---
name: self [11990,11994]
name: self [12035,12039]
===
match
---
simple_stmt [4169,4177]
simple_stmt [4214,4222]
===
match
---
atom_expr [20110,20116]
atom_expr [19780,19786]
===
match
---
name: BulkStateFetcher [7857,7873]
name: BulkStateFetcher [7902,7918]
===
match
---
atom_expr [24954,24972]
atom_expr [24624,24642]
===
match
---
trailer [9241,9282]
trailer [9286,9327]
===
match
---
operator: = [25026,25027]
operator: = [24713,24714]
===
match
---
atom_expr [16104,16162]
atom_expr [15774,15832]
===
match
---
name: conf [8365,8369]
name: conf [8410,8414]
===
match
---
atom_expr [15469,15487]
atom_expr [15139,15157]
===
match
---
operator: , [8385,8386]
operator: , [8430,8431]
===
match
---
operator: , [10626,10627]
operator: , [10671,10672]
===
match
---
argument [4527,4541]
argument [4572,4586]
===
match
---
operator: -> [22404,22406]
operator: -> [22074,22076]
===
match
---
subscriptlist [23043,23068]
subscriptlist [22713,22738]
===
match
---
name: task_results [23404,23416]
name: task_results [23074,23086]
===
match
---
name: getattr [11928,11935]
name: getattr [11973,11980]
===
match
---
trailer [16417,16439]
trailer [16087,16109]
===
match
---
name: len [20451,20454]
name: len [20121,20124]
===
match
---
name: get_hostname [3539,3551]
name: get_hostname [3584,3596]
===
match
---
name: result [11283,11289]
name: result [11328,11334]
===
match
---
name: self [19481,19485]
name: self [19151,19155]
===
match
---
name: join [15001,15005]
name: join [14671,14675]
===
match
---
expr_stmt [7774,7822]
expr_stmt [7819,7867]
===
match
---
name: key [9495,9498]
name: key [9540,9543]
===
match
---
trailer [23627,23651]
trailer [23297,23321]
===
match
---
expr_stmt [22598,22652]
expr_stmt [22268,22322]
===
match
---
name: Pool [25012,25016]
name: ProcessPoolExecutor [24682,24701]
===
match
---
funcdef [17893,20529]
funcdef [17563,20199]
===
match
---
trailer [21361,21366]
trailer [21031,21036]
===
match
---
name: log [10541,10544]
name: log [10586,10589]
===
match
---
name: args [5870,5874]
name: args [5915,5919]
===
match
---
trailer [20372,20496]
trailer [20042,20166]
===
match
---
atom_expr [12411,12469]
atom_expr [12456,12514]
===
match
---
atom_expr [15596,15622]
atom_expr [15266,15292]
===
match
---
name: result [1441,1447]
name: result [1486,1492]
===
match
---
trailer [11920,11926]
trailer [11965,11971]
===
match
---
arglist [16975,16984]
arglist [16645,16654]
===
match
---
simple_stmt [25861,25924]
simple_stmt [25554,25617]
===
match
---
simple_stmt [20506,20529]
simple_stmt [20176,20199]
===
match
---
trailer [17960,17974]
trailer [17630,17644]
===
match
---
name: info [15383,15387]
name: info [15053,15057]
===
match
---
name: app [2801,2804]
name: app [2846,2849]
===
match
---
arglist [2710,2743]
arglist [2755,2788]
===
match
---
fstring [21565,21624]
fstring [21235,21294]
===
match
---
name: celery_tasks [19798,19810]
name: celery_tasks [19468,19480]
===
match
---
name: key [16488,16491]
name: key [16158,16161]
===
match
---
trailer [16339,16352]
trailer [16009,16022]
===
match
---
name: app [22677,22680]
name: app [22347,22350]
===
match
---
name: state [17398,17403]
name: state [17068,17073]
===
match
---
name: get [16137,16140]
name: get [15807,15810]
===
match
---
name: getfloat [2482,2490]
name: getfloat [2527,2535]
===
match
---
atom [24023,24092]
atom [23693,23762]
===
match
---
atom_expr [22729,22774]
atom_expr [22399,22444]
===
match
---
name: repr [15006,15010]
name: repr [14676,14680]
===
match
---
name: conf [2477,2481]
name: conf [2522,2526]
===
match
---
operator: , [1883,1884]
operator: , [1928,1929]
===
match
---
simple_stmt [10476,10516]
simple_stmt [10521,10561]
===
match
---
expr_stmt [21342,21409]
expr_stmt [21012,21079]
===
match
---
name: add [20152,20155]
name: add [19822,19825]
===
match
---
trailer [16439,16443]
trailer [16109,16113]
===
match
---
operator: , [24312,24313]
operator: , [23982,23983]
===
match
---
name: _ [10113,10114]
name: _ [10158,10159]
===
match
---
trailer [16205,16223]
trailer [15875,15893]
===
match
---
dotted_name [2146,2165]
dotted_name [2191,2210]
===
match
---
name: update_all_task_states [13343,13365]
name: update_all_task_states [13013,13035]
===
match
---
operator: , [10737,10738]
operator: , [10782,10783]
===
match
---
funcdef [24832,25966]
funcdef [24502,25659]
===
match
---
parameters [17544,17709]
parameters [17214,17379]
===
match
---
operator: , [24972,24973]
operator: , [24642,24643]
===
match
---
param [22291,22302]
param [21961,21972]
===
match
---
operator: , [8413,8414]
operator: , [8458,8459]
===
match
---
name: self [9506,9510]
name: self [9551,9555]
===
match
---
simple_stmt [6252,6573]
simple_stmt [6297,6618]
===
match
---
atom_expr [10708,10737]
atom_expr [10753,10782]
===
match
---
trailer [4741,4748]
trailer [4786,4793]
===
match
---
trailer [4845,4850]
trailer [4890,4895]
===
match
---
arglist [11909,11957]
arglist [11954,12002]
===
match
---
name: celery [1233,1239]
name: celery [1278,1284]
===
match
---
simple_stmt [22870,22956]
simple_stmt [22540,22626]
===
match
---
name: task_result [24515,24526]
name: task_result [24185,24196]
===
match
---
atom_expr [10211,10289]
atom_expr [10256,10334]
===
match
---
trailer [19579,19581]
trailer [19249,19251]
===
match
---
simple_stmt [3480,3555]
simple_stmt [3525,3600]
===
match
---
name: MutableMapping [25347,25361]
name: MutableMapping [25040,25054]
===
match
---
if_stmt [10307,10875]
if_stmt [10352,10920]
===
match
---
trailer [20158,20162]
trailer [19828,19832]
===
match
---
atom_expr [3762,3774]
atom_expr [3807,3819]
===
match
---
suite [2667,2745]
suite [2712,2790]
===
match
---
name: airflow [2014,2021]
name: airflow [2059,2066]
===
match
---
not_test [19373,19389]
not_test [19043,19059]
===
match
---
suite [10148,11959]
suite [10193,12004]
===
match
---
operator: , [25365,25366]
operator: , [25058,25059]
===
match
---
name: TaskInstanceKey [1993,2008]
name: TaskInstanceKey [2038,2053]
===
match
---
operator: = [13869,13870]
operator: = [13539,13540]
===
match
---
name: queue [5892,5897]
name: queue [5937,5942]
===
match
---
raise_stmt [17783,17848]
raise_stmt [17453,17518]
===
match
---
name: task_adoption_timeout [20065,20086]
name: task_adoption_timeout [19735,19756]
===
match
---
operator: = [16308,16309]
operator: = [15978,15979]
===
match
---
simple_stmt [8954,9095]
simple_stmt [8999,9140]
===
match
---
trailer [17492,17498]
trailer [17162,17168]
===
match
---
if_stmt [2613,2800]
if_stmt [2658,2845]
===
match
---
name: app [23924,23927]
name: app [23594,23597]
===
match
---
name: config_source [2853,2866]
name: config_source [2898,2911]
===
match
---
expr_stmt [19078,19095]
expr_stmt [18748,18765]
===
match
---
name: backend [22550,22557]
name: backend [22220,22227]
===
match
---
tfpdef [8606,8624]
tfpdef [8651,8669]
===
match
---
name: states_by_celery_task_id [19454,19478]
name: states_by_celery_task_id [19124,19148]
===
match
---
arglist [13071,13134]
arglist [12740,12803]
===
match
---
trailer [21684,21708]
trailer [21354,21378]
===
match
---
name: pid [3325,3328]
name: pid [3370,3373]
===
match
---
atom_expr [24024,24046]
atom_expr [23694,23716]
===
match
---
trailer [3726,3733]
trailer [3771,3778]
===
match
---
name: self [15374,15378]
name: self [15044,15048]
===
match
---
name: utcnow [13871,13877]
name: utcnow [13541,13547]
===
match
---
name: REVOKED [16752,16759]
name: REVOKED [16422,16429]
===
match
---
trailer [4386,4391]
trailer [4431,4436]
===
match
---
name: info [19730,19734]
name: info [19400,19404]
===
match
---
trailer [23227,23232]
trailer [22897,22902]
===
match
---
name: not_adopted_tis [19104,19119]
name: not_adopted_tis [18774,18789]
===
match
---
operator: = [19255,19256]
operator: = [18925,18926]
===
match
---
name: Celery [1247,1253]
name: Celery [1292,1298]
===
match
---
atom_expr [3901,3923]
atom_expr [3946,3968]
===
match
---
name: MutableMapping [24357,24371]
name: MutableMapping [24027,24041]
===
match
---
name: exceptions [1772,1782]
name: exceptions [1817,1827]
===
match
---
string: "status" [24564,24572]
string: "status" [24234,24242]
===
match
---
atom_expr [19164,19187]
atom_expr [18834,18857]
===
match
---
atom_expr [16052,16076]
atom_expr [15722,15746]
===
match
---
name: isinstance [25494,25504]
name: isinstance [25187,25197]
===
match
---
decorator [6170,6201]
decorator [6215,6246]
===
match
---
name: update_all_task_states [15716,15738]
name: update_all_task_states [15386,15408]
===
match
---
import_name [1041,1057]
import_name [1041,1057]
===
match
---
parameters [4326,4356]
parameters [4371,4401]
===
match
---
funcdef [17297,17522]
funcdef [16967,17192]
===
match
---
name: airflow [1924,1931]
name: airflow [1969,1976]
===
match
---
name: self [13420,13424]
name: self [13090,13094]
===
match
---
trailer [13974,13976]
trailer [13644,13646]
===
match
---
operator: , [21686,21687]
operator: , [21356,21357]
===
match
---
trailer [15350,15352]
trailer [15020,15022]
===
match
---
trailer [19535,19582]
trailer [19205,19252]
===
match
---
expr_stmt [8255,8324]
expr_stmt [8300,8369]
===
match
---
trailer [3707,3709]
trailer [3752,3754]
===
match
---
atom_expr [17222,17291]
atom_expr [16892,16961]
===
match
---
expr_stmt [2755,2799]
expr_stmt [2800,2844]
===
match
---
name: Exception [21487,21496]
name: Exception [21157,21166]
===
match
---
name: key [20202,20205]
name: key [19872,19875]
===
match
---
trailer [11050,11203]
trailer [11095,11248]
===
match
---
trailer [19670,19677]
trailer [19340,19347]
===
match
---
name: key [15125,15128]
name: key [14795,14798]
===
match
---
atom_expr [17411,17437]
atom_expr [17081,17107]
===
match
---
name: state_or_exception [25505,25523]
name: state_or_exception [25198,25216]
===
match
---
operator: = [11334,11335]
operator: = [11379,11380]
===
match
---
name: self [5267,5271]
name: self [5312,5316]
===
match
---
funcdef [17527,17849]
funcdef [17197,17519]
===
match
---
name: self [13502,13506]
name: self [13172,13176]
===
match
---
name: TaskDb [1405,1411]
name: TaskDb [1450,1456]
===
match
---
trailer [15387,15499]
trailer [15057,15169]
===
match
---
expr_stmt [2457,2535]
expr_stmt [2502,2580]
===
match
---
simple_stmt [20006,20087]
simple_stmt [19676,19757]
===
match
---
name: airflow [6717,6724]
name: airflow [6762,6769]
===
match
---
atom_expr [12494,12547]
atom_expr [12539,12592]
===
match
---
trailer [9783,9818]
trailer [9828,9863]
===
match
---
name: join [20333,20337]
name: join [20003,20007]
===
match
---
simple_stmt [5718,5767]
simple_stmt [5763,5812]
===
match
---
operator: = [2268,2269]
operator: = [2313,2314]
===
match
---
trailer [17103,17146]
trailer [16773,16816]
===
match
---
name: len [15857,15860]
name: len [15527,15530]
===
match
---
name: self [7364,7368]
name: self [7409,7413]
===
match
---
operator: = [9116,9117]
operator: = [9161,9162]
===
match
---
funcdef [16460,17292]
funcdef [16130,16962]
===
match
---
operator: , [11167,11168]
operator: , [11212,11213]
===
match
---
name: command [17598,17605]
name: command [17268,17275]
===
match
---
trailer [15213,15235]
trailer [14883,14905]
===
match
---
simple_stmt [23673,23711]
simple_stmt [23343,23381]
===
match
---
string: """Sends task to executor.""" [5684,5713]
string: """Sends task to executor.""" [5729,5758]
===
match
---
name: get_key_for_task [23160,23176]
name: get_key_for_task [22830,22846]
===
match
---
dotted_name [1348,1372]
dotted_name [1393,1417]
===
match
---
atom_expr [25096,25156]
atom_expr [24783,24843]
===
match
---
name: Stats [2035,2040]
name: Stats [2080,2085]
===
match
---
if_stmt [3439,3471]
if_stmt [3484,3516]
===
match
---
trailer [16153,16161]
trailer [15823,15831]
===
match
---
name: task_tuples_to_send [12502,12521]
name: task_tuples_to_send [12547,12566]
===
match
---
comparison [17393,17437]
comparison [17063,17107]
===
match
---
trailer [15600,15622]
trailer [15270,15292]
===
match
---
param [6230,6236]
param [6275,6281]
===
match
---
trailer [20367,20372]
trailer [20037,20042]
===
match
---
parameters [24867,24888]
parameters [24537,24558]
===
match
---
trailer [15949,15970]
trailer [15619,15640]
===
match
---
trailer [23869,23877]
trailer [23539,23547]
===
match
---
funcdef [15712,16242]
funcdef [15382,15912]
===
match
---
name: sync_pool [25043,25052]
name: sync_pool [24730,24739]
===
match
---
param [23019,23030]
param [22689,22700]
===
match
---
number: 1 [9582,9583]
number: 1 [9627,9628]
===
match
---
param [17305,17310]
param [16975,16980]
===
match
---
name: self [24868,24872]
name: self [24538,24542]
===
match
---
name: airflow [1651,1658]
name: airflow [1696,1703]
===
match
---
name: command_to_exec [3190,3205]
name: command_to_exec [3235,3250]
===
match
---
name: _tasks_list_to_task_ids [23095,23118]
name: _tasks_list_to_task_ids [22765,22788]
===
match
---
name: self [11374,11378]
name: self [11419,11423]
===
match
---
atom_expr [22677,22688]
atom_expr [22347,22358]
===
match
---
parameters [8441,8447]
parameters [8486,8492]
===
match
---
name: map [13050,13053]
name: map [12736,12739]
===
match
---
trailer [23881,23891]
trailer [23551,23561]
===
match
---
name: str [20606,20609]
name: str [20276,20279]
===
match
---
trailer [8144,8154]
trailer [8189,8199]
===
match
---
name: len [22923,22926]
name: len [22593,22596]
===
match
---
name: self [15508,15512]
name: self [15178,15182]
===
match
---
atom_expr [19230,19253]
atom_expr [18900,18923]
===
match
---
param [22383,22388]
param [22053,22058]
===
match
---
name: task_results_by_task_id [23997,24020]
name: task_results_by_task_id [23667,23690]
===
match
---
name: DEFAULT_CELERY_CONFIG [1698,1719]
name: DEFAULT_CELERY_CONFIG [1743,1764]
===
match
---
name: key_and_async_results [9981,10002]
name: key_and_async_results [10026,10047]
===
match
---
name: map [25211,25214]
name: map [24920,24923]
===
match
---
atom_expr [19798,19826]
atom_expr [19468,19496]
===
match
---
name: SUCCESS [16639,16646]
name: SUCCESS [16309,16316]
===
match
---
name: adopted_task_timeouts [8019,8040]
name: adopted_task_timeouts [8064,8085]
===
match
---
trailer [23966,23968]
trailer [23636,23638]
===
match
---
funcdef [22257,22365]
funcdef [21927,22035]
===
match
---
name: len [12498,12501]
name: len [12543,12546]
===
match
---
name: self [15434,15438]
name: self [15104,15108]
===
match
---
simple_stmt [25172,25306]
simple_stmt [24859,24999]
===
match
---
name: task_tuples_to_send [12061,12080]
name: task_tuples_to_send [12106,12125]
===
match
---
name: k [23184,23185]
name: k [22854,22855]
===
match
---
operator: = [22605,22606]
operator: = [22275,22276]
===
match
---
atom [16714,16760]
atom [16384,16430]
===
match
---
name: decode_result [23275,23288]
name: decode_result [22945,22958]
===
match
---
operator: , [25417,25418]
operator: , [25110,25111]
===
match
---
name: isinstance [10976,10986]
name: isinstance [11021,11031]
===
match
---
testlist_star_expr [19785,19795]
testlist_star_expr [19455,19465]
===
match
---
trailer [15479,15485]
trailer [15149,15155]
===
match
---
atom_expr [17488,17501]
atom_expr [17158,17171]
===
match
---
expr_stmt [22210,22251]
expr_stmt [21880,21921]
===
match
---
name: items [15480,15485]
name: items [15150,15155]
===
match
---
simple_stmt [23079,23132]
simple_stmt [22749,22802]
===
match
---
argument [4543,4550]
argument [4588,4595]
===
match
---
operator: , [15145,15146]
operator: , [14815,14816]
===
match
---
name: self [8465,8469]
name: self [8510,8514]
===
match
---
name: str [22415,22418]
name: str [22085,22088]
===
match
---
name: apply_async [5858,5869]
name: apply_async [5903,5914]
===
match
---
name: exception_traceback [6082,6101]
name: exception_traceback [6127,6146]
===
match
---
name: log [4656,4659]
name: log [4701,4704]
===
match
---
trailer [22310,22315]
trailer [21980,21985]
===
match
---
comp_op [19188,19194]
comp_op [18858,18864]
===
match
---
atom_expr [9441,9479]
atom_expr [9486,9524]
===
match
---
simple_stmt [2672,2745]
simple_stmt [2717,2790]
===
match
---
name: values [19573,19579]
name: values [19243,19249]
===
match
---
name: log [3043,3046]
name: log [3088,3091]
===
match
---
or_test [12057,12117]
or_test [12102,12162]
===
match
---
name: key [13920,13923]
name: key [13590,13593]
===
match
---
name: tasks [17455,17460]
name: tasks [17125,17130]
===
match
---
operator: = [25897,25898]
operator: = [25590,25591]
===
match
---
name: airflow [6751,6758]
name: airflow [6796,6803]
===
match
---
simple_stmt [2041,2098]
simple_stmt [2086,2143]
===
match
---
atom_expr [16825,16846]
atom_expr [16495,16516]
===
match
---
trailer [15516,15521]
trailer [15186,15191]
===
match
---
name: celery_configuration [2755,2775]
name: celery_configuration [2800,2820]
===
match
---
subscriptlist [24309,24334]
subscriptlist [23979,24004]
===
match
---
operator: , [16397,16398]
operator: , [16067,16068]
===
match
---
operator: , [13923,13924]
operator: , [13593,13594]
===
match
---
trailer [25574,25578]
trailer [25267,25271]
===
match
---
name: a [22333,22334]
name: a [22003,22004]
===
match
---
atom [11245,11265]
atom [11290,11310]
===
match
---
name: async_tasks [23552,23563]
name: async_tasks [23222,23233]
===
match
---
operator: = [13124,13125]
operator: = [12793,12794]
===
match
---
trailer [23438,23475]
trailer [23108,23145]
===
match
---
operator: = [21563,21564]
operator: = [21233,21234]
===
match
---
trailer [25081,25158]
trailer [24768,24845]
===
match
---
argument [4501,4525]
argument [4546,4570]
===
match
---
name: info [24590,24594]
name: info [24260,24264]
===
match
---
dotted_name [6171,6200]
dotted_name [6216,6245]
===
match
---
operator: = [19091,19092]
operator: = [18761,18762]
===
match
---
name: self [17510,17514]
name: self [17180,17184]
===
match
---
operator: = [3852,3853]
operator: = [3897,3898]
===
match
---
suite [15090,15241]
suite [14760,14911]
===
match
---
name: SimpleTaskInstance [5473,5491]
name: SimpleTaskInstance [5518,5536]
===
match
---
expr_stmt [23612,23664]
expr_stmt [23282,23334]
===
match
---
comparison [17003,17033]
comparison [16673,16703]
===
match
---
name: task_tuples_to_send [9649,9668]
name: task_tuples_to_send [9694,9713]
===
match
---
name: len [9258,9261]
name: len [9303,9306]
===
match
---
name: info [20214,20218]
name: info [19884,19888]
===
match
---
operator: -> [3312,3314]
operator: -> [3357,3359]
===
match
---
name: CommandType [1885,1896]
name: CommandType [1930,1941]
===
match
---
operator: , [20609,20610]
operator: , [20279,20280]
===
match
---
operator: , [1219,1220]
operator: , [1264,1265]
===
match
---
atom_expr [23148,23179]
atom_expr [22818,22849]
===
match
---
sync_comp_for [9789,9817]
sync_comp_for [9834,9862]
===
match
---
atom_expr [19739,19771]
atom_expr [19409,19441]
===
insert-tree
---
simple_stmt [787,942]
    string: """CeleryExecutor  .. seealso::     For more information on how the CeleryExecutor works, take a look at the guide:     :ref:`executor:CeleryExecutor` """ [787,941]
to
file_input [787,25966]
at 0
===
insert-tree
---
simple_stmt [1094,1145]
    import_from [1094,1144]
        dotted_name [1099,1117]
            name: concurrent [1099,1109]
            name: futures [1110,1117]
        name: ProcessPoolExecutor [1125,1144]
to
file_input [787,25966]
at 11
===
insert-tree
---
simple_stmt [1145,1183]
    import_from [1145,1182]
        name: multiprocessing [1150,1165]
        name: cpu_count [1173,1182]
to
file_input [787,25966]
at 12
===
insert-tree
---
simple_stmt [2582,2657]
    string: ''' To start the celery worker, run the command: airflow celery worker ''' [2582,2656]
to
file_input [787,25966]
at 37
===
insert-node
---
name: CeleryExecutor [7006,7020]
to
classdef [6955,20529]
at 0
===
insert-node
---
name: BaseExecutor [7021,7033]
to
classdef [6955,20529]
at 1
===
insert-tree
---
simple_stmt [7040,7391]
    string: """     CeleryExecutor is recommended for production use of Airflow. It allows     distributing the execution of task instances to multiple worker nodes.      Celery is a simple, flexible and reliable distributed system to process     vast amounts of messages, while providing operations with the tools     required to maintain such a system.     """ [7040,7390]
to
suite [6990,20529]
at 0
===
update-node
---
name: Pool [12933,12937]
replace Pool by ProcessPoolExecutor
===
update-node
---
name: Pool [25012,25016]
replace Pool by ProcessPoolExecutor
===
move-tree
---
argument [12938,12961]
    name: processes [12938,12947]
    operator: = [12947,12948]
    name: num_processes [12948,12961]
to
trailer [12937,12989]
at 0
===
insert-node
---
atom_expr [12704,12818]
to
expr_stmt [13016,13148]
at 2
===
insert-node
---
atom_expr [24888,24998]
to
expr_stmt [25172,25305]
at 2
===
update-node
---
name: processes [12938,12947]
replace processes by max_workers
===
insert-node
---
trailer [12708,12818]
to
atom_expr [12704,12818]
at 1
===
update-node
---
name: processes [25017,25026]
replace processes by max_workers
===
insert-node
---
trailer [24892,24998]
to
atom_expr [24888,24998]
at 1
===
move-tree
---
atom_expr [13040,13148]
    name: send_pool [13040,13049]
    trailer [13049,13053]
        name: map [13050,13053]
    trailer [13053,13148]
        arglist [13071,13134]
            name: send_task_to_executor [13071,13092]
            operator: , [13092,13093]
            name: task_tuples_to_send [13094,13113]
            operator: , [13113,13114]
            argument [13115,13134]
                name: chunksize [13115,13124]
                operator: = [13124,13125]
                name: chunksize [13125,13134]
to
trailer [12708,12818]
at 0
===
move-tree
---
atom_expr [25201,25305]
    name: sync_pool [25201,25210]
    trailer [25210,25214]
        name: map [25211,25214]
    trailer [25214,25305]
        arglist [25232,25291]
            name: fetch_celery_task_state [25232,25255]
            operator: , [25255,25256]
            name: async_results [25257,25270]
            operator: , [25270,25271]
            argument [25272,25291]
                name: chunksize [25272,25281]
                operator: = [25281,25282]
                name: chunksize [25282,25291]
to
trailer [24892,24998]
at 0
===
delete-tree
---
simple_stmt [787,942]
    string: """CeleryExecutor  .. seealso::     For more information on how the CeleryExecutor works, take a look at the guide:     :ref:`executor:CeleryExecutor` """ [787,941]
===
delete-tree
---
simple_stmt [1094,1138]
    import_from [1094,1137]
        name: multiprocessing [1099,1114]
        import_as_names [1122,1137]
            name: Pool [1122,1126]
            operator: , [1126,1127]
            name: cpu_count [1128,1137]
===
delete-tree
---
simple_stmt [2537,2612]
    string: ''' To start the celery worker, run the command: airflow celery worker ''' [2537,2611]
===
delete-node
---
name: CeleryExecutor [6961,6975]
===
===
delete-node
---
name: BaseExecutor [6976,6988]
===
===
delete-tree
---
simple_stmt [6995,7346]
    string: """     CeleryExecutor is recommended for production use of Airflow. It allows     distributing the execution of task instances to multiple worker nodes.      Celery is a simple, flexible and reliable distributed system to process     vast amounts of messages, while providing operations with the tools     required to maintain such a system.     """ [6995,7345]
===
delete-tree
---
funcdef [12557,12919]
    name: reset_signals [12561,12574]
    parameters [12574,12576]
    suite [12577,12919]
        simple_stmt [12731,12745]
            import_name [12731,12744]
                name: signal [12738,12744]
        simple_stmt [12758,12803]
            atom_expr [12758,12802]
                name: signal [12758,12764]
                trailer [12764,12771]
                    name: signal [12765,12771]
                trailer [12771,12802]
                    arglist [12772,12801]
                        atom_expr [12772,12785]
                            name: signal [12772,12778]
                            trailer [12778,12785]
                                name: SIGINT [12779,12785]
                        operator: , [12785,12786]
                        atom_expr [12787,12801]
                            name: signal [12787,12793]
                            trailer [12793,12801]
                                name: SIG_DFL [12794,12801]
        simple_stmt [12815,12861]
            atom_expr [12815,12860]
                name: signal [12815,12821]
                trailer [12821,12828]
                    name: signal [12822,12828]
                trailer [12828,12860]
                    arglist [12829,12859]
                        atom_expr [12829,12843]
                            name: signal [12829,12835]
                            trailer [12835,12843]
                                name: SIGTERM [12836,12843]
                        operator: , [12843,12844]
                        atom_expr [12845,12859]
                            name: signal [12845,12851]
                            trailer [12851,12859]
                                name: SIG_DFL [12852,12859]
        simple_stmt [12873,12919]
            atom_expr [12873,12918]
                name: signal [12873,12879]
                trailer [12879,12886]
                    name: signal [12880,12886]
                trailer [12886,12918]
                    arglist [12887,12917]
                        atom_expr [12887,12901]
                            name: signal [12887,12893]
                            trailer [12893,12901]
                                name: SIGUSR2 [12894,12901]
                        operator: , [12901,12902]
                        atom_expr [12903,12917]
                            name: signal [12903,12909]
                            trailer [12909,12917]
                                name: SIG_DFL [12910,12917]
===
delete-node
---
arglist [12938,12988]
===
