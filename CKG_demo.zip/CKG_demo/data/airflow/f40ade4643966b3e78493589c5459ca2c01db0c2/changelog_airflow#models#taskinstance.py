===
match
---
name: TaskInstance [77599,77611]
name: TaskInstance [77611,77623]
===
match
---
atom_expr [63766,63780]
atom_expr [63778,63792]
===
match
---
name: dag_id [46117,46123]
name: dag_id [46117,46123]
===
match
---
operator: } [46151,46152]
operator: } [46151,46152]
===
match
---
name: Variable [2116,2124]
name: Variable [2116,2124]
===
match
---
simple_stmt [4167,4193]
simple_stmt [4167,4193]
===
match
---
name: timezone [46219,46227]
name: timezone [46219,46227]
===
match
---
if_stmt [47980,48684]
if_stmt [47980,48684]
===
match
---
trailer [70743,70769]
trailer [70755,70781]
===
match
---
trailer [52998,53006]
trailer [52998,53006]
===
match
---
name: _CURRENT_CONTEXT [3687,3703]
name: _CURRENT_CONTEXT [3687,3703]
===
match
---
name: pendulum [59473,59481]
name: pendulum [59485,59493]
===
match
---
name: handle_failure [45428,45442]
name: handle_failure [45428,45442]
===
match
---
name: dagrun [8077,8083]
name: dagrun [8077,8083]
===
match
---
name: ignore_all_deps [52192,52207]
name: ignore_all_deps [52192,52207]
===
match
---
atom_expr [6143,6151]
atom_expr [6143,6151]
===
match
---
trailer [11231,11240]
trailer [11231,11240]
===
match
---
operator: == [25911,25913]
operator: == [25911,25913]
===
match
---
atom_expr [79109,79121]
atom_expr [79121,79133]
===
match
---
name: utils [2824,2829]
name: utils [2824,2829]
===
match
---
name: warnings [892,900]
name: warnings [892,900]
===
match
---
atom_expr [50446,50479]
atom_expr [50446,50479]
===
match
---
classdef [60956,61885]
classdef [60968,61897]
===
match
---
name: execution_date [11599,11613]
name: execution_date [11599,11613]
===
match
---
operator: = [32828,32829]
operator: = [32828,32829]
===
match
---
name: debug [24695,24700]
name: debug [24695,24700]
===
match
---
operator: = [13537,13538]
operator: = [13537,13538]
===
match
---
name: state [56277,56282]
name: state [56289,56294]
===
match
---
trailer [12124,12126]
trailer [12124,12126]
===
match
---
atom_expr [68932,69145]
atom_expr [68944,69157]
===
match
---
operator: , [41472,41473]
operator: , [41472,41473]
===
match
---
trailer [59950,59961]
trailer [59962,59973]
===
match
---
trailer [22678,22687]
trailer [22678,22687]
===
match
---
trailer [41532,41547]
trailer [41532,41547]
===
match
---
argument [48920,48933]
argument [48920,48933]
===
match
---
name: property [79202,79210]
name: property [79214,79222]
===
match
---
name: self [24984,24988]
name: self [24984,24988]
===
match
---
param [51908,51932]
param [51908,51932]
===
match
---
string: """         The start date from property previous_ti_success.          :param state: If passed, it only take into account instances of a specific state.         :param session: SQLAlchemy ORM Session         """ [30748,30959]
string: """         The start date from property previous_ti_success.          :param state: If passed, it only take into account instances of a specific state.         :param session: SQLAlchemy ORM Session         """ [30748,30959]
===
match
---
trailer [57918,57924]
trailer [57930,57936]
===
match
---
operator: } [47130,47131]
operator: } [47130,47131]
===
match
---
name: Dict [1046,1050]
name: Dict [1046,1050]
===
match
---
name: timezone [53606,53614]
name: timezone [53606,53614]
===
match
---
operator: = [69633,69634]
operator: = [69645,69646]
===
match
---
expr_stmt [35645,35690]
expr_stmt [35645,35690]
===
match
---
param [51833,51863]
param [51833,51863]
===
match
---
name: ds_nodash [59858,59867]
name: ds_nodash [59870,59879]
===
match
---
name: set_current_context [48733,48752]
name: set_current_context [48733,48752]
===
match
---
trailer [11092,11101]
trailer [11092,11101]
===
match
---
trailer [4646,4662]
trailer [4646,4662]
===
match
---
name: RUNNING [5343,5350]
name: RUNNING [5343,5350]
===
match
---
name: TaskInstance [80104,80116]
name: TaskInstance [80116,80128]
===
match
---
argument [39217,39262]
argument [39217,39262]
===
match
---
name: self [32666,32670]
name: self [32666,32670]
===
match
---
trailer [23435,23439]
trailer [23435,23439]
===
match
---
argument [72426,72446]
argument [72438,72458]
===
match
---
string: 'dag_run' [62739,62748]
string: 'dag_run' [62751,62760]
===
match
---
trailer [7071,7079]
trailer [7071,7079]
===
match
---
trailer [30555,30579]
trailer [30555,30579]
===
match
---
expr_stmt [22180,22393]
expr_stmt [22180,22393]
===
match
---
trailer [70821,70826]
trailer [70833,70838]
===
match
---
name: session [56922,56929]
name: session [56934,56941]
===
match
---
name: try_number [69848,69858]
name: try_number [69860,69870]
===
match
---
operator: = [30501,30502]
operator: = [30501,30502]
===
match
---
decorator [79610,79620]
decorator [79622,79632]
===
match
---
name: test_mode [41734,41743]
name: test_mode [41734,41743]
===
match
---
simple_stmt [19054,19092]
simple_stmt [19054,19092]
===
match
---
suite [5768,6131]
suite [5768,6131]
===
match
---
simple_stmt [31339,31487]
simple_stmt [31339,31487]
===
match
---
suite [54758,54824]
suite [54758,54836]
===
match
---
expr_stmt [69955,69995]
expr_stmt [69967,70007]
===
match
---
expr_stmt [13374,13396]
expr_stmt [13374,13396]
===
match
---
operator: , [31739,31740]
operator: , [31739,31740]
===
match
---
suite [36932,42216]
suite [36932,42216]
===
match
---
trailer [41407,41422]
trailer [41407,41422]
===
match
---
operator: * [34578,34579]
operator: * [34578,34579]
===
match
---
name: self [51180,51184]
name: self [51180,51184]
===
match
---
argument [66945,66969]
argument [66957,66981]
===
match
---
name: Any [60769,60772]
name: Any [60781,60784]
===
match
---
name: dep [33450,33453]
name: dep [33450,33453]
===
match
---
simple_stmt [50900,50917]
simple_stmt [50900,50917]
===
match
---
param [14852,14856]
param [14852,14856]
===
match
---
operator: = [69842,69843]
operator: = [69854,69855]
===
match
---
atom_expr [31801,31814]
atom_expr [31801,31814]
===
match
---
trailer [25347,25353]
trailer [25347,25353]
===
match
---
trailer [8556,8560]
trailer [8556,8560]
===
match
---
decorators [42858,42901]
decorators [42858,42901]
===
match
---
trailer [48300,48501]
trailer [48300,48501]
===
match
---
atom_expr [60775,60814]
atom_expr [60787,60826]
===
match
---
suite [80739,80787]
suite [80751,80799]
===
match
---
argument [66731,66749]
argument [66743,66761]
===
match
---
param [80058,80063]
param [80070,80075]
===
match
---
name: debug [30977,30982]
name: debug [30977,30982]
===
match
---
name: relationship [1400,1412]
name: relationship [1400,1412]
===
match
---
operator: = [59645,59646]
operator: = [59657,59658]
===
match
---
atom_expr [25509,25522]
atom_expr [25509,25522]
===
match
---
name: mark_success_url [20031,20047]
name: mark_success_url [20031,20047]
===
match
---
operator: , [24576,24577]
operator: , [24576,24577]
===
match
---
import_name [871,884]
import_name [871,884]
===
match
---
trailer [10757,10791]
trailer [10757,10791]
===
match
---
simple_stmt [80494,80711]
simple_stmt [80506,80723]
===
match
---
operator: , [28195,28196]
operator: , [28195,28196]
===
match
---
suite [66506,67432]
suite [66518,67444]
===
match
---
simple_stmt [66169,66197]
simple_stmt [66181,66209]
===
match
---
operator: , [18840,18841]
operator: , [18840,18841]
===
match
---
name: ignore_ti_state [52343,52358]
name: ignore_ti_state [52343,52358]
===
match
---
string: 'ti_state_lkp' [11664,11678]
string: 'ti_state_lkp' [11664,11678]
===
match
---
operator: = [51999,52000]
operator: = [51999,52000]
===
match
---
operator: = [23081,23082]
operator: = [23081,23082]
===
match
---
trailer [5247,5294]
trailer [5247,5294]
===
match
---
name: update [68908,68914]
name: update [68920,68926]
===
match
---
atom_expr [77046,77073]
atom_expr [77058,77085]
===
match
---
name: execution_date [12683,12697]
name: execution_date [12683,12697]
===
match
---
string: 'prev_execution_date' [63243,63264]
string: 'prev_execution_date' [63255,63276]
===
match
---
name: self [13056,13060]
name: self [13056,13060]
===
match
---
trailer [10942,10971]
trailer [10942,10971]
===
match
---
name: DateTime [31320,31328]
name: DateTime [31320,31328]
===
match
---
name: task_ids [7139,7147]
name: task_ids [7139,7147]
===
match
---
name: dr [36287,36289]
name: dr [36287,36289]
===
match
---
name: bool [36614,36618]
name: bool [36614,36618]
===
match
---
operator: = [38806,38807]
operator: = [38806,38807]
===
match
---
param [30094,30118]
param [30094,30118]
===
match
---
atom_expr [69331,69393]
atom_expr [69343,69405]
===
match
---
name: self [25941,25945]
name: self [25941,25945]
===
match
---
fstring [65800,65857]
fstring [65812,65869]
===
match
---
atom_expr [75831,75843]
atom_expr [75843,75855]
===
match
---
name: self [56510,56514]
name: self [56522,56526]
===
match
---
operator: } [46123,46124]
operator: } [46123,46124]
===
match
---
name: self [42128,42132]
name: self [42128,42132]
===
match
---
name: schedule [27900,27908]
name: schedule [27900,27908]
===
match
---
trailer [72438,72446]
trailer [72450,72458]
===
match
---
annassign [78821,78836]
annassign [78833,78848]
===
match
---
trailer [50864,50870]
trailer [50864,50870]
===
match
---
name: render [70274,70280]
name: render [70286,70292]
===
match
---
atom_expr [38539,38552]
atom_expr [38539,38552]
===
match
---
trailer [35497,35501]
trailer [35497,35501]
===
match
---
name: Index [11785,11790]
name: Index [11785,11790]
===
match
---
name: var [60591,60594]
name: var [60603,60606]
===
match
---
operator: , [63084,63085]
operator: , [63096,63097]
===
match
---
operator: } [20005,20006]
operator: } [20005,20006]
===
match
---
operator: = [28708,28709]
operator: = [28708,28709]
===
match
---
name: DagRun [8413,8419]
name: DagRun [8413,8419]
===
match
---
trailer [46639,46661]
trailer [46639,46661]
===
match
---
name: Context [50290,50297]
name: Context [50290,50297]
===
match
---
decorated [56731,57102]
decorated [56743,57114]
===
match
---
expr_stmt [23186,23207]
expr_stmt [23186,23207]
===
match
---
simple_stmt [14107,14131]
simple_stmt [14107,14131]
===
match
---
name: dag [57615,57618]
name: dag [57627,57630]
===
match
---
funcdef [46703,46911]
funcdef [46703,46911]
===
match
---
name: property [14819,14827]
name: property [14819,14827]
===
match
---
name: cmd [18917,18920]
name: cmd [18917,18920]
===
match
---
operator: + [35720,35721]
operator: + [35720,35721]
===
match
---
name: self [24749,24753]
name: self [24749,24753]
===
match
---
name: signal [46927,46933]
name: signal [46927,46933]
===
match
---
simple_stmt [41556,41578]
simple_stmt [41556,41578]
===
match
---
atom_expr [57207,57224]
atom_expr [57219,57236]
===
match
---
name: str [27068,27071]
name: str [27068,27071]
===
match
---
name: execution_date [74625,74639]
name: execution_date [74637,74651]
===
match
---
operator: @ [14262,14263]
operator: @ [14262,14263]
===
match
---
operator: == [36362,36364]
operator: == [36362,36364]
===
match
---
trailer [7608,7611]
trailer [7608,7611]
===
match
---
name: int [79730,79733]
name: int [79742,79745]
===
match
---
trailer [30480,30510]
trailer [30480,30510]
===
match
---
atom_expr [46750,46811]
atom_expr [46750,46811]
===
match
---
funcdef [60704,60947]
funcdef [60716,60959]
===
match
---
operator: @ [79778,79779]
operator: @ [79790,79791]
===
match
---
name: key [50187,50190]
name: key [50187,50190]
===
match
---
simple_stmt [69172,69309]
simple_stmt [69184,69321]
===
match
---
atom_expr [65668,65694]
atom_expr [65680,65706]
===
match
---
operator: @ [79678,79679]
operator: @ [79690,79691]
===
match
---
name: self [44349,44353]
name: self [44349,44353]
===
match
---
name: session [58044,58051]
name: session [58056,58063]
===
match
---
number: 1 [69079,69080]
number: 1 [69091,69092]
===
match
---
name: try_number [7057,7067]
name: try_number [7057,7067]
===
match
---
trailer [14070,14076]
trailer [14070,14076]
===
match
---
name: log [52558,52561]
name: log [52558,52561]
===
match
---
simple_stmt [22902,22935]
simple_stmt [22902,22935]
===
match
---
string: """         Pull XComs that optionally meet certain criteria.          The default value for `key` limits the search to XComs         that were returned by other tasks (as opposed to those that were pushed         manually). To remove this filter, pass key=None (or any desired value).          If a single task_id string is provided, the result is the value of the         most recent matching XCom from that task_id. If multiple task_ids are         provided, a tuple of matching values is returned. None is returned         whenever no matches are found.          :param key: A key for the XCom. If provided, only XComs with matching             keys will be returned. The default key is 'return_value', also             available as a constant XCOM_RETURN_KEY. This key is automatically             given to XComs returned by tasks (as opposed to being pushed             manually). To remove the filter, pass key=None.         :type key: str         :param task_ids: Only XComs from tasks with matching ids will be             pulled. Can pass None to remove the filter.         :type task_ids: str or iterable of strings (representing task_ids)         :param dag_id: If provided, only pulls XComs from this DAG.             If None (default), the DAG of the calling task is used.         :type dag_id: str         :param include_prior_dates: If False, only XComs from the current             execution_date are returned. If True, XComs from previous dates             are returned as well.         :type include_prior_dates: bool         :param session: Sqlalchemy ORM Session         :type session: Session         """ [72874,74500]
string: """         Pull XComs that optionally meet certain criteria.          The default value for `key` limits the search to XComs         that were returned by other tasks (as opposed to those that were pushed         manually). To remove this filter, pass key=None (or any desired value).          If a single task_id string is provided, the result is the value of the         most recent matching XCom from that task_id. If multiple task_ids are         provided, a tuple of matching values is returned. None is returned         whenever no matches are found.          :param key: A key for the XCom. If provided, only XComs with matching             keys will be returned. The default key is 'return_value', also             available as a constant XCOM_RETURN_KEY. This key is automatically             given to XComs returned by tasks (as opposed to being pushed             manually). To remove the filter, pass key=None.         :type key: str         :param task_ids: Only XComs from tasks with matching ids will be             pulled. Can pass None to remove the filter.         :type task_ids: str or iterable of strings (representing task_ids)         :param dag_id: If provided, only pulls XComs from this DAG.             If None (default), the DAG of the calling task is used.         :type dag_id: str         :param include_prior_dates: If False, only XComs from the current             execution_date are returned. If True, XComs from previous dates             are returned as well.         :type include_prior_dates: bool         :param session: Sqlalchemy ORM Session         :type session: Session         """ [72886,74512]
===
match
---
name: BooleanClauseList [76188,76205]
name: BooleanClauseList [76200,76217]
===
match
---
string: 'outlets' [63098,63107]
string: 'outlets' [63110,63119]
===
match
---
operator: = [24070,24071]
operator: = [24070,24071]
===
match
---
atom_expr [53305,53328]
atom_expr [53305,53328]
===
match
---
expr_stmt [27433,27470]
expr_stmt [27433,27470]
===
match
---
fstring_expr [59857,59868]
fstring_expr [59869,59880]
===
match
---
arglist [33128,33163]
arglist [33128,33163]
===
match
---
operator: = [33336,33337]
operator: = [33336,33337]
===
match
---
trailer [48019,48021]
trailer [48019,48021]
===
match
---
name: self [28988,28992]
name: self [28988,28992]
===
match
---
simple_stmt [3214,3234]
simple_stmt [3214,3234]
===
match
---
comparison [76885,76903]
comparison [76897,76915]
===
match
---
operator: , [39447,39448]
operator: , [39447,39448]
===
match
---
string: '<br>' [67782,67788]
string: '<br>' [67794,67800]
===
match
---
and_test [15526,15547]
and_test [15526,15547]
===
match
---
name: cmd [18982,18985]
name: cmd [18982,18985]
===
match
---
string: """Set TI duration""" [70995,71016]
string: """Set TI duration""" [71007,71028]
===
match
---
trailer [6306,6310]
trailer [6306,6310]
===
match
---
name: rendered_value [64735,64749]
name: rendered_value [64747,64761]
===
match
---
argument [66983,67010]
argument [66995,67022]
===
match
---
name: utils [2781,2786]
name: utils [2781,2786]
===
match
---
name: set_duration [70959,70971]
name: set_duration [70971,70983]
===
match
---
name: dag_id [74554,74560]
name: dag_id [74566,74572]
===
match
---
decorator [79778,79788]
decorator [79790,79800]
===
match
---
trailer [30397,30403]
trailer [30397,30403]
===
match
---
name: self [12267,12271]
name: self [12267,12271]
===
match
---
name: log [2620,2623]
name: log [2620,2623]
===
match
---
name: pool [23110,23114]
name: pool [23110,23114]
===
match
---
fstring_expr [44260,44274]
fstring_expr [44260,44274]
===
match
---
atom_expr [26782,26809]
atom_expr [26782,26809]
===
match
---
name: warning [41180,41187]
name: warning [41180,41187]
===
match
---
name: bool [36660,36664]
name: bool [36660,36664]
===
match
---
name: end_date [71033,71041]
name: end_date [71045,71053]
===
match
---
name: timeout [2967,2974]
name: timeout [2967,2974]
===
match
---
name: ts [63918,63920]
name: ts [63930,63932]
===
match
---
argument [48465,48478]
argument [48465,48478]
===
match
---
name: executor_config [24121,24136]
name: executor_config [24121,24136]
===
match
---
operator: = [39035,39036]
operator: = [39035,39036]
===
match
---
name: merge [25649,25654]
name: merge [25649,25654]
===
match
---
expr_stmt [6177,6207]
expr_stmt [6177,6207]
===
match
---
name: self [25567,25571]
name: self [25567,25571]
===
match
---
atom_expr [12230,12258]
atom_expr [12230,12258]
===
match
---
tfpdef [42246,42255]
tfpdef [42246,42255]
===
match
---
name: AirflowSensorTimeout [45191,45211]
name: AirflowSensorTimeout [45191,45211]
===
match
---
name: State [44930,44935]
name: State [44930,44935]
===
match
---
name: task [66416,66420]
name: task [66428,66432]
===
match
---
arith_expr [25584,25615]
arith_expr [25584,25615]
===
match
---
name: end_date [78522,78530]
name: end_date [78534,78542]
===
match
---
operator: , [43121,43122]
operator: , [43121,43122]
===
match
---
name: or_ [77552,77555]
name: or_ [77564,77567]
===
match
---
trailer [58103,58115]
trailer [58115,58127]
===
match
---
name: job_ids [5436,5443]
name: job_ids [5436,5443]
===
match
---
operator: = [65666,65667]
operator: = [65678,65679]
===
match
---
operator: , [51931,51932]
operator: , [51931,51932]
===
match
---
name: ds_nodash [62806,62815]
name: ds_nodash [62818,62827]
===
match
---
name: operator_helpers [2720,2736]
name: operator_helpers [2720,2736]
===
match
---
name: overwrite_params_with_dag_run_conf [60021,60055]
name: overwrite_params_with_dag_run_conf [60033,60067]
===
match
---
operator: , [16860,16861]
operator: , [16860,16861]
===
match
---
return_stmt [77265,77473]
return_stmt [77277,77485]
===
match
---
name: dag_model [11824,11833]
name: dag_model [11824,11833]
===
match
---
trailer [41702,41711]
trailer [41702,41711]
===
match
---
atom_expr [4774,4800]
atom_expr [4774,4800]
===
match
---
name: List [1062,1066]
name: List [1062,1066]
===
match
---
name: kubernetes [3005,3015]
name: kubernetes [3005,3015]
===
match
---
name: hostname [44060,44068]
name: hostname [44060,44068]
===
match
---
atom [19226,19251]
atom [19226,19251]
===
match
---
operator: = [54678,54679]
operator: = [54678,54679]
===
match
---
funcdef [14832,14933]
funcdef [14832,14933]
===
match
---
simple_stmt [56206,56246]
simple_stmt [56218,56258]
===
match
---
simple_stmt [70311,70365]
simple_stmt [70323,70377]
===
match
---
suite [79502,79535]
suite [79514,79547]
===
match
---
operator: , [30676,30677]
operator: , [30676,30677]
===
match
---
operator: , [67010,67011]
operator: , [67022,67023]
===
match
---
arglist [70906,70948]
arglist [70918,70960]
===
match
---
name: TaskInstance [22200,22212]
name: TaskInstance [22200,22212]
===
match
---
name: job_id [19082,19088]
name: job_id [19082,19088]
===
match
---
operator: , [18873,18874]
operator: , [18873,18874]
===
match
---
operator: , [23518,23519]
operator: , [23518,23519]
===
match
---
name: non_requeueable_dep_context [39007,39034]
name: non_requeueable_dep_context [39007,39034]
===
match
---
expr_stmt [57527,57538]
expr_stmt [57539,57550]
===
match
---
simple_stmt [32848,33053]
simple_stmt [32848,33053]
===
match
---
expr_stmt [23911,23944]
expr_stmt [23911,23944]
===
match
---
atom_expr [51544,51564]
atom_expr [51544,51564]
===
match
---
trailer [77058,77073]
trailer [77070,77085]
===
match
---
atom_expr [24590,24609]
atom_expr [24590,24609]
===
match
---
atom_expr [23105,23114]
atom_expr [23105,23114]
===
match
---
argument [40505,40550]
argument [40505,40550]
===
match
---
not_test [56654,56667]
not_test [56666,56679]
===
match
---
trailer [77133,77157]
trailer [77145,77169]
===
match
---
name: self [42686,42690]
name: self [42686,42690]
===
match
---
trailer [20899,21088]
trailer [20899,21088]
===
match
---
trailer [12745,12749]
trailer [12745,12749]
===
match
---
name: self [71092,71096]
name: self [71104,71108]
===
match
---
string: 'run_id' [63613,63621]
string: 'run_id' [63625,63633]
===
match
---
name: task_id [66776,66783]
name: task_id [66788,66795]
===
match
---
if_stmt [54704,55116]
if_stmt [54704,55128]
===
match
---
simple_stmt [58889,58960]
simple_stmt [58901,58972]
===
match
---
trailer [30982,31016]
trailer [30982,31016]
===
match
---
name: session [52903,52910]
name: session [52903,52910]
===
match
---
param [49106,49118]
param [49106,49118]
===
match
---
atom_expr [51949,51962]
atom_expr [51949,51962]
===
match
---
trailer [25513,25522]
trailer [25513,25522]
===
match
---
name: self [45423,45427]
name: self [45423,45427]
===
match
---
suite [60830,60947]
suite [60842,60959]
===
match
---
name: execution_date [71354,71368]
name: execution_date [71366,71380]
===
match
---
dotted_name [2915,2934]
dotted_name [2915,2934]
===
match
---
name: _try_number [53820,53831]
name: _try_number [53820,53831]
===
match
---
tfpdef [16494,16512]
tfpdef [16494,16512]
===
match
---
trailer [8253,8268]
trailer [8253,8268]
===
match
---
name: property [31248,31256]
name: property [31248,31256]
===
match
---
decorator [19731,19741]
decorator [19731,19741]
===
match
---
operator: , [77458,77459]
operator: , [77470,77471]
===
match
---
name: run [51651,51654]
name: run [51651,51654]
===
match
---
name: session [75690,75697]
name: session [75702,75709]
===
match
---
term [38816,38824]
term [38816,38824]
===
match
---
operator: = [78096,78097]
operator: = [78108,78109]
===
match
---
name: queued_dttm [23336,23347]
name: queued_dttm [23336,23347]
===
match
---
param [51678,51699]
param [51678,51699]
===
match
---
operator: @ [30585,30586]
operator: @ [30585,30586]
===
match
---
expr_stmt [8608,8632]
expr_stmt [8608,8632]
===
match
---
operator: , [46476,46477]
operator: , [46476,46477]
===
match
---
simple_stmt [8884,8909]
simple_stmt [8884,8909]
===
match
---
expr_stmt [38407,38433]
expr_stmt [38407,38433]
===
match
---
name: context [47187,47194]
name: context [47187,47194]
===
match
---
operator: { [19957,19958]
operator: { [19957,19958]
===
match
---
name: hr_line_break [41408,41421]
name: hr_line_break [41408,41421]
===
match
---
trailer [67775,67789]
trailer [67787,67801]
===
match
---
name: _Variable__NO_DEFAULT_SENTINEL [60784,60814]
name: _Variable__NO_DEFAULT_SENTINEL [60796,60826]
===
match
---
argument [61837,61860]
argument [61849,61872]
===
match
---
expr_stmt [27900,27934]
expr_stmt [27900,27934]
===
match
---
operator: = [31737,31738]
operator: = [31737,31738]
===
match
---
operator: = [24114,24115]
operator: = [24114,24115]
===
match
---
atom_expr [44055,44068]
atom_expr [44055,44068]
===
match
---
trailer [59421,59429]
trailer [59433,59441]
===
match
---
operator: -> [20527,20529]
operator: -> [20527,20529]
===
match
---
name: dep_context [40723,40734]
name: dep_context [40723,40734]
===
match
---
name: dates_by_dag_id [8132,8147]
name: dates_by_dag_id [8132,8147]
===
match
---
trailer [64802,64819]
trailer [64814,64831]
===
match
---
operator: = [30695,30696]
operator: = [30695,30696]
===
match
---
operator: , [19076,19077]
operator: , [19076,19077]
===
match
---
argument [52372,52397]
argument [52372,52397]
===
match
---
atom_expr [58207,58219]
atom_expr [58219,58231]
===
match
---
argument [70281,70296]
argument [70293,70308]
===
match
---
trailer [22652,22661]
trailer [22652,22661]
===
match
---
name: self [9078,9082]
name: self [9078,9082]
===
match
---
name: dt [28192,28194]
name: dt [28192,28194]
===
match
---
atom_expr [14080,14093]
atom_expr [14080,14093]
===
match
---
operator: -> [79570,79572]
operator: -> [79582,79584]
===
match
---
trailer [8509,8511]
trailer [8509,8511]
===
match
---
operator: = [52775,52776]
operator: = [52775,52776]
===
match
---
name: TaskInstance [77421,77433]
name: TaskInstance [77433,77445]
===
match
---
operator: @ [80009,80010]
operator: @ [80021,80022]
===
match
---
name: execution_date [24618,24632]
name: execution_date [24618,24632]
===
match
---
operator: , [4783,4784]
operator: , [4783,4784]
===
match
---
atom_expr [16840,16853]
atom_expr [16840,16853]
===
match
---
trailer [41175,41179]
trailer [41175,41179]
===
match
---
name: _executor_config [78626,78642]
name: _executor_config [78638,78654]
===
match
---
atom_expr [77373,77389]
atom_expr [77385,77401]
===
match
---
name: render [70392,70398]
name: render [70404,70410]
===
match
---
trailer [59592,59601]
trailer [59604,59613]
===
match
---
number: 1 [58217,58218]
number: 1 [58229,58230]
===
match
---
simple_stmt [57447,57474]
simple_stmt [57459,57486]
===
match
---
argument [66763,66783]
argument [66775,66795]
===
match
---
name: try_number [5721,5731]
name: try_number [5721,5731]
===
match
---
trailer [12719,12759]
trailer [12719,12759]
===
match
---
comparison [25463,25495]
comparison [25463,25495]
===
match
---
name: test_mode [13379,13388]
name: test_mode [13379,13388]
===
match
---
operator: = [51924,51925]
operator: = [51924,51925]
===
match
---
name: task [51418,51422]
name: task [51418,51422]
===
match
---
operator: , [1344,1345]
operator: , [1344,1345]
===
match
---
trailer [21465,21469]
trailer [21465,21469]
===
match
---
operator: == [5334,5336]
operator: == [5334,5336]
===
match
---
param [31873,31890]
param [31873,31890]
===
match
---
decorator [42858,42875]
decorator [42858,42875]
===
match
---
suite [70629,70950]
suite [70641,70962]
===
match
---
decorator [60678,60692]
decorator [60690,60704]
===
match
---
name: error_file [54505,54515]
name: error_file [54505,54515]
===
match
---
simple_stmt [80752,80787]
simple_stmt [80764,80799]
===
match
---
name: defaultdict [925,936]
name: defaultdict [925,936]
===
match
---
name: session [74794,74801]
name: session [74806,74813]
===
match
---
operator: , [11959,11960]
operator: , [11959,11960]
===
match
---
expr_stmt [28654,28717]
expr_stmt [28654,28717]
===
match
---
name: self [26813,26817]
name: self [26813,26817]
===
match
---
if_stmt [68685,70535]
if_stmt [68697,70547]
===
match
---
atom_expr [81099,81125]
atom_expr [81111,81137]
===
match
---
name: end_date [25589,25597]
name: end_date [25589,25597]
===
match
---
operator: = [33256,33257]
operator: = [33256,33257]
===
match
---
string: """         Copy common attributes from the given task.          :param task: The task object to copy from         :type task: airflow.models.BaseOperator         :param pool_override: Use the pool_override instead of task's pool         :type pool_override: str         """ [23549,23823]
string: """         Copy common attributes from the given task.          :param task: The task object to copy from         :type task: airflow.models.BaseOperator         :param pool_override: Use the pool_override instead of task's pool         :type pool_override: str         """ [23549,23823]
===
match
---
atom_expr [59573,59618]
atom_expr [59585,59630]
===
match
---
atom_expr [12169,12181]
atom_expr [12169,12181]
===
match
---
arglist [69740,69909]
arglist [69752,69921]
===
match
---
atom_expr [79911,79920]
atom_expr [79923,79932]
===
match
---
trailer [12271,12276]
trailer [12271,12276]
===
match
---
name: log [1963,1966]
name: log [1963,1966]
===
match
---
name: next_try_number [14836,14851]
name: next_try_number [14836,14851]
===
match
---
name: t [76947,76948]
name: t [76959,76960]
===
match
---
simple_stmt [47472,47552]
simple_stmt [47472,47552]
===
match
---
name: SHUTDOWN [7663,7671]
name: SHUTDOWN [7663,7671]
===
match
---
trailer [5342,5350]
trailer [5342,5350]
===
match
---
name: task_copy [50113,50122]
name: task_copy [50113,50122]
===
match
---
trailer [74624,74639]
trailer [74636,74651]
===
match
---
name: try_number [41085,41095]
name: try_number [41085,41095]
===
match
---
import_from [57411,57437]
import_from [57423,57449]
===
match
---
name: dag_id [77190,77196]
name: dag_id [77202,77208]
===
match
---
string: "airflow.task" [12297,12311]
string: "airflow.task" [12297,12311]
===
match
---
param [16805,16823]
param [16805,16823]
===
match
---
operator: , [27050,27051]
operator: , [27050,27051]
===
match
---
name: task [50912,50916]
name: task [50912,50916]
===
match
---
name: incr [55290,55294]
name: incr [55302,55306]
===
match
---
arith_expr [58185,58219]
arith_expr [58197,58231]
===
match
---
string: 'yesterday_ds_nodash' [64235,64256]
string: 'yesterday_ds_nodash' [64247,64268]
===
match
---
name: start_date [10605,10615]
name: start_date [10605,10615]
===
match
---
atom_expr [79751,79772]
atom_expr [79763,79784]
===
match
---
name: bool [42993,42997]
name: bool [42993,42997]
===
match
---
atom_expr [12077,12090]
atom_expr [12077,12090]
===
match
---
name: int [78877,78880]
name: int [78889,78892]
===
match
---
name: dag_id [47104,47110]
name: dag_id [47104,47110]
===
match
---
decorator [26996,27013]
decorator [26996,27013]
===
match
---
operator: = [54455,54456]
operator: = [54455,54456]
===
match
---
atom_expr [46126,46138]
atom_expr [46126,46138]
===
match
---
expr_stmt [5488,5508]
expr_stmt [5488,5508]
===
match
---
parameters [60383,60389]
parameters [60395,60401]
===
match
---
name: ti [77974,77976]
name: ti [77986,77988]
===
match
---
trailer [19842,19852]
trailer [19842,19852]
===
match
---
name: from_string [69341,69352]
name: from_string [69353,69364]
===
match
---
operator: = [20836,20837]
operator: = [20836,20837]
===
match
---
operator: ** [11346,11348]
operator: ** [11346,11348]
===
match
---
name: query [75698,75703]
name: query [75710,75715]
===
match
---
subscriptlist [72673,72691]
subscriptlist [72685,72703]
===
match
---
atom_expr [19006,19020]
atom_expr [19006,19020]
===
match
---
name: _log_state [42394,42404]
name: _log_state [42394,42404]
===
match
---
name: self [41286,41290]
name: self [41286,41290]
===
match
---
argument [50208,50220]
argument [50208,50220]
===
match
---
name: jinja_context [68894,68907]
name: jinja_context [68906,68919]
===
match
---
name: dag_id [72460,72466]
name: dag_id [72472,72478]
===
match
---
trailer [80877,80879]
trailer [80889,80891]
===
match
---
trailer [40125,40136]
trailer [40125,40136]
===
match
---
trailer [12819,12830]
trailer [12819,12830]
===
match
---
name: self [31867,31871]
name: self [31867,31871]
===
match
---
name: Index [11729,11734]
name: Index [11729,11734]
===
match
---
name: get_template_context [57293,57313]
name: get_template_context [57305,57325]
===
match
---
argument [72558,72573]
argument [72570,72585]
===
match
---
argument [49851,49866]
argument [49851,49866]
===
match
---
import_from [81005,81045]
import_from [81017,81057]
===
match
---
argument [72401,72412]
argument [72413,72424]
===
match
---
and_test [71028,71061]
and_test [71040,71073]
===
match
---
name: try_number [78566,78576]
name: try_number [78578,78588]
===
match
---
operator: { [47664,47665]
operator: { [47664,47665]
===
match
---
name: AirflowException [64910,64926]
name: AirflowException [64922,64938]
===
match
---
import_from [7509,7550]
import_from [7509,7550]
===
match
---
name: include_prior_dates [72784,72803]
name: include_prior_dates [72796,72815]
===
match
---
atom_expr [33777,33794]
atom_expr [33777,33794]
===
match
---
name: NONE [40803,40807]
name: NONE [40803,40807]
===
match
---
trailer [64716,64721]
trailer [64728,64733]
===
match
---
return_stmt [76532,76543]
return_stmt [76544,76555]
===
match
---
trailer [33521,33525]
trailer [33521,33525]
===
match
---
operator: = [78602,78603]
operator: = [78614,78615]
===
match
---
trailer [76493,76498]
trailer [76505,76510]
===
match
---
name: session [30094,30101]
name: session [30094,30101]
===
match
---
expr_stmt [78585,78612]
expr_stmt [78597,78624]
===
match
---
power [34581,34607]
power [34581,34607]
===
match
---
arglist [70817,70855]
arglist [70829,70867]
===
match
---
trailer [66817,66844]
trailer [66829,66856]
===
match
---
param [26014,26019]
param [26014,26019]
===
match
---
string: "%s" [54873,54877]
string: "%s" [54885,54889]
===
match
---
name: provide_session [57269,57284]
name: provide_session [57281,57296]
===
match
---
atom_expr [55490,55503]
atom_expr [55502,55515]
===
match
---
operator: , [39150,39151]
operator: , [39150,39151]
===
match
---
atom_expr [71028,71041]
atom_expr [71040,71053]
===
match
---
trailer [67252,67283]
trailer [67264,67295]
===
match
---
trailer [19491,19498]
trailer [19491,19498]
===
match
---
if_stmt [7489,7672]
if_stmt [7489,7672]
===
match
---
import_from [2511,2553]
import_from [2511,2553]
===
match
---
parameters [33238,33276]
parameters [33238,33276]
===
match
---
trailer [44810,44815]
trailer [44810,44815]
===
match
---
name: math [34546,34550]
name: math [34546,34550]
===
match
---
funcdef [13601,14167]
funcdef [13601,14167]
===
match
---
trailer [58079,58094]
trailer [58091,58106]
===
match
---
name: getuser [13016,13023]
name: getuser [13016,13023]
===
match
---
trailer [51136,51142]
trailer [51136,51142]
===
match
---
operator: { [20355,20356]
operator: { [20355,20356]
===
match
---
name: email_on_failure [56229,56245]
name: email_on_failure [56241,56257]
===
match
---
name: priority_weight_total [23981,24002]
name: priority_weight_total [23981,24002]
===
match
---
name: lock_for_update [21670,21685]
name: lock_for_update [21670,21685]
===
match
---
name: query [75166,75171]
name: query [75178,75183]
===
match
---
operator: , [64733,64734]
operator: , [64745,64746]
===
match
---
trailer [53755,53760]
trailer [53755,53760]
===
match
---
trailer [15484,15489]
trailer [15484,15489]
===
match
---
trailer [42349,42366]
trailer [42349,42366]
===
match
---
operator: = [39439,39440]
operator: = [39439,39440]
===
match
---
trailer [20111,20144]
trailer [20111,20144]
===
match
---
name: mark_success [38856,38868]
name: mark_success [38856,38868]
===
match
---
trailer [44397,44438]
trailer [44397,44438]
===
match
---
operator: , [22163,22164]
operator: , [22163,22164]
===
match
---
return_stmt [33173,33184]
return_stmt [33173,33184]
===
match
---
name: Integer [11093,11100]
name: Integer [11093,11100]
===
match
---
operator: , [61340,61341]
operator: , [61352,61353]
===
match
---
trailer [41667,41673]
trailer [41667,41673]
===
match
---
trailer [5267,5293]
trailer [5267,5293]
===
match
---
name: self [80571,80575]
name: self [80583,80587]
===
match
---
name: REQUEUEABLE_DEPS [39085,39101]
name: REQUEUEABLE_DEPS [39085,39101]
===
match
---
operator: @ [79379,79380]
operator: @ [79391,79392]
===
match
---
name: dr [8585,8587]
name: dr [8585,8587]
===
match
---
operator: , [48439,48440]
operator: , [48439,48440]
===
match
---
name: session [36306,36313]
name: session [36306,36313]
===
match
---
atom_expr [41785,41801]
atom_expr [41785,41801]
===
match
---
expr_stmt [32821,32834]
expr_stmt [32821,32834]
===
match
---
arglist [78908,78929]
arglist [78920,78941]
===
match
---
trailer [35661,35666]
trailer [35661,35666]
===
match
---
name: property [79056,79064]
name: property [79068,79076]
===
match
---
trailer [78365,78373]
trailer [78377,78385]
===
match
---
name: self [61274,61278]
name: self [61286,61290]
===
match
---
suite [48022,48684]
suite [48022,48684]
===
match
---
name: kube_config [66650,66661]
name: kube_config [66662,66673]
===
match
---
operator: = [10561,10562]
operator: = [10561,10562]
===
match
---
name: ti_key_str [63729,63739]
name: ti_key_str [63741,63751]
===
match
---
if_stmt [50401,50480]
if_stmt [50401,50480]
===
match
---
suite [65631,65695]
suite [65643,65707]
===
match
---
atom_expr [78470,78483]
atom_expr [78482,78495]
===
match
---
param [15186,15196]
param [15186,15196]
===
match
---
name: self [14232,14236]
name: self [14232,14236]
===
match
---
atom_expr [41474,41489]
atom_expr [41474,41489]
===
match
---
string: 'core' [59962,59968]
string: 'core' [59974,59980]
===
match
---
atom_expr [72298,72317]
atom_expr [72310,72329]
===
match
---
atom_expr [8150,8166]
atom_expr [8150,8166]
===
match
---
name: jinja2 [69227,69233]
name: jinja2 [69239,69245]
===
match
---
name: _execution_date [80684,80699]
name: _execution_date [80696,80711]
===
match
---
expr_stmt [52963,53037]
expr_stmt [52963,53037]
===
match
---
comp_op [28533,28539]
comp_op [28533,28539]
===
match
---
operator: , [14214,14215]
operator: , [14214,14215]
===
match
---
decorator [80009,80026]
decorator [80021,80038]
===
match
---
parameters [14957,15265]
parameters [14957,15265]
===
match
---
suite [5351,5462]
suite [5351,5462]
===
match
---
operator: , [47275,47276]
operator: , [47275,47276]
===
match
---
operator: = [36290,36291]
operator: = [36290,36291]
===
match
---
name: Column [10688,10694]
name: Column [10688,10694]
===
match
---
operator: = [32627,32628]
operator: = [32627,32628]
===
match
---
operator: , [63739,63740]
operator: , [63751,63752]
===
match
---
atom_expr [51438,51460]
atom_expr [51438,51460]
===
match
---
suite [25016,25661]
suite [25016,25661]
===
match
---
param [64327,64331]
param [64339,64343]
===
match
---
simple_stmt [58739,58781]
simple_stmt [58751,58793]
===
match
---
trailer [11123,11137]
trailer [11123,11137]
===
match
---
expr_stmt [76653,76682]
expr_stmt [76665,76694]
===
match
---
name: BaseJob [80993,81000]
name: BaseJob [81005,81012]
===
match
---
operator: = [52910,52911]
operator: = [52910,52911]
===
match
---
operator: -> [72858,72860]
operator: -> [72870,72872]
===
match
---
trailer [56820,56836]
trailer [56832,56848]
===
match
---
suite [3626,3649]
suite [3626,3649]
===
match
---
trailer [8232,8239]
trailer [8232,8239]
===
match
---
operator: , [72850,72851]
operator: , [72862,72863]
===
match
---
name: TaskReschedule [53719,53733]
name: TaskReschedule [53719,53733]
===
match
---
trailer [56716,56723]
trailer [56728,56735]
===
match
---
atom_expr [46862,46910]
atom_expr [46862,46910]
===
match
---
name: task [53279,53283]
name: task [53279,53283]
===
match
---
operator: , [1349,1350]
operator: , [1349,1350]
===
match
---
trailer [76140,76173]
trailer [76152,76185]
===
match
---
name: utils [2524,2529]
name: utils [2524,2529]
===
match
---
atom [20838,21117]
atom [20838,21117]
===
match
---
string: "--pickle" [18994,19004]
string: "--pickle" [18994,19004]
===
match
---
argument [11969,11982]
argument [11969,11982]
===
match
---
trailer [33030,33037]
trailer [33030,33037]
===
match
---
name: str [43068,43071]
name: str [43068,43071]
===
match
---
arglist [24879,24942]
arglist [24879,24942]
===
match
---
trailer [59481,59490]
trailer [59493,59502]
===
match
---
name: execution_date [28050,28064]
name: execution_date [28050,28064]
===
match
---
operator: = [79041,79042]
operator: = [79053,79054]
===
match
---
trailer [75819,75827]
trailer [75831,75839]
===
match
---
trailer [47568,47572]
trailer [47568,47572]
===
match
---
simple_stmt [27385,27405]
simple_stmt [27385,27405]
===
match
---
string: "airflow" [18831,18840]
string: "airflow" [18831,18840]
===
match
---
tfpdef [42411,42424]
tfpdef [42411,42424]
===
match
---
funcdef [78258,79050]
funcdef [78270,79062]
===
match
---
name: execution_date [24911,24925]
name: execution_date [24911,24925]
===
match
---
name: email [2530,2535]
name: email [2530,2535]
===
match
---
name: State [39944,39949]
name: State [39944,39949]
===
match
---
atom_expr [75105,75135]
atom_expr [75117,75147]
===
match
---
operator: == [26958,26960]
operator: == [26958,26960]
===
match
---
trailer [78496,78506]
trailer [78508,78518]
===
match
---
atom_expr [52089,52520]
atom_expr [52089,52520]
===
match
---
name: bool [36739,36743]
name: bool [36739,36743]
===
match
---
suite [13622,14167]
suite [13622,14167]
===
match
---
name: task_id [79145,79152]
name: task_id [79157,79164]
===
match
---
parameters [20047,20053]
parameters [20047,20053]
===
match
---
atom_expr [43888,43902]
atom_expr [43888,43902]
===
match
---
name: task_id [5545,5552]
name: task_id [5545,5552]
===
match
---
name: dag_id [6265,6271]
name: dag_id [6265,6271]
===
match
---
atom_expr [55348,55384]
atom_expr [55360,55396]
===
match
---
decorator [61568,61582]
decorator [61580,61594]
===
match
---
operator: = [23331,23332]
operator: = [23331,23332]
===
match
---
name: dag [15474,15477]
name: dag [15474,15477]
===
match
---
name: count [75709,75714]
name: count [75721,75726]
===
match
---
name: QUEUED [8704,8710]
name: QUEUED [8704,8710]
===
match
---
name: Iterable [72678,72686]
name: Iterable [72690,72698]
===
match
---
trailer [42453,42852]
trailer [42453,42852]
===
match
---
name: strftime [59088,59096]
name: strftime [59100,59108]
===
match
---
name: self [23069,23073]
name: self [23069,23073]
===
match
---
name: ignore_ti_state [52327,52342]
name: ignore_ti_state [52327,52342]
===
match
---
suite [42111,42196]
suite [42111,42196]
===
match
---
name: self [38539,38543]
name: self [38539,38543]
===
match
---
name: models [1991,1997]
name: models [1991,1997]
===
match
---
trailer [74553,74560]
trailer [74565,74572]
===
match
---
operator: , [16822,16823]
operator: , [16822,16823]
===
match
---
param [50281,50298]
param [50281,50298]
===
match
---
name: log [46755,46758]
name: log [46755,46758]
===
match
---
name: add [55356,55359]
name: add [55368,55371]
===
match
---
name: datetime [71379,71387]
name: datetime [71391,71399]
===
match
---
param [49100,49105]
param [49100,49105]
===
match
---
if_stmt [54726,54886]
if_stmt [54726,54898]
===
match
---
simple_stmt [44833,44850]
simple_stmt [44833,44850]
===
match
---
name: job_id [51941,51947]
name: job_id [51941,51947]
===
match
---
string: 'Try {{try_number}} out of {{max_tries + 1}}<br>' [68376,68425]
string: 'Try {{try_number}} out of {{max_tries + 1}}<br>' [68388,68437]
===
match
---
name: info [47573,47577]
name: info [47573,47577]
===
match
---
operator: == [80568,80570]
operator: == [80580,80582]
===
match
---
trailer [46878,46910]
trailer [46878,46910]
===
match
---
simple_stmt [25712,25828]
simple_stmt [25712,25828]
===
match
---
string: "--ignore-dependencies" [19227,19250]
string: "--ignore-dependencies" [19227,19250]
===
match
---
operator: = [72694,72695]
operator: = [72706,72707]
===
match
---
name: airflow [2481,2488]
name: airflow [2481,2488]
===
match
---
name: execution_date [12439,12453]
name: execution_date [12439,12453]
===
match
---
trailer [29159,29164]
trailer [29159,29164]
===
match
---
trailer [24165,24175]
trailer [24165,24175]
===
match
---
arglist [6092,6129]
arglist [6092,6129]
===
match
---
name: airflow [66554,66561]
name: airflow [66566,66573]
===
match
---
trailer [31188,31199]
trailer [31188,31199]
===
match
---
name: in_ [7080,7083]
name: in_ [7080,7083]
===
match
---
atom_expr [26602,26911]
atom_expr [26602,26911]
===
match
---
string: '\n' [67776,67780]
string: '\n' [67788,67792]
===
match
---
name: job_id [52803,52809]
name: job_id [52803,52809]
===
match
---
trailer [81111,81125]
trailer [81123,81137]
===
match
---
expr_stmt [78492,78530]
expr_stmt [78504,78542]
===
match
---
operator: = [21151,21152]
operator: = [21151,21152]
===
match
---
name: incr [55226,55230]
name: incr [55238,55242]
===
match
---
simple_stmt [26920,26937]
simple_stmt [26920,26937]
===
match
---
suite [67484,70591]
suite [67496,70603]
===
match
---
fstring_expr [15652,15666]
fstring_expr [15652,15666]
===
match
---
operator: @ [65285,65286]
operator: @ [65297,65298]
===
match
---
trailer [6108,6129]
trailer [6108,6129]
===
match
---
operator: -> [21693,21695]
operator: -> [21693,21695]
===
match
---
name: utils [2961,2966]
name: utils [2961,2966]
===
match
---
atom_expr [36838,36851]
atom_expr [36838,36851]
===
match
---
name: __tablename__ [10364,10377]
name: __tablename__ [10364,10377]
===
match
---
operator: = [52475,52476]
operator: = [52475,52476]
===
match
---
name: hr_line_break [38792,38805]
name: hr_line_break [38792,38805]
===
match
---
name: set_current_context [3364,3383]
name: set_current_context [3364,3383]
===
match
---
trailer [53888,53897]
trailer [53888,53897]
===
match
---
param [14967,14972]
param [14967,14972]
===
match
---
atom_expr [22674,22687]
atom_expr [22674,22687]
===
match
---
decorator [24181,24198]
decorator [24181,24198]
===
match
---
operator: = [23241,23242]
operator: = [23241,23242]
===
match
---
funcdef [50584,51621]
funcdef [50584,51621]
===
match
---
suite [59321,59512]
suite [59333,59524]
===
match
---
param [66229,66262]
param [66241,66274]
===
match
---
name: ConnectionAccessor [64159,64177]
name: ConnectionAccessor [64171,64189]
===
match
---
parameters [60620,60626]
parameters [60632,60638]
===
match
---
name: environ [47746,47753]
name: environ [47746,47753]
===
match
---
atom_expr [71108,71123]
atom_expr [71120,71135]
===
match
---
name: kube_config [67253,67264]
name: kube_config [67265,67276]
===
match
---
argument [7035,7169]
argument [7035,7169]
===
match
---
decorator [28958,28968]
decorator [28958,28968]
===
match
---
trailer [22246,22253]
trailer [22246,22253]
===
match
---
name: Optional [36874,36882]
name: Optional [36874,36882]
===
match
---
import_from [2658,2700]
import_from [2658,2700]
===
match
---
parameters [4689,4818]
parameters [4689,4818]
===
match
---
operator: , [70507,70508]
operator: , [70519,70520]
===
match
---
suite [19368,19405]
suite [19368,19405]
===
match
---
name: log [44614,44617]
name: log [44614,44617]
===
match
---
operator: = [67043,67044]
operator: = [67055,67056]
===
match
---
operator: = [60773,60774]
operator: = [60785,60786]
===
match
---
trailer [57665,57672]
trailer [57677,57684]
===
match
---
operator: @ [13402,13403]
operator: @ [13402,13403]
===
match
---
trailer [69689,69696]
trailer [69701,69708]
===
match
---
operator: , [75974,75975]
operator: , [75986,75987]
===
match
---
name: from_string [69431,69442]
name: from_string [69443,69454]
===
match
---
trailer [14085,14093]
trailer [14085,14093]
===
match
---
name: task_id [5501,5508]
name: task_id [5501,5508]
===
match
---
string: 'ti' [68730,68734]
string: 'ti' [68742,68746]
===
match
---
name: execution_date [58134,58148]
name: execution_date [58146,58160]
===
match
---
operator: , [57034,57035]
operator: , [57046,57047]
===
match
---
operator: = [59412,59413]
operator: = [59424,59425]
===
match
---
name: session [26602,26609]
name: session [26602,26609]
===
match
---
name: dag_id [9313,9319]
name: dag_id [9313,9319]
===
match
---
try_stmt [49724,49965]
try_stmt [49724,49965]
===
match
---
trailer [11575,11614]
trailer [11575,11614]
===
match
---
name: context [50986,50993]
name: context [50986,50993]
===
match
---
operator: = [58759,58760]
operator: = [58771,58772]
===
match
---
operator: , [52430,52431]
operator: , [52430,52431]
===
match
---
atom_expr [33891,33902]
atom_expr [33891,33902]
===
match
---
name: TemplateAssertionError [1221,1243]
name: TemplateAssertionError [1221,1243]
===
match
---
name: result [75089,75095]
name: result [75101,75107]
===
match
---
atom_expr [48648,48683]
atom_expr [48648,48683]
===
match
---
name: state [21219,21224]
name: state [21219,21224]
===
match
---
name: self [66738,66742]
name: self [66750,66754]
===
match
---
string: '' [59549,59551]
string: '' [59561,59563]
===
match
---
simple_stmt [53079,53120]
simple_stmt [53079,53120]
===
match
---
name: local [16694,16699]
name: local [16694,16699]
===
match
---
name: get_previous_start_date [31771,31794]
name: get_previous_start_date [31771,31794]
===
match
---
name: task [12184,12188]
name: task [12184,12188]
===
match
---
name: self [78995,78999]
name: self [79007,79011]
===
match
---
if_stmt [19467,19517]
if_stmt [19467,19517]
===
match
---
simple_stmt [11301,11365]
simple_stmt [11301,11365]
===
match
---
simple_stmt [60579,60595]
simple_stmt [60591,60607]
===
match
---
name: airflow [2362,2369]
name: airflow [2362,2369]
===
match
---
trailer [25254,25261]
trailer [25254,25261]
===
match
---
name: session [8299,8306]
name: session [8299,8306]
===
match
---
name: task [46112,46116]
name: task [46112,46116]
===
match
---
trailer [63510,63599]
trailer [63522,63611]
===
match
---
name: state [28527,28532]
name: state [28527,28532]
===
match
---
string: "worker-config" [67118,67133]
string: "worker-config" [67130,67145]
===
match
---
name: query [24476,24481]
name: query [24476,24481]
===
match
---
name: e [44847,44848]
name: e [44847,44848]
===
match
---
name: in_ [77369,77372]
name: in_ [77381,77384]
===
match
---
operator: , [42162,42163]
operator: , [42162,42163]
===
match
---
name: log [42133,42136]
name: log [42133,42136]
===
match
---
suite [77834,77999]
suite [77846,78011]
===
match
---
operator: = [13067,13068]
operator: = [13067,13068]
===
match
---
name: stacklevel [29375,29385]
name: stacklevel [29375,29385]
===
match
---
trailer [23007,23016]
trailer [23007,23016]
===
match
---
trailer [69233,69250]
trailer [69245,69262]
===
match
---
name: commit [39501,39507]
name: commit [39501,39507]
===
match
---
string: "%s dependency '%s' PASSED: %s, %s" [33553,33588]
string: "%s dependency '%s' PASSED: %s, %s" [33553,33588]
===
match
---
name: _try_number [10737,10748]
name: _try_number [10737,10748]
===
match
---
name: session [32799,32806]
name: session [32799,32806]
===
match
---
trailer [77129,77133]
trailer [77141,77145]
===
match
---
operator: = [74619,74620]
operator: = [74631,74632]
===
match
---
funcdef [9632,9771]
funcdef [9632,9771]
===
match
---
suite [64781,64822]
suite [64793,64834]
===
match
---
operator: , [8411,8412]
operator: , [8411,8412]
===
match
---
with_stmt [49745,49868]
with_stmt [49745,49868]
===
match
---
name: last_dagrun [28871,28882]
name: last_dagrun [28871,28882]
===
match
---
parameters [72624,72857]
parameters [72636,72869]
===
match
---
suite [75442,75495]
suite [75454,75507]
===
match
---
name: XCom [24482,24486]
name: XCom [24482,24486]
===
match
---
trailer [55289,55294]
trailer [55301,55306]
===
match
---
return_stmt [14789,14812]
return_stmt [14789,14812]
===
match
---
operator: -> [31299,31301]
operator: -> [31299,31301]
===
match
---
simple_stmt [59175,59236]
simple_stmt [59187,59248]
===
match
---
atom_expr [22590,22605]
atom_expr [22590,22605]
===
match
---
atom_expr [60586,60594]
atom_expr [60598,60606]
===
match
---
atom_expr [58264,58321]
atom_expr [58276,58333]
===
match
---
operator: = [72466,72467]
operator: = [72478,72479]
===
match
---
operator: , [21073,21074]
operator: , [21073,21074]
===
match
---
fstring_expr [65853,65856]
fstring_expr [65865,65868]
===
match
---
arglist [44439,44452]
arglist [44439,44452]
===
match
---
name: dag_id [76897,76903]
name: dag_id [76909,76915]
===
match
---
atom_expr [22440,22469]
atom_expr [22440,22469]
===
match
---
name: prev_execution_date [59344,59363]
name: prev_execution_date [59356,59375]
===
match
---
name: sha1 [34708,34712]
name: sha1 [34708,34712]
===
match
---
atom_expr [15816,16363]
atom_expr [15816,16363]
===
match
---
operator: = [6152,6153]
operator: = [6152,6153]
===
match
---
trailer [66175,66182]
trailer [66187,66194]
===
match
---
decorator [49046,49063]
decorator [49046,49063]
===
match
---
name: pool [19510,19514]
name: pool [19510,19514]
===
match
---
name: self [55150,55154]
name: self [55162,55166]
===
match
---
name: str [72727,72730]
name: str [72739,72742]
===
match
---
name: session [27462,27469]
name: session [27462,27469]
===
match
---
operator: = [5716,5717]
operator: = [5716,5717]
===
match
---
name: start_date [25605,25615]
name: start_date [25605,25615]
===
match
---
atom_expr [75382,75421]
atom_expr [75394,75433]
===
match
---
param [70972,70976]
param [70984,70988]
===
match
---
decorator [20468,20485]
decorator [20468,20485]
===
match
---
atom_expr [56224,56245]
atom_expr [56236,56257]
===
match
---
atom_expr [70906,70921]
atom_expr [70918,70933]
===
match
---
atom_expr [26718,26768]
atom_expr [26718,26768]
===
match
---
name: iso [18783,18786]
name: iso [18783,18786]
===
match
---
trailer [70069,70083]
trailer [70081,70095]
===
match
---
name: self [78304,78308]
name: self [78316,78320]
===
match
---
simple_stmt [45914,45920]
simple_stmt [45914,45920]
===
match
---
trailer [48187,48214]
trailer [48187,48214]
===
match
---
operator: = [67357,67358]
operator: = [67369,67370]
===
match
---
suite [38658,38712]
suite [38658,38712]
===
match
---
funcdef [75949,76079]
funcdef [75961,76091]
===
match
---
trailer [79755,79772]
trailer [79767,79784]
===
match
---
name: pickle [4174,4180]
name: pickle [4174,4180]
===
match
---
funcdef [25680,25964]
funcdef [25680,25964]
===
match
---
argument [31727,31739]
argument [31727,31739]
===
match
---
atom_expr [19823,19854]
atom_expr [19823,19854]
===
match
---
suite [49500,50244]
suite [49500,50244]
===
match
---
atom_expr [46341,46362]
atom_expr [46341,46362]
===
match
---
expr_stmt [53590,53623]
expr_stmt [53590,53623]
===
match
---
operator: = [10987,10988]
operator: = [10987,10988]
===
match
---
name: quote [19817,19822]
name: quote [19817,19822]
===
match
---
suite [76519,76544]
suite [76531,76556]
===
match
---
trailer [59961,60002]
trailer [59973,60014]
===
match
---
name: expected_state [3721,3735]
name: expected_state [3721,3735]
===
match
---
atom_expr [4635,4662]
atom_expr [4635,4662]
===
match
---
operator: = [19873,19874]
operator: = [19873,19874]
===
match
---
decorated [33190,33833]
decorated [33190,33833]
===
match
---
operator: -> [3980,3982]
operator: -> [3980,3982]
===
match
---
trailer [40888,41154]
trailer [40888,41154]
===
match
---
suite [64887,65280]
suite [64899,65292]
===
match
---
name: key [79866,79869]
name: key [79878,79881]
===
match
---
name: dates_by_dag_id [8488,8503]
name: dates_by_dag_id [8488,8503]
===
match
---
arglist [33471,33497]
arglist [33471,33497]
===
match
---
name: t [76885,76886]
name: t [76897,76898]
===
match
---
dictorsetmaker [68730,68740]
dictorsetmaker [68742,68752]
===
match
---
arglist [15859,16353]
arglist [15859,16353]
===
match
---
simple_stmt [9530,9613]
simple_stmt [9530,9613]
===
match
---
tfpdef [42946,42964]
tfpdef [42946,42964]
===
match
---
suite [79341,79374]
suite [79353,79386]
===
match
---
funcdef [16387,19726]
funcdef [16387,19726]
===
match
---
simple_stmt [35018,35068]
simple_stmt [35018,35068]
===
match
---
trailer [78999,79006]
trailer [79011,79018]
===
match
---
name: execution_date [12794,12808]
name: execution_date [12794,12808]
===
match
---
operator: = [10806,10807]
operator: = [10806,10807]
===
match
---
name: drs [8279,8282]
name: drs [8279,8282]
===
match
---
name: session [52015,52022]
name: session [52015,52022]
===
match
---
name: net [2677,2680]
name: net [2677,2680]
===
match
---
name: int [79498,79501]
name: int [79510,79513]
===
match
---
trailer [47711,47713]
trailer [47711,47713]
===
match
---
operator: , [65562,65563]
operator: , [65574,65575]
===
match
---
annassign [78642,78668]
annassign [78654,78680]
===
match
---
param [4695,4699]
param [4695,4699]
===
match
---
decorated [8938,9125]
decorated [8938,9125]
===
match
---
name: dag_id [34785,34791]
name: dag_id [34785,34791]
===
match
---
name: dep_context [33486,33497]
name: dep_context [33486,33497]
===
match
---
if_stmt [5364,5462]
if_stmt [5364,5462]
===
match
---
simple_stmt [21710,22104]
simple_stmt [21710,22104]
===
match
---
name: self [23360,23364]
name: self [23360,23364]
===
match
---
if_stmt [75434,75495]
if_stmt [75446,75507]
===
match
---
name: provide_session [24182,24197]
name: provide_session [24182,24197]
===
match
---
simple_stmt [44224,44277]
simple_stmt [44224,44277]
===
match
---
name: refresh_from_task [38355,38372]
name: refresh_from_task [38355,38372]
===
match
---
atom_expr [31222,31240]
atom_expr [31222,31240]
===
match
---
string: 'TaskInstance' [27123,27137]
string: 'TaskInstance' [27123,27137]
===
match
---
tfpdef [71316,71324]
tfpdef [71328,71336]
===
match
---
name: UtcDateTime [2898,2909]
name: UtcDateTime [2898,2909]
===
match
---
name: pool [78832,78836]
name: pool [78844,78848]
===
match
---
name: ti_key_str [59811,59821]
name: ti_key_str [59823,59833]
===
match
---
trailer [4460,4471]
trailer [4460,4471]
===
match
---
param [79489,79493]
param [79501,79505]
===
match
---
atom [20224,20462]
atom [20224,20462]
===
match
---
name: Column [11086,11092]
name: Column [11086,11092]
===
match
---
name: dep_status [33636,33646]
name: dep_status [33636,33646]
===
match
---
operator: == [22303,22305]
operator: == [22303,22305]
===
match
---
trailer [62721,62725]
trailer [62733,62737]
===
match
---
name: external_trigger [58655,58671]
name: external_trigger [58667,58683]
===
match
---
name: session [27454,27461]
name: session [27454,27461]
===
match
---
operator: , [7257,7258]
operator: , [7257,7258]
===
match
---
trailer [66992,67008]
trailer [67004,67020]
===
match
---
funcdef [56752,57102]
funcdef [56764,57114]
===
match
---
simple_stmt [69406,69489]
simple_stmt [69418,69501]
===
match
---
dotted_name [2311,2338]
dotted_name [2311,2338]
===
match
---
trailer [69660,69662]
trailer [69672,69674]
===
match
---
operator: , [18856,18857]
operator: , [18856,18857]
===
match
---
operator: = [50905,50906]
operator: = [50905,50906]
===
match
---
name: in_ [77933,77936]
name: in_ [77945,77948]
===
match
---
trailer [42633,42639]
trailer [42633,42639]
===
match
---
fstring_end: ' [47140,47141]
fstring_end: ' [47140,47141]
===
match
---
operator: } [75224,75225]
operator: } [75236,75237]
===
match
---
name: job [7564,7567]
name: job [7564,7567]
===
match
---
trailer [78948,78965]
trailer [78960,78977]
===
match
---
name: State [40797,40802]
name: State [40797,40802]
===
match
---
atom_expr [4174,4192]
atom_expr [4174,4192]
===
match
---
name: job_id [44031,44037]
name: job_id [44031,44037]
===
match
---
if_stmt [22403,22513]
if_stmt [22403,22513]
===
match
---
simple_stmt [19132,19174]
simple_stmt [19132,19174]
===
match
---
name: pool_slots [23158,23168]
name: pool_slots [23158,23168]
===
match
---
operator: , [53760,53761]
operator: , [53760,53761]
===
match
---
trailer [35710,35719]
trailer [35710,35719]
===
match
---
trailer [78543,78555]
trailer [78555,78567]
===
match
---
name: lazy_object_proxy [1168,1185]
name: lazy_object_proxy [1168,1185]
===
match
---
atom_expr [24863,24943]
atom_expr [24863,24943]
===
match
---
simple_stmt [41308,41325]
simple_stmt [41308,41325]
===
match
---
name: mark_success [52385,52397]
name: mark_success [52385,52397]
===
match
---
arglist [46345,46361]
arglist [46345,46361]
===
match
---
return_stmt [9759,9770]
return_stmt [9759,9770]
===
match
---
parameters [14209,14222]
parameters [14209,14222]
===
match
---
trailer [47359,47386]
trailer [47359,47386]
===
match
---
name: execution_date [12394,12408]
name: execution_date [12394,12408]
===
match
---
name: dag [27416,27419]
name: dag [27416,27419]
===
match
---
name: self [27438,27442]
name: self [27438,27442]
===
match
---
atom_expr [33385,33401]
atom_expr [33385,33401]
===
match
---
name: warning [40833,40840]
name: warning [40833,40840]
===
match
---
atom_expr [66169,66196]
atom_expr [66181,66208]
===
match
---
if_stmt [75022,75495]
if_stmt [75034,75507]
===
match
---
name: state [28812,28817]
name: state [28812,28817]
===
match
---
number: 256 [10950,10953]
number: 256 [10950,10953]
===
match
---
return_stmt [33866,33957]
return_stmt [33866,33957]
===
match
---
expr_stmt [25231,25263]
expr_stmt [25231,25263]
===
match
---
name: _queue [79836,79842]
name: _queue [79848,79854]
===
match
---
name: task_reschedule [39985,40000]
name: task_reschedule [39985,40000]
===
match
---
arglist [68958,69127]
arglist [68970,69139]
===
match
---
name: replace [59536,59543]
name: replace [59548,59555]
===
match
---
operator: } [47110,47111]
operator: } [47110,47111]
===
match
---
simple_stmt [69676,69942]
simple_stmt [69688,69954]
===
match
---
operator: = [52668,52669]
operator: = [52668,52669]
===
match
---
atom [57492,57494]
atom [57504,57506]
===
match
---
name: fd [4068,4070]
name: fd [4068,4070]
===
match
---
name: params [66169,66175]
name: params [66181,66187]
===
match
---
operator: , [16484,16485]
operator: , [16484,16485]
===
match
---
trailer [20981,20989]
trailer [20981,20989]
===
match
---
funcdef [33838,33958]
funcdef [33838,33958]
===
match
---
operator: = [46682,46683]
operator: = [46682,46683]
===
match
---
suite [79895,79921]
suite [79907,79933]
===
match
---
name: self [63800,63804]
name: self [63812,63816]
===
match
---
name: item [61619,61623]
name: item [61631,61635]
===
match
---
name: refresh_from_db [21634,21649]
name: refresh_from_db [21634,21649]
===
match
---
name: external_executor_id [6180,6200]
name: external_executor_id [6180,6200]
===
match
---
name: pool [15226,15230]
name: pool [15226,15230]
===
match
---
simple_stmt [36212,36278]
simple_stmt [36212,36278]
===
match
---
atom_expr [70895,70949]
atom_expr [70907,70961]
===
match
---
simple_stmt [30165,30381]
simple_stmt [30165,30381]
===
match
---
name: job_id [5454,5460]
name: job_id [5454,5460]
===
match
---
string: """         Make an XCom available for tasks to pull.          :param key: A key for the XCom         :type key: str         :param value: A value for the XCom. The value is pickled and stored             in the database.         :type value: any picklable object         :param execution_date: if provided, the XCom will not be visible until             this date. This can be used, for example, to send a message to a             task on a future date without it being immediately visible.         :type execution_date: datetime         :param session: Sqlalchemy ORM Session         :type session: Session         """ [71453,72073]
string: """         Make an XCom available for tasks to pull.          :param key: A key for the XCom         :type key: str         :param value: A value for the XCom. The value is pickled and stored             in the database.         :type value: any picklable object         :param execution_date: if provided, the XCom will not be visible until             this date. This can be used, for example, to send a message to a             task on a future date without it being immediately visible.         :type execution_date: datetime         :param session: Sqlalchemy ORM Session         :type session: Session         """ [71465,72085]
===
match
---
trailer [12663,12665]
trailer [12663,12665]
===
match
---
operator: = [58977,58978]
operator: = [58989,58990]
===
match
---
name: _update_ti_state_for_sensing [48653,48681]
name: _update_ti_state_for_sensing [48653,48681]
===
match
---
operator: = [35541,35542]
operator: = [35541,35542]
===
match
---
operator: { [46111,46112]
operator: { [46111,46112]
===
match
---
simple_stmt [10364,10396]
simple_stmt [10364,10396]
===
match
---
name: set_duration [53637,53649]
name: set_duration [53637,53649]
===
match
---
name: job_id [19034,19040]
name: job_id [19034,19040]
===
match
---
simple_stmt [24468,24653]
simple_stmt [24468,24653]
===
match
---
operator: = [12698,12699]
operator: = [12698,12699]
===
match
---
name: ti [23005,23007]
name: ti [23005,23007]
===
match
---
import_from [2274,2305]
import_from [2274,2305]
===
match
---
name: yesterday_ds [58169,58181]
name: yesterday_ds [58181,58193]
===
match
---
if_stmt [46299,46396]
if_stmt [46299,46396]
===
match
---
trailer [22199,22213]
trailer [22199,22213]
===
match
---
return_stmt [21212,21224]
return_stmt [21212,21224]
===
match
---
name: pendulum [28027,28035]
name: pendulum [28027,28035]
===
match
---
trailer [44539,44547]
trailer [44539,44547]
===
match
---
name: self [13000,13004]
name: self [13000,13004]
===
match
---
name: k [47665,47666]
name: k [47665,47666]
===
match
---
name: Column [11225,11231]
name: Column [11225,11231]
===
match
---
arglist [42030,42092]
arglist [42030,42092]
===
match
---
suite [57345,64289]
suite [57357,64301]
===
match
---
operator: = [16043,16044]
operator: = [16043,16044]
===
match
---
expr_stmt [28228,28240]
expr_stmt [28228,28240]
===
match
---
argument [11992,12006]
argument [11992,12006]
===
match
---
name: dialect [77508,77515]
name: dialect [77520,77527]
===
match
---
name: Optional [30711,30719]
name: Optional [30711,30719]
===
match
---
and_test [50113,50158]
and_test [50113,50158]
===
match
---
fstring_string: = [47667,47668]
fstring_string: = [47667,47668]
===
match
---
name: dag_id [44252,44258]
name: dag_id [44252,44258]
===
match
---
try_stmt [64777,65280]
try_stmt [64789,65292]
===
match
---
name: log [30973,30976]
name: log [30973,30976]
===
match
---
atom_expr [54680,54694]
atom_expr [54680,54694]
===
match
---
trailer [12173,12181]
trailer [12173,12181]
===
match
---
operator: { [59826,59827]
operator: { [59838,59839]
===
match
---
name: str [8859,8862]
name: str [8859,8862]
===
match
---
name: email_for_state [56316,56331]
name: email_for_state [56328,56343]
===
match
---
trailer [66182,66196]
trailer [66194,66208]
===
match
---
dotted_name [2559,2580]
dotted_name [2559,2580]
===
match
---
trailer [7611,7615]
trailer [7611,7615]
===
match
---
trailer [24931,24942]
trailer [24931,24942]
===
match
---
name: get_previous_scheduled_dagrun [28671,28700]
name: get_previous_scheduled_dagrun [28671,28700]
===
match
---
name: self [44862,44866]
name: self [44862,44866]
===
match
---
parameters [60711,60829]
parameters [60723,60841]
===
match
---
operator: , [32789,32790]
operator: , [32789,32790]
===
match
---
name: vals_kv [75061,75068]
name: vals_kv [75073,75080]
===
match
---
atom_expr [57962,57976]
atom_expr [57974,57988]
===
match
---
name: dep_status [32723,32733]
name: dep_status [32723,32733]
===
match
---
trailer [4650,4657]
trailer [4650,4657]
===
match
---
name: operator [23279,23287]
name: operator [23279,23287]
===
match
---
atom_expr [71238,71251]
atom_expr [71250,71263]
===
match
---
simple_stmt [72154,72349]
simple_stmt [72166,72361]
===
match
---
atom_expr [63379,63432]
atom_expr [63391,63444]
===
match
---
param [79080,79084]
param [79092,79096]
===
match
---
trailer [6813,7385]
trailer [6813,7385]
===
match
---
trailer [41179,41187]
trailer [41179,41187]
===
match
---
comp_op [51230,51236]
comp_op [51230,51236]
===
match
---
operator: , [70346,70347]
operator: , [70358,70359]
===
match
---
name: ignore_depends_on_past [52244,52266]
name: ignore_depends_on_past [52244,52266]
===
match
---
name: dag [58916,58919]
name: dag [58928,58931]
===
match
---
name: execution_date [20117,20131]
name: execution_date [20117,20131]
===
match
---
simple_stmt [857,871]
simple_stmt [857,871]
===
match
---
name: DagRun [36348,36354]
name: DagRun [36348,36354]
===
match
---
trailer [42136,42141]
trailer [42136,42141]
===
match
---
annassign [3276,3296]
annassign [3276,3296]
===
match
---
expr_stmt [23832,23855]
expr_stmt [23832,23855]
===
match
---
simple_stmt [51313,51347]
simple_stmt [51313,51347]
===
match
---
trailer [46833,46841]
trailer [46833,46841]
===
match
---
string: 'mssql' [77524,77531]
string: 'mssql' [77536,77543]
===
match
---
fstring_expr [59841,59855]
fstring_expr [59853,59867]
===
match
---
name: ts [58124,58126]
name: ts [58136,58138]
===
match
---
fstring_string: __ [59839,59841]
fstring_string: __ [59851,59853]
===
match
---
atom_expr [12700,12759]
atom_expr [12700,12759]
===
match
---
string: """Executes Task (optionally with a Timeout) and pushes Xcom results""" [49509,49580]
string: """Executes Task (optionally with a Timeout) and pushes Xcom results""" [49509,49580]
===
match
---
atom_expr [58287,58299]
atom_expr [58299,58311]
===
match
---
simple_stmt [47314,47387]
simple_stmt [47314,47387]
===
match
---
atom_expr [42629,42647]
atom_expr [42629,42647]
===
match
---
argument [57036,57051]
argument [57048,57063]
===
match
---
name: Exception [54409,54418]
name: Exception [54409,54418]
===
match
---
simple_stmt [76483,76499]
simple_stmt [76495,76511]
===
match
---
arglist [9308,9383]
arglist [9308,9383]
===
match
---
return_stmt [27994,28005]
return_stmt [27994,28005]
===
match
---
return_stmt [24856,24943]
return_stmt [24856,24943]
===
match
---
trailer [11663,11719]
trailer [11663,11719]
===
match
---
operator: = [47864,47865]
operator: = [47864,47865]
===
match
---
name: dag_id [66743,66749]
name: dag_id [66755,66761]
===
match
---
decorator [79678,79688]
decorator [79690,79700]
===
match
---
expr_stmt [25509,25554]
expr_stmt [25509,25554]
===
match
---
name: Column [10936,10942]
name: Column [10936,10942]
===
match
---
name: log [30394,30397]
name: log [30394,30397]
===
match
---
name: _run_execute_callback [50253,50274]
name: _run_execute_callback [50253,50274]
===
match
---
name: self [13110,13114]
name: self [13110,13114]
===
match
---
simple_stmt [10864,10896]
simple_stmt [10864,10896]
===
match
---
atom_expr [13110,13129]
atom_expr [13110,13129]
===
match
---
name: task_id_by_key [6247,6261]
name: task_id_by_key [6247,6261]
===
match
---
trailer [62530,62558]
trailer [62542,62570]
===
match
---
operator: , [4698,4699]
operator: , [4698,4699]
===
match
---
name: timetable [27915,27924]
name: timetable [27915,27924]
===
match
---
name: self [79593,79597]
name: self [79605,79609]
===
match
---
trailer [18985,18992]
trailer [18985,18992]
===
match
---
simple_stmt [57061,57102]
simple_stmt [57073,57114]
===
match
---
trailer [47267,47300]
trailer [47267,47300]
===
match
---
dotted_name [2028,2057]
dotted_name [2028,2057]
===
match
---
expr_stmt [55150,55183]
expr_stmt [55162,55195]
===
match
---
operator: , [66969,66970]
operator: , [66981,66982]
===
match
---
operator: , [57585,57586]
operator: , [57597,57598]
===
match
---
name: self [49227,49231]
name: self [49227,49231]
===
match
---
name: dag_id [77012,77018]
name: dag_id [77024,77030]
===
match
---
simple_stmt [41757,41777]
simple_stmt [41757,41777]
===
match
---
number: 80 [38822,38824]
number: 80 [38822,38824]
===
match
---
operator: = [13014,13015]
operator: = [13014,13015]
===
match
---
name: str [16849,16852]
name: str [16849,16852]
===
match
---
atom_expr [79031,79040]
atom_expr [79043,79052]
===
match
---
comparison [77046,77091]
comparison [77058,77103]
===
match
---
atom_expr [30137,30154]
atom_expr [30137,30154]
===
match
---
trailer [80683,80699]
trailer [80695,80711]
===
match
---
operator: @ [54328,54329]
operator: @ [54328,54329]
===
match
---
operator: = [53235,53236]
operator: = [53235,53236]
===
match
---
trailer [77894,77902]
trailer [77906,77914]
===
match
---
name: getLogger [3311,3320]
name: getLogger [3311,3320]
===
match
---
trailer [30728,30737]
trailer [30728,30737]
===
match
---
string: 'execution_date is {}; received {})' [72254,72290]
string: 'execution_date is {}; received {})' [72266,72302]
===
match
---
name: hasattr [78900,78907]
name: hasattr [78912,78919]
===
match
---
param [21267,21279]
param [21267,21279]
===
match
---
trailer [69464,69471]
trailer [69476,69483]
===
match
---
operator: , [15152,15153]
operator: , [15152,15153]
===
match
---
name: urllib [1108,1114]
name: urllib [1108,1114]
===
match
---
atom_expr [9553,9564]
atom_expr [9553,9564]
===
match
---
name: debug [23440,23445]
name: debug [23440,23445]
===
match
---
name: refresh_from_db [38447,38462]
name: refresh_from_db [38447,38462]
===
match
---
suite [50672,51621]
suite [50672,51621]
===
match
---
name: cmd [18824,18827]
name: cmd [18824,18827]
===
match
---
atom_expr [35939,35965]
atom_expr [35939,35965]
===
match
---
trailer [25450,25459]
trailer [25450,25459]
===
match
---
operator: , [42796,42797]
operator: , [42796,42797]
===
match
---
name: XCom [72358,72362]
name: XCom [72370,72374]
===
match
---
operator: = [67117,67118]
operator: = [67129,67130]
===
match
---
operator: @ [20468,20469]
operator: @ [20468,20469]
===
match
---
suite [60390,60423]
suite [60402,60435]
===
match
---
name: activate_dag_runs [7952,7969]
name: activate_dag_runs [7952,7969]
===
match
---
name: Any [78644,78647]
name: Any [78656,78659]
===
match
---
number: 0 [76565,76566]
number: 0 [76577,76578]
===
match
---
atom_expr [25941,25963]
atom_expr [25941,25963]
===
match
---
parameters [61510,61516]
parameters [61522,61528]
===
match
---
if_stmt [72082,72349]
if_stmt [72094,72361]
===
match
---
name: dag_id [6852,6858]
name: dag_id [6852,6858]
===
match
---
name: pool [16317,16321]
name: pool [16317,16321]
===
match
---
expr_stmt [12972,12991]
expr_stmt [12972,12991]
===
match
---
except_clause [48246,48262]
except_clause [48246,48262]
===
match
---
atom_expr [20164,20197]
atom_expr [20164,20197]
===
match
---
name: _try_number [78544,78555]
name: _try_number [78556,78567]
===
match
---
name: SIGTERM [46941,46948]
name: SIGTERM [46941,46948]
===
match
---
atom_expr [8413,8445]
atom_expr [8413,8445]
===
match
---
param [4759,4816]
param [4759,4816]
===
match
---
name: bool [16810,16814]
name: bool [16810,16814]
===
match
---
name: jinja_context [70283,70296]
name: jinja_context [70295,70308]
===
match
---
name: session [28701,28708]
name: session [28701,28708]
===
match
---
operator: , [19004,19005]
operator: , [19004,19005]
===
match
---
name: timezone [12811,12819]
name: timezone [12811,12819]
===
match
---
trailer [41770,41776]
trailer [41770,41776]
===
match
---
operator: = [32798,32799]
operator: = [32798,32799]
===
match
---
operator: , [72638,72639]
operator: , [72650,72651]
===
match
---
name: prev_ti [30556,30563]
name: prev_ti [30556,30563]
===
match
---
comparison [28548,28577]
comparison [28548,28577]
===
match
---
atom_expr [16876,16889]
atom_expr [16876,16889]
===
match
---
simple_stmt [58807,58877]
simple_stmt [58819,58889]
===
match
---
string: """Log URL for TaskInstance""" [19772,19802]
string: """Log URL for TaskInstance""" [19772,19802]
===
match
---
name: passed [33688,33694]
name: passed [33688,33694]
===
match
---
trailer [6851,6858]
trailer [6851,6858]
===
match
---
atom_expr [61400,61408]
atom_expr [61412,61420]
===
match
---
operator: = [27073,27074]
operator: = [27073,27074]
===
match
---
expr_stmt [51259,51296]
expr_stmt [51259,51296]
===
match
---
string: 'ti_successes' [49025,49039]
string: 'ti_successes' [49025,49039]
===
match
---
name: ti [80845,80847]
name: ti [80857,80859]
===
match
---
name: dag_id [77200,77206]
name: dag_id [77212,77218]
===
match
---
string: 'html_content_template' [70399,70422]
string: 'html_content_template' [70411,70434]
===
match
---
simple_stmt [41663,41690]
simple_stmt [41663,41690]
===
match
---
name: datetime [78508,78516]
name: datetime [78520,78528]
===
match
---
operator: = [38522,38523]
operator: = [38522,38523]
===
match
---
decorator [29981,29998]
decorator [29981,29998]
===
match
---
atom_expr [8208,8269]
atom_expr [8208,8269]
===
match
---
string: """         Get datetime of the next retry if the task instance fails. For exponential         backoff, retry_delay is used as base and will be converted to seconds.         """ [34002,34179]
string: """         Get datetime of the next retry if the task instance fails. For exponential         backoff, retry_delay is used as base and will be converted to seconds.         """ [34002,34179]
===
match
---
atom_expr [22234,22253]
atom_expr [22234,22253]
===
match
---
name: state [44922,44927]
name: state [44922,44927]
===
match
---
operator: , [16222,16223]
operator: , [16222,16223]
===
match
---
trailer [34550,34555]
trailer [34550,34555]
===
match
---
annassign [78355,78373]
annassign [78367,78385]
===
match
---
arglist [40711,40765]
arglist [40711,40765]
===
match
---
name: task [12210,12214]
name: task [12210,12214]
===
match
---
string: 'ti' [63794,63798]
string: 'ti' [63806,63810]
===
match
---
argument [30481,30492]
argument [30481,30492]
===
match
---
name: ti [78788,78790]
name: ti [78800,78802]
===
match
---
param [43089,43122]
param [43089,43122]
===
match
---
atom_expr [67303,67334]
atom_expr [67315,67346]
===
match
---
atom_expr [32599,32611]
atom_expr [32599,32611]
===
match
---
try_stmt [62488,62654]
try_stmt [62500,62666]
===
match
---
name: dep_status [32983,32993]
name: dep_status [32983,32993]
===
match
---
name: format [34748,34754]
name: format [34748,34754]
===
match
---
atom_expr [30128,30155]
atom_expr [30128,30155]
===
match
---
suite [60003,60088]
suite [60015,60100]
===
match
---
name: job_id [16285,16291]
name: job_id [16285,16291]
===
match
---
trailer [12115,12124]
trailer [12115,12124]
===
match
---
name: params [59887,59893]
name: params [59899,59905]
===
match
---
operator: , [10954,10955]
operator: , [10954,10955]
===
match
---
operator: = [16316,16317]
operator: = [16316,16317]
===
match
---
atom_expr [53606,53623]
atom_expr [53606,53623]
===
match
---
string: "{}#{}#{}#{}" [34734,34747]
string: "{}#{}#{}#{}" [34734,34747]
===
match
---
tfpdef [62353,62362]
tfpdef [62365,62374]
===
match
---
suite [72865,75495]
suite [72877,75507]
===
match
---
name: execution_date [12044,12058]
name: execution_date [12044,12058]
===
match
---
simple_stmt [45023,45046]
simple_stmt [45023,45046]
===
match
---
arglist [74605,74802]
arglist [74617,74814]
===
match
---
string: 'Submitting %s to sensor service' [49143,49176]
string: 'Submitting %s to sensor service' [49143,49176]
===
match
---
operator: , [55376,55377]
operator: , [55388,55389]
===
match
---
name: error_file [45485,45495]
name: error_file [45485,45495]
===
match
---
param [15072,15101]
param [15072,15101]
===
match
---
decorated [61568,61885]
decorated [61580,61897]
===
match
---
operator: , [72412,72413]
operator: , [72424,72425]
===
match
---
string: 'Airflow alert: {{ti}}' [67817,67840]
string: 'Airflow alert: {{ti}}' [67829,67852]
===
match
---
trailer [20315,20322]
trailer [20315,20322]
===
match
---
string: 'ti_pool' [11735,11744]
string: 'ti_pool' [11735,11744]
===
match
---
arglist [45082,45132]
arglist [45082,45132]
===
match
---
operator: = [72810,72811]
operator: = [72822,72823]
===
match
---
trailer [28049,28064]
trailer [28049,28064]
===
match
---
name: self [71108,71112]
name: self [71120,71124]
===
match
---
name: self [60384,60388]
name: self [60396,60400]
===
match
---
name: self [76032,76036]
name: self [76044,76048]
===
match
---
test [32666,32710]
test [32666,32710]
===
match
---
simple_stmt [38325,38342]
simple_stmt [38325,38342]
===
match
---
atom_expr [46245,46262]
atom_expr [46245,46262]
===
match
---
parameters [13437,13443]
parameters [13437,13443]
===
match
---
operator: , [26018,26019]
operator: , [26018,26019]
===
match
---
classdef [61894,62654]
classdef [61906,62666]
===
match
---
atom_expr [23186,23196]
atom_expr [23186,23196]
===
match
---
name: self [9321,9325]
name: self [9321,9325]
===
match
---
name: ti [78829,78831]
name: ti [78841,78843]
===
match
---
operator: @ [21609,21610]
operator: @ [21609,21610]
===
match
---
name: task_tries [7259,7269]
name: task_tries [7259,7269]
===
match
---
trailer [10659,10672]
trailer [10659,10672]
===
match
---
simple_stmt [53590,53624]
simple_stmt [53590,53624]
===
match
---
name: execution_date [72303,72317]
name: execution_date [72315,72329]
===
match
---
name: state [79558,79563]
name: state [79570,79575]
===
match
---
argument [66858,66884]
argument [66870,66896]
===
match
---
name: self [79712,79716]
name: self [79724,79728]
===
match
---
atom_expr [70806,70856]
atom_expr [70818,70868]
===
match
---
trailer [26516,26521]
trailer [26516,26521]
===
match
---
name: dag_id [57858,57864]
name: dag_id [57870,57876]
===
match
---
param [20048,20052]
param [20048,20052]
===
match
---
name: str [72687,72690]
name: str [72699,72702]
===
match
---
tfpdef [3965,3978]
tfpdef [3965,3978]
===
match
---
operator: = [12001,12002]
operator: = [12001,12002]
===
match
---
atom_expr [9292,9384]
atom_expr [9292,9384]
===
match
---
expr_stmt [59561,59618]
expr_stmt [59573,59630]
===
match
---
simple_stmt [79904,79921]
simple_stmt [79916,79933]
===
match
---
decorator [62302,62316]
decorator [62314,62328]
===
match
---
operator: = [19815,19816]
operator: = [19815,19816]
===
match
---
simple_stmt [32570,32612]
simple_stmt [32570,32612]
===
match
---
param [75562,75569]
param [75574,75581]
===
match
---
name: modded_hash [35018,35029]
name: modded_hash [35018,35029]
===
match
---
operator: , [80062,80063]
operator: , [80074,80075]
===
match
---
expr_stmt [22902,22934]
expr_stmt [22902,22934]
===
match
---
argument [45474,45495]
argument [45474,45495]
===
match
---
trailer [57853,57857]
trailer [57865,57869]
===
match
---
name: self [63686,63690]
name: self [63698,63702]
===
match
---
name: dagrun [57706,57712]
name: dagrun [57718,57724]
===
match
---
atom_expr [40784,40794]
atom_expr [40784,40794]
===
match
---
name: instance [8179,8187]
name: instance [8179,8187]
===
match
---
name: self [9308,9312]
name: self [9308,9312]
===
match
---
name: task [38325,38329]
name: task [38325,38329]
===
match
---
name: ti [6092,6094]
name: ti [6092,6094]
===
match
---
name: iso [19958,19961]
name: iso [19958,19961]
===
match
---
operator: @ [53362,53363]
operator: @ [53362,53363]
===
match
---
arglist [28789,28817]
arglist [28789,28817]
===
match
---
trailer [34200,34205]
trailer [34200,34205]
===
match
---
comparison [77653,77687]
comparison [77665,77699]
===
match
---
name: state [21159,21164]
name: state [21159,21164]
===
match
---
trailer [58029,58031]
trailer [58041,58043]
===
match
---
operator: = [57001,57002]
operator: = [57013,57014]
===
match
---
trailer [69442,69464]
trailer [69454,69476]
===
match
---
argument [52147,52162]
argument [52147,52162]
===
match
---
atom_expr [60016,60087]
atom_expr [60028,60099]
===
match
---
simple_stmt [60133,60358]
simple_stmt [60145,60370]
===
match
---
operator: = [56984,56985]
operator: = [56996,56997]
===
match
---
return_stmt [61469,61484]
return_stmt [61481,61496]
===
match
---
name: State [21538,21543]
name: State [21538,21543]
===
match
---
name: hostname [38544,38552]
name: hostname [38544,38552]
===
match
---
operator: , [26704,26705]
operator: , [26704,26705]
===
match
---
trailer [31039,31055]
trailer [31039,31055]
===
match
---
simple_stmt [20206,20463]
simple_stmt [20206,20463]
===
match
---
simple_stmt [1103,1134]
simple_stmt [1103,1134]
===
match
---
name: e [45443,45444]
name: e [45443,45444]
===
match
---
trailer [59784,59792]
trailer [59796,59804]
===
match
---
trailer [11057,11062]
trailer [11057,11062]
===
match
---
comparison [51205,51241]
comparison [51205,51241]
===
match
---
simple_stmt [54584,54626]
simple_stmt [54584,54626]
===
match
---
name: add [55433,55436]
name: add [55445,55448]
===
match
---
name: dag_run_state [8619,8632]
name: dag_run_state [8619,8632]
===
match
---
string: 'prev_ds_nodash' [63197,63213]
string: 'prev_ds_nodash' [63209,63225]
===
match
---
arglist [45443,45495]
arglist [45443,45495]
===
match
---
simple_stmt [36941,38317]
simple_stmt [36941,38317]
===
match
---
name: prepare_for_execution [46640,46661]
name: prepare_for_execution [46640,46661]
===
match
---
simple_stmt [61274,61290]
simple_stmt [61286,61302]
===
match
---
name: self [9363,9367]
name: self [9363,9367]
===
match
---
name: kubernetes [3127,3137]
name: kubernetes [3127,3137]
===
match
---
trailer [48806,48826]
trailer [48806,48826]
===
match
---
name: task_id [75836,75843]
name: task_id [75848,75855]
===
match
---
atom [19556,19565]
atom [19556,19565]
===
match
---
name: self [14967,14971]
name: self [14967,14971]
===
match
---
name: strftime [58221,58229]
name: strftime [58233,58241]
===
match
---
operator: , [63121,63122]
operator: , [63133,63134]
===
match
---
trailer [77433,77441]
trailer [77445,77453]
===
match
---
string: "Dependencies all met for %s" [33128,33157]
string: "Dependencies all met for %s" [33128,33157]
===
match
---
name: pool [52834,52838]
name: pool [52834,52838]
===
match
---
trailer [4075,4091]
trailer [4075,4091]
===
match
---
name: task [43863,43867]
name: task [43863,43867]
===
match
---
operator: = [28811,28812]
operator: = [28811,28812]
===
match
---
name: Iterable [1052,1060]
name: Iterable [1052,1060]
===
match
---
operator: = [42273,42274]
operator: = [42273,42274]
===
match
---
simple_stmt [50681,50849]
simple_stmt [50681,50849]
===
match
---
atom_expr [74620,74639]
atom_expr [74632,74651]
===
match
---
suite [70034,70298]
suite [70046,70310]
===
match
---
name: prev_ds [63176,63183]
name: prev_ds [63188,63195]
===
match
---
simple_stmt [6797,7386]
simple_stmt [6797,7386]
===
match
---
expr_stmt [38539,38569]
expr_stmt [38539,38569]
===
match
---
operator: -> [79412,79414]
operator: -> [79424,79426]
===
match
---
name: pool [36868,36872]
name: pool [36868,36872]
===
match
---
operator: = [72844,72845]
operator: = [72856,72857]
===
match
---
operator: , [16428,16429]
operator: , [16428,16429]
===
match
---
name: query [80508,80513]
name: query [80520,80525]
===
match
---
trailer [43945,43971]
trailer [43945,43971]
===
match
---
name: str [16447,16450]
name: str [16447,16450]
===
match
---
operator: , [16250,16251]
operator: , [16250,16251]
===
match
---
atom_expr [75402,75412]
atom_expr [75414,75424]
===
match
---
arith_expr [69843,69862]
arith_expr [69855,69874]
===
match
---
trailer [4398,4416]
trailer [4398,4416]
===
match
---
simple_stmt [41219,41256]
simple_stmt [41219,41256]
===
match
---
name: autoescape [69279,69289]
name: autoescape [69291,69301]
===
match
---
trailer [36882,36887]
trailer [36882,36887]
===
match
---
simple_stmt [76553,76568]
simple_stmt [76565,76580]
===
match
---
name: self [23105,23109]
name: self [23105,23109]
===
match
---
trailer [69541,69567]
trailer [69553,69579]
===
match
---
arglist [35475,35521]
arglist [35475,35521]
===
match
---
name: property [9131,9139]
name: property [9131,9139]
===
match
---
classdef [9773,77999]
classdef [9773,78011]
===
match
---
trailer [58654,58671]
trailer [58666,58683]
===
match
---
trailer [22638,22647]
trailer [22638,22647]
===
match
---
import_from [1358,1412]
import_from [1358,1412]
===
match
---
trailer [49306,49313]
trailer [49306,49313]
===
match
---
operator: = [44502,44503]
operator: = [44502,44503]
===
match
---
operator: , [9578,9579]
operator: , [9578,9579]
===
match
---
name: execution_date [62870,62884]
name: execution_date [62882,62896]
===
match
---
atom_expr [7645,7654]
atom_expr [7645,7654]
===
match
---
argument [69740,69759]
argument [69752,69771]
===
match
---
name: self [79751,79755]
name: self [79763,79767]
===
match
---
operator: = [18828,18829]
operator: = [18828,18829]
===
match
---
suite [5554,5751]
suite [5554,5751]
===
match
---
name: exception [56589,56598]
name: exception [56601,56610]
===
match
---
string: 'start_date' [42783,42795]
string: 'start_date' [42783,42795]
===
match
---
tfpdef [30649,30669]
tfpdef [30649,30669]
===
match
---
name: execution_date [59578,59592]
name: execution_date [59590,59604]
===
match
---
atom_expr [79182,79195]
atom_expr [79194,79207]
===
match
---
atom_expr [55192,55211]
atom_expr [55204,55223]
===
match
---
atom_expr [38350,38398]
atom_expr [38350,38398]
===
match
---
suite [40767,41354]
suite [40767,41354]
===
match
---
name: self [42763,42767]
name: self [42763,42767]
===
match
---
expr_stmt [70311,70364]
expr_stmt [70323,70376]
===
match
---
operator: , [64179,64180]
operator: , [64191,64192]
===
match
---
operator: = [22725,22726]
operator: = [22725,22726]
===
match
---
suite [14307,14813]
suite [14307,14813]
===
match
---
simple_stmt [25641,25661]
simple_stmt [25641,25661]
===
match
---
name: RenderedTaskInstanceFields [47314,47340]
name: RenderedTaskInstanceFields [47314,47340]
===
match
---
name: failed [32620,32626]
name: failed [32620,32626]
===
match
---
comparison [75861,75896]
comparison [75873,75908]
===
match
---
name: nullable [10956,10964]
name: nullable [10956,10964]
===
match
---
or_test [72507,72544]
or_test [72519,72556]
===
match
---
name: RenderedTaskInstanceFields [64439,64465]
name: RenderedTaskInstanceFields [64451,64477]
===
match
---
simple_stmt [75580,75627]
simple_stmt [75592,75639]
===
match
---
atom_expr [6106,6129]
atom_expr [6106,6129]
===
match
---
operator: , [7925,7926]
operator: , [7925,7926]
===
match
---
funcdef [24741,24944]
funcdef [24741,24944]
===
match
---
name: DepContext [40389,40399]
name: DepContext [40389,40399]
===
match
---
name: task [12149,12153]
name: task [12149,12153]
===
match
---
atom_expr [70054,70083]
atom_expr [70066,70095]
===
match
---
arglist [52723,52919]
arglist [52723,52919]
===
match
---
simple_stmt [25370,25420]
simple_stmt [25370,25420]
===
match
---
name: mark_success [18891,18903]
name: mark_success [18891,18903]
===
match
---
string: 'ti_dag_state' [11530,11544]
string: 'ti_dag_state' [11530,11544]
===
match
---
import_from [1456,1509]
import_from [1456,1509]
===
match
---
simple_stmt [53225,53266]
simple_stmt [53225,53266]
===
match
---
operator: , [16605,16606]
operator: , [16605,16606]
===
match
---
import_from [2811,2860]
import_from [2811,2860]
===
match
---
name: self [28901,28905]
name: self [28901,28905]
===
match
---
name: execution_date [77722,77736]
name: execution_date [77734,77748]
===
match
---
trailer [56469,56475]
trailer [56481,56487]
===
match
---
simple_stmt [59561,59619]
simple_stmt [59573,59631]
===
match
---
sync_comp_for [76943,76955]
sync_comp_for [76955,76967]
===
match
---
atom_expr [24523,24534]
atom_expr [24523,24534]
===
match
---
name: state [49197,49202]
name: state [49197,49202]
===
match
---
simple_stmt [1943,1978]
simple_stmt [1943,1978]
===
match
---
name: exception_html [69796,69810]
name: exception_html [69808,69822]
===
match
---
atom [34586,34607]
atom [34586,34607]
===
match
---
name: self [33610,33614]
name: self [33610,33614]
===
match
---
name: key [70130,70133]
name: key [70142,70145]
===
match
---
name: task_copy [46623,46632]
name: task_copy [46623,46632]
===
match
---
operator: , [24988,24989]
operator: , [24988,24989]
===
match
---
name: hasattr [57573,57580]
name: hasattr [57585,57592]
===
match
---
name: dag [28548,28551]
name: dag [28548,28551]
===
match
---
name: sanitized_pod [67343,67356]
name: sanitized_pod [67355,67368]
===
match
---
if_stmt [19182,19253]
if_stmt [19182,19253]
===
match
---
expr_stmt [13305,13321]
expr_stmt [13305,13321]
===
match
---
return_stmt [67411,67431]
return_stmt [67423,67443]
===
match
---
funcdef [80030,80848]
funcdef [80042,80860]
===
match
---
fstring [33873,33957]
fstring [33873,33957]
===
match
---
operator: , [44446,44447]
operator: , [44446,44447]
===
match
---
simple_stmt [70377,70446]
simple_stmt [70389,70458]
===
match
---
annassign [78694,78716]
annassign [78706,78728]
===
match
---
trailer [49210,49218]
trailer [49210,49218]
===
match
---
operator: = [50190,50191]
operator: = [50190,50191]
===
match
---
name: pool_override [38379,38392]
name: pool_override [38379,38392]
===
match
---
operator: , [69908,69909]
operator: , [69920,69921]
===
match
---
parameters [57313,57333]
parameters [57325,57345]
===
match
---
and_test [31169,31241]
and_test [31169,31241]
===
match
---
atom_expr [61541,61554]
atom_expr [61553,61566]
===
match
---
suite [50969,51119]
suite [50969,51119]
===
match
---
atom_expr [42016,42093]
atom_expr [42016,42093]
===
match
---
arglist [10490,10540]
arglist [10490,10540]
===
match
---
name: func [75704,75708]
name: func [75716,75720]
===
match
---
name: provide_session [71259,71274]
name: provide_session [71271,71286]
===
match
---
name: _run_finished_callback [57066,57088]
name: _run_finished_callback [57078,57100]
===
match
---
name: var [61550,61553]
name: var [61562,61565]
===
match
---
name: strftime [59364,59372]
name: strftime [59376,59384]
===
match
---
arglist [56599,56640]
arglist [56611,56652]
===
match
---
operator: , [70558,70559]
operator: , [70570,70571]
===
match
---
operator: , [1805,1806]
operator: , [1805,1806]
===
match
---
trailer [22966,22976]
trailer [22966,22976]
===
match
---
name: filter [36341,36347]
name: filter [36341,36347]
===
match
---
tfpdef [16530,16551]
tfpdef [16530,16551]
===
match
---
number: 0 [10789,10790]
number: 0 [10789,10790]
===
match
---
string: ' dag_id=%s, task_id=%s,' [42505,42530]
string: ' dag_id=%s, task_id=%s,' [42505,42530]
===
match
---
trailer [55363,55383]
trailer [55375,55395]
===
match
---
name: pid [23374,23377]
name: pid [23374,23377]
===
match
---
name: str [51994,51997]
name: str [51994,51997]
===
match
---
trailer [64684,64686]
trailer [64696,64698]
===
match
---
name: try_number [41479,41489]
name: try_number [41479,41489]
===
match
---
operator: , [63629,63630]
operator: , [63641,63642]
===
match
---
simple_stmt [52599,52606]
simple_stmt [52599,52606]
===
match
---
name: TaskInstance [80514,80526]
name: TaskInstance [80526,80538]
===
match
---
name: has_dag [12656,12663]
name: has_dag [12656,12663]
===
match
---
name: bool [51811,51815]
name: bool [51811,51815]
===
match
---
trailer [30464,30480]
trailer [30464,30480]
===
match
---
trailer [22718,22724]
trailer [22718,22724]
===
match
---
arglist [6941,7196]
arglist [6941,7196]
===
match
---
simple_stmt [59811,59870]
simple_stmt [59823,59882]
===
match
---
name: stacklevel [31727,31737]
name: stacklevel [31727,31737]
===
match
---
name: dump [4642,4646]
name: dump [4642,4646]
===
match
---
atom [19065,19090]
atom [19065,19090]
===
match
---
string: """Fetch rendered template fields from DB""" [64342,64386]
string: """Fetch rendered template fields from DB""" [64354,64398]
===
match
---
return_stmt [19917,20007]
return_stmt [19917,20007]
===
match
---
name: mark_success [36761,36773]
name: mark_success [36761,36773]
===
match
---
suite [79166,79196]
suite [79178,79208]
===
match
---
trailer [53326,53328]
trailer [53326,53328]
===
match
---
expr_stmt [78539,78576]
expr_stmt [78551,78588]
===
match
---
operator: , [11003,11004]
operator: , [11003,11004]
===
match
---
name: dag_id [74512,74518]
name: dag_id [74524,74530]
===
match
---
atom_expr [13374,13388]
atom_expr [13374,13388]
===
match
---
trailer [77374,77389]
trailer [77386,77401]
===
match
---
name: jinja_env [69955,69964]
name: jinja_env [69967,69976]
===
match
---
operator: , [46485,46486]
operator: , [46485,46486]
===
match
---
comparison [20969,21005]
comparison [20969,21005]
===
match
---
name: pickle_id [15530,15539]
name: pickle_id [15530,15539]
===
match
---
operator: == [24520,24522]
operator: == [24520,24522]
===
match
---
name: conditions [6797,6807]
name: conditions [6797,6807]
===
match
---
name: result [42370,42376]
name: result [42370,42376]
===
match
---
name: reconstructor [13403,13416]
name: reconstructor [13403,13416]
===
match
---
trailer [7410,7420]
trailer [7410,7420]
===
match
---
name: email_alert [70600,70611]
name: email_alert [70612,70623]
===
match
---
expr_stmt [46203,46236]
expr_stmt [46203,46236]
===
match
---
atom_expr [22714,22724]
atom_expr [22714,22724]
===
match
---
name: extend [19492,19498]
name: extend [19492,19498]
===
match
---
trailer [64075,64077]
trailer [64087,64089]
===
match
---
name: get [19880,19883]
name: get [19880,19883]
===
match
---
name: TaskInstance [28089,28101]
name: TaskInstance [28089,28101]
===
match
---
expr_stmt [26597,26911]
expr_stmt [26597,26911]
===
match
---
name: sqlalchemy [2880,2890]
name: sqlalchemy [2880,2890]
===
match
---
name: has_option [70059,70069]
name: has_option [70071,70081]
===
match
---
atom_expr [13016,13025]
atom_expr [13016,13025]
===
match
---
name: self [60621,60625]
name: self [60633,60637]
===
match
---
trailer [62913,62920]
trailer [62925,62932]
===
match
---
atom_expr [69421,69488]
atom_expr [69433,69500]
===
match
---
trailer [31770,31794]
trailer [31770,31794]
===
match
---
simple_stmt [23186,23208]
simple_stmt [23186,23208]
===
match
---
name: test_mode [57002,57011]
name: test_mode [57014,57023]
===
match
---
name: with_for_update [80761,80776]
name: with_for_update [80773,80788]
===
match
---
operator: = [74656,74657]
operator: = [74668,74669]
===
match
---
name: force_fail [57013,57023]
name: force_fail [57025,57035]
===
match
---
atom [19392,19403]
atom [19392,19403]
===
match
---
if_stmt [35599,35691]
if_stmt [35599,35691]
===
match
---
atom_expr [41633,41646]
atom_expr [41633,41646]
===
match
---
if_stmt [7945,8005]
if_stmt [7945,8005]
===
match
---
name: self [25322,25326]
name: self [25322,25326]
===
match
---
name: get_previous_start_date [30610,30633]
name: get_previous_start_date [30610,30633]
===
match
---
decorator [9130,9140]
decorator [9130,9140]
===
match
---
atom_expr [57393,57402]
atom_expr [57405,57414]
===
match
---
name: Float [10695,10700]
name: Float [10695,10700]
===
match
---
name: self [53079,53083]
name: self [53079,53083]
===
match
---
name: test_mode [56992,57001]
name: test_mode [57004,57013]
===
match
---
argument [40711,40734]
argument [40711,40734]
===
match
---
operator: == [75828,75830]
operator: == [75840,75842]
===
match
---
operator: , [1658,1659]
operator: , [1658,1659]
===
match
---
comparison [7680,7709]
comparison [7680,7709]
===
match
---
simple_stmt [13000,13026]
simple_stmt [13000,13026]
===
match
---
simple_stmt [18982,19023]
simple_stmt [18982,19023]
===
match
---
suite [45971,46059]
suite [45971,46059]
===
match
---
argument [74653,74660]
argument [74665,74672]
===
match
---
name: self [75831,75835]
name: self [75843,75847]
===
match
---
atom_expr [54775,54823]
atom_expr [54775,54835]
===
match
---
name: subject [70834,70841]
name: subject [70846,70853]
===
match
---
name: operator [11106,11114]
name: operator [11106,11114]
===
match
---
name: delay [35645,35650]
name: delay [35645,35650]
===
match
---
suite [25703,25964]
suite [25703,25964]
===
match
---
operator: , [16936,16937]
operator: , [16936,16937]
===
match
---
name: dep_status [33822,33832]
name: dep_status [33822,33832]
===
match
---
operator: = [54017,54018]
operator: = [54017,54018]
===
match
---
name: State [41633,41638]
name: State [41633,41638]
===
match
---
atom_expr [53694,53976]
atom_expr [53694,53976]
===
match
---
name: Column [10411,10417]
name: Column [10411,10417]
===
match
---
atom_expr [55284,55309]
atom_expr [55296,55321]
===
match
---
classdef [60097,60947]
classdef [60109,60959]
===
match
---
name: command_as_list [14942,14957]
name: command_as_list [14942,14957]
===
match
---
operator: , [51898,51899]
operator: , [51898,51899]
===
match
---
name: namespace [67147,67156]
name: namespace [67159,67168]
===
match
---
name: hostname [13088,13096]
name: hostname [13088,13096]
===
match
---
testlist_comp [77955,77983]
testlist_comp [77967,77995]
===
match
---
name: session [57036,57043]
name: session [57048,57055]
===
match
---
tfpdef [43089,43114]
tfpdef [43089,43114]
===
match
---
suite [33419,33833]
suite [33419,33833]
===
match
---
parameters [21260,21280]
parameters [21260,21280]
===
match
---
trailer [66050,66055]
trailer [66062,66067]
===
match
---
fstring_end: ' [44274,44275]
fstring_end: ' [44274,44275]
===
match
---
expr_stmt [23069,23092]
expr_stmt [23069,23092]
===
match
---
name: str [60651,60654]
name: str [60663,60666]
===
match
---
name: session [41757,41764]
name: session [41757,41764]
===
match
---
name: primary_key [10583,10594]
name: primary_key [10583,10594]
===
match
---
arglist [31056,31084]
arglist [31056,31084]
===
match
---
operator: , [42173,42174]
operator: , [42173,42174]
===
match
---
name: Optional [43023,43031]
name: Optional [43023,43031]
===
match
---
simple_stmt [9463,9522]
simple_stmt [9463,9522]
===
match
---
name: unixname [13005,13013]
name: unixname [13005,13013]
===
match
---
decorated [79926,80004]
decorated [79938,80016]
===
match
---
name: self [22112,22116]
name: self [22112,22116]
===
match
---
name: update [57650,57656]
name: update [57662,57668]
===
match
---
trailer [41638,41646]
trailer [41638,41646]
===
match
---
name: task [55252,55256]
name: task [55264,55268]
===
match
---
tfpdef [72784,72809]
tfpdef [72796,72821]
===
match
---
name: airflow [2279,2286]
name: airflow [2279,2286]
===
match
---
simple_stmt [65975,66020]
simple_stmt [65987,66032]
===
match
---
name: self [33987,33991]
name: self [33987,33991]
===
match
---
trailer [23085,23092]
trailer [23085,23092]
===
match
---
trailer [23047,23056]
trailer [23047,23056]
===
match
---
simple_stmt [60016,60088]
simple_stmt [60028,60100]
===
match
---
name: state [75874,75879]
name: state [75886,75891]
===
match
---
trailer [59205,59214]
trailer [59217,59226]
===
match
---
operator: = [23115,23116]
operator: = [23115,23116]
===
match
---
operator: @ [61568,61569]
operator: @ [61580,61581]
===
match
---
simple_stmt [11142,11176]
simple_stmt [11142,11176]
===
match
---
argument [69781,69810]
argument [69793,69822]
===
match
---
atom_expr [32848,33052]
atom_expr [32848,33052]
===
match
---
trailer [45759,45767]
trailer [45759,45767]
===
match
---
atom_expr [64712,64721]
atom_expr [64724,64733]
===
match
---
name: local [15141,15146]
name: local [15141,15146]
===
match
---
comparison [51132,51159]
comparison [51132,51159]
===
match
---
testlist_comp [45936,45964]
testlist_comp [45936,45964]
===
match
---
expr_stmt [52083,52520]
expr_stmt [52083,52520]
===
match
---
operator: = [48473,48474]
operator: = [48473,48474]
===
match
---
name: execution_date [16460,16474]
name: execution_date [16460,16474]
===
match
---
argument [50187,50206]
argument [50187,50206]
===
match
---
operator: = [68027,68028]
operator: = [68039,68040]
===
match
---
string: 'Try {{try_number}} out of {{max_tries + 1}}<br>' [68043,68092]
string: 'Try {{try_number}} out of {{max_tries + 1}}<br>' [68055,68104]
===
match
---
param [19757,19761]
param [19757,19761]
===
match
---
trailer [60654,60664]
trailer [60666,60676]
===
match
---
trailer [6233,6237]
trailer [6233,6237]
===
match
---
operator: = [60933,60934]
operator: = [60945,60946]
===
match
---
arith_expr [71092,71123]
arith_expr [71104,71135]
===
match
---
name: ignore_ti_state [39168,39183]
name: ignore_ti_state [39168,39183]
===
match
---
sync_comp_for [47673,47713]
sync_comp_for [47673,47713]
===
match
---
subscript [80895,80899]
subscript [80907,80911]
===
match
---
string: 'BASE_URL' [19897,19907]
string: 'BASE_URL' [19897,19907]
===
match
---
argument [52861,52885]
argument [52861,52885]
===
match
---
name: self [13374,13378]
name: self [13374,13378]
===
match
---
atom_expr [7273,7286]
atom_expr [7273,7286]
===
match
---
param [57320,57332]
param [57332,57344]
===
match
---
atom_expr [54200,54219]
atom_expr [54200,54219]
===
match
---
name: ignore_ti_state [40619,40634]
name: ignore_ti_state [40619,40634]
===
match
---
string: "Marking success for %s on %s" [42030,42060]
string: "Marking success for %s on %s" [42030,42060]
===
match
---
trailer [46349,46355]
trailer [46349,46355]
===
match
---
name: macros [57431,57437]
name: macros [57443,57449]
===
match
---
name: item [60916,60920]
name: item [60928,60932]
===
match
---
name: self [43870,43874]
name: self [43870,43874]
===
match
---
atom_expr [59842,59854]
atom_expr [59854,59866]
===
match
---
param [78271,78276]
param [78283,78288]
===
match
---
atom_expr [60655,60663]
atom_expr [60667,60675]
===
match
---
suite [49978,50035]
suite [49978,50035]
===
match
---
string: "--ignore-all-dependencies" [19144,19171]
string: "--ignore-all-dependencies" [19144,19171]
===
match
---
operator: = [39134,39135]
operator: = [39134,39135]
===
match
---
atom_expr [67157,67187]
atom_expr [67169,67199]
===
match
---
parameters [36026,36057]
parameters [36026,36057]
===
match
---
simple_stmt [65874,65899]
simple_stmt [65886,65911]
===
match
---
operator: = [40471,40472]
operator: = [40471,40472]
===
match
---
operator: = [41712,41713]
operator: = [41712,41713]
===
match
---
atom_expr [61274,61282]
atom_expr [61286,61294]
===
match
---
return_stmt [30519,30579]
return_stmt [30519,30579]
===
match
---
name: int [16743,16746]
name: int [16743,16746]
===
match
---
operator: , [54419,54420]
operator: , [54419,54420]
===
match
---
name: dep_status [33716,33726]
name: dep_status [33716,33726]
===
match
---
operator: = [15125,15126]
operator: = [15125,15126]
===
match
---
name: instance [28036,28044]
name: instance [28036,28044]
===
match
---
decorated [24727,24944]
decorated [24727,24944]
===
match
---
name: expunge_all [58018,58029]
name: expunge_all [58030,58041]
===
match
---
argument [63412,63431]
argument [63424,63443]
===
match
---
name: send_email [2543,2553]
name: send_email [2543,2553]
===
match
---
param [33245,33262]
param [33245,33262]
===
match
---
name: dag_id [57842,57848]
name: dag_id [57854,57860]
===
match
---
trailer [25261,25263]
trailer [25261,25263]
===
match
---
name: ti [80752,80754]
name: ti [80764,80766]
===
match
---
funcdef [14938,16364]
funcdef [14938,16364]
===
match
---
operator: , [62204,62205]
operator: , [62216,62217]
===
match
---
string: """Get the email subject content for exceptions.""" [67493,67544]
string: """Get the email subject content for exceptions.""" [67505,67556]
===
match
---
decorated [79848,79921]
decorated [79860,79933]
===
match
---
simple_stmt [56681,56701]
simple_stmt [56693,56713]
===
match
---
trailer [19680,19706]
trailer [19680,19706]
===
match
---
atom_expr [3687,3709]
atom_expr [3687,3709]
===
match
---
simple_stmt [805,820]
simple_stmt [805,820]
===
match
---
simple_stmt [2274,2306]
simple_stmt [2274,2306]
===
match
---
sync_comp_for [75284,75307]
sync_comp_for [75296,75319]
===
match
---
arglist [61424,61451]
arglist [61436,61463]
===
match
---
operator: = [48786,48787]
operator: = [48786,48787]
===
match
---
atom_expr [24011,24027]
atom_expr [24011,24027]
===
match
---
name: self [60655,60659]
name: self [60667,60671]
===
match
---
operator: , [30084,30085]
operator: , [30084,30085]
===
match
---
name: Index [11570,11575]
name: Index [11570,11575]
===
match
---
expr_stmt [14232,14256]
expr_stmt [14232,14256]
===
match
---
trailer [55359,55384]
trailer [55371,55396]
===
match
---
simple_stmt [2080,2125]
simple_stmt [2080,2125]
===
match
---
atom_expr [22186,22393]
atom_expr [22186,22393]
===
match
---
name: test_mode [45123,45132]
name: test_mode [45123,45132]
===
match
---
operator: , [42698,42699]
operator: , [42698,42699]
===
match
---
name: utcnow [39906,39912]
name: utcnow [39906,39912]
===
match
---
atom_expr [53012,53037]
atom_expr [53012,53037]
===
match
---
name: staticmethod [76085,76097]
name: staticmethod [76097,76109]
===
match
---
operator: , [54495,54496]
operator: , [54495,54496]
===
match
---
name: dag_run [66183,66190]
name: dag_run [66195,66202]
===
match
---
atom_expr [56580,56641]
atom_expr [56592,56653]
===
match
---
name: error [56979,56984]
name: error [56991,56996]
===
match
---
trailer [69971,69976]
trailer [69983,69988]
===
match
---
name: job_id [23086,23092]
name: job_id [23086,23092]
===
match
---
trailer [46758,46764]
trailer [46758,46764]
===
match
---
operator: , [51668,51669]
operator: , [51668,51669]
===
match
---
trailer [21158,21164]
trailer [21158,21164]
===
match
---
name: exception [50527,50536]
name: exception [50527,50536]
===
match
---
simple_stmt [71167,71188]
simple_stmt [71179,71200]
===
match
---
name: actual_start_date [45082,45099]
name: actual_start_date [45082,45099]
===
match
---
operator: , [63028,63029]
operator: , [63040,63041]
===
match
---
param [66223,66228]
param [66235,66240]
===
match
---
expr_stmt [3214,3233]
expr_stmt [3214,3233]
===
match
---
operator: = [80863,80864]
operator: = [80875,80876]
===
match
---
simple_stmt [19215,19253]
simple_stmt [19215,19253]
===
match
---
name: dr [8728,8730]
name: dr [8728,8730]
===
match
---
name: TaskInstance [20866,20878]
name: TaskInstance [20866,20878]
===
match
---
expr_stmt [3234,3258]
expr_stmt [3234,3258]
===
match
---
argument [57089,57100]
argument [57101,57112]
===
match
---
name: ti [6177,6179]
name: ti [6177,6179]
===
match
---
param [42240,42245]
param [42240,42245]
===
match
---
name: XCom [75402,75406]
name: XCom [75414,75418]
===
match
---
name: Any [1041,1044]
name: Any [1041,1044]
===
match
---
operator: , [66141,66142]
operator: , [66153,66154]
===
match
---
name: sqlalchemy [1265,1275]
name: sqlalchemy [1265,1275]
===
match
---
name: self [12169,12173]
name: self [12169,12173]
===
match
---
simple_stmt [31929,32562]
simple_stmt [31929,32562]
===
match
---
name: self [50518,50522]
name: self [50518,50522]
===
match
---
name: task [59921,59925]
name: task [59933,59937]
===
match
---
operator: , [69277,69278]
operator: , [69289,69290]
===
match
---
name: self [78944,78948]
name: self [78956,78960]
===
match
---
trailer [44841,44846]
trailer [44841,44846]
===
match
---
name: refresh_from_db [43985,44000]
name: refresh_from_db [43985,44000]
===
match
---
decorator [79127,79137]
decorator [79139,79149]
===
match
---
atom_expr [41698,41711]
atom_expr [41698,41711]
===
match
---
name: self [23864,23868]
name: self [23864,23868]
===
match
---
parameters [79959,79965]
parameters [79971,79977]
===
match
---
suite [44686,44944]
suite [44686,44944]
===
match
---
atom_expr [59414,59438]
atom_expr [59426,59450]
===
match
---
trailer [36384,36399]
trailer [36384,36399]
===
match
---
operator: @ [29981,29982]
operator: @ [29981,29982]
===
match
---
name: session [28797,28804]
name: session [28797,28804]
===
match
---
tfpdef [54505,54530]
tfpdef [54505,54530]
===
match
---
name: execution_date [58080,58094]
name: execution_date [58092,58106]
===
match
---
number: 2 [31738,31739]
number: 2 [31738,31739]
===
match
---
name: queue [23191,23196]
name: queue [23191,23196]
===
match
---
operator: , [11614,11615]
operator: , [11614,11615]
===
match
---
operator: -> [43151,43153]
operator: -> [43151,43153]
===
match
---
atom [45935,45965]
atom [45935,45965]
===
match
---
name: max_tries [22967,22976]
name: max_tries [22967,22976]
===
match
---
name: item [61358,61362]
name: item [61370,61374]
===
match
---
atom_expr [50000,50034]
atom_expr [50000,50034]
===
match
---
trailer [76036,76040]
trailer [76048,76052]
===
match
---
trailer [20116,20131]
trailer [20116,20131]
===
match
---
tfpdef [72648,72693]
tfpdef [72660,72705]
===
match
---
name: relationship [81074,81086]
name: relationship [81086,81098]
===
match
---
trailer [77916,77931]
trailer [77928,77943]
===
match
---
argument [6911,7286]
argument [6911,7286]
===
match
---
suite [28994,29437]
suite [28994,29437]
===
match
---
operator: == [6859,6861]
operator: == [6859,6861]
===
match
---
trailer [7435,7447]
trailer [7435,7447]
===
match
---
number: 1000 [10889,10893]
number: 1000 [10889,10893]
===
match
---
param [21261,21266]
param [21261,21266]
===
match
---
decorated [79540,79605]
decorated [79552,79617]
===
match
---
name: ignore_ti_state [16133,16148]
name: ignore_ti_state [16133,16148]
===
match
---
atom_expr [54729,54757]
atom_expr [54729,54757]
===
match
---
name: value [72407,72412]
name: value [72419,72424]
===
match
---
operator: = [78322,78323]
operator: = [78334,78335]
===
match
---
simple_stmt [48105,48124]
simple_stmt [48105,48124]
===
match
---
return_stmt [65874,65898]
return_stmt [65886,65910]
===
match
---
name: prev_execution_date [59451,59470]
name: prev_execution_date [59463,59482]
===
match
---
operator: = [44928,44929]
operator: = [44928,44929]
===
match
---
atom_expr [48733,48761]
atom_expr [48733,48761]
===
match
---
argument [31069,31084]
argument [31069,31084]
===
match
---
simple_stmt [80870,80918]
simple_stmt [80882,80930]
===
match
---
name: start_date [22611,22621]
name: start_date [22611,22621]
===
match
---
operator: -> [70978,70980]
operator: -> [70990,70992]
===
match
---
operator: , [74639,74640]
operator: , [74651,74652]
===
match
---
name: Variable [61665,61673]
name: Variable [61677,61685]
===
match
---
name: refresh_from_db [44471,44486]
name: refresh_from_db [44471,44486]
===
match
---
trailer [24076,24084]
trailer [24076,24084]
===
match
---
string: 'priority_weight' [78912,78929]
string: 'priority_weight' [78924,78941]
===
match
---
atom_expr [64649,64686]
atom_expr [64661,64698]
===
match
---
name: error_file [55097,55107]
name: error_file [55109,55119]
===
match
---
name: ds [58070,58072]
name: ds [58082,58084]
===
match
---
name: session [80064,80071]
name: session [80076,80083]
===
match
---
trailer [46130,46138]
trailer [46130,46138]
===
match
---
name: extend [18986,18992]
name: extend [18986,18992]
===
match
---
atom_expr [23832,23842]
atom_expr [23832,23842]
===
match
---
parameters [42239,42256]
parameters [42239,42256]
===
match
---
operator: , [11678,11679]
operator: , [11678,11679]
===
match
---
param [79406,79410]
param [79418,79422]
===
match
---
operator: = [56179,56180]
operator: = [56191,56192]
===
match
---
operator: , [7195,7196]
operator: , [7195,7196]
===
match
---
name: self [56794,56798]
name: self [56806,56810]
===
match
---
simple_stmt [44178,44216]
simple_stmt [44178,44216]
===
match
---
operator: , [6104,6105]
operator: , [6104,6105]
===
match
---
name: self [79982,79986]
name: self [79994,79998]
===
match
---
name: ti [23199,23201]
name: ti [23199,23201]
===
match
---
name: html_content [69406,69418]
name: html_content [69418,69430]
===
match
---
trailer [44866,44882]
trailer [44866,44882]
===
match
---
name: airflow [8062,8069]
name: airflow [8062,8069]
===
match
---
operator: = [8617,8618]
operator: = [8617,8618]
===
match
---
atom_expr [44862,44904]
atom_expr [44862,44904]
===
match
---
name: try_number [13605,13615]
name: try_number [13605,13615]
===
match
---
expr_stmt [51490,51527]
expr_stmt [51490,51527]
===
match
---
name: self [67467,67471]
name: self [67479,67483]
===
match
---
name: self [79109,79113]
name: self [79121,79125]
===
match
---
funcdef [79554,79605]
funcdef [79566,79617]
===
match
---
operator: = [43115,43116]
operator: = [43115,43116]
===
match
---
name: property [79849,79857]
name: property [79861,79869]
===
match
---
fstring_expr [33904,33918]
fstring_expr [33904,33918]
===
match
---
suite [66351,66402]
suite [66363,66414]
===
match
---
tfpdef [36682,36704]
tfpdef [36682,36704]
===
match
---
operator: = [52871,52872]
operator: = [52871,52872]
===
match
---
name: test_mode [13527,13536]
name: test_mode [13527,13536]
===
match
---
name: result [42266,42272]
name: result [42266,42272]
===
match
---
name: __init__ [12116,12124]
name: __init__ [12116,12124]
===
match
---
expr_stmt [15474,15493]
expr_stmt [15474,15493]
===
match
---
simple_stmt [4449,4472]
simple_stmt [4449,4472]
===
match
---
operator: , [65336,65337]
operator: , [65348,65349]
===
match
---
atom_expr [10751,10791]
atom_expr [10751,10791]
===
match
---
trailer [34561,34575]
trailer [34561,34575]
===
match
---
name: task [27396,27400]
name: task [27396,27400]
===
match
---
operator: , [49176,49177]
operator: , [49176,49177]
===
match
---
simple_stmt [33866,33958]
simple_stmt [33866,33958]
===
match
---
operator: = [51692,51693]
operator: = [51692,51693]
===
match
---
name: session [20513,20520]
name: session [20513,20520]
===
match
---
decorator [79540,79550]
decorator [79552,79562]
===
match
---
argument [16285,16298]
argument [16285,16298]
===
match
---
name: subject [69321,69328]
name: subject [69333,69340]
===
match
---
operator: - [35518,35519]
operator: - [35518,35519]
===
match
---
operator: -> [4330,4332]
operator: -> [4330,4332]
===
match
---
name: max_retry_delay [35667,35682]
name: max_retry_delay [35667,35682]
===
match
---
name: first [57919,57924]
name: first [57931,57936]
===
match
---
atom_expr [69112,69126]
atom_expr [69124,69138]
===
match
---
name: models [64408,64414]
name: models [64420,64426]
===
match
---
name: AirflowRescheduleException [1694,1720]
name: AirflowRescheduleException [1694,1720]
===
match
---
trailer [49401,49450]
trailer [49401,49450]
===
match
---
name: dag_id [24884,24890]
name: dag_id [24884,24890]
===
match
---
simple_stmt [39526,39539]
simple_stmt [39526,39539]
===
match
---
operator: , [51969,51970]
operator: , [51969,51970]
===
match
---
argument [47179,47194]
argument [47179,47194]
===
match
---
name: setter [14184,14190]
name: setter [14184,14190]
===
match
---
atom_expr [8224,8239]
atom_expr [8224,8239]
===
match
---
name: test_mode [52411,52420]
name: test_mode [52411,52420]
===
match
---
simple_stmt [25509,25555]
simple_stmt [25509,25555]
===
match
---
name: next_execution_date [59025,59044]
name: next_execution_date [59037,59056]
===
match
---
return_stmt [14107,14130]
return_stmt [14107,14130]
===
match
---
name: context [51110,51117]
name: context [51110,51117]
===
match
---
name: tis [76515,76518]
name: tis [76527,76530]
===
match
---
trailer [66190,66195]
trailer [66202,66207]
===
match
---
name: ti [5303,5305]
name: ti [5303,5305]
===
match
---
name: self [25431,25435]
name: self [25431,25435]
===
match
---
name: downstream_task_ids [26543,26562]
name: downstream_task_ids [26543,26562]
===
match
---
number: 2 [7924,7925]
number: 2 [7924,7925]
===
match
---
name: airflow [65419,65426]
name: airflow [65431,65438]
===
match
---
operator: == [77674,77676]
operator: == [77686,77688]
===
match
---
name: state [31795,31800]
name: state [31795,31800]
===
match
---
simple_stmt [16966,18775]
simple_stmt [16966,18775]
===
match
---
suite [56259,56354]
suite [56271,56366]
===
match
---
trailer [67713,67727]
trailer [67725,67739]
===
match
---
param [72827,72851]
param [72839,72863]
===
match
---
simple_stmt [59268,59290]
simple_stmt [59280,59302]
===
match
---
name: provide_session [56732,56747]
name: provide_session [56744,56759]
===
match
---
operator: , [69862,69863]
operator: , [69874,69875]
===
match
---
expr_stmt [66685,67294]
expr_stmt [66697,67306]
===
match
---
trailer [66415,66420]
trailer [66427,66432]
===
match
---
simple_stmt [53632,53652]
simple_stmt [53632,53652]
===
match
---
name: COLLATION_ARGS [10507,10521]
name: COLLATION_ARGS [10507,10521]
===
match
---
simple_stmt [41341,41354]
simple_stmt [41341,41354]
===
match
---
trailer [44229,44234]
trailer [44229,44234]
===
match
---
name: pool [23120,23124]
name: pool [23120,23124]
===
match
---
operator: = [68727,68728]
operator: = [68739,68740]
===
match
---
trailer [56694,56700]
trailer [56706,56712]
===
match
---
expr_stmt [12267,12312]
expr_stmt [12267,12312]
===
match
---
atom_expr [31204,31241]
atom_expr [31204,31241]
===
match
---
operator: , [50206,50207]
operator: , [50206,50207]
===
match
---
name: KeyboardInterrupt [45947,45964]
name: KeyboardInterrupt [45947,45964]
===
match
---
name: state [52984,52989]
name: state [52984,52989]
===
match
---
simple_stmt [41272,41292]
simple_stmt [41272,41292]
===
match
---
name: defaultdict [5236,5247]
name: defaultdict [5236,5247]
===
match
---
trailer [43927,43945]
trailer [43927,43945]
===
match
---
name: session [71405,71412]
name: session [71417,71424]
===
match
---
operator: , [38704,38705]
operator: , [38704,38705]
===
match
---
name: self [42175,42179]
name: self [42175,42179]
===
match
---
name: task [12253,12257]
name: task [12253,12257]
===
match
---
atom_expr [58184,58241]
atom_expr [58196,58253]
===
match
---
param [50611,50616]
param [50611,50616]
===
match
---
trailer [15709,15723]
trailer [15709,15723]
===
match
---
atom_expr [44466,44508]
atom_expr [44466,44508]
===
match
---
expr_stmt [24093,24136]
expr_stmt [24093,24136]
===
match
---
name: pool [16870,16874]
name: pool [16870,16874]
===
match
---
operator: = [55130,55131]
operator: = [55142,55143]
===
match
---
name: getpid [44108,44114]
name: getpid [44108,44114]
===
match
---
name: value [14216,14221]
name: value [14216,14221]
===
match
---
arglist [47360,47385]
arglist [47360,47385]
===
match
---
trailer [26697,26704]
trailer [26697,26704]
===
match
---
simple_stmt [12972,12992]
simple_stmt [12972,12992]
===
match
---
operator: = [51891,51892]
operator: = [51891,51892]
===
match
---
atom_expr [42062,42071]
atom_expr [42062,42071]
===
match
---
name: is_localized [12426,12438]
name: is_localized [12426,12438]
===
match
---
expr_stmt [28509,28577]
expr_stmt [28509,28577]
===
match
---
name: self [25463,25467]
name: self [25463,25467]
===
match
---
string: '\n' [47652,47656]
string: '\n' [47652,47656]
===
match
---
trailer [12234,12252]
trailer [12234,12252]
===
match
---
trailer [32670,32674]
trailer [32670,32674]
===
match
---
dotted_name [1983,2006]
dotted_name [1983,2006]
===
match
---
name: dag_run_state [8013,8026]
name: dag_run_state [8013,8026]
===
match
---
suite [45010,45153]
suite [45010,45153]
===
match
---
name: get_template_context [44354,44374]
name: get_template_context [44354,44374]
===
match
---
return_stmt [20206,20462]
return_stmt [20206,20462]
===
match
---
name: task [50446,50450]
name: task [50446,50450]
===
match
---
trailer [76072,76078]
trailer [76084,76090]
===
match
---
trailer [12286,12296]
trailer [12286,12296]
===
match
---
operator: , [52358,52359]
operator: , [52358,52359]
===
match
---
atom_expr [11270,11294]
atom_expr [11270,11294]
===
match
---
name: _date_or_empty [42768,42782]
name: _date_or_empty [42768,42782]
===
match
---
simple_stmt [2601,2658]
simple_stmt [2601,2658]
===
match
---
name: dag_id [6862,6868]
name: dag_id [6862,6868]
===
match
---
atom_expr [38671,38711]
atom_expr [38671,38711]
===
match
---
simple_stmt [76532,76544]
simple_stmt [76544,76556]
===
match
---
name: self [51360,51364]
name: self [51360,51364]
===
match
---
name: Connection [62244,62254]
name: Connection [62256,62266]
===
match
---
operator: , [11757,11758]
operator: , [11757,11758]
===
match
---
name: max_tries [10796,10805]
name: max_tries [10796,10805]
===
match
---
name: prepare_for_execution [53242,53263]
name: prepare_for_execution [53242,53263]
===
match
---
simple_stmt [28022,28066]
simple_stmt [28022,28066]
===
match
---
operator: , [78910,78911]
operator: , [78922,78923]
===
match
---
name: session [74786,74793]
name: session [74798,74805]
===
match
---
funcdef [60608,60665]
funcdef [60620,60677]
===
match
---
operator: = [23974,23975]
operator: = [23974,23975]
===
match
---
simple_stmt [2125,2179]
simple_stmt [2125,2179]
===
match
---
name: self [20507,20511]
name: self [20507,20511]
===
match
---
trailer [66742,66749]
trailer [66754,66761]
===
match
---
trailer [76629,76644]
trailer [76641,76656]
===
match
---
name: cmd [19054,19057]
name: cmd [19054,19057]
===
match
---
atom_expr [44521,44531]
atom_expr [44521,44531]
===
match
---
name: min_backoff [34528,34539]
name: min_backoff [34528,34539]
===
match
---
name: timedelta [35488,35497]
name: timedelta [35488,35497]
===
match
---
simple_stmt [7983,8005]
simple_stmt [7983,8005]
===
match
---
operator: < [72119,72120]
operator: < [72131,72132]
===
match
---
atom_expr [57881,57900]
atom_expr [57893,57912]
===
match
---
simple_stmt [49368,49451]
simple_stmt [49368,49451]
===
match
---
trailer [51364,51370]
trailer [51364,51370]
===
match
---
operator: == [7054,7056]
operator: == [7054,7056]
===
match
---
name: pod_mutation_hook [67312,67329]
name: pod_mutation_hook [67324,67341]
===
match
---
name: mark_success [52736,52748]
name: mark_success [52736,52748]
===
match
---
parameters [26013,26033]
parameters [26013,26033]
===
match
---
arglist [61831,61883]
arglist [61843,61895]
===
match
---
name: iso [20100,20103]
name: iso [20100,20103]
===
match
---
trailer [78625,78642]
trailer [78637,78654]
===
match
---
parameters [30633,30707]
parameters [30633,30707]
===
match
---
atom_expr [23199,23207]
atom_expr [23199,23207]
===
match
---
atom_expr [7002,7195]
atom_expr [7002,7195]
===
match
---
trailer [61544,61554]
trailer [61556,61566]
===
match
---
operator: = [10463,10464]
operator: = [10463,10464]
===
match
---
name: get_previous_execution_date [63384,63411]
name: get_previous_execution_date [63396,63423]
===
match
---
name: self [32737,32741]
name: self [32737,32741]
===
match
---
trailer [46003,46040]
trailer [46003,46040]
===
match
---
name: task_retries [5659,5671]
name: task_retries [5659,5671]
===
match
---
operator: = [31800,31801]
operator: = [31800,31801]
===
match
---
operator: = [53604,53605]
operator: = [53604,53605]
===
match
---
trailer [65557,65580]
trailer [65569,65592]
===
match
---
name: task [50932,50936]
name: task [50932,50936]
===
match
---
name: execution_date [58190,58204]
name: execution_date [58202,58216]
===
match
---
name: start_date [22595,22605]
name: start_date [22595,22605]
===
match
---
name: iso [18875,18878]
name: iso [18875,18878]
===
match
---
operator: , [16164,16165]
operator: , [16164,16165]
===
match
---
comparison [77421,77458]
comparison [77433,77470]
===
match
---
atom_expr [20273,20285]
atom_expr [20273,20285]
===
match
---
name: SUCCESS [51152,51159]
name: SUCCESS [51152,51159]
===
match
---
simple_stmt [77847,77999]
simple_stmt [77859,78011]
===
match
---
name: self [67714,67718]
name: self [67726,67730]
===
match
---
name: Dict [3244,3248]
name: Dict [3244,3248]
===
match
---
arith_expr [39070,39101]
arith_expr [39070,39101]
===
match
---
atom_expr [49227,49242]
atom_expr [49227,49242]
===
match
---
name: ti [79043,79045]
name: ti [79055,79057]
===
match
---
name: var [61405,61408]
name: var [61417,61420]
===
match
---
expr_stmt [5219,5294]
expr_stmt [5219,5294]
===
match
---
name: task_id [20982,20989]
name: task_id [20982,20989]
===
match
---
name: dag [15544,15547]
name: dag [15544,15547]
===
match
---
subscriptlist [8979,8997]
subscriptlist [8979,8997]
===
match
---
operator: , [40650,40651]
operator: , [40650,40651]
===
match
---
string: 'try_number' [10758,10770]
string: 'try_number' [10758,10770]
===
match
---
name: utils [2489,2494]
name: utils [2489,2494]
===
match
---
name: render [69568,69574]
name: render [69580,69586]
===
match
---
operator: = [40634,40635]
operator: = [40634,40635]
===
match
---
operator: , [36787,36788]
operator: , [36787,36788]
===
match
---
if_stmt [40678,41354]
if_stmt [40678,41354]
===
match
---
trailer [35606,35611]
trailer [35606,35611]
===
match
---
param [61646,61705]
param [61658,61717]
===
match
---
name: filter [8334,8340]
name: filter [8334,8340]
===
match
---
name: airflow [2606,2613]
name: airflow [2606,2613]
===
match
---
dotted_name [14173,14190]
dotted_name [14173,14190]
===
match
---
param [53137,53141]
param [53137,53141]
===
match
---
atom_expr [45023,45045]
atom_expr [45023,45045]
===
match
---
suite [3402,3943]
suite [3402,3943]
===
match
---
name: self [79268,79272]
name: self [79280,79284]
===
match
---
name: UP_FOR_RETRY [35922,35934]
name: UP_FOR_RETRY [35922,35934]
===
match
---
simple_stmt [54006,54043]
simple_stmt [54006,54043]
===
match
---
param [56846,56879]
param [56858,56891]
===
match
---
argument [38379,38397]
argument [38379,38397]
===
match
---
operator: == [77521,77523]
operator: == [77533,77535]
===
match
---
trailer [67229,67252]
trailer [67241,67264]
===
match
---
operator: -> [8970,8972]
operator: -> [8970,8972]
===
match
---
return_stmt [35699,35727]
return_stmt [35699,35727]
===
match
---
expr_stmt [3196,3212]
expr_stmt [3196,3212]
===
match
---
trailer [65692,65694]
trailer [65704,65706]
===
match
---
operator: { [47668,47669]
operator: { [47668,47669]
===
match
---
operator: = [27461,27462]
operator: = [27461,27462]
===
match
---
name: self [42932,42936]
name: self [42932,42936]
===
match
---
param [43053,43080]
param [43053,43080]
===
match
---
trailer [6075,6085]
trailer [6075,6085]
===
match
---
atom_expr [63418,63431]
atom_expr [63430,63443]
===
match
---
operator: } [48996,48997]
operator: } [48996,48997]
===
match
---
name: collections [906,917]
name: collections [906,917]
===
match
---
simple_stmt [64798,64822]
simple_stmt [64810,64834]
===
match
---
atom_expr [47983,48021]
atom_expr [47983,48021]
===
match
---
suite [4015,4262]
suite [4015,4262]
===
match
---
simple_stmt [8867,8880]
simple_stmt [8867,8880]
===
match
---
name: try_number [79478,79488]
name: try_number [79490,79500]
===
match
---
atom_expr [12205,12214]
atom_expr [12205,12214]
===
match
---
name: self [76073,76077]
name: self [76085,76089]
===
match
---
name: task [46635,46639]
name: task [46635,46639]
===
match
---
atom_expr [44071,44085]
atom_expr [44071,44085]
===
match
---
operator: = [56283,56284]
operator: = [56295,56296]
===
match
---
number: 1 [9381,9382]
number: 1 [9381,9382]
===
match
---
atom_expr [7601,7624]
atom_expr [7601,7624]
===
match
---
name: ID_LEN [10497,10503]
name: ID_LEN [10497,10503]
===
match
---
tfpdef [76121,76174]
tfpdef [76133,76186]
===
match
---
operator: , [65947,65948]
operator: , [65959,65960]
===
match
---
name: _task_id [78347,78355]
name: _task_id [78359,78367]
===
match
---
trailer [59535,59543]
trailer [59547,59555]
===
match
---
atom_expr [79593,79604]
atom_expr [79605,79616]
===
match
---
operator: = [67751,67752]
operator: = [67763,67764]
===
match
---
name: utcnow [53615,53621]
name: utcnow [53615,53621]
===
match
---
name: get [60708,60711]
name: get [60720,60723]
===
match
---
simple_stmt [43980,44018]
simple_stmt [43980,44018]
===
match
---
operator: - [80897,80898]
operator: - [80909,80910]
===
match
---
atom_expr [45754,45767]
atom_expr [45754,45767]
===
match
---
suite [39968,40166]
suite [39968,40166]
===
match
---
name: __file__ [69267,69275]
name: __file__ [69279,69287]
===
match
---
atom_expr [28593,28604]
atom_expr [28593,28604]
===
match
---
name: do_xcom_push [50123,50135]
name: do_xcom_push [50123,50135]
===
match
---
atom_expr [48178,48229]
atom_expr [48178,48229]
===
match
---
trailer [28230,28234]
trailer [28230,28234]
===
match
---
simple_stmt [4824,5198]
simple_stmt [4824,5198]
===
match
---
name: self [79080,79084]
name: self [79092,79096]
===
match
---
string: """             Wrapper around Variable. This way you can get variables in             templates by using ``{{ var.value.variable_name }}`` or             ``{{ var.value.get('variable_name', 'fallback') }}``.             """ [60133,60357]
string: """             Wrapper around Variable. This way you can get variables in             templates by using ``{{ var.value.variable_name }}`` or             ``{{ var.value.get('variable_name', 'fallback') }}``.             """ [60145,60369]
===
match
---
operator: = [70209,70210]
operator: = [70221,70222]
===
match
---
name: delete_old_records [47341,47359]
name: delete_old_records [47341,47359]
===
match
---
simple_stmt [47564,47730]
simple_stmt [47564,47730]
===
match
---
operator: = [72565,72566]
operator: = [72577,72578]
===
match
---
parameters [14851,14857]
parameters [14851,14857]
===
match
---
name: log [22117,22120]
name: log [22117,22120]
===
match
---
string: "Updating task params (%s) with DagRun.conf (%s)" [66084,66133]
string: "Updating task params (%s) with DagRun.conf (%s)" [66096,66145]
===
match
---
decorated [79610,79673]
decorated [79622,79685]
===
match
---
trailer [47161,47178]
trailer [47161,47178]
===
match
---
trailer [58860,58875]
trailer [58872,58887]
===
match
---
name: self [24613,24617]
name: self [24613,24617]
===
match
---
name: html_content_err [70932,70948]
name: html_content_err [70944,70960]
===
match
---
name: subject [70923,70930]
name: subject [70935,70942]
===
match
---
atom_expr [54440,54454]
atom_expr [54440,54454]
===
match
---
name: self [23508,23512]
name: self [23508,23512]
===
match
---
name: ValueError [72160,72170]
name: ValueError [72172,72182]
===
match
---
name: dag [12746,12749]
name: dag [12746,12749]
===
match
---
atom_expr [42275,42300]
atom_expr [42275,42300]
===
match
---
name: get_failed_dep_statuses [32742,32765]
name: get_failed_dep_statuses [32742,32765]
===
match
---
string: """Prepare Task for Execution""" [46502,46534]
string: """Prepare Task for Execution""" [46502,46534]
===
match
---
name: Integer [10916,10923]
name: Integer [10916,10923]
===
match
---
simple_stmt [22112,22171]
simple_stmt [22112,22171]
===
match
---
name: dag_run [60079,60086]
name: dag_run [60091,60098]
===
match
---
name: should_pass_filepath [15503,15523]
name: should_pass_filepath [15503,15523]
===
match
---
name: State [29961,29966]
name: State [29961,29966]
===
match
---
operator: , [69126,69127]
operator: , [69138,69139]
===
match
---
string: '%Y-%m-%d' [58230,58240]
string: '%Y-%m-%d' [58242,58252]
===
match
---
suite [4819,8763]
suite [4819,8763]
===
match
---
name: state [25905,25910]
name: state [25905,25910]
===
match
---
atom_expr [9566,9578]
atom_expr [9566,9578]
===
match
---
name: deps [39065,39069]
name: deps [39065,39069]
===
match
---
funcdef [36012,36474]
funcdef [36012,36474]
===
match
---
name: dep_context [32766,32777]
name: dep_context [32766,32777]
===
match
---
name: job_id [11804,11810]
name: job_id [11804,11810]
===
match
---
funcdef [4665,8763]
funcdef [4665,8763]
===
match
---
operator: } [59854,59855]
operator: } [59866,59867]
===
match
---
operator: } [19961,19962]
operator: } [19961,19962]
===
match
---
decorator [14818,14828]
decorator [14818,14828]
===
match
---
trailer [19611,19636]
trailer [19611,19636]
===
match
---
atom_expr [14912,14928]
atom_expr [14912,14928]
===
match
---
name: is_premature [25684,25696]
name: is_premature [25684,25696]
===
match
---
operator: , [62779,62780]
operator: , [62791,62792]
===
match
---
operator: , [40487,40488]
operator: , [40487,40488]
===
match
---
operator: , [12734,12735]
operator: , [12734,12735]
===
match
---
name: filter [20893,20899]
name: filter [20893,20899]
===
match
---
name: are_dependents_done [25994,26013]
name: are_dependents_done [25994,26013]
===
match
---
suite [22527,23378]
suite [22527,23378]
===
match
---
name: TR [6941,6943]
name: TR [6941,6943]
===
match
---
simple_stmt [39007,39329]
simple_stmt [39007,39329]
===
match
---
atom_expr [66988,67010]
atom_expr [67000,67022]
===
match
---
decorated [21609,23481]
decorated [21609,23481]
===
match
---
atom_expr [22947,22961]
atom_expr [22947,22961]
===
match
---
argument [10452,10468]
argument [10452,10468]
===
match
---
fstring_string:  [ [33940,33942]
fstring_string:  [ [33940,33942]
===
match
---
operator: = [49203,49204]
operator: = [49203,49204]
===
match
---
trailer [78346,78355]
trailer [78358,78367]
===
match
---
comparison [36378,36422]
comparison [36378,36422]
===
match
---
trailer [22193,22199]
trailer [22193,22199]
===
match
---
name: context [66444,66451]
name: context [66456,66463]
===
match
---
operator: , [7137,7138]
operator: , [7137,7138]
===
match
---
name: self [43980,43984]
name: self [43980,43984]
===
match
---
operator: -> [66488,66490]
operator: -> [66500,66502]
===
match
---
param [36797,36821]
param [36797,36821]
===
match
---
operator: -> [56942,56944]
operator: -> [56954,56956]
===
match
---
funcdef [79692,79773]
funcdef [79704,79785]
===
match
---
atom_expr [29414,29436]
atom_expr [29414,29436]
===
match
---
atom_expr [69520,69591]
atom_expr [69532,69603]
===
match
---
trailer [59490,59511]
trailer [59502,59523]
===
match
---
name: exception_html [69014,69028]
name: exception_html [69026,69040]
===
match
---
name: timezone [25246,25254]
name: timezone [25246,25254]
===
match
---
simple_stmt [51173,51190]
simple_stmt [51173,51190]
===
match
---
string: 'dag' [62710,62715]
string: 'dag' [62722,62727]
===
match
---
name: self [51664,51668]
name: self [51664,51668]
===
match
---
fstring_expr [59826,59839]
fstring_expr [59838,59851]
===
match
---
atom_expr [76669,76682]
atom_expr [76681,76694]
===
match
---
atom_expr [3585,3617]
atom_expr [3585,3617]
===
match
---
name: _priority_weight [78850,78866]
name: _priority_weight [78862,78878]
===
match
---
operator: , [39262,39263]
operator: , [39262,39263]
===
match
---
trailer [4792,4799]
trailer [4792,4799]
===
match
---
operator: = [67156,67157]
operator: = [67168,67169]
===
match
---
string: """     Clears a set of task instances, but makes sure the running ones     get killed.      :param tis: a list of task instances     :param session: current session     :param dag_run_state: state to set DagRun to. If set to False, dagrun state will not         be changed.     :param dag: DAG object     :param activate_dag_runs: Deprecated parameter, do not pass     """ [4824,5197]
string: """     Clears a set of task instances, but makes sure the running ones     get killed.      :param tis: a list of task instances     :param session: current session     :param dag_run_state: state to set DagRun to. If set to False, dagrun state will not         be changed.     :param dag: DAG object     :param activate_dag_runs: Deprecated parameter, do not pass     """ [4824,5197]
===
match
---
simple_stmt [55125,55142]
simple_stmt [55137,55154]
===
match
---
atom_expr [46271,46290]
atom_expr [46271,46290]
===
match
---
string: 'ti_dag_date' [11576,11589]
string: 'ti_dag_date' [11576,11589]
===
match
---
name: self [48284,48288]
name: self [48284,48288]
===
match
---
simple_stmt [22714,22736]
simple_stmt [22714,22736]
===
match
---
suite [57626,57674]
suite [57638,57686]
===
match
---
trailer [14118,14130]
trailer [14118,14130]
===
match
---
name: merge [41765,41770]
name: merge [41765,41770]
===
match
---
name: self [23404,23408]
name: self [23404,23408]
===
match
---
atom_expr [53050,53066]
atom_expr [53050,53066]
===
match
---
funcdef [72611,75495]
funcdef [72623,75507]
===
match
---
simple_stmt [7719,7937]
simple_stmt [7719,7937]
===
match
---
name: get_k8s_pod_yaml [65541,65557]
name: get_k8s_pod_yaml [65553,65569]
===
match
---
if_stmt [5521,6131]
if_stmt [5521,6131]
===
match
---
trailer [19135,19142]
trailer [19135,19142]
===
match
---
operator: , [36820,36821]
operator: , [36820,36821]
===
match
---
name: dag_id [77612,77618]
name: dag_id [77624,77630]
===
match
---
string: 'webserver' [20173,20184]
string: 'webserver' [20173,20184]
===
match
---
param [50299,50303]
param [50299,50303]
===
match
---
operator: , [77757,77758]
operator: , [77769,77770]
===
match
---
trailer [67264,67282]
trailer [67276,67294]
===
match
---
name: IO [1037,1039]
name: IO [1037,1039]
===
match
---
simple_stmt [69955,69996]
simple_stmt [69967,70008]
===
match
---
simple_stmt [24783,24848]
simple_stmt [24783,24848]
===
match
---
name: context [49480,49487]
name: context [49480,49487]
===
match
---
name: dill [11289,11293]
name: dill [11289,11293]
===
match
---
name: datetime [79243,79251]
name: datetime [79255,79263]
===
match
---
name: all [76881,76884]
name: all [76893,76896]
===
match
---
name: verbose [31905,31912]
name: verbose [31905,31912]
===
match
---
atom_expr [51360,51370]
atom_expr [51360,51370]
===
match
---
tfpdef [72827,72843]
tfpdef [72839,72855]
===
match
---
operator: = [38422,38423]
operator: = [38422,38423]
===
match
---
argument [69377,69392]
argument [69389,69404]
===
match
---
funcdef [33211,33833]
funcdef [33211,33833]
===
match
---
string: 'ti_job_id' [11791,11802]
string: 'ti_job_id' [11791,11802]
===
match
---
atom_expr [80621,80634]
atom_expr [80633,80646]
===
match
---
trailer [6310,6322]
trailer [6310,6322]
===
match
---
name: provide_session [80010,80025]
name: provide_session [80022,80037]
===
match
---
trailer [44374,44376]
trailer [44374,44376]
===
match
---
name: task [42169,42173]
name: task [42169,42173]
===
match
---
name: self [61545,61549]
name: self [61557,61561]
===
match
---
operator: = [61663,61664]
operator: = [61675,61676]
===
match
---
simple_stmt [3056,3110]
simple_stmt [3056,3110]
===
match
---
operator: , [68977,68978]
operator: , [68989,68990]
===
match
---
trailer [59649,59657]
trailer [59661,59669]
===
match
---
expr_stmt [3260,3296]
expr_stmt [3260,3296]
===
match
---
simple_stmt [42440,42853]
simple_stmt [42440,42853]
===
match
---
atom_expr [62244,62288]
atom_expr [62256,62300]
===
match
---
import_from [1511,1539]
import_from [1511,1539]
===
match
---
name: log [42445,42448]
name: log [42445,42448]
===
match
---
trailer [56688,56694]
trailer [56700,56706]
===
match
---
param [75976,75985]
param [75988,75997]
===
match
---
name: test_mode [52776,52785]
name: test_mode [52776,52785]
===
match
---
name: html_content [70706,70718]
name: html_content [70718,70730]
===
match
---
name: session [40048,40055]
name: session [40048,40055]
===
match
---
trailer [40876,40880]
trailer [40876,40880]
===
match
---
trailer [46288,46290]
trailer [46288,46290]
===
match
---
simple_stmt [7645,7672]
simple_stmt [7645,7672]
===
match
---
name: log [25277,25280]
name: log [25277,25280]
===
match
---
name: self [79357,79361]
name: self [79369,79373]
===
match
---
name: self [79633,79637]
name: self [79645,79649]
===
match
---
atom_expr [59138,59162]
atom_expr [59150,59174]
===
match
---
atom_expr [23290,23301]
atom_expr [23290,23301]
===
match
---
argument [16133,16164]
argument [16133,16164]
===
match
---
trailer [47059,47061]
trailer [47059,47061]
===
match
---
atom_expr [14796,14812]
atom_expr [14796,14812]
===
match
---
name: state [11554,11559]
name: state [11554,11559]
===
match
---
atom_expr [28901,28913]
atom_expr [28901,28913]
===
match
---
name: verbose [39449,39456]
name: verbose [39449,39456]
===
match
---
expr_stmt [44917,44943]
expr_stmt [44917,44943]
===
match
---
operator: = [22688,22689]
operator: = [22688,22689]
===
match
---
name: self [79662,79666]
name: self [79674,79678]
===
match
---
name: get_template_context [66379,66399]
name: get_template_context [66391,66411]
===
match
---
test [52971,53037]
test [52971,53037]
===
match
---
simple_stmt [59907,59934]
simple_stmt [59919,59946]
===
match
---
name: _handle_reschedule [53387,53405]
name: _handle_reschedule [53387,53405]
===
match
---
name: super [12108,12113]
name: super [12108,12113]
===
match
---
param [62353,62363]
param [62365,62375]
===
match
---
trailer [41527,41532]
trailer [41527,41532]
===
match
---
trailer [69116,69126]
trailer [69128,69138]
===
match
---
simple_stmt [12169,12197]
simple_stmt [12169,12197]
===
match
---
name: pid [44099,44102]
name: pid [44099,44102]
===
match
---
trailer [46234,46236]
trailer [46234,46236]
===
match
---
fstring_expr [47093,47111]
fstring_expr [47093,47111]
===
match
---
name: render [69465,69471]
name: render [69477,69483]
===
match
---
atom_expr [57793,57926]
atom_expr [57805,57938]
===
match
---
funcdef [25990,26991]
funcdef [25990,26991]
===
match
---
name: dag_id [24513,24519]
name: dag_id [24513,24519]
===
match
---
atom_expr [25584,25597]
atom_expr [25584,25597]
===
match
---
operator: = [69893,69894]
operator: = [69905,69906]
===
match
---
name: res [52536,52539]
name: res [52536,52539]
===
match
---
name: verbose_aware_logger [33107,33127]
name: verbose_aware_logger [33107,33127]
===
match
---
operator: = [22918,22919]
operator: = [22918,22919]
===
match
---
name: __init__ [78262,78270]
name: __init__ [78274,78282]
===
match
---
if_stmt [21126,21204]
if_stmt [21126,21204]
===
match
---
operator: , [64721,64722]
operator: , [64733,64734]
===
match
---
atom_expr [35471,35522]
atom_expr [35471,35522]
===
match
---
trailer [45860,45897]
trailer [45860,45897]
===
match
---
name: UndefinedError [65739,65753]
name: UndefinedError [65751,65765]
===
match
---
name: _run_finished_callback [53084,53106]
name: _run_finished_callback [53084,53106]
===
match
---
operator: = [66949,66950]
operator: = [66961,66962]
===
match
---
expr_stmt [22989,23016]
expr_stmt [22989,23016]
===
match
---
atom_expr [15480,15493]
atom_expr [15480,15493]
===
match
---
suite [70176,70220]
suite [70188,70232]
===
match
---
string: """         The task instance for the task that ran before this task instance.          :param state: If passed, it only take into account instances of a specific state.         :param session: SQLAlchemy ORM Session         """ [27148,27376]
string: """         The task instance for the task that ran before this task instance.          :param state: If passed, it only take into account instances of a specific state.         :param session: SQLAlchemy ORM Session         """ [27148,27376]
===
match
---
name: self [79564,79568]
name: self [79576,79580]
===
match
---
tfpdef [16870,16889]
tfpdef [16870,16889]
===
match
---
expr_stmt [10401,10469]
expr_stmt [10401,10469]
===
match
---
trailer [28900,28931]
trailer [28900,28931]
===
match
---
atom_expr [50172,50221]
atom_expr [50172,50221]
===
match
---
trailer [64819,64821]
trailer [64831,64833]
===
match
---
name: dag_run_state [4759,4772]
name: dag_run_state [4759,4772]
===
match
---
name: jinja_context [69379,69392]
name: jinja_context [69391,69404]
===
match
---
simple_stmt [77545,77821]
simple_stmt [77557,77833]
===
match
---
arglist [67714,67726]
arglist [67726,67738]
===
match
---
atom_expr [9363,9378]
atom_expr [9363,9378]
===
match
---
arglist [19884,19907]
arglist [19884,19907]
===
match
---
atom_expr [76881,76956]
atom_expr [76893,76968]
===
match
---
if_stmt [49680,50035]
if_stmt [49680,50035]
===
match
---
trailer [54866,54872]
trailer [54878,54884]
===
match
---
name: airflow [1516,1523]
name: airflow [1516,1523]
===
match
---
name: tis [76561,76564]
name: tis [76573,76576]
===
match
---
name: max_retry_delay [35612,35627]
name: max_retry_delay [35612,35627]
===
match
---
suite [51393,51621]
suite [51393,51621]
===
match
---
operator: { [68729,68730]
operator: { [68741,68742]
===
match
---
arith_expr [58265,58299]
arith_expr [58277,58311]
===
match
---
operator: , [7304,7305]
operator: , [7304,7305]
===
match
---
simple_stmt [15275,15466]
simple_stmt [15275,15466]
===
match
---
name: provide_session [65286,65301]
name: provide_session [65298,65313]
===
match
---
decorator [79294,79304]
decorator [79306,79316]
===
match
---
name: registered [48165,48175]
name: registered [48165,48175]
===
match
---
simple_stmt [35444,35523]
simple_stmt [35444,35523]
===
match
---
raise_stmt [46856,46910]
raise_stmt [46856,46910]
===
match
---
atom_expr [41629,41653]
atom_expr [41629,41653]
===
match
---
simple_stmt [28082,28215]
simple_stmt [28082,28215]
===
match
---
operator: , [52480,52481]
operator: , [52480,52481]
===
match
---
atom_expr [8383,8446]
atom_expr [8383,8446]
===
match
---
name: max_tries [69102,69111]
name: max_tries [69114,69123]
===
match
---
name: str [62359,62362]
name: str [62371,62374]
===
match
---
name: html_content [70377,70389]
name: html_content [70389,70401]
===
match
---
name: TaskInstanceStateType [78074,78095]
name: TaskInstanceStateType [78086,78107]
===
match
---
simple_stmt [1456,1510]
simple_stmt [1456,1510]
===
match
---
name: self [24011,24015]
name: self [24011,24015]
===
match
---
trailer [5396,5402]
trailer [5396,5402]
===
match
---
operator: , [24925,24926]
operator: , [24925,24926]
===
match
---
name: outlets [63114,63121]
name: outlets [63126,63133]
===
match
---
fstring_start: f' [44235,44237]
fstring_start: f' [44235,44237]
===
match
---
name: AirflowFailException [1638,1658]
name: AirflowFailException [1638,1658]
===
match
---
tfpdef [71405,71421]
tfpdef [71417,71433]
===
match
---
name: fd [3965,3967]
name: fd [3965,3967]
===
match
---
import_from [64395,64465]
import_from [64407,64477]
===
match
---
operator: = [7923,7924]
operator: = [7923,7924]
===
match
---
trailer [44882,44904]
trailer [44882,44904]
===
match
---
name: queue [11036,11041]
name: queue [11036,11041]
===
match
---
tfpdef [30057,30077]
tfpdef [30057,30077]
===
match
---
name: primaryjoin [11878,11889]
name: primaryjoin [11878,11889]
===
match
---
param [31293,31297]
param [31293,31297]
===
match
---
atom_expr [27911,27934]
atom_expr [27911,27934]
===
match
---
name: Exception [50644,50653]
name: Exception [50644,50653]
===
match
---
name: query [22194,22199]
name: query [22194,22199]
===
match
---
operator: = [60062,60063]
operator: = [60074,60075]
===
match
---
if_stmt [40081,40166]
if_stmt [40081,40166]
===
match
---
trailer [41315,41322]
trailer [41315,41322]
===
match
---
param [33263,33275]
param [33263,33275]
===
match
---
name: UtcDateTime [11163,11174]
name: UtcDateTime [11163,11174]
===
match
---
suite [2995,3172]
suite [2995,3172]
===
match
---
operator: , [63151,63152]
operator: , [63163,63164]
===
match
---
trailer [54242,54244]
trailer [54242,54244]
===
match
---
trailer [29684,29918]
trailer [29684,29918]
===
match
---
name: State [41676,41681]
name: State [41676,41681]
===
match
---
comparison [8013,8039]
comparison [8013,8039]
===
match
---
operator: = [43868,43869]
operator: = [43868,43869]
===
match
---
atom_expr [54398,54419]
atom_expr [54398,54419]
===
match
---
name: self [79831,79835]
name: self [79843,79847]
===
match
---
name: item [61831,61835]
name: item [61843,61847]
===
match
---
trailer [42829,42841]
trailer [42829,42841]
===
match
---
name: pool_slots [23142,23152]
name: pool_slots [23142,23152]
===
match
---
trailer [24059,24069]
trailer [24059,24069]
===
match
---
name: context_to_airflow_vars [47495,47518]
name: context_to_airflow_vars [47495,47518]
===
match
---
simple_stmt [46623,46664]
simple_stmt [46623,46664]
===
match
---
name: bool [42960,42964]
name: bool [42960,42964]
===
match
---
name: execution_date [72492,72506]
name: execution_date [72504,72518]
===
match
---
name: mark_success [44309,44321]
name: mark_success [44309,44321]
===
match
---
atom_expr [24030,24046]
atom_expr [24030,24046]
===
match
---
atom_expr [8388,8401]
atom_expr [8388,8401]
===
match
---
string: 'conf' [62684,62690]
string: 'conf' [62696,62702]
===
match
---
trailer [29966,29974]
trailer [29966,29974]
===
match
---
param [24222,24227]
param [24222,24227]
===
match
---
name: try_number [69050,69060]
name: try_number [69062,69072]
===
match
---
atom_expr [47495,47551]
atom_expr [47495,47551]
===
match
---
return_stmt [15809,16363]
return_stmt [15809,16363]
===
match
---
comparison [74512,74526]
comparison [74524,74538]
===
match
---
trailer [8340,8543]
trailer [8340,8543]
===
match
---
name: error [50617,50622]
name: error [50617,50622]
===
match
---
atom_expr [66771,66783]
atom_expr [66783,66795]
===
match
---
name: task [56465,56469]
name: task [56477,56481]
===
match
---
name: SUCCESS [63424,63431]
name: SUCCESS [63436,63443]
===
match
---
atom_expr [46920,46965]
atom_expr [46920,46965]
===
match
---
name: query [74570,74575]
name: query [74582,74587]
===
match
---
operator: , [51862,51863]
operator: , [51862,51863]
===
match
---
atom_expr [40797,40807]
atom_expr [40797,40807]
===
match
---
name: task [55446,55450]
name: task [55458,55462]
===
match
---
trailer [46340,46363]
trailer [46340,46363]
===
match
---
dotted_name [80965,80985]
dotted_name [80977,80997]
===
match
---
suite [51242,51347]
suite [51242,51347]
===
match
---
trailer [58855,58876]
trailer [58867,58888]
===
match
---
name: sqlalchemy [1363,1373]
name: sqlalchemy [1363,1373]
===
match
---
fstring [19935,20007]
fstring [19935,20007]
===
match
---
operator: = [25009,25010]
operator: = [25009,25010]
===
match
---
param [60729,60739]
param [60741,60751]
===
match
---
trailer [6145,6151]
trailer [6145,6151]
===
match
---
name: airflow [64400,64407]
name: airflow [64412,64419]
===
match
---
tfpdef [51979,51998]
tfpdef [51979,51998]
===
match
---
simple_stmt [67303,67335]
simple_stmt [67315,67347]
===
match
---
name: session [39432,39439]
name: session [39432,39439]
===
match
---
name: settings [1531,1539]
name: settings [1531,1539]
===
match
---
trailer [63411,63432]
trailer [63423,63444]
===
match
---
operator: } [64287,64288]
operator: } [64299,64300]
===
match
---
operator: , [72774,72775]
operator: , [72786,72787]
===
match
---
parameters [23507,23539]
parameters [23507,23539]
===
match
---
name: use_default [67688,67699]
name: use_default [67700,67711]
===
match
---
expr_stmt [10677,10701]
expr_stmt [10677,10701]
===
match
---
if_stmt [18888,18948]
if_stmt [18888,18948]
===
match
---
name: bytes [3972,3977]
name: bytes [3972,3977]
===
match
---
name: self [45565,45569]
name: self [45565,45569]
===
match
---
atom_expr [59647,59683]
atom_expr [59659,59695]
===
match
---
trailer [80906,80908]
trailer [80918,80920]
===
match
---
suite [54575,56726]
suite [54575,56738]
===
match
---
string: """Send alert email with exception information.""" [70638,70688]
string: """Send alert email with exception information.""" [70650,70700]
===
match
---
operator: , [45444,45445]
operator: , [45444,45445]
===
match
---
trailer [60537,60541]
trailer [60549,60553]
===
match
---
operator: @ [26996,26997]
operator: @ [26996,26997]
===
match
---
name: list [76489,76493]
name: list [76501,76505]
===
match
---
name: context [50471,50478]
name: context [50471,50478]
===
match
---
name: self [66482,66486]
name: self [66494,66498]
===
match
---
atom_expr [50113,50135]
atom_expr [50113,50135]
===
match
---
operator: = [74752,74753]
operator: = [74764,74765]
===
match
---
name: end_date [55155,55163]
name: end_date [55167,55175]
===
match
---
operator: , [63229,63230]
operator: , [63241,63242]
===
match
---
simple_stmt [39493,39510]
simple_stmt [39493,39510]
===
match
---
trailer [4180,4186]
trailer [4180,4186]
===
match
---
name: self [23274,23278]
name: self [23274,23278]
===
match
---
trailer [42767,42782]
trailer [42767,42782]
===
match
---
name: end_date [71097,71105]
name: end_date [71109,71117]
===
match
---
name: task_id [10401,10408]
name: task_id [10401,10408]
===
match
---
if_stmt [19413,19459]
if_stmt [19413,19459]
===
match
---
simple_stmt [53152,53192]
simple_stmt [53152,53192]
===
match
---
expr_stmt [11497,11818]
expr_stmt [11497,11818]
===
match
---
trailer [53782,53797]
trailer [53782,53797]
===
match
---
name: prev_ti [31181,31188]
name: prev_ti [31181,31188]
===
match
---
strings [68376,68665]
strings [68388,68677]
===
match
---
trailer [26969,26989]
trailer [26969,26989]
===
match
---
trailer [23364,23368]
trailer [23364,23368]
===
match
---
atom_expr [54253,54322]
atom_expr [54253,54322]
===
match
---
operator: = [39456,39457]
operator: = [39456,39457]
===
match
---
name: XCOM_RETURN_KEY [50191,50206]
name: XCOM_RETURN_KEY [50191,50206]
===
match
---
atom_expr [78492,78506]
atom_expr [78504,78518]
===
match
---
suite [52619,52934]
suite [52619,52934]
===
match
---
name: try_number [6295,6305]
name: try_number [6295,6305]
===
match
---
trailer [61549,61553]
trailer [61561,61565]
===
match
---
name: Optional [51985,51993]
name: Optional [51985,51993]
===
match
---
atom_expr [25463,25473]
atom_expr [25463,25473]
===
match
---
name: self [69843,69847]
name: self [69855,69859]
===
match
---
operator: , [4739,4740]
operator: , [4739,4740]
===
match
---
name: job_id [15205,15211]
name: job_id [15205,15211]
===
match
---
expr_stmt [46623,46663]
expr_stmt [46623,46663]
===
match
---
param [71405,71429]
param [71417,71441]
===
match
---
operator: } [44258,44259]
operator: } [44258,44259]
===
match
---
operator: @ [49046,49047]
operator: @ [49046,49047]
===
match
---
simple_stmt [5219,5295]
simple_stmt [5219,5295]
===
match
---
trailer [77721,77736]
trailer [77733,77748]
===
match
---
name: DagRun [81039,81045]
name: DagRun [81051,81057]
===
match
---
operator: = [52191,52192]
operator: = [52191,52192]
===
match
---
trailer [33646,33655]
trailer [33646,33655]
===
match
---
operator: = [11834,11835]
operator: = [11834,11835]
===
match
---
string: "/confirm" [20238,20248]
string: "/confirm" [20238,20248]
===
match
---
name: int [34679,34682]
name: int [34679,34682]
===
match
---
trailer [78103,78125]
trailer [78115,78137]
===
match
---
string: 'Log: <a href="{{ti.log_url}}">Link</a><br>' [68156,68200]
string: 'Log: <a href="{{ti.log_url}}">Link</a><br>' [68168,68212]
===
match
---
name: isoformat [18804,18813]
name: isoformat [18804,18813]
===
match
---
simple_stmt [30450,30511]
simple_stmt [30450,30511]
===
match
---
operator: = [24159,24160]
operator: = [24159,24160]
===
match
---
or_test [32584,32611]
or_test [32584,32611]
===
match
---
parameters [33850,33856]
parameters [33850,33856]
===
match
---
string: """             This attribute is deprecated.             Please use `airflow.models.taskinstance.TaskInstance.get_previous_start_date` method.             """ [31522,31681]
string: """             This attribute is deprecated.             Please use `airflow.models.taskinstance.TaskInstance.get_previous_start_date` method.             """ [31522,31681]
===
match
---
operator: = [13097,13098]
operator: = [13097,13098]
===
match
---
operator: = [23369,23370]
operator: = [23369,23370]
===
match
---
number: 0 [26934,26935]
number: 0 [26934,26935]
===
match
---
suite [15266,16364]
suite [15266,16364]
===
match
---
name: get_previous_ti [31040,31055]
name: get_previous_ti [31040,31055]
===
match
---
operator: , [49104,49105]
operator: , [49104,49105]
===
match
---
name: self [57248,57252]
name: self [57260,57264]
===
match
---
name: make_aware [12820,12830]
name: make_aware [12820,12830]
===
match
---
argument [67147,67187]
argument [67159,67199]
===
match
---
operator: = [72433,72434]
operator: = [72445,72446]
===
match
---
expr_stmt [10546,10600]
expr_stmt [10546,10600]
===
match
---
trailer [23318,23330]
trailer [23318,23330]
===
match
---
atom [57775,57940]
atom [57787,57952]
===
match
---
expr_stmt [56206,56245]
expr_stmt [56218,56257]
===
match
---
fstring_expr [47668,47671]
fstring_expr [47668,47671]
===
match
---
trailer [77957,77961]
trailer [77969,77973]
===
match
---
atom_expr [77904,77931]
atom_expr [77916,77943]
===
match
---
name: set [8162,8165]
name: set [8162,8165]
===
match
---
operator: = [10934,10935]
operator: = [10934,10935]
===
match
---
trailer [78386,78402]
trailer [78398,78414]
===
match
---
string: """Sets the log context.""" [75996,76023]
string: """Sets the log context.""" [76008,76035]
===
match
---
name: jinja_context [69676,69689]
name: jinja_context [69688,69701]
===
match
---
operator: , [15968,15969]
operator: , [15968,15969]
===
match
---
param [25002,25014]
param [25002,25014]
===
match
---
arglist [32766,32806]
arglist [32766,32806]
===
match
---
name: query [57801,57806]
name: query [57813,57818]
===
match
---
name: cfg_path [15245,15253]
name: cfg_path [15245,15253]
===
match
---
name: str [8984,8987]
name: str [8984,8987]
===
match
---
name: pickle [4635,4641]
name: pickle [4635,4641]
===
match
---
suite [64602,64751]
suite [64614,64763]
===
match
---
name: self [40685,40689]
name: self [40685,40689]
===
match
---
name: session [57793,57800]
name: session [57805,57812]
===
match
---
name: task_id_by_key [7353,7367]
name: task_id_by_key [7353,7367]
===
match
---
name: handle_failure [54353,54367]
name: handle_failure [54353,54367]
===
match
---
simple_stmt [1161,1186]
simple_stmt [1161,1186]
===
match
---
name: e [45216,45217]
name: e [45216,45217]
===
match
---
suite [61919,62654]
suite [61931,62666]
===
match
---
trailer [18927,18947]
trailer [18927,18947]
===
match
---
trailer [19225,19252]
trailer [19225,19252]
===
match
---
atom_expr [23953,23973]
atom_expr [23953,23973]
===
match
---
name: seek [4071,4075]
name: seek [4071,4075]
===
match
---
name: Literal [2468,2475]
name: Literal [2468,2475]
===
match
---
name: property [13588,13596]
name: property [13588,13596]
===
match
---
funcdef [62140,62289]
funcdef [62152,62301]
===
match
---
trailer [5453,5460]
trailer [5453,5460]
===
match
---
name: Optional [54517,54525]
name: Optional [54517,54525]
===
match
---
operator: @ [9618,9619]
operator: @ [9618,9619]
===
match
---
argument [16264,16271]
argument [16264,16271]
===
match
---
name: dag_id [33896,33902]
name: dag_id [33896,33902]
===
match
---
simple_stmt [78811,78837]
simple_stmt [78823,78849]
===
match
---
tfpdef [16805,16814]
tfpdef [16805,16814]
===
match
---
operator: , [42615,42616]
operator: , [42615,42616]
===
match
---
simple_stmt [46672,46694]
simple_stmt [46672,46694]
===
match
---
name: self [41474,41478]
name: self [41474,41478]
===
match
---
name: PickleType [1314,1324]
name: PickleType [1314,1324]
===
match
---
name: self [47271,47275]
name: self [47271,47275]
===
match
---
trailer [31310,31329]
trailer [31310,31329]
===
match
---
name: Optional [51949,51957]
name: Optional [51949,51957]
===
match
---
name: ti [47268,47270]
name: ti [47268,47270]
===
match
---
operator: = [66803,66804]
operator: = [66815,66816]
===
match
---
trailer [80507,80513]
trailer [80519,80525]
===
match
---
decorator [21609,21626]
decorator [21609,21626]
===
match
---
name: error_fd [53028,53036]
name: error_fd [53028,53036]
===
match
---
name: dag_id [22262,22268]
name: dag_id [22262,22268]
===
match
---
name: _try_number [14119,14130]
name: _try_number [14119,14130]
===
match
---
operator: , [36557,36558]
operator: , [36557,36558]
===
match
---
param [14981,15000]
param [14981,15000]
===
match
---
dotted_name [1363,1377]
dotted_name [1363,1377]
===
match
---
operator: - [5747,5748]
operator: - [5747,5748]
===
match
---
trailer [21594,21601]
trailer [21594,21601]
===
match
---
simple_stmt [51490,51528]
simple_stmt [51490,51528]
===
match
---
expr_stmt [70377,70445]
expr_stmt [70389,70457]
===
match
---
atom_expr [5616,5642]
atom_expr [5616,5642]
===
match
---
name: str [16784,16787]
name: str [16784,16787]
===
match
---
simple_stmt [12267,12313]
simple_stmt [12267,12313]
===
match
---
name: key [74657,74660]
name: key [74669,74672]
===
match
---
name: execution_date [28159,28173]
name: execution_date [28159,28173]
===
match
---
name: on_kill [46834,46841]
name: on_kill [46834,46841]
===
match
---
atom_expr [77854,77998]
atom_expr [77866,78010]
===
match
---
name: self [75556,75560]
name: self [75568,75572]
===
match
---
param [79960,79964]
param [79972,79976]
===
match
---
operator: , [50279,50280]
operator: , [50279,50280]
===
match
---
decorated [71258,72585]
decorated [71270,72597]
===
match
---
name: task [58911,58915]
name: task [58923,58927]
===
match
---
operator: , [15870,15871]
operator: , [15870,15871]
===
match
---
atom_expr [8299,8562]
atom_expr [8299,8562]
===
match
---
name: session [72558,72565]
name: session [72570,72577]
===
match
---
name: session [27081,27088]
name: session [27081,27088]
===
match
---
param [71316,71325]
param [71328,71337]
===
match
---
argument [15982,16013]
argument [15982,16013]
===
match
---
operator: , [10450,10451]
operator: , [10450,10451]
===
match
---
simple_stmt [57643,57674]
simple_stmt [57655,57686]
===
match
---
name: log [21466,21469]
name: log [21466,21469]
===
match
---
name: property [9619,9627]
name: property [9619,9627]
===
match
---
decorator [25969,25986]
decorator [25969,25986]
===
match
---
decorator [21230,21247]
decorator [21230,21247]
===
match
---
trailer [12650,12655]
trailer [12650,12655]
===
match
---
parameters [51654,52034]
parameters [51654,52034]
===
match
---
operator: = [11042,11043]
operator: = [11042,11043]
===
match
---
operator: = [52838,52839]
operator: = [52838,52839]
===
match
---
operator: = [70319,70320]
operator: = [70331,70332]
===
match
---
param [54547,54560]
param [54547,54560]
===
match
---
trailer [36319,36327]
trailer [36319,36327]
===
match
---
trailer [19883,19908]
trailer [19883,19908]
===
match
---
name: dag_id [18858,18864]
name: dag_id [18858,18864]
===
match
---
trailer [20859,20865]
trailer [20859,20865]
===
match
---
name: prev_ds [59245,59252]
name: prev_ds [59257,59264]
===
match
---
operator: , [11744,11745]
operator: , [11744,11745]
===
match
---
name: job [7645,7648]
name: job [7645,7648]
===
match
---
name: Index [11524,11529]
name: Index [11524,11529]
===
match
---
name: Optional [30064,30072]
name: Optional [30064,30072]
===
match
---
parameters [60451,60515]
parameters [60463,60527]
===
match
---
operator: @ [19731,19732]
operator: @ [19731,19732]
===
match
---
operator: , [15258,15259]
operator: , [15258,15259]
===
match
---
operator: , [51737,51738]
operator: , [51737,51738]
===
match
---
name: self [25525,25529]
name: self [25525,25529]
===
match
---
name: reconstructor [1385,1398]
name: reconstructor [1385,1398]
===
match
---
trailer [7284,7286]
trailer [7284,7286]
===
match
---
name: task_copy [53225,53234]
name: task_copy [53225,53234]
===
match
---
annassign [78457,78483]
annassign [78469,78495]
===
match
---
trailer [58094,58103]
trailer [58106,58115]
===
match
---
name: tomorrow_ds [59773,59784]
name: tomorrow_ds [59785,59796]
===
match
---
param [53453,53469]
param [53453,53469]
===
match
---
name: result [50214,50220]
name: result [50214,50220]
===
match
---
name: self [78492,78496]
name: self [78504,78508]
===
match
---
name: task_id [28906,28913]
name: task_id [28906,28913]
===
match
---
name: info [41440,41444]
name: info [41440,41444]
===
match
---
name: FAILED [21544,21550]
name: FAILED [21544,21550]
===
match
---
trailer [21101,21105]
trailer [21101,21105]
===
match
---
simple_stmt [54668,54695]
simple_stmt [54668,54695]
===
match
---
expr_stmt [50900,50916]
expr_stmt [50900,50916]
===
match
---
string: "TaskInstance" [76141,76155]
string: "TaskInstance" [76153,76167]
===
match
---
simple_stmt [22674,22702]
simple_stmt [22674,22702]
===
match
---
string: """Return Number of running TIs from the DB""" [75580,75626]
string: """Return Number of running TIs from the DB""" [75592,75638]
===
match
---
name: dates [7344,7349]
name: dates [7344,7349]
===
match
---
atom_expr [12646,12665]
atom_expr [12646,12665]
===
match
---
atom_expr [45984,46040]
atom_expr [45984,46040]
===
match
---
dotted_name [2085,2108]
dotted_name [2085,2108]
===
match
---
comp_op [50147,50153]
comp_op [50147,50153]
===
match
---
name: error_file [4399,4409]
name: error_file [4399,4409]
===
match
---
trailer [51089,51109]
trailer [51089,51109]
===
match
---
operator: , [40038,40039]
operator: , [40038,40039]
===
match
---
name: execution_date [9585,9599]
name: execution_date [9585,9599]
===
match
---
atom_expr [59827,59838]
atom_expr [59839,59850]
===
match
---
simple_stmt [1540,1579]
simple_stmt [1540,1579]
===
match
---
param [49474,49479]
param [49474,49479]
===
match
---
name: cmd [19488,19491]
name: cmd [19488,19491]
===
match
---
param [51872,51899]
param [51872,51899]
===
match
---
import_as_names [2157,2178]
import_as_names [2157,2178]
===
match
---
suite [79966,80004]
suite [79978,80016]
===
match
---
name: self [74549,74553]
name: self [74561,74565]
===
match
---
trailer [66378,66399]
trailer [66390,66411]
===
match
---
simple_stmt [23549,23824]
simple_stmt [23549,23824]
===
match
---
name: on_failure_callback [51090,51109]
name: on_failure_callback [51090,51109]
===
match
---
atom_expr [47685,47713]
atom_expr [47685,47713]
===
match
---
trailer [34909,34911]
trailer [34909,34911]
===
match
---
param [79802,79806]
param [79814,79818]
===
match
---
simple_stmt [57953,57998]
simple_stmt [57965,58010]
===
match
---
param [16764,16796]
param [16764,16796]
===
match
---
atom [26869,26899]
atom [26869,26899]
===
match
---
name: replace [59650,59657]
name: replace [59662,59669]
===
match
---
operator: = [11889,11890]
operator: = [11889,11890]
===
match
---
atom_expr [51040,51060]
atom_expr [51040,51060]
===
match
---
simple_stmt [53200,53217]
simple_stmt [53200,53217]
===
match
---
name: error_fd [52872,52880]
name: error_fd [52872,52880]
===
match
---
atom_expr [57849,57864]
atom_expr [57861,57876]
===
match
---
operator: , [62757,62758]
operator: , [62769,62770]
===
match
---
trailer [24431,24437]
trailer [24431,24437]
===
match
---
argument [61430,61451]
argument [61442,61463]
===
match
---
suite [4436,4472]
suite [4436,4472]
===
match
---
operator: , [64277,64278]
operator: , [64289,64290]
===
match
---
name: session [31069,31076]
name: session [31069,31076]
===
match
---
trailer [23335,23347]
trailer [23335,23347]
===
match
---
import_name [857,870]
import_name [857,870]
===
match
---
expr_stmt [41698,41718]
expr_stmt [41698,41718]
===
match
---
operator: , [11930,11931]
operator: , [11930,11931]
===
match
---
simple_stmt [48165,48230]
simple_stmt [48165,48230]
===
match
---
expr_stmt [23274,23301]
expr_stmt [23274,23301]
===
match
---
atom_expr [23976,24002]
atom_expr [23976,24002]
===
match
---
trailer [60411,60415]
trailer [60423,60427]
===
match
---
atom_expr [23117,23124]
atom_expr [23117,23124]
===
match
---
suite [61720,61885]
suite [61732,61897]
===
match
---
atom_expr [78563,78576]
atom_expr [78575,78588]
===
match
---
param [42932,42937]
param [42932,42937]
===
match
---
except_clause [44952,45009]
except_clause [44952,45009]
===
match
---
atom_expr [70739,70780]
atom_expr [70751,70792]
===
match
---
operator: , [45121,45122]
operator: , [45121,45122]
===
match
---
parameters [46721,46736]
parameters [46721,46736]
===
match
---
name: warn [29160,29164]
name: warn [29160,29164]
===
match
---
expr_stmt [3297,3330]
expr_stmt [3297,3330]
===
match
---
operator: = [59195,59196]
operator: = [59207,59208]
===
match
---
operator: = [36619,36620]
operator: = [36619,36620]
===
match
---
trailer [70252,70264]
trailer [70264,70276]
===
match
---
param [61358,61368]
param [61370,61380]
===
match
---
operator: - [39083,39084]
operator: - [39083,39084]
===
match
---
atom_expr [12149,12160]
atom_expr [12149,12160]
===
match
---
atom_expr [76489,76498]
atom_expr [76501,76510]
===
match
---
trailer [35943,35963]
trailer [35943,35963]
===
match
---
atom_expr [34734,34881]
atom_expr [34734,34881]
===
match
---
operator: = [56222,56223]
operator: = [56234,56235]
===
match
---
operator: , [69028,69029]
operator: , [69040,69041]
===
match
---
name: task [15485,15489]
name: task [15485,15489]
===
match
---
atom [18830,18879]
atom [18830,18879]
===
match
---
trailer [44206,44213]
trailer [44206,44213]
===
match
---
param [51664,51669]
param [51664,51669]
===
match
---
comparison [80548,80583]
comparison [80560,80595]
===
match
---
name: provide_session [35992,36007]
name: provide_session [35992,36007]
===
match
---
name: ti [22524,22526]
name: ti [22524,22526]
===
match
---
name: retries [57217,57224]
name: retries [57229,57236]
===
match
---
atom_expr [40389,40665]
atom_expr [40389,40665]
===
match
---
trailer [59920,59933]
trailer [59932,59945]
===
match
---
name: AirflowSmartSensorException [1778,1805]
name: AirflowSmartSensorException [1778,1805]
===
match
---
name: ignore_ti_state [39184,39199]
name: ignore_ti_state [39184,39199]
===
match
---
name: on_success_callback [51210,51229]
name: on_success_callback [51210,51229]
===
match
---
name: ignore_all_deps [39119,39134]
name: ignore_all_deps [39119,39134]
===
match
---
name: self [14912,14916]
name: self [14912,14916]
===
match
---
atom_expr [44809,44815]
atom_expr [44809,44815]
===
match
---
name: airflow [2130,2137]
name: airflow [2130,2137]
===
match
---
trailer [79361,79373]
trailer [79373,79385]
===
match
---
arglist [66084,66155]
arglist [66096,66167]
===
match
---
simple_stmt [51544,51573]
simple_stmt [51544,51573]
===
match
---
name: RUNNING_DEPS [2421,2433]
name: RUNNING_DEPS [2421,2433]
===
match
---
subscriptlist [76141,76172]
subscriptlist [76153,76184]
===
match
---
comparison [15584,15617]
comparison [15584,15617]
===
match
---
atom_expr [5436,5461]
atom_expr [5436,5461]
===
match
---
name: context [44339,44346]
name: context [44339,44346]
===
match
---
trailer [81063,81071]
trailer [81075,81083]
===
match
---
atom_expr [26616,26648]
atom_expr [26616,26648]
===
match
---
simple_stmt [3196,3213]
simple_stmt [3196,3213]
===
match
---
operator: = [80755,80756]
operator: = [80767,80768]
===
match
---
atom_expr [50907,50916]
atom_expr [50907,50916]
===
match
---
trailer [9367,9378]
trailer [9367,9378]
===
match
---
trailer [11280,11294]
trailer [11280,11294]
===
match
---
trailer [19142,19173]
trailer [19142,19173]
===
match
---
name: try_number [34833,34843]
name: try_number [34833,34843]
===
match
---
name: catchup [28597,28604]
name: catchup [28597,28604]
===
match
---
atom_expr [56285,56303]
atom_expr [56297,56315]
===
match
---
simple_stmt [74540,74561]
simple_stmt [74552,74573]
===
match
---
name: session [7456,7463]
name: session [7456,7463]
===
match
---
name: execution_date [77917,77931]
name: execution_date [77929,77943]
===
match
---
trailer [47951,47966]
trailer [47951,47966]
===
match
---
trailer [75419,75421]
trailer [75431,75433]
===
match
---
operator: @ [79127,79128]
operator: @ [79139,79140]
===
match
---
name: try_number [9368,9378]
name: try_number [9368,9378]
===
match
---
operator: -> [24755,24757]
operator: -> [24755,24757]
===
match
---
return_stmt [79175,79195]
return_stmt [79187,79207]
===
match
---
atom_expr [28766,28818]
atom_expr [28766,28818]
===
match
---
expr_stmt [35444,35522]
expr_stmt [35444,35522]
===
match
---
name: VariableJsonAccessor [60962,60982]
name: VariableJsonAccessor [60974,60994]
===
match
---
name: Log [55360,55363]
name: Log [55372,55375]
===
match
---
name: ignore_all_deps [15009,15024]
name: ignore_all_deps [15009,15024]
===
match
---
trailer [53309,53326]
trailer [53309,53326]
===
match
---
name: get_template_context [69640,69660]
name: get_template_context [69652,69672]
===
match
---
name: Column [10839,10845]
name: Column [10839,10845]
===
match
---
name: TemplateAssertionError [64842,64864]
name: TemplateAssertionError [64854,64876]
===
match
---
expr_stmt [78074,78125]
expr_stmt [78086,78137]
===
match
---
name: Stats [48944,48949]
name: Stats [48944,48949]
===
match
---
atom_expr [75861,75879]
atom_expr [75873,75891]
===
match
---
expr_stmt [53200,53216]
expr_stmt [53200,53216]
===
match
---
suite [58794,58960]
suite [58806,58972]
===
match
---
arglist [50187,50220]
arglist [50187,50220]
===
match
---
trailer [6094,6104]
trailer [6094,6104]
===
match
---
arglist [29698,29908]
arglist [29698,29908]
===
match
---
name: end_date [53595,53603]
name: end_date [53595,53603]
===
match
---
name: ti [78324,78326]
name: ti [78336,78338]
===
match
---
name: error_file [4283,4293]
name: error_file [4283,4293]
===
match
---
trailer [23849,23855]
trailer [23849,23855]
===
match
---
param [56808,56837]
param [56820,56849]
===
match
---
name: TaskInstance [80597,80609]
name: TaskInstance [80609,80621]
===
match
---
expr_stmt [69321,69393]
expr_stmt [69333,69405]
===
match
---
name: DagRun [57720,57726]
name: DagRun [57732,57738]
===
match
---
atom_expr [59473,59511]
atom_expr [59485,59523]
===
match
---
name: pod [67330,67333]
name: pod [67342,67345]
===
match
---
suite [4423,4663]
suite [4423,4663]
===
match
---
name: dep_context [33245,33256]
name: dep_context [33245,33256]
===
match
---
simple_stmt [10474,10542]
simple_stmt [10474,10542]
===
match
---
param [70612,70617]
param [70624,70629]
===
match
---
comparison [76999,77028]
comparison [77011,77040]
===
match
---
name: self [66771,66775]
name: self [66783,66787]
===
match
---
decorated [79778,79843]
decorated [79790,79855]
===
match
---
name: open [70160,70164]
name: open [70172,70176]
===
match
---
atom_expr [35902,35912]
atom_expr [35902,35912]
===
match
---
name: task [43875,43879]
name: task [43875,43879]
===
match
---
trailer [44265,44273]
trailer [44265,44273]
===
match
---
operator: , [2419,2420]
operator: , [2419,2420]
===
match
---
operator: , [1746,1747]
operator: , [1746,1747]
===
match
---
operator: , [12036,12037]
operator: , [12036,12037]
===
match
---
name: task_id [77213,77220]
name: task_id [77225,77232]
===
match
---
trailer [51957,51962]
trailer [51957,51962]
===
match
---
trailer [41560,41572]
trailer [41560,41572]
===
match
---
name: debug [25281,25286]
name: debug [25281,25286]
===
match
---
suite [15724,15762]
suite [15724,15762]
===
match
---
name: self [60469,60473]
name: self [60481,60485]
===
match
---
name: Optional [76179,76187]
name: Optional [76191,76199]
===
match
---
name: AirflowSmartSensorException [49374,49401]
name: AirflowSmartSensorException [49374,49401]
===
match
---
name: self [58265,58269]
name: self [58277,58281]
===
match
---
atom_expr [67359,67402]
atom_expr [67371,67414]
===
match
---
operator: , [48814,48815]
operator: , [48814,48815]
===
match
---
number: 2 [29386,29387]
number: 2 [29386,29387]
===
match
---
trailer [25648,25654]
trailer [25648,25654]
===
match
---
name: ti [23083,23085]
name: ti [23083,23085]
===
match
---
not_test [65592,65613]
not_test [65604,65625]
===
match
---
import_from [1894,1942]
import_from [1894,1942]
===
match
---
name: self [66988,66992]
name: self [67000,67004]
===
match
---
simple_stmt [79824,79843]
simple_stmt [79836,79855]
===
match
---
trailer [24896,24904]
trailer [24896,24904]
===
match
---
name: result [50237,50243]
name: result [50237,50243]
===
match
---
arglist [66731,67284]
arglist [66743,67296]
===
match
---
arglist [47268,47299]
arglist [47268,47299]
===
match
---
atom_expr [53079,53119]
atom_expr [53079,53119]
===
match
---
name: first [36437,36442]
name: first [36437,36442]
===
match
---
import_from [57686,57726]
import_from [57698,57738]
===
match
---
atom_expr [78968,78986]
atom_expr [78980,78998]
===
match
---
operator: { [59841,59842]
operator: { [59853,59854]
===
match
---
trailer [7039,7094]
trailer [7039,7094]
===
match
---
name: session [49299,49306]
name: session [49299,49306]
===
match
---
name: self [68736,68740]
name: self [68748,68752]
===
match
---
trailer [41624,41628]
trailer [41624,41628]
===
match
---
import_from [2434,2475]
import_from [2434,2475]
===
match
---
atom_expr [31311,31328]
atom_expr [31311,31328]
===
match
---
name: execution_date [57866,57880]
name: execution_date [57878,57892]
===
match
---
simple_stmt [68335,68676]
simple_stmt [68347,68688]
===
match
---
name: Exception [54747,54756]
name: Exception [54747,54756]
===
match
---
operator: , [29329,29330]
operator: , [29329,29330]
===
match
---
name: key [79046,79049]
name: key [79058,79061]
===
match
---
atom_expr [61665,61704]
atom_expr [61677,61716]
===
match
---
operator: , [22382,22383]
operator: , [22382,22383]
===
match
---
name: dag_id [11680,11686]
name: dag_id [11680,11686]
===
match
---
name: RenderedTaskInstanceFields [46587,46613]
name: RenderedTaskInstanceFields [46587,46613]
===
match
---
operator: = [66689,66690]
operator: = [66701,66702]
===
match
---
suite [78931,78987]
suite [78943,78999]
===
match
---
tfpdef [30094,30110]
tfpdef [30094,30110]
===
match
---
name: start_date [25375,25385]
name: start_date [25375,25385]
===
match
---
simple_stmt [12205,12222]
simple_stmt [12205,12222]
===
match
---
name: next_execution_date [59068,59087]
name: next_execution_date [59080,59099]
===
match
---
operator: , [1243,1244]
operator: , [1243,1244]
===
match
---
trailer [8703,8710]
trailer [8703,8710]
===
match
---
name: dict [66500,66504]
name: dict [66512,66516]
===
match
---
name: _state [78590,78596]
name: _state [78602,78608]
===
match
---
trailer [48902,48934]
trailer [48902,48934]
===
match
---
name: self [78539,78543]
name: self [78551,78555]
===
match
---
suite [75048,75349]
suite [75060,75361]
===
match
---
trailer [9325,9333]
trailer [9325,9333]
===
match
---
argument [57842,57864]
argument [57854,57876]
===
match
---
name: or_ [1346,1349]
name: or_ [1346,1349]
===
match
---
if_stmt [65589,65866]
if_stmt [65601,65878]
===
match
---
name: task_copy [46684,46693]
name: task_copy [46684,46693]
===
match
---
simple_stmt [22947,22977]
simple_stmt [22947,22977]
===
match
---
not_test [55321,55334]
not_test [55333,55346]
===
match
---
not_test [41730,41743]
not_test [41730,41743]
===
match
---
name: queued_by_job [81112,81125]
name: queued_by_job [81124,81137]
===
match
---
simple_stmt [71453,72074]
simple_stmt [71465,72086]
===
match
---
trailer [4808,4815]
trailer [4808,4815]
===
match
---
operator: , [21654,21655]
operator: , [21654,21655]
===
match
---
simple_stmt [46543,46614]
simple_stmt [46543,46614]
===
match
---
argument [69472,69487]
argument [69484,69499]
===
match
---
param [75556,75561]
param [75568,75573]
===
match
---
operator: , [36894,36895]
operator: , [36894,36895]
===
match
---
funcdef [66202,66453]
funcdef [66214,66465]
===
match
---
trailer [75470,75488]
trailer [75482,75500]
===
match
---
expr_stmt [78441,78483]
expr_stmt [78453,78495]
===
match
---
expr_stmt [49192,49218]
expr_stmt [49192,49218]
===
match
---
name: self [57207,57211]
name: self [57219,57223]
===
match
---
atom_expr [81074,81094]
atom_expr [81086,81106]
===
match
---
expr_stmt [38325,38341]
expr_stmt [38325,38341]
===
match
---
expr_stmt [8645,8665]
expr_stmt [8645,8665]
===
match
---
fstring_expr [46140,46152]
fstring_expr [46140,46152]
===
match
---
operator: @ [42858,42859]
operator: @ [42858,42859]
===
match
---
atom_expr [44094,44102]
atom_expr [44094,44102]
===
match
---
name: execution_date [66955,66969]
name: execution_date [66967,66981]
===
match
---
name: XCom [2174,2178]
name: XCom [2174,2178]
===
match
---
trailer [70816,70856]
trailer [70828,70868]
===
match
---
name: items [7279,7284]
name: items [7279,7284]
===
match
---
operator: == [77197,77199]
operator: == [77209,77211]
===
match
---
operator: @ [24949,24950]
operator: @ [24949,24950]
===
match
---
param [26020,26032]
param [26020,26032]
===
match
---
expr_stmt [10706,10732]
expr_stmt [10706,10732]
===
match
---
atom_expr [5703,5715]
atom_expr [5703,5715]
===
match
---
operator: , [40601,40602]
operator: , [40601,40602]
===
match
---
trailer [60659,60663]
trailer [60671,60675]
===
match
---
expr_stmt [10864,10895]
expr_stmt [10864,10895]
===
match
---
name: str [4295,4298]
name: str [4295,4298]
===
match
---
name: self [44466,44470]
name: self [44466,44470]
===
match
---
name: self [12468,12472]
name: self [12468,12472]
===
match
---
name: task_id [47365,47372]
name: task_id [47365,47372]
===
match
---
trailer [35963,35965]
trailer [35963,35965]
===
match
---
name: _log_state [56368,56378]
name: _log_state [56380,56390]
===
match
---
name: self [30043,30047]
name: self [30043,30047]
===
match
---
param [79633,79637]
param [79645,79649]
===
match
---
trailer [56152,56154]
trailer [56164,56166]
===
match
---
param [54429,54462]
param [54429,54462]
===
match
---
decorator [33190,33207]
decorator [33190,33207]
===
match
---
atom_expr [59946,60002]
atom_expr [59958,60014]
===
match
---
tfpdef [27081,27097]
tfpdef [27081,27097]
===
match
---
number: 1 [49000,49001]
number: 1 [49000,49001]
===
match
---
suite [44289,44548]
suite [44289,44548]
===
match
---
simple_stmt [56580,56642]
simple_stmt [56592,56654]
===
match
---
name: attr [42289,42293]
name: attr [42289,42293]
===
match
---
name: self [69967,69971]
name: self [69979,69983]
===
match
---
testlist_comp [64842,64880]
testlist_comp [64854,64892]
===
match
---
atom_expr [25600,25615]
atom_expr [25600,25615]
===
match
---
operator: = [23843,23844]
operator: = [23843,23844]
===
match
---
name: dag_id [77317,77323]
name: dag_id [77329,77335]
===
match
---
operator: , [11014,11015]
operator: , [11014,11015]
===
match
---
trailer [63504,63510]
trailer [63516,63522]
===
match
---
suite [4158,4193]
suite [4158,4193]
===
match
---
string: """             This attribute is deprecated.             Please use `airflow.models.taskinstance.TaskInstance.get_previous_ti` method.             """ [29698,29849]
string: """             This attribute is deprecated.             Please use `airflow.models.taskinstance.TaskInstance.get_previous_ti` method.             """ [29698,29849]
===
match
---
simple_stmt [12108,12127]
simple_stmt [12108,12127]
===
match
---
trailer [76886,76893]
trailer [76898,76905]
===
match
---
string: """URL to mark TI success""" [20063,20091]
string: """URL to mark TI success""" [20063,20091]
===
match
---
trailer [58017,58029]
trailer [58029,58041]
===
match
---
trailer [27067,27072]
trailer [27067,27072]
===
match
---
atom_expr [25583,25632]
atom_expr [25583,25632]
===
match
---
comparison [77211,77237]
comparison [77223,77249]
===
match
---
name: path [15788,15792]
name: path [15788,15792]
===
match
---
name: self [52089,52093]
name: self [52089,52093]
===
match
---
operator: , [26768,26769]
operator: , [26768,26769]
===
match
---
funcdef [3360,3943]
funcdef [3360,3943]
===
match
---
trailer [47572,47577]
trailer [47572,47577]
===
match
---
with_item [4394,4422]
with_item [4394,4422]
===
match
---
atom_expr [11263,11295]
atom_expr [11263,11295]
===
match
---
operator: = [36852,36853]
operator: = [36852,36853]
===
match
---
operator: = [10481,10482]
operator: = [10481,10482]
===
match
---
name: session [36033,36040]
name: session [36033,36040]
===
match
---
name: log [41399,41402]
name: log [41399,41402]
===
match
---
simple_stmt [10929,10972]
simple_stmt [10929,10972]
===
match
---
parameters [79869,79875]
parameters [79881,79887]
===
match
---
string: '-' [59793,59796]
string: '-' [59805,59808]
===
match
---
string: 'dag_run_conf_overrides_params' [59970,60001]
string: 'dag_run_conf_overrides_params' [59982,60013]
===
match
---
atom [75262,75308]
atom [75274,75320]
===
match
---
name: self [42629,42633]
name: self [42629,42633]
===
match
---
string: "Webserver does not have access to User-defined Macros or Filters " [64948,65015]
string: "Webserver does not have access to User-defined Macros or Filters " [64960,65027]
===
match
---
operator: , [20511,20512]
operator: , [20511,20512]
===
match
---
simple_stmt [1260,1358]
simple_stmt [1260,1358]
===
match
---
operator: = [28173,28174]
operator: = [28173,28174]
===
match
---
name: task [44247,44251]
name: task [44247,44251]
===
match
---
arglist [20173,20196]
arglist [20173,20196]
===
match
---
operator: , [11868,11869]
operator: , [11868,11869]
===
match
---
trailer [62282,62288]
trailer [62294,62300]
===
match
---
string: 'execution_date' [62829,62845]
string: 'execution_date' [62841,62857]
===
match
---
name: self [74620,74624]
name: self [74632,74636]
===
match
---
name: self [44139,44143]
name: self [44139,44143]
===
match
---
expr_stmt [59268,59289]
expr_stmt [59280,59301]
===
match
---
string: 'value' [64095,64102]
string: 'value' [64107,64114]
===
match
---
name: provide_session [29982,29997]
name: provide_session [29982,29997]
===
match
---
simple_stmt [23953,24003]
simple_stmt [23953,24003]
===
match
---
comparison [28593,28612]
comparison [28593,28612]
===
match
---
name: min [35471,35474]
name: min [35471,35474]
===
match
---
expr_stmt [68006,68325]
expr_stmt [68018,68337]
===
match
---
name: execution_date [58712,58726]
name: execution_date [58724,58738]
===
match
---
simple_stmt [39879,39915]
simple_stmt [39879,39915]
===
match
---
name: self [79234,79238]
name: self [79246,79250]
===
match
---
operator: = [59283,59284]
operator: = [59295,59296]
===
match
---
expr_stmt [78621,78668]
expr_stmt [78633,78680]
===
match
---
atom_expr [18917,18947]
atom_expr [18917,18947]
===
match
---
sync_comp_for [8467,8511]
sync_comp_for [8467,8511]
===
match
---
name: ignore_depends_on_past [40505,40527]
name: ignore_depends_on_past [40505,40527]
===
match
---
name: prev_ti [30526,30533]
name: prev_ti [30526,30533]
===
match
---
number: 1 [55270,55271]
number: 1 [55282,55283]
===
match
---
name: info [41403,41407]
name: info [41403,41407]
===
match
---
name: self [69112,69116]
name: self [69124,69128]
===
match
---
name: NamedTuple [8787,8797]
name: NamedTuple [8787,8797]
===
match
---
return_stmt [75321,75348]
return_stmt [75333,75360]
===
match
---
simple_stmt [59521,59553]
simple_stmt [59533,59565]
===
match
---
or_test [33338,33365]
or_test [33338,33365]
===
match
---
trailer [26890,26898]
trailer [26890,26898]
===
match
---
trailer [46207,46216]
trailer [46207,46216]
===
match
---
simple_stmt [42128,42196]
simple_stmt [42128,42196]
===
match
---
number: 2 [29906,29907]
number: 2 [29906,29907]
===
match
---
simple_stmt [3635,3649]
simple_stmt [3635,3649]
===
match
---
name: rendered_k8s_spec [65881,65898]
name: rendered_k8s_spec [65893,65910]
===
match
---
name: dag [15605,15608]
name: dag [15605,15608]
===
match
---
name: self [56168,56172]
name: self [56180,56184]
===
match
---
trailer [45027,45043]
trailer [45027,45043]
===
match
---
name: task_reschedule [40139,40154]
name: task_reschedule [40139,40154]
===
match
---
name: XCom [24590,24594]
name: XCom [24590,24594]
===
match
---
arglist [55231,55274]
arglist [55243,55286]
===
match
---
name: error [56985,56990]
name: error [56997,57002]
===
match
---
name: self [54253,54257]
name: self [54253,54257]
===
match
---
param [46487,46491]
param [46487,46491]
===
match
---
trailer [19976,19984]
trailer [19976,19984]
===
match
---
trailer [24527,24534]
trailer [24527,24534]
===
match
---
name: TR [7040,7042]
name: TR [7040,7042]
===
match
---
name: airflow [2439,2446]
name: airflow [2439,2446]
===
match
---
operator: = [23003,23004]
operator: = [23003,23004]
===
match
---
trailer [42179,42194]
trailer [42179,42194]
===
match
---
name: self [23220,23224]
name: self [23220,23224]
===
match
---
name: models [57699,57705]
name: models [57711,57717]
===
match
---
trailer [45408,45410]
trailer [45408,45410]
===
match
---
simple_stmt [51040,51069]
simple_stmt [51040,51069]
===
match
---
classdef [78128,80848]
classdef [78140,80860]
===
match
---
name: activate_dag_runs [4717,4734]
name: activate_dag_runs [4717,4734]
===
match
---
name: dag_run [57980,57987]
name: dag_run [57992,57999]
===
match
---
parameters [50274,50304]
parameters [50274,50304]
===
match
---
operator: , [59796,59797]
operator: , [59808,59809]
===
match
---
suite [32808,33053]
suite [32808,33053]
===
match
---
atom_expr [13000,13013]
atom_expr [13000,13013]
===
match
---
name: job_ids [7492,7499]
name: job_ids [7492,7499]
===
match
---
name: task [46126,46130]
name: task [46126,46130]
===
match
---
import_from [1202,1259]
import_from [1202,1259]
===
match
---
trailer [35611,35627]
trailer [35611,35627]
===
match
---
trailer [70120,70134]
trailer [70132,70146]
===
match
---
atom_expr [66183,66195]
atom_expr [66195,66207]
===
match
---
simple_stmt [49824,49868]
simple_stmt [49824,49868]
===
match
---
name: Optional [71370,71378]
name: Optional [71382,71390]
===
match
---
arglist [70070,70082]
arglist [70082,70094]
===
match
---
name: extend [18921,18927]
name: extend [18921,18927]
===
match
---
name: get_failed_dep_statuses [33215,33238]
name: get_failed_dep_statuses [33215,33238]
===
match
---
name: self [54858,54862]
name: self [54870,54874]
===
match
---
simple_stmt [23137,23174]
simple_stmt [23137,23174]
===
match
---
simple_stmt [57547,57562]
simple_stmt [57559,57574]
===
match
---
name: start_date [71051,71061]
name: start_date [71063,71073]
===
match
---
name: context [49851,49858]
name: context [49851,49858]
===
match
---
name: get_email_subject_content [67441,67466]
name: get_email_subject_content [67453,67478]
===
match
---
name: session [49271,49278]
name: session [49271,49278]
===
match
---
operator: = [47293,47294]
operator: = [47293,47294]
===
match
---
tfpdef [36597,36618]
tfpdef [36597,36618]
===
match
---
atom_expr [69061,69076]
atom_expr [69073,69088]
===
match
---
trailer [75782,75789]
trailer [75794,75801]
===
match
---
tfpdef [16569,16597]
tfpdef [16569,16597]
===
match
---
name: self [79518,79522]
name: self [79530,79534]
===
match
---
fstring_expr [19971,19985]
fstring_expr [19971,19985]
===
match
---
string: 'task_instance' [63669,63684]
string: 'task_instance' [63681,63696]
===
match
---
trailer [46940,46948]
trailer [46940,46948]
===
match
---
atom_expr [38555,38569]
atom_expr [38555,38569]
===
match
---
name: self [47925,47929]
name: self [47925,47929]
===
match
---
name: info [54262,54266]
name: info [54262,54266]
===
match
---
atom_expr [46635,46663]
atom_expr [46635,46663]
===
match
---
trailer [23292,23301]
trailer [23292,23301]
===
match
---
name: str [36847,36850]
name: str [36847,36850]
===
match
---
operator: , [29849,29850]
operator: , [29849,29850]
===
match
---
trailer [58300,58309]
trailer [58312,58321]
===
match
---
string: '%Y%m%dT%H%M%S' [42350,42365]
string: '%Y%m%dT%H%M%S' [42350,42365]
===
match
---
name: dr [28228,28230]
name: dr [28228,28230]
===
match
---
with_stmt [4389,4663]
with_stmt [4389,4663]
===
match
---
trailer [57216,57224]
trailer [57228,57236]
===
match
---
return_stmt [9285,9384]
return_stmt [9285,9384]
===
match
---
atom_expr [51985,51998]
atom_expr [51985,51998]
===
match
---
name: UtcDateTime [10660,10671]
name: UtcDateTime [10660,10671]
===
match
---
trailer [22344,22359]
trailer [22344,22359]
===
match
---
name: strftime [42341,42349]
name: strftime [42341,42349]
===
match
---
atom_expr [49683,49710]
atom_expr [49683,49710]
===
match
---
trailer [55432,55436]
trailer [55444,55448]
===
match
---
decorated [26996,28953]
decorated [26996,28953]
===
match
---
simple_stmt [23911,23945]
simple_stmt [23911,23945]
===
match
---
trailer [21566,21572]
trailer [21566,21572]
===
match
---
testlist_comp [45169,45211]
testlist_comp [45169,45211]
===
match
---
operator: , [75560,75561]
operator: , [75572,75573]
===
match
---
name: task [51085,51089]
name: task [51085,51089]
===
match
---
trailer [53636,53649]
trailer [53636,53649]
===
match
---
simple_stmt [11824,12014]
simple_stmt [11824,12014]
===
match
---
arith_expr [42467,42593]
arith_expr [42467,42593]
===
match
---
simple_stmt [60533,60563]
simple_stmt [60545,60575]
===
match
---
atom_expr [62847,62885]
atom_expr [62859,62897]
===
match
---
trailer [55230,55275]
trailer [55242,55287]
===
match
---
simple_stmt [8057,8123]
simple_stmt [8057,8123]
===
match
---
suite [50505,50579]
suite [50505,50579]
===
match
---
name: close [53059,53064]
name: close [53059,53064]
===
match
---
operator: = [60078,60079]
operator: = [60090,60091]
===
match
---
string: """Functions that need to be run before a Task is executed""" [50314,50375]
string: """Functions that need to be run before a Task is executed""" [50314,50375]
===
match
---
decorator [72590,72607]
decorator [72602,72619]
===
match
---
trailer [25571,25580]
trailer [25571,25580]
===
match
---
name: hr_line_break [41188,41201]
name: hr_line_break [41188,41201]
===
match
---
decorator [8938,8948]
decorator [8938,8948]
===
match
---
operator: = [27098,27099]
operator: = [27098,27099]
===
match
---
name: session [28915,28922]
name: session [28915,28922]
===
match
---
name: ApiClient [3041,3050]
name: ApiClient [3041,3050]
===
match
---
decorated [13402,13582]
decorated [13402,13582]
===
match
---
name: self [78382,78386]
name: self [78394,78398]
===
match
---
operator: -> [27111,27113]
operator: -> [27111,27113]
===
match
---
name: self [53305,53309]
name: self [53305,53309]
===
match
---
name: last_dagrun [28752,28763]
name: last_dagrun [28752,28763]
===
match
---
trailer [12655,12663]
trailer [12655,12663]
===
match
---
parameters [24748,24754]
parameters [24748,24754]
===
match
---
name: job_id [43015,43021]
name: job_id [43015,43021]
===
match
---
name: TaskInstance [26670,26682]
name: TaskInstance [26670,26682]
===
match
---
expr_stmt [35535,35586]
expr_stmt [35535,35586]
===
match
---
expr_stmt [23953,24002]
expr_stmt [23953,24002]
===
match
---
atom_expr [69227,69277]
atom_expr [69239,69289]
===
match
---
name: previous_ti [28976,28987]
name: previous_ti [28976,28987]
===
match
---
name: dag [5532,5535]
name: dag [5532,5535]
===
match
---
simple_stmt [68006,68326]
simple_stmt [68018,68338]
===
match
---
name: orm [1374,1377]
name: orm [1374,1377]
===
match
---
name: task_id [6314,6321]
name: task_id [6314,6321]
===
match
---
name: task_ids [75299,75307]
name: task_ids [75311,75319]
===
match
---
name: provide_session [72591,72606]
name: provide_session [72603,72618]
===
match
---
name: self [53406,53410]
name: self [53406,53410]
===
match
---
operator: + [5732,5733]
operator: + [5732,5733]
===
match
---
name: self [53884,53888]
name: self [53884,53888]
===
match
---
name: utils [2923,2928]
name: utils [2923,2928]
===
match
---
funcdef [79624,79673]
funcdef [79636,79685]
===
match
---
name: ID_LEN [10425,10431]
name: ID_LEN [10425,10431]
===
match
---
simple_stmt [53050,53067]
simple_stmt [53050,53067]
===
match
---
name: where [7430,7435]
name: where [7430,7435]
===
match
---
name: get [20169,20172]
name: get [20169,20172]
===
match
---
trailer [6272,6291]
trailer [6272,6291]
===
match
---
param [72648,72701]
param [72660,72713]
===
match
---
param [80064,80077]
param [80076,80089]
===
match
---
operator: = [52501,52502]
operator: = [52501,52502]
===
match
---
param [43131,43144]
param [43131,43144]
===
match
---
not_test [27545,27551]
not_test [27545,27551]
===
match
---
name: test_mode [56846,56855]
name: test_mode [56858,56867]
===
match
---
name: Variable [60544,60552]
name: Variable [60556,60564]
===
match
---
atom_expr [47314,47386]
atom_expr [47314,47386]
===
match
---
atom_expr [5394,5402]
atom_expr [5394,5402]
===
match
---
trailer [9109,9124]
trailer [9109,9124]
===
match
---
simple_stmt [10706,10733]
simple_stmt [10706,10733]
===
match
---
atom_expr [72121,72140]
atom_expr [72133,72152]
===
match
---
simple_stmt [1894,1943]
simple_stmt [1894,1943]
===
match
---
trailer [34832,34843]
trailer [34832,34843]
===
match
---
suite [18904,18948]
suite [18904,18948]
===
match
---
if_stmt [19261,19341]
if_stmt [19261,19341]
===
match
---
arglist [29178,29388]
arglist [29178,29388]
===
match
---
operator: = [75260,75261]
operator: = [75272,75273]
===
match
---
trailer [49260,49262]
trailer [49260,49262]
===
match
---
atom [45753,45782]
atom [45753,45782]
===
match
---
arglist [42467,42842]
arglist [42467,42842]
===
match
---
name: self [19757,19761]
name: self [19757,19761]
===
match
---
name: self [71167,71171]
name: self [71179,71183]
===
match
---
suite [45824,45920]
suite [45824,45920]
===
match
---
expr_stmt [23137,23173]
expr_stmt [23137,23173]
===
match
---
fstring_string: &dag_id= [20302,20310]
fstring_string: &dag_id= [20302,20310]
===
match
---
decorator [56731,56748]
decorator [56743,56760]
===
match
---
name: get [60553,60556]
name: get [60565,60568]
===
match
---
trailer [21058,21073]
trailer [21058,21073]
===
match
---
operator: , [40438,40439]
operator: , [40438,40439]
===
match
---
suite [55065,55116]
suite [55077,55128]
===
match
---
name: self [66950,66954]
name: self [66962,66966]
===
match
---
atom [36292,36454]
atom [36292,36454]
===
match
---
argument [61862,61883]
argument [61874,61895]
===
match
---
name: incr [49020,49024]
name: incr [49020,49024]
===
match
---
name: rendered_value [64631,64645]
name: rendered_value [64643,64657]
===
match
---
tfpdef [51678,51691]
tfpdef [51678,51691]
===
match
---
name: dag [5524,5527]
name: dag [5524,5527]
===
match
---
simple_stmt [34528,34611]
simple_stmt [34528,34611]
===
match
---
atom_expr [80648,80675]
atom_expr [80660,80687]
===
match
---
operator: == [80676,80678]
operator: == [80688,80690]
===
match
---
trailer [58216,58219]
trailer [58228,58231]
===
match
---
trailer [49842,49850]
trailer [49842,49850]
===
match
---
dotted_name [2362,2395]
dotted_name [2362,2395]
===
match
---
name: Optional [36838,36846]
name: Optional [36838,36846]
===
match
---
name: self [41663,41667]
name: self [41663,41667]
===
match
---
name: DepContext [39037,39047]
name: DepContext [39037,39047]
===
match
---
name: defaultdict [8150,8161]
name: defaultdict [8150,8161]
===
match
---
name: models [2138,2144]
name: models [2138,2144]
===
match
---
atom_expr [19215,19252]
atom_expr [19215,19252]
===
match
---
trailer [15863,15870]
trailer [15863,15870]
===
match
---
operator: = [52641,52642]
operator: = [52641,52642]
===
match
---
name: t [77211,77212]
name: t [77223,77224]
===
match
---
trailer [6313,6321]
trailer [6313,6321]
===
match
---
name: pool [79628,79632]
name: pool [79640,79644]
===
match
---
name: self [39348,39352]
name: self [39348,39352]
===
match
---
simple_stmt [46053,46059]
simple_stmt [46053,46059]
===
match
---
name: previous_ti_success [29460,29479]
name: previous_ti_success [29460,29479]
===
match
---
simple_stmt [5202,5215]
simple_stmt [5202,5215]
===
match
---
simple_stmt [58070,58116]
simple_stmt [58082,58128]
===
match
---
atom_expr [18789,18815]
atom_expr [18789,18815]
===
match
---
name: provide_session [21610,21625]
name: provide_session [21610,21625]
===
match
---
name: TaskInstanceKey [76157,76172]
name: TaskInstanceKey [76169,76184]
===
match
---
param [36597,36627]
param [36597,36627]
===
match
---
import_from [1978,2022]
import_from [1978,2022]
===
match
---
simple_stmt [52052,52075]
simple_stmt [52052,52075]
===
match
---
name: local [16178,16183]
name: local [16178,16183]
===
match
---
trailer [81086,81094]
trailer [81098,81106]
===
match
---
atom_expr [58939,58958]
atom_expr [58951,58970]
===
match
---
suite [76957,77173]
suite [76969,77185]
===
match
---
atom_expr [78811,78821]
atom_expr [78823,78833]
===
match
---
trailer [79186,79195]
trailer [79198,79207]
===
match
---
name: dep_context [32570,32581]
name: dep_context [32570,32581]
===
match
---
trailer [19852,19854]
trailer [19852,19854]
===
match
---
trailer [76059,76072]
trailer [76071,76084]
===
match
---
string: """         Clears all XCom data from the database for the task instance          :param session: SQLAlchemy ORM Session         :type session: Session         """ [24251,24414]
string: """         Clears all XCom data from the database for the task instance          :param session: SQLAlchemy ORM Session         :type session: Session         """ [24251,24414]
===
match
---
operator: -> [30708,30710]
operator: -> [30708,30710]
===
match
---
atom_expr [6177,6200]
atom_expr [6177,6200]
===
match
---
suite [66272,66453]
suite [66284,66465]
===
match
---
simple_stmt [13305,13322]
simple_stmt [13305,13322]
===
match
---
name: error [57089,57094]
name: error [57101,57106]
===
match
---
trailer [64926,65272]
trailer [64938,65284]
===
match
---
trailer [55174,55181]
trailer [55186,55193]
===
match
---
name: first [40057,40062]
name: first [40057,40062]
===
match
---
import_from [2476,2510]
import_from [2476,2510]
===
match
---
string: """         Get the very latest state from the database, if a session is passed,         we use and looking up the state becomes part of the session, otherwise         a new session is used.          :param session: SQLAlchemy ORM Session         :type session: Session         """ [20543,20824]
string: """         Get the very latest state from the database, if a session is passed,         we use and looking up the state becomes part of the session, otherwise         a new session is used.          :param session: SQLAlchemy ORM Session         :type session: Session         """ [20543,20824]
===
match
---
atom_expr [70160,70170]
atom_expr [70172,70182]
===
match
---
name: TaskFail [2014,2022]
name: TaskFail [2014,2022]
===
match
---
return_stmt [79350,79373]
return_stmt [79362,79385]
===
match
---
name: airflow [1983,1990]
name: airflow [1983,1990]
===
match
---
param [16438,16451]
param [16438,16451]
===
match
---
string: "-" [38816,38819]
string: "-" [38816,38819]
===
match
---
import_as_names [1221,1259]
import_as_names [1221,1259]
===
match
---
atom_expr [25272,25334]
atom_expr [25272,25334]
===
match
---
name: query [36314,36319]
name: query [36314,36319]
===
match
---
name: self [41771,41775]
name: self [41771,41775]
===
match
---
param [46730,46735]
param [46730,46735]
===
match
---
name: str [16885,16888]
name: str [16885,16888]
===
match
---
name: default_var [61837,61848]
name: default_var [61849,61860]
===
match
---
operator: = [20162,20163]
operator: = [20162,20163]
===
match
---
arglist [72298,72333]
arglist [72310,72345]
===
match
---
simple_stmt [23105,23125]
simple_stmt [23105,23125]
===
match
---
operator: @ [35991,35992]
operator: @ [35991,35992]
===
match
---
atom_expr [62865,62884]
atom_expr [62877,62896]
===
match
---
operator: , [60069,60070]
operator: , [60081,60082]
===
match
---
string: 'tomorrow_ds_nodash' [63858,63878]
string: 'tomorrow_ds_nodash' [63870,63890]
===
match
---
name: ti [5325,5327]
name: ti [5325,5327]
===
match
---
expr_stmt [75239,75308]
expr_stmt [75251,75320]
===
match
---
operator: = [57960,57961]
operator: = [57972,57973]
===
match
---
arglist [11858,12007]
arglist [11858,12007]
===
match
---
atom_expr [52643,52674]
atom_expr [52643,52674]
===
match
---
name: ti [78277,78279]
name: ti [78289,78291]
===
match
---
argument [45875,45896]
argument [45875,45896]
===
match
---
simple_stmt [67799,67841]
simple_stmt [67811,67853]
===
match
---
operator: - [69077,69078]
operator: - [69089,69090]
===
match
---
tfpdef [4759,4800]
tfpdef [4759,4800]
===
match
---
name: info [44618,44622]
name: info [44618,44622]
===
match
---
string: 'Rescheduling task, marking task as UP_FOR_RESCHEDULE' [54267,54321]
string: 'Rescheduling task, marking task as UP_FOR_RESCHEDULE' [54267,54321]
===
match
---
fstring [20337,20361]
fstring [20337,20361]
===
match
---
trailer [24878,24943]
trailer [24878,24943]
===
match
---
tfpdef [12044,12068]
tfpdef [12044,12068]
===
match
---
operator: = [51411,51412]
operator: = [51411,51412]
===
match
---
trailer [66717,67294]
trailer [66729,67306]
===
match
---
name: self [20940,20944]
name: self [20940,20944]
===
match
---
expr_stmt [8132,8166]
expr_stmt [8132,8166]
===
match
---
param [54377,54382]
param [54377,54382]
===
match
---
tfpdef [51793,51815]
tfpdef [51793,51815]
===
match
---
atom_expr [41757,41776]
atom_expr [41757,41776]
===
match
---
name: log [32701,32704]
name: log [32701,32704]
===
match
---
trailer [66150,66155]
trailer [66162,66167]
===
match
---
atom_expr [41431,41510]
atom_expr [41431,41510]
===
match
---
name: update [47754,47760]
name: update [47754,47760]
===
match
---
param [36553,36558]
param [36553,36558]
===
match
---
simple_stmt [78342,78374]
simple_stmt [78354,78386]
===
match
---
simple_stmt [76032,76047]
simple_stmt [76044,76059]
===
match
---
argument [28159,28195]
argument [28159,28195]
===
match
---
trailer [22922,22934]
trailer [22922,22934]
===
match
---
operator: = [11512,11513]
operator: = [11512,11513]
===
match
---
operator: , [16520,16521]
operator: , [16520,16521]
===
match
---
operator: = [3685,3686]
operator: = [3685,3686]
===
match
---
string: "Failed to register in sensor service." [48326,48365]
string: "Failed to register in sensor service." [48326,48365]
===
match
---
trailer [19548,19555]
trailer [19548,19555]
===
match
---
funcdef [61498,61555]
funcdef [61510,61567]
===
match
---
name: e [65278,65279]
name: e [65290,65291]
===
match
---
name: self [34196,34200]
name: self [34196,34200]
===
match
---
operator: = [40005,40006]
operator: = [40005,40006]
===
match
---
trailer [77679,77687]
trailer [77691,77699]
===
match
---
trailer [10881,10895]
trailer [10881,10895]
===
match
---
name: dag_id [12154,12160]
name: dag_id [12154,12160]
===
match
---
decorator [30585,30602]
decorator [30585,30602]
===
match
---
name: jinja_env [69331,69340]
name: jinja_env [69343,69352]
===
match
---
atom_expr [55252,55266]
atom_expr [55264,55278]
===
match
---
simple_stmt [6073,6131]
simple_stmt [6073,6131]
===
match
---
name: frame [46730,46735]
name: frame [46730,46735]
===
match
---
name: params [57483,57489]
name: params [57495,57501]
===
match
---
name: clear_xcom_data [47044,47059]
name: clear_xcom_data [47044,47059]
===
match
---
name: session [39440,39447]
name: session [39440,39447]
===
match
---
simple_stmt [45388,45411]
simple_stmt [45388,45411]
===
match
---
name: session [28709,28716]
name: session [28709,28716]
===
match
---
operator: = [51498,51499]
operator: = [51498,51499]
===
match
---
name: TaskInstance [75861,75873]
name: TaskInstance [75873,75885]
===
match
---
suite [44816,44850]
suite [44816,44850]
===
match
---
trailer [44846,44849]
trailer [44846,44849]
===
match
---
operator: { [62670,62671]
operator: { [62682,62683]
===
match
---
atom_expr [77861,77880]
atom_expr [77873,77892]
===
match
---
operator: = [51565,51566]
operator: = [51565,51566]
===
match
---
atom_expr [10839,10859]
atom_expr [10839,10859]
===
match
---
name: self [14301,14305]
name: self [14301,14305]
===
match
---
expr_stmt [79031,79049]
expr_stmt [79043,79061]
===
match
---
if_stmt [70051,70220]
if_stmt [70063,70232]
===
match
---
trailer [41495,41505]
trailer [41495,41505]
===
match
---
name: self [46357,46361]
name: self [46357,46361]
===
match
---
atom_expr [78604,78612]
atom_expr [78616,78624]
===
match
---
number: 1 [9360,9361]
number: 1 [9360,9361]
===
match
---
name: dag_run_state [7983,7996]
name: dag_run_state [7983,7996]
===
match
---
name: TaskInstanceKey [24863,24878]
name: TaskInstanceKey [24863,24878]
===
match
---
name: TaskInstance [77294,77306]
name: TaskInstance [77306,77318]
===
match
---
decorated [14818,14933]
decorated [14818,14933]
===
match
---
simple_stmt [66650,66677]
simple_stmt [66662,66689]
===
match
---
name: conf [20164,20168]
name: conf [20164,20168]
===
match
---
operator: , [52843,52844]
operator: , [52843,52844]
===
match
---
name: timezone [55166,55174]
name: timezone [55178,55186]
===
match
---
name: self [36403,36407]
name: self [36403,36407]
===
match
---
name: ti [78519,78521]
name: ti [78531,78533]
===
match
---
name: dag_id [77022,77028]
name: dag_id [77034,77040]
===
match
---
string: '' [59680,59682]
string: '' [59692,59694]
===
match
---
expr_stmt [57765,57940]
expr_stmt [57777,57952]
===
match
---
name: DepContext [2346,2356]
name: DepContext [2346,2356]
===
match
---
name: items [47706,47711]
name: items [47706,47711]
===
match
---
trailer [33924,33939]
trailer [33924,33939]
===
match
---
trailer [26964,26990]
trailer [26964,26990]
===
match
---
operator: , [25326,25327]
operator: , [25326,25327]
===
match
---
atom_expr [76624,76644]
atom_expr [76636,76656]
===
match
---
suite [8799,9771]
suite [8799,9771]
===
match
---
name: drs [8591,8594]
name: drs [8591,8594]
===
match
---
argument [30494,30509]
argument [30494,30509]
===
match
---
name: TR [40007,40009]
name: TR [40007,40009]
===
match
---
expr_stmt [41663,41689]
expr_stmt [41663,41689]
===
match
---
atom_expr [50633,50654]
atom_expr [50633,50654]
===
match
---
name: property [79927,79935]
name: property [79939,79947]
===
match
---
trailer [7732,7936]
trailer [7732,7936]
===
match
---
atom_expr [47157,47195]
atom_expr [47157,47195]
===
match
---
name: result [48779,48785]
name: result [48779,48785]
===
match
---
operator: , [9361,9362]
operator: , [9361,9362]
===
match
---
atom_expr [56630,56640]
atom_expr [56642,56652]
===
match
---
atom_expr [25343,25353]
atom_expr [25343,25353]
===
match
---
simple_stmt [70638,70689]
simple_stmt [70650,70701]
===
match
---
name: bool [56900,56904]
name: bool [56912,56916]
===
match
---
name: uselist [11969,11976]
name: uselist [11969,11976]
===
match
---
trailer [33726,33733]
trailer [33726,33733]
===
match
---
param [15110,15132]
param [15110,15132]
===
match
---
operator: , [53468,53469]
operator: , [53468,53469]
===
match
---
fstring_expr [20272,20286]
fstring_expr [20272,20286]
===
match
---
operator: = [46633,46634]
operator: = [46633,46634]
===
match
---
suite [28637,28718]
suite [28637,28718]
===
match
---
atom_expr [57248,57262]
atom_expr [57260,57274]
===
match
---
suite [77252,77474]
suite [77264,77486]
===
match
---
simple_stmt [77265,77474]
simple_stmt [77277,77486]
===
match
---
trailer [36369,36376]
trailer [36369,36376]
===
match
---
funcdef [21630,23481]
funcdef [21630,23481]
===
match
---
expr_stmt [58969,58983]
expr_stmt [58981,58995]
===
match
---
trailer [49196,49202]
trailer [49196,49202]
===
match
---
trailer [24568,24576]
trailer [24568,24576]
===
match
---
name: dag_id [66731,66737]
name: dag_id [66743,66749]
===
match
---
tfpdef [36830,36851]
tfpdef [36830,36851]
===
match
---
decorator [75500,75517]
decorator [75512,75529]
===
match
---
name: end_date [55495,55503]
name: end_date [55507,55515]
===
match
---
name: dag [5578,5581]
name: dag [5578,5581]
===
match
---
name: TaskInstance [81051,81063]
name: TaskInstance [81063,81075]
===
match
---
suite [19532,19567]
suite [19532,19567]
===
match
---
expr_stmt [78382,78432]
expr_stmt [78394,78444]
===
match
---
atom [19681,19705]
atom [19681,19705]
===
match
---
name: signal_handler [46707,46721]
name: signal_handler [46707,46721]
===
match
---
name: Column [10808,10814]
name: Column [10808,10814]
===
match
---
simple_stmt [54228,54245]
simple_stmt [54228,54245]
===
match
---
trailer [77515,77520]
trailer [77527,77532]
===
match
---
name: task [23929,23933]
name: task [23929,23933]
===
match
---
name: dagrun [36232,36238]
name: dagrun [36232,36238]
===
match
---
name: dag_run [57547,57554]
name: dag_run [57559,57566]
===
match
---
name: conf [66151,66155]
name: conf [66163,66167]
===
match
---
name: PodGenerator [67044,67056]
name: PodGenerator [67056,67068]
===
match
---
operator: , [1303,1304]
operator: , [1303,1304]
===
match
---
trailer [52661,52674]
trailer [52661,52674]
===
match
---
operator: = [21663,21664]
operator: = [21663,21664]
===
match
---
expr_stmt [22947,22976]
expr_stmt [22947,22976]
===
match
---
name: ti [77955,77957]
name: ti [77967,77969]
===
match
---
suite [45552,45920]
suite [45552,45920]
===
match
---
operator: += [41573,41575]
operator: += [41573,41575]
===
match
---
name: next_ds_nodash [59121,59135]
name: next_ds_nodash [59133,59147]
===
match
---
name: dr [36471,36473]
name: dr [36471,36473]
===
match
---
expr_stmt [41219,41255]
expr_stmt [41219,41255]
===
match
---
name: RUNNING_DEPS [39070,39082]
name: RUNNING_DEPS [39070,39082]
===
match
---
trailer [30072,30077]
trailer [30072,30077]
===
match
---
name: is_eligible_to_retry [56132,56152]
name: is_eligible_to_retry [56144,56164]
===
match
---
operator: @ [31821,31822]
operator: @ [31821,31822]
===
match
---
name: pickle [4449,4455]
name: pickle [4449,4455]
===
match
---
name: datetime [12060,12068]
name: datetime [12060,12068]
===
match
---
atom_expr [11524,11560]
atom_expr [11524,11560]
===
match
---
name: property [25667,25675]
name: property [25667,25675]
===
match
---
name: ti [21153,21155]
name: ti [21153,21155]
===
match
---
operator: , [70422,70423]
operator: , [70434,70435]
===
match
---
name: task_id [9326,9333]
name: task_id [9326,9333]
===
match
---
suite [27420,28932]
suite [27420,28932]
===
match
---
name: prev_attempted_tries [6109,6129]
name: prev_attempted_tries [6109,6129]
===
match
---
operator: , [15195,15196]
operator: , [15195,15196]
===
match
---
trailer [26794,26809]
trailer [26794,26809]
===
match
---
atom_expr [58707,58726]
atom_expr [58719,58738]
===
match
---
name: datetime [942,950]
name: datetime [942,950]
===
match
---
name: queue [23837,23842]
name: queue [23837,23842]
===
match
---
simple_stmt [41785,41802]
simple_stmt [41785,41802]
===
match
---
name: context [3888,3895]
name: context [3888,3895]
===
match
---
argument [11005,11014]
argument [11005,11014]
===
match
---
name: context [51612,51619]
name: context [51612,51619]
===
match
---
atom_expr [9308,9319]
atom_expr [9308,9319]
===
match
---
name: globals [80870,80877]
name: globals [80882,80889]
===
match
---
name: self [71238,71242]
name: self [71250,71254]
===
match
---
name: self [36365,36369]
name: self [36365,36369]
===
match
---
string: """         This attribute is deprecated.         Please use `airflow.models.taskinstance.TaskInstance.get_previous_start_date` method.         """ [31339,31486]
string: """         This attribute is deprecated.         Please use `airflow.models.taskinstance.TaskInstance.get_previous_start_date` method.         """ [31339,31486]
===
match
---
funcdef [36500,42216]
funcdef [36500,42216]
===
match
---
operator: { [33919,33920]
operator: { [33919,33920]
===
match
---
operator: == [77221,77223]
operator: == [77233,77235]
===
match
---
suite [49728,49868]
suite [49728,49868]
===
match
---
name: try_number [22907,22917]
name: try_number [22907,22917]
===
match
---
trailer [12476,12484]
trailer [12476,12484]
===
match
---
trailer [26868,26900]
trailer [26868,26900]
===
match
---
trailer [29164,29398]
trailer [29164,29398]
===
match
---
name: warn [29680,29684]
name: warn [29680,29684]
===
match
---
trailer [16848,16853]
trailer [16848,16853]
===
match
---
operator: , [16896,16897]
operator: , [16896,16897]
===
match
---
name: execution_date [12860,12874]
name: execution_date [12860,12874]
===
match
---
name: execution_date [72126,72140]
name: execution_date [72138,72152]
===
match
---
if_stmt [77483,77999]
if_stmt [77495,78011]
===
match
---
argument [10956,10970]
argument [10956,10970]
===
match
---
operator: = [31898,31899]
operator: = [31898,31899]
===
match
---
name: datetime [78459,78467]
name: datetime [78471,78479]
===
match
---
tfpdef [16906,16929]
tfpdef [16906,16929]
===
match
---
expr_stmt [35018,35067]
expr_stmt [35018,35067]
===
match
---
name: get_template_env [69977,69993]
name: get_template_env [69989,70005]
===
match
---
trailer [22310,22318]
trailer [22310,22318]
===
match
---
name: get_previous_start_date [63541,63564]
name: get_previous_start_date [63553,63576]
===
match
---
name: XCom [24548,24552]
name: XCom [24548,24552]
===
match
---
exprlist [64619,64645]
exprlist [64631,64657]
===
match
---
string: '%Y-%m-%d' [58310,58320]
string: '%Y-%m-%d' [58322,58332]
===
match
---
suite [19422,19459]
suite [19422,19459]
===
match
---
operator: = [45467,45468]
operator: = [45467,45468]
===
match
---
suite [52540,52606]
suite [52540,52606]
===
match
---
simple_stmt [38792,38840]
simple_stmt [38792,38840]
===
match
---
parameters [50610,50663]
parameters [50610,50663]
===
match
---
name: max_tries [6095,6104]
name: max_tries [6095,6104]
===
match
---
argument [16335,16352]
argument [16335,16352]
===
match
---
name: ignore_task_deps [39280,39296]
name: ignore_task_deps [39280,39296]
===
match
---
simple_stmt [2023,2080]
simple_stmt [2023,2080]
===
match
---
name: error [4300,4305]
name: error [4300,4305]
===
match
---
atom_expr [30064,30077]
atom_expr [30064,30077]
===
match
---
name: execution_date [72085,72099]
name: execution_date [72097,72111]
===
match
---
name: kubernetes [66562,66572]
name: kubernetes [66574,66584]
===
match
---
name: airflow_context_vars [47472,47492]
name: airflow_context_vars [47472,47492]
===
match
---
simple_stmt [44339,44377]
simple_stmt [44339,44377]
===
match
---
name: pool [19470,19474]
name: pool [19470,19474]
===
match
---
trailer [79272,79288]
trailer [79284,79300]
===
match
---
name: log [49134,49137]
name: log [49134,49137]
===
match
---
name: task [63651,63655]
name: task [63663,63667]
===
match
---
argument [10781,10790]
argument [10781,10790]
===
match
---
atom_expr [8608,8616]
atom_expr [8608,8616]
===
match
---
funcdef [79862,79921]
funcdef [79874,79933]
===
match
---
name: provide_session [54329,54344]
name: provide_session [54329,54344]
===
match
---
name: execution_date [78418,78432]
name: execution_date [78430,78444]
===
match
---
comparison [80597,80634]
comparison [80609,80646]
===
match
---
trailer [44837,44841]
trailer [44837,44841]
===
match
---
expr_stmt [32570,32611]
expr_stmt [32570,32611]
===
match
---
name: items [7162,7167]
name: items [7162,7167]
===
match
---
name: Column [10483,10489]
name: Column [10483,10489]
===
match
---
trailer [56865,56871]
trailer [56877,56883]
===
match
---
name: lock_for_update [80078,80093]
name: lock_for_update [80090,80105]
===
match
---
name: context [51259,51266]
name: context [51259,51266]
===
match
---
name: session [65572,65579]
name: session [65584,65591]
===
match
---
operator: = [15742,15743]
operator: = [15742,15743]
===
match
---
trailer [53211,53216]
trailer [53211,53216]
===
match
---
name: TaskInstance [76999,77011]
name: TaskInstance [77011,77023]
===
match
---
atom_expr [38510,38521]
atom_expr [38510,38521]
===
match
---
name: self [34828,34832]
name: self [34828,34832]
===
match
---
atom_expr [21559,21578]
atom_expr [21559,21578]
===
match
---
name: Column [11117,11123]
name: Column [11117,11123]
===
match
---
not_test [44305,44321]
not_test [44305,44321]
===
match
---
operator: , [71324,71325]
operator: , [71336,71337]
===
match
---
trailer [13526,13536]
trailer [13526,13536]
===
match
---
name: pool [23898,23902]
name: pool [23898,23902]
===
match
---
atom [5212,5214]
atom [5212,5214]
===
match
---
operator: = [69111,69112]
operator: = [69123,69124]
===
match
---
operator: , [9089,9090]
operator: , [9089,9090]
===
match
---
name: params [59907,59913]
name: params [59919,59925]
===
match
---
name: property [20014,20022]
name: property [20014,20022]
===
match
---
trailer [47364,47372]
trailer [47364,47372]
===
match
---
trailer [42645,42647]
trailer [42645,42647]
===
match
---
suite [56493,56534]
suite [56505,56546]
===
match
---
import_name [885,900]
import_name [885,900]
===
match
---
name: ti [6143,6145]
name: ti [6143,6145]
===
match
---
trailer [7005,7195]
trailer [7005,7195]
===
match
---
decorated [20468,21225]
decorated [20468,21225]
===
match
---
operator: , [71428,71429]
operator: , [71440,71441]
===
match
---
name: mark_success [14981,14993]
name: mark_success [14981,14993]
===
match
---
name: context [66343,66350]
name: context [66355,66362]
===
match
---
decorated [62302,62654]
decorated [62314,62666]
===
match
---
string: "previous_start_date was called" [30983,31015]
string: "previous_start_date was called" [30983,31015]
===
match
---
name: task_id [22311,22318]
name: task_id [22311,22318]
===
match
---
name: str [78705,78708]
name: str [78717,78720]
===
match
---
string: "`activate_dag_runs` parameter to clear_task_instances function is deprecated. " [7746,7826]
string: "`activate_dag_runs` parameter to clear_task_instances function is deprecated. " [7746,7826]
===
match
---
argument [74605,74639]
argument [74617,74651]
===
match
---
name: is_container [75025,75037]
name: is_container [75037,75049]
===
match
---
fstring_end: " [20006,20007]
fstring_end: " [20006,20007]
===
match
---
trailer [25630,25632]
trailer [25630,25632]
===
match
---
name: ts [59647,59649]
name: ts [59659,59661]
===
match
---
atom_expr [40824,40855]
atom_expr [40824,40855]
===
match
---
expr_stmt [66650,66676]
expr_stmt [66662,66688]
===
match
---
name: dill [1142,1146]
name: dill [1142,1146]
===
match
---
name: v [47680,47681]
name: v [47680,47681]
===
match
---
return_stmt [4223,4261]
return_stmt [4223,4261]
===
match
---
comparison [22332,22382]
comparison [22332,22382]
===
match
---
name: warning [48293,48300]
name: warning [48293,48300]
===
match
---
trailer [72672,72692]
trailer [72684,72704]
===
match
---
trailer [59925,59932]
trailer [59937,59944]
===
match
---
trailer [32704,32710]
trailer [32704,32710]
===
match
---
simple_stmt [56363,56434]
simple_stmt [56375,56446]
===
match
---
param [71354,71396]
param [71366,71408]
===
match
---
atom [71091,71124]
atom [71103,71136]
===
match
---
simple_stmt [78539,78577]
simple_stmt [78551,78589]
===
match
---
atom_expr [71075,71088]
atom_expr [71087,71100]
===
match
---
trailer [61673,61704]
trailer [61685,61716]
===
match
---
name: String [10882,10888]
name: String [10882,10888]
===
match
---
simple_stmt [21525,21551]
simple_stmt [21525,21551]
===
match
---
trailer [20131,20141]
trailer [20131,20141]
===
match
---
trailer [38567,38569]
trailer [38567,38569]
===
match
---
name: schedule_interval [28552,28569]
name: schedule_interval [28552,28569]
===
match
---
name: State [25914,25919]
name: State [25914,25919]
===
match
---
name: task_id [9571,9578]
name: task_id [9571,9578]
===
match
---
dotted_name [2866,2890]
dotted_name [2866,2890]
===
match
---
operator: { [15652,15653]
operator: { [15652,15653]
===
match
---
operator: , [55271,55272]
operator: , [55283,55284]
===
match
---
operator: == [51143,51145]
operator: == [51143,51145]
===
match
---
argument [52662,52673]
argument [52662,52673]
===
match
---
name: try_number [12977,12987]
name: try_number [12977,12987]
===
match
---
simple_stmt [79102,79122]
simple_stmt [79114,79134]
===
match
---
atom_expr [7069,7093]
atom_expr [7069,7093]
===
match
---
name: self [44026,44030]
name: self [44026,44030]
===
match
---
name: session [28923,28930]
name: session [28923,28930]
===
match
---
expr_stmt [24011,24046]
expr_stmt [24011,24046]
===
match
---
trailer [56378,56433]
trailer [56390,56445]
===
match
---
name: typing_compat [2447,2460]
name: typing_compat [2447,2460]
===
match
---
operator: = [16513,16514]
operator: = [16513,16514]
===
match
---
trailer [12749,12758]
trailer [12749,12758]
===
match
---
name: get_template_context [51274,51294]
name: get_template_context [51274,51294]
===
match
---
trailer [46344,46362]
trailer [46344,46362]
===
match
---
simple_stmt [47157,47196]
simple_stmt [47157,47196]
===
match
---
trailer [61404,61408]
trailer [61416,61420]
===
match
---
atom_expr [26627,26647]
atom_expr [26627,26647]
===
match
---
name: self [30968,30972]
name: self [30968,30972]
===
match
---
comparison [24508,24534]
comparison [24508,24534]
===
match
---
suite [62613,62654]
suite [62625,62666]
===
match
---
operator: = [78413,78414]
operator: = [78425,78426]
===
match
---
atom_expr [56363,56433]
atom_expr [56375,56445]
===
match
---
name: yesterday_ds_nodash [59692,59711]
name: yesterday_ds_nodash [59704,59723]
===
match
---
simple_stmt [55348,55385]
simple_stmt [55360,55397]
===
match
---
trailer [77555,77820]
trailer [77567,77832]
===
match
---
simple_stmt [78441,78484]
simple_stmt [78453,78496]
===
match
---
name: timezone [12877,12885]
name: timezone [12877,12885]
===
match
---
name: debug [24432,24437]
name: debug [24432,24437]
===
match
---
trailer [59674,59683]
trailer [59686,59695]
===
match
---
operator: , [1095,1096]
operator: , [1095,1096]
===
match
---
trailer [72362,72366]
trailer [72374,72378]
===
match
---
suite [12777,12847]
suite [12777,12847]
===
match
---
lambdef [63528,63585]
lambdef [63540,63597]
===
match
---
name: ignore_depends_on_past [15072,15094]
name: ignore_depends_on_past [15072,15094]
===
match
---
name: dag_id [8851,8857]
name: dag_id [8851,8857]
===
match
---
name: self [42164,42168]
name: self [42164,42168]
===
match
---
trailer [34797,34805]
trailer [34797,34805]
===
match
---
name: commit [24669,24675]
name: commit [24669,24675]
===
match
---
return_stmt [79586,79604]
return_stmt [79598,79616]
===
match
---
suite [8999,9125]
suite [8999,9125]
===
match
---
simple_stmt [11219,11241]
simple_stmt [11219,11241]
===
match
---
name: DepContext [32599,32609]
name: DepContext [32599,32609]
===
match
---
trailer [8244,8269]
trailer [8244,8269]
===
match
---
except_clause [65707,65759]
except_clause [65719,65771]
===
match
---
operator: , [62885,62886]
operator: , [62897,62898]
===
match
---
expr_stmt [8728,8762]
expr_stmt [8728,8762]
===
match
---
atom_expr [56465,56475]
atom_expr [56477,56487]
===
match
---
name: reschedule_date [53936,53951]
name: reschedule_date [53936,53951]
===
match
---
name: default [11005,11012]
name: default [11005,11012]
===
match
---
trailer [11337,11363]
trailer [11337,11363]
===
match
---
name: task [38337,38341]
name: task [38337,38341]
===
match
---
funcdef [50249,50579]
funcdef [50249,50579]
===
match
---
name: renderedtifields [46563,46579]
name: renderedtifields [46563,46579]
===
match
---
name: test_mode [55325,55334]
name: test_mode [55337,55346]
===
match
---
operator: , [1088,1089]
operator: , [1088,1089]
===
match
---
atom_expr [58856,58875]
atom_expr [58868,58887]
===
match
---
comparison [38630,38657]
comparison [38630,38657]
===
match
---
operator: , [16450,16451]
operator: , [16450,16451]
===
match
---
trailer [18803,18813]
trailer [18803,18813]
===
match
---
suite [65966,66197]
suite [65978,66209]
===
match
---
arglist [54740,54756]
arglist [54740,54756]
===
match
---
name: jinja2 [1207,1213]
name: jinja2 [1207,1213]
===
match
---
name: self [60533,60537]
name: self [60545,60549]
===
match
---
number: 0 [26931,26932]
number: 0 [26931,26932]
===
match
---
trailer [52983,52989]
trailer [52983,52989]
===
match
---
simple_stmt [76607,76645]
simple_stmt [76619,76657]
===
match
---
atom_expr [70211,70219]
atom_expr [70223,70231]
===
match
---
trailer [22294,22302]
trailer [22294,22302]
===
match
---
name: SimpleTaskInstance [78134,78152]
name: SimpleTaskInstance [78146,78164]
===
match
---
name: session [25002,25009]
name: session [25002,25009]
===
match
---
atom_expr [24892,24904]
atom_expr [24892,24904]
===
match
---
name: deserialize_json [61430,61446]
name: deserialize_json [61442,61458]
===
match
---
argument [63565,63584]
argument [63577,63596]
===
match
---
trailer [42448,42453]
trailer [42448,42453]
===
match
---
operator: = [66868,66869]
operator: = [66880,66881]
===
match
---
operator: , [77323,77324]
operator: , [77335,77336]
===
match
---
name: self [31035,31039]
name: self [31035,31039]
===
match
---
name: session [36904,36911]
name: session [36904,36911]
===
match
---
name: self [49178,49182]
name: self [49178,49182]
===
match
---
trailer [21155,21158]
trailer [21155,21158]
===
match
---
trailer [67767,67775]
trailer [67779,67787]
===
match
---
name: self [66869,66873]
name: self [66881,66885]
===
match
---
atom_expr [8973,8998]
atom_expr [8973,8998]
===
match
---
expr_stmt [10642,10672]
expr_stmt [10642,10672]
===
match
---
name: _run_as_user [78682,78694]
name: _run_as_user [78694,78706]
===
match
---
operator: , [4298,4299]
operator: , [4298,4299]
===
match
---
name: task [12217,12221]
name: task [12217,12221]
===
match
---
name: self [9566,9570]
name: self [9566,9570]
===
match
---
simple_stmt [46088,46155]
simple_stmt [46088,46155]
===
match
---
suite [35628,35691]
suite [35628,35691]
===
match
---
comparison [6941,6976]
comparison [6941,6976]
===
match
---
name: self [51500,51504]
name: self [51500,51504]
===
match
---
name: xcom [75375,75379]
name: xcom [75387,75391]
===
match
---
operator: , [80583,80584]
operator: , [80595,80596]
===
match
---
atom_expr [55082,55115]
atom_expr [55094,55127]
===
match
---
name: self [40872,40876]
name: self [40872,40876]
===
match
---
comparison [26782,26832]
comparison [26782,26832]
===
match
---
name: session [41308,41315]
name: session [41308,41315]
===
match
---
operator: = [78710,78711]
operator: = [78722,78723]
===
match
---
operator: } [20285,20286]
operator: } [20285,20286]
===
match
---
trailer [52093,52133]
trailer [52093,52133]
===
match
---
name: dr [28766,28768]
name: dr [28766,28768]
===
match
---
import_from [80960,81000]
import_from [80972,81012]
===
match
---
and_test [72085,72140]
and_test [72097,72152]
===
match
---
trailer [64177,64179]
trailer [64189,64191]
===
match
---
simple_stmt [53305,53329]
simple_stmt [53305,53329]
===
match
---
name: value [71334,71339]
name: value [71346,71351]
===
match
---
return_stmt [33085,33097]
return_stmt [33085,33097]
===
match
---
name: log [41524,41527]
name: log [41524,41527]
===
match
---
name: ti_deps [2319,2326]
name: ti_deps [2319,2326]
===
match
---
name: task [56334,56338]
name: task [56346,56350]
===
match
---
dotted_name [1418,1440]
dotted_name [1418,1440]
===
match
---
arith_expr [69061,69080]
arith_expr [69073,69092]
===
match
---
name: Any [72861,72864]
name: Any [72873,72876]
===
match
---
name: self [67066,67070]
name: self [67078,67082]
===
match
---
name: Proxy [63505,63510]
name: Proxy [63517,63522]
===
match
---
name: log [71201,71204]
name: log [71213,71216]
===
match
---
name: __repr__ [60612,60620]
name: __repr__ [60624,60632]
===
match
---
operator: , [48219,48220]
operator: , [48219,48220]
===
match
---
name: extend [19674,19680]
name: extend [19674,19680]
===
match
---
name: ignore_task_deps [16615,16631]
name: ignore_task_deps [16615,16631]
===
match
---
simple_stmt [13056,13075]
simple_stmt [13056,13075]
===
match
---
trailer [46093,46098]
trailer [46093,46098]
===
match
---
operator: = [58705,58706]
operator: = [58717,58718]
===
match
---
trailer [23868,23873]
trailer [23868,23873]
===
match
---
operator: , [11711,11712]
operator: , [11711,11712]
===
match
---
trailer [80894,80900]
trailer [80906,80912]
===
match
---
trailer [10852,10858]
trailer [10852,10858]
===
match
---
name: raw [15186,15189]
name: raw [15186,15189]
===
match
---
name: cmd [19545,19548]
name: cmd [19545,19548]
===
match
---
name: previous_start_date_success [31265,31292]
name: previous_start_date_success [31265,31292]
===
match
---
simple_stmt [35699,35728]
simple_stmt [35699,35728]
===
match
---
name: airflow [1948,1955]
name: airflow [1948,1955]
===
match
---
suite [62492,62565]
suite [62504,62577]
===
match
---
trailer [65672,65692]
trailer [65684,65704]
===
match
---
decorator [13402,13417]
decorator [13402,13417]
===
match
---
operator: = [60416,60417]
operator: = [60428,60429]
===
match
---
trailer [28035,28044]
trailer [28035,28044]
===
match
---
operator: , [48478,48479]
operator: , [48478,48479]
===
match
---
name: log [23436,23439]
name: log [23436,23439]
===
match
---
operator: = [57555,57556]
operator: = [57567,57568]
===
match
---
trailer [69696,69941]
trailer [69708,69953]
===
match
---
expr_stmt [23404,23421]
expr_stmt [23404,23421]
===
match
---
atom_expr [56510,56533]
atom_expr [56522,56545]
===
match
---
name: Column [11044,11050]
name: Column [11044,11050]
===
match
---
name: session [65564,65571]
name: session [65576,65583]
===
match
---
simple_stmt [66411,66453]
simple_stmt [66423,66465]
===
match
---
annassign [8857,8862]
annassign [8857,8862]
===
match
---
name: all [77184,77187]
name: all [77196,77199]
===
match
---
name: XCOM_RETURN_KEY [2157,2172]
name: XCOM_RETURN_KEY [2157,2172]
===
match
---
atom_expr [22608,22621]
atom_expr [22608,22621]
===
match
---
trailer [9552,9612]
trailer [9552,9612]
===
match
---
name: min_backoff [35056,35067]
name: min_backoff [35056,35067]
===
match
---
name: task_copy [48816,48825]
name: task_copy [48816,48825]
===
match
---
name: state [46350,46355]
name: state [46350,46355]
===
match
---
name: dep_context [39391,39402]
name: dep_context [39391,39402]
===
match
---
atom_expr [66818,66829]
atom_expr [66830,66841]
===
match
---
operator: , [10431,10432]
operator: , [10431,10432]
===
match
---
atom_expr [41617,41654]
atom_expr [41617,41654]
===
match
---
argument [74702,74719]
argument [74714,74731]
===
match
---
name: rendered_k8s_spec [65596,65613]
name: rendered_k8s_spec [65608,65625]
===
match
---
trailer [78417,78432]
trailer [78429,78444]
===
match
---
name: session [46376,46383]
name: session [46376,46383]
===
match
---
name: self [58075,58079]
name: self [58087,58091]
===
match
---
simple_stmt [44125,44145]
simple_stmt [44125,44145]
===
match
---
operator: = [36813,36814]
operator: = [36813,36814]
===
match
---
trailer [21529,21535]
trailer [21529,21535]
===
match
---
if_stmt [66336,66402]
if_stmt [66348,66414]
===
match
---
expr_stmt [78995,79022]
expr_stmt [79007,79034]
===
match
---
name: yesterday_ds [59714,59726]
name: yesterday_ds [59726,59738]
===
match
---
string: """Setting Next Try Number""" [14867,14896]
string: """Setting Next Try Number""" [14867,14896]
===
match
---
suite [30156,30580]
suite [30156,30580]
===
match
---
name: self [21573,21577]
name: self [21573,21577]
===
match
---
simple_stmt [52553,52587]
simple_stmt [52553,52587]
===
match
---
atom_expr [23220,23240]
atom_expr [23220,23240]
===
match
---
suite [19588,19637]
suite [19588,19637]
===
match
---
comparison [25900,25932]
comparison [25900,25932]
===
match
---
name: State [45754,45759]
name: State [45754,45759]
===
match
---
name: log [41176,41179]
name: log [41176,41179]
===
match
---
suite [5475,6238]
suite [5475,6238]
===
match
---
operator: = [66372,66373]
operator: = [66384,66385]
===
match
---
arglist [22234,22383]
arglist [22234,22383]
===
match
---
operator: = [71389,71390]
operator: = [71401,71402]
===
match
---
atom_expr [35602,35627]
atom_expr [35602,35627]
===
match
---
trailer [44935,44943]
trailer [44935,44943]
===
match
---
trailer [78521,78530]
trailer [78533,78542]
===
match
---
name: Exception [56826,56835]
name: Exception [56838,56847]
===
match
---
atom_expr [23137,23152]
atom_expr [23137,23152]
===
match
---
trailer [30972,30976]
trailer [30972,30976]
===
match
---
simple_stmt [2701,2768]
simple_stmt [2701,2768]
===
match
---
name: sentry [2253,2259]
name: sentry [2253,2259]
===
match
---
name: UP_FOR_RETRY [25483,25495]
name: UP_FOR_RETRY [25483,25495]
===
match
---
atom_expr [67753,67789]
atom_expr [67765,67801]
===
match
---
name: str [24997,25000]
name: str [24997,25000]
===
match
---
simple_stmt [67411,67432]
simple_stmt [67423,67444]
===
match
---
fstring [55231,55268]
fstring [55243,55280]
===
match
---
dotted_name [1545,1566]
dotted_name [1545,1566]
===
match
---
name: self [70906,70910]
name: self [70918,70922]
===
match
---
simple_stmt [46920,46966]
simple_stmt [46920,46966]
===
match
---
string: '-' [59658,59661]
string: '-' [59670,59673]
===
match
---
trailer [27914,27924]
trailer [27914,27924]
===
match
---
name: bool [51725,51729]
name: bool [51725,51729]
===
match
---
name: timezone [12700,12708]
name: timezone [12700,12708]
===
match
---
name: self [33404,33408]
name: self [33404,33408]
===
match
---
atom_expr [24116,24136]
atom_expr [24116,24136]
===
match
---
parameters [33986,33992]
parameters [33986,33992]
===
match
---
operator: = [70110,70111]
operator: = [70122,70123]
===
match
---
operator: -> [79718,79720]
operator: -> [79730,79732]
===
match
---
string: 'inlets' [62899,62907]
string: 'inlets' [62911,62919]
===
match
---
tfpdef [16438,16450]
tfpdef [16438,16450]
===
match
---
simple_stmt [2306,2357]
simple_stmt [2306,2357]
===
match
---
trailer [35976,35983]
trailer [35976,35983]
===
match
---
atom_expr [9091,9103]
atom_expr [9091,9103]
===
match
---
name: state [30057,30062]
name: state [30057,30062]
===
match
---
name: self [64327,64331]
name: self [64339,64343]
===
match
---
import_from [3056,3109]
import_from [3056,3109]
===
match
---
simple_stmt [28752,28819]
simple_stmt [28752,28819]
===
match
---
name: end_date [25530,25538]
name: end_date [25530,25538]
===
match
---
name: task [55137,55141]
name: task [55149,55153]
===
match
---
operator: = [65571,65572]
operator: = [65583,65584]
===
match
---
operator: , [52207,52208]
operator: , [52207,52208]
===
match
---
name: extend [19058,19064]
name: extend [19058,19064]
===
match
---
operator: = [44196,44197]
operator: = [44196,44197]
===
match
---
expr_stmt [43888,43914]
expr_stmt [43888,43914]
===
match
---
name: airflow [2311,2318]
name: airflow [2311,2318]
===
match
---
trailer [70327,70364]
trailer [70339,70376]
===
match
---
trailer [77494,77502]
trailer [77506,77514]
===
match
---
trailer [77932,77936]
trailer [77944,77948]
===
match
---
operator: = [39402,39403]
operator: = [39402,39403]
===
match
---
atom_expr [40121,40136]
atom_expr [40121,40136]
===
match
---
operator: , [54559,54560]
operator: , [54559,54560]
===
match
---
string: "at task runtime. Attempt %s of " [40980,41013]
string: "at task runtime. Attempt %s of " [40980,41013]
===
match
---
operator: , [16754,16755]
operator: , [16754,16755]
===
match
---
name: dep_name [33647,33655]
name: dep_name [33647,33655]
===
match
---
trailer [59734,59743]
trailer [59746,59755]
===
match
---
name: duration [71080,71088]
name: duration [71092,71100]
===
match
---
simple_stmt [44055,44086]
simple_stmt [44055,44086]
===
match
---
simple_stmt [22590,22622]
simple_stmt [22590,22622]
===
match
---
name: self [44609,44613]
name: self [44609,44613]
===
match
---
parameters [9639,9645]
parameters [9639,9645]
===
match
---
trailer [24700,24721]
trailer [24700,24721]
===
match
---
atom_expr [27391,27404]
atom_expr [27391,27404]
===
match
---
operator: , [54407,54408]
operator: , [54407,54408]
===
match
---
operator: = [5576,5577]
operator: = [5576,5577]
===
match
---
name: xcom [75437,75441]
name: xcom [75449,75453]
===
match
---
trailer [8387,8446]
trailer [8387,8446]
===
match
---
fstring_end: ' [46152,46153]
fstring_end: ' [46152,46153]
===
match
---
import_as_names [1616,1830]
import_as_names [1616,1830]
===
match
---
name: instance [8224,8232]
name: instance [8224,8232]
===
match
---
return_stmt [70236,70297]
return_stmt [70248,70309]
===
match
---
simple_stmt [64704,64751]
simple_stmt [64716,64763]
===
match
---
name: params [60056,60062]
name: params [60068,60074]
===
match
---
name: getboolean [59951,59961]
name: getboolean [59963,59973]
===
match
---
trailer [3991,4014]
trailer [3991,4014]
===
match
---
operator: , [16189,16190]
operator: , [16189,16190]
===
match
---
parameters [3383,3401]
parameters [3383,3401]
===
match
---
name: start_date [71113,71123]
name: start_date [71125,71135]
===
match
---
name: task [51589,51593]
name: task [51589,51593]
===
match
---
operator: , [47678,47679]
operator: , [47678,47679]
===
match
---
trailer [8333,8340]
trailer [8333,8340]
===
match
---
name: dag_id [8233,8239]
name: dag_id [8233,8239]
===
match
---
operator: , [46948,46949]
operator: , [46948,46949]
===
match
---
name: utcnow [35977,35983]
name: utcnow [35977,35983]
===
match
---
name: bool [51687,51691]
name: bool [51687,51691]
===
match
---
trailer [80760,80776]
trailer [80772,80788]
===
match
---
expr_stmt [66364,66401]
expr_stmt [66376,66413]
===
match
---
name: task_id [75096,75103]
name: task_id [75108,75115]
===
match
---
name: RUNNING [41682,41689]
name: RUNNING [41682,41689]
===
match
---
name: item [62559,62563]
name: item [62571,62575]
===
match
---
name: self [34587,34591]
name: self [34587,34591]
===
match
---
name: task_copy [47983,47992]
name: task_copy [47983,47992]
===
match
---
trailer [71210,71252]
trailer [71222,71264]
===
match
---
operator: , [24890,24891]
operator: , [24890,24891]
===
match
---
name: task [57657,57661]
name: task [57669,57673]
===
match
---
trailer [54257,54261]
trailer [54257,54261]
===
match
---
name: start_date [39884,39894]
name: start_date [39884,39894]
===
match
---
operator: = [23153,23154]
operator: = [23153,23154]
===
match
---
name: str [42252,42255]
name: str [42252,42255]
===
match
---
name: Optional [56857,56865]
name: Optional [56869,56877]
===
match
---
name: State [52993,52998]
name: State [52993,52998]
===
match
---
param [46472,46477]
param [46472,46477]
===
match
---
if_stmt [78897,78987]
if_stmt [78909,78999]
===
match
---
operator: = [69749,69750]
operator: = [69761,69762]
===
match
---
name: ignore_task_deps [15040,15056]
name: ignore_task_deps [15040,15056]
===
match
---
atom_expr [59197,59235]
atom_expr [59209,59247]
===
match
---
name: qry [80494,80497]
name: qry [80506,80509]
===
match
---
atom_expr [72718,72731]
atom_expr [72730,72743]
===
match
---
expr_stmt [58739,58780]
expr_stmt [58751,58792]
===
match
---
name: provide_session [30586,30601]
name: provide_session [30586,30601]
===
match
---
atom_expr [4803,4815]
atom_expr [4803,4815]
===
match
---
name: self [29934,29938]
name: self [29934,29938]
===
match
---
trailer [3282,3291]
trailer [3282,3291]
===
match
---
trailer [33453,33470]
trailer [33453,33470]
===
match
---
return_stmt [42204,42215]
return_stmt [42204,42215]
===
match
---
try_stmt [2991,3213]
try_stmt [2991,3213]
===
match
---
name: dag_ids [74674,74681]
name: dag_ids [74686,74693]
===
match
---
name: dict [69714,69718]
name: dict [69726,69730]
===
match
---
operator: = [52809,52810]
operator: = [52809,52810]
===
match
---
atom_expr [6247,6322]
atom_expr [6247,6322]
===
match
---
operator: @ [57268,57269]
operator: @ [57280,57281]
===
match
---
name: total_seconds [71125,71138]
name: total_seconds [71137,71150]
===
match
---
simple_stmt [66281,66328]
simple_stmt [66293,66340]
===
match
---
name: str [79089,79092]
name: str [79101,79104]
===
match
---
argument [45457,45472]
argument [45457,45472]
===
match
---
name: timezone [41238,41246]
name: timezone [41238,41246]
===
match
---
param [23514,23519]
param [23514,23519]
===
match
---
operator: = [7997,7998]
operator: = [7997,7998]
===
match
---
name: prev_execution_date [63266,63285]
name: prev_execution_date [63278,63297]
===
match
---
number: 1 [14165,14166]
number: 1 [14165,14166]
===
match
---
operator: , [33475,33476]
operator: , [33475,33476]
===
match
---
suite [21281,21604]
suite [21281,21604]
===
match
---
string: 'macros' [62934,62942]
string: 'macros' [62946,62954]
===
match
---
suite [4338,4663]
suite [4338,4663]
===
match
---
trailer [77577,77776]
trailer [77589,77788]
===
match
---
atom_expr [19670,19706]
atom_expr [19670,19706]
===
match
---
operator: , [1879,1880]
operator: , [1879,1880]
===
match
---
trailer [42024,42029]
trailer [42024,42029]
===
match
---
comparison [35939,35985]
comparison [35939,35985]
===
match
---
argument [69050,69080]
argument [69062,69092]
===
match
---
trailer [29434,29436]
trailer [29434,29436]
===
match
---
name: Variable [61818,61826]
name: Variable [61830,61838]
===
match
---
operator: = [41674,41675]
operator: = [41674,41675]
===
match
---
name: session [55348,55355]
name: session [55360,55367]
===
match
---
operator: , [36916,36917]
operator: , [36916,36917]
===
match
---
trailer [75270,75274]
trailer [75282,75286]
===
match
---
name: prev_ti [31169,31176]
name: prev_ti [31169,31176]
===
match
---
name: _update_ti_state_for_sensing [49071,49099]
name: _update_ti_state_for_sensing [49071,49099]
===
match
---
operator: = [30486,30487]
operator: = [30486,30487]
===
match
---
simple_stmt [4138,4150]
simple_stmt [4138,4150]
===
match
---
if_stmt [39927,40166]
if_stmt [39927,40166]
===
match
---
param [65943,65948]
param [65955,65960]
===
match
---
argument [47857,47872]
argument [47857,47872]
===
match
---
atom_expr [43870,43879]
atom_expr [43870,43879]
===
match
---
name: bool [16701,16705]
name: bool [16701,16705]
===
match
---
operator: , [62920,62921]
operator: , [62932,62933]
===
match
---
name: raw [76037,76040]
name: raw [76049,76052]
===
match
---
comparison [20917,20951]
comparison [20917,20951]
===
match
---
suite [50388,50480]
suite [50388,50480]
===
match
---
atom_expr [74578,74812]
atom_expr [74590,74824]
===
match
---
expr_stmt [25370,25419]
expr_stmt [25370,25419]
===
match
---
argument [39065,39101]
argument [39065,39101]
===
match
---
operator: = [43037,43038]
operator: = [43037,43038]
===
match
---
operator: , [57011,57012]
operator: , [57023,57024]
===
match
---
param [52015,52028]
param [52015,52028]
===
match
---
trailer [6294,6305]
trailer [6294,6305]
===
match
---
atom_expr [78845,78866]
atom_expr [78857,78878]
===
match
---
trailer [58915,58919]
trailer [58927,58931]
===
match
---
tfpdef [60729,60738]
tfpdef [60741,60750]
===
match
---
name: Integer [11232,11239]
name: Integer [11232,11239]
===
match
---
operator: = [57391,57392]
operator: = [57403,57404]
===
match
---
suite [51473,51621]
suite [51473,51621]
===
match
---
name: str [61541,61544]
name: str [61553,61556]
===
match
---
comparison [80648,80699]
comparison [80660,80711]
===
match
---
operator: , [42071,42072]
operator: , [42071,42072]
===
match
---
name: full_filepath [15588,15601]
name: full_filepath [15588,15601]
===
match
---
trailer [66246,66255]
trailer [66258,66267]
===
match
---
expr_stmt [34188,34217]
expr_stmt [34188,34217]
===
match
---
argument [44001,44016]
argument [44001,44016]
===
match
---
name: _date_or_empty [42225,42239]
name: _date_or_empty [42225,42239]
===
match
---
atom_expr [3992,4013]
atom_expr [3992,4013]
===
match
---
name: kubernetes_helper_functions [66573,66600]
name: kubernetes_helper_functions [66585,66612]
===
match
---
atom_expr [78944,78965]
atom_expr [78956,78977]
===
match
---
expr_stmt [15631,15667]
expr_stmt [15631,15667]
===
match
---
operator: = [47186,47187]
operator: = [47186,47187]
===
match
---
name: local [19416,19421]
name: local [19416,19421]
===
match
---
parameters [20506,20526]
parameters [20506,20526]
===
match
---
name: merge [41280,41285]
name: merge [41280,41285]
===
match
---
operator: = [16706,16707]
operator: = [16706,16707]
===
match
---
atom_expr [4449,4471]
atom_expr [4449,4471]
===
match
---
name: task [26538,26542]
name: task [26538,26542]
===
match
---
trailer [7625,7629]
trailer [7625,7629]
===
match
---
name: self [23832,23836]
name: self [23832,23836]
===
match
---
suite [6346,7484]
suite [6346,7484]
===
match
---
name: state [25328,25333]
name: state [25328,25333]
===
match
---
atom_expr [76977,77172]
atom_expr [76989,77184]
===
match
---
atom_expr [49758,49801]
atom_expr [49758,49801]
===
match
---
name: task [58829,58833]
name: task [58841,58845]
===
match
---
operator: = [67815,67816]
operator: = [67827,67828]
===
match
---
simple_stmt [27994,28006]
simple_stmt [27994,28006]
===
match
---
name: task_id [75288,75295]
name: task_id [75300,75307]
===
match
---
name: RenderedTaskInstanceFields [47241,47267]
name: RenderedTaskInstanceFields [47241,47267]
===
match
---
operator: , [42293,42294]
operator: , [42293,42294]
===
match
---
trailer [79915,79920]
trailer [79927,79932]
===
match
---
simple_stmt [4223,4262]
simple_stmt [4223,4262]
===
match
---
decorator [79379,79389]
decorator [79391,79401]
===
match
---
fstring_start: f' [48955,48957]
fstring_start: f' [48955,48957]
===
match
---
name: airflow [1899,1906]
name: airflow [1899,1906]
===
match
---
name: queue [79017,79022]
name: queue [79029,79034]
===
match
---
funcdef [70596,70950]
funcdef [70608,70962]
===
match
---
atom_expr [39897,39914]
atom_expr [39897,39914]
===
match
---
atom_expr [57573,57593]
atom_expr [57585,57605]
===
match
---
string: 'test_mode' [63753,63764]
string: 'test_mode' [63765,63776]
===
match
---
atom_expr [41663,41673]
atom_expr [41663,41673]
===
match
---
trailer [59543,59552]
trailer [59555,59564]
===
match
---
trailer [11130,11136]
trailer [11130,11136]
===
match
---
name: TaskInstance [22234,22246]
name: TaskInstance [22234,22246]
===
match
---
name: Context [3283,3290]
name: Context [3283,3290]
===
match
---
operator: , [54461,54462]
operator: , [54461,54462]
===
match
---
name: context [3739,3746]
name: context [3739,3746]
===
match
---
fstring [48955,48998]
fstring [48955,48998]
===
match
---
comparison [22234,22268]
comparison [22234,22268]
===
match
---
trailer [44132,44138]
trailer [44132,44138]
===
match
---
trailer [19879,19883]
trailer [19879,19883]
===
match
---
string: "Dependencies not met for %s, dependency '%s' FAILED: %s" [32886,32943]
string: "Dependencies not met for %s, dependency '%s' FAILED: %s" [32886,32943]
===
match
---
operator: , [27079,27080]
operator: , [27079,27080]
===
match
---
string: 'email' [70070,70077]
string: 'email' [70082,70089]
===
match
---
name: error [54707,54712]
name: error [54707,54712]
===
match
---
trailer [36442,36444]
trailer [36442,36444]
===
match
---
operator: = [69795,69796]
operator: = [69807,69808]
===
match
---
name: self [79182,79186]
name: self [79194,79198]
===
match
---
trailer [66399,66401]
trailer [66411,66413]
===
match
---
param [15226,15236]
param [15226,15236]
===
match
---
trailer [47753,47760]
trailer [47753,47760]
===
match
---
argument [38480,38500]
argument [38480,38500]
===
match
---
simple_stmt [1413,1456]
simple_stmt [1413,1456]
===
match
---
atom_expr [34542,34610]
atom_expr [34542,34610]
===
match
---
name: dag_id [72710,72716]
name: dag_id [72722,72728]
===
match
---
name: str [8979,8982]
name: str [8979,8982]
===
match
---
expr_stmt [59752,59801]
expr_stmt [59764,59813]
===
match
---
name: task_copy [47113,47122]
name: task_copy [47113,47122]
===
match
---
trailer [53241,53263]
trailer [53241,53263]
===
match
---
name: join [47657,47661]
name: join [47657,47661]
===
match
---
name: state [5397,5402]
name: state [5397,5402]
===
match
---
name: ignore_task_deps [16027,16043]
name: ignore_task_deps [16027,16043]
===
match
---
expr_stmt [59397,59438]
expr_stmt [59409,59450]
===
match
---
name: is_smart_sensor_compatible [47993,48019]
name: is_smart_sensor_compatible [47993,48019]
===
match
---
string: 'Host: {{ti.hostname}}<br>' [68563,68590]
string: 'Host: {{ti.hostname}}<br>' [68575,68602]
===
match
---
trailer [30145,30154]
trailer [30145,30154]
===
match
---
operator: = [80498,80499]
operator: = [80510,80511]
===
match
---
and_test [76885,76942]
and_test [76897,76954]
===
match
---
lambdef [5248,5293]
lambdef [5248,5293]
===
match
---
operator: = [12182,12183]
operator: = [12182,12183]
===
match
---
operator: = [28235,28236]
operator: = [28235,28236]
===
match
---
name: session [65338,65345]
name: session [65350,65357]
===
match
---
funcdef [70955,71253]
funcdef [70967,71265]
===
match
---
operator: = [36780,36781]
operator: = [36780,36781]
===
match
---
name: state [21191,21196]
name: state [21191,21196]
===
match
---
operator: , [9333,9334]
operator: , [9333,9334]
===
match
---
operator: , [36031,36032]
operator: , [36031,36032]
===
match
---
name: str [78121,78124]
name: str [78133,78136]
===
match
---
atom_expr [34587,34602]
atom_expr [34587,34602]
===
match
---
trailer [50450,50470]
trailer [50450,50470]
===
match
---
trailer [50638,50654]
trailer [50638,50654]
===
match
---
arglist [28123,28196]
arglist [28123,28196]
===
match
---
suite [72141,72349]
suite [72153,72361]
===
match
---
name: e [44684,44685]
name: e [44684,44685]
===
match
---
name: extend [19605,19611]
name: extend [19605,19611]
===
match
---
name: tis [8191,8194]
name: tis [8191,8194]
===
match
---
dotted_name [36217,36238]
dotted_name [36217,36238]
===
match
---
name: TaskInstance [77341,77353]
name: TaskInstance [77353,77365]
===
match
---
tfpdef [16417,16428]
tfpdef [16417,16428]
===
match
---
parameters [65331,65351]
parameters [65343,65363]
===
match
---
name: self [13616,13620]
name: self [13616,13620]
===
match
---
argument [16312,16321]
argument [16312,16321]
===
match
---
operator: = [42998,42999]
operator: = [42998,42999]
===
match
---
trailer [10417,10469]
trailer [10417,10469]
===
match
---
operator: = [57534,57535]
operator: = [57546,57547]
===
match
---
operator: == [75775,75777]
operator: == [75787,75789]
===
match
---
operator: -> [79876,79878]
operator: -> [79888,79890]
===
match
---
fstring_start: f' [47087,47089]
fstring_start: f' [47087,47089]
===
match
---
name: State [49205,49210]
name: State [49205,49210]
===
match
---
name: property [29443,29451]
name: property [29443,29451]
===
match
---
operator: { [20272,20273]
operator: { [20272,20273]
===
match
---
decorated [65285,65899]
decorated [65297,65911]
===
match
---
name: airflow [2516,2523]
name: airflow [2516,2523]
===
match
---
trailer [34591,34602]
trailer [34591,34602]
===
match
---
number: 1 [49003,49004]
number: 1 [49003,49004]
===
match
---
trailer [58943,58958]
trailer [58955,58970]
===
match
---
trailer [12113,12115]
trailer [12113,12115]
===
match
---
name: email [56470,56475]
name: email [56482,56487]
===
match
---
trailer [79016,79022]
trailer [79028,79034]
===
match
---
name: items [64679,64684]
name: items [64691,64696]
===
match
---
operator: @ [79055,79056]
operator: @ [79067,79068]
===
match
---
name: task [62717,62721]
name: task [62729,62733]
===
match
---
atom_expr [43923,43971]
atom_expr [43923,43971]
===
match
---
atom_expr [67066,67086]
atom_expr [67078,67098]
===
match
---
expr_stmt [7395,7447]
expr_stmt [7395,7447]
===
match
---
name: __table__ [7411,7420]
name: __table__ [7411,7420]
===
match
---
operator: , [11560,11561]
operator: , [11560,11561]
===
match
---
operator: , [16795,16796]
operator: , [16795,16796]
===
match
---
trailer [19384,19391]
trailer [19384,19391]
===
match
---
parameters [25696,25702]
parameters [25696,25702]
===
match
---
name: xcom_pull [72615,72624]
name: xcom_pull [72627,72636]
===
match
---
name: fd [4420,4422]
name: fd [4420,4422]
===
match
---
operator: } [57493,57494]
operator: } [57505,57506]
===
match
---
trailer [62864,62885]
trailer [62876,62897]
===
match
---
name: on_failure_callback [50937,50956]
name: on_failure_callback [50937,50956]
===
match
---
atom_expr [4068,4091]
atom_expr [4068,4091]
===
match
---
expr_stmt [67688,67727]
expr_stmt [67700,67739]
===
match
---
suite [45783,45807]
suite [45783,45807]
===
match
---
name: context [47865,47872]
name: context [47865,47872]
===
match
---
parameters [70611,70628]
parameters [70623,70640]
===
match
---
name: reduced [9148,9155]
name: reduced [9148,9155]
===
match
---
atom_expr [50518,50578]
atom_expr [50518,50578]
===
match
---
operator: , [56912,56913]
operator: , [56924,56925]
===
match
---
name: jinja_context [69474,69487]
name: jinja_context [69486,69499]
===
match
---
name: get [75271,75274]
name: get [75283,75286]
===
match
---
atom_expr [75466,75494]
atom_expr [75478,75506]
===
match
---
file_input [787,81150]
file_input [787,81162]
===
match
---
suite [64687,64751]
suite [64699,64763]
===
match
---
name: delay [34188,34193]
name: delay [34188,34193]
===
match
---
operator: == [6959,6961]
operator: == [6959,6961]
===
match
---
simple_stmt [31162,31242]
simple_stmt [31162,31242]
===
match
---
atom_expr [77709,77736]
atom_expr [77721,77748]
===
match
---
expr_stmt [48105,48123]
expr_stmt [48105,48123]
===
match
---
expr_stmt [34528,34610]
expr_stmt [34528,34610]
===
match
---
name: result [75128,75134]
name: result [75140,75146]
===
match
---
fstring_start: f" [20337,20339]
fstring_start: f" [20337,20339]
===
match
---
funcdef [57107,57263]
funcdef [57119,57275]
===
match
---
simple_stmt [28864,28932]
simple_stmt [28864,28932]
===
match
---
name: state [31056,31061]
name: state [31056,31061]
===
match
---
subscriptlist [3998,4012]
subscriptlist [3998,4012]
===
match
---
name: execute [49843,49850]
name: execute [49843,49850]
===
match
---
simple_stmt [9759,9771]
simple_stmt [9759,9771]
===
match
---
name: KubeConfig [66664,66674]
name: KubeConfig [66676,66686]
===
match
---
operator: , [19508,19509]
operator: , [19508,19509]
===
match
---
name: self [65668,65672]
name: self [65680,65684]
===
match
---
atom_expr [64159,64179]
atom_expr [64171,64191]
===
match
---
name: property [19732,19740]
name: property [19732,19740]
===
match
---
name: task [64717,64721]
name: task [64729,64733]
===
match
---
name: task_id [46131,46138]
name: task_id [46131,46138]
===
match
---
name: Environment [69191,69202]
name: Environment [69203,69214]
===
match
---
operator: = [15478,15479]
operator: = [15478,15479]
===
match
---
suite [35759,35986]
suite [35759,35986]
===
match
---
name: test_mode [36797,36806]
name: test_mode [36797,36806]
===
match
---
simple_stmt [26043,26497]
simple_stmt [26043,26497]
===
match
---
fstring_expr [46111,46124]
fstring_expr [46111,46124]
===
match
---
name: session [31891,31898]
name: session [31891,31898]
===
match
---
simple_stmt [45841,45898]
simple_stmt [45841,45898]
===
match
---
name: task_id [80610,80617]
name: task_id [80622,80629]
===
match
---
atom_expr [13522,13536]
atom_expr [13522,13536]
===
match
---
arglist [72380,72574]
arglist [72392,72586]
===
match
---
fstring_end: " [20286,20287]
fstring_end: " [20286,20287]
===
match
---
name: session [21267,21274]
name: session [21267,21274]
===
match
---
trailer [22459,22461]
trailer [22459,22461]
===
match
---
operator: = [16890,16891]
operator: = [16890,16891]
===
match
---
operator: , [74772,74773]
operator: , [74784,74785]
===
match
---
if_stmt [59298,59512]
if_stmt [59310,59524]
===
match
---
import_as_names [2403,2433]
import_as_names [2403,2433]
===
match
---
operator: = [12215,12216]
operator: = [12215,12216]
===
match
---
name: dag_id [76577,76583]
name: dag_id [76589,76595]
===
match
---
operator: = [16789,16790]
operator: = [16789,16790]
===
match
---
name: dag_id [77625,77631]
name: dag_id [77637,77643]
===
match
---
operator: = [35651,35652]
operator: = [35651,35652]
===
match
---
decorator [79201,79211]
decorator [79213,79223]
===
match
---
simple_stmt [61400,61453]
simple_stmt [61412,61465]
===
match
---
argument [52471,52480]
argument [52471,52480]
===
match
---
operator: = [4748,4749]
operator: = [4748,4749]
===
match
---
name: create_pod_id [66608,66621]
name: create_pod_id [66620,66633]
===
match
---
funcdef [61238,61290]
funcdef [61250,61302]
===
match
---
operator: { [48976,48977]
operator: { [48976,48977]
===
match
---
name: dict [68932,68936]
name: dict [68944,68948]
===
match
---
name: session [55425,55432]
name: session [55437,55444]
===
match
---
atom_expr [30460,30510]
atom_expr [30460,30510]
===
match
---
name: task [56224,56228]
name: task [56236,56240]
===
match
---
suite [51160,51347]
suite [51160,51347]
===
match
---
name: ti [78650,78652]
name: ti [78662,78664]
===
match
---
operator: { [44260,44261]
operator: { [44260,44261]
===
match
---
funcdef [79474,79535]
funcdef [79486,79547]
===
match
---
operator: , [63844,63845]
operator: , [63856,63857]
===
match
---
name: current_time [25542,25554]
name: current_time [25542,25554]
===
match
---
simple_stmt [19488,19517]
simple_stmt [19488,19517]
===
match
---
argument [39119,39150]
argument [39119,39150]
===
match
---
trailer [57831,57841]
trailer [57843,57853]
===
match
---
trailer [53594,53603]
trailer [53594,53603]
===
match
---
simple_stmt [69321,69394]
simple_stmt [69333,69406]
===
match
---
trailer [20277,20285]
trailer [20277,20285]
===
match
---
name: qry [22440,22443]
name: qry [22440,22443]
===
match
---
trailer [49137,49142]
trailer [49137,49142]
===
match
---
atom_expr [3983,4014]
atom_expr [3983,4014]
===
match
---
name: default_conn [62641,62653]
name: default_conn [62653,62665]
===
match
---
name: execution_date [42078,42092]
name: execution_date [42078,42092]
===
match
---
name: delay [35722,35727]
name: delay [35722,35727]
===
match
---
atom_expr [77341,77403]
atom_expr [77353,77415]
===
match
---
argument [72460,72478]
argument [72472,72490]
===
match
---
simple_stmt [78944,78987]
simple_stmt [78956,78999]
===
match
---
trailer [51273,51294]
trailer [51273,51294]
===
match
---
simple_stmt [15474,15494]
simple_stmt [15474,15494]
===
match
---
trailer [70915,70921]
trailer [70927,70933]
===
match
---
atom_expr [23431,23480]
atom_expr [23431,23480]
===
match
---
simple_stmt [2511,2554]
simple_stmt [2511,2554]
===
match
---
name: ti [78415,78417]
name: ti [78427,78429]
===
match
---
atom_expr [28128,28137]
atom_expr [28128,28137]
===
match
---
comparison [52979,53006]
comparison [52979,53006]
===
match
---
name: state [41668,41673]
name: state [41668,41673]
===
match
---
argument [8383,8511]
argument [8383,8511]
===
match
---
name: ti [23045,23047]
name: ti [23045,23047]
===
match
---
name: state [33948,33953]
name: state [33948,33953]
===
match
---
trailer [20997,21005]
trailer [20997,21005]
===
match
---
expr_stmt [54169,54190]
expr_stmt [54169,54190]
===
match
---
if_stmt [66028,66197]
if_stmt [66040,66209]
===
match
---
name: DeprecationWarning [31695,31713]
name: DeprecationWarning [31695,31713]
===
match
---
name: log_url [19749,19756]
name: log_url [19749,19756]
===
match
---
name: state [51137,51142]
name: state [51137,51142]
===
match
---
trailer [39905,39912]
trailer [39905,39912]
===
match
---
name: exception [67757,67766]
name: exception [67769,67778]
===
match
---
name: dag_run [58647,58654]
name: dag_run [58659,58666]
===
match
---
trailer [56290,56303]
trailer [56302,56315]
===
match
---
operator: = [4801,4802]
operator: = [4801,4802]
===
match
---
trailer [19498,19516]
trailer [19498,19516]
===
match
---
name: self [46345,46349]
name: self [46345,46349]
===
match
---
name: with_entities [75172,75185]
name: with_entities [75184,75197]
===
match
---
trailer [77873,77880]
trailer [77885,77892]
===
match
---
operator: = [22962,22963]
operator: = [22962,22963]
===
match
---
operator: , [77687,77688]
operator: , [77699,77700]
===
match
---
operator: , [6976,6977]
operator: , [6976,6977]
===
match
---
trailer [12425,12438]
trailer [12425,12438]
===
match
---
trailer [42731,42749]
trailer [42731,42749]
===
match
---
trailer [60556,60562]
trailer [60568,60574]
===
match
---
simple_stmt [55220,55276]
simple_stmt [55232,55288]
===
match
---
tfpdef [56888,56904]
tfpdef [56900,56916]
===
match
---
operator: = [52087,52088]
operator: = [52087,52088]
===
match
---
trailer [46227,46234]
trailer [46227,46234]
===
match
---
simple_stmt [28228,28241]
simple_stmt [28228,28241]
===
match
---
name: start_date [25393,25403]
name: start_date [25393,25403]
===
match
---
trailer [30719,30738]
trailer [30719,30738]
===
match
---
trailer [24512,24519]
trailer [24512,24519]
===
match
---
arglist [11630,11647]
arglist [11630,11647]
===
match
---
trailer [12740,12745]
trailer [12740,12745]
===
match
---
trailer [16924,16929]
trailer [16924,16929]
===
match
---
name: XCom [75105,75109]
name: XCom [75117,75121]
===
match
---
atom [18993,19021]
atom [18993,19021]
===
match
---
operator: = [11084,11085]
operator: = [11084,11085]
===
match
---
expr_stmt [64475,64560]
expr_stmt [64487,64572]
===
match
---
name: execute [7464,7471]
name: execute [7464,7471]
===
match
---
expr_stmt [81051,81094]
expr_stmt [81063,81106]
===
match
---
atom_expr [6827,7319]
atom_expr [6827,7319]
===
match
---
atom_expr [66664,66676]
atom_expr [66676,66688]
===
match
---
name: State [44534,44539]
name: State [44534,44539]
===
match
---
trailer [25482,25495]
trailer [25482,25495]
===
match
---
operator: , [39101,39102]
operator: , [39101,39102]
===
match
---
atom_expr [24508,24519]
atom_expr [24508,24519]
===
match
---
decorator [25666,25676]
decorator [25666,25676]
===
match
---
string: "Received SIGTERM. Terminating subprocesses." [46765,46810]
string: "Received SIGTERM. Terminating subprocesses." [46765,46810]
===
match
---
fstring_end: " [20360,20361]
fstring_end: " [20360,20361]
===
match
---
simple_stmt [68894,69160]
simple_stmt [68906,69172]
===
match
---
name: priority_weight [11068,11083]
name: priority_weight [11068,11083]
===
match
---
name: replace [59422,59429]
name: replace [59434,59441]
===
match
---
name: ti [23371,23373]
name: ti [23371,23373]
===
match
---
operator: = [7406,7407]
operator: = [7406,7407]
===
match
---
except_clause [3172,3190]
except_clause [3172,3190]
===
match
---
name: TaskInstance [75807,75819]
name: TaskInstance [75819,75831]
===
match
---
atom_expr [57643,57673]
atom_expr [57655,57685]
===
match
---
and_test [58635,58671]
and_test [58647,58683]
===
match
---
operator: , [34791,34792]
operator: , [34791,34792]
===
match
---
string: "Task successfully registered in smart sensor." [49402,49449]
string: "Task successfully registered in smart sensor." [49402,49449]
===
match
---
atom_expr [65514,65580]
atom_expr [65526,65592]
===
match
---
operator: = [7655,7656]
operator: = [7655,7656]
===
match
---
name: extend [19549,19555]
name: extend [19549,19555]
===
match
---
suite [15775,15800]
suite [15775,15800]
===
match
---
dotted_name [1584,1602]
dotted_name [1584,1602]
===
match
---
name: isoformat [20132,20141]
name: isoformat [20132,20141]
===
match
---
return_stmt [79824,79842]
return_stmt [79836,79854]
===
match
---
trailer [77189,77196]
trailer [77201,77208]
===
match
---
funcdef [51647,53120]
funcdef [51647,53120]
===
match
---
simple_stmt [59451,59512]
simple_stmt [59463,59524]
===
match
---
name: max_tries [5706,5715]
name: max_tries [5706,5715]
===
match
---
except_clause [44653,44685]
except_clause [44653,44685]
===
match
---
operator: , [77880,77881]
operator: , [77892,77893]
===
match
---
name: dag_id [12140,12146]
name: dag_id [12140,12146]
===
match
---
suite [56563,56642]
suite [56575,56654]
===
match
---
atom_expr [34793,34805]
atom_expr [34793,34805]
===
match
---
simple_stmt [62437,62472]
simple_stmt [62449,62484]
===
match
---
name: state [42634,42639]
name: state [42634,42639]
===
match
---
atom_expr [10721,10731]
atom_expr [10721,10731]
===
match
---
trailer [42782,42796]
trailer [42782,42796]
===
match
---
not_test [28617,28636]
not_test [28617,28636]
===
match
---
name: modded_hash [35475,35486]
name: modded_hash [35475,35486]
===
match
---
name: __repr__ [61502,61510]
name: __repr__ [61514,61522]
===
match
---
name: session [80500,80507]
name: session [80512,80519]
===
match
---
name: Base [1889,1893]
name: Base [1889,1893]
===
match
---
atom_expr [76055,76078]
atom_expr [76067,76090]
===
match
---
name: test_mode [51908,51917]
name: test_mode [51908,51917]
===
match
---
suite [46737,46911]
suite [46737,46911]
===
match
---
operator: , [72317,72318]
operator: , [72329,72330]
===
match
---
name: _pool [79667,79672]
name: _pool [79679,79684]
===
match
---
fstring_start: f' [55231,55233]
fstring_start: f' [55243,55245]
===
match
---
name: retries [24077,24084]
name: retries [24077,24084]
===
match
---
number: 1 [41134,41135]
number: 1 [41134,41135]
===
match
---
atom_expr [49014,49040]
atom_expr [49014,49040]
===
match
---
atom_expr [22964,22976]
atom_expr [22964,22976]
===
match
---
name: refresh_from_db [45393,45408]
name: refresh_from_db [45393,45408]
===
match
---
trailer [70769,70780]
trailer [70781,70792]
===
match
---
name: int [8925,8928]
name: int [8925,8928]
===
match
---
atom_expr [79014,79022]
atom_expr [79026,79034]
===
match
---
param [4283,4299]
param [4283,4299]
===
match
---
operator: = [10712,10713]
operator: = [10712,10713]
===
match
---
trailer [12976,12987]
trailer [12976,12987]
===
match
---
name: sqlalchemy [1461,1471]
name: sqlalchemy [1461,1471]
===
match
---
expr_stmt [24055,24084]
expr_stmt [24055,24084]
===
match
---
atom_expr [72658,72693]
atom_expr [72670,72705]
===
match
---
simple_stmt [7395,7448]
simple_stmt [7395,7448]
===
match
---
atom_expr [57229,57244]
atom_expr [57241,57256]
===
match
---
atom_expr [41080,41095]
atom_expr [41080,41095]
===
match
---
operator: = [21685,21686]
operator: = [21685,21686]
===
match
---
for_stmt [33432,33833]
for_stmt [33432,33833]
===
match
---
simple_stmt [14316,14464]
simple_stmt [14316,14464]
===
match
---
name: fd [4659,4661]
name: fd [4659,4661]
===
match
---
funcdef [64294,65280]
funcdef [64306,65292]
===
match
---
trailer [41223,41235]
trailer [41223,41235]
===
match
---
operator: , [24226,24227]
operator: , [24226,24227]
===
match
---
name: hostname [22994,23002]
name: hostname [22994,23002]
===
match
---
trailer [44083,44085]
trailer [44083,44085]
===
match
---
number: 1000 [11131,11135]
number: 1000 [11131,11135]
===
match
---
simple_stmt [30968,31017]
simple_stmt [30968,31017]
===
match
---
trailer [19218,19225]
trailer [19218,19225]
===
match
---
simple_stmt [80838,80848]
simple_stmt [80850,80860]
===
match
---
trailer [69529,69541]
trailer [69541,69553]
===
match
---
operator: @ [9130,9131]
operator: @ [9130,9131]
===
match
---
name: task_copy [46824,46833]
name: task_copy [46824,46833]
===
match
---
trailer [6091,6130]
trailer [6091,6130]
===
match
---
simple_stmt [6247,6323]
simple_stmt [6247,6323]
===
match
---
if_stmt [59879,59934]
if_stmt [59891,59946]
===
match
---
atom_expr [38407,38421]
atom_expr [38407,38421]
===
match
---
trailer [31212,31221]
trailer [31212,31221]
===
match
---
trailer [7615,7624]
trailer [7615,7624]
===
match
---
name: test_mode [45864,45873]
name: test_mode [45864,45873]
===
match
---
suite [80954,81150]
suite [80966,81162]
===
match
---
atom_expr [43980,44017]
atom_expr [43980,44017]
===
match
---
parameters [56784,56941]
parameters [56796,56953]
===
match
---
simple_stmt [9676,9751]
simple_stmt [9676,9751]
===
match
---
simple_stmt [62513,62565]
simple_stmt [62525,62577]
===
match
---
comparison [22282,22318]
comparison [22282,22318]
===
match
---
atom_expr [77740,77757]
atom_expr [77752,77769]
===
match
---
operator: , [70930,70931]
operator: , [70942,70943]
===
match
---
trailer [25919,25932]
trailer [25919,25932]
===
match
---
trailer [49284,49290]
trailer [49284,49290]
===
match
---
operator: , [77028,77029]
operator: , [77040,77041]
===
match
---
trailer [35921,35934]
trailer [35921,35934]
===
match
---
name: ignore_depends_on_past [39240,39262]
name: ignore_depends_on_past [39240,39262]
===
match
---
trailer [58309,58321]
trailer [58321,58333]
===
match
---
trailer [5535,5544]
trailer [5535,5544]
===
match
---
operator: = [80910,80911]
operator: = [80922,80923]
===
match
---
name: email_alert [56515,56526]
name: email_alert [56527,56538]
===
match
---
operator: , [35682,35683]
operator: , [35682,35683]
===
match
---
atom_expr [46203,46216]
atom_expr [46203,46216]
===
match
---
name: error_file [52861,52871]
name: error_file [52861,52871]
===
match
---
name: timezone [49245,49253]
name: timezone [49245,49253]
===
match
---
string: """Return TI Context""" [57354,57377]
string: """Return TI Context""" [57366,57389]
===
match
---
trailer [13004,13013]
trailer [13004,13013]
===
match
---
trailer [7584,7593]
trailer [7584,7593]
===
match
---
simple_stmt [48779,48827]
simple_stmt [48779,48827]
===
match
---
name: hasattr [67706,67713]
name: hasattr [67718,67725]
===
match
---
operator: = [36911,36912]
operator: = [36911,36912]
===
match
---
trailer [53278,53283]
trailer [53278,53283]
===
match
---
simple_stmt [42266,42319]
simple_stmt [42266,42319]
===
match
---
operator: = [66256,66257]
operator: = [66268,66269]
===
match
---
simple_stmt [25231,25264]
simple_stmt [25231,25264]
===
match
---
string: '%Y%m%dT%H%M%S' [59602,59617]
string: '%Y%m%dT%H%M%S' [59614,59629]
===
match
---
operator: , [1050,1051]
operator: , [1050,1051]
===
match
---
name: handle_failure [45846,45860]
name: handle_failure [45846,45860]
===
match
---
annassign [40000,40064]
annassign [40000,40064]
===
match
---
operator: = [69419,69420]
operator: = [69431,69432]
===
match
---
atom_expr [55425,55505]
atom_expr [55437,55517]
===
match
---
operator: = [68360,68361]
operator: = [68372,68373]
===
match
---
operator: = [31912,31913]
operator: = [31912,31913]
===
match
---
name: e [44594,44595]
name: e [44594,44595]
===
match
---
tfpdef [62195,62204]
tfpdef [62207,62216]
===
match
---
trailer [59577,59592]
trailer [59589,59604]
===
match
---
operator: , [62696,62697]
operator: , [62708,62709]
===
match
---
name: models [2036,2042]
name: models [2036,2042]
===
match
---
name: timezone [44198,44206]
name: timezone [44198,44206]
===
match
---
name: Exception [48253,48262]
name: Exception [48253,48262]
===
match
---
atom_expr [42661,42672]
atom_expr [42661,42672]
===
match
---
trailer [69639,69660]
trailer [69651,69672]
===
match
---
string: 'prev_ds' [63165,63174]
string: 'prev_ds' [63177,63186]
===
match
---
atom_expr [76135,76173]
atom_expr [76147,76185]
===
match
---
name: pickle_id [18959,18968]
name: pickle_id [18959,18968]
===
match
---
funcdef [79792,79843]
funcdef [79804,79855]
===
match
---
name: get_connection_from_secrets [62255,62282]
name: get_connection_from_secrets [62267,62294]
===
match
---
trailer [25961,25963]
trailer [25961,25963]
===
match
---
atom_expr [24161,24175]
atom_expr [24161,24175]
===
match
---
atom_expr [44198,44215]
atom_expr [44198,44215]
===
match
---
string: 'html_content_template' [70484,70507]
string: 'html_content_template' [70496,70519]
===
match
---
operator: == [39941,39943]
operator: == [39941,39943]
===
match
---
argument [29375,29387]
argument [29375,29387]
===
match
---
name: execution_date [9110,9124]
name: execution_date [9110,9124]
===
match
---
name: session [22186,22193]
name: session [22186,22193]
===
match
---
dotted_name [1899,1924]
dotted_name [1899,1924]
===
match
---
trailer [69847,69858]
trailer [69859,69870]
===
match
---
arith_expr [19924,20007]
arith_expr [19924,20007]
===
match
---
trailer [71138,71140]
trailer [71150,71152]
===
match
---
param [76121,76174]
param [76133,76186]
===
match
---
string: '-' [59735,59738]
string: '-' [59747,59750]
===
match
---
sync_comp_for [77390,77402]
sync_comp_for [77402,77414]
===
match
---
atom_expr [30389,30441]
atom_expr [30389,30441]
===
match
---
name: dump [4456,4460]
name: dump [4456,4460]
===
match
---
suite [19041,19092]
suite [19041,19092]
===
match
---
trailer [67008,67010]
trailer [67020,67022]
===
match
---
trailer [41523,41527]
trailer [41523,41527]
===
match
---
operator: , [16119,16120]
operator: , [16119,16120]
===
match
---
trailer [11050,11063]
trailer [11050,11063]
===
match
---
comparison [5325,5350]
comparison [5325,5350]
===
match
---
param [65338,65350]
param [65350,65362]
===
match
---
trailer [51021,51023]
trailer [51021,51023]
===
match
---
name: self [66069,66073]
name: self [66081,66085]
===
match
---
name: self [58856,58860]
name: self [58868,58872]
===
match
---
suite [74527,74561]
suite [74539,74573]
===
match
---
trailer [57857,57864]
trailer [57869,57876]
===
match
---
name: prev_execution_date [58685,58704]
name: prev_execution_date [58697,58716]
===
match
---
name: self [66411,66415]
name: self [66423,66427]
===
match
---
name: reschedule_exception [53431,53451]
name: reschedule_exception [53431,53451]
===
match
---
suite [56668,56701]
suite [56680,56713]
===
match
---
trailer [5410,5419]
trailer [5410,5419]
===
match
---
atom_expr [24548,24560]
atom_expr [24548,24560]
===
match
---
operator: @ [79460,79461]
operator: @ [79472,79473]
===
match
---
operator: , [39430,39431]
operator: , [39430,39431]
===
match
---
name: kube_config [3080,3091]
name: kube_config [3080,3091]
===
match
---
name: stacklevel [7913,7923]
name: stacklevel [7913,7923]
===
match
---
atom_expr [59068,59108]
atom_expr [59080,59120]
===
match
---
operator: = [76559,76560]
operator: = [76571,76572]
===
match
---
name: Log [46341,46344]
name: Log [46341,46344]
===
match
---
simple_stmt [21212,21225]
simple_stmt [21212,21225]
===
match
---
operator: , [70077,70078]
operator: , [70089,70090]
===
match
---
number: 0 [21156,21157]
number: 0 [21156,21157]
===
match
---
operator: @ [79610,79611]
operator: @ [79622,79623]
===
match
---
name: self [50172,50176]
name: self [50172,50176]
===
match
---
if_stmt [27542,28215]
if_stmt [27542,28215]
===
match
---
trailer [54207,54213]
trailer [54207,54213]
===
match
---
name: bool [16633,16637]
name: bool [16633,16637]
===
match
---
trailer [56172,56178]
trailer [56184,56190]
===
match
---
atom_expr [6273,6290]
atom_expr [6273,6290]
===
match
---
name: conf [62692,62696]
name: conf [62704,62708]
===
match
---
fstring_start: f" [20261,20263]
fstring_start: f" [20261,20263]
===
match
---
name: task [57386,57390]
name: task [57398,57402]
===
match
---
name: default_var [60756,60767]
name: default_var [60768,60779]
===
match
---
name: task [5674,5678]
name: task [5674,5678]
===
match
---
name: VariableAccessor [64104,64120]
name: VariableAccessor [64116,64132]
===
match
---
expr_stmt [57953,57997]
expr_stmt [57965,58009]
===
match
---
operator: @ [71258,71259]
operator: @ [71270,71271]
===
match
---
trailer [16742,16747]
trailer [16742,16747]
===
match
---
trailer [40710,40766]
trailer [40710,40766]
===
match
---
name: PodGenerator [67217,67229]
name: PodGenerator [67229,67241]
===
match
---
name: in_ [26865,26868]
name: in_ [26865,26868]
===
match
---
string: '' [57536,57538]
string: '' [57548,57550]
===
match
---
name: debug [71205,71210]
name: debug [71217,71222]
===
match
---
name: self [66374,66378]
name: self [66386,66390]
===
match
---
arglist [36348,36422]
arglist [36348,36422]
===
match
---
trailer [54235,54242]
trailer [54235,54242]
===
match
---
name: AirflowNotFoundException [1664,1688]
name: AirflowNotFoundException [1664,1688]
===
match
---
string: """         This attribute is deprecated.         Please use `airflow.models.taskinstance.TaskInstance.get_previous_ti` method.         """ [29523,29662]
string: """         This attribute is deprecated.         Please use `airflow.models.taskinstance.TaskInstance.get_previous_ti` method.         """ [29523,29662]
===
match
---
operator: , [64122,64123]
operator: , [64134,64135]
===
match
---
name: State [14080,14085]
name: State [14080,14085]
===
match
---
simple_stmt [44521,44548]
simple_stmt [44521,44548]
===
match
---
return_stmt [77545,77820]
return_stmt [77557,77832]
===
match
---
param [13616,13620]
param [13616,13620]
===
match
---
atom_expr [15653,15665]
atom_expr [15653,15665]
===
match
---
tfpdef [24990,25000]
tfpdef [24990,25000]
===
match
---
trailer [53263,53265]
trailer [53263,53265]
===
match
---
name: session [57044,57051]
name: session [57056,57063]
===
match
---
suite [59045,59236]
suite [59057,59248]
===
match
---
name: settings [41909,41917]
name: settings [41909,41917]
===
match
---
name: airflow [2663,2670]
name: airflow [2663,2670]
===
match
---
trailer [33909,33917]
trailer [33909,33917]
===
match
---
arglist [3789,3928]
arglist [3789,3928]
===
match
---
simple_stmt [12860,12917]
simple_stmt [12860,12917]
===
match
---
simple_stmt [50518,50579]
simple_stmt [50518,50579]
===
match
---
trailer [39934,39940]
trailer [39934,39940]
===
match
---
atom_expr [36365,36376]
atom_expr [36365,36376]
===
match
---
name: self [49129,49133]
name: self [49129,49133]
===
match
---
atom_expr [9078,9089]
atom_expr [9078,9089]
===
match
---
tfpdef [71354,71388]
tfpdef [71366,71400]
===
match
---
trailer [42029,42093]
trailer [42029,42093]
===
match
---
atom_expr [69676,69941]
atom_expr [69688,69953]
===
match
---
expr_stmt [19864,19908]
expr_stmt [19864,19908]
===
match
---
simple_stmt [24686,24722]
simple_stmt [24686,24722]
===
match
---
if_stmt [5322,6238]
if_stmt [5322,6238]
===
match
---
simple_stmt [35768,35887]
simple_stmt [35768,35887]
===
match
---
suite [42431,42853]
suite [42431,42853]
===
match
---
test [57962,57997]
test [57974,58009]
===
match
---
trailer [41279,41285]
trailer [41279,41285]
===
match
---
name: open [4394,4398]
name: open [4394,4398]
===
match
---
operator: , [4657,4658]
operator: , [4657,4658]
===
match
---
trailer [41402,41407]
trailer [41402,41407]
===
match
---
trailer [42639,42645]
trailer [42639,42645]
===
match
---
operator: == [26690,26692]
operator: == [26690,26692]
===
match
---
simple_stmt [21559,21579]
simple_stmt [21559,21579]
===
match
---
operator: = [20520,20521]
operator: = [20520,20521]
===
match
---
trailer [21469,21475]
trailer [21469,21475]
===
match
---
name: staticmethod [16370,16382]
name: staticmethod [16370,16382]
===
match
---
name: defaultdict [5276,5287]
name: defaultdict [5276,5287]
===
match
---
atom_expr [64704,64750]
atom_expr [64716,64762]
===
match
---
expr_stmt [76032,76046]
expr_stmt [76044,76058]
===
match
---
name: task_id [12189,12196]
name: task_id [12189,12196]
===
match
---
name: upper [42640,42645]
name: upper [42640,42645]
===
match
---
parameters [27036,27110]
parameters [27036,27110]
===
match
---
atom_expr [4647,4657]
atom_expr [4647,4657]
===
match
---
trailer [69718,69927]
trailer [69730,69939]
===
match
---
string: '' [59798,59800]
string: '' [59810,59812]
===
match
---
name: end_date [35711,35719]
name: end_date [35711,35719]
===
match
---
simple_stmt [3260,3297]
simple_stmt [3260,3297]
===
match
---
atom_expr [12279,12312]
atom_expr [12279,12312]
===
match
---
decorated [53362,54323]
decorated [53362,54323]
===
match
---
trailer [51209,51229]
trailer [51209,51229]
===
match
---
parameters [12031,12098]
parameters [12031,12098]
===
match
---
sync_comp_for [75152,75211]
sync_comp_for [75164,75223]
===
match
---
operator: , [42409,42410]
operator: , [42409,42410]
===
match
---
string: "Task Duration set to %s" [71211,71236]
string: "Task Duration set to %s" [71223,71248]
===
match
---
if_stmt [12391,12917]
if_stmt [12391,12917]
===
match
---
tfpdef [50281,50297]
tfpdef [50281,50297]
===
match
---
name: TemplateAssertionError [65715,65737]
name: TemplateAssertionError [65727,65749]
===
match
---
name: context [51040,51047]
name: context [51040,51047]
===
match
---
name: dep_context [40375,40386]
name: dep_context [40375,40386]
===
match
---
operator: , [33733,33734]
operator: , [33733,33734]
===
match
---
name: error_file [46018,46028]
name: error_file [46018,46028]
===
match
---
atom_expr [39037,39328]
atom_expr [39037,39328]
===
match
---
name: execution_date [22345,22359]
name: execution_date [22345,22359]
===
match
---
name: Stats [47075,47080]
name: Stats [47075,47080]
===
match
---
name: self [56959,56963]
name: self [56971,56975]
===
match
---
name: task_id [66763,66770]
name: task_id [66775,66782]
===
match
---
trailer [69471,69488]
trailer [69483,69500]
===
match
---
name: error_file [55054,55064]
name: error_file [55066,55076]
===
match
---
arglist [77861,77931]
arglist [77873,77943]
===
match
---
operator: , [49001,49002]
operator: , [49001,49002]
===
match
---
atom_expr [41171,41202]
atom_expr [41171,41202]
===
match
---
name: try_number [34592,34602]
name: try_number [34592,34602]
===
match
---
fstring_string: operator_successes_ [48957,48976]
fstring_string: operator_successes_ [48957,48976]
===
match
---
trailer [41478,41489]
trailer [41478,41489]
===
match
---
atom_expr [10618,10637]
atom_expr [10618,10637]
===
match
---
name: PodGenerator [3159,3171]
name: PodGenerator [3159,3171]
===
match
---
name: task [24030,24034]
name: task [24030,24034]
===
match
---
trailer [7042,7053]
trailer [7042,7053]
===
match
---
operator: @ [14818,14819]
operator: @ [14818,14819]
===
match
---
operator: , [53410,53411]
operator: , [53410,53411]
===
match
---
name: self [79802,79806]
name: self [79814,79818]
===
match
---
name: utils [2671,2676]
name: utils [2671,2676]
===
match
---
name: self [47039,47043]
name: self [47039,47043]
===
match
---
name: context [51338,51345]
name: context [51338,51345]
===
match
---
atom_expr [23005,23016]
atom_expr [23005,23016]
===
match
---
trailer [44622,44625]
trailer [44622,44625]
===
match
---
trailer [23445,23480]
trailer [23445,23480]
===
match
---
trailer [78815,78821]
trailer [78827,78833]
===
match
---
operator: , [45862,45863]
operator: , [45862,45863]
===
match
---
name: models [65427,65433]
name: models [65439,65445]
===
match
---
atom_expr [46112,46123]
atom_expr [46112,46123]
===
match
---
operator: } [33953,33954]
operator: } [33953,33954]
===
match
---
operator: + [14163,14164]
operator: + [14163,14164]
===
match
---
expr_stmt [52632,52674]
expr_stmt [52632,52674]
===
match
---
name: self [19823,19827]
name: self [19823,19827]
===
match
---
name: self [13305,13309]
name: self [13305,13309]
===
match
---
operator: , [46016,46017]
operator: , [46016,46017]
===
match
---
name: jinja2 [1154,1160]
name: jinja2 [1154,1160]
===
match
---
operator: == [25474,25476]
operator: == [25474,25476]
===
match
---
decorator [53362,53379]
decorator [53362,53379]
===
match
---
param [51979,52006]
param [51979,52006]
===
match
---
name: dag_id [20930,20936]
name: dag_id [20930,20936]
===
match
---
operator: = [40743,40744]
operator: = [40743,40744]
===
match
---
trailer [69430,69442]
trailer [69442,69454]
===
match
---
name: verbose_aware_logger [32848,32868]
name: verbose_aware_logger [32848,32868]
===
match
---
comparison [8388,8411]
comparison [8388,8411]
===
match
---
name: self [21054,21058]
name: self [21054,21058]
===
match
---
operator: == [26810,26812]
operator: == [26810,26812]
===
match
---
trailer [24650,24652]
trailer [24650,24652]
===
match
---
suite [44596,44645]
suite [44596,44645]
===
match
---
argument [11016,11030]
argument [11016,11030]
===
match
---
trailer [68907,68914]
trailer [68919,68926]
===
match
---
name: prev_ds [59414,59421]
name: prev_ds [59426,59433]
===
match
---
strings [40910,41058]
strings [40910,41058]
===
match
---
number: 2 [34581,34582]
number: 2 [34581,34582]
===
match
---
atom_expr [78098,78125]
atom_expr [78110,78137]
===
match
---
name: execute [50010,50017]
name: execute [50010,50017]
===
match
---
atom_expr [44534,44547]
atom_expr [44534,44547]
===
match
---
name: state [30487,30492]
name: state [30487,30492]
===
match
---
name: task_id_by_key [6331,6345]
name: task_id_by_key [6331,6345]
===
match
---
name: e [46004,46005]
name: e [46004,46005]
===
match
---
atom_expr [64798,64821]
atom_expr [64810,64833]
===
match
---
simple_stmt [42327,42385]
simple_stmt [42327,42385]
===
match
---
trailer [24594,24609]
trailer [24594,24609]
===
match
---
name: last_scheduling_decision [8731,8755]
name: last_scheduling_decision [8731,8755]
===
match
---
trailer [23033,23042]
trailer [23033,23042]
===
match
---
name: get_previous_ti [30465,30480]
name: get_previous_ti [30465,30480]
===
match
---
atom_expr [42810,42841]
atom_expr [42810,42841]
===
match
---
atom_expr [15584,15601]
atom_expr [15584,15601]
===
match
---
simple_stmt [41617,41655]
simple_stmt [41617,41655]
===
match
---
name: str [4647,4650]
name: str [4647,4650]
===
match
---
trailer [25374,25385]
trailer [25374,25385]
===
match
---
name: TaskInstance [80648,80660]
name: TaskInstance [80660,80672]
===
match
---
name: TaskFail [55437,55445]
name: TaskFail [55449,55457]
===
match
---
name: execution_date [76910,76924]
name: execution_date [76922,76936]
===
match
---
operator: = [10594,10595]
operator: = [10594,10595]
===
match
---
name: lazy_object_proxy [63487,63504]
name: lazy_object_proxy [63499,63516]
===
match
---
name: and_ [7035,7039]
name: and_ [7035,7039]
===
match
---
atom_expr [55437,55504]
atom_expr [55449,55516]
===
match
---
operator: == [77737,77739]
operator: == [77749,77751]
===
match
---
name: queue [79796,79801]
name: queue [79808,79813]
===
match
---
name: full_filepath [15748,15761]
name: full_filepath [15748,15761]
===
match
---
name: TaskInstanceKey [9537,9552]
name: TaskInstanceKey [9537,9552]
===
match
---
name: Exception [4204,4213]
name: Exception [4204,4213]
===
match
---
trailer [56963,56978]
trailer [56975,56990]
===
match
---
trailer [44213,44215]
trailer [44213,44215]
===
match
---
trailer [59214,59235]
trailer [59226,59247]
===
match
---
operator: = [11223,11224]
operator: = [11223,11224]
===
match
---
trailer [41764,41770]
trailer [41764,41770]
===
match
---
import_from [66549,66621]
import_from [66561,66633]
===
match
---
trailer [10814,10823]
trailer [10814,10823]
===
match
---
name: self [48215,48219]
name: self [48215,48219]
===
match
---
simple_stmt [10976,11032]
simple_stmt [10976,11032]
===
match
---
name: self [62865,62869]
name: self [62877,62881]
===
match
---
atom_expr [56815,56836]
atom_expr [56827,56848]
===
match
---
name: getuser [2803,2810]
name: getuser [2803,2810]
===
match
---
operator: = [22184,22185]
operator: = [22184,22185]
===
match
---
sync_comp_for [7239,7286]
sync_comp_for [7239,7286]
===
match
---
trailer [80821,80827]
trailer [80833,80839]
===
match
---
operator: = [29385,29386]
operator: = [29385,29386]
===
match
---
trailer [24494,24643]
trailer [24494,24643]
===
match
---
funcdef [60371,60423]
funcdef [60383,60435]
===
match
---
atom_expr [46824,46843]
atom_expr [46824,46843]
===
match
---
decorated [72590,75495]
decorated [72602,75507]
===
match
---
string: "run" [18851,18856]
string: "run" [18851,18856]
===
match
---
name: getLogger [12287,12296]
name: getLogger [12287,12296]
===
match
---
name: self [44094,44098]
name: self [44094,44098]
===
match
---
arglist [12502,12616]
arglist [12502,12616]
===
match
---
string: "Exporting the following env vars:\n%s" [47595,47634]
string: "Exporting the following env vars:\n%s" [47595,47634]
===
match
---
return_stmt [26945,26990]
return_stmt [26945,26990]
===
match
---
subscriptlist [3249,3257]
subscriptlist [3249,3257]
===
match
---
name: delete [24644,24650]
name: delete [24644,24650]
===
match
---
operator: @ [33190,33191]
operator: @ [33190,33191]
===
match
---
simple_stmt [5659,5687]
simple_stmt [5659,5687]
===
match
---
simple_stmt [23832,23856]
simple_stmt [23832,23856]
===
match
---
atom_expr [20852,21107]
atom_expr [20852,21107]
===
match
---
name: Optional [54440,54448]
name: Optional [54440,54448]
===
match
---
name: next_ds [59138,59145]
name: next_ds [59150,59157]
===
match
---
operator: = [36705,36706]
operator: = [36705,36706]
===
match
---
simple_stmt [3297,3331]
simple_stmt [3297,3331]
===
match
---
name: ts_nodash_with_tz [59627,59644]
name: ts_nodash_with_tz [59639,59656]
===
match
---
name: _log [12272,12276]
name: _log [12272,12276]
===
match
---
atom_expr [5337,5350]
atom_expr [5337,5350]
===
match
---
testlist_comp [26870,26898]
testlist_comp [26870,26898]
===
match
---
name: session [53470,53477]
name: session [53470,53477]
===
match
---
name: TaskReschedule [2065,2079]
name: TaskReschedule [2065,2079]
===
match
---
operator: = [38330,38331]
operator: = [38330,38331]
===
match
---
param [23508,23513]
param [23508,23513]
===
match
---
trailer [57233,57244]
trailer [57245,57256]
===
match
---
operator: , [23473,23474]
operator: , [23473,23474]
===
match
---
name: self [20112,20116]
name: self [20112,20116]
===
match
---
atom_expr [77677,77687]
atom_expr [77689,77699]
===
match
---
param [29480,29484]
param [29480,29484]
===
match
---
simple_stmt [3585,3618]
simple_stmt [3585,3618]
===
match
---
name: dep_context [33324,33335]
name: dep_context [33324,33335]
===
match
---
name: ti [6262,6264]
name: ti [6262,6264]
===
match
---
number: 1 [54189,54190]
number: 1 [54189,54190]
===
match
---
name: self [42240,42244]
name: self [42240,42244]
===
match
---
operator: = [16677,16678]
operator: = [16677,16678]
===
match
---
name: str [56821,56824]
name: str [56833,56836]
===
match
---
simple_stmt [1186,1202]
simple_stmt [1186,1202]
===
match
---
name: self [26014,26018]
name: self [26014,26018]
===
match
---
atom_expr [64104,64122]
atom_expr [64116,64134]
===
match
---
suite [19657,19707]
suite [19657,19707]
===
match
---
string: 'ts_nodash' [63934,63945]
string: 'ts_nodash' [63946,63957]
===
match
---
simple_stmt [55425,55506]
simple_stmt [55437,55518]
===
match
---
name: ti_hash [34669,34676]
name: ti_hash [34669,34676]
===
match
---
trailer [57969,57976]
trailer [57981,57988]
===
match
---
name: start_date [40155,40165]
name: start_date [40155,40165]
===
match
---
trailer [34205,34217]
trailer [34205,34217]
===
match
---
name: property [79679,79687]
name: property [79691,79699]
===
match
---
operator: , [62982,62983]
operator: , [62994,62995]
===
match
---
trailer [69574,69591]
trailer [69586,69603]
===
match
---
operator: , [45767,45768]
operator: , [45767,45768]
===
match
---
suite [70793,70857]
suite [70805,70869]
===
match
---
atom_expr [49205,49218]
atom_expr [49205,49218]
===
match
---
name: schedule [28174,28182]
name: schedule [28174,28182]
===
match
---
simple_stmt [76216,76281]
simple_stmt [76228,76293]
===
match
---
trailer [6889,7304]
trailer [6889,7304]
===
match
---
name: primary [8956,8963]
name: primary [8956,8963]
===
match
---
trailer [62869,62884]
trailer [62881,62896]
===
match
---
trailer [33470,33498]
trailer [33470,33498]
===
match
---
trailer [52557,52561]
trailer [52557,52561]
===
match
---
atom_expr [9356,9383]
atom_expr [9356,9383]
===
match
---
name: dag_run [58635,58642]
name: dag_run [58647,58654]
===
match
---
suite [56476,56642]
suite [56488,56654]
===
match
---
suite [44322,44454]
suite [44322,44454]
===
match
---
operator: = [16638,16639]
operator: = [16638,16639]
===
match
---
trailer [80776,80778]
trailer [80788,80790]
===
match
---
fstring_expr [48976,48997]
fstring_expr [48976,48997]
===
match
---
decorated [79294,79374]
decorated [79306,79386]
===
match
---
expr_stmt [32643,32710]
expr_stmt [32643,32710]
===
match
---
name: String [11331,11337]
name: String [11331,11337]
===
match
---
name: next_ds [62975,62982]
name: next_ds [62987,62994]
===
match
---
string: """         Return the try number that this task number will be when it is actually         run.          If the TaskInstance is currently running, this will match the column in the         database, in all other cases this will be incremented.         """ [13631,13887]
string: """         Return the try number that this task number will be when it is actually         run.          If the TaskInstance is currently running, this will match the column in the         database, in all other cases this will be incremented.         """ [13631,13887]
===
match
---
simple_stmt [67493,67545]
simple_stmt [67505,67557]
===
match
---
atom_expr [70243,70297]
atom_expr [70255,70309]
===
match
---
name: self [59573,59577]
name: self [59585,59589]
===
match
---
name: session [40736,40743]
name: session [40736,40743]
===
match
---
atom_expr [78788,78802]
atom_expr [78800,78814]
===
match
---
name: dag_id [80561,80567]
name: dag_id [80573,80579]
===
match
---
trailer [76564,76567]
trailer [76576,76579]
===
match
---
name: state [56173,56178]
name: state [56185,56190]
===
match
---
name: bool [36700,36704]
name: bool [36700,36704]
===
match
---
string: "--raw" [19557,19564]
string: "--raw" [19557,19564]
===
match
---
name: pickle_id [16213,16222]
name: pickle_id [16213,16222]
===
match
---
name: self [70817,70821]
name: self [70829,70833]
===
match
---
name: self [12926,12930]
name: self [12926,12930]
===
match
---
operator: = [10409,10410]
operator: = [10409,10410]
===
match
---
atom_expr [64910,65272]
atom_expr [64922,65284]
===
match
---
suite [33857,33958]
suite [33857,33958]
===
match
---
dotted_name [65419,65450]
dotted_name [65431,65462]
===
match
---
name: ti [20833,20835]
name: ti [20833,20835]
===
match
---
if_stmt [33062,33098]
if_stmt [33062,33098]
===
match
---
name: base_worker_pod [67201,67216]
name: base_worker_pod [67213,67228]
===
match
---
name: commit [41316,41322]
name: commit [41316,41322]
===
match
---
expr_stmt [11301,11364]
expr_stmt [11301,11364]
===
match
---
operator: , [11750,11751]
operator: , [11750,11751]
===
match
---
name: tis [5309,5312]
name: tis [5309,5312]
===
match
---
operator: , [49487,49488]
operator: , [49487,49488]
===
match
---
trailer [26626,26648]
trailer [26626,26648]
===
match
---
not_test [15526,15539]
not_test [15526,15539]
===
match
---
name: TaskInstance [15816,15828]
name: TaskInstance [15816,15828]
===
match
---
trailer [45585,45587]
trailer [45585,45587]
===
match
---
trailer [45988,46003]
trailer [45988,46003]
===
match
---
name: with_try_number [9394,9409]
name: with_try_number [9394,9409]
===
match
---
atom_expr [77955,77969]
atom_expr [77967,77981]
===
match
---
name: task_id [77434,77441]
name: task_id [77446,77453]
===
match
---
argument [60056,60069]
argument [60068,60081]
===
match
---
parameters [16407,16943]
parameters [16407,16943]
===
match
---
testlist_comp [11524,11812]
testlist_comp [11524,11812]
===
match
---
trailer [28044,28065]
trailer [28044,28065]
===
match
---
argument [28701,28716]
argument [28701,28716]
===
match
---
simple_stmt [70806,70857]
simple_stmt [70818,70869]
===
match
---
operator: = [76584,76585]
operator: = [76596,76597]
===
match
---
simple_stmt [75239,75309]
simple_stmt [75251,75321]
===
match
---
simple_stmt [57200,57263]
simple_stmt [57212,57275]
===
match
---
name: ti [78968,78970]
name: ti [78980,78982]
===
match
---
trailer [7662,7671]
trailer [7662,7671]
===
match
---
trailer [23278,23287]
trailer [23278,23287]
===
match
---
operator: = [11012,11013]
operator: = [11012,11013]
===
match
---
name: state [22730,22735]
name: state [22730,22735]
===
match
---
atom_expr [10411,10469]
atom_expr [10411,10469]
===
match
---
trailer [67368,67370]
trailer [67380,67382]
===
match
---
name: get [60912,60915]
name: get [60924,60927]
===
match
---
atom_expr [26965,26989]
atom_expr [26965,26989]
===
match
---
name: self [72298,72302]
name: self [72310,72314]
===
match
---
trailer [19445,19458]
trailer [19445,19458]
===
match
---
operator: = [40795,40796]
operator: = [40795,40796]
===
match
---
simple_stmt [13083,13102]
simple_stmt [13083,13102]
===
match
---
name: full_filepath [15710,15723]
name: full_filepath [15710,15723]
===
match
---
argument [39168,39199]
argument [39168,39199]
===
match
---
string: 'Host: {{ti.hostname}}<br>' [68213,68240]
string: 'Host: {{ti.hostname}}<br>' [68225,68252]
===
match
---
operator: { [33890,33891]
operator: { [33890,33891]
===
match
---
atom_expr [28548,28569]
atom_expr [28548,28569]
===
match
---
atom_expr [79982,80003]
atom_expr [79994,80015]
===
match
---
simple_stmt [2948,2990]
simple_stmt [2948,2990]
===
match
---
operator: -> [9646,9648]
operator: -> [9646,9648]
===
match
---
expr_stmt [44094,44116]
expr_stmt [44094,44116]
===
match
---
name: state [30649,30654]
name: state [30649,30654]
===
match
---
name: str [30665,30668]
name: str [30665,30668]
===
match
---
atom_expr [75089,75103]
atom_expr [75101,75115]
===
match
---
trailer [76674,76682]
trailer [76686,76694]
===
match
---
string: """         Checks on whether the task instance is in the right state and timeframe         to be retried.         """ [35768,35886]
string: """         Checks on whether the task instance is in the right state and timeframe         to be retried.         """ [35768,35886]
===
match
---
param [24984,24989]
param [24984,24989]
===
match
---
name: enrich_errors [42887,42900]
name: enrich_errors [42887,42900]
===
match
---
name: self [61511,61515]
name: self [61523,61527]
===
match
---
atom_expr [44026,44037]
atom_expr [44026,44037]
===
match
---
suite [60983,61885]
suite [60995,61897]
===
match
---
name: context [47519,47526]
name: context [47519,47526]
===
match
---
import_from [2306,2356]
import_from [2306,2356]
===
match
---
name: State [63571,63576]
name: State [63583,63588]
===
match
---
name: in_ [8435,8438]
name: in_ [8435,8438]
===
match
---
trailer [38676,38681]
trailer [38676,38681]
===
match
---
name: Optional [30128,30136]
name: Optional [30128,30136]
===
match
---
suite [33072,33098]
suite [33072,33098]
===
match
---
operator: } [55266,55267]
operator: } [55278,55279]
===
match
---
expr_stmt [69406,69488]
expr_stmt [69418,69500]
===
match
---
not_test [52532,52539]
not_test [52532,52539]
===
match
---
atom_expr [53815,53831]
atom_expr [53815,53831]
===
match
---
name: _dag_id [79114,79121]
name: _dag_id [79126,79133]
===
match
---
name: self [38630,38634]
name: self [38630,38634]
===
match
---
name: TR [6849,6851]
name: TR [6849,6851]
===
match
---
operator: , [18864,18865]
operator: , [18864,18865]
===
match
---
name: item [62195,62199]
name: item [62207,62211]
===
match
---
param [42246,42255]
param [42246,42255]
===
match
---
simple_stmt [57386,57403]
simple_stmt [57398,57415]
===
match
---
name: ti [22964,22966]
name: ti [22964,22966]
===
match
---
operator: = [51816,51817]
operator: = [51816,51817]
===
match
---
expr_stmt [71075,71140]
expr_stmt [71087,71152]
===
match
---
atom_expr [61411,61452]
atom_expr [61423,61464]
===
match
---
atom_expr [33517,33752]
atom_expr [33517,33752]
===
match
---
trailer [45081,45133]
trailer [45081,45133]
===
match
---
expr_stmt [56272,56303]
expr_stmt [56284,56315]
===
match
---
trailer [23408,23414]
trailer [23408,23414]
===
match
---
trailer [8312,8320]
trailer [8312,8320]
===
match
---
operator: , [33694,33695]
operator: , [33694,33695]
===
match
---
atom_expr [35653,35690]
atom_expr [35653,35690]
===
match
---
return_stmt [4167,4192]
return_stmt [4167,4192]
===
match
---
name: mark_success [15943,15955]
name: mark_success [15943,15955]
===
match
---
name: Optional [16876,16884]
name: Optional [16876,16884]
===
match
---
operator: , [8477,8478]
operator: , [8477,8478]
===
match
---
operator: , [51783,51784]
operator: , [51783,51784]
===
match
---
name: self [79153,79157]
name: self [79165,79169]
===
match
---
operator: = [57773,57774]
operator: = [57785,57786]
===
match
---
simple_stmt [64395,64466]
simple_stmt [64407,64478]
===
match
---
name: signum [46722,46728]
name: signum [46722,46728]
===
match
---
name: ignore_task_deps [40585,40601]
name: ignore_task_deps [40585,40601]
===
match
---
param [16906,16937]
param [16906,16937]
===
match
---
name: self [44393,44397]
name: self [44393,44397]
===
match
---
name: self [31293,31297]
name: self [31293,31297]
===
match
---
name: context [48911,48918]
name: context [48911,48918]
===
match
---
param [16694,16714]
param [16694,16714]
===
match
---
trailer [13309,13313]
trailer [13309,13313]
===
match
---
name: execution_date [58861,58875]
name: execution_date [58873,58887]
===
match
---
name: default [10781,10788]
name: default [10781,10788]
===
match
---
name: session [72827,72834]
name: session [72839,72846]
===
match
---
comparison [51360,51392]
comparison [51360,51392]
===
match
---
name: filter [80528,80534]
name: filter [80540,80546]
===
match
---
name: hashlib [812,819]
name: hashlib [812,819]
===
match
---
trailer [46661,46663]
trailer [46661,46663]
===
match
---
decorated [3333,3943]
decorated [3333,3943]
===
match
---
suite [57594,58061]
suite [57606,58073]
===
match
---
name: self [63766,63770]
name: self [63778,63782]
===
match
---
if_stmt [50857,51621]
if_stmt [50857,51621]
===
match
---
expr_stmt [56316,56353]
expr_stmt [56328,56365]
===
match
---
name: TaskInstance [78281,78293]
name: TaskInstance [78293,78305]
===
match
---
atom_expr [33920,33939]
atom_expr [33920,33939]
===
match
---
name: self [53590,53594]
name: self [53590,53594]
===
match
---
tfpdef [43053,43072]
tfpdef [43053,43072]
===
match
---
suite [79815,79843]
suite [79827,79855]
===
match
---
if_stmt [76508,76544]
if_stmt [76520,76556]
===
match
---
name: ti [77797,77799]
name: ti [77809,77811]
===
match
---
expr_stmt [75061,75225]
expr_stmt [75073,75237]
===
match
---
name: dep_context [32778,32789]
name: dep_context [32778,32789]
===
match
---
name: self [52687,52691]
name: self [52687,52691]
===
match
---
trailer [13378,13388]
trailer [13378,13388]
===
match
---
name: get_previous_ti [29939,29954]
name: get_previous_ti [29939,29954]
===
match
---
name: state [28806,28811]
name: state [28806,28811]
===
match
---
atom_expr [72467,72478]
atom_expr [72479,72490]
===
match
---
if_stmt [77181,77474]
if_stmt [77193,77486]
===
match
---
atom_expr [53274,53283]
atom_expr [53274,53283]
===
match
---
name: execution_date [15915,15929]
name: execution_date [15915,15929]
===
match
---
with_stmt [47070,48935]
with_stmt [47070,48935]
===
match
---
simple_stmt [8728,8763]
simple_stmt [8728,8763]
===
match
---
tfpdef [61358,61367]
tfpdef [61370,61379]
===
match
---
suite [79424,79455]
suite [79436,79467]
===
match
---
decorator [54328,54345]
decorator [54328,54345]
===
match
---
operator: , [72446,72447]
operator: , [72458,72459]
===
match
---
operator: = [26926,26927]
operator: = [26926,26927]
===
match
---
name: init_on_load [13425,13437]
name: init_on_load [13425,13437]
===
match
---
trailer [55256,55266]
trailer [55268,55278]
===
match
---
name: ti [5498,5500]
name: ti [5498,5500]
===
match
---
expr_stmt [76607,76644]
expr_stmt [76619,76656]
===
match
---
simple_stmt [46203,46237]
simple_stmt [46203,46237]
===
match
---
atom [38815,38825]
atom [38815,38825]
===
match
---
suite [24774,24944]
suite [24774,24944]
===
match
---
name: dag [15584,15587]
name: dag [15584,15587]
===
match
---
operator: , [3895,3896]
operator: , [3895,3896]
===
match
---
name: dag_id [75783,75789]
name: dag_id [75795,75801]
===
match
---
expr_stmt [11180,11214]
expr_stmt [11180,11214]
===
match
---
number: 1 [58297,58298]
number: 1 [58309,58310]
===
match
---
string: '' [59435,59437]
string: '' [59447,59449]
===
match
---
atom_expr [25477,25495]
atom_expr [25477,25495]
===
match
---
name: airflow [36217,36224]
name: airflow [36217,36224]
===
match
---
operator: == [35913,35915]
operator: == [35913,35915]
===
match
---
atom_expr [44125,44144]
atom_expr [44125,44144]
===
match
---
param [75970,75975]
param [75982,75987]
===
match
---
operator: , [15929,15930]
operator: , [15929,15930]
===
match
---
name: COLLATION_ARGS [10435,10449]
name: COLLATION_ARGS [10435,10449]
===
match
---
name: extend [19136,19142]
name: extend [19136,19142]
===
match
---
name: self [24423,24427]
name: self [24423,24427]
===
match
---
atom_expr [50874,50886]
atom_expr [50874,50886]
===
match
---
trailer [53649,53651]
trailer [53649,53651]
===
match
---
atom_expr [47374,47385]
atom_expr [47374,47385]
===
match
---
name: path [70165,70169]
name: path [70177,70181]
===
match
---
name: actual_start_date [44178,44195]
name: actual_start_date [44178,44195]
===
match
---
simple_stmt [60847,60880]
simple_stmt [60859,60892]
===
match
---
name: self [71196,71200]
name: self [71208,71212]
===
match
---
simple_stmt [33324,33366]
simple_stmt [33324,33366]
===
match
---
trailer [48954,49005]
trailer [48954,49005]
===
match
---
trailer [26875,26883]
trailer [26875,26883]
===
match
---
import_from [1833,1893]
import_from [1833,1893]
===
match
---
argument [40568,40601]
argument [40568,40601]
===
match
---
name: info [42025,42029]
name: info [42025,42029]
===
match
---
name: str [43032,43035]
name: str [43032,43035]
===
match
---
name: ignore_depends_on_past [16074,16096]
name: ignore_depends_on_past [16074,16096]
===
match
---
suite [69606,70535]
suite [69618,70547]
===
match
---
atom_expr [80548,80567]
atom_expr [80560,80579]
===
match
---
operator: = [15636,15637]
operator: = [15636,15637]
===
match
---
arglist [70328,70363]
arglist [70340,70375]
===
match
---
operator: , [49478,49479]
operator: , [49478,49479]
===
match
---
name: force_fail [56414,56424]
name: force_fail [56426,56436]
===
match
---
name: task_id [15889,15896]
name: task_id [15889,15896]
===
match
---
trailer [6275,6290]
trailer [6275,6290]
===
match
---
name: init_run_context [75953,75969]
name: init_run_context [75965,75981]
===
match
---
operator: , [55268,55269]
operator: , [55280,55281]
===
match
---
string: """         Returns whether or not all the conditions are met for this task instance to be run         given the context for the dependencies (e.g. a task instance being force run from         the UI will ignore some dependencies).          :param dep_context: The execution context that determines the dependencies that             should be evaluated.         :type dep_context: DepContext         :param session: database session         :type session: sqlalchemy.orm.session.Session         :param verbose: whether log details on failed dependencies on             info or debug log level         :type verbose: bool         """ [31929,32561]
string: """         Returns whether or not all the conditions are met for this task instance to be run         given the context for the dependencies (e.g. a task instance being force run from         the UI will ignore some dependencies).          :param dep_context: The execution context that determines the dependencies that             should be evaluated.         :type dep_context: DepContext         :param session: database session         :type session: sqlalchemy.orm.session.Session         :param verbose: whether log details on failed dependencies on             info or debug log level         :type verbose: bool         """ [31929,32561]
===
match
---
trailer [61480,61484]
trailer [61492,61496]
===
match
---
name: TaskInstance [21023,21035]
name: TaskInstance [21023,21035]
===
match
---
name: os [854,856]
name: os [854,856]
===
match
---
if_stmt [19031,19092]
if_stmt [19031,19092]
===
match
---
expr_stmt [44339,44376]
expr_stmt [44339,44376]
===
match
---
number: 1 [38709,38710]
number: 1 [38709,38710]
===
match
---
fstring_string: operator_failures_ [55233,55251]
fstring_string: operator_failures_ [55245,55263]
===
match
---
atom_expr [46672,46681]
atom_expr [46672,46681]
===
match
---
name: str [16925,16928]
name: str [16925,16928]
===
match
---
argument [28123,28137]
argument [28123,28137]
===
match
---
subscriptlist [50639,50653]
subscriptlist [50639,50653]
===
match
---
trailer [80879,80909]
trailer [80891,80921]
===
match
---
funcdef [28972,29437]
funcdef [28972,29437]
===
match
---
expr_stmt [65648,65694]
expr_stmt [65660,65706]
===
match
---
simple_stmt [2476,2511]
simple_stmt [2476,2511]
===
match
---
arglist [38373,38397]
arglist [38373,38397]
===
match
---
name: self [22674,22678]
name: self [22674,22678]
===
match
---
name: set_duration [55197,55209]
name: set_duration [55209,55221]
===
match
---
argument [43952,43970]
argument [43952,43970]
===
match
---
atom_expr [14146,14162]
atom_expr [14146,14162]
===
match
---
name: VariableAccessor [60103,60119]
name: VariableAccessor [60115,60131]
===
match
---
name: state [23409,23414]
name: state [23409,23414]
===
match
---
expr_stmt [80850,80869]
expr_stmt [80862,80881]
===
match
---
name: lock_for_update [80723,80738]
name: lock_for_update [80735,80750]
===
match
---
trailer [36407,36422]
trailer [36407,36422]
===
match
---
simple_stmt [8208,8270]
simple_stmt [8208,8270]
===
match
---
dotted_name [3061,3091]
dotted_name [3061,3091]
===
match
---
trailer [76884,76956]
trailer [76896,76968]
===
match
---
operator: } [20322,20323]
operator: } [20322,20323]
===
match
---
name: Optional [29489,29497]
name: Optional [29489,29497]
===
match
---
name: execution_date [76607,76621]
name: execution_date [76619,76633]
===
match
---
name: retry_exponential_backoff [34239,34264]
name: retry_exponential_backoff [34239,34264]
===
match
---
trailer [50879,50886]
trailer [50879,50886]
===
match
---
operator: = [16930,16931]
operator: = [16930,16931]
===
match
---
if_stmt [44806,44850]
if_stmt [44806,44850]
===
match
---
trailer [12188,12196]
trailer [12188,12196]
===
match
---
operator: == [77314,77316]
operator: == [77326,77328]
===
match
---
name: bool [51771,51775]
name: bool [51771,51775]
===
match
---
name: dates [8479,8484]
name: dates [8479,8484]
===
match
---
trailer [34811,34826]
trailer [34811,34826]
===
match
---
name: bool [72805,72809]
name: bool [72817,72821]
===
match
---
name: task [23845,23849]
name: task [23845,23849]
===
match
---
name: next_ds_nodash [63014,63028]
name: next_ds_nodash [63026,63040]
===
match
---
expr_stmt [13000,13025]
expr_stmt [13000,13025]
===
match
---
name: bool [54449,54453]
name: bool [54449,54453]
===
match
---
name: _task_id [79187,79195]
name: _task_id [79199,79207]
===
match
---
name: field_name [64723,64733]
name: field_name [64735,64745]
===
match
---
simple_stmt [25893,25964]
simple_stmt [25893,25964]
===
match
---
name: State [5405,5410]
name: State [5405,5410]
===
match
---
name: isinstance [54729,54739]
name: isinstance [54729,54739]
===
match
---
name: dr [27433,27435]
name: dr [27433,27435]
===
match
---
name: res [52083,52086]
name: res [52083,52086]
===
match
---
comparison [50932,50968]
comparison [50932,50968]
===
match
---
trailer [47340,47359]
trailer [47340,47359]
===
match
---
name: incr [48950,48954]
name: incr [48950,48954]
===
match
---
name: self [28045,28049]
name: self [28045,28049]
===
match
---
name: str [67753,67756]
name: str [67765,67768]
===
match
---
tfpdef [51941,51962]
tfpdef [51941,51962]
===
match
---
if_stmt [19100,19174]
if_stmt [19100,19174]
===
match
---
string: 'ti_failures' [55295,55308]
string: 'ti_failures' [55307,55320]
===
match
---
operator: = [30078,30079]
operator: = [30078,30079]
===
match
---
name: Column [10563,10569]
name: Column [10563,10569]
===
match
---
param [65957,65964]
param [65969,65976]
===
match
---
trailer [15656,15665]
trailer [15656,15665]
===
match
---
name: render_k8s_pod_yaml [66462,66481]
name: render_k8s_pod_yaml [66474,66493]
===
match
---
operator: = [30670,30671]
operator: = [30670,30671]
===
match
---
operator: , [19623,19624]
operator: , [19623,19624]
===
match
---
trailer [41253,41255]
trailer [41253,41255]
===
match
---
operator: , [72817,72818]
operator: , [72829,72830]
===
match
---
trailer [28551,28569]
trailer [28551,28569]
===
match
---
atom_expr [41519,41547]
atom_expr [41519,41547]
===
match
---
import_name [1135,1146]
import_name [1135,1146]
===
match
---
trailer [39912,39914]
trailer [39912,39914]
===
match
---
name: create_pod_id [66804,66817]
name: create_pod_id [66816,66829]
===
match
---
name: mark_success [51872,51884]
name: mark_success [51872,51884]
===
match
---
operator: @ [24181,24182]
operator: @ [24181,24182]
===
match
---
trailer [9584,9599]
trailer [9584,9599]
===
match
---
argument [39391,39430]
argument [39391,39430]
===
match
---
suite [65760,65866]
suite [65772,65878]
===
match
---
atom_expr [27059,27072]
atom_expr [27059,27072]
===
match
---
return_stmt [28082,28214]
return_stmt [28082,28214]
===
match
---
atom_expr [23274,23287]
atom_expr [23274,23287]
===
match
---
param [67467,67472]
param [67479,67484]
===
match
---
string: """         Checks whether the immediate dependents of this task instance have succeeded or have been skipped.         This is meant to be used by wait_for_downstream.          This is useful when you do not want to start processing the next         schedule of a task until the dependents are done. For instance,         if the task DROPs and recreates a table.          :param session: SQLAlchemy ORM Session         :type session: Session         """ [26043,26496]
string: """         Checks whether the immediate dependents of this task instance have succeeded or have been skipped.         This is meant to be used by wait_for_downstream.          This is useful when you do not want to start processing the next         schedule of a task until the dependents are done. For instance,         if the task DROPs and recreates a table.          :param session: SQLAlchemy ORM Session         :type session: Session         """ [26043,26496]
===
match
---
operator: , [1887,1888]
operator: , [1887,1888]
===
match
---
operator: , [67087,67088]
operator: , [67099,67100]
===
match
---
name: pool_override [23876,23889]
name: pool_override [23876,23889]
===
match
---
name: task [12741,12745]
name: task [12741,12745]
===
match
---
name: str [78823,78826]
name: str [78835,78838]
===
match
---
name: self [54377,54381]
name: self [54377,54381]
===
match
---
name: t [77242,77243]
name: t [77254,77255]
===
match
---
atom_expr [56168,56178]
atom_expr [56180,56190]
===
match
---
atom_expr [10490,10522]
atom_expr [10490,10522]
===
match
---
name: dag_id [75768,75774]
name: dag_id [75780,75786]
===
match
---
name: mark_success [41986,41998]
name: mark_success [41986,41998]
===
match
---
parameters [24221,24241]
parameters [24221,24241]
===
match
---
for_stmt [7560,7672]
for_stmt [7560,7672]
===
match
---
trailer [20944,20951]
trailer [20944,20951]
===
match
---
name: self [54775,54779]
name: self [54775,54779]
===
match
---
trailer [47122,47130]
trailer [47122,47130]
===
match
---
arglist [49143,49182]
arglist [49143,49182]
===
match
---
operator: = [79012,79013]
operator: = [79024,79025]
===
match
---
operator: , [33484,33485]
operator: , [33484,33485]
===
match
---
arglist [11576,11613]
arglist [11576,11613]
===
match
---
name: dag_id [20945,20951]
name: dag_id [20945,20951]
===
match
---
trailer [49940,49942]
trailer [49940,49942]
===
match
---
expr_stmt [12794,12846]
expr_stmt [12794,12846]
===
match
---
trailer [49142,49183]
trailer [49142,49183]
===
match
---
name: executor_config [11245,11260]
name: executor_config [11245,11260]
===
match
---
testlist_comp [19613,19634]
testlist_comp [19613,19634]
===
match
---
trailer [67329,67334]
trailer [67341,67346]
===
match
---
name: next_execution_date [59175,59194]
name: next_execution_date [59187,59206]
===
match
---
expr_stmt [10976,11031]
expr_stmt [10976,11031]
===
match
---
string: 'ds_nodash' [62793,62804]
string: 'ds_nodash' [62805,62816]
===
match
---
return_stmt [25893,25963]
return_stmt [25893,25963]
===
match
---
operator: , [26832,26833]
operator: , [26832,26833]
===
match
---
string: 'next_ds_nodash' [62996,63012]
string: 'next_ds_nodash' [63008,63024]
===
match
---
operator: , [66133,66134]
operator: , [66145,66146]
===
match
---
expr_stmt [8851,8862]
expr_stmt [8851,8862]
===
match
---
annassign [8874,8879]
annassign [8874,8879]
===
match
---
param [23520,23538]
param [23520,23538]
===
match
---
tfpdef [72710,72731]
tfpdef [72722,72743]
===
match
---
trailer [19555,19566]
trailer [19555,19566]
===
match
---
name: State [26870,26875]
name: State [26870,26875]
===
match
---
string: 'Exception:<br>Failed attempt to attach error logs<br>' [68438,68493]
string: 'Exception:<br>Failed attempt to attach error logs<br>' [68450,68505]
===
match
---
trailer [57924,57926]
trailer [57936,57938]
===
match
---
simple_stmt [34002,34180]
simple_stmt [34002,34180]
===
match
---
name: filter [26650,26656]
name: filter [26650,26656]
===
match
---
subscriptlist [78104,78124]
subscriptlist [78116,78136]
===
match
---
operator: = [44069,44070]
operator: = [44069,44070]
===
match
---
simple_stmt [40872,41155]
simple_stmt [40872,41155]
===
match
---
term [35046,35067]
term [35046,35067]
===
match
---
atom_expr [24564,24576]
atom_expr [24564,24576]
===
match
---
param [30057,30085]
param [30057,30085]
===
match
---
trailer [39047,39328]
trailer [39047,39328]
===
match
---
simple_stmt [49959,49965]
simple_stmt [49959,49965]
===
match
---
simple_stmt [937,978]
simple_stmt [937,978]
===
match
---
operator: -> [79808,79810]
operator: -> [79820,79822]
===
match
---
parameters [64326,64332]
parameters [64338,64344]
===
match
---
expr_stmt [11245,11295]
expr_stmt [11245,11295]
===
match
---
simple_stmt [23069,23093]
simple_stmt [23069,23093]
===
match
---
name: context [46478,46485]
name: context [46478,46485]
===
match
---
name: self [25584,25588]
name: self [25584,25588]
===
match
---
name: ti [77740,77742]
name: ti [77752,77754]
===
match
---
not_test [46302,46315]
not_test [46302,46315]
===
match
---
name: self [63536,63540]
name: self [63548,63552]
===
match
---
decorated [13587,14167]
decorated [13587,14167]
===
match
---
operator: = [3206,3207]
operator: = [3206,3207]
===
match
---
atom_expr [21587,21603]
atom_expr [21587,21603]
===
match
---
operator: = [52296,52297]
operator: = [52296,52297]
===
match
---
trailer [72290,72297]
trailer [72302,72309]
===
match
---
if_stmt [4117,4150]
if_stmt [4117,4150]
===
match
---
operator: , [10770,10771]
operator: , [10770,10771]
===
match
---
argument [52280,52313]
argument [52280,52313]
===
match
---
operator: = [30111,30112]
operator: = [30111,30112]
===
match
---
name: task [51173,51177]
name: task [51173,51177]
===
match
---
operator: = [15056,15057]
operator: = [15056,15057]
===
match
---
name: cmd [19132,19135]
name: cmd [19132,19135]
===
match
---
simple_stmt [5571,5600]
simple_stmt [5571,5600]
===
match
---
subscriptlist [56821,56835]
subscriptlist [56833,56847]
===
match
---
name: tis [77803,77806]
name: tis [77815,77818]
===
match
---
operator: , [77631,77632]
operator: , [77643,77644]
===
match
---
name: context [50281,50288]
name: context [50281,50288]
===
match
---
string: "Setting task state for %s to %s" [25287,25320]
string: "Setting task state for %s to %s" [25287,25320]
===
match
---
funcdef [3945,4262]
funcdef [3945,4262]
===
match
---
name: include_prior_dates [74733,74752]
name: include_prior_dates [74745,74764]
===
match
---
name: job_ids [7616,7623]
name: job_ids [7616,7623]
===
match
---
trailer [47043,47059]
trailer [47043,47059]
===
match
---
operator: = [47270,47271]
operator: = [47270,47271]
===
match
---
name: ignore_depends_on_past [16569,16591]
name: ignore_depends_on_past [16569,16591]
===
match
---
simple_stmt [79175,79196]
simple_stmt [79187,79208]
===
match
---
arglist [10425,10449]
arglist [10425,10449]
===
match
---
import_from [65414,65484]
import_from [65426,65496]
===
match
---
name: state [11752,11757]
name: state [11752,11757]
===
match
---
name: current_time [25407,25419]
name: current_time [25407,25419]
===
match
---
trailer [47760,47782]
trailer [47760,47782]
===
match
---
string: """Render k8s pod yaml""" [66515,66540]
string: """Render k8s pod yaml""" [66527,66552]
===
match
---
name: dag [28593,28596]
name: dag [28593,28596]
===
match
---
trailer [65540,65557]
trailer [65552,65569]
===
match
---
suite [79646,79673]
suite [79658,79685]
===
match
---
trailer [51611,51620]
trailer [51611,51620]
===
match
---
atom_expr [22902,22917]
atom_expr [22902,22917]
===
match
---
string: "--force" [19393,19402]
string: "--force" [19393,19402]
===
match
---
simple_stmt [10546,10601]
simple_stmt [10546,10601]
===
match
---
simple_stmt [49923,49943]
simple_stmt [49923,49943]
===
match
---
name: mark_success [16494,16506]
name: mark_success [16494,16506]
===
match
---
arith_expr [41491,41509]
arith_expr [41491,41509]
===
match
---
name: first [80779,80784]
name: first [80791,80796]
===
match
---
dotted_name [8062,8083]
dotted_name [8062,8083]
===
match
---
name: self [50860,50864]
name: self [50860,50864]
===
match
---
operator: , [46728,46729]
operator: , [46728,46729]
===
match
---
name: content [70201,70208]
name: content [70213,70220]
===
match
---
arglist [48807,48825]
arglist [48807,48825]
===
match
---
name: handle_failure [45989,46003]
name: handle_failure [45989,46003]
===
match
---
name: self [25343,25347]
name: self [25343,25347]
===
match
---
trailer [72366,72584]
trailer [72378,72596]
===
match
---
name: dep_status [33777,33787]
name: dep_status [33777,33787]
===
match
---
trailer [68914,69159]
trailer [68926,69171]
===
match
---
operator: , [63780,63781]
operator: , [63792,63793]
===
match
---
name: last_dagrun [28835,28846]
name: last_dagrun [28835,28846]
===
match
---
name: bool [36576,36580]
name: bool [36576,36580]
===
match
---
if_stmt [38579,38712]
if_stmt [38579,38712]
===
match
---
operator: , [52885,52886]
operator: , [52885,52886]
===
match
---
operator: = [8756,8757]
operator: = [8756,8757]
===
match
---
arglist [45861,45896]
arglist [45861,45896]
===
match
---
operator: , [11719,11720]
operator: , [11719,11720]
===
match
---
suite [59894,59934]
suite [59906,59946]
===
match
---
atom_expr [23069,23080]
atom_expr [23069,23080]
===
match
---
operator: , [70023,70024]
operator: , [70035,70036]
===
match
---
simple_stmt [6143,6165]
simple_stmt [6143,6165]
===
match
---
name: Session [27090,27097]
name: Session [27090,27097]
===
match
---
simple_stmt [43923,43972]
simple_stmt [43923,43972]
===
match
---
param [65949,65956]
param [65961,65968]
===
match
---
name: pool [52476,52480]
name: pool [52476,52480]
===
match
---
name: SUCCESS [38650,38657]
name: SUCCESS [38650,38657]
===
match
---
name: construct_pod [66704,66717]
name: construct_pod [66716,66729]
===
match
---
operator: = [44103,44104]
operator: = [44103,44104]
===
match
---
atom_expr [58761,58780]
atom_expr [58773,58792]
===
match
---
name: self [56272,56276]
name: self [56284,56288]
===
match
---
simple_stmt [80126,80486]
simple_stmt [80138,80498]
===
match
---
argument [16236,16250]
argument [16236,16250]
===
match
---
name: field_name [64619,64629]
name: field_name [64631,64641]
===
match
---
fstring_expr [47664,47667]
fstring_expr [47664,47667]
===
match
---
expr_stmt [39879,39914]
expr_stmt [39879,39914]
===
match
---
arglist [34700,34932]
arglist [34700,34932]
===
match
---
name: verbose [32683,32690]
name: verbose [32683,32690]
===
match
---
tfpdef [54471,54487]
tfpdef [54471,54487]
===
match
---
string: "&state=success" [20436,20452]
string: "&state=success" [20436,20452]
===
match
---
operator: = [23197,23198]
operator: = [23197,23198]
===
match
---
string: '%Y-%m-%d' [58104,58114]
string: '%Y-%m-%d' [58116,58126]
===
match
---
trailer [8394,8401]
trailer [8394,8401]
===
match
---
operator: = [22648,22649]
operator: = [22648,22649]
===
match
---
name: execution_date [77354,77368]
name: execution_date [77366,77380]
===
match
---
string: """             Wrapper around Variable. This way you can get variables in             templates by using ``{{ var.json.variable_name }}`` or             ``{{ var.json.get('variable_name', {'fall': 'back'}) }}``.             """ [60996,61224]
string: """             Wrapper around Variable. This way you can get variables in             templates by using ``{{ var.json.variable_name }}`` or             ``{{ var.json.get('variable_name', {'fall': 'back'}) }}``.             """ [61008,61236]
===
match
---
name: task [62909,62913]
name: task [62921,62925]
===
match
---
arglist [30481,30509]
arglist [30481,30509]
===
match
---
string: 'tomorrow_ds' [63818,63831]
string: 'tomorrow_ds' [63830,63843]
===
match
---
atom_expr [3278,3291]
atom_expr [3278,3291]
===
match
---
atom_expr [77653,77673]
atom_expr [77665,77685]
===
match
---
except_clause [50488,50504]
except_clause [50488,50504]
===
match
---
name: ti [22608,22610]
name: ti [22608,22610]
===
match
---
operator: @ [8938,8939]
operator: @ [8938,8939]
===
match
---
name: dag [27911,27914]
name: dag [27911,27914]
===
match
---
name: api_client [3023,3033]
name: api_client [3023,3033]
===
match
---
atom_expr [10418,10450]
atom_expr [10418,10450]
===
match
---
name: self [42440,42444]
name: self [42440,42444]
===
match
---
name: self [55473,55477]
name: self [55485,55489]
===
match
---
name: models [36225,36231]
name: models [36225,36231]
===
match
---
name: warn [7728,7732]
name: warn [7728,7732]
===
match
---
atom_expr [6220,6237]
atom_expr [6220,6237]
===
match
---
arglist [64712,64749]
arglist [64724,64761]
===
match
---
operator: = [51730,51731]
operator: = [51730,51731]
===
match
---
trailer [46764,46811]
trailer [46764,46811]
===
match
---
name: ti_deps [2370,2377]
name: ti_deps [2370,2377]
===
match
---
tfpdef [60491,60500]
tfpdef [60503,60512]
===
match
---
import_name [820,834]
import_name [820,834]
===
match
---
trailer [61278,61282]
trailer [61290,61294]
===
match
---
atom_expr [47208,47301]
atom_expr [47208,47301]
===
match
---
name: pool_override [23520,23533]
name: pool_override [23520,23533]
===
match
---
operator: = [39296,39297]
operator: = [39296,39297]
===
match
---
trailer [77624,77631]
trailer [77636,77643]
===
match
---
operator: -> [50664,50666]
operator: -> [50664,50666]
===
match
---
trailer [34899,34909]
trailer [34899,34909]
===
match
---
funcdef [29456,29976]
funcdef [29456,29976]
===
match
---
tfpdef [16832,16853]
tfpdef [16832,16853]
===
match
---
name: dep_context [33338,33349]
name: dep_context [33338,33349]
===
match
---
name: refresh_from_task [23490,23507]
name: refresh_from_task [23490,23507]
===
match
---
name: ConnectionAccessor [61900,61918]
name: ConnectionAccessor [61912,61930]
===
match
---
name: session [21559,21566]
name: session [21559,21566]
===
match
---
operator: = [20104,20105]
operator: = [20104,20105]
===
match
---
name: execution_timeout [49768,49785]
name: execution_timeout [49768,49785]
===
match
---
fstring_end: " [33956,33957]
fstring_end: " [33956,33957]
===
match
---
simple_stmt [49991,50035]
simple_stmt [49991,50035]
===
match
---
name: ignore_depends_on_past [52221,52243]
name: ignore_depends_on_past [52221,52243]
===
match
---
atom_expr [69714,69927]
atom_expr [69726,69939]
===
match
---
name: next_retry_datetime [33967,33986]
name: next_retry_datetime [33967,33986]
===
match
---
simple_stmt [29671,29919]
simple_stmt [29671,29919]
===
match
---
atom_expr [6886,7304]
atom_expr [6886,7304]
===
match
---
return_stmt [31759,31815]
return_stmt [31759,31815]
===
match
---
name: session [44125,44132]
name: session [44125,44132]
===
match
---
operator: = [53477,53478]
operator: = [53477,53478]
===
match
---
name: lock_for_update [44487,44502]
name: lock_for_update [44487,44502]
===
match
---
atom_expr [26846,26900]
atom_expr [26846,26900]
===
match
---
atom [62670,64288]
atom [62682,64300]
===
match
---
name: next_ds [58969,58976]
name: next_ds [58981,58988]
===
match
---
name: AirflowTaskTimeout [49887,49905]
name: AirflowTaskTimeout [49887,49905]
===
match
---
trailer [76134,76174]
trailer [76146,76186]
===
match
---
name: end_date [46208,46216]
name: end_date [46208,46216]
===
match
---
operator: , [1688,1689]
operator: , [1688,1689]
===
match
---
param [78277,78293]
param [78289,78305]
===
match
---
trailer [57661,57665]
trailer [57673,57677]
===
match
---
name: str [54526,54529]
name: str [54526,54529]
===
match
---
trailer [21035,21050]
trailer [21035,21050]
===
match
---
simple_stmt [22634,22662]
simple_stmt [22634,22662]
===
match
---
trailer [23245,23261]
trailer [23245,23261]
===
match
---
name: Optional [66491,66499]
name: Optional [66503,66511]
===
match
---
name: Variable [60903,60911]
name: Variable [60915,60923]
===
match
---
name: self [27391,27395]
name: self [27391,27395]
===
match
---
argument [52444,52457]
argument [52444,52457]
===
match
---
suite [19119,19174]
suite [19119,19174]
===
match
---
name: String [11124,11130]
name: String [11124,11130]
===
match
---
atom_expr [26693,26704]
atom_expr [26693,26704]
===
match
---
atom_expr [79662,79672]
atom_expr [79674,79684]
===
match
---
param [51793,51824]
param [51793,51824]
===
match
---
simple_stmt [30389,30442]
simple_stmt [30389,30442]
===
match
---
param [3965,3978]
param [3965,3978]
===
match
---
simple_stmt [48284,48502]
simple_stmt [48284,48502]
===
match
---
trailer [42340,42349]
trailer [42340,42349]
===
match
---
operator: = [57043,57044]
operator: = [57055,57056]
===
match
---
trailer [42690,42698]
trailer [42690,42698]
===
match
---
simple_stmt [19917,20008]
simple_stmt [19917,20008]
===
match
---
name: downstream_task_ids [26748,26767]
name: downstream_task_ids [26748,26767]
===
match
---
name: self [56580,56584]
name: self [56592,56596]
===
match
---
trailer [75730,75737]
trailer [75742,75749]
===
match
---
operator: = [59007,59008]
operator: = [59019,59020]
===
match
---
name: state [26859,26864]
name: state [26859,26864]
===
match
---
simple_stmt [10642,10673]
simple_stmt [10642,10673]
===
match
---
suite [65352,65899]
suite [65364,65911]
===
match
---
name: Log [1974,1977]
name: Log [1974,1977]
===
match
---
simple_stmt [23220,23262]
simple_stmt [23220,23262]
===
match
---
expr_stmt [80752,80786]
expr_stmt [80764,80798]
===
match
---
parameters [4282,4329]
parameters [4282,4329]
===
match
---
name: self [23029,23033]
name: self [23029,23033]
===
match
---
string: """Overwrite Task Params with DagRun.conf""" [65975,66019]
string: """Overwrite Task Params with DagRun.conf""" [65987,66031]
===
match
---
trailer [10845,10859]
trailer [10845,10859]
===
match
---
name: _dag_id [80576,80583]
name: _dag_id [80588,80595]
===
match
---
simple_stmt [76055,76079]
simple_stmt [76067,76091]
===
match
---
simple_stmt [70201,70220]
simple_stmt [70213,70232]
===
match
---
trailer [49133,49137]
trailer [49133,49137]
===
match
---
name: Column [10751,10757]
name: Column [10751,10757]
===
match
---
suite [54713,55116]
suite [54713,55128]
===
match
---
name: State [38644,38649]
name: State [38644,38649]
===
match
---
trailer [7593,7600]
trailer [7593,7600]
===
match
---
name: SUCCESS [31807,31814]
name: SUCCESS [31807,31814]
===
match
---
simple_stmt [19864,19909]
simple_stmt [19864,19909]
===
match
---
operator: = [35469,35470]
operator: = [35469,35470]
===
match
---
operator: , [65737,65738]
operator: , [65749,65750]
===
match
---
name: exception [69750,69759]
name: exception [69762,69771]
===
match
---
param [31891,31904]
param [31891,31904]
===
match
---
operator: = [31076,31077]
operator: = [31076,31077]
===
match
---
name: session [41617,41624]
name: session [41617,41624]
===
match
---
trailer [52561,52566]
trailer [52561,52566]
===
match
---
dotted_name [2816,2837]
dotted_name [2816,2837]
===
match
---
funcdef [70009,70298]
funcdef [70021,70310]
===
match
---
name: self [24222,24226]
name: self [24222,24226]
===
match
---
operator: , [42972,42973]
operator: , [42972,42973]
===
match
---
operator: = [78648,78649]
operator: = [78660,78661]
===
match
---
suite [12455,12917]
suite [12455,12917]
===
match
---
argument [40753,40765]
argument [40753,40765]
===
match
---
name: timedelta [58287,58296]
name: timedelta [58299,58308]
===
match
---
dictorsetmaker [62684,64278]
dictorsetmaker [62696,64290]
===
match
---
trailer [38634,38640]
trailer [38634,38640]
===
match
---
trailer [38514,38521]
trailer [38514,38521]
===
match
---
trailer [45043,45045]
trailer [45043,45045]
===
match
---
param [36868,36895]
param [36868,36895]
===
match
---
simple_stmt [80960,81001]
simple_stmt [80972,81013]
===
match
---
name: Any [3254,3257]
name: Any [3254,3257]
===
match
---
argument [77373,77402]
argument [77385,77414]
===
match
---
simple_stmt [45800,45807]
simple_stmt [45800,45807]
===
match
---
expr_stmt [80494,80710]
expr_stmt [80506,80722]
===
match
---
argument [74674,74688]
argument [74686,74700]
===
match
---
name: ignore_depends_on_past [39217,39239]
name: ignore_depends_on_past [39217,39239]
===
match
---
atom_expr [53590,53603]
atom_expr [53590,53603]
===
match
---
name: State [31801,31806]
name: State [31801,31806]
===
match
---
trailer [56978,57052]
trailer [56990,57064]
===
match
---
suite [64333,65280]
suite [64345,65292]
===
match
---
name: max [6088,6091]
name: max [6088,6091]
===
match
---
trailer [27400,27404]
trailer [27400,27404]
===
match
---
number: 1 [11013,11014]
number: 1 [11013,11014]
===
match
---
name: self [48788,48792]
name: self [48788,48792]
===
match
---
trailer [56131,56152]
trailer [56143,56164]
===
match
---
trailer [28700,28717]
trailer [28700,28717]
===
match
---
trailer [72170,72348]
trailer [72182,72360]
===
match
---
trailer [45774,45781]
trailer [45774,45781]
===
match
---
trailer [78445,78457]
trailer [78457,78469]
===
match
---
name: self [35602,35606]
name: self [35602,35606]
===
match
---
trailer [50017,50034]
trailer [50017,50034]
===
match
---
operator: == [21051,21053]
operator: == [21051,21053]
===
match
---
trailer [48681,48683]
trailer [48681,48683]
===
match
---
name: data [4124,4128]
name: data [4124,4128]
===
match
---
name: self [25900,25904]
name: self [25900,25904]
===
match
---
operator: , [21265,21266]
operator: , [21265,21266]
===
match
---
operator: , [34826,34827]
operator: , [34826,34827]
===
match
---
name: dag_id [8395,8401]
name: dag_id [8395,8401]
===
match
---
string: 'ti_state' [11630,11640]
string: 'ti_state' [11630,11640]
===
match
---
name: value [14251,14256]
name: value [14251,14256]
===
match
---
simple_stmt [52687,52934]
simple_stmt [52687,52934]
===
match
---
except_clause [45161,45217]
except_clause [45161,45217]
===
match
---
operator: , [56836,56837]
operator: , [56848,56849]
===
match
---
name: Union [76135,76140]
name: Union [76147,76152]
===
match
---
name: plugins_manager [2192,2207]
name: plugins_manager [2192,2207]
===
match
---
name: task [63109,63113]
name: task [63121,63125]
===
match
---
operator: , [53951,53952]
operator: , [53951,53952]
===
match
---
trailer [41121,41131]
trailer [41121,41131]
===
match
---
name: _execute_task [49460,49473]
name: _execute_task [49460,49473]
===
match
---
simple_stmt [70995,71017]
simple_stmt [71007,71029]
===
match
---
name: end_date [41703,41711]
name: end_date [41703,41711]
===
match
---
trailer [23915,23926]
trailer [23915,23926]
===
match
---
trailer [45392,45408]
trailer [45392,45408]
===
match
---
name: strftime [58301,58309]
name: strftime [58313,58321]
===
match
---
name: Optional [43059,43067]
name: Optional [43059,43067]
===
match
---
expr_stmt [10605,10637]
expr_stmt [10605,10637]
===
match
---
trailer [57618,57625]
trailer [57630,57637]
===
match
---
atom_expr [80870,80909]
atom_expr [80882,80921]
===
match
---
atom_expr [78768,78785]
atom_expr [78780,78797]
===
match
---
not_test [56123,56154]
not_test [56135,56166]
===
match
---
return_stmt [31162,31241]
return_stmt [31162,31241]
===
match
---
simple_stmt [19300,19341]
simple_stmt [19300,19341]
===
match
---
trailer [47844,47856]
trailer [47844,47856]
===
match
---
suite [8048,8763]
suite [8048,8763]
===
match
---
operator: , [33588,33589]
operator: , [33588,33589]
===
match
---
argument [74786,74801]
argument [74798,74813]
===
match
---
simple_stmt [65648,65695]
simple_stmt [65660,65707]
===
match
---
name: exception_html [69781,69795]
name: exception_html [69793,69807]
===
match
---
name: timedelta [58207,58216]
name: timedelta [58219,58228]
===
match
---
operator: + [35044,35045]
operator: + [35044,35045]
===
match
---
trailer [63770,63780]
trailer [63782,63792]
===
match
---
trailer [79035,79040]
trailer [79047,79052]
===
match
---
name: query [7579,7584]
name: query [7579,7584]
===
match
---
trailer [28788,28818]
trailer [28788,28818]
===
match
---
if_stmt [74509,74561]
if_stmt [74521,74573]
===
match
---
import_from [978,1017]
import_from [978,1017]
===
match
---
name: self [51413,51417]
name: self [51413,51417]
===
match
---
operator: <= [57245,57247]
operator: <= [57257,57259]
===
match
---
trailer [49313,49315]
trailer [49313,49315]
===
match
---
param [36722,36752]
param [36722,36752]
===
match
---
name: session [57320,57327]
name: session [57332,57339]
===
match
---
argument [52411,52430]
argument [52411,52430]
===
match
---
operator: , [35486,35487]
operator: , [35486,35487]
===
match
---
name: e [65864,65865]
name: e [65876,65877]
===
match
---
name: ti [23243,23245]
name: ti [23243,23245]
===
match
---
operator: @ [36479,36480]
operator: @ [36479,36480]
===
match
---
operator: = [43965,43966]
operator: = [43965,43966]
===
match
---
trailer [57656,57673]
trailer [57668,57685]
===
match
---
name: self [41394,41398]
name: self [41394,41398]
===
match
---
atom_expr [51146,51159]
atom_expr [51146,51159]
===
match
---
operator: , [11695,11696]
operator: , [11695,11696]
===
match
---
name: len [26961,26964]
name: len [26961,26964]
===
match
---
simple_stmt [29927,29976]
simple_stmt [29927,29976]
===
match
---
name: session [41785,41792]
name: session [41785,41792]
===
match
---
import_from [3114,3171]
import_from [3114,3171]
===
match
---
operator: = [49113,49114]
operator: = [49113,49114]
===
match
---
except_clause [27951,27972]
except_clause [27951,27972]
===
match
---
suite [14858,14933]
suite [14858,14933]
===
match
---
name: task [23893,23897]
name: task [23893,23897]
===
match
---
name: read [4106,4110]
name: read [4106,4110]
===
match
---
atom_expr [5367,5376]
atom_expr [5367,5376]
===
match
---
name: SUCCESS [29967,29974]
name: SUCCESS [29967,29974]
===
match
---
dotted_name [2773,2795]
dotted_name [2773,2795]
===
match
---
name: test_mode [53453,53462]
name: test_mode [53453,53462]
===
match
---
operator: , [36376,36377]
operator: , [36376,36377]
===
match
---
trailer [77860,77932]
trailer [77872,77944]
===
match
---
operator: , [54381,54382]
operator: , [54381,54382]
===
match
---
expr_stmt [24145,24175]
expr_stmt [24145,24175]
===
match
---
operator: -> [79639,79641]
operator: -> [79651,79653]
===
match
---
name: t [77188,77189]
name: t [77200,77201]
===
match
---
atom_expr [9580,9599]
atom_expr [9580,9599]
===
match
---
name: task_id [12174,12181]
name: task_id [12174,12181]
===
match
---
trailer [22610,22621]
trailer [22610,22621]
===
match
---
name: task [44261,44265]
name: task [44261,44265]
===
match
---
expr_stmt [57386,57402]
expr_stmt [57398,57414]
===
match
---
name: conf [19875,19879]
name: conf [19875,19879]
===
match
---
trailer [34754,34865]
trailer [34754,34865]
===
match
---
name: task [46487,46491]
name: task [46487,46491]
===
match
---
param [30678,30701]
param [30678,30701]
===
match
---
name: state [25348,25353]
name: state [25348,25353]
===
match
---
name: self [25509,25513]
name: self [25509,25513]
===
match
---
expr_stmt [49824,49867]
expr_stmt [49824,49867]
===
match
---
trailer [8419,8434]
trailer [8419,8434]
===
match
---
name: State [8698,8703]
name: State [8698,8703]
===
match
---
trailer [34707,34712]
trailer [34707,34712]
===
match
---
atom_expr [53337,53356]
atom_expr [53337,53356]
===
match
---
simple_stmt [32643,32711]
simple_stmt [32643,32711]
===
match
---
name: ti [78736,78738]
name: ti [78748,78750]
===
match
---
name: _execution_date [79273,79288]
name: _execution_date [79285,79300]
===
match
---
name: DagRun [8091,8097]
name: DagRun [8091,8097]
===
match
---
return_stmt [9530,9612]
return_stmt [9530,9612]
===
match
---
parameters [66481,66487]
parameters [66493,66499]
===
match
---
operator: = [74710,74711]
operator: = [74722,74723]
===
match
---
arith_expr [9363,9382]
arith_expr [9363,9382]
===
match
---
funcdef [12019,13397]
funcdef [12019,13397]
===
match
---
expr_stmt [15788,15799]
expr_stmt [15788,15799]
===
match
---
operator: = [71089,71090]
operator: = [71101,71102]
===
match
---
trailer [78681,78694]
trailer [78693,78706]
===
match
---
atom_expr [4103,4112]
atom_expr [4103,4112]
===
match
---
operator: = [69226,69227]
operator: = [69238,69239]
===
match
---
tfpdef [61646,61662]
tfpdef [61658,61674]
===
match
---
atom_expr [9105,9124]
atom_expr [9105,9124]
===
match
---
trailer [33525,33531]
trailer [33525,33531]
===
match
---
simple_stmt [28654,28718]
simple_stmt [28654,28718]
===
match
---
trailer [7083,7093]
trailer [7083,7093]
===
match
---
name: execution_date [12601,12615]
name: execution_date [12601,12615]
===
match
---
atom_expr [56857,56871]
atom_expr [56869,56883]
===
match
---
param [51941,51970]
param [51941,51970]
===
match
---
expr_stmt [58685,58726]
expr_stmt [58697,58738]
===
match
---
suite [79252,79289]
suite [79264,79301]
===
match
---
trailer [78849,78866]
trailer [78861,78878]
===
match
---
trailer [40154,40165]
trailer [40154,40165]
===
match
---
trailer [23073,23080]
trailer [23073,23080]
===
match
---
name: from_string [69530,69541]
name: from_string [69542,69553]
===
match
---
trailer [46098,46154]
trailer [46098,46154]
===
match
---
name: TaskInstance [77882,77894]
name: TaskInstance [77894,77906]
===
match
---
name: file_path [16236,16245]
name: file_path [16236,16245]
===
match
---
name: try_number [14173,14183]
name: try_number [14173,14183]
===
match
---
name: state [35907,35912]
name: state [35907,35912]
===
match
---
simple_stmt [25343,25362]
simple_stmt [25343,25362]
===
match
---
trailer [38462,38501]
trailer [38462,38501]
===
match
---
trailer [28596,28604]
trailer [28596,28604]
===
match
---
name: dag [28237,28240]
name: dag [28237,28240]
===
match
---
name: self [46245,46249]
name: self [46245,46249]
===
match
---
name: Session [71414,71421]
name: Session [71426,71433]
===
match
---
name: execution_date [53783,53797]
name: execution_date [53783,53797]
===
match
---
name: dag_id [76592,76598]
name: dag_id [76604,76610]
===
match
---
name: try_number [7043,7053]
name: try_number [7043,7053]
===
match
---
if_stmt [51435,51621]
if_stmt [51435,51621]
===
match
---
name: macros [62944,62950]
name: macros [62956,62962]
===
match
---
name: prev_ds_nodash [59397,59411]
name: prev_ds_nodash [59409,59423]
===
match
---
atom_expr [51313,51346]
atom_expr [51313,51346]
===
match
---
operator: @ [56731,56732]
operator: @ [56743,56744]
===
match
---
name: dag_id [78327,78333]
name: dag_id [78339,78345]
===
match
---
arglist [46934,46964]
arglist [46934,46964]
===
match
---
operator: , [62177,62178]
operator: , [62189,62190]
===
match
---
testlist [9078,9124]
testlist [9078,9124]
===
match
---
simple_stmt [66069,66157]
simple_stmt [66081,66169]
===
match
---
name: TaskInstance [26846,26858]
name: TaskInstance [26846,26858]
===
match
---
trailer [25588,25597]
trailer [25588,25597]
===
match
---
atom_expr [32737,32807]
atom_expr [32737,32807]
===
match
---
operator: = [47545,47546]
operator: = [47545,47546]
===
match
---
atom_expr [60651,60664]
atom_expr [60663,60676]
===
match
---
suite [13444,13582]
suite [13444,13582]
===
match
---
name: execution_date [10546,10560]
name: execution_date [10546,10560]
===
match
---
funcdef [49456,50244]
funcdef [49456,50244]
===
match
---
simple_stmt [20153,20198]
simple_stmt [20153,20198]
===
match
---
name: get_hostname [38555,38567]
name: get_hostname [38555,38567]
===
match
---
name: airflow [2559,2566]
name: airflow [2559,2566]
===
match
---
operator: == [8695,8697]
operator: == [8695,8697]
===
match
---
name: retry_delay [34206,34217]
name: retry_delay [34206,34217]
===
match
---
string: """         Returns a command that can be executed anywhere where airflow is         installed. This command is part of the message sent to executors by         the orchestrator.         """ [15275,15465]
string: """         Returns a command that can be executed anywhere where airflow is         installed. This command is part of the message sent to executors by         the orchestrator.         """ [15275,15465]
===
match
---
fstring_expr [47112,47131]
fstring_expr [47112,47131]
===
match
---
fstring [44235,44275]
fstring [44235,44275]
===
match
---
name: render_templates [47277,47293]
name: render_templates [47277,47293]
===
match
---
atom_expr [19435,19458]
atom_expr [19435,19458]
===
match
---
strings [64948,65254]
strings [64960,65266]
===
match
---
operator: , [24632,24633]
operator: , [24632,24633]
===
match
---
name: session [41272,41279]
name: session [41272,41279]
===
match
---
arglist [59675,59682]
arglist [59687,59694]
===
match
---
arglist [11338,11362]
arglist [11338,11362]
===
match
---
operator: , [11597,11598]
operator: , [11597,11598]
===
match
---
atom_expr [78585,78596]
atom_expr [78597,78608]
===
match
---
operator: , [39313,39314]
operator: , [39313,39314]
===
match
---
name: loader [69220,69226]
name: loader [69232,69238]
===
match
---
simple_stmt [56709,56726]
simple_stmt [56721,56738]
===
match
---
simple_stmt [38539,38570]
simple_stmt [38539,38570]
===
match
---
trailer [22213,22220]
trailer [22213,22220]
===
match
---
name: task_id [7072,7079]
name: task_id [7072,7079]
===
match
---
name: __repr__ [33842,33850]
name: __repr__ [33842,33850]
===
match
---
name: hr_line_break [40841,40854]
name: hr_line_break [40841,40854]
===
match
---
name: Iterable [76126,76134]
name: Iterable [76138,76146]
===
match
---
expr_stmt [12169,12196]
expr_stmt [12169,12196]
===
match
---
sliceop [80896,80899]
sliceop [80908,80911]
===
match
---
name: self [24093,24097]
name: self [24093,24097]
===
match
---
simple_stmt [32821,32835]
simple_stmt [32821,32835]
===
match
---
atom_expr [47925,47966]
atom_expr [47925,47966]
===
match
---
decorated [42858,46422]
decorated [42858,46422]
===
match
---
operator: } [68740,68741]
operator: } [68752,68753]
===
match
---
operator: = [5234,5235]
operator: = [5234,5235]
===
match
---
simple_stmt [24856,24944]
simple_stmt [24856,24944]
===
match
---
simple_stmt [65494,65581]
simple_stmt [65506,65593]
===
match
---
operator: = [24028,24029]
operator: = [24028,24029]
===
match
---
parameters [79488,79494]
parameters [79500,79506]
===
match
---
string: "--local" [19447,19456]
string: "--local" [19447,19456]
===
match
---
name: task_ids [72648,72656]
name: task_ids [72660,72668]
===
match
---
trailer [63576,63584]
trailer [63588,63596]
===
match
---
name: List [16947,16951]
name: List [16947,16951]
===
match
---
name: job_ids [5202,5209]
name: job_ids [5202,5209]
===
match
---
operator: , [11686,11687]
operator: , [11686,11687]
===
match
---
operator: @ [51626,51627]
operator: @ [51626,51627]
===
match
---
argument [52766,52785]
argument [52766,52785]
===
match
---
trailer [24668,24675]
trailer [24668,24675]
===
match
---
simple_stmt [2434,2476]
simple_stmt [2434,2476]
===
match
---
expr_stmt [28022,28065]
expr_stmt [28022,28065]
===
match
---
simple_stmt [19381,19405]
simple_stmt [19381,19405]
===
match
---
operator: = [40722,40723]
operator: = [40722,40723]
===
match
---
name: or_ [6886,6889]
name: or_ [6886,6889]
===
match
---
name: ignore_all_deps [52176,52191]
name: ignore_all_deps [52176,52191]
===
match
---
trailer [35983,35985]
trailer [35983,35985]
===
match
---
atom_expr [77599,77618]
atom_expr [77611,77630]
===
match
---
trailer [26933,26936]
trailer [26933,26936]
===
match
---
trailer [72666,72693]
trailer [72678,72705]
===
match
---
atom_expr [31181,31199]
atom_expr [31181,31199]
===
match
---
comparison [77188,77206]
comparison [77200,77218]
===
match
---
import_from [36212,36252]
import_from [36212,36252]
===
match
---
name: Union [4307,4312]
name: Union [4307,4312]
===
match
---
name: state [21145,21150]
name: state [21145,21150]
===
match
---
operator: = [61409,61410]
operator: = [61421,61422]
===
match
---
name: Session [30103,30110]
name: Session [30103,30110]
===
match
---
parameters [31866,31919]
parameters [31866,31919]
===
match
---
operator: @ [76084,76085]
operator: @ [76096,76097]
===
match
---
trailer [20172,20197]
trailer [20172,20197]
===
match
---
name: self [47374,47378]
name: self [47374,47378]
===
match
---
trailer [50009,50017]
trailer [50009,50017]
===
match
---
decorated [24949,25661]
decorated [24949,25661]
===
match
---
atom_expr [35657,35682]
atom_expr [35657,35682]
===
match
---
operator: , [11589,11590]
operator: , [11589,11590]
===
match
---
name: items [8504,8509]
name: items [8504,8509]
===
match
---
trailer [47518,47551]
trailer [47518,47551]
===
match
---
simple_stmt [49192,49219]
simple_stmt [49192,49219]
===
match
---
atom_expr [28871,28931]
atom_expr [28871,28931]
===
match
---
operator: } [47666,47667]
operator: } [47666,47667]
===
match
---
atom_expr [42164,42173]
atom_expr [42164,42173]
===
match
---
operator: = [52450,52451]
operator: = [52450,52451]
===
match
---
trailer [41322,41324]
trailer [41322,41324]
===
match
---
name: TaskInstance [22282,22294]
name: TaskInstance [22282,22294]
===
match
---
simple_stmt [72874,74501]
simple_stmt [72886,74513]
===
match
---
comparison [24548,24576]
comparison [24548,24576]
===
match
---
operator: = [50656,50657]
operator: = [50656,50657]
===
match
---
trailer [66703,66717]
trailer [66715,66729]
===
match
---
expr_stmt [81099,81149]
expr_stmt [81111,81161]
===
match
---
trailer [71204,71210]
trailer [71216,71222]
===
match
---
simple_stmt [44153,44170]
simple_stmt [44153,44170]
===
match
---
operator: = [28764,28765]
operator: = [28764,28765]
===
match
---
name: warnings [29151,29159]
name: warnings [29151,29159]
===
match
---
operator: , [69759,69760]
operator: , [69771,69772]
===
match
---
trailer [43874,43879]
trailer [43874,43879]
===
match
---
name: base_url [19924,19932]
name: base_url [19924,19932]
===
match
---
trailer [4081,4090]
trailer [4081,4090]
===
match
---
name: session [20852,20859]
name: session [20852,20859]
===
match
---
comparison [21023,21073]
comparison [21023,21073]
===
match
---
import_name [835,846]
import_name [835,846]
===
match
---
operator: = [78882,78883]
operator: = [78894,78895]
===
match
---
dotted_name [64400,64431]
dotted_name [64412,64443]
===
match
---
name: pendulum [30538,30546]
name: pendulum [30538,30546]
===
match
---
trailer [5500,5508]
trailer [5500,5508]
===
match
---
name: state [5328,5333]
name: state [5328,5333]
===
match
---
name: ti [22690,22692]
name: ti [22690,22692]
===
match
---
name: self [38510,38514]
name: self [38510,38514]
===
match
---
atom_expr [56959,57052]
atom_expr [56971,57064]
===
match
---
operator: = [33270,33271]
operator: = [33270,33271]
===
match
---
name: DeprecationWarning [29863,29881]
name: DeprecationWarning [29863,29881]
===
match
---
suite [27139,28953]
suite [27139,28953]
===
match
---
atom_expr [19488,19516]
atom_expr [19488,19516]
===
match
---
name: self [24523,24527]
name: self [24523,24527]
===
match
---
trailer [43067,43072]
trailer [43067,43072]
===
match
---
name: filter_by [57832,57841]
name: filter_by [57844,57853]
===
match
---
name: session [56681,56688]
name: session [56693,56700]
===
match
---
trailer [14150,14162]
trailer [14150,14162]
===
match
---
atom_expr [35543,35586]
atom_expr [35543,35586]
===
match
---
name: kube_config [66909,66920]
name: kube_config [66921,66932]
===
match
---
string: "tasks" [18842,18849]
string: "tasks" [18842,18849]
===
match
---
simple_stmt [24145,24176]
simple_stmt [24145,24176]
===
match
---
name: delay_backoff_in_seconds [35444,35468]
name: delay_backoff_in_seconds [35444,35468]
===
match
---
decorated [28958,29437]
decorated [28958,29437]
===
match
---
annassign [8898,8908]
annassign [8898,8908]
===
match
---
name: dates [8439,8444]
name: dates [8439,8444]
===
match
---
operator: = [48926,48927]
operator: = [48926,48927]
===
match
---
operator: , [20951,20952]
operator: , [20951,20952]
===
match
---
trailer [48288,48292]
trailer [48288,48292]
===
match
---
operator: = [66770,66771]
operator: = [66782,66783]
===
match
---
name: path [15737,15741]
name: path [15737,15741]
===
match
---
name: self [41648,41652]
name: self [41648,41652]
===
match
---
atom_expr [64507,64560]
atom_expr [64519,64572]
===
match
---
string: "Clearing XCom data" [24438,24458]
string: "Clearing XCom data" [24438,24458]
===
match
---
name: ti [22496,22498]
name: ti [22496,22498]
===
match
---
atom_expr [13083,13096]
atom_expr [13083,13096]
===
match
---
simple_stmt [47925,47967]
simple_stmt [47925,47967]
===
match
---
atom_expr [14066,14076]
atom_expr [14066,14076]
===
match
---
trailer [75171,75185]
trailer [75183,75197]
===
match
---
trailer [11734,11775]
trailer [11734,11775]
===
match
---
name: session [72566,72573]
name: session [72578,72585]
===
match
---
atom_expr [49750,49802]
atom_expr [49750,49802]
===
match
---
name: settings [77486,77494]
name: settings [77498,77506]
===
match
---
trailer [44525,44531]
trailer [44525,44531]
===
match
---
name: str [51958,51961]
name: str [51958,51961]
===
match
---
name: dates_by_dag_id [8208,8223]
name: dates_by_dag_id [8208,8223]
===
match
---
name: ignore_depends_on_past [19264,19286]
name: ignore_depends_on_past [19264,19286]
===
match
---
name: xcom_push [71283,71292]
name: xcom_push [71295,71304]
===
match
---
trailer [56228,56245]
trailer [56240,56257]
===
match
---
operator: = [13314,13315]
operator: = [13314,13315]
===
match
---
suite [24242,24722]
suite [24242,24722]
===
match
---
atom_expr [69967,69995]
atom_expr [69979,70007]
===
match
---
trailer [30563,30578]
trailer [30563,30578]
===
match
---
operator: = [23533,23534]
operator: = [23533,23534]
===
match
---
simple_stmt [51259,51297]
simple_stmt [51259,51297]
===
match
---
string: "exception" [51552,51563]
string: "exception" [51552,51563]
===
match
---
operator: , [64864,64865]
operator: , [64876,64877]
===
match
---
name: self [9640,9644]
name: self [9640,9644]
===
match
---
operator: -> [57334,57336]
operator: -> [57346,57348]
===
match
---
comparison [7040,7067]
comparison [7040,7067]
===
match
---
string: "%s. State set to NONE." [41034,41058]
string: "%s. State set to NONE." [41034,41058]
===
match
---
param [36033,36056]
param [36033,36056]
===
match
---
name: filter [24488,24494]
name: filter [24488,24494]
===
match
---
trailer [11269,11295]
trailer [11269,11295]
===
match
---
param [15162,15177]
param [15162,15177]
===
match
---
suite [79577,79605]
suite [79589,79617]
===
match
---
name: error [46759,46764]
name: error [46759,46764]
===
match
---
trailer [54448,54454]
trailer [54448,54454]
===
match
---
trailer [75204,75210]
trailer [75216,75222]
===
match
---
atom_expr [77882,77902]
atom_expr [77894,77914]
===
match
---
param [8964,8968]
param [8964,8968]
===
match
---
trailer [64120,64122]
trailer [64132,64134]
===
match
---
name: t [76908,76909]
name: t [76920,76921]
===
match
---
operator: , [59547,59548]
operator: , [59559,59560]
===
match
---
name: self [23475,23479]
name: self [23475,23479]
===
match
---
param [42982,43006]
param [42982,43006]
===
match
---
operator: = [16854,16855]
operator: = [16854,16855]
===
match
---
trailer [75109,75127]
trailer [75121,75139]
===
match
---
simple_stmt [40375,40666]
simple_stmt [40375,40666]
===
match
---
argument [29895,29907]
argument [29895,29907]
===
match
---
name: task_id [20278,20285]
name: task_id [20278,20285]
===
match
---
name: is_container [2588,2600]
name: is_container [2588,2600]
===
match
---
atom [19612,19635]
atom [19612,19635]
===
match
---
funcdef [79940,80004]
funcdef [79952,80016]
===
match
---
atom_expr [6911,7218]
atom_expr [6911,7218]
===
match
---
name: self [62173,62177]
name: self [62185,62189]
===
match
---
name: set [5288,5291]
name: set [5288,5291]
===
match
---
name: prev_execution_date [58807,58826]
name: prev_execution_date [58819,58838]
===
match
---
trailer [55369,55376]
trailer [55381,55388]
===
match
---
trailer [10727,10731]
trailer [10727,10731]
===
match
---
operator: @ [16369,16370]
operator: @ [16369,16370]
===
match
---
name: dagrun [81025,81031]
name: dagrun [81037,81043]
===
match
---
name: in_env_var_format [47528,47545]
name: in_env_var_format [47528,47545]
===
match
---
name: kube_image [66898,66908]
name: kube_image [66910,66920]
===
match
---
param [36761,36788]
param [36761,36788]
===
match
---
operator: = [78827,78828]
operator: = [78839,78840]
===
match
---
operator: , [70841,70842]
operator: , [70853,70854]
===
match
---
atom [68029,68325]
atom [68041,68337]
===
match
---
operator: , [34911,34912]
operator: , [34911,34912]
===
match
---
expr_stmt [13083,13101]
expr_stmt [13083,13101]
===
match
---
trailer [26682,26689]
trailer [26682,26689]
===
match
---
atom_expr [23155,23168]
atom_expr [23155,23168]
===
match
---
operator: , [11552,11553]
operator: , [11552,11553]
===
match
---
operator: , [41095,41096]
operator: , [41095,41096]
===
match
---
name: _end_date [78497,78506]
name: _end_date [78509,78518]
===
match
---
name: lazy_object_proxy [63330,63347]
name: lazy_object_proxy [63342,63359]
===
match
---
trailer [23439,23445]
trailer [23439,23445]
===
match
---
operator: = [5403,5404]
operator: = [5403,5404]
===
match
---
name: session [1433,1440]
name: session [1433,1440]
===
match
---
argument [47277,47299]
argument [47277,47299]
===
match
---
tfpdef [54429,54454]
tfpdef [54429,54454]
===
match
---
atom_expr [11785,11811]
atom_expr [11785,11811]
===
match
---
name: session [52911,52918]
name: session [52911,52918]
===
match
---
simple_stmt [60644,60665]
simple_stmt [60656,60677]
===
match
---
trailer [66920,66931]
trailer [66932,66943]
===
match
---
trailer [25467,25473]
trailer [25467,25473]
===
match
---
name: ti [5718,5720]
name: ti [5718,5720]
===
match
---
operator: = [48910,48911]
operator: = [48910,48911]
===
match
---
trailer [43031,43036]
trailer [43031,43036]
===
match
---
name: log [40829,40832]
name: log [40829,40832]
===
match
---
param [12070,12097]
param [12070,12097]
===
match
---
expr_stmt [58124,58160]
expr_stmt [58136,58172]
===
match
---
name: priority_weight [79696,79711]
name: priority_weight [79708,79723]
===
match
---
suite [58672,58781]
suite [58684,58793]
===
match
---
atom_expr [77622,77631]
atom_expr [77634,77643]
===
match
---
operator: , [30047,30048]
operator: , [30047,30048]
===
match
---
atom_expr [25246,25263]
atom_expr [25246,25263]
===
match
---
parameters [30033,30124]
parameters [30033,30124]
===
match
---
parameters [53136,53142]
parameters [53136,53142]
===
match
---
simple_stmt [44862,44905]
simple_stmt [44862,44905]
===
match
---
import_from [2357,2433]
import_from [2357,2433]
===
match
---
suite [21178,21204]
suite [21178,21204]
===
match
---
operator: -> [9433,9435]
operator: -> [9433,9435]
===
match
---
atom_expr [33353,33365]
atom_expr [33353,33365]
===
match
---
return_stmt [28941,28952]
return_stmt [28941,28952]
===
match
---
trailer [26615,26649]
trailer [26615,26649]
===
match
---
operator: = [67700,67701]
operator: = [67712,67713]
===
match
---
operator: = [63417,63418]
operator: = [63429,63430]
===
match
---
operator: , [4316,4317]
operator: , [4316,4317]
===
match
---
suite [50429,50480]
suite [50429,50480]
===
match
---
atom_expr [76908,76924]
atom_expr [76920,76936]
===
match
---
name: self [42016,42020]
name: self [42016,42020]
===
match
---
name: dt [28022,28024]
name: dt [28022,28024]
===
match
---
trailer [21543,21550]
trailer [21543,21550]
===
match
---
and_test [12394,12454]
and_test [12394,12454]
===
match
---
arglist [59154,59161]
arglist [59166,59173]
===
match
---
operator: , [63956,63957]
operator: , [63968,63969]
===
match
---
name: _try_number [14237,14248]
name: _try_number [14237,14248]
===
match
---
atom_expr [45565,45587]
atom_expr [45565,45587]
===
match
---
name: Context [57337,57344]
name: Context [57349,57356]
===
match
---
trailer [80625,80634]
trailer [80637,80646]
===
match
---
trailer [23373,23377]
trailer [23373,23377]
===
match
---
atom_expr [10483,10541]
atom_expr [10483,10541]
===
match
---
name: try_number [69066,69076]
name: try_number [69078,69088]
===
match
---
operator: , [12006,12007]
operator: , [12006,12007]
===
match
---
param [79153,79157]
param [79165,79169]
===
match
---
trailer [49850,49867]
trailer [49850,49867]
===
match
---
atom_expr [12468,12630]
atom_expr [12468,12630]
===
match
---
trailer [8306,8312]
trailer [8306,8312]
===
match
---
name: task [28133,28137]
name: task [28133,28137]
===
match
---
fstring_string: &task_id= [19962,19971]
fstring_string: &task_id= [19962,19971]
===
match
---
trailer [8647,8658]
trailer [8647,8658]
===
match
---
operator: , [74719,74720]
operator: , [74731,74732]
===
match
---
trailer [57800,57806]
trailer [57812,57818]
===
match
---
param [50275,50280]
param [50275,50280]
===
match
---
simple_stmt [66549,66641]
simple_stmt [66561,66653]
===
match
---
parameters [29479,29485]
parameters [29479,29485]
===
match
---
trailer [69258,69266]
trailer [69270,69278]
===
match
---
name: self [23911,23915]
name: self [23911,23915]
===
match
---
name: try_number [24932,24942]
name: try_number [24932,24942]
===
match
---
name: dag_id [7336,7342]
name: dag_id [7336,7342]
===
match
---
trailer [43984,44000]
trailer [43984,44000]
===
match
---
name: k [47677,47678]
name: k [47677,47678]
===
match
---
name: and_ [77573,77577]
name: and_ [77585,77589]
===
match
---
operator: = [61283,61284]
operator: = [61295,61296]
===
match
---
funcdef [19745,20008]
funcdef [19745,20008]
===
match
---
name: self [22714,22718]
name: self [22714,22718]
===
match
---
name: signal [878,884]
name: signal [878,884]
===
match
---
expr_stmt [74540,74560]
expr_stmt [74552,74572]
===
match
---
trailer [42168,42173]
trailer [42168,42173]
===
match
---
number: 0 [12990,12991]
number: 0 [12990,12991]
===
match
---
name: registered [48105,48115]
name: registered [48105,48115]
===
match
---
atom_expr [77188,77196]
atom_expr [77200,77208]
===
match
---
name: execution_date [6276,6290]
name: execution_date [6276,6290]
===
match
---
trailer [65799,65858]
trailer [65811,65870]
===
match
---
simple_stmt [25567,25633]
simple_stmt [25567,25633]
===
match
---
operator: , [72700,72701]
operator: , [72712,72713]
===
match
---
suite [50159,50222]
suite [50159,50222]
===
match
---
operator: = [6808,6809]
operator: = [6808,6809]
===
match
---
and_test [5524,5553]
and_test [5524,5553]
===
match
---
trailer [28882,28900]
trailer [28882,28900]
===
match
---
name: models [1907,1913]
name: models [1907,1913]
===
match
---
argument [47662,47713]
argument [47662,47713]
===
match
---
name: dag_run [66143,66150]
name: dag_run [66155,66162]
===
match
---
trailer [18920,18927]
trailer [18920,18927]
===
match
---
name: RUNNING [75889,75896]
name: RUNNING [75901,75908]
===
match
---
operator: = [12988,12989]
operator: = [12988,12989]
===
match
---
if_stmt [54634,54695]
if_stmt [54634,54695]
===
match
---
name: session [24228,24235]
name: session [24228,24235]
===
match
---
name: on_execute_callback [50451,50470]
name: on_execute_callback [50451,50470]
===
match
---
comparison [75807,75843]
comparison [75819,75855]
===
match
---
atom_expr [76561,76567]
atom_expr [76573,76579]
===
match
---
name: ignore_ti_state [16149,16164]
name: ignore_ti_state [16149,16164]
===
match
---
simple_stmt [62663,64289]
simple_stmt [62675,64301]
===
match
---
name: execution_date [77059,77073]
name: execution_date [77071,77085]
===
match
---
name: rendered_k8s_spec [65648,65665]
name: rendered_k8s_spec [65660,65677]
===
match
---
name: commit [44161,44167]
name: commit [44161,44167]
===
match
---
arglist [57842,57900]
arglist [57854,57912]
===
match
---
trailer [7648,7654]
trailer [7648,7654]
===
match
---
name: instance [62856,62864]
name: instance [62868,62876]
===
match
---
name: ignore_task_deps [16044,16060]
name: ignore_task_deps [16044,16060]
===
match
---
funcdef [23486,24176]
funcdef [23486,24176]
===
match
---
atom_expr [56334,56353]
atom_expr [56346,56365]
===
match
---
param [50617,50662]
param [50617,50662]
===
match
---
operator: , [34805,34806]
operator: , [34805,34806]
===
match
---
argument [32791,32806]
argument [32791,32806]
===
match
---
string: 'TaskInstanceKey' [9436,9453]
string: 'TaskInstanceKey' [9436,9453]
===
match
---
atom_expr [49192,49202]
atom_expr [49192,49202]
===
match
---
tfpdef [51833,51854]
tfpdef [51833,51854]
===
match
---
operator: , [61704,61705]
operator: , [61716,61717]
===
match
---
arglist [40034,40055]
arglist [40034,40055]
===
match
---
trailer [27924,27934]
trailer [27924,27934]
===
match
---
atom_expr [46934,46948]
atom_expr [46934,46948]
===
match
---
return_stmt [79433,79454]
return_stmt [79445,79466]
===
match
---
operator: , [12042,12043]
operator: , [12042,12043]
===
match
---
name: merge [46384,46389]
name: merge [46384,46389]
===
match
---
name: get_prev [28183,28191]
name: get_prev [28183,28191]
===
match
---
return_stmt [77847,77998]
return_stmt [77859,78010]
===
match
---
suite [60627,60665]
suite [60639,60677]
===
match
---
name: dag [62722,62725]
name: dag [62734,62737]
===
match
---
tfpdef [56846,56871]
tfpdef [56858,56883]
===
match
---
argument [67024,67087]
argument [67036,67099]
===
match
---
operator: { [45753,45754]
operator: { [45753,45754]
===
match
---
simple_stmt [62634,62654]
simple_stmt [62646,62666]
===
match
---
name: _CURRENT_CONTEXT [3585,3601]
name: _CURRENT_CONTEXT [3585,3601]
===
match
---
atom_expr [11051,11062]
atom_expr [11051,11062]
===
match
---
import_from [2861,2909]
import_from [2861,2909]
===
match
---
expr_stmt [76483,76498]
expr_stmt [76495,76510]
===
match
---
name: self [23137,23141]
name: self [23137,23141]
===
match
---
trailer [28670,28700]
trailer [28670,28700]
===
match
---
suite [57138,57263]
suite [57150,57275]
===
match
---
name: conditions [7436,7446]
name: conditions [7436,7446]
===
match
---
trailer [53733,53966]
trailer [53733,53966]
===
match
---
operator: = [52342,52343]
operator: = [52342,52343]
===
match
---
simple_stmt [5616,5643]
simple_stmt [5616,5643]
===
match
---
name: str [12086,12089]
name: str [12086,12089]
===
match
---
funcdef [20027,20463]
funcdef [20027,20463]
===
match
---
simple_stmt [4020,4064]
simple_stmt [4020,4064]
===
match
---
atom_expr [3244,3258]
atom_expr [3244,3258]
===
match
---
expr_stmt [59121,59162]
expr_stmt [59133,59174]
===
match
---
operator: = [31061,31062]
operator: = [31061,31062]
===
match
---
name: ds [59533,59535]
name: ds [59545,59547]
===
match
---
trailer [12708,12719]
trailer [12708,12719]
===
match
---
operator: = [10907,10908]
operator: = [10907,10908]
===
match
---
operator: @ [79848,79849]
operator: @ [79860,79861]
===
match
---
arglist [52147,52510]
arglist [52147,52510]
===
match
---
name: priority_weight [23225,23240]
name: priority_weight [23225,23240]
===
match
---
name: BooleanClauseList [1492,1509]
name: BooleanClauseList [1492,1509]
===
match
---
operator: , [60738,60739]
operator: , [60750,60751]
===
match
---
trailer [22126,22170]
trailer [22126,22170]
===
match
---
name: execution_date [8420,8434]
name: execution_date [8420,8434]
===
match
---
expr_stmt [57483,57494]
expr_stmt [57495,57506]
===
match
---
simple_stmt [58969,58984]
simple_stmt [58981,58996]
===
match
---
atom_expr [8358,8529]
atom_expr [8358,8529]
===
match
---
name: self [57229,57233]
name: self [57241,57245]
===
match
---
trailer [46389,46395]
trailer [46389,46395]
===
match
---
name: error_file [45875,45885]
name: error_file [45875,45885]
===
match
---
if_stmt [7677,8005]
if_stmt [7677,8005]
===
match
---
expr_stmt [59058,59108]
expr_stmt [59070,59120]
===
match
---
name: innerjoin [11992,12001]
name: innerjoin [11992,12001]
===
match
---
name: timedelta [968,977]
name: timedelta [968,977]
===
match
---
string: """         Checks dependencies and then sets state to RUNNING if they are met. Returns         True if and only if state is set to RUNNING, which implies that task should be         executed, in preparation for _run_raw_task          :param verbose: whether to turn on more verbose logging         :type verbose: bool         :param ignore_all_deps: Ignore all of the non-critical dependencies, just runs         :type ignore_all_deps: bool         :param ignore_depends_on_past: Ignore depends_on_past DAG attribute         :type ignore_depends_on_past: bool         :param ignore_task_deps: Don't check the dependencies of this TaskInstance's task         :type ignore_task_deps: bool         :param ignore_ti_state: Disregards previous task instance state         :type ignore_ti_state: bool         :param mark_success: Don't run the task, mark its state as success         :type mark_success: bool         :param test_mode: Doesn't record success or failure in the DB         :type test_mode: bool         :param job_id: Job (BackfillJob / LocalTaskJob / SchedulerJob) ID         :type job_id: str         :param pool: specifies the pool to use to run the task instance         :type pool: str         :param session: SQLAlchemy ORM Session         :type session: Session         :return: whether the state was changed to running or not         :rtype: bool         """ [36941,38316]
string: """         Checks dependencies and then sets state to RUNNING if they are met. Returns         True if and only if state is set to RUNNING, which implies that task should be         executed, in preparation for _run_raw_task          :param verbose: whether to turn on more verbose logging         :type verbose: bool         :param ignore_all_deps: Ignore all of the non-critical dependencies, just runs         :type ignore_all_deps: bool         :param ignore_depends_on_past: Ignore depends_on_past DAG attribute         :type ignore_depends_on_past: bool         :param ignore_task_deps: Don't check the dependencies of this TaskInstance's task         :type ignore_task_deps: bool         :param ignore_ti_state: Disregards previous task instance state         :type ignore_ti_state: bool         :param mark_success: Don't run the task, mark its state as success         :type mark_success: bool         :param test_mode: Doesn't record success or failure in the DB         :type test_mode: bool         :param job_id: Job (BackfillJob / LocalTaskJob / SchedulerJob) ID         :type job_id: str         :param pool: specifies the pool to use to run the task instance         :type pool: str         :param session: SQLAlchemy ORM Session         :type session: Session         :return: whether the state was changed to running or not         :rtype: bool         """ [36941,38316]
===
match
---
name: execution_date [72507,72521]
name: execution_date [72519,72533]
===
match
---
atom_expr [13056,13066]
atom_expr [13056,13066]
===
match
---
operator: , [64077,64078]
operator: , [64089,64090]
===
match
---
with_item [70160,70175]
with_item [70172,70187]
===
match
---
name: ti [78363,78365]
name: ti [78375,78377]
===
match
---
simple_stmt [10401,10470]
simple_stmt [10401,10470]
===
match
---
comparison [14066,14093]
comparison [14066,14093]
===
match
---
argument [7913,7925]
argument [7913,7925]
===
match
---
simple_stmt [27900,27935]
simple_stmt [27900,27935]
===
match
---
operator: , [41058,41059]
operator: , [41058,41059]
===
match
---
param [61619,61629]
param [61631,61641]
===
match
---
name: ti [21129,21131]
name: ti [21129,21131]
===
match
---
simple_stmt [3114,3172]
simple_stmt [3114,3172]
===
match
---
operator: , [59678,59679]
operator: , [59690,59691]
===
match
---
trailer [70212,70217]
trailer [70224,70229]
===
match
---
name: count [26920,26925]
name: count [26920,26925]
===
match
---
name: deps [33397,33401]
name: deps [33397,33401]
===
match
---
operator: = [76622,76623]
operator: = [76634,76635]
===
match
---
atom_expr [78621,78642]
atom_expr [78633,78654]
===
match
---
arglist [39065,39314]
arglist [39065,39314]
===
match
---
name: attr [42246,42250]
name: attr [42246,42250]
===
match
---
operator: = [40137,40138]
operator: = [40137,40138]
===
match
---
operator: @ [72590,72591]
operator: @ [72602,72603]
===
match
---
atom_expr [44833,44849]
atom_expr [44833,44849]
===
match
---
name: try_number [9416,9426]
name: try_number [9416,9426]
===
match
---
name: query [8307,8312]
name: query [8307,8312]
===
match
---
name: get_hostname [44071,44083]
name: get_hostname [44071,44083]
===
match
---
name: self [12972,12976]
name: self [12972,12976]
===
match
---
simple_stmt [14789,14813]
simple_stmt [14789,14813]
===
match
---
name: airflow [7514,7521]
name: airflow [7514,7521]
===
match
---
simple_stmt [53274,53296]
simple_stmt [53274,53296]
===
match
---
trailer [9359,9383]
trailer [9359,9383]
===
match
---
operator: - [9379,9380]
operator: - [9379,9380]
===
match
---
trailer [51151,51159]
trailer [51151,51159]
===
match
---
name: logging [3303,3310]
name: logging [3303,3310]
===
match
---
operator: , [42672,42673]
operator: , [42672,42673]
===
match
---
name: self [63379,63383]
name: self [63391,63395]
===
match
---
operator: = [65512,65513]
operator: = [65524,65525]
===
match
---
expr_stmt [59245,59259]
expr_stmt [59257,59271]
===
match
---
name: primary [77962,77969]
name: primary [77974,77981]
===
match
---
name: replace [59667,59674]
name: replace [59679,59686]
===
match
---
name: pod_id [66797,66803]
name: pod_id [66809,66815]
===
match
---
atom_expr [19054,19091]
atom_expr [19054,19091]
===
match
---
trailer [45427,45442]
trailer [45427,45442]
===
match
---
name: log [12473,12476]
name: log [12473,12476]
===
match
---
arith_expr [35032,35067]
arith_expr [35032,35067]
===
match
---
operator: , [66783,66784]
operator: , [66795,66796]
===
match
---
operator: , [61628,61629]
operator: , [61640,61641]
===
match
---
name: max_tries [24060,24069]
name: max_tries [24060,24069]
===
match
---
name: rendered_task_instance_fields [64649,64678]
name: rendered_task_instance_fields [64661,64690]
===
match
---
name: error [51063,51068]
name: error [51063,51068]
===
match
---
trailer [63540,63564]
trailer [63552,63576]
===
match
---
trailer [78326,78333]
trailer [78338,78345]
===
match
---
name: session [44009,44016]
name: session [44009,44016]
===
match
---
atom_expr [50996,51023]
atom_expr [50996,51023]
===
match
---
try_stmt [70789,70950]
try_stmt [70801,70962]
===
match
---
name: os [4079,4081]
name: os [4079,4081]
===
match
---
argument [39280,39313]
argument [39280,39313]
===
match
---
name: _log_state [46250,46260]
name: _log_state [46250,46260]
===
match
---
trailer [26649,26656]
trailer [26649,26656]
===
match
---
atom_expr [35916,35934]
atom_expr [35916,35934]
===
match
---
dotted_name [57691,57712]
dotted_name [57703,57724]
===
match
---
import_from [2179,2239]
import_from [2179,2239]
===
match
---
name: self [52553,52557]
name: self [52553,52557]
===
match
---
simple_stmt [47208,47302]
simple_stmt [47208,47302]
===
match
---
atom_expr [22989,23002]
atom_expr [22989,23002]
===
match
---
param [20513,20525]
param [20513,20525]
===
match
---
name: self [22306,22310]
name: self [22306,22310]
===
match
---
name: self [64798,64802]
name: self [64810,64814]
===
match
---
atom_expr [49299,49315]
atom_expr [49299,49315]
===
match
---
name: self [24927,24931]
name: self [24927,24931]
===
match
---
trailer [63564,63585]
trailer [63576,63597]
===
match
---
expr_stmt [5571,5599]
expr_stmt [5571,5599]
===
match
---
atom_expr [11324,11364]
atom_expr [11324,11364]
===
match
---
name: dag_id [9558,9564]
name: dag_id [9558,9564]
===
match
---
name: str [8876,8879]
name: str [8876,8879]
===
match
---
name: self [64712,64716]
name: self [64724,64728]
===
match
---
suite [49711,49965]
suite [49711,49965]
===
match
---
name: conf [70112,70116]
name: conf [70124,70128]
===
match
---
trailer [55209,55211]
trailer [55221,55223]
===
match
---
atom [19143,19172]
atom [19143,19172]
===
match
---
argument [76885,76955]
argument [76897,76967]
===
match
---
operator: -> [29486,29488]
operator: -> [29486,29488]
===
match
---
name: pod_override_object [67024,67043]
name: pod_override_object [67036,67055]
===
match
---
atom [58264,58300]
atom [58276,58312]
===
match
---
lambdef [5268,5292]
lambdef [5268,5292]
===
match
---
simple_stmt [41909,41951]
simple_stmt [41909,41951]
===
match
---
atom_expr [79357,79373]
atom_expr [79369,79385]
===
match
---
operator: , [26900,26901]
operator: , [26900,26901]
===
match
---
atom_expr [78539,78555]
atom_expr [78551,78567]
===
match
---
operator: , [22318,22319]
operator: , [22318,22319]
===
match
---
operator: + [42543,42544]
operator: + [42543,42544]
===
match
---
trailer [62254,62282]
trailer [62266,62294]
===
match
---
argument [40417,40438]
argument [40417,40438]
===
match
---
name: run_id [57953,57959]
name: run_id [57965,57971]
===
match
---
expr_stmt [8279,8572]
expr_stmt [8279,8572]
===
match
---
name: self [53274,53278]
name: self [53274,53278]
===
match
---
simple_stmt [53337,53357]
simple_stmt [53337,53357]
===
match
---
simple_stmt [30748,30960]
simple_stmt [30748,30960]
===
match
---
atom_expr [78519,78530]
atom_expr [78531,78542]
===
match
---
simple_stmt [21191,21204]
simple_stmt [21191,21204]
===
match
---
name: max_tries [41496,41505]
name: max_tries [41496,41505]
===
match
---
name: self [14114,14118]
name: self [14114,14118]
===
match
---
param [56922,56935]
param [56934,56947]
===
match
---
trailer [54266,54322]
trailer [54266,54322]
===
match
---
funcdef [33963,35728]
funcdef [33963,35728]
===
match
---
operator: == [75880,75882]
operator: == [75892,75894]
===
match
---
name: timezone [12417,12425]
name: timezone [12417,12425]
===
match
---
expr_stmt [38792,38825]
expr_stmt [38792,38825]
===
match
---
strings [7746,7867]
strings [7746,7867]
===
match
---
trailer [80784,80786]
trailer [80796,80798]
===
match
---
atom_expr [25641,25660]
atom_expr [25641,25660]
===
match
---
name: task [50404,50408]
name: task [50404,50408]
===
match
---
param [9410,9415]
param [9410,9415]
===
match
---
name: check_and_change_state_before_execution [36504,36543]
name: check_and_change_state_before_execution [36504,36543]
===
match
---
string: "Recording the task instance as FAILED" [21476,21515]
string: "Recording the task instance as FAILED" [21476,21515]
===
match
---
name: content [70025,70032]
name: content [70037,70044]
===
match
---
name: str [36883,36886]
name: str [36883,36886]
===
match
---
name: job_id [52810,52816]
name: job_id [52810,52816]
===
match
---
name: next_retry_datetime [35944,35963]
name: next_retry_datetime [35944,35963]
===
match
---
atom_expr [60407,60415]
atom_expr [60419,60427]
===
match
---
name: Union [54398,54403]
name: Union [54398,54403]
===
match
---
name: session [52494,52501]
name: session [52494,52501]
===
match
---
name: email_for_state [56206,56221]
name: email_for_state [56218,56233]
===
match
---
trailer [3763,3771]
trailer [3763,3771]
===
match
---
string: "Failed when executing execute callback" [50537,50577]
string: "Failed when executing execute callback" [50537,50577]
===
match
---
operator: = [59136,59137]
operator: = [59148,59149]
===
match
---
expr_stmt [80813,80829]
expr_stmt [80825,80841]
===
match
---
fstring_string: . [33903,33904]
fstring_string: . [33903,33904]
===
match
---
fstring_end: ' [55267,55268]
fstring_end: ' [55279,55280]
===
match
---
name: String [10721,10727]
name: String [10721,10727]
===
match
---
name: self [50907,50911]
name: self [50907,50911]
===
match
---
name: strftime [59593,59601]
name: strftime [59605,59613]
===
match
---
trailer [46754,46758]
trailer [46754,46758]
===
match
---
name: dag [27385,27388]
name: dag [27385,27388]
===
match
---
operator: = [49998,49999]
operator: = [49998,49999]
===
match
---
trailer [23224,23240]
trailer [23224,23240]
===
match
---
for_stmt [64615,64751]
for_stmt [64627,64763]
===
match
---
suite [20054,20463]
suite [20054,20463]
===
match
---
name: dag_id [19999,20005]
name: dag_id [19999,20005]
===
match
---
atom_expr [46376,46395]
atom_expr [46376,46395]
===
match
---
name: xcom [75489,75493]
name: xcom [75501,75505]
===
match
---
name: tomorrow_ds [58250,58261]
name: tomorrow_ds [58262,58273]
===
match
---
trailer [57065,57088]
trailer [57077,57100]
===
match
---
name: command_as_list [66993,67008]
name: command_as_list [67005,67020]
===
match
---
string: 'Mark success: <a href="{{ti.mark_success_url}}">Link</a><br>' [68253,68315]
string: 'Mark success: <a href="{{ti.mark_success_url}}">Link</a><br>' [68265,68327]
===
match
---
simple_stmt [1202,1260]
simple_stmt [1202,1260]
===
match
---
string: "Refreshed TaskInstance %s" [23446,23473]
string: "Refreshed TaskInstance %s" [23446,23473]
===
match
---
trailer [63113,63121]
trailer [63125,63133]
===
match
---
name: self [33920,33924]
name: self [33920,33924]
===
match
---
name: self [53815,53819]
name: self [53815,53819]
===
match
---
trailer [55181,55183]
trailer [55193,55195]
===
match
---
simple_stmt [67343,67403]
simple_stmt [67355,67415]
===
match
---
atom_expr [75807,75827]
atom_expr [75819,75839]
===
match
---
name: replace [59727,59734]
name: replace [59739,59746]
===
match
---
name: self [72634,72638]
name: self [72646,72650]
===
match
---
name: UP_FOR_RETRY [25920,25932]
name: UP_FOR_RETRY [25920,25932]
===
match
---
parameters [79322,79328]
parameters [79334,79340]
===
match
---
trailer [51047,51060]
trailer [51047,51060]
===
match
---
name: dag [15744,15747]
name: dag [15744,15747]
===
match
---
tfpdef [61619,61628]
tfpdef [61631,61640]
===
match
---
name: max_tries [41122,41131]
name: max_tries [41122,41131]
===
match
---
name: self [42283,42287]
name: self [42283,42287]
===
match
---
arglist [35657,35689]
arglist [35657,35689]
===
match
---
name: max_tries [69884,69893]
name: max_tries [69896,69905]
===
match
---
name: self [61336,61340]
name: self [61348,61352]
===
match
---
operator: , [63183,63184]
operator: , [63195,63196]
===
match
---
name: __getattr__ [60440,60451]
name: __getattr__ [60452,60463]
===
match
---
operator: , [55471,55472]
operator: , [55483,55484]
===
match
---
name: task [5571,5575]
name: task [5571,5575]
===
match
---
operator: , [59968,59969]
operator: , [59980,59981]
===
match
---
name: task_retries [5734,5746]
name: task_retries [5734,5746]
===
match
---
name: task [47961,47965]
name: task [47961,47965]
===
match
---
arglist [41445,41509]
arglist [41445,41509]
===
match
---
suite [45218,45515]
suite [45218,45515]
===
match
---
or_test [28527,28577]
or_test [28527,28577]
===
match
---
operator: , [70718,70719]
operator: , [70730,70731]
===
match
---
name: has_task [5536,5544]
name: has_task [5536,5544]
===
match
---
operator: @ [28958,28959]
operator: @ [28958,28959]
===
match
---
operator: % [35054,35055]
operator: % [35054,35055]
===
match
---
trailer [47856,47873]
trailer [47856,47873]
===
match
---
param [4745,4754]
param [4745,4754]
===
match
---
arglist [26670,26901]
arglist [26670,26901]
===
match
---
suite [56950,57102]
suite [56962,57114]
===
match
---
arglist [48955,49004]
arglist [48955,49004]
===
match
---
name: self [79323,79327]
name: self [79335,79339]
===
match
---
param [33851,33855]
param [33851,33855]
===
match
---
name: _execution_date [78387,78402]
name: _execution_date [78399,78414]
===
match
---
string: "Task failed with exception" [54794,54822]
string: "Task failed with exception" [54790,54818]
===
match
---
name: job [80973,80976]
name: job [80985,80988]
===
match
---
name: context [66229,66236]
name: context [66241,66248]
===
match
---
string: "wb" [4411,4415]
string: "wb" [4411,4415]
===
match
---
name: Stats [55220,55225]
name: Stats [55232,55237]
===
match
---
name: loads [4181,4186]
name: loads [4181,4186]
===
match
---
trailer [5636,5642]
trailer [5636,5642]
===
match
---
name: info [44842,44846]
name: info [44842,44846]
===
match
---
operator: = [67216,67217]
operator: = [67228,67229]
===
match
---
name: models [1956,1962]
name: models [1956,1962]
===
match
---
atom_expr [38332,38341]
atom_expr [38332,38341]
===
match
---
name: self [9580,9584]
name: self [9580,9584]
===
match
---
simple_stmt [56272,56304]
simple_stmt [56284,56316]
===
match
---
name: test_mode [42982,42991]
name: test_mode [42982,42991]
===
match
---
name: self [54680,54684]
name: self [54680,54684]
===
match
---
trailer [43892,43902]
trailer [43892,43902]
===
match
---
operator: , [59661,59662]
operator: , [59673,59674]
===
match
---
string: """             This attribute is deprecated.             Please use `airflow.models.taskinstance.TaskInstance.get_previous_ti` method.             """ [29178,29329]
string: """             This attribute is deprecated.             Please use `airflow.models.taskinstance.TaskInstance.get_previous_ti` method.             """ [29178,29329]
===
match
---
name: _start_date [79362,79373]
name: _start_date [79374,79385]
===
match
---
name: html_content_err [70458,70474]
name: html_content_err [70470,70486]
===
match
---
name: Any [62394,62397]
name: Any [62406,62409]
===
match
---
parameters [54367,54566]
parameters [54367,54566]
===
match
---
name: get_connection_from_secrets [62531,62558]
name: get_connection_from_secrets [62543,62570]
===
match
---
name: Column [10989,10995]
name: Column [10989,10995]
===
match
---
trailer [59792,59801]
trailer [59804,59813]
===
match
---
trailer [60020,60055]
trailer [60032,60067]
===
match
---
atom_expr [7657,7671]
atom_expr [7657,7671]
===
match
---
name: Optional [30656,30664]
name: Optional [30656,30664]
===
match
---
trailer [21475,21516]
trailer [21475,21516]
===
match
---
trailer [57649,57656]
trailer [57661,57668]
===
match
---
name: bind [77503,77507]
name: bind [77515,77519]
===
match
---
operator: } [59867,59868]
operator: } [59879,59880]
===
match
---
expr_stmt [5703,5750]
expr_stmt [5703,5750]
===
match
---
atom_expr [39493,39509]
atom_expr [39493,39509]
===
match
---
atom_expr [34828,34843]
atom_expr [34828,34843]
===
match
---
simple_stmt [835,847]
simple_stmt [835,847]
===
match
---
suite [7970,8005]
suite [7970,8005]
===
match
---
name: task [34201,34205]
name: task [34201,34205]
===
match
---
operator: , [31871,31872]
operator: , [31871,31872]
===
match
---
trailer [42716,42731]
trailer [42716,42731]
===
match
---
funcdef [60436,60595]
funcdef [60448,60607]
===
match
---
name: activate_dag_runs [7680,7697]
name: activate_dag_runs [7680,7697]
===
match
---
param [51708,51738]
param [51708,51738]
===
match
---
trailer [79045,79049]
trailer [79057,79061]
===
match
---
name: TaskInstanceKey [79879,79894]
name: TaskInstanceKey [79891,79906]
===
match
---
atom_expr [70477,70534]
atom_expr [70489,70546]
===
match
---
name: self [49192,49196]
name: self [49192,49196]
===
match
---
trailer [7079,7083]
trailer [7079,7083]
===
match
---
operator: - [25598,25599]
operator: - [25598,25599]
===
match
---
trailer [45442,45496]
trailer [45442,45496]
===
match
---
name: NamedTemporaryFile [52643,52661]
name: NamedTemporaryFile [52643,52661]
===
match
---
name: raw [76043,76046]
name: raw [76055,76058]
===
match
---
trailer [6159,6164]
trailer [6159,6164]
===
match
---
operator: == [51371,51373]
operator: == [51371,51373]
===
match
---
atom_expr [67253,67282]
atom_expr [67265,67294]
===
match
---
parameters [36543,36923]
parameters [36543,36923]
===
match
---
string: """Get Airflow Variable value""" [60847,60879]
string: """Get Airflow Variable value""" [60859,60891]
===
match
---
trailer [49278,49284]
trailer [49278,49284]
===
match
---
param [16655,16685]
param [16655,16685]
===
match
---
fstring_string: . [47111,47112]
fstring_string: . [47111,47112]
===
match
---
atom [25583,25616]
atom [25583,25616]
===
match
---
expr_stmt [5202,5214]
expr_stmt [5202,5214]
===
match
---
name: task_copy [47094,47103]
name: task_copy [47094,47103]
===
match
---
name: func [1340,1344]
name: func [1340,1344]
===
match
---
name: pool [52839,52843]
name: pool [52839,52843]
===
match
---
trailer [51417,51422]
trailer [51417,51422]
===
match
---
operator: , [45189,45190]
operator: , [45189,45190]
===
match
---
name: render_templates [64803,64819]
name: render_templates [64815,64831]
===
match
---
strings [48326,48439]
strings [48326,48439]
===
match
---
name: self [78585,78589]
name: self [78597,78601]
===
match
---
name: Optional [16916,16924]
name: Optional [16916,16924]
===
match
---
name: html_content [70843,70855]
name: html_content [70855,70867]
===
match
---
atom_expr [7456,7483]
atom_expr [7456,7483]
===
match
---
trailer [50911,50916]
trailer [50911,50916]
===
match
---
atom_expr [10909,10924]
atom_expr [10909,10924]
===
match
---
atom_expr [72678,72691]
atom_expr [72690,72703]
===
match
---
name: self [44521,44525]
name: self [44521,44525]
===
match
---
simple_stmt [56168,56194]
simple_stmt [56180,56206]
===
match
---
trailer [69190,69202]
trailer [69202,69214]
===
match
---
name: prev_ti [31025,31032]
name: prev_ti [31025,31032]
===
match
---
name: task [23514,23518]
name: task [23514,23518]
===
match
---
simple_stmt [13522,13582]
simple_stmt [13522,13582]
===
match
---
name: scalar [75925,75931]
name: scalar [75937,75943]
===
match
---
name: total_seconds [49786,49799]
name: total_seconds [49786,49799]
===
match
---
arglist [10996,11030]
arglist [10996,11030]
===
match
---
name: error [57095,57100]
name: error [57107,57112]
===
match
---
trailer [4779,4800]
trailer [4779,4800]
===
match
---
trailer [71171,71180]
trailer [71183,71192]
===
match
---
operator: , [31067,31068]
operator: , [31067,31068]
===
match
---
name: tis [76483,76486]
name: tis [76495,76498]
===
match
---
name: execution_date [58766,58780]
name: execution_date [58778,58792]
===
match
---
trailer [9082,9089]
trailer [9082,9089]
===
match
---
simple_stmt [10737,10792]
simple_stmt [10737,10792]
===
match
---
operator: , [77902,77903]
operator: , [77914,77915]
===
match
---
trailer [53701,53705]
trailer [53701,53705]
===
match
---
suite [70882,70950]
suite [70894,70962]
===
match
---
atom_expr [66738,66749]
atom_expr [66750,66761]
===
match
---
name: following_schedule [58920,58938]
name: following_schedule [58932,58950]
===
match
---
trailer [21572,21578]
trailer [21572,21578]
===
match
---
name: yesterday_ds [64209,64221]
name: yesterday_ds [64221,64233]
===
match
---
if_stmt [41983,42196]
if_stmt [41983,42196]
===
match
---
simple_stmt [5703,5751]
simple_stmt [5703,5751]
===
match
---
name: last_dagrun [28654,28665]
name: last_dagrun [28654,28665]
===
match
---
simple_stmt [11180,11215]
simple_stmt [11180,11215]
===
match
---
expr_stmt [78768,78802]
expr_stmt [78780,78814]
===
match
---
import_from [1943,1977]
import_from [1943,1977]
===
match
---
name: DagRun [81087,81093]
name: DagRun [81099,81105]
===
match
---
import_from [3000,3050]
import_from [3000,3050]
===
match
---
param [62380,62405]
param [62392,62417]
===
match
---
simple_stmt [61534,61555]
simple_stmt [61546,61567]
===
match
---
trailer [47929,47951]
trailer [47929,47951]
===
match
---
name: data [4096,4100]
name: data [4096,4100]
===
match
---
name: session [24468,24475]
name: session [24468,24475]
===
match
---
return_stmt [79904,79920]
return_stmt [79916,79932]
===
match
---
name: TaskInstance [77861,77873]
name: TaskInstance [77873,77885]
===
match
---
trailer [8161,8166]
trailer [8161,8166]
===
match
---
trailer [70398,70445]
trailer [70410,70457]
===
match
---
simple_stmt [49014,49041]
simple_stmt [49014,49041]
===
match
---
name: email [70827,70832]
name: email [70839,70844]
===
match
---
name: State [7657,7662]
name: State [7657,7662]
===
match
---
trailer [4070,4075]
trailer [4070,4075]
===
match
---
suite [26563,26588]
suite [26563,26588]
===
match
---
atom_expr [41219,41235]
atom_expr [41219,41235]
===
match
---
parameters [13615,13621]
parameters [13615,13621]
===
match
---
if_stmt [41727,41777]
if_stmt [41727,41777]
===
match
---
trailer [66954,66969]
trailer [66966,66981]
===
match
---
name: utils [2874,2879]
name: utils [2874,2879]
===
match
---
trailer [49692,49710]
trailer [49692,49710]
===
match
---
name: in_ [77130,77133]
name: in_ [77142,77145]
===
match
---
name: execution_date [6962,6976]
name: execution_date [6962,6976]
===
match
---
trailer [71032,71041]
trailer [71044,71053]
===
match
---
name: airflow [3119,3126]
name: airflow [3119,3126]
===
match
---
param [54391,54420]
param [54391,54420]
===
match
---
trailer [5287,5292]
trailer [5287,5292]
===
match
---
name: Optional [27114,27122]
name: Optional [27114,27122]
===
match
---
atom_expr [9321,9333]
atom_expr [9321,9333]
===
match
---
atom_expr [40007,40064]
atom_expr [40007,40064]
===
match
---
atom_expr [41117,41131]
atom_expr [41117,41131]
===
match
---
name: ApiClient [67359,67368]
name: ApiClient [67371,67380]
===
match
---
trailer [44617,44622]
trailer [44617,44622]
===
match
---
name: RUNNING [41639,41646]
name: RUNNING [41639,41646]
===
match
---
name: self [57132,57136]
name: self [57144,57148]
===
match
---
suite [46493,49041]
suite [46493,49041]
===
match
---
trailer [22906,22917]
trailer [22906,22917]
===
match
---
trailer [40033,40056]
trailer [40033,40056]
===
match
---
if_stmt [41587,41655]
if_stmt [41587,41655]
===
match
---
if_stmt [38849,41354]
if_stmt [38849,41354]
===
match
---
name: task [57398,57402]
name: task [57410,57414]
===
match
---
expr_stmt [53274,53295]
expr_stmt [53274,53295]
===
match
---
trailer [5720,5731]
trailer [5720,5731]
===
match
---
arglist [54873,54884]
arglist [54885,54896]
===
match
---
expr_stmt [8867,8879]
expr_stmt [8867,8879]
===
match
---
atom_expr [56681,56700]
atom_expr [56693,56712]
===
match
---
operator: , [63285,63286]
operator: , [63297,63298]
===
match
---
trailer [7471,7483]
trailer [7471,7483]
===
match
---
name: raw [16805,16808]
name: raw [16805,16808]
===
match
---
trailer [23201,23207]
trailer [23201,23207]
===
match
---
simple_stmt [62237,62289]
simple_stmt [62249,62301]
===
match
---
operator: = [22438,22439]
operator: = [22438,22439]
===
match
---
name: Optional [16775,16783]
name: Optional [16775,16783]
===
match
---
name: self [78845,78849]
name: self [78857,78861]
===
match
---
name: job_id [52444,52450]
name: job_id [52444,52450]
===
match
---
trailer [9312,9319]
trailer [9312,9319]
===
match
---
name: var [60412,60415]
name: var [60424,60427]
===
match
---
string: """Fetch rendered template fields from DB""" [65361,65405]
string: """Fetch rendered template fields from DB""" [65373,65417]
===
match
---
trailer [79835,79842]
trailer [79847,79854]
===
match
---
name: file_path [19625,19634]
name: file_path [19625,19634]
===
match
---
if_stmt [25428,25633]
if_stmt [25428,25633]
===
match
---
name: or_ [6810,6813]
name: or_ [6810,6813]
===
match
---
operator: - [58205,58206]
operator: - [58217,58218]
===
match
---
name: self [79489,79493]
name: self [79501,79505]
===
match
---
name: state [10706,10711]
name: state [10706,10711]
===
match
---
name: error_file [45886,45896]
name: error_file [45886,45896]
===
match
---
suite [8711,8763]
suite [8711,8763]
===
match
---
name: datetime [8900,8908]
name: datetime [8900,8908]
===
match
---
name: conf [1574,1578]
name: conf [1574,1578]
===
match
---
trailer [66443,66452]
trailer [66455,66464]
===
match
---
return_stmt [42327,42384]
return_stmt [42327,42384]
===
match
---
name: self [35902,35906]
name: self [35902,35906]
===
match
---
name: self [33159,33163]
name: self [33159,33163]
===
match
---
name: UP_FOR_RESCHEDULE [54025,54042]
name: UP_FOR_RESCHEDULE [54025,54042]
===
match
---
operator: ** [69377,69379]
operator: ** [69389,69391]
===
match
---
name: pool [23869,23873]
name: pool [23869,23873]
===
match
---
name: String [10490,10496]
name: String [10490,10496]
===
match
---
operator: , [63690,63691]
operator: , [63702,63703]
===
match
---
atom_expr [29934,29975]
atom_expr [29934,29975]
===
match
---
operator: == [52990,52992]
operator: == [52990,52992]
===
match
---
name: dag_run [57765,57772]
name: dag_run [57777,57784]
===
match
---
operator: = [69060,69061]
operator: = [69072,69073]
===
match
---
atom_expr [34679,34946]
atom_expr [34679,34946]
===
match
---
simple_stmt [13453,13514]
simple_stmt [13453,13514]
===
match
---
trailer [14916,14928]
trailer [14916,14928]
===
match
---
operator: = [46217,46218]
operator: = [46217,46218]
===
match
---
name: pickle [864,870]
name: pickle [864,870]
===
match
---
name: Context [66247,66254]
name: Context [66259,66266]
===
match
---
name: Tuple [78098,78103]
name: Tuple [78110,78115]
===
match
---
operator: = [50994,50995]
operator: = [50994,50995]
===
match
---
name: self [42661,42665]
name: self [42661,42665]
===
match
---
param [16723,16755]
param [16723,16755]
===
match
---
name: self [42073,42077]
name: self [42073,42077]
===
match
---
expr_stmt [26920,26936]
expr_stmt [26920,26936]
===
match
---
param [71302,71307]
param [71314,71319]
===
match
---
operator: = [78517,78518]
operator: = [78529,78530]
===
match
---
operator: = [61848,61849]
operator: = [61860,61861]
===
match
---
name: self [29480,29484]
name: self [29480,29484]
===
match
---
name: content [70265,70272]
name: content [70277,70284]
===
match
---
name: max_tries [57253,57262]
name: max_tries [57265,57274]
===
match
---
trailer [75931,75933]
trailer [75943,75945]
===
match
---
name: values_ordered_by_id [75328,75348]
name: values_ordered_by_id [75340,75360]
===
match
---
fstring_expr [55251,55267]
fstring_expr [55263,55279]
===
match
---
simple_stmt [34188,34218]
simple_stmt [34188,34218]
===
match
---
return_stmt [57200,57262]
return_stmt [57212,57274]
===
match
---
atom_expr [55452,55471]
atom_expr [55464,55483]
===
match
---
name: dr [8608,8610]
name: dr [8608,8610]
===
match
---
trailer [75406,75412]
trailer [75418,75424]
===
match
---
param [12032,12037]
param [12032,12037]
===
match
---
name: task_id [77895,77902]
name: task_id [77907,77914]
===
match
---
number: 1 [23172,23173]
number: 1 [23172,23173]
===
match
---
name: self [79406,79410]
name: self [79418,79422]
===
match
---
trailer [35515,35517]
trailer [35515,35517]
===
match
---
name: handle_failure [56964,56978]
name: handle_failure [56976,56990]
===
match
---
name: Optional [66238,66246]
name: Optional [66250,66258]
===
match
---
operator: { [65853,65854]
operator: { [65865,65866]
===
match
---
name: self [66818,66822]
name: self [66830,66834]
===
match
---
name: _try_number [22923,22934]
name: _try_number [22923,22934]
===
match
---
simple_stmt [2811,2861]
simple_stmt [2811,2861]
===
match
---
name: self [23314,23318]
name: self [23314,23318]
===
match
---
name: try_number [8913,8923]
name: try_number [8913,8923]
===
match
---
param [13438,13442]
param [13438,13442]
===
match
---
trailer [77276,77473]
trailer [77288,77485]
===
match
---
arglist [55446,55503]
arglist [55458,55515]
===
match
---
trailer [24120,24136]
trailer [24120,24136]
===
match
---
atom_expr [56709,56725]
atom_expr [56721,56737]
===
match
---
simple_stmt [70895,70950]
simple_stmt [70907,70962]
===
match
---
trailer [44107,44114]
trailer [44107,44114]
===
match
---
simple_stmt [79744,79773]
simple_stmt [79756,79785]
===
match
---
trailer [26730,26738]
trailer [26730,26738]
===
match
---
expr_stmt [8884,8908]
expr_stmt [8884,8908]
===
match
---
name: self [31766,31770]
name: self [31766,31770]
===
match
---
decorated [60678,60947]
decorated [60690,60959]
===
match
---
trailer [10496,10522]
trailer [10496,10522]
===
match
---
operator: , [38478,38479]
operator: , [38478,38479]
===
match
---
name: UndefinedError [1245,1259]
name: UndefinedError [1245,1259]
===
match
---
suite [47143,48935]
suite [47143,48935]
===
match
---
name: end_date [22653,22661]
name: end_date [22653,22661]
===
match
---
trailer [58051,58058]
trailer [58063,58070]
===
match
---
name: timedelta [35543,35552]
name: timedelta [35543,35552]
===
match
---
name: BaseJob [7585,7592]
name: BaseJob [7585,7592]
===
match
---
trailer [78606,78612]
trailer [78618,78624]
===
match
---
name: dep_status [33020,33030]
name: dep_status [33020,33030]
===
match
---
if_stmt [59022,59236]
if_stmt [59034,59248]
===
match
---
name: State [63418,63423]
name: State [63430,63435]
===
match
---
argument [57866,57900]
argument [57878,57912]
===
match
---
expr_stmt [57547,57561]
expr_stmt [57559,57573]
===
match
---
operator: { [19993,19994]
operator: { [19993,19994]
===
match
---
name: start_date [40126,40136]
name: start_date [40126,40136]
===
match
---
name: result [48927,48933]
name: result [48927,48933]
===
match
---
operator: } [19984,19985]
operator: } [19984,19985]
===
match
---
trailer [26656,26911]
trailer [26656,26911]
===
match
---
name: self [36027,36031]
name: self [36027,36031]
===
match
---
parameters [42922,43150]
parameters [42922,43150]
===
match
---
atom_expr [42686,42698]
atom_expr [42686,42698]
===
match
---
fstring_start: f' [46099,46101]
fstring_start: f' [46099,46101]
===
match
---
name: self [8964,8968]
name: self [8964,8968]
===
match
---
name: datetime [958,966]
name: datetime [958,966]
===
match
---
operator: == [76894,76896]
operator: == [76906,76908]
===
match
---
term [34556,34608]
term [34556,34608]
===
match
---
name: context [3384,3391]
name: context [3384,3391]
===
match
---
arglist [9553,9611]
arglist [9553,9611]
===
match
---
name: external_executor_id [11301,11321]
name: external_executor_id [11301,11321]
===
match
---
expr_stmt [10796,10823]
expr_stmt [10796,10823]
===
match
---
name: self [69894,69898]
name: self [69906,69910]
===
match
---
name: unixname [23034,23042]
name: unixname [23034,23042]
===
match
---
name: self [69061,69065]
name: self [69073,69077]
===
match
---
trailer [77611,77618]
trailer [77623,77630]
===
match
---
operator: , [2172,2173]
operator: , [2172,2173]
===
match
---
decorator [65285,65302]
decorator [65297,65314]
===
match
---
operator: = [52154,52155]
operator: = [52154,52155]
===
match
---
name: debug [33526,33531]
name: debug [33526,33531]
===
match
---
name: self [49474,49478]
name: self [49474,49478]
===
match
---
simple_stmt [41519,41548]
simple_stmt [41519,41548]
===
match
---
operator: , [66749,66750]
operator: , [66761,66762]
===
match
---
trailer [40009,40033]
trailer [40009,40033]
===
match
---
atom_expr [38644,38657]
atom_expr [38644,38657]
===
match
---
atom_expr [26538,26562]
atom_expr [26538,26562]
===
match
---
decorated [29442,29976]
decorated [29442,29976]
===
match
---
operator: - [71106,71107]
operator: - [71118,71119]
===
match
---
operator: = [40584,40585]
operator: = [40584,40585]
===
match
---
name: ti [6311,6313]
name: ti [6311,6313]
===
match
---
atom_expr [12417,12454]
atom_expr [12417,12454]
===
match
---
name: property [79295,79303]
name: property [79307,79315]
===
match
---
name: base [1853,1857]
name: base [1853,1857]
===
match
---
trailer [72297,72334]
trailer [72309,72346]
===
match
---
name: pool_slots [23916,23926]
name: pool_slots [23916,23926]
===
match
---
tfpdef [56808,56836]
tfpdef [56820,56848]
===
match
---
trailer [24437,24459]
trailer [24437,24459]
===
match
---
simple_stmt [54775,54824]
simple_stmt [54775,54836]
===
match
---
dotted_name [1461,1484]
dotted_name [1461,1484]
===
match
---
operator: , [8982,8983]
operator: , [8982,8983]
===
match
---
name: self [70612,70616]
name: self [70624,70628]
===
match
---
atom_expr [78363,78373]
atom_expr [78375,78385]
===
match
---
name: pendulum [30137,30145]
name: pendulum [30137,30145]
===
match
---
simple_stmt [57411,57438]
simple_stmt [57423,57450]
===
match
---
trailer [78831,78836]
trailer [78843,78848]
===
match
---
string: 'webserver' [19884,19895]
string: 'webserver' [19884,19895]
===
match
---
atom_expr [58911,58959]
atom_expr [58923,58971]
===
match
---
name: dep_name [32994,33002]
name: dep_name [32994,33002]
===
match
---
trailer [77135,77143]
trailer [77147,77155]
===
match
---
trailer [78704,78709]
trailer [78716,78721]
===
match
---
simple_stmt [58685,58727]
simple_stmt [58697,58739]
===
match
---
operator: = [3242,3243]
operator: = [3242,3243]
===
match
---
name: self [61251,61255]
name: self [61263,61267]
===
match
---
name: FileSystemLoader [69234,69250]
name: FileSystemLoader [69246,69262]
===
match
---
name: render_templates [66206,66222]
name: render_templates [66218,66234]
===
match
---
trailer [75413,75419]
trailer [75425,75431]
===
match
---
name: property [79541,79549]
name: property [79553,79561]
===
match
---
name: Sentry [2267,2273]
name: Sentry [2267,2273]
===
match
---
operator: = [70475,70476]
operator: = [70487,70488]
===
match
---
name: ti [78604,78606]
name: ti [78616,78618]
===
match
---
atom_expr [57610,57625]
atom_expr [57622,57637]
===
match
---
decorated [79127,79196]
decorated [79139,79208]
===
match
---
simple_stmt [43888,43915]
simple_stmt [43888,43915]
===
match
---
name: int [34542,34545]
name: int [34542,34545]
===
match
---
atom_expr [47835,47873]
atom_expr [47835,47873]
===
match
---
atom_expr [66950,66969]
atom_expr [66962,66981]
===
match
---
name: self [80058,80062]
name: self [80070,80074]
===
match
---
fstring_expr [33890,33903]
fstring_expr [33890,33903]
===
match
---
trailer [8438,8445]
trailer [8438,8445]
===
match
---
name: Context [3234,3241]
name: Context [3234,3241]
===
match
---
operator: = [56872,56873]
operator: = [56884,56885]
===
match
---
name: _try_number [41561,41572]
name: _try_number [41561,41572]
===
match
---
name: result [48920,48926]
name: result [48920,48926]
===
match
---
argument [31795,31814]
argument [31795,31814]
===
match
---
try_stmt [48140,48502]
try_stmt [48140,48502]
===
match
---
trailer [41924,41932]
trailer [41924,41932]
===
match
---
yield_expr [33816,33832]
yield_expr [33816,33832]
===
match
---
trailer [5581,5590]
trailer [5581,5590]
===
match
---
string: "exception" [51048,51059]
string: "exception" [51048,51059]
===
match
---
name: self [61400,61404]
name: self [61412,61416]
===
match
---
name: integrate_macros_plugins [2215,2239]
name: integrate_macros_plugins [2215,2239]
===
match
---
name: State [51146,51151]
name: State [51146,51151]
===
match
---
name: self [71075,71079]
name: self [71087,71091]
===
match
---
expr_stmt [69172,69308]
expr_stmt [69184,69320]
===
match
---
name: extend [19219,19225]
name: extend [19219,19225]
===
match
---
name: kube_config [67157,67168]
name: kube_config [67169,67180]
===
match
---
simple_stmt [64475,64561]
simple_stmt [64487,64573]
===
match
---
trailer [47577,47729]
trailer [47577,47729]
===
match
---
name: self [22363,22367]
name: self [22363,22367]
===
match
---
expr_stmt [21191,21203]
expr_stmt [21191,21203]
===
match
---
name: cfg_path [19696,19704]
name: cfg_path [19696,19704]
===
match
---
name: e [65758,65759]
name: e [65770,65771]
===
match
---
expr_stmt [32620,32634]
expr_stmt [32620,32634]
===
match
---
trailer [54024,54042]
trailer [54024,54042]
===
match
---
suite [76207,77999]
suite [76219,78011]
===
match
---
trailer [75737,75911]
trailer [75749,75923]
===
match
---
operator: = [53284,53285]
operator: = [53284,53285]
===
match
---
funcdef [27017,28953]
funcdef [27017,28953]
===
match
---
name: Stats [38671,38676]
name: Stats [38671,38676]
===
match
---
name: Integer [10815,10822]
name: Integer [10815,10822]
===
match
---
simple_stmt [42204,42216]
simple_stmt [42204,42216]
===
match
---
name: execution_date [72104,72118]
name: execution_date [72116,72130]
===
match
---
atom_expr [75186,75198]
atom_expr [75198,75210]
===
match
---
atom_expr [15605,15617]
atom_expr [15605,15617]
===
match
---
name: dr [28668,28670]
name: dr [28668,28670]
===
match
---
simple_stmt [50314,50376]
simple_stmt [50314,50376]
===
match
---
operator: , [15131,15132]
operator: , [15131,15132]
===
match
---
name: provide_session [33191,33206]
name: provide_session [33191,33206]
===
match
---
operator: = [15955,15956]
operator: = [15955,15956]
===
match
---
name: self [33471,33475]
name: self [33471,33475]
===
match
---
operator: = [78966,78967]
operator: = [78978,78979]
===
match
---
decorated [25666,25964]
decorated [25666,25964]
===
match
---
operator: = [16291,16292]
operator: = [16291,16292]
===
match
---
operator: = [72383,72384]
operator: = [72395,72396]
===
match
---
name: ti [22650,22652]
name: ti [22650,22652]
===
match
---
name: state [11713,11718]
name: state [11713,11718]
===
match
---
param [21670,21691]
param [21670,21691]
===
match
---
string: "&downstream=false" [20404,20423]
string: "&downstream=false" [20404,20423]
===
match
---
atom_expr [22257,22268]
atom_expr [22257,22268]
===
match
---
name: Optional [12077,12085]
name: Optional [12077,12085]
===
match
---
trailer [67311,67329]
trailer [67323,67341]
===
match
---
simple_stmt [15788,15800]
simple_stmt [15788,15800]
===
match
---
decorator [42879,42901]
decorator [42879,42901]
===
match
---
name: state [63565,63570]
name: state [63577,63582]
===
match
---
trailer [9570,9578]
trailer [9570,9578]
===
match
---
name: task_id [72439,72446]
name: task_id [72451,72458]
===
match
---
name: task_id [77122,77129]
name: task_id [77134,77141]
===
match
---
atom_expr [34196,34217]
atom_expr [34196,34217]
===
match
---
atom_expr [79440,79454]
atom_expr [79452,79466]
===
match
---
atom_expr [62909,62920]
atom_expr [62921,62932]
===
match
---
suite [5313,6323]
suite [5313,6323]
===
match
---
dotted_name [2663,2680]
dotted_name [2663,2680]
===
match
---
parameters [79563,79569]
parameters [79575,79581]
===
match
---
name: self [42062,42066]
name: self [42062,42066]
===
match
---
simple_stmt [8608,8633]
simple_stmt [8608,8633]
===
match
---
name: bool [51886,51890]
name: bool [51886,51890]
===
match
---
name: exception [69740,69749]
name: exception [69752,69761]
===
match
---
simple_stmt [36287,36455]
simple_stmt [36287,36455]
===
match
---
trailer [50936,50956]
trailer [50936,50956]
===
match
---
trailer [75888,75896]
trailer [75900,75908]
===
match
---
operator: = [36050,36051]
operator: = [36050,36051]
===
match
---
name: exception [68958,68967]
name: exception [68970,68979]
===
match
---
name: execution_date [8254,8268]
name: execution_date [8254,8268]
===
match
---
name: Exception [50495,50504]
name: Exception [50495,50504]
===
match
---
name: task_id [77136,77143]
name: task_id [77148,77155]
===
match
---
name: task_copy [53337,53346]
name: task_copy [53337,53346]
===
match
---
name: self [49285,49289]
name: self [49285,49289]
===
match
---
name: jinja_env [69520,69529]
name: jinja_env [69532,69541]
===
match
---
atom_expr [71196,71252]
atom_expr [71208,71264]
===
match
---
if_stmt [59943,60088]
if_stmt [59955,60100]
===
match
---
atom_expr [71370,71388]
atom_expr [71382,71400]
===
match
---
expr_stmt [6143,6164]
expr_stmt [6143,6164]
===
match
---
name: exception_html [68999,69013]
name: exception_html [69011,69025]
===
match
---
param [24228,24240]
param [24228,24240]
===
match
---
expr_stmt [58169,58241]
expr_stmt [58181,58253]
===
match
---
trailer [49019,49024]
trailer [49019,49024]
===
match
---
name: ti [22435,22437]
name: ti [22435,22437]
===
match
---
operator: , [12583,12584]
operator: , [12583,12584]
===
match
---
name: default_html_content_err [68335,68359]
name: default_html_content_err [68347,68371]
===
match
---
trailer [41917,41924]
trailer [41917,41924]
===
match
---
name: ignore_ti_state [15110,15125]
name: ignore_ti_state [15110,15125]
===
match
---
atom_expr [72188,72334]
atom_expr [72200,72346]
===
match
---
name: base_job [7527,7535]
name: base_job [7527,7535]
===
match
---
operator: , [24904,24905]
operator: , [24904,24905]
===
match
---
name: load_error_file [3949,3964]
name: load_error_file [3949,3964]
===
match
---
operator: , [63655,63656]
operator: , [63667,63668]
===
match
---
name: debug [30398,30403]
name: debug [30398,30403]
===
match
---
name: context [48753,48760]
name: context [48753,48760]
===
match
---
name: duration [71243,71251]
name: duration [71255,71263]
===
match
---
trailer [68936,69145]
trailer [68948,69157]
===
match
---
expr_stmt [51406,51422]
expr_stmt [51406,51422]
===
match
---
expr_stmt [19811,19855]
expr_stmt [19811,19855]
===
match
---
simple_stmt [847,857]
simple_stmt [847,857]
===
match
---
operator: = [70737,70738]
operator: = [70749,70750]
===
match
---
atom_expr [3969,3978]
atom_expr [3969,3978]
===
match
---
trailer [6831,7319]
trailer [6831,7319]
===
match
---
name: SENSING [49211,49218]
name: SENSING [49211,49218]
===
match
---
dotted_name [2184,2207]
dotted_name [2184,2207]
===
match
---
name: airflow [2953,2960]
name: airflow [2953,2960]
===
match
---
name: _try_number [54174,54185]
name: _try_number [54174,54185]
===
match
---
name: pool [11746,11750]
name: pool [11746,11750]
===
match
---
param [56794,56799]
param [56806,56811]
===
match
---
name: primary_key [10452,10463]
name: primary_key [10452,10463]
===
match
---
string: """Returns SQLAlchemy filter to query selected task instances""" [76216,76280]
string: """Returns SQLAlchemy filter to query selected task instances""" [76228,76292]
===
match
---
name: task_copy [49758,49767]
name: task_copy [49758,49767]
===
match
---
argument [52494,52509]
argument [52494,52509]
===
match
---
argument [52834,52843]
argument [52834,52843]
===
match
---
name: cmd [19670,19673]
name: cmd [19670,19673]
===
match
---
name: Sentry [42880,42886]
name: Sentry [42880,42886]
===
match
---
arglist [34780,34843]
arglist [34780,34843]
===
match
---
string: """Handle Failure for the TaskInstance""" [54584,54625]
string: """Handle Failure for the TaskInstance""" [54584,54625]
===
match
---
atom [34580,34608]
atom [34580,34608]
===
match
---
trailer [19303,19310]
trailer [19303,19310]
===
match
---
trailer [70280,70297]
trailer [70292,70309]
===
match
---
simple_stmt [23314,23348]
simple_stmt [23314,23348]
===
match
---
trailer [22993,23002]
trailer [22993,23002]
===
match
---
name: tis [76952,76955]
name: tis [76964,76967]
===
match
---
name: Connection [1932,1942]
name: Connection [1932,1942]
===
match
---
name: self [15859,15863]
name: self [15859,15863]
===
match
---
name: Float [1291,1296]
name: Float [1291,1296]
===
match
---
suite [48263,48502]
suite [48263,48502]
===
match
---
name: append [5444,5450]
name: append [5444,5450]
===
match
---
name: staticmethod [62303,62315]
name: staticmethod [62315,62327]
===
match
---
operator: } [15665,15666]
operator: } [15665,15666]
===
match
---
atom [75071,75225]
atom [75083,75237]
===
match
---
simple_stmt [4635,4663]
simple_stmt [4635,4663]
===
match
---
return_stmt [14905,14932]
return_stmt [14905,14932]
===
match
---
name: str [16952,16955]
name: str [16952,16955]
===
match
---
trailer [51442,51460]
trailer [51442,51460]
===
match
---
operator: = [24235,24236]
operator: = [24235,24236]
===
match
---
operator: = [10749,10750]
operator: = [10749,10750]
===
match
---
atom_expr [24093,24113]
atom_expr [24093,24113]
===
match
---
trailer [24149,24158]
trailer [24149,24158]
===
match
---
operator: = [57490,57491]
operator: = [57502,57503]
===
match
---
string: '' [42427,42429]
string: '' [42427,42429]
===
match
---
atom [64841,64881]
atom [64853,64893]
===
match
---
name: self [24892,24896]
name: self [24892,24896]
===
match
---
name: FAILED [45775,45781]
name: FAILED [45775,45781]
===
match
---
operator: , [12068,12069]
operator: , [12068,12069]
===
match
---
string: """Remake the key by subtracting 1 from try number to match in memory information""" [9192,9276]
string: """Remake the key by subtracting 1 from try number to match in memory information""" [9192,9276]
===
match
---
name: merge [6228,6233]
name: merge [6228,6233]
===
match
---
trailer [10569,10600]
trailer [10569,10600]
===
match
---
operator: , [3927,3928]
operator: , [3927,3928]
===
match
---
simple_stmt [11497,11819]
simple_stmt [11497,11819]
===
match
---
decorated [51626,53120]
decorated [51626,53120]
===
match
---
operator: = [11024,11025]
operator: = [11024,11025]
===
match
---
atom_expr [53884,53897]
atom_expr [53884,53897]
===
match
---
suite [41970,42196]
suite [41970,42196]
===
match
---
atom_expr [21153,21164]
atom_expr [21153,21164]
===
match
---
name: get_previous_ti [27021,27036]
name: get_previous_ti [27021,27036]
===
match
---
simple_stmt [56510,56534]
simple_stmt [56522,56546]
===
match
---
name: debug [22121,22126]
name: debug [22121,22126]
===
match
---
name: value [75407,75412]
name: value [75419,75424]
===
match
---
trailer [67056,67065]
trailer [67068,67077]
===
match
---
import_from [1540,1578]
import_from [1540,1578]
===
match
---
atom_expr [81128,81149]
atom_expr [81140,81161]
===
match
---
name: on_retry_callback [51443,51460]
name: on_retry_callback [51443,51460]
===
match
---
trailer [67397,67402]
trailer [67409,67414]
===
match
---
atom_expr [13305,13313]
atom_expr [13305,13313]
===
match
---
name: incr [46094,46098]
name: incr [46094,46098]
===
match
---
comparison [6849,6868]
comparison [6849,6868]
===
match
---
simple_stmt [46405,46422]
simple_stmt [46405,46422]
===
match
---
name: _CURRENT_CONTEXT [3260,3276]
name: _CURRENT_CONTEXT [3260,3276]
===
match
---
atom_expr [76126,76174]
atom_expr [76138,76186]
===
match
---
name: str [19006,19009]
name: str [19006,19009]
===
match
---
expr_stmt [71167,71187]
expr_stmt [71179,71199]
===
match
---
name: try_number [14199,14209]
name: try_number [14199,14209]
===
match
---
atom_expr [77109,77157]
atom_expr [77121,77169]
===
match
---
param [79712,79716]
param [79724,79728]
===
match
---
name: Stats [49014,49019]
name: Stats [49014,49019]
===
match
---
trailer [77961,77969]
trailer [77973,77981]
===
match
---
operator: { [20310,20311]
operator: { [20310,20311]
===
match
---
name: quote [20106,20111]
name: quote [20106,20111]
===
match
---
name: info [52562,52566]
name: info [52562,52566]
===
match
---
operator: , [57318,57319]
operator: , [57330,57331]
===
match
---
decorated [30585,31242]
decorated [30585,31242]
===
match
---
name: first [75414,75419]
name: first [75426,75431]
===
match
---
name: dag [15490,15493]
name: dag [15490,15493]
===
match
---
operator: ** [69575,69577]
operator: ** [69587,69589]
===
match
---
trailer [57806,57814]
trailer [57818,57826]
===
match
---
trailer [28101,28214]
trailer [28101,28214]
===
match
---
trailer [4105,4110]
trailer [4105,4110]
===
match
---
name: var [60538,60541]
name: var [60550,60553]
===
match
---
atom_expr [23845,23855]
atom_expr [23845,23855]
===
match
---
operator: = [16552,16553]
operator: = [16552,16553]
===
match
---
param [28988,28992]
param [28988,28992]
===
match
---
suite [62420,62654]
suite [62432,62666]
===
match
---
name: executor_config [67071,67086]
name: executor_config [67083,67098]
===
match
---
operator: = [28525,28526]
operator: = [28525,28526]
===
match
---
number: 1 [69861,69862]
number: 1 [69873,69874]
===
match
---
trailer [24487,24494]
trailer [24487,24494]
===
match
---
atom_expr [23911,23926]
atom_expr [23911,23926]
===
match
---
decorated [79678,79773]
decorated [79690,79785]
===
match
---
atom_expr [78829,78836]
atom_expr [78841,78848]
===
match
---
atom_expr [4394,4416]
atom_expr [4394,4416]
===
match
---
atom_expr [24686,24721]
atom_expr [24686,24721]
===
match
---
name: default_conn [62380,62392]
name: default_conn [62392,62404]
===
match
---
name: _set_context [76060,76072]
name: _set_context [76072,76084]
===
match
---
name: from_obj [67057,67065]
name: from_obj [67069,67077]
===
match
---
atom_expr [19132,19173]
atom_expr [19132,19173]
===
match
---
name: email [56635,56640]
name: email [56647,56652]
===
match
---
tfpdef [12070,12090]
tfpdef [12070,12090]
===
match
---
trailer [5705,5715]
trailer [5705,5715]
===
match
---
operator: , [52027,52028]
operator: , [52027,52028]
===
match
---
dictorsetmaker [64047,64123]
dictorsetmaker [64059,64135]
===
match
---
atom [19311,19339]
atom [19311,19339]
===
match
---
name: XCom [75466,75470]
name: XCom [75478,75482]
===
match
---
name: ds_nodash [59521,59530]
name: ds_nodash [59533,59542]
===
match
---
arglist [12720,12758]
arglist [12720,12758]
===
match
---
argument [39449,39461]
argument [39449,39461]
===
match
---
operator: = [52969,52970]
operator: = [52969,52970]
===
match
---
name: min_backoff [35032,35043]
name: min_backoff [35032,35043]
===
match
---
name: self [24879,24883]
name: self [24879,24883]
===
match
---
trailer [27442,27453]
trailer [27442,27453]
===
match
---
name: _prepare_and_execute_task_with_callbacks [46431,46471]
name: _prepare_and_execute_task_with_callbacks [46431,46471]
===
match
---
operator: , [34931,34932]
operator: , [34931,34932]
===
match
---
operator: = [23927,23928]
operator: = [23927,23928]
===
match
---
string: '%Y-%m-%d' [59097,59107]
string: '%Y-%m-%d' [59109,59119]
===
match
---
atom_expr [59533,59552]
atom_expr [59545,59564]
===
match
---
atom_expr [49129,49183]
atom_expr [49129,49183]
===
match
---
suite [53484,54323]
suite [53484,54323]
===
match
---
name: execution_date [8884,8898]
name: execution_date [8884,8898]
===
match
---
trailer [38336,38341]
trailer [38336,38341]
===
match
---
trailer [61423,61452]
trailer [61435,61464]
===
match
---
expr_stmt [34669,34946]
expr_stmt [34669,34946]
===
match
---
trailer [53027,53037]
trailer [53027,53037]
===
match
---
name: first_task_id [77445,77458]
name: first_task_id [77457,77470]
===
match
---
name: lead_msg [42607,42615]
name: lead_msg [42607,42615]
===
match
---
funcdef [21251,21604]
funcdef [21251,21604]
===
match
---
trailer [32868,33052]
trailer [32868,33052]
===
match
---
name: pickle_id [16203,16212]
name: pickle_id [16203,16212]
===
match
---
name: SEEK_SET [4082,4090]
name: SEEK_SET [4082,4090]
===
match
---
name: provide_session [31822,31837]
name: provide_session [31822,31837]
===
match
---
name: self [38350,38354]
name: self [38350,38354]
===
match
---
name: AirflowSmartSensorException [44563,44590]
name: AirflowSmartSensorException [44563,44590]
===
match
---
strings [68043,68315]
strings [68055,68327]
===
match
---
simple_stmt [61469,61485]
simple_stmt [61481,61497]
===
match
---
trailer [72529,72544]
trailer [72541,72556]
===
match
---
name: max [35498,35501]
name: max [35498,35501]
===
match
---
name: Exception [4003,4012]
name: Exception [4003,4012]
===
match
---
name: task [51313,51317]
name: task [51313,51317]
===
match
---
expr_stmt [6073,6130]
expr_stmt [6073,6130]
===
match
---
name: exception [54784,54793]
name: error [54784,54789]
===
match
---
tfpdef [51908,51923]
tfpdef [51908,51923]
===
match
---
atom_expr [12184,12196]
atom_expr [12184,12196]
===
match
---
expr_stmt [27385,27404]
expr_stmt [27385,27404]
===
match
---
param [33987,33991]
param [33987,33991]
===
match
---
name: task_copy [50000,50009]
name: task_copy [50000,50009]
===
match
---
operator: } [65855,65856]
operator: } [65867,65868]
===
match
---
name: self [23186,23190]
name: self [23186,23190]
===
match
---
name: register_in_sensor_service [48188,48214]
name: register_in_sensor_service [48188,48214]
===
match
---
string: 'yesterday_ds' [64193,64207]
string: 'yesterday_ds' [64205,64219]
===
match
---
param [16417,16429]
param [16417,16429]
===
match
---
trailer [41681,41689]
trailer [41681,41689]
===
match
---
name: instance [59482,59490]
name: instance [59494,59502]
===
match
---
simple_stmt [4068,4092]
simple_stmt [4068,4092]
===
match
---
operator: , [28913,28914]
operator: , [28913,28914]
===
match
---
arglist [53751,53952]
arglist [53751,53952]
===
match
---
name: self [41698,41702]
name: self [41698,41702]
===
match
---
atom_expr [51180,51189]
atom_expr [51180,51189]
===
match
---
expr_stmt [70105,70134]
expr_stmt [70117,70146]
===
match
---
operator: = [53462,53463]
operator: = [53462,53463]
===
match
---
name: task_id_by_key [5219,5233]
name: task_id_by_key [5219,5233]
===
match
---
name: airflow [46548,46555]
name: airflow [46548,46555]
===
match
---
operator: , [41135,41136]
operator: , [41135,41136]
===
match
---
trailer [33947,33953]
trailer [33947,33953]
===
match
---
name: get_previous_execution_date [30006,30033]
name: get_previous_execution_date [30006,30033]
===
match
---
name: utcnow [44207,44213]
name: utcnow [44207,44213]
===
match
---
trailer [44470,44486]
trailer [44470,44486]
===
match
---
operator: -> [76176,76178]
operator: -> [76188,76190]
===
match
---
name: context [47179,47186]
name: context [47179,47186]
===
match
---
string: """         Refreshes the task instance from the database based on the primary key          :param session: SQLAlchemy ORM Session         :type session: Session         :param lock_for_update: if True, indicates that the database should             lock the TaskInstance (issuing a FOR UPDATE clause) until the             session is committed.         :type lock_for_update: bool         """ [21710,22103]
string: """         Refreshes the task instance from the database based on the primary key          :param session: SQLAlchemy ORM Session         :type session: Session         :param lock_for_update: if True, indicates that the database should             lock the TaskInstance (issuing a FOR UPDATE clause) until the             session is committed.         :type lock_for_update: bool         """ [21710,22103]
===
match
---
name: warning [12477,12484]
name: warning [12477,12484]
===
match
---
argument [35553,35585]
argument [35553,35585]
===
match
---
name: isoformat [58149,58158]
name: isoformat [58161,58170]
===
match
---
simple_stmt [69501,69592]
simple_stmt [69513,69604]
===
match
---
name: delete_qry [7395,7405]
name: delete_qry [7395,7405]
===
match
---
trailer [34233,34238]
trailer [34233,34238]
===
match
---
operator: = [12946,12947]
operator: = [12946,12947]
===
match
---
name: self [46203,46207]
name: self [46203,46207]
===
match
---
name: deserialize_model_file [67230,67252]
name: deserialize_model_file [67242,67264]
===
match
---
dotted_name [46548,46579]
dotted_name [46548,46579]
===
match
---
param [53431,53452]
param [53431,53452]
===
match
---
testlist [70551,70590]
testlist [70563,70602]
===
match
---
suite [78153,80848]
suite [78165,80860]
===
match
---
name: self [65943,65947]
name: self [65955,65959]
===
match
---
name: log [24691,24694]
name: log [24691,24694]
===
match
---
trailer [40840,40855]
trailer [40840,40855]
===
match
---
name: get_dagrun [27443,27453]
name: get_dagrun [27443,27453]
===
match
---
simple_stmt [74570,74813]
simple_stmt [74582,74825]
===
match
---
arglist [40417,40651]
arglist [40417,40651]
===
match
---
simple_stmt [9285,9385]
simple_stmt [9285,9385]
===
match
---
operator: , [76155,76156]
operator: , [76167,76168]
===
match
---
name: delete_qry [7472,7482]
name: delete_qry [7472,7482]
===
match
---
expr_stmt [20833,21117]
expr_stmt [20833,21117]
===
match
---
name: execution_date [77077,77091]
name: execution_date [77089,77103]
===
match
---
name: client [3016,3022]
name: client [3016,3022]
===
match
---
name: instance [30547,30555]
name: instance [30547,30555]
===
match
---
name: key [9636,9639]
name: key [9636,9639]
===
match
---
operator: , [48998,48999]
operator: , [48998,48999]
===
match
---
name: orm [1429,1432]
name: orm [1429,1432]
===
match
---
if_stmt [57570,58061]
if_stmt [57582,58073]
===
match
---
atom_expr [77211,77220]
atom_expr [77223,77232]
===
match
---
decorator [36479,36496]
decorator [36479,36496]
===
match
---
name: context [66364,66371]
name: context [66376,66383]
===
match
---
trailer [47656,47661]
trailer [47656,47661]
===
match
---
tfpdef [16615,16637]
tfpdef [16615,16637]
===
match
---
atom_expr [19994,20005]
atom_expr [19994,20005]
===
match
---
suite [75987,76079]
suite [75999,76091]
===
match
---
name: strftime [58095,58103]
name: strftime [58107,58115]
===
match
---
atom_expr [29671,29918]
atom_expr [29671,29918]
===
match
---
name: self [41219,41223]
name: self [41219,41223]
===
match
---
trailer [25392,25403]
trailer [25392,25403]
===
match
---
dotted_name [2516,2535]
dotted_name [2516,2535]
===
match
---
name: clear_task_instances [4669,4689]
name: clear_task_instances [4669,4689]
===
match
---
trailer [76591,76598]
trailer [76603,76610]
===
match
---
suite [75571,75944]
suite [75583,75956]
===
match
---
simple_stmt [1147,1161]
simple_stmt [1147,1161]
===
match
---
trailer [44160,44167]
trailer [44160,44167]
===
match
---
number: 1000 [10853,10857]
number: 1000 [10853,10857]
===
match
---
operator: , [80076,80077]
operator: , [80088,80089]
===
match
---
name: incr [44230,44234]
name: incr [44230,44234]
===
match
---
operator: , [66829,66830]
operator: , [66841,66842]
===
match
---
simple_stmt [8279,8573]
simple_stmt [8279,8573]
===
match
---
simple_stmt [26505,26522]
simple_stmt [26505,26522]
===
match
---
operator: , [56798,56799]
operator: , [56810,56811]
===
match
---
name: provide_session [75501,75516]
name: provide_session [75513,75528]
===
match
---
funcdef [31842,33185]
funcdef [31842,33185]
===
match
---
atom_expr [28228,28234]
atom_expr [28228,28234]
===
match
---
name: self [30643,30647]
name: self [30643,30647]
===
match
---
fstring_end: " [47671,47672]
fstring_end: " [47671,47672]
===
match
---
name: self [22257,22261]
name: self [22257,22261]
===
match
---
atom_expr [42712,42749]
atom_expr [42712,42749]
===
match
---
atom_expr [11086,11101]
atom_expr [11086,11101]
===
match
---
simple_stmt [30519,30580]
simple_stmt [30519,30580]
===
match
---
name: _state [79598,79604]
name: _state [79610,79616]
===
match
---
suite [7632,7672]
suite [7632,7672]
===
match
---
name: get [61598,61601]
name: get [61610,61613]
===
match
---
name: setattr [64704,64711]
name: setattr [64716,64723]
===
match
---
expr_stmt [68335,68675]
expr_stmt [68347,68687]
===
match
---
arglist [10570,10599]
arglist [10570,10599]
===
match
---
operator: , [38707,38708]
operator: , [38707,38708]
===
match
---
atom_expr [6088,6130]
atom_expr [6088,6130]
===
match
---
name: TR [3214,3216]
name: TR [3214,3216]
===
match
---
name: String [10943,10949]
name: String [10943,10949]
===
match
---
trailer [23190,23196]
trailer [23190,23196]
===
match
---
atom_expr [31766,31815]
atom_expr [31766,31815]
===
match
---
name: state [2929,2934]
name: state [2929,2934]
===
match
---
if_stmt [27413,28932]
if_stmt [27413,28932]
===
match
---
operator: , [16684,16685]
operator: , [16684,16685]
===
match
---
trailer [75387,75401]
trailer [75399,75413]
===
match
---
name: self [69635,69639]
name: self [69647,69651]
===
match
---
simple_stmt [4343,4385]
simple_stmt [4343,4385]
===
match
---
argument [11940,11959]
argument [11940,11959]
===
match
---
dotted_name [66554,66600]
dotted_name [66566,66612]
===
match
---
operator: = [66987,66988]
operator: = [66999,67000]
===
match
---
name: first [22505,22510]
name: first [22505,22510]
===
match
---
atom_expr [61545,61553]
atom_expr [61557,61565]
===
match
---
name: context [47952,47959]
name: context [47952,47959]
===
match
---
name: dep_status [33677,33687]
name: dep_status [33677,33687]
===
match
---
name: finished [25451,25459]
name: finished [25451,25459]
===
match
---
operator: = [48116,48117]
operator: = [48116,48117]
===
match
---
name: instance [59206,59214]
name: instance [59218,59226]
===
match
---
trailer [3707,3709]
trailer [3707,3709]
===
match
---
atom_expr [55150,55163]
atom_expr [55162,55175]
===
match
---
operator: = [46028,46029]
operator: = [46028,46029]
===
match
---
import_from [1018,1102]
import_from [1018,1102]
===
match
---
atom_expr [70321,70364]
atom_expr [70333,70376]
===
match
---
name: self [55132,55136]
name: self [55144,55148]
===
match
---
simple_stmt [23864,23903]
simple_stmt [23864,23903]
===
match
---
name: warnings [29671,29679]
name: warnings [29671,29679]
===
match
---
operator: , [75843,75844]
operator: , [75855,75856]
===
match
---
name: kubernetes [3069,3079]
name: kubernetes [3069,3079]
===
match
---
name: session [44153,44160]
name: session [44153,44160]
===
match
---
argument [72380,72387]
argument [72392,72399]
===
match
---
import_from [46543,46613]
import_from [46543,46613]
===
match
---
name: task [50900,50904]
name: task [50900,50904]
===
match
---
name: task [57212,57216]
name: task [57224,57228]
===
match
---
atom_expr [24145,24158]
atom_expr [24145,24158]
===
match
---
name: test_mode [46007,46016]
name: test_mode [46007,46016]
===
match
---
number: 1 [41576,41577]
number: 1 [41576,41577]
===
match
---
operator: = [10873,10874]
operator: = [10873,10874]
===
match
---
trailer [47103,47110]
trailer [47103,47110]
===
match
---
atom_expr [55364,55376]
atom_expr [55376,55388]
===
match
---
name: task [46677,46681]
name: task [46677,46681]
===
match
---
name: merge [44133,44138]
name: merge [44133,44138]
===
match
---
simple_stmt [14232,14257]
simple_stmt [14232,14257]
===
match
---
trailer [49231,49242]
trailer [49231,49242]
===
match
---
simple_stmt [26945,26991]
simple_stmt [26945,26991]
===
match
---
trailer [74591,74812]
trailer [74603,74824]
===
match
---
trailer [50186,50221]
trailer [50186,50221]
===
match
---
atom_expr [20940,20951]
atom_expr [20940,20951]
===
match
---
atom_expr [44153,44169]
atom_expr [44153,44169]
===
match
---
simple_stmt [44094,44117]
simple_stmt [44094,44117]
===
match
---
operator: , [1312,1313]
operator: , [1312,1313]
===
match
---
name: task [57581,57585]
name: task [57593,57597]
===
match
---
name: dispose [41925,41932]
name: dispose [41925,41932]
===
match
---
operator: , [55450,55451]
operator: , [55462,55463]
===
match
---
string: """Write error into error file by path""" [4343,4384]
string: """Write error into error file by path""" [4343,4384]
===
match
---
name: session [54228,54235]
name: session [54228,54235]
===
match
---
trailer [39500,39507]
trailer [39500,39507]
===
match
---
operator: -> [79086,79088]
operator: -> [79098,79100]
===
match
---
operator: { [55251,55252]
operator: { [55263,55264]
===
match
---
simple_stmt [31759,31816]
simple_stmt [31759,31816]
===
match
---
name: bool [56866,56870]
name: bool [56878,56882]
===
match
---
name: pod [67398,67401]
name: pod [67410,67413]
===
match
---
expr_stmt [28752,28818]
expr_stmt [28752,28818]
===
match
---
atom_expr [51269,51296]
atom_expr [51269,51296]
===
match
---
name: self [60586,60590]
name: self [60598,60602]
===
match
---
suite [48144,48230]
suite [48144,48230]
===
match
---
atom [65714,65754]
atom [65726,65766]
===
match
---
funcdef [9390,9613]
funcdef [9390,9613]
===
match
---
funcdef [79215,79289]
funcdef [79227,79301]
===
match
---
name: task [51406,51410]
name: task [51406,51410]
===
match
---
decorator [79055,79065]
decorator [79067,79077]
===
match
---
name: self [57061,57065]
name: self [57073,57077]
===
match
---
operator: ** [69472,69474]
operator: ** [69484,69486]
===
match
---
parameters [76120,76175]
parameters [76132,76187]
===
match
---
name: Optional [50624,50632]
name: Optional [50624,50632]
===
match
---
trailer [39883,39894]
trailer [39883,39894]
===
match
---
string: '' [56430,56432]
string: '' [56442,56444]
===
match
---
trailer [78907,78930]
trailer [78919,78942]
===
match
---
trailer [19310,19340]
trailer [19310,19340]
===
match
---
operator: = [80071,80072]
operator: = [80083,80084]
===
match
---
atom_expr [53237,53265]
atom_expr [53237,53265]
===
match
---
operator: ** [10433,10435]
operator: ** [10433,10435]
===
match
---
name: str [20530,20533]
name: str [20530,20533]
===
match
---
operator: = [53205,53206]
operator: = [53205,53206]
===
match
---
operator: , [47634,47635]
operator: , [47634,47635]
===
match
---
name: max_tries [22952,22961]
name: max_tries [22952,22961]
===
match
---
name: pool [43966,43970]
name: pool [43966,43970]
===
match
---
name: self [46672,46676]
name: self [46672,46676]
===
match
---
name: signal_handler [46950,46964]
name: signal_handler [46950,46964]
===
match
---
trailer [41084,41095]
trailer [41084,41095]
===
match
---
name: html_content [70560,70572]
name: html_content [70572,70584]
===
match
---
parameters [61318,61382]
parameters [61330,61394]
===
match
---
atom_expr [72160,72348]
atom_expr [72172,72360]
===
match
---
dotted_name [3334,3359]
dotted_name [3334,3359]
===
match
---
name: session [38471,38478]
name: session [38471,38478]
===
match
---
operator: , [36672,36673]
operator: , [36672,36673]
===
match
---
param [35753,35757]
param [35753,35757]
===
match
---
simple_stmt [36067,36204]
simple_stmt [36067,36204]
===
match
---
name: subject [70551,70558]
name: subject [70563,70570]
===
match
---
string: """Get Airflow Connection value""" [62437,62471]
string: """Get Airflow Connection value""" [62449,62483]
===
match
---
suite [7500,7672]
suite [7500,7672]
===
match
---
atom_expr [66069,66156]
atom_expr [66081,66168]
===
match
---
testlist_comp [19500,19514]
testlist_comp [19500,19514]
===
match
---
trailer [41628,41654]
trailer [41628,41654]
===
match
---
trailer [59087,59096]
trailer [59099,59108]
===
match
---
simple_stmt [11068,11102]
simple_stmt [11068,11102]
===
match
---
param [33239,33244]
param [33239,33244]
===
match
---
trailer [48889,48902]
trailer [48889,48902]
===
match
---
atom_expr [44105,44116]
atom_expr [44105,44116]
===
match
---
atom_expr [63109,63121]
atom_expr [63121,63133]
===
match
---
fstring [47662,47672]
fstring [47662,47672]
===
match
---
arglist [11791,11810]
arglist [11791,11810]
===
match
---
comparison [3721,3746]
comparison [3721,3746]
===
match
---
argument [74733,74772]
argument [74745,74784]
===
match
---
tfpdef [16764,16788]
tfpdef [16764,16788]
===
match
---
name: file_path [19578,19587]
name: file_path [19578,19587]
===
match
---
suite [71154,71188]
suite [71166,71200]
===
match
---
operator: = [61878,61879]
operator: = [61890,61891]
===
match
---
name: exception_html [67736,67750]
name: exception_html [67748,67762]
===
match
---
simple_stmt [45058,45134]
simple_stmt [45058,45134]
===
match
---
name: iso [20356,20359]
name: iso [20356,20359]
===
match
---
name: get [62332,62335]
name: get [62344,62347]
===
match
---
atom_expr [31035,31085]
atom_expr [31035,31085]
===
match
---
return_stmt [60644,60664]
return_stmt [60656,60676]
===
match
---
atom_expr [66909,66931]
atom_expr [66921,66943]
===
match
---
trailer [25529,25538]
trailer [25529,25538]
===
match
---
operator: , [70616,70617]
operator: , [70628,70629]
===
match
---
atom_expr [33636,33655]
atom_expr [33636,33655]
===
match
---
argument [52723,52748]
argument [52723,52748]
===
match
---
name: Exception [45936,45945]
name: Exception [45936,45945]
===
match
---
atom_expr [81051,81071]
atom_expr [81063,81083]
===
match
---
trailer [58158,58160]
trailer [58170,58172]
===
match
---
name: conf [66051,66055]
name: conf [66063,66067]
===
match
---
atom_expr [31302,31329]
atom_expr [31302,31329]
===
match
---
trailer [78308,78316]
trailer [78320,78328]
===
match
---
suite [48533,48684]
suite [48533,48684]
===
match
---
argument [39432,39447]
argument [39432,39447]
===
match
---
operator: { [47112,47113]
operator: { [47112,47113]
===
match
---
name: self [24564,24568]
name: self [24564,24568]
===
match
---
simple_stmt [25272,25335]
simple_stmt [25272,25335]
===
match
---
name: SUCCESS [44540,44547]
name: SUCCESS [44540,44547]
===
match
---
atom_expr [11729,11775]
atom_expr [11729,11775]
===
match
---
name: first [76553,76558]
name: first [76565,76570]
===
match
---
param [67473,67482]
param [67485,67494]
===
match
---
simple_stmt [23274,23302]
simple_stmt [23274,23302]
===
match
---
import_name [787,804]
import_name [787,804]
===
match
---
name: jinja2 [69184,69190]
name: jinja2 [69196,69202]
===
match
---
name: timezone [39897,39905]
name: timezone [39897,39905]
===
match
---
trailer [64554,64560]
trailer [64566,64572]
===
match
---
simple_stmt [46376,46396]
simple_stmt [46376,46396]
===
match
---
funcdef [46427,49041]
funcdef [46427,49041]
===
match
---
atom_expr [8698,8710]
atom_expr [8698,8710]
===
match
---
trailer [58148,58158]
trailer [58160,58170]
===
match
---
trailer [49932,49940]
trailer [49932,49940]
===
match
---
simple_stmt [55284,55310]
simple_stmt [55296,55322]
===
match
---
expr_stmt [12683,12759]
expr_stmt [12683,12759]
===
match
---
name: self [51132,51136]
name: self [51132,51136]
===
match
---
name: value [75205,75210]
name: value [75217,75222]
===
match
---
atom_expr [33107,33164]
atom_expr [33107,33164]
===
match
---
name: self [78342,78346]
name: self [78354,78358]
===
match
---
comparison [50140,50158]
comparison [50140,50158]
===
match
---
operator: = [11197,11198]
operator: = [11197,11198]
===
match
---
simple_stmt [14139,14167]
simple_stmt [14139,14167]
===
match
---
import_from [2554,2600]
import_from [2554,2600]
===
match
---
tfpdef [36868,36887]
tfpdef [36868,36887]
===
match
---
name: dag [57854,57857]
name: dag [57866,57869]
===
match
---
operator: , [71344,71345]
operator: , [71356,71357]
===
match
---
name: generate_command [15829,15845]
name: generate_command [15829,15845]
===
match
---
simple_stmt [61811,61885]
simple_stmt [61823,61897]
===
match
---
name: task_id [47123,47130]
name: task_id [47123,47130]
===
match
---
operator: = [57880,57881]
operator: = [57892,57893]
===
match
---
import_from [1579,1832]
import_from [1579,1832]
===
match
---
sync_comp_for [77144,77156]
sync_comp_for [77156,77168]
===
match
---
simple_stmt [3234,3259]
simple_stmt [3234,3259]
===
match
---
atom_expr [41491,41505]
atom_expr [41491,41505]
===
match
---
comp_op [50957,50963]
comp_op [50957,50963]
===
match
---
atom_expr [51589,51620]
atom_expr [51589,51620]
===
match
---
atom_expr [56127,56154]
atom_expr [56139,56166]
===
match
---
atom_expr [33450,33498]
atom_expr [33450,33498]
===
match
---
trailer [28191,28195]
trailer [28191,28195]
===
match
---
operator: = [71422,71423]
operator: = [71434,71435]
===
match
---
name: cfg_path [16335,16343]
name: cfg_path [16335,16343]
===
match
---
operator: , [7867,7868]
operator: , [7867,7868]
===
match
---
funcdef [14276,14813]
funcdef [14276,14813]
===
match
---
trailer [31794,31815]
trailer [31794,31815]
===
match
---
atom_expr [10808,10823]
atom_expr [10808,10823]
===
match
---
comparison [75755,75789]
comparison [75767,75801]
===
match
---
trailer [50122,50135]
trailer [50122,50135]
===
match
---
atom_expr [79518,79534]
atom_expr [79530,79546]
===
match
---
trailer [36347,36423]
trailer [36347,36423]
===
match
---
trailer [40399,40665]
trailer [40399,40665]
===
match
---
name: Column [11324,11330]
name: Column [11324,11330]
===
match
---
operator: , [53429,53430]
operator: , [53429,53430]
===
match
---
if_stmt [52529,52606]
if_stmt [52529,52606]
===
match
---
simple_stmt [12230,12259]
simple_stmt [12230,12259]
===
match
---
trailer [75767,75774]
trailer [75779,75786]
===
match
---
name: replace [59146,59153]
name: replace [59158,59165]
===
match
---
simple_stmt [44638,44645]
simple_stmt [44638,44645]
===
match
---
fstring_string: .duration [47131,47140]
fstring_string: .duration [47131,47140]
===
match
---
trailer [12252,12258]
trailer [12252,12258]
===
match
---
name: var [61481,61484]
name: var [61493,61496]
===
match
---
operator: , [77403,77404]
operator: , [77415,77416]
===
match
---
name: timeout [2982,2989]
name: timeout [2982,2989]
===
match
---
string: """Get failed Dependencies""" [33286,33315]
string: """Get failed Dependencies""" [33286,33315]
===
match
---
return_stmt [76970,77172]
return_stmt [76982,77184]
===
match
---
funcdef [79141,79196]
funcdef [79153,79208]
===
match
---
argument [40736,40751]
argument [40736,40751]
===
match
---
simple_stmt [64342,64387]
simple_stmt [64354,64399]
===
match
---
trailer [6291,6306]
trailer [6291,6306]
===
match
---
param [36567,36588]
param [36567,36588]
===
match
---
trailer [63353,63446]
trailer [63365,63458]
===
match
---
trailer [55225,55230]
trailer [55237,55242]
===
match
---
simple_stmt [78768,78803]
simple_stmt [78780,78815]
===
match
---
operator: == [20990,20992]
operator: == [20990,20992]
===
match
---
simple_stmt [66685,67295]
simple_stmt [66697,67307]
===
match
---
name: filter_for_tis [76106,76120]
name: filter_for_tis [76118,76132]
===
match
---
atom_expr [56272,56282]
atom_expr [56284,56294]
===
match
---
operator: = [16748,16749]
operator: = [16748,16749]
===
match
---
operator: == [24561,24563]
operator: == [24561,24563]
===
match
---
name: use_default [68688,68699]
name: use_default [68700,68711]
===
match
---
param [72748,72775]
param [72760,72787]
===
match
---
operator: , [61860,61861]
operator: , [61872,61873]
===
match
---
name: test_mode [63771,63780]
name: test_mode [63783,63792]
===
match
---
atom_expr [42334,42366]
atom_expr [42334,42366]
===
match
---
name: ready_for_retry [25946,25961]
name: ready_for_retry [25946,25961]
===
match
---
name: TR [7408,7410]
name: TR [7408,7410]
===
match
---
suite [8195,8270]
suite [8195,8270]
===
match
---
trailer [75924,75931]
trailer [75936,75943]
===
match
---
operator: , [56934,56935]
operator: , [56946,56947]
===
match
---
trailer [60552,60556]
trailer [60564,60568]
===
match
---
name: task_tries [7151,7161]
name: task_tries [7151,7161]
===
match
---
trailer [59372,59384]
trailer [59384,59396]
===
match
---
expr_stmt [22634,22661]
expr_stmt [22634,22661]
===
match
---
name: execution_date [26818,26832]
name: execution_date [26818,26832]
===
match
---
name: executor_namespace [67169,67187]
name: executor_namespace [67181,67199]
===
match
---
trailer [69065,69076]
trailer [69077,69088]
===
match
---
string: '' [42382,42384]
string: '' [42382,42384]
===
match
---
arglist [41633,41652]
arglist [41633,41652]
===
match
---
operator: , [1398,1399]
operator: , [1398,1399]
===
match
---
name: provide_session [20469,20484]
name: provide_session [20469,20484]
===
match
---
trailer [30546,30555]
trailer [30546,30555]
===
match
---
name: bool [51919,51923]
name: bool [51919,51923]
===
match
---
expr_stmt [70697,70780]
expr_stmt [70709,70792]
===
match
---
name: datetime [79415,79423]
name: datetime [79427,79435]
===
match
---
and_test [28593,28636]
and_test [28593,28636]
===
match
---
trailer [59096,59108]
trailer [59108,59120]
===
match
---
if_stmt [34226,35691]
if_stmt [34226,35691]
===
match
---
string: "&upstream=false" [20374,20391]
string: "&upstream=false" [20374,20391]
===
match
---
trailer [52691,52705]
trailer [52691,52705]
===
match
---
param [9640,9644]
param [9640,9644]
===
match
---
operator: , [33243,33244]
operator: , [33243,33244]
===
match
---
name: XCom [75186,75190]
name: XCom [75198,75202]
===
match
---
trailer [29679,29684]
trailer [29679,29684]
===
match
---
operator: @ [42879,42880]
operator: @ [42879,42880]
===
match
---
simple_stmt [76577,76599]
simple_stmt [76589,76611]
===
match
---
arglist [43946,43970]
arglist [43946,43970]
===
match
---
decorated [14262,14813]
decorated [14262,14813]
===
match
---
name: all [21102,21105]
name: all [21102,21105]
===
match
---
name: are_dependencies_met [40690,40710]
name: are_dependencies_met [40690,40710]
===
match
---
name: get_previous_dagrun [28769,28788]
name: get_previous_dagrun [28769,28788]
===
match
---
trailer [3248,3258]
trailer [3248,3258]
===
match
---
name: __table_args__ [11497,11511]
name: __table_args__ [11497,11511]
===
match
---
operator: , [47526,47527]
operator: , [47526,47527]
===
match
---
operator: = [69013,69014]
operator: = [69025,69026]
===
match
---
testlist_comp [18831,18878]
testlist_comp [18831,18878]
===
match
---
name: XCom [75200,75204]
name: XCom [75212,75216]
===
match
---
atom_expr [46088,46154]
atom_expr [46088,46154]
===
match
---
arglist [60916,60945]
arglist [60928,60957]
===
match
---
atom_expr [46405,46421]
atom_expr [46405,46421]
===
match
---
operator: { [33942,33943]
operator: { [33942,33943]
===
match
---
operator: = [66737,66738]
operator: = [66749,66750]
===
match
---
funcdef [71279,72585]
funcdef [71291,72597]
===
match
---
operator: , [71395,71396]
operator: , [71407,71408]
===
match
---
comparison [76908,76942]
comparison [76920,76954]
===
match
---
name: self [12646,12650]
name: self [12646,12650]
===
match
---
atom_expr [8488,8511]
atom_expr [8488,8511]
===
match
---
operator: , [75896,75897]
operator: , [75908,75909]
===
match
---
if_stmt [50929,51119]
if_stmt [50929,51119]
===
match
---
name: logging [12279,12286]
name: logging [12279,12286]
===
match
---
comparison [25431,25459]
comparison [25431,25459]
===
match
---
funcdef [61594,61885]
funcdef [61606,61897]
===
match
---
name: next_execution_date [63065,63084]
name: next_execution_date [63077,63096]
===
match
---
operator: = [43073,43074]
operator: = [43073,43074]
===
match
---
name: renderedtifields [64415,64431]
name: renderedtifields [64427,64443]
===
match
---
expr_stmt [58889,58959]
expr_stmt [58901,58971]
===
match
---
arith_expr [5718,5750]
arith_expr [5718,5750]
===
match
---
suite [41744,41777]
suite [41744,41777]
===
match
---
return_stmt [75669,75943]
return_stmt [75681,75955]
===
match
---
atom_expr [5718,5731]
atom_expr [5718,5731]
===
match
---
fstring_string: ti.start. [44237,44246]
fstring_string: ti.start. [44237,44246]
===
match
---
name: self [15480,15484]
name: self [15480,15484]
===
match
---
name: rendered_task_instance_fields [64475,64504]
name: rendered_task_instance_fields [64487,64516]
===
match
---
simple_stmt [6177,6208]
simple_stmt [6177,6208]
===
match
---
operator: = [52022,52023]
operator: = [52022,52023]
===
match
---
expr_stmt [58992,59013]
expr_stmt [59004,59025]
===
match
---
name: execution_date [77375,77389]
name: execution_date [77387,77401]
===
match
---
and_test [8013,8047]
and_test [8013,8047]
===
match
---
arglist [56979,57051]
arglist [56991,57063]
===
match
---
operator: , [42841,42842]
operator: , [42841,42842]
===
match
---
dotted_name [2439,2460]
dotted_name [2439,2460]
===
match
---
operator: = [28796,28797]
operator: = [28796,28797]
===
match
---
name: ignore_all_deps [51708,51723]
name: ignore_all_deps [51708,51723]
===
match
---
name: get_dep_statuses [33454,33470]
name: get_dep_statuses [33454,33470]
===
match
---
fstring_string: dag. [47089,47093]
fstring_string: dag. [47089,47093]
===
match
---
argument [40040,40055]
argument [40040,40055]
===
match
---
trailer [58189,58204]
trailer [58201,58216]
===
match
---
argument [46018,46039]
argument [46018,46039]
===
match
---
name: session [39493,39500]
name: session [39493,39500]
===
match
---
arglist [39391,39461]
arglist [39391,39461]
===
match
---
simple_stmt [79261,79289]
simple_stmt [79273,79301]
===
match
---
atom_expr [28174,28195]
atom_expr [28174,28195]
===
match
---
trailer [38411,38421]
trailer [38411,38421]
===
match
---
name: deps [40417,40421]
name: deps [40417,40421]
===
match
---
if_stmt [15556,15800]
if_stmt [15556,15800]
===
match
---
name: filepath [15609,15617]
name: filepath [15609,15617]
===
match
---
trailer [67065,67087]
trailer [67077,67099]
===
match
---
exprlist [7336,7349]
exprlist [7336,7349]
===
match
---
string: '%Y-%m-%d' [59373,59383]
string: '%Y-%m-%d' [59385,59395]
===
match
---
simple_stmt [43168,43855]
simple_stmt [43168,43855]
===
match
---
atom_expr [47241,47300]
atom_expr [47241,47300]
===
match
---
name: session [30678,30685]
name: session [30678,30685]
===
match
---
name: execution_date [18789,18803]
name: execution_date [18789,18803]
===
match
---
name: replace [59785,59792]
name: replace [59797,59804]
===
match
---
trailer [26542,26562]
trailer [26542,26562]
===
match
---
operator: , [11344,11345]
operator: , [11344,11345]
===
match
---
operator: } [20359,20360]
operator: } [20359,20360]
===
match
---
decorated [29981,30580]
decorated [29981,30580]
===
match
---
trailer [51504,51525]
trailer [51504,51525]
===
match
---
name: refresh_from_task [43928,43945]
name: refresh_from_task [43928,43945]
===
match
---
exprlist [8471,8484]
exprlist [8471,8484]
===
match
---
name: from_string [70253,70264]
name: from_string [70265,70276]
===
match
---
argument [16203,16222]
argument [16203,16222]
===
match
---
simple_stmt [19545,19567]
simple_stmt [19545,19567]
===
match
---
if_stmt [57607,57674]
if_stmt [57619,57686]
===
match
---
simple_stmt [10796,10824]
simple_stmt [10796,10824]
===
match
---
suite [5377,5462]
suite [5377,5462]
===
match
---
atom_expr [80880,80908]
atom_expr [80892,80920]
===
match
---
name: make_aware [12709,12719]
name: make_aware [12709,12719]
===
match
---
name: dag_id [77874,77880]
name: dag_id [77886,77892]
===
match
---
string: "--pool" [19500,19508]
string: "--pool" [19500,19508]
===
match
---
simple_stmt [19601,19637]
simple_stmt [19601,19637]
===
match
---
name: format [72291,72297]
name: format [72303,72309]
===
match
---
simple_stmt [78677,78717]
simple_stmt [78689,78729]
===
match
---
simple_stmt [20833,21118]
simple_stmt [20833,21118]
===
match
---
trailer [53064,53066]
trailer [53064,53066]
===
match
---
operator: } [33939,33940]
operator: } [33939,33940]
===
match
---
name: end_date [10642,10650]
name: end_date [10642,10650]
===
match
---
atom_expr [78677,78694]
atom_expr [78689,78706]
===
match
---
import_name [1161,1185]
import_name [1161,1185]
===
match
---
trailer [14800,14812]
trailer [14800,14812]
===
match
---
string: "--job-id" [19066,19076]
string: "--job-id" [19066,19076]
===
match
---
atom_expr [54228,54244]
atom_expr [54228,54244]
===
match
---
name: pre_execute [47845,47856]
name: pre_execute [47845,47856]
===
match
---
name: iso [19811,19814]
name: iso [19811,19814]
===
match
---
trailer [35501,35515]
trailer [35501,35515]
===
match
---
parameters [75969,75986]
parameters [75981,75998]
===
match
---
operator: , [41489,41490]
operator: , [41489,41490]
===
match
---
operator: , [42060,42061]
operator: , [42060,42061]
===
match
---
and_test [66031,66055]
and_test [66043,66067]
===
match
---
name: tuple_ [77854,77860]
name: tuple_ [77866,77872]
===
match
---
name: qry [22501,22504]
name: qry [22501,22504]
===
match
---
atom_expr [6073,6085]
atom_expr [6073,6085]
===
match
---
operator: = [30458,30459]
operator: = [30458,30459]
===
match
---
name: self [24686,24690]
name: self [24686,24690]
===
match
---
name: dag_id [77307,77313]
name: dag_id [77319,77325]
===
match
---
name: int [78557,78560]
name: int [78569,78572]
===
match
---
operator: + [42503,42504]
operator: + [42503,42504]
===
match
---
operator: { [64029,64030]
operator: { [64041,64042]
===
match
---
name: execution_date [36385,36399]
name: execution_date [36385,36399]
===
match
---
name: SUCCESS [63577,63584]
name: SUCCESS [63589,63596]
===
match
---
trailer [31508,31750]
trailer [31508,31750]
===
match
---
name: _task_id [80626,80634]
name: _task_id [80638,80646]
===
match
---
name: verbose [36567,36574]
name: verbose [36567,36574]
===
match
---
atom_expr [79043,79049]
atom_expr [79055,79061]
===
match
---
string: 'next_execution_date' [63042,63063]
string: 'next_execution_date' [63054,63075]
===
match
---
operator: , [67780,67781]
operator: , [67792,67793]
===
match
---
suite [79093,79122]
suite [79105,79134]
===
match
---
string: """         Construct a TaskInstance from the database based on the primary key          :param session: DB session.         :param lock_for_update: if True, indicates that the database should             lock the TaskInstance (issuing a FOR UPDATE clause) until the             session is committed.         :return: the task instance constructed         """ [80126,80485]
string: """         Construct a TaskInstance from the database based on the primary key          :param session: DB session.         :param lock_for_update: if True, indicates that the database should             lock the TaskInstance (issuing a FOR UPDATE clause) until the             session is committed.         :return: the task instance constructed         """ [80138,80497]
===
match
---
suite [78295,79050]
suite [78307,79062]
===
match
---
arith_expr [35706,35727]
arith_expr [35706,35727]
===
match
---
name: html_content_err [70574,70590]
name: html_content_err [70586,70602]
===
match
---
fstring_expr [44246,44259]
fstring_expr [44246,44259]
===
match
---
name: models [81018,81024]
name: models [81030,81036]
===
match
---
atom_expr [46329,46363]
atom_expr [46329,46363]
===
match
---
name: self [66831,66835]
name: self [66843,66847]
===
match
---
trailer [55494,55503]
trailer [55506,55515]
===
match
---
name: LoggingMixin [2645,2657]
name: LoggingMixin [2645,2657]
===
match
---
tfpdef [51708,51729]
tfpdef [51708,51729]
===
match
---
name: Column [10653,10659]
name: Column [10653,10659]
===
match
---
trailer [13023,13025]
trailer [13023,13025]
===
match
---
string: """         Based on this instance's try_number, this will calculate         the number of previously attempted tries, defaulting to 0.         """ [14316,14463]
string: """         Based on this instance's try_number, this will calculate         the number of previously attempted tries, defaulting to 0.         """ [14316,14463]
===
match
---
with_stmt [48728,48827]
with_stmt [48728,48827]
===
match
---
simple_stmt [59752,59802]
simple_stmt [59764,59814]
===
match
---
name: execution_date [11697,11711]
name: execution_date [11697,11711]
===
match
---
simple_stmt [75459,75495]
simple_stmt [75471,75507]
===
match
---
trailer [41435,41439]
trailer [41435,41439]
===
match
---
name: session [2830,2837]
name: session [2830,2837]
===
match
---
parameters [24983,25015]
parameters [24983,25015]
===
match
---
name: ti [23333,23335]
name: ti [23333,23335]
===
match
---
atom_expr [19545,19566]
atom_expr [19545,19566]
===
match
---
name: all [8557,8560]
name: all [8557,8560]
===
match
---
arglist [32886,33038]
arglist [32886,33038]
===
match
---
name: var [60660,60663]
name: var [60672,60675]
===
match
---
name: self [25600,25604]
name: self [25600,25604]
===
match
---
simple_stmt [5394,5420]
simple_stmt [5394,5420]
===
match
---
argument [44487,44507]
argument [44487,44507]
===
match
---
string: "--subdir" [19613,19623]
string: "--subdir" [19613,19623]
===
match
---
trailer [24617,24632]
trailer [24617,24632]
===
match
---
atom_expr [21538,21550]
atom_expr [21538,21550]
===
match
---
trailer [55136,55141]
trailer [55148,55153]
===
match
---
argument [68999,69028]
argument [69011,69040]
===
match
---
name: error [21470,21475]
name: error [21470,21475]
===
match
---
atom_expr [25567,25580]
atom_expr [25567,25580]
===
match
---
name: SUCCESS [45760,45767]
name: SUCCESS [45760,45767]
===
match
---
suite [49906,49965]
suite [49906,49965]
===
match
---
operator: = [53112,53113]
operator: = [53112,53113]
===
match
---
trailer [24690,24694]
trailer [24690,24694]
===
match
---
name: file_path [16764,16773]
name: file_path [16764,16773]
===
match
---
atom_expr [6810,7385]
atom_expr [6810,7385]
===
match
---
simple_stmt [12683,12760]
simple_stmt [12683,12760]
===
match
---
name: self [58129,58133]
name: self [58141,58145]
===
match
---
name: String [10418,10424]
name: String [10418,10424]
===
match
---
operator: = [11261,11262]
operator: = [11261,11262]
===
match
---
argument [69884,69908]
argument [69896,69920]
===
match
---
name: State [54019,54024]
name: State [54019,54024]
===
match
---
operator: = [39239,39240]
operator: = [39239,39240]
===
match
---
operator: = [51267,51268]
operator: = [51267,51268]
===
match
---
not_test [66339,66350]
not_test [66351,66362]
===
match
---
string: 'ts_nodash_with_tz' [63970,63989]
string: 'ts_nodash_with_tz' [63982,64001]
===
match
---
trailer [47745,47753]
trailer [47745,47753]
===
match
---
funcdef [76102,77999]
funcdef [76114,78011]
===
match
---
simple_stmt [50986,51024]
simple_stmt [50986,51024]
===
match
---
operator: , [32943,32944]
operator: , [32943,32944]
===
match
---
simple_stmt [2861,2910]
simple_stmt [2861,2910]
===
match
---
expr_stmt [61400,61452]
expr_stmt [61412,61464]
===
match
---
trailer [19057,19064]
trailer [19057,19064]
===
match
---
suite [9812,77999]
suite [9812,78011]
===
match
---
name: with_entities [75388,75401]
name: with_entities [75400,75413]
===
match
---
trailer [74582,74591]
trailer [74594,74603]
===
match
---
expr_stmt [39007,39328]
expr_stmt [39007,39328]
===
match
---
param [79323,79327]
param [79335,79339]
===
match
---
name: e [45861,45862]
name: e [45861,45862]
===
match
---
name: queued_dttm [41224,41235]
name: queued_dttm [41224,41235]
===
match
---
name: pid [11219,11222]
name: pid [11219,11222]
===
match
---
name: refresh_from_db [45028,45043]
name: refresh_from_db [45028,45043]
===
match
---
param [62195,62205]
param [62207,62217]
===
match
---
trailer [22467,22469]
trailer [22467,22469]
===
match
---
expr_stmt [20100,20144]
expr_stmt [20100,20144]
===
match
---
simple_stmt [22496,22513]
simple_stmt [22496,22513]
===
match
---
name: UndefinedError [64866,64880]
name: UndefinedError [64878,64892]
===
match
---
atom_expr [32696,32710]
atom_expr [32696,32710]
===
match
---
comparison [77486,77531]
comparison [77498,77543]
===
match
---
simple_stmt [52083,52521]
simple_stmt [52083,52521]
===
match
---
name: task [59882,59886]
name: task [59894,59898]
===
match
---
name: end_date [53889,53897]
name: end_date [53889,53897]
===
match
---
name: prev_execution_date [59301,59320]
name: prev_execution_date [59313,59332]
===
match
---
fstring_start: f" [65800,65802]
fstring_start: f" [65812,65814]
===
match
---
name: datetime [78404,78412]
name: datetime [78416,78424]
===
match
---
operator: = [44008,44009]
operator: = [44008,44009]
===
match
---
atom_expr [12811,12846]
atom_expr [12811,12846]
===
match
---
arglist [33553,33734]
arglist [33553,33734]
===
match
---
name: key [24745,24748]
name: key [24745,24748]
===
match
---
simple_stmt [36464,36474]
simple_stmt [36464,36474]
===
match
---
simple_stmt [59121,59163]
simple_stmt [59133,59175]
===
match
---
simple_stmt [51085,51119]
simple_stmt [51085,51119]
===
match
---
strings [72188,72290]
strings [72200,72302]
===
match
---
name: Column [10875,10881]
name: Column [10875,10881]
===
match
---
name: error [54879,54884]
name: error [54891,54896]
===
match
---
trailer [23157,23168]
trailer [23157,23168]
===
match
---
operator: = [58909,58910]
operator: = [58921,58922]
===
match
---
trailer [3601,3608]
trailer [3601,3608]
===
match
---
atom_expr [66491,66505]
atom_expr [66503,66517]
===
match
---
name: duration [71172,71180]
name: duration [71184,71192]
===
match
---
simple_stmt [10605,10638]
simple_stmt [10605,10638]
===
match
---
atom_expr [5674,5686]
atom_expr [5674,5686]
===
match
---
simple_stmt [21145,21165]
simple_stmt [21145,21165]
===
match
---
argument [77573,77806]
argument [77585,77818]
===
match
---
name: subject [70311,70318]
name: subject [70323,70330]
===
match
---
operator: = [29960,29961]
operator: = [29960,29961]
===
match
---
atom_expr [75704,75716]
atom_expr [75716,75728]
===
match
---
name: Variable [61411,61419]
name: Variable [61423,61431]
===
match
---
atom_expr [77552,77820]
atom_expr [77564,77832]
===
match
---
expr_stmt [6797,7385]
expr_stmt [6797,7385]
===
match
---
import_name [805,819]
import_name [805,819]
===
match
---
name: test_mode [38424,38433]
name: test_mode [38424,38433]
===
match
---
operator: == [77442,77444]
operator: == [77454,77456]
===
match
---
expr_stmt [40121,40165]
expr_stmt [40121,40165]
===
match
---
name: RenderedTaskInstanceFields [47208,47234]
name: RenderedTaskInstanceFields [47208,47234]
===
match
---
trailer [45743,45749]
trailer [45743,45749]
===
match
---
operator: = [52735,52736]
operator: = [52735,52736]
===
match
---
operator: = [43903,43904]
operator: = [43903,43904]
===
match
---
atom_expr [70392,70445]
atom_expr [70404,70457]
===
match
---
atom_expr [66804,66844]
atom_expr [66816,66856]
===
match
---
suite [52043,53120]
suite [52043,53120]
===
match
---
expr_stmt [23864,23902]
expr_stmt [23864,23902]
===
match
---
return_stmt [79975,80003]
return_stmt [79987,80015]
===
match
---
name: self [20311,20315]
name: self [20311,20315]
===
match
---
operator: = [4101,4102]
operator: = [4101,4102]
===
match
---
name: task [59827,59831]
name: task [59839,59843]
===
match
---
operator: = [8148,8149]
operator: = [8148,8149]
===
match
---
name: task [26965,26969]
name: task [26965,26969]
===
match
---
simple_stmt [21461,21517]
simple_stmt [21461,21517]
===
match
---
atom_expr [67217,67283]
atom_expr [67229,67295]
===
match
---
trailer [53346,53354]
trailer [53346,53354]
===
match
---
name: variable [2100,2108]
name: variable [2100,2108]
===
match
---
simple_stmt [47835,47874]
simple_stmt [47835,47874]
===
match
---
simple_stmt [12794,12847]
simple_stmt [12794,12847]
===
match
---
atom_expr [20917,20936]
atom_expr [20917,20936]
===
match
---
trailer [77742,77757]
trailer [77754,77769]
===
match
---
trailer [40056,40062]
trailer [40056,40062]
===
match
---
trailer [9557,9564]
trailer [9557,9564]
===
match
---
tfpdef [36033,36049]
tfpdef [36033,36049]
===
match
---
string: '' [13099,13101]
string: '' [13099,13101]
===
match
---
operator: = [80093,80094]
operator: = [80105,80106]
===
match
---
name: mark_success [52723,52735]
name: mark_success [52723,52735]
===
match
---
atom_expr [8645,8658]
atom_expr [8645,8658]
===
match
---
name: FAILED [55370,55376]
name: FAILED [55382,55388]
===
match
---
trailer [10489,10541]
trailer [10489,10541]
===
match
---
name: session [46329,46336]
name: session [46329,46336]
===
match
---
trailer [63423,63431]
trailer [63435,63443]
===
match
---
argument [77188,77250]
argument [77200,77262]
===
match
---
name: base_url [19864,19872]
name: base_url [19864,19872]
===
match
---
atom [18928,18946]
atom [18928,18946]
===
match
---
string: """Returns a tuple that identifies the task instance uniquely""" [24783,24847]
string: """Returns a tuple that identifies the task instance uniquely""" [24783,24847]
===
match
---
name: DagRun [57807,57813]
name: DagRun [57819,57825]
===
match
---
atom_expr [26743,26767]
atom_expr [26743,26767]
===
match
---
annassign [78596,78612]
annassign [78608,78624]
===
match
---
name: State [25445,25450]
name: State [25445,25450]
===
match
---
atom_expr [30656,30669]
atom_expr [30656,30669]
===
match
---
expr_stmt [12860,12916]
expr_stmt [12860,12916]
===
match
---
trailer [24694,24700]
trailer [24694,24700]
===
match
---
expr_stmt [5394,5419]
expr_stmt [5394,5419]
===
match
---
comparison [57229,57262]
comparison [57241,57274]
===
match
---
operator: = [78468,78469]
operator: = [78480,78481]
===
match
---
name: context [51490,51497]
name: context [51490,51497]
===
match
---
atom_expr [60903,60946]
atom_expr [60915,60958]
===
match
---
if_stmt [28832,28932]
if_stmt [28832,28932]
===
match
---
simple_stmt [75321,75349]
simple_stmt [75333,75361]
===
match
---
trailer [56598,56641]
trailer [56610,56653]
===
match
---
operator: , [70921,70922]
operator: , [70933,70934]
===
match
---
operator: , [41646,41647]
operator: , [41646,41647]
===
match
---
operator: = [76487,76488]
operator: = [76499,76500]
===
match
---
name: _key [79036,79040]
name: _key [79048,79052]
===
match
---
operator: } [33917,33918]
operator: } [33917,33918]
===
match
---
name: error_file [46029,46039]
name: error_file [46029,46039]
===
match
---
string: "started running, please use 'airflow tasks render' for debugging the " [65131,65202]
string: "started running, please use 'airflow tasks render' for debugging the " [65143,65214]
===
match
---
name: str [30073,30076]
name: str [30073,30076]
===
match
---
name: seconds [35553,35560]
name: seconds [35553,35560]
===
match
---
simple_stmt [10900,10925]
simple_stmt [10900,10925]
===
match
---
name: result [50140,50146]
name: result [50140,50146]
===
match
---
trailer [79444,79454]
trailer [79456,79466]
===
match
---
name: error [52963,52968]
name: error [52963,52968]
===
match
---
operator: , [47959,47960]
operator: , [47959,47960]
===
match
---
atom_expr [79721,79734]
atom_expr [79733,79746]
===
match
---
trailer [71096,71105]
trailer [71108,71117]
===
match
---
name: self [36553,36557]
name: self [36553,36557]
===
match
---
simple_stmt [29151,29399]
simple_stmt [29151,29399]
===
match
---
atom_expr [19601,19636]
atom_expr [19601,19636]
===
match
---
name: in_ [26739,26742]
name: in_ [26739,26742]
===
match
---
trailer [38446,38462]
trailer [38446,38462]
===
match
---
name: self [27046,27050]
name: self [27046,27050]
===
match
---
argument [67101,67133]
argument [67113,67145]
===
match
---
atom_expr [43023,43036]
atom_expr [43023,43036]
===
match
---
trailer [27122,27138]
trailer [27122,27138]
===
match
---
name: self [46390,46394]
name: self [46390,46394]
===
match
---
atom_expr [77573,77776]
atom_expr [77585,77788]
===
match
---
trailer [26864,26868]
trailer [26864,26868]
===
match
---
atom_expr [22650,22661]
atom_expr [22650,22661]
===
match
---
operator: , [9599,9600]
operator: , [9599,9600]
===
match
---
trailer [34784,34791]
trailer [34784,34791]
===
match
---
atom_expr [52979,52989]
atom_expr [52979,52989]
===
match
---
name: pool_slots [23934,23944]
name: pool_slots [23934,23944]
===
match
---
name: session [21656,21663]
name: session [21656,21663]
===
match
---
atom_expr [66374,66401]
atom_expr [66386,66413]
===
match
---
comparison [28527,28544]
comparison [28527,28544]
===
match
---
simple_stmt [38350,38399]
simple_stmt [38350,38399]
===
match
---
arith_expr [34587,34606]
arith_expr [34587,34606]
===
match
---
simple_stmt [42016,42094]
simple_stmt [42016,42094]
===
match
---
operator: = [40421,40422]
operator: = [40421,40422]
===
match
---
trailer [16783,16788]
trailer [16783,16788]
===
match
---
dotted_name [2606,2637]
dotted_name [2606,2637]
===
match
---
name: commit [41793,41799]
name: commit [41793,41799]
===
match
---
name: _date_or_empty [42815,42829]
name: _date_or_empty [42815,42829]
===
match
---
operator: , [28137,28138]
operator: , [28137,28138]
===
match
---
name: property [79380,79388]
name: property [79392,79400]
===
match
---
operator: = [38495,38496]
operator: = [38495,38496]
===
match
---
atom_expr [66691,67294]
atom_expr [66703,67306]
===
match
---
name: item [61424,61428]
name: item [61436,61440]
===
match
---
expr_stmt [47472,47551]
expr_stmt [47472,47551]
===
match
---
atom_expr [7719,7936]
atom_expr [7719,7936]
===
match
---
name: PodGenerator [66691,66703]
name: PodGenerator [66703,66715]
===
match
---
trailer [79522,79534]
trailer [79534,79546]
===
match
---
simple_stmt [59692,59744]
simple_stmt [59704,59756]
===
match
---
name: Integer [10772,10779]
name: Integer [10772,10779]
===
match
---
operator: = [66662,66663]
operator: = [66674,66675]
===
match
---
name: pendulum [31204,31212]
name: pendulum [31204,31212]
===
match
---
operator: , [36751,36752]
operator: , [36751,36752]
===
match
---
raise_stmt [65777,65865]
raise_stmt [65789,65877]
===
match
---
fstring_start: f" [19935,19937]
fstring_start: f" [19935,19937]
===
match
---
name: ignore_all_deps [15982,15997]
name: ignore_all_deps [15982,15997]
===
match
---
name: result [42334,42340]
name: result [42334,42340]
===
match
---
name: TR [7069,7071]
name: TR [7069,7071]
===
match
---
atom_expr [53632,53651]
atom_expr [53632,53651]
===
match
---
operator: = [12091,12092]
operator: = [12091,12092]
===
match
---
operator: , [74801,74802]
operator: , [74813,74814]
===
match
---
return_stmt [75459,75494]
return_stmt [75471,75506]
===
match
---
operator: { [59857,59858]
operator: { [59869,59870]
===
match
---
name: dag_run [66031,66038]
name: dag_run [66043,66050]
===
match
---
or_test [23155,23173]
or_test [23155,23173]
===
match
---
parameters [79079,79085]
parameters [79091,79097]
===
match
---
funcdef [30002,30580]
funcdef [30002,30580]
===
match
---
name: cmd [19300,19303]
name: cmd [19300,19303]
===
match
---
operator: { [33904,33905]
operator: { [33904,33905]
===
match
---
param [70020,70024]
param [70032,70036]
===
match
---
operator: } [44273,44274]
operator: } [44273,44274]
===
match
---
name: executor_config [79944,79959]
name: executor_config [79956,79971]
===
match
---
atom_expr [42440,42852]
atom_expr [42440,42852]
===
match
---
trailer [41792,41799]
trailer [41792,41799]
===
match
---
name: dep_status [33436,33446]
name: dep_status [33436,33446]
===
match
---
name: log [54863,54866]
name: log [54875,54878]
===
match
---
annassign [78866,78888]
annassign [78878,78900]
===
match
---
name: dag_id [76887,76893]
name: dag_id [76899,76905]
===
match
---
name: set_state [24974,24983]
name: set_state [24974,24983]
===
match
---
param [42405,42410]
param [42405,42410]
===
match
---
name: jinja_context [68713,68726]
name: jinja_context [68725,68738]
===
match
---
trailer [46275,46288]
trailer [46275,46288]
===
match
---
trailer [57471,57473]
trailer [57483,57485]
===
match
---
import_as_names [1283,1357]
import_as_names [1283,1357]
===
match
---
simple_stmt [29407,29437]
simple_stmt [29407,29437]
===
match
---
operator: , [11982,11983]
operator: , [11982,11983]
===
match
---
name: bool [16508,16512]
name: bool [16508,16512]
===
match
---
name: params [57666,57672]
name: params [57678,57684]
===
match
---
parameters [79233,79239]
parameters [79245,79251]
===
match
---
atom_expr [57447,57473]
atom_expr [57459,57485]
===
match
---
name: str [61625,61628]
name: str [61637,61640]
===
match
---
trailer [33127,33164]
trailer [33127,33164]
===
match
---
argument [10505,10521]
argument [10505,10521]
===
match
---
name: duration [10677,10685]
name: duration [10677,10685]
===
match
---
operator: , [9319,9320]
operator: , [9319,9320]
===
match
---
simple_stmt [50172,50222]
simple_stmt [50172,50222]
===
match
---
name: f [70211,70212]
name: f [70223,70224]
===
match
---
fstring [47087,47141]
fstring [47087,47141]
===
match
---
trailer [44613,44617]
trailer [44613,44617]
===
match
---
name: self [35706,35710]
name: self [35706,35710]
===
match
---
name: ti [77677,77679]
name: ti [77689,77691]
===
match
---
simple_stmt [58044,58061]
simple_stmt [58056,58073]
===
match
---
suite [62220,62289]
suite [62232,62301]
===
match
---
trailer [40802,40807]
trailer [40802,40807]
===
match
---
return_stmt [79102,79121]
return_stmt [79114,79133]
===
match
---
trailer [41187,41202]
trailer [41187,41202]
===
match
---
name: models [2093,2099]
name: models [2093,2099]
===
match
---
name: RenderedTaskInstanceFields [64507,64533]
name: RenderedTaskInstanceFields [64519,64545]
===
match
---
trailer [24643,24650]
trailer [24643,24650]
===
match
---
decorated [79379,79455]
decorated [79391,79467]
===
match
---
name: self [9105,9109]
name: self [9105,9109]
===
match
---
atom_expr [72667,72692]
atom_expr [72679,72704]
===
match
---
name: next_ds_nodash [58992,59006]
name: next_ds_nodash [59004,59018]
===
match
---
atom_expr [34780,34791]
atom_expr [34780,34791]
===
match
---
name: unixname [23048,23056]
name: unixname [23048,23056]
===
match
---
trailer [71112,71123]
trailer [71124,71135]
===
match
---
atom_expr [25900,25910]
atom_expr [25900,25910]
===
match
---
name: REQUEUEABLE_DEPS [40422,40438]
name: REQUEUEABLE_DEPS [40422,40438]
===
match
---
name: ti [23117,23119]
name: ti [23117,23119]
===
match
---
atom_expr [45423,45496]
atom_expr [45423,45496]
===
match
---
name: execution_date [76630,76644]
name: execution_date [76642,76656]
===
match
---
if_stmt [18956,19023]
if_stmt [18956,19023]
===
match
---
name: dag_id [79073,79079]
name: dag_id [79085,79091]
===
match
---
comparison [36348,36376]
comparison [36348,36376]
===
match
---
suite [41999,42094]
suite [41999,42094]
===
match
---
name: tuple_ [1351,1357]
name: tuple_ [1351,1357]
===
match
---
if_stmt [13034,13075]
if_stmt [13034,13075]
===
match
---
trailer [8223,8240]
trailer [8223,8240]
===
match
---
testlist_comp [75263,75307]
testlist_comp [75275,75319]
===
match
---
simple_stmt [45984,46041]
simple_stmt [45984,46041]
===
match
---
operator: , [19895,19896]
operator: , [19895,19896]
===
match
---
trailer [3771,3942]
trailer [3771,3942]
===
match
---
string: '-' [59154,59157]
string: '-' [59166,59169]
===
match
---
simple_stmt [44609,44626]
simple_stmt [44609,44626]
===
match
---
name: warn [31504,31508]
name: warn [31504,31508]
===
match
---
simple_stmt [79031,79050]
simple_stmt [79043,79062]
===
match
---
simple_stmt [46856,46911]
simple_stmt [46856,46911]
===
match
---
operator: = [15253,15254]
operator: = [15253,15254]
===
match
---
operator: == [22360,22362]
operator: == [22360,22362]
===
match
---
name: task_id [9096,9103]
name: task_id [9096,9103]
===
match
---
name: scheduler_job_id [67101,67117]
name: scheduler_job_id [67113,67129]
===
match
---
name: force_fail [57024,57034]
name: force_fail [57036,57046]
===
match
---
name: context [48903,48910]
name: context [48903,48910]
===
match
---
trailer [48214,48229]
trailer [48214,48229]
===
match
---
suite [46316,46396]
suite [46316,46396]
===
match
---
param [24749,24753]
param [24749,24753]
===
match
---
trailer [9307,9384]
trailer [9307,9384]
===
match
---
expr_stmt [30450,30510]
expr_stmt [30450,30510]
===
match
---
simple_stmt [11036,11064]
simple_stmt [11036,11064]
===
match
---
name: dag_run [65957,65964]
name: dag_run [65969,65976]
===
match
---
atom_expr [19817,19855]
atom_expr [19817,19855]
===
match
---
name: Exception [56553,56562]
name: Exception [56565,56574]
===
match
---
arglist [24508,24633]
arglist [24508,24633]
===
match
---
simple_stmt [64904,65280]
simple_stmt [64916,65292]
===
match
---
number: 1 [80898,80899]
number: 1 [80910,80911]
===
match
---
name: warning [3764,3771]
name: warning [3764,3771]
===
match
---
arglist [7746,7926]
arglist [7746,7926]
===
match
---
name: _run_raw_task [42909,42922]
name: _run_raw_task [42909,42922]
===
match
---
operator: , [28804,28805]
operator: , [28804,28805]
===
match
---
name: count [26952,26957]
name: count [26952,26957]
===
match
---
simple_stmt [9192,9277]
simple_stmt [9192,9277]
===
match
---
name: and_ [8383,8387]
name: and_ [8383,8387]
===
match
---
funcdef [54349,56726]
funcdef [54349,56738]
===
match
---
fstring_expr [46125,46139]
fstring_expr [46125,46139]
===
match
---
suite [79735,79773]
suite [79747,79785]
===
match
---
operator: = [26027,26028]
operator: = [26027,26028]
===
match
---
name: render_templates [53310,53326]
name: render_templates [53310,53326]
===
match
---
trailer [60783,60814]
trailer [60795,60826]
===
match
---
trailer [6261,6272]
trailer [6261,6272]
===
match
---
simple_stmt [27433,27471]
simple_stmt [27433,27471]
===
match
---
name: self [48977,48981]
name: self [48977,48981]
===
match
---
simple_stmt [35645,35691]
simple_stmt [35645,35691]
===
match
---
name: TaskInstance [26782,26794]
name: TaskInstance [26782,26794]
===
match
---
trailer [72302,72317]
trailer [72314,72329]
===
match
---
name: task [51185,51189]
name: task [51185,51189]
===
match
---
param [30649,30677]
param [30649,30677]
===
match
---
atom_expr [67044,67087]
atom_expr [67056,67099]
===
match
---
atom_expr [58829,58876]
atom_expr [58841,58888]
===
match
---
trailer [44167,44169]
trailer [44167,44169]
===
match
---
operator: , [1289,1290]
operator: , [1289,1290]
===
match
---
operator: = [50213,50214]
operator: = [50213,50214]
===
match
---
atom_expr [22332,22359]
atom_expr [22332,22359]
===
match
---
trailer [22594,22605]
trailer [22594,22605]
===
match
---
name: pid [23365,23368]
name: pid [23365,23368]
===
match
---
operator: = [81126,81127]
operator: = [81138,81139]
===
match
---
name: post_execute [48890,48902]
name: post_execute [48890,48902]
===
match
---
atom_expr [43059,43072]
atom_expr [43059,43072]
===
match
---
name: State [55364,55369]
name: State [55376,55381]
===
match
---
simple_stmt [40784,40808]
simple_stmt [40784,40808]
===
match
---
param [56888,56913]
param [56900,56925]
===
match
---
trailer [71378,71388]
trailer [71390,71400]
===
match
---
atom_expr [66411,66452]
atom_expr [66423,66464]
===
match
---
string: """Key used to identify task instance.""" [8804,8845]
string: """Key used to identify task instance.""" [8804,8845]
===
match
---
trailer [49757,49802]
trailer [49757,49802]
===
match
---
name: SHUTDOWN [5411,5419]
name: SHUTDOWN [5411,5419]
===
match
---
trailer [15747,15761]
trailer [15747,15761]
===
match
---
argument [69102,69126]
argument [69114,69138]
===
match
---
name: task [70822,70826]
name: task [70834,70838]
===
match
---
trailer [79597,79604]
trailer [79609,79616]
===
match
---
param [70618,70627]
param [70630,70639]
===
match
---
name: duration [22693,22701]
name: duration [22693,22701]
===
match
---
trailer [69352,69369]
trailer [69364,69381]
===
match
---
operator: , [70572,70573]
operator: , [70584,70585]
===
match
---
expr_stmt [44521,44547]
expr_stmt [44521,44547]
===
match
---
name: self [15910,15914]
name: self [15910,15914]
===
match
---
operator: , [21005,21006]
operator: , [21005,21006]
===
match
---
expr_stmt [67343,67402]
expr_stmt [67355,67414]
===
match
---
name: pickle_id [15162,15171]
name: pickle_id [15162,15171]
===
match
---
simple_stmt [78492,78531]
simple_stmt [78504,78543]
===
match
---
atom_expr [58044,58060]
atom_expr [58056,58072]
===
match
---
trailer [31319,31328]
trailer [31319,31328]
===
match
---
string: "previous_execution_date was called" [30404,30440]
string: "previous_execution_date was called" [30404,30440]
===
match
---
atom_expr [48977,48996]
atom_expr [48977,48996]
===
match
---
name: execution_date [19828,19842]
name: execution_date [19828,19842]
===
match
---
param [20507,20512]
param [20507,20512]
===
match
---
name: test_mode [46306,46315]
name: test_mode [46306,46315]
===
match
---
param [43015,43044]
param [43015,43044]
===
match
---
argument [60922,60945]
argument [60934,60957]
===
match
---
name: self [45023,45027]
name: self [45023,45027]
===
match
---
or_test [56109,56154]
or_test [56121,56166]
===
match
---
simple_stmt [45565,45588]
simple_stmt [45565,45588]
===
match
---
atom_expr [23333,23347]
atom_expr [23333,23347]
===
match
---
trailer [10424,10450]
trailer [10424,10450]
===
match
---
return_stmt [80838,80847]
return_stmt [80850,80859]
===
match
---
atom_expr [80757,80786]
atom_expr [80769,80798]
===
match
---
name: context [48221,48228]
name: context [48221,48228]
===
match
---
name: os [47743,47745]
name: os [47743,47745]
===
match
---
trailer [45845,45860]
trailer [45845,45860]
===
match
---
operator: = [52384,52385]
operator: = [52384,52385]
===
match
---
trailer [22504,22510]
trailer [22504,22510]
===
match
---
name: Column [10618,10624]
name: Column [10618,10624]
===
match
---
arglist [10758,10790]
arglist [10758,10790]
===
match
---
name: task_id [26640,26647]
name: task_id [26640,26647]
===
match
---
name: self [78271,78275]
name: self [78283,78287]
===
match
---
parameters [9409,9432]
parameters [9409,9432]
===
match
---
expr_stmt [11036,11063]
expr_stmt [11036,11063]
===
match
---
name: session [75562,75569]
name: session [75574,75581]
===
match
---
fstring [20261,20287]
fstring [20261,20287]
===
match
---
sync_comp_for [77793,77806]
sync_comp_for [77805,77818]
===
match
---
subscriptlist [4780,4799]
subscriptlist [4780,4799]
===
match
---
name: start_date [8648,8658]
name: start_date [8648,8658]
===
match
---
exprlist [47677,47681]
exprlist [47677,47681]
===
match
---
operator: = [52420,52421]
operator: = [52420,52421]
===
match
---
name: render_template_fields [66421,66443]
name: render_template_fields [66433,66455]
===
match
---
operator: = [15024,15025]
operator: = [15024,15025]
===
match
---
funcdef [14195,14257]
funcdef [14195,14257]
===
match
---
comparison [26952,26990]
comparison [26952,26990]
===
match
---
name: read [70213,70217]
name: read [70225,70229]
===
match
---
trailer [80534,80710]
trailer [80546,80722]
===
match
---
operator: , [53797,53798]
operator: , [53797,53798]
===
match
---
atom_expr [25431,25441]
atom_expr [25431,25441]
===
match
---
trailer [28182,28191]
trailer [28182,28191]
===
match
---
trailer [44030,44037]
trailer [44030,44037]
===
match
---
if_stmt [56442,56642]
if_stmt [56454,56654]
===
match
---
trailer [47178,47195]
trailer [47178,47195]
===
match
---
operator: @ [31247,31248]
operator: @ [31247,31248]
===
match
---
trailer [75714,75716]
trailer [75726,75728]
===
match
---
operator: = [38470,38471]
operator: = [38470,38471]
===
match
---
operator: , [1772,1773]
operator: , [1772,1773]
===
match
---
name: task_copy [49833,49842]
name: task_copy [49833,49842]
===
match
---
name: get_rendered_k8s_spec [65310,65331]
name: get_rendered_k8s_spec [65322,65343]
===
match
---
expr_stmt [51173,51189]
expr_stmt [51173,51189]
===
match
---
simple_stmt [24661,24678]
simple_stmt [24661,24678]
===
match
---
name: value [50208,50213]
name: value [50208,50213]
===
match
---
name: Exception [70872,70881]
name: Exception [70884,70893]
===
match
---
expr_stmt [54668,54694]
expr_stmt [54668,54694]
===
match
---
trailer [44353,44374]
trailer [44353,44374]
===
match
---
simple_stmt [35535,35587]
simple_stmt [35535,35587]
===
match
---
atom_expr [35968,35985]
atom_expr [35968,35985]
===
match
---
name: error [21255,21260]
name: error [21255,21260]
===
match
---
name: session [30502,30509]
name: session [30502,30509]
===
match
---
operator: = [74681,74682]
operator: = [74693,74694]
===
match
---
operator: , [42647,42648]
operator: , [42647,42648]
===
match
---
operator: = [28127,28128]
operator: = [28127,28128]
===
match
---
atom_expr [61818,61884]
atom_expr [61830,61896]
===
match
---
trailer [21601,21603]
trailer [21601,21603]
===
match
---
name: self [61476,61480]
name: self [61488,61492]
===
match
---
atom_expr [69184,69308]
atom_expr [69196,69320]
===
match
---
annassign [78506,78530]
annassign [78518,78542]
===
match
---
name: error [54867,54872]
name: error [54879,54884]
===
match
---
expr_stmt [53225,53265]
expr_stmt [53225,53265]
===
match
---
trailer [75185,75211]
trailer [75197,75223]
===
match
---
string: '-' [59544,59547]
string: '-' [59556,59559]
===
match
---
tfpdef [16723,16747]
tfpdef [16723,16747]
===
match
---
atom_expr [5325,5333]
atom_expr [5325,5333]
===
match
---
operator: = [31033,31034]
operator: = [31033,31034]
===
match
---
not_test [39344,39475]
not_test [39344,39475]
===
match
---
string: "when Dag Serialization is enabled. Hence for the task that have not yet " [65036,65110]
string: "when Dag Serialization is enabled. Hence for the task that have not yet " [65048,65122]
===
match
---
atom_expr [78696,78709]
atom_expr [78708,78721]
===
match
---
string: 'TaskInstanceKey' [9165,9182]
string: 'TaskInstanceKey' [9165,9182]
===
match
---
expr_stmt [23029,23056]
expr_stmt [23029,23056]
===
match
---
expr_stmt [41556,41577]
expr_stmt [41556,41577]
===
match
---
atom_expr [15910,15929]
atom_expr [15910,15929]
===
match
---
name: Any [61659,61662]
name: Any [61671,61674]
===
match
---
simple_stmt [80813,80830]
simple_stmt [80825,80842]
===
match
---
fstring_string: Unable to render a k8s spec for this taskinstance:  [65802,65853]
fstring_string: Unable to render a k8s spec for this taskinstance:  [65814,65865]
===
match
---
trailer [66822,66829]
trailer [66834,66841]
===
match
---
operator: , [24534,24535]
operator: , [24534,24535]
===
match
---
trailer [38681,38711]
trailer [38681,38711]
===
match
---
name: sqlalchemy [1418,1428]
name: sqlalchemy [1418,1428]
===
match
---
suite [21132,21165]
suite [21132,21165]
===
match
---
name: mark_success [52372,52384]
name: mark_success [52372,52384]
===
match
---
name: default_var [61646,61657]
name: default_var [61658,61669]
===
match
---
subscriptlist [54404,54418]
subscriptlist [54404,54418]
===
match
---
name: force_fail [54471,54481]
name: force_fail [54471,54481]
===
match
---
name: self [19972,19976]
name: self [19972,19976]
===
match
---
name: set_duration [46276,46288]
name: set_duration [46276,46288]
===
match
---
suite [52950,53120]
suite [52950,53120]
===
match
---
trailer [35656,35690]
trailer [35656,35690]
===
match
---
name: tis [77247,77250]
name: tis [77259,77262]
===
match
---
decorator [14262,14272]
decorator [14262,14272]
===
match
---
operator: , [1039,1040]
operator: , [1039,1040]
===
match
---
operator: , [6868,6869]
operator: , [6868,6869]
===
match
---
simple_stmt [43863,43880]
simple_stmt [43863,43880]
===
match
---
name: str [54404,54407]
name: str [54404,54407]
===
match
---
if_stmt [26531,26588]
if_stmt [26531,26588]
===
match
---
atom_expr [71092,71105]
atom_expr [71104,71117]
===
match
---
operator: , [40734,40735]
operator: , [40734,40735]
===
match
---
sync_comp_for [7332,7375]
sync_comp_for [7332,7375]
===
match
---
operator: , [8987,8988]
operator: , [8987,8988]
===
match
---
atom_expr [60544,60562]
atom_expr [60556,60574]
===
match
---
expr_stmt [23360,23377]
expr_stmt [23360,23377]
===
match
---
name: task_id [78366,78373]
name: task_id [78378,78385]
===
match
---
name: commit [54236,54242]
name: commit [54236,54242]
===
match
---
name: default_subject [67799,67814]
name: default_subject [67811,67826]
===
match
---
trailer [75095,75103]
trailer [75107,75115]
===
match
---
string: 'task' [63643,63649]
string: 'task' [63655,63661]
===
match
---
simple_stmt [59245,59260]
simple_stmt [59257,59272]
===
match
---
parameters [3964,3979]
parameters [3964,3979]
===
match
---
trailer [55355,55359]
trailer [55367,55371]
===
match
---
atom_expr [23083,23092]
atom_expr [23083,23092]
===
match
---
funcdef [61303,61485]
funcdef [61315,61497]
===
match
---
operator: , [67283,67284]
operator: , [67295,67296]
===
match
---
expr_stmt [54006,54042]
expr_stmt [54006,54042]
===
match
---
name: job_id [38524,38530]
name: job_id [38524,38530]
===
match
---
simple_stmt [24093,24137]
simple_stmt [24093,24137]
===
match
---
name: _run_raw_task [52692,52705]
name: _run_raw_task [52692,52705]
===
match
---
name: duration [22679,22687]
name: duration [22679,22687]
===
match
---
arglist [75755,75897]
arglist [75767,75909]
===
match
---
operator: = [36581,36582]
operator: = [36581,36582]
===
match
---
simple_stmt [69619,69663]
simple_stmt [69631,69675]
===
match
---
name: dag_id [59832,59838]
name: dag_id [59844,59850]
===
match
---
trailer [8730,8755]
trailer [8730,8755]
===
match
---
arglist [38463,38500]
arglist [38463,38500]
===
match
---
operator: , [72478,72479]
operator: , [72490,72491]
===
match
---
name: duration [25572,25580]
name: duration [25572,25580]
===
match
---
atom_expr [63571,63584]
atom_expr [63583,63596]
===
match
---
atom_expr [4307,4328]
atom_expr [4307,4328]
===
match
---
atom_expr [51500,51527]
atom_expr [51500,51527]
===
match
---
name: engine [41918,41924]
name: engine [41918,41924]
===
match
---
name: try_number [66874,66884]
name: try_number [66886,66896]
===
match
---
name: ID_LEN [11338,11344]
name: ID_LEN [11338,11344]
===
match
---
atom_expr [50932,50956]
atom_expr [50932,50956]
===
match
---
atom_expr [78650,78668]
atom_expr [78662,78680]
===
match
---
atom_expr [21054,21073]
atom_expr [21054,21073]
===
match
---
name: TaskInstance [77046,77058]
name: TaskInstance [77058,77070]
===
match
---
simple_stmt [67736,67790]
simple_stmt [67748,67802]
===
match
---
number: 16 [34929,34931]
number: 16 [34929,34931]
===
match
---
atom_expr [47743,47782]
atom_expr [47743,47782]
===
match
---
simple_stmt [78074,78126]
simple_stmt [78086,78138]
===
match
---
operator: , [36626,36627]
operator: , [36626,36627]
===
match
---
operator: } [64136,64137]
operator: } [64148,64149]
===
match
---
trailer [56514,56526]
trailer [56526,56538]
===
match
---
trailer [69253,69258]
trailer [69265,69270]
===
match
---
operator: , [4815,4816]
operator: , [4815,4816]
===
match
---
atom_expr [47564,47729]
atom_expr [47564,47729]
===
match
---
trailer [49767,49785]
trailer [49767,49785]
===
match
---
expr_stmt [12135,12160]
expr_stmt [12135,12160]
===
match
---
trailer [46145,46151]
trailer [46145,46151]
===
match
---
name: property [24728,24736]
name: property [24728,24736]
===
match
---
trailer [11629,11648]
trailer [11629,11648]
===
match
---
trailer [77665,77673]
trailer [77677,77685]
===
match
---
name: ds [62777,62779]
name: ds [62789,62791]
===
match
---
suite [7710,8005]
suite [7710,8005]
===
match
---
name: task [26743,26747]
name: task [26743,26747]
===
match
---
atom_expr [55220,55275]
atom_expr [55232,55287]
===
match
---
name: jinja_env [69421,69430]
name: jinja_env [69433,69442]
===
match
---
tfpdef [9416,9431]
tfpdef [9416,9431]
===
match
---
operator: , [11640,11641]
operator: , [11640,11641]
===
match
---
name: dag_run_state [8681,8694]
name: dag_run_state [8681,8694]
===
match
---
atom_expr [22920,22934]
atom_expr [22920,22934]
===
match
---
operator: , [15062,15063]
operator: , [15062,15063]
===
match
---
name: log [56585,56588]
name: log [56597,56600]
===
match
---
suite [30739,31242]
suite [30739,31242]
===
match
---
name: self [79031,79035]
name: self [79043,79047]
===
match
---
decorator [51626,51643]
decorator [51626,51643]
===
match
---
name: typing [1023,1029]
name: typing [1023,1029]
===
match
---
trailer [50536,50578]
trailer [50536,50578]
===
match
---
number: 1 [35520,35521]
number: 1 [35520,35521]
===
match
---
name: all [7626,7629]
name: all [7626,7629]
===
match
---
name: start_date [55478,55488]
name: start_date [55490,55500]
===
match
---
trailer [59666,59674]
trailer [59678,59686]
===
match
---
atom_expr [24055,24069]
atom_expr [24055,24069]
===
match
---
name: first_task_id [76653,76666]
name: first_task_id [76665,76678]
===
match
---
trailer [23141,23152]
trailer [23141,23152]
===
match
---
string: """Load and return error from error file""" [4020,4063]
string: """Load and return error from error file""" [4020,4063]
===
match
---
name: dag_id [16417,16423]
name: dag_id [16417,16423]
===
match
---
operator: != [3736,3738]
operator: != [3736,3738]
===
match
---
operator: = [32664,32665]
operator: = [32664,32665]
===
match
---
trailer [5590,5599]
trailer [5590,5599]
===
match
---
suite [31920,33185]
suite [31920,33185]
===
match
---
name: generate_command [16391,16407]
name: generate_command [16391,16407]
===
match
---
name: self [13083,13087]
name: self [13083,13087]
===
match
---
suite [54841,54886]
suite [54853,54898]
===
match
---
trailer [4110,4112]
trailer [4110,4112]
===
match
---
name: airflow [2866,2873]
name: airflow [2866,2873]
===
match
---
name: self [45058,45062]
name: self [45058,45062]
===
match
---
string: """         The execution date from property previous_ti_success.          :param state: If passed, it only take into account instances of a specific state.         :param session: SQLAlchemy ORM Session         """ [30165,30380]
string: """         The execution date from property previous_ti_success.          :param state: If passed, it only take into account instances of a specific state.         :param session: SQLAlchemy ORM Session         """ [30165,30380]
===
match
---
if_stmt [28590,28819]
if_stmt [28590,28819]
===
match
---
funcdef [67437,70591]
funcdef [67449,70603]
===
match
---
atom_expr [36378,36399]
atom_expr [36378,36399]
===
match
---
operator: @ [13587,13588]
operator: @ [13587,13588]
===
match
---
import_name [1147,1160]
import_name [1147,1160]
===
match
---
name: ignore_task_deps [40568,40584]
name: ignore_task_deps [40568,40584]
===
match
---
operator: , [70832,70833]
operator: , [70844,70845]
===
match
---
expr_stmt [55125,55141]
expr_stmt [55137,55153]
===
match
---
name: task_id [44266,44273]
name: task_id [44266,44273]
===
match
---
return_stmt [50230,50243]
return_stmt [50230,50243]
===
match
---
tfpdef [36761,36779]
tfpdef [36761,36779]
===
match
---
name: prev_ti [31222,31229]
name: prev_ti [31222,31229]
===
match
---
name: self [49100,49104]
name: self [49100,49104]
===
match
---
name: default_subject [70348,70363]
name: default_subject [70360,70375]
===
match
---
name: previous_schedule [58838,58855]
name: previous_schedule [58850,58867]
===
match
---
name: params [60063,60069]
name: params [60075,60081]
===
match
---
name: self [30389,30393]
name: self [30389,30393]
===
match
---
fstring_end: ' [48997,48998]
fstring_end: ' [48997,48998]
===
match
---
atom_expr [72434,72446]
atom_expr [72446,72458]
===
match
---
trailer [54872,54885]
trailer [54884,54897]
===
match
---
name: max_tries [69117,69126]
name: max_tries [69129,69138]
===
match
---
trailer [76187,76206]
trailer [76199,76218]
===
match
---
operator: , [19694,19695]
operator: , [19694,19695]
===
match
---
name: check_and_change_state_before_execution [52094,52133]
name: check_and_change_state_before_execution [52094,52133]
===
match
---
argument [10433,10449]
argument [10433,10449]
===
match
---
name: task [12651,12655]
name: task [12651,12655]
===
match
---
name: Optional [78868,78876]
name: Optional [78880,78888]
===
match
---
simple_stmt [38442,38502]
simple_stmt [38442,38502]
===
match
---
atom_expr [42073,42092]
atom_expr [42073,42092]
===
match
---
name: downstream_task_ids [26970,26989]
name: downstream_task_ids [26970,26989]
===
match
---
name: pod [66685,66688]
name: pod [66697,66700]
===
match
---
fstring_expr [33942,33954]
fstring_expr [33942,33954]
===
match
---
fstring_start: f" [47662,47664]
fstring_start: f" [47662,47664]
===
match
---
trailer [48292,48300]
trailer [48292,48300]
===
match
---
arglist [59735,59742]
arglist [59747,59754]
===
match
---
simple_stmt [33286,33316]
simple_stmt [33286,33316]
===
match
---
name: _run_as_user [78773,78785]
name: _run_as_user [78785,78797]
===
match
---
name: self [41491,41495]
name: self [41491,41495]
===
match
---
name: self [34793,34797]
name: self [34793,34797]
===
match
---
operator: = [59342,59343]
operator: = [59354,59355]
===
match
---
parameters [49099,49119]
parameters [49099,49119]
===
match
---
operator: , [43950,43951]
operator: , [43950,43951]
===
match
---
operator: = [8659,8660]
operator: = [8659,8660]
===
match
---
name: priority_weight [78971,78986]
name: priority_weight [78983,78998]
===
match
---
name: _try_number [14151,14162]
name: _try_number [14151,14162]
===
match
---
operator: } [45781,45782]
operator: } [45781,45782]
===
match
---
simple_stmt [1579,1833]
simple_stmt [1579,1833]
===
match
---
name: ignore_task_deps [19185,19201]
name: ignore_task_deps [19185,19201]
===
match
---
annassign [78316,78333]
annassign [78328,78345]
===
match
---
trailer [59831,59838]
trailer [59843,59850]
===
match
---
operator: , [11811,11812]
operator: , [11811,11812]
===
match
---
decorated [14172,14257]
decorated [14172,14257]
===
match
---
name: task_id [77666,77673]
name: task_id [77678,77685]
===
match
---
name: State [2942,2947]
name: State [2942,2947]
===
match
---
name: self [22989,22993]
name: self [22989,22993]
===
match
---
expr_stmt [78304,78333]
expr_stmt [78316,78345]
===
match
---
name: execution_date [6944,6958]
name: execution_date [6944,6958]
===
match
---
name: priority_weight [23246,23261]
name: priority_weight [23246,23261]
===
match
---
operator: = [70390,70391]
operator: = [70402,70403]
===
match
---
name: end_date [79397,79405]
name: end_date [79409,79417]
===
match
---
trailer [44098,44102]
trailer [44098,44102]
===
match
---
name: _run_finished_callback [50588,50610]
name: _run_finished_callback [50588,50610]
===
match
---
name: session [31077,31084]
name: session [31077,31084]
===
match
---
name: context [50026,50033]
name: context [50026,50033]
===
match
---
trailer [33363,33365]
trailer [33363,33365]
===
match
---
arglist [10497,10521]
arglist [10497,10521]
===
match
---
name: and_ [6911,6915]
name: and_ [6911,6915]
===
match
---
atom_expr [41556,41572]
atom_expr [41556,41572]
===
match
---
trailer [51109,51118]
trailer [51109,51118]
===
match
---
atom_expr [69251,69276]
atom_expr [69263,69288]
===
match
---
operator: , [55488,55489]
operator: , [55500,55501]
===
match
---
name: key [72384,72387]
name: key [72396,72399]
===
match
---
atom_expr [60533,60541]
atom_expr [60545,60553]
===
match
---
name: delay [35684,35689]
name: delay [35684,35689]
===
match
---
name: state [30481,30486]
name: state [30481,30486]
===
match
---
name: render_templates [47162,47178]
name: render_templates [47162,47178]
===
match
---
atom_expr [49271,49290]
atom_expr [49271,49290]
===
match
---
atom_expr [10563,10600]
atom_expr [10563,10600]
===
match
---
simple_stmt [26597,26912]
simple_stmt [26597,26912]
===
match
---
name: task_id [20998,21005]
name: task_id [20998,21005]
===
match
---
name: _schedule [27925,27934]
name: _schedule [27925,27934]
===
match
---
arglist [76999,77158]
arglist [77011,77170]
===
match
---
atom_expr [58185,58204]
atom_expr [58197,58216]
===
match
---
simple_stmt [23431,23481]
simple_stmt [23431,23481]
===
match
---
decorated [20013,20463]
decorated [20013,20463]
===
match
---
operator: , [48918,48919]
operator: , [48918,48919]
===
match
---
param [79564,79568]
param [79576,79580]
===
match
---
name: dag_id [11591,11597]
name: dag_id [11591,11597]
===
match
---
trailer [13087,13096]
trailer [13087,13096]
===
match
---
simple_stmt [22180,22394]
simple_stmt [22180,22394]
===
match
---
name: self [47564,47568]
name: self [47564,47568]
===
match
---
name: state [38635,38640]
name: state [38635,38640]
===
match
---
operator: , [62404,62405]
operator: , [62416,62417]
===
match
---
trailer [69976,69993]
trailer [69988,70005]
===
match
---
name: State [56285,56290]
name: State [56297,56302]
===
match
---
string: " Continue to run task in non smart sensor mode." [48390,48439]
string: " Continue to run task in non smart sensor mode." [48390,48439]
===
match
---
strings [20238,20452]
strings [20238,20452]
===
match
---
trailer [3997,4013]
trailer [3997,4013]
===
match
---
funcdef [79308,79374]
funcdef [79320,79386]
===
match
---
atom_expr [45058,45133]
atom_expr [45058,45133]
===
match
---
arglist [80548,80700]
arglist [80560,80712]
===
match
---
arglist [47952,47965]
arglist [47952,47965]
===
match
---
trailer [36340,36347]
trailer [36340,36347]
===
match
---
tfpdef [16460,16484]
tfpdef [16460,16484]
===
match
---
string: """Returns TaskInstanceKey with provided ``try_number``""" [9463,9521]
string: """Returns TaskInstanceKey with provided ``try_number``""" [9463,9521]
===
match
---
trailer [58058,58060]
trailer [58070,58072]
===
match
---
trailer [19822,19855]
trailer [19822,19855]
===
match
---
except_clause [4480,4496]
except_clause [4480,4496]
===
match
---
string: 'var' [64022,64027]
string: 'var' [64034,64039]
===
match
---
trailer [34545,34610]
trailer [34545,34610]
===
match
---
trailer [61826,61830]
trailer [61838,61842]
===
match
---
expr_stmt [11142,11175]
expr_stmt [11142,11175]
===
match
---
return_stmt [19715,19725]
return_stmt [19715,19725]
===
match
---
name: execution_date [24595,24609]
name: execution_date [24595,24609]
===
match
---
operator: , [14999,15000]
operator: , [14999,15000]
===
match
---
return_stmt [62513,62564]
return_stmt [62525,62576]
===
match
---
name: ts_nodash [63947,63956]
name: ts_nodash [63959,63968]
===
match
---
atom_expr [51374,51392]
atom_expr [51374,51392]
===
match
---
trailer [28905,28913]
trailer [28905,28913]
===
match
---
atom_expr [76999,77018]
atom_expr [77011,77030]
===
match
---
simple_stmt [78382,78433]
simple_stmt [78394,78445]
===
match
---
name: ti [6292,6294]
name: ti [6292,6294]
===
match
---
atom_expr [3303,3330]
atom_expr [3303,3330]
===
match
---
trailer [12139,12146]
trailer [12139,12146]
===
match
---
name: set [72363,72366]
name: set [72375,72378]
===
match
---
operator: = [5672,5673]
operator: = [5672,5673]
===
match
---
name: execution_date [55457,55471]
name: execution_date [55469,55483]
===
match
---
simple_stmt [3000,3051]
simple_stmt [3000,3051]
===
match
---
trailer [55477,55488]
trailer [55489,55500]
===
match
---
name: queued_dttm [11142,11153]
name: queued_dttm [11142,11153]
===
match
---
name: in_ [7612,7615]
name: in_ [7612,7615]
===
match
---
name: tomorrow_ds_nodash [59752,59770]
name: tomorrow_ds_nodash [59764,59782]
===
match
---
trailer [51294,51296]
trailer [51294,51296]
===
match
---
trailer [51379,51392]
trailer [51379,51392]
===
match
---
name: default_html_content [69443,69463]
name: default_html_content [69455,69475]
===
match
---
name: session [30494,30501]
name: session [30494,30501]
===
match
---
atom_expr [49833,49867]
atom_expr [49833,49867]
===
match
---
atom_expr [62520,62564]
atom_expr [62532,62576]
===
match
---
name: foreign_keys [11940,11952]
name: foreign_keys [11940,11952]
===
match
---
name: self [20993,20997]
name: self [20993,20997]
===
match
---
argument [66898,66931]
argument [66910,66943]
===
match
---
simple_stmt [21290,21453]
simple_stmt [21290,21453]
===
match
---
name: self [80621,80625]
name: self [80633,80637]
===
match
---
name: get [70117,70120]
name: get [70129,70132]
===
match
---
name: info [49138,49142]
name: info [49138,49142]
===
match
---
name: info [42137,42141]
name: info [42137,42141]
===
match
---
operator: = [81072,81073]
operator: = [81084,81085]
===
match
---
string: 'previously_succeeded' [38682,38704]
string: 'previously_succeeded' [38682,38704]
===
match
---
number: 1 [38706,38707]
number: 1 [38706,38707]
===
match
---
atom_expr [42763,42796]
atom_expr [42763,42796]
===
match
---
atom_expr [40685,40766]
atom_expr [40685,40766]
===
match
---
atom_expr [23045,23056]
atom_expr [23045,23056]
===
match
---
operator: , [52005,52006]
operator: , [52005,52006]
===
match
---
simple_stmt [18783,18816]
simple_stmt [18783,18816]
===
match
---
name: task [51438,51442]
name: task [51438,51442]
===
match
---
name: self [78768,78772]
name: self [78780,78784]
===
match
---
suite [33795,33833]
suite [33795,33833]
===
match
---
operator: , [30492,30493]
operator: , [30492,30493]
===
match
---
name: get_templated_fields [64534,64554]
name: get_templated_fields [64546,64566]
===
match
---
operator: , [52785,52786]
operator: , [52785,52786]
===
match
---
param [42411,42429]
param [42411,42429]
===
match
---
trailer [19081,19089]
trailer [19081,19089]
===
match
---
import_from [2910,2947]
import_from [2910,2947]
===
match
---
arglist [70121,70133]
arglist [70133,70145]
===
match
---
name: state [63412,63417]
name: state [63424,63429]
===
match
---
name: bool [54483,54487]
name: bool [54483,54487]
===
match
---
simple_stmt [5436,5462]
simple_stmt [5436,5462]
===
match
---
name: error [53107,53112]
name: error [53107,53112]
===
match
---
name: self [22634,22638]
name: self [22634,22638]
===
match
---
operator: -> [79495,79497]
operator: -> [79507,79509]
===
match
---
operator: , [52748,52749]
operator: , [52748,52749]
===
match
---
simple_stmt [57527,57539]
simple_stmt [57539,57551]
===
match
---
atom_expr [43101,43114]
atom_expr [43101,43114]
===
match
---
atom_expr [25914,25932]
atom_expr [25914,25932]
===
match
---
simple_stmt [1511,1540]
simple_stmt [1511,1540]
===
match
---
operator: = [51855,51856]
operator: = [51855,51856]
===
match
---
try_stmt [56489,56642]
try_stmt [56501,56654]
===
match
---
name: platform [2787,2795]
name: platform [2787,2795]
===
match
---
simple_stmt [70458,70535]
simple_stmt [70470,70547]
===
match
---
name: prev_ds_nodash [59268,59282]
name: prev_ds_nodash [59280,59294]
===
match
---
name: getattr [42275,42282]
name: getattr [42275,42282]
===
match
---
trailer [58229,58241]
trailer [58241,58253]
===
match
---
trailer [7629,7631]
trailer [7629,7631]
===
match
---
operator: , [18849,18850]
operator: , [18849,18850]
===
match
---
atom_expr [39348,39475]
atom_expr [39348,39475]
===
match
---
name: dag_id [11546,11552]
name: dag_id [11546,11552]
===
match
---
name: Stats [55284,55289]
name: Stats [55296,55301]
===
match
---
simple_stmt [48880,48935]
simple_stmt [48880,48935]
===
match
---
operator: , [53897,53898]
operator: , [53897,53898]
===
match
---
name: expected_state [3670,3684]
name: expected_state [3670,3684]
===
match
---
trailer [80609,80617]
trailer [80621,80629]
===
match
---
operator: = [63570,63571]
operator: = [63582,63583]
===
match
---
arglist [47595,47715]
arglist [47595,47715]
===
match
---
trailer [38543,38552]
trailer [38543,38552]
===
match
---
name: task [12038,12042]
name: task [12038,12042]
===
match
---
operator: , [1829,1830]
operator: , [1829,1830]
===
match
---
name: taskreschedule [2043,2057]
name: taskreschedule [2043,2057]
===
match
---
name: lead_msg [42411,42419]
name: lead_msg [42411,42419]
===
match
---
name: staticmethod [60679,60691]
name: staticmethod [60691,60703]
===
match
---
atom_expr [59344,59384]
atom_expr [59356,59396]
===
match
---
name: self [72121,72125]
name: self [72133,72137]
===
match
---
if_stmt [50110,50222]
if_stmt [50110,50222]
===
match
---
operator: , [75198,75199]
operator: , [75210,75211]
===
match
---
atom_expr [34700,34911]
atom_expr [34700,34911]
===
match
---
atom_expr [7151,7169]
atom_expr [7151,7169]
===
match
---
atom_expr [38442,38501]
atom_expr [38442,38501]
===
match
---
fstring_expr [20355,20360]
fstring_expr [20355,20360]
===
match
---
expr_stmt [58807,58876]
expr_stmt [58819,58888]
===
match
---
suite [64764,65280]
suite [64776,65292]
===
match
---
name: dag [58834,58837]
name: dag [58846,58849]
===
match
---
argument [52176,52207]
argument [52176,52207]
===
match
---
simple_stmt [39985,40065]
simple_stmt [39985,40065]
===
match
---
trailer [10624,10637]
trailer [10624,10637]
===
match
---
simple_stmt [885,901]
simple_stmt [885,901]
===
match
---
argument [48903,48918]
argument [48903,48918]
===
match
---
trailer [64711,64750]
trailer [64723,64762]
===
match
---
name: Union [4774,4779]
name: Union [4774,4779]
===
match
---
string: 'next_ds' [62964,62973]
string: 'next_ds' [62976,62985]
===
match
---
name: UtcDateTime [10570,10581]
name: UtcDateTime [10570,10581]
===
match
---
trailer [29938,29954]
trailer [29938,29954]
===
match
---
name: job_id [52451,52457]
name: job_id [52451,52457]
===
match
---
name: set_error_file [55082,55096]
name: set_error_file [55094,55108]
===
match
---
atom_expr [59714,59743]
atom_expr [59726,59755]
===
match
---
name: self [45984,45988]
name: self [45984,45988]
===
match
---
suite [9454,9613]
suite [9454,9613]
===
match
---
operator: @ [25969,25970]
operator: @ [25969,25970]
===
match
---
simple_stmt [81099,81150]
simple_stmt [81111,81162]
===
match
---
operator: , [7067,7068]
operator: , [7067,7068]
===
match
---
atom_expr [80818,80829]
atom_expr [80830,80841]
===
match
---
name: DateTime [30729,30737]
name: DateTime [30729,30737]
===
match
---
name: _dag_id [78309,78316]
name: _dag_id [78321,78328]
===
match
---
name: Column [10714,10720]
name: Column [10714,10720]
===
match
---
string: 'execution_date can not be in the past (current ' [72188,72237]
string: 'execution_date can not be in the past (current ' [72200,72249]
===
match
---
name: self [38332,38336]
name: self [38332,38336]
===
match
---
funcdef [42221,42385]
funcdef [42221,42385]
===
match
---
name: state [13037,13042]
name: state [13037,13042]
===
match
---
trailer [55436,55505]
trailer [55448,55517]
===
match
---
atom_expr [12972,12987]
atom_expr [12972,12987]
===
match
---
try_stmt [44285,46155]
try_stmt [44285,46155]
===
match
---
for_stmt [8175,8270]
for_stmt [8175,8270]
===
match
---
name: Exception [4318,4327]
name: Exception [4318,4327]
===
match
---
simple_stmt [49129,49184]
simple_stmt [49129,49184]
===
match
---
name: result [75156,75162]
name: result [75168,75174]
===
match
---
param [61251,61255]
param [61263,61267]
===
match
---
atom_expr [23371,23377]
atom_expr [23371,23377]
===
match
---
argument [15943,15968]
argument [15943,15968]
===
match
---
arglist [48215,48228]
arglist [48215,48228]
===
match
---
param [4704,4712]
param [4704,4712]
===
match
---
param [65332,65337]
param [65344,65349]
===
match
---
operator: , [16321,16322]
operator: , [16321,16322]
===
match
---
name: merge [21567,21572]
name: merge [21567,21572]
===
match
---
name: self [21261,21265]
name: self [21261,21265]
===
match
---
decorated [49046,49451]
decorated [49046,49451]
===
match
---
operator: , [42749,42750]
operator: , [42749,42750]
===
match
---
atom_expr [15706,15723]
atom_expr [15706,15723]
===
match
---
name: error [4461,4466]
name: error [4461,4466]
===
match
---
if_stmt [8010,8763]
if_stmt [8010,8763]
===
match
---
tfpdef [62380,62397]
tfpdef [62392,62409]
===
match
---
atom_expr [14232,14248]
atom_expr [14232,14248]
===
match
---
argument [44883,44903]
argument [44883,44903]
===
match
---
name: ti [5703,5705]
name: ti [5703,5705]
===
match
---
suite [23540,24176]
suite [23540,24176]
===
match
---
expr_stmt [18824,18879]
expr_stmt [18824,18879]
===
match
---
name: task_ids [75038,75046]
name: task_ids [75050,75058]
===
match
---
string: "Current context is not equal to the state at context stack. Expected=%s, got=%s" [3789,3870]
string: "Current context is not equal to the state at context stack. Expected=%s, got=%s" [3789,3870]
===
match
---
name: str [3249,3252]
name: str [3249,3252]
===
match
---
operator: @ [24727,24728]
operator: @ [24727,24728]
===
match
---
name: failed [32821,32827]
name: failed [32821,32827]
===
match
---
param [72710,72739]
param [72722,72751]
===
match
---
trailer [24015,24027]
trailer [24015,24027]
===
match
---
simple_stmt [51406,51423]
simple_stmt [51406,51423]
===
match
---
trailer [41799,41801]
trailer [41799,41801]
===
match
---
name: self [78811,78815]
name: self [78823,78827]
===
match
---
atom_expr [53207,53216]
atom_expr [53207,53216]
===
match
---
operator: , [25320,25321]
operator: , [25320,25321]
===
match
---
name: get [61420,61423]
name: get [61432,61435]
===
match
---
name: ts_nodash_with_tz [63991,64008]
name: ts_nodash_with_tz [64003,64020]
===
match
---
atom_expr [9537,9612]
atom_expr [9537,9612]
===
match
---
operator: = [35560,35561]
operator: = [35560,35561]
===
match
---
name: task_id [5591,5598]
name: task_id [5591,5598]
===
match
---
atom_expr [23404,23414]
atom_expr [23404,23414]
===
match
---
name: mark_success [42946,42958]
name: mark_success [42946,42958]
===
match
---
suite [9667,9771]
suite [9667,9771]
===
match
---
operator: = [29905,29906]
operator: = [29905,29906]
===
match
---
expr_stmt [80870,80917]
expr_stmt [80882,80929]
===
match
---
name: log [32671,32674]
name: log [32671,32674]
===
match
---
name: dag [27401,27404]
name: dag [27401,27404]
===
match
---
name: exceptions [1592,1602]
name: exceptions [1592,1602]
===
match
---
name: Session [77495,77502]
name: Session [77507,77514]
===
match
---
name: state [24990,24995]
name: state [24990,24995]
===
match
---
atom_expr [41676,41689]
atom_expr [41676,41689]
===
match
---
operator: , [46355,46356]
operator: , [46355,46356]
===
match
---
argument [72492,72544]
argument [72504,72556]
===
match
---
arglist [47519,47550]
arglist [47519,47550]
===
match
---
return_stmt [70544,70590]
return_stmt [70556,70602]
===
match
---
name: ignore_task_deps [52297,52313]
name: ignore_task_deps [52297,52313]
===
match
---
operator: , [43079,43080]
operator: , [43079,43080]
===
match
---
expr_stmt [59692,59743]
expr_stmt [59704,59755]
===
match
---
name: property [79779,79787]
name: property [79791,79799]
===
match
---
name: failed [33065,33071]
name: failed [33065,33071]
===
match
---
name: ignore_ti_state [16655,16670]
name: ignore_ti_state [16655,16670]
===
match
---
param [36636,36673]
param [36636,36673]
===
match
---
name: stats [2287,2292]
name: stats [2287,2292]
===
match
---
trailer [30136,30155]
trailer [30136,30155]
===
match
---
name: delete [52662,52668]
name: delete [52662,52668]
===
match
---
comparison [77294,77323]
comparison [77306,77335]
===
match
---
name: provide_session [2845,2860]
name: provide_session [2845,2860]
===
match
---
expr_stmt [44026,44046]
expr_stmt [44026,44046]
===
match
---
trailer [58919,58938]
trailer [58931,58950]
===
match
---
name: str [43110,43113]
name: str [43110,43113]
===
match
---
expr_stmt [58070,58115]
expr_stmt [58082,58127]
===
match
---
name: str [79642,79645]
name: str [79654,79657]
===
match
---
trailer [79666,79672]
trailer [79678,79684]
===
match
---
operator: = [8283,8284]
operator: = [8283,8284]
===
match
---
name: xcom [2145,2149]
name: xcom [2145,2149]
===
match
---
name: provide_session [25970,25985]
name: provide_session [25970,25985]
===
match
---
argument [57013,57034]
argument [57025,57046]
===
match
---
simple_stmt [15809,16364]
simple_stmt [15809,16364]
===
match
---
operator: , [54745,54746]
operator: , [54745,54746]
===
match
---
operator: , [42244,42245]
operator: , [42244,42245]
===
match
---
return_stmt [26576,26587]
return_stmt [26576,26587]
===
match
---
decorator [14172,14191]
decorator [14172,14191]
===
match
---
name: test_mode [41594,41603]
name: test_mode [41594,41603]
===
match
---
atom_expr [53751,53760]
atom_expr [53751,53760]
===
match
---
return_stmt [4138,4149]
return_stmt [4138,4149]
===
match
---
operator: , [30647,30648]
operator: , [30647,30648]
===
match
---
operator: = [35030,35031]
operator: = [35030,35031]
===
match
---
name: Session [1448,1455]
name: Session [1448,1455]
===
match
---
name: execution_date [21036,21050]
name: execution_date [21036,21050]
===
match
---
operator: } [59838,59839]
operator: } [59850,59851]
===
match
---
name: AirflowSensorTimeout [1726,1746]
name: AirflowSensorTimeout [1726,1746]
===
match
---
operator: = [57094,57095]
operator: = [57106,57107]
===
match
---
expr_stmt [75375,75421]
expr_stmt [75387,75433]
===
match
---
name: AirflowFailException [45169,45189]
name: AirflowFailException [45169,45189]
===
match
---
trailer [79986,80003]
trailer [79998,80015]
===
match
---
name: connection [1914,1924]
name: connection [1914,1924]
===
match
---
name: key [72748,72751]
name: key [72760,72763]
===
match
---
atom_expr [3760,3942]
atom_expr [3760,3942]
===
match
---
trailer [46412,46419]
trailer [46412,46419]
===
match
---
operator: -> [30125,30127]
operator: -> [30125,30127]
===
match
---
operator: , [67471,67472]
operator: , [67483,67484]
===
match
---
atom_expr [11156,11175]
atom_expr [11156,11175]
===
match
---
atom_expr [78441,78457]
atom_expr [78453,78469]
===
match
---
name: tis [76494,76497]
name: tis [76506,76509]
===
match
---
operator: @ [79201,79202]
operator: @ [79213,79214]
===
match
---
trailer [70264,70273]
trailer [70276,70285]
===
match
---
name: str [79008,79011]
name: str [79020,79023]
===
match
---
trailer [69202,69308]
trailer [69214,69320]
===
match
---
name: context [3641,3648]
name: context [3641,3648]
===
match
---
name: error_file [45474,45484]
name: error_file [45474,45484]
===
match
---
expr_stmt [48165,48229]
expr_stmt [48165,48229]
===
match
---
name: reschedule_exception [53915,53935]
name: reschedule_exception [53915,53935]
===
match
---
name: should_pass_filepath [15681,15701]
name: should_pass_filepath [15681,15701]
===
match
---
operator: = [21536,21537]
operator: = [21536,21537]
===
match
---
simple_stmt [1358,1413]
simple_stmt [1358,1413]
===
match
---
trailer [13060,13066]
trailer [13060,13066]
===
match
---
name: log [47569,47572]
name: log [47569,47572]
===
match
---
name: str [79811,79814]
name: str [79823,79826]
===
match
---
trailer [30393,30397]
trailer [30393,30397]
===
match
---
name: are_dependencies_met [39353,39373]
name: are_dependencies_met [39353,39373]
===
match
---
atom_expr [66869,66884]
atom_expr [66881,66896]
===
match
---
operator: , [45472,45473]
operator: , [45472,45473]
===
match
---
name: Union [1097,1102]
name: Union [1097,1102]
===
match
---
arglist [11530,11559]
arglist [11530,11559]
===
match
---
operator: -> [16944,16946]
operator: -> [16944,16946]
===
match
---
operator: = [57023,57024]
operator: = [57035,57036]
===
match
---
name: warnings [7719,7727]
name: warnings [7719,7727]
===
match
---
simple_stmt [2357,2434]
simple_stmt [2357,2434]
===
match
---
number: 1 [41508,41509]
number: 1 [41508,41509]
===
match
---
suite [46075,46155]
suite [46075,46155]
===
match
---
operator: == [50871,50873]
operator: == [50871,50873]
===
match
---
simple_stmt [70544,70591]
simple_stmt [70556,70603]
===
match
---
atom_expr [55473,55488]
atom_expr [55485,55500]
===
match
---
name: dag_run [81064,81071]
name: dag_run [81076,81083]
===
match
---
simple_stmt [54253,54323]
simple_stmt [54253,54323]
===
match
---
trailer [70116,70120]
trailer [70128,70132]
===
match
---
name: task [5637,5641]
name: task [5637,5641]
===
match
---
simple_stmt [70236,70298]
simple_stmt [70248,70310]
===
match
---
operator: , [29387,29388]
operator: , [29387,29388]
===
match
---
simple_stmt [56959,57053]
simple_stmt [56971,57065]
===
match
---
trailer [54793,54823]
trailer [54789,54835]
===
match
---
decorated [9618,9771]
decorated [9618,9771]
===
match
---
trailer [44000,44017]
trailer [44000,44017]
===
match
---
atom_expr [12267,12276]
atom_expr [12267,12276]
===
match
---
expr_stmt [22435,22469]
expr_stmt [22435,22469]
===
match
---
operator: , [33002,33003]
operator: , [33002,33003]
===
match
---
operator: + [19933,19934]
operator: + [19933,19934]
===
match
---
atom_expr [58129,58160]
atom_expr [58141,58172]
===
match
---
name: hasattr [78728,78735]
name: hasattr [78740,78747]
===
match
---
return_stmt [60896,60946]
return_stmt [60908,60958]
===
match
---
arglist [4461,4470]
arglist [4461,4470]
===
match
---
expr_stmt [60533,60562]
expr_stmt [60545,60574]
===
match
---
annassign [78402,78432]
annassign [78414,78444]
===
match
---
atom_expr [66143,66155]
atom_expr [66155,66167]
===
match
---
operator: @ [60678,60679]
operator: @ [60690,60691]
===
match
---
operator: , [30117,30118]
operator: , [30117,30118]
===
match
---
except_clause [64834,64886]
except_clause [64846,64898]
===
match
---
tfpdef [4283,4298]
tfpdef [4283,4298]
===
match
---
tfpdef [16694,16705]
tfpdef [16694,16705]
===
match
---
name: os [69251,69253]
name: os [69263,69265]
===
match
---
operator: , [77157,77158]
operator: , [77169,77170]
===
match
---
dotted_name [3005,3033]
dotted_name [3005,3033]
===
match
---
name: session [54547,54554]
name: session [54547,54554]
===
match
---
operator: = [10837,10838]
operator: = [10837,10838]
===
match
---
atom_expr [33020,33037]
atom_expr [33020,33037]
===
match
---
name: tis [76121,76124]
name: tis [76133,76136]
===
match
---
atom_expr [11225,11240]
atom_expr [11225,11240]
===
match
---
trailer [20141,20143]
trailer [20141,20143]
===
match
---
name: RenderedTaskInstanceFields [65458,65484]
name: RenderedTaskInstanceFields [65470,65496]
===
match
---
operator: { [47093,47094]
operator: { [47093,47094]
===
match
---
name: add [6307,6310]
name: add [6307,6310]
===
match
---
name: Optional [1080,1088]
name: Optional [1080,1088]
===
match
---
name: ti [26597,26599]
name: ti [26597,26599]
===
match
---
name: ti [79014,79016]
name: ti [79026,79028]
===
match
---
trailer [39352,39373]
trailer [39352,39373]
===
match
---
name: pendulum [62847,62855]
name: pendulum [62859,62867]
===
match
---
operator: , [15896,15897]
operator: , [15896,15897]
===
match
---
expr_stmt [22674,22701]
expr_stmt [22674,22701]
===
match
---
name: dag_id [74682,74688]
name: dag_id [74694,74700]
===
match
---
suite [56155,56246]
suite [56167,56258]
===
match
---
name: ignore_all_deps [16530,16545]
name: ignore_all_deps [16530,16545]
===
match
---
string: "execution date %s has no timezone information. Using default from dag or system" [12502,12583]
string: "execution date %s has no timezone information. Using default from dag or system" [12502,12583]
===
match
---
decorator [31247,31257]
decorator [31247,31257]
===
match
---
name: session [7571,7578]
name: session [7571,7578]
===
match
---
expr_stmt [51040,51068]
expr_stmt [51040,51068]
===
match
---
name: Log [41629,41632]
name: Log [41629,41632]
===
match
---
argument [47528,47550]
argument [47528,47550]
===
match
---
name: self [52979,52983]
name: self [52979,52983]
===
match
---
name: self [21525,21529]
name: self [21525,21529]
===
match
---
name: task [28123,28127]
name: task [28123,28127]
===
match
---
arglist [48903,48933]
arglist [48903,48933]
===
match
---
trailer [11162,11175]
trailer [11162,11175]
===
match
---
operator: , [16298,16299]
operator: , [16298,16299]
===
match
---
trailer [58296,58299]
trailer [58308,58311]
===
match
---
name: get [61827,61830]
name: get [61839,61842]
===
match
---
name: dep [33378,33381]
name: dep [33378,33381]
===
match
---
name: ti_hash [35046,35053]
name: ti_hash [35046,35053]
===
match
---
trailer [50470,50479]
trailer [50470,50479]
===
match
---
trailer [57885,57900]
trailer [57897,57912]
===
match
---
trailer [49024,49040]
trailer [49024,49040]
===
match
---
operator: , [10522,10523]
operator: , [10522,10523]
===
match
---
name: self [33851,33855]
name: self [33851,33855]
===
match
---
name: session [53694,53701]
name: session [53694,53701]
===
match
---
annassign [78555,78576]
annassign [78567,78588]
===
match
---
operator: = [44532,44533]
operator: = [44532,44533]
===
match
---
name: dag_id [15864,15870]
name: dag_id [15864,15870]
===
match
---
suite [80800,80830]
suite [80812,80842]
===
match
---
name: run_as_user [24016,24027]
name: run_as_user [24016,24027]
===
match
---
atom_expr [27114,27138]
atom_expr [27114,27138]
===
match
---
argument [69575,69590]
argument [69587,69602]
===
match
---
name: isoformat [19843,19852]
name: isoformat [19843,19852]
===
match
---
trailer [26930,26933]
trailer [26930,26933]
===
match
---
name: self [53207,53211]
name: self [53207,53211]
===
match
---
operator: = [4734,4735]
operator: = [4734,4735]
===
match
---
name: test_mode [54668,54677]
name: test_mode [54668,54677]
===
match
---
name: e [45550,45551]
name: e [45550,45551]
===
match
---
simple_stmt [58992,59014]
simple_stmt [59004,59026]
===
match
---
simple_stmt [787,805]
simple_stmt [787,805]
===
match
---
name: error [51567,51572]
name: error [51567,51572]
===
match
---
trailer [22116,22120]
trailer [22116,22120]
===
match
---
atom [8285,8572]
atom [8285,8572]
===
match
---
operator: = [21274,21275]
operator: = [21274,21275]
===
match
---
name: nullable [11016,11024]
name: nullable [11016,11024]
===
match
---
operator: , [1632,1633]
operator: , [1632,1633]
===
match
---
name: airflow [1584,1591]
name: airflow [1584,1591]
===
match
---
arglist [59658,59665]
arglist [59670,59677]
===
match
---
simple_stmt [45146,45153]
simple_stmt [45146,45153]
===
match
---
simple_stmt [15503,15548]
simple_stmt [15503,15548]
===
match
---
name: TaskInstance [26718,26730]
name: TaskInstance [26718,26730]
===
match
---
testlist_comp [19066,19089]
testlist_comp [19066,19089]
===
match
---
trailer [31806,31814]
trailer [31806,31814]
===
match
---
trailer [70273,70280]
trailer [70285,70292]
===
match
---
simple_stmt [52963,53038]
simple_stmt [52963,53038]
===
match
---
trailer [26620,26626]
trailer [26620,26626]
===
match
---
name: error_file [43089,43099]
name: error_file [43089,43099]
===
match
---
name: task [44448,44452]
name: task [44448,44452]
===
match
---
name: e [65854,65855]
name: e [65866,65867]
===
match
---
trailer [54525,54530]
trailer [54525,54530]
===
match
---
fstring_string: &execution_date= [20339,20355]
fstring_string: &execution_date= [20339,20355]
===
match
---
name: prev_ti [30450,30457]
name: prev_ti [30450,30457]
===
match
---
atom [77954,77984]
atom [77966,77996]
===
match
---
trailer [59363,59372]
trailer [59375,59384]
===
match
---
atom_expr [41308,41324]
atom_expr [41308,41324]
===
match
---
atom [68362,68675]
atom [68374,68687]
===
match
---
operator: = [39183,39184]
operator: = [39183,39184]
===
match
---
operator: = [49831,49832]
operator: = [49831,49832]
===
match
---
trailer [79113,79121]
trailer [79125,79133]
===
match
---
name: task [53200,53204]
name: task [53200,53204]
===
match
---
arith_expr [35488,35521]
arith_expr [35488,35521]
===
match
---
trailer [19827,19842]
trailer [19827,19842]
===
match
---
name: task_id [16438,16445]
name: task_id [16438,16445]
===
match
---
atom_expr [39879,39894]
atom_expr [39879,39894]
===
match
---
simple_stmt [59334,59385]
simple_stmt [59346,59397]
===
match
---
operator: , [29907,29908]
operator: , [29907,29908]
===
match
---
decorated [25969,26991]
decorated [25969,26991]
===
match
---
name: models [8070,8076]
name: models [8070,8076]
===
match
---
operator: = [72406,72407]
operator: = [72418,72419]
===
match
---
operator: , [64137,64138]
operator: , [64149,64150]
===
match
---
expr_stmt [26505,26521]
expr_stmt [26505,26521]
===
match
---
atom_expr [26885,26898]
atom_expr [26885,26898]
===
match
---
name: Optional [79721,79729]
name: Optional [79733,79741]
===
match
---
operator: = [3217,3218]
operator: = [3217,3218]
===
match
---
name: default_html_content [70424,70444]
name: default_html_content [70436,70456]
===
match
---
trailer [22443,22459]
trailer [22443,22459]
===
match
---
name: airflow [81010,81017]
name: airflow [81022,81029]
===
match
---
name: _priority_weight [78949,78965]
name: _priority_weight [78961,78977]
===
match
---
param [12044,12069]
param [12044,12069]
===
match
---
simple_stmt [46245,46263]
simple_stmt [46245,46263]
===
match
---
operator: = [40047,40048]
operator: = [40047,40048]
===
match
---
name: replace [67768,67775]
name: replace [67780,67787]
===
match
---
expr_stmt [23220,23261]
expr_stmt [23220,23261]
===
match
---
name: self [33891,33895]
name: self [33891,33895]
===
match
---
string: """             Wrapper around Connection. This way you can get connections in             templates by using ``{{ conn.conn_id }}`` or             ``{{ conn.get('conn_id') }}``.             """ [61932,62126]
string: """             Wrapper around Connection. This way you can get connections in             templates by using ``{{ conn.conn_id }}`` or             ``{{ conn.get('conn_id') }}``.             """ [61944,62138]
===
match
---
name: task_id [11688,11695]
name: task_id [11688,11695]
===
match
---
operator: , [9414,9415]
operator: , [9414,9415]
===
match
---
tfpdef [54391,54419]
tfpdef [54391,54419]
===
match
---
argument [69220,69277]
argument [69232,69289]
===
match
---
name: ti [26928,26930]
name: ti [26928,26930]
===
match
---
operator: = [14249,14250]
operator: = [14249,14250]
===
match
---
trailer [38372,38398]
trailer [38372,38398]
===
match
---
trailer [40788,40794]
trailer [40788,40794]
===
match
---
trailer [5327,5333]
trailer [5327,5333]
===
match
---
name: ti [5367,5369]
name: ti [5367,5369]
===
match
---
param [57132,57136]
param [57144,57148]
===
match
---
name: ti [6273,6275]
name: ti [6273,6275]
===
match
---
name: send_email [70806,70816]
name: send_email [70818,70828]
===
match
---
name: force_fail [56888,56898]
name: force_fail [56900,56910]
===
match
---
dotted_name [2245,2259]
dotted_name [2245,2259]
===
match
---
name: dag_id [24528,24534]
name: dag_id [24528,24534]
===
match
---
trailer [51317,51337]
trailer [51317,51337]
===
match
---
trailer [75703,75717]
trailer [75715,75729]
===
match
---
atom_expr [54169,54185]
atom_expr [54169,54185]
===
match
---
operator: = [59531,59532]
operator: = [59543,59544]
===
match
---
name: task [24072,24076]
name: task [24072,24076]
===
match
---
trailer [75274,75283]
trailer [75286,75295]
===
match
---
trailer [33787,33794]
trailer [33787,33794]
===
match
---
suite [75362,75495]
suite [75374,75507]
===
match
---
name: cmd [19215,19218]
name: cmd [19215,19218]
===
match
---
trailer [71050,71061]
trailer [71062,71073]
===
match
---
trailer [78876,78881]
trailer [78888,78893]
===
match
---
string: 'ds' [62771,62775]
string: 'ds' [62783,62787]
===
match
---
name: self [72467,72471]
name: self [72479,72483]
===
match
---
arglist [77599,77758]
arglist [77611,77770]
===
match
---
trailer [53705,53976]
trailer [53705,53976]
===
match
---
trailer [24475,24481]
trailer [24475,24481]
===
match
---
trailer [15828,15845]
trailer [15828,15845]
===
match
---
expr_stmt [10929,10971]
expr_stmt [10929,10971]
===
match
---
operator: = [52243,52244]
operator: = [52243,52244]
===
match
---
name: state [27052,27057]
name: state [27052,27057]
===
match
---
name: timezone [12750,12758]
name: timezone [12750,12758]
===
match
---
name: queue [23850,23855]
name: queue [23850,23855]
===
match
---
trailer [44234,44276]
trailer [44234,44276]
===
match
---
name: self [45841,45845]
name: self [45841,45845]
===
match
---
name: str [78598,78601]
name: str [78610,78613]
===
match
---
trailer [7373,7375]
trailer [7373,7375]
===
match
---
string: """Run TaskInstance""" [52052,52074]
string: """Run TaskInstance""" [52052,52074]
===
match
---
string: '%sMarking task as %s.' [42467,42490]
string: '%sMarking task as %s.' [42467,42490]
===
match
---
comparison [26670,26704]
comparison [26670,26704]
===
match
---
return_stmt [39526,39538]
return_stmt [39526,39538]
===
match
---
trailer [55445,55504]
trailer [55457,55516]
===
match
---
name: execution_date [12720,12734]
name: execution_date [12720,12734]
===
match
---
expr_stmt [10900,10924]
expr_stmt [10900,10924]
===
match
---
raise_stmt [49368,49450]
raise_stmt [49368,49450]
===
match
---
operator: , [4409,4410]
operator: , [4409,4410]
===
match
---
simple_stmt [57483,57519]
simple_stmt [57495,57531]
===
match
---
atom_expr [68894,69159]
atom_expr [68906,69171]
===
match
---
suite [71444,72585]
suite [71456,72597]
===
match
---
expr_stmt [7645,7671]
expr_stmt [7645,7671]
===
match
---
name: session [25641,25648]
name: session [25641,25648]
===
match
---
fstring_start: f" [20300,20302]
fstring_start: f" [20300,20302]
===
match
---
name: session [24661,24668]
name: session [24661,24668]
===
match
---
expr_stmt [11219,11240]
expr_stmt [11219,11240]
===
match
---
name: update [69690,69696]
name: update [69702,69708]
===
match
---
dotted_name [2279,2292]
dotted_name [2279,2292]
===
match
---
parameters [31292,31298]
parameters [31292,31298]
===
match
---
trailer [5618,5636]
trailer [5618,5636]
===
match
---
operator: , [52162,52163]
operator: , [52162,52163]
===
match
---
simple_stmt [35895,35986]
simple_stmt [35895,35986]
===
match
---
operator: = [51776,51777]
operator: = [51776,51777]
===
match
---
name: UtcDateTime [10625,10636]
name: UtcDateTime [10625,10636]
===
match
---
string: '' [59159,59161]
string: '' [59171,59173]
===
match
---
suite [20534,21225]
suite [20534,21225]
===
match
---
operator: , [59738,59739]
operator: , [59750,59751]
===
match
---
trailer [6227,6233]
trailer [6227,6233]
===
match
---
atom_expr [22690,22701]
atom_expr [22690,22701]
===
match
---
atom_expr [59907,59933]
atom_expr [59919,59945]
===
match
---
decorated [35991,36474]
decorated [35991,36474]
===
match
---
trailer [77212,77220]
trailer [77224,77232]
===
match
---
expr_stmt [40375,40665]
expr_stmt [40375,40665]
===
match
---
name: task [23976,23980]
name: task [23976,23980]
===
match
---
expr_stmt [20153,20197]
expr_stmt [20153,20197]
===
match
---
comparison [51438,51472]
comparison [51438,51472]
===
match
---
simple_stmt [60407,60423]
simple_stmt [60419,60435]
===
match
---
operator: , [63898,63899]
operator: , [63910,63911]
===
match
---
trailer [60590,60594]
trailer [60602,60606]
===
match
---
operator: - [69859,69860]
operator: - [69871,69872]
===
match
---
name: self [60016,60020]
name: self [60028,60032]
===
match
---
atom_expr [24661,24677]
atom_expr [24661,24677]
===
match
---
expr_stmt [59811,59869]
expr_stmt [59823,59881]
===
match
---
name: Integer [1305,1312]
name: Integer [1305,1312]
===
match
---
trailer [66499,66505]
trailer [66511,66517]
===
match
---
name: on_retry_callback [51594,51611]
name: on_retry_callback [51594,51611]
===
match
---
number: 1 [5749,5750]
number: 1 [5749,5750]
===
match
---
atom_expr [72358,72584]
atom_expr [72370,72596]
===
match
---
name: verbose [51678,51685]
name: verbose [51678,51685]
===
match
---
arglist [59544,59551]
arglist [59556,59563]
===
match
---
arith_expr [14146,14166]
arith_expr [14146,14166]
===
match
---
expr_stmt [51544,51572]
expr_stmt [51544,51572]
===
match
---
trailer [36354,36361]
trailer [36354,36361]
===
match
---
name: dag_id [36370,36376]
name: dag_id [36370,36376]
===
match
---
name: state [14071,14076]
name: state [14071,14076]
===
match
---
operator: , [20184,20185]
operator: , [20184,20185]
===
match
---
name: first [76624,76629]
name: first [76636,76641]
===
match
---
operator: , [45873,45874]
operator: , [45873,45874]
===
match
---
atom_expr [67706,67727]
atom_expr [67718,67739]
===
match
---
trailer [46419,46421]
trailer [46419,46421]
===
match
---
expr_stmt [31025,31085]
expr_stmt [31025,31085]
===
match
---
simple_stmt [54169,54191]
simple_stmt [54169,54191]
===
match
---
suite [70986,71253]
suite [70998,71265]
===
match
---
name: state [6146,6151]
name: state [6146,6151]
===
match
---
name: dag_id [8405,8411]
name: dag_id [8405,8411]
===
match
---
simple_stmt [12926,12963]
simple_stmt [12926,12963]
===
match
---
operator: == [38641,38643]
operator: == [38641,38643]
===
match
---
operator: = [38392,38393]
operator: = [38392,38393]
===
match
---
name: AirflowException [46862,46878]
name: AirflowException [46862,46878]
===
match
---
parameters [62335,62419]
parameters [62347,62431]
===
match
---
name: String [1326,1332]
name: String [1326,1332]
===
match
---
or_test [25431,25495]
or_test [25431,25495]
===
match
---
argument [56992,57011]
argument [57004,57023]
===
match
---
name: provide_session [21231,21246]
name: provide_session [21231,21246]
===
match
---
operator: != [15602,15604]
operator: != [15602,15604]
===
match
---
name: raw [16268,16271]
name: raw [16268,16271]
===
match
---
trailer [53058,53064]
trailer [53058,53064]
===
match
---
operator: = [25386,25387]
operator: = [25386,25387]
===
match
---
expr_stmt [59334,59384]
expr_stmt [59346,59396]
===
match
---
operator: , [72544,72545]
operator: , [72556,72557]
===
match
---
trailer [55096,55115]
trailer [55108,55127]
===
match
---
name: self [56695,56699]
name: self [56707,56711]
===
match
---
operator: , [54537,54538]
operator: , [54537,54538]
===
match
---
trailer [47705,47711]
trailer [47705,47711]
===
match
---
argument [50018,50033]
argument [50018,50033]
===
match
---
trailer [70910,70915]
trailer [70922,70927]
===
match
---
name: Index [1298,1303]
name: Index [1298,1303]
===
match
---
if_stmt [14063,14131]
if_stmt [14063,14131]
===
match
---
name: NamedTuple [1068,1078]
name: NamedTuple [1068,1078]
===
match
---
name: prev_execution_date [59491,59510]
name: prev_execution_date [59503,59522]
===
match
---
name: str [16425,16428]
name: str [16425,16428]
===
match
---
name: __getattr__ [61307,61318]
name: __getattr__ [61319,61330]
===
match
---
atom_expr [44247,44258]
atom_expr [44247,44258]
===
match
---
expr_stmt [21145,21164]
expr_stmt [21145,21164]
===
match
---
simple_stmt [3407,3581]
simple_stmt [3407,3581]
===
match
---
name: pendulum [59197,59205]
name: pendulum [59209,59217]
===
match
---
trailer [57211,57216]
trailer [57223,57228]
===
match
---
param [36682,36713]
param [36682,36713]
===
match
---
atom_expr [6262,6271]
atom_expr [6262,6271]
===
match
---
name: task_id [26731,26738]
name: task_id [26731,26738]
===
match
---
parameters [78270,78294]
parameters [78282,78306]
===
match
---
parameters [67466,67483]
parameters [67478,67495]
===
match
---
name: bool [36927,36931]
name: bool [36927,36931]
===
match
---
trailer [52705,52933]
trailer [52705,52933]
===
match
---
decorator [24949,24966]
decorator [24949,24966]
===
match
---
expr_stmt [42266,42300]
expr_stmt [42266,42300]
===
match
---
simple_stmt [34669,34947]
simple_stmt [34669,34947]
===
match
---
name: parse [1115,1120]
name: parse [1115,1120]
===
match
---
operator: , [4466,4467]
operator: , [4466,4467]
===
match
---
name: str [4313,4316]
name: str [4313,4316]
===
match
---
suite [29514,29976]
suite [29514,29976]
===
match
---
simple_stmt [79433,79455]
simple_stmt [79445,79467]
===
match
---
suite [77532,77821]
suite [77544,77833]
===
match
---
name: log [3297,3300]
name: log [3297,3300]
===
match
---
trailer [67070,67086]
trailer [67082,67098]
===
match
---
name: Stats [2300,2305]
name: Stats [2300,2305]
===
match
---
trailer [32700,32704]
trailer [32700,32704]
===
match
---
param [60756,60815]
param [60768,60827]
===
match
---
suite [49120,49451]
suite [49120,49451]
===
match
---
operator: = [51061,51062]
operator: = [51061,51062]
===
match
---
operator: , [43005,43006]
operator: , [43005,43006]
===
match
---
name: dag_run [60071,60078]
name: dag_run [60083,60090]
===
match
---
parameters [65942,65965]
parameters [65954,65977]
===
match
---
operator: = [36888,36889]
operator: = [36888,36889]
===
match
---
arglist [40910,41136]
arglist [40910,41136]
===
match
---
name: instance [8245,8253]
name: instance [8245,8253]
===
match
---
name: params [63145,63151]
name: params [63157,63163]
===
match
---
name: utcnow [41247,41253]
name: utcnow [41247,41253]
===
match
---
name: State [35916,35921]
name: State [35916,35921]
===
match
---
trailer [42814,42829]
trailer [42814,42829]
===
match
---
simple_stmt [51589,51621]
simple_stmt [51589,51621]
===
match
---
name: clear_xcom_data [24206,24221]
name: clear_xcom_data [24206,24221]
===
match
---
operator: @ [79294,79295]
operator: @ [79306,79307]
===
match
---
operator: , [52816,52817]
operator: , [52816,52817]
===
match
---
arglist [23446,23479]
arglist [23446,23479]
===
match
---
name: lock_for_update [44883,44898]
name: lock_for_update [44883,44898]
===
match
---
name: self [55490,55494]
name: self [55502,55506]
===
match
---
trailer [47240,47301]
trailer [47240,47301]
===
match
---
name: error [54740,54745]
name: error [54740,54745]
===
match
---
operator: , [45099,45100]
operator: , [45099,45100]
===
match
---
operator: , [16013,16014]
operator: , [16013,16014]
===
match
---
suite [36058,36474]
suite [36058,36474]
===
match
---
name: render [70321,70327]
name: render [70333,70339]
===
match
---
trailer [51993,51998]
trailer [51993,51998]
===
match
---
atom_expr [59882,59893]
atom_expr [59894,59905]
===
match
---
parameters [28987,28993]
parameters [28987,28993]
===
match
---
trailer [71124,71138]
trailer [71136,71150]
===
match
---
name: _start_date [78446,78457]
name: _start_date [78458,78469]
===
match
---
name: self [43923,43927]
name: self [43923,43927]
===
match
---
name: DagRun [36320,36326]
name: DagRun [36320,36326]
===
match
---
name: render [70477,70483]
name: render [70489,70495]
===
match
---
operator: -> [9162,9164]
operator: -> [9162,9164]
===
match
---
trailer [75401,75413]
trailer [75413,75425]
===
match
---
simple_stmt [32620,32635]
simple_stmt [32620,32635]
===
match
---
name: cfg_path [16906,16914]
name: cfg_path [16906,16914]
===
match
---
operator: = [42965,42966]
operator: = [42965,42966]
===
match
---
name: task_id [24569,24576]
name: task_id [24569,24576]
===
match
---
string: 'Mark success: <a href="{{ti.mark_success_url}}">Link</a><br>' [68603,68665]
string: 'Mark success: <a href="{{ti.mark_success_url}}">Link</a><br>' [68615,68677]
===
match
---
name: str [78357,78360]
name: str [78369,78372]
===
match
---
name: Optional [78696,78704]
name: Optional [78708,78716]
===
match
---
simple_stmt [45509,45515]
simple_stmt [45509,45515]
===
match
---
trailer [64678,64684]
trailer [64690,64696]
===
match
---
name: execution_date [12931,12945]
name: execution_date [12931,12945]
===
match
---
name: UP_FOR_RETRY [51380,51392]
name: UP_FOR_RETRY [51380,51392]
===
match
---
operator: = [28666,28667]
operator: = [28666,28667]
===
match
---
trailer [53614,53621]
trailer [53614,53621]
===
match
---
name: dag_id [26683,26689]
name: dag_id [26683,26689]
===
match
---
name: render [69370,69376]
name: render [69382,69388]
===
match
---
atom_expr [78304,78316]
atom_expr [78316,78328]
===
match
---
tfpdef [43015,43036]
tfpdef [43015,43036]
===
match
---
expr_stmt [23314,23347]
expr_stmt [23314,23347]
===
match
---
try_stmt [4432,4663]
try_stmt [4432,4663]
===
match
---
name: get_template_context [51001,51021]
name: get_template_context [51001,51021]
===
match
---
decorator [3333,3360]
decorator [3333,3360]
===
match
---
except_clause [70865,70881]
except_clause [70877,70893]
===
match
---
argument [16027,16060]
argument [16027,16060]
===
match
---
suite [18969,19023]
suite [18969,19023]
===
match
---
simple_stmt [59397,59439]
simple_stmt [59409,59451]
===
match
---
try_stmt [27663,28006]
try_stmt [27663,28006]
===
match
---
simple_stmt [7456,7484]
simple_stmt [7456,7484]
===
match
---
argument [11346,11362]
argument [11346,11362]
===
match
---
if_stmt [3718,3943]
if_stmt [3718,3943]
===
match
---
operator: , [10503,10504]
operator: , [10503,10504]
===
match
---
trailer [77936,77998]
trailer [77948,78010]
===
match
---
name: first_task_id [77224,77237]
name: first_task_id [77236,77249]
===
match
---
name: property [79128,79136]
name: property [79140,79148]
===
match
---
trailer [56584,56588]
trailer [56596,56600]
===
match
---
arith_expr [20213,20462]
arith_expr [20213,20462]
===
match
---
name: context [51544,51551]
name: context [51544,51551]
===
match
---
simple_stmt [76653,76683]
simple_stmt [76665,76695]
===
match
---
name: first [76586,76591]
name: first [76598,76603]
===
match
---
trailer [56634,56640]
trailer [56646,56652]
===
match
---
name: _end_date [79445,79454]
name: _end_date [79457,79466]
===
match
---
simple_stmt [79586,79605]
simple_stmt [79598,79617]
===
match
---
argument [53107,53118]
argument [53107,53118]
===
match
---
parameters [79711,79717]
parameters [79723,79729]
===
match
---
operator: , [23512,23513]
operator: , [23512,23513]
===
match
---
operator: , [45945,45946]
operator: , [45945,45946]
===
match
---
name: self [33517,33521]
name: self [33517,33521]
===
match
---
trailer [75873,75879]
trailer [75885,75891]
===
match
---
operator: , [52457,52458]
operator: , [52457,52458]
===
match
---
operator: = [6086,6087]
operator: = [6086,6087]
===
match
---
comp_op [51461,51467]
comp_op [51461,51467]
===
match
---
name: AirflowException [1616,1632]
name: AirflowException [1616,1632]
===
match
---
decorator [16369,16383]
decorator [16369,16383]
===
match
---
name: ignore_task_deps [39297,39313]
name: ignore_task_deps [39297,39313]
===
match
---
name: email_on_retry [56339,56353]
name: email_on_retry [56351,56365]
===
match
---
name: execution_date [79219,79233]
name: execution_date [79231,79245]
===
match
---
name: query [20860,20865]
name: query [20860,20865]
===
match
---
name: TaskInstance [22332,22344]
name: TaskInstance [22332,22344]
===
match
---
atom_expr [5451,5460]
atom_expr [5451,5460]
===
match
---
simple_stmt [78621,78669]
simple_stmt [78633,78681]
===
match
---
trailer [56338,56353]
trailer [56350,56365]
===
match
---
funcdef [20489,21225]
funcdef [20489,21225]
===
match
---
name: error [54391,54396]
name: error [54391,54396]
===
match
---
atom_expr [16916,16929]
atom_expr [16916,16929]
===
match
---
arglist [71211,71251]
arglist [71223,71263]
===
match
---
name: relationship [81128,81140]
name: relationship [81140,81152]
===
match
---
trailer [58765,58780]
trailer [58777,58792]
===
match
---
return_stmt [29927,29975]
return_stmt [29927,29975]
===
match
---
name: utils [2567,2572]
name: utils [2567,2572]
===
match
---
name: dag [15653,15656]
name: dag [15653,15656]
===
match
---
operator: -> [66264,66266]
operator: -> [66276,66278]
===
match
---
trailer [42282,42300]
trailer [42282,42300]
===
match
---
name: task [50299,50303]
name: task [50299,50303]
===
match
---
trailer [66077,66083]
trailer [66089,66095]
===
match
---
atom_expr [5256,5293]
atom_expr [5256,5293]
===
match
---
operator: = [44038,44039]
operator: = [44038,44039]
===
match
---
argument [16074,16119]
argument [16074,16119]
===
match
---
name: self [25388,25392]
name: self [25388,25392]
===
match
---
name: add [53702,53705]
name: add [53702,53705]
===
match
---
dotted_name [1838,1857]
dotted_name [1838,1857]
===
match
---
name: self [21461,21465]
name: self [21461,21465]
===
match
---
name: self [9091,9095]
name: self [9091,9095]
===
match
---
name: Optional [3983,3991]
name: Optional [3983,3991]
===
match
---
atom_expr [70112,70134]
atom_expr [70124,70146]
===
match
---
trailer [53354,53356]
trailer [53354,53356]
===
match
---
trailer [12930,12945]
trailer [12930,12945]
===
match
---
atom_expr [44393,44453]
atom_expr [44393,44453]
===
match
---
name: bool [36775,36779]
name: bool [36775,36779]
===
match
---
name: test_mode [52421,52430]
name: test_mode [52421,52430]
===
match
---
atom_expr [32983,33002]
atom_expr [32983,33002]
===
match
---
trailer [22692,22701]
trailer [22692,22701]
===
match
---
operator: = [16183,16184]
operator: = [16183,16184]
===
match
---
decorator [57268,57285]
decorator [57280,57297]
===
match
---
atom_expr [10936,10971]
atom_expr [10936,10971]
===
match
---
simple_stmt [49299,49316]
simple_stmt [49299,49316]
===
match
---
operator: + [41132,41133]
operator: + [41132,41133]
===
match
---
name: self [71046,71050]
name: self [71058,71062]
===
match
---
operator: , [54877,54878]
operator: , [54889,54890]
===
match
---
operator: , [61428,61429]
operator: , [61440,61441]
===
match
---
simple_stmt [53694,53977]
simple_stmt [53694,53977]
===
match
---
arglist [20917,21074]
arglist [20917,21074]
===
match
---
name: info [42449,42453]
name: info [42449,42453]
===
match
---
name: ti [22920,22922]
name: ti [22920,22922]
===
match
---
try_stmt [52615,53120]
try_stmt [52615,53120]
===
match
---
name: fd [4468,4470]
name: fd [4468,4470]
===
match
---
simple_stmt [10828,10860]
simple_stmt [10828,10860]
===
match
---
atom [58184,58220]
atom [58196,58232]
===
match
---
name: prev_attempted_tries [14280,14300]
name: prev_attempted_tries [14280,14300]
===
match
---
trailer [12153,12160]
trailer [12153,12160]
===
match
---
operator: , [67718,67719]
operator: , [67730,67731]
===
match
---
name: task [57849,57853]
name: task [57861,57865]
===
match
---
arglist [60056,60086]
arglist [60068,60098]
===
match
---
trailer [12209,12214]
trailer [12209,12214]
===
match
---
operator: + [38813,38814]
operator: + [38813,38814]
===
match
---
name: self [9553,9557]
name: self [9553,9557]
===
match
---
simple_stmt [75061,75226]
simple_stmt [75073,75238]
===
match
---
trailer [34865,34872]
trailer [34865,34872]
===
match
---
atom [75676,75943]
atom [75688,75955]
===
match
---
tfpdef [16655,16676]
tfpdef [16655,16676]
===
match
---
number: 2 [34605,34606]
number: 2 [34605,34606]
===
match
---
name: str [61364,61367]
name: str [61376,61379]
===
match
---
trailer [9339,9354]
trailer [9339,9354]
===
match
---
name: merge [49279,49284]
name: merge [49279,49284]
===
match
---
atom_expr [75200,75210]
atom_expr [75212,75222]
===
match
---
name: ignore_depends_on_past [51747,51769]
name: ignore_depends_on_past [51747,51769]
===
match
---
name: actual_start_date [53849,53866]
name: actual_start_date [53849,53866]
===
match
---
name: dr [27549,27551]
name: dr [27549,27551]
===
match
---
name: Optional [43101,43109]
name: Optional [43101,43109]
===
match
---
atom_expr [76586,76598]
atom_expr [76598,76610]
===
match
---
arglist [9360,9382]
arglist [9360,9382]
===
match
---
name: pool [38393,38397]
name: pool [38393,38397]
===
match
---
operator: = [68967,68968]
operator: = [68979,68980]
===
match
---
name: quote [1128,1133]
name: quote [1128,1133]
===
match
---
arith_expr [14912,14932]
arith_expr [14912,14932]
===
match
---
atom [68729,68741]
atom [68741,68753]
===
match
---
name: v [47669,47670]
name: v [47669,47670]
===
match
---
trailer [32741,32765]
trailer [32741,32765]
===
match
---
operator: , [29361,29362]
operator: , [29361,29362]
===
match
---
trailer [59657,59666]
trailer [59669,59678]
===
match
---
trailer [80560,80567]
trailer [80572,80579]
===
match
---
operator: , [45455,45456]
operator: , [45455,45456]
===
match
---
simple_stmt [54858,54886]
simple_stmt [54870,54898]
===
match
---
string: "CHECK AND CHANGE" [52567,52585]
string: "CHECK AND CHANGE" [52567,52585]
===
match
---
name: test_mode [53551,53560]
name: test_mode [53551,53560]
===
match
---
import_from [2601,2657]
import_from [2601,2657]
===
match
---
name: signal [46920,46926]
name: signal [46920,46926]
===
match
---
decorator [79848,79858]
decorator [79860,79870]
===
match
---
name: self [72525,72529]
name: self [72537,72541]
===
match
---
argument [16178,16189]
argument [16178,16189]
===
match
---
atom_expr [42175,42194]
atom_expr [42175,42194]
===
match
---
atom_expr [29961,29974]
atom_expr [29961,29974]
===
match
---
name: end_date [25514,25522]
name: end_date [25514,25522]
===
match
---
name: pendulum [31311,31319]
name: pendulum [31311,31319]
===
match
---
suite [68700,69592]
suite [68712,69604]
===
match
---
param [16832,16861]
param [16832,16861]
===
match
---
trailer [40880,40888]
trailer [40880,40888]
===
match
---
operator: , [69080,69081]
operator: , [69092,69093]
===
match
---
trailer [22220,22393]
trailer [22220,22393]
===
match
---
name: airflow [1838,1845]
name: airflow [1838,1845]
===
match
---
return_stmt [61811,61884]
return_stmt [61823,61896]
===
match
---
name: pod_generator [3138,3151]
name: pod_generator [3138,3151]
===
match
---
parameters [71292,71435]
parameters [71304,71447]
===
match
---
trailer [5544,5553]
trailer [5544,5553]
===
match
---
name: AirflowException [65783,65799]
name: AirflowException [65795,65811]
===
match
---
operator: = [14993,14994]
operator: = [14993,14994]
===
match
---
atom_expr [23864,23873]
atom_expr [23864,23873]
===
match
---
name: var [61279,61282]
name: var [61291,61294]
===
match
---
name: str [79573,79576]
name: str [79585,79588]
===
match
---
name: ignore_task_deps [36682,36698]
name: ignore_task_deps [36682,36698]
===
match
---
operator: = [27389,27390]
operator: = [27389,27390]
===
match
---
annassign [79006,79022]
annassign [79018,79034]
===
match
---
name: path [16246,16250]
name: path [16246,16250]
===
match
---
trailer [42132,42136]
trailer [42132,42136]
===
match
---
trailer [24910,24925]
trailer [24910,24925]
===
match
---
name: is_eligible_to_retry [57111,57131]
name: is_eligible_to_retry [57123,57143]
===
match
---
name: state [8611,8616]
name: state [8611,8616]
===
match
---
name: self [53751,53755]
name: self [53751,53755]
===
match
---
name: Tuple [1090,1095]
name: Tuple [1090,1095]
===
match
---
name: utcnow [25255,25261]
name: utcnow [25255,25261]
===
match
---
trailer [25280,25286]
trailer [25280,25286]
===
match
---
trailer [48981,48986]
trailer [48981,48986]
===
match
---
expr_stmt [5659,5686]
expr_stmt [5659,5686]
===
match
---
string: 'dag' [57587,57592]
string: 'dag' [57599,57604]
===
match
---
simple_stmt [15631,15668]
simple_stmt [15631,15668]
===
match
---
atom [19499,19515]
atom [19499,19515]
===
match
---
name: DeprecationWarning [7881,7899]
name: DeprecationWarning [7881,7899]
===
match
---
operator: , [25000,25001]
operator: , [25000,25001]
===
match
---
trailer [3971,3978]
trailer [3971,3978]
===
match
---
trailer [48752,48761]
trailer [48752,48761]
===
match
---
name: self [57393,57397]
name: self [57405,57409]
===
match
---
name: total_seconds [34562,34575]
name: total_seconds [34562,34575]
===
match
---
trailer [32674,32679]
trailer [32674,32679]
===
match
---
if_stmt [58632,58960]
if_stmt [58644,58972]
===
match
---
name: extend [19385,19391]
name: extend [19385,19391]
===
match
---
name: ignore_depends_on_past [36636,36658]
name: ignore_depends_on_past [36636,36658]
===
match
---
operator: , [71236,71237]
operator: , [71248,71249]
===
match
---
suite [19475,19517]
suite [19475,19517]
===
match
---
trailer [7167,7169]
trailer [7167,7169]
===
match
---
name: inlets [62914,62920]
name: inlets [62926,62932]
===
match
---
trailer [7600,7625]
trailer [7600,7625]
===
match
---
trailer [39507,39509]
trailer [39507,39509]
===
match
---
name: String [11051,11057]
name: String [11051,11057]
===
match
---
name: ti [6234,6236]
name: ti [6234,6236]
===
match
---
import_from [2023,2079]
import_from [2023,2079]
===
match
---
name: force_fail [45457,45467]
name: force_fail [45457,45467]
===
match
---
name: job_id [16832,16838]
name: job_id [16832,16838]
===
match
---
simple_stmt [79655,79673]
simple_stmt [79667,79685]
===
match
---
name: self [23431,23435]
name: self [23431,23435]
===
match
---
trailer [75037,75047]
trailer [75049,75059]
===
match
---
name: FAILED [50880,50886]
name: FAILED [50880,50886]
===
match
---
param [21656,21669]
param [21656,21669]
===
match
---
name: jinja_context [69619,69632]
name: jinja_context [69631,69644]
===
match
---
operator: @ [75500,75501]
operator: @ [75512,75513]
===
match
---
name: self [70972,70976]
name: self [70984,70988]
===
match
---
arglist [7040,7093]
arglist [7040,7093]
===
match
---
suite [4129,4150]
suite [4129,4150]
===
match
---
trailer [58220,58229]
trailer [58232,58241]
===
match
---
trailer [53819,53831]
trailer [53819,53831]
===
match
---
funcdef [65904,66197]
funcdef [65916,66209]
===
match
---
name: test_mode [45446,45455]
name: test_mode [45446,45455]
===
match
---
simple_stmt [23360,23378]
simple_stmt [23360,23378]
===
match
---
param [70025,70032]
param [70037,70044]
===
match
---
operator: = [5496,5497]
operator: = [5496,5497]
===
match
---
operator: , [78275,78276]
operator: , [78287,78288]
===
match
---
trailer [63347,63353]
trailer [63359,63365]
===
match
---
atom_expr [55166,55183]
atom_expr [55178,55195]
===
match
---
comparison [39930,39967]
comparison [39930,39967]
===
match
---
argument [60071,60086]
argument [60083,60098]
===
match
---
name: overwrite_params_with_dag_run_conf [65908,65942]
name: overwrite_params_with_dag_run_conf [65920,65954]
===
match
---
atom_expr [75025,75047]
atom_expr [75037,75059]
===
match
---
name: _priority_weight [79756,79772]
name: _priority_weight [79768,79784]
===
match
---
decorated [16369,19726]
decorated [16369,19726]
===
match
---
suite [60120,60947]
suite [60132,60959]
===
match
---
name: dag_run [57962,57969]
name: dag_run [57974,57981]
===
match
---
name: t [77134,77135]
name: t [77146,77147]
===
match
---
trailer [41398,41402]
trailer [41398,41402]
===
match
---
string: '-' [59430,59433]
string: '-' [59442,59445]
===
match
---
string: 'TaskInstance' [29498,29512]
string: 'TaskInstance' [29498,29512]
===
match
---
operator: = [15171,15172]
operator: = [15171,15172]
===
match
---
trailer [51551,51564]
trailer [51551,51564]
===
match
---
fstring [46099,46153]
fstring [46099,46153]
===
match
---
string: 'kcah_acitats' [80880,80894]
string: 'kcah_acitats' [80892,80906]
===
match
---
name: self [26512,26516]
name: self [26512,26516]
===
match
---
name: bool [36808,36812]
name: bool [36808,36812]
===
match
---
operator: = [28025,28026]
operator: = [28025,28026]
===
match
---
import_as_names [1037,1102]
import_as_names [1037,1102]
===
match
---
trailer [50632,50655]
trailer [50632,50655]
===
match
---
simple_stmt [3670,3710]
simple_stmt [3670,3710]
===
match
---
not_test [33773,33794]
not_test [33773,33794]
===
match
---
simple_stmt [18824,18880]
simple_stmt [18824,18880]
===
match
---
import_from [8057,8097]
import_from [8057,8097]
===
match
---
name: count [26621,26626]
name: count [26621,26626]
===
match
---
trailer [26858,26864]
trailer [26858,26864]
===
match
---
string: """         Returns whether a task is in UP_FOR_RETRY state and its retry interval         has elapsed.         """ [25712,25827]
string: """         Returns whether a task is in UP_FOR_RETRY state and its retry interval         has elapsed.         """ [25712,25827]
===
match
---
name: task [33409,33413]
name: task [33409,33413]
===
match
---
name: ti [5451,5453]
name: ti [5451,5453]
===
match
---
name: UP_FOR_RESCHEDULE [39950,39967]
name: UP_FOR_RESCHEDULE [39950,39967]
===
match
---
operator: , [40751,40752]
operator: , [40751,40752]
===
match
---
atom_expr [79831,79842]
atom_expr [79843,79854]
===
match
---
trailer [50408,50428]
trailer [50408,50428]
===
match
---
name: get_many [74583,74591]
name: get_many [74595,74603]
===
match
---
simple_stmt [80850,80870]
simple_stmt [80862,80882]
===
match
---
simple_stmt [57354,57378]
simple_stmt [57366,57390]
===
match
---
not_test [25937,25963]
not_test [25937,25963]
===
match
---
name: Union [72667,72672]
name: Union [72679,72684]
===
match
---
name: ignore_all_deps [19103,19118]
name: ignore_all_deps [19103,19118]
===
match
---
simple_stmt [70105,70135]
simple_stmt [70117,70147]
===
match
---
name: name [52881,52885]
name: name [52881,52885]
===
match
---
trailer [25276,25280]
trailer [25276,25280]
===
match
---
atom_expr [22634,22647]
atom_expr [22634,22647]
===
match
---
name: __init__ [61242,61250]
name: __init__ [61254,61262]
===
match
---
trailer [72686,72691]
trailer [72698,72703]
===
match
---
name: __init__ [12023,12031]
name: __init__ [12023,12031]
===
match
---
name: max_tries [6076,6085]
name: max_tries [6076,6085]
===
match
---
string: """Only Renders Templates for the TI""" [53152,53191]
string: """Only Renders Templates for the TI""" [53152,53191]
===
match
---
name: ignore_all_deps [40456,40471]
name: ignore_all_deps [40456,40471]
===
match
---
trailer [56186,56193]
trailer [56198,56205]
===
match
---
operator: = [50025,50026]
operator: = [50025,50026]
===
match
---
expr_stmt [33324,33365]
expr_stmt [33324,33365]
===
match
---
simple_stmt [58010,58032]
simple_stmt [58022,58044]
===
match
---
trailer [61419,61423]
trailer [61431,61435]
===
match
---
name: try_number [66858,66868]
name: try_number [66870,66880]
===
match
---
name: commit [56717,56723]
name: commit [56729,56735]
===
match
---
name: hexdigest [34900,34909]
name: hexdigest [34900,34909]
===
match
---
operator: , [31681,31682]
operator: , [31681,31682]
===
match
---
name: xcom_push [50177,50186]
name: xcom_push [50177,50186]
===
match
---
simple_stmt [59058,59109]
simple_stmt [59070,59121]
===
match
---
param [14210,14215]
param [14210,14215]
===
match
---
string: "--ignore-depends-on-past" [19312,19338]
string: "--ignore-depends-on-past" [19312,19338]
===
match
---
operator: = [54554,54555]
operator: = [54554,54555]
===
match
---
name: dag_id [36355,36361]
name: dag_id [36355,36361]
===
match
---
operator: @ [62302,62303]
operator: @ [62314,62315]
===
match
---
trailer [47992,48019]
trailer [47992,48019]
===
match
---
if_stmt [19525,19567]
if_stmt [19525,19567]
===
match
---
name: extend [19304,19310]
name: extend [19304,19310]
===
match
---
name: result [49991,49997]
name: result [49991,49997]
===
match
---
name: ignore_ti_state [36722,36737]
name: ignore_ti_state [36722,36737]
===
match
---
arglist [10418,10468]
arglist [10418,10468]
===
match
---
test [42334,42384]
test [42334,42384]
===
match
---
string: 'Exception:<br>{{exception_html}}<br>' [68105,68143]
string: 'Exception:<br>{{exception_html}}<br>' [68117,68155]
===
match
---
arglist [42142,42194]
arglist [42142,42194]
===
match
---
name: datetime [16476,16484]
name: datetime [16476,16484]
===
match
---
operator: , [67133,67134]
operator: , [67145,67146]
===
match
---
trailer [40828,40832]
trailer [40828,40832]
===
match
---
tfpdef [42982,42997]
tfpdef [42982,42997]
===
match
---
name: rendered_k8s_spec [65494,65511]
name: rendered_k8s_spec [65506,65523]
===
match
---
argument [52803,52816]
argument [52803,52816]
===
match
---
param [27052,27080]
param [27052,27080]
===
match
---
trailer [34575,34577]
trailer [34575,34577]
===
match
---
operator: -= [54186,54188]
operator: -= [54186,54188]
===
match
---
name: task [57610,57614]
name: task [57622,57626]
===
match
---
parameters [14300,14306]
parameters [14300,14306]
===
match
---
operator: , [59157,59158]
operator: , [59169,59170]
===
match
---
atom_expr [59921,59932]
atom_expr [59933,59944]
===
match
---
trailer [36846,36851]
trailer [36846,36851]
===
match
---
trailer [38649,38657]
trailer [38649,38657]
===
match
---
name: execution_date [9340,9354]
name: execution_date [9340,9354]
===
match
---
name: or_ [8358,8361]
name: or_ [8358,8361]
===
match
---
atom_expr [58647,58671]
atom_expr [58659,58683]
===
match
---
suite [61517,61555]
suite [61529,61567]
===
match
---
name: start_date [79312,79322]
name: start_date [79324,79334]
===
match
---
comparison [77709,77757]
comparison [77721,77769]
===
match
---
operator: = [16598,16599]
operator: = [16598,16599]
===
match
---
name: NamedTemporaryFile [999,1017]
name: NamedTemporaryFile [999,1017]
===
match
---
argument [32766,32789]
argument [32766,32789]
===
match
---
name: State [45769,45774]
name: State [45769,45774]
===
match
---
name: airflow [2245,2252]
name: airflow [2245,2252]
===
match
---
name: min [35653,35656]
name: min [35653,35656]
===
match
---
trailer [46249,46260]
trailer [46249,46260]
===
match
---
atom_expr [47039,47061]
atom_expr [47039,47061]
===
match
---
name: self [40784,40788]
name: self [40784,40788]
===
match
---
funcdef [53125,53357]
funcdef [53125,53357]
===
match
---
name: actual_start_date [53412,53429]
name: actual_start_date [53412,53429]
===
match
---
operator: = [16148,16149]
operator: = [16148,16149]
===
match
---
atom_expr [31495,31750]
atom_expr [31495,31750]
===
match
---
parameters [80057,80100]
parameters [80069,80112]
===
match
---
param [16870,16897]
param [16870,16897]
===
match
---
operator: = [26510,26511]
operator: = [26510,26511]
===
match
---
operator: , [53831,53832]
operator: , [53831,53832]
===
match
---
operator: , [21668,21669]
operator: , [21668,21669]
===
match
---
name: renderedtifields [65434,65450]
name: renderedtifields [65446,65462]
===
match
---
decorator [71258,71275]
decorator [71270,71287]
===
match
---
atom_expr [51413,51422]
atom_expr [51413,51422]
===
match
---
arglist [38682,38710]
arglist [38682,38710]
===
match
---
operator: , [9354,9355]
operator: , [9354,9355]
===
match
---
operator: , [16645,16646]
operator: , [16645,16646]
===
match
---
name: BaseJob [7601,7608]
name: BaseJob [7601,7608]
===
match
---
trailer [51337,51346]
trailer [51337,51346]
===
match
---
name: ignore_schedule [28509,28524]
name: ignore_schedule [28509,28524]
===
match
---
expr_stmt [7983,8004]
expr_stmt [7983,8004]
===
match
---
suite [42257,42385]
suite [42257,42385]
===
match
---
atom_expr [75778,75789]
atom_expr [75790,75801]
===
match
---
string: "Refreshing TaskInstance %s from DB" [22127,22163]
string: "Refreshing TaskInstance %s from DB" [22127,22163]
===
match
---
arglist [46004,46039]
arglist [46004,46039]
===
match
---
trailer [58269,58284]
trailer [58281,58296]
===
match
---
operator: = [40527,40528]
operator: = [40527,40528]
===
match
---
fstring_string: . [44259,44260]
fstring_string: . [44259,44260]
===
match
---
atom_expr [11658,11719]
atom_expr [11658,11719]
===
match
---
trailer [70826,70832]
trailer [70838,70844]
===
match
---
name: render [70013,70019]
name: render [70025,70031]
===
match
---
trailer [26738,26742]
trailer [26738,26742]
===
match
---
param [79870,79874]
param [79882,79886]
===
match
---
trailer [69340,69352]
trailer [69352,69364]
===
match
---
operator: , [78738,78739]
operator: , [78750,78751]
===
match
---
name: self [58761,58765]
name: self [58773,58777]
===
match
---
name: AirflowSkipException [44660,44680]
name: AirflowSkipException [44660,44680]
===
match
---
operator: , [12615,12616]
operator: , [12615,12616]
===
match
---
trailer [56526,56533]
trailer [56538,56545]
===
match
---
trailer [42444,42448]
trailer [42444,42448]
===
match
---
param [61511,61515]
param [61523,61527]
===
match
---
atom_expr [78900,78930]
atom_expr [78912,78942]
===
match
---
trailer [76909,76924]
trailer [76921,76936]
===
match
---
simple_stmt [14867,14897]
simple_stmt [14867,14897]
===
match
---
name: self [46472,46476]
name: self [46472,46476]
===
match
---
name: get_rendered_template_fields [64298,64326]
name: get_rendered_template_fields [64310,64338]
===
match
---
tfpdef [36722,36743]
tfpdef [36722,36743]
===
match
---
operator: , [15100,15101]
operator: , [15100,15101]
===
match
---
expr_stmt [8913,8932]
expr_stmt [8913,8932]
===
match
---
name: self [39879,39883]
name: self [39879,39883]
===
match
---
factor [80897,80899]
factor [80909,80911]
===
match
---
and_test [77188,77237]
and_test [77200,77249]
===
match
---
atom_expr [75690,75933]
atom_expr [75702,75945]
===
match
---
operator: = [74576,74577]
operator: = [74588,74589]
===
match
---
return_stmt [79655,79672]
return_stmt [79667,79684]
===
match
---
not_test [76511,76518]
not_test [76523,76530]
===
match
---
arglist [11664,11718]
arglist [11664,11718]
===
match
---
string: 'Failed to send email to: %s' [56599,56628]
string: 'Failed to send email to: %s' [56611,56640]
===
match
---
atom_expr [20311,20322]
atom_expr [20311,20322]
===
match
---
expr_stmt [70201,70219]
expr_stmt [70213,70231]
===
match
---
simple_stmt [820,835]
simple_stmt [820,835]
===
match
---
simple_stmt [871,885]
simple_stmt [871,885]
===
match
---
atom_expr [63330,63446]
atom_expr [63342,63458]
===
match
---
name: dag_id [20316,20322]
name: dag_id [20316,20322]
===
match
---
trailer [49785,49799]
trailer [49785,49799]
===
match
---
name: name [77516,77520]
name: name [77528,77532]
===
match
---
name: self [41171,41175]
name: self [41171,41175]
===
match
---
name: Optional [16840,16848]
name: Optional [16840,16848]
===
match
---
operator: = [26600,26601]
operator: = [26600,26601]
===
match
---
name: self [32961,32965]
name: self [32961,32965]
===
match
---
name: fd [4103,4105]
name: fd [4103,4105]
===
match
---
arglist [67776,67788]
arglist [67788,67800]
===
match
---
operator: , [33614,33615]
operator: , [33614,33615]
===
match
---
name: context [49859,49866]
name: context [49859,49866]
===
match
---
operator: = [36744,36745]
operator: = [36744,36745]
===
match
---
atom_expr [10846,10858]
atom_expr [10846,10858]
===
match
---
funcdef [42905,46422]
funcdef [42905,46422]
===
match
---
parameters [42404,42430]
parameters [42404,42430]
===
match
---
string: """         Forces the task instance's state to FAILED in the database.          :param session: SQLAlchemy ORM Session         :type session: Session         """ [21290,21452]
string: """         Forces the task instance's state to FAILED in the database.          :param session: SQLAlchemy ORM Session         :type session: Session         """ [21290,21452]
===
match
---
comparison [72104,72140]
comparison [72116,72152]
===
match
---
operator: , [55107,55108]
operator: , [55119,55120]
===
match
---
argument [6827,7375]
argument [6827,7375]
===
match
---
name: self [20048,20052]
name: self [20048,20052]
===
match
---
name: task [70911,70915]
name: task [70923,70927]
===
match
---
name: start_date [78473,78483]
name: start_date [78485,78495]
===
match
---
string: "Executing %s on %s" [42142,42162]
string: "Executing %s on %s" [42142,42162]
===
match
---
fstring_string: &dag_id= [19985,19993]
fstring_string: &dag_id= [19985,19993]
===
match
---
name: self [38442,38446]
name: self [38442,38446]
===
match
---
operator: , [51823,51824]
operator: , [51823,51824]
===
match
---
fstring_end: " [20323,20324]
fstring_end: " [20323,20324]
===
match
---
operator: = [59571,59572]
operator: = [59583,59584]
===
match
---
operator: = [25581,25582]
operator: = [25581,25582]
===
match
---
atom_expr [77272,77473]
atom_expr [77284,77485]
===
match
---
name: DepContext [33353,33363]
name: DepContext [33353,33363]
===
match
---
simple_stmt [22435,22470]
simple_stmt [22435,22470]
===
match
---
operator: = [15524,15525]
operator: = [15524,15525]
===
match
---
name: state [50865,50870]
name: state [50865,50870]
===
match
---
param [36830,36859]
param [36830,36859]
===
match
---
suite [22422,22470]
suite [22422,22470]
===
match
---
name: mark_success [15956,15968]
name: mark_success [15956,15968]
===
match
---
operator: = [78361,78362]
operator: = [78373,78374]
===
match
---
atom_expr [10875,10895]
atom_expr [10875,10895]
===
match
---
operator: , [51698,51699]
operator: , [51698,51699]
===
match
---
operator: { [46140,46141]
operator: { [46140,46141]
===
match
---
try_stmt [50384,50579]
try_stmt [50384,50579]
===
match
---
name: base_job [80977,80985]
name: base_job [80989,80997]
===
match
---
name: priority_weight [23958,23973]
name: priority_weight [23958,23973]
===
match
---
decorated [79055,79122]
decorated [79067,79134]
===
match
---
simple_stmt [19811,19856]
simple_stmt [19811,19856]
===
match
---
expr_stmt [78677,78716]
expr_stmt [78689,78728]
===
match
---
name: task [38373,38377]
name: task [38373,38377]
===
match
---
operator: = [32777,32778]
operator: = [32777,32778]
===
match
---
trailer [7420,7427]
trailer [7420,7427]
===
match
---
simple_stmt [25025,25223]
simple_stmt [25025,25223]
===
match
---
name: task_id [72426,72433]
name: task_id [72438,72445]
===
match
---
operator: = [40760,40761]
operator: = [40760,40761]
===
match
---
name: context [48807,48814]
name: context [48807,48814]
===
match
---
suite [70084,70220]
suite [70096,70232]
===
match
---
operator: = [15793,15794]
operator: = [15793,15794]
===
match
---
name: data [4187,4191]
name: data [4187,4191]
===
match
---
trailer [3703,3707]
trailer [3703,3707]
===
match
---
trailer [46116,46123]
trailer [46116,46123]
===
match
---
return_stmt [79744,79772]
return_stmt [79756,79784]
===
match
---
expr_stmt [59521,59552]
expr_stmt [59533,59564]
===
match
---
name: Index [11624,11629]
name: Index [11624,11629]
===
match
---
operator: + [58285,58286]
operator: + [58297,58298]
===
match
---
dictorsetmaker [75089,75211]
dictorsetmaker [75101,75223]
===
match
---
operator: , [64008,64009]
operator: , [64020,64021]
===
match
---
atom_expr [66238,66255]
atom_expr [66250,66267]
===
match
---
name: state [25356,25361]
name: state [25356,25361]
===
match
---
atom_expr [45841,45897]
atom_expr [45841,45897]
===
match
---
param [31867,31872]
param [31867,31872]
===
match
---
operator: = [16212,16213]
operator: = [16212,16213]
===
match
---
name: job_id [5370,5376]
name: job_id [5370,5376]
===
match
---
operator: , [69810,69811]
operator: , [69822,69823]
===
match
---
name: String [10846,10852]
name: String [10846,10852]
===
match
---
name: pool [10929,10933]
name: pool [10929,10933]
===
match
---
name: dag [57662,57665]
name: dag [57674,57677]
===
match
---
trailer [45569,45585]
trailer [45569,45585]
===
match
---
name: execution_date [21059,21073]
name: execution_date [21059,21073]
===
match
---
name: self [46750,46754]
name: self [46750,46754]
===
match
---
atom_expr [24879,24890]
atom_expr [24879,24890]
===
match
---
not_test [4120,4128]
not_test [4120,4128]
===
match
---
simple_stmt [27148,27377]
simple_stmt [27148,27377]
===
match
---
name: raw [13310,13313]
name: raw [13310,13313]
===
match
---
trailer [42665,42672]
trailer [42665,42672]
===
match
---
trailer [53621,53623]
trailer [53621,53623]
===
match
---
atom_expr [51085,51118]
atom_expr [51085,51118]
===
match
---
operator: = [15189,15190]
operator: = [15189,15190]
===
match
---
trailer [66674,66676]
trailer [66686,66688]
===
match
---
operator: -> [79240,79242]
operator: -> [79252,79254]
===
match
---
simple_stmt [1833,1894]
simple_stmt [1833,1894]
===
match
---
simple_stmt [60896,60947]
simple_stmt [60908,60959]
===
match
---
name: non_requeueable_dep_context [39403,39430]
name: non_requeueable_dep_context [39403,39430]
===
match
---
name: init_on_load [13115,13127]
name: init_on_load [13115,13127]
===
match
---
name: query_for_task_instance [40010,40033]
name: query_for_task_instance [40010,40033]
===
match
---
trailer [24883,24890]
trailer [24883,24890]
===
match
---
name: datetime [8989,8997]
name: datetime [8989,8997]
===
match
---
name: Optional [72658,72666]
name: Optional [72670,72678]
===
match
---
trailer [15845,16363]
trailer [15845,16363]
===
match
---
if_stmt [64569,65280]
if_stmt [64581,65292]
===
match
---
name: subject [70697,70704]
name: subject [70709,70716]
===
match
---
name: self [12230,12234]
name: self [12230,12234]
===
match
---
name: on_success_callback [51318,51337]
name: on_success_callback [51318,51337]
===
match
---
annassign [8923,8932]
annassign [8923,8932]
===
match
---
name: tis [77980,77983]
name: tis [77992,77995]
===
match
---
simple_stmt [33107,33165]
simple_stmt [33107,33165]
===
match
---
name: run_id [63623,63629]
name: run_id [63635,63641]
===
match
---
simple_stmt [12135,12161]
simple_stmt [12135,12161]
===
match
---
name: exception [70770,70779]
name: exception [70782,70791]
===
match
---
name: task [24161,24165]
name: task [24161,24165]
===
match
---
suite [21701,23481]
suite [21701,23481]
===
match
---
name: helpers [2573,2580]
name: helpers [2573,2580]
===
match
---
name: SKIPPED [44936,44943]
name: SKIPPED [44936,44943]
===
match
---
name: tempfile [983,991]
name: tempfile [983,991]
===
match
---
name: dag_id [66823,66829]
name: dag_id [66835,66841]
===
match
---
name: job_id [38515,38521]
name: job_id [38515,38521]
===
match
---
if_stmt [22521,23422]
if_stmt [22521,23422]
===
match
---
name: task_copy [48880,48889]
name: task_copy [48880,48889]
===
match
---
name: state [22719,22724]
name: state [22719,22724]
===
match
---
trailer [25654,25660]
trailer [25654,25660]
===
match
---
simple_stmt [26576,26588]
simple_stmt [26576,26588]
===
match
---
operator: @ [29442,29443]
operator: @ [29442,29443]
===
match
---
operator: = [28922,28923]
operator: = [28922,28923]
===
match
---
try_stmt [3622,3943]
try_stmt [3622,3943]
===
match
---
operator: = [23288,23289]
operator: = [23288,23289]
===
match
---
trailer [16951,16956]
trailer [16951,16956]
===
match
---
name: add [46337,46340]
name: add [46337,46340]
===
match
---
simple_stmt [41171,41203]
simple_stmt [41171,41203]
===
match
---
name: airflow [2816,2823]
name: airflow [2816,2823]
===
match
---
name: default_html_content [68006,68026]
name: default_html_content [68018,68038]
===
match
---
name: try_number [69832,69842]
name: try_number [69844,69854]
===
match
---
comparison [45739,45782]
comparison [45739,45782]
===
match
---
trailer [5678,5686]
trailer [5678,5686]
===
match
---
name: self [57881,57885]
name: self [57893,57897]
===
match
---
expr_stmt [25343,25361]
expr_stmt [25343,25361]
===
match
---
name: error [53113,53118]
name: error [53113,53118]
===
match
---
operator: = [10686,10687]
operator: = [10686,10687]
===
match
---
operator: = [11952,11953]
operator: = [11952,11953]
===
match
---
name: Optional [27059,27067]
name: Optional [27059,27067]
===
match
---
name: self [42810,42814]
name: self [42810,42814]
===
match
---
parameters [61601,61719]
parameters [61613,61731]
===
match
---
simple_stmt [40824,40856]
simple_stmt [40824,40856]
===
match
---
name: State [26885,26890]
name: State [26885,26890]
===
match
---
operator: , [74688,74689]
operator: , [74700,74701]
===
match
---
name: provide_session [49047,49062]
name: provide_session [49047,49062]
===
match
---
name: self [39930,39934]
name: self [39930,39934]
===
match
---
atom_expr [46141,46151]
atom_expr [46141,46151]
===
match
---
name: airflow_context_vars [47685,47705]
name: airflow_context_vars [47685,47705]
===
match
---
name: handle_failure_with_callback [56756,56784]
name: handle_failure_with_callback [56768,56796]
===
match
---
funcdef [30606,31242]
funcdef [30606,31242]
===
match
---
name: BaseJob [81141,81148]
name: BaseJob [81153,81160]
===
match
---
simple_stmt [24011,24047]
simple_stmt [24011,24047]
===
match
---
name: date [66945,66949]
name: date [66957,66961]
===
match
---
operator: = [23415,23416]
operator: = [23415,23416]
===
match
---
parameters [62155,62219]
parameters [62167,62231]
===
match
---
argument [77134,77156]
argument [77146,77168]
===
match
---
name: job_id [36830,36836]
name: job_id [36830,36836]
===
match
---
trailer [11790,11811]
trailer [11790,11811]
===
match
---
name: test_mode [56658,56667]
name: test_mode [56670,56679]
===
match
---
trailer [58833,58837]
trailer [58845,58849]
===
match
---
operator: = [58182,58183]
operator: = [58194,58195]
===
match
---
atom_expr [63487,63599]
atom_expr [63499,63611]
===
match
---
name: path [69254,69258]
name: path [69266,69270]
===
match
---
name: send_email [70895,70905]
name: send_email [70907,70917]
===
match
---
name: retries [5679,5686]
name: retries [5679,5686]
===
match
---
not_test [26534,26562]
not_test [26534,26562]
===
match
---
decorated [80009,80848]
decorated [80021,80860]
===
match
---
trailer [72726,72731]
trailer [72738,72743]
===
match
---
atom_expr [54019,54042]
atom_expr [54019,54042]
===
match
---
atom_expr [11331,11363]
atom_expr [11331,11363]
===
match
---
expr_stmt [10474,10541]
expr_stmt [10474,10541]
===
match
---
operator: == [22254,22256]
operator: == [22254,22256]
===
match
---
name: provide_session [26997,27012]
name: provide_session [26997,27012]
===
match
---
expr_stmt [76577,76598]
expr_stmt [76589,76610]
===
match
---
trailer [20892,20899]
trailer [20892,20899]
===
match
---
name: task [26505,26509]
name: task [26505,26509]
===
match
---
expr [33385,33418]
expr [33385,33418]
===
match
---
name: str [50639,50642]
name: str [50639,50642]
===
match
---
name: self [33239,33243]
name: self [33239,33243]
===
match
---
name: RenderedTaskInstanceFields [65514,65540]
name: RenderedTaskInstanceFields [65526,65552]
===
match
---
expr_stmt [4096,4112]
expr_stmt [4096,4112]
===
match
---
name: total_seconds [35502,35515]
name: total_seconds [35502,35515]
===
match
---
name: logging_mixin [2624,2637]
name: logging_mixin [2624,2637]
===
match
---
name: prev_ds_nodash [63215,63229]
name: prev_ds_nodash [63227,63241]
===
match
---
name: commit [46413,46419]
name: commit [46413,46419]
===
match
---
trailer [79729,79734]
trailer [79741,79746]
===
match
---
atom_expr [40872,41154]
atom_expr [40872,41154]
===
match
---
name: models [46556,46562]
name: models [46556,46562]
===
match
---
param [79234,79238]
param [79246,79250]
===
match
---
trailer [28768,28788]
trailer [28768,28788]
===
match
---
atom_expr [51205,51229]
atom_expr [51205,51229]
===
match
---
name: dag_id [8471,8477]
name: dag_id [8471,8477]
===
match
---
operator: , [56990,56991]
operator: , [57002,57003]
===
match
---
trailer [77121,77129]
trailer [77133,77141]
===
match
---
name: Literal [4785,4792]
name: Literal [4785,4792]
===
match
---
name: dag_id [47379,47385]
name: dag_id [47379,47385]
===
match
---
atom_expr [39944,39967]
atom_expr [39944,39967]
===
match
---
trailer [80900,80906]
trailer [80912,80918]
===
match
---
argument [27454,27469]
argument [27454,27469]
===
match
---
argument [69279,69294]
argument [69291,69306]
===
match
---
name: pool [16312,16316]
name: pool [16312,16316]
===
match
---
name: self [72434,72438]
name: self [72446,72450]
===
match
---
arglist [55097,55114]
arglist [55109,55126]
===
match
---
trailer [7427,7429]
trailer [7427,7429]
===
match
---
operator: = [38553,38554]
operator: = [38553,38554]
===
match
---
name: reschedule_exception [44989,45009]
name: reschedule_exception [44989,45009]
===
match
---
name: first [80822,80827]
name: first [80834,80839]
===
match
---
atom_expr [16734,16747]
atom_expr [16734,16747]
===
match
---
simple_stmt [33173,33185]
simple_stmt [33173,33185]
===
match
---
name: task_ids [74702,74710]
name: task_ids [74714,74722]
===
match
---
fstring [59824,59869]
fstring [59836,59881]
===
match
---
not_test [12413,12454]
not_test [12413,12454]
===
match
---
name: AttributeError [27958,27972]
name: AttributeError [27958,27972]
===
match
---
name: self [21650,21654]
name: self [21650,21654]
===
match
---
operator: -> [71436,71438]
operator: -> [71448,71450]
===
match
---
trailer [78735,78754]
trailer [78747,78766]
===
match
---
name: dr [8645,8647]
name: dr [8645,8647]
===
match
---
name: dependencies_deps [2378,2395]
name: dependencies_deps [2378,2395]
===
match
---
name: params [57619,57625]
name: params [57631,57637]
===
match
---
atom_expr [21525,21535]
atom_expr [21525,21535]
===
match
---
name: Session [30687,30694]
name: Session [30687,30694]
===
match
---
suite [19763,20008]
suite [19763,20008]
===
match
---
operator: , [4753,4754]
operator: , [4753,4754]
===
match
---
param [21650,21655]
param [21650,21655]
===
match
---
name: dry_run [53129,53136]
name: dry_run [53129,53136]
===
match
---
operator: @ [20013,20014]
operator: @ [20013,20014]
===
match
---
trailer [23109,23114]
trailer [23109,23114]
===
match
---
decorated [31247,31816]
decorated [31247,31816]
===
match
---
name: ignore_schedule [28621,28636]
name: ignore_schedule [28621,28636]
===
match
---
arglist [77294,77459]
arglist [77306,77471]
===
match
---
name: session [32791,32798]
name: session [32791,32798]
===
match
---
name: current_state [20493,20506]
name: current_state [20493,20506]
===
match
---
atom_expr [11199,11214]
atom_expr [11199,11214]
===
match
---
name: self [14852,14856]
name: self [14852,14856]
===
match
---
simple_stmt [24055,24085]
simple_stmt [24055,24085]
===
match
---
name: execution_date [22368,22382]
name: execution_date [22368,22382]
===
match
---
name: dag [28231,28234]
name: dag [28231,28234]
===
match
---
trailer [72125,72140]
trailer [72137,72152]
===
match
---
operator: , [42593,42594]
operator: , [42593,42594]
===
match
---
name: delay [34556,34561]
name: delay [34556,34561]
===
match
---
name: str [62201,62204]
name: str [62213,62216]
===
match
---
operator: , [50297,50298]
operator: , [50297,50298]
===
match
---
simple_stmt [11106,11138]
simple_stmt [11106,11138]
===
match
---
trailer [62558,62564]
trailer [62570,62576]
===
match
---
expr_stmt [38510,38530]
expr_stmt [38510,38530]
===
match
---
decorated [21230,21604]
decorated [21230,21604]
===
match
---
name: raw [16264,16267]
name: raw [16264,16267]
===
match
---
name: cfg_path [16344,16352]
name: cfg_path [16344,16352]
===
match
---
name: state [45744,45749]
name: state [45744,45749]
===
match
---
trailer [25904,25910]
trailer [25904,25910]
===
match
---
atom_expr [78415,78432]
atom_expr [78427,78444]
===
match
---
string: 'task_instance_key_str' [63704,63727]
string: 'task_instance_key_str' [63716,63739]
===
match
---
trailer [6264,6271]
trailer [6264,6271]
===
match
---
atom_expr [58265,58284]
atom_expr [58277,58296]
===
match
---
name: Variable [60775,60783]
name: Variable [60787,60795]
===
match
---
name: REQUEUEABLE_DEPS [2403,2419]
name: REQUEUEABLE_DEPS [2403,2419]
===
match
---
simple_stmt [46329,46364]
simple_stmt [46329,46364]
===
match
---
simple_stmt [24423,24460]
simple_stmt [24423,24460]
===
match
---
name: self [78621,78625]
name: self [78633,78637]
===
match
---
simple_stmt [41698,41719]
simple_stmt [41698,41719]
===
match
---
atom_expr [24423,24459]
atom_expr [24423,24459]
===
match
---
name: state [39935,39940]
name: state [39935,39940]
===
match
---
name: _date_or_empty [42717,42731]
name: _date_or_empty [42717,42731]
===
match
---
trailer [12085,12090]
trailer [12085,12090]
===
match
---
trailer [44114,44116]
trailer [44114,44116]
===
match
---
fstring_string:   [33918,33919]
fstring_string:   [33918,33919]
===
match
---
trailer [72471,72478]
trailer [72483,72490]
===
match
---
name: DeprecationWarning [29343,29361]
name: DeprecationWarning [29343,29361]
===
match
---
atom_expr [77294,77313]
atom_expr [77306,77325]
===
match
---
name: Index [11658,11663]
name: Index [11658,11663]
===
match
---
tfpdef [27052,27072]
tfpdef [27052,27072]
===
match
---
name: self [64555,64559]
name: self [64567,64571]
===
match
---
name: SKIPPED [26876,26883]
name: SKIPPED [26876,26883]
===
match
---
name: task_copy [48178,48187]
name: task_copy [48178,48187]
===
match
---
operator: , [61367,61368]
operator: , [61379,61380]
===
match
---
name: dag_id [26698,26704]
name: dag_id [26698,26704]
===
match
---
trailer [58711,58726]
trailer [58723,58738]
===
match
---
trailer [36313,36319]
trailer [36313,36319]
===
match
---
atom [45168,45212]
atom [45168,45212]
===
match
---
name: exc_info [48465,48473]
name: exc_info [48465,48473]
===
match
---
suite [41604,41655]
suite [41604,41655]
===
match
---
trailer [24097,24113]
trailer [24097,24113]
===
match
---
name: task_type [55257,55266]
name: task_type [55269,55278]
===
match
---
operator: * [38820,38821]
operator: * [38820,38821]
===
match
---
simple_stmt [33816,33833]
simple_stmt [33816,33833]
===
match
---
trailer [8978,8998]
trailer [8978,8998]
===
match
---
name: __init__ [60375,60383]
name: __init__ [60387,60395]
===
match
---
name: log [50523,50526]
name: log [50523,50526]
===
match
---
name: Column [11263,11269]
name: Column [11263,11269]
===
match
---
tfpdef [78277,78293]
tfpdef [78289,78305]
===
match
---
name: Any [71341,71344]
name: Any [71353,71356]
===
match
---
param [4300,4328]
param [4300,4328]
===
match
---
operator: = [59471,59472]
operator: = [59483,59484]
===
match
---
name: task_ids [74711,74719]
name: task_ids [74723,74731]
===
match
---
name: task [48982,48986]
name: task [48982,48986]
===
match
---
expr_stmt [65494,65580]
expr_stmt [65506,65592]
===
match
---
operator: = [55164,55165]
operator: = [55176,55177]
===
match
---
operator: , [62815,62816]
operator: , [62827,62828]
===
match
---
simple_stmt [44393,44454]
simple_stmt [44393,44454]
===
match
---
suite [53143,53357]
suite [53143,53357]
===
match
---
argument [65564,65579]
argument [65576,65591]
===
match
---
atom_expr [77134,77143]
atom_expr [77146,77155]
===
match
---
param [27081,27104]
param [27081,27104]
===
match
---
name: verbose [40753,40760]
name: verbose [40753,40760]
===
match
---
operator: = [54531,54532]
operator: = [54531,54532]
===
match
---
atom_expr [19078,19089]
atom_expr [19078,19089]
===
match
---
name: DagRun [8313,8319]
name: DagRun [8313,8319]
===
match
---
except_clause [49880,49905]
except_clause [49880,49905]
===
match
---
operator: ** [10505,10507]
operator: ** [10505,10507]
===
match
---
dotted_name [2953,2974]
dotted_name [2953,2974]
===
match
---
suite [61257,61290]
suite [61269,61302]
===
match
---
trailer [4312,4328]
trailer [4312,4328]
===
match
---
name: Column [11156,11162]
name: Column [11156,11162]
===
match
---
atom_expr [27438,27470]
atom_expr [27438,27470]
===
match
---
arglist [75186,75210]
arglist [75198,75222]
===
match
---
name: dag_run [62750,62757]
name: dag_run [62762,62769]
===
match
---
string: 'email' [70121,70128]
string: 'email' [70133,70140]
===
match
---
arith_expr [41117,41135]
arith_expr [41117,41135]
===
match
---
name: dep_context [31873,31884]
name: dep_context [31873,31884]
===
match
---
operator: = [8929,8930]
operator: = [8929,8930]
===
match
---
operator: , [1296,1297]
operator: , [1296,1297]
===
match
---
argument [28789,28804]
argument [28789,28804]
===
match
---
name: elements [1476,1484]
name: elements [1476,1484]
===
match
---
name: task [35607,35611]
name: task [35607,35611]
===
match
---
trailer [60055,60087]
trailer [60067,60099]
===
match
---
simple_stmt [19670,19707]
simple_stmt [19670,19707]
===
match
---
name: ti [6106,6108]
name: ti [6106,6108]
===
match
---
name: end_date [22639,22647]
name: end_date [22639,22647]
===
match
---
trailer [48652,48681]
trailer [48652,48681]
===
match
---
number: 1 [55273,55274]
number: 1 [55285,55286]
===
match
---
param [61336,61341]
param [61348,61353]
===
match
---
operator: = [10651,10652]
operator: = [10651,10652]
===
match
---
trailer [59846,59854]
trailer [59858,59866]
===
match
---
operator: , [7342,7343]
operator: , [7342,7343]
===
match
---
return_stmt [62663,64288]
return_stmt [62675,64300]
===
match
---
name: bool [51850,51854]
name: bool [51850,51854]
===
match
---
trailer [70905,70949]
trailer [70917,70961]
===
match
---
atom_expr [22282,22302]
atom_expr [22282,22302]
===
match
---
decorated [36479,42216]
decorated [36479,42216]
===
match
---
atom_expr [26670,26689]
atom_expr [26670,26689]
===
match
---
name: deserialize_value [75110,75127]
name: deserialize_value [75122,75139]
===
match
---
atom_expr [55360,55383]
atom_expr [55372,55395]
===
match
---
operator: - [34603,34604]
operator: - [34603,34604]
===
match
---
trailer [53935,53951]
trailer [53935,53951]
===
match
---
name: str [4780,4783]
name: str [4780,4783]
===
match
---
operator: = [56929,56930]
operator: = [56941,56942]
===
match
---
trailer [38354,38372]
trailer [38354,38372]
===
match
---
name: warning [40881,40888]
name: warning [40881,40888]
===
match
---
trailer [54779,54783]
trailer [54779,54783]
===
match
---
funcdef [57289,64289]
funcdef [57301,64301]
===
match
---
atom_expr [5276,5292]
atom_expr [5276,5292]
===
match
---
name: ignore_all_deps [36597,36612]
name: ignore_all_deps [36597,36612]
===
match
---
arglist [22127,22169]
arglist [22127,22169]
===
match
---
name: self [55452,55456]
name: self [55464,55468]
===
match
---
import_name [1186,1201]
import_name [1186,1201]
===
match
---
simple_stmt [81005,81046]
simple_stmt [81017,81058]
===
match
---
name: key [72380,72383]
name: key [72392,72395]
===
match
---
atom_expr [78324,78333]
atom_expr [78336,78345]
===
match
---
atom_expr [74549,74560]
atom_expr [74561,74572]
===
match
---
trailer [11529,11560]
trailer [11529,11560]
===
match
---
return_stmt [35895,35985]
return_stmt [35895,35985]
===
match
---
suite [78755,78803]
suite [78767,78815]
===
match
---
name: start_date [31189,31199]
name: start_date [31189,31199]
===
match
---
trailer [12900,12916]
trailer [12900,12916]
===
match
---
trailer [80778,80784]
trailer [80790,80796]
===
match
---
operator: , [15030,15031]
operator: , [15030,15031]
===
match
---
name: pool [52471,52475]
name: pool [52471,52475]
===
match
---
operator: = [15094,15095]
operator: = [15094,15095]
===
match
---
name: session [49106,49113]
name: session [49106,49113]
===
match
---
return_stmt [14139,14166]
return_stmt [14139,14166]
===
match
---
atom_expr [29489,29513]
atom_expr [29489,29513]
===
match
---
comparison [8681,8710]
comparison [8681,8710]
===
match
---
atom_expr [80597,80617]
atom_expr [80609,80629]
===
match
---
operator: , [31889,31890]
operator: , [31889,31890]
===
match
---
trailer [25435,25441]
trailer [25435,25441]
===
match
---
if_stmt [33770,33833]
if_stmt [33770,33833]
===
match
---
name: ti [5394,5396]
name: ti [5394,5396]
===
match
---
trailer [77507,77515]
trailer [77519,77527]
===
match
---
param [49489,49498]
param [49489,49498]
===
match
---
trailer [8560,8562]
trailer [8560,8562]
===
match
---
trailer [75190,75198]
trailer [75202,75210]
===
match
---
param [4717,4740]
param [4717,4740]
===
match
---
funcdef [66458,67432]
funcdef [66470,67444]
===
match
---
name: state [54011,54016]
name: state [54011,54016]
===
match
---
atom_expr [10882,10894]
atom_expr [10882,10894]
===
match
---
name: signal [46934,46940]
name: signal [46934,46940]
===
match
---
operator: = [12147,12148]
operator: = [12147,12148]
===
match
---
atom_expr [11044,11063]
atom_expr [11044,11063]
===
match
---
trailer [60915,60946]
trailer [60927,60958]
===
match
---
arglist [10943,10970]
arglist [10943,10970]
===
match
---
simple_stmt [46824,46844]
simple_stmt [46824,46844]
===
match
---
string: "TaskInstanceKey" [9649,9666]
string: "TaskInstanceKey" [9649,9666]
===
match
---
name: force_fail [56109,56119]
name: force_fail [56121,56131]
===
match
---
trailer [24481,24487]
trailer [24481,24487]
===
match
---
name: email [70916,70921]
name: email [70928,70933]
===
match
---
name: get_dagrun [36016,36026]
name: get_dagrun [36016,36026]
===
match
---
name: self [22165,22169]
name: self [22165,22169]
===
match
---
trailer [54403,54419]
trailer [54403,54419]
===
match
---
trailer [22261,22268]
trailer [22261,22268]
===
match
---
simple_stmt [79350,79374]
simple_stmt [79362,79386]
===
match
---
string: ' execution_date=%s, start_date=%s, end_date=%s' [42545,42593]
string: ' execution_date=%s, start_date=%s, end_date=%s' [42545,42593]
===
match
---
operator: , [11802,11803]
operator: , [11802,11803]
===
match
---
name: sql [1472,1475]
name: sql [1472,1475]
===
match
---
name: self [34807,34811]
name: self [34807,34811]
===
match
---
trailer [10720,10732]
trailer [10720,10732]
===
match
---
trailer [41444,41510]
trailer [41444,41510]
===
match
---
argument [56979,56990]
argument [56991,57002]
===
match
---
suite [12099,13397]
suite [12099,13397]
===
match
---
atom_expr [76179,76206]
atom_expr [76191,76218]
===
match
---
name: base_url [20213,20221]
name: base_url [20213,20221]
===
match
---
operator: = [34540,34541]
operator: = [34540,34541]
===
match
---
atom_expr [34229,34264]
atom_expr [34229,34264]
===
match
---
if_stmt [39341,39539]
if_stmt [39341,39539]
===
match
---
name: f [70174,70175]
name: f [70186,70187]
===
match
---
operator: = [12809,12810]
operator: = [12809,12810]
===
match
---
operator: , [1720,1721]
operator: , [1720,1721]
===
match
---
atom_expr [53915,53951]
atom_expr [53915,53951]
===
match
---
name: settings [67303,67311]
name: settings [67315,67323]
===
match
---
atom_expr [24072,24084]
atom_expr [24072,24084]
===
match
---
trailer [10995,11031]
trailer [10995,11031]
===
match
---
string: "--mark-success" [18929,18945]
string: "--mark-success" [18929,18945]
===
match
---
name: job_id [16292,16298]
name: job_id [16292,16298]
===
match
---
arglist [57581,57592]
arglist [57593,57604]
===
match
---
name: contextlib [794,804]
name: contextlib [794,804]
===
match
---
decorator [29442,29452]
decorator [29442,29452]
===
match
---
name: SUCCESS [26891,26898]
name: SUCCESS [26891,26898]
===
match
---
simple_stmt [48944,49006]
simple_stmt [48944,49006]
===
match
---
trailer [35552,35586]
trailer [35552,35586]
===
match
---
name: max [9356,9359]
name: max [9356,9359]
===
match
---
fstring_string: <TaskInstance:  [33875,33890]
fstring_string: <TaskInstance:  [33875,33890]
===
match
---
operator: , [1060,1061]
operator: , [1060,1061]
===
match
---
atom_expr [35488,35517]
atom_expr [35488,35517]
===
match
---
name: str [78318,78321]
name: str [78330,78333]
===
match
---
name: test_mode [43893,43902]
name: test_mode [43893,43902]
===
match
---
tfpdef [51747,51775]
tfpdef [51747,51775]
===
match
---
import_from [2240,2273]
import_from [2240,2273]
===
match
---
if_stmt [19645,19707]
if_stmt [19645,19707]
===
match
---
name: execution_date [12948,12962]
name: execution_date [12948,12962]
===
match
---
name: state [51365,51370]
name: state [51365,51370]
===
match
---
atom_expr [34546,34609]
atom_expr [34546,34609]
===
match
---
funcdef [42390,42853]
funcdef [42390,42853]
===
match
---
trailer [77368,77372]
trailer [77380,77384]
===
match
---
expr_stmt [36287,36454]
expr_stmt [36287,36454]
===
match
---
if_stmt [41959,42196]
if_stmt [41959,42196]
===
match
---
name: primary_key [10524,10535]
name: primary_key [10524,10535]
===
match
---
trailer [7727,7732]
trailer [7727,7732]
===
match
---
name: self [26693,26697]
name: self [26693,26697]
===
match
---
suite [22483,22513]
suite [22483,22513]
===
match
---
simple_stmt [76970,77173]
simple_stmt [76982,77185]
===
match
---
suite [8595,8763]
suite [8595,8763]
===
match
---
name: dirname [69259,69266]
name: dirname [69271,69278]
===
match
---
name: TaskInstanceKey [78104,78119]
name: TaskInstanceKey [78116,78131]
===
match
---
name: _try_number [14801,14812]
name: _try_number [14801,14812]
===
match
---
operator: + [20222,20223]
operator: + [20222,20223]
===
match
---
trailer [30403,30441]
trailer [30403,30441]
===
match
---
atom_expr [22727,22735]
atom_expr [22727,22735]
===
match
---
operator: = [40387,40388]
operator: = [40387,40388]
===
match
---
atom_expr [44261,44273]
atom_expr [44261,44273]
===
match
---
funcdef [79393,79455]
funcdef [79405,79467]
===
match
---
tfpdef [51872,51890]
tfpdef [51872,51890]
===
match
---
or_test [25388,25419]
or_test [25388,25419]
===
match
---
atom_expr [30711,30738]
atom_expr [30711,30738]
===
match
---
fstring_end: " [59868,59869]
fstring_end: " [59880,59881]
===
match
---
if_stmt [55318,55385]
if_stmt [55330,55397]
===
match
---
operator: , [4001,4002]
operator: , [4001,4002]
===
match
---
parameters [79632,79638]
parameters [79644,79650]
===
match
---
operator: , [966,967]
operator: , [966,967]
===
match
---
name: ti [80813,80815]
name: ti [80825,80827]
===
match
---
name: are_dependencies_met [31846,31866]
name: are_dependencies_met [31846,31866]
===
match
---
name: self [14146,14150]
name: self [14146,14150]
===
match
---
atom_expr [79268,79288]
atom_expr [79280,79300]
===
match
---
name: COLLATION_ARGS [11348,11362]
name: COLLATION_ARGS [11348,11362]
===
match
---
for_stmt [32719,33053]
for_stmt [32719,33053]
===
match
---
trailer [15608,15617]
trailer [15608,15617]
===
match
---
simple_stmt [78585,78613]
simple_stmt [78597,78625]
===
match
---
atom_expr [32666,32679]
atom_expr [32666,32679]
===
match
---
atom_expr [25388,25403]
atom_expr [25388,25403]
===
match
---
name: log [40877,40880]
name: log [40877,40880]
===
match
---
argument [52327,52358]
argument [52327,52358]
===
match
---
trailer [19438,19445]
trailer [19438,19445]
===
match
---
string: 'ts' [63912,63916]
string: 'ts' [63924,63928]
===
match
---
operator: = [13389,13390]
operator: = [13389,13390]
===
match
---
suite [3191,3213]
suite [3191,3213]
===
match
---
simple_stmt [44466,44509]
simple_stmt [44466,44509]
===
match
---
atom_expr [49245,49262]
atom_expr [49245,49262]
===
match
---
simple_stmt [81051,81095]
simple_stmt [81063,81107]
===
match
---
operator: == [24610,24612]
operator: == [24610,24612]
===
match
---
name: log [54258,54261]
name: log [54258,54261]
===
match
---
name: t [77394,77395]
name: t [77406,77407]
===
match
---
operator: = [16245,16246]
operator: = [16245,16246]
===
match
---
name: pickle_id [19010,19019]
name: pickle_id [19010,19019]
===
match
---
suite [49803,49868]
suite [49803,49868]
===
match
---
trailer [62855,62864]
trailer [62867,62876]
===
match
---
import_from [901,936]
import_from [901,936]
===
match
---
trailer [19064,19091]
trailer [19064,19091]
===
match
---
funcdef [4264,4663]
funcdef [4264,4663]
===
match
---
name: TaskInstance [20969,20981]
name: TaskInstance [20969,20981]
===
match
---
name: log [3760,3763]
name: log [3760,3763]
===
match
---
operator: , [16559,16560]
operator: , [16559,16560]
===
match
---
atom_expr [78995,79006]
atom_expr [79007,79018]
===
match
---
dotted_name [1108,1120]
dotted_name [1108,1120]
===
match
---
name: next_execution_date [58739,58758]
name: next_execution_date [58751,58770]
===
match
---
if_stmt [48519,48684]
if_stmt [48519,48684]
===
match
---
tfpdef [66229,66255]
tfpdef [66241,66267]
===
match
---
atom_expr [25370,25385]
atom_expr [25370,25385]
===
match
---
atom_expr [71046,71061]
atom_expr [71058,71073]
===
match
---
operator: = [59771,59772]
operator: = [59783,59784]
===
match
---
suite [28735,28819]
suite [28735,28819]
===
match
---
arglist [4076,4090]
arglist [4076,4090]
===
match
---
name: execution_date [30564,30578]
name: execution_date [30564,30578]
===
match
---
string: """Initialize the attributes that aren't stored in the DB""" [13453,13513]
string: """Initialize the attributes that aren't stored in the DB""" [13453,13513]
===
match
---
expr_stmt [78811,78836]
expr_stmt [78823,78848]
===
match
---
operator: = [25244,25245]
operator: = [25244,25245]
===
match
---
simple_stmt [46750,46812]
simple_stmt [46750,46812]
===
match
---
simple_stmt [65414,65485]
simple_stmt [65426,65497]
===
match
---
name: ignore_all_deps [39135,39150]
name: ignore_all_deps [39135,39150]
===
match
---
simple_stmt [29523,29663]
simple_stmt [29523,29663]
===
match
---
expr_stmt [67799,67840]
expr_stmt [67811,67852]
===
match
---
operator: = [57327,57328]
operator: = [57339,57340]
===
match
---
operator: = [72757,72758]
operator: = [72769,72770]
===
match
---
name: self [42405,42409]
name: self [42405,42409]
===
match
---
operator: , [62362,62363]
operator: , [62374,62375]
===
match
---
name: log [42021,42024]
name: log [42021,42024]
===
match
---
suite [33499,33833]
suite [33499,33833]
===
match
---
atom_expr [76032,76040]
atom_expr [76044,76052]
===
match
---
operator: = [69182,69183]
operator: = [69194,69195]
===
match
---
name: params [57643,57649]
name: params [57655,57661]
===
match
---
name: merge [56689,56694]
name: merge [56701,56706]
===
match
---
name: raw [19528,19531]
name: raw [19528,19531]
===
match
---
operator: = [59066,59067]
operator: = [59078,59079]
===
match
---
argument [66797,66844]
argument [66809,66856]
===
match
---
name: execution_date [72319,72333]
name: execution_date [72331,72345]
===
match
---
name: cmd [19601,19604]
name: cmd [19601,19604]
===
match
---
expr_stmt [60407,60422]
expr_stmt [60419,60434]
===
match
---
param [53406,53411]
param [53406,53411]
===
match
---
name: TR [40002,40004]
name: TR [40002,40004]
===
match
---
name: construct_task_instance [80034,80057]
name: construct_task_instance [80046,80069]
===
match
---
fstring_expr [33919,33940]
fstring_expr [33919,33940]
===
match
---
atom_expr [47652,47714]
atom_expr [47652,47714]
===
match
---
name: self [79911,79915]
name: self [79923,79927]
===
match
---
atom_expr [20969,20989]
atom_expr [20969,20989]
===
match
---
expr_stmt [44055,44085]
expr_stmt [44055,44085]
===
match
---
param [54505,54538]
param [54505,54538]
===
match
---
name: task_id [75275,75282]
name: task_id [75287,75294]
===
match
---
name: key [71316,71319]
name: key [71328,71331]
===
match
---
name: verbose [41962,41969]
name: verbose [41962,41969]
===
match
---
name: VariableJsonAccessor [64055,64075]
name: VariableJsonAccessor [64067,64087]
===
match
---
atom_expr [18982,19022]
atom_expr [18982,19022]
===
match
---
name: TaskInstance [77653,77665]
name: TaskInstance [77665,77677]
===
match
---
funcdef [31261,31816]
funcdef [31261,31816]
===
match
---
param [15141,15153]
param [15141,15153]
===
match
---
operator: == [36400,36402]
operator: == [36400,36402]
===
match
---
except_clause [4197,4213]
except_clause [4197,4213]
===
match
---
name: refresh_from_db [45570,45585]
name: refresh_from_db [45570,45585]
===
match
---
name: error_fd [52632,52640]
name: error_fd [52632,52640]
===
match
---
simple_stmt [18917,18948]
simple_stmt [18917,18948]
===
match
---
atom_expr [52993,53006]
atom_expr [52993,53006]
===
match
---
simple_stmt [28509,28578]
simple_stmt [28509,28578]
===
match
---
trailer [29954,29975]
trailer [29954,29975]
===
match
---
name: should_pass_filepath [15559,15579]
name: should_pass_filepath [15559,15579]
===
match
---
atom [64029,64137]
atom [64041,64149]
===
match
---
name: operator [23293,23301]
name: operator [23293,23301]
===
match
---
trailer [44921,44927]
trailer [44921,44927]
===
match
---
arglist [59793,59800]
arglist [59805,59812]
===
match
---
operator: = [12875,12876]
operator: = [12875,12876]
===
match
---
operator: == [8402,8404]
operator: == [8402,8404]
===
match
---
name: self [12205,12209]
name: self [12205,12209]
===
match
---
trailer [78472,78483]
trailer [78484,78495]
===
match
---
simple_stmt [49509,49581]
simple_stmt [49509,49581]
===
match
---
trailer [33687,33694]
trailer [33687,33694]
===
match
---
name: self [47157,47161]
name: self [47157,47161]
===
match
---
name: ti [78908,78910]
name: ti [78920,78922]
===
match
---
atom_expr [24906,24925]
atom_expr [24906,24925]
===
match
---
name: first [22462,22467]
name: first [22462,22467]
===
match
---
operator: , [53451,53452]
operator: , [53451,53452]
===
match
---
suite [80117,80848]
suite [80129,80860]
===
match
---
trailer [26742,26768]
trailer [26742,26768]
===
match
---
trailer [15888,15896]
trailer [15888,15896]
===
match
---
name: on_execute_callback [50409,50428]
name: on_execute_callback [50409,50428]
===
match
---
name: self [58185,58189]
name: self [58197,58201]
===
match
---
trailer [54739,54757]
trailer [54739,54757]
===
match
---
name: self [71028,71032]
name: self [71040,71044]
===
match
---
string: """         Set TaskInstance state.          :param state: State to set for the TI         :type state: str         :param session: SQLAlchemy ORM Session         :type session: Session         """ [25025,25222]
string: """         Set TaskInstance state.          :param state: State to set for the TI         :type state: str         :param session: SQLAlchemy ORM Session         :type session: Session         """ [25025,25222]
===
match
---
decorated [31821,33185]
decorated [31821,33185]
===
match
---
trailer [46676,46681]
trailer [46676,46681]
===
match
---
name: ready_for_retry [35737,35752]
name: ready_for_retry [35737,35752]
===
match
---
trailer [78970,78986]
trailer [78982,78998]
===
match
---
parameters [79405,79411]
parameters [79417,79423]
===
match
---
funcdef [75521,75944]
funcdef [75533,75956]
===
match
---
name: state [7649,7654]
name: state [7649,7654]
===
match
---
name: execution_timeout [49693,49710]
name: execution_timeout [49693,49710]
===
match
---
atom_expr [12926,12945]
atom_expr [12926,12945]
===
match
---
name: filter [22214,22220]
name: filter [22214,22220]
===
match
---
operator: = [80816,80817]
operator: = [80828,80829]
===
match
---
atom_expr [7035,7094]
atom_expr [7035,7094]
===
match
---
string: 'utf-8' [34873,34880]
string: 'utf-8' [34873,34880]
===
match
---
operator: , [70128,70129]
operator: , [70140,70141]
===
match
---
testlist_star_expr [70697,70736]
testlist_star_expr [70709,70748]
===
match
---
operator: { [75071,75072]
operator: { [75083,75084]
===
match
---
operator: = [39069,39070]
operator: = [39069,39070]
===
match
---
trailer [29497,29513]
trailer [29497,29513]
===
match
---
name: state [13061,13066]
name: state [13061,13066]
===
match
---
operator: , [80634,80635]
operator: , [80646,80647]
===
match
---
name: args [66983,66987]
name: args [66995,66999]
===
match
---
decorated [79201,79289]
decorated [79213,79301]
===
match
---
name: ignore_ti_state [40635,40650]
name: ignore_ti_state [40635,40650]
===
match
---
operator: = [44347,44348]
operator: = [44347,44348]
===
match
---
except_clause [44556,44595]
except_clause [44556,44595]
===
match
---
trailer [76981,77172]
trailer [76993,77184]
===
match
---
comparison [54637,54654]
comparison [54637,54654]
===
match
---
argument [52221,52266]
argument [52221,52266]
===
match
---
atom_expr [78342,78355]
atom_expr [78354,78367]
===
match
---
name: instance [31213,31221]
name: instance [31213,31221]
===
match
---
name: property [14263,14271]
name: property [14263,14271]
===
match
---
trailer [26747,26767]
trailer [26747,26767]
===
match
---
param [16530,16560]
param [16530,16560]
===
match
---
expr_stmt [67736,67789]
expr_stmt [67748,67801]
===
match
---
operator: ** [34583,34585]
operator: ** [34583,34585]
===
match
---
name: ti [6073,6075]
name: ti [6073,6075]
===
match
---
name: exception [68968,68977]
name: exception [68980,68989]
===
match
---
testlist_comp [65715,65753]
testlist_comp [65727,65765]
===
match
---
operator: , [72738,72739]
operator: , [72750,72751]
===
match
---
trailer [57088,57101]
trailer [57100,57113]
===
match
---
funcdef [62328,62654]
funcdef [62340,62666]
===
match
---
trailer [42141,42195]
trailer [42141,42195]
===
match
---
trailer [31229,31240]
trailer [31229,31240]
===
match
---
expr_stmt [22496,22512]
expr_stmt [22496,22512]
===
match
---
param [36027,36032]
param [36027,36032]
===
match
---
parameters [66222,66263]
parameters [66234,66275]
===
match
---
name: FAILED [56187,56193]
name: FAILED [56199,56205]
===
match
---
trailer [23957,23973]
trailer [23957,23973]
===
match
---
name: Connection [62520,62530]
name: Connection [62532,62542]
===
match
---
name: t [77373,77374]
name: t [77385,77386]
===
match
---
name: self [53137,53141]
name: self [53137,53141]
===
match
---
trailer [10949,10954]
trailer [10949,10954]
===
match
---
atom_expr [75755,75774]
atom_expr [75767,75786]
===
match
---
name: task [34234,34238]
name: task [34234,34238]
===
match
---
name: execution_date [74605,74619]
name: execution_date [74617,74631]
===
match
---
string: "\n" [38808,38812]
string: "\n" [38808,38812]
===
match
---
atom_expr [26961,26990]
atom_expr [26961,26990]
===
match
---
name: item [60729,60733]
name: item [60741,60745]
===
match
---
and_test [56445,56475]
and_test [56457,56487]
===
match
---
name: Tuple [8973,8978]
name: Tuple [8973,8978]
===
match
---
operator: -> [80101,80103]
operator: -> [80113,80115]
===
match
---
name: self [78441,78445]
name: self [78453,78457]
===
match
---
operator: == [77074,77076]
operator: == [77086,77088]
===
match
---
name: KubeConfig [3099,3109]
name: KubeConfig [3099,3109]
===
match
---
simple_stmt [78158,78253]
simple_stmt [78170,78265]
===
match
---
simple_stmt [79511,79535]
simple_stmt [79523,79547]
===
match
---
name: AirflowNotFoundException [62588,62612]
name: AirflowNotFoundException [62600,62624]
===
match
---
simple_stmt [44026,44047]
simple_stmt [44026,44047]
===
match
---
name: self [35657,35661]
name: self [35657,35661]
===
match
---
name: airflow [1545,1552]
name: airflow [1545,1552]
===
match
---
name: self [48648,48652]
name: self [48648,48652]
===
match
---
operator: , [64221,64222]
operator: , [64233,64234]
===
match
---
operator: , [4077,4078]
operator: , [4077,4078]
===
match
---
arglist [48326,48479]
arglist [48326,48479]
===
match
---
string: """         This attribute is deprecated.         Please use `airflow.models.taskinstance.TaskInstance.get_previous_ti` method.         """ [29003,29142]
string: """         This attribute is deprecated.         Please use `airflow.models.taskinstance.TaskInstance.get_previous_ti` method.         """ [29003,29142]
===
match
---
simple_stmt [50230,50244]
simple_stmt [50230,50244]
===
match
---
atom_expr [28045,28064]
atom_expr [28045,28064]
===
match
---
name: get_email_subject_content [70744,70769]
name: get_email_subject_content [70756,70781]
===
match
---
name: execution_date [77743,77757]
name: execution_date [77755,77769]
===
match
---
tfpdef [71334,71344]
tfpdef [71346,71356]
===
match
---
param [16494,16521]
param [16494,16521]
===
match
---
name: relationship [11836,11848]
name: relationship [11836,11848]
===
match
---
name: deserialize_value [75471,75488]
name: deserialize_value [75483,75500]
===
match
---
name: operator [24150,24158]
name: operator [24150,24158]
===
match
---
trailer [56723,56725]
trailer [56735,56737]
===
match
---
operator: = [66908,66909]
operator: = [66920,66921]
===
match
---
operator: -> [79329,79331]
operator: -> [79341,79343]
===
match
---
except_clause [45928,45970]
except_clause [45928,45970]
===
match
---
name: session [6220,6227]
name: session [6220,6227]
===
match
---
name: Column [11199,11205]
name: Column [11199,11205]
===
match
---
trailer [75697,75703]
trailer [75709,75715]
===
match
---
atom_expr [19972,19984]
atom_expr [19972,19984]
===
match
---
parameters [57131,57137]
parameters [57143,57149]
===
match
---
atom_expr [22112,22170]
atom_expr [22112,22170]
===
match
---
operator: = [45484,45485]
operator: = [45484,45485]
===
match
---
trailer [23836,23842]
trailer [23836,23842]
===
match
---
name: test_mode [43905,43914]
name: test_mode [43905,43914]
===
match
---
operator: = [27436,27437]
operator: = [27436,27437]
===
match
---
atom_expr [52687,52933]
atom_expr [52687,52933]
===
match
---
if_stmt [55051,55116]
if_stmt [55063,55128]
===
match
---
name: session [26020,26027]
name: session [26020,26027]
===
match
---
name: task_reschedule [40084,40099]
name: task_reschedule [40084,40099]
===
match
---
name: reason [33727,33733]
name: reason [33727,33733]
===
match
---
operator: = [59822,59823]
operator: = [59834,59835]
===
match
---
operator: , [60500,60501]
operator: , [60512,60513]
===
match
---
simple_stmt [20100,20145]
simple_stmt [20100,20145]
===
match
---
name: self [33905,33909]
name: self [33905,33909]
===
match
---
simple_stmt [59627,59684]
simple_stmt [59639,59696]
===
match
---
string: "Starting attempt %s of %s" [41445,41472]
string: "Starting attempt %s of %s" [41445,41472]
===
match
---
atom_expr [78868,78881]
atom_expr [78880,78893]
===
match
---
name: info [32675,32679]
name: info [32675,32679]
===
match
---
name: pendulum [1193,1201]
name: pendulum [1193,1201]
===
match
---
name: dep_context [33385,33396]
name: dep_context [33385,33396]
===
match
---
name: defaultdict [5256,5267]
name: defaultdict [5256,5267]
===
match
---
simple_stmt [2658,2701]
simple_stmt [2658,2701]
===
match
---
suite [14223,14257]
suite [14223,14257]
===
match
---
trailer [4186,4192]
trailer [4186,4192]
===
match
---
simple_stmt [58169,58242]
simple_stmt [58181,58254]
===
match
---
name: log [24428,24431]
name: log [24428,24431]
===
match
---
trailer [26609,26615]
trailer [26609,26615]
===
match
---
operator: = [22499,22500]
operator: = [22499,22500]
===
match
---
name: session [21587,21594]
name: session [21587,21594]
===
match
---
name: priority_weight [11759,11774]
name: priority_weight [11759,11774]
===
match
---
fstring_string: ]> [33954,33956]
fstring_string: ]> [33954,33956]
===
match
---
simple_stmt [33085,33098]
simple_stmt [33085,33098]
===
match
---
operator: , [70704,70705]
operator: , [70716,70717]
===
match
---
name: try_number [9601,9611]
name: try_number [9601,9611]
===
match
---
name: ti [78470,78472]
name: ti [78482,78484]
===
match
---
trailer [30976,30982]
trailer [30976,30982]
===
match
---
atom_expr [51132,51142]
atom_expr [51132,51142]
===
match
---
trailer [77011,77018]
trailer [77023,77030]
===
match
---
name: e [45969,45970]
name: e [45969,45970]
===
match
---
trailer [34872,34881]
trailer [34872,34881]
===
match
---
string: """Return task instance primary key part of the key""" [9008,9062]
string: """Return task instance primary key part of the key""" [9008,9062]
===
match
---
name: hostname [10828,10836]
name: hostname [10828,10836]
===
match
---
param [15205,15217]
param [15205,15217]
===
match
---
dotted_name [81010,81031]
dotted_name [81022,81043]
===
match
---
return_stmt [60579,60594]
return_stmt [60591,60606]
===
match
---
name: staticmethod [61569,61581]
name: staticmethod [61581,61593]
===
match
---
trailer [30664,30669]
trailer [30664,30669]
===
match
---
trailer [46841,46843]
trailer [46841,46843]
===
match
---
name: state [21530,21535]
name: state [21530,21535]
===
match
---
trailer [58133,58148]
trailer [58145,58160]
===
match
---
name: XCom [74578,74582]
name: XCom [74590,74594]
===
match
---
name: session [46405,46412]
name: session [46405,46412]
===
match
---
name: pod_template_file [67265,67282]
name: pod_template_file [67277,67294]
===
match
---
operator: = [59253,59254]
operator: = [59265,59266]
===
match
---
suite [19202,19253]
suite [19202,19253]
===
match
---
operator: -> [52035,52037]
operator: -> [52035,52037]
===
match
---
simple_stmt [7509,7551]
simple_stmt [7509,7551]
===
match
---
funcdef [13421,13582]
funcdef [13421,13582]
===
match
---
operator: , [36712,36713]
operator: , [36712,36713]
===
match
---
name: AirflowTaskTimeout [1811,1829]
name: AirflowTaskTimeout [1811,1829]
===
match
---
param [60491,60501]
param [60503,60513]
===
match
---
expr_stmt [49991,50034]
expr_stmt [49991,50034]
===
match
---
fstring_string: . [46139,46140]
fstring_string: . [46139,46140]
===
match
---
name: ignore_all_deps [15998,16013]
name: ignore_all_deps [15998,16013]
===
match
---
name: default_subject [69353,69368]
name: default_subject [69365,69380]
===
match
---
name: DagRun [8388,8394]
name: DagRun [8388,8394]
===
match
---
name: contextmanager [3345,3359]
name: contextmanager [3345,3359]
===
match
---
atom_expr [33905,33917]
atom_expr [33905,33917]
===
match
---
trailer [54261,54266]
trailer [54261,54266]
===
match
---
suite [55335,55385]
suite [55347,55397]
===
match
---
operator: -> [79159,79161]
operator: -> [79171,79173]
===
match
---
atom_expr [30720,30737]
atom_expr [30720,30737]
===
match
---
atom_expr [11124,11136]
atom_expr [11124,11136]
===
match
---
raise_stmt [64904,65279]
raise_stmt [64916,65291]
===
match
---
simple_stmt [49227,49263]
simple_stmt [49227,49263]
===
match
---
string: 'prev_execution_date_success' [63299,63328]
string: 'prev_execution_date_success' [63311,63340]
===
match
---
atom_expr [10688,10701]
atom_expr [10688,10701]
===
match
---
name: dag [15706,15709]
name: dag [15706,15709]
===
match
---
fstring_start: f" [59824,59826]
fstring_start: f" [59836,59838]
===
match
---
name: self [41080,41084]
name: self [41080,41084]
===
match
---
name: dag [4745,4748]
name: dag [4745,4748]
===
match
---
name: bool [16672,16676]
name: bool [16672,16676]
===
match
---
operator: = [75380,75381]
operator: = [75392,75393]
===
match
---
fstring_string: DAGS_FOLDER/ [15640,15652]
fstring_string: DAGS_FOLDER/ [15640,15652]
===
match
---
operator: , [1078,1079]
operator: , [1078,1079]
===
match
---
param [16460,16485]
param [16460,16485]
===
match
---
name: and_ [77272,77276]
name: and_ [77284,77288]
===
match
---
operator: , [11544,11545]
operator: , [11544,11545]
===
match
---
name: self [13438,13442]
name: self [13438,13442]
===
match
---
trailer [54213,54219]
trailer [54213,54219]
===
match
---
name: self [70739,70743]
name: self [70751,70755]
===
match
---
if_stmt [76878,77173]
if_stmt [76890,77185]
===
match
---
trailer [46926,46933]
trailer [46926,46933]
===
match
---
not_test [38852,38868]
not_test [38852,38868]
===
match
---
name: task [53756,53760]
name: task [53756,53760]
===
match
---
try_stmt [4154,4262]
try_stmt [4154,4262]
===
match
---
arglist [70399,70444]
arglist [70411,70456]
===
match
---
name: test_mode [54637,54646]
name: test_mode [54637,54646]
===
match
---
operator: = [60542,60543]
operator: = [60554,60555]
===
match
---
trailer [46260,46262]
trailer [46260,46262]
===
match
---
string: 'Immediate failure requested. ' [56379,56410]
string: 'Immediate failure requested. ' [56391,56422]
===
match
---
name: str [72753,72756]
name: str [72765,72768]
===
match
---
string: "Failed to load task run error" [4230,4261]
string: "Failed to load task run error" [4230,4261]
===
match
---
operator: , [66227,66228]
operator: , [66239,66240]
===
match
---
name: debug [32705,32710]
name: debug [32705,32710]
===
match
---
simple_stmt [1018,1103]
simple_stmt [1018,1103]
===
match
---
dotted_name [7514,7535]
dotted_name [7514,7535]
===
match
---
atom_expr [36306,36444]
atom_expr [36306,36444]
===
match
---
suite [25496,25633]
suite [25496,25633]
===
match
---
trailer [12296,12312]
trailer [12296,12312]
===
match
---
name: Optional [16734,16742]
name: Optional [16734,16742]
===
match
---
atom_expr [49923,49942]
atom_expr [49923,49942]
===
match
---
name: _handle_reschedule [45063,45081]
name: _handle_reschedule [45063,45081]
===
match
---
trailer [13114,13127]
trailer [13114,13127]
===
match
---
atom_expr [54006,54016]
atom_expr [54006,54016]
===
match
---
atom_expr [77421,77441]
atom_expr [77433,77453]
===
match
---
funcdef [24202,24722]
funcdef [24202,24722]
===
match
---
name: self [14066,14070]
name: self [14066,14070]
===
match
---
simple_stmt [9071,9125]
simple_stmt [9071,9125]
===
match
---
name: execution_date [12831,12845]
name: execution_date [12831,12845]
===
match
---
name: context [44439,44446]
name: context [44439,44446]
===
match
---
operator: = [64505,64506]
operator: = [64517,64518]
===
match
---
atom_expr [5236,5294]
atom_expr [5236,5294]
===
match
---
trailer [7278,7284]
trailer [7278,7284]
===
match
---
trailer [22461,22467]
trailer [22461,22467]
===
match
---
operator: = [72506,72507]
operator: = [72518,72519]
===
match
---
trailer [63383,63411]
trailer [63395,63423]
===
match
---
name: filter [75731,75737]
name: filter [75743,75749]
===
match
---
name: contextlib [3334,3344]
name: contextlib [3334,3344]
===
match
---
operator: = [18787,18788]
operator: = [18787,18788]
===
match
---
name: self [33943,33947]
name: self [33943,33947]
===
match
---
trailer [58837,58855]
trailer [58849,58867]
===
match
---
name: task_copy [49923,49932]
name: task_copy [49923,49932]
===
match
---
trailer [55294,55309]
trailer [55306,55321]
===
match
---
trailer [14236,14248]
trailer [14236,14248]
===
match
---
trailer [15914,15929]
trailer [15914,15929]
===
match
---
trailer [77372,77403]
trailer [77384,77415]
===
match
---
atom_expr [65783,65858]
atom_expr [65795,65870]
===
match
---
simple_stmt [29003,29143]
simple_stmt [29003,29143]
===
match
---
name: task_id [22295,22302]
name: task_id [22295,22302]
===
match
---
atom_expr [11117,11137]
atom_expr [11117,11137]
===
match
---
trailer [77306,77313]
trailer [77318,77325]
===
match
---
name: refresh_from_task [5619,5636]
name: refresh_from_task [5619,5636]
===
match
---
and_test [15681,15723]
and_test [15681,15723]
===
match
---
name: Context [3393,3400]
name: Context [3393,3400]
===
match
---
name: self [66223,66227]
name: self [66235,66239]
===
match
---
name: context [50018,50025]
name: context [50018,50025]
===
match
---
trailer [23119,23124]
trailer [23119,23124]
===
match
---
trailer [28132,28137]
trailer [28132,28137]
===
match
---
argument [47268,47275]
argument [47268,47275]
===
match
---
simple_stmt [978,1018]
simple_stmt [978,1018]
===
match
---
atom_expr [12736,12758]
atom_expr [12736,12758]
===
match
---
atom_expr [80571,80583]
atom_expr [80583,80595]
===
match
---
dotted_name [2706,2736]
dotted_name [2706,2736]
===
match
---
expr_stmt [49227,49262]
expr_stmt [49227,49262]
===
match
---
operator: , [40550,40551]
operator: , [40550,40551]
===
match
---
argument [31056,31067]
argument [31056,31067]
===
match
---
simple_stmt [58250,58322]
simple_stmt [58262,58334]
===
match
---
trailer [34712,34899]
trailer [34712,34899]
===
match
---
name: airflow [2915,2922]
name: airflow [2915,2922]
===
match
---
name: Stats [44224,44229]
name: Stats [44224,44229]
===
match
---
for_stmt [33374,33833]
for_stmt [33374,33833]
===
match
---
operator: = [51178,51179]
operator: = [51178,51179]
===
match
---
operator: , [16352,16353]
operator: , [16352,16353]
===
match
---
param [14216,14221]
param [14216,14221]
===
match
---
trailer [52566,52586]
trailer [52566,52586]
===
match
---
number: 256 [11058,11061]
number: 256 [11058,11061]
===
match
---
name: task_id [24553,24560]
name: task_id [24553,24560]
===
match
---
trailer [48949,48954]
trailer [48949,48954]
===
match
---
param [16569,16606]
param [16569,16606]
===
match
---
operator: , [52266,52267]
operator: , [52266,52267]
===
match
---
name: commit [49307,49313]
name: commit [49307,49313]
===
match
---
name: self [42712,42716]
name: self [42712,42716]
===
match
---
trailer [10888,10894]
trailer [10888,10894]
===
match
---
trailer [75127,75135]
trailer [75139,75147]
===
match
---
operator: = [10535,10536]
operator: = [10535,10536]
===
match
---
funcdef [35733,35986]
funcdef [35733,35986]
===
match
---
name: incr [38677,38681]
name: incr [38677,38681]
===
match
---
name: default_var [60922,60933]
name: default_var [60934,60945]
===
match
---
operator: , [61835,61836]
operator: , [61847,61848]
===
match
---
string: 'Log: <a href="{{ti.log_url}}">Link</a><br>' [68506,68550]
string: 'Log: <a href="{{ti.log_url}}">Link</a><br>' [68518,68562]
===
match
---
trailer [24552,24560]
trailer [24552,24560]
===
match
---
expr_stmt [11106,11137]
expr_stmt [11106,11137]
===
match
---
trailer [70058,70069]
trailer [70070,70081]
===
match
---
fstring_start: f" [33873,33875]
fstring_start: f" [33873,33875]
===
match
---
trailer [52880,52885]
trailer [52880,52885]
===
match
---
atom_expr [4079,4090]
atom_expr [4079,4090]
===
match
---
name: conf [66191,66195]
name: conf [66203,66207]
===
match
---
string: """     Simplified Task Instance.      Used to send data between processes via Queues.     """ [78158,78252]
string: """     Simplified Task Instance.      Used to send data between processes via Queues.     """ [78170,78264]
===
match
---
name: item [60491,60495]
name: item [60503,60507]
===
match
---
name: tis [77399,77402]
name: tis [77411,77414]
===
match
---
trailer [70483,70534]
trailer [70495,70546]
===
match
---
return_stmt [79511,79534]
return_stmt [79523,79546]
===
match
---
name: airflow [2085,2092]
name: airflow [2085,2092]
===
match
---
decorator [76084,76098]
decorator [76096,76110]
===
match
---
name: e [44809,44810]
name: e [44809,44810]
===
match
---
trailer [54010,54016]
trailer [54010,54016]
===
match
---
atom_expr [7040,7053]
atom_expr [7040,7053]
===
match
---
operator: , [9103,9104]
operator: , [9103,9104]
===
match
---
name: str [3998,4001]
name: str [3998,4001]
===
match
---
name: exception [67473,67482]
name: exception [67485,67494]
===
match
---
operator: , [63599,63600]
operator: , [63611,63612]
===
match
---
atom_expr [36348,36361]
atom_expr [36348,36361]
===
match
---
operator: = [16096,16097]
operator: = [16096,16097]
===
match
---
with_stmt [70155,70220]
with_stmt [70167,70232]
===
match
---
trailer [47661,47714]
trailer [47661,47714]
===
match
---
operator: , [72387,72388]
operator: , [72399,72400]
===
match
---
operator: , [42287,42288]
operator: , [42287,42288]
===
match
---
name: Optional [72718,72726]
name: Optional [72730,72738]
===
match
---
operator: , [47372,47373]
operator: , [47372,47373]
===
match
---
name: debug [66078,66083]
name: debug [66090,66095]
===
match
---
number: 1 [8931,8932]
number: 1 [8931,8932]
===
match
---
trailer [32765,32807]
trailer [32765,32807]
===
match
---
operator: , [9564,9565]
operator: , [9564,9565]
===
match
---
name: self [29414,29418]
name: self [29414,29418]
===
match
---
suite [27552,28215]
suite [27552,28215]
===
match
---
name: expected_state [3913,3927]
name: expected_state [3913,3927]
===
match
---
trailer [59726,59734]
trailer [59738,59746]
===
match
---
name: TaskInstance [20917,20929]
name: TaskInstance [20917,20929]
===
match
---
operator: , [72573,72574]
operator: , [72585,72586]
===
match
---
name: e [64885,64886]
name: e [64897,64898]
===
match
---
trailer [23897,23902]
trailer [23897,23902]
===
match
---
operator: , [66931,66932]
operator: , [66943,66944]
===
match
---
name: self [23953,23957]
name: self [23953,23957]
===
match
---
arglist [70484,70533]
arglist [70496,70545]
===
match
---
trailer [34238,34264]
trailer [34238,34264]
===
match
---
trailer [71200,71204]
trailer [71212,71216]
===
match
---
operator: = [75979,75980]
operator: = [75991,75992]
===
match
---
trailer [71242,71251]
trailer [71254,71263]
===
match
---
testlist_comp [19682,19704]
testlist_comp [19682,19704]
===
match
---
simple_stmt [46502,46535]
simple_stmt [46502,46535]
===
match
---
name: cmd [19435,19438]
name: cmd [19435,19438]
===
match
---
atom_expr [10943,10954]
atom_expr [10943,10954]
===
match
---
name: AirflowRescheduleException [44959,44985]
name: AirflowRescheduleException [44959,44985]
===
match
---
name: self [9156,9160]
name: self [9156,9160]
===
match
---
name: ceil [34551,34555]
name: ceil [34551,34555]
===
match
---
expr_stmt [43863,43879]
expr_stmt [43863,43879]
===
match
---
name: qry [80757,80760]
name: qry [80769,80772]
===
match
---
atom_expr [47094,47110]
atom_expr [47094,47110]
===
match
---
trailer [57614,57618]
trailer [57626,57630]
===
match
---
name: self [12135,12139]
name: self [12135,12139]
===
match
---
trailer [23933,23944]
trailer [23933,23944]
===
match
---
suite [50305,50579]
suite [50305,50579]
===
match
---
trailer [60911,60915]
trailer [60923,60927]
===
match
---
name: default_var [60934,60945]
name: default_var [60946,60957]
===
match
---
trailer [80827,80829]
trailer [80839,80841]
===
match
---
name: int [9428,9431]
name: int [9428,9431]
===
match
---
name: prev_ds [59334,59341]
name: prev_ds [59346,59353]
===
match
---
trailer [12438,12454]
trailer [12438,12454]
===
match
---
arglist [6849,7305]
arglist [6849,7305]
===
match
---
expr_stmt [50986,51023]
expr_stmt [50986,51023]
===
match
---
simple_stmt [72358,72585]
simple_stmt [72370,72597]
===
match
---
trailer [42077,42092]
trailer [42077,42092]
===
match
---
operator: , [32965,32966]
operator: , [32965,32966]
===
match
---
atom_expr [41909,41934]
atom_expr [41909,41934]
===
match
---
not_test [67702,67727]
not_test [67714,67739]
===
match
---
atom_expr [45388,45410]
atom_expr [45388,45410]
===
match
---
decorator [13587,13597]
decorator [13587,13597]
===
match
---
number: 0 [4076,4077]
number: 0 [4076,4077]
===
match
---
name: and_ [6827,6831]
name: and_ [6827,6831]
===
match
---
operator: } [33902,33903]
operator: } [33902,33903]
===
match
---
name: raw [75976,75979]
name: raw [75988,75991]
===
match
---
expr_stmt [40784,40807]
expr_stmt [40784,40807]
===
match
---
name: dates [7273,7278]
name: dates [7273,7278]
===
match
---
operator: { [19971,19972]
operator: { [19971,19972]
===
match
---
trailer [32609,32611]
trailer [32609,32611]
===
match
---
name: merge [54208,54213]
name: merge [54208,54213]
===
match
---
import_from [2701,2767]
import_from [2701,2767]
===
match
---
name: self [15884,15888]
name: self [15884,15888]
===
match
---
fstring_end: " [65856,65857]
fstring_end: " [65868,65869]
===
match
---
name: TaskInstanceKey [24758,24773]
name: TaskInstanceKey [24758,24773]
===
match
---
name: utcnow [46228,46234]
name: utcnow [46228,46234]
===
match
---
name: execution_date [36408,36422]
name: execution_date [36408,36422]
===
match
---
name: state [29955,29960]
name: state [29955,29960]
===
match
---
name: self [14210,14214]
name: self [14210,14214]
===
match
---
name: TaskReschedule [3219,3233]
name: TaskReschedule [3219,3233]
===
match
---
operator: -> [54567,54569]
operator: -> [54567,54569]
===
match
---
argument [52903,52918]
argument [52903,52918]
===
match
---
name: _run_execute_callback [47930,47951]
name: _run_execute_callback [47930,47951]
===
match
---
trailer [51184,51189]
trailer [51184,51189]
===
match
---
name: hr_line_break [41533,41546]
name: hr_line_break [41533,41546]
===
match
---
parameters [9155,9161]
parameters [9155,9161]
===
match
---
operator: , [77091,77092]
operator: , [77103,77104]
===
match
---
simple_stmt [12468,12631]
simple_stmt [12468,12631]
===
match
---
trailer [34682,34946]
trailer [34682,34946]
===
match
---
operator: = [21197,21198]
operator: = [21197,21198]
===
match
---
import_from [937,977]
import_from [937,977]
===
match
---
trailer [42066,42071]
trailer [42066,42071]
===
match
---
sync_comp_for [7123,7169]
sync_comp_for [7123,7169]
===
match
---
name: utcnow [49254,49260]
name: utcnow [49254,49260]
===
match
---
param [30643,30648]
param [30643,30648]
===
match
---
trailer [57397,57402]
trailer [57409,57414]
===
match
---
name: task_id [33910,33917]
name: task_id [33910,33917]
===
match
---
name: pop [3704,3707]
name: pop [3704,3707]
===
match
---
simple_stmt [9008,9063]
simple_stmt [9008,9063]
===
match
---
expr_stmt [13056,13074]
expr_stmt [13056,13074]
===
match
---
atom_expr [44930,44943]
atom_expr [44930,44943]
===
match
---
and_test [15559,15617]
and_test [15559,15617]
===
match
---
atom_expr [41272,41291]
atom_expr [41272,41291]
===
match
---
param [72634,72639]
param [72646,72651]
===
match
---
atom_expr [22501,22512]
atom_expr [22501,22512]
===
match
---
name: self [44917,44921]
name: self [44917,44921]
===
match
---
atom_expr [75883,75896]
atom_expr [75895,75908]
===
match
---
name: ignore_task_deps [51793,51809]
name: ignore_task_deps [51793,51809]
===
match
---
operator: , [50642,50643]
operator: , [50642,50643]
===
match
---
name: get_num_running_task_instances [75525,75555]
name: get_num_running_task_instances [75537,75567]
===
match
---
trailer [80660,80675]
trailer [80672,80687]
===
match
---
except_clause [62581,62612]
except_clause [62593,62624]
===
match
---
operator: = [56332,56333]
operator: = [56344,56345]
===
match
---
name: timer [47081,47086]
name: timer [47081,47086]
===
match
---
tfpdef [60756,60772]
tfpdef [60768,60784]
===
match
---
atom_expr [10653,10672]
atom_expr [10653,10672]
===
match
---
simple_stmt [67688,67728]
simple_stmt [67700,67740]
===
match
---
funcdef [24970,25661]
funcdef [24970,25661]
===
match
---
trailer [46933,46965]
trailer [46933,46965]
===
match
---
simple_stmt [66364,66402]
simple_stmt [66376,66414]
===
match
---
name: queued_dttm [23319,23330]
name: queued_dttm [23319,23330]
===
match
---
name: session [40040,40047]
name: session [40040,40047]
===
match
---
name: func [26616,26620]
name: func [26616,26620]
===
match
---
name: start_date [49232,49242]
name: start_date [49232,49242]
===
match
---
atom_expr [4785,4799]
atom_expr [4785,4799]
===
match
---
atom_expr [41238,41255]
atom_expr [41238,41255]
===
match
---
name: State [51374,51379]
name: State [51374,51379]
===
match
---
argument [40456,40487]
argument [40456,40487]
===
match
---
name: State [4803,4808]
name: State [4803,4808]
===
match
---
name: self [45739,45743]
name: self [45739,45743]
===
match
---
name: hostname [23008,23016]
name: hostname [23008,23016]
===
match
---
trailer [54862,54866]
trailer [54874,54878]
===
match
---
trailer [15489,15493]
trailer [15489,15493]
===
match
---
name: Proxy [63348,63353]
name: Proxy [63360,63365]
===
match
---
atom_expr [62717,62725]
atom_expr [62729,62737]
===
match
---
atom_expr [19300,19340]
atom_expr [19300,19340]
===
match
---
atom_expr [57657,57672]
atom_expr [57669,57684]
===
match
---
trailer [32993,33002]
trailer [32993,33002]
===
match
---
operator: , [7899,7900]
operator: , [7899,7900]
===
match
---
name: vals_kv [75263,75270]
name: vals_kv [75275,75282]
===
match
---
simple_stmt [61737,61795]
simple_stmt [61749,61807]
===
match
---
trailer [61830,61884]
trailer [61842,61896]
===
match
---
name: context [47857,47864]
name: context [47857,47864]
===
match
---
atom_expr [64055,64077]
atom_expr [64067,64089]
===
match
---
atom_expr [25525,25538]
atom_expr [25525,25538]
===
match
---
operator: == [80618,80620]
operator: == [80630,80632]
===
match
---
atom_expr [15744,15761]
atom_expr [15744,15761]
===
match
---
trailer [9095,9103]
trailer [9095,9103]
===
match
---
arglist [28901,28930]
arglist [28901,28930]
===
match
---
trailer [40689,40710]
trailer [40689,40710]
===
match
---
string: """For API-compatibly with TaskInstance.          Returns self         """ [9676,9750]
string: """For API-compatibly with TaskInstance.          Returns self         """ [9676,9750]
===
match
---
atom_expr [28027,28065]
atom_expr [28027,28065]
===
match
---
simple_stmt [13631,13888]
simple_stmt [13631,13888]
===
match
---
name: self [54214,54218]
name: self [54214,54218]
===
match
---
name: info [41528,41532]
name: info [41528,41532]
===
match
---
operator: = [69289,69290]
operator: = [69301,69302]
===
match
---
atom_expr [6311,6321]
atom_expr [6311,6321]
===
match
---
name: task [24116,24120]
name: task [24116,24120]
===
match
---
exprlist [7127,7147]
exprlist [7127,7147]
===
match
---
arglist [4647,4661]
arglist [4647,4661]
===
match
---
name: task [69972,69976]
name: task [69984,69988]
===
match
---
trailer [47378,47385]
trailer [47378,47385]
===
match
---
name: execution_date [80661,80675]
name: execution_date [80673,80687]
===
match
---
simple_stmt [75996,76024]
simple_stmt [76008,76036]
===
match
---
name: self [45388,45392]
name: self [45388,45392]
===
match
---
except_clause [45523,45551]
except_clause [45523,45551]
===
match
---
operator: = [57848,57849]
operator: = [57860,57861]
===
match
---
atom_expr [39930,39940]
atom_expr [39930,39940]
===
match
---
trailer [77502,77507]
trailer [77514,77519]
===
match
---
name: start_date [31230,31240]
name: start_date [31230,31240]
===
match
---
name: error [56808,56813]
name: error [56820,56825]
===
match
---
name: state [13069,13074]
name: state [13069,13074]
===
match
---
name: self [60407,60411]
name: self [60419,60423]
===
match
---
operator: = [47493,47494]
operator: = [47493,47494]
===
match
---
argument [40619,40650]
argument [40619,40650]
===
match
---
name: session [40744,40751]
name: session [40744,40751]
===
match
---
name: cmd [19381,19384]
name: cmd [19381,19384]
===
match
---
name: timeout [49750,49757]
name: timeout [49750,49757]
===
match
---
string: "task_instance" [10380,10395]
string: "task_instance" [10380,10395]
===
match
---
operator: == [77019,77021]
operator: == [77031,77033]
===
match
---
trailer [25604,25615]
trailer [25604,25615]
===
match
---
simple_stmt [75375,75422]
simple_stmt [75387,75434]
===
match
---
name: update [66176,66182]
name: update [66188,66194]
===
match
---
name: utils [2614,2619]
name: utils [2614,2619]
===
match
---
name: self [79440,79444]
name: self [79452,79456]
===
match
---
name: ignore_depends_on_past [40528,40550]
name: ignore_depends_on_past [40528,40550]
===
match
---
name: self [57314,57318]
name: self [57326,57330]
===
match
---
trailer [33895,33902]
trailer [33895,33902]
===
match
---
trailer [16884,16889]
trailer [16884,16889]
===
match
---
simple_stmt [78845,78889]
simple_stmt [78857,78901]
===
match
---
trailer [8361,8529]
trailer [8361,8529]
===
match
---
name: DagRun [36246,36252]
name: DagRun [36246,36252]
===
match
---
try_stmt [65627,65866]
try_stmt [65639,65878]
===
match
---
name: get_hostname [2688,2700]
name: get_hostname [2688,2700]
===
match
---
atom_expr [57061,57101]
atom_expr [57073,57113]
===
match
---
decorated [9130,9385]
decorated [9130,9385]
===
match
---
name: Column [10909,10915]
name: Column [10909,10915]
===
match
---
name: Column [1283,1289]
name: Column [1283,1289]
===
match
---
simple_stmt [31495,31751]
simple_stmt [31495,31751]
===
match
---
dotted_name [1948,1966]
dotted_name [1948,1966]
===
match
---
name: TaskInstance [81099,81111]
name: TaskInstance [81111,81123]
===
match
---
expr_stmt [23105,23124]
expr_stmt [23105,23124]
===
match
---
name: self [75778,75782]
name: self [75790,75794]
===
match
---
dotted_name [42880,42900]
dotted_name [42880,42900]
===
match
---
name: execution_date [33925,33939]
name: execution_date [33925,33939]
===
match
---
name: ignore_ti_state [19352,19367]
name: ignore_ti_state [19352,19367]
===
match
---
name: self [80679,80683]
name: self [80691,80695]
===
match
---
name: refresh_from_db [44867,44882]
name: refresh_from_db [44867,44882]
===
match
---
name: timezone [35968,35976]
name: timezone [35968,35976]
===
match
---
name: delay [35535,35540]
name: delay [35535,35540]
===
match
---
atom [11514,11818]
atom [11514,11818]
===
match
---
suite [61383,61485]
suite [61395,61497]
===
match
---
import_from [2080,2124]
import_from [2080,2124]
===
match
---
name: dep_context [32584,32595]
name: dep_context [32584,32595]
===
match
---
name: pool [51979,51983]
name: pool [51979,51983]
===
match
---
and_test [30526,30579]
and_test [30526,30579]
===
match
---
number: 1 [14931,14932]
number: 1 [14931,14932]
===
match
---
number: 20 [10728,10730]
number: 20 [10728,10730]
===
match
---
trailer [54684,54694]
trailer [54684,54694]
===
match
---
funcdef [49067,49451]
funcdef [49067,49451]
===
match
---
atom_expr [22363,22382]
atom_expr [22363,22382]
===
match
---
atom [19446,19457]
atom [19446,19457]
===
match
---
suite [54655,54695]
suite [54655,54695]
===
match
---
name: state [31062,31067]
name: state [31062,31067]
===
match
---
atom_expr [20993,21005]
atom_expr [20993,21005]
===
match
---
name: task_id [18866,18873]
name: task_id [18866,18873]
===
match
---
trailer [22120,22126]
trailer [22120,22126]
===
match
---
name: html_content_err [69501,69517]
name: html_content_err [69513,69529]
===
match
---
atom_expr [48944,49005]
atom_expr [48944,49005]
===
match
---
name: TaskInstanceKey [8771,8786]
name: TaskInstanceKey [8771,8786]
===
match
---
tfpdef [36636,36664]
tfpdef [36636,36664]
===
match
---
atom_expr [33716,33733]
atom_expr [33716,33733]
===
match
---
name: add [8241,8244]
name: add [8241,8244]
===
match
---
expr_stmt [18783,18815]
expr_stmt [18783,18815]
===
match
---
trailer [44059,44068]
trailer [44059,44068]
===
match
---
trailer [12885,12900]
trailer [12885,12900]
===
match
---
name: state [25468,25473]
name: state [25468,25473]
===
match
---
name: dag_id [72472,72478]
name: dag_id [72484,72490]
===
match
---
trailer [8610,8616]
trailer [8610,8616]
===
match
---
simple_stmt [19715,19726]
simple_stmt [19715,19726]
===
match
---
name: and_ [76977,76981]
name: and_ [76989,76993]
===
match
---
atom_expr [19875,19908]
atom_expr [19875,19908]
===
match
---
operator: = [5210,5211]
operator: = [5210,5211]
===
match
---
trailer [19604,19611]
trailer [19604,19611]
===
match
---
trailer [7161,7167]
trailer [7161,7167]
===
match
---
atom_expr [47113,47130]
atom_expr [47113,47130]
===
match
---
name: Optional [31302,31310]
name: Optional [31302,31310]
===
match
---
fstring_string: ?task_id= [20263,20272]
fstring_string: ?task_id= [20263,20272]
===
match
---
atom_expr [16947,16956]
atom_expr [16947,16956]
===
match
---
expr_stmt [11824,12013]
expr_stmt [11824,12013]
===
match
---
param [66482,66486]
param [66494,66498]
===
match
---
param [60469,60474]
param [60481,60486]
===
match
---
name: task_id [75820,75827]
name: task_id [75832,75839]
===
match
---
name: try_number [7127,7137]
name: try_number [7127,7137]
===
match
---
trailer [20929,20936]
trailer [20929,20936]
===
match
---
simple_stmt [31025,31086]
simple_stmt [31025,31086]
===
match
---
trailer [29418,29434]
trailer [29418,29434]
===
match
---
subscriptlist [4313,4327]
subscriptlist [4313,4327]
===
match
---
name: path [15631,15635]
name: path [15631,15635]
===
match
---
name: tis [77153,77156]
name: tis [77165,77168]
===
match
---
trailer [51525,51527]
trailer [51525,51527]
===
match
---
name: result [49824,49830]
name: result [49824,49830]
===
match
---
trailer [50522,50526]
trailer [50522,50526]
===
match
---
name: _try_number [79523,79534]
name: _try_number [79535,79546]
===
match
---
string: 'end_date' [42830,42840]
string: 'end_date' [42830,42840]
===
match
---
operator: , [36587,36588]
operator: , [36587,36588]
===
match
---
simple_stmt [23404,23422]
simple_stmt [23404,23422]
===
match
---
name: pickle_id [16723,16732]
name: pickle_id [16723,16732]
===
match
---
name: self [40034,40038]
name: self [40034,40038]
===
match
---
name: get_task_instance [28883,28900]
name: get_task_instance [28883,28900]
===
match
---
simple_stmt [2768,2811]
simple_stmt [2768,2811]
===
match
---
operator: = [76667,76668]
operator: = [76679,76680]
===
match
---
atom_expr [46219,46236]
atom_expr [46219,46236]
===
match
---
import_as_names [1385,1412]
import_as_names [1385,1412]
===
match
---
arglist [69220,69294]
arglist [69232,69306]
===
match
---
name: execution_date [42180,42194]
name: execution_date [42180,42194]
===
match
---
name: self [65332,65336]
name: self [65344,65348]
===
match
---
operator: , [22268,22269]
operator: , [22268,22269]
===
match
---
operator: , [60814,60815]
operator: , [60826,60827]
===
match
---
comparison [24590,24632]
comparison [24590,24632]
===
match
---
name: self [12032,12036]
name: self [12032,12036]
===
match
---
atom_expr [5532,5553]
atom_expr [5532,5553]
===
match
---
name: task_id [24897,24904]
name: task_id [24897,24904]
===
match
---
name: jinja_env [70243,70252]
name: jinja_env [70255,70264]
===
match
---
expr_stmt [69619,69662]
expr_stmt [69631,69674]
===
match
---
atom_expr [15884,15896]
atom_expr [15884,15896]
===
match
---
sync_comp_for [77238,77250]
sync_comp_for [77250,77262]
===
match
---
name: self [41117,41121]
name: self [41117,41121]
===
match
---
simple_stmt [6220,6238]
simple_stmt [6220,6238]
===
match
---
operator: = [58827,58828]
operator: = [58839,58840]
===
match
---
name: session [54200,54207]
name: session [54200,54207]
===
match
---
trailer [8240,8244]
trailer [8240,8244]
===
match
---
argument [10524,10540]
argument [10524,10540]
===
match
---
operator: = [61446,61447]
operator: = [61458,61459]
===
match
---
operator: = [15146,15147]
operator: = [15146,15147]
===
match
---
argument [28915,28930]
argument [28915,28930]
===
match
---
simple_stmt [2910,2948]
simple_stmt [2910,2948]
===
match
---
atom_expr [9335,9354]
atom_expr [9335,9354]
===
match
---
parameters [79801,79807]
parameters [79813,79819]
===
match
---
name: TaskInstance [80548,80560]
name: TaskInstance [80560,80572]
===
match
---
name: Union [3992,3997]
name: Union [3992,3997]
===
match
---
operator: , [52918,52919]
operator: , [52918,52919]
===
match
---
atom_expr [80500,80710]
atom_expr [80512,80722]
===
match
---
trailer [5443,5450]
trailer [5443,5450]
===
match
---
trailer [56588,56598]
trailer [56600,56610]
===
match
---
operator: , [56628,56629]
operator: , [56640,56641]
===
match
---
trailer [55154,55163]
trailer [55166,55175]
===
match
---
operator: = [32582,32583]
operator: = [32582,32583]
===
match
---
expr_stmt [21525,21550]
expr_stmt [21525,21550]
===
match
---
simple_stmt [53574,53581]
simple_stmt [53574,53581]
===
match
---
atom_expr [75166,75211]
atom_expr [75178,75223]
===
match
---
suite [66056,66197]
suite [66068,66209]
===
match
---
name: models [1846,1852]
name: models [1846,1852]
===
match
---
name: exception [70618,70627]
name: exception [70630,70639]
===
match
---
trailer [41932,41934]
trailer [41932,41934]
===
match
---
name: error [55109,55114]
name: error [55121,55126]
===
match
---
operator: == [20937,20939]
operator: == [20937,20939]
===
match
---
name: task_id [59847,59854]
name: task_id [59859,59866]
===
match
---
name: id [7609,7611]
name: id [7609,7611]
===
match
---
arglist [31522,31740]
arglist [31522,31740]
===
match
---
operator: { [46125,46126]
operator: { [46125,46126]
===
match
---
atom_expr [46345,46355]
atom_expr [46345,46355]
===
match
---
name: __name__ [3321,3329]
name: __name__ [3321,3329]
===
match
---
name: session [28789,28796]
name: session [28789,28796]
===
match
---
string: "rendering of template_fields." [65223,65254]
string: "rendering of template_fields." [65235,65266]
===
match
---
argument [69832,69862]
argument [69844,69874]
===
match
---
simple_stmt [57686,57752]
simple_stmt [57698,57764]
===
match
---
name: task [53212,53216]
name: task [53212,53216]
===
match
---
suite [33277,33833]
suite [33277,33833]
===
match
---
import_from [2948,2989]
import_from [2948,2989]
===
match
---
operator: , [3870,3871]
operator: , [3870,3871]
===
match
---
trailer [51593,51611]
trailer [51593,51611]
===
match
---
name: provide_session [53363,53378]
name: provide_session [53363,53378]
===
match
---
trailer [66775,66783]
trailer [66787,66795]
===
match
---
name: max_tries [69899,69908]
name: max_tries [69911,69920]
===
match
---
name: qry [22180,22183]
name: qry [22180,22183]
===
match
---
operator: = [36665,36666]
operator: = [36665,36666]
===
match
---
name: self [35753,35757]
name: self [35753,35757]
===
match
---
atom_expr [30968,31016]
atom_expr [30968,31016]
===
match
---
trailer [66420,66443]
trailer [66432,66455]
===
match
---
sync_comp_for [77970,77983]
sync_comp_for [77982,77995]
===
match
---
operator: = [54488,54489]
operator: = [54488,54489]
===
match
---
suite [26034,26991]
suite [26034,26991]
===
match
---
name: session [43131,43138]
name: session [43131,43138]
===
match
---
trailer [47080,47086]
trailer [47080,47086]
===
match
---
trailer [80575,80583]
trailer [80587,80595]
===
match
---
atom_expr [10714,10732]
atom_expr [10714,10732]
===
match
---
name: job_id [44040,44046]
name: job_id [44040,44046]
===
match
---
name: airflow [80965,80972]
name: airflow [80977,80984]
===
match
---
name: execution_date [72530,72544]
name: execution_date [72542,72556]
===
match
---
name: params [59926,59932]
name: params [59938,59944]
===
match
---
operator: + [14929,14930]
operator: + [14929,14930]
===
match
---
operator: = [49243,49244]
operator: = [49243,49244]
===
match
---
suite [13043,13075]
suite [13043,13075]
===
match
---
operator: } [46138,46139]
operator: } [46138,46139]
===
match
---
name: self [46141,46145]
name: self [46141,46145]
===
match
---
name: yesterday_ds_nodash [64258,64277]
name: yesterday_ds_nodash [64270,64289]
===
match
---
name: self [50996,51000]
name: self [50996,51000]
===
match
---
atom_expr [47075,47142]
atom_expr [47075,47142]
===
match
---
simple_stmt [14905,14933]
simple_stmt [14905,14933]
===
match
---
name: test_mode [52766,52775]
name: test_mode [52766,52775]
===
match
---
trailer [75488,75494]
trailer [75500,75506]
===
match
---
trailer [48986,48996]
trailer [48986,48996]
===
match
---
simple_stmt [4096,4113]
simple_stmt [4096,4113]
===
match
---
operator: } [47670,47671]
operator: } [47670,47671]
===
match
---
simple_stmt [22989,23017]
simple_stmt [22989,23017]
===
match
---
name: self [35939,35943]
name: self [35939,35943]
===
match
---
operator: = [65345,65346]
operator: = [65357,65358]
===
match
---
suite [65614,65866]
suite [65626,65878]
===
match
---
trailer [12472,12476]
trailer [12472,12476]
===
match
---
arglist [4399,4415]
arglist [4399,4415]
===
match
---
string: """         Returns the DagRun for this TaskInstance          :param session: SQLAlchemy ORM Session         :return: DagRun         """ [36067,36203]
string: """         Returns the DagRun for this TaskInstance          :param session: SQLAlchemy ORM Session         :return: DagRun         """ [36067,36203]
===
match
---
operator: , [59433,59434]
operator: , [59445,59446]
===
match
---
string: ':' [59675,59678]
string: ':' [59687,59690]
===
match
---
simple_stmt [13374,13397]
simple_stmt [13374,13397]
===
match
---
expr_stmt [59451,59511]
expr_stmt [59463,59523]
===
match
---
name: try_number [57234,57244]
name: try_number [57246,57256]
===
match
---
param [16615,16646]
param [16615,16646]
===
match
---
name: passed [33788,33794]
name: passed [33788,33794]
===
match
---
expr_stmt [25567,25632]
expr_stmt [25567,25632]
===
match
---
name: key [77958,77961]
name: key [77970,77973]
===
match
---
trailer [53106,53119]
trailer [53106,53119]
===
match
---
if_stmt [53548,53581]
if_stmt [53548,53581]
===
match
---
atom_expr [24613,24632]
atom_expr [24613,24632]
===
match
---
name: ignore_ti_state [51833,51848]
name: ignore_ti_state [51833,51848]
===
match
---
trailer [67756,67767]
trailer [67768,67779]
===
match
---
arglist [42283,42299]
arglist [42283,42299]
===
match
---
name: item [62283,62287]
name: item [62295,62299]
===
match
---
not_test [40681,40766]
not_test [40681,40766]
===
match
---
atom_expr [7408,7447]
atom_expr [7408,7447]
===
match
---
name: key [70079,70082]
name: key [70091,70094]
===
match
---
expr_stmt [46672,46693]
expr_stmt [46672,46693]
===
match
---
name: timezone [2502,2510]
name: timezone [2502,2510]
===
match
---
not_test [7948,7969]
not_test [7948,7969]
===
match
---
name: task_id [66836,66843]
name: task_id [66848,66855]
===
match
---
name: test_mode [38412,38421]
name: test_mode [38412,38421]
===
match
---
atom_expr [6154,6164]
atom_expr [6154,6164]
===
match
---
classdef [8765,9771]
classdef [8765,9771]
===
match
---
name: configuration [1553,1566]
name: configuration [1553,1566]
===
match
---
name: session [44001,44008]
name: session [44001,44008]
===
match
---
fstring_string: ti.finish. [46101,46111]
fstring_string: ti.finish. [46101,46111]
===
match
---
expr_stmt [39985,40064]
expr_stmt [39985,40064]
===
match
---
trailer [51000,51021]
trailer [51000,51021]
===
match
---
simple_stmt [24251,24415]
simple_stmt [24251,24415]
===
match
---
name: self [53632,53636]
name: self [53632,53636]
===
match
---
trailer [50176,50186]
trailer [50176,50186]
===
match
---
name: stacklevel [29895,29905]
name: stacklevel [29895,29905]
===
match
---
name: run_as_user [24035,24046]
name: run_as_user [24035,24046]
===
match
---
fstring [15638,15667]
fstring [15638,15667]
===
match
---
atom_expr [50404,50428]
atom_expr [50404,50428]
===
match
---
name: task_id [19977,19984]
name: task_id [19977,19984]
===
match
---
fstring [20300,20324]
fstring [20300,20324]
===
match
---
operator: = [3301,3302]
operator: = [3301,3302]
===
match
---
return_stmt [62237,62288]
return_stmt [62249,62300]
===
match
---
name: bool [16593,16597]
name: bool [16593,16597]
===
match
---
name: execution_date [76928,76942]
name: execution_date [76940,76954]
===
match
---
name: ID_LEN [1881,1887]
name: ID_LEN [1881,1887]
===
match
---
name: DateTime [30146,30154]
name: DateTime [30146,30154]
===
match
---
name: airflow [3061,3068]
name: airflow [3061,3068]
===
match
---
fstring_expr [20310,20323]
fstring_expr [20310,20323]
===
match
---
name: running [14086,14093]
name: running [14086,14093]
===
match
---
name: self [14796,14800]
name: self [14796,14800]
===
match
---
name: bool [16547,16551]
name: bool [16547,16551]
===
match
---
name: base_url [20153,20161]
name: base_url [20153,20161]
===
match
---
decorator [31821,31838]
decorator [31821,31838]
===
match
---
name: params [66135,66141]
name: params [66147,66153]
===
match
---
atom_expr [53778,53797]
atom_expr [53778,53797]
===
match
---
param [9156,9160]
param [9156,9160]
===
match
---
expr_stmt [3670,3709]
expr_stmt [3670,3709]
===
match
---
atom_expr [33943,33953]
atom_expr [33943,33953]
===
match
---
atom_expr [12135,12146]
atom_expr [12135,12146]
===
match
---
atom_expr [23243,23261]
atom_expr [23243,23261]
===
match
---
simple_stmt [50446,50480]
simple_stmt [50446,50480]
===
match
---
atom_expr [33677,33694]
atom_expr [33677,33694]
===
match
---
param [15245,15259]
param [15245,15259]
===
match
---
operator: = [34677,34678]
operator: = [34677,34678]
===
match
---
string: """Get Airflow Variable after deserializing JSON value""" [61737,61794]
string: """Get Airflow Variable after deserializing JSON value""" [61749,61806]
===
match
---
name: pendulum [30720,30728]
name: pendulum [30720,30728]
===
match
---
name: str [19078,19081]
name: str [19078,19081]
===
match
---
trailer [25945,25961]
trailer [25945,25961]
===
match
---
import_from [1413,1455]
import_from [1413,1455]
===
match
---
name: TaskInstanceKey [9292,9307]
name: TaskInstanceKey [9292,9307]
===
match
---
trailer [44438,44453]
trailer [44438,44453]
===
match
---
decorator [9618,9628]
decorator [9618,9628]
===
match
---
arglist [66818,66843]
arglist [66830,66855]
===
match
---
return_stmt [28864,28931]
return_stmt [28864,28931]
===
match
---
atom_expr [20106,20144]
atom_expr [20106,20144]
===
match
---
trailer [78772,78785]
trailer [78784,78797]
===
match
---
operator: = [25354,25355]
operator: = [25354,25355]
===
match
---
simple_stmt [15737,15762]
simple_stmt [15737,15762]
===
match
---
simple_stmt [8851,8863]
simple_stmt [8851,8863]
===
match
---
expr_stmt [22714,22735]
expr_stmt [22714,22735]
===
match
---
atom_expr [78728,78754]
atom_expr [78740,78766]
===
match
---
operator: , [1338,1339]
operator: , [1338,1339]
===
match
---
suite [71062,71141]
suite [71074,71153]
===
match
---
name: ti [23290,23292]
name: ti [23290,23292]
===
match
---
suite [3747,3943]
suite [3747,3943]
===
match
---
trailer [8434,8438]
trailer [8434,8438]
===
match
---
atom_expr [54858,54885]
atom_expr [54870,54897]
===
match
---
testlist_comp [18994,19020]
testlist_comp [18994,19020]
===
match
---
name: XCom [24508,24512]
name: XCom [24508,24512]
===
match
---
name: task_id [75191,75198]
name: task_id [75203,75210]
===
match
---
atom_expr [11836,12013]
atom_expr [11836,12013]
===
match
---
name: self [54006,54010]
name: self [54006,54010]
===
match
---
name: ImportError [3179,3190]
name: ImportError [3179,3190]
===
match
---
name: self [20273,20277]
name: self [20273,20277]
===
match
---
string: """Render templates in the operator fields.""" [66281,66327]
string: """Render templates in the operator fields.""" [66293,66339]
===
match
---
trailer [69993,69995]
trailer [70005,70007]
===
match
---
name: append [3602,3608]
name: append [3602,3608]
===
match
---
for_stmt [5299,6323]
for_stmt [5299,6323]
===
match
---
name: query [75382,75387]
name: query [75394,75399]
===
match
---
argument [38463,38478]
argument [38463,38478]
===
match
---
if_stmt [8678,8763]
if_stmt [8678,8763]
===
match
---
name: execution_date [26795,26809]
name: execution_date [26795,26809]
===
match
---
param [60384,60388]
param [60396,60400]
===
match
---
atom_expr [26928,26936]
atom_expr [26928,26936]
===
match
---
name: airflow [2184,2191]
name: airflow [2184,2191]
===
match
---
simple_stmt [1135,1147]
simple_stmt [1135,1147]
===
match
---
atom_expr [61476,61484]
atom_expr [61488,61496]
===
match
---
operator: = [16267,16268]
operator: = [16267,16268]
===
match
---
trailer [44251,44258]
trailer [44251,44258]
===
match
---
string: "Rescheduling due to concurrency limits reached " [40910,40959]
string: "Rescheduling due to concurrency limits reached " [40910,40959]
===
match
---
or_test [25525,25554]
or_test [25525,25554]
===
match
---
string: "Task received SIGTERM signal" [46879,46909]
string: "Task received SIGTERM signal" [46879,46909]
===
match
---
name: error_fd [53050,53058]
name: error_fd [53050,53058]
===
match
---
funcdef [79069,79122]
funcdef [79081,79134]
===
match
---
name: _try_number [14917,14928]
name: _try_number [14917,14928]
===
match
---
trailer [19998,20005]
trailer [19998,20005]
===
match
---
trailer [11205,11214]
trailer [11205,11214]
===
match
---
name: dag_id [11953,11959]
name: dag_id [11953,11959]
===
match
---
name: deserialize_json [61862,61878]
name: deserialize_json [61874,61890]
===
match
---
operator: = [48176,48177]
operator: = [48176,48177]
===
match
---
operator: , [15235,15236]
operator: , [15235,15236]
===
match
---
operator: = [10788,10789]
operator: = [10788,10789]
===
match
---
name: context [3609,3616]
name: context [3609,3616]
===
match
---
lambdef [63371,63432]
lambdef [63383,63444]
===
match
---
trailer [48792,48806]
trailer [48792,48806]
===
match
---
tfpdef [50617,50655]
tfpdef [50617,50655]
===
match
---
name: execution_date [7243,7257]
name: execution_date [7243,7257]
===
match
---
argument [11281,11293]
argument [11281,11293]
===
match
---
and_test [25900,25963]
and_test [25900,25963]
===
match
---
name: ignore_ti_state [38610,38625]
name: ignore_ti_state [38610,38625]
===
match
---
operator: , [15176,15177]
operator: , [15176,15177]
===
match
---
atom_expr [5578,5599]
atom_expr [5578,5599]
===
match
---
name: _queue [79000,79006]
name: _queue [79012,79018]
===
match
---
simple_stmt [52632,52675]
simple_stmt [52632,52675]
===
match
---
simple_stmt [19772,19803]
simple_stmt [19772,19803]
===
match
---
name: sanitize_for_serialization [67371,67397]
name: sanitize_for_serialization [67383,67409]
===
match
---
trailer [67370,67397]
trailer [67382,67409]
===
match
---
trailer [34555,34609]
trailer [34555,34609]
===
match
---
trailer [22510,22512]
trailer [22510,22512]
===
match
---
atom_expr [44609,44625]
atom_expr [44609,44625]
===
match
---
operator: , [63920,63921]
operator: , [63932,63933]
===
match
---
name: task_ids [7084,7092]
name: task_ids [7084,7092]
===
match
---
operator: , [1066,1067]
operator: , [1066,1067]
===
match
---
name: run_as_user [78791,78802]
name: run_as_user [78803,78814]
===
match
---
name: self [24906,24910]
name: self [24906,24910]
===
match
---
trailer [24675,24677]
trailer [24675,24677]
===
match
---
name: executor_config [24098,24113]
name: executor_config [24098,24113]
===
match
---
operator: , [10779,10780]
operator: , [10779,10780]
===
match
---
comparison [50860,50886]
comparison [50860,50886]
===
match
---
trailer [47086,47142]
trailer [47086,47142]
===
match
---
atom_expr [6849,6858]
atom_expr [6849,6858]
===
match
---
trailer [22367,22382]
trailer [22367,22382]
===
match
---
name: execution_date [58270,58284]
name: execution_date [58282,58296]
===
match
---
atom_expr [33404,33418]
atom_expr [33404,33418]
===
match
---
name: self [71302,71306]
name: self [71314,71318]
===
match
---
operator: = [39895,39896]
operator: = [39895,39896]
===
match
---
trailer [12484,12630]
trailer [12484,12630]
===
match
---
atom_expr [12108,12126]
atom_expr [12108,12126]
===
match
---
simple_stmt [71196,71253]
simple_stmt [71208,71265]
===
match
---
name: default_html_content_err [69542,69566]
name: default_html_content_err [69554,69578]
===
match
---
name: self [46271,46275]
name: self [46271,46275]
===
match
---
suite [23391,23422]
suite [23391,23422]
===
match
---
suite [28847,28932]
suite [28847,28932]
===
match
---
operator: , [66884,66885]
operator: , [66896,66897]
===
match
---
name: self [50611,50615]
name: self [50611,50615]
===
match
---
name: self [19994,19998]
name: self [19994,19998]
===
match
---
name: str [79162,79165]
name: str [79174,79177]
===
match
---
atom_expr [23360,23368]
atom_expr [23360,23368]
===
match
---
trailer [59601,59618]
trailer [59613,59630]
===
match
---
parameters [61250,61256]
parameters [61262,61268]
===
match
---
trailer [57580,57593]
trailer [57592,57605]
===
match
---
simple_stmt [901,937]
simple_stmt [901,937]
===
match
---
name: test_mode [54429,54438]
name: test_mode [54429,54438]
===
match
---
simple_stmt [56316,56354]
simple_stmt [56328,56366]
===
match
---
operator: = [49858,49859]
operator: = [49858,49859]
===
match
---
name: airflow [57691,57698]
name: airflow [57703,57710]
===
match
---
atom_expr [44917,44927]
atom_expr [44917,44927]
===
match
---
name: Union [50633,50638]
name: Union [50633,50638]
===
match
---
operator: = [74547,74548]
operator: = [74559,74560]
===
match
---
expr_stmt [15503,15547]
expr_stmt [15503,15547]
===
match
---
if_stmt [71025,71188]
if_stmt [71037,71200]
===
match
---
arglist [25287,25333]
arglist [25287,25333]
===
match
---
name: item [60557,60561]
name: item [60569,60573]
===
match
---
name: _execute_task [48793,48806]
name: _execute_task [48793,48806]
===
match
---
trailer [69266,69276]
trailer [69278,69288]
===
match
---
expr_stmt [78845,78888]
expr_stmt [78857,78900]
===
match
---
name: tis [4695,4698]
name: tis [4695,4698]
===
match
---
operator: = [41236,41237]
operator: = [41236,41237]
===
match
---
trailer [22729,22735]
trailer [22729,22735]
===
match
---
name: conf [59946,59950]
name: conf [59958,59962]
===
match
---
trailer [6915,7218]
trailer [6915,7218]
===
match
---
operator: , [74660,74661]
operator: , [74672,74673]
===
match
---
name: provide_session [42859,42874]
name: provide_session [42859,42874]
===
match
---
simple_stmt [58124,58161]
simple_stmt [58136,58173]
===
match
---
tfpdef [36797,36812]
tfpdef [36797,36812]
===
match
---
name: refresh_from_task [12235,12252]
name: refresh_from_task [12235,12252]
===
match
---
trailer [80527,80534]
trailer [80539,80546]
===
match
---
name: airflow_context_vars [47761,47781]
name: airflow_context_vars [47761,47781]
===
match
---
simple_stmt [8132,8167]
simple_stmt [8132,8167]
===
match
---
operator: = [75069,75070]
operator: = [75081,75082]
===
match
---
decorated [57268,64289]
decorated [57280,64301]
===
match
---
name: task_copy [49489,49498]
name: task_copy [49489,49498]
===
match
---
string: 'subject_template' [70328,70346]
string: 'subject_template' [70340,70358]
===
match
---
trailer [40062,40064]
trailer [40062,40064]
===
match
---
name: self [34780,34784]
name: self [34780,34784]
===
match
---
atom_expr [20112,20143]
atom_expr [20112,20143]
===
match
---
operator: , [67187,67188]
operator: , [67199,67200]
===
match
---
simple_stmt [40121,40166]
simple_stmt [40121,40166]
===
match
---
name: ApiClient [3196,3205]
name: ApiClient [3196,3205]
===
match
---
string: "--cfg-path" [19682,19694]
string: "--cfg-path" [19682,19694]
===
match
---
trailer [42020,42024]
trailer [42020,42024]
===
match
---
name: log [66074,66077]
name: log [66086,66089]
===
match
---
operator: = [15211,15212]
operator: = [15211,15212]
===
match
---
parameters [8963,8969]
parameters [8963,8969]
===
match
---
expr_stmt [76553,76567]
expr_stmt [76565,76579]
===
match
---
import_from [2125,2178]
import_from [2125,2178]
===
match
---
name: str [60735,60738]
name: str [60747,60750]
===
match
---
atom_expr [63536,63585]
atom_expr [63548,63597]
===
match
---
name: self [44833,44837]
name: self [44833,44837]
===
match
---
name: run_id [57970,57976]
name: run_id [57982,57988]
===
match
---
name: get_task [5582,5590]
name: get_task [5582,5590]
===
match
---
operator: = [78786,78787]
operator: = [78798,78799]
===
match
---
if_stmt [51202,51347]
if_stmt [51202,51347]
===
match
---
name: pool_slots [10976,10986]
name: pool_slots [10976,10986]
===
match
---
param [9416,9431]
param [9416,9431]
===
match
---
name: self [41519,41523]
name: self [41519,41523]
===
match
---
name: dag_id [22247,22253]
name: dag_id [22247,22253]
===
match
---
if_stmt [78725,78803]
if_stmt [78737,78815]
===
match
---
name: context_to_airflow_vars [2744,2767]
name: context_to_airflow_vars [2744,2767]
===
match
---
operator: = [56905,56906]
operator: = [56917,56918]
===
match
---
argument [11878,11930]
argument [11878,11930]
===
match
---
if_stmt [44302,44454]
if_stmt [44302,44454]
===
match
---
name: dag_id [9083,9089]
name: dag_id [9083,9089]
===
match
---
name: t [77148,77149]
name: t [77160,77161]
===
match
---
name: cmd [19722,19725]
name: cmd [19722,19725]
===
match
---
name: airflow [2773,2780]
name: airflow [2773,2780]
===
match
---
operator: , [66844,66845]
operator: , [66856,66857]
===
match
---
name: execution_date [12901,12915]
name: execution_date [12901,12915]
===
match
---
argument [29955,29974]
argument [29955,29974]
===
match
---
name: total_seconds [25617,25630]
name: total_seconds [25617,25630]
===
match
---
name: load_error_file [53012,53027]
name: load_error_file [53012,53027]
===
match
---
operator: , [11648,11649]
operator: , [11648,11649]
===
match
---
simple_stmt [8913,8933]
simple_stmt [8913,8933]
===
match
---
simple_stmt [23029,23057]
simple_stmt [23029,23057]
===
match
---
trailer [41246,41253]
trailer [41246,41253]
===
match
---
trailer [66873,66884]
trailer [66885,66896]
===
match
---
name: self [25370,25374]
name: self [25370,25374]
===
match
---
name: task_copy [49683,49692]
name: task_copy [49683,49692]
===
match
---
atom_expr [30556,30578]
atom_expr [30556,30578]
===
match
---
operator: = [15230,15231]
operator: = [15230,15231]
===
match
---
trailer [66083,66156]
trailer [66095,66168]
===
match
---
operator: = [11976,11977]
operator: = [11976,11977]
===
match
---
atom_expr [16775,16788]
atom_expr [16775,16788]
===
match
---
tfpdef [3384,3400]
tfpdef [3384,3400]
===
match
---
name: self [41556,41560]
name: self [41556,41560]
===
match
---
name: PickleType [11270,11280]
name: PickleType [11270,11280]
===
match
---
name: task_id [77680,77687]
name: task_id [77692,77699]
===
match
---
operator: = [15997,15998]
operator: = [15997,15998]
===
match
---
string: 'conn' [64151,64157]
string: 'conn' [64163,64169]
===
match
---
import_as_names [1865,1893]
import_as_names [1865,1893]
===
match
---
name: self [32696,32700]
name: self [32696,32700]
===
match
---
name: AirflowSkipException [1752,1772]
name: AirflowSkipException [1752,1772]
===
match
---
name: log [33522,33525]
name: log [33522,33525]
===
match
---
operator: , [52397,52398]
operator: , [52397,52398]
===
match
---
name: provide_session [24950,24965]
name: provide_session [24950,24965]
===
match
---
fstring_expr [19957,19962]
fstring_expr [19957,19962]
===
match
---
name: session [33263,33270]
name: session [33263,33270]
===
match
---
name: task_type [24166,24175]
name: task_type [24166,24175]
===
match
---
name: ti [77622,77624]
name: ti [77634,77636]
===
match
---
trailer [24427,24431]
trailer [24427,24431]
===
match
---
trailer [18992,19022]
trailer [18992,19022]
===
match
---
operator: = [10964,10965]
operator: = [10964,10965]
===
match
---
name: State [56181,56186]
name: State [56193,56198]
===
match
---
atom_expr [50624,50655]
atom_expr [50624,50655]
===
match
---
dotted_name [2130,2149]
dotted_name [2130,2149]
===
match
---
atom_expr [69635,69662]
atom_expr [69647,69674]
===
match
---
not_test [38582,38601]
not_test [38582,38601]
===
match
---
operator: , [52313,52314]
operator: , [52313,52314]
===
match
---
atom_expr [66043,66055]
atom_expr [66055,66067]
===
match
---
if_stmt [19575,19637]
if_stmt [19575,19637]
===
match
---
param [53470,53482]
param [53470,53482]
===
match
---
string: """Is task instance is eligible for retry""" [57147,57191]
string: """Is task instance is eligible for retry""" [57159,57203]
===
match
---
name: self [56363,56367]
name: self [56375,56379]
===
match
---
operator: , [60920,60921]
operator: , [60932,60933]
===
match
---
simple_stmt [28941,28953]
simple_stmt [28941,28953]
===
match
---
trailer [41439,41444]
trailer [41439,41444]
===
match
---
operator: = [12277,12278]
operator: = [12277,12278]
===
match
---
atom_expr [56181,56193]
atom_expr [56193,56205]
===
match
---
name: self [25272,25276]
name: self [25272,25276]
===
match
---
name: task_id [42691,42698]
name: task_id [42691,42698]
===
match
---
simple_stmt [38510,38531]
simple_stmt [38510,38531]
===
match
---
suite [40100,40166]
suite [40100,40166]
===
match
---
name: pickler [11281,11288]
name: pickler [11281,11288]
===
match
---
name: default_html_content_err [70509,70533]
name: default_html_content_err [70521,70545]
===
match
---
operator: , [1044,1045]
operator: , [1044,1045]
===
match
---
import_name [847,856]
import_name [847,856]
===
match
---
parameters [35752,35758]
parameters [35752,35758]
===
match
---
name: session [56709,56716]
name: session [56721,56728]
===
match
---
trailer [5450,5461]
trailer [5450,5461]
===
match
---
name: self [22590,22594]
name: self [22590,22594]
===
match
---
trailer [44486,44508]
trailer [44486,44508]
===
match
---
decorator [20013,20023]
decorator [20013,20023]
===
match
---
name: state [12070,12075]
name: state [12070,12075]
===
match
---
name: warnings [31495,31503]
name: warnings [31495,31503]
===
match
---
trailer [46383,46389]
trailer [46383,46389]
===
match
---
comparison [77599,77631]
comparison [77611,77643]
===
match
---
atom_expr [12877,12916]
atom_expr [12877,12916]
===
match
---
atom_expr [26512,26521]
atom_expr [26512,26521]
===
match
---
trailer [70164,70170]
trailer [70176,70182]
===
match
---
import_from [1103,1133]
import_from [1103,1133]
===
match
---
expr_stmt [61274,61289]
expr_stmt [61286,61301]
===
match
---
name: self [30460,30464]
name: self [30460,30464]
===
match
---
trailer [50526,50536]
trailer [50526,50536]
===
match
---
operator: , [57864,57865]
operator: , [57876,57877]
===
match
---
name: task [43946,43950]
name: task [43946,43950]
===
match
---
trailer [75708,75714]
trailer [75720,75726]
===
match
---
simple_stmt [65777,65866]
simple_stmt [65789,65878]
===
match
---
name: task [35662,35666]
name: task [35662,35666]
===
match
---
name: STATICA_HACK [80921,80933]
name: STATICA_HACK [80933,80945]
===
match
---
operator: , [11775,11776]
operator: , [11775,11776]
===
match
---
except_clause [56546,56562]
except_clause [56558,56574]
===
match
---
if_stmt [6328,7484]
if_stmt [6328,7484]
===
match
---
operator: = [16815,16816]
operator: = [16815,16816]
===
match
---
operator: , [33261,33262]
operator: , [33261,33262]
===
match
---
return_stmt [29407,29436]
return_stmt [29407,29436]
===
match
---
trailer [27395,27400]
trailer [27395,27400]
===
match
---
operator: , [33157,33158]
operator: , [33157,33158]
===
match
---
operator: @ [14172,14173]
operator: @ [14172,14173]
===
match
---
yield_expr [3635,3648]
yield_expr [3635,3648]
===
match
---
name: self [44055,44059]
name: self [44055,44059]
===
match
---
suite [34265,35691]
suite [34265,35691]
===
match
---
simple_stmt [45423,45497]
simple_stmt [45423,45497]
===
match
---
name: Stats [46088,46093]
name: Stats [46088,46093]
===
match
---
expr_stmt [12926,12962]
expr_stmt [12926,12962]
===
match
---
name: _Variable__NO_DEFAULT_SENTINEL [61674,61704]
name: _Variable__NO_DEFAULT_SENTINEL [61686,61716]
===
match
---
simple_stmt [54200,54220]
simple_stmt [54200,54220]
===
match
---
expr_stmt [59627,59683]
expr_stmt [59639,59695]
===
match
---
string: """         Call callback defined for finished state change.          NOTE: Only invoke this function from caller of self._run_raw_task or         self.run         """ [50681,50848]
string: """         Call callback defined for finished state change.          NOTE: Only invoke this function from caller of self._run_raw_task or         self.run         """ [50681,50848]
===
match
---
atom_expr [23314,23330]
atom_expr [23314,23330]
===
match
---
suite [60516,60595]
suite [60528,60607]
===
match
---
atom_expr [24468,24652]
atom_expr [24468,24652]
===
match
---
simple_stmt [41431,41511]
simple_stmt [41431,41511]
===
match
---
operator: , [47714,47715]
operator: , [47714,47715]
===
match
---
simple_stmt [47743,47783]
simple_stmt [47743,47783]
===
match
---
name: _prepare_and_execute_task_with_callbacks [44398,44438]
name: _prepare_and_execute_task_with_callbacks [44398,44438]
===
match
---
operator: = [76041,76042]
operator: = [76053,76054]
===
match
---
name: render_k8s_pod_yaml [65673,65692]
name: render_k8s_pod_yaml [65685,65704]
===
match
---
name: taskfail [1998,2006]
name: taskfail [1998,2006]
===
match
---
atom_expr [45769,45781]
atom_expr [45769,45781]
===
match
---
name: self [50275,50279]
name: self [50275,50279]
===
match
---
param [25697,25701]
param [25697,25701]
===
match
---
name: include_prior_dates [74753,74772]
name: include_prior_dates [74765,74784]
===
match
---
operator: , [62725,62726]
operator: , [62737,62738]
===
match
---
name: pool [43053,43057]
name: pool [43053,43057]
===
match
---
operator: , [62950,62951]
operator: , [62962,62963]
===
match
---
name: convert_to_utc [12886,12900]
name: convert_to_utc [12886,12900]
===
match
---
return_stmt [9071,9124]
return_stmt [9071,9124]
===
match
---
name: unixname [10864,10872]
name: unixname [10864,10872]
===
match
---
trailer [35474,35522]
trailer [35474,35522]
===
match
---
name: __getattr__ [62144,62155]
name: __getattr__ [62156,62167]
===
match
---
name: and_ [1334,1338]
name: and_ [1334,1338]
===
match
---
atom_expr [70817,70832]
atom_expr [70829,70844]
===
match
---
simple_stmt [55082,55116]
simple_stmt [55094,55128]
===
match
---
name: pool_override [43952,43965]
name: pool_override [43952,43965]
===
match
---
simple_stmt [47039,47062]
simple_stmt [47039,47062]
===
match
---
operator: = [27909,27910]
operator: = [27909,27910]
===
match
---
name: verbose_aware_logger [32643,32663]
name: verbose_aware_logger [32643,32663]
===
match
---
operator: = [3292,3293]
operator: = [3292,3293]
===
match
---
atom_expr [36403,36422]
atom_expr [36403,36422]
===
match
---
name: extend [19439,19445]
name: extend [19439,19445]
===
match
---
simple_stmt [38407,38434]
simple_stmt [38407,38434]
===
match
---
simple_stmt [65361,65406]
simple_stmt [65373,65418]
===
match
---
atom_expr [40139,40165]
atom_expr [40139,40165]
===
match
---
name: task_id [34798,34805]
name: task_id [34798,34805]
===
match
---
arglist [11735,11774]
arglist [11735,11774]
===
match
---
name: State [5337,5342]
name: State [5337,5342]
===
match
---
trailer [3608,3617]
trailer [3608,3617]
===
match
---
atom_expr [11624,11648]
atom_expr [11624,11648]
===
match
---
and_test [38582,38657]
and_test [38582,38657]
===
match
---
suite [4214,4262]
suite [4214,4262]
===
match
---
name: lock_for_update [38480,38495]
name: lock_for_update [38480,38495]
===
match
---
trailer [26639,26647]
trailer [26639,26647]
===
match
---
atom_expr [29151,29398]
atom_expr [29151,29398]
===
match
---
parameters [53405,53483]
parameters [53405,53483]
===
match
---
suite [16957,19726]
suite [16957,19726]
===
match
---
suite [50887,51119]
suite [50887,51119]
===
match
---
funcdef [9144,9385]
funcdef [9144,9385]
===
match
---
operator: = [6201,6202]
operator: = [6201,6202]
===
match
---
trailer [44138,44144]
trailer [44138,44144]
===
match
---
operator: , [26883,26884]
operator: , [26883,26884]
===
match
---
parameters [19756,19762]
parameters [19756,19762]
===
match
---
suite [9183,9385]
suite [9183,9385]
===
match
---
name: utils [2714,2719]
name: utils [2714,2719]
===
match
---
name: State [6154,6159]
name: State [6154,6159]
===
match
---
name: self [56127,56131]
name: self [56139,56143]
===
match
---
decorated [79460,79535]
decorated [79472,79547]
===
match
---
atom_expr [8728,8755]
atom_expr [8728,8755]
===
match
---
string: 'run_as_user' [78740,78753]
string: 'run_as_user' [78752,78765]
===
match
---
operator: , [80699,80700]
operator: , [80711,80712]
===
match
---
name: or_ [7002,7005]
name: or_ [7002,7005]
===
match
---
atom_expr [5498,5508]
atom_expr [5498,5508]
===
match
---
name: task [51205,51209]
name: task [51205,51209]
===
match
---
atom_expr [6092,6104]
atom_expr [6092,6104]
===
match
---
name: deps [33414,33418]
name: deps [33414,33418]
===
match
---
name: self [43888,43892]
name: self [43888,43892]
===
match
---
name: conf [70054,70058]
name: conf [70066,70070]
===
match
---
trailer [69376,69393]
trailer [69388,69405]
===
match
---
trailer [57252,57262]
trailer [57264,57274]
===
match
---
name: provide_session [36480,36495]
name: provide_session [36480,36495]
===
match
---
dotted_name [3119,3151]
dotted_name [3119,3151]
===
match
---
atom_expr [15859,15870]
atom_expr [15859,15870]
===
match
---
param [27046,27051]
param [27046,27051]
===
match
---
decorated [19731,20008]
decorated [19731,20008]
===
match
---
trailer [64533,64554]
trailer [64545,64566]
===
match
---
suite [19287,19341]
suite [19287,19341]
===
match
---
name: lock_for_update [22406,22421]
name: lock_for_update [22406,22421]
===
match
---
param [46478,46486]
param [46478,46486]
===
match
---
parameters [70019,70033]
parameters [70031,70045]
===
match
---
operator: , [60473,60474]
operator: , [60485,60486]
===
match
---
name: tomorrow_ds [63833,63844]
name: tomorrow_ds [63845,63856]
===
match
---
arith_expr [38808,38825]
arith_expr [38808,38825]
===
match
---
atom_expr [35706,35719]
atom_expr [35706,35719]
===
match
---
name: reason [33031,33037]
name: reason [33031,33037]
===
match
---
trailer [55196,55209]
trailer [55208,55221]
===
match
---
param [42946,42973]
param [42946,42973]
===
match
---
for_stmt [8581,8763]
for_stmt [8581,8763]
===
match
---
operator: = [58262,58263]
operator: = [58274,58275]
===
match
---
name: tomorrow_ds_nodash [63880,63898]
name: tomorrow_ds_nodash [63892,63910]
===
match
---
name: property [8939,8947]
name: property [8939,8947]
===
match
---
atom_expr [23893,23902]
atom_expr [23893,23902]
===
match
---
operator: + [41506,41507]
operator: + [41506,41507]
===
match
---
expr_stmt [13522,13544]
expr_stmt [13522,13544]
===
match
---
name: self [76055,76059]
name: self [76067,76071]
===
match
---
operator: | [33402,33403]
operator: | [33402,33403]
===
match
---
operator: , [43043,43044]
operator: , [43043,43044]
===
match
---
name: verbose [52155,52162]
name: verbose [52155,52162]
===
match
---
atom_expr [52553,52586]
atom_expr [52553,52586]
===
match
---
atom_expr [77184,77251]
atom_expr [77196,77263]
===
match
---
name: task_id [8867,8874]
name: task_id [8867,8874]
===
match
---
name: str [60497,60500]
name: str [60509,60512]
===
match
---
name: ti [22727,22729]
name: ti [22727,22729]
===
match
---
name: self [34229,34233]
name: self [34229,34233]
===
match
---
trailer [69567,69574]
trailer [69579,69586]
===
match
---
operator: , [4711,4712]
operator: , [4711,4712]
===
match
---
atom_expr [25445,25459]
atom_expr [25445,25459]
===
match
---
trailer [67168,67187]
trailer [67180,67199]
===
match
---
atom_expr [77486,77520]
atom_expr [77498,77532]
===
match
---
name: airflow [2706,2713]
name: airflow [2706,2713]
===
match
---
name: task_type [48987,48996]
name: task_type [48987,48996]
===
match
---
trailer [7429,7435]
trailer [7429,7435]
===
match
---
name: self [55378,55382]
name: self [55390,55394]
===
match
---
name: Session [36042,36049]
name: Session [36042,36049]
===
match
---
decorator [79460,79470]
decorator [79472,79482]
===
match
---
param [14301,14305]
param [14301,14305]
===
match
---
name: self [40121,40125]
name: self [40121,40125]
===
match
---
name: queue [23202,23207]
name: queue [23202,23207]
===
match
---
name: cfg_path [19648,19656]
name: cfg_path [19648,19656]
===
match
---
operator: = [45885,45886]
operator: = [45885,45886]
===
match
---
operator: , [42936,42937]
operator: , [42936,42937]
===
match
---
arglist [59430,59437]
arglist [59442,59449]
===
match
---
param [36904,36917]
param [36904,36917]
===
match
---
decorated [54328,56726]
decorated [54328,56738]
===
match
---
atom_expr [59773,59801]
atom_expr [59785,59813]
===
match
---
name: self [22947,22951]
name: self [22947,22951]
===
match
---
atom_expr [42128,42195]
atom_expr [42128,42195]
===
match
---
simple_stmt [44917,44944]
simple_stmt [44917,44944]
===
match
---
param [3384,3400]
param [3384,3400]
===
match
---
trailer [25616,25630]
trailer [25616,25630]
===
match
---
name: reschedule_exception [45101,45121]
name: reschedule_exception [45101,45121]
===
match
---
operator: = [72732,72733]
operator: = [72744,72745]
===
match
---
import_from [1260,1357]
import_from [1260,1357]
===
match
---
param [31905,31918]
param [31905,31918]
===
match
---
string: 'prev_start_date_success' [63460,63485]
string: 'prev_start_date_success' [63472,63497]
===
match
---
atom_expr [5405,5419]
atom_expr [5405,5419]
===
match
---
operator: , [72676,72677]
operator: , [72688,72689]
===
match
---
string: "Please use `dag_run_state`" [7839,7867]
string: "Please use `dag_run_state`" [7839,7867]
===
match
---
suite [12666,12760]
suite [12666,12760]
===
match
---
if_stmt [45736,45920]
if_stmt [45736,45920]
===
match
---
expr_stmt [12205,12221]
expr_stmt [12205,12221]
===
match
---
import_from [2768,2810]
import_from [2768,2810]
===
match
---
param [62173,62178]
param [62185,62190]
===
match
---
atom_expr [38630,38640]
atom_expr [38630,38640]
===
match
---
trailer [66073,66077]
trailer [66085,66089]
===
match
---
simple_stmt [11245,11296]
simple_stmt [11245,11296]
===
match
---
comp_op [8027,8033]
comp_op [8027,8033]
===
match
---
simple_stmt [75669,75944]
simple_stmt [75681,75956]
===
match
---
suite [15618,15668]
suite [15618,15668]
===
match
---
trailer [13127,13129]
trailer [13127,13129]
===
match
---
arglist [78736,78753]
arglist [78748,78765]
===
match
---
name: update [59914,59920]
name: update [59926,59932]
===
match
---
name: email_for_state [56445,56460]
name: email_for_state [56457,56472]
===
match
---
param [30043,30048]
param [30043,30048]
===
match
---
expr_stmt [68713,68741]
expr_stmt [68725,68753]
===
match
---
name: state [44526,44531]
name: state [44526,44531]
===
match
---
trailer [11848,12013]
trailer [11848,12013]
===
match
---
and_test [35902,35985]
and_test [35902,35985]
===
match
---
expr_stmt [78944,78986]
expr_stmt [78956,78998]
===
match
---
simple_stmt [60996,61225]
simple_stmt [61008,61237]
===
match
---
name: datetime [79332,79340]
name: datetime [79344,79352]
===
match
---
name: execution_date [58944,58958]
name: execution_date [58956,58970]
===
match
---
name: e [44623,44624]
name: e [44623,44624]
===
match
---
name: self [24145,24149]
name: self [24145,24149]
===
match
---
suite [43159,46422]
suite [43159,46422]
===
match
---
trailer [41285,41291]
trailer [41285,41291]
===
match
---
name: State [50874,50879]
name: State [50874,50879]
===
match
---
string: '' [59663,59665]
string: '' [59675,59677]
===
match
---
trailer [46336,46340]
trailer [46336,46340]
===
match
---
argument [68958,68977]
argument [68970,68989]
===
match
---
expr_stmt [58250,58321]
expr_stmt [58262,58333]
===
match
---
trailer [80513,80527]
trailer [80525,80539]
===
match
---
name: key [74653,74656]
name: key [74665,74668]
===
match
---
operator: , [78119,78120]
operator: , [78131,78132]
===
match
---
trailer [69369,69376]
trailer [69381,69388]
===
match
---
string: 'json' [64047,64053]
string: 'json' [64059,64065]
===
match
---
operator: = [11322,11323]
operator: = [11322,11323]
===
match
---
name: default_var [61849,61860]
name: default_var [61861,61872]
===
match
---
trailer [20168,20172]
trailer [20168,20172]
===
match
---
trailer [26817,26832]
trailer [26817,26832]
===
match
---
atom [3294,3296]
atom [3294,3296]
===
match
---
simple_stmt [1978,2023]
simple_stmt [1978,2023]
===
match
---
atom_expr [71167,71180]
atom_expr [71179,71192]
===
match
---
trailer [78652,78668]
trailer [78664,78680]
===
match
---
trailer [36436,36442]
trailer [36436,36442]
===
match
---
name: execution_date [34812,34826]
name: execution_date [34812,34826]
===
match
---
dictorsetmaker [45754,45781]
dictorsetmaker [45754,45781]
===
match
---
name: self [9766,9770]
name: self [9766,9770]
===
match
---
name: test_mode [54685,54694]
name: test_mode [54685,54694]
===
match
---
trailer [6179,6200]
trailer [6179,6200]
===
match
---
if_stmt [80720,80830]
if_stmt [80732,80842]
===
match
---
comparison [35902,35934]
comparison [35902,35934]
===
match
---
trailer [12830,12846]
trailer [12830,12846]
===
match
---
name: self [25655,25659]
name: self [25655,25659]
===
match
---
trailer [21105,21107]
trailer [21105,21107]
===
match
---
operator: = [69518,69519]
operator: = [69530,69531]
===
match
---
name: ti [23155,23157]
name: ti [23155,23157]
===
match
---
parameters [79152,79158]
parameters [79164,79170]
===
match
---
param [15040,15063]
param [15040,15063]
===
match
---
atom_expr [48788,48826]
atom_expr [48788,48826]
===
match
---
name: dep_context [2327,2338]
name: dep_context [2327,2338]
===
match
---
name: error [4651,4656]
name: error [4651,4656]
===
match
---
string: '' [59740,59742]
string: '' [59752,59754]
===
match
---
name: airflow [2028,2035]
name: airflow [2028,2035]
===
match
---
name: ti [5616,5618]
name: ti [5616,5618]
===
match
---
trailer [54783,54793]
trailer [54783,54789]
===
match
---
trailer [5369,5376]
trailer [5369,5376]
===
match
---
name: Exception [4487,4496]
name: Exception [4487,4496]
===
match
---
atom_expr [53719,53966]
atom_expr [53719,53966]
===
match
---
operator: , [16060,16061]
operator: , [16060,16061]
===
match
---
atom_expr [76885,76893]
atom_expr [76897,76905]
===
match
---
suite [39476,39539]
suite [39476,39539]
===
match
---
suite [53561,53581]
suite [53561,53581]
===
match
---
operator: , [36858,36859]
operator: , [36858,36859]
===
match
---
simple_stmt [68713,68742]
simple_stmt [68725,68754]
===
match
---
name: values_ordered_by_id [75239,75259]
name: values_ordered_by_id [75251,75271]
===
match
---
tfpdef [36567,36580]
tfpdef [36567,36580]
===
match
---
trailer [34747,34754]
trailer [34747,34754]
===
match
---
trailer [66835,66843]
trailer [66847,66855]
===
match
---
simple_stmt [48648,48684]
simple_stmt [48648,48684]
===
match
---
operator: , [65955,65956]
operator: , [65967,65968]
===
match
---
decorated [76084,77999]
decorated [76096,78011]
===
match
---
decorator [35991,36008]
decorator [35991,36008]
===
match
---
simple_stmt [13110,13130]
simple_stmt [13110,13130]
===
match
---
import_as_names [958,977]
import_as_names [958,977]
===
match
---
trailer [40832,40840]
trailer [40832,40840]
===
match
---
atom_expr [45739,45749]
atom_expr [45739,45749]
===
match
---
arglist [8388,8445]
arglist [8388,8445]
===
match
---
operator: @ [79540,79541]
operator: @ [79552,79553]
===
match
---
name: self [58939,58943]
name: self [58951,58955]
===
match
---
name: property [28959,28967]
name: property [28959,28967]
===
match
---
name: next_ds [59058,59065]
name: next_ds [59070,59077]
===
match
---
param [15009,15031]
param [15009,15031]
===
match
---
funcdef [8952,9125]
funcdef [8952,9125]
===
match
---
simple_stmt [55192,55212]
simple_stmt [55204,55224]
===
match
---
param [57314,57319]
param [57326,57331]
===
match
---
name: state [40789,40794]
name: state [40789,40794]
===
match
---
simple_stmt [79975,80004]
simple_stmt [79987,80016]
===
match
---
trailer [81140,81149]
trailer [81152,81161]
===
match
---
trailer [43109,43114]
trailer [43109,43114]
===
match
---
operator: = [51963,51964]
operator: = [51963,51964]
===
match
---
trailer [39373,39475]
trailer [39373,39475]
===
match
---
name: job_id [23074,23080]
name: job_id [23074,23080]
===
match
---
operator: , [33655,33656]
operator: , [33655,33656]
===
match
---
name: sanitized_pod [67418,67431]
name: sanitized_pod [67430,67443]
===
match
---
atom_expr [58075,58115]
atom_expr [58087,58127]
===
match
---
trailer [4641,4646]
trailer [4641,4646]
===
match
---
name: jinja_env [69172,69181]
name: jinja_env [69184,69193]
===
match
---
operator: , [29881,29882]
operator: , [29881,29882]
===
match
---
atom_expr [52872,52885]
atom_expr [52872,52885]
===
match
---
atom_expr [48284,48501]
atom_expr [48284,48501]
===
match
---
operator: , [1332,1333]
operator: , [1332,1333]
===
match
---
operator: = [62398,62399]
operator: = [62410,62411]
===
match
---
name: Integer [11206,11213]
name: Integer [11206,11213]
===
match
---
atom_expr [23029,23042]
atom_expr [23029,23042]
===
match
---
operator: , [52509,52510]
operator: , [52509,52510]
===
match
---
return_stmt [41341,41353]
return_stmt [41341,41353]
===
match
---
name: XCOM_RETURN_KEY [72759,72774]
name: XCOM_RETURN_KEY [72771,72786]
===
match
---
operator: < [35966,35967]
operator: < [35966,35967]
===
match
---
trailer [11330,11364]
trailer [11330,11364]
===
match
---
name: dep_context [40711,40722]
name: dep_context [40711,40722]
===
match
---
name: Integer [10996,11003]
name: Integer [10996,11003]
===
match
---
operator: == [77619,77621]
operator: == [77631,77633]
===
match
---
atom_expr [55132,55141]
atom_expr [55144,55153]
===
match
---
atom_expr [14114,14130]
atom_expr [14114,14130]
===
match
---
name: ignore_depends_on_past [16097,16119]
name: ignore_depends_on_past [16097,16119]
===
match
---
name: task [55125,55129]
name: task [55137,55141]
===
match
---
name: AirflowException [45530,45546]
name: AirflowException [45530,45546]
===
match
---
param [51747,51784]
param [51747,51784]
===
match
---
name: DagRun [36378,36384]
name: DagRun [36378,36384]
===
match
---
decorator [24727,24737]
decorator [24727,24737]
===
match
---
name: self [47360,47364]
name: self [47360,47364]
===
match
---
expr_stmt [48779,48826]
expr_stmt [48779,48826]
===
match
---
name: encode [34866,34872]
name: encode [34866,34872]
===
match
---
atom_expr [80679,80699]
atom_expr [80691,80711]
===
match
---
trailer [3320,3330]
trailer [3320,3330]
===
match
---
name: self [41431,41435]
name: self [41431,41435]
===
match
---
name: log [48289,48292]
name: log [48289,48292]
===
match
---
name: write [47235,47240]
name: write [47235,47240]
===
match
---
funcdef [65306,65899]
funcdef [65318,65911]
===
match
---
not_test [41590,41603]
not_test [41590,41603]
===
match
---
decorator [79926,79936]
decorator [79938,79948]
===
match
---
funcdef [53383,54323]
funcdef [53383,54323]
===
match
---
name: TaskInstance [77109,77121]
name: TaskInstance [77121,77133]
===
match
---
name: State [75883,75888]
name: State [75895,75900]
===
match
---
name: self [9335,9339]
name: self [9335,9339]
===
match
---
trailer [69898,69908]
trailer [69910,69920]
===
match
---
trailer [78589,78596]
trailer [78601,78608]
===
match
---
operator: , [15216,15217]
operator: , [15216,15217]
===
match
---
name: current_time [25231,25243]
name: current_time [25231,25243]
===
match
---
name: params [65949,65955]
name: params [65961,65967]
===
match
---
simple_stmt [33517,33753]
simple_stmt [33517,33753]
===
match
---
name: path [70105,70109]
name: path [70117,70121]
===
match
---
simple_stmt [61932,62127]
simple_stmt [61944,62139]
===
match
---
raise_stmt [72154,72348]
raise_stmt [72166,72360]
===
match
---
name: log [41436,41439]
name: log [41436,41439]
===
match
---
name: next_execution_date [59215,59234]
name: next_execution_date [59227,59246]
===
match
---
trailer [56276,56282]
trailer [56288,56294]
===
match
---
operator: , [56824,56825]
operator: , [56836,56837]
===
match
---
atom_expr [6292,6305]
atom_expr [6292,6305]
===
match
---
not_test [38606,38625]
not_test [38606,38625]
===
match
---
simple_stmt [41394,41423]
simple_stmt [41394,41423]
===
match
---
suite [3661,3943]
suite [3661,3943]
===
match
---
return_stmt [79261,79288]
return_stmt [79273,79300]
===
match
---
trailer [35906,35912]
trailer [35906,35912]
===
match
---
simple_stmt [3760,3943]
simple_stmt [3760,3943]
===
match
---
operator: , [14971,14972]
operator: , [14971,14972]
===
match
---
name: on_kill [49933,49940]
name: on_kill [49933,49940]
===
match
---
if_stmt [12643,12847]
if_stmt [12643,12847]
===
match
---
expr_stmt [11068,11101]
expr_stmt [11068,11101]
===
match
---
name: TaskInstance [26627,26639]
name: TaskInstance [26627,26639]
===
match
---
operator: @ [25666,25667]
operator: @ [25666,25667]
===
match
---
trailer [57841,57901]
trailer [57853,57913]
===
match
---
name: self [78677,78681]
name: self [78689,78693]
===
match
---
operator: = [59712,59713]
operator: = [59724,59725]
===
match
---
arglist [55364,55382]
arglist [55376,55394]
===
match
---
name: self [40824,40828]
name: self [40824,40828]
===
match
---
name: registered [48522,48532]
name: registered [48522,48532]
===
match
---
operator: , [71306,71307]
operator: , [71318,71319]
===
match
---
operator: , [10581,10582]
operator: , [10581,10582]
===
match
---
name: state [78607,78612]
name: state [78619,78624]
===
match
---
trailer [35666,35682]
trailer [35666,35682]
===
match
---
operator: = [22606,22607]
operator: = [22606,22607]
===
match
---
trailer [59886,59893]
trailer [59898,59905]
===
match
---
name: task_copy [47835,47844]
name: task_copy [47835,47844]
===
match
---
name: task [42067,42071]
name: task [42067,42071]
===
match
---
simple_stmt [71075,71141]
simple_stmt [71087,71153]
===
match
---
trailer [45062,45081]
trailer [45062,45081]
===
match
---
operator: = [23043,23044]
operator: = [23043,23044]
===
match
---
name: self [79960,79964]
name: self [79972,79976]
===
match
---
operator: , [53866,53867]
operator: , [53866,53867]
===
match
---
string: 'params' [63135,63143]
string: 'params' [63147,63155]
===
match
---
name: filepath [15657,15665]
name: filepath [15657,15665]
===
match
---
string: 'execution_date' [42732,42748]
string: 'execution_date' [42732,42748]
===
match
---
trailer [15587,15601]
trailer [15587,15601]
===
match
---
trailer [19391,19404]
trailer [19391,19404]
===
match
---
atom_expr [24927,24942]
atom_expr [24927,24942]
===
match
---
atom_expr [23929,23944]
atom_expr [23929,23944]
===
match
---
atom_expr [22306,22318]
atom_expr [22306,22318]
===
match
---
param [54471,54496]
param [54471,54496]
===
match
---
name: items [7368,7373]
name: items [7368,7373]
===
match
---
name: item [62353,62357]
name: item [62365,62369]
===
match
---
operator: , [39199,39200]
operator: , [39199,39200]
===
match
---
expr_stmt [70458,70534]
expr_stmt [70470,70546]
===
match
---
simple_stmt [70697,70781]
simple_stmt [70709,70793]
===
match
---
operator: = [69329,69330]
operator: = [69341,69342]
===
match
---
name: executor_config [78653,78668]
name: executor_config [78665,78680]
===
match
---
name: self [13522,13526]
name: self [13522,13526]
===
match
---
decorated [75500,75944]
decorated [75512,75956]
===
match
---
atom_expr [7571,7631]
atom_expr [7571,7631]
===
match
---
name: error [56527,56532]
name: error [56539,56544]
===
match
---
string: "XCom data cleared" [24701,24720]
string: "XCom data cleared" [24701,24720]
===
match
---
atom_expr [26813,26832]
atom_expr [26813,26832]
===
match
---
trailer [77353,77368]
trailer [77365,77380]
===
match
---
expr_stmt [10364,10395]
expr_stmt [10364,10395]
===
match
---
fstring_expr [19993,20006]
fstring_expr [19993,20006]
===
match
---
parameters [70971,70977]
parameters [70983,70989]
===
match
---
trailer [52133,52520]
trailer [52133,52520]
===
match
---
name: ts_nodash [59561,59570]
name: ts_nodash [59573,59582]
===
match
---
string: "DagModel" [11858,11868]
string: "DagModel" [11858,11868]
===
match
---
operator: , [31903,31904]
operator: , [31903,31904]
===
match
---
fstring_string: __ [59855,59857]
fstring_string: __ [59867,59869]
===
match
---
operator: = [78561,78562]
operator: = [78573,78574]
===
match
---
if_stmt [56651,56701]
if_stmt [56663,56713]
===
match
---
fstring_end: " [15666,15667]
fstring_end: " [15666,15667]
===
match
---
name: TaskInstance [77904,77916]
name: TaskInstance [77916,77928]
===
match
---
simple_stmt [8804,8846]
simple_stmt [8804,8846]
===
match
---
name: jobs [7522,7526]
name: jobs [7522,7526]
===
match
---
name: State [25477,25482]
name: State [25477,25482]
===
match
---
trailer [23980,24002]
trailer [23980,24002]
===
match
---
atom_expr [50860,50870]
atom_expr [50860,50870]
===
match
---
name: task_id [5488,5495]
name: task_id [5488,5495]
===
match
---
name: tis [8044,8047]
name: tis [8044,8047]
===
match
---
atom_expr [58010,58031]
atom_expr [58022,58043]
===
match
---
name: _executor_config [79987,80003]
name: _executor_config [79999,80015]
===
match
---
name: run_id [57527,57533]
name: run_id [57539,57545]
===
match
---
atom_expr [69894,69908]
atom_expr [69906,69920]
===
match
---
name: state [11642,11647]
name: state [11642,11647]
===
match
---
arglist [59962,60001]
arglist [59974,60013]
===
match
---
name: COLLATION_ARGS [1865,1879]
name: COLLATION_ARGS [1865,1879]
===
match
---
expr_stmt [74570,74812]
expr_stmt [74582,74824]
===
match
---
simple_stmt [78304,78334]
simple_stmt [78316,78346]
===
match
---
name: str [71321,71324]
name: str [71333,71336]
===
match
---
trailer [56367,56378]
trailer [56379,56390]
===
match
---
name: log [54780,54783]
name: log [54780,54783]
===
match
---
name: airflow [57416,57423]
name: airflow [57428,57435]
===
match
---
name: self [25697,25701]
name: self [25697,25701]
===
match
---
operator: , [33037,33038]
operator: , [33037,33038]
===
match
---
trailer [4455,4460]
trailer [4455,4460]
===
match
---
trailer [49799,49801]
trailer [49799,49801]
===
match
---
suite [14094,14131]
suite [14094,14131]
===
match
---
trailer [59145,59153]
trailer [59157,59165]
===
match
---
trailer [71079,71088]
trailer [71091,71100]
===
match
---
param [60621,60625]
param [60633,60637]
===
match
---
name: IO [3969,3971]
name: IO [3969,3971]
===
match
---
name: self [28128,28132]
name: self [28128,28132]
===
match
---
name: _pool [78816,78821]
name: _pool [78828,78833]
===
match
---
operator: , [1324,1325]
operator: , [1324,1325]
===
match
---
name: verbose [52147,52154]
name: verbose [52147,52154]
===
match
---
name: self [75970,75974]
name: self [75982,75986]
===
match
---
name: List [3278,3282]
name: List [3278,3282]
===
match
---
simple_stmt [57765,57941]
simple_stmt [57777,57953]
===
match
---
param [71334,71345]
param [71346,71357]
===
match
---
if_stmt [56106,56354]
if_stmt [56118,56366]
===
match
---
name: math [842,846]
name: math [842,846]
===
match
---
name: task [59842,59846]
name: task [59854,59858]
===
match
---
trailer [41632,41653]
trailer [41632,41653]
===
match
---
name: session [33477,33484]
name: session [33477,33484]
===
match
---
atom_expr [69843,69858]
atom_expr [69855,69870]
===
match
---
suite [33993,35728]
suite [33993,35728]
===
match
---
name: STATICA_HACK [80850,80862]
name: STATICA_HACK [80862,80874]
===
match
---
name: NONE [6160,6164]
name: NONE [6160,6164]
===
match
---
name: key [70020,70023]
name: key [70032,70035]
===
match
---
operator: = [43138,43139]
operator: = [43138,43139]
===
match
---
trailer [47234,47240]
trailer [47234,47240]
===
match
---
parameters [21649,21692]
parameters [21649,21692]
===
match
---
trailer [31221,31241]
trailer [31221,31241]
===
match
---
atom_expr [54517,54530]
atom_expr [54517,54530]
===
match
---
name: filter [7594,7600]
name: filter [7594,7600]
===
match
---
name: execution_date [57886,57900]
name: execution_date [57898,57912]
===
match
---
trailer [33413,33418]
trailer [33413,33418]
===
match
---
param [72784,72818]
param [72796,72830]
===
match
---
operator: = [11288,11289]
operator: = [11288,11289]
===
match
---
name: property [79461,79469]
name: property [79473,79481]
===
match
---
trailer [24034,24046]
trailer [24034,24046]
===
match
---
name: dry_run [53347,53354]
name: dry_run [53347,53354]
===
match
---
operator: @ [21230,21231]
operator: @ [21230,21231]
===
match
---
atom_expr [78382,78402]
atom_expr [78394,78414]
===
match
---
tfpdef [4300,4328]
tfpdef [4300,4328]
===
match
---
name: state [25436,25441]
name: state [25436,25441]
===
match
---
decorated [24181,24722]
decorated [24181,24722]
===
match
---
fstring_start: f" [15638,15640]
fstring_start: f" [15638,15640]
===
match
---
trailer [75835,75843]
trailer [75847,75855]
===
match
---
arglist [65558,65579]
arglist [65570,65591]
===
match
---
simple_stmt [10677,10702]
simple_stmt [10677,10702]
===
match
---
name: task [56630,56634]
name: task [56642,56646]
===
match
---
operator: = [58127,58128]
operator: = [58139,58140]
===
match
---
atom_expr [11570,11614]
atom_expr [11570,11614]
===
match
---
name: args [44811,44815]
name: args [44811,44815]
===
match
---
name: task_id [76675,76682]
name: task_id [76687,76694]
===
match
---
name: QUEUED [4809,4815]
name: QUEUED [4809,4815]
===
match
---
name: next_execution_date [58889,58908]
name: next_execution_date [58901,58920]
===
match
---
operator: = [42425,42426]
operator: = [42425,42426]
===
match
---
atom_expr [48880,48934]
atom_expr [48880,48934]
===
match
---
operator: , [38377,38378]
operator: , [38377,38378]
===
match
---
fstring_string: /log?execution_date= [19937,19957]
fstring_string: /log?execution_date= [19937,19957]
===
match
---
name: with_for_update [22444,22459]
name: with_for_update [22444,22459]
===
match
---
operator: = [10378,10379]
operator: = [10378,10379]
===
match
---
atom_expr [30538,30579]
atom_expr [30538,30579]
===
match
---
name: utcnow [55175,55181]
name: utcnow [55187,55193]
===
match
---
trailer [49253,49260]
trailer [49253,49260]
===
match
---
expr_stmt [56168,56193]
expr_stmt [56180,56205]
===
match
---
name: Union [56815,56820]
name: Union [56827,56832]
===
match
---
operator: , [63804,63805]
operator: , [63816,63817]
===
match
---
atom_expr [6941,6958]
atom_expr [6941,6958]
===
match
---
name: jinja_context [69577,69590]
name: jinja_context [69589,69602]
===
match
---
atom_expr [19381,19404]
atom_expr [19381,19404]
===
match
---
expr_stmt [22590,22621]
expr_stmt [22590,22621]
===
match
---
fstring_string: . [46124,46125]
fstring_string: . [46124,46125]
===
match
---
operator: = [16343,16344]
operator: = [16343,16344]
===
match
---
atom_expr [75263,75283]
atom_expr [75275,75295]
===
match
---
operator: == [76925,76927]
operator: == [76937,76939]
===
match
---
name: str [42421,42424]
name: str [42421,42424]
===
match
---
trailer [7578,7584]
trailer [7578,7584]
===
match
---
operator: , [75789,75790]
operator: , [75801,75802]
===
match
---
operator: = [10616,10617]
operator: = [10616,10617]
===
match
---
trailer [10915,10924]
trailer [10915,10924]
===
match
---
atom_expr [41394,41422]
atom_expr [41394,41422]
===
match
---
name: dag_run [66043,66050]
name: dag_run [66055,66062]
===
match
---
simple_stmt [19435,19459]
simple_stmt [19435,19459]
===
match
---
name: add [41625,41628]
name: add [41625,41628]
===
match
---
trailer [31503,31508]
trailer [31503,31508]
===
match
---
suite [27973,28006]
suite [27973,28006]
===
match
---
expr_stmt [10737,10791]
expr_stmt [10737,10791]
===
match
---
tfpdef [72748,72756]
tfpdef [72760,72768]
===
match
---
name: self [65558,65562]
name: self [65570,65574]
===
match
---
simple_stmt [20063,20092]
simple_stmt [20063,20092]
===
match
---
param [53412,53430]
param [53412,53430]
===
match
---
expr_stmt [59175,59235]
expr_stmt [59187,59247]
===
match
---
name: session [38463,38470]
name: session [38463,38470]
===
match
---
trailer [55456,55471]
trailer [55468,55483]
===
match
---
name: html_content_err [70720,70736]
name: html_content_err [70732,70748]
===
match
---
trailer [58938,58959]
trailer [58950,58971]
===
match
---
operator: , [56878,56879]
operator: , [56890,56891]
===
match
---
trailer [78565,78576]
trailer [78577,78588]
===
match
---
argument [67201,67283]
argument [67213,67295]
===
match
---
if_stmt [80918,81150]
if_stmt [80930,81162]
===
match
---
trailer [18813,18815]
trailer [18813,18815]
===
match
---
trailer [7463,7471]
trailer [7463,7471]
===
match
---
simple_stmt [57147,57192]
simple_stmt [57159,57204]
===
match
---
atom_expr [28089,28214]
atom_expr [28089,28214]
===
match
---
atom_expr [34556,34577]
atom_expr [34556,34577]
===
match
---
name: self [54169,54173]
name: self [54169,54173]
===
match
---
argument [28806,28817]
argument [28806,28817]
===
match
---
name: os [44105,44107]
name: os [44105,44107]
===
match
---
trailer [27453,27470]
trailer [27453,27470]
===
match
---
name: str [72673,72676]
name: str [72685,72688]
===
match
---
operator: = [74793,74794]
operator: = [74805,74806]
===
match
---
trailer [7367,7373]
trailer [7367,7373]
===
match
---
atom_expr [21023,21050]
atom_expr [21023,21050]
===
match
---
atom_expr [10989,11031]
atom_expr [10989,11031]
===
match
---
name: commit [21595,21601]
name: commit [21595,21601]
===
match
---
param [49480,49488]
param [49480,49488]
===
match
---
expr_stmt [44178,44215]
expr_stmt [44178,44215]
===
match
---
simple_stmt [46271,46291]
simple_stmt [46271,46291]
===
match
---
name: session [52502,52509]
name: session [52502,52509]
===
match
---
name: _key [79916,79920]
name: _key [79928,79932]
===
match
---
string: """         Immediately runs the task (without checking or changing db state         before execution) and then sets the appropriate final state after         completion and runs any post-execute callbacks. Meant to be called         only after another function changes the state to running.          :param mark_success: Don't run the task, mark its state as success         :type mark_success: bool         :param test_mode: Doesn't record success or failure in the DB         :type test_mode: bool         :param pool: specifies the pool to use to run the task instance         :type pool: str         :param session: SQLAlchemy ORM Session         :type session: Session         """ [43168,43854]
string: """         Immediately runs the task (without checking or changing db state         before execution) and then sets the appropriate final state after         completion and runs any post-execute callbacks. Meant to be called         only after another function changes the state to running.          :param mark_success: Don't run the task, mark its state as success         :type mark_success: bool         :param test_mode: Doesn't record success or failure in the DB         :type test_mode: bool         :param pool: specifies the pool to use to run the task instance         :type pool: str         :param session: SQLAlchemy ORM Session         :type session: Session         """ [43168,43854]
===
match
---
trailer [25286,25334]
trailer [25286,25334]
===
match
---
operator: , [31713,31714]
operator: , [31713,31714]
===
match
---
name: set_error_file [4268,4282]
name: set_error_file [4268,4282]
===
match
---
and_test [57207,57262]
and_test [57219,57274]
===
match
---
return_stmt [61534,61554]
return_stmt [61546,61566]
===
match
---
trailer [78790,78802]
trailer [78802,78814]
===
match
---
name: first [76669,76674]
name: first [76681,76686]
===
match
---
trailer [39949,39967]
trailer [39949,39967]
===
match
---
name: dag_id [10474,10480]
name: dag_id [10474,10480]
===
match
---
name: query [26610,26615]
name: query [26610,26615]
===
match
---
operator: { [57492,57493]
operator: { [57504,57505]
===
match
---
exprlist [7243,7269]
exprlist [7243,7269]
===
match
---
trailer [19009,19020]
trailer [19009,19020]
===
match
---
atom_expr [49374,49450]
atom_expr [49374,49450]
===
match
---
name: logging [827,834]
name: logging [827,834]
===
match
---
operator: = [31884,31885]
operator: = [31884,31885]
===
match
---
operator: = [11154,11155]
operator: = [11154,11155]
===
match
---
operator: = [44898,44899]
operator: = [44898,44899]
===
match
---
name: self [9410,9414]
name: self [9410,9414]
===
match
---
dotted_name [2481,2494]
dotted_name [2481,2494]
===
match
---
trailer [33531,33752]
trailer [33531,33752]
===
match
---
operator: = [71181,71182]
operator: = [71193,71194]
===
match
---
parameters [49473,49499]
parameters [49473,49499]
===
match
---
simple_stmt [20543,20825]
simple_stmt [20543,20825]
===
match
---
operator: = [58073,58074]
operator: = [58085,58086]
===
match
---
name: SUCCESS [52999,53006]
name: SUCCESS [52999,53006]
===
match
---
param [12038,12043]
param [12038,12043]
===
match
---
name: self [55192,55196]
name: self [55204,55208]
===
match
---
if_stmt [19349,19405]
if_stmt [19349,19405]
===
match
---
return_stmt [36464,36473]
return_stmt [36464,36473]
===
match
---
simple_stmt [55150,55184]
simple_stmt [55162,55196]
===
match
---
operator: , [64629,64630]
operator: , [64641,64642]
===
match
---
operator: { [44246,44247]
operator: { [44246,44247]
===
match
---
atom_expr [47360,47372]
atom_expr [47360,47372]
===
match
---
trailer [53083,53106]
trailer [53083,53106]
===
match
---
operator: = [69965,69966]
operator: = [69977,69978]
===
match
---
atom_expr [44349,44376]
atom_expr [44349,44376]
===
match
---
name: self [51269,51273]
name: self [51269,51273]
===
match
---
name: get_template_context [51505,51525]
name: get_template_context [51505,51525]
===
match
---
name: task_copy [53286,53295]
name: task_copy [53286,53295]
===
match
---
operator: , [46005,46006]
operator: , [46005,46006]
===
match
---
name: commit [58052,58058]
name: commit [58064,58070]
===
match
---
simple_stmt [2179,2240]
simple_stmt [2179,2240]
===
match
---
name: task [26517,26521]
name: task [26517,26521]
===
match
---
simple_stmt [21587,21604]
simple_stmt [21587,21604]
===
match
---
string: 'task' [67720,67726]
string: 'task' [67732,67738]
===
match
---
simple_stmt [49271,49291]
simple_stmt [49271,49291]
===
match
---
name: kube_image [66921,66931]
name: kube_image [66933,66943]
===
match
---
tfpdef [30678,30694]
tfpdef [30678,30694]
===
match
---
name: property [79611,79619]
name: property [79623,79631]
===
match
---
simple_stmt [2240,2274]
simple_stmt [2240,2274]
===
match
---
operator: @ [3333,3334]
operator: @ [3333,3334]
===
match
---
operator: , [16271,16272]
operator: , [16271,16272]
===
match
---
trailer [10694,10701]
trailer [10694,10701]
===
match
---
atom_expr [21461,21516]
atom_expr [21461,21516]
===
match
---
parameters [46471,46492]
parameters [46471,46492]
===
match
---
trailer [69250,69277]
trailer [69262,69289]
===
match
---
name: ignore_task_deps [52280,52296]
name: ignore_task_deps [52280,52296]
===
match
---
operator: = [25523,25524]
operator: = [25523,25524]
===
match
---
name: hashlib [34700,34707]
name: hashlib [34700,34707]
===
match
---
operator: -> [36924,36926]
operator: -> [36924,36926]
===
match
---
expr_stmt [78342,78373]
expr_stmt [78354,78385]
===
match
---
name: dag_id [42666,42672]
name: dag_id [42666,42672]
===
match
---
name: task [53237,53241]
name: task [53237,53241]
===
match
---
string: """     Sets the current execution context to the provided context object.     This method should be called once per Task execution, before calling operator.execute.     """ [3407,3580]
string: """     Sets the current execution context to the provided context object.     This method should be called once per Task execution, before calling operator.execute.     """ [3407,3580]
===
match
---
name: integrate_macros_plugins [57447,57471]
name: integrate_macros_plugins [57459,57483]
===
match
---
atom_expr [66831,66843]
atom_expr [66843,66855]
===
match
---
atom_expr [28668,28717]
atom_expr [28668,28717]
===
match
---
name: queued_by_job_id [11180,11196]
name: queued_by_job_id [11180,11196]
===
match
---
atom_expr [72525,72544]
atom_expr [72537,72556]
===
match
---
name: delete [7421,7427]
name: delete [7421,7427]
===
match
---
atom_expr [34807,34826]
atom_expr [34807,34826]
===
match
---
trailer [8503,8509]
trailer [8503,8509]
===
match
---
name: ignore_all_deps [40472,40487]
name: ignore_all_deps [40472,40487]
===
match
---
trailer [70217,70219]
trailer [70229,70231]
===
match
---
atom_expr [7353,7375]
atom_expr [7353,7375]
===
match
---
trailer [19673,19680]
trailer [19673,19680]
===
match
---
operator: , [50615,50616]
operator: , [50615,50616]
===
match
---
expr_stmt [10828,10859]
expr_stmt [10828,10859]
===
match
---
name: ti [78563,78565]
name: ti [78575,78577]
===
match
---
operator: , [63446,63447]
operator: , [63458,63459]
===
match
---
name: job_id [10900,10906]
name: job_id [10900,10906]
===
match
---
name: rendered_task_instance_fields [64572,64601]
name: rendered_task_instance_fields [64584,64613]
===
match
---
expr_stmt [15737,15761]
expr_stmt [15737,15761]
===
match
---
atom_expr [36874,36887]
atom_expr [36874,36887]
===
match
---
operator: = [11115,11116]
operator: = [11115,11116]
===
match
---
name: Session [72836,72843]
name: Session [72848,72855]
===
match
---
name: TaskInstance [75755,75767]
name: TaskInstance [75767,75779]
===
match
---
trailer [59429,59438]
trailer [59441,59450]
===
match
---
comp_op [7698,7704]
comp_op [7698,7704]
===
match
---
trailer [54173,54185]
trailer [54173,54185]
===
match
---
name: ignore_all_deps [38586,38601]
name: ignore_all_deps [38586,38601]
===
match
---
trailer [77187,77251]
trailer [77199,77263]
===
match
---
name: self [38407,38411]
name: self [38407,38411]
===
match
---
simple_stmt [2554,2601]
simple_stmt [2554,2601]
===
match
---
operator: , [43143,43144]
operator: , [43143,43144]
===
match
---
trailer [3310,3320]
trailer [3310,3320]
===
match
---
string: 'BASE_URL' [20186,20196]
string: 'BASE_URL' [20186,20196]
===
match
---
return_stmt [62634,62653]
return_stmt [62646,62665]
===
match
---
suite [31330,31816]
suite [31330,31816]
===
match
---
param [46722,46729]
param [46722,46729]
===
match
---
name: qry [80818,80821]
name: qry [80830,80833]
===
match
---
name: TaskInstance [77709,77721]
name: TaskInstance [77721,77733]
===
match
---
parameters [75555,75570]
parameters [75567,75582]
===
match
---
name: self [53778,53782]
name: self [53778,53782]
===
match
---
name: UP_FOR_RETRY [56291,56303]
name: UP_FOR_RETRY [56303,56315]
===
match
---
name: self [12736,12740]
name: self [12736,12740]
===
match
---
expr_stmt [69501,69591]
expr_stmt [69513,69603]
===
match
---
name: state [46146,46151]
name: state [46146,46151]
===
match
---
string: """         Generates the shell command required to execute this task instance.          :param dag_id: DAG ID         :type dag_id: str         :param task_id: Task ID         :type task_id: str         :param execution_date: Execution date for the task         :type execution_date: datetime         :param mark_success: Whether to mark the task as successful         :type mark_success: bool         :param ignore_all_deps: Ignore all ignorable dependencies.             Overrides the other ignore_* parameters.         :type ignore_all_deps: bool         :param ignore_depends_on_past: Ignore depends_on_past parameter of DAGs             (e.g. for Backfills)         :type ignore_depends_on_past: bool         :param ignore_task_deps: Ignore task-specific dependencies such as depends_on_past             and trigger rule         :type ignore_task_deps: bool         :param ignore_ti_state: Ignore the task instance's previous failure/success         :type ignore_ti_state: bool         :param local: Whether to run the task locally         :type local: bool         :param pickle_id: If the DAG was serialized to the DB, the ID             associated with the pickled DAG         :type pickle_id: Optional[int]         :param file_path: path to the file containing the DAG definition         :type file_path: Optional[str]         :param raw: raw mode (needs more details)         :type raw: Optional[bool]         :param job_id: job ID (needs more details)         :type job_id: Optional[int]         :param pool: the Airflow pool that the task should run in         :type pool: Optional[str]         :param cfg_path: the Path to the configuration file         :type cfg_path: Optional[str]         :return: shell command that can be used to run the task instance         :rtype: list[str]         """ [16966,18774]
string: """         Generates the shell command required to execute this task instance.          :param dag_id: DAG ID         :type dag_id: str         :param task_id: Task ID         :type task_id: str         :param execution_date: Execution date for the task         :type execution_date: datetime         :param mark_success: Whether to mark the task as successful         :type mark_success: bool         :param ignore_all_deps: Ignore all ignorable dependencies.             Overrides the other ignore_* parameters.         :type ignore_all_deps: bool         :param ignore_depends_on_past: Ignore depends_on_past parameter of DAGs             (e.g. for Backfills)         :type ignore_depends_on_past: bool         :param ignore_task_deps: Ignore task-specific dependencies such as depends_on_past             and trigger rule         :type ignore_task_deps: bool         :param ignore_ti_state: Ignore the task instance's previous failure/success         :type ignore_ti_state: bool         :param local: Whether to run the task locally         :type local: bool         :param pickle_id: If the DAG was serialized to the DB, the ID             associated with the pickled DAG         :type pickle_id: Optional[int]         :param file_path: path to the file containing the DAG definition         :type file_path: Optional[str]         :param raw: raw mode (needs more details)         :type raw: Optional[bool]         :param job_id: job ID (needs more details)         :type job_id: Optional[int]         :param pool: the Airflow pool that the task should run in         :type pool: Optional[str]         :param cfg_path: the Path to the configuration file         :type cfg_path: Optional[str]         :return: shell command that can be used to run the task instance         :rtype: list[str]         """ [16966,18774]
===
match
---
name: upper [80901,80906]
name: upper [80913,80918]
===
match
---
simple_stmt [66515,66541]
simple_stmt [66527,66553]
===
match
---
operator: ** [70281,70283]
operator: ** [70293,70295]
===
match
---
name: get_previous_ti [29419,29434]
name: get_previous_ti [29419,29434]
===
match
---
simple_stmt [78995,79023]
simple_stmt [79007,79035]
===
match
---
param [24990,25001]
param [24990,25001]
===
match
---
operator: @ [79926,79927]
operator: @ [79938,79939]
===
match
---
operator: , [3252,3253]
operator: , [3252,3253]
===
match
---
atom_expr [8245,8268]
atom_expr [8245,8268]
===
match
---
name: value [72401,72406]
name: value [72413,72418]
===
match
---
operator: = [23874,23875]
operator: = [23874,23875]
===
match
---
suite [38869,41354]
suite [38869,41354]
===
match
---
name: delay_backoff_in_seconds [35561,35585]
name: delay_backoff_in_seconds [35561,35585]
===
match
---
suite [48762,48827]
suite [48762,48827]
===
match
---
param [80078,80099]
param [80090,80111]
===
match
---
trailer [31055,31085]
trailer [31055,31085]
===
match
---
test [56379,56432]
test [56391,56444]
===
match
---
trailer [59153,59162]
trailer [59165,59174]
===
match
---
trailer [33408,33413]
trailer [33408,33413]
===
match
---
operator: = [34194,34195]
operator: = [34194,34195]
===
match
---
or_test [23876,23902]
or_test [23876,23902]
===
match
---
atom_expr [26870,26883]
atom_expr [26870,26883]
===
match
---
argument [10583,10599]
argument [10583,10599]
===
match
---
string: "TaskInstance.dag_id == DagModel.dag_id" [11890,11930]
string: "TaskInstance.dag_id == DagModel.dag_id" [11890,11930]
===
match
---
name: dag_id [74540,74546]
name: dag_id [74552,74558]
===
match
---
trailer [59913,59920]
trailer [59925,59932]
===
match
---
name: local [16184,16189]
name: local [16184,16189]
===
match
---
trailer [6943,6958]
trailer [6943,6958]
===
match
---
name: BaseJob [7543,7550]
name: BaseJob [7543,7550]
===
match
---
operator: , [16713,16714]
operator: , [16713,16714]
===
match
---
simple_stmt [8645,8666]
simple_stmt [8645,8666]
===
match
---
name: session [4704,4711]
name: session [4704,4711]
===
match
---
name: self [24055,24059]
name: self [24055,24059]
===
match
---
suite [27667,27935]
suite [27667,27935]
===
match
---
atom_expr [71091,71140]
atom_expr [71103,71152]
===
match
---
trailer [22951,22961]
trailer [22951,22961]
===
match
---
name: self [58707,58711]
name: self [58719,58723]
===
match
---
suite [4497,4663]
suite [4497,4663]
===
match
---
simple_stmt [5488,5509]
simple_stmt [5488,5509]
===
match
---
name: self [79870,79874]
name: self [79882,79886]
===
match
---
simple_stmt [38671,38712]
simple_stmt [38671,38712]
===
match
---
name: self [22902,22906]
name: self [22902,22906]
===
match
---
name: provide_session [51627,51642]
name: provide_session [51627,51642]
===
match
---
atom_expr [44224,44276]
atom_expr [44224,44276]
===
match
---
trailer [20865,20879]
trailer [20865,20879]
===
match
---
trailer [33396,33401]
trailer [33396,33401]
===
match
---
name: log [44838,44841]
name: log [44838,44841]
===
match
---
name: session [58010,58017]
name: session [58022,58029]
===
insert-node
---
name: TaskInstance [9779,9791]
to
classdef [9773,77999]
at 0
===
insert-tree
---
arglist [9792,9810]
    name: Base [9792,9796]
    operator: , [9796,9797]
    name: LoggingMixin [9798,9810]
to
classdef [9773,77999]
at 1
===
insert-tree
---
simple_stmt [9817,10359]
    string: """     Task instances store the state of a task instance. This table is the     authority and single source of truth around what tasks have run and the     state they are in.      The SqlAlchemy model doesn't have a SqlAlchemy foreign key to the task or     dag model deliberately to have more control over transactions.      Database transactions on this table should insure double triggers and     any confusion around what task instances are or aren't ready to run     even while multiple schedulers may be firing task instances.     """ [9817,10358]
to
suite [9812,77999]
at 0
===
update-node
---
name: exception [54784,54793]
replace exception by error
===
insert-node
---
arglist [54790,54834]
to
trailer [54793,54823]
at 0
===
move-tree
---
string: "Task failed with exception" [54794,54822]
to
arglist [54790,54834]
at 0
===
delete-node
---
name: TaskInstance [9779,9791]
===
===
delete-tree
---
arglist [9792,9810]
    name: Base [9792,9796]
    operator: , [9796,9797]
    name: LoggingMixin [9798,9810]
===
delete-tree
---
simple_stmt [9817,10359]
    string: """     Task instances store the state of a task instance. This table is the     authority and single source of truth around what tasks have run and the     state they are in.      The SqlAlchemy model doesn't have a SqlAlchemy foreign key to the task or     dag model deliberately to have more control over transactions.      Database transactions on this table should insure double triggers and     any confusion around what task instances are or aren't ready to run     even while multiple schedulers may be firing task instances.     """ [9817,10358]
